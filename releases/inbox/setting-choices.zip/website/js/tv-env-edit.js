// js/tv-env-edit.js — a setting's Edit button (Settings → Change here, and a company's card on Outside services;
// decisions/0125). A setting with set answers opens its choices, each with what it does (TvAsk.choose; data-choices,
// data-multi); any other, a one-field form (TvAsk.ask). Saved through /admin/api/env-setting.php, whose answer carries
// the next step: whether what it switched on works now, and a button that finishes the job (open the page, switch the
// setting it still needs, ask the service again) (Jason, 2026-11-17: "intuitive processing for action steps … start to
// finish an idea", never a box that assumes you know what to type).
// Use: TvEnvEdit.bind(root) — every [data-env] button inside root (a selector or element).
(function () {
  if (window.TvEnvEdit) return;

  async function post(body) {
    var csrf = (await (await fetch('/api/auth/session.php', { credentials: 'include' })).json()).csrf_token;
    return (await fetch('/admin/api/env-setting.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })).json();
  }

  // Shows the value on every Edit button and line for this setting on the page (a card and Settings can both show it).
  function shown(key, value, label) {
    document.querySelectorAll('[data-env="' + key + '"]').forEach(function (b) {
      b.dataset.value = value;
      var row = b.closest('.os-env, dd'), v = row && row.querySelector('[data-v]');
      if (v) v.textContent = label || value || 'Not set';
    });
  }

  function labelOf(b, value) {
    try { var c = JSON.parse(b.dataset.choices || '[]'); var names = value.split(',').map(function (v) { var x = c.filter(function (y) { return y[0] === v; })[0]; return x ? x[1] : v; }); return names.join(', '); }
    catch (e) { return value; }
  }

  // The step after a save: a notice, and its button when there's something left to do.
  async function step(next, anchor) {
    if (!next) return;
    if (!next.kind) { TvAsk.say(next.text, { anchor: anchor, bad: next.bad }); return; }
    var go = await TvAsk.confirm(next.text, { yes: next.label, no: 'Not now', danger: next.kind === 'set' && next.bad });
    if (!go) return;
    if (next.kind === 'go') { if (/^https?:/.test(next.target)) window.open(next.target, '_blank', 'noopener'); else location.href = next.target; return; }
    TvAsk.busy(anchor, true);
    try {
      var r = next.kind === 'set' ? await post({ key: next.target[0], value: next.target[1] }) : await post({ do: next.target });
      if (!r.ok) { TvAsk.say((r.error && r.error.message) || 'That didn\'t work. Try again.', { anchor: anchor, bad: true }); return; }
      if (next.kind === 'set') { var b2 = document.querySelector('[data-env="' + next.target[0] + '"]'); shown(next.target[0], r.value, b2 ? labelOf(b2, r.value) : r.value); }
      if (r.next) await step(r.next, anchor); else TvAsk.say(r.message, { anchor: anchor });
    } catch (e) { TvAsk.say('That didn\'t work. Try again.', { anchor: anchor, bad: true }); }
    finally { TvAsk.busy(anchor, false); }
  }

  async function edit(b) {
    if (b.disabled) return;
    var choices = null;
    try { choices = b.dataset.choices ? JSON.parse(b.dataset.choices) : null; } catch (e) {}
    var v = choices && choices.length
      ? await TvAsk.choose(b.dataset.label, choices, b.dataset.value, { multi: b.hasAttribute('data-multi'), note: b.hasAttribute('data-multi') ? 'Tick each one that applies; none means card only.' : '' })
      : await TvAsk.ask(b.dataset.label, b.dataset.value);
    if (v === null || v === undefined || v === b.dataset.value) return;
    TvAsk.busy(b, true);
    try {
      var r = await post({ key: b.dataset.env, value: v });
      if (!r.ok) { TvAsk.say((r.error && r.error.message) || 'That didn\'t save.', { anchor: b, bad: true }); return; }
      shown(b.dataset.env, r.value, choices ? labelOf(b, r.value) : '');
      TvAsk.busy(b, false);
      if (r.next) await step(r.next, b);
      else TvAsk.say(r.message + ' It\'s in use from the next page you open.', { anchor: b });
    } catch (e) { TvAsk.say('That didn\'t save. Try again.', { anchor: b, bad: true }); }
    finally { TvAsk.busy(b, false); }
  }

  function bind(root) {
    var r = typeof root === 'string' ? document.querySelector(root) : (root || document);
    if (!r) return;
    r.querySelectorAll('[data-env]').forEach(function (b) {
      if (b.__tvEnv) return; b.__tvEnv = true;
      b.addEventListener('click', function () { edit(b); });
    });
  }

  window.TvEnvEdit = { bind: bind };
})();
