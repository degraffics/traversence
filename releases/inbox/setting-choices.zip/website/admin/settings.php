<?php
// admin/settings.php — Settings, an area of the admin dashboard (decisions/0078). Read-only for now: how the site is
// set up, from the .env file (in the hosting account's home folder, above public_html) and the server. Secrets are
// never shown, only whether they're set. Changing a setting here, instead of in .env, is coming.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/crawler/AutoImport.php';

$pdo = Database::connection();
tv_admin_require($pdo);
$env = fn (string $k): string => trim((string) (getenv($k) ?: ''));
$set = fn (string $k): array => $env($k) !== '' ? ['Set', 'ok'] : ['Not set', ''];
$on = fn (string $k, string $default = 'on'): bool => strtolower($env($k) ?: $default) !== 'off';
$host = fn (string $u): string => (string) (parse_url($u, PHP_URL_HOST) ?: $u);
$sessDir = dirname(__DIR__, 2) . '/app/storage/sessions';
// database updates the site checks for: [table it makes => the file in app/migrations to run in phpMyAdmin]
$hasTable = function (string $t) use ($pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t($t) . ' LIMIT 1'); return true; } catch (Throwable) { return false; } };
$dbFiles = ['search_outcomes' => '2026-10-19_search_outcomes.sql', 'resource_guides' => '2026-10-22_resource_guides.sql', 'search_learned' => '2026-10-23_search_learning.sql',
            'search_senses' => '2026-10-24_word_senses.sql', 'member_actions' => '2026-11-17_member_standing.sql', 'prospects' => '2026-11-18_sales.sql', 'category_also' => '2026-11-19_category_also.sql'];
$hasCol = function (string $t, string $c) use ($pdo): bool { try { $pdo->query("SELECT `$c` FROM `$t` LIMIT 0"); return true; } catch (Throwable) { return false; } };
// AI services (decisions/0108): which are connected (the key's last 4 only), this month's spend against the cap
$aiRows = [];
try {
    require_once dirname(__DIR__, 2) . '/app/lib/AiClient.php';
    // each provider's own console: where its keys, usage, limits and bills are (AWS_CONSOLE_URL: the account's sign-in link)
    $awsReg = $env('AWS_REGION') ?: 'us-east-2'; $awsIn = $env('AWS_CONSOLE_URL') ?: 'https://console.aws.amazon.com/';
    $aiLinks = [
        'claude' => [['Console', 'https://console.anthropic.com/'], ['Usage', 'https://console.anthropic.com/usage'], ['API keys', 'https://console.anthropic.com/settings/keys'], ['Limits', 'https://console.anthropic.com/settings/limits'], ['Billing', 'https://console.anthropic.com/settings/billing']],
        'google' => [['Cloud console', 'https://console.cloud.google.com/'], ['Document AI', 'https://console.cloud.google.com/ai/document-ai'], ['Service accounts', 'https://console.cloud.google.com/iam-admin/serviceaccounts'], ['Billing', 'https://console.cloud.google.com/billing']],
        'aws' => [['Sign in', $awsIn], ['Textract', 'https://' . $awsReg . '.console.aws.amazon.com/textract/home?region=' . $awsReg], ['The site\'s user (traversence-site)', 'https://console.aws.amazon.com/iam/home#/users/details/traversence-site'], ['Budgets', 'https://console.aws.amazon.com/billing/home#/budgets']],
    ];
    foreach (AiClient::PROVIDERS as $pk => [$plabel, $pkeys]) $aiRows[] = [$plabel, AiClient::on($pk) ? 'Connected ' . AiClient::keyHint($pk) : 'Not connected', AiClient::on($pk) ? 'ok' : null, implode(', ', $pkeys) . ' in .env',
        ['claude' => 'Reads business cards now; brochures, photo → product and writing with AI Assist.', 'google' => 'Menus and price lists, with the Asset Digitizing Studio.', 'aws' => 'Tables and forms, with the Studio.'][$pk], $aiLinks[$pk]];
    // S3 storage: the same AWS key, checked for real (the bucket answers), not just "a key is set"
    require_once dirname(__DIR__, 2) . '/app/lib/Aws.php';
    require_once dirname(__DIR__, 2) . '/app/lib/S3.php';
    $s3other = trim((string) (getenv('S3_ENDPOINT') ?: '')) !== '';   // Cloudflare R2 or another S3-compatible store (decisions/0151)
    [$s3ok, $s3say] = $s3other || Aws::on() ? Aws::checkBucket() : [false, 'Not connected'];
    $s3cors = null;
    if ($s3ok) { require_once dirname(__DIR__, 2) . '/app/lib/S3.php'; $s3cors = S3::corsOk(); }
    $aiRows[] = [$s3other ? 'File storage (S3-compatible)' : 'AWS S3 (storage)', $s3say . ($s3ok ? ($s3cors === true ? ' · uploads ready' : ($s3cors === false ? ' · uploads need the CORS rule' : '')) : ''), $s3ok && $s3cors !== false ? 'ok' : (Aws::on() || $s3other ? 'red' : null), $s3other ? 'S3_ENDPOINT, S3_BUCKET, S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY in .env' : 'S3_BUCKET with the AWS keys in .env',
        'Every file the site keeps, so Bluehost holds none, each in its owner\'s folder (decisions/0123, 0124): members/ (profile and journey photos, GO Code logos, claim documents), businesses/ (photos, quote files, straight from the browser), orders/ (proofs, artwork, labels), guests/, internal/ (scanned cards); Textract\'s working files (textract/, deleted after 7 days).'
        . ($s3cors === false ? ' The bucket needs its CORS rule (Permissions → Cross-origin resource sharing; decisions/0122 has it) before uploads can go to it.' : ($s3ok && $s3cors === null ? ' Couldn\'t read the bucket\'s CORS rule (the key lacks s3:GetBucketCORS); check it\'s set as in decisions/0122.' : '')),
        // the files from before S3: moved from here, a batch at a time (no terminal on the host), decisions/0123
        '_move' => $s3ok,
        Aws::bucket() !== '' ? [['The bucket', 'https://s3.console.aws.amazon.com/s3/buckets/' . rawurlencode(Aws::bucket()) . '?region=' . $awsReg], ['Its lifecycle rules', 'https://s3.console.aws.amazon.com/s3/buckets/' . rawurlencode(Aws::bucket()) . '?region=' . $awsReg . '&tab=management']] : []];
    if (AiClient::ready($pdo)) {
        $aiUsd = AiClient::monthUsd($pdo); $aiCap = AiClient::capUsd();
        $aiRows[] = ['This month, all AI', '$' . number_format($aiUsd, $aiUsd > 0 && $aiUsd < 1 ? 3 : 2) . ' of the $' . number_format($aiCap, 2) . ' cap', $aiUsd >= $aiCap ? 'red' : ($aiUsd >= 0.8 * $aiCap ? 'red' : 'ok'), 'The Service register (it was AI_MONTHLY_CAP_USD)',
            'What the site\'s own AI requests cost this month (worked out from each answer), a safety brake: at the cap the site stops sending AI requests until the 1st, and cards can still be filled in by hand. The bill itself is in each service\'s console (Usage, Budgets), which also counts anything the site doesn\'t see.'];
        $money = fn (float $d) => '$' . number_format($d, $d > 0 && $d < 1 ? 3 : 2);   // a fraction of a cent still shows
        $words = ['card' => 'card', 'menu' => 'menu page', 'brochure' => 'brochure', 'photo_product' => 'product photo'];
        foreach (AiClient::monthBy($pdo) + array_fill_keys(array_keys(array_filter(AiClient::PROVIDERS, fn ($x, $k) => AiClient::on($k), ARRAY_FILTER_USE_BOTH)), [0.0, 0, []]) as $pk => [$usd, $n, $kinds]) {
            $what = $kinds ? implode(', ', array_map(fn ($k, $c) => $c . ' ' . ($words[$k] ?? $k) . ($c === 1 ? '' : 's') . ' read', array_keys($kinds), $kinds)) : 'nothing yet';
            $aiRows[] = [explode(' (', AiClient::PROVIDERS[$pk][0] ?? $pk)[0] . ' this month', $money($usd) . ' · ' . $what, null, '', $n ? 'About $' . number_format($usd / $n, 4) . ' each.' : ''];
        }
        $aiQ = (int) $pdo->query("SELECT COUNT(*) FROM " . Database::t('ai_jobs') . " WHERE status = 'queued' AND created_at < NOW() - INTERVAL 5 MINUTE")->fetchColumn();
        $aiRows[] = ['Worker', $aiQ ? $aiQ . ' waiting more than 5 minutes: is the cron job set?' : 'Nothing waiting', $aiQ ? 'red' : 'ok', 'cPanel cron, every minute', 'php ' . dirname(__DIR__, 2) . '/app/scripts/ai_worker.php'];
    }
} catch (Throwable) {}

// the crawler's web search (decisions/0084): this month's use, where it stops, how far the month's pace allows today
$wsRows = [];
try {
    require_once dirname(__DIR__, 2) . '/app/lib/SearchIndex.php';
    $ws = fn (string $k) => SearchIndex::ready($pdo) ? SearchIndex::state($pdo, $k) : '';
    $wsUsed = $ws('websearch_month') === date('Y-m') ? (int) $ws('websearch_used') : 0;
    $wsMonthly = (int) $ws('websearch_monthly'); $wsEngine = $ws('websearch_engine');
    require_once dirname(__DIR__, 2) . '/app/lib/Thresholds.php';   // the stop line is the service register's (Release A)
    $wsStop = (int) floor($wsMonthly * max(10, min(100, (float) Thresholds::get($pdo, 'websearch_stop_pct'))) / 100);
    $wsPace = (int) floor($wsStop * (int) date('j') / max(1, (int) date('t')));
    $wsOff = strtolower($env('WEBSEARCH')) === 'off';
    $wsRows[] = ['Search service', $wsEngine === '' ? 'None (no key on the crawler)' : ucfirst($wsEngine), $wsEngine === '' ? null : 'ok', 'TAVILY_API_KEY on Railway', 'Tavily stops at its plan\'s limit unless PAYGO or auto-upgrade is on in its dashboard: keep both off.'];
    $wsRows[] = ['This month', $wsUsed . ' of ' . ($wsMonthly ?: '?') . ' searches', $wsMonthly && $wsUsed >= $wsStop ? 'red' : ($wsMonthly && $wsUsed >= 0.8 * $wsMonthly ? 'red' : 'ok'), 'The Service register (it started from SEARCH_MONTHLY on Railway)', 'Counted by the site from the crawler\'s reports. If Tavily\'s dashboard shows more, trust Tavily\'s.'];
    $wsDay = $ws('websearch_day') === date('Y-m-d') ? (int) $ws('websearch_day_used') : 0;
    $wsRows[] = ['Stops at', $wsOff ? 'Off: no web search' : $wsStop . ' this month; up to ' . $wsPace . ' by the end of today; ' . (int) ceil($wsStop / max(1, (int) date('t'))) . ' a day at most (' . $wsDay . ' today)', $wsOff ? 'red' : null, 'WEBSEARCH in .env; the stop line in the Service register', 'The crawler asks before each run how many it may make: never past ' . ($env('WEBSEARCH_STOP_PCT') ?: '90') . '% of the allowance, spread over the month. WEBSEARCH=off stops it.'];
    // the Google check (decisions/0085): the same pace and stop, counted apart
    $plUsed = $ws('places_month') === date('Y-m') ? (int) $ws('places_used') : 0;
    $plMonthly = (int) $ws('places_monthly'); $plStop = (int) $ws('places_stop');
    $wsRows[] = ['Google check (Places)', $ws('places_seen') === '' ? 'Not running yet (GOOGLE_PLACES_KEY on Railway, and the new crawler)' : $plUsed . ' of ' . ($plMonthly ?: '?') . ' this month; stops at ' . $plStop . '; ' . (int) ceil($plStop / max(1, (int) date('t'))) . ' a day at most (' . ($ws('places_day') === date('Y-m-d') ? (int) $ws('places_day_used') : 0) . ' today)',
        $ws('places_seen') === '' ? null : ($plStop && $plUsed >= $plStop ? 'red' : 'ok'), 'GOOGLE_PLACES_KEY on Railway; the month\'s checks and the stop line in the Service register; GOOGLE_PLACES=off in .env',
        'Checks listings against Google: keeps Google\'s place ID, and puts any Google lists as permanently closed in Review. Google\'s own daily limits (200 searches) and the $10 budget alert sit above this.'];
} catch (Throwable) {}
$dbRows = [];
$hasIdent = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM user_identities LIMIT 0'); return true; } catch (Throwable) { return false; } })();
$hasClose = $hasTable('account_closures');
$hasShort = $hasTable('short_codes');
$hasQrOrders = $hasTable('qr_orders');
$hasStaff = $hasTable('staff_accounts');
$hasManifests = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM order_packs LIMIT 1'); $pdo->query('SELECT ship_mode FROM orders LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-12_shipping_manifests.sql', $hasManifests ? 'Done' : 'Run it', $hasManifests ? 'ok' : 'red', 'app/migrations/2026-12-12_shipping_manifests.sql', $hasManifests ? '' : 'Shipping as manifests: shipping mode, destinations with estimates, lots, packs and packing slips.'];
$hasWorkspaces = (function () use ($pdo): bool { try { $pdo->query('SELECT level FROM ' . Database::t('staff_accounts') . ' LIMIT 1'); $pdo->query('SELECT 1 FROM listing_memberships LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-13_workspaces_and_roles.sql', $hasWorkspaces ? 'Done' : 'Run it', $hasWorkspaces ? 'ok' : 'red', 'app/migrations/2026-12-13_workspaces_and_roles.sql', $hasWorkspaces ? '' : 'The admin workspaces: staff levels and departments, business teams and their roles, the action log.'];
$hasPulse = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('pulse_marks') . ' LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-14_pulse.sql', $hasPulse ? 'Done' : 'Run it', $hasPulse ? 'ok' : 'red', 'app/migrations/2026-12-14_pulse.sql', $hasPulse ? '' : 'Pulse: taking items (Mine) and marking them done.'];
$hasCases = (function () use ($pdo): bool { try { $pdo->query('SELECT case_no FROM ' . Database::t('pulse_marks') . ' LIMIT 1'); $pdo->query('SELECT availability FROM ' . Database::t('staff_accounts') . ' LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-15_pulse_cases.sql', $hasCases ? 'Done' : 'Run it', $hasCases ? 'ok' : 'red', 'app/migrations/2026-12-15_pulse_cases.sql', $hasCases ? '' : 'Pulse cases (numbers, escalation, comments and replies, team posts) and staff profiles.'];
$hasJobs = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM order_vendor_jobs LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-16_vendor_jobs.sql', $hasJobs ? 'Done' : 'Run it', $hasJobs ? 'ok' : 'red', 'app/migrations/2026-12-16_vendor_jobs.sql', $hasJobs ? '' : 'Printer and vendor jobs on orders (vendor, work order, expected date, cost, note).'];
$hasVO = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('vendor_jobs') . ' LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-17_vendor_orders.sql', $hasVO ? 'Done' : 'Run it', $hasVO ? 'ok' : 'red', 'app/migrations/2026-12-17_vendor_orders.sql', $hasVO ? '' : 'Vendor orders and their jobs, laid out like 4OVER (order #, projects, Job IDs, statuses, tracking, costs); margin for staff.'];
$hasTg = (function () use ($pdo): bool { try { $pdo->query('SELECT tags FROM order_lines LIMIT 0'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-18_item_panel.sql', $hasTg ? 'Done' : 'Run it', $hasTg ? 'ok' : 'red', 'app/migrations/2026-12-18_item_panel.sql', $hasTg ? '' : 'Tags on order items (Rush, Reprint, Sample) for the item panel.'];
$hasPs = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('pulse_settings') . ' LIMIT 0'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-19_pulse_settings.sql', $hasPs ? 'Done' : 'Run it', $hasPs ? 'ok' : 'red', 'app/migrations/2026-12-19_pulse_settings.sql', $hasPs ? '' : 'Stream settings: routing each kind of Pulse item to a department, and the clocks (SLA) per severity.'];
$hasCs = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('sales_cards') . ' LIMIT 0'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-20_card_scanner.sql', $hasCs ? 'Done' : 'Run it', $hasCs ? 'ok' : 'red', 'app/migrations/2026-12-20_card_scanner.sql', $hasCs ? '' : 'The business card scanner and the AI job queue (Sales → Scan cards).'];
$hasLd = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('sales_territories') . ' LIMIT 0'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-21_leads.sql', $hasLd ? 'Done' : 'Run it', $hasLd ? 'ok' : 'red', 'app/migrations/2026-12-21_leads.sql', $hasLd ? '' : 'Lead stages (met, meeting, quote, won, lost), lead scores and sales territories. Then add the hourly cron: php app/scripts/sales_tick.php'];
$hasInline = (function () use ($pdo): bool { try { $pdo->query('SELECT ship_style FROM order_lines LIMIT 1'); $pdo->query('SELECT 1 FROM order_files LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-11_inline_order.sql', $hasInline ? 'Done' : 'Run it', $hasInline ? 'ok' : 'red', 'app/migrations/2026-12-11_inline_order.sql', $hasInline ? '' : 'The order edited in place: drag to reorder, each item\'s ship icon (style, carrier, address, labels), a due date.'];
$hasItemShip = (function () use ($pdo): bool { try { $pdo->query('SELECT ship_cents FROM order_lines LIMIT 1'); $pdo->query('SELECT 1 FROM order_addresses LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-10_item_shipping.sql', $hasItemShip ? 'Done' : 'Run it', $hasItemShip ? 'ok' : 'red', 'app/migrations/2026-12-10_item_shipping.sql', $hasItemShip ? '' : 'Drop ship per item: an order\'s ship-to addresses, and each item\'s destination and shipping charge.'];
$hasItemStatus = (function () use ($pdo): bool { try { $pdo->query('SELECT item_status FROM order_lines LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-09_items_invoice.sql', $hasItemStatus ? 'Done' : 'Run it', $hasItemStatus ? 'ok' : 'red', 'app/migrations/2026-12-09_items_invoice.sql', $hasItemStatus ? '' : 'Each item\'s own status and tracking, and an order\'s P.O. number and payment terms.'];
$hasDelivery = (function () use ($pdo): bool { try { $pdo->query('SELECT delivery FROM orders LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-08_delivery_outside.sql', $hasDelivery ? 'Done' : 'Run it', $hasDelivery ? 'ok' : 'red', 'app/migrations/2026-12-08_delivery_outside.sql', $hasDelivery ? '' : 'Shipping (the ship-to address) and orders paid outside QuickBooks.'];
$hasInboxMode = (function () use ($pdo): bool { try { $pdo->query('SELECT qb_env FROM ' . Database::t('order_inbox') . ' LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-07_inbox_mode.sql', $hasInboxMode ? 'Done' : 'Run it', $hasInboxMode ? 'ok' : 'red', 'app/migrations/2026-12-07_inbox_mode.sql', $hasInboxMode ? '' : 'Keeps refunds and credit memos from the QuickBooks sandbox out of Production\'s inbox (E-Commerce → Orders). Safe to run twice.'];
$hasClientOrders = (function () use ($pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('products') . ' LIMIT 1'); $pdo->query('SELECT pay_mode FROM orders LIMIT 1'); return true; } catch (Throwable) { return false; } })();
$dbRows[] = ['2026-12-06_client_orders.sql', $hasClientOrders ? 'Done' : 'Run it', $hasClientOrders ? 'ok' : 'red', 'app/migrations/2026-12-06_client_orders.sql', $hasClientOrders ? '' : 'Needed for orders you build for a client to review, approve and pay, and for the product catalog (E-Commerce → Client orders, Products; decisions/0101). Run after 2026-12-05_staff_logins.sql. Safe to run twice.'];
$dbRows[] = ['2026-12-05_staff_logins.sql', $hasStaff ? 'Done' : 'Run it', $hasStaff ? 'ok' : 'red', 'app/migrations/2026-12-05_staff_logins.sql', $hasStaff ? '' : 'Needed for staff logins: a staff ID, password and authenticator code, separate from member accounts (decisions/0100). Then People & roles → Staff logins. Safe to run twice.'];
$hasQbCheckout = $hasTable('qb_settings');
$dbRows[] = ['2026-12-04_qb_checkout.sql', $hasQbCheckout ? 'Done' : 'Run it', $hasQbCheckout ? 'ok' : 'red', 'app/migrations/2026-12-04_qb_checkout.sql', $hasQbCheckout ? '' : 'Needed for paying by card on our own checkout page and for the Sandbox / Production switch on E-Commerce → Payments (decisions/0098). Run after 2026-12-03_qb_refunds.sql. Safe to run twice.'];
$hasQbRefunds = $hasTable('order_inbox');
$dbRows[] = ['2026-12-03_qb_refunds.sql', $hasQbRefunds ? 'Done' : 'Run it', $hasQbRefunds ? 'ok' : 'red', 'app/migrations/2026-12-03_qb_refunds.sql', $hasQbRefunds ? '' : 'Needed for refunds both ways with QuickBooks: refund the card from an order, and refunds or credit memos made in QuickBooks recorded on their order (decisions/0098). Run after 2026-12-02_orders.sql. Safe to run twice.'];
$hasOrders = false; try { $pdo->query('SELECT short_code_id FROM qr_issued LIMIT 0'); $pdo->query('SELECT 1 FROM order_ledger LIMIT 0'); $hasOrders = true; } catch (Throwable) {}
$dbRows[] = ['2026-12-02_orders.sql', $hasOrders ? 'Done' : 'Run it', $hasOrders ? 'ok' : 'red', 'app/migrations/2026-12-02_orders.sql', $hasOrders ? '' : 'Needed for E-Commerce: the orders, their money ledger and history, Fix / Credit / Refund, and GO Codes through trvgo.us (decisions/0098). Moves the GO Code orders in with the same numbers. Run after 2026-11-29_go_codes_guest.sql. Safe to run twice.'];
$hasRealmSealed = false; try { $hasRealmSealed = (int) $pdo->query("SELECT CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = " . $pdo->quote(Database::schemaOf('qb_connection')) . " AND TABLE_NAME = 'qb_connection' AND COLUMN_NAME = 'realm_id'")->fetchColumn() >= 200; } catch (Throwable) {}
$dbRows[] = ['2026-12-01_qb_realm_sealed.sql', $hasRealmSealed ? 'Done' : 'Run it', $hasRealmSealed ? 'ok' : 'red', 'app/migrations/2026-12-01_qb_realm_sealed.sql', $hasRealmSealed ? '' : 'Stores the QuickBooks company id encrypted, as Intuit requires (decisions/0096). Run after 2026-11-28_qr_orders.sql. Safe to run twice.'];
$hasTwoStep = $hasTable('two_step_devices');
$dbRows[] = ['2026-11-30_two_step.sql', $hasTwoStep ? 'Done' : 'Run it', $hasTwoStep ? 'ok' : 'red', 'app/migrations/2026-11-30_two_step.sql', $hasTwoStep ? '' : 'Needed for "Trust this browser for 30 days" on two-step sign-in for staff (decisions/0097). Without it, the code is asked at every sign-in. Safe to run twice.'];
$hasGoGuest = false; try { $pdo->query('SELECT guest_key FROM qr_issued LIMIT 1'); $hasGoGuest = true; } catch (Throwable) {}
$dbRows[] = ['2026-11-29_go_codes_guest.sql', $hasGoGuest ? 'Done' : 'Run it', $hasGoGuest ? 'ok' : 'red', 'app/migrations/2026-11-29_go_codes_guest.sql', $hasGoGuest ? '' : 'Needed for GO Codes without an account: guest carts, guest checkout and the order links (decisions/0096). Run after 2026-11-28_qr_orders.sql. Safe to run twice.'];
$dbRows[] = ['2026-11-28_qr_orders.sql', $hasQrOrders ? 'Done' : 'Run it', $hasQrOrders ? 'ok' : 'red', 'app/migrations/2026-11-28_qr_orders.sql', $hasQrOrders ? '' : 'Needed for free and paid QR codes, the cart and QuickBooks checkout (decisions/0095). In phpMyAdmin: Import this file. Safe to run twice.'];
$dbRows[] = ['2026-11-27_short_codes.sql', $hasShort ? 'Done' : 'Run it', $hasShort ? 'ok' : 'red', 'app/migrations/2026-11-27_short_codes.sql', $hasShort ? '' : 'Needed for trvgo.us short links, QR codes you can change and Save contact counts (decisions/0094). In phpMyAdmin: Import this file. Safe to run twice.'];
$dbRows[] = ['2026-11-25_account_closing.sql', $hasClose ? 'Done' : 'Run it', $hasClose ? 'ok' : 'red', 'app/migrations/2026-11-25_account_closing.sql', $hasClose ? '' : 'Needed for the 30 days to restore a deleted account (until then, Delete my account deletes straight away). In phpMyAdmin: Import this file. Run it once only.'];
$dbRows[] = ['2026-11-24_account_deletion.sql', $hasCol('users', 'deleted_at') ? 'Done' : 'Run it', $hasCol('users', 'deleted_at') ? 'ok' : 'red', 'app/migrations/2026-11-24_account_deletion.sql', $hasCol('users', 'deleted_at') ? '' : 'Needed for Delete my account. In phpMyAdmin: Import this file. Run it once only.'];
$dbRows[] = ['2026-11-23_social_sign_in.sql', $hasIdent ? 'Done' : 'Run it', $hasIdent ? 'ok' : 'red', 'app/migrations/2026-11-23_social_sign_in.sql', $hasIdent ? '' : 'Needed for Sign in with Apple, Microsoft and Facebook. In phpMyAdmin: Import this file. Run it once only.'];
$dbRows[] = ['2026-11-21_google_sign_in.sql', $hasCol('users', 'google_sub') ? 'Done' : 'Run it', $hasCol('users', 'google_sub') ? 'ok' : 'red', 'app/migrations/2026-11-21_google_sign_in.sql', $hasCol('users', 'google_sub') ? '' : 'Needed for Continue with Google. In phpMyAdmin: Import this file. Run it once only.'];
foreach ($dbFiles as $t => $f) $dbRows[] = [$f, $hasTable($t) ? 'Done' : 'Run it', $hasTable($t) ? 'ok' : 'red', 'app/migrations/' . $f, $hasTable($t) ? '' : 'In phpMyAdmin: pick the database, Import, choose this file from the delivery zip, Go. Running it twice does no harm.'];

// [group => [[label, value, pill class or null, the .env name or where it comes from, what it does]]]
$G = [
    'Publishing' => [
        ['Auto-publish', AutoImport::enabled() ? 'On' : 'Off', AutoImport::enabled() ? 'ok' : 'red', 'AUTO_IMPORT', 'Listings that pass every check publish on their own (decisions/0076). Off: everything waits in Review.'],
        ['Crawler', $on('CRAWL_QUEUE') ? 'Running' : 'Paused', $on('CRAWL_QUEUE') ? 'ok' : 'red', 'CRAWL_QUEUE', 'Off pauses every crawl job.'],
    ],
    'Privacy' => [
        ['Usage analytics', $env('ANALYTICS_SRC') !== '' ? ($env('ANALYTICS_NAME') ?: 'Set up') . ' (' . $host($env('ANALYTICS_SRC')) . ')' : 'None set up', $env('ANALYTICS_SRC') !== '' ? 'ok' : null, 'ANALYTICS_SRC, ANALYTICS_NAME', 'Loads only for people who say yes (decisions/0077). With none set up, nobody is asked.'],
        ['Videos', 'Wait for a yes', 'ok', 'built in', 'YouTube and Vimeo load only after Play, or with Videos allowed.'],
        ['Staying signed in', 'Until sign-out or the browser closes; 30 days unused', null, 'built in', 'Sessions are kept in app/storage/sessions' . (is_dir($sessDir) && is_writable($sessDir) ? '.' : ', which isn\'t writable yet: people may be signed out sooner.')],
    ],
    'Email' => [
        ['Staff mailboxes (cPanel)', $env('CPANEL_HOST') !== '' && $env('CPANEL_USER') !== '' && $env('CPANEL_TOKEN') !== '' ? 'Made from Staff logins on ' . (getenv('STAFF_EMAIL_DOMAIN') ?: 'trvgo.com') : 'Made by hand in cPanel', $env('CPANEL_TOKEN') !== '' ? 'ok' : null, 'CPANEL_HOST, CPANEL_USER, CPANEL_TOKEN, STAFF_EMAIL_DOMAIN', 'Adding someone on Staff logins makes their first.last@ mailbox; ending their access stops it signing in.'],
        ['Sending through', $env('SMTP_HOST') !== '' ? $env('SMTP_HOST') . ($env('SMTP_PORT') !== '' ? ':' . $env('SMTP_PORT') : '') : 'The server\'s own mail', $env('SMTP_HOST') !== '' ? 'ok' : null, 'SMTP_HOST, SMTP_PORT', 'Sign-up links, claim codes and notices.'],
        ['From', trim($env('SMTP_FROM_NAME') . ' ' . ($env('SMTP_FROM_EMAIL') !== '' ? '<' . $env('SMTP_FROM_EMAIL') . '>' : '')) ?: 'Not set', null, 'SMTP_FROM_NAME, SMTP_FROM_EMAIL', ''],
        ['Sign-in for sending', $set('SMTP_PASSWORD')[0], $set('SMTP_PASSWORD')[1], 'SMTP_USERNAME, SMTP_PASSWORD', 'Never shown here.'],
        ['Postal address on sales emails', $env('BUSINESS_POSTAL_ADDRESS') ?: 'Not set', $env('BUSINESS_POSTAL_ADDRESS') !== '' ? 'ok' : 'red', 'BUSINESS_POSTAL_ADDRESS', 'Every claim-invite email from Sales must carry it (decisions/0081). Until it\'s set, Sales copies the claim link instead of emailing it.'],
    ],
    'Site and services' => [
        ['Site address', $env('APP_URL') ?: 'Not set', null, 'APP_URL', 'Used in emails and shared links.'],
        ['Default place', $env('DEFAULT_GEO_HUB_SLUG') ?: 'Not set', null, 'DEFAULT_GEO_HUB_SLUG', 'Where the site opens before a visitor picks a place.'],
        ['Claims phone line', $env('CLAIM_VERIFY_NUMBER') ?: 'Not set', null, 'CLAIM_VERIFY_NUMBER', 'The number owners are told to expect a call from.'],
        ['Sign in with Apple', $env('APPLE_CLIENT_ID') !== '' ? 'On' : 'Off: not set up', $env('APPLE_CLIENT_ID') !== '' ? 'ok' : '', 'APPLE_CLIENT_ID (the Services ID)', 'Apple Developer Program ($99 a year). The Services ID lists traversence.com and the return address https://traversence.com/api/auth/apple.php (decisions/0090).'],
        ['Sign in with Microsoft', $env('MICROSOFT_CLIENT_ID') !== '' ? 'On' : 'Off: not set up', $env('MICROSOFT_CLIENT_ID') !== '' ? 'ok' : '', 'MICROSOFT_CLIENT_ID (MICROSOFT_TENANT, default common)', 'Azure portal → App registrations: personal and work accounts, Web redirect https://traversence.com/api/auth/microsoft.php, ID tokens ticked (decisions/0090).'],
        ['Sign in with Facebook', ($env('FACEBOOK_APP_ID') !== '' && $env('FACEBOOK_APP_SECRET') !== '') ? 'On' : 'Off: not set up', ($env('FACEBOOK_APP_ID') !== '' && $env('FACEBOOK_APP_SECRET') !== '') ? 'ok' : '', 'FACEBOOK_APP_ID, FACEBOOK_APP_SECRET', 'Meta app with Facebook Login: valid redirect https://traversence.com/api/auth/facebook.php, privacy policy /privacy.php, data deletion /data-deletion.php, then Live (decisions/0090).'],
        ['Captcha on sign-in', ($env('TURNSTILE_SITE_KEY') !== '' && $env('TURNSTILE_SECRET_KEY') !== '') ? 'On' : 'Off: not set up', ($env('TURNSTILE_SITE_KEY') !== '' && $env('TURNSTILE_SECRET_KEY') !== '') ? 'ok' : '', 'TURNSTILE_SITE_KEY, TURNSTILE_SECRET_KEY', 'Cloudflare Turnstile on sign-in, sign-up and forgot password (decisions/0097). Free: dash.cloudflare.com → Turnstile → Add widget, domain traversence.com, mode Managed.'],
        ['Two-step sign-in for staff', strtolower($env('TV_TWO_STEP')) === 'off' ? 'Off (TV_TWO_STEP=off)' : 'On', strtolower($env('TV_TWO_STEP')) === 'off' ? 'red' : 'ok', 'TV_TWO_STEP', 'Staff enter an emailed code before the admin side opens (decisions/0097). TV_TWO_STEP=off is only the emergency switch for when email is down.'],
        ['Sign in with Google', ($env('GOOGLE_CLIENT_ID') !== '' && $env('GOOGLE_CLIENT_SECRET') !== '') ? 'On' : 'Off: not set up', ($env('GOOGLE_CLIENT_ID') !== '' && $env('GOOGLE_CLIENT_SECRET') !== '') ? 'ok' : '', 'GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET', 'Continue with Google on sign-in and sign-up (decisions/0085). Google\'s client must list https://traversence.com/api/auth/google.php as its redirect. Run app/migrations/2026-11-21_google_sign_in.sql first.'],
        ['Census key', $set('CENSUS_API_KEY')[0], $set('CENSUS_API_KEY')[1], 'CENSUS_API_KEY', 'Populations and place profiles (Data loads).'],
        ['Crawler key', $set('CRAWLER_API_TOKEN')[0], $set('CRAWLER_API_TOKEN')[1], 'CRAWLER_API_TOKEN', 'Lets the crawler worker report in.'],
        ['Privacy keys', ($env('TAG_HASH_KEY') !== '' && $env('GUEST_HASH_KEY') !== '') ? 'Set' : 'Not all set', ($env('TAG_HASH_KEY') !== '' && $env('GUEST_HASH_KEY') !== '') ? 'ok' : 'red', 'TAG_HASH_KEY, GUEST_HASH_KEY', 'Scramble guest and tag numbers so they can\'t be traced back.'],
    ],
    'Paid services the crawler uses' => $wsRows,
    'AI services (decisions/0108)' => $aiRows,
    'Database updates' => $dbRows,
    'Server' => [
        ['PHP', PHP_VERSION, null, 'the host', ''],
        ['Database', (function () use ($pdo) { try { return 'MySQL ' . $pdo->query('SELECT VERSION()')->fetchColumn(); } catch (Throwable) { return 'Not reachable'; } })(), null, 'DB_HOST, DB_DATABASE', ''],
        ['Maintenance notice', 'Coming', null, '', 'A notice across the top of every page while work is being done.'],
    ],
];
tv_admin_start('settings', 'Settings', 'How the site is set up. To change one, edit the <code>.env</code> file in the hosting account\'s home folder (above <code>public_html</code>); changing them here is coming. Passwords and keys are never shown, only whether they\'re set.');
ob_start();
// plain settings changed here instead of in .env (decisions/0125); keys, passwords and tokens stay in .env by hand
require_once __DIR__ . '/../../app/lib/EnvSettings.php';
require_once __DIR__ . '/../../app/admin/Access.php';
[$envOk, $envWhy] = Access::can('config.env', ['min' => 'executive', 'depts' => []]);
?>
<div class="hb-card tv-bleed mt-2" id="tv-envset">
  <h2 class="hb-h" style="margin-top:0">Change here</h2>
  <p class="text-xs text-[#8A7355] mb-2">These are written into .env for you, and the file before each change is kept. Keys, passwords and tokens stay in .env, changed by hand in cPanel → File Manager.</p>
  <dl class="hb-dl">
    <?php foreach (EnvSettings::EDITABLE as $k => [$lab, $what]): $v = EnvSettings::shown($k); /* a choice's name ("Test"), not its code */ ?>
    <dt><?= tv_e($lab) ?></dt>
    <dd><b data-v class="break-all"><?= $v !== '' ? tv_e($v) : '<span class="text-[#8A7355] font-normal">Not set</span>' ?></b>
      <button type="button" class="hb-b ml-1" data-env="<?= tv_e($k) ?>" data-label="<?= tv_e($lab) ?>"<?= EnvSettings::editAttrs($k) ?><?= $envOk ? '' : ' disabled title="' . tv_e($envWhy) . '" aria-disabled="true"' ?>>Edit</button>
      <small class="block text-[#8A7355] text-xs mt-0.5"><?= tv_e($what) ?> <code><?= tv_e($k) ?></code><?= $envOk ? '' : ' · ' . tv_e($envWhy) ?></small></dd>
    <?php endforeach; ?>
  </dl>
</div>
<script src="/js/tv-env-edit.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-env-edit.js') ?>"></script>
<script>TvEnvEdit.bind('#tv-envset');   // Settings → Change here: choices for set answers, then the next step (decisions/0125)</script>
<?php
foreach ($G as $g => $rows): ?>
<div class="hb-card tv-bleed mt-2">
  <h2 class="hb-h" style="margin-top:0"><?= tv_e($g) ?></h2>
  <dl class="hb-dl">
    <?php foreach ($rows as $row): $move = !empty($row['_move']); unset($row['_move']); $row = array_values($row); [$label, $val, $cls, $from, $what] = $row; $links = $row[5] ?? []; ?>
    <dt><?= tv_e($label) ?></dt>
    <dd><?= $cls !== null ? '<span class="hb-pill ' . $cls . '" style="margin-left:0">' . tv_e($val) . '</span>' : '<b>' . tv_e($val) . '</b>' ?>
      <?php if ($what !== '' || $from !== ''): ?><small class="block text-[#8A7355] text-xs mt-0.5"><?= tv_e($what) ?><?= $from !== '' ? ' <code>' . tv_e($from) . '</code>' : '' ?></small><?php endif; ?>
      <?php if ($links): ?><small class="block text-xs mt-0.5"><?php foreach ($links as $i => [$lt, $lu]): ?><?= $i ? ' · ' : '' ?><a href="<?= tv_e($lu) ?>" target="_blank" rel="noopener" style="color:#92400E;text-decoration:underline"><?= tv_e($lt) ?> ↗</a><?php endforeach; ?></small><?php endif; ?></dd>
      <?php if ($move): ?><div class="mt-1.5" id="tv-s3move"><p class="text-xs text-[#8A7355]" data-t>Checking for files still on the server…</p><button type="button" class="hb-b go mt-1" style="display:none">Move files to S3</button></div><?php endif; ?>
    <?php endforeach; ?>
  </dl>
</div>
<?php endforeach;
?>
<script>
(function () {   // Settings → AWS S3: move the files from before S3 off the server, a batch per request (decisions/0123)
  var box = document.getElementById('tv-s3move'); if (!box) return;
  var t = box.querySelector('[data-t]'), btn = box.querySelector('button');
  function mb(b) { return b >= 1073741824 ? (b / 1073741824).toFixed(2) + ' GB' : (b / 1048576).toFixed(1) + ' MB'; }
  function left(r) { if (!r.left) { t.textContent = 'Every file is in S3: none left on the server.'; btn.style.display = "none"; return; }
    t.textContent = r.left + ' file' + (r.left === 1 ? '' : 's') + ' (' + mb(r.left_bytes) + ') from before still to move into their owners\' folders in S3. Nothing changes for visitors while they move. The scheduled task Files to S3 does this too (System Configuration → Scheduled tasks).';
    btn.textContent = 'Move ' + r.left + ' file' + (r.left === 1 ? '' : 's') + ' to S3'; btn.style.display = ""; }
  fetch('/admin/api/move-files.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (r) { if (r.ok) left(r); else t.textContent = (r.error && r.error.message) || 'Couldn\'t check.'; }).catch(function () { t.textContent = 'Couldn\'t check just now.'; });
  btn.addEventListener('click', async function () {
    if (!(await TvAsk.confirm('Move them now? Keep this page open until it says done; it goes a batch at a time.', { anchor: btn, yes: 'Move them' }))) return;
    btn.disabled = true;
    var csrf = (await (await fetch('/api/auth/session.php', { credentials: 'include' })).json()).csrf_token, total = 0, bytes = 0, r;
    try {
      do {
        r = await (await fetch('/admin/api/move-files.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: '{}' })).json();
        if (!r.ok) throw r.error || {};
        total += r.moved; bytes += r.bytes;
        t.textContent = 'Moved ' + total + ' (' + mb(bytes) + ')… ' + r.left + ' to go.';
      } while (r.moved + (r.missing || 0) > 0 && r.left > r.stuck);
      if (r.left) { left(r); TvAsk.say('Moved ' + total + '. ' + r.left + ' wouldn\'t go yet (they still work from the server); try again later.', { anchor: btn }); }
      else { t.textContent = 'Done: moved ' + total + ' file' + (total === 1 ? '' : 's') + ' (' + mb(bytes) + '). Every file is in S3.'; btn.style.display = "none"; }
    } catch (e) { t.textContent = (e && e.message) || 'The move stopped. Try again: what moved stays moved.'; }
    btn.disabled = false;
  });
})();
</script>
<?php
$html = (string) ob_get_clean();
tv_admin_hub('Settings', ['setup' => ['label' => 'How it\'s set up', 'html' => $html]]);
tv_admin_end();
