<?php
// /admin/api/env-setting.php — Settings → "Change here" (decisions/0125): one plain setting written into .env.
// POST JSON {key, value} with X-CSRF-Token -> {key, value, message, next}. next is the step that finishes the job
// (EnvSettings::next: whether what it switched on works now for whoever saved it, and a button for the rest), or null.
// {do: 'namecom_check'} runs a next step's action (EnvSettings::act) -> {message, next}. Only the settings EnvSettings lists (never a key, password or token), and
// only for whoever may "Change settings" (the Founder and Executives unless Permissions says otherwise). Logged.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/admin/Access.php';
require_once __DIR__ . '/../../../app/lib/EnvSettings.php';
require_once __DIR__ . '/../../../app/lib/Team.php';

Response::requireMethod('POST');
Response::requireCsrf();
$me = Auth::currentUser();
if (!$me || empty($me['is_admin'])) Response::error('Admins only.', 403, 'forbidden');
[$ok, $why] = Access::can('config.env', ['min' => 'executive', 'depts' => []]);
if (!$ok) Response::error($why . '.', 403, 'forbidden');
$b = Response::jsonBody();
$key = (string) ($b['key'] ?? '');
$next = function (string $k, string $v) use ($me): ?array {
    $n = EnvSettings::next(Database::connection(), (int) $me['id'], $k, $v);
    return $n ? ['text' => $n[0], 'kind' => $n[1], 'label' => $n[2], 'target' => $n[3], 'bad' => (bool) $n[4]] : null;
};
if (($b['do'] ?? '') !== '') {
    try {
        $msg = EnvSettings::act((string) $b['do']);
        Response::success(['message' => $msg, 'next' => $next('DOMAIN_SALES_MODE', EnvSettings::current('DOMAIN_SALES_MODE'))]);
    } catch (InvalidArgumentException $x) { Response::error($x->getMessage(), 422, 'validation_error'); }
    catch (Throwable $x) { Response::error('Name.com still refuses: ' . $x->getMessage(), 409, 'still_refused'); }
}
try {
    [$before, $after] = EnvSettings::set($key, (string) ($b['value'] ?? ''));
    $s = Access::staff();
    Audit::log(Database::connection(), ['user' => (int) $me['id'], 'staff' => $s ? (int) $s['id'] : null, 'route' => 'admin', 'action' => 'config.env',
        'detail' => $key . ': ' . ($before === '' ? '(empty)' : $before) . ' → ' . ($after === '' ? '(empty)' : $after)]);
    Response::success(['key' => $key, 'value' => $after, 'message' => EnvSettings::EDITABLE[$key][0] . ($after === '' ? ' cleared.' : ' saved.'), 'next' => $next($key, $after)]);
} catch (InvalidArgumentException $x) { Response::error($x->getMessage(), 422, 'validation_error'); }
catch (RuntimeException $x) { error_log('env-setting ' . $key . ': ' . $x->getMessage()); Response::error($x->getMessage(), 409, 'not_written'); }
