-- Search demand can record a search that found nothing (dest 'empty', gap review P1-3). If dest is an ENUM it becomes a
-- short text column (every value it holds stays as it is); if it's already text, nothing changes. Safe to run twice.
SET @s = (SELECT IF(COUNT(*) = 1, 'ALTER TABLE search_demand MODIFY dest VARCHAR(16) NOT NULL DEFAULT ''search''', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'search_demand' AND COLUMN_NAME = 'dest' AND DATA_TYPE = 'enum');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
