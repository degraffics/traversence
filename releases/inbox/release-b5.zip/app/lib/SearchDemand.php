<?php

declare(strict_types=1);

require_once __DIR__ . '/SearchText.php';

/**
 * Search demand (decisions/0066): what people look for, where, and where they went next, counted by day. It is the
 * crawler's target list and the out-of-region funnel: state → county → town → what. Counts only, never who.
 *
 *   fromSearch()  a search someone acted on: its place (from the words, or the place set on the site) and its anchor
 *   add()         one count: place, anchor, destination (search, listing, osm, gmaps, tool, place)
 *   funnel()      the last N days by state → county → town, with their top anchors and destinations
 */
final class SearchDemand
{
    public const DESTS = ['search', 'listing', 'osm', 'gmaps', 'tool', 'place', 'lacking', 'empty'];   // empty: a search that found nothing (gap review P1-3)   // lacking: "near me" found too little within 5 mi (2026-11-10)

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM search_demand LIMIT 1'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    /** "Seattle, WA" → [town, '', WA]; "Navajo County, AZ" → ['', Navajo, AZ]; "Arizona" → ['', '', AZ]. */
    public static function parse(string $label): ?array
    {
        $label = trim(explode('·', $label)[0]);
        if (!preg_match('/^(.{2,80}?),\s*([A-Z]{2})$/u', $label, $m)) return null;
        $name = trim($m[1]);
        if (preg_match('/^(.+?)\s+County$/iu', $name, $c)) return ['', trim($c[1]), $m[2]];
        return [$name, '', $m[2]];
    }

    public static function add(PDO $pdo, string $state, string $county, string $town, string $anchor, string $dest, ?bool $inside = null): void
    {
        if (!self::ready($pdo) || !preg_match('/^[A-Z]{2}$/', $state) || !in_array($dest, self::DESTS, true)) return;
        $town = mb_substr(trim($town), 0, 80); $county = mb_substr(trim(preg_replace('/\s+County$/i', '', $county)), 0, 80);
        $anchor = mb_substr(trim(mb_strtolower(preg_replace('/\s+/', ' ', $anchor))), 0, 60);
        if ($town !== '' && $county === '') {   // a town's county, from the ZIP list
            try { $st = $pdo->prepare('SELECT TRIM(county) FROM zip_coordinates WHERE city = ? AND state = ? AND county IS NOT NULL LIMIT 1'); $st->execute([$town, $state]); $county = (string) ($st->fetchColumn() ?: ''); } catch (Throwable) {}
            $county = preg_replace('/\s+County$/i', '', $county);
        }
        if ($inside === null) $inside = self::inside($pdo, $state, $county, $town);
        $day = date('Y-m-d');
        try {
            $up = $pdo->prepare('UPDATE search_demand SET n = n + 1 WHERE day = ? AND state = ? AND county = ? AND town = ? AND anchor = ? AND dest = ?');
            $up->execute([$day, $state, $county, $town, $anchor, $dest]);
            if ($up->rowCount() === 0) $pdo->prepare('INSERT INTO search_demand (day, state, county, town, anchor, dest, inside, n) VALUES (?, ?, ?, ?, ?, ?, ?, 1)')->execute([$day, $state, $county, $town, $anchor, $dest, $inside ? 1 : 0]);
        } catch (Throwable $e) { error_log('search demand: ' . $e->getMessage()); }
    }

    /** Whether a town (or county) is in one of our areas: its ZIPs belong to a town area (micro cluster). */
    private static function inside(PDO $pdo, string $state, string $county, string $town): bool
    {
        try {
            $st = $pdo->prepare('SELECT TRIM(zip) FROM zip_coordinates WHERE state = ?' . ($town !== '' ? ' AND city = ?' : ' AND county = ?') . ' LIMIT 10');
            $st->execute([$state, $town !== '' ? $town : $county]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $z) {
                $c = $pdo->prepare('SELECT 1 FROM micro_clusters WHERE primary_zip = ? OR associated_zips LIKE ? LIMIT 1');
                $c->execute([$z, '%"' . $z . '"%']);
                if ($c->fetchColumn()) return true;
            }
        } catch (Throwable) {}
        return false;
    }

    /** A search someone acted on (searched, or picked a prediction): its place and what it was for. */
    /** Counts a search under $dest; the place it was for (its city and state when it's a town), or null. */
    public static function fromSearch(PDO $pdo, string $q, array $ctx, string $dest = 'search'): ?array
    {
        if (!self::ready($pdo) || mb_strlen(trim($q)) < 2) return null;
        try {
            $u = UniversalSearch::understand($pdo, $q, $ctx);
            $place = null; $cat = null;
            foreach ($u['chips'] as $c) { if ($c['type'] === 'place' && !$place) $place = $c; if ($c['type'] === 'category' && !$cat) $cat = $c; }
            if (!$place) $place = UniversalSearch::scopePlace($pdo, $ctx);
            if (!$place) return null;
            $state = (string) ($place['state'] ?? ''); $town = (string) ($place['city'] ?? ''); $county = (string) ($place['county'] ?? '');
            if ($state === '' && ($p = self::parse((string) ($place['label'] ?? '')))) { [$town, $county, $state] = $p; }
            if ($state === '' && !empty($place['zips'])) {   // one of our areas: its first ZIP's town and state
                $st = $pdo->prepare('SELECT TRIM(city), TRIM(state), TRIM(county) FROM zip_coordinates WHERE zip = ? LIMIT 1'); $st->execute([(string) $place['zips'][0]]);
                if ($r = $st->fetch(PDO::FETCH_NUM)) { [$town, $state, $county] = [ucwords(mb_strtolower((string) $r[0])), (string) $r[1], (string) $r[2]]; }
            }
            if ($state === '') return null;
            $anchor = '';
            if (class_exists('Situations') || is_file(__DIR__ . '/Situations.php')) { require_once __DIR__ . '/Situations.php'; $sits = Situations::read($pdo, $q); if ($sits) $anchor = (string) $sits[0]['label']; }
            if ($anchor === '' && $cat) $anchor = (string) $cat['label'];
            if ($anchor === '') $anchor = trim((string) ($u['text'] ?? ''));
            self::add($pdo, $state, $county, $town, $anchor, in_array($dest, self::DESTS, true) ? $dest : 'search', empty($place['outside']) && !empty($place['slug']) ? true : null);
            return ['city' => $town, 'state' => $state, 'anchor' => $anchor];
        } catch (Throwable $e) { error_log('search demand: ' . $e->getMessage()); }
        return null;
    }

    /**
     * Topics searched and not found (gap review P1-3): W6's topic gaps, by how often they're asked, the last $days days.
     * [[state, town, anchor, n]]. The anchor is our own reading of the search (a situation or a category), else its text.
     */
    public static function emptyTopics(PDO $pdo, int $days = 90, int $limit = 50): array
    {
        try {
            $st = $pdo->prepare("SELECT state, town, anchor, SUM(n) AS n FROM search_demand WHERE dest = 'empty' AND anchor <> '' AND day >= ? GROUP BY state, town, anchor ORDER BY n DESC LIMIT " . max(1, min(500, $limit)));
            $st->execute([date('Y-m-d', strtotime('-' . max(1, $days) . ' days'))]);
            return $st->fetchAll(PDO::FETCH_NUM);
        } catch (Throwable $x) { return []; }
    }

    /** "near me" searches whose results were lacking, the last $days days, most first: [[state, county, town, anchor, n]]. */
    public static function lacking(PDO $pdo, int $days = 30): array
    {
        if (!self::ready($pdo)) return [];
        try {
            $st = $pdo->prepare("SELECT state, county, town, anchor, SUM(n) AS n FROM search_demand WHERE dest = 'lacking' AND day >= ? GROUP BY state, county, town, anchor ORDER BY SUM(n) DESC LIMIT 60");
            $st->execute([date('Y-m-d', time() - $days * 86400)]);
            return $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return []; }
    }

    /**
     * The funnel for the last $days days: [['state', 'searches', 'outside', 'counties' => [['county', 'searches', 'towns' =>
     * [['town', 'searches', 'inside', 'anchors' => [[anchor, n]], 'dests' => [dest => n]]]]]]], biggest first.
     */
    public static function funnel(PDO $pdo, int $days = 90, bool $outsideOnly = false): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT state, county, town, anchor, dest, inside, SUM(n) AS n FROM search_demand WHERE day >= ?' . ($outsideOnly ? ' AND inside = 0' : '') . ' GROUP BY state, county, town, anchor, dest, inside');
        $st->execute([date('Y-m-d', time() - $days * 86400)]);
        $S = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $n = (int) $r['n']; $s = $r['state']; $c = $r['county'] !== '' ? $r['county'] : '(county not known)'; $t = $r['town'] !== '' ? $r['town'] : '(the whole county)';
            $S[$s] ??= ['state' => $s, 'searches' => 0, 'outside' => 0, 'counties' => []];
            $S[$s]['counties'][$c] ??= ['county' => $c, 'searches' => 0, 'towns' => []];
            $S[$s]['counties'][$c]['towns'][$t] ??= ['town' => $t, 'searches' => 0, 'inside' => (bool) (int) $r['inside'], 'anchors' => [], 'dests' => []];
            $T = &$S[$s]['counties'][$c]['towns'][$t];
            if ($r['dest'] === 'search') { $S[$s]['searches'] += $n; $S[$s]['counties'][$c]['searches'] += $n; $T['searches'] += $n; if (!(int) $r['inside']) $S[$s]['outside'] += $n; }
            if ($r['anchor'] !== '') $T['anchors'][$r['anchor']] = ($T['anchors'][$r['anchor']] ?? 0) + $n;
            $T['dests'][$r['dest']] = ($T['dests'][$r['dest']] ?? 0) + $n;
            unset($T);
        }
        $by = fn ($a, $b) => $b['searches'] <=> $a['searches'];
        foreach ($S as &$s) {
            foreach ($s['counties'] as &$c) {
                foreach ($c['towns'] as &$t) { arsort($t['anchors']); $t['anchors'] = array_slice($t['anchors'], 0, 6, true); }
                unset($t);
                $c['towns'] = array_values($c['towns']); usort($c['towns'], $by);
            }
            unset($c);
            $s['counties'] = array_values($s['counties']); usort($s['counties'], $by);
        }
        unset($s);
        $S = array_values($S); usort($S, $by);
        return $S;
    }
}
