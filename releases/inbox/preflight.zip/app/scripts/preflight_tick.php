<?php
// app/scripts/preflight_tick.php — the pre-flight, by itself (decisions/0163 §10's note of 2026-11-16): every 15 minutes
// it looks whether .env changed (its time and size, never its contents) and whether tonight's run (2 am Arizona) is due;
// either runs every test in order (app/lib/Preflight.php), and red lines go to Pulse as one case, "Pre-flight". Read-only
// tests: it never starts, pauses or changes anything. On staging too: there its outside calls are held by the gate and
// say so. Sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Preflight.php';
$pdo = Database::connection();
try {
    require_once __DIR__ . '/../lib/Scheduler.php';
    Scheduler::run('preflight_tick');   // its runs show in System Configuration → Scheduled tasks
    $why = Preflight::tick($pdo);
    echo $why === '' ? "Pre-flight: nothing due.\n" : 'Pre-flight ran (' . $why . ").\n";
} catch (Throwable $e) {
    error_log('preflight_tick: ' . $e->getMessage());
    echo 'Pre-flight stopped: ' . $e->getMessage() . "\n";
    exit(1);
}
