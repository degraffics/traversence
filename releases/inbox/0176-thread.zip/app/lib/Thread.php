<?php
// app/lib/Thread.php — the dispatcher's one shape (decisions/0176 §1–2). One thread per thing (an incident, a photo, an
// order's file), updated in place. Its owner (the board, the service monitor, a library) supplies the facts and buttons;
// this draws them the same way on every surface, so a thread reads alike wherever it's seen:
//   1. Title: what happened, in plain words
//   2. Status: who paused it, since when, the next try
//   3. What it affects: the workflows that use it, and each one's backup, or "none"
//   4. What the system is doing
//   5. Buttons: the fix, and the thing's own actions (with "What to do" when a person has something to do)
//   6. Details ▾: the raw evidence, folded
// Per surface (0176 §2): push, the title and status; Pulse, everything but the details; the board and the card, all of
// it; the logbook, the finished story. Every part is read from the state as it is now, each time it's drawn (0176 §7).
//
// Facts: ['title', 'level' (trip|warning|notice|closed), 'pill', 'status', 'affects' => [lines], 'doing', 'todo',
//         'buttons' => [[label, act, id, confirm?]], 'details' => [[label, text]]]. Words only; nothing about a person.
declare(strict_types=1);

final class Thread
{
    public const SURFACES = ['push', 'pulse', 'board', 'card', 'logbook'];
    /** Each part's heading, as every surface names it (0176 §2). */
    public const PARTS = ['status' => 'Status', 'affects' => 'What it affects', 'doing' => 'What the system is doing', 'todo' => 'What to do', 'details' => 'Details'];

    private static function e($s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }

    /** A moment in the words is written {t:2026-11-20T09:12:00Z}: on a page it's a <time> shown in the viewer's zone,
     *  labelled (CLAUDE.md "Times where they happened", js/tv-time.js); in plain text, in UTC, labelled. */
    private const T = '/\{t:(\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d)?Z)\}/';
    public static function times(string $escaped): string
    {
        return (string) preg_replace_callback(self::T, fn ($m) => '<time datetime="' . $m[1] . '" data-tv-time data-tz="UTC">' . gmdate('M j, H:i', (int) strtotime($m[1])) . ' UTC</time>', $escaped);
    }
    public static function plain(string $s): string
    {
        return (string) preg_replace_callback(self::T, fn ($m) => gmdate('M j, H:i', (int) strtotime($m[1])) . ' UTC', $s);
    }

    /** The facts with every part present, trimmed; an owner may leave any out. */
    public static function shape(array $f): array
    {
        $t = fn ($k, int $n) => mb_substr(trim((string) ($f[$k] ?? '')), 0, $n);
        return [
            'title' => $t('title', 200), 'level' => in_array($f['level'] ?? '', ['trip', 'warning', 'notice', 'closed'], true) ? $f['level'] : 'notice',
            'pill' => $t('pill', 40), 'pill_class' => $t('pill_class', 80), 'acts_class' => $t('acts_class', 80), 'holds' => $t('holds', 200), 'status' => $t('status', 600),
            'affects' => array_values(array_filter(array_map(fn ($x) => mb_substr(trim((string) $x), 0, 300), (array) ($f['affects'] ?? [])), 'strlen')),
            'doing' => $t('doing', 600), 'todo' => $t('todo', 600),
            'buttons' => array_values(array_filter((array) ($f['buttons'] ?? []), fn ($b) => is_array($b) && trim((string) ($b[0] ?? '')) !== '')),
            'details' => array_values(array_filter((array) ($f['details'] ?? []), fn ($d) => is_array($d) && trim((string) ($d[1] ?? '')) !== '')),
        ];
    }

    /**
     * The thread drawn for one surface. $buttonsHtml, when given, stands for part 5 (the board draws its own buttons with
     * its permissions); otherwise each button posts to $endpoint in place (js/pulse-msg.js: data-msg-act). $lead, when
     * given, is drawn after the status (e.g. the board's Holds link).
     */
    public static function html(array $f, string $surface, ?string $buttonsHtml = null, string $endpoint = '', string $affectsHtml = ''): string
    {
        $f = self::shape($f); $e = [self::class, 'e'];
        $pill = $f['pill'] !== '' ? '<span class="' . ($f['pill_class'] !== '' ? $e($f['pill_class']) : 'tv-th-pill tv-th-' . $e($f['level'])) . '">' . $e($f['pill']) . '</span> ' : '';
        static $css = false; $h0 = $css ? '' : self::css(); $css = true;   // its look, once per page
        $line = fn (string $k, string $html) => '<span class="tv-th-' . $k . '"><b>' . self::PARTS[$k] . ':</b> ' . self::times($html) . '</span>';
        $h = $h0 . '<div class="tv-th" data-th-surface="' . $e($surface) . '">'
           . '<p class="tv-th-title">' . $pill . '<b>' . $e($f['title']) . '</b></p><div class="tv-th-parts">';
        if ($f['status'] !== '') $h .= $line('status', $e($f['status']));
        $aff = $f['affects'] ?: ($f['holds'] !== '' ? [$f['holds']] : []);   // nothing else affected: the part it holds
        if ($affectsHtml !== '' || $aff) $h .= $line('affects', $affectsHtml !== '' ? $affectsHtml : $e(implode('; ', $aff)));
        if ($f['doing'] !== '') $h .= $line('doing', $e($f['doing']));
        if ($f['todo'] !== '' && $f['level'] !== 'closed') $h .= $line('todo', $e($f['todo']));
        $h .= '</div>';
        $b = $buttonsHtml;
        if ($b === null) {
            $b = '';
            foreach ($f['buttons'] as $x) {
                $body = json_encode(['action' => (string) ($x[1] ?? ''), 'id' => (string) ($x[2] ?? '')], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                $b .= (string) ($x[1] ?? '') === 'href'
                    ? '<a class="tv-btn" href="' . $e($x[2] ?? '') . '" data-peek-frame>' . $e($x[0]) . '</a> '
                    : '<button type="button" class="tv-btn" data-msg-act="' . $e($endpoint) . '" data-msg-body=\'' . $e($body) . '\''
                      . (is_string($x[3] ?? null) && $x[3] !== '' ? ' data-confirm="' . $e($x[3]) . '" data-yes="' . $e($x[0]) . '"' : '') . '>' . $e($x[0]) . '</button> ';
            }
        }
        if (trim($b) !== '') $h .= '<div class="tv-th-acts ' . ($f['acts_class'] !== '' ? $e($f['acts_class']) : 'tv-msg-acts') . '">' . $b . '</div>';
        // the raw evidence, folded, only where all of it is shown (0176 §2: the board and the card)
        if ($f['details'] && in_array($surface, ['board', 'card'], true)) {
            $h .= '<details class="tv-th-details"><summary>' . self::PARTS['details'] . ' ▾</summary><dl>';
            foreach ($f['details'] as [$k, $v]) $h .= '<dt>' . $e($k) . '</dt><dd>' . self::times($e($v)) . '</dd>';
            $h .= '</dl></details>';
        }
        return $h . '</div>';
    }

    /** The push: its title and status only (0176 §2). The level decides whether it's pushed (0172's levels). */
    public static function push(array $f): array
    {
        $f = self::shape($f);
        return ['title' => $f['title'], 'body' => self::plain($f['status'])];
    }

    /** Plain words for a surface without HTML: Pulse's summary line (no details), or the logbook's finished story. */
    public static function text(array $f, string $surface = 'pulse'): string
    {
        $f = self::shape($f);
        $parts = [];
        if ($surface === 'logbook') $parts[] = $f['title'] . '.';
        if ($f['status'] !== '') $parts[] = self::PARTS['status'] . ': ' . $f['status'];
        $aff = $f['affects'] ?: ($f['holds'] !== '' ? [$f['holds']] : []);
        if ($aff) $parts[] = self::PARTS['affects'] . ': ' . implode('; ', $aff) . '.';
        if ($f['doing'] !== '' && $surface !== 'logbook') $parts[] = self::PARTS['doing'] . ': ' . $f['doing'];
        if ($f['todo'] !== '' && $f['level'] !== 'closed' && $surface !== 'logbook') $parts[] = self::PARTS['todo'] . ': ' . $f['todo'];
        return self::plain(trim(implode(' ', $parts)));
    }

    /** The thread's look, once per page: brand tokens only (brand.md §4), no literal colours; fits 390px. */
    public static function css(): string
    {
        return '<style>.tv-th{min-width:0}.tv-th-title{margin:0 0 .2rem}.tv-th-parts{display:grid;gap:.15rem;font-size:13px}.tv-th-parts>span{min-width:0;overflow-wrap:anywhere}'
             . '.tv-th-pill{display:inline-block;border-radius:999px;padding:0 .45rem;font-size:11.5px;border:1px solid var(--tv-line-strong,currentColor)}'
             . '.tv-th-trip{color:var(--tv-fail)}.tv-th-warning{color:var(--tv-hold)}.tv-th-acts{display:flex;flex-wrap:wrap;gap:.35rem;margin:.4rem 0}'
             . '.tv-th-details>summary{cursor:pointer;font-size:12.5px}.tv-th-details dl{display:grid;grid-template-columns:max-content 1fr;gap:.15rem .6rem;margin:.3rem 0;font-size:12px}'
             . '.tv-th-details dd{margin:0;min-width:0;overflow-wrap:anywhere;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}</style>';
    }
}
