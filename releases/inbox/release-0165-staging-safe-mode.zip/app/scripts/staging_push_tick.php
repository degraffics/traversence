<?php
// app/scripts/staging_push_tick.php — live's changes pushed to staging within a minute (decisions/0165 §3): live's outbox,
// each key once, for the rows staging didn't touch; a row both changed goes on the conflicts list. Every minute, on the
// live site. Does nothing (and logs nothing) until Keep staging caught up is on, nor while staging starts over.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Staging.php';
if (Staging::here()) exit;
require_once __DIR__ . '/../lib/StagingSite.php';
$pdo = Database::connection();
try { if (!StagingSite::isSetUp($pdo) || !StagingSite::mirrorOn($pdo) || StagingSite::running($pdo)) exit; } catch (Throwable $e) { exit; }
try { if ((int) $pdo->query("SELECT GET_LOCK('tv_staging_push', 0)")->fetchColumn() !== 1) exit; } catch (Throwable $e) {}
require_once __DIR__ . '/../lib/StagingSync.php';
$t0 = time(); $all = [];
do {
    $o = StagingSync::push();
    foreach ($o as $k => $n) $all[$k] = ($all[$k] ?? 0) + $n;
} while ($o && time() - $t0 < 45);
if (!$all) exit;   // nothing waited: no run logged
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('staging_push_tick');
StagingSite::putState($pdo, 'pushed', ['at' => date('c'), 'counts' => $all]);
$words = []; foreach ($all as $k => $n) $words[] = $n . ' ' . $k;
echo 'Pushed to staging: ' . implode(', ', $words) . ".\n";
