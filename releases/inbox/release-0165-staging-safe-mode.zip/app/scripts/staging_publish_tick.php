<?php
// app/scripts/staging_publish_tick.php — carries on a Publish of staging on the server (decisions/0165 §4, §5), a step
// at a time, so the page needn't stay open; an email says when it's done or where it stopped. Starts a scheduled publish
// at its time after a fresh preview, and stops (saying why) if a new conflict appears. Every minute; does nothing (and logs
// nothing) when nothing is running or due.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Staging.php';
if (Staging::here()) exit;
require_once __DIR__ . '/../lib/StagingSite.php';
$pdo = Database::connection();
try { if (!StagingSite::isSetUp($pdo)) exit; } catch (Throwable $e) { exit; }
require_once __DIR__ . '/../lib/StagingPublish.php';
$run = StagingPublish::state($pdo, 'publish');
$due = StagingPublish::state($pdo, 'scheduled');
$running = $run && in_array($run['state'] ?? '', ['running', 'undoing'], true);
if (!$running && !($due && strtotime((string) $due['at']) <= time())) exit;
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('staging_publish_tick');
if (!$running) {
    StagingSite::putState($pdo, 'scheduled', null);
    require_once __DIR__ . '/../lib/Releases.php';
    if (!Releases::inWindow($pdo)) { echo "Its time came outside the release window: not published. Schedule it again inside the window.\n"; exit; }
    $pv = StagingPublish::preview($pdo, (int) $due['by']);
    if (!empty($pv['blocking'])) { echo 'Scheduled publish stopped: ' . implode(' ', $pv['blocking']) . "\n"; exit; }
    $run = StagingPublish::start($pdo, (int) $due['by'], (string) ($due['tz'] ?? ''));
}
$run = StagingPublish::carry($pdo, 50);
echo ($run['message'] ?? ('Publish: ' . StagingPublish::stepName($run['steps'][$run['pos']] ?? 'finish') . '.')) . "\n";
