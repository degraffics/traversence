<?php
// app/scripts/staging_tick.php — the weekly refresh of the staging copy, stopped (decisions/0165 §3, 2026-11-15): staging
// catches up from live instead and keeps its own work, so nothing copies over it on a schedule. Start staging over stays,
// as a button on System Configuration → Staging (it lists what staging would lose and offers Publish first). This job does
// nothing and can be removed from Scheduled tasks; it's kept so a cron line still pointing here doesn't fail.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
echo "The weekly staging refresh is stopped (decisions/0165): staging catches up from live. Start staging over is a button on System Configuration → Staging.\n";
