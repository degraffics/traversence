<?php
// app/scripts/staging_night_tick.php — the nightly full pass (decisions/0165 §3): every kept row's fingerprint against
// staging's base (a missed push, a delete the database cascaded, a change made outside the code), the reference tables
// copied again where live's changed, the register of record numbers rebuilt, staging's code scanned for outside calls
// that skip the gate, and the live keys of held services taken out of staging's .env. Nightly, on the live site, a table at
// a time with a pause between (live and staging share the server). Does nothing until Keep staging caught up is on.
// --now runs it at once (Catch up now).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Staging.php';
if (Staging::here()) exit;
require_once __DIR__ . '/../lib/StagingSite.php';
$pdo = Database::connection();
try { if (!StagingSite::isSetUp($pdo)) exit; } catch (Throwable $e) { exit; }
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('staging_night_tick');
require_once __DIR__ . '/../lib/StagingGate.php';
$gone = StagingSite::cleanEnv($pdo);
$root = StagingSite::stagingRoot($pdo);
if ($root !== '' && is_dir($root . '/app/lib')) StagingSite::putState($pdo, 'ungated', ['at' => date('c'), 'calls' => array_slice(StagingGate::scan($root), 0, 300)]);
if (!StagingSite::mirrorOn($pdo) || StagingSite::running($pdo)) { echo 'Keep staging caught up is off' . ($gone ? '; took ' . implode(', ', $gone) . ' out of staging\'s .env' : '') . ".\n"; exit; }
if ((int) $pdo->query("SELECT GET_LOCK('tv_staging_push', 30)")->fetchColumn() !== 1) { echo "The push holds the lock: tried again tomorrow.\n"; exit; }
require_once __DIR__ . '/../lib/StagingSync.php';
$all = []; $copied = [];
foreach (array_keys(StagingSync::pairs()) as $realm) {
    foreach (StagingSync::tables($realm) as $t) {
        foreach (StagingSync::passTable($realm, $t) as $k => $n) $all[$k] = ($all[$k] ?? 0) + $n;
        usleep(200000);
    }
    $copied = array_merge($copied, StagingSync::followTables($realm));
}
[$refs, $unknown] = StagingSync::saveRefs();
StagingSite::putState($pdo, 'night', ['at' => date('c'), 'counts' => $all, 'copied' => $copied, 'refs' => $refs, 'unknown' => $unknown]);
$words = []; foreach ($all as $k => $n) if ($k !== 'same') $words[] = $n . ' ' . $k;
echo 'Night pass: ' . ($words ? implode(', ', $words) : 'staging was in step') . '; ' . count($copied) . ' reference tables copied again; ' . $refs . ' places record numbers are kept (' . $unknown . ' not known yet).' . "\n";
