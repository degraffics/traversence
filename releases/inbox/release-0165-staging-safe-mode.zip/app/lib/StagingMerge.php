<?php
// app/lib/StagingMerge.php — the three-way merge of decisions/0165 §4, as rules with no database: one row, three copies
// (the base, taken when staging and live last matched; staging's; live's), and what Publish (or catch-up) does with it.
// Used by StagingSync (catch-up: only rows staging didn't touch take live's changes) and StagingPublish (the preview and
// the publish). Kept apart so the rules can be tested on their own (tools/staging-tests/).
//
//   staging   live        result
//   changed   unchanged   staging's row
//   unchanged changed     live's row stays
//   changed   changed     each side's fields; the same field to the same value is nothing; to different values a conflict
//   added     —           added to live, with a live id
//   removed   unchanged   removed on live
//   removed   changed     a conflict          changed  removed  a conflict
//   both added rows that clash on a unique key: a conflict (StagingPublish finds those; this file can't see the keys)
declare(strict_types=1);

final class StagingMerge
{
    /** The outcome of one row. */
    public const KEEP = 'keep';          // nothing to do on live
    public const UPDATE = 'update';      // write $fields to live's row
    public const INSERT = 'insert';      // add staging's row to live (a new live id)
    public const DELETE = 'delete';      // remove live's row
    public const CONFLICT = 'conflict';  // Jason chooses

    /**
     * One row. $base: the row as it was when both sides last matched (null when the base has no such row, i.e. it was
     * added since); $stg, $live: the row now on each side (null when it isn't there). $skip: fields never carried
     * (people's stripped details, a stand-in on staging: a change staging made to one is shown as not carried).
     * Returns ['do' => KEEP|UPDATE|INSERT|DELETE|CONFLICT, 'fields' => [col => value to write], 'clash' => [col => [base,
     * staging, live]], 'why' => a line, 'left' => [cols staging changed that aren't carried]].
     */
    public static function row(?array $base, ?array $stg, ?array $live, array $skip = []): array
    {
        $out = ['do' => self::KEEP, 'fields' => [], 'clash' => [], 'why' => '', 'left' => []];
        if ($base === null) {
            if ($stg !== null && $live === null) return ['do' => self::INSERT, 'fields' => $stg, 'why' => 'Added on staging.'] + $out;
            if ($stg === null) return ['why' => $live === null ? 'Not on either side.' : 'Added on live.'] + $out;
            // both have a row by this key that the base never had: two rows that happen to share an id (staging renumbers
            // its own at a clash, so this is staging's own new row under a number live now uses): carried as a new row
            return ['do' => self::INSERT, 'fields' => $stg, 'why' => 'Added on staging (its number is taken on live: it gets a new one).'] + $out;
        }
        $sCh = $stg === null ? 'removed' : (self::same($base, $stg, $skip) ? 'same' : 'changed');
        $lCh = $live === null ? 'removed' : (self::same($base, $live, $skip) ? 'same' : 'changed');
        if ($sCh === 'same') {
            $out['left'] = $stg !== null ? self::changedCols($base, $stg, $skip, true) : [];
            return ['why' => $lCh === 'same' ? 'Unchanged.' : ($lCh === 'removed' ? 'Removed on live.' : 'Changed on live only.')] + $out;
        }
        if ($sCh === 'removed') {
            if ($lCh === 'same') return ['do' => self::DELETE, 'why' => 'Removed on staging.'] + $out;
            if ($lCh === 'removed') return ['why' => 'Removed on both.'] + $out;
            return ['do' => self::CONFLICT, 'clash' => ['*' => ['row', 'removed', 'changed']], 'why' => 'Removed on staging, changed on live.'] + $out;
        }
        // staging changed it
        if ($lCh === 'removed') return ['do' => self::CONFLICT, 'clash' => ['*' => ['row', 'changed', 'removed']], 'why' => 'Changed on staging, removed on live.'] + $out;
        $sCols = self::changedCols($base, $stg, $skip);
        $out['left'] = self::changedCols($base, $stg, $skip, true);
        $lCols = $lCh === 'same' ? [] : self::changedCols($base, $live, $skip);
        $fields = []; $clash = [];
        foreach ($sCols as $c) {
            $sv = $stg[$c] ?? null;
            if (in_array($c, $lCols, true)) {
                $lv = $live[$c] ?? null;
                if (self::eq($sv, $lv)) continue;          // the same field to the same value: nothing to do
                $clash[$c] = [$base[$c] ?? null, $sv, $lv];
                continue;
            }
            $fields[$c] = $sv;
        }
        if ($clash) return ['do' => self::CONFLICT, 'fields' => $fields, 'clash' => $clash, 'why' => 'Both sides changed ' . implode(', ', array_keys($clash)) . '.'] + $out;
        if (!$fields) return ['why' => 'Changed the same way on both.'] + $out;
        return ['do' => self::UPDATE, 'fields' => $fields, 'why' => 'Changed on staging' . ($lCols ? ' (live changed other fields: both kept)' : '') . '.'] + $out;
    }

    /** Settles a conflict by a choice: 'live' (keep live), 'staging' (use staging), or per field [col => 'live'|'staging'|['value' => v]]. */
    public static function settle(array $merge, $choice, ?array $stg, ?array $live): array
    {
        if ($merge['do'] !== self::CONFLICT) return $merge;
        $whole = isset($merge['clash']['*']);
        if ($choice === 'live') return ['do' => self::KEEP, 'fields' => [], 'why' => 'Kept live\'s.'] + $merge;
        if ($choice === 'staging') {
            if ($whole) {
                if ($stg === null) return ['do' => self::DELETE, 'fields' => [], 'why' => 'Used staging\'s: removed.'] + $merge;
                return ['do' => $live === null ? self::INSERT : self::UPDATE, 'fields' => $stg, 'why' => 'Used staging\'s.'] + $merge;
            }
            $f = $merge['fields'];
            foreach ($merge['clash'] as $c => $v) $f[$c] = $v[1];
            return ['do' => self::UPDATE, 'fields' => $f, 'why' => 'Used staging\'s.'] + $merge;
        }
        if (is_array($choice) && !$whole) {
            $f = $merge['fields'];
            foreach ($merge['clash'] as $c => $v) {
                $pick = $choice[$c] ?? null;
                if ($pick === null) throw new InvalidArgumentException('Choose live\'s, staging\'s or a value for ' . $c . '.');
                if ($pick === 'staging') $f[$c] = $v[1];
                elseif (is_array($pick) && array_key_exists('value', $pick)) $f[$c] = $pick['value'];
            }
            return ['do' => $f ? self::UPDATE : self::KEEP, 'fields' => $f, 'why' => 'Chosen field by field.'] + $merge;
        }
        throw new InvalidArgumentException('Choose Keep live, Use staging, or a choice per field.');
    }

    public static function same(array $a, array $b, array $skip = []): bool
    {
        return self::changedCols($a, $b, $skip) === [];
    }

    /** The columns whose value differs (skipped ones left out, or only those when $onlySkipped). */
    public static function changedCols(array $a, array $b, array $skip = [], bool $onlySkipped = false): array
    {
        $out = [];
        foreach (array_unique(array_merge(array_keys($a), array_keys($b))) as $c) {
            $sk = in_array($c, $skip, true);
            if ($sk !== $onlySkipped) continue;
            if (!self::eq($a[$c] ?? null, $b[$c] ?? null)) $out[] = $c;
        }
        return $out;
    }

    /** Values as the database gives them back: strings, numbers or null. 1 and '1' are the same; null and '' aren't. */
    public static function eq($a, $b): bool
    {
        if ($a === null || $b === null) return $a === $b;
        return (string) $a === (string) $b;
    }
}
