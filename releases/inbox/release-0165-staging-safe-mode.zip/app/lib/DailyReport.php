<?php
// app/lib/DailyReport.php — the daily Pulse report (Jason, 2026-11-01): one email a day, 5 am Arizona time, to the Founder
// only, with everything that needs attention and a button to the step that does it.
//
//   Needs you now   critical, an alert past its clock, or escalated to you
//   Today           alerts
//   Can wait        updates and events
//   System status   the dashboard's checks (tv_admin_status); only the parts that need a look are spelled out
//   Yesterday       cases closed, calls logged
//
// Each section is folded (<details>) in mail apps that support it; others show it open. Each case has a button straight to
// its step in Pulse (/admin/pulse/stream#case=KEY&step=N): after the usual staff sign-in, that step's own button is one
// tap. The email itself never acts: mail scanners open every link in a message, so a link that acted would fire on its own.
// No visitor's name, email or phone goes in the email: those stay behind the sign-in.
//
// An all-clear day still sends one line, so a missing email means the report stopped; and Pulse raises a case when the
// morning's report didn't go out (dailyrep:DATE), with Send it now. Runs hourly (app/scripts/daily_report.php) and sends
// once the hour arrives in Arizona, once a day. No AI, no paid service: the site's own mail.
declare(strict_types=1);

require_once __DIR__ . '/Pulse.php';
require_once __DIR__ . '/AdminTables.php';
require_once __DIR__ . '/Mailer.php';

final class DailyReport
{
    public const TZ = 'America/Phoenix';
    public const HOUR = 5;          // the default send hour, Arizona time
    private const PER_SECTION = 40; // more than this in a section: "and N more in Pulse"

    public static function ensure(PDO $pdo): void
    {
        AdminTables::make($pdo, ['daily_reports' => '(day DATE NOT NULL PRIMARY KEY, sent_at DATETIME NOT NULL /* Arizona time */, ok TINYINT(1) NOT NULL DEFAULT 0,
            to_email VARCHAR(190) NOT NULL DEFAULT \'\', subject VARCHAR(255) NOT NULL DEFAULT \'\', error VARCHAR(500) NOT NULL DEFAULT \'\')']);
    }

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM ' . Database::t('daily_reports') . ' LIMIT 0'); return true; } catch (Throwable) { return false; }
    }

    /** Now in Arizona. */
    public static function now(): DateTime { return new DateTime('now', new DateTimeZone(self::TZ)); }

    /** The hour it goes, Arizona time (Stream settings). */
    public static function hour(PDO $pdo): int
    {
        $h = Pulse::setting($pdo, 'report_hour');
        return $h !== null && preg_match('/^\d{1,2}$/', $h) && (int) $h <= 23 ? (int) $h : self::HOUR;
    }

    /**
     * Who may receive it: the Owners (site admins, super admins, Founder staff logins), [user id => [email, name]], oldest
     * account first. A staff login's own user record has a placeholder address (<id>@staff.traversence.invalid) that is
     * never mailed: the staff account's own email is used (else its linked member account's).
     */
    public static function owners(PDO $pdo): array
    {
        $q = function (string $sql) use ($pdo): array { try { return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) { return []; } };
        $sa = Database::t('staff_accounts'); $aa = Database::t('admin_access');
        $ids = [];
        foreach ($q("SELECT id FROM users WHERE is_admin = 1 AND COALESCE(is_suspended, 0) = 0") ?: $q("SELECT id FROM users WHERE is_admin = 1") as $r) $ids[(int) $r['id']] = true;
        foreach ($q("SELECT user_id FROM {$aa} WHERE tier = 'super_admin'") as $r) $ids[(int) $r['user_id']] = true;
        foreach ($q("SELECT user_id FROM {$sa} WHERE level = 'founder' AND status = 'active'") as $r) $ids[(int) $r['user_id']] = true;
        if (!$ids) return [];
        ksort($ids);
        $users = []; foreach ($q('SELECT id, email, display_name FROM users WHERE id IN (' . implode(',', array_keys($ids)) . ')') as $u) $users[(int) $u['id']] = $u;
        $staff = []; foreach ($q("SELECT s.user_id, s.name, s.email, s.status, m.email AS member_email, m.display_name AS member_name FROM {$sa} s LEFT JOIN users m ON m.id = s.member_user_id") as $r) $staff[(int) $r['user_id']] = $r;
        $out = []; $seen = [];
        foreach (array_keys($ids) as $id) {
            $u = $users[$id] ?? null; if (!$u) continue;
            $email = (string) $u['email']; $name = (string) $u['display_name'];
            if (str_ends_with(strtolower($email), '.invalid')) {
                $s = $staff[$id] ?? null;
                if (!$s || $s['status'] === 'ended') continue;
                $email = (string) ($s['email'] ?: $s['member_email']); $name = (string) ($s['name'] ?: $s['member_name']);
            }
            $email = trim($email);
            if ($email === '' || str_ends_with(strtolower($email), '.invalid') || !filter_var($email, FILTER_VALIDATE_EMAIL) || isset($seen[strtolower($email)])) continue;
            $seen[strtolower($email)] = true;
            $out[$id] = [$email, $name];
        }
        return $out;
    }

    /** The one person it goes to: [id, email, name] (Stream settings; else the first Owner, the Founder). */
    public static function recipient(PDO $pdo): ?array
    {
        $own = self::owners($pdo);
        $id = (int) (Pulse::setting($pdo, 'report_to') ?? 0);
        if (!isset($own[$id])) $id = (int) array_key_first($own);
        return $id && isset($own[$id]) ? [$id, $own[$id][0], $own[$id][1]] : null;
    }

    /** Today's report, if it went: the row. */
    public static function today(PDO $pdo): ?array
    {
        if (!self::ready($pdo)) return null;
        try { $st = $pdo->prepare('SELECT * FROM ' . Database::t('daily_reports') . ' WHERE day = ?'); $st->execute([self::now()->format('Y-m-d')]); return $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable) { return null; }
    }

    /** The scheduled run: sends once the hour has come in Arizona, once a day. Returns what it did, in words. */
    public static function tick(PDO $pdo): string
    {
        self::ensure($pdo);
        $now = self::now();
        if ((int) $now->format('G') < self::hour($pdo)) return 'Not yet: it goes at ' . self::hour($pdo) . ':00 Arizona time.';
        $t = self::today($pdo);
        if ($t && (int) $t['ok']) return 'Already sent today.';
        return self::send($pdo, true);
    }

    /** Builds and sends it. $daily: this is the day's report (recorded, so it isn't sent again); false = an extra copy now. */
    public static function send(PDO $pdo, bool $daily = false): string
    {
        $to = self::recipient($pdo);
        if (!$to) throw new RuntimeException('No Owner account with an email to send it to.');
        $r = self::build($pdo, $to[0]);
        $err = '';
        try { Mailer::send($to[1], $r['subject'], self::text($r), $to[2] !== '' ? $to[2] : null, '', self::html($r)); }
        catch (Throwable $x) { $err = mb_substr($x->getMessage(), 0, 500); }
        if ($daily) {
            self::ensure($pdo);
            $pdo->prepare('INSERT INTO ' . Database::t('daily_reports') . ' (day, sent_at, ok, to_email, subject, error) VALUES (?, ?, ?, ?, ?, ?)
                           ON DUPLICATE KEY UPDATE sent_at = VALUES(sent_at), ok = VALUES(ok), to_email = VALUES(to_email), subject = VALUES(subject), error = VALUES(error)')
                ->execute([self::now()->format('Y-m-d'), self::now()->format('Y-m-d H:i:s'), $err === '' ? 1 : 0, $to[1], mb_substr($r['subject'], 0, 255), $err]);
        }
        if ($err !== '') throw new RuntimeException('The report didn\'t send: ' . $err);
        return 'Sent to ' . $to[1] . ': ' . $r['subject'];
    }

    // ---- what's in it ------------------------------------------------------------------------------------------------

    /** The report: subject, sections [key => [title, items]], status rows, yesterday, counts. */
    public static function build(PDO $pdo, int $uid): array
    {
        $items = array_values(array_filter(Pulse::items($pdo, null, $uid), fn ($i) => $i['state'] !== 'done' && !str_starts_with($i['key'], 'dailyrep:')));
        $sec = ['now' => ['Needs you now', []], 'today' => ['Today', []], 'wait' => ['Can wait', []]];
        foreach ($items as $it) {
            // critical, an alert past its clock, or escalated to you: now. An update past its clock still waits (it says so)
            $k = $it['severity'] === 'critical' || ($it['over'] && $it['severity'] === 'alert') || $it['esc_to_me'] ? 'now' : ($it['severity'] === 'alert' ? 'today' : 'wait');
            $sec[$k][1][] = self::line($it);
        }
        // the system checks (the same ones the dashboard shows)
        $status = [];
        if (!function_exists('tv_admin_status')) { try { require_once __DIR__ . '/../ui/admin-dashboard.php'; } catch (Throwable) {} }
        if (function_exists('tv_admin_status')) { try { $status = tv_admin_status($pdo); } catch (Throwable) {} }
        $bad = array_values(array_filter($status, fn ($s) => in_array($s[0], ['warn', 'bad'], true)));
        // yesterday, in Arizona
        $y0 = (clone self::now())->modify('yesterday')->setTimezone(new DateTimeZone(date_default_timezone_get()));
        $y1 = (clone $y0)->modify('+1 day');
        $one = function (string $sql, array $a) use ($pdo): ?int { try { $st = $pdo->prepare($sql); $st->execute($a); return (int) $st->fetchColumn(); } catch (Throwable) { return null; } };
        $span = [$y0->format('Y-m-d H:i:s'), $y1->format('Y-m-d H:i:s')];
        $yday = array_filter([
            'closed' => $one('SELECT COUNT(*) FROM ' . Database::t('pulse_marks') . ' WHERE done_at >= ? AND done_at < ?', $span),
            'calls' => $one('SELECT COUNT(*) FROM ' . Database::t('prospect_log') . " WHERE kind <> 'note' AND at >= ? AND at < ?", $span),
        ], fn ($n) => $n !== null);

        $n = count($sec['now'][1]); $d = count($sec['today'][1]); $w = count($sec['wait'][1]);
        $clear = !$n && !$d && !$w && !$bad;
        $subject = 'Traversence today: ' . ($clear ? 'all clear' : implode(' · ', array_filter([
            $n ? $n . ' need' . ($n === 1 ? 's' : '') . ' you now' : '', $d ? $d . ' today' : '', $w ? $w . ' can wait' : '',
            $bad ? count($bad) . ' system check' . (count($bad) === 1 ? '' : 's') . ' to look at' : 'system OK'])));
        return ['subject' => $subject, 'date' => self::now()->format('l, F j'), 'sections' => $sec, 'status' => $status, 'bad' => $bad,
                'yesterday' => $yday, 'clear' => $clear, 'hour' => self::hour($pdo), 'base' => rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/')];
    }

    /** One case in the email: title, the case's facts, why (no one's contact details), and the buttons to its steps. */
    private static function line(array $it): array
    {
        $case = '/admin/pulse/stream#case=' . rawurlencode($it['key']);
        $btn = [];
        $play = []; try { $play = Pulse::playbook($it); } catch (Throwable) {}
        foreach ($play as $n => $st) {   // the first step that does the work in one tap (or a form), else the first tool to open
            $a = $st['act'] ?? null;
            if (!$a || !empty($st['auto'])) continue;
            if (in_array($a[0], ['do', 'form', 'stage'], true)) { $btn[] = [(string) $a[2], $case . '&step=' . $n]; break; }
        }
        if (!$btn) foreach ($play as $n => $st) {
            $a = $st['act'] ?? null;
            if ($a && empty($st['auto']) && in_array($a[0], ['tool', 'reply'], true)) { $btn[] = [(string) $st['t'], $case . '&step=' . $n]; break; }
        }
        foreach ($play as $st) if (!empty($st['ext']) && empty($st['auto'])) { $btn[] = ['Open ' . $st['ext'][0] . ' ↗', $st['ext'][1]]; break; }   // the outside service it needs
        $btn[] = ['Open the case', $case];
        $facts = [];
        if (!empty($it['case_no'])) $facts[] = 'Case #' . (int) $it['case_no'];
        if ($it['when'] !== '') {
            $age = time() - strtotime($it['when']);
            $facts[] = $age < 3600 ? 'new this hour' : ($age < 86400 ? 'open ' . (int) floor($age / 3600) . ' h' : 'open ' . (int) floor($age / 86400) . ' day' . ($age >= 172800 ? 's' : ''));
        }
        if ($it['over']) $facts[] = 'past its clock';
        if ($it['esc']) $facts[] = 'escalated to the ' . ($it['esc'] === 1 ? 'Manager' : 'Director');
        if ($it['who'] !== '') $facts[] = 'with ' . $it['who'];
        $src = Pulse::SOURCES[$it['source']][0] ?? '';
        return ['title' => (string) $it['title'], 'why' => self::scrub((string) $it['why']), 'facts' => $facts, 'src' => $src, 'buttons' => $btn, 'sev' => $it['severity']];
    }

    /** Takes email addresses and phone numbers out of a line that leaves the site. */
    public static function scrub(string $s): string
    {
        $s = (string) preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '[email]', $s);
        $s = (string) preg_replace('/(?<!\d)(\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}(?!\d)/', '[phone]', $s);
        return mb_strimwidth(trim($s), 0, 180, '…');
    }

    // ---- the email ----------------------------------------------------------------------------------------------------

    public static function html(array $r): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $u = fn (string $p) => $e(preg_match('#^https?://#', $p) ? $p : $r['base'] . $p);
        $dot = ['ok' => '#3F8A5E', 'warn' => '#C99A06', 'bad' => '#C2410C', 'off' => '#8A7355'];
        $sevc = ['critical' => '#C2410C', 'alert' => '#B45309', 'update' => '#8A7355', 'event' => '#8A7355'];
        $btn = fn (string $label, string $href, bool $main) => '<a href="' . $u($href) . '" style="display:inline-block;margin:6px 6px 0 0;padding:6px 12px;border-radius:999px;border:1px solid '
            . ($main ? '#92400E;background:#92400E;color:#FFFBF2' : '#CBB98D;background:#FFFBF2;color:#92400E') . ';font-weight:700;font-size:13px;text-decoration:none">' . $e($label) . '</a>';
        $sum = 'cursor:pointer;padding:12px 14px;font-size:16px;font-weight:700;color:#3E2B1F;list-style:none';
        $box = 'margin:0 0 10px;background:#FFFBF2;border:1px solid #E8DCC2;border-radius:10px';
        $h = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $e($r['subject']) . '</title></head>'
           . '<body style="margin:0;padding:0;background:#F6EFDF;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#3E2B1F">'
           . '<div style="max-width:640px;margin:0 auto;padding:14px 8px">'
           . '<p style="margin:0 6px 2px;font-size:13px;color:#8A7355">' . $e($r['date']) . ' · your daily report</p>'
           . '<h1 style="margin:0 6px 12px;font-size:20px;line-height:1.3;color:#3E2B1F">' . $e(preg_replace('/^Traversence today: /', '', $r['subject'])) . '</h1>';
        if ($r['clear']) {
            $h .= '<div style="' . $box . ';padding:14px"><b style="color:#3F8A5E">&#10003; All clear:</b> nothing needs you, and every system check is OK.</div>';
        }
        foreach ($r['sections'] as $k => [$title, $lines]) {
            if (!$lines) continue;
            $h .= '<details style="' . $box . '"><summary style="' . $sum . '">' . $e($title) . ' <span style="color:#8A7355;font-weight:600">(' . count($lines) . ')</span></summary><div style="padding:0 14px 8px">';
            foreach (array_slice($lines, 0, self::PER_SECTION) as $l) {
                $h .= '<div style="padding:10px 0;border-top:1px solid #EEE3CA">'
                    . '<div style="font-size:12px;color:' . ($sevc[$l['sev']] ?? '#8A7355') . ';font-weight:700;text-transform:uppercase;letter-spacing:.03em">' . $e($l['src']) . ($l['facts'] ? ' <span style="color:#8A7355;font-weight:600;text-transform:none;letter-spacing:0">· ' . $e(implode(' · ', $l['facts'])) . '</span>' : '') . '</div>'
                    . '<div style="font-size:15px;font-weight:700;margin:2px 0"><a href="' . $u(end($l['buttons'])[1]) . '" style="color:#92400E">' . $e($l['title']) . '</a></div>'
                    . ($l['why'] !== '' ? '<div style="font-size:13px;color:#5C4632">' . $e($l['why']) . '</div>' : '') . '<div>';
                foreach ($l['buttons'] as $i => [$label, $href]) $h .= $btn($label, $href, $i === 0 && count($l['buttons']) > 1);
                $h .= '</div></div>';
            }
            if (count($lines) > self::PER_SECTION) $h .= '<p style="margin:8px 0;font-size:13px"><a href="' . $u('/admin/pulse/stream') . '" style="color:#92400E">And ' . (count($lines) - self::PER_SECTION) . ' more in Pulse</a></p>';
            $h .= '</div></details>';
        }
        if ($r['status']) {
            $okNames = array_map(fn ($s) => $s[1], array_filter($r['status'], fn ($s) => $s[0] === 'ok'));
            $off = array_map(fn ($s) => $s[1], array_filter($r['status'], fn ($s) => $s[0] === 'off'));
            $h .= '<details style="' . $box . '"><summary style="' . $sum . '">System status <span style="color:' . ($r['bad'] ? '#C2410C' : '#3F8A5E') . ';font-weight:600">(' . ($r['bad'] ? count($r['bad']) . ' to look at' : 'all OK') . ')</span> <span style="float:right;color:#B45309">&#9662;</span></summary><div style="padding:0 14px 10px">';
            foreach ($r['bad'] as $row) {
                [$sx, $name, $line, $url] = $row; $svc = Pulse::SERVICES[$row[4] ?? ''] ?? null;
                $h .= '<div style="padding:8px 0;border-top:1px solid #EEE3CA;font-size:14px"><span style="display:inline-block;width:9px;height:9px;border-radius:9px;background:' . $dot[$sx] . ';margin-right:6px"></span><b>' . $e($name) . '</b>: ' . $e($line) . '<br>'
                    . ($svc ? $btn('Open ' . $svc[0] . ' ↗', $svc[1], true) : '') . $btn('Open ' . $name, (string) $url, false) . '</div>';
            }
            if ($okNames) $h .= '<div style="padding:8px 0;border-top:1px solid #EEE3CA;font-size:13px;color:#5C4632"><span style="color:#3F8A5E;font-weight:700">&#10003; OK:</span> ' . $e(implode(', ', $okNames)) . '</div>';
            if ($off) $h .= '<div style="padding:4px 0;font-size:13px;color:#8A7355">Off on purpose: ' . $e(implode(', ', $off)) . '</div>';
            $h .= '</div></details>';
        }
        if ($r['yesterday']) {
            $y = [];
            if (isset($r['yesterday']['closed'])) $y[] = $r['yesterday']['closed'] . ' case' . ($r['yesterday']['closed'] === 1 ? '' : 's') . ' closed';
            if (isset($r['yesterday']['calls'])) $y[] = $r['yesterday']['calls'] . ' call' . ($r['yesterday']['calls'] === 1 ? '' : 's') . ' logged';
            $h .= '<p style="margin:12px 6px 4px;font-size:13px;color:#5C4632"><b>Yesterday:</b> ' . $e(implode(' · ', $y)) . '.</p>';
        }
        $h .= '<p style="margin:12px 6px 0;font-size:12px;color:#8A7355">Each button opens Pulse at that step (staff sign-in as usual); the step\'s own button does the work. This email changes nothing by itself. '
            . 'Sent each day at ' . $e(self::hourLabel((int) $r['hour'])) . ' Arizona time; change it in <a href="' . $u('/admin/pulse/settings') . '" style="color:#92400E">Stream settings</a>.</p>'
            . '</div></body></html>';
        return $h;
    }

    /**
     * The daily report's look for any system email (Jason, 2026-11-15: "so all system emails look alike"): a small context
     * line, a bold headline, the body (boxes from box()), and the muted footnote. Returns the whole HTML page.
     */
    public static function frame(string $subject, string $context, string $headline, string $body, string $foot): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $e($subject) . '</title></head>'
             . '<body style="margin:0;padding:0;background:#F6EFDF;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#3E2B1F">'
             . '<div style="max-width:640px;margin:0 auto;padding:14px 8px">'
             . '<p style="margin:0 6px 2px;font-size:13px;color:#8A7355">' . $e($context) . '</p>'
             . '<h1 style="margin:0 6px 12px;font-size:20px;line-height:1.3;color:#3E2B1F">' . $e($headline) . '</h1>'
             . $body
             . '<p style="margin:12px 6px 0;font-size:12px;color:#8A7355">' . $foot . '</p></div></body></html>';
    }

    /** One rounded, folding section box ($html is its inside, already escaped). */
    public static function box(string $title, string $count, string $html, bool $open = true): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        return '<details' . ($open ? ' open' : '') . ' style="margin:0 0 10px;background:#FFFBF2;border:1px solid #E8DCC2;border-radius:10px"><summary style="cursor:pointer;padding:12px 14px;font-size:16px;font-weight:700;color:#3E2B1F;list-style:none">'
             . $e($title) . ($count !== '' ? ' <span style="color:#8A7355;font-weight:600">(' . $e($count) . ')</span>' : '') . '</summary><div style="padding:0 14px 10px">' . $html . '</div></details>';
    }

    /** The daily report's button: main (brown, filled) or plain. */
    public static function button(string $label, string $href, bool $main = true): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        return '<a href="' . $e($href) . '" style="display:inline-block;margin:6px 6px 0 0;padding:8px 16px;border-radius:999px;border:1px solid '
             . ($main ? '#92400E;background:#92400E;color:#FFFBF2' : '#CBB98D;background:#FFFBF2;color:#92400E') . ';font-weight:700;font-size:14px;text-decoration:none">' . $e($label) . '</a>';
    }

    /** 5 → "5 am". */
    public static function hourLabel(int $h): string { return $h === 0 ? 'midnight' : ($h === 12 ? 'noon' : ($h % 12) . ($h < 12 ? ' am' : ' pm')); }

    public static function text(array $r): string
    {
        $t = $r['subject'] . "\n" . $r['date'] . "\n\n";
        if ($r['clear']) $t .= "All clear: nothing needs you, and every system check is OK.\n\n";
        foreach ($r['sections'] as [$title, $lines]) {
            if (!$lines) continue;
            $t .= strtoupper($title) . ' (' . count($lines) . ")\n";
            foreach (array_slice($lines, 0, self::PER_SECTION) as $l) {
                $t .= '- ' . $l['title'] . ($l['facts'] ? ' (' . implode(', ', $l['facts']) . ')' : '') . "\n" . ($l['why'] !== '' ? '  ' . $l['why'] . "\n" : '');
                foreach ($l['buttons'] as [$label, $href]) $t .= '  ' . $label . ': ' . (preg_match('#^https?://#', $href) ? $href : $r['base'] . $href) . "\n";
            }
            if (count($lines) > self::PER_SECTION) $t .= '- and ' . (count($lines) - self::PER_SECTION) . " more in Pulse\n";
            $t .= "\n";
        }
        if ($r['status']) {
            $t .= "SYSTEM STATUS\n";
            foreach ($r['bad'] as $row) { [$sx, $name, $line, $url] = $row; $svc = Pulse::SERVICES[$row[4] ?? ''] ?? null; $t .= '- ' . $name . ': ' . $line . ' ' . $r['base'] . $url . ($svc ? "\n  Open " . $svc[0] . ': ' . $svc[1] : '') . "\n"; }
            $ok = array_map(fn ($s) => $s[1], array_filter($r['status'], fn ($s) => $s[0] === 'ok'));
            if ($ok) $t .= 'OK: ' . implode(', ', $ok) . "\n";
            $t .= "\n";
        }
        if ($r['yesterday']) $t .= 'Yesterday: ' . implode(' · ', array_filter([isset($r['yesterday']['closed']) ? $r['yesterday']['closed'] . ' cases closed' : '', isset($r['yesterday']['calls']) ? $r['yesterday']['calls'] . ' calls logged' : ''])) . "\n\n";
        return $t . "Each link opens Pulse at that step (staff sign-in as usual). This email changes nothing by itself.\n";
    }
}
