<?php
// app/lib/StagingIds.php — the register of record numbers (decisions/0165 §4, stg_id_refs): every place an id is kept, so
// that when a row made on staging takes a new number (at a clash with live's, or its live id at Publish) every reference
// to it moves with it. The places:
//   col     a column (`listing_id`, `owner_user_id`, …: StagingTables::refOf reads its name, REFS names the rest)
//   json    an id inside a JSON or settings blob, by path (StagingTables::JSON)
//   kind    a "kind:id" string (listing:123, user:45) in notes, logs, activity and Pulse keys (StagingTables::KINDS)
//   link    a link in text (/listing/view.php?id=123) in pages, descriptions and messages (StagingTables::LINKS)
//   key     a file or store key that carries an id (StagingTables::STORE_KEYS)
// Built from the live databases' columns (build()), checked before every catch-up apply and every publish (unknown()):
// a column that holds what looks like a record number but isn't known stops it, naming the table and field.
// The rewriting itself is plain text and JSON work, kept here without a database so it can be tested on its own.
declare(strict_types=1);

require_once __DIR__ . '/staging-tables.php';

final class StagingIds
{
    /**
     * The register from the databases' columns: $cols = [[realm, table, column, data type]]. Returns ['refs' => [[realm,
     * table, column, place (col|json|kind), points to, path]], 'unknown' => [[realm, table, column]]].
     */
    public static function build(array $cols): array
    {
        $refs = []; $unknown = [];
        $tables = [];
        foreach ($cols as [$realm, $t, $c, $type]) $tables[$t][$c] = $type;
        foreach ($cols as [$realm, $t, $c, $type]) {
            $to = StagingTables::refOf($t, $c, (string) $type);
            if ($to === null) { $unknown[] = [$realm, $t, $c]; continue; }
            if ($to === '?kind') {
                $kc = self::kindCol($tables[$t] ?? []);
                if ($kc === '') { $unknown[] = [$realm, $t, $c]; continue; }
                $refs[] = [$realm, $t, $c, 'col', '?' . $kc, ''];
                continue;
            }
            if ($to !== '') $refs[] = [$realm, $t, $c, 'col', $to, ''];
            if (isset(StagingTables::JSON[$t . '.' . $c])) foreach (StagingTables::JSON[$t . '.' . $c] as $path => $pt) $refs[] = [$realm, $t, $c, 'json', $pt, $path];
            if (preg_match('/text|char/i', (string) $type)) foreach (StagingTables::TEXT_COLS as $p) if (preg_match($p, strtolower($c))) { $refs[] = [$realm, $t, $c, 'kind', '*', '']; break; }
        }
        return ['refs' => $refs, 'unknown' => $unknown];
    }

    /** The column beside a ?kind reference that says which table it points to (kind, ref_kind, from_kind, …). */
    private static function kindCol(array $cols): string
    {
        foreach (['kind', 'ref_kind', 'ref_type', 'item_kind', 'target_kind', 'from_kind', 'to_kind', 'entity_type', 'type'] as $k) if (isset($cols[$k])) return $k;
        return '';
    }

    /**
     * Rewrites kind:id strings and links in text, by $map = [table => [old id => new id]]. Returns [text, how many].
     * "listing:12" becomes "listing:40"; "/listing/view.php?id=12" becomes "…id=40"; "listing:120" is left alone.
     */
    public static function text(string $s, array $map): array
    {
        if ($s === '' || !$map) return [$s, 0];
        $n = 0;
        $kinds = array_keys(array_filter(StagingTables::KINDS, fn ($t) => isset($map[$t])));
        if ($kinds) {
            $s = (string) preg_replace_callback('/(?<![A-Za-z0-9_])(' . implode('|', array_map('preg_quote', $kinds)) . '):(\d+)(?!\d)/', function ($m) use ($map, &$n) {
                $t = StagingTables::KINDS[$m[1]];
                if (!isset($map[$t][(int) $m[2]])) return $m[0];
                $n++;
                return $m[1] . ':' . $map[$t][(int) $m[2]];
            }, $s);
        }
        foreach (StagingTables::LINKS as $t => $pats) {
            if (!isset($map[$t])) continue;
            foreach ($pats as $p) $s = (string) preg_replace_callback($p, function ($m) use ($map, $t, &$n) {
                $id = (int) $m[1];
                if (!isset($map[$t][$id])) return $m[0];
                $n++;
                return str_replace($m[1], (string) $map[$t][$id], $m[0]);
            }, $s);
        }
        return [$s, $n];
    }

    /**
     * Rewrites ids in a JSON blob at the register's paths ($paths = [path => table], '?kind' paths read a "kind" beside the
     * id). Strings inside it are rewritten as text too (kind:id, links). Returns [json, how many]; text that isn't JSON is
     * rewritten as text.
     */
    public static function json(string $s, array $paths, array $map): array
    {
        $d = json_decode($s, true);
        if (!is_array($d)) return self::text($s, $map);
        $n = 0;
        foreach ($paths as $path => $t) self::walk($d, explode('.', $path), $t, $map, $n);
        array_walk_recursive($d, function (&$v) use ($map, &$n) { if (is_string($v) && $v !== '') { [$v, $k] = self::text($v, $map); $n += $k; } });
        return [$n ? (string) json_encode($d, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : $s, $n];
    }

    private static function walk(&$node, array $path, string $t, array $map, int &$n): void
    {
        if (!$path) {
            if ($t === '?kind') return;   // handled by its parent below
            if ((is_int($node) || (is_string($node) && ctype_digit($node))) && isset($map[$t][(int) $node])) { $node = is_int($node) ? (int) $map[$t][(int) $node] : (string) $map[$t][(int) $node]; $n++; }
            return;
        }
        $k = array_shift($path);
        if (!is_array($node)) return;
        if ($k === '*') { foreach ($node as &$child) self::walk($child, $path, $t, $map, $n); unset($child); return; }
        if (!array_key_exists($k, $node)) return;
        if (!$path && $t === '?kind') {   // { "kind": "listing", "id": 12 } or ids beside a kind
            $kt = StagingTables::KINDS[(string) ($node['kind'] ?? '')] ?? '';
            if ($kt !== '') self::walk($node[$k], [], $kt, $map, $n);
            return;
        }
        self::walk($node[$k], $path, $t, $map, $n);
    }

    /** A store key with a new id (entity/12/photo.jpg → entity/40/photo.jpg). Returns the key, changed or not. */
    public static function storeKey(string $key, array $map): string
    {
        foreach (StagingTables::STORE_KEYS as $p) {
            $key = (string) preg_replace_callback($p, function ($m) use ($map) {
                $t = StagingTables::KINDS[$m[1]] ?? (in_array($m[1], StagingTables::KINDS, true) ? $m[1] : '');
                return $t !== '' && isset($map[$t][(int) $m[3]]) ? $m[1] . $m[2] . '/' . $map[$t][(int) $m[3]] . '/' : $m[0];
            }, $key, 1);
        }
        return $key;
    }

    /**
     * A row's references rewritten: its columns (by the register's col refs for its table, $refs = [col => table or ?kind]),
     * JSON blobs and text. Returns [row, how many].
     */
    public static function row(array $row, array $colRefs, array $jsonRefs, array $textCols, array $map): array
    {
        $n = 0;
        foreach ($colRefs as $c => $t) {
            if (!array_key_exists($c, $row) || $row[$c] === null) continue;
            if ($t[0] === '?') $t = StagingTables::KINDS[(string) ($row[substr($t, 1)] ?? '')] ?? '';
            if ($t !== '' && isset($map[$t][(int) $row[$c]])) { $row[$c] = $map[$t][(int) $row[$c]]; $n++; }
        }
        foreach ($jsonRefs as $c => $paths) if (isset($row[$c]) && is_string($row[$c])) { [$row[$c], $k] = self::json($row[$c], $paths, $map); $n += $k; }
        foreach ($textCols as $c) if (isset($row[$c]) && is_string($row[$c]) && !isset($jsonRefs[$c])) { [$row[$c], $k] = self::text($row[$c], $map); $n += $k; }
        return [$row, $n];
    }

    /** Is this value something that looks like a record number (for the unknown-reference stop)? */
    public static function looksLikeId($v): bool
    {
        return $v !== null && $v !== '' && (is_int($v) || ctype_digit((string) $v)) && (int) $v > 0;
    }
}
