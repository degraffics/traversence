<?php
/**
 * Database.php
 *
 * Core PDO connection class for the Traversence platform.
 * Implements spec Section 12.4: PHP/PDO on BlueHost, decoupled via .env.
 *
 * No Composer dependency assumed (BlueHost shared hosting may not have
 * Composer available) — includes a minimal built-in .env loader. If the
 * project already has vlucas/phpdotenv or similar installed, the loader
 * below is a no-op for any variable that's already set.
 *
 * Usage:
 *   require_once __DIR__ . '/Database.php';
 *   $pdo = Database::connection();
 *   $stmt = $pdo->prepare('SELECT * FROM entities WHERE id = :id');
 *   $stmt->execute(['id' => $id]);
 */

final class Database
{
    private static ?PDO $instance = null;
    private static bool $envLoaded = false;

    public static function connection(): PDO
    {
        if (self::$instance === null) {
            self::loadEnv();
            self::$instance = self::adminContext() ? self::adminOnMain() : null;
            self::$instance ??= self::createConnection();
        }
        return self::$instance;
    }

    /** Which login the main connection uses: 'admin' on admin pages (decisions/0110, phase A), else 'main'. */
    private static string $as = 'main';
    public static function signedInAs(): string { self::connection(); return self::$as; }

    /** An admin page or admin endpoint (not the staff sign-in pages, which run before anyone is staff). */
    private static function adminContext(): bool
    {
        if (PHP_SAPI === 'cli') return false;
        $p = strtolower((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH));
        return (str_starts_with($p, '/admin/') || $p === '/admin' || str_starts_with($p, '/api/admin/'))
            && !in_array($p, ['/admin/login.php', '/admin/setup.php'], true);
    }

    /**
     * Admin pages work on the main database signed in as the admin login. If that login isn't set up or can't sign
     * in, they fall back to the main login (logged), so the admin never goes down over a setting.
     */
    private static function adminOnMain(): ?PDO
    {
        $user = self::env('DB_ADMIN_USERNAME');
        if (!$user || $user === self::env('DB_USERNAME')) return null;
        try { $pdo = self::createConnection(self::env('DB_DATABASE'), $user, (string) self::env('DB_ADMIN_PASSWORD')); self::$as = 'admin'; return $pdo; }
        catch (Throwable $e) { error_log('Admin login unavailable, using the main login: ' . ($e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage())); return null; }
    }

    /**
     * Minimal .env parser. Looks for a .env file at
     * /home4/degraff1/.env — four directories above this file
     * (api/ -> website/ -> traversence/ -> public_html/ -> home root),
     * outside the public_html document root by design so it's never
     * web-reachable regardless of server config.
     *
     * CONFIRMED 2026-09-16 via diag-env-check.php: the live deployment
     * path is public_html/traversence/website/api/Database.php — one
     * level deeper than an earlier fix assumed (public_html/traversence/
     * api/, no "website" segment). If this file's deployment depth ever
     * changes again, this constant must be re-verified against the
     * actual live path, not assumed — see the platform spec's standing
     * lesson on this exact failure class.
     */
    /** The .env file this site reads (for admin pages that say where a setting is looked for). */
    public static function envPath(): string
    {
        return dirname(__DIR__, 4) . '/.env';
    }

    private static function loadEnv(): void
    {
        if (self::$envLoaded) {
            return;
        }
        self::$envLoaded = true;

        $envPath = self::envPath();
        if (!is_readable($envPath)) {
            return;
        }

        $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }
            if (!str_contains($line, '=')) {
                continue;
            }
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if (strlen($value) >= 2 &&
                (($value[0] === '"' && $value[-1] === '"') ||
                 ($value[0] === "'" && $value[-1] === "'"))) {
                $value = substr($value, 1, -1);
            }
            if (getenv($key) === false) {
                putenv("{$key}={$value}");
                $_ENV[$key] = $value;
            }
        }
        // Jason's naming (DB_DATABASE-main, DB_USERNAME-admin, DB_PASSWORD-lister…) also sets the standard names, so every
        // part of the site that reads DB_PASSWORD or DB_DATABASE directly keeps working.
        foreach (self::ALIASES as $std => $alt) {
            $v = getenv($alt);
            if ($v !== false && $v !== '' && (getenv($std) === false || getenv($std) === '')) { putenv("{$std}={$v}"); $_ENV[$std] = $v; }
        }
    }

    private const ALIASES = [
        'DB_DATABASE' => 'DB_DATABASE-main', 'DB_USERNAME' => 'DB_USERNAME-main', 'DB_PASSWORD' => 'DB_PASSWORD-main',
        'DB_ADMIN_DATABASE' => 'DB_DATABASE-admin', 'DB_ADMIN_USERNAME' => 'DB_USERNAME-admin', 'DB_ADMIN_PASSWORD' => 'DB_PASSWORD-admin',
        'DB_USERS_DATABASE' => 'DB_DATABASE-user', 'DB_USERS_USERNAME' => 'DB_USERNAME-user', 'DB_USERS_PASSWORD' => 'DB_PASSWORD-user',
        'DB_LISTINGS_DATABASE' => 'DB_DATABASE-lister', 'DB_LISTINGS_USERNAME' => 'DB_USERNAME-lister', 'DB_LISTINGS_PASSWORD' => 'DB_PASSWORD-lister',
    ];

    private static function env(string $key, ?string $default = null): ?string
    {
        $value = getenv($key);
        return $value === false || $value === '' ? $default : $value;
    }

    // ---- the data realms (decisions/0110): one database and one login each ------------------------------------------
    // listings: every business's private data (login DB_LISTINGS_*); users: members' private data (DB_USERS_*); admin:
    // staff, settings, keys and our own business (DB_ADMIN_DATABASE, with the main login). Main stays DB_DATABASE.
    public const REALMS = ['admin' => 'ADMIN', 'listings' => 'LISTINGS', 'users' => 'USERS'];
    private static array $realms = [];

    /** A realm's connection (its own database, its own login). Throws if it isn't set up in .env. */
    public static function realm(string $realm): PDO
    {
        if (!isset(self::REALMS[$realm])) throw new InvalidArgumentException('Not a data realm.');
        if (!isset(self::$realms[$realm])) {
            self::loadEnv();
            [$db, $user, $pass] = self::realmConfig($realm);
            if (!$db || !$user) throw new RuntimeException('The ' . $realm . ' database isn\'t set up in .env.');
            self::$realms[$realm] = self::createConnection($db, $user, (string) $pass);
        }
        return self::$realms[$realm];
    }

    /** A connection of its own to a realm (not shared with anything else in the request): the business gateway's, so the
     *  business it's set to can't be seen or changed by other code using the realm. */
    public static function realmOwn(string $realm): PDO
    {
        if (!isset(self::REALMS[$realm])) throw new InvalidArgumentException('Not a data realm.');
        self::loadEnv();
        [$db, $user, $pass] = self::realmConfig($realm);
        if (!$db || !$user) throw new RuntimeException('The ' . $realm . ' database isn\'t set up in .env.');
        return self::createConnection($db, $user, (string) $pass);
    }

    /** [database, login, password] for a realm; the admin realm signs in with the main login. */
    public static function realmConfig(string $realm): array
    {
        self::loadEnv();
        $k = self::REALMS[$realm];
        if ($realm === 'admin') return [self::env('DB_ADMIN_DATABASE'), self::env('DB_ADMIN_USERNAME') ?: self::env('DB_USERNAME'), self::env('DB_ADMIN_PASSWORD') ?: self::env('DB_PASSWORD')];
        return [self::env("DB_{$k}_DATABASE"), self::env("DB_{$k}_USERNAME"), self::env("DB_{$k}_PASSWORD")];
    }

    // ---- where a table lives (decisions/0110 phase B) --------------------------------------------------------------
    // Tables move out of main one group at a time (System Configuration → Data separation → Move). The move tool records
    // each moved table in main's `data_moves` (table → realm), so an upload of the code can never lose track of it; code
    // names a movable table through t(), which gives its quoted name, with its database in front once it has moved.
    private static ?array $moves = null;

    /** table => realm, for the tables that have moved (read once per request, only when a movable table is used). */
    public static function moves(): array
    {
        if (self::$moves === null) {
            self::$moves = [];
            try { foreach (self::connection()->query('SELECT tbl, realm FROM data_moves') as $r) self::$moves[(string) $r['tbl']] = (string) $r['realm']; } catch (Throwable) {}
        }
        return self::$moves;
    }

    public static function forgetMoves(): void { self::$moves = null; }

    /** The database a table lives in now (for information_schema lookups). */
    public static function schemaOf(string $table): string
    {
        $r = self::moves()[$table] ?? null;
        return $r === null ? self::mainName() : (string) self::realmConfig($r)[0];
    }

    /** A table's name for SQL: `wf_items`, or `degraff1_trv_admin`.`wf_items` once it has moved. */
    public static function t(string $table): string
    {
        $r = self::moves()[$table] ?? null;
        if ($r === null) return '`' . $table . '`';
        [$db] = self::realmConfig($r);
        return '`' . str_replace('`', '', (string) $db) . '`.`' . $table . '`';
    }

    /** The main login's name. */
    /** Reads .env without connecting (pages that only need a setting, like media.php). */
    public static function readEnv(): void { self::loadEnv(); }

    public static function mainUser(): string { self::loadEnv(); return (string) self::env('DB_USERNAME'); }

    /** Can the main login (public pages, scheduled scripts) see into that database? */
    public static function mainCanSee(string $db): bool
    {
        try {
            $pdo = self::createConnection(self::env('DB_DATABASE'), self::env('DB_USERNAME'), (string) self::env('DB_PASSWORD'));
            $pdo->query('SHOW TABLES FROM `' . str_replace('`', '', $db) . '`')->fetchAll();
            return true;
        } catch (Throwable) { return false; }
    }

    /** The main database's name. */
    public static function mainName(): string { self::loadEnv(); return (string) self::env('DB_DATABASE'); }

    private static function createConnection(?string $dbname = null, ?string $user = null, ?string $pass = null): PDO
    {
        $host    = self::env('DB_HOST', 'localhost');
        $port    = self::env('DB_PORT', '3306');
        $dbname  ??= self::env('DB_DATABASE');
        $user    ??= self::env('DB_USERNAME');
        $pass    ??= self::env('DB_PASSWORD');
        $charset = self::env('DB_CHARSET', 'utf8mb4');

        if (!$dbname || !$user) {
            throw new RuntimeException(
                'Database configuration missing. Ensure DB_HOST, DB_DATABASE, ' .
                'DB_USERNAME, and DB_PASSWORD are set in .env or the server environment.'
            );
        }

        $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset={$charset}";

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_PERSISTENT         => false,
        ];

        try {
            $pdo = new PDO($dsn, $user, $pass, $options);
            if (self::env('STAGING') === '1') { require_once __DIR__ . '/Staging.php'; Staging::tag($pdo); }   // staging only: who's acting, for its change record (decisions/0165 §3)
            return $pdo;
        } catch (PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            throw new RuntimeException('Database connection failed.', 0, $e);   // the cause stays attached for the data check
        }
    }

    public static function transaction(callable $callback): mixed
    {
        $pdo = self::connection();
        $pdo->beginTransaction();
        try {
            $result = $callback($pdo);
            $pdo->commit();
            return $result;
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private function __construct() {}
    private function __clone() {}
}
