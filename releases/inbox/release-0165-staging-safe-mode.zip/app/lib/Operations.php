<?php
// app/lib/Operations.php — Operations (decisions/0163 §1–§6, §10; Release A): one view of the outside services, their
// caps and paces, what they cost against revenue and the community budget, the warnings at 50/75/95% and "returns
// empty", watching Railway's deploys and the sync, and the switch-on check. Built from what exists (OutsideServices'
// cards, ServiceHealth, Automation's switches, CrawlService's ledger, ai_jobs, email_sends, Thresholds & gates): no new
// ledger. It shows and records: it calls no outside service while watching is off (shipped off), and switches nothing on.
//
//   register($pdo)          one row per service: what uses it, where its key lives (named, never shown), its caps and
//                           paces (Thresholds: the one setting the code reads), this month's use and cost, its status
//   costs($pdo)             this month by service and by workflow, against revenue and the community budget; the AI
//                           cap's shares per workflow (WorkflowSettings: ai_share_pct)
//   warnings($pdo)          every cap or budget at 50/75/95%: one Pulse case per service (ops:cap:<service>)
//   empties($pdo)           tasks that had work and got answers but returned nothing (one Pulse case, ops:empty)
//   watch / watchTick       Railway's latest deploy and the sync's runs (ops:watch:<what>), only while switched on
//   switchOnCheck($pdo)     "Check before switching on" (§10): each line green, or what's missing with its fix
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Thresholds.php';
require_once __DIR__ . '/OutsideServices.php';
require_once __DIR__ . '/Automation.php';

final class Operations
{
    /** The register's caps and paces by service (OutsideServices::COMPANIES key => Thresholds gates). */
    public const CAPS = [
        'anthropic' => ['ai_month_usd', 'guide_ondemand_share', 'ai_free_asks', 'ai_cover'],
        'aws' => ['ses_month_usd'],
        'google' => ['places_monthly', 'places_stop_pct', 'paid_spread'],
        'tavily' => ['websearch_monthly', 'websearch_stop_pct', 'paid_spread'],
        'osm' => ['osm_daily_crawler', 'osm_daily_site', 'osm_daily_mb', 'osm_per_minute_crawler', 'osm_per_minute_site', 'osm_cache_days', 'osm_ramp_days'],
    ];

    /** The paces among the caps, in words (%s is the value): what makes a service "paced". */
    public const PACES = [
        'places_stop_pct' => 'stops at %s%% of the month\'s checks, no further into it than the month is gone', 'websearch_stop_pct' => 'stops at %s%% of the month\'s searches, no further into it than the month is gone',
        'paid_spread' => 'spread evenly through the day', 'osm_per_minute_crawler' => 'the crawler at most %s query a minute', 'osm_per_minute_site' => 'the site at most %s query a minute',
    ];

    /** Where each service's key lives, named, never shown: key => [[setting, where]]. 'Railway' ones the site can't read. */
    public const KEYS = [
        'anthropic' => [['ANTHROPIC_API_KEY', '.env']],
        'aws' => [['AWS_ACCESS_KEY_ID', '.env'], ['AWS_SECRET_ACCESS_KEY', '.env']],
        'google' => [['GOOGLE_PLACES_KEY', 'Railway']],
        'tavily' => [['TAVILY_API_KEY', 'Railway']],
        'brave' => [['BRAVE_API_KEY', 'Railway']],
        'ridb' => [['RIDB_API_KEY', 'Railway']],
        'heigit' => [['ORS_API_KEY', '.env']],
        'census' => [['CENSUS_API_KEY', '.env']],
        'cloudflare' => [['TURNSTILE_SECRET_KEY', '.env']],
        'namecom' => [['NAMECOM_TOKEN', '.env']],
        'github' => [['GITHUB_DOCS_TOKEN', '.env'], ['GITHUB_SYNC_TOKEN', '.env (watching the sync)']],
        'railway' => [['CRAWLER_API_TOKEN', '.env and Railway'], ['RAILWAY_API_TOKEN', '.env (watching deploys)']],
        'pixabay' => [['PIXABAY_KEY', '.env']],
        'az511' => [['AZ511_API_KEY', '.env']],
        'gemini' => [['GEMINI_API_KEY', '.env']],
        'supabase' => [['SUPABASE_URL', '.env'], ['SUPABASE_SERVICE_KEY', '.env']],
    ];

    /** Services added switched off (Jason, 2026-11-15): paused once, on the first look, until a person switches them on. */
    public const ADDED_OFF = ['gemini', 'supabase'];

    /** Services::all() keys onto the register's services. */
    public const USAGE_OF = ['websearch' => 'tavily', 'places' => 'google', 'claude' => 'anthropic', 'ses' => 'aws'];

    /** The warning levels (Jason, 2026-11-14), in percent, and each one's Pulse severity. */
    public const LEVELS = [95 => 'critical', 75 => 'alert', 50 => 'update'];

    /** Statuses (§1), always with the reason. */
    public const STATUSES = ['active' => 'Active', 'paced' => 'Paced', 'held' => 'Held', 'off' => 'Off', 'out' => 'Out of budget'];

    /** "Returns empty" (§4): a frequent task flagged after this many runs in 24 hours that returned nothing. */
    public const EMPTY_RUNS = 12;

    public static function can(): array
    {
        if (!class_exists('Access', false)) require_once __DIR__ . '/../admin/Access.php';
        return Access::can('config.operations', ['min' => 'executive', 'depts' => []]);
    }

    private static function env(string $k): string
    {
        $v = getenv($k);
        if (($v === false || $v === '') && isset($_ENV[$k])) $v = (string) $_ENV[$k];
        return $v === false ? '' : (string) $v;
    }

    private static function state(PDO $pdo, string $k): string
    {
        try { require_once __DIR__ . '/SearchIndex.php'; return SearchIndex::state($pdo, $k); } catch (Throwable $e) { return ''; }
    }

    private static function setState(PDO $pdo, string $k, string $v): void
    {
        require_once __DIR__ . '/SearchIndex.php';
        SearchIndex::setState($pdo, $k, $v);
    }

    // ---- the register (§1) --------------------------------------------------------------------------------------------

    /**
     * Today's values recorded once (§1: "the register starts from today's values, found automatically; nothing is
     * retyped"). Only a cap whose old place holds a value, or whose default is what the code used before, is recorded:
     * a worker's allowance it hasn't sent yet waits for its first report (api/crawl/usage.php). Returns the gates recorded.
     */
    public static function seed(PDO $pdo): array
    {
        $done = [];
        foreach (self::ADDED_OFF as $svc) {   // switched off, once (a person's later switch stands)
            if (!Automation::ready($pdo) || self::state($pdo, 'ops:added_off:' . $svc) !== '') continue;
            try { Automation::set($pdo, 'service', $svc, true, 'Added switched off (Jason, 2026-11-15): nothing calls it until Release B and a person\'s switch', 0, 'Release A'); self::setState($pdo, 'ops:added_off:' . $svc, gmdate('Y-m-d H:i')); $done[] = $svc . ' off'; } catch (Throwable $x) { error_log('ops seed ' . $svc . ': ' . $x->getMessage()); }
        }
        foreach (Thresholds::FOUND as $gate => $from) {
            if (Thresholds::stored($pdo, $gate) !== null) continue;
            $f = Thresholds::found($pdo, $gate);
            if ($f === null && $from[0][0] === 'state') continue;   // the worker's number: recorded when it reports
            if (Thresholds::recordFound($pdo, $gate)) $done[] = $gate;
        }
        return $done;
    }

    /** Which workflows and tasks use a service: [workflows[], tasks[], jobs[]]. */
    public static function users(PDO $pdo, string $svc): array
    {
        $ctl = OutsideServices::CONTROLS[$svc] ?? [];
        $tasks = (array) ($ctl['tasks'] ?? []); $jobs = (array) ($ctl['jobs'] ?? []); $wfs = [];
        $crawl = self::crawlReady($pdo) ? CrawlService::tasks($pdo) : [];
        foreach ($tasks as $t) if (isset($crawl[$t])) $wfs[(string) $crawl[$t]['wf']] = true;
        foreach ($jobs as $j) foreach (Automation::JOBS[$j] ?? [] as $w) $wfs[$w] = true;
        if ($svc === 'anthropic' && self::crawlReady($pdo)) foreach (CrawlService::FEATURE_WF as $w) $wfs[$w] = true;
        $w = array_keys($wfs);
        usort($w, fn ($a, $b) => (int) substr($a, 1) <=> (int) substr($b, 1));
        return [$w, $tasks, $jobs];
    }

    private static function crawlReady(PDO $pdo): bool
    {
        if (!class_exists('CrawlService', false)) { if (!is_file(__DIR__ . '/crawler/CrawlService.php')) return false; require_once __DIR__ . '/crawler/CrawlService.php'; }
        return CrawlService::ready($pdo);
    }

    /** Its keys: [[setting, where, present: true|false|null (can't be read from the site)]]. Never the value. */
    public static function keys(string $svc): array
    {
        $out = [];
        foreach (self::KEYS[$svc] ?? [] as [$k, $where]) $out[] = [$k, $where, str_starts_with($where, 'Railway') ? null : self::env($k) !== ''];
        return $out;
    }

    /** Its caps and paces: [[gate, label, value, unit, how it was set, set by, at]]. */
    public static function caps(PDO $pdo, string $svc): array
    {
        $out = [];
        foreach (self::CAPS[$svc] ?? [] as $g) {
            $def = Thresholds::GATES[$g] ?? null;
            if (!$def) continue;
            $st = Thresholds::stored($pdo, $g);
            $how = $st === null ? (isset(Thresholds::FOUND[$g]) && Thresholds::found($pdo, $g) !== null ? 'Not recorded yet: read from ' . Thresholds::found($pdo, $g)[1] : 'Its default')
                 : (!empty($st['found']) ? 'Found: ' . $st['found'] : (!empty($st['reset']) ? 'Reset to its default' : 'Set'));
            $out[] = ['gate' => $g, 'label' => $def[0], 'value' => Thresholds::get($pdo, $g), 'unit' => $def[6], 'how' => $how, 'by' => (int) ($st['by'] ?? 0), 'at' => (string) ($st['at'] ?? ''), 'min' => $def[3], 'max' => $def[4], 'step' => $def[5], 'where' => $def[7]];
        }
        return $out;
    }

    /** This month's use by our count: service => [used, cap, pct, cost usd, unit, money, note]. */
    public static function usage(PDO $pdo): array
    {
        $out = [];
        try {
            require_once __DIR__ . '/Services.php';
            foreach (Services::all($pdo) as $k => $s) {
                $svc = self::USAGE_OF[$k] ?? $k;
                $out[$svc][] = ['what' => $s['name'], 'used' => (float) $s['used'], 'cap' => (float) $s['cap'], 'pct' => (int) $s['pct'], 'cost' => (float) $s['cost'], 'unit' => (string) $s['unit'], 'money' => (bool) $s['money'], 'stop' => $s['stop'] ?? null];
            }
        } catch (Throwable $x) { error_log('ops usage: ' . $x->getMessage()); }
        if (class_exists('ServiceHealth', false) || is_file(__DIR__ . '/ServiceHealth.php')) {
            require_once __DIR__ . '/ServiceHealth.php';
            foreach (['crawler', 'site'] as $c) {
                try {
                    $b = ServiceHealth::osmBudget($pdo, $c);
                    $used = max(0, (int) $b['limit'] - (int) $b['queries']);
                    $out['osm'][] = ['what' => 'OpenStreetMap queries today: ' . ($c === 'site' ? 'the site' : 'the crawler'), 'used' => $used, 'cap' => (float) $b['limit'], 'pct' => $b['limit'] > 0 ? (int) floor($used / $b['limit'] * 100) : 0, 'cost' => 0.0, 'unit' => 'queries', 'money' => false, 'stop' => null, 'day' => true];
                } catch (Throwable $x) {}
            }
        }
        return $out;
    }

    /**
     * Its status, with the reason (§1): ['active'|'paced'|'held'|'off'|'out', why]. Off: switched off, or no key. Held: an
     * open issue holding it (ServiceHealth). Out of budget: a cap reached (until the 1st, or tomorrow for a daily one).
     * Paced: a pace keeps it under its cap. Silence is a status: a service nothing reports on says so.
     */
    public static function status(PDO $pdo, string $svc, ?array $use = null): array
    {
        $use = $use ?? (self::usage($pdo)[$svc] ?? []);
        if (($why = Automation::serviceOff($pdo, $svc)) !== null) return ['off', $why];
        foreach (self::keys($svc) as [$k, $where, $has]) if ($has === false && !str_contains($where, '(')) return ['off', 'No key: ' . $k . ' isn\'t in ' . $where . '.'];
        try {
            require_once __DIR__ . '/ServiceHealth.php';
            foreach (ServiceHealth::openAll($pdo) as $si) if ($si['service'] === $svc && ServiceHealth::holding($si)) { [$t] = ServiceHealth::describe($si); return ['held', 'Issue #' . (int) $si['id'] . ': ' . $t]; }
        } catch (Throwable $x) {}
        foreach ($use as $u) if ($u['cap'] > 0 && $u['pct'] >= 100) return ['out', $u['what'] . ' is at its cap: ' . (!empty($u['day']) ? 'until tomorrow (UTC).' : 'until ' . date('F j', strtotime('first day of next month')) . '.')];
        $p = [];
        foreach (self::CAPS[$svc] ?? [] as $g) {
            if (!isset(self::PACES[$g])) continue;
            $v = Thresholds::get($pdo, $g);
            if ((float) $v > 0) $p[] = sprintf(self::PACES[$g], self::num($v));
        }
        if ($p) return ['paced', ucfirst(implode('; ', array_unique($p))) . '.'];
        $master = Automation::master($pdo);
        return ['active', $master ? 'On; its automatic calls are held by the master switch (people\'s own presses still reach it).' : 'On.'];
    }

    public static function num($v): string
    {
        return is_float($v) && floor($v) !== $v ? number_format($v, 2) : number_format((float) $v);
    }

    /** One row per service (§1). */
    public static function register(PDO $pdo): array
    {
        $use = self::usage($pdo); $ledger = self::ledgerBy($pdo); $out = [];
        require_once __DIR__ . '/Services.php';
        $plan = []; foreach (Services::plans()[0] as $p) $plan[(string) $p['service']] = ($plan[(string) $p['service']] ?? 0.0) + (float) $p['usd'];   // flat monthly plans (Railway's Hobby)
        foreach (OutsideServices::COMPANIES as $k => $c) {
            [$wfs, $tasks, $jobs] = self::users($pdo, $k);
            $u = $use[$k] ?? [];
            // the ledger's cost (failed calls included) where it has one, as Costs shows; else Services' estimate
            $led = 0.0; foreach (OutsideServices::LEDGER[$k] ?? [] as $ls) $led += $ledger[$ls]['usd'] ?? 0.0;
            $cost = $led > 0 ? $led : array_sum(array_column(array_filter($u, fn ($x) => empty($x['day'])), 'cost'));
            $cost += $plan[$k] ?? 0.0;
            require_once __DIR__ . '/StagingGate.php';
            $out[$k] = ['key' => $k, 'name' => $c[0], 'what' => $c[1], 'price' => $c[2], 'workflows' => $wfs, 'tasks' => $tasks, 'jobs' => $jobs,
                        'staging' => StagingGate::answer($k), 'staging_word' => StagingGate::WORDS[StagingGate::answer($k)],   // its answer on staging (decisions/0165 §1); a service with none is held
                        'keys' => self::keys($k), 'caps' => self::caps($pdo, $k), 'use' => $u, 'cost' => $cost,
                        'provider' => 'Our count only' . ($k === 'anthropic' ? ' (no Admin API key: the Console is an individual account, decisions/0163 §7)' : ''),
                        'produced' => self::produced($pdo, $k), 'status' => self::status($pdo, $k, $u)];
        }
        return $out;
    }

    /** What a service produced this month and the cost per result, where the ledger says (§1). '' when it isn't counted. */
    private static function produced(PDO $pdo, string $svc): string
    {
        if ($svc !== 'google' && $svc !== 'tavily') return '';
        try {
            require_once __DIR__ . '/Services.php';
            $i = Services::independence($pdo);
            return $i['listings'] ? number_format($i['listings']) . ' listings from the crawler this month' . ($i['per_listing'] !== null ? ', ' . $i['per_listing'] . ' paid lookups each (Places and web search together)' : '') : 'No listings from the crawler this month';
        } catch (Throwable $x) { return ''; }
    }

    /** The crawler's ledger this month by its own service names: service => [units, usd, failed]. */
    private static function ledgerBy(PDO $pdo, ?string $month = null): array
    {
        $out = [];
        $from = ($month ?? date('Y-m')) . '-01'; $to = date('Y-m-01', strtotime($from . ' +1 month'));
        try {
            $st = $pdo->prepare('SELECT service, SUM(units) u, SUM(usd_micros) c, SUM(ok = 0) bad FROM crawl_costs WHERE at >= ? AND at < ? GROUP BY service');
            $st->execute([$from, $to]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['service']] = ['units' => (int) $r['u'], 'usd' => (int) $r['c'] / 1e6, 'failed' => (int) $r['bad']];
        } catch (Throwable $x) {}
        return $out;
    }

    // ---- costs together (§2) ------------------------------------------------------------------------------------------

    /**
     * This month's spend in one place: by service, by workflow, the plans, against revenue and the community budget.
     * ['services' => [svc => usd], 'workflows' => [wf => [svc => usd]], 'plans' => usd, 'total', 'revenue', 'community'
     * (MemberPosts::budget), 'covered' => bool, 'ai_shares' => [wf => [share_pct, cap_usd, spent, pct]]].
     */
    public static function costs(PDO $pdo): array
    {
        $svc = []; $wf = [];
        $ledgerOf = [];
        foreach (OutsideServices::LEDGER as $k => $names) foreach ($names as $n) $ledgerOf[$n] = $k;
        if (self::crawlReady($pdo)) {
            foreach (CrawlService::spend($pdo) as $w => $bySvc) foreach ($bySvc as $s => [$units, $usd]) {
                $company = $s === 'claude' ? 'anthropic' : ($ledgerOf[$s] ?? $s);
                $svc[$company] = ($svc[$company] ?? 0.0) + $usd;
                $wf[$w][$company] = ($wf[$w][$company] ?? 0.0) + $usd;
            }
        } else {
            try { require_once __DIR__ . '/AiClient.php'; $a = AiClient::monthUsd($pdo); if ($a > 0) { $svc['anthropic'] = $a; $wf['other']['anthropic'] = $a; } } catch (Throwable $x) {}
        }
        try {
            if (is_file(__DIR__ . '/SesMail.php')) { require_once __DIR__ . '/SesMail.php'; [$n, $usd] = SesMail::month($pdo); if ($usd > 0) { $svc['aws'] = ($svc['aws'] ?? 0.0) + $usd; $wf['email']['aws'] = ($wf['email']['aws'] ?? 0.0) + $usd; } }
        } catch (Throwable $x) {}
        require_once __DIR__ . '/Services.php';
        [$plans, $fixed] = Services::plans();
        foreach ($plans as $p) $svc[(string) $p['service']] = ($svc[(string) $p['service']] ?? 0.0) + (float) $p['usd'];
        $total = array_sum($svc);
        $community = ['month' => date('Y-m'), 'spent' => 0.0, 'budget' => 0.0, 'pct' => 0, 'revenue' => 0.0, 'share' => 0, 'floor' => 0];
        try { require_once __DIR__ . '/MemberPosts.php'; $community = MemberPosts::budget($pdo) + $community; } catch (Throwable $x) {}
        arsort($svc);
        return ['services' => $svc, 'workflows' => $wf, 'plans' => $fixed, 'total' => $total, 'revenue' => (float) $community['revenue'],
                'community' => $community, 'covered' => $total <= (float) $community['revenue'], 'ai_shares' => self::aiShares($pdo, $wf)];
    }

    /**
     * The AI cap's shares per workflow (§7, X4): each workflow's ai_share_pct (WorkflowSettings) of the month's cap, what
     * it spent, and its percent. A share unused at the month's end passes on to the next month's pool (recorded, not yet
     * carried: Release B). W5's half of the daily allowance (guide_ondemand_share) stays its own rule.
     */
    public static function aiShares(PDO $pdo, ?array $wf = null): array
    {
        require_once __DIR__ . '/AiClient.php';
        require_once __DIR__ . '/WorkflowSettings.php';
        $wf = $wf ?? self::costs($pdo)['workflows'];
        $cap = AiClient::capUsd(); $out = [];
        foreach (WorkflowSettings::all($pdo) as $w => $spec) {
            $pct = (int) ($spec['budgets']['ai_share_pct'] ?? 0);
            if ($pct <= 0) continue;
            $shareUsd = $cap * $pct / 100; $spent = (float) ($wf[$w]['anthropic'] ?? 0.0);
            $out[$w] = ['share_pct' => $pct, 'cap_usd' => $shareUsd, 'spent' => $spent, 'pct' => $shareUsd > 0 ? (int) floor($spent / $shareUsd * 100) : 0];
        }
        return $out;
    }

    // ---- warnings (§4) ------------------------------------------------------------------------------------------------

    /**
     * Every cap or budget at 50% or more: service => ['level', 'sev', 'lines' => [[what, used, cap, pct, money, unit]]].
     * The services' monthly caps (AI, SES, Google checks, web search), OpenStreetMap's daily budgets, the AI cap's shares
     * per workflow (under anthropic) and the community budget (under 'community').
     */
    public static function warnings(PDO $pdo): array
    {
        $by = [];
        foreach (self::usage($pdo) as $svc => $lines) foreach ($lines as $u) if ($u['cap'] > 0 && $u['pct'] >= 50) $by[$svc][] = $u;
        foreach (self::aiShares($pdo) as $w => $a) if ($a['pct'] >= 50) $by['anthropic'][] = ['what' => $w . '\'s share of the AI cap (' . $a['share_pct'] . '%)', 'used' => $a['spent'], 'cap' => $a['cap_usd'], 'pct' => $a['pct'], 'money' => true, 'unit' => 'dollars'];
        try {
            require_once __DIR__ . '/MemberPosts.php';
            $b = MemberPosts::budget($pdo);
            if ((float) $b['budget'] > 0 && (int) $b['pct'] >= 50) $by['community'][] = ['what' => 'The community budget (members\' Moments, Snaps and Keeps)', 'used' => (float) $b['spent'], 'cap' => (float) $b['budget'], 'pct' => (int) $b['pct'], 'money' => true, 'unit' => 'dollars'];
        } catch (Throwable $x) {}
        $out = [];
        foreach ($by as $svc => $lines) {
            $top = max(array_column($lines, 'pct'));
            foreach (self::LEVELS as $lvl => $sev) if ($top >= $lvl) { $out[$svc] = ['level' => $lvl, 'sev' => $sev, 'lines' => $lines]; break; }
        }
        return $out;
    }

    private static function fmtUse(array $u): string
    {
        return $u['money'] ? '$' . number_format((float) $u['used'], 2) . ' of $' . number_format((float) $u['cap'], 2) : number_format((float) $u['used']) . ' of ' . number_format((float) $u['cap']) . ' ' . $u['unit'];
    }

    // ---- "returns empty" (§4) -----------------------------------------------------------------------------------------

    /**
     * Tasks that had work and got answers, but nothing came back (not an empty queue, not held): a frequent task that
     * did its work at least EMPTY_RUNS times in 24 hours and found nothing; a bulk load on its first empty run.
     * [task => [wf, name, runs, fetches, searches, last_why, last_at, bulk]].
     */
    public static function empties(PDO $pdo): array
    {
        if (!self::crawlReady($pdo)) return [];
        $tasks = CrawlService::tasks($pdo); $out = [];
        try {
            $rows = $pdo->query("SELECT task, COUNT(*) n, SUM(fetches) f, SUM(searches) s, MAX(at) last_at,
                                        SUM(CASE WHEN counts IS NULL OR counts = '' OR counts = '[]' OR counts = '{}' THEN 0 ELSE 1 END) counted
                                   FROM crawl_run_items WHERE outcome = 'done' AND at >= NOW() - INTERVAL 24 HOUR GROUP BY task")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $x) { return []; }
        foreach ($rows as $r) {
            $t = (string) $r['task']; $info = $tasks[$t] ?? null;
            if (!$info || (int) $r['f'] + (int) $r['s'] <= 0) continue;   // asked nothing outside: not "empty", just quiet
            $bulk = ($info['mode'] ?? '') === 'bulk';
            if (!$bulk && (int) $r['n'] < self::EMPTY_RUNS) continue;
            $found = 0;
            $st = $pdo->prepare("SELECT counts FROM crawl_run_items WHERE task = ? AND outcome = 'done' AND at >= NOW() - INTERVAL 24 HOUR ORDER BY id DESC LIMIT 200"); $st->execute([$t]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $c) foreach ((array) (json_decode((string) $c, true) ?: []) as $v) if (is_numeric($v)) $found += (int) $v;
            if ($found > 0) continue;
            $out[$t] = ['wf' => (string) $info['wf'], 'name' => (string) $info['name'], 'runs' => (int) $r['n'], 'fetches' => (int) $r['f'], 'searches' => (int) $r['s'],
                        'last_why' => (string) ($info['last_why'] ?? ''), 'last_at' => (string) $r['last_at'], 'bulk' => $bulk];
        }
        return $out;
    }

    // ---- watching Railway and the sync (§5) ---------------------------------------------------------------------------

    /** What's watched: key => [name, the key it needs, where it looks]. */
    public const WATCH = [
        'railway' => ['Railway: the crawler\'s latest deploy', 'RAILWAY_API_TOKEN', 'backboard.railway.com (GraphQL), project RAILWAY_PROJECT_ID, service RAILWAY_SERVICE_ID'],
        'sync' => ['The 3-way sync\'s runs', 'GITHUB_SYNC_TOKEN', 'api.github.com: degraffics/traverse-3way-sync, sync.yml'],
    ];

    /** The watch's switch (shipped off, Release A): ['on' => bool, 'by', 'at']. */
    public static function watching(PDO $pdo): array
    {
        $j = json_decode(self::state($pdo, 'ops:watch'), true);
        return is_array($j) ? $j + ['on' => false] : ['on' => false, 'by' => 0, 'at' => ''];
    }

    public static function setWatching(PDO $pdo, bool $on, int $uid): void
    {
        if ($on) foreach (self::WATCH as [$name, $key]) if (self::env($key) === '') throw new RuntimeException($name . ' needs ' . $key . ' in .env (File Manager) first.');
        self::setState($pdo, 'ops:watch', json_encode(['on' => $on, 'by' => $uid, 'at' => gmdate('Y-m-d H:i')]));
    }

    /** The last look at each: key => ['at' (UTC), 'ok' => bool|null, 'what', 'url']. */
    public static function watched(PDO $pdo): array
    {
        $out = [];
        foreach (array_keys(self::WATCH) as $k) { $j = json_decode(self::state($pdo, 'ops:watch:' . $k), true); if (is_array($j)) $out[$k] = $j; }
        return $out;
    }

    /** The hourly look (services_tick), only while watching is on: free status reads (§6: no new spend). */
    public static function watchTick(PDO $pdo): array
    {
        if (empty(self::watching($pdo)['on'])) return [];
        $done = [];
        foreach (array_keys(self::WATCH) as $k) {
            try { $r = $k === 'railway' ? self::lookRailway() : self::lookSync(); }
            catch (Throwable $x) { $r = ['ok' => null, 'what' => 'Couldn\'t look: ' . mb_substr($x->getMessage(), 0, 200), 'url' => '']; }
            $prev = self::watched($pdo)[$k] ?? [];
            $r['since'] = ($r['ok'] ?? null) === false ? (($prev['ok'] ?? null) === false && !empty($prev['since']) ? (string) $prev['since'] : gmdate('Y-m-d H:i')) : '';   // when it started failing
            self::setState($pdo, 'ops:watch:' . $k, json_encode($r + ['at' => gmdate('Y-m-d H:i')], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            $done[] = 'watched ' . $k;
        }
        return $done;
    }

    private static function get(string $url, array $headers, ?string $post = null): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => $headers, CURLOPT_USERAGENT => 'Traversence operations watch']);
        if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
        $body = (string) curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch);
        curl_close($ch);
        if ($code < 200 || $code >= 300) throw new RuntimeException('HTTP ' . $code . ($err !== '' ? ' (' . $err . ')' : ''));
        return json_decode($body, true) ?: [];
    }

    /** Railway's latest deploy: failed or crashed is bad; building or deploying for over 30 minutes is stalled. */
    private static function lookRailway(): array
    {
        $q = 'query($p: String!, $s: String!) { deployments(first: 1, input: {projectId: $p, serviceId: $s}) { edges { node { id status createdAt } } } }';
        $j = self::get('https://backboard.railway.com/graphql/v2', ['Authorization: Bearer ' . self::env('RAILWAY_API_TOKEN'), 'Content-Type: application/json'],
            json_encode(['query' => $q, 'variables' => ['p' => self::env('RAILWAY_PROJECT_ID'), 's' => self::env('RAILWAY_SERVICE_ID')]]));
        $n = $j['data']['deployments']['edges'][0]['node'] ?? null;
        if (!$n) return ['ok' => null, 'what' => 'No deploy found (check RAILWAY_PROJECT_ID and RAILWAY_SERVICE_ID).', 'url' => 'https://railway.com/dashboard'];
        $st = strtoupper((string) $n['status']); $age = time() - strtotime((string) $n['createdAt']);
        $bad = in_array($st, ['FAILED', 'CRASHED'], true); $stalled = in_array($st, ['BUILDING', 'DEPLOYING', 'INITIALIZING', 'QUEUED'], true) && $age > 1800;
        return ['ok' => !$bad && !$stalled, 'what' => 'The latest deploy is ' . strtolower($st) . ($stalled ? ' after ' . (int) round($age / 60) . ' minutes (stalled)' : '') . ', from ' . gmdate('M j, H:i', strtotime((string) $n['createdAt'])) . ' UTC.', 'url' => 'https://railway.com/dashboard'];
    }

    /** The sync's latest run: failed is bad; running over 15 minutes is stuck (CLAUDE.md); none for 14 hours is stalled. */
    private static function lookSync(): array
    {
        $j = self::get('https://api.github.com/repos/degraffics/traverse-3way-sync/actions/workflows/sync.yml/runs?per_page=1', ['Authorization: Bearer ' . self::env('GITHUB_SYNC_TOKEN'), 'Accept: application/vnd.github+json']);
        $r = $j['workflow_runs'][0] ?? null;
        if (!$r) return ['ok' => null, 'what' => 'No runs found.', 'url' => 'https://github.com/degraffics/traverse-3way-sync/actions'];
        $age = time() - strtotime((string) $r['created_at']); $running = (string) $r['status'] !== 'completed';
        $ok = !$running ? (string) $r['conclusion'] === 'success' && $age < 14 * 3600 : $age < 900;
        $what = $running ? 'Run #' . (int) $r['run_number'] . ' is ' . str_replace('_', ' ', (string) $r['status']) . ' for ' . (int) round($age / 60) . ' minutes' . ($age >= 900 ? ' (stuck)' : '')
              : 'Run #' . (int) $r['run_number'] . ' ' . ((string) $r['conclusion'] === 'success' ? 'finished' : (string) $r['conclusion']) . ' ' . (int) round($age / 3600) . ' h ago' . ($age >= 14 * 3600 ? ' (none since: stalled)' : '');
        return ['ok' => $ok, 'what' => $what . '.', 'url' => (string) ($r['html_url'] ?? 'https://github.com/degraffics/traverse-3way-sync/actions')];
    }

    /** The hourly job's part (Services::tick): today's caps recorded once, and the watch when it's on. */
    public static function tick(PDO $pdo): array
    {
        $out = [];
        if ($s = self::seed($pdo)) $out[] = 'recorded ' . implode(', ', $s);
        return array_merge($out, self::watchTick($pdo));
    }

    // ---- Pulse ------------------------------------------------------------------------------------------------------

    /** The cases: [[key, sev, title, why, when, url]]. */
    public static function pulseItems(PDO $pdo): array
    {
        $out = [];
        foreach (self::warnings($pdo) as $svc => $w) {
            $name = $svc === 'community' ? 'The community budget' : (OutsideServices::COMPANIES[$svc][0] ?? $svc);
            $top = $w['lines'][0]; foreach ($w['lines'] as $l) if ($l['pct'] > $top['pct']) $top = $l;
            // its time: when this level was first reached this month, so a resolved case comes back only at the next level
            $lv = json_decode(self::state($pdo, 'ops:lvl:' . $svc), true);
            if (!is_array($lv) || ($lv['m'] ?? '') !== date('Y-m') || (int) ($lv['l'] ?? 0) < $w['level']) { $lv = ['m' => date('Y-m'), 'l' => $w['level'], 'at' => date('Y-m-d H:i:s')]; self::setState($pdo, 'ops:lvl:' . $svc, json_encode($lv)); }
            $out[] = ['ops:cap:' . $svc, $w['sev'], $name . ' at ' . $w['level'] . '%', $top['what'] . ': ' . self::fmtUse($top) . ' (' . $top['pct'] . '%).' . (count($w['lines']) > 1 ? ' And ' . (count($w['lines']) - 1) . ' more line(s).' : ''), (string) $lv['at'], '/admin/config/register' . ($svc !== 'community' ? '#svc-' . $svc : '')];
        }
        if ($e = self::empties($pdo)) {
            $names = array_map(fn ($t, $r) => $r['wf'] . ' ' . $r['name'], array_keys($e), $e);
            // its time: when a task last joined the list (a resolved case comes back only for a new one)
            $was = json_decode(self::state($pdo, 'ops:empty'), true); $now = array_keys($e); sort($now);
            if (!is_array($was) || array_diff($now, (array) ($was['tasks'] ?? []))) { $was = ['tasks' => $now, 'at' => date('Y-m-d H:i:s')]; self::setState($pdo, 'ops:empty', json_encode($was)); }
            $out[] = ['ops:empty', 'alert', 'Returns empty: ' . count($e) . ' task' . (count($e) === 1 ? '' : 's'), implode('; ', array_slice($names, 0, 4)) . (count($e) > 4 ? '; and more' : '') . ': each had work and got answers, but nothing came back.', (string) $was['at'], '/admin/config/board'];
        }
        $watch = self::watching($pdo);
        if (!empty($watch['on'])) foreach (self::watched($pdo) as $k => $r) {
            if (($r['ok'] ?? null) !== false) continue;
            $out[] = ['ops:watch:' . $k, 'alert', self::WATCH[$k][0] . ': needs a look', (string) $r['what'], date('Y-m-d H:i:s', strtotime((string) ($r['since'] ?? $r['at'] ?? 'now') . ' UTC')), '/admin/config/register#watch'];
        }
        return $out;
    }

    /** A case's steps (Pulse::playbook). $s is Pulse's step factory. */
    public static function pulseSteps(PDO $pdo, string $key, callable $s): array
    {
        if (str_starts_with($key, 'ops:cap:')) {
            $svc = substr($key, 8); $w = self::warnings($pdo)[$svc] ?? null; $st = [];
            foreach ($w['lines'] ?? [] as $l) $st[] = $s($l['what'] . ': ' . $l['pct'] . '%', self::fmtUse($l) . '.', null);
            $caps = self::CAPS[$svc] ?? [];
            if ($caps) {
                $g = $caps[0]; $def = Thresholds::GATES[$g];
                $st[] = $s('Raise the cap', $def[0] . ', now ' . self::num(Thresholds::get($pdo, $g)) . ' ' . $def[6] . '. Kept with who and when, with a Reset.', ['form', 'ops_cap:' . $g, 'Set it', [['value', $def[0] . ' (' . $def[6] . ')', 'text', (string) Thresholds::get($pdo, $g)]]]);
            }
            $ext = ['anthropic' => 'anthropic', 'aws' => 'ses', 'google' => 'google', 'tavily' => 'tavily'][$svc] ?? '';
            if ($ext !== '') $st[] = $s('Top up, or check the bill', 'With the provider: its balance and limits.', null, false, $ext);
            if (isset(OutsideServices::COMPANIES[$svc]) && !isset(Automation::NOT_PAUSABLE[$svc])) $st[] = $s('Pause the work', 'Pauses ' . OutsideServices::COMPANIES[$svc][0] . ' on the Automation page: nothing automatic calls it until it\'s resumed. Business operations carry on.', ['do', 'ops_pause:' . $svc, 'Pause it']);
            if ($svc === 'community') $st[] = $s('See the budget', 'Members\' Moments, Snaps and Keeps are paid from 3% of revenue, $25 at least (decisions/0154).', ['tool', '/admin/config/costs']);
            $st[] = $s('Resolve the case', 'It comes back if it climbs to the next level.', ['resolve']);
            return $st;
        }
        if ($key === 'ops:empty') {
            $st = [];
            foreach (self::empties($pdo) as $t => $r) {
                $st[] = $s($r['wf'] . ' ' . $r['name'] . ': ' . $r['runs'] . ' runs, nothing back', 'In 24 hours: ' . number_format($r['fetches']) . ' pages read, ' . number_format($r['searches']) . ' searches, nothing found.' . ($r['last_why'] !== '' ? ' Its last answer: ' . $r['last_why'] . '.' : '') . ' The step clears itself when it finds something again.', ['tool', '/admin/insights/crawler']);
                $st[] = $s('Check ' . $r['name'] . ' now', 'It runs first on the crawler\'s next run (while automation is on).', ['do', 'ops_runnext:' . $t, 'Check it now']);
                $st[] = $s('Pause ' . $r['name'], 'Switched off on the Automation page, with your reason; its work waits.', ['do', 'ops_task_off:' . $t, 'Pause the task']);
            }
            return $st ?: [$s('Nothing returns empty now', 'The case closes by itself.', ['resolve'])];
        }
        if (str_starts_with($key, 'ops:watch:')) {
            $k = substr($key, 10); $r = self::watched($pdo)[$k] ?? [];
            return [$s('Look at it', (string) ($r['what'] ?? ''), null, false, $k === 'railway' ? 'railway' : 'github'),
                    $s('Resolve the case', 'Once it\'s healthy again; the next hourly look raises it again if not.', ['resolve'])];
        }
        return [];
    }

    /** Pulse::manage for an ops: case. Returns what to say. */
    public static function pulseDo(PDO $pdo, string $key, string $what, array $a, int $uid, string $who): string
    {
        [$ok, $why] = self::can();
        if (!$ok) throw new RuntimeException($why . '.');
        if (preg_match('/^ops_cap:([a-z_]+)$/', $what, $m) && in_array($m[1], array_merge(...array_values(self::CAPS)), true)) {
            $v = Thresholds::set($pdo, $m[1], (string) ($a['value'] ?? ''), $uid);
            return Thresholds::GATES[$m[1]][0] . ': ' . self::num($v) . ' ' . Thresholds::GATES[$m[1]][6] . '.';
        }
        if (preg_match('/^ops_pause:([a-z0-9]+)$/', $what, $m) && isset(OutsideServices::COMPANIES[$m[1]])) {
            Automation::set($pdo, 'service', $m[1], true, 'Near its cap (Pulse warning)', $uid, $who);
            return OutsideServices::COMPANIES[$m[1]][0] . ' is paused.';
        }
        if (preg_match('/^ops_(runnext|task_off):([a-z0-9_]+)$/', $what, $m) && self::crawlReady($pdo) && isset(CrawlService::tasks($pdo)[$m[2]])) {
            if ($m[1] === 'runnext') { CrawlService::runNext($pdo, $m[2]); return 'It runs first on the crawler\'s next run.'; }
            Automation::setTask($pdo, $m[2], false, 'Returns empty (Pulse)', $uid, $who);
            return 'The task is switched off.';
        }
        throw new RuntimeException('Unknown step.');
    }

    // ---- the switch-on check (§10) ------------------------------------------------------------------------------------

    /**
     * "Check before switching on" (§10.1): [['line', 'ok' => bool, 'why', 'fix' => [label, url]|null, 'scope' => 'all'|
     * W…|service key, 'stage' => where it's built]]. Anything red keeps that part paused with the reason. Jason,
     * 2026-11-15: the master switch stays off until Release B, whose lines are red until it's built.
     */
    public static function switchOnCheck(PDO $pdo): array
    {
        $L = [];
        $line = function (string $what, bool $ok, string $why, ?array $fix = null, string $scope = 'all', string $stage = '') use (&$L) { $L[] = ['line' => $what, 'ok' => $ok, 'why' => $why, 'fix' => $fix, 'scope' => $scope, 'stage' => $stage]; };
        // no database update waiting or failed
        try {
            require_once __DIR__ . '/DbUpdates.php';
            $waiting = count(DbUpdates::all($pdo)); $failed = count(array_filter(DbUpdates::log($pdo), fn ($r) => !(int) $r['ok']));
            $line('No database update waiting or failed', !$waiting && !$failed, $waiting || $failed ? ($waiting ? $waiting . ' waiting' : '') . ($waiting && $failed ? ', ' : '') . ($failed ? $failed . ' failed' : '') . '.' : 'None.', ['Database updates', '/admin/config/dbupdates']);
        } catch (Throwable $x) { $line('No database update waiting or failed', false, 'Couldn\'t read them: ' . $x->getMessage(), ['Database updates', '/admin/config/dbupdates']); }
        // every service a workflow uses: its key present, not held, its budget and pace set
        foreach (self::register($pdo) as $k => $r) {
            if (!$r['workflows']) continue;
            $miss = array_values(array_filter($r['keys'], fn ($x) => $x[2] === false && !str_contains($x[1], '(')));
            $unread = array_values(array_filter($r['keys'], fn ($x) => $x[2] === null));
            $unset = array_values(array_filter($r['caps'], fn ($c) => isset(Thresholds::FOUND[$c['gate']]) && Thresholds::stored($pdo, $c['gate']) === null));   // a moved cap not recorded yet (its default elsewhere is set)
            $why = [];
            if ($miss) $why[] = 'no key: ' . implode(', ', array_map(fn ($x) => $x[0] . ' (' . $x[1] . ')', $miss));
            if ($unread) $why[] = implode(', ', array_column($unread, 0)) . ' on Railway can\'t be checked from the site until the worker reports its keys (Release B)';
            if ($r['status'][0] === 'held') $why[] = 'held: ' . $r['status'][1];
            if ($r['status'][0] === 'out') $why[] = 'out of budget: ' . $r['status'][1];
            if ($unset) $why[] = 'not recorded in the register: ' . implode(', ', array_map(fn ($c) => mb_strtolower($c['label']), $unset));
            $line($r['name'] . ' (' . implode(', ', $r['workflows']) . ')', !$why, $why ? ucfirst(implode('; ', $why)) . '.' : 'Key present, not held, its budget and pace set.', ['Service register', '/admin/config/register#svc-' . $k], $k);
        }
        // OpenStreetMap: at least one server not held
        try {
            require_once __DIR__ . '/ServiceHealth.php';
            $free = 0; $all = ServiceHealth::servers($pdo, 'osm', 'overpass', true);
            foreach ($all as $sv) { $st = ServiceHealth::serverState($pdo, $sv); if (!(int) $sv['paused'] && $st[0] !== 'bad') $free++; }   // [tone, words, case]: 'bad' is held
            $line('OpenStreetMap: at least one server not held', $free > 0, $free . ' of ' . count($all) . ' Overpass servers free.', ['OpenStreetMap\'s card', '/admin/config/services#svc-osm'], 'osm');
        } catch (Throwable $x) { $line('OpenStreetMap: at least one server not held', false, 'Couldn\'t read the servers: ' . $x->getMessage(), null, 'osm'); }
        // Railway: its schedule back on and its latest deploy healthy (the watch)
        $watch = self::watching($pdo); $seen = self::watched($pdo)['railway'] ?? null;
        $line('The Railway crawler\'s schedule back on, its latest deploy healthy', !empty($watch['on']) && ($seen['ok'] ?? null) === true,
            empty($watch['on']) ? 'Watching is off (Release A ships it off); it needs RAILWAY_API_TOKEN in .env, then Switch watching on. The crawler\'s cron was removed 2026-11-14: set it again on Railway.' : (string) ($seen['what'] ?? 'Not looked at yet.'), ['Watching', '/admin/config/register#watch'], 'railway');
        // the story-only level (P5-3): built in Release A
        require_once __DIR__ . '/Landmarks.php';
        $line('Landmarks\' story-only level (P5-3)', defined('Landmarks::STORY_ONLY'), 'Built: a protected place publicly known moves only to story only; guides\' names no further.', null, 'W9', 'Release A');
        // what's built in Release B (decisions/0163 §8 "Before any switch-on"; Jason, 2026-11-15: keep the master off until then)
        foreach ([
            ['The crawler\'s open fixes live: the junk listing names (AutoImport calls DataCleanup::junkName) and the four approved releases W6, W9, W10/W11, W12', 'all'],
            ['W1 and W8 gate on 0164\'s floor and readiness, not 0133\'s (gap review X2)', 'W1'],
            ['The clocks: each workflow\'s backlog from its paused time, drained at the ramp\'s half budget (X1)', 'all'],
            ['The engine\'s Pulse case, "The engine needs a person" (X3)', 'all'],
            ['A site that blocks us held with a Reactivate step, never retried by itself; the same for a banned service (P1-2, 0164 §6.1)', 'all'],
            ['Opening a geo-hub: its authority sources\' terms and readers, and its opening budget set (H3, H5)', 'all'],
        ] as [$what, $scope]) $line($what, false, 'Built in Release B (handoffs/release-b.md).', null, $scope, 'Release B');
        return $L;
    }

    /**
     * The check's red lines that hold a switch being turned on. 'all' (the master): every red line. A workflow: the lines
     * for it and for the services it uses (the lines for everything hold it through the master). A service: its own.
     * $withAll adds the lines for everything to a workflow's or a service's (what keeps it paused in all).
     */
    public static function blocking(PDO $pdo, string $scope = 'all', bool $withAll = false): array
    {
        $mine = [$scope => true];
        if (isset(Automation::WORKFLOWS[$scope])) foreach (array_keys(OutsideServices::COMPANIES) as $svc) if (in_array($scope, self::users($pdo, $svc)[0], true)) $mine[$svc] = true;
        return array_values(array_filter(self::switchOnCheck($pdo), fn ($l) => !$l['ok'] && ($scope === 'all' || isset($mine[$l['scope']]) || ($withAll && $l['scope'] === 'all'))));
    }
}
