<?php
// app/lib/staging-tables.php — the one register of tables for staging (decisions/0165 §3): every table's class, and the
// links between rows (which column, JSON path, "kind:id" string or link in text holds a record number of which table).
// A migration or ensure() that makes a table names it here in the same release; the zip check (R14) blocks one that
// doesn't. An unlisted table is treated as *follows live*: copied from live, never carried by Publish, and listed on the
// Staging page as "no class", so nothing staging did in it is lost without being shown.
//
// The classes:
//   records  what people and staff make (listings, places, pages, guides, posts, workflows, settings): live's changes come
//            in by catch-up; staging's are merged in at Publish (StagingPublish)
//   money    orders, payments, invoices, subscriptions, gateway rows: live's come in (stripped); never carried
//   follows  bulk reference data and anything a job recomputes: copied from live; never carried
//   own      staging's own (the held ledger, its logs, sessions, views and taps from staging visits): kept; never carried
//   never    sign-in secrets, devices, the vault, one-time codes, page cache, live's release record: empty on staging
declare(strict_types=1);

final class StagingTables
{
    public const CLASSES = [
        'records' => ['Records', 'What people and staff make: catch-up brings live\'s changes in; Publish merges staging\'s into live.'],
        'money'   => ['Money', 'Orders, payments and the like: live\'s come in, stripped; never carried (everything on staging is sandbox).'],
        'follows' => ['Follows live', 'Reference data and what a job recomputes: copied from live; never carried (live\'s own jobs redo it).'],
        'own'     => ['Staging\'s own', 'Staging\'s ledger, logs, views and taps: kept on staging; never carried.'],
        'never'   => ['Never copied', 'Sign-in secrets, devices, the vault, one-time codes, caches: empty on staging; never carried.'],
    ];

    /** Records: carried. */
    public const RECORDS = [
        // listings and places
        'entities', 'entity_metadata', 'listing_categories', 'listing_access', 'listing_memberships', 'listing_actions', 'categories', 'category_also', 'category_terms', 'category_changes',
        'places', 'place_profile', 'place_guides', 'place_stories', 'place_dossiers', 'landmarks', 'experiences', 'experience_links', 'storefronts', 'business_domains', 'short_codes',
        'hubs', 'geo_hubs', 'hub_counties', 'micro_clusters', 'cluster_overrides', 'cluster_subgroups', 'nations', 'nation_decision_log', 'jurisdictions', 'jurisdiction_laws',
        'identity_facts', 'identity_fact_sources', 'identity_applied', 'stories', 'live_events', 'live_event_places', 'heritage_places', 'heritage_facts', 'heritage_sources',
        // guides, journeys, topics
        'resource_guides', 'resource_entries', 'how_guides', 'guide_picks', 'guide_requests', 'guide_audits', 'journeys', 'journey_media', 'journey_coauthors', 'suggested_journeys',
        'topics', 'topic_names', 'topic_places', 'topic_relations', 'topic_facts', 'situations', 'situation_needs', 'situation_sources', 'situation_triggers',
        // community and posts
        'community_groups', 'community_group_members', 'community_group_places', 'community_group_tags', 'community_charters', 'community_chapter_offers', 'community_posts', 'community_help',
        'member_posts', 'member_post_media', 'member_post_to', 'member_post_edits', 'content_comments', 'journey_comments', 'content_tags', 'content_reports', 'takedowns',
        'member_profiles', 'user_settings', 'notice_prefs', 'user_places', 'user_links', 'people_groups', 'people_group_members', 'people_connections',
        // the site's pages, content and settings
        'site_pages', 'site_block_versions', 'site_block_zones', 'site_block_schedule', 'content_templates', 'content_template_versions', 'hero_media', 'consent_wordings', 'policies',
        'feature_switches', 'automation_switches', 'commerce_settings', 'market_settings', 'cleanup_settings', 'pulse_settings', 'staff_settings', 'search_terms', 'search_meanings', 'search_senses',
        'source_rules', 'sources', 'crawler_sources', 'reference_sources', 'crawl_workflows', 'crawl_capture_tasks',
        // workflows, Pulse, staff and access
        'wf_workflows', 'wf_versions', 'wf_items', 'wf_history', 'workflow_versions', 'pulse_marks', 'pulse_notes', 'pulse_posts', 'admin_permissions', 'admin_access',
        'role_grants', 'role_perms', 'staff_accounts', 'system_tags', 'tags',
        // the business side (not money): CRM, sales, products, gallery
        'crm_customers', 'crm_tags', 'crm_customer_tags', 'crm_notes', 'prospects', 'prospect_log', 'sales_cards', 'sales_territories', 'products', 'price_lists', 'price_list_rules',
        'plan_features', 'plans', 'tax_rates', 'ship_rules', 'cost_items', 'cost_recipes', 'market_items', 'market_item_photos', 'market_item_versions', 'market_posts', 'market_photos',
        'gallery_albums', 'gallery_album_items', 'gallery_album_opts', 'gallery_album_people', 'gallery_items', 'gallery_files', 'gallery_versions', 'storage_folders', 'stock_slots', 'contact_cards',
        'address_contacts', 'business_broadcasts', 'collateral', 'biz_codes', 'promotions', 'listing_claims', 'listing_invites', 'people_invites', 'contributors', 'users',
    ];

    /** Money: never carried. */
    public const MONEY = ['orders', 'order_lines', 'order_line_parts', 'order_line_costs', 'order_addresses', 'order_events', 'order_ledger', 'order_files', 'order_proofs', 'order_packs',
        'order_pack_items', 'order_lots', 'order_projects', 'order_feedback', 'order_inbox', 'order_work_orders', 'order_work_order_log', 'market_orders', 'market_offers', 'market_offer_events',
        'market_pay_events', 'market_checkout', 'market_cart', 'market_tickets', 'market_downloads', 'market_gateways', 'subscriptions', 'subscription_addons', 'subscription_charges',
        'member_plans', 'biz_payments', 'biz_quotes', 'biz_quote_lines', 'biz_quote_log', 'biz_code_uses', 'promotion_uses', 'transfers', 'disputes', 'qb_connection', 'qb_settings',
        'qbo_items', 'cart_plans', 'vendor_orders', 'vendor_jobs', 'member_post_spend', 'member_storage_earned', 'earned_gb'];

    /** Follows live: never carried. Names, then patterns. */
    public const FOLLOWS = ['zip_coordinates', 'tv_zip_population', 'open_places', 'open_place_asks', 'npi_orgs', 'npi_loads', 'irs_orgs', 'irs_loads', 'rec_places', 'rec_loads', 'landmark_loads',
        'nation_shapes', 'nation_sensitive', 'ip_eu_ranges', 'ip_eu_ranges_new', 'ip_eu_meta', 'search_index', 'search_index_state', 'search_learned', 'search_demand', 'search_counts',
        'search_outcomes', 'search_opens', 'search_suggestion_flags', 'search_frames', 'search_edits', 'search_drafts', 'listing_confidence', 'lead_scores', 'platform_counts', 'tag_counts',
        'content_like_tally', 'crawl_jobs', 'crawl_targets', 'crawl_pages', 'crawl_runs', 'crawl_run_items', 'crawl_requests', 'crawl_costs', 'crawl_service_calls', 'crawl_osm_asks',
        'crawler_raw_index', 'source_facts', 'identity_jobs', 'town_crawl_jobs', 'guide_finds', 'travel_legs', 'osm_usage', 'stock_images', 'stock_search_cache', 'stock_uses', 'weather',
        'service_issues', 'service_servers', 'ai_jobs', 'video_jobs', 'cleanup_checks', 'cleanup_runs', 'cleanup_ledger', 'data_moves', 'db_updates_log', 'job_runs', 'job_setup',
        'daily_reports', 'situation_gaps', 'match_names', 'junk_name', 'store_junk', 'store_guard', 'store_cite', 'imported', 'crm_sync', 'email_events', 'email_sends', 'email_state',
        'email_suppress', 'email_pauses', 'notices_sent', 'notice_delivery', 'audit_log', 'staff_log', 'role_log', 'automation_log', 'member_access_log', 'member_action_log',
        'member_post_log', 'tool_consent_log', 'threshold_log', 'like_events', 'like_flags', 'like_watch', 'guest_likes', 'guest_ip_likes', 'site_health_marks', 'csp_reports',
        'admin_edit_log', 'qr_issued', 'short_scans', 'member_active_days', 'biz_schema'];
    public const FOLLOWS_LIKE = ['/_cache$/', '/_counts?$/', '/_tally$/', '/_loads$/', '/^search_/', '/^crawl_/', '/^ip_/', '/_log$/', '/^tvchk_/', '/^_moved_/'];

    /** Staging's own: kept; never carried. Views and taps from staging visits are staging's (Jason, 2026-11-15, choice 5). */
    public const OWN = ['staging_mail', 'staging_s3', 'staging_held', 'staging_allow', 'staging_pace', 'stg_plan', 'stg_base', 'stg_changes', 'stg_renumber', 'stg_id_refs', 'stg_conflicts', 'stg_outbox_seen', 'pub_journal', 'stg_bar_used',
        'journey_views', 'member_post_views', 'content_likes', 'journey_likes', 'gallery_downloads', 'gallery_uses', 'gallery_picks', 'gallery_pick_sends', 'gallery_guest', 'gallery_guest_items',
        'gallery_guest_keys', 'market_saves', 'market_contacts', 'search_opens', 'member_post_holds', 'member_post_prefs', 'messages', 'message_threads', 'message_members', 'business_messages',
        'business_message_reads', 'business_message_mutes', 'guest_inquiries', 'guest_inquiry_messages', 'contact_requests', 'site_form_entries', 'verify_requests', 'verification_attempts',
        'age_confirmations', 'terms_acceptances', 'tool_consents', 'marketing_optins', 'account_closures', 'opt_out_requests', 'entity_referrals', 'connections', 'contact_shares',
        'business_contact_shares', 'community_group_invites', 'community_group_joins', 'community_invite_codes', 'ai_asks', 'test_records', 'user_blocks'];

    /** Never copied: empty on staging (StagingSite::EMPTY_TABLES and live's own records of staging and releases). */
    public const NEVER = ['vault_meta', 'vault_creds', 'vault_items', 'vault_ext', 'vault_log', 'email_confirmations', 'user_otp_challenges', 'user_identities', 'two_step_devices',
        'staff_recovery_codes', 'guest_devices', 'support_grants', 'page_cache', 'staging_state', 'site_releases', 'site_release_settings', 'stg_outbox', 'identities'];

    /**
     * Kinds: the word a "kind:id" string, a Pulse key or a link uses, => its table. Every id of these tables found in
     * text (kind:id, links) is rewritten when a row is renumbered.
     */
    public const KINDS = ['entity' => 'entities', 'listing' => 'entities', 'business' => 'entities', 'landmark' => 'landmarks', 'guide' => 'resource_guides', 'post' => 'member_posts',
        'place' => 'places', 'journey' => 'journeys', 'order' => 'orders', 'experience' => 'experiences', 'user' => 'users', 'storefront' => 'storefronts', 'page' => 'site_pages',
        'workflow' => 'wf_workflows', 'topic' => 'topics', 'group' => 'community_groups', 'comment' => 'content_comments', 'story' => 'stories'];

    /** Links in text that carry a record number: table => patterns (the number is the first group). */
    public const LINKS = [
        'entities' => ['#/listing/view\.php\?id=(\d+)#', '#/listing/(\d+)(?![\d/])#', '#/biz/(\d+)(?!\d)#'],
        'resource_guides' => ['#/guide\.php\?id=(\d+)#', '#/guides?/(\d+)(?!\d)#'],
        'journeys' => ['#/journey\.php\?id=(\d+)#', '#/journeys?/(\d+)(?!\d)#'],
        'places' => ['#/place\.php\?id=(\d+)#'],
        'landmarks' => ['#/landmark\.php\?id=(\d+)#'],
        'member_posts' => ['#/post\.php\?id=(\d+)#'],
        'experiences' => ['#/experience\.php\?id=(\d+)#'],
    ];

    /**
     * Columns that hold a record number, named here where the name doesn't say which table (the rest are read from
     * their names: <thing>_id → the table of <thing>, by NAMES). table.column => table it points to.
     */
    public const REFS = [
        '*.owner_user_id' => 'users', '*.created_by' => 'users', '*.updated_by' => 'users', '*.approved_by' => 'users', '*.decided_by' => 'users', '*.by_user' => 'users',
        '*.member_user_id' => 'users', '*.author_id' => 'users', '*.parent_id' => '=', '*.replaces_id' => '=', '*.ref_id' => '?kind', '*.from_id' => '?kind', '*.to_id' => '?kind',
        'listing_access.entity_id' => 'entities', 'entity_metadata.entity_id' => 'entities', 'storefronts.entity_id' => 'entities',
    ];

    /** <thing>_id → table, where the plural isn't just <thing>s. */
    public const NAMES = ['entity' => 'entities', 'listing' => 'entities', 'business' => 'entities', 'biz' => 'entities', 'user' => 'users', 'member' => 'users', 'staff' => 'staff_accounts',
        'category' => 'categories', 'guide' => 'resource_guides', 'post' => 'member_posts', 'story' => 'stories', 'group' => 'community_groups', 'workflow' => 'wf_workflows',
        'wf' => 'wf_workflows', 'page' => 'site_pages', 'album' => 'gallery_albums', 'customer' => 'crm_customers', 'hub' => 'hubs', 'cluster' => 'micro_clusters', 'nation' => 'nations',
        'topic' => 'topics', 'situation' => 'situations', 'product' => 'products', 'item' => '?', 'thread' => 'message_threads'];

    /** JSON and settings blobs that hold record numbers: table.column => [JSON path (a.b.*.c) => table]. */
    public const JSON = [
        'site_pages.layout' => ['blocks.*.listing_id' => 'entities', 'blocks.*.guide_id' => 'resource_guides', 'blocks.*.ids.*' => '?kind'],
        'site_block_versions.data' => ['*.listing_id' => 'entities', '*.guide_id' => 'resource_guides'],
        'content_template_versions.body' => ['*.listing_id' => 'entities'],
        'user_settings.value' => ['saved.*.listing_id' => 'entities'],
        'pulse_marks.data' => ['entity_id' => 'entities', 'user_id' => 'users'],
    ];

    /** Columns whose text is searched for kind:id strings and links (notes, logs, descriptions, messages, Pulse keys). */
    public const TEXT_COLS = ['/(^|_)(note|notes|body|text|description|summary|msg|message|detail|details|key|ref|url|link|html|content|about)$/'];

    /** Store keys that carry an id: pattern (group 1 = table kind, group 2 = id). */
    public const STORE_KEYS = ['#^(entity|entities|listing|guide|journey|post|place|user)(s?)/(\d+)/#'];

    /** The class of a table ('follows' when it has none: see noClass()). */
    public static function classOf(string $t): string
    {
        if (in_array($t, self::NEVER, true)) return 'never';
        if (in_array($t, self::OWN, true)) return 'own';
        if (in_array($t, self::MONEY, true)) return 'money';
        if (in_array($t, self::RECORDS, true)) return 'records';
        return 'follows';
    }

    /** Is the table named here (by name or pattern)? A table that isn't is shown as "no class" (treated as follows live). */
    public static function named(string $t): bool
    {
        foreach ([self::NEVER, self::OWN, self::MONEY, self::RECORDS, self::FOLLOWS] as $l) if (in_array($t, $l, true)) return true;
        foreach (self::FOLLOWS_LIKE as $p) if (preg_match($p, $t)) return true;
        return false;
    }

    public static function carried(string $t): bool { return self::classOf($t) === 'records'; }

    /** The table a column points to: a table name, '=' (its own table), '?kind' (a kind column beside it says), '' when it holds no record number, null when it looks like one and isn't known. */
    public static function refOf(string $t, string $col, string $type = 'int'): ?string
    {
        $c = strtolower($col);
        if (isset(self::REFS[$t . '.' . $c])) return self::REFS[$t . '.' . $c];
        if (isset(self::REFS['*.' . $c])) return self::REFS['*.' . $c] === '=' ? $t : self::REFS['*.' . $c];
        if ($c === 'id') return '';
        if (!preg_match('/^(.+)_id$/', $c, $m)) return '';
        if (!preg_match('/int/i', $type)) return '';   // text ids (a Stripe id, a Google place id) aren't our record numbers
        $thing = (string) preg_replace('/^(old|new|from|to|parent|main|primary|linked|home|via|source|target|their|my|other)_/', '', $m[1]);
        if (isset(self::NAMES[$thing])) return self::NAMES[$thing] === '?' ? null : self::NAMES[$thing];
        foreach ([$thing . 's', $thing . 'es', preg_replace('/y$/', 'ies', $thing), $thing] as $guess) if (in_array($guess, self::RECORDS, true) || in_array($guess, self::MONEY, true)) return $guess;
        return null;
    }
}
