/* js/stg-bar.js — the site manager (decisions/0159 §5; it was the staging bar, decisions/0145 Phase 5): on staging.trvgo.us,
 * for whoever came in from the live admin (Open staging). At the top of every page, in the admin command bar's look (0129):
 *   Releases ▾  what's on staging now, what's waiting, what's live and at which step; choosing one shows it here;
 *               Check for builds takes Claude's finished builds from git onto staging now (the site also looks every 10 min)
 *   Upload      a release zip goes straight onto staging and its checks run (the one uploader: target release_zip_bar,
 *               then the live site makes it a release); no separate Approve the plan or Put it on staging
 *   Review      a build sent for review (Jason, 2026-11-13): UI, UX and Functional, each Approve or Needs changes with a
 *               note; Publish opens when all three are approved
 *   Changes     the pages it touches, to jump to and look at, its files and checks
 *   Note        pins what you see to this page (kept with the release)
 *   Publish ▾   Publish now, Schedule, the next step; Turn off and Roll back once it's live
 * Opening a release here is the look (the live site records it); Publish is the sign-off. Every action goes to the live site
 * (/api/stg-bar.php passes it on, signed) as you, with the release permissions you had when you came in. ◆ folds it. */
(function () {
  var mount = document.getElementById('tv-stg-bar');
  if (!mount) return;
  var KEY = 'tvStgRel', FOLD = 'tvStgFold';
  var get = function (k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
  var put = function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} };
  // the release picked from Releases ▾ (or just acted on) is kept for this tab only; otherwise the bar shows what's on
  // staging now, or the newest (Jason, 2026-11-13: it kept showing #18, the first one it showed, after #27 went live)
  var getRel = function () { try { return sessionStorage.getItem(KEY) || ''; } catch (e) { return ''; } };
  var putRel = function (v) { try { sessionStorage.setItem(KEY, v); localStorage.removeItem(KEY); } catch (e) {} };
  var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
  var C = { sage: '#B9D8C6', sageLine: '#9CC3AE', orange: '#E07F3C', peach: '#F1B48C', ink: '#2B1D14', cream: '#FFFBF2', line: '#CBB98D', brown: '#92400E', ok: '#8FBCA8', bad: '#B91C1C' };

  // the bar sits over the page (z-index 1000) but under the site's own pop-ups (the Gallery, search, peek: 1370 and up)
  var css = document.createElement('style');
  css.textContent = '#tv-stg-bar{position:relative;z-index:1000;font:14px/1.35 system-ui,sans-serif;color:' + C.ink + '}'
    + '#tv-stg-bar .sm{display:flex;align-items:stretch;min-height:2.6rem;background:' + C.sage + ';border-bottom:1px solid ' + C.sageLine + ';box-shadow:0 6px 14px -12px rgba(0,0,0,.5)}'
    + '#tv-stg-bar .sm-fold{flex:0 0 2.6rem;border:0;background:' + C.orange + ';color:#fff;font-size:1.1rem;cursor:pointer}#tv-stg-bar .sm-fold:hover{background:#C96A28}'
    + '#tv-stg-bar .sm-l{box-sizing:border-box;flex:1 1 10rem;min-width:0;display:flex;flex-direction:column;justify-content:center;padding:.25rem .7rem}'
    + '#tv-stg-bar .sm-t{font:700 1rem ui-serif,Georgia,serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
    + '#tv-stg-bar .sm-s{font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#3E2B1F}'
    + '#tv-stg-bar .sm-dot{display:inline-block;width:.55rem;height:.55rem;border-radius:50%;margin-right:.35rem;vertical-align:0}'
    + '#tv-stg-bar .sm-r{position:relative;isolation:isolate;display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;gap:.35rem;padding:.3rem .6rem .3rem 2.1rem}'
    + '#tv-stg-bar .sm-r::before{content:"";position:absolute;inset:0;z-index:-1;background:' + C.peach + ';clip-path:polygon(1.5rem 0,100% 0,100% 100%,0 100%)}'
    + '#tv-stg-bar .sm-b{font:700 .85rem/1.2 system-ui,sans-serif;border:1.5px solid ' + C.orange + ';background:#fff;color:' + C.ink + ';border-radius:.3rem;padding:.32rem .65rem;cursor:pointer;text-decoration:none;white-space:nowrap}'
    + '#tv-stg-bar .sm-b.go{background:' + C.orange + ';color:#fff}#tv-stg-bar .sm-b[disabled]{opacity:.5;cursor:default}'
    + '#tv-stg-bar .sm-b[aria-busy=true]::before{content:"";display:inline-block;width:.7rem;height:.7rem;margin-right:.35rem;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;vertical-align:-1px;animation:smspin .8s linear infinite}'
    + '@keyframes smspin{to{transform:rotate(360deg)}}'
    + '#tv-stg-bar .sm-dd{position:relative}'
    + '#tv-stg-bar .sm-menu{position:absolute;right:0;top:calc(100% + .35rem);min-width:15rem;max-width:min(22rem,calc(100vw - 1rem));max-height:min(70vh,30rem);overflow:auto;background:' + C.cream + ';border:1px solid ' + C.line + ';border-radius:.7rem;box-shadow:0 14px 30px -12px rgba(0,0,0,.45);padding:.3rem;display:grid;z-index:2}'
    + '#tv-stg-bar .sm-menu button{display:block;width:100%;text-align:left;font:600 .9rem/1.3 system-ui,sans-serif;color:#3E2B1F;background:none;border:0;border-radius:.45rem;padding:.5rem .6rem;cursor:pointer}'
    + '#tv-stg-bar .sm-menu button:hover,#tv-stg-bar .sm-menu button[aria-current=true]{background:#F3EAD6}#tv-stg-bar .sm-menu .no{color:#991B1B}'
    + '#tv-stg-bar .sm-menu h5{margin:.4rem .6rem .15rem;font:700 .72rem system-ui,sans-serif;letter-spacing:.04em;text-transform:uppercase;color:#8A7355}'
    + '#tv-stg-bar .sm-menu small{display:block;font-weight:400;color:#8A7355}'
    + '#tv-stg-bar .sm-panel{background:' + C.cream + ';color:#3E2B1F;max-height:60vh;overflow:auto;padding:.7rem .9rem;border-bottom:3px solid ' + C.orange + '}'
    + '#tv-stg-bar .sm-panel h4{margin:.6rem 0 .25rem;font-size:.85rem;color:' + C.brown + '}#tv-stg-bar .sm-panel a{color:' + C.brown + '}'
    + '#tv-stg-bar .sm-panel ul{margin:0;padding-left:1.1rem}#tv-stg-bar .sm-panel textarea,#tv-stg-bar .sm-panel input{width:100%;box-sizing:border-box;font:16px system-ui,sans-serif;padding:.4rem;border:1px solid ' + C.line + ';border-radius:.4rem}'
    + '#tv-stg-bar .sm-panel .sm-b{margin:.5rem .35rem 0 0}'
    + '#tv-stg-bar .sm-msg{padding:.45rem .9rem;font-weight:600}'
    + '#tv-stg-bar .sm-tab{position:fixed;right:8px;bottom:8px;background:' + C.orange + ';color:#fff;border:0;border-radius:999px;padding:6px 12px;font:700 12px system-ui,sans-serif;box-shadow:0 1px 4px rgba(0,0,0,.3);z-index:1000}'
    + '@media (max-width:640px){#tv-stg-bar .sm{flex-wrap:wrap}#tv-stg-bar .sm-l{flex-basis:calc(100% - 2.6rem)}#tv-stg-bar .sm-r{flex:1 1 100%;justify-content:flex-start;padding-left:.6rem}#tv-stg-bar .sm-r::before{clip-path:none}#tv-stg-bar .sm-menu{right:auto;left:0}}';
  document.head.appendChild(css);

  var state = null, open = '', menu = '', msg = null;
  function el(tag, attrs, kids) {
    var x = document.createElement(tag);
    for (var k in (attrs || {})) { if (k === 'text') x.textContent = attrs[k]; else if (k === 'on') x.addEventListener('click', attrs[k]); else x.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c) x.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return x;
  }
  function api(method, body) {
    var o = { method: method, credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-Tv-Stg-Bar': '1' } };
    if (body) o.body = JSON.stringify(window.tvSafe ? tvSafe(body) : body);
    var url = '/api/stg-bar.php' + (method === 'GET' ? '?rel=' + encodeURIComponent(getRel()) : '');
    return fetch(url, o).then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'Staging didn\'t answer clearly. Try again.' } }; }); }, function () { return { ok: false, error: { message: 'The connection dropped. Try again.' } }; })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again; still stuck? Write to support@traversence.com.'); return j; });
  }
  function busy(btn, on) { if (!btn) return; if (on) { btn.setAttribute('aria-busy', 'true'); btn.disabled = true; } else { btn.removeAttribute('aria-busy'); btn.disabled = false; } }
  function say(text, bad, btn) { msg = [text, !!bad]; if (window.TvAsk && TvAsk.say && btn && btn.isConnected) TvAsk.say(text, { anchor: btn, bad: !!bad }); }
  function load() { return api('GET').then(function (j) { state = j; draw(); }, function (e) { msg = [e.message, true]; draw(); }); }
  function act(btn, action, args) {
    busy(btn, true);
    return api('POST', { action: action, rel: state && state.release ? state.release.id : 0, args: Object.assign({ tz: tz, page: location.pathname + location.search }, args || {}) })
      .then(function (j) { open = action === 'note' ? 'notes' : ''; menu = ''; say(j.message || 'Done.', false, btn); if (j.id) putRel(String(j.id)); return load(); },
            function (e) { busy(btn, false); say(e.message, true, btn); draw(); });
  }

  // staging as a whole (decisions/0165 §5): the line, Held, Conflicts, Preview and Publish, To send now, Roll back
  function stgAct(btn, sa, args) {
    busy(btn, true);
    return api('POST', { action: 'stg:' + sa, rel: 0, args: Object.assign({ tz: tz }, args || {}) })
      .then(function (j) { busy(btn, false); if (j.message) say(j.message, false, btn); return j; }, function (e) { busy(btn, false); say(e.message, true, btn); drawMsg(); throw e; });
  }
  function when(iso) { try { var d = typeof iso === 'number' ? new Date(iso * 1000) : new Date(String(iso).replace(' ', 'T') + (/[zZ+]|[-]\d\d:\d\d$/.test(String(iso)) ? '' : 'Z')); return d.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short' }); } catch (e) { return String(iso); } }
  function rowsTable(cols, rows) {
    var tb = el('table', { style: 'width:100%;border-collapse:collapse;font-size:.8rem;margin:.3rem 0' });
    tb.appendChild(el('tr', {}, cols.map(function (c) { return el('th', { style: 'text-align:left;border-bottom:1px solid #E8DCC2;padding:2px 4px', text: c }); })));
    rows.forEach(function (r) { tb.appendChild(el('tr', {}, r.map(function (v) { return el('td', { style: 'vertical-align:top;border-bottom:1px solid #F3E8D6;padding:2px 4px;word-break:break-word', text: v == null ? '—' : String(v) }); }))); });
    return tb;
  }
  var stgRun = null, stgPoll = 0;
  function stgPanel(kind) {
    var S = (state && state.staging) || {}, panel = el('div', { class: 'sm-panel' });
    if (kind === 'held') {
      panel.appendChild(el('p', { style: 'margin:0', text: 'What staging held instead of sending or calling out, newest first. Nothing here left staging; an email can be sent to you, marked as from staging, never to its real recipient.' }));
      var box = el('div', { text: 'Loading…' }); panel.appendChild(box);
      stgAct(null, 'held', { limit: 60 }).then(function (j) {
        box.textContent = '';
        if (!j.held.length) { box.textContent = 'Nothing held yet.'; return; }
        j.held.forEach(function (h) {
          var row = el('div', { style: 'border-top:1px solid #E8DCC2;padding:.35rem 0' });
          row.appendChild(el('b', { text: (h.kind === 'mail' ? 'Email' : h.kind === 'csp' ? 'Blocked script' : 'Call') + ': ' + (h.subject || h.target) }));
          row.appendChild(el('div', { style: 'font-size:.78rem;color:#8A7355', text: (h.kind === 'mail' ? 'to ' + h.target + ' · ' : (h.service ? h.service + ' · ' : '')) + (h.why || '') + ' · ' + when(h.created_at) + (h.replayed_at ? ' · done: ' + h.replayed_to : '') }));
          if (h.kind === 'mail') row.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Send to me', on: function (e) { stgAct(e.currentTarget, 'sendme', { id: h.id }); } }));
          box.appendChild(row);
        });
      }, function (e) { box.textContent = e.message; });
    }
    if (kind === 'conf') {
      panel.appendChild(el('p', { style: 'margin:0', text: 'Rows both sides changed, the same field two ways: base (when they last matched) · staging · live. Choose for each; Publish opens when none is left.' }));
      var cb = el('div', { text: 'Loading…' }); panel.appendChild(cb);
      var drawConf = function (list) {
        cb.textContent = '';
        if (!list.length) { cb.textContent = 'No conflicts.'; return; }
        list.forEach(function (x) {
          var row = el('div', { style: 'border-top:1px solid #E8DCC2;padding:.4rem 0' });
          row.appendChild(el('b', { text: x.kind + ' · ' + x.tbl + ' #' + x.k.replace(/\u001f/g, ' · ') }));
          row.appendChild(el('div', { style: 'font-size:.78rem;color:#8A7355', text: x.why + ' · found ' + when(x.found_at) }));
          var rows = []; Object.keys(x.clash || {}).forEach(function (f) { var v = x.clash[f]; rows.push([f === '*' ? '(the whole row)' : f, v[0], v[1], v[2]]); });
          row.appendChild(rowsTable(['Field', 'Base', 'Staging', 'Live'], rows));
          row.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Keep live', on: function (e) { stgAct(e.currentTarget, 'settle', { realm: x.realm, tbl: x.tbl, k: x.k, choice: 'live' }).then(function (j) { drawConf(j.conflicts || []); load(); }); } }));
          row.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Use staging', on: function (e) { stgAct(e.currentTarget, 'settle', { realm: x.realm, tbl: x.tbl, k: x.k, choice: 'staging' }).then(function (j) { drawConf(j.conflicts || []); load(); }); } }));
          cb.appendChild(row);
        });
        cb.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Keep live for the rest', on: function (e) { if (window.TvAsk && !TvAsk.gate(e.currentTarget, 'Keep live\'s for every conflict left?', { yes: 'Keep live' })) return; stgAct(e.currentTarget, 'keeplive').then(function () { drawConf([]); load(); }); } }));
      };
      stgAct(null, 'conflicts').then(function (j) { drawConf(j.conflicts); }, function (e) { cb.textContent = e.message; });
    }
    if (kind === 'pub') {
      var pv = S.preview, run = stgRun || S.run;
      if (run && (run.state === 'running' || run.state === 'undoing' || run.state === 'stopped')) {
        panel.appendChild(el('h4', { style: 'margin-top:0', text: run.state === 'stopped' ? 'Publish stopped at ' + run.step : (run.state === 'undoing' ? 'Undoing: ' : 'Publishing: ') + 'step ' + (run.pos + 1) + ' of ' + run.of + ', ' + run.step }));
        panel.appendChild(el('ul', { style: 'font-size:.78rem' }, run.log.map(function (l) { return el('li', { text: l }); })));
        if (run.message) panel.appendChild(el('p', { text: run.message }));
        if (run.state === 'stopped') {
          panel.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Carry on', on: function (e) { stgAct(e.currentTarget, 'carryon').then(function (j) { stgRun = j.run; draw(); }); } }));
          panel.appendChild(el('a', { class: 'sm-b', href: 'mailto:support@traversence.com?subject=Publish%20of%20staging%20stopped', text: 'Ask our team' }));
        } else if (!stgPoll) stgPoll = setTimeout(function () { stgPoll = 0; stgAct(null, 'carry').then(function (j) { stgRun = j.run; if (open === 'stg:pub') draw(); if (j.run && /done|undone|rolled_back/.test(j.run.state)) load(); }, function () {}); }, 5000);
        return panel;
      }
      if (run && /done|undone|rolled_back/.test(run.state) && run.message) panel.appendChild(el('p', { style: 'margin:0 0 .4rem;font-weight:600', text: run.message }));
      panel.appendChild(el('p', { style: 'margin:0', text: 'Publish takes all of staging to live at once: every release here, then what was made and changed here, merged with live (nothing lost; a field both changed is yours to choose). Live stays open. Staging\'s views, counts, test data and money never go.' }));
      if (pv) {
        var c = pv.counts || {}, kinds = Object.keys(c);
        panel.appendChild(el('h4', { text: 'The preview, worked out ' + when(pv.at) }));
        panel.appendChild(el('p', { style: 'margin:0', text: (pv.releases || []).length + ' releases (' + pv.files + ' files) · ' + pv.rows + ' rows · ' + pv.conflicts + ' conflicts · ' + pv.held + ' held · about ' + pv.minutes + ' min' }));
        if (kinds.length) panel.appendChild(rowsTable(['What', 'Added', 'Changed', 'Removed'], kinds.map(function (k) { return [k, c[k].added || 0, c[k].changed || 0, c[k].removed || 0]; })));
        var nc = Object.keys(pv.not_carried || {});
        if (nc.length) { panel.appendChild(el('h4', { text: 'Not carried, and why' })); panel.appendChild(el('ul', { style: 'font-size:.78rem' }, nc.map(function (k) { return el('li', { text: k + ': ' + pv.not_carried[k] }); }))); }
        if ((pv.releases || []).length) { panel.appendChild(el('h4', { text: 'Releases' })); panel.appendChild(el('ul', { style: 'font-size:.78rem' }, pv.releases.map(function (x) { return el('li', { text: (x.ok ? '✓ #' : '✗ #') + x.id + ' ' + x.title }); }))); }
        if (pv.blocking && pv.blocking.length) panel.appendChild(el('p', { 'data-tv-status': 'bad', 'data-tv-label': 'Publish waits:', text: pv.blocking.join(' ') }));
      }
      panel.appendChild(el('button', { type: 'button', class: 'sm-b', text: pv ? 'Preview again' : 'Preview', on: function (e) { stgAct(e.currentTarget, 'preview').then(function () { load().then(function () { open = 'stg:pub'; draw(); }); }); } }));
      var fresh = pv && (Date.now() - new Date(pv.at).getTime()) < 15 * 60000 && !(pv.blocking || []).length;
      if (fresh) panel.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Publish', on: function (e) {
        if (window.TvAsk && !TvAsk.gate(e.currentTarget, 'Publish staging to live?', { yes: 'Publish' })) return;
        stgAct(e.currentTarget, 'publish').then(function (j) { stgRun = j.run; draw(); });
      } }));
      else if (pv) panel.appendChild(el('small', { style: 'display:block;color:#8A7355', text: (pv.blocking || []).length ? 'Publish opens when nothing above waits.' : 'The preview is over 15 minutes old: Preview again, then Publish.' }));
      var dt = el('input', { type: 'datetime-local', 'aria-label': 'When staging goes live' });
      panel.appendChild(el('h4', { text: 'Or schedule it' + (S.scheduled ? ' (scheduled for ' + when(S.scheduled.at) + ')' : '') }));
      panel.appendChild(dt);
      panel.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Schedule', on: function (e) { if (!dt.value) { say('Choose the date and time first.', true, e.currentTarget); drawMsg(); return; } stgAct(e.currentTarget, 'schedule', { at: dt.value }).then(load); } }));
      if (S.scheduled) panel.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Take off the schedule', on: function (e) { stgAct(e.currentTarget, 'unschedule').then(load); } }));
    }
    if (kind === 'send') {
      panel.appendChild(el('p', { style: 'margin:0', text: 'Held on staging and never sent by Publish. Each can go from the live site now, to its real recipient, or be dropped.' }));
      var sb = el('div', { text: 'Loading…' }); panel.appendChild(sb);
      stgAct(null, 'tosend').then(function (j) {
        sb.textContent = ''; if (!j.items.length) { sb.textContent = 'Nothing waiting.'; return; }
        j.items.forEach(function (h) {
          var row = el('div', { style: 'border-top:1px solid #E8DCC2;padding:.35rem 0' }, [el('b', { text: h.subject }), el('div', { style: 'font-size:.78rem;color:#8A7355', text: 'to ' + h.target + ' · ' + when(h.created_at) })]);
          row.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Send', on: function (e) { if (window.TvAsk && !TvAsk.gate(e.currentTarget, 'Send it to ' + h.target + ' from the live site?', { yes: 'Send' })) return; stgAct(e.currentTarget, 'sendnow', { id: h.id, send: 1 }).then(function () { row.remove(); }); } }));
          row.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Drop', on: function (e) { stgAct(e.currentTarget, 'sendnow', { id: h.id, send: 0 }).then(function () { row.remove(); }); } }));
          sb.appendChild(row);
        });
      }, function (e) { sb.textContent = e.message; });
    }
    return panel;
  }

  // Upload: the one uploader (js/tv-upload.js, loaded when first needed), then the live site makes it a release, on staging
  function withUploader() {
    if (window.TvUpload) return Promise.resolve();
    return new Promise(function (ok, no) { var s = document.createElement('script'); s.src = '/js/tv-upload.js'; s.onload = ok; s.onerror = function () { no(new Error('The uploader didn\'t load. Reload the page and try again.')); }; document.head.appendChild(s); });
  }
  function upload(btn, file) {
    if (!/\.zip$/i.test(file.name || '')) { say('Choose the release\'s .zip file.', true, btn); draw(); return; }
    busy(btn, true); msg = ['Uploading ' + file.name + '…', false]; open = ''; drawMsg();
    withUploader().then(function () { return TvUpload.send([file], { target: 'release_zip_bar', ctx: { tz: tz }, el: mount }); })
      .then(function (res) {
        var r = (res && res[0]) || {}, got = r.result || r;
        if (r.ok === false || r.error || !got.inbox) throw new Error((r.error && (r.error.message || r.error)) || 'The upload didn\'t go through. Try again.');
        msg = ['Uploaded: making it a release and putting it on staging (its checks run now; a minute or two)…', false]; drawMsg();
        return act(btn, 'upload', { inbox: got.inbox, name: got.name || file.name });
      })
      .catch(function (e) { busy(btn, false); say(e.message, true, btn); draw(); });
  }

  function drawMsg() {
    var old = mount.querySelector('.sm-msg'); if (old) old.remove();
    if (!msg) return;
    var m = el('div', { class: 'sm-msg', role: 'status', style: 'background:' + (msg[1] ? C.bad : C.ok) + ';color:' + (msg[1] ? C.cream : '#1F2E27') }, [(msg[1] ? 'Error: ' : (/…$/.test(msg[0]) ? '' : 'Success: ')) + msg[0]]);
    m.appendChild(el('button', { type: 'button', class: 'sm-b', style: 'float:right;padding:0 .4rem;margin-left:.5rem', 'aria-label': 'Close', text: '×', on: function () { msg = null; drawMsg(); } }));
    var bar = mount.querySelector('.sm'); if (bar && bar.nextSibling) mount.insertBefore(m, bar.nextSibling); else mount.appendChild(m);
  }

  // when the site last looked for builds by itself (the 10-minute job): a job that isn't running shows here
  function seenLine() {
    var j = state && state.git_seen && state.git_seen.job, now = (state && state.now) || Math.floor(Date.now() / 1000);
    if (!j) return 'The site hasn\'t looked by itself yet (its 10-minute job): use this.';
    var m = Math.max(0, Math.round((now - j.at) / 60));
    return (m > 25 ? '⚠ ' : '') + 'The site last looked by itself ' + (m < 1 ? 'just now' : m + ' min ago') + (j.found < 0 ? ' (GitHub didn\'t answer)' : '') + (m > 25 ? ': its 10-minute job isn\'t running.' : '.');
  }
  function dd(name, label, items) {   // a drop-down like the command bar's Shortcuts: [label, onclick, class, small]
    var wrap = el('div', { class: 'sm-dd' });
    wrap.appendChild(el('button', { type: 'button', class: 'sm-b', 'aria-haspopup': 'true', 'aria-expanded': String(menu === name), text: label + ' ▾', on: function () { menu = menu === name ? '' : name; draw(); } }));
    if (menu === name) {
      var m = el('div', { class: 'sm-menu', role: 'menu' });
      items.forEach(function (it) {
        if (typeof it === 'string') { m.appendChild(el('h5', { text: it })); return; }
        var b = el('button', { type: 'button', role: 'menuitem', class: it[2] || '', on: it[1] }, [it[0]]);
        if (it[3]) b.appendChild(el('small', { text: it[3] }));
        if (it[4]) b.setAttribute('aria-current', 'true');
        m.appendChild(b);
      });
      wrap.appendChild(m);
    }
    return wrap;
  }

  function draw() {
    mount.innerHTML = '';
    if (get(FOLD) === '1') { mount.appendChild(el('button', { class: 'sm-tab', type: 'button', text: 'Site manager ▾', 'aria-label': 'Open the site manager', on: function () { put(FOLD, ''); draw(); } })); return; }
    var r = state && state.release, list = (state && state.releases) || [];
    var bar = el('div', { class: 'sm', role: 'region', 'aria-label': 'Site manager' });
    bar.appendChild(el('button', { type: 'button', class: 'sm-fold', title: 'Fold the site manager', 'aria-label': 'Fold the site manager', text: '◆', on: function () { put(FOLD, '1'); draw(); } }));
    var l = el('div', { class: 'sm-l' });
    var t = el('div', { class: 'sm-t' });
    if (r) { t.appendChild(el('span', { class: 'sm-dot', style: 'background:' + (r.tone === 'bad' ? C.bad : r.tone === 'ok' ? '#2F7D5B' : '#8A7355') })); t.appendChild(document.createTextNode('#' + r.id + ' ' + r.title)); t.title = r.title; }
    else t.textContent = 'Site manager · staging';
    l.appendChild(t);
    l.appendChild(el('div', { class: 'sm-s', title: r ? r.line : '', text: r ? r.state_name + (r.state === 'live' && r.switch ? ', step ' + r.step + ' of 3' : '') + ': ' + r.line
      : (state ? (state.staging ? state.staging.line + ' · ' : '') + (list.length ? 'No release chosen: Releases ▾ to choose one, or Upload a zip.' : 'No release on staging now: you\'re looking at a copy of live. Upload a zip to try one.') : 'Loading…') }));
    bar.appendChild(l);

    var right = el('div', { class: 'sm-r' });
    // Releases ▾
    var items = [], groups = { staging: 'On staging now', waiting: 'Waiting', live: 'Live (the newest)' };
    if (state && state.can_upload) items.push(['Check for builds', function () {   // first in the list (Jason, 2026-11-13: it was lost under the live ones)
      menu = ''; draw(); act(mount.querySelector('.sm-dd > .sm-b'), 'pull');   // the bar moves to what came in (its id), else stays
    }, '', 'Claude\'s finished builds, from git, onto staging now. ' + seenLine()]);
    ['staging', 'waiting', 'live'].forEach(function (g) {
      var xs = list.filter(function (x) { return x.group === g; }); if (g === 'live') xs = xs.slice(0, 5); if (!xs.length) return;
      items.push(groups[g]);
      xs.forEach(function (x) { items.push(['#' + x.id + ' ' + x.title, function () { putRel(String(x.id)); menu = ''; msg = null; load(); }, '', x.state + (x.step ? ', ' + x.step : ''), r && r.id === x.id]); });
    });
    // what's checked out (decisions/0161 §10): the file, who, why, since when, near expiry; tapping one opens its session
    var co = state && state.checkouts;
    if (co && co.claims && co.claims.length) {
      items.push('Checked out (' + co.claims.length + ')');
      co.claims.forEach(function (c) {
        var t = function (s) { try { return new Date(s * 1000).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short' }); } catch (e) { return ''; } };
        items.push([(c.near ? '⚠ ' : '') + c.what, function () { menu = ''; draw(); window.open(c.session_url || co.url, '_blank', 'noopener'); }, c.near ? 'no' : '',
          (c.kind === 'change' ? 'Change' : 'Add') + ' · session …' + String(c.session).slice(-6) + (c.why ? ' · ' + c.why : '') + ' · since ' + t(c.since) + (c.near ? ' · near expiry' : '')]);
      });
    } else if (co && co.ok) items.push(['Nothing checked out', function () { menu = ''; draw(); window.open(co.url, '_blank', 'noopener'); }, '', 'No session is writing a release for any file now.']);

    var S = state && state.staging;
    if (S) {
      var si = [S.line + (S.caught_up ? ' · caught up ' + when(S.caught_up) : '')];
      si.push(['Preview and publish', function () { menu = ''; open = 'stg:pub'; draw(); }, 'go', S.run && S.run.state === 'running' ? 'Publishing now' : (S.preview ? 'Last preview ' + when(S.preview.at) : 'Work out what goes live')]);
      si.push(['Conflicts (' + S.conflicts + ')', function () { menu = ''; open = 'stg:conf'; draw(); }, S.conflicts ? 'no' : '', 'Rows both sides changed: choose']);
      si.push(['Held (' + S.held + ')', function () { menu = ''; open = 'stg:held'; draw(); }, '', 'What didn\'t leave staging']);
      if (S.last) si.push(['To send now', function () { menu = ''; open = 'stg:send'; draw(); }, '', 'Held items of the last publish']);
      if (S.last && new Date(S.last.until).getTime() > Date.now()) si.push(['Roll back the last publish', function (e) {
        menu = ''; draw();
        var b = mount.querySelector('.sm-dd > .sm-b');
        if (window.TvAsk && !TvAsk.gate(b, 'Roll back the whole publish of ' + when(S.last.at) + '? Rows live changed since stay as live has them.', { yes: 'Roll back', danger: true })) return;
        stgAct(b, 'rollback').then(function (j) { stgRun = j.run; open = 'stg:pub'; draw(); });
      }, 'no', 'Until ' + when(S.last.until)]);
      if (S.live_keys && S.live_keys.length) si.push('Payments are off here: a live key is in staging\'s .env (' + S.live_keys.join(', ') + ')');
      if (S.ungated) si.push(S.ungated + ' outside calls in the code skip the gate (System Configuration → Staging lists them)');
      if (!S.mirror) si.push('Staging isn\'t kept caught up yet: until it is, only releases\' code and migrations publish (System Configuration → Staging)');
      right.appendChild(dd('stg', 'Staging', si));
    }
    right.appendChild(dd('rel', 'Releases', items));
    // Upload
    if (state && state.can_upload) {
      var up = el('button', { type: 'button', class: 'sm-b', text: 'Upload', title: 'A release zip goes straight onto staging, and its checks run' });
      var inp = el('input', { type: 'file', accept: '.zip,application/zip', hidden: '', 'data-art': 'off', 'aria-label': 'The release zip' });
      inp.addEventListener('change', function () { var f = inp.files && inp.files[0]; inp.value = ''; if (f) upload(up, f); });
      // a release zip is the site's, not a Gallery item: the device's own file picker (data-art off); any open view closes first
      up.addEventListener('click', function () { open = ''; menu = ''; Array.prototype.forEach.call(mount.querySelectorAll('.sm-panel,.sm-menu'), function (x) { x.remove(); }); inp.click(); });
      right.appendChild(up); right.appendChild(inp);
    }
    if (r) {
      if (r.review) {   // sent for review (Jason, 2026-11-13): UI, UX and Functional, then Publish
        var left = r.review.filter(function (p) { return p[3] !== true; }).length;
        right.appendChild(el('button', { type: 'button', class: 'sm-b' + (left ? ' go' : ''), 'aria-expanded': String(open === 'review'), text: left ? 'Review (' + left + ' to go)' : 'Reviewed ✓', on: function () { open = open === 'review' ? '' : 'review'; menu = ''; draw(); } }));
      }
      right.appendChild(el('button', { type: 'button', class: 'sm-b', 'aria-expanded': String(open === 'changes'), text: 'Changes', on: function () { open = open === 'changes' ? '' : 'changes'; menu = ''; draw(); } }));
      right.appendChild(el('button', { type: 'button', class: 'sm-b', 'aria-expanded': String(open === 'notes'), text: 'Note' + (r.notes.length ? ' (' + r.notes.length + ')' : ''), on: function () { open = open === 'notes' ? '' : 'notes'; menu = ''; draw(); } }));
      var acts = r.reviewed === false ? r.acts.filter(function (a) { return a[0] !== 'publish' && a[0] !== 'schedule'; }) : r.acts;   // Publish opens once all three are approved
      if (acts.length) {
        var pubs = acts.map(function (a) {
          return [a[1], function () {
            menu = '';
            if (a[0] === 'schedule') { open = 'schedule'; draw(); return; }
            if (a[2]) { open = 'confirm:' + a[0] + ':' + a[2] + ':' + a[1]; draw(); return; }
            act(right.querySelector('.sm-dd:last-of-type > .sm-b'), a[0]);
          }, a[2] === 2 ? 'no' : ''];
        });
        right.appendChild(dd('pub', 'Publish', pubs));
      }
    }
    right.appendChild(el('a', { class: 'sm-b', href: r ? r.admin : 'https://traversence.com/admin/config/releases', text: 'Live admin ↗' }));
    bar.appendChild(right);
    mount.appendChild(bar);

    var panel = null;
    if (r && open === 'changes') {
      panel = el('div', { class: 'sm-panel' });
      panel.appendChild(el('p', { style: 'margin:0', text: r.line }));
      if (r.changes && r.changes.length) {   // short items, each with where to look (Jason, 2026-11-15: legible on a phone)
        panel.appendChild(el('h4', { text: 'What it changes (' + r.changes.length + ')' }));
        panel.appendChild(el('ul', {}, r.changes.map(function (c) { return el('li', {}, [c[0], c[1] ? el('small', { style: 'display:block;color:#8A7355', text: c[1] }) : null]); })));
      } else if (r.why) { panel.appendChild(el('h4', { text: 'What it changes' })); panel.appendChild(el('p', { style: 'margin:0;white-space:pre-wrap', text: r.why })); }
      panel.appendChild(el('h4', { text: 'Pages to look at (here, on staging)' }));
      panel.appendChild(el('ul', {}, r.pages.map(function (p) { return el('li', {}, [el('a', { href: p, text: p })]); })));
      panel.appendChild(el('h4', { text: 'Its files (' + r.files.length + ')' + (r.switch ? ' · switch ' + r.switch : ' · no switch: everyone at once') }));
      panel.appendChild(el('ul', { style: 'font:12px ui-monospace,monospace' }, r.files.slice(0, 60).map(function (f) { return el('li', { text: f }); })));
      if (r.checks.length) { panel.appendChild(el('h4', { text: 'Its checks' })); panel.appendChild(el('ul', {}, r.checks.map(function (c) { return el('li', { text: (c.ok === false ? '✗ ' : c.ok ? '✓ ' : '· ') + c.name + ': ' + c.detail }); }))); }
      if (r.replaced && Object.keys(r.replaced).length) { panel.appendChild(el('h4', { text: 'Replaced by a later release on staging' })); panel.appendChild(el('ul', { style: 'font:12px ui-monospace,monospace' }, Object.keys(r.replaced).map(function (f) { return el('li', { text: f + ' → #' + r.replaced[f] }); }))); }
      if (r.stale) panel.appendChild(el('p', { style: 'color:' + C.bad + ';font-weight:600', text: 'Staging was started over from live since this release went on: Publish ▾ → Put it on staging again before publishing.' }));
    }
    if (r && r.review && open === 'review') {
      panel = el('div', { class: 'sm-panel' });
      panel.appendChild(el('p', { style: 'margin:0 0 .4rem', text: 'Use it here on staging, then give each part your verdict. Needs changes takes a note: it\'s kept with the release, the build gets fixed and comes back for review.' }));
      r.review.forEach(function (p) {
        var row = el('div', { style: 'border-top:1px solid #E8DCC2;padding:.5rem 0' });
        var st = p[3] === true ? '✓ Approved' + (p[4] ? ' by ' + p[4] : '') : p[3] === false ? '✗ Needs changes' + (p[5] ? ': ' + p[5] : '') : 'Waiting for you';
        row.appendChild(el('b', { text: p[1] + ' ' })); row.appendChild(el('span', { style: 'color:' + (p[3] === true ? '#2F7D5B' : p[3] === false ? C.bad : '#8A7355'), text: st }));
        row.appendChild(el('div', { style: 'font-size:.8rem;color:#8A7355', text: p[2] }));
        var ta = el('textarea', { rows: '2', 'aria-label': 'What needs changing in ' + p[1], placeholder: 'What needs changing (for Needs changes)', 'data-spell': '', style: 'margin-top:.35rem' });
        row.appendChild(ta);
        row.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Approve ' + p[1], on: function (e) { act(e.currentTarget, 'review', { part: p[0], ok: 1, text: ta.value }).then(function () { open = 'review'; draw(); }); } }));
        row.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Needs changes', on: function (e) { if (!ta.value.trim()) { say('Say what needs changing first.', true, e.currentTarget); drawMsg(); ta.focus(); return; } act(e.currentTarget, 'review', { part: p[0], ok: 0, text: ta.value }).then(function () { open = 'review'; draw(); }); } }));
        panel.appendChild(row);
      });
      if (r.reviewed) panel.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Preview and publish staging', on: function () { open = 'stg:pub'; draw(); } }));
    }
    if (r && open === 'notes') {
      panel = el('div', { class: 'sm-panel' });
      var ta = el('textarea', { rows: '3', 'aria-label': 'What you saw on this page', placeholder: 'What you saw on this page (' + location.pathname + ')', 'data-spell': '' });
      panel.appendChild(ta);
      panel.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Save the note', on: function (e) { if (!ta.value.trim()) { say('Write what you saw first.', true, e.currentTarget); drawMsg(); return; } act(e.currentTarget, 'note', { text: ta.value }); } }));
      if (r.notes.length) { panel.appendChild(el('h4', { text: 'Notes so far' })); panel.appendChild(el('ul', {}, r.notes.map(function (n) { return el('li', { text: n.msg }); }))); }
      setTimeout(function () { ta.focus(); }, 30);
    }
    if (r && open === 'schedule') {
      panel = el('div', { class: 'sm-panel' });
      var when = el('input', { type: 'datetime-local', 'aria-label': 'When it goes live' });
      panel.appendChild(el('p', { style: 'margin:0 0 6px', text: 'When should it go live? (your time zone: ' + (tz || 'this device\'s') + ')' + (r.state === 'staged' ? ' Scheduling it is its sign-off.' : '') }));
      panel.appendChild(when);
      panel.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Schedule it', on: function (e) { if (!when.value) { say('Choose the date and time first.', true, e.currentTarget); drawMsg(); return; } act(e.currentTarget, 'schedule', { at: when.value }); } }));
      panel.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Cancel', on: function () { open = ''; draw(); } }));
    }
    if (r && open.indexOf('confirm:') === 0) {
      var p = open.split(':'), what = p[1], danger = p[2] === '2', label = p.slice(3).join(':');
      var ask = { publish: 'Publish it to the live site now?' + (r.state === 'staged' ? ' That signs it off.' : '') + (r.switch ? ' It goes to staff and test accounts first.' : ' It has no switch: everyone gets it at once.'),
        next: r.step === 1 ? 'Turn it on for a share of members as well?' : 'Turn it on for everyone?', off: 'Turn it off for everyone, now? Its files stay; Roll back takes them out.',
        back: 'Put the previous copy of every file back on the live site, now?', withdraw: 'Withdraw it? It won\'t go live.' }[what] || label + '?';
      panel = el('div', { class: 'sm-panel' });
      panel.appendChild(el('p', { style: 'margin:0', text: ask }));
      panel.appendChild(el('button', { type: 'button', class: 'sm-b go', style: danger ? 'background:' + C.bad + ';border-color:' + C.bad : '', text: label, on: function (e) { act(e.currentTarget, what); } }));
      panel.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Cancel', on: function () { open = ''; draw(); } }));
    }
    if (open.indexOf('stg:') === 0) panel = stgPanel(open.slice(4));
    if (panel) mount.appendChild(panel);
    drawMsg();
  }
  document.addEventListener('click', function (e) { if (menu && e.target.isConnected && !mount.contains(e.target)) { menu = ''; draw(); } });   // (a button the bar just redrew isn't outside it)
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && (menu || open)) { menu = ''; open = ''; draw(); } });
  draw();
  load();
  // it keeps itself current (Jason, 2026-11-13): a build that arrives, a review or a publish shows without reloading the
  // page. Every minute while the page is in view (not while a menu or a view is open, or a button is busy), and at once on
  // coming back to the tab.
  function quiet() { return !menu && !open && !mount.querySelector('[aria-busy=true]') && document.visibilityState === 'visible'; }
  setInterval(function () { if (quiet()) load(); }, 60000);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible' && !menu && !open) load(); });
})();
