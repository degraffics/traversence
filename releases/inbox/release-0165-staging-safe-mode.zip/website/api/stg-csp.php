<?php
// website/api/stg-csp.php — staging's Content Security Policy reports (decisions/0165 §1): what a page on staging tried to
// load and the policy blocked, kept in the held ledger (kind csp) so a third-party script that would track or report out
// shows in Held. Staging only; on live it's not there (404). Nothing is sent anywhere.
declare(strict_types=1);

require_once __DIR__ . '/../../app/lib/Staging.php';
if (!Staging::here() || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(404); exit; }
$j = json_decode((string) file_get_contents('php://input', false, null, 0, 20000), true);
$r = is_array($j) ? (array) ($j['csp-report'] ?? $j) : [];
$blocked = mb_substr((string) ($r['blocked-uri'] ?? $r['blockedURL'] ?? ''), 0, 190);
$page = mb_substr((string) parse_url((string) ($r['document-uri'] ?? $r['documentURL'] ?? ''), PHP_URL_PATH), 0, 200);
if ($blocked !== '') {
    require_once __DIR__ . '/../../app/lib/StagingGate.php';
    StagingGate::record('csp', StagingGate::serviceOf($blocked), $blocked, 'Blocked on ' . $page . ' (' . mb_substr((string) ($r['violated-directive'] ?? $r['effectiveDirective'] ?? ''), 0, 40) . ')', '', 'not allowed to load on staging (its Content Security Policy)');
}
http_response_code(204);
