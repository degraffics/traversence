-- The crawler's calls by outside service (decisions/0160 note 2026-11-13: "the crawler reports by service"): each run's
-- calls, failures and last error per host and capture task, filed under the service's card (OutsideServices). Safe to
-- run twice.
CREATE TABLE IF NOT EXISTS crawl_service_calls (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  run_id INT UNSIGNED NOT NULL,
  at DATETIME NOT NULL,
  task VARCHAR(40) NOT NULL DEFAULT '',
  host VARCHAR(190) NOT NULL,
  service VARCHAR(40) NOT NULL,
  calls INT UNSIGNED NOT NULL DEFAULT 0,
  fails INT UNSIGNED NOT NULL DEFAULT 0,
  last_error VARCHAR(255) DEFAULT NULL,
  KEY idx_csc_service (service, at),
  KEY idx_csc_run (run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
