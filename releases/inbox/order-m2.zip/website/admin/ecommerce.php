<?php
// admin/ecommerce.php — E-Commerce, an area of the admin dashboard (decisions/0098, 0099): everything Traversence sells.
//   Orders    what needs a person first (card disputes, waiting for payment), then every order; each opens its page.
//             Under them, what's in shoppers' carts (Grant gives a GO Code free). Test orders hide in Production.
//             (admin/order.php: Fix, Credit, Refund, Chargeback, the history and the money)
//             One list for both kinds (Jason, 2026-10-16): the site's checkout and the orders our team builds for a client
//             (admin/client-order.php, decisions/0101); those still being built or out for review are listed first.
//   Products  the catalog (admin/products.php)
//   Payments  QuickBooks: the connection, its health and log (admin/quickbooks.php)
//   Plans     subscriptions (decisions/0108): what needs a person (declined cards, trials ending), monthly revenue,
//             every plan, start a trial, end one or stop it at its renewal; the daily run's last result
//   Reports   this month and last: sales, tax, refunds, credits, disputes, net
// QuickBooks keeps the books; this keeps the operations record. Admins only: it's money.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/Orders.php';
require_once __DIR__ . '/../../app/lib/QrIssue.php';
require_once __DIR__ . '/../../app/lib/Qr.php';
require_once __DIR__ . '/../../app/lib/Products.php';
require_once __DIR__ . '/../../app/lib/QuickBooksPay.php';
require_once __DIR__ . '/../../app/lib/ClientOrders.php';
require_once __DIR__ . '/../../app/lib/Billing.php';

$pdo = Database::connection();
tv_crawler_require_admin($pdo);
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$usd = fn ($c) => Orders::usd((int) $c);
$ready = Orders::ready($pdo) && QrIssue::ready($pdo);

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'grant') {
            QrIssue::grant($pdo, (int) $me['id'], (int) ($_POST['id'] ?? 0));
            tv_crawler_flash(['type' => 'ok', 'text' => 'Granted: it\'s in their GO Codes now, no charge.']);
        } elseif ($do === 'check_qb') {   // a missed webhook: ask QuickBooks for its recent refunds and credit memos
            $n = Orders::checkQuickBooks($pdo);
            tv_crawler_flash(['type' => 'ok', 'text' => 'Checked QuickBooks: ' . $n['recorded'] . ' recorded on their orders, ' . $n['inbox'] . ' new for you to place.']);
        } elseif (in_array($do, ['sub_trial', 'sub_end', 'sub_stop', 'sub_resume'], true)) {
            if ($do === 'sub_trial') {
                $t = trim((string) ($_POST['who'] ?? ''));
                $lid = ctype_digit($t) ? (int) $t : 0;
                if (!$lid && $t !== '') { $st = $pdo->prepare('SELECT id FROM entities WHERE name = ? ORDER BY id LIMIT 2'); $st->execute([$t]); $ids = $st->fetchAll(PDO::FETCH_COLUMN); if (count($ids) > 1) throw new RuntimeException('More than one listing has that name: use its number.'); $lid = (int) ($ids[0] ?? 0); }
                if (!$lid) throw new RuntimeException('Enter the listing\'s number or exact name.');
                Billing::trial($pdo, (int) $me['id'], 'listing', $lid, (string) ($_POST['plan'] ?? ''), (int) ($_POST['days'] ?? 30));
                tv_crawler_flash(['type' => 'ok', 'text' => 'Trial started. The owner has an email with how to keep it.']);
            } else {
                $sid = (int) ($_POST['id'] ?? 0);
                if ($do === 'sub_end') Billing::endNow($pdo, $sid, 'ended by our team');
                else Billing::cancelAtEnd($pdo, $sid, $do === 'sub_stop');
                tv_crawler_flash(['type' => 'ok', 'text' => $do === 'sub_end' ? 'Ended: it\'s on the free plan now.' : ($do === 'sub_stop' ? 'It stops at its renewal.' : 'It renews as usual.')]);
            }
            header('Location: /admin/ecommerce.php#plans', true, 303); exit;
        } elseif ($do === 'dismiss') {
            Orders::inboxDismiss($pdo, (int) ($_POST['id'] ?? 0), (int) $me['id']);
            tv_crawler_flash(['type' => 'ok', 'text' => 'Set aside: not for one of our orders.']);
        }
    } catch (Throwable $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    header('Location: /admin/ecommerce.php#' . (str_starts_with((string) ($_POST['do'] ?? ''), 'sub_') ? 'plans' : 'orders'), true, 303); exit;
}

// the title is the section that's open (Orders, Products…), with where it sits top right (Jason, 2026-10-16)
tv_admin_start('ecommerce', 'Orders', '', null, [['E-Commerce', '/admin/ecommerce.php'], ['Orders', null]]);
require_once __DIR__ . '/../../app/lib/QuickBooksPay.php';
if (QuickBooksPay::env() === 'sandbox') echo '<p class="hb-card hot tv-bleed" style="margin-top:.5rem"><b>Sandbox (testing) is on.</b> Checkout is open to our team only and orders go to the QuickBooks sandbox company. <a class="hb-go" href="#payments" data-hgo="payments">Switch back under Payments</a></p>';
if (!$ready) { echo '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2026-12-02_orders.sql</code> in phpMyAdmin first (after the GO Codes migrations).</p></div>'; tv_admin_end(); return; }
$flash = tv_crawler_flash();

// ---- orders -----------------------------------------------------------------------------------------------------------
$q = trim((string) ($_GET['q'] ?? ''));
$where = "o.status <> 'void'"; $args = [];
if ($q !== '') {
    if (preg_match('/^#?(\d+)$/', $q, $m)) { $where = 'o.id = ?'; $args = [(int) $m[1]]; }
    else { $where = '(o.bill_email LIKE ? OR o.bill_name LIKE ? OR o.invoice_no = ?)'; $args = ['%' . $q . '%', '%' . $q . '%', $q]; }
}
// client orders join the list once approved (drafts and those out for review are listed above it), and in
// Production the tests (orders made in the sandbox) are left out unless asked for
$coCol = Products::ready($pdo);
if ($coCol && $q === '') $where .= " AND NOT (o.created_by IS NOT NULL AND o.status IN ('draft', 'sent'))";
$env = QuickBooksPay::env();
$testWhere = Orders::hasCol($pdo, 'qb_env') && $env !== 'mock' ? " AND o.qb_env IS NOT NULL AND o.qb_env <> " . $pdo->quote($env) : '';
$tests = $testWhere !== '' ? (int) $pdo->query("SELECT COUNT(*) FROM orders o WHERE o.status <> 'void'" . $testWhere)->fetchColumn() : 0;
$showTests = !empty($_GET['tests']) || $q !== '';
if ($testWhere !== '' && !$showTests) $where .= ' AND NOT (o.qb_env IS NOT NULL AND o.qb_env <> ' . $pdo->quote($env) . ')';
$st = $pdo->prepare("SELECT o.*, (SELECT COUNT(*) FROM order_lines l WHERE l.order_id = o.id) AS nlines FROM orders o WHERE $where
                     ORDER BY (o.status = 'disputed') DESC, (o.status = 'pending') DESC, o.id DESC LIMIT 150");
$st->execute($args);
$orders = $st->fetchAll(PDO::FETCH_ASSOC);
$inbox = Orders::inbox($pdo);
$candOrder = function (int $id) use ($pdo): ?array { static $c = []; if (!array_key_exists($id, $c)) { $st = $pdo->prepare('SELECT id, paid_at FROM orders WHERE id = ?'); $st->execute([$id]); $c[$id] = $st->fetch(PDO::FETCH_ASSOC) ?: null; } return $c[$id]; };
$attention = count(array_filter($orders, fn ($o) => in_array($o['status'], ['disputed', 'pending'], true))) + count($inbox);
// a client order's items each have their own status: the list sums them up ("2 In Production · 1 Shipped")
$itemSum = [];
$coIds = array_map(fn ($o) => (int) $o['id'], array_filter($orders, fn ($o) => (int) ($o['created_by'] ?? 0) > 0));
if ($coIds && ClientOrders::hasItems($pdo)) {
    $byId = array_column($orders, null, 'id');
    foreach ($pdo->query('SELECT order_id, item_status, product FROM order_lines WHERE order_id IN (' . implode(',', $coIds) . ')')->fetchAll(PDO::FETCH_ASSOC) as $r) {
        if ($r['product'] === 'shipping') continue;
        $lab = ClientOrders::statusLabel(ClientOrders::itemStatus($byId[$r['order_id']], $r));
        $itemSum[(int) $r['order_id']][$lab] = ($itemSum[(int) $r['order_id']][$lab] ?? 0) + 1;
    }
}
$open = fn (array $o) => (int) ($o['created_by'] ?? 0) > 0 ? '/admin/backoffice/orders/' . (int) $o['id'] : '/admin/order.php?id=' . (int) $o['id'];   // a client's order opens its own page (proofs, production, payments)
$pill = fn (string $s) => '<span class="hb-pill' . (in_array($s, ['paid'], true) ? ' ok' : (in_array($s, ['disputed', 'refunded'], true) ? ' red' : '')) . '">' . $e(Orders::STATUS[$s] ?? $s) . '</span>';

ob_start(); ?>
<p class="hb-intro">Every order, from the site's checkout and the ones you build for a client, what needs a person first. Fix it first, then a credit; a refund only when neither works.</p>
<!--building-->
<?php if ($flash): ?><p class="hb-card tv-bleed" role="status" data-tv-flash="<?= $e($flash['type'] ?? '') ?>" style="background:<?= ($flash['type'] ?? '') === 'error' ? '#FEE2E2' : '#DCFCE7' ?>"><?= $e($flash['text'] ?? '') ?></p><?php endif; ?>
<?php if ($inbox): ?>
<h2 class="hb-h" style="margin-top:.3rem">From QuickBooks: which order?</h2>
<p class="hb-intro">Refunds and credit memos made in QuickBooks that couldn't be placed on their order by themselves.</p>
<div class="hb-card hot tv-bleed" style="margin-top:.4rem">
  <?php foreach ($inbox as $i): $cands = array_filter(array_map('intval', explode(',', (string) $i['candidates']))); $exact = array_filter($cands, fn ($c) => Orders::refundable($pdo, $c) === (int) $i['amount_cents']); ?>
  <div class="hb-row" style="align-items:flex-start">
    <div style="min-width:0;flex:1"><b><?= $i['kind'] === 'refund' ? 'Refund Receipt' : 'Credit memo' ?> <?= $e($i['qb_ref']) ?> · <?= $usd($i['amount_cents']) ?></b>
      <small><?= $e($i['customer'] ?: 'Customer not named') ?><?= $i['txn_date'] ? ' · ' . $e(date('M j, Y', strtotime((string) $i['txn_date']))) : '' ?> · <?= $e($i['why']) ?></small>
      <small><?php if ($cands): ?>Could be: <?php foreach ($cands as $k => $c): ?><?= $k ? ', ' : '' ?><a class="underline text-[#92400E]" href="/admin/order.php?id=<?= $c ?>&amp;inbox=<?= (int) $i['id'] ?>">order #<?= $c ?></a><?php $co = $candOrder($c); if ($co): $left = Orders::refundable($pdo, $c); ?> <span<?= count($exact) === 1 && $left === (int) $i['amount_cents'] ? ' style="color:#166534;font-weight:600" title="Exactly the refund\'s amount left"' : '' ?>>(<?= $co['paid_at'] ? 'paid ' . $e(date('M j, g:i a', strtotime((string) $co['paid_at']))) . ', ' : '' ?><?= $usd($left) ?> left)</span><?php endif; ?><?php endforeach; ?><?php endif; ?>
        <form method="get" action="/admin/order.php" style="display:inline-flex;gap:.3rem;margin-left:.3rem"><input type="hidden" name="inbox" value="<?= (int) $i['id'] ?>"><input class="hb-in" name="id" inputmode="numeric" placeholder="Order #" aria-label="Order number" style="width:6rem;padding:.2rem .4rem;font-size:.8rem"><button class="hb-b" style="padding:.2rem .5rem">Open</button></form></small>
    </div>
    <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $i['id'] ?>"><button class="hb-b" name="do" value="dismiss" data-confirm="Not for one of our orders? It's set aside, nothing changes." data-yes="Set it aside">Not ours</button></form>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<form method="post" style="margin:.4rem 0"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><button class="hb-b" name="do" value="check_qb" title="Refunds and credit memos made in QuickBooks are recorded when QuickBooks tells us; this asks it for the last 45 days, in case a message was missed">Check QuickBooks for refunds</button></form>
<form class="ec-f" method="get" action="/admin/ecommerce.php#orders"><input class="hb-in" type="search" name="q" value="<?= $e($q) ?>" placeholder="Order #, email, name or invoice number" aria-label="Find an order"><button class="hb-b go">Find</button><?php if ($q !== ''): ?><a class="hb-b" href="/admin/ecommerce.php#orders">All orders</a><?php endif; ?></form>
<?php if ($tests && $q === ''): ?><p style="margin:.35rem 0 0;font-size:.88rem;color:#8A7355"><?= $showTests ? 'Showing' : 'Hiding' ?> <?= $tests ?> test order<?= $tests === 1 ? '' : 's' ?> (made in the QuickBooks <?= $env === 'sandbox' ? 'production company' : 'sandbox' ?>). <a class="hb-go" href="/admin/ecommerce.php<?= $showTests ? '' : '?tests=1' ?>#orders"><?= $showTests ? 'Hide them' : 'Show them' ?></a></p><?php endif; ?>
<div class="hb-card tv-bleed" style="margin-top:.5rem">
  <?php if (!$orders): ?><p class="text-sm"><?= $q !== '' ? 'No order matches that.' : 'No orders yet.' ?></p><?php endif; ?>
  <?php foreach ($orders as $o): ?>
  <div class="hb-row">
    <div style="min-width:0;flex:1">
      <a class="hb-nm" href="<?= $open($o) ?>">Order #<?= $e(Orders::no($o)) ?></a><?= $pill((string) $o['status']) ?><?= (int) ($o['created_by'] ?? 0) > 0 ? '<span class="hb-pill" title="Built by our team for this client">For a client</span>' . (isset($itemSum[(int) $o['id']]) ? '<span class="hb-pill">' . $e(implode(' · ', array_map(fn ($k, $n) => $n . ' ' . $k, array_keys($itemSum[(int) $o['id']]), $itemSum[(int) $o['id']]))) . '</span>' : '') : '' ?><?= ($o['qb_env'] ?? '') === 'sandbox' ? '<span class="hb-pill" title="Made in the QuickBooks sandbox: a test">Test</span>' : '' ?>
      <small><?= $e($o['bill_name'] ?: 'No name') ?> · <?= $e($o['bill_email']) ?><?= $o['user_id'] ? '' : ' (guest)' ?></small>
      <small><?= (int) $o['nlines'] ?> item<?= (int) $o['nlines'] === 1 ? '' : 's' ?> · <?= $usd($o['total_cents']) ?><?= $o['invoice_no'] ? ' · invoice ' . $e($o['invoice_no']) : '' ?> · <?= $e(date('M j, Y', strtotime((string) ($o['paid_at'] ?: $o['created_at'])))) ?></small>
    </div>
    <a class="hb-b" href="<?= $open($o) ?>">Open</a>
  </div>
  <?php endforeach; ?>
</div>
<?php $ordersHtml = (string) ob_get_clean();

// ---- carts ------------------------------------------------------------------------------------------------------------
// GO Codes people put in their cart on the site and haven't paid for yet (a client order's codes are on its order)
$carts = $pdo->query("SELECT q.id, q.type, q.title, q.status, q.created_at, u.email, u.display_name FROM qr_issued q LEFT JOIN users u ON u.id = q.user_id
                      WHERE q.status IN ('cart', 'pending')" . ($coCol ? ' AND (q.order_id IS NULL OR q.order_id NOT IN (SELECT id FROM orders WHERE created_by IS NOT NULL))' : '') . " ORDER BY q.id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
ob_start(); ?>
<details class="ec-carts"><summary class="hb-h" style="cursor:pointer">In shoppers' carts (<?= count($carts) ?>)</summary>
<p class="hb-intro">GO Codes people added to their cart on the site and haven't checked out. Grant gives one free (it's issued to them at once, no charge, and noted).</p>
<div class="hb-card tv-bleed" style="margin-top:.5rem">
  <?php if (!$carts): ?><p class="text-sm">Nothing waiting in anyone's cart.</p><?php endif; ?>
  <?php foreach ($carts as $c): ?>
  <div class="hb-row">
    <div style="min-width:0;flex:1"><b><?= $e($c['title'] ?: 'Untitled') ?></b> <span class="hb-pill"><?= $e(Qr::TYPES[$c['type']] ?? $c['type']) ?></span>
      <small><?= $e(($c['display_name'] ?? '') ?: ($c['email'] ?? '') ?: 'a guest') ?> · <?= $c['status'] === 'pending' ? 'checking out' : 'in the cart' ?> since <?= $e(date('M j', strtotime((string) $c['created_at']))) ?></small></div>
    <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><button class="hb-b" name="do" value="grant" data-confirm="Give this code to them free?" data-yes="Grant it">Grant</button></form>
  </div>
  <?php endforeach; ?>
</div>
</details>
<?php $ordersHtml .= (string) ob_get_clean();

// ---- client orders (decisions/0101): built by our team, reviewed and approved by the client ---------------------------
$coReady = Products::ready($pdo);
$clients = $coReady ? $pdo->query("SELECT o.*, (SELECT COUNT(*) FROM order_lines l WHERE l.order_id = o.id) AS nlines FROM orders o WHERE o.created_by IS NOT NULL AND o.status <> 'void'
                                   ORDER BY (o.review = 'changes') DESC, FIELD(o.status, 'draft', 'sent', 'pending', 'paid') DESC, o.id DESC LIMIT 150")->fetchAll(PDO::FETCH_ASSOC) : [];
$coState = function (array $o) use ($pdo): array {
    $m = Orders::money($pdo, (int) $o['id']);
    return match (true) {
        $o['status'] === 'draft' => ['Draft', ''],
        $o['status'] === 'sent' && ClientOrders::expired($o) => ['Link expired', 'red'],
        $o['status'] === 'sent' && $o['review'] === 'changes' => ['Changes requested', 'red'],
        $o['status'] === 'sent' => ['Waiting on the client', ''],
        $o['status'] === 'pending' && $m['paid'] > 0 => ['Deposit paid', ''],
        $o['status'] === 'pending' => ['Approved, not paid', ''],
        default => [(Orders::STATUS[$o['status']] ?? $o['status']) . ($o['stage'] !== '' ? ' · ' . (ClientOrders::STAGES[$o['stage']] ?? $o['stage']) : ''), $o['status'] === 'paid' ? 'ok' : ''],
    };
};
$coAttention = count(array_filter($clients, fn ($o) => $o['review'] === 'changes' || ($o['status'] === 'paid' && in_array($o['stage'], ['production', 'ordered'], true))));
$building = array_values(array_filter($clients, fn ($o) => in_array($o['status'], ['draft', 'sent'], true)));
ob_start(); ?>
<p style="margin:.5rem 0 0;display:flex;gap:.4rem;flex-wrap:wrap"><?php if ($coReady): ?><a class="hb-b go" href="/admin/client-order.php?new=1">New order</a><?php endif; ?></p>
<?php if ($building): ?>
<h2 class="hb-h">Being built or with the client</h2>
<p class="hb-intro">Orders you're putting together for a client, and those out for them to review and approve. Once approved they join the list below.</p>
<div class="hb-card tv-bleed" style="margin-top:.4rem">
  <?php foreach ($building as $o): [$lab, $cls] = $coState($o); ?>
  <div class="hb-row">
    <div style="min-width:0;flex:1">
      <a class="hb-nm" href="/admin/backoffice/orders/<?= (int) $o['id'] ?>"><?= $e($o['bill_name'] ?: 'Order #' . Orders::no($o)) ?><?= $o['client_company'] !== '' ? ' · ' . $e($o['client_company']) : '' ?></a><span class="hb-pill <?= $e($cls) ?>"><?= $e($lab) ?></span>
      <small>Order #<?= $e(Orders::no($o)) ?> · <?= (int) $o['nlines'] ?> line<?= (int) $o['nlines'] === 1 ? '' : 's' ?> · <?= $usd($o['subtotal_cents']) ?><?= $o['pay_mode'] === 'outside' ? '' : ' before tax' ?> · <?= $e(date('M j', strtotime((string) ($o['sent_at'] ?: $o['created_at'])))) ?></small>
    </div>
    <a class="hb-b" href="/admin/backoffice/orders/<?= (int) $o['id'] ?>">Open</a>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?php $ordersHtml = str_replace('<!--building-->', (string) ob_get_clean(), $ordersHtml);

// ---- reports ----------------------------------------------------------------------------------------------------------
$period = function (string $from, string $to) use ($pdo): array {
    $real = Orders::hasCol($pdo, 'qb_env') ? " AND order_id IN (SELECT id FROM orders WHERE qb_env <> 'sandbox')" : '';   // tests stay out
    $st = $pdo->prepare('SELECT kind, COUNT(*) AS n, COALESCE(SUM(amount_cents), 0) AS c FROM order_ledger WHERE created_at >= ? AND created_at < ?' . $real . ' GROUP BY kind');
    $st->execute([$from, $to]);
    $k = array_fill_keys(array_keys(Orders::KINDS), ['n' => 0, 'c' => 0]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $k[$r['kind']] = ['n' => (int) $r['n'], 'c' => (int) $r['c']];
    $st = $pdo->prepare("SELECT COALESCE(SUM(tax_cents), 0) FROM orders WHERE paid_at >= ? AND paid_at < ? AND status <> 'void'" . (Orders::hasCol($pdo, 'qb_env') ? " AND qb_env <> 'sandbox'" : ''));
    $st->execute([$from, $to]);
    $k['tax'] = (int) $st->fetchColumn();
    $k['cancelled'] = 0;   // payments recorded here and never processed, taken off in the period (Cancel the record, M2)
    try { $st = $pdo->prepare('SELECT COALESCE(SUM(amount_cents), 0) FROM order_payment_cancels WHERE created_at >= ? AND created_at < ?' . (Orders::hasCol($pdo, 'qb_env') ? " AND order_id IN (SELECT id FROM orders WHERE qb_env <> 'sandbox')" : '')); $st->execute([$from, $to]); $k['cancelled'] = (int) $st->fetchColumn(); } catch (Throwable $x) {}
    $k['net'] = $k['charge']['c'] + $k['deposit']['c'] - $k['refund']['c'] - $k['chargeback']['c'] + $k['chargeback_reversed']['c'] - $k['cancelled'];
    return $k;
};
$m0 = date('Y-m-01'); $m1 = date('Y-m-01', strtotime($m0 . ' +1 month')); $mp = date('Y-m-01', strtotime($m0 . ' -1 month'));
ob_start(); ?>
<p class="hb-intro">From the order ledger. Sales include tax collected for the state; QuickBooks has the books (payment fees, cost of goods and what's paid out).</p>
<?php foreach ([[date('F Y'), $period($m0, $m1)], [date('F Y', strtotime($mp)), $period($mp, $m0)]] as [$label, $k]): ?>
<h2 class="hb-h"><?= $e($label) ?></h2>
<div class="hb-grid">
  <div class="hb-card tv-bleed"><div class="num"><?= $usd($k['charge']['c'] + $k['deposit']['c']) ?></div><div class="lab"><?= $k['charge']['n'] ?> paid order<?= $k['charge']['n'] === 1 ? '' : 's' ?> (<?= $usd($k['tax']) ?> of it tax)</div></div>
  <div class="hb-card tv-bleed"><div class="num"><?= $usd($k['refund']['c']) ?></div><div class="lab"><?= $k['refund']['n'] ?> refund<?= $k['refund']['n'] === 1 ? '' : 's' ?></div></div>
  <div class="hb-card tv-bleed"><div class="num"><?= $usd($k['credit_issued']['c']) ?></div><div class="lab"><?= $k['credit_issued']['n'] ?> credit<?= $k['credit_issued']['n'] === 1 ? '' : 's' ?> given</div></div>
  <div class="hb-card tv-bleed"><div class="num"><?= $usd($k['chargeback']['c'] - $k['chargeback_reversed']['c']) ?></div><div class="lab"><?= $k['chargeback']['n'] ?> card dispute<?= $k['chargeback']['n'] === 1 ? '' : 's' ?> (<?= $k['chargeback_reversed']['n'] ?> won)</div></div>
  <div class="hb-card tv-bleed hot"><div class="num"><?= $usd($k['net']) ?></div><div class="lab">kept, after refunds and disputes</div></div>
</div>
<?php endforeach; ?>
<?php $reportsHtml = (string) ob_get_clean();

// ---- plans (subscriptions) ---------------------------------------------------------------------------------------------
$plansHtml = ''; $plansBadge = 0;
if (Billing::ready($pdo)) {
    $subs = $pdo->query("SELECT s.*, COALESCE(e.name, u.display_name, u.email) AS who FROM subscriptions s
        LEFT JOIN entities e ON s.owner_type = 'listing' AND e.id = s.owner_id LEFT JOIN users u ON s.owner_type = 'user' AND u.id = s.owner_id
        WHERE s.status <> 'ended' ORDER BY FIELD(s.status, 'past_due', 'trial', 'active'), s.period_end LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
    $packs = [];
    foreach ($pdo->query("SELECT a.sub_id, a.addon, a.qty FROM subscription_addons a JOIN subscriptions s ON s.id = a.sub_id WHERE s.status <> 'ended'") as $a) $packs[(int) $a['sub_id']][] = $a;
    $mrr = 0; $cnt = ['active' => 0, 'trial' => 0, 'past_due' => 0]; $soon = date('Y-m-d', strtotime('+7 days'));
    foreach ($subs as $x) {
        $cnt[$x['status']] = ($cnt[$x['status']] ?? 0) + 1;
        if ($x['status'] === 'trial') continue;
        $mrr += $x['cycle'] === 'year' ? (int) round($x['price_cents'] / 12) : (int) $x['price_cents'];
        foreach ($packs[(int) $x['id']] ?? [] as $a) $mrr += (Billing::ADDONS[$a['addon']][1] ?? 0) * (int) $a['qty'];
    }
    $plansBadge = $cnt['past_due'] + count(array_filter($subs, fn ($x) => $x['status'] === 'trial' && $x['trial_ends'] <= $soon));
    $run = @json_decode((string) @file_get_contents(__DIR__ . '/../../app/storage/billing_tick.json'), true) ?: null;
    $hid = fn ($n, $v) => '<input type="hidden" name="' . $n . '" value="' . $e($v) . '">';
    ob_start(); ?>
<p class="hb-intro">Plans renew on their own each night (<code>app/scripts/billing_tick.php</code>): a declined card is tried again after 3 and 7 days, then the plan ends on Free; trials end on Free unless the owner keeps them. <?= $run ? 'Last run ' . $e(date('M j, g:i a', (int) $run['at'])) . ': ' . (int) $run['renewed'] . ' renewed, ' . (int) $run['retry'] . ' declined, ' . (int) $run['ended'] . ' ended, ' . (int) $run['reminders'] . ' reminders.' : '<b>It hasn\'t run yet:</b> add it in cPanel → Cron Jobs.' ?></p>
<div class="hb-grid">
  <div class="hb-card tv-bleed hot"><div class="num"><?= $usd($mrr) ?></div><div class="lab">a month from <?= $cnt['active'] + $cnt['past_due'] ?> paid plan<?= $cnt['active'] + $cnt['past_due'] === 1 ? '' : 's' ?> (yearly counted by the month)</div></div>
  <div class="hb-card tv-bleed"><div class="num"><?= $cnt['trial'] ?></div><div class="lab">on a trial</div></div>
  <div class="hb-card tv-bleed"><div class="num"><?= $cnt['past_due'] ?></div><div class="lab">declined, being tried again</div></div>
</div>
<h2 class="hb-h">Start a trial</h2>
<form method="post" class="ec-f"><?= $hid('csrf', $csrf) ?>
  <input class="hb-in" name="who" placeholder="Listing number or exact name" aria-label="Listing" required>
  <select class="hb-in" name="plan" aria-label="Plan" style="flex:0 1 12rem"><?php foreach (Billing::PLANS as $k => $p) if ($p[1] === 'listing' && $p[2] > 0): ?><option value="<?= $e($k) ?>"><?= $e($p[0]) ?></option><?php endif; ?></select>
  <select class="hb-in" name="days" aria-label="Days" style="flex:0 1 7rem"><?php foreach (Billing::TRIAL_DAYS as $d): ?><option value="<?= $d ?>"><?= $d ?> days</option><?php endforeach; ?></select>
  <button class="hb-b go" name="do" value="sub_trial">Start trial</button>
</form>
<h2 class="hb-h">Plans</h2>
<div class="hb-card tv-bleed">
  <?php if (!$subs): ?><p class="text-sm">No plans yet.</p><?php endif; ?>
  <?php foreach ($subs as $x): $nm = Billing::PLANS[$x['plan']][0] ?? $x['plan']; ?>
  <div class="hb-row">
    <div style="min-width:0;flex:1">
      <?= $x['owner_type'] === 'listing' ? '<a class="hb-nm" href="/admin/listing-edit.php?id=' . (int) $x['owner_id'] . '">' . $e($x['who'] ?: 'Listing #' . $x['owner_id']) . '</a>' : '<span class="hb-nm">' . $e($x['who'] ?: 'Member #' . $x['owner_id']) . '</span><span class="hb-pill">Personal</span>' ?>
      <span class="hb-pill"><?= $e(['past_due' => 'Declined', 'trial' => 'Trial', 'active' => 'Active'][$x['status']] ?? $x['status']) ?></span>
      <small><?= $e($nm) ?> · <?= $x['status'] === 'trial' ? 'free until ' . $e(date('M j, Y', strtotime((string) $x['trial_ends']))) : $usd($x['price_cents']) . ($x['cycle'] === 'year' ? ' a year' : ' a month') . ' · ' . ($x['cancel_at_end'] ? 'stops ' : 'renews ') . $e(date('M j, Y', strtotime((string) $x['period_end']))) ?><?= $x['next_plan'] ? ' · then ' . $e(Billing::PLANS[$x['next_plan']][0] ?? $x['next_plan']) : '' ?></small>
      <small><?= $x['card_label'] ? $e($x['card_label']) : 'No card' ?><?= $x['status'] === 'past_due' ? ' · declined ' . (int) $x['fails'] . '×, next try ' . $e(date('M j', strtotime((string) $x['next_try']))) : '' ?><?= !empty($packs[(int) $x['id']]) ? ' · ' . $e(implode(', ', array_map(fn ($a) => (Billing::ADDONS[$a['addon']][0] ?? $a['addon']) . ((int) $a['qty'] > 1 ? ' ×' . $a['qty'] : ''), $packs[(int) $x['id']]))) : '' ?><?= $x['bill_email'] ? ' · ' . $e($x['bill_email']) : '' ?></small>
    </div>
    <form method="post" style="display:flex;gap:.3rem;flex-wrap:wrap"><?= $hid('csrf', $csrf) . $hid('id', $x['id']) ?>
      <?php if ($x['status'] !== 'trial'): ?><button class="hb-b" name="do" value="<?= $x['cancel_at_end'] ? 'sub_resume' : 'sub_stop' ?>"<?= $x['cancel_at_end'] ? '' : ' data-confirm="Stop it at its renewal? They keep it until then." data-yes="Stop at renewal"' ?>><?= $x['cancel_at_end'] ? 'Renew' : 'Stop at renewal' ?></button><?php endif; ?>
      <button class="hb-b" name="do" value="sub_end" data-confirm="End it now? It goes to Free today, with no refund here (refund a payment from its receipt in QuickBooks if needed)." data-yes="End it" data-danger>End now</button>
    </form>
  </div>
  <?php endforeach; ?>
</div>
<?php $plansHtml = (string) ob_get_clean();
} else $plansHtml = '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2026-12-22_billing.sql</code> in phpMyAdmin first.</p></div>';
?>
<style>
  .ec-f{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.3rem}.ec-f .hb-in{flex:1 1 14rem;width:auto}
</style>
<?php
tv_admin_hub('E-Commerce', [
    'orders' => ['label' => 'Orders', 'html' => $ordersHtml, 'badge' => $attention + $coAttention],
    'products' => ['label' => 'Products', 'url' => '/admin/products.php'],
    'plans' => ['label' => 'Plans', 'html' => $plansHtml, 'badge' => $plansBadge],
    'payments' => ['label' => 'Payments', 'url' => '/admin/quickbooks.php'],
    'reports' => ['label' => 'Reports', 'html' => $reportsHtml],
]);
tv_admin_end();
