<?php
// api/video/_auth.php — shared by the video worker's endpoints (decisions/0153 §8; workers/video in the docs repo).
// Bearer token = VIDEO_WORKER_TOKEN from .env (the same value in the worker's Railway variables). Fails closed when it
// isn't set. Shared hosting often strips the Authorization header, so X-Video-Token works too.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/VideoJobs.php';
require_once __DIR__ . '/../../../app/lib/Store.php';

$pdo = Database::connection();   // reads .env
$expected = (string) (getenv('VIDEO_WORKER_TOKEN') ?: '');
if ($expected === '') { error_log('VIDEO_WORKER_TOKEN is not configured: refusing video worker requests.'); Response::error('Video worker access is not configured on this server.', 503, 'not_configured'); }
$given = preg_match('/^Bearer\s+(.+)$/i', $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '', $mm) ? $mm[1] : (string) ($_SERVER['HTTP_X_VIDEO_TOKEN'] ?? '');
if ($given === '' || !hash_equals($expected, $given)) Response::error('Invalid or missing video worker token.', 401, 'unauthenticated');
require_once __DIR__ . '/../../../app/lib/ControlLedger.php';   // the System Control Board's ledger (decisions/0171 §4)
ControlLedger::begin($pdo, 'video/' . basename((string) ($_SERVER['SCRIPT_FILENAME'] ?? 'unknown'), '.php'));
if (!VideoJobs::ready($pdo)) Response::error('The video tables aren\'t there yet (the migration runs within the hour).', 503, 'not_configured');
