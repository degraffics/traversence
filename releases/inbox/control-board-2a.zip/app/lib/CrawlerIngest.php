<?php

declare(strict_types=1);

require_once __DIR__ . '/TrustScore.php';

/**
 * CrawlerIngest.php
 *
 * Shared logic between scripts/migrate_listings.php (one-time legacy
 * migration) and api/ingest.php (ongoing live crawler endpoint). Both
 * consumers need identical hashing/upsert/cluster-resolution behavior —
 * this class is the single source of truth for that so the two paths
 * can't silently diverge over time.
 */
final class CrawlerIngest
{
    /**
     * Minimal, non-exhaustive starting map from legacy free-text category
     * strings to the Chameleon Filter intent vectors (spec Section 5/3).
     * Anything not matched here defaults to Utility=1/Experience=0 (the
     * safer default for a rural-infrastructure-first platform) AND gets
     * flagged with an `intent_needs_review` metadata key so it surfaces
     * for admin cleanup rather than silently staying wrong forever.
     */
    private const CATEGORY_INTENT_MAP = [
        // Utility
        'contractor'        => ['utility' => true,  'experience' => false],
        'hvac'               => ['utility' => true,  'experience' => false],
        'auto repair'        => ['utility' => true,  'experience' => false],
        'mechanic'           => ['utility' => true,  'experience' => false],
        'hardware'           => ['utility' => true,  'experience' => false],
        'grocery'            => ['utility' => true,  'experience' => false],
        'veterinary'         => ['utility' => true,  'experience' => false],
        'real estate'        => ['utility' => true,  'experience' => false],
        'insurance'          => ['utility' => true,  'experience' => false],
        'medical clinic'     => ['utility' => true,  'experience' => false],
        'pharmacy'           => ['utility' => true,  'experience' => false],
        // Experience
        'hotel'              => ['utility' => false, 'experience' => true],
        'motel'              => ['utility' => false, 'experience' => true],
        'bed and breakfast'  => ['utility' => false, 'experience' => true],
        'museum'             => ['utility' => false, 'experience' => true],
        'outfitter'          => ['utility' => false, 'experience' => true],
        'tour guide'         => ['utility' => false, 'experience' => true],
        'gallery'            => ['utility' => false, 'experience' => true],
        // Hybrid
        'cafe'               => ['utility' => true,  'experience' => true],
        'restaurant'         => ['utility' => true,  'experience' => true],
        'general store'      => ['utility' => true,  'experience' => true],
        'trading post'       => ['utility' => true,  'experience' => true],
    ];

    public static function normalizeZip(string|int $zip): string
    {
        return sprintf('%05d', (int) $zip);
    }

    public static function computeCompositeHash(string $name, string $address, string $zip): string
    {
        $normalized = strtolower(trim($name)) . strtolower(trim($address)) . self::normalizeZip($zip);
        return hash('sha256', $normalized);
    }

    /**
     * @return array{utility:bool,experience:bool,needs_review:bool}
     */
    public static function resolveIntentVectors(?string $category): array
    {
        $key = strtolower(trim((string) $category));
        if ($key !== '' && isset(self::CATEGORY_INTENT_MAP[$key])) {
            return self::CATEGORY_INTENT_MAP[$key] + ['needs_review' => false];
        }
        return ['utility' => true, 'experience' => false, 'needs_review' => true];
    }

    /**
     * Auto-seed grouping limits (decisions/0042, amended 2026-09-28: 20 mi, not 100 — a
     * 100-mile join radius filled clusters in arrival order, e.g. Show Low into St. Johns).
     *
     * An unmatched ZIP joins the nearest cluster in its geo-hub whose center is within
     * AUTO_SEED_RADIUS_MILES, as long as that cluster stays within its size limits:
     *
     *   - never more than AUTO_SEED_TOWN_CAP distinct towns (a metro's many same-named
     *     ZIPs count as one town, so this doesn't split a city);
     *   - and, if population is known for every ZIP involved (zip_coordinates.population,
     *     loaded by api/scripts/import_zip_population.php), a total no higher than
     *     AUTO_SEED_POPULATION_CEILING. Unknown population means the town cap alone.
     *
     * The ceiling is sized for the rural pilot; a metro ZIP alone can pass 50,000, so it
     * needs revisiting before a metro hub (e.g. Phoenix) goes live.
     *
     * If no cluster qualifies, the ZIP becomes the anchor of a new cluster.
     */
    public const AUTO_SEED_RADIUS_MILES = 20.0;
    public const AUTO_SEED_POPULATION_CEILING = 50000;
    public const AUTO_SEED_TOWN_CAP = 5;

    /** null until checked; whether zip_coordinates has the population column yet. */
    private static ?bool $hasPopulationColumn = null;

    /**
     * Finds the micro_cluster for a ZIP (checking primary_zip and the
     * associated_zips JSON array). If none covers it, the ZIP joins the
     * nearest qualifying cluster (see the AUTO_SEED_* limits above), or
     * seeds a new cluster anchored on its own town if none qualifies.
     *
     * LIMITATION (flagged, not silently handled): auto-seeding always
     * targets the single $defaultGeoHubId passed in. That's correct for
     * the pilot, where the crawler only operates within one geo-hub
     * (Ancient Borderlands). Once a second hub/geo-hub goes live, this
     * needs a real way to pick the *correct* geo-hub per incoming
     * record (e.g. a region parameter the crawler config supplies)
     * rather than defaulting blindly — do not extend this function's
     * current behavior across multiple simultaneous geo-hubs without
     * revisiting this.
     */
    public static function resolveMicroClusterId(PDO $pdo, string $zip, int $defaultGeoHubId): int
    {
        // no real ZIP, no area: "" or "0" used to become "00000" and seed an area called "ZIP 00000" (2026-10-14)
        if (!preg_match('/^\d{3,5}$/', trim($zip)) || (int) $zip === 0) return 0;
        $zip = self::normalizeZip($zip);

        $stmt = $pdo->prepare(
            'SELECT id FROM micro_clusters
             WHERE primary_zip = :zip
                OR JSON_CONTAINS(associated_zips, JSON_QUOTE(:zip2))
             LIMIT 1'
        );
        $stmt->execute(['zip' => $zip, 'zip2' => $zip]);
        $existing = $stmt->fetchColumn();
        if ($existing !== false) {
            return (int) $existing;
        }

        $facts = self::zipFacts($pdo, [$zip])[$zip] ?? null;

        // Join the nearest cluster in this geo-hub that can take the ZIP.
        if ($facts !== null && $facts['lat'] !== null) {
            $clusters = self::loadClusters($pdo, $defaultGeoHubId);
            $target = self::pickCluster($clusters, $facts);
            if ($target !== null) {
                $pdo->prepare(
                    "UPDATE micro_clusters
                        SET associated_zips = JSON_ARRAY_APPEND(COALESCE(associated_zips, JSON_ARRAY()), '$', :zip), updated_at = NOW()
                      WHERE id = :id"
                )->execute(['zip' => $zip, 'id' => $target]);
                return $target;
            }
        }

        // Nothing qualifies — seed a new cluster anchored on this ZIP's town
        // (Phase 1 automated seeding, geography-driven, not the Phase 2 LLM
        // engine — source stays 'automated_seed', not 'system_proposed').
        $town = $facts !== null ? trim((string) $facts['city']) : '';
        $name = ($town !== '' ? $town : 'ZIP ' . $zip) . ' (auto-seeded, needs review)';
        $slug = self::uniqueClusterSlug($pdo, $defaultGeoHubId, self::autoSeedSlug($town !== '' ? $town : $zip));

        $insert = $pdo->prepare(
            'INSERT INTO micro_clusters (geo_hub_id, slug, name, primary_zip, associated_zips, center_lat, center_lon, source, confidence_score, created_at, updated_at)
             VALUES (:geo_hub_id, :slug, :name, :zip, JSON_ARRAY(:zip2), :lat, :lon, \'automated_seed\', 1.00, NOW(), NOW())'
        );
        $insert->execute([
            'geo_hub_id' => $defaultGeoHubId,
            'slug'       => $slug,
            'name'       => $name,
            'zip'        => $zip,
            'zip2'       => $zip,
            'lat'        => $facts['lat'] ?? null,
            'lon'        => $facts['lon'] ?? null,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * Whether a cluster whose ZIPs are $members can also take $new: town cap always,
     * population ceiling too when every population is known.
     *
     * @param list<array{zip:string,city:?string,state:?string,population:?int}> $members
     * @param array{zip:string,city:?string,state:?string,population:?int} $new
     */
    public static function clusterAccepts(array $members, array $new): bool
    {
        $all = [...$members, $new];

        $towns = [];
        foreach ($all as $z) {
            $city = strtolower(trim((string) $z['city']));
            $towns[$city !== '' ? $city . '|' . strtolower(trim((string) $z['state'])) : 'zip:' . $z['zip']] = true;
        }
        if (count($towns) > self::AUTO_SEED_TOWN_CAP) {
            return false;
        }

        $total = 0;
        foreach ($all as $z) {
            if ($z['population'] === null) {
                return true;
            }
            $total += $z['population'];
        }
        return $total <= self::AUTO_SEED_POPULATION_CEILING;
    }

    /**
     * The id of the nearest cluster within AUTO_SEED_RADIUS_MILES that accepts
     * $new, or null. $clusters as returned by loadClusters().
     *
     * @param array<int, array{lat:?float,lon:?float,members:list<array>}> $clusters
     */
    public static function pickCluster(array $clusters, array $new): ?int
    {
        $ranked = [];
        foreach ($clusters as $id => $c) {
            if ($c['lat'] === null) {
                continue;
            }
            $d = self::miles($new['lat'], $new['lon'], $c['lat'], $c['lon']);
            if ($d <= self::AUTO_SEED_RADIUS_MILES) {
                $ranked[$id] = $d;
            }
        }
        asort($ranked);
        foreach (array_keys($ranked) as $id) {
            if (self::clusterAccepts($clusters[$id]['members'], $new)) {
                return $id;
            }
        }
        return null;
    }

    /**
     * Every cluster in a geo-hub with its center and member ZIP facts, keyed by id.
     * The center is center_lat/lon, or the primary ZIP's coordinates if unset.
     *
     * @return array<int, array{id:int,slug:string,name:string,source:string,primary_zip:string,lat:?float,lon:?float,members:list<array>}>
     */
    public static function loadClusters(PDO $pdo, int $geoHubId): array
    {
        $st = $pdo->prepare(
            'SELECT id, slug, name, source, primary_zip, associated_zips, center_lat, center_lon
               FROM micro_clusters WHERE geo_hub_id = :g ORDER BY id'
        );
        $st->execute(['g' => $geoHubId]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        $zipsById = [];
        $allZips = [];
        foreach ($rows as $r) {
            $zips = [self::normalizeZip($r['primary_zip'])];
            foreach ((array) (json_decode((string) $r['associated_zips'], true) ?? []) as $z) {
                $zips[] = self::normalizeZip((string) $z);
            }
            $zipsById[(int) $r['id']] = array_values(array_unique($zips));
            array_push($allZips, ...$zipsById[(int) $r['id']]);
        }
        $facts = self::zipFacts($pdo, $allZips);

        $out = [];
        foreach ($rows as $r) {
            $id = (int) $r['id'];
            $members = array_map(
                fn (string $z) => $facts[$z] ?? ['zip' => $z, 'city' => null, 'state' => null, 'lat' => null, 'lon' => null, 'population' => null],
                $zipsById[$id]
            );
            $primary = $members[0];
            $out[$id] = [
                'id'          => $id,
                'slug'        => (string) $r['slug'],
                'name'        => (string) $r['name'],
                'source'      => (string) $r['source'],
                'primary_zip' => $primary['zip'],
                'lat'         => $r['center_lat'] !== null ? (float) $r['center_lat'] : $primary['lat'],
                'lon'         => $r['center_lon'] !== null ? (float) $r['center_lon'] : $primary['lon'],
                'members'     => $members,
            ];
        }
        return $out;
    }

    /**
     * City, state, coordinates and population for each ZIP found in zip_coordinates,
     * keyed by ZIP. population is null until import_zip_population.php has run (or if
     * the column doesn't exist yet), which makes grouping fall back to the town cap.
     *
     * @param list<string> $zips
     * @return array<string, array{zip:string,city:?string,state:?string,lat:?float,lon:?float,population:?int}>
     */
    public static function zipFacts(PDO $pdo, array $zips): array
    {
        $zips = array_values(array_unique(array_map(fn ($z) => self::normalizeZip($z), $zips)));
        if ($zips === []) {
            return [];
        }
        if (self::$hasPopulationColumn === null) {
            $col = $pdo->query("SHOW COLUMNS FROM zip_coordinates LIKE 'population'");
            self::$hasPopulationColumn = $col !== false && $col->fetch() !== false;
        }
        $pop = self::$hasPopulationColumn ? 'population' : 'NULL AS population';
        $in = implode(',', array_fill(0, count($zips), '?'));
        $st = $pdo->prepare("SELECT zip, city, state, latitude, longitude, $pop FROM zip_coordinates WHERE zip IN ($in) ORDER BY id");
        $st->execute($zips);

        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $z = self::normalizeZip($r['zip']);
            if (isset($out[$z])) {
                continue;   // zip_coordinates can hold a ZIP more than once; the first row wins
            }
            $out[$z] = [
                'zip'        => $z,
                'city'       => $r['city'] !== null ? trim((string) $r['city']) : null,
                'state'      => $r['state'] !== null ? trim((string) $r['state']) : null,
                'lat'        => $r['latitude'] !== null ? (float) $r['latitude'] : null,
                'lon'        => $r['longitude'] !== null ? (float) $r['longitude'] : null,
                'population' => $r['population'] !== null ? (int) $r['population'] : null,
            ];
        }
        return $out;
    }

    /** decisions/0042 slug formula with "auto" standing in for the tier id: cluster-auto-show-low. */
    public static function autoSeedSlug(string $anchor): string
    {
        $s = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($anchor)), '-');
        return 'cluster-auto-' . trim(substr($s !== '' ? $s : 'unnamed', 0, 60), '-');
    }

    /** $base, or $base-2, -3… — unique within the geo-hub (uq_micro_clusters_geo_hub_slug). */
    private static function uniqueClusterSlug(PDO $pdo, int $geoHubId, string $base): string
    {
        $check = $pdo->prepare('SELECT 1 FROM micro_clusters WHERE geo_hub_id = :g AND slug = :s LIMIT 1');
        $slug = $base;
        for ($n = 2; ; $n++) {
            $check->execute(['g' => $geoHubId, 's' => $slug]);
            if ($check->fetchColumn() === false) {
                return $slug;
            }
            $slug = "$base-$n";
        }
    }

    public static function miles(float $lat1, float $lon1, float $lat2, float $lon2): float
    {
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon / 2) ** 2;
        return 2 * 3959 * asin(min(1, sqrt($a)));
    }

    /**
     * Looks up an existing zip_coordinates row for fallback lat/lon.
     * Returns null if none found (caller should not fail the record —
     * just proceed without coordinates rather than blocking ingestion).
     */
    public static function fallbackCoordinates(PDO $pdo, string $zip): ?array
    {
        $zip = self::normalizeZip($zip);
        $stmt = $pdo->prepare('SELECT latitude, longitude FROM zip_coordinates WHERE zip = :zip LIMIT 1');
        $stmt->execute(['zip' => $zip]);
        $row = $stmt->fetch();
        return $row === false ? null : ['latitude' => $row['latitude'], 'longitude' => $row['longitude']];
    }

    /**
     * Upserts one merchant entity + its metadata from a normalized
     * record. Returns ['entity_id' => int, 'action' => 'created'|'updated'].
     *
     * Core identity fields on `entities` (name, lat/lon, primary_zip) are
     * only overwritten by the crawler while the listing is still
     * `unclaimed` — once claimed, those become owner-editable only via
     * the business dashboard, never patched by a crawler run. This rule
     * isn't from the original spec verbatim; it's the natural extension
     * of the `is_locked` field-locking concept applied consistently to
     * the entities table itself, not just entity_metadata.
     *
     * @param array $record  Expected keys: name, address, city, state, zip,
     *                        phone, description, category, ai_summary,
     *                        latitude (optional), longitude (optional),
     *                        legacy_status (optional, for migration traceability)
     */
    public static function upsertEntity(PDO $pdo, array $record, int $defaultGeoHubId, bool $check = false): array
    {
        // $check (the ingest API, decisions/0164 §3.1): with no exact hash, the one identity check reads candidates fresh;
        // the same business (or one covered by a listed one) is matched, never made again, and only its gaps are filled (R4)
        $name = trim((string) $record['name']);
        $address = trim((string) ($record['address'] ?? ''));
        $zip = self::normalizeZip($record['zip'] ?? '00000');

        if ($name === '') {
            throw new InvalidArgumentException('Record is missing a business name.');
        }

        $hash = self::computeCompositeHash($name, $address, $zip);

        $lat = $record['latitude'] ?? null;
        $lon = $record['longitude'] ?? null;
        $coords = null;
        if ($lat === null || $lon === null) {
            $coords = self::fallbackCoordinates($pdo, $zip);
            if ($coords !== null) {
                $lat = $lat ?? $coords['latitude'];
                $lon = $lon ?? $coords['longitude'];
            }
        }

        $clusterId = self::resolveMicroClusterId($pdo, $zip, $defaultGeoHubId);
        $intent = self::resolveIntentVectors($record['category'] ?? null);

        $existingStmt = $pdo->prepare('SELECT id, status FROM entities WHERE composite_hash = :hash LIMIT 1');
        $existingStmt->execute(['hash' => $hash]);
        $existing = $existingStmt->fetch();
        $matched = false;
        if ($existing === false && $check) {
            require_once __DIR__ . '/ListingIdentity.php';
            $id = ListingIdentity::resolve($pdo, ['name' => $name, 'address' => $address, 'zip' => $zip, 'phone' => (string) ($record['phone'] ?? ''), 'lat' => $record['latitude'] ?? null, 'lng' => $record['longitude'] ?? null]);
            if (in_array($id['kind'], ['same', 'covered'], true)) {
                $st = $pdo->prepare('SELECT id, status FROM entities WHERE id = ?'); $st->execute([$id['id']]);
                $existing = $st->fetch(); $matched = $existing !== false;
            }
        }

        if ($existing === false) {
            $insert = $pdo->prepare(
                'INSERT INTO entities
                    (entity_type, name, composite_hash, primary_zip, micro_cluster_id, latitude, longitude,
                     status, trust_score, is_suppressed, submission_source, intent_utility, intent_experience,
                     created_by_type, updated_by_type, created_at, updated_at)
                 VALUES
                    (\'merchant\', :name, :hash, :zip, :cluster_id, :lat, :lon,
                     :status, :trust_score, :is_suppressed, \'prepopulated\', :intent_utility, :intent_experience,
                     \'ai_crawler\', \'ai_crawler\', NOW(), NOW())'
            );
            [$status, $isSuppressed] = self::mapLegacyStatus($record['legacy_status'] ?? null);

            // Creation-time trust score only — geocode-match bonus is a
            // one-time award, never re-applied on later crawler re-runs
            // of the same record (see class doc-comment on why this
            // must be idempotent, not repeated per crawl cycle).
            $initialTrustScore = TrustScore::ENTITY_AI_CRAWLER_BASELINE;
            if ($coords !== null && ($record['latitude'] ?? null) === null) {
                // Bonus only applies when OUR OWN zip_coordinates lookup
                // resolved the coordinates, not when the crawler payload
                // already supplied its own unverified lat/lon.
                $initialTrustScore += TrustScore::ENTITY_GEOCODE_MATCH_BONUS;
            }

            $insert->execute([
                'name'              => $name,
                'hash'              => $hash,
                'zip'               => $zip,
                'cluster_id'        => $clusterId ?: null,
                'lat'               => $lat,
                'lon'               => $lon,
                'status'            => $status,
                'trust_score'       => $initialTrustScore,
                'is_suppressed'     => $isSuppressed ? 1 : 0,
                'intent_utility'    => $intent['utility'] ? 1 : 0,
                'intent_experience' => $intent['experience'] ? 1 : 0,
            ]);
            $entityId = (int) $pdo->lastInsertId();
            $action = 'created';
        } else {
            $entityId = (int) $existing['id'];
            $action = $matched ? 'matched' : 'updated';

            // Only patch core identity fields while still unclaimed —
            // once claimed, the crawler must not overwrite them. A listing the identity check matched keeps its own (gaps only).
            if ($existing['status'] === 'unclaimed' && !$matched) {
                // a point a person set (staff, the owner, a visitor's pin used in Review) or the Census placed stays put (decisions/0058 §15)
                $g = $pdo->prepare("SELECT meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key = 'geocode' LIMIT 1");
                $g->execute([(int) $existing['id']]);
                $gs = (string) ((json_decode((string) $g->fetchColumn(), true) ?: [])['s'] ?? '');
                if (in_array($gs, ['staff', 'owner', 'visitor', 'site', 'match', 'exact'], true)) {
                    $keep = $pdo->prepare('SELECT latitude, longitude FROM entities WHERE id = ?'); $keep->execute([(int) $existing['id']]);
                    if ($k = $keep->fetch(PDO::FETCH_ASSOC)) { $lat = $k['latitude']; $lon = $k['longitude']; }
                }
                $update = $pdo->prepare(
                    'UPDATE entities SET name = :name, primary_zip = :zip, micro_cluster_id = :cluster_id,
                        latitude = :lat, longitude = :lon, updated_by_type = \'ai_crawler\', updated_at = NOW()
                     WHERE id = :id'
                );
                $update->execute([
                    'name' => $name, 'zip' => $zip, 'cluster_id' => $clusterId ?: null,
                    'lat' => $lat, 'lon' => $lon, 'id' => $entityId,
                ]);
            }
        }

        if (!empty($intent['needs_review'])) {
            self::upsertMetadataKey($pdo, $entityId, 'intent_needs_review', 'true');
        }

        $metadata = [
            'address'         => $address,
            'city'            => $record['city'] ?? null,
            'state'           => $record['state'] ?? null,
            'phone'           => $record['phone'] ?? null,
            'description'     => $record['description'] ?? null,
            'category'        => $record['category'] ?? null,
            'ai_summary'      => $record['ai_summary'] ?? null,
        ];
        $has = [];
        if ($matched) { $h = $pdo->prepare('SELECT meta_key FROM entity_metadata WHERE entity_id = ?'); $h->execute([$entityId]); $has = array_flip($h->fetchAll(PDO::FETCH_COLUMN)); }
        foreach ($metadata as $key => $value) {
            if ($value === null || $value === '' || isset($has[$key])) {
                continue;
            }
            // 'ai_summary' gets its own explicit baseline (spec Section 16);
            // every other crawler-sourced field relies on entity_metadata's
            // column default (10.00) rather than being set here explicitly.
            $trustScore = $key === 'ai_summary' ? TrustScore::METADATA_AI_SUMMARY_BASELINE : null;
            self::upsertMetadataKey($pdo, $entityId, $key, $value, $trustScore);
        }

        require_once __DIR__ . '/ListingIdentity.php'; ListingIdentity::writeKeys($pdo, $entityId);   // its identity keys (decisions/0164 §3.1)
        return ['entity_id' => $entityId, 'action' => $action, 'composite_hash' => $hash];
    }

    /**
     * Upserts a single entity_metadata key, respecting is_locked.
     * Never sets is_locked = 1 itself — that only happens when a human
     * (owner/admin) edits a field via the business dashboard, not here.
     *
     * @param float|null $explicitTrustScore When null, relies on the
     *        entity_metadata table's column default (10.00) for a fresh
     *        row and leaves an existing row's trust_score untouched on
     *        update. When set, used as the trust_score on initial
     *        insert (e.g. the 'ai_summary' key's higher baseline).
     * @return bool true if written, false if skipped due to lock
     *
     * Public (was private) so Listing Intake (spec §31, IntakeStager::approve) writes its
     * extra 5W keys through this same lock-respecting path instead of duplicating it.
     */
    public static function upsertMetadataKey(PDO $pdo, int $entityId, string $key, mixed $value, ?float $explicitTrustScore = null, array $src = []): bool
    {
        $existing = $pdo->prepare(
            'SELECT is_locked FROM entity_metadata WHERE entity_id = :entity_id AND meta_key = :key LIMIT 1'
        );
        $existing->execute(['entity_id' => $entityId, 'key' => $key]);
        $row = $existing->fetch();

        if ($row !== false && (int) $row['is_locked'] === 1) {
            if (class_exists('ControlLedger', false)) ControlLedger::touched('listing', $entityId, 'refused: ' . $key . ' kept (a person entered it)');   // the board's ledger (decisions/0171 §4)
            return false; // human-edited field — crawler must not touch it
        }

        $jsonValue = json_encode($value, JSON_UNESCAPED_SLASHES);

        if ($explicitTrustScore !== null) {
            $stmt = $pdo->prepare(
                'INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, trust_score, created_at, updated_at)
                 VALUES (:entity_id, :key, :value, \'ai_crawler\', 0, :trust_score, NOW(), NOW())
                 ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = \'ai_crawler\', updated_at = NOW()'
            );
            $stmt->execute(['entity_id' => $entityId, 'key' => $key, 'value' => $jsonValue, 'trust_score' => $explicitTrustScore]);
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at)
                 VALUES (:entity_id, :key, :value, \'ai_crawler\', 0, NOW(), NOW())
                 ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = \'ai_crawler\', updated_at = NOW()'
            );
            $stmt->execute(['entity_id' => $entityId, 'key' => $key, 'value' => $jsonValue]);
        }
        // the listing's identity records it as it's written, with where it was read when known (decisions/0133)
        if (in_array($key, ['aka', 'address', 'city', 'state', 'phone', 'website', 'email', 'hours', 'description', 'offerings', 'category'], true)) {
            require_once __DIR__ . '/Identity.php';
            Identity::listingWrote($pdo, $entityId, $key, $value, 'ai_crawler', 0, $src);
        }
        if (class_exists('ControlLedger', false)) ControlLedger::touched('listing', $entityId, 'updated: ' . $key);   // a worker's call, measured for the board (decisions/0171 §4)

        return true;
    }

    /**
     * Maps the legacy `listings.status` enum (pending/active/rejected)
     * onto the new lifecycle. Resolved decision (previously handled
     * conservatively, now confirmed):
     *
     *   'active'   -> status='unclaimed', visible.
     *   'pending'  -> status='unclaimed', visible (NOT suppressed).
     *                 Unclaimed is a normal, publicly-browsable state in
     *                 this schema, not a hidden one (Section 4) — the
     *                 unclaimed/verification lifecycle itself is the
     *                 moderation gate, not visibility-suppression. A
     *                 legacy 'pending' record is treated the same as
     *                 'active' now that this has been explicitly decided.
     *   'rejected' -> status='unclaimed', is_suppressed=1. Still
     *                 suppressed — unlike 'pending', this represents an
     *                 actual past admin decision, not just "hadn't been
     *                 reviewed yet," so it is never silently resurrected.
     *
     * @return array{0:string,1:bool} [status, is_suppressed]
     */
    private static function mapLegacyStatus(?string $legacyStatus): array
    {
        return match ($legacyStatus) {
            'rejected' => ['unclaimed', true],
            default    => ['unclaimed', false], // 'active', 'pending', or unknown/new crawler record
        };
    }
}
