<?php

declare(strict_types=1);

require_once __DIR__ . '/../CrawlerIngest.php';

/**
 * api/lib/crawler/IntakeStager.php — Listing Intake, step 3 of 3 (spec Section 31).
 *
 * The BlueHost side of intake: everything that touches the database.
 *
 *   stage()   — enriches each proposed listing (ZIP -> coordinates, micro-cluster preview,
 *               existing-listing match, category suggestions) and parks it in
 *               crawler_raw_index as 'staged'. Nothing public changes.
 *   approve() — the admin's reviewed version goes through CrawlerIngest::upsertEntity(),
 *               the SAME upsert api/ingest.php uses (spec §21.2: no second ingest path),
 *               then sets category_id and writes the extra 5W metadata keys.
 *   reject()  — marks it rejected; the content hash keeps a re-crawl from re-staging it.
 *
 * When the crawl moves to the VPS, the VPS runs SiteFetcher + ListingExtractor and POSTs
 * candidates here; this class does not change.
 */
final class IntakeStager
{
    /**
     * entity_metadata keys this tool writes beyond CrawlerIngest's own
     * (address, city, state, phone, description, category). None of these existed
     * in entity_metadata as of 2026-09-28 (checked live), so no naming collisions.
     * One place to rename them if the spec settles on different names.
     */
    public const EXTRA_META_KEYS = [
        'email'        => ['actions', 'email'],
        'website'      => ['actions', 'website'],
        'whatsapp'     => ['actions', 'whatsapp'],
        'contact_url'  => ['actions', 'contact_url'],   // a contact-form or booking page, for places with no public email
        'social_links' => ['actions', 'social'],
        'hours'        => ['when', 'hours'],
        'service_area' => ['where', 'service_area'],
        'offerings'    => ['what', 'offerings'],
        'audience'     => ['who', 'audience'],
        'highlights'   => ['why', 'highlights'],
        'source_url'   => ['where', 'location_page'],
    ];

    private const LIST_FIELDS = ['hours', 'service_area', 'offerings', 'audience', 'highlights', 'social'];

    /**
     * What goes where, and how much: shown as help on every edit form and enforced on save.
     * Lists are one item per line; leading bullets (•, -, *, numbers) are removed.
     */
    public const FIELD_RULES = [
        'name'         => ['max' => 120,  'help' => 'The name people know it by. No slogans or locations.'],
        'description'  => ['max' => 1500, 'help' => 'A few plain sentences about the place: what it is and who it helps. Explanations of services go here.'],
        'offerings'    => ['items' => 30, 'each' => 60,  'help' => 'Short names of services or products, one per line: Emergency care, Cardiology, Pharmacy. Details go in Description.'],
        'hours'        => ['items' => 14, 'each' => 60,  'help' => 'One line per day or day range: Mon–Fri 8am–5pm, Sat 9am–1pm.'],
        'audience'     => ['items' => 10, 'each' => 40,  'help' => 'Who it serves, one per line: Veterans, Families, Seniors.'],
        'highlights'   => ['items' => 6,  'each' => 100, 'help' => 'What sets it apart, one short line each.'],
        'service_area' => ['items' => 40, 'each' => 60,  'help' => 'Towns or ZIPs it serves, one per line.'],
        'social'       => ['items' => 10, 'each' => 300, 'help' => 'Full links to its pages, one per line.'],
    ];
    private const LIST_LABELS = ['hours' => 'Hours', 'service_area' => 'Service area', 'offerings' => 'Offerings',
                                 'audience' => 'Audience', 'highlights' => 'Highlights', 'social' => 'Social links'];

    // ------------------------------------------------------------------
    // Access
    // ------------------------------------------------------------------

    /**
     * Who may use Listing Intake: a super_admin in admin_access (the Section 27 capability model,
     * columns confirmed live: user_id, hub_id, tier), or the legacy users.is_admin flag.
     * Regional admins are left out for now: intake can create listings and clusters in any hub.
     */
    public static function canUseIntake(PDO $pdo, array $user): bool
    {
        if (!empty($user['is_admin'])) return true;
        $st = $pdo->prepare("SELECT 1 FROM " . Database::t('admin_access') . " WHERE user_id = :u AND tier = 'super_admin' LIMIT 1");
        $st->execute(['u' => (int) $user['id']]);
        return $st->fetchColumn() !== false;
    }

    // ------------------------------------------------------------------
    // Sources
    // ------------------------------------------------------------------

    /** Why a site is crawled — the checkboxes on the intake form (crawler_sources.purposes). */
    public const PURPOSES = [
        'create_listings' => 'Create listing(s)',
        'content_topics'  => 'Content topics',
        'guide_create'    => 'Guide create',
        'other'           => 'Other',
    ];

    /** @param string[] $purposes keys of PURPOSES (validated by the caller) */
    public static function createSource(PDO $pdo, string $url, array $purposes, ?string $note, int $userId): int
    {
        $stmt = $pdo->prepare(
            'INSERT INTO ' . Database::t('crawler_sources') . ' (url, domain, engine, purposes, rationale, added_by_user_id, added_by_type)
             VALUES (:url, :domain, \'directory\', :purposes, :rationale, :uid, \'admin\')'
        );
        $stmt->execute([
            'url' => $url,
            'domain' => SiteFetcher::siteKey((string) parse_url($url, PHP_URL_HOST)),
            'purposes' => implode(',', $purposes),
            'rationale' => $note,
            'uid' => $userId > 0 ? $userId : null,   // the worker and bulk loads have no user: NULL, never 0 (the foreign key)
        ]);
        return (int) $pdo->lastInsertId();
    }

    /**
     * Clears failed sources that need no one (Jason, 2026-11-01: "remove failed where needed"): one crawled again with
     * success since (its sightings move to the run that worked), one that was never a website (a phone number typed as
     * an address), and one on a site we never crawl (social media). A failure that may be the site's (it was down) stays
     * and shows in Pulse, to crawl again or remove. Returns how many it cleared.
     */
    public static function tidySources(PDO $pdo): int
    {
        require_once __DIR__ . '/SiteFetcher.php';
        $T = Database::t('crawler_sources'); $R = Database::t('crawler_raw_index');
        $n = 0;
        try {
            foreach ($pdo->query("SELECT id, url, last_crawled_at, last_error FROM $T WHERE last_error IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC) as $s) {
                $host = strtolower((string) parse_url((string) $s['url'], PHP_URL_HOST));
                $ok = $pdo->prepare("SELECT id FROM $T WHERE url = ? AND id <> ? AND last_error IS NULL AND last_crawled_at >= ? ORDER BY last_crawled_at DESC LIMIT 1");
                $ok->execute([(string) $s['url'], (int) $s['id'], (string) $s['last_crawled_at']]);
                $twin = (int) $ok->fetchColumn();
                $notSite = $host === '' || !preg_match('/\.[a-z]{2,}$/', $host);
                $never = $host !== '' && preg_match(SiteFetcher::NEVER_CRAWL, $host);
                if (!$twin && !$notSite && !$never) continue;   // may be the site's: a person decides, in Pulse
                if ($twin) $pdo->prepare("UPDATE $R SET source_id = ? WHERE source_id = ?")->execute([$twin, (int) $s['id']]);
                $pdo->prepare("DELETE FROM $T WHERE id = ?")->execute([(int) $s['id']]);
                $n++;
            }
        } catch (Throwable $x) { error_log('tidy sources: ' . $x->getMessage()); }
        return $n;
    }

    /** A person removes a failed source (Pulse): its sightings stay, without a source. */
    public static function removeSource(PDO $pdo, int $id): void
    {
        $T = Database::t('crawler_sources');
        $st = $pdo->prepare("SELECT last_error FROM $T WHERE id = ?"); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That source is already gone.');
        if ($r['last_error'] === null) throw new InvalidArgumentException('That source is working: only a failed one is removed here.');
        $pdo->prepare('UPDATE ' . Database::t('crawler_raw_index') . ' SET source_id = NULL WHERE source_id = ?')->execute([$id]);
        $pdo->prepare("DELETE FROM $T WHERE id = ?")->execute([$id]);
    }

    public static function recordRun(PDO $pdo, int $sourceId, int $pages, array $log, ?string $error): void
    {
        $pdo->prepare(
            'UPDATE ' . Database::t('crawler_sources') . ' SET last_crawled_at = NOW(), last_pages_fetched = :p, last_error = :e, last_log = :l WHERE id = :id'
        )->execute([
            'p' => $pages, 'e' => $error === null ? null : mb_substr($error, 0, 500),
            'l' => json_encode(array_slice($log, 0, 200), JSON_UNESCAPED_SLASHES), 'id' => $sourceId,
        ]);
    }

    // ------------------------------------------------------------------
    // Staging
    // ------------------------------------------------------------------

    /**
     * Stages each new candidate; any that pass every decisions/0044 guardrail are published straight
     * away by AutoImport and reported in auto_imported instead of staged.
     * @return array{staged:int[],already_known:int,auto_imported:int[]} ids of new staged rows / new listings
     */
    public static function stage(PDO $pdo, int $sourceId, array $candidates): array
    {
        require_once __DIR__ . '/AutoImport.php';
        $categories = self::leafCategories($pdo);
        $staged = [];
        $auto = [];
        $known = 0;

        foreach ($candidates as $c) {
            $hash = self::contentHash($c);
            $dup = $pdo->prepare('SELECT id FROM ' . Database::t('crawler_raw_index') . ' WHERE content_hash = :h LIMIT 1');
            $dup->execute(['h' => $hash]);
            if ($dup->fetchColumn() !== false) { $known++; continue; }

            $c = self::enrich($pdo, $c, $categories);
            // Crawling a site again: a location already waiting in Review (same site, same street and ZIP) is
            // refreshed in place, not added a second time. Nothing a person decided is touched.
            if (($prev = self::waitingSameLocation($pdo, $c)) !== null) {
                // what a person already decided in the helper stays decided: "not the same place", and its own notes
                $was = $pdo->prepare('SELECT raw_payload FROM ' . Database::t('crawler_raw_index') . ' WHERE id = ?'); $was->execute([$prev]);
                $was = json_decode((string) $was->fetchColumn(), true) ?: [];
                foreach (['not_same', 'helper'] as $k) if (isset($was[$k])) $c[$k] = $was[$k];
                if (!empty($c['not_same'])) {
                    if (in_array((int) ($c['match']['exact']['id'] ?? 0), $c['not_same'], true)) $c['match']['exact'] = null;
                    $c['match']['possible'] = array_values(array_filter($c['match']['possible'], fn ($m) => !in_array((int) $m['id'], $c['not_same'], true)));
                }
                $pdo->prepare('UPDATE ' . Database::t('crawler_raw_index') . ' SET raw_payload = :p, content_hash = :h, confidence_score = :conf, matched_entity_id = :m, source_id = :sid WHERE id = :id')
                    ->execute(['p' => json_encode($c, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), 'h' => $hash,
                               'conf' => max(0, min(100, (int) $c['confidence'])), 'm' => $c['match']['exact']['id'] ?? null, 'sid' => $sourceId, 'id' => $prev]);
                require_once __DIR__ . '/../Identity.php'; Identity::fromIntake($pdo, $prev);   // its identity, from what was seen this time (decisions/0133)
                if (class_exists('ControlLedger', false)) ControlLedger::touched('review', $prev, 'review: seen again, refreshed in place');   // the board's ledger (decisions/0171 §4)
                $staged[] = $prev;
                continue;
            }
            $pdo->prepare(
                'INSERT INTO ' . Database::t('crawler_raw_index') . ' (source_id, source_url, payload_type, raw_payload, content_hash, confidence_score, status, matched_entity_id)
                 VALUES (:sid, :url, \'listing\', :payload, :h, :conf, \'staged\', :match)'
            )->execute([
                'sid' => $sourceId,
                'url' => mb_substr($c['where']['location_page'] ?? $c['source']['start_url'], 0, 500),
                'payload' => json_encode($c, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                'h' => $hash,
                'conf' => max(0, min(100, (int) $c['confidence'])),
                'match' => $c['match']['exact']['id'] ?? null,
            ]);
            $rowId = (int) $pdo->lastInsertId();
            require_once __DIR__ . '/../Identity.php'; Identity::fromIntake($pdo, $rowId);   // an identity from the first sighting (decisions/0133)
            $imported = AutoImport::tryImport($pdo, $rowId, $c);
            if ($imported !== null) {
                $auto[] = (int) $imported['entity_id'];
                if (class_exists('ControlLedger', false)) ControlLedger::touched('listing', (int) $imported['entity_id'], ($imported['action'] ?? '') === 'created' ? 'stored' : 'updated: gaps filled from a find');
            } else {
                $staged[] = $rowId;
                if (class_exists('ControlLedger', false)) ControlLedger::touched('review', $rowId, 'review');   // the board's ledger (decisions/0171 §4)
            }
        }
        return ['staged' => $staged, 'already_known' => $known, 'auto_imported' => $auto];
    }

    /** A staged or quarantined row from the same site for the same street and ZIP, if any. */
    private static function waitingSameLocation(PDO $pdo, array $c): ?int
    {
        $site = (string) ($c['source']['site'] ?? '');
        $zip = (string) ($c['where']['zip'] ?? '');
        $street = (string) ($c['where']['address'] ?? '');
        if ($site === '' || $zip === '' || $street === '') return null;
        $key = ListingExtractor::streetKey($street);
        $st = $pdo->prepare("SELECT id, raw_payload FROM " . Database::t('crawler_raw_index') . " WHERE status IN ('staged', 'quarantined') AND source_url LIKE :u ORDER BY id DESC LIMIT 200");
        $st->execute(['u' => '%' . preg_replace('/^www\./', '', $site) . '%']);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $p = json_decode((string) $r['raw_payload'], true);
            if (!is_array($p) || preg_replace('/^www\./', '', (string) ($p['source']['site'] ?? '')) !== preg_replace('/^www\./', '', $site)) continue;
            if ((string) ($p['where']['zip'] ?? '') === $zip && ListingExtractor::streetKey((string) ($p['where']['address'] ?? '')) === $key) return (int) $r['id'];
        }
        return null;
    }

    /** Same facts => same hash, regardless of when or how many pages were crawled. */
    public static function contentHash(array $c): string
    {
        unset($c['source'], $c['confidence']);
        return hash('sha256', json_encode($c, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private static function enrich(PDO $pdo, array $c, array $categories): array
    {
        $zip = $c['where']['zip'] ?? '';

        // Where: coordinates + micro-cluster, read-only (approval is what may auto-seed a cluster)
        $c['geo'] = ['latitude' => null, 'longitude' => null, 'resolved' => false, 'cluster' => null];
        $sitePt = $c['where']['point'] ?? null;   // the site's own map (rural places often have no street address)
        if (is_array($sitePt) && is_numeric($sitePt['lat'] ?? null) && is_numeric($sitePt['lon'] ?? null)) {
            $c['geo'] = ['latitude' => (float) $sitePt['lat'], 'longitude' => (float) $sitePt['lon'], 'resolved' => true, 'cluster' => null, 'source' => 'site'];
        }
        if (preg_match('/^\d{5}$/', $zip)) {
            $coords = $c['geo']['resolved'] ? null : CrawlerIngest::fallbackCoordinates($pdo, $zip);
            if ($c['geo']['resolved']) {
                // the point is the site's; the ZIP still finds the cluster below
            } elseif ($coords !== null) {
                $c['geo'] = ['latitude' => (float) $coords['latitude'], 'longitude' => (float) $coords['longitude'], 'resolved' => true, 'cluster' => null];
            } else {
                $c['flags'][] = ['code' => 'zip_unknown', 'message' => "ZIP $zip isn't in zip_coordinates, so there's no map pin. Set the pin by hand before approving."];
            }
            $cl = $pdo->prepare(
                'SELECT id, name FROM micro_clusters WHERE primary_zip = :zip OR JSON_CONTAINS(associated_zips, JSON_QUOTE(:zip2)) LIMIT 1'
            );
            $cl->execute(['zip' => $zip, 'zip2' => $zip]);
            if ($row = $cl->fetch(PDO::FETCH_ASSOC)) {
                $c['geo']['cluster'] = ['id' => (int) $row['id'], 'name' => $row['name']];
            } else {
                $c['flags'][] = ['code' => 'no_cluster', 'message' => "No micro-cluster covers ZIP $zip. Approving adds it to the nearest cluster within " . (int) CrawlerIngest::AUTO_SEED_RADIUS_MILES . " miles that has room, or auto-seeds a new one named after its town, under the default geo-hub."];
            }
        }

        // Match against existing listings: exact composite hash, then same-ZIP name/phone look-alikes
        $c['match'] = ['exact' => null, 'possible' => []];
        if ($zip !== '' && $c['where']['address'] !== '') {
            $hash = CrawlerIngest::computeCompositeHash($c['name'], $c['where']['address'], $zip);
            $ex = $pdo->prepare('SELECT id, name, status FROM entities WHERE composite_hash = :h LIMIT 1');
            $ex->execute(['h' => $hash]);
            if ($row = $ex->fetch(PDO::FETCH_ASSOC)) {
                $c['match']['exact'] = ['id' => (int) $row['id'], 'name' => $row['name'], 'status' => $row['status']];
                $c['flags'][] = ['code' => 'exact_match', 'message' => "Already listed as #{$row['id']} ({$row['status']}). Merge the new data into it."];
            }
        }
        $c['match']['possible'] = self::findLookalikes($pdo, $c, $c['match']['exact']['id'] ?? 0);
        // Match context from visitors (decisions/0053): someone told us this website or phone belongs to a listing,
        // or to a business we don't list yet. Only the business's own website counts, never the site crawled
        // (a chamber directory lists many businesses).
        if (is_file(__DIR__ . '/../Suggestions.php')) {
            require_once __DIR__ . '/../Suggestions.php';
            try { $hints = Suggestions::hints($pdo, (string) ($c['actions']['website'] ?? ''), (string) ($c['actions']['phone'] ?? '')); } catch (Throwable) { $hints = []; }
            $exactId = (int) ($c['match']['exact']['id'] ?? 0);
            foreach ($hints as $h) {
                if ($h['id'] > 0) {
                    if ($h['id'] === $exactId) continue;
                    $at = array_search($h['id'], array_column($c['match']['possible'], 'id'), true);
                    if ($at !== false) $c['match']['possible'][$at]['why'] .= ' + ' . $h['why'];
                    else $c['match']['possible'][] = ['id' => $h['id'], 'name' => $h['name'], 'status' => $h['status'], 'zip' => $h['zip'], 'why' => $h['why']];
                } else {
                    $c['flags'][] = ['code' => 'visitor_hint', 'message' => 'A visitor told us about this business' . ($h['name'] !== '' ? ' (“' . $h['name'] . '”)' : '') . ': ' . $h['why'] . '. Mark suggestion #' . $h['suggestion'] . ' used in Review once it\'s listed.'];
                }
            }
        }
        if ($c['match']['possible']) {
            $c['flags'][] = ['code' => 'possible_duplicate', 'message' => 'Looks like a listing that already exists. If it\'s the same business, merge into it instead of creating a second one.'];
        }

        // What: category suggestions (interim word match; decisions/0024's weighted classifier replaces this)
        $c['category_suggestions'] = self::suggestCategories($c, $categories);
        if (!$c['category_suggestions']) {
            $c['flags'][] = ['code' => 'no_category', 'message' => 'No category matched. Pick one before approving.'];
        }
        return $c;
    }

    /**
     * Existing listings that are probably this business: same ZIP with a similar name or the same
     * phone, or the same phone anywhere (a legacy row may carry a different or missing ZIP).
     */
    /**
     * The candidate's matches against what's listed now (decisions/0074): a row that waited in Review while other rows
     * were published (another copy of the same business among them) is checked again before it's published or merged.
     * Matches it had that are gone stay out; ones only a visitor gave stay in.
     */
    public static function freshMatch(PDO $pdo, array $c): array
    {
        $zip = (string) ($c['where']['zip'] ?? ''); $addr = (string) ($c['where']['address'] ?? '');
        $exact = null;
        if ($zip !== '' && $addr !== '') {
            $ex = $pdo->prepare('SELECT id, name, status FROM entities WHERE composite_hash = :h LIMIT 1');
            $ex->execute(['h' => CrawlerIngest::computeCompositeHash((string) ($c['name'] ?? ''), $addr, $zip)]);
            if ($row = $ex->fetch(PDO::FETCH_ASSOC)) $exact = ['id' => (int) $row['id'], 'name' => $row['name'], 'status' => $row['status']];
        }
        $possible = self::findLookalikes($pdo, $c, $exact['id'] ?? 0);
        $have = array_column($possible, 'id');
        foreach ((array) ($c['match']['possible'] ?? []) as $m) if (!empty($m['id']) && !in_array((int) $m['id'], $have, true) && stripos((string) ($m['why'] ?? ''), 'visitor') !== false) $possible[] = $m;
        return ['exact' => $exact, 'possible' => $possible];
    }

    private static function findLookalikes(PDO $pdo, array $c, int $skipId): array
    {
        // the one identity check's candidates (decisions/0164 §3.1): read fresh from the identity keys, hidden twins
        // included, every one scored (no cap of 5, no unordered LIMIT that drops the real twin in a busy ZIP)
        require_once __DIR__ . '/../ListingIdentity.php';
        if (ListingIdentity::ready($pdo)) {
            $cand = ListingIdentity::cand($c);
            $ph = ListingIdentity::phoneKey((string) ($cand['actions']['phone'] ?? ''));
            $main = $ph !== '' && ListingIdentity::phoneShare($pdo, $ph) > ListingIdentity::setting($pdo, 'main_line');
            $out = [];
            foreach (ListingIdentity::load($pdo, ListingIdentity::candidateIds($pdo, $cand, [$skipId])) as $id => $l) {
                if ($l['hidden'] && $l['same_as']) continue;
                $r = ListingIdentity::relate($cand, $l, $main);
                if ($r['kind'] === 'other') continue;
                $why = array_filter([$r['phone'] ? 'same phone' : '', $r['addr'] ? 'same street address' : '', $r['zip'] && $r['name'] >= 0.5 ? 'similar name, same ZIP' : '', !empty($r['site']) ? 'same website' : '']);
                if (!$why) $why = [$r['kind'] === 'branch' ? 'same name, another street number' : 'similar name nearby'];
                $out[] = ['id' => $id, 'name' => $l['name'], 'status' => $l['claimed'] ? 'claimed' : 'unclaimed', 'zip' => $l['zip'], 'why' => implode(' + ', $why), 'phone' => ListingIdentity::phoneKey($l['phone']), 'address' => $l['address'], 'kind' => $r['kind'], 'hidden' => $l['hidden']];
            }
            usort($out, fn ($a, $b) => [array_search($a['kind'], ['same', 'covered', 'maybe', 'place', 'branch'], true), $a['id']] <=> [array_search($b['kind'], ['same', 'covered', 'maybe', 'place', 'branch'], true), $b['id']]);
            return $out;
        }
        $zip = (string) ($c['where']['zip'] ?? '');
        $myName = self::nameKey($c['name']);
        $myPhone = substr(preg_replace('/\D/', '', (string) ($c['actions']['phone'] ?? '')), -10);
        $rows = [];
        if (preg_match('/^\d{5}$/', $zip)) {
            $st = $pdo->prepare(
                "SELECT e.id, e.name, e.status, e.primary_zip, m.meta_value AS phone, ma.meta_value AS address
                   FROM entities e
                   LEFT JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'phone'
                   LEFT JOIN entity_metadata ma ON ma.entity_id = e.id AND ma.meta_key = 'address'
                  WHERE e.entity_type = 'merchant' AND e.primary_zip = :zip
                  LIMIT 2000"
            );
            $st->execute(['zip' => $zip]);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        }
        if (strlen($myPhone) === 10) {
            // stored phones vary in format ("(928) 321-1000", "928.321.1000"); the LIKE narrows, PHP confirms
            $st = $pdo->prepare(
                "SELECT e.id, e.name, e.status, e.primary_zip, m.meta_value AS phone, ma.meta_value AS address
                   FROM entity_metadata m JOIN entities e ON e.id = m.entity_id
                   LEFT JOIN entity_metadata ma ON ma.entity_id = e.id AND ma.meta_key = 'address'
                  WHERE m.meta_key = 'phone' AND e.entity_type = 'merchant' AND m.meta_value LIKE :p
                  LIMIT 200"
            );
            $st->execute(['p' => '%' . substr($myPhone, 3, 3) . '%' . substr($myPhone, 6) . '%']);
            $rows = array_merge($rows, $st->fetchAll(PDO::FETCH_ASSOC));
        }
        $out = [];
        foreach ($rows as $row) {
            $id = (int) $row['id'];
            if ($id === $skipId || isset($out[$id])) continue;
            $phone = json_decode((string) $row['phone'], true);
            $phone = substr(preg_replace('/\D/', '', is_string($phone) ? $phone : (string) $row['phone']), -10);
            similar_text($myName, self::nameKey($row['name']), $pct);
            $why = [];
            if ($pct >= 70 && $row['primary_zip'] === $zip) $why[] = 'similar name, same ZIP';
            if ($myPhone !== '' && $phone === $myPhone) $why[] = 'same phone';
            $addr = json_decode((string) ($row['address'] ?? ''), true);
            if ($why) $out[$id] = ['id' => $id, 'name' => $row['name'], 'status' => $row['status'], 'zip' => $row['primary_zip'], 'why' => implode(' + ', $why),
                                   'phone' => $phone, 'address' => is_string($addr) ? $addr : (string) ($row['address'] ?? '')];   // so a match can be read as another location (decisions/0074)
        }
        return array_slice(array_values($out), 0, 5);
    }

    private static function nameKey(string $s): string
    {
        $s = strtolower(preg_replace('/[^A-Za-z0-9 ]+/', ' ', $s));
        $s = preg_replace('/\b(the|and|llc|inc|co|corp|company|ltd)\b/', ' ', $s);
        return trim(preg_replace('/\s+/', ' ', $s));
    }

    /** Active leaf categories with their group name. */
    public static function leafCategories(PDO $pdo): array
    {
        return $pdo->query(
            "SELECT c.id, c.name, c.slug, g.name AS group_name, COALESCE(NULLIF(c.display_name, ''), c.name) AS plain, g.id AS group_id, COALESCE(u.n, 0) AS used
               FROM categories c JOIN categories g ON g.id = c.parent_id
               LEFT JOIN (SELECT category_id, COUNT(*) AS n FROM entities GROUP BY category_id) u ON u.category_id = c.id
              WHERE c.is_active = 1
              ORDER BY g.name, plain"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * The NPI Registry's label for a provider (its taxonomy, as NpiBulk and Verify put it in offerings), mapped to our
     * category: a federal record of what the provider is, so the category is sure (decisions/0076).
     */
    public const NPI_CATEGORY = [
        'health care' => 'Health Services', 'clinic' => 'Clinics', 'dentist' => 'Dentists', 'community behavioral health' => 'Mental Health Services',
        'internal medicine' => 'Physicians & Surgeons', 'family medicine' => 'Physicians & Surgeons', 'pharmacy' => 'Pharmacies', 'counseling' => 'Counselors',
        'nurse practitioner' => 'Nurses-Practitioners', 'chiropractic' => 'Chiropractors DC', 'home health care' => 'Home Health Service',
        'medical equipment and supplies' => 'Home Health & Health Care Equipment', 'assisted living' => 'Nursing & Convalescent Homes',
        'mental health clinic' => 'Mental Health Services', 'in-home supportive care' => 'Home Health Service', 'medical transportation' => 'Ambulance Service',
        'social services' => 'Social Service & Welfare Organizations', 'residential mental health treatment' => 'Mental Health Services',
        'physical therapy' => 'Physical Therapists', 'dental clinic' => 'Dentists', 'eye care' => 'Optometrists OD', 'hospice' => 'Hospices',
        'substance use treatment' => 'Substance Abuse Centers', 'psychiatry' => 'Mental Health Services', 'psychologist' => 'Psychologists',
        'primary care clinic' => 'Clinics', 'urgent care' => 'Urgent Medical Care Centers And Clinics', 'skilled nursing facility' => 'Nursing & Convalescent Homes',
        'community health center' => 'Medical Centers', 'medical laboratory' => 'Laboratories-Medical', 'hospital' => 'Hospitals',
        "women's health" => 'Physicians & Surgeons', 'pediatrics' => 'Physicians & Surgeons', 'occupational therapy' => 'Occupational Therapists',
        'dialysis center' => 'Dialysis', 'developmental disability services' => 'Social Service & Welfare Organizations', 'prosthetics and orthotics' => 'Prosthetic Devices',
        'rural health clinic' => 'Clinics', 'nursing care' => 'Home Health Service', 'ambulance service' => 'Ambulance Service', 'psychiatric hospital' => 'Hospitals',
        'psychiatric unit' => 'Hospitals', 'respite care' => 'Home Health Service', 'personal care services' => 'Home Health Service', 'infusion therapy' => 'Health Services',
        'rehabilitation hospital' => 'Hospitals', 'nursing facility' => 'Nursing & Convalescent Homes', 'speech therapy' => 'Speech Pathologists',
        'memory care' => 'Nursing & Convalescent Homes',
    ];

    /** Category suggestions for a candidate, as staging makes them (the pipeline refreshes old ones with it). */
    public static function suggestFor(PDO $pdo, array $c): array
    {
        static $cats = null;
        $cats ??= self::leafCategories($pdo);
        $c['what']['offerings'] = (array) ($c['what']['offerings'] ?? []); $c['what']['description'] = (string) ($c['what']['description'] ?? '');
        $c['name'] = (string) ($c['name'] ?? '');
        return self::suggestCategories($c, $cats);
    }

    private static function suggestCategories(array $c, array $categories): array
    {
        // a registry's own label for what it is comes first, and is sure
        $byName = []; foreach ($categories as $cat) $byName[mb_strtolower((string) $cat['name'])] = $cat;
        foreach ((array) ($c['what']['offerings'] ?? []) as $o) {
            $k = mb_strtolower(trim((string) $o));
            if (isset(self::NPI_CATEGORY[$k]) && ($cat = $byName[mb_strtolower(self::NPI_CATEGORY[$k])] ?? null)) {
                $rest = array_values(array_filter(self::classified($c), fn ($x) => $x['id'] !== (int) $cat['id']));
                return array_slice(array_merge([['id' => (int) $cat['id'], 'name' => $cat['name'], 'group' => $cat['group_name'], 'score' => 99, 'from' => 'registry']], $rest), 0, 3);
            }
        }
        return self::classified($c);
    }

    /** The weighted classifier's best fits (decisions/0024), as suggestions with their confidence and why. */
    private static function classified(array $c): array
    {
        require_once __DIR__ . '/../CategoryClassifier.php';
        $out = [];
        foreach (CategoryClassifier::classify($c, CategoryClassifier::categories(Database::connection())) as $x)
            $out[] = ['id' => $x['id'], 'name' => $x['name'], 'group' => $x['group'], 'score' => $x['confidence'], 'confidence' => $x['confidence'], 'why' => implode('; ', $x['why']), 'from' => 'classifier'];
        return $out;
    }

    // ------------------------------------------------------------------
    // Review
    // ------------------------------------------------------------------

    /** Same resolution api/ingest.php does (duplicated deliberately; see §31 follow-ups). */
    public static function defaultGeoHubId(PDO $pdo): int
    {
        $slug = getenv('DEFAULT_GEO_HUB_SLUG') ?: 'ancient-borderlands';
        $stmt = $pdo->prepare('SELECT id FROM geo_hubs WHERE slug = :slug LIMIT 1');
        $stmt->execute(['slug' => $slug]);
        $id = $stmt->fetchColumn();
        if ($id === false) {
            throw new RuntimeException("DEFAULT_GEO_HUB_SLUG '$slug' does not exist in geo_hubs, so approvals can't place listings. Fix .env first.");
        }
        return (int) $id;
    }

    /** One row by id, in the given status, as listRows() gives it; null when it isn't (any more). */
    public static function oneRow(PDO $pdo, int $rowId, string $status = 'staged'): ?array
    {
        return $rowId > 0 ? (self::listRows($pdo, $status, 1, $rowId)[0] ?? null) : null;
    }

    /**
     * Approves one staged candidate with the admin's edits. $adminId null = approved automatically
     * (AutoImport, decisions/0044); $note is kept as the row's review_note.
     * @return array{entity_id:int,action:string}
     */
    public static function approve(PDO $pdo, int $rowId, array $in, ?int $adminId, ?string $note = null, array $differentFrom = []): array
    {
        $geoHubId = self::defaultGeoHubId($pdo);
        $v = self::validate($pdo, $in);
        // the one identity check (decisions/0164 §3.1), whoever approves (arrival, the pipeline, the second look, quick
        // approve, the helper, Review): candidates read fresh, inside the identity lock, never the match stored at staging
        require_once __DIR__ . '/../ListingIdentity.php';
        return ListingIdentity::locked($pdo, (string) $v['zip'], function () use ($pdo, $rowId, $in, $v, $adminId, $geoHubId, $note, $differentFrom): array {
            $c = ListingIdentity::cand(['name' => $v['name'], 'address' => $v['address'], 'zip' => $v['zip'], 'phone' => $v['phone'], 'website' => (string) ($v['meta']['website'] ?? ''), 'lat' => $v['latitude'], 'lng' => $v['longitude']]);
            $id = ListingIdentity::resolve($pdo, $c, ['different' => $differentFrom]);
            if ($id['kind'] === 'same') {   // the same business: its gaps filled, nothing overwritten (R4)
                require_once __DIR__ . '/AutoImport.php';
                return AutoImport::fillGaps($pdo, $rowId, $id['id'], ['name' => $v['name']], $adminId, mb_substr(($note ? $note . '; ' : '') . 'the identity check: ' . $id['why'], 0, 1000), $in, (int) ($v['category_id'] ?? 0));
            }
            if ($id['kind'] === 'covered') {   // covered by a listed one: not listed again, nothing copied
                self::reject($pdo, $rowId, mb_substr('The identity check: ' . $id['why'], 0, 1000), $adminId);
                $pdo->prepare('UPDATE ' . Database::t('crawler_raw_index') . ' SET entity_id = ? WHERE id = ?')->execute([$id['id'], $rowId]);
                require_once __DIR__ . '/../Identity.php'; Identity::adopt($pdo, $rowId, $id['id']);
                return ['entity_id' => $id['id'], 'action' => 'closed'];
            }
            if ($id['kind'] === 'maybe') {
                throw new InvalidArgumentException('It may already be listed as "' . ($id['hits'][0]['name'] ?? '') . '" (#' . $id['id'] . '): ' . ($id['hits'][0]['why'] ?? '')
                    . ($adminId ? '. Compare them in Review, or answer "a different business".' : '. The identity check sends it to be vetted.'));
            }
            $out = self::approveNew($pdo, $rowId, $v, $adminId, $geoHubId, $note);
            foreach ($differentFrom as $other) if ((int) $other > 0) ListingIdentity::different($pdo, (int) $out['entity_id'], (int) $other, (int) $adminId);
            return $out;
        });
    }

    /** approve()'s write, once the identity check found nothing listed that it is. */
    private static function approveNew(PDO $pdo, int $rowId, array $v, ?int $adminId, int $geoHubId, ?string $note): array
    {
        $out = Database::transaction(function (PDO $pdo) use ($rowId, $v, $adminId, $geoHubId, $note): array {
            $row = $pdo->prepare('SELECT id, status FROM ' . Database::t('crawler_raw_index') . ' WHERE id = :id FOR UPDATE');
            $row->execute(['id' => $rowId]);
            $r = $row->fetch(PDO::FETCH_ASSOC);
            if ($r === false) throw new InvalidArgumentException('That proposed listing no longer exists.');
            if (!in_array($r['status'], ['staged', 'quarantined'], true)) {
                throw new InvalidArgumentException("This proposed listing was already {$r['status']}.");
            }

            $result = CrawlerIngest::upsertEntity($pdo, [
                'name' => $v['name'], 'address' => $v['address'], 'city' => $v['city'], 'state' => $v['state'],
                'zip' => $v['zip'], 'phone' => $v['phone'], 'description' => $v['description'],
                'category' => $v['category_name'], 'latitude' => $v['latitude'], 'longitude' => $v['longitude'],
            ], $geoHubId);
            $entityId = (int) $result['entity_id'];

            // Category: CrawlerIngest only writes the text 'category' key; search filters on category_id.
            // Same claimed-listing rule as CrawlerIngest's core fields: never overwrite an owner's choice.
            if ($v['category_id'] !== null) {
                $pdo->prepare("UPDATE entities SET category_id = :c WHERE id = :id AND (status = 'unclaimed' OR category_id IS NULL)")
                    ->execute(['c' => $v['category_id'], 'id' => $entityId]);
            }

            foreach (self::EXTRA_META_KEYS as $key => [$group, $field]) {
                $value = $v['meta'][$key] ?? null;
                if ($value === null || $value === '' || $value === []) continue;
                CrawlerIngest::upsertMetadataKey($pdo, $entityId, $key, $value);   // respects is_locked
            }

            $pdo->prepare(
                "UPDATE " . Database::t('crawler_raw_index') . " SET status = 'published', entity_id = :e, reviewed_payload = :p,
                        reviewed_by_user_id = :u, reviewed_at = NOW(), review_note = COALESCE(:n, review_note) WHERE id = :id"
            )->execute([
                'e' => $entityId, 'u' => $adminId, 'id' => $rowId, 'n' => $note,
                'p' => json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ]);
            return ['entity_id' => $entityId, 'action' => $result['action']];
        });
        require_once __DIR__ . '/../Identity.php';   // the listing's identity records what was written (decisions/0133)
        Identity::adopt($pdo, $rowId, (int) ($out['entity_id'] ?? 0));   // the sighting's evidence joins the listing
        Identity::syncFromListing($pdo, (int) ($out['entity_id'] ?? 0), 'ai_crawler', (int) $adminId, ['url' => (string) ($v['meta']['source_url'] ?? ''), 'kind' => ($v['meta']['source_url'] ?? '') !== '' ? Identity::kindFor((string) $v['meta']['source_url']) : 'crawler', 'label' => 'Where the crawler found it']);
        return $out;
    }

    /**
     * An admin's edit of a live listing (Admin → Edit listing). Same validation and limits as approving
     * (FIELD_RULES). Every value is written as a person's edit (source 'admin', locked), so the crawler never
     * overwrites it; emptied fields are removed. The ZIP isn't changed here, since that moves the listing
     * between clusters (Crawler → Places).
     */
    public static function adminSave(PDO $pdo, int $entityId, array $in, int $adminId): void
    {
        $e = self::existingListing($pdo, $entityId) ?? throw new InvalidArgumentException('That listing no longer exists.');
        $in['zip'] = $e['primary_zip'];
        $v = self::validate($pdo, $in);
        Database::transaction(function (PDO $pdo) use ($entityId, $v): void {
            $pdo->prepare("UPDATE entities SET name = ?, category_id = ?, latitude = COALESCE(?, latitude), longitude = COALESCE(?, longitude),
                                  updated_by_type = 'admin', updated_at = NOW() WHERE id = ?")
                ->execute([$v['name'], $v['category_id'], $v['latitude'], $v['longitude'], $entityId]);
            $values = ['address' => $v['address'], 'city' => $v['city'], 'state' => $v['state'], 'phone' => $v['phone'],
                       'description' => $v['description']] + array_diff_key($v['meta'], ['source_url' => 1]);
            $put = $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at)
                                  VALUES (?, ?, ?, 'admin', 1, NOW(), NOW())
                                  ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = 'admin', is_locked = 1, updated_at = NOW()");
            $del = $pdo->prepare('DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = ?');
            foreach ($values as $key => $value) {
                if ($value === null || $value === '' || $value === []) $del->execute([$entityId, $key]);
                else $put->execute([$entityId, $key, json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
            }
            return;
        });
        require_once __DIR__ . '/../Identity.php';
        Identity::syncFromListing($pdo, $entityId, 'admin', $adminId);   // staff's edit, recorded in the identity with them as its source
    }

    private static function isLink(string $s): bool
    {
        return (bool) preg_match('#^https?://[^\s]+$#i', trim($s));
    }

    /** Hides a listing from the public site, or brings it back. */
    public static function setSuppressed(PDO $pdo, int $entityId, bool $hidden): void
    {
        $pdo->prepare("UPDATE entities SET is_suppressed = ?, updated_by_type = 'admin', updated_at = NOW() WHERE id = ?")->execute([$hidden ? 1 : 0, $entityId]);
        // shown again: the one identity check (decisions/0164 §3.1); a twin live already makes the pair a step of the identity queue
        if (!$hidden) { require_once __DIR__ . '/../ListingIdentity.php'; try { ListingIdentity::writeKeys($pdo, $entityId); ListingIdentity::beforeShow($pdo, $entityId, true); } catch (Throwable $x) { error_log('identity on show: ' . $x->getMessage()); } }
    }

    /**
     * How each reviewed field lands on an existing listing when merging.
     *   core — a column on `entities`; written only while the listing is unclaimed (CrawlerIngest's rule)
     *   meta — one entity_metadata value; written through upsertMetadataKey(), so owner-locked keys are never touched
     *   list — an entity_metadata JSON list; "append" adds the new items to what's already there
     */
    public const MERGE_FIELDS = [
        'name' => ['core', 'name'], 'category_id' => ['core', 'category_id'], 'zip' => ['core', 'primary_zip'], 'pin' => ['core', 'latlon'],
        'address' => ['meta', 'address'], 'city' => ['meta', 'city'], 'state' => ['meta', 'state'], 'phone' => ['meta', 'phone'],
        'description' => ['meta', 'description'], 'email' => ['meta', 'email'], 'website' => ['meta', 'website'], 'whatsapp' => ['meta', 'whatsapp'],
        'contact_url' => ['meta', 'contact_url'],
        'hours' => ['list', 'hours'], 'service_area' => ['list', 'service_area'], 'offerings' => ['list', 'offerings'],
        'audience' => ['list', 'audience'], 'highlights' => ['list', 'highlights'], 'social' => ['list', 'social_links'],
    ];

    /** Everything already on a listing, for the side-by-side merge view — including what the owner entered. */
    public static function existingListing(PDO $pdo, int $entityId): ?array
    {
        $st = $pdo->prepare(
            "SELECT e.id, e.name, e.status, e.is_suppressed, e.primary_zip, e.latitude, e.longitude, e.category_id,
                    c.name AS category_name, mc.name AS cluster_name, e.created_by_type, e.updated_by_type, e.created_at, e.updated_at
               FROM entities e
               LEFT JOIN categories c ON c.id = e.category_id
               LEFT JOIN micro_clusters mc ON mc.id = e.micro_cluster_id
              WHERE e.id = :id AND e.entity_type = 'merchant' LIMIT 1"
        );
        $st->execute(['id' => $entityId]);
        $e = $st->fetch(PDO::FETCH_ASSOC);
        if ($e === false) return null;
        $e['id'] = (int) $e['id'];
        $e['claimed'] = $e['status'] !== 'unclaimed';

        // Who holds this listing (listing_access, columns confirmed live 2026-09-28)
        $a = $pdo->prepare(
            'SELECT la.access_level, la.created_at, u.id AS user_id, u.display_name, u.email, g.display_name AS granted_by
               FROM listing_access la
               JOIN users u ON u.id = la.user_id
               LEFT JOIN users g ON g.id = la.granted_by_user_id
              WHERE la.entity_id = :id
              ORDER BY la.access_level = \'owner\' DESC, la.created_at'
        );
        $a->execute(['id' => $entityId]);
        $e['access'] = array_map(fn ($r) => $r + ['user_id' => (int) $r['user_id']], $a->fetchAll(PDO::FETCH_ASSOC));

        $m = $pdo->prepare('SELECT meta_key, meta_value, source_type, is_locked, trust_score, updated_at FROM entity_metadata WHERE entity_id = :id ORDER BY meta_key');
        $m->execute(['id' => $entityId]);
        $e['meta'] = [];
        foreach ($m->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $val = json_decode((string) $row['meta_value'], true);
            $e['meta'][$row['meta_key']] = [
                'value' => $val === null && $row['meta_value'] !== 'null' ? $row['meta_value'] : $val,
                'source' => $row['source_type'],            // ai_crawler | user | owner | admin
                'locked' => (int) $row['is_locked'] === 1,   // a person edited it; crawler data never overwrites it
                'updated_at' => $row['updated_at'],
            ];
        }
        return $e;
    }

    /**
     * Merges a proposed listing into an existing one, field by field.
     * $choices: field => 'keep' | 'replace' | 'append' (lists only). Missing = keep.
     * @return array{entity_id:int,applied:string[],skipped:array<string,string>}
     */
    public static function merge(PDO $pdo, int $rowId, int $entityId, array $in, array $choices, ?int $adminId): array   // null: done on its own (decisions/0074)
    {
        // A link in Email is the contact or booking page (see validate()): move the value and the admin's choice with it.
        if (self::isLink((string) ($in['email'] ?? ''))) {
            if (trim((string) ($in['contact_url'] ?? '')) === '') {
                $in['contact_url'] = $in['email'];
                if (isset($choices['email']) && !isset($choices['contact_url'])) $choices['contact_url'] = $choices['email'];
            }
            $in['email'] = '';
            unset($choices['email']);
        }
        $choices = array_intersect_key($choices, self::MERGE_FIELDS);
        $active = array_filter($choices, fn ($c) => in_array($c, ['replace', 'append'], true));
        if (!$active) throw new InvalidArgumentException('Nothing selected to add. Choose "Use new" or "Add to" on at least one field, or reject.');
        // Only the fields being written are checked: a bad value the admin chose to keep out (e.g. a URL the crawler
        // took for an email) must not block the merge.
        foreach (array_keys(self::MERGE_FIELDS) as $f) {
            if (isset($active[$f])) continue;
            if ($f === 'pin') { unset($in['latitude'], $in['longitude']); continue; }
            unset($in[$f]);
        }
        $v = self::validate($pdo, $in, true);
        $geoHubId = isset($active['zip']) ? self::defaultGeoHubId($pdo) : 0;

        $out = Database::transaction(function (PDO $pdo) use ($rowId, $entityId, $v, $active, $adminId, $geoHubId): array {
            $row = $pdo->prepare('SELECT status FROM ' . Database::t('crawler_raw_index') . ' WHERE id = :id FOR UPDATE');
            $row->execute(['id' => $rowId]);
            $status = $row->fetchColumn();
            if ($status === false) throw new InvalidArgumentException('That proposed listing no longer exists.');
            if (!in_array($status, ['staged', 'quarantined'], true)) throw new InvalidArgumentException("This proposed listing was already $status.");

            $ent = $pdo->prepare("SELECT id, name, status, primary_zip, category_id FROM entities WHERE id = :id AND entity_type = 'merchant' FOR UPDATE");
            $ent->execute(['id' => $entityId]);
            $e = $ent->fetch(PDO::FETCH_ASSOC);
            if ($e === false) throw new InvalidArgumentException("Listing #$entityId doesn't exist.");
            $unclaimed = $e['status'] === 'unclaimed';

            $locks = [];
            $current = [];
            $m = $pdo->prepare('SELECT meta_key, meta_value, source_type, is_locked FROM entity_metadata WHERE entity_id = :id');
            $m->execute(['id' => $entityId]);
            foreach ($m->fetchAll(PDO::FETCH_ASSOC) as $r) {
                // Anything a person entered is protected, locked or not: upsertMetadataKey() would
                // re-label it source_type 'ai_crawler', so owner data could lose its attribution.
                $locks[$r['meta_key']] = (int) $r['is_locked'] === 1 || ($r['source_type'] !== null && $r['source_type'] !== 'ai_crawler');
                $current[$r['meta_key']] = json_decode((string) $r['meta_value'], true) ?? $r['meta_value'];
            }

            $applied = [];
            $skipped = [];
            $core = [];
            foreach ($active as $field => $choice) {
                [$kind, $target] = self::MERGE_FIELDS[$field];
                if ($kind === 'core') {
                    if ($field === 'category_id') {
                        if ($v['category_id'] === null) { $skipped[$field] = 'no category chosen'; continue; }
                        if (!$unclaimed && $e['category_id'] !== null) { $skipped[$field] = 'owner-controlled (listing is ' . $e['status'] . ')'; continue; }
                        $core['category_id'] = $v['category_id'];
                        if (empty($locks['category'])) CrawlerIngest::upsertMetadataKey($pdo, $entityId, 'category', $v['category_name']);
                    } elseif (!$unclaimed) {
                        $skipped[$field] = 'owner-controlled (listing is ' . $e['status'] . ')';
                        continue;
                    } elseif ($field === 'name') {
                        if ($v['name'] === '') { $skipped[$field] = 'empty'; continue; }
                        $core['name'] = $v['name'];
                    } elseif ($field === 'zip') {
                        if ($v['zip'] === '') { $skipped[$field] = 'empty'; continue; }
                        $core['primary_zip'] = $v['zip'];
                        $core['micro_cluster_id'] = CrawlerIngest::resolveMicroClusterId($pdo, $v['zip'], $geoHubId) ?: null;
                    } elseif ($field === 'pin') {
                        if ($v['latitude'] === null) { $skipped[$field] = 'no pin'; continue; }
                        $core['latitude'] = $v['latitude'];
                        $core['longitude'] = $v['longitude'];
                    }
                    $applied[] = $field;
                    continue;
                }

                if (!empty($locks[$target])) { $skipped[$field] = 'entered by a person, kept'; continue; }
                $new = $kind === 'list' ? ($field === 'social' ? $v['social'] : $v[$field]) : ($v['meta'][$target] ?? $v[$field] ?? null);
                if ($new === null || $new === '' || $new === []) { $skipped[$field] = 'empty'; continue; }
                if ($kind === 'list' && $choice === 'append') {
                    $old = $current[$target] ?? [];
                    $old = is_array($old) ? $old : (trim((string) $old) === '' ? [] : [(string) $old]);
                    $seen = [];
                    $merged = [];
                    foreach (array_merge($old, $new) as $item) {
                        $k = strtolower(trim((string) $item));
                        if ($k !== '' && !isset($seen[$k])) { $seen[$k] = true; $merged[] = $item; }
                    }
                    $new = array_slice($merged, 0, 100);
                }
                CrawlerIngest::upsertMetadataKey($pdo, $entityId, $target, $new);
                $applied[] = $field;
            }

            if ($core) {
                // Keep composite_hash in step with the new name/address/ZIP so the next crawl matches exactly —
                // unless another listing already holds that hash.
                $name = $core['name'] ?? $e['name'];
                $zip = $core['primary_zip'] ?? (string) $e['primary_zip'];
                $address = in_array('address', $applied, true) ? $v['address'] : (string) ($current['address'] ?? '');
                $hash = CrawlerIngest::computeCompositeHash($name, $address, $zip);
                $taken = $pdo->prepare('SELECT id FROM entities WHERE composite_hash = :h AND id <> :id LIMIT 1');
                $taken->execute(['h' => $hash, 'id' => $entityId]);
                if ($taken->fetchColumn() === false && $unclaimed) $core['composite_hash'] = $hash;

                $set = implode(', ', array_map(fn ($k) => "$k = :$k", array_keys($core)));
                $pdo->prepare("UPDATE entities SET $set, updated_by_type = 'ai_crawler', updated_at = NOW() WHERE id = :id")
                    ->execute($core + ['id' => $entityId]);
            }

            $pdo->prepare(
                "UPDATE " . Database::t('crawler_raw_index') . " SET status = 'merged', entity_id = :e, reviewed_payload = :p,
                        reviewed_by_user_id = :u, reviewed_at = NOW(), review_note = :n WHERE id = :id"
            )->execute([
                'e' => $entityId, 'u' => $adminId, 'id' => $rowId,
                'n' => mb_substr('Merged into #' . $entityId . ': ' . (implode(', ', $applied) ?: 'nothing'), 0, 500),
                'p' => json_encode(['fields' => $v, 'choices' => $active, 'applied' => $applied, 'skipped' => $skipped], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ]);
            // the names left behind are its other names (decisions/0084): the found one, or its old one when renamed
            try {
                require_once __DIR__ . '/../Aliases.php';
                $final = isset($core['name']) ? (string) $core['name'] : (string) $e['name'];
                $other = array_values(array_filter([(string) ($v['name'] ?? ''), (string) $e['name']], fn ($n) => $n !== '' && $n !== $final));
                if ($other) Aliases::add($pdo, $entityId, $other, $adminId ? 'admin' : 'ai_crawler');
            } catch (Throwable $x) { error_log('merge aliases: ' . $x->getMessage()); }
            return ['entity_id' => $entityId, 'applied' => $applied, 'skipped' => $skipped];
        });
        require_once __DIR__ . '/../Identity.php';   // the listing's identity records what was written (decisions/0133)
        Identity::adopt($pdo, $rowId, $entityId);   // the sighting's evidence joins the listing it's the same as
        Identity::syncFromListing($pdo, $entityId, 'ai_crawler', (int) $adminId, ['url' => (string) ($v['meta']['source_url'] ?? ''), 'kind' => ($v['meta']['source_url'] ?? '') !== '' ? Identity::kindFor((string) $v['meta']['source_url']) : 'crawler', 'label' => 'Where the crawler found it']);
        return $out;
    }

    public static function reject(PDO $pdo, int $rowId, string $note, ?int $adminId): void
    {
        $stmt = $pdo->prepare(
            "UPDATE " . Database::t('crawler_raw_index') . " SET status = 'rejected', review_note = :n, reviewed_by_user_id = :u, reviewed_at = NOW()
              WHERE id = :id AND status IN ('staged','quarantined')"
        );
        $stmt->execute(['n' => mb_substr($note, 0, 500) ?: null, 'u' => $adminId, 'id' => $rowId]);
        if ($stmt->rowCount() === 0) throw new InvalidArgumentException('That proposed listing was already reviewed.');
    }

    /** Server-side validation of the admin's edited form. Throws InvalidArgumentException with a field-specific message. */
    private static function validate(PDO $pdo, array $in, bool $partial = false): array
    {
        // $partial (merge): only fields the admin chose to write are checked, and none are required.
        $str = function (string $k, int $max, bool $required = false) use ($in, $partial): string {
            $s = trim((string) ($in[$k] ?? ''));
            if ($required && !$partial && $s === '') throw new InvalidArgumentException(ucfirst(str_replace('_', ' ', $k)) . ' is required.');
            if (mb_strlen($s) > $max) throw new InvalidArgumentException(ucfirst($k) . " is too long (max $max characters).");
            return $s;
        };
        $v = [
            'name' => $str('name', self::FIELD_RULES['name']['max'], true),
            'address' => $str('address', 255, trim((string) ($in['phone'] ?? '')) === ''),   // a phone and a town are enough (decisions/0164 §5.4, P3-1): placed at the town's middle, marked approximate
            'city' => $str('city', 120, true),
            'state' => strtoupper($str('state', 2, true)),
            'zip' => $str('zip', 5, true),
            'description' => $str('description', self::FIELD_RULES['description']['max']),
        ];
        if (($v['state'] !== '' || !$partial) && !preg_match('/^[A-Z]{2}$/', $v['state'])) throw new InvalidArgumentException('State must be a 2-letter code (AZ).');
        if (($v['zip'] !== '' || !$partial) && !preg_match('/^\d{5}$/', $v['zip'])) throw new InvalidArgumentException('ZIP must be 5 digits.');

        $phone = $str('phone', 30);
        $v['phone'] = $phone === '' ? null : (ListingExtractor::phone($phone) ?? throw new InvalidArgumentException('Phone must be a 10-digit US number.'));

        $v['latitude'] = $v['longitude'] = null;
        if (($in['latitude'] ?? '') !== '' && ($in['longitude'] ?? '') !== '') {
            $lat = filter_var($in['latitude'], FILTER_VALIDATE_FLOAT);
            $lon = filter_var($in['longitude'], FILTER_VALIDATE_FLOAT);
            if ($lat === false || $lon === false || abs($lat) > 90 || abs($lon) > 180) throw new InvalidArgumentException('Map pin coordinates are invalid.');
            $v['latitude'] = $lat; $v['longitude'] = $lon;
        }

        $v['category_id'] = null; $v['category_name'] = null;
        if (($in['category_id'] ?? '') !== '') {
            $stmt = $pdo->prepare('SELECT id, name FROM categories WHERE id = :id AND is_active = 1 AND parent_id IS NOT NULL LIMIT 1');
            $stmt->execute(['id' => (int) $in['category_id']]);
            $cat = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cat === false) throw new InvalidArgumentException('Pick a valid category.');
            $v['category_id'] = (int) $cat['id']; $v['category_name'] = $cat['name'];
        } elseif (!$partial) {
            throw new InvalidArgumentException('Pick a category before approving (search filters on it).');
        }

        // A web link typed into Email (a contact form or booking page, for places with no public email) is kept as
        // the "Contact or booking page" instead of being refused.
        $email = $str('email', 255);
        $contactUrl = $str('contact_url', 500);
        if (self::isLink($email)) { if ($contactUrl === '') $contactUrl = $email; $email = ''; }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Email is not valid. For a contact form or booking link, use "Contact or booking page".');
        if ($contactUrl !== '' && !self::isLink($contactUrl)) throw new InvalidArgumentException('Contact or booking page must start with http:// or https://');
        $website = $str('website', 500);
        if ($website !== '' && !preg_match('#^https?://[^\s]+$#i', $website)) throw new InvalidArgumentException('Website must start with http:// or https://');
        $whatsapp = $str('whatsapp', 30);
        $sourceUrl = $str('source_url', 500);

        $list = function (string $k) use ($in): array {
            $rule = self::FIELD_RULES[$k];
            $label = self::LIST_LABELS[$k];
            $raw = $in[$k] ?? [];
            if (is_string($raw)) $raw = preg_split('/\R/', $raw);
            $out = [];
            foreach ((array) $raw as $item) {
                // "• Cardiology", "- Cardiology", "1. Cardiology" -> "Cardiology"
                $item = trim((string) preg_replace('/^\s*(?:[\x{2022}\x{25CF}\x{25AA}\x{2023}*\-\x{2013}\x{2014}]+|\d+[.)])\s*/u', '', (string) $item));
                if ($item === '') continue;
                if (mb_strlen($item) > $rule['each']) {
                    throw new InvalidArgumentException("$label: each line can be up to {$rule['each']} characters, and this one is " . mb_strlen($item)
                        . ': "' . mb_strimwidth($item, 0, 50, '…') . '". ' . ($k === 'offerings' ? 'Keep just the service name here and move the detail to Description.' : 'Shorten it or split it into lines.'));
                }
                $out[] = $item;
            }
            $out = array_values(array_unique($out));
            if (count($out) > $rule['items']) throw new InvalidArgumentException("$label: up to {$rule['items']} lines (this has " . count($out) . ').');
            return $out;
        };
        foreach (self::LIST_FIELDS as $k) {
            $v[$k] = $list($k);
        }
        $v['meta'] = [
            'email' => $email ?: null, 'website' => $website ?: null,
            'whatsapp' => $whatsapp !== '' ? (ListingExtractor::phone($whatsapp) ?? throw new InvalidArgumentException('WhatsApp must be a 10-digit number.')) : null,
            'contact_url' => $contactUrl ?: null,
            'social_links' => $v['social'], 'hours' => $v['hours'], 'service_area' => $v['service_area'],
            'offerings' => $v['offerings'], 'audience' => $v['audience'], 'highlights' => $v['highlights'],
            'source_url' => $sourceUrl ?: null,
        ];
        return $v;
    }

    // ------------------------------------------------------------------
    // Listing for the review screen
    // ------------------------------------------------------------------

    public static function listRows(PDO $pdo, string $status, int $limit = 100, int $rowId = 0, bool $bestFirst = false): array
    {
        if (!in_array($status, ['staged', 'quarantined', 'published', 'merged', 'rejected'], true)) $status = 'staged';
        $stmt = $pdo->prepare(
            'SELECT r.id, r.source_id, r.source_url, r.raw_payload, r.reviewed_payload, r.confidence_score, r.status,
                    r.matched_entity_id, r.entity_id, r.review_note, r.reviewed_at, r.created_at,
                    s.url AS source_start_url, s.purposes AS source_purposes, s.rationale AS source_rationale
               FROM ' . Database::t('crawler_raw_index') . ' r LEFT JOIN ' . Database::t('crawler_sources') . ' s ON s.id = r.source_id
              WHERE r.status = :st AND r.payload_type = \'listing\'' . ($rowId > 0 ? ' AND r.id = ' . $rowId : '') . '
              ORDER BY ' . ($bestFirst ? 'r.confidence_score DESC, r.id ASC' : 'r.source_id DESC, r.id ASC') . '
              LIMIT ' . max(1, min(500, $limit))
        );
        $stmt->execute(['st' => $status]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) {
            $r['payload'] = json_decode((string) $r['raw_payload'], true);
            $r['reviewed'] = $r['reviewed_payload'] !== null ? json_decode((string) $r['reviewed_payload'], true) : null;
            unset($r['raw_payload'], $r['reviewed_payload']);
            foreach (['id', 'source_id', 'confidence_score', 'matched_entity_id', 'entity_id'] as $k) {
                $r[$k] = $r[$k] === null ? null : (int) $r[$k];
            }
        }
        return $rows;
    }
}
