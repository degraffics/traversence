-- decisions/0171 §4 (the System Control Board, release 2a): the ledger and the records each call touched.
-- control_ledger: one row per call a worker makes to the site (/api/crawl/*, /api/video/*): what it handed out, received,
-- stored, updated, sent to Review and refused (refusals by reason), its answer code, how long it took, the crawler run.
-- control_records: the ids of the records each call touched, at most control_records_per_call (the rest counted).
-- Ids and counts only: never a person's name, email, phone or a page's text. Both kept a set number of days
-- (Thresholds: control_ledger_days, control_records_days), trimmed in small batches. Staging class: follows.
-- Add-only and safe to run twice.
CREATE TABLE IF NOT EXISTS control_ledger (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  at DATETIME NOT NULL,
  endpoint VARCHAR(40) NOT NULL,
  method VARCHAR(6) NOT NULL DEFAULT 'GET',
  code SMALLINT NOT NULL DEFAULT 200,
  ms INT NOT NULL DEFAULT 0,
  run_id INT NULL,
  sent INT NOT NULL DEFAULT 0,
  received INT NOT NULL DEFAULT 0,
  stored INT NOT NULL DEFAULT 0,
  updated INT NOT NULL DEFAULT 0,
  review INT NOT NULL DEFAULT 0,
  refused INT NOT NULL DEFAULT 0,
  reasons VARCHAR(500) NULL,
  records INT NOT NULL DEFAULT 0,
  KEY ep_at (endpoint, at),
  KEY run (run_id),
  KEY at (at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS control_records (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ledger_id BIGINT UNSIGNED NOT NULL,
  at DATETIME NOT NULL,
  kind VARCHAR(20) NOT NULL,
  ref_id BIGINT NOT NULL,
  what VARCHAR(60) NOT NULL,
  KEY ledger (ledger_id),
  KEY ref (kind, ref_id),
  KEY at (at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
