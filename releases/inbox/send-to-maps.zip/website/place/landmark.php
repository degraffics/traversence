<?php
// /place/landmark.php?id=924849 — one natural landmark (decisions/0058 §24): badlands, an arch, a canyon, a butte. The
// name and location are from USGS Geographic Names (GNIS); the description from Wikidata and Wikipedia; the photo from
// Wikimedia Commons, credited. On a sovereign nation's land it shows only after a person confirmed the nation welcomes
// visitors there, and it says so. Content page standard (§20): hero, header, Engage bar, comments.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/Landmarks.php';
require_once __DIR__ . '/../../app/lib/Nations.php';

$pdo = Database::connection();
$id = (int) ($_GET['id'] ?? 0);
$r = $id > 0 ? Landmarks::get($pdo, $id) : null;
// story only (0164 R7, P5-3): publicly known but held for a word in its name, so it's named and told, never placed: no
// pin, coordinates, map, directions, distance, nearest town, photos near it, pairs or outing
$story = !$r && $id > 0 ? Landmarks::story($pdo, $id) : null;
if ($story) {
    $name = (string) $story['name'];
    tv_page_start($name, ['no_crumbs' => true]);
    tv_count_item('landmark:' . $id);
    $kind = Landmarks::kindLabel($story);
    $about = Landmarks::about($pdo, $story);
    $region = $story['nation'] === '' && (string) $story['state'] !== '' ? (string) $story['state'] : '';   // the state only: never the way in
    ?>
  <div class="max-w-2xl" style="margin-top:.8rem">
    <article class="tv-bleed" style="position:relative;background:var(--tv-card-a);border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.8rem .9rem .9rem" data-link-host>
      <span data-link="place:lm:<?= (int) $id ?>" data-link-label="<?= tv_e($name) ?>"></span>
      <p style="font-size:.7rem;letter-spacing:.09em;text-transform:uppercase;color:var(--tv-meta);margin:0;padding-right:2.6rem"><?= tv_e($kind) ?><?= $region !== '' ? ' · ' . tv_e($region) : '' ?></p>
      <h1 class="font-serif font-bold text-2xl" style="margin:.2rem 0 .4rem;padding-right:2.6rem"><?= tv_e($name) ?></h1>
      <?php if ($about !== ''): ?><p style="font-size:.93rem;line-height:1.6;color:var(--tv-ink);margin:0"><?= tv_e($about) ?></p><?php endif; ?>
      <p data-tv-status="info" data-tv-label="Told, not placed:" style="margin:.7rem 0 0"><?= tv_e(Landmarks::COURTESY) ?></p>
      <p style="font-size:.72rem;color:var(--tv-meta);margin-top:.6rem;line-height:1.5">Told from public sources (<?= $story['file'] === 'wikidata' ? 'Wikidata, CC0' : ($story['file'] === 'manual' ? 'Traversence' : 'USGS Geographic Names') ?><?= $story['wiki_title'] !== '' ? '; Wikipedia, CC BY-SA' : '' ?>). <a href="/takedown.php?kind=landmark&amp;ref=<?= (int) $id ?>" rel="nofollow" style="color:var(--tv-link)">Ask us to take this down</a></p>
    </article>
  </div>
<?php
    tv_page_end(); exit;
}
$name = $r ? (string) $r['name'] : 'Place not found';
if (!$r) http_response_code(404);   // gone, hidden, or kept until the nation tools (decisions/0058 §27)
tv_page_start($name, ['no_crumbs' => true]);
if ($r) tv_count_item('landmark:' . $id);   // the platform's counts
if (!$r): ?>
  <div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Place not found</h1><p class="text-sm text-[color:var(--tv-meta)] mt-2">It may no longer be listed.</p></div>
<?php tv_page_end(); exit; endif;

$kind = Landmarks::kindLabel($r);
$lat = (float) $r['lat']; $lon = (float) $r['lon'];
$where = $r['near_town'] !== '' ? $r['near_town'] . ', ' . $r['state'] : '';
$in = $where !== '' ? ' near ' . $r['near_town'] : '';
$q = fn (string $words) => tv_e($words . $in);   // what a tap searches for: "Badlands near Farmington"
$plural = fn (string $k) => preg_match('/s$/i', $k) ? $k : (preg_match('/y$/i', $k) ? substr($k, 0, -1) . 'ies' : $k . 's');
$dist = 0.0;
if ($where !== '') {
    $st = $pdo->prepare('SELECT latitude, longitude FROM zip_coordinates WHERE zip = ? LIMIT 1');
    $st->execute([$r['zip5']]);
    if ($z = $st->fetch(PDO::FETCH_NUM)) $dist = Landmarks::miles($lat, $lon, (float) $z[0], (float) $z[1]);
}
$nation = $r['nation'] !== '' ? Nations::byShape($pdo, (string) $r['nation']) : null;   // the nation's own name and its rules (decisions/0058 §26)
$nationName = $r['nation'] !== '' ? Nations::label($pdo, (string) $r['nation']) : '';
$nearLine = $nationName !== '' ? 'On ' . $nationName . ' land' : ($where !== '' ? ($dist >= 1.5 ? 'About ' . (int) round($dist) . ' mi from ' . $where : 'In ' . $where) : $r['county'] . ' County, ' . $r['state']);
$dir = 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($lat . ',' . $lon);
$about = Landmarks::about($pdo, $r);   // Wikipedia is cited with a link, never copied (its rule: decisions/0133)
if (trim((string) ($r['extract'] ?? '')) === '' && trim((string) ($r['research'] ?? '')) === '') { require_once __DIR__ . '/../../app/lib/PlaceFinder.php'; PlaceFinder::wantAbout($pdo, (int) $r['gnis_id']); }   // opened with nothing written: Claude writes it, once (2026-11-10)
$acts = Landmarks::activities($r);
// outdoors (a peak, a trail, water, a campground; GNIS's natural features) gets the leave-no-trace care and the land
// manager line; a district, a museum or a house doesn't (2026-11-10)
$outdoorPlace = (bool) array_intersect($acts, ['hike', 'water', 'camp', 'views']) || !in_array((string) $r['file'], ['wikidata', 'manual'], true);
require_once __DIR__ . '/../../app/lib/Guides.php';
$guideLine = Guides::lineAbout($pdo, 'landmark:' . (int) $id, (string) $name);   // what the guide says about it (2026-11-10)
$wiki = $r['wiki_title'] !== '' ? 'https://en.wikipedia.org/wiki/' . rawurlencode(str_replace(' ', '_', (string) $r['wiki_title'])) : '';
$credit = $r['image_url'] !== '' ? 'Photo: ' . ($r['image_credit'] !== '' ? $r['image_credit'] : 'Wikimedia Commons') . ', ' . $r['image_license'] : '';

require_once __DIR__ . '/../../app/ui/explore-hero.php';
require_once __DIR__ . '/../../app/ui/engage-ui.php';
$share = '/user/journeys/compose.php?' . http_build_query(['about' => $name, 'pin' => $lat . ',' . $lon]);   // "Share a photo": a journey with the place filled in (decisions/0058 §30)
echo tv_explore_hero($pdo, ['name' => $name, 'heading' => $name, 'edit' => false, 'photos_of' => $name, 'share' => $share, 'share_label' => 'Share a photo',
    'slides' => $r['image_url'] !== '' ? [['image' => (string) $r['image_url'], 'caption' => $credit]] : null, 'near' => [$lat, $lon], 'own_last' => true,   // journeys shared there first, then its Commons photo (decisions/0058 §31)
    'sub' => implode(' · ', array_filter([$kind, $nearLine])),
    'actions' => tv_engage_bar($pdo, 'lm', (string) $id, ['title' => $name, 'fold' => true, 'tools' => ['trip' => ['lat' => $lat, 'lon' => $lon]]])]);   // ⋯ (2026-11-19)
?>
<style>
  .lm{max-width:46rem;margin-top:.8rem}
  .lm-card{position:relative;background:var(--tv-card-a);border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.8rem .55rem .9rem .9rem}
  .lm-kick{display:flex;flex-wrap:wrap;gap:.15rem .5rem;font-size:.7rem;letter-spacing:.09em;text-transform:uppercase;color:var(--tv-meta);padding-right:2.6rem;margin:0}
  .lm-q{background:none;border:0;padding:0;font:inherit;text-align:left;letter-spacing:inherit;text-transform:inherit;color:var(--tv-link);cursor:pointer;text-decoration:underline;text-decoration-color:rgba(146,64,14,.3);text-underline-offset:3px}
  .lm-body{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:.75rem;margin-top:.5rem;align-items:start}
  .lm-acts{grid-column:2;grid-row:1;display:flex;flex-direction:column;gap:.3rem}.lm-info{grid-column:1;grid-row:1}
  .lm-a{display:flex;align-items:center;justify-content:center;width:30px;height:30px;color:var(--tv-icon,#B45309);background:var(--tv-field);border:1px solid var(--tv-line-strong);border-radius:999px;cursor:pointer;padding:0;text-decoration:none}
  .lm-a svg{width:17px;height:17px}.lm-a:hover{border-color:var(--tv-icon,#B45309);background:var(--tv-hold-bg)}
  .lm-sum{font-size:.93rem;line-height:1.6;color:var(--tv-ink);margin:0}
  .lm-nation{font-size:.86rem;line-height:1.5;background:var(--tv-canvas);border-left:3px solid var(--tv-line-strong);border-radius:.4rem;padding:.5rem .65rem;margin:.7rem 0 0;color:var(--tv-ink)}.lm-nation p{margin:0}.lm-nation a{color:var(--tv-link);text-decoration:underline}
  .lm-rules{margin:.45rem 0 0;display:grid;gap:.3rem}.lm-rules dt{font-weight:700;font-size:.78rem;color:var(--tv-meta)}.lm-rules dd{margin:0}.lm-rsrc{font-size:.74rem !important;color:var(--tv-meta);margin-top:.4rem !important}
  .lm-care{font-size:.84rem;color:var(--tv-meta);margin:.6rem 0 0}
  .lm-dl{font-size:.86rem;margin-top:.7rem;display:grid;gap:.15rem}.lm-dl dt{display:inline;color:var(--tv-meta)}.lm-dl dd{display:inline;margin:0}
  .lm-src{font-size:.72rem;color:var(--tv-meta);margin-top:.6rem;line-height:1.5}.lm-src a{color:var(--tv-link)}
  /* the action icons: a column under the Link button, the same 30px, the same right edge, .3rem apart (decisions/0058 §11) */
  .lm-card{min-height:11.5rem}
  .lm-body{display:block !important}.lm-info{padding-right:2.6rem}
  .lm-acts{position:absolute;top:calc(.55rem + 30px + .3rem);right:.55rem;display:flex;flex-direction:column;gap:.3rem;z-index:4}
</style>
<div class="lm">
  <article class="lm-card tv-bleed" data-link-host>
    <span data-link="place:lm:<?= $id ?>" data-link-label="<?= tv_e($name) ?>"></span>
    <p class="lm-kick">
      <button type="button" class="lm-q" data-q="<?= $q($plural($kind)) ?>" title="Find more <?= tv_e(mb_strtolower($plural($kind))) ?><?= tv_e($in) ?>"><?= tv_e($kind) ?></button>
      <?php if ($r['county'] !== ''): ?><span aria-hidden="true">·</span><button type="button" class="lm-q" data-q="<?= tv_e('outdoors in ' . $r['county'] . ' County ' . $r['state']) ?>" title="More outdoors in <?= tv_e($r['county']) ?> County"><?= tv_e($r['county']) ?> County</button><?php endif; ?>
    </p>
    <div class="lm-body"><div class="lm-acts" aria-label="Map and directions">
      <button type="button" class="lm-a" id="lm-map" title="See on map" aria-label="See on map"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><path d="M8 2v16M16 6v16"/></svg></button>
      <a class="lm-a" href="<?= tv_e($dir) ?>" target="_blank" rel="noopener" title="Get directions" aria-label="Get directions"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg></a>
      <?php if ($wiki): ?><a class="lm-a" href="<?= tv_e($wiki) ?>" target="_blank" rel="noopener" title="Read more on Wikipedia" aria-label="Read more on Wikipedia"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/></svg></a><?php endif; ?>
    </div><div class="lm-info">
      <?php if ($acts): ?><p class="lm-do" style="display:flex;flex-wrap:wrap;gap:.35rem;margin:.2rem 0 .4rem"><?php foreach ($acts as $a): ?><span title="<?= tv_e(Landmarks::ACTIVITIES[$a][1]) ?>" style="font-size:.8rem;font-weight:700;border-radius:999px;padding:.15rem .6rem;background:color-mix(in srgb,var(--tv-moss) 18%,var(--tv-canvas));color:color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink))"><?= tv_e(Landmarks::ACTIVITIES[$a][0]) ?></span><?php endforeach; ?></p><p class="lm-sum" style="margin-top:0"><?= tv_e(Landmarks::ACTIVITIES[$acts[0]][1]) ?></p><?php endif; ?>
      <?php if ($about !== ''): ?><p class="lm-sum"><?= tv_e($about) ?></p><?php else: ?><p class="lm-sum">A <?= tv_e(mb_strtolower($kind)) ?><?= $where !== '' ? ' near ' . tv_e($r['near_town']) : '' ?>. Been there? Tell people what it's like in the comments.</p><?php endif; ?>
      <?php if ($r['nation'] !== ''): $rules = Nations::rules($nation); $vl = Nations::visitorLink($nation); ?>
        <div class="lm-nation">
          <p>This is on <?= tv_e($nationName) ?> land. Tribal nations are sovereign nations, with their own laws and permits; the nation welcomes visitors here<?= $r['evidence_url'] !== '' ? ' (<a href="' . tv_e($r['evidence_url']) . '" target="_blank" rel="noopener">its page</a>)' : '' ?>. Stay where it welcomes visitors.</p>
          <?php if ($rules): ?><dl class="lm-rules"><?php foreach ($rules as [$rl, $rt]): ?><div><dt><?= tv_e($rl) ?></dt><dd><?= nl2br(tv_e($rt)) ?></dd></div><?php endforeach; ?></dl>
            <p class="lm-rsrc">The nation's rules, checked <?= tv_e(date('M Y', strtotime((string) $nation['verified_at']))) ?><?= $vl ? ' · <a href="' . tv_e($vl) . '" target="_blank" rel="noopener">its visitor information</a>' : '' ?>.</p>
          <?php else: ?><p>Before you go, check the nation's own visitor information for permits, fees, guides, and photography and drone rules<?= $vl ? ': <a href="' . tv_e($vl) . '" target="_blank" rel="noopener">' . tv_e($nationName) . ' visitor information</a>' : '' ?>.</p><?php endif; ?>
        </div>
      <?php endif; ?>
      <?php if ($guideLine): ?><blockquote style="margin:.6rem 0;padding:.5rem .7rem;border-left:3px solid var(--tv-sage);background:color-mix(in srgb,var(--tv-moss) 18%,var(--tv-canvas));font-size:.9rem;line-height:1.45">&ldquo;<?= tv_e($guideLine['line']) ?>&rdquo; <a href="<?= tv_e($guideLine['url']) ?>" style="display:block;margin-top:.25rem;font-size:.8rem;font-weight:700;color:var(--tv-link)">From <?= tv_e($guideLine['title']) ?> &rsaquo;</a></blockquote><?php endif; ?>
      <p style="font-size:.86rem;margin:.5rem 0 0"><a href="#comments" style="color:var(--tv-link);font-weight:600">Add a tip or review</a> &middot; <button type="button" class="underline" style="color:var(--tv-link);font-weight:600" data-tv-suggest="<?= tv_e(json_encode(['target' => 'landmark:' . $id, 'target_name' => $name, 'topic' => 'outdoors'], JSON_UNESCAPED_UNICODE)) ?>">Suggest a change</button></p>
      <?php if ($outdoorPlace): ?><p class="lm-care">Leave it as you found it: stay on durable ground, pack out what you bring, and take only photos.</p><?php endif; ?>
      <dl class="lm-dl">
        <?php if ($where !== ''): ?><div><dt>Nearest town:</dt> <dd><?= tv_e($where) ?></dd></div><?php endif; ?>
        <?php if ($r['county'] !== ''): ?><div><dt>County:</dt> <dd><?= tv_e($r['county'] . ', ' . $r['state']) ?></dd></div><?php endif; ?>
      </dl>
      <p class="lm-src"><?php if ($r['file'] === 'wikidata'): ?>Name, location and description: <a href="https://www.wikidata.org/wiki/<?= tv_e((string) $r['qid']) ?>" target="_blank" rel="noopener">Wikidata</a> (CC0). <?= $wiki ? 'More on <a href="' . tv_e($wiki) . '" target="_blank" rel="noopener">Wikipedia</a> (CC BY-SA). ' : '' ?><?php elseif ($r['file'] === 'manual'): ?>Added by Traversence. <?= $wiki ? 'More on <a href="' . tv_e($wiki) . '" target="_blank" rel="noopener">Wikipedia</a>. ' : '' ?><?php else: ?>Name and location: USGS Geographic Names. <?= $wiki ? 'Description: <a href="' . tv_e($wiki) . '" target="_blank" rel="noopener">Wikipedia</a> (CC BY-SA). ' : ($r['wd_desc'] !== '' ? 'Description: Wikidata. ' : '') ?><?php endif; ?>
        <?= $credit !== '' ? tv_e($credit) . ($r['image_page'] !== '' ? ', <a href="' . tv_e($r['image_page']) . '" target="_blank" rel="noopener">Wikimedia Commons</a>' : '') . '. ' : '' ?>
        <?= $outdoorPlace ? 'Conditions change: check with the land manager before you go. ' : '' ?><a href="/takedown.php?kind=landmark&amp;ref=<?= (int) $id ?>" rel="nofollow">Ask us to take this down</a>
        <button type="button" class="underline" data-tv-suggest="<?= tv_e(json_encode(['target' => 'landmark:' . $id, 'target_name' => $name, 'topic' => 'outdoors'], JSON_UNESCAPED_UNICODE)) ?>">Something wrong, or shouldn't be shown? Tell us</button></p>
    </div></div>
  </article>
  <?php
  // what pairs with it, and a day made of them (2026-11-10, "the mission is immersion and connecting")
  $pairs = []; $day = null;
  try { $pairs = Landmarks::pairs($pdo, $r, 3); $day = Landmarks::outing($pdo, $r, $pairs); } catch (Throwable $e) { error_log('pairs ' . $id . ': ' . $e->getMessage()); }
  if ($pairs): ?>
  <section class="lm-card tv-bleed" style="margin-top:.6rem;min-height:0" aria-labelledby="lm-pairs-h">
    <h2 id="lm-pairs-h" style="font-size:.78rem;letter-spacing:.09em;text-transform:uppercase;color:var(--tv-meta);margin:0 0 .4rem">Pairs with</h2>
    <?php foreach ($pairs as $x): $xa = Landmarks::about($pdo, $x); ?>
      <div style="padding:.4rem 0;border-top:1px solid rgba(203,185,141,.45)">
        <a href="/place/landmark.php?id=<?= (int) $x['gnis_id'] ?>" style="color:var(--tv-link);font-weight:700;text-decoration:underline;text-underline-offset:3px"><?= tv_e((string) $x['name']) ?></a>
        <span style="font-size:.8rem;color:var(--tv-meta)"> · <?= tv_e(Landmarks::kindLabel($x)) ?> · <?= $x['miles'] < 1 ? 'under a mile' : round($x['miles']) . ' mi' ?></span>
        <?php if ($xa !== ''): ?><p style="font-size:.86rem;line-height:1.45;color:var(--tv-ink);margin:.15rem 0 0"><?= tv_e(mb_strlen($xa) > 150 ? rtrim(mb_substr($xa, 0, 147)) . '…' : $xa) ?></p><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </section>
  <?php endif; if ($day): ?>
  <section class="lm-card tv-bleed" style="margin-top:.6rem;min-height:0" aria-labelledby="lm-day-h">
    <h2 id="lm-day-h" style="font-size:.78rem;letter-spacing:.09em;text-transform:uppercase;color:var(--tv-meta);margin:0 0 .4rem">Make a day of it</h2>
    <ol style="margin:0;padding-left:1.2rem;font-size:.9rem;line-height:1.5;color:var(--tv-ink)">
      <?php foreach ($day['stops'] as $i => $s): ?>
        <li style="margin:.2rem 0"><?= $s['url'] !== '' ? '<a href="' . tv_e($s['url']) . '" style="color:var(--tv-link);font-weight:600;text-decoration:underline">' . tv_e($s['label']) . '</a>' : '<b>' . tv_e($s['label']) . '</b>' ?>
          <span style="font-size:.8rem;color:var(--tv-meta)"> · <?= tv_e($s['sub']) ?><?= $i ? ' · ' . ($s['leg'] < 1 ? 'under a mile on' : round($s['leg']) . ' mi on') : '' ?><?= !empty($s['osm']) ? ' · from OpenStreetMap' : '' ?></span></li>
      <?php endforeach; ?>
    </ol>
    <p style="font-size:.86rem;margin:.45rem 0 0">About <?= max(1, (int) round($day['miles'])) ?> mi in all. <?php require_once __DIR__ . '/../../app/ui/maps-send.php'; $mAttrs = tv_maps_attrs($day['stops'], $r['name'] . ': a day out'); ?><?php if ($mAttrs !== ''): ?><?= tv_maps_script() ?><a <?= $mAttrs ?> aria-haspopup="dialog" style="color:var(--tv-link);font-weight:600;text-decoration:underline">Send to Maps</a><?php else: ?><a href="<?= tv_e($day['route']) ?>" target="_blank" rel="noopener" data-out="directions" style="color:var(--tv-link);font-weight:600;text-decoration:underline">Open the route in Maps</a><?php endif; ?></p>
    <?php if (array_filter($day['stops'], fn ($s) => !empty($s['osm']))): ?><p class="lm-src" style="margin-top:.35rem">The place to eat is from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors (ODbL), not a Traversence listing.</p><?php endif; ?>
  </section>
  <?php endif; ?>
</div>
<script>
  (function () {
    document.querySelector('.lm').addEventListener('click', function (e) {
      var b = e.target.closest('[data-q]'); if (b && window.TvSearch) TvSearch.open(b.getAttribute('data-q'));
    });
    // See on map: this landmark and the outdoors around it (10 mi), with this one chosen
    var m = document.getElementById('lm-map');
    if (m) m.addEventListener('click', function () {
      if (!window.TvMap) return;
      var here = { lat: <?= $lat ?>, lon: <?= $lon ?>, radius: 10 }, id = <?= json_encode('rec:g' . str_pad((string) $id, 10, '0', STR_PAD_LEFT)) ?>;
      TvMap.open({ panel: true, title: <?= json_encode($name) ?>, radius: 10, select: id,
        titleFor: function () { return 'Outdoor places around ' + <?= json_encode($name) ?>; },
        load: function (area, words) {
          var a = area || here, qs = new URLSearchParams({ pins: 1, kinds: words ? 'listing,outdoors' : 'outdoors', lat: a.lat, lon: a.lon, radius: a.radius });
          if (words) qs.set('q', words);
          return fetch('/api/search.php?' + qs.toString(), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
            if (!(d.pins || []).some(function (p) { return p.id === id; })) (d.pins = d.pins || []).push({ id: id, lat: here.lat, lon: here.lon, name: <?= json_encode($name) ?>, category: <?= json_encode($kind) ?> });
            d.center = a; return d;
          });
        }
      });
    });
  })();
</script>
<?php require_once __DIR__ . '/../../app/ui/featured-in.php'; echo tv_featured_in($pdo, 'landmark:' . (int) $id);   // what names it (decisions/0132) ?>
<?= tv_engage_comments($pdo, 'lm', (string) $id) ?>
<script src="/js/link-button.js?v=<?= (int) @filemtime(__DIR__ . '/../js/link-button.js') ?>" defer></script>
<?php tv_page_end();
