<?php
// app/ui/suggested-journeys.php — how a suggested journey looks (decisions/0146): on a guide (a card each, the stops
// folded) and on its own page (/journeys/suggested.php?id=). Each stop: the time, the name (its page), what it is and how
// long, its hours; between stops the time and distance (ours, from travel_legs, "about" when estimated); Directions to
// each, and the whole route in the visitor's own maps app. Labelled "Suggested by Traversence"; OpenStreetMap credited
// where its times show.
declare(strict_types=1);

require_once __DIR__ . '/../lib/Hours.php';
require_once __DIR__ . '/maps-send.php';

function tv_sj_css(): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    return '<style>
  .sj-list{display:grid;gap:.55rem}
  .sj{position:relative;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.8rem;padding:.7rem .8rem}
  .sj-by{font:700 .68rem system-ui,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#5E8F77}
  .sj-t{display:block;font:700 1.05rem/1.3 var(--tv-font-head,Georgia,serif);color:#92400E;text-decoration:underline;margin:.1rem 0 .2rem;padding-right:2.4rem}
  .sj-why{color:#3E2B1F;font-size:.9rem;line-height:1.5;margin:0 0 .3rem}
  .sj-meta{font-size:.8rem;color:#5C4632}
  .sj-route{position:absolute;top:.6rem;right:.6rem;width:30px;height:30px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;border:1px solid #CBB98D;background:#FFFBF2;color:#B45309}
  .sj-route svg,.sj-acts svg{width:15px;height:15px}
  .sj details>summary{cursor:pointer;font-weight:700;color:#92400E;font-size:.88rem;margin-top:.35rem}
  .sj-stops{list-style:none;margin:.4rem 0 0;padding:0}
  .sj-stop{display:flex;gap:.6rem;align-items:flex-start;background:#F7EFDC;border:1px solid #EADFC4;border-radius:.6rem;padding:.45rem .55rem}
  .sj-time{flex:0 0 4.2rem;font:700 .85rem var(--tv-font-head,Georgia,serif);color:#3E2B1F}
  .sj-body{flex:1;min-width:0}.sj-body a.sj-n{font-weight:700;color:#92400E;text-decoration:underline}.sj-body small{display:block;color:#5C4632;font-size:.78rem}
  .sj-acts{display:flex;flex-direction:column;gap:.3rem}.sj-acts a{width:30px;height:30px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;border:1px solid #CBB98D;background:#FFFBF2;color:#B45309}
  .sj-leg{font-size:.76rem;color:#8A7355;padding:.25rem 0 .25rem 4.8rem}
  .sj-note{font-size:.76rem;color:#8A7355;margin:.4rem 0 0}.sj-note a{text-decoration:underline}
  @media (max-width:767px){ .sj-list{gap:3px} .sj{border-radius:.5rem} .sj-time{flex-basis:3.6rem} .sj-leg{padding-left:4.2rem} }
</style>';
}

/** minutes => "about 6 hours", "45 min" */
function tv_sj_span(int $m): string
{
    if ($m < 60) return $m . ' min';
    $h = round($m / 30) / 2;
    return ($h == (int) $h ? (int) $h : $h) . ' hour' . ($h == 1 ? '' : 's');
}

/** The whole route in the visitor's own maps app (decisions/0058 §8): without script, Google's first ten stops; with it,
 * Send to Maps (decisions/0174 §4, app/ui/maps-send.php) offers Google or Apple and every stop, in legs. */
function tv_sj_route_url(array $stops): string
{
    require_once __DIR__ . '/maps-send.php';
    return tv_maps_fallback(tv_maps_stops($stops));
}

/** One journey: a card on a guide ($full false, stops folded) or the whole page's list ($full true). */
function tv_sj_card(array $j, bool $full = false): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
    $ic = fn (string $p) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
    $stops = (array) $j['stops'];
    $route = tv_sj_route_url($stops);
    $osm = false; $line = false; $osmPlace = false;
    $list = '<ol class="sj-stops">';
    foreach ($stops as $i => $s) {
        if (!empty($s['leg'])) {
            $lg = $s['leg']; if (($lg['source'] ?? '') === 'ors') $osm = true; else $line = true;
            $list .= '<li class="sj-leg">' . (($lg['source'] ?? '') === 'ors' ? '' : 'about ') . (int) $lg['minutes'] . ' min ' . ($lg['mode'] === 'walk' ? 'walk' : 'drive') . ((float) $lg['miles'] >= .1 ? ' · ' . $e(number_format((float) $lg['miles'], 1)) . ' mi' : '') . '</li>';
        }
        $id = preg_match('/^entity:(\d+)$/', (string) $s['ref'], $m) ? (int) $m[1] : 0;
        $isOsm = str_starts_with((string) $s['ref'], 'osm:'); if ($isOsm) $osmPlace = true;
        $dir = 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode(($s['address'] ?? '') !== '' ? (string) $s['address'] : round((float) $s['lat'], 6) . ',' . round((float) $s['lon'], 6));
        $hours = ['unknown' => 'Hours not known: check before you go', 'daylight' => 'Daylight hours', 'open' => 'Open then'][$s['hours']] ?? '';
        $list .= '<li class="sj-stop"><span class="sj-time">' . $e(Hours::clock((int) $s['arrive'])) . '</span><div class="sj-body"><a class="sj-n" href="' . $e($s['url']) . '"' . ($isOsm ? ' target="_blank" rel="noopener"' : '') . '>' . $e($s['name']) . '</a>'
            . '<small>' . $e(implode(' · ', array_filter([(string) $s['sub'], tv_sj_span((int) $s['stay'])]))) . '</small>' . ($hours !== '' ? '<small>' . $e($hours) . '</small>' : '') . '</div>'
            . '<span class="sj-acts"><a href="' . $e($dir) . '" target="_blank" rel="noopener" title="Directions" aria-label="Directions to ' . $e($s['name']) . '" data-out="directions"' . ($id ? ' data-e="' . $id . '"' : '') . '>' . $ic('<polygon points="3 11 22 2 13 21 11 13 3 11"/>') . '</a></span></li>';
    }
    $list .= '</ol>';
    $n = count($stops);
    $meta = $n . ' stop' . ($n === 1 ? '' : 's') . ' · about ' . tv_sj_span((int) $j['minutes']) . ((float) $j['miles'] > 0 ? ' · ' . number_format((float) $j['miles'], 1) . ' mi' : '');
    $notes = 'Timed for a Saturday' . (!empty($j['sunset']) ? '; sunset about ' . $e(Hours::clock((int) $j['sunset'])) : '') . '. Check hours before you go.'
        . ($osmPlace ? ' Places marked from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>.' : '')
        . ($osm ? ' Travel times © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors' . ($line ? '; "about" times are estimates' : '') . '.' : ($line ? ' Travel times are estimates.' : ''));
    return '<article class="sj tv-bleed"><span class="sj-by">Suggested by Traversence</span>'
        . ($full ? '<h2 class="sj-t" style="text-decoration:none;color:#3E2B1F">' . $e($j['title']) . '</h2>' : '<a class="sj-t" href="/journeys/suggested.php?id=' . (int) $j['id'] . '">' . $e($j['title']) . '</a>')
        . ($route !== '' ? tv_maps_script() . '<a class="sj-route" ' . tv_maps_attrs($stops, (string) $j['title']) . ' title="Send to Maps: the whole route in Google Maps or Apple Maps" aria-label="Send the whole route to Google Maps or Apple Maps" aria-haspopup="dialog">' . $ic('<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h8a3 3 0 0 0 0-6H8a3 3 0 0 1 0-6h8"/>') . '</a>' : '')
        . ($j['why'] !== '' && $j['why'] !== null ? '<p class="sj-why">' . $e($j['why']) . '</p>' : '')
        . '<p class="sj-meta">' . $e($meta) . '</p>'
        . ($full ? $list : '<details><summary>See the stops</summary>' . $list . '</details>')
        . '<p class="sj-note">' . $notes . '</p></article>';
}
