<?php
// app/lib/JourneyPlan.php — the journey engine (decisions/0146): suggested journeys built by rules from a guide's own
// places, no AI and no cost. The guide decides what kinds of journey it has (its strongest themes) and how many stops
// (as many as fit the time, the hours and the distances). Each stop is timed against its hours and the daylight,
// breakfast in the morning, lunch at midday, and each leg's time comes from our own travel_legs (TravelLegs).
// Never a protected place (decisions/0066), a closed business, one whose point is only its ZIP's middle, or one that
// asked to be left out. A business is in because it fits, never because it pays.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/PageCache.php';
require_once __DIR__ . '/Guides.php';
require_once __DIR__ . '/Hours.php';
require_once __DIR__ . '/TravelLegs.php';

final class JourneyPlan
{
    /** theme => [title, the guide sections its "why" is read from, the words in a guide that show it's strong there] */
    public const THEMES = [
        'day' => ['A day in %s', ['glance'], ''],
        'outdoors' => ['Outdoors around %s', ['do', 'glance'], 'trail|hike|lake|river|canyon|forest|mountain|beach|ocean|cove|park|fishing|camp|outdoor|view|sunset|wildlife|bird|paddle|surf'],
        'heritage' => ['Heritage and history in %s', ['footsteps', 'landmarks'], 'history|historic|heritage|museum|pioneer|founded|mission|fort|railroad|settler|century|monument|landmark'],
        'food' => ['A taste of %s', ['eat'], 'restaurant|cafe|coffee|diner|bakery|food|eat|dish|brew|wine|tacos|bbq|fresh|local favorite'],
        'culture' => ['Arts and culture in %s', ['do'], 'art|gallery|theater|theatre|music|festival|craft|artist|performance|studio'],
        'shopping' => ['Shopping in %s', ['do', 'glance'], 'shop|boutique|antique|market|gift|store|trading post|souvenir'],
    ];
    /** minutes people usually stay, by kind of stop (ours: the rules, then what people set in their own trips) */
    public const DWELL = ['coffee' => 30, 'meal' => 60, 'drinks' => 60, 'museum' => 90, 'gallery' => 45, 'culture' => 60, 'park' => 90,
                          'outdoor' => 120, 'viewpoint' => 45, 'landmark' => 30, 'shop' => 30];
    /** the hours each journey runs (minutes after midnight): a day, a morning outdoors, the rest late morning on */
    private const WINDOW = ['day' => [540, 1170], 'outdoors' => [480, 780], 'heritage' => [600, 960], 'culture' => [600, 960], 'shopping' => [600, 900], 'food' => [480, 1290]];
    /** the reference day: suggestions are timed for a Saturday, and say so */
    public const DAY = 6;
    /** a journey needs at least this many stops; a day, three across two themes */
    public const MIN_STOPS = 2;
    /** how many themed journeys a guide shows besides its day */
    public const MAX_THEMES = 4;
    /** rebuilt weekly, or sooner when the guide changes */
    public const RENEW_DAYS = 7;

    private const OUTDOOR_FCLASS = '/Summit|Lake|Falls|Arch|Beach|Cape|Park|Spring|Gap|Valley|Canyon|Basin|Bay|Crater|Island|Pillar|Range|Ridge|Bend|Cliff|Reservoir|Trail|Forest|Lava|Plain|Gorge|Overlook|Mesa|Butte/i';
    private const HERITAGE_FCLASS = '/Building|Church|Cemetery|Mine|Bridge|Dam|Tower|Historical|Monument|Fort|Museum|Mission|Trading/i';
    private const STATE_TZ = ['AZ' => 'America/Phoenix', 'CA' => 'America/Los_Angeles', 'NV' => 'America/Los_Angeles', 'OR' => 'America/Los_Angeles', 'WA' => 'America/Los_Angeles',
        'NM' => 'America/Denver', 'UT' => 'America/Denver', 'CO' => 'America/Denver', 'WY' => 'America/Denver', 'MT' => 'America/Denver', 'ID' => 'America/Boise',
        'TX' => 'America/Chicago', 'OK' => 'America/Chicago', 'KS' => 'America/Chicago', 'NE' => 'America/Chicago', 'SD' => 'America/Chicago', 'ND' => 'America/Chicago',
        'MN' => 'America/Chicago', 'IA' => 'America/Chicago', 'MO' => 'America/Chicago', 'AR' => 'America/Chicago', 'LA' => 'America/Chicago', 'WI' => 'America/Chicago',
        'IL' => 'America/Chicago', 'MS' => 'America/Chicago', 'AL' => 'America/Chicago', 'TN' => 'America/Chicago', 'AK' => 'America/Anchorage', 'HI' => 'Pacific/Honolulu'];

    private static ?bool $ready = null;

    public static function ready(PDO $pdo): bool
    {
        if (self::$ready !== null) return self::$ready;
        try { $pdo->query('SELECT 1 FROM suggested_journeys LIMIT 0'); return self::$ready = true; } catch (Throwable) { return self::$ready = false; }
    }

    // ---- what the guide offers -----------------------------------------------------------------------------------------

    /**
     * The places a journey may use, from the guide's own picks, landmarks and outdoor places: each ['ref', 'name', 'url',
     * 'sub', 'theme', 'kind' (a DWELL key), 'lat', 'lon', 'hours' (parsed week or null), 'daylight', 'mentioned'].
     */
    public static function candidates(PDO $pdo, array $p): array
    {
        if ($p['lat'] === null || $p['level'] === 'hub') return [];
        $named = self::mentioned($pdo, $p['key']);
        $out = [];
        $eatKinds = array_column(Guides::KINDS['eat'], 0);
        foreach (['eat' => 12, 'do' => 14, 'shop' => 8] as $section => $n) {
            foreach (Guides::picks($pdo, $p, $section, $n, 'v') as $r) {
                if ($r['latitude'] === null || $r['longitude'] === null) continue;
                $cat = (string) $r['category'] . ' ' . (string) $r['name'];
                if ($section === 'eat') { $kind = ($r['kind'] ?? '') === $eatKinds[0] ? 'coffee' : (($r['kind'] ?? '') === $eatKinds[1] ? 'drinks' : 'meal'); $theme = 'food'; }
                elseif ($section === 'shop') { $kind = 'shop'; $theme = 'shopping'; }
                elseif (preg_match('/Museum/i', $cat)) { $kind = 'museum'; $theme = 'heritage'; }
                elseif (preg_match('/Historic|Monument|Landmark|Heritage/i', $cat)) { $kind = 'landmark'; $theme = 'heritage'; }
                elseif (preg_match('/Galler|Theat|Arts|Music|Performing|Craft|Cinema/i', $cat)) { $kind = preg_match('/Galler|Craft/i', $cat) ? 'gallery' : 'culture'; $theme = 'culture'; }
                elseif (($r['kind'] ?? '') === Guides::KINDS['do'][0][0]) { $kind = 'park'; $theme = 'outdoors'; }
                else { $kind = 'culture'; $theme = 'culture'; }
                $ref = 'entity:' . (int) $r['id'];
                $out[$ref] = ['ref' => $ref, 'id' => (int) $r['id'], 'name' => (string) $r['name'], 'url' => '/listing/view.php?id=' . (int) $r['id'],
                    'sub' => preg_replace('/\s*\([^)]*$/', '', (string) $r['category']), 'theme' => $theme, 'kind' => $kind,
                    'lat' => (float) $r['latitude'], 'lon' => (float) $r['longitude'], 'hours' => Hours::parse((string) ($r['hours'] ?? '')), 'daylight' => $theme === 'outdoors',
                    'mentioned' => isset($named[$ref]), 'address' => trim((string) ($r['address'] ?? '') . ', ' . (string) ($r['city'] ?? '') . ' ' . (string) ($r['state'] ?? ''), ', ')];
            }
        }
        $out = self::dropListings($pdo, $out);
        // outside our areas (a place built on demand, decisions/0147) we have no listings: OpenStreetMap's places to eat,
        // shown as OpenStreetMap's with its credit, never a listing (decisions/0065)
        if ((int) ($p['cluster'] ?? 0) === 0 && $p['level'] === 'town' && is_file(__DIR__ . '/OpenPlaces.php')) {
            require_once __DIR__ . '/OpenPlaces.php';
            foreach (['coffee' => 'coffee', 'food' => 'meal'] as $ok => $kind) {
                try { $rows = OpenPlaces::near($pdo, $ok, (float) $p['lat'], (float) $p['lon'], 10, 8); } catch (Throwable) { $rows = []; }
                foreach ($rows as $o) {
                    $ref = 'osm:' . $o['ref'];
                    if (isset($out[$ref]) || !preg_match('~/\?api=1&destination=(-?[\d.]+)%2C(-?[\d.]+)~', (string) $o['directions'], $m)) continue;
                    $k = $ok === 'food' && preg_match('/caf[eé]|coffee|bakery/i', (string) $o['what']) ? 'coffee' : $kind;
                    $out[$ref] = ['ref' => $ref, 'name' => (string) $o['label'], 'url' => (string) $o['url'], 'sub' => (string) ($o['what'] ?: 'Place to eat'), 'theme' => 'food', 'kind' => $k,
                        'lat' => (float) $m[1], 'lon' => (float) $m[2], 'hours' => Hours::parse((string) $o['hours']), 'daylight' => false, 'mentioned' => false, 'osm' => true,
                        'address' => trim((string) $o['street'] . ', ' . (string) $o['city'], ', ')];
                }
            }
        }
        // landmarks the guide names first, then the nearest worth a stop; never a protected one (decisions/0066)
        require_once __DIR__ . '/Landmarks.php';
        $lms = Guides::landmarks($pdo, $p, 12);
        $ids = []; foreach (array_keys($named) as $nr) if (str_starts_with($nr, 'landmark:')) $ids[] = (int) substr($nr, 9);
        if ($ids) {
            try {
                $st = $pdo->query('SELECT gnis_id, name, fclass, near_town, lat, lon, wd_desc, image_url FROM landmarks WHERE ' . Landmarks::visibleSql() . ' AND gnis_id IN (' . implode(',', array_map('intval', $ids)) . ')');
                $lms = array_merge($st->fetchAll(PDO::FETCH_ASSOC), $lms);
            } catch (Throwable) {}
        }
        foreach ($lms as $l) {
            $ref = 'landmark:' . (int) $l['gnis_id'];
            if (isset($out[$ref]) || $l['lat'] === null) continue;
            $fc = (string) $l['fclass'];
            if (Landmarks::isProtected((string) $l['name'] . ' ' . $fc . ' ' . (string) ($l['wd_desc'] ?? ''))) continue;   // told in the guide, never a stop with directions
            if (preg_match('/\bArt\b|Gallery|Theat|Amphitheat/i', $fc)) { $theme = 'culture'; $kind = preg_match('/Museum/i', $fc) ? 'museum' : 'gallery'; }   // an art museum, a gallery, a theater (places on demand, decisions/0148)
            elseif (preg_match('/Museum/i', $fc)) { $theme = 'heritage'; $kind = 'museum'; }
            elseif (preg_match(self::OUTDOOR_FCLASS, $fc)) { $theme = 'outdoors'; $kind = preg_match('/Park|Preserve|Reserve|Trail/i', $fc) ? 'park' : 'viewpoint'; }
            elseif (preg_match(self::HERITAGE_FCLASS, $fc) || preg_match(self::HERITAGE_FCLASS, (string) $l['name'])) { $theme = 'heritage'; $kind = 'landmark'; }
            else continue;   // a populated place, a school, a post office: not a stop
            $out[$ref] = ['ref' => $ref, 'name' => (string) $l['name'], 'url' => '/place/landmark.php?id=' . (int) $l['gnis_id'], 'sub' => ucfirst($fc), 'theme' => $theme, 'kind' => $kind,
                'lat' => (float) $l['lat'], 'lon' => (float) $l['lon'], 'hours' => null, 'daylight' => true, 'mentioned' => isset($named[$ref]), 'address' => ''];
        }
        // outdoor places (Recreation.gov's areas, trails and facilities near the place)
        if (is_file(__DIR__ . '/crawler/RecBulk.php')) {
            require_once __DIR__ . '/crawler/RecBulk.php';
            try { $recs = RecBulk::near($pdo, [[(float) $p['lat'], (float) $p['lon']]], ['geo_hub' => 40, 'cluster' => 25, 'town' => 15, 'sub' => 10][$p['level']] ?? 20, 10); } catch (Throwable) { $recs = []; }
            foreach ($recs as $r) {
                $ref = 'rec:' . $r['ridb_id'];
                if (isset($out[$ref]) || $r['lat'] === null) continue;
                $out[$ref] = ['ref' => $ref, 'name' => RecBulk::displayName((string) $r['name']), 'url' => '/place/recreation.php?id=' . rawurlencode((string) $r['ridb_id']), 'sub' => (string) ($r['type'] ?: 'Outdoors'),
                    'theme' => 'outdoors', 'kind' => preg_match('/Trail|Area|Forest|Wilderness|Lake|Park/i', (string) $r['type'] . ' ' . $r['name']) ? 'outdoor' : 'park',
                    'lat' => (float) $r['lat'], 'lon' => (float) $r['lon'], 'hours' => null, 'daylight' => true, 'mentioned' => isset($named[$ref]), 'address' => ''];
            }
        }
        // one per name
        $seen = []; $keep = [];
        foreach ($out as $ref => $c) { $nk = strtolower(preg_replace('/\W+/', '', $c['name'])); if ($nk === '' || isset($seen[$nk])) continue; $seen[$nk] = 1; $keep[$ref] = $c; }
        return $keep;
    }

    /** Listings left out: asked to be (decisions/0146 §6 q5), only placed at their ZIP's middle, a location kept private
     *  (ListingSafety, decisions/0174 §2) or a mailbox (no way to drive to it): the same rules as Directions. */
    private static function dropListings(PDO $pdo, array $out): array
    {
        $ids = []; foreach ($out as $c) if (isset($c['id'])) $ids[] = (int) $c['id'];
        if (!$ids) return $out;
        $in = implode(',', $ids);
        try {
            $drop = $pdo->query("SELECT entity_id FROM entity_metadata WHERE meta_key = 'no_suggested_journeys' AND entity_id IN ($in)")->fetchAll(PDO::FETCH_COLUMN);
            require_once __DIR__ . '/Geocoder.php';
            $drop = array_merge($drop, $pdo->query('SELECT e.id FROM entities e WHERE e.id IN (' . $in . ') AND ' . Geocoder::APPROX)->fetchAll(PDO::FETCH_COLUMN));
        } catch (Throwable) { $drop = []; }
        try {
            require_once __DIR__ . '/ListingSafety.php'; require_once __DIR__ . '/ListingActions.php';
            foreach ($pdo->query('SELECT id, name, category_id FROM entities WHERE id IN (' . $in . ')')->fetchAll(PDO::FETCH_ASSOC) as $e)
                if (ListingSafety::isConfidential($e['category_id'] !== null ? (int) $e['category_id'] : null, (string) $e['name'])) $drop[] = (int) $e['id'];
        } catch (Throwable) {}
        foreach ($out as $ref => $c) if (isset($c['id']) && ListingActions::isMailbox((string) ($c['address'] ?? ''))) $drop[] = (int) $c['id'];
        foreach ($drop as $d) unset($out['entity:' . (int) $d]);
        return $out;
    }

    /** The places the guide's own text names, linked to our record: ref => true. */
    private static function mentioned(PDO $pdo, string $key): array
    {
        try {
            $st = $pdo->prepare("SELECT ref FROM content_tags WHERE src = ? AND status IN ('linked','thin')"); $st->execute(['guide:' . $key]);
            return array_fill_keys(array_map('strval', $st->fetchAll(PDO::FETCH_COLUMN)), true);
        } catch (Throwable) { return []; }
    }

    /** How strongly each theme runs through the guide: its usable places, those the guide names, and its words. */
    public static function strengths(array $cands, array $sections): array
    {
        $text = strtolower(strip_tags(implode("\n", array_map('strval', $sections))));
        $s = [];
        foreach (self::THEMES as $t => [, , $words]) {
            if ($t === 'day') continue;
            $n = 0; $m = 0;
            foreach ($cands as $c) if ($c['theme'] === $t) { $n++; if ($c['mentioned']) $m++; }
            if ($n < self::MIN_STOPS) continue;
            $hits = $words !== '' && $text !== '' ? preg_match_all('/\b(' . $words . ')/', $text) : 0;
            $s[$t] = $n + 2 * $m + min(10, (int) $hits);
        }
        arsort($s);
        return $s;
    }

    // ---- timing --------------------------------------------------------------------------------------------------------

    public static function timezone(array $p): string
    {
        $st = strtoupper(trim((string) ($p['state'] ?? '')));
        if (isset(self::STATE_TZ[$st])) return self::STATE_TZ[$st];
        $lon = (float) ($p['lon'] ?? -100);
        return $lon < -114.5 ? 'America/Los_Angeles' : ($lon < -102 ? 'America/Denver' : ($lon < -87 ? 'America/Chicago' : 'America/New_York'));
    }

    /** The next Saturday at the place, and its sunrise and sunset in minutes after midnight there. */
    public static function day(array $p, ?int $now = null): array
    {
        $tz = new DateTimeZone(self::timezone($p));
        $d = (new DateTimeImmutable('@' . ($now ?? time())))->setTimezone($tz)->setTime(12, 0);
        $d = $d->modify('+' . ((self::DAY - (int) $d->format('w') + 7) % 7) . ' days');
        $sun = date_sun_info($d->getTimestamp(), (float) $p['lat'], (float) $p['lon']);
        $min = function ($ts) use ($tz) { if (!is_int($ts)) return null; $t = (new DateTimeImmutable('@' . $ts))->setTimezone($tz); return (int) $t->format('G') * 60 + (int) $t->format('i'); };
        return ['date' => $d->format('Y-m-d'), 'dow' => (int) $d->format('w'), 'sunrise' => $min($sun['sunrise'] ?? null) ?? 390, 'sunset' => $min($sun['sunset'] ?? null) ?? 1110];
    }

    /** Can the stop be visited from $arrive for its stay? true, false, or null when its hours aren't known. */
    public static function openFor(array $c, int $dow, int $arrive, int $stay, array $day): ?bool
    {
        if ($c['daylight'] && $c['hours'] === null) return $arrive >= $day['sunrise'] && $arrive + $stay <= $day['sunset'];
        if ($c['hours'] === null) return null;
        return Hours::openAt($c['hours'], $dow, $arrive) === true && Hours::openAt($c['hours'], $dow, $arrive + max(0, $stay - 10)) !== false;
    }

    // ---- building ------------------------------------------------------------------------------------------------------

    /**
     * One journey for a theme from the candidates, or null when it can't be made. Greedy: from where you are, the best
     * next stop open on arrival, near, named by the guide, and right for the time of day.
     */
    public static function build(PDO $pdo, array $p, string $theme, array $cands, array $day, array $held = []): ?array
    {
        $pool = array_values(array_filter($cands, fn ($c) => $theme === 'day' ? $c['kind'] !== 'drinks' : $c['theme'] === $theme));
        if (count($pool) < self::MIN_STOPS) return null;
        [$t, $end] = self::WINDOW[$theme];
        if ($theme === 'outdoors') $t = max($t, $day['sunrise'] + 30);
        $end = $theme === 'outdoors' ? min($end, $day['sunset']) : $end;
        $cur = ['ref' => 'place:' . $p['key'], 'lat' => (float) $p['lat'], 'lon' => (float) $p['lon']];
        $stops = []; $had = ['coffee' => 0, 'lunch' => 0, 'dinner' => 0, 'drinks' => 0]; $prevTheme = '';
        while ($pool) {
            $best = null; $bestScore = INF;
            foreach ($pool as $i => $c) {
                $leg = $stops ? self::leg($pdo, $cur, $c, $held) : ['minutes' => 0, 'meters' => 0, 'source' => '', 'mode' => ''];
                $arrive = (int) (ceil(($t + $leg['minutes']) / 5) * 5);
                $stay = self::DWELL[$c['kind']] ?? 45;
                if ($arrive + $stay > $end) continue;
                $slot = self::slot($c['kind'], $arrive);
                if ($c['kind'] === 'coffee' || $c['kind'] === 'meal' || $c['kind'] === 'drinks') {
                    if ($slot === '' || $had[$slot]) continue;   // food at its time, once each
                }
                $open = self::openFor($c, $day['dow'], $arrive, $stay, $day);
                if ($open === false) continue;
                $score = $leg['minutes'] + ($c['mentioned'] ? -15 : 0) + ($open === null ? 12 : 0) + ($theme === 'day' && $c['theme'] === $prevTheme ? 10 : 0);
                if ($slot !== '') $score -= 40;   // a meal at mealtime comes first
                elseif ($theme === 'day' && !$had['lunch'] && $arrive >= 690 && $arrive <= 810) $score += 25;   // lunchtime: eat
                if ($theme === 'food') $score += max(0, $arrive - $t) / 2;   // the next meal, not one hours away
                if (!$stops) $score = self::leg($pdo, $cur, $c, $held)['minutes'] + ($c['mentioned'] ? -15 : 0) + ($slot !== '' ? -40 : 0);   // start near the middle of the place
                if ($score < $bestScore) { $bestScore = $score; $best = [$i, $leg, $arrive, $stay, $open, $slot]; }
            }
            if ($best === null) {
                if ($theme === 'food' && $t < $end) { $t = self::nextMeal($t); if ($t < $end) continue; }   // wait for the next mealtime
                if ($theme === 'day' && !$had['dinner'] && $t >= 900 && $t < 1050) { $t = 1050; continue; }   // a free hour, then dinner
                break;
            }
            [$i, $leg, $arrive, $stay, $open, $slot] = $best;
            $c = $pool[$i]; unset($pool[$i]);
            if ($slot !== '') $had[$slot] = 1;
            $stops[] = ['ref' => $c['ref'], 'name' => $c['name'], 'url' => $c['url'], 'sub' => $c['sub'], 'theme' => $c['theme'], 'kind' => $c['kind'], 'lat' => $c['lat'], 'lon' => $c['lon'],
                'address' => $c['address'], 'arrive' => $arrive, 'leave' => $arrive + $stay, 'stay' => $stay, 'hours' => $open === null ? 'unknown' : ($c['daylight'] && $c['hours'] === null ? 'daylight' : 'open'),
                'leg' => $stops ? ['minutes' => (int) round($leg['minutes']), 'miles' => round($leg['meters'] / 1609.34, 1), 'mode' => $leg['mode'], 'source' => $leg['source']] : null];
            $t = $arrive + $stay; $cur = $c; $prevTheme = $c['theme'];
        }
        $themes = count(array_unique(array_column($stops, 'theme')));
        if (count($stops) < ($theme === 'day' ? 3 : self::MIN_STOPS) || ($theme === 'day' && $themes < 2)) return null;
        $miles = 0.0; foreach ($stops as $s) $miles += $s['leg']['miles'] ?? 0;
        return ['theme' => $theme, 'title' => sprintf(self::THEMES[$theme][0], $p['name']), 'stops' => $stops, 'minutes' => end($stops)['leave'] - $stops[0]['arrive'],
                'miles' => round($miles, 1), 'sunset' => $day['sunset'], 'day' => $day['dow']];
    }

    /** breakfast before 10:30, lunch 11:30 to 1:30, dinner 5:30 to 7:30, drinks after 7: the meal a time is for, or ''. */
    private static function slot(string $kind, int $m): string
    {
        if ($kind === 'coffee') return $m <= 630 ? 'coffee' : '';
        if ($kind === 'meal') return $m >= 690 && $m <= 810 ? 'lunch' : ($m >= 1050 && $m <= 1170 ? 'dinner' : '');
        if ($kind === 'drinks') return $m >= 1140 ? 'drinks' : '';
        return '';
    }

    private static function nextMeal(int $t): int
    {
        foreach ([690, 1050, 1140] as $m) if ($m > $t) return $m;
        return 1440;
    }

    /** The leg from one point to the next: held, else estimated; walking when it's close. */
    private static function leg(PDO $pdo, array $a, array $b, array $held): array
    {
        $line = TravelLegs::miles((float) $a['lat'], (float) $a['lon'], (float) $b['lat'], (float) $b['lon']);
        $mode = TravelLegs::modeFor($line);
        $k = $a['ref'] . '>' . $b['ref']; $k2 = $b['ref'] . '>' . $a['ref'];
        $h = $held[$mode][$k] ?? $held[$mode][$k2] ?? null;
        return ($h ?: TravelLegs::estimate($line, $mode)) + ['mode' => $mode];
    }

    /** Why take it: the first sentence of the guide's own words for the theme, else a plain line. */
    public static function why(array $p, string $theme, array $sections, array $j): string
    {
        foreach (self::THEMES[$theme][1] as $k) {
            $t = trim(preg_replace(['/^#+\s.*$/m', '/\*\*|__|`/', '/\[([^\]]+)\]\([^)]*\)/', '/\s+/'], ['', '', '$1', ' '], strip_tags((string) ($sections[$k] ?? ''))));
            if ($t === '') continue;
            if (preg_match('/^(.{40,260}?[.!?])(\s|$)/u', $t, $m)) return $m[1];
        }
        $n = count($j['stops']);
        return ['day' => "A full day in {$p['name']}: $n stops, from morning to evening.", 'outdoors' => "A morning outside: $n of the open places around {$p['name']}.",
                'heritage' => "$n places that hold the story of {$p['name']}.", 'food' => "Where to eat in {$p['name']}, from breakfast to dinner.",
                'culture' => "$n places for the arts and culture of {$p['name']}.", 'shopping' => "$n local shops worth the stop in {$p['name']}."][$theme];
    }

    // ---- keeping them ----------------------------------------------------------------------------------------------------

    /**
     * Build (or rebuild) a place's suggested journeys and store them. Staff edits and pins stay; a journey taken down
     * stays down. Returns how many are live.
     */
    public static function buildPlace(PDO $pdo, string $key): int
    {
        if (!self::ready($pdo)) return 0;
        $p = Guides::place($pdo, $key);
        if (!$p || $p['lat'] === null || $p['level'] === 'hub') return 0;
        $cands = self::candidates($pdo, $p);
        $sections = Guides::shown($pdo, $key)['sections'];
        $day = self::day($p);
        // our own travel times: ask once for any the town's places don't have yet, then read only our table
        $pts = array_values(array_map(fn ($c) => ['ref' => $c['ref'], 'lat' => $c['lat'], 'lon' => $c['lon']], $cands));
        array_unshift($pts, ['ref' => 'place:' . $key, 'lat' => (float) $p['lat'], 'lon' => (float) $p['lon']]);
        try { TravelLegs::prepare($pdo, $pts, 'drive'); } catch (Throwable $e) { error_log('JourneyPlan: ' . $e->getMessage()); }
        $held = ['drive' => TravelLegs::held($pdo, $pts, 'drive'), 'walk' => TravelLegs::held($pdo, $pts, 'walk')];
        $strengths = self::strengths($cands, $sections);
        $built = [];
        $dayJ = self::build($pdo, $p, 'day', $cands, $day, $held);
        if ($dayJ) $built['day'] = [$dayJ, 100];
        foreach (array_slice($strengths, 0, self::MAX_THEMES, true) as $t => $s) { $j = self::build($pdo, $p, $t, $cands, $day, $held); if ($j) $built[$t] = [$j, $s]; }
        $keep = $pdo->prepare('SELECT theme, status, pinned, edited_by, sig FROM suggested_journeys WHERE place_key = ?'); $keep->execute([$key]);
        $have = []; foreach ($keep->fetchAll(PDO::FETCH_ASSOC) as $r) $have[$r['theme']] = $r;
        $now = date('Y-m-d H:i:s');
        foreach ($built as $t => [$j, $s]) {
            $sig = md5(json_encode(array_map(fn ($x) => [$x['ref'], $x['arrive']], $j['stops'])));
            $h = $have[$t] ?? null;
            if ($h && ($h['edited_by'] !== null || (int) $h['pinned'] === 1)) { $pdo->prepare('UPDATE suggested_journeys SET built_at = ? WHERE place_key = ? AND theme = ?')->execute([$now, $key, $t]); continue; }   // a person's version stays
            $why = self::why($p, $t, $sections, $j);
            $pdo->prepare('INSERT INTO suggested_journeys (place_key, theme, title, why, stops, minutes, miles, day_of_week, strength, status, sig, built_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE title = VALUES(title), why = VALUES(why), stops = VALUES(stops), minutes = VALUES(minutes), miles = VALUES(miles), day_of_week = VALUES(day_of_week), strength = VALUES(strength), sig = VALUES(sig), built_at = VALUES(built_at)')
                ->execute([$key, $t, $j['title'], $why, json_encode(['stops' => $j['stops'], 'sunset' => $j['sunset']]), $j['minutes'], $j['miles'], $j['day'], $s, $h ? $h['status'] : 'live', $sig, $now]);
        }
        // a theme with too few places left comes down until it can be built again (decisions/0146 §3); a person's stays
        foreach ($have as $t => $h) if (!isset($built[$t]) && $h['edited_by'] === null && (int) $h['pinned'] === 0) $pdo->prepare('DELETE FROM suggested_journeys WHERE place_key = ? AND theme = ?')->execute([$key, $t]);
        PageCache::put($pdo, 'journeys:tried:' . $key, self::RENEW_DAYS * 86400, 1);
        PageCache::forget($pdo, 'journeys:place:' . $key);
        return count(array_filter($built, fn ($b, $t) => ($have[$t]['status'] ?? 'live') === 'live', ARRAY_FILTER_USE_BOTH));
    }

    /** The job: a few live guides a run whose journeys are missing or a week old, the oldest first. */
    public static function tick(PDO $pdo, int $n = 3): array
    {
        if (!self::ready($pdo)) return [0, 0];
        $st = $pdo->prepare("SELECT g.place_key FROM place_guides g LEFT JOIN (SELECT place_key, MIN(built_at) b FROM suggested_journeys GROUP BY place_key) s ON s.place_key = g.place_key
            WHERE g.status = 'live' AND (s.b IS NULL OR s.b < ? OR s.b < g.updated_at) ORDER BY s.b IS NOT NULL, s.b LIMIT 60");
        $st->execute([date('Y-m-d H:i:s', time() - self::RENEW_DAYS * 86400)]);
        $places = 0; $live = 0;
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $key) {
            if ($places >= $n) break;
            $hasRows = (bool) $pdo->query('SELECT 1 FROM suggested_journeys WHERE place_key = ' . $pdo->quote((string) $key) . ' LIMIT 1')->fetchColumn();
            if (!$hasRows && PageCache::get($pdo, 'journeys:tried:' . $key)) continue;   // too few places last week: wait
            try { $live += self::buildPlace($pdo, (string) $key); } catch (Throwable $e) { error_log('JourneyPlan ' . $key . ': ' . $e->getMessage()); }
            $places++;
        }
        return [$places, $live];
    }

    /** A place's live journeys, the day first, then pinned, then the strongest. */
    public static function forPlace(PDO $pdo, string $key): array
    {
        if (!self::ready($pdo)) return [];
        return PageCache::remember($pdo, 'journeys:place:' . $key, 1800, function () use ($pdo, $key) {
            $st = $pdo->prepare("SELECT * FROM suggested_journeys WHERE place_key = ? AND status = 'live' ORDER BY theme = 'day' DESC, pinned DESC, strength DESC, id");
            $st->execute([$key]);
            return array_map([self::class, 'decode'], $st->fetchAll(PDO::FETCH_ASSOC));
        });
    }

    public static function get(PDO $pdo, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM suggested_journeys WHERE id = ?'); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ? self::decode($r) : null;
    }

    private static function decode(array $r): array
    {
        $d = json_decode((string) $r['stops'], true) ?: [];
        $r['stops'] = (array) ($d['stops'] ?? []); $r['sunset'] = (int) ($d['sunset'] ?? 0);
        return $r;
    }
}
