-- The System Control Board's historian (decisions/0171 §6, release 4b): each process's readings over time
-- (control_readings: its state when it changes and hourly, and each hour's counts; kept control_readings_days, 30 by
-- default) and one row per reading per day (control_daily, kept 400 days). Staging class: own (staging-tables.php).
-- Safe to run twice; ControlHistorian::ensure() makes the same tables if this hasn't run yet.
CREATE TABLE IF NOT EXISTS control_readings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  proc VARCHAR(60) NOT NULL,
  reading VARCHAR(20) NOT NULL,
  value DOUBLE NOT NULL DEFAULT 0,
  state VARCHAR(8) NULL,
  at DATETIME NOT NULL,
  KEY proc_reading_at (proc, reading, at),
  KEY reading_at (reading, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS control_daily (
  day DATE NOT NULL,
  proc VARCHAR(60) NOT NULL,
  reading VARCHAR(20) NOT NULL,
  vmin DOUBLE NULL,
  vmax DOUBLE NULL,
  vlast DOUBLE NULL,
  vsum DOUBLE NULL,
  red_s INT UNSIGNED NOT NULL DEFAULT 0,
  amber_s INT UNSIGNED NOT NULL DEFAULT 0,
  blue_s INT UNSIGNED NOT NULL DEFAULT 0,
  up_s INT UNSIGNED NOT NULL DEFAULT 0,
  due_s INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (day, proc, reading)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
