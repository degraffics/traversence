<?php
// app/lib/ControlHistorian.php — the System Control Board's historian (decisions/0171 §6, release 4b). Each process's
// readings kept over time, so every process and system has a trend:
//   - its state (the board's light, after its rules: ControlBoard::boardLight), written when it changes and at least once
//     an hour, every 5 minutes by the board's watch (control_tick);
//   - each hour's counts, written once the hour is over: worker calls, records in, stored, refused, server errors, average
//     ms, runs and failed runs; for an outside service, this month's spend and its share of its cap.
// Raw rows (control_readings) are kept control_readings_days (Thresholds & gates, default 30); each finished day is also
// one row per reading in control_daily (min, max, last, sum, and the time spent red, amber or blue), kept 400 days.
// Uptime is the time green or amber against the time it should have been on (off, in maintenance and not yet tested
// don't count). Trends are drawn as small inline SVGs (no library) for the last 24 hours, 7 days or 30 days.
// Both tables are each site's own on staging (staging-tables.php OWN).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class ControlHistorian
{
    /** A state as a number (for min and max) and its band: up (green or amber), down (red), out (blue), none. */
    public const STATES = ['ok' => [0, 'up'], 'warn' => [1, 'up'], 'hold' => [2, 'up'], 'bad' => [3, 'down'], 'maint' => [4, 'out'], 'off' => [5, 'none'], 'wait' => [6, 'none'], 'new' => [6, 'none'], 'na' => [6, 'none']];
    /** The hourly counts, in the order a trend lists them. */
    public const COUNTS = ['calls' => 'worker calls', 'in' => 'records in', 'stored' => 'stored', 'refused' => 'refused', 'errors' => 'server errors', 'ms' => 'ms a call', 'runs' => 'runs', 'failed' => 'failed runs', 'spend' => 'USD this month', 'cap_pct' => '% of its cap'];
    public const RANGES = ['24h' => [86400, 3600, 'the last 24 hours'], '7d' => [604800, 21600, 'the last 7 days'], '30d' => [2592000, 86400, 'the last 30 days']];
    private static bool $ready = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $pdo->exec("CREATE TABLE IF NOT EXISTS control_readings (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, proc VARCHAR(60) NOT NULL, reading VARCHAR(20) NOT NULL,
            value DOUBLE NOT NULL DEFAULT 0, state VARCHAR(8) NULL, at DATETIME NOT NULL, KEY proc_reading_at (proc, reading, at), KEY reading_at (reading, at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS control_daily (day DATE NOT NULL, proc VARCHAR(60) NOT NULL, reading VARCHAR(20) NOT NULL, vmin DOUBLE NULL, vmax DOUBLE NULL, vlast DOUBLE NULL, vsum DOUBLE NULL,
            red_s INT UNSIGNED NOT NULL DEFAULT 0, amber_s INT UNSIGNED NOT NULL DEFAULT 0, blue_s INT UNSIGNED NOT NULL DEFAULT 0, up_s INT UNSIGNED NOT NULL DEFAULT 0, due_s INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (day, proc, reading)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        self::$ready = true;
    }

    /** How long raw rows are kept: Thresholds & gates' control_readings_days (30 until set). */
    public static function keepDays(PDO $pdo): int
    {
        try { require_once __DIR__ . '/Thresholds.php'; $v = Thresholds::get($pdo, 'control_readings_days'); return $v === null ? 30 : max(7, min(90, (int) $v)); } catch (Throwable $x) { return 30; }
    }

    // ---- writing (the watch, every 5 minutes) -------------------------------------------------------------------------

    /** Every process's light now, after the board's rules: proc => [light, row]. */
    public static function lights(PDO $pdo): array
    {
        require_once __DIR__ . '/ControlBoard.php'; require_once __DIR__ . '/ControlRegister.php'; require_once __DIR__ . '/ControlAlarms.php'; require_once __DIR__ . '/Preflight.php';
        $res = Preflight::results($pdo);
        $tripped = []; foreach (ControlAlarms::list($pdo) as $x) if ($x['cleared_at'] === null && $x['level'] === 'trip') $tripped[(string) $x['proc']] = true;
        $out = [];
        foreach (ControlRegister::processes($pdo) as $id => $p) {
            try { $row = ControlBoard::process($pdo, $id, $p, $res); [$light] = ControlBoard::boardLight($pdo, $id, $row, $tripped); $out[$id] = [$light, $row]; }
            catch (Throwable $x) { error_log('historian ' . $id . ': ' . $x->getMessage()); }
        }
        return $out;
    }

    /**
     * The watch's part: each process's state, written when it changed or its last is an hour old; the hour just ended's
     * counts, once; the day just ended rolled up, and old rows trimmed, once a day. Returns what it did. Never throws.
     */
    public static function tick(PDO $pdo, ?int $now = null, ?array $lights = null): array
    {
        $now = $now ?? time(); $did = [];
        try {
            self::ensure($pdo);
            $lights = $lights ?? self::lights($pdo);
            $last = self::lastStates($pdo);
            $ins = $pdo->prepare("INSERT INTO control_readings (proc, reading, value, state, at) VALUES (?, 'state', ?, ?, ?)");
            $n = 0;
            foreach ($lights as $id => [$light]) {
                $light = isset(self::STATES[$light]) ? $light : 'wait';
                $l = $last[$id] ?? null;
                if ($l && $l[0] === $light && $now - $l[1] < 3600) continue;
                $ins->execute([$id, self::STATES[$light][0], $light, gmdate('Y-m-d H:i:s', $now)]); $n++;
            }
            if ($n) $did[] = $n . ' state(s)';
            // the hour just ended, once
            $hour = intdiv($now, 3600) * 3600 - 3600;
            if (self::once($pdo, 'ch:hour', (string) $hour)) { $c = self::writeHour($pdo, $hour, $now, $lights); $did[] = $c . ' count(s) for ' . gmdate('H:00', $hour) . ' UTC'; }
            // the day just ended, once: rolled up, then old rows trimmed
            $day = gmdate('Y-m-d', $now - 86400);
            if (self::once($pdo, 'ch:day', $day)) { $did[] = 'day ' . $day . ': ' . self::rollup($pdo, $day) . ' row(s)'; $did[] = self::trim($pdo, $now) . ' trimmed'; }
        } catch (Throwable $x) { error_log('historian tick: ' . $x->getMessage()); }
        return $did;
    }

    /**
     * The historian's own time, each watch (the session manager, 2026-11-18: "time the tick's historian step ... a heavy
     * watch shows on the board itself"): kept as a reading of job:control_tick (hist_ms), and judged as 0171 §5 judges a
     * job: slow when over its usual (the middle of its last 20) × control_slow_factor and over 20 seconds; a warning on
     * the board until a watch takes its usual time again. Returns whether it was slow. Never throws.
     */
    public static function timed(PDO $pdo, int $ms, ?int $now = null): bool
    {
        try {
            self::ensure($pdo);
            $past = array_map('intval', $pdo->query("SELECT value FROM control_readings WHERE proc = 'job:control_tick' AND reading = 'hist_ms' ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_COLUMN));
            $pdo->prepare("INSERT INTO control_readings (proc, reading, value, state, at) VALUES ('job:control_tick', 'hist_ms', ?, NULL, ?)")->execute([$ms, gmdate('Y-m-d H:i:s', $now ?? time())]);
            require_once __DIR__ . '/ControlAlarms.php'; require_once __DIR__ . '/Thresholds.php';
            $f = (float) (Thresholds::get($pdo, 'control_slow_factor') ?? 3);
            sort($past); $usual = $past ? $past[intdiv(count($past), 2)] : 0; $lim = max(20000, (int) ($usual * $f));
            if ($ms > $lim && count($past) >= 5) {
                ControlAlarms::raise($pdo, 'watch:history:slow', 'job:control_tick', 'warning', 'slow', 'The board\'s watch is slow keeping history',
                    'Its history step took ' . round($ms / 1000, 1) . ' s against its usual ' . round($usual / 1000, 1) . ' s: the watch\'s other checks wait on it.', 'Look at how many processes and readings there are; a slow ledger query is the usual cause. Lower control_readings_days in Thresholds & gates if the tables have grown.', round($ms / 1000, 1) . ' s (usual ' . round($usual / 1000, 1) . ')', [], true, false);
                return true;
            }
            ControlAlarms::clear($pdo, 'watch:history:slow', 'Its history step took ' . round($ms / 1000, 1) . ' s, its usual time.');
            return false;
        } catch (Throwable $x) { error_log('historian timed: ' . $x->getMessage()); return false; }
    }

    /** Each process's newest state: proc => [state, at]. */
    private static function lastStates(PDO $pdo): array
    {
        $out = [];
        foreach ($pdo->query("SELECT r.proc, r.state, r.at FROM control_readings r JOIN (SELECT proc, MAX(id) id FROM control_readings WHERE reading = 'state' GROUP BY proc) m ON m.id = r.id")->fetchAll(PDO::FETCH_ASSOC) as $r)
            $out[(string) $r['proc']] = [(string) $r['state'], (int) strtotime($r['at'] . ' UTC')];
        return $out;
    }

    /** True the first time it's asked for this value of $key (kept in search_index_state, like the board's other marks). */
    private static function once(PDO $pdo, string $key, string $value): bool
    {
        require_once __DIR__ . '/SearchIndex.php';
        if ((string) SearchIndex::state($pdo, $key) === $value) return false;
        SearchIndex::setState($pdo, $key, $value);
        return true;
    }

    /** One hour's counts for every process (only those not zero), stamped at the hour's start. */
    private static function writeHour(PDO $pdo, int $hour, int $now, array $lights): int
    {
        require_once __DIR__ . '/ControlBoard.php'; require_once __DIR__ . '/ControlRegister.php'; require_once __DIR__ . '/SystemStart.php';
        $w = [$now - $hour, $now - $hour - 3600];   // seconds ago: [from, to]
        $ins = $pdo->prepare('INSERT INTO control_readings (proc, reading, value, state, at) VALUES (?, ?, ?, NULL, ?)');
        $at = gmdate('Y-m-d H:i:s', $hour); $n = 0;
        $put = function (string $id, array $v) use ($ins, $at, &$n) { foreach ($v as $k => $x) if ((float) $x != 0.0) { $ins->execute([$id, $k, (float) $x, $at]); $n++; } };
        $usage = [];
        try { require_once __DIR__ . '/Operations.php'; $usage = Operations::usage($pdo); } catch (Throwable $x) {}
        foreach (array_keys($lights) as $id) {
            $eps = []; $tasks = []; $jobs = [];
            if (str_starts_with($id, 'wf:')) { $pt = ControlRegister::of($pdo, substr($id, 3)); $eps = array_values(array_filter($pt['endpoints'], fn ($e) => !in_array($e, ['crawl/service', 'crawl/usage'], true))); $tasks = $pt['tasks']; $jobs = $pt['jobs']; }
            elseif (str_starts_with($id, 't:')) { $d = SystemStart::TASKS[substr($id, 2)] ?? null; if ($d) { $tasks = (array) $d[4]; $jobs = (array) $d[3]; } }
            elseif (str_starts_with($id, 'wk:')) { $k = substr($id, 3); $wk = ControlRegister::WORKERS[$k] ?? null; if ($wk) { $eps = $wk[2]; foreach (ControlRegister::ENDPOINTS as $e => [, $for]) if (in_array('@' . $k, $for, true) || ($k === 'crawler' && !array_filter($for, fn ($f) => $f[0] === '@' || $f === 'W0'))) $eps[] = $e; $eps = array_values(array_unique($eps)); } }
            elseif (str_starts_with($id, 'job:')) $jobs = [substr($id, 4)];
            $c = $eps ? ControlBoard::calls($pdo, $eps, $w) : null;
            $o = $tasks ? ControlBoard::outcomes($pdo, $tasks, $w) : [];
            $j = $jobs ? ControlBoard::jobRuns($pdo, $jobs, $w) : [0, 0];
            $v = ['runs' => array_sum($o) + $j[0] + $j[1], 'failed' => (int) ($o['failed'] ?? 0) + $j[1]];
            if ($c) $v += ['calls' => $c['calls'], 'in' => $c['received'], 'stored' => $c['stored'] + $c['updated'], 'refused' => $c['refused'], 'errors' => $c['errors'], 'ms' => $c['ms']];
            if (str_starts_with($id, 'svc:') && isset($usage[substr($id, 4)])) {
                $u = $usage[substr($id, 4)];
                $v['spend'] = round(array_sum(array_column($u, 'cost')), 2); $v['cap_pct'] = $u ? max(array_column($u, 'pct')) : 0;
            }
            $put($id, $v);
        }
        return $n;
    }

    /** One finished day into control_daily: each count's min, max, last and sum; each state's time red, amber, blue, up and due. */
    public static function rollup(PDO $pdo, string $day): int
    {
        self::ensure($pdo);
        $from = (int) strtotime($day . ' 00:00:00 UTC'); $to = $from + 86400;
        $put = $pdo->prepare('REPLACE INTO control_daily (day, proc, reading, vmin, vmax, vlast, vsum, red_s, amber_s, blue_s, up_s, due_s) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $n = 0;
        $st = $pdo->prepare("SELECT proc, reading, MIN(value) vmin, MAX(value) vmax, SUM(value) vsum, SUBSTRING_INDEX(GROUP_CONCAT(value ORDER BY at DESC, id DESC), ',', 1) vlast
            FROM control_readings WHERE reading <> 'state' AND at >= ? AND at < ? GROUP BY proc, reading");   // hist_ms too: the watch's own time, day by day
        $st->execute([gmdate('Y-m-d H:i:s', $from), gmdate('Y-m-d H:i:s', $to)]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $put->execute([$day, $r['proc'], $r['reading'], $r['vmin'], $r['vmax'], $r['vlast'], $r['vsum'], 0, 0, 0, 0, 0]); $n++; }
        foreach (self::durations($pdo, null, $from, $to) as $proc => $d) {
            $put->execute([$day, $proc, 'state', null, null, null, null, $d['bad'], $d['warn'] + $d['hold'], $d['maint'], $d['up'], $d['due']]); $n++;
        }
        return $n;
    }

    /** Raw rows older than keepDays, and daily rows older than 400 days, removed. */
    private static function trim(PDO $pdo, int $now): int
    {
        $n = $pdo->exec("DELETE FROM control_readings WHERE at < '" . gmdate('Y-m-d H:i:s', $now - self::keepDays($pdo) * 86400) . "' LIMIT 50000");
        $n += $pdo->exec("DELETE FROM control_daily WHERE day < '" . gmdate('Y-m-d', $now - 400 * 86400) . "'");
        return (int) $n;
    }

    // ---- reading -----------------------------------------------------------------------------------------------------

    /**
     * Seconds in each state between $from and $to, per process (null: all), from its state rows (the last one before
     * $from carries in): proc => [ok, warn, hold, bad, maint, off, wait, up, down, due]. Time before a process's first
     * row isn't counted. due = up + down (the time it should have been on).
     */
    public static function durations(PDO $pdo, ?array $procs, int $from, int $to): array
    {
        self::ensure($pdo);
        $in = $procs !== null ? ($procs ? ' AND proc IN (' . implode(',', array_map(fn ($p) => $pdo->quote($p), $procs)) . ')' : ' AND 1 = 0') : '';
        $f = gmdate('Y-m-d H:i:s', $from); $t = gmdate('Y-m-d H:i:s', $to);
        $rows = $pdo->query("SELECT r.proc, r.state, r.at FROM control_readings r JOIN (SELECT proc, MAX(id) id FROM control_readings WHERE reading = 'state' AND at < '$f'$in GROUP BY proc) m ON m.id = r.id
            UNION ALL SELECT proc, state, at FROM control_readings WHERE reading = 'state' AND at >= '$f' AND at < '$t'$in ORDER BY proc, at")->fetchAll(PDO::FETCH_ASSOC);
        $by = []; foreach ($rows as $r) $by[(string) $r['proc']][] = [max($from, (int) strtotime($r['at'] . ' UTC')), (string) $r['state']];
        $out = [];
        foreach ($by as $proc => $list) {
            $d = array_fill_keys(['ok', 'warn', 'hold', 'bad', 'maint', 'off', 'wait', 'up', 'down', 'due'], 0);
            foreach ($list as $i => [$at, $s]) {
                $end = $list[$i + 1][0] ?? min($to, time());
                $sec = max(0, $end - $at); $s = isset(self::STATES[$s]) ? $s : 'wait';
                $d[$s === 'new' || $s === 'na' ? 'wait' : $s] += $sec;
                $band = self::STATES[$s][1];
                if ($band === 'up') $d['up'] += $sec; elseif ($band === 'down') $d['down'] += $sec;
            }
            $d['due'] = $d['up'] + $d['down'];
            $out[$proc] = $d;
        }
        return $out;
    }

    /** Uptime as a percentage (one decimal), or null when it wasn't due to be on at all. */
    public static function uptime(array $d): ?float
    {
        return !empty($d['due']) ? round(100 * $d['up'] / $d['due'], 1) : null;
    }

    /**
     * A trend for one process, or a system's processes summed (sys:<key>): buckets over the range (hours for 24h, 6 hours
     * for 7d, days for 30d), each with its counts and its state (the worst it was in, of up, down and out), plus totals
     * and uptime. Returns ['range', 'label', 'buckets' => [[at, counts, state]], 'totals', 'uptime', 'procs'].
     */
    public static function trend(PDO $pdo, string $id, string $range, ?int $now = null): array
    {
        self::ensure($pdo);
        $now = $now ?? time();
        [$span, $step, $label] = self::RANGES[$range] ?? self::RANGES['24h'];
        $procs = [$id];
        if (str_starts_with($id, 'sys:')) { require_once __DIR__ . '/ControlRegister.php'; $procs = array_keys(array_filter(ControlRegister::processes($pdo), fn ($p) => $p[0] === substr($id, 4))); }
        $end = intdiv($now, $step) * $step + $step; $start = $end - $span;
        $buckets = []; for ($b = $start; $b < $end; $b += $step) $buckets[$b] = ['at' => $b, 'c' => [], 'state' => ''];
        $totals = array_fill_keys(array_keys(self::COUNTS), 0); $msN = 0; $msSum = 0.0;
        if ($procs) {
            $in = implode(',', array_map(fn ($p) => $pdo->quote($p), $procs));
            $st = $pdo->query("SELECT reading, value, at FROM control_readings WHERE proc IN ($in) AND reading NOT IN ('state', 'hist_ms') AND at >= '" . gmdate('Y-m-d H:i:s', $start) . "' AND at < '" . gmdate('Y-m-d H:i:s', $end) . "'");
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $b = $start + intdiv((int) strtotime($r['at'] . ' UTC') - $start, $step) * $step; $k = (string) $r['reading']; $v = (float) $r['value'];
                if (!isset($buckets[$b])) continue;
                if ($k === 'ms') { $buckets[$b]['c']['ms_n'] = ($buckets[$b]['c']['ms_n'] ?? 0) + 1; $buckets[$b]['c']['ms_s'] = ($buckets[$b]['c']['ms_s'] ?? 0) + $v; $msN++; $msSum += $v; continue; }
                if (in_array($k, ['spend', 'cap_pct'], true)) { $buckets[$b]['c'][$k] = max($buckets[$b]['c'][$k] ?? 0, $v); $totals[$k] = max($totals[$k], $v); continue; }   // month-to-date: the latest, not a sum
                $buckets[$b]['c'][$k] = ($buckets[$b]['c'][$k] ?? 0) + $v; $totals[$k] = ($totals[$k] ?? 0) + $v;
            }
        }
        foreach ($buckets as $b => &$bk) {
            if (!empty($bk['c']['ms_n'])) $bk['c']['ms'] = round($bk['c']['ms_s'] / $bk['c']['ms_n']);
            unset($bk['c']['ms_n'], $bk['c']['ms_s']);
            $d = $procs ? self::durations($pdo, $procs, $b, min($b + $step, $now)) : [];
            $sum = ['up' => 0, 'down' => 0, 'maint' => 0, 'due' => 0]; foreach ($d as $x) foreach ($sum as $k => $_) $sum[$k] += $x[$k];
            $bk['state'] = $b >= $now ? '' : ($sum['down'] ? 'down' : ($sum['maint'] && !$sum['up'] ? 'out' : ($sum['up'] ? 'up' : '')));
        }
        unset($bk);
        $totals['ms'] = $msN ? round($msSum / $msN) : 0;
        $all = self::durations($pdo, $procs, $start, min($end, $now)); $sum = ['up' => 0, 'down' => 0, 'due' => 0]; foreach ($all as $x) foreach ($sum as $k => $_) $sum[$k] += $x[$k];
        return ['range' => $range, 'label' => $label, 'step' => $step, 'buckets' => array_values($buckets), 'totals' => $totals, 'uptime' => self::uptime($sum), 'procs' => count($procs)];
    }

    // ---- drawing -----------------------------------------------------------------------------------------------------

    /** A trend as HTML: the range buttons, a small inline SVG (bars of activity over a state strip) and its numbers in words. */
    public static function html(array $t, string $id): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $bs = $t['buckets']; $n = max(1, count($bs));
        // the bars: records in where a process takes records, else runs, else worker calls
        $key = $t['totals']['in'] > 0 ? 'in' : ($t['totals']['runs'] > 0 ? 'runs' : 'calls');
        $max = 0.0; foreach ($bs as $b) $max = max($max, (float) ($b['c'][$key] ?? 0));
        $W = 300; $H = 54; $bw = $W / $n; $svg = '';
        foreach ($bs as $i => $b) {
            $v = (float) ($b['c'][$key] ?? 0); $x = round($i * $bw + 0.5, 2); $w = round(max(1, $bw - 1), 2);
            if ($v > 0 && $max > 0) { $h = max(1.5, round(38 * $v / $max, 2)); $svg .= '<rect x="' . $x . '" y="' . (40 - $h) . '" width="' . $w . '" height="' . $h . '" fill="var(--cb-bar)"><title>' . $e(gmdate('M j, H:i', $b['at']) . ' UTC: ' . number_format($v) . ' ' . self::COUNTS[$key]) . '</title></rect>'; }
            $col = ['up' => 'var(--cb-up)', 'down' => 'var(--cb-fail)', 'out' => 'var(--cb-maint)'][$b['state']] ?? 'var(--cb-none)';
            $svg .= '<rect x="' . $x . '" y="45" width="' . $w . '" height="7" rx="1" fill="' . $col . '"><title>' . $e(gmdate('M j, H:i', $b['at']) . ' UTC: ' . (['up' => 'working (green or amber)', 'down' => 'red', 'out' => 'in maintenance'][$b['state']] ?? 'off or not tested')) . '</title></rect>';
        }
        $tt = $t['totals'];
        $words = [];
        $words[] = $t['uptime'] === null ? 'Uptime: not due to be on' : 'Uptime ' . rtrim(rtrim(number_format($t['uptime'], 1), '0'), '.') . '%';
        if ($tt['in']) $words[] = number_format($tt['in']) . ' records in (' . number_format($tt['stored']) . ' stored, ' . number_format($tt['refused']) . ' refused)';
        if ($tt['runs']) $words[] = number_format($tt['runs']) . ' runs' . ($tt['failed'] ? ', ' . number_format($tt['failed']) . ' failed' : '');
        if ($tt['calls']) $words[] = number_format($tt['calls']) . ' worker calls' . ($tt['errors'] ? ', ' . number_format($tt['errors']) . ' server errors' : '') . ($tt['ms'] ? ', ' . number_format($tt['ms']) . ' ms a call' : '');
        if ($tt['spend'] || $tt['cap_pct']) $words[] = '$' . number_format($tt['spend'], 2) . ' this month, ' . (int) $tt['cap_pct'] . '% of its cap';
        $btns = '';
        foreach (self::RANGES as $k => [, , $l]) $btns .= '<button type="button" class="ak-b cb-xs' . ($k === $t['range'] ? ' on' : '') . '" data-cb-range="' . $k . '" aria-pressed="' . ($k === $t['range'] ? 'true' : 'false') . '" title="' . $e(ucfirst($l)) . '">' . $k . '</button>';
        $aria = ucfirst($t['label']) . ': ' . implode('; ', $words) . '. Bars: ' . self::COUNTS[$key] . '; the strip below: green or amber working, red down, blue in maintenance.';
        return '<div class="cb-tr" data-cb-tr="' . $e($id) . '" data-range="' . $e($t['range']) . '"><div class="cb-trb" role="group" aria-label="Range">' . $btns . '</div>'
            . '<svg class="cb-trs" viewBox="0 0 ' . $W . ' ' . $H . '" preserveAspectRatio="none" role="img" aria-label="' . $e($aria) . '">' . $svg . '</svg>'
            . '<p class="cb-trw">' . $e(implode(' · ', $words)) . ($t['procs'] > 1 ? ' <small>(' . (int) $t['procs'] . ' processes)</small>' : '') . ' <small>Bars: ' . $e(self::COUNTS[$key]) . ', ' . $e($t['label']) . '.</small></p></div>';
    }
}
