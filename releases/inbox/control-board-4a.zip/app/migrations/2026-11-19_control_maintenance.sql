-- The System Control Board's maintenance windows (decisions/0171 §2.5, release 4a): a process taken out of service on
-- purpose, with why, from, Back by, who, and when it came back. Staging class: own (app/lib/staging-tables.php).
-- Safe to run twice; ControlMaintenance::ensure() makes the same table if this hasn't run yet.
CREATE TABLE IF NOT EXISTS control_maintenance (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  proc VARCHAR(60) NOT NULL,
  state VARCHAR(10) NOT NULL DEFAULT 'planned',
  from_at DATETIME NOT NULL,
  until_at DATETIME NOT NULL,
  why VARCHAR(255) NOT NULL,
  by_uid INT UNSIGNED NULL,
  by_name VARCHAR(80) NULL,
  out_at DATETIME NULL,
  stopped VARCHAR(255) NULL,
  back_at DATETIME NULL,
  back_by VARCHAR(80) NULL,
  note VARCHAR(400) NULL,
  KEY proc_state (proc, state),
  KEY state (state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
