<?php
// app/scripts/vectors_tick.php — The vector index's upkeep (decisions/0164 §5.2; 0163 §8 stage 11): public listings whose
// text changed are embedded by Gemini's free model (public text only) and kept on Supabase's free tier. Shipped off: it
// runs only while automation, W3, Supabase's service and AI use's "vector index" are on, and SUPABASE_URL and
// SUPABASE_SERVICE_KEY are in .env. Not in Scheduler::AUTO: added in System Configuration → Scheduled tasks when wanted.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('vectors_tick');
require_once __DIR__ . '/../lib/Vectors.php';
$pdo = Database::connection();
if (($w = Vectors::off($pdo)) !== null) { echo 'Not run: ' . $w . "\n"; exit(0); }
echo 'Vector index: ' . Vectors::tick($pdo, 50) . " listings indexed.\n";
