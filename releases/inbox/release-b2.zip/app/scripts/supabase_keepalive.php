<?php
// app/scripts/supabase_keepalive.php — Supabase's keep-alive (decisions/0164 §5.2): one tiny read a day so the free project
// doesn't pause after a week idle. Under Supabase's own switch and keys, not the master (it gathers nothing, costs nothing).
// Not in Scheduler::AUTO: added in System Configuration → Scheduled tasks once Supabase is connected.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('supabase_keepalive');
require_once __DIR__ . '/../lib/Vectors.php';
echo Vectors::keepAlive(Database::connection()) . "\n";
