<?php
// app/lib/GeminiCompare.php — The sample comparison before any feature moves to Gemini (decisions/0164 §2.3, 0163 §11:
// "a director's call on AI use, made after the sample comparison: a sample read by both, side by side"). A director
// presses Compare on AI use: up to 5 public pages from the source register (sites we read, never cite-only) are fetched
// once, cleaned by Gemini::safe, and read by Claude (Haiku, inside the AI cap, counted) and by Gemini (the free tier,
// through every gate). Both answers are kept side by side with how far they agree, for the director to judge. Nothing is
// stored as a fact; nothing is listed. It changes no provider: moving page_read is the separate Provider choice.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Gemini.php';
require_once __DIR__ . '/AiClient.php';

final class GeminiCompare
{
    public const PAGES = 5;
    private const STATE = 'gemini:compare';
    private const SCHEMA = ['type' => 'object', 'properties' => ['places' => ['type' => 'array', 'items' => ['type' => 'object',
        'properties' => ['name' => ['type' => 'string'], 'street' => ['type' => 'string'], 'city' => ['type' => 'string'], 'phone' => ['type' => 'string'], 'website' => ['type' => 'string']],
        'required' => ['name', 'street', 'city', 'phone', 'website'], 'additionalProperties' => false]]], 'required' => ['places'], 'additionalProperties' => false];

    /** Public pages to compare on: the source register's sites we read (rule "facts"), each one's home page. */
    public static function pages(PDO $pdo, int $n = self::PAGES): array
    {
        require_once __DIR__ . '/crawler/SourceIndex.php';
        $out = [];
        try {
            foreach ($pdo->query("SELECT host, home_url FROM " . Database::t('reference_sources') . " WHERE status = 'read' ORDER BY last_read_at DESC LIMIT 60")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                if (in_array(SourceIndex::useRule($pdo, (string) $r['host']), ['cite', 'ignore'], true)) continue;
                $out[] = (string) ($r['home_url'] ?: 'https://' . $r['host'] . '/');
                if (count($out) >= $n) break;
            }
        } catch (Throwable $x) { error_log('gemini compare pages: ' . $x->getMessage()); }
        return $out;
    }

    /** Runs the comparison. Returns the stored result: ['at', 'by', 'pages' => [[url, removed, claude[], gemini[], agree, why]]]. */
    public static function run(PDO $pdo, int $uid, string $who): array
    {
        if (($w = Gemini::refused('page_read')) !== null) throw new RuntimeException($w);
        if (!AiClient::on('gemini')) throw new RuntimeException('Gemini isn\'t connected: add GEMINI_API_KEY to .env (File Manager).');
        if (!AiClient::on('claude')) throw new RuntimeException('Claude isn\'t connected (ANTHROPIC_API_KEY in .env).');
        if (AiClient::overCap($pdo)) throw new RuntimeException('The month\'s AI cap is reached: Claude\'s side waits until the 1st.');
        @set_time_limit(300);
        require_once __DIR__ . '/crawler/SiteFetcher.php';
        $res = ['at' => gmdate('c'), 'by' => $who, 'pages' => []];
        foreach (self::pages($pdo) as $url) {
            $row = ['url' => $url, 'removed' => [], 'claude' => [], 'gemini' => [], 'agree' => 0, 'why' => ''];
            try {
                $pages = (new SiteFetcher(['max_pages' => 1]))->fetch(SiteFetcher::normalizeStartUrl($url))['pages'] ?? [];   // robots.txt, the pace, held sites (SiteFetcher)
                $text = (string) ($pages[0]['text'] ?? strip_tags((string) ($pages[0]['html'] ?? '')));
                if (trim($text) === '') { $row['why'] = 'The page didn\'t load (or robots.txt asks us not to).'; $res['pages'][] = $row; continue; }
                [$clean, $gone] = Gemini::safe($text, $pdo);
                $row['removed'] = $gone; $clean = mb_substr($clean, 0, 20000);
                $ask = "Read the public web page below. List each business, organization or public place it names, with its street, city, phone and website as the page gives them; leave a field empty when the page doesn't say it. Don't guess.\n\nPAGE:\n" . $clean;
                // Claude: Haiku, counted against the AI cap (decisions/0163 §7)
                $c = AiClient::claudeAsk($ask, self::SCHEMA, 'claude-haiku-5-5', 0, 2048);
                AiClient::record($pdo, 'page_read', 0, 'done', ['provider' => 'claude', 'model' => 'claude-haiku-5-5', 'in' => (int) ($c['in'] ?? 0), 'out' => (int) ($c['out'] ?? 0), 'micros' => (int) ($c['micros'] ?? 0)], $uid);
                $row['claude'] = array_slice((array) ($c['data']['places'] ?? []), 0, 40);
                // Gemini: the free tier, through every gate (Gemini::read), from the same cleaned page
                $g = Gemini::read($pdo, 'page_read', 'extract_compare', ['page' => $clean], true);
                if (!$g['ok']) { $row['why'] = 'Gemini: ' . $g['why']; }
                else $row['gemini'] = self::lines($g['text']);
                $row['agree'] = self::agree($row['claude'], $row['gemini']);
            } catch (Throwable $x) { $row['why'] = mb_substr($x->getMessage(), 0, 200); }
            $res['pages'][] = $row;
        }
        require_once __DIR__ . '/SearchIndex.php';
        SearchIndex::setState($pdo, self::STATE, json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $res;
    }

    public static function last(PDO $pdo): ?array
    {
        try { require_once __DIR__ . '/SearchIndex.php'; $v = json_decode(SearchIndex::state($pdo, self::STATE), true); return is_array($v) ? $v : null; } catch (Throwable) { return null; }
    }

    /** Gemini's JSON lines (or a JSON list) as places. */
    private static function lines(string $t): array
    {
        $t = trim(preg_replace('/^```(json)?|```$/m', '', $t));
        $j = json_decode($t, true);
        if (is_array($j)) return array_slice(array_values(isset($j['places']) ? (array) $j['places'] : $j), 0, 40);
        $out = [];
        foreach (preg_split('/\R/', $t) as $l) { $x = json_decode(trim($l, " ,\t"), true); if (is_array($x)) $out[] = $x; }
        return array_slice($out, 0, 40);
    }

    /** Share (0–100) of Claude's names Gemini also found, with the same phone where both give one. */
    public static function agree(array $a, array $b): int
    {
        if (!$a) return $b ? 0 : 100;
        require_once __DIR__ . '/ListingIdentity.php';
        $hit = 0;
        foreach ($a as $x) foreach ($b as $y) {
            if (!is_array($x) || !is_array($y)) continue;
            if (ListingIdentity::nameKey((string) ($x['name'] ?? '')) !== ListingIdentity::nameKey((string) ($y['name'] ?? ''))) continue;
            $p1 = ListingIdentity::phoneKey((string) ($x['phone'] ?? '')); $p2 = ListingIdentity::phoneKey((string) ($y['phone'] ?? ''));
            if ($p1 === '' || $p2 === '' || $p1 === $p2) { $hit++; break; }
        }
        return (int) round(100 * $hit / count($a));
    }
}
