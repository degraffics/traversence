<?php
// app/lib/Vectors.php — The sidecar vector index for semantic search (decisions/0164 §5.2, §12 C10; 0163 §8 stage 11):
// Postgres with pgvector on Supabase's free tier, beside MySQL, which stays the record. Embeddings come from Gemini's free
// embedding model, PUBLIC TEXT ONLY (what a listing or a guide shows the public, through Gemini::safe and its gates); a
// person's words, private details and held names never go. Its upkeep is a task under Supabase's card (vectors_tick).
//   setupSql()          the table and the match function, to paste once in Supabase's SQL editor (shown on the card)
//   tick($pdo, $n)      public records changed since their last embedding, $n at a time, paced (supabase_daily)
//   (search, the index's reader, comes with its first caller: semantic search and AI Assist; 0164 §5.2)
// Shipped off: Supabase's service is paused (Operations::ADDED_OFF), the AI feature vector_index is off by default, and
// the job is under the master switch. Needs SUPABASE_URL and SUPABASE_SERVICE_KEY in .env (Jason, 2026-11-15).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Vectors
{
    public const DIM = 768;
    public const MODEL = 'gemini-embedding-001';
    public const FEATURE = 'vector_index';

    public static function setupSql(): string
    {
        return "create extension if not exists vector;\n"
             . "create table if not exists tv_vectors (ref text primary key, kind text not null, place text, body_hash text not null, embedding vector(" . self::DIM . ") not null, updated_at timestamptz not null default now());\n"
             . "create index if not exists tv_vectors_hnsw on tv_vectors using hnsw (embedding vector_cosine_ops);\n"
             . "create or replace function tv_match(q vector(" . self::DIM . "), k int, kinds text[] default null) returns table(ref text, kind text, distance float)\n"
             . "language sql stable as \$\$ select ref, kind, embedding <=> q as distance from tv_vectors where kinds is null or kind = any(kinds) order by embedding <=> q limit k \$\$;";
    }

    private static function env(string $k): string
    {
        $v = getenv($k);
        return $v === false ? '' : trim((string) $v);
    }

    public static function configured(): bool { return self::env('SUPABASE_URL') !== '' && self::env('SUPABASE_SERVICE_KEY') !== ''; }

    /** Why the index may not be used now, or null. */
    public static function off(PDO $pdo): ?string
    {
        if (!self::configured()) return 'Supabase isn\'t connected: SUPABASE_URL and SUPABASE_SERVICE_KEY in .env.';
        require_once __DIR__ . '/Automation.php';
        if (($w = Automation::serviceOff($pdo, 'supabase')) !== null) return $w;
        require_once __DIR__ . '/AiClient.php';
        if (!AiClient::feature($pdo, self::FEATURE)['enabled']) return 'The vector index is switched off on AI use.';
        $host = (string) parse_url(self::env('SUPABASE_URL'), PHP_URL_HOST);
        require_once __DIR__ . '/ServiceHealth.php';
        return ServiceHealth::allowed($pdo, $host);   // holds, bans and staging's answer (StagingGate::hold)
    }

    /** One text's embedding from Gemini (public text only, through its gates and its daily allowance), or null. */
    public static function embed(PDO $pdo, string $text, bool $onDemand = false): ?array
    {
        require_once __DIR__ . '/Gemini.php'; require_once __DIR__ . '/AiClient.php'; require_once __DIR__ . '/Automation.php'; require_once __DIR__ . '/ServiceHealth.php'; require_once __DIR__ . '/StagingGate.php';
        if (Gemini::refused(self::FEATURE) !== null || !AiClient::on('gemini')) return null;
        if (Automation::serviceOff($pdo, Gemini::SERVICE) !== null || ServiceHealth::allowed($pdo, Gemini::HOST) !== null || Gemini::room($pdo, $onDemand) !== null) return null;
        [$clean] = Gemini::safe($text, $pdo);
        if ($clean === '') return null;
        $url = 'https://' . Gemini::HOST . '/v1beta/models/' . self::MODEL . ':embedContent';
        if (StagingGate::hold($url, 'Gemini: embeddings') !== null) return null;
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'x-goog-api-key: ' . AiClient::geminiKey()],
            CURLOPT_POSTFIELDS => json_encode(['content' => ['parts' => [['text' => mb_substr($clean, 0, 8000)]]], 'outputDimensionality' => self::DIM], JSON_UNESCAPED_UNICODE)]);
        $b = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
        $v = is_string($b) ? (json_decode($b, true)['embedding']['values'] ?? null) : null;
        AiClient::record($pdo, self::FEATURE, 0, is_array($v) ? 'done' : 'failed', ['provider' => 'gemini', 'model' => self::MODEL, 'micros' => 0]);
        if (!is_array($v) || count($v) !== self::DIM) { ServiceHealth::siteFailed($pdo, $url, $code, is_string($b) ? mb_substr($b, 0, 1000) : '', $err, 'Gemini embeddings'); return null; }
        return array_map('floatval', $v);
    }

    /** Supabase's REST call (PostgREST). */
    private static function rest(PDO $pdo, string $method, string $path, $body = null): array
    {
        require_once __DIR__ . '/StagingGate.php'; require_once __DIR__ . '/ServiceHealth.php';
        $url = rtrim(self::env('SUPABASE_URL'), '/') . '/rest/v1/' . $path;
        if (($w = StagingGate::hold($url, 'Supabase: ' . $path)) !== null) throw new RuntimeException($w);
        $k = self::env('SUPABASE_SERVICE_KEY');
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_HTTPHEADER => ['apikey: ' . $k, 'Authorization: Bearer ' . $k, 'Content-Type: application/json', 'Prefer: resolution=merge-duplicates,return=minimal']]
            + ($body !== null ? [CURLOPT_POSTFIELDS => json_encode($body)] : []));
        $b = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
        if ($code < 200 || $code >= 300) { ServiceHealth::siteFailed($pdo, $url, $code, is_string($b) ? mb_substr($b, 0, 1000) : '', $err, 'Supabase'); throw new RuntimeException('Supabase answered ' . ($code ?: $err)); }
        return is_string($b) && $b !== '' ? (json_decode($b, true) ?: []) : [];
    }

    /**
     * The free project's keep-alive (Supabase pauses a free project after about a week idle): one tiny read a day. Under
     * Supabase's own switch and its keys only, not the master: it gathers nothing and costs nothing (session manager,
     * 2026-11-15). While the project is paused anyway, search keeps to the normal index.
     */
    public static function keepAlive(PDO $pdo): string
    {
        if (!self::configured()) return 'Supabase isn\'t connected: SUPABASE_URL and SUPABASE_SERVICE_KEY in .env.';
        require_once __DIR__ . '/Automation.php';
        if (($w = Automation::serviceOff($pdo, 'supabase')) !== null) return $w;
        try { self::rest($pdo, 'GET', 'tv_vectors?select=ref&limit=1'); return 'Supabase answered: kept awake.'; }
        catch (Throwable $x) { return 'Supabase didn\'t answer: ' . $x->getMessage(); }
    }

    /** The public text of a listing: its name, its kind, its town and what it shows the public (never contact details). */
    private static function listingText(array $r): string
    {
        return trim($r['name'] . '. ' . ($r['cat'] ?? '') . ' in ' . ($r['city'] ?? '') . '. ' . mb_substr((string) ($r['about'] ?? ''), 0, 1500));
    }

    /** Upkeep: public listings whose text changed since their embedding, $n at a time. Returns how many were indexed. */
    public static function tick(PDO $pdo, int $n = 50): int
    {
        if (self::off($pdo) !== null) return 0;
        require_once __DIR__ . '/Thresholds.php'; require_once __DIR__ . '/SearchIndex.php'; require_once __DIR__ . '/ListingSafety.php';
        $today = 'vectors:day:' . gmdate('Y-m-d');
        $done = (int) SearchIndex::state($pdo, $today);
        $room = max(0, (int) Thresholds::get($pdo, 'supabase_daily') - $done);
        $n = min($n, $room);
        if ($n <= 0) return 0;
        $since = SearchIndex::state($pdo, 'vectors:since') ?: '2000-01-01 00:00:00';
        $st = $pdo->prepare("SELECT e.id, e.name, e.category_id, e.updated_at, c.name AS cat, JSON_UNQUOTE(m.meta_value) AS city, JSON_UNQUOTE(d.meta_value) AS about
                               FROM entities e LEFT JOIN categories c ON c.id = e.category_id
                               LEFT JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'city'
                               LEFT JOIN entity_metadata d ON d.entity_id = e.id AND d.meta_key = 'description'
                              WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.updated_at > ? ORDER BY e.updated_at, e.id LIMIT " . (int) $n);
        $st->execute([$since]);
        $rows = []; $last = $since;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if (ListingSafety::isConfidential($r['category_id'] !== null ? (int) $r['category_id'] : null, (string) $r['name'])) { $last = (string) $r['updated_at']; continue; }   // a confidential place is never sent (T1)
            $t = self::listingText($r);
            $v = self::embed($pdo, $t);
            if ($v === null) break;   // Gemini's allowance or a hold: this one and the rest wait for the next run
            $last = (string) $r['updated_at'];
            $rows[] = ['ref' => 'listing:' . (int) $r['id'], 'kind' => 'listing', 'place' => (string) ($r['city'] ?? ''), 'body_hash' => sha1($t), 'embedding' => '[' . implode(',', $v) . ']'];
        }
        if ($rows) { self::rest($pdo, 'POST', 'tv_vectors', $rows); SearchIndex::setState($pdo, $today, (string) ($done + count($rows))); }
        SearchIndex::setState($pdo, 'vectors:since', $last);
        return count($rows);
    }
}
