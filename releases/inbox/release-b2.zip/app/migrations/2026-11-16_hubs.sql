-- Release B (decisions/0164 R17, §7.1; 0163 §8 stage 10): a hub's stage on its readiness meter and its opening budget,
-- and W14's staged authority sources (Arizona's and New Mexico's from the rural test's Run 2, staged by hand, switched
-- off). Safe to run twice: tables if missing, rows only if missing.
CREATE TABLE IF NOT EXISTS hub_stages (
  hub_id INT UNSIGNED NOT NULL,
  stage VARCHAR(10) NOT NULL DEFAULT 'open',
  state CHAR(2) DEFAULT NULL,
  opening_budget_usd DECIMAL(10,2) DEFAULT NULL,
  set_by INT UNSIGNED DEFAULT NULL,
  set_at DATETIME DEFAULT NULL,
  PRIMARY KEY (hub_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS authority_sources (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  state CHAR(2) NOT NULL,
  kind VARCHAR(20) NOT NULL,
  name VARCHAR(160) NOT NULL,
  url VARCHAR(500) NOT NULL,
  host VARCHAR(160) NOT NULL,
  service VARCHAR(20) DEFAULT NULL,
  real_use VARCHAR(10) NOT NULL DEFAULT 'lookup',
  proves VARCHAR(200) DEFAULT NULL,
  terms_url VARCHAR(500) DEFAULT NULL,
  terms_read_at DATETIME DEFAULT NULL,
  terms_by INT UNSIGNED DEFAULT NULL,
  reader_ok_at DATETIME DEFAULT NULL,
  provenance VARCHAR(500) DEFAULT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'staged',
  enabled TINYINT NOT NULL DEFAULT 0,
  on_by INT UNSIGNED DEFAULT NULL,
  on_at DATETIME DEFAULT NULL,
  note VARCHAR(500) DEFAULT NULL,
  added_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_state_url (state, url(190))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO authority_sources (state, kind, name, url, host, service, real_use, proves, terms_url, provenance, note, added_at) VALUES
('AZ', 'company', 'Arizona Corporation Commission (Arizona Business Center)', 'https://arizonabusinesscenter.azcc.gov/', 'arizonabusinesscenter.azcc.gov', 'azcc', 'lookup', 'exists, its registered name and address', 'https://azcc.gov/', 'Run 2 (research/rural-test-2026-11-14.md §8): moved from ecorp.azcc.gov', 'Terms to read before use', UTC_TIMESTAMP()),
('AZ', 'sales_tax', 'Arizona TPT licence lookup', 'https://aztaxes.gov/', 'aztaxes.gov', NULL, 'claim', 'a transaction privilege tax licence (by its number)', 'https://azdor.gov/', 'Run 2: a licence number behind a CAPTCHA', 'A claim-time check of the number the owner gives', UTC_TIMESTAMP()),
('AZ', 'liquor', 'Arizona Department of Liquor Licenses and Control', 'https://azliquor.gov/', 'azliquor.gov', 'azlicences', 'blocked', 'a liquor licence: open, kind of business, location', 'https://azliquor.gov/', 'Run 2: a Cloudflare challenge on robots.txt itself', 'Ask for the public licence list as a file (a public-records request)', UTC_TIMESTAMP()),
('AZ', 'contractor', 'Arizona Registrar of Contractors', 'https://roc.az.gov/', 'roc.az.gov', 'azlicences', 'blocked', 'a contractor licence', 'https://roc.az.gov/', 'Run 2: a Cloudflare challenge', 'Ask for the list as a file', UTC_TIMESTAMP()),
('AZ', 'health', 'Apache County health permits', 'https://www.apachecountyaz.gov/', 'apachecountyaz.gov', 'azlicences', 'blocked', 'a food-service permit: open, location', 'https://www.apachecountyaz.gov/', 'Run 2: a Cloudflare challenge', 'Ask for the permit list as a file', UTC_TIMESTAMP()),
('AZ', 'health', 'Navajo County health permits', 'https://www.navajocountyaz.gov/', 'navajocountyaz.gov', 'azlicences', 'blocked', 'a food-service permit: open, location', 'https://www.navajocountyaz.gov/', 'Run 2', 'Ask for the permit list as a file', UTC_TIMESTAMP()),
('NM', 'company', 'New Mexico Secretary of State (business search)', 'https://enterprise.sos.nm.gov/search', 'enterprise.sos.nm.gov', 'nmsos', 'lookup', 'exists, its registered name and address', 'https://www.sos.nm.gov/', 'decisions/0164 §1.5', 'Terms to read before use', UTC_TIMESTAMP()),
('NM', 'liquor', 'New Mexico Alcoholic Beverage Control', 'https://www.rld.nm.gov/alcohol-and-gaming/', 'rld.nm.gov', NULL, 'lookup', 'a liquor licence', 'https://www.rld.nm.gov/', 'decisions/0164 §1.5', 'Terms and the list\'s form to check', UTC_TIMESTAMP());
