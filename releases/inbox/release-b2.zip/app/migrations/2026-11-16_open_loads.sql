-- Release B (decisions/0164 §1.5; 0163 §8 stage 8): each open-dataset load by town and release (Overture, Foursquare), so
-- a town is read once a release and the board shows what each produced. Safe to run twice.
CREATE TABLE IF NOT EXISTS open_loads (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  dataset VARCHAR(20) NOT NULL,
  place_key VARCHAR(40) NOT NULL,
  release_id VARCHAR(40) NOT NULL,
  started_at DATETIME NOT NULL,
  finished_at DATETIME DEFAULT NULL,
  seen INT UNSIGNED NOT NULL DEFAULT 0,
  staged INT UNSIGNED NOT NULL DEFAULT 0,
  listed INT UNSIGNED NOT NULL DEFAULT 0,
  closed INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_load (dataset, place_key, release_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
