<?php
// api/crawl/loads.php — the worker's open-dataset loads (decisions/0164 §1.5; 0163 §8 stage 8; OpenLoads). Worker token.
//   GET ?dataset=overture&release=2026-10-21.0   -> {paused, why} or {towns: [{key, name, state, zip, box}]}
//   POST {dataset, release, key, rows: […]}       -> {seen, staged, listed, closed, skipped}   (≤2000 rows)
//   POST {dataset, release, key, done: true}      -> {ok}
//   POST {geofabrik_probe: [{state, ok, status, bytes, why}]}  -> {ok}
// Shipped off: every answer is "paused" until the master, W1, the dataset's service and its task are on.
declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/crawler/OpenLoads.php';

if (!OpenLoads::ready($pdo)) Response::error('The open loads\' database update hasn\'t run yet.', 503, 'not_configured');
try {
    OpenLoads::ensureTasks($pdo);
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $ds = (string) ($_GET['dataset'] ?? '');
        if (!isset(OpenLoads::DATASETS[$ds])) Response::error('Which dataset?', 422, 'bad_request');
        if (($w = OpenLoads::off($pdo, $ds)) !== null) Response::json(['ok' => true, 'paused' => true, 'why' => $w, 'towns' => []]);
        require_once __DIR__ . '/../../../app/lib/Thresholds.php';
        $n = max(0, (int) Thresholds::get($pdo, 'load_towns_per_run'));
        Response::json(['ok' => true, 'paused' => false, 'towns' => OpenLoads::due($pdo, $ds, mb_substr((string) ($_GET['release'] ?? ''), 0, 40), $n)]);
    }
    Response::requireMethod('POST');
    $b = Response::jsonBody();
    if (isset($b['geofabrik_probe'])) {
        OpenLoads::probed($pdo, (array) $b['geofabrik_probe']);
        Response::json(['ok' => true]);
    }
    $ds = (string) ($b['dataset'] ?? ''); $rel = mb_substr((string) ($b['release'] ?? ''), 0, 40); $key = mb_substr((string) ($b['key'] ?? ''), 0, 40);
    if (!isset(OpenLoads::DATASETS[$ds]) || $rel === '' || $key === '') Response::error('Which dataset, release and town?', 422, 'bad_request');
    if (($w = OpenLoads::off($pdo, $ds)) !== null) Response::json(['ok' => true, 'paused' => true, 'why' => $w]);
    if (!empty($b['done'])) { OpenLoads::finish($pdo, $ds, $rel, $key); Response::json(['ok' => true]); }
    Response::json(['ok' => true] + OpenLoads::batch($pdo, $ds, $rel, $key, (array) ($b['rows'] ?? [])));
} catch (Throwable $e) {
    error_log('api/crawl/loads.php: ' . $e->getMessage());
    Response::error('Could not take the load: ' . mb_substr($e->getMessage(), 0, 200), 500, 'server_error');
}
