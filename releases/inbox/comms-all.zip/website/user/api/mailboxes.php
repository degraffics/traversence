<?php
// /user/api/mailboxes.php — mailboxes read and answered in Pulse (decisions/0172 §4.7; 0167 §2, §2a; app/lib/Mailboxes.php).
// Signed in; only the mailboxes the person reads (their own, or ours they oversee) are ever shown. POSTs need X-CSRF-Token.
//   GET                                 -> {boxes, rows}: the inbox, one row per conversation (?box=, ?q=, ?view=inbox|sent|all)
//   GET ?thread=<mail id>[&pictures=1]   -> one conversation, shown safely; read state written back
//   POST {connect: {provider, address, label, host, port, login, password, smtp_host, smtp_port}}
//   POST {reconnect: id, body|password}  POST {disconnect: id}   POST {approve: id} | {decline: id}  (a manager)
//   POST {act: read|unread|archive|junk, mail: id}   POST {send: {from, to, cc, subject, text, reply_to}}   POST {make_case: id}
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/Mailboxes.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$uid = (int) $me['id'];
try {
    if (!Mailboxes::ready($pdo)) Response::error('Mailboxes in Pulse switch on once the site\'s update has run (within the hour).', 503, 'not_ready');
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['thread'])) Response::json(['ok' => true] + Mailboxes::thread($pdo, $uid, (int) $_GET['thread'], !empty($_GET['pictures'])));
        if (empty($_GET['nosync'])) Mailboxes::syncFor($pdo, $uid);   // fresh at once when the person opens it (§4.7)
        Response::json(['ok' => true, 'csrf' => $_SESSION['csrf_token'] ?? null, 'providers' => Mailboxes::PROVIDERS, 'gmail_signin' => Mailboxes::gmailGate($pdo)]
            + Mailboxes::inbox($pdo, $uid, (int) ($_GET['box'] ?? 0), mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 80), 50, (string) ($_GET['view'] ?? 'inbox')));
    }
    Response::requireMethod('POST');
    Response::requireCsrf();
    $b = Response::jsonBody();
    $say = null; $extra = [];
    if (isset($b['connect'])) { [$id, $say] = Mailboxes::connect($pdo, $uid, 'staff', (array) $b['connect']); $extra['id'] = $id; }
    elseif (isset($b['reconnect'])) $say = Mailboxes::reconnect($pdo, $uid, (int) $b['reconnect'], (string) ($b['password'] ?? $b['body'] ?? ''));
    elseif (isset($b['disconnect'])) $say = Mailboxes::disconnect($pdo, $uid, (int) $b['disconnect']);
    elseif (isset($b['approve'])) $say = Mailboxes::approve($pdo, $uid, (int) $b['approve'], true);
    elseif (isset($b['decline'])) $say = Mailboxes::approve($pdo, $uid, (int) $b['decline'], false);
    elseif (isset($b['act'])) $say = Mailboxes::act($pdo, $uid, (int) ($b['mail'] ?? 0), (string) $b['act']);
    elseif (isset($b['send'])) $say = Mailboxes::send($pdo, $uid, (array) $b['send']);
    elseif (isset($b['make_case'])) $say = Mailboxes::makeCase($pdo, $uid, (int) $b['make_case']);
    else Response::error('Nothing to do.', 422, 'not_allowed');
    if (!empty($b['from_msg'])) {   // pressed inside a message: its body, read again
        require_once __DIR__ . '/../../../app/lib/Notify.php';
        if (($m = Notify::one($pdo, $uid, (int) $b['from_msg'])) && ($body = Notify::body($pdo, $m, $uid))) $extra['html'] = $body['html'];
    }
    Response::json(['ok' => true, 'message' => $say] + $extra);
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'not_allowed');
} catch (Throwable $e) {
    error_log('mailboxes: ' . $e->getMessage());
    Response::error(mb_substr($e->getMessage(), 0, 200) ?: 'That didn\'t work. Try again; still stuck? Write to support@traversence.com.', 500, 'failed');
}
