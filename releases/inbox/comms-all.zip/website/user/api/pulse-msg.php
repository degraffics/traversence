<?php
// /user/api/pulse-msg.php — a dispatcher message opened in place in Pulse (decisions/0172 "The message: what it's for, and
// acting on it inside it"): its body as the part that owns its kind draws it (Notify::BODIES), read live, with its own
// buttons; its route (message control, 0172 §4.3); marked read. And the bell's list: everything unread at Alert or above,
// its colour the highest level waiting. Signed in.
//   GET ?id=<message id>   -> {id, kind, level, title, html, state, route: [{via, stage, detail, at}], when, from, url}
//   GET ?bell=1            -> {top: level|null, items: [{id, level, title, from, when, url}]}
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/Notify.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$uid = (int) $me['id'];
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
try {
    if (isset($_GET['bell'])) {
        $items = []; $top = null; $order = array_keys(Notify::LEVELS);
        if (Notify::ready($pdo)) {
            $st = $pdo->prepare("SELECT id, lvl, title, sender_name, updated_at, url FROM comms_messages WHERE to_user = ? AND read_at IS NULL AND lvl IN ('critical','urgent','alert') ORDER BY FIELD(lvl,'critical','urgent','alert'), updated_at DESC LIMIT 30");
            $st->execute([$uid]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $items[] = ['id' => (int) $r['id'], 'level' => (string) $r['lvl'], 'title' => (string) $r['title'], 'from' => (string) $r['sender_name'] ?: 'Traversence', 'when' => (string) $r['updated_at'], 'url' => (string) $r['url']];
                if ($top === null || array_search($r['lvl'], $order, true) < array_search($top, $order, true)) $top = (string) $r['lvl'];
            }
        }
        Response::json(['ok' => true, 'top' => $top, 'items' => $items]);
    }
    $m = Notify::one($pdo, $uid, (int) ($_GET['id'] ?? 0));
    if (!$m) Response::error('That message isn\'t here any more.', 404, 'not_found');
    Notify::markRead($pdo, $uid, [(int) $m['id']]);
    $body = Notify::body($pdo, $m, $uid);
    $html = $body['html'] ?? ('<p>' . nl2br($e($m['body'])) . '</p>' . ((string) $m['url'] !== '' ? '<p class="tv-msg-acts"><a class="tv-btn" href="' . $e($m['url']) . '">Open it</a></p>' : ''));
    Response::json(['ok' => true, 'id' => (int) $m['id'], 'kind' => (string) $m['kind'], 'level' => (string) $m['lvl'], 'title' => (string) $m['title'], 'html' => $html,
        'state' => (string) ($body['state'] ?? ''), 'route' => array_slice(Notify::routeOf($pdo, (int) $m['id']), -3), 'when' => (string) $m['created_at'], 'from' => (string) $m['sender_name'] ?: 'Traversence', 'url' => (string) $m['url'],
        'csrf' => $_SESSION['csrf_token'] ?? null]);
} catch (Throwable $x) {
    error_log('pulse-msg: ' . $x->getMessage());
    Response::error('That message didn\'t open. Try again; still stuck? Write to support@traversence.com.', 500, 'failed');
}
