<?php
// /user/api/push.php — push on this device (decisions/0172 §4.4, §4.6): the person's devices and our public key. Signed in;
// POSTs need X-CSRF-Token (from GET). js/tv-push.js calls it.
//   GET                                     -> {ok, ready, key, devices: [{id, device, hash, created, last_ok, failed}], csrf}
//                                              (a page knows its own device by sha256 of its endpoint = hash)
//   POST {subscribe: PushSubscription, device: "Chrome on Android"}   this device on
//   POST {unsubscribe: endpoint}            this device off
//   POST {remove: id}                       another of the person's devices off
//   POST {test: true}                       "Push works on this device" to each of them -> {ok, sent, failed, held, none}

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/WebPush.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$uid = (int) $me['id'];
if (!WebPush::ready($pdo)) Response::error('Push isn\'t set up on the site yet. Try again after the next update.', 503, 'not_ready');
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        Response::json(['ok' => true, 'ready' => true, 'key' => WebPush::publicKey(), 'devices' => WebPush::devices($pdo, $uid), 'csrf' => $_SESSION['csrf_token'] ?? null]);
    }
    Response::requireMethod('POST');
    Response::requireCsrf();
    $b = Response::jsonBody();
    if (isset($b['subscribe']) && is_array($b['subscribe'])) {
        WebPush::subscribe($pdo, $uid, $b['subscribe'], (string) ($b['device'] ?? ''));
        Response::json(['ok' => true, 'devices' => WebPush::devices($pdo, $uid)]);
    }
    if (isset($b['unsubscribe'])) {
        WebPush::unsubscribe($pdo, $uid, (string) $b['unsubscribe']);
        Response::json(['ok' => true, 'devices' => WebPush::devices($pdo, $uid)]);
    }
    if (isset($b['remove'])) {
        WebPush::remove($pdo, $uid, (int) $b['remove']);
        Response::json(['ok' => true, 'devices' => WebPush::devices($pdo, $uid)]);
    }
    if (!empty($b['test'])) {
        Response::json(['ok' => true] + WebPush::test($pdo, $uid));
    }
    Response::error('Nothing to do.', 422, 'bad_request');
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'not_allowed');
} catch (RuntimeException $e) {
    error_log('push: ' . $e->getMessage());
    Response::error('Push isn\'t working on the site right now. Our team has been told; try again later.', 503, 'push_unavailable');
}
