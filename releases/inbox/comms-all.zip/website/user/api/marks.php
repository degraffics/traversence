<?php
// /user/api/marks.php — a person's own marks on their Pulse items (decisions/0172 "Flags and tags in Pulse"): Follow up,
// importance, tags, pin, file, archive. Members, business teams and staff alike; never shown to the sender. Signed in;
// POSTs need X-CSRF-Token.
//   GET ?items=comms:1,mail:4          -> {marks: {item: {...}}, tags: [...], folders: {name: n}}
//   GET ?view=pinned|folder|archived|flagged|high|tag|hidden&arg=   -> {marks: {item: {...}}}
//   POST {item, set: {follow, date, tz, flag, importance, pinned, folder, archived, tags, read}}  -> {marks, message}
//   POST {tag: {name, colour, scope}}  -> {tag}       POST {tag_delete: id}
// A message's own button (js/pulse-msg.js) may post {item, set, from_msg}: the answer then carries the message's body again.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/PulseMarks.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$uid = (int) $me['id'];
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['view'])) Response::json(['ok' => true, 'marks' => PulseMarks::view($pdo, $uid, (string) $_GET['view'], (string) ($_GET['arg'] ?? ''))]);
        $items = array_filter(explode(',', (string) ($_GET['items'] ?? '')));
        Response::json(['ok' => true, 'ready' => PulseMarks::ready($pdo), 'marks' => PulseMarks::of($pdo, $uid, $items), 'tags' => PulseMarks::tags($pdo, $uid),
            'folders' => PulseMarks::folders($pdo, $uid), 'scopes' => PulseMarks::scopes($pdo, $uid), 'colours' => PulseMarks::COLOURS, 'due' => PulseMarks::DUE, 'csrf' => $_SESSION['csrf_token'] ?? null]);
    }
    Response::requireMethod('POST');
    Response::requireCsrf();
    $b = Response::jsonBody();
    if (isset($b['tag'])) Response::json(['ok' => true, 'tag' => PulseMarks::addTag($pdo, $uid, (string) ($b['tag']['name'] ?? ''), (string) ($b['tag']['colour'] ?? ''), (string) ($b['tag']['scope'] ?? '')), 'message' => 'Tag added.']);
    if (isset($b['tag_delete'])) { PulseMarks::deleteTag($pdo, $uid, (int) $b['tag_delete']); Response::json(['ok' => true, 'message' => 'Tag removed.']); }
    $r = PulseMarks::set($pdo, $uid, (string) ($b['item'] ?? ''), (array) ($b['set'] ?? []));
    if (!empty($b['from_msg'])) {   // pressed inside a message: its body, read again
        require_once __DIR__ . '/../../../app/lib/Notify.php';
        if (($m = Notify::one($pdo, $uid, (int) $b['from_msg'])) && ($body = Notify::body($pdo, $m, $uid))) $r['html'] = $body['html'];
    }
    Response::json(['ok' => true] + $r);
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'not_allowed');
} catch (Throwable $e) {
    error_log('marks: ' . $e->getMessage());
    Response::error('That didn\'t save. Try again; still stuck? Write to support@traversence.com.', 500, 'failed');
}
