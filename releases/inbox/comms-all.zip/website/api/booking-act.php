<?php
// /api/booking-act.php — the buttons inside a booking's message in Pulse (decisions/0172 §2.5, §6 step 7;
// app/lib/Bookings.php). Signed in; POST JSON with X-CSRF-Token:
//   {act: cancel, order, msg}   the customer cancels a stay or rental not paid yet (MarketCheckout::cancel: theirs, unpaid)
// -> {ok, message, html (the message's body drawn again, when msg is the viewer's own)} or {ok: false, error: {message}}
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Bookings.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$uid = Auth::currentUserId();
if ($uid === null) Response::error('Sign in to manage your booking.', 401, 'unauthenticated');
Response::requireMethod('POST');
Response::requireCsrf();
try {
    [$said, $html] = Bookings::act($pdo, (int) $uid, Response::jsonBody());
    Response::success(['message' => $said] + ($html !== '' ? ['html' => $html] : []));
} catch (InvalidArgumentException $x) {
    Response::error($x->getMessage(), 422, 'not_allowed');
}
