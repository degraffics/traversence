<?php
// /api/comment-act.php — the buttons inside a comment's message in Pulse (decisions/0172 §2.3, §6 step 7;
// app/lib/CommentNotices.php). Signed in; POST JSON with X-CSRF-Token:
//   {act: reply, comment, body, age?, msg}     a public reply (one level), as the person
//   {act: hide|show, comment, msg}             the listing's Owner and Managers, and our staff (Engage::canHide)
//   {act: report, comment, reason, body, msg}  to our Reports (Reports::file)
// -> {ok, message, html (the message's body drawn again, when msg is the viewer's own)} or {ok: false, error: {message}}
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/CommentNotices.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$uid = Auth::currentUserId();
if ($uid === null) Response::error('Sign in to answer it.', 401, 'unauthenticated');
Response::requireMethod('POST');
Response::requireCsrf();
if (!Engage::ready($pdo)) Response::error('Comments aren\'t switched on yet.', 503, 'not_configured');
try {
    [$said, $html] = CommentNotices::act($pdo, (int) $uid, Response::jsonBody());
    Response::success(['message' => $said] + ($html !== '' ? ['html' => $html] : []));
} catch (InvalidArgumentException $x) {
    Response::error($x->getMessage(), 422, str_contains($x->getMessage(), '18 or older') ? 'age' : 'not_allowed');
}
