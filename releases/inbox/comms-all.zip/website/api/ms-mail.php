<?php
// /api/ms-mail.php — Sign in with Microsoft for a mailbox read in Pulse (decisions/0172 §4.7: Microsoft no longer takes
// passwords for IMAP, so Microsoft 365 and Outlook.com connect by sign-in, through Graph). ?start=1 sends the signed-in
// staff member to Microsoft; Microsoft sends them back here with a code, which becomes sealed tokens on the mailbox
// (Mailboxes::connectMicrosoft). The app's keys (MS_MAIL_CLIENT_ID, MS_MAIL_CLIENT_SECRET) are entered by an owner in
// System Configuration → Communications; the redirect address to register is https://traversence.com/api/ms-mail.php.
// Never a dead end: anything that stops here says why and links back to the inbox.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/MsGraphMail.php';
require_once __DIR__ . '/../../app/lib/Mailboxes.php';

header('Cache-Control: no-store');
$back = '/admin/dashboard/inbox';
$done = function (string $msg, bool $ok) use ($back): void {
    header('Location: ' . $back . '#' . ($ok ? 'ok=' : 'error=') . rawurlencode($msg));
    exit;
};
$me = Auth::currentUser();
if ($me === null) { header('Location: /login.php?next=' . rawurlencode('/api/ms-mail.php?start=1')); exit; }
$pdo = Database::connection();
if (!MsGraphMail::ready()) $done('Sign in with Microsoft isn\'t set up yet: an owner adds the app\'s keys in System Configuration → Communications (https://traversence.com/admin/config/communications).', false);

if (isset($_GET['start'])) {
    $state = bin2hex(random_bytes(16));
    $_SESSION['ms_mail_state'] = $state;
    header('Location: ' . MsGraphMail::authUrl($state));
    exit;
}
if (isset($_GET['error'])) $done('Microsoft didn\'t connect it: ' . mb_substr((string) ($_GET['error_description'] ?? $_GET['error']), 0, 200) . ' Try again, or write to support@traversence.com.', false);
$state = (string) ($_GET['state'] ?? '');
if ($state === '' || !hash_equals((string) ($_SESSION['ms_mail_state'] ?? ''), $state)) $done('That sign-in link is old or was opened in another browser. Start again from your inbox.', false);
unset($_SESSION['ms_mail_state']);
try {
    $tok = MsGraphMail::exchange((string) ($_GET['code'] ?? ''));
    [$id, $say] = Mailboxes::connectMicrosoft($pdo, (int) $me['id'], $tok);
    $done($say, true);
} catch (Throwable $e) {
    error_log('ms-mail: ' . $e->getMessage());
    $done($e instanceof InvalidArgumentException ? $e->getMessage() : 'Microsoft\'s sign-in didn\'t finish: ' . mb_substr($e->getMessage(), 0, 160) . ' Try again, or write to support@traversence.com.', false);
}
