<?php
// /api/out.php — counts a visitor's action on a listing (api/lib/ListingActions.php): POST e=<listing id>, a=call|email|
// directions|website|contact, sent by js/out-count.js with navigator.sendBeacon as the link opens. Counts only.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/ListingActions.php';
require_once __DIR__ . '/../../app/lib/PlatformCounts.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
$e = (int) ($_POST['e'] ?? 0);
$a = (string) ($_POST['a'] ?? '');
try {
    $pdo = Database::connection();
    $st = $pdo->prepare("SELECT 1 FROM entities WHERE id = ? AND entity_type = 'merchant'");
    $st->execute([$e]);
    // the team's own taps, and a listing's own people on it, aren't counted
    if ($st->fetchColumn() && !PlatformCounts::isTeam($pdo) && !PlatformCounts::runsListing($pdo, $e)) ListingActions::count($pdo, $e, $a);
} catch (Throwable $x) {
    error_log('out.php: ' . $x->getMessage());
}
http_response_code(204);
