<?php
// /api/group-act.php — the buttons inside a community group's message in Pulse (decisions/0172 §2.8, §6 step 7;
// app/lib/GroupNotices.php). Signed in; POST JSON with X-CSRF-Token:
//   {act: accept|decline, group, member, msg}            a request to join (the group's moderators: Community::manage)
//   {act: keep|remove|remove_member, post, msg}          a reported post (whoever handles its reports: Community::decideReport)
//   {act: mute|unmute, group, msg}                       the person's own link setting for the group's posts
//   {act: report, post, reason, body, msg}               a post, to the group's moderators (danger: our Safety team; Reports::file)
// -> {ok, message, html (the message's body drawn again, when msg is the viewer's own)} or {ok: false, error: {message}}
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/GroupNotices.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$uid = Auth::currentUserId();
if ($uid === null) Response::error('Sign in to do that.', 401, 'unauthenticated');
Response::requireMethod('POST');
Response::requireCsrf();
if (!Community::ready($pdo)) Response::error('Groups aren\'t switched on yet.', 503, 'not_configured');
try {
    [$said, $html] = GroupNotices::act($pdo, (int) $uid, Response::jsonBody());
    Response::success(['message' => $said] + ($html !== '' ? ['html' => $html] : []));
} catch (InvalidArgumentException $x) {
    Response::error($x->getMessage(), 422, 'not_allowed');
}
