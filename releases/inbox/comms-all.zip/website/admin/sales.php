<?php
// admin/sales.php — Sales, an area of the admin dashboard (decisions/0081): turning unclaimed listings into active
// ones. Calls today (follow-ups due, then the best ones to call next), every prospect with filters, a business you
// saw in person added straight into the funnel, the new listings, and the funnel itself. Each prospect: call it,
// log what happened (the next follow-up is set for you), send or copy its claim link.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/Sales.php';
require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
require_once __DIR__ . '/../../app/ui/card-scanner.php';
require_once __DIR__ . '/../../app/ui/lead-panel.php';
require_once __DIR__ . '/../../app/ui/promotions-admin.php';
require_once __DIR__ . '/../../app/lib/StaffLogin.php';

$pdo = Database::connection();
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$ready = Sales::ready($pdo);
$F = $ready ? Sales::funnel($pdo) : [];
$cats = IntakeStager::leafCategories($pdo);
tv_admin_start('sales', 'Sales', 'Turn unclaimed listings into active ones: call who\'s due, then who\'s most worth a call; log what happened and the next follow-up is set for you; send or copy the claim link. Add a business you visited and it goes straight into the funnel.');
if (!$ready) { echo '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2026-11-18_sales.sql</code> in phpMyAdmin first.</p></div>'; tv_admin_end(); return; }

$catOptions = '<option value="">Any category</option>' . implode('', array_map(fn ($c) => '<option value="' . (int) $c['id'] . '">' . $e($c['label'] ?? $c['name'] ?? '') . '</option>', $cats));
$filters = function (string $id, array $preset = []) use ($catOptions, $e): string {
    return '<form class="sl-f" data-list="' . $id . '" onsubmit="return false">'
        . '<input class="hb-in" name="q" type="search" placeholder="Name, phone or #id">'
        . '<input class="hb-in" name="town" placeholder="Town">'
        . '<select class="hb-in" name="category">' . $catOptions . '</select>'
        . '<select class="hb-in" name="stage"><option value="">Worth a call</option><option value="new">Not contacted</option>'
        . implode('', array_map(fn ($k, $l) => $k === 'new' ? '' : '<option value="' . $k . '">' . $e($l) . '</option>', array_keys(Sales::STAGES), Sales::STAGES)) . '</select>'
        . '<select class="hb-in" name="web"><option value="">Any web presence</option><option value="not_own">No website of its own</option><option value="none">No website at all</option><option value="social">Facebook or social only</option><option value="own">Has a website</option></select>'
        . '<select class="hb-in" name="has"><option value="">Any contact</option><option value="phone">Has a phone</option><option value="website">Has a website</option><option value="email">Has an email</option></select>'
        . '<select class="hb-in" name="owner"><option value="">Everyone\'s</option><option value="me">Mine</option><option value="none">Shared queue</option></select>'
        . '<select class="hb-in" name="sort"><option value="best">Best to call first (score)</option><option value="views">Most viewed</option><option value="new">Newest</option><option value="name">A to Z</option><option value="due">Follow-up date</option></select>'
        . '</form>';
};
ob_start(); ?>
<div class="hb-card tv-bleed"><h2 class="hb-h" style="margin-top:0">Follow-ups due<?= $F['due'] ? ' (' . $F['due'] . ')' : '' ?></h2>
  <div class="sl-list" data-src="due=1&sort=due" data-empty="Nothing due today. Start on the ones below."></div></div>
<div class="hb-card tv-bleed mt-2"><h2 class="hb-h" style="margin-top:0">Best to call next</h2>
  <p class="text-xs text-[#8A7355]">Not contacted yet, with a phone: the ones people are looking at, and new ones, first.</p>
  <div class="sl-list" data-src="stage=new&has=phone&sort=best" data-limit="10" data-empty="No one left to call."></div></div>
<?php $calls = (string) ob_get_clean();

ob_start(); ?>
<div class="hb-card tv-bleed"><?= $filters('all') ?><p class="text-xs text-[#8A7355] mt-1" data-count="all"></p><div class="sl-list" data-id="all" data-src="" data-more-btn></div></div>
<?php $all = (string) ob_get_clean();

ob_start(); ?>
<div class="hb-card tv-bleed"><p class="text-sm text-[#5C4632]">Listings added in the last 7 days, newest first: by the crawler, by staff, or by owners.</p>
  <div class="sl-list" data-src="added=7&sort=new&claimed=all&stage=any" data-more-btn data-empty="Nothing new this week."></div></div>
<?php $new = (string) ob_get_clean();

ob_start(); ?>
<div class="hb-card tv-bleed">
  <p class="text-sm text-[#5C4632]">A business you saw in person. It's listed right away (unclaimed), the crawler fills in what it can find, and it starts in the funnel with your visit logged.</p>
  <form id="sl-field" class="sl-form" autocomplete="off" onsubmit="return false">
    <label>Business name<input class="hb-in" name="name" required maxlength="120"></label>
    <label>Category<select class="hb-in" name="category_id" required><option value="">Choose…</option><?= substr($catOptions, strpos($catOptions, '</option>') + 9) ?></select></label>
    <label>Town<input class="hb-in" name="town" required maxlength="80"></label>
    <label>Street address<input class="hb-in" name="address" maxlength="160"></label>
    <label>Phone<input class="hb-in" name="phone" inputmode="tel" maxlength="20"></label>
    <label>Website<input class="hb-in" name="website" maxlength="300"></label>
    <label>Email<input class="hb-in" name="email" type="email" maxlength="160"></label>
    <label>Who you spoke with<input class="hb-in" name="contact_name" maxlength="120" placeholder="Name and role"></label>
    <label>What happened<select class="hb-in" name="outcome">
      <option value="left_message">Left our info</option><option value="interested">Talked: interested</option><option value="invited">Gave them the claim link</option>
      <option value="not_now">Talked: not now</option><option value="no">Not interested</option></select></label>
    <label>Follow up on<input class="hb-in" name="next_at" type="date"></label>
    <label class="sl-wide">Notes<textarea class="hb-in" name="note" rows="3" maxlength="1000" placeholder="Hours, owner's name, what they need…"></textarea></label>
    <div class="sl-wide flex gap-2 flex-wrap"><button type="button" class="hb-b go" id="sl-field-go">Add it and log the visit</button><span class="text-sm" id="sl-field-msg" role="status"></span></div>
  </form>
  <div id="sl-field-dups" hidden></div>
</div>
<?php $field = (string) ob_get_clean();

$pct = fn (int $a, int $b) => $b ? (int) round(100 * $a / $b) : 0;
$total = $F['unclaimed'] + $F['claimed'] + $F['verified'];
ob_start(); ?>
<div class="hb-card tv-bleed">
  <h2 class="hb-h" style="margin-top:0">The funnel</h2>
  <ol class="sl-funnel">
    <?php foreach ([['Not contacted', $F['new'], 'stage=new'], ['Contacted', $F['contacted'], 'stage=contacted'], ['Interested', $F['interested'], 'stage=interested'], ['Claim invite sent', $F['invited'], 'stage=invited'],
                    ['Claimed', $F['claimed'], 'claimed=yes'], ['Verified', $F['verified'], ''], ['Met in person', $F['met'] ?? 0, ''], ['Meeting set', $F['meeting'] ?? 0, ''], ['Quote sent', $F['quote'] ?? 0, ''], ['Won', $F['won'] ?? 0, ''], ['Paying', $F['paid'], '']] as [$l, $n, $go]): ?>
    <li><b><?= number_format($n) ?></b><span><?= $e($l) ?></span><i style="width:<?= max(2, $pct($n, max(1, $total))) ?>%"></i></li>
    <?php endforeach; ?>
  </ol>
  <p class="text-sm mt-2 text-[#5C4632]">Set aside: <?= number_format($F['not_now']) ?> not now (back in 30 days) · <?= number_format($F['no']) ?> not interested · <?= number_format($F['lost'] ?? 0) ?> lost · <?= number_format($F['closed']) ?> closed or wrong number.</p>
  <h2 class="hb-h">This week</h2>
  <div class="hb-grid">
    <div class="hb-card"><div class="num"><?= $F['week']['contacts'] ?></div><div class="lab">calls, visits, emails and texts</div></div>
    <div class="hb-card"><div class="num"><?= $F['week']['invites'] ?></div><div class="lab">claim invites sent</div></div>
    <div class="hb-card"><div class="num"><?= $F['week']['claims'] ?></div><div class="lab">claims started by owners</div></div>
    <div class="hb-card"><div class="num"><?= $F['week']['added'] ?></div><div class="lab">listings added (<?= $F['week']['field'] ?> from the field)</div></div>
  </div>
</div>
<?php $funnel = (string) ob_get_clean();

tv_admin_hub('Sales', [
    'cards' => ['label' => 'Scan cards', 'html' => CardScan::ready($pdo) ? tv_card_scanner($pdo, substr($catOptions, strpos($catOptions, '</option>') + 9)) : '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2026-12-20_card_scanner.sql</code> in phpMyAdmin first.</p></div>'],
    'calls' => ['label' => 'Calls today', 'html' => $calls, 'badge' => $F['due']],
    'all' => ['label' => 'All prospects', 'html' => $all],
    'field' => ['label' => 'Add from the field', 'html' => $field],
    'new' => ['label' => 'New this week', 'html' => $new, 'badge' => 0],
    'funnel' => ['label' => 'Funnel', 'html' => $funnel],
    'territories' => ['label' => 'Territories', 'html' => tv_lead_territories()],
    'promos' => ['label' => 'Promotions', 'html' => (($fl = tv_crawler_flash()) ? '<p class="hb-card tv-bleed" role="status" data-tv-flash="' . tv_e((string) ($fl['type'] ?? '')) . '" style="background:' . (($fl['type'] ?? '') === 'error' ? '#FEE2E2' : '#DCFCE7') . '">' . $e($fl['text'] ?? '') . '</p>' : '')
        . tv_promotions_panel($pdo, Promotions::canMake(StaffLogin::ready($pdo) ? StaffLogin::inSession($pdo) : null), (string) ($_SESSION['csrf_token'] ?? ''))],
]);
echo tv_lead_panel();
$svg = fn (string $d) => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
?>
<style>
  .sl-f{display:flex;flex-wrap:wrap;gap:.4rem}.sl-f .hb-in{width:auto;flex:1 1 9rem;font-size:.88rem;padding:.4rem .55rem}
  .sl-row{display:flex;gap:.6rem;align-items:flex-start;justify-content:space-between;padding:.65rem .1rem;border-top:1px solid #EADFC4}
  .sl-row:first-child{border-top:0}
  .sl-main{min-width:0;flex:1}
  .sl-nm{font-weight:700;color:#92400E;text-decoration:underline;font-size:1rem}
  .sl-sub{font-size:.8rem;color:#8A7355;margin-top:.1rem}
  .sl-ct{font-size:.85rem;color:#3E2B1F;margin-top:.2rem;display:flex;flex-wrap:wrap;gap:.2rem .7rem}
  .sl-ct a{color:#92400E;text-decoration:underline}
  .sl-last{font-size:.82rem;color:#5C4632;margin-top:.25rem}
  .sl-acts{display:flex;flex-direction:column;gap:.3rem;flex:none}
  .sl-ic{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#B45309;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}
  .sl-ic.on{background:#8FBCA8;color:#1F3B2F;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .sl-pill{display:inline-block;font-size:.7rem;font-weight:700;border-radius:999px;padding:.05rem .5rem;background:#EADFC4;color:#5C4632;margin-left:.35rem;vertical-align:middle}
  .sl-pill.interested,.sl-pill.invited{background:#FDE68A;color:#78350F}.sl-pill.claimed,.sl-pill.verified,.sl-pill.paid{background:#DCEFE5;color:#1F5C43}
  .sl-pill.no,.sl-pill.closed{background:#FEE2E2;color:#991B1B}
  .sl-panel{margin:.5rem 0 .2rem;padding:.7rem;border:1px solid #CBB98D;border-radius:.7rem;background:#FFFBF2}
  .sl-outs{display:flex;flex-wrap:wrap;gap:.3rem;margin:.35rem 0}
  .sl-out{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;border-radius:999px;padding:.3rem .65rem;background:#fff;cursor:pointer}
  .sl-out.on{background:#3E2B1F;color:#FFF8EA;border-color:#3E2B1F}
  .sl-form{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(15rem,100%),1fr));gap:.6rem;margin-top:.6rem}
  .sl-form label{display:flex;flex-direction:column;gap:.2rem;font-size:.8rem;font-weight:600;color:#5C4632}.sl-wide{grid-column:1/-1}
  .sl-funnel{list-style:none;margin:.5rem 0 0;padding:0;display:grid;gap:.3rem}
  .sl-funnel li{position:relative;display:flex;gap:.6rem;align-items:baseline;padding:.4rem .6rem;border-radius:.5rem;background:#FFFBF2;border:1px solid #EADFC4;overflow:hidden}
  .sl-funnel li b{font:700 1.15rem Georgia,serif;min-width:4.5rem;position:relative;z-index:1}.sl-funnel li span{position:relative;z-index:1;font-size:.9rem}
  .sl-funnel li i{position:absolute;left:0;top:0;bottom:0;background:rgba(143,188,168,.3)}
  .sl-hist{font-size:.8rem;color:#5C4632;margin-top:.5rem}.sl-hist p{margin:.15rem 0}
  .sl-pill.web-own{background:#DCEFE5;color:#1F5C43}.sl-pill.web-social{background:#FFF1D6;color:#92400E}.sl-pill.web-none{background:#FEE2E2;color:#991B1B}
</style>
<script>
(function () {
  var CATS = null, csrf = null, IC = <?= json_encode([
    'call' => $svg('<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>'),
    'log' => $svg('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>'),
    'invite' => $svg('<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>'),
  ]) ?>;
  var OUT = <?= json_encode(array_map(fn ($o) => [$o[2], $o[1]], Sales::OUTCOMES)) ?>, KINDS = <?= json_encode(Sales::KINDS) ?>, CAN_EMAIL = <?= Sales::canEmail() ? 'true' : 'false' ?>;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function tok() { return csrf ? Promise.resolve(csrf) : fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrf = d.csrf_token || ''); }); }
  function api(q, body) {
    var p = body ? tok().then(function (c) { return fetch('/admin/api/sales.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); })
      : fetch('/admin/api/sales.php?' + q, { credentials: 'include' });
    return p.then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work.'); return j; });
  }
  function fmt(d) { if (!d) return ''; var t = new Date(String(d).replace(' ', 'T')); return isNaN(t) ? d : t.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }); }
  function row(p) {
    var ct = [p.phone ? '<a href="tel:' + esc(p.phone.replace(/[^\d+]/g, '')) + '">' + esc(p.phone) + '</a>' : '<span class="text-[#8A7355]">No phone</span>',
              p.website ? '<a href="' + esc(p.website) + '" target="_blank" rel="noopener">Website</a>' : '', p.email ? '<a href="mailto:' + esc(p.email) + '">' + esc(p.email) + '</a>' : ''].filter(Boolean).join('');
    var last = p.last_contact_at ? esc(p.last_outcome || 'Contacted') + ' ' + fmt(p.last_contact_at) : '';
    var next = p.next_at ? 'follow up ' + fmt(p.next_at) : '';
    var who = p.contact_name ? 'ask for ' + esc(p.contact_name) : '';
    return '<div class="sl-row" data-p="' + p.id + '"><div class="sl-main">'
      + '<a class="sl-nm" href="/admin/sales.php?lead=' + p.id + '#all" data-lead="' + p.id + '" title="Open the lead">' + esc(p.name) + '</a>' + (window.slScore ? window.slScore(p) : '') + '<span class="sl-pill ' + esc(p.stage) + '">' + esc(p.stage_label) + '</span>' + (p.web_label ? '<span class="sl-pill web-' + esc(p.web) + '" title="Web presence">' + esc(p.web_label) + '</span>' : '')
      + '<div class="sl-sub">' + esc([p.category, p.city].filter(Boolean).join(' · ')) + ' · added ' + fmt(p.added) + (p.views || p.taps ? ' · ' + p.views + ' views, ' + p.taps + ' taps (30 days)' : '') + '</div>'
      + (p.reach && p.reach.line ? '<div class="sl-last" title="Counts only, never who: a reason to invite (decisions/0172)">' + esc(p.reach.line) + '</div>' : '')
      + '<div class="sl-ct">' + ct + '</div>'
      + ([last, next, who].filter(Boolean).length ? '<div class="sl-last">' + [last, next, who].filter(Boolean).join(' · ') + '</div>' : '')
      + (p.notes ? '<div class="sl-last">' + esc(p.notes.split('\n')[0]) + '</div>' : '')
      + '<div data-panel></div></div>'
      + '<div class="sl-acts">' + (p.phone ? '<a class="sl-ic" href="tel:' + esc(p.phone.replace(/[^\d+]/g, '')) + '" title="Call" aria-label="Call ' + esc(p.name) + '">' + IC.call + '</a>' : '')
      + '<button type="button" class="sl-ic" data-log="' + p.id + '" title="Log a contact" aria-label="Log a contact with ' + esc(p.name) + '">' + IC.log + '</button>'
      + '<button type="button" class="sl-ic" data-inv="' + p.id + '" title="Claim link" aria-label="Claim link for ' + esc(p.name) + '">' + IC.invite + '</button></div></div>';
  }
  var DATA = {};
  function load(box, append) {
    var f = box.closest('[data-hsec]').querySelector('form.sl-f'), q = box.getAttribute('data-src') || '';
    if (f) { var fd = new FormData(f), parts = []; fd.forEach(function (v, k) { if (v) parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(v)); }); q = parts.join('&'); }
    var page = append ? (+box.getAttribute('data-page') || 0) + 1 : 0;
    box.setAttribute('data-page', page);
    return api(q + '&page=' + page).then(function (j) {
      var items = j.items; if (box.getAttribute('data-limit')) items = items.slice(0, +box.getAttribute('data-limit'));
      items.forEach(function (p) { DATA[p.id] = p; });
      var html = items.map(row).join('');
      var more = box.hasAttribute('data-more-btn') && (page + 1) * 30 < j.total ? '<p class="mt-2"><button type="button" class="hb-b" data-next>Show more</button></p>' : '';
      var old = box.querySelector('[data-next]'); if (old) old.parentNode.remove();
      if (append) box.insertAdjacentHTML('beforeend', html + more); else box.innerHTML = (html || '<p class="text-sm text-[#8A7355]">' + esc(box.getAttribute('data-empty') || 'No one matches.') + '</p>') + more;
      var cnt = box.closest('[data-hsec]').querySelector('[data-count]'); if (cnt) cnt.textContent = j.total.toLocaleString() + ' match';
    }).catch(function (x) { box.innerHTML = '<p class="text-sm">' + esc(x.message) + '</p>'; });
  }
  var loaded = {};
  function loadSec(k) { if (loaded[k]) return; loaded[k] = 1; document.querySelectorAll('[data-hsec="' + k + '"] .sl-list').forEach(function (b) { load(b); }); }
  var dirty = false;   // after a save, the Funnel (drawn with the page) is out of date: it reloads when opened
  document.addEventListener('tv-hub-show', function (e) { if (e.detail === 'funnel' && dirty) { location.reload(); return; } loadSec(e.detail); });
  loadSec((location.hash.slice(1) || 'calls'));
  var t = null;
  document.querySelectorAll('form.sl-f').forEach(function (f) {
    var go = function () { clearTimeout(t); t = setTimeout(function () { load(f.parentNode.querySelector('.sl-list')); }, 300); };
    f.addEventListener('input', go); f.addEventListener('change', go);
  });
  function refreshRow(p) { dirty = true; DATA[p.id] = p; document.querySelectorAll('[data-p="' + p.id + '"]').forEach(function (r) { r.outerHTML = row(p); }); }
  window.slRefreshRow = refreshRow; window.slOut = {}; Object.keys(OUT).forEach(function (k) { window.slOut[k] = OUT[k][0]; });
  function panelFor(btn) { var r = btn.closest('[data-p]'), pn = r.querySelector('[data-panel]'); var open = pn.getAttribute('data-open') === btn.getAttribute('data-log') + btn.getAttribute('data-inv'); return [r, pn, open]; }
  document.addEventListener('click', function (e) {
    var nx = e.target.closest('[data-next]'); if (nx) { load(nx.closest('.sl-list'), true); return; }
    var lg = e.target.closest('[data-log]');
    if (lg) {
      var id = +lg.getAttribute('data-log'), p = DATA[id], r = lg.closest('[data-p]'), pn = r.querySelector('[data-panel]');
      if (pn.innerHTML && pn.getAttribute('data-kind') === 'log') { pn.innerHTML = ''; lg.classList.remove('on'); return; }
      r.querySelectorAll('.sl-ic').forEach(function (b) { b.classList.remove('on'); }); lg.classList.add('on');
      pn.setAttribute('data-kind', 'log');
      pn.innerHTML = '<div class="sl-panel"><div class="flex flex-wrap gap-2"><select class="hb-in" style="width:auto" data-k>' + Object.keys(KINDS).filter(function (k) { return k !== 'invite'; }).map(function (k) { return '<option value="' + k + '">' + KINDS[k] + '</option>'; }).join('') + '</select>'
        + '<input class="hb-in" style="flex:1;min-width:9rem;width:auto" data-cn placeholder="Who you spoke with" value="' + esc(p.contact_name) + '"></div>'
        + '<div class="sl-outs">' + Object.keys(OUT).map(function (k) { return '<button type="button" class="sl-out" data-o="' + k + '" data-days="' + (OUT[k][1] == null ? '' : OUT[k][1]) + '">' + esc(OUT[k][0]) + '</button>'; }).join('') + '</div>'
        + '<textarea class="hb-in" rows="2" data-nt placeholder="What they said (optional)"></textarea>'
        + '<div class="flex flex-wrap gap-2 items-center mt-2"><label class="text-sm">Follow up on <input type="date" class="hb-in" style="width:auto" data-nx></label>'
        + '<button type="button" class="hb-b go" data-save>Save</button><span class="text-sm" data-msg></span></div><div class="sl-hist" data-h></div></div>';
      api('id=' + id).then(function (j) { pn.querySelector('[data-h]').innerHTML = j.history.length ? '<b>History</b>' + j.history.map(function (h) { return '<p>' + esc(h.at) + ' · ' + esc(h.kind) + (h.outcome ? ': ' + esc(h.outcome) : '') + (h.note ? ' · ' + esc(h.note) : '') + (h.by ? ' · ' + esc(h.by) : '') + '</p>'; }).join('') : ''; });
      return;
    }
    var o = e.target.closest('.sl-panel .sl-out');   // the list's own log panels (the lead panel has its own)
    if (o) {
      o.parentNode.querySelectorAll('.sl-out').forEach(function (b) { b.classList.toggle('on', b === o); });
      var d = o.getAttribute('data-days'), nx2 = o.closest('.sl-panel').querySelector('[data-nx]');
      if (d !== '') { var dt = new Date(); dt.setDate(dt.getDate() + +d); nx2.value = dt.toISOString().slice(0, 10); } else if (o.getAttribute('data-o') !== 'note') nx2.value = '';
      return;
    }
    var sv = e.target.closest('[data-save]');
    if (sv) {
      var pn2 = sv.closest('[data-panel]'), r2 = sv.closest('[data-p]'), on = pn2.querySelector('.sl-out.on'), m = pn2.querySelector('[data-msg]');
      if (!on) { m.textContent = 'Choose what happened.'; return; }
      sv.disabled = true;
      api('', { do: 'log', id: +r2.getAttribute('data-p'), kind: pn2.querySelector('[data-k]').value, outcome: on.getAttribute('data-o'), note: pn2.querySelector('[data-nt]').value,
                next_at: pn2.querySelector('[data-nx]').value || 'none', contact_name: pn2.querySelector('[data-cn]').value })
        .then(function (j) { refreshRow(j.item); TvAsk.say('Saved' + (j.item.next_at ? ': follow up ' + fmt(j.item.next_at) : '') + '.'); })
        .catch(function (x) { sv.disabled = false; m.textContent = x.message; });
      return;
    }
    var iv = e.target.closest('[data-inv]');
    if (iv) {
      var id3 = +iv.getAttribute('data-inv'), p3 = DATA[id3], r3 = iv.closest('[data-p]'), pn3 = r3.querySelector('[data-panel]');
      if (pn3.innerHTML && pn3.getAttribute('data-kind') === 'inv') { pn3.innerHTML = ''; iv.classList.remove('on'); return; }
      r3.querySelectorAll('.sl-ic').forEach(function (b) { b.classList.remove('on'); }); iv.classList.add('on');
      pn3.setAttribute('data-kind', 'inv');
      pn3.innerHTML = '<div class="sl-panel"><p class="text-sm"><b>Claim link</b> (free to claim):</p><p class="text-sm" style="word-break:break-all"><a class="underline text-[#92400E]" href="' + esc(p3.claim_link) + '" target="_blank" rel="noopener">' + esc(p3.claim_link) + '</a></p>'
        + '<div class="flex flex-wrap gap-2 mt-2"><button type="button" class="hb-b go" data-copy>Copy it</button>'
        + (p3.email && CAN_EMAIL ? '<button type="button" class="hb-b" data-email>Email it to ' + esc(p3.email) + '</button>' : '')
        + '<button type="button" class="hb-b" data-sent>I sent it (text or in person)</button></div>'
        + (p3.email && !CAN_EMAIL ? '<p class="text-xs text-[#8A7355] mt-1">Emailing it needs BUSINESS_POSTAL_ADDRESS in .env (every sales email must carry your postal address).</p>' : '')
        + '<p class="text-sm" data-msg></p></div>';
      return;
    }
    var cp = e.target.closest('[data-copy]');
    if (cp) { var link = DATA[+cp.closest('[data-p]').getAttribute('data-p')].claim_link; (navigator.clipboard ? navigator.clipboard.writeText(link) : Promise.reject()).then(function () { TvAsk.say('Copied.', { anchor: cp }); }, function () { TvAsk.say(link, { anchor: cp }); }); return; }
    var se = e.target.closest('[data-sent]'), em = e.target.closest('[data-email]');
    if (se || em) {
      var b = se || em, id4 = +b.closest('[data-p]').getAttribute('data-p');
      if (em && !TvAsk.gate(em, 'Email the claim link to ' + DATA[id4].email + '?', { yes: 'Send it' })) return;
      b.disabled = true;
      (em ? api('', { do: 'invite', id: id4 }) : api('', { do: 'log', id: id4, kind: 'text', outcome: 'invited', note: 'Claim link sent' }))
        .then(function (j) { refreshRow(j.item); TvAsk.say('Logged: claim invite sent. Follow up ' + fmt(j.item.next_at) + '.'); })
        .catch(function (x) { b.disabled = false; b.closest('.sl-panel').querySelector('[data-msg]').textContent = x.message; });
    }
  });
  // Add from the field
  var ff = document.getElementById('sl-field'), fm = document.getElementById('sl-field-msg'), dupBox = document.getElementById('sl-field-dups');
  function sendField(anyway) {
    var body = { do: 'field', anyway: !!anyway }; new FormData(ff).forEach(function (v, k) { body[k] = v; });
    fm.textContent = 'Saving…';
    return api('', body).then(function (j) {
      if (j.duplicates) {
        fm.textContent = 'It may already be listed:';
        dupBox.hidden = false;
        dupBox.innerHTML = '<div class="sl-panel">' + j.duplicates.map(function (d) { return '<div class="hb-row"><span><a class="sl-nm" href="/listing/view.php?id=' + d.id + '" data-peek-frame>' + esc(d.name) + '</a><small>' + esc(d.city) + ' · ' + esc(d.why) + '</small></span><button type="button" class="hb-b" data-use="' + d.id + '">It\'s this one: log the visit</button></div>'; }).join('')
          + '<p class="mt-2"><button type="button" class="hb-b go" data-anyway>It\'s a different business: add it</button></p></div>';
        return;
      }
      dupBox.hidden = true; ff.reset();
      fm.innerHTML = 'Added and logged. <a class="underline text-[#92400E]" href="/listing/view.php?id=' + j.id + '" data-peek-frame>See it</a> · <a class="underline text-[#92400E]" href="/admin/listing-edit.php?id=' + j.id + '" data-peek-frame>Edit it</a>';
      loaded = {}; dirty = true;
    }).catch(function (x) { fm.textContent = x.message; });
  }
  if (ff) {
    document.getElementById('sl-field-go').addEventListener('click', function () { if (ff.reportValidity()) sendField(false); });
    dupBox.addEventListener('click', function (e) {
      if (e.target.closest('[data-anyway]')) { sendField(true); return; }
      var u = e.target.closest('[data-use]'); if (!u) return;
      var fd = new FormData(ff);
      api('', { do: 'log', id: +u.getAttribute('data-use'), kind: 'visit', outcome: fd.get('outcome'), note: fd.get('note'), next_at: fd.get('next_at') || '', contact_name: fd.get('contact_name') })
        .then(function () { dupBox.hidden = true; ff.reset(); fm.textContent = 'Visit logged on the existing listing.'; loaded = {}; }).catch(function (x) { fm.textContent = x.message; });
    });
  }
})();
</script>
<?php tv_admin_end();
