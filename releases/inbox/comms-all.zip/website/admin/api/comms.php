<?php
// /admin/api/comms.php — System Configuration → Communications' buttons (decisions/0167; app/admin/comms-console.php) and the
// mail-failure message's Check again (0172 "The message"). POST JSON {action, …} with X-CSRF-Token -> {message} (and the
// message's body again when pressed inside one: from_msg). GET ?lazy=dns|sent -> {html}. Viewing follows
// Access::can('config.communications'); making, resetting, routing, DNS, pauses and keys are owner-level
// ('config.communications.manage'). Every change is logged (CommsSetup::log), never a password.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/admin/Access.php';
require_once __DIR__ . '/../../../app/lib/CommsSetup.php';
require_once __DIR__ . '/../../../app/lib/Notify.php';

header('Cache-Control: no-store');
$me = Auth::currentUser();
if (!$me || !Access::staff()) Response::error('Staff only.', 403, 'forbidden');
$pdo = Database::connection();
$uid = (int) $me['id'];
[$canSee, $whySee] = Access::can('config.communications', ['min' => 'manager', 'depts' => []]);
[$can, $why] = Access::can('config.communications.manage', ['min' => 'founder', 'depts' => []]);
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (!$canSee) Response::error($whySee . '.', 403, 'forbidden');
        require_once __DIR__ . '/../../../app/admin/comms-console.php';
        Response::success(['html' => tv_comms_lazy($pdo, (string) ($_GET['lazy'] ?? ''))]);
    }
    Response::requireMethod('POST');
    Response::requireCsrf();
    $b = Response::jsonBody();
    $act = (string) ($b['action'] ?? '');
    $own = function () use ($can, $why): void { if (!$can) throw new InvalidArgumentException($why . '.'); };
    $extra = [];
    switch ($act) {
        case 'check':   // anyone who received the failure, or may see Communications, may look again
            $w = CommsSetup::check($pdo, (string) ($b['sender'] ?? ''), $uid);
            if ($w !== '' && empty($b['from_msg'])) Response::error('Check failed: ' . $w, 422, 'check_failed');
            $say = $w === '' ? 'Signed in: ' . CommsSetup::sender((string) $b['sender'])['address'] . ' works.' : 'Still failing: ' . $w;
            break;
        case 'test': if (!$canSee) throw new InvalidArgumentException($whySee . '.'); $say = CommsSetup::test($pdo, (string) ($b['sender'] ?? ''), (string) ($me['email'] ?? ''), $uid); break;
        case 'fields':
            $own(); $k = (string) ($b['sender'] ?? ''); $said = [];
            foreach (CommsSetup::fields($k) as $f => $key) if (array_key_exists($f, $b) && (string) $b[$f] !== EnvSettings::value($key)) $said[] = CommsSetup::setField($pdo, $k, $f, (string) $b[$f], $uid);
            if (trim((string) ($b['password'] ?? '')) !== '') $said[] = CommsSetup::setPasswordOnly($pdo, $k, (string) $b['password'], $uid);
            $say = $said ? implode(' ', $said) : 'Nothing changed.';
            break;
        case 'undo': $own(); $say = CommsSetup::undoReset($pdo, (string) ($b['sender'] ?? ''), $uid); break;
        case 'mailbox':
            $own();
            $email = isset($b['local']) ? trim((string) $b['local']) . '@' . trim((string) ($b['domain'] ?? '')) : (string) ($b['email'] ?? '');
            $say = CommsSetup::mailboxDo($pdo, (string) ($b['do'] ?? ''), $email, (string) ($b['password'] ?? ''), $uid);
            break;
        case 'read':   // one of our mailboxes read in its overseers' Pulse inbox
            $own();
            require_once __DIR__ . '/../../../app/lib/Mailboxes.php';
            [, $say] = Mailboxes::connect($pdo, $uid, 'system', ['provider' => 'cpanel', 'address' => (string) ($b['email'] ?? ''), 'password' => (string) ($b['password'] ?? '')]);
            break;
        case 'overseer': $own(); $say = CommsSetup::setOverseer($pdo, (string) ($b['mailbox'] ?? ''), (int) ($b['user'] ?? 0), !empty($b['on']), $uid); break;
        case 'route': $own(); $say = CommsSetup::setRoute($pdo, (string) ($b['kind'] ?? ''), (string) ($b['sender'] ?? ''), $uid); break;
        case 'dnsfix': $own(); $say = CommsSetup::domainFix($pdo, (string) ($b['domain'] ?? ''), (string) ($b['what'] ?? ''), $uid); break;
        case 'pause': $own(); if (trim((string) ($b['why'] ?? '')) === '') throw new InvalidArgumentException('Say why, so whoever resumes it knows.'); CommsSetup::pause($pdo, (string) ($b['ckey'] ?? ''), (string) $b['why'], $uid); $say = 'Paused. Messages still reach Pulse; Resume sends what waits from then on.'; break;
        case 'resume': $own(); CommsSetup::resume($pdo, (string) ($b['ckey'] ?? ''), $uid); $say = 'Resumed.'; break;
        case 'ses_setup': $own(); require_once __DIR__ . '/../../../app/lib/SesInbound.php'; $say = SesInbound::setup($pdo, $uid); break;
        case 'ms_keys':
            $own();
            require_once __DIR__ . '/../../../app/lib/EnvSettings.php';
            if (trim((string) ($b['id'] ?? '')) === '' || trim((string) ($b['secret'] ?? '')) === '') throw new InvalidArgumentException('Both the client ID and the secret\'s value, please.');
            if (!preg_match('/^[0-9a-f-]{36}$/i', trim((string) $b['id']))) throw new InvalidArgumentException('The Application (client) ID looks like 8-4-4-4-12 letters and numbers.');
            EnvSettings::setMailSecret('MS_MAIL_CLIENT_ID', trim((string) $b['id']));
            EnvSettings::setMailSecret('MS_MAIL_CLIENT_SECRET', trim((string) $b['secret']));
            CommsSetup::log($pdo, $uid, 'ms_keys', 'Sign in with Microsoft', 'keys written to .env');
            $say = 'Saved. Staff can now use Sign in with Microsoft in their Pulse inbox.';
            break;
        default: throw new InvalidArgumentException('Unknown action.');
    }
    if (!empty($b['from_msg']) && ($m = Notify::one($pdo, $uid, (int) $b['from_msg'])) && ($body = Notify::body($pdo, $m, $uid))) $extra['html'] = $body['html'];
    Response::success(['message' => $say] + $extra);
} catch (InvalidArgumentException $x) {
    Response::error($x->getMessage(), 422, 'not_allowed');
} catch (Throwable $x) {
    error_log('admin comms: ' . $x->getMessage());
    Response::error(mb_substr($x->getMessage(), 0, 240) ?: 'That didn\'t work. Try again.', 500, 'failed');
}
