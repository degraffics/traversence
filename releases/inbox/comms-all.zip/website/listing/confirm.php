<?php
// /listing/confirm.php?t=… — a guest confirms their email for a message they left on an unclaimed listing (decisions/0172
// §3.3): nothing goes to the business until this link is pressed, so no one can send in someone else's name. The link
// works for 48 hours. Never a dead end: an old or broken link offers a new one (by the reply code), leaving it again on
// the listing's page, and a note to our team, with our email address.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/ListingMessages.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$pdo = Database::connection();
$t = (string) ($_GET['t'] ?? '');
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$flash = null;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    try {
        if (!hash_equals((string) $_SESSION['csrf_token'], (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('This page had expired. Try again.');
        if (($_POST['help'] ?? '') === 'resend') { ListingMessages::resendConfirm($pdo, (string) ($_POST['code'] ?? '')); $flash = ['ok', 'We\'ve sent a new link to the email you gave. It works for ' . ListingMessages::CONFIRM_HOURS . ' hours.']; }
        else $flash = ['ok', ListingMessages::askTeam((string) ($_POST['email'] ?? ''), (string) ($_POST['note'] ?? ''), 'the confirm-your-message page')];
    } catch (InvalidArgumentException $x) { $flash = ['error', $x->getMessage()]; }
    catch (Throwable $x) { error_log('listing confirm help: ' . $x->getMessage()); $flash = ['error', 'That didn\'t go through. Write to ' . ListingMessages::helpTo() . ' instead.']; }
    $r = null;
} else {
    $r = ListingMessages::ready($pdo) ? ListingMessages::confirm($pdo, $t) : null;
}

tv_page_start('Your message', ['no_crumbs' => true]);
$csrf = tv_e((string) $_SESSION['csrf_token']);
$box = 'background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:.5rem;padding:1rem 1.1rem;margin-top:.75rem';
$btn = 'background:#3E2B1F;color:#EFE3C8;border-radius:.6rem;padding:.5rem 1rem;font-weight:600;border:0';
$in = 'display:block;width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.5rem;background:#FFFBF2;padding:.45rem .55rem;margin-top:.2rem';
?>
<div class="max-w-xl tv-bleed" style="<?= $box ?>">
  <h1 class="font-serif font-bold text-2xl text-[#3E2B1F]">Your message</h1>
  <?php if ($flash): ?>
    <p class="mt-2" data-tv-flash="<?= $flash[0] === 'ok' ? 'ok' : 'error' ?>" data-tv-status="<?= $flash[0] === 'ok' ? 'ok' : 'bad' ?>" data-tv-label="<?= $flash[0] === 'ok' ? 'Done:' : 'Not sent:' ?>"><?= tv_e($flash[1]) ?></p>
  <?php elseif ($r): ?>
    <p class="mt-2" data-tv-status="ok" data-tv-label="<?= $r['again'] ? 'Already confirmed:' : 'Confirmed:' ?>">Your email is confirmed, and your message to <?= tv_e($r['name']) ?> is on its way.</p>
    <p class="text-sm mt-2"><?= tv_e($r['said']) ?></p>
    <p class="text-sm mt-2">See where it stands any time on <a class="underline font-semibold" href="/listing/view.php?id=<?= (int) $r['entity_id'] ?>#lm"><?= tv_e($r['name']) ?>'s page</a>, under "Check a reply", with your reply code.</p>
  <?php else: ?>
    <p class="mt-2" data-tv-status="bad" data-tv-label="Link not working:">This link is too old, was already replaced, or isn't complete. Your message hasn't gone to the business.</p>
    <p class="text-sm mt-2">Links work for <?= ListingMessages::CONFIRM_HOURS ?> hours. Messages not confirmed in that time are deleted, so if yours is older, leave it again on the listing's page.</p>
  <?php endif; ?>
</div>
<?php if (!$r): // never a dead end: a new link by the reply code, or our team ?>
<div class="max-w-xl tv-bleed" style="<?= $box ?>">
  <form method="post"><input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="help" value="resend">
    <label class="text-sm text-[#5C4632]">Send a new link: your reply code<input style="<?= $in ?>" name="code" required maxlength="12" autocapitalize="characters" placeholder="ABCD-EFGH" spellcheck="false"></label>
    <button type="submit" class="mt-2" style="<?= $btn ?>">Send me a new link</button></form>
</div>
<div class="max-w-xl tv-bleed" style="<?= $box ?>">
  <form method="post"><input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="help" value="team">
    <label class="text-sm text-[#5C4632]">Ask our team: your email<input style="<?= $in ?>" type="email" name="email" required autocomplete="email" maxlength="160" spellcheck="false"></label>
    <label class="text-sm text-[#5C4632] mt-2 block">What happened?<textarea style="<?= $in ?>" name="note" rows="3" maxlength="1500" data-spell></textarea></label>
    <button type="submit" class="mt-2" style="<?= $btn ?>">Send to our team</button></form>
  <p class="text-sm mt-2">Or write to <a class="underline" href="mailto:<?= tv_e(ListingMessages::helpTo()) ?>"><?= tv_e(ListingMessages::helpTo()) ?></a>.</p>
</div>
<?php endif; ?>
<?php tv_page_end();
