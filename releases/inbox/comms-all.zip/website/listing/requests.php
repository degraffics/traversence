<?php
// /listing/requests.php?t=… — the links in a visitor's request emailed to an unclaimed listing (decisions/0172 §3.3):
//   s…  Stop requests to this address: no more requests are emailed there; messages wait on the listing for a claim.
//       Its way back: Send requests again.
//   p…  Report this as spam: the message goes to our Safety team as a report (0052, 0137), the process every report
//       follows; on a "messages are waiting" notice it stops requests to the address instead.
// No sign-in (the address the email went to is who's asking; the link is signed). A visit shows what it does and a
// button, so a mail scanner opening the link changes nothing. Claim the listing is offered on every state.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/ListingMessages.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$pdo = Database::connection();
$t = (string) ($_GET['t'] ?? $_POST['t'] ?? '');
$tok = ListingMessages::ready($pdo) ? ListingMessages::fromToken($pdo, $t) : null;
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$done = '';
$err = '';
if ($tok && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    try {
        if (!hash_equals((string) $_SESSION['csrf_token'], (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('This page had expired. Press the button again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'stop') { ListingMessages::stopRequests($pdo, $tok); $done = 'stopped'; }
        elseif ($do === 'resume') { ListingMessages::resumeRequests($pdo, $tok); $done = 'resumed'; }
        elseif ($do === 'spam') { ListingMessages::reportSpam($pdo, $tok); $done = 'reported'; }
        $tok = ListingMessages::fromToken($pdo, $t);
    } catch (InvalidArgumentException $x) { $err = $x->getMessage(); }
    catch (Throwable $x) { error_log('listing requests page: ' . $x->getMessage()); $err = 'That didn\'t go through. Try again, or write to ' . ListingMessages::helpTo() . '.'; }
}

tv_page_start('Requests from Traversence', ['no_crumbs' => true]);
$csrf = tv_e((string) $_SESSION['csrf_token']);
$box = 'background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:.5rem;padding:1rem 1.1rem;margin-top:.75rem';
$btn = 'background:#3E2B1F;color:#EFE3C8;border-radius:.6rem;padding:.5rem 1rem;font-weight:600;border:0';
$btn2 = 'background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem 1rem;font-weight:600';
$form = fn (string $do, string $label, string $style) => '<form method="post" style="display:inline-block;margin:.5rem .4rem 0 0"><input type="hidden" name="t" value="' . tv_e($t) . '"><input type="hidden" name="csrf" value="' . $csrf . '"><input type="hidden" name="do" value="' . $do . '"><button type="submit" style="' . $style . '">' . tv_e($label) . '</button></form>';
?>
<div class="max-w-xl tv-bleed" style="<?= $box ?>">
  <h1 class="font-serif font-bold text-2xl text-[#3E2B1F]">Requests from Traversence</h1>
  <?php if (!$tok): ?>
    <p class="mt-2" data-tv-status="bad" data-tv-label="Not found:">This link isn't complete. Use the link in the email itself, or write to us at <a class="underline" href="mailto:<?= tv_e(ListingMessages::helpTo()) ?>"><?= tv_e(ListingMessages::helpTo()) ?></a> and say which business it's about: we'll stop the requests by hand.</p>
  <?php else: $name = tv_e($tok['listing']); $claim = '/claim.php?listing=' . (int) $tok['entity_id']; ?>
    <?php if ($err !== ''): ?><p class="mt-2" data-tv-flash="error" data-tv-status="bad" data-tv-label="Error:"><?= tv_e($err) ?></p><?php endif; ?>
    <?php if ($done === 'stopped'): ?>
      <p class="mt-2" data-tv-flash="ok" data-tv-status="ok" data-tv-label="Done:">We won't email visitors' requests for <?= $name ?> to this address again. Messages left for it wait on its listing, and are delivered only if it's claimed.</p>
    <?php elseif ($done === 'resumed'): ?>
      <p class="mt-2" data-tv-flash="ok" data-tv-status="ok" data-tv-label="Done:">Requests for <?= $name ?> can come to this address again.</p>
    <?php elseif ($done === 'reported'): ?>
      <p class="mt-2" data-tv-flash="ok" data-tv-status="ok" data-tv-label="Reported:"><?= $tok['send']['inquiry_id'] !== null ? 'Thank you. Our Safety team looks at it, as with every report; the sender isn\'t told who reported it.' : 'Thank you. We\'ve stopped these emails to this address.' ?></p>
    <?php endif; ?>
    <?php if ($tok['what'] === 's' || $done === 'stopped' || $done === 'resumed'): ?>
      <p class="text-sm mt-2"><?= $tok['stopped'] ? 'Requests for ' . $name . ' aren\'t emailed to this address.' : 'This stops emails of visitors\' requests for ' . $name . ' to this address. Messages left for it then wait on its listing until it\'s claimed.' ?></p>
      <?= $tok['stopped'] ? $form('resume', 'Send requests again', $btn2) : $form('stop', 'Stop requests to this address', $btn) ?>
    <?php else: ?>
      <p class="text-sm mt-2">A visitor's message to <?= $name ?> that looks like spam or abuse goes to our Safety team as a report: they decide, as with every report on Traversence.</p>
      <?= $done === 'reported' ? '' : $form('spam', 'Report this as spam', $btn) ?>
      <?= $tok['stopped'] ? '' : $form('stop', 'Stop requests to this address', $btn2) ?>
    <?php endif; ?>
    <p class="text-sm mt-3">Is <?= $name ?> yours? <a class="underline font-semibold" href="<?= tv_e($claim) ?>">Claim your listing</a> (free) to see and answer every request in Traversence, and choose how you hear about them.</p>
  <?php endif; ?>
</div>
<?php tv_page_end();
