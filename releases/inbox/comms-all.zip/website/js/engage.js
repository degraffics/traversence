// js/engage.js — the Engage bar and Comments on content pages (decisions/0058 §20; includes/engage-ui.php).
// Like, Share (the phone's share sheet, else copy the link), Report (a page's own item or a comment), and comments:
// post, remove, report, and reply (one level, decisions/0172 §2.3). A guest's like counts (decisions/0009); comments and
// reports open the account panel.
(function () {
  var csrf = null, REASONS = { spam: 'Spam or scam', harassment: 'Harassment or hate', sacred_site: 'Shows a sacred or restricted site', private_info: 'Someone’s private information',
    people: 'Shows people without their consent', private_property: 'Private property without permission', unsafe: 'Unsafe or illegal', other: 'Something else' };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  (function () { var st = document.createElement('style'); st.textContent = '.eg-hc{margin:.5rem 0;padding:.7rem .8rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.7rem;max-width:22rem;font-size:.88rem;color:#3E2B1F}.eg-hc p{margin:0 0 .4rem}.eg-hc b{display:block}.eg-hcw{min-height:65px}'; document.head.appendChild(st); })();
  function token() {
    if (csrf) return Promise.resolve(csrf);
    return fetch('/api/engage.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { csrf = d.csrf; return csrf; });
  }
  function post(body, opt) {
    return token().then(function (t) {
      return fetch('/api/engage.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': t || '' }, body: JSON.stringify(body) });
    }).then(function (r) { return r.json().then(function (d) {
      if (r.status === 401) {   // a guest, for something that needs an account: the account panel (js/tv-join.js), not a detour
        if (window.TvJoin) TvJoin.open({ why: d.error && d.error.message, next: location.pathname + location.search, more: d.error && d.error.more && opt && opt.more });
        else location.href = '/login.php?tab=create&next=' + encodeURIComponent(location.pathname + location.search);
        throw new Error('Sign in first.'); }
      if (!d.ok) { var er = new Error(d.error && d.error.message ? d.error.message : 'That didn’t work.'); er.code = d.error && d.error.code; er.sitekey = d.error && d.error.sitekey; throw er; }
      return d; }); });
  }
  // The "verify you're human" check, for likes (app/lib/LikeGuard.php): Cloudflare Turnstile beside the button. Usually it
  // passes by itself in a second. Resolves with its token; with no site key set up, at once with ''.
  var tsLoad = null;
  function humanCheck(sitekey, anchor) {
    if (!sitekey) return Promise.resolve('');
    if (!tsLoad) tsLoad = new Promise(function (res, rej) {
      if (window.turnstile) return res();
      var sc = document.createElement('script'); sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'; sc.async = true;
      sc.onload = function () { res(); }; sc.onerror = function () { tsLoad = null; rej(new Error('The check couldn’t load. Turn off any blocker for this site, or sign in to keep liking.')); };
      document.head.appendChild(sc);
    });
    return tsLoad.then(function () { return new Promise(function (res, rej) {
      var old = document.querySelector('.eg-hc'); if (old) old.remove();
      var box = document.createElement('div'); box.className = 'eg-hc'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'Confirm you’re a person');
      box.innerHTML = '<p><b>One moment</b> Confirming you’re a person…</p><div class="eg-hcw"></div><button type="button" class="eg-b" data-x>Cancel</button>';
      anchor.insertAdjacentElement('afterend', box);
      box.querySelector('[data-x]').addEventListener('click', function () { box.remove(); rej(new Error('cancelled')); });
      try {
        turnstile.render(box.querySelector('.eg-hcw'), { sitekey: sitekey, size: 'flexible',
          callback: function (t) { box.remove(); res(t); },
          'error-callback': function () { box.remove(); rej(new Error('The check didn’t pass. Please try again.')); } });
      } catch (x) { box.remove(); rej(new Error('The check couldn’t start. Please try again.')); }
    }); });
  }
  // A like, and what the checks may ask first: confirm you're a person (428), Keep liking past today's 100 (429), or, for
  // a guest a few likes in, the account panel with Keep going as a guest (401, more). Each then tries the like again.
  function likeIt(like, bar, tries) {
    tries = tries || 0;
    if (window.TvAsk) TvAsk.busy(like, true);
    var again = function () { if (tries < 3) likeIt(like, bar, tries + 1); };
    post({ action: 'like', kind: bar.getAttribute('data-eg-kind'), ref: bar.getAttribute('data-eg-ref') },
         { more: function () { post({ action: 'guest_more' }).then(again).catch(function (x) { TvAsk.say(x.message, { anchor: like, bad: true }); }); } })
      .then(function (d) {
        if (window.TvAsk) TvAsk.busy(like, false);
        like.setAttribute('aria-pressed', d.liked ? 'true' : 'false'); like.querySelector('span').textContent = d.likes;
        if (d.guest && d.ask_learning && window.TvJoin) TvJoin.askLearning(like, function (on) { post({ action: 'learning', on: on }).catch(function () {}); });   // decisions/0051 §1: once a visit
      }).catch(function (x) {
        if (window.TvAsk) TvAsk.busy(like, false);
        if (x.message === 'Sign in first.' || x.message === 'cancelled') return;
        if (x.code === 'check') {
          humanCheck(x.sitekey, like).then(function (t) { return post({ action: 'like_pass', token: t }); }).then(again)
            .catch(function (y) { if (y.message !== 'cancelled') TvAsk.say(y.message, { anchor: like, bad: true }); });
          return;
        }
        if (x.code === 'daily') {
          TvAsk.confirm(x.message + ' Keep liking? You\u2019ll get another 100 for today.', { anchor: like, yes: 'Keep liking', no: 'Not now' }).then(function (yes) {
            if (!yes) return;
            humanCheck(x.sitekey, like).then(function (t) { return post({ action: 'like_more', token: t }); }).then(again)
              .catch(function (y) { if (y.message !== 'cancelled') TvAsk.say(y.message, { anchor: like, bad: true }); });
          });
          return;
        }
        TvAsk.say(x.message, { anchor: like, bad: true });
      });
  }
  function reportBox(near, what, id) {
    var old = document.querySelector('.eg-rep'); if (old) old.remove();
    var box = document.createElement('div'); box.className = 'eg-rep';
    box.innerHTML = '<b>Report</b><br><select>' + Object.keys(REASONS).map(function (k) { return '<option value="' + k + '">' + REASONS[k] + '</option>'; }).join('') + '</select><br>'
      + '<input type="text" maxlength="500" placeholder="Anything we should know (optional)" style="width:100%"><br><button type="button" class="eg-b">Send report</button> <button type="button" class="eg-b" data-x>Cancel</button> <span class="eg-note"></span>';
    near.insertAdjacentElement('afterend', box);
    box.addEventListener('click', function (e) {
      if (e.target.closest('[data-x]')) { box.remove(); return; }
      if (!e.target.closest('button.eg-b')) return;
      var n = box.querySelector('.eg-note');
      post({ action: 'report', what: what, id: id, reason: box.querySelector('select').value, note: box.querySelector('input').value })
        .then(function () { box.innerHTML = '<span class="eg-note">Thank you. Our team will look at it.</span>'; }).catch(function (x) { n.textContent = x.message; });
    });
  }
  document.addEventListener('click', function (e) {
    var bar = e.target.closest('.eg-bar'), sec = e.target.closest('.eg-sec');
    var like = e.target.closest('[data-eg-like]');
    if (like && bar) {
      likeIt(like, bar);
      return;
    }
    var share = e.target.closest('[data-eg-share]');
    if (share && bar) {
      var here = location.origin + location.pathname + location.search;
      var data = { title: bar.getAttribute('data-eg-title') || document.title, url: window.tvShort ? tvShort.now(here) : here };   // trvgo.us (decisions/0094)
      if (navigator.share) { navigator.share(data).catch(function () {}); return; }
      var done = function () { var s = share.querySelector('span'); s.textContent = 'Link copied'; setTimeout(function () { s.textContent = 'Share'; }, 2000); };
      var copy = function () { TvAsk.ask('Copy this link', data.url, { yes: 'Done' }); };
      if (navigator.clipboard) navigator.clipboard.writeText(data.url).then(done, copy); else copy();
      return;
    }
    var rep = e.target.closest('[data-eg-report]');
    if (rep && bar) { var p = rep.getAttribute('data-eg-report').split(':'); reportBox(bar, p[0], +p[1]); return; }
    var del = e.target.closest('[data-eg-del]');
    if (del && sec) {
      if (!TvAsk.gate(del, 'Remove this comment?', { yes: 'Remove', danger: true })) return;
      if (window.TvAsk) TvAsk.busy(del, true);
      post({ action: 'uncomment', comment: +del.getAttribute('data-eg-del') }).then(function () { var cm = del.closest('.eg-cm'); (cm.classList.contains('eg-re') ? cm : (cm.closest('.eg-th') || cm)).remove(); })   // a comment takes its replies with it
        .catch(function (x) { if (window.TvAsk) TvAsk.busy(del, false); TvAsk.say(x.message, { anchor: del, bad: true }); });
      return;
    }
    var crep = e.target.closest('[data-eg-rep]');
    if (crep && sec) { reportBox(crep.closest('.eg-cm'), 'comment', +crep.getAttribute('data-eg-rep')); return; }
    // Reply (decisions/0172 §2.3): one level, a box under the comment's replies; its writer is told
    var rb = e.target.closest('[data-eg-reply]');
    if (rb && sec) {
      var th = rb.closest('.eg-th'), open = th.querySelector('.eg-rf');
      if (open) { open.querySelector('textarea').focus(); return; }
      var main = sec.querySelector('[data-eg-form] [data-eg-age]');
      var f = document.createElement('form'); f.className = 'eg-rf'; f.setAttribute('data-eg-rf', rb.getAttribute('data-eg-reply'));
      f.innerHTML = '<textarea class="eg-in" maxlength="2000" placeholder="Reply to ' + esc(th.querySelector('.eg-cm b').textContent) + ' (public)" required></textarea>'
        + (main ? '<label class="eg-note"><input type="checkbox" data-eg-age required> I am 18 or older</label>' : '')
        + '<p style="margin:.3rem 0 0"><button class="eg-b" type="submit">Post reply</button> <button class="eg-b" type="button" data-eg-rx>Cancel</button></p>';
      th.appendChild(f); f.querySelector('textarea').focus();
      return;
    }
    var rx = e.target.closest('[data-eg-rx]');
    if (rx) { rx.closest('.eg-rf').remove(); }
  });
  document.addEventListener('submit', function (e) {
    var f = e.target.closest('[data-eg-rf]'); if (!f) return;
    e.preventDefault();
    var sec = f.closest('.eg-sec'), t = f.querySelector('textarea'), age = f.querySelector('[data-eg-age]'), btn = f.querySelector('button[type=submit]');
    if (window.TvAsk) TvAsk.busy(btn, true);
    (age && age.checked ? post({ action: 'age' }) : Promise.resolve()).then(function () {
      return post({ action: 'comment', kind: sec.getAttribute('data-eg-kind'), ref: sec.getAttribute('data-eg-ref'), body: t.value, parent: +f.getAttribute('data-eg-rf') });
    }).then(function (d) {
      f.insertAdjacentHTML('beforebegin', '<div class="eg-cm eg-re" data-c="' + d.comment.id + '"><button type="button" data-eg-del="' + d.comment.id + '">Remove</button><b>' + esc(d.comment.name) + '</b><small>just now</small><p>' + esc(d.comment.body) + '</p></div>');
      f.remove();
      var mainAge = sec.querySelector('[data-eg-form] [data-eg-age]'); if (age && mainAge) mainAge.closest('label').remove();
      var n = document.querySelector('.eg-bar a[href="#comments"] span'); if (n) n.textContent = +n.textContent + 1;
    }).catch(function (x) { if (window.TvAsk) { TvAsk.busy(btn, false); TvAsk.say(x.message, { anchor: btn, bad: true }); } });
  });
  document.addEventListener('submit', function (e) {
    var f = e.target.closest('[data-eg-form]'); if (!f) return;
    e.preventDefault();
    var sec = f.closest('.eg-sec'), t = f.querySelector('textarea'), age = f.querySelector('[data-eg-age]'), msg = f.querySelector('[data-eg-msg]');
    msg.textContent = 'Posting…';
    (age && age.checked ? post({ action: 'age' }) : Promise.resolve()).then(function () {
      return post({ action: 'comment', kind: sec.getAttribute('data-eg-kind'), ref: sec.getAttribute('data-eg-ref'), body: t.value });
    }).then(function (d) {
      var none = sec.querySelector('[data-eg-none]'); if (none) none.remove();
      sec.querySelector('[data-eg-list]').insertAdjacentHTML('beforeend', '<div class="eg-th" data-th="' + d.comment.id + '"><div class="eg-cm" data-c="' + d.comment.id + '"><button type="button" data-eg-del="' + d.comment.id + '">Remove</button><button type="button" data-eg-reply="' + d.comment.id + '">Reply</button><b>' + esc(d.comment.name) + '</b><small>just now</small><p>' + esc(d.comment.body) + '</p></div></div>');
      t.value = ''; msg.textContent = ''; if (age) age.closest('label').remove();
      var n = document.querySelector('.eg-bar a[href="#comments"] span'); if (n) n.textContent = +n.textContent + 1;
    }).catch(function (x) { msg.textContent = x.message; });
  });
})();
