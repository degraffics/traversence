/* js/admin-inbox.js — Dashboard → My inbox (decisions/0172 §4.7; app/admin/inbox-console.php). The list is one row per
 * conversation across the mailboxes you read, each labelled with its mailbox; a row opens in place under itself (one at a
 * time) with the email shown safely (Show pictures to load outside ones), its row actions (Unread, Archive, Junk, Make it
 * a case) and its answer box (Reply, Reply all, Forward; From: only your mailboxes; Send). Every press answers beside itself
 * (TvAsk.say). Data: /user/api/mailboxes.php. */
(function () {
  var box = document.getElementById('ib');
  if (!box) return;
  var csrf = box.getAttribute('data-csrf') || '', S = { boxes: [], rows: [] };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, el, bad) { if (window.TvAsk) TvAsk.say(m, { anchor: el, bad: !!bad }); }
  function busy(el, on) { if (window.TvAsk) TvAsk.busy(el, on); }
  function post(body) {
    return fetch('/user/api/mailboxes.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work.'); return j; });
  }
  function tm(w) { return '<time datetime="' + esc(w) + '" data-tv-time>' + esc(w) + '</time>'; }
  var hash = (location.hash || '').match(/^#(ok|error)=(.*)$/);   // back from Sign in with Microsoft
  if (hash) { setTimeout(function () { say(decodeURIComponent(hash[2]), document.getElementById('ib-list'), hash[1] === 'error'); }, 300); history.replaceState(null, '', location.pathname); }

  function load(nosync) {
    var q = document.getElementById('ib-q').value.trim(), b = document.getElementById('ib-box').value, v = document.getElementById('ib-view').value;
    return fetch('/user/api/mailboxes.php?box=' + encodeURIComponent(b) + '&view=' + v + '&q=' + encodeURIComponent(q) + (nosync ? '&nosync=1' : ''), { credentials: 'include' })
      .then(function (r) { return r.json(); }).then(function (j) {
        if (!j.ok) throw new Error((j.error && j.error.message) || 'Your inbox didn\'t load.');
        if (j.csrf) csrf = j.csrf;
        S = j; paint();
      }).catch(function (e) { document.getElementById('ib-list').innerHTML = '<p data-tv-status="bad" data-tv-label="Error:">' + esc(e.message) + ' Try Check now; still stuck? Write to support@traversence.com.</p>'; });
  }
  function paint() {
    var sel = document.getElementById('ib-box'), cur = sel.value;
    sel.innerHTML = '<option value="0">All my mailboxes</option>' + S.boxes.filter(function (b) { return b.status !== 'pending'; }).map(function (b) { return '<option value="' + b.id + '"' + (String(b.id) === cur ? ' selected' : '') + '>' + esc(b.address) + '</option>'; }).join('');
    document.getElementById('ib-boxes').innerHTML = S.boxes.map(function (b) {
      var bad = b.status === 'failed';
      return '<span class="ib-chip' + (bad ? ' bad' : '') + '" title="' + esc(bad ? b.last_error : b.status === 'pending' ? 'Waiting for your manager\'s OK' : 'Last read ' + (b.last_sync_at || 'not yet')) + '">' + esc(b.address) + (b.status === 'pending' ? ' · waiting for an OK' : bad ? ' · needs reconnecting' : '')
        + (b.owner_type !== 'system' ? ' <button type="button" class="ak-btn ghost sm" data-ib-disc="' + b.id + '" data-confirm="Disconnect ' + esc(b.address) + '? Our copy of its mail and its password are deleted; the mailbox itself stays as it is." data-yes="Disconnect" data-danger>Disconnect</button>' : '') + '</span>';
    }).join('');
    var list = document.getElementById('ib-list');
    if (!S.boxes.length) { list.innerHTML = '<p class="ak-note">No mailboxes yet. An owner adds ours (support@, orders@) in Communications, or connect one of yours below.</p>'; return; }
    if (!S.rows.length) { list.innerHTML = '<p class="ak-note">Nothing here' + (document.getElementById('ib-q').value ? ' for that search' : '') + '.</p>'; return; }
    list.innerHTML = S.rows.map(function (r) {
      return '<div class="ib-r' + (r.unread ? ' new' : '') + '" data-id="' + r.id + '" id="mail-' + r.id + '"><span class="ib-s">' + esc(r.from) + (r.count > 1 ? ' (' + r.count + ')' : '') + ' · ' + esc(r.subject || '(no subject)') + (r.attach ? ' (attachment)' : '') + '</span>'
        + '<small>' + tm(r.when) + '</small><small>' + esc(r.snippet) + '</small><small>' + esc(r.mailbox) + '</small></div>';
    }).join('');
    if (window.TvTime) TvTime.paint(list);
    var m = (location.hash || '').match(/^#mail-(\d+)/); if (m) { var row = document.getElementById('mail-' + m[1]); if (row) open(row); }
  }
  function open(row, pictures) {
    var nxt = row.nextElementSibling;
    if (nxt && nxt.classList.contains('ib-open') && !pictures) { nxt.remove(); return; }
    box.querySelectorAll('.ib-open').forEach(function (x) { x.remove(); });   // one open at a time
    var o = document.createElement('div'); o.className = 'ib-open'; o.innerHTML = '<p class="ak-note">Opening…</p>';
    row.insertAdjacentElement('afterend', o); row.classList.remove('new');
    fetch('/user/api/mailboxes.php?thread=' + row.getAttribute('data-id') + (pictures ? '&pictures=1' : ''), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok) throw new Error((j.error && j.error.message) || 'It didn\'t open.');
      var last = j.messages[j.messages.length - 1], held = j.messages.some(function (m) { return m.held_pictures; });
      var addr = function (l) { return (l || []).map(function (a) { return esc(a.addr || a[0] || ''); }).join(', '); };
      o.innerHTML = j.messages.map(function (m) {
        return '<div class="ib-mail"><p><b>' + esc(m.from || m.from_addr) + '</b> &lt;' + esc(m.from_addr) + '&gt; · ' + tm(m.when) + '<br><small>To ' + addr(m.to) + (m.cc && m.cc.length ? ' · Cc ' + addr(m.cc) : '') + ' · in ' + esc(j.mailbox.address) + '</small></p>'
          + (m.html ? '<div class="ib-html">' + m.html + '</div>' : '<pre style="white-space:pre-wrap;font:inherit">' + esc(m.text) + '</pre>')
          + (m.attach && m.attach.length ? '<p><small>Attached: ' + m.attach.map(function (a) { return esc(a.name || 'attachment'); }).join(', ') + ' (open them in the mailbox itself for now)</small></p>' : '') + '</div>';
      }).join('')
        + '<div class="ib-acts">' + (held ? '<button type="button" class="ak-btn ghost sm" data-ib="pictures">Show pictures</button>' : '')
        + '<button type="button" class="ak-btn ghost sm" data-ib="unread">Mark unread</button><button type="button" class="ak-btn ghost sm" data-ib="archive">Archive</button>'
        + '<button type="button" class="ak-btn ghost sm" data-ib="junk" data-confirm="Move it to Junk?" data-yes="Move to Junk">Junk</button><button type="button" class="ak-btn ghost sm" data-ib="case">Make it a case</button></div>'
        + '<form class="ib-reply"><label>Reply <select name="how"><option value="reply">Reply</option><option value="all">Reply all</option><option value="fwd">Forward</option></select></label>'
        + '<label>From <select name="from">' + j.from_choices.map(function (f) { return '<option value="' + f.id + '"' + (f.id === j.mailbox.id ? ' selected' : '') + '>' + esc(f.address) + '</option>'; }).join('') + '</select></label>'
        + '<label>To <input name="to" value="' + esc(last.direction === 'out' ? addr(last.to) : last.from_addr) + '" spellcheck="false"></label><label>Cc <input name="cc" spellcheck="false"></label>'
        + '<label>Message <textarea name="text" rows="5" data-spell required></textarea></label><button class="ak-btn">Send</button></form>';
      o.setAttribute('data-last', last.id); o.setAttribute('data-to', last.from_addr); o.setAttribute('data-all', [last.from_addr].concat((last.to || []).map(function (a) { return a.addr || a[0]; }), (last.cc || []).map(function (a) { return a.addr || a[0]; })).filter(function (a) { return a && j.from_choices.every(function (f) { return f.address !== a; }); }).join(', '));
      o.setAttribute('data-subject', last.subject || '');
      if (window.TvTime) TvTime.paint(o);
    }).catch(function (e) { o.innerHTML = '<p data-tv-status="bad" data-tv-label="Error:">' + esc(e.message) + '</p>'; });
  }
  box.addEventListener('click', function (ev) {
    var d = ev.target.closest('[data-ib-disc]');
    if (d) { if (window.TvAsk && !TvAsk.gate(d, d.getAttribute('data-confirm'), { yes: 'Disconnect', danger: true })) return; busy(d, true); post({ disconnect: +d.getAttribute('data-ib-disc') }).then(function (j) { busy(d, false); say(j.message, d); setTimeout(function () { load(true); }, 900); }).catch(function (e) { busy(d, false); say(e.message, d, true); }); return; }
    var a = ev.target.closest('[data-ib]');
    if (a) {
      var o = a.closest('.ib-open'), row = o.previousElementSibling, id = +o.getAttribute('data-last'), what = a.getAttribute('data-ib');
      if (what === 'pictures') { open(row, true); return; }
      if (a.hasAttribute('data-confirm') && window.TvAsk && !TvAsk.gate(a, a.getAttribute('data-confirm'), { yes: a.getAttribute('data-yes') })) return;
      busy(a, true);
      post(what === 'case' ? { make_case: id } : { act: what, mail: id }).then(function (j) { busy(a, false); say(j.message, a); if (what === 'unread') row.classList.add('new'); if (what === 'archive' || what === 'junk') setTimeout(function () { o.remove(); row.remove(); }, 900); })
        .catch(function (e) { busy(a, false); say(e.message, a, true); });
      return;
    }
    var r = ev.target.closest('.ib-r'); if (r) open(r);
  });
  box.addEventListener('change', function (ev) {
    var s = ev.target.closest('.ib-reply select[name=how]');
    if (!s) return;
    var f = s.form, o = f.closest('.ib-open');
    f.elements.to.value = s.value === 'fwd' ? '' : s.value === 'all' ? o.getAttribute('data-all') : o.getAttribute('data-to');
  });
  box.addEventListener('submit', function (ev) {
    var f = ev.target;
    if (f.id === 'ib-cform') {
      ev.preventDefault();
      var b = f.querySelector('button'), c = {}; Array.prototype.forEach.call(f.elements, function (x) { if (x.name) c[x.name] = x.value; });
      busy(b, true);
      post({ connect: c }).then(function (j) { busy(b, false); say(j.message, b); f.reset(); setTimeout(function () { load(); }, 900); }).catch(function (e) { busy(b, false); say(e.message, b, true); });
      return;
    }
    if (!f.classList.contains('ib-reply')) return;
    ev.preventDefault();
    var o = f.closest('.ib-open'), btn = f.querySelector('button'), how = f.elements.how.value, sub = o.getAttribute('data-subject');
    var body = { from: +f.elements.from.value, to: f.elements.to.value, cc: f.elements.cc.value, text: f.elements.text.value };
    if (how === 'fwd') { body.subject = /^fwd?:/i.test(sub) ? sub : 'Fwd: ' + sub; body.text += '\n\n---------- Forwarded message ----------\n' + (o.querySelector('.ib-mail:last-of-type') || o).innerText.slice(0, 20000); }
    else body.reply_to = +o.getAttribute('data-last');
    busy(btn, true);
    post({ send: body }).then(function (j) { busy(btn, false); say(j.message, btn); f.elements.text.value = ''; }).catch(function (e) { busy(btn, false); say(e.message, btn, true); });
  });
  document.getElementById('ib-new').addEventListener('click', function (ev) {
    var list = document.getElementById('ib-list'), ex = document.getElementById('ib-compose');
    if (ex) { ex.remove(); return; }
    var o = document.createElement('div'); o.className = 'ib-open'; o.id = 'ib-compose';
    o.innerHTML = '<form class="ib-reply"><input type="hidden" name="how" value="new"><label>From <select name="from">' + S.boxes.filter(function (b) { return b.status === 'active'; }).map(function (b) { return '<option value="' + b.id + '">' + esc(b.address) + '</option>'; }).join('') + '</select></label>'
      + '<label>To <input name="to" spellcheck="false" required></label><label>Cc <input name="cc" spellcheck="false"></label><label>Subject <input name="subject" data-spell></label><label>Message <textarea name="text" rows="6" data-spell required></textarea></label><button class="ak-btn">Send</button></form>';
    list.insertAdjacentElement('beforebegin', o);
    o.querySelector('form').addEventListener('submit', function (e2) {
      e2.preventDefault(); e2.stopPropagation();
      var f = e2.target, btn = f.querySelector('button');
      busy(btn, true);
      post({ send: { from: +f.elements.from.value, to: f.elements.to.value, cc: f.elements.cc.value, subject: f.elements.subject.value, text: f.elements.text.value } })
        .then(function (j) { busy(btn, false); say(j.message, btn); f.reset(); }).catch(function (e) { busy(btn, false); say(e.message, btn, true); });
    });
  });
  document.getElementById('ib-refresh').addEventListener('click', function (ev) { var b = ev.currentTarget; busy(b, true); load().then(function () { busy(b, false); say('Up to date.', b); }); });
  ['ib-box', 'ib-view'].forEach(function (id) { document.getElementById(id).addEventListener('change', function () { load(true); }); });
  var tq; document.getElementById('ib-q').addEventListener('input', function () { clearTimeout(tq); tq = setTimeout(function () { load(true); }, 350); });
  load();
})();
