/* js/admin-comms.js — System Configuration → Communications (decisions/0167; app/admin/comms-console.php). Each button
 * (data-cs) posts its JSON to /admin/api/comms.php, shows its spinner, asks first where it changes something
 * (data-confirm), answers beside itself (TvAsk.say), and the page is drawn again in place, keeping what's open. Forms
 * (data-cs-form) post their fields the same way. "…_open" buttons only open the small form for that row. The lazy
 * parts (domain health, Sent) load when opened. A routing choice saves when it changes. */
(function () {
  var box = document.getElementById('cs');
  if (!box) return;
  var csrf = box.getAttribute('data-csrf') || '';
  function post(body) {
    return fetch('/admin/api/comms.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again; still stuck? Write to support@traversence.com.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again.'); return j; });
  }
  function say(msg, el, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: el, bad: !!bad }); }
  function redraw(then) {
    var open = {}; box.querySelectorAll('details').forEach(function (d, i) { open[i] = d.open; });
    fetch(location.pathname + location.search, { credentials: 'include' }).then(function (r) { return r.ok ? r.text() : ''; }).then(function (html) {
      var nb = html && new DOMParser().parseFromString(html, 'text/html').getElementById('cs');
      if (!nb) return;
      box.innerHTML = nb.innerHTML;
      box.querySelectorAll('details').forEach(function (d, i) { if (open[i]) { d.open = true; lazy(d); } });
      if (window.TvTime) TvTime.paint(box);
      if (then) then();
    });
  }
  function lazy(d) {
    var part = d.getAttribute('data-cs-lazy'), body = d.querySelector('.cs-lazy-body');
    if (!part || !body || d.getAttribute('data-loaded')) return;
    d.setAttribute('data-loaded', '1');
    body.innerHTML = '<p class="ak-note">Reading…</p>';
    fetch('/admin/api/comms.php?lazy=' + part, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) {
      body.innerHTML = j.ok ? j.html : '<p data-tv-status="bad" data-tv-label="Error:">' + ((j.error && j.error.message) || 'It didn\'t load.') + '</p>';
      if (window.TvTime) TvTime.paint(body);
    }).catch(function () { body.innerHTML = '<p data-tv-status="bad" data-tv-label="Error:">It didn\'t load. Close and open it again.</p>'; d.removeAttribute('data-loaded'); });
  }
  function showForm(id, b, fields, label) {
    var f = document.getElementById(id);
    if (!f) return;
    Object.keys(fields).forEach(function (k) { var x = f.querySelector('[name=' + k + ']'); if (x) x.value = fields[k]; });
    var l = f.querySelector('[data-cs-label]'); if (l) l.textContent = label || '';
    f.hidden = false;
    var at = b.closest('.cs-scroll') || b.closest('section') || b.parentNode;   // under the table it was opened from (a form can't sit inside a row)
    at.insertAdjacentElement('afterend', f);
    var first = f.querySelector('input:not([type=hidden]), select'); if (first) first.focus();
  }
  box.addEventListener('toggle', function (ev) { if (ev.target.open) lazy(ev.target); }, true);
  box.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-cs]');
    if (!b || b.disabled) return;
    var body; try { body = JSON.parse(b.getAttribute('data-cs')); } catch (x) { return; }
    var a = body.action;
    if (a === 'fields_open') { var sec = b.closest('section'), f = sec && sec.querySelector('.cs-fields'); if (f) { f.hidden = !f.hidden; } return; }
    if (a === 'overseer_open') { showForm('cs-overseer', b, { mailbox: body.mailbox }, ''); document.getElementById('cs-overseer').hidden = false; return; }
    if (a === 'reset_open') { showForm('cs-reset', b, { email: body.email }, 'Reset ' + body.email); return; }
    if (a === 'read_open') { showForm('cs-read', b, { email: body.email }, 'Read ' + body.email + ' in its overseers\' Pulse inbox'); return; }
    if (b.hasAttribute('data-confirm') && window.TvAsk && !TvAsk.gate(b, b.getAttribute('data-confirm'), { yes: b.getAttribute('data-yes') || 'Yes', danger: b.hasAttribute('data-danger') })) return;
    if (window.TvAsk) TvAsk.busy(b, true);
    post(body).then(function (j) {
      if (window.TvAsk) TvAsk.busy(b, false);
      var id = b.id || '';
      say(j.message, b);
      if (a !== 'check' && a !== 'test') redraw(function () { var n = id && document.getElementById(id); if (n) say(j.message, n); });
    }).catch(function (e) { if (window.TvAsk) TvAsk.busy(b, false); say(e.message, b, true); });
  });
  box.addEventListener('submit', function (ev) {
    var f = ev.target.closest('[data-cs-form]');
    if (!f) return;
    ev.preventDefault();
    var body; try { body = JSON.parse(f.getAttribute('data-cs-form')); } catch (x) { return; }
    Array.prototype.forEach.call(f.elements, function (x) { if (!x.name) return; body[x.name] = x.type === 'checkbox' ? x.checked : x.value; });
    var btn = f.querySelector('button') || f;
    if (window.TvAsk) TvAsk.busy(btn, true);
    post(body).then(function (j) {
      if (window.TvAsk) TvAsk.busy(btn, false);
      say(j.message, btn);
      setTimeout(redraw, 1200);   // the answer stays readable beside the button, then the page shows the change
    }).catch(function (e) { if (window.TvAsk) TvAsk.busy(btn, false); say(e.message, btn, true); });
  });
  box.addEventListener('change', function (ev) {
    var s = ev.target.closest('[data-cs-route]');
    if (!s) return;
    if (window.TvAsk) TvAsk.busy(s, true);
    post({ action: 'route', kind: s.getAttribute('data-cs-route'), sender: s.value }).then(function (j) { if (window.TvAsk) TvAsk.busy(s, false); say(j.message, s); })
      .catch(function (e) { if (window.TvAsk) TvAsk.busy(s, false); say(e.message, s, true); });
  });
})();
