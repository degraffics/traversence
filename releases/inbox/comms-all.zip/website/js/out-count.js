// js/out-count.js — the platform's counts (decisions/0058 §9, §13). Counts only: never who. Nothing here identifies a
// person or a device; "the section before" is kept in this tab only (sessionStorage) to count the move between them.
//   • a page: its section (<meta name="tv-sec">) and item (<meta name="tv-item">), and the move from the section
//     before, to /api/count.php (m=view)
//   • Call, Email, Directions, Website, Contact on a listing ([data-out][data-e]) to /api/out.php, for the business (and,
//     while it's unclaimed, for Sales as a reason to invite: decisions/0172 §3.3)
//   • anything marked [data-count="metric:key"] (e.g. "act:recommend"), and what's opened from the search panel
(function () {
  'use strict';
  function beacon(url, data) {
    try {
      var f = new FormData(); Object.keys(data).forEach(function (k) { if (data[k] != null && data[k] !== '') f.append(k, data[k]); });
      if (navigator.sendBeacon) navigator.sendBeacon(url, f); else fetch(url, { method: 'POST', body: f, credentials: 'include', keepalive: true });
    } catch (x) {}
  }
  window.tvCount = function (data) { beacon('/api/count.php', data); };
  // the page itself
  function meta(n) { var m = document.querySelector('meta[name="' + n + '"]'); return m ? m.getAttribute('content') : ''; }
  var sec = meta('tv-sec');
  if (sec) {
    // the page's address too (Jason, 2026-10-30: "actual page urls and routes: SEO proof"): its path, with ?id= or
    // ?view= when they name what's shown; the page before it in this tab; and, arriving from outside, the site that sent
    // them (its name only, never the full address)
    var q = new URLSearchParams(location.search), path = location.pathname + (q.get('id') ? '?id=' + q.get('id') : (q.get('view') ? '?view=' + q.get('view') : ''));
    var before = '', pathBefore = ''; try { before = sessionStorage.getItem('tv_sec') || ''; pathBefore = sessionStorage.getItem('tv_path') || ''; sessionStorage.setItem('tv_sec', sec); sessionStorage.setItem('tv_path', path); } catch (x) {}
    var ref = ''; try { var r = document.referrer ? new URL(document.referrer) : null; if (r && r.host !== location.host) ref = r.host; } catch (x) {}
    beacon('/api/count.php', { m: 'view', s: sec, i: meta('tv-item'), f: before, p: path, pb: pathBefore, ref: before ? '' : ref, utm: before ? '' : (q.get('utm_source') || '') });
  }
  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target : null; if (!t) return;
    var a = t.closest('[data-out][data-e]');
    if (a) beacon('/api/out.php', { e: a.getAttribute('data-e'), a: a.getAttribute('data-out') });
    var c = t.closest('[data-count]');
    if (c) { var p = c.getAttribute('data-count').split(':'); beacon('/api/count.php', { m: p[0], k: p.slice(1).join(':') }); return; }
    var r = t.closest('.tvs-panel [data-kind]');   // opened from the search: what kind of thing
    if (r) beacon('/api/count.php', { m: 'search_click', k: r.getAttribute('data-kind') });
  }, true);
})();
