/*
 * js/tv-push.js — push on this device (decisions/0172 §4.4, §4.6). Needs js/tv-ask.js.
 *   TvPush.supported()          → bool: this browser can take pushes (on an iPhone or iPad, once the site is on the Home Screen)
 *   TvPush.state()              → Promise<'on'|'off'|'blocked'|'unsupported'>
 *   TvPush.turnOn(btn)          → Promise<bool>  registers /push-sw.js, asks the browser, subscribes, tells the site
 *   TvPush.turnOff(btn)         → Promise<bool>
 *   TvPush.ask(btn, why)        → Promise<bool>  asked when an action turns push on (§4.4): our own small question beside
 *                                                the button first; the browser's prompt only after the person says yes
 *   TvPush.test(btn)            → Promise<bool>  "Push works on this device" to each of the person's devices
 *   TvPush.devices()            → Promise<[{id, device, created, last_ok, failed, here}]>  (here: this browser)
 *   TvPush.remove(btn, id)      → Promise<bool>  another device off
 * Every button shows TvAsk.busy while it works and answers with TvAsk.say beside it. No browser dialogs of our own.
 */
(function () {
  if (window.TvPush) return;
  var API = '/user/api/push.php', SW = '/push-sw.js';
  var csrf = null, synced = false;

  function ios() { return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); }
  function standalone() { return navigator.standalone === true || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches); }
  var HOME_SCREEN = 'On an iPhone or iPad, push works once Traversence is on your Home Screen: tap Share, then "Add to Home Screen", open Traversence from there and turn push on again.';
  var BLOCKED = 'Notifications are blocked for this site in your browser. To allow them, tap the padlock or site settings icon beside the address, set Notifications to Allow, then reload this page and try again.';
  var NO_PUSH = 'This browser can\'t take push notifications. Try a recent Chrome, Edge, Firefox or Safari, or keep getting these in Pulse and by email.';

  function apiOk() { return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && window.isSecureContext; }
  function supported() { return apiOk() && !(ios() && !standalone()); }
  function whyNot() { return ios() && !standalone() ? HOME_SCREEN : NO_PUSH; }

  function say(btn, msg, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: btn || undefined, bad: !!bad }); }
  function busy(btn, on) { if (btn && window.TvAsk) TvAsk.busy(btn, on); }

  function get() {
    return fetch(API, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d || !d.ok) throw new Error((d && d.error) || 'Push isn\'t available right now. Try again later.');
      csrf = d.csrf || csrf; return d;
    });
  }
  function post(body) {
    var go = function () {
      return fetch(API, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
        .then(function (r) { return r.json(); }).then(function (d) {
          if (!d || !d.ok) throw new Error((d && (d.error || d.message)) || 'That didn\'t go through. Try again.');
          return d;
        });
    };
    return csrf ? go() : get().then(go);
  }
  function errText(e) { return (e && e.message) ? e.message : 'That didn\'t go through. Try again.'; }

  function keyBytes(b64u) {
    var s = b64u.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
    var raw = atob(s), out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }
  function sameKey(a, b) {
    if (!a || !b) return false;
    a = new Uint8Array(a); if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }
  function deviceName() {
    var ua = navigator.userAgent, b = 'Browser', o = '';
    if (/Edg\//.test(ua)) b = 'Edge'; else if (/OPR\//.test(ua)) b = 'Opera'; else if (/Firefox\//.test(ua)) b = 'Firefox';
    else if (/Chrome\//.test(ua)) b = 'Chrome'; else if (/Safari\//.test(ua)) b = 'Safari';
    if (ios()) o = /iPad/.test(ua) || navigator.maxTouchPoints > 1 && !/iPhone/.test(ua) ? 'iPad' : 'iPhone';
    else if (/Android/.test(ua)) o = 'Android'; else if (/Windows/.test(ua)) o = 'Windows'; else if (/Mac OS X/.test(ua)) o = 'Mac';
    else if (/CrOS/.test(ua)) o = 'Chromebook'; else if (/Linux/.test(ua)) o = 'Linux';
    return o ? b + ' on ' + o : b;
  }
  function hash(text) {
    if (!window.crypto || !crypto.subtle) return Promise.resolve('');
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)).then(function (buf) {
      return Array.prototype.map.call(new Uint8Array(buf), function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
    });
  }

  function registration() { return navigator.serviceWorker.getRegistration('/').then(function (r) { return r || null; }); }
  function currentSub() { return registration().then(function (r) { return r ? r.pushManager.getSubscription() : null; }); }

  function state() {
    if (!supported()) return Promise.resolve('unsupported');
    if (Notification.permission === 'denied') return Promise.resolve('blocked');
    return currentSub().then(function (s) {
      if (s && !synced && Notification.permission === 'granted') { synced = true; post({ subscribe: s.toJSON(), device: deviceName() }).catch(function () {}); }   // keeps the site's copy current (a renewed endpoint)
      return s && Notification.permission === 'granted' ? 'on' : 'off';
    }).catch(function () { return 'off'; });
  }

  function turnOn(btn) {
    if (!supported()) { say(btn, whyNot(), true); return Promise.resolve(false); }
    if (Notification.permission === 'denied') { say(btn, BLOCKED, true); return Promise.resolve(false); }
    busy(btn, true);
    // the browser's question first, while the tap still counts as the person's (Safari needs it)
    var perm = Notification.permission === 'granted' ? Promise.resolve('granted') : new Promise(function (res) {
      var p = Notification.requestPermission(res); if (p && p.then) p.then(res);
    });
    return perm.then(function (answer) {
      if (answer !== 'granted') { var e = new Error(answer === 'denied' ? BLOCKED : 'Push wasn\'t turned on. When you\'re ready, try again and choose Allow.'); e.soft = answer !== 'denied'; throw e; }
      return Promise.all([navigator.serviceWorker.register(SW, { scope: '/' }), get()]);
    }).then(function (both) {
      var reg = both[0], key = keyBytes(both[1].key);
      return navigator.serviceWorker.ready.then(function () { return reg.pushManager.getSubscription(); }).then(function (old) {
        if (old && !sameKey(old.options && old.options.applicationServerKey, key)) return old.unsubscribe().then(function () { return null; });
        return old;
      }).then(function (old) { return old || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key }); });
    }).then(function (sub) {
      return post({ subscribe: sub.toJSON(), device: deviceName() });
    }).then(function () {
      synced = true; busy(btn, false);
      say(btn, 'Push is on for this device. Choose what comes by push in your Communications setting.', false);
      return true;
    }).catch(function (e) {
      busy(btn, false); say(btn, errText(e), !e.soft); return false;
    });
  }

  function turnOff(btn) {
    if (!apiOk()) { say(btn, 'Push isn\'t on for this device.', false); return Promise.resolve(true); }
    busy(btn, true);
    return currentSub().then(function (s) {
      if (!s) return null;
      return post({ unsubscribe: s.endpoint }).then(function () { return s.unsubscribe(); });
    }).then(function () {
      busy(btn, false); say(btn, 'Push is off for this device. You\'ll still find everything in Pulse.', false); return true;
    }).catch(function (e) { busy(btn, false); say(btn, errText(e), true); return false; });
  }

  function ask(btn, why) {
    return state().then(function (st) {
      if (st === 'on') return true;
      if (st === 'unsupported') { say(btn, whyNot(), false); return false; }
      if (st === 'blocked') { say(btn, BLOCKED, true); return false; }
      if (!window.TvAsk) return false;
      return TvAsk.confirm(why || 'Get a push on this device when this happens?', { anchor: btn, yes: 'Turn on push', no: 'Not now' })
        .then(function (yes) { return yes ? turnOn(btn) : false; });
    });
  }

  function test(btn) {
    busy(btn, true);
    return post({ test: true }).then(function (d) {
      busy(btn, false);
      if (d.none) { say(btn, 'You have no devices with push on. Turn it on here first.', true); return false; }
      if (d.held && !d.sent) { say(btn, 'Pushes are held on staging, so nothing was sent.', false); return false; }
      say(btn, d.failed ? 'Sent to ' + d.sent + ' of your devices; ' + d.failed + ' didn\'t take it. A device that keeps failing can be turned off and on again.' : 'Sent. It should show on each of your devices in a moment.', !!d.failed && !d.sent);
      return d.sent > 0;
    }).catch(function (e) { busy(btn, false); say(btn, errText(e), true); return false; });
  }

  function devices() {
    return Promise.all([get(), apiOk() ? currentSub().catch(function () { return null; }) : null]).then(function (both) {
      var list = both[0].devices || [], s = both[1];
      return (s ? hash(s.endpoint) : Promise.resolve('')).then(function (h) {
        return list.map(function (d) { return { id: d.id, device: d.device, created: d.created, last_ok: d.last_ok, failed: d.failed, here: !!h && d.hash === h }; });
      });
    });
  }

  function remove(btn, id) {
    busy(btn, true);
    return post({ remove: id }).then(function () { busy(btn, false); say(btn, 'That device won\'t get pushes any more.', false); return true; })
      .catch(function (e) { busy(btn, false); say(btn, errText(e), true); return false; });
  }

  window.TvPush = { supported: supported, state: state, turnOn: turnOn, turnOff: turnOff, ask: ask, test: test, devices: devices, remove: remove };
})();
