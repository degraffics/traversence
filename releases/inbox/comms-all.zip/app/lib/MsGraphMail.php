<?php
// app/lib/MsGraphMail.php — Microsoft 365 and Outlook.com mailboxes in Pulse by "Sign in with Microsoft" (decisions/0172
// §4.7: Microsoft no longer accepts passwords for IMAP, so this is the one service that needs sign-in from the start; it
// costs nothing, publisher verification is free). Through Microsoft Graph: read the inbox, send from the mailbox (saved in
// its own Sent Items), mark read, move. No password is kept: the sign-in's tokens are sealed by the caller (CommsCrypt).
// .env: MS_MAIL_CLIENT_ID and MS_MAIL_CLIENT_SECRET, from the app registration at
// https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade (any organization's directory and
// personal accounts; redirect URI https://traversence.com/api/ms-mail.php). A token is refreshed in place when it has
// expired ($tok is passed by reference: the caller seals it again). Staging never calls Microsoft (StagingGate::hold, 0165).
// Refusals are thrown in plain words for the person's Reconnect alert; tokens are never logged.
declare(strict_types=1);

final class MsGraphMail
{
    public const REDIRECT = 'https://traversence.com/api/ms-mail.php';
    private const LOGIN = 'https://login.microsoftonline.com/common/oauth2/v2.0/';
    private const GRAPH = 'https://graph.microsoft.com/v1.0';
    private const SCOPES = 'offline_access openid email Mail.ReadWrite Mail.Send User.Read';

    /** For tests only: function (string $method, string $url, array $headers, ?string $body): [int status, string body]. */
    public static ?Closure $http = null;

    /** The app's keys are in .env. */
    public static function ready(): bool
    {
        return self::env('MS_MAIL_CLIENT_ID') !== '' && self::env('MS_MAIL_CLIENT_SECRET') !== '';
    }

    /** Where the person is sent to sign in; $state comes back to the redirect (the caller checks it). */
    public static function authUrl(string $state): string
    {
        return self::LOGIN . 'authorize?' . http_build_query([
            'client_id' => self::env('MS_MAIL_CLIENT_ID'),
            'response_type' => 'code',
            'redirect_uri' => self::REDIRECT,
            'response_mode' => 'query',
            'scope' => self::SCOPES,
            'state' => $state,
            'prompt' => 'select_account',
        ], '', '&', PHP_QUERY_RFC3986);
    }

    /** The code from the redirect → [access_token, refresh_token, expires_at, address, name]. */
    public static function exchange(string $code): array
    {
        $tok = self::token(['grant_type' => 'authorization_code', 'code' => $code, 'redirect_uri' => self::REDIRECT], '');
        [$st, $me] = self::call('GET', '/me?$select=mail,userPrincipalName,displayName', $tok['access_token']);
        if ($st !== 200) throw new RuntimeException(self::graphError($st, $me, 'the new sign-in'));
        $addr = (string) ($me['mail'] ?? '') ?: (string) ($me['userPrincipalName'] ?? '');
        $tok['address'] = $addr;
        $tok['name'] = (string) ($me['displayName'] ?? '');
        return $tok;
    }

    /** A fresh access token from the refresh token; the address is kept. */
    public static function refresh(array $tok): array
    {
        $addr = (string) ($tok['address'] ?? '');
        if ((string) ($tok['refresh_token'] ?? '') === '') throw new RuntimeException('Microsoft\'s sign-in for ' . ($addr ?: 'this mailbox') . ' expired: reconnect it.');
        $new = self::token(['grant_type' => 'refresh_token', 'refresh_token' => (string) $tok['refresh_token']], $addr);
        if ($new['refresh_token'] === '') $new['refresh_token'] = (string) $tok['refresh_token'];   // Microsoft may not send a new one
        return array_merge($tok, $new);
    }

    /**
     * Inbox messages in MailMime::parse()'s shape, plus uid (Graph's id, which survives moves), seen, thread (Graph's
     * conversationId) and has_attachments. $since (ISO 8601): only those received at or after it, oldest first; else the
     * newest 50.
     */
    public static function list(array &$tok, string $since = ''): array
    {
        $q = ['$select' => 'id,internetMessageId,conversationId,from,toRecipients,ccRecipients,replyTo,subject,receivedDateTime,bodyPreview,body,hasAttachments,isRead,flag',
              '$top' => '50'];
        if ($since !== '') {
            $t = strtotime($since);
            if ($t === false) throw new InvalidArgumentException('"since" isn\'t a date.');
            $q['$filter'] = 'receivedDateTime ge ' . gmdate('Y-m-d\TH:i:s\Z', $t);
            $q['$orderby'] = 'receivedDateTime asc';
        } else {
            $q['$orderby'] = 'receivedDateTime desc';
        }
        $r = self::authed($tok, 'GET', '/me/mailFolders/inbox/messages?' . http_build_query($q, '', '&', PHP_QUERY_RFC3986), null, 'read the inbox');
        $out = [];
        foreach ((array) ($r['value'] ?? []) as $m) $out[] = self::normalize((array) $m);
        return $out;
    }

    /**
     * Sends from the mailbox, saved in its Sent Items. $m: to [[addr, name] …], cc, subject, text or html,
     * attachments [[name, type, data] …]; a reply: reply_to_graph_id (the message answered), so Microsoft threads it.
     */
    public static function send(array &$tok, array $m): void
    {
        $html = (string) ($m['html'] ?? '');
        $text = (string) ($m['text'] ?? '');
        $body = $html !== '' ? ['contentType' => 'HTML', 'content' => $html] : ['contentType' => 'Text', 'content' => $text];
        $msg = ['toRecipients' => self::recipients($m['to'] ?? [])];
        if (!empty($m['cc'])) $msg['ccRecipients'] = self::recipients($m['cc']);
        $atts = [];
        foreach ((array) ($m['attachments'] ?? []) as $a) {
            $atts[] = ['@odata.type' => '#microsoft.graph.fileAttachment', 'name' => (string) ($a['name'] ?? 'attachment'),
                'contentType' => (string) ($a['type'] ?? '') ?: 'application/octet-stream', 'contentBytes' => base64_encode((string) ($a['data'] ?? ''))];
        }
        if ($atts) $msg['attachments'] = $atts;
        $reply = (string) ($m['reply_to_graph_id'] ?? '');
        if ($reply !== '') {
            // the reply keeps Microsoft's thread and quoting; the comment is the person's words
            $msg['body'] = $body;
            if (!$msg['toRecipients']) unset($msg['toRecipients']);
            self::authed($tok, 'POST', '/me/messages/' . rawurlencode($reply) . '/reply', ['message' => $msg], 'send the reply');
            return;
        }
        if (!$msg['toRecipients']) throw new RuntimeException('The message has no one to send to.');
        $msg['subject'] = (string) ($m['subject'] ?? '');
        $msg['body'] = $body;
        self::authed($tok, 'POST', '/me/sendMail', ['message' => $msg, 'saveToSentItems' => true], 'send the message');
    }

    public static function markRead(array &$tok, string $id, bool $on): void
    {
        self::authed($tok, 'PATCH', '/me/messages/' . rawurlencode($id), ['isRead' => $on], 'mark the message ' . ($on ? 'read' : 'unread'));
    }

    /** Moves a message to a well-known folder (inbox, archive, deleteditems, junkemail, sentitems) or a folder id; its new id. */
    public static function move(array &$tok, string $id, string $folderWellKnown): string
    {
        $r = self::authed($tok, 'POST', '/me/messages/' . rawurlencode($id) . '/move', ['destinationId' => $folderWellKnown], 'move the message');
        return (string) ($r['id'] ?? $id);
    }

    // ---- inside -------------------------------------------------------------------------------------------------------

    /** A Graph message → MailMime::parse()'s shape. */
    public static function normalize(array $m): array
    {
        $addr = fn ($r) => ['addr' => (string) ($r['emailAddress']['address'] ?? ''), 'name' => (string) ($r['emailAddress']['name'] ?? '')];
        $list = fn ($rs) => array_values(array_filter(array_map($addr, (array) $rs), fn ($a) => $a['addr'] !== ''));
        $isHtml = strtolower((string) ($m['body']['contentType'] ?? '')) === 'html';
        $content = (string) ($m['body']['content'] ?? '');
        if (!class_exists('MailMime')) require_once __DIR__ . '/MailMime.php';
        $t = strtotime((string) ($m['receivedDateTime'] ?? ''));
        return [
            'uid' => (string) ($m['id'] ?? ''),
            'message_id' => trim((string) ($m['internetMessageId'] ?? ''), '<> '),
            'in_reply_to' => '',
            'references' => [],
            'thread' => (string) ($m['conversationId'] ?? ''),
            'from' => isset($m['from']) ? $addr($m['from']) : ['addr' => '', 'name' => ''],
            'to' => $list($m['toRecipients'] ?? []),
            'cc' => $list($m['ccRecipients'] ?? []),
            'reply_to' => $list($m['replyTo'] ?? []),
            'subject' => (string) ($m['subject'] ?? ''),
            'date' => $t === false ? 0 : $t,
            'text' => $isHtml ? MailMime::htmlToText($content) : $content,
            'html' => $isHtml ? $content : '',
            'attachments' => [],
            'has_attachments' => !empty($m['hasAttachments']),
            'seen' => !empty($m['isRead']),
            'flagged' => strtolower((string) ($m['flag']['flagStatus'] ?? '')) === 'flagged',
            'snippet' => (string) ($m['bodyPreview'] ?? ''),
        ];
    }

    private static function recipients($list): array
    {
        $out = [];
        foreach ((array) $list as $r) {
            if (is_string($r)) $r = ['addr' => $r];
            $a = trim((string) ($r['addr'] ?? $r[0] ?? ''));
            if ($a === '') continue;
            $e = ['address' => $a];
            $n = trim((string) ($r['name'] ?? $r[1] ?? ''));
            if ($n !== '') $e['name'] = $n;
            $out[] = ['emailAddress' => $e];
        }
        return $out;
    }

    /** A Graph call with the token refreshed first when it has expired (or once more after a 401). */
    private static function authed(array &$tok, string $method, string $path, ?array $body, string $doing): array
    {
        $who = (string) ($tok['address'] ?? '') ?: 'this mailbox';
        if ((int) ($tok['expires_at'] ?? 0) < time() + 60) $tok = self::refresh($tok);
        [$st, $r] = self::call($method, $path, (string) ($tok['access_token'] ?? ''), $body);
        if ($st === 401) {
            $tok = self::refresh($tok);
            [$st, $r] = self::call($method, $path, (string) $tok['access_token'], $body);
            if ($st === 401) throw new RuntimeException('Microsoft\'s sign-in for ' . $who . ' expired: reconnect it.');
        }
        if ($st < 200 || $st >= 300) throw new RuntimeException(self::graphError($st, $r, $who, $doing));
        return $r;
    }

    private static function graphError(int $st, array $r, string $who, string $doing = 'reach the mailbox'): string
    {
        $code = (string) ($r['error']['code'] ?? '');
        $msg = trim(preg_replace('/\s+/', ' ', (string) ($r['error']['message'] ?? '')) ?? '');
        $said = $msg !== '' ? ' (it said "' . mb_substr($msg, 0, 200) . '")' : '';
        if ($st === 0) return 'Microsoft didn\'t answer when asked to ' . $doing . ' for ' . $who . ': it will be tried again.';
        if ($code === 'MailboxNotEnabledForRESTAPI' || $code === 'MailboxNotHostedInExchangeOnline' || $code === 'ResourceNotFound' && str_contains($msg, 'mailbox')) {
            return 'The Microsoft account ' . $who . ' has no Outlook mailbox that can be read.';
        }
        if ($code === 'ErrorQuotaExceeded' || stripos($msg, 'quota') !== false) return 'The mailbox ' . $who . ' is full.';
        if ($code === 'ErrorAccessDenied' || $code === 'Authorization_RequestDenied' || $st === 403) {
            return 'Microsoft refused to let Traversence ' . $doing . ' for ' . $who . $said . ': reconnect it and allow mail access (a work account\'s administrator may need to approve it).';
        }
        if ($code === 'ErrorItemNotFound' || $st === 404) return 'That message is no longer in ' . $who . ' (moved or deleted in Outlook).';
        if ($st === 429 || $st === 503 || $st === 504) return 'Microsoft asked us to slow down for ' . $who . ': it will be tried again in a few minutes.';
        if ($code === 'ErrorMessageSizeExceeded' || $st === 413) return 'The message is too large for Microsoft to send.';
        return 'Microsoft couldn\'t ' . $doing . ' for ' . $who . ' (' . ($code !== '' ? $code : 'error ' . $st) . ')' . ($msg !== '' ? ': ' . mb_substr($msg, 0, 200) : '') . '.';
    }

    /** The token endpoint: [access_token, refresh_token, expires_at]. */
    private static function token(array $grant, string $who): array
    {
        if (!self::ready()) throw new RuntimeException('Sign in with Microsoft isn\'t set up yet: MS_MAIL_CLIENT_ID and MS_MAIL_CLIENT_SECRET are missing from .env.');
        $form = http_build_query($grant + ['client_id' => self::env('MS_MAIL_CLIENT_ID'), 'client_secret' => self::env('MS_MAIL_CLIENT_SECRET'), 'scope' => self::SCOPES], '', '&');
        [$st, $raw] = self::http('POST', self::LOGIN . 'token', ['Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'], $form, 'Mail: Microsoft sign-in');
        $r = json_decode($raw, true);
        $r = is_array($r) ? $r : [];
        if ($st === 200 && (string) ($r['access_token'] ?? '') !== '') {
            return ['access_token' => (string) $r['access_token'], 'refresh_token' => (string) ($r['refresh_token'] ?? ''), 'expires_at' => time() + max(60, (int) ($r['expires_in'] ?? 3600))];
        }
        $err = (string) ($r['error'] ?? '');
        $desc = (string) ($r['error_description'] ?? '');
        if ($st === 0) throw new RuntimeException('Microsoft\'s sign-in didn\'t answer: it will be tried again.');
        if ($err === 'invalid_grant' || $err === 'interaction_required') {
            throw new RuntimeException($grant['grant_type'] === 'refresh_token'
                ? 'Microsoft\'s sign-in for ' . ($who ?: 'this mailbox') . ' expired: reconnect it.'
                : 'Microsoft\'s sign-in code was used or expired: sign in with Microsoft again.');
        }
        if ($err === 'invalid_client' || $err === 'unauthorized_client') throw new RuntimeException('Microsoft refused Traversence\'s app keys (MS_MAIL_CLIENT_ID / MS_MAIL_CLIENT_SECRET in .env): the secret may have expired.');
        if ($err === 'consent_required') throw new RuntimeException('Mail access for ' . ($who ?: 'this account') . ' needs its organization\'s administrator to approve Traversence.');
        $line = strtok($desc, "\r\n");
        throw new RuntimeException('Microsoft\'s sign-in refused (' . ($err !== '' ? $err : 'error ' . $st) . ')' . ($line ? ': ' . mb_substr((string) $line, 0, 200) : '') . '.');
    }

    /** A Graph request: [status, decoded body]. */
    private static function call(string $method, string $path, string $access, ?array $body = null): array
    {
        $h = ['Authorization: Bearer ' . $access, 'Accept: application/json', 'Prefer: IdType="ImmutableId"'];
        $payload = null;
        if ($body !== null) { $h[] = 'Content-Type: application/json'; $payload = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); }
        [$st, $raw] = self::http($method, self::GRAPH . $path, $h, $payload, 'Mail: Microsoft ' . strtolower($method) . ' ' . (string) strtok($path, '?'));
        $r = $raw === '' ? [] : json_decode($raw, true);
        return [$st, is_array($r) ? $r : []];
    }

    /** Through StagingGate first, then curl (25 s). [status (0 when nothing came back), body]. */
    private static function http(string $method, string $url, array $headers, ?string $body, string $what): array
    {
        if (!class_exists('StagingGate')) require_once __DIR__ . '/StagingGate.php';
        if (($w = StagingGate::hold(strtok($url, '?') ?: $url, $what)) !== null) throw new RuntimeException($w);
        if (self::$http !== null) {
            $r = (self::$http)($method, $url, $headers, $body);
            return [(int) $r[0], (string) $r[1]];
        }
        $ch = curl_init($url);
        $opt = [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_FOLLOWLOCATION => false];
        if ($body !== null) $opt[CURLOPT_POSTFIELDS] = $body;
        curl_setopt_array($ch, $opt);
        $raw = curl_exec($ch);
        $st = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$raw === false ? 0 : $st, is_string($raw) ? $raw : ''];
    }

    private static function env(string $k): string { return trim((string) (getenv($k) ?: '')); }
}
