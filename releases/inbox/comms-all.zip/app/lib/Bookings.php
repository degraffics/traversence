<?php
// app/lib/Bookings.php — bookings and rentals reaching people (decisions/0172 §2.5, §6 step 7). A booking is a
// Marketplace order (market_orders) whose line is a stay ('booking': check-in and check-out dates, guests) or a rental
// ('rental': pick-up and return days), as KindCheckout made it. This library tells people about them; it never changes
// an order's money: what it shows in Pulse acts only through the order's own steps (MarketCheckout).
//
//   reminders  Bookings::remind (the booking_remind job, every 15 minutes): 24 hours before (booking.tomorrow, Notice)
//              and 2 hours before (booking.soon, Urgent), to the customer, each once (Notify's thing
//              'booking:<order>:24h'). A stay starts at its check-in time (the item's "Check-in from", as the guest was
//              shown it) on its first day; a rental, and a stay whose check-in time can't be read, has a day and no hour:
//              its 24-hour reminder goes at 9 am the day before, and there's no 2-hour one. A customer whose account is
//              gone is emailed at the order's address (system email: they're the business's customer), noted on the order.
//   changes    Bookings::changed: the other side is told, Urgent. By the customer → the business's team (biz.booking);
//              by the business or the system → the customer (booking.changed), and the system's to the business too.
//              Today that's the customer cancelling before paying (MarketCheckout::cancel) and an unpaid booking
//              released when its hold ran out (MarketCheckout::tick). The business has no way yet to change or cancel a
//              Marketplace booking here; when it does, it calls changed($o, 'business', …).
//   bodies     pulseBody for the four kinds: the booking read live (dates, nights, guests, the place, where it stands)
//              and its own steps where they exist: the customer's Cancel while it's unpaid; the order's page.
declare(strict_types=1);

require_once __DIR__ . '/CommsBody.php';

final class Bookings
{
    public const ENDPOINT = '/api/booking-act.php';
    /** A stay or rental with no hour: its 24-hour reminder goes at this hour the day before. */
    private const DAY_HOUR = 9;

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /** The order's stay or rental: [kind, title, item_id, from, to, nights, guests] or null. */
    public static function of(array $o): ?array
    {
        $lines = $o['lines'] ?? (json_decode((string) ($o['order_lines'] ?? ''), true) ?: []);
        foreach ((array) $lines as $l) {
            $k = (string) ($l['kind'] ?? '');
            if (($k === 'booking' || $k === 'rental') && !empty($l['kx']['from'])) {
                return ['kind' => $k, 'title' => (string) ($l['title'] ?? ''), 'item_id' => (int) ($l['item_id'] ?? 0), 'from' => (string) $l['kx']['from'], 'to' => (string) ($l['kx']['to'] ?? ''),
                        'n' => (int) ($l['qty'] ?? 1), 'guests' => (int) ($l['kx']['guests'] ?? 0)];
            }
        }
        return null;
    }

    /** When it starts: [unix time, has an hour]. A stay at its check-in time; otherwise the day only. */
    public static function startsAt(PDO $pdo, array $b): array
    {
        $day = strtotime($b['from'] . ' 00:00:00');
        if ($b['kind'] === 'booking' && $b['item_id'] > 0) {
            try {
                require_once __DIR__ . '/MarketBiz.php'; require_once __DIR__ . '/ItemKinds.php';
                $it = MarketBiz::get($pdo, $b['item_id']);
                $in = $it ? trim((string) (ItemKinds::data('booking', $it['kind_data'] ?? null)['checkin'] ?? '')) : '';
                $in = trim((string) preg_replace('/^(from|after|at)\s+/i', '', $in));
                if ($in !== '' && preg_match('/\d/', $in) && ($t = strtotime($b['from'] . ' ' . $in)) && date('Y-m-d', $t) === $b['from']) return [$t, true];
            } catch (Throwable $x) { error_log('booking check-in time: ' . $x->getMessage()); }
        }
        return [$day, false];
    }

    /** The orders that hold their dates: paid, or waiting for a direct payment within its hold. */
    private static function holding(array $o): bool
    {
        return $o['status'] === 'paid' || ($o['status'] === 'awaiting' && strtotime((string) $o['hold_until']) > time());
    }

    /**
     * The booking_remind job (every 15 minutes): each reminder once, when it's due. Returns how many went.
     * $now: for the tests.
     */
    public static function remind(PDO $pdo, ?int $now = null): int
    {
        $now = $now ?? time();
        try { $pdo->query('SELECT 1 FROM market_orders LIMIT 0'); } catch (Throwable) { return 0; }
        $sent = 0;
        foreach ([0, 1, 2] as $d) {   // stays and rentals starting today, tomorrow or the day after
            $day = date('Y-m-d', $now + $d * 86400);
            $st = $pdo->prepare("SELECT * FROM market_orders WHERE status IN ('paid','awaiting') AND order_lines LIKE ? AND (order_lines LIKE ? OR order_lines LIKE ?) LIMIT 500");
            $st->execute(['%"from":"' . $day . '"%', '%"kind":"booking"%', '%"kind":"rental"%']);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $o) {
                try {
                    if (!self::holding($o) || !($b = self::of($o)) || $b['from'] !== $day) continue;
                    [$t, $timed] = self::startsAt($pdo, $b);
                    if ($now >= $t) continue;   // it has started
                    $at24 = $timed ? $t - 86400 : strtotime($day . ' 00:00:00') - 86400 + self::DAY_HOUR * 3600;
                    $placed = strtotime((string) $o['created_at']);
                    if ($timed && $now >= $t - 7200) { if ($placed < $t - 7200) $sent += self::tell($pdo, $o, $b, '2h', $t, $timed); }
                    elseif ($now >= $at24 && $placed < $at24) $sent += self::tell($pdo, $o, $b, '24h', $t, $timed);   // booked after that moment: they know
                } catch (Throwable $x) { error_log('booking reminder ' . ($o['id'] ?? '?') . ': ' . $x->getMessage()); }
            }
        }
        return $sent;
    }

    /** One reminder to the customer: their Pulse, or (no account now) an email to the order's address. */
    private static function tell(PDO $pdo, array $o, array $b, string $which, int $t, bool $timed): int
    {
        $biz = self::bizName($pdo, (int) $o['entity_id']);
        $stay = $b['kind'] === 'booking';
        $when = $timed ? date('g:i A', $t) : '';
        $title = $which === '2h'
            ? ($stay ? 'Check-in at ' . $biz . ' at ' . $when . ' today' : 'Your rental from ' . $biz . ' starts at ' . $when)
            : ($stay ? 'Your stay at ' . $biz . ' is tomorrow' : 'Your rental from ' . $biz . ' is tomorrow');
        $body = self::plainLine($b) . ($timed ? ($stay ? ' Check-in from ' . $when . '.' : '') : '');
        $url = '/market/order.php?t=' . $o['token'];
        $buyer = (int) $o['buyer_id'];
        $live = false;
        if ($buyer > 0) { $st = $pdo->prepare('SELECT 1 FROM users WHERE id = ? AND is_suspended = 0'); $st->execute([$buyer]); $live = $st->fetchColumn() !== false; }
        if ($live) {
            require_once __DIR__ . '/Notify.php';
            return Notify::send($pdo, $which === '2h' ? 'booking.soon' : 'booking.tomorrow', ['users' => [$buyer]],
                ['thing' => 'booking:' . (int) $o['id'] . ':' . $which, 'url' => $url, 'from' => ['entity', (int) $o['entity_id'], $biz]], ['title' => $title, 'body' => $body]);
        }
        $mark = 'Reminder emailed (' . ($which === '2h' ? '2 h' : '24 h') . ')';
        if (trim((string) $o['email']) === '' || str_contains((string) $o['note'], $mark)) return 0;
        try {
            require_once __DIR__ . '/Mailer.php';
            Mailer::send((string) $o['email'], $title, 'Hi ' . (trim((string) $o['name']) ?: 'there') . ",\n\n" . $body . "\n\nYour order: https://traversence.com" . $url . "\n\nTraversence", (string) $o['name']);
            $pdo->prepare('UPDATE market_orders SET note = CONCAT(note, ?) WHERE id = ?')->execute([' [' . date('M j') . '] ' . $mark . '.', (int) $o['id']]);
            return 1;
        } catch (Throwable $x) { error_log('booking reminder email ' . $o['id'] . ': ' . $x->getMessage()); return 0; }
    }

    /**
     * A booking changed or was cancelled: the other side is told (Urgent). $by: customer | business | system. $what: a
     * short past-tense line ("cancelled before paying", "released: the payment didn't arrive by Dec 2"). Returns how many
     * people were told.
     */
    public static function changed(PDO $pdo, array $o, string $by, string $what): int
    {
        $b = self::of($o);
        if (!$b) return 0;
        require_once __DIR__ . '/Notify.php';
        $biz = self::bizName($pdo, (int) $o['entity_id']);
        $who = trim((string) $o['name']) !== '' ? trim((string) $o['name']) : 'The customer';
        $thing = 'booking:' . (int) $o['id'] . ':' . substr(sha1($by . '|' . $what), 0, 10);
        $n = 0;
        if ($by === 'customer' || $by === 'system') {
            $n += Notify::send($pdo, 'biz.booking', ['entity' => (int) $o['entity_id'], 'except' => [(int) $o['buyer_id']]],
                ['thing' => $thing, 'thread' => 'booking:' . (int) $o['id'], 'url' => '/business/' . (int) $o['entity_id'] . '/quotes', 'from' => $by === 'customer' ? ['user', (int) $o['buyer_id'], $who] : ['system', null, 'Traversence']],
                ['title' => 'Order #' . (int) $o['id'] . ($by === 'customer' ? ': ' . $who . ' ' : ': ') . $what, 'body' => self::plainLine($b)]);
        }
        if ($by === 'business' || $by === 'system') {
            $n += Notify::send($pdo, 'booking.changed', ['users' => [(int) $o['buyer_id']]],
                ['thing' => $thing, 'thread' => 'booking:' . (int) $o['id'], 'url' => '/market/order.php?t=' . $o['token'], 'from' => ['entity', (int) $o['entity_id'], $biz]],
                ['title' => ($b['kind'] === 'booking' ? 'Your stay at ' : 'Your rental from ') . $biz . ': ' . $what, 'body' => self::plainLine($b)]);
        }
        return $n;
    }

    /** "Cabin (Dec 2 to Dec 4, 2 nights) · 2 guests." */
    private static function plainLine(array $b): string
    {
        return self::dates($b) . ($b['guests'] > 0 ? ' · ' . $b['guests'] . ($b['guests'] === 1 ? ' guest' : ' guests') : '') . '.';
    }

    private static function dates(array $b): string
    {
        $f = strtotime($b['from']); $t = strtotime($b['to']);
        $what = preg_replace('/\s*\([^)]*\)\s*$/', '', $b['title']);
        return $what . ': ' . date('D M j', $f) . ($t ? ' to ' . date('D M j', $t) : '') . ', ' . $b['n'] . ($b['kind'] === 'booking' ? ' night' : ' day') . ($b['n'] === 1 ? '' : 's');
    }

    private static function bizName(PDO $pdo, int $e): string
    {
        $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([$e]);
        return (string) ($st->fetchColumn() ?: 'the business');
    }

    /** The order a message is about, from its thing ('booking:12:24h'). */
    public static function orderOf(array $m): int
    {
        return preg_match('/^booking:(\d+):/', (string) ($m['thing'] ?? ''), $x) ? (int) $x[1] : 0;
    }

    /** Pulse's body for booking.tomorrow, booking.soon, booking.changed and biz.booking: ['html', 'state']. */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        require_once __DIR__ . '/MarketCheckout.php';
        $o = MarketCheckout::get($pdo, self::orderOf($m));
        $b = $o ? self::of($o) : null;
        if (!$o || !$b) return ['html' => CommsBody::wrap(CommsBody::status('This booking isn\'t on Traversence any more.', 'info', 'Gone:')), 'state' => 'Gone'];
        $mine = (int) $o['buyer_id'] === $viewer;
        $team = !$mine && MarketCheckout::onOrderTeam($pdo, $viewer, $o);
        if (!$mine && !$team) return ['html' => CommsBody::wrap(CommsBody::status('This booking is between the customer and the business.', 'info')), 'state' => 'Not yours to see'];
        $stay = $b['kind'] === 'booking';
        [$t, $timed] = self::startsAt($pdo, $b);
        $biz = self::bizName($pdo, (int) $o['entity_id']);
        $status = MarketCheckout::STATUSES[$o['status']] ?? ucfirst((string) $o['status']);
        $h = CommsBody::facts([
            $stay ? 'Stay' : 'Rental' => preg_replace('/\s*\([^)]*\)\s*$/', '', $b['title']),
            'Where' => $biz,
            $stay ? 'Check-in' : 'Pick up' => date('D M j, Y', strtotime($b['from'])) . ($timed ? ', from ' . date('g:i A', $t) : ''),
            $stay ? 'Check-out' : 'Return' => $b['to'] !== '' ? date('D M j, Y', strtotime($b['to'])) : '',
            $stay ? 'Nights' : 'Days' => (string) $b['n'],
            'Guests' => $stay && $b['guests'] > 0 ? (string) $b['guests'] : '',
            'For' => $team ? (trim((string) $o['name']) ?: 'The customer') : '',
            'Order' => '#' . (int) $o['id'] . ' · ' . $status . ' · ' . MarketCheckout::money((int) $o['total_cents']),
        ]);
        $ended = in_array($o['status'], ['cancelled', 'expired', 'refunded'], true);
        $past = time() >= $t;
        if ($ended) {
            $state = $status . ' ' . date('M j', strtotime((string) $o['updated_at']));
            $h .= '<p data-tv-status="info" data-tv-label="' . CommsBody::e($status) . ':">' . ($o['status'] === 'expired' ? 'The hold ran out before the payment arrived, so the dates were released' : 'It isn\'t going ahead')
                . ' (' . CommsBody::time((string) $o['updated_at']) . ').</p>';
        } elseif ($o['status'] === 'awaiting' || $o['status'] === 'pending') {
            $state = 'Waiting for payment · held until ' . date('M j', strtotime((string) $o['hold_until']));
            $h .= CommsBody::status($mine ? MarketCheckout::instructions($pdo, $o) : 'Waiting for the customer\'s payment. The dates are held until ' . date('M j', strtotime((string) $o['hold_until'])) . '.', 'info', 'Waiting:');
        } else {
            $state = $past ? ($stay ? 'Under way or done' : 'Picked up or done') : ($stay ? 'Booked · check-in ' : 'Booked · pick up ') . date('M j', $t) . ($timed ? ' ' . date('g:i A', $t) : '');
        }
        $acts = [];
        if ($mine) {
            $acts[] = '<a class="tv-btn" href="/market/order.php?t=' . CommsBody::e((string) $o['token']) . '" data-peek-frame>Your order</a>';
            if (in_array($o['status'], ['pending', 'awaiting'], true)) $acts[] = CommsBody::button('Cancel it', self::ENDPOINT, ['act' => 'cancel', 'order' => (int) $o['id'], 'msg' => (int) ($m['id'] ?? 0)], ['confirm' => 'Cancel this booking? The dates are released for others.', 'yes' => 'Cancel it', 'danger' => true]);
            elseif ($o['status'] === 'paid' && !$past) $acts[] = '<small class="tv-mb-why">It\'s paid: to change or cancel it, write to ' . CommsBody::e($biz) . ' from Your order.</small>';
        } else {
            $acts[] = '<a class="tv-btn" href="/business/' . (int) $o['entity_id'] . '/quotes" data-peek-frame>Open the order</a>';
        }
        $h .= CommsBody::acts($acts);
        return ['html' => CommsBody::wrap($h), 'state' => $state];
    }

    /** A button in the body: [message, new html or '']. Only the customer's Cancel (unpaid), through MarketCheckout::cancel. */
    public static function act(PDO $pdo, int $uid, array $b): array
    {
        require_once __DIR__ . '/MarketCheckout.php';
        $o = MarketCheckout::get($pdo, (int) ($b['order'] ?? 0));
        if (!$o || !self::of($o)) throw new InvalidArgumentException('That booking isn\'t on Traversence any more.');
        if ((string) ($b['act'] ?? '') !== 'cancel') throw new InvalidArgumentException('Unknown action.');
        MarketCheckout::cancel($pdo, $uid, $o);   // checks it's theirs and unpaid; tells the business
        $m = CommsBody::message($pdo, (int) ($b['msg'] ?? 0), $uid);
        return ['Cancelled. The dates are released, and ' . self::bizName($pdo, (int) $o['entity_id']) . ' is told.', $m ? self::pulseBody($pdo, $m, $uid)['html'] : ''];
    }
}
