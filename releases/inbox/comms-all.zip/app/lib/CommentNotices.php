<?php
// app/lib/CommentNotices.php — what a comment's message carries (decisions/0172 §2.3, §6 step 7): the bodies Pulse draws
// for biz.comment (a comment on a business's listing), comment.reply (a reply to my comment) and content.comment (a
// comment on something I made), and what their buttons do (/api/comment-act.php).
//
// Each body shows the comment itself, the one it answers, the replies so far and where it is, read live; then its own
// actions: Reply (posted as the person; on a listing, a team member's comments are named with the business: there's no
// separate "as the business" comment), Hide and Show it again (the listing's Owner and Managers, and our staff:
// Engage::canHide), and Report (the site's one report process: Reports::file, to our Reports). Acting never moves the
// message; the body is drawn again with where it stands now.
declare(strict_types=1);

require_once __DIR__ . '/CommsBody.php';
require_once __DIR__ . '/Engage.php';

final class CommentNotices
{
    public const ENDPOINT = '/api/comment-act.php';

    /** The comment a message is about: its id from the message's thing ('comment:12', 'reply:12'). */
    public static function commentOf(array $m): int
    {
        return preg_match('/^(?:comment|reply):(\d+)$/', (string) ($m['thing'] ?? ''), $x) ? (int) $x[1] : 0;
    }

    /** Pulse's body for biz.comment, comment.reply and content.comment: ['html', 'state']. */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        require_once __DIR__ . '/People.php';
        $c = Engage::getComment($pdo, self::commentOf($m));
        if (!$c) return ['html' => CommsBody::wrap(CommsBody::status('Its writer deleted this comment, so there\'s nothing to answer now.', 'info', 'Deleted:')), 'state' => 'Deleted by its writer'];
        $msg = (int) ($m['id'] ?? 0);
        $name = fn (int $u) => ($p = People::user($pdo, $u)) ? People::name($p) : 'Someone who left';
        [$where, $url] = self::where($pdo, $c);
        $h = '<p>On <a href="' . CommsBody::e($url) . '#comments" data-peek-frame>' . CommsBody::e($where) . '</a></p>';
        $top = $c['parent_id'] > 0 ? Engage::getComment($pdo, $c['parent_id']) : null;
        if ($top) $h .= CommsBody::quote($top['user_id'] === $viewer ? 'You' : $name($top['user_id']), $top['created_at'], $top['body'], $top['status'] === 'hidden' ? 'Hidden' : '');
        $h .= '<div' . ($top ? ' class="tv-mb-sub"' : '') . '>' . CommsBody::quote($name($c['user_id']), $c['created_at'], $c['body'], $c['status'] === 'hidden' ? 'Hidden' : '') . '</div>';
        $thread = $top ?: $c;
        $later = array_values(array_filter(Engage::replies($pdo, $thread['id']), fn ($r) => (int) $r['id'] !== $c['id'] && strtotime((string) $r['created_at']) >= strtotime($c['created_at'])));
        if ($later) {
            $h .= '<details><summary>' . count($later) . ' ' . (count($later) === 1 ? 'reply' : 'replies') . ' since</summary>';
            foreach ($later as $r) $h .= '<div class="tv-mb-sub">' . CommsBody::quote((int) $r['user_id'] === $viewer ? 'You' : (string) $r['name'], (string) $r['created_at'], (string) $r['body']) . '</div>';
            $h .= '</details>';
        }

        // where it stands now
        if ($c['status'] === 'hidden') {
            $by = $c['hidden_by'] === $viewer && $viewer > 0 ? 'you' : ($c['hidden_by'] > 0 && $c['kind'] === 'listing' && Engage::teamRole($pdo, $c['hidden_by'], (int) $c['ref']) !== null ? $name($c['hidden_by']) : 'our team');
            $state = 'Hidden by ' . $by . ($c['hidden_at'] !== '' ? ' ' . date('M j, g:i A', strtotime($c['hidden_at'])) : '');
            $h .= '<p data-tv-status="info" data-tv-label="Hidden:">Hidden by ' . CommsBody::e($by) . ($c['hidden_at'] !== '' ? ' ' . CommsBody::time($c['hidden_at']) : '') . '. It isn\'t shown on the page.</p>';
        } elseif ($top && $top['status'] !== 'visible') {
            $state = 'The comment it answers is hidden';
            $h .= CommsBody::status('The comment it answers is hidden, so the conversation isn\'t shown on the page.', 'info', 'Hidden:');
        } else {
            $n = count(Engage::replies($pdo, $thread['id'], 100));
            $state = 'Shown on the page' . ($n ? ' · ' . $n . ' ' . ($n === 1 ? 'reply' : 'replies') : ' · no replies yet');
        }
        $reported = self::reportedBy($pdo, $viewer, $c['id']);
        if ($reported) $state .= ' · you reported it';

        // its actions
        $acts = [];
        [$canHide, $whyNot] = Engage::canHide($pdo, $viewer, $c);
        $showHide = $m['kind'] === 'biz.comment' || Engage::canTidy($pdo, $viewer);
        if ($showHide) {
            if ($c['status'] === 'hidden') $acts[] = CommsBody::button('Show it again', self::ENDPOINT, ['act' => 'show', 'comment' => $c['id'], 'msg' => $msg], $canHide ? [] : ['off' => $whyNot]);
            else $acts[] = CommsBody::button('Hide', self::ENDPOINT, ['act' => 'hide', 'comment' => $c['id'], 'msg' => $msg], $canHide ? ['confirm' => 'Hide this comment from the page? You can show it again here.', 'yes' => 'Hide it', 'danger' => true] : ['off' => $whyNot]);
        }
        $h .= CommsBody::acts($acts);
        $open = $c['status'] === 'visible' && (!$top || $top['status'] === 'visible');
        if ($open) {
            $age = '';
            require_once __DIR__ . '/AgeGate.php';
            try { if (!AgeGate::confirmed($pdo, $viewer)) $age = '<label><input type="checkbox" name="age" value="1" required> I am 18 or older</label>'; } catch (Throwable) {}
            $team = $c['kind'] === 'listing' && Engage::teamRole($pdo, $viewer, (int) $c['ref']) !== null;
            $h .= CommsBody::reply(self::ENDPOINT, ['act' => 'reply', 'comment' => $thread['id'], 'msg' => $msg],
                $team ? 'Reply in public, as yourself, named with ' . $where : 'Reply in public', 'Reply', 2000, $age);
        }
        if ($c['status'] === 'visible' && $c['user_id'] !== $viewer && !$reported) $h .= self::reportForm($c['id'], $msg);
        return ['html' => CommsBody::wrap($h), 'state' => $state];
    }

    /** The report box: the site's reasons (Reports::REASONS) and a note, to our Reports. */
    private static function reportForm(int $id, int $msg): string
    {
        require_once __DIR__ . '/Reports.php';
        $o = '';
        foreach (Reports::REASONS as $k => $label) $o .= '<option value="' . CommsBody::e($k) . '">' . CommsBody::e($label) . '</option>';
        return '<details><summary>Report it</summary><form class="tv-mb-reply" data-msg-reply="' . self::ENDPOINT . '" data-msg-body=\'' . json_encode(['act' => 'report', 'comment' => $id, 'msg' => $msg], JSON_HEX_APOS | JSON_HEX_TAG | JSON_HEX_AMP) . '\'>'
            . '<label>Why<select name="reason">' . $o . '</select></label><textarea name="body" data-spell maxlength="500" rows="2" placeholder="Anything our team should know (optional)"></textarea>'
            . '<button type="submit" class="tv-btn">Send report</button></form></details>';
    }

    /** Whether this person has reported this comment already. */
    private static function reportedBy(PDO $pdo, int $uid, int $id): bool
    {
        try { $st = $pdo->prepare("SELECT 1 FROM content_reports WHERE reporter_id = ? AND kind = 'content_comment' AND target_id = ?"); $st->execute([$uid, $id]); return $st->fetchColumn() !== false; }
        catch (Throwable) { return false; }
    }

    /** Where the comment is: [name, path]. */
    private static function where(PDO $pdo, array $c): array
    {
        $url = Engage::pageUrl($pdo, $c['kind'], $c['ref']);
        try {
            $sql = ['listing' => 'SELECT name FROM entities WHERE id = ?', 'exp' => 'SELECT title FROM experiences WHERE id = ?'][$c['kind']] ?? null;
            if ($sql) { $st = $pdo->prepare($sql); $st->execute([(int) $c['ref']]); $n = (string) $st->fetchColumn(); if ($n !== '') return [$n, $url]; }
        } catch (Throwable) {}
        return [['listing' => 'the listing', 'exp' => 'the experience', 'guide' => 'the guide', 'sj' => 'the journey', 'place' => 'the place', 'lm' => 'the landmark', 'rec' => 'the place'][$c['kind']] ?? 'the page', $url];
    }

    /**
     * A button or reply box in the body was used: [message, new html or ''] or an InvalidArgumentException with what's
     * wrong. $b: act (reply|hide|show|report), comment, msg (the message it was pressed in), body, reason, age.
     */
    public static function act(PDO $pdo, int $uid, array $b): array
    {
        $c = Engage::getComment($pdo, (int) ($b['comment'] ?? 0));
        if (!$c) throw new InvalidArgumentException('That comment was deleted by its writer.');
        switch ((string) ($b['act'] ?? '')) {
            case 'reply':
                if (!empty($b['age'])) { require_once __DIR__ . '/AgeGate.php'; AgeGate::confirm($pdo, $uid); }
                Engage::comment($pdo, $uid, $c['kind'], $c['ref'], (string) ($b['body'] ?? ''), $c['id']);
                $said = 'Replied. It\'s on the page now.';
                break;
            case 'hide':
            case 'show':
                [$ok, $why] = Engage::canHide($pdo, $uid, $c);
                if (!$ok) throw new InvalidArgumentException($why);
                $hide = $b['act'] === 'hide';
                if (($c['status'] === 'hidden') === $hide) { $said = $hide ? 'It was hidden already.' : 'It\'s shown already.'; break; }
                Engage::setCommentHidden($pdo, $c['id'], $hide, $uid);
                $said = $hide ? 'Hidden. It isn\'t shown on the page; Show it again brings it back.' : 'Shown on the page again.';
                break;
            case 'report':
                require_once __DIR__ . '/Reports.php';
                Reports::file($pdo, $uid, 'content_comment', $c['id'], (string) ($b['reason'] ?? 'other'), (string) ($b['body'] ?? ($b['note'] ?? '')));
                $said = 'Thank you. Our team will look at it.';
                break;
            default:
                throw new InvalidArgumentException('Unknown action.');
        }
        $m = CommsBody::message($pdo, (int) ($b['msg'] ?? 0), $uid);
        return [$said, $m ? self::pulseBody($pdo, $m, $uid)['html'] : ''];
    }
}
