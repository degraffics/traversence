<?php
// app/lib/MailMime.php — reads and writes email messages for outside mailboxes in Pulse (decisions/0172 §4.7, on 0167's
// email engine): parse() turns a raw message (from IMAP, POP or SES) into the parts Pulse shows (who, subject, date, the
// text and HTML, the attachments' names and where they are), safeHtml() makes a message's HTML safe to draw in a page
// (no scripts, no tracking pictures until the person asks), snippet() the first words for a list, build() a raw message
// for sending through the mailbox's own SMTP and for saving in its Sent folder, threadKey() which conversation a message
// belongs to. Pure PHP: no IMAP or mailparse extension (Bluehost's PHP may not have them), nothing reached outside.
declare(strict_types=1);

final class MailMime
{
    /** What a held picture shows until the person chooses "Show pictures": a transparent pixel, sized by the page. */
    public const HELD_PICTURE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

    /** Elements removed with everything inside them. */
    private const DROP = ['script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'form', 'input', 'button',
        'select', 'textarea', 'link', 'meta', 'base', 'svg', 'math', 'template', 'noscript', 'title', 'head', 'audio', 'video', 'source', 'track', 'portal'];

    /** Attributes that hold a URL. */
    private const URL_ATTRS = ['href', 'src', 'action', 'formaction', 'background', 'poster', 'cite', 'longdesc', 'lowsrc', 'dynsrc', 'xlink:href', 'usemap', 'ping'];

    // ---- reading ------------------------------------------------------------------------------------------------------

    /**
     * A raw message as Pulse uses it: message_id, in_reply_to, references [], from [addr, name], to / cc / reply_to
     * [[addr, name] …], subject, date (unix time, 0 when none), text, html, attachments [[name, type, size, part, cid]].
     * Attachment bodies aren't kept: part() pulls one by its part path when the person opens it.
     */
    public static function parse(string $raw): array
    {
        [$head, $body] = self::split($raw);
        $h = self::headers($head);
        $out = [
            'message_id' => self::firstId(self::h($h, 'message-id')),
            'in_reply_to' => self::firstId(self::h($h, 'in-reply-to')),
            'references' => self::ids(self::h($h, 'references')),
            'from' => self::addresses(self::h($h, 'from'))[0] ?? ['addr' => '', 'name' => ''],
            'to' => self::addresses(self::h($h, 'to')),
            'cc' => self::addresses(self::h($h, 'cc')),
            'reply_to' => self::addresses(self::h($h, 'reply-to')),
            'subject' => trim(self::decodeHeader(self::h($h, 'subject'))),
            'date' => self::date(self::h($h, 'date')),
            'text' => '',
            'html' => '',
            'attachments' => [],
        ];
        if ($out['date'] === 0) {   // no Date: the newest Received line's time, if any
            foreach ($h['received'] ?? [] as $r) { $p = strrpos($r, ';'); if ($p !== false && ($t = self::date(substr($r, $p + 1))) > 0) { $out['date'] = $t; break; } }
        }
        $texts = []; $htmls = [];
        self::walk($h, $body, '', $texts, $htmls, $out['attachments'], false);
        $out['text'] = trim(implode("\n\n", $texts));
        $out['html'] = trim(implode("\n<hr>\n", $htmls));
        if ($out['text'] === '' && $out['html'] !== '') $out['text'] = self::htmlToText($out['html']);
        return $out;
    }

    /** One part of a raw message by its path ('1.2'), decoded: [type, name, data]. Throws when the message has no such part. */
    public static function part(string $raw, string $path): array
    {
        [$head, $body] = self::split($raw);
        $h = self::headers($head);
        $want = $path === '' ? [] : explode('.', $path);
        while (true) {
            [$type, $params] = self::contentType($h);
            if (str_starts_with($type, 'multipart/') && $want) {
                $parts = self::multipart($body, (string) ($params['boundary'] ?? ''));
                $i = (int) array_shift($want);
                if (!isset($parts[$i - 1])) break;
                [$head, $body] = self::split($parts[$i - 1]);
                $h = self::headers($head);
                continue;
            }
            if ($want && $want !== ['1']) break;   // a single part is '1'
            return ['type' => $type, 'name' => self::fileName($h, $params), 'data' => self::decodeBody($body, self::h($h, 'content-transfer-encoding'))];
        }
        throw new RuntimeException('That attachment isn\'t in the message any more.');
    }

    /** The first meaningful words of a message's text, quoted replies ("> …", "On … wrote:") and signatures left out. */
    public static function snippet(string $text, int $len = 200): string
    {
        $keep = [];
        foreach (preg_split('/\R/u', $text) ?: [] as $line) {
            $t = trim($line);
            if ($t === '' || $t[0] === '>') continue;
            if (preg_match('/^(On\b.{0,200}\bwrote:|Le\b.{0,200}\ba écrit\s*:|Am\b.{0,200}\bschrieb\b.*:|El\b.{0,200}\bescribió:)$/iu', $t)) break;
            if (preg_match('/^(-{2,}\s*(Original|Forwarded) Message\s*-{2,}|_{8,}|From:\s.+@.+|Sent from my \w+|--)$/iu', $t)) break;
            $keep[] = $t;
            if (mb_strlen(implode(' ', $keep)) > $len) break;
        }
        $s = preg_replace('/\s+/u', ' ', implode(' ', $keep)) ?? '';
        if (mb_strlen($s) <= $len) return $s;
        $cut = mb_substr($s, 0, $len);
        $sp = mb_strrpos($cut, ' ');
        if ($sp !== false && $sp > $len * 0.6) $cut = mb_substr($cut, 0, $sp);
        return rtrim($cut, " ,.;:-") . '…';
    }

    /**
     * Which conversation a message belongs to: a sha1 of the first id in References, else In-Reply-To, else its own
     * Message-ID (so an original and every reply to it share a key); with no ids, its subject without Re:/Fwd: and the
     * two addresses. Works on parse()'s result or MsGraphMail's.
     */
    public static function threadKey(array $parsed): string
    {
        $refs = array_values(array_filter((array) ($parsed['references'] ?? []), 'strlen'));
        $id = $refs[0] ?? (($parsed['in_reply_to'] ?? '') !== '' ? $parsed['in_reply_to'] : (string) ($parsed['message_id'] ?? ''));
        $id = trim((string) $id, " \t<>");
        if ($id !== '') return sha1('id:' . $id);
        $subj = self::baseSubject((string) ($parsed['subject'] ?? ''));
        $a = strtolower((string) ($parsed['from']['addr'] ?? ''));
        $b = strtolower((string) ($parsed['to'][0]['addr'] ?? ''));
        $pair = [$a, $b]; sort($pair);
        return sha1('subject:' . $subj . '|' . implode('|', $pair));
    }

    /** A subject without its Re:, Fwd:, AW:, SV:, [list] tags and the like, lower-case, for grouping. */
    public static function baseSubject(string $s): string
    {
        $s = trim($s);
        do {
            $before = $s;
            $s = preg_replace('/^\s*((re|fw|fwd|aw|wg|sv|vs|tr|rif|r|odp|antw|antwort|ynt|res|enc)(\[\d+\]|\(\d+\))?\s*[:：]|\[[^\]]{1,40}\])\s*/iu', '', $s) ?? $s;
        } while ($s !== $before);
        return mb_strtolower(preg_replace('/\s+/u', ' ', trim($s)) ?? $s);
    }

    // ---- showing ------------------------------------------------------------------------------------------------------

    /**
     * A message's HTML made safe to draw inside a page: scripts, styles, frames, forms and the like removed with what's
     * inside them, every on… attribute gone, javascript:/vbscript:/data: links removed, links open in a new tab without
     * telling the sender, outside pictures held (the original kept in data-held-src, shown when the person chooses
     * "Show pictures", i.e. $pictures) so opening a message doesn't tell the sender it was read; cid: pictures become
     * data-cid for the page to fill from the attachment. Returns only what goes inside <body>.
     */
    public static function safeHtml(string $html, bool $pictures = false): string
    {
        if (trim($html) === '') return '';
        if (preg_match('/<body\b[^>]*>(.*)<\/body\s*>/is', $html, $m)) $html = $m[1];
        elseif (preg_match('/<body\b[^>]*>(.*)$/is', $html, $m)) $html = $m[1];
        $html = preg_replace('/<head\b.*?<\/head\s*>/is', '', $html) ?? '';
        $html = preg_replace('/<\/?(html|body)\b[^>]*>/i', '', $html) ?? '';
        if (!mb_check_encoding($html, 'UTF-8')) $html = mb_convert_encoding($html, 'UTF-8', 'UTF-8');

        $doc = new DOMDocument('1.0', 'UTF-8');
        $prev = libxml_use_internal_errors(true);
        $ok = $doc->loadHTML('<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body><div id="tv-mail-root">'
            . $html . '</div></body></html>', LIBXML_NONET | LIBXML_COMPACT);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        if (!$ok) return nl2br(htmlspecialchars(self::htmlToText($html), ENT_QUOTES, 'UTF-8'));
        $root = $doc->getElementById('tv-mail-root');
        if ($root === null) return '';

        $xp = new DOMXPath($doc);
        $junk = $xp->query('.//comment() | .//processing-instruction()', $root);
        if ($junk !== false) foreach (iterator_to_array($junk) as $n) { if ($n->parentNode !== null) $n->parentNode->removeChild($n); }
        $all = iterator_to_array($root->getElementsByTagName('*'));
        foreach ($all as $el) {
            /** @var DOMElement $el */
            if ($el->parentNode === null || !self::attached($el, $root)) continue;
            $tag = strtolower($el->localName ?? $el->nodeName);
            if (in_array($tag, self::DROP, true) || str_contains($tag, ':')) { $el->parentNode->removeChild($el); continue; }
            self::cleanAttributes($el, $tag, $pictures);
        }
        $out = '';
        foreach (iterator_to_array($root->childNodes) as $n) $out .= $doc->saveHTML($n);
        return trim($out);
    }

    /** Plain text from HTML: paragraphs and line breaks kept, tags and entities gone. */
    public static function htmlToText(string $html): string
    {
        $s = preg_replace('/<(script|style|head|title)\b.*?<\/\1\s*>/is', '', $html) ?? $html;
        $s = preg_replace('/<br\s*\/?>/i', "\n", $s) ?? $s;
        $s = preg_replace('/<\/(p|div|tr|li|h[1-6]|blockquote|table|section|article)\s*>/i', "\n", $s) ?? $s;
        $s = preg_replace('/<li\b[^>]*>/i', '• ', $s) ?? $s;
        $s = strip_tags($s);
        $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $s = str_replace("\u{00A0}", ' ', $s);
        $s = preg_replace('/[ \t]+/u', ' ', $s) ?? $s;
        $s = preg_replace('/ *\n */', "\n", $s) ?? $s;
        $s = preg_replace('/\n{3,}/', "\n\n", $s) ?? $s;
        return trim($s);
    }

    // ---- writing ------------------------------------------------------------------------------------------------------

    /**
     * A raw RFC 5322 message, CRLF line endings, for SMTP (the caller dot-escapes) and IMAP APPEND. $m: from [addr, name]
     * (or addr / name at the top), to [[addr, name] …], cc, reply_to, subject, text, html (both → multipart/alternative),
     * attachments [[name, type, data] …] (→ multipart/mixed), in_reply_to, references [], message_id (made from the
     * sender's domain when absent), date (unix time; now when absent).
     */
    public static function build(array $m): string
    {
        $from = isset($m['from']) && is_array($m['from']) ? $m['from'] : ['addr' => (string) ($m['addr'] ?? ''), 'name' => (string) ($m['name'] ?? '')];
        $fromAddr = trim((string) ($from['addr'] ?? $from[0] ?? ''));
        if ($fromAddr === '' || !str_contains($fromAddr, '@')) throw new InvalidArgumentException('A message needs the address it\'s sent from.');
        $domain = substr($fromAddr, strrpos($fromAddr, '@') + 1);
        $mid = trim((string) ($m['message_id'] ?? ''), " <>");
        if ($mid === '') $mid = bin2hex(random_bytes(16)) . '@' . $domain;
        $date = (int) ($m['date'] ?? 0) ?: time();

        $hd = [];
        $hd[] = 'Date: ' . date('D, d M Y H:i:s O', $date);
        $hd[] = 'From: ' . self::formatAddress($fromAddr, (string) ($from['name'] ?? $from[1] ?? ''));
        foreach (['to' => 'To', 'cc' => 'Cc', 'reply_to' => 'Reply-To'] as $k => $name) {
            $list = self::addrList($m[$k] ?? []);
            if ($list) $hd[] = $name . ': ' . implode(",\r\n ", $list);
        }
        $hd[] = 'Subject: ' . self::encodeHeader((string) ($m['subject'] ?? ''), 9);
        $hd[] = 'Message-ID: <' . $mid . '>';
        $irt = trim((string) ($m['in_reply_to'] ?? ''), " <>");
        if ($irt !== '') $hd[] = 'In-Reply-To: <' . $irt . '>';
        $refs = array_values(array_filter(array_map(fn ($r) => trim((string) $r, " <>"), (array) ($m['references'] ?? [])), 'strlen'));
        if ($irt !== '' && !in_array($irt, $refs, true)) $refs[] = $irt;
        if ($refs) $hd[] = 'References: ' . implode("\r\n ", array_map(fn ($r) => '<' . $r . '>', $refs));
        $hd[] = 'MIME-Version: 1.0';

        $text = self::crlf((string) ($m['text'] ?? ''));
        $html = (string) ($m['html'] ?? '');
        if ($text === '' && $html !== '') $text = self::crlf(self::htmlToText($html));
        $leaf = fn (string $type, string $body) => ['Content-Type: ' . $type . '; charset=UTF-8', 'Content-Transfer-Encoding: base64', rtrim(chunk_split(base64_encode($body), 76, "\r\n"))];
        $main = $html !== ''
            ? self::multipartOf('alternative', [$leaf('text/plain', $text), $leaf('text/html', self::crlf($html))])
            : $leaf('text/plain', $text);
        $atts = (array) ($m['attachments'] ?? []);
        if ($atts) {
            $parts = [$main];
            foreach ($atts as $a) {
                $name = (string) ($a['name'] ?? 'attachment');
                $type = (string) ($a['type'] ?? '') ?: 'application/octet-stream';
                $enc = preg_match('/[^\x20-\x7E]|"/', $name) ? "filename*=UTF-8''" . rawurlencode($name) : 'filename="' . $name . '"';
                $parts[] = ['Content-Type: ' . $type . '; name="' . self::encodeHeader(str_replace('"', '', $name), 0) . '"',
                    'Content-Disposition: attachment; ' . $enc, 'Content-Transfer-Encoding: base64',
                    rtrim(chunk_split(base64_encode((string) ($a['data'] ?? '')), 76, "\r\n"))];
            }
            $main = self::multipartOf('mixed', $parts);
        }
        $body = array_pop($main);
        return implode("\r\n", array_merge($hd, $main)) . "\r\n\r\n" . $body . "\r\n";
    }

    /** "Name" <addr> with the name encoded when it isn't plain ASCII. */
    public static function formatAddress(string $addr, string $name = ''): string
    {
        $addr = trim($addr);
        $name = trim(str_replace(["\r", "\n"], ' ', $name));
        if ($name === '' || strcasecmp($name, $addr) === 0) return $addr;
        if (preg_match('/[^\x20-\x7E]/', $name)) return self::encodeHeader($name, 0) . ' <' . $addr . '>';
        return '"' . addcslashes($name, '"\\') . '" <' . $addr . '>';
    }

    /** RFC 2047 B-encoding for a header that isn't plain ASCII, in words of at most 75 characters, folded. */
    public static function encodeHeader(string $s, int $used = 0): string
    {
        $s = str_replace(["\r", "\n"], ' ', $s);
        if (!preg_match('/[^\x20-\x7E]/', $s)) return $s;
        if (!mb_check_encoding($s, 'UTF-8')) $s = mb_convert_encoding($s, 'UTF-8', 'ISO-8859-1');
        // each line ≤ 78: a word of n bytes is 4·⌈n/3⌉ + 12 characters, after the header's name on the first line, a space on the rest
        $words = []; $chunk = '';
        $limit = max(3, intdiv(66 - $used, 4) * 3);
        foreach (mb_str_split($s, 1, 'UTF-8') as $ch) {
            if ($chunk !== '' && strlen($chunk . $ch) > $limit) { $words[] = $chunk; $chunk = ''; $limit = 48; }
            $chunk .= $ch;
        }
        if ($chunk !== '') $words[] = $chunk;
        return implode("\r\n ", array_map(fn ($w) => '=?UTF-8?B?' . base64_encode($w) . '?=', $words));
    }

    // ---- inside: the structure ----------------------------------------------------------------------------------------

    /** Header block and body, split at the first blank line (CRLF or LF). */
    private static function split(string $raw): array
    {
        $raw = ltrim($raw, "\r\n");
        if (preg_match('/\r?\n\r?\n/', $raw, $m, PREG_OFFSET_CAPTURE)) {
            $p = $m[0][1];
            return [substr($raw, 0, $p), substr($raw, $p + strlen($m[0][0]))];
        }
        // no blank line: all headers when it looks like headers, else all body
        return preg_match('/^[\x21-\x39\x3B-\x7E]+:/', $raw) ? [$raw, ''] : ['', $raw];
    }

    /** Headers by lower-case name, each a list of unfolded raw values. */
    private static function headers(string $head): array
    {
        $out = [];
        $head = preg_replace('/\r?\n[ \t]+/', ' ', $head) ?? $head;   // unfold
        foreach (preg_split('/\r?\n/', $head) ?: [] as $line) {
            $p = strpos($line, ':');
            if ($p === false || $p === 0) continue;
            $name = strtolower(trim(substr($line, 0, $p)));
            if ($name === '' || preg_match('/\s/', $name)) continue;
            $out[$name][] = trim(substr($line, $p + 1));
        }
        return $out;
    }

    private static function h(array $h, string $name): string { return (string) ($h[$name][0] ?? ''); }

    /** Content-Type's type (lower-case, text/plain when absent) and its parameters, RFC 2231 continuations joined. */
    private static function contentType(array $h): array
    {
        $v = self::h($h, 'content-type');
        if ($v === '') return ['text/plain', ['charset' => 'us-ascii']];
        $parts = self::params($v);
        $type = strtolower(trim((string) array_shift($parts)));
        if (!preg_match('#^[a-z0-9.+_-]+/[a-z0-9.+_-]+$#', $type)) $type = $type === 'text' ? 'text/plain' : 'application/octet-stream';
        return [$type, $parts];
    }

    /** "value; a=1; b="two"" → [0 => value, a => 1, b => two], with RFC 2231 (name*=, name*0*=) decoded. */
    private static function params(string $v): array
    {
        $out = [];
        $pieces = []; $cur = ''; $q = false;
        for ($i = 0, $n = strlen($v); $i < $n; $i++) {
            $c = $v[$i];
            if ($c === '\\' && $q && $i + 1 < $n) { $cur .= $c . $v[++$i]; continue; }
            if ($c === '"') $q = !$q;
            if ($c === ';' && !$q) { $pieces[] = $cur; $cur = ''; continue; }
            $cur .= $c;
        }
        $pieces[] = $cur;
        $out[0] = trim((string) array_shift($pieces));
        $cont = [];
        foreach ($pieces as $p) {
            $e = strpos($p, '=');
            if ($e === false) continue;
            $k = strtolower(trim(substr($p, 0, $e)));
            $val = trim(substr($p, $e + 1));
            if (strlen($val) >= 2 && $val[0] === '"' && substr($val, -1) === '"') $val = stripcslashes(substr($val, 1, -1));
            if (preg_match('/^([^*]+)\*(\d+)?(\*)?$/', $k, $m)) {   // RFC 2231
                $cont[$m[1]][(int) ($m[2] ?? 0)] = [$val, isset($m[3]) || ($m[2] ?? '') === ''];
                continue;
            }
            $out[$k] = $val;
        }
        foreach ($cont as $k => $segs) {
            ksort($segs);
            $charset = ''; $s = '';
            foreach ($segs as $i => [$val, $enc]) {
                if ($enc) {
                    if ($i === 0 && preg_match("/^([^']*)'[^']*'(.*)$/s", $val, $m)) { $charset = $m[1]; $val = $m[2]; }
                    $val = rawurldecode($val);
                }
                $s .= $val;
            }
            $out[$k] = self::toUtf8($s, $charset !== '' ? $charset : 'utf-8');
        }
        return $out;
    }

    /** The parts of a multipart body, between its boundaries (preamble and epilogue dropped). */
    private static function multipart(string $body, string $boundary): array
    {
        if ($boundary === '') return [$body];
        $parts = preg_split('/(?:^|\r?\n)--' . preg_quote($boundary, '/') . '(--|)[ \t]*(?=\r?\n|$)/', $body, -1, PREG_SPLIT_DELIM_CAPTURE) ?: [];
        // [preamble, (close?), part1, (close?), part2, …]: a close marker '--' ends the list
        $out = [];
        for ($i = 1, $n = count($parts); $i < $n; $i += 2) {
            if (($parts[$i] ?? '') === '--') break;
            if (!isset($parts[$i + 1])) break;
            $out[] = preg_replace('/^\r?\n/', '', $parts[$i + 1]) ?? $parts[$i + 1];
        }
        if (!$out && count($parts) === 1) return [$body];   // a boundary that never appears: the whole body as one part
        return $out;
    }

    /** Walks a part: texts and HTMLs in order; everything else an attachment (its metadata only). */
    private static function walk(array $h, string $body, string $path, array &$texts, array &$htmls, array &$atts, bool $inAlt): void
    {
        [$type, $params] = self::contentType($h);
        if (str_starts_with($type, 'multipart/')) {
            $parts = self::multipart($body, (string) ($params['boundary'] ?? ''));
            if ($type === 'multipart/alternative') {
                // the richest version that's shown: the last HTML for html, the last plain for text
                $t = []; $x = []; $before = count($atts);
                foreach ($parts as $i => $p) {
                    [$ph, $pb] = self::split($p);
                    $tt = []; $hh = [];
                    self::walk(self::headers($ph), $pb, ltrim($path . '.' . ($i + 1), '.'), $tt, $hh, $atts, true);
                    if ($tt) $t = $tt;
                    if ($hh) $x = $hh;
                }
                array_push($texts, ...$t);
                array_push($htmls, ...$x);
                return;
            }
            foreach ($parts as $i => $p) {
                [$ph, $pb] = self::split($p);
                self::walk(self::headers($ph), $pb, ltrim($path . '.' . ($i + 1), '.'), $texts, $htmls, $atts, $inAlt);
            }
            return;
        }
        $path = $path === '' ? '1' : $path;
        $disp = self::params(self::h($h, 'content-disposition'));
        $isAttach = strtolower((string) ($disp[0] ?? '')) === 'attachment';
        $name = self::fileName($h, $params);
        $cid = trim(self::h($h, 'content-id'), " <>");
        if (!$isAttach && ($type === 'text/plain' || $type === 'text/html') && $name === '') {
            $s = self::toUtf8(self::decodeBody($body, self::h($h, 'content-transfer-encoding')), (string) ($params['charset'] ?? ''));
            if ($type === 'text/plain') {
                if (strtolower((string) ($params['format'] ?? '')) === 'flowed') $s = self::unflow($s, strtolower((string) ($params['delsp'] ?? '')) === 'yes');
                $texts[] = str_replace("\r\n", "\n", $s);
            } else {
                $htmls[] = $s;
            }
            return;
        }
        if ($type === 'message/rfc822' && $name === '') {
            [$eh] = self::split($body);
            $sub = trim(self::decodeHeader(self::h(self::headers($eh), 'subject')));
            $name = ($sub !== '' ? preg_replace('/[\\\\\/:*?"<>|]+/', ' ', $sub) : 'message') . '.eml';
        }
        if ($name === '') $name = ($cid !== '' ? 'inline' : 'attachment') . '-' . str_replace('.', '-', $path) . self::extFor($type);
        $atts[] = ['name' => $name, 'type' => $type, 'size' => strlen(self::decodeBody($body, self::h($h, 'content-transfer-encoding'))), 'part' => $path, 'cid' => $cid];
    }

    private static function fileName(array $h, array $ctParams): string
    {
        $disp = self::params(self::h($h, 'content-disposition'));
        $n = (string) ($disp['filename'] ?? $ctParams['name'] ?? '');
        $n = trim(self::decodeHeader($n));
        return str_replace(['/', '\\', "\0"], '_', $n);
    }

    private static function extFor(string $type): string
    {
        $map = ['image/jpeg' => '.jpg', 'image/png' => '.png', 'image/gif' => '.gif', 'application/pdf' => '.pdf', 'text/calendar' => '.ics', 'message/rfc822' => '.eml', 'text/plain' => '.txt', 'text/html' => '.html'];
        return $map[$type] ?? '';
    }

    /** format=flowed (RFC 3676): soft line breaks (a line ending in a space) joined. */
    private static function unflow(string $s, bool $delsp): string
    {
        $out = '';
        foreach (preg_split('/\r?\n/', $s) ?: [] as $line) {
            if ($line !== '-- ' && substr($line, -1) === ' ') { $out .= $delsp ? substr($line, 0, -1) : $line; continue; }
            $out .= $line . "\n";
        }
        return rtrim($out, "\n");
    }

    // ---- inside: encodings --------------------------------------------------------------------------------------------

    private static function decodeBody(string $body, string $cte): string
    {
        $cte = strtolower(trim($cte));
        if ($cte === 'base64') {
            $d = base64_decode(preg_replace('/[^A-Za-z0-9+\/=]/', '', $body) ?? '', false);
            return $d === false ? '' : $d;
        }
        if ($cte === 'quoted-printable') return quoted_printable_decode(str_replace(["\r\n", "\r"], "\n", $body));
        return $body;
    }

    /** Text in a named charset → UTF-8; an unknown or wrong charset is read as Windows-1252 or cleaned, never fatal. */
    public static function toUtf8(string $s, string $charset): string
    {
        $cs = strtolower(trim($charset, " \"'"));
        $cs = ['' => '', 'us-ascii' => 'utf-8', 'ascii' => 'utf-8', 'utf8' => 'utf-8', 'latin1' => 'iso-8859-1', 'ks_c_5601-1987' => 'cp949',
               'gb2312' => 'gbk', 'x-sjis' => 'shift_jis', 'iso-8859-8-i' => 'iso-8859-8', 'cp-850' => 'cp850', 'unicode-1-1-utf-7' => 'utf-7'][$cs] ?? $cs;
        if ($cs === 'utf-8' || $cs === '') {
            if (mb_check_encoding($s, 'UTF-8')) return $s;
            $cs = 'windows-1252';   // labelled UTF-8 (or not at all) but isn't: almost always Windows-1252
        }
        if ($cs === 'iso-8859-1') $cs = 'windows-1252';   // a superset, and what senders actually mean
        $out = false;
        try {
            if (in_array(strtoupper($cs), array_map('strtoupper', mb_list_encodings()), true)) $out = @mb_convert_encoding($s, 'UTF-8', $cs);
        } catch (Throwable $e) { $out = false; }
        if (!is_string($out) && function_exists('iconv')) $out = @iconv($cs, 'UTF-8//IGNORE', $s);
        if (!is_string($out) || $out === '' && $s !== '') $out = mb_convert_encoding($s, 'UTF-8', 'UTF-8');
        return mb_check_encoding($out, 'UTF-8') ? $out : mb_convert_encoding($out, 'UTF-8', 'UTF-8');
    }

    /** A header value with its RFC 2047 encoded words (Q and B, any charset) decoded to UTF-8. */
    public static function decodeHeader(string $v): string
    {
        if (!str_contains($v, '=?')) return self::toUtf8($v, '');
        $re = '/=\?([^?*]+)(?:\*[^?]*)?\?([QqBb])\?([^?]*)\?=/';
        if (!preg_match_all($re, $v, $all, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) return self::toUtf8($v, '');
        // runs of encoded words in one charset are joined as bytes first, so a character split across two words survives;
        // whitespace between two encoded words isn't shown (RFC 2047 §6.2)
        $out = ''; $pos = 0; $run = ''; $runCs = '';
        $flush = function () use (&$out, &$run, &$runCs) { if ($run !== '') $out .= self::toUtf8($run, $runCs); $run = ''; $runCs = ''; };
        foreach ($all as $m) {
            $between = substr($v, $pos, $m[0][1] - $pos);
            if ($between !== '' && !($run !== '' && trim($between) === '')) { $flush(); $out .= self::toUtf8($between, ''); }
            $cs = strtolower($m[1][0]);
            $data = strtoupper($m[2][0]) === 'B'
                ? (string) base64_decode(str_pad($m[3][0], (int) (ceil(strlen($m[3][0]) / 4) * 4), '='))
                : quoted_printable_decode(str_replace('_', ' ', $m[3][0]));
            if ($run !== '' && $cs !== $runCs) $flush();
            $run .= $data; $runCs = $cs;
            $pos = $m[0][1] + strlen($m[0][0]);
        }
        $flush();
        return $out . self::toUtf8(substr($v, $pos), '');
    }

    // ---- inside: addresses, ids, dates --------------------------------------------------------------------------------

    /** An address header → [[addr, name] …]; groups ("team: a@x, b@y;") flattened; bad entries dropped. */
    public static function addresses(string $v): array
    {
        $v = trim($v);
        if ($v === '') return [];
        $items = []; $cur = ''; $q = false; $angle = 0; $paren = 0;
        for ($i = 0, $n = strlen($v); $i < $n; $i++) {
            $c = $v[$i];
            if ($c === '\\' && $i + 1 < $n) { $cur .= $c . $v[++$i]; continue; }
            if ($c === '"' && $paren === 0) $q = !$q;
            elseif (!$q) {
                if ($c === '<') $angle++;
                elseif ($c === '>') $angle = max(0, $angle - 1);
                elseif ($c === '(') $paren++;
                elseif ($c === ')') $paren = max(0, $paren - 1);
                elseif (($c === ',' || $c === ';') && $angle === 0 && $paren === 0) { $items[] = $cur; $cur = ''; continue; }
                elseif ($c === ':' && $angle === 0 && $paren === 0 && !str_contains($cur, '@')) { $cur = ''; continue; }   // a group's name
            }
            $cur .= $c;
        }
        $items[] = $cur;
        $out = [];
        foreach ($items as $it) {
            $it = trim($it);
            if ($it === '') continue;
            $name = ''; $addr = '';
            if (preg_match('/^(.*)<([^<>]*)>\s*(\(.*\))?\s*$/s', $it, $m)) {
                $addr = trim($m[2]); $name = trim($m[1]);
            } else {
                if (preg_match('/\(([^()]*)\)/', $it, $m)) { $name = $m[1]; $it = trim(str_replace($m[0], '', $it)); }
                $addr = $it;
            }
            $addr = trim($addr, " \t\"'");
            if (strlen($name) >= 2 && $name[0] === '"' && substr($name, -1) === '"') $name = stripcslashes(substr($name, 1, -1));
            $name = trim(self::decodeHeader($name), " \t\"'");
            if ($addr === '' || !str_contains($addr, '@')) continue;
            $out[] = ['addr' => $addr, 'name' => $name === $addr ? '' : $name];
        }
        return $out;
    }

    /** "<a@b> <c@d>" → ['a@b', 'c@d']. */
    private static function ids(string $v): array
    {
        preg_match_all('/<([^<>\s]+)>/', $v, $m);
        if ($m[1]) return array_values(array_unique($m[1]));
        $v = trim($v);
        return $v !== '' && str_contains($v, '@') && !preg_match('/\s/', $v) ? [$v] : [];
    }

    private static function firstId(string $v): string { return self::ids($v)[0] ?? ''; }

    private static function date(string $v): int
    {
        $v = trim(preg_replace('/\([^)]*\)/', '', $v) ?? $v);
        if ($v === '') return 0;
        $v = preg_replace('/\s+(UT|Z)$/i', ' +0000', $v) ?? $v;
        $t = strtotime($v);
        if ($t === false && preg_match('/\d{1,2}\s+\w{3}\s+\d{2,4}\s+\d{1,2}:\d{2}(:\d{2})?(\s+[+-]\d{4})?/', $v, $m)) $t = strtotime($m[0]);
        return $t === false || $t < 0 ? 0 : (int) $t;
    }

    // ---- inside: building ---------------------------------------------------------------------------------------------

    /** [[addr, name] …] or 'a@b' or ['a@b', …] → formatted addresses. */
    private static function addrList($v): array
    {
        if (is_string($v)) $v = self::addresses($v);
        $out = [];
        foreach ((array) $v as $a) {
            if (is_string($a)) { $a = ['addr' => $a, 'name' => '']; }
            $addr = trim((string) ($a['addr'] ?? $a[0] ?? ''));
            if ($addr === '' || preg_match('/[\r\n<>,;\s]/', $addr)) continue;
            $out[] = self::formatAddress($addr, (string) ($a['name'] ?? $a[1] ?? ''));
        }
        return $out;
    }

    /** A multipart part as [header lines …, body]. */
    private static function multipartOf(string $sub, array $parts): array
    {
        $b = '=_tv' . bin2hex(random_bytes(12));
        $body = "This is a multi-part message in MIME format.\r\n";
        foreach ($parts as $p) {
            $pb = array_pop($p);
            $body .= "\r\n--{$b}\r\n" . implode("\r\n", $p) . "\r\n\r\n" . $pb;
        }
        $body .= "\r\n--{$b}--";
        return ['Content-Type: multipart/' . $sub . '; boundary="' . $b . '"', $body];
    }

    private static function crlf(string $s): string { return str_replace(["\r\n", "\r", "\n"], ["\n", "\n", "\r\n"], $s); }

    // ---- inside: safeHtml ---------------------------------------------------------------------------------------------

    private static function attached(DOMNode $n, DOMNode $root): bool
    {
        for ($p = $n->parentNode; $p !== null; $p = $p->parentNode) if ($p === $root) return true;
        return false;
    }

    private static function cleanAttributes(DOMElement $el, string $tag, bool $pictures): void
    {
        $names = [];
        foreach (iterator_to_array($el->attributes) as $a) $names[] = $a->nodeName;
        foreach ($names as $name) {
            $ln = strtolower($name);
            $val = $el->getAttribute($name);
            if (str_starts_with($ln, 'on') || in_array($ln, ['formaction', 'srcdoc', 'xmlns', 'is', 'autofocus', 'contenteditable', 'id'], true) || str_starts_with($ln, 'xml')) { $el->removeAttribute($name); continue; }
            if ($ln === 'srcset') {
                if ($pictures && !self::badScheme($val, false)) continue;
                if (!$pictures) $el->setAttribute('data-held-srcset', $val);
                $el->removeAttribute($name); continue;
            }
            if ($ln === 'style') {
                $el->setAttribute('style', self::cleanStyle($el, $val, $pictures));
                if (trim($el->getAttribute('style')) === '') $el->removeAttribute('style');
                continue;
            }
            if (!in_array($ln, self::URL_ATTRS, true)) continue;
            $url = self::normUrl($val);
            $scheme = self::scheme($url);
            if ($tag === 'img' && $ln === 'src') {
                if ($scheme === 'cid') { $el->removeAttribute($name); $el->setAttribute('data-cid', trim(substr($url, 4), '<> ')); $el->setAttribute('src', self::HELD_PICTURE); continue; }
                if ($scheme === 'data') {
                    if ($pictures && preg_match('#^data:image/(png|gif|jpe?g|webp|bmp)[;,]#i', $url)) continue;
                    $el->setAttribute('src', self::HELD_PICTURE); continue;
                }
                if ($scheme === 'http' || $scheme === 'https' || $scheme === '' && str_starts_with($url, '//')) {
                    if ($pictures) continue;
                    $el->setAttribute('data-held-src', $val);
                    $el->setAttribute('src', self::HELD_PICTURE);
                    $el->setAttribute('class', trim($el->getAttribute('class') . ' tv-held-pic'));
                    continue;
                }
                $el->setAttribute('src', self::HELD_PICTURE); continue;
            }
            if ($ln === 'background') {
                if ($pictures && ($scheme === 'http' || $scheme === 'https')) continue;
                if ($scheme === 'http' || $scheme === 'https') $el->setAttribute('data-held-background', $val);
                $el->removeAttribute($name); continue;
            }
            if ($ln === 'href' && ($tag === 'a' || $tag === 'area')) {
                if (self::badScheme($url, false)) { $el->removeAttribute($name); continue; }
                if ($scheme === 'http' || $scheme === 'https' || str_starts_with($url, '//')) {
                    $el->setAttribute('target', '_blank');
                    $el->setAttribute('rel', 'noopener noreferrer nofollow');
                }
                continue;
            }
            if ($ln === 'cite' && !self::badScheme($url, false)) continue;
            $el->removeAttribute($name);   // any other URL attribute (src outside img, ping, usemap…) isn't needed in a message
        }
        if ($tag === 'a' && $el->hasAttribute('target') && !$el->hasAttribute('href')) $el->removeAttribute('target');
    }

    private static function normUrl(string $u): string
    {
        $u = html_entity_decode($u, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return trim(preg_replace('/[\x00-\x20\x7F]+/', '', $u) ?? '');
    }

    private static function scheme(string $url): string
    {
        return preg_match('/^([a-z][a-z0-9+.-]*):/i', $url, $m) ? strtolower($m[1]) : '';
    }

    private static function badScheme(string $url, bool $allowDataImage): bool
    {
        $s = self::scheme(self::normUrl($url));
        if ($s === '' || in_array($s, ['http', 'https', 'mailto', 'tel', 'sms', 'cid'], true)) return false;
        if ($s === 'data' && $allowDataImage && preg_match('#^data:image/(png|gif|jpe?g|webp)[;,]#i', $url)) return false;
        return true;
    }

    /** A style attribute without scripts in it (expression, behavior, javascript:) and with outside url()s held. */
    private static function cleanStyle(DOMElement $el, string $css, bool $pictures): string
    {
        $c = html_entity_decode($css, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $c = preg_replace('/\/\*.*?\*\//s', '', $c) ?? '';
        $c = preg_replace_callback('/\\\\([0-9a-f]{1,6})\s?/i', fn ($m) => mb_chr((int) hexdec($m[1]), 'UTF-8') ?: '', $c) ?? '';   // CSS escapes, so they can't hide words
        if (preg_match('/expression\s*\(|behavior\s*:|-moz-binding|javascript:|vbscript:|@import/i', $c)) return '';
        $held = [];
        $c = preg_replace_callback('/url\s*\(\s*([\'"]?)(.*?)\1\s*\)/is', function ($m) use ($pictures, &$held) {
            $u = self::normUrl($m[2]); $s = self::scheme($u);
            if (($s === 'http' || $s === 'https') && $pictures) return $m[0];
            if ($s === 'http' || $s === 'https') $held[] = $u;
            if ($s === 'data' && $pictures && preg_match('#^data:image/(png|gif|jpe?g|webp)[;,]#i', $u)) return $m[0];
            return 'none';
        }, $c) ?? '';
        if ($held) $el->setAttribute('data-held-style', $css);
        $c = preg_replace('/position\s*:\s*(fixed|absolute|sticky)/i', 'position:static', $c) ?? $c;   // a message can't cover the page
        return trim($c);
    }
}
