<?php
// app/lib/CommsCrypt.php — seals the secrets Communications keeps in the database (decisions/0172 §4.7: "stored
// encrypted, never shown back, removed by Disconnect"): a connected mailbox's app password or sign-in tokens, and the
// web push keys' private half when kept outside .env. AES-256-GCM with a key the site makes itself and writes to .env
// (COMMS_SEAL_KEY, EnvSettings::WRITE_ONLY), never shown. A sealed value is "v1:" + base64(iv | tag | ciphertext).
// Without the key (it couldn't be written), seal() throws, so nothing is ever kept in the clear.
declare(strict_types=1);

final class CommsCrypt
{
    private const KEY = 'COMMS_SEAL_KEY';

    /** The key, made and written to .env the first time it's needed. */
    private static function key(): string
    {
        $k = trim((string) (getenv(self::KEY) ?: ''));
        if ($k === '') {
            require_once __DIR__ . '/EnvSettings.php';
            $k = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
            EnvSettings::setSecret(self::KEY, $k);   // throws if .env can't be written: then nothing is sealed or kept
        }
        return hash('sha256', 'tv-comms|' . $k, true);
    }

    public static function seal(string $plain): string
    {
        $iv = random_bytes(12); $tag = '';
        $c = openssl_encrypt($plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($c === false) throw new RuntimeException('Couldn\'t seal the secret, so it wasn\'t kept.');
        return 'v1:' . base64_encode($iv . $tag . $c);
    }

    /** The plain value, or '' when it can't be opened (the key changed): the person is asked to reconnect. */
    public static function open(string $sealed): string
    {
        if (!str_starts_with($sealed, 'v1:')) return '';
        $raw = base64_decode(substr($sealed, 3), true);
        if ($raw === false || strlen($raw) < 29) return '';
        try { $p = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16)); } catch (Throwable) { return ''; }
        return $p === false ? '' : $p;
    }
}
