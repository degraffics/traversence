<?php
// app/lib/ListingMessages.php — Leave a message on an unclaimed listing (decisions/0172 §3.3, Jason 2026-11-18).
//
// A listing nobody manages offers its own data (Call, Email, Website, Directions) and Leave a message. The message is
// accepted only with a way to answer its sender: a member account, a confirmed email, or a phone (with the guest's
// say-so to give it to the business once it claims). Each message is its own record, a guest thread in guest_inquiries
// on the listing's id (members' too, with user_id), never in the session or a cookie, marked by leave_state:
//
//   confirm    a guest's email isn't confirmed yet: nothing goes until the link is pressed (48 hours, then deleted)
//   held       kept on the listing until it's claimed (no public email, Stop requests, a bounce, or after a notice)
//   queued     waiting for the next "messages are waiting" notice to the listing's email (§3.3's pace)
//   paused     the kind is paused by message control (§4.3), or the send failed: it goes when it can
//   screened   it looked like spam or abuse: held for Safety in Pulse (a report, the existing process), not sent
//   emailed    sent to the listing's public email as a visitor's request, from requests@, the reply coming back here
//   answered   the business answered by email (the email route, before any claim)
//   delivered  the listing's claim was verified: the business has it in Traversence (delivered_at set)
//
// The pace to one address (Jason): the first request goes at once; later ones queue; at 5 waiting one email says
// "5 visitors have left you messages on Traversence" (a notice, not the messages: reading needs an account); a queue
// that doesn't reach 5 gets the same notice 10 days after its oldest message. Then the count starts again.
// Protections: its own sender (requests@), screening (no attachments, links removed, a length cap, the words checked),
// one waiting message per sender per listing, the guest limits, members' 10 a day, Stop requests and Report this as
// spam in every email, bounces and complaints stopping that address (email_suppress) and the kind pausing itself when
// complaints pass 0.1% of the last 1,000 or bounces surge (CommsSetup, kind:listing.request).
// Private until delivered: nobody at Traversence reads the words (a report shows the one reported to Safety, as any
// report does); Sales sees only the count. Withdrawn and expired messages are deleted, their email with them.
declare(strict_types=1);

require_once __DIR__ . '/GuestInquiries.php';
require_once __DIR__ . '/ListingActions.php';

final class ListingMessages
{
    public const CKEY = 'kind:listing.request';   // message control's key for this kind (CommsSetup)
    public const MAIL_KIND = 'listing_request';   // its own sender (CommsSetup::prefixFor → requests@)
    public const HOLD_DAYS = 90;
    public const NOTICE_AT = 5;
    public const NOTICE_DAYS = 10;
    public const CONFIRM_HOURS = 48;
    public const MAX_LEN = 2000;
    public const MEMBER_PER_DAY = 10;
    public const KIND_LABEL = 'General inquiry';   // what it's typed as (0052 step 4)
    /** Waiting: not yet with the business in Traversence. */
    public const WAITING = ['confirm', 'held', 'queued', 'paused', 'screened', 'emailed'];
    private const SITE = 'https://traversence.com';

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM listing_requests LIMIT 0'); $pdo->query('SELECT 1 FROM listing_request_sends LIMIT 0'); $ok = GuestInquiries::leftReady($pdo); } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }
    private static function site(): string { return rtrim((string) (getenv('APP_URL') ?: self::SITE), '/'); }
    private static function key(): string { return (string) (getenv('LISTING_MSG_KEY') ?: hash('sha256', 'tv-listing-msg|' . (getenv('DB_PASSWORD') ?: '') . '|' . __DIR__)); }
    private static function sig(string $v, int $n = 16): string { return substr(hash_hmac('sha256', $v, self::key()), 0, $n); }
    private static function addrHash(string $addr): string { return hash('sha256', mb_strtolower(trim($addr))); }   // as SesMail::hash, so email_suppress agrees

    // ---- what the form says, by route ---------------------------------------------------------------------------------

    /** The route a message would take now: 'email' (the listing's public email, not stopped, not paused) or 'held'. */
    public static function routeFor(PDO $pdo, int $e): string
    {
        $mail = ListingActions::publicEmail($pdo, $e);
        return $mail !== '' && !self::suppressed($pdo, $mail) && !self::paused($pdo) ? 'email' : 'held';
    }

    /** The sender-facing words for a route (0172 §3.3, Jason's words): [before, button]. */
    public static function words(string $route): array
    {
        return $route === 'email'
            ? ['This business isn\'t on Traversence yet. We\'ll send your message to the email this listing gives, and bring any reply back here.', 'Send by email']
            : ['This business isn\'t on Traversence yet, so no one reads this here. We\'ll keep your message on this listing and deliver it only if the business claims it. For anything now, call them directly.', 'Leave it for them'];
    }

    // ---- leaving one --------------------------------------------------------------------------------------------------

    /**
     * Leaves a message. $uid: the signed-in member, or null for a guest. $in: body; a guest's nonce, answer, website
     * (the check), name (first name), answer_by (email|phone), email, phone, phone_ok.
     * Returns ['id', 'state', 'said' (the words to show), 'code' (guests: shown once)].
     */
    public static function leave(PDO $pdo, int $e, ?int $uid, array $in): array
    {
        if (!self::ready($pdo)) throw new InvalidArgumentException('Leaving a message isn\'t switched on yet. Call them instead.');
        $l = self::listing($pdo, $e);
        if (!$l) throw new InvalidArgumentException('That listing isn\'t available.');
        if ($l['status'] !== 'unclaimed' || ListingActions::managed($pdo, $e)) throw new InvalidArgumentException('This business is on Traversence now: message it from its page instead.');
        $now = self::now();
        $waiting = "'" . implode("','", self::WAITING) . "'";
        if ($uid !== null && $uid > 0) {
            if (is_file(__DIR__ . '/Standing.php')) { require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid); }   // limited accounts can't send (0079)
            $st = $pdo->prepare("SELECT 1 FROM guest_inquiries WHERE user_id = ? AND entity_id = ? AND leave_state IN ($waiting) LIMIT 1");
            $st->execute([$uid, $e]);
            if ($st->fetchColumn() !== false) throw new InvalidArgumentException('You already have a message waiting for ' . $l['name'] . '. You can leave another once it\'s answered, or withdraw it.');
            $st = $pdo->prepare('SELECT COUNT(*) FROM guest_inquiries WHERE user_id = ? AND leave_state IS NOT NULL AND created_at > ?');
            $st->execute([$uid, date('Y-m-d H:i:s', time() - 86400)]);
            if ((int) $st->fetchColumn() >= self::MEMBER_PER_DAY) throw new InvalidArgumentException('That\'s ' . self::MEMBER_PER_DAY . ' new messages today. Try again tomorrow.');
            $u = $pdo->prepare('SELECT display_name FROM users WHERE id = ?'); $u->execute([$uid]);
            $name = self::firstName((string) $u->fetchColumn()) ?: 'A member';
            [$body, $why] = self::screen((string) ($in['body'] ?? ''));
            $pdo->prepare("INSERT INTO guest_inquiries (entity_id, user_id, name, contact_type, contact, code_hash, device_hash, ip_hash, status, leave_state, guest_read_at, created_at, last_at)
                           VALUES (?, ?, ?, 'account', NULL, ?, '', '', 'open', 'held', ?, ?, ?)")
                ->execute([$e, $uid, $name, hash('sha256', 'member|' . $uid . '|' . bin2hex(random_bytes(8))), $now, $now, $now]);
            $id = (int) $pdo->lastInsertId();
            self::addMessage($pdo, $id, false, $body);
            $state = self::start($pdo, $id, $why);
            return ['id' => $id, 'state' => $state, 'said' => self::said($pdo, $id), 'code' => ''];
        }

        // a guest (0052 step 6's guest questions, with a way to answer them)
        GuestInquiries::checkForm($in);
        [$dev, $ip] = GuestInquiries::guestLimits($pdo);
        $name = self::firstName(strip_tags((string) ($in['name'] ?? '')));
        if ($name === '') throw new InvalidArgumentException('Add your first name, so they know who\'s asking.');
        $by = (string) ($in['answer_by'] ?? '');
        $email = trim((string) ($in['email'] ?? ''));
        $phone = trim((string) ($in['phone'] ?? ''));
        if ($by === 'email') {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email doesn\'t look right.');
            $contact = mb_strtolower($email);
        } elseif ($by === 'phone') {
            if (strlen(preg_replace('/\D/', '', $phone)) < 10) throw new InvalidArgumentException('Enter a 10-digit phone number.');
            if (empty($in['phone_ok'])) throw new InvalidArgumentException('Tick the box to let the business have your number once it claims its listing: it\'s the only way it can call you.');
            $contact = mb_substr($phone, 0, 40);
        } else {
            throw new InvalidArgumentException('Choose how they can answer you: by email or by phone. Without one, the message can\'t be left.');
        }
        // one waiting message per sender per listing, until it's answered: this device, or this email
        $st = $pdo->prepare("SELECT 1 FROM guest_inquiries WHERE entity_id = ? AND leave_state IN ($waiting) AND (device_hash = ? OR (contact_type = 'email' AND contact = ?)) LIMIT 1");
        $st->execute([$e, $dev, $by === 'email' ? $contact : '-']);
        if ($st->fetchColumn() !== false) throw new InvalidArgumentException('You already have a message waiting for ' . $l['name'] . '. Check it with your reply code, or withdraw it to write a new one.');
        [$body, $why] = self::screen((string) ($in['body'] ?? ''));
        [$code, $codeHash] = GuestInquiries::newCode($pdo);
        $token = bin2hex(random_bytes(16));
        $pdo->prepare('INSERT INTO guest_inquiries (entity_id, name, contact_type, contact, code_hash, device_hash, ip_hash, status, leave_state, phone_ok, confirm_hash, guest_read_at, created_at, last_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$e, $name, $by, $contact, $codeHash, $dev, $ip, 'open', $by === 'email' ? 'confirm' : 'held', $by === 'phone' ? 1 : 0,
                       $by === 'email' ? hash('sha256', $token) : null, $now, $now, $now]);
        $id = (int) $pdo->lastInsertId();
        self::addMessage($pdo, $id, false, $body);
        if ($why !== '') $pdo->prepare('UPDATE guest_inquiries SET screen_why = ? WHERE id = ?')->execute([mb_substr($why, 0, 160), $id]);
        if ($by === 'email') {
            // confirmed first (Jason agreed, 2026-11-18): nothing goes to the business until the link is pressed
            $url = self::site() . '/listing/confirm.php?t=' . $id . '.' . $token;
            self::mailSystem($contact, 'Confirm your message to ' . $l['name'],
                "Hello $name,\n\nYou left a message for {$l['name']} on Traversence. Press this link to confirm this is your email, and it goes on its way:\n$url\n\n"
                . "Nothing is sent until you do. The link works for " . self::CONFIRM_HOURS . " hours.\n\nYour reply code: $code\nKeep this code: it's the only way back to your message, on the listing's page under \"Check a reply\".\n\n"
                . "Didn't leave a message? Ignore this email and nothing happens.\n\nTraversence", $name);
            return ['id' => $id, 'state' => 'confirm', 'said' => self::said($pdo, $id), 'code' => $code];
        }
        $state = self::start($pdo, $id, $why);
        return ['id' => $id, 'state' => $state, 'said' => self::said($pdo, $id), 'code' => $code];
    }

    /** A guest's email link: confirms the address and sends the message on its route. ['entity_id', 'name', 'said'] or null. */
    public static function confirm(PDO $pdo, string $t): ?array
    {
        if (!preg_match('/^(\d+)\.([a-f0-9]{32})$/', $t, $m) || !self::ready($pdo)) return null;
        $st = $pdo->prepare("SELECT * FROM guest_inquiries WHERE id = ? AND confirm_hash = ?");
        $st->execute([(int) $m[1], hash('sha256', $m[2])]);
        $q = $st->fetch(PDO::FETCH_ASSOC);
        if (!$q) return null;
        $l = self::listing($pdo, (int) $q['entity_id']);
        if ($q['leave_state'] !== 'confirm') return ['entity_id' => (int) $q['entity_id'], 'name' => (string) ($l['name'] ?? ''), 'said' => self::said($pdo, (int) $q['id']), 'again' => true];
        if (strtotime((string) $q['created_at']) < time() - self::CONFIRM_HOURS * 3600) return null;
        $pdo->prepare("UPDATE guest_inquiries SET email_ok_at = ?, leave_state = 'held' WHERE id = ?")->execute([self::now(), (int) $q['id']]);
        self::start($pdo, (int) $q['id'], (string) ($q['screen_why'] ?? ''));
        return ['entity_id' => (int) $q['entity_id'], 'name' => (string) ($l['name'] ?? ''), 'said' => self::said($pdo, (int) $q['id']), 'again' => false];
    }

    /** A guest asks again for the confirm link, by their reply code (a lost or late email). */
    public static function resendConfirm(PDO $pdo, string $code): void
    {
        $q = GuestInquiries::byCode($pdo, $code);
        if (($q['leave_state'] ?? '') !== 'confirm') throw new InvalidArgumentException('That message doesn\'t need confirming.');
        $token = bin2hex(random_bytes(16));
        $pdo->prepare('UPDATE guest_inquiries SET confirm_hash = ?, created_at = ? WHERE id = ?')->execute([hash('sha256', $token), self::now(), (int) $q['id']]);
        $l = self::listing($pdo, (int) $q['entity_id']);
        self::mailSystem((string) $q['contact'], 'Confirm your message to ' . ($l['name'] ?? 'the business'),
            "Here's a new link to confirm your message to " . ($l['name'] ?? 'the business') . ":\n" . self::site() . '/listing/confirm.php?t=' . (int) $q['id'] . '.' . $token
            . "\n\nNothing is sent until you press it. It works for " . self::CONFIRM_HOURS . " hours.\n\nTraversence", (string) $q['name']);
    }

    /** First steps after it's accepted: screened → held for Safety; otherwise along its route. */
    private static function start(PDO $pdo, int $id, string $why): string
    {
        if ($why !== '') {
            $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'screened', screen_why = ? WHERE id = ?")->execute([mb_substr($why, 0, 160), $id]);
            if (is_file(__DIR__ . '/Reports.php')) {
                try { require_once __DIR__ . '/Reports.php'; Reports::file($pdo, 0, 'listing_message', $id, 'spam', 'Held by the screen before it went to the business: ' . $why); }
                catch (Throwable $x) { error_log('listing message screen report: ' . $x->getMessage()); }
            }
            return 'screened';
        }
        return self::route($pdo, $id);
    }

    /**
     * Sends a message along its route (§4.2): to the business's Pulse if the listing's claim is verified; else the
     * listing's public email by the pace; else held on the listing. Returns its state.
     */
    public static function route(PDO $pdo, int $id): string
    {
        $q = self::row($pdo, $id);
        if (!$q || $q['delivered_at'] !== null) return (string) ($q['leave_state'] ?? '');
        $e = (int) $q['entity_id'];
        $l = self::listing($pdo, $e);
        if ($l && $l['status'] === 'verified' && ListingActions::managed($pdo, $e)) { self::deliver($pdo, $q, $l); return 'delivered'; }
        $set = fn (string $s) => $pdo->prepare('UPDATE guest_inquiries SET leave_state = ? WHERE id = ?')->execute([$s, $id]);
        $mail = $l && $l['status'] === 'unclaimed' ? ListingActions::publicEmail($pdo, $e) : '';
        if ($mail === '' || self::suppressed($pdo, $mail)) { $set('held'); return 'held'; }
        if (self::paused($pdo)) { $set('paused'); return 'paused'; }
        $h = self::addrHash($mail);
        $st = $pdo->prepare('SELECT * FROM listing_requests WHERE entity_id = ?'); $st->execute([$e]);
        $lr = $st->fetch(PDO::FETCH_ASSOC);
        if (!$lr || $lr['addr_hash'] !== $h || $lr['first_sent_at'] === null) {
            // the first request to this address goes at once
            if (!self::sendRequest($pdo, $q, $l, $mail)) { $set('paused'); return 'paused'; }
            $pdo->prepare('INSERT INTO listing_requests (entity_id, addr_hash, first_sent_at, updated_at) VALUES (?, ?, ?, ?)
                           ON DUPLICATE KEY UPDATE addr_hash = VALUES(addr_hash), first_sent_at = VALUES(first_sent_at), last_notice_at = NULL, notices = 0, updated_at = VALUES(updated_at)')
                ->execute([$e, $h, self::now(), self::now()]);
            $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'emailed', sent_at = ? WHERE id = ?")->execute([self::now(), $id]);
            return 'emailed';
        }
        $set('queued');
        if (self::queued($pdo, $e) >= self::NOTICE_AT) self::sendNotice($pdo, $e);
        return (string) self::row($pdo, $id)['leave_state'];
    }

    private static function queued(PDO $pdo, int $e): int
    {
        $st = $pdo->prepare("SELECT COUNT(*) FROM guest_inquiries WHERE entity_id = ? AND leave_state = 'queued'"); $st->execute([$e]);
        return (int) $st->fetchColumn();
    }

    // ---- the emails to the business ------------------------------------------------------------------------------------

    /** The first request, by itself: a visitor's request, from requests@, the reply coming back through the reply address. */
    private static function sendRequest(PDO $pdo, array $q, array $l, string $to): bool
    {
        $words = self::thread($pdo, (int) $q['id']);
        $text = $words ? $words[count($words) - 1]['body'] : '';
        $sid = self::logSend($pdo, (int) $l['id'], (int) $q['id'], 'request', $to);
        $claim = self::site() . '/claim.php?listing=' . (int) $l['id'];
        $body = "Hello,\n\nA visitor on Traversence, the local guide, left a message for {$l['name']}. Traversence lists {$l['name']} from public information; "
            . "you haven't joined, so we're passing it on to the email your listing gives, as a visitor's request.\n\n"
            . "From: {$q['name']} (a visitor)\nType: " . self::KIND_LABEL . "\n\n$text\n\n"
            . "Reply to this email to answer them. Your answer reaches them through Traversence: we never share their email or phone, and they see your address only if you write it.\n\n"
            . "Claim your listing (free) to see and answer every request in Traversence: $claim\n\n" . self::footer($sid);
        return self::mailRequest($pdo, $sid, $to, 'A visitor asked about ' . $l['name'] . ' on Traversence', $body, self::replyAddress((int) $q['id']));
    }

    /** "5 visitors have left you messages on Traversence": a notice of messages waiting, not the messages (Jason). */
    private static function sendNotice(PDO $pdo, int $e): bool
    {
        $l = self::listing($pdo, $e);
        $mail = $l ? ListingActions::publicEmail($pdo, $e) : '';
        $st = $pdo->prepare("SELECT id FROM guest_inquiries WHERE entity_id = ? AND leave_state = 'queued' ORDER BY id"); $st->execute([$e]);
        $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        if (!$ids) return false;
        $hold = fn () => $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'held' WHERE id IN (" . implode(',', $ids) . ')')->execute();
        if ($mail === '' || self::suppressed($pdo, $mail)) { $hold(); return false; }
        if (self::paused($pdo)) return false;   // they wait in the queue; the next tick tries again
        $n = count($ids);
        $sid = self::logSend($pdo, $e, null, 'notice', $mail);
        $claim = self::site() . '/claim.php?listing=' . $e;
        $has = false;
        try { $u = $pdo->prepare('SELECT 1 FROM users WHERE email = ? LIMIT 1'); $u->execute([$mail]); $has = $u->fetchColumn() !== false; } catch (Throwable) {}
        $subject = $n === 1 ? 'A visitor has left you a message on Traversence' : $n . ' visitors have left you messages on Traversence';
        $body = "Hello,\n\n" . ($n === 1 ? 'A visitor has' : "$n visitors have") . " left " . ($n === 1 ? 'a message' : 'messages') . " for {$l['name']} on Traversence, the local guide. "
            . "They're waiting for you there: we don't email them one by one, and reading and answering them needs an account.\n\n"
            . "Claim your listing (free) to read and answer them: $claim\n"
            . ($has ? "This address already has a Traversence account: sign in, then claim your listing: " . self::site() . "/login.php\n" : '')
            . "\nMessages left for you are kept " . self::HOLD_DAYS . " days.\n\n" . self::footer($sid);
        if (!self::mailRequest($pdo, $sid, $mail, $subject, $body, '')) return false;
        $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'held', sent_at = COALESCE(sent_at, ?) WHERE id IN (" . implode(',', $ids) . ')')->execute([self::now()]);
        $pdo->prepare('UPDATE listing_requests SET last_notice_at = ?, notices = notices + 1, updated_at = ? WHERE entity_id = ?')->execute([self::now(), self::now(), $e]);
        return true;
    }

    private static function footer(int $sid): string
    {
        $post = trim((string) (getenv('BUSINESS_POSTAL_ADDRESS') ?: ''));
        return "Stop requests to this address: " . self::site() . '/listing/requests.php?t=' . self::token('s', $sid) . "\n"
            . "Report this as spam: " . self::site() . '/listing/requests.php?t=' . self::token('p', $sid) . "\n\nTraversence" . ($post !== '' ? "\n$post" : '') . "\n";
    }

    private static function logSend(PDO $pdo, int $e, ?int $inquiryId, string $what, string $to): int
    {
        $pdo->prepare('INSERT INTO listing_request_sends (entity_id, inquiry_id, what, addr_hash, outcome, sent_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$e, $inquiryId, $what, self::addrHash($to), 'sent', self::now()]);
        return (int) $pdo->lastInsertId();
    }

    /** Sends one email of this kind from its own sender; a failure is written on its send row and the message waits. */
    private static function mailRequest(PDO $pdo, int $sid, string $to, string $subject, string $text, string $replyTo): bool
    {
        require_once __DIR__ . '/Mailer.php';
        $prefix = self::commsSetup() ? CommsSetup::prefixFor(self::MAIL_KIND) : 'REQUESTS';
        try { Mailer::send($to, $subject, $text, null, $prefix, '', $replyTo); return true; }
        catch (Throwable $x) {
            error_log('listing request mail: ' . $x->getMessage());
            $pdo->prepare("UPDATE listing_request_sends SET outcome = 'failed' WHERE id = ?")->execute([$sid]);
            return false;
        }
    }

    /** Mail to a guest (the confirm link, an answer, delivered, expired): the system sender. */
    private static function mailSystem(string $to, string $subject, string $text, string $name = ''): bool
    {
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
        require_once __DIR__ . '/Mailer.php';
        try { Mailer::send($to, $subject, $text, $name !== '' ? $name : null); return true; }
        catch (Throwable $x) { error_log('listing message mail to a guest: ' . $x->getMessage()); return false; }
    }

    // ---- tokens in the emails: Stop requests, Report this as spam --------------------------------------------------------

    public static function token(string $what, int $sid): string { return $what . $sid . '-' . self::sig($what . '|' . $sid); }

    /** ['what' => s|p, 'send' => row, 'listing' => name] for a link from an email, or null. */
    public static function fromToken(PDO $pdo, string $t): ?array
    {
        if (!preg_match('/^([sp])(\d+)-([a-f0-9]{16})$/', $t, $m) || !hash_equals(self::sig($m[1] . '|' . $m[2]), $m[3])) return null;
        $st = $pdo->prepare('SELECT * FROM listing_request_sends WHERE id = ?'); $st->execute([(int) $m[2]]);
        $s = $st->fetch(PDO::FETCH_ASSOC);
        if (!$s) return null;
        $l = self::listing($pdo, (int) $s['entity_id']);
        return ['what' => $m[1], 'send' => $s, 'listing' => (string) ($l['name'] ?? 'this listing'), 'entity_id' => (int) $s['entity_id'],
                'stopped' => self::suppressedHash($pdo, (string) $s['addr_hash'])];
    }

    /** Stop requests to this address: nothing more is emailed there; messages are held on the listing for a claim. */
    public static function stopRequests(PDO $pdo, array $tok): void
    {
        $h = (string) $tok['send']['addr_hash'];
        $pdo->prepare("INSERT IGNORE INTO email_suppress (addr_hash, scope, reason, created_at) VALUES (?, 'requests', 'unsubscribe', ?)")->execute([$h, self::now()]);
        self::holdFor($pdo, $h);
    }

    /** Undo for Stop: requests may come again (the business changed its mind). */
    public static function resumeRequests(PDO $pdo, array $tok): void
    {
        $pdo->prepare("DELETE FROM email_suppress WHERE addr_hash = ? AND scope = 'requests' AND reason = 'unsubscribe'")->execute([(string) $tok['send']['addr_hash']]);
    }

    /**
     * Report this as spam (0052, 0137): the message goes to Safety in Pulse as a report, the same process as any other;
     * it counts as a complaint for message control. A notice (no one message) stops requests to the address instead.
     */
    public static function reportSpam(PDO $pdo, array $tok): void
    {
        $s = $tok['send'];
        $pdo->prepare("UPDATE listing_request_sends SET outcome = 'reported' WHERE id = ?")->execute([(int) $s['id']]);
        if ($s['inquiry_id'] !== null && is_file(__DIR__ . '/Reports.php')) {
            require_once __DIR__ . '/Reports.php';
            Reports::file($pdo, 0, 'listing_message', (int) $s['inquiry_id'], 'spam', 'Reported as spam from the email it was sent in, by the listing\'s address.');
        } else {
            self::stopRequests($pdo, $tok);
        }
        self::control($pdo);
    }

    // ---- bounces, complaints and message control (§4.3) ------------------------------------------------------------------

    /** A bounce to an address (Mailer's or SES's report): emails to it stop at once; its listings fall back to holding. */
    public static function bounced(PDO $pdo, string $addr): void { self::badAddress($pdo, $addr, 'bounce', 'bounced'); }

    /** A complaint (a mailbox's spam button): the same, counted as a complaint. */
    public static function complained(PDO $pdo, string $addr): void { self::badAddress($pdo, $addr, 'complaint', 'complained'); }

    private static function badAddress(PDO $pdo, string $addr, string $reason, string $outcome): void
    {
        if (!self::ready($pdo) || trim($addr) === '') return;
        $h = self::addrHash($addr);
        $pdo->prepare("INSERT IGNORE INTO email_suppress (addr_hash, scope, reason, created_at) VALUES (?, 'all', ?, ?)")->execute([$h, $reason, self::now()]);
        $st = $pdo->prepare("SELECT id FROM listing_request_sends WHERE addr_hash = ? AND outcome = 'sent' ORDER BY id DESC LIMIT 1"); $st->execute([$h]);
        if (($sid = $st->fetchColumn()) !== false) $pdo->prepare('UPDATE listing_request_sends SET outcome = ? WHERE id = ?')->execute([$outcome, (int) $sid]);
        self::holdFor($pdo, $h);
        self::control($pdo);
    }

    /** Messages waiting to be emailed to this address are held on their listings instead. */
    private static function holdFor(PDO $pdo, string $hash): void
    {
        $st = $pdo->prepare('SELECT entity_id FROM listing_requests WHERE addr_hash = ?'); $st->execute([$hash]);
        foreach (array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)) as $e)
            $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'held' WHERE entity_id = ? AND leave_state IN ('queued', 'paused')")->execute([$e]);
    }

    /**
     * Message control for this kind: complaints (and spam reports) over 0.1% of the last 1,000 sends, or a bounce surge
     * (5 of the last 100), pause the kind by itself until an owner resumes it; held messages wait meanwhile.
     */
    public static function control(PDO $pdo): bool
    {
        if (!self::commsSetup() || CommsSetup::paused($pdo, self::CKEY)) return false;
        $rows = $pdo->query('SELECT outcome FROM listing_request_sends ORDER BY id DESC LIMIT 1000')->fetchAll(PDO::FETCH_COLUMN);
        $c = count(array_filter($rows, fn ($o) => $o === 'complained' || $o === 'reported'));
        $b = count(array_filter(array_slice($rows, 0, 100), fn ($o) => $o === 'bounced'));
        $why = $c > 1 && $c / 1000 > 0.001 ? 'Complaints at ' . $c . ' of the last ' . min(1000, max(count($rows), 1)) . ' requests to unclaimed listings (the line is 0.1% of 1,000).'
             : ($b >= 5 ? 'A bounce surge: ' . $b . ' of the last ' . min(100, count($rows)) . ' requests to unclaimed listings bounced.' : '');
        if ($why === '') return false;
        CommsSetup::pause($pdo, self::CKEY, $why . ' Messages are held on their listings until an owner resumes it.', null);
        return true;
    }

    private static function paused(PDO $pdo): bool
    {
        return self::commsSetup() && CommsSetup::paused($pdo, self::CKEY);
    }

    private static function commsSetup(): bool
    {
        if (class_exists('CommsSetup')) return true;
        if (!is_file(__DIR__ . '/CommsSetup.php')) return false;
        require_once __DIR__ . '/CommsSetup.php';
        return class_exists('CommsSetup');
    }

    private static function suppressed(PDO $pdo, string $addr): bool { return self::suppressedHash($pdo, self::addrHash($addr)); }

    private static function suppressedHash(PDO $pdo, string $h): bool
    {
        try { $st = $pdo->prepare("SELECT 1 FROM email_suppress WHERE addr_hash = ? AND (scope = 'all' OR scope = 'requests') LIMIT 1"); $st->execute([$h]); return $st->fetchColumn() !== false; }
        catch (Throwable) { return false; }
    }

    // ---- the business's email reply ----------------------------------------------------------------------------------

    /** The reply address on a request: requests+r<id>-<16 hex>@traversence.com, signed so it can't be guessed. */
    public static function replyAddress(int $inquiryId): string
    {
        $domain = (string) (getenv('REQUESTS_DOMAIN') ?: 'traversence.com');
        return 'requests+r' . $inquiryId . '-' . self::sig('reply|' . $inquiryId) . '@' . $domain;
    }

    /** The message a reply address names, or 0. */
    public static function fromReplyAddress(string $addr): int
    {
        if (!preg_match('/requests\+r(\d+)-([a-f0-9]{16})@/i', $addr, $m)) return 0;
        return hash_equals(self::sig('reply|' . $m[1]), strtolower($m[2])) ? (int) $m[1] : 0;
    }

    /**
     * An email to a reply address (read from requests@'s mailbox): the business's answer, quoted text stripped, stored on
     * the sender's thread as from the business, and the sender told. $parsed: ['from' => ['addr', 'name'], 'subject',
     * 'text', 'html']. False when the address isn't ours or nothing is left once the quote is cut.
     */
    public static function emailReply(PDO $pdo, string $toAddress, array $parsed): bool
    {
        $id = self::fromReplyAddress($toAddress);
        if (!$id || !self::ready($pdo)) return false;
        $q = self::row($pdo, $id);
        if (!$q) return false;
        $text = (string) ($parsed['text'] ?? '');
        if (trim($text) === '' && ($parsed['html'] ?? '') !== '') $text = html_entity_decode(strip_tags(preg_replace('#<br\s*/?>|</p>|</div>#i', "\n", (string) $parsed['html'])), ENT_QUOTES);
        $text = self::stripQuoted($text);
        if (mb_strlen($text) < 1) return false;
        $text = mb_substr($text, 0, 4000);
        $now = self::now();
        $l = self::listing($pdo, (int) $q['entity_id']);
        $biz = (string) ($l['name'] ?? 'The business');
        if ($q['status'] === 'moved' && $q['user_id'] !== null) {   // delivered to a claimed business as a member's conversation: it joins it
            require_once __DIR__ . '/BizMessages.php';
            $typed = BizMessages::typesReady($pdo);
            $pdo->prepare('INSERT INTO business_messages (entity_id, user_id, from_business, kind, body, big, visible_at, created_at' . ($typed ? ', msg_type' : '') . ') VALUES (?, ?, 1, ?, ?, 0, ?, ?' . ($typed ? ", 'inquiry'" : '') . ')')
                ->execute([(int) $q['entity_id'], (int) $q['user_id'], 'message', $text, $now, $now]);
        } else {
            self::addMessage($pdo, $id, true, $text);
            $pdo->prepare("UPDATE guest_inquiries SET status = 'answered', last_at = ?, leave_state = CASE WHEN delivered_at IS NULL THEN 'answered' ELSE leave_state END WHERE id = ?")->execute([$now, $id]);
        }
        self::tellSender($pdo, $q, 'answered:' . substr(sha1($text), 0, 10), $biz . ' answered your message',
            $biz . " answered by email:\n\n" . mb_strimwidth($text, 0, 1500, '…'));
        return true;
    }

    /** Cuts the quoted email below an answer: "> " lines, "On … wrote:", "Original Message", a "From:" header block. */
    public static function stripQuoted(string $t): string
    {
        $t = str_replace("\r", '', $t);
        $out = [];
        foreach (explode("\n", $t) as $line) {
            if (preg_match('/^\s*>/', $line) || preg_match('/^\s*On .{3,200}wrote:\s*$/i', $line) || preg_match('/^\s*-{2,}\s*Original Message/i', $line)
                || preg_match('/^\s*_{5,}\s*$/', $line) || (preg_match('/^\s*From:\s.+/i', $line) && $out)) break;
            $out[] = $line;
        }
        return trim(implode("\n", $out));
    }

    // ---- the claim ------------------------------------------------------------------------------------------------

    /**
     * The listing's claim is verified (Claims::verify): every message waiting on it is delivered into the business's
     * Pulse as an Alert, with when it was left, and each sender is told. Screened ones stay with Safety; unconfirmed
     * guest emails wait for their link. Returns how many were delivered.
     */
    public static function claimed(PDO $pdo, int $e): int
    {
        if (!self::ready($pdo)) return 0;
        $l = self::listing($pdo, $e);
        if (!$l) return 0;
        $st = $pdo->prepare("SELECT * FROM guest_inquiries WHERE entity_id = ? AND leave_state IN ('held', 'queued', 'paused', 'emailed', 'answered') AND delivered_at IS NULL AND status <> 'moved' ORDER BY id");
        $st->execute([$e]);
        $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $q) { try { self::deliver($pdo, $q, $l); $n++; } catch (Throwable $x) { error_log('listing message delivery ' . $q['id'] . ': ' . $x->getMessage()); } }
        $pdo->prepare('DELETE FROM listing_requests WHERE entity_id = ?')->execute([$e]);
        return $n;
    }

    private static function deliver(PDO $pdo, array $q, array $l): void
    {
        $id = (int) $q['id']; $e = (int) $l['id']; $now = self::now();
        $when = date('M j, Y', strtotime((string) $q['created_at']));
        if ($q['user_id'] !== null) {
            // a member's: it becomes an ordinary conversation between them and the business, with everything said so far
            require_once __DIR__ . '/BizMessages.php';
            $uid = (int) $q['user_id'];
            $typed = BizMessages::typesReady($pdo);
            foreach (self::thread($pdo, $id) as $m) {
                $cols = 'entity_id, user_id, from_business, kind, body, big, visible_at, created_at' . ($typed ? ', msg_type' : '');
                $vals = [$e, $uid, $m['from_business'] ? 1 : 0, 'message', $m['body'], 0, $m['at'], $m['at']];
                if ($typed) $vals[] = 'inquiry';
                $pdo->prepare("INSERT INTO business_messages ($cols) VALUES (" . implode(', ', array_fill(0, count($vals), '?')) . ')')->execute($vals);
            }
            $pdo->prepare("UPDATE guest_inquiries SET status = 'moved', moved_user_id = ?, leave_state = 'delivered', delivered_at = ?, last_at = ? WHERE id = ?")->execute([$uid, $now, $now, $id]);
            $pdo->prepare('DELETE FROM guest_inquiry_messages WHERE inquiry_id = ?')->execute([$id]);
            $ref = 'bizmsg:' . $e . ':' . $uid; $from = ['user', $uid, (string) $q['name']];
        } else {
            $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'delivered', delivered_at = ?, last_at = ?, biz_read_at = NULL WHERE id = ?")->execute([$now, $now, $id]);
            $ref = 'guestq:' . $e . ':' . $id; $from = ['guest', null, $q['name'] . ' (guest)'];
        }
        try {
            require_once __DIR__ . '/Notify.php';
            Notify::send($pdo, 'listing.held', ['entity' => $e], ['thing' => 'held:' . $id, 'url' => '/user/dashboard.php#pulse', 'pulse_ref' => $ref, 'from' => $from],
                ['title' => $q['name'] . ' left ' . $l['name'] . ' a message before you claimed it', 'body' => 'Left on ' . $when . '. Read and answer it in your messages on Traversence.']);
        } catch (Throwable $x) { error_log('listing.held notify: ' . $x->getMessage()); }
        self::tellSender($pdo, $q, 'delivered', 'Your message to ' . $l['name'] . ' was delivered',
            $l['name'] . ' claimed its listing on Traversence and now has your message' . ($q['user_id'] !== null ? '. Their answer will reach your Pulse.' : '. Their answer will reach you ' . ($q['contact_type'] === 'email' ? 'by email and ' : '') . 'under your reply code.'));
    }

    /** Tells the sender: a member in their Pulse (Notify, listing.left: a Notice); a guest by email, if they gave one. */
    private static function tellSender(PDO $pdo, array $q, string $stage, string $title, string $body): void
    {
        $e = (int) $q['entity_id'];
        if ($q['user_id'] !== null) {
            try {
                require_once __DIR__ . '/Notify.php';
                $url = $stage === 'delivered' ? '/user/dashboard.php#addressbook:biz=' . $e : '/listing/view.php?id=' . $e . '#lm';   // delivered: a conversation in their inbox now
                Notify::send($pdo, 'listing.left', ['users' => [(int) $q['user_id']]], ['thing' => 'left:' . (int) $q['id'] . ':' . $stage, 'url' => $url, 'from' => ['system', null, 'Traversence']],
                    ['title' => $title, 'body' => $body]);
            } catch (Throwable $x) { error_log('listing.left notify: ' . $x->getMessage()); }
            return;
        }
        if ($q['contact_type'] === 'email' && $q['email_ok_at'] !== null && (string) $q['contact'] !== '') {
            self::mailSystem((string) $q['contact'], $title, $body . "\n\nSee it on Traversence: " . self::site() . '/listing/view.php?id=' . $e . "#lm (\"Check a reply\", with your reply code)."
                . "\n\nYou're getting this because you left this message and chose to be answered by email. Nothing else will be sent.\n\nTraversence", (string) $q['name']);
        }
    }

    // ---- the sender's side: check, follow up, withdraw ---------------------------------------------------------------

    /** Where a left message stands, for its sender (Check a reply, their Pulse). */
    public static function describe(array $q): array
    {
        $s = (string) ($q['leave_state'] ?? '');
        $delivered = ($q['delivered_at'] ?? null) !== null;
        $until = date('M j, Y', strtotime((string) $q['created_at']) + self::HOLD_DAYS * 86400);
        if ($delivered) {
            $key = ($q['status'] ?? '') === 'answered' ? 'answered' : 'delivered';
            $label = $key === 'answered' ? 'Answered' : 'Delivered';
            $note = 'The business claimed its listing and has your message in Traversence.';
        } elseif ($s === 'confirm') {
            $key = 'confirm'; $label = 'Waiting for you to confirm your email';
            $note = 'Press the link we emailed you. Nothing goes to the business until you do.';
        } elseif ($s === 'emailed') {
            $key = 'emailed'; $label = 'Sent by email';
            $note = 'Sent to the email this listing gives; they may not have joined Traversence. Any reply comes back here. Kept until ' . $until . ' if no answer comes.';
        } elseif ($s === 'answered') {
            $key = 'answered'; $label = 'Answered';
            $note = 'They answered by email. Their answer is below.';
        } else {
            $key = 'held'; $label = 'Waiting: not delivered';
            $note = match ($s) {
                'queued' => 'This business isn\'t on Traversence yet. We\'ve emailed it before, so we\'ll tell it messages are waiting here; it reads them once it claims its listing. Kept until ' . $until . '.',
                'paused' => 'Emails to businesses are paused for a while, so your message waits on the listing and goes when they resume. Kept until ' . $until . '.',
                'screened' => 'We\'re checking it before it goes; it waits on the listing meanwhile. Kept until ' . $until . '.',
                default => 'This business isn\'t on Traversence yet, so no one reads this here. We keep your message on this listing and deliver it only if the business claims it'
                    . (($q['sent_at'] ?? null) !== null ? ' (we\'ve emailed it that messages are waiting)' : '') . '. Kept until ' . $until . '. For anything now, call them directly.',
            };
        }
        return ['left' => true, 'state' => $key, 'state_label' => $label, 'state_note' => $note, 'can_withdraw' => !$delivered];
    }

    /** May the sender write more in this thread? Once it's been answered by email, or after it's delivered. */
    public static function canFollowUp(array $q): bool
    {
        return ($q['delivered_at'] ?? null) !== null || ($q['leave_state'] ?? '') === 'answered';
    }

    /** The sender writes again after an email answer: it goes to the same address, the reply address on it; else it's held. */
    public static function followUp(PDO $pdo, array $q, string $body): void
    {
        if (!self::canFollowUp($q)) throw new InvalidArgumentException('Your message is still waiting for an answer. You can withdraw it, and leave a new one.');
        $id = (int) $q['id'];
        $n = $pdo->prepare('SELECT COUNT(*) FROM guest_inquiry_messages WHERE inquiry_id = ? AND from_business = 0 AND created_at > ?');
        $n->execute([$id, date('Y-m-d H:i:s', time() - 86400)]);
        if ((int) $n->fetchColumn() >= 10) throw new InvalidArgumentException('That\'s a lot for one day. Try again tomorrow.');
        [$text, $why] = self::screen($body);
        self::addMessage($pdo, $id, false, $text);
        $pdo->prepare('UPDATE guest_inquiries SET last_at = ?, guest_read_at = ? WHERE id = ?')->execute([self::now(), self::now(), $id]);
        if (($q['delivered_at'] ?? null) !== null) return;   // delivered: GuestInquiries tells the team (it only gets here before delivery)
        $e = (int) $q['entity_id'];
        $l = self::listing($pdo, $e);
        $mail = ListingActions::publicEmail($pdo, $e);
        if ($why !== '' || $mail === '' || self::suppressed($pdo, $mail) || self::paused($pdo) || !$l) {
            $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'held' WHERE id = ?")->execute([$id]);
            if ($why !== '') self::start($pdo, $id, $why);
            return;
        }
        $sid = self::logSend($pdo, $e, $id, 'request', $mail);
        $ok = self::mailRequest($pdo, $sid, $mail, 'Re: A visitor asked about ' . $l['name'] . ' on Traversence',
            "{$q['name']} wrote again about their message to {$l['name']}:\n\n$text\n\nReply to this email to answer them.\n\nClaim your listing (free) to see and answer every request in Traversence: "
            . self::site() . '/claim.php?listing=' . $e . "\n\n" . self::footer($sid), self::replyAddress($id));
        $pdo->prepare('UPDATE guest_inquiries SET leave_state = ? WHERE id = ?')->execute([$ok ? 'emailed' : 'held', $id]);
    }

    /** The sender takes it back, any time before it's delivered: deleted with its email. $uid for a member's, $code for a guest's. */
    public static function withdraw(PDO $pdo, ?int $uid, int $id = 0, string $code = ''): void
    {
        if ($code !== '') $q = GuestInquiries::byCode($pdo, $code);
        else { $q = self::row($pdo, $id); if (!$q || (int) ($q['user_id'] ?? 0) !== (int) $uid || !$uid) throw new InvalidArgumentException('That message isn\'t yours.'); }
        if (($q['leave_state'] ?? null) === null) throw new InvalidArgumentException('That isn\'t a message left on a listing.');
        if (($q['delivered_at'] ?? null) !== null) throw new InvalidArgumentException('It was delivered already: it\'s a conversation with the business now.');
        self::delete($pdo, (int) $q['id']);
    }

    private static function delete(PDO $pdo, int $id): void
    {
        $pdo->prepare('DELETE FROM guest_inquiry_messages WHERE inquiry_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM guest_inquiries WHERE id = ?')->execute([$id]);
    }

    /**
     * A member's left messages, for their Pulse and the listing page (0172 §3.3: marked "Waiting: not delivered" or
     * "Sent by email"): newest first, [id, entity_id, listing, url, state, state_label, state_note, can_withdraw,
     * created_at, last_at, last (the last words, cut), messages (only with $entity)]. Delivered ones are ordinary
     * business conversations by then (BizMessages), so they aren't listed here.
     */
    public static function forMember(PDO $pdo, int $uid, int $entity = 0): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT g.*, e.name AS listing FROM guest_inquiries g LEFT JOIN entities e ON e.id = g.entity_id
                              WHERE g.user_id = ? AND g.leave_state IS NOT NULL AND g.status <> 'moved'" . ($entity > 0 ? ' AND g.entity_id = ' . (int) $entity : '') . ' ORDER BY g.last_at DESC LIMIT 100');
        $st->execute([$uid]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $q) {
            $msgs = self::thread($pdo, (int) $q['id']);
            $out[] = ['id' => (int) $q['id'], 'entity_id' => (int) $q['entity_id'], 'listing' => (string) $q['listing'], 'url' => '/listing/view.php?id=' . (int) $q['entity_id'] . '#lm',
                      'created_at' => (string) $q['created_at'], 'last_at' => (string) $q['last_at'],
                      'last' => $msgs ? mb_strimwidth($msgs[count($msgs) - 1]['body'], 0, 90, '…') : '', 'can_write' => self::canFollowUp($q)]
                    + self::describe($q) + ($entity > 0 ? ['messages' => $msgs] : []);
        }
        return $out;
    }

    /** A member writes again in their own left thread. */
    public static function memberFollowUp(PDO $pdo, int $uid, int $id, string $body): void
    {
        $q = self::row($pdo, $id);
        if (!$q || (int) ($q['user_id'] ?? 0) !== $uid) throw new InvalidArgumentException('That message isn\'t yours.');
        self::followUp($pdo, $q, $body);
    }

    // ---- the screen ---------------------------------------------------------------------------------------------------

    /**
     * Screened before it goes (0172 §3.3): text only (no attachments: the form takes none), links removed, a length
     * cap, and the words checked: the site's own check (ListingSafety::contentProblem), then what a message to a
     * business adds (sales spam, threats, shouting, many links). Returns [the words to keep, why it looks like spam or
     * abuse ('' when it doesn't)].
     */
    public static function screen(string $body): array
    {
        $s = trim(str_replace("\r", '', strip_tags($body)));
        if (mb_strlen($s) > self::MAX_LEN) throw new InvalidArgumentException('Keep it under ' . number_format(self::MAX_LEN) . ' characters: they\'ll answer a short message sooner.');
        $link = '~\b(?:https?://|www\.)\S+|\b[a-z0-9][a-z0-9-]{0,62}\.(?:com|net|org|io|co|biz|info|ru|cn|xyz|top|link|click|shop|online|site|app|me|ly)(?:/\S*)?\b~i';
        $why = [];
        require_once __DIR__ . '/ListingSafety.php';
        if ($p = ListingSafety::contentProblem($s)) $why[] = $p;   // the site's word check (comments, profiles, listings use it too)
        $links = preg_match_all($link, $s);
        $s = trim((string) preg_replace($link, '[link removed]', $s));
        if (mb_strlen(trim(str_replace('[link removed]', '', $s))) < 2) throw new InvalidArgumentException('Write your message first. Links are taken out, so say it in words.');
        if ($links >= 3) $why[] = $links . ' links';
        $low = mb_strtolower($s);
        foreach (['crypto', 'bitcoin', 'forex', 'casino', 'viagra', 'cialis', 'payday loan', 'seo services', 'backlink', 'guest post', 'rank your website', 'first page of google',
                  'wire transfer', 'gift card', 'western union', 'investment opportunity', 'click here', 'act now', 'limited time offer', '100% free', 'work from home'] as $w)
            if (str_contains($low, $w)) { $why[] = 'the words "' . $w . '"'; break; }
        foreach (['kill you', 'burn it down', 'i will hurt', 'you will regret', 'watch your back'] as $w)
            if (str_contains($low, $w)) { $why[] = 'a threat'; break; }
        $letters = preg_replace('/[^A-Za-z]/', '', $s);
        if (strlen($letters) >= 40 && strlen(preg_replace('/[^A-Z]/', '', $letters)) / strlen($letters) > 0.7) $why[] = 'shouting in capitals';
        if (preg_match('/(.)\1{9,}/u', $s)) $why[] = 'one character repeated';
        return [$s, implode(', ', $why)];
    }

    // ---- reports (Reports.php calls these: the abuse process of 0052 and 0137) ------------------------------------------

    /** What Safety sees for a reported or screened message: [text, author, author_id, where, hidden] or null if it's gone. */
    public static function forReport(PDO $pdo, int $id): ?array
    {
        $q = self::row($pdo, $id);
        if (!$q) return null;
        $msgs = self::thread($pdo, $id);
        $l = self::listing($pdo, (int) $q['entity_id']);
        return ['text' => implode("\n", array_map(fn ($m) => ($m['from_business'] ? 'The business' : $q['name']) . ': ' . $m['body'], array_slice($msgs, -10))) ?: '(no words left)',
                'author' => $q['user_id'] !== null ? (string) $q['name'] : $q['name'] . ' (a guest)', 'author_id' => (int) ($q['user_id'] ?? 0),
                'where' => 'Message left on ' . ($l['name'] ?? 'a listing') . ($q['screen_why'] ? ' (held by the screen: ' . $q['screen_why'] . ')' : ''),
                'group_id' => 0, 'hidden' => $q['status'] === 'spam' || $q['leave_state'] === 'screened', 'url' => '/listing/view.php?id=' . (int) $q['entity_id']];
    }

    /**
     * Safety decided (Reports::decide): remove deletes the words and marks it spam (a guest's device counts toward
     * being turned off, as guest questions do; a member's standing follows Reports' own rule); dismiss or restore lets a
     * screened message go on along its route.
     */
    public static function decided(PDO $pdo, int $id, string $what): void
    {
        $q = self::row($pdo, $id);
        if (!$q) return;
        if ($what === 'remove') {
            if ($q['user_id'] === null && (string) $q['device_hash'] !== '') {
                try { GuestInquiries::mark($pdo, (int) $q['entity_id'], $id, 'spam'); } catch (Throwable) {}
            }
            $pdo->prepare('DELETE FROM guest_inquiry_messages WHERE inquiry_id = ?')->execute([$id]);
            $pdo->prepare("UPDATE guest_inquiries SET status = 'spam', contact = NULL, leave_state = 'held' WHERE id = ?")->execute([$id]);
            return;
        }
        if ($q['leave_state'] === 'screened') {
            $pdo->prepare("UPDATE guest_inquiries SET leave_state = 'held', screen_why = NULL WHERE id = ?")->execute([$id]);
            self::route($pdo, $id);
        }
    }

    // ---- the clock -------------------------------------------------------------------------------------------------

    /**
     * The hourly job (Scheduler: listing_messages): paused ones go once the kind resumes; a queue that reached 5, or
     * whose oldest is 10 days old, gets its one notice; unconfirmed guest emails go after 48 hours; messages never
     * delivered expire at 90 days, the sender told first. Returns what it did.
     */
    public static function tick(PDO $pdo): array
    {
        $did = ['routed' => 0, 'notices' => 0, 'expired' => 0, 'unconfirmed' => 0];
        if (!self::ready($pdo)) return $did;
        if (!self::paused($pdo)) {
            foreach ($pdo->query("SELECT id FROM guest_inquiries WHERE leave_state = 'paused' ORDER BY id LIMIT 200")->fetchAll(PDO::FETCH_COLUMN) as $id) { self::route($pdo, (int) $id); $did['routed']++; }
            $old = date('Y-m-d H:i:s', time() - self::NOTICE_DAYS * 86400);
            $st = $pdo->prepare("SELECT entity_id, COUNT(*) AS n, MIN(created_at) AS oldest FROM guest_inquiries WHERE leave_state = 'queued' GROUP BY entity_id HAVING n >= ? OR oldest <= ?");
            $st->execute([self::NOTICE_AT, $old]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (self::sendNotice($pdo, (int) $r['entity_id'])) $did['notices']++;
        }
        $st = $pdo->prepare("SELECT id FROM guest_inquiries WHERE leave_state = 'confirm' AND created_at < ?");
        $st->execute([date('Y-m-d H:i:s', time() - self::CONFIRM_HOURS * 3600)]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) { self::delete($pdo, (int) $id); $did['unconfirmed']++; }
        $st = $pdo->prepare("SELECT * FROM guest_inquiries WHERE leave_state IN ('held', 'queued', 'paused', 'screened', 'emailed') AND delivered_at IS NULL AND status <> 'spam' AND created_at < ? LIMIT 500");
        $st->execute([date('Y-m-d H:i:s', time() - self::HOLD_DAYS * 86400)]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $q) {
            $l = self::listing($pdo, (int) $q['entity_id']);
            $biz = (string) ($l['name'] ?? 'the business');
            if ($q['leave_state'] === 'emailed') self::tellSender($pdo, $q, 'expired', 'No answer from ' . $biz, 'We sent your message to the email ' . $biz . '\'s listing gives, and no answer came in ' . self::HOLD_DAYS . ' days, so we\'ve deleted it. Call them, or leave another.');
            else self::tellSender($pdo, $q, 'expired', 'Your message to ' . $biz . ' wasn\'t delivered', $biz . ' didn\'t claim its listing on Traversence within ' . self::HOLD_DAYS . ' days, so your message wasn\'t delivered and we\'ve deleted it. Call them, or leave another.');
            self::delete($pdo, (int) $q['id']);
            $did['expired']++;
        }
        $pdo->prepare("DELETE FROM guest_inquiries WHERE status = 'spam' AND leave_state IS NOT NULL AND last_at < ?")->execute([date('Y-m-d H:i:s', time() - self::HOLD_DAYS * 86400)]);
        return $did;
    }

    // ---- counts, for Sales (counts only, never who or what) ----------------------------------------------------------

    /** Messages waiting on this listing for its claim (not withdrawn, expired, unconfirmed or held for Safety). */
    public static function countWaiting(PDO $pdo, int $e): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->prepare("SELECT COUNT(*) FROM guest_inquiries WHERE entity_id = ? AND leave_state IN ('held', 'queued', 'paused', 'emailed', 'answered') AND delivered_at IS NULL AND status <> 'spam'");
        $st->execute([$e]);
        return (int) $st->fetchColumn();
    }

    // ---- small helpers ------------------------------------------------------------------------------------------------

    private static function row(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM guest_inquiries WHERE id = ? AND leave_state IS NOT NULL'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private static function listing(PDO $pdo, int $e): ?array
    {
        $st = $pdo->prepare("SELECT id, name, status, is_suppressed FROM entities WHERE id = ? AND entity_type = 'merchant'");
        try { $st->execute([$e]); } catch (Throwable) { $st = $pdo->prepare('SELECT id, name, status, 0 AS is_suppressed FROM entities WHERE id = ?'); $st->execute([$e]); }
        $l = $st->fetch(PDO::FETCH_ASSOC);
        if (!$l || (int) $l['is_suppressed'] === 1) return null;
        $l['id'] = (int) $l['id']; $l['name'] = (string) $l['name']; $l['status'] = (string) $l['status'];
        return $l;
    }

    private static function addMessage(PDO $pdo, int $id, bool $fromBusiness, string $body): void
    {
        $pdo->prepare('INSERT INTO guest_inquiry_messages (inquiry_id, from_business, body, created_at) VALUES (?, ?, ?, ?)')->execute([$id, $fromBusiness ? 1 : 0, $body, self::now()]);
    }

    private static function thread(PDO $pdo, int $id): array
    {
        $st = $pdo->prepare('SELECT from_business, body, created_at FROM guest_inquiry_messages WHERE inquiry_id = ? ORDER BY id LIMIT 200');
        $st->execute([$id]);
        return array_map(fn ($m) => ['from_business' => (bool) (int) $m['from_business'], 'body' => (string) $m['body'], 'at' => (string) $m['created_at']], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    private static function firstName(string $s): string
    {
        $s = trim(preg_replace('/\s+/', ' ', $s));
        return mb_substr((string) strtok($s, ' '), 0, 40);
    }

    /** The words for the sender after they leave it, from where it now stands. */
    private static function said(PDO $pdo, int $id): string
    {
        $q = self::row($pdo, $id);
        if (!$q) return '';
        if ($q['leave_state'] === 'confirm') return 'Check your email: press the link we sent to ' . self::mask((string) $q['contact']) . '. Nothing goes to the business until you do.';
        if ($q['leave_state'] === 'emailed') return 'Sent to the email this listing gives; they may not have joined Traversence. Any reply comes back here.';
        return self::describe($q)['state_note'];
    }

    /** Never a dead end: a note to our team from a page whose link didn't work (3 a session a day; our inbox, free). */
    public static function askTeam(string $email, string $note, string $where): string
    {
        $email = trim($email);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Give us an email to answer you at.');
        $tries = array_filter((array) ($_SESSION['lm_help'] ?? []), fn ($t) => $t > time() - 86400);
        if (count($tries) >= 3) throw new InvalidArgumentException('We\'ve had your notes today. Write to ' . self::helpTo() . ' and we\'ll answer you there.');
        $tries[] = time(); $_SESSION['lm_help'] = array_values($tries);
        require_once __DIR__ . '/Mailer.php';
        try { Mailer::send(self::helpTo(), 'Help with a message left on a listing', 'From ' . $where . ".\n\nTheir note:\n" . (trim($note) !== '' ? mb_substr(trim($note), 0, 1500) : '(none)') . "\n\nReply to: $email"); }
        catch (Throwable $x) { error_log('listing message help: ' . $x->getMessage()); throw new InvalidArgumentException('That didn\'t send. Write to ' . self::helpTo() . ' instead.'); }
        return 'Sent to our team. We\'ll answer you at ' . $email . ', usually within a business day.';
    }

    public static function helpTo(): string { return (string) (getenv('SMTP_REPLY_TO') ?: 'support@traversence.com'); }

    public static function mask(string $email): string
    {
        [$u, $d] = array_pad(explode('@', $email, 2), 2, '');
        return mb_substr($u, 0, 1) . '***@' . $d;
    }
}
