<?php
// app/lib/PulseMarks.php — a person's own marks on anything in their Pulse (decisions/0172 "Flags and tags in Pulse", "The
// row's icons"): Follow up (a flag with a date: at its time the item comes back unread, as a Notice to that person, until
// it's marked complete), importance (High or Low), tags (their own words with a colour, or a team's shared tags), pinned
// (their choice; the site never pins), filed in a folder, archived. Kept per person (pulse_flags), never shown to the
// sender, never changing anything for anyone else. Assign, escalate and Done stay where they are (Pulse::mark; the
// message's own process).
// An item is named by where it lives: 'comms:<id>' (a dispatcher message), 'mail:<id>' (a connected mailbox's mail),
// 'pulse:<item key>' (an admin Pulse case), 'notice:<id>', 'biz:<entity>:<user>', 'guest:<id>' … any string up to 120.
declare(strict_types=1);

final class PulseMarks
{
    public const DUE = ['today' => 'Today', 'tomorrow' => 'Tomorrow', 'week' => 'This week', 'nextweek' => 'Next week', 'date' => 'A date', 'none' => 'No date'];
    public const COLOURS = ['#8FBCA8', '#B45309', '#92400E', '#2F6B55', '#6D28D9', '#B91C1C', '#1D4ED8', '#5C4632'];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM pulse_flags LIMIT 0'); $pdo->query('SELECT 1 FROM pulse_tags LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    private static function item(string $item): string
    {
        $item = trim($item);
        if (!preg_match('/^[a-z]{2,10}:[A-Za-z0-9:_.@-]{1,108}$/', $item)) throw new InvalidArgumentException('Not an item in Pulse.');
        return $item;
    }

    /** The marks on these items for this person: item => {flag, due, importance, tags[], pinned, folder, archived, back}. */
    public static function of(PDO $pdo, int $u, array $items): array
    {
        if (!self::ready($pdo) || !$items) return [];
        $items = array_slice(array_values(array_unique(array_map('strval', $items))), 0, 300);
        $st = $pdo->prepare('SELECT * FROM pulse_flags WHERE user_id = ? AND item IN (' . implode(',', array_fill(0, count($items), '?')) . ')');
        $st->execute(array_merge([$u], $items));
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['item']] = self::shape($r);
        return $out;
    }

    private static function shape(array $r): array
    {
        return ['flag' => (string) $r['flag_state'], 'due' => $r['due_at'], 'importance' => (string) $r['importance'], 'tags' => array_values(array_filter(array_map('intval', explode(',', (string) $r['tags'])))),
            'pinned' => (bool) $r['pinned'], 'folder' => (string) $r['folder'], 'archived' => (bool) $r['archived'], 'back' => (bool) $r['unread_again']];
    }

    /** The day a Follow up choice means, in the person's zone; 5 pm the chosen day (Outlook's way). */
    public static function dueFor(string $when, string $date, string $tz): ?string
    {
        try { $z = new DateTimeZone($tz !== '' ? $tz : date_default_timezone_get()); } catch (Throwable) { $z = new DateTimeZone('UTC'); }
        $d = new DateTimeImmutable('now', $z);
        switch ($when) {
            case 'today': $t = $d->setTime(17, 0); if ($t <= $d) $t = $d->modify('+1 hour'); break;
            case 'tomorrow': $t = $d->modify('+1 day')->setTime(9, 0); break;
            case 'week': $t = $d->modify('friday this week')->setTime(9, 0); if ($t <= $d) $t = $d->modify('+1 day')->setTime(9, 0); break;
            case 'nextweek': $t = $d->modify('monday next week')->setTime(9, 0); break;
            case 'date':
                if (!preg_match('/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2})?$/', $date)) throw new InvalidArgumentException('Choose a date.');
                $t = new DateTimeImmutable(strlen($date) === 10 ? $date . ' 09:00' : $date, $z);
                break;
            case 'none': return null;
            default: throw new InvalidArgumentException('Choose when to follow up.');
        }
        return $t->setTimezone(new DateTimeZone(date_default_timezone_get()))->format('Y-m-d H:i:s');
    }

    /**
     * Sets this person's marks on one item. $set may hold: follow (a DUE key) + date + tz; flag 'done' | 'clear';
     * importance 'high'|'low'|''; pinned; folder; archived; tags [ids]; read (clears "back").
     */
    public static function set(PDO $pdo, int $u, string $item, array $set): array
    {
        if (!self::ready($pdo)) throw new InvalidArgumentException('Flags and tags switch on once the site\'s update has run.');
        $item = self::item($item);
        $cur = self::of($pdo, $u, [$item])[$item] ?? ['flag' => '', 'due' => null, 'importance' => '', 'tags' => [], 'pinned' => false, 'folder' => '', 'archived' => false, 'back' => false];
        $said = [];
        if (isset($set['follow'])) {
            $cur['due'] = self::dueFor((string) $set['follow'], (string) ($set['date'] ?? ''), (string) ($set['tz'] ?? ''));
            $cur['flag'] = 'open'; $cur['back'] = false;
            $said[] = $cur['due'] ? 'Follow up set.' : 'Flagged, with no date.';
        }
        if (isset($set['flag'])) {
            if ($set['flag'] === 'done') { $cur['flag'] = 'done'; $cur['back'] = false; $said[] = 'Marked complete.'; }
            elseif ($set['flag'] === 'clear') { $cur['flag'] = ''; $cur['due'] = null; $cur['back'] = false; $said[] = 'Flag cleared.'; }
        }
        if (array_key_exists('importance', $set)) { $i = (string) $set['importance']; if (!in_array($i, ['', 'high', 'low'], true)) throw new InvalidArgumentException('High, Low or neither.'); $cur['importance'] = $i; $said[] = $i === '' ? 'Importance cleared.' : ucfirst($i) . ' importance.'; }
        if (array_key_exists('pinned', $set)) { $cur['pinned'] = (bool) $set['pinned']; $said[] = $cur['pinned'] ? 'Pinned in your list.' : 'Unpinned.'; }
        if (array_key_exists('folder', $set)) { $f = trim((string) $set['folder']); if (mb_strlen($f) > 60) throw new InvalidArgumentException('Keep a folder\'s name under 60 characters.'); $cur['folder'] = $f; $cur['archived'] = false; $said[] = $f === '' ? 'Back in the list.' : 'Filed in ' . $f . '.'; }
        if (array_key_exists('archived', $set)) { $cur['archived'] = (bool) $set['archived']; $said[] = $cur['archived'] ? 'Archived.' : 'Back in the list.'; }
        if (array_key_exists('tags', $set)) {
            $ids = array_values(array_unique(array_filter(array_map('intval', (array) $set['tags']))));
            $mine = array_column(self::tags($pdo, $u), 'id');
            foreach ($ids as $id) if (!in_array($id, $mine, true)) throw new InvalidArgumentException('That tag isn\'t one of yours.');
            $cur['tags'] = array_slice($ids, 0, 20); $said[] = 'Tags saved.';
        }
        if (!empty($set['read'])) $cur['back'] = false;
        if (array_key_exists('unread', $set)) $cur['back'] = (bool) $set['unread'];   // the row's ✉: unread again, by the person's choice
        $pdo->prepare('INSERT INTO pulse_flags (user_id, item, flag_state, due_at, importance, tags, pinned, folder, archived, unread_again, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE flag_state = VALUES(flag_state), due_at = VALUES(due_at), importance = VALUES(importance), tags = VALUES(tags), pinned = VALUES(pinned), folder = VALUES(folder),
                       archived = VALUES(archived), unread_again = VALUES(unread_again), came_back_at = IF(VALUES(due_at) <=> due_at, came_back_at, NULL), updated_at = VALUES(updated_at)')
            ->execute([$u, $item, $cur['flag'], $cur['due'], $cur['importance'], implode(',', $cur['tags']), $cur['pinned'] ? 1 : 0, $cur['folder'], $cur['archived'] ? 1 : 0, $cur['back'] ? 1 : 0, self::now()]);
        return ['marks' => $cur, 'message' => implode(' ', $said) ?: 'Saved.'];
    }

    /** Items this person has in a view: pinned, a folder, archived, flagged, a tag, High importance. [item => marks] */
    public static function view(PDO $pdo, int $u, string $view, string $arg = ''): array
    {
        if (!self::ready($pdo)) return [];
        $w = 'user_id = ?'; $a = [$u];
        switch ($view) {
            case 'pinned': $w .= ' AND pinned = 1'; break;
            case 'folder': $w .= ' AND folder = ?'; $a[] = $arg; break;
            case 'archived': $w .= ' AND archived = 1'; break;
            case 'flagged': $w .= " AND flag_state = 'open'"; break;
            case 'high': $w .= " AND importance = 'high'"; break;
            case 'tag': $w .= ' AND FIND_IN_SET(?, tags)'; $a[] = (string) (int) $arg; break;
            case 'hidden': $w .= " AND (archived = 1 OR folder <> '')"; break;   // what the main list leaves out
            default: throw new InvalidArgumentException('Unknown view.');
        }
        $st = $pdo->prepare("SELECT * FROM pulse_flags WHERE $w ORDER BY updated_at DESC LIMIT 500"); $st->execute($a);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['item']] = self::shape($r);
        return $out;
    }

    /** This person's folders (their own names). */
    public static function folders(PDO $pdo, int $u): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT folder, COUNT(*) AS n FROM pulse_flags WHERE user_id = ? AND folder <> '' GROUP BY folder ORDER BY folder"); $st->execute([$u]);
        return $st->fetchAll(PDO::FETCH_KEY_PAIR);
    }

    // ---- tags: a person's own, a business team's shared, our staff's shared ----------------------------------------------

    /** The scopes this person may tag with: ['user:<id>', 'entity:<id>' for each business they're on, 'staff:0' for staff]. */
    public static function scopes(PDO $pdo, int $u): array
    {
        $out = ['user:' . $u];
        try { require_once __DIR__ . '/Roles.php'; foreach (Roles::contexts($pdo, $u) as $c) if (($c['kind'] ?? '') === 'org' && isset($c['scope']['entity']) && empty($c['scope']['preview'])) $out[] = 'entity:' . (int) $c['scope']['entity']; } catch (Throwable) {}
        try { $st = $pdo->prepare("SELECT 1 FROM " . Database::t('staff_accounts') . " WHERE user_id = ? AND status = 'active'"); $st->execute([$u]); if ($st->fetchColumn()) $out[] = 'staff:0'; } catch (Throwable) {}
        return array_values(array_unique($out));
    }

    /** [{id, name, colour, scope, shared}] */
    public static function tags(PDO $pdo, int $u): array
    {
        if (!self::ready($pdo)) return [];
        $w = []; $a = [];
        foreach (self::scopes($pdo, $u) as $sc) { [$t, $i] = explode(':', $sc); $w[] = '(owner_type = ? AND owner_id = ?)'; $a[] = $t; $a[] = (int) $i; }
        $st = $pdo->prepare('SELECT id, owner_type, owner_id, name, colour FROM pulse_tags WHERE ' . implode(' OR ', $w) . ' ORDER BY owner_type <> \'user\', name'); $st->execute($a);
        return array_map(fn ($r) => ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'colour' => (string) $r['colour'], 'scope' => $r['owner_type'] . ':' . $r['owner_id'], 'shared' => $r['owner_type'] !== 'user'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function addTag(PDO $pdo, int $u, string $name, string $colour, string $scope = ''): array
    {
        if (!self::ready($pdo)) throw new InvalidArgumentException('Tags switch on once the site\'s update has run.');
        $name = trim(preg_replace('/\s+/', ' ', $name));
        if ($name === '' || mb_strlen($name) > 40) throw new InvalidArgumentException('A tag is 1 to 40 characters.');
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $colour)) $colour = self::COLOURS[0];
        $scope = $scope !== '' ? $scope : 'user:' . $u;
        if (!in_array($scope, self::scopes($pdo, $u), true)) throw new InvalidArgumentException('You can\'t add tags there.');
        [$t, $i] = explode(':', $scope);
        $pdo->prepare('INSERT INTO pulse_tags (owner_type, owner_id, name, colour, made_by, created_at) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE colour = VALUES(colour)')
            ->execute([$t, (int) $i, $name, $colour, $u, self::now()]);
        $st = $pdo->prepare('SELECT id FROM pulse_tags WHERE owner_type = ? AND owner_id = ? AND name = ?'); $st->execute([$t, (int) $i, $name]);
        return ['id' => (int) $st->fetchColumn(), 'name' => $name, 'colour' => $colour, 'scope' => $scope, 'shared' => $t !== 'user'];
    }

    /** Removes a tag (from everyone's items that carried it, for a shared one). */
    public static function deleteTag(PDO $pdo, int $u, int $id): void
    {
        $tag = null;
        foreach (self::tags($pdo, $u) as $t) if ($t['id'] === $id) $tag = $t;
        if (!$tag) throw new InvalidArgumentException('That tag isn\'t one of yours.');
        $pdo->prepare('DELETE FROM pulse_tags WHERE id = ?')->execute([$id]);
        $st = $pdo->prepare('SELECT id, tags FROM pulse_flags WHERE FIND_IN_SET(?, tags)'); $st->execute([(string) $id]);
        $up = $pdo->prepare('UPDATE pulse_flags SET tags = ? WHERE id = ?');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $up->execute([implode(',', array_diff(explode(',', (string) $r['tags']), [(string) $id])), $r['id']]);
    }

    // ---- Follow up: the job, and the message it sends ---------------------------------------------------------------------

    /** The pulse_followup job (every 10 min): flags whose time came are back on top, unread, and the person is told once. */
    public static function due(PDO $pdo, int $limit = 200): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->prepare("SELECT id, user_id, item, due_at FROM pulse_flags WHERE flag_state = 'open' AND due_at IS NOT NULL AND due_at <= ? AND came_back_at IS NULL ORDER BY due_at LIMIT " . max(1, $limit));
        $st->execute([self::now()]);
        $n = 0;
        require_once __DIR__ . '/Notify.php';
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $pdo->prepare('UPDATE pulse_flags SET came_back_at = ?, unread_again = 1, pinned = pinned WHERE id = ?')->execute([self::now(), $r['id']]);
            Notify::send($pdo, 'followup.due', ['users' => [(int) $r['user_id']]], ['thing' => 'fu:' . $r['id'] . ':' . $r['due_at'], 'url' => '/user/dashboard.php#pulse', 'from' => ['system', null, 'Pulse']],
                ['title' => 'Follow up: ' . self::label($pdo, (int) $r['user_id'], (string) $r['item']), 'body' => 'You flagged this to follow up. It\'s back on top of your Pulse, unread, until you mark it complete.']);
            $n++;
        }
        return $n;
    }

    /** A short name for an item, for the follow-up message. */
    public static function label(PDO $pdo, int $u, string $item): string
    {
        [$t, $id] = array_pad(explode(':', $item, 2), 2, '');
        try {
            if ($t === 'comms') { $st = $pdo->prepare('SELECT title FROM comms_messages WHERE id = ? AND to_user = ?'); $st->execute([(int) $id, $u]); if ($x = $st->fetchColumn()) return (string) $x; }
            if ($t === 'mail') { $st = $pdo->prepare('SELECT subject FROM comms_mail WHERE id = ?'); $st->execute([(int) $id]); if ($x = $st->fetchColumn()) return (string) $x; }
            if ($t === 'pulse') return 'case ' . $id;
        } catch (Throwable) {}
        return 'an item in your Pulse';
    }

    /** The follow-up message's body: the item, Mark complete and Clear flag in it. */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
        $id = preg_match('/^fu:(\d+):/', (string) $m['thing'], $x) ? (int) $x[1] : 0;
        $st = $pdo->prepare('SELECT * FROM pulse_flags WHERE id = ? AND user_id = ?'); $st->execute([$id, $viewer]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return ['html' => '<p>The flag was taken off.</p>', 'state' => 'Cleared'];
        $done = $r['flag_state'] !== 'open';
        $state = $done ? ($r['flag_state'] === 'done' ? 'Marked complete.' : 'Flag cleared.') : 'Still flagged.';
        $act = fn (string $label, array $set, string $cls = '') => '<button type="button" class="tv-btn' . $cls . '" data-msg-act="/user/api/marks.php" data-msg-body=\'' . $e(json_encode(['item' => $r['item'], 'set' => $set, 'from_msg' => (int) $m['id']])) . '\'>' . $e($label) . '</button>';
        $html = '<p>' . $e($m['body']) . '</p><p data-tv-status="' . ($done ? 'ok' : 'info') . '" data-tv-label="' . ($done ? 'Done:' : 'Flagged:') . '">' . $e($state) . '</p>'
              . ($done ? '' : '<p class="tv-msg-acts">' . $act('Mark complete', ['flag' => 'done']) . ' ' . $act('Tomorrow', ['follow' => 'tomorrow']) . ' ' . $act('Clear flag', ['flag' => 'clear'], ' ghost') . '</p>');
        return ['html' => $html, 'state' => $state];
    }
}
