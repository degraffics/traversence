<?php
// app/lib/GroupNotices.php — community groups reaching their people (decisions/0172 §2.8, §6 step 7).
//
// Joining a group works like Link: once joined, every new post in the group reaches the member as a notice
// (group.post, General, in Pulse; email only if they chose it for the kind), handled by their link settings: a member who
// mutes the group (a user_links row, target 'group', muted) gets none. Posts gather into one unread message per group
// (Notify's thread) instead of one each, until it's read. Blocked people's posts never reach them.
// A role's duties come as their own messages, by need to act, while the person holds the role:
//   group.join    a request to join, to whoever moderates (Community::can 'moderate'), with Accept and Decline in it
//   group.report  a post reported to the group, to whoever handles its reports (the charter: moderators, or only its
//                 owner), with Keep, Remove, and Remove the post and its author. A report of danger goes to our Safety
//                 team instead (Reports::file) and isn't sent here.
//   group.mention a member mentioned in a post (@[name](u:id)), instead of that post's group.post.
// A business's group (0102 §4c): its duties go to the business's Pulse (to_entity), to the team members whose role
// moderates there (Owner, Manager, Creator, Support) or, for reports, handles them.
// Group posts have no replies or comments yet, so "a reply to my post" has nothing to send; mentions do.
declare(strict_types=1);

require_once __DIR__ . '/CommsBody.php';
require_once __DIR__ . '/Community.php';

final class GroupNotices
{
    public const ENDPOINT = '/api/group-act.php';

    private static function plain(string $body): string
    {
        $t = class_exists('Tags') && method_exists('Tags', 'plain') ? Tags::plain($body) : (string) preg_replace('/@\[([^\]\n]{1,80})\]\([^)]*\)/u', '@$1', $body);
        return trim($t);
    }

    /** Whether this person muted the group (their link settings). */
    public static function muted(PDO $pdo, int $uid, int $gid): bool
    {
        try { $st = $pdo->prepare("SELECT muted FROM user_links WHERE user_id = ? AND target_type = 'group' AND target_id = ?"); $st->execute([$uid, (string) $gid]); return (int) $st->fetchColumn() === 1; }
        catch (Throwable) { return false; }
    }

    /** Mutes (or unmutes) a group's posts for this person: their link to it, muted. Unmuting removes the row. */
    public static function setMuted(PDO $pdo, int $uid, array $g, bool $mute): void
    {
        $gid = (int) $g['id'];
        $pdo->prepare("DELETE FROM user_links WHERE user_id = ? AND target_type = 'group' AND target_id = ?")->execute([$uid, (string) $gid]);
        if ($mute) $pdo->prepare("INSERT INTO user_links (user_id, target_type, target_id, label, url, muted) VALUES (?, 'group', ?, ?, ?, 1)")
            ->execute([$uid, (string) $gid, mb_substr((string) $g['name'], 0, 255), '/community/group.php?id=' . $gid]);
    }

    /** Who moderates the group ($duty 'moderate'), or handles its reports ($duty 'reports'): user ids. */
    public static function leaders(PDO $pdo, array $g, string $duty = 'moderate'): array
    {
        $gid = (int) $g['id'];
        $ids = [];
        $st = $pdo->prepare("SELECT user_id FROM community_group_members WHERE group_id = ? AND status = 'active' AND role IN ('owner','moderator')"); $st->execute([$gid]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $u) $ids[(int) $u] = true;
        if (($g['owner_kind'] ?? 'person') === 'listing' && (int) ($g['owner_ref'] ?? 0) > 0) {   // a business's group: its team by role (0102 §4c)
            try { require_once __DIR__ . '/Team.php'; foreach (Team::members($pdo, (int) $g['owner_ref']) as $m) $ids[(int) $m['user_id']] = true; } catch (Throwable) {}
            try { require_once __DIR__ . '/Roles.php'; foreach (Roles::team($pdo, 'org', 'entity', (string) (int) $g['owner_ref']) as $m) $ids[(int) $m['user_id']] = true; } catch (Throwable) {}
            try { $s = $pdo->prepare('SELECT owner_user_id FROM entities WHERE id = ?'); $s->execute([(int) $g['owner_ref']]); if ($o = (int) $s->fetchColumn()) $ids[$o] = true; } catch (Throwable) {}
        }
        $out = [];
        foreach (array_keys($ids) as $u) if ($duty === 'reports' ? Community::handlesReports($pdo, $gid, $u, $g) : Community::can($pdo, $gid, $u, 'moderate', $g)) $out[] = $u;
        return $out;
    }

    /** Where a duty goes: the people, and a business's group's business (its Pulse). */
    private static function to(array $g, array $ids): array
    {
        $to = ['users' => $ids];
        if (($g['owner_kind'] ?? 'person') === 'listing' && (int) ($g['owner_ref'] ?? 0) > 0) $to['entity'] = (int) $g['owner_ref'];
        return $to;
    }

    /**
     * A new post in the group (Community::post): each member is told, by their link settings; a member mentioned in it is
     * told as a mention. Returns how many were told.
     */
    public static function posted(PDO $pdo, array $g, int $pid, int $author, string $body, string $who): int
    {
        require_once __DIR__ . '/Notify.php';
        $gid = (int) $g['id'];
        $st = $pdo->prepare("SELECT user_id FROM community_group_members WHERE group_id = ? AND status = 'active' AND user_id <> ?"); $st->execute([$gid, $author]);
        $members = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        if (!$members) return 0;
        $mutedSet = [];
        try {
            $st = $pdo->prepare("SELECT user_id FROM user_links WHERE target_type = 'group' AND target_id = ? AND muted = 1"); $st->execute([(string) $gid]);
            $mutedSet = array_flip(array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)));
        } catch (Throwable) {}
        preg_match_all('/@\[[^\]\n]{1,80}\]\(u:(\d+)\)/u', $body, $mx);
        $mentioned = array_flip(array_map('intval', $mx[1] ?? []));
        $text = mb_strimwidth(self::plain($body), 0, 300, '…');
        $url = '/community/group.php?id=' . $gid;
        $post = []; $ment = [];
        foreach ($members as $u) {
            if (People::blocked($pdo, $u, $author)) continue;
            if (isset($mentioned[$u])) { $ment[] = $u; continue; }   // a mention needs them: it reaches them muted or not
            if (!isset($mutedSet[$u])) $post[] = $u;
        }
        $n = 0;
        if ($ment) $n += Notify::send($pdo, 'group.mention', ['users' => $ment], ['thing' => 'gmention:' . $gid . ':' . $pid, 'url' => $url, 'from' => ['user', $author, $who]],
            ['title' => $who . ' mentioned you in ' . $g['name'], 'body' => $text]);
        if ($post) $n += Notify::send($pdo, 'group.post', ['users' => $post], ['thing' => 'gpost:' . $gid . ':' . $pid, 'thread' => 'group:' . $gid, 'url' => $url, 'from' => ['user', $author, $who]],
            ['title' => $who . ' posted in ' . $g['name'], 'body' => $text]);
        return $n;
    }

    /** A request to join (Community::join, status pending): whoever moderates is told, with Accept and Decline. */
    public static function joinAsked(PDO $pdo, array $g, int $uid): int
    {
        require_once __DIR__ . '/Notify.php';
        $ids = array_values(array_diff(self::leaders($pdo, $g, 'moderate'), [$uid]));
        if (!$ids) return 0;
        $u = People::user($pdo, $uid);
        $name = $u ? People::name($u) : 'Someone';
        return Notify::send($pdo, 'group.join', self::to($g, $ids), ['thing' => 'gjoin:' . (int) $g['id'] . ':' . $uid . ':' . date('YmdHis'), 'thread' => 'gjoin:' . (int) $g['id'],
            'url' => '/community/group.php?id=' . (int) $g['id'] . '#members', 'from' => ['user', $uid, $name]],
            ['title' => $name . ' asked to join ' . $g['name'], 'body' => 'Accept or decline it here, or in the group\'s Members.']);
    }

    /** A post reported to the group (Community::reportFiled; not danger, which is ours): whoever handles its reports is told. */
    public static function reported(PDO $pdo, int $postId, string $reason): int
    {
        if ($reason === 'unsafe') return 0;   // Traversence's Safety team has it (Reports::file)
        require_once __DIR__ . '/Notify.php'; require_once __DIR__ . '/Reports.php';
        $st = $pdo->prepare('SELECT group_id, user_id FROM community_posts WHERE id = ?'); $st->execute([$postId]);
        $p = $st->fetch(PDO::FETCH_ASSOC);
        if (!$p) return 0;
        $g = Community::group($pdo, (int) $p['group_id']);
        if (!$g) return 0;
        $ids = array_values(array_diff(self::leaders($pdo, $g, 'reports'), [(int) $p['user_id']]));
        if (!$ids) return 0;
        $st = $pdo->prepare("SELECT COUNT(*) FROM content_reports WHERE kind = 'group_post' AND target_id = ? AND status = 'open'"); $st->execute([$postId]);
        $n = (int) $st->fetchColumn();
        return Notify::send($pdo, 'group.report', self::to($g, $ids), ['thing' => 'greport:' . (int) $g['id'] . ':' . $postId . ':' . $n, 'thread' => 'greport:' . (int) $g['id'],
            'url' => '/community/group.php?id=' . (int) $g['id'] . '#reports'],
            ['title' => 'A post in ' . $g['name'] . ' was reported', 'body' => Reports::label($reason) . ($n > 1 ? ' (' . $n . ' reports on it)' : '') . '. Keep it or remove it here.']);
    }

    // ---- the bodies ---------------------------------------------------------------------------------------------------

    /** [group id, second id] from a message's thing ('gpost:4:12', 'gjoin:4:7:…', 'greport:4:12:2', 'gmention:4:12'). */
    private static function ids(array $m): array
    {
        return preg_match('/^g(?:post|join|report|mention):(\d+):(\d+)/', (string) ($m['thing'] ?? ''), $x) ? [(int) $x[1], (int) $x[2]] : [0, 0];
    }

    private static function name(PDO $pdo, int $u): string { $p = People::user($pdo, $u); return $p ? People::name($p) : 'Someone who left'; }

    /** Pulse's body for group.post, group.mention, group.join and group.report: ['html', 'state']. */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        [$gid, $ref] = self::ids($m);
        $g = $gid ? Community::group($pdo, $gid) : null;
        if (!$g) return ['html' => CommsBody::wrap(CommsBody::status('This group isn\'t on Traversence any more.', 'info', 'Gone:')), 'state' => 'The group is gone'];
        $msg = (int) ($m['id'] ?? 0);
        $link = '<a href="/community/group.php?id=' . $gid . '" data-peek-frame>' . CommsBody::e((string) $g['name']) . '</a>';
        switch ((string) $m['kind']) {
            case 'group.join': return self::joinBody($pdo, $g, $ref, $viewer, $msg, $link);
            case 'group.report': return self::reportBody($pdo, $g, $ref, $viewer, $msg, $link);
            default: return self::postBody($pdo, $g, $ref, $viewer, $msg, $link, (string) $m['kind'] === 'group.mention', (string) ($m['created_at'] ?? ''));
        }
    }

    private static function postBody(PDO $pdo, array $g, int $pid, int $viewer, int $msg, string $link, bool $mention, string $since): array
    {
        $gid = (int) $g['id'];
        $posts = Community::posts($pdo, $viewer, $gid);   // members only, blocked people left out, held posts only for their authors and moderators
        if (!Community::isMember($pdo, $gid, $viewer)) return ['html' => CommsBody::wrap('<p>In ' . $link . '.</p>' . CommsBody::status('You aren\'t in this group now, so its posts aren\'t shown here.', 'info')), 'state' => 'Not in the group'];
        $the = null; $newer = [];
        foreach ($posts as $p) { if ($p['id'] === $pid) $the = $p; elseif ($p['id'] > $pid && $p['author_id'] !== $viewer) $newer[] = $p; }
        $h = '<p>In ' . $link . '</p>';
        if ($the) $h .= CommsBody::quote($the['author'], $the['at'], self::plain($the['body']), $the['held'] ? 'Held while it\'s looked at' : '');
        else $h .= CommsBody::status('That post was removed.', 'info', 'Removed:');
        if (!$mention && $newer) {   // the group's posts since, in this one message (one per group while unread)
            $h .= '<details' . (count($newer) <= 3 ? ' open' : '') . '><summary>' . count($newer) . ' more ' . (count($newer) === 1 ? 'post' : 'posts') . ' since</summary>';
            foreach (array_reverse(array_slice($newer, 0, 10)) as $p) $h .= CommsBody::quote($p['author'], $p['at'], mb_strimwidth(self::plain($p['body']), 0, 400, '…'));
            $h .= '</details>';
        }
        $muted = self::muted($pdo, $viewer, $gid);
        $acts = ['<a class="tv-btn" href="/community/group.php?id=' . $gid . '" data-peek-frame>Open the group</a>'];
        $acts[] = $muted ? CommsBody::button('Unmute its posts', self::ENDPOINT, ['act' => 'unmute', 'group' => $gid, 'msg' => $msg])
                         : CommsBody::button('Mute its posts', self::ENDPOINT, ['act' => 'mute', 'group' => $gid, 'msg' => $msg], ['confirm' => 'Stop new posts in ' . $g['name'] . ' reaching your Pulse? Mentions of you still do.', 'yes' => 'Mute']);
        $h .= CommsBody::acts($acts);
        if ($the && $the['author_id'] !== $viewer) $h .= self::reportForm((int) $the['id'], $msg);
        $state = ($the ? ($the['held'] ? 'Held while it\'s looked at' : 'In the group') : 'Removed') . ($muted ? ' · you muted its posts' : '');
        return ['html' => CommsBody::wrap($h), 'state' => $state];
    }

    private static function reportForm(int $pid, int $msg): string
    {
        require_once __DIR__ . '/Reports.php';
        $o = '';
        foreach (Reports::REASONS as $k => $label) $o .= '<option value="' . CommsBody::e($k) . '">' . CommsBody::e($label) . '</option>';
        return '<details><summary>Report it</summary><form class="tv-mb-reply" data-msg-reply="' . self::ENDPOINT . '" data-msg-body=\'' . json_encode(['act' => 'report', 'post' => $pid, 'msg' => $msg], JSON_HEX_APOS | JSON_HEX_TAG | JSON_HEX_AMP) . '\'>'
            . '<label>Why<select name="reason">' . $o . '</select></label><textarea name="body" data-spell maxlength="500" rows="2" placeholder="Anything the group\'s moderators should know (optional)"></textarea>'
            . '<button type="submit" class="tv-btn">Send report</button></form></details>';
    }

    private static function joinBody(PDO $pdo, array $g, int $asker, int $viewer, int $msg, string $link): array
    {
        $gid = (int) $g['id'];
        if (!Community::can($pdo, $gid, $viewer, 'moderate', $g)) return ['html' => CommsBody::wrap('<p>In ' . $link . '.</p>' . CommsBody::status('You don\'t moderate this group now, so its requests are for its moderators.', 'info')), 'state' => 'Not yours now'];
        $pending = array_values(array_filter(Community::members($pdo, $viewer, $gid), fn ($r) => $r['status'] === 'pending'));
        $h = '<p>In ' . $link . '</p>';
        foreach ($pending as $r) {
            $h .= '<div class="tv-mb-q"><b>' . CommsBody::e($r['name']) . '</b> asked to join' . (!empty($r['invited_by']) ? ' <small>invited by ' . CommsBody::e((string) $r['invited_by']) . '</small>' : '');
            foreach ((array) ($r['answers'] ?? []) as $a) if (is_array($a) && count($a) === 2) $h .= '<p><small>' . CommsBody::e((string) $a[0]) . '</small><br>' . CommsBody::e((string) $a[1]) . '</p>';
            $h .= CommsBody::acts([CommsBody::button('Accept', self::ENDPOINT, ['act' => 'accept', 'group' => $gid, 'member' => (int) $r['id'], 'msg' => $msg]),
                                   CommsBody::button('Decline', self::ENDPOINT, ['act' => 'decline', 'group' => $gid, 'member' => (int) $r['id'], 'msg' => $msg], ['confirm' => 'Decline ' . $r['name'] . '\'s request? They\'re told it wasn\'t accepted.', 'yes' => 'Decline', 'danger' => true])]) . '</div>';
        }
        // the one this message was about, where it stands now
        $mm = Community::membership($pdo, $gid, $asker);
        $who = self::name($pdo, $asker);
        if ($mm && $mm['status'] === 'active') {
            $st = $pdo->prepare('SELECT joined_at FROM community_group_members WHERE group_id = ? AND user_id = ?'); $st->execute([$gid, $asker]);
            $at = (string) $st->fetchColumn();
            $state = $who . ' is in: accepted ' . date('M j', strtotime($at));
            $h .= '<p data-tv-status="ok" data-tv-label="Accepted:">' . CommsBody::e($who) . ' is in the group (' . CommsBody::time($at) . ').</p>';
        } elseif ($mm) $state = count($pending) . ' waiting';
        else { $state = $who . '\'s request was declined or withdrawn'; $h .= CommsBody::status($who . '\'s request was declined, or they withdrew it.', 'info', 'Closed:'); }
        if (!$pending) $h .= CommsBody::status('No requests are waiting.', 'ok', 'All clear:');
        elseif ($mm && $mm['status'] !== 'pending') $state .= ' · ' . count($pending) . ' more waiting';
        return ['html' => CommsBody::wrap($h), 'state' => $state];
    }

    private static function reportBody(PDO $pdo, array $g, int $pid, int $viewer, int $msg, string $link): array
    {
        $gid = (int) $g['id'];
        if (!Community::handlesReports($pdo, $gid, $viewer, $g)) return ['html' => CommsBody::wrap('<p>In ' . $link . '.</p>' . CommsBody::status('This group\'s reports are handled by others now (its charter says who).', 'info')), 'state' => 'Not yours now'];
        $queue = Community::reportQueue($pdo, $gid, $viewer);
        $h = '<p>In ' . $link . '</p>';
        foreach ($queue as $q) {
            $h .= '<div class="tv-mb-q"><b>' . CommsBody::e($q['author']) . '</b> <small>' . (int) $q['reports'] . ' ' . ($q['reports'] === 1 ? 'report' : 'reports') . ': ' . CommsBody::e(implode(', ', $q['reasons'])) . ($q['held'] ? ' · held, hidden while you decide' : '') . '</small>'
                . '<p>' . nl2br(CommsBody::e(self::plain($q['body']))) . '</p>'
                . CommsBody::acts([CommsBody::button('Keep', self::ENDPOINT, ['act' => 'keep', 'post' => $q['post_id'], 'msg' => $msg]),
                                   CommsBody::button('Remove', self::ENDPOINT, ['act' => 'remove', 'post' => $q['post_id'], 'msg' => $msg], ['confirm' => 'Remove this post from the group? Its author is told.', 'yes' => 'Remove it', 'danger' => true]),
                                   CommsBody::button('Remove the post and its author', self::ENDPOINT, ['act' => 'remove_member', 'post' => $q['post_id'], 'msg' => $msg], ['confirm' => 'Remove this post, and its author from the group?', 'yes' => 'Remove both', 'danger' => true])]) . '</div>';
        }
        // the post this message was about, where it stands now: decided by whom and when
        $st = $pdo->prepare("SELECT status, handled_by, handled_at FROM content_reports WHERE kind = 'group_post' AND target_id = ? AND route = 'group' ORDER BY (status = 'open') DESC, handled_at DESC LIMIT 1");
        try { $st->execute([$pid]); $r = $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable) { $r = null; }
        if ($r && $r['status'] !== 'open') {
            $by = (int) $r['handled_by'] === $viewer ? 'you' : self::name($pdo, (int) $r['handled_by']);
            $state = ($r['status'] === 'removed' ? 'Removed by ' : 'Kept by ') . $by . ' ' . date('M j', strtotime((string) $r['handled_at']));
            $h .= '<p data-tv-status="ok" data-tv-label="Decided:">' . ($r['status'] === 'removed' ? 'Removed' : 'Kept') . ' by ' . CommsBody::e($by) . ' (' . CommsBody::time((string) $r['handled_at']) . ').</p>';
        } else $state = count($queue) . ' reported ' . (count($queue) === 1 ? 'post' : 'posts') . ' waiting';
        if (!$queue) $h .= CommsBody::status('No reported posts are waiting.', 'ok', 'All clear:');
        return ['html' => CommsBody::wrap($h), 'state' => $state];
    }

    // ---- the buttons --------------------------------------------------------------------------------------------------

    /** A button in a group's message: [message, new html or '']. Each acts through Community (which checks who may). */
    public static function act(PDO $pdo, int $uid, array $b): array
    {
        $act = (string) ($b['act'] ?? '');
        $pid = (int) ($b['post'] ?? 0);
        $gid = (int) ($b['group'] ?? 0);
        if ($pid > 0 && !$gid) { $st = $pdo->prepare('SELECT group_id FROM community_posts WHERE id = ?'); $st->execute([$pid]); $gid = (int) $st->fetchColumn(); }
        $g = $gid ? Community::group($pdo, $gid) : null;
        if (!$g) throw new InvalidArgumentException('That group isn\'t on Traversence any more.');
        switch ($act) {
            case 'accept':
            case 'decline':
                $member = (int) ($b['member'] ?? 0);
                $mm = Community::membership($pdo, $gid, $member);
                if (!$mm) throw new InvalidArgumentException('They withdrew their request.');
                if ($mm['status'] !== 'pending') throw new InvalidArgumentException('They\'re in the group already. To remove someone, use the group\'s Members.');
                Community::manage($pdo, $uid, $gid, $member, $act);   // moderators only; tells them
                $said = $act === 'accept' ? self::name($pdo, $member) . ' is in. They\'re told.' : 'Declined. They\'re told it wasn\'t accepted.';
                break;
            case 'keep':
            case 'remove':
            case 'remove_member':
                Community::decideReport($pdo, $uid, $pid, $act);   // whoever handles the group's reports
                $said = ['keep' => 'Kept. It shows in the group again.', 'remove' => 'Removed. Its author is told.', 'remove_member' => 'Removed, with its author. They\'re told.'][$act];
                break;
            case 'mute':
            case 'unmute':
                self::setMuted($pdo, $uid, $g, $act === 'mute');
                $said = $act === 'mute' ? 'Muted. New posts in ' . $g['name'] . ' won\'t reach your Pulse; mentions of you still do.' : 'Unmuted. New posts reach your Pulse again.';
                break;
            case 'report':
                require_once __DIR__ . '/Reports.php';
                Reports::file($pdo, $uid, 'group_post', $pid, (string) ($b['reason'] ?? 'other'), (string) ($b['body'] ?? ''));
                $said = (string) ($b['reason'] ?? '') === 'unsafe' ? 'Thank you. Our Safety team will look at it.' : 'Thank you. The group\'s moderators will look at it.';
                break;
            default:
                throw new InvalidArgumentException('Unknown action.');
        }
        $m = CommsBody::message($pdo, (int) ($b['msg'] ?? 0), $uid);
        return [$said, $m ? self::pulseBody($pdo, $m, $uid)['html'] : ''];
    }
}
