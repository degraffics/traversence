<?php
// app/lib/MailImap.php — reads a mailbox over IMAP for Pulse (decisions/0172 §4.7: our cPanel mailboxes, and any outside
// mailbox signed in with an app password: a business's own host, Yahoo, iCloud, Zoho, Gmail by app password). Written
// over a plain socket, as Mailer is for SMTP, because Bluehost's PHP may not have the IMAP extension (it left PHP's core
// in 8.4). Port 993 is TLS from the start; 143 upgrades with STARTTLS (never signs in unencrypted). Mail is read with
// BODY.PEEK, so reading it in Pulse doesn't mark it read; setSeen() does that on purpose, both ways (§4.7). Staging never
// connects (StagingGate::hold, decisions/0165). Every refusal is thrown in plain words for the person's Reconnect alert;
// a password is never logged or put in a message.
declare(strict_types=1);

final class MailImap
{
    private const TIMEOUT = 20;
    /** The exception code of a server's NO or BAD (as against a connection that failed). */
    private const REFUSED = 7;

    /** For tests only: function (string $host, int $port, bool $tls): resource, used in place of the network. */
    public static ?Closure $open = null;
    /** For tests only: function ($stream): bool, used in place of the TLS upgrade after STARTTLS. */
    public static ?Closure $starttls = null;

    private string $host;
    private int $port;
    private string $login;
    private string $password;
    private string $address;
    /** @var resource|null */
    private $s = null;
    private int $tag = 0;
    private array $caps = [];
    private bool $authed = false;
    private string $selected = '';

    /** $c: host, port (993 TLS by default; 143 with STARTTLS), login, password, address (the mailbox's address, for messages). */
    public function __construct(array $c)
    {
        $this->host = strtolower(trim((string) ($c['host'] ?? '')));
        $this->port = (int) ($c['port'] ?? 0) ?: 993;
        $this->login = (string) ($c['login'] ?? '');
        $this->password = (string) ($c['password'] ?? '');
        $this->address = trim((string) ($c['address'] ?? '')) ?: $this->login;
        if ($this->host === '') throw new RuntimeException('The mail server for ' . $this->address . ' isn\'t set: add its server name (e.g. imap.example.com).');
    }

    public function __destruct()
    {
        if (is_resource($this->s)) @fclose($this->s);
    }

    /** '' when the mailbox signs in and its INBOX opens, else the exact refusal in plain words. */
    public static function check(array $c): string
    {
        try {
            $m = new self($c);
            $m->login();
            $m->select('INBOX', true);
            $m->logout();
            return '';
        } catch (Throwable $e) {
            return $e->getMessage();
        }
    }

    /** Connects (TLS) and signs in. */
    public function login(): void
    {
        if ($this->authed) return;
        if ($this->login === '' || $this->password === '') throw new RuntimeException('The sign-in name or password for ' . $this->address . ' is missing: reconnect it.');
        $this->connect();
        if (!$this->authed) {
            if (in_array('LOGINDISABLED', $this->caps, true)) throw new RuntimeException('The mail server for ' . $this->address . ' doesn\'t allow signing in with a password here.');
            try {
                $r = $this->run(['LOGIN ', self::astring($this->login), ' ', self::astring($this->password)]);
            } catch (RuntimeException $e) {
            if ($e->getCode() !== self::REFUSED) throw $e;
                throw new RuntimeException($this->refusal($e->getMessage(), true));
            }
            $this->authed = true;
            $this->caps = self::capsFrom($r['text']) ?: $this->capability();
        }
    }

    /**
     * Every folder: [name (readable), raw (as the server names it), delim, flags [], use ('inbox', 'sent', 'trash',
     * 'junk', 'archive', 'drafts', 'all', 'flagged' or ''), selectable].
     */
    public function folders(): array
    {
        $this->login();
        $r = $this->run(['LIST "" "*"']);
        $out = [];
        foreach ($r['untagged'] as [$line, $lits]) {
            if (!preg_match('/^\* LIST \(([^)]*)\) (NIL|"(?:[^"\\\\]|\\\\.)*") (.*)$/is', $line, $m)) continue;
            $flags = preg_split('/\s+/', trim($m[1]), -1, PREG_SPLIT_NO_EMPTY) ?: [];
            $delim = $m[2] === 'NIL' ? '' : stripcslashes(substr($m[2], 1, -1));
            $raw = self::stringFrom(trim($m[3], " \t"), $lits);
            $use = '';
            $lf = array_map('strtolower', $flags);
            foreach (['\\sent' => 'sent', '\\trash' => 'trash', '\\junk' => 'junk', '\\archive' => 'archive', '\\drafts' => 'drafts', '\\all' => 'all', '\\flagged' => 'flagged'] as $f => $u) {
                if (in_array($f, $lf, true)) { $use = $u; break; }
            }
            $name = self::utf7Decode($raw);
            if (strcasecmp($raw, 'INBOX') === 0) $use = 'inbox';
            if ($use === '') {   // servers without SPECIAL-USE: by the usual names
                $leaf = strtolower($delim !== '' && strrpos($name, $delim) !== false ? substr($name, strrpos($name, $delim) + strlen($delim)) : $name);
                $byName = ['sent' => 'sent', 'sent items' => 'sent', 'sent messages' => 'sent', 'sent mail' => 'sent', 'trash' => 'trash', 'deleted items' => 'trash',
                    'deleted messages' => 'trash', 'bin' => 'trash', 'junk' => 'junk', 'spam' => 'junk', 'junk e-mail' => 'junk', 'junk email' => 'junk', 'bulk mail' => 'junk',
                    'archive' => 'archive', 'archives' => 'archive', 'drafts' => 'drafts'];
                $use = $byName[$leaf] ?? '';
            }
            $out[] = ['name' => $name, 'raw' => $raw, 'delim' => $delim, 'flags' => $flags, 'use' => $use, 'selectable' => !in_array('\\noselect', $lf, true) && !in_array('\\nonexistent', $lf, true)];
        }
        return $out;
    }

    /** Opens a folder (its readable name, as folders() gives it); $readOnly uses EXAMINE. [exists, uidvalidity, uidnext]. */
    public function select(string $folder, bool $readOnly = false): array
    {
        $this->login();
        try {
            $r = $this->run([$readOnly ? 'EXAMINE ' : 'SELECT ', self::mailbox($folder)]);
        } catch (RuntimeException $e) {
            if ($e->getCode() !== self::REFUSED) throw $e;
            throw new RuntimeException('The folder "' . $folder . '" in ' . $this->address . ' couldn\'t be opened: ' . $this->refusal($e->getMessage(), false));
        }
        $this->selected = $folder;
        $out = ['exists' => 0, 'uidvalidity' => 0, 'uidnext' => 0];
        foreach ($r['untagged'] as [$line]) {
            if (preg_match('/^\* (\d+) EXISTS/i', $line, $m)) $out['exists'] = (int) $m[1];
            if (preg_match('/\[UIDVALIDITY (\d+)\]/i', $line, $m)) $out['uidvalidity'] = (int) $m[1];
            if (preg_match('/\[UIDNEXT (\d+)\]/i', $line, $m)) $out['uidnext'] = (int) $m[1];
        }
        return $out;
    }

    /** The oldest $max UIDs after $uid in the open folder (a server answers n+1:* with its last UID even when nothing is new). */
    public function uidsAfter(int $uid, int $max = 50): array
    {
        $ids = array_values(array_filter($this->search('UID ' . ($uid + 1) . ':*'), fn ($u) => $u > $uid));
        return array_slice($ids, 0, max(1, $max));
    }

    /** UIDs of messages that arrived in the last $days days, oldest first. */
    public function uidsSince(int $days): array
    {
        $t = time() - max(0, $days) * 86400;
        $mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][(int) gmdate('n', $t) - 1];
        return $this->search('SINCE ' . gmdate('j', $t) . '-' . $mon . '-' . gmdate('Y', $t));
    }

    /** The messages, whole: [[uid, flags [], size, raw] …] in UID order. Reading doesn't mark them read (BODY.PEEK). */
    public function fetch(array $uids): array
    {
        $uids = array_values(array_unique(array_filter(array_map('intval', $uids), fn ($u) => $u > 0)));
        if (!$uids) return [];
        sort($uids);
        $this->needFolder();
        $r = $this->run(['UID FETCH ' . self::set($uids) . ' (UID FLAGS RFC822.SIZE BODY.PEEK[])']);
        $bySeq = [];
        foreach ($r['untagged'] as [$line, $lits]) {
            if (!preg_match('/^\* (\d+) FETCH \((.*)\)\s*$/is', $line, $m)) continue;
            $seq = (int) $m[1];
            $it = $m[2];
            $row = $bySeq[$seq] ?? ['uid' => 0, 'flags' => [], 'size' => 0, 'raw' => null];
            if (preg_match('/(?:^|\s)UID (\d+)/i', $it, $x)) $row['uid'] = (int) $x[1];
            if (preg_match('/(?:^|\s)FLAGS \(([^)]*)\)/i', $it, $x)) $row['flags'] = preg_split('/\s+/', trim($x[1]), -1, PREG_SPLIT_NO_EMPTY) ?: [];
            if (preg_match('/(?:^|\s)RFC822\.SIZE (\d+)/i', $it, $x)) $row['size'] = (int) $x[1];
            if (preg_match('/(?:^|\s)BODY\[\](?:<\d+>)? (\x00L\d+\x00|NIL|"(?:[^"\\\\]|\\\\.)*")/i', $it, $x)) $row['raw'] = $x[1] === 'NIL' ? '' : self::stringFrom($x[1], $lits);
            $bySeq[$seq] = $row;
        }
        $out = [];
        foreach ($bySeq as $row) {
            if ($row['uid'] > 0 && $row['raw'] !== null && in_array($row['uid'], $uids, true)) {
                if ($row['size'] === 0) $row['size'] = strlen($row['raw']);
                $out[$row['uid']] = $row;
            }
        }
        ksort($out);
        return array_values($out);
    }

    public function setSeen(int $uid, bool $on): void { $this->store($uid, '\\Seen', $on); }

    public function setFlagged(int $uid, bool $on): void { $this->store($uid, '\\Flagged', $on); }

    /** Moves a message to another folder (its readable name): MOVE where the server has it, else COPY, \Deleted and UID EXPUNGE. */
    public function move(int $uid, string $folder): void
    {
        $this->needFolder();
        $mb = self::mailbox($folder);
        if (in_array('MOVE', $this->caps, true)) { $this->run(['UID MOVE ' . $uid . ' ', $mb]); return; }
        $this->run(['UID COPY ' . $uid . ' ', $mb]);
        $this->store($uid, '\\Deleted', true);
        // only this message is removed: UID EXPUNGE (UIDPLUS). Without it the message stays marked deleted, because a plain
        // EXPUNGE would also remove anything else the person marked deleted in their own mail app.
        if (in_array('UIDPLUS', $this->caps, true)) $this->run(['UID EXPUNGE ' . $uid]);
    }

    /** Saves a raw message in a folder (a reply in Sent): marked read unless other $flags are given. */
    public function append(string $folder, string $raw, array $flags = ['\\Seen']): void
    {
        $this->login();
        $raw = str_replace(["\r\n", "\r", "\n"], ["\n", "\n", "\r\n"], $raw);
        $fl = array_values(array_filter($flags, fn ($f) => preg_match('/^\\\\?[A-Za-z$]+$/', (string) $f)));
        try {
            $this->run(['APPEND ', self::mailbox($folder), ' (' . implode(' ', $fl) . ') ', ['lit' => $raw]]);
        } catch (RuntimeException $e) {
            if ($e->getCode() !== self::REFUSED) throw $e;
            throw new RuntimeException('The message couldn\'t be saved in "' . $folder . '" of ' . $this->address . ': ' . $this->refusal($e->getMessage(), false));
        }
    }

    /** Signs out and closes the connection; a failed goodbye isn't an error. */
    public function logout(): void
    {
        if (!is_resource($this->s)) return;
        try { $this->run(['LOGOUT']); } catch (Throwable $e) {}
        @fclose($this->s);
        $this->s = null; $this->authed = false; $this->selected = '';
    }

    // ---- inside: the connection ---------------------------------------------------------------------------------------

    private function connect(): void
    {
        if (is_resource($this->s)) return;
        if (!class_exists('StagingGate')) require_once __DIR__ . '/StagingGate.php';
        if (($w = StagingGate::hold('imap://' . $this->host, 'Mail: read ' . $this->address)) !== null) throw new RuntimeException($w);
        $tls = $this->port !== 143;
        if (self::$open !== null) {
            $s = (self::$open)($this->host, $this->port, $tls);
        } else {
            $ctx = stream_context_create(['ssl' => ['peer_name' => $this->host, 'SNI_enabled' => true, 'verify_peer' => true, 'verify_peer_name' => true]]);
            $errno = 0; $errstr = '';
            $s = @stream_socket_client(($tls ? 'ssl' : 'tcp') . '://' . $this->host . ':' . $this->port, $errno, $errstr, self::TIMEOUT, STREAM_CLIENT_CONNECT, $ctx);
            if ($s === false) throw new RuntimeException(self::connectError($this->host, $this->port, $errno, $errstr));
        }
        if (!is_resource($s)) throw new RuntimeException('Port ' . $this->port . ' on ' . $this->host . ' is blocked or the server didn\'t answer.');
        stream_set_timeout($s, self::TIMEOUT);
        $this->s = $s;
        $this->tag = 0;
        [$greet] = $this->readLine();
        if (preg_match('/^\* BYE\b\s*(.*)$/i', $greet, $m)) throw new RuntimeException('The mail server ' . $this->host . ' turned the connection away: ' . self::clean($m[1]));
        if (!preg_match('/^\* (OK|PREAUTH)\b/i', $greet, $m)) throw new RuntimeException('That isn\'t an IMAP mail server at ' . $this->host . ':' . $this->port . ' (it said "' . self::clean(substr($greet, 0, 80)) . '").');
        $this->authed = strtoupper($m[1]) === 'PREAUTH';
        $this->caps = self::capsFrom($greet) ?: $this->capability();
        if (!$tls) {
            if (!in_array('STARTTLS', $this->caps, true)) throw new RuntimeException('The mail server ' . $this->host . ' doesn\'t offer encryption on port 143: use port 993.');
            $this->run(['STARTTLS']);
            $ok = self::$starttls !== null ? (bool) (self::$starttls)($this->s) : @stream_socket_enable_crypto($this->s, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if (!$ok) throw new RuntimeException('A secure connection to ' . $this->host . ' couldn\'t be made (its certificate or encryption was refused).');
            $this->caps = $this->capability();
        }
    }

    public static function connectError(string $host, int $port, int $errno, string $errstr): string
    {
        $e = strtolower($errstr . ' ' . (string) (error_get_last()['message'] ?? ''));
        if (str_contains($e, 'getaddrinfo') || str_contains($e, 'name or service not known') || str_contains($e, 'no such host') || str_contains($e, 'name resolution')) {
            return 'The mail server ' . $host . ' wasn\'t found: check its name.';
        }
        if (str_contains($e, 'certificate') || str_contains($e, 'ssl') || str_contains($e, 'crypto')) {
            return 'A secure connection to ' . $host . ' couldn\'t be made (its certificate or encryption was refused).';
        }
        if (str_contains($e, 'refused')) return 'The mail server ' . $host . ' refused the connection on port ' . $port . ': check the port.';
        return 'Port ' . $port . ' on ' . $host . ' is blocked or the server didn\'t answer.';
    }

    private function capability(): array
    {
        $r = $this->run(['CAPABILITY']);
        foreach ($r['untagged'] as [$line]) if (preg_match('/^\* CAPABILITY (.*)$/i', $line, $m)) return self::capList($m[1]);
        return [];
    }

    private static function capsFrom(string $text): array
    {
        return preg_match('/\[CAPABILITY ([^\]]*)\]/i', $text, $m) ? self::capList($m[1]) : [];
    }

    private static function capList(string $s): array { return array_map('strtoupper', preg_split('/\s+/', trim($s), -1, PREG_SPLIT_NO_EMPTY) ?: []); }

    /**
     * One command: $parts are strings, or ['lit' => bytes] sent as a literal (wait for "+", then the bytes). Returns
     * [untagged [[line, literals] …], status, text]; NO or BAD throws with the server's words.
     */
    private function run(array $parts): array
    {
        if (!is_resource($this->s)) throw new RuntimeException('The connection to ' . $this->host . ' was closed.');
        $tag = 'A' . str_pad((string) ++$this->tag, 4, '0', STR_PAD_LEFT);
        $untagged = [];
        $buf = $tag . ' ';
        foreach ($parts as $p) {
            if (is_array($p)) {
                $data = (string) $p['lit'];
                $this->write($buf . '{' . strlen($data) . "}\r\n");
                while (true) {   // the server's go-ahead, or its refusal
                    [$line, $lits] = $this->readLine();
                    if ($line !== '' && $line[0] === '+') break;
                    if (str_starts_with($line, $tag . ' ')) return $this->finish($tag, $line, $untagged);
                    $untagged[] = [$line, $lits];
                }
                $buf = $data;
                continue;
            }
            $buf .= $p;
        }
        $this->write($buf . "\r\n");
        while (true) {
            [$line, $lits] = $this->readLine();
            if (str_starts_with($line, $tag . ' ')) return $this->finish($tag, $line, $untagged);
            if ($line !== '' && $line[0] === '+') continue;   // a stray go-ahead (an IDLE-style prompt) isn't ours to answer
            $untagged[] = [$line, $lits];
        }
    }

    private function finish(string $tag, string $line, array $untagged): array
    {
        $rest = substr($line, strlen($tag) + 1);
        $status = strtoupper((string) strtok($rest, ' '));
        $text = trim((string) substr($rest, strlen($status)));
        if ($status !== 'OK') throw new RuntimeException(($status === 'BAD' ? 'BAD ' : '') . $text, self::REFUSED);
        return ['untagged' => $untagged, 'status' => $status, 'text' => $text];
    }

    private function write(string $s): void
    {
        $left = $s;
        while ($left !== '') {
            $n = @fwrite($this->s, $left);
            if ($n === false || $n === 0) throw new RuntimeException('The mail server ' . $this->host . ' closed the connection.');
            $left = (string) substr($left, $n);
        }
    }

    /**
     * One response line with its literals read in: [text, literals] where each {n} literal is replaced in the text by a
     * marker "\0L<i>\0" and its bytes are literals[i].
     */
    private function readLine(): array
    {
        $text = ''; $lits = [];
        while (true) {
            $line = fgets($this->s);
            if ($line === false) $this->lost();
            if (preg_match('/\{(\d+)\+?\}\r?\n$/', $line, $m)) {
                $n = (int) $m[1];
                $text .= substr($line, 0, -strlen($m[0])) . "\x00L" . count($lits) . "\x00";
                $data = '';
                while (strlen($data) < $n) {
                    $chunk = fread($this->s, min(65536, $n - strlen($data)));
                    if ($chunk === false || $chunk === '') {
                        if (feof($this->s) || !empty(stream_get_meta_data($this->s)['timed_out'])) $this->lost();
                        continue;
                    }
                    $data .= $chunk;
                }
                $lits[] = $data;
                continue;   // the line goes on after the literal
            }
            $text .= rtrim($line, "\r\n");
            return [$text, $lits];
        }
    }

    /** @return never */
    private function lost(): void
    {
        $timedOut = is_resource($this->s) && !empty(stream_get_meta_data($this->s)['timed_out']);
        throw new RuntimeException($timedOut
            ? 'The mail server ' . $this->host . ' stopped answering (no reply in ' . self::TIMEOUT . ' seconds).'
            : 'The mail server ' . $this->host . ' closed the connection.');
    }

    private function needFolder(): void
    {
        $this->login();
        if ($this->selected === '') $this->select('INBOX');
    }

    private function search(string $criteria): array
    {
        $this->needFolder();
        $r = $this->run(['UID SEARCH ' . $criteria]);
        $ids = [];
        foreach ($r['untagged'] as [$line]) {
            if (preg_match('/^\* SEARCH\b(.*)$/i', $line, $m)) foreach (preg_split('/\s+/', trim($m[1]), -1, PREG_SPLIT_NO_EMPTY) ?: [] as $u) if (ctype_digit($u)) $ids[] = (int) $u;
        }
        $ids = array_values(array_unique($ids));
        sort($ids);
        return $ids;
    }

    private function store(int $uid, string $flag, bool $on): void
    {
        $this->needFolder();
        $this->run(['UID STORE ' . $uid . ' ' . ($on ? '+' : '-') . 'FLAGS.SILENT (' . $flag . ')']);
    }

    /** A refusal in plain words: the password, a full mailbox, a server that's busy, else the server's own words. */
    private function refusal(string $said, bool $atLogin): string
    {
        $s = self::clean($said);
        $l = strtolower($said);
        if (str_contains($l, '[overquota]') || str_contains($l, 'quota') || str_contains($l, 'mailbox is full') || str_contains($l, 'over quota')) return 'The mailbox ' . $this->address . ' is full.';
        if (str_contains($l, 'application-specific password') || str_contains($l, 'app password') || str_contains($l, 'web login required') || str_contains($l, '[alert] please log in via your web browser')) {
            return 'The mail server wants an app password for ' . $this->address . ', not the account\'s own password: make one in the account\'s security settings and reconnect.';
        }
        if (str_contains($l, '[unavailable]') || str_contains($l, 'temporarily') || str_contains($l, 'try again later')) return 'The mail server for ' . $this->address . ' is busy or down for now (it said "' . $s . '"): it will be tried again.';
        if (str_contains($l, 'disabled') || str_contains($l, 'suspended') || str_contains($l, '[contactadmin]') || str_contains($l, 'not enabled for imap') || str_contains($l, 'imap access')) {
            return 'The mailbox ' . $this->address . ' is suspended or has IMAP turned off at the mail server (it said "' . $s . '").';
        }
        if ($atLogin || str_contains($l, '[authenticationfailed]') || str_contains($l, 'invalid credentials') || str_contains($l, 'authentication failed') || str_contains($l, 'login failed')) {
            return 'The mail server refused the password for ' . $this->address . ($s !== '' ? ' (it said "' . $s . '")' : '') . '.';
        }
        return 'the mail server said "' . $s . '".';
    }

    /** The server's words without response codes' brackets noise, control characters or the tag. */
    private static function clean(string $s): string
    {
        $s = preg_replace('/^BAD\s+/', '', $s) ?? $s;
        $s = preg_replace('/\[(?:[A-Z-]+)(?: [^\]]*)?\]\s*/', '', $s) ?? $s;
        $s = preg_replace('/[\x00-\x1F\x7F]+/', ' ', $s) ?? $s;
        $s = trim($s);
        return mb_substr($s !== '' ? $s : 'no reason given', 0, 200);
    }

    // ---- inside: strings, folder names, sets --------------------------------------------------------------------------

    /** A string argument: quoted (with \ and " escaped) when it's plain ASCII, else a literal. */
    private static function astring(string $s): array|string
    {
        if (preg_match('/[^\x20-\x7E]/', $s)) return ['lit' => $s];
        return '"' . addcslashes($s, '"\\') . '"';
    }

    /** A folder's readable name as the server wants it (modified UTF-7, quoted). */
    private static function mailbox(string $name): string
    {
        $raw = strcasecmp($name, 'INBOX') === 0 ? 'INBOX' : self::utf7Encode($name);
        return '"' . addcslashes($raw, '"\\') . '"';
    }

    /** A literal marker, a quoted string or an atom → its value. */
    private static function stringFrom(string $tok, array $lits): string
    {
        if (preg_match('/^\x00L(\d+)\x00$/', $tok, $m)) return (string) ($lits[(int) $m[1]] ?? '');
        if (strlen($tok) >= 2 && $tok[0] === '"' && substr($tok, -1) === '"') return preg_replace('/\\\\(.)/s', '$1', substr($tok, 1, -1)) ?? '';
        return $tok;
    }

    /** [1,2,3,7,9,10] → "1:3,7,9:10". */
    private static function set(array $uids): string
    {
        $out = []; $start = $prev = null;
        foreach ($uids as $u) {
            if ($start === null) { $start = $prev = $u; continue; }
            if ($u === $prev + 1) { $prev = $u; continue; }
            $out[] = $start === $prev ? (string) $start : $start . ':' . $prev;
            $start = $prev = $u;
        }
        if ($start !== null) $out[] = $start === $prev ? (string) $start : $start . ':' . $prev;
        return implode(',', $out);
    }

    /** IMAP's modified UTF-7 (RFC 3501 §5.1.3) → UTF-8. */
    public static function utf7Decode(string $s): string
    {
        return preg_replace_callback('/&([A-Za-z0-9+,]*)-/', function ($m) {
            if ($m[1] === '') return '&';
            $b = base64_decode(str_pad(strtr($m[1], ',', '/'), (int) (ceil(strlen($m[1]) / 4) * 4), '='));
            $u = $b === false ? '' : @mb_convert_encoding($b, 'UTF-8', 'UTF-16BE');
            return is_string($u) ? $u : $m[0];
        }, $s) ?? $s;
    }

    /** UTF-8 → IMAP's modified UTF-7. */
    public static function utf7Encode(string $s): string
    {
        $out = ''; $run = '';
        $flush = function () use (&$out, &$run) {
            if ($run === '') return;
            $out .= '&' . rtrim(strtr(base64_encode(mb_convert_encoding($run, 'UTF-16BE', 'UTF-8')), '/', ','), '=') . '-';
            $run = '';
        };
        foreach (mb_str_split($s, 1, 'UTF-8') as $ch) {
            $o = ord($ch);
            if (strlen($ch) === 1 && $o >= 0x20 && $o <= 0x7E) { $flush(); $out .= $ch === '&' ? '&-' : $ch; }
            else $run .= $ch;
        }
        $flush();
        return $out;
    }
}
