<?php
// app/lib/CommsSetup.php — the email engine's setup (decisions/0167 §1, §3, §4; 0172 §4.3, §4.6): System Configuration →
// Communications reads and changes everything here. Communications is where the mail is set up; Pulse is where it's
// handled (Mailboxes.php).
//   - Senders: one card each (the system sender, orders@, requests@ for visitors' requests to unclaimed listings, SES
//     personal; SES bulk shown as coming). Address, name and reply-to live in .env (EnvSettings), each with its mailbox,
//     server and port; Check signs in without sending (MailSmtp::check) and gives the exact refusal; Send me a test.
//   - Mailboxes: every mailbox on every domain of the cPanel account (UAPI Email::list_pops_with_disk), marked system,
//     staff or inbox; made, suspended, unsuspended or reset here. A reset's password is typed or made by the site, set
//     through cPanel and written straight into .env for its sender, never shown; the old one kept until Check passes.
//   - Routing: each kind of email and the sender it goes from (prefixFor()); code asks for a kind, never a sender.
//   - Domain health: SPF, DKIM and DMARC read through cPanel, with a fix where cPanel can make the record.
//   - Message control's Controlling (0172 §4.3): a kind, channel or sender paused and resumed (comms_controls).
//   - Overseers (0167 §2a): who reads which mailbox in their Pulse inbox.
// Every change is logged (comms_setup_log: who, when, which mailbox), never a password. Staging never writes .env or calls
// cPanel's mailbox API (CPanel/CPanelMail ask StagingGate::hold first; .env writes are refused here on staging).
declare(strict_types=1);

final class CommsSetup
{
    /** Senders: key => [name, .env prefix ('' = the SMTP_* system sender), default address, what goes from it, engine]. */
    public const SENDERS = [
        'system'   => ['The system sender', '', 'donotreply@traversence.com', 'Sign-in codes, account notices, receipts and the site\'s own messages.', 'bluehost'],
        'orders'   => ['Orders', 'ORDERS', 'orders@trvgo.us', 'Work orders to vendors and their updates.', 'bluehost'],
        'requests' => ['Visitors\' requests', 'REQUESTS', 'requests@traversence.com', 'A visitor\'s message to a listing no one has claimed yet, sent to the email the listing gives (decisions/0172 §3.3): its own sender, so a complaint never touches sign-in codes or receipts.', 'bluehost'],
        'ses_personal' => ['Amazon SES, personal', 'SES', 'notices@send.traversence.com', 'Notices by email and the backup when Bluehost refuses (decisions/0137 §8).', 'ses'],
        'ses_bulk' => ['Amazon SES, bulk', 'SESBULK', '', 'Businesses\' campaigns and offers: coming with the campaigns build.', 'coming'],
    ];

    /** Kinds of email and their default sender (0167 §1 Routing). */
    public const MAIL_KINDS = [
        'codes'           => ['Sign-in codes', 'One-time codes for members and staff.', 'system'],
        'notices'         => ['Account notices', 'Notices and the messages the dispatcher emails.', 'system'],
        'receipts'        => ['Receipts', 'Order and payment receipts.', 'system'],
        'work_orders'     => ['Work orders', 'Work orders to vendors and their updates.', 'orders'],
        'vendor'          => ['Vendor email', 'Other email with vendors.', 'orders'],
        'digests'         => ['Digests', 'The weekly email of notices.', 'ses_personal'],
        'campaigns'       => ['Campaigns', 'A business\'s offers and news to people who chose them (coming).', 'ses_bulk'],
        'listing_request' => ['Requests to unclaimed listings', 'A visitor\'s message sent to an unclaimed listing\'s public email.', 'requests'],
    ];

    /** The domains whose mail health is read (0167 §1). Zones hosted on Bluehost's nameservers. */
    public const DOMAINS = ['traversence.com' => 'traversence.com', 'trvgo.us' => 'trvgo.us', 'send.traversence.com' => 'traversence.com', 'via.traversence.com' => 'traversence.com'];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { foreach (['comms_routing', 'comms_overseers', 'comms_setup_log', 'comms_controls'] as $t) $pdo->query("SELECT 1 FROM $t LIMIT 0"); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    private static function env(string $k): string { require_once __DIR__ . '/EnvSettings.php'; return EnvSettings::value($k); }

    private static function onStaging(): bool
    {
        try { require_once __DIR__ . '/StagingGate.php'; return StagingGate::here(); } catch (Throwable) { return false; }
    }

    public static function log(PDO $pdo, ?int $uid, string $what, string $target, string $detail = ''): void
    {
        try { $pdo->prepare('INSERT INTO comms_setup_log (user_id, what, target, detail, created_at) VALUES (?, ?, ?, ?, ?)')->execute([$uid, mb_substr($what, 0, 40), mb_substr($target, 0, 190), mb_substr($detail, 0, 255), self::now()]); }
        catch (Throwable $e) { error_log('comms log: ' . $e->getMessage()); }
    }

    // ---- senders --------------------------------------------------------------------------------------------------------

    /** A sender's settings as Mailer reads them: [address, name, reply-to, host, port, login, has password, password key]. */
    public static function sender(string $key): array
    {
        $d = self::SENDERS[$key] ?? null;
        if (!$d) throw new InvalidArgumentException('No such sender.');
        $p = $d[1];
        if ($d[4] !== 'bluehost') return ['address' => $p === 'SES' ? (self::env('SES_FROM_EMAIL') ?: $d[2]) : $d[2], 'name' => '', 'reply_to' => '', 'host' => '', 'port' => 0, 'login' => '', 'has_password' => false, 'pw_key' => '', 'prefix' => $p, 'own_login' => false];
        $own = $p !== '' && self::env($p . '_SMTP_USERNAME') !== '';
        $g = fn (string $k) => $p !== '' ? self::env($p . '_' . $k) : '';
        $login = $own ? $g('SMTP_USERNAME') : self::env('SMTP_USERNAME');
        $pwKey = $own ? $p . '_SMTP_PASSWORD' : 'SMTP_PASSWORD';
        return ['address' => ($p !== '' ? $g('FROM_EMAIL') : self::env('SMTP_FROM_EMAIL')) ?: ($p === '' ? $login : '') ?: $d[2],
            'name' => ($p !== '' ? $g('FROM_NAME') : self::env('SMTP_FROM_NAME')) ?: 'Traversence',
            'reply_to' => ($p !== '' ? $g('REPLY_TO') : '') ?: self::env('SMTP_REPLY_TO') ?: 'support@traversence.com',
            'host' => ($own ? $g('SMTP_HOST') : '') ?: self::env('SMTP_HOST'), 'port' => (int) ((($own ? $g('SMTP_PORT') : '') ?: self::env('SMTP_PORT')) ?: 587),
            'login' => $login, 'has_password' => self::env($pwKey) !== '', 'pw_key' => $pwKey, 'prefix' => $p, 'own_login' => $own];
    }

    /** The .env prefix Mailer::send takes for a kind of email, by the routing table ('' = the system sender). */
    public static function prefixFor(string $mailKind, ?PDO $pdo = null): string
    {
        $key = self::MAIL_KINDS[$mailKind][2] ?? 'system';
        try {
            $pdo = $pdo ?? Database::connection();
            if (self::ready($pdo)) { $st = $pdo->prepare('SELECT sender_key FROM comms_routing WHERE mail_kind = ?'); $st->execute([$mailKind]); $key = (string) ($st->fetchColumn() ?: $key); }
        } catch (Throwable) {}
        $d = self::SENDERS[$key] ?? self::SENDERS['system'];
        return $d[4] === 'bluehost' ? $d[1] : '';   // SES senders aren't Mailer's: their kinds go through SesMail as before
    }

    /** Check: signs in to the mail server without sending. '' when it signs in, else the exact refusal. */
    public static function check(PDO $pdo, string $key, ?int $uid = null): string
    {
        $s = self::sender($key);
        if (self::SENDERS[$key][4] === 'ses') {
            require_once __DIR__ . '/SesMail.php';
            $why = SesMail::hasKeys('personal') ? '' : 'Amazon SES\'s keys aren\'t in .env yet.';
        } elseif (self::SENDERS[$key][4] !== 'bluehost') {
            return 'Coming: nothing to check yet.';
        } elseif ($s['host'] === '' || $s['login'] === '' || !$s['has_password']) {
            $why = 'Not set up: ' . ($s['host'] === '' ? 'the server' : ($s['login'] === '' ? 'the mailbox it signs in with' : 'its password')) . ' isn\'t in .env.';
        } else {
            require_once __DIR__ . '/MailSmtp.php';
            $why = MailSmtp::check(['host' => $s['host'], 'port' => $s['port'], 'login' => $s['login'], 'password' => self::env($s['pw_key'])]);
        }
        self::log($pdo, $uid, $why === '' ? 'check_ok' : 'check_failed', $key, $why === '' ? 'Signed in' : $why);
        if ($why === '' && $s['pw_key'] !== '') { require_once __DIR__ . '/EnvSettings.php'; try { if (EnvSettings::hasOld($s['pw_key'])) EnvSettings::forgetOld($s['pw_key']); } catch (Throwable) {} }
        return $why;
    }

    /** Send me a test: to the signed-in staff member. Returns what to say. */
    public static function test(PDO $pdo, string $key, string $to, ?int $uid): string
    {
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Your account has no email address to send the test to.');
        $d = self::SENDERS[$key] ?? null;
        if (!$d || $d[4] === 'coming') throw new InvalidArgumentException('That sender isn\'t built yet.');
        $body = "This is a test from System Configuration → Communications, sent from \"" . $d[0] . "\".\n\nIf it reached you, this sender works.\n\nTraversence";
        if ($d[4] === 'ses') {
            require_once __DIR__ . '/SesMail.php';
            $r = SesMail::send($pdo, ['account' => 'personal', 'from_local' => 'notices', 'from_domain' => 'send.traversence.com', 'from_name' => 'Traversence', 'to' => $to, 'to_name' => '',
                'subject' => 'Test: ' . $d[0], 'text' => $body, 'html' => '', 'sender' => 'traversence', 'purpose' => 'site_email', 'scope' => 'site_email', 'why' => 'A test you asked for in Communications.']);
            $ok = (($r['status'] ?? '') === 'sent');
            self::log($pdo, $uid, 'test', $key, $ok ? 'Sent' : 'Not sent: ' . (string) ($r['status'] ?? '?'));
            if (!$ok) throw new RuntimeException('Amazon SES didn\'t send it (' . (string) ($r['status'] ?? 'no answer') . ').');
            return 'Test sent by Amazon SES to ' . $to . '.';
        }
        require_once __DIR__ . '/Mailer.php';
        Mailer::send($to, 'Test: ' . $d[0] . ' · Traversence', $body, null, $d[1]);
        self::log($pdo, $uid, 'test', $key, 'Sent');
        return 'Test sent from ' . self::sender($key)['address'] . ' to ' . $to . '. If it doesn\'t arrive in a few minutes, press Check.';
    }

    /** The sender's last send and last failure, from the route (0167: "last sent, last failure"). */
    public static function lastOf(PDO $pdo, string $key): array
    {
        $out = ['sent' => null, 'failed' => null, 'failed_why' => '', 'sent_24h' => 0, 'failed_24h' => 0];
        try {
            $st = $pdo->prepare("SELECT stage, MAX(happened_at) AS at, SUM(happened_at > ?) AS n FROM comms_route WHERE via = 'email' AND sender_key = ? AND stage IN ('sent','failed') GROUP BY stage");
            $st->execute([date('Y-m-d H:i:s', time() - 86400), $key]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $out[$r['stage']] = (string) $r['at']; $out[$r['stage'] . '_24h'] = (int) $r['n']; }
            if ($out['failed']) { $st = $pdo->prepare("SELECT detail FROM comms_route WHERE via = 'email' AND sender_key = ? AND stage = 'failed' ORDER BY id DESC LIMIT 1"); $st->execute([$key]); $out['failed_why'] = (string) $st->fetchColumn(); }
        } catch (Throwable) {}
        return $out;
    }

    /** A send failed (Mailer): its sender's overseers hear it in Pulse, once an hour at most per sender, with Check again in it. */
    public static function sendFailed(PDO $pdo, string $sender, string $why): void
    {
        if (!isset(self::SENDERS[$sender])) $sender = 'system';
        $s = self::sender($sender);
        $addr = $s['address'];
        $to = self::overseersOf($pdo, $s['login'] !== '' ? $s['login'] : $addr);   // who reads the mailbox it signs in with
        if (!$to) $to = self::founders($pdo);
        if (!$to) return;
        require_once __DIR__ . '/Notify.php';
        Notify::send($pdo, 'mail.failure', ['staff' => $to], ['thing' => 'mailfail:' . $sender . ':' . date('YmdH'), 'url' => '/admin/config/communications#cs-' . $sender, 'from' => ['system', null, 'Communications']],
            ['title' => 'Email from ' . $addr . ' failed', 'body' => 'The mail server said: ' . mb_substr(trim($why), 0, 300)]);
    }

    /** The message body in Pulse for a mail failure: where it stands now, and Check again (0172 "The message"). */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
        $key = preg_match('/^mailfail:([a-z_]+):/', (string) $m['thing'], $x) ? $x[1] : 'system';
        $last = self::lastOf($pdo, $key);
        $fine = $last['sent'] && (!$last['failed'] || $last['sent'] > $last['failed']);
        $state = $fine ? 'Sending again since ' . $last['sent'] . '.' : 'Still failing: ' . ($last['failed_why'] ?: 'see the sender\'s card') . '.';
        $html = '<p>' . $e($m['body']) . '</p><p data-tv-status="' . ($fine ? 'ok' : 'bad') . '" data-tv-label="' . ($fine ? 'Working:' : 'Failing:') . '">' . $e($state) . '</p>'
              . '<p class="tv-msg-acts"><button type="button" class="tv-btn" data-msg-act="/admin/api/comms.php" data-msg-body=\'' . $e(json_encode(['action' => 'check', 'sender' => $key, 'from_msg' => (int) $m['id']])) . '\'>Check again</button> '
              . '<a class="tv-btn ghost" href="/admin/config/communications#cs-' . $e($key) . '" data-peek-frame>Its card</a></p>';
        return ['html' => $html, 'state' => $state];
    }

    // ---- sender settings: address, name, reply-to, server, login (EnvSettings) -----------------------------------------------

    /** The .env keys a sender's card edits: [field => key]. */
    public static function fields(string $key): array
    {
        $d = self::SENDERS[$key] ?? null;
        if (!$d || $d[4] !== 'bluehost') return [];
        $p = $d[1];
        if ($p === '') return ['address' => 'SMTP_FROM_EMAIL', 'name' => 'SMTP_FROM_NAME', 'reply_to' => 'SMTP_REPLY_TO', 'host' => 'SMTP_HOST', 'port' => 'SMTP_PORT', 'login' => 'SMTP_USERNAME'];
        return ['address' => $p . '_FROM_EMAIL', 'name' => $p . '_FROM_NAME', 'reply_to' => $p . '_REPLY_TO', 'host' => $p . '_SMTP_HOST', 'port' => $p . '_SMTP_PORT', 'login' => $p . '_SMTP_USERNAME'];
    }

    public static function setField(PDO $pdo, string $key, string $field, string $value, ?int $uid): string
    {
        if (self::onStaging()) throw new RuntimeException('Staging never changes .env: change it on the live site.');
        $k = self::fields($key)[$field] ?? '';
        if ($k === '') throw new InvalidArgumentException('That can\'t be changed here.');
        require_once __DIR__ . '/EnvSettings.php';
        [$before, $after] = EnvSettings::set($k, $value);
        self::log($pdo, $uid, 'field', $key, $field . ': ' . ($before === '' ? '(empty)' : $before) . ' → ' . ($after === '' ? '(empty)' : $after));
        return EnvSettings::EDITABLE[$k][0] . ($after === '' ? ' cleared.' : ' saved.');
    }

    // ---- mailboxes on cPanel (every domain) -------------------------------------------------------------------------------

    /** Every mailbox on the account: [[email, domain, used MB, quota MB, suspended, kind (system|staff|inbox), overseers]]. */
    public static function mailboxes(PDO $pdo): array
    {
        require_once __DIR__ . '/CPanel.php';
        $rows = (array) CPanel::uapi('Email', 'list_pops_with_disk', []);
        $system = [];
        foreach (array_keys(self::SENDERS) as $k) { $s = self::sender($k); if ($s['login'] !== '') $system[strtolower($s['login'])] = $k; if ($s['address'] !== '') $system[strtolower($s['address'])] = $system[strtolower($s['address'])] ?? $k; }
        $staff = [];
        try { foreach ($pdo->query("SELECT LOWER(email) AS e, name FROM " . Database::t('staff_accounts') . " WHERE email <> ''")->fetchAll(PDO::FETCH_ASSOC) as $s) $staff[$s['e']] = (string) $s['name']; } catch (Throwable) {}
        $ov = self::overseersAll($pdo);
        $out = [];
        foreach ($rows as $r) {
            $em = strtolower((string) ($r['email'] ?? ($r['login'] ?? '')));
            if ($em === '' || !str_contains($em, '@')) continue;
            $out[] = ['email' => $em, 'domain' => (string) ($r['domain'] ?? explode('@', $em)[1]),
                'used' => round((float) ($r['diskused'] ?? 0), 1), 'quota' => is_numeric($r['diskquota'] ?? null) ? (float) $r['diskquota'] : 0.0,
                'suspended' => !empty($r['suspended_login']) || !empty($r['suspended_incoming']),
                'kind' => isset($system[$em]) ? 'system' : (isset($staff[$em]) ? 'staff' : 'inbox'), 'sender' => $system[$em] ?? '', 'staff_name' => $staff[$em] ?? '',
                'overseers' => $ov[$em] ?? []];
        }
        usort($out, fn ($a, $b) => [$a['domain'], $a['email']] <=> [$b['domain'], $b['email']]);
        return $out;
    }

    /** cPanel's domains with mail (for Make a mailbox's domain choice). */
    public static function domains(): array
    {
        require_once __DIR__ . '/CPanel.php';
        $out = [];
        try { foreach ((array) CPanel::uapi('Email', 'list_mail_domains', []) as $d) if (!empty($d['domain'])) $out[] = (string) $d['domain']; } catch (Throwable $e) { $out = ['traversence.com', 'trvgo.us']; }
        return array_values(array_unique($out));
    }

    /** A password: the one typed (checked against a strength rule like cPanel's) or a strong one made by the site. */
    private static function password(string $typed): string
    {
        if ($typed === '') return self::madePassword();
        if (strlen($typed) < 12 || !preg_match('/[a-z]/', $typed) || !preg_match('/[A-Z]/', $typed) || !preg_match('/\d/', $typed) || !preg_match('/[^A-Za-z0-9]/', $typed))
            throw new InvalidArgumentException('Use at least 12 characters with a lower-case and a capital letter, a number and a symbol (cPanel refuses weaker ones).');
        if (preg_match('/["\\\\\r\n\s]/', $typed)) throw new InvalidArgumentException('No spaces, quotes or backslashes: the password has to fit in .env.');
        return $typed;
    }

    private static function madePassword(): string
    {
        $sets = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnpqrstuvwxyz', '23456789', '!%+=?@'];
        $all = implode('', $sets); $p = '';
        foreach ($sets as $set) $p .= $set[random_int(0, strlen($set) - 1)];
        for ($i = 0; $i < 18; $i++) $p .= $all[random_int(0, strlen($all) - 1)];
        $a = str_split($p);
        for ($i = count($a) - 1; $i > 0; $i--) { $j = random_int(0, $i); [$a[$i], $a[$j]] = [$a[$j], $a[$i]]; }
        return implode('', $a);
    }

    /** The sender (if any) whose mailbox this is, so its new password goes into .env: the sender key, or ''. */
    private static function senderOfMailbox(string $email): string
    {
        foreach (array_keys(self::SENDERS) as $k) { $s = self::sender($k); if ($s['login'] !== '' && strtolower($s['login']) === strtolower($email) && $s['pw_key'] !== '') return $k; }
        return '';
    }

    /**
     * Make, suspend, unsuspend or reset a mailbox (owner-level, checked by the caller). Returns what to say. A reset of a
     * sender's mailbox writes the new password to .env for that sender and runs Check at once (0167 §4).
     */
    public static function mailboxDo(PDO $pdo, string $act, string $email, string $typed, ?int $uid): string
    {
        if (self::onStaging()) throw new RuntimeException('Staging never changes mailboxes: do it on the live site.');
        $email = strtolower(trim($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Write the whole address, like support@traversence.com.');
        require_once __DIR__ . '/CPanelMail.php';
        [$local, $domain] = explode('@', $email, 2);
        switch ($act) {
            case 'make':
                if (!in_array($domain, self::domains(), true)) throw new InvalidArgumentException($domain . ' isn\'t a domain on our cPanel account.');
                $pw = self::password($typed);
                CPanelMail::createWith($email, $pw);
                self::log($pdo, $uid, 'mailbox_made', $email, $typed === '' ? 'password made by the site' : 'password typed');
                $said = $email . ' is made.';
                break;
            case 'suspend': CPanelMail::suspend($email); self::log($pdo, $uid, 'mailbox_suspended', $email); return $email . ' can\'t sign in now; its mail is kept. Unsuspend lets it in again.';
            case 'unsuspend': CPanelMail::unsuspend($email); self::log($pdo, $uid, 'mailbox_unsuspended', $email); return $email . ' can sign in again.';
            case 'reset':
                $pw = self::password($typed);
                CPanelMail::setPassword($email, $pw);
                self::log($pdo, $uid, 'mailbox_reset', $email, $typed === '' ? 'password made by the site' : 'password typed');
                $said = $email . '\'s password is changed.';
                break;
            default: throw new InvalidArgumentException('Unknown action.');
        }
        $sk = self::senderOfMailbox($email);
        if ($sk !== '') {   // the sender signs in with it: the new password goes straight into .env, then Check
            require_once __DIR__ . '/EnvSettings.php';
            EnvSettings::setMailSecret(self::sender($sk)['pw_key'], $pw);
            self::log($pdo, $uid, 'env_written', $sk, self::sender($sk)['pw_key'] . ' written (the old one kept until Check passes)');
            $why = self::check($pdo, $sk, $uid);
            $said .= $why === '' ? ' It\'s written into .env for "' . self::SENDERS[$sk][0] . '" and Check signed in.' : ' It\'s written into .env for "' . self::SENDERS[$sk][0] . '", but Check failed: ' . $why . ' Undo puts the old one back.';
        } else {
            $said .= ' The password isn\'t shown: open its webmail with Reset again if someone needs to sign in, or connect it to an inbox in Pulse.';
        }
        return $said;
    }

    /** Undo a reset whose Check failed: the kept old password goes back into .env and into cPanel. */
    public static function undoReset(PDO $pdo, string $sender, ?int $uid): string
    {
        if (self::onStaging()) throw new RuntimeException('Staging never changes .env.');
        $s = self::sender($sender);
        require_once __DIR__ . '/EnvSettings.php';
        $text = (string) @file_get_contents(Database::envPath());
        if (!preg_match('/^# OLD ' . preg_quote($s['pw_key'], '/') . ' \S+: (.*)$/m', $text, $m)) throw new InvalidArgumentException('There\'s no earlier password kept for it.');
        require_once __DIR__ . '/CPanelMail.php';
        CPanelMail::setPassword($s['login'], trim($m[1]));
        EnvSettings::putBack($s['pw_key']);
        self::log($pdo, $uid, 'reset_undone', $sender);
        $why = self::check($pdo, $sender, $uid);
        return 'The old password is back.' . ($why === '' ? ' Check signed in.' : ' Check still fails: ' . $why);
    }

    /** A sender's password typed by an owner (when the mailbox isn't on our cPanel, or to fix .env by hand). */
    public static function setPasswordOnly(PDO $pdo, string $sender, string $typed, ?int $uid): string
    {
        if (self::onStaging()) throw new RuntimeException('Staging never changes .env.');
        $s = self::sender($sender);
        if ($s['pw_key'] === '') throw new InvalidArgumentException('That sender has no password.');
        if ($typed === '') throw new InvalidArgumentException('Type the mailbox\'s password.');
        require_once __DIR__ . '/EnvSettings.php';
        EnvSettings::setMailSecret($s['pw_key'], $typed);
        self::log($pdo, $uid, 'env_written', $sender, $s['pw_key'] . ' typed (the old one kept until Check passes)');
        $why = self::check($pdo, $sender, $uid);
        return $why === '' ? 'Saved, and Check signed in.' : 'Saved, but Check failed: ' . $why . ' Undo puts the old one back.';
    }

    // ---- routing ------------------------------------------------------------------------------------------------------------

    /** [mail kind => sender key], with the defaults. */
    public static function routing(PDO $pdo): array
    {
        $out = array_map(fn ($d) => $d[2], self::MAIL_KINDS);
        if (self::ready($pdo)) foreach ($pdo->query('SELECT mail_kind, sender_key FROM comms_routing')->fetchAll(PDO::FETCH_KEY_PAIR) as $k => $v) if (isset($out[$k]) && isset(self::SENDERS[$v])) $out[$k] = $v;
        return $out;
    }

    public static function setRoute(PDO $pdo, string $kind, string $sender, ?int $uid): string
    {
        if (!isset(self::MAIL_KINDS[$kind]) || !isset(self::SENDERS[$sender])) throw new InvalidArgumentException('Unknown kind or sender.');
        if (self::SENDERS[$sender][4] === 'coming') throw new InvalidArgumentException('That sender isn\'t built yet.');
        $pdo->prepare('INSERT INTO comms_routing (mail_kind, sender_key, changed_by, changed_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE sender_key = VALUES(sender_key), changed_by = VALUES(changed_by), changed_at = VALUES(changed_at)')
            ->execute([$kind, $sender, $uid, self::now()]);
        self::log($pdo, $uid, 'route', $kind, '→ ' . $sender);
        return self::MAIL_KINDS[$kind][0] . ' now go from "' . self::SENDERS[$sender][0] . '".';
    }

    // ---- domain health (SPF, DKIM, DMARC through cPanel) -------------------------------------------------------------------

    /** [[domain, check (SPF|DKIM|DMARC), ok, what we found, can fix]]. */
    public static function domainHealth(): array
    {
        require_once __DIR__ . '/CPanel.php';
        $out = [];
        foreach (self::DOMAINS as $dom => $zone) {
            $rel = $dom === $zone ? '@' : substr($dom, 0, -strlen($zone) - 1);
            try { $txt = array_values(array_map(fn ($r) => trim($r[1], '"'), array_filter(CPanel::records($zone, $rel), fn ($r) => $r[0] === 'TXT'))); }
            catch (Throwable $e) { $out[] = [$dom, 'DNS', false, $e->getMessage(), false]; continue; }
            $spf = array_values(array_filter($txt, fn ($t) => stripos($t, 'v=spf1') === 0));
            $out[] = [$dom, 'SPF', count($spf) === 1, $spf ? implode(' | ', $spf) : 'No SPF record', $dom === $zone];
            try { $dm = array_values(array_filter(array_map(fn ($r) => trim($r[1], '"'), array_filter(CPanel::records($zone, '_dmarc' . ($rel === '@' ? '' : '.' . $rel)), fn ($r) => $r[0] === 'TXT')), fn ($t) => stripos($t, 'v=DMARC1') === 0)); }
            catch (Throwable) { $dm = []; }
            $out[] = [$dom, 'DMARC', count($dm) === 1, $dm ? $dm[0] : 'No DMARC record', true];
            if ($dom === $zone) {   // DKIM for the domains Bluehost sends for; SES's own (send., via.) are set by SesMail's setup (0137 §8)
                try { $dk = (array) CPanel::uapi('EmailAuth', 'validate_current_dkims', ['domain' => $dom]); $st = (string) (($dk[0]['state'] ?? '') ?: ''); $out[] = [$dom, 'DKIM', strtoupper($st) === 'VALID', $st !== '' ? $st : 'Not read', strtoupper($st) !== 'VALID']; }
                catch (Throwable $e) { $out[] = [$dom, 'DKIM', false, $e->getMessage(), true]; }
            }
        }
        return $out;
    }

    /** The fix button: cPanel makes the record. DMARC starts at p=none (reports only), so nothing legitimate is refused. */
    public static function domainFix(PDO $pdo, string $dom, string $what, ?int $uid): string
    {
        if (self::onStaging()) throw new RuntimeException('Staging never changes DNS.');
        if (!isset(self::DOMAINS[$dom])) throw new InvalidArgumentException('Not one of our mail domains.');
        require_once __DIR__ . '/CPanel.php';
        $zone = self::DOMAINS[$dom];
        switch ($what) {
            case 'SPF': if ($dom !== $zone) throw new InvalidArgumentException('Amazon SES\'s setup makes that one: System Configuration → Outside services → Amazon.'); CPanel::uapi('EmailAuth', 'install_spf_records', ['domain' => $dom]); break;
            case 'DKIM': CPanel::uapi('EmailAuth', 'enable_dkim', ['domain' => $dom]); break;
            case 'DMARC':
                $rel = '_dmarc' . ($dom === $zone ? '' : '.' . substr($dom, 0, -strlen($zone) - 1));
                CPanel::dnsEnsure($zone, [[$rel, 'TXT', 'v=DMARC1; p=none; rua=mailto:postmaster@' . $zone, 'one']]);
                break;
            default: throw new InvalidArgumentException('Unknown record.');
        }
        self::log($pdo, $uid, 'dns_fixed', $dom, $what);
        return $what . ' for ' . $dom . ' is set. DNS can take up to an hour to show it everywhere.';
    }

    // ---- overseers (0167 §2a) -------------------------------------------------------------------------------------------------

    private static function overseersAll(PDO $pdo): array
    {
        $out = [];
        if (!self::ready($pdo)) return $out;
        foreach ($pdo->query('SELECT mailbox, user_id FROM comms_overseers')->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['mailbox']][] = (int) $r['user_id'];
        return $out;
    }

    public static function overseersOf(PDO $pdo, string $mailbox): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT user_id FROM comms_overseers WHERE mailbox = ?'); $st->execute([strtolower($mailbox)]);
        return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }

    /** The mailboxes this person oversees (their own staff mailbox always theirs). */
    public static function oversees(PDO $pdo, int $uid): array
    {
        $out = [];
        if (self::ready($pdo)) { $st = $pdo->prepare('SELECT mailbox FROM comms_overseers WHERE user_id = ?'); $st->execute([$uid]); $out = $st->fetchAll(PDO::FETCH_COLUMN); }
        try { $st = $pdo->prepare("SELECT LOWER(email) FROM " . Database::t('staff_accounts') . " WHERE user_id = ? AND status = 'active' AND email <> ''"); $st->execute([$uid]); if ($own = $st->fetchColumn()) $out[] = $own; } catch (Throwable) {}
        return array_values(array_unique(array_map('strtolower', $out)));
    }

    public static function setOverseer(PDO $pdo, string $mailbox, int $user, bool $on, ?int $by): string
    {
        $mailbox = strtolower(trim($mailbox));
        if (!filter_var($mailbox, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Not a mailbox.');
        $st = $pdo->prepare("SELECT name FROM " . Database::t('staff_accounts') . " WHERE user_id = ? AND status = 'active'"); $st->execute([$user]);
        $name = $st->fetchColumn();
        if ($name === false) throw new InvalidArgumentException('Only an active staff member can oversee a mailbox.');
        if ($on) $pdo->prepare('INSERT IGNORE INTO comms_overseers (mailbox, user_id, added_by, added_at) VALUES (?, ?, ?, ?)')->execute([$mailbox, $user, $by, self::now()]);
        else $pdo->prepare('DELETE FROM comms_overseers WHERE mailbox = ? AND user_id = ?')->execute([$mailbox, $user]);
        self::log($pdo, $by, $on ? 'overseer_added' : 'overseer_removed', $mailbox, (string) $name);
        return $on ? $name . ' now reads ' . $mailbox . ' in their Pulse inbox.' : $name . ' no longer reads ' . $mailbox . '.';
    }

    /** The Founder(s): who hears when no one oversees a mailbox. */
    public static function founders(PDO $pdo): array
    {
        $out = [];
        try {
            require_once __DIR__ . '/Workspaces.php';
            foreach ($pdo->query("SELECT * FROM " . Database::t('staff_accounts') . " WHERE status = 'active' AND user_id IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC) as $s)
                if (Workspaces::levelOf($s)[0] === 'founder') $out[] = (int) $s['user_id'];
        } catch (Throwable) {}
        return $out;
    }

    // ---- message control: pause and resume (0172 §4.3) ----------------------------------------------------------------------

    /** ckey: 'kind:<kind>', 'channel:<email|push>', 'sender:<key>'. */
    public static function paused(PDO $pdo, string $ckey): bool
    {
        if (!self::ready($pdo)) return false;
        try { $st = $pdo->prepare('SELECT paused FROM comms_controls WHERE ckey = ?'); $st->execute([$ckey]); return (bool) (int) ($st->fetchColumn() ?: 0); } catch (Throwable) { return false; }
    }

    public static function pause(PDO $pdo, string $ckey, string $why, ?int $by): void
    {
        $pdo->prepare('INSERT INTO comms_controls (ckey, paused, why, by_user, changed_at) VALUES (?, 1, ?, ?, ?) ON DUPLICATE KEY UPDATE paused = 1, why = VALUES(why), by_user = VALUES(by_user), changed_at = VALUES(changed_at)')
            ->execute([mb_substr($ckey, 0, 60), mb_substr($why, 0, 255), $by, self::now()]);
        self::log($pdo, $by, 'paused', $ckey, $why);
        if ($by === null) {   // paused by itself: an owner hears, with Resume in the message
            require_once __DIR__ . '/Notify.php';
            Notify::send($pdo, 'mail.failure', ['staff' => self::founders($pdo)], ['thing' => 'paused:' . $ckey . ':' . date('Ymd'), 'url' => '/admin/config/communications#cs-controls', 'from' => ['system', null, 'Message control']],
                ['title' => 'Paused by itself: ' . $ckey, 'body' => $why . ' Resume it in System Configuration → Communications.']);
        }
    }

    public static function resume(PDO $pdo, string $ckey, ?int $by): void
    {
        $pdo->prepare('UPDATE comms_controls SET paused = 0, why = ?, by_user = ?, changed_at = ? WHERE ckey = ?')->execute(['Resumed', $by, self::now(), $ckey]);
        self::log($pdo, $by, 'resumed', $ckey);
    }

    /** [{ckey, paused, why, by, at}] */
    public static function controls(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [];
        return $pdo->query('SELECT c.ckey, c.paused, c.why, c.changed_at, u.display_name FROM comms_controls c LEFT JOIN users u ON u.id = c.by_user ORDER BY c.paused DESC, c.changed_at DESC')->fetchAll(PDO::FETCH_ASSOC);
    }

    // ---- reporting: the Sent view and the counts (0167 §2, 0172 §4.3) --------------------------------------------------------

    /** The Sent view: everything the site sent by email, newest first: [{at, sender, subject, stage, detail, kind}]. */
    public static function sent(PDO $pdo, string $q = '', string $stage = '', int $limit = 100, int $before = 0): array
    {
        $w = ["r.via = 'email'", "r.stage IN ('sent','failed','held','bounced','complained','stopped','skipped')"]; $a = [];
        if ($stage !== '' && in_array($stage, ['sent', 'failed', 'held', 'bounced', 'complained', 'stopped', 'skipped'], true)) { $w[] = 'r.stage = ?'; $a[] = $stage; }
        if ($before > 0) { $w[] = 'r.id < ?'; $a[] = $before; }
        if ($q !== '') { $w[] = '(COALESCE(r.subject, m.title) LIKE ? OR r.detail LIKE ?)'; $a[] = '%' . $q . '%'; $a[] = '%' . $q . '%'; }
        $st = $pdo->prepare('SELECT r.id, r.message_id, r.stage, r.detail, r.happened_at, COALESCE(r.sender_key, \'\') AS sender_key, COALESCE(r.subject, m.title, \'\') AS subject, COALESCE(r.mail_kind, m.kind, \'\') AS kind
                              FROM comms_route r LEFT JOIN comms_messages m ON m.id = r.message_id AND r.message_id > 0 WHERE ' . implode(' AND ', $w) . ' ORDER BY r.id DESC LIMIT ' . max(1, min(300, $limit)));
        $st->execute($a);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Message control's report: per channel and stage, the last 7 days. [[via, stage, n]] */
    public static function report(PDO $pdo, int $days = 7): array
    {
        $st = $pdo->prepare('SELECT via, stage, COUNT(*) AS n FROM comms_route WHERE happened_at > ? GROUP BY via, stage ORDER BY via, stage');
        $st->execute([date('Y-m-d H:i:s', time() - $days * 86400)]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** The setup log, newest first. */
    public static function history(PDO $pdo, int $limit = 30): array
    {
        if (!self::ready($pdo)) return [];
        return $pdo->query('SELECT l.what, l.target, l.detail, l.created_at, u.display_name FROM comms_setup_log l LEFT JOIN users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT ' . max(1, min(200, $limit)))->fetchAll(PDO::FETCH_ASSOC);
    }
}
