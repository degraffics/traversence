<?php
// app/lib/MailSmtp.php — sends a message through a connected mailbox's own SMTP server, with that mailbox's own sign-in
// (decisions/0172 §4.7: a reply from Pulse goes out from the person's real address), and checks a mailbox's SMTP sign-in
// without sending (Communications' Check, and the system mailbox's: MailSmtp::check(['host' => getenv('SMTP_HOST'), …])).
// Unlike Mailer, which sends the site's own mail with the .env mailbox, the credentials come from the caller. Port 587
// upgrades with STARTTLS, 465 is TLS from the start; AUTH PLAIN or LOGIN, whichever the server offers. A plain socket, in
// Mailer's style. Staging never sends (StagingGate::hold, 0165). Refusals are thrown in plain words; the password is
// never logged or repeated.
declare(strict_types=1);

final class MailSmtp
{
    private const TIMEOUT = 20;

    /** For tests only: function (string $host, int $port, bool $tls): resource, used in place of the network. */
    public static ?Closure $open = null;
    /** For tests only: function ($stream): bool, used in place of the TLS upgrade after STARTTLS. */
    public static ?Closure $starttls = null;

    /**
     * Sends $raw (a whole message, e.g. MailMime::build()) from $from to every address in $rcpts. $c: host, port (587 by
     * default), login, password. A refused recipient stops the send before anything goes out, naming the address.
     */
    public static function send(array $c, string $from, array $rcpts, string $raw): void
    {
        $rcpts = array_values(array_unique(array_filter(array_map(fn ($r) => trim(is_array($r) ? (string) ($r['addr'] ?? $r[0] ?? '') : (string) $r), $rcpts), fn ($r) => $r !== '')));
        if (!$rcpts) throw new RuntimeException('The message has no one to send to.');
        foreach (array_merge([$from], $rcpts) as $a) {
            if (preg_match('/[\r\n<>\s]/', $a) || !str_contains($a, '@')) throw new RuntimeException('"' . mb_substr($a, 0, 80) . '" isn\'t an email address.');
        }
        [$s, $ehlo] = self::open($c, 'send from ' . $from);
        try {
            self::auth($s, $ehlo, $c);
            $r = self::cmd($s, 'MAIL FROM:<' . $from . '>');
            if ($r[0] !== 250) throw new RuntimeException(self::refusal($r, $c, 'from'));
            $refused = [];
            foreach ($rcpts as $to) {
                $r = self::cmd($s, 'RCPT TO:<' . $to . '>');
                if ($r[0] !== 250 && $r[0] !== 251) $refused[] = $to . ' (' . self::clean($r[1]) . ')';
            }
            if ($refused) {
                try { self::cmd($s, 'RSET'); } catch (Throwable $e) {}
                throw new RuntimeException('The mail server wouldn\'t send to ' . implode(', ', $refused) . ', so nothing was sent.');
            }
            $r = self::cmd($s, 'DATA');
            if ($r[0] !== 354) throw new RuntimeException(self::refusal($r, $c, 'data'));
            self::write($s, self::dots($raw) . "\r\n.\r\n");
            $r = self::read($s);
            if ($r[0] !== 250) throw new RuntimeException(self::refusal($r, $c, 'data'));
            try { self::cmd($s, 'QUIT'); } catch (Throwable $e) {}   // the server has it: a failed goodbye isn't a failed send
        } finally {
            if (is_resource($s)) @fclose($s);
        }
    }

    /** Connects, says hello, encrypts, signs in and leaves without sending: '' when all of that works, else the exact refusal. */
    public static function check(array $c): string
    {
        try {
            [$s, $ehlo] = self::open($c, 'check ' . (string) ($c['login'] ?? ''));
            try {
                self::auth($s, $ehlo, $c);
                try { self::cmd($s, 'QUIT'); } catch (Throwable $e) {}
            } finally {
                if (is_resource($s)) @fclose($s);
            }
            return '';
        } catch (Throwable $e) {
            return $e->getMessage();
        }
    }

    // ---- inside -------------------------------------------------------------------------------------------------------

    /** [the connection, greeted, EHLO'd and encrypted; the EHLO reply] */
    private static function open(array $c, string $what): array
    {
        $host = strtolower(trim((string) ($c['host'] ?? '')));
        $port = (int) ($c['port'] ?? 0) ?: 587;
        if ($host === '') throw new RuntimeException('The outgoing (SMTP) server isn\'t set: add its name (e.g. smtp.example.com).');
        if ((string) ($c['login'] ?? '') === '' || (string) ($c['password'] ?? '') === '') throw new RuntimeException('The sign-in name or password for the outgoing server ' . $host . ' is missing: reconnect it.');
        if (!class_exists('StagingGate')) require_once __DIR__ . '/StagingGate.php';
        if (($w = StagingGate::hold('smtp://' . $host, 'Mail: ' . $what)) !== null) throw new RuntimeException($w);
        $tls = $port === 465;
        if (self::$open !== null) {
            $s = (self::$open)($host, $port, $tls);
        } else {
            $ctx = stream_context_create(['ssl' => ['peer_name' => $host, 'SNI_enabled' => true, 'verify_peer' => true, 'verify_peer_name' => true]]);
            $errno = 0; $errstr = '';
            $s = @stream_socket_client(($tls ? 'ssl' : 'tcp') . '://' . $host . ':' . $port, $errno, $errstr, self::TIMEOUT, STREAM_CLIENT_CONNECT, $ctx);
            if ($s === false) {
                if (!class_exists('MailImap')) require_once __DIR__ . '/MailImap.php';
                throw new RuntimeException(MailImap::connectError($host, $port, $errno, $errstr));
            }
        }
        if (!is_resource($s)) throw new RuntimeException('Port ' . $port . ' on ' . $host . ' is blocked or the server didn\'t answer.');
        stream_set_timeout($s, self::TIMEOUT);
        $r = self::read($s);
        if ($r[0] !== 220) {
            @fclose($s);
            throw new RuntimeException($r[0] === 554 || $r[0] === 421
                ? 'The outgoing server ' . $host . ' turned the connection away (it said "' . self::clean($r[1]) . '").'
                : 'That isn\'t an SMTP mail server at ' . $host . ':' . $port . ' (it said "' . self::clean($r[1]) . '").');
        }
        $r = self::cmd($s, 'EHLO ' . self::me());
        if ($r[0] !== 250) throw new RuntimeException('The outgoing server ' . $host . ' wouldn\'t talk to us (it said "' . self::clean($r[1]) . '").');
        if (!$tls) {
            if (!preg_match('/^250[ -]STARTTLS\b/mi', $r[1])) throw new RuntimeException('The outgoing server ' . $host . ' doesn\'t offer encryption on port ' . $port . ': use port 587 or 465.');
            $x = self::cmd($s, 'STARTTLS');
            if ($x[0] !== 220) throw new RuntimeException('The outgoing server ' . $host . ' refused encryption (it said "' . self::clean($x[1]) . '").');
            $ok = self::$starttls !== null ? (bool) (self::$starttls)($s) : @stream_socket_enable_crypto($s, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if (!$ok) throw new RuntimeException('A secure connection to ' . $host . ' couldn\'t be made (its certificate or encryption was refused).');
            $r = self::cmd($s, 'EHLO ' . self::me());   // again after STARTTLS (RFC 3207)
            if ($r[0] !== 250) throw new RuntimeException('The outgoing server ' . $host . ' wouldn\'t talk to us (it said "' . self::clean($r[1]) . '").');
        }
        return [$s, $r[1]];
    }

    /** AUTH PLAIN when offered, else LOGIN. */
    private static function auth($s, string $ehlo, array $c): void
    {
        $mechs = preg_match('/^250[ -]AUTH[ =](.*)$/mi', $ehlo, $m) ? array_map('strtoupper', preg_split('/\s+/', trim($m[1])) ?: []) : [];
        $login = (string) $c['login']; $pw = (string) $c['password'];
        if (in_array('PLAIN', $mechs, true) || !in_array('LOGIN', $mechs, true)) {
            $r = self::cmd($s, 'AUTH PLAIN ' . base64_encode("\0" . $login . "\0" . $pw));
            if ($r[0] === 235) return;
            if (!in_array('LOGIN', $mechs, true) || ($r[0] !== 504 && $r[0] !== 500 && $r[0] !== 501)) throw new RuntimeException(self::refusal($r, $c, 'auth'));
        }
        $r = self::cmd($s, 'AUTH LOGIN');
        if ($r[0] === 334) $r = self::cmd($s, base64_encode($login));
        if ($r[0] === 334) $r = self::cmd($s, base64_encode($pw));
        if ($r[0] !== 235) throw new RuntimeException(self::refusal($r, $c, 'auth'));
    }

    /** A refusal in plain words. */
    private static function refusal(array $r, array $c, string $stage): string
    {
        [$code, $text] = $r;
        $who = (string) ($c['login'] ?? '');
        $said = self::clean($text);
        $l = strtolower($text);
        if (str_contains($l, 'suspend') || str_contains($l, 'disabled') || str_contains($l, 'blocked') && $stage !== 'data' || str_contains($l, 'locked')) {
            return 'The mailbox ' . $who . ' is suspended or locked at the mail server (it said "' . $said . '").';
        }
        if (str_contains($l, 'application-specific password') || str_contains($l, 'app password') || preg_match('/\b5\.7\.9\b/', $text)) {
            return 'The mail server wants an app password for ' . $who . ', not the account\'s own password: make one in the account\'s security settings and reconnect.';
        }
        if (str_contains($l, 'smtp auth') && (str_contains($l, 'disabled') || str_contains($l, 'not enabled'))) return 'Sending with a password is turned off for ' . $who . ' at the mail server (it said "' . $said . '").';
        if ($stage === 'auth') {
            if ($code >= 400 && $code < 500) return 'The outgoing server for ' . $who . ' is busy or down for now (it said "' . $said . '"): it will be tried again.';
            return 'The mail server refused the password for ' . $who . ($said !== '' ? ' (it said "' . $said . '")' : '') . '.';
        }
        if ($code === 552 || str_contains($l, 'quota') || str_contains($l, 'too large') || str_contains($l, 'size')) return 'The message is too large or the mailbox ' . $who . ' is full (the server said "' . $said . '").';
        if ($code === 550 && $stage === 'from') return 'The mail server won\'t send as that address from ' . $who . ' (it said "' . $said . '").';
        if ($code === 0) return 'The outgoing server stopped answering.';
        if ($code >= 400 && $code < 500) return 'The outgoing server is busy for now (it said "' . $said . '"): it will be tried again.';
        return 'The outgoing server refused the message (it said "' . $said . '").';
    }

    /** [code, the whole reply] */
    private static function cmd($s, string $line): array
    {
        self::write($s, $line . "\r\n");
        return self::read($s);
    }

    private static function read($s): array
    {
        $resp = '';
        while (($line = fgets($s, 2048)) !== false) {
            $resp .= $line;
            if (strlen($line) < 4 || $line[3] !== '-') break;   // the last line of a reply has a space (or nothing) after its code
        }
        if ($resp === '') {
            $timedOut = !empty(stream_get_meta_data($s)['timed_out']);
            throw new RuntimeException($timedOut ? 'The outgoing server stopped answering (no reply in ' . self::TIMEOUT . ' seconds).' : 'The outgoing server closed the connection.');
        }
        return [(int) substr($resp, 0, 3), rtrim($resp)];
    }

    private static function write($s, string $data): void
    {
        $left = $data;
        while ($left !== '') {
            $n = @fwrite($s, $left);
            if ($n === false || $n === 0) throw new RuntimeException('The connection to the outgoing server was lost.');
            $left = (string) substr($left, $n);
        }
    }

    /** CRLF line endings and a "." added to every line that starts with one (RFC 5321 §4.5.2). */
    public static function dots(string $raw): string
    {
        $raw = str_replace(["\r\n", "\r"], "\n", rtrim($raw, "\r\n"));
        return preg_replace('/^\./m', '..', str_replace("\n", "\r\n", $raw)) ?? $raw;
    }

    /** The server's words, one line, codes and control characters taken out; never the password (it isn't in a reply). */
    private static function clean(string $t): string
    {
        $t = preg_replace('/^\d{3}[ -](\d\.\d+\.\d+\s+)?/m', '', $t) ?? $t;
        $t = trim(preg_replace('/[\x00-\x1F\x7F]+/', ' ', $t) ?? $t);
        return mb_substr($t !== '' ? $t : 'no reason given', 0, 200);
    }

    private static function me(): string
    {
        $h = (string) (getenv('APP_URL') ?: 'traversence.com');
        return preg_replace('#^https?://|/.*$#', '', $h) ?: 'traversence.com';
    }
}
