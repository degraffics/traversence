<?php
// api/lib/ListingActions.php — what visitors do from a listing (decisions/0058 §9): Call, Email, Directions, Website,
// the contact page. Counted per listing, action and day, for the business's Insights and, while it's unclaimed, for
// Sales as a reason to invite (decisions/0172 §3.3). Never who: no user, device or address is stored. One count per
// visit (session) per listing and action a day, so repeat taps don't inflate it.
//
// Also the one place that says what a listing can do for the person looking at it (decisions/0172 §3.1):
// ListingActions::actions() lists the actions that work, and ListingActions::managed() is the one test of "managed"
// (someone holds listing_access), which the listing page, the storefront, the dashboard, guest questions and the
// search API all ask.

declare(strict_types=1);

final class ListingActions
{
    public const ACTIONS = ['call' => 'Calls', 'email' => 'Emails', 'directions' => 'Directions', 'website' => 'Website visits', 'contact' => 'Contact page visits', 'save' => 'Contacts saved'];

    /** What each action is, for a card (decisions/0172 §3.1): key => [label, title]. */
    public const KINDS = [
        'message'    => ['Message', 'Message them in your Traversence inbox'],
        'leave'      => ['Leave a message', 'Leave a message, held for them until they claim this listing'],
        'ask'        => ['Ask a question', 'Ask a question without an account'],
        'call'       => ['Call', 'Call'],
        'email'      => ['Email', 'Email them from your own mail app'],
        'directions' => ['Directions', 'Get directions'],
        'website'    => ['Website', 'Website'],
        'contact'    => ['Contact or book', 'Contact or book online'],
        'claim'      => ['Claim it', 'Are you the owner? Claim it to add photos, hours and more.'],
    ];
    private const PUBLIC_STATUSES = ['unclaimed', 'claimed-unverified', 'pending-verification', 'verified'];

    /** Managed (decisions/0172 §3.1, gap 5): someone holds listing_access, so someone reads its messages. The one test. */
    public static function managed(PDO $pdo, int $entityId): bool
    {
        if ($entityId <= 0) return false;
        try { $st = $pdo->prepare('SELECT 1 FROM listing_access WHERE entity_id = ? LIMIT 1'); $st->execute([$entityId]); return $st->fetchColumn() !== false; }
        catch (PDOException) { return false; }
    }

    /** The same test for a page of listings: [id => true] for the managed ones. */
    public static function managedSet(PDO $pdo, array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn ($i) => $i > 0)));
        if (!$ids) return [];
        try { return array_fill_keys(array_map('intval', $pdo->query('SELECT DISTINCT entity_id FROM listing_access WHERE entity_id IN (' . implode(',', $ids) . ')')->fetchAll(PDO::FETCH_COLUMN)), true); }
        catch (PDOException) { return []; }
    }

    /** The listing's public email (entity_metadata 'email': "a public contact address only"), or ''. */
    public static function publicEmail(PDO $pdo, int $entityId): string
    {
        try { $st = $pdo->prepare("SELECT meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key = 'email' LIMIT 1"); $st->execute([$entityId]); $v = $st->fetchColumn(); }
        catch (PDOException) { return ''; }
        return self::cleanEmail($v === false ? '' : (string) $v);
    }

    public static function cleanEmail(string $v): string
    {
        $d = json_decode($v, true);
        $v = trim(is_string($d) ? $d : $v);
        if (str_starts_with(strtolower($v), 'mailto:')) $v = substr($v, 7);
        return filter_var($v, FILTER_VALIDATE_EMAIL) ? $v : '';
    }

    /**
     * The actions that work for this listing and this viewer (decisions/0172 §3.1), in the order cards show them:
     * [key => ['label', 'title', 'href', 'out' (its data-out count, or '')]]. A card shows exactly these.
     *   message    managed, the viewer isn't on its team (the listing page only)
     *   leave      not managed: Leave a message (the listing page only, §3.3)
     *   ask        managed, the viewer signed out (guest questions, 0052)
     *   call       it has a phone
     *   email      its public email is known (opens the visitor's own mail app; only the tap is counted)
     *   directions a place on the map or an address, and its location isn't kept private (0044, 0076)
     *   website, contact   it has one
     *   claim      unclaimed, the viewer isn't staff (and it's a business: not a drop box)
     * $viewer: the signed-in person (a users row with 'id'; 'is_admin' if known), null signed out. $row: what the caller
     * already read about the listing (id, name, status, category_id, phone, website, contact_url, email, latitude,
     * longitude, address, city, state), so nothing is read twice. $where: 'page' (the listing page) or 'card'.
     */
    public static function actions(PDO $pdo, int $entityId, ?array $viewer, array $row = [], string $where = 'card'): array
    {
        if ($entityId <= 0) return [];
        $row = self::row($pdo, $entityId, $row);
        if (!$row) return [];
        $uid = $viewer ? (int) ($viewer['id'] ?? 0) : 0;
        $managed = array_key_exists('managed', $row) ? (bool) $row['managed'] : self::managed($pdo, $entityId);
        $team = $uid > 0 && self::onTeam($pdo, $uid, $entityId, $row);
        $staff = $uid > 0 && self::isStaff($pdo, $viewer);
        require_once __DIR__ . '/ListingSafety.php';
        $private = ListingSafety::isConfidential(isset($row['category_id']) && $row['category_id'] !== null ? (int) $row['category_id'] : null, (string) ($row['name'] ?? ''));
        $out = [];
        $add = function (string $k, string $href, string $count = '') use (&$out) { $out[$k] = ['label' => self::KINDS[$k][0], 'title' => self::KINDS[$k][1], 'href' => $href, 'out' => $count]; };
        if ($where === 'page' && !$team) {
            if ($managed) $add('message', '/user/dashboard.php#addressbook:biz=' . $entityId);
            elseif (($row['status'] ?? '') === 'unclaimed' && !$staff && !self::notABusiness($pdo, $entityId)) $add('leave', '/listing/view.php?id=' . $entityId . '#lm');
            if ($managed && $uid === 0) $add('ask', '/listing/view.php?id=' . $entityId . '#gq');
        }
        $tel = preg_replace('/[^\d+]/', '', (string) ($row['phone'] ?? ''));
        if (strlen(preg_replace('/\D/', '', $tel)) >= 7) $add('call', 'tel:' . $tel, 'call');
        $mail = self::cleanEmail((string) ($row['email'] ?? ''));
        if ($mail !== '') $add('email', 'mailto:' . $mail, 'email');
        if (!$private) {
            $lat = $row['latitude'] ?? null; $lon = $row['longitude'] ?? null;
            if ($lat !== null && $lon !== null && $lat !== '' && $lon !== '') $add('directions', 'https://www.google.com/maps/search/?api=1&query=' . urlencode($lat . ',' . $lon), 'directions');
            elseif (trim((string) ($row['address'] ?? '')) !== '') $add('directions', 'https://www.google.com/maps/search/?api=1&query=' . urlencode(implode(', ', array_filter([$row['address'], $row['city'] ?? '', $row['state'] ?? '']))), 'directions');
        }
        $web = trim((string) ($row['website'] ?? ''));
        if ($web !== '') $add('website', preg_match('#^https?://#i', $web) ? $web : 'https://' . $web, 'website');
        $cu = trim((string) ($row['contact_url'] ?? ''));
        if ($cu !== '' && preg_match('#^https?://#i', $cu)) $add('contact', $cu, 'contact');
        if (($row['status'] ?? '') === 'unclaimed' && !$staff && !$team && !self::notABusiness($pdo, $entityId)) $add('claim', '/claim.php?listing=' . $entityId);
        return $out;
    }

    /** The listing's fields actions() reads, from what the caller has, the rest from the database. [] when it isn't public. */
    private static function row(PDO $pdo, int $e, array $row): array
    {
        $need = ['name', 'status', 'category_id', 'phone', 'website', 'contact_url', 'email', 'latitude', 'longitude', 'address', 'city', 'state'];
        if (!array_diff($need, array_keys($row))) return $row;
        try {
            $st = $pdo->prepare("SELECT id, name, status, is_suppressed, category_id, latitude, longitude FROM entities WHERE id = ? AND entity_type = 'merchant' LIMIT 1");
            $st->execute([$e]);
            $base = $st->fetch(PDO::FETCH_ASSOC);
            if (!$base || (int) $base['is_suppressed'] === 1 || !in_array((string) $base['status'], self::PUBLIC_STATUSES, true)) return [];
            $m = [];
            $q = $pdo->prepare("SELECT meta_key, meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key IN ('phone', 'website', 'contact_url', 'email', 'address', 'city', 'state')");
            $q->execute([$e]);
            foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { $v = json_decode((string) $r['meta_value'], true); $m[$r['meta_key']] = is_scalar($v) ? (string) $v : (string) $r['meta_value']; }
        } catch (PDOException) { return []; }
        return $row + $base + $m + array_fill_keys($need, null);
    }

    private static function onTeam(PDO $pdo, int $uid, int $e, array $row): bool
    {
        if (isset($row['owner_user_id']) && (int) $row['owner_user_id'] === $uid) return true;
        try { $st = $pdo->prepare('SELECT 1 FROM listing_access WHERE entity_id = ? AND user_id = ? LIMIT 1'); $st->execute([$e, $uid]); if ($st->fetchColumn() !== false) return true; } catch (PDOException) {}
        if (is_file(__DIR__ . '/Team.php')) { try { require_once __DIR__ . '/Team.php'; return Team::roleOf($pdo, $uid, $e) !== null; } catch (Throwable) {} }
        return false;
    }

    /** Our staff (admins, or anyone with admin access): Claim it isn't offered to them (0172 §3.1). */
    private static function isStaff(PDO $pdo, ?array $viewer): bool
    {
        if (!$viewer) return false;
        if (!empty($viewer['is_admin'])) return true;
        try { $st = $pdo->prepare('SELECT 1 FROM ' . (class_exists('Database') ? Database::t('admin_access') : 'admin_access') . ' WHERE user_id = ? LIMIT 1'); $st->execute([(int) $viewer['id']]); return (bool) $st->fetchColumn(); }
        catch (Throwable) { return false; }
    }

    private static function notABusiness(PDO $pdo, int $e): bool
    {
        if (!is_file(__DIR__ . '/PlaceScope.php')) return false;
        try { require_once __DIR__ . '/PlaceScope.php'; return PlaceScope::notABusiness($pdo, $e) !== ''; } catch (Throwable) { return false; }
    }

    /**
     * What visitors did through Traversence with this listing since the start of the month (decisions/0172 §3.3), for
     * Sales: [call, email, website, directions, messages (left on it and waiting), 'line' => the sentence]. Counts only,
     * never who or what.
     */
    public static function reach(PDO $pdo, int $entityId, ?string $since = null): array
    {
        $since = $since ?? date('Y-m-01');
        $out = ['call' => 0, 'email' => 0, 'website' => 0, 'directions' => 0, 'messages' => 0];
        if (self::ready($pdo)) {
            $st = $pdo->prepare("SELECT action, SUM(n) FROM listing_actions WHERE entity_id = ? AND day >= ? AND action IN ('call', 'email', 'website', 'directions') GROUP BY action");
            $st->execute([$entityId, $since]);
            foreach ($st->fetchAll(PDO::FETCH_NUM) as [$a, $n]) $out[(string) $a] = (int) $n;
        }
        if (is_file(__DIR__ . '/ListingMessages.php')) { require_once __DIR__ . '/ListingMessages.php'; $out['messages'] = ListingMessages::countWaiting($pdo, $entityId); }   // waiting for its claim, however old
        $out['line'] = self::reachLine($out);
        return $out;
    }

    /** "37 people called or emailed you through Traversence this month. 4 people have left you messages on Traversence." */
    public static function reachLine(array $r): string
    {
        $ce = (int) ($r['call'] ?? 0) + (int) ($r['email'] ?? 0);
        $wd = (int) ($r['website'] ?? 0) + (int) ($r['directions'] ?? 0);
        $m = (int) ($r['messages'] ?? 0);
        $p = fn (int $n) => $n === 1 ? '1 person' : $n . ' people';
        $s = [];
        if ($ce) $s[] = $p($ce) . ' called or emailed you through Traversence this month.';
        if ($wd) $s[] = ($wd === 1 ? '1 visit' : $wd . ' visits') . ' to your website or for directions came from Traversence this month.';
        if ($m) $s[] = $p($m) . ($m === 1 ? ' has' : ' have') . ' left you messages on Traversence.';
        return implode(' ', $s);
    }

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM listing_actions LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    public static function count(PDO $pdo, int $entityId, string $action): bool
    {
        if (!self::ready($pdo) || $entityId <= 0 || !isset(self::ACTIONS[$action])) return false;
        $day = date('Y-m-d');
        $key = $entityId . ':' . $action . ':' . $day;
        if (session_status() === PHP_SESSION_ACTIVE) {
            if (!empty($_SESSION['tv_la'][$key])) return false;
            $_SESSION['tv_la'][$key] = 1;
        }
        $up = $pdo->prepare('UPDATE listing_actions SET n = n + 1 WHERE entity_id = ? AND action = ? AND day = ?');
        $up->execute([$entityId, $action, $day]);
        if ($up->rowCount() === 0) {
            try { $pdo->prepare('INSERT INTO listing_actions (entity_id, action, day, n) VALUES (?, ?, ?, 1)')->execute([$entityId, $action, $day]); }
            catch (PDOException) { $up->execute([$entityId, $action, $day]); }   // two at once: the other one inserted
        }
        return true;
    }

    /** Totals for the last $days days: [action => n]. */
    public static function summary(PDO $pdo, int $entityId, int $days = 30): array
    {
        $out = array_fill_keys(array_keys(self::ACTIONS), 0);
        if (!self::ready($pdo)) return $out;
        $st = $pdo->prepare('SELECT action, SUM(n) AS n FROM listing_actions WHERE entity_id = ? AND day >= ? GROUP BY action');
        $st->execute([$entityId, date('Y-m-d', time() - $days * 86400)]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['action']] = (int) $r['n'];
        return $out;
    }
}
