<?php
// app/lib/SesInbound.php — mail received by Amazon SES (decisions/0172 §4.7): an address on a domain whose mail is pointed at
// SES, with no mail host. SES keeps nothing here: each message goes to SNS (Base64, up to 150 KB) and on to
// /api/ses-inbound.php, which stores it in the connected mailbox (Mailboxes, provider 'ses') at once.
// Only the subdomain in.traversence.com is pointed at SES, so the mail Bluehost receives for traversence.com and trvgo.us
// (support@, orders@, staff) is never touched. Setup is owner-level, from System Configuration → Communications, and
// costs per message: Amazon charges about $0.10 per 1,000 received and per 256 KB chunk, counted on the route (via
// 'ses-in') like every send, so message control shows it. A business's own domain comes with the App store (0169).
declare(strict_types=1);

final class SesInbound
{
    public const DOMAIN = 'in.traversence.com';
    public const ENDPOINT = 'https://traversence.com/api/ses-inbound.php';
    private const RULESET = 'tv-inbound';

    private static function lib(string $f): void { require_once __DIR__ . '/' . $f; }

    /** Where receiving stands: [topic, rule set made, MX in place]. */
    public static function status(PDO $pdo): array
    {
        self::lib('SesMail.php');
        return ['topic' => SesMail::state($pdo, 'topic_inbound'), 'confirmed' => SesMail::state($pdo, 'confirmed_' . md5(SesMail::state($pdo, 'topic_inbound'))), 'rules' => SesMail::state($pdo, 'inbound_rules'),
                'mx' => SesMail::state($pdo, 'inbound_mx'), 'domain' => self::DOMAIN];
    }

    /** Sets receiving up, each step safe to run again. Returns what was done. */
    public static function setup(PDO $pdo, ?int $uid): string
    {
        self::lib('SesMail.php'); self::lib('StagingGate.php');
        if (StagingGate::here()) throw new RuntimeException('Staging never changes our AWS account.');
        if (!SesMail::hasKeys('personal')) throw new RuntimeException('Amazon SES\'s keys aren\'t in .env yet: System Configuration → Outside services → Amazon.');
        $said = [];
        [$code, $res] = SesMail::sns('personal', ['Action' => 'CreateTopic', 'Name' => 'tv-ses-inbound']);
        if ($code !== 200 || !preg_match('#<TopicArn>([^<]+)</TopicArn>#', $res, $m)) throw new RuntimeException('SNS answered ' . $code . ': ' . mb_substr(strip_tags($res), 0, 200));
        $arn = $m[1];
        SesMail::setState($pdo, 'topic_inbound', $arn);
        SesMail::sns('personal', ['Action' => 'Subscribe', 'TopicArn' => $arn, 'Protocol' => 'https', 'Endpoint' => self::ENDPOINT]);
        $said[] = 'the topic';
        // the domain must be verified with SES to receive for it
        [$code, $res] = SesMail::api('personal', 'POST', '/v2/email/identities', ['EmailIdentity' => self::DOMAIN]);
        $records = [['in', 'MX', '10 inbound-smtp.' . SesMail::region() . '.amazonaws.com']];
        $j = json_decode($res, true);
        if ($code !== 200 && !str_contains($res, 'AlreadyExists')) throw new RuntimeException('SES answered ' . $code . ': ' . mb_substr($res, 0, 200));
        if ($code !== 200) { [$c2, $r2] = SesMail::api('personal', 'GET', '/v2/email/identities/' . self::DOMAIN); $j = json_decode($r2, true); }
        foreach ((array) ($j['DkimAttributes']['Tokens'] ?? []) as $t) $records[] = [$t . '._domainkey.in', 'CNAME', $t . '.dkim.amazonses.com'];
        foreach ([['Action' => 'CreateReceiptRuleSet', 'RuleSetName' => self::RULESET], ['Action' => 'SetActiveReceiptRuleSet', 'RuleSetName' => self::RULESET],
                  ['Action' => 'CreateReceiptRule', 'RuleSetName' => self::RULESET, 'Rule.Name' => 'tv-in', 'Rule.Enabled' => 'true', 'Rule.ScanEnabled' => 'true', 'Rule.TlsPolicy' => 'Optional',
                   'Rule.Recipients.member.1' => self::DOMAIN, 'Rule.Actions.member.1.SNSAction.TopicArn' => $arn, 'Rule.Actions.member.1.SNSAction.Encoding' => 'Base64']] as $q) {
            [$code, $res] = SesMail::query('personal', $q);
            if ($code !== 200 && !str_contains($res, 'AlreadyExists')) throw new RuntimeException('SES (' . $q['Action'] . ') answered ' . $code . ': ' . mb_substr(strip_tags($res), 0, 200));
        }
        SesMail::setState($pdo, 'inbound_rules', date('Y-m-d H:i:s'));
        $said[] = 'the receiving rule';
        self::lib('CPanel.php');
        CPanel::dnsEnsure('traversence.com', $records);
        SesMail::setState($pdo, 'inbound_mx', date('Y-m-d H:i:s'));
        $said[] = 'the DNS records for ' . self::DOMAIN;
        self::lib('CommsSetup.php');
        CommsSetup::log($pdo, $uid, 'ses_receiving', self::DOMAIN, implode(', ', $said));
        return 'Receiving is set up: ' . implode(', ', $said) . '. Connect an address like hello@' . self::DOMAIN . ' to an inbox to read its mail in Pulse.';
    }

    /** One SNS notification of received mail. Returns a word for the log. */
    public static function received(PDO $pdo, array $n): string
    {
        $raw = isset($n['content']) ? (string) base64_decode((string) $n['content'], true) : '';
        if ($raw === '') return 'no content (over 150 KB?)';
        $verdicts = (array) ($n['receipt'] ?? []);
        $spam = in_array(($verdicts['spamVerdict']['status'] ?? ''), ['FAIL'], true) || in_array(($verdicts['virusVerdict']['status'] ?? ''), ['FAIL'], true);
        self::lib('Mailboxes.php'); self::lib('MailMime.php');
        $p = MailMime::parse($raw);
        $n2 = 0;
        foreach ((array) ($n['receipt']['recipients'] ?? $n['mail']['destination'] ?? []) as $to) {
            $st = $pdo->prepare("SELECT id FROM comms_mailboxes WHERE provider = 'ses' AND address = ? AND status = 'active'"); $st->execute([strtolower((string) $to)]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
                if (Mailboxes::store($pdo, (int) $id, $spam ? 'Junk' : 'INBOX', (string) ($n['mail']['messageId'] ?? bin2hex(random_bytes(8))), $p, false)) $n2++;
            }
        }
        try { $pdo->prepare("INSERT INTO comms_route (message_id, via, stage, detail, provider_id, happened_at, mail_kind) VALUES (0, 'ses-in', 'delivered', ?, ?, ?, 'ses_receive')")
            ->execute(['Received by Amazon SES, ' . strlen($raw) . ' bytes, ' . $n2 . ' mailbox' . ($n2 === 1 ? '' : 'es'), mb_substr((string) ($n['mail']['messageId'] ?? ''), 0, 120), date('Y-m-d H:i:s')]); } catch (Throwable) {}
        return $n2 ? 'stored' : 'no connected mailbox for it';
    }
}
