<?php
// app/lib/CPanelMail.php — staff mailboxes (first.last@<work domain>) made and suspended from Staff logins, through
// cPanel's own API (UAPI, Email module) with an API token (decisions/0100). .env:
//   CPANEL_HOST   the cPanel server's name (cPanel → General Information → Server Name / hostname), port 2083
//   CPANEL_USER   the cPanel username
//   CPANEL_TOKEN  an API token (cPanel → Security → Manage API Tokens); kept only in .env, never shown
// Without them, Staff logins works as before and mailboxes are made in cPanel by hand.
declare(strict_types=1);

final class CPanelMail
{
    public const QUOTA_MB = 1024;

    public static function ready(): bool
    {
        return trim((string) getenv('CPANEL_HOST')) !== '' && trim((string) getenv('CPANEL_USER')) !== '' && trim((string) getenv('CPANEL_TOKEN')) !== '';
    }

    /** Makes the mailbox. Returns its new password (shown once), or '' when it already existed (left as it is). */
    public static function create(string $email): string
    {
        [$local, $domain] = explode('@', $email, 2);
        $pw = self::password();
        try {
            self::call('add_pop', ['email' => $local, 'domain' => $domain, 'password' => $pw, 'quota' => self::QUOTA_MB, 'send_welcome_email' => 0]);
        } catch (RuntimeException $e) {
            if (stripos($e->getMessage(), 'exists') !== false) return '';
            throw $e;
        }
        return $pw;
    }

    /** Makes a mailbox with this password (Communications, decisions/0167 §4: typed or made by the site). */
    public static function createWith(string $email, string $pw): void
    {
        [$local, $domain] = explode('@', $email, 2);
        try { self::call('add_pop', ['email' => $local, 'domain' => $domain, 'password' => $pw, 'quota' => self::QUOTA_MB, 'send_welcome_email' => 0]); }
        catch (RuntimeException $e) { if (stripos($e->getMessage(), 'exists') !== false) throw new RuntimeException($email . ' already exists: use Reset to change its password.'); throw $e; }
    }

    /** A new password for an existing mailbox (Communications' Reset). */
    public static function setPassword(string $email, string $pw): void
    {
        [$local, $domain] = explode('@', $email, 2);
        self::call('passwd_pop', ['email' => $local, 'domain' => $domain, 'password' => $pw]);
    }

    /** Stops the mailbox signing in (its mail is kept); unsuspend() lets it in again. */
    public static function suspend(string $email): void { self::call('suspend_login', ['email' => $email]); }
    public static function unsuspend(string $email): void { self::call('unsuspend_login', ['email' => $email]); }

    public static function webmail(string $email): string { return 'https://' . explode('@', $email, 2)[1] . '/webmail'; }

    private static function call(string $fn, array $q): array
    {
        if (!self::ready()) throw new RuntimeException('Mailboxes can\'t be made from here yet: add the cPanel API token to .env.');
        $host = preg_replace('#^https?://|[:/].*$#', '', trim((string) getenv('CPANEL_HOST')));
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold('https://' . $host . ':2083/execute/Email/' . $fn, 'cPanel mailboxes: ' . $fn)) !== null) throw new RuntimeException($w);   // our hosting account: never changed from staging
        $ch = curl_init('https://' . $host . ':2083/execute/Email/' . $fn . '?' . http_build_query($q));
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => ['Authorization: cpanel ' . trim((string) getenv('CPANEL_USER')) . ':' . trim((string) getenv('CPANEL_TOKEN'))]]);
        $raw = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
        if ($raw === false) { error_log('cpanel ' . $fn . ': ' . $err); throw new RuntimeException('cPanel didn\'t answer. Check CPANEL_HOST in .env, or try again.'); }
        $d = json_decode((string) $raw, true);
        if ($code === 401 || $code === 403) throw new RuntimeException('cPanel refused the API token. Check CPANEL_USER and CPANEL_TOKEN in .env.');
        if (!is_array($d)) { error_log('cpanel ' . $fn . ': HTTP ' . $code . ' ' . mb_substr((string) $raw, 0, 200)); throw new RuntimeException('cPanel gave an answer we couldn\'t read (HTTP ' . $code . ').'); }
        if ((int) ($d['status'] ?? 0) !== 1) throw new RuntimeException('cPanel: ' . trim(strip_tags((string) (($d['errors'] ?? [])[0] ?? 'it didn\'t work.'))));
        return $d;
    }

    private static function password(): string
    {
        $sets = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnpqrstuvwxyz', '23456789', '!#%+=?@'];
        $all = implode('', $sets); $p = '';
        foreach ($sets as $set) $p .= $set[random_int(0, strlen($set) - 1)];
        for ($i = 0; $i < 16; $i++) $p .= $all[random_int(0, strlen($all) - 1)];
        $a = str_split($p);
        for ($i = count($a) - 1; $i > 0; $i--) { $j = random_int(0, $i); [$a[$i], $a[$j]] = [$a[$j], $a[$i]]; }
        return implode('', $a);
    }
}
