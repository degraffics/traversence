<?php
// app/lib/MailPop.php — reads a mailbox over POP3 for Pulse, only where a provider doesn't offer IMAP (decisions/0172
// §4.7): the inbox only, no folders, no read state back. It never deletes (no DELE): the mail stays on the server, so the
// mailbox remains the original and Pulse a window onto it. Port 995 is TLS from the start; 110 upgrades with STLS (never
// signs in unencrypted). A plain socket, as MailImap and Mailer are. Staging never connects (StagingGate::hold, 0165).
// Refusals are thrown in plain words for the person's Reconnect alert; the password is never logged.
declare(strict_types=1);

final class MailPop
{
    private const TIMEOUT = 20;

    /** For tests only: function (string $host, int $port, bool $tls): resource, used in place of the network. */
    public static ?Closure $open = null;
    /** For tests only: function ($stream): bool, used in place of the TLS upgrade after STLS. */
    public static ?Closure $starttls = null;

    private string $host;
    private int $port;
    private string $login;
    private string $password;
    private string $address;
    /** @var resource|null */
    private $s = null;
    private bool $authed = false;

    /** $c: host, port (995 TLS by default; 110 with STLS), login, password, address. */
    public function __construct(array $c)
    {
        $this->host = strtolower(trim((string) ($c['host'] ?? '')));
        $this->port = (int) ($c['port'] ?? 0) ?: 995;
        $this->login = (string) ($c['login'] ?? '');
        $this->password = (string) ($c['password'] ?? '');
        $this->address = trim((string) ($c['address'] ?? '')) ?: $this->login;
        if ($this->host === '') throw new RuntimeException('The mail server for ' . $this->address . ' isn\'t set: add its server name (e.g. pop.example.com).');
    }

    public function __destruct()
    {
        if (is_resource($this->s)) @fclose($this->s);
    }

    /** '' when the mailbox signs in and lists its messages, else the exact refusal in plain words. */
    public static function check(array $c): string
    {
        try {
            $p = new self($c);
            $p->login();
            $p->uidl();
            $p->quit();
            return '';
        } catch (Throwable $e) {
            return $e->getMessage();
        }
    }

    public function login(): void
    {
        if ($this->authed) return;
        if ($this->login === '' || $this->password === '') throw new RuntimeException('The sign-in name or password for ' . $this->address . ' is missing: reconnect it.');
        if (!class_exists('StagingGate')) require_once __DIR__ . '/StagingGate.php';
        if (($w = StagingGate::hold('pop3://' . $this->host, 'Mail: read ' . $this->address)) !== null) throw new RuntimeException($w);
        $tls = $this->port !== 110;
        if (self::$open !== null) {
            $s = (self::$open)($this->host, $this->port, $tls);
        } else {
            $ctx = stream_context_create(['ssl' => ['peer_name' => $this->host, 'SNI_enabled' => true, 'verify_peer' => true, 'verify_peer_name' => true]]);
            $errno = 0; $errstr = '';
            $s = @stream_socket_client(($tls ? 'ssl' : 'tcp') . '://' . $this->host . ':' . $this->port, $errno, $errstr, self::TIMEOUT, STREAM_CLIENT_CONNECT, $ctx);
            if ($s === false) {
                if (!class_exists('MailImap')) require_once __DIR__ . '/MailImap.php';
                throw new RuntimeException(MailImap::connectError($this->host, $this->port, $errno, $errstr));
            }
        }
        if (!is_resource($s)) throw new RuntimeException('Port ' . $this->port . ' on ' . $this->host . ' is blocked or the server didn\'t answer.');
        stream_set_timeout($s, self::TIMEOUT);
        $this->s = $s;
        $greet = $this->line();
        if (!str_starts_with($greet, '+OK')) throw new RuntimeException('That isn\'t a POP3 mail server at ' . $this->host . ':' . $this->port . ' (it said "' . self::clean($greet) . '").');
        if (!$tls) {
            $r = $this->cmd('STLS', false);
            if (!str_starts_with($r, '+OK')) throw new RuntimeException('The mail server ' . $this->host . ' doesn\'t offer encryption on port 110: use port 995.');
            $ok = self::$starttls !== null ? (bool) (self::$starttls)($this->s) : @stream_socket_enable_crypto($this->s, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if (!$ok) throw new RuntimeException('A secure connection to ' . $this->host . ' couldn\'t be made (its certificate or encryption was refused).');
        }
        $r = $this->cmd('USER ' . self::arg($this->login), false);
        if (str_starts_with($r, '+OK')) $r = $this->cmd('PASS ' . self::arg($this->password), false);
        if (!str_starts_with($r, '+OK')) throw new RuntimeException($this->refusal($r));
        $this->authed = true;
    }

    /** Every message's number and lasting id: [n => uid]. */
    public function uidl(): array
    {
        $this->login();
        $out = [];
        foreach (explode("\n", $this->multi('UIDL')) as $l) {
            if (preg_match('/^(\d+)\s+(\S+)/', trim($l), $m)) $out[(int) $m[1]] = $m[2];
        }
        return $out;
    }

    /** One whole message by its number, dot-unstuffed, CRLF line endings. Left on the server. */
    public function retr(int $n): string
    {
        $this->login();
        return $this->multi('RETR ' . $n);
    }

    public function quit(): void
    {
        if (!is_resource($this->s)) return;
        try { $this->cmd('QUIT', false); } catch (Throwable $e) {}
        @fclose($this->s);
        $this->s = null; $this->authed = false;
    }

    // ---- inside -------------------------------------------------------------------------------------------------------

    /** A command whose answer is one line. With $must, -ERR throws. */
    private function cmd(string $c, bool $must = true): string
    {
        $this->write($c . "\r\n");
        $r = $this->line();
        if ($must && !str_starts_with($r, '+OK')) throw new RuntimeException($this->refusal($r));
        return $r;
    }

    /** A command whose answer runs to a line holding only ".": the body, with ".." at a line's start turned back into ".". */
    private function multi(string $c): string
    {
        $this->cmd($c);
        $out = '';
        while (true) {
            $l = fgets($this->s);
            if ($l === false) $this->lost();
            $t = rtrim($l, "\r\n");
            if ($t === '.') break;
            if (isset($t[0]) && $t[0] === '.') $t = substr($t, 1);
            $out .= $t . "\r\n";
        }
        return $out;
    }

    private function line(): string
    {
        $l = fgets($this->s);
        if ($l === false) $this->lost();
        return rtrim($l, "\r\n");
    }

    private function write(string $s): void
    {
        if (!is_resource($this->s) || @fwrite($this->s, $s) !== strlen($s)) throw new RuntimeException('The mail server ' . $this->host . ' closed the connection.');
    }

    private function lost(): void
    {
        $timedOut = is_resource($this->s) && !empty(stream_get_meta_data($this->s)['timed_out']);
        throw new RuntimeException($timedOut
            ? 'The mail server ' . $this->host . ' stopped answering (no reply in ' . self::TIMEOUT . ' seconds).'
            : 'The mail server ' . $this->host . ' closed the connection.');
    }

    private static function arg(string $s): string { return str_replace(["\r", "\n"], '', $s); }

    private function refusal(string $r): string
    {
        $s = self::clean($r);
        $l = strtolower($r);
        if (str_contains($l, '[in-use]') || str_contains($l, 'in use') || str_contains($l, 'locked')) return 'The mailbox ' . $this->address . ' is busy in another mail app right now: it will be tried again.';
        if (str_contains($l, '[sys/temp]') || str_contains($l, 'temporar') || str_contains($l, 'try again')) return 'The mail server for ' . $this->address . ' is busy or down for now (it said "' . $s . '"): it will be tried again.';
        if (str_contains($l, 'quota') || str_contains($l, 'full')) return 'The mailbox ' . $this->address . ' is full.';
        if (str_contains($l, 'suspended') || str_contains($l, 'disabled') || str_contains($l, 'not enabled') || str_contains($l, 'pop access')) {
            return 'The mailbox ' . $this->address . ' is suspended or has POP turned off at the mail server (it said "' . $s . '").';
        }
        if (str_contains($l, 'app password') || str_contains($l, 'application-specific')) return 'The mail server wants an app password for ' . $this->address . ', not the account\'s own password: make one in the account\'s security settings and reconnect.';
        if (!$this->authed) return 'The mail server refused the password for ' . $this->address . ($s !== '' ? ' (it said "' . $s . '")' : '') . '.';
        return 'The mail server for ' . $this->address . ' said "' . $s . '".';
    }

    private static function clean(string $s): string
    {
        $s = preg_replace('/^[+-](OK|ERR)\s*/i', '', $s) ?? $s;
        $s = preg_replace('/^\[[A-Z\/-]+\]\s*/', '', $s) ?? $s;
        $s = trim(preg_replace('/[\x00-\x1F\x7F]+/', ' ', $s) ?? $s);
        return mb_substr($s !== '' ? $s : 'no reason given', 0, 200);
    }
}
