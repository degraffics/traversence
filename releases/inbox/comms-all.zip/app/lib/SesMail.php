<?php
// app/lib/SesMail.php — email through Amazon SES (decisions/0137 §8). Bluehost (Mailer) sends system email only: sign-in
// codes, account notices, our own receipts, support. Everything else goes through SES, from two AWS accounts kept apart
// so one business's bad list can't stop anyone's receipt:
//   personal  notices and the weekly digest (send.traversence.com), and one-to-one mail in a business's name (via.)
//   bulk      invitations, campaigns, newsletters a business sends to its own people (via.traversence.com)
// Mail in someone's name comes from our sending domain ("Pine Cafe via Traversence"), with Reply-To theirs.
//
// Every send: the suppression list first (a bounce or complaint stops all mail to that address; an unsubscribe stops it
// from that sender, or stops notices); a paused sender is held; bulk mail stops at the month's cap (Services & usage),
// personal mail only alerts. Each message carries one-click unsubscribe (List-Unsubscribe, RFC 8058) and, when it's bulk,
// the sender's postal address (CAN-SPAM). Addresses are kept only as a hash.
//
// .env: SES_MODE (off | mock | live; mock records each message and sends nothing), SES_REGION (us-east-2, where SES was set up;
// defaults to AWS_REGION),
// personal: the site's AWS key (AWS_ACCESS_KEY_ID) unless SES_PERSONAL_KEY_ID / _SECRET are set; bulk: SES_BULK_KEY_ID /
// SES_BULK_SECRET (its own account, when bulk mail is built), SES_MONTHLY_CAP_USD (10),
// SES_USD_PER_1000 (0.10), EMAIL_LINK_KEY (optional; unsubscribe links). Setup (identities, DNS through the cPanel API,
// bounce reports through SNS) is a case in the admin Pulse; the AWS side is in decisions/0137 §8 "Setting up AWS".
declare(strict_types=1);

require_once __DIR__ . '/Aws.php';

final class SesMail
{
    public const ACCOUNTS = ['personal' => 'Personal (notices, receipts in a business\'s name)', 'bulk' => 'Bulk (invitations, campaigns)'];
    /** The sending domains each account verifies. */
    public const IDENTITIES = ['personal' => ['send.traversence.com', 'via.traversence.com'], 'bulk' => ['via.traversence.com']];
    public const ZONE = 'traversence.com';
    /** DMARC for the sending domains: watch only, reports to support@ (Jason, 2026-11-01). */
    public const DMARC = 'v=DMARC1; p=none; rua=mailto:support@traversence.com';
    public const CONFIG_SET = ['personal' => 'tv-personal', 'bulk' => 'tv-bulk'];
    /** A sender is paused at these rates over its last 30 days, once it has sent at least MIN_SENDS (AWS reviews at 5% / 0.1%). */
    public const PAUSE_BOUNCE = 0.03;
    public const PAUSE_COMPLAINT = 0.0008;
    public const MIN_SENDS = 50;
    public const STATUSES = ['queued' => 'Queued', 'sent' => 'Sent', 'mock' => 'Recorded (mock)', 'failed' => 'Failed', 'suppressed' => 'Not sent: suppressed',
                             'paused' => 'Not sent: sender paused', 'capped' => 'Not sent: month\'s cap', 'bounced' => 'Bounced', 'complained' => 'Marked as spam'];

    private static function env(string $k, string $d = ''): string { $v = getenv($k); return $v === false || trim((string) $v) === '' ? $d : trim((string) $v); }

    public static function mode(): string
    {
        $m = self::env('SES_MODE', 'off');
        if ($m === 'live') { require_once __DIR__ . '/Staging.php'; if (Staging::here()) return 'mock'; }   // the staging copy only records (decisions/0145 Phase 3)
        return in_array($m, ['off', 'mock', 'live'], true) ? $m : 'off';
    }
    public static function region(): string { return self::env('SES_REGION', self::env('AWS_REGION', 'us-east-2')); }   // set up in US East (Ohio), Jason 2026-11-01
    /**
     * An account's keys. Personal mail uses the site's existing AWS account and key (AWS_ACCESS_KEY_ID, the one S3 uses,
     * with SES permissions added: Jason, 2026-11-01) unless SES_PERSONAL_KEY_ID is set; bulk mail has its own account,
     * set up when businesses' invitations and campaigns are built.
     */
    public static function keys(string $account): array
    {
        if ($account === 'bulk') return [self::env('SES_BULK_KEY_ID'), self::env('SES_BULK_SECRET')];
        $id = self::env('SES_PERSONAL_KEY_ID');
        return $id !== '' ? [$id, self::env('SES_PERSONAL_SECRET')] : [self::env('AWS_ACCESS_KEY_ID'), self::env('AWS_SECRET_ACCESS_KEY')];
    }
    public static function hasKeys(string $account): bool { [$k, $s] = self::keys($account); return $k !== '' && $s !== ''; }

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM email_sends LIMIT 0'); $pdo->query('SELECT 1 FROM email_suppress LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    public static function hash(string $email): string { return hash('sha256', mb_strtolower(trim($email))); }
    private static function now(): string { return date('Y-m-d H:i:s'); }
    private static function linkKey(): string { return self::env('EMAIL_LINK_KEY') ?: hash('sha256', 'tv-email|' . (getenv('DB_PASSWORD') ?: '') . '|' . dirname(__DIR__)); }

    public static function state(PDO $pdo, string $k): string
    {
        try { $st = $pdo->prepare('SELECT v FROM email_state WHERE k = ?'); $st->execute([$k]); return (string) ($st->fetchColumn() ?: ''); } catch (Throwable) { return ''; }
    }
    public static function setState(PDO $pdo, string $k, string $v): void
    {
        $pdo->prepare('REPLACE INTO email_state (k, v) VALUES (?, ?)')->execute([$k, $v]);
    }

    /**
     * Sends one message. $m: account (personal|bulk), from_local ('notices'), from_domain, from_name, to, to_name,
     * subject, text, html (optional), reply_to (optional), sender ('traversence' | 'listing:12' | 'user:5'), purpose
     * ('notice', 'digest', 'invite'…), user_id (the person it's to, when they have an account), scope (what Unsubscribe
     * stops: 'notices' or the sender), why (the footer's line: why they got it), postal (the sender's postal address:
     * required for bulk). Returns ['status' => …, 'id' => send id].
     */
    public static function send(PDO $pdo, array $m): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('Email sending isn\'t switched on yet (its database update hasn\'t run).');
        $mode = self::mode();
        if ($mode === 'off') throw new RuntimeException('Email sending is off (SES_MODE in .env).');
        $account = ($m['account'] ?? 'personal') === 'bulk' ? 'bulk' : 'personal';
        $to = trim((string) ($m['to'] ?? ''));
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email address isn\'t valid.');
        require_once __DIR__ . '/TestAccounts.php';
        if (TestAccounts::isTestEmail($to)) return ['status' => 'test', 'id' => 0];   // a test account: nothing sent (decisions/0145 §3)
        $sender = mb_substr((string) ($m['sender'] ?? 'traversence'), 0, 40);
        $scope = mb_substr((string) ($m['scope'] ?? $sender), 0, 40);
        $h = self::hash($to);
        $record = function (string $status, string $err = '', ?string $msgId = null) use ($pdo, $account, $sender, $m, $h, $to, $scope): int {
            $pdo->prepare('INSERT INTO email_sends (account, sender, purpose, to_hash, to_domain, user_id, scope, message_id, status, error, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$account, $sender, mb_substr((string) ($m['purpose'] ?? ''), 0, 20), $h, mb_substr((string) substr(strrchr($to, '@') ?: '', 1), 0, 120),
                           !empty($m['user_id']) ? (int) $m['user_id'] : null, $scope, $msgId, $status, mb_substr($err, 0, 300), self::now()]);
            return (int) $pdo->lastInsertId();
        };
        if (self::suppressed($pdo, $h, $scope)) return ['status' => 'suppressed', 'id' => $record('suppressed')];
        if (self::paused($pdo, $sender)) return ['status' => 'paused', 'id' => $record('paused')];
        if ($account === 'bulk') {
            if (trim((string) ($m['postal'] ?? '')) === '') throw new InvalidArgumentException('Bulk email needs the sender\'s postal address (a mailing address or PO box in its settings).');
            require_once __DIR__ . '/Thresholds.php';
            $cap = (float) Thresholds::get($pdo, 'ses_month_usd');   // the service register (decisions/0163 §1; was SES_MONTHLY_CAP_USD)
            if ($cap > 0 && self::monthUsd($pdo) >= $cap) return ['status' => 'capped', 'id' => $record('capped')];
        }
        $id = $record('queued');
        $raw = self::mime($m, $to, $id, $account);
        if ($mode === 'mock') {
            require_once __DIR__ . '/Staging.php';
            Staging::holdMail($to, (string) ($m['subject'] ?? ''), (string) ($m['text'] ?? ''), (string) ($m['html'] ?? ''), 'ses');   // on staging: kept to read (nothing on live)
            $pdo->prepare("UPDATE email_sends SET status = 'mock' WHERE id = ?")->execute([$id]);
            return ['status' => 'mock', 'id' => $id];
        }
        if (!self::hasKeys($account)) {
            $pdo->prepare("UPDATE email_sends SET status = 'failed', error = 'No keys for this account in .env' WHERE id = ?")->execute([$id]);
            return ['status' => 'failed', 'id' => $id];
        }
        $body = ['FromEmailAddress' => self::fromAddress($m), 'Destination' => ['ToAddresses' => [$to]], 'Content' => ['Raw' => ['Data' => base64_encode($raw)]],
                 'ConfigurationSetName' => self::CONFIG_SET[$account], 'EmailTags' => [['Name' => 'send', 'Value' => (string) $id]]];
        [$code, $res] = self::api($account, 'POST', '/v2/email/outbound-emails', $body);
        $d = json_decode($res, true);
        if ($code === 200 && !empty($d['MessageId'])) {
            $pdo->prepare("UPDATE email_sends SET status = 'sent', message_id = ? WHERE id = ?")->execute([(string) $d['MessageId'], $id]);
            return ['status' => 'sent', 'id' => $id];
        }
        $pdo->prepare("UPDATE email_sends SET status = 'failed', error = ? WHERE id = ?")->execute([mb_substr('SES ' . $code . ': ' . (string) ($d['message'] ?? $res), 0, 300), $id]);
        return ['status' => 'failed', 'id' => $id];
    }

    private static function fromAddress(array $m): string
    {
        $dom = in_array($m['from_domain'] ?? '', ['send.traversence.com', 'via.traversence.com'], true) ? $m['from_domain'] : 'send.traversence.com';
        $local = preg_replace('/[^a-z0-9.\-]/', '', mb_strtolower((string) ($m['from_local'] ?? 'notices'))) ?: 'notices';
        return $local . '@' . $dom;
    }

    private static function enc(string $s): string { return preg_match('/[^\x20-\x7e]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s; }
    private static function addr(string $email, string $name): string { $name = trim(str_replace(['"', "\r", "\n"], '', $name)); return $name !== '' ? self::enc('"' . $name . '"') . ' <' . $email . '>' : $email; }

    /** The whole message: headers (one-click unsubscribe), the text with its footer, and HTML when given. */
    public static function mime(array $m, string $to, int $sendId, string $account): string
    {
        $unsub = self::unsubscribeUrl($sendId, $to);
        $footer = "\n\n--\n" . trim((string) ($m['why'] ?? 'You\'re getting this because of your Traversence account.')) . "\n"
            . ($account === 'bulk' ? 'Sent by ' . trim((string) ($m['from_name'] ?? '')) . ', ' . trim((string) ($m['postal'] ?? '')) . ", through Traversence.\n" : '')
            . 'Stop these: ' . $unsub . "\n";
        $text = str_replace("\r", '', (string) ($m['text'] ?? '')) . $footer;
        $hdr = ['From: ' . self::addr(self::fromAddress($m), (string) ($m['from_name'] ?? 'Traversence')), 'To: ' . self::addr($to, (string) ($m['to_name'] ?? '')),
                'Subject: ' . self::enc(str_replace(["\r", "\n"], ' ', (string) ($m['subject'] ?? ''))), 'Date: ' . date('r'),
                'Message-ID: <tv' . $sendId . '.' . bin2hex(random_bytes(6)) . '@' . (in_array($m['from_domain'] ?? '', ['via.traversence.com'], true) ? 'via' : 'send') . '.traversence.com>',
                'MIME-Version: 1.0', 'List-Unsubscribe: <' . $unsub . '>', 'List-Unsubscribe-Post: List-Unsubscribe=One-Click'];
        if (!empty($m['reply_to']) && filter_var($m['reply_to'], FILTER_VALIDATE_EMAIL)) $hdr[] = 'Reply-To: ' . $m['reply_to'];
        $html = (string) ($m['html'] ?? '');
        if ($html === '') return implode("\r\n", $hdr) . "\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text));
        $b = 'tv' . bin2hex(random_bytes(10));
        $html .= '<hr style="border:0;border-top:1px solid #ddd;margin:24px 0 8px"><p style="font-size:12px;color:#777">' . htmlspecialchars(trim((string) ($m['why'] ?? '')), ENT_QUOTES) . '<br>'
            . ($account === 'bulk' ? htmlspecialchars('Sent by ' . ($m['from_name'] ?? '') . ', ' . ($m['postal'] ?? '') . ', through Traversence.', ENT_QUOTES) . '<br>' : '')
            . '<a href="' . htmlspecialchars($unsub, ENT_QUOTES) . '">Stop these</a></p>';
        return implode("\r\n", $hdr) . "\r\nContent-Type: multipart/alternative; boundary=\"$b\"\r\n\r\n"
            . "--$b\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text))
            . "--$b\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) . "--$b--\r\n";
    }

    // ---- unsubscribe (one click) ----

    public static function token(int $sendId, string $to): string
    {
        $sig = substr(hash_hmac('sha256', $sendId . '|' . self::hash($to), self::linkKey()), 0, 24);
        return $sendId . '-' . $sig;
    }

    public static function unsubscribeUrl(int $sendId, string $to): string
    {
        return 'https://traversence.com/email/unsubscribe.php?t=' . rawurlencode(self::token($sendId, $to));
    }

    /** Checks a link's token: the send row, or null. */
    public static function fromToken(PDO $pdo, string $t): ?array
    {
        if (!preg_match('/^(\d+)-([a-f0-9]{24})$/', $t, $mm)) return null;
        $st = $pdo->prepare('SELECT * FROM email_sends WHERE id = ?'); $st->execute([(int) $mm[1]]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $want = substr(hash_hmac('sha256', (int) $mm[1] . '|' . $r['to_hash'], self::linkKey()), 0, 24);
        return hash_equals($want, $mm[2]) ? $r : null;
    }

    /** Stops this kind of mail to this address: notices (and the person's notices go back to the Pulse only), or this sender's. */
    public static function unsubscribe(PDO $pdo, array $row): string
    {
        $scope = (string) $row['scope'] ?: (string) $row['sender'];
        $pdo->prepare("INSERT IGNORE INTO email_suppress (addr_hash, scope, reason, created_at) VALUES (?, ?, 'unsubscribe', ?)")->execute([$row['to_hash'], $scope, self::now()]);
        if ($scope === 'notices' && !empty($row['user_id'])) {
            require_once __DIR__ . '/Notices.php';
            try { Notices::setDelivery($pdo, (int) $row['user_id'], 'pulse'); } catch (Throwable) {}
        }
        if (preg_match('/^listing:(\d+)$/', $scope, $mm) && !empty($row['user_id']) && is_file(__DIR__ . '/Marketing.php')) {   // a member: the business's own "no more", as Marketing keeps it
            require_once __DIR__ . '/Marketing.php';
            try { Marketing::unsubscribe($pdo, (int) $row['user_id'], (int) $mm[1], 'never'); } catch (Throwable) {}
        }
        return $scope;
    }

    public static function suppressed(PDO $pdo, string $hash, string $scope): bool
    {
        $st = $pdo->prepare("SELECT 1 FROM email_suppress WHERE addr_hash = ? AND (scope = 'all' OR scope = ?) LIMIT 1");
        $st->execute([$hash, $scope]);
        return $st->fetchColumn() !== false;
    }

    // ---- bounces, complaints and pauses ----

    /** One SES event (from SNS): a bounce or complaint stops mail to that address, marks the send, and may pause its sender. */
    public static function event(PDO $pdo, array $e): string
    {
        $type = (string) ($e['eventType'] ?? $e['notificationType'] ?? '');
        $msg = (string) ($e['mail']['messageId'] ?? '');
        if ($type === 'Bounce') {
            if (($e['bounce']['bounceType'] ?? '') !== 'Permanent') return 'transient bounce: kept';
            $who = array_map(fn ($r) => (string) ($r['emailAddress'] ?? ''), (array) ($e['bounce']['bouncedRecipients'] ?? []));
            $status = 'bounced';
        } elseif ($type === 'Complaint') {
            $who = array_map(fn ($r) => (string) ($r['emailAddress'] ?? ''), (array) ($e['complaint']['complainedRecipients'] ?? []));
            $status = 'complained';
        } else return 'ignored: ' . $type;
        foreach ($who as $addr) if ($addr !== '') $pdo->prepare("INSERT IGNORE INTO email_suppress (addr_hash, scope, reason, created_at) VALUES (?, 'all', ?, ?)")
            ->execute([self::hash($addr), $status === 'bounced' ? 'bounce' : 'complaint', self::now()]);
        if ($msg !== '') {
            $pdo->prepare('UPDATE email_sends SET status = ? WHERE message_id = ?')->execute([$status, $msg]);
            $st = $pdo->prepare('SELECT DISTINCT sender FROM email_sends WHERE message_id = ?'); $st->execute([$msg]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $s) self::checkPause($pdo, (string) $s);
        }
        return $status . ': ' . count($who);
    }

    /** [sends, bounced, complained] for a sender over the last 30 days. */
    public static function rates(PDO $pdo, string $sender): array
    {
        $st = $pdo->prepare("SELECT COUNT(*), SUM(status = 'bounced'), SUM(status = 'complained') FROM email_sends WHERE sender = ? AND created_at > ? AND status IN ('sent', 'bounced', 'complained')");
        $st->execute([$sender, date('Y-m-d H:i:s', time() - 30 * 86400)]);
        $r = $st->fetch(PDO::FETCH_NUM);
        return [(int) $r[0], (int) $r[1], (int) $r[2]];
    }

    /** Pauses a sender (never Traversence's own notices) when its rates cross the line; it's told why, and our team can lift it. */
    public static function checkPause(PDO $pdo, string $sender): bool
    {
        if ($sender === 'traversence') return false;
        [$n, $b, $c] = self::rates($pdo, $sender);
        if ($n < self::MIN_SENDS) return false;
        $why = $b / $n >= self::PAUSE_BOUNCE ? 'Bounces at ' . round($b / $n * 100, 1) . '% (the line is 3%): check the list is current and everyone on it agreed to hear from you.'
             : ($c / $n >= self::PAUSE_COMPLAINT ? 'Spam complaints at ' . round($c / $n * 100, 2) . '% (the line is 0.08%): send only to people who asked for your mail.' : '');
        if ($why === '') return false;
        $pdo->prepare('INSERT INTO email_pauses (sender, reason, paused_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE reason = VALUES(reason), paused_at = VALUES(paused_at), lifted_by = NULL, lifted_at = NULL')
            ->execute([$sender, $why, self::now()]);
        return true;
    }

    public static function paused(PDO $pdo, string $sender): bool
    {
        try { $st = $pdo->prepare('SELECT 1 FROM email_pauses WHERE sender = ? AND lifted_at IS NULL'); $st->execute([$sender]); return $st->fetchColumn() !== false; } catch (Throwable) { return false; }
    }

    public static function liftPause(PDO $pdo, string $sender, int $staff): void
    {
        $pdo->prepare('UPDATE email_pauses SET lifted_by = ?, lifted_at = ? WHERE sender = ? AND lifted_at IS NULL')->execute([$staff, self::now(), $sender]);
    }

    // ---- cost (Services & usage) ----

    /** This month: [messages sent (both accounts), dollars at SES_USD_PER_1000]. */
    public static function month(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [0, 0.0];
        $st = $pdo->prepare("SELECT COUNT(*) FROM email_sends WHERE created_at >= ? AND status IN ('sent', 'bounced', 'complained')"); $st->execute([date('Y-m-01 00:00:00')]);
        $n = (int) $st->fetchColumn();
        return [$n, $n / 1000 * (float) self::env('SES_USD_PER_1000', '0.10')];
    }
    public static function monthUsd(PDO $pdo): float { return self::month($pdo)[1]; }

    // ---- AWS calls ----

    /** A signed SES (API v2) call for an account: [http code, body]. */
    public static function api(string $account, string $method, string $path, ?array $json = null): array
    {
        [$key, $secret] = self::keys($account);
        $host = 'email.' . self::region() . '.amazonaws.com';
        $body = $json === null ? '' : (string) json_encode($json, JSON_UNESCAPED_SLASHES);
        return self::signed($method, 'ses', $host, $path, $body, ['content-type' => 'application/json'], $key, $secret);
    }

    /** A signed SNS call (its Query API): [http code, body XML]. */
    public static function sns(string $account, array $params): array
    {
        [$key, $secret] = self::keys($account);
        $body = http_build_query($params + ['Version' => '2010-03-31'], '', '&', PHP_QUERY_RFC3986);
        return self::signed('POST', 'sns', 'sns.' . self::region() . '.amazonaws.com', '/', $body, ['content-type' => 'application/x-www-form-urlencoded; charset=utf-8'], $key, $secret);
    }

    /** A signed call to SES's Query API (v1: receipt rules for receiving mail, decisions/0172 §4.7): [http code, body XML]. */
    public static function query(string $account, array $params): array
    {
        [$key, $secret] = self::keys($account);
        $body = http_build_query($params + ['Version' => '2010-12-01'], '', '&', PHP_QUERY_RFC3986);
        return self::signed('POST', 'ses', 'email.' . self::region() . '.amazonaws.com', '/', $body, ['content-type' => 'application/x-www-form-urlencoded; charset=utf-8'], $key, $secret);
    }

    private static function signed(string $method, string $service, string $host, string $path, string $body, array $headers, string $key, string $secret): array
    {
        if ($key === '' || $secret === '') return [0, 'No keys'];
        $now = gmdate('Ymd\THis\Z'); $hash = hash('sha256', $body);
        $h = array_change_key_case($headers + ['host' => $host, 'x-amz-date' => $now, 'x-amz-content-sha256' => $hash], CASE_LOWER);
        $h['authorization'] = Aws::authorization($method, $path, '', $h, $hash, $key, $secret, self::region(), $service, $now);
        $out = []; foreach ($h as $k2 => $v) if ($k2 !== 'host') $out[] = $k2 . ': ' . $v;
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold('https://' . $host . $path, 'Amazon ' . strtoupper($service) . ' ' . $method . ' ' . $path)) !== null) return [0, $w];   // SES and SNS send and change our account: held on staging
        $ch = curl_init('https://' . $host . $path);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => $out]
            + ($body !== '' ? [CURLOPT_POSTFIELDS => $body] : []));
        $res = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return [$code, is_string($res) ? $res : ''];
    }

    // ---- setup (the admin Pulse case "Set up email sending") ----

    /**
     * Creates each account's sending domains (or reads them back) and returns the DNS records they need:
     * [[name relative to the zone, type, value], …]: DKIM (3 CNAMEs each), the mail-from MX and SPF, and DMARC.
     */
    public static function setupIdentities(PDO $pdo, string $account): array
    {
        if (!self::hasKeys($account)) throw new RuntimeException('Add ' . ($account === 'bulk' ? 'SES_BULK' : 'SES_PERSONAL') . '_KEY_ID and _SECRET to .env first.');
        $recs = [];
        self::api($account, 'POST', '/v2/email/configuration-sets', ['ConfigurationSetName' => self::CONFIG_SET[$account]]);   // already there: fine
        foreach (self::IDENTITIES[$account] as $dom) {
            [$code, $res] = self::api($account, 'POST', '/v2/email/identities', ['EmailIdentity' => $dom, 'ConfigurationSetName' => self::CONFIG_SET[$account]]);
            if ($code !== 200) {   // made before: read it back
                [$code, $res] = self::api($account, 'GET', '/v2/email/identities/' . rawurlencode($dom));
                if ($code !== 200) throw new RuntimeException('SES (' . $account . ', ' . $dom . ') answered ' . $code . ': ' . mb_substr($res, 0, 200));
            }
            $d = json_decode($res, true) ?: [];
            foreach ((array) ($d['DkimAttributes']['Tokens'] ?? []) as $t) $recs[] = [$t . '._domainkey.' . self::rel($dom), 'CNAME', $t . '.dkim.amazonses.com'];
            self::api($account, 'PUT', '/v2/email/identities/' . rawurlencode($dom) . '/mail-from', ['MailFromDomain' => 'bounce.' . $dom, 'BehaviorOnMxFailure' => 'USE_DEFAULT_VALUE']);
            $recs[] = ['bounce.' . self::rel($dom), 'MX', '10 feedback-smtp.' . self::region() . '.amazonses.com'];
            $recs[] = ['bounce.' . self::rel($dom), 'TXT', 'v=spf1 include:amazonses.com ~all'];
            // DMARC reports to support@ (Jason, 2026-11-01); 'one': a name has one DMARC record, so an older one is replaced
            $recs[] = ['_dmarc.' . self::rel($dom), 'TXT', self::DMARC, 'one'];
        }
        $all = json_decode(self::state($pdo, 'dns_records'), true) ?: [];
        foreach ($all as $k => $r) if (str_starts_with((string) $r[0], '_dmarc.')) unset($all[$k]);   // an older DMARC value goes
        foreach ($recs as $r) $all[implode('|', $r)] = $r;
        self::setState($pdo, 'dns_records', (string) json_encode($all));
        return array_values($all);
    }

    private static function rel(string $dom): string { return preg_replace('/\.' . preg_quote(self::ZONE, '/') . '$/', '', $dom); }

    /** Adds the records setup found to traversence.com's DNS (Bluehost) through the cPanel API: [added, already there]. */
    public static function applyDns(PDO $pdo): array
    {
        require_once __DIR__ . '/CPanel.php';
        $recs = array_values(json_decode(self::state($pdo, 'dns_records'), true) ?: []);
        foreach ($recs as $i => $r) if (str_starts_with((string) $r[0], '_dmarc.')) $recs[$i] = [$r[0], 'TXT', self::DMARC, 'one'];   // saved before the change
        if (!$recs) throw new RuntimeException('Set up the sending domains first: that\'s where the records come from.');
        $out = CPanel::dnsEnsure(self::ZONE, $recs);
        $keep = []; foreach ($recs as $r) $keep[implode('|', $r)] = $r;
        self::setState($pdo, 'dns_records', (string) json_encode($keep));
        if (!self::state($pdo, 'dns_applied')) self::setState($pdo, 'dns_applied', self::now());   // when they first went in: the two-hour wait counts from here
        self::setState($pdo, 'dmarc_value', self::DMARC);
        return $out;
    }

    /**
     * The records as the world sees them (what AWS reads), not as cPanel says: each one looked up in public DNS.
     * Returns the ones not found, as "TYPE name → value" for a person to add by hand if the site can't. Kept in
     * dns_missing for the case to show.
     */
    public static function unpublished(PDO $pdo): array
    {
        $miss = [];
        foreach (array_values(json_decode(self::state($pdo, 'dns_records'), true) ?: []) as $r) {
            [$rel, $type, $value] = $r;
            $fq = $rel === '' ? self::ZONE : $rel . '.' . self::ZONE;
            $want = strtolower(rtrim((string) $value, '.'));
            $found = false;
            $got = @dns_get_record($fq, ['CNAME' => DNS_CNAME, 'MX' => DNS_MX, 'TXT' => DNS_TXT][$type] ?? DNS_ANY) ?: [];
            foreach ($got as $g) {
                if ($type === 'CNAME' && strtolower(rtrim((string) ($g['target'] ?? ''), '.')) === $want) $found = true;
                if ($type === 'MX' && str_ends_with($want, strtolower(rtrim((string) ($g['target'] ?? ''), '.')))) $found = true;
                if ($type === 'TXT' && strtolower(implode('', (array) ($g['entries'] ?? [$g['txt'] ?? '']))) === $want) $found = true;
            }
            if (!$found) $miss[] = $type . ' ' . $rel . ' → ' . $value;
        }
        self::setState($pdo, 'dns_missing', (string) json_encode($miss));
        self::setState($pdo, 'dns_checked', self::now());
        return $miss;
    }

    /** Whether public DNS shows more than one DMARC record at any of our DMARC names (providers then ignore them all). */
    public static function dmarcExtra(PDO $pdo): bool
    {
        foreach (array_values(json_decode(self::state($pdo, 'dns_records'), true) ?: []) as $r) {
            if (!str_starts_with((string) $r[0], '_dmarc.')) continue;
            $n = 0;
            foreach (@dns_get_record($r[0] . '.' . self::ZONE, DNS_TXT) ?: [] as $g) if (stripos(implode('', (array) ($g['entries'] ?? [$g['txt'] ?? ''])), 'v=DMARC1') === 0) $n++;
            if ($n > 1) return true;
        }
        return false;
    }

    /** Bounce and complaint reports: an SNS topic per account, our endpoint subscribed, the configuration set sending to it. */
    public static function setupEvents(PDO $pdo, string $account, string $endpoint = 'https://traversence.com/api/ses-events.php'): string
    {
        if (!self::hasKeys($account)) throw new RuntimeException('Add the account\'s keys to .env first.');
        [$code, $res] = self::sns($account, ['Action' => 'CreateTopic', 'Name' => 'tv-ses-events-' . $account]);
        if ($code !== 200 || !preg_match('#<TopicArn>([^<]+)</TopicArn>#', $res, $mm)) throw new RuntimeException('SNS answered ' . $code . ': ' . mb_substr(strip_tags($res), 0, 200));
        $arn = $mm[1];
        self::setState($pdo, 'topic_' . $account, $arn);
        self::sns($account, ['Action' => 'Subscribe', 'TopicArn' => $arn, 'Protocol' => 'https', 'Endpoint' => $endpoint]);
        [$code, $res] = self::api($account, 'POST', '/v2/email/configuration-sets/' . self::CONFIG_SET[$account] . '/event-destinations',
            ['EventDestinationName' => 'tv-bounces', 'EventDestination' => ['Enabled' => true, 'MatchingEventTypes' => ['BOUNCE', 'COMPLAINT'], 'SnsDestination' => ['TopicArn' => $arn]]]);
        if ($code !== 200 && !str_contains($res, 'AlreadyExists')) throw new RuntimeException('SES answered ' . $code . ': ' . mb_substr($res, 0, 200));
        return $arn;
    }

    /** Where setup stands, per account: keys, production access, each domain verified, reports connected; and the DNS. */
    public static function status(PDO $pdo): array
    {
        $out = ['mode' => self::mode(), 'region' => self::region(), 'dns_applied' => self::state($pdo, 'dns_applied'), 'accounts' => []];
        foreach (array_keys(self::ACCOUNTS) as $a) {
            $s = ['keys' => self::hasKeys($a), 'production' => null, 'domains' => [], 'events' => self::state($pdo, 'topic_' . $a) !== ''];
            if ($s['keys'] && self::mode() !== 'off') {   // reading what AWS has is fine in mock mode too: only sending waits for live
                [$c, $r] = self::api($a, 'GET', '/v2/email/account');
                if ($c === 200) $s['production'] = (bool) ((json_decode($r, true) ?: [])['ProductionAccessEnabled'] ?? false);
                foreach (self::IDENTITIES[$a] as $dom) {
                    [$c, $r] = self::api($a, 'GET', '/v2/email/identities/' . rawurlencode($dom));
                    $s['domains'][$dom] = $c === 200 && (bool) ((json_decode($r, true) ?: [])['VerifiedForSendingStatus'] ?? false);
                }
            }
            $out['accounts'][$a] = $s;
        }
        return $out;
    }

    /** Checks with AWS and keeps the answer (the Pulse reads it, so a page load never waits on AWS). */
    public static function check(PDO $pdo): array
    {
        $st = self::status($pdo);
        self::setState($pdo, 'status', (string) json_encode($st + ['checked_at' => date('Y-m-d H:i:s')]));
        return $st;
    }

    /** What's left of the setup, in plain words (empty when it's done): from what's on file and the last check. */
    public static function todo(PDO $pdo): array
    {
        $last = json_decode(self::state($pdo, 'status'), true) ?: [];
        $p = (array) ($last['accounts']['personal'] ?? []);
        $out = [];
        if (!self::hasKeys('personal')) $out['keys'] = 'The site\'s AWS key isn\'t in .env';
        if (self::mode() === 'off') $out['mode'] = 'SES_MODE is off in .env';
        elseif (self::mode() === 'mock') $out['live'] = 'Sending is in mock mode (recorded, not sent)';
        if (($p['production'] ?? null) !== true) $out['production'] = 'Production access not confirmed';
        if (!self::state($pdo, 'dns_records')) $out['identities'] = 'Sending domains not made yet';
        $miss = json_decode(self::state($pdo, 'dns_missing'), true);
        if (!self::state($pdo, 'dns_applied')) $out['dns'] = 'DNS records not added';
        elseif (!is_array($miss) || $miss) $out['dns'] = is_array($miss) ? count($miss) . ' DNS record' . (count($miss) === 1 ? '' : 's') . ' not published yet' : 'DNS records not checked yet';   // done only when public DNS shows them all
        elseif (self::state($pdo, 'dmarc_value') !== self::DMARC) $out['dns'] = 'DMARC record to update (reports to support@)';   // runs again once
        elseif (self::state($pdo, 'dmarc_single') === '') $out['dns'] = 'DMARC: one record at each name (a second one makes providers ignore both)';   // 2026-11-10: runs until public DNS shows one
        $topic = self::state($pdo, 'topic_personal');
        if (!$topic) $out['events'] = 'Bounce reports not connected';
        elseif (!self::state($pdo, 'confirmed_' . md5($topic))) $out['events'] = 'Bounce reports waiting for AWS to confirm the subscription';   // done only when /api/ses-events.php confirmed it
        $doms = (array) ($p['domains'] ?? []);
        if (!$doms || in_array(false, $doms, true)) $out['verified'] = 'Sending domains not verified yet';
        if (self::mode() === 'live' && ($p['production'] ?? null) === true && !self::state($pdo, 'test_sent')) $out['test'] = 'Test email not sent yet';
        return $out;
    }

    /** What production access is asked with (decisions/0137 §8): what's sent, and how bounces, complaints and unsubscribes are handled. */
    public const USE_CASE = 'Traversence (https://traversence.com) is a travel and local community site. We send transactional email only to members '
        . 'who asked for it: notices about their groups, their own account and orders, and a weekly digest they chose. No bought or rented lists. '
        . 'Bounces and complaints come back through SNS to our endpoint and stop all further mail to that address at once; sending pauses itself '
        . 'above a 3% bounce or 0.08% complaint rate. Every message carries one-click unsubscribe (List-Unsubscribe-Post) and our postal address.';

    /**
     * The setup, run by itself (Jason, 2026-11-01: "if I have to click a button and then it does what it needs to do, why
     * do I have to click it?"): every step a person isn't needed for, in order, as far as it can get. The scheduled job
     * ses_setup_tick runs it every 15 minutes until nothing's left; the Pulse case only shows where it stands. Each step
     * runs once; the AWS check runs each time. Returns what it did, in words; a step that fails stops the run and is kept
     * (auto_error) for the case to show, and the next run tries again.
     */
    public static function autoSetup(PDO $pdo): array
    {
        $did = [];
        if (!self::hasKeys('personal') || self::mode() === 'off') return $did;   // .env first: a person's step
        try {
            $todo = self::todo($pdo);
            if (isset($todo['identities'])) { $n = count(self::setupIdentities($pdo, 'personal')); $did[] = 'Sending domains made (' . $n . ' DNS records).'; }
            if (!isset($todo['identities']) && self::state($pdo, 'dns_records') && self::state($pdo, 'dmarc_single') === '' && !self::unpublished($pdo)) {
                // one DMARC record per name (2026-11-10: an older one stayed beside the new, and providers ignored both)
                if (self::dmarcExtra($pdo)) { [$a] = self::applyDns($pdo); $did[] = 'DMARC: ' . $a . ' extra record' . ($a === 1 ? '' : 's') . ' taken out.'; }
                if (!self::dmarcExtra($pdo)) self::setState($pdo, 'dmarc_single', self::now());   // public DNS shows one: done
            }
            if (!isset($todo['identities']) && self::state($pdo, 'dns_records') && self::unpublished($pdo)) {   // checked in public DNS each run, not taken on cPanel's word
                [$a, $h] = self::applyDns($pdo);
                $miss = self::unpublished($pdo);
                $did[] = 'DNS: ' . $a . ' added, ' . $h . ' already in the zone, ' . count($miss) . ' not yet seen in public DNS.';
                // in the zone for two hours and still not public: the DNS the world sees isn't this zone; a person adds them
                $since = strtotime(self::state($pdo, 'dns_applied') ?: 'now');
                if ($miss && $a === 0 && $since < time() - 7200) throw new RuntimeException(count($miss) . ' DNS records are in cPanel\'s zone but not in public DNS after two hours: add them in Bluehost → Domains → traversence.com → DNS (listed in step 4).');
            }
            if (isset($todo['events'])) { self::setupEvents($pdo, 'personal'); $did[] = 'Bounce and complaint reports connected.'; }
            $st = self::check($pdo); $p = $st['accounts']['personal'];
            $verified = $p['domains'] && !in_array(false, $p['domains'], true);
            if ($verified && $p['production'] === false && self::state($pdo, 'prod_asked') === '') {   // asked once; AWS answers within a day
                [$c, $r] = self::api('personal', 'POST', '/v2/email/account/details', ['MailType' => 'TRANSACTIONAL', 'WebsiteURL' => 'https://traversence.com',
                    'UseCaseDescription' => self::USE_CASE, 'ContactLanguage' => 'EN', 'AdditionalContactEmailAddresses' => ['support@traversence.com'], 'ProductionAccessEnabled' => true]);
                if ($c !== 200) throw new RuntimeException('Asking AWS for production access: AWS answered ' . $c . ' (' . mb_substr($r, 0, 160) . ')');
                self::setState($pdo, 'prod_asked', self::now()); $did[] = 'Production access asked for.';
            }
            if ($verified && $p['production'] === true && self::mode() === 'live' && self::state($pdo, 'test_sent') === '') {   // one test, once it can really go
                $did[] = 'Test to support@traversence.com: ' . self::test($pdo, 'support@traversence.com') . '.';
                self::setState($pdo, 'test_sent', self::now());
            }
            self::setState($pdo, 'auto_error', '');
        } catch (Throwable $e) {
            self::setState($pdo, 'auto_error', mb_substr($e->getMessage(), 0, 400));
            $did[] = 'Stopped: ' . $e->getMessage();
        }
        self::setState($pdo, 'auto_at', self::now());
        if ($did) self::setState($pdo, 'auto_did', mb_substr(implode(' ', $did), 0, 600));
        return $did;
    }

    /** A test email to a staff member, through the personal account. */
    public static function test(PDO $pdo, string $to): string
    {
        $r = self::send($pdo, ['account' => 'personal', 'from_local' => 'notices', 'from_domain' => 'send.traversence.com', 'from_name' => 'Traversence',
            'to' => $to, 'subject' => 'Traversence email test', 'text' => 'This came through Amazon SES, from send.traversence.com. If you can read it, email sending works.',
            'sender' => 'traversence', 'purpose' => 'test', 'scope' => 'test', 'why' => 'Someone on the Traversence team sent this test from the admin Pulse.']);
        return (self::STATUSES[$r['status']] ?? $r['status']) . ' (send #' . $r['id'] . ')';
    }
}
