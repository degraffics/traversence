<?php

declare(strict_types=1);

/**
 * api/lib/Marketing.php — a person and the businesses they link (decisions/0047 §3).
 *
 * Linking a business opens two-way in-app messages with it: the business can send offers and news to the
 * person's Traversence inbox, and the person can message it. Unlinking ends that at once. The person can
 * stay linked but unsubscribe (and choose when the business may ask again: 1, 3 or 6 months, or never), pick
 * a frequency, and share contact details with the business itself (email or text only then; kept apart from
 * person-to-person sharing, so it is always one person and one business). One master switch,
 * "No marketing from anyone", stops every business.
 *
 * marketing_optins holds only departures from the default: a 'no' row is an unsubscribe; a 'yes' row
 * holds a frequency other than the weekly digest. No row, while linked, means subscribed (weekly).
 */
final class Marketing
{
    public const FREQUENCIES = ['any' => 'As it happens', 'weekly' => 'Weekly digest', 'big' => 'Big offers only'];
    public const ASK_AGAIN = ['1m' => '1 month', '3m' => '3 months', '6m' => '6 months', 'never' => 'Never'];
    public const SHARE_FIELDS = ['phone' => 'Phone', 'email' => 'Email', 'address' => 'Mailing address', 'social' => 'Social'];

    public static function tableExists(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM marketing_optins LIMIT 1'); return true; } catch (PDOException) { return false; }
    }

    public static function masterOff(PDO $pdo, int $uid): bool
    {
        try {
            $st = $pdo->prepare('SELECT no_marketing FROM user_settings WHERE user_id = ?');
            $st->execute([$uid]);
            return (int) $st->fetchColumn() === 1;
        } catch (PDOException) { return false; }
    }

    public static function setMaster(PDO $pdo, int $uid, bool $off): void
    {
        $st = $pdo->prepare('SELECT 1 FROM user_settings WHERE user_id = ?');
        $st->execute([$uid]);
        if ($st->fetchColumn() === false) $pdo->prepare('INSERT INTO user_settings (user_id) VALUES (?)')->execute([$uid]);
        $pdo->prepare('UPDATE user_settings SET no_marketing = ? WHERE user_id = ?')->execute([$off ? 1 : 0, $uid]);
    }

    /** Linking is the person reaching out first: any earlier unsubscribe (even "never") is cleared. */
    public static function onLink(PDO $pdo, int $uid, int $entityId): void
    {
        if (self::tableExists($pdo)) $pdo->prepare('DELETE FROM marketing_optins WHERE user_id = ? AND entity_id = ?')->execute([$uid, $entityId]);
    }

    /** Unlinking ends offers and takes back shared contact details. A "never" is kept so the business can't ask again. */
    public static function onUnlink(PDO $pdo, int $uid, int $entityId): void
    {
        if (self::tableExists($pdo)) $pdo->prepare('DELETE FROM marketing_optins WHERE user_id = ? AND entity_id = ? AND never = 0')->execute([$uid, $entityId]);
        if (self::sharesReady($pdo)) self::share($pdo, $uid, $entityId, []);   // unlinking takes back what they could see
    }

    public static function subscribe(PDO $pdo, int $uid, int $entityId, string $frequency): void
    {
        if (!isset(self::FREQUENCIES[$frequency])) $frequency = 'weekly';
        $pdo->prepare('DELETE FROM marketing_optins WHERE user_id = ? AND entity_id = ?')->execute([$uid, $entityId]);
        if ($frequency !== 'weekly') {
            $pdo->prepare("INSERT INTO marketing_optins (user_id, entity_id, status, frequency) VALUES (?, ?, 'yes', ?)")->execute([$uid, $entityId, $frequency]);
        }
    }

    public static function unsubscribe(PDO $pdo, int $uid, int $entityId, string $askAgain): void
    {
        if (!isset(self::ASK_AGAIN[$askAgain])) $askAgain = '3m';
        $never = $askAgain === 'never';
        $after = $never ? null : date('Y-m-d H:i:s', strtotime('+' . (int) $askAgain . ' months'));
        $pdo->prepare('DELETE FROM marketing_optins WHERE user_id = ? AND entity_id = ?')->execute([$uid, $entityId]);
        $pdo->prepare("INSERT INTO marketing_optins (user_id, entity_id, status, frequency, ask_after, never) VALUES (?, ?, 'no', 'weekly', ?, ?)")
            ->execute([$uid, $entityId, $after, $never ? 1 : 0]);
    }

    /** May this business ask this person (to link, or to subscribe again) right now? For decisions/0047 phase 3b. */
    public static function mayAsk(PDO $pdo, int $uid, int $entityId): bool
    {
        if (!self::tableExists($pdo) || self::masterOff($pdo, $uid)) return false;
        $st = $pdo->prepare('SELECT status, ask_after, never FROM marketing_optins WHERE user_id = ? AND entity_id = ?');
        $st->execute([$uid, $entityId]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return true;
        if ($r['status'] === 'yes' || (int) $r['never']) return false;
        return $r['ask_after'] !== null && strtotime((string) $r['ask_after']) <= time();
    }

    /** People who manage this business's listing: whoever a contact card shared "with the business" goes to. */
    public static function staff(PDO $pdo, int $entityId): array
    {
        try {
            $st = $pdo->prepare('SELECT DISTINCT user_id FROM listing_access WHERE entity_id = ?');
            $st->execute([$entityId]);
            return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        } catch (PDOException) { return []; }
    }

    public static function sharesReady(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM business_contact_shares LIMIT 1'); return true; } catch (PDOException) { return false; }
    }

    /** Which of this person's contact fields the business can see (its own list, apart from person-to-person shares). */
    public static function shared(PDO $pdo, int $uid, int $entityId): array
    {
        if (!self::sharesReady($pdo)) return [];
        $st = $pdo->prepare('SELECT field FROM business_contact_shares WHERE user_id = ? AND entity_id = ? AND revoked_at IS NULL');
        $st->execute([$uid, $entityId]);
        return $st->fetchAll(PDO::FETCH_COLUMN);
    }

    /** Shares exactly these fields with the business; the rest are taken back. */
    public static function share(PDO $pdo, int $uid, int $entityId, array $fields): void
    {
        $fields = array_values(array_intersect(array_keys(self::SHARE_FIELDS), $fields));
        foreach (array_keys(self::SHARE_FIELDS) as $f) {
            if (in_array($f, $fields, true)) {
                $st = $pdo->prepare('SELECT revoked_at FROM business_contact_shares WHERE user_id = ? AND entity_id = ? AND field = ?');
                $st->execute([$uid, $entityId, $f]);
                $row = $st->fetch(PDO::FETCH_ASSOC);
                if ($row === false) {
                    $pdo->prepare('INSERT INTO business_contact_shares (user_id, entity_id, field) VALUES (?, ?, ?)')->execute([$uid, $entityId, $f]);
                } elseif ($row['revoked_at'] !== null) {
                    $pdo->prepare('UPDATE business_contact_shares SET revoked_at = NULL, created_at = NOW() WHERE user_id = ? AND entity_id = ? AND field = ?')->execute([$uid, $entityId, $f]);
                }
            } else {
                $pdo->prepare('UPDATE business_contact_shares SET revoked_at = NOW() WHERE user_id = ? AND entity_id = ? AND field = ? AND revoked_at IS NULL')
                    ->execute([$uid, $entityId, $f]);
            }
        }
    }

    /** The live values of what this person shares with the business, for its managers. */
    public static function cardForBusiness(PDO $pdo, int $uid, int $entityId): array
    {
        $fields = self::shared($pdo, $uid, $entityId);
        if (!$fields) return [];
        try {
            $st = $pdo->prepare('SELECT phone, email, address, social FROM contact_cards WHERE user_id = ?');
            $st->execute([$uid]);
            $card = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException) { return []; }
        $out = [];
        foreach ($fields as $f) if ((string) ($card[$f] ?? '') !== '') $out[$f] = (string) $card[$f];
        return $out;
    }

    /** Every business this person has linked, with where they stand. */
    public static function all(PDO $pdo, int $uid): array
    {
        $st = $pdo->prepare("SELECT l.target_id, l.label, m.status, m.frequency, m.ask_after, m.never FROM user_links l
                               LEFT JOIN marketing_optins m ON m.user_id = l.user_id AND m.entity_id = l.target_id
                              WHERE l.user_id = ? AND l.target_type = 'business' ORDER BY l.label");
        $st->execute([$uid]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $id = (int) $r['target_id'];
            $out[] = ['entity_id' => $id, 'name' => (string) $r['label'], 'subscribed' => $r['status'] !== 'no',
                      'frequency' => $r['status'] === 'yes' ? $r['frequency'] : 'weekly', 'ask_after' => $r['ask_after'],
                      'never' => (int) $r['never'], 'shared' => self::shared($pdo, $uid, $id),
                      'staffed' => (bool) array_diff(self::staff($pdo, $id), [$uid]), 'shares_ready' => self::sharesReady($pdo),
                      'actions' => self::actionsFor($pdo, $id, $uid)];
        }
        return $out;
    }

    /** What works for this listing, for this person (decisions/0172 §3.1): Message only when someone manages it. */
    private static function actionsFor(PDO $pdo, int $id, int $uid): array
    {
        try {
            require_once __DIR__ . '/ListingActions.php';
            $out = [];
            foreach (ListingActions::actions($pdo, $id, ['id' => $uid], [], 'page') as $k => $a) if (in_array($k, ['message', 'leave', 'call', 'email', 'website'], true)) $out[] = ['key' => $k] + $a;
            return $out;
        } catch (Throwable $x) { error_log('marketing actions: ' . $x->getMessage()); return []; }
    }

    /**
     * The people who linked this business, for its team (decisions/0141 §2.6): the Linking consent tells each person the
     * business can see that they linked it, so names show; contact details only as each person shares them, read live
     * from their own card (Marketing::cardForBusiness), never copied, so unlinking or a change takes effect at once. No
     * export. Newest first; ['total', 'rows' => [uid, name, since, subscribed, frequency, card]].
     */
    public static function linkers(PDO $pdo, int $entityId, int $limit = 50, int $offset = 0, string $find = ''): array
    {
        // who shows by name: the open-links rule of Links::linkedBy (decisions/0052): made under the open terms, or the
        // linker has seen the one-time notice; not suspended, not paused
        $from = "FROM user_links l JOIN users u ON u.id = l.user_id
                   LEFT JOIN tool_consents c ON c.user_id = l.user_id AND c.tool = 'linking'
                   LEFT JOIN user_settings s ON s.user_id = l.user_id";
        $where = "l.target_type = 'business' AND l.target_id = ? AND COALESCE(u.is_suspended, 0) = 0 AND COALESCE(c.status, '') <> 'inactive'
                  AND (s.open_links_ack IS NOT NULL OR (c.status = 'active' AND c.activated_at <= l.created_at))";
        $args = [(string) $entityId];
        if ($find !== '') { $where .= ' AND u.display_name LIKE ?'; $args[] = '%' . addcslashes($find, '%_\\') . '%'; }
        try { $st = $pdo->prepare("SELECT COUNT(*) $from WHERE $where"); $st->execute($args); $total = (int) $st->fetchColumn(); }
        catch (PDOException) { return ['total' => 0, 'rows' => []]; }   // tables not there yet
        $mo = self::tableExists($pdo);
        $st = $pdo->prepare("SELECT l.user_id, u.display_name, l.created_at, COALESCE(s.no_marketing, 0) AS off" . ($mo ? ', m.status, m.frequency' : ', NULL AS status, NULL AS frequency')
            . " $from" . ($mo ? ' LEFT JOIN marketing_optins m ON m.user_id = l.user_id AND m.entity_id = l.target_id' : '')
            . " WHERE $where ORDER BY l.created_at DESC, l.user_id DESC LIMIT " . max(1, min(200, $limit)) . ' OFFSET ' . max(0, $offset));
        $st->execute($args);
        $rows = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $u = (int) $r['user_id'];
            $rows[] = ['uid' => $u, 'name' => trim((string) $r['display_name']) !== '' ? (string) $r['display_name'] : 'Member #' . $u, 'since' => (string) $r['created_at'],
                'subscribed' => $r['status'] !== 'no' && !(int) $r['off'], 'frequency' => $r['status'] === 'yes' ? (string) $r['frequency'] : 'weekly',
                'card' => self::cardForBusiness($pdo, $u, $entityId)];
        }
        return ['total' => $total, 'rows' => $rows];
    }

    /** Business Insights: counts only, never names. */
    public static function counts(PDO $pdo, int $entityId): array
    {
        $one = function (string $sql) use ($pdo, $entityId): int {
            $st = $pdo->prepare($sql);
            $st->execute([(string) $entityId]);
            return (int) $st->fetchColumn();
        };
        $base = "FROM user_links l LEFT JOIN marketing_optins m ON m.user_id = l.user_id AND m.entity_id = l.target_id
                 LEFT JOIN user_settings s ON s.user_id = l.user_id WHERE l.target_type = 'business' AND l.target_id = ?";
        $sharing = self::sharesReady($pdo) ? $one("SELECT COUNT(DISTINCT c.user_id) FROM business_contact_shares c JOIN user_links l ON l.user_id = c.user_id
                              AND l.target_type = 'business' AND l.target_id = c.entity_id WHERE c.entity_id = ? AND c.revoked_at IS NULL") : 0;
        return [
            'linked' => $one("SELECT COUNT(*) $base"),
            'subscribed' => $one("SELECT COUNT(*) $base AND COALESCE(m.status, 'yes') = 'yes' AND COALESCE(s.no_marketing, 0) = 0"),
            'unsubscribed' => $one("SELECT COUNT(*) $base AND (m.status = 'no' OR COALESCE(s.no_marketing, 0) = 1)"),
            'new_30d' => $one("SELECT COUNT(*) $base AND l.created_at >= NOW() - INTERVAL 30 DAY"),
            'sharing_contact' => $sharing,
            'never_ask' => $one("SELECT COUNT(*) FROM marketing_optins WHERE entity_id = ? AND never = 1"),
        ];
    }
}
