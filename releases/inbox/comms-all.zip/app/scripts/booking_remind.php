<?php
// app/scripts/booking_remind.php — Booking reminders (Reminds customers a day before a stay or rental and 2 hours before check-in, once each). 15min; sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('booking_remind');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Bookings.php';
$pdo = Database::connection();
$n = (int) Bookings::remind($pdo);
echo 'Reminders sent: ' . $n . ".\n";
