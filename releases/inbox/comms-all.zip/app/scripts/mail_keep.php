<?php
// app/scripts/mail_keep.php — Mailboxes: keep 90 days (Our working copy of connected mailboxes keeps the last 90 days for search and threading; the mailbox itself keeps everything). daily; sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('mail_keep');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Mailboxes.php';
$pdo = Database::connection();
$n = (int) Mailboxes::purge($pdo);
echo 'Older emails removed from our copy: ' . $n . ".\n";
