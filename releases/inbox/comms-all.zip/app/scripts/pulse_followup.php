<?php
// app/scripts/pulse_followup.php — Pulse: follow-ups (Brings back, unread and on top, each item someone flagged to follow up once its time comes, and tells them). 10min; sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('pulse_followup');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/PulseMarks.php';
$pdo = Database::connection();
$n = (int) PulseMarks::due($pdo);
echo 'Follow-ups brought back: ' . $n . ".\n";
