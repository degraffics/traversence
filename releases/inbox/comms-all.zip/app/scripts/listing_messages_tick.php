<?php
// app/scripts/listing_messages_tick.php — messages left on unclaimed listings (decisions/0172 §3.3; ListingMessages::tick):
// the pace of requests to a listing's email, unconfirmed guest emails deleted after 48 hours, the 90-day expiry. Hourly;
// sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('listing_messages_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/ListingMessages.php';
$r = ListingMessages::tick(Database::connection());
echo 'Done: ' . json_encode($r) . ".\n";
