<?php
// app/scripts/mail_sync.php — Mailboxes in Pulse (Reads every connected mailbox). 5min; sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('mail_sync');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Mailboxes.php';
$pdo = Database::connection();
$n = (int) Mailboxes::syncAll($pdo);
echo 'New emails stored: ' . $n . ".\n";
