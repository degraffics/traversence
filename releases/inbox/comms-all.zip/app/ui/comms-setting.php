<?php
// app/ui/comms-setting.php — the one Communications setting (decisions/0172 §4.4), drawn the same for a member (Dashboard →
// App Settings) and for our staff (Dashboard → Your communications in the admin; Jason, 2026-11-18: "one Communications
// setting per person"): each kind × Pulse, email and push, quiet hours (off unless set), push on this device, the weekly
// email of notices. It reads and writes /user/api/comms.php.
declare(strict_types=1);

function tv_comms_setting(string $who = 'member'): string
{
    ob_start(); ?>
        <h3 class="ab-h" id="communications">Communications</h3>
        <p class="text-sm text-[#5C4632]">Everything reaches your Pulse. Choose what also comes by email or push, and when to keep quiet.<?= $who === 'member' ? ' Marketing from businesses is under <a class="underline text-amber-800" href="#security">Privacy Settings</a>.' : '' ?></p>
        <div class="cm-quiet mt-2" id="cm-push">
          <p class="text-sm"><b>Push on this device</b> <span id="cm-push-state" class="text-xs text-[#8A7355]">Checking…</span></p>
          <p class="text-xs text-[#8A7355]">Our own push, free: it says what happened and opens it in your Pulse. Critical ones always come; the rest as you choose below.</p>
          <div class="cm-q-row"><button type="button" class="cm-btn" id="cm-push-on">Turn on push here</button><button type="button" class="cm-btn" id="cm-push-off" hidden>Turn it off here</button><button type="button" class="cm-btn" id="cm-push-test" hidden>Send me a test</button></div>
        </div>
        <div class="cm-quiet mt-2">
          <label class="flex items-center gap-2 text-sm"><input type="checkbox" id="cm-q-on"> <b>Quiet hours</b></label>
          <p class="text-xs text-[#8A7355]">Off unless you set them. While they're on, notices and activity wait and come by email when they end, and push waits for messages too. Anything critical or urgent still comes at once.</p>
          <div id="cm-q-times" class="cm-q-row" hidden>
            <label class="text-sm">From <input type="time" id="cm-q-from" value="22:00"></label>
            <label class="text-sm">to <input type="time" id="cm-q-to" value="07:00"></label>
            <button type="button" class="cm-btn" id="cm-q-save">Save quiet hours</button>
            <span class="text-xs text-[#8A7355]" id="cm-q-tz"></span>
          </div>
        </div>
        <div id="cm-kinds" class="mt-3"><p class="text-sm">Loading…</p></div>
        <label class="flex items-start gap-2 text-sm mt-3" id="cm-digest-row" hidden><input type="checkbox" class="mt-1" id="cm-digest"> <span><b>A weekly email of your notices</b><span class="block text-xs text-[#8A7355]">One email a week listing the notices in your Pulse.</span></span></label>
        <style>
          .cm-quiet{border:1px solid #CBB98D;border-radius:.5rem;padding:.5rem .6rem;background:#FFFBF2}
          .cm-q-row{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .6rem;margin-top:.4rem}.cm-q-row[hidden]{display:none}
          .cm-q-row input[type=time]{border:1px solid #CBB98D;border-radius:.4rem;padding:.2rem .35rem;background:#fff;max-width:7.5rem}
          .cm-btn{border:1px solid #92400E;color:#92400E;border-radius:.45rem;padding:.25rem .6rem;font-size:.85rem;background:#fff}
          .cm-g{font-weight:700;color:#3E2B1F;font-size:.85rem;margin:.7rem 0 .2rem}
          .cm-k{display:grid;grid-template-columns:1fr auto auto auto;gap:.2rem .7rem;align-items:start;padding:.4rem 0;border-top:1px solid #E3D3AC}
          .cm-k b{font-size:.875rem}.cm-k small{display:block;font-size:.75rem;color:#8A7355}
          .cm-k label{display:flex;align-items:center;gap:.25rem;font-size:.8rem;white-space:nowrap}
          .cm-lv{display:inline-block;font-size:.68rem;border:1px solid #CBB98D;border-radius:999px;padding:0 .4rem;margin-left:.3rem;color:#5C4632;font-weight:400}
          @media (max-width:420px){.cm-k{grid-template-columns:repeat(3,auto);justify-content:start}.cm-k>div{grid-column:1/-1}}
        </style>
        <script>
        (function () {   // the Communications setting (decisions/0172 §4.4): each kind × Pulse, email and push, quiet hours, push on this device; it took in Notices
          var box = document.getElementById('cm-kinds'), csrf = null;
          var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
          function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
          function hm(m) { return ('0' + Math.floor(m / 60)).slice(-2) + ':' + ('0' + (m % 60)).slice(-2); }
          function post(body) {
            return fetch('/user/api/comms.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
              .then(function (r) { return r.json(); });
          }
          function box1(k, via, on, fixed) {
            return '<label' + (fixed ? ' title="' + esc(fixed) + '"' : '') + '><input type="checkbox" data-cm="' + esc(k) + '" data-via="' + via + '"' + (on ? ' checked' : '') + (fixed ? ' disabled' : '') + '> ' + (via === 'pulse' ? 'Pulse' : via === 'email' ? 'Email' : 'Push') + '</label>';
          }
          function load() {
            fetch('/user/api/comms.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
              if (!d.ok) { box.innerHTML = '<p data-tv-status="info" data-tv-label="Not yet:">Your Communications setting isn\'t available right now.</p>'; return; }
              csrf = d.csrf; var g = '', h = '';
              d.kinds.forEach(function (k) {
                if (k.group !== g) { g = k.group; h += '<p class="cm-g">' + esc(g) + '</p>'; }
                h += '<div class="cm-k"><div><b>' + esc(k.name) + '</b><span class="cm-lv">' + esc(k.level) + '</span><small>' + esc(k.what) + '</small>'
                  + (k.email_fixed ? '<small>' + esc(k.email_fixed) + '</small>' : '') + '</div>'
                  + box1(k.kind, 'pulse', k.pulse, k.pulse_fixed) + box1(k.kind, 'email', k.email, k.email_fixed) + box1(k.kind, 'push', k.push, k.push_fixed) + '</div>';
              });
              box.innerHTML = h + (d.ready ? '' : '<p class="mt-2" data-tv-status="info" data-tv-label="Not yet:">Email choices and quiet hours switch on once the site\'s update has run.</p>');
              var on = !!d.quiet; document.getElementById('cm-q-on').checked = on; document.getElementById('cm-q-times').hidden = !on;
              if (d.quiet) { document.getElementById('cm-q-from').value = hm(d.quiet.from); document.getElementById('cm-q-to').value = hm(d.quiet.to); }
              document.getElementById('cm-q-tz').textContent = (d.quiet && d.quiet.tz ? d.quiet.tz : tz) ? 'Your time: ' + ((d.quiet && d.quiet.tz) || tz) : '';
              document.getElementById('cm-digest-row').hidden = !d.digest_on; document.getElementById('cm-digest').checked = !!d.digest;
            }).catch(function () { box.textContent = 'Not available right now.'; });
          }
          box.addEventListener('change', function (e) {
            var c = e.target.closest('[data-cm]'); if (!c) return;
            post({ kind: c.getAttribute('data-cm'), via: c.getAttribute('data-via'), on: c.checked })
              .then(function (d) { if (d.ok) TvAsk.say(c.checked ? 'On.' : 'Off.', { anchor: c }); else { c.checked = !c.checked; TvAsk.say(d.error.message, { anchor: c, bad: true }); } })
              .catch(function () { c.checked = !c.checked; TvAsk.say('Couldn\'t save. Try again.', { anchor: c, bad: true }); });
          });
          function saveQuiet(btn, body) {
            if (window.TvAsk && TvAsk.busy) TvAsk.busy(btn, true);
            return post(body).then(function (d) {
              if (window.TvAsk && TvAsk.busy) TvAsk.busy(btn, false);
              if (d.ok) TvAsk.say(body.quiet ? 'Quiet hours saved.' : 'Quiet hours off.', { anchor: btn }); else TvAsk.say(d.error.message, { anchor: btn, bad: true });
              return d.ok;
            }).catch(function () { if (window.TvAsk && TvAsk.busy) TvAsk.busy(btn, false); TvAsk.say('Couldn\'t save. Try again.', { anchor: btn, bad: true }); return false; });
          }
          document.getElementById('cm-q-on').addEventListener('change', function (e) {
            var c = e.target; document.getElementById('cm-q-times').hidden = !c.checked;
            if (!c.checked) saveQuiet(c, { quiet: null }).then(function (ok) { if (!ok) { c.checked = true; document.getElementById('cm-q-times').hidden = false; } });
            else TvAsk.say('Choose the times, then Save.', { anchor: c });
          });
          document.getElementById('cm-q-save').addEventListener('click', function (e) {
            saveQuiet(e.currentTarget, { quiet: { from: document.getElementById('cm-q-from').value, to: document.getElementById('cm-q-to').value, tz: tz } });
          });
          document.getElementById('cm-digest').addEventListener('change', function (e) {
            var c = e.target;
            post({ digest: c.checked }).then(function (d) { if (d.ok) TvAsk.say(c.checked ? 'On.' : 'Off.', { anchor: c }); else { c.checked = !c.checked; TvAsk.say(d.error.message, { anchor: c, bad: true }); } })
              .catch(function () { c.checked = !c.checked; TvAsk.say('Couldn\'t save. Try again.', { anchor: c, bad: true }); });
          });
          // push on this device (js/tv-push.js): asked here, never by the browser until the person says yes
          var ps = document.getElementById('cm-push-state'), pOn = document.getElementById('cm-push-on'), pOff = document.getElementById('cm-push-off'), pT = document.getElementById('cm-push-test');
          function pstate() {
            if (!window.TvPush) return;
            TvPush.state().then(function (s) {
              ps.textContent = s === 'on' ? 'On here.' : s === 'blocked' ? 'Blocked in this browser\'s settings: allow notifications for traversence.com, then Turn on.' : s === 'unsupported' ? 'This browser can\'t take push (on an iPhone, add the site to your Home Screen first).' : 'Off here.';
              pOn.hidden = s === 'on' || s === 'unsupported'; pOff.hidden = pT.hidden = s !== 'on';
            });
          }
          var sc = document.createElement('script'); sc.src = '/js/tv-push.js'; sc.onload = pstate; document.head.appendChild(sc);
          pOn.addEventListener('click', function () { TvPush.turnOn(pOn).then(function () { pstate(); load(); }); });
          pOff.addEventListener('click', function () { TvPush.turnOff(pOff).then(pstate); });
          pT.addEventListener('click', function () { TvPush.test(pT); });
          load();
        })();
        </script>
<?php
    return (string) ob_get_clean();
}
