-- Communications, the rest as one release (decisions/0167, 0172 §6 steps 3-7; Jason, 2026-11-18). Add-only: new
-- tables, and new columns guarded so the file is safe to run twice. Every table is named in app/lib/staging-tables.php.

-- 0167 §1: which kind of email goes from which sender (routing), who oversees which mailbox (§2a), and the setup log
CREATE TABLE IF NOT EXISTS comms_routing (
  mail_kind VARCHAR(30) NOT NULL PRIMARY KEY,
  sender_key VARCHAR(30) NOT NULL,
  changed_by INT NULL,
  changed_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS comms_overseers (
  mailbox VARCHAR(190) NOT NULL,
  user_id INT NOT NULL,
  added_by INT NULL,
  added_at DATETIME NOT NULL,
  PRIMARY KEY (mailbox, user_id),
  KEY by_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS comms_setup_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  what VARCHAR(40) NOT NULL,
  target VARCHAR(190) NOT NULL DEFAULT '',
  detail VARCHAR(255) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL,
  KEY by_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 0172 §4.3 Controlling: a kind, a channel or a sender paused (by an owner, or by itself on complaints)
CREATE TABLE IF NOT EXISTS comms_controls (
  ckey VARCHAR(60) NOT NULL PRIMARY KEY,
  paused TINYINT NOT NULL DEFAULT 0,
  why VARCHAR(255) NOT NULL DEFAULT '',
  by_user INT NULL,
  changed_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 0167 §2: every Bluehost send on the one route (message_id 0 when it wasn't a Notify message); the address kept hashed
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE comms_route ADD COLUMN sender_key VARCHAR(30) NULL, ADD COLUMN addr_hash CHAR(64) NULL, ADD COLUMN subject VARCHAR(200) NULL, ADD COLUMN mail_kind VARCHAR(30) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'comms_route' AND COLUMN_NAME = 'sender_key');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE comms_route ADD INDEX by_via_time (via, happened_at)', 'DO 0')
  FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'comms_route' AND INDEX_NAME = 'by_via_time');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

-- 0172 "Flags and tags in Pulse": a person's own marks on any item (never shown to the sender), and their tags
CREATE TABLE IF NOT EXISTS pulse_flags (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  item VARCHAR(120) NOT NULL,
  flag_state VARCHAR(10) NOT NULL DEFAULT '',
  due_at DATETIME NULL,
  came_back_at DATETIME NULL,
  importance VARCHAR(4) NOT NULL DEFAULT '',
  tags VARCHAR(500) NOT NULL DEFAULT '',
  pinned TINYINT NOT NULL DEFAULT 0,
  folder VARCHAR(60) NOT NULL DEFAULT '',
  archived TINYINT NOT NULL DEFAULT 0,
  unread_again TINYINT NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY one_mark (user_id, item),
  KEY due (flag_state, due_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pulse_tags (
  id INT AUTO_INCREMENT PRIMARY KEY,
  owner_type VARCHAR(10) NOT NULL,
  owner_id INT NOT NULL,
  name VARCHAR(40) NOT NULL,
  colour VARCHAR(7) NOT NULL DEFAULT '#8FBCA8',
  made_by INT NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY one_name (owner_type, owner_id, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 0172 §4.7 and 0167 §2a: mailboxes read in Pulse (ours by IMAP, outside ones by IMAP, POP, Microsoft or SES receiving)
CREATE TABLE IF NOT EXISTS comms_mailboxes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  owner_type VARCHAR(10) NOT NULL,
  owner_id INT NOT NULL DEFAULT 0,
  label VARCHAR(80) NOT NULL DEFAULT '',
  address VARCHAR(190) NOT NULL,
  provider VARCHAR(12) NOT NULL,
  host VARCHAR(190) NOT NULL DEFAULT '',
  port INT NOT NULL DEFAULT 0,
  login VARCHAR(190) NOT NULL DEFAULT '',
  secret TEXT NULL,
  smtp_host VARCHAR(190) NOT NULL DEFAULT '',
  smtp_port INT NOT NULL DEFAULT 0,
  status VARCHAR(10) NOT NULL DEFAULT 'pending',
  approved_by INT NULL,
  approved_at DATETIME NULL,
  last_sync_at DATETIME NULL,
  last_error VARCHAR(255) NOT NULL DEFAULT '',
  sync_mark VARCHAR(255) NOT NULL DEFAULT '',
  made_by INT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY one_box (owner_type, owner_id, address),
  KEY by_status (status, last_sync_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS comms_mail (
  id INT AUTO_INCREMENT PRIMARY KEY,
  mailbox_id INT NOT NULL,
  folder VARCHAR(60) NOT NULL DEFAULT 'INBOX',
  uid VARCHAR(190) NOT NULL,
  msg_id VARCHAR(255) NOT NULL DEFAULT '',
  thread_key CHAR(40) NOT NULL DEFAULT '',
  direction VARCHAR(3) NOT NULL DEFAULT 'in',
  from_addr VARCHAR(190) NOT NULL DEFAULT '',
  from_name VARCHAR(120) NOT NULL DEFAULT '',
  to_list TEXT NULL,
  cc_list TEXT NULL,
  subject VARCHAR(255) NOT NULL DEFAULT '',
  sent_at DATETIME NULL,
  snippet VARCHAR(300) NOT NULL DEFAULT '',
  body_text MEDIUMTEXT NULL,
  body_html MEDIUMTEXT NULL,
  attach TEXT NULL,
  seen TINYINT NOT NULL DEFAULT 0,
  flagged TINYINT NOT NULL DEFAULT 0,
  comms_id INT NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY one_mail (mailbox_id, folder, uid),
  KEY by_box_time (mailbox_id, sent_at),
  KEY by_thread (thread_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 0172 §4.6: the push engine's subscriptions, one per device (our own keys; free)
CREATE TABLE IF NOT EXISTS push_subs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  endpoint VARCHAR(600) NOT NULL,
  endpoint_hash CHAR(64) NOT NULL,
  p256dh VARCHAR(200) NOT NULL,
  auth_key VARCHAR(64) NOT NULL,
  device VARCHAR(120) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL,
  last_ok_at DATETIME NULL,
  failed_at DATETIME NULL,
  fails INT NOT NULL DEFAULT 0,
  UNIQUE KEY one_endpoint (endpoint_hash),
  KEY by_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 0172 §2.3: replies on comments (a comment's parent)
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE content_comments ADD COLUMN parent_id INT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'content_comments' AND COLUMN_NAME = 'parent_id');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE content_comments ADD COLUMN hidden_by INT NULL, ADD COLUMN hidden_at DATETIME NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'content_comments' AND COLUMN_NAME = 'hidden_by');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE content_comments ADD INDEX by_parent (parent_id)', 'DO 0')
  FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'content_comments' AND INDEX_NAME = 'by_parent');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
