<?php
// /user/api/bell.php — the bell's count (decisions/0172 §6 step 2, gap 6): everything unread for this person at Alert or
// above, from where each lives. Signed in.
//   GET -> {ok, requests, contact_asks, unread, message_requests, from_businesses, business_messages, guest_questions, sent_to_you, needs_you}
// Each is a count; the header's bell adds them up (js/header-nav.js). Business messages and guest questions count for
// the listings this person helps run.

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/People.php';
require_once __DIR__ . '/../../../app/lib/BizMessages.php';
require_once __DIR__ . '/../../../app/lib/Notify.php';

header('Cache-Control: no-store');
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$pdo = Database::connection();
$uid = (int) $me['id'];
// a staff login (decisions/0100: no member side): its bell is the admin Pulse's (critical, overdue, escalated to you), and
// it opens there (Jason, 2026-11-19). The count is the one admin Pulse kept as it drew; worked out here when there's none.
require_once __DIR__ . '/../../../app/lib/Roles.php';
if (Roles::staffLogin($pdo, $uid)) {
    $n = null;
    try { require_once __DIR__ . '/../../../app/lib/PageCache.php'; $n = PageCache::get($pdo, 'pulsebell:' . $uid); } catch (Throwable $e) {}
    if ($n === null) {
        try { require_once __DIR__ . '/../../../app/lib/StaffLogin.php'; require_once __DIR__ . '/../../../app/ui/pulse-ui.php';
            $n = tv_pulse_bell_n(Pulse::items($pdo, StaffLogin::inSession($pdo) ?: null, $uid)); PageCache::put($pdo, 'pulsebell:' . $uid, 900, $n);
        } catch (Throwable $e) { error_log('bell staff: ' . $e->getMessage()); $n = 0; }
    }
    Response::json(['ok' => true, 'staff' => (int) $n, 'href' => '/admin/dashboard#bell']);
}
$out = ['requests' => 0, 'contact_asks' => 0, 'unread' => 0, 'message_requests' => 0, 'from_businesses' => 0, 'business_messages' => 0, 'guest_questions' => 0, 'sent_to_you' => 0, 'needs_you' => 0];
$try = function (string $k, callable $f) use (&$out) { try { $out[$k] = (int) $f(); } catch (Throwable $e) { error_log('bell ' . $k . ': ' . $e->getMessage()); } };
if (People::tableExists($pdo)) { try { $out = array_merge($out, array_map('intval', People::waiting($pdo, $uid))); } catch (Throwable $e) { error_log('bell people: ' . $e->getMessage()); } }
if (BizMessages::ready($pdo)) {
    $try('from_businesses', fn () => BizMessages::personUnread($pdo, $uid));
    $try('business_messages', fn () => BizMessages::staffUnread($pdo, $uid));
}
if (is_file(__DIR__ . '/../../../app/lib/GuestInquiries.php')) {
    require_once __DIR__ . '/../../../app/lib/GuestInquiries.php';
    $try('guest_questions', fn () => GuestInquiries::ready($pdo) ? GuestInquiries::staffUnread($pdo, $uid) : 0);
}
$try('sent_to_you', fn () => Notify::unreadForBell($pdo, $uid));
// what needs you that the counts above don't already hold (a notice on the account, a claim's last step, referrals, the
// Marketplace's checks and offers): the member Pulse's "Needs you" rows, on the bell too (decisions/0172)
$try('needs_you', function () use ($pdo, $uid) {
    require_once __DIR__ . '/../../../app/lib/MemberPulse.php';
    $n = 0;
    foreach (MemberPulse::needs($pdo, $uid, ['kind' => 'member', 'scope' => []]) as [$c, $text, $url]) {
        if (str_starts_with((string) $url, '#addressbook') || $url === '#pulse' || $url === '#links') continue;   // counted above, or a tip
        $n += $c ?: 1;
    }
    return $n;
});
Response::json(['ok' => true] + $out);
