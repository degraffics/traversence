// js/tv-pulse.js — the Pulse (decisions/0055 §5): one list of what's coming in (From, Subject, Received), each row opening
// in place (▾), for the context you're acting in (/user/api/pulse.php). One script for every page it shows on: your
// Dashboard, and a business's Overview (/business/<id>; Jason, 2026-11-11: "The dashboard here needs the pulse").
// The page draws the panel (app/ui/pulse-panel.php) and calls TvPulse.load(); a new post (tvm:posted) reloads it.
// The row's icons manage the message (decisions/0172 step 3): read or unread, pin, file (a folder or Archive) and ⊕ (Follow
// up, importance, tags) are the person's own marks (/user/api/marks.php); a dispatcher message opens with its own body
// and buttons (js/pulse-msg.js).
(function () {
  'use strict';
  if (!document.getElementById('pu-list') || window.TvPulse) return;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  // ---- the Pulse (decisions/0055 §5) ----
  var P = { data: null, filter: 'all', tab: null, group: '' };
  function pref(k, d) { try { var v = localStorage.getItem('tv_pulse_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function setPref(k, v) { try { localStorage.setItem('tv_pulse_' + k, JSON.stringify(v)); } catch (e) {} }
  function when(w) { if (!w) return ''; var d = new Date(String(w).replace(' ', 'T')); if (isNaN(d)) return String(w).slice(0, 10); var m = (Date.now() - d) / 60000;
    return m < 60 ? Math.max(1, Math.round(m)) + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : m < 10080 ? Math.round(m / 1440) + ' d ago' : d.toLocaleDateString(); }
  function loadPulse() {
    fetch('/user/api/pulse.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) throw new Error(d.error && d.error.message);
      P.data = d; paintPulse(); openAsked();
    }).catch(function (e) { document.getElementById('pu-needs').innerHTML = '<p class="pu-muted">' + esc(e.message || 'The Pulse isn\'t available right now.') + '</p>'; });
  }
  // the Pulse as in Jason's mockup (draft 2026-10-09). Each row opens to what it really is (decisions/0172): its conversation, words or body, with its own actions.
  var SV = function (d, w) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 1.7) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>'; };
  var IC = {
    reply: SV('<path d="M3 9l9 6 9-6"/><path d="M3 9l9-6 9 6v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>'),
    fwd: SV('<path d="M14 5l7 6-7 6V13c-6 0-9 2-11 6 0-6 3-11 11-11z"/>'),
    pin: SV('<path d="M9 3h6l-1 6 3 3v2H7v-2l3-3z"/><path d="M12 14v7"/>'),
    report: SV('<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>'),
    folder: SV('<path d="M3 6a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M12 10v6M9.5 13.5 12 16l2.5-2.5"/>'),
    add: SV('<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>'),
    down: SV('<path d="M5 8l7 8 7-8z" fill="currentColor"/>'),
    more: SV('<circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/>'),
    link: SV('<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>', 2.4),
    heart: SV('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>', 2),
    eye: SV('<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>', 2.2),
    chat: SV('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>', 2.2),
    open: SV('<path d="M15 3h6v6M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>', 2.2),
    clip: SV('<path d="M21.4 11.1l-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/>'),
    cam: SV('<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>'),
    vid: SV('<rect x="2" y="5" width="15" height="14" rx="2"/><path d="M17 10l5-3v10l-5-3z"/>'),
    cast: SV('<circle cx="12" cy="12" r="2"/><path d="M16.2 7.8a6 6 0 0 1 0 8.4M7.8 16.2a6 6 0 0 1 0-8.4M19.1 4.9a10 10 0 0 1 0 14.2M4.9 19.1a10 10 0 0 1 0-14.2"/>')
  };
  var ORDER = ['needs', 'messages', 'community', 'marketplace', 'listings', 'discovery', 'questions', 'notices'];
  function stamp(w) { if (!w) return ''; var d = new Date(String(w).replace(' ', 'T')); if (isNaN(d)) return String(w).slice(0, 16);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ', ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); }
  function paintPulse() {
    var d = P.data, needs = document.getElementById('pu-needs');
    var nCount = d.needs.reduce(function (a, n) { return a + (n[0] || 1); }, 0), bn = document.getElementById('pu-bell-n');
    bn.hidden = !nCount; bn.textContent = nCount > 99 ? '99+' : nCount;
    // what needs you arrives as rows ("Needs you") and on the bell, not as a fixed block above the list (decisions/0172)
    if (needs) needs.hidden = true;
    document.getElementById('pu-bell').setAttribute('aria-pressed', P.filter === 'needs' ? 'true' : 'false');
    var src = Object.keys(d.sources || {}).sort(function (a, b) { return ORDER.indexOf(a) - ORDER.indexOf(b); });
    var off = pref('off', []), on = src.filter(function (k) { return off.indexOf(k) < 0; }), mode = pref('mode', 'list');
    var items = d.items.filter(function (i) { return on.indexOf(i.source) >= 0; });
    P.items = items;
    // the groups (decisions/0172: a group is a channel, not an inbox; a group you run folds in as its label and filter)
    var groups = items.map(function (i) { return i.group || ''; }).filter(function (g, k, a) { return g && a.indexOf(g) === k; }).sort();
    if (P.group && groups.indexOf(P.group) < 0) P.group = '';
    var count = function (k) { return items.filter(function (i) { return i.source === k; }).length; };
    document.querySelectorAll('input[name="pu-mode"]').forEach(function (r) { r.checked = r.value === mode; });
    document.getElementById('pu-srcs').innerHTML = src.map(function (k) { return '<label><input type="checkbox" data-src="' + k + '"' + (off.indexOf(k) < 0 ? ' checked' : '') + '> ' + esc(d.sources[k]) + '</label>'; }).join('');
    var list = document.getElementById('pu-list'), chips = document.getElementById('pu-chips'), member = d.context && d.context.kind === 'member';
    // the pills: each source with its count; a tap shows only that one, again shows everything. Tabs mode always shows one.
    if (mode === 'tabs' && (P.filter === 'all' || on.indexOf(P.filter) < 0)) P.filter = on[0] || 'all';
    if (P.filter !== 'all' && P.filter !== 'journeys' && on.indexOf(P.filter) < 0) P.filter = 'all';
    chips.innerHTML = on.map(function (k) { return '<button type="button" class="pv-cat' + (P.filter === k ? ' on' : '') + '" data-f="' + k + '" aria-pressed="' + (P.filter === k) + '">' + esc(d.sources[k]) + ' <small>' + count(k) + '</small></button>'; }).join('')
      + (groups.length ? '<button type="button" class="pv-cat pv-grp' + (P.group ? ' on' : '') + '" data-grp title="The groups you belong to and run: show one" aria-haspopup="dialog">' + esc(P.group || 'Groups') + ' <small>' + (P.group ? items.filter(function (i) { return i.group === P.group; }).length : groups.length) + '</small> &#9662;</button>' : '')
      + (member ? '<button type="button" class="pv-cat soon' + (P.filter === 'journeys' ? ' on' : '') + '" data-f="journeys" title="Journeys from people and places you follow: coming">Journeys <small>0</small></button>' : '');
    var empty = { messages: 'No messages yet. Find people in your Address Book.', community: 'Posts from your groups and new connections show here.',
      discovery: 'Link a place (the chain icon on any region or town page) and what\'s new there shows here.', listings: 'Link businesses and places, and their news shows here.',
      marketplace: 'Marketplace posts from sellers you link will show here. Your own posts are in Your Marketplace (#market).', questions: 'Questions from guests who aren\'t signed in show here.',
      notices: 'Comments on your listing and other notices to your business show here.',
      journeys: 'Journeys from the people and places you follow will show here. Coming.' };
    var its = P.filter === 'all' ? items : items.filter(function (i) { return i.source === P.filter; });
    if (P.group) its = its.filter(function (i) { return i.group === P.group; });
    list.className = 'pu-list' + (mode === 'stream' ? '' : ' pl tv-bleed');
    if (!its.length && d.context && d.context.kind === 'admin') { list.innerHTML = '<p class="pu-muted" style="padding:.7rem .4rem">Your Pulse as staff is in the admin: <a class="underline" href="/admin/dashboard" target="_top">open the admin\'s Pulse</a>.</p>'; return; }   // never "Nothing new yet" beside a staff bell (Jason, 2026-11-19)
    if (!its.length) { list.innerHTML = '<p class="pu-muted" style="padding:.7rem .4rem">' + esc(P.filter === 'all' ? 'Nothing new yet. Link places, businesses and people, and join groups: your Pulse is built from them.' : (empty[P.filter] || 'Nothing yet.')) + '</p>'; return; }
    if (mode === 'stream') {
      list.innerHTML = its.map(function (i) { return '<a class="pu-it' + (i.unread ? ' new' : '') + '" href="' + esc(i.url) + '"><span class="pu-src">' + esc(d.sources[i.source] || i.source) + '</span><span><b>' + esc(i.title) + '</b>'
        + '<small>' + esc(i.body) + (i.when ? ' · ' + esc(when(i.when)) : '') + '</small></span></a>'; }).join('');
      return;
    }
    // the six icons manage the message (decisions/0172 "The row's icons"); one that can't act on this row is greyed with the
    // reason in its title, never hidden. On a phone they fold into one ⋯ beside ▾.
    var acts = function (n) {
      var it = items[+n] || {}, fwdWhy = it.fwd || '', pr = it.protect || [], prOk = pr.filter(function (x) { return !x[3]; }), prWhy = prOk.length ? '' : (pr[0] ? pr[0][3] : 'There\'s nothing to protect here.');
      var btn = function (pa, ic, label, why, pressed) {
        return '<button type="button" class="pl-i" data-pa="' + pa + '" data-n="' + n + '" title="' + esc(why ? label + ': ' + why : label) + '" aria-label="' + esc(label) + '"'
          + (why ? ' aria-disabled="true"' : '') + (pressed ? ' aria-pressed="false"' : '') + '>' + ic + '</button>';
      };
      return btn('read', IC.reply, 'Mark read or unread', '') + btn('forward', IC.fwd, 'Pass it on', fwdWhy) + btn('pin', IC.pin, 'Pin in your list', '', true)
        + btn('report', IC.report, 'Protect: ' + (prOk.map(function (x) { return x[1]; }).join(', ') || 'report, block, mute'), prWhy)
        + btn('folder', IC.folder, 'Move to a folder', '') + btn('save', IC.add, 'Add to: Follow up, importance, tags, your Address Book', '');
    };
    list.innerHTML = '<div class="pl-h"><span></span><span>From</span><span></span><span>Subject</span><span>Received</span><span></span></div>'
      + its.map(function (i) {
        // an item that names its sender (what needs you, a message the dispatcher sent): From is the sender, Subject its title
        // then its words; otherwise (a conversation) the title is who it's with and the words are the subject
        var n = items.indexOf(i), named = !!(i.from && i.from !== i.title), from = named ? i.from : (i.title || d.sources[i.source]),
          subj = named ? esc(i.title) + (i.body ? ' <small style="font-weight:400;color:#8A7355;margin-left:.3rem">' + esc(i.body) + '</small>' : '') : esc(i.body);
        return '<div class="pl-r' + (i.unread ? ' new' : '') + '" data-n="' + n + '"><span class="pl-av" aria-hidden="true">' + esc(String(from).charAt(0).toUpperCase()) + '</span>'
          + '<span class="pl-from">' + esc(from) + '<small>' + esc(d.sources[i.source] || i.source) + '</small></span>'
          + '<a class="pl-ln" href="' + esc(i.url) + '" title="Go to where it came from" aria-label="Go to where it came from">' + IC.link + '</a>'
          + '<span class="pl-sub">' + subj + '</span><span class="pl-when" title="' + esc(when(i.when)) + '">' + esc(stamp(i.when)) + '</span>'
          + '<span class="pl-act">' + acts(n) + '<button type="button" class="pl-i pl-more" data-pa="more" title="More actions" aria-label="More actions" aria-expanded="false">' + IC.more + '</button>'
          + '<button type="button" class="pl-i x" data-pl-x title="Open" aria-label="Open" aria-expanded="false">' + IC.down + '</button></span>'
          + '<p class="pl-note" role="status"></p><div class="pl-body" hidden></div></div>';
      }).join('');
    P.acts = acts;
    P.items = items;
    marks(its, items);
  }

  // ---- the person's own marks (decisions/0172 "Flags and tags in Pulse"): pin, folder, archive, Follow up, importance, tags,
  // read or unread, kept per person (/user/api/marks.php), never shown to the sender; the list's order is theirs to choose
  function itemKey(i) {
    if (i.item) return i.item;
    var s = String(i.url) + '|' + String(i.title), h = 0;
    for (var k = 0; k < s.length; k++) { h = ((h << 5) - h + s.charCodeAt(k)) | 0; }
    return String(i.source).replace(/[^a-z]/g, '').slice(0, 10) + ':' + (h >>> 0).toString(36);
  }
  var M = { marks: {}, tags: [], folders: {}, csrf: '', view: pref('view', '') };
  (function () { var st = document.createElement('style');
    st.textContent = '.pl-marks{display:inline-flex;gap:.25rem;margin-left:.35rem;vertical-align:middle}.pl-flag{color:#B91C1C}.pl-flag.done{color:#2F6B55}.pl-imp{font-size:.72rem;font-weight:700;color:#92400E}.pl-imp.low{color:#8A7355}'
      + '.pl-tag{font-size:.72rem;border:1px solid;border-radius:999px;padding:0 .4rem}.pu-views{display:flex;flex-wrap:wrap;gap:.3rem;margin:.3rem 0}.pl-r.lvl-critical{box-shadow:inset 3px 0 0 #B91C1C}.pl-r.lvl-urgent{box-shadow:inset 3px 0 0 #B45309}';
    document.head.appendChild(st); })();
  function mpost(body) {
    return fetch('/user/api/marks.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': M.csrf || window.appCsrfToken || '' },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }).then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t save.'); return j; });
  }
  function marks(its, items) {
    var keys = items.map(itemKey);
    fetch('/user/api/marks.php?items=' + encodeURIComponent(keys.join(',')), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok || !j.ready) return;
      M.marks = j.marks || {}; M.tags = j.tags || []; M.folders = j.folders || {}; M.csrf = j.csrf || M.csrf;
      paintMarks();
    }).catch(function () {});
  }
  function paintMarks() {
    var list = document.getElementById('pu-list'), rows = list.querySelectorAll('.pl-r'), pinned = [];
    var tagName = {}; M.tags.forEach(function (t) { tagName[t.id] = t; });
    rows.forEach(function (r) {
      var i = P.items[+r.getAttribute('data-n')], m = M.marks[itemKey(i)] || {};
      var filed = m.archived || m.folder;
      r.hidden = M.view === '' ? !!filed : M.view === 'pinned' ? !m.pinned : M.view === 'flagged' ? m.flag !== 'open' : M.view === 'archived' ? !m.archived : M.view.indexOf('folder:') === 0 ? m.folder !== M.view.slice(7) : false;
      var pin = r.querySelector('[data-pa=pin]'); if (pin) pin.setAttribute('aria-pressed', m.pinned ? 'true' : 'false');
      if (m.back) r.classList.add('new');
      var badge = r.querySelector('.pl-marks'); if (!badge) { badge = document.createElement('span'); badge.className = 'pl-marks'; r.querySelector('.pl-sub').appendChild(badge); }
      badge.innerHTML = (m.flag === 'open' ? '<span class="pl-flag" title="Follow up' + (m.due ? ': ' + esc(m.due) : '') + '">&#9873;</span>' : m.flag === 'done' ? '<span class="pl-flag done" title="Follow-up done">&#10003;</span>' : '')
        + (m.importance ? '<span class="pl-imp ' + esc(m.importance) + '">' + (m.importance === 'high' ? 'High' : 'Low') + '</span>' : '')
        + (m.tags || []).map(function (t) { var x = tagName[t]; return x ? '<span class="pl-tag" style="border-color:' + esc(x.colour) + ';color:' + esc(x.colour) + '">' + esc(x.name) + '</span>' : ''; }).join('');
      if (i.level && (i.level === 'critical' || i.level === 'urgent')) r.classList.add('lvl-' + i.level);
      if (m.pinned) pinned.push(r);
    });
    var head = list.querySelector('.pl-h');
    pinned.reverse().forEach(function (r) { head.insertAdjacentElement('afterend', r); });   // pinned by the person: theirs, at the top of their own list
    var v = document.getElementById('pu-views');
    if (!v) { v = document.createElement('div'); v.id = 'pu-views'; v.className = 'pu-views'; list.parentNode.insertBefore(v, list); }
    var opts = [['', 'Inbox'], ['pinned', 'Pinned'], ['flagged', 'Follow up'], ['archived', 'Archived']].concat(Object.keys(M.folders).map(function (f) { return ['folder:' + f, f]; }));
    v.innerHTML = opts.map(function (o) { return '<button type="button" class="pv-cat' + (M.view === o[0] ? ' on' : '') + '" data-view="' + esc(o[0]) + '" aria-pressed="' + (M.view === o[0]) + '">' + esc(o[1]) + '</button>'; }).join('');
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#pu-views [data-view]'); if (!b) return;
    M.view = b.getAttribute('data-view'); setPref('view', M.view); paintMarks();
  });
  function mark(r, a, set, said) {
    var i = P.items[+r.getAttribute('data-n')], key = itemKey(i);
    if (window.TvAsk) TvAsk.busy(a, true);
    return mpost({ item: key, set: set }).then(function (j) {
      if (window.TvAsk) { TvAsk.busy(a, false); TvAsk.say(said || j.message, { anchor: a, bad: false }); }
      M.marks[key] = j.marks; paintMarks();
    }).catch(function (x) { if (window.TvAsk) { TvAsk.busy(a, false); TvAsk.say(x.message, { anchor: a, bad: true }); } });
  }
  function addTo(r, a) {
    var i = P.items[+r.getAttribute('data-n')], m = M.marks[itemKey(i)] || {};
    var ch = [['today', 'Follow up today', ''], ['tomorrow', 'Follow up tomorrow', ''], ['week', 'Follow up this week', ''], ['nextweek', 'Follow up next week', ''], ['date', 'Follow up on a date', '']];
    if (m.flag === 'open') ch.push(['done', 'Mark the follow-up complete', ''], ['clear', 'Clear the flag', '']);
    ch.push(['high', 'High importance', 'Only for you: sort and find by it.'], ['low', 'Low importance', ''], ['noimp', 'No importance', ''], ['tags', 'Tags…', 'Your own words with a colour; a team\'s shared tags too.']);
    // what else this row can go to (decisions/0172's ⊕): the sender to your Address Book; a post Kept, or to a journey
    var rk = (i.ref || {}).kind, person = i.post && i.post.owner && !i.post.owner.business;
    var off = {};
    ch.push(['abook', 'Your Address Book', rk === 'people' || person ? 'The person, as a connection.' : rk === 'biz' ? 'The business, linked: its news comes here.' : '']);
    if (!(rk === 'people' || rk === 'biz' || person)) off.abook = rk === 'team' || rk === 'guest' ? 'A customer\'s details stay with your business\'s messages.' : 'There\'s no one person or business here to add.';
    if (i.post) { ch.push(['keep', 'Keep it', 'It stays, and its photos go to your Gallery.']); ch.push(['journey', 'A journey', '']); off.journey = 'Coming with Journeys (its own build).'; }
    var pr = TvAsk.choose('Add to', ch, '', { yes: 'Choose' });
    Object.keys(off).forEach(function (k) { var inp = document.querySelector('.tv-ask input[value="' + k + '"]'); if (inp) { inp.disabled = true; var lb = inp.closest('label'); lb.style.opacity = '.55'; lb.title = off[k]; var sm = lb.querySelector('small') || lb.querySelector('span').appendChild(document.createElement('small')); sm.textContent = 'Not here: ' + off[k]; } });   // greyed with the reason
    pr.then(function (v) {
      if (!v) return;
      if (v === 'abook') return busySay(a, act({ do: 'addressbook', item: itemOf(i) }));
      if (v === 'keep') return busySay(a, act({ do: 'keep', item: itemOf(i) }));
      var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (x) {}
      if (['today', 'tomorrow', 'week', 'nextweek'].indexOf(v) >= 0) return mark(r, a, { follow: v, tz: tz });
      if (v === 'date') return TvAsk.ask('Follow up on (YYYY-MM-DD)', '').then(function (d) { if (d) mark(r, a, { follow: 'date', date: String(d).trim(), tz: tz }); });
      if (v === 'done' || v === 'clear') return mark(r, a, { flag: v });
      if (v === 'high' || v === 'low' || v === 'noimp') return mark(r, a, { importance: v === 'noimp' ? '' : v });
      if (v === 'tags') {
        var tc = M.tags.map(function (t) { return [String(t.id), t.name, t.shared ? 'Shared with your team' : '']; }).concat([['new', 'A new tag…', '']]);
        return TvAsk.choose('Tags', tc, (m.tags || []).join(','), { multi: true }).then(function (picked) {
          if (picked === null) return;
          var ids = picked.split(',').filter(function (x) { return x && x !== 'new'; });
          if (picked.split(',').indexOf('new') < 0) return mark(r, a, { tags: ids });
          return TvAsk.ask('New tag', '').then(function (name) {
            if (!name) return;
            return mpost({ tag: { name: name } }).then(function (j) { M.tags.push(j.tag); ids.push(String(j.tag.id)); return mark(r, a, { tags: ids }); });
          });
        });
      }
    });
  }
  // ---- a row's own actions (/user/api/pulse-act.php, decisions/0172): conversations, ↗ Pass it on, 🛡 Protect, ⊕ ----
  function act(body) {
    return fetch('/user/api/pulse-act.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': (P.data && P.data.csrf) || M.csrf || window.appCsrfToken || '' },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }).then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work.'); return j; });
  }
  function itemOf(i) { return { ref: i.ref || {}, comms: i.comms || 0, post: i.post ? { id: i.post.id, url: i.post.url, owner: i.post.owner } : null, title: i.title, body: i.body, url: i.url }; }
  function busySay(a, p, okSay) {   // the spinner on what was pressed, then the answer beside it (or in the middle when there's no room)
    if (window.TvAsk) TvAsk.busy(a, true);
    return p.then(function (j) { if (window.TvAsk) { TvAsk.busy(a, false); TvAsk.say(okSay || j.message || 'Done.', { anchor: a, bad: false }); } return j; })
      .catch(function (x) { if (window.TvAsk) { TvAsk.busy(a, false); TvAsk.say(x.message, { anchor: a, bad: true }); } });
  }
  function convoPaint(box, i, t) {
    var who = function (m) { return m.mine ? 'You' : (m.from || t.with); };
    box.innerHTML = (t.note ? '<p data-tv-status="info" data-tv-label="Left:">' + esc(t.note) + '</p>' : '') + (t.contact ? '<p class="pu-muted">' + esc(t.contact) + '</p>' : '')
      + '<div class="pl-msgs">' + (t.messages.length ? t.messages.map(function (m) {
        return '<div class="pl-m' + (m.mine ? ' me' : '') + '"><small>' + esc(who(m)) + ' · <time datetime="' + esc(String(m.at).replace(' ', 'T')) + '" data-tv-time>' + esc(stamp(m.at)) + '</time></small><p>' + esc(m.body) + '</p></div>';
      }).join('') : '<p class="pu-muted">No messages yet.</p>') + '</div>'
      + (t.can_reply ? '<form class="pl-reply"><textarea name="body" data-spell rows="2" maxlength="4000" required placeholder="Reply to ' + esc(t.with) + '" aria-label="Reply"></textarea>'
          + (t.types && t.types.length ? '<label class="pu-muted">What kind of message <select name="type">' + t.types.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === 'inquiry' ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join('') + '</select></label>' : '')
          + '<button type="submit" class="pl-send">Send</button></form>'
        : '<p data-tv-status="info" data-tv-label="Can\'t reply:">' + esc(t.why || 'You can\'t write here.') + '</p>');
    var ms = box.querySelector('.pl-msgs'); if (ms) ms.scrollTop = ms.scrollHeight;
    if (window.TvTime) TvTime.paint(box);
  }
  function convo(r, i) {
    var box = r.querySelector('.pl-conv');
    fetch('/user/api/pulse-act.php?ref=' + encodeURIComponent(JSON.stringify(i.ref)), { credentials: 'include' }).then(function (x) { return x.json(); }).then(function (j) {
      if (!j.ok) throw new Error((j.error && j.error.message) || 'That conversation didn\'t open.');
      if (j.csrf && P.data) P.data.csrf = j.csrf;
      convoPaint(box, i, j.thread); r.classList.remove('new');
    }).catch(function (e) { box.innerHTML = '<p data-tv-status="bad" data-tv-label="Error:">' + esc(e.message) + ' Try again; still stuck? Write to support@traversence.com.</p>'; });
  }
  document.addEventListener('submit', function (e) {
    var f = e.target.closest && e.target.closest('#pu-list .pl-reply'); if (!f) return;
    e.preventDefault();
    var r = f.closest('.pl-r'), i = P.items[+r.getAttribute('data-n')], btn = f.querySelector('.pl-send'), txt = f.elements.body.value.trim();
    if (!txt) { TvAsk.say('Write something first.', { anchor: btn, bad: true }); return; }
    if (window.TvAsk) TvAsk.busy(btn, true);
    act({ do: 'reply', ref: i.ref, body: txt, type: f.elements.type ? f.elements.type.value : '' }).then(function (j) {
      if (window.TvAsk) TvAsk.busy(btn, false);
      var box = r.querySelector('.pl-conv'); if (j.thread) convoPaint(box, i, j.thread);
      TvAsk.say(j.message || 'Sent.', { anchor: box.querySelector('.pl-send') || box, bad: false });   // beside the new Send, after the conversation redraws
    }).catch(function (x) { if (window.TvAsk) { TvAsk.busy(btn, false); TvAsk.say(x.message, { anchor: btn, bad: true }); } });
  });
  function forwardFlow(r, a, i) {
    fetch('/user/api/pulse-act.php?forward_to=1', { credentials: 'include' }).then(function (x) { return x.json(); }).then(function (t) {
      if (!t.ok) throw new Error((t.error && t.error.message) || 'That didn\'t open.');
      var ch = (t.team || []).map(function (p) { return ['team:' + p[0], p[1], p[2]]; }).concat((t.people || []).map(function (p) { return ['person:' + p[0], p[1], p[2]]; }));
      ch.push(['email', 'An email address…', t.left > 0 ? 'Sent from Traversence with a line saying you forwarded it (' + t.left + ' left today).' : 'No more email forwards today: try tomorrow.']);
      return TvAsk.choose('Pass it on to', ch, '', { yes: 'Next', note: 'Who it\'s from and what it says go with it.' }).then(function (v) {
        if (!v) return;
        var send = function (to, toUser, toEmail) {
          return TvAsk.ask('A note with it (optional)', '').then(function (note) {
            if (note === null) return;
            return busySay(a, act({ do: 'forward', item: itemOf(i), to: to, to_user: toUser, to_email: toEmail, note: note || '' }));
          });
        };
        if (v === 'email') return TvAsk.ask('Their email address', '').then(function (em) { if (em) return send('email', 0, String(em).trim()); });
        var p = v.split(':'); return send(p[0], +p[1], '');
      });
    }).catch(function (x) { TvAsk.say(x.message, { anchor: a, bad: true }); });
  }
  function protectFlow(r, a, i) {
    var pr = (i.protect || []).filter(function (x) { return !x[3]; });
    if (!pr.length) { TvAsk.say((i.protect && i.protect[0] && i.protect[0][3]) || 'There\'s nothing to protect here.', { anchor: a, bad: true }); return; }
    var all = (i.protect || []).map(function (x) { return [x[0], x[1], x[3] ? 'Not here: ' + x[3] : x[2]]; });
    var p = TvAsk.choose('Protect', all, '', { yes: 'Go on', note: 'They\'re never told.' });
    (i.protect || []).forEach(function (x) { if (x[3]) { var inp = document.querySelector('.tv-ask input[value="' + x[0] + '"]'); if (inp) { inp.disabled = true; inp.closest('label').style.opacity = '.55'; inp.closest('label').title = x[3]; } } });   // greyed with the reason
    p.then(function (v) {
      if (!v) return;
      if (v === 'report' && i.post && window.TvMoments) { var pb = r.querySelector('.pl-body'); if (pb.hidden) pb = plOpen(r); var t2 = pb.querySelector('[data-more]'); if (t2) t2.click(); return; }   // a post: its own Report
      if (v === 'report') {
        var reasons = (i.ref && i.ref.kind === 'biz') ? [['spam', 'Spam or scam', ''], ['harassment', 'Harassment or hate', ''], ['mislabelled', 'Sales sent as another type', ''], ['other', 'Something else', '']]
          : [['spam', 'Spam or scam', ''], ['harassment', 'Harassment or hate', ''], ['private_info', 'Someone\'s private information', ''], ['unsafe', 'Breaks the law or puts someone in danger', ''], ['other', 'Something else', '']];
        return TvAsk.choose('Why are you reporting it?', reasons, '', { yes: 'Next' }).then(function (why) {
          if (!why) return;
          return TvAsk.ask('Anything our team should know (optional)', '').then(function (note) { if (note === null) return; return busySay(a, act({ do: 'report', item: itemOf(i), reason: why, note: note || '' })); });
        });
      }
      if (v === 'block') return TvAsk.confirm('Block them? They can\'t message you, and they aren\'t told.', { anchor: a, yes: 'Block', danger: true }).then(function (ok) { if (ok) return busySay(a, act({ do: 'block', item: itemOf(i) })); });
      if (v === 'mute') return busySay(a, act({ do: 'mute', item: itemOf(i), on: true })).then(function (j) { if (j && i.ref && i.ref.group) { r.hidden = true; } });
    });
  }
  function plOpen(r) {
    var i = P.items[+r.getAttribute('data-n')], body = r.querySelector('.pl-body'), me = document.getElementById('pu-list').getAttribute('data-me') || 'you';
    if (!body.innerHTML && i.comms) {   // a message carries its own process (decisions/0172): its body, read live, with its buttons
      body.innerHTML = '<div class="pl-act2">' + P.acts(r.getAttribute('data-n')) + '</div><div class="pl-msgbox"></div>';
      var go = function () { window.TvPulseMsg.open(i.comms, body.querySelector('.pl-msgbox')).then(function () { r.classList.remove('new'); }); };
      if (window.TvPulseMsg) go(); else { var sc = document.createElement('script'); sc.src = '/js/pulse-msg.js'; sc.onload = go; document.head.appendChild(sc); }
    }
    if (!body.innerHTML && i.post && window.TvMoments) {   // a post (decisions/0153): the real one, in place: photos or video, reactions, comments
      body.innerHTML = '<div class="pl-act2">' + P.acts(r.getAttribute('data-n')) + '</div><div class="pl-post"></div><p class="pl-msg" role="status"></p>';
      TvMoments.show(body.querySelector('.pl-post'), i.post);
    }
    if (!body.innerHTML) {   // everything else opens as what it is (decisions/0172 "The message"): no placeholders
      var ref = i.ref || {}, top = '<div class="pl-act2">' + P.acts(r.getAttribute('data-n')) + '</div>';
      if (['people', 'biz', 'team', 'guest'].indexOf(ref.kind) >= 0) {   // a conversation: its messages and a Reply that sends
        body.innerHTML = top + '<div class="pl-conv" aria-live="polite"><p class="pu-muted">Opening…</p></div>';
        convo(r, i);
      } else {
        var ph = i.photos || [], h = top + '<div class="pl-x' + (ph.length ? ' media' : '') + '">';
        if (ph.length) {
          h += '<div class="pl-media"><div class="pl-main" style="background-image:url(\'' + esc(ph[0]) + '\')"></div>'
            + '<div class="pl-thumbs">' + ph.slice(1, 9).map(function (u, k) { return '<button type="button" data-ph-n="' + (k + 1) + '" style="background-image:url(\'' + esc(u) + '\')" aria-label="Photo ' + (k + 2) + '"></button>'; }).join('') + '</div>'
            + '<a class="pl-open" href="' + esc(i.url) + '" title="Open it" aria-label="Open it">' + IC.open + '</a></div>';
        }
        h += '<div class="pl-text">';
        if (ref.kind === 'left') {   // a message left on a listing no one has claimed: where it stands
          h += '<p><b>' + esc(i.title) + '</b></p><p data-tv-status="info" data-tv-label="' + esc(ref.state || 'Where it stands') + ':">' + esc(ref.note || '') + '</p>'
            + '<p><a class="tv-btn-link" href="' + esc(i.url) + '">Open it on the listing</a></p>';
        } else if (ref.kind === 'needs') {   // what needs you: the site's own count, and where to act on it
          h += '<p>' + esc(i.title) + (i.body ? '. ' + esc(i.body) : '') + '</p><p><a class="tv-btn-link" href="' + esc(i.url) + '">Go to it</a></p>';
        } else {
          h += '<p>' + (i.title && i.from && i.from !== i.title ? '<b>' + esc(i.title) + '</b><br>' : '') + esc(i.body) + '</p>'
            + (i.url && i.url !== '#' ? '<p><a href="' + esc(i.url) + '">See more</a></p>' : '');
        }
        h += '<p class="pl-msg" role="status"></p></div></div>';
        body.innerHTML = h;
      }
    }
    var open = body.hidden; body.hidden = !open; r.classList.toggle('open', open);
    var x = r.querySelector('[data-pl-x]'); x.setAttribute('aria-expanded', String(open)); x.title = open ? 'Close' : 'Open';
    return body;
  }
  var q = document.getElementById('pu-q');
  if (q) q.addEventListener('input', function () {
    var t = q.value.trim().toLowerCase();
    document.querySelectorAll('#pu-list .pl-r, #pu-list .pu-it').forEach(function (r) { r.hidden = t !== '' && r.textContent.toLowerCase().indexOf(t) < 0; });
  });
  document.getElementById('pu-chips').addEventListener('click', function (e) {
    var gb = e.target.closest('[data-grp]');
    if (gb) {
      var gs = P.data.items.map(function (i) { return i.group || ''; }).filter(function (g, k, a) { return g && a.indexOf(g) === k; }).sort();
      TvAsk.choose('Show a group', [['', 'Every group', '']].concat(gs.map(function (g) { return [g, g, '']; })), P.group, { yes: 'Show' }).then(function (v) { if (v === null) return; P.group = v; paintPulse(); });
      return;
    }
    var b = e.target.closest('[data-f]'); if (!b) return;
    var f = b.getAttribute('data-f');
    P.filter = P.filter === f && pref('mode', 'list') !== 'tabs' ? 'all' : f; paintPulse();
  });
  document.getElementById('pu-bell').addEventListener('click', function () {   // the bell shows what needs you: its rows
    if (!P.data) return;
    P.filter = P.filter === 'needs' ? 'all' : 'needs'; paintPulse();
  });
  var pvn = document.getElementById('pv-name');
  if (pvn) pvn.addEventListener('click', function (e) { e.stopPropagation(); if (window.tvCx) window.tvCx(pvn); });
  document.getElementById('pu-list').addEventListener('click', function (e) {
    var r = e.target.closest('.pl-r'); if (!r) return;
    if (e.target.closest('[data-pl-x]')) { plOpen(r); return; }
    var t = e.target.closest('[data-ph-n]');
    if (t) { var ph = P.items[+r.getAttribute('data-n')].photos, k = +t.getAttribute('data-ph-n'), main = r.querySelector('.pl-main'), cur = main.getAttribute('data-k') || 0;
      main.style.backgroundImage = 'url("' + ph[k] + '")'; t.style.backgroundImage = 'url("' + ph[cur] + '")'; t.setAttribute('data-ph-n', cur); main.setAttribute('data-k', k); return; }
    var a = e.target.closest('[data-pa]'); if (!a) return;
    var act = a.getAttribute('data-pa');
    if (act === 'more') { var pa2 = a.parentNode, on2 = !pa2.classList.contains('more'); pa2.classList.toggle('more', on2); a.setAttribute('aria-expanded', String(on2)); return; }   // on a phone: the six fold into ⋯
    var ip = P.items[+r.getAttribute('data-n')];
    if (a.getAttribute('aria-disabled') === 'true') { TvAsk.say(a.title.replace(/^[^:]*: /, ''), { anchor: a, bad: true }); return; }   // greyed: says why
    if (act === 'forward') { forwardFlow(r, a, ip); return; }
    if (act === 'report') { protectFlow(r, a, ip); return; }
    if (ip && ip.post && window.TvMoments && act === 'reply') {   // a post: reply is a comment on it
      var pb = r.querySelector('.pl-body'); if (pb.hidden) pb = plOpen(r);
      var t = pb.querySelector(act === 'reply' ? '.tmo-acts [data-com]' : '[data-more]'); if (t) t.click(); return;
    }
    if (act === 'reply') { var b = r.querySelector('.pl-body'); if (b.hidden) b = plOpen(r); var ta = b.querySelector('textarea'); if (ta) ta.focus(); return; }
    var mk = M.marks[itemKey(ip)] || {};
    if (act === 'read') { var un = !r.classList.contains('new'); r.classList.toggle('new', un); mark(r, a, { unread: un }, un ? 'Marked unread.' : 'Marked read.'); return; }
    if (act === 'pin') { mark(r, a, { pinned: !mk.pinned }); return; }
    if (act === 'folder') {
      var fch = [['__archive', 'Archive', 'Out of the list; Archived shows it.']].concat(Object.keys(M.folders).map(function (f) { return [f, f, '']; })).concat([['__new', 'A new folder…', ''], ['__back', 'Back in the list', '']]);
      TvAsk.choose('File it', fch, mk.archived ? '__archive' : (mk.folder || ''), { yes: 'File it' }).then(function (v) {
        if (!v) return;
        if (v === '__archive') return mark(r, a, { archived: true });
        if (v === '__back') return mark(r, a, { folder: '' });
        if (v === '__new') return TvAsk.ask('New folder', '').then(function (n) { if (n) { M.folders[n] = 0; mark(r, a, { folder: n }); } });
        mark(r, a, { folder: v });
      });
      return;
    }
    if (act === 'save') { addTo(r, a); return; }
  });
  (function () {   // on a phone the settings panel sits under the gear, within the screen's edges
    var d = document.querySelector('.pu-set'); if (!d) return;
    function place() { if (!d.open) return; var p = d.querySelector('.pu-setp'); if (innerWidth >= 768) { p.style.top = ''; return; } p.style.top = Math.round(d.querySelector('summary').getBoundingClientRect().bottom + 6) + 'px'; }
    d.addEventListener('toggle', place); addEventListener('resize', place); addEventListener('scroll', function () { if (d.open && innerWidth < 768) d.open = false; }, { passive: true });
  })();
  document.querySelector('.pu-setp').addEventListener('change', function (e) {
    var t = e.target;
    if (t.name === 'pu-mode') setPref('mode', t.value);
    if (t.hasAttribute('data-src')) { var off = pref('off', []), k = t.getAttribute('data-src'); off = off.filter(function (x) { return x !== k; }); if (!t.checked) off.push(k); setPref('off', off); }
    paintPulse();
  });
  document.addEventListener('tvm:posted', function () { var l = document.getElementById('pu-list'); if (l && l.offsetParent !== null) loadPulse(); });   // a new post shows in the Pulse
  function openComms(id) {
    id = +id; if (!id || !P.items) return false;
    var n = -1; P.items.forEach(function (i, k) { if (+i.comms === id) n = k; });
    if (n < 0) return false;
    if (P.filter !== 'all' || P.group || M.view !== '') { P.filter = 'all'; P.group = ''; M.view = ''; paintPulse(); }
    var r = document.querySelector('#pu-list .pl-r[data-n="' + n + '"]'); if (!r) return false;
    r.hidden = false;
    if (r.querySelector('.pl-body').hidden) plOpen(r);
    r.scrollIntoView({ block: 'center', behavior: 'smooth' });
    return true;
  }
  function openAsked() {   // arrived from the bell on another page: ?pulse_msg=ID opens that message's row
    var m = /[?&]pulse_msg=(\d+)/.exec(location.search); if (!m || P.asked) return;
    P.asked = true;
    if (openComms(m[1])) return;
    // not in this Pulse (another account's, or filed): it opens on its own above the list
    var box = document.createElement('div'); box.className = 'pl-alone tv-bleed';
    var list = document.getElementById('pu-list'); list.parentNode.insertBefore(box, list);
    var go = function () { window.TvPulseMsg.open(m[1], box); };
    if (window.TvPulseMsg) go(); else { var sc = document.createElement('script'); sc.src = '/js/pulse-msg.js'; sc.onload = go; document.head.appendChild(sc); }
  }
  window.TvPulse = { load: loadPulse, openComms: openComms };
})();
