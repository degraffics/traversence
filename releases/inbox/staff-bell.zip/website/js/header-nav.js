// js/header-nav.js
//
// Behavior for includes/header.php and includes/brand.php (decisions/0055 §2). js/location-scope.js sets
// window.appHasLocation / window.appAuthActive / window.appIsAdmin and calls window.updateHeaderIconStates()
// whenever they change. No animated transitions anywhere: everything opens and closes instantly.

function updateHeaderIconStates() {
  var dot = document.getElementById('menu-location-dot');
  if (dot) dot.classList.toggle('hidden', !window.appHasLocation);
  var menuBtn = document.getElementById('icon-menu-btn');
  if (menuBtn) menuBtn.classList.toggle('tv-glow', !!window.appHasLocation);
  var loc = document.getElementById('menu-location-label'), ploc = document.getElementById('tvpm-loc');
  if (loc && ploc) ploc.textContent = loc.textContent || 'not set';

  // Role-aware items: data-auth="out" | "in" | "admin". Presentation only; the server enforces access.
  var authed = !!window.appAuthActive;
  var isAdmin = authed && !!window.appIsAdmin;
  document.querySelectorAll('[data-auth]').forEach(function (el) {
    var kind = el.getAttribute('data-auth');
    el.classList.toggle('hidden', !(kind === 'out' ? !authed : (kind === 'in' ? authed : isAdmin)));
  });
  var profileBtn = document.getElementById('icon-profile-btn');
  if (profileBtn) profileBtn.classList.toggle('in', authed);   // teal when signed in
  if (authed) loadBell();
}
window.updateHeaderIconStates = updateHeaderIconStates;

// The bell: everything waiting for you at Alert or above, once signed in (decisions/0172): messages, requests, messages
// from businesses, and for a business you help run its customers' messages and guest questions, and what the one
// dispatcher sent you (/user/api/bell.php sums them).
var bellLoaded = false;
function loadBell() {
  if (bellLoaded) return; bellLoaded = true;
  fetch('/user/api/bell.php', { credentials: 'include', headers: { Accept: 'application/json' } })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (d) {
      if (!d) return;
      var bl = document.getElementById('tv-bell'); if (bl && d.href) { bl.href = d.href; bl.title = 'Your Pulse: critical, overdue and escalated to you'; }   // a staff login's bell opens the admin's Pulse (Jason, 2026-11-19)
      var n = 0;
      Object.keys(d).forEach(function (k) { if (k !== 'ok' && typeof d[k] === 'number') n += d[k]; });
      var b = document.getElementById('tv-bell-n');
      if (b && n > 0) { b.textContent = n > 99 ? '99+' : String(n); b.hidden = false; }
      // the bell's colour (the highest level waiting) and its list, each item opening in place (decisions/0172 step 3)
      if (n > 0 && !d.href && !window.TvPulseMsg && !document.getElementById('tv-pulse-msg-js')) { var s = document.createElement('script'); s.id = 'tv-pulse-msg-js'; s.src = '/js/pulse-msg.js'; s.defer = true; document.head.appendChild(s); }
    }).catch(function () {});
}

function handleProfileIconClick() {
  window.location.href = window.appAuthActive ? '/user/dashboard.php' : '/login.php';
}
window.handleProfileIconClick = handleProfileIconClick;

// Sign out: same endpoint and CSRF header as the portal pages; back to the home page either way.
// Signing out (Jason, 2026-11-05: a sign-out that quietly failed left him signed in). The page's token may not have
// arrived yet, or be missing on a page: then a fresh one is asked for and it tries again. It goes home only once the
// server says you're signed out; otherwise it says so, beside the button.
function siteLogout(tok, btn) {
  var post = function (t) {
    return fetch('/api/auth/logout.php', { method: 'POST', credentials: 'include', headers: { 'X-CSRF-Token': t || '', 'Content-Type': 'application/json' } })
      .then(function (r) { if (!r.ok) throw new Error('refused'); return r; });
  };
  var t = tok || window.appCsrfToken || '';
  (t ? post(t) : Promise.reject(new Error('no token')))
    .catch(function () {
      return fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); })
        .then(function (j) { if (j && j.authenticated === false) return true; return post((j && j.csrf_token) || ''); });   // already out: nothing to do
    })
    .then(function () {
      try { sessionStorage.removeItem('traversence_location'); localStorage.removeItem('traversence_location'); } catch (e) {}
      window.location.href = '/';
    })
    .catch(function () {
      if (window.TvAsk) { if (btn) TvAsk.busy(btn, false); TvAsk.say('We couldn\u2019t sign you out. Check your connection and try again.', { anchor: btn || null, bad: true }); }
    });
}
window.siteLogout = siteLogout;

// The menu: a dropdown on wider screens, the full-screen menu on phones.
function isPhone() { return window.matchMedia && matchMedia('(max-width: 767px)').matches; }
function toggleSiteMenu(forceClose) {
  var btn = document.getElementById('icon-menu-btn');
  var panel = document.getElementById('site-menu-panel');
  var pm = document.getElementById('tv-phone-menu');
  if (!btn) return;
  if (forceClose) {
    if (panel) panel.classList.add('hidden');
    if (pm) { pm.hidden = true; document.documentElement.style.overflow = ''; }
    btn.setAttribute('aria-expanded', 'false');
    return;
  }
  if (isPhone() && pm) {
    var open = pm.hidden;
    // over everything: out of the header's layer, so the tool bar can't sit on top of it
    if (open && pm.parentNode !== document.body) document.body.appendChild(pm);
    pm.hidden = !open;
    document.documentElement.style.overflow = open ? 'hidden' : '';
    btn.setAttribute('aria-expanded', String(open));
    if (open) { var x = pm.querySelector('[data-tvpm-close]'); if (x) x.focus(); }
    return;
  }
  if (!panel) return;
  var nowOpen = panel.classList.contains('hidden');
  panel.classList.toggle('hidden', !nowOpen);
  btn.setAttribute('aria-expanded', String(nowOpen));
}
window.toggleSiteMenu = toggleSiteMenu;

document.addEventListener('click', function (e) {
  if (e.target.closest && e.target.closest('[data-tvpm-close]')) { toggleSiteMenu(true); return; }
  var t = e.target.closest && e.target.closest('[data-tv-toggle]');
  if (t) {
    // Collapse / expand the logo or the funnel icons; remembered in this browser.
    var which = t.getAttribute('data-tv-toggle'), cls = which === 'brand' ? 'tv-brand-min' : 'tv-nav-min';
    var min = document.documentElement.classList.toggle(cls);
    try { var s = JSON.parse(localStorage.getItem('tv_header') || '{}'); s[which] = min ? 'min' : 'full'; localStorage.setItem('tv_header', JSON.stringify(s)); } catch (x) {}
    if (typeof window.syncTopBarSpacer === 'function') window.syncTopBarSpacer();
    return;
  }
  var menuBtn = document.getElementById('icon-menu-btn');
  var panel = document.getElementById('site-menu-panel');
  if (!menuBtn || !panel) return;
  if (!menuBtn.contains(e.target) && !panel.contains(e.target) && panel.classList.contains('hidden') === false) toggleSiteMenu(true);
});

document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') toggleSiteMenu(true);
});

// Phones (Jason, 2026-10-09): the compass opens the site menu; the corner with you (your photo, or ☰ signed out) opens the
// page's tools (app-shell.php sets window.tvTools). Pages without tools keep the site menu there. Wider screens: unchanged.
(function () {
  function phone() { return window.matchMedia('(max-width: 767px)').matches; }
  document.addEventListener('click', function (e) {
    if (!phone()) return;
    if (e.target.closest && e.target.closest('#brand-link')) { e.preventDefault(); e.stopPropagation(); toggleSiteMenu(); return; }
  }, true);
  function hook() {
    var btn = document.getElementById('icon-menu-btn'); if (!btn || btn.dataset.tvHooked) return;
    btn.dataset.tvHooked = '1';
    var site = btn.onclick; btn.onclick = null;
    btn.addEventListener('click', function (e) {
      if (phone() && typeof window.tvTools === 'function') { e.stopPropagation(); window.tvTools(); return; }
      if (site) site.call(btn, e); else toggleSiteMenu();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hook); else hook();
})();

document.addEventListener('DOMContentLoaded', function () {
  document.documentElement.classList.remove('tv-brand-intro');   // the old logo intro is gone
  updateHeaderIconStates();
});
