<?php
// GET /api/admin/intake/candidates.php?status=staged|published|rejected[&categories=1][&id=N]
//   id: just that one row (Admin → Crawler → Review's "Edit" opens a single listing)
//   ids=1,2,3: just those rows (the listings a crawl just found)
declare(strict_types=1);
require_once __DIR__ . '/_common.php';

$pdo = Database::connection();
$rowId = (int) ($_GET['id'] ?? 0);
$ids = array_filter(array_map('intval', explode(',', (string) ($_GET['ids'] ?? ''))));
$rows = IntakeStager::listRows($pdo, (string) ($_GET['status'] ?? 'staged'), ($rowId || $ids) ? 500 : 100);
if ($rowId) $rows = array_values(array_filter($rows, fn ($r) => (int) $r['id'] === $rowId));
if ($ids) $rows = array_values(array_filter($rows, fn ($r) => in_array((int) $r['id'], $ids, true)));
$out = ['rows' => $rows];
// one row that's no longer waiting (Review's Edit, or a board link to a review item): what happened to it, by whom and when,
// and the listing it became, so the page is never a dead end (CLAUDE.md "Never a dead end"; words follow the state)
if ($rowId && !$rows) {
    try {
        $st = $pdo->prepare('SELECT r.status, r.entity_id, r.matched_entity_id, r.review_note, r.reviewed_at, u.display_name AS by_name
                               FROM ' . Database::t('crawler_raw_index') . ' r LEFT JOIN users u ON u.id = r.reviewed_by_user_id WHERE r.id = ?');
        $st->execute([$rowId]);
        if ($o = $st->fetch(PDO::FETCH_ASSOC)) $out['outcome'] = ['status' => (string) $o['status'], 'entity_id' => $o['entity_id'] !== null ? (int) $o['entity_id'] : null,
            'note' => (string) ($o['review_note'] ?? ''), 'at' => $o['reviewed_at'] ? gmdate('c', (int) strtotime((string) $o['reviewed_at'])) : null, 'by' => (string) ($o['by_name'] ?? '')];
    } catch (Throwable $e) { error_log('candidates outcome: ' . $e->getMessage()); }
}
if (($_GET['categories'] ?? '') === '1') {
    $out['categories'] = array_map(fn ($c) => ['id' => (int) $c['id'], 'name' => $c['name'], 'group' => $c['group_name']],
        IntakeStager::leafCategories($pdo));
}
$out['csrf'] = $_SESSION['csrf_token'] ?? null;
intake_json($out);
