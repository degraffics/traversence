<?php
// app/lib/Storefront.php — a business's storefront on trvgo.us (decisions/0139, the Marketplace's step 5a; 0135 §1).
//   trvgo.us/<shop>           the storefront: the listing, its published items, its pages (SitePages, owner = the listing)
//   trvgo.us/<shop>/<page>    one of its pages;  trvgo.us/<brand>/<location>  a location under a parent brand's shop
// A shop name can't look like a GO Code (exactly 6 characters from the code alphabet), so the two never meet on trvgo.us.
// Core and up (Plan feature 'storefront'). Stages: Building (only its team sees it, through a preview link) → Live →
// Paused. The look: one of the brand's ready themes, the business's logo and cover, one accent color (Jason left it
// open; ready themes keep every shop readable and working on phones). traversence.com stays the source: everything is
// read live; signing in, the cart and checkout stay there. Connecting its own domain is step 5b.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Storefront
{
    public const FEATURE = 'storefront';
    public const STATUSES = ['building' => 'Building', 'live' => 'Live', 'paused' => 'Paused'];
    /** The ready themes: [name, page, card, ink, soft ink, line, default accent]. All in the brand's palette. */
    public const THEMES = [
        'canyon' => ['Canyon', '#EFE3C8', '#FFFBF2', '#3E2B1F', '#6B5640', '#E3D3AC', '#92400E'],
        'sage' => ['Sage', '#EEF4EF', '#FFFFFF', '#1F3A2E', '#4D6B5E', '#CFE0D6', '#3F7A62'],
        'paper' => ['Paper', '#FAF8F3', '#FFFFFF', '#2A2420', '#6B625A', '#E7E1D6', '#B45309'],
        'night' => ['Night', '#1F1A16', '#2A231E', '#F5EBDD', '#C9B9A3', '#44382E', '#E0A15A'],
    ];
    /** Names a shop can't take: our own paths on trvgo.us and words that would mislead. */
    private const RESERVED = ['qr', 'api', 'admin', 'www', 'shop', 'shops', 'store', 'market', 'marketplace', 'help', 'faq', 'about', 'login', 'signin',
        'index', 'edge', 'trvgo', 'traversence', 'support', 'terms', 'privacy', 'official', 'go', 'app', 'static', 'assets', 'mail', 'email', 'billing',
        'staging'];   // staging: the site's test copy's name (ShortCodes::RESERVED, decisions/0145 Phase 3)
    private const CODE_ALPHABET = '23456789abcdefghjkmnpqrstuvwxyz';   // ShortCodes' (decisions/0094)

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM storefronts LIMIT 0'); return true; } catch (Throwable) { return false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /** trvgo.us's address (ShortCodes::base(): trvgo.us on the server). */
    public static function base(): string
    {
        require_once __DIR__ . '/ShortCodes.php';
        return rtrim(ShortCodes::base(), '/');
    }

    /** Its address: its own domain once that's live (step 5b, decisions/0139), else trvgo.us/<shop>. A location sits under its brand. */
    public static function url(array $sf, string $page = ''): string
    {
        $tail = $page !== '' ? '/' . $page : '';
        if (!empty($sf['domain'])) return 'https://' . $sf['domain'] . $tail;
        if (!empty($sf['parent_domain'])) return 'https://' . $sf['parent_domain'] . '/' . $sf['slug'] . $tail;
        return self::trvgoUrl($sf, $page);
    }

    /** Its trvgo.us address, whatever its domain. */
    public static function trvgoUrl(array $sf, string $page = ''): string
    {
        $path = (string) $sf['slug'];
        if (!empty($sf['parent_slug'])) $path = $sf['parent_slug'] . '/' . $path;
        return self::base() . '/' . $path . ($page !== '' ? '/' . $page : '');
    }

    /** Would trvgo.us read this as a GO Code? Exactly 6 characters, all from the code alphabet (capitals work there too). */
    public static function looksLikeCode(string $s): bool
    {
        $s = strtolower($s);
        return strlen($s) === 6 && strspn($s, self::CODE_ALPHABET) === 6;
    }

    /** A path trvgo.us might hand over as a shop: letters, digits and hyphens, up to three parts, and not a code. */
    public static function looksLikeShop(string $path): bool
    {
        $path = strtolower(trim($path, '/'));
        return $path !== '' && preg_match('#^[a-z0-9-]{3,40}(/[a-z0-9-]{1,80}){0,2}$#', $path) === 1 && !self::looksLikeCode(explode('/', $path)[0]);
    }

    public static function slugify(string $s): string
    {
        return trim(substr((string) preg_replace('/[^a-z0-9]+/', '-', strtolower(trim($s))), 0, 40), '-');
    }

    /** Why a shop name can't be used, or '' when it can. */
    public static function nameProblem(PDO $pdo, string $slug, int $e): string
    {
        if ($slug === '' || strlen($slug) < 3) return 'Use at least 3 letters or numbers.';
        if (!preg_match('/^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])$/', $slug) || str_contains($slug, '--')) return 'Use letters, numbers and single hyphens (not at the start or end), up to 40.';
        if (in_array($slug, self::RESERVED, true)) return '"' . $slug . '" is kept for Traversence. Try another.';
        if (self::looksLikeCode($slug)) return 'Six letters like "' . $slug . '" read as a GO Code on trvgo.us. Add a letter or a hyphen.';
        try { $c = $pdo->prepare('SELECT 1 FROM short_codes WHERE code = ?'); $c->execute([$slug]); if ($c->fetchColumn()) return 'A GO Code already uses that. Try another.'; } catch (Throwable) {}   // belt and braces: codes are made 6 letters long
        $st = $pdo->prepare('SELECT entity_id FROM storefronts WHERE slug = ? AND entity_id <> ?'); $st->execute([$slug, $e]);
        if ($st->fetchColumn()) return 'Another shop has that name. Try another.';
        return '';
    }

    public static function allowed(PDO $pdo, int $e): array
    {
        require_once __DIR__ . '/Plan.php'; require_once __DIR__ . '/MarketBiz.php';
        return Plan::allows($pdo, MarketBiz::tier($pdo, $e), self::FEATURE);
    }

    /** The business's storefront, with its parent's name when it's a location; null when it hasn't set one up. */
    public static function get(PDO $pdo, int $e): ?array
    {
        $st = $pdo->prepare('SELECT s.*, p.slug AS parent_slug, p.domain AS parent_domain FROM storefronts s LEFT JOIN storefronts p ON p.entity_id = s.parent_id WHERE s.entity_id = ?');
        $st->execute([$e]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** The storefront a trvgo.us path names: [storefront, page slug]. A location only under its own brand. */
    public static function resolve(PDO $pdo, string $path): ?array
    {
        $p = explode('/', strtolower(trim($path, '/')));
        $st = $pdo->prepare('SELECT s.*, p.slug AS parent_slug, p.domain AS parent_domain FROM storefronts s LEFT JOIN storefronts p ON p.entity_id = s.parent_id WHERE s.slug = ?');
        $st->execute([$p[0]]);
        $sf = $st->fetch(PDO::FETCH_ASSOC);
        if (!$sf) return null;
        if (!empty($sf['parent_id'])) return null;   // a location is reached under its brand
        if (isset($p[1])) {   // a location of this brand, or one of its pages
            $st->execute([$p[1]]);
            $loc = $st->fetch(PDO::FETCH_ASSOC);
            if ($loc && (int) $loc['parent_id'] === (int) $sf['entity_id']) return [$loc, $p[2] ?? ''];
            if (isset($p[2])) return null;
            return [$sf, $p[1]];
        }
        return [$sf, ''];
    }

    /** A first storefront, from the listing's name (Building until the business goes live). */
    public static function start(PDO $pdo, int $e, int $uid, string $name): array
    {
        if ($sf = self::get($pdo, $e)) return $sf;
        [$ok, $start] = self::allowed($pdo, $e);
        if (!$ok) { require_once __DIR__ . '/Plan.php'; throw new InvalidArgumentException(Plan::upgradeNote($start) . '.'); }
        $base = self::slugify($name) ?: 'shop-' . $e;
        if (strlen($base) < 3) $base .= '-shop';
        $slug = $base;
        for ($i = 2; self::nameProblem($pdo, $slug, $e) !== ''; $i++) { $slug = substr($base, 0, 36) . '-' . $i; if ($i > 60) { $slug = 'shop-' . $e; break; } }
        $pdo->prepare("INSERT INTO storefronts (entity_id, slug, status, theme, created_at, updated_at, updated_by) VALUES (?, ?, 'building', 'canyon', ?, ?, ?)")
            ->execute([$e, $slug, self::now(), self::now(), $uid ?: null]);
        return self::get($pdo, $e);
    }

    /**
     * Saves the storefront's settings: name (slug), theme, accent, tagline, about, and a parent brand (a storefront whose
     * team this person is on, with Storefront & pages). Validated; nothing is saved when one part is wrong.
     */
    public static function save(PDO $pdo, int $e, int $uid, array $in, ?callable $mayParent = null): array
    {
        $sf = self::get($pdo, $e);
        if (!$sf) throw new InvalidArgumentException('Set up the storefront first.');
        $slug = array_key_exists('slug', $in) ? self::slugify((string) $in['slug']) : (string) $sf['slug'];
        if (($why = self::nameProblem($pdo, $slug, $e)) !== '') throw new InvalidArgumentException($why);
        $theme = isset(self::THEMES[$in['theme'] ?? '']) ? (string) $in['theme'] : (string) $sf['theme'];
        $accent = strtoupper(trim((string) ($in['accent'] ?? $sf['accent'])));
        if ($accent !== '' && !preg_match('/^#[0-9A-F]{6}$/', $accent)) throw new InvalidArgumentException('The accent color should look like #92400E.');
        if ($accent !== '' && self::contrast($accent, self::THEMES[$theme][2]) < 3.0) throw new InvalidArgumentException('That accent is too close to the ' . self::THEMES[$theme][0] . ' theme\'s cards to read. Pick a darker or brighter one.');
        $tag = mb_substr(trim((string) ($in['tagline'] ?? $sf['tagline'])), 0, 160);
        $about = mb_substr(trim((string) ($in['about'] ?? $sf['about'])), 0, 1500);
        $parent = $sf['parent_id'] !== null ? (int) $sf['parent_id'] : null;
        if (array_key_exists('parent', $in)) {
            $ps = self::slugify((string) $in['parent']);
            if ($ps === '') $parent = null;
            else {
                $st = $pdo->prepare('SELECT entity_id, parent_id FROM storefronts WHERE slug = ?'); $st->execute([$ps]);
                $p = $st->fetch(PDO::FETCH_ASSOC);
                if (!$p || (int) $p['entity_id'] === $e) throw new InvalidArgumentException('There\'s no other shop called "' . $ps . '".');
                if ($p['parent_id'] !== null) throw new InvalidArgumentException('"' . $ps . '" is itself a location. Choose the brand\'s own shop.');
                if (!$mayParent || !$mayParent((int) $p['entity_id'])) throw new InvalidArgumentException('You can only list this as a location of a brand whose storefront you also run.');
                $parent = (int) $p['entity_id'];
            }
        }
        $pdo->prepare('UPDATE storefronts SET slug = ?, theme = ?, accent = ?, tagline = ?, about = ?, parent_id = ?, updated_at = ?, updated_by = ? WHERE entity_id = ?')
            ->execute([$slug, $theme, $accent, $tag, $about, $parent, self::now(), $uid ?: null, $e]);
        return self::get($pdo, $e);
    }

    /** Live or Paused (back to Building isn't a choice: a shop that's been live pauses). */
    public static function setStatus(PDO $pdo, int $e, int $uid, string $to): void
    {
        $sf = self::get($pdo, $e);
        if (!$sf) throw new InvalidArgumentException('Set up the storefront first.');
        if (!in_array($to, ['live', 'paused'], true)) throw new InvalidArgumentException('Live or Paused.');
        if ($to === 'live') { [$ok, $start] = self::allowed($pdo, $e); if (!$ok) { require_once __DIR__ . '/Plan.php'; throw new InvalidArgumentException(Plan::upgradeNote($start) . '.'); } }
        $pdo->prepare('UPDATE storefronts SET status = ?, live_at = IF(? = \'live\' AND live_at IS NULL, ?, live_at), updated_at = ?, updated_by = ? WHERE entity_id = ?')
            ->execute([$to, $to, self::now(), self::now(), $uid ?: null, $e]);
    }

    /** May the public see it? Live, on a plan that includes it, its listing up. */
    public static function showing(PDO $pdo, array $sf): bool
    {
        if ($sf['status'] !== 'live') return false;
        $st = $pdo->prepare('SELECT is_suppressed FROM entities WHERE id = ?'); $st->execute([(int) $sf['entity_id']]);
        if ((int) $st->fetchColumn() === 1) return false;
        return self::allowed($pdo, (int) $sf['entity_id'])[0];
    }

    /** The team's preview of a shop that isn't live: a signed link, good for 7 days (trvgo.us keeps no session). */
    public static function previewKey(int $e, int $daysAgo = 0): string
    {
        $secret = (string) (getenv('APP_SECRET') ?: getenv('DB_PASSWORD') ?: 'tv');
        return substr(hash_hmac('sha256', 'storefront-preview|' . $e . '|' . date('Y-W', strtotime('-' . $daysAgo . ' days')), $secret), 0, 20);
    }

    public static function previewOk(int $e, string $key): bool
    {
        return $key !== '' && (hash_equals(self::previewKey($e), $key) || hash_equals(self::previewKey($e, 7), $key));
    }

    // ---- the logo and cover: the business's own photos, in a public "Storefront" album ------------------------------

    /** Sets the logo or cover to one of the business's photos (0 clears it), and keeps the public album to match. */
    public static function setPhoto(PDO $pdo, int $e, string $which, int $item): void
    {
        if (!in_array($which, ['logo', 'cover'], true)) throw new InvalidArgumentException('Logo or cover.');
        if ($item) {
            $st = $pdo->prepare("SELECT id FROM gallery_items WHERE id = ? AND owner_kind = 'businesses' AND owner_ref = ? AND kind = 'photo' AND ready = 1");
            $st->execute([$item, (string) $e]);
            if (!$st->fetchColumn()) throw new InvalidArgumentException('That photo isn\'t one of the business\'s.');
        }
        $pdo->prepare('UPDATE storefronts SET ' . $which . '_id = ?, updated_at = ? WHERE entity_id = ?')->execute([$item ?: null, self::now(), $e]);
        self::syncAlbum($pdo, $e);
    }

    /**
     * The photos a storefront shows in the business's public "Storefront" album, so anyone may see them: its logo and
     * cover, and the pictures in its pages' blocks, published or in a draft its preview shows (decisions/0159 step 5a).
     * Only the business's own photos ever join it.
     */
    public static function syncAlbum(PDO $pdo, int $e): void
    {
        try {
            require_once __DIR__ . '/Gallery.php'; require_once __DIR__ . '/Market.php';
            Gallery::ensure($pdo);
            $k = 'salbum:' . $e;
            $album = (int) (Market::setting($pdo, $k) ?? 0);
            $st = $pdo->prepare("SELECT id FROM gallery_albums WHERE id = ? AND owner_kind = 'businesses' AND owner_ref = ?"); $st->execute([$album, (string) $e]);
            if (!$album || !$st->fetchColumn()) {
                $pdo->prepare("INSERT INTO gallery_albums (owner_kind, owner_ref, title, about, mode, visibility, token, created_at) VALUES ('businesses', ?, 'Storefront', ?, 'social', 'public', ?, ?)")
                    ->execute([(string) $e, 'Your storefront\'s logo and cover. They show on your storefront.', bin2hex(random_bytes(16)), self::now()]);
                $album = (int) $pdo->lastInsertId();
                Market::remember($pdo, $k, (string) $album);
            }
            $sf = self::get($pdo, $e);
            $want = array_values(array_unique(array_merge(array_filter([(int) ($sf['logo_id'] ?? 0), (int) ($sf['cover_id'] ?? 0)]), self::blockPhotos($pdo, $e))));
            $st = $pdo->prepare('SELECT item_id FROM gallery_album_items WHERE album_id = ?'); $st->execute([$album]);
            $have = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
            foreach (array_diff($have, $want) as $g) $pdo->prepare('DELETE FROM gallery_album_items WHERE album_id = ? AND item_id = ?')->execute([$album, $g]);
            $ins = $pdo->prepare('INSERT IGNORE INTO gallery_album_items (album_id, item_id, sort, added_at) VALUES (?, ?, 0, ?)');
            foreach (array_diff($want, $have) as $g) $ins->execute([$album, $g, self::now()]);
        } catch (Throwable $x) { error_log('storefront album: ' . $x->getMessage()); }
    }

    /** The business's own photos its pages' blocks show (live versions and drafts of its "shop.<page id>" zones). */
    private static function blockPhotos(PDO $pdo, int $e): array
    {
        try {
            $st = $pdo->prepare("SELECT CONCAT('shop.', id) FROM site_pages WHERE owner_id = ?"); $st->execute([$e]);
            $zones = $st->fetchAll(PDO::FETCH_COLUMN);
            if (!$zones) return [];
            $in = implode(',', array_fill(0, count($zones), '?'));
            $st = $pdo->prepare("SELECT z.draft, v.tree FROM site_block_zones z LEFT JOIN site_block_versions v ON v.zone = z.zone AND v.version = z.live_version WHERE z.zone IN ($in)");
            $st->execute($zones);
            $ids = [];
            foreach ($st->fetchAll(PDO::FETCH_NUM) as [$d, $t]) {
                preg_match_all('#/gallery/m\.php\?i=(\d+)#', (string) $d . ' ' . (string) $t, $m);
                foreach ($m[1] as $i) $ids[(int) $i] = true;
            }
            if (!$ids) return [];
            $ids = array_keys($ids);
            $st = $pdo->prepare("SELECT id FROM gallery_items WHERE owner_kind = 'businesses' AND owner_ref = ? AND kind = 'photo' AND ready = 1 AND id IN (" . implode(',', array_fill(0, count($ids), '?')) . ')');
            $st->execute(array_merge([(string) $e], $ids));
            return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        } catch (Throwable $x) { error_log('storefront block photos: ' . $x->getMessage()); return []; }
    }

    /** A photo's address for the storefront ('' when none). */
    public static function photoUrl(PDO $pdo, ?int $id, string $size = 'card'): string
    {
        if (!$id) return '';
        try {
            require_once __DIR__ . '/Gallery.php';
            $st = $pdo->prepare('SELECT * FROM gallery_items WHERE id = ? AND ready = 1'); $st->execute([$id]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return $r ? Gallery::url($r, $size) : '';
        } catch (Throwable) { return ''; }
    }

    /** WCAG contrast ratio of two #RRGGBB colors. */
    public static function contrast(string $a, string $b): float
    {
        $l = function (string $h): float {
            $c = array_map(fn ($x) => hexdec($x) / 255, str_split(ltrim($h, '#'), 2));
            $c = array_map(fn ($v) => $v <= 0.03928 ? $v / 12.92 : (($v + 0.055) / 1.055) ** 2.4, $c);
            return 0.2126 * $c[0] + 0.7152 * $c[1] + 0.0722 * $c[2];
        };
        [$x, $y] = [$l($a), $l($b)];
        return (max($x, $y) + 0.05) / (min($x, $y) + 0.05);
    }

    /** Every storefront for the admin: [rows with the business's name]. */
    public static function all(PDO $pdo, string $status = '', string $q = ''): array
    {
        $w = ['1 = 1']; $a = [];
        if (isset(self::STATUSES[$status])) { $w[] = 's.status = ?'; $a[] = $status; }
        if (($q = trim($q)) !== '') { $w[] = '(s.slug LIKE ? OR e.name LIKE ?)'; array_push($a, "%$q%", "%$q%"); }
        $st = $pdo->prepare('SELECT s.*, e.name, e.plan_tier, p.slug AS parent_slug, p.domain AS parent_domain FROM storefronts s LEFT JOIN entities e ON e.id = s.entity_id LEFT JOIN storefronts p ON p.entity_id = s.parent_id WHERE '
            . implode(' AND ', $w) . ' ORDER BY s.updated_at DESC LIMIT 300');
        $st->execute($a);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
