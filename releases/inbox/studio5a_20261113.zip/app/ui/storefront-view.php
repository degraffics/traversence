<?php
// app/ui/storefront-view.php — a business's storefront as trvgo.us shows it (decisions/0139, step 5a). Called by the
// trvgo.us router (trvgo/index.php) for a path that isn't a code. Drawn live from traversence.com's data: the listing's
// public details (VCard::listingCard, which keeps a confidential listing's address off), its published items
// (MarketBiz), its live pages (SitePages, owner = the listing). No session, no cookie and no script, like the rest of
// trvgo.us: buying, messaging and signing in happen on traversence.com, where the links lead. Not live: its team sees it
// through the preview link from the portal (?preview=…), marked as a preview and kept out of search engines.
// A page made of blocks (decisions/0159 step 5a, Storefront Studio: zone "shop.<page id>") draws its published blocks
// (Blocks::shop, plain HTML in the storefront's colors); the preview link shows its team's drafts, on a live storefront
// too, and pages still in Draft. A page nobody has edited as blocks shows its Markdown, as before.
declare(strict_types=1);

require_once __DIR__ . '/../lib/Storefront.php';

/**
 * A visit on a business's own domain, passed on by the edge (decisions/0139 §3, step 5b): trusted only with the edge's
 * key (X-TV-Edge, STOREFRONT_EDGE_KEY). The domain's path is its storefront's: / is the shop, /about-us a page,
 * /location a location of the brand. False when it isn't a live domain of ours (the router says so).
 */
function tv_storefront_domain(PDO $pdo, string $host, string $key, string $path, string $site): bool
{
    $want = (string) getenv('STOREFRONT_EDGE_KEY');
    if ($want === '' || !hash_equals($want, $key)) { error_log('SECURITY trvgo: a domain visit without the edge\'s key (' . mb_substr($host, 0, 80) . ')'); return false; }
    require_once __DIR__ . '/../lib/Domains.php';
    if (!Domains::ready($pdo) || !($hit = Domains::byHost($pdo, $host))) return false;
    $sf = Storefront::get($pdo, $hit[0]);
    if (!$sf) return false;
    $base = !empty($sf['parent_slug']) ? $sf['parent_slug'] . '/' . $sf['slug'] : (string) $sf['slug'];
    $path = trim(strtolower($path), '/');
    if ($path !== '' && !preg_match('#^[a-z0-9-]{1,80}(/[a-z0-9-]{1,80})?$#', $path)) return false;
    return tv_storefront_serve($pdo, $base . ($path !== '' ? '/' . $path : ''), $site, true);
}

/** Serves the storefront a path names. False when there's no such shop (the router then says the code isn't active). */
function tv_storefront_serve(PDO $pdo, string $path, string $site, bool $onDomain = false): bool
{
    if (!Storefront::ready($pdo) || !Storefront::looksLikeShop($path)) return false;
    $hit = Storefront::resolve($pdo, $path);
    if (!$hit) return false;
    [$sf, $pageSlug] = $hit;
    $e = (int) $sf['entity_id'];
    $preview = !Storefront::showing($pdo, $sf);
    $team = Storefront::previewOk($e, (string) ($_GET['preview'] ?? ''));   // its team's look: drafts shown (5a)
    if ($preview && !$team) return tv_storefront_closed($sf, $site);
    // on trvgo.us, a shop with its own domain lives there now: one address for search engines (previews stay here)
    if (!$onDomain && !$team && (!empty($sf['domain']) || !empty($sf['parent_domain']))) {
        header('Location: ' . Storefront::url($sf, $pageSlug), true, 301);
        header('Cache-Control: public, max-age=300', true);
        return true;
    }

    require_once __DIR__ . '/../lib/VCard.php'; require_once __DIR__ . '/../lib/MarketBiz.php'; require_once __DIR__ . '/../lib/SitePages.php';
    $card = VCard::listingCard($pdo, $e);
    if (!$card) return false;   // the listing isn't up
    $pages = array_values(array_filter(SitePages::all($pdo, $e), fn ($p) => $p['status'] === 'live' || ($team && $p['status'] === 'draft')));
    $page = null;
    if ($pageSlug !== '') {
        $page = SitePages::bySlug($pdo, $pageSlug, $e);
        if (!$page || !($page['status'] === 'live' || ($team && $page['status'] === 'draft'))) return false;
    }
    require_once __DIR__ . '/../lib/Blocks.php';
    $blocks = $page ? Blocks::shop($pdo, (int) $page['id'], $team) : null;   // null: the page's Markdown, as before
    if ($blocks !== null) $blocks = (string) preg_replace('#(src|href)="/(?!/)#', '$1="' . $site . '/', $blocks);   // our own paths are on traversence.com
    $abs = fn (string $u) => $u !== '' && $u[0] === '/' ? $site . $u : $u;   // our own paths live on traversence.com
    $h = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES);
    [$tname, $bg, $cardBg, $ink, $soft, $line, $defAccent] = Storefront::THEMES[$sf['theme']] ?? Storefront::THEMES['canyon'];
    $accent = $sf['accent'] !== '' ? (string) $sf['accent'] : $defAccent;
    $onAccent = Storefront::contrast($accent, '#FFFFFF') >= 4.5 ? '#FFFFFF' : '#1F1A16';
    $logo = $abs(Storefront::photoUrl($pdo, $sf['logo_id'] ? (int) $sf['logo_id'] : null, 'card'));
    $cover = $abs(Storefront::photoUrl($pdo, $sf['cover_id'] ? (int) $sf['cover_id'] : null, 'full'));
    // no cover of its own: a stock photo as its banner, the one its team chose or one picked for it, always labelled
    // "Stock photo · Representative" (never shown as the business's own); its own cover takes over by itself (decisions/0143)
    $stock = null;
    if ($cover === '') {
        try {
            require_once __DIR__ . '/../lib/StockLibrary.php'; require_once __DIR__ . '/stock-ui.php';
            $cl = $pdo->prepare('SELECT micro_cluster_id FROM entities WHERE id = ?'); $cl->execute([$e]);
            $stock = StockLibrary::forSlot($pdo, 'storefront_cover', (string) $e, 'main street shop', ($sfCl = (int) $cl->fetchColumn()) ? 'cluster:' . $sfCl : '', ['representative' => true, 'fallback' => 'main street']);
        } catch (Throwable $x) { error_log('storefront stock: ' . $x->getMessage()); }
    }
    $name = (string) $card['org'];
    $home = $team ? Storefront::trvgoUrl($sf) : Storefront::url($sf);
    $q = $team ? '?preview=' . rawurlencode((string) $_GET['preview']) : '';
    $items = $page ? [] : MarketBiz::browse($pdo, [], 120, $e);
    $locations = [];
    if (!$page && empty($sf['parent_id'])) {   // a brand's locations, live ones only
        $st = $pdo->prepare("SELECT s.*, e.name FROM storefronts s JOIN entities e ON e.id = s.entity_id WHERE s.parent_id = ? AND s.status = 'live' AND e.is_suppressed = 0 ORDER BY e.name");
        $st->execute([$e]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $l) $locations[] = ['name' => (string) $l['name'], 'url' => $preview ? Storefront::trvgoUrl($l + ['parent_slug' => $sf['slug']]) : Storefront::url($l + ['parent_slug' => $sf['slug'], 'parent_domain' => $sf['domain']])];
    }
    $title = $page ? $page['title'] . ' · ' . $name : $name . ($sf['tagline'] !== '' ? ' · ' . $sf['tagline'] : '');
    $desc = $page ? (string) ($page['summary'] ?: mb_substr(trim((string) preg_replace('/\s+/', ' ', strip_tags((string) preg_replace('#<style.*?</style>#s', '', $blocks ?? SitePages::html((string) $page['body']))))), 0, 160)) : (string) ($sf['tagline'] ?: mb_substr((string) $sf['about'], 0, 160));
    $canonical = $home . ($page ? '/' . $page['slug'] : '');
    $addr = trim(implode(', ', array_filter([$card['street'] ?? '', trim(($card['city'] ?? '') . ' ' . ($card['state'] ?? '') . ' ' . ($card['zip'] ?? ''))])));
    $listing = $site . '/listing/view.php?id=' . $e;

    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: ' . ($team ? 'no-store, private' : 'public, max-age=300'), true);
    header('X-Robots-Tag: ' . ($team ? 'noindex, nofollow' : 'all'), true);
    header('Referrer-Policy: strict-origin-when-cross-origin', true);
    // no script at all, so the policy can forbid every one (the card pages' rules, 0098, would allow far more)
    header("Content-Security-Policy: default-src 'none'; img-src 'self' https: data:; style-src 'unsafe-inline'; form-action 'none'; base-uri 'none'; frame-ancestors 'none'");

    $ld = ['@context' => 'https://schema.org', '@type' => 'LocalBusiness', 'name' => $name, 'url' => $home] + (isset($card['phone']) ? ['telephone' => $card['phone']] : [])
        + ($addr !== '' ? ['address' => ['@type' => 'PostalAddress', 'streetAddress' => $card['street'] ?? '', 'addressLocality' => $card['city'] ?? '', 'addressRegion' => $card['state'] ?? '', 'postalCode' => $card['zip'] ?? '']] : [])
        + ($logo !== '' ? ['logo' => $logo] : []);

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . $h($title) . '</title><meta name="description" content="' . $h($desc) . '">'
        . ($team ? '' : '<link rel="canonical" href="' . $h($canonical) . '">')
        . '<meta property="og:title" content="' . $h($page ? $page['title'] : $name) . '"><meta property="og:description" content="' . $h($desc) . '"><meta property="og:url" content="' . $h($canonical) . '">'
        . ($cover !== '' || $logo !== '' ? '<meta property="og:image" content="' . $h($cover ?: $logo) . '">' : '')
        . '<script type="application/ld+json">' . json_encode($ld, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) . '</script>'
        . '<style>'
        . ':root{--bg:' . $bg . ';--card:' . $cardBg . ';--ink:' . $ink . ';--soft:' . $soft . ';--line:' . $line . ';--acc:' . $accent . ';--on:' . $onAccent . '}'
        . '*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}'
        . 'a{color:var(--acc)}.w{max-width:64rem;margin:0 auto;padding:0 16px}'
        . '.pv{background:#FDE68A;color:#78350F;text-align:center;font:600 .85rem system-ui,sans-serif;padding:.45rem 1rem}'
        . '.hero{position:relative;background:var(--card) center/cover no-repeat;border-bottom:1px solid var(--line)}'
        . '.hero.has{min-height:clamp(10rem,32vw,20rem)}.hero.has::after{content:"";position:absolute;inset:0;background:linear-gradient(transparent 40%,rgba(0,0,0,.45))}'
        . '.top{display:flex;gap:.9rem;align-items:flex-end;padding-top:1.4rem;position:relative;z-index:1}.hero.has+.w .top{margin-top:-2.6rem;padding-top:0}'
        . '.hero.has+.w .top h1{text-shadow:0 1px 0 var(--bg)}'
        . '.lg{width:5.5rem;height:5.5rem;border-radius:1rem;background:var(--card) center/cover no-repeat;border:3px solid var(--card);box-shadow:0 2px 10px rgba(0,0,0,.18);flex:none}'
        . '.top h1{font:700 clamp(1.5rem,4vw,2.2rem)/1.15 Georgia,serif;margin:0 0 .2rem}.tag{color:var(--soft);margin:0}'
        . 'nav.pg{display:flex;flex-wrap:wrap;gap:.4rem;margin:1rem 0 .4rem}nav.pg a{border:1px solid var(--line);background:var(--card);border-radius:999px;padding:.3rem .85rem;text-decoration:none;color:var(--ink);font-weight:600;font-size:.9rem}'
        . 'nav.pg a.on{background:var(--acc);border-color:var(--acc);color:var(--on)}'
        . '.box{background:var(--card);border:1px solid var(--line);border-radius:.8rem;padding:1rem 1.1rem;margin:.8rem 0}'
        . '.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(14rem,100%),1fr));gap:.7rem;margin:.6rem 0}'
        . '.it{background:var(--card);border:1px solid var(--line);border-radius:.8rem;overflow:hidden;display:flex;flex-direction:column;text-decoration:none;color:var(--ink)}'
        . '.it .ph{aspect-ratio:4/3;background:var(--line) center/cover no-repeat}.it .tx{padding:.6rem .75rem .75rem}.it b{display:block;color:var(--acc);text-decoration:underline}'
        . '.it .pr{display:block;font-weight:700;margin-top:.15rem}.it small{display:block;color:var(--soft)}'
        . '.acts{display:flex;flex-wrap:wrap;gap:.45rem;margin:.6rem 0 0}.btn{display:inline-block;background:var(--acc);color:var(--on);border-radius:.6rem;padding:.5rem .95rem;font-weight:700;text-decoration:none}'
        . '.btn.o{background:transparent;color:var(--acc);border:1px solid var(--acc)}'
        . '.pgb h2{font:700 1.25rem Georgia,serif;margin:1rem 0 .4rem}.pgb h3{font-size:1.05rem;margin:.9rem 0 .3rem}.pgb img{max-width:100%;border-radius:.5rem}'
        . 'h2.s{font:700 1.2rem Georgia,serif;margin:1.4rem 0 .2rem}.ft{color:var(--soft);font-size:.85rem;text-align:center;padding:2rem 16px 2.5rem}'
        // a page's blocks in the storefront's own colors (the full themes as the blocks' starting styles come in 5b)
        . '.pgb .tvb-sec{color:var(--ink)}.pgb .tvb-text a{color:var(--acc)}.pgb .tvb-img figcaption{color:var(--soft)}.pgb .tvb-btn{background:var(--acc);color:var(--on)}'
        . '.pgb .tvb-btn.plain{background:transparent;color:var(--acc);border-color:var(--acc)}.pgb .tvb-bg-sand,.pgb .tvb-bg-sage{background:var(--bg);border-color:var(--line)}.pgb .tvb-hr{border-top-color:var(--line)}'
        . '@media (max-width:767px){.w{padding:0 3px}.box,.it{border-radius:.5rem}.box{padding:.85rem .8rem}.top{padding-left:.5rem;padding-right:.5rem}nav.pg,h2.s,.tag{padding:0 .5rem}.top .tag{padding:0}.grid{gap:3px}}'
        . '</style></head><body>';
    if ($preview) echo '<div class="pv">Preview: only your team has this link. The storefront isn\'t ' . ($sf['status'] === 'paused' ? 'showing while it\'s paused' : 'live yet') . '. Pages show their drafts.</div>';
    elseif ($team) echo '<div class="pv">Preview: only your team has this link. Pages show their drafts and pages still in Draft; visitors see what\'s published.</div>';
    echo ($cover !== '' ? '<div class="hero has" style="background-image:url(\'' . $h($cover) . '\')"></div>'
            : ($stock ? '<div class="hero has stk" style="background-image:url(\'' . $h($abs($stock['url'])) . '\')">' . tv_stock_tag($stock, ['site' => $site, 'at' => 'tr']) . '</div>' : ''))
        . '<div class="w"><div class="top">' . ($logo !== '' ? '<div class="lg" style="background-image:url(\'' . $h($logo) . '\')" role="img" aria-label="' . $h($name) . '"></div>' : '')
        . '<div><h1>' . $h($name) . '</h1>' . ($sf['tagline'] !== '' ? '<p class="tag">' . $h($sf['tagline']) . '</p>' : '') . '</div></div>';
    // the menu: the shop, its pages
    if ($pages) {
        echo '<nav class="pg" aria-label="' . $h($name) . '"><a href="' . $h($home . $q) . '"' . (!$page ? ' class="on"' : '') . '>Shop</a>';
        foreach ($pages as $p) echo '<a href="' . $h($home . '/' . $p['slug'] . $q) . '"' . ($page && (int) $page['id'] === (int) $p['id'] ? ' class="on"' : '') . '>' . $h($p['title']) . ($p['status'] === 'draft' ? ' (draft)' : '') . '</a>';
        echo '</nav>';
    }
    if ($page) {
        $body = $blocks ?? (string) preg_replace('#(src|href)="/(?!/)#', '$1="' . $site . '/', SitePages::html((string) $page['body']));   // its own pictures and links are on traversence.com
        echo '<article class="box pgb"><h2 style="margin-top:0">' . $h($page['title']) . '</h2>' . $body
            . ($page['form'] !== 'none' ? '<div class="acts"><a class="btn" href="' . $h($listing) . '">Message ' . $h($name) . '</a></div>' : '') . '</article>';
    } else {
        if ($sf['about'] !== '') echo '<div class="box">' . nl2br($h($sf['about'])) . '</div>';
        if ($locations) {
            echo '<h2 class="s">Our locations</h2><div class="grid">';
            foreach ($locations as $l) echo '<a class="it" href="' . $h($l['url']) . '"><span class="tx"><b>' . $h($l['name']) . '</b></span></a>';
            echo '</div>';
        }
        echo '<h2 class="s">Shop</h2>';
        if (!$items) echo '<div class="box"><p style="margin:0">Nothing listed right now. <a href="' . $h($listing) . '">Message ' . $h($name) . '</a> to ask what\'s available.</p></div>';
        else {
            echo '<div class="grid">';
            foreach ($items as $it) echo '<a class="it" href="' . $h($site . $it['url']) . '"><span class="ph"' . ($it['photo'] !== '' ? ' style="background-image:url(\'' . $h($abs($it['photo'])) . '\')"' : '') . ' role="img" aria-label="' . $h($it['title']) . '"></span>'
                . '<span class="tx"><b>' . $h($it['title']) . '</b><span class="pr">' . $h($it['price']) . '</span>' . (($it['kind'] ?? 'physical') !== 'physical' && !empty($it['kind_name']) ? '<small>' . $h($it['kind_name']) . ($it['category'] !== '' ? ' · ' . $h($it['category']) : '') . '</small>' : ($it['category'] !== '' ? '<small>' . $h($it['category']) . '</small>' : '')) . '</span></a>';   // its kind (decisions/0141 §5)
            echo '</div><p class="tag" style="font-size:.88rem">Buying, messages and offers are on Traversence, where ' . $h($name) . ' gets them.</p>';
        }
        // its store policies, as buyers accept them at checkout (decisions/0142 §5.3); no script, so a details box
        try { require_once __DIR__ . '/../lib/StorePolicies.php'; echo StorePolicies::css() . StorePolicies::box($pdo, (int) $sf['entity_id'], null, false, 'Store policies'); } catch (Throwable $x) { error_log('storefront policies: ' . $x->getMessage()); }
    }
    // contact: what the listing shows publicly
    echo '<div class="box"><b>' . $h($name) . '</b>' . ($addr !== '' ? '<div>' . $h($addr) . '</div>' : '') . '<div class="acts">'
        . (isset($card['phone']) ? '<a class="btn" href="tel:' . $h(preg_replace('/[^0-9+]/', '', (string) $card['phone'])) . '">Call ' . $h($card['phone']) . '</a>' : '')
        . '<a class="btn' . (isset($card['phone']) ? ' o' : '') . '" href="' . $h($listing) . '">Message us</a>'
        . (isset($card['geo']) ? '<a class="btn o" href="https://www.google.com/maps/dir/?api=1&amp;destination=' . $h($card['geo'][0] . ',' . $card['geo'][1]) . '">Directions</a>' : '')
        . (isset($card['url']) ? '<a class="btn o" href="' . $h($card['url']) . '" rel="nofollow noopener">Website</a>' : '')
        . '</div></div></div>'
        . '<div class="ft">' . $h($name) . ' on <a href="' . $h($site) . '">Traversence</a></div></body></html>';
    return true;
}

/** A shop that isn't showing (paused, building, its plan ended): a plain page, not a missing one. */
function tv_storefront_closed(array $sf, string $site): bool
{
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex', true);
    $h = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Not open right now · TRVGO</title>'
        . '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7EFDC;color:#3E2B1F;font:16px/1.5 Georgia,serif;padding:16px}'
        . '.c{max-width:24rem;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.9rem;padding:1.2rem 1.3rem;text-align:center}a{color:#92400E}</style></head>'
        . '<body><div class="c"><h1 style="font-size:1.3rem;margin:0 0 .4rem">This shop isn\'t open right now</h1>'
        . '<p style="margin:0 0 .8rem">Its storefront is being set up or is paused. The business is still on Traversence.</p>'
        . '<p style="margin:0"><a href="' . $h($site . '/listing/view.php?id=' . (int) $sf['entity_id']) . '">See it on Traversence</a></p></div></body></html>';
    return true;
}
