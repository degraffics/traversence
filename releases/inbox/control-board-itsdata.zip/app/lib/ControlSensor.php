<?php
// app/lib/ControlSensor.php — the System Control Board's sensor for the site's own critical duties (decisions/0171 §5's
// note, Jason 2026-11-19: "Critical is that our site can perform its duties. Search, page load, payment processing,
// database connections, system critical processing or procedures"). The workers' calls have the ledger; search, sign-in
// and payments are called by browsers and by Intuit, so nothing watched them. Two readings, both free:
//   1. what visitors hit: a server error (a 5xx, or a fatal error) on one of their paths, noted by a hook in Database.php
//      (path and status only: no query string, address or user; kept 7 days; never written when the table or the
//      connection isn't there, and never thrown);
//   2. a probe every 5 minutes from the board's watch: one search through the search library with nothing recorded (no
//      demand, no crawler, no view, no AI), and QuickBooks' token read locally (a real check at most once an hour, held
//      on staging).
// A part fails when its probe fails, or when its paths answered server errors to at least control_crit_requests requests
// in the window (3 unless changed in Thresholds & gates): one visitor's odd request is kept as a notice on the part's
// row, never a trip. A failure is raised on the part, and the critical rule does the rest (a trip at once while the system
// keeps trying; Recovered; the Escalation Notice).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class ControlSensor
{
    /** The parts it watches: id => [name, its paths (the start of each), what to do when it fails]. */
    public const PARTS = [
        'site:search' => ['Search', ['/api/search.php', '/api/search_listings.php', '/q.php', '/api/place.php', '/api/places.php', '/api/open-places.php'],
            'Open the failing path (beside this) to see what visitors get; the server\'s error log on Bluehost says why. Its next good answers clear this.'],
        'site:signin' => ['Sign-in', ['/login.php', '/api/auth/'],
            'Open the sign-in page (beside this); the server\'s error log on Bluehost says why. Its next good answers clear this.'],
        'site:payments' => ['Checkout and payments', ['/order.php', '/api/qb-webhook.php', '/api/plans.php', '/api/market-pay.php', '/api/market-webhook.php'],
            'Open QuickBooks\' connection (beside this) and the server\'s error log on Bluehost. Its next good answers clear this.'],
    ];
    private const WINDOW = 300;   // the watch's 5 minutes
    /** Tests only: stand-ins for the probes (null: the real ones). */
    public static $searchProbe = null; public static $payProbe = null; public static $signinProbe = null;

    public static function ensure(PDO $pdo): void
    {
        $pdo->exec('CREATE TABLE IF NOT EXISTS control_errors (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, path VARCHAR(120) NOT NULL,
            code SMALLINT UNSIGNED NOT NULL, at DATETIME NOT NULL, KEY at (at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    }

    /** The part a request's path belongs to ('' none). */
    public static function partOf(string $path): string
    {
        foreach (self::PARTS as $pid => [, $paths]) foreach ($paths as $p) if ($path === $p || str_starts_with($path, $p)) return $pid;
        return '';
    }

    /**
     * The hook (Database.php's shutdown): a server error on a watched path is noted. Only with a connection already open
     * (a database that's down has its own alarm, and connecting now would slow the answer); never throws.
     */
    public static function note(int $code): void
    {
        try {
            $path = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
            if ($path === '' || self::partOf($path) === '') return;
            $pdo = Database::open(); if (!$pdo) return;
            $pdo->prepare('INSERT INTO control_errors (path, code, at) VALUES (?, ?, UTC_TIMESTAMP())')->execute([mb_substr($path, 0, 120), max(500, min(599, $code))]);
        } catch (Throwable $x) {}
    }

    /** How many requests make a part's failure (Thresholds & gates; one alone is kept as a notice). */
    public static function threshold(PDO $pdo): int
    {
        try { require_once __DIR__ . '/Thresholds.php'; $v = Thresholds::get($pdo, 'control_crit_requests'); return $v === null ? 3 : max(1, (int) $v); } catch (Throwable $x) { return 3; }
    }

    /** The search probe: one search through the library, nothing recorded or sent. [ok, words]. */
    public static function probeSearch(PDO $pdo): array
    {
        $t = microtime(true);
        try {
            require_once __DIR__ . '/UniversalSearch.php';
            $r = UniversalSearch::search($pdo, 'Show Low', ['no_side' => 1]);   // no_side: no crawler, no demand, no help-find (UniversalSearch)
            $ms = (int) round((microtime(true) - $t) * 1000);
            return is_array($r) ? [true, 'A test search answered in ' . $ms . ' ms (nothing recorded).'] : [false, 'A test search gave no answer.'];
        } catch (Throwable $x) { return [false, 'A test search failed: ' . mb_substr($x->getMessage(), 0, 160)]; }
    }

    /**
     * The sign-in test: what signing in needs, without signing anyone in: the session store takes a write (a probe file,
     * removed at once; never a session), the sign-in library loads and the accounts table answers (one read). [ok, words].
     */
    public static function probeSignin(PDO $pdo): array
    {
        try {
            $dir = __DIR__ . '/../storage/sessions';
            if (!is_dir($dir)) return [false, 'The session store (app/storage/sessions) isn\'t there: no one can stay signed in.'];
            $f = $dir . '/probe-' . bin2hex(random_bytes(6));
            if (@file_put_contents($f, 'x') !== 1) return [false, 'The session store (app/storage/sessions) won\'t take a write: no one can stay signed in.'];
            @unlink($f);
            require_once __DIR__ . '/Auth.php';
            if (!class_exists('Auth')) return [false, 'The sign-in library didn\'t load.'];
            $pdo->query('SELECT id FROM users LIMIT 1')->fetchColumn();
            return [true, 'Sign-in\'s parts answer: the session store takes a write, the accounts table answers (no one signed in).'];
        } catch (Throwable $x) { return [false, 'Sign-in\'s test failed: ' . mb_substr($x->getMessage(), 0, 160)]; }
    }

    /**
     * QuickBooks: its token read locally every 5 minutes; a real check at most once an hour (held on staging). [state,
     * words]: 'na' not set up (no judgement), 'ok', 'held' (needs reconnecting: a trip at once), 'bad' (it failed).
     */
    public static function probePayments(PDO $pdo): array
    {
        try {
            require_once __DIR__ . '/QuickBooksPay.php';
            if (QuickBooksPay::env() === 'mock' || !QuickBooksPay::configured()) return ['na', 'QuickBooks isn\'t set up here.'];
            $c = QuickBooksPay::connection($pdo);
            if (!$c) return ['na', 'QuickBooks isn\'t connected yet.'];
            if (QuickBooksPay::needsReconnect($c)) return ['held', 'QuickBooks\' connection ran out or was refused: it needs reconnecting.'];
            require_once __DIR__ . '/SearchIndex.php';
            $last = (int) SearchIndex::state($pdo, 'control:qb_checked');
            if (time() - $last < 3600) return ['ok', 'Connected; its token is good until ' . gmdate('M j', (int) strtotime((string) $c['refresh_until'])) . ' (last asked QuickBooks ' . gmdate('H:i', $last) . ' UTC).'];
            require_once __DIR__ . '/StagingGate.php';
            if (StagingGate::hold('https://quickbooks.api.intuit.com/v3/company', 'The Control Board\'s hourly QuickBooks check') !== null) return ['ok', 'Connected (staging: the hourly check is held).'];
            SearchIndex::setState($pdo, 'control:qb_checked', (string) time());
            try { QuickBooksPay::ping($pdo); return ['ok', 'Connected; QuickBooks answered at ' . gmdate('H:i') . ' UTC.']; }
            catch (Throwable $x) {
                $m = $x->getMessage();
                if (preg_match('/needs reconnecting|\((401|403)[,)]/', $m)) return ['held', 'QuickBooks refused us: ' . mb_substr($m, 0, 160)];
                return ['bad', 'QuickBooks didn\'t answer: ' . mb_substr($m, 0, 160)];
            }
        } catch (Throwable $x) { return ['bad', 'QuickBooks\' check failed: ' . mb_substr($x->getMessage(), 0, 160)]; }
    }

    // ---- Pulse's gathering time (Jason, 2026-11-19: "add Pulse's load-time warning"; the session manager's spec) --------

    /** One open of the admin's Pulse: how long its rows took to gather, kept with the board's readings (the time only). */
    public static function pulseTimed(PDO $pdo, int $ms): void
    {
        try { require_once __DIR__ . '/ControlHistorian.php'; ControlHistorian::ensure($pdo);
            $pdo->prepare("INSERT INTO control_readings (proc, reading, value, state, at) VALUES ('site:pulse', 'gather_ms', ?, NULL, UTC_TIMESTAMP())")->execute([max(0, $ms)]); } catch (Throwable $x) {}
    }

    /** Its usual gathering time: [median ms of the last 20 opens, how many opens], or [null, 0]. */
    public static function pulseUsual(PDO $pdo): array
    {
        try { $v = array_map('floatval', $pdo->query("SELECT value FROM control_readings WHERE proc = 'site:pulse' AND reading = 'gather_ms' ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_COLUMN)); } catch (Throwable $x) { $v = []; }
        if (!$v) return [null, 0];
        sort($v); $n = count($v); $m = $n % 2 ? $v[intdiv($n, 2)] : ($v[$n / 2 - 1] + $v[$n / 2]) / 2;
        return [(int) round($m), $n];
    }

    /** The limit (Thresholds & gates, default 2 seconds). */
    public static function pulseLimit(PDO $pdo): int
    {
        try { require_once __DIR__ . '/Thresholds.php'; $v = Thresholds::get($pdo, 'control_pulse_ms'); return $v === null ? 2000 : max(100, (int) $v); } catch (Throwable $x) { return 2000; }
    }

    /** The watch: slow Pulse is a warning on the board only (slow is never a trip, 4e), cleared when its usual time is back. */
    public static function pulseWatch(PDO $pdo): string
    {
        [$m, $n] = self::pulseUsual($pdo); $lim = self::pulseLimit($pdo);
        require_once __DIR__ . '/ControlAlarms.php';
        if ($m !== null && $n >= 5 && $m > $lim) {
            ControlAlarms::raise($pdo, 'slow:site:pulse', 'site:pulse', 'warning', 'slow', 'Pulse is slow to gather (' . number_format($m / 1000, 1) . ' s). The fix is the Pulse store: a communications build.',
                'Staff wait about ' . number_format($m / 1000, 1) . ' s each time they open Pulse (the middle of its last ' . $n . ' opens; the limit is ' . number_format($lim / 1000, 1) . ' s). Nothing is stopped.',
                'The fix is a Pulse store (rows kept ready instead of gathered on each open): a communications build. The limit is in Thresholds & gates.',
                $m . ' ms usual, last ' . $n . ' opens', [['The limit', 'peek', '/admin/config/thresholds#gate-control_pulse_ms']], false, false);
            return 'Pulse slow';
        }
        if ($m !== null && $m <= $lim) ControlAlarms::clear($pdo, 'slow:site:pulse', 'Pulse gathers in ' . number_format($m / 1000, 1) . ' s again.');
        return '';
    }

    /** Check, on its row or alarm: the watch judges it now. [still failing, words]. */
    public static function checkOne(PDO $pdo, string $pid): array
    {
        if ($pid === 'site:payments') { try { require_once __DIR__ . '/SearchIndex.php'; SearchIndex::setState($pdo, 'control:qb_checked', '0'); } catch (Throwable $x) {} }   // Check it now: QuickBooks asked at once
        self::watch($pdo);
        require_once __DIR__ . '/ControlAlarms.php';
        foreach (ControlAlarms::ofProc($pdo, $pid) as $a) if ($a['level'] === 'trip' && $a['cleared_at'] === null)
            return [true, 'Still failing: ' . (string) $a['reading'] . (!empty($a['retrying_at']) ? ' The system keeps trying.' : ' Only Resolve clears it now.')];
        return [false, 'Working: ' . (self::PARTS[$pid][0] ?? $pid) . ' answered well (' . gmdate('H:i') . ' UTC).'];
    }

    /** The watch (every 5 minutes, ControlAlarms::tick): each part judged, raised or cleared. Returns what it did. */
    public static function watch(PDO $pdo): string
    {
        $did = [];
        try {
            self::ensure($pdo);
            require_once __DIR__ . '/ControlAlarms.php';
            $n0 = self::threshold($pdo); $at = gmdate('H:i') . ' UTC';
            $byPart = [];
            $st = $pdo->query('SELECT path, code, at FROM control_errors WHERE at >= UTC_TIMESTAMP() - INTERVAL ' . self::WINDOW . ' SECOND ORDER BY id DESC');
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $p = self::partOf((string) $r['path']); if ($p !== '') $byPart[$p][] = $r; }
            foreach (self::PARTS as $pid => [$name, $paths, $todo]) {
                $errs = $byPart[$pid] ?? []; $n = count($errs);
                [$pok, $pwords] = $pid === 'site:search' ? (self::$searchProbe ? (self::$searchProbe)() : self::probeSearch($pdo))
                    : ($pid === 'site:signin' ? (self::$signinProbe ? (self::$signinProbe)() : self::probeSignin($pdo)) : [null, '']);
                if ($pid === 'site:payments') {
                    [$ps, $pwords] = self::$payProbe ? (self::$payProbe)() : self::probePayments($pdo);
                    if ($ps === 'held') {   // refused or out: held is a trip at once (0171 §5)
                        ControlAlarms::raise($pdo, 'crit:site:payments:token', $pid, 'trip', 'held', 'QuickBooks needs reconnecting', 'Checkout can\'t take a card until it\'s connected again.', 'Press Connect QuickBooks again (beside this: its page, signed in to Intuit) and connect; then Check it now, which asks QuickBooks at once.', $pwords,
                            [['Connect QuickBooks again', 'peek', '/admin/quickbooks.php'], ['QuickBooks (Intuit)', 'link', 'https://qbo.intuit.com/', 'quickbooks'], ['Check it now', 'check', $pid]], false, false); $did[] = 'QuickBooks held';
                    } else ControlAlarms::clear($pdo, 'crit:site:payments:token', 'Connected again (' . $at . ').');
                    $pok = $ps === 'bad' ? false : ($ps === 'ok' ? true : null);
                }
                $paths0 = array_count_values(array_column($errs, 'path')); arsort($paths0);
                $worst = (string) (array_key_first($paths0) ?? $paths[0]);
                $reading = trim(($n ? $n . ' server error' . ($n === 1 ? '' : 's') . ' in 5 minutes (' . implode(', ', array_map(fn ($p, $c) => $p . ' ×' . $c, array_keys($paths0), $paths0)) . ')' : 'No server errors in 5 minutes') . ($pwords !== '' ? '. ' . $pwords : ''));
                $fix = [[$name . ': ' . $worst, 'peek', $worst . ($worst === '/q.php' ? '?q=Show+Low' : '')], ['Bluehost: the error log', 'link', 'https://my.bluehost.com/', 'bluehost']];
                if ($pid === 'site:payments') $fix[0] = ['QuickBooks\' connection', 'peek', '/admin/quickbooks.php'];
                if ($pok === false || $n >= $n0) {
                    ControlAlarms::raise($pdo, 'crit:' . $pid, $pid, 'trip', 'crash', $name . ' is failing',
                        ($pok === false ? 'Its test failed. ' : '') . ($n >= $n0 ? $n . ' requests got a server error in 5 minutes (' . $n0 . ' or more is a failure). ' : '') . 'Visitors can\'t ' . ['site:search' => 'search', 'site:signin' => 'sign in', 'site:payments' => 'pay'][$pid] . ' reliably.',
                        $todo, $reading, $fix, true, true);
                    $did[] = $name . ' failing';
                } else {
                    if (ControlAlarms::clear($pdo, 'crit:' . $pid, 'Answered well at ' . $at . ($pwords !== '' ? ': ' . $pwords : '.'))) $did[] = $name . ' good again';
                    if ($n > 0) {   // one visitor's odd request: kept on the part's row as evidence, never a trip
                        ControlAlarms::raise($pdo, 'crit:' . $pid . ':one', $pid, 'notice', 'crash', $name . ': ' . $n . ' server error' . ($n === 1 ? '' : 's') . ' (under the ' . $n0 . ' that make a failure)',
                            'Kept as evidence; it isn\'t a failure unless ' . $n0 . ' or more requests get one in 5 minutes, or its test fails.', $todo, $reading, $fix, true, false);
                    } else {
                        $rec = 0; try { $q = $pdo->prepare('SELECT COUNT(*) FROM control_errors WHERE at >= UTC_TIMESTAMP() - INTERVAL 1 HOUR AND path IN (' . implode(',', array_fill(0, count($paths), '?')) . ')'); $q->execute($paths); $rec = (int) $q->fetchColumn(); } catch (Throwable $x) {}
                        if (!$rec) ControlAlarms::clear($pdo, 'crit:' . $pid . ':one', 'No server errors in the last hour (' . $at . ').');
                    }
                }
            }
            $pw = self::pulseWatch($pdo); if ($pw !== '') $did[] = $pw;
            // 7 days kept (no visitor data in it: path and status only)
            $pdo->exec('DELETE FROM control_errors WHERE at < UTC_TIMESTAMP() - INTERVAL 7 DAY');
        } catch (Throwable $x) { error_log('ControlSensor::watch: ' . $x->getMessage()); }
        return implode(', ', $did);
    }
}
