<?php
// /api/client-order.php — the client paying an order our team built for them (decisions/0101), from its page
// (/order.php?t=…). POST {t, action: 'pay', token} with the card form's one-time token (the card went from the
// client's browser to Intuit, never here) and expect (the cents the page showed: refused if what's due differs) → {ok, status, due_cents}. POST {t, action: 'status'} → the same, no charge.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/ClientOrders.php';

Response::requireMethod('POST');
Response::requireCsrf();
$pdo = Database::connection();
$b = Response::jsonBody();
$o = ClientOrders::byToken($pdo, (string) ($b['t'] ?? ''));
if (!$o) Response::error('That order link doesn\'t work.', 404, 'not_found');
if (($b['action'] ?? '') === 'pay' && ClientOrders::staffView($pdo, $o)) Response::error(ClientOrders::STAFF_VIEW_MSG, 403, 'staff_view');
try {
    if (($b['action'] ?? '') === 'pay') $o = ClientOrders::pay($pdo, $o, (string) ($b['token'] ?? ''), isset($b['expect']) ? (int) $b['expect'] : null);   // the amount the page showed
    Response::success(['status' => $o['status'], 'due_cents' => ClientOrders::dueNow($pdo, $o)]);
} catch (PDOException $e) {
    error_log('client-order pay: ' . $e->getMessage());
    Response::error('Something went wrong on our side. If your card was charged, we\'ll see it and email you; don\'t pay again.', 500, 'server_error');
} catch (RuntimeException $e) {
    Response::error($e->getMessage(), 400, 'bad_request');
}
