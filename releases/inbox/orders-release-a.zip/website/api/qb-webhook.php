<?php
// /api/qb-webhook.php — QuickBooks tells us about payments, invoice changes, and refunds and credit memos made in
// QuickBooks (decisions/0095, 0098). Signed with the app's verifier token (intuit-signature), checked before anything is
// read. A paid order's codes are issued at once, and a client order's part payments are recorded as they arrive
// (QrIssue::checkPaid, decisions/0101 note of 2026-11-20, B.3); the buyer's own page also asks QuickBooks (QrIssue::refresh), so a
// missed webhook only delays, never loses, an order. A refund or credit memo is recorded on its order when there's only
// one it can be, or waits in E-Commerce → Orders for a person (Orders::fromQuickBooks); "Check QuickBooks" there
// catches any webhook that was missed.
declare(strict_types=1);

require_once __DIR__ . '/../../app/lib/Database.php';
require_once __DIR__ . '/../../app/lib/QrIssue.php';
require_once __DIR__ . '/../../app/lib/QuickBooksPay.php';
require_once __DIR__ . '/../../app/lib/Orders.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
$body = (string) file_get_contents('php://input');
try { $pdo = Database::connection(); } catch (Throwable $e) { error_log('qb webhook db: ' . $e->getMessage()); http_response_code(503); exit; }   // also loads .env (the verifier token)
$env = QuickBooksPay::verifyEnv($body, (string) ($_SERVER['HTTP_INTUIT_SIGNATURE'] ?? ''));
if ($env === '') { QuickBooksPay::logWebhook(false, []); http_response_code(401); exit; }
QuickBooksPay::useEnv($env);   // signed with the sandbox's token: it's about the sandbox company, whatever the switch says
$payload = json_decode($body, true);
http_response_code(200);   // QuickBooks wants a quick answer; the work below is short
$failed = 0;   // an order that couldn't be checked: the others still are, and QuickBooks is asked to send it again (500)
try {
    $ids = QuickBooksPay::invoicesIn($pdo, is_array($payload) ? $payload : []);
    QuickBooksPay::logWebhook(true, $ids, $ids ? '' : '(no invoices of ours)');
    if ($ids) {
        $st = $pdo->prepare("SELECT id FROM orders WHERE status = 'pending' AND invoice_id IN (" . implode(',', array_fill(0, count($ids), '?')) . ')');
        $st->execute($ids);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $oid) {   // a client order's part payments too (decisions/0101 note, 2026-11-20, B.3)
            try { QrIssue::checkPaid($pdo, (int) $oid); }
            catch (Throwable $e) { $failed++; error_log('qb webhook order ' . (int) $oid . ': ' . $e->getMessage()); }
        }
    }
} catch (Throwable $e) {
    $failed++; error_log('qb webhook: ' . $e->getMessage());
}
// refunds and credit memos made in QuickBooks
if (is_array($payload) && Orders::ready($pdo)) foreach (QuickBooksPay::refundsIn($payload) as [$entity, $id, $op]) {
    if ($op === 'Delete' || $op === 'Void') { QuickBooksPay::logNote("$entity $id $op: check its order by hand"); continue; }
    try {
        $r = Orders::fromQuickBooks($pdo, $entity, QuickBooksPay::fetch($pdo, $entity, $id));
        QuickBooksPay::logNote("$entity $id: $r");
    } catch (Throwable $e) { error_log("qb webhook $entity $id: " . $e->getMessage()); }
}
// any order that failed: QuickBooks sends the notice again later (its retry), and recording is safe to repeat (only what's new)
if ($failed > 0 && !headers_sent()) http_response_code(500);
