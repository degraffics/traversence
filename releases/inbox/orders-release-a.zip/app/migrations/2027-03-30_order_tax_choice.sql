-- decisions/0177 §2 (Jason, 2026-11-23): the order taker picks the order's sales tax (taxable, reseller, exempt, out of
-- state); an item can differ (its own Taxable). tax_note keeps the reseller or exemption certificate's words, or the
-- QuickBooks exemption item a pulled invoice carried ("504 Interstate Commerce"). Safe to run twice.
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE orders ADD COLUMN tax_choice VARCHAR(16) NOT NULL DEFAULT ''taxable''', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'tax_choice');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE orders ADD COLUMN tax_note VARCHAR(200) NOT NULL DEFAULT ''''', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'tax_note');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
