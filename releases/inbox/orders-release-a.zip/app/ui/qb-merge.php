<?php
// app/ui/qb-merge.php — the order page's QuickBooks invoice section (decisions/0128, step 3): an order that refers to a
// QuickBooks invoice by number is merged with it (its lines, tax and payments), and a linked one is refreshed from it.
// QuickBooks is asked only when you open it (?qbmerge=NNN), never on every page view. The form posts do=qb_merge to the
// order page, which calls QbPull::merge().
declare(strict_types=1);

function tv_qb_merge_box(PDO $pdo, array $o, string $hidden): string
{
    require_once __DIR__ . '/../lib/QbPull.php';
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES); $usd = fn ($c) => Orders::usd((int) $c);
    $oid = (int) $o['id']; $linked = !empty($o['invoice_id']); $no = trim((string) ($o['invoice_no'] ?? ''));
    $ask = trim((string) ($_GET['qbmerge'] ?? ''));
    if ($ask !== '' && !preg_match('/^[A-Za-z0-9-]{1,40}$/', $ask)) $ask = '';
    if ($no === '' && $ask === '') return '';
    if ($ask === '' || ($linked && $ask !== $no)) $ask = '';
    [$can, $why] = Access::can('backoffice.orders.pull', ['min' => 'manager', 'depts' => ['fin', 'ops']]);
    $h = '<h2 class="hb-h" id="qbmerge">QuickBooks invoice ' . $e($no ?: $ask) . '</h2><div class="hb-card tv-bleed">';
    if ($ask === '') {   // closed: say what it would do, open it on a tap
        return $h . '<p data-tv-status="info" data-tv-label="' . ($linked ? 'Linked:' : 'Not merged:') . '">' . ($linked
                ? 'This order is linked to QuickBooks invoice ' . $e($no) . '. If the invoice was changed in QuickBooks, refresh the order from it: its lines, tax and payments.'
                : 'This order refers to QuickBooks invoice ' . $e($no) . ' made by hand, so the two can differ. Merge them: the order takes the invoice\'s lines, prices, tax and payments, and keeps its proofs, files and work orders.')
            . '</p><a class="hb-b go" href="?qbmerge=' . rawurlencode($no) . '#qbmerge">' . ($linked ? 'Check it against the invoice' : 'Show what merging does') . '</a></div>';
    }
    try { $pl = QbPull::mergePlan($pdo, $ask, $oid); }
    catch (Throwable $x) { return $h . '<p data-tv-status="bad" data-tv-label="Can\'t merge:">' . $e($x instanceof RuntimeException ? $x->getMessage() : 'QuickBooks didn\'t answer: try again.') . '</p></div>'; }
    $inv = $pl['inv']; $paid = $inv['total'] > 0 && $inv['balance'] <= 0;
    $here = array_column($pl['lines_here'], null, 'id');
    $products = []; foreach (Products::all($pdo) as $p) $products[(int) $p['id']] = (string) $p['name'];
    $h .= '<style>.qbm-l{border-top:1px solid #EADFC4;padding:.45rem 0;display:grid;grid-template-columns:1fr auto;gap:.15rem .6rem}.qbm-l small{color:#8A7355;display:block}.qbm-l .amt{text-align:right;font-weight:700;white-space:nowrap}.qbm-l .was{color:#8A7355;font-weight:400;text-decoration:line-through;margin-right:.3rem}'
        . '.qbm-tag{display:inline-block;font-size:.72rem;font-weight:700;padding:.03rem .45rem;border-radius:999px;margin-right:.3rem;background:#F3EAD6;color:#5C4632}.qbm-tag.add{background:#DCEFE5;color:#1F3A2E}.qbm-tag.drop{background:#F8DAD5;color:#7F1D1D}'
        . '.qbm-dec{display:grid;gap:.3rem;margin:.4rem 0}.qbm-dec label{display:grid;gap:.15rem;font-size:.86rem;color:#5C4632}.qbm-keep{display:flex;gap:.35rem;align-items:center;font-size:.86rem;color:#5C4632;margin-top:.2rem}</style>';
    $h .= '<p data-tv-status="' . ($paid ? 'ok' : 'info') . '" data-tv-label="' . ($paid ? 'Paid in QuickBooks:' : 'Open in QuickBooks:') . '">' . $e($inv['company'] ?: $inv['person']) . ' · ' . $usd($inv['total']) . ' with ' . $usd($inv['tax']) . ' tax'
        . ($paid ? '. The payment rules: the order is rebuilt to match the invoice exactly' . ($inv['paid'] > $pl['paid_here'] ? ', and ' . $usd($inv['paid'] - $pl['paid_here']) . ' paid in QuickBooks is recorded here' : '') . '.'
                 : ($inv['paid'] ? ', ' . $usd($inv['paid']) . ' paid, ' . $usd($inv['balance']) . ' left.' : ', not paid yet.')) . '</p>';
    if ($pl['gap'] !== 0) $h .= '<p data-tv-status="' . ($pl['gap'] > 0 ? 'bad' : 'info') . '" data-tv-label="Price gap:">The order here is ' . $usd((int) $pl['order']['total_cents']) . ', ' . $usd(abs($pl['gap'])) . ' ' . ($pl['gap'] > 0 ? 'under' : 'over') . ' the invoice.'
        . ($pl['gap'] > 0 ? ' Merging notes it so the products\' prices can be fixed for next time.' : ($paid ? ' The invoice is what was agreed and paid.' : '')) . '</p>';
    $f = '<form method="post" action="#qbmerge">' . $hidden . '<input type="hidden" name="invoice" value="' . $e($inv['no']) . '"><h4 style="margin:.6rem 0 .1rem">What changes</h4>';
    $open = []; $byI = array_column($pl['lines'], null, 'i');
    foreach ($pl['groups'] as $lid => $set) {   // one line here that the invoice splits into versions
        $cur = $here[$lid]; $was = (int) $cur['unit_cents'] * max(1, (int) $cur['qty']); $now = array_sum(array_map(fn ($i) => (int) $byI[$i]['amount'], $set));
        foreach ($set as $i) if ($byI[$i]['kind'] === 'open') $open[$byI[$i]['item'][0]] = $byI[$i]['item'][1];
        $f .= '<div class="qbm-l"><div><span class="qbm-tag">' . ($was === $now ? 'Same' : 'Updates') . '</span>' . $e($cur['title'])
            . '<small>On the invoice as ' . count($set) . ' lines: ' . $e(implode('; ', array_map(fn ($i) => $byI[$i]['head'] . ' · ' . number_format((float) $byI[$i]['qty']) . ' · ' . $usd($byI[$i]['amount']), $set))) . '. They stay one line here, so its proofs, files and work order stay with it.</small></div>'
            . '<div class="amt">' . ($was !== $now ? '<span class="was">' . $usd($was) . '</span>' : '') . $usd($now) . '</div></div>';
    }
    foreach ($pl['lines'] as $l) {
        if ($l['kind'] === 'open') $open[$l['item'][0]] = $l['item'][1];
        $lid = (int) $pl['pairs'][$l['i']]; if ($lid && isset($pl['groups'][$lid])) continue;
        $cur = $here[$lid] ?? null; $was = $cur ? (int) $cur['unit_cents'] * max(1, (int) $cur['qty']) : null;
        $kind = $l['kind'] === 'product' ? ($products[$l['product']] ?? '') : ($l['kind'] === 'charge' ? 'a charge' : ($l['kind'] === 'tax' ? 'a tax exemption: the order is exempt' : ($l['kind'] === 'leave' ? 'kept as written' : 'item not mapped yet: decide below')));
        $f .= '<div class="qbm-l"><div>' . ($cur ? '<span class="qbm-tag">' . ($was === $l['amount'] ? 'Same' : 'Updates') . '</span>' . $e($cur['title']) : '<span class="qbm-tag add">Adds</span>' . $e($l['head']) . ($l['qty'] > 1 ? ' · ' . $e(number_format($l['qty'])) : ''))
            . '<small>Invoice: ' . $e($l['head']) . ($l['qty'] > 1 ? ' · ' . $e(number_format($l['qty'])) : '') . ' · "' . $e($l['item'][1]) . '", ' . $e($kind) . ($l['taxable'] ? ' · taxed' : '') . '</small></div>'
            . '<div class="amt">' . ($cur && $was !== $l['amount'] ? '<span class="was">' . $usd($was) . '</span>' : '') . $usd($l['amount']) . '</div></div>';
    }
    foreach ($pl['only'] as $ol) {
        $amt = (int) $ol['unit_cents'] * max(1, (int) $ol['qty']);
        $f .= '<div class="qbm-l"><div><span class="qbm-tag drop">' . ($paid ? 'Drops' : 'Not on the invoice') . '</span>' . $e($ol['title'])
            . ($paid ? '<small>The invoice is paid without it: it comes off the order (kept in the history).</small>'
                     : '<label class="qbm-keep"><input type="checkbox" name="keep[' . (int) $ol['id'] . ']" value="1"' . (!empty($o['invoice_id']) ? ' checked' : '') . '> Keep it on the order (add it in QuickBooks too, then refresh). Not ticked, it comes off.</label>')
            . '</div><div class="amt">' . $usd($amt) . '</div></div>';
    }
    if ($open) {
        $f .= '<h4 style="margin:.6rem 0 .1rem">Items to map first</h4><p class="ak-note" style="margin:0;font-size:.84rem;color:#8A7355">Decided once for each QuickBooks item and remembered (Back-Office → QuickBooks items).</p><div class="qbm-dec">';
        foreach ($open as $ref => $name) {
            $o2 = QbPull::itemChoices($products, (string) $name);
            $f .= '<label>"' . $e((string) $name) . '"<select class="hb-in" name="item[' . $e((string) $ref) . ']" required>' . $o2 . '</select></label>';
        }
        $f .= '</div>';
    }
    $f .= '<p style="font-size:.84rem;color:#8A7355;margin:.5rem 0">Updated lines keep their proofs, files and work orders. Nothing is written to QuickBooks.</p>'
        . '<div style="display:flex;flex-wrap:wrap;gap:.4rem;align-items:center"><button class="hb-b go" data-confirm="' . $e(($linked ? 'Refresh this order from' : 'Merge this order with') . ' invoice ' . $inv['no'] . '? The order takes its lines, prices and tax' . ($paid ? ' and its payment' : '') . '.') . '" data-yes="' . ($linked ? 'Refresh it' : 'Merge them') . '"'
        . ($can ? '' : ' disabled title="' . $e($why) . '"') . '>' . ($linked ? 'Refresh from the invoice' : 'Merge into this order') . '</button><a href="?#qbmerge" style="font-size:.86rem">Not now</a></div></form>';
    return $h . $f . '</div>';
}
