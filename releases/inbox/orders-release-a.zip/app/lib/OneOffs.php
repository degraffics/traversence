<?php
// app/lib/OneOffs.php — one-off purchases (decisions/0154 §5): keep a single video in 4K ($0.99), without a plan. In the
// one cart (cart_plans, owner_type 'media'), paid with the cart's card entry (one more one-time token): an order of its
// own (orders + order_lines), the card charged on it (QuickBooksPay::chargeCard, which refuses real money for a test),
// a Sales Receipt in the books like a plan's (no invoice: nothing to ship, nothing to tax by address), and then what was
// bought happens. A test account pays in the sandbox only (decisions/0145). GO Codes' checkout is untouched.
declare(strict_types=1);

final class OneOffs
{
    /** kind => [name, cents] */
    public const KINDS = ['keep_4k' => ['Keep a video in 4K', 99], 'pro_month' => ['A month of Personal Pro', 995]];   // pro_month: Billing::oneMonth, nothing renews

    /** Can this member buy Keep in 4K for this video? '' when yes, else why not. */
    public static function keep4kWhyNot(PDO $pdo, int $uid, int $mediaId): string
    {
        require_once __DIR__ . '/MemberPosts.php';
        $m = MemberPosts::media($pdo, $mediaId);
        if (!$m || $m['kind'] !== 'video' || ($m['owner_kind'] ?? 'members') !== 'members' || (int) $m['user_id'] !== $uid) return 'That isn\'t one of your videos.';
        if ((int) ($m['keep_hd'] ?? 0)) return 'That video already keeps its original.';
        if (MemberPosts::hdAllowed($pdo, $m)) return 'Your plan keeps originals already.';
        if (min((int) $m['width'], (int) $m['height']) <= 720) return 'That video is 720p already: there\'s nothing bigger to keep.';
        $p = $m['post_id'] ? MemberPosts::get($pdo, (int) $m['post_id']) : null;
        if (!$p || MemberPosts::ended($p)) return 'That post has ended.';
        if ($p['kept_at'] !== null) return 'That post is kept already, at your plan\'s size.';
        return '';
    }

    /** Why this line can't be bought now ('' when it can). */
    public static function whyNot(PDO $pdo, int $uid, string $item, int $ref): string
    {
        if ($item === 'pro_month') { require_once __DIR__ . '/Billing.php'; return Billing::oneMonthWhyNot($pdo, $uid); }
        return self::keep4kWhyNot($pdo, $uid, $ref);
    }

    /** A single month of Personal Pro into the one cart (once: another goes on top after paying). */
    public static function addProMonth(PDO $pdo, int $uid): void
    {
        if (($why = self::whyNot($pdo, $uid, 'pro_month', $uid)) !== '') throw new InvalidArgumentException($why);
        $pdo->prepare("INSERT IGNORE INTO cart_plans (user_id, owner_type, owner_id, item, qty, cycle, created_at) VALUES (?, 'oneoff', ?, 'pro_month', 1, 'once', ?)")->execute([$uid, $uid, date('Y-m-d H:i:s')]);
    }

    public static function addKeep4k(PDO $pdo, int $uid, int $mediaId): void
    {
        if (($why = self::keep4kWhyNot($pdo, $uid, $mediaId)) !== '') throw new InvalidArgumentException($why);
        $pdo->prepare("INSERT IGNORE INTO cart_plans (user_id, owner_type, owner_id, item, qty, cycle, created_at) VALUES (?, 'media', ?, 'keep_4k', 1, 'once', ?)")->execute([$uid, $mediaId, date('Y-m-d H:i:s')]);
    }

    /** Pays the member's one-off lines with one card token, as one order. Returns the order id. */
    public static function pay(PDO $pdo, int $uid, array $lines, string $token): int
    {
        require_once __DIR__ . '/QuickBooksPay.php'; require_once __DIR__ . '/Orders.php'; require_once __DIR__ . '/TestAccounts.php'; require_once __DIR__ . '/MemberPosts.php';
        if (!preg_match('/^[A-Za-z0-9_.:-]{6,300}$/', $token)) throw new RuntimeException('The card details didn\'t come through. Nothing was charged. Try again.');
        foreach ($lines as $l) if (($why = self::whyNot($pdo, $uid, (string) $l['item'], (int) $l['ref'])) !== '') throw new InvalidArgumentException($why);
        if ($u0 = Orders::cardUnknown($pdo, $uid)) throw new RuntimeException(Orders::cardUnknownWords($u0));   // a charge that got no answer waits first (the survey, #9)
        $st = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ?'); $st->execute([$uid]); $u = $st->fetch(PDO::FETCH_ASSOC) ?: ['email' => '', 'display_name' => ''];
        $total = array_sum(array_map(fn ($l) => (int) $l['cents'], $lines));
        $test = TestAccounts::isTestUser($pdo, $uid);
        if ($test) QuickBooksPay::useEnv('sandbox');   // a test account pays in the sandbox only (decisions/0145 §3)
        try {
            $pdo->prepare("INSERT INTO orders (status, user_id, access_token, items, subtotal_cents, total_cents, bill_name, bill_email, approved_at) VALUES ('pending', ?, ?, ?, ?, ?, ?, ?, NOW())")
                ->execute([$uid, bin2hex(random_bytes(20)), count($lines), $total, $total, (string) ($u['display_name'] ?: $u['email']), (string) $u['email']]);
            $oid = (int) $pdo->lastInsertId();
            try { $pdo->prepare('UPDATE orders SET qb_env = ? WHERE id = ?')->execute([QuickBooksPay::env(), $oid]); } catch (Throwable) {}
            $ln = $pdo->prepare('INSERT INTO order_lines (order_id, product, ref_id, title, qty, unit_cents, approved_at) VALUES (?, ?, ?, ?, 1, ?, NOW())');
            foreach ($lines as $l) $ln->execute([$oid, (string) $l['item'], (int) $l['ref'], (string) $l['name'], (int) $l['cents']]);
            Orders::number($pdo, $oid);
            $row = Orders::get($pdo, $oid);
            try { $charge = QuickBooksPay::chargeCard($pdo, $row, $token, 'oneoff-' . $oid, $total); }
            catch (Throwable $e) {
                if (Orders::unanswered($e)) {   // no answer: it may have been charged, so the order stays and our team settles it
                    Orders::event($pdo, $oid, 'card_unknown', 'The card got no answer from QuickBooks Payments (' . mb_substr($e->getMessage(), 0, 160) . '): check whether it was charged, then mark it paid or void it.');
                    throw new RuntimeException(Orders::cardUnknownWords(Orders::get($pdo, $oid) ?: ['id' => $oid]));
                }
                $pdo->prepare("UPDATE orders SET status = 'void', note = ? WHERE id = ?")->execute([mb_substr('card: ' . $e->getMessage(), 0, 300), $oid]);
                $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE order_id = ?")->execute([$oid]);
                throw $e;
            }
            // the card is charged: from here on nothing may stop what was bought
            $pdo->prepare("UPDATE orders SET status = 'paid', paid_at = NOW() WHERE id = ?")->execute([$oid]);
            try { $pdo->prepare('UPDATE orders SET charge_id = ? WHERE id = ?')->execute([$charge, $oid]); } catch (Throwable) {}
            $pdo->prepare("UPDATE order_lines SET status = 'done' WHERE order_id = ?")->execute([$oid]);
            $kept = true; $month = null;
            foreach ($lines as $l) if ($l['item'] === 'pro_month') {
                require_once __DIR__ . '/Billing.php';
                try { $month = Billing::oneMonth($pdo, $uid); }
                catch (Throwable $x) { Orders::event($pdo, $oid, 'needs_attention', 'Paid for a month of Pro, but it didn\'t start (' . mb_substr($x->getMessage(), 0, 160) . '): start it by hand, or refund.'); }
            }
            foreach ($lines as $l) if ($l['item'] === 'keep_4k') {
                $pdo->prepare('UPDATE member_post_media SET keep_hd = 1 WHERE id = ?')->execute([(int) $l['ref']]);
                $m = MemberPosts::media($pdo, (int) $l['ref']);
                if ($m && $m['post_id']) { try { MemberPosts::keep($pdo, $uid, (int) $m['post_id']); } catch (Throwable $x) { $kept = false; Orders::event($pdo, $oid, 'note', 'Bought; Keep didn\'t go through (' . mb_substr($x->getMessage(), 0, 160) . '): the member keeps it from the post.'); } }
            }
            $warn = '';
            try { QuickBooksPay::salesReceipt($pdo, $uid, ['name' => (string) ($u['display_name'] ?: $u['email']), 'email' => (string) $u['email']], array_map(fn ($l) => [(string) $l['name'], (int) $l['cents']], $lines), $charge, 'oneoff-' . $oid); }
            catch (Throwable $x) { $warn = 'The card was charged (' . $charge . ') but QuickBooks didn\'t take the sales receipt (' . $x->getMessage() . '): add it there.'; }
            Orders::record($pdo, $oid, 'charge', $total, 'charge-' . $oid, 'card', '', 'card ' . $charge);
            Orders::event($pdo, $oid, 'paid', 'Paid ' . Orders::usd($total) . ' by card: ' . implode(', ', array_map(fn ($l) => (string) $l['name'], $lines)), $uid);
            if ($warn !== '') Orders::event($pdo, $oid, 'needs_books', $warn);
        } finally { if ($test) QuickBooksPay::useEnv(null); }
        try {
            require_once __DIR__ . '/Mailer.php';
            if ((string) $u['email'] !== '') Mailer::send((string) $u['email'], 'Your Traversence receipt: ' . Orders::usd($total), "Thank you. Here's your receipt:\n\n"
                . implode("\n", array_map(fn ($l) => '  ' . $l['name'] . ': ' . Orders::usd((int) $l['cents']), $lines)) . "\n\n  Total charged to your card: " . Orders::usd($total)
                . "\n\n" . (in_array('keep_4k', array_column($lines, 'item'), true) ? ($kept ? "Your video keeps its original size, and its post is kept on your profile.\n" : "Your video keeps its original size: tap Keep on its post (before it ends) to keep it on your profile.\n") : '')
                . ($month ? 'Personal Pro is yours until ' . date('F j, Y', strtotime((string) $month['period_end'])) . ". Nothing renews: it goes back to the free plan on its own.\n" : ''));
        } catch (Throwable $x) { error_log('oneoff receipt: ' . $x->getMessage()); }
        return $oid;
    }
}
