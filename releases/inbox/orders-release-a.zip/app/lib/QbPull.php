<?php
// app/lib/QbPull.php — a QuickBooks invoice into a Traversence order (decisions/0128, step 2): an order that started in
// QuickBooks. The invoice is the source of every number (lines, prices, tax, total, payments); we fill in what the site
// needs to process it, and from then on the site tracks it, keeps its history and offers it again as reorders. Read
// only in QuickBooks: a payment made there is recorded here, never posted back. preview() shows it first; pull() reads
// the invoice again (never trusting the page) and builds the order.
declare(strict_types=1);

require_once __DIR__ . '/Books.php';
require_once __DIR__ . '/ClientOrders.php';
require_once __DIR__ . '/Products.php';
require_once __DIR__ . '/Clients.php';

final class QbPull
{
    /**
     * What pulling invoice $no would do: ['inv' => summary, 'lines' => [...], 'client' => [...], 'existing' => order|null,
     * 'refers' => [orders that only refer to it]], or throws when it can't be read. Each line: i, kind (product | charge
     * | open), item [ref, name], title, note, qty, amount (cents), taxable, products (tagged ids), product (chosen id).
     */
    public static function preview(PDO $pdo, string $no): array
    {
        $no = trim(preg_replace('/^#/', '', $no));
        if ($no === '') throw new RuntimeException('Enter the invoice number.');
        $got = QuickBooksPay::invoiceByNumber($pdo, $no);
        if (!$got) throw new RuntimeException('QuickBooks (' . Books::env() . ') has no invoice ' . $no . '.');
        $inv = $got['invoice']; $cust = $got['customer']; $env = Books::env();
        $tax = (int) round(((float) ($inv['TxnTaxDetail']['TotalTax'] ?? 0)) * 100);
        $total = (int) round(((float) ($inv['TotalAmt'] ?? 0)) * 100);
        $balance = (int) round(((float) ($inv['Balance'] ?? 0)) * 100);
        $paid = max(0, $total - $balance);
        $email = strtolower(trim((string) ($inv['BillEmail']['Address'] ?? ($cust['PrimaryEmailAddr']['Address'] ?? ''))));
        $company = trim((string) ($cust['CompanyName'] ?? '')) ?: trim((string) ($inv['CustomerRef']['name'] ?? ''));
        $person = trim(((string) ($cust['GivenName'] ?? '')) . ' ' . ((string) ($cust['FamilyName'] ?? ''))) ?: (string) ($cust['DisplayName'] ?? $company);
        $addr = function (array $a): array {   // QuickBooks keeps name lines above the street: the street is the line before the city
            $ls = array_values(array_filter([$a['Line1'] ?? '', $a['Line2'] ?? '', $a['Line3'] ?? '', $a['Line4'] ?? ''], fn ($l) => trim((string) $l) !== ''));
            $street = (string) (end($ls) ?: ''); $names = array_slice($ls, 0, max(0, count($ls) - 1));
            return ['name' => (string) ($names[0] ?? ''), 'street' => $street, 'city' => (string) ($a['City'] ?? ''), 'state' => strtoupper((string) ($a['CountrySubDivisionCode'] ?? '')), 'zip' => (string) ($a['PostalCode'] ?? '')];
        };
        $sum = [
            'id' => (string) $inv['Id'], 'no' => (string) ($inv['DocNumber'] ?? $no), 'date' => (string) ($inv['TxnDate'] ?? ''), 'due' => (string) ($inv['DueDate'] ?? ''),
            'tax' => $tax, 'total' => $total, 'paid' => $paid, 'balance' => $balance, 'payments' => $got['payments'],
            'customer' => (string) ($inv['CustomerRef']['value'] ?? ''), 'company' => $company, 'person' => $person, 'email' => $email,
            'phone' => (string) ($cust['PrimaryPhone']['FreeFormNumber'] ?? ''), 'bill' => $addr((array) ($inv['BillAddr'] ?? [])), 'ship' => $addr((array) ($inv['ShipAddr'] ?? [])),
        ];
        // lines: each through its item's tags
        $lines = []; $i = 0;
        $prods = []; foreach (Products::all($pdo) as $p) $prods[(int) $p['id']] = (string) $p['name'];
        foreach ((array) ($inv['Line'] ?? []) as $l) {
            $type = (string) ($l['DetailType'] ?? '');
            if (!in_array($type, ['SalesItemLineDetail', 'DiscountLineDetail'], true)) continue;
            $d = (array) ($l[$type] ?? []);
            $amount = (int) round(((float) ($l['Amount'] ?? 0)) * 100) * ($type === 'DiscountLineDetail' ? -1 : 1);
            $ref = (string) ($d['ItemRef']['value'] ?? ''); $iname = (string) ($d['ItemRef']['name'] ?? ($type === 'DiscountLineDetail' ? 'Discount' : 'Item'));
            $desc = trim((string) ($l['Description'] ?? ''));
            $first = trim((string) strtok($desc, "\n"));
            $head = $first !== '' && mb_strlen($first) <= 80 && !str_contains($first, ':') ? $first : $iname;   // "$25 Gift Certificates" says more than the item
            $note = trim($head === $first ? (string) substr($desc, strlen($first)) : $desc);
            $qty = (float) ($d['Qty'] ?? 1);
            $line = ['i' => $i++, 'item' => [$ref, $iname], 'head' => $head, 'note' => $note, 'qty' => $qty > 0 ? $qty : 1, 'amount' => $amount,
                     'taxable' => ($d['TaxCodeRef']['value'] ?? '') === 'TAX', 'products' => [], 'product' => 0, 'kind' => 'open'];
            if ($type === 'DiscountLineDetail' || $ref === '') { $line['kind'] = 'charge'; $lines[] = $line; continue; }
            Books::stageItem($pdo, $ref, $iname, $desc, isset($d['UnitPrice']) ? (float) $d['UnitPrice'] : null, $line['taxable']);
            $st = Books::itemState($pdo, $ref);
            $line['products'] = $st['products'];
            if ($st['role'] === 'charge') $line['kind'] = 'charge';
            elseif ($st['role'] === 'tax') $line['kind'] = 'tax';   // it only marks a tax exemption ("504 Interstate Commerce")
            elseif ($st['role'] === 'leave') $line['kind'] = 'leave';   // kept as written: not a product, not a reorder item
            elseif ($st['products']) {
                $line['kind'] = 'product';
                $best = $st['products'][0]; $bestPct = -1;   // a general item tagged to several products: the one its words fit best
                if (count($st['products']) > 1) foreach ($st['products'] as $pid) { similar_text(strtolower($prods[$pid] ?? ''), strtolower($head . ' ' . $desc), $pct); if ($pct > $bestPct) { $bestPct = $pct; $best = $pid; } }
                $line['product'] = $best;
            }
            $lines[] = $line;
        }
        // the client: tagged customer first, else what the Clients tool would find
        $client = ['tagged' => null, 'found' => []];
        if (Clients::ready($pdo)) {
            if ($sum['customer'] !== '') { $t = SystemTags::things($pdo, 'qbo.customer', $env, $sum['customer']); if ($t) $client['tagged'] = Clients::get($pdo, $t[0]); }
            if (!$client['tagged']) foreach (array_filter([$company, $sum['phone']]) as $q) foreach (Clients::find($pdo, $q, $email) as $f) $client['found'][$f['id']] ??= $f;
            $client['found'] = array_values($client['found']);
        }
        // already here?
        $existing = null;
        $t = SystemTags::things($pdo, 'qbo.invoice', $env, $sum['id']);
        if ($t) $existing = Orders::get($pdo, $t[0]);
        if (!$existing) { $st = $pdo->prepare('SELECT * FROM orders WHERE invoice_id = ? AND qb_env = ? LIMIT 1'); $st->execute([$sum['id'], $env]); $existing = $st->fetch(PDO::FETCH_ASSOC) ?: null; }
        $st = $pdo->prepare("SELECT * FROM orders WHERE invoice_no = ? AND (invoice_id IS NULL OR invoice_id = '') AND status NOT IN ('void') ORDER BY id"); $st->execute([$sum['no']]);
        return ['inv' => $sum, 'lines' => $lines, 'client' => $client, 'existing' => $existing, 'refers' => $st->fetchAll(PDO::FETCH_ASSOC)];
    }

    /**
     * Builds the order from invoice $no. $in: email (when QuickBooks has none), client ('auto' | listing id | 'person'),
     * item[ref] for each QuickBooks item not mapped yet ('p:<product id>' | 'make' | 'charge'; once per item, however
     * many lines use it, and remembered for later invoices), pick[i] to choose among a general item's products for a
     * line. Returns the new order's id.
     */
    public static function pull(PDO $pdo, string $no, array $in, int $uid): int
    {
        $pv = self::preview($pdo, $no); $inv = $pv['inv']; $env = Books::env();
        if ($pv['existing']) throw new RuntimeException('Invoice ' . $inv['no'] . ' is already order #' . Orders::no($pv['existing']) . '.');
        if ($pv['refers']) throw new RuntimeException('Order #' . Orders::no($pv['refers'][0]) . ' already refers to invoice ' . $inv['no'] . ': merge them (the next step) rather than make a second order.');
        $email = strtolower(trim((string) ($in['email'] ?? ''))) ?: $inv['email'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('QuickBooks has no email for this customer: add the client\'s email.');
        // settle each undecided line first (remembered for every later invoice)
        $done = [];
        foreach ($pv['lines'] as $l) {
            if ($l['kind'] !== 'open' || isset($done[$l['item'][0]])) continue;
            $done[$l['item'][0]] = true;
            self::decideItem($pdo, $l, (string) ($in['item'][$l['item'][0]] ?? ''), $uid);
        }
        $pv = self::preview($pdo, $no);   // again, with the decisions
        foreach ($pv['lines'] as $l) if ($l['kind'] === 'open') throw new RuntimeException('"' . $l['item'][1] . '" still needs deciding.');

        $pdo->beginTransaction();
        try {
            $oid = ClientOrders::create($pdo, $uid, ['name' => $inv['person'] ?: $inv['company'], 'email' => $email, 'company' => $inv['company'], 'phone' => $inv['phone']]);
            $sub = 0; $n = 0;
            foreach ($pv['lines'] as $l) {
                $pick = (int) ($in['pick'][$l['i']] ?? 0);
                $pid = $l['kind'] === 'product' ? (in_array($pick, $l['products'], true) ? $pick : (int) $l['product']) : 0;
                if (!self::insertLine($pdo, $oid, $l, $pid)) continue;   // an exemption marker with no amount: no line
                $sub += $l['amount']; $n++;
            }
            $b = $inv['bill']; $s = $inv['ship']; $full = $inv['total'] > 0 && $inv['balance'] <= 0;
            $pdo->prepare("UPDATE orders SET status = 'pending', approved_at = ?, approved_name = ?, sent_at = ?, invoice_id = ?, invoice_no = ?, qb_customer_id = ?, qb_env = ?, pay_mode = 'invoice',
                           items = ?, subtotal_cents = ?, tax_cents = ?, total_cents = ?, due_date = ?, bill_street = ?, bill_city = ?, bill_state = ?, bill_zip = ?,
                           ship_name = ?, ship_street = ?, ship_city = ?, ship_state = ?, ship_zip = ?, stage = '' WHERE id = ?")
                ->execute([($inv['date'] ?: date('Y-m-d')) . ' 12:00:00', 'QuickBooks invoice ' . $inv['no'], ($inv['date'] ?: date('Y-m-d')) . ' 12:00:00', $inv['id'], $inv['no'], $inv['customer'], $env,
                           $n, $sub, $inv['tax'], $inv['total'], $inv['due'] ?: null, $b['street'], $b['city'], $b['state'], $b['zip'],
                           $s['name'] ?: ($inv['company'] ?: $inv['person']), $s['street'], $s['city'], $s['state'], $s['zip'], $oid]);
            if ($inv['total'] !== $sub + $inv['tax']) Orders::event($pdo, $oid, 'pulled_note', 'QuickBooks\' total ' . Orders::usd($inv['total']) . ' differs from its lines plus tax (' . Orders::usd($sub + $inv['tax']) . '): its total is kept.', $uid);
            // payments made in QuickBooks: recorded here, never posted back
            foreach ($inv['payments'] ?: ($inv['paid'] > 0 ? [['id' => 'paid', 'date' => '', 'cents' => $inv['paid']]] : []) as $p) {
                if ($p['cents'] <= 0) continue;
                $left = $inv['total'] - Orders::money($pdo, $oid)['paid'];
                Orders::record($pdo, $oid, $p['cents'] >= $left ? 'charge' : 'deposit', min($p['cents'], max(1, $left)), 'qbpull-' . $env . '-' . $inv['id'] . '-' . $p['id'], 'quickbooks', $inv['no'], 'Paid in QuickBooks' . ($p['date'] !== '' ? ' ' . date('M j, Y', strtotime($p['date'])) : '') . ' (pulled from the invoice)', $uid);
            }
            if ($full) $pdo->prepare("UPDATE orders SET status = 'paid', paid_at = COALESCE(paid_at, ?) WHERE id = ?")->execute([($inv['payments'] ? max(array_column($inv['payments'], 'date')) : date('Y-m-d')) . ' 12:00:00', $oid]);
            self::exemptFrom($pdo, $oid, $pv['lines']);
            SystemTags::set($pdo, 'qbo.invoice', $oid, $env, $inv['id'], 'Invoice ' . $inv['no'], $uid, 'pulled');
            $pdo->commit();
        } catch (Throwable $x) { $pdo->rollBack(); throw $x; }

        // the client's business, and its QuickBooks customer tag
        $o = Orders::get($pdo, $oid); $c = (string) ($in['client'] ?? 'auto');
        try {
            if ($pv['client']['tagged']) Clients::attachOrder($pdo, $oid, (int) $pv['client']['tagged']['id'], $uid);
            elseif ($c === 'person') Clients::attachOrder($pdo, $oid, 0, $uid);
            elseif (ctype_digit($c) && (int) $c > 0) Clients::attachOrder($pdo, $oid, (int) $c, $uid);
            elseif (Clients::ready($pdo)) Clients::autoConnect($pdo, $o, $uid);
            $lid = (int) (Orders::get($pdo, $oid)['listing_id'] ?? 0);
            if ($lid > 0 && $inv['customer'] !== '') {
                SystemTags::set($pdo, 'qbo.customer', $lid, $env, $inv['customer'], $inv['company'] ?: $inv['person'], $uid, 'from invoice ' . $inv['no']);
                $pdo->prepare('UPDATE client_listings SET qb_customer_id = ? WHERE entity_id = ?')->execute([$inv['customer'], $lid]);
            }
        } catch (Throwable $x) { error_log('qb pull client: ' . $x->getMessage()); }
        $setup = Books::snapshot($pdo);
        Orders::event($pdo, $oid, 'pulled', 'Pulled from QuickBooks invoice ' . $inv['no'] . ': ' . $n . ' line' . ($n === 1 ? '' : 's') . ', ' . Orders::usd($inv['total']) . ($inv['tax'] ? ' with ' . Orders::usd($inv['tax']) . ' tax' : '') . ', ' . ($full ? 'paid' : ($inv['paid'] ? Orders::usd($inv['paid']) . ' paid' : 'not paid')) . '. Set up: books ' . $setup['books'] . ', tax ' . $setup['tax'] . ', history ' . $setup['history'] . '.', $uid);
        // reorder items: each product line, art or not (its files are added when they come)
        try { require_once __DIR__ . '/Collateral.php'; Collateral::fromOrder($pdo, $oid, true); } catch (Throwable $x) { error_log('qb pull collateral: ' . $x->getMessage()); }
        return $oid;
    }

    // ---- step 3: an invoice into an order that's already here (decisions/0128) ----------------------------------------
    // Unpaid: one order, linked to the invoice; lines that match take the invoice's run and price (their proofs, files
    // and work orders stay), lines only on the invoice are added, lines only on the order are kept or dropped (your
    // choice: a kept line isn't on the invoice yet: add it in QuickBooks and pull again). Paid: the payment rules, so
    // the order is rebuilt to match the invoice exactly (lines only on the order are dropped), the QuickBooks payment is
    // recorded, and the site carries on from there. Pulling again refreshes it the same way.

    /** A line's run size and words, for matching. */
    private static function runOf(array $l): int { return ClientOrders::runQty($l); }

    /**
     * How invoice $no would merge into order $oid: preview() plus 'order' (the order), 'pairs' (each invoice line i =>
     * the order line id it updates, or 0 to add), 'only' (order lines not on the invoice), 'paid_here' (cents already
     * recorded on the order) and 'gap' (the invoice total less the order's).
     */
    public static function mergePlan(PDO $pdo, string $no, int $oid): array
    {
        $pv = self::preview($pdo, $no);
        $o = Orders::get($pdo, $oid);
        if (!$o || !ClientOrders::isClient($o)) throw new RuntimeException('That order isn\'t one of our client orders.');
        if ($o['status'] === 'void') throw new RuntimeException('That order is cancelled.');
        if ($pv['existing'] && (int) $pv['existing']['id'] !== $oid) throw new RuntimeException('Invoice ' . $pv['inv']['no'] . ' is already order #' . Orders::no($pv['existing']) . '.');
        $env = Books::env();
        if (!empty($o['invoice_id']) && (string) $o['invoice_id'] !== $pv['inv']['id']) throw new RuntimeException('This order is linked to another QuickBooks invoice (' . $o['invoice_no'] . ').');
        $lines = array_values(array_filter(Orders::lines($pdo, $oid), fn ($l) => $l['status'] !== 'cancelled' && $l['product'] !== 'go_code'));
        $norm = fn (string $t) => trim(preg_replace('/[^a-z0-9$]+/', ' ', strtolower(preg_replace('/·.*$/u', '', $t))));
        $free = array_column($lines, null, 'id'); $pairs = [];
        foreach ($pv['lines'] as $l) {   // best match: same product and run, then same product, then the words, then a charge by its name
            $best = 0; $score = 0; $run = (int) round($l['qty']);
            foreach ($free as $id => $ol) {
                $sc = 0;
                if ($l['kind'] === 'product' && (int) $ol['product_id'] > 0 && in_array((int) $ol['product_id'], $l['products'] ?: [$l['product']], true)) $sc += 50;
                if ($l['kind'] === 'charge' && in_array($ol['product'], ['shipping', 'custom'], true)) $sc += 10;
                similar_text($norm((string) $ol['title']), $norm($l['head']), $pct); $sc += $pct * .4;
                if (self::runOf($ol) === $run && $run > 1) $sc += 15;
                if ($sc > $score) { $score = $sc; $best = $id; }
            }
            $pairs[$l['i']] = $score >= 30 ? $best : 0;
            if ($pairs[$l['i']]) unset($free[$pairs[$l['i']]]);
        }
        // one line here that the invoice splits into several (a run of 9,000 invoiced as three versions of 3,000): they all
        // update that line, so its proofs, files and work order stay with it
        $words = fn (string $t) => array_values(array_unique(array_filter(preg_split('/[^a-z]+/', strtolower(preg_replace('/·.*$/u', '', $t))), fn ($w) => strlen($w) > 2)));
        $groups = [];
        foreach ($free as $id => $ol) {
            $want = $words((string) $ol['title']); if (!$want) continue;
            $set = []; $sum = 0;
            foreach ($pv['lines'] as $l) {
                if ($pairs[$l['i']] || $l['kind'] === 'charge') continue;
                $have = $words($l['head'] . ' ' . $l['note']);
                if (count(array_intersect($want, $have)) / count($want) < .6) continue;
                $set[] = $l['i']; $sum += (int) round($l['qty']);
            }
            $run = self::runOf($ol);
            if (count($set) < 2 || ($run > 1 && $sum !== $run)) continue;
            foreach ($set as $i) $pairs[$i] = $id;
            $groups[$id] = $set; unset($free[$id]);
        }
        $paidHere = Orders::money($pdo, $oid)['paid'];
        return $pv + ['order' => $o, 'lines_here' => $lines, 'pairs' => $pairs, 'groups' => $groups, 'only' => array_values($free), 'paid_here' => $paidHere, 'gap' => $pv['inv']['total'] - (int) $o['total_cents']];
    }

    /**
     * Merges invoice $no into order $oid. $in: item[ref] for items not mapped yet (as pull()), keep[line id] = 1 to keep
     * an order line that isn't on the invoice (unpaid invoices only). Returns what was done, in words.
     */
    public static function merge(PDO $pdo, string $no, int $oid, array $in, int $uid): string
    {
        $pl = self::mergePlan($pdo, $no, $oid);
        $done = [];
        foreach ($pl['lines'] as $l) {   // undecided items first, as for a pull (remembered)
            if ($l['kind'] !== 'open' || isset($done[$l['item'][0]])) continue;
            $done[$l['item'][0]] = true;
            self::decideItem($pdo, $l, (string) ($in['item'][$l['item'][0]] ?? ''), $uid);
        }
        $pl = self::mergePlan($pdo, $no, $oid);
        $inv = $pl['inv']; $o = $pl['order']; $env = Books::env(); $paid = $inv['total'] > 0 && $inv['balance'] <= 0;
        $was = (int) $o['total_cents']; $upd = 0; $add = 0; $drop = 0; $kept = 0;
        $pdo->beginTransaction();
        try {
            $byI = array_column($pl['lines'], null, 'i');
            foreach ($pl['groups'] as $lid => $set) {   // one line here, several on the invoice: the line takes their sum, the versions noted
                $ls = array_map(fn ($i) => $byI[$i], $set); $amt = array_sum(array_column($ls, 'amount')); $run = array_sum(array_map(fn ($l) => max(1, (int) round($l['qty'])), $ls));
                $cur = null; foreach ($pl['lines_here'] as $h) if ((int) $h['id'] === (int) $lid) $cur = $h;
                $pid = 0; foreach ($ls as $l) if ($l['kind'] === 'product') { $pid = (int) $l['product']; break; }
                $title = $cur && $cur['product'] === 'product' ? ClientOrders::titleWithRun((string) $cur['title'], $run) : (string) ($cur['title'] ?? '');
                $note = 'On QuickBooks invoice ' . $inv['no'] . ' as: ' . implode('; ', array_map(fn ($l) => $l['head'] . ' · ' . number_format((float) $l['qty']) . ' · ' . Orders::usd((int) $l['amount']), $ls));
                $pdo->prepare('UPDATE order_lines SET title = ?, qty = 1, unit_cents = ?, list_cents = ?, taxable = ?, note = ?' . ($pid && empty($cur['product_id']) ? ', product_id = ' . $pid : '') . ' WHERE id = ?')
                    ->execute([mb_substr($title, 0, 160), $amt, $amt, max(array_map(fn ($l) => $l['taxable'] ? 1 : 0, $ls)), mb_substr($note, 0, 300), (int) $lid]);
                if ($cur && $cur['product'] === 'product' && ClientOrders::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([$run, (int) $lid]);
                $upd++;
            }
            foreach ($pl['lines'] as $l) {
                $lid = (int) $pl['pairs'][$l['i']];
                if ($lid && isset($pl['groups'][$lid])) continue;
                $run = max(1, (int) round($l['qty']));
                $pid = $l['kind'] === 'product' ? (int) $l['product'] : 0;
                if ($lid) {   // the invoice's run and price on the line that's here: its proofs, files and work orders stay
                    $cur = null; foreach ($pl['lines_here'] as $h) if ((int) $h['id'] === $lid) $cur = $h;
                    $title = $cur && $cur['product'] === 'product' ? ClientOrders::titleWithRun((string) $cur['title'], $run) : (string) $cur['title'];
                    $pdo->prepare('UPDATE order_lines SET title = ?, qty = 1, unit_cents = ?, list_cents = ?, taxable = ?' . ($pid && empty($cur['product_id']) ? ', product_id = ' . $pid : '') . ' WHERE id = ?')
                        ->execute([mb_substr($title, 0, 160), $l['amount'], $l['amount'], $l['taxable'] ? 1 : 0, $lid]);
                    if ($cur && $cur['product'] === 'product' && ClientOrders::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([$run, $lid]);
                    if ($l['kind'] === 'charge') $pdo->prepare("UPDATE order_lines SET tags = TRIM(BOTH ',' FROM CONCAT_WS(',', NULLIF(tags, ''), 'charge')) WHERE id = ? AND FIND_IN_SET('charge', COALESCE(tags, '')) = 0")->execute([$lid]);
                    $upd++;
                } else {
                    if (self::insertLine($pdo, $oid, $l, $pid)) $add++;
                }
            }
            foreach ($pl['only'] as $ol) {   // on the order, not the invoice
                if (!$paid && !empty($in['keep'][(int) $ol['id']])) { $kept++; continue; }
                $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE id = ?")->execute([(int) $ol['id']]);
                Orders::event($pdo, $oid, 'line_dropped', 'Dropped to match QuickBooks invoice ' . $inv['no'] . ': ' . $ol['title'] . ' · ' . Orders::usd((int) $ol['unit_cents'] * max(1, (int) $ol['qty'])), $uid, (int) $ol['id']);
                $drop++;
            }
            $st = $pdo->prepare("SELECT COUNT(*), COALESCE(SUM(qty * unit_cents), 0) FROM order_lines WHERE order_id = ? AND status <> 'cancelled'"); $st->execute([$oid]);
            [$n, $sub] = array_map('intval', $st->fetch(PDO::FETCH_NUM));
            $total = $kept ? $sub + $inv['tax'] : $inv['total'];   // a kept line isn't on the invoice yet: the order shows it on top
            $b = $inv['bill'];
            $pdo->prepare("UPDATE orders SET status = IF(status IN ('draft','sent'), 'pending', status), approved_at = COALESCE(approved_at, ?), approved_name = COALESCE(NULLIF(approved_name, ''), ?), sent_at = COALESCE(sent_at, ?),
                           invoice_id = ?, invoice_no = ?, qb_customer_id = COALESCE(NULLIF(qb_customer_id, ''), ?), qb_env = ?, pay_mode = 'invoice', items = ?, subtotal_cents = ?, tax_cents = ?, total_cents = ?,
                           due_date = COALESCE(?, due_date), bill_street = COALESCE(NULLIF(bill_street, ''), ?), bill_city = COALESCE(NULLIF(bill_city, ''), ?), bill_state = COALESCE(NULLIF(bill_state, ''), ?), bill_zip = COALESCE(NULLIF(bill_zip, ''), ?) WHERE id = ?")
                ->execute([($inv['date'] ?: date('Y-m-d')) . ' 12:00:00', 'QuickBooks invoice ' . $inv['no'], ($inv['date'] ?: date('Y-m-d')) . ' 12:00:00', $inv['id'], $inv['no'], $inv['customer'], $env,
                           $n, $sub, $inv['tax'], $total, $inv['due'] ?: null, $b['street'], $b['city'], $b['state'], $b['zip'], $oid]);
            // QuickBooks' payments: what it has that isn't recorded here yet (a payment already recorded here isn't counted twice)
            $owed = max(0, $inv['paid'] - (int) $pl['paid_here']);
            if ($owed > 0) {
                $left = $total - Orders::money($pdo, $oid)['paid'];
                Orders::record($pdo, $oid, $owed >= $left ? 'charge' : 'deposit', $owed, 'qbmerge-' . $env . '-' . $inv['id'] . '-' . $oid . '-' . $inv['paid'], 'quickbooks', $inv['no'], 'Paid in QuickBooks (merged from the invoice)', $uid);
            }
            if ($paid && !$kept) $pdo->prepare("UPDATE orders SET status = IF(status IN ('pending'), 'paid', status), paid_at = COALESCE(paid_at, ?) WHERE id = ?")->execute([($inv['payments'] ? max(array_column($inv['payments'], 'date')) : date('Y-m-d')) . ' 12:00:00', $oid]);
            self::exemptFrom($pdo, $oid, $pl['lines']);
            SystemTags::set($pdo, 'qbo.invoice', $oid, $env, $inv['id'], 'Invoice ' . $inv['no'], $uid, 'merged');
            $pdo->commit();
        } catch (Throwable $x) { $pdo->rollBack(); throw $x; }
        try {   // the client's QuickBooks customer, on its business
            $lid = (int) (Orders::get($pdo, $oid)['listing_id'] ?? 0);
            if ($lid > 0 && $inv['customer'] !== '') { SystemTags::set($pdo, 'qbo.customer', $lid, $env, $inv['customer'], $inv['company'] ?: $inv['person'], $uid, 'from invoice ' . $inv['no']); $pdo->prepare('UPDATE client_listings SET qb_customer_id = ? WHERE entity_id = ?')->execute([$inv['customer'], $lid]); }
        } catch (Throwable $x) { error_log('qb merge client: ' . $x->getMessage()); }
        $gap = $inv['total'] - $was;
        $words = 'Merged QuickBooks invoice ' . $inv['no'] . ': ' . $upd . ' line' . ($upd === 1 ? '' : 's') . ' updated, ' . $add . ' added' . ($drop ? ', ' . $drop . ' dropped' : '') . ($kept ? ', ' . $kept . ' kept (not on the invoice yet)' : '')
            . '. Total ' . Orders::usd($was) . ' → ' . Orders::usd($inv['total']) . ($paid ? ', paid in QuickBooks' : ($inv['paid'] ? ', ' . Orders::usd($inv['paid']) . ' paid' : '')) . '.';
        Orders::event($pdo, $oid, 'merged', $words, $uid);
        if ($gap !== 0) Orders::event($pdo, $oid, 'price_gap', $gap > 0 ? 'The order here was ' . Orders::usd($gap) . ' under the invoice: check the products\' prices so the next order isn\'t.' : 'The invoice is ' . Orders::usd(-$gap) . ' under what the order here had' . ($paid ? ': the payment rules (it\'s what was agreed); if we were underpriced, fix the product\'s price for next time.' : '.'), $uid);
        try { require_once __DIR__ . '/Collateral.php'; Collateral::fromOrder($pdo, $oid, true); } catch (Throwable $x) { error_log('qb merge collateral: ' . $x->getMessage()); }
        return $words;
    }

    /**
     * The choices for one QuickBooks item on a pull or merge (Jason's screenshot, 2026-11-23: "504 Interstate Commerce" fitted
     * none): what it is first, each with its meaning, then our products to tag it to. An item whose name reads as a tax
     * exemption (interstate, exempt, resale) starts on that choice; one named like a product starts on that product.
     */
    public static function itemChoices(array $products, string $name): string
    {
        $e = fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES);
        $taxy = (bool) preg_match('/\\b(interstate|exempt|exemption|resale|reseller)\\b/i', $name);
        $h = '<option value="">Choose…</option><optgroup label="What it is">';
        foreach ([['make', 'Make a product from it', 'a new product, offered for reorders'], ['charge', 'It\'s a charge', 'shipping, shrink wrap, fees: never a product or a reorder item'],
                  ['tax', 'It marks a tax exemption', 'the order is exempt from sales tax, named by it; it adds no line'], ['leave', 'Leave it', 'its line comes in as written, not a product or a reorder item']] as [$v, $l, $why])
            $h .= '<option value="' . $v . '"' . ($v === 'tax' && $taxy ? ' selected' : '') . '>' . $e($l . ': ' . $why) . '</option>';
        $h .= '</optgroup><optgroup label="Tag it to one of our products">';
        foreach ($products as $pid => $pn) $h .= '<option value="p:' . (int) $pid . '"' . (!$taxy && mb_strtolower((string) $pn) === mb_strtolower($name) ? ' selected' : '') . '>' . $e($pn) . '</option>';
        return $h . '</optgroup>';
    }

    /**
     * One QuickBooks item decided on the pull or merge, remembered for every later invoice (Books::decide): p:<product>,
     * make, charge, tax (it only marks a sales-tax exemption) or leave (its line comes in as written).
     */
    private static function decideItem(PDO $pdo, array $l, string $c, int $uid): void
    {
        if (in_array($c, ['charge', 'make', 'tax', 'leave'], true)) Books::decide($pdo, $l['item'][0], $c, 0, $uid);
        elseif (preg_match('/^p:(\d+)$/', $c, $m)) Books::decide($pdo, $l['item'][0], 'link', (int) $m[1], $uid);
        else throw new RuntimeException('Decide each item that isn\'t mapped yet ("' . $l['item'][1] . '").');
    }

    /** An invoice carrying an exemption item: the order is exempt from sales tax, named by the item (decisions/0177 §2). */
    private static function exemptFrom(PDO $pdo, int $oid, array $lines): void
    {
        $names = array_values(array_unique(array_map(fn ($l) => (string) $l['item'][1], array_filter($lines, fn ($l) => $l['kind'] === 'tax'))));
        if (!$names || !Orders::hasCol($pdo, 'tax_choice')) return;
        $pdo->prepare("UPDATE orders SET tax_choice = 'exempt', tax_note = ? WHERE id = ?")->execute([mb_substr('From QuickBooks: ' . implode(', ', $names), 0, 200), $oid]);
        Orders::event($pdo, $oid, 'tax_choice', 'Exempt from sales tax: the QuickBooks invoice carries ' . implode(', ', $names) . '.');
    }

    /** A line from the invoice, added to an order: a product run, a charge, or a line kept as written. False: nothing added. */
    private static function insertLine(PDO $pdo, int $oid, array $l, int $pid): bool
    {
        if ($l['kind'] === 'tax' && (int) $l['amount'] === 0) return false;   // an exemption marker: the order's tax choice, not a line
        $qty = (int) round($l['qty']);
        if ($pid) {
            $pdo->prepare("INSERT INTO order_lines (order_id, product, product_id, title, qty, unit_cents, list_cents, cost_cents, taxable, options, note) VALUES (?, 'product', ?, ?, 1, ?, ?, 0, ?, '', ?)")
                ->execute([$oid, $pid, mb_substr($l['head'] . ($qty > 1 ? ' · ' . number_format($qty) : ''), 0, 160), $l['amount'], $l['amount'], $l['taxable'] ? 1 : 0, mb_substr($l['note'], 0, 300)]);
            $id = (int) $pdo->lastInsertId();
            if (ClientOrders::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([max(1, $qty), $id]);
            return true;
        }
        $ship = (bool) preg_match('/\b(ship|shipping|freight|deliver|delivery|postage)\b/i', $l['item'][1]);
        $pdo->prepare('INSERT INTO order_lines (order_id, product, title, qty, unit_cents, list_cents, cost_cents, taxable, note, tags) VALUES (?, ?, ?, 1, ?, ?, 0, ?, ?, ?)')
            ->execute([$oid, $ship && $l['kind'] === 'charge' ? 'shipping' : 'custom', mb_substr($l['head'], 0, 160), $l['amount'], $l['amount'], $l['taxable'] ? 1 : 0, mb_substr($l['note'], 0, 300), $l['kind'] === 'charge' ? 'charge' : '']);
        return true;
    }
}
