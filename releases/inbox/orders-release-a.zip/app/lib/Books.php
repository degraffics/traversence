<?php
// app/lib/Books.php — who does what with the money (decisions/0128), and mapping QuickBooks' items to our products.
// Three roles, each set on its own: the processor (the payment gateway at checkout, only that), the bookkeeper (matches
// or manages our orders, payments, clients and taxes) and order/CRM management. Tax and history each have one authority,
// the bookkeeper or Traversence; the other follows. Before a bookkeeper records anything, its items are mapped to our
// products here: tagged (SystemTags 'qbo.item'), made into a product, marked as a charge (shipping, fees), or left.
// Reading QuickBooks' items writes nothing there; mapping never changes a past order's lines.
declare(strict_types=1);

require_once __DIR__ . '/SystemTags.php';
require_once __DIR__ . '/QuickBooksPay.php';

final class Books
{
    /** The roles: key => [label, what it does, choices (value => label), today's setting]. */
    public const ROLES = [
        'processor' => ['Processor', 'The payment gateway at checkout, and only that.', ['qbo' => 'QuickBooks Payments', 'offline' => 'No card gateway: our team records wires, checks, cash'], 'qbo'],
        'books' => ['Bookkeeper', 'Matches or manages our orders, payments, clients and taxes. Traversence keeps its own books (the ledger, payments, credits, refunds); QuickBooks can do it instead. It needn\'t be the processor.', ['trv' => 'Traversence (its own books)', 'qbo' => 'QuickBooks'], 'qbo'],
        'orders' => ['Order and CRM management', 'Orders, work orders, customer relations, marketing.', ['trv' => 'Traversence', 'other' => 'Another system'], 'trv'],
        'tax' => ['Tax authority', 'Whose tax wins; the other takes it as given.', ['books' => 'The bookkeeper', 'trv' => 'Traversence'], 'books'],
        'history' => ['History authority', 'Whose record of an order wins when they differ.', ['books' => 'The bookkeeper', 'trv' => 'Traversence'], 'trv'],
    ];
    /** Words that mark a QuickBooks item as a charge on an order, not a product (suggested only). */
    private const CHARGE_WORDS = '/\b(ship|shipping|freight|deliver|delivery|postage|shrink|wrap|setup|set-up|rush|fee|fees|handling|tax|discount|deposit|credit|tip)\b/i';

    public static function role(PDO $pdo, string $k): string
    {
        if ($k === 'tax') {   // the same setting as Taxes & shipping's tax source, so the two never disagree
            if (self::role($pdo, 'books') === 'trv') return 'trv';
            try { require_once __DIR__ . '/Commerce.php'; return Commerce::taxSource($pdo) === 'quickbooks' ? 'books' : 'trv'; } catch (Throwable) { return 'books'; }
        }
        if ($k === 'history' && self::role($pdo, 'books') === 'trv') return 'trv';
        $v = self::setting($pdo, 'role_' . $k);
        $v = ['none' => $k === 'books' ? 'trv' : 'offline'][$v] ?? $v;   // the first version's "none"
        return isset(self::ROLES[$k][2][$v]) ? $v : self::ROLES[$k][3];
    }

    public static function setRoles(PDO $pdo, array $in, int $uid): void
    {
        foreach (self::ROLES as $k => [, , $choices]) {
            if (!isset($in[$k])) continue;
            if (!isset($choices[$in[$k]])) throw new RuntimeException('Choose one of the ways shown for ' . strtolower(self::ROLES[$k][0]) . '.');
            if ($k === 'tax') continue;   // below, once the bookkeeper is known
            self::put($pdo, 'role_' . $k, (string) $in[$k], $uid);
        }
        require_once __DIR__ . '/Commerce.php';
        $tax = self::role($pdo, 'books') === 'trv' ? 'trv' : (string) ($in['tax'] ?? self::role($pdo, 'tax'));   // our own books: we're the tax and history authority
        Commerce::setSetting($pdo, 'tax_source', $tax === 'books' ? 'quickbooks' : 'rates');
        if (self::role($pdo, 'books') === 'trv') self::put($pdo, 'role_history', 'trv', $uid);
    }

    /**
     * What each role needs before it works, checked now: [role, ok, what, [link label, url]|null]. A role isn't
     * functional until its line is ok (Jason, 2026-10-28: e-commerce requirements must be set and managed).
     */
    public static function requirements(PDO $pdo): array
    {
        $out = []; $qbOn = false;
        try { $c = QuickBooksPay::connection($pdo); $qbOn = QuickBooksPay::env() === 'mock' || ($c && !QuickBooksPay::needsReconnect($c)); } catch (Throwable) {}
        $needsQb = self::role($pdo, 'processor') === 'qbo' || self::role($pdo, 'books') === 'qbo';
        if ($needsQb) $out[] = ['QuickBooks', $qbOn, $qbOn ? 'Connected (' . QuickBooksPay::env() . ').' : 'Not connected, or it needs reconnecting: card checkout and the books stop until it is.', $qbOn ? null : ['Connect QuickBooks', '/admin/quickbooks.php']];
        if (self::role($pdo, 'processor') === 'offline') $out[] = ['Processor', true, 'No card checkout: clients choose wire, check or cash, and our team records each payment on the order.', null];
        if (self::role($pdo, 'books') === 'qbo') {
            $pr = self::progress($pdo);
            $ok = $pr['items'] > 0 && $pr['open'] === 0;
            $out[] = ['Bookkeeper', $ok, $pr['items'] === 0 ? 'QuickBooks\' items aren\'t mapped yet: read them below and decide each, before the books record orders.' : ($ok ? 'Every QuickBooks item is mapped.' : $pr['open'] . ' QuickBooks item' . ($pr['open'] === 1 ? '' : 's') . ' still to map, below.'), null];
        } else $out[] = ['Bookkeeper', true, 'Traversence keeps the books: the ledger, payments, credits and refunds on each order, and Money reports.', ['Money reports', '/admin/backoffice/money']];
        if (self::role($pdo, 'tax') === 'trv') {
            $n = 0; try { require_once __DIR__ . '/Commerce.php'; $n = count(array_filter(Commerce::rates($pdo), fn ($r) => (int) $r['active'])); } catch (Throwable) {}
            $out[] = ['Tax', $n > 0, $n > 0 ? 'Traversence works out tax from ' . $n . ' rate' . ($n === 1 ? '' : 's') . ' in Taxes & shipping.' : 'Traversence is the tax authority but has no tax rates: add them in Taxes & shipping, or no tax is charged.', ['Taxes & shipping', '/admin/backoffice/taxes']];
        } else $out[] = ['Tax', $qbOn, 'QuickBooks works out the tax on each invoice; Traversence takes it as given.', null];
        if (self::role($pdo, 'orders') === 'other') $out[] = ['Orders', true, 'Orders are managed in another system: Traversence keeps the record and the books only.', null];
        return $out;
    }

    /** What each order records: the setup it was made under. */
    public static function snapshot(PDO $pdo): array
    {
        $o = []; foreach (array_keys(self::ROLES) as $k) $o[$k] = self::role($pdo, $k);
        return $o;
    }

    private static function setting(PDO $pdo, string $name): string
    {
        try { $st = $pdo->prepare('SELECT value FROM ' . Database::t('qb_settings') . ' WHERE name = ?'); $st->execute([$name]); return (string) ($st->fetchColumn() ?: ''); } catch (Throwable) { return ''; }
    }

    private static function put(PDO $pdo, string $name, string $value, int $uid): void
    {
        $pdo->prepare('INSERT INTO ' . Database::t('qb_settings') . ' (name, value, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_by = VALUES(updated_by)')->execute([$name, $value, $uid]);
    }

    // ---- QuickBooks' items, staged here to map ---------------------------------------------------------------------------

    public static function ensure(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $pdo->exec("CREATE TABLE IF NOT EXISTS qbo_items (
            env VARCHAR(12) NOT NULL, ref VARCHAR(64) NOT NULL, name VARCHAR(200) NOT NULL DEFAULT '', description VARCHAR(1000) NOT NULL DEFAULT '',
            price DECIMAL(14,4) DEFAULT NULL, taxable TINYINT(1) NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1, type VARCHAR(30) NOT NULL DEFAULT '',
            role VARCHAR(10) NOT NULL DEFAULT '', role_by INT UNSIGNED DEFAULT NULL, role_at DATETIME DEFAULT NULL, fetched_at DATETIME NOT NULL,
            PRIMARY KEY (env, ref)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
        $done = true;
    }

    public static function env(): string { return QuickBooksPay::env(); }

    /** Reads QuickBooks' item list into qbo_items (read only there). Products already holding a QuickBooks item id are tagged with it. Returns how many items. */
    public static function readItems(PDO $pdo, int $uid): int
    {
        self::ensure($pdo);
        $env = self::env(); $n = 0;
        $up = $pdo->prepare('INSERT INTO qbo_items (env, ref, name, description, price, taxable, active, type, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), price = VALUES(price), taxable = VALUES(taxable), active = VALUES(active), type = VALUES(type), fetched_at = VALUES(fetched_at)');
        foreach (QuickBooksPay::items($pdo) as $i) {
            $up->execute([$env, (string) $i['Id'], mb_substr((string) ($i['Name'] ?? ''), 0, 200), mb_substr((string) ($i['Description'] ?? ''), 0, 1000),
                isset($i['UnitPrice']) ? (float) $i['UnitPrice'] : null, !empty($i['Taxable']) ? 1 : 0, ($i['Active'] ?? true) ? 1 : 0, (string) ($i['Type'] ?? '')]);
            $n++;
        }
        try {   // the old way kept the id on the product: carry it over as a tag
            foreach ($pdo->query("SELECT id, qb_item_id, qb_item_env FROM products WHERE qb_item_id IS NOT NULL AND qb_item_id <> ''")->fetchAll(PDO::FETCH_ASSOC) as $p)
                if (((string) $p['qb_item_env'] ?: $env) === $env && !SystemTags::get($pdo, 'qbo.item', (int) $p['id'], $env)) SystemTags::set($pdo, 'qbo.item', (int) $p['id'], $env, (string) $p['qb_item_id'], '', $uid, 'carried over');
        } catch (Throwable) {}
        return $n;
    }

    /**
     * Each staged item with where it stands and a suggestion: state (linked | charge | leave | open), products (tagged
     * ids), suggest ['product', id, why] | ['charge', why] | ['new', why].
     */
    public static function items(PDO $pdo): array
    {
        self::ensure($pdo);
        $env = self::env();
        $st = $pdo->prepare('SELECT * FROM qbo_items WHERE env = ? ORDER BY active DESC, name'); $st->execute([$env]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $map = SystemTags::map($pdo, 'qbo.item', $env);
        $prods = [];
        foreach ($pdo->query("SELECT id, name FROM products WHERE status <> 'deleted' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC) as $p) $prods[(int) $p['id']] = (string) $p['name'];
        $norm = fn (string $s) => trim(preg_replace('/[^a-z0-9]+/', ' ', strtolower($s)));
        foreach ($rows as &$r) {
            $r['products'] = $map[(string) $r['ref']] ?? [];
            $r['state'] = $r['products'] ? 'linked' : ($r['role'] !== '' ? $r['role'] : 'open');
            $r['suggest'] = null;
            if ($r['state'] !== 'open') continue;
            if (preg_match(self::CHARGE_WORDS, (string) $r['name'])) { $r['suggest'] = ['charge', 'its name sounds like a charge, not a product']; continue; }
            $best = 0; $bestId = 0;
            foreach ($prods as $pid => $pn) {
                if ($norm($pn) === $norm((string) $r['name'])) { $best = 100; $bestId = $pid; break; }
                similar_text($norm($pn), $norm((string) $r['name']), $pct);
                if ($pct > $best) { $best = $pct; $bestId = $pid; }
            }
            $r['suggest'] = $best >= 75 ? ['product', $bestId, $best >= 100 ? 'the same name' : 'a close name'] : ['new', 'no product like it yet'];
        }
        unset($r);
        return $rows;
    }

    /** Where mapping stands: [items, decided, open, products not tagged yet]. */
    public static function progress(PDO $pdo): array
    {
        $it = self::items($pdo);
        $open = count(array_filter($it, fn ($r) => $r['state'] === 'open' && (int) $r['active']));
        $tagged = array_unique(array_merge([], ...array_values(SystemTags::map($pdo, 'qbo.item', self::env()))));
        $untagged = (int) $pdo->query("SELECT COUNT(*) FROM products WHERE status = 'active'" . ($tagged ? ' AND id NOT IN (' . implode(',', array_map('intval', $tagged)) . ')' : ''))->fetchColumn();
        return ['items' => count($it), 'decided' => count($it) - count(array_filter($it, fn ($r) => $r['state'] === 'open')), 'open' => $open, 'untagged' => $untagged];
    }

    private static function item(PDO $pdo, string $ref): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM qbo_items WHERE env = ? AND ref = ?'); $st->execute([self::env(), $ref]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new RuntimeException('That QuickBooks item isn\'t in the list: read the items again.');
        return $r;
    }

    private static function setRole(PDO $pdo, string $ref, string $role, int $uid): void
    {
        $pdo->prepare('UPDATE qbo_items SET role = ?, role_by = ?, role_at = NOW() WHERE env = ? AND ref = ?')->execute([$role, $uid, self::env(), $ref]);
    }

    /**
     * One decision on an item: link (to product $pid; a general item may tag several products), make (a product from
     * it, then tag), charge, leave, or clear (back to undecided: its role and its product tags come off). Returns what
     * was done, in words.
     */
    public static function decide(PDO $pdo, string $ref, string $what, int $pid, int $uid): string
    {
        $it = self::item($pdo, $ref); $env = self::env();
        switch ($what) {
            case 'link':
                require_once __DIR__ . '/Products.php';
                $p = Products::get($pdo, $pid);
                if (!$p) throw new RuntimeException('Choose one of our products.');
                SystemTags::set($pdo, 'qbo.item', $pid, $env, $ref, (string) $it['name'], $uid);
                self::setRole($pdo, $ref, '', $uid);
                return '"' . $it['name'] . '" is tagged to ' . $p['name'] . '.';
            case 'make':
                require_once __DIR__ . '/Products.php';
                $had = $pdo->prepare('SELECT id, name FROM products WHERE sku = ? LIMIT 1'); $had->execute(['QB-' . $ref]);
                if ($hp = $had->fetch(PDO::FETCH_ASSOC)) {   // made from this item before (its tag since taken off): tag that one again, not a second copy
                    SystemTags::set($pdo, 'qbo.item', (int) $hp['id'], $env, $ref, (string) $it['name'], $uid, 'made from the item earlier');
                    self::setRole($pdo, $ref, '', $uid);
                    return '"' . $it['name'] . '" is tagged again to ' . $hp['name'] . ', the product made from it before.';
                }
                $price = $it['price'] !== null && (float) $it['price'] > 0 ? rtrim(rtrim(number_format((float) $it['price'], 4, '.', ''), '0'), '.') : '0';
                $nid = Products::save($pdo, 0, ['name' => (string) $it['name'], 'sku' => 'QB-' . $ref, 'kind' => 'print', 'description' => (string) $it['description'],
                    'qty' => ['1'], 'cost' => [''], 'price' => [$price], 'markup' => 0, 'taxable' => (int) $it['taxable'], 'status' => 'active']);
                SystemTags::set($pdo, 'qbo.item', $nid, $env, $ref, (string) $it['name'], $uid, 'made from the item');
                self::setRole($pdo, $ref, '', $uid);
                return 'Made the product "' . $it['name'] . '" from it and tagged them. Add its runs, options and vendor in Products.';
            case 'charge': case 'leave': case 'tax':   // tax: it only marks a sales-tax exemption (Arizona's "504 Interstate Commerce"): the pulled order is exempt, no line
                foreach (SystemTags::things($pdo, 'qbo.item', $env, $ref) as $t) { $g = SystemTags::get($pdo, 'qbo.item', $t, $env); if ($g && $g['ref'] === $ref) SystemTags::remove($pdo, (int) $g['id'], $uid); }
                self::setRole($pdo, $ref, $what, $uid);
                return '"' . $it['name'] . '" ' . ($what === 'charge' ? 'is a charge on orders (shipping, fees): never a product or a reorder item.' : ($what === 'tax' ? 'marks a tax exemption: an order pulled with it is exempt from sales tax, named by it, and it adds no line.' : 'is left as it is.'));
            case 'clear':
                foreach (SystemTags::things($pdo, 'qbo.item', $env, $ref) as $t) { $g = SystemTags::get($pdo, 'qbo.item', $t, $env); if ($g && $g['ref'] === $ref) SystemTags::remove($pdo, (int) $g['id'], $uid); }
                self::setRole($pdo, $ref, '', $uid);
                return '"' . $it['name'] . '" is undecided again.';
        }
        throw new RuntimeException('Choose what to do with it.');
    }

    /** Takes every suggestion that's a match or a charge (never makes products on its own). Returns how many. */
    public static function acceptSuggestions(PDO $pdo, int $uid): int
    {
        $n = 0;
        foreach (self::items($pdo) as $r) {
            if ($r['state'] !== 'open' || !$r['suggest']) continue;
            if ($r['suggest'][0] === 'product') { self::decide($pdo, (string) $r['ref'], 'link', (int) $r['suggest'][1], $uid); $n++; }
            elseif ($r['suggest'][0] === 'charge') { self::decide($pdo, (string) $r['ref'], 'charge', 0, $uid); $n++; }
        }
        return $n;
    }

    /** An item seen on an invoice but not read yet: staged so it can be decided like the rest. */
    public static function stageItem(PDO $pdo, string $ref, string $name, string $desc = '', ?float $price = null, bool $taxable = false): void
    {
        self::ensure($pdo);
        $pdo->prepare('INSERT IGNORE INTO qbo_items (env, ref, name, description, price, taxable, active, fetched_at) VALUES (?, ?, ?, ?, ?, ?, 1, NOW())')
            ->execute([self::env(), $ref, mb_substr($name, 0, 200), mb_substr($desc, 0, 1000), $price, $taxable ? 1 : 0]);
    }

    /** One staged item's role ('' | charge | leave | tax), and our products tagged with it. */
    public static function itemState(PDO $pdo, string $ref): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT role FROM qbo_items WHERE env = ? AND ref = ?'); $st->execute([self::env(), $ref]);
        return ['role' => (string) ($st->fetchColumn() ?: ''), 'products' => SystemTags::things($pdo, 'qbo.item', self::env(), $ref)];
    }

    /** The QuickBooks item for one of our products in this mode ('' when it has none yet). */
    public static function itemFor(PDO $pdo, int $pid): string
    {
        if ($pid <= 0) return '';
        try { $t = SystemTags::get($pdo, 'qbo.item', $pid, self::env()); return $t ? (string) $t['ref'] : ''; } catch (Throwable) { return ''; }
    }
}
