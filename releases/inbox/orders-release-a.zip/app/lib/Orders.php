<?php
// app/lib/Orders.php — the order system (decisions/0098, 0099): one record for every order, whatever it sells, and a
// money ledger that is only ever added to.
//
//   orders        who, status, totals, billing, the QuickBooks invoice, the private Manage link
//   order_lines   what was bought (product + what it delivers, e.g. a GO Code), price and cost, approved_at (final)
//   order_ledger  money: charge, refund, credit_issued, credit_used, chargeback, chargeback_reversed, deposit. Each
//                 event has a request_key, so recording the same event twice does nothing.
//   order_events  the order's history: placed, paid, fixed, credited, refunded, chargeback…, with who did it
//
// QuickBooks keeps the books (decisions/0098): money moves there (the customer pays on QuickBooks' page; a refund to
// the card is made in QuickBooks); this records what happened, creates the QuickBooks records it can (a credit memo),
// and puts the order and what it delivered right (a refunded GO Code is switched off).
//
// The policy (Terms "Fix it, credit, then refund"): fix first, then a full or partial credit, a refund only when
// neither works; made-to-order lines are final once approved.
declare(strict_types=1);

final class Orders
{
    /** Ledger kinds and the sign their amount carries (+ money or credit to us/them, as it reads in the order). */
    public const KINDS = ['charge' => 'Paid', 'deposit' => 'Deposit paid', 'refund' => 'Refunded', 'credit_issued' => 'Credit given',
                          'credit_used' => 'Credit used', 'chargeback' => 'Card dispute', 'chargeback_reversed' => 'Dispute won'];
    public const STATUS = ['draft' => 'Draft', 'sent' => 'Sent to customer', 'pending' => 'Waiting for payment', 'paid' => 'Paid', 'void' => 'Cancelled',
                           'part_refunded' => 'Partly refunded', 'refunded' => 'Refunded', 'disputed' => 'Card dispute open'];

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM order_ledger LIMIT 1'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    public static function get(PDO $pdo, int $oid): ?array
    {
        $st = $pdo->prepare('SELECT * FROM orders WHERE id = ?'); $st->execute([$oid]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function lines(PDO $pdo, int $oid): array
    {
        static $pos = null;   // dragged into order (2026-12-11_inline_order.sql); a new line goes last
        if ($pos === null) { try { $pdo->query('SELECT position FROM order_lines LIMIT 0'); $pos = true; } catch (Throwable) { $pos = false; } }
        $st = $pdo->prepare('SELECT * FROM order_lines WHERE order_id = ? ORDER BY ' . ($pos ? '(position = 0), position, id' : 'id')); $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function ledger(PDO $pdo, int $oid): array
    {
        $st = $pdo->prepare('SELECT l.*, u.display_name AS actor_name FROM order_ledger l LEFT JOIN users u ON u.id = l.actor_user_id WHERE l.order_id = ? ORDER BY l.id');
        $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function events(PDO $pdo, int $oid): array
    {
        $st = $pdo->prepare('SELECT e.*, u.display_name AS actor_name FROM order_events e LEFT JOIN users u ON u.id = e.actor_user_id WHERE e.order_id = ? ORDER BY e.id');
        $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function event(PDO $pdo, int $oid, string $event, string $note = '', ?int $actor = null, ?int $line = null): void
    {
        $pdo->prepare('INSERT INTO order_events (order_id, line_id, event, note, actor_user_id) VALUES (?, ?, ?, ?, ?)')
            ->execute([$oid, $line, mb_substr($event, 0, 40), mb_substr($note, 0, 600), $actor]);
    }

    /**
     * Records a money event once (a repeat with the same $key does nothing). $cents is positive; the kind says which way
     * it goes. Returns true when it was new. The order's status follows.
     */
    public static function record(PDO $pdo, int $oid, string $kind, int $cents, string $key, string $method = '', string $qbRef = '', string $note = '', ?int $actor = null): bool
    {
        if (!isset(self::KINDS[$kind])) throw new InvalidArgumentException('kind');
        if ($cents <= 0) throw new RuntimeException('Enter an amount.');
        $st = $pdo->prepare('INSERT IGNORE INTO order_ledger (order_id, kind, amount_cents, method, qb_ref, note, actor_user_id, request_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $st->execute([$oid, $kind, $cents, mb_substr($method, 0, 40), mb_substr($qbRef, 0, 60), mb_substr($note, 0, 400), $actor, mb_substr($key, 0, 80)]);
        if (!$st->rowCount()) return false;
        self::settle($pdo, $oid);
        return true;
    }

    /** What the ledger adds up to for an order: paid in, refunded, credited, disputed, and the net kept. */
    public static function money(PDO $pdo, int $oid): array
    {
        $st = $pdo->prepare('SELECT kind, SUM(amount_cents) AS c FROM order_ledger WHERE order_id = ? GROUP BY kind'); $st->execute([$oid]);
        $k = array_fill_keys(array_keys(self::KINDS), 0);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $k[$r['kind']] = (int) $r['c'];
        $in = $k['charge'] + $k['deposit'];
        $net = $in - $k['refund'] - $k['chargeback'] + $k['chargeback_reversed'];
        return ['paid' => $in, 'refunded' => $k['refund'], 'credited' => $k['credit_issued'], 'credit_used' => $k['credit_used'],
                'disputed' => max(0, $k['chargeback'] - $k['chargeback_reversed']), 'net' => $net, 'by_kind' => $k];
    }

    /** The status that follows from the money, for a paid order (drafts, waiting and cancelled orders keep theirs). */
    private static function settle(PDO $pdo, int $oid): void
    {
        $o = self::get($pdo, $oid);
        if (!$o || in_array($o['status'], ['draft', 'sent', 'void'], true)) return;
        $m = self::money($pdo, $oid);
        if ($m['paid'] <= 0) return;
        if ($o['status'] === 'pending' && $m['paid'] < (int) $o['total_cents']) return;   // a deposit: waiting for the rest (decisions/0101)
        $open = self::disputeOpen($pdo, $oid);
        $status = $open ? 'disputed' : ($m['net'] <= 0 ? 'refunded' : ($m['refunded'] > 0 ? 'part_refunded' : 'paid'));
        if ($status !== $o['status']) $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $oid]);
    }

    /** Is a card dispute open (recorded, not yet won or lost)? */
    public static function disputeOpen(PDO $pdo, int $oid): bool
    {
        $st = $pdo->prepare("SELECT event FROM order_events WHERE order_id = ? AND event IN ('chargeback', 'chargeback_won', 'chargeback_lost') ORDER BY id DESC LIMIT 1");
        $st->execute([$oid]);
        return $st->fetchColumn() === 'chargeback';
    }

    /** Store credit lasts this long from when it's given (Terms, "Fix it, credit, then refund"; Jason, 2026-10-28: 90 days). */
    public const CREDIT_DAYS = 90;

    /**
     * A customer's store credit: given minus used, across their orders (by account, or by email for a guest). Each
     * credit lasts CREDIT_DAYS; what's used comes off the oldest first, and what's left of a credit past its date is gone.
     */
    public static function creditBalance(PDO $pdo, ?int $uid, string $email): int
    {
        $sql = "SELECT l.kind, l.amount_cents, l.created_at FROM order_ledger l JOIN orders o ON o.id = l.order_id
                WHERE l.kind IN ('credit_issued', 'credit_used') AND " . ($uid ? 'o.user_id = ?' : 'o.user_id IS NULL AND LOWER(o.bill_email) = LOWER(?)') . ' ORDER BY l.created_at, l.id';
        $st = $pdo->prepare($sql); $st->execute([$uid ?: $email]);
        $lots = [];   // [cents left, good until]
        $gone = function (int $at) use (&$lots) { foreach ($lots as $i => $c) if ($c[1] < $at) unset($lots[$i]); };
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $at = strtotime((string) $r['created_at']) ?: time();
            $gone($at);
            if ($r['kind'] === 'credit_issued') { $lots[] = [(int) $r['amount_cents'], strtotime('+' . self::CREDIT_DAYS . ' days', $at)]; continue; }
            $use = (int) $r['amount_cents'];
            foreach ($lots as $i => $c) { if ($use <= 0) break; $take = min($use, $c[0]); $lots[$i][0] -= $take; $use -= $take; }
        }
        $gone(time());
        return (int) array_sum(array_column($lots, 0));
    }

    /** When a credit given now runs out, for the email that tells them about it. */
    public static function creditUntil(): string { return date('F j, Y', strtotime('+' . self::CREDIT_DAYS . ' days')); }

    // ---- what staff do (E-Commerce → an order) -----------------------------------------------------------------------

    /**
     * A credit on the customer's account (full or partial), in place of a refund. Created in QuickBooks as a credit memo
     * for the customer, so the books and the next invoice see it.
     */
    public static function credit(PDO $pdo, int $oid, int $cents, string $note, int $actor): void
    {
        $o = self::paidOrder($pdo, $oid);
        self::sameEnv($o);
        $left = self::money($pdo, $oid)['net'] - self::money($pdo, $oid)['credited'];
        if ($cents > max(0, $left)) throw new RuntimeException('That\'s more than this order has left to credit (' . self::usd($left) . ').');
        require_once __DIR__ . '/QuickBooksPay.php';
        $key = 'credit-' . $oid . '-' . substr(hash('sha256', $cents . '|' . $note . '|' . date('YmdHi')), 0, 12);
        $ref = QuickBooksPay::creditMemo($pdo, $o, $cents, $note, $key);
        self::record($pdo, $oid, 'credit_issued', $cents, $key, 'account credit', $ref, $note, $actor);
        self::event($pdo, $oid, 'credited', self::usd($cents) . ' credit on the customer\'s account' . ($note !== '' ? ': ' . $note : ''), $actor);
        self::tell($o, 'A credit on your Traversence account', 'We\'ve put a credit of ' . self::usd($cents) . ' on your account for order #' . self::no($o) . ($note !== '' ? " ($note)" : '') . ".\nIt's used toward your next order, and is good until " . self::creditUntil() . '.');
    }

    /** Work with QuickBooks on an order only in the mode it was made in (the sandbox/production switch). */
    public static function sameEnv(array $o): void
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $env = QuickBooksPay::env();
        $oe = (string) ($o['qb_env'] ?? '');
        if ($env === 'mock' || $oe === '' || $oe === $env) return;
        throw new RuntimeException('Order #' . self::no($o) . ' was made in the QuickBooks ' . $oe . ($oe === 'sandbox' ? ' (testing)' : '') . '. Switch E-Commerce → Payments to ' . ucfirst($oe) . ' to do this with QuickBooks.');
    }

    /** What's left to refund on an order: paid, less refunds, disputes lost and credits already given. */
    public static function refundable(PDO $pdo, int $oid): int
    {
        $m = self::money($pdo, $oid);
        return max(0, $m['net'] - $m['credited']);
    }

    private static function checkRefund(PDO $pdo, int $oid, int $cents, string $reason): void
    {
        if (trim($reason) === '') throw new RuntimeException('Say why it\'s refunded: the policy is fix first, then credit.');
        $left = self::refundable($pdo, $oid);
        $m = self::money($pdo, $oid);
        if ($cents > $left) throw new RuntimeException('That\'s more than was paid and not yet refunded or credited (' . self::usd($left) . ($m['credited'] ? ', after the ' . self::usd($m['credited']) . ' credit' : '') . ').');
    }

    /**
     * A refund, the last resort (full or partial), started here: the card goes back through QuickBooks Payments, the
     * books get a Refund Receipt, then the order is put right ($revoke: line ids; a full refund takes back every line)
     * and the customer is emailed. Returns a warning for our team ('' when all went through).
     */
    public static function refundThroughQuickBooks(PDO $pdo, int $oid, int $cents, string $reason, array $revoke, int $actor): string
    {
        $o = self::paidOrder($pdo, $oid);
        self::sameEnv($o);
        self::checkRefund($pdo, $oid, $cents, $reason);
        $key = 'rf' . $oid . '-' . substr(hash('sha256', $cents . '|' . trim($reason) . '|' . date('YmdH')), 0, 16);   // the same refund clicked twice is done once
        require_once __DIR__ . '/QuickBooksPay.php';
        $card = QuickBooksPay::refundCard($pdo, $o, $cents, $reason, $key);
        $warn = ''; $rr = '';
        try { $rr = QuickBooksPay::refundReceipt($pdo, $o, $cents, $reason, $key, $card); }
        catch (Throwable $e) { $warn = 'The card was refunded, but QuickBooks didn\'t take the Refund Receipt (' . $e->getMessage() . '). Make one in QuickBooks for the books.'; }
        $ref = mb_substr(trim(($rr !== '' ? 'Refund Receipt ' . $rr : '') . ($card !== '' ? ' · card ' . $card : ''), ' ·'), 0, 60);
        if (!self::applyRefund($pdo, $o, $cents, $reason, $ref, $revoke, $actor, $key, 'card')) throw new RuntimeException('That refund is recorded already.');
        if ($warn !== '') self::event($pdo, $oid, 'needs_books', $warn, $actor);
        return $warn;
    }

    /** Records a refund already made in QuickBooks (by hand, with its Refund Receipt number). */
    public static function refund(PDO $pdo, int $oid, int $cents, string $reason, string $qbRef, array $revoke, int $actor): void
    {
        $o = self::paidOrder($pdo, $oid);
        self::checkRefund($pdo, $oid, $cents, $reason);
        $key = 'refund-' . $oid . '-' . substr(hash('sha256', $cents . '|' . $qbRef . '|' . $reason), 0, 12);
        if (!self::applyRefund($pdo, $o, $cents, $reason, $qbRef !== '' ? 'Refund Receipt ' . $qbRef : '', $revoke, $actor, $key, 'quickbooks')) throw new RuntimeException('That refund is recorded already.');
    }

    /** The money, what the lines delivered, the history and the email, for a refund however it was made. False: a repeat. */
    private static function applyRefund(PDO $pdo, array $o, int $cents, string $reason, string $qbRef, array $revoke, ?int $actor, string $key, string $method): bool
    {
        $oid = (int) $o['id'];
        if (!self::record($pdo, $oid, 'refund', $cents, $key, $method, $qbRef, $reason, $actor)) return false;
        $full = self::refundable($pdo, $oid) <= 0;
        $ids = $full ? array_map(fn ($l) => (int) $l['id'], self::lines($pdo, $oid)) : array_map('intval', $revoke);
        $taken = self::takeBack($pdo, $oid, $ids, 'refunded', $actor);
        self::event($pdo, $oid, 'refunded', self::usd($cents) . ($full ? ' (all of it)' : '') . ': ' . $reason . ($qbRef !== '' ? ' · ' . $qbRef : '') . ($taken ? ' · taken back: ' . implode(', ', $taken) : ''), $actor);
        self::tell($o, 'Your refund for order #' . self::no($o), 'We\'ve refunded ' . self::usd($cents) . ' for order #' . self::no($o) . ".\nIt goes back to the card or account you paid with; your bank may take a few days to show it."
            . ($taken ? "\n\nThe refunded GO Codes are no longer active." : ''));
        return true;
    }

    // ---- what QuickBooks tells us (the webhook, or "Check QuickBooks") -----------------------------------------------

    /**
     * A Refund Receipt or credit memo made in QuickBooks. Ours (tagged [TRV:…]) are already recorded. Otherwise, matched
     * to the customer's paid orders: a full refund or a credit with exactly one possible order is recorded by itself;
     * anything else waits in the inbox (E-Commerce → Orders) for a person to say which order, and which items.
     * Returns what happened: ours, done, recorded, inbox (new), queued (waiting already) or skip.
     */
    public static function fromQuickBooks(PDO $pdo, string $entity, array $doc): string
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $kind = $entity === 'RefundReceipt' ? 'refund' : 'credit';
        $id = (string) ($doc['Id'] ?? '');
        if ($id === '' || !in_array($entity, ['RefundReceipt', 'CreditMemo'], true)) return 'skip';
        if (QuickBooksPay::isOurs($doc)) return 'ours';
        $key = 'qb-' . ($kind === 'refund' ? 'rr' : 'cm') . '-' . $id;
        $st = $pdo->prepare('SELECT 1 FROM order_ledger WHERE request_key = ?'); $st->execute([$key]);
        if ($st->fetchColumn()) return 'done';
        $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('order_inbox') . ' WHERE kind = ? AND qb_id = ?'); $st->execute([$kind, $id]);
        if ($st->fetchColumn()) return 'queued';
        $cents = (int) round(((float) ($doc['TotalAmt'] ?? 0)) * 100);
        if ($cents <= 0) return 'skip';
        $cust = (string) ($doc['CustomerRef']['value'] ?? '');
        $ref = (string) ($doc['DocNumber'] ?? $id);
        $label = ($kind === 'refund' ? 'Refund Receipt ' : 'Credit memo ') . $ref;
        $cands = self::candidates($pdo, $cust);
        if (!$cands) return 'skip';   // a customer with no paid orders from the site (something else the company sells): not ours
        $fit = array_values(array_filter($cands, fn ($o) => self::refundable($pdo, (int) $o['id']) >= $cents));
        $why = '';
        if (count($fit) === 1 && count($cands) === 1) {
            $o = $fit[0]; $oid = (int) $o['id'];
            if ($kind === 'credit') {
                self::record($pdo, $oid, 'credit_issued', $cents, $key, 'account credit', $label, 'Made in QuickBooks');
                self::event($pdo, $oid, 'credited', self::usd($cents) . ' credit: ' . $label . ' made in QuickBooks');
                return 'recorded';
            }
            if ($cents === self::refundable($pdo, $oid)) {
                self::applyRefund($pdo, $o, $cents, 'Refunded in QuickBooks', $label, [], null, $key, 'quickbooks');
                return 'recorded';
            }
            $why = 'Part of the order was refunded: which items, if any, should stop working?';
        } elseif (!$fit) $why = 'It\'s more than any of this customer\'s orders has left to refund.';
        else {
            $exact = array_values(array_filter($fit, fn ($o) => self::refundable($pdo, (int) $o['id']) === $cents));
            if (count($exact) === 1) $why = 'More than one of this customer\'s orders could be the one; order #' . (int) $exact[0]['id'] . ' has exactly that left.';
            elseif ($exact) $why = count($exact) . ' of this customer\'s orders have exactly that left: check the date and card in QuickBooks.';
            else $why = 'More than one of this customer\'s orders could be the one.';
            usort($cands, fn ($a, $b) => (self::refundable($pdo, (int) $b['id']) === $cents) <=> (self::refundable($pdo, (int) $a['id']) === $cents));   // exact amounts first
        }
        $pdo->prepare('INSERT IGNORE INTO ' . Database::t('order_inbox') . ' (kind, qb_id, qb_ref, amount_cents, customer, qb_customer_id, txn_date, candidates, why) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$kind, $id, mb_substr($ref, 0, 60), $cents, mb_substr((string) ($doc['CustomerRef']['name'] ?? ''), 0, 160), $cust,
                       preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($doc['TxnDate'] ?? '')) ? $doc['TxnDate'] : null,
                       implode(',', array_map(fn ($o) => (int) $o['id'], $cands)), $why]);
        try { require_once __DIR__ . '/QuickBooksPay.php'; $pdo->prepare('UPDATE ' . Database::t('order_inbox') . ' SET qb_env = ? WHERE kind = ? AND qb_id = ? AND qb_env IS NULL')->execute([QuickBooksPay::env(), $kind, $id]); } catch (Throwable) {}   // before 2026-12-07_inbox_mode.sql
        return 'inbox';
    }

    /** A QuickBooks customer's paid orders (by the customer on the order, or by the customer's invoices). */
    private static function candidates(PDO $pdo, string $cust): array
    {
        if ($cust === '') return [];
        $inv = QuickBooksPay::customerInvoices($pdo, $cust);
        $sql = "SELECT * FROM orders WHERE status IN ('paid', 'part_refunded', 'disputed')" . (self::hasCol($pdo, 'qb_env') ? " AND qb_env = " . $pdo->quote(QuickBooksPay::env() === 'sandbox' ? 'sandbox' : 'production') : '') . " AND (qb_customer_id = ?" . ($inv ? ' OR invoice_id IN (' . implode(',', array_fill(0, count($inv), '?')) . ')' : '') . ') ORDER BY id DESC LIMIT 50';
        $st = $pdo->prepare($sql); $st->execute(array_merge([$cust], $inv));
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Is this orders column there yet (a migration may not have run)? */
    /** Is this a sandbox (test) order: made while E-Commerce → Payments was on the QuickBooks sandbox? */
    public static function isTest(array $o): bool { return ($o['qb_env'] ?? '') === 'sandbox'; }

    /** The number people see: a real order's own sequence, a sandbox order's "S-3" (2026-12-29_order_numbers.sql). */
    public static function no(array $o): string
    {
        if (self::isTest($o)) return 'S-' . (int) (($o['test_no'] ?? 0) ?: $o['id']);
        return (string) (int) (($o['order_no'] ?? 0) ?: $o['id']);
    }

    /** Give an order its number once it knows its QuickBooks mode: the next real one, or the next sandbox one. */
    public static function number(PDO $pdo, int $oid): void
    {
        if (!self::hasCol($pdo, 'order_no') || !self::hasCol($pdo, 'test_no')) return;
        $o = self::get($pdo, $oid); if (!$o) return;
        $col = self::isTest($o) ? 'test_no' : 'order_no';
        if ((int) ($o[$col] ?? 0)) return;
        $n = (int) $pdo->query("SELECT COALESCE(MAX($col), 0) + 1 FROM orders")->fetchColumn();   // (two steps: MySQL won't read the table it's updating)
        $pdo->prepare("UPDATE orders SET $col = ? WHERE id = ? AND $col IS NULL")->execute([$n, $oid]);
    }

    /** An order found by the number people see ("12", "#12", "S-3"), else by its id. */
    public static function byNo(PDO $pdo, string $no): ?array
    {
        $no = strtoupper(trim(ltrim(trim($no), '#')));
        if (self::hasCol($pdo, 'test_no') && preg_match('/^S-?(\d+)$/', $no, $m)) { $st = $pdo->prepare("SELECT * FROM orders WHERE test_no = ? AND qb_env = 'sandbox'"); $st->execute([(int) $m[1]]); return $st->fetch(PDO::FETCH_ASSOC) ?: null; }
        if (!ctype_digit($no)) return null;
        if (self::hasCol($pdo, 'order_no')) { $st = $pdo->prepare("SELECT * FROM orders WHERE order_no = ? AND (qb_env IS NULL OR qb_env <> 'sandbox')"); $st->execute([(int) $no]); if ($r = $st->fetch(PDO::FETCH_ASSOC)) return $r; }
        return self::get($pdo, (int) $no);
    }

    public static function hasCol(PDO $pdo, string $col): bool
    {
        static $c = [];
        if (!isset($c[$col])) { try { $pdo->query('SELECT `' . preg_replace('/\W/', '', $col) . '` FROM orders LIMIT 0'); $c[$col] = true; } catch (Throwable) { $c[$col] = false; } }
        return $c[$col];
    }

    public static function inbox(PDO $pdo, string $status = 'open'): array
    {
        try {   // only the mode we're in: the sandbox company's refunds never show in Production (2026-12-07_inbox_mode.sql)
            require_once __DIR__ . '/QuickBooksPay.php';
            $st = $pdo->prepare('SELECT * FROM ' . Database::t('order_inbox') . ' WHERE status = ? AND qb_env = ? ORDER BY id DESC LIMIT 100'); $st->execute([$status, QuickBooksPay::env()]);
            return $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) {}
        try { $st = $pdo->prepare('SELECT * FROM ' . Database::t('order_inbox') . ' WHERE status = ? ORDER BY id DESC LIMIT 100'); $st->execute([$status]); return $st->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable) { return []; }   // before 2026-12-03_qb_refunds.sql
    }

    public static function inboxItem(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('order_inbox') . ' WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** A person says which order a refund or credit made in QuickBooks belongs to (and, for a refund, which items stop). */
    public static function inboxApply(PDO $pdo, int $inboxId, int $oid, array $revoke, int $actor): void
    {
        $i = self::inboxItem($pdo, $inboxId);
        if (!$i || $i['status'] !== 'open') throw new RuntimeException('That one is dealt with already.');
        $o = self::paidOrder($pdo, $oid);
        $cents = (int) $i['amount_cents'];
        $label = ($i['kind'] === 'refund' ? 'Refund Receipt ' : 'Credit memo ') . $i['qb_ref'];
        if ($i['kind'] === 'refund') {
            if ($cents > self::refundable($pdo, $oid)) throw new RuntimeException('That\'s more than this order has left to refund (' . self::usd(self::refundable($pdo, $oid)) . '). Pick another order.');
            self::applyRefund($pdo, $o, $cents, 'Refunded in QuickBooks', $label, $revoke, $actor, 'qb-rr-' . $i['qb_id'], 'quickbooks');
        } else {
            self::record($pdo, $oid, 'credit_issued', $cents, 'qb-cm-' . $i['qb_id'], 'account credit', $label, 'Made in QuickBooks', $actor);
            self::event($pdo, $oid, 'credited', self::usd($cents) . ' credit: ' . $label . ' made in QuickBooks', $actor);
        }
        $pdo->prepare("UPDATE " . Database::t('order_inbox') . " SET status = 'done', order_id = ?, actor_user_id = ?, done_at = NOW() WHERE id = ?")->execute([$oid, $actor, $inboxId]);
    }

    /** Not for one of our orders (a refund for something else the company sells): kept, out of the way. */
    public static function inboxDismiss(PDO $pdo, int $inboxId, int $actor): void
    {
        $pdo->prepare("UPDATE " . Database::t('order_inbox') . " SET status = 'dismissed', actor_user_id = ?, done_at = NOW() WHERE id = ? AND status = 'open'")->execute([$actor, $inboxId]);
    }

    /** Asks QuickBooks for the last 45 days of Refund Receipts and credit memos (in case a webhook was missed). */
    public static function checkQuickBooks(PDO $pdo): array
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $n = ['recorded' => 0, 'inbox' => 0];
        foreach (['RefundReceipt', 'CreditMemo'] as $ent) foreach (QuickBooksPay::recent($pdo, $ent) as $doc) {
            $r = self::fromQuickBooks($pdo, $ent, (array) $doc);
            if (isset($n[$r])) $n[$r]++;
        }
        return $n;
    }

    /** A card dispute (chargeback) was opened: the money is held by the bank, and what the order delivered is paused. */
    public static function chargeback(PDO $pdo, int $oid, int $cents, string $ref, int $actor): void
    {
        self::paidOrder($pdo, $oid);
        if (self::disputeOpen($pdo, $oid)) throw new RuntimeException('A dispute is already open on this order.');
        self::event($pdo, $oid, 'chargeback', self::usd($cents) . ' disputed' . ($ref !== '' ? ' · ' . $ref : ''), $actor);
        self::record($pdo, $oid, 'chargeback', $cents, 'chargeback-' . $oid . '-' . substr(hash('sha256', $ref . '|' . $cents . '|' . date('YmdHis')), 0, 12), 'card', $ref, 'Dispute opened', $actor);
        self::pause($pdo, $oid, true);
    }

    /** The dispute's outcome: won (money back, things back on) or lost (the same as a refund). */
    public static function chargebackResolved(PDO $pdo, int $oid, bool $won, int $actor): void
    {
        if (!self::disputeOpen($pdo, $oid)) throw new RuntimeException('There\'s no open dispute on this order.');
        $st = $pdo->prepare("SELECT amount_cents FROM order_ledger WHERE order_id = ? AND kind = 'chargeback' ORDER BY id DESC LIMIT 1"); $st->execute([$oid]);
        $cents = (int) $st->fetchColumn();
        self::event($pdo, $oid, $won ? 'chargeback_won' : 'chargeback_lost', $won ? 'Dispute won: the money came back' : 'Dispute lost', $actor);
        if ($won) {
            self::record($pdo, $oid, 'chargeback_reversed', $cents, 'chargeback-won-' . $oid . '-' . date('YmdHis'), 'card', '', 'Dispute won', $actor);
            self::pause($pdo, $oid, false);
        } else {
            self::settle($pdo, $oid);
            self::takeBack($pdo, $oid, array_map(fn ($l) => (int) $l['id'], self::lines($pdo, $oid)), 'charged back', $actor);
        }
    }

    /**
     * Fix it, the first step of the policy: our team corrects what a line delivered (a GO Code's link, number or card).
     * The printed QR stays the same; trvgo.us serves the corrected one at once (Wi-Fi: a new picture to download).
     */
    public static function fix(PDO $pdo, int $oid, int $lineId, array $fields, string $title, string $why, int $actor): array
    {
        $l = null;
        foreach (self::lines($pdo, $oid) as $x) if ((int) $x['id'] === $lineId) $l = $x;
        if (!$l || $l['product'] !== 'go_code' || !$l['ref_id']) throw new RuntimeException('That line can\'t be fixed here.');
        if ($l['status'] === 'refunded') throw new RuntimeException('That code was refunded, so it\'s switched off.');
        require_once __DIR__ . '/QrIssue.php';
        $r = QrIssue::staffFix($pdo, (int) $l['ref_id'], $fields, $title, $actor);
        if ($title !== '') $pdo->prepare('UPDATE order_lines SET title = ? WHERE id = ?')->execute([mb_substr(trim($title), 0, 160), $lineId]);
        self::event($pdo, $oid, 'fixed', ($r['changed'] ? 'Changed ' . implode(', ', $r['changed']) : 'Saved, nothing changed') . ($why !== '' ? ': ' . $why : '')
            . ($r['direct'] ? ' (a Wi-Fi code: the customer downloads the new picture)' : ''), $actor, $lineId);
        return $r;
    }

    /** Our team pauses a line's GO Code (it shows "not active" when scanned) or turns it back on, without a refund. */
    public static function pauseLine(PDO $pdo, int $oid, int $lineId, bool $off, string $why, int $actor): void
    {
        $l = null;
        foreach (self::lines($pdo, $oid) as $x) if ((int) $x['id'] === $lineId) $l = $x;
        if (!$l || $l['product'] !== 'go_code' || !$l['ref_id'] || $l['status'] === 'refunded') throw new RuntimeException('That code can\'t be paused here.');
        if (!$off && self::disputeOpen($pdo, $oid)) throw new RuntimeException('A card dispute is open on this order: its codes stay paused until it\'s decided.');
        require_once __DIR__ . '/QrIssue.php';
        QrIssue::pause($pdo, (int) $l['ref_id'], $off);
        if ($off) $pdo->prepare('UPDATE short_codes s JOIN qr_issued q ON q.short_code_id = s.id SET s.off_reason = ? WHERE q.id = ?')->execute(['staff: paused' . ($why !== '' ? ': ' . mb_substr($why, 0, 170) : ''), (int) $l['ref_id']]);
        self::event($pdo, $oid, $off ? 'paused' : 'resumed', ($off ? 'Paused ' : 'Turned back on: ') . $l['title'] . ($why !== '' ? ' (' . $why . ')' : ''), $actor, $lineId);
    }

    /** A note for our team in the order's history (never shown to the customer). */
    public static function note(PDO $pdo, int $oid, string $note, int $actor): void
    {
        $note = trim($note);
        if ($note === '') throw new RuntimeException('Write the note first.');
        if (!self::get($pdo, $oid)) throw new RuntimeException('That order isn\'t here.');
        self::event($pdo, $oid, 'note', $note, $actor);
    }

    /** Cancels an order still waiting for payment: nothing was paid; its GO Codes go back to the cart. */
    public static function cancelUnpaid(PDO $pdo, int $oid, string $why, int $actor): void
    {
        $o = self::get($pdo, $oid);
        if (!$o || !in_array($o['status'], ['pending', 'draft', 'sent'], true)) throw new RuntimeException('Only an order that isn\'t paid can be cancelled.');
        $pdo->prepare("UPDATE orders SET status = 'void', note = ? WHERE id = ?")->execute([mb_substr($why, 0, 300), $oid]);
        $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE order_id = ?")->execute([$oid]);
        $pdo->prepare("UPDATE qr_issued SET status = 'cart', order_id = NULL WHERE order_id = ? AND status = 'pending'")->execute([$oid]);
        if (!empty($o['promo_id'])) { require_once __DIR__ . '/Promotions.php'; if (Promotions::ready($pdo)) Promotions::release($pdo, $oid); }   // a promo code used on it can be used again
        self::event($pdo, $oid, 'cancelled', $why !== '' ? $why : 'Cancelled before payment', $actor ?: null);
        // its QuickBooks invoice is voided too, so its page can't take a payment for a cancelled order (the survey, #18)
        if (!empty($o['invoice_id'])) {
            require_once __DIR__ . '/QuickBooksPay.php';
            $env = QuickBooksPay::env(); $oe = (string) ($o['qb_env'] ?? '');
            $no = $oe !== '' && $oe !== $env && $env !== 'mock' ? 'it was made in the QuickBooks ' . $oe . ', and Payments is on ' . $env . ' now' : QuickBooksPay::voidInvoice($pdo, (string) $o['invoice_id']);
            self::event($pdo, $oid, $no === '' ? 'invoice_voided' : 'needs_books', $no === '' ? 'QuickBooks invoice ' . $o['invoice_no'] . ' voided' : 'Void QuickBooks invoice ' . $o['invoice_no'] . ' by hand: ' . $no, $actor ?: null);
        }
    }

    /** A card charge that got no answer (QuickBooks Payments timed out, so it may have gone through): not a decline. */
    public static function unanswered(Throwable $e): bool
    {
        // only QuickBooks Payments' own "no answer" words (chargeCard, chargeSaved): a decline or a refusal says Nothing was charged
        return (bool) preg_match('/didn.t answer|can.t tell yet whether|didn.t say which charge/i', $e->getMessage());
    }

    /**
     * This member's order whose card got no answer in the last two hours, or null (the survey, #9): a new payment waits for
     * it, so a retry after a timeout never charges twice. Our team settles it (paid, or voided) from the order.
     */
    public static function cardUnknown(PDO $pdo, int $uid): ?array
    {
        if ($uid <= 0) return null;
        $st = $pdo->prepare("SELECT o.* FROM orders o JOIN order_events e ON e.order_id = o.id AND e.event = 'card_unknown' WHERE o.user_id = ? AND o.status = 'pending' AND e.created_at > NOW() - INTERVAL 2 HOUR ORDER BY o.id DESC LIMIT 1");
        $st->execute([$uid]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Words for a member whose last card got no answer. */
    public static function cardUnknownWords(array $o): string
    {
        return 'Your last payment (order #' . self::no($o) . ') got no answer from the card processor, so it may have gone through. Nothing more was charged. We\'re checking it and will email you; don\'t pay again. Questions: support@traversence.com.';
    }

    // ---- helpers -----------------------------------------------------------------------------------------------------

    private static function paidOrder(PDO $pdo, int $oid): array
    {
        $o = self::get($pdo, $oid);
        if (!$o) throw new RuntimeException('That order isn\'t here.');
        if (self::money($pdo, $oid)['paid'] <= 0) throw new RuntimeException('Nothing has been paid on this order yet.');
        return $o;
    }

    /** Takes back what lines delivered (a GO Code is switched off: its link shows "not active"). Returns their titles. */
    private static function takeBack(PDO $pdo, int $oid, array $lineIds, string $why, ?int $actor): array
    {
        $done = [];
        foreach (self::lines($pdo, $oid) as $l) {
            if (!in_array((int) $l['id'], $lineIds, true) || $l['status'] === 'refunded') continue;
            $pdo->prepare("UPDATE order_lines SET status = 'refunded' WHERE id = ?")->execute([(int) $l['id']]);
            if ($l['product'] === 'go_code' && $l['ref_id']) {
                require_once __DIR__ . '/QrIssue.php';
                QrIssue::revoke($pdo, (int) $l['ref_id'], $why);
            }
            $done[] = (string) $l['title'];
        }
        return $done;
    }

    /** Pauses (or restores) what a disputed order delivered. */
    private static function pause(PDO $pdo, int $oid, bool $off): void
    {
        require_once __DIR__ . '/QrIssue.php';
        foreach (self::lines($pdo, $oid) as $l) if ($l['product'] === 'go_code' && $l['ref_id'] && $l['status'] !== 'refunded') QrIssue::pause($pdo, (int) $l['ref_id'], $off);
    }

    /** Emails the customer (never fails the action). */
    private static function tell(array $o, string $subject, string $body): void
    {
        if (!filter_var((string) $o['bill_email'], FILTER_VALIDATE_EMAIL)) return;
        try {
            require_once __DIR__ . '/Mailer.php';
            Mailer::send((string) $o['bill_email'], $subject, $body . "\n\nQuestions? Reply to this email, or write to support@traversence.com.\n\nTraversence", (string) $o['bill_name'] ?: null);
        } catch (Throwable $e) { error_log('orders email: ' . $e->getMessage()); }
    }

    public static function usd(int $cents): string { return ($cents < 0 ? '−' : '') . '$' . number_format(abs($cents) / 100, 2); }
}
