<?php
// app/lib/Billing.php — plans and subscriptions (decisions/0108 step 3; Master AOS v44 §5).
//
// A subscription is a plan for a listing (Free, Basic, Core, Strategic, Cornerstone) or for a person (Free, Plus,
// Pro), monthly or yearly, with add-ons (storage packs, AI credit packs). The plan's price is the AOS's; yearly is
// 10 months for 12, on the plan only: add-ons are full price, billed on the plan's schedule (one renewal date, one
// charge). The card is kept on file in QuickBooks Payments; each renewal charges it (option B) and writes a Sales
// Receipt into QuickBooks. A declined renewal is tried again 3 and 7 days later, then the account drops to Free (the
// listing stays up). A trial (30, 60 or 90 days, no commitment) ends on Free unless the owner chooses to keep the plan;
// reminders go 5 days and 1 day before, and on the day. The listing's tier (entities.plan_tier) follows its plan.
// Charges are never made twice: each has a key, and QuickBooks Payments does a key once.
declare(strict_types=1);

require_once __DIR__ . '/QuickBooksPay.php';

final class Billing
{
    // key => [name, for, monthly price (cents), storage GB, AI credits a month, the listing's tier]
    public const PLANS = [
        'free'          => ['Free', 'listing', 0, 2, 0, 'free'],
        'basic'         => ['Basic Partner', 'listing', 2995, 10, 10, 'basic'],
        'core'          => ['Core Partner', 'listing', 7995, 25, 50, 'core'],
        'strategic'     => ['Strategic Partner', 'listing', 22995, 100, 250, 'strategic'],
        'cornerstone'   => ['Cornerstone', 'listing', 39995, 250, 500, 'cornerstone'],
        'personal_free' => ['Personal', 'user', 0, 2, 0, ''],
        'personal_plus' => ['Personal Plus', 'user', 495, 25, 10, ''],
        'personal_pro'  => ['Personal Pro', 'user', 995, 50, 25, ''],
    ];
    // key => [name, monthly price (cents), storage GB, AI credits a month] — the same for personal accounts and listings
    public const ADDONS = [
        'storage_25'  => ['+25 GB storage', 295, 25, 0],
        'storage_50'  => ['+50 GB storage', 595, 50, 0],
        'storage_100' => ['+100 GB storage', 1195, 100, 0],
        'storage_250' => ['+250 GB storage', 2895, 250, 0],
        'storage_1tb' => ['+1 TB storage', 11495, 1000, 0],
        'storage_5tb' => ['+5 TB storage', 57495, 5000, 0],
        'ai_50'       => ['+50 AI Assist credits a month', 2995, 0, 50],
    ];
    public const TRIAL_DAYS = [30, 60, 90];
    public const SELF_TRIAL_DAYS = 7;   // Try Pro free for 7 days (decisions/0154 §5): once an account, no card, no AI credits
    public const RETRY_DAYS = [3, 7];   // after a declined renewal; then it ends

    public static function ready(PDO $pdo): bool { try { $pdo->query('SELECT 1 FROM subscriptions LIMIT 0'); return true; } catch (Throwable) { return false; } }

    private static function today(): string { return date('Y-m-d', (int) (getenv('BILLING_NOW') ? strtotime((string) getenv('BILLING_NOW')) : time())); }   // BILLING_NOW: tests only

    /** A plan's price for a cycle: a year is 10 months (the annual discount, on plans only). */
    public static function planPrice(string $plan, string $cycle): int
    {
        $m = self::PLANS[$plan][2] ?? 0;
        return $cycle === 'year' ? $m * 10 : $m;
    }

    /** An add-on's price for a cycle: full price, 12 months for a year. */
    public static function addonPrice(string $addon, string $cycle, int $qty = 1): int
    {
        return (self::ADDONS[$addon][1] ?? 0) * max(1, $qty) * ($cycle === 'year' ? 12 : 1);
    }

    public static function usd(int $c): string { return '$' . number_format($c / 100, 2); }

    /** A plan line with a percentage off: [line, cents off]. */
    private static function promoLine(array $l, int $pct): array
    {
        $off = (int) round((int) $l[1] * $pct / 100);
        return [[$l[0] . ' (' . $pct . '% off)', (int) $l[1] - $off], $off];
    }

    /** A subscription's promotion on this charge's plan line, if it has periods left. [lines, cents off]. */
    private static function withPromo(array $s, array $lines): array
    {
        if ((int) ($s['promo_left'] ?? 0) <= 0 || (int) ($s['promo_percent'] ?? 0) <= 0) return [$lines, 0];
        [$lines[0], $off] = self::promoLine($lines[0], (int) $s['promo_percent']);
        return [$lines, $off];
    }

    /** One period of the promotion used (255: every period, never runs out). */
    private static function promoUsed(PDO $pdo, int $sid): void
    {
        $pdo->prepare('UPDATE subscriptions SET promo_left = promo_left - 1 WHERE id = ? AND promo_left > 0 AND promo_left < 255')->execute([$sid]);
    }

    /** What a plan with these add-ons costs per cycle: ['lines' => [[title, cents]], 'total' => cents]. */
    public static function quote(string $plan, string $cycle, array $addons = [], int $promoPct = 0): array
    {
        if (!isset(self::PLANS[$plan])) throw new InvalidArgumentException('Choose a plan.');
        $per = $cycle === 'year' ? 'a year' : 'a month';
        $lines = [[self::PLANS[$plan][0] . ' plan, ' . $per . ($cycle === 'year' ? ' (10 months for 12)' : ''), self::planPrice($plan, $cycle)]];
        if ($promoPct > 0) [$lines[0]] = self::promoLine($lines[0], $promoPct);   // a promotion: the plan only, never the packs
        foreach ($addons as $a => $q) if (isset(self::ADDONS[$a]) && (int) $q > 0) $lines[] = [self::ADDONS[$a][0] . ((int) $q > 1 ? ' × ' . (int) $q : '') . ', ' . $per, self::addonPrice($a, $cycle, (int) $q)];
        return ['lines' => $lines, 'total' => array_sum(array_column($lines, 1))];
    }

    // ---- who it's for ------------------------------------------------------------------------------------------------

    /** The account: a listing (its name, its owner who pays) or a person. */
    public static function owner(PDO $pdo, string $type, int $id): array
    {
        if ($type === 'listing') {
            $st = $pdo->prepare('SELECT e.id, e.name, e.owner_user_id, e.plan_tier, u.email, u.display_name FROM entities e LEFT JOIN users u ON u.id = e.owner_user_id WHERE e.id = ?'); $st->execute([$id]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            if (!$r) throw new InvalidArgumentException('That listing isn\'t here.');
            return ['type' => 'listing', 'id' => $id, 'name' => (string) $r['name'], 'payer' => (int) $r['owner_user_id'], 'email' => (string) $r['email'], 'payer_name' => (string) $r['display_name'], 'tier' => (string) $r['plan_tier']];
        }
        if ($type !== 'user') throw new InvalidArgumentException('That isn\'t an account.');
        $st = $pdo->prepare('SELECT id, email, display_name FROM users WHERE id = ?'); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That account isn\'t here.');
        return ['type' => 'user', 'id' => $id, 'name' => (string) ($r['display_name'] ?: $r['email']), 'payer' => $id, 'email' => (string) $r['email'], 'payer_name' => (string) $r['display_name'], 'tier' => ''];
    }

    /** May this person manage the account's plan? Its owner (or a manager on the listing), or the person themself. */
    public static function canManage(PDO $pdo, int $uid, string $type, int $id): bool
    {
        if ($type === 'user') return $uid === $id;
        if (class_exists('Team') || is_file(__DIR__ . '/Team.php')) { require_once __DIR__ . '/Team.php'; if (Team::ready($pdo) && Team::can($pdo, $uid, $id, 'billing', 'edit')) return true; }
        $st = $pdo->prepare("SELECT 1 FROM entities WHERE id = ? AND owner_user_id = ? UNION SELECT 1 FROM listing_access WHERE entity_id = ? AND user_id = ? AND access_level IN ('owner','manager') LIMIT 1");
        try { $st->execute([$id, $uid, $id, $uid]); return (bool) $st->fetchColumn(); } catch (Throwable) { return false; }
    }

    /** The account's live subscription (not ended), or null (it's on Free). */
    public static function current(PDO $pdo, string $type, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare("SELECT * FROM subscriptions WHERE owner_type = ? AND owner_id = ? AND status <> 'ended' ORDER BY id DESC LIMIT 1"); $st->execute([$type, $id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function get(PDO $pdo, int $sid): array
    {
        $st = $pdo->prepare('SELECT * FROM subscriptions WHERE id = ?'); $st->execute([$sid]);
        $s = $st->fetch(PDO::FETCH_ASSOC);
        if (!$s) throw new InvalidArgumentException('That subscription isn\'t here.');
        return $s;
    }

    public static function addons(PDO $pdo, int $sid): array
    {
        $st = $pdo->prepare('SELECT * FROM subscription_addons WHERE sub_id = ? ORDER BY id'); $st->execute([$sid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function charges(PDO $pdo, int $sid): array
    {
        $st = $pdo->prepare('SELECT * FROM subscription_charges WHERE sub_id = ? ORDER BY id DESC LIMIT 50'); $st->execute([$sid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** What the account has: its plan, storage (GB) and AI credits a month, its plan's and its packs' together. */
    public static function allowance(PDO $pdo, string $type, int $id): array
    {
        $s = self::current($pdo, $type, $id);
        $plan = $s ? (string) $s['plan'] : ($type === 'user' ? 'personal_free' : 'free');
        $gb = self::PLANS[$plan][3] ?? 0; $ai = self::PLANS[$plan][4] ?? 0;
        if ($s && $s['status'] === 'trial' && (int) ($s['self_trial'] ?? 0)) $ai = 0;   // the free week of Pro: no AI credits (they cost us; decisions/0154 §5)
        if ($s && $s['status'] !== 'trial') foreach (self::addons($pdo, (int) $s['id']) as $a) { $gb += (self::ADDONS[$a['addon']][2] ?? 0) * (int) $a['qty']; $ai += (self::ADDONS[$a['addon']][3] ?? 0) * (int) $a['qty']; }
        return ['plan' => $plan, 'storage_gb' => $gb, 'ai_credits' => $ai];
    }

    // ---- starting, trials, changes ---------------------------------------------------------------------------------

    private static function addPeriod(string $from, string $cycle): string { return date('Y-m-d', strtotime($from . ($cycle === 'year' ? ' +1 year' : ' +1 month'))); }

    /**
     * Starts a paid plan: the card is kept on file, the first period charged, a receipt written and emailed. $token is
     * the card's one-time token from the browser. Returns the subscription.
     */
    public static function start(PDO $pdo, int $uid, string $type, int $id, string $plan, string $cycle, array $addons, string $token, ?int $staff = null, ?array $promo = null): array
    {
        $o = self::owner($pdo, $type, $id);
        if ((self::PLANS[$plan][1] ?? '') !== $type) throw new InvalidArgumentException('Choose one of the plans for this account.');
        if (self::planPrice($plan, 'month') === 0) throw new InvalidArgumentException('The free plan needs no card: it\'s what the account has without one.');
        if (!in_array($cycle, ['month', 'year'], true)) $cycle = 'month';
        $cur = self::current($pdo, $type, $id);
        if ($cur && $cur['status'] !== 'trial') throw new InvalidArgumentException('This account has a plan already: change it instead.');
        if (trim($token) === '') throw new InvalidArgumentException('Enter the card.');
        $addons = array_filter(array_map('intval', array_intersect_key($addons, self::ADDONS)), fn ($q) => $q > 0);
        $q = self::quote($plan, $cycle, $addons);
        $wallet = 'TRV-' . ($type === 'listing' ? 'L' : 'U') . $id;
        [$card, $label, $wcard] = self::cardFrom($pdo, $uid, $type, $id, $token);   // a wallet card ('wallet:<id>') or a new one, saved into the wallet (decisions/0166 §6a)
        $today = self::today();
        if ($cur) {   // a trial that's kept: the same subscription carries on, paid from today
            $sid = (int) $cur['id'];
            $pdo->prepare("UPDATE subscriptions SET plan = ?, cycle = ?, price_cents = ?, wallet = ?, card_id = ?, card_label = ?, cancel_at_end = 0, payer_id = ?, bill_name = ?, bill_email = ? WHERE id = ?")
                ->execute([$plan, $cycle, self::planPrice($plan, $cycle), $wallet, $card, $label, $uid ?: $o['payer'], $o['payer_name'] ?: $o['name'], $o['email'], $sid]);
        } else {
            $pdo->prepare("INSERT INTO subscriptions (owner_type, owner_id, plan, cycle, status, price_cents, period_start, period_end, payer_id, bill_name, bill_email, wallet, card_id, card_label, created_by)
                           VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
                ->execute([$type, $id, $plan, $cycle, self::planPrice($plan, $cycle), $today, self::addPeriod($today, $cycle), $uid ?: $o['payer'], $o['payer_name'] ?: $o['name'], $o['email'], $wallet, $card, $label, $staff]);
            $sid = (int) $pdo->lastInsertId();
        }
        $pdo->prepare('DELETE FROM subscription_addons WHERE sub_id = ?')->execute([$sid]);
        foreach ($addons as $a => $n) $pdo->prepare('INSERT INTO subscription_addons (sub_id, addon, qty, month_cents) VALUES (?, ?, ?, ?)')->execute([$sid, $a, $n, self::ADDONS[$a][1]]);
        if ($promo && ($promo['kind'] ?? '') === 'percent' && (int) $promo['percent'] > 0)   // a code: a percentage off the plan for its periods
            $pdo->prepare('UPDATE subscriptions SET promo_id = ?, promo_percent = ?, promo_left = ? WHERE id = ?')->execute([(int) $promo['id'], (int) $promo['percent'], (int) $promo['periods'] === 0 ? 255 : (int) $promo['periods'], $sid]);
        [$q['lines']] = self::withPromo(self::get($pdo, $sid), $q['lines']);
        try {
            self::charge($pdo, $sid, 'start', $q['lines'], 'sub' . $sid . '-start-' . $today);
        } catch (RuntimeException $x) {   // the first payment failed: nothing starts (the card stays in the wallet, unassigned)
            require_once __DIR__ . '/Orders.php';
            // no answer (it may have been charged): the plan is kept as it is, so trying again today reuses the same charge key
            // ('sub<id>-start-<day>') and QuickBooks makes it once; ending it here would start a new plan with a new key (the survey, #9)
            if (Orders::unanswered($x)) throw new RuntimeException('The card processor didn\'t answer, so it may have gone through. Nothing more will be charged: try again in a few minutes and it completes the same payment, never a second one.');
            $pdo->prepare('UPDATE subscriptions SET promo_id = NULL, promo_percent = 0, promo_left = 0 WHERE id = ?')->execute([$sid]);
            if ($cur) $pdo->prepare("UPDATE subscriptions SET cancel_at_end = 1, plan = ?, cycle = ? WHERE id = ?")->execute([$cur['plan'], $cur['cycle'], $sid]);
            else { $pdo->prepare('DELETE FROM subscription_addons WHERE sub_id = ?')->execute([$sid]); $pdo->prepare("UPDATE subscriptions SET status = 'ended', ended_at = NOW(), end_reason = 'first payment declined' WHERE id = ?")->execute([$sid]); }
            throw $x;
        }
        self::promoUsed($pdo, $sid);
        if ($wcard) { require_once __DIR__ . '/Wallet.php'; Wallet::assign($pdo, $wcard, 'plan', $sid); }   // the plan renews on this card: it's locked in the wallet
        $pdo->prepare("UPDATE subscriptions SET status = 'active', trial_ends = NULL, period_start = ?, period_end = ?, fails = 0, next_try = NULL, notices = '' WHERE id = ?")
            ->execute([$today, self::addPeriod($today, $cycle), $sid]);
        self::syncTier($pdo, $type, $id);
        return self::get($pdo, $sid);
    }

    /** A trial of a plan (staff or a promo): no card, no charge; it ends on Free unless the owner keeps the plan. */
    public static function trial(PDO $pdo, int $by, string $type, int $id, string $plan, int $days, bool $self = false): array
    {
        $o = self::owner($pdo, $type, $id);
        if ((self::PLANS[$plan][1] ?? '') !== $type || self::planPrice($plan, 'month') === 0) throw new InvalidArgumentException('Choose a paid plan for this account.');
        if ($self ? $days !== self::SELF_TRIAL_DAYS : !in_array($days, self::TRIAL_DAYS, true)) throw new InvalidArgumentException('A trial is 30, 60 or 90 days.');
        if (self::current($pdo, $type, $id)) throw new InvalidArgumentException('This account has a plan or a trial already.');
        $end = date('Y-m-d', strtotime(self::today() . " +$days days"));
        $pdo->prepare("INSERT INTO subscriptions (owner_type, owner_id, plan, cycle, status, price_cents, trial_ends, period_start, period_end, cancel_at_end, payer_id, bill_name, bill_email, created_by)
                       VALUES (?, ?, ?, 'month', 'trial', ?, ?, ?, ?, 1, ?, ?, ?, ?)")
            ->execute([$type, $id, $plan, self::planPrice($plan, 'month'), $end, self::today(), $end, $o['payer'] ?: null, $o['payer_name'] ?: $o['name'], $o['email'], $by ?: null]);
        $sid = (int) $pdo->lastInsertId();
        if ($self) { try { $pdo->prepare('UPDATE subscriptions SET self_trial = 1 WHERE id = ?')->execute([$sid]); } catch (PDOException) {} }
        self::syncTier($pdo, $type, $id);
        if ($o['email'] !== '') self::mail($o['email'], 'Your ' . $days . '-day ' . self::PLANS[$plan][0] . ' trial has started',
            "Hello" . ($o['payer_name'] !== '' ? ' ' . $o['payer_name'] : '') . ",\n\n" . $o['name'] . " now has " . self::PLANS[$plan][0] . " for $days days, free, with no commitment.\n\n"
            . "Your trial\n  Plan: " . self::PLANS[$plan][0] . "\n  Started: " . date('F j, Y', strtotime(self::today())) . "\n  Ends: " . date('F j, Y', strtotime($end)) . "\n  Charged today: nothing (no card needed)\n  After the trial: " . self::usd(self::planPrice($plan, 'month')) . " a month, only if you choose to keep it\n\n"
            . "To keep it, set up billing before " . date('F j', strtotime($end)) . ": add a card and choose Keep my plan:\n" . self::link($type, $id) . "\n\n"
            . "If you don't, it goes back to the Free plan on its own when the trial ends. Nothing is charged, and your listing and content stay; the paid tools pause.\n\n"
            . "We'll email you 5 days before it ends, the day before, and on the day. You can end the trial early any time on the Plans page.\n\n"
            . "Terms (plans and trials): " . rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/') . "/terms.php#plans\n");
        return self::get($pdo, $sid);
    }

    /** May this member start Try Pro free for 7 days? '' when yes, else why not: once an account (never a Pro plan or any
     *  trial before), Verified (email confirmed, 18+), no plan now (decisions/0154 §5). */
    public static function selfTrialWhyNot(PDO $pdo, int $uid): string
    {
        if (!self::ready($pdo)) return 'Plans aren\'t open yet.';
        if (self::current($pdo, 'user', $uid)) return 'You have a plan already.';
        $st = $pdo->prepare("SELECT 1 FROM subscriptions WHERE owner_type = 'user' AND owner_id = ? AND (plan = 'personal_pro' OR trial_ends IS NOT NULL) LIMIT 1"); $st->execute([$uid]);
        if ($st->fetchColumn()) return 'The free week of Pro is once an account, and yours has been used.';
        try { require_once __DIR__ . '/MemberVerification.php'; if (!MemberVerification::verified($pdo, $uid)) return 'Confirm your email and age first (Verified), then try Pro.'; } catch (Throwable) {}
        return '';
    }

    /** Try Pro free for 7 days: no card; it ends on Free unless kept (Keep my plan, with a card). */
    public static function selfTrial(PDO $pdo, int $uid): array
    {
        if (($why = self::selfTrialWhyNot($pdo, $uid)) !== '') throw new InvalidArgumentException($why);
        return self::trial($pdo, 0, 'user', $uid, 'personal_pro', self::SELF_TRIAL_DAYS, true);
    }

    /** A single month of a personal plan, paid once (decisions/0154 §5; app/lib/OneOffs.php charges it): the plan for a
     *  month, no card kept, nothing renews; it ends on Free on its own. Another month bought before it ends adds a month.
     *  Replaces a free trial; refuses when a renewing plan is on. */
    public static function oneMonth(PDO $pdo, int $uid, string $plan = 'personal_pro'): array
    {
        if ((self::PLANS[$plan][1] ?? '') !== 'user' || self::planPrice($plan, 'month') === 0) throw new InvalidArgumentException('Choose a paid personal plan.');
        $s = self::current($pdo, 'user', $uid);
        if ($s && (int) ($s['month_only'] ?? 0) && $s['status'] === 'active' && $s['plan'] === $plan) {   // another month on top
            $pdo->prepare('UPDATE subscriptions SET period_end = ? WHERE id = ?')->execute([self::addPeriod((string) $s['period_end'], 'month'), (int) $s['id']]);
            return self::get($pdo, (int) $s['id']);
        }
        if ($s && $s['status'] !== 'trial') throw new InvalidArgumentException('You have a plan already: change it on the Plans page.');
        if ($s) self::endNow($pdo, (int) $s['id'], 'replaced by a month of ' . self::PLANS[$plan][0]);
        $o = self::owner($pdo, 'user', $uid); $today = self::today();
        $pdo->prepare("INSERT INTO subscriptions (owner_type, owner_id, plan, cycle, status, price_cents, period_start, period_end, cancel_at_end, payer_id, bill_name, bill_email, created_by)
                       VALUES ('user', ?, ?, 'month', 'active', ?, ?, ?, 1, ?, ?, ?, ?)")
            ->execute([$uid, $plan, self::planPrice($plan, 'month'), $today, self::addPeriod($today, 'month'), $uid, $o['payer_name'] ?: $o['name'], $o['email'], $uid]);
        $sid = (int) $pdo->lastInsertId();
        try { $pdo->prepare('UPDATE subscriptions SET month_only = 1 WHERE id = ?')->execute([$sid]); } catch (PDOException) {}
        self::syncTier($pdo, 'user', $uid);
        return self::get($pdo, $sid);
    }

    /** May this member buy a single month? '' when yes, else why not. */
    public static function oneMonthWhyNot(PDO $pdo, int $uid, string $plan = 'personal_pro'): string
    {
        if (!self::ready($pdo)) return 'Plans aren\'t open yet.';
        $s = self::current($pdo, 'user', $uid);
        if ($s && $s['status'] !== 'trial' && !((int) ($s['month_only'] ?? 0) && $s['plan'] === $plan)) return 'You have a plan already: change it on the Plans page.';
        return '';
    }

    /** Puts a new card on file; a renewal that was declined is tried on it at once. */
    public static function setCard(PDO $pdo, int $sid, string $token): array
    {
        $s = self::get($pdo, $sid);
        $wallet = $s['wallet'] ?: 'TRV-' . ($s['owner_type'] === 'listing' ? 'L' : 'U') . $s['owner_id'];
        [$card, $label, $wcard] = self::cardFrom($pdo, (int) ($s['payer_id'] ?: 0), (string) $s['owner_type'], (int) $s['owner_id'], $token);
        $pdo->prepare('UPDATE subscriptions SET wallet = ?, card_id = ?, card_label = ? WHERE id = ?')->execute([$wallet, $card, $label, $sid]);
        if ($wcard) { require_once __DIR__ . '/Wallet.php'; Wallet::assign($pdo, $wcard, 'plan', $sid); }
        if ($s['status'] === 'past_due') self::renew($pdo, self::get($pdo, $sid), true);
        return self::get($pdo, $sid);
    }

    /**
     * The card a plan pays with (decisions/0166 §6a: plans pay from the account's wallet). $token: 'wallet:<id>' picks a
     * saved card; a one-time token saves a new card into the wallet. Returns [card ref, label, wallet card id]; before
     * the wallet's database update has run, the card is saved as before ([ref, label, 0]).
     */
    private static function cardFrom(PDO $pdo, int $uid, string $type, int $id, string $token): array
    {
        require_once __DIR__ . '/Wallet.php';
        if (Wallet::ready($pdo)) { $c = Wallet::resolve($pdo, $uid ?: ($type === 'user' ? $id : 0), $type, $id, $token); return [(string) $c['card_ref'], (string) $c['label'], (int) $c['id']]; }
        $wallet = 'TRV-' . ($type === 'listing' ? 'L' : 'U') . $id;
        [$card, $label] = QuickBooksPay::saveCard($pdo, $wallet, $token, 'card-' . $wallet . '-' . substr(hash('sha256', $token), 0, 10));
        return [$card, $label, 0];
    }

    /** Stops it at the end of the period (no refund mid-term), or undoes that. */
    public static function cancelAtEnd(PDO $pdo, int $sid, bool $stop): array
    {
        $s = self::get($pdo, $sid);
        if ($s['status'] === 'ended') throw new InvalidArgumentException('It has ended already.');
        if (!$stop && $s['status'] === 'trial' && $s['card_id'] === '') throw new InvalidArgumentException('To keep the plan after the trial, add a card and choose Keep my plan.');
        if (!$stop && $s['card_id'] === '') throw new InvalidArgumentException('To keep it renewing, add a card first (Change card), then choose to keep it.');   // a single month bought on its own
        $pdo->prepare('UPDATE subscriptions SET cancel_at_end = ? WHERE id = ?')->execute([$stop ? 1 : 0, $sid]);
        return self::get($pdo, $sid);
    }

    /** Ends it now (staff: a refund case, a duplicate). The account goes back to Free. */
    public static function endNow(PDO $pdo, int $sid, string $why): void
    {
        $s = self::get($pdo, $sid);
        $pdo->prepare("UPDATE subscriptions SET status = 'ended', ended_at = NOW(), end_reason = ? WHERE id = ?")->execute([mb_substr($why ?: 'ended by our team', 0, 40), $sid]);
        self::syncTier($pdo, $s['owner_type'], (int) $s['owner_id']);
    }

    /**
     * A bigger plan starts now, the difference for the rest of the period charged at once; a smaller one starts at the
     * renewal (the account keeps what it paid for until then).
     */
    public static function changePlan(PDO $pdo, int $sid, string $plan): array
    {
        $s = self::get($pdo, $sid);
        if ((self::PLANS[$plan][1] ?? '') !== $s['owner_type']) throw new InvalidArgumentException('Choose one of the plans for this account.');
        if ($s['status'] === 'trial') { $pdo->prepare('UPDATE subscriptions SET plan = ?, price_cents = ? WHERE id = ?')->execute([$plan, self::planPrice($plan, 'month'), $sid]); self::syncTier($pdo, $s['owner_type'], (int) $s['owner_id']); return self::get($pdo, $sid); }
        if ($s['status'] !== 'active') throw new InvalidArgumentException('Settle the card first, then change the plan.');
        $new = self::planPrice($plan, $s['cycle']); $old = (int) $s['price_cents'];
        if ($plan === $s['plan']) { $pdo->prepare('UPDATE subscriptions SET next_plan = NULL WHERE id = ?')->execute([$sid]); return self::get($pdo, $sid); }
        if ($new < $old || self::planPrice($plan, 'month') === 0) {   // smaller (or Free): at the renewal
            $pdo->prepare('UPDATE subscriptions SET next_plan = ? WHERE id = ?')->execute([$plan, $sid]);
            return self::get($pdo, $sid);
        }
        $diff = (int) round(($new - $old) * self::leftShare($s));
        if ($diff > 0) self::charge($pdo, $sid, 'upgrade', [['Move to ' . self::PLANS[$plan][0] . ' for the rest of this period', $diff]], 'sub' . $sid . '-up-' . $plan . '-' . self::today());
        $pdo->prepare('UPDATE subscriptions SET plan = ?, price_cents = ?, next_plan = NULL WHERE id = ?')->execute([$plan, $new, $sid]);
        self::syncTier($pdo, $s['owner_type'], (int) $s['owner_id']);
        return self::get($pdo, $sid);
    }

    /** What changing to $plan would do, without doing it: ['when' => 'now'|'renewal'|'same', 'charge' => cents now]. */
    public static function previewChange(array $s, string $plan): array
    {
        if ($plan === $s['plan']) return ['when' => 'same', 'charge' => 0];
        if ($s['status'] === 'trial') return ['when' => 'now', 'charge' => 0];
        $new = self::planPrice($plan, $s['cycle']); $old = (int) $s['price_cents'];
        if ($new < $old || self::planPrice($plan, 'month') === 0) return ['when' => 'renewal', 'charge' => 0];
        return ['when' => 'now', 'charge' => max(0, (int) round(($new - $old) * self::leftShare($s)))];
    }

    /** What adding a pack would charge now (the rest of the period). */
    public static function previewAddon(array $s, string $addon, int $qty = 1): int
    {
        return isset(self::ADDONS[$addon]) ? (int) round(self::addonPrice($addon, $s['cycle'], max(1, $qty)) * self::leftShare($s)) : 0;
    }

    /** How much of the current period is left (0–1). */
    private static function leftShare(array $s): float
    {
        $a = strtotime((string) $s['period_start']); $b = strtotime((string) $s['period_end']); $t = strtotime(self::today());
        return $b > $a ? max(0, min(1, ($b - $t) / ($b - $a))) : 0;
    }

    /** Adds a pack: charged now for the rest of the period, then renewing with the plan. */
    public static function addAddon(PDO $pdo, int $sid, string $addon, int $qty = 1): array
    {
        $s = self::get($pdo, $sid);
        if (!isset(self::ADDONS[$addon])) throw new InvalidArgumentException('Choose a pack.');
        if ($s['status'] !== 'active') throw new InvalidArgumentException($s['status'] === 'trial' ? 'Packs are added once the plan is kept (after the trial, or Keep my plan now).' : 'Settle the card first, then add a pack.');
        $qty = max(1, min(20, $qty));
        $cents = (int) round(self::addonPrice($addon, $s['cycle'], $qty) * self::leftShare($s));
        $pdo->prepare('INSERT INTO subscription_addons (sub_id, addon, qty, month_cents) VALUES (?, ?, ?, ?)')->execute([$sid, $addon, $qty, self::ADDONS[$addon][1]]);
        $aid = (int) $pdo->lastInsertId();
        if ($cents > 0) {
            try { self::charge($pdo, $sid, 'addon', [[self::ADDONS[$addon][0] . ($qty > 1 ? ' × ' . $qty : '') . ', until ' . date('M j, Y', strtotime((string) $s['period_end'])), $cents]], 'sub' . $sid . '-add-' . $aid); }
            catch (RuntimeException $x) { $pdo->prepare('DELETE FROM subscription_addons WHERE id = ?')->execute([$aid]); throw $x; }
        }
        return self::get($pdo, $sid);
    }

    /**
     * A one-off charge on the plan's card on file, with its QuickBooks receipt and email, like a pack: a business's domain
     * bought through us, or its yearly renewal (decisions/0139 §3). $key makes it happen once. Returns the charge id.
     */
    public static function chargeExtra(PDO $pdo, string $type, int $id, string $kind, array $lines, string $key): string
    {
        $s = self::current($pdo, $type, $id);
        if (!$s || !in_array($s['status'], ['active', 'trial'], true) || (string) $s['card_id'] === '') throw new RuntimeException('Add a card to your plan first (Plan & settings → Plans), then try again.', 402);
        return self::charge($pdo, (int) $s['id'], $kind, $lines, $key);
    }

    /** Takes a pack off at the renewal (or undoes that). */
    public static function removeAddon(PDO $pdo, int $sid, int $aid, bool $remove = true): void
    {
        $pdo->prepare('UPDATE subscription_addons SET remove_at_end = ? WHERE id = ? AND sub_id = ?')->execute([$remove ? 1 : 0, $aid, $sid]);
    }

    // ---- charging ---------------------------------------------------------------------------------------------------

    /** Charges the card on file for these lines, writes the receipt and emails it. Throws on a decline (recorded). */
    private static function charge(PDO $pdo, int $sid, string $kind, array $lines, string $key): string
    {
        $s = self::get($pdo, $sid);
        $done = $pdo->prepare("SELECT charge_id FROM subscription_charges WHERE req_key = ? AND status = 'paid'"); $done->execute([$key]);
        if ($c = $done->fetchColumn()) return (string) $c;   // already charged for this
        $total = array_sum(array_column($lines, 1));
        if ($s['card_id'] === '') throw new RuntimeException('There\'s no card on file.', 402);
        $o = self::owner($pdo, $s['owner_type'], (int) $s['owner_id']);
        require_once __DIR__ . '/TestAccounts.php';
        $test = !empty($o['payer']) && TestAccounts::isTestUser($pdo, (int) $o['payer']);   // a test account pays in sandbox only (decisions/0145 §3)
        try {
            if ($test) QuickBooksPay::useEnv('sandbox');
            try { $cid = QuickBooksPay::chargeSaved($pdo, (string) $s['card_id'], $total, 'Traversence ' . self::PLANS[$s['plan']][0] . ' for ' . $o['name'], $key); }
            catch (Throwable $x) { if ($test) QuickBooksPay::useEnv(null); throw $x; }   // the receipt below stays in the sandbox too
        } catch (RuntimeException $x) {
            $pdo->prepare("INSERT INTO subscription_charges (sub_id, kind, amount_cents, items, status, error, req_key) VALUES (?, ?, ?, ?, 'failed', ?, ?)
                           ON DUPLICATE KEY UPDATE status = 'failed', error = VALUES(error)")
                ->execute([$sid, $kind, $total, json_encode($lines, JSON_UNESCAPED_UNICODE), mb_substr($x->getMessage(), 0, 300), $key]);
            throw $x;
        }
        $rid = '';
        try { $rid = QuickBooksPay::salesReceipt($pdo, (int) ($s['payer_id'] ?: 0), ['name' => $s['bill_name'] ?: $o['name'], 'email' => $s['bill_email'] ?: $o['email']], $lines, $cid, $key); }
        catch (Throwable $x) { error_log('billing receipt sub ' . $sid . ': ' . $x->getMessage()); }   // the money is taken; the books catch up (Settings shows it)
        finally { if ($test) QuickBooksPay::useEnv(null); }   // a test account's receipt went to the sandbox's books, never the live ones (2026-11-10)
        $pdo->prepare("INSERT INTO subscription_charges (sub_id, kind, amount_cents, items, status, charge_id, receipt_id, req_key) VALUES (?, ?, ?, ?, 'paid', ?, ?, ?)
                       ON DUPLICATE KEY UPDATE status = 'paid', charge_id = VALUES(charge_id), receipt_id = VALUES(receipt_id), error = ''")
            ->execute([$sid, $kind, $total, json_encode($lines, JSON_UNESCAPED_UNICODE), $cid, $rid, $key]);
        $to = $s['bill_email'] ?: $o['email'];
        if ($to !== '') self::mail($to, 'Your Traversence receipt: ' . self::usd($total),
            "Thank you. Here's your receipt for " . $o['name'] . ":\n\n" . implode("\n", array_map(fn ($l) => '  ' . $l[0] . ': ' . self::usd((int) $l[1]), $lines))
            . "\n\n  Total charged to " . ($s['card_label'] ?: 'your card') . ': ' . self::usd($total) . "\n\nManage your plan: " . self::link($s['owner_type'], (int) $s['owner_id']) . "\n");
        return $cid;
    }

    /**
     * Renews one subscription that's due (or tries a declined one again). A smaller plan chosen for later starts here;
     * packs marked to come off come off. Returns 'renewed', 'retry', 'ended' or 'skipped'.
     */
    public static function renew(PDO $pdo, array $s, bool $now = false): string
    {
        $sid = (int) $s['id']; $today = self::today();
        if ($s['status'] === 'trial') {
            if ($s['trial_ends'] > $today) return 'skipped';
            if ((int) $s['cancel_at_end'] || $s['card_id'] === '') { self::finish($pdo, $s, 'trial ended'); return 'ended'; }
            // kept: the first paid month starts at the trial's end
            $pdo->prepare("UPDATE subscriptions SET status = 'active', period_start = ?, period_end = ? WHERE id = ?")->execute([$today, $today, $sid]);
            $s = self::get($pdo, $sid);
        }
        if (!$now && $s['status'] === 'active' && $s['period_end'] > $today) return 'skipped';
        if (!$now && $s['status'] === 'past_due' && $s['next_try'] > $today) return 'skipped';
        if ((int) $s['cancel_at_end']) { self::finish($pdo, $s, 'cancelled'); return 'ended'; }
        if ($s['next_plan']) {
            if (self::planPrice((string) $s['next_plan'], 'month') === 0) { self::finish($pdo, $s, 'moved to free'); return 'ended'; }
            $pdo->prepare('UPDATE subscriptions SET plan = next_plan, price_cents = ?, next_plan = NULL WHERE id = ?')->execute([self::planPrice((string) $s['next_plan'], $s['cycle']), $sid]);
        }
        $pdo->prepare('DELETE FROM subscription_addons WHERE sub_id = ? AND remove_at_end = 1')->execute([$sid]);
        $s = self::get($pdo, $sid);
        $addons = []; foreach (self::addons($pdo, $sid) as $a) $addons[$a['addon']] = ($addons[$a['addon']] ?? 0) + (int) $a['qty'];
        $q = self::quote((string) $s['plan'], (string) $s['cycle'], $addons);
        $q['lines'][0][1] = (int) $s['price_cents'] ?: $q['lines'][0][1];   // the price it was taken at
        [$q['lines']] = self::withPromo($s, $q['lines']);
        try {
            self::charge($pdo, $sid, 'renewal', $q['lines'], 'sub' . $sid . '-renew-' . $s['period_end'] . '-' . (int) $s['fails']);
        } catch (RuntimeException $x) {
            if ($x->getCode() === 503) return 'retry';   // QuickBooks didn't answer: tomorrow's run tries again, same key
            $fails = (int) $s['fails'] + 1;
            if ($fails > count(self::RETRY_DAYS)) { self::finish($pdo, $s, 'payment declined'); return 'ended'; }
            $next = date('Y-m-d', strtotime((string) $s['period_end'] . ' +' . self::RETRY_DAYS[$fails - 1] . ' days'));
            $pdo->prepare("UPDATE subscriptions SET status = 'past_due', fails = ?, next_try = ? WHERE id = ?")->execute([$fails, $next, $sid]);
            $o = self::owner($pdo, $s['owner_type'], (int) $s['owner_id']);
            if (($s['bill_email'] ?: $o['email']) !== '') self::mail($s['bill_email'] ?: $o['email'], 'Your card was declined: ' . $o['name'] . '\'s plan',
                "We couldn't renew " . self::PLANS[$s['plan']][0] . " for " . $o['name'] . " with " . ($s['card_label'] ?: 'your card') . " (" . $x->getMessage() . ").\n\n"
                . "We'll try again on " . date('F j', strtotime($next)) . ". To fix it now, update the card here: " . self::link($s['owner_type'], (int) $s['owner_id']) . "\n\n"
                . "If it can't be renewed, the account goes back to the free plan" . ($s['owner_type'] === 'listing' ? ' (the listing stays up)' : '') . ".\n");
            return 'retry';
        }
        self::promoUsed($pdo, $sid);
        $from = $s['status'] === 'past_due' ? $today : (string) $s['period_end'];
        $pdo->prepare("UPDATE subscriptions SET status = 'active', period_start = ?, period_end = ?, fails = 0, next_try = NULL, notices = '' WHERE id = ?")
            ->execute([$from, self::addPeriod($from, (string) $s['cycle']), $sid]);
        self::syncTier($pdo, $s['owner_type'], (int) $s['owner_id']);
        return 'renewed';
    }

    private static function finish(PDO $pdo, array $s, string $why): void
    {
        $pdo->prepare("UPDATE subscriptions SET status = 'ended', ended_at = NOW(), end_reason = ? WHERE id = ?")->execute([$why, (int) $s['id']]);
        self::syncTier($pdo, $s['owner_type'], (int) $s['owner_id']);
        $o = self::owner($pdo, $s['owner_type'], (int) $s['owner_id']);
        $to = $s['bill_email'] ?: $o['email'];
        if ($to === '') return;
        $plan = self::PLANS[$s['plan']][0];
        $msg = ['trial ended' => "The $plan trial for {$o['name']} has ended, and it's back on the free plan. Nothing was charged.",
                'cancelled' => "{$o['name']}'s $plan plan has ended, as you asked. It's back on the free plan.",
                'moved to free' => "{$o['name']} has moved to the free plan, as you asked.",
                'payment declined' => "We couldn't renew {$o['name']}'s $plan plan, so it's back on the free plan."][$why] ?? "{$o['name']}'s $plan plan has ended.";
        self::mail($to, $plan . ' has ended for ' . $o['name'], $msg . ($s['owner_type'] === 'listing' ? ' The listing stays up.' : '') . "\n\nYou can choose a plan again any time: " . self::link($s['owner_type'], (int) $s['owner_id']) . "\n");
    }

    /**
     * The daily run: reminders (a trial 5 days and 1 day before it ends, and on the day; a yearly plan 7 days before it
     * renews), then renewals and retries. Returns counts.
     */
    public static function tick(PDO $pdo): array
    {
        $n = ['renewed' => 0, 'retry' => 0, 'ended' => 0, 'reminders' => 0];
        if (!self::ready($pdo)) return $n;
        $today = self::today();
        foreach ($pdo->query("SELECT * FROM subscriptions WHERE status IN ('trial','active') AND period_end <= '" . date('Y-m-d', strtotime($today . ' +7 days')) . "'")->fetchAll(PDO::FETCH_ASSOC) as $s) {
            $days = (int) round((strtotime((string) $s['period_end']) - strtotime($today)) / 86400);
            $tag = $s['status'] === 'trial' ? ($days <= 0 ? 't0' : ($days <= 1 ? 't1' : ($days <= 5 ? 't5' : ''))) : ($s['cycle'] === 'year' && $days <= 7 && $days > 0 && !(int) $s['cancel_at_end'] ? 'y7' : '');
            if ($tag === '' || str_contains((string) $s['notices'], $tag)) continue;
            $o = self::owner($pdo, $s['owner_type'], (int) $s['owner_id']);
            $to = $s['bill_email'] ?: $o['email'];
            $pdo->prepare('UPDATE subscriptions SET notices = CONCAT(notices, ?) WHERE id = ?')->execute([$tag . ' ', (int) $s['id']]);
            if ($to === '') continue;
            $plan = self::PLANS[$s['plan']][0]; $when = date('F j', strtotime((string) $s['period_end']));
            if ($tag === 'y7') self::mail($to, 'Your yearly ' . $plan . ' plan renews on ' . $when,
                "{$o['name']}'s yearly $plan plan renews on $when for " . self::usd((int) $s['price_cents']) . " plus its add-ons, charged to " . ($s['card_label'] ?: 'your card') . ".\n\nTo change or stop it: " . self::link($s['owner_type'], (int) $s['owner_id']) . "\n");
            else self::mail($to, $tag === 't0' ? "Your $plan trial ends today" : "Your $plan trial ends " . ($tag === 't1' ? 'tomorrow' : 'in 5 days'),
                "{$o['name']}'s $plan trial ends " . ($tag === 't0' ? 'today' : "on $when") . ".\n\n"
                . ((int) $s['cancel_at_end'] ? "To keep $plan after the trial, set up billing: add a card and choose Keep my plan (" . self::usd((int) $s['price_cents']) . " a month from then, cancel any time):\n" . self::link($s['owner_type'], (int) $s['owner_id'])
                    . "\n\nIf you don't, {$o['name']} goes back to the Free plan on its own when the trial ends. Nothing is charged, and nothing is lost: your listing, photos and content stay; the paid tools pause until you choose a plan again.\n"
                    : "You chose to keep it: " . self::usd((int) $s['price_cents']) . " a month will be charged to " . ($s['card_label'] ?: 'your card') . " from then. To stop instead: " . self::link($s['owner_type'], (int) $s['owner_id']) . "\n"));
            $n['reminders']++;
        }
        foreach ($pdo->query("SELECT * FROM subscriptions WHERE (status IN ('trial','active') AND period_end <= '$today') OR (status = 'past_due' AND next_try <= '$today') ORDER BY id LIMIT 500")->fetchAll(PDO::FETCH_ASSOC) as $s) {
            try { $r = self::renew($pdo, $s); if (isset($n[$r])) $n[$r]++; }
            catch (Throwable $x) { error_log('billing renew ' . $s['id'] . ': ' . $x->getMessage()); $n['retry']++; }
        }
        return $n;
    }

    /** The listing's tier follows its plan while it's live (a trial, paid, or a renewal being retried); Free otherwise. */
    public static function syncTier(PDO $pdo, string $type, int $id): void
    {
        if ($type !== 'listing') return;
        $s = self::current($pdo, $type, $id);
        $tier = $s ? (self::PLANS[$s['plan']][5] ?? 'free') : 'free';
        try { $pdo->prepare('UPDATE entities SET plan_tier = ? WHERE id = ?')->execute([$tier ?: 'free', $id]); } catch (Throwable $x) { error_log('billing tier: ' . $x->getMessage()); }
        try { require_once __DIR__ . '/SupportAccess.php'; SupportAccess::sync($pdo, $id); } catch (Throwable $x) { error_log('billing white glove: ' . $x->getMessage()); }   // decisions/0117
    }

    public static function link(string $type, int $id): string
    {
        return rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/') . '/plans.php?' . ($type === 'listing' ? 'listing=' . $id : 'me=1');
    }

    private static function mail(string $to, string $subject, string $body): void
    {
        try { require_once __DIR__ . '/Mailer.php'; Mailer::send($to, $subject, $body . "\nTraversence\n"); } catch (Throwable $x) { error_log('billing mail: ' . $x->getMessage()); }
    }
}
