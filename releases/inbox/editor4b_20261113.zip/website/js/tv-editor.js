/* js/tv-editor.js — the editor (decisions/0159 §3, §6; app/lib/Blocks.php, /api/blocks.php). Loaded only for staff with
 * pages.edit, on a page with a zone (Blocks::zone). Edit on a zone opens its panel (a sheet from the bottom on a phone, a
 * panel at the side on a computer, the page making room beside it):
 *  - Add: the widget panel. Tap a block to add it where you are, or drag it onto the page (or onto Layout).
 *  - Layout: the zone's sections, columns and blocks; drag ⠿ to move a block (between columns and sections too) or a
 *    section; tap one to pick it. A tap on the page picks what's there.
 *  - The picked block gets its toolbar on the page (Manage, Design, up, down, copy, remove); Manage holds its words,
 *    Design its alignment, width and spacing for the view in use: Desktop, Tablet or Phone (tablet takes desktop's unless
 *    set, phone takes tablet's). A section's own settings: columns, background, inner space, column widths and order.
 *  - Every change shows on the page at once, drawn by the server as visitors will get it (the preview); Tablet and Phone
 *    narrow the zone to that screen, so it reflows exactly as theirs will.
 *  - Save draft keeps it for the team only; Publish puts it live as the next version; ▾ holds Versions (Roll back) and
 *    Throw the draft away. Every action shows its spinner, then the site's notice (TvAsk).
 * Step 4a; 4b added the live components (Add → Parts of the site: search box, businesses, map button, guide, GO Code, each
 * with its own settings from Blocks::LIVE) and, on a page of ours, the Page tab (title, search description, share picture,
 * live when saved). The engage bar and a form, global header and footer, and scheduled publishing are 4c. */
(function () {
  var zones = document.querySelectorAll('[data-tvb-zone]');
  if (!zones.length) return;
  var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
  var REOPEN = 'tvbReopen';
  var SVG = {
    d: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/></svg>',
    t: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M11 18h2"/></svg>',
    p: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/></svg>'
  };
  var ICON = { heading: 'H', text: '¶', image: '▣', button: '⬭', divider: '—', spacer: '↕', search: '⌕', listings: '▦', map: '⌖', guide: '❖', gocode: '▩' };
  var css = document.createElement('style');
  css.textContent = '.tve{position:fixed;z-index:1360;background:#FFFBF2;color:#3E2B1F;box-shadow:0 -10px 30px -10px rgba(0,0,0,.45);display:flex;flex-direction:column;font:15px/1.4 system-ui,sans-serif;left:0;right:0;bottom:0;max-height:62vh;border-radius:1rem 1rem 0 0}'
    + '@media (min-width:900px){.tve{left:auto;top:0;width:27rem;max-height:none;border-radius:0;box-shadow:-10px 0 30px -10px rgba(0,0,0,.45)}}@media (min-width:1340px){body.tve-open{margin-right:27rem}}@media (max-width:899.98px){body.tve-open{padding-bottom:64vh}}'
    + '.tve-hd{position:relative;padding:.6rem 2.9rem .55rem .7rem;background:#B9D8C6;border-radius:inherit;border-bottom:1px solid #9CC3AE}'
    + '.tve-hd b{display:block;font:700 1rem ui-serif,Georgia,serif;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-bottom:.35rem}'
    + '.tve-x{position:absolute;top:.45rem;right:.5rem;width:2rem;height:2rem;border-radius:50%;border:1.5px solid #3E2B1F;background:#FFFBF2;color:#3E2B1F;font:700 1rem system-ui;cursor:pointer;line-height:1}'
    + '.tve-row{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center}.tve-hd small{display:block;margin-top:.35rem;color:#3E2B1F}'
    + '.tve-b{font:700 .85rem/1.2 system-ui,sans-serif;border:1.5px solid #E07F3C;background:#fff;color:#2B1D14;border-radius:.3rem;padding:.35rem .6rem;cursor:pointer}'
    + '.tve-b.go{background:#E07F3C;color:#fff}.tve-b.no{border-color:#B91C1C;color:#991B1B}.tve-b.sm{padding:.15rem .45rem;font-size:.78rem}.tve-b[aria-pressed=true]{background:#2F6B4F;border-color:#2F6B4F;color:#fff}'
    + '.tve-b[aria-busy=true]::before{content:"";display:inline-block;width:.7rem;height:.7rem;margin-right:.35rem;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;vertical-align:-1px;animation:tvespin .8s linear infinite}@keyframes tvespin{to{transform:rotate(360deg)}}'
    + '.tve-bps{display:inline-flex;border:1.5px solid #2F6B4F;border-radius:.4rem;overflow:hidden;margin-left:auto}.tve-bps button{border:0;background:#fff;color:#2F6B4F;padding:.25rem .45rem;cursor:pointer;display:flex;align-items:center}.tve-bps button[aria-pressed=true]{background:#2F6B4F;color:#fff}'
    + '.tve-menu{position:relative}.tve-menu>div{position:absolute;top:110%;left:0;z-index:3;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;box-shadow:0 8px 20px -8px rgba(0,0,0,.4);padding:.3rem;min-width:12rem}.tve-menu>div button{display:block;width:100%;text-align:left;margin:.15rem 0}'
    + '.tve-tabs{display:flex;gap:0;border-bottom:1px solid #CBB98D;background:#F7EFDC}.tve-tabs button{flex:1;border:0;background:none;padding:.5rem .3rem;font:700 .82rem system-ui;color:#5C4632;cursor:pointer;border-bottom:3px solid transparent}.tve-tabs button[aria-selected=true]{color:#92400E;border-bottom-color:#E07F3C}'
    + '.tve-bd{overflow:auto;padding:.6rem .7rem 1.2rem;flex:1}'
    + '.tve-wid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:.45rem}.tve-w{border:1.5px solid #CBB98D;background:#fff;border-radius:.55rem;padding:.55rem .3rem;text-align:center;cursor:grab;touch-action:none;user-select:none;font:700 .8rem system-ui;color:#3E2B1F}.tve-w i{display:block;font:700 1.3rem Georgia,serif;font-style:normal;color:#B45309;margin-bottom:.15rem}'
    + '.tve-lsec{border:1px solid #CBB98D;border-radius:.6rem;margin:.5rem 0;background:#F7EFDC}.tve-lsh{display:flex;gap:.35rem;align-items:center;padding:.4rem .5rem;border-bottom:1px solid #E2D4B2;cursor:pointer}.tve-lsh strong{flex:1}'
    + '.tve-lcol{padding:.3rem .5rem .45rem}.tve-lcol>h5{margin:.1rem 0 .2rem;font:700 .7rem system-ui;letter-spacing:.04em;text-transform:uppercase;color:#8A7355}'
    + '.tve-lb{display:flex;gap:.4rem;align-items:center;background:#FFFBF2;border:1px solid #E2D4B2;border-radius:.45rem;padding:.35rem .45rem;margin:.25rem 0;cursor:pointer;font-size:.88rem}.tve-lb span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
    + '.tve-lb.on,.tve-lsh.on{outline:2px solid #2F6B4F;outline-offset:1px}.tve-drop{border:1.5px dashed #CBB98D;border-radius:.45rem;padding:.3rem;text-align:center;color:#8A7355;font-size:.78rem;margin-top:.25rem}'
    + '.tve-h{cursor:grab;touch-action:none;user-select:none;color:#8A7355;font-size:1.05rem;padding:0 .15rem}'
    + '.tve label{display:block;font-size:.78rem;font-weight:700;color:#5C4632;margin:.35rem 0 .1rem}.tve input,.tve textarea,.tve select{width:100%;box-sizing:border-box;font:16px system-ui,sans-serif;border:1px solid #CBB98D;border-radius:.4rem;padding:.35rem .45rem;background:#fff;color:#3E2B1F}'
    + '.tve-hint{font-size:.78rem;color:#8A7355;margin:.3rem 0}.tve-note{background:#E3EFE8;border:1px solid #B9D8C6;border-radius:.45rem;padding:.4rem .55rem;font-size:.82rem;margin:.2rem 0 .5rem}'
    + '.tve-dot{display:inline-block;width:.55rem;height:.55rem;border-radius:50%;background:#E2A93B;margin-left:.3rem;vertical-align:1px}.tve-v{display:flex;gap:.4rem;align-items:center;border-bottom:1px solid #E2D4B2;padding:.4rem 0}.tve-v span{flex:1}'
    + '.tve-tb{position:absolute;z-index:1350;display:flex;gap:.2rem;background:#2F6B4F;border-radius:.45rem;padding:.2rem;box-shadow:0 6px 16px -6px rgba(0,0,0,.5)}.tve-tb button{border:0;background:transparent;color:#fff;font:700 .78rem system-ui;padding:.3rem .45rem;border-radius:.3rem;cursor:pointer}.tve-tb button:hover{background:rgba(255,255,255,.18)}'
    + '.tve-ghost{position:fixed;z-index:1400;pointer-events:none;background:#2F6B4F;color:#fff;font:700 .8rem system-ui;padding:.3rem .6rem;border-radius:.4rem;box-shadow:0 6px 16px -6px rgba(0,0,0,.5)}'
    + '.tve-line{position:absolute;z-index:1390;height:3px;background:#E07F3C;border-radius:2px;pointer-events:none;box-shadow:0 0 0 2px rgba(224,127,60,.25)}';
  document.head.appendChild(css);

  var cur = null;   // {zone, el, label, data, tree, dirty, view, tab, sel, bp}
  var panel = null, toolbar = null;
  function el(tag, attrs, kids) {
    var x = document.createElement(tag);
    for (var k in (attrs || {})) { if (k === 'text') x.textContent = attrs[k]; else if (k === 'html') x.innerHTML = attrs[k]; else if (k === 'on') x.addEventListener('click', attrs[k]); else x.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c != null) x.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return x;
  }
  function btn(text, on, cls, extra) { return el('button', Object.assign({ type: 'button', class: 'tve-b' + (cls ? ' ' + cls : ''), text: text, on: on }, extra || {})); }
  function say(msg, anchor, bad) { if (window.TvAsk && TvAsk.say) TvAsk.say(msg, { anchor: anchor, bad: !!bad }); }
  function busy(b, on) { if (!b) return; if (window.TvAsk && TvAsk.busy) TvAsk.busy(b, on); else { if (on) b.setAttribute('aria-busy', 'true'); else b.removeAttribute('aria-busy'); b.disabled = !!on; } }
  function ask(msg, anchor, yes, danger) { return window.TvAsk && TvAsk.confirm ? TvAsk.confirm(msg, { anchor: anchor, yes: yes, danger: !!danger }) : Promise.resolve(true); }
  function api(body) {
    var o = { credentials: 'include', headers: { 'Content-Type': 'application/json' } };
    if (body) { o.method = 'POST'; o.headers['X-CSRF-Token'] = cur.el.getAttribute('data-csrf') || ''; body.tz = tz; body.zone = cur.zone; o.body = JSON.stringify(window.tvSafe ? tvSafe(body) : body); }
    return fetch('/api/blocks.php' + (body ? '' : '?zone=' + encodeURIComponent(cur.zone)), o)
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again.' } }; }); }, function () { return { ok: false, error: { message: 'The connection dropped. Try again.' } }; })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again; still stuck? Write to support@traversence.com.'); return j; });
  }
  function when(iso, z) { try { return window.TvTime && TvTime.fmt ? TvTime.fmt(iso, z) : new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short', timeZone: z || undefined }); } catch (e) { return iso; } }
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  function blank(t) {
    return t === 'heading' ? { t: t, text: '', level: 2 } : t === 'text' ? { t: t, md: '' } : t === 'image' ? { t: t, src: '', alt: '', caption: '' }
      : t === 'button' ? { t: 'button', label: '', href: '', style: 'primary' } : t === 'spacer' ? { t: t, size: 'm' } : live(t) ? liveBlank(t) : { t: t };
  }
  function live(t) { return !!(cur && cur.data.live && cur.data.live[t]); }
  function liveBlank(t) {
    var b = { t: t }, spec = cur.data.live[t][1];
    Object.keys(spec).forEach(function (k) { b[k] = spec[k][1] === 'select' ? Object.keys(spec[k][2])[0] : ''; });
    return b;
  }
  function newSection() { return { cols: [[]], bg: 'none', align: 'left' }; }
  function typeName(t) { return ((cur.data.types || {})[t] || [t])[0]; }
  function summary(b) {
    var w = b.t === 'heading' ? b.text : b.t === 'text' ? b.md : b.t === 'image' ? (b.alt || b.src) : b.t === 'button' ? b.label : b.t === 'spacer' ? ({ s: 'small', m: 'medium', l: 'large', xl: 'extra large' })[b.size] : '';
    if (live(b.t)) w = b.t === 'search' ? (b.words || 'empty box') : b.t === 'gocode' ? (b.path || 'this page') : [b.cat, b.town].filter(Boolean).join(' in ');
    w = String(w || '').replace(/\s+/g, ' ').trim();
    return typeName(b.t) + (w ? ': ' + w : b.t === 'divider' ? '' : ' (not filled in)');
  }
  function block(sel) { var s = cur.tree.sections[sel.s]; return s && s.cols[sel.c] && s.cols[sel.c][sel.b]; }

  // ---- the preview: the server draws the tree, the zone shows it -------------------------------------------------------
  var pvTimer = null, pvSeq = 0;
  function changed(redraw) {
    cur.dirty = true;
    var h = panel && panel.querySelector('[data-save]'); if (h && !h.querySelector('.tve-dot')) h.appendChild(el('span', { class: 'tve-dot', title: 'Not saved yet', 'aria-label': 'Not saved yet' }));
    if (redraw) draw();
    clearTimeout(pvTimer); pvTimer = setTimeout(preview, redraw ? 60 : 380);
  }
  function preview() {
    if (!cur) return;
    var n = ++pvSeq, c = cur;
    api({ action: 'preview', tree: c.tree, here: location.pathname + location.search }).then(function (j) {
      if (c !== cur || n !== pvSeq) return;
      Array.prototype.slice.call(c.el.children).forEach(function (x) { if (!x.classList.contains('tvb-tag')) x.remove(); });
      var box = el('div', { html: j.html || '<p class="tvb-empty">Nothing here yet: add a block from Add.</p>' });
      while (box.firstChild) c.el.appendChild(box.firstChild);
      liveParts(c.el);
      mark();
    }, function (e) { if (c === cur) say('The preview didn\'t draw: ' + e.message, c.el.querySelector('[data-tvb-edit]'), true); });
  }
  function mark() {
    if (!cur) return;
    cur.el.querySelectorAll('.tvb-picked').forEach(function (x) { x.classList.remove('tvb-picked'); });
    var t = null, s = cur.sel;
    if (s && s.b != null) t = cur.el.querySelector('[data-tvb-b="' + s.s + '.' + s.c + '.' + s.b + '"]');
    else if (s) t = cur.el.querySelector('[data-tvb-s="' + s.s + '"]');
    if (t) t.classList.add('tvb-picked');
    placeToolbar(t && s.b != null ? t : null);
  }
  // the live parts' browser half (js/tv-blocks.js): a script put in by innerHTML doesn't run, so it's loaded and run here
  function liveParts(root) {
    if (!root.querySelector('[data-tvb-listings],[data-tvb-map],[data-tvb-search]')) return;
    if (window.TvBlocks) { TvBlocks.scan(root); return; }
    var s = document.querySelector('script[data-tvb-js]') || (function () { var x = document.createElement('script'); x.src = '/js/tv-blocks.js'; x.setAttribute('data-tvb-js', ''); document.head.appendChild(x); return x; })();
    s.addEventListener('load', function () { if (window.TvBlocks) TvBlocks.scan(root); });
  }
  function setView(bp) {
    cur.bp = bp;
    cur.el.classList.remove('tvb-view-t', 'tvb-view-p');
    if (bp !== 'd') cur.el.classList.add('tvb-view-' + bp);
    draw(); setTimeout(function () { mark(); cur && cur.el.scrollIntoView({ block: 'nearest' }); }, 30);
  }

  // ---- the block's toolbar on the page --------------------------------------------------------------------------------
  function placeToolbar(t) {
    // on a phone the page is too narrow for a toolbar over it: the same buttons sit in the panel's block row
    if (!t || window.innerWidth < 900) { if (toolbar) toolbar.style.display = 'none'; return; }
    if (!toolbar) {
      toolbar = el('div', { class: 'tve-tb', role: 'toolbar', 'aria-label': 'This block' });
      [['Manage', function () { cur.tab = 'manage'; draw(); }], ['Design', function () { cur.tab = 'design'; draw(); }],
       ['↑', function () { nudge(-1); }, 'Move up'], ['↓', function () { nudge(1); }, 'Move down'],
       ['⧉', function () { copyPicked(); }, 'Copy it'], ['✕', function (e) { removePicked(e.currentTarget); }, 'Remove it']].forEach(function (x) {
        toolbar.appendChild(el('button', Object.assign({ type: 'button', text: x[0], on: x[1] }, x[2] ? { title: x[2], 'aria-label': x[2] } : {})));
      });
      document.body.appendChild(toolbar);
    }
    var r = t.getBoundingClientRect();
    toolbar.style.display = 'flex';
    var top = r.top + window.scrollY - toolbar.offsetHeight - 6;
    if (top < window.scrollY + 4) top = r.bottom + window.scrollY + 6;
    toolbar.style.top = top + 'px';
    // at the block's top right, where the block above usually has empty space (its words start at the left)
    toolbar.style.left = Math.max(4, Math.min(r.right + window.scrollX - toolbar.offsetWidth, window.scrollX + document.documentElement.clientWidth - toolbar.offsetWidth - 4)) + 'px';
  }
  window.addEventListener('scroll', function () { if (cur) mark(); }, { passive: true });
  window.addEventListener('resize', function () { if (cur) mark(); });
  function move(list, i, d) { var j = i + d; if (j < 0 || j >= list.length) return false; var x = list[i]; list[i] = list[j]; list[j] = x; return true; }
  function nudge(d) {
    var s = cur.sel;
    if (move(cur.tree.sections[s.s].cols[s.c], s.b, d)) { s.b += d; changed(true); }
  }
  function copyPicked() { var s = cur.sel, list = cur.tree.sections[s.s].cols[s.c]; list.splice(s.b + 1, 0, clone(list[s.b])); s.b++; changed(true); }
  function removePicked(anchor) {
    var s = cur.sel;
    ask('Remove this ' + typeName(block(s).t).toLowerCase() + '?', anchor, 'Remove', true).then(function (y) {
      if (!y) return; cur.tree.sections[s.s].cols[s.c].splice(s.b, 1); cur.sel = null; cur.tab = 'layout'; changed(true);
    });
  }

  // ---- drag and drop: by mouse or finger, from the widget panel or a ⠿ handle, onto the page or Layout ---------------
  var drag = null;
  function startDrag(e, what, label) {
    if (e.button > 0) return;
    e.preventDefault();
    drag = { what: what, x0: e.clientX, y0: e.clientY, moved: false, target: null, ghost: el('div', { class: 'tve-ghost', text: label }), line: el('div', { class: 'tve-line' }) };
    document.addEventListener('pointermove', onMove); document.addEventListener('pointerup', onUp); document.addEventListener('pointercancel', onUp);
  }
  function onMove(e) {
    if (!drag) return;
    if (!drag.moved) { if (Math.abs(e.clientX - drag.x0) + Math.abs(e.clientY - drag.y0) < 6) return; drag.moved = true; document.body.appendChild(drag.ghost); document.body.appendChild(drag.line); }
    drag.ghost.style.left = (e.clientX + 12) + 'px'; drag.ghost.style.top = (e.clientY + 12) + 'px';
    var bd = panel && panel.querySelector('.tve-bd');
    [[bd, bd && bd.getBoundingClientRect()], [window, { top: 0, bottom: window.innerHeight }]].forEach(function (p) {
      if (!p[0] || !p[1]) return; var r = p[1];
      if (e.clientY < r.top + 36 && e.clientY >= r.top) (p[0].scrollBy ? p[0] : window).scrollBy(0, -12);
      else if (e.clientY > r.bottom - 36 && e.clientY <= r.bottom) (p[0].scrollBy ? p[0] : window).scrollBy(0, 12);
    });
    drag.target = findTarget(e.clientX, e.clientY);
    var t = drag.target;
    if (!t) { drag.line.style.display = 'none'; return; }
    var r = t.node.getBoundingClientRect();
    drag.line.style.display = 'block';
    drag.line.style.left = (r.left + window.scrollX) + 'px'; drag.line.style.width = r.width + 'px';
    drag.line.style.top = ((t.where === 'before' ? r.top : r.bottom) + window.scrollY - 1) + 'px';
  }
  function findTarget(x, y) {
    var n = document.elementFromPoint(x, y);
    if (!n || !cur) return null;
    var isSec = drag.what.kind === 'sec';
    var half = function (node) { var r = node.getBoundingClientRect(); return y < r.top + r.height / 2 ? 'before' : 'after'; };
    if (isSec) {
      var sNode = n.closest('[data-tvl-s],[data-tvb-s]');
      if (!sNode || !(cur.el.contains(sNode) || (panel && panel.contains(sNode)))) return null;
      return { node: sNode, s: +(sNode.getAttribute('data-tvl-s') || sNode.getAttribute('data-tvb-s')), where: half(sNode) };
    }
    var b = n.closest('[data-tvl-b],[data-tvb-b]');
    if (b && (cur.el.contains(b) || (panel && panel.contains(b)))) {
      var p = (b.getAttribute('data-tvl-b') || b.getAttribute('data-tvb-b')).split('.').map(Number);
      return { node: b, s: p[0], c: p[1], b: p[2], where: half(b) };
    }
    var c = n.closest('[data-tvl-c],[data-tvb-c]');
    if (c && (cur.el.contains(c) || (panel && panel.contains(c)))) {
      var q = (c.getAttribute('data-tvl-c') || c.getAttribute('data-tvb-c')).split('.').map(Number);
      return { node: c, s: q[0], c: q[1], b: cur.tree.sections[q[0]].cols[q[1]].length, where: 'after' };
    }
    return null;
  }
  function onUp() {
    document.removeEventListener('pointermove', onMove); document.removeEventListener('pointerup', onUp); document.removeEventListener('pointercancel', onUp);
    var d = drag; drag = null;
    if (!d) return;
    d.ghost.remove(); d.line.remove();
    if (!d.moved) { if (d.what.kind === 'new') addBlock(d.what.t); return; }   // a tap on a widget adds it
    var t = d.target; if (!t) return;
    var secs = cur.tree.sections;
    if (d.what.kind === 'sec') {
      var from = d.what.s, to = t.s + (t.where === 'after' ? 1 : 0);
      if (from < to) to--;
      if (to === from) return;
      var sec = secs.splice(from, 1)[0]; secs.splice(to, 0, sec); cur.sel = { s: to }; changed(true); return;
    }
    var at = t.b + (t.where === 'after' && t.node.matches('[data-tvl-b],[data-tvb-b]') ? 1 : 0), dest = secs[t.s].cols[t.c], item;
    if (d.what.kind === 'new') item = blank(d.what.t);
    else {
      var w = d.what, src = secs[w.s].cols[w.c];
      if (w.s === t.s && w.c === t.c && (at === w.b || at === w.b + 1)) return;
      item = src.splice(w.b, 1)[0];
      if (w.s === t.s && w.c === t.c && w.b < at) at--;
    }
    dest.splice(at, 0, item);
    cur.sel = { s: t.s, c: t.c, b: at }; cur.tab = d.what.kind === 'new' ? 'manage' : cur.tab === 'add' ? 'layout' : cur.tab;
    changed(true);
  }
  function addBlock(t) {
    var s = cur.sel, secs = cur.tree.sections;
    if (!secs.length) secs.push(newSection());
    var si = s ? s.s : secs.length - 1, ci = s && s.c != null ? s.c : 0, list = secs[si].cols[ci], at = s && s.b != null ? s.b + 1 : list.length;
    list.splice(at, 0, blank(t)); cur.sel = { s: si, c: ci, b: at }; cur.tab = 'manage'; changed(true);
    say(typeName(t) + ' added' + (secs.length > 1 ? ' to section ' + (si + 1) : '') + ': fill it in below.', panel.querySelector('.tve-tabs'));
  }

  // ---- the panel ------------------------------------------------------------------------------------------------------
  function open(zoneEl, view) {
    cur = { zone: zoneEl.getAttribute('data-tvb-zone'), label: zoneEl.getAttribute('data-tvb-label') || '', el: zoneEl, dirty: false, view: view === 'versions' ? 'versions' : 'edit', tab: 'add', sel: null, bp: 'd' };
    var b = zoneEl.querySelector('[data-tvb-edit]'); busy(b, true);
    api().then(function (j) {
      busy(b, false); cur.data = j; cur.tree = clone(j.state.draft || j.state.live || { sections: [] });
      if (!cur.tree.sections.length) cur.tree.sections.push(newSection());
      document.body.classList.add('tve-open'); draw(); preview();
    }, function (e) { busy(b, false); say(e.message, b, true); cur = null; });
  }
  function close() {
    if (cur && cur.dirty) { ask('Close without saving? Your changes since the last Save draft are lost.', panel.querySelector('.tve-x'), 'Close', true).then(function (y) { if (y) { cur.dirty = false; location.reload(); } }); return; }
    shut();
  }
  function shut() {
    if (panel) panel.remove(); panel = null;
    if (toolbar) toolbar.style.display = 'none';
    if (cur) { cur.el.classList.remove('tvb-view-t', 'tvb-view-p'); cur.el.querySelectorAll('.tvb-picked').forEach(function (x) { x.classList.remove('tvb-picked'); }); }
    document.body.classList.remove('tve-open'); cur = null;
  }

  function field(lab, input) { return el('div', {}, [el('label', { text: lab }), input]); }
  function inp(obj, key, attrs) {
    var x = el(attrs && attrs.area ? 'textarea' : 'input', Object.assign({}, attrs && attrs.area ? { rows: '5' } : { type: 'text' }, (attrs && attrs.extra) || {}));
    x.value = obj[key] || ''; x.addEventListener('input', function () { obj[key] = x.value; changed(); });
    return x;
  }
  function sel(obj, key, opts, redraw) {
    var x = el('select');
    opts.forEach(function (o) { var op = el('option', { value: o[0], text: o[1] }); if (String(obj[key]) === String(o[0])) op.selected = true; x.appendChild(op); });
    x.addEventListener('change', function () { obj[key] = /^\d+$/.test(x.value) && key === 'level' ? +x.value : x.value; changed(redraw); });
    return x;
  }

  function blockBox(b) {
    var box = el('div');
    if (b.t === 'heading') { box.appendChild(field('Words', inp(b, 'text', { extra: { 'data-spell': '', maxlength: '200' } }))); box.appendChild(field('Size', sel(b, 'level', [[2, 'Large'], [3, 'Smaller']]))); }
    if (b.t === 'text') { box.appendChild(field('The words', inp(b, 'md', { area: true }))); box.appendChild(el('p', { class: 'tve-hint', text: 'A blank line starts a new paragraph. "- " starts a list line. **bold**, *italic*, [words](/link or https://…).' })); }
    if (b.t === 'image') {
      var src = inp(b, 'src', { extra: { placeholder: 'https://… or upload one', spellcheck: 'false' } });
      var up = btn('Upload a picture', null, 'sm');
      var file = el('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', hidden: '', 'data-art': 'off' });
      up.addEventListener('click', function () { file.click(); });
      file.addEventListener('change', function () {
        var f = file.files && file.files[0]; file.value = ''; if (!f || !window.TvUpload) { if (f) say('The uploader isn\'t on this page: reload it and try again.', up, true); return; }
        busy(up, true);
        TvUpload.send([f], { target: 'block_image', ctx: { zone: cur.zone }, el: box }).then(function (res) {
          busy(up, false); var r = (res && res[0]) || {}, got = r.result || r;
          if (r.ok === false || r.error || !got.url) { say((r.error && (r.error.message || r.error)) || 'The upload didn\'t go through. Try again.', up, true); return; }
          b.src = got.url; src.value = got.url; changed(); say('Uploaded: it shows on the page now. Save draft keeps it.', up);
        }, function () { busy(up, false); say('The upload didn\'t go through. Try again.', up, true); });
      });
      box.appendChild(field('The picture', src)); box.appendChild(el('div', {}, [up, file]));
      box.appendChild(field('What it shows (for those who can\'t see it)', inp(b, 'alt', { extra: { 'data-spell': '' } })));
      box.appendChild(field('Caption (optional)', inp(b, 'caption', { extra: { 'data-spell': '' } })));
    }
    if (b.t === 'button') {
      box.appendChild(field('Words on it', inp(b, 'label', { extra: { 'data-spell': '', maxlength: '80' } })));
      box.appendChild(field('Where it goes', inp(b, 'href', { extra: { placeholder: '/page, https://…, mailto:…', spellcheck: 'false' } })));
      box.appendChild(field('Look', sel(b, 'style', [['primary', 'Filled'], ['plain', 'Outline']])));
    }
    if (b.t === 'spacer') box.appendChild(field('How much space', sel(b, 'size', [['s', 'Small'], ['m', 'Medium'], ['l', 'Large'], ['xl', 'Extra large']])));
    if (b.t === 'divider') box.appendChild(el('p', { class: 'tve-hint', text: 'A thin line across its column. Design sets its width and the space around it.' }));
    if (live(b.t)) {
      var spec = cur.data.live[b.t][1];
      box.appendChild(el('p', { class: 'tve-note', text: 'A part of the site: it draws itself from our own data, the same as on its own page. Here you choose what it shows.' }));
      Object.keys(spec).forEach(function (k) {
        var f = spec[k];
        var x = f[1] === 'select' ? sel(b, k, Object.keys(f[2]).map(function (v) { return [v, f[2][v]]; })) : inp(b, k, { extra: { maxlength: String(f[2]), placeholder: f[3] || '', spellcheck: k === 'path' ? 'false' : 'true' } });
        box.appendChild(field(f[0], x));
        if (f[1] !== 'select' && f[3]) box.appendChild(el('p', { class: 'tve-hint', text: f[3] }));
      });
    }
    return box;
  }

  /** The design settings of a section or block for the view in use: each one shows what it inherits. */
  function designBox(obj, spec) {
    var bps = ['d', 't', 'p'], i = bps.indexOf(cur.bp), names = cur.data.bps || { d: ['Desktop'], t: ['Tablet'], p: ['Phone'] };
    obj.design = obj.design || {};
    var box = el('div');
    box.appendChild(el('p', { class: 'tve-note', text: 'Designing for ' + names[cur.bp][0] + (i > 0 ? ': what isn\'t set here follows ' + names[bps[i - 1]][0] + '.' : ': Tablet and Phone follow this unless set there.') + ' Switch views at the top.' }));
    Object.keys(spec).forEach(function (k) {
      var choices = spec[k][1], keys = Object.keys(choices), inherited = keys[0];
      for (var j = 0; j < i; j++) if (obj.design[bps[j]] && obj.design[bps[j]][k] != null) inherited = obj.design[bps[j]][k];
      var mine = obj.design[cur.bp] && obj.design[cur.bp][k] != null ? obj.design[cur.bp][k] : '';
      var x = el('select');
      x.appendChild(el('option', { value: '', text: (i > 0 ? 'As ' + names[bps[i - 1]][0].toLowerCase() : 'Standard') + ' (' + choices[inherited] + ')' }));
      keys.forEach(function (v) { var o = el('option', { value: v, text: choices[v] }); if (mine === v) o.selected = true; x.appendChild(o); });
      x.addEventListener('change', function () {
        var d = obj.design[cur.bp] = obj.design[cur.bp] || {};
        if (x.value === '') delete d[k]; else d[k] = x.value;
        if (!Object.keys(d).length) delete obj.design[cur.bp];
        changed(true);
      });
      box.appendChild(field(spec[k][0], x));
    });
    if (spec.split && obj.cols && obj.cols.length === 1) box.appendChild(el('p', { class: 'tve-hint', text: 'Column widths, order and spacing take effect with 2 or 3 columns. On a phone, columns always stack.' }));
    return box;
  }

  function sectionBox(si) {
    var s = cur.tree.sections[si], box = el('div');
    var cols = el('select');
    [1, 2, 3].forEach(function (k) { var o = el('option', { value: k, text: k + ' column' + (k > 1 ? 's' : '') }); if (s.cols.length === k) o.selected = true; cols.appendChild(o); });
    cols.addEventListener('change', function () {
      var k = +cols.value; while (s.cols.length < k) s.cols.push([]);
      if (s.cols.length > k) { var extra = s.cols.splice(k); extra.forEach(function (c) { s.cols[k - 1] = s.cols[k - 1].concat(c); }); }   // blocks of a removed column move to the last one, never lost
      changed(true);
    });
    box.appendChild(field('Columns', cols));
    box.appendChild(field('Background', sel(s, 'bg', Object.keys(cur.data.bgs || { none: 1 }).map(function (k) { return [k, (cur.data.bgs || {})[k] || k]; }))));
    box.appendChild(field('Words line up', sel(s, 'align', [['left', 'Left'], ['center', 'Centred']])));
    box.appendChild(el('h4', { text: 'Design: ' + (cur.data.bps || {})[cur.bp][0], style: 'margin:.8rem 0 0;font:700 .9rem Georgia,serif' }));
    box.appendChild(designBox(s, cur.data.design.section));
    box.appendChild(el('div', { class: 'tve-row', style: 'margin-top:.7rem' }, [
      btn('↑ Up', function () { if (si > 0) { var x = cur.tree.sections.splice(si, 1)[0]; cur.tree.sections.splice(si - 1, 0, x); cur.sel = { s: si - 1 }; changed(true); } }, 'sm'),
      btn('↓ Down', function () { if (si < cur.tree.sections.length - 1) { var x = cur.tree.sections.splice(si, 1)[0]; cur.tree.sections.splice(si + 1, 0, x); cur.sel = { s: si + 1 }; changed(true); } }, 'sm'),
      btn('⧉ Copy the section', function () { cur.tree.sections.splice(si + 1, 0, clone(s)); cur.sel = { s: si + 1 }; changed(true); }, 'sm'),
      btn('✕ Remove the section', function (e) {
        ask('Remove section ' + (si + 1) + ' and everything in it?', e.currentTarget, 'Remove', true).then(function (y) { if (y) { cur.tree.sections.splice(si, 1); cur.sel = null; cur.tab = 'layout'; changed(true); } });
      }, 'sm no')]));
    return box;
  }

  function layoutBox() {
    var bd = el('div');
    cur.tree.sections.forEach(function (s, si) {
      var on = cur.sel && cur.sel.s === si && cur.sel.b == null;
      var h = el('span', { class: 'tve-h', title: 'Drag to move the section', 'aria-label': 'Drag to move the section', text: '⠿' });
      h.addEventListener('pointerdown', function (e) { startDrag(e, { kind: 'sec', s: si }, 'Section ' + (si + 1)); });
      var head = el('div', { class: 'tve-lsh' + (on ? ' on' : ''), 'data-tvl-s': si }, [h, el('strong', { text: 'Section ' + (si + 1) + ' · ' + s.cols.length + ' column' + (s.cols.length > 1 ? 's' : '') }), el('span', { class: 'tve-hint', text: 'Settings ›' })]);
      head.addEventListener('click', function (e) { if (e.target === h) return; pick({ s: si }); });
      var sec = el('div', { class: 'tve-lsec' }, [head]);
      s.cols.forEach(function (c, ci) {
        var col = el('div', { class: 'tve-lcol' });
        if (s.cols.length > 1) col.appendChild(el('h5', { text: 'Column ' + (ci + 1) }));
        c.forEach(function (b, bi) {
          var hb = el('span', { class: 'tve-h', title: 'Drag to move it', 'aria-label': 'Drag to move it', text: '⠿' });
          hb.addEventListener('pointerdown', function (e) { startDrag(e, { kind: 'block', s: si, c: ci, b: bi }, summary(b).slice(0, 40)); });
          var row = el('div', { class: 'tve-lb' + (cur.sel && cur.sel.s === si && cur.sel.c === ci && cur.sel.b === bi ? ' on' : ''), 'data-tvl-b': si + '.' + ci + '.' + bi }, [hb, el('span', { text: summary(b) })]);
          row.addEventListener('click', function (e) { if (e.target === hb) return; pick({ s: si, c: ci, b: bi }); });
          col.appendChild(row);
        });
        var drop = el('div', { class: 'tve-drop', 'data-tvl-c': si + '.' + ci, text: c.length ? 'Drop here to put it last' : 'Empty: drop a block here, or tap one in Add' });
        drop.addEventListener('click', function () { cur.sel = { s: si, c: ci, b: c.length - 1 }; if (!c.length) cur.sel.b = null; cur.tab = 'add'; draw(); });
        col.appendChild(drop);
        sec.appendChild(col);
      });
      bd.appendChild(sec);
    });
    bd.appendChild(btn('+ Add a section', function () { cur.tree.sections.push(newSection()); cur.sel = { s: cur.tree.sections.length - 1 }; cur.tab = 'section'; changed(true); }));
    return bd;
  }

  function addBox() {
    var bd = el('div'), types = cur.data.types || {}, s = cur.sel;
    bd.appendChild(el('p', { class: 'tve-hint', text: 'Tap one to add it ' + (s && s.b != null ? 'after the block you picked' : s ? 'to the end of ' + (s.c != null ? 'column ' + (s.c + 1) + ' of ' : '') + 'section ' + (s.s + 1) : 'at the end') + ', or drag it to its place on the page.' }));
    var grid = el('div', { class: 'tve-wid' }), liveGrid = el('div', { class: 'tve-wid' });
    Object.keys(types).forEach(function (t) {
      var w = el('div', { class: 'tve-w', role: 'button', tabindex: '0', title: types[t][1], 'aria-label': 'Add ' + types[t][0] + ': ' + types[t][1] }, [el('i', { text: ICON[t] || '+' }), types[t][0]]);
      w.addEventListener('pointerdown', function (e) { startDrag(e, { kind: 'new', t: t }, types[t][0]); });
      w.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); addBlock(t); } });
      (live(t) ? liveGrid : grid).appendChild(w);
    });
    bd.appendChild(grid);
    if (liveGrid.children.length) {
      bd.appendChild(el('h4', { text: 'Parts of the site', style: 'margin:.9rem 0 .2rem;font:700 .9rem Georgia,serif' }));
      bd.appendChild(el('p', { class: 'tve-hint', text: 'They draw themselves from our data, so they stay current. Coming next: the engage bar and a form.' }));
      bd.appendChild(liveGrid);
    }
    return bd;
  }

  /** A page of ours: how it shows in search engines and when shared. Saved at once (not part of the draft). */
  function pageBox() {
    var pg = cur.data.page, can = cur.data.can || {}, f = { title: pg.title, summary: pg.summary, share_image: pg.share_image };
    var box = el('div');
    box.appendChild(el('p', { class: 'tve-note', text: 'How this page shows in search results and when it\'s shared. These are saved for the page at once, apart from the draft' + (pg.status !== 'live' ? ' (the page itself isn\'t live yet).' : '.') }));
    var t = inp(f, 'title', { extra: { maxlength: '120', 'data-spell': '' } }), d = inp(f, 'summary', { area: true, extra: { maxlength: '300', rows: '3' } }), im = inp(f, 'share_image', { extra: { placeholder: 'https://… or upload one', spellcheck: 'false' } });
    var count = el('p', { class: 'tve-hint' }), cnt = function () { count.textContent = (f.summary || '').length + ' of 300 letters. Search engines show about the first 155.'; };
    d.addEventListener('input', cnt); cnt();
    [t, d, im].forEach(function (x) { x.addEventListener('input', function () { cur.pageDirty = true; }); });
    box.appendChild(field('Title (in the browser tab and search results)', t));
    box.appendChild(field('Search description', d)); box.appendChild(count);
    var up = btn('Upload a picture', null, 'sm'), file = el('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', hidden: '', 'data-art': 'off' });
    up.addEventListener('click', function () { file.click(); });
    file.addEventListener('change', function () {
      var fl = file.files && file.files[0]; file.value = ''; if (!fl || !window.TvUpload) { if (fl) say('The uploader isn\'t on this page: reload it and try again.', up, true); return; }
      busy(up, true);
      TvUpload.send([fl], { target: 'block_image', ctx: { zone: cur.zone }, el: box }).then(function (res) {
        busy(up, false); var r = (res && res[0]) || {}, got = r.result || r;
        if (r.ok === false || r.error || !got.url) { say((r.error && (r.error.message || r.error)) || 'The upload didn\'t go through. Try again.', up, true); return; }
        f.share_image = got.url; im.value = got.url; cur.pageDirty = true; say('Uploaded: Save page settings keeps it.', up);
      }, function () { busy(up, false); say('The upload didn\'t go through. Try again.', up, true); });
    });
    box.appendChild(field('Share picture (shown when the page is shared)', im)); box.appendChild(el('div', {}, [up, file]));
    box.appendChild(el('p', { class: 'tve-hint', text: 'A wide picture works best: about 1200 by 630.' }));
    var save = btn('Save page settings', function (e) {
      var b = e.currentTarget; busy(b, true);
      api({ action: 'page', title: f.title, summary: f.summary, share_image: f.share_image }).then(function (j) {
        busy(b, false); cur.data.page = j.page || cur.data.page; cur.pageDirty = false; say(j.message, b);
      }, function (x) { busy(b, false); say(x.message, b, true); });
    }, 'go');
    if (!can.publish) { save.disabled = true; save.title = 'Saving these needs Pages: publish (System Configuration → Permissions).'; }
    box.appendChild(el('p', { style: 'margin-top:.7rem' }, [save]));
    if (!can.publish) box.appendChild(el('p', { class: 'tve-hint', text: 'Saving these needs Pages: publish (System Configuration → Permissions).' }));
    box.appendChild(el('p', { class: 'tve-hint' }, ['The page\'s address and its own text stay in the admin: ', el('a', { href: '/admin/market/pages', text: 'Marketplace & Storefronts → Our pages' }), '.']));
    return box;
  }

  function pick(s) {
    cur.sel = s;
    if (s.b != null) { if (cur.tab !== 'design') cur.tab = 'manage'; } else cur.tab = 'section';
    draw(); mark();
    var t = s.b != null ? cur.el.querySelector('[data-tvb-b="' + s.s + '.' + s.c + '.' + s.b + '"]') : cur.el.querySelector('[data-tvb-s="' + s.s + '"]');
    if (t) { var r = t.getBoundingClientRect(), top = panel && window.innerWidth < 900 ? 0.32 : 0.6; if (r.bottom < 0 || r.top > window.innerHeight * top) window.scrollBy({ top: r.top - window.innerHeight * 0.12, behavior: 'smooth' }); }
  }

  function act(b, action, extra, ok) {
    busy(b, true);
    return api(Object.assign({ action: action }, extra || {})).then(function (j) {
      busy(b, false); cur.dirty = false;
      try { sessionStorage.setItem(REOPEN, JSON.stringify({ zone: cur.zone, msg: j.message, view: ok || 'edit' })); } catch (e) {}
      location.reload();   // the page shows the draft, or what's live now
    }, function (e) { busy(b, false); say(e.message, b, true); });
  }
  function isEmpty(t) { return !t.sections.some(function (s) { return s.cols.some(function (c) { return c.length; }); }); }

  function draw() {
    var keep = panel ? panel.querySelector('.tve-bd').scrollTop : 0, sameTab = panel && panel.getAttribute('data-tab') === cur.tab + cur.view;
    if (panel) panel.remove();
    var st = cur.data.state, can = cur.data.can || {};
    if (cur.sel && cur.sel.b != null && !block(cur.sel)) cur.sel = null;
    if (cur.sel && !cur.tree.sections[cur.sel.s]) cur.sel = null;
    if (!cur.sel && (cur.tab === 'manage' || cur.tab === 'design' || cur.tab === 'section')) cur.tab = 'layout';
    if (cur.tab === 'page' && (!cur.data.page || cur.sel)) cur.tab = 'layout';
    var line = st.draft ? 'Draft saved' + (st.draft_by ? ' by ' + st.draft_by : '') + (st.draft_at ? ', ' + when(st.draft_at.replace(' ', 'T') + 'Z', st.draft_tz) : '') + ': only our team sees it.' : st.live_version ? 'Live: version ' + st.live_version + '.' : 'Not published yet: visitors see the page as it was.';
    panel = el('div', { class: 'tve', role: 'dialog', 'aria-label': 'Edit ' + cur.label, 'data-tab': cur.tab + cur.view });
    var hd = el('div', { class: 'tve-hd' }, [el('b', { text: cur.label }), el('button', { type: 'button', class: 'tve-x', title: 'Close', 'aria-label': 'Close', text: '✕', on: close })]);
    var row = el('div', { class: 'tve-row' });
    if (cur.view === 'edit') {
      row.appendChild(btn('Save draft', function (e) { act(e.currentTarget, 'save', { tree: cur.tree }); }, '', { 'data-save': '' }));
      if (cur.dirty) row.lastChild.appendChild(el('span', { class: 'tve-dot', title: 'Not saved yet', 'aria-label': 'Not saved yet' }));
      if (can.publish) row.appendChild(btn('Publish', function (e) {
        var b = e.currentTarget;
        ask(isEmpty(cur.tree) ? 'There\'s nothing in it: publishing leaves this space empty for visitors. Publish anyway?' : 'Publish this to everyone now? It becomes the next version; Versions can roll it back.', b, 'Publish', isEmpty(cur.tree))
          .then(function (y) { if (y) act(b, 'publish', { tree: cur.tree }); });
      }, 'go'));
      var menu = el('span', { class: 'tve-menu' }), list = null;
      var more = btn('▾', function () {
        if (list) { list.remove(); list = null; return; }
        list = el('div', { role: 'menu' }, [btn('Versions and roll back', function () { cur.view = 'versions'; draw(); })]);
        if (st.draft) list.appendChild(btn('Throw the draft away', function (e) {
          var b = e.currentTarget; ask('Throw the draft away? The page goes back to what\'s live.', b, 'Throw it away', true).then(function (y) { if (y) act(b, 'discard'); });
        }, 'no'));
        menu.appendChild(list);
      }, '', { title: 'More', 'aria-label': 'More: versions, throw the draft away', 'aria-haspopup': 'menu' });
      menu.appendChild(more); row.appendChild(menu);
      var bps = el('span', { class: 'tve-bps', role: 'group', 'aria-label': 'View as' });
      ['d', 't', 'p'].forEach(function (k) { var n = ((cur.data.bps || {})[k] || [k])[0]; bps.appendChild(el('button', { type: 'button', html: SVG[k], title: n, 'aria-label': 'View as ' + n, 'aria-pressed': String(cur.bp === k), on: function () { setView(k); } })); });
      row.appendChild(bps);
    } else row.appendChild(btn('← Back to editing', function () { cur.view = 'edit'; draw(); }));
    hd.appendChild(row);
    hd.appendChild(el('small', { text: line }));
    panel.appendChild(hd);

    var bd = el('div', { class: 'tve-bd' });
    if (cur.view === 'edit') {
      var tabs = el('div', { class: 'tve-tabs', role: 'tablist' });
      var tlist = [['add', 'Add'], ['layout', 'Layout']];
      if (cur.data.page && !cur.sel) tlist.push(['page', 'Page']);
      if (cur.sel && cur.sel.b != null) tlist.push(['manage', 'Manage'], ['design', 'Design']);
      else if (cur.sel) tlist.push(['section', 'Section ' + (cur.sel.s + 1)]);
      tlist.forEach(function (t) { tabs.appendChild(el('button', { type: 'button', role: 'tab', 'aria-selected': String(cur.tab === t[0]), text: t[1], on: function () { cur.tab = t[0]; draw(); } })); });
      panel.appendChild(tabs);
      if (cur.tab === 'add') bd.appendChild(addBox());
      else if (cur.tab === 'layout') bd.appendChild(layoutBox());
      else if (cur.tab === 'section') bd.appendChild(sectionBox(cur.sel.s));
      else if (cur.tab === 'page') bd.appendChild(pageBox());
      else {
        var b = block(cur.sel);
        bd.appendChild(el('p', { class: 'tve-row', style: 'margin:0 0 .4rem' }, [el('strong', { text: typeName(b.t) + ' · section ' + (cur.sel.s + 1) + (cur.tree.sections[cur.sel.s].cols.length > 1 ? ', column ' + (cur.sel.c + 1) : ''), style: 'flex:1;color:#92400E' }),
          btn('↑', function () { nudge(-1); }, 'sm', { title: 'Move up', 'aria-label': 'Move up' }), btn('↓', function () { nudge(1); }, 'sm', { title: 'Move down', 'aria-label': 'Move down' }),
          btn('⧉', copyPicked, 'sm', { title: 'Copy it', 'aria-label': 'Copy it' }), btn('✕', function (e) { removePicked(e.currentTarget); }, 'sm no', { title: 'Remove it', 'aria-label': 'Remove it' }),
          btn('Done', function () { cur.sel = null; cur.tab = 'layout'; draw(); mark(); }, 'sm')]));
        bd.appendChild(cur.tab === 'design' ? designBox(b, cur.data.design.block) : blockBox(b));
      }
    } else {
      var vs = cur.data.versions || [];
      if (!vs.length) bd.appendChild(el('p', { text: 'Nothing published here yet.' }));
      vs.forEach(function (v) {
        var r = el('div', { class: 'tve-v' }, [el('span', { text: 'Version ' + v.version + (v.version === st.live_version ? ' (live)' : '') + ' · ' + (v.by || 'someone') + ' · ' + when(v.at, v.tz) + (v.note ? ' · ' + v.note : '') })]);
        if (can.publish && v.version !== st.live_version) r.appendChild(btn('Roll back to it', function (e) {
          var b = e.currentTarget; ask('Put version ' + v.version + ' live again? It becomes the next version; nothing is lost.', b, 'Roll back').then(function (y) { if (y) act(b, 'rollback', { version: v.version }, 'versions'); });
        }, 'sm'));
        bd.appendChild(r);
      });
    }
    panel.appendChild(bd);
    document.body.appendChild(panel);
    if (sameTab) bd.scrollTop = keep;
  }

  // a tap on the page while editing picks what's there (links on it don't navigate away)
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-tvb-edit]');
    if (b) { if (cur) { say('Close the zone you\'re editing first.', b, true); return; } open(b.closest('[data-tvb-zone]')); return; }
    if (!cur || !cur.el.contains(e.target)) return;
    var hit = e.target.closest('[data-tvb-b],[data-tvb-c],[data-tvb-s]');
    if (!hit) return;
    e.preventDefault();
    if (hit.hasAttribute('data-tvb-b')) { var p = hit.getAttribute('data-tvb-b').split('.').map(Number); pick({ s: p[0], c: p[1], b: p[2] }); }
    else if (hit.hasAttribute('data-tvb-c')) { var q = hit.getAttribute('data-tvb-c').split('.').map(Number); cur.sel = { s: q[0], c: q[1] }; cur.tab = 'add'; draw(); mark(); }
    else pick({ s: +hit.getAttribute('data-tvb-s') });
  }, true);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && cur && !drag && !(e.target.closest && e.target.closest('input,textarea,select'))) close(); });
  window.addEventListener('beforeunload', function (e) { if (cur && cur.dirty) { e.preventDefault(); e.returnValue = ''; } });
  // back after Save draft, Publish or Roll back: the same zone's panel, open again, with the answer beside it
  var again = null; try { again = JSON.parse(sessionStorage.getItem(REOPEN) || 'null'); sessionStorage.removeItem(REOPEN); } catch (e) {}
  if (again) {
    var z = document.querySelector('[data-tvb-zone="' + String(again.zone).replace(/"/g, '') + '"]');
    if (z) {
      z.scrollIntoView({ block: 'center' });
      setTimeout(function () { say(again.msg || 'Done.', z.querySelector('[data-tvb-edit]')); open(z, again.view); }, 300);
    }
  }
})();
