<?php
// app/lib/Blocks.php — the editor's core (decisions/0159 §3, §6, step 3): a page's content as a tree of blocks, edited in
// place on the real page by staff with pages.edit, kept as a draft only the team sees (the draft is the preview), put
// live with pages.publish, every publish a numbered version, Roll back to any of them.
//
//   zone      a place on a page that holds blocks: a coded page adds one where a release puts it (Blocks::zone(), the home
//             page's "home.after-doors" first), and each of our own pages (SitePages) has one under its text ("page.<id>").
//             What a coded page showed before stays its fallback, so nothing built is lost (0159 §2).
//   tree      ['sections' => [section…]]; a section is ['cols' => [[block…], …] (1 to 3 columns), 'bg' => none|sand|sage,
//             'align' => left|center]; a block is one of TYPES. Structured, never free positions: sections stack, columns
//             sit side by side in a grid and stack on phones (0159 §6, 0058 §11).
//   versions  each publish keeps its tree, numbered, with who and when (and the device's time zone). Roll back publishes a
//             copy of an earlier one as the next version, so the history only grows.
// Rendered on the server to plain HTML (escaped text; links and pictures only from safe addresses), the same for everyone;
// only an editor gets the zone's outline, its Edit button and js/tv-editor.js.
//   design    (step 4a) each section and block may carry ['design' => ['d' => […], 't' => […], 'p' => […]]]: desktop, tablet,
//             phone. Tablet takes what desktop has unless it says otherwise, phone takes tablet's. Only the choices in
//             SEC_DESIGN / BLOCK_DESIGN are kept. They draw as classes answered by container queries on the zone's own
//             width, so the editor's tablet and phone views (the zone narrowed) show exactly what those screens get.
//   live      (step 4b) blocks that are parts of the site, drawn by its own code and data: LIVE is their registry (name,
//             what it is, its settings, where it may go). A new one, or a change to one, is a code release; the editor
//             only places and sets them up (0159 §3.3). Those that need the database get it from useDb() (zone() and
//             /api/blocks.php call it); those that run in the browser draw from the site's public APIs (js/tv-blocks.js),
//             so they keep the same rules as the pages they come from.
// The engage bar and a form as live blocks, global components (header, footer) and scheduled publishing are step 4c.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/SitePages.php';

final class Blocks
{
    /** Who may (Founder only until a role is given them, System Configuration → Permissions). */
    public const PERMS = ['pages.edit' => 'Pages: edit content in place and save drafts', 'pages.publish' => 'Pages: publish content and roll it back'];
    /** The kinds of block in the core (more, and live components, in step 4): [name, what it is]. */
    public const TYPES = ['heading' => ['Heading', 'A title for what follows'], 'text' => ['Text', 'Paragraphs, lists, bold, italic and links'],
        'image' => ['Picture', 'One picture, with words for those who can\'t see it'], 'button' => ['Button', 'A link that looks like a button'],
        'divider' => ['Divider', 'A thin line between parts'], 'spacer' => ['Spacer', 'Empty space, to give things room'],
        // live components (step 4b): the site's own parts
        'search' => ['Search box', 'The site\'s search, ready to type in, or with words of your own already in it'],
        'listings' => ['Businesses', 'Business cards from our directory for a town and a kind of business'],
        'map' => ['Map button', 'Opens the site\'s map of businesses for a town and a kind of business'],
        'guide' => ['Guide', 'A card for a town\'s or area\'s guide, linking to it'],
        'gocode' => ['GO Code', 'The QR code and short trvgo.us address for this page, or another of ours']];
    /**
     * The live components (0159 §3.3): key => [where it may go (zone starts, '' for anywhere), settings]. Each setting is
     * [label, kind (text|select), choices or max length, hint]. The first choice of a select is its default.
     */
    public const LIVE = [
        'search'   => ['', ['words' => ['Words already in it (optional)', 'text', 80, 'Leave empty for an empty box'],
                            'label' => ['What the box says before typing', 'text', 60, 'For example: Find a place, a business or a trail']]],
        'listings' => ['', ['town' => ['Town', 'text', 60, 'Town and state, like Cortez, CO'],
                            'cat' => ['Kind of business (optional)', 'text', 60, 'Its name as in the directory, like restaurants'],
                            'n' => ['How many', 'select', ['6' => '6', '3' => '3', '9' => '9', '12' => '12']],
                            'sort' => ['Order', 'select', ['best' => 'Best first', 'name' => 'A to Z', 'distance' => 'Nearest the town\'s centre']]]],
        'map'      => ['', ['town' => ['Town', 'text', 60, 'Town and state, like Cortez, CO'],
                            'cat' => ['Kind of business (optional)', 'text', 60, 'Like restaurants, or leave empty for all'],
                            'label' => ['Words on the button', 'text', 60, 'For example: See them on the map']]],
        'guide'    => ['', ['town' => ['Town or area', 'text', 60, 'The guide\'s town, like Cortez']]],
        'gocode'   => ['', ['path' => ['Which page (optional)', 'text', 200, 'Leave empty for this page, or a page of ours like /directory/'],
                            'caption' => ['Words under it (optional)', 'text', 120, 'For example: Scan to open this page on your phone']]],
    ];
    private static ?PDO $db = null;
    private static string $here = '/';
    /** The breakpoints (decisions/0159 §6): key => [name, the zone's width it starts at]. */
    public const BPS = ['d' => ['Desktop', 900], 't' => ['Tablet', 560], 'p' => ['Phone', 0]];
    /** What a section's design may set, per breakpoint: key => [label, [value => name, …]] (the first value is the default). */
    public const SEC_DESIGN = [
        'pad'    => ['Inner space', ['auto' => 'Automatic', '0' => 'None', 's' => 'Small', 'm' => 'Medium', 'l' => 'Large']],
        'gap'    => ['Space between columns', ['m' => 'Medium', 's' => 'Small', 'l' => 'Large']],
        'split'  => ['Column widths', ['even' => 'Even', 'wide-left' => 'Wider left', 'wide-right' => 'Wider right']],
        'valign' => ['Line columns up at', ['top' => 'The top', 'middle' => 'The middle', 'bottom' => 'The bottom']],
        'rev'    => ['Column order', ['0' => 'As placed', '1' => 'Reversed']],
        'hide'   => ['Show', ['0' => 'Shown', '1' => 'Hidden here']],
    ];
    /** What a block's design may set, per breakpoint. */
    public const BLOCK_DESIGN = [
        'align' => ['Alignment', ['inherit' => 'As the section', 'left' => 'Left', 'center' => 'Centred', 'right' => 'Right']],
        'w'     => ['Width', ['full' => 'Full', 'wide' => 'Three quarters', 'half' => 'Half', 'third' => 'A third']],
        'mt'    => ['Space above', ['0' => 'None', 's' => 'Small', 'm' => 'Medium', 'l' => 'Large', 'xl' => 'Extra large']],
        'mb'    => ['Space below', ['0' => 'None', 's' => 'Small', 'm' => 'Medium', 'l' => 'Large', 'xl' => 'Extra large']],
        'hide'  => ['Show', ['0' => 'Shown', '1' => 'Hidden here']],
    ];
    public const BGS = ['none' => 'No background', 'sand' => 'Sand', 'sage' => 'Sage'];
    private const MAX_SECTIONS = 20, MAX_BLOCKS = 30, MAX_TEXT = 20000;

    private static bool $ready = false;
    private static bool $kit = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci';
        $pdo->exec('CREATE TABLE IF NOT EXISTS site_block_zones (zone VARCHAR(80) NOT NULL PRIMARY KEY, draft MEDIUMTEXT NULL, draft_by INT UNSIGNED NULL,
            draft_name VARCHAR(100) NOT NULL DEFAULT \'\', draft_at DATETIME NULL, draft_tz VARCHAR(64) NOT NULL DEFAULT \'\', live_version INT UNSIGNED NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL)' . $tail);
        $pdo->exec('CREATE TABLE IF NOT EXISTS site_block_versions (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, zone VARCHAR(80) NOT NULL, version INT UNSIGNED NOT NULL,
            tree MEDIUMTEXT NOT NULL, by_user INT UNSIGNED NULL, by_name VARCHAR(100) NOT NULL DEFAULT \'\', at DATETIME NOT NULL, tz VARCHAR(64) NOT NULL DEFAULT \'\',
            note VARCHAR(200) NOT NULL DEFAULT \'\', UNIQUE KEY uq_block_version (zone, version))' . $tail);
        self::$ready = true;
    }

    // ---- who ----------------------------------------------------------------------------------------------------------

    /** [allowed, why not]. Staff signed in with their staff login, and the permission (Founder until given to a role). */
    public static function can(string $perm): array
    {
        if (!isset(self::PERMS[$perm])) return [false, 'Not a pages permission.'];
        if (PHP_SAPI === 'cli') return [true, ''];
        if (!class_exists('Auth') || !Auth::currentUser()) return [false, 'Sign in first.'];
        require_once __DIR__ . '/../admin/Access.php';
        if (Access::staff() === null) return [false, 'Sign in with your staff login (the admin) first.'];
        [$ok, $why] = Access::can($perm, ['min' => 'founder', 'depts' => []]);
        return [$ok, $ok ? '' : (($why ?: 'Your role can\'t do this') . '. It\'s given in System Configuration → Permissions.')];
    }

    private static function need(string $perm): void
    {
        [$ok, $why] = self::can($perm);
        if (!$ok) throw new RuntimeException($why);
    }

    public static function zoneOk(string $zone): bool { return (bool) preg_match('/^[a-z0-9][a-z0-9._-]{1,79}$/', $zone); }

    // ---- the tree: kept clean whatever is sent --------------------------------------------------------------------------

    /** A tree as it may be kept: only known kinds and fields, lengths capped, addresses checked. */
    public static function clean($tree): array
    {
        $out = ['sections' => []];
        foreach (array_slice((array) (is_array($tree) ? ($tree['sections'] ?? []) : []), 0, self::MAX_SECTIONS) as $s) {
            if (!is_array($s)) continue;
            $cols = [];
            foreach (array_slice((array) ($s['cols'] ?? []), 0, 3) as $c) {
                $blocks = [];
                foreach (array_slice(is_array($c) ? $c : [], 0, self::MAX_BLOCKS) as $b) if (is_array($b) && ($cb = self::cleanBlock($b))) $blocks[] = $cb;
                $cols[] = $blocks;
            }
            if (!$cols) $cols = [[]];
            $sec = ['cols' => $cols, 'bg' => isset(self::BGS[$s['bg'] ?? '']) ? $s['bg'] : 'none', 'align' => ($s['align'] ?? '') === 'center' ? 'center' : 'left'];
            if ($d = self::cleanDesign($s['design'] ?? null, self::SEC_DESIGN)) $sec['design'] = $d;
            $out['sections'][] = $sec;
        }
        return $out;
    }

    /** Only known keys and values per breakpoint; nothing kept that equals what it would inherit anyway. */
    private static function cleanDesign($d, array $spec): array
    {
        if (!is_array($d)) return [];
        $out = [];
        foreach (array_keys(self::BPS) as $bp) {
            foreach ((is_array($d[$bp] ?? null) ? $d[$bp] : []) as $k => $v) {
                $v = (string) $v;
                if (isset($spec[$k]) && isset($spec[$k][1][$v])) $out[$bp][$k] = $v;
            }
        }
        return $out;
    }

    /** The values in force at each breakpoint: defaults, then desktop, then tablet, then phone. */
    private static function resolve(array $d, array $spec): array
    {
        $cur = []; foreach ($spec as $k => $x) $cur[$k] = (string) array_key_first($x[1]);
        $out = [];
        foreach (array_keys(self::BPS) as $bp) { $cur = array_merge($cur, $d[$bp] ?? []); $out[$bp] = $cur; }
        return $out;
    }

    /** Classes for the values that differ from the default, per breakpoint ("tvb-p-align-center"). */
    private static function designClasses(array $d, array $spec): string
    {
        if (!$d) return '';
        $c = '';
        foreach (self::resolve($d, $spec) as $bp => $vals)
            foreach ($vals as $k => $v) if ($v !== (string) array_key_first($spec[$k][1])) $c .= ' tvb-' . $bp . '-' . $k . '-' . $v;
        return $c;
    }

    private static function cleanBlock(array $b): ?array
    {
        $cb = self::cleanBlockBody($b);
        if ($cb && ($d = self::cleanDesign($b['design'] ?? null, self::BLOCK_DESIGN))) $cb['design'] = $d;
        return $cb;
    }

    private static function cleanBlockBody(array $b): ?array
    {
        $t = (string) ($b['t'] ?? '');
        $str = fn ($k, $n) => mb_substr(trim((string) ($b[$k] ?? '')), 0, $n);
        switch ($t) {
            case 'heading': return ['t' => 'heading', 'text' => $str('text', 200), 'level' => (int) ($b['level'] ?? 2) === 3 ? 3 : 2];
            case 'text': return ['t' => 'text', 'md' => mb_substr((string) ($b['md'] ?? ''), 0, self::MAX_TEXT)];
            case 'image':
                $src = $str('src', 500);
                return ['t' => 'image', 'src' => self::safeUrl($src, true) ? $src : '', 'alt' => $str('alt', 200), 'caption' => $str('caption', 300)];
            case 'button':
                $href = $str('href', 500);
                return ['t' => 'button', 'label' => $str('label', 80), 'href' => self::safeUrl($href, false) ? $href : '', 'style' => ($b['style'] ?? '') === 'plain' ? 'plain' : 'primary'];
            case 'divider': return ['t' => 'divider'];
            case 'spacer': return ['t' => 'spacer', 'size' => in_array($b['size'] ?? '', ['s', 'm', 'l', 'xl'], true) ? $b['size'] : 'm'];
        }
        if (isset(self::LIVE[$t])) {   // a live component: only its own settings, each checked against its kind
            $out = ['t' => $t];
            foreach (self::LIVE[$t][1] as $k => [$label, $kind, $x]) {
                $v = trim((string) ($b[$k] ?? ''));
                if ($kind === 'select') $out[$k] = isset($x[$v]) ? $v : (string) array_key_first($x);
                else $out[$k] = mb_substr(preg_replace('/[\x00-\x1F<>"]+/u', ' ', $v), 0, (int) $x);
            }
            if ($t === 'gocode' && $out['path'] !== '' && !preg_match('#^/(?!/)[^\s]*$#', $out['path'])) $out['path'] = '';
            return $out;
        }
        return null;
    }

    /** Pictures from our own uploads or images, or https; links to our pages, https, email or phone. */
    public static function safeUrl(string $u, bool $img): bool
    {
        if ($u === '') return true;
        return $img ? (bool) preg_match('#^(https://[^\s"<>]+|/uploads/[^\s"<>]+|/image/[^\s"<>]+)$#', $u) : (bool) preg_match('#^(/(?!/)[^\s"<>]*|https://[^\s"<>]+|mailto:[^\s"<>]+|tel:[0-9+() -]+|\#[\w-]*)$#', $u);
    }

    // ---- drawing ------------------------------------------------------------------------------------------------------

    /**
     * The tree as HTML (no zone wrapper). Empty sections and blocks draw nothing, except for an editor ($paths: each section
     * and block marked with where it sits in the tree, so a tap on the page picks it in the panel, and blocks hidden at a
     * breakpoint shown faded instead of left out).
     */
    public static function render(array $tree, bool $paths = false): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $h = '';
        foreach (($tree['sections'] ?? []) as $si => $s) {
            $cols = ''; $any = false;
            foreach ($s['cols'] as $ci => $c) {
                $in = '';
                foreach ($c as $bi => $b) {
                    $x = self::blockHtml($b, $e);
                    if ($x === '' && $paths) $x = '<p class="tvb-blank">' . $e((self::TYPES[$b['t']] ?? [$b['t']])[0]) . ': ' . $e(self::why($b)) . '</p>';
                    if ($x === '') continue;
                    $in .= '<div class="tvb-b' . self::designClasses($b['design'] ?? [], self::BLOCK_DESIGN) . '"' . ($paths ? ' data-tvb-b="' . $si . '.' . $ci . '.' . $bi . '"' : '') . '>' . $x . '</div>';
                }
                if ($in === '' && $paths) $in = '<p class="tvb-blank" data-tvb-c="' . $si . '.' . $ci . '">Empty column</p>';
                $cols .= '<div class="tvb-col">' . $in . '</div>';
                $any = $any || $in !== '';
            }
            if (!$any) continue;   // a section with nothing in it draws nothing
            $h .= '<section class="tvb-sec tvb-bg-' . $s['bg'] . ($s['align'] === 'center' ? ' tvb-center' : '') . ($s['bg'] !== 'none' ? ' tv-bleed' : '')
                . self::designClasses($s['design'] ?? [], self::SEC_DESIGN) . '"' . ($paths ? ' data-tvb-s="' . $si . '"' : '') . '><div class="tvb-cols tvb-c' . count($s['cols']) . '">' . $cols . '</div></section>';
        }
        return $h;
    }

    /** Why a block draws nothing yet (an editor's placeholder): visitors see nothing in its place. */
    private static function why(array $b): string
    {
        if ($b['t'] === 'guide') return trim($b['town']) === '' ? 'name its town' : 'no published guide found for "' . $b['town'] . '" (visitors see nothing here)';
        if (in_array($b['t'], ['listings', 'map'], true) && $b['town'] === '') return 'name its town';
        if ($b['t'] === 'gocode') return 'no short address could be made for that page yet';
        return 'not filled in yet';
    }

    private static function blockHtml(array $b, callable $e): string
    {
        switch ($b['t']) {
            case 'heading': return $b['text'] !== '' ? '<h' . $b['level'] . ' class="tvb-h' . $b['level'] . '">' . $e($b['text']) . '</h' . $b['level'] . '>' : '';
            case 'text': return trim($b['md']) !== '' ? '<div class="tvb-text">' . SitePages::html($b['md']) . '</div>' : '';
            case 'image': return $b['src'] !== '' ? '<figure class="tvb-img"><img src="' . $e($b['src']) . '" alt="' . $e($b['alt']) . '" loading="lazy">' . ($b['caption'] !== '' ? '<figcaption>' . $e($b['caption']) . '</figcaption>' : '') . '</figure>' : '';
            case 'button': return $b['label'] !== '' && $b['href'] !== '' ? '<p class="tvb-btnrow"><a class="tvb-btn' . ($b['style'] === 'plain' ? ' plain' : '') . '" href="' . $e($b['href']) . '"' . (str_starts_with($b['href'], 'http') ? ' rel="noopener" target="_blank"' : '') . '>' . $e($b['label']) . '</a></p>' : '';
            case 'divider': return '<hr class="tvb-hr">';
            case 'spacer': return '<div class="tvb-space tvb-space-' . $b['size'] . '" aria-hidden="true"></div>';
        }
        if (isset(self::LIVE[$b['t']])) return self::live($b, $e);
        return '';
    }

    /** The database for the live components that read it (zone() and /api/blocks.php give it), and the page they're on. */
    public static function useDb(PDO $pdo, string $here = ''): void
    {
        self::$db = $pdo;
        if ($here !== '') self::$here = $here;
        elseif (isset($_SERVER['REQUEST_URI'])) self::$here = (string) (parse_url((string) $_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
        $q = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_QUERY) ?: '');
        if ($here === '' && $q !== '' && preg_match('/(?:^|&)s=([a-z0-9-]+)/', $q, $m)) self::$here .= '?s=' . $m[1];   // a page of ours (/pages/view.php?s=…)
    }

    /** "Cortez, CO" → ['Cortez', 'CO']; a town alone keeps no state. */
    private static function townState(string $t): array
    {
        $t = trim($t);
        if (preg_match('/^(.+?),\s*([A-Za-z]{2})$/', $t, $m)) return [trim($m[1]), strtoupper($m[2])];
        return [$t, ''];
    }

    /**
     * A live component, drawn by the site's own code. The browser ones (search, businesses, map) carry their settings
     * for js/tv-blocks.js and a plain link that works without it; the guide and the GO Code read the database here.
     * What has nothing to show draws nothing for visitors (an editor sees why, from render()'s placeholder).
     */
    private static function live(array $b, callable $e): string
    {
        switch ($b['t']) {
            case 'search':
                return self::liveJs() . '<form class="tvb-search" action="/directory/" method="get" role="search" data-tvb-search><input type="search" name="q" value="' . $e($b['words']) . '" placeholder="' . $e($b['label'] !== '' ? $b['label'] : 'Find a place, a business or a trail') . '" aria-label="Search Traversence" data-spell>'
                    . '<button type="submit" class="tvb-btn">Search</button></form>';
            case 'listings':
            case 'map':
                if ($b['town'] === '') return '';
                [$town, $st] = self::townState($b['town']);
                $dir = '/directory/?' . http_build_query(array_filter(['town' => $town, 'state' => $st, 'q' => $b['cat']]));
                $data = ' data-town="' . $e($town) . '" data-state="' . $e($st) . '" data-cat="' . $e($b['cat']) . '" data-dir="' . $e($dir) . '"';
                if ($b['t'] === 'map') return self::liveJs() . '<p class="tvb-btnrow"><a class="tvb-btn" href="' . $e($dir) . '" data-tvb-map' . $data . '>' . $e($b['label'] !== '' ? $b['label'] : 'See them on the map') . '</a></p>';
                return self::liveJs() . '<div class="tvb-cards" data-tvb-listings' . $data . ' data-n="' . (int) $b['n'] . '" data-sort="' . $e($b['sort']) . '"><p class="tvb-more"><a href="' . $e($dir) . '">See ' . $e($b['cat'] !== '' ? $b['cat'] : 'businesses') . ' in ' . $e($town) . '</a></p></div>';
            case 'guide':
                $g = self::guideFor($b['town']);
                if (!$g) return '';
                return '<a class="tvb-guide" href="' . $e($g['url']) . '"><small>' . $e($g['kind'] ?? 'Guide') . '</small><b>' . $e($g['name']) . '</b>'
                    . ($g['about'] !== '' ? '<span>' . $e(mb_strimwidth(strip_tags((string) $g['about']), 0, 180, '…')) . '</span>' : '') . '<em>Open the guide →</em></a>';
            case 'gocode':
                $path = $b['path'] !== '' ? $b['path'] : self::$here;
                $short = '';
                if (self::$db) { try { require_once __DIR__ . '/ShortCodes.php'; $short = ShortCodes::forPage(self::$db, $path); } catch (Throwable $x) { error_log('blocks gocode: ' . $x->getMessage()); } }
                if ($short === '') return '';
                return '<figure class="tvb-go"><img src="/api/qr.php?page=' . $e(rawurlencode($path)) . '&amp;format=svg" alt="QR code for ' . $e($short) . '" width="180" height="180" loading="lazy">'
                    . '<figcaption><a href="' . $e($short) . '">' . $e(preg_replace('#^https?://#', '', $short)) . '</a>' . ($b['caption'] !== '' ? '<span>' . $e($b['caption']) . '</span>' : '') . '</figcaption></figure>';
        }
        return '';
    }

    /** A page of ours behind a zone ("page.<id>"): what its settings tab edits (title, search description, share picture). */
    public static function pageOf(PDO $pdo, string $zone): ?array
    {
        if (!preg_match('/^page\.(\d+)$/', $zone, $m)) return null;
        $p = SitePages::get($pdo, (int) $m[1]);
        return $p ? ['id' => (int) $p['id'], 'title' => (string) $p['title'], 'summary' => (string) $p['summary'], 'share_image' => (string) ($p['share_image'] ?? ''),
                     'status' => (string) $p['status'], 'url' => SitePages::url($p)] : null;
    }

    /** A town's guide, found by its name as people write it ("Cortez" or "Cortez, CO"); null when there's none live. */
    private static function guideFor(string $town): ?array
    {
        if (!self::$db || trim($town) === '') return null;
        try {
            require_once __DIR__ . '/Guides.php';
            [$name] = self::townState($town);
            $g = Guides::fromQuery(self::$db, ['town' => Guides::slug($name)]);
            if (!$g || !empty($g['planned'])) return null;
            $sh = Guides::shown(self::$db, $g['key']);
            return !empty($sh['sections']) ? $g : null;   // only a guide with something published (and nothing taken down)
        } catch (Throwable $x) { error_log('blocks guide: ' . $x->getMessage()); return null; }
    }

    /** The browser half of the live components, once a page. */
    private static function liveJs(): string
    {
        static $once = false;
        if ($once) return '';
        $once = true;
        return '<script src="/js/tv-blocks.js?v=' . (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-blocks.js') . '" defer></script>';
    }

    /** The blocks' look, once a page (the brand's colours; phones: one column, 3px from the edges, decisions/0058 §11). */
    /** The design classes, answered by the zone's width (container queries), so a narrowed zone previews a phone. */
    private static function designCss(): string
    {
        $sp = ['0' => '0', 's' => '.5rem', 'm' => '1rem', 'l' => '2rem', 'xl' => '3.5rem'];
        $pad = ['0' => '0', 's' => '.6rem .7rem', 'm' => '1.1rem 1.25rem', 'l' => '2rem 2.2rem'];
        $css = '.tvb-zone{container:tvb/inline-size}.tvb-b{box-sizing:border-box}.tvb-hr{border:0;border-top:1.5px solid #D9C9A3;margin:.8rem 0}'
            . '.tvb-space-s{height:.75rem}.tvb-space-m{height:1.75rem}.tvb-space-l{height:3rem}.tvb-space-xl{height:5rem}'
            . '.tvb-blank{border:1.5px dashed #CBB98D;border-radius:.5rem;padding:.4rem .6rem;color:#8A7355;font:600 .8rem system-ui,sans-serif;margin:.3rem 0}'
            . '.tvb-cols{display:grid;gap:1rem;grid-template-columns:minmax(0,1fr)}';
        $q = ['d' => '(min-width:900px)', 't' => '(min-width:560px) and (max-width:899.98px)', 'p' => '(max-width:559.98px)'];
        foreach ($q as $bp => $when) {
            $r = '';
            if ($bp !== 'p') {
                $r .= '.tvb-c2{grid-template-columns:repeat(2,minmax(0,1fr))}.tvb-c3{grid-template-columns:repeat(3,minmax(0,1fr))}'
                    . ".tvb-$bp-split-wide-left .tvb-c2{grid-template-columns:2fr 1fr}.tvb-$bp-split-wide-right .tvb-c2{grid-template-columns:1fr 2fr}"
                    . ".tvb-$bp-split-wide-left .tvb-c3{grid-template-columns:2fr 1fr 1fr}.tvb-$bp-split-wide-right .tvb-c3{grid-template-columns:1fr 1fr 2fr}";
            }
            foreach ($pad as $k => $v) $r .= ".tvb-sec.tvb-$bp-pad-$k{padding:$v}";
            $r .= ".tvb-$bp-gap-s .tvb-cols{gap:.5rem}.tvb-$bp-gap-l .tvb-cols{gap:2rem}"
                . ".tvb-$bp-valign-middle .tvb-cols{align-items:center}.tvb-$bp-valign-bottom .tvb-cols{align-items:end}"
                . ".tvb-$bp-rev-1 .tvb-col:nth-child(1){order:3}.tvb-$bp-rev-1 .tvb-col:nth-child(3){order:1}"
                . ".tvb-$bp-align-left{text-align:left}.tvb-$bp-align-center{text-align:center;margin-left:auto;margin-right:auto}.tvb-$bp-align-right{text-align:right;margin-left:auto}"
                . ".tvb-$bp-align-center .tvb-img img{margin:0 auto}.tvb-$bp-align-right .tvb-img img{margin-left:auto}"
                . ".tvb-$bp-w-wide{max-width:75%}.tvb-$bp-w-half{max-width:50%}.tvb-$bp-w-third{max-width:33.333%}";
            foreach ($sp as $k => $v) $r .= ".tvb-$bp-mt-$k{margin-top:$v}.tvb-$bp-mb-$k{margin-bottom:$v}";
            $r .= ".tvb-$bp-hide-1{display:none}.tvb-edit .tvb-$bp-hide-1{display:block;opacity:.35;outline:1px dashed #8A7355}";
            $css .= "@container tvb $when{" . $r . '}';
        }
        // the editor: the picked section or block, and a phone or tablet view (the zone narrowed in place)
        return $css . '.tvb-edit [data-tvb-b],.tvb-edit [data-tvb-s]{cursor:pointer}.tvb-edit .tvb-picked{outline:2px solid #2F6B4F;outline-offset:2px;border-radius:.3rem}'
            . '.tvb-edit.tvb-view-t,.tvb-edit.tvb-view-p{margin-left:auto;margin-right:auto;background:#FFFBF2;box-shadow:0 0 0 9999px rgba(62,43,31,.08)}'
            . '.tvb-edit.tvb-view-t{max-width:820px}.tvb-edit.tvb-view-p{max-width:390px}';
    }

    private static function kit(): string
    {
        if (self::$kit) return '';
        self::$kit = true;
        return '<style>.tvb-zone{display:block}.tvb-sec{margin:1.2rem 0;border-radius:1rem;color:#3E2B1F}.tvb-bg-sand{background:#F7EFDC;border:1px solid #D9C9A3;padding:1.1rem 1.25rem}'
            . '.tvb-bg-sage{background:#E3EFE8;border:1px solid #B9D8C6;padding:1.1rem 1.25rem}.tvb-center{text-align:center}.tvb-cols{display:grid;gap:1rem}'
            . '.tvb-h2{font:700 1.6rem/1.25 Georgia,serif;margin:.2rem 0 .5rem}.tvb-h3{font:700 1.2rem/1.3 Georgia,serif;margin:.2rem 0 .4rem}'
            . '.tvb-text{font-size:1rem;line-height:1.65}.tvb-text p{margin:.5rem 0}.tvb-text ul{list-style:disc;padding-left:1.3rem}.tvb-text a{color:#92400E;text-decoration:underline}'
            . '.tvb-text h2{font:700 1.3rem Georgia,serif;margin:1rem 0 .4rem}.tvb-text h3{font-weight:700;font-size:1.1rem;margin:.8rem 0 .3rem}'
            . '.tvb-img{margin:.5rem 0}.tvb-img img{max-width:100%;height:auto;border-radius:.6rem;display:block}.tvb-center .tvb-img img{margin:0 auto}.tvb-img figcaption{font-size:.85rem;color:#8A7355;margin-top:.3rem}'
            . '.tvb-btnrow{margin:.6rem 0}.tvb-btn{display:inline-block;background:#92400E;color:#FFFBF2;border-radius:999px;padding:.55rem 1.2rem;font-weight:700;text-decoration:none}'
            . '.tvb-btn.plain{background:transparent;color:#92400E;border:1.5px solid #92400E}'
            . '@media (max-width:767px){.tvb-sec.tv-bleed{margin-left:3px;margin-right:3px;border-radius:.5rem}.tvb-cols{gap:.6rem}}'
            . '.tvb-edit{position:relative;outline:2px dashed #E07F3C;outline-offset:4px;border-radius:.5rem;min-height:3rem}'
            . '.tvb-edit>.tvb-tag{position:absolute;top:-.9rem;left:.4rem;z-index:5;display:flex;gap:.3rem;align-items:center;font:700 .75rem system-ui,sans-serif}'
            . '.tvb-edit>.tvb-tag span{background:#FDE68A;color:#3E2B1F;border-radius:999px;padding:.15rem .5rem}'
            . '.tvb-edit>.tvb-tag button{background:#E07F3C;color:#fff;border:0;border-radius:999px;padding:.3rem .8rem;font:inherit;cursor:pointer}'
            . '.tvb-empty{border:1.5px dashed #CBB98D;border-radius:.6rem;padding:.8rem;color:#8A7355;font-size:.9rem;text-align:center}'
            . '.tvb-search{display:flex;gap:.4rem;max-width:40rem}.tvb-search input{flex:1;min-width:0;font:16px system-ui,sans-serif;border:1.5px solid #CBB98D;border-radius:999px;padding:.55rem 1rem;background:#FFFBF2;color:#3E2B1F}.tvb-search button{border:0;cursor:pointer}'
            . '.tvb-cards{display:grid;gap:.75rem;grid-template-columns:repeat(auto-fill,minmax(15rem,1fr))}.tvb-card{background:#FFFBF2;border:1px solid #E2D4B2;border-radius:.8rem;padding:.75rem .85rem;color:#3E2B1F}'
            . '.tvb-card-h{display:flex;gap:.35rem;align-items:flex-start}.tvb-card-h a.n{flex:1;min-width:0;color:#92400E;text-decoration:underline;font:700 1.02rem Georgia,serif}'
            . '.tvb-ib{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;border:1.5px solid #92400E;background:#FFFBF2;color:#B45309;flex:none}.tvb-ib svg{width:15px;height:15px}'
            . '.tvb-card p{margin:.35rem 0 0;font-size:.88rem;line-height:1.45}.tvb-card .k{font-size:.78rem;color:#8A7355;text-transform:capitalize}.tvb-more{grid-column:1/-1;margin:.2rem 0}.tvb-more a{color:#92400E;text-decoration:underline;font-weight:700}'
            . '.tvb-guide{display:block;max-width:34rem;background:#F7EFDC;border:1px solid #D9C9A3;border-radius:.9rem;padding:.9rem 1.1rem;color:#3E2B1F;text-decoration:none}.tvb-guide small{display:block;font:700 .72rem system-ui;letter-spacing:.05em;text-transform:uppercase;color:#B45309}'
            . '.tvb-guide b{display:block;font:700 1.25rem Georgia,serif;color:#92400E;text-decoration:underline;margin:.15rem 0 .3rem}.tvb-guide span{display:block;font-size:.92rem;line-height:1.5}.tvb-guide em{display:block;margin-top:.4rem;font-style:normal;font-weight:700;color:#92400E}'
            . '.tvb-go{margin:.5rem 0;display:inline-block;text-align:center}.tvb-go img{display:block;width:180px;height:180px;background:#fff;border-radius:.5rem;padding:.4rem}.tvb-go figcaption a{color:#92400E;font-weight:700}.tvb-go figcaption span{display:block;font-size:.85rem;color:#8A7355}'
            . '.tvb-acts{display:flex;gap:.3rem;order:1}.tvb-lk{order:2}@media (max-width:767px){.tvb-card{border-radius:.5rem}.tvb-card-h{flex-wrap:wrap}.tvb-card-h a.n{flex-basis:calc(100% - 40px)}.tvb-acts{order:3;flex-basis:100%}}'
            . self::designCss() . '</style>';
    }

    // ---- reading ------------------------------------------------------------------------------------------------------

    public static function state(PDO $pdo, string $zone): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM site_block_zones WHERE zone = ?'); $st->execute([$zone]);
        $z = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        $live = null; $v = (int) ($z['live_version'] ?? 0);
        if ($v) { $st = $pdo->prepare('SELECT tree FROM site_block_versions WHERE zone = ? AND version = ?'); $st->execute([$zone, $v]); $live = json_decode((string) $st->fetchColumn(), true); }
        $draft = $z && $z['draft'] !== null ? json_decode((string) $z['draft'], true) : null;
        return ['zone' => $zone, 'live' => is_array($live) ? self::clean($live) : null, 'live_version' => $v,
                'draft' => is_array($draft) ? self::clean($draft) : null, 'draft_by' => (string) ($z['draft_name'] ?? ''), 'draft_at' => $z['draft_at'] ?? null, 'draft_tz' => (string) ($z['draft_tz'] ?? '')];
    }

    public static function versions(PDO $pdo, string $zone, int $limit = 30): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT version, by_name, at, tz, note FROM site_block_versions WHERE zone = ? ORDER BY version DESC LIMIT ' . max(1, min(100, $limit)));
        $st->execute([$zone]);
        return array_map(fn ($r) => ['version' => (int) $r['version'], 'by' => (string) $r['by_name'], 'at' => gmdate('c', (int) strtotime($r['at'] . ' UTC')), 'tz' => (string) $r['tz'], 'note' => (string) $r['note']],
            $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /**
     * A zone on a page. Everyone sees the live version (or the page's own content, $fallback, until one is published).
     * An editor sees the draft when there is one (the preview, marked Draft), with the zone outlined and its Edit button.
     */
    public static function zone(PDO $pdo, string $zone, string $fallback = '', string $label = ''): string
    {
        if (!self::zoneOk($zone)) return $fallback;
        try { $s = self::state($pdo, $zone); } catch (Throwable $e) { error_log('blocks ' . $zone . ': ' . $e->getMessage()); return $fallback; }
        if (!self::$db) self::useDb($pdo);
        [$edit] = self::can('pages.edit');
        $tree = $edit && $s['draft'] !== null ? $s['draft'] : $s['live'];
        $html = $tree !== null ? self::render($tree, $edit) : $fallback;
        if (!$edit) return $html === '' ? '' : self::kit() . '<div class="tvb-zone" data-tvb="' . htmlspecialchars($zone) . '">' . $html . '</div>';
        $e = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES, 'UTF-8');
        $tag = $s['draft'] !== null ? 'Draft: only our team sees this' : ($s['live_version'] ? 'Live, version ' . $s['live_version'] : 'Not published yet');
        $js = '';
        static $once = false;
        if (!$once) { $once = true; $js = '<script src="/js/tv-editor.js?v=' . (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-editor.js') . '" defer></script>'; }
        return self::kit() . '<div class="tvb-zone tvb-edit" data-tvb-zone="' . $e($zone) . '" data-tvb-label="' . $e($label !== '' ? $label : $zone) . '" data-csrf="' . $e($_SESSION['csrf_token'] ?? '') . '">'
            . '<div class="tvb-tag"><span>' . $e($tag) . '</span><button type="button" data-tvb-edit>Edit</button></div>'
            . ($html !== '' ? $html : '<p class="tvb-empty">' . ($s['draft'] === null && $s['live_version']
                ? 'Version ' . (int) $s['live_version'] . ' is live and has nothing in it, so visitors see nothing here. Edit to add to it, or Edit → ▾ → Versions to roll back to an earlier one.'
                : $e($label !== '' ? $label : 'This space') . ' is empty: Edit to add a section. Visitors see nothing here until it\'s published.') . '</p>')
            . '</div>' . $js;
    }

    // ---- changing -----------------------------------------------------------------------------------------------------

    private static function touch(PDO $pdo, string $zone): void
    {
        $pdo->prepare('INSERT IGNORE INTO site_block_zones (zone, updated_at) VALUES (?, UTC_TIMESTAMP())')->execute([$zone]);
    }

    /** Save draft: kept for the team only, on the real page. */
    public static function saveDraft(PDO $pdo, string $zone, $tree, int $uid, string $name, string $tz): string
    {
        self::need('pages.edit');
        if (!self::zoneOk($zone)) throw new RuntimeException('That isn\'t a place for blocks.');
        self::ensure($pdo); self::touch($pdo, $zone);
        $pdo->prepare('UPDATE site_block_zones SET draft = ?, draft_by = ?, draft_name = ?, draft_at = UTC_TIMESTAMP(), draft_tz = ?, updated_at = UTC_TIMESTAMP() WHERE zone = ?')
            ->execute([json_encode(self::clean($tree), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $uid ?: null, mb_substr($name, 0, 100), mb_substr($tz, 0, 64), $zone]);
        return 'Draft saved: only our team sees it, here on the page. Publish puts it live.';
    }

    /** Publish: the draft (or the tree sent) becomes the next version and goes live; the draft is cleared. */
    public static function publish(PDO $pdo, string $zone, $tree, int $uid, string $name, string $tz, string $note = ''): string
    {
        self::need('pages.publish');
        if (!self::zoneOk($zone)) throw new RuntimeException('That isn\'t a place for blocks.');
        self::ensure($pdo);
        $s = self::state($pdo, $zone);
        $t = $tree !== null ? self::clean($tree) : $s['draft'];
        if ($t === null) throw new RuntimeException('Nothing to publish: make a change first.');
        return 'Published: version ' . self::newVersion($pdo, $zone, $t, $uid, $name, $tz, $note) . ' is live.';
    }

    private static function newVersion(PDO $pdo, string $zone, array $tree, int $uid, string $name, string $tz, string $note): int
    {
        self::touch($pdo, $zone);
        $pdo->beginTransaction();
        try {
            $st = $pdo->prepare('SELECT COALESCE(MAX(version), 0) + 1 FROM site_block_versions WHERE zone = ? FOR UPDATE'); $st->execute([$zone]);
            $v = (int) $st->fetchColumn();
            $pdo->prepare('INSERT INTO site_block_versions (zone, version, tree, by_user, by_name, at, tz, note) VALUES (?, ?, ?, ?, ?, UTC_TIMESTAMP(), ?, ?)')
                ->execute([$zone, $v, json_encode($tree, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $uid ?: null, mb_substr($name, 0, 100), mb_substr($tz, 0, 64), mb_substr($note, 0, 200)]);
            $pdo->prepare('UPDATE site_block_zones SET live_version = ?, draft = NULL, draft_by = NULL, draft_name = \'\', draft_at = NULL, updated_at = UTC_TIMESTAMP() WHERE zone = ?')->execute([$v, $zone]);
            $pdo->commit();
        } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        return $v;
    }

    /** Roll back: an earlier version published again, as the next version (the history only grows). */
    public static function rollBack(PDO $pdo, string $zone, int $version, int $uid, string $name, string $tz): string
    {
        self::need('pages.publish');
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT tree FROM site_block_versions WHERE zone = ? AND version = ?'); $st->execute([$zone, $version]);
        $t = json_decode((string) $st->fetchColumn(), true);
        if (!is_array($t)) throw new RuntimeException('That version isn\'t here.');
        $v = self::newVersion($pdo, $zone, self::clean($t), $uid, $name, $tz, 'Rolled back to version ' . $version);
        return 'Rolled back: version ' . $version . ' is live again (as version ' . $v . ').';
    }

    /** Throw the draft away: the page shows what's live again. */
    public static function discard(PDO $pdo, string $zone): string
    {
        self::need('pages.edit');
        self::ensure($pdo);
        $pdo->prepare('UPDATE site_block_zones SET draft = NULL, draft_by = NULL, draft_name = \'\', draft_at = NULL, updated_at = UTC_TIMESTAMP() WHERE zone = ?')->execute([$zone]);
        return 'Draft thrown away: the page shows what\'s live.';
    }
}
