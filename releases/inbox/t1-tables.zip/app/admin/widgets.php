<?php
// app/admin/widgets.php — the widget library's server side (decisions/0109 A3). Each widget is drawn here as a container
// with its config; js/admin-kit.js brings it to life (fetching from /admin/api/<module>/<tool>, filtering, opening items
// in the drawer, moving them through their workflow). Widgets know nothing about the section they're in.
declare(strict_types=1);

require_once __DIR__ . '/AdminModules.php';
require_once __DIR__ . '/Workflow.php';

function tv_w_e(string $s): string { return htmlspecialchars($s, ENT_QUOTES); }

/** A quick task's fields for the page: a select's choices from {key: name} or {key: [name, what it is]} to
 *  [key, name(, what it is)] (the list's ⓘ, js/admin-kit.js). */
function tv_w_fields(array $fields): array
{
    return array_map(fn ($f) => isset($f[3]) && is_array($f[3]) ? [$f[0], $f[1], $f[2], array_map(fn ($k, $v) => is_array($v) ? [(string) $k, (string) $v[0], (string) ($v[1] ?? '')] : [(string) $k, $v], array_keys($f[3]), $f[3]), $f[4] ?? null] : $f, $fields);
}

/** Table or Pipeline: a list from a tool, with its search, Shortcuts-style filters and (Pipeline) the stage filter. */
function tv_w_table(PDO $pdo, string $tool, bool $pipeline): string
{
    $t = Modules::tool($tool);
    if (!$t) return '';
    [$ok, $why] = Modules::canTool($tool);
    if (!$ok) return '<div class="ak-card ak-off" title="' . tv_w_e($why) . '">' . tv_w_e($t['title']) . ': ' . tv_w_e($why) . '</div>';
    $stages = [];
    if (!empty($t['workflow']) && Workflow::ready($pdo)) {
        foreach (Workflow::def($pdo, $t['workflow'])['stages'] as $s) $stages[] = ['key' => $s['key'], 'label' => $s['label'], 'end' => ($s['kind'] ?? '') === 'end', 'color' => $s['color'] ?? ''];
    }
    // filter and select options go as [key, label] pairs, so keys like "7" keep their order in the browser
    $cfg = ['tool' => $tool, 'title' => $t['title'], 'columns' => $t['columns'], 'filters' => array_map(fn ($f) => [$f[0], $f[1], array_map(fn ($k, $v) => [(string) $k, $v], array_keys($f[2]), $f[2])], (is_callable($t['filters'] ?? null) ? ($t['filters'])($pdo) : ($t['filters'] ?? []))),
            'stages' => $stages, 'pipeline' => $pipeline && $stages, 'countBy' => (string) ($t['count_by'] ?? ''),
            'open' => $t['open'] ?? 'detail', 'create' => isset($t['create']) ? ['label' => $t['create']['label'], 'page' => $t['create']['page'] ?? '', 'fields' => tv_w_fields(is_callable($t['create']['fields'] ?? null) ? ($t['create']['fields'])($pdo) : ($t['create']['fields'] ?? [])),
            'allowed' => Access::can($tool . '.create', $t['create']['rule'] ?? ['min' => 'staff', 'depts' => []])] : null];
    require_once __DIR__ . '/kit-table.php';
    return tv_table($cfg);   // the one table (design/table-standard.md); its markup lives there
}

/** MetricCards: a row of numbers; tapping one filters the list below it (its stage). */
function tv_w_metrics(PDO $pdo, string $tool): string
{
    $t = Modules::tool($tool);
    if (!$t || empty($t['metrics']) || !Modules::canTool($tool)[0]) return '';
    $h = '<div class="ak-metrics">';
    foreach (($t['metrics'])($pdo) as [$label, $value, $filter]) {
        $h .= '<button type="button" class="ak-metric tv-bleed"' . ($filter !== '' ? ' data-ak-stage="' . tv_w_e($tool . '|' . $filter) . '"' : ' disabled') . '><b>' . tv_w_e((string) $value) . '</b><span>' . tv_w_e($label) . '</span></button>';
    }
    return $h . '</div>';
}

/** A bridge: one of today's tool pages shown inside the section until it's rebuilt from widgets. */
function tv_w_bridge(string $url): string
{
    $u = $url . (str_contains($url, '?') ? '&' : '?') . 'embed=1';
    return '<div class="ak-bridge"><iframe class="ak-frame" src="' . tv_w_e($u) . '" title="Tool" loading="lazy" data-ak-frame data-host data-no-back></iframe>'
        . '<p class="ak-note"><a href="' . tv_w_e($url) . '" data-ak-full>Open it on its own page</a></p></div>';
}

/**
 * An item's own page inside its module (/admin/backoffice/orders/9): the page in a frame that fits its height. A
 * #part of the address (from the Pulse: #item=31:proofs) goes on to the page, and when the page moves to another item
 * (a new order saved) the address above follows it.
 */
function tv_w_item(string $url, string $base): string
{
    $u = $url . (str_contains($url, '?') ? '&' : '?') . 'embed=1';
    // the frame fills the window below the module's header and scrolls itself (not stretched to the page's length), so
    // the page's pop-ups (Name the project, + Add item) open in the middle of what you're looking at
    return '<div class="ak-bridge"><iframe class="ak-frame" id="ak-item" src="' . tv_w_e($u) . '" title="Order" style="display:block;width:100%;border:0;height:75vh;background:transparent"></iframe></div>'
        . '<script>(function () { var f = document.getElementById("ak-item"), base = ' . json_encode($base) . ';'
        . ' if (location.hash) f.src = f.src.split("#")[0] + location.hash;'
        // wide: the rest of the window below the header; a phone: one whole screen, brought into view after the first tap inside (the tap itself still lands)
        . ' var fit = function () { var t = f.getBoundingClientRect().top + window.scrollY; f.style.height = (window.innerWidth < 768 ? window.innerHeight : Math.max(420, window.innerHeight - t - 8)) + "px"; };'
        . ' fit(); window.addEventListener("resize", fit); window.addEventListener("load", fit);'
        . ' f.addEventListener("load", function () { fit(); try { f.contentDocument.addEventListener("click", function () { setTimeout(function () { var t = f.getBoundingClientRect().top; if (window.innerWidth < 768 && Math.abs(t) > 4) window.scrollBy(0, t); }, 0); }, true); } catch (e) {} });'
        . ' f.addEventListener("load", function () { try { var m = /[?&]id=(\\d+)/.exec(f.contentWindow.location.search); if (m && location.pathname !== base + "/" + m[1]) history.replaceState(null, "", base + "/" + m[1]); } catch (e) {} });'
        . ' })();</script>';
}

/** The landing page of a section that's coming (greyed in the menu; Jason, 2026-10-22). */
function tv_w_landing(array $m, array $s): string
{
    $h = '<div class="ak-landing tv-bleed"><p class="ak-tag">Coming</p><h2>' . tv_w_e($s['label']) . '</h2><p>' . tv_w_e($s['about'] ?? '') . '</p>';
    $h .= '<p class="ak-note">Part of ' . tv_w_e($m['num'] . '. ' . $m['name']) . '.' . (($s['waits'] ?? '') !== '' ? ' Waiting on: ' . tv_w_e($s['waits']) : '') . '</p>';
    if (!empty($s['meanwhile'])) {
        $h .= '<p class="ak-note"><b>Meanwhile:</b> ';
        foreach ($s['meanwhile'] as $i => [$l, $u]) $h .= ($i ? ' · ' : '') . '<a href="' . tv_w_e($u) . '">' . tv_w_e($l) . '</a>';
        $h .= '</p>';
    }
    return $h . '</div>';
}

/** A section's body: its widgets in order (or its landing page). */
function tv_w_section(PDO $pdo, array $m, string $sk): string
{
    $s = $m['sections'][$sk];
    if ($s['status'] === 'coming') return tv_w_landing($m, $s);
    $h = '';
    // a page a scheduled task serves says when it runs, with Change to its card on Scheduled tasks (Jason, 2026-11-17)
    try { require_once __DIR__ . '/job-line.php'; $h = tv_admin_job_line($pdo, (string) ($m['key'] ?? ''), $sk); } catch (Throwable $e) { error_log('job line: ' . $e->getMessage()); }
    foreach ($s['widgets'] as $w) {
        $h .= match ($w[0]) {
            'pipeline' => tv_w_table($pdo, $w[1], true),
            'table' => tv_w_table($pdo, $w[1], false),
            'metrics' => tv_w_metrics($pdo, $w[1]),
            'bridge' => tv_w_bridge($w[1]),
            'html' => function_exists($w[1]) ? (string) ($w[1])($pdo) : '',
            default => '',
        };
    }
    return $h;
}
