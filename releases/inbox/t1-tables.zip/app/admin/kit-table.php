<?php
/**
 * One table for the admin's lists (design/table-standard.md, Jason 2026-11-19; T1). Draws the section that
 * js/admin-kit.js's List fills: the 2026-11-12 list standard (sortable columns, Columns, Show 10/25/50/100 a page,
 * Show more, the page bar with the range) plus a status column, labeled times, a sub-line, one action and ⋯,
 * group rows and columns with no data yet said once. Paging, sort, filter and the count come from the server.
 *
 * $cfg: tool (an admin tool, /admin/api/<tool>) or src (any endpoint answering {rows, total, counts?, sortable?});
 *   title; columns [[key, label, kind]] (kinds: name, status, when, date, count, money, pill, stage; the first is the
 *   name); sub (a row key shown under the name); act [key, label] (the one visible button); menu [[key, label, svg?]]
 *   (the ⋯ menu; a row's _off[key] = why greys it); filters, stages, create as before (tv_w_table); noData (the words
 *   for an empty column, default "no history yet"). A row may be ['id' => …, '_group' => ['label', 'n', 'status',
 *   'sub', 'rows' => […]]]: one row that opens to its members. Acting dispatches tv-table:act on the section; if the
 *   page doesn't cancel it, the tool's own action runs (POST {action: key, id}).
 */
function tv_table(array $cfg): string
{
    $title = (string) ($cfg['title'] ?? '');
    $cfg += ['tool' => '', 'columns' => [], 'filters' => [], 'stages' => [], 'pipeline' => false, 'countBy' => '', 'open' => 'detail', 'create' => null];
    return '<section class="ak-list" data-ak-table="' . htmlspecialchars(json_encode($cfg, JSON_UNESCAPED_UNICODE), ENT_QUOTES) . '">'
        . '<div class="akt-skel" role="status" aria-label="' . htmlspecialchars('Loading ' . strtolower($title), ENT_QUOTES) . '"><i></i><i></i><i></i></div></section>';
}
