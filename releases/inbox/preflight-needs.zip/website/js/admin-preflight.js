/* js/admin-preflight.js — System Configuration → Pre-flight (decisions/0163 §10's note of 2026-11-16). Run all goes line by
 * line in the page's order, each line's mark a spinner while it runs, then drawn again with its answer, like a log filling
 * in; a line still waiting (W0's test batch, sent at the indexer's next check-in) is asked again shortly. Each line's Test
 * runs it alone; a fix button runs its fix, then tests the line again. Every slow press shows its spinner (TvAsk.busy) and
 * a notice only when a request fails: a line's ✓ or ✗ is its answer (Jason, 2026-11-17). Answers come from /admin/api/config/preflight. */
(function () {
  var box = document.getElementById('pf');
  if (!box) return;
  var csrf = box.getAttribute('data-csrf') || '', running = false;

  function post(body) {
    return fetch('/admin/api/config/preflight', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again.'); return j; });
  }
  function say(msg, el, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: el, bad: !!bad }); }
  /** A line's notice: at the top of its opened body, the full width (never in the header row beside the name). */
  function sayLine(msg, li, bad) {
    var d = li && li.querySelector('details'), b = li && li.querySelector('.pf-b');
    if (d) d.open = true;
    var first = b && b.firstElementChild;
    if (!first) { say(msg, li, bad); return; }
    say(msg, first, bad);
  }
  function busy(el, on) { if (el && window.TvAsk && TvAsk.busy) TvAsk.busy(el, on); }
  function counts(html) { var c = box.querySelector('[data-pf-counts]'); if (c && html) c.innerHTML = html; paint(c); }
  function paint(root) { if (window.TvTime && root) TvTime.paint(root); }
  function groups() {
    box.querySelectorAll('.pf-g').forEach(function (g) {
      var n = { ok: 0, bad: 0, na: 0 };
      g.querySelectorAll('.pf-l').forEach(function (l) { var s = l.getAttribute('data-s'); if (n[s] !== undefined) n[s]++; });
      var marks = g.querySelectorAll('[data-pf-gc] .pf-m'), gc = g.querySelector('[data-pf-gc]');
      if (!gc || marks.length < 3) return;
      gc.innerHTML = marks[0].outerHTML + n.ok + ' ' + marks[1].outerHTML + n.bad + ' ' + marks[2].outerHTML + n.na;
    });
  }

  /** Runs one line: its spinner, then the line drawn again. Resolves with its state. */
  function runLine(li, open) {
    var id = li.getAttribute('data-pf'), wasOpen = li.querySelector('details') && li.querySelector('details').open;
    li.setAttribute('data-busy', '1');
    return post({ action: 'run', id: id }).then(function (j) {
      var t = document.createElement('div'); t.innerHTML = j.html;
      var fresh = t.firstElementChild;
      li.replaceWith(fresh);
      if (open || wasOpen || j.s === 'bad') { var d = fresh.querySelector('details'); if (d && (open || wasOpen)) d.open = true; }
      paint(fresh); live(); groups(); applyRed();   // the page's own counts: it opens fresh, so stored results never mix in
      return { s: j.s, li: fresh };
    }, function (e) { li.removeAttribute('data-busy'); throw e; });
  }

  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  // a run starts fresh (Jason, 2026-11-17: "it needs to refresh the preflight"): every line back to queued, the counts from 0,
  // then each line fills in as its answer comes, like a log, with "Testing 34 of 87: OpenStreetMap" above
  var prog = box.querySelector('[data-pf-prog]'), total = 0;
  function progress(text) { if (!prog) return; prog.hidden = !text; prog.textContent = text || ''; }
  function live() {
    var n = { ok: 0, warn: 0, bad: 0, na: 0, wait: 0, queued: 0, 'new': 0 };
    box.querySelectorAll('.pf-l').forEach(function (l) { var s = l.getAttribute('data-s'); n[s] = (n[s] || 0) + 1; });
    var c = box.querySelector('[data-pf-counts]'), marks = c ? c.querySelectorAll('.pf-m') : [];
    if (c && marks.length >= 3) c.innerHTML = '<span class="pf-c">' + marks[0].outerHTML + n.ok + '</span> · <span class="pf-c">' + marks[1].outerHTML + n.bad + '</span> · <span class="pf-c">' + marks[2].outerHTML + n.na + ' not needed yet</span>' + (n.warn ? ' · ' + n.warn + ' on a backup' : '') + (n.wait ? ' · ' + n.wait + ' waiting' : '') + ' · ' + (n.queued + n['new']) + ' to test';
  }
  function reset() {
    box.querySelectorAll('.pf-l').forEach(function (l) {
      l.setAttribute('data-s', 'queued'); l.removeAttribute('data-slow');
      var m = l.querySelector('.pf-m'); if (m) { m.className = 'pf-m pf-new'; m.title = 'Queued'; var svg = m.querySelector('svg'); if (svg) svg.innerHTML = '<circle cx="12" cy="12" r="2.5"/>'; }
      var sl = l.querySelector('.pf-slow'); if (sl) sl.remove();
      var w = l.querySelector('.pf-w'); if (w) w.textContent = 'queued';
    });
    groups(); live();
  }

  function runAll(btn) {
    if (running) return;
    running = true; busy(btn, true);
    var started = Math.floor(Date.now() / 1000);   // the run's length is kept (start to finish)
    var lis = Array.prototype.slice.call(box.querySelectorAll('.pf-l')), waiting = [], i = 0, bad = 0;
    total = lis.length; redOnly = false; slowOnly = false; applyRed(); reset();
    function next() {
      if (i >= lis.length) return Promise.resolve();
      var li = box.querySelector('[data-pf="' + lis[i++].getAttribute('data-pf') + '"]');
      var nm = li.querySelector('.pf-n'); progress('Testing ' + i + ' of ' + total + ': ' + (nm ? nm.textContent : ''));
      return runLine(li, false).then(function (r) { if (r.s === 'wait') waiting.push(r.li.getAttribute('data-pf')); if (r.s === 'bad') bad++; return next(); },
        function (e) { sayLine(e.message, li, true); return next(); });
    }
    function again(round) {   // lines still waiting (the indexer's test batch): asked again every 20 seconds, five times at most
      if (!waiting.length || round > 5) return Promise.resolve();
      progress('Waiting for ' + waiting.length + ' line' + (waiting.length === 1 ? '' : 's') + ' to answer (W0\'s test batch comes at the indexer\'s next check-in): asked again in 20 s, try ' + round + ' of 5');
      return wait(20000).then(function () {
        var ids = waiting; waiting = [];
        return ids.reduce(function (p, id) { return p.then(function () {
          var li = box.querySelector('[data-pf="' + id + '"]'); if (!li) return;
          return runLine(li, false).then(function (r) { if (r.s === 'wait') waiting.push(id); if (r.s === 'bad') bad++; });
        }); }, Promise.resolve()).then(function () { return again(round + 1); });
      });
    }
    next().then(function () { return again(1); }).then(function () { return post({ action: 'done', start: started }); }).then(function (j) {
      running = false; live(); busy(btn, false); progress('');
      var lg = box.querySelector('[data-pf-runs]'); if (lg && j.log) { lg.innerHTML = j.log; paint(lg); }   // this run, first in the run log, with its report   // the marks and the counts say how it went: no notice
    }).catch(function (e) { busy(btn, false); running = false; progress(''); say(e.message, btn, true); });
  }

  var redOnly = false, slowOnly = false;
  function applyRed() {
    box.querySelectorAll('.pf-l').forEach(function (l) { l.hidden = (redOnly && l.getAttribute('data-s') !== 'bad') || (slowOnly && !l.hasAttribute('data-slow')); });
    box.querySelectorAll('.pf-g').forEach(function (g) { g.hidden = (redOnly || slowOnly) && !g.querySelector('.pf-l:not([hidden])'); });   // a group with nothing to show folds away
    var b = box.querySelector('[data-pf-red]'); if (b) b.textContent = redOnly ? 'Show every line' : 'Show only what\'s red';
    var s = box.querySelector('[data-pf-slow]'); if (s) s.textContent = slowOnly ? 'Show every line' : 'Show the slow ones';
  }
  function openLine(hash) {
    var li = hash && hash.length > 1 ? document.getElementById(hash.slice(1)) : null;
    if (!li || !li.classList.contains('pf-l')) return;
    var g = li.closest('details.pf-g'); if (g) g.open = true;
    var d = li.querySelector('details'); if (d) d.open = true;
    li.hidden = false; li.scrollIntoView({ block: 'center' });
  }

  box.addEventListener('click', function (ev) {
    var b = ev.target.closest('button, a[data-pf-first]');
    if (!b || !box.contains(b)) return;
    if (b.hasAttribute('data-pf-all')) { ev.preventDefault(); runAll(b); return; }
    if (b.hasAttribute('data-pf-red')) { ev.preventDefault(); redOnly = !redOnly; slowOnly = false; applyRed(); return; }
    if (b.hasAttribute('data-pf-slow')) { ev.preventDefault(); slowOnly = !slowOnly; redOnly = false; applyRed(); return; }
    if (b.hasAttribute('data-pf-first')) { ev.preventDefault(); openLine(b.getAttribute('href')); return; }
    if (b.hasAttribute('data-pf-run')) {
      ev.preventDefault(); ev.stopPropagation();   // a button in the summary: test, don't fold
      var li = b.closest('.pf-l'); busy(b, true);
      runLine(li, false).catch(function (e) { busy(b, false); sayLine(e.message, li, true); });   // its ✓ or ✗ is the answer: no notice
      return;
    }
    if (b.hasAttribute('data-pf-fix')) {
      ev.preventDefault();
      var li2 = b.closest('.pf-l'); busy(b, true);
      post({ action: 'fix', fix: b.getAttribute('data-pf-fix') }).then(function (j) {
        busy(b, false);
        return runLine(li2, true);   // what the fix did shows as the line's new mark and answer
      }).catch(function (e) { busy(b, false); say(e.message, b.closest('.pf-fx') || b, true); });
    }
  });
  window.addEventListener('hashchange', function () { openLine(location.hash); });
  openLine(location.hash);
})();
