<?php
// app/scripts/guide_live_tick.php — Guide weather and roads (decisions/0131 §5): renews the weather of every guide's
// place before it runs out, and Arizona's road work feeds, so a guide page reads them ready-made and never waits on the
// weather service or AZ 511. Sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('guide_live_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Guides.php';
require_once __DIR__ . '/../lib/Weather.php';
require_once __DIR__ . '/../lib/Roads511.php';
$pdo = Database::connection();
try { $n = Roads511::warm($pdo); }   // a feed that can't be read never stops the weather (2026-11-13)
catch (Throwable $e) { $n = 'not read (' . mb_substr($e->getMessage(), 0, 120) . ')'; error_log('guide_live_tick roads: ' . $e->getMessage()); }
$pts = [];
foreach (Guides::tree($pdo) as [$key]) {
    if (str_starts_with($key, 'hub:')) continue;   // a region has no point of its own: its towns' do
    $p = Guides::place($pdo, $key);
    if ($p && $p['lat'] !== null) $pts[round((float) $p['lat'], 3) . ',' . round((float) $p['lon'], 3)] = [$p['lat'], $p['lon']];
}
[$ok, $bad] = Weather::warm($pdo, array_values($pts), 1200, 240);
echo 'Roads: ' . $n . ' work zones. Weather: ' . $ok . ' renewed' . ($bad ? ', ' . $bad . ' failed (the last good forecast still shows)' : '') . ' of ' . count($pts) . " places.\n";
