<?php
// app/admin/operations-console.php — System Configuration → Service register, Costs, and Workflow board (decisions/0163
// §1–§5, §10; Release A). The register: every outside service, what uses it, where its key lives (named, never shown),
// its caps and paces (the one setting the code reads, with who and when, history and Reset), this month's use and cost,
// and its status with the reason; watching Railway and the sync (shipped off). Costs: this month by service and by
// workflow, against revenue and the community budget, with the AI cap's shares. The board: each workflow's switch, last
// run, output, cost, and its settings (tasks, shares, routes, budgets, gates, weights, retry ladder, person steps) saved
// as versions with "Go back to it"; the switch-on check. It shows and records: nothing here switches anything on.
declare(strict_types=1);

/** Who's acting and the posted form, shared by the three sections. [can, why, uid, who, csrf, tz, flash]. */
function tv_ops_ctx(PDO $pdo): array
{
    require_once __DIR__ . '/../lib/Operations.php';
    require_once __DIR__ . '/../lib/WorkflowSettings.php';
    [$can, $why] = Operations::can();
    $me = Access::staff(); $uid = (int) (Auth::currentUserId() ?? 0);
    $who = trim((string) ($me['name'] ?? ''));
    if ($who === '' && $uid) { try { $st = $pdo->prepare('SELECT display_name FROM users WHERE id = ?'); $st->execute([$uid]); $who = (string) ($st->fetchColumn() ?: ''); } catch (Throwable $x) {} }
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $tz = mb_substr(preg_replace('/[^A-Za-z0-9_\/+-]/', '', (string) ($_POST['tz'] ?? '')), 0, 64);
    $flash = '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['op_do']) && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        try {
            if (!$can) throw new RuntimeException($why);
            $do = (string) $_POST['op_do']; $ref = (string) ($_POST['ref'] ?? '');
            switch ($do) {
                case 'cap_set':
                    if (!in_array($ref, array_merge(...array_values(Operations::CAPS)), true)) throw new RuntimeException('That isn\'t one of the register\'s caps.');
                    $v = Thresholds::set($pdo, $ref, (string) ($_POST['value'] ?? ''), $uid);
                    $say = Thresholds::GATES[$ref][0] . ': ' . Operations::num($v) . ' ' . Thresholds::GATES[$ref][6] . '.'; break;
                case 'cap_reset':
                    if (!in_array($ref, array_merge(...array_values(Operations::CAPS)), true)) throw new RuntimeException('That isn\'t one of the register\'s caps.');
                    Thresholds::reset($pdo, $ref, $uid); $say = Thresholds::GATES[$ref][0] . ': back to its default.'; break;
                case 'watch_on': Operations::setWatching($pdo, true, $uid); $say = 'Watching is on: the hourly job looks at Railway and the sync.'; break;
                case 'watch_off': Operations::setWatching($pdo, false, $uid); $say = 'Watching is off: nothing calls Railway or GitHub from here.'; break;
                case 'wf_save':
                    if (!isset(Automation::WORKFLOWS[$ref])) throw new RuntimeException('No such workflow.');
                    [$n, $ch, $red] = WorkflowSettings::save($pdo, $ref, WorkflowSettings::fromForm($pdo, $ref, $_POST), $uid, (string) ($_POST['note'] ?? ''), $tz);
                    $say = $ref . ' saved as version ' . $n . ' (' . count($ch) . ' change' . (count($ch) === 1 ? '' : 's') . ').' . ($red ? ' The switch-on check has ' . $red . ' red line' . ($red === 1 ? '' : 's') . ' for it, so it stays paused until they\'re green.' : ''); break;
                case 'wf_back':
                    if (!isset(Automation::WORKFLOWS[$ref])) throw new RuntimeException('No such workflow.');
                    [$n] = WorkflowSettings::restore($pdo, $ref, (int) ($_POST['version'] ?? 0), $uid, $tz);
                    $say = $ref . ' is back to version ' . (int) $_POST['version'] . ', saved as version ' . $n . '.'; break;
                default: throw new RuntimeException('Unknown action.');
            }
            $flash = '<p data-tv-flash="ok">' . tv_w_e($say) . '</p>';
        } catch (Throwable $x) {
            $known = $x instanceof RuntimeException || $x instanceof InvalidArgumentException;
            if (!$known) error_log('operations: ' . $x->getMessage());
            $flash = '<p data-tv-flash="error">' . tv_w_e($known ? $x->getMessage() : 'That didn\'t work: try again.') . '</p>';
        }
    }
    return [$can, $why, $uid, $who, $csrf, $tz, $flash];
}

/** A small form: op_do, hidden fields, a button that waits for a yes when $confirm is set. */
function tv_ops_form(string $csrf, string $do, string $label, array $hidden = [], string $confirm = '', string $extra = '', bool $can = true, string $why = '', string $cls = 'ak-b'): string
{
    $h = '<form method="post" style="display:inline-flex;gap:.3rem;align-items:center;flex-wrap:wrap;margin:0"><input type="hidden" name="csrf" value="' . tv_w_e($csrf) . '"><input type="hidden" name="op_do" value="' . tv_w_e($do) . '"><input type="hidden" name="tz" value="" data-tz>';
    foreach ($hidden as $k => $v) $h .= '<input type="hidden" name="' . tv_w_e($k) . '" value="' . tv_w_e((string) $v) . '">';
    return $h . $extra . '<button class="' . $cls . '" type="submit"' . ($confirm !== '' ? ' data-confirm="' . tv_w_e($confirm) . '" data-yes="' . tv_w_e($label) . '"' : '') . (!$can ? ' disabled title="' . tv_w_e($why) . '"' : '') . '>' . tv_w_e($label) . '</button></form>';
}

/** The device's time zone into each form (decisions: times where they happened). */
function tv_ops_tz_js(): string
{
    return '<script>(function(){var z="";try{z=Intl.DateTimeFormat().resolvedOptions().timeZone||""}catch(e){}document.querySelectorAll("input[data-tz]").forEach(function(i){i.value=z})})();</script>';
}

const TV_OPS_TONE = ['active' => 'ok', 'paced' => 'info', 'held' => 'bad', 'off' => 'info', 'out' => 'bad'];

/** System Configuration → Service register. */
function tv_admin_mod_register(PDO $pdo): string
{
    [$can, $why, $uid, $who, $csrf, $tz, $flash] = tv_ops_ctx($pdo);
    $e = 'tv_w_e';
    Operations::seed($pdo);   // today's values, recorded once (nothing retyped)
    $reg = Operations::register($pdo);
    $h = $flash . '<p class="ak-note">Every outside service we call, in one place (decisions/0163 §1): what uses it, where its key lives (named, never shown), its caps and paces, this month\'s use and cost by our count, and its status with the reason. A cap set here is the one setting the code reads: the old copies in .env and on Railway were read once to start it, and are retired. ' . ($can ? '' : '<b>' . $e($why) . '</b>') . '</p>';
    // the summary
    $by = []; foreach ($reg as $r) $by[$r['status'][0]] = ($by[$r['status'][0]] ?? 0) + 1;
    $h .= '<div class="ak-metrics">';
    foreach (Operations::STATUSES as $k => $label) $h .= '<div class="ak-metric"><b>' . (int) ($by[$k] ?? 0) . '</b><span>' . $e($label) . '</span></div>';
    $h .= '</div>';
    // watching (§5)
    $w = Operations::watching($pdo); $seen = Operations::watched($pdo);
    $wb = '<p class="ak-note">The site looks at Railway\'s latest deploy and the sync\'s runs itself, every hour, and raises a Pulse case when one fails or stalls, so it no longer depends on a Claude session. Free status reads only. Shipped off: it needs its keys in .env first (File Manager), never shown here.</p><table class="ak-aa"><thead><tr><th>What</th><th>Its key</th><th>Where it looks</th><th>Last look</th></tr></thead><tbody>';
    foreach (Operations::WATCH as $k => [$name, $key, $where]) {
        $s = $seen[$k] ?? null; $has = getenv($key) !== false && getenv($key) !== '';
        $wb .= '<tr><td><b>' . $e($name) . '</b></td><td><code>' . $e($key) . '</code> ' . ($has ? '<span data-tv-status="ok">in .env</span>' : '<span data-tv-status="info">not in .env yet</span>') . '</td><td><small>' . $e($where) . '</small></td><td>'
            . ($s ? '<span data-tv-status="' . (($s['ok'] ?? null) === true ? 'ok' : (($s['ok'] ?? null) === false ? 'bad' : 'info')) . '">' . $e((string) $s['what']) . '</span> <time datetime="' . $e(str_replace(' ', 'T', (string) $s['at']) . ':00Z') . '" data-tv-time data-tz="UTC">' . $e((string) $s['at']) . ' UTC</time>' : '<small>Never looked</small>') . '</td></tr>';
    }
    $wb .= '</tbody></table>' . (!empty($w['on']) ? tv_ops_form($csrf, 'watch_off', 'Switch watching off', [], 'Stop watching Railway and the sync? Their Pulse cases stop too.', '', $can, $why)
        : tv_ops_form($csrf, 'watch_on', 'Switch watching on', [], 'Start watching Railway and the sync? The hourly job reads their status (free); nothing else changes.', '', $can, $why, 'ak-b go'));
    $h .= '<div id="watch">' . tv_admin_fold('Watching Railway and the sync', !empty($w['on']) ? 'On' : 'Off (shipped off)', !empty($w['on']) ? 'ok' : 'info', '', $wb, false) . '</div>';
    // a fold per service: the ones with caps or use first
    uasort($reg, fn ($a, $b) => [!($a['caps'] || $a['use']), $a['name']] <=> [!($b['caps'] || $b['use']), $b['name']]);
    foreach ($reg as $k => $r) {
        [$st, $sw] = $r['status'];
        $b = '<p class="ak-note">' . $e($r['what']) . '</p><p data-tv-status="' . (TV_OPS_TONE[$st] ?? 'info') . '" data-tv-label="' . $e(Operations::STATUSES[$st] . ':') . '">' . $e($sw) . '</p>';
        $b .= '<dl class="ak-note" style="display:grid;grid-template-columns:max-content 1fr;gap:.2rem .7rem;margin:.4rem 0">'
            . '<dt>Used by</dt><dd>' . ($r['workflows'] ? $e(implode(', ', array_map(fn ($wf) => $wf . ' ' . (Automation::WORKFLOWS[$wf][0] ?? ''), $r['workflows']))) : 'No workflow: people\'s own presses and business operations') . ($r['tasks'] ? '<br><small>Tasks: ' . $e(implode(', ', $r['tasks'])) . '</small>' : '') . ($r['jobs'] ? '<br><small>Jobs: ' . $e(implode(', ', $r['jobs'])) . '</small>' : '') . '</dd>'
            . '<dt>Its key</dt><dd>' . ($r['keys'] ? implode('<br>', array_map(fn ($x) => '<code>' . $e($x[0]) . '</code> in ' . $e($x[1]) . ': ' . ($x[2] === null ? 'can\'t be read from the site' : ($x[2] ? 'present' : 'not set')), $r['keys'])) : 'None needed') . '</dd>'
            . '<dt>Known price</dt><dd>' . $e($r['price']) . '</dd>'
            . '<dt>This month</dt><dd>' . ($r['use'] ? implode('<br>', array_map(fn ($u) => $e($u['what']) . ': ' . ($u['money'] ? '$' . number_format($u['used'], 2) . ($u['cap'] > 0 ? ' of $' . number_format($u['cap'], 2) : '') : number_format($u['used']) . ($u['cap'] > 0 ? ' of ' . number_format($u['cap']) : '') . ' ' . $e($u['unit'])) . ($u['cap'] > 0 ? ' (' . (int) $u['pct'] . '%)' : ''), $r['use'])) : 'Nothing counted') . ($r['cost'] > 0 ? '<br>Cost about $' . number_format($r['cost'], 2) : '') . '<br><small>' . $e($r['provider']) . '</small></dd>'
            . ($r['produced'] !== '' ? '<dt>Produced</dt><dd>' . $e($r['produced']) . '</dd>' : '')
            . '</dl>';
        if ($r['caps']) {
            $b .= '<h4 class="ak-h">Caps and paces</h4><table class="ak-aa"><thead><tr><th>Setting</th><th>Now</th><th>Set it</th><th>History</th></tr></thead><tbody>';
            foreach ($r['caps'] as $c) {
                $hist = Thresholds::history($pdo, $c['gate'], 6);
                $b .= '<tr id="cap-' . $e($c['gate']) . '"><td><b>' . $e($c['label']) . '</b><br><small>' . $e($c['where']) . '</small></td><td>' . $e(Operations::num($c['value']) . ' ' . $c['unit']) . '<br><small>' . $e($c['how']) . ($c['at'] !== '' ? ', ' . $c['at'] . ' (server time)' : '') . '</small></td><td>'
                    . tv_ops_form($csrf, 'cap_set', 'Set', ['ref' => $c['gate']], '', '<input class="ak-in" style="width:7rem" type="text" inputmode="decimal" name="value" value="' . $e((string) $c['value']) . '" aria-label="' . $e($c['label']) . '" title="Between ' . $e((string) $c['min']) . ' and ' . $e((string) $c['max']) . '">', $can, $why)
                    . ' ' . tv_ops_form($csrf, 'cap_reset', 'Reset', ['ref' => $c['gate']], 'Back to its default (' . Operations::num(Thresholds::GATES[$c['gate']][2]) . ')?', '', $can, $why) . '</td><td><small>'
                    . ($hist ? implode('<br>', array_map(fn ($x) => $e(($x['old_v'] ?? '–') . ' → ' . $x['new_v'] . ', ' . $x['at'] . ($x['note'] !== '' ? ' (' . $x['note'] . ')' : '')), $hist)) : 'No changes yet') . '</small></td></tr>';
            }
            $b .= '</tbody></table>';
        }
        $h .= '<div id="svc-' . $e($k) . '">' . tv_admin_fold($r['name'], Operations::STATUSES[$st] . ($r['cost'] > 0 ? ' · $' . number_format($r['cost'], 2) . ' this month' : ''), TV_OPS_TONE[$st] ?? 'info', '', $b, false) . '</div>';
    }
    return $h . tv_ops_tz_js();
}

/** System Configuration → Costs. */
function tv_admin_mod_costs(PDO $pdo): string
{
    [$can, $why] = tv_ops_ctx($pdo);
    $e = 'tv_w_e';
    $c = Operations::costs($pdo); $cm = $c['community'];
    $usd = fn ($v) => '$' . number_format((float) $v, 2);
    $h = '<p class="ak-note">This month\'s spend in one place (decisions/0163 §2): the crawler\'s ledger, Claude\'s (ai_jobs), email\'s and the monthly plans, by service and by workflow, set against revenue and the community budget, so "no income, no expense" is checked by the system. Our counts; failed calls included.</p>';
    $h .= '<div class="ak-metrics"><div class="ak-metric"><b>' . $usd($c['total']) . '</b><span>Spent this month</span></div><div class="ak-metric"><b>' . $usd($c['revenue']) . '</b><span>Revenue last month</span></div>'
        . '<div class="ak-metric"><b>' . $usd($cm['spent']) . ' of ' . $usd($cm['budget']) . '</b><span>Community budget (' . (int) $cm['pct'] . '%)</span></div></div>';
    $h .= $c['covered'] ? '<p data-tv-status="ok" data-tv-label="Covered:">This month\'s spend so far is within last month\'s revenue.</p>'
        : '<p data-tv-status="bad" data-tv-label="Not covered:">This month\'s spend (' . $usd($c['total']) . ') is past last month\'s revenue (' . $usd($c['revenue']) . '). Nothing new should spend until revenue covers it (no income, no expense); the AI cap and the services\' caps are in the <a class="underline" href="/admin/config/register">Service register</a>.</p>';
    $rows = '';
    foreach ($c['services'] as $k => $v) $rows .= '<tr><td>' . $e(OutsideServices::COMPANIES[$k][0] ?? $k) . '</td><td>' . $usd($v) . '</td></tr>';
    $h .= tv_admin_fold('By service', count($c['services']) . ' with spend', 'info', '', $rows ? '<table class="ak-aa"><thead><tr><th>Service</th><th>This month</th></tr></thead><tbody>' . $rows . '</tbody></table>' : '<p class="ak-note">Nothing spent this month.</p>', true);
    $rows = '';
    ksort($c['workflows'], SORT_NATURAL);
    foreach ($c['workflows'] as $wf => $bySvc) $rows .= '<tr><td><b>' . $e($wf) . '</b> ' . $e(Automation::WORKFLOWS[$wf][0] ?? ($wf === 'run' ? 'The crawler\'s runs' : ($wf === 'email' ? 'Email' : 'Not a workflow\'s'))) . '</td><td>' . $e(implode(' · ', array_map(fn ($s, $v) => (OutsideServices::COMPANIES[$s][0] ?? $s) . ' $' . number_format($v, 2), array_keys($bySvc), $bySvc))) . '</td><td>' . $usd(array_sum($bySvc)) . '</td></tr>';
    $h .= tv_admin_fold('By workflow', count($c['workflows']) . ' with spend', 'info', '', $rows ? '<table class="ak-aa"><thead><tr><th>Workflow</th><th>Services</th><th>This month</th></tr></thead><tbody>' . $rows . '</tbody></table>' : '<p class="ak-note">Nothing spent this month.</p>', false);
    $rows = '';
    foreach ($c['ai_shares'] as $wf => $a) $rows .= '<tr><td><b>' . $e($wf) . '</b> ' . $e(Automation::WORKFLOWS[$wf][0] ?? '') . '</td><td>' . (int) $a['share_pct'] . '% (' . $usd($a['cap_usd']) . ')</td><td>' . $usd($a['spent']) . '</td><td><span data-tv-status="' . ($a['pct'] >= 95 ? 'bad' : ($a['pct'] >= 50 ? 'info' : 'ok')) . '">' . (int) $a['pct'] . '%</span></td></tr>';
    $h .= tv_admin_fold('The AI cap\'s shares', $c['ai_shares'] ? count($c['ai_shares']) . ' set' : 'None set', 'info', '', '<p class="ak-note">The monthly AI cap split into a share per workflow (decisions/0163 §7, X4), set on the <a class="underline" href="/admin/config/board">Workflow board</a>. The 50/75/95% warnings apply to each share; a share unused at the month\'s end passes on to the next month\'s pool once the engine reads the shares (Release B). W5\'s half of the daily allowance stays its own rule.</p>'
        . ($rows ? '<table class="ak-aa"><thead><tr><th>Workflow</th><th>Its share</th><th>Spent</th><th>Used</th></tr></thead><tbody>' . $rows . '</tbody></table>' : ''), false);
    $h .= tv_admin_fold('A hub\'s opening budget', 'None set', 'info', '', '<p class="ak-note">A one-time allowance per hub, separate from upkeep (0164 R17), set when the hub is Planned. None is set yet; the switch-on check names it for a hub that opens.</p>', false);
    return $h;
}

/** System Configuration → Workflow board (and the task schedule, the switch-on check). */
function tv_admin_mod_board(PDO $pdo): string
{
    [$can, $why, $uid, $who, $csrf, $tz, $flash] = tv_ops_ctx($pdo);
    $e = 'tv_w_e';
    require_once __DIR__ . '/../lib/crawler/CrawlService.php';
    $crawl = CrawlService::ready($pdo);
    $tasks = $crawl ? CrawlService::tasks($pdo) : []; $stats = $crawl ? CrawlService::taskStats($pdo, 24) : [];
    $spend = Operations::costs($pdo)['workflows'];
    $empty = Operations::empties($pdo);
    $routeChoices = array_keys(array_filter(OutsideServices::CONTROLS, fn ($c) => !empty($c['tasks'])));   // the services a crawler task can be routed to
    $h = $flash . '<p class="ak-note">Each workflow, W1 to W13 (W14 from when it\'s built): its switch, its last run and output, its cost this month, and its settings. Every setting is edited here, never only in code; each save is a version (who, when, what changed) with "Go back to it", and the switch-on check\'s red lines keep it paused until they\'re green (decisions/0163 §3, §10). Switches stay on the <a class="underline" href="/admin/config/automation">Automation</a> page. ' . ($can ? '' : '<b>' . $e($why) . '</b>') . '</p>';
    // Start the system (Jason, 2026-11-15), the same card as on the Automation page; its buttons post there
    require_once __DIR__ . '/../lib/SystemStart.php';
    [$canStart, $whyStart] = SystemStart::can();
    $h .= SystemStart::panel($pdo, $csrf, $canStart, (string) $whyStart, '/admin/config/automation');
    // the switch-on check
    $chk = Operations::switchOnCheck($pdo); $red = array_filter($chk, fn ($l) => !$l['ok']);
    $cb = '<ul style="list-style:none;padding:0;margin:0;display:grid;gap:.35rem">';
    foreach ($chk as $l) $cb .= '<li><p data-tv-status="' . ($l['ok'] ? 'ok' : 'bad') . '" data-tv-label="' . $e($l['line'] . ':') . '" style="margin:0">' . $e($l['why']) . ($l['fix'] ? ' <a class="underline" href="' . $e($l['fix'][1]) . '">' . $e($l['fix'][0]) . '</a>' : '') . ($l['stage'] !== '' ? ' <small>(' . $e($l['stage']) . ')</small>' : '') . '</p></li>';
    $cb .= '</ul>';
    $h .= '<div id="check">' . tv_admin_fold('Check before switching on', $red ? count($red) . ' of ' . count($chk) . ' red: the master switch stays off' : 'All green', $red ? 'bad' : 'ok', '', '<p class="ak-note">Run each time this page opens. Jason, 2026-11-15: the master switch stays off until Release B, whose lines are red until it\'s built. The Automation page refuses Switch automation on while any line is red.</p>' . $cb, false) . '</div>';
    foreach (Automation::WORKFLOWS as $wf => [$name, $what, $where]) {
        $spec = WorkflowSettings::current($pdo, $wf);
        $off = Automation::wfOff($pdo, $wf); $master = Automation::master($pdo);
        $mine = array_filter($tasks, fn ($t) => (string) $t['wf'] === $wf);
        $last = null; foreach ($mine as $t) if ($t['last_served_at'] && (!$last || $t['last_served_at'] > $last['last_served_at'])) $last = $t;
        $cost = array_sum($spend[$wf] ?? []);
        $b = '<p class="ak-note">' . $e($what) . ' Runs on: ' . $e($where) . '.</p>';
        $b .= '<p data-tv-status="' . ($off || $master ? 'info' : 'ok') . '" data-tv-label="Switch:">' . $e($off !== null ? 'Paused: ' . $off : ($master ? 'On, held by the master switch' : 'Running')) . '</p>';
        $b .= '<p class="ak-note">Last run: ' . ($last ? $e($last['name'] . ', ' . $last['last_served_at'] . ' (server time): ' . strtolower(CrawlService::OUTCOMES[(string) $last['last_outcome']] ?? (string) $last['last_outcome']) . ((string) ($last['last_why'] ?? '') !== '' ? ' (' . $last['last_why'] . ')' : '')) : 'none on the crawler') . '. Cost this month: $' . number_format($cost, 2) . '. Where work waits, by phase (0164 §1–§6): shown from Release B.</p>';
        $emptyHere = array_filter($empty, fn ($r) => $r['wf'] === $wf);
        if ($emptyHere) $b .= '<p data-tv-status="bad" data-tv-label="Returns empty:">' . $e(implode(', ', array_column($emptyHere, 'name'))) . ': had work and got answers, but nothing came back (a Pulse case).</p>';
        // the form: every setting, one save
        $f = '<form method="post"><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="op_do" value="wf_save"><input type="hidden" name="ref" value="' . $e($wf) . '"><input type="hidden" name="tz" value="" data-tz>';
        $f .= '<h4 class="ak-h">What starts it</h4><p class="ak-note">' . $e($spec['starts']['schedule']) . '</p><label class="ak-note">Its triggers (what else starts it, in words) <textarea class="ak-in" name="triggers" rows="2" data-spell>' . $e((string) $spec['starts']['triggers']) . '</textarea></label>';
        if ($spec['tasks']) {
            $f .= '<h4 class="ak-h">The task schedule</h4>' . ($spec['share_pct'] !== null ? '<label class="ak-note">Its share of a crawler run <input class="ak-in" style="width:5rem" type="text" inputmode="numeric" name="share_pct" value="' . (int) $spec['share_pct'] . '">%</label>' : '');
            $f .= '<div style="overflow-x:auto"><table class="ak-aa"><thead><tr><th>Task</th>';
            foreach (WorkflowSettings::TASK_FIELDS as [$label]) $f .= '<th>' . $e($label) . '</th>';
            $f .= '<th>Services it may use</th><th>Last 24 h</th></tr></thead><tbody>';
            foreach ($spec['tasks'] as $t => $task) {
                $st = $stats[$t] ?? [];
                $f .= '<tr><td><b>' . $e($task['name']) . '</b><br><small>' . $e($t) . ((int) ($tasks[$t]['enabled'] ?? 1) ? '' : ' · switched off') . '</small></td>';
                foreach (WorkflowSettings::TASK_FIELDS as $col => [$label, $lo, $hi]) $f .= '<td><input class="ak-in" style="width:5rem" type="text" inputmode="numeric" name="t[' . $e($t) . '][' . $col . ']" value="' . (int) $task[$col] . '" aria-label="' . $e($task['name'] . ': ' . $label) . '" title="' . $lo . ' to ' . $hi . '"></td>';
                $f .= '<td><input type="hidden" name="t[' . $e($t) . '][routes][]" value=""><small style="display:grid;gap:.1rem">';
                foreach ($routeChoices as $rs) $f .= '<label style="white-space:nowrap"><input type="checkbox" name="t[' . $e($t) . '][routes][]" value="' . $e($rs) . '"' . (in_array($rs, (array) $task['routes'], true) ? ' checked' : '') . '> ' . $e(OutsideServices::COMPANIES[$rs][0] ?? $rs) . '</label>';
                $f .= '</small></td>'
                    . '<td><small>' . $e(implode(', ', array_map(fn ($k, $v) => $v . ' ' . str_replace('_', ' ', $k), array_keys(array_diff_key($st, ['seconds' => 1])), array_diff_key($st, ['seconds' => 1]))) ?: 'No runs') . '</small></td></tr>';
            }
            $f .= '</tbody></table></div><p class="ak-note">A task\'s services (its routes) are read by the crawler service from Release B; until then they\'re recorded here.</p>';
        }
        $f .= '<h4 class="ak-h">Budgets</h4><label class="ak-note">Its share of the AI cap <input class="ak-in" style="width:5rem" type="text" inputmode="numeric" name="ai_share_pct" value="' . (int) ($spec['budgets']['ai_share_pct'] ?? 0) . '">%</label> '
            . '<label class="ak-note">Its monthly budget, all services <input class="ak-in" style="width:6rem" type="text" inputmode="decimal" name="month_usd" value="' . $e((string) ($spec['budgets']['month_usd'] ?? 0)) . '"> dollars (0: none of its own)</label>';
        if ($spec['gates']) {
            $f .= '<h4 class="ak-h">Its gates</h4>';
            foreach ($spec['gates'] as $g => $v) $f .= '<label class="ak-note" style="display:block">' . $e(Thresholds::GATES[$g][0]) . ' <input class="ak-in" style="width:6rem" type="text" inputmode="decimal" name="g[' . $e($g) . ']" value="' . $e((string) $v) . '"> ' . $e(Thresholds::GATES[$g][6]) . '</label>';
        }
        if ($spec['weights']) {
            $f .= '<details><summary class="ak-h" style="cursor:pointer">The collaborative score\'s weights</summary><p class="ak-note">Not a gate (decisions/0163 §12): what each independent source adds to a listing\'s confidence, once per origin. Read by the engine from Release B.</p><table class="ak-aa"><tbody>';
            foreach ($spec['weights'] as $k => $v) $f .= '<tr><td>' . $e(WorkflowSettings::WEIGHTS[$k][0] ?? $k) . '</td><td><input class="ak-in" style="width:5rem" type="text" inputmode="numeric" name="w[' . $e($k) . ']" value="' . (int) $v . '"></td></tr>';
            $f .= '</tbody></table></details>';
        }
        if ($spec['ladder']) {
            $f .= '<details><summary class="ak-h" style="cursor:pointer">The retry ladder</summary><p class="ak-note">For what the engine retries for itself; never a site that blocks us (that waits for a person\'s Reactivate). New evidence starts it again. Read by the engine from Release B.</p><table class="ak-aa"><thead><tr><th>After fails in a row</th><th>Next try in days</th></tr></thead><tbody>';
            foreach ($spec['ladder'] as $i => [$n, $d]) $f .= '<tr><td><input class="ak-in" style="width:5rem" type="text" inputmode="numeric" name="ladder[' . $i . '][0]" value="' . (int) $n . '"></td><td><input class="ak-in" style="width:5rem" type="text" inputmode="numeric" name="ladder[' . $i . '][1]" value="' . (int) $d . '"></td></tr>';
            $f .= '</tbody></table></details>';
        }
        $f .= '<h4 class="ak-h">Steps that need a person</h4><textarea class="ak-in" name="person" rows="3" data-spell aria-label="Steps that need a person, one a line">' . $e(implode("\n", (array) $spec['person'])) . '</textarea>';
        $f .= '<p style="display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;margin-top:.5rem"><input class="ak-in" type="text" name="note" maxlength="300" data-spell placeholder="What this change is for (kept with the version)" style="flex:1;min-width:12rem">'
            . '<button class="ak-b go" type="submit" data-confirm="Save ' . $e($wf) . '\'s settings as a new version? The settings the code reads change now; nothing is switched on." data-yes="Save ' . $e($wf) . ' settings"' . (!$can ? ' disabled title="' . $e($why) . '"' : '') . '>Save ' . $e($wf) . ' settings</button></p></form>';
        $b .= $f;
        // versions
        $vs = WorkflowSettings::versions($pdo, $wf, 12);
        if ($vs) {
            $b .= '<h4 class="ak-h">Versions</h4><ul style="list-style:none;padding:0;margin:0;display:grid;gap:.35rem">';
            foreach ($vs as $i => $v) {
                $ch = json_decode((string) $v['changes'], true) ?: [];
                $b .= '<li><b>Version ' . (int) $v['version'] . '</b> · ' . $e(($v['by_name'] ?? '') !== '' ? (string) $v['by_name'] : ((int) $v['saved_by'] ? 'staff' : 'found')) . ' · <time datetime="' . $e(str_replace(' ', 'T', (string) $v['saved_at'])) . '" data-tv-time' . ((string) $v['tz'] !== '' ? ' data-tz="' . $e((string) $v['tz']) . '"' : '') . '>' . $e((string) $v['saved_at']) . '</time>'
                    . ((string) $v['note'] !== '' ? ' · ' . $e((string) $v['note']) : '') . ((int) $v['check_red'] ? ' · <span data-tv-status="info">' . (int) $v['check_red'] . ' red on the check</span>' : '')
                    . ($ch ? '<br><small>' . $e(implode('; ', array_slice($ch, 0, 6))) . (count($ch) > 6 ? '; and ' . (count($ch) - 6) . ' more' : '') . '</small>' : '')
                    . ($i > 0 ? ' ' . tv_ops_form($csrf, 'wf_back', 'Go back to it', ['ref' => $wf, 'version' => (int) $v['version']], 'Go back to version ' . (int) $v['version'] . '? It\'s saved as a new version, so nothing is lost.', '', $can, $why) : ' <small>(current)</small>') . '</li>';
            }
            $b .= '</ul>';
        }
        $h .= '<div id="wf-' . $e($wf) . '">' . tv_admin_fold($wf . ' ' . $name, ($off !== null ? 'Paused' : ($master ? 'Held by the master' : 'Running')) . ($cost > 0 ? ' · $' . number_format($cost, 2) : '') . ($vs ? ' · version ' . (int) $vs[0]['version'] : '') . ($emptyHere ? ' · returns empty' : ''), $emptyHere ? 'bad' : ($off !== null || $master ? 'info' : 'ok'), '', $b, false) . '</div>';
    }
    return $h . tv_ops_tz_js();
}
