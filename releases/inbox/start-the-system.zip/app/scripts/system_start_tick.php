<?php
// app/scripts/system_start_tick.php — carries on Start the system (System Configuration → Automation; decisions/0163 §10),
// so the page can close: each run takes the next steps (the keys, watching, the switch-on check, Railway's schedule, the
// master switch, then one workflow or new task at a time behind its gate). Every 10 minutes; does nothing (and logs
// nothing) until the button is pressed, and never on staging. Sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Staging.php';
if (Staging::here()) exit;
require_once __DIR__ . '/../lib/SystemStart.php';
$pdo = Database::connection();
try {
    if (!in_array(SystemStart::state($pdo)['state'] ?? '', ['running', 'stopped'], true)) exit;   // not pressed, done or paused
} catch (Throwable $e) { exit; }
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('system_start_tick');   // its runs show in System Configuration → Scheduled tasks
$st = SystemStart::tick($pdo);
echo 'Start the system: ' . ($st['state'] ?? '?') . "\n";
