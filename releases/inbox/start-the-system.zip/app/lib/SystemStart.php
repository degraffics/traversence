<?php
// app/lib/SystemStart.php — "Start the system" and "Pause everything" (Jason, 2026-11-15: "It seems like you expect me to
// flip each switch. Thats more work for me again. We need a ondemand system start which will fire each of the steps you
// expect me to flip. And I will address issues that the system can't fix itself."; decisions/0163 §10, its note of that
// day). One press on System Configuration → Automation (or the Workflow board) runs the switch-on in steps, on the server
// (system_start_tick, every 10 minutes), so the page can close:
//   1. the keys: a missing one holds only what needs it, and is a step in Pulse ("Starting the system") naming where it goes;
//   2. watching Railway's deploys and the sync, once its keys are there;
//   3. the switch-on check, with what it can fix by itself fixed (database updates, a failed one tried once more, the
//      register's caps recorded, held services' probes brought forward, the junk count read fresh); a red line holds
//      only what it's for, and its fix is a step in Pulse;
//   4. Railway: the crawler's schedule set again through its API (restarts kept at Never), or a step with the setting;
//   5. the master switch on, then the workflows one at a time in 0163's order (W1 first), each starting only when the one
//      before has run cleanly (start_gate_runs good runs or start_gate_hours, no new service issue, nothing out of budget,
//      failures no more than one in ten); each comes back at half budget for 14 days (Clocks::ramp, 0163 §10.2);
//   6. then the new tasks, each gated the same way: the identity recheck, Overture, Foursquare, OpenStreetMap from
//      Geofabrik, the vector index, W14.
// A gate that fails stops the sequence there (that one paused, what's left held) with one Pulse step. When Jason fixes
// what a step names, the next tick carries on by itself. Nothing here runs until the button is pressed; never on staging.
// Every outside call it makes (Railway's API) goes through ServiceHealth::allowed (holds, pauses, staging's answer).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Automation.php';
require_once __DIR__ . '/Operations.php';
require_once __DIR__ . '/Thresholds.php';

final class SystemStart
{
    public const KEY = 'ops:start';
    public const BY = 'Start the system';
    public const WAIT = 'Waiting its turn (Start the system)';
    /** The crawler's schedule on Railway before it was removed on 2026-11-14 (handoffs/crawler-revamp.md). */
    public const CRON = '*/5 * * * *';
    /** The workflows in order (0163 §10.2: one at a time, W1 first). W13 is people's own: nothing to switch. */
    public const ORDER = ['W1', 'W2', 'W3', 'W4', 'W5', 'W6', 'W7', 'W8', 'W9', 'W10', 'W11', 'W12'];
    /** The new tasks after them (§6): item => [name, its workflow (on first), services it calls, site jobs, crawler task(s)]. */
    public const TASKS = [
        'recheck' => ['The identity recheck', 'W2', [], ['identity_recheck_tick'], ['recheck']],
        'overture' => ['Overture\'s town loads', 'W1', ['overture'], [], ['overture_bulk']],
        'foursquare' => ['Foursquare\'s open places', 'W1', ['foursquare'], [], ['foursquare_bulk']],
        'osm' => ['OpenStreetMap from Geofabrik', 'W1', ['geofabrik'], [], ['geofabrik_bulk']],
        'vectors' => ['The vector index', 'W3', ['supabase', 'gemini'], ['vectors_tick'], []],
        'W14' => ['W14 Authority sources', '', [], [], []],
    ];
    /** The steps before the workflows. */
    public const FIRST = ['keys' => 'Check the keys', 'watch' => 'Switch on watching', 'check' => 'Run the switch-on check', 'railway' => 'Railway: the crawler\'s schedule', 'master' => 'The master switch on'];
    public const LABELS = ['pending' => 'Waiting', 'on' => 'Running, watched', 'done' => 'Done', 'held' => 'Held', 'stopped' => 'Stopped'];

    /** The tests' own switch-on check lines (tools/release-b-tests/start.php); null on the site. */
    public static $check = null;

    // ---- its state (one row in search_index_state: no new table) ---------------------------------------------------

    public static function state(PDO $pdo): array
    {
        try { require_once __DIR__ . '/SearchIndex.php'; $j = json_decode(SearchIndex::state($pdo, self::KEY), true); } catch (Throwable) { $j = null; }
        return is_array($j) ? $j : ['state' => 'idle'];
    }

    private static function save(PDO $pdo, array $st): void
    {
        $st['log'] = array_slice($st['log'] ?? [], -60);
        require_once __DIR__ . '/SearchIndex.php';
        SearchIndex::setState($pdo, self::KEY, json_encode($st, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private static function note(array &$st, string $line): void { $st['log'][] = [gmdate('Y-m-d H:i:s'), $line]; }

    /** Every item in order: id => name. */
    public static function items(): array
    {
        $out = self::FIRST;
        foreach (self::ORDER as $wf) $out['wf:' . $wf] = $wf . ' ' . (Automation::WORKFLOWS[$wf][0] ?? '');
        foreach (self::TASKS as $t => $d) $out['t:' . $t] = $d[0];
        return $out;
    }

    public static function can(): array
    {
        if (!class_exists('Access', false)) require_once __DIR__ . '/../admin/Access.php';
        return Access::can('config.automation', ['min' => 'executive', 'depts' => []]);
    }

    private static function staging(): bool
    {
        require_once __DIR__ . '/Staging.php';
        return Staging::here();
    }

    /** Why the button can't be pressed here, or null. */
    public static function refused(PDO $pdo): ?string
    {
        if (self::staging()) return 'Start the system runs on the live site only: staging is a safe copy, where nothing switches on.';
        if (!Automation::ready($pdo)) return 'The switches\' database update hasn\'t run yet.';
        return null;
    }

    // ---- the two buttons ----------------------------------------------------------------------------------------------

    /** Start the system: a new run, everything waiting its turn, and its first steps at once. */
    public static function start(PDO $pdo, int $uid, string $who): array
    {
        if (($no = self::refused($pdo)) !== null) throw new RuntimeException($no);
        $st = self::state($pdo);
        if (in_array($st['state'] ?? '', ['running', 'stopped'], true)) throw new RuntimeException('It\'s already starting: its progress is below.');
        $st = ['state' => 'running', 'run' => time(), 'by_uid' => $uid, 'by' => $who, 'items' => [], 'asks' => [], 'log' => $st['log'] ?? []];
        foreach (array_keys(self::items()) as $id) $st['items'][$id] = ['s' => 'pending', 'why' => '', 'at' => 0];
        // every workflow waits its turn, so the master doesn't start them all at once (0163 §10.2); one paused before keeps
        // its reason in the log, and any other reason seen later is a person's pause since the start
        foreach (array_merge(self::ORDER, ['W14']) as $wf) {
            $r = Automation::workflows($pdo)[$wf] ?? null;
            if ($r && !((int) $r['paused'] && (string) $r['paused_why'] === self::WAIT)) try { Automation::setWorkflow($pdo, $wf, true, self::WAIT, $uid, self::BY); } catch (Throwable $x) { error_log('start wait ' . $wf . ': ' . $x->getMessage()); }
        }
        self::note($st, 'Started by ' . ($who !== '' ? $who : 'a director') . '.');
        self::log($pdo, 'start', false, 'Start the system pressed', $uid, $who);
        self::save($pdo, $st);
        return self::tick($pdo);
    }

    /** Pause everything: the master off and Railway's schedule stopped (when its keys allow), in one press, logged. */
    public static function pauseAll(PDO $pdo, int $uid, string $who): string
    {
        if (self::staging()) throw new RuntimeException('Nothing runs on staging to pause.');
        Automation::set($pdo, 'master', 'all', true, 'Pause everything, pressed by ' . ($who !== '' ? $who : 'a director'), $uid, $who);
        $st = self::state($pdo);
        [$ok, $words] = self::railwayKeys() ? self::railwaySchedule($pdo, null) : [false, 'Railway\'s keys aren\'t in .env, so its schedule wasn\'t touched (each run still ends at once while the master is off).'];
        $st['state'] = 'paused'; $st['paused_at'] = time();
        self::note($st, 'Paused everything (' . ($who !== '' ? $who : 'a director') . '). Railway: ' . $words);
        self::log($pdo, 'pause_all', true, 'Pause everything; Railway: ' . $words, $uid, $who);
        self::save($pdo, $st);
        return 'Everything is paused: the master switch is off. Railway: ' . $words;
    }

    private static function log(PDO $pdo, string $ref, bool $pause, string $why, int $uid, string $who): void
    {
        try {
            $pdo->prepare('INSERT INTO automation_log (at, kind, ref, paused, why, by_uid, by_name) VALUES (UTC_TIMESTAMP(), ?, ?, ?, ?, ?, ?)')
                ->execute(['master', $ref, $pause ? 1 : 0, mb_substr($why, 0, 255), $uid ?: null, mb_substr($who, 0, 80) ?: null]);
        } catch (Throwable $x) { error_log('start log: ' . $x->getMessage()); }
    }

    // ---- the tick: one step forward at a time ------------------------------------------------------------------------

    /** The every-10-minutes job (and each press): does what's due, then says where it is. */
    public static function tick(PDO $pdo): array
    {
        $st = self::state($pdo);
        if (!in_array($st['state'] ?? '', ['running', 'stopped'], true) || self::staging()) return $st;
        $lock = false;
        try { $lock = (bool) $pdo->query("SELECT GET_LOCK('tv_system_start', 0)")->fetchColumn(); } catch (Throwable) {}
        if (!$lock) return $st;
        try { $st = self::advance($pdo, $st); self::save($pdo, $st); }
        catch (Throwable $x) { error_log('system start: ' . $x->getMessage()); self::note($st, 'A step failed: ' . mb_substr($x->getMessage(), 0, 200) . ' (tried again next time).'); self::save($pdo, $st); }
        finally { try { $pdo->query("SELECT RELEASE_LOCK('tv_system_start')"); } catch (Throwable) {} }
        return $st;
    }

    private static function set(array &$st, string $id, string $s, string $why): void
    {
        $was = $st['items'][$id] ?? [];
        if (($was['s'] ?? '') !== $s || ($was['why'] ?? '') !== $why) {
            $st['items'][$id] = ['s' => $s, 'why' => $why, 'at' => time(), 'on_at' => $s === 'on' ? (int) ($was['on_at'] ?? 0 ?: time()) : (int) ($was['on_at'] ?? 0)];
            if (($was['s'] ?? '') !== $s) self::note($st, (self::items()[$id] ?? $id) . ': ' . strtolower(self::LABELS[$s] ?? $s) . ($why !== '' ? ' (' . $why . ')' : '') . '.');
        }
    }

    private static function advance(PDO $pdo, array $st): array
    {
        $uid = (int) ($st['by_uid'] ?? 0); $asks = [];
        // a person paused the master after this run turned it on: the run stops (their switch stands)
        $m = Automation::masterRow($pdo);
        if (!empty($st['master_on']) && $m && (int) $m['paused'] && (string) ($m['by_name'] ?? '') !== self::BY) {
            $st['state'] = 'paused'; self::note($st, 'The master switch was paused by a person: the start stops here (Start the system again to carry on).');
            return $st;
        }

        // 1. the keys
        $reg = Operations::register($pdo); $missing = [];
        foreach ($reg as $k => $r) {
            if (!$r['workflows'] && !in_array($k, ['railway', 'github', 'gemini', 'supabase', 'foursquare'], true)) continue;
            foreach ($r['keys'] as [$n, $where, $have]) if ($have !== true) $missing[$n] = [$where, $have, $r['name']];
        }
        foreach ($missing as $n => [$where, $have, $svc]) $asks[] = ['Add ' . $n, 'For ' . $svc . ': ' . ($have === null ? 'the crawler hasn\'t reported it yet (it does at each run). If it\'s missing, add it ' : 'add it ') . Operations::whereToAdd($where) . '. What needs it waits; everything else goes ahead.', null, str_starts_with($where, 'Railway') ? 'railway' : ''];
        self::set($st, 'keys', $missing ? 'held' : 'done', $missing ? count($missing) . ' missing or not reported: ' . implode(', ', array_keys($missing)) : 'Every key in place');

        // 2. watching
        $w = Operations::watching($pdo);
        if (empty($w['on'])) {
            $need = []; foreach (Operations::WATCH as [$name, $key]) if (self::env($key) === '') $need[] = $key;
            if (!$need && self::env('RAILWAY_PROJECT_ID') !== '' && self::env('RAILWAY_SERVICE_ID') !== '') {
                Operations::setWatching($pdo, true, $uid); Operations::watchTick($pdo);
                self::set($st, 'watch', 'done', 'Switched on, first look taken');
            } else self::set($st, 'watch', 'held', 'Needs ' . implode(', ', $need ?: ['RAILWAY_PROJECT_ID', 'RAILWAY_SERVICE_ID']) . ' in .env');
        } else self::set($st, 'watch', 'done', 'On');

        // 3. the switch-on check, after what it can fix by itself
        $fixed = self::fixes($pdo, $st);
        Automation::forget();
        $chk = self::$check ?? Operations::switchOnCheck($pdo);
        $byScope = [];
        foreach ($chk as $l) if (!$l['ok']) $byScope[$l['scope']][] = $l;
        $all = $byScope['all'] ?? [];
        foreach ($chk as $l) {
            if ($l['ok'] || in_array($l['scope'], ['keys', 'schedule'], true)) continue;   // keys: above; the schedule: step 4
            $act = $l['fix'] ? ['tool', $l['fix'][1]] : null;
            if (str_contains($l['why'], 'junk name') ) $act = ['do', 'ops_start_junk', 'Send them to Review'];
            $asks[] = [$l['line'], $l['why'] . ' ' . ($l['scope'] === 'all' ? 'It holds the master switch.' : 'It holds only what it\'s for (' . $l['scope'] . ').'), $act, ''];
        }
        $red = count(array_filter($chk, fn ($l) => !$l['ok'] && !in_array($l['scope'], ['keys', 'schedule'], true)));
        self::set($st, 'check', $red ? 'held' : 'done', ($red ? $red . ' red line' . ($red === 1 ? '' : 's') . ($all ? ', ' . count($all) . ' holding everything' : ', each holding only its own part') : 'Every line green') . ($fixed ? '; fixed by itself: ' . implode(', ', $fixed) : ''));

        // 4. Railway's schedule
        $rs = $st['items']['railway'] ?? [];
        if (($rs['s'] ?? '') !== 'done') {
            if (self::railwayKeys()) {
                [$ok, $words] = self::railwaySchedule($pdo, self::CRON);
                self::set($st, 'railway', $ok ? 'done' : 'held', $words);
                if (!$ok) $asks[] = ['Set the crawler\'s schedule on Railway', $words . ' By hand: Railway → the traversence service → Settings: Cron Schedule ' . self::CRON . ', Restart Policy Never.', null, 'railway'];
            } else {
                self::set($st, 'railway', 'held', 'No RAILWAY_API_TOKEN, RAILWAY_PROJECT_ID and RAILWAY_SERVICE_ID in .env');
                $asks[] = ['Set the crawler\'s schedule on Railway', 'Add RAILWAY_API_TOKEN, RAILWAY_PROJECT_ID and RAILWAY_SERVICE_ID in the site\'s .env (cPanel → File Manager) and this is done for you. Or by hand: Railway → the traversence service → Settings: Cron Schedule ' . self::CRON . ', Restart Policy Never.', null, 'railway'];
            }
        }

        // 5. the master: waits only for the lines that hold everything
        if ($all) {
            self::set($st, 'master', 'held', 'Waiting for: ' . implode('; ', array_map(fn ($l) => $l['line'], array_slice($all, 0, 3))));
            $st['asks'] = $asks; return $st;
        }
        if (Automation::master($pdo)) { Automation::set($pdo, 'master', 'all', false, 'Start the system', $uid, self::BY); $st['master_on'] = time(); }
        self::set($st, 'master', 'done', 'On; workflows start one at a time');

        // 5–6. the workflows, then the new tasks: one at a time, each gated
        $ids = array_keys(self::items()); $ids = array_slice($ids, count(self::FIRST));
        $running = null;
        foreach ($ids as $id) if (($st['items'][$id]['s'] ?? '') === 'on') { $running = $id; break; }
        if ($st['state'] === 'stopped') { $st['asks'] = array_merge($asks, $st['stop_asks'] ?? []); return $st; }
        if ($running !== null && ($p = self::personPaused($pdo, self::parts($pdo, $running)[0])) !== null && (str_starts_with($running, 'wf:') || $running === 't:W14')) {
            self::set($st, $running, 'held', $p); $running = null;   // their switch stands; the next one starts
        }
        if ($running !== null) {
            $g = self::gate($pdo, $running, (int) $st['items'][$running]['on_at']);
            if ($g[0] === 'fail') {
                self::pauseItem($pdo, $running, 'Its gate failed in Start the system: ' . $g[1], $uid);
                self::set($st, $running, 'stopped', $g[1]);
                $st['state'] = 'stopped';
                $st['stop_asks'] = [[self::items()[$running] . ': its gate failed', $g[1] . ' It\'s paused, and what\'s after it waits. Look at what went wrong, then carry on.', ['do', 'ops_start_go', 'Try it again'], ''],
                                    ['Or leave it paused', 'The sequence carries on with the next one; this one stays paused until it\'s switched on by hand.', ['do', 'ops_start_skip', 'Leave it, carry on'], '']];
                $st['asks'] = array_merge($asks, $st['stop_asks']);
                return $st;
            }
            if ($g[0] === 'wait') { self::set($st, $running, 'on', $g[1]); $st['asks'] = $asks; return $st; }
            self::set($st, $running, 'done', $g[1]);
        }
        foreach ($ids as $id) {
            $s = $st['items'][$id]['s'] ?? 'pending';
            if ($s === 'done' || $s === 'stopped') continue;
            $why = self::heldBy($pdo, $id, $st, $byScope);
            if ($why !== null) { self::set($st, $id, 'held', $why); continue; }
            self::turnOn($pdo, $id, $uid);
            self::set($st, $id, 'on', 'Switched on; watched before the next starts');
            break;
        }
        $left = array_filter($ids, fn ($id) => ($st['items'][$id]['s'] ?? '') !== 'done');
        if (!$left) { $st['state'] = 'done'; self::note($st, 'Everything is on.'); }
        $st['asks'] = $asks;
        return $st;
    }

    /** What the check can fix by itself, once a run (each kept in the state so it isn't repeated): [what it did]. */
    private static function fixes(PDO $pdo, array &$st): array
    {
        $done = [];
        try {
            require_once __DIR__ . '/DbUpdates.php';
            $failed = array_keys(array_filter(DbUpdates::log($pdo), fn ($r) => !(int) $r['ok']));
            if ($failed && empty($st['fix_retried'])) { DbUpdates::retry($pdo, $failed); $st['fix_retried'] = 1; $done[] = 'the failed database update tried once more'; }
            if (DbUpdates::all($pdo)) { $r = DbUpdates::autoRun($pdo, false, 'start'); if ($r['ran']) $done[] = count($r['ran']) . ' database update(s) run'; }
        } catch (Throwable $x) { error_log('start fixes db: ' . $x->getMessage()); }
        try { if ($s = Operations::seed($pdo)) $done[] = 'the register\'s caps recorded (' . implode(', ', $s) . ')'; } catch (Throwable $x) {}
        if (empty($st['fix_probed'])) {
            try {
                require_once __DIR__ . '/ServiceHealth.php';
                $n = 0; foreach (ServiceHealth::openAll($pdo) as $si) if (ServiceHealth::holding($si) && ServiceHealth::probeSoon($pdo, (int) $si['id'])) $n++;
                if ($n) $done[] = $n . ' held service(s) probed again';
            } catch (Throwable $x) {}
            try { require_once __DIR__ . '/SearchIndex.php'; SearchIndex::setState($pdo, 'ops:junk_live', ''); } catch (Throwable $x) {}   // counted fresh
            $st['fix_probed'] = 1;
        }
        return $done;
    }

    /** Why an item must wait now (a red line for it or its services, a missing key, its workflow not on), or null. */
    private static function heldBy(PDO $pdo, string $id, array $st, array $byScope): ?string
    {
        [$wf, $svcs, , $tasks] = self::parts($pdo, $id);
        $why = [];
        if (str_starts_with($id, 'wf:')) {
            $r = Automation::workflows($pdo)[$wf] ?? null;
            if (!$r) return 'Not set up yet (its database update adds it)';
            if (($p = self::personPaused($pdo, $wf)) !== null) return $p;
        } else {
            $t = substr($id, 2); $parent = self::TASKS[$t][1];
            if ($parent !== '' && ($st['items']['wf:' . $parent]['s'] ?? '') !== 'done') return 'Waits for ' . $parent . ' to be on and clean';
            if ($t === 'recheck') { require_once __DIR__ . '/ListingIdentity.php'; if (!ListingIdentity::ready($pdo)) $why[] = 'its database update hasn\'t run'; }
            if (in_array($t, ['overture', 'foursquare', 'osm'], true)) { require_once __DIR__ . '/crawler/OpenLoads.php'; if (!OpenLoads::ready($pdo)) $why[] = 'its database update hasn\'t run'; }
            if ($t === 'foursquare' && (Operations::workerKeys()['HF_TOKEN'] ?? null) !== true) $why[] = 'HF_TOKEN on Railway (a Hugging Face account that accepted Foursquare\'s terms), not reported by the crawler yet';
            if ($t === 'vectors') {
                require_once __DIR__ . '/Vectors.php';
                if (!Vectors::configured()) $why[] = 'SUPABASE_URL and SUPABASE_SERVICE_KEY in .env';
                if (self::env('GEMINI_API_KEY') === '') $why[] = 'GEMINI_API_KEY in .env';
            }
            if ($t === 'W14') { require_once __DIR__ . '/HubOpening.php'; if (!HubOpening::ready($pdo)) $why[] = 'its database update hasn\'t run'; }
        }
        foreach (array_merge([$wf], $svcs) as $sc) foreach ($byScope[$sc] ?? [] as $l) $why[] = $l['line'] . ': ' . rtrim($l['why'], '.');
        return $why ? ucfirst(implode('; ', array_slice(array_unique($why), 0, 3))) : null;
    }

    /** A workflow paused by a person since the start (any reason but the start's own), or null. */
    private static function personPaused(PDO $pdo, string $wf): ?string
    {
        $r = Automation::workflows($pdo)[$wf] ?? null;
        if (!$r || !(int) $r['paused']) return null;
        $why = (string) ($r['paused_why'] ?? '');
        return $why === self::WAIT ? null : 'Paused by a person since the start' . ($why !== '' ? ': ' . $why : '') . ' (their switch stands)';
    }

    /** An item's workflow, the services it calls, its site jobs and its crawler tasks. */
    private static function parts(PDO $pdo, string $id): array
    {
        if (str_starts_with($id, 'wf:')) {
            $wf = substr($id, 3); $svcs = [];
            foreach (array_keys(OutsideServices::COMPANIES) as $svc) if (in_array($wf, Operations::users($pdo, $svc)[0], true)) $svcs[] = $svc;
            $jobs = array_keys(array_filter(Automation::JOBS, fn ($w) => in_array($wf, $w, true)));
            return [$wf, $svcs, $jobs, []];
        }
        $t = substr($id, 2);
        if ($t === 'W14') return ['W14', [], [], []];
        [, $parent, $svcs, $jobs, $tasks] = self::TASKS[$t];
        return [$parent, $svcs, $jobs, $tasks];
    }

    private static function turnOn(PDO $pdo, string $id, int $uid): void
    {
        $why = 'Its turn in Start the system';
        if (str_starts_with($id, 'wf:') || $id === 't:W14') {
            $wf = $id === 't:W14' ? 'W14' : substr($id, 3);
            if ($wf === 'W14') { require_once __DIR__ . '/HubOpening.php'; HubOpening::ensureWorkflow($pdo); }
            Automation::setWorkflow($pdo, $wf, false, $why, $uid, self::BY);
            return;
        }
        $t = substr($id, 2); [, , $svcs, $jobs, $tasks] = self::TASKS[$t];
        if (in_array($t, ['overture', 'foursquare', 'osm'], true)) { require_once __DIR__ . '/crawler/OpenLoads.php'; OpenLoads::ensureTasks($pdo); }
        foreach ($svcs as $svc) if (Automation::service($pdo, $svc)) Automation::set($pdo, 'service', $svc, false, $why, $uid, self::BY);
        foreach ($tasks as $task) Automation::setTask($pdo, $task, true, $why, $uid, self::BY);
        if ($t === 'vectors') {
            require_once __DIR__ . '/AiClient.php';
            $f = AiClient::FEATURES['vector_index'];
            AiClient::setFeature($pdo, 'vector_index', ['enabled' => 1, 'model' => $f[2], 'per_day' => $f[3], 'month_usd' => $f[4]], $uid);
        }
        foreach ($jobs as $job) self::ensureJob($job);
    }

    /** A job not set up in cPanel by itself (Scheduler::AUTO leaves it out until it's wanted) added on its usual schedule. */
    private static function ensureJob(string $job): void
    {
        try {
            require_once __DIR__ . '/Scheduler.php';
            if (!Scheduler::lineFor(Scheduler::cronLines(), $job)) Scheduler::add($job, Scheduler::JOBS[$job][2]);
        } catch (Throwable $x) { error_log('start job ' . $job . ': ' . $x->getMessage()); }
    }

    private static function pauseItem(PDO $pdo, string $id, string $why, int $uid): void
    {
        $why = mb_substr($why, 0, 250);
        if (str_starts_with($id, 'wf:') || $id === 't:W14') { Automation::setWorkflow($pdo, $id === 't:W14' ? 'W14' : substr($id, 3), true, $why, $uid, self::BY); return; }
        foreach (self::TASKS[substr($id, 2)][4] as $task) Automation::setTask($pdo, $task, false, $why, $uid, self::BY);
        if ($id === 't:vectors') foreach (['supabase'] as $svc) Automation::set($pdo, 'service', $svc, true, $why, $uid, self::BY);
    }

    /** The gates (0163 §12, "Start the system"): ['wait'|'pass'|'fail', why]. */
    public static function gate(PDO $pdo, string $id, int $since): array
    {
        [$wf, $svcs, $jobs] = self::parts($pdo, $id);
        $secs = max(0, time() - $since);
        $hours = (float) Thresholds::get($pdo, 'start_gate_hours'); $need = (int) Thresholds::get($pdo, 'start_gate_runs');
        // no new service issue
        try {
            require_once __DIR__ . '/ServiceHealth.php';
            foreach (ServiceHealth::openAll($pdo) as $si) if (in_array((string) $si['service'], $svcs, true) && strtotime((string) $si['first_at'] . ' UTC') >= $since) { [$t] = ServiceHealth::describe($si); return ['fail', 'A new service issue (#' . (int) $si['id'] . '): ' . $t . '.']; }
        } catch (Throwable $x) {}
        // nothing out of budget
        foreach ($svcs as $svc) { $s = Operations::status($pdo, $svc); if ($s[0] === 'out') return ['fail', (OutsideServices::COMPANIES[$svc][0] ?? $svc) . ' is out of budget: ' . $s[1]]; }
        // its runs since it came on: good ones, and failures no more than one in ten
        [$good, $bad] = self::runs($pdo, $id, $jobs, $secs);
        if ($bad > 1 && $bad * 10 > $good + $bad) return ['fail', $bad . ' of its ' . ($good + $bad) . ' runs failed since it came on (more than one in ten).'];
        $gone = $secs >= $hours * 3600;
        if ($good >= $need || $gone) return ['pass', ($good >= $need ? $good . ' good run' . ($good === 1 ? '' : 's') : 'Clean for ' . self::num($hours) . ' hours') . ', no new service issue, nothing out of budget'];
        return ['wait', $good . ' of ' . $need . ' good runs so far; clean so far; the next starts after ' . $need . ' good runs or ' . self::num($hours) . ' hours (' . (int) floor($secs / 60) . ' min in)'];
    }

    /** Its runs since it came on: [good, failed]. The site's jobs (job_runs) and, for the crawler's part, the crawler's runs. */
    private static function runs(PDO $pdo, string $id, array $jobs, int $secs): array
    {
        $good = 0; $bad = 0; $secs = max(1, $secs);
        if ($jobs) try {
            $in = implode(',', array_map(fn ($j) => $pdo->quote($j), $jobs));
            $r = $pdo->query('SELECT COALESCE(SUM(ok = 1), 0) g, COALESCE(SUM(ok = 0), 0) b FROM ' . Database::t('job_runs') . " WHERE job IN ($in) AND started_at >= NOW() - INTERVAL $secs SECOND")->fetch(PDO::FETCH_ASSOC);
            $good += (int) $r['g']; $bad += (int) $r['b'];
        } catch (Throwable $x) {}
        $crawler = str_starts_with($id, 'wf:') ? str_contains((string) (Automation::WORKFLOWS[substr($id, 3)][2] ?? ''), 'crawler') : (bool) self::TASKS[substr($id, 2)][4];
        if ($crawler && $id !== 't:recheck') try {
            $r = $pdo->query("SELECT COALESCE(SUM(status IN ('ok', 'partial', 'done')), 0) g, COALESCE(SUM(status = 'failed'), 0) b FROM crawl_runs WHERE started_at >= NOW() - INTERVAL $secs SECOND")->fetch(PDO::FETCH_ASSOC);
            $good += (int) $r['g']; $bad += (int) $r['b'];
        } catch (Throwable $x) {}
        return [$good, $bad];
    }

    // ---- Pulse: one case, "Starting the system" ------------------------------------------------------------------------

    public static function pulseItems(PDO $pdo): array
    {
        $st = self::state($pdo);
        if (!in_array($st['state'] ?? '', ['running', 'stopped'], true) || empty($st['asks'])) return [];
        $n = count($st['asks']);
        return [['ops:start', $st['state'] === 'stopped' ? 'critical' : 'alert', 'Starting the system', ($st['state'] === 'stopped' ? 'Stopped at a gate. ' : '') . $n . ' thing' . ($n === 1 ? '' : 's') . ' only you can fix; the rest carries on by itself.', date('Y-m-d H:i:s', (int) $st['run']), '/admin/config/automation#start']];
    }

    public static function pulseSteps(PDO $pdo, callable $s): array
    {
        $st = self::state($pdo); $out = [];
        foreach ($st['asks'] ?? [] as [$t, $h, $act, $ext]) $out[] = $s($t, $h, $act, false, (string) $ext);
        $out[] = $s('Look again now', 'Once you\'ve fixed one, the sequence carries on by itself within 10 minutes; this looks at once.', ['do', 'ops_start_tick', 'Look again']);
        return $out;
    }

    public static function pulseDo(PDO $pdo, string $what, int $uid, string $who): string
    {
        [$ok, $why] = self::can();
        if (!$ok) throw new RuntimeException($why . '.');
        $st = self::state($pdo);
        if ($what === 'ops_start_junk') {
            require_once __DIR__ . '/DataCleanup.php';
            $r = DataCleanup::run($pdo, 'junk_name', $uid, $who);
            require_once __DIR__ . '/SearchIndex.php'; SearchIndex::setState($pdo, 'ops:junk_live', '');
            self::tick($pdo);
            return 'Data cleanup\'s junk-name pass ran' . (!empty($r['id']) ? ' (run #' . (int) $r['id'] . ', with Undo on Data cleanup)' : '') . '.';
        }
        if (in_array($what, ['ops_start_go', 'ops_start_skip'], true) && ($st['state'] ?? '') === 'stopped') {
            foreach ($st['items'] as $id => $it) if ($it['s'] === 'stopped') {
                if ($what === 'ops_start_go') { self::turnOn($pdo, $id, $uid); self::set($st, $id, 'on', 'Tried again by ' . $who); $st['items'][$id]['on_at'] = time(); }
                else self::set($st, $id, 'done', 'Left paused by ' . $who . '; switch it on by hand when it\'s right');
            }
            $st['state'] = 'running'; unset($st['stop_asks']);
            self::save($pdo, $st);
            self::tick($pdo);
            return $what === 'ops_start_go' ? 'It\'s on again and watched; the sequence carries on.' : 'It stays paused; the sequence carries on with the next.';
        }
        if ($what === 'ops_start_tick') { self::tick($pdo); return 'Looked again: see the progress on the Automation page.'; }
        throw new RuntimeException('Unknown step.');
    }

    // ---- Railway (its API, through the gates) --------------------------------------------------------------------------

    private static function env(string $k): string
    {
        $v = getenv($k);
        if (($v === false || $v === '') && isset($_ENV[$k])) $v = (string) $_ENV[$k];
        return $v === false ? '' : (string) $v;
    }

    public static function railwayKeys(): bool
    {
        return self::env('RAILWAY_API_TOKEN') !== '' && self::env('RAILWAY_PROJECT_ID') !== '' && self::env('RAILWAY_SERVICE_ID') !== '';
    }

    private static function railway(PDO $pdo, string $query, array $vars): array
    {
        require_once __DIR__ . '/ServiceHealth.php';
        if (($no = ServiceHealth::allowed($pdo, 'backboard.railway.com')) !== null) throw new RuntimeException($no);
        $ch = curl_init('https://backboard.railway.com/graphql/v2');
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_POST => true, CURLOPT_USERAGENT => 'Traversence system start',
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . self::env('RAILWAY_API_TOKEN'), 'Content-Type: application/json'], CURLOPT_POSTFIELDS => json_encode(['query' => $query, 'variables' => $vars])]);
        $body = (string) curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $j = json_decode($body, true) ?: [];
        if ($code < 200 || $code >= 300 || !empty($j['errors'])) throw new RuntimeException('Railway answered ' . $code . (!empty($j['errors'][0]['message']) ? ': ' . mb_substr((string) $j['errors'][0]['message'], 0, 160) : ''));
        return (array) ($j['data'] ?? []);
    }

    /** The crawler's schedule set ($cron) or stopped (null), restarts kept at Never, then read back: [ok, words]. */
    public static function railwaySchedule(PDO $pdo, ?string $cron): array
    {
        try {
            $p = self::railway($pdo, 'query($p: String!) { project(id: $p) { environments { edges { node { id name } } } } }', ['p' => self::env('RAILWAY_PROJECT_ID')]);
            $env = ''; foreach ($p['project']['environments']['edges'] ?? [] as $e) { if ($env === '' || strtolower((string) $e['node']['name']) === 'production') $env = (string) $e['node']['id']; }
            if ($env === '') return [false, 'Railway found no environment in project RAILWAY_PROJECT_ID.'];
            $svc = self::env('RAILWAY_SERVICE_ID');
            self::railway($pdo, 'mutation($s: String!, $e: String!, $i: ServiceInstanceUpdateInput!) { serviceInstanceUpdate(serviceId: $s, environmentId: $e, input: $i) }', ['s' => $svc, 'e' => $env, 'i' => ['cronSchedule' => $cron, 'restartPolicyType' => 'NEVER']]);
            $r = self::railway($pdo, 'query($s: String!, $e: String!) { serviceInstance(serviceId: $s, environmentId: $e) { cronSchedule restartPolicyType nextCronRunAt } }', ['s' => $svc, 'e' => $env])['serviceInstance'] ?? [];
            $got = (string) ($r['cronSchedule'] ?? ''); $rp = (string) ($r['restartPolicyType'] ?? '');
            $ok = ($cron === null ? $got === '' : $got === $cron) && $rp === 'NEVER';
            return [$ok, $ok ? ($cron === null ? 'its schedule is stopped, restarts Never.' : 'schedule ' . $cron . ', restarts Never' . (!empty($r['nextCronRunAt']) ? ', next run ' . gmdate('H:i', (int) strtotime((string) $r['nextCronRunAt'])) . ' UTC' : '') . '.')
                         : 'Railway reads back schedule "' . ($got !== '' ? $got : 'none') . '", restarts ' . ($rp !== '' ? $rp : 'unknown') . '.'];
        } catch (Throwable $x) { return [false, 'Couldn\'t set it through Railway\'s API: ' . $x->getMessage() . '.']; }
    }

    private static function num(float $v): string { return floor($v) === $v ? (string) (int) $v : number_format($v, 1); }

    // ---- the progress view -------------------------------------------------------------------------------------------

    /** The card: the two buttons and each step done, waiting or held, with its reason. $action: where the forms post. */
    public static function panel(PDO $pdo, string $csrf, bool $can, string $why, string $action = ''): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $st = self::state($pdo); $state = (string) ($st['state'] ?? 'idle');
        $no = self::refused($pdo); $dis = !$can ? ' disabled title="' . $e($why) . '"' : ($no !== null ? ' disabled title="' . $e($no) . '"' : '');
        $form = fn (string $do, string $label, string $confirm, bool $danger) => '<form method="post"' . ($action !== '' ? ' action="' . $e($action) . '"' : '') . ' style="display:inline"><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="au_do" value="' . $e($do) . '"><input type="hidden" name="ref" value="all">'
            . '<button class="ak-b' . ($danger ? '' : ' go') . '" type="submit" data-confirm="' . $e($confirm) . '" data-yes="' . $e($label) . '"' . ($danger ? ' data-danger' : '') . $dis . '>' . $e($label) . '</button></form>';
        $busy = in_array($state, ['running', 'stopped'], true);
        $h = '<div class="ak-card tv-bleed au-m" id="start"><h3 class="ak-h" style="margin-top:0">Start the system</h3>'
            . '<p class="ak-note">One press runs the whole switch-on on the server (the page can close): the keys, watching, the switch-on check with what it can fix by itself, Railway\'s schedule, the master switch, then W1 to W12 one at a time and the new tasks, each starting only once the one before has run cleanly. Anything only you can fix is a step in Pulse ("Starting the system"); fix it and it carries on by itself.</p>'
            . '<p>' . (!$busy ? $form('start', 'Start the system', 'Start the system? The switch-on runs by itself, one workflow at a time, each at half budget for its first 14 days. Pause everything stops it at any time.', false) . ' ' : '')
            . $form('pause_all', 'Pause everything', 'Pause everything? The master switch goes off and Railway\'s schedule stops. Business operations carry on.', true) . '</p>';
        if ($no !== null) $h .= '<p data-tv-status="info" data-tv-label="Here:">' . $e($no) . '</p>';
        $tone = ['running' => 'info', 'stopped' => 'bad', 'done' => 'ok', 'paused' => 'info', 'idle' => 'info'][$state] ?? 'info';
        $words = ['idle' => 'Never pressed.', 'running' => 'Starting, step by step.', 'stopped' => 'Stopped at a gate: see Pulse, "Starting the system".', 'done' => 'Everything is on.', 'paused' => 'Paused everything.'][$state] ?? $state;
        $since = !empty($st['run']) ? ' Started ' . self::when((int) $st['run']) . (!empty($st['by']) ? ' by ' . $e($st['by']) : '') . '.' : '';
        $h .= '<p data-tv-status="' . $tone . '" data-tv-label="Now:">' . $e($words) . $since . '</p>';
        if (!empty($st['items'])) {
            $h .= '<ol style="margin:.4rem 0 .4rem 1.1rem;display:grid;gap:.25rem">';
            foreach (self::items() as $id => $name) {
                $it = $st['items'][$id] ?? ['s' => 'pending', 'why' => ''];
                $t = ['done' => 'ok', 'on' => 'info', 'held' => 'bad', 'stopped' => 'bad', 'pending' => 'info'][$it['s']] ?? 'info';
                $h .= '<li><p data-tv-status="' . $t . '" data-tv-label="' . $e($name . ': ' . (self::LABELS[$it['s']] ?? $it['s'])) . '" style="margin:0">' . $e((string) $it['why']) . (!empty($it['at']) ? ' <small>' . self::when((int) $it['at']) . '</small>' : '') . '</p></li>';
            }
            $h .= '</ol>';
        }
        if (!empty($st['log'])) {
            $lb = '<ul style="margin:0;padding-left:1rem;font-size:.85rem">';
            foreach (array_reverse(array_slice($st['log'], -15)) as [$at, $line]) $lb .= '<li>' . self::when((int) strtotime($at . ' UTC')) . ' ' . $e($line) . '</li>';
            $h .= '<details><summary>What it did</summary>' . $lb . '</ul></details>';
        }
        return $h . '</div>';
    }

    private static function when(int $ts): string
    {
        return '<time datetime="' . gmdate('c', $ts) . '" data-tv-time>' . gmdate('M j, g:i A', $ts) . ' UTC</time>';
    }
}
