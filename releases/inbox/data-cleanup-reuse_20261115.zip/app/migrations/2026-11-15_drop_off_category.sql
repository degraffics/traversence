-- app/migrations/2026-11-15_drop_off_category.sql — "Mail & package drop-off" (Jason, 2026-11-15: drop and collection
-- boxes are "their own listing and map pin", handoffs/data-cleanup.md). A new leaf under the group that holds the post
-- office (or shipping, or mail) category. Insert only, safe to run twice: nothing is added when the leaf is there, or
-- when no such group is found (Data cleanup then says the category isn't there yet). Listings get it from a Data cleanup
-- pass ("Mail & package drop-offs"), logged and undoable, so there is no UPDATE here.
INSERT INTO categories (parent_id, slug, name, sort_order, is_active, created_at, updated_at)
SELECT g.pid, 'mail-package-drop-off', 'Mail & package drop-off', 0, 1, NOW(), NOW()
  FROM (SELECT c.parent_id AS pid FROM categories c
         WHERE c.parent_id IS NOT NULL AND c.is_active = 1
           AND (LOWER(c.name) LIKE '%post office%' OR LOWER(c.slug) LIKE '%post-office%' OR LOWER(c.slug) LIKE '%postoffice%'
                OR LOWER(c.name) LIKE '%postal%' OR LOWER(c.name) LIKE '%shipping%' OR LOWER(c.name) LIKE 'mail%' OR LOWER(c.name) LIKE '% mail%')
         ORDER BY (LOWER(c.name) LIKE '%post office%') DESC, (LOWER(c.name) LIKE '%postal%') DESC, (LOWER(c.name) LIKE '%shipping%') DESC, c.id
         LIMIT 1) g
 WHERE NOT EXISTS (SELECT 1 FROM categories x WHERE x.slug = 'mail-package-drop-off');
