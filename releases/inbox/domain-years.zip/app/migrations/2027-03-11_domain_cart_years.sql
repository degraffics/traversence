-- How many years a domain in the cart is bought for (Jason, 2026-11-17: a 1, 2, 3, 4, 5 or 10 year choice, like
-- whois.com). Adds one column; safe to run twice. domain_cart is in the main database (2027-03-10_account_domains_wallet).
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE domain_cart ADD COLUMN years TINYINT UNSIGNED NOT NULL DEFAULT 1 AFTER kind', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'domain_cart' AND COLUMN_NAME = 'years');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
