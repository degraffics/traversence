/* js/pulse-msg.js — a message acts inside itself (decisions/0172 "The message: what it's for, and acting on it inside it").
 * Any page that shows a message's body (the member's and the admin's Pulse, the bell's list) loads this once:
 *   - <button data-msg-act="/endpoint" data-msg-body='{json}'> posts the JSON (with X-CSRF-Token), shows its spinner, says
 *     the answer beside itself, and puts the answer's html (the message's body, read again) in place: it never leaves the
 *     page. data-confirm / data-yes / data-danger ask first (TvAsk.gate).
 *   - <form data-msg-reply="/endpoint" data-msg-body='{json}'> posts the JSON plus its named fields (a short reply, a
 *     password to reconnect), the same way.
 *   - TvPulseMsg.open(id, el): draws message <id> in el, in place: what happened, where it stands now, its body with its
 *     buttons, its last three route entries, and marks it read.
 *   - The bell (#tv-bell): its colour is the highest level waiting (Critical red, Urgent amber, Alert marked), and a tap
 *     lists those items, each opening in place; "Open Pulse" goes to the whole list. Nothing is pinned or moved by us.
 */
(function () {
  if (window.TvPulseMsg) return;
  var csrf = window.appCsrfToken || '';
  function token() {
    if (csrf) return Promise.resolve(csrf);
    return fetch('/user/api/marks.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) { csrf = j.csrf || ''; return csrf; });
  }
  function post(url, body) {
    return token().then(function (t) {
      return fetch(url, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': t },
        body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) });
    }).then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again; still stuck? Write to support@traversence.com.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work. Try again.'); return j; });
  }
  function say(msg, el, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: el, bad: !!bad }); }
  function busy(el, on) { if (window.TvAsk) TvAsk.busy(el, on); }
  function bodyOf(el) { try { return JSON.parse(el.getAttribute('data-msg-body') || '{}'); } catch (e) { return {}; } }
  function swap(el, html) {
    var box = el.closest('.tv-msg-body');
    if (box && html) { box.innerHTML = html; if (window.TvTime) TvTime.paint(box);
      var st = box.parentNode && box.parentNode.querySelector('.tv-msg-state');   // where it stands changed: the body's own status line says it now
      if (st && html.indexOf('data-tv-status') >= 0) st.parentNode.removeChild(st); }
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  document.addEventListener('click', function (ev) {
    var b = ev.target.closest && ev.target.closest('[data-msg-act]');
    if (!b) return;
    ev.preventDefault();
    if (b.hasAttribute('data-confirm') && window.TvAsk && !TvAsk.gate(b, b.getAttribute('data-confirm'), { yes: b.getAttribute('data-yes') || 'Yes', danger: b.hasAttribute('data-danger') })) return;
    busy(b, true);
    post(b.getAttribute('data-msg-act'), bodyOf(b)).then(function (j) {
      busy(b, false); say(j.message || 'Done.', b); swap(b, j.html);
    }).catch(function (e) { busy(b, false); say(e.message, b, true); });
  });
  document.addEventListener('submit', function (ev) {
    var f = ev.target.closest && ev.target.closest('form[data-msg-reply]');
    if (!f) return;
    ev.preventDefault();
    var body = bodyOf(f), btn = f.querySelector('button') || f;
    Array.prototype.forEach.call(f.elements, function (x) { if (x.name) body[x.name] = x.value; });
    if (f.querySelector('[name=body]') && !String(body.body || '').trim()) { say('Write something first.', btn, true); return; }
    busy(btn, true);
    post(f.getAttribute('data-msg-reply'), body).then(function (j) {
      busy(btn, false); say(j.message || 'Sent.', btn); f.reset(); swap(f, j.html);
    }).catch(function (e) { busy(btn, false); say(e.message, btn, true); });
  });

  var LEVEL = { critical: 'Critical', urgent: 'Urgent', alert: 'Alert', notice: 'Notice', general: 'General', special: 'Special' };
  function open(id, el) {
    el.innerHTML = '<p class="tv-msg-wait">Opening…</p>';
    return fetch('/user/api/pulse-msg.php?id=' + encodeURIComponent(id), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok) throw new Error((j.error && j.error.message) || 'That message didn\'t open.');
      if (j.csrf) csrf = j.csrf;
      var route = (j.route || []).map(function (r) { return '<li><time datetime="' + esc(r.at) + '" data-tv-time>' + esc(r.at) + '</time> · ' + esc(r.via) + ': ' + esc(r.stage) + (r.detail ? ' (' + esc(r.detail) + ')' : '') + '</li>'; }).join('');
      el.innerHTML = '<div class="tv-msg lvl-' + esc(j.level) + '"><p class="tv-msg-what"><span class="tv-lvl lvl-' + esc(j.level) + '">' + esc(LEVEL[j.level] || j.level) + '</span> ' + esc(j.title) + '</p>'
        + (j.state && j.html.indexOf(esc(j.state)) < 0 && j.html.indexOf('data-tv-status') < 0 ? '<p class="tv-msg-state">' + esc(j.state) + '</p>' : '')   // a body that already says where it stands (its own status line) isn't repeated
        + '<div class="tv-msg-body">' + j.html + '</div>'
        + (route ? '<details class="tv-msg-route"><summary>Its route</summary><ul>' + route + '</ul></details>' : '') + '</div>';
      if (window.TvTime) TvTime.paint(el);
      return j;
    }).catch(function (e) { el.innerHTML = '<p data-tv-status="bad" data-tv-label="Error:">' + esc(e.message) + ' Try again; still stuck? Write to support@traversence.com.</p>'; });
  }

  // the bell: colour and list
  function bell() {
    var a = document.getElementById('tv-bell');
    if (!a || !window.appAuthActive) return;
    fetch('/user/api/pulse-msg.php?bell=1', { credentials: 'include' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      if (!j || !j.ok) return;
      a.classList.remove('lvl-critical', 'lvl-urgent', 'lvl-alert');
      if (j.top) a.classList.add('lvl-' + j.top);
      if (!j.items.length || a.getAttribute('data-bell-list')) return;
      a.setAttribute('data-bell-list', '1');
      var pop = null;
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        if (pop) { pop.remove(); pop = null; return; }
        pop = document.createElement('div');
        pop.className = 'tv-bell-pop'; pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-label', 'Waiting for you');
        pop.innerHTML = '<ul>' + j.items.map(function (it) {
          return '<li><button type="button" class="tv-bell-it lvl-' + esc(it.level) + '" data-id="' + it.id + '"><span class="tv-lvl lvl-' + esc(it.level) + '">' + esc(LEVEL[it.level]) + '</span> ' + esc(it.title) + '<small>' + esc(it.from) + ' · <time datetime="' + esc(it.when) + '" data-tv-time>' + esc(it.when) + '</time></small></button><div class="tv-bell-open"></div></li>';
        }).join('') + '</ul><p><a href="' + esc(a.getAttribute('href')) + '">Open Pulse</a></p>';
        a.parentNode.insertBefore(pop, a.nextSibling);
        if (window.TvTime) TvTime.paint(pop);
        pop.addEventListener('click', function (e2) {
          var it = e2.target.closest('.tv-bell-it');
          if (!it) return;
          var box = it.nextElementSibling;
          if (box.innerHTML) { box.innerHTML = ''; return; }
          pop.querySelectorAll('.tv-bell-open').forEach(function (x) { if (x !== box) x.innerHTML = ''; });   // one open at a time
          open(it.getAttribute('data-id'), box);
          it.classList.add('read');
        });
      });
      document.addEventListener('keydown', function (e3) { if (e3.key === 'Escape' && pop) { pop.remove(); pop = null; } });
    }).catch(function () {});
  }

  var css = document.createElement('style');
  css.textContent = '.tv-lvl{font-weight:700;font-size:.8rem}.tv-lvl.lvl-critical{color:#B91C1C}.tv-lvl.lvl-urgent{color:#B45309}.tv-lvl.lvl-alert{color:#C2410C}.tv-lvl.lvl-notice{color:#5C4632}.tv-lvl.lvl-general{color:#2F6B55}.tv-lvl.lvl-special{color:#6D28D9}'
    + '.tv-msg{display:grid;gap:.4rem}.tv-msg-what{margin:0;font-weight:600}.tv-msg-state{margin:0;color:#5C4632;font-size:.9rem}.tv-msg-acts{display:flex;flex-wrap:wrap;gap:.4rem;margin:.4rem 0 0}'
    + '.tv-msg-route{font-size:.82rem;color:#8A7355}.tv-msg-route ul{margin:.2rem 0 0;padding-left:1rem}'
    + '#tv-bell.lvl-critical svg{color:#B91C1C}#tv-bell.lvl-urgent svg{color:#B45309}#tv-bell.lvl-alert svg{color:#C2410C}'
    + '.tv-bell-pop{position:absolute;right:.5rem;top:3.2rem;z-index:1000;width:min(26rem,calc(100vw - 6px));max-height:70vh;overflow:auto;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;box-shadow:0 8px 24px rgba(62,43,31,.18);padding:.5rem}'
    + '.tv-bell-pop ul{list-style:none;margin:0;padding:0}.tv-bell-pop li{border-bottom:1px solid #EADFC4}.tv-bell-it{all:unset;display:block;cursor:pointer;padding:.5rem .3rem;width:100%;box-sizing:border-box}.tv-bell-it.read{opacity:.7}'
    + '.tv-bell-it small{display:block;color:#8A7355}.tv-bell-open:not(:empty){padding:.3rem .3rem .6rem}.tv-bell-pop>p{margin:.4rem .3rem 0;text-align:right}.tv-bell-open{text-align:left}'
    + '@media (max-width:767px){.tv-bell-pop{left:3px;right:3px;width:auto}}';
  document.head.appendChild(css);

  window.TvPulseMsg = { open: open, post: post, bell: bell };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bell); else bell();
})();
