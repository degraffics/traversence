// js/tv-pulse.js — the Pulse (decisions/0055 §5): one list of what's coming in (From, Subject, Received), each row opening
// in place (▾), for the context you're acting in (/user/api/pulse.php). One script for every page it shows on: your
// Dashboard, and a business's Overview (/business/<id>; Jason, 2026-11-11: "The dashboard here needs the pulse").
// The page draws the panel (app/ui/pulse-panel.php) and calls TvPulse.load(); a new post (tvm:posted) reloads it.
// The row's icons manage the message (decisions/0172 step 3): read or unread, pin, file (a folder or Archive) and ⊕ (Follow
// up, importance, tags) are the person's own marks (/user/api/marks.php); a dispatcher message opens with its own body
// and buttons (js/pulse-msg.js).
(function () {
  'use strict';
  if (!document.getElementById('pu-list') || window.TvPulse) return;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  // ---- the Pulse (decisions/0055 §5) ----
  var P = { data: null, filter: 'all', tab: null };
  function pref(k, d) { try { var v = localStorage.getItem('tv_pulse_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function setPref(k, v) { try { localStorage.setItem('tv_pulse_' + k, JSON.stringify(v)); } catch (e) {} }
  function when(w) { if (!w) return ''; var d = new Date(String(w).replace(' ', 'T')); if (isNaN(d)) return String(w).slice(0, 10); var m = (Date.now() - d) / 60000;
    return m < 60 ? Math.max(1, Math.round(m)) + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : m < 10080 ? Math.round(m / 1440) + ' d ago' : d.toLocaleDateString(); }
  function loadPulse() {
    fetch('/user/api/pulse.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) throw new Error(d.error && d.error.message);
      P.data = d; paintPulse();
    }).catch(function (e) { document.getElementById('pu-needs').innerHTML = '<p class="pu-muted">' + esc(e.message || 'The Pulse isn\'t available right now.') + '</p>'; });
  }
  // the Pulse as in Jason's mockup (draft 2026-10-09). Row actions, likes, comments and Publish show the layout; most are "coming".
  var SV = function (d, w) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 1.7) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>'; };
  var IC = {
    reply: SV('<path d="M3 9l9 6 9-6"/><path d="M3 9l9-6 9 6v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>'),
    fwd: SV('<path d="M14 5l7 6-7 6V13c-6 0-9 2-11 6 0-6 3-11 11-11z"/>'),
    pin: SV('<path d="M9 3h6l-1 6 3 3v2H7v-2l3-3z"/><path d="M12 14v7"/>'),
    report: SV('<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>'),
    folder: SV('<path d="M3 6a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M12 10v6M9.5 13.5 12 16l2.5-2.5"/>'),
    add: SV('<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>'),
    down: SV('<path d="M5 8l7 8 7-8z" fill="currentColor"/>'),
    link: SV('<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>', 2.4),
    heart: SV('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>', 2),
    eye: SV('<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>', 2.2),
    chat: SV('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>', 2.2),
    open: SV('<path d="M15 3h6v6M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>', 2.2),
    clip: SV('<path d="M21.4 11.1l-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/>'),
    cam: SV('<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>'),
    vid: SV('<rect x="2" y="5" width="15" height="14" rx="2"/><path d="M17 10l5-3v10l-5-3z"/>'),
    cast: SV('<circle cx="12" cy="12" r="2"/><path d="M16.2 7.8a6 6 0 0 1 0 8.4M7.8 16.2a6 6 0 0 1 0-8.4M19.1 4.9a10 10 0 0 1 0 14.2M4.9 19.1a10 10 0 0 1 0-14.2"/>')
  };
  var ORDER = ['needs', 'messages', 'community', 'marketplace', 'listings', 'discovery', 'questions', 'notices'];
  function stamp(w) { if (!w) return ''; var d = new Date(String(w).replace(' ', 'T')); if (isNaN(d)) return String(w).slice(0, 16);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ', ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); }
  function paintPulse() {
    var d = P.data, needs = document.getElementById('pu-needs');
    var nCount = d.needs.reduce(function (a, n) { return a + (n[0] || 1); }, 0), bn = document.getElementById('pu-bell-n');
    bn.hidden = !nCount; bn.textContent = nCount > 99 ? '99+' : nCount;
    // what needs you arrives as rows ("Needs you") and on the bell, not as a fixed block above the list (decisions/0172)
    if (needs) needs.hidden = true;
    document.getElementById('pu-bell').setAttribute('aria-pressed', P.filter === 'needs' ? 'true' : 'false');
    var src = Object.keys(d.sources || {}).sort(function (a, b) { return ORDER.indexOf(a) - ORDER.indexOf(b); });
    var off = pref('off', []), on = src.filter(function (k) { return off.indexOf(k) < 0; }), mode = pref('mode', 'list');
    var items = d.items.filter(function (i) { return on.indexOf(i.source) >= 0; });
    P.items = items;
    var count = function (k) { return items.filter(function (i) { return i.source === k; }).length; };
    document.querySelectorAll('input[name="pu-mode"]').forEach(function (r) { r.checked = r.value === mode; });
    document.getElementById('pu-srcs').innerHTML = src.map(function (k) { return '<label><input type="checkbox" data-src="' + k + '"' + (off.indexOf(k) < 0 ? ' checked' : '') + '> ' + esc(d.sources[k]) + '</label>'; }).join('');
    var list = document.getElementById('pu-list'), chips = document.getElementById('pu-chips'), member = d.context && d.context.kind === 'member';
    // the pills: each source with its count; a tap shows only that one, again shows everything. Tabs mode always shows one.
    if (mode === 'tabs' && (P.filter === 'all' || on.indexOf(P.filter) < 0)) P.filter = on[0] || 'all';
    if (P.filter !== 'all' && P.filter !== 'journeys' && on.indexOf(P.filter) < 0) P.filter = 'all';
    chips.innerHTML = on.map(function (k) { return '<button type="button" class="pv-cat' + (P.filter === k ? ' on' : '') + '" data-f="' + k + '" aria-pressed="' + (P.filter === k) + '">' + esc(d.sources[k]) + ' <small>' + count(k) + '</small></button>'; }).join('')
      + (member ? '<button type="button" class="pv-cat soon' + (P.filter === 'journeys' ? ' on' : '') + '" data-f="journeys" title="Journeys from people and places you follow: coming">Journeys <small>0</small></button>' : '');
    var empty = { messages: 'No messages yet. Find people in your Address Book.', community: 'Posts from your groups and new connections show here.',
      discovery: 'Link a place (the chain icon on any region or town page) and what\'s new there shows here.', listings: 'Link businesses and places, and their news shows here.',
      marketplace: 'Marketplace posts from sellers you link will show here. Your own posts are in Your Marketplace (#market).', questions: 'Questions from guests who aren\'t signed in show here.',
      notices: 'Comments on your listing and other notices to your business show here.',
      journeys: 'Journeys from the people and places you follow will show here. Coming.' };
    var its = P.filter === 'all' ? items : items.filter(function (i) { return i.source === P.filter; });
    list.className = 'pu-list' + (mode === 'stream' ? '' : ' pl tv-bleed');
    if (!its.length) { list.innerHTML = '<p class="pu-muted" style="padding:.7rem .4rem">' + esc(P.filter === 'all' ? 'Nothing new yet. Link places, businesses and people, and join groups: your Pulse is built from them.' : (empty[P.filter] || 'Nothing yet.')) + '</p>'; return; }
    if (mode === 'stream') {
      list.innerHTML = its.map(function (i) { return '<a class="pu-it' + (i.unread ? ' new' : '') + '" href="' + esc(i.url) + '"><span class="pu-src">' + esc(d.sources[i.source] || i.source) + '</span><span><b>' + esc(i.title) + '</b>'
        + '<small>' + esc(i.body) + (i.when ? ' · ' + esc(when(i.when)) : '') + '</small></span></a>'; }).join('');
      return;
    }
    var acts = function (n) {
      return '<button type="button" class="pl-i" data-pa="read" data-n="' + n + '" title="Mark read or unread" aria-label="Mark read or unread">' + IC.reply + '</button>'
        + '<button type="button" class="pl-i" data-pa="forward" data-n="' + n + '" title="Forward" aria-label="Forward">' + IC.fwd + '</button>'
        + '<button type="button" class="pl-i" data-pa="pin" data-n="' + n + '" title="Pin in your list" aria-label="Pin" aria-pressed="false">' + IC.pin + '</button>'
        + '<button type="button" class="pl-i" data-pa="report" data-n="' + n + '" title="Report" aria-label="Report">' + IC.report + '</button>'
        + '<button type="button" class="pl-i" data-pa="folder" data-n="' + n + '" title="Move to a folder" aria-label="Move to a folder">' + IC.folder + '</button>'
        + '<button type="button" class="pl-i" data-pa="save" data-n="' + n + '" title="Add to: Follow up, importance, tags" aria-label="Add to: Follow up, importance, tags">' + IC.add + '</button>';
    };
    list.innerHTML = '<div class="pl-h"><span></span><span>From</span><span></span><span>Subject</span><span>Received</span><span></span></div>'
      + its.map(function (i) {
        // an item that names its sender (what needs you, a message the dispatcher sent): From is the sender, Subject its title
        // then its words; otherwise (a conversation) the title is who it's with and the words are the subject
        var n = items.indexOf(i), named = !!(i.from && i.from !== i.title), from = named ? i.from : (i.title || d.sources[i.source]),
          subj = named ? esc(i.title) + (i.body ? ' <small style="font-weight:400;color:#8A7355;margin-left:.3rem">' + esc(i.body) + '</small>' : '') : esc(i.body);
        return '<div class="pl-r' + (i.unread ? ' new' : '') + '" data-n="' + n + '"><span class="pl-av" aria-hidden="true">' + esc(String(from).charAt(0).toUpperCase()) + '</span>'
          + '<span class="pl-from">' + esc(from) + '<small>' + esc(d.sources[i.source] || i.source) + '</small></span>'
          + '<a class="pl-ln" href="' + esc(i.url) + '" title="Go to where it came from" aria-label="Go to where it came from">' + IC.link + '</a>'
          + '<span class="pl-sub">' + subj + '</span><span class="pl-when" title="' + esc(when(i.when)) + '">' + esc(stamp(i.when)) + '</span>'
          + '<span class="pl-act">' + acts(n) + '<button type="button" class="pl-i x" data-pl-x title="Open" aria-label="Open" aria-expanded="false">' + IC.down + '</button></span>'
          + '<p class="pl-note" role="status"></p><div class="pl-body" hidden></div></div>';
      }).join('');
    P.acts = acts;
    P.items = items;
    marks(its, items);
  }

  // ---- the person's own marks (decisions/0172 "Flags and tags in Pulse"): pin, folder, archive, Follow up, importance, tags,
  // read or unread, kept per person (/user/api/marks.php), never shown to the sender; the list's order is theirs to choose
  function itemKey(i) {
    if (i.item) return i.item;
    var s = String(i.url) + '|' + String(i.title), h = 0;
    for (var k = 0; k < s.length; k++) { h = ((h << 5) - h + s.charCodeAt(k)) | 0; }
    return String(i.source).replace(/[^a-z]/g, '').slice(0, 10) + ':' + (h >>> 0).toString(36);
  }
  var M = { marks: {}, tags: [], folders: {}, csrf: '', view: pref('view', '') };
  (function () { var st = document.createElement('style');
    st.textContent = '.pl-marks{display:inline-flex;gap:.25rem;margin-left:.35rem;vertical-align:middle}.pl-flag{color:#B91C1C}.pl-flag.done{color:#2F6B55}.pl-imp{font-size:.72rem;font-weight:700;color:#92400E}.pl-imp.low{color:#8A7355}'
      + '.pl-tag{font-size:.72rem;border:1px solid;border-radius:999px;padding:0 .4rem}.pu-views{display:flex;flex-wrap:wrap;gap:.3rem;margin:.3rem 0}.pl-r.lvl-critical{box-shadow:inset 3px 0 0 #B91C1C}.pl-r.lvl-urgent{box-shadow:inset 3px 0 0 #B45309}';
    document.head.appendChild(st); })();
  function mpost(body) {
    return fetch('/user/api/marks.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': M.csrf || window.appCsrfToken || '' },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }).then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t save.'); return j; });
  }
  function marks(its, items) {
    var keys = items.map(itemKey);
    fetch('/user/api/marks.php?items=' + encodeURIComponent(keys.join(',')), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok || !j.ready) return;
      M.marks = j.marks || {}; M.tags = j.tags || []; M.folders = j.folders || {}; M.csrf = j.csrf || M.csrf;
      paintMarks();
    }).catch(function () {});
  }
  function paintMarks() {
    var list = document.getElementById('pu-list'), rows = list.querySelectorAll('.pl-r'), pinned = [];
    var tagName = {}; M.tags.forEach(function (t) { tagName[t.id] = t; });
    rows.forEach(function (r) {
      var i = P.items[+r.getAttribute('data-n')], m = M.marks[itemKey(i)] || {};
      var filed = m.archived || m.folder;
      r.hidden = M.view === '' ? !!filed : M.view === 'pinned' ? !m.pinned : M.view === 'flagged' ? m.flag !== 'open' : M.view === 'archived' ? !m.archived : M.view.indexOf('folder:') === 0 ? m.folder !== M.view.slice(7) : false;
      var pin = r.querySelector('[data-pa=pin]'); if (pin) pin.setAttribute('aria-pressed', m.pinned ? 'true' : 'false');
      if (m.back) r.classList.add('new');
      var badge = r.querySelector('.pl-marks'); if (!badge) { badge = document.createElement('span'); badge.className = 'pl-marks'; r.querySelector('.pl-sub').appendChild(badge); }
      badge.innerHTML = (m.flag === 'open' ? '<span class="pl-flag" title="Follow up' + (m.due ? ': ' + esc(m.due) : '') + '">&#9873;</span>' : m.flag === 'done' ? '<span class="pl-flag done" title="Follow-up done">&#10003;</span>' : '')
        + (m.importance ? '<span class="pl-imp ' + esc(m.importance) + '">' + (m.importance === 'high' ? 'High' : 'Low') + '</span>' : '')
        + (m.tags || []).map(function (t) { var x = tagName[t]; return x ? '<span class="pl-tag" style="border-color:' + esc(x.colour) + ';color:' + esc(x.colour) + '">' + esc(x.name) + '</span>' : ''; }).join('');
      if (i.level && (i.level === 'critical' || i.level === 'urgent')) r.classList.add('lvl-' + i.level);
      if (m.pinned) pinned.push(r);
    });
    var head = list.querySelector('.pl-h');
    pinned.reverse().forEach(function (r) { head.insertAdjacentElement('afterend', r); });   // pinned by the person: theirs, at the top of their own list
    var v = document.getElementById('pu-views');
    if (!v) { v = document.createElement('div'); v.id = 'pu-views'; v.className = 'pu-views'; list.parentNode.insertBefore(v, list); }
    var opts = [['', 'Inbox'], ['pinned', 'Pinned'], ['flagged', 'Follow up'], ['archived', 'Archived']].concat(Object.keys(M.folders).map(function (f) { return ['folder:' + f, f]; }));
    v.innerHTML = opts.map(function (o) { return '<button type="button" class="pv-cat' + (M.view === o[0] ? ' on' : '') + '" data-view="' + esc(o[0]) + '" aria-pressed="' + (M.view === o[0]) + '">' + esc(o[1]) + '</button>'; }).join('');
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#pu-views [data-view]'); if (!b) return;
    M.view = b.getAttribute('data-view'); setPref('view', M.view); paintMarks();
  });
  function mark(r, a, set, said) {
    var i = P.items[+r.getAttribute('data-n')], key = itemKey(i);
    if (window.TvAsk) TvAsk.busy(a, true);
    return mpost({ item: key, set: set }).then(function (j) {
      if (window.TvAsk) { TvAsk.busy(a, false); TvAsk.say(said || j.message, { anchor: a }); }
      M.marks[key] = j.marks; paintMarks();
    }).catch(function (x) { if (window.TvAsk) { TvAsk.busy(a, false); TvAsk.say(x.message, { anchor: a, bad: true }); } });
  }
  function addTo(r, a) {
    var i = P.items[+r.getAttribute('data-n')], m = M.marks[itemKey(i)] || {};
    var ch = [['today', 'Follow up today', ''], ['tomorrow', 'Follow up tomorrow', ''], ['week', 'Follow up this week', ''], ['nextweek', 'Follow up next week', ''], ['date', 'Follow up on a date', '']];
    if (m.flag === 'open') ch.push(['done', 'Mark the follow-up complete', ''], ['clear', 'Clear the flag', '']);
    ch.push(['high', 'High importance', 'Only for you: sort and find by it.'], ['low', 'Low importance', ''], ['noimp', 'No importance', ''], ['tags', 'Tags…', 'Your own words with a colour; a team\'s shared tags too.']);
    TvAsk.choose('Add to', ch, '', { yes: 'Choose' }).then(function (v) {
      if (!v) return;
      var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (x) {}
      if (['today', 'tomorrow', 'week', 'nextweek'].indexOf(v) >= 0) return mark(r, a, { follow: v, tz: tz });
      if (v === 'date') return TvAsk.ask('Follow up on (YYYY-MM-DD)', '').then(function (d) { if (d) mark(r, a, { follow: 'date', date: String(d).trim(), tz: tz }); });
      if (v === 'done' || v === 'clear') return mark(r, a, { flag: v });
      if (v === 'high' || v === 'low' || v === 'noimp') return mark(r, a, { importance: v === 'noimp' ? '' : v });
      if (v === 'tags') {
        var tc = M.tags.map(function (t) { return [String(t.id), t.name, t.shared ? 'Shared with your team' : '']; }).concat([['new', 'A new tag…', '']]);
        return TvAsk.choose('Tags', tc, (m.tags || []).join(','), { multi: true }).then(function (picked) {
          if (picked === null) return;
          var ids = picked.split(',').filter(function (x) { return x && x !== 'new'; });
          if (picked.split(',').indexOf('new') < 0) return mark(r, a, { tags: ids });
          return TvAsk.ask('New tag', '').then(function (name) {
            if (!name) return;
            return mpost({ tag: { name: name } }).then(function (j) { M.tags.push(j.tag); ids.push(String(j.tag.id)); return mark(r, a, { tags: ids }); });
          });
        });
      }
    });
  }
  function plOpen(r) {
    var i = P.items[+r.getAttribute('data-n')], body = r.querySelector('.pl-body'), me = document.getElementById('pu-list').getAttribute('data-me') || 'you';
    if (!body.innerHTML && i.comms) {   // a message carries its own process (decisions/0172): its body, read live, with its buttons
      body.innerHTML = '<div class="pl-act2">' + P.acts(r.getAttribute('data-n')) + '</div><div class="pl-msgbox"></div>';
      var go = function () { window.TvPulseMsg.open(i.comms, body.querySelector('.pl-msgbox')).then(function () { r.classList.remove('new'); }); };
      if (window.TvPulseMsg) go(); else { var sc = document.createElement('script'); sc.src = '/js/pulse-msg.js'; sc.onload = go; document.head.appendChild(sc); }
    }
    if (!body.innerHTML && i.post && window.TvMoments) {   // a post (decisions/0153): the real one, in place: photos or video, reactions, comments
      body.innerHTML = '<div class="pl-act2">' + P.acts(r.getAttribute('data-n')) + '</div><div class="pl-post"></div><p class="pl-msg" role="status"></p>';
      TvMoments.show(body.querySelector('.pl-post'), i.post);
    }
    if (!body.innerHTML) {
      var ph = i.photos || [], h = '<div class="pl-act2">' + P.acts(r.getAttribute('data-n')) + '</div><div class="pl-x' + (ph.length ? ' media' : '') + '">';
      if (ph.length) {
        h += '<div class="pl-media"><div class="pl-main" style="background-image:url(\'' + esc(ph[0]) + '\')"><button type="button" class="pl-heart" data-pa="like" aria-pressed="false" title="Like" aria-label="Like">' + IC.heart + '</button>'
          + '<span class="pl-stat"><span>' + IC.eye + '## views</span><span>' + IC.chat + '## comments</span></span></div>'
          + '<div class="pl-thumbs">' + ph.slice(1, 9).map(function (u, k) { return '<button type="button" data-ph-n="' + (k + 1) + '" style="background-image:url(\'' + esc(u) + '\')" aria-label="Photo ' + (k + 2) + '"></button>'; }).join('') + '</div>'
          + '<a class="pl-open" href="' + esc(i.url) + '" title="Open it" aria-label="Open it">' + IC.open + '</a></div>';
      }
      h += '<div class="pl-text"><p>' + esc(i.body) + ' <a href="' + esc(i.url) + '">See more</a></p>'
        + '<div class="pl-cm"><div class="pl-cm-top"><div class="pl-cm-av"><span>' + esc(me.charAt(0).toUpperCase()) + '</span><button type="button" data-pa="as" title="Comment as you or a business you manage" aria-label="Comment as">&#9660;</button></div>'
        + '<textarea placeholder="Comment as ' + esc(me) + '" aria-label="Comment"></textarea></div>'
        + '<div class="pl-cm-bar"><button type="button" class="pl-i" data-pa="attach" title="Attach a file" aria-label="Attach a file">' + IC.clip + '</button>'
        + '<button type="button" class="pl-i" data-pa="photo" title="Add a photo" aria-label="Add a photo">' + IC.cam + '</button>'
        + '<button type="button" class="pl-i" data-pa="video" title="Add a video" aria-label="Add a video">' + IC.vid + '</button><span class="sp"></span>'
        + '<button type="button" class="pl-i" data-pa="audience" title="Who sees it" aria-label="Who sees it">' + IC.cast + '</button>'
        + '<span class="pl-pub"><button type="button" data-pa="publish">PUBLISH</button><button type="button" data-pa="pubmenu" aria-label="More ways to post" aria-expanded="false">&#9660;</button>'
        + '<span class="pl-pubm" hidden><button type="button" data-pa="publish">Publish</button><button type="button" data-pa="draft">Save as draft</button><button type="button" data-pa="schedule">Schedule</button></span></span></div></div>'
        + '<p class="pl-msg" role="status"></p></div></div>';
      body.innerHTML = h;
    }
    var open = body.hidden; body.hidden = !open; r.classList.toggle('open', open);
    var x = r.querySelector('[data-pl-x]'); x.setAttribute('aria-expanded', String(open)); x.title = open ? 'Close' : 'Open';
    return body;
  }
  var SOON = { forward: 'Forwarding is coming.', report: 'Reporting from the Pulse is coming. For now, use Report where it came from.', attach: 'Attachments are coming.', photo: 'Adding photos is coming.', video: 'Adding videos is coming.',
    audience: 'Choosing who sees it is coming.', as: 'Commenting as a business you manage is coming.', publish: 'Posting from the Pulse is coming.',
    draft: 'Drafts are coming.', schedule: 'Scheduling is coming.', like: '' };
  var q = document.getElementById('pu-q');
  if (q) q.addEventListener('input', function () {
    var t = q.value.trim().toLowerCase();
    document.querySelectorAll('#pu-list .pl-r, #pu-list .pu-it').forEach(function (r) { r.hidden = t !== '' && r.textContent.toLowerCase().indexOf(t) < 0; });
  });
  document.getElementById('pu-chips').addEventListener('click', function (e) {
    var b = e.target.closest('[data-f]'); if (!b) return;
    var f = b.getAttribute('data-f');
    P.filter = P.filter === f && pref('mode', 'list') !== 'tabs' ? 'all' : f; paintPulse();
  });
  document.getElementById('pu-bell').addEventListener('click', function () {   // the bell shows what needs you: its rows
    if (!P.data) return;
    P.filter = P.filter === 'needs' ? 'all' : 'needs'; paintPulse();
  });
  var pvn = document.getElementById('pv-name');
  if (pvn) pvn.addEventListener('click', function (e) { e.stopPropagation(); if (window.tvCx) window.tvCx(pvn); });
  document.getElementById('pu-list').addEventListener('click', function (e) {
    var r = e.target.closest('.pl-r'); if (!r) return;
    if (e.target.closest('[data-pl-x]')) { plOpen(r); return; }
    var t = e.target.closest('[data-ph-n]');
    if (t) { var ph = P.items[+r.getAttribute('data-n')].photos, k = +t.getAttribute('data-ph-n'), main = r.querySelector('.pl-main'), cur = main.getAttribute('data-k') || 0;
      main.style.backgroundImage = 'url("' + ph[k] + '")'; t.style.backgroundImage = 'url("' + ph[cur] + '")'; t.setAttribute('data-ph-n', cur); main.setAttribute('data-k', k); return; }
    var a = e.target.closest('[data-pa]'); if (!a) return;
    var act = a.getAttribute('data-pa'), note = r.querySelector('.pl-note'), msg = r.querySelector('.pl-msg');
    if (act === 'pubmenu') { var m = a.parentNode.querySelector('.pl-pubm'); m.hidden = !m.hidden; a.setAttribute('aria-expanded', String(!m.hidden)); return; }
    var ip = P.items[+r.getAttribute('data-n')];
    if (ip && ip.post && window.TvMoments && (act === 'reply' || act === 'report')) {   // a post: reply is a comment on it, report is its own Report
      var pb = r.querySelector('.pl-body'); if (pb.hidden) pb = plOpen(r);
      var t = pb.querySelector(act === 'reply' ? '.tmo-acts [data-com]' : '[data-more]'); if (t) t.click(); return;
    }
    if (act === 'reply') { var b = r.querySelector('.pl-body'); if (b.hidden) b = plOpen(r); var ta = b.querySelector('textarea'); if (ta) ta.focus(); return; }
    var mk = M.marks[itemKey(ip)] || {};
    if (act === 'read') { var un = !r.classList.contains('new'); r.classList.toggle('new', un); mark(r, a, { unread: un }, un ? 'Marked unread.' : 'Marked read.'); return; }
    if (act === 'pin') { mark(r, a, { pinned: !mk.pinned }); return; }
    if (act === 'folder') {
      var fch = [['__archive', 'Archive', 'Out of the list; Archived shows it.']].concat(Object.keys(M.folders).map(function (f) { return [f, f, '']; })).concat([['__new', 'A new folder…', ''], ['__back', 'Back in the list', '']]);
      TvAsk.choose('File it', fch, mk.archived ? '__archive' : (mk.folder || ''), { yes: 'File it' }).then(function (v) {
        if (!v) return;
        if (v === '__archive') return mark(r, a, { archived: true });
        if (v === '__back') return mark(r, a, { folder: '' });
        if (v === '__new') return TvAsk.ask('New folder', '').then(function (n) { if (n) { M.folders[n] = 0; mark(r, a, { folder: n }); } });
        mark(r, a, { folder: v });
      });
      return;
    }
    if (act === 'save') { addTo(r, a); return; }
    if (act === 'like') { a.setAttribute('aria-pressed', a.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); }
    var say = act === 'like' ? 'Likes are coming.' : SOON[act];
    if (!say) return;
    var pm = a.closest('.pl-pubm'); if (pm) pm.hidden = true;
    if (msg && a.closest('.pl-body')) msg.textContent = say; else note.textContent = say;
  });
  (function () {   // on a phone the settings panel sits under the gear, within the screen's edges
    var d = document.querySelector('.pu-set'); if (!d) return;
    function place() { if (!d.open) return; var p = d.querySelector('.pu-setp'); if (innerWidth >= 768) { p.style.top = ''; return; } p.style.top = Math.round(d.querySelector('summary').getBoundingClientRect().bottom + 6) + 'px'; }
    d.addEventListener('toggle', place); addEventListener('resize', place); addEventListener('scroll', function () { if (d.open && innerWidth < 768) d.open = false; }, { passive: true });
  })();
  document.querySelector('.pu-setp').addEventListener('change', function (e) {
    var t = e.target;
    if (t.name === 'pu-mode') setPref('mode', t.value);
    if (t.hasAttribute('data-src')) { var off = pref('off', []), k = t.getAttribute('data-src'); off = off.filter(function (x) { return x !== k; }); if (!t.checked) off.push(k); setPref('off', off); }
    paintPulse();
  });
  document.addEventListener('tvm:posted', function () { var l = document.getElementById('pu-list'); if (l && l.offsetParent !== null) loadPulse(); });   // a new post shows in the Pulse
  window.TvPulse = { load: loadPulse };
})();
