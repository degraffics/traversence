<?php
// app/lib/Scheduler.php — our scheduled scripts (app/scripts/*_tick.php, ai_worker.php) and their cron jobs in cPanel,
// set from System Configuration → Scheduled tasks through the cPanel API (CPanel::api2, module Cron). Each script
// records its own runs (run() at its top), so the page shows when each last ran and whether it worked, whether or not
// cPanel can be reached from here. Cron runs on the server's clock.
declare(strict_types=1);

require_once __DIR__ . '/AdminTables.php';
require_once __DIR__ . '/CPanel.php';

final class Scheduler
{
    /** Our jobs: key (its script, app/scripts/<key>.php) => [name, what it does, the preset it starts on, how late is "late" in minutes]. */
    public const JOBS = [
        'ai_worker' => ['AI worker', 'Reads queued AI jobs: scanned business cards now, menus and brochures with the Studio.', 'minute', 15],
        'standing_tick' => ['Notices of action', 'Moves notices whose 24 hours ran out (page loads do it too, every few minutes).', '10min', 60],
        'sales_tick' => ['Lead scores', 'Scores the listings worth a call and gives new listings in a territory to its rep.', 'hourly', 180],
        'files_tick' => ['Files to S3', 'Moves files from before S3 into their owners\' folders in S3, a batch at a time, until none are left on the server (decisions/0124). Then it has nothing to do and can be removed.', '10min', 60],
        'work_orders_tick' => ['Work order reminders', 'Asks vendors for an update: a work order not accepted by 9:00 am the next business day, 24 hours before its must-have time, and at it.', 'hourly', 180],
        'guide_finds_tick' => ['Find it and guide drafts', 'Looks up the names a guide mentions that we don\'t have yet (our crawler first, then web search with Claude) and sends what it confirms through the listings pipeline, which publishes the ready ones; links names once they\'re listed. And drafts one guide a run with Claude (asked-for ones first, then unwritten city and community guides), published by its score. And, while the Live events template is set running, looks for one place\'s upcoming events.', '15min', 60],
        'listings_tick' => ['Listings pipeline', 'Matches the crawler\'s waiting listings again, merges the ones we already have and publishes the ready ones by rule, without anyone opening Review.', '15min', 60],
        'guide_live_tick' => ['Guide weather and roads', 'Keeps each guide\'s weather (National Weather Service) and Arizona\'s road work (AZ 511) fresh ahead of visitors, so a guide never waits on them.', '15min', 60],
        'got_it_tick' => ['Did it arrive?', 'Reminds a client to tell us they have their order (that completes it), 72 hours after the last of it shipped or was ready for pickup, once.', 'hourly', 180],
        'pay_wait_tick' => ['Payment reminders', 'Reminds a client who chose wire or check and hasn\'t given a confirmation code (and tells support): 2 hours after, 9:00 am the next business day, and 4 pm with the other ways to pay.', '15min', 60],
        'services_tick' => ['Services & usage', 'Emails the admins when web search, Google Places or Claude reaches 80% or 100% of its monthly cap, and the month\'s report on the 1st (decisions/0133).', 'hourly', 180],
        'takedowns_tick' => ['Takedowns and the guide audit', 'Hides what someone asked us to take down once 24 hours pass without a person deciding (a protected reason hides it at once), and draws the quarterly sample of published guides to audit (decisions/0133).', '10min', 60],
        'heritage_tick' => ['Heritage catalog', 'Reads each guide\'s place (the Library of Congress\'s records the crawler found, its dossier and research) into vetted facts for the heritage catalog and the guides\' "Walking in the footsteps" chapter, files them in the Topic index, keeps topic summaries current and researches the most asked-for thin topics.', 'hourly', 180],
        'daily_report' => ['Daily report', 'Emails the Founder one report a day at 5 am Arizona time (Stream settings): every open Pulse case with a button to its step, and the system status. It checks each hour and sends once the hour comes.', 'hourly2', 180],
        'market_tick' => ['Marketplace check', 'Asks sellers "Still available?" of every post that\'s due, and takes off the ones asked at the last check that nobody confirmed (decisions/0135 §8). Closes offers nobody answered in 7 days and reminds a trade\'s other side to confirm (§4).', 'daily', 1560],
        'notice_digest' => ['Notices by email: weekly digest', 'Sends each person who chose a weekly email of their notices one email of the week\'s notices, through Amazon SES (decisions/0137 §6, §8). Runs daily; each person gets one every 7 days.', 'daily', 30],
        'ses_setup_tick' => ['Email sending setup', 'Sets up Amazon SES by itself (decisions/0137 §8): the sending domains, their DNS records through the cPanel API, bounce reports, the check with AWS, asking for production access, and one test once live. Does nothing once the setup is done.', '15min', 60],
        'domains_tick' => ['Businesses\' domains', 'Checks businesses\' own domains on their storefronts (decisions/0139 §3): DNS and the certificate for the ones waiting, live ones once a day, and renews domains bought through us two weeks before they run out.', '15min', 60],
        'billing_tick' => ['Plans and renewals', 'Renews what\'s due on the card on file, retries declined cards, ends trials and sends the reminders.', 'daily', 1560],
        'region_tick' => ['Sign-up region check', 'Keeps the EU/EEA/UK address ranges for the sign-up check fresh (decisions/0027): downloads DB-IP\'s free country file (CC BY 4.0) once a month; daily it only checks.', 'daily', 240],
        'guide_ondemand_tick' => ['Guides on demand', 'Carries on guides a searcher asked for after they leave, writes the ones waiting for the allowance (most asked first), and writes each first look in full once its deeper research is in (decisions/0147).', '5min', 30],
        'journeys_tick' => ['Suggested journeys', 'Builds each live guide\'s suggested journeys from its own places by rules (no AI), three guides a run, again weekly or when the guide changes; asks openrouteservice once for a town\'s travel times and keeps them (decisions/0146).', 'hourly', 180],
        'landmark_photos_tick' => ['Landmark photos', 'Looks on Wikimedia Commons for a free photo of each shown landmark that has none (taken nearby and named for it), 20 an hour, and keeps the best with its credit and licence. One with none found is looked at again after 30 days.', 'hourly', 180],
        'like_watch_tick' => ['Like checks', 'Looks at the last hour\'s likes: takes machine likes (perfectly timed, or more likes than views) off the count, reports groups of new accounts and guests to Safety in Pulse, and deletes like records older than 30 days.', 'hourly', 180],
        'earned_storage_tick' => ['Earned storage', 'Counts each member\'s qualifying followers and friends who joined, and adds the storage they\'ve earned: 1 GB per 500 followers and per friend, up to 25 GB, 5 GB a month at most (decisions/0154 §7).', 'daily', 1500],
        'moments_tick' => ['Moments', 'Ends posts whose 3 or 7 days are up (deletes them and their photos and videos, unless kept or waiting on a report), tells people a day before, lets go of uploads never posted, and releases reported posts\' held copies after their 90 days (decisions/0153).', 'hourly', 180],
        'guest_tick' => ['Guests\' 30 days', 'Deletes the hashed connections behind guests\' likes after 30 days (decisions/0009); the likes stay in the counts.', 'daily', 60],
        'vault_digest_tick' => ['Vault email summaries', 'Sends the vault\'s hourly and daily email summaries to whoever chose them (the vault\'s Emails), only when something happened. Alerts about devices, recovery words and locks always go at once.', 'hourly', 180],
        'releases_tick' => ['Releases', 'Publishes a release when its scheduled time comes, and moves live releases on a step (members, then everyone) once their hours have passed clean, inside the release window (System Configuration → Releases). A failed check pauses it and emails whoever approved it.', '10min', 60],
        'staging_carry_tick' => ['Staging refresh, carried on', 'Works through a staging refresh on the server once one is started (System Configuration → Staging, or the weekly Staging refresh), so the page needn\'t stay open. Does nothing when no refresh is running.', 'minute', 15],
        'audit_clock_tick' => ['Site audit clock', 'Asks GitHub to run the site audit\'s checks when their hour comes (the code checks at 7:00 and 19:00 UTC, the browser checks and paths at 9:00, the search probe at 10:00), because GitHub\'s own schedule skips them when it\'s busy (decisions/0145). Site health in Pulse says when one hasn\'t run in 26 hours. Does nothing on staging.', 'hourly', 180],
        'staging_tick' => ['Staging refresh', 'Once staging.trvgo.us is set up (System Configuration → Staging): a fresh copy of the live site there once a week, its files and databases with people\'s details replaced by test values, the test accounts kept (decisions/0145 Phase 3). Until then it does nothing.', 'weekly', 10140],
    ];

    /** Jobs that set themselves up in cPanel (sync()), on their usual schedule, with no one opening cPanel (Jason, 2026-10-28):
     *  every new job goes here. One removed on the Scheduled tasks page stays removed. */
    public const AUTO = ['moments_tick', 'earned_storage_tick', 'guide_ondemand_tick', 'journeys_tick', 'landmark_photos_tick', 'like_watch_tick', 'guest_tick', 'region_tick', 'work_orders_tick', 'pay_wait_tick', 'got_it_tick', 'guide_finds_tick', 'guide_live_tick', 'listings_tick', 'services_tick', 'heritage_tick', 'takedowns_tick', 'daily_report', 'market_tick', 'notice_digest', 'ses_setup_tick', 'domains_tick', 'staging_tick', 'staging_carry_tick', 'releases_tick', 'vault_digest_tick', 'audit_clock_tick'];

    /** Schedules to choose from: key => [label, minute, hour, day, month, weekday]. */
    public const PRESETS = [
        'minute' => ['Every minute', '*', '*', '*', '*', '*'],
        '5min' => ['Every 5 minutes', '*/5', '*', '*', '*', '*'],
        '10min' => ['Every 10 minutes', '*/10', '*', '*', '*', '*'],
        '15min' => ['Every 15 minutes', '*/15', '*', '*', '*', '*'],
        'hourly' => ['Every hour (at :17)', '17', '*', '*', '*', '*'],
        'hourly2' => ['Every hour (at :02)', '2', '*', '*', '*', '*'],
        '6hours' => ['Every 6 hours', '17', '*/6', '*', '*', '*'],
        'daily' => ['Every day at 6:13 am', '13', '6', '*', '*', '*'],
        'nightly' => ['Every night at 2:13 am', '13', '2', '*', '*', '*'],
        'weekly' => ['Every Sunday at 3:13 am', '13', '3', '*', '*', '0'],
    ];

    public static function ensure(PDO $pdo): void
    {
        AdminTables::make($pdo, ['job_runs' => '(id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, job VARCHAR(40) NOT NULL, started_at DATETIME NOT NULL,
            finished_at DATETIME DEFAULT NULL, ok TINYINT(1) DEFAULT NULL, note VARCHAR(255) NOT NULL DEFAULT \'\', KEY idx_job_runs (job, id))',
            'job_setup' => '(job VARCHAR(40) NOT NULL PRIMARY KEY, state VARCHAR(10) NOT NULL, at DATETIME NOT NULL)']);
    }

    // ---- a script's own run --------------------------------------------------------------------------------------------

    /** Called at the top of a scheduled script: records the run, and at the end whether it finished and what it said. */
    public static function run(string $job): void
    {
        try {
            $pdo = Database::connection();
            self::ensure($pdo);
            $pdo->prepare('INSERT INTO ' . Database::t('job_runs') . ' (job, started_at) VALUES (?, NOW())')->execute([$job]);
            $id = (int) $pdo->lastInsertId();
            if (random_int(1, 50) === 1) $pdo->prepare('DELETE FROM ' . Database::t('job_runs') . ' WHERE job = ? AND started_at < NOW() - INTERVAL 14 DAY')->execute([$job]);
        } catch (Throwable $e) { error_log('scheduler: ' . $e->getMessage()); return; }   // the job still runs
        try { self::sync($pdo); } catch (Throwable $e) { error_log('scheduler sync: ' . $e->getMessage()); }   // any running job sets up new ones (hourly at most)
        ob_start();
        register_shutdown_function(function () use ($pdo, $id) {
            $out = (string) ob_get_clean();
            echo $out;
            $e = error_get_last();
            $bad = $e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true);
            $lines = array_values(array_filter(array_map('trim', explode("\n", $out))));
            $note = $bad ? 'Stopped: ' . $e['message'] : (string) end($lines);
            try { $pdo->prepare('UPDATE ' . Database::t('job_runs') . ' SET finished_at = NOW(), ok = ?, note = ? WHERE id = ?')->execute([$bad ? 0 : 1, mb_substr($note, 0, 255), $id]); } catch (Throwable) {}
        });
    }

    /** The last run of each job: job => row. */
    public static function lastRuns(PDO $pdo): array
    {
        self::ensure($pdo);
        $out = [];
        foreach (array_keys(self::JOBS) as $j) {
            $st = $pdo->prepare('SELECT * FROM ' . Database::t('job_runs') . ' WHERE job = ? ORDER BY id DESC LIMIT 1'); $st->execute([$j]);
            if ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                $f = $pdo->prepare('SELECT COUNT(*) FROM ' . Database::t('job_runs') . ' WHERE job = ? AND ok = 0 AND started_at > NOW() - INTERVAL 1 DAY'); $f->execute([$j]);
                $r['fails_today'] = (int) $f->fetchColumn();
                $out[$j] = $r;
            }
        }
        return $out;
    }

    // ---- the cron jobs in cPanel ---------------------------------------------------------------------------------------

    /** Every cron line in cPanel: [line, linekey, minute, hour, day, month, weekday, command]. */
    public static function cronLines(): array
    {
        $out = [];
        foreach (CPanel::api2('Cron', 'listcron') as $r) {
            if (!is_array($r) || !isset($r['command'])) continue;   // the list ends with a count
            $out[] = ['line' => (int) ($r['line'] ?? 0), 'linekey' => (string) ($r['linekey'] ?? ''), 'minute' => (string) $r['minute'], 'hour' => (string) $r['hour'], 'day' => (string) $r['day'],
                'month' => (string) $r['month'], 'weekday' => (string) $r['weekday'], 'command' => (string) $r['command']];
        }
        return $out;
    }

    /** Which cron line runs a job (null when none). */
    public static function lineFor(array $lines, string $job): ?array
    {
        foreach ($lines as $l) if (str_contains($l['command'], 'app/scripts/' . $job . '.php')) return $l;
        return null;
    }

    /** The command for a job: PHP (the one our other jobs use, else CRON_PHP, else cPanel's usual), the script, output to nowhere (no email each run). */
    public static function command(string $job, array $lines = []): string
    {
        $php = trim((string) getenv('CRON_PHP')) ?: '/usr/local/bin/php';
        foreach ($lines as $l) if (preg_match('#^(\S*php\S*)\s+\S*app/scripts/#', $l['command'], $m)) { $php = $m[1]; break; }
        $script = (realpath(__DIR__ . '/../scripts') ?: __DIR__ . '/../scripts') . '/' . $job . '.php';
        return $php . ' ' . $script . ' >/dev/null 2>&1';
    }

    /**
     * Sets up the AUTO jobs cPanel doesn't have yet, on their usual schedule, through the cPanel API: at most once an hour
     * unless $now. A job removed on the page (or one we set up and someone took out in cPanel) isn't put back. Returns
     * the jobs it added.
     */
    public static function sync(PDO $pdo, bool $now = false): array
    {
        try { require_once __DIR__ . '/../admin/DataMove.php'; DataMove::home($pdo); } catch (Throwable $x) { error_log('identity home: ' . $x->getMessage()); }   // the identity record lives in main (decisions/0133)
        try { require_once __DIR__ . '/Identity.php'; Identity::backfillIntake($pdo, 50); Identity::backfillListings($pdo, 50); require_once __DIR__ . '/crawler/IntakeStager.php'; IntakeStager::tidySources($pdo); require_once __DIR__ . '/ListingConfidence.php'; ListingConfidence::backfill($pdo, 300); } catch (Throwable $x) { error_log('intake identities: ' . $x->getMessage()); }   // sightings from before 2026-11-01 get theirs
        try { require_once __DIR__ . '/DbUpdates.php'; DbUpdates::autoRun($pdo); } catch (Throwable $x) { error_log('db updates: ' . $x->getMessage()); }   // new migration files run themselves, at most once an hour
        if (!CPanel::ready()) return [];
        self::ensure($pdo);
        $t = Database::t('job_setup');
        if (!$now) {
            $st = $pdo->query("SELECT at FROM $t WHERE job = '_sync'"); $last = $st ? $st->fetchColumn() : false;
            if ($last && strtotime((string) $last) > time() - 3600) return [];
        }
        $pdo->prepare("REPLACE INTO $t (job, state, at) VALUES ('_sync', 'ran', NOW())")->execute();
        $known = $pdo->query("SELECT job, state FROM $t")->fetchAll(PDO::FETCH_KEY_PAIR);
        $lines = self::cronLines(); $added = [];
        foreach (self::AUTO as $job) {
            if (!isset(self::JOBS[$job])) continue;
            if (self::lineFor($lines, $job)) { if (!isset($known[$job])) self::mark($pdo, $job, 'added'); continue; }
            if (isset($known[$job])) continue;   // removed, or set up before and taken out by hand: left that way
            $p = self::PRESETS[self::JOBS[$job][2]];
            CPanel::api2('Cron', 'add_line', ['command' => self::command($job, $lines), 'minute' => $p[1], 'hour' => $p[2], 'day' => $p[3], 'month' => $p[4], 'weekday' => $p[5]]);
            self::mark($pdo, $job, 'added'); $added[] = $job;
        }
        return $added;
    }

    private static function mark(PDO $pdo, string $job, string $state): void
    {
        try { self::ensure($pdo); $pdo->prepare('REPLACE INTO ' . Database::t('job_setup') . ' (job, state, at) VALUES (?, ?, NOW())')->execute([$job, $state]); } catch (Throwable $e) { error_log('scheduler mark: ' . $e->getMessage()); }
    }

    public static function add(string $job, string $preset): void
    {
        if (!isset(self::JOBS[$job])) throw new InvalidArgumentException('Not one of our jobs.');
        $p = self::PRESETS[$preset] ?? null; if (!$p) throw new InvalidArgumentException('Choose when it runs.');
        $lines = self::cronLines();
        if (self::lineFor($lines, $job)) throw new InvalidArgumentException('It\'s already set up in cPanel.');
        CPanel::api2('Cron', 'add_line', ['command' => self::command($job, $lines), 'minute' => $p[1], 'hour' => $p[2], 'day' => $p[3], 'month' => $p[4], 'weekday' => $p[5]]);
        self::mark(Database::connection(), $job, 'added');
    }

    public static function change(string $job, string $preset): void
    {
        $p = self::PRESETS[$preset] ?? null; if (!$p) throw new InvalidArgumentException('Choose when it runs.');
        $l = self::lineFor(self::cronLines(), $job); if (!$l) throw new InvalidArgumentException('It isn\'t set up in cPanel yet.');
        CPanel::api2('Cron', 'edit_line', ['line' => $l['line'], 'linekey' => $l['linekey'], 'command' => $l['command'], 'minute' => $p[1], 'hour' => $p[2], 'day' => $p[3], 'month' => $p[4], 'weekday' => $p[5]]);
    }

    public static function remove(string $job): void
    {
        $l = self::lineFor(self::cronLines(), $job); if (!$l) throw new InvalidArgumentException('It isn\'t set up in cPanel.');
        CPanel::api2('Cron', 'remove_line', ['line' => $l['line'], 'linekey' => $l['linekey']]);
        self::mark(Database::connection(), $job, 'removed');   // sync() leaves it out from now on
    }

    /** The preset a line matches ('' when it's set to something else). */
    public static function presetOf(array $l): string
    {
        foreach (self::PRESETS as $k => $p) if ([$l['minute'], $l['hour'], $l['day'], $l['month'], $l['weekday']] === array_slice($p, 1)) return $k;
        return '';
    }

    /** A cron schedule in words, as well as can be said. */
    public static function words(array $l): string
    {
        $k = self::presetOf($l);
        return $k !== '' ? self::PRESETS[$k][0] : trim($l['minute'] . ' ' . $l['hour'] . ' ' . $l['day'] . ' ' . $l['month'] . ' ' . $l['weekday']) . ' (cron)';
    }
}
