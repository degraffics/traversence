<?php
// app/scripts/audit_clock_tick.php — asks GitHub to run the site audit's workflows when their hour comes (AuditClock),
// because GitHub's own schedule skips them when it's busy (decisions/0145, 2026-11-13). Hourly at :17; sets itself up
// in cPanel through the API (Scheduler::AUTO). Does nothing on staging.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('audit_clock_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/AuditClock.php';
try { echo implode(' ', AuditClock::tick(Database::connection())) . "\n"; }
catch (Throwable $e) { echo 'Not ready yet: ' . $e->getMessage() . "\n"; }
