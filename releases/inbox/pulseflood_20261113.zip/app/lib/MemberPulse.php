<?php

declare(strict_types=1);

require_once __DIR__ . '/Roles.php';
require_once __DIR__ . '/Links.php';
require_once __DIR__ . '/People.php';
require_once __DIR__ . '/BizMessages.php';

/**
 * app/lib/MemberPulse.php — a member's Pulse: everything incoming, in one place (decisions/0055 §5).
 *
 * needs():  what needs the person, for the context they're acting in (the old Notification Center, now the top of
 *           the Pulse). Counts and a link, never anyone's private content.
 * stream(): what's new, from every source, newest first: messages, community, discovery, listings, marketplace
 *           (member); customer messages and guest questions (a listing's team); group posts (steward).
 * Staff (Admin) have "needs" only: queues and reports. No role reads people's private messages.
 */
final class MemberPulse
{
    public const SOURCES = ['messages' => 'Messages', 'community' => 'Community', 'discovery' => 'Discovery', 'listings' => 'Listings',
                            'marketplace' => 'Marketplace', 'questions' => 'Guest questions'];

    /** The sources a context has, in order. */
    public static function sources(array $ctx): array
    {
        return match ($ctx['kind']) {
            'org' => ['messages', 'questions'],
            'steward' => ['community'],
            'admin' => [],
            default => ['messages', 'community', 'discovery', 'listings', 'marketplace'],
        };
    }

    /** @return list<array{0: int, 1: string, 2: string}> [count (0 = a note), text, link] */
    public static function needs(PDO $pdo, int $uid, array $ctx): array
    {
        $n = [];
        // a notice of action on the account comes first, in every role (decisions/0079)
        if (is_file(__DIR__ . '/Standing.php')) {
            require_once __DIR__ . '/Standing.php';
            try {
                if ($nt = Standing::current($pdo, $uid)) $n[] = [0, $nt['status'] === 'review' ? 'You asked for a review of the notice on your account: a person will reply by email.'
                    : ((int) $nt['step'] >= 2 ? 'Final warning on your account: posting and messaging are stopped. See what to do.' : 'A notice on your account needs you within 24 hours.'), '/user/notice.php'];
            } catch (Throwable) {}
        }
        if ($ctx['kind'] === 'member' && is_file(__DIR__ . '/Notices.php')) {   // notices sent once, unseen (decisions/0137 §6)
            require_once __DIR__ . '/Notices.php';
            try { if ($c = Notices::unread($pdo, $uid)) $n[] = [$c, $c === 1 ? 'new notice' : 'new notices', '#pulse']; } catch (Throwable) {}
        }
        if ($ctx['kind'] === 'member') {
            try {
                $st = $pdo->prepare('SELECT COUNT(*) FROM entity_referrals WHERE referrer_user_id = ? AND confirmed_at IS NULL');
                $st->execute([$uid]);
                if ($c = (int) $st->fetchColumn()) $n[] = [$c, $c === 1 ? 'referral request to confirm' : 'referral requests to confirm', '#business'];
            } catch (Throwable) {}
            // a claim waiting on its last step, or a request on hold (decisions/0070)
            if (is_file(__DIR__ . '/Claims.php')) {
                require_once __DIR__ . '/Claims.php';
                try {
                    if (Claims::ready($pdo)) foreach (Claims::forUser($pdo, $uid) as $c) {
                        if ($c['status'] === 'managed') $n[] = [0, 'Finish claiming ' . $c['name'] . ': text ' . $c['text_code'] . ' to ' . Claims::verifyNumber() . '.', '/claim.php?listing=' . (int) $c['entity_id']];
                        elseif ($c['status'] === 'on_hold') $n[] = [0, 'Your request to claim ' . $c['name'] . ' is on hold: an admin will be in touch.', '/claim.php?listing=' . (int) $c['entity_id']];
                    }
                } catch (Throwable) {}
            }
            if (People::tableExists($pdo)) {
                $w = People::waiting($pdo, $uid);
                if ($w['requests']) $n[] = [$w['requests'], $w['requests'] === 1 ? 'person wants to connect' : 'people want to connect', '#addressbook:requests'];
                if ($w['contact_asks']) $n[] = [$w['contact_asks'], 'asked for your contact info', '#addressbook:requests'];
                if ($w['unread']) $n[] = [$w['unread'], $w['unread'] === 1 ? 'unread message' : 'unread messages', '#addressbook:messages'];
                if (!empty($w['message_requests'])) $n[] = [$w['message_requests'], $w['message_requests'] === 1 ? 'message request' : 'message requests', '#addressbook:messages'];
            }
            if (is_file(__DIR__ . '/Market.php')) {   // the Marketplace's 30-day check (decisions/0135 §8)
                require_once __DIR__ . '/Market.php';
                try { if ($c = Market::asking($pdo, $uid)) $n[] = [$c, $c === 1 ? 'Marketplace post to confirm: still available?' : 'Marketplace posts to confirm: still available?', '#market']; } catch (Throwable) {}
                if (is_file(__DIR__ . '/MarketOffers.php')) {   // offers and trades waiting on you (0135 §4)
                    require_once __DIR__ . '/MarketOffers.php';
                    try { if ($c = MarketOffers::waiting($pdo, $uid)) $n[] = [$c, $c === 1 ? 'Marketplace offer waiting on you' : 'Marketplace offers waiting on you', '#market:offers']; } catch (Throwable) {}
                }
            }
            if (BizMessages::ready($pdo)) {
                try { if ($c = BizMessages::personUnread($pdo, $uid)) $n[] = [$c, $c === 1 ? 'new message from a business' : 'new messages from businesses', '#addressbook:messages']; } catch (Throwable) {}
            }
            if (Links::tableExists($pdo)) {
                if (Links::needsOpenNotice($pdo, $uid)) $n[] = [0, 'Links are now open connections: review who you\'ve linked.', '#links'];
                $st = $pdo->prepare('SELECT COUNT(*) FROM user_links WHERE user_id = ?');
                $st->execute([$uid]);
                if (!(int) $st->fetchColumn()) $n[] = [0, 'Tap the chain icon on any place or listing to link it. Your Pulse is built from what you link.', '#links'];
            }
        } elseif ($ctx['kind'] === 'org' && !empty($ctx['scope']['preview'])) {
            $n = [[3, 'customer messages waiting (sample)', '#business'], [1, 'guest question waiting (sample)', '#business'], [0, 'Add your hours: listings with hours show in "Open now" searches (sample)', '#pulse']];
        } elseif ($ctx['kind'] === 'org') {
            $e = (int) $ctx['scope']['entity'];
            if (is_file(__DIR__ . '/MarketBiz.php')) {   // the Marketplace (decisions/0135 step 3): still on offer? and offers waiting
                require_once __DIR__ . '/MarketBiz.php'; require_once __DIR__ . '/MarketOffers.php';
                try {
                    if ($c = count(MarketBiz::asking($pdo, $e))) $n[] = [$c, $c === 1 ? 'Marketplace item to confirm: still on offer?' : 'Marketplace items to confirm: still on offer?', '/business/' . $e . '/marketplace#still'];
                    if ($c = MarketOffers::waitingEntity($pdo, $e)) $n[] = [$c, $c === 1 ? 'Marketplace offer waiting on you' : 'Marketplace offers waiting on you', '/business/' . $e . '/marketplace#offers'];
                } catch (Throwable) {}
            }
            if (is_file(__DIR__ . '/Domains.php')) {   // its own domain needs it (decisions/0139 step 5b)
                require_once __DIR__ . '/Domains.php';
                try {
                    $dm = Domains::ready($pdo) ? Domains::forEntity($pdo, $e) : null;
                    if ($dm && $dm['status'] === 'failed') $n[] = [0, 'Your domain ' . $dm['domain'] . ' stopped pointing at your storefront. See what to fix.', '/business/' . $e . '/storefront#domain'];
                    elseif ($dm && $dm['status'] === 'added' && strtotime((string) $dm['created_at']) < strtotime('-2 days')) $n[] = [0, 'Finish connecting ' . $dm['domain'] . ': its records aren\'t found yet.', '/business/' . $e . '/storefront#domain'];
                    elseif ($dm && $dm['source'] === 'bought' && str_starts_with((string) $dm['last_error'], 'Renewing')) $n[] = [0, 'Your domain ' . $dm['domain'] . ' couldn\'t renew: check the card on your plan.', '/plans.php?listing=' . $e];
                } catch (Throwable) {}
            }
            if (is_file(__DIR__ . '/MarketCheckout.php')) {   // card checkout stopped (decisions/0135 step 4b): reconnect it
                require_once __DIR__ . '/MarketCheckout.php';
                try {
                    $g = MarketCheckout::ready($pdo) ? MarketCheckout::gateway($pdo, $e) : null;
                    if ($g && $g['status'] === 'broken') $n[] = [0, 'Card payments stopped: reconnect ' . (MarketPay::PROVIDERS[$g['provider']] ?? 'your gateway') . ' in E-commerce setup. Buyers can still pay your other ways.', '/business/' . $e . '/checkout'];
                } catch (Throwable) {}
            }
            if (BizMessages::ready($pdo) && Roles::can($ctx, 'messages')) {
                try {
                    $c = 0; foreach (BizMessages::bizInbox($pdo, $e) as $t) $c += $t['unread'];
                    if ($c) $n[] = [$c, $c === 1 ? 'customer message waiting' : 'customer messages waiting', '#business'];
                } catch (Throwable) {}
                if (is_file(__DIR__ . '/GuestInquiries.php')) {
                    require_once __DIR__ . '/GuestInquiries.php';
                    try { $c = count(array_filter(GuestInquiries::bizList($pdo, $e), fn ($q) => $q['unread'])); if ($c) $n[] = [$c, $c === 1 ? 'guest question waiting' : 'guest questions waiting', '#business']; } catch (Throwable) {}
                }
            }
        } elseif ($ctx['kind'] === 'steward') {
            try {
                $ids = array_map(fn ($g) => (int) $g['id'], $ctx['scope']['groups']);
                if ($ids) {
                    $c = (int) $pdo->query("SELECT COUNT(*) FROM community_group_members WHERE status = 'pending' AND group_id IN (" . implode(',', $ids) . ')')->fetchColumn();
                    if ($c) $n[] = [$c, $c === 1 ? 'person asked to join a community you run' : 'people asked to join communities you run', '#steward'];
                    // reports on posts, for whoever handles them in the group (decisions/0137 §5): reminded while they wait;
                    // after 14 days our team is told as well (Pulse, "Group help")
                    if (is_file(__DIR__ . '/Community.php')) {
                        require_once __DIR__ . '/Community.php';
                        [$rc, $days] = Community::reportsWaiting($pdo, $uid, $ids);
                        if ($rc) $n[] = [$rc, ($rc === 1 ? 'reported post waits' : 'reported posts wait') . ' in your communities' . ($days >= 2 ? ' (' . $days . ' days)' : ''), '#steward'];
                    }
                }
            } catch (Throwable) {}
        } elseif ($ctx['kind'] === 'admin') {
            if ((Roles::can($ctx, 'content') || Roles::can($ctx, 'listings')) && is_file(__DIR__ . '/../ui/admin-crawler.php')) {
                require_once __DIR__ . '/../ui/admin-crawler.php';
                try {   // the crawler's own findings are the review checkers' work: only people's suggestions count here (2026-11-13)
                    $w = tv_crawler_waiting($pdo);
                    if (isset($w['suggestions'])) { require_once __DIR__ . '/Suggestions.php'; $w['suggestions'] = Suggestions::peopleCount($pdo); }
                    if ($c = array_sum($w)) $n[] = [$c, 'crawler items waiting for review', '/admin/crawler-review.php'];
                } catch (Throwable) {}
            }
            if ((Roles::can($ctx, 'content') || Roles::can($ctx, 'listings')) && is_file(__DIR__ . '/Claims.php')) {
                require_once __DIR__ . '/Claims.php';
                try {
                    $k = Claims::counts($pdo);
                    if ($k['held']) $n[] = [$k['held'], $k['held'] === 1 ? 'claim request on hold (Notice)' : 'claim requests on hold (Notice)', '/admin/claims.php#held'];
                    if ($k['claims']) $n[] = [$k['claims'], ($k['claims'] === 1 ? 'claim to confirm' : 'claims to confirm') . ($k['overdue'] ? ' (' . $k['overdue'] . ' past 48 hours)' : ''), '/admin/claims.php#claims'];
                    if ($k['disputes']) $n[] = [$k['disputes'], $k['disputes'] === 1 ? 'dispute to decide' : 'disputes to decide', '/admin/claims.php#disputes'];
                } catch (Throwable) {}
            }
            if ((Roles::can($ctx, 'people') || Roles::can($ctx, 'reports')) && is_file(__DIR__ . '/Reports.php')) {
                require_once __DIR__ . '/Reports.php';
                try { if ($c = Reports::openCount($pdo)) $n[] = [$c, $c === 1 ? 'community report to review' : 'community reports to review', '/admin/reports.php']; } catch (Throwable) {}
            }
        }
        // a role that needs a confirmed email, held without one (decisions/0062 as amended 2026-11-05): a note
        if (is_file(__DIR__ . '/MemberVerification.php')) {
            require_once __DIR__ . '/MemberVerification.php';
            try {
                if (!MemberVerification::consented($pdo, $uid) && ($held = MemberVerification::rolesHeld($pdo, $uid))) {
                    $n[] = [0, 'Confirm your email to keep being able to ' . implode(', ', array_map(fn ($r) => MemberVerification::ROLES[$r], $held)) . ': open the link we sent you, or send it again from Sign in.', '/login.php'];
                }
            } catch (Throwable) {}
        }
        return $n;
    }

    /** @return list<array{source: string, title: string, body: string, url: string, when: string, unread: bool}> */
    public static function stream(PDO $pdo, int $uid, array $ctx, int $limit = 60): array
    {
        $items = [];
        $add = function (string $src, array $rows) use (&$items) {
            foreach ($rows as $r) $items[] = ['source' => $src, 'title' => (string) ($r['title'] ?? ''), 'body' => (string) ($r['body'] ?? ''), 'url' => (string) ($r['url'] ?? '#'),
                                              'when' => (string) ($r['when'] ?? ''), 'unread' => !empty($r['unread']), 'from' => (string) ($r['from'] ?? ''), 'photos' => array_values((array) ($r['photos'] ?? []))] + (isset($r['post']) ? ['post' => $r['post']] : []);
        };
        if ($ctx['kind'] === 'member') {
            if (People::tableExists($pdo)) {
                try {
                    $add('messages', array_map(fn ($t) => ['title' => $t['with'], 'body' => ($t['mine'] ? 'You: ' : '') . $t['last'], 'url' => '#addressbook:messages',
                                                           'when' => $t['at'], 'unread' => $t['unread'] > 0], array_slice(People::threads($pdo, $uid), 0, 15)));
                } catch (Throwable) {}
            }
            if (BizMessages::ready($pdo)) {
                try {
                    $add('messages', array_map(fn ($t) => ['title' => $t['name'], 'body' => ($t['mine'] ? 'You: ' : '') . $t['last'], 'url' => '#addressbook:messages',
                                                           'when' => $t['at'], 'unread' => $t['unread'] > 0], array_slice(BizMessages::personInbox($pdo, $uid), 0, 15)));
                } catch (Throwable) {}
            }
            if (is_file(__DIR__ . '/MemberPosts.php')) {   // posts (decisions/0153): people's under Community, businesses' under Listings (0055 §5)
                require_once __DIR__ . '/MemberPosts.php';
                try { if (MemberPosts::ready($pdo)) { $pr = MemberPosts::pulseRows($pdo, $uid, 25);
                    $add('community', array_values(array_filter($pr, fn ($r) => empty($r['business'])))); $add('listings', array_values(array_filter($pr, fn ($r) => !empty($r['business'])))); } } catch (Throwable) {}
            }
            if (Links::tableExists($pdo)) {
                foreach (['community', 'discovery', 'listings'] as $tab) {
                    try { $add($tab, Links::feed($pdo, $uid, $tab, 25)); } catch (Throwable) {}
                }
            }
            // notices sent once (decisions/0137 §6): shown here, then marked seen
            if (is_file(__DIR__ . '/Notices.php')) {
                require_once __DIR__ . '/Notices.php';
                try { $add('community', Notices::forUser($pdo, $uid, 30)); Notices::markSeen($pdo, $uid); } catch (Throwable) {}
            }
        } elseif ($ctx['kind'] === 'org' && !empty($ctx['scope']['preview'])) {
            $t = fn (int $h) => date('Y-m-d H:i:s', time() - $h * 3600);   // sample items, FPO
            $add('messages', [['title' => 'Maria B. (sample)', 'body' => 'Are you open Saturday morning?', 'url' => '#business', 'when' => $t(1), 'unread' => true],
                              ['title' => 'Sam T. (sample)', 'body' => 'You: Yes, we can fit you in at 10.', 'url' => '#business', 'when' => $t(20), 'unread' => false],
                              ['title' => 'Lee R. (sample)', 'body' => 'Do you take walk-ins?', 'url' => '#business', 'when' => $t(30), 'unread' => true]]);
            $add('questions', [['title' => 'A guest (sample)', 'body' => 'Is there parking out front?', 'url' => '#business', 'when' => $t(5), 'unread' => true]]);
        } elseif ($ctx['kind'] === 'org' && Roles::can($ctx, 'messages')) {
            $e = (int) $ctx['scope']['entity'];
            if (BizMessages::ready($pdo)) {
                try {
                    $add('messages', array_map(fn ($t) => ['title' => $t['name'], 'body' => ($t['mine'] ? 'You: ' : '') . $t['last'], 'url' => '#business',
                                                           'when' => $t['at'], 'unread' => $t['unread'] > 0], array_slice(BizMessages::bizInbox($pdo, $e), 0, 25)));
                } catch (Throwable) {}
            }
            if (is_file(__DIR__ . '/GuestInquiries.php')) {
                require_once __DIR__ . '/GuestInquiries.php';
                try {
                    $add('questions', array_map(fn ($q) => ['title' => $q['name'] . ' (guest)', 'body' => ($q['mine'] ? 'You: ' : '') . $q['last'], 'url' => '#business',
                                                            'when' => $q['at'], 'unread' => $q['unread']], array_slice(GuestInquiries::bizList($pdo, $e), 0, 25)));
                } catch (Throwable) {}
            }
        } elseif ($ctx['kind'] === 'steward' && is_file(__DIR__ . '/Community.php')) {
            require_once __DIR__ . '/Community.php';
            try { if (Community::ready($pdo)) $add('community', Community::feed($pdo, $uid)); } catch (Throwable) {}
        }
        usort($items, fn ($a, $b) => strcmp($b['when'], $a['when']));
        return self::photos($pdo, array_slice($items, 0, $limit));
    }

    /** A listing's photos (its hero, HeroMedia), up to 9, on the items that point at it: the Pulse shows them when a row opens. */
    private static function photos(PDO $pdo, array $items): array
    {
        if (!is_file(__DIR__ . '/HeroMedia.php')) return $items;
        require_once __DIR__ . '/HeroMedia.php';
        try { if (!HeroMedia::ready($pdo)) return $items; } catch (Throwable) { return $items; }
        $seen = [];
        foreach ($items as &$i) {
            if (!preg_match('#^/listing/view\.php\?id=(\d+)#', $i['url'], $m)) continue;
            $id = (int) $m[1];
            if (!isset($seen[$id])) {
                try { $seen[$id] = array_slice(array_values(array_filter(array_map(fn ($x) => $x['image'] ?? null, HeroMedia::slides($pdo, 'listing', $id)))), 0, 9); }
                catch (Throwable) { $seen[$id] = []; }
            }
            $i['photos'] = $seen[$id];
        }
        return $items;
    }
}
