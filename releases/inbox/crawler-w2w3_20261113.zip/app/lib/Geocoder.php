<?php

declare(strict_types=1);

require_once __DIR__ . '/CrawlerIngest.php';
require_once __DIR__ . '/ListingSafety.php';
require_once __DIR__ . '/PageCache.php';

/**
 * api/lib/Geocoder.php — street addresses turned into map points (decisions/0053, follow-up).
 *
 * Most listings were imported with the middle of their ZIP area as their point (or none), so a town's listings stack
 * on one spot.
 * This sends street addresses to the U.S. Census geocoder (free, no key; its batch service takes up to 10,000 a file)
 * and fills in the point when it finds the address.
 *
 * Rules:
 *   - Only replaces a point that is empty or is exactly its ZIP's middle (APPROX). A point a person set, or one the
 *     crawler read from the site, is never changed.
 *   - Confidential listings (shelters, recovery and the like: ListingSafety) are never geocoded. They show a phone only.
 *   - Rural Arizona: many places have no street address the Census can place. Those aren't dropped, they're sorted so
 *     each gets placed another way (classify()): mailing-only (PO box, HC or rural route, general delivery), a mile
 *     marker ("Hwy 60 MP 342": the highway and milepost are kept for a milepost lookup), or a road with no number
 *     ("Hwy 191", "County Road 3140"). These get their point from the business's own website map (the crawler), from
 *     staff (Edit listing, "Pick on the map"), or from a visitor's pin ("Tell us": drop a pin, or "I'm here now").
 *   - Each try is recorded in entity_metadata 'geocode' ({s: match|exact|nomatch|tie|mailonly|milepost|nonumber|private,
 *     at}). An address
 *     the Census couldn't place is tried again after 90 days, or sooner if the address changes.
 */
final class Geocoder
{
    public const URL = 'https://geocoding.geo.census.gov/geocoder/locations/addressbatch';
    public const KEY = 'geocode';
    public const BATCH = 500;          // per request: small enough for shared hosting's time limit
    private const RETRY_DAYS = 90;
    /** SQL: the listing (alias e) has no point, or only its ZIP area's middle. */
    public const APPROX = "(e.latitude IS NULL OR e.longitude IS NULL OR EXISTS (SELECT 1 FROM zip_coordinates zc WHERE zc.zip = TRIM(e.primary_zip)
                             AND ABS(e.latitude - zc.latitude) < 0.0002 AND ABS(e.longitude - zc.longitude) < 0.0002))";

    /** What's left to do. */
    public static function counts(PDO $pdo, bool $fresh = false): array
    {
        if (!$fresh) return PageCache::remember($pdo, 'geocode:counts', 600, fn () => self::counts($pdo, true));   // ten counts over every listing: kept 10 minutes
        $q = fn (string $sql) => (int) $pdo->query($sql)->fetchColumn();
        $base = "FROM entities e WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0";
        $addr = "EXISTS (SELECT 1 FROM entity_metadata a WHERE a.entity_id = e.id AND a.meta_key = 'address' AND COALESCE(JSON_UNQUOTE(a.meta_value), '') NOT IN ('', 'null'))";
        $tried = fn (string $s) => "EXISTS (SELECT 1 FROM entity_metadata g WHERE g.entity_id = e.id AND g.meta_key = '" . self::KEY . "' AND JSON_UNQUOTE(JSON_EXTRACT(g.meta_value, '$.s')) IN ($s))";
        return [
            'total' => $q("SELECT COUNT(*) $base"),
            'with_point' => $q("SELECT COUNT(*) $base AND NOT " . self::APPROX),   // a point of its own, not the ZIP's middle
            'found' => $q("SELECT COUNT(*) $base AND " . $tried("'match','exact'")),
            'not_found' => $q("SELECT COUNT(*) $base AND " . self::APPROX . " AND " . $tried("'nomatch','tie'")),
            'mailonly' => $q("SELECT COUNT(*) $base AND " . self::APPROX . " AND " . $tried("'mailonly','skipped'")),
            'milepost' => $q("SELECT COUNT(*) $base AND " . self::APPROX . " AND " . $tried("'milepost'")),
            'nonumber' => $q("SELECT COUNT(*) $base AND " . self::APPROX . " AND " . $tried("'nonumber'")),
            'private' => $q("SELECT COUNT(*) $base AND " . self::APPROX . " AND " . $tried("'private'")),
            'no_address' => $q("SELECT COUNT(*) $base AND " . self::APPROX . " AND NOT $addr"),
            'to_do' => count(self::candidates($pdo, 100000, true)),
        ];
    }

    /**
     * Listings to send: no point, a street address, not tried (or not found 90+ days ago, or the address changed since).
     * @return list<array{id: int, name: string, category_id: ?int, address: string, city: string, state: string, zip: string}>
     */
    public static function candidates(PDO $pdo, int $limit, bool $idsOnly = false, ?int $onlyId = null): array
    {
        $since = date('Y-m-d H:i:s', time() - self::RETRY_DAYS * 86400);
        // a listing kept private under the wider rule before decisions/0076 is tried again: placed now unless still private
        $st = $pdo->prepare("SELECT e.id, e.name, e.category_id, e.primary_zip, a.meta_value AS address, c.meta_value AS city, s.meta_value AS state
                               FROM entities e
                               JOIN entity_metadata a ON a.entity_id = e.id AND a.meta_key = 'address'
                          LEFT JOIN entity_metadata c ON c.entity_id = e.id AND c.meta_key = 'city'
                          LEFT JOIN entity_metadata s ON s.entity_id = e.id AND s.meta_key = 'state'
                          LEFT JOIN entity_metadata g ON g.entity_id = e.id AND g.meta_key = '" . self::KEY . "'
                              WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND " . self::APPROX . ($onlyId !== null ? ' AND e.id = ' . (int) $onlyId : '') . "
                                AND (g.id IS NULL OR g.updated_at < a.updated_at
                                     OR (JSON_UNQUOTE(JSON_EXTRACT(g.meta_value, '$.s')) IN ('nomatch', 'tie') AND g.updated_at < ?)
                                     OR (JSON_UNQUOTE(JSON_EXTRACT(g.meta_value, '$.s')) = 'private' AND g.updated_at < '2026-10-11'))
                              ORDER BY e.id LIMIT " . max(1, min(100000, $limit)));
        $st->execute([$since]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $v = fn ($x) => is_string($d = json_decode((string) $x, true)) ? trim($d) : trim((string) $x);
            $addr = $v($r['address']);
            if ($addr === '' || $addr === 'null') { self::mark($pdo, (int) $r['id'], 'nonumber'); continue; }   // marked, so it isn't first in line forever (review §3)
            $out[] = $idsOnly ? ['id' => (int) $r['id']] : ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'category_id' => $r['category_id'] !== null ? (int) $r['category_id'] : null,
                'address' => $addr, 'city' => $v($r['city']), 'state' => $v($r['state']), 'zip' => substr(preg_replace('/\D/', '', (string) $r['primary_zip']), 0, 5)];
        }
        return $out;
    }

    /**
     * What kind of address it is. ['s' => null, 'street' => '123 Main St'] when the Census can try it; otherwise
     * 's' says why not: mailonly, milepost (with 'hwy' and 'mp'), nonumber.
     */
    public static function classify(string $addr): array
    {
        $addr = trim(preg_replace('/\s+/', ' ', $addr));
        if ($addr === '') return ['s' => 'nonumber', 'street' => ''];
        // a mile marker: "Hwy 60 MP 342", "US-60 Milepost 342.5", "Mile Marker 342 State Route 77"
        if (preg_match('/\b(?:mp|mm|mile\s*(?:post|marker)|milepost)\s*#?\s*(\d{1,3}(?:\.\d)?)\b/i', $addr, $m)) {
            $hwy = preg_match('/\b(?:us|u\.s\.|state\s*route|sr|az|hwy|highway|i|interstate|route|rte)[\s-]*(\d{1,3})\b/i', $addr, $h) ? (int) $h[1] : null;
            return ['s' => 'milepost', 'street' => '', 'hwy' => $hwy, 'mp' => (float) $m[1]];
        }
        // mailing only: a box marks a post office, not the place
        if (preg_match('/\b(p\.?\s*o\.?\s*box|post office box|general delivery|hc\s*\d+|h\.c\.\s*\d+|rr\s*\d+|rural route|star route|box \d+)\b/i', $addr)) {
            return ['s' => 'mailonly', 'street' => ''];
        }
        $street = trim(explode(',', $addr)[0]);
        $street = preg_replace('/\s+(suite|ste|unit|#|apt|bldg|building|space|spc|lot)\.?\s*[\w-]*$/i', '', $street);   // the Census wants the building
        // a house number first ("12345 W Hwy 260", "123 County Road 3144"): the Census can try it
        if (preg_match('/^\d+[a-z]?\s+\S/i', $street)) return ['s' => null, 'street' => mb_substr($street, 0, 100)];
        return ['s' => 'nonumber', 'street' => ''];
    }

    /** The street line, or '' when the Census can't try it. */
    public static function street(string $addr): string
    {
        return (string) self::classify($addr)['street'];
    }

    /** One batch: send, read, save. Returns what happened. */
    public static function run(PDO $pdo, int $limit = self::BATCH): array
    {
        $done = ['sent' => 0, 'found' => 0, 'not_found' => 0, 'skipped' => 0, 'private' => 0, 'mailonly' => 0, 'milepost' => 0, 'nonumber' => 0];
        PageCache::forget($pdo, 'geocode:counts');   // a batch changes the counts
        $rows = self::candidates($pdo, max(1, min(self::BATCH, $limit)));
        if (!$rows) return $done + ['left' => 0];
        $send = [];
        foreach ($rows as $r) {
            if (ListingSafety::isConfidential($r['category_id'], $r['name'])) { self::mark($pdo, $r['id'], 'private'); $done['private']++; continue; }
            $k = self::classify($r['address']);
            if ($k['s'] !== null) {   // placed another way (see the class notes); a mile marker keeps its highway and milepost
                self::mark($pdo, $r['id'], $k['s'], '', $k['s'] === 'milepost' ? ['hwy' => $k['hwy'], 'mp' => $k['mp']] : []);
                $done[$k['s']]++; $done['skipped']++; continue;
            }
            if ($r['zip'] === '' && ($r['city'] === '' || $r['state'] === '')) { self::mark($pdo, $r['id'], 'nonumber'); $done['nonumber']++; $done['skipped']++; continue; }
            $send[$r['id']] = [$r['id'], $k['street'], $r['city'], $r['state'], $r['zip']];
        }
        if ($send) {
            $res = self::parse(self::post(self::csv(array_values($send))));
            foreach ($send as $id => $_) {
                $hit = $res[$id] ?? null;
                if ($hit && $hit['lat'] !== null) {
                    $ok = $pdo->prepare('SELECT 1 FROM entities e WHERE e.id = ? AND ' . self::APPROX);   // still empty or the ZIP's middle
                    $ok->execute([$id]);
                    if ($ok->fetchColumn()) { $pdo->prepare('UPDATE entities SET latitude = ?, longitude = ?, updated_at = NOW() WHERE id = ?')->execute([$hit['lat'], $hit['lon'], $id]); self::record($pdo, $id, (float) $hit['lat'], (float) $hit['lon'], 'census'); }
                    self::mark($pdo, $id, $hit['exact'] ? 'exact' : 'match', $hit['matched']);
                    $done['found']++;
                } else {
                    self::mark($pdo, $id, $hit && $hit['tie'] ? 'tie' : 'nomatch');
                    $done['not_found']++;
                }
            }
            $done['sent'] = count($send);
        }
        return $done + ['left' => count(self::candidates($pdo, 100000, true))];
    }

    /** Whether a listing's point is only approximate (none, or its ZIP area's middle). */
    public static function isApprox(PDO $pdo, int $id): bool
    {
        $st = $pdo->prepare('SELECT 1 FROM entities e WHERE e.id = ? AND ' . self::APPROX);
        $st->execute([$id]);
        return (bool) $st->fetchColumn();
    }

    /**
     * One listing, now (decisions/0058 §14): when someone opens a listing whose pin is only approximate, its street
     * address goes to the Census's single-address service and the point is saved, so the pin moves to the street.
     * Tried once (then again after 90 days, or when the address changes), never for confidential listings or
     * addresses the Census can't place (PO boxes, mileposts, roads with no number). Returns ['lat', 'lon', 'exact'] or null.
     */
    public static function locateOne(PDO $pdo, int $id): ?array
    {
        $r = self::candidates($pdo, 1, false, $id)[0] ?? null;
        if (!$r) return null;   // has a real point, no address, or tried recently
        if (ListingSafety::isConfidential($r['category_id'], $r['name'])) { self::mark($pdo, $id, 'private'); return null; }
        $k = self::classify($r['address']);
        if ($k['s'] !== null) { self::mark($pdo, $id, $k['s'], '', $k['s'] === 'milepost' ? ['hwy' => $k['hwy'], 'mp' => $k['mp']] : []); return null; }
        if (!function_exists('curl_init')) return null;
        $url = 'https://geocoding.geo.census.gov/geocoder/locations/address?' . http_build_query(['street' => $k['street'], 'city' => $r['city'], 'state' => $r['state'],
            'zip' => $r['zip'], 'benchmark' => 'Public_AR_Current', 'format' => 'json']);
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4]);
        $body = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($body === false || $code !== 200) return null;   // not marked: tried again next time
        $m = json_decode((string) $body, true)['result']['addressMatches'][0] ?? null;
        if (!$m || !isset($m['coordinates']['x'], $m['coordinates']['y'])) { self::mark($pdo, $id, 'nomatch'); return null; }
        $lat = round((float) $m['coordinates']['y'], 7); $lon = round((float) $m['coordinates']['x'], 7);
        if ($lat < 17 || $lat > 72 || $lon < -180 || $lon > -60) { self::mark($pdo, $id, 'nomatch'); return null; }
        if (self::isApprox($pdo, $id)) { $pdo->prepare('UPDATE entities SET latitude = ?, longitude = ?, updated_at = NOW() WHERE id = ?')->execute([$lat, $lon, $id]); self::record($pdo, $id, $lat, $lon, 'census'); }
        self::mark($pdo, $id, 'match', mb_substr((string) ($m['matchedAddress'] ?? ''), 0, 200));
        return ['lat' => $lat, 'lon' => $lon, 'matched' => (string) ($m['matchedAddress'] ?? '')];
    }

    private static function mark(PDO $pdo, int $id, string $s, string $matched = '', array $more = []): void
    {
        CrawlerIngest::upsertMetadataKey($pdo, $id, self::KEY, array_filter(['s' => $s, 'at' => date('c'), 'matched' => $matched] + $more, fn ($v) => $v !== '' && $v !== null));
    }

    /**
     * A point from somewhere other than the Census (the business's website map, staff, a visitor's pin), set when the
     * listing has none or only its ZIP's middle. $source: site | staff | owner | visitor. Staff and the listing's owner
     * replace any point (decisions/0058 §15); the others only an empty one or a ZIP's middle. Returns whether it was set.
     */
    public static function setPoint(PDO $pdo, int $id, float $lat, float $lon, string $source): bool
    {
        if ($lat < 17 || $lat > 72 || $lon < -180 || $lon > -60) return false;   // not in the U.S.
        $ok = $pdo->prepare('SELECT 1 FROM entities e WHERE e.id = ? AND ' . self::APPROX);
        $ok->execute([$id]);
        if (!in_array($source, ['staff', 'owner'], true) && !$ok->fetchColumn()) return false;   // only staff and the owner replace a point that's already real
        $pdo->prepare('UPDATE entities SET latitude = ?, longitude = ?, updated_at = NOW() WHERE id = ?')->execute([round($lat, 7), round($lon, 7), $id]);
        self::mark($pdo, $id, $source);
        self::record($pdo, $id, $lat, $lon, $source);
        return true;
    }

    /** The point goes into the listing's identity with where it came from (decisions/0133): the Census is public data. */
    private static function record(PDO $pdo, int $id, float $lat, float $lon, string $source): void
    {
        require_once __DIR__ . '/Identity.php';
        $as = ['staff' => 'admin', 'owner' => 'owner', 'visitor' => 'user'][$source] ?? 'ai_crawler';
        $src = ['census' => ['kind' => 'government', 'url' => 'https://geocoding.geo.census.gov/', 'label' => 'U.S. Census geocoder'],
                'site' => ['kind' => 'own_site', 'label' => 'Its own website\'s map']][$source] ?? [];
        Identity::listingWrote($pdo, $id, 'point', ['lat' => round($lat, 6), 'lon' => round($lon, 6)], $as, 0, $src);
    }

    /** The Census batch file: id, street, city, state, zip. */
    public static function csv(array $rows): string
    {
        $f = fopen('php://temp', 'r+');
        foreach ($rows as $r) fputcsv($f, $r, ',', '"', '');
        rewind($f);
        return (string) stream_get_contents($f);
    }

    /**
     * The Census reply: "id","input","Match"|"No_Match"|"Tie","Exact"|"Non_Exact","matched address","lon,lat","tiger id","side"
     * @return array<int, array{lat: ?float, lon: ?float, exact: bool, tie: bool, matched: string}>
     */
    public static function parse(string $raw): array
    {
        $out = [];
        foreach (preg_split('/\r?\n/', trim($raw)) as $line) {
            if ($line === '') continue;
            $c = str_getcsv($line, ',', '"', '');
            $id = (int) ($c[0] ?? 0);
            if (!$id) continue;
            $lat = $lon = null;
            if (($c[2] ?? '') === 'Match' && preg_match('/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/', (string) ($c[5] ?? ''), $m)) {
                [$lon, $lat] = [(float) $m[1], (float) $m[2]];
                if ($lat < 17 || $lat > 72 || $lon < -180 || $lon > -60) $lat = $lon = null;   // not in the U.S.: ignore
            }
            $out[$id] = ['lat' => $lat !== null ? round($lat, 7) : null, 'lon' => $lon !== null ? round($lon, 7) : null, 'exact' => ($c[3] ?? '') === 'Exact',
                         'tie' => ($c[2] ?? '') === 'Tie', 'matched' => mb_substr((string) ($c[4] ?? ''), 0, 200)];
        }
        return $out;
    }

    /** Sends the batch file. Throws RuntimeException with a readable reason. */
    public static function post(string $csv): string
    {
        if (!function_exists('curl_init')) throw new RuntimeException('This server has no curl, so it can\'t reach the Census geocoder.');
        $tmp = tempnam(sys_get_temp_dir(), 'tvgeo');
        file_put_contents($tmp, $csv);
        try {
            $ch = curl_init(self::URL);
            curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 170, CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_POSTFIELDS => ['benchmark' => 'Public_AR_Current', 'addressFile' => new CURLFile($tmp, 'text/csv', 'addresses.csv')]]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err = curl_error($ch);
            curl_close($ch);
        } finally {
            @unlink($tmp);
        }
        if ($body === false || $code !== 200) throw new RuntimeException('The Census geocoder didn\'t answer (HTTP ' . $code . ($err !== '' ? ', ' . $err : '') . '). Try again in a few minutes.');
        if (stripos((string) $body, '<html') !== false) throw new RuntimeException('The Census geocoder sent back a page instead of results. Try again later.');
        return (string) $body;
    }
}
