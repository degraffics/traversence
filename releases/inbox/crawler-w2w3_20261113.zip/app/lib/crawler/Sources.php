<?php

declare(strict_types=1);

/**
 * api/lib/crawler/Sources.php — the list of websites that confirm places for the directory (decisions/0045).
 *
 * Every reference the crawler's second look accepts is recorded here by website, with how many listings it
 * has confirmed. A person then decides what each one is for:
 *   read       worth reading regularly — the worker reads it and follows its links (community and
 *              government directories, chambers, tourism sites);
 *   cite_only  counts as a reference when found, never read in bulk (commercial directories, whose terms
 *              forbid copying; social media; a single place's own website);
 *   ignore     does not count as a reference at all.
 * New websites arrive as "suggested", with a starting kind and status guessed from the address.
 */
final class Sources
{
    public const KINDS = [
        'government' => 'Government', 'community_directory' => 'Community directory', 'chamber' => 'Chamber of commerce',
        'tourism' => 'Tourism', 'registry' => 'Official registry', 'organization' => 'Organization',
        'own_site' => "A place's own website", 'commercial' => 'Commercial directory', 'social' => 'Social media', 'other' => 'Other',
    ];
    public const STATUSES = ['suggested' => 'Waiting for you', 'read' => 'Read regularly', 'cite_only' => 'Cite only', 'ignore' => 'Ignore'];

    /** Commercial directories: their terms forbid automated copying, so they are cited, never read in bulk. */
    private const COMMERCIAL = ['yelp.com', 'mapquest.com', 'yellowpages.com', 'superpages.com', 'bbb.org', 'manta.com',
        'tripadvisor.com', 'foursquare.com', 'nextdoor.com', 'healthgrades.com', 'zocdoc.com', 'vitals.com', 'webmd.com',
        'hotfrog.com', 'chamberofcommerce.com', 'cylex.us.com', 'brownbook.net', 'local.com', 'caring.com',
        'psychologytoday.com', 'sharecare.com', 'usnews.com', 'careacross.com', 'yellowbook.com', 'google.com', 'apple.com'];
    private const SOCIAL = ['facebook.com', 'instagram.com', 'linkedin.com', 'x.com', 'twitter.com', 'tiktok.com', 'youtube.com', 'pinterest.com'];
    private const COMMUNITY = ['findhelp.org', '211.org', 'unitedway.org', 'feedingamerica.org', 'foodpantries.org', 'findatreatment.gov'];
    private const SKIP = ['openstreetmap.org'];

    // ---- The source register's rules (decisions/0133): the licence decides what we may do with what a source says ----

    public const LICENCES = ['public_domain' => 'Public domain', 'odbl' => 'Open (ODbL)', 'cc_by_sa' => 'Open (CC BY-SA)', 'cc_by' => 'Open (CC BY)',
        'cc0' => 'Open (CC0)', 'per_item' => 'Item by item', 'terms' => 'Its terms restrict use', 'unknown' => 'Not known yet'];
    /** What we may do with it, most to least. */
    public const USES = ['facts' => 'Store its facts', 'credit' => 'Show with credit', 'pointer' => 'A pointer only (that it exists, a link)',
        'cite' => 'Cite only (counts as a reference, never read in bulk)', 'evidence' => 'Evidence only (may confirm, never supply)'];

    /**
     * The sources the engine runs on, with their standing rules: host => [name, kind, licence, use, what we take, credit,
     * limits, refresh days, terms page]. A person's entry in source_rules (Sources page) overrides one of these.
     */
    public const STANDING = [
        'openstreetmap.org' => ['OpenStreetMap', 'Map data', 'odbl', 'pointer', 'That a place exists, its map link and its website as a pointer; never its phone, hours or address. Data outside our regions stays in its own tables.', '© OpenStreetMap contributors', 'Overpass: a few queries a minute', 30, 'https://osmfoundation.org/wiki/Licence'],
        'wikipedia.org' => ['Wikipedia', 'Encyclopedia', 'cc_by_sa', 'cite', 'Cited with a link: its articles are never copied or read in bulk, since its share-alike licence would reach our record (Jason, 2026-11-01). Facts come from Wikidata (CC0) and official sources.', '', 'Polite: one request at a time', 180, 'https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use'],
        'wikidata.org' => ['Wikidata', 'Open data', 'cc0', 'facts', 'Facts (population, founding, official website).', '', 'SPARQL: one query at a time', 180, 'https://www.wikidata.org/wiki/Wikidata:Licensing'],
        'commons.wikimedia.org' => ['Wikimedia Commons', 'Photo archive', 'per_item', 'credit', 'Photos licensed CC0, public domain, CC BY or CC BY-SA, each with its credit.', 'Photo: <author>, <licence>, via Wikimedia Commons', 'Polite: one request at a time', 180, 'https://commons.wikimedia.org/wiki/Commons:Licensing'],
        'google.com' => ['Google Places', 'Paid API', 'terms', 'evidence', 'The place ID, the check date and whether it matches; Google verifies and links, it doesn\'t fill in listings.', '', 'GOOGLE_PLACES_MONTHLY (3,000), stops at 90%', 90, 'https://cloud.google.com/maps-platform/terms'],
        'tavily.com' => ['Web search (Tavily)', 'Paid API', 'terms', 'evidence', 'Which pages show a place; the pages themselves are read under their own rules.', '', 'SEARCH_MONTHLY (1,000), stops at 90%', null, 'https://tavily.com/terms'],
        'anthropic.com' => ['Claude (web research)', 'Paid API', 'terms', 'evidence', 'Research and drafts we write from; every name it gives is checked against a real place.', '', 'AI_MONTHLY_CAP_USD and each feature\'s budget', null, 'https://www.anthropic.com/legal/commercial-terms'],
        'irs.gov' => ['IRS exempt organizations', 'Bulk file', 'public_domain', 'evidence', 'Confirms a nonprofit exists; never shown, never creates a listing.', '', 'Monthly file', 30, 'https://www.irs.gov/charities-non-profits/exempt-organizations-business-master-file-extract-eo-bmf'],
        'npiregistry.cms.hhs.gov' => ['NPI Registry (CMS)', 'Registry', 'public_domain', 'facts', 'Health providers\' names, addresses and phones (an official registry).', '', 'Monthly file; the API politely', 30, 'https://npiregistry.cms.hhs.gov/'],
        'recreation.gov' => ['Recreation.gov (RIDB)', 'API', 'public_domain', 'credit', 'Federal recreation areas, campgrounds and facilities.', 'Recreation.gov', 'An API key; 50 requests a minute', 30, 'https://ridb.recreation.gov/docs'],
        'census.gov' => ['U.S. Census (TIGER, AIANNH)', 'Bulk file', 'public_domain', 'facts', 'Boundaries, including tribal nations\' lands.', '', 'Yearly files', 365, 'https://www.census.gov/data/developers/about/terms-of-service.html'],
        'usgs.gov' => ['USGS place names (GNIS)', 'Bulk file', 'public_domain', 'facts', 'Official names of places, landmarks and features.', '', 'Files by state', 365, 'https://www.usgs.gov/information-policies-and-instructions/copyrights-and-credits'],
        'weather.gov' => ['National Weather Service', 'API', 'public_domain', 'credit', 'Forecasts and alerts for a place (its location, never a visitor\'s).', 'National Weather Service', 'Polite, with a contact in the user agent', null, 'https://www.weather.gov/disclaimer'],
        'az511.gov' => ['AZ 511', 'API', 'terms', 'credit', 'Arizona road work and closures (WZDx), shown with a link to check AZ 511.', 'AZ 511', 'Its feed, every 10 minutes', null, 'https://az511.gov/'],
        'loc.gov' => ['Library of Congress', 'Archive', 'per_item', 'credit', 'Coming: historic newspapers, photos, maps and oral histories for history and the Topic index; each item\'s rights statement decides.', 'Library of Congress', 'Its API limits, paced', 365, 'https://www.loc.gov/legal/'],
    ];

    /** A source's rules: a person's entry, else its standing rules, else what its kind suggests. */
    public static function rules(PDO $pdo, string $host, string $kind = ''): array
    {
        $site = self::site(self::host('https://' . $host));
        $std = self::STANDING[$host] ?? self::STANDING[$site] ?? null;
        $r = $std ? ['licence' => $std[2], 'use_rule' => $std[3], 'credit_line' => $std[5], 'limits' => $std[6], 'refresh_days' => $std[7], 'terms_url' => $std[8], 'from' => 'standing']
                  : self::byKind($kind ?: self::classify($host)[0]) + ['credit_line' => '', 'limits' => '', 'refresh_days' => null, 'terms_url' => '', 'from' => 'kind'];
        $r += ['terms_checked_at' => null];
        foreach (self::ruleRows($pdo) as $h => $row) if ($h === $host || $h === $site) { $r = array_merge($r, array_filter($row, fn ($v) => $v !== null && $v !== '')); $r['from'] = 'set'; }
        return $r;
    }

    /** May we keep and show what this source says (not only use it to confirm)? */
    public static function mayStore(PDO $pdo, string $host, string $kind = ''): bool
    {
        return in_array(self::rules($pdo, $host, $kind)['use_rule'], ['facts', 'credit'], true);
    }

    private static function byKind(string $kind): array
    {
        return match ($kind) {
            'commercial' => ['licence' => 'terms', 'use_rule' => 'cite'],
            'social' => ['licence' => 'terms', 'use_rule' => 'evidence'],
            'registry' => ['licence' => 'public_domain', 'use_rule' => 'facts'],
            default => ['licence' => 'unknown', 'use_rule' => 'facts'],   // a place's name, address and phone are facts; never a page's words
        };
    }

    private static ?array $rows = null;
    private static function ruleRows(PDO $pdo): array
    {
        if (self::$rows !== null) return self::$rows;
        try { self::$rows = []; foreach ($pdo->query('SELECT host, licence, use_rule, credit_line, limits, refresh_days, terms_url, terms_checked_at FROM ' . Database::t('source_rules'))->fetchAll(PDO::FETCH_ASSOC) as $r) self::$rows[(string) $r['host']] = $r; }
        catch (Throwable $e) { self::$rows = []; }
        return self::$rows;
    }

    public static function rulesReady(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM ' . Database::t('source_rules') . ' LIMIT 0'); return true; } catch (Throwable $e) { return false; }
    }

    /**
     * A person read a source's terms today and says they allow our rule as it stands: only that is recorded (the date and
     * who), never the rule itself, so a rule that was set before the checks (AZ 511's) is never refused for it.
     */
    public static function markRead(PDO $pdo, string $host, int $uid): void
    {
        $r = self::rules($pdo, $host);
        $pdo->prepare('INSERT INTO ' . Database::t('source_rules') . ' (host, licence, use_rule, credit_line, limits, refresh_days, terms_url, terms_checked_at, checked_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE terms_checked_at = VALUES(terms_checked_at), checked_by = VALUES(checked_by)')
            ->execute([$host, (string) $r['licence'], (string) $r['use_rule'], mb_substr((string) ($r['credit_line'] ?? ''), 0, 255), mb_substr((string) ($r['limits'] ?? ''), 0, 255),
                       !empty($r['refresh_days']) ? (int) $r['refresh_days'] : null, mb_substr((string) ($r['terms_url'] ?? ''), 0, 500), date('Y-m-d'), $uid]);
        self::$rows = null;
    }

    /** A person sets a source's rules (and, ticking it, that they read its terms today). */
    public static function setRules(PDO $pdo, string $host, array $in, int $uid): void
    {
        $host = self::host('https://' . preg_replace('#^https?://#i', '', trim($host)));
        if ($host === '' || !str_contains($host, '.')) throw new InvalidArgumentException('Which website?');
        $lic = (string) ($in['licence'] ?? ''); $use = (string) ($in['use_rule'] ?? '');
        if (!isset(self::LICENCES[$lic])) throw new InvalidArgumentException('Choose its licence.');
        if (!isset(self::USES[$use])) throw new InvalidArgumentException('Choose what we may do with it.');
        if ($lic === 'terms' && in_array($use, ['facts', 'credit'], true)) throw new InvalidArgumentException('Its terms restrict use: it can be a pointer, cited or used as evidence, not stored or shown.');
        $url = trim((string) ($in['terms_url'] ?? ''));
        if ($url !== '' && !preg_match('#^https?://#i', $url)) throw new InvalidArgumentException('The terms page should be a web address.');
        $days = (int) ($in['refresh_days'] ?? 0);
        $pdo->prepare('INSERT INTO ' . Database::t('source_rules') . ' (host, licence, use_rule, credit_line, limits, refresh_days, terms_url, terms_checked_at, checked_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE licence = VALUES(licence), use_rule = VALUES(use_rule), credit_line = VALUES(credit_line), limits = VALUES(limits), refresh_days = VALUES(refresh_days),
                                               terms_url = VALUES(terms_url), terms_checked_at = COALESCE(VALUES(terms_checked_at), terms_checked_at), checked_by = COALESCE(VALUES(checked_by), checked_by)')
            ->execute([$host, $lic, $use, mb_substr(trim((string) ($in['credit_line'] ?? '')), 0, 255), mb_substr(trim((string) ($in['limits'] ?? '')), 0, 255), $days > 0 ? min(3650, $days) : null,
                       mb_substr($url, 0, 500), !empty($in['checked']) ? date('Y-m-d') : null, !empty($in['checked']) ? $uid : null]);
        self::$rows = null;
        try { require_once __DIR__ . '/../Heritage.php'; Heritage::restamp($pdo, $host); } catch (Throwable $e) { error_log('restamp ' . $host . ': ' . $e->getMessage()); }   // the facts it backs follow the new rules
    }

    public static function tableExists(PDO $pdo): bool
    {
        try {
            $pdo->query('SELECT 1 FROM ' . Database::t('reference_sources') . ' LIMIT 1');
            return true;
        } catch (PDOException) {
            return false;
        }
    }

    public static function host(string $url): string
    {
        return preg_replace('/^www\./', '', strtolower((string) parse_url($url, PHP_URL_HOST)));
    }

    /** The site's registrable part, so pages on sub-domains count as one website (www.x.org, business.x.org). */
    public static function site(string $host): string
    {
        $parts = explode('.', $host);
        $n = (str_ends_with($host, '.us.com') || preg_match('/\.(state|co|ci)\.[a-z]{2}\.us$/', $host)) ? 3 : 2;
        if (str_ends_with($host, '.gov') || str_ends_with($host, '.us')) $n = min(count($parts), 3);   // keep a county or state office apart
        return implode('.', array_slice($parts, -$n));
    }

    /** A starting kind and status for a new website, from its address and how the crawler found it. */
    public static function classify(string $host, string $foundAs = '', string $title = ''): array
    {
        $site = self::site($host);
        $in = fn (array $list) => in_array($site, $list, true) || in_array($host, $list, true);
        if ($in(self::SOCIAL)) return ['social', 'cite_only'];
        if ($in(self::COMMERCIAL)) return ['commercial', 'cite_only'];
        if ($foundAs === 'registry') return ['registry', 'cite_only'];     // looked up per listing; bulk loading is its own step
        if ($foundAs === 'own_site') return ['own_site', 'cite_only'];
        if ($in(self::COMMUNITY)) return ['community_directory', 'suggested'];
        if ($foundAs === 'chamber' || str_contains($host, 'chamber') || stripos($title, 'chamber of commerce') !== false) return ['chamber', 'suggested'];
        if ($foundAs === 'government' || preg_match('/\.(gov|us)$/', $host) || str_contains($host, '.gov.')) return ['government', 'suggested'];
        if ($foundAs === 'directory') return ['community_directory', 'suggested'];
        if (preg_match('/(^|\.)(visit|explore|discover)[a-z]|tourism|travel/', $host)) return ['tourism', 'suggested'];
        if (str_ends_with($host, '.org')) return ['organization', 'suggested'];
        return ['other', 'suggested'];
    }

    /** Records one accepted reference: a new website is added, a known one gets another confirmation. */
    public static function note(PDO $pdo, string $url, string $foundAs, string $listingName, string $title = ''): void
    {
        $host = self::host($url);
        // A place's own website confirms only that place, so it isn't a source to list or read.
        if ($host === '' || $foundAs === 'own_site' || in_array(self::site($host), self::SKIP, true) || !self::tableExists($pdo)) return;
        [$kind, $status] = self::classify($host, $foundAs, $title);
        $why = null;
        if ($status === 'suggested' && ($j = self::judgeOf($host, $kind, $title))) { [$status, $kind, $why] = $j; }   // the register decides what it can (decisions/0157 §7)
        $parts = parse_url($url);
        $home = ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? $host) . '/';
        $st = $pdo->prepare('SELECT id FROM ' . Database::t('reference_sources') . ' WHERE host = ?');
        $st->execute([$host]);
        $id = $st->fetchColumn();
        if ($id === false) {
            $pdo->prepare('INSERT INTO ' . Database::t('reference_sources') . ' (host, home_url, kind, status, label, confirmations, last_listing, sample_url, added_by)
                           VALUES (?, ?, ?, ?, ?, 1, ?, ?, \'crawler\')')
                ->execute([$host, mb_substr($home, 0, 500), $kind, $status, mb_substr($title, 0, 190) ?: null, mb_substr($listingName, 0, 255), mb_substr($url, 0, 500)]);
            if ($why !== null) { self::ensureJudge($pdo); try { $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET judged_by = 'crawler', judged_why = ? WHERE host = ?")->execute([mb_substr($why, 0, 255), $host]); } catch (Throwable $e) {} }
        } else {
            $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET confirmations = confirmations + 1, last_listing = ?, last_seen = NOW(),
                                  sample_url = COALESCE(sample_url, ?) WHERE id = ?')
                ->execute([mb_substr($listingName, 0, 255), mb_substr($url, 0, 500), (int) $id]);
        }
    }

    /** Websites a person marked "ignore": the second look doesn't count them as references. */
    public static function ignoredHosts(PDO $pdo): array
    {
        if (!self::tableExists($pdo)) return [];
        return $pdo->query("SELECT host FROM " . Database::t('reference_sources') . " WHERE status = 'ignore'")->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Rebuilds the counts from every crawled listing so far (staged, published or merged): the website
     * each listing's references came from, counted once per listing. Adds websites not yet listed.
     * @return array{sources:int, added:int}
     */
    public static function harvest(PDO $pdo): array
    {
        $count = [];
        $meta = [];
        $st = $pdo->query("SELECT raw_payload FROM " . Database::t('crawler_raw_index') . " WHERE payload_type = 'listing'");
        while (($raw = $st->fetchColumn()) !== false) {
            $c = json_decode((string) $raw, true);
            if (!is_array($c)) continue;
            $seen = [];
            foreach ((array) ($c['corroboration'] ?? []) as $u) {
                $url = is_array($u) ? (string) ($u['url'] ?? '') : (string) $u;
                $host = self::host($url);
                $kind = is_array($u) ? (string) ($u['kind'] ?? '') : 'own_site';   // older rows: the place's homepage
                if ($host === '' || $kind === 'own_site' || isset($seen[$host]) || in_array(self::site($host), self::SKIP, true)) continue;
                $seen[$host] = true;
                $count[$host] = ($count[$host] ?? 0) + 1;
                $meta[$host] = [$url, $kind, (string) ($c['name'] ?? ''),
                                is_array($u) ? (string) ($u['label'] ?? '') : ''];
            }
        }
        $added = 0;
        foreach ($count as $host => $n) {
            $st = $pdo->prepare('SELECT id FROM ' . Database::t('reference_sources') . ' WHERE host = ?');
            $st->execute([$host]);
            if ($st->fetchColumn() === false) {
                self::note($pdo, $meta[$host][0], $meta[$host][1], $meta[$host][2], $meta[$host][3]);
                $added++;
            }
            $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET confirmations = ? WHERE host = ?')->execute([$n, $host]);
        }
        return ['sources' => count($count), 'added' => $added];
    }

    /** Every website, waiting-for-you first, then by how much it has confirmed. */
    public static function all(PDO $pdo, string $status = ''): array
    {
        $sql = 'SELECT * FROM ' . Database::t('reference_sources') . '' . (isset(self::STATUSES[$status]) ? ' WHERE status = :s' : '')
             . " ORDER BY FIELD(status, 'suggested', 'read', 'cite_only', 'ignore'), confirmations DESC, host";
        $st = $pdo->prepare($sql);
        $st->execute(isset(self::STATUSES[$status]) ? ['s' => $status] : []);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function counts(PDO $pdo): array
    {
        $out = array_fill_keys(array_keys(self::STATUSES), 0);
        foreach ($pdo->query('SELECT status, COUNT(*) n FROM ' . Database::t('reference_sources') . ' GROUP BY status')->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $out[$r['status']] = (int) $r['n'];
        }
        return $out;
    }

    public static function update(PDO $pdo, int $id, ?string $status, ?string $kind): void
    {
        if ($status !== null) {
            if (!isset(self::STATUSES[$status])) throw new InvalidArgumentException('Unknown status.');
            $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET status = ? WHERE id = ?')->execute([$status, $id]);
            self::ensureJudge($pdo);   // a person's call: the crawler never changes it (decisions/0157 §7)
            try { $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET judged_by = 'person', judged_why = NULL WHERE id = ?")->execute([$id]); } catch (Throwable $e) {}
        }
        if ($kind !== null) {
            if (!isset(self::KINDS[$kind])) throw new InvalidArgumentException('Unknown kind.');
            $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET kind = ? WHERE id = ?')->execute([$kind, $id]);
        }
    }

    /** A source a person adds by hand (a county services page, a chamber directory): read regularly. */
    public static function add(PDO $pdo, string $url, string $kind, string $label): string
    {
        $url = trim($url);
        if (!preg_match('#^https?://#i', $url)) $url = 'https://' . $url;
        $host = self::host($url);
        if ($host === '' || !str_contains($host, '.')) throw new InvalidArgumentException('That doesn\'t look like a web address.');
        if (!isset(self::KINDS[$kind])) [$kind] = self::classify($host);
        $st = $pdo->prepare('SELECT id FROM ' . Database::t('reference_sources') . ' WHERE host = ?');
        $st->execute([$host]);
        if (($id = $st->fetchColumn()) !== false) {
            $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET status = 'read', kind = ?, home_url = ?, label = COALESCE(NULLIF(?, ''), label) WHERE id = ?")
                ->execute([$kind, mb_substr($url, 0, 500), mb_substr($label, 0, 190), (int) $id]);
            return $host;
        }
        $pdo->prepare("INSERT INTO " . Database::t('reference_sources') . " (host, home_url, kind, status, label, added_by) VALUES (?, ?, ?, 'read', ?, 'admin')")
            ->execute([$host, mb_substr($url, 0, 500), $kind, mb_substr($label, 0, 190) ?: null]);
        self::ensureJudge($pdo);
        try { $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET judged_by = 'person', judged_why = NULL WHERE host = ?")->execute([$host]); } catch (Throwable $e) {}
        return $host;
    }

    // ---- The register decides (decisions/0157 §7, amending 0045) -----------------------------------------------------------

    /** Tribal nations' sites, by address or by what they say they are: always a person's call (decisions/0066). */
    private const NATION_HOST = '/(-nsn\.gov$|tribe|tribal|navajo|hopi|zuni|pueblo|tohono|pascua|yavapai|hualapai|havasupai|wmat\.|apachenation|sancarlos)/i';
    private const NATION_WORDS = '/\b(tribe|tribal|tribes|nation\b(?!al)|pueblo|rancheria|reservation|band of)\b/i';

    /** The columns the register's own calls need, added on first use wherever the table lives. */
    public static function ensureJudge(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        try {
            $t = Database::t('reference_sources');
            if (!$pdo->query("SHOW COLUMNS FROM $t LIKE 'judged_by'")->fetch())
                $pdo->exec("ALTER TABLE $t ADD COLUMN judged_by VARCHAR(12) NULL, ADD COLUMN judged_why VARCHAR(255) NULL, ADD COLUMN about VARCHAR(500) NULL, ADD COLUMN about_at DATETIME NULL");
            // the trust record (decisions/0157 §5): how often what it showed was later borne out, or shown wrong
            if (!$pdo->query("SHOW COLUMNS FROM $t LIKE 'borne_out'")->fetch())
                $pdo->exec("ALTER TABLE $t ADD COLUMN borne_out INT UNSIGNED NOT NULL DEFAULT 0, ADD COLUMN shown_wrong INT UNSIGNED NOT NULL DEFAULT 0");
            // the Common Crawl crawl it was last read from (decisions/0157 §8.3)
            if (!$pdo->query("SHOW COLUMNS FROM $t LIKE 'cc_crawl'")->fetch())
                $pdo->exec("ALTER TABLE $t ADD COLUMN cc_crawl VARCHAR(24) NULL");
        } catch (Throwable $e) { error_log('Sources::ensureJudge: ' . $e->getMessage()); }
    }

    /** Is it a public body by its address? Government, the military, schools, state and local .us offices. */
    private static function publicByAddress(string $host): bool
    {
        return (bool) preg_match('/\.(gov|mil|edu)$|\.[a-z]{2}\.us$/', $host);   // the state and locality .us names (co.apache.az.us, ci.show-low.az.us)
    }

    /**
     * The register's own call on a site waiting for one (decisions/0157 §7): [status, kind, why] or null (it waits). Never for
     * a site a person decided, and never for a tribal nation's (by address or by what it says it is).
     */
    public static function judgeOf(string $host, string $kind, string $about = ''): ?array
    {
        if (preg_match(self::NATION_HOST, $host) || ($about !== '' && preg_match(self::NATION_WORDS, $about))) return null;
        if (in_array($kind, ['commercial', 'social'], true)) return ['cite_only', $kind, 'A commercial directory or social media: its terms forbid copying, so it is cited, never read in bulk.'];
        if (self::publicByAddress($host)) return ['read', $kind === 'other' || $kind === '' ? (str_ends_with($host, '.edu') ? 'organization' : 'government') : $kind, 'A public body by its address (' . $host . '): its facts are public, so it is read regularly.'];
        if ($about !== '') {
            if (preg_match('/\b(GovernmentOrganization|GovernmentOffice)\b|\b(department of|county of|city of|town of|village of|state of|official (web)?site of the|public works|board of supervisors|county government|city government|state agency)\b/i', $about))
                return ['read', 'government', 'It says it is a government office: "' . mb_strimwidth($about, 0, 120, '…') . '"'];
            if (preg_match('/\b(EducationalOrganization|CollegeOrUniversity|school district|community college|university)\b/i', $about))
                return ['read', 'organization', 'It says it is a school or college: "' . mb_strimwidth($about, 0, 120, '…') . '"'];
        }
        return null;   // a chamber, a tourism site, an organization: the second tier reads its terms (with the caps), until then a person
    }

    /**
     * Judges the sites waiting for a call that it can (by address now; by what they say once the worker has read their home
     * page). Returns how many it decided. Cheap: run with the worker's calls.
     */
    public static function sweep(PDO $pdo, int $max = 200): int
    {
        if (!self::tableExists($pdo)) return 0;
        self::ensureJudge($pdo);
        $n = 0;
        try {
            $st = $pdo->query("SELECT id, host, kind, about FROM " . Database::t('reference_sources') . " WHERE status = 'suggested' AND judged_by IS NULL ORDER BY id LIMIT " . (int) $max);
            $up = $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET status = ?, kind = ?, judged_by = 'crawler', judged_why = ? WHERE id = ? AND status = 'suggested' AND judged_by IS NULL");
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $j = self::judgeOf((string) $r['host'], (string) $r['kind'], (string) ($r['about'] ?? ''));
                if (!$j) continue;
                $up->execute([$j[0], isset(self::KINDS[$j[1]]) ? $j[1] : (string) $r['kind'], mb_substr($j[2], 0, 255), (int) $r['id']]);
                $n += $up->rowCount();
            }
        } catch (Throwable $e) { error_log('Sources::sweep: ' . $e->getMessage()); }
        return $n;
    }

    // ---- The trust record (decisions/0157 §5) -------------------------------------------------------------------------------

    /**
     * How much a site's word counts toward the two independent sources (decisions/0044), from its record: a site whose
     * finds were later borne out (published, merged, confirmed) counts more; one often shown wrong (turned down as closed,
     * not real or wrong) less, or not at all. Until it has three outcomes, it counts as any site does. 0 to 1.5.
     */
    public static function trustWeight(PDO $pdo, string $host): float
    {
        static $memo = [];
        $host = self::host('https://' . preg_replace('#^https?://#i', '', $host));
        if (isset($memo[$host])) return $memo[$host];
        $w = 1.0;
        try {
            self::ensureJudge($pdo);
            $st = $pdo->prepare('SELECT borne_out, shown_wrong FROM ' . Database::t('reference_sources') . ' WHERE host = ?'); $st->execute([$host]);
            if ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                $ok = (int) $r['borne_out']; $bad = (int) $r['shown_wrong'];
                if ($ok + $bad >= 3) { $share = $ok / ($ok + $bad); $w = $share >= 0.9 ? 1.5 : ($share >= 0.7 ? 1.0 : ($share >= 0.5 ? 0.5 : 0.0)); }
            }
        } catch (Throwable $e) {}
        return $memo[$host] = $w;
    }

    /** Words in a turned-down find's note that say the source was wrong (not a duplicate or out of scope). */
    private const WRONG = '/\b(closed|out of business|does ?n.?t exist|not real|no such|wrong|incorrect|moved|fake|spam|not a business)\b/i';

    /**
     * Counts what became of the finds decided since the last count (the listings pipeline runs it): each site that showed a
     * published or merged find is borne out once; each that showed one turned down as wrong is shown wrong once. Returns
     * [borne out, shown wrong].
     */
    public static function tallyTrust(PDO $pdo, int $max = 300): array
    {
        if (!self::tableExists($pdo)) return [0, 0];
        self::ensureJudge($pdo);
        $ok = 0; $bad = 0;
        try {
            $T = Database::t('crawler_raw_index');
            // each decided find once: it carries "trust_counted" once counted, whenever it was decided
            $st = $pdo->query("SELECT id, status, source_url, raw_payload, review_note FROM $T
                                WHERE status IN ('published', 'merged', 'rejected') AND raw_payload NOT LIKE '%\"trust_counted\"%' ORDER BY id DESC LIMIT " . (int) $max);
            $up = [1 => $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET borne_out = borne_out + 1 WHERE host = ?'),
                   0 => $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET shown_wrong = shown_wrong + 1 WHERE host = ?')];
            $mark = $pdo->prepare("UPDATE $T SET raw_payload = ? WHERE id = ?");
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $c = json_decode((string) $r['raw_payload'], true);
                if (!is_array($c)) continue;
                $good = $r['status'] !== 'rejected' ? 1 : 0;
                // a duplicate or out of scope isn't the source's fault: only "closed, not real, wrong" counts against it
                if ($good || preg_match(self::WRONG, (string) $r['review_note'])) {
                    $hosts = [self::host((string) $r['source_url'])];
                    foreach ((array) ($c['corroboration'] ?? []) as $u) $hosts[] = self::host(is_array($u) ? (string) ($u['url'] ?? '') : (string) $u);
                    foreach (array_unique(array_filter($hosts)) as $h) { $up[$good]->execute([$h]); if ($up[$good]->rowCount()) { $good ? $ok++ : $bad++; } }
                }
                $c['trust_counted'] = 1;
                $mark->execute([json_encode($c, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), (int) $r['id']]);
            }
        } catch (Throwable $e) { error_log('Sources::tallyTrust: ' . $e->getMessage()); }
        return [$ok, $bad];
    }

    /**
     * Sites the pages we read link to (decisions/0157 §8): each new one goes on the register like any site the crawler
     * meets, its kind guessed from its address and the words of the link, and judged where it can be (public bodies read,
     * commercial and social cited); the rest wait to be described. Only the register: nothing is read until it's "read".
     * $links: [{url, text, from}]. Returns how many were new.
     */
    public static function addLinked(PDO $pdo, array $links, string $fromHost = '', int $max = 40): int
    {
        if (!self::tableExists($pdo)) return 0;
        self::ensureJudge($pdo);
        $T = Database::t('reference_sources');
        $n = 0; $seen = [];
        $has = $pdo->prepare("SELECT 1 FROM $T WHERE host = ?");
        $ins = $pdo->prepare("INSERT INTO $T (host, home_url, kind, status, label, sample_url, added_by) VALUES (?, ?, ?, ?, ?, ?, 'link')");
        $why = $pdo->prepare("UPDATE $T SET judged_by = 'crawler', judged_why = ? WHERE host = ?");
        foreach (array_slice($links, 0, max(1, min(500, $max))) as $l) {
            if (!is_array($l)) continue;
            $url = (string) ($l['url'] ?? '');
            if (!preg_match('#^https?://#i', $url)) continue;
            $host = self::host($url);
            if ($host === '' || !str_contains($host, '.') || isset($seen[$host]) || in_array(self::site($host), self::SKIP, true)) continue;
            $seen[$host] = true;
            try {
                $has->execute([$host]); if ($has->fetchColumn()) continue;
                $text = mb_substr(trim(strip_tags((string) ($l['text'] ?? ''))), 0, 190);
                [$kind, $status] = self::classify($host, '', $text);
                $j = $status === 'suggested' ? self::judgeOf($host, $kind, $text) : null;
                if ($j) [$status, $kind] = [$j[0], $j[1]];
                $p = parse_url($url);
                $ins->execute([$host, ($p['scheme'] ?? 'https') . '://' . ($p['host'] ?? $host) . '/', $kind, $status, $text !== '' ? $text : null, mb_substr($url, 0, 500)]);
                $why->execute([mb_substr(($j ? $j[2] . ' ' : '') . 'Linked from ' . ($fromHost !== '' ? $fromHost : 'a page we read') . '.', 0, 255), $host]);
                if (!$j) $pdo->prepare("UPDATE $T SET judged_by = NULL WHERE host = ?")->execute([$host]);   // still waiting: only noted where it came from
                $n++;
            } catch (Throwable $e) { error_log('Sources::addLinked: ' . $e->getMessage()); }
        }
        return $n;
    }

    /** Sites waiting for a call whose home page the worker hasn't described yet: [[host, home_url]]. */
    public static function toDescribe(PDO $pdo, int $max = 3): array
    {
        if (!self::tableExists($pdo)) return [];
        self::ensureJudge($pdo);
        try {
            // never described first; then, still undecided, one whose home page said nothing after 14 days, and any after 60
            // (review §2: one failed describe, or one while the terms feature was off, left a site waiting for good)
            return $pdo->query("SELECT host, home_url FROM " . Database::t('reference_sources') . " WHERE status = 'suggested' AND judged_by IS NULL
                                 AND (about_at IS NULL OR (about_at < NOW() - INTERVAL 14 DAY AND COALESCE(about, '') = '') OR about_at < NOW() - INTERVAL 60 DAY)
                                 AND kind NOT IN ('commercial', 'social', 'own_site') ORDER BY about_at IS NOT NULL, about_at, confirmations DESC, id LIMIT " . max(1, min(10, $max)))->fetchAll(PDO::FETCH_NUM);
        } catch (Throwable $e) { return []; }
    }

    /** What a site says it is, from the worker (its title, description, schema.org types): kept, then judged. */
    public static function describe(PDO $pdo, string $host, array $d): void
    {
        self::ensureJudge($pdo);
        $host = self::host('https://' . preg_replace('#^https?://#i', '', trim($host)));
        $about = trim(implode(' · ', array_filter(array_map(fn ($x) => trim(strip_tags(html_entity_decode((string) $x, ENT_QUOTES))),
            [$d['site_name'] ?? '', $d['title'] ?? '', $d['description'] ?? '', implode(' ', array_map('strval', (array) ($d['types'] ?? [])))]))));
        try {
            $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET about = ?, about_at = NOW(), label = COALESCE(label, NULLIF(?, '')) WHERE host = ?")
                ->execute([mb_substr($about, 0, 500), mb_substr(trim((string) ($d['site_name'] ?? $d['title'] ?? '')), 0, 190), $host]);
        } catch (Throwable $e) { error_log('Sources::describe: ' . $e->getMessage()); }
    }
}
