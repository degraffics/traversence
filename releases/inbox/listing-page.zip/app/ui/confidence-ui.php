<?php
// app/ui/confidence-ui.php — a listing's confidence on its card (decisions/0133, "On the card: the ring and How we know").
// The ring sits in the card's actions column at their 30px size: the number inside, the arc filled to the score, its
// colour from the red-orange-gold-green gradient at that score; the label is spoken, so it never rests on colour alone.
// Tapping it opens How we know: the band in words, each piece of evidence with its date, and "Is this right?" Yes / No
// for each detail (Yes counts once a day per device, never who; No opens the correction form a person reviews).
declare(strict_types=1);

require_once __DIR__ . '/../lib/ListingConfidence.php';

/** The colour on the gradient at a score (0 red, 38 orange, 63 gold, 88+ green). */
function tv_confidence_colour(int $score): string
{
    $stops = [[0, [194, 65, 12]], [38, [234, 138, 30]], [63, [201, 154, 6]], [88, [63, 138, 94]]];
    $score = max(0, min(100, $score));
    for ($i = 1; $i < count($stops); $i++) {
        [$x1, $c1] = $stops[$i - 1]; [$x2, $c2] = $stops[$i];
        if ($score <= $x2) { $t = ($score - $x1) / ($x2 - $x1); return sprintf('#%02X%02X%02X', ...array_map(fn ($a, $b) => (int) round($a + ($b - $a) * $t), $c1, $c2)); }
    }
    return '#3F8A5E';
}

/** The ring: a button that opens How we know (#lv-know). */
function tv_confidence_ring(array $c): string
{
    $s = (int) $c['score']; $col = tv_confidence_colour($s);
    $r = 12.5; $len = 2 * M_PI * $r; $fill = $len * $s / 100;
    $say = 'How sure we are: ' . $s . ' out of 100, ' . $c['label'] . '. Show how we know.';
    return '<button type="button" class="lv-ring" data-know-open aria-controls="lv-know" aria-expanded="false" title="' . tv_e($say) . '" aria-label="' . tv_e($say) . '">'
        . '<svg viewBox="0 0 30 30" width="30" height="30" aria-hidden="true"><circle cx="15" cy="15" r="14.5" style="fill:var(--tv-field,#F8F2E6);stroke:var(--tv-line-strong,#9E8B70)" stroke-width="1"/><circle cx="15" cy="15" r="' . $r . '" fill="none" style="stroke:var(--tv-line,#D6C8AA)" stroke-width="2"/>'
        . '<circle cx="15" cy="15" r="' . $r . '" fill="none" stroke="' . $col . '" stroke-width="3" stroke-linecap="round" stroke-dasharray="' . round($fill, 2) . ' ' . round($len, 2) . '" transform="rotate(-90 15 15)"/>'
        . '<text x="15" y="15" text-anchor="middle" dominant-baseline="central" font-size="10" font-weight="600" style="fill:var(--tv-meta,#5E4F3C)" font-family="system-ui,sans-serif">' . $s . '</text></svg></button>';
}

/**
 * How sure we are, in words (B5, Jason 2026-11-22: "the score ring said in words"): the band's colour as a dot, its label,
 * and the button that opens How we know, the ring's own job (decisions/0133). The number is in the panel.
 */
function tv_confidence_words(array $c): string
{
    $say = 'How sure we are: ' . $c['label'] . '. Show how we know.';
    return '<button type="button" class="lv-sure" data-know-open aria-controls="lv-know" aria-expanded="false" aria-label="' . tv_e($say) . '">'
        . '<span class="lv-sure-dot" style="background:' . tv_confidence_colour((int) $c['score']) . '" aria-hidden="true"></span>'
        . '<span>How sure we are: <b>' . tv_e((string) $c['label']) . '</b></span><span class="lv-sure-more" aria-hidden="true">How we know ▾</span></button>';
}

/**
 * How we know, under the card (opened by the ring or the words). $details: [fact => label] the listing shows (phone, address,
 * website, hours), each with Is this right? Yes / No. $suggest: what the correction form opens with.
 */
function tv_confidence_panel(array $c, int $eid, array $details, array $suggest): string
{
    $col = tv_confidence_colour((int) $c['score']);
    $h = '<section class="lv-know tv-bleed" id="lv-know" hidden aria-label="How we know">'
       . '<div class="lv-know-h"><span class="lv-know-dot" style="background:' . $col . '"></span><b>' . tv_e($c['label']) . '</b><span class="lv-know-n">' . (int) $c['score'] . ' of 100</span>'
       . '<button type="button" class="lv-know-x" data-know-close aria-label="Close">×</button></div>'
       . '<p class="lv-know-m">' . tv_e($c['meaning']) . '. ' . ((int) $c['score'] >= 76 ? 'A person stands behind it.' : 'Green needs our team\'s check or the owner\'s claim.') . '</p><ul class="lv-know-l">';
    foreach ($c['lines'] as $l) $h .= '<li' . (str_starts_with((string) $l[0], '⚠') ? ' class="bad"' : '') . '>' . tv_e((string) $l[0]) . ($l[1] !== '' ? ' <small>· ' . tv_e((string) $l[1]) . '</small>' : '') . '</li>';
    $h .= '</ul>';
    if ($details) {
        $h .= '<p class="lv-know-q">Is this right?</p><div class="lv-know-ask">';
        foreach ($details as $fact => $label)
            $h .= '<div class="lv-know-r"><span>' . tv_e($label) . '</span><button type="button" class="lv-know-b" data-know-yes="' . tv_e($fact) . '" data-e="' . $eid . '">Yes</button>'
                . '<button type="button" class="lv-know-b" data-tv-suggest="' . tv_e(json_encode($suggest + ['kind' => 'fix'], JSON_UNESCAPED_UNICODE)) . '">No</button></div>';
        $h .= '</div><p class="lv-know-f">Yes counts once a day from this device, and we never record who. No opens a correction our team reviews.</p>';
    }
    return $h . '</section>';
}

/** The ring's and panel's look and behaviour (once a page). */
function tv_confidence_assets(): string
{
    static $done = false; if ($done) return ''; $done = true;
    return '<style>.lv-sure{display:inline-flex;flex-wrap:wrap;align-items:center;gap:.25rem .45rem;margin-top:.45rem;padding:0;border:0;background:none;color:var(--tv-ink,#3E2B1F);font:inherit;font-size:.82rem;text-align:left;cursor:pointer}'
        . '.lv-sure:hover .lv-sure-more{text-decoration-thickness:2px}.lv-sure-dot{width:.65rem;height:.65rem;border-radius:999px;flex:none}.lv-sure-more{color:var(--tv-link,#92400E);font-weight:600;text-decoration:underline;text-underline-offset:2px}'
        . '.lv-sure[aria-expanded=true] .lv-sure-more{text-decoration:none}.lv-sure:focus-visible{outline:2px solid #F59E0B;outline-offset:2px}'
        . '.lv-ring{display:flex;align-items:center;justify-content:center;width:30px;height:30px;padding:0;border:0;background:none;border-radius:999px;cursor:pointer}'
        . '.lv-ring:focus-visible{outline:2px solid #F59E0B;outline-offset:2px}'
        . '.lv-know{margin:3px 0 0;background:#FFFBF2;border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.7rem .9rem .8rem}'
        . '.lv-know-h{display:flex;align-items:center;gap:.45rem;font-size:1rem;color:#3E2B1F}.lv-know-dot{width:.7rem;height:.7rem;border-radius:999px;flex:none}'
        . '.lv-know-n{color:#8A7355;font-size:.85rem}.lv-know-x{margin-left:auto;width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#5C4632;font-size:1.1rem;line-height:1;cursor:pointer}'
        . '.lv-know-m{margin:.3rem 0 .4rem;font-size:.86rem;color:#5C4632}.lv-know-l{margin:0;padding:0;list-style:none;font-size:.88rem;color:#3E2B1F}'
        . '.lv-know-l li{padding:.3rem 0;border-top:1px solid #EEE3CA}.lv-know-l li::before{content:"✓ ";color:#3F8A5E;font-weight:700}.lv-know-l li.bad::before{content:""}.lv-know-l li.bad{color:#9A3412}'
        . '.lv-know-l small{color:#8A7355}.lv-know-q{margin:.6rem 0 .25rem;font-weight:700;font-size:.9rem;color:#3E2B1F}'
        . '.lv-know-r{display:flex;align-items:center;gap:.4rem;padding:.25rem 0;font-size:.88rem;color:#3E2B1F}.lv-know-r span{flex:1;min-width:0}'
        . '.lv-know-b{min-width:3.2rem;height:30px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#92400E;font-weight:700;font-size:.82rem;cursor:pointer}'
        . '.lv-know-b[aria-pressed=true]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3A2E;box-shadow:0 0 0 3px rgba(143,188,168,.35)}'
        . '.lv-know-f{margin:.45rem 0 0;font-size:.75rem;color:#8A7355}</style>'
        . '<script>(function(){var P=document.getElementById("lv-know");if(!P)return;var R=document.querySelector("[data-know-open]");'
        . 'function show(on){P.hidden=!on;if(R)R.setAttribute("aria-expanded",on?"true":"false");if(on)P.scrollIntoView({block:"nearest",behavior:"smooth"});}if(location.hash==="#lv-know")setTimeout(function(){show(true)},300);'
        . 'var tok=null;function csrf(){if(tok)return tok;tok=fetch("/api/auth/session.php",{credentials:"include"}).then(function(r){return r.json()}).then(function(d){return(d&&d.csrf_token)||""}).catch(function(){return""});return tok;}'
        . 'document.addEventListener("click",function(e){if(e.target.closest("[data-know-open]")){show(P.hidden);return;}if(e.target.closest("[data-know-close]")){show(false);return;}'
        . 'var y=e.target.closest("[data-know-yes]");if(!y)return;var f=y.getAttribute("data-know-yes"),id=y.getAttribute("data-e"),k="tvYes:"+id+":"+f+":"+new Date().toISOString().slice(0,10);'
        . 'var once=false;try{once=!!localStorage.getItem(k)}catch(x){}y.setAttribute("aria-pressed","true");'
        . 'if(once){window.TvAsk&&TvAsk.say("Thank you: we already have your answer for today.",{anchor:y,bad:false});return;}'
        . 'csrf().then(function(t){return fetch("/api/listing-confirm.php",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json","X-CSRF-Token":t},body:JSON.stringify({id:+id,fact:f})})})'
        . '.then(function(r){return r.json()}).then(function(j){try{localStorage.setItem(k,"1")}catch(x){}window.TvAsk&&TvAsk.say(j.ok?(j.message||"Thank you."):((j.error&&j.error.message)||"That didn\'t save."),{anchor:y,bad:!j.ok});})'
        . '.catch(function(){window.TvAsk&&TvAsk.say("That didn\'t reach us. Try again in a moment.",{anchor:y,bad:true});});});})();</script>';
}
