<?php
// app/admin/control-console.php — System Configuration → System Control Board (decisions/0171, release 2b; laid out again
// after Jason's example board, 2026-11-18: "adjust the page layout and presentation of data so I can better use and
// understand our system board"). From the top:
// - a status strip: what's held now, the three core hosts and when the pre-flight last ran;
// - the six stages, and where the system stands;
// - the system's own controls, with a filter and Open all / Close all;
// - two panels: what's holding now (each opens its process) and the four query timings against their limits;
// - each system a card, its processes rows in columns (Process, Where it stands, Last 24 hours). Each row opens under its
//   name to its whole process: Route, Its check, Needs (each source in order, ours first, which works), Last 24 hours
//   (what came in and where every one went), runs, Records touched, and its controls.
// Buttons answer in place (js/admin-control.js); the board draws itself again every 30 seconds while it's open. The data
// is ControlBoard's (app/lib/ControlBoard.php), read from the pre-flight's stored lines and the ledger: nothing is tested
// by opening the page.
declare(strict_types=1);

require_once __DIR__ . '/../lib/ControlBoard.php';
if (!function_exists('tv_w_e')) require_once __DIR__ . '/widgets.php';

function tv_cb_mark(string $light): string
{
    $m = ['ok' => ['#DCFCE7', '#15803D', 'check', 'Working'], 'bad' => ['#FEE2E2', '#B91C1C', 'x', 'Needs a look'], 'warn' => ['#FEF3C7', '#B45309', 'check', 'On a backup or near a limit'],
          'off' => ['#F1EDE6', '#8a7a68', 'dash', 'Switched off'], 'wait' => ['#F1EDE6', '#8a7a68', 'clock', 'Not tested yet'], 'new' => ['#F1EDE6', '#8a7a68', 'clock', 'Not tested yet'], 'na' => ['#F1EDE6', '#8a7a68', 'dash', 'Nothing to do']][$light] ?? ['#F1EDE6', '#8a7a68', 'dash', ''];
    $ic = function_exists('tv_icon') ? tv_icon($m[2], 'cb-svg') : ($light === 'bad' ? '✗' : '✓');
    return '<span class="cb-m" role="img" aria-label="' . tv_w_e($m[3]) . '" title="' . tv_w_e($m[3]) . '" style="background:' . $m[0] . ';color:' . $m[1] . '">' . $ic . '</span>';
}

function tv_cb_record_link(string $kind, int $id): string
{
    $u = $kind === 'listing' ? '/admin/listing-edit.php?id=' . $id : ($kind === 'review' ? '/admin/listing-intake.php?row=' . $id : '');
    $label = ($kind === 'listing' ? 'Listing #' : ($kind === 'review' ? 'Review item #' : ucfirst($kind) . ' #')) . $id;
    return $u !== '' ? '<a href="' . tv_w_e($u) . '" data-peek-frame class="underline">' . tv_w_e($label) . '</a>' : tv_w_e($label);
}

function tv_cb_time(int $at): string
{
    return $at ? '<time datetime="' . gmdate('c', $at) . '" data-tv-time>' . gmdate('M j, H:i', $at) . ' UTC</time>' : 'not run yet';
}

/** One line of a process's detail: a label on the left (above, on a phone), what it says on the right. */
function tv_cb_kv(string $label, string $html): string
{
    return '<div class="cb-kv"><span class="cb-lb">' . tv_w_e($label) . '</span><div class="cb-kd">' . $html . '</div></div>';
}

/** The needs table: each need, its sources in order (ours first), which works, what happens when none does. */
function tv_cb_needs(array $needs, bool $canTest, string $whyTest, callable $btn): string
{
    if (!$needs) return '';
    $words = ['ok' => 'Answered by its first source', 'warn' => 'On a backup', 'bad' => 'Nothing works: holding', 'na' => 'Not set up', 'wait' => 'Waiting', 'new' => 'Not tested yet'];
    $h = '<div class="cb-nt" role="table" aria-label="Needs"><div class="cb-nr cb-nh" role="row"><span role="columnheader">Need</span><span role="columnheader">Sources, ours first → backups</span><span role="columnheader">Where it stands</span><span role="columnheader">If none works</span><span role="columnheader"></span></div>';
    foreach ($needs as $k => [$name, $s, $src, $fallback, $soft, $at]) {
        $chips = [];
        foreach ($src as $i => [$sn, $sw, $works]) {
            $c = $works === null ? 'cb-sq' : ($works ? 'cb-sy' : 'cb-sn');
            $chips[] = '<span class="cb-src ' . $c . '" title="' . tv_w_e($sw) . '">' . ($i + 1) . '. ' . tv_w_e($sn) . ' ' . ($works === null ? '…' : ($works ? '✓' : '✗')) . '</span>';
        }
        $h .= '<div class="cb-nr" role="row" id="cb-nd-' . tv_w_e($k) . '"><span role="cell"><b>' . tv_w_e($name) . '</b></span>'
            . '<span role="cell" class="cb-chain">' . implode('<span class="cb-ar" aria-hidden="true">→</span>', $chips) . '</span>'
            . '<span role="cell" class="cb-ns">' . tv_cb_mark($s) . ' ' . tv_w_e($words[$s] ?? $s) . ($at ? ' <small>(' . tv_cb_time($at) . ')</small>' : '') . '</span>'
            . '<span role="cell"><small>' . tv_w_e(ucfirst($fallback)) . ($soft ? ' (never holds)' : '') . '</small></span>'
            . '<span role="cell">' . $btn('check', 'Test', $canTest, $whyTest, 'nd:' . $k, ['class' => 'ak-b cb-xs']) . '</span></div>';
    }
    return $h . '</div>';
}

function tv_admin_mod_control(PDO $pdo): string
{
    $e = 'tv_w_e';
    [$can, $why] = ControlBoard::can();
    if (!$can) return '<p data-tv-status="info" data-tv-label="Not for your role:">' . $e((string) $why) . '. The System Control Board is for executives: ask one, or write to support@traversence.com.</p>';
    require_once __DIR__ . '/../lib/SystemStart.php';
    require_once __DIR__ . '/../lib/Preflight.php';
    require_once __DIR__ . '/../lib/Staging.php';
    [$canRun, $whyRun] = SystemStart::can();
    [$canPf, $whyPf] = Preflight::can();
    $staging = Staging::here();
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $btn = function (string $act, string $label, bool $ok, string $why, string $id = '', array $attr = []) use ($e): string {
        $cls = $attr['class'] ?? 'ak-b'; unset($attr['class']);
        $a = ''; foreach ($attr as $k => $v) $a .= ' ' . $k . '="' . $e($v) . '"';
        return '<button type="button" class="' . $e($cls) . '" data-cb="' . $e($act) . '"' . ($id !== '' ? ' data-cb-id="' . $e($id) . '"' : '') . ($ok ? $a : ' disabled title="' . $e($why) . '"') . '>' . $e($label) . '</button>';
    };
    ControlBoard::settle($pdo);
    [$stage, $stageWords] = ControlBoard::stage($pdo);
    $wNo = $staging ? 'Nothing runs on staging: these work on the live site.' : $whyRun;

    // every process, read once
    $res = Preflight::results($pdo);
    $by = []; $held = [];
    foreach (ControlRegister::processes($pdo) as $id => $p) {
        $by[$p[0]][$id] = $row = ControlBoard::process($pdo, $id, $p, $res);
        if ($row['light'] === 'bad') $held[$id] = $row;
    }
    $siteNeeds = ControlBoard::needs($res, array_keys(array_filter(Preflight::NEEDS, fn ($n) => $n[0] === 'siteneeds')));
    $core = ControlBoard::core($res);
    $lastAt = 0; foreach ($res as $r) $lastAt = max($lastAt, (int) ($r['at'] ?? 0));
    $pid = fn (string $id) => 'cb-p-' . str_replace(':', '-', $id);

    $h = '<div id="cb" data-csrf="' . $e($csrf) . '">';

    // ---- the status strip: what's held, the core hosts, the last test
    $coreBad = array_filter($core, fn ($c) => $c[1] === 'bad');
    $beacon = $stage === 'shutdown' ? ['off', 'Stopped'] : ($coreBad ? ['bad', 'A core host is down: everything holds'] : ($held ? ['bad', count($held) . ' held: ' . implode(', ', array_slice(array_map(fn ($r) => $r['name'], $held), 0, 3)) . (count($held) > 3 ? ' and ' . (count($held) - 3) . ' more' : '')] : ['ok', 'All clear: nothing held']));
    $h .= '<div class="cb-top cb-strip" role="status"><span class="cb-beacon cb-b-' . $beacon[0] . '">' . tv_cb_mark($beacon[0]) . $e($beacon[1]) . '</span>'
        . '<span class="cb-core"><b>Core hosts</b> ' . implode(' ', array_map(fn ($c) => '<span class="cb-ch">' . tv_cb_mark($c[1]) . $e($c[0]) . '</span>', $core)) . '</span>'
        . '<span class="cb-last">Last tested ' . tv_cb_time($lastAt) . '</span></div>';

    // ---- the six stages, and where the system stands
    $h .= '<div class="cb-stages" role="list" aria-label="Stages">';
    $i = 0;
    foreach (ControlBoard::STAGES as $k => $label) {
        $i++; $soon = in_array($k, ['maintenance', 'history'], true);
        $h .= '<div role="listitem" class="cb-st' . ($k === $stage ? ' on' : '') . ($soon ? ' soon' : '') . '"' . ($k === $stage ? ' aria-current="step"' : '') . ($soon ? ' title="Coming in the board\'s release 4"' : '') . '><small>' . $i . ($soon ? ' · coming' : '') . '</small>' . $e($label) . '</div>';
    }
    $h .= '</div><p class="cb-stage" data-tv-status="' . ($stage === 'observe' ? 'ok' : 'info') . '" data-tv-label="' . $e(ControlBoard::STAGES[$stage]) . ':">' . $e($stageWords) . '</p>';

    // ---- the system's own controls; find, open all, close all
    $h .= '<div class="cb-bar"><div class="cb-acts">'
        . $btn('preflight', 'Run the pre-flight', $canPf && !$staging, $staging ? $wNo : $whyPf)
        . $btn('start', 'Start the system', $canRun && !$staging, $wNo, '', ['data-confirm' => 'Start the system? It confirms each workflow and task, then switches them on in order.', 'data-yes' => 'Start it'])
        . $btn('shutdown', 'Shut down in order', $canRun && !$staging, $wNo, '', ['data-confirm' => 'Shut the whole system down in order? The tasks, then the workflows in reverse order, then the master switch and the crawler\'s schedule. What\'s running finishes.', 'data-yes' => 'Shut it down'])
        . $btn('pauseall', 'Pause everything', $canRun && !$staging, $wNo, '', ['class' => 'ak-b cb-danger', 'data-confirm' => 'Pause everything at once? The emergency stop: the master switch off and the crawler\'s schedule removed.', 'data-yes' => 'Pause everything', 'data-danger' => '1'])
        . '</div><div class="cb-acts cb-find"><input type="search" class="ak-q" data-cb-filter placeholder="Find a process, need or source" aria-label="Find a process, need or source">'
        . '<button type="button" class="ak-b" data-cb-all="1">Open all</button><button type="button" class="ak-b" data-cb-all="0">Close all</button></div></div>';

    // ---- two panels: holding now; the query timings
    $h .= '<div class="cb-panels"><section class="ak-card tv-bleed cb-panel"><h3 class="cb-ph">Holding now <small>' . count($held) . '</small></h3>';
    if (!$held) $h .= '<p data-tv-status="ok" data-tv-label="All clear:">Nothing is held. Every process is working, switched off by choice, or not tested yet.</p>';
    else {
        $h .= '<ul class="cb-hl">';
        foreach (array_slice($held, 0, 8, true) as $id => $r) $h .= '<li>' . tv_cb_mark('bad') . '<span><a href="#' . $e($pid($id)) . '" data-cb-go="' . $e($pid($id)) . '" class="underline">' . $e($r['name']) . '</a> <small>' . $e(ControlRegister::SYSTEMS[$r['sys']] ?? '') . '</small><br><small>' . $e(mb_strlen($r['words']) > 160 ? preg_replace('/\s+\S*$/u', '', mb_substr($r['words'], 0, 160)) . ' …' : $r['words']) . '</small></span></li>';
        $h .= '</ul>' . (count($held) > 8 ? '<p class="ak-note">And ' . (count($held) - 8) . ' more, each marked with a red X below.</p>' : '');
    }
    $h .= '</section><section class="ak-card tv-bleed cb-panel"><h3 class="cb-ph">Query timings <small>the four heaviest, against their limits</small></h3><table class="cb-tt"><thead><tr><th>Query</th><th>Took</th><th><a class="underline" href="/admin/config/thresholds" title="Change a limit on Thresholds">Limit</a></th><th></th></tr></thead><tbody>';
    foreach (ControlBoard::timings($pdo, $res) as $k => [$what, $ms, $lim, $s, $at])
        $h .= '<tr><td>' . $e(preg_replace('/ \(.*$/', '', $what)) . '<br><small>' . $e((string) (preg_match('/\((.*)\)/', $what, $mm) ? $mm[1] : '')) . '</small></td><td class="cb-num">' . ($ms === null ? '—' : number_format($ms) . ' ms') . '</td><td class="cb-num">' . ($lim ? number_format($lim) . ' ms' : '—') . '</td><td>' . tv_cb_mark($ms === null ? 'new' : $s) . '</td></tr>';
    $h .= '</tbody></table><div class="cb-acts">' . $btn('timings', 'Re-test the four', $canPf, (string) $whyPf) . '<small class="ak-note">Read only; a slow one is noted and holds nothing.</small></div></section></div>';

    // ---- the systems, each process a row in columns
    foreach (ControlRegister::SYSTEMS as $sk => $sname) {
        $rows = $by[$sk] ?? [];
        $n = array_count_values(array_column($rows, 'light'));
        $worst = !empty($n['bad']) ? 'bad' : (!empty($n['warn']) ? 'warn' : (!empty($n['ok']) ? 'ok' : 'wait'));
        $sum = [];
        foreach (['ok' => 'working', 'bad' => 'held', 'warn' => 'on a backup', 'off' => 'off', 'wait' => 'not tested'] as $k => $w) if (!empty($n[$k])) $sum[] = $n[$k] . ' ' . $w;
        $h .= '<details class="ak-card tv-bleed cb-sys" id="cb-' . $e($sk) . '" data-cb-sys="' . $e($sk) . '"' . (!empty($n['bad']) ? ' open' : '') . '>'
            . '<summary class="cb-sh"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($worst) . '<h3 class="cb-title">' . $e($sname) . '</h3><small class="cb-sum">' . $e(implode(' · ', $sum)) . '</small></summary>'
            . '<div class="cb-row cb-head" aria-hidden="true"><span></span><span></span><span>Process</span><span>Where it stands</span><span class="cb-r">Last 24 hours</span></div>';
        foreach ($rows as $id => $p) {
            $c = $p['calls'];
            $needs = str_starts_with($id, 'wf:') ? ControlBoard::needs($res, (array) ($p['parts']['needs'] ?? [])) : [];
            $nOk = count(array_filter($needs, fn ($x) => in_array($x[1], ['ok', 'warn'], true)));
            $q = mb_strtolower($p['name'] . ' ' . $p['words'] . ' ' . implode(' ', array_map(fn ($x) => $x[0] . ' ' . implode(' ', array_column($x[2], 0)), $needs)));
            $right = $c['calls'] ? number_format($c['calls']) . ' call' . ($c['calls'] === 1 ? '' : 's') . ' · ' . $c['ms'] . ' ms' : ($p['jobs'][0] + $p['jobs'][1] ? ($p['jobs'][0] + $p['jobs'][1]) . ' job run' . ($p['jobs'][0] + $p['jobs'][1] === 1 ? '' : 's') : '—');
            $h .= '<details class="cb-p" id="' . $e($pid($id)) . '" data-cb-p="' . $e($id) . '" data-q="' . $e($q) . '"' . ($p['light'] === 'bad' ? ' open' : '') . '>'
                . '<summary class="cb-row"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($p['light']) . '<b class="cb-n">' . $e($p['name']) . '</b>'
                . '<span class="cb-c">' . $e($p['words']) . ($needs ? ' <small class="cb-nc">' . $nOk . ' of ' . count($needs) . ' needs answered</small>' : '') . '</span><small class="cb-r">' . $e($right) . '</small></summary>'
                . '<div class="cb-b cb-l-' . $e($p['light']) . '">';
            // Route
            if ($p['route']) $h .= tv_cb_kv('Route', '<code class="cb-route">' . $e((string) $p['route']['said']) . '</code>');
            // Its check
            if ($p['line']) $h .= tv_cb_kv('Its check', tv_cb_mark((string) ($p['line']['s'] ?? 'new')) . ' <small>' . tv_cb_time((int) ($p['line']['at'] ?? 0)) . '</small> ' . $e(mb_strlen((string) ($p['line']['said'] ?? '')) > 600 ? preg_replace('/\s+\S*$/u', '', mb_substr((string) $p['line']['said'], 0, 600)) . ' …' : (string) ($p['line']['said'] ?? '')));
            elseif (!str_starts_with($id, 'wk:') || ControlRegister::WORKERS[substr($id, 3)][3] !== '') $h .= tv_cb_kv('Its check', 'Not run yet: press Run its check.');
            // Needs
            if ($needs) $h .= tv_cb_kv('Needs', tv_cb_needs($needs, $canPf, (string) $whyPf, $btn));
            if (str_starts_with($id, 'svc:') && ($u = ControlBoard::usedBy(substr($id, 4)))) $h .= tv_cb_kv('Used by', $e(implode(', ', $u)) . '.');
            // Last 24 hours: every one accounted for
            if ($c['calls']) {
                $sorted = $c['stored'] + $c['updated'] + $c['review'] + $c['refused']; $rest = $c['received'] - $sorted;
                $h .= tv_cb_kv('Last 24 hours', '<span class="cb-acct">' . number_format($c['calls']) . ' worker call' . ($c['calls'] === 1 ? '' : 's') . ', ' . $c['ms'] . ' ms on average' . ($c['errors'] ? ', <b class="cb-bad">' . $c['errors'] . ' server error' . ($c['errors'] === 1 ? '' : 's') . '</b>' : '') . '.<br>'
                    . 'Received <b>' . number_format($c['received']) . '</b> = stored <b class="cb-good">' . number_format($c['stored']) . '</b> + updated <b>' . number_format($c['updated']) . '</b> + to Review <b>' . number_format($c['review']) . '</b> + refused <b>' . number_format($c['refused']) . '</b>'
                    . ($rest > 0 ? ' + <b>' . number_format($rest) . '</b> with no change recorded' : '') . ($rest >= 0 ? ' <span class="cb-good">✓ every one accounted for</span>' : '') . '</span>');
            }
            if ($p['outcomes']) { $o = []; foreach ($p['outcomes'] as $k => $v) $o[] = $v . ' ' . str_replace('_', ' ', (string) $k); $h .= tv_cb_kv('Crawler task runs', $e(implode(', ', $o)) . '.'); }
            if ($p['jobs'][0] + $p['jobs'][1]) $h .= tv_cb_kv('Site jobs', $p['jobs'][0] . ' ran' . ($p['jobs'][1] ? ', <b class="cb-bad">' . $p['jobs'][1] . ' stopped</b>' : '') . '.');
            // Records touched
            $eps = $p['parts']['endpoints'] ?? [];
            if (str_starts_with($id, 'wk:')) { $k = substr($id, 3); $eps = ControlRegister::WORKERS[$k][2]; foreach (ControlRegister::ENDPOINTS as $ep => [, $for]) if (in_array('@' . $k, $for, true) || ($k === 'crawler' && !array_filter($for, fn ($f) => $f[0] === '@' || $f === 'W0'))) $eps[] = $ep; }
            $recs = ControlBoard::records($pdo, array_values(array_filter($eps, fn ($ep) => !in_array($ep, ['crawl/service', 'crawl/usage'], true))), 12);
            if ($recs) $h .= tv_cb_kv('Records touched', implode(' · ', array_map(fn ($r) => tv_cb_record_link((string) $r[0], (int) $r[1]) . ' <small>(' . $e((string) $r[2]) . ')</small>', $recs)));
            if ($id === 'wk:crawler') {
                $rr = '';
                foreach (ControlBoard::runs($pdo, 5) as [$run, $calls, $rrs]) {
                    $sumc = ['stored' => 0, 'review' => 0, 'updated' => 0, 'refused' => 0]; foreach ($calls as $cl) foreach ($sumc as $k => $_) $sumc[$k] += (int) $cl['n_' . $k];
                    $rr .= '<details class="cb-run"><summary>Run #' . (int) $run['id'] . ' · ' . $e((string) $run['status']) . ' · ' . tv_cb_time((int) strtotime((string) $run['started_at'])) . ' · ' . count($calls) . ' calls: ' . $sumc['stored'] . ' stored, ' . $sumc['updated'] . ' updated, ' . $sumc['review'] . ' to Review, ' . $sumc['refused'] . ' refused</summary>'
                        . ($rrs ? '<p class="ak-note">' . implode(' · ', array_map(fn ($r) => tv_cb_record_link((string) $r['kind'], (int) $r['ref_id']) . ' <small>(' . $e((string) $r['what']) . ')</small>', $rrs)) . '</p>' : '<p class="ak-note">No records touched.</p>') . '</details>';
                }
                if ($rr !== '') $h .= tv_cb_kv('Its last runs', $rr);
            }
            // its controls
            $acts = '';
            if (isset($res[$id]) || str_starts_with($id, 'wf:') || str_starts_with($id, 't:') || str_starts_with($id, 'svc:') || str_starts_with($id, 'site:') || (str_starts_with($id, 'wk:') && ControlRegister::WORKERS[substr($id, 3)][3] !== '')) $acts .= $btn('check', 'Run its check', $canPf, (string) $whyPf, $id);
            if ($p['switch'] === 'on') $acts .= $btn('stop', 'Shut it down', $canRun && !$staging, $wNo, $id, ['data-confirm' => 'Shut ' . $p['name'] . ' down? Its tasks first, then the workflow. What\'s running finishes.', 'data-yes' => 'Shut it down']);
            if ($p['switch'] === 'off') $acts .= $btn('start1', 'Start it', $canRun && !$staging, $wNo, $id);
            if (str_starts_with($id, 'svc:')) $acts .= '<a class="ak-b" href="/admin/config/register#svc-' . $e(substr($id, 4)) . '" data-peek-frame>Its register entry</a>';
            if ($acts !== '') $h .= '<div class="cb-acts">' . $acts . '</div>';
            $h .= '</div></details>';
        }
        // the site: what it needs from outside, each with its sources
        if ($sk === 'site' && $siteNeeds) {
            $sn = array_count_values(array_column($siteNeeds, 1));
            $sl = !empty($sn['bad']) ? 'bad' : (!empty($sn['warn']) ? 'warn' : (!empty($sn['ok']) ? 'ok' : 'wait'));
            $h .= '<details class="cb-p" id="cb-p-site-needs" data-cb-p="site:needs" data-q="' . $e(mb_strtolower('what the site needs ' . implode(' ', array_map(fn ($x) => $x[0] . ' ' . implode(' ', array_column($x[2], 0)), $siteNeeds)))) . '">'
                . '<summary class="cb-row"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($sl) . '<b class="cb-n">What the site needs from outside</b><span class="cb-c">' . count($siteNeeds) . ' needs: ' . (int) ($sn['ok'] ?? 0) . ' answered first, ' . (int) ($sn['warn'] ?? 0) . ' on a backup or their fallback, ' . (int) ($sn['bad'] ?? 0) . ' with nothing working. None of them holds the engine.</span><small class="cb-r">—</small></summary>'
                . '<div class="cb-b cb-l-' . $sl . '">' . tv_cb_kv('Needs', tv_cb_needs($siteNeeds, $canPf, (string) $whyPf, $btn)) . '</div></details>';
        }
        $h .= '</details>';
    }

    // ---- the pre-flight, every line (its own section stays: /admin/config/preflight)
    $h .= '<details class="ak-card tv-bleed" id="preflight" style="margin-top:.6rem"><summary class="cb-sh"><span class="cb-caret" aria-hidden="true">▾</span><span></span><h3 class="cb-title">Pre-flight: every line, as tested last</h3></summary>'
        . '<p class="ak-note">The same lines as <a class="underline" href="/admin/config/preflight">Pre-flight</a>, with its Run all and each line\'s Test.</p>'
        . (function_exists('tv_admin_mod_preflight') ? tv_admin_mod_preflight($pdo) : '') . '</details>';
    $h .= '<div class="cb-none" hidden><p data-tv-status="info" data-tv-label="Nothing found:">No process, need or source has those words. Clear the box to see them all.</p></div></div>';

    $h .= '<style>'
        . '#cb .cb-m{display:inline-flex;width:1.35rem;height:1.35rem;border-radius:.3rem;align-items:center;justify-content:center;flex:0 0 auto;vertical-align:middle}#cb .cb-svg{width:.9rem;height:.9rem;fill:none;stroke:currentColor;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}'
        . '#cb summary{list-style:none;cursor:pointer}#cb summary::-webkit-details-marker{display:none}#cb details:not([open])>summary .cb-caret{display:inline-block;transform:rotate(-90deg)}#cb .cb-caret{color:#8a7a68;font-size:12px}'
        . '#cb .cb-strip{display:flex;flex-wrap:wrap;gap:.4rem .9rem;align-items:center;padding:.45rem .7rem;border:1px solid #E5D9C3;border-radius:.5rem;background:#F6F0E4;font-size:13px}'
        . '#cb .cb-beacon{display:inline-flex;gap:.4rem;align-items:center;font-weight:700;padding:.15rem .55rem .15rem .2rem;border-radius:.4rem}#cb .cb-b-ok{background:#E8F3EC;color:#15803D}#cb .cb-b-bad{background:#FEE2E2;color:#B91C1C}#cb .cb-b-off{background:#F1EDE6;color:#6b5d4f}'
        . '#cb .cb-core{display:inline-flex;gap:.5rem;align-items:center;flex-wrap:wrap}#cb .cb-ch{display:inline-flex;gap:.25rem;align-items:center}#cb .cb-core .cb-m,#cb .cb-beacon .cb-m{width:1.1rem;height:1.1rem}#cb .cb-last{color:#6b5d4f;margin-left:auto}'
        . '#cb .cb-stages{display:grid;grid-template-columns:repeat(6,1fr);gap:.35rem;margin:.6rem 0 .4rem}#cb .cb-st{border:1px solid #E5D9C3;border-radius:.4rem;padding:.4rem .55rem;font-size:13px;background:#FFFBF2}#cb .cb-st small{display:block;color:#8a7a68;font-size:11px}'
        . '#cb .cb-st.on{background:#E8F3EC;border-color:#8FBCA8;box-shadow:0 0 6px #8FBCA8;font-weight:600}#cb .cb-st.soon{opacity:.55}'
        . '#cb .cb-bar{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.4rem;margin:.5rem 0}#cb .cb-acts{display:flex;gap:.35rem;flex-wrap:wrap;align-items:center;margin:.4rem 0}#cb .cb-bar .cb-acts{margin:0}#cb .cb-find .ak-q{width:15rem;max-width:100%}'
        . '#cb .cb-danger{color:#B91C1C;border-color:#E6B8B8}#cb .cb-xs{padding:.15rem .5rem;font-size:12px;min-height:0}'
        . '#cb .cb-panels{display:grid;grid-template-columns:1fr 1fr;gap:.6rem;margin:.4rem 0 .6rem}#cb .cb-panel{padding:.6rem .8rem;margin:0}#cb .cb-ph{font-weight:700;font-size:14px;margin:0 0 .4rem;padding-bottom:.3rem;border-bottom:1px solid #EFE6D6}#cb .cb-ph small{font-weight:400;color:#8a7a68;margin-left:.3rem}'
        . '#cb .cb-hl{list-style:none;margin:0;padding:0;display:grid;gap:.4rem}#cb .cb-hl li{display:flex;gap:.45rem;align-items:flex-start;font-size:13.5px}'
        . '#cb .cb-tt{width:100%;border-collapse:collapse;font-size:13px}#cb .cb-tt th{text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.03em;color:#8a7a68;padding:.2rem .3rem;border-bottom:1px solid #EFE6D6}#cb .cb-tt td{padding:.3rem;border-bottom:1px solid #F3ECE0;vertical-align:top}#cb .cb-tt small{color:#8a7a68}#cb .cb-num{white-space:nowrap;font-variant-numeric:tabular-nums}'
        . '#cb .cb-sys{margin:.0 0 .6rem;padding:0;overflow:hidden}#cb .cb-sh{display:flex;gap:.55rem;align-items:center;padding:.55rem .8rem;background:#F6F0E4}#cb .cb-title{margin:0;font-size:1.05rem;font-weight:700}#cb .cb-sum{margin-left:auto;color:#6b5d4f;text-align:right}'
        . '#cb .cb-row{display:grid;grid-template-columns:.9rem 1.35rem minmax(9rem,17rem) minmax(0,1fr) 8.5rem;gap:.2rem .6rem;align-items:start;padding:.5rem .8rem}#cb .cb-r{text-align:right;color:#6b5d4f;font-variant-numeric:tabular-nums}'
        . '#cb .cb-head{padding:.35rem .8rem;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#8a7a68;border-bottom:1px solid #EFE6D6;background:#FFFBF2}'
        . '#cb .cb-p{border-top:1px solid #EFE6D6}#cb .cb-p:first-of-type{border-top:0}#cb .cb-p>summary:hover{background:#FBF6EC}#cb .cb-c{font-size:13.5px;color:#4a3f35}#cb .cb-nc{color:#6b5d4f;white-space:nowrap}'
        . '#cb .cb-b{margin:0 .8rem .7rem 2.9rem;padding:.2rem 0 .2rem .8rem;border-left:3px solid #8FBCA8;display:grid;gap:.45rem}#cb .cb-l-bad{border-left-color:#E07A7A}#cb .cb-l-warn{border-left-color:#E5B567}#cb .cb-l-off,#cb .cb-l-wait,#cb .cb-l-na{border-left-color:#D6CBB8}'
        . '#cb .cb-kv{display:grid;grid-template-columns:8.5rem minmax(0,1fr);gap:.6rem;font-size:13.5px}#cb .cb-lb{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:#8a7a68;padding-top:.15rem}'
        . '#cb .cb-route{font-size:12.5px;background:#FFFBF2;border:1px solid #EFE6D6;border-radius:.3rem;padding:.15rem .45rem;display:inline-block;white-space:normal}'
        . '#cb .cb-nt{border:1px solid #EFE6D6;border-radius:.4rem;overflow:hidden}#cb .cb-nr{display:grid;grid-template-columns:minmax(8rem,12rem) minmax(0,1.6fr) minmax(9rem,1fr) minmax(7rem,.8fr) auto;gap:.5rem;padding:.35rem .55rem;border-top:1px solid #F3ECE0;align-items:start;font-size:13px}'
        . '#cb .cb-nh{border-top:0;background:#F6F0E4;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.03em;color:#8a7a68}#cb .cb-ns{display:flex;gap:.3rem;align-items:flex-start;flex-wrap:wrap}#cb .cb-ns small,#cb .cb-nr small{color:#6b5d4f}'
        . '#cb .cb-chain{display:flex;flex-wrap:wrap;gap:.25rem;align-items:center}#cb .cb-src{font-size:12px;padding:.05rem .4rem;border-radius:.3rem;border:1px solid}#cb .cb-sy{background:#E8F3EC;border-color:#B6D9C4;color:#14532D}#cb .cb-sn{background:#FEF2F2;border-color:#E6B8B8;color:#7F1D1D}#cb .cb-sq{background:#F6F0E4;border-color:#E5D9C3;color:#6b5d4f}#cb .cb-ar{color:#8a7a68;font-size:12px}'
        . '#cb a{color:#92400E}#cb a.ak-b{color:inherit}#cb .cb-good{color:#15803D}#cb .cb-bad{color:#B91C1C}#cb .cb-acct{font-variant-numeric:tabular-nums}#cb .cb-run>summary{font-size:13px;color:#4a3f35}'
        . '@media (max-width:900px){#cb .cb-panels{grid-template-columns:1fr}#cb .cb-stages{grid-template-columns:repeat(3,1fr)}#cb .cb-nr{grid-template-columns:1fr 1fr}#cb .cb-nh{display:none}#cb .cb-nr>span:nth-child(2){grid-column:1/-1;order:3}#cb .cb-nr>span:nth-child(4){order:4}#cb .cb-nr>span:nth-child(5){order:5;justify-self:end}}'
        . '@media (max-width:767px){#cb .cb-row{grid-template-columns:.9rem 1.35rem minmax(0,1fr);padding:.5rem .6rem}#cb .cb-c,#cb .cb-r{grid-column:3;text-align:left}#cb .cb-head{display:none}#cb .cb-b{margin:0 .5rem .6rem .5rem}#cb .cb-kv{grid-template-columns:1fr;gap:.15rem}#cb .cb-sh{flex-wrap:wrap;padding:.5rem .6rem}#cb .cb-sum{margin-left:0;flex-basis:100%;text-align:left}#cb .cb-last{margin-left:0}#cb .cb-find .ak-q{flex:1 1 100%;width:auto}}'
        . '</style>'
        . '<script src="/js/tv-time.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/tv-time.js') . '" defer></script>'
        . '<script src="/js/admin-control.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/admin-control.js') . '" defer></script>';
    return $h;
}
