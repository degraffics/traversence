/* js/tv-art.js — the Gallery, wherever a file is chosen (Jason, 2026-11-04: "where ever a photo upload or select option
 * is … it routes through the gallery tool"; and the system file pop-ups shouldn't be the first thing people meet).
 * Loaded by tv-upload.js on every page. Any <input type="file"> opens this panel instead of the computer's file dialog:
 *
 *   Your gallery   the person's (or the business's) Gallery, by catalog, photos and documents, as the input takes them:
 *                  pick one or several, each showing where it's been used. Picked items reach the page as files, marked
 *                  (TvArt.itemOf); tv-upload.js then sends do=gallery instead of the bytes, and the server uses the one
 *                  in the Gallery or copies it S3 to S3 into its record (Uploads::gallery), recording the use.
 *   Stock          only where the input says it illustrates (data-art-slot), never on a product, journey, review,
 *                  album, profile, proof or order (decisions/0143). Choosing one is saved by data-stock-post.
 *   Upload new     drag files in, paste a screenshot, or Browse your device (the computer's dialog, only when asked).
 *                  Documents are kept in the Gallery's Documents album first, then handed over marked, so the Gallery
 *                  holds every file and knows where it went.
 *
 * On the input: data-art="off" (the computer's dialog, as before), data-art="upload" (the Upload tab alone),
 * data-art-b="<listing>" (that business's Gallery; else the page's /business/<id>/ or ?b=), data-art-slot="storefront_cover"
 * + data-stock-post, data-stock-action, data-owner (the Stock tab). Every input, orders and documents included, gets
 * Your gallery (Jason, 2026-11-04: "the gallery should handle all access to files and have the intelligence to know how
 * they are used"); the record (an order, a quote) still keeps its own copy. On our team's pages (/admin/) there's no
 * Gallery of anyone's own (Jason, 2026-11-05): the first tab is the record's files (an order's, then its client's earlier
 * orders', data-art-record or the page's order), and new files go to the record only.
 * Busy spinners and the site's notices (TvAsk); never a browser pop-up.
 */
(function () {
  'use strict';
  if (window.TvArt) return;
  var reg = {};   // name|size → gallery item id, for files picked from the Gallery
  var TYPES = { pdf: 'application/pdf', svg: 'image/svg+xml', ai: 'application/postscript', eps: 'application/postscript', psd: 'image/vnd.adobe.photoshop', zip: 'application/zip',
    doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xls: 'application/vnd.ms-excel',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    txt: 'text/plain', csv: 'text/csv', indd: 'application/x-indesign', ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff', woff2: 'font/woff2', tif: 'image/tiff', tiff: 'image/tiff',
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', heic: 'image/heic', mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', mp3: 'audio/mpeg', wav: 'audio/wav' };   // what the Gallery keeps (GalleryModes::FILES)
  function key(f) { return (f.name || '') + '|' + f.size; }
  function itemOf(f) { return f ? (f.__tvArtItem || reg[key(f)] || 0) : 0; }
  var regR = {};   // name|size → a record's file (order_proof:12), on our team's pages
  function recordOf(f) { return f ? (f.__tvArtRecord || regR[key(f)] || '') : ''; }
  // our team's pages: no Gallery of their own; files belong to the record (Jason, 2026-11-05)
  var ADMIN = /^\/admin\//.test(location.pathname);
  function record(inp) {
    var r = inp.getAttribute('data-art-record') || (inp.closest('[data-art-record]') || { getAttribute: function () { return ''; } }).getAttribute('data-art-record');
    if (r) return r;
    var m = location.pathname.match(/^\/admin\/backoffice\/orders\/(\d+)/); if (m) return 'order:' + m[1];
    if (/^\/admin\/client-order\.php$/.test(location.pathname)) { var id = new URLSearchParams(location.search).get('id'); if (id && /^\d+$/.test(id)) return 'order:' + id; }
    return '';
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function busy(el, on) { if (window.TvAsk && TvAsk.busy) TvAsk.busy(el, on); else el.disabled = on; }
  function say(m, el, bad) { if (window.TvAsk && TvAsk.say) TvAsk.say(m, { anchor: el, bad: !!bad }); }
  function json(r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer properly. Try again.' } }; }).then(function (d) { if (!d.ok) { var e = new Error((d.error && d.error.message) || 'That didn\'t work.'); e.status = r.status; throw e; } return d; }); }
  var csrfP = null;
  function csrf() {
    var m = document.querySelector('meta[name="csrf-token"]'); if (m && m.content) return Promise.resolve(m.content);
    return csrfP || (csrfP = fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (d && d.csrf_token) || ''; }));
  }

  /** What an input takes: images only (the Gallery can fill it), or other files too. */
  function imagesOnly(inp) {
    var a = (inp.getAttribute('accept') || '').toLowerCase().split(',').map(function (x) { return x.trim(); }).filter(Boolean);
    if (!a.length) return false;
    return a.every(function (x) { return /^image\//.test(x) || /^\.(jpe?g|png|webp|gif|heic)$/.test(x); });
  }
  function fits(inp, f) {
    var a = (inp.getAttribute('accept') || '').toLowerCase().split(',').map(function (x) { return x.trim(); }).filter(Boolean);
    if (!a.length) return true;
    var n = (f.name || '').toLowerCase(), t = (f.type || '').toLowerCase();
    return a.some(function (x) { return x[0] === '.' ? n.slice(-x.length) === x : (/\/\*$/.test(x) ? t.indexOf(x.slice(0, -1)) === 0 : t === x); });
  }
  function business(inp) {
    var b = inp.getAttribute('data-art-b') || (inp.closest('[data-art-b]') || { getAttribute: function () { return ''; } }).getAttribute('data-art-b');
    if (b) return b;
    var m = location.pathname.match(/^\/business\/(\d+)/); if (m) return m[1];
    var q = new URLSearchParams(location.search).get('b'); return q && /^\d+$/.test(q) ? q : '';
  }

  var css = '.tva-ov{position:fixed;inset:0;z-index:1995;background:rgba(30,19,12,.55);display:flex;align-items:flex-start;justify-content:center;padding:4vh 1rem;overflow-y:auto}'
    + '.tva{background:#FFFBF2;border:1px solid #CBB98D;border-radius:1rem;width:100%;max-width:52rem;box-shadow:0 20px 50px rgba(0,0,0,.35);color:#3E2B1F;font-family:system-ui,sans-serif}'
    + '.tva-hd{display:flex;align-items:center;justify-content:space-between;gap:.5rem;padding:.8rem 1rem;border-bottom:1px solid #E5D7B6}.tva-hd b{font:700 1.1rem Georgia,serif}'
    + '.tva-x{border:0;background:none;font-size:1.5rem;line-height:1;color:#8A7355;cursor:pointer;padding:.2rem .4rem}'
    + '.tva-tabs{display:flex;gap:.3rem;padding:.6rem 1rem 0;border-bottom:1px solid #E5D7B6;flex-wrap:wrap}.tva-tabs button{font-weight:700;font-size:.88rem;border:1.5px solid #CBB98D;border-bottom:0;border-radius:.5rem .5rem 0 0;padding:.45rem .9rem;background:#FFFBF2;color:#5C4632;cursor:pointer}'
    + '.tva-tabs button[aria-selected="true"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}'
    + '.tva-bar{display:flex;flex-wrap:wrap;gap:.4rem;padding:.7rem 1rem;align-items:center}.tva-bar input[type=search]{flex:1 1 12rem;min-width:0;border:1.5px solid #CBB98D;border-radius:999px;padding:.5rem .85rem;font-size:1rem;background:#fff}'
    + '.tva-bar select{border:1.5px solid #CBB98D;border-radius:999px;padding:.45rem .7rem;background:#FFFBF2;color:#5C4632;font-weight:600}'
    + '.tva-b{border:1.5px solid #CBB98D;border-radius:999px;background:#FFFBF2;color:#5C4632;font-weight:700;padding:.45rem .9rem;cursor:pointer;font-size:.9rem}.tva-b.go{background:#92400E;border-color:#92400E;color:#FFFBF2}.tva-b.go:hover{background:#B45309}.tva-b[disabled]{opacity:.55;cursor:default}'
    + '.tva-note{margin:0 1rem .6rem;font-size:.84rem;color:#5C4632}'
    + '.tva-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(9.5rem,1fr));gap:.5rem;padding:0 1rem 1rem;max-height:55vh;overflow-y:auto}'
    + '.tva-i{position:relative;border:2px solid #E5D7B6;border-radius:.6rem;overflow:hidden;background:#fff;cursor:pointer;padding:0;text-align:left;display:flex;flex-direction:column;font:inherit;color:inherit}'
    + '.tva-i img{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;background:#E3D3AC}.tva-i small{display:block;padding:.3rem .45rem;font-size:.72rem;color:#5C4632;line-height:1.3;overflow-wrap:anywhere}'
    + '.tva-i[aria-pressed="true"]{border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.45)}.tva-i .ck{position:absolute;left:.35rem;top:.35rem;width:1.5rem;height:1.5rem;border-radius:50%;border:2px solid #fff;background:rgba(20,13,8,.35);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem}'
    + '.tva-doc{display:flex;align-items:center;justify-content:center;aspect-ratio:1/1;background:#F3EAD3;color:#92400E}.tva-doc b{font:700 1.1rem Georgia,serif;border:2px solid #CBB98D;border-radius:.4rem;padding:.4rem .6rem;background:#FFFBF2}.tva-i small em{display:block;font-style:normal;color:#3F6B58;margin-top:.15rem}.tva-i .ck{color:transparent}.tva-i[aria-pressed="true"] .ck{background:#8FBCA8;border-color:#8FBCA8;color:#fff}'
    + '.tva-drop{margin:1rem;border:2px dashed #CBB98D;border-radius:.9rem;padding:2rem 1rem;text-align:center;color:#5C4632;background:#F7EFDC}.tva-drop.on{border-color:#8FBCA8;background:#EAF3EE}.tva-drop b{display:block;font:700 1.1rem Georgia,serif;color:#3E2B1F;margin-bottom:.3rem}.tva-drop p{margin:.3rem 0 .9rem;font-size:.88rem}'
    + '.tva-ft{display:flex;flex-wrap:wrap;gap:.5rem;justify-content:space-between;align-items:center;border-top:1px solid #E5D7B6;padding:.6rem 1rem;font-size:.8rem;color:#5C4632}'
    + '@media (max-width:767px){.tva-ov{padding:3px}.tva{border-radius:.5rem}.tva-g{grid-template-columns:repeat(3,minmax(0,1fr));gap:3px;padding:0 3px 3px}.tva-i{border-radius:.5rem}.tva-bar,.tva-hd,.tva-ft{padding-left:.6rem;padding-right:.6rem}.tva-tabs{padding:.5rem .6rem 0}.tva-note{margin:0 .6rem .6rem}.tva-drop{margin:.6rem 3px}}';
  function addCss() { if (document.getElementById('tva-css')) return; var s = document.createElement('style'); s.id = 'tva-css'; s.textContent = css; document.head.appendChild(s); }

  /** Hands files to the input as if they'd been chosen there: the page's own code takes it from here. */
  function deliver(inp, files) {
    files = files.filter(function (f) { return fits(inp, f); });
    if (!files.length) return false;
    if (!inp.multiple) files = files.slice(0, 1);
    var dt = new DataTransfer(); files.forEach(function (f) { dt.items.add(f); });
    inp.files = dt.files;
    inp.dispatchEvent(new Event('input', { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function open(inp) {
    addCss();
    var mode = inp.getAttribute('data-art') || '', photos = imagesOnly(inp), rec = ADMIN ? record(inp) : '', mine = mode !== 'upload' && (!ADMIN || !!rec), slot = inp.getAttribute('data-art-slot') || '';
    var tabs = (mine ? [['mine', ADMIN ? 'This order\'s files' : 'Your gallery']] : []).concat(mine && photos && slot ? [['stock', 'Stock']] : []).concat([['upload', 'Upload new']]);
    var b = business(inp), back = document.activeElement, tab = tabs[0][0], picked = {}, items = [];
    function ext(n) { var m = /\.([a-z0-9]+)$/i.exec(n || ''); return m ? m[1].toLowerCase() : ''; }
    var ov = document.createElement('div'); ov.className = 'tva-ov';
    ov.innerHTML = '<div class="tva" role="dialog" aria-modal="true" aria-labelledby="tva-h"><div class="tva-hd"><b id="tva-h">' + (photos ? 'Choose ' + (inp.multiple ? 'photos' : 'a photo') : 'Add ' + (inp.multiple ? 'files' : 'a file')) + '</b><button type="button" class="tva-x" aria-label="Close">×</button></div>'
      + (tabs.length > 1 ? '<div class="tva-tabs" role="tablist">' + tabs.map(function (t) { return '<button type="button" role="tab" data-tab="' + t[0] + '" aria-selected="' + (t[0] === tab) + '">' + t[1] + '</button>'; }).join('') + '</div>' : '')
      + '<div data-body></div></div>';
    document.body.appendChild(ov);
    var body = ov.querySelector('[data-body]'), done = false;
    function close() { if (done) return; done = true; ov.remove(); document.removeEventListener('keydown', keys); document.removeEventListener('paste', paste); if (back && back.focus) try { back.focus(); } catch (x) {} }
    function keys(e) { if (e.key === 'Escape') close(); }
    var upTake = null;
    function paste(e) {   // a screenshot or copied image, straight in
      var fs = [].slice.call((e.clipboardData && e.clipboardData.files) || []); if (!fs.length) return;
      e.preventDefault(); if (upTake) upTake(fs); else if (deliver(inp, fs)) close(); else say('That kind of file can\'t go here.', ov.querySelector('.tva-hd'), true);
    }
    document.addEventListener('keydown', keys); document.addEventListener('paste', paste);
    ov.addEventListener('click', function (e) { if (e.target === ov || e.target.closest('.tva-x')) close(); });
    var tb = ov.querySelector('.tva-tabs');
    if (tb) tb.addEventListener('click', function (e) {
      var t = e.target.closest('[data-tab]'); if (!t) return;
      tab = t.getAttribute('data-tab'); tb.querySelectorAll('[data-tab]').forEach(function (x) { x.setAttribute('aria-selected', x === t ? 'true' : 'false'); }); draw();
    });

    function draw() {
      if (tab === 'upload') return drawUpload();
      var isMine = tab === 'mine';
      body.innerHTML = '<form class="tva-bar" role="search">' + (isMine ? '<select name="cat" aria-label="Catalog"><option value="">All catalogs</option></select>' : '')
        + '<input type="search" name="q" placeholder="' + (isMine ? 'Search your gallery' : 'What should it show? (desert, main street…)') + '" aria-label="Search"><button class="tva-b go">Search</button></form>'
        + '<p class="tva-note" aria-live="polite"></p><div class="tva-g"></div>'
        + '<div class="tva-ft"><span>' + (isMine ? (ADMIN ? 'Files belong to their order. One chosen here is copied into where you\'re adding it.' : photos ? 'Your photos stay in your Gallery; anything you upload goes there too.' : 'Your files stay in your Gallery; the place you add one keeps its own copy, and the Gallery remembers where it went.') : 'Stock photos aren\'t yours: they\'re labelled "Stock photo" with their credit, and your own photo takes over once you add it.') + '</span>'
        + (isMine ? '<button type="button" class="tva-b go" data-use disabled>Use ' + (inp.multiple ? 'selected' : 'this photo') + '</button>' : '') + '</div>';
      var f = body.querySelector('form'), g = body.querySelector('.tva-g'), note = body.querySelector('.tva-note'), use = body.querySelector('[data-use]');
      picked = {};
      function count() { var n = Object.keys(picked).length; if (use) { use.disabled = !n; use.textContent = n > 1 ? 'Use ' + n + ' photos' : (inp.multiple ? 'Use selected' : 'Use this photo'); } }
      function load(btn) {
        busy(btn, true);
        var u = isMine && rec ? '/api/stock.php?record=' + encodeURIComponent(rec) + '&accept=' + encodeURIComponent(inp.getAttribute('accept') || '') + '&q=' + encodeURIComponent(f.q.value.trim()) + '&cat=' + encodeURIComponent(f.cat ? f.cat.value : '')
          : isMine ? '/api/stock.php?mine=1' + (b ? '&b=' + encodeURIComponent(b) : '') + '&accept=' + encodeURIComponent(inp.getAttribute('accept') || '') + '&q=' + encodeURIComponent(f.q.value.trim()) + '&cat=' + encodeURIComponent(f.cat ? f.cat.value : '')
          : '/api/stock.php?slot=' + encodeURIComponent(slot) + '&sources=1&q=' + encodeURIComponent(f.q.value.trim());
        fetch(u, { credentials: 'include' }).then(json).then(function (d) {
          busy(btn, false); items = (d.items || []).concat(d.found || []);
          if (d.notes && d.notes.length && !isMine) d.note = (d.note || '') + ' ' + d.notes.join(' ');
          if (isMine && f.cat && f.cat.options.length === 1) (d.catalogs || []).forEach(function (c) { var o = document.createElement('option'); o.value = c[0]; o.textContent = c[1] + ' (' + c[3] + ')'; f.cat.appendChild(o); });
          note.textContent = d.note || (isMine ? (d.owner || 'Your gallery') + ': ' + items.length + (photos ? ' photo' : ' item') + (items.length === 1 ? '' : 's') + '.' : items.length + ' stock photo' + (items.length === 1 ? '' : 's') + '.');
          g.innerHTML = items.map(function (it, i) {
            return '<button type="button" class="tva-i" data-i="' + i + '" aria-pressed="false" title="' + esc(isMine ? (it.title || it.credit) + (it.used ? ' · ' + it.used : '') : (it.label || 'Stock photo') + ' · ' + it.credit) + '">' + (isMine ? '<span class="ck" aria-hidden="true">✓</span>' : '')
              + (it.kind === 'file' ? '<span class="tva-doc"><b>' + esc(it.ext) + '</b></span>' : '<img src="' + esc(it.card) + '" alt="' + esc(it.title || '') + '" loading="lazy">')
              + '<small>' + (isMine ? esc(it.credit) + (it.used ? '<em>' + esc(it.used) + '</em>' : '') : '<b>' + esc(it.found ? it.source_name : 'Stock photo') + '</b> · ' + esc(it.credit)) + '</small></button>';
          }).join('');
          picked = {}; count();
        }, function (x) {
          busy(btn, false);
          if (isMine && x.status === 401) { tab = 'upload'; if (tb) { var m = tb.querySelector('[data-tab=mine]'); if (m) m.remove(); var s = tb.querySelector('[data-tab=stock]'); if (s) s.remove(); var up = tb.querySelector('[data-tab=upload]'); if (up) up.setAttribute('aria-selected', 'true'); } draw(); return; }   // not signed in: upload only
          note.textContent = ''; say(x.message, btn, true);
        });
      }
      f.addEventListener('submit', function (e) { e.preventDefault(); load(f.querySelector('button')); });
      if (f.cat) f.cat.addEventListener('change', function () { load(f.querySelector('button')); });
      g.addEventListener('click', function (e) {
        var t = e.target.closest('[data-i]'); if (!t) return;
        var it = items[+t.getAttribute('data-i')];
        if (!isMine) return useStock(it, t);
        var on = t.getAttribute('aria-pressed') !== 'true';
        if (!inp.multiple) { g.querySelectorAll('[aria-pressed="true"]').forEach(function (x) { x.setAttribute('aria-pressed', 'false'); }); picked = {}; }
        t.setAttribute('aria-pressed', on ? 'true' : 'false'); if (on) picked[t.getAttribute('data-i')] = it; else delete picked[t.getAttribute('data-i')];
        count();
      });
      if (use) use.addEventListener('click', function () { useMine(Object.keys(picked).map(function (k) { return picked[k]; }), use); });
      load(f.querySelector('button'));
    }

    /** Photos from the Gallery: fetched as files (the page treats them as if just chosen) and marked, so a destination that
     *  keeps its photos in the Gallery uses the one already there. */
    function useMine(list, btn) {
      if (!list.length) return;
      busy(btn, true);
      Promise.all(list.map(function (it) {
        if (it.record && it.kind === 'photo' && it.card) {   // an order's photo: its bytes too, so a page that shows it first (the profile picture's cropper) has the picture; the server still copies the order's own file (_from_record)
          return fetch(it.card, { credentials: 'include' }).then(function (r) { if (!r.ok) throw new Error('A photo couldn\'t be fetched from your order. Try again.'); return r.blob(); }).then(function (bl) {
            var rt = bl.type && /^image\//.test(bl.type) ? bl.type : (TYPES[(it.ext || '').toLowerCase()] || 'image/jpeg');
            var pf = new File([bl], it.name, { type: rt, lastModified: Date.now() });
            try { pf.__tvArtRecord = it.record; } catch (x) {}
            regR[key(pf)] = it.record;
            return pf;
          });
        }
        if (it.record) {   // an order's file: the server copies it from the order (Uploads::gallery, _from_record)
          var rx = (it.ext || '').toLowerCase(), rf = new File([''], it.name, { type: TYPES[rx] || 'application/octet-stream', lastModified: Date.now() });
          try { rf.__tvArtRecord = it.record; } catch (x) {}
          regR[key(rf)] = it.record;
          return rf;
        }
        if (it.kind === 'file') {   // a document: the server copies it from the Gallery (Uploads::gallery), so only its name travels
          var ext = (it.ext || '').toLowerCase(), df = new File([''], it.name, { type: TYPES[ext] || 'application/octet-stream', lastModified: Date.now() });
          try { df.__tvArtItem = it.gallery; } catch (x) {}
          reg[key(df)] = it.gallery;
          return df;
        }
        return fetch(it.url, { credentials: 'include' }).then(function (r) { if (!r.ok) throw new Error('A photo couldn\'t be fetched from your Gallery. Try again.'); return r.blob(); }).then(function (bl) {
          var type = bl.type && /^image\//.test(bl.type) ? bl.type : 'image/jpeg', ext = type === 'image/png' ? 'png' : (type === 'image/webp' ? 'webp' : 'jpg');
          var f = new File([bl], 'gallery-' + it.gallery + '.' + ext, { type: type, lastModified: Date.now() });
          try { f.__tvArtItem = it.gallery; } catch (x) {}
          reg[key(f)] = it.gallery;
          return f;
        });
      })).then(function (files) { busy(btn, false); if (deliver(inp, files)) close(); else say('Those photos can\'t go here.', btn, true); },
        function (x) { busy(btn, false); say(x.message, btn, true); });
    }

    function useStock(it, el) {
      var post = inp.getAttribute('data-stock-post'); if (!post) return;
      busy(el, true);
      var q = (body.querySelector('input[name=q]') || {}).value || '';
      // found at a source (not in the library yet): added to it first (StockLibrary::adopt), then used
      var first = !it.found ? Promise.resolve(it) : csrf().then(function (c) {
        return fetch('/api/stock.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify({ action: 'adopt', slot: slot, source: it.source, id: it.source_id, q: q }) });
      }).then(function (r) { return r.json ? json(r) : r; }).then(function (d) { return d.item || d; });
      first.then(function (got) { it = got; return csrf(); }).then(function (c) {
        var body = { action: inp.getAttribute('data-stock-action') || 'use', slot: slot, owner: inp.getAttribute('data-owner') || '', stock: it.id };
        return fetch(post, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) });
      }).then(json).then(function (d) { busy(el, false); close(); say(d.message || 'Saved.', inp.closest('label') || inp.parentNode); setTimeout(function () { location.reload(); }, 1200); },
        function (x) { busy(el, false); say(x.message, el, true); });
    }

    /** New files from the device. Photos go straight to the page (where they're used puts them in the Gallery); other files
     *  are kept in the Gallery's Documents album first, then handed over marked, so the Gallery has every file and knows
     *  where it went. A file the Gallery can't keep (an unusual kind) goes straight to the page. */
    function take(fs, el) {
      fs = fs.filter(function (f) { return fits(inp, f); });
      if (!fs.length) { say('That kind of file can\'t go here.', el, true); return; }
      if (!inp.multiple) fs = fs.slice(0, 1);
      var keep = !photos && mine && !ADMIN && window.TvUpload ? fs.filter(function (f) { return TYPES[ext(f.name)]; }) : [];   // our team's files go to the record only
      if (!keep.length) { if (deliver(inp, fs)) close(); return; }
      csrf().then(function (c) {
        return fetch('/api/stock.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify({ action: 'docs_album', b: b || 0 }) });
      }).then(json).then(function (d) {
        return TvUpload.send(keep, { target: 'gallery_file', ctx: { album: d.album }, el: el, inside: true }).then(function (res) {
          keep.forEach(function (f, i) { var id = res[i] && +res[i].item; if (id) { try { f.__tvArtItem = id; } catch (x) {} reg[key(f)] = id; } });
          if (deliver(inp, fs)) close();
        });
      }).catch(function (x) { if (x && x.message === 'cancelled') return; say((x && x.message ? x.message + ' ' : '') + 'It goes straight to where you added it instead.', el, true); if (deliver(inp, fs)) close(); });
    }

    function drawUpload() {
      var acc = (inp.getAttribute('accept') || '').split(',').map(function (x) { return x.trim().replace(/^\./, '').replace(/^application\//, '').replace(/^image\/(?!\*)/, ''); }).filter(Boolean).map(function (x) { return x === 'image/*' ? 'photos' : (x === 'video/*' ? 'videos' : x.toUpperCase()); });
      body.innerHTML = '<div class="tva-drop" data-drop><b>Drop ' + (inp.multiple ? 'files' : 'a file') + ' here</b><p>or paste a screenshot (Ctrl+V or ⌘V)' + (acc.length ? '. ' + esc(acc.filter(function (x, i, a) { return a.indexOf(x) === i; }).join(', ')) : '') + '.</p>'
        + '<button type="button" class="tva-b go" data-browse>Browse your device</button></div>'
        + '<div class="tva-ft"><span>' + (ADMIN ? 'It\'s kept with the order, where your team can find it and use it again.' : photos ? 'What you upload is also kept in your Gallery, ready to use again.' : (mine ? 'Kept in your Gallery\'s Documents too, so you can find it and use it again.' : 'Kept in your Gallery.')) + '</span></div>';
      var z = body.querySelector('[data-drop]');
      ['dragenter', 'dragover'].forEach(function (ev) { z.addEventListener(ev, function (e) { e.preventDefault(); z.classList.add('on'); }); });
      ['dragleave', 'drop'].forEach(function (ev) { z.addEventListener(ev, function (e) { e.preventDefault(); z.classList.remove('on'); }); });
      z.addEventListener('drop', function (e) { var fs = [].slice.call((e.dataTransfer && e.dataTransfer.files) || []); if (fs.length) take(fs, z); });
      body.querySelector('[data-browse]').addEventListener('click', function () {   // the computer's own dialog, only because they asked
        var pk = document.createElement('input'); pk.type = 'file'; pk.multiple = inp.multiple; if (inp.accept) pk.accept = inp.accept; pk.setAttribute('data-art', 'off');
        pk.addEventListener('change', function () { var fs = [].slice.call(pk.files || []); if (fs.length) take(fs, z); });
        pk.click();
      });
      upTake = function (fs) { take(fs, z); };
    }
    draw();
  }

  // every file input on the site: the panel instead of the computer's dialog
  document.addEventListener('click', function (e) {
    var inp = e.target;
    if (!inp || inp.tagName !== 'INPUT' || inp.type !== 'file' || inp.disabled) return;
    if (inp.__tvArtPass) { inp.__tvArtPass = false; return; }
    if (inp.getAttribute('data-art') === 'off' || inp.hasAttribute('capture') || inp.closest('.tva')) return;
    if (typeof DataTransfer === 'undefined') return;   // a very old browser: its own dialog
    try { new DataTransfer(); } catch (x) { return; }
    e.preventDefault();
    open(inp);
  }, true);

  window.TvArt = { open: open, itemOf: itemOf, recordOf: recordOf };
})();
