<?php
// user/market/index.php — Your Marketplace, in the member Dashboard (decisions/0031, 0135): Selling (your posts, where
// each stands, and what you can do with it), Buying (what you saved and the sellers you messaged), and Post something.
// Opens in the Dashboard's Marketplace section (#market) and on its own. Selling needs a member who is 18 or older.
// Photos go through the one uploader (decisions/0127, target market_photo) first; then the post is sent with their ids.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../../app/ui/page-shell.php';
require_once __DIR__ . '/../../../app/lib/Market.php';
require_once __DIR__ . '/../../../app/lib/AgeGate.php';
require_once __DIR__ . '/../../../app/lib/MarketOffers.php';
require_once __DIR__ . '/../../../app/ui/market-ui.php';

$uid = Auth::currentUserId();
if ($uid === null) { header('Location: /login.php?next=' . rawurlencode('/user/market/' . (isset($_GET['new']) ? '?new=1' : '')), true, 302); exit; }
$pdo = Database::connection();
$ready = Market::ready($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$edit = $ready && isset($_GET['edit']) ? Market::get($pdo, (int) $_GET['edit']) : null;
if ($edit && ((int) $edit['user_id'] !== $uid || $edit['status'] === 'removed')) $edit = null;
$tab = $edit || isset($_GET['new']) ? 'post' : (in_array((string) ($_GET['tab'] ?? ''), ['buying', 'offers'], true) ? (string) $_GET['tab'] : 'selling');
$offers = MarketOffers::ready($pdo) ? MarketOffers::forUser($pdo, $uid) : ['selling' => [], 'buying' => []];
$waiting = MarketOffers::ready($pdo) ? MarketOffers::waiting($pdo, $uid) : 0;
$mine = $ready ? Market::mine($pdo, $uid) : [];
$openOn = MarketOffers::openCounts($pdo, array_column($mine, 'id'));
$buy = $ready ? Market::buying($pdo, $uid) : ['saved' => [], 'talks' => []];
$cap = $ready ? (int) Market::setting($pdo, 'person_cap') : 5;
$out = $ready ? Market::outCount($pdo, $uid) : 0;
$cats = $ready ? Market::categories($pdo) : [];
$ageOk = AgeGate::confirmed($pdo, $uid);
$e = $edit ?: [];
$eFields = json_decode((string) ($e['fields'] ?? ''), true) ?: [];
$ePhotos = $edit ? Market::photos($pdo, (int) $edit['id']) : [];
$top = tv_embedded() ? ' target="_top"' : '';
$self = '/user/market/' . (tv_embedded() ? '?embed=1' : '');
$q = fn (string $extra) => $self . (str_contains($self, '?') ? '&' : '?') . $extra;

tv_page_start('Your Marketplace', ['section' => 'market', 'active' => $tab === 'post' ? 'sell' : ($tab === 'buying' ? 'saved' : 'selling'), 'no_crumbs' => true]);
echo tv_market_css();
?>
<style>
  .um{max-width:52rem}
  .um h1{font-family:ui-serif,Georgia,serif;font-size:1.7rem;margin:0 0 .25rem;color:#3E2B1F}
  .um-lead{font-size:.9rem;color:#5C4632;line-height:1.5;margin:0 0 .8rem}
  .um-tabs{display:flex;gap:.35rem;flex-wrap:wrap;margin:0 0 .9rem}
  .um-tabs a{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.35rem .85rem;font-size:.86rem;font-weight:600;text-decoration:none}
  .um-tabs a[aria-current="page"]{background:#3E2B1F;border-color:#3E2B1F;color:#FFFBF2}
  .um-card{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;padding:.85rem .95rem;margin-bottom:.8rem}
  .um-card h2{font-family:ui-serif,Georgia,serif;font-size:1.12rem;margin:0 0 .5rem;color:#3E2B1F}
  .um-row{display:flex;gap:.7rem;align-items:flex-start;padding:.65rem 0;border-top:1px solid #EADFC4;flex-wrap:wrap}.um-row:first-of-type{border-top:0}
  .um-th{flex:0 0 64px;width:64px;height:64px;border-radius:.5rem;overflow:hidden;background:#EFE3C8;display:flex;align-items:center;justify-content:center}
  .um-th img{width:100%;height:100%;object-fit:cover}.um-th .ta-svg{color:#B8863B}
  .um-mid{flex:1 1 14rem;min-width:0}
  .um-mid a.nm{color:#92400E;text-decoration:underline;font-weight:700;overflow-wrap:anywhere}
  .um-mid small{display:block;color:#8A7355;font-size:.78rem;margin-top:.12rem}
  .um-st{display:inline-block;font-size:.64rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;border-radius:999px;padding:.12rem .5rem;background:#E8F2EC;color:#2F5D4A;margin-right:.3rem;vertical-align:middle}
  .um-st.held,.um-st.pending,.um-st.paused{background:#FEF3C7;color:#92400E}.um-st.expired,.um-st.sold{background:#EFE3C8;color:#5C4632}.um-st.removed{background:#FEE2E2;color:#991B1B}
  .um-acts{display:flex;flex-wrap:wrap;gap:.3rem;flex:1 1 100%;padding-left:calc(64px + .7rem)}
  .um-b{font:inherit;font-size:.8rem;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .7rem;background:#FFFBF2;color:#3E2B1F;text-decoration:none;cursor:pointer;font-weight:600}
  .um-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFFBF2}.um-b.ask{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}
  .um-f{display:grid;gap:.65rem}.um-f label{display:grid;gap:.2rem;font-size:.78rem;font-weight:700;color:#5C4632}
  .um-f input[type=text],.um-f input[type=number],.um-f input[type=date],.um-f textarea,.um-f select{font:inherit;font-size:.92rem;font-weight:400;border:1px solid #CBB98D;border-radius:.5rem;padding:.45rem .55rem;background:#fff;color:#3E2B1F;width:100%;box-sizing:border-box}
  .um-f small{font-weight:400;color:#8A7355}
  .um-2{display:grid;grid-template-columns:1fr 1fr;gap:.6rem}
  .um-radio{display:flex;flex-wrap:wrap;gap:.3rem .9rem;font-weight:400}.um-radio label{display:flex;align-items:center;gap:.3rem;font-weight:400;font-size:.9rem;color:#3E2B1F}
  .um-ac{position:relative}.um-list{position:absolute;left:0;right:0;top:100%;z-index:20;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;box-shadow:0 10px 20px -12px rgba(0,0,0,.4);max-height:16rem;overflow:auto}
  .um-list button{display:flex;justify-content:space-between;gap:.5rem;width:100%;text-align:left;border:0;border-bottom:1px solid #EADFC4;background:none;padding:.5rem .6rem;font:inherit;font-size:.88rem;cursor:pointer;color:#3E2B1F}.um-list small{color:#8A7355}
  .um-phs{display:flex;flex-wrap:wrap;gap:.4rem}
  .um-ph{position:relative;width:84px;height:84px;border-radius:.5rem;overflow:hidden;background:#EFE3C8;border:1px solid #CBB98D}
  .um-ph img{width:100%;height:100%;object-fit:cover}
  .um-ph button{position:absolute;top:3px;right:3px;width:22px;height:22px;border-radius:999px;border:0;background:rgba(62,43,31,.85);color:#FFFBF2;cursor:pointer;font-size:.9rem;line-height:1}
  .um-ph.first::after{content:"Cover";position:absolute;left:3px;bottom:3px;font-size:.6rem;font-weight:700;background:rgba(62,43,31,.85);color:#FFFBF2;border-radius:.3rem;padding:.05rem .3rem}
  .um-add{width:84px;height:84px;border-radius:.5rem;border:1.5px dashed #B8863B;background:#FFFBF2;color:#B45309;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:.78rem;font-weight:700;text-align:center}
  .um-btn{display:inline-block;border-radius:999px;border:0;background:#3E2B1F;color:#FFFBF2;font-weight:700;padding:.55rem 1.1rem;cursor:pointer;font-size:.9rem;text-decoration:none}
  .um-btn.l{background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D}
  .um-note{font-size:.8rem;color:#5C4632;margin:0}
  @media (max-width:640px){.um-2{grid-template-columns:1fr}.um-acts{padding-left:0}}
</style>
<div class="um">
  <h1>Your Marketplace</h1>
  <p class="um-lead">Sell, give away or offer something near you, and keep track of what you&rsquo;re after. For your posts, no payment passes through Traversence: buyers message you, and you agree the price, payment and pickup together. A business&rsquo;s items can be paid for on the site, straight to the business through its own account.</p>
  <nav class="um-tabs" aria-label="Your Marketplace">
    <a href="<?= tv_e($self) ?>"<?= $tab === 'selling' ? ' aria-current="page"' : '' ?>>Selling (<?= count($mine) ?>)</a>
    <a href="<?= tv_e($q('tab=offers')) ?>"<?= $tab === 'offers' ? ' aria-current="page"' : '' ?>>Offers<?= $waiting ? ' (' . $waiting . ' waiting on you)' : '' ?></a>
    <a href="<?= tv_e($q('tab=buying')) ?>"<?= $tab === 'buying' ? ' aria-current="page"' : '' ?>>Buying</a>
    <a href="<?= tv_e($q('new=1')) ?>"<?= $tab === 'post' && !$edit ? ' aria-current="page"' : '' ?>>Post something</a>
    <a href="/market/"<?= $top ?>>Browse the Marketplace</a>
  </nav>
  <?php if (!$ready): ?><p data-tv-status="info" data-tv-label="Coming:">The Marketplace opens once its database update has run (it runs by itself within the hour).</p><?php else: ?>

  <?php if ($tab === 'selling'): ?>
  <section class="um-card tv-bleed"><h2>Your posts</h2>
    <p class="um-note"><?= $out ?> of <?= $cap ?> out now (showing, pending or waiting for a look). Every <?= (int) Market::setting($pdo, 'check_days') ?> days we ask whether each is still available: confirm with one tap, or it comes off at the next check.</p>
    <?php if (!$mine): ?><p class="um-note" style="margin-top:.6rem">Nothing yet. <a class="underline font-semibold" href="<?= tv_e($q('new=1')) ?>">Post something</a></p><?php endif; ?>
    <?php foreach ($mine as $c): $s = $c['status']; ?>
    <div class="um-row" id="p<?= (int) $c['id'] ?>">
      <span class="um-th"><?= $c['photo'] !== '' ? '<img src="' . tv_e($c['photo']) . '" alt="" loading="lazy">' : tv_icon('store') ?></span>
      <span class="um-mid"><?php if (!empty($c['test'])): ?><span class="um-st held">Test</span><?php endif; ?><span class="um-st <?= tv_e($s) ?>"><?= tv_e($c['status_label']) ?></span><a class="nm" href="<?= tv_e($c['url']) ?>"<?= $top ?>><?= tv_e($c['title']) ?></a>
        <small><?= tv_e($c['price'] . ' · ' . $c['place'] . ' · ' . $c['length']) ?><?= in_array($s, Market::SHOWN, true) && $c['check'] !== '' ? ' · next check ' . tv_e($c['check']) : '' ?></small>
        <?php if ($c['saves'] || $c['talks']): ?><small><?= $c['saves'] ? (int) $c['saves'] . ' saved it' : '' ?><?= $c['saves'] && $c['talks'] ? ' · ' : '' ?><?= $c['talks'] ? (int) $c['talks'] . ' messaged you about it' : '' ?></small><?php endif; ?>
        <?php if (!empty($openOn[$c['id']])): ?><small><a class="underline" href="<?= tv_e($q('tab=offers')) ?>"><?= (int) $openOn[$c['id']] ?> open offer<?= $openOn[$c['id']] === 1 ? '' : 's' ?></a></small><?php endif; ?>
        <?php if ($c['asked']): ?><small data-tv-status="info" data-tv-label="Still available?">Tap Still available, or it comes off at the next check.</small><?php endif; ?>
        <?php if ($c['note'] !== ''): ?><small data-tv-status="<?= $s === 'removed' ? 'bad' : 'info' ?>" data-tv-label="<?= $s === 'removed' ? 'Why:' : 'Waiting:' ?>"><?= tv_e($c['note']) ?></small><?php endif; ?></span>
      <span class="um-acts">
        <?php if ($c['asked']): ?><button class="um-b ask" data-um="confirm" data-id="<?= (int) $c['id'] ?>">Still available</button><?php endif; ?>
        <?php if ($s === 'active'): ?><button class="um-b" data-um="pending" data-id="<?= (int) $c['id'] ?>">Mark pending</button><?php endif; ?>
        <?php if ($s === 'pending'): ?><button class="um-b" data-um="show" data-id="<?= (int) $c['id'] ?>">Available again</button><?php endif; ?>
        <?php if (in_array($s, ['active', 'pending', 'paused', 'expired'], true)): ?><button class="um-b go" data-um="sold" data-id="<?= (int) $c['id'] ?>">Mark sold</button><?php endif; ?>
        <?php if (in_array($s, ['paused', 'expired', 'sold'], true)): ?><button class="um-b go" data-um="relist" data-id="<?= (int) $c['id'] ?>">Put it back up</button><?php endif; ?>
        <?php if ($s !== 'removed'): ?><a class="um-b" href="<?= tv_e($q('edit=' . (int) $c['id'])) ?>">Edit</a><?php endif; ?>
        <?php if (in_array($s, ['active', 'pending'], true)): ?><button class="um-b" data-um="pause" data-id="<?= (int) $c['id'] ?>">Take off for now</button><?php endif; ?>
        <?php if ($s !== 'removed'): ?><button class="um-b" data-um="remove" data-id="<?= (int) $c['id'] ?>" data-ask="Take this post down for good? It stays in your list for the record.">Take down</button><?php endif; ?>
      </span>
    </div>
    <?php endforeach; ?>
  </section>
  <?php endif; ?>

  <?php if ($tab === 'offers'): $ph = (string) (Market::setting($pdo, 'payhow:' . $uid) ?? ''); ?>
  <section class="um-card tv-bleed"><h2>How you take payment</h2>
    <p class="um-note">For people buying from you. Shown only to someone whose offer you accepted, never on your posts. For example: &ldquo;Cash at pickup, or Zelle to 928-555-0101 (Sam R.)&rdquo;.</p>
    <div style="display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.4rem"><input type="text" id="um-payhow" maxlength="300" value="<?= tv_e($ph) ?>" style="flex:1 1 16rem;border:1px solid #CBB98D;border-radius:.5rem;padding:.4rem .5rem"><button type="button" class="um-b go" id="um-payhow-save">Save</button></div>
  </section>
  <?php endif; ?>
  <?php if ($tab === 'offers'): ?>
  <section class="um-card tv-bleed"><h2>Offers on your posts</h2>
    <?php if (!$offers['selling']): ?><p class="um-note">When someone makes an offer on one of your posts, it shows here, with a message in your messages.</p><?php endif; ?>
    <?php foreach ($offers['selling'] as $o) echo tv_market_offer($o, true, $top); ?>
  </section>
  <section class="um-card tv-bleed"><h2>Your offers</h2>
    <?php if (!$offers['buying']): ?><p class="um-note">Make an offer from any post. Once you agree and meet, the seller taps Sold and you tap Got it: that completes the trade and earns you both trust points.</p><?php endif; ?>
    <?php foreach ($offers['buying'] as $o) echo tv_market_offer($o, true, $top); ?>
  </section>
  <?php endif; ?>

  <?php if ($tab === 'buying' && is_file(__DIR__ . '/../../../app/lib/MarketCheckout.php')): require_once __DIR__ . '/../../../app/lib/MarketCheckout.php'; $myOrders = MarketCheckout::forBuyer($pdo, $uid); $cartN = MarketCheckout::cartCount($pdo, $uid); ?>
  <section class="um-card tv-bleed"><h2>Your orders from businesses</h2>
    <?php if ($cartN): ?><p class="um-note"><a class="underline font-semibold" href="/market/cart.php"<?= $top ?>>Your cart (<?= $cartN ?>)</a></p><?php endif; ?>
    <?php if (!$myOrders): ?><p class="um-note">When you buy from a business on the Marketplace, your orders show here.</p><?php endif; ?>
    <?php foreach ($myOrders as $mo): ?><div class="um-row"><span class="um-mid"><a class="nm" href="/market/order.php?t=<?= tv_e($mo['token']) ?>"<?= $top ?>>Order <?= (int) $mo['id'] ?> · <?= tv_e((string) $mo['biz']) ?></a>
      <small><?= tv_e(MarketCheckout::money((int) $mo['total_cents'])) ?> · <?= tv_e(MarketCheckout::STATUSES[$mo['status']] ?? $mo['status']) ?> · <?= tv_e(date('M j', strtotime((string) $mo['created_at']))) ?></small></span></div><?php endforeach; ?>
  </section>
  <?php endif; ?>
  <?php if ($tab === 'buying'): ?>
  <section class="um-card tv-bleed"><h2>Saved</h2>
    <?php if (!$buy['saved']): ?><p class="um-note">Tap the bookmark on any post to keep it here.</p><?php else: ?>
    <div class="mk-grid"><?php foreach ($buy['saved'] as $c) echo $c['gone'] ? '<article class="mk-card tv-bleed"><div class="mk-b"><div class="mk-price">' . tv_e($c['price']) . '</div><span class="mk-name" style="text-decoration:none;color:#8A7355">' . tv_e($c['title']) . '</span><div class="mk-m">No longer up</div><button type="button" class="um-b" style="margin-top:.4rem" data-mk-save="' . (int) $c['id'] . '" aria-pressed="true">Remove</button></div></article>' : str_replace('href="/market/', ($top ? 'target="_top" ' : '') . 'href="/market/', tv_market_card($c, true)); ?></div>
    <?php endif; ?>
  </section>
  <section class="um-card tv-bleed"><h2>Sellers you messaged</h2>
    <?php if (!$buy['talks']): ?><p class="um-note">When you message a seller from a post, it shows here. Their replies come to your messages.</p><?php endif; ?>
    <?php foreach ($buy['talks'] as $c): ?>
    <div class="um-row">
      <span class="um-th"><?= $c['photo'] !== '' ? '<img src="' . tv_e($c['photo']) . '" alt="" loading="lazy">' : tv_icon('store') ?></span>
      <span class="um-mid"><?php if ($c['gone']): ?><b><?= tv_e($c['title']) ?></b><?php else: ?><a class="nm" href="<?= tv_e($c['url']) ?>"<?= $top ?>><?= tv_e($c['title']) ?></a><?php endif; ?>
        <small><?= tv_e($c['price'] . ' · ' . $c['place']) ?> · <?= $c['gone'] ? 'no longer up' : tv_e($c['status_label']) ?></small></span>
      <span class="um-acts"><a class="um-b go" href="/user/dashboard.php#addressbook:messages"<?= $top ?: ' target="_top"' ?>>Open the conversation</a></span>
    </div>
    <?php endforeach; ?>
  </section>
  <?php endif; ?>

  <?php if ($tab === 'post'): ?>
  <form class="um-card um-f tv-bleed" id="um-post" novalidate>
    <h2><?= $edit ? 'Edit your post' : 'Post something' ?></h2>
    <?php if (!$edit && $out >= $cap): ?><p data-tv-status="bad" data-tv-label="Full:">You have <?= $cap ?> posts out, the most at once. Mark one sold or take one off first.</p><?php endif; ?>
    <input type="hidden" name="id" value="<?= $edit ? (int) $edit['id'] : 0 ?>">
    <label>What is it?<span class="um-radio"><?php foreach (Market::KINDS as $k => $l): ?><label><input type="radio" name="kind" value="<?= $k ?>"<?= ($e['kind'] ?? 'item') === $k ? ' checked' : '' ?>> <?= $k === 'item' ? 'Something to sell or give away' : 'A service (lessons, repairs, hauling…)' ?></label><?php endforeach; ?></span></label>
    <div><span class="um-f" style="display:block;font-size:.78rem;font-weight:700;color:#5C4632;margin-bottom:.25rem">Photos <small id="um-ph-need">(at least one for an item, up to <?= Market::MAX_PHOTOS ?>; the first is the cover)</small></span>
      <div class="um-phs" id="um-phs"><?php foreach ($ePhotos as $i => $ph): ?><span class="um-ph<?= $i ? '' : ' first' ?>" data-item="<?= (int) $ph['id'] ?>"><img src="<?= tv_e($ph['card']) ?>" alt=""><button type="button" aria-label="Remove this photo">&times;</button></span><?php endforeach; ?>
        <label class="um-add" id="um-add">+ Add photos<input type="file" accept="image/jpeg,image/png,image/webp" multiple hidden id="um-file"></label></div></div>
    <label>Title <small>What it is, in a few words: &ldquo;Kids&rsquo; bike, 20 inch&rdquo;</small><input type="text" name="title" maxlength="120" required value="<?= tv_e($e['title'] ?? '') ?>"></label>
    <div class="um-2">
      <label>Price<span class="um-radio"><?php foreach (Market::PRICE_MODES as $k => $l): ?><label><input type="radio" name="price_mode" value="<?= $k ?>"<?= ($e['price_mode'] ?? 'fixed') === $k ? ' checked' : '' ?>> <?= tv_e($l) ?></label><?php endforeach; ?></span>
        <input type="number" name="price" min="0.01" step="0.01" placeholder="Dollars" value="<?= isset($e['price_cents']) && $e['price_cents'] !== null ? tv_e(rtrim(rtrim(number_format((int) $e['price_cents'] / 100, 2, '.', ''), '0'), '.')) : '' ?>" aria-label="Price in dollars"></label>
      <label>Category<select name="category" required><option value="">Choose one</option><?php foreach ($cats as $c => $fl): ?><option data-fields="<?= tv_e(json_encode($fl)) ?>"<?= ($e['category'] ?? '') === $c ? ' selected' : '' ?>><?= tv_e($c) ?></option><?php endforeach; ?></select></label>
    </div>
    <div class="um-2" id="um-fields"></div>
    <label id="um-cond">Condition<select name="condition"><option value="">Not saying</option><?php foreach (Market::CONDITIONS as $k => $l): ?><option value="<?= $k ?>"<?= ($e['item_condition'] ?? '') === $k ? ' selected' : '' ?>><?= tv_e($l) ?></option><?php endforeach; ?></select></label>
    <label>Description <small>Optional: size, age, what&rsquo;s included, when you can meet</small><textarea name="about" rows="4" maxlength="4000"><?= tv_e($e['about'] ?? '') ?></textarea></label>
    <label class="um-ac">Where <small>The town or area. Buyers see only this, never your address.</small>
      <input type="text" id="um-place" autocomplete="off" placeholder="Start typing a town" value="<?= tv_e($e['place_label'] ?? '') ?>"><input type="hidden" name="place_key" id="um-place-key" value="<?= tv_e($e['place_key'] ?? '') ?>">
      <span class="um-list" id="um-place-list" hidden></span></label>
    <label>Offer this for <small>We ask &ldquo;Still available?&rdquo; when the time is up (and every <?= (int) Market::setting($pdo, 'check_days') ?> days for Ongoing). Confirm in one tap.</small>
      <select name="length" id="um-length"><?php $curLen = $edit ? ($edit['ends_on'] ? 'date' : (string) (int) $edit['offer_days']) : ''; foreach (Market::LENGTHS as $d => $l): ?><option value="<?= $d ?>"<?= $curLen === (string) $d ? ' selected' : '' ?><?= $d === 0 ? ' data-service' : '' ?>><?= tv_e($l) ?></option><?php endforeach; ?><option value="date"<?= $curLen === 'date' ? ' selected' : '' ?>>Until a date</option></select>
      <input type="date" name="ends_on" id="um-ends" value="<?= tv_e((string) ($e['ends_on'] ?? '')) ?>" min="<?= date('Y-m-d', strtotime('+1 day')) ?>" max="<?= date('Y-m-d', strtotime('+1 year')) ?>" hidden aria-label="Offered until"></label>
    <?php if (!$edit && Market::testsReady($pdo) && Market::isStaff($pdo, $uid)): ?><label class="um-radio"><label><input type="checkbox" name="test" value="1" checked> <span><b>Test post:</b> only our team sees it. Offers, messages and Sold / Got it work between team members; it counts in no numbers or trust points. Untick for a real post.</span></label></label><?php elseif ($edit && Market::isTest($edit)): ?><p data-tv-status="info" data-tv-label="Test post:">Only our team sees it.</p><?php endif; ?>
    <?php if (!$ageOk): ?><label class="um-radio"><label><input type="checkbox" name="over_18" value="1"> I am 18 or older</label></label><?php endif; ?>
    <p class="um-note">Not allowed: weapons and ammunition, drugs and alcohol, anything stolen or fake, and anything from a burial, sacred or protected site. Some words mean a person looks first. <a class="underline" href="/faq.php#what-can-i-sell-on-the-marketplace"<?= $top ?>>What can I sell?</a></p>
    <div><?php $full = !$edit && $out >= $cap; /* 0135 §7: greyed out with the reason at the cap; a team test post doesn't count */ ?><button class="um-btn" type="submit" id="um-send"<?= $full ? ' disabled title="' . tv_e("You have $cap posts out, the most at once. Mark one sold or take one off first.") . '" data-full' : '' ?>><?= $edit ? 'Save' : 'Post it' ?></button> <a class="um-btn l" href="<?= tv_e($self) ?>">Cancel</a></div>
  </form>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?= tv_market_js() ?>
<script>
(function () {
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var SELF = <?= json_encode($self) ?>;
  // ---- Selling: each post's buttons -------------------------------------------------------------------------------
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-um]'); if (!b) return;
    var ask = b.getAttribute('data-ask');
    if (ask && !TvAsk.gate(b, ask, { yes: 'Take it down', danger: true })) return;
    b.disabled = true;
    tvMarketPost({ action: 'act', id: +b.getAttribute('data-id'), what: b.getAttribute('data-um') }).then(function (d) {
      TvAsk.say(d.message, { anchor: b }); setTimeout(function () { location.reload(); }, 900);
    }).catch(function (x) { TvAsk.say(x.message, { anchor: b, bad: true }); b.disabled = false; });
  });
  var ph = document.getElementById('um-payhow-save');
  if (ph) ph.addEventListener('click', function () { ph.disabled = true; tvMarketPost({ action: 'payhow', text: document.getElementById('um-payhow').value }).then(function (d) { TvAsk.say(d.message, { anchor: ph }); }, function (x) { TvAsk.say(x.message, { anchor: ph, bad: true }); }).then(function () { ph.disabled = false; }); });
  // ---- Post something -----------------------------------------------------------------------------------------------
  (function () {   // at the cap, a team member's Test post (it doesn't count) frees Post it again
    var s = document.getElementById('um-send'), t = s && s.form && s.form.elements.test;
    if (!s || !s.hasAttribute('data-full') || !t) return;
    function sync() { s.disabled = !t.checked; } t.addEventListener('change', sync); sync();
  })();
  var form = document.getElementById('um-post'); if (!form) return;
  var CUR = <?= json_encode($eFields, JSON_UNESCAPED_UNICODE) ?>;
  var cat = form.elements.category, box = document.getElementById('um-fields'), cond = document.getElementById('um-cond');
  var len = document.getElementById('um-length'), ends = document.getElementById('um-ends'), phs = document.getElementById('um-phs'), file = document.getElementById('um-file');
  function kind() { var k = form.querySelector('[name=kind]:checked'); return k ? k.value : 'item'; }
  function fields() {
    var o = cat.options[cat.selectedIndex], fl = []; try { fl = JSON.parse(o.getAttribute('data-fields') || '[]'); } catch (x) {}
    box.innerHTML = fl.map(function (f) { return '<label>' + esc(f) + ' <small>Optional</small><input type="text" maxlength="80" data-field="' + esc(f) + '" value="' + esc(CUR[f] || '') + '"></label>'; }).join('');
    box.hidden = !fl.length;
  }
  function kindChanged() {
    var svc = kind() === 'service';
    cond.hidden = svc;
    var on = len.querySelector('[data-service]'); on.disabled = !svc; on.hidden = !svc;
    if (!svc && len.value === '0') len.value = '30';
    if (!form.elements.id.value || form.elements.id.value === '0') { if (!len.dataset.touched) len.value = svc ? '90' : '30'; }
    document.getElementById('um-ph-need').textContent = svc ? '(optional for a service, up to <?= Market::MAX_PHOTOS ?>; the first is the cover)' : '(at least one for an item, up to <?= Market::MAX_PHOTOS ?>; the first is the cover)';
  }
  function lenChanged() { ends.hidden = len.value !== 'date'; }
  function priceChanged() { var m = form.querySelector('[name=price_mode]:checked'); form.elements.price.hidden = !m || m.value !== 'fixed'; }
  cat.addEventListener('change', fields); len.addEventListener('change', function () { len.dataset.touched = '1'; lenChanged(); });
  form.querySelectorAll('[name=kind]').forEach(function (r) { r.addEventListener('change', kindChanged); });
  form.querySelectorAll('[name=price_mode]').forEach(function (r) { r.addEventListener('change', priceChanged); });
  fields(); kindChanged(); lenChanged(); priceChanged();
  if (form.elements.id.value !== '0' && <?= json_encode($edit ? ($edit['ends_on'] ? 'date' : (string) (int) $edit['offer_days']) : '') ?>) len.dataset.touched = '1';

  // photos: through the one uploader, into your gallery; the post takes their ids
  function tidy() { phs.querySelectorAll('.um-ph').forEach(function (p, i) { p.classList.toggle('first', i === 0); }); }
  phs.addEventListener('click', function (e) { var x = e.target.closest('.um-ph button'); if (x) { x.closest('.um-ph').remove(); tidy(); } });
  file.addEventListener('change', function () {
    var have = phs.querySelectorAll('.um-ph').length, files = Array.prototype.slice.call(file.files, 0, Math.max(0, <?= Market::MAX_PHOTOS ?> - have));
    if (!files.length) { TvAsk.say('That\'s the most photos for one post.', { anchor: phs, bad: true }); return; }
    TvUpload.send(files, { target: 'market_photo', el: phs, shrink: 2400 }).then(function (res) {
      res.forEach(function (r) { if (!r || !r.item) return; var s = document.createElement('span'); s.className = 'um-ph'; s.setAttribute('data-item', r.item.id);
        s.innerHTML = '<img src="' + esc(r.item.card) + '" alt=""><button type="button" aria-label="Remove this photo">&times;</button>'; phs.insertBefore(s, document.getElementById('um-add')); });
      tidy(); file.value = '';
    }, function () { file.value = ''; });
  });

  // where: the town picker (the same places as journeys and experiences)
  var pi = document.getElementById('um-place'), pk = document.getElementById('um-place-key'), pl = document.getElementById('um-place-list'), t = null, seq = 0, opts = [];
  pi.addEventListener('input', function () {
    pk.value = ''; clearTimeout(t); var v = pi.value.trim(); if (v.length < 2) { pl.hidden = true; return; }
    t = setTimeout(function () { var my = ++seq;
      fetch('/api/journeys.php?places=' + encodeURIComponent(v), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        if (my !== seq) return; opts = d.places || [];
        pl.innerHTML = opts.length ? opts.map(function (o, i) { return '<button type="button" data-i="' + i + '"><span>' + esc(o.label) + '</span><small>' + esc(o.sub || '') + '</small></button>'; }).join('') : '<button type="button" disabled>No town by that name yet</button>';
        pl.hidden = false; }).catch(function () {});
    }, 220);
  });
  pl.addEventListener('click', function (e) { var b = e.target.closest('[data-i]'); if (!b) return; var o = opts[+b.getAttribute('data-i')]; pi.value = o.label; pk.value = o.key; pl.hidden = true; });
  document.addEventListener('click', function (e) { if (!e.target.closest('.um-ac')) pl.hidden = true; });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var send = document.getElementById('um-send');
    if (!pk.value) { pi.focus(); TvAsk.say('Choose the town from the list as you type.', { anchor: pi, bad: true }); return; }
    var m = form.querySelector('[name=price_mode]:checked');
    var body = { action: 'post', id: +form.elements.id.value || 0, kind: kind(), title: form.elements.title.value, about: form.elements.about.value, category: cat.value,
      condition: form.elements.condition.value, price_mode: m ? m.value : 'fixed', price: form.elements.price.value, place_key: pk.value,
      length: len.value === 'date' ? '' : len.value, ends_on: len.value === 'date' ? ends.value : '', fields: {}, photos: [] };
    box.querySelectorAll('[data-field]').forEach(function (i) { body.fields[i.getAttribute('data-field')] = i.value; });
    phs.querySelectorAll('.um-ph').forEach(function (p) { body.photos.push(+p.getAttribute('data-item')); });
    if (form.elements.test && form.elements.test.checked) body.test = 1;
    if (form.elements.over_18) { if (!form.elements.over_18.checked) { TvAsk.say('Please confirm you are 18 or older.', { anchor: form.elements.over_18, bad: true }); return; } body.over_18 = 1; }
    if (send.hasAttribute('data-full') && !body.test) { TvAsk.say(send.title, { anchor: send, bad: true }); return; }
    send.disabled = true;
    tvMarketPost(body).then(function (d) {
      TvAsk.say(d.message, { anchor: send });
      setTimeout(function () { location.href = SELF + (SELF.indexOf('?') < 0 ? '?' : '&') + 'x=' + Date.now() + '#p' + d.id; }, 1100);
    }).catch(function (x) { TvAsk.say(x.message, { anchor: send, bad: true }); send.disabled = false; });
  });
})();
</script>
<?php tv_page_end();
