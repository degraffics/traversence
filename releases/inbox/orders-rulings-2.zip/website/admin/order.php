<?php
// admin/order.php?id= — one order, for customer service (E-Commerce, decisions/0098). The policy, in its order:
//   1. Fix it      correct what a line delivered (a GO Code's link, number or card): the printed code stays the same
//   2. Credit      a full or partial credit on the customer's account (a QuickBooks credit memo), used toward the next order
//   3. Refund      only when neither works: the money goes back in QuickBooks (staff), recorded here with QuickBooks'
//                  reference and a reason; the refunded GO Codes are switched off (trvgo.us shows "not active")
// Also: a card dispute (chargeback) and how it ended, checking a payment with QuickBooks, cancelling an unpaid order,
// a note for our team. The history and the money ledger below are only ever added to. Admins only.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/Orders.php';
require_once __DIR__ . '/../../app/lib/QrIssue.php';
require_once __DIR__ . '/../../app/lib/Qr.php';
require_once __DIR__ . '/../../app/lib/QuickBooksPay.php';
require_once __DIR__ . '/../../app/lib/ClientOrders.php';
require_once __DIR__ . '/../../app/lib/WorkOrders.php';

$pdo = Database::connection();
tv_crawler_require_admin($pdo);
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$usd = fn ($c) => Orders::usd((int) $c);
$oid = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$self = '/admin/order.php?id=' . $oid;
// a client order still being built or reviewed isn't an order yet: it opens in its builder (decisions/0101)
if ($oid && ($pre = Orders::get($pdo, $oid)) && (int) ($pre['created_by'] ?? 0) > 0 && in_array($pre['status'], ['draft', 'sent'], true)) { header('Location: /admin/client-order.php?id=' . $oid, true, 302); exit; }
$actor = (int) $me['id'];
$cents = function (string $s): int {
    $s = str_replace([',', '$', ' '], '', trim($s));
    if (!preg_match('/^\d+(\.\d{1,2})?$/', $s)) throw new RuntimeException('Enter the amount in dollars, like 4.95.');
    return (int) round(((float) $s) * 100);
};

if (!Orders::ready($pdo)) { tv_admin_start('ecommerce', 'Order'); echo '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2026-12-02_orders.sql</code> first.</p></div>'; tv_admin_end(); return; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $msg = '';
        switch ((string) ($_POST['do'] ?? '')) {
            case 'fix':
                $f = array_map(fn ($v) => is_string($v) ? $v : '', (array) ($_POST['f'] ?? []));
                $r = Orders::fix($pdo, $oid, (int) ($_POST['line'] ?? 0), $f, (string) ($_POST['title'] ?? ''), trim((string) ($_POST['why'] ?? '')), $actor);
                $msg = $r['changed'] ? 'Fixed: ' . implode(', ', $r['changed']) . ($r['direct'] ? '. It\'s a Wi-Fi code, so tell the customer to download the new picture.' : '. Scans open the corrected one now; the printed code stays the same.') : 'Nothing was different, so nothing changed.';
                break;
            case 'credit':
                Orders::credit($pdo, $oid, $cents((string) ($_POST['amount'] ?? '')), trim((string) ($_POST['note'] ?? '')), $actor);
                $msg = 'Credit given, and created in QuickBooks as a credit memo. The customer was emailed.';
                break;
            case 'refund':
                $amt = $cents((string) ($_POST['amount'] ?? '')); $why = (string) ($_POST['reason'] ?? ''); $rv = (array) ($_POST['revoke'] ?? []);
                if (($_POST['how'] ?? '') === 'record') {   // already refunded in QuickBooks by hand
                    Orders::refund($pdo, $oid, $amt, $why, trim((string) ($_POST['qb_ref'] ?? '')), $rv, $actor);
                    $msg = 'Refund recorded and the customer emailed.';
                } else {
                    $warn = Orders::refundThroughQuickBooks($pdo, $oid, $amt, $why, $rv, $actor);
                    if ($warn !== '') { tv_crawler_flash(['type' => 'error', 'text' => $warn]); header('Location: ' . $self, true, 303); exit; }
                    $msg = 'Refunded to the card through QuickBooks, with a Refund Receipt in the books. The customer was emailed.';
                }
                if (array_filter($rv) || Orders::refundable($pdo, $oid) <= 0) $msg .= ' Refunded GO Codes are switched off.';
                // the open work orders ticked to stop with it (decisions/0101, note of 2026-11-20, B.5)
                $stopped = [];
                foreach (array_map('intval', (array) ($_POST['stop_wo'] ?? [])) as $wid) {
                    $w = WorkOrders::get($pdo, $wid, $oid); if (!$w) continue;
                    try { WorkOrders::cancel($pdo, $w, 'Refunded: ' . trim($why), $actor); $stopped[] = $w['wo_no']; }
                    catch (Throwable $x) { $msg .= ' Work order ' . $w['wo_no'] . ' wasn\'t cancelled: ' . $x->getMessage(); }
                }
                if ($stopped) $msg .= ' Cancelled ' . implode(', ', $stopped) . ', and the vendor was told.';
                break;
            case 'inbox':   // a refund or credit made in QuickBooks, put on this order by a person
                Orders::inboxApply($pdo, (int) ($_POST['inbox'] ?? 0), $oid, (array) ($_POST['revoke'] ?? []), $actor);
                $msg = 'Recorded on this order.';
                break;
            case 'chargeback':
                Orders::chargeback($pdo, $oid, $cents((string) ($_POST['amount'] ?? '')), trim((string) ($_POST['ref'] ?? '')), $actor);
                $msg = 'Dispute recorded. The order\'s GO Codes are paused until it\'s decided.';
                break;
            case 'won': Orders::chargebackResolved($pdo, $oid, true, $actor); $msg = 'Dispute won: the codes are back on.'; break;
            case 'lost': Orders::chargebackResolved($pdo, $oid, false, $actor); $msg = 'Dispute lost: recorded, and the codes are switched off.'; break;
            case 'check':
                if (($co = Orders::get($pdo, $oid)) && ClientOrders::isClient($co)) { $got = ClientOrders::fromQuickBooks($pdo, $oid); $msg = $got !== '' ? 'Recorded from QuickBooks: ' . $got . '.' : 'Nothing new paid on its QuickBooks invoice.'; }   // part payments too (decisions/0101 note, 2026-11-20, B.3)
                elseif (QuickBooksPay::paid($pdo, $oid)) { QrIssue::markPaid($pdo, $oid); $msg = 'Paid: the codes are issued and the customer emailed.'; }
                else $msg = 'QuickBooks says it isn\'t paid yet.';
                break;
            case 'mockpaid':   // the local test only (QB_ENV=mock)
                if (QuickBooksPay::env() !== 'mock') throw new RuntimeException('Only in the local test.');
                $pdo->prepare("UPDATE orders SET note = 'mock-paid' WHERE id = ?")->execute([$oid]);
                QrIssue::markPaid($pdo, $oid); $msg = 'Marked paid (test).';
                break;
            case 'cancel':
                Orders::cancelUnpaid($pdo, $oid, trim((string) ($_POST['why'] ?? '')), $actor);
                $msg = 'Cancelled. Its GO Codes are back in the cart.' . (($o = Orders::get($pdo, $oid)) && $o['invoice_no'] ? ' Void invoice ' . $o['invoice_no'] . ' in QuickBooks too.' : '');
                break;
            case 'pause': case 'resume':
                Orders::pauseLine($pdo, $oid, (int) ($_POST['line'] ?? 0), $_POST['do'] === 'pause', trim((string) ($_POST['why'] ?? '')), $actor);
                $msg = $_POST['do'] === 'pause' ? 'Paused: scanning it shows "This code isn\'t active" until you turn it back on.' : 'Turned back on: it works again.';
                break;
            case 'note': Orders::note($pdo, $oid, (string) ($_POST['note'] ?? ''), $actor); $msg = 'Note added.'; break;
        }
        if ($msg !== '') tv_crawler_flash(['type' => 'ok', 'text' => $msg]);
    } catch (Throwable $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    header('Location: ' . $self, true, 303); exit;
}

$o = Orders::get($pdo, $oid);
$isClient = $o && (int) ($o['created_by'] ?? 0) > 0;
tv_admin_start('ecommerce', $o ? 'Order #' . Orders::no($o) : 'Order', '', null, [['E-Commerce', '/admin/ecommerce.php'], $isClient ? ['Orders', '/admin/ecommerce.php#orders'] : ['Orders', '/admin/ecommerce.php#orders'], [$o ? 'Order #' . $oid : 'Order', null]]);
if (!$o) { echo '<div class="hb-card tv-bleed"><p class="text-sm">There\'s no order #' . $oid . '. <a class="hb-go" href="/admin/ecommerce.php#orders">All orders</a></p></div>'; tv_admin_end(); return; }

$flash = tv_crawler_flash();
$lines = Orders::lines($pdo, $oid);
$m = Orders::money($pdo, $oid);
$dispute = Orders::disputeOpen($pdo, $oid);
$paid = $m['paid'] > 0;
$unpaid = in_array($o['status'], ['pending', 'draft', 'sent'], true);
$credit = Orders::creditBalance($pdo, $o['user_id'] ? (int) $o['user_id'] : null, (string) $o['bill_email']);
$env = QuickBooksPay::env();
$codes = [];   // line id => its GO Code, with its trvgo.us address
foreach ($lines as $l) if ($l['product'] === 'go_code' && $l['ref_id']) {
    $st = $pdo->prepare('SELECT q.*, s.code AS short_code, s.active AS short_active, s.scans FROM qr_issued q LEFT JOIN short_codes s ON s.id = q.short_code_id WHERE q.id = ?');
    $st->execute([(int) $l['ref_id']]);
    $r = $st->fetch(PDO::FETCH_ASSOC);
    if ($r && !$r['short_code'] && QrIssue::owned($r) && !in_array($r['type'], QrIssue::DIRECT, true)) {   // issued before codes went through trvgo.us
        $r['short_code'] = QrIssue::issueShort($pdo, (int) $r['id']); $r['short_active'] = 1; $r['scans'] = 0;
    }
    if ($r) $codes[(int) $l['id']] = $r;
}
$when = fn ($t) => $t ? date('M j, Y g:i a', strtotime((string) $t)) : '';
$hidden = fn (string $do) => '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="id" value="' . $oid . '"><input type="hidden" name="do" value="' . $do . '">';
?>
<style>
  .or{color:#3E2B1F;font-size:0.98rem}
  .or-top{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center;margin:.2rem 0 .4rem}
  .or-msg{padding:.5rem .7rem;border-radius:.5rem;background:#DCFCE7;margin:.45rem 0}.or-msg.error{background:#FEE2E2}
  .or-sum{display:grid;grid-template-columns:repeat(auto-fit,minmax(9rem,1fr));gap:.45rem;margin-top:.5rem}
  .or-sum div{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem;padding:.45rem .7rem;font-size:0.9rem;color:#5C4632}.or-sum b{display:block;font:700 1.15rem var(--tv-font-head,Georgia,serif);color:#3E2B1F}
  .or-line{border-top:1px solid #EADFC4;padding:.6rem 0}.or-line:first-child{border-top:0;padding-top:0}
  .or-line .hd{display:flex;justify-content:space-between;gap:.5rem;align-items:flex-start}
  .or-line img{width:4.2rem;height:4.2rem;border-radius:.35rem;background:#fff;border:1px solid #EADFC4;flex:0 0 auto}
  .or-acts{display:flex;flex-direction:column;gap:.3rem;flex:0 0 auto}
  .or-acts a,.or-acts button{width:30px;height:30px;border-radius:999px;border:1.5px solid #B8863B;background:#FFFBF2;color:#B45309;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0;font-size:0.68rem;font-weight:800;text-decoration:none}
  .or-acts a:hover,.or-acts button:hover,.or-acts button.on{background:#8FBCA8;border-color:#6E9F8A;color:#1F3A2E;box-shadow:0 0 6px rgba(143,188,168,.7)}
  .or-ic{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
  .or-line small{display:block;color:#8A7355;font-size:0.88rem;overflow-wrap:anywhere}
  .or details{margin-top:.4rem}.or details summary{cursor:pointer;font-weight:700;color:#92400E;font-size:0.93rem}
  .or-form{display:grid;gap:.4rem;margin-top:.45rem}.or-form label{font-size:0.88rem;color:#5C4632;display:grid;gap:.15rem}
  .or-form .two{display:grid;grid-template-columns:1fr 1fr;gap:.4rem}
  .or-step{display:inline-flex;align-items:center;justify-content:center;width:1.4rem;height:1.4rem;border-radius:999px;background:#92400E;color:#fff;font-size:0.83rem;font-weight:700;margin-right:.35rem}
  .or-log{margin:.3rem 0 0;padding:0;list-style:none}.or-log li{border-top:1px solid #EADFC4;padding:.4rem 0;font-size:0.93rem}.or-log li:first-child{border-top:0}
  .or-log small{color:#8A7355}
  .or-amt.neg{color:#991B1B}
  @media (max-width:767px){.or-form .two{grid-template-columns:1fr}}
</style>
<div class="or">
  <div class="or-top">
    <span class="hb-pill<?= $o['status'] === 'paid' ? ' ok' : (in_array($o['status'], ['disputed', 'refunded'], true) ? ' red' : '') ?>" style="margin:0"><?= $e(Orders::STATUS[$o['status']] ?? $o['status']) ?></span><?= ($o['qb_env'] ?? '') === 'sandbox' ? '<span class="hb-pill" style="margin:0" title="Made in the QuickBooks sandbox: a test, no real money">Test (sandbox)</span>' : '' ?>
    <?php if ((int) ($o['created_by'] ?? 0) > 0): ?><a class="hb-b go" href="/admin/backoffice/orders/<?= $oid ?>">Client order: proofs, production</a><a class="hb-b" href="/order.php?t=<?= $e($o['access_token']) ?>" target="_blank" rel="noopener">What the client sees ↗</a>
    <?php elseif ($o['access_token']): ?><a class="hb-b" href="<?= $e(QrIssue::manageUrl($o)) ?>" data-peek-frame>What the customer sees</a><?php endif; ?>
  </div>
  <?php if ($flash): ?><p class="or-msg <?= $e($flash['type'] ?? '') ?>" role="status" data-tv-flash="<?= $e($flash['type'] ?? '') ?>"><?= $e($flash['text'] ?? '') ?></p><?php endif; ?>
  <?php $ib = !empty($_GET['inbox']) ? Orders::inboxItem($pdo, (int) $_GET['inbox']) : null; if ($ib && $ib['status'] === 'open'): ?>
  <div class="hb-card hot tv-bleed" style="margin-bottom:.6rem">
    <b>From QuickBooks: <?= $ib['kind'] === 'refund' ? 'Refund Receipt' : 'credit memo' ?> <?= $e($ib['qb_ref']) ?>, <?= $usd($ib['amount_cents']) ?></b>
    <small style="display:block;color:#5C4632"><?= $e($ib['customer']) ?><?= $ib['txn_date'] ? ' · ' . $e(date('M j, Y', strtotime((string) $ib['txn_date']))) : '' ?> · <?= $e($ib['why']) ?></small>
    <form method="post" class="or-form"><?= $hidden('inbox') ?><input type="hidden" name="inbox" value="<?= (int) $ib['id'] ?>">
      <?php if ($ib['kind'] === 'refund'): $live2 = array_filter(Orders::lines($pdo, $oid), fn ($l) => $l['status'] !== 'refunded'); ?>
        <fieldset style="font-size:.82rem"><legend style="color:#5C4632">Switch off (if it's all that was left, every item is switched off)</legend>
        <?php foreach ($live2 as $l): ?><label style="display:flex;gap:.4rem;align-items:center"><input type="checkbox" name="revoke[]" value="<?= (int) $l['id'] ?>"> <?= $e($l['title'] ?: 'Item') ?></label><?php endforeach; ?></fieldset>
      <?php endif; ?>
      <div><button class="hb-b go" data-confirm="Record it on order #<?= $e(Orders::no($o)) ?>?" data-yes="Record it">It's this order: record it</button></div>
    </form>
  </div>
  <?php endif; ?>

  <div class="hb-card tv-bleed">
    <dl class="hb-dl" style="margin-top:0">
      <dt>Customer</dt><dd><?= $e($o['bill_name'] ?: 'No name') ?> · <a class="underline" href="mailto:<?= $e($o['bill_email']) ?>"><?= $e($o['bill_email']) ?></a><?= $o['user_id'] ? ' · member #' . (int) $o['user_id'] : ' · guest' ?></dd>
      <dt>Billing address</dt><dd><?= $e(trim($o['bill_street'] . ', ' . $o['bill_city'] . ', ' . $o['bill_state'] . ' ' . $o['bill_zip'], ' ,')) ?: '—' ?></dd>
      <dt>QuickBooks</dt><dd><?= $o['invoice_no'] ? 'Invoice ' . $e($o['invoice_no']) : 'No invoice' ?><?= $o['pay_url'] ? ' · <a class="underline" href="' . $e($o['pay_url']) . '" target="_blank" rel="noopener">its payment page</a>' : '' ?></dd>
      <dt>Placed</dt><dd><?= $e($when($o['created_at'])) ?><?= $o['paid_at'] ? ' · paid ' . $e($when($o['paid_at'])) : '' ?></dd>
      <?php if ($credit > 0): ?><dt>Credit on account</dt><dd><?= $usd($credit) ?></dd><?php endif; ?>
    </dl>
    <div class="or-sum">
      <div><b><?= $usd($o['subtotal_cents']) ?></b>subtotal</div>
      <div><b><?= $usd($o['tax_cents']) ?></b>tax</div>
      <div><b><?= $usd($o['total_cents']) ?></b>total</div>
      <div><b><?= $usd($m['paid']) ?></b>paid</div>
      <?php if ($m['refunded']): ?><div><b><?= $usd($m['refunded']) ?></b>refunded</div><?php endif; ?>
      <?php if ($m['credited']): ?><div><b><?= $usd($m['credited']) ?></b>credited</div><?php endif; ?>
      <?php if ($m['disputed']): ?><div><b><?= $usd($m['disputed']) ?></b>in dispute</div><?php endif; ?>
      <?php if ($paid): ?><div><b><?= $usd($m['net']) ?></b>kept</div><?php endif; ?>
    </div>
    <?php if ($unpaid): ?>
    <form method="post" class="or-top" style="margin-top:.6rem"><?= $hidden('check') ?><button class="hb-b go">Check payment with QuickBooks</button></form>
    <?php if ($env === 'mock'): ?><form method="post" class="or-top"><?= $hidden('mockpaid') ?><button class="hb-b">Mark paid (test)</button></form><?php endif; ?>
    <?php endif; ?>
  </div>

  <h2 class="hb-h">What was ordered</h2>
  <div class="hb-card tv-bleed">
    <?php if (!$lines): ?><p class="text-sm">No lines on this order.</p><?php endif; ?>
    <?php foreach ($lines as $l): $c = $codes[(int) $l['id']] ?? null; ?>
    <div class="or-line">
      <div class="hd">
        <div style="min-width:0;flex:1">
          <b><?= $e($l['title'] ?: 'Item') ?></b> <span class="hb-pill<?= $l['status'] === 'refunded' ? ' red' : ($l['status'] === 'done' ? ' ok' : '') ?>"><?= $e(['open' => 'Open', 'done' => 'Delivered', 'cancelled' => 'Cancelled', 'refunded' => 'Refunded'][$l['status']] ?? $l['status']) ?></span>
          <small><?= $l['product'] === 'go_code' ? 'GO Code' : $e($l['product']) ?><?= $c ? ' · ' . $e(Qr::TYPES[$c['type']] ?? $c['type']) : '' ?> · <?= (int) $l['qty'] ?> × <?= $usd($l['unit_cents']) ?><?= $l['approved_at'] ? ' · approved ' . $e(date('M j', strtotime((string) $l['approved_at']))) : '' ?></small>
          <?php if ($c): ?>
            <?php if ($c['short_code']): ?><small><a class="underline" href="<?= $e(QrIssue::shortUrl((string) $c['short_code'])) ?>" target="_blank" rel="noopener"><?= $e(preg_replace('#^https?://#', '', QrIssue::shortUrl((string) $c['short_code']))) ?></a> · <?= (int) $c['scans'] ?> scan<?= (int) $c['scans'] === 1 ? '' : 's' ?><?= !(int) $c['short_active'] ? ' · <b>switched off</b>' : '' ?></small>
            <?php elseif (in_array($c['type'], QrIssue::DIRECT, true)): ?><small>Wi-Fi: the code holds the network itself (no trvgo.us address)</small><?php endif; ?>
            <small style="color:#3E2B1F;font-weight:600"><?= $e(QrIssue::holds((string) $c['type'], json_decode((string) $c['fields'], true) ?: [])) ?></small>
          <?php endif; ?>
        </div>
        <?php if ($c && QrIssue::owned($c)): $q = '/api/qr.php?issued=' . (int) $c['id'] . '&staff=1'; $go = $c['short_code'] ? QrIssue::shortUrl((string) $c['short_code']) : ''; $on = (int) ($c['short_active'] ?? 1); ?>
        <a href="<?= $e($q) ?>&format=png&px=900" data-peek-frame title="See it larger"><img src="<?= $e($q) ?>&format=png&px=200" alt="" loading="lazy" onerror="this.remove()"></a>
        <div class="or-acts">
          <?php if ($go !== ''): ?><a href="<?= $e($go) ?>?b=1" target="_blank" rel="noopener" title="Try it (not counted as a scan)" aria-label="Try it"><?= tv_icon('eye', 'or-ic') ?></a>
          <button type="button" data-copy="<?= $e($go) ?>" title="Copy its address" aria-label="Copy its address"><?= tv_icon('link', 'or-ic') ?></button><?php endif; ?>
          <a href="<?= $e($q) ?>&format=svg&download=1" title="Download for print (SVG)" aria-label="Download SVG">SVG</a>
          <a href="<?= $e($q) ?>&format=png&px=1200&download=1" title="Download for screens (PNG)" aria-label="Download PNG">PNG</a>
          <?php if ($go !== ''): ?><form method="post"><?= $hidden($on ? 'pause' : 'resume') ?><input type="hidden" name="line" value="<?= (int) $l['id'] ?>">
            <button class="<?= $on ? '' : 'on' ?>" title="<?= $on ? 'Pause it (shows not active; no refund)' : 'Turn it back on' ?>" aria-label="<?= $on ? 'Pause it' : 'Turn it back on' ?>" data-confirm="<?= $on ? 'Pause this code? Scanning it shows \'not active\' until it\'s turned back on.' : 'Turn this code back on?' ?>" data-yes="<?= $on ? 'Pause it' : 'Turn it on' ?>"<?= $on ? ' data-danger' : '' ?>><?= tv_icon('power', 'or-ic') ?></button></form><?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
      <?php if ($c && $l['status'] !== 'refunded' && $c['status'] !== 'revoked'): $f = json_decode((string) $c['fields'], true) ?: []; ?>
      <details>
        <summary><span class="or-step">1</span>Fix it</summary>
        <form method="post" class="or-form"><?= $hidden('fix') ?><input type="hidden" name="line" value="<?= (int) $l['id'] ?>">
          <label>Name on the code<input class="hb-in" name="title" value="<?= $e($c['title']) ?>" maxlength="120"></label>
          <?php foreach (QrIssue::FIELDS[$c['type']] ?? [] as $k => $lab): $v = (string) ($f[$k] ?? ''); ?>
            <label><?= $e($lab) ?><?php if (in_array($k, ['text', 'body', 'details', 'note', 'message'], true)): ?><textarea class="hb-in" name="f[<?= $e($k) ?>]" rows="3"><?= $e($v) ?></textarea><?php else: ?><input class="hb-in" name="f[<?= $e($k) ?>]" value="<?= $e($v) ?>"><?php endif; ?></label>
          <?php endforeach; ?>
          <label>What was wrong (for the history)<input class="hb-in" name="why" maxlength="200" placeholder="Customer wrote in: typo in the link"></label>
          <div><button class="hb-b go" data-confirm="Save the fix? Scans open the corrected code at once." data-yes="Save it">Save the fix</button></div>
        </form>
      </details>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <?php if ($paid): ?>
  <h2 class="hb-h">Customer service</h2>
  <p class="hb-intro">Fix it first (above). If that doesn't put it right, a credit; a refund only when neither works. Made-to-order work is final once approved.</p>
  <div class="hb-card tv-bleed">
    <details>
      <summary><span class="or-step">2</span>Credit (full or partial)</summary>
      <form method="post" class="or-form"><?= $hidden('credit') ?>
        <div class="two"><label>Amount ($)<input class="hb-in" name="amount" inputmode="decimal" required placeholder="<?= $e(number_format(max(0, $m['net'] - $m['credited']) / 100, 2)) ?>"></label>
        <label>Why (the customer sees this)<input class="hb-in" name="note" maxlength="200" placeholder="Sorry for the trouble"></label></div>
        <div><button class="hb-b go" data-confirm="Give this credit? It's created in QuickBooks and the customer is emailed." data-yes="Give the credit">Give the credit</button></div>
        <small class="text-xs text-[#8A7355]">Created in QuickBooks as a credit memo for the customer. Turn on Automatically apply credits in QuickBooks (Account and settings → Advanced) so it comes off their next invoice.</small>
      </form>
    </details>
    <details>
      <summary><span class="or-step">3</span>Refund (last resort)</summary>
      <form method="post" class="or-form"><?= $hidden('refund') ?>
        <?php $cards = QuickBooksPay::canRefundCards($pdo); ?>
        <label style="display:flex;gap:.45rem;align-items:flex-start;font-size:.85rem;color:#3E2B1F"><input type="radio" name="how" value="card"<?= $cards ? ' checked' : ' disabled' ?>> <span><b>Refund the card through QuickBooks.</b> One step: the money goes back to the card, the Refund Receipt goes in the books, and the order is put right.<?= $cards ? '' : ' <i>Reconnect QuickBooks (E-Commerce → Payments) to turn this on.</i>' ?></span></label>
        <label style="display:flex;gap:.45rem;align-items:flex-start;font-size:.85rem;color:#3E2B1F"><input type="radio" name="how" value="record"<?= $cards ? '' : ' checked' ?>> <span><b>Already refunded in QuickBooks:</b> record it here. (Refunds made in QuickBooks are usually recorded by themselves, when QuickBooks tells us.)</span></label>
        <div class="two"><label>Amount ($, all of it unless you change it)<input class="hb-in" name="amount" inputmode="decimal" required value="<?= $e(number_format(Orders::refundable($pdo, $oid) / 100, 2, '.', '')) ?>"></label>
        <label>Refund Receipt no. (only when recording one made in QuickBooks)<input class="hb-in" name="qb_ref" maxlength="60" placeholder="e.g. 1003"></label></div>
        <label>Why a refund (fix and credit didn't work because…)<input class="hb-in" name="reason" maxlength="300" required></label>
        <?php $live = array_filter($lines, fn ($l) => $l['status'] !== 'refunded'); if ($live): ?>
          <fieldset style="font-size:.82rem"><legend style="color:#5C4632">Switch off (for a partial refund; a full refund switches all of them off)</legend>
          <?php foreach ($live as $l): ?><label style="display:flex;gap:.4rem;align-items:center"><input type="checkbox" name="revoke[]" value="<?= (int) $l['id'] ?>"> <?= $e($l['title'] ?: 'Item') ?></label><?php endforeach; ?></fieldset>
        <?php endif; ?>
        <?php $openWo = $isClient && WorkOrders::ready($pdo) ? array_filter(WorkOrders::forOrder($pdo, $oid), fn ($w) => !in_array((string) $w['status'], ['received', 'cancelled', 'complete', 'declined', 'rejected'], true)) : []; if ($openWo): ?>
          <fieldset style="font-size:.82rem"><legend style="color:#5C4632">Open work orders: where each stands first (decisions/0101, B.5)</legend>
          <?php foreach ($openWo as $w): $late = in_array((string) $w['status'], ['accepted', 'production', 'shipped', 'ready'], true); ?>
            <p data-tv-status="<?= $late ? 'bad' : 'info' ?>" data-tv-label="<?= $e($w['wo_no']) ?>:"><?= $e($w['vendor']) ?>, <?= $e(WorkOrders::STATUS[$w['status']] ?? $w['status']) ?>.<?= $late ? ' The vendor has accepted or made it, so its cost may not come back. What the client gets back is decided separately.' : ' Not accepted yet.' ?></p>
            <label style="display:flex;gap:.4rem;align-items:center"><input type="checkbox" name="stop_wo[]" value="<?= (int) $w['id'] ?>"> Cancel the work order and notify the vendor</label>
          <?php endforeach; ?></fieldset>
        <?php endif; ?>
        <div><button class="hb-b no" data-confirm="Refund this? The customer is emailed and refunded GO Codes stop working (their link shows 'not active'). Ticked work orders are cancelled and their vendors told." data-yes="Refund it" data-danger>Refund</button></div>
      </form>
    </details>
    <details>
      <summary>Card dispute (chargeback)</summary>
      <?php if ($dispute): ?>
        <p class="text-sm" style="margin-top:.4rem">A dispute is open: the order's GO Codes are paused. When the bank decides:</p>
        <div class="or-top">
          <form method="post"><?= $hidden('won') ?><button class="hb-b go" data-confirm="Dispute won? The codes come back on." data-yes="It was won">Won</button></form>
          <form method="post"><?= $hidden('lost') ?><button class="hb-b no" data-confirm="Dispute lost? The codes are switched off for good." data-yes="It was lost" data-danger>Lost</button></form>
        </div>
      <?php else: ?>
      <form method="post" class="or-form"><?= $hidden('chargeback') ?>
        <div class="two"><label>Amount disputed ($)<input class="hb-in" name="amount" inputmode="decimal" required value="<?= $e(number_format(max(0, $m['net']) / 100, 2, '.', '')) ?>"></label>
        <label>Case or reference no.<input class="hb-in" name="ref" maxlength="60"></label></div>
        <div><button class="hb-b no" data-confirm="Record a card dispute? The order's GO Codes are paused until it's decided." data-yes="Record it" data-danger>Record the dispute</button></div>
      </form>
      <?php endif; ?>
    </details>
  </div>
  <?php elseif ($unpaid): ?>
  <h2 class="hb-h">Not paid yet</h2>
  <div class="hb-card tv-bleed">
    <form method="post" class="or-form"><?= $hidden('cancel') ?>
      <label>Why it's cancelled (optional)<input class="hb-in" name="why" maxlength="200"></label>
      <div><button class="hb-b no" data-confirm="Cancel this order? Its GO Codes go back to the cart." data-yes="Cancel it" data-danger>Cancel the order</button></div>
    </form>
  </div>
  <?php endif; ?>

  <h2 class="hb-h">History</h2>
  <div class="hb-card tv-bleed">
    <ul class="or-log">
      <?php foreach (Orders::events($pdo, $oid) as $ev): ?>
      <li><b><?= $e(ucfirst(str_replace('_', ' ', (string) $ev['event']))) ?></b><?= $ev['note'] !== '' ? ': ' . $e($ev['note']) : '' ?><br><small><?= $e($when($ev['created_at'])) ?><?= $ev['actor_name'] ? ' · ' . $e($ev['actor_name']) : '' ?></small></li>
      <?php endforeach; ?>
    </ul>
    <form method="post" class="or-form"><?= $hidden('note') ?><label>A note for our team<textarea class="hb-in" name="note" rows="2" maxlength="600"></textarea></label><div><button class="hb-b">Add the note</button></div></form>
  </div>

  <h2 class="hb-h">Money</h2>
  <div class="hb-card tv-bleed">
    <?php $led = Orders::ledger($pdo, $oid); if (!$led): ?><p class="text-sm">Nothing paid yet.</p><?php endif; ?>
    <ul class="or-log">
      <?php foreach ($led as $x): $neg = in_array($x['kind'], ['refund', 'chargeback', 'credit_used'], true); ?>
      <li><b><?= $e(Orders::KINDS[$x['kind']] ?? $x['kind']) ?></b> <span class="or-amt<?= $neg ? ' neg' : '' ?>"><?= $neg ? '−' : '' ?><?= $usd($x['amount_cents']) ?></span><?= $x['qb_ref'] !== '' ? ' · QuickBooks ' . $e($x['qb_ref']) : '' ?><?= $x['note'] !== '' ? ' · ' . $e($x['note']) : '' ?><br><small><?= $e($when($x['created_at'])) ?><?= $x['actor_name'] ? ' · ' . $e($x['actor_name']) : '' ?></small></li>
      <?php endforeach; ?>
    </ul>
  </div>
</div>
<script>
document.addEventListener('click', function (e) {
  var b = e.target.closest('[data-copy]'); if (!b) return;
  var t = b.getAttribute('data-copy');
  (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { TvAsk.say('Copied ' + t.replace(/^https?:\/\//, ''), { anchor: b }); }, function () { TvAsk.ask('Its address', t); });
});
</script>
<?php tv_admin_end();
