<?php
// app/lib/Collateral.php — the Collateral Center (decisions/0101, addendum 2026-10-28). A collateral item is a client's
// configured piece: the artwork (its approved proof, print-ready files, production setups, 1-up print files, natives)
// with its product, options, quantity, vendor and notes. It's tied to the order item it came from (made when an order
// is approved, or brought in from past orders) and follows the newest order of it. Reorder makes a new draft order
// from one or more items: the same product, specs and quantity (priced from today's catalog), with the files copied
// over. With the same art, the proof goes to the client marked as a reuse ("Confirm reuse", still signed off with their
// initials); with changes, a new proof round. Clients see only items released to them (Jason: "only the approved, and
// allowed for USE released"), on their Your orders page.
declare(strict_types=1);

require_once __DIR__ . '/ClientOrders.php';

final class Collateral
{
    /** The file kinds a collateral item carries over (not labels, estimates or invoices). */
    public const FILE_KINDS = ['setup', 'print', 'artwork', 'native', 'reference'];

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT 1 FROM collateral LIMIT 0'); $pdo->query('SELECT reuse_of FROM order_proofs LIMIT 0'); $pdo->query('SELECT collateral_id FROM order_lines LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    public static function get(PDO $pdo, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM collateral WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** A name for the piece: the item's name without its run size ("Sunday Ticket 4x6", not "… · 500"). */
    private static function nameOf(array $l): string { return trim((string) preg_replace('/ · [\d,]+(?=\s*-|$)/', '', (string) $l['title'])) ?: 'Item ' . (int) $l['id']; }

    /** Is there artwork on this item worth keeping (an approved proof, or print files)? */
    private static function hasArt(PDO $pdo, int $lineId): bool
    {
        $a = $pdo->prepare("SELECT 1 FROM order_proofs WHERE line_id = ? AND mime <> 'go-code' AND (status = 'approved' OR kind = 'final') LIMIT 1"); $a->execute([$lineId]);
        if ($a->fetchColumn()) return true;
        if (!ClientOrders::hasInline($pdo)) return false;
        $f = $pdo->prepare("SELECT 1 FROM order_files WHERE line_id = ? AND kind IN ('setup','print','artwork','native') LIMIT 1"); $f->execute([$lineId]);
        return (bool) $f->fetchColumn();
    }

    /**
     * An approved order's items into the client's collateral: a new item for each piece with artwork, or the newest
     * order of one already there (a reorder carries its collateral_id). Safe to run again.
     */
    public static function fromOrder(PDO $pdo, int $oid, bool $artLater = false): int   // $artLater: an order pulled from QuickBooks (decisions/0128): its items count before their files come
    {
        if (!self::ready($pdo)) return 0;
        $o = Orders::get($pdo, $oid);
        if (!$o || !ClientOrders::isClient($o) || empty($o['approved_at']) || Orders::isTest($o) || ($o['qb_env'] ?? '') === 'mock' || $o['status'] === 'void') return 0;
        $n = 0;
        foreach (Orders::lines($pdo, $oid) as $l) {
            if (in_array($l['product'], ['shipping', 'go_code'], true) || in_array($l['status'], ['cancelled', 'refunded'], true) || in_array('charge', ClientOrders::tags($l), true)) continue;   // charges (shrink wrap, fees) are never reorder items
            if (!self::hasArt($pdo, (int) $l['id']) && !($artLater && $l['product'] === 'product')) continue;
            $qty = $l['product'] === 'product' ? ClientOrders::runQty($l) : (int) $l['qty'];
            $have = null;
            if (!empty($l['collateral_id'])) $have = self::get($pdo, (int) $l['collateral_id']);
            if (!$have) { $st = $pdo->prepare('SELECT * FROM collateral WHERE source_line_id = ?'); $st->execute([(int) $l['id']]); $have = $st->fetch(PDO::FETCH_ASSOC) ?: null; }
            if ($have) {
                if ((int) $have['source_line_id'] !== (int) $l['id'])   // a newer order of it: its files and specs now
                    $pdo->prepare('UPDATE collateral SET source_order_id = ?, source_line_id = ?, product_id = ?, options = ?, qty = ?, note = ?, vendor_id = COALESCE(?, vendor_id), times_ordered = times_ordered + 1 WHERE id = ?')
                        ->execute([$oid, (int) $l['id'], $l['product_id'] ?: null, (string) $l['options'], $qty, (string) $l['note'], $l['vendor_id'] ?? null, (int) $have['id']]);
                else $pdo->prepare('UPDATE collateral SET options = ?, qty = ?, note = ? WHERE id = ?')->execute([(string) $l['options'], $qty, (string) $l['note'], (int) $have['id']]);   // the same order approved again (reopened, changed): its specs now
                $cid = (int) $have['id'];
            } else {
                $pdo->prepare('INSERT INTO collateral (client_email, client_name, client_company, user_id, name, product, product_id, options, qty, note, vendor_id, source_order_id, source_line_id, first_order_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                    ->execute([strtolower(trim((string) $o['bill_email'])), (string) $o['bill_name'], (string) $o['client_company'], $o['user_id'] ?: null, mb_substr(self::nameOf($l), 0, 160), (string) $l['product'],
                               $l['product_id'] ?: null, (string) $l['options'], $qty, (string) $l['note'], $l['vendor_id'] ?? null, $oid, (int) $l['id'], $oid]);
                $cid = (int) $pdo->lastInsertId(); $n++;
            }
            $pdo->prepare('UPDATE order_lines SET collateral_id = ? WHERE id = ?')->execute([$cid, (int) $l['id']]);
        }
        return $n;
    }

    /** Past approved orders brought in (the first time the Collateral Center opens, and after). Returns how many items were made. */
    public static function backfill(PDO $pdo): int
    {
        if (!self::ready($pdo)) return 0;
        $n = 0;
        foreach ($pdo->query("SELECT id FROM orders WHERE created_by IS NOT NULL AND approved_at IS NOT NULL AND status <> 'void' AND qb_env NOT IN ('sandbox','mock') ORDER BY approved_at")->fetchAll(PDO::FETCH_COLUMN) as $oid) $n += self::fromOrder($pdo, (int) $oid);
        return $n;
    }

    /**
     * An item's files, from the newest order of it: [kind label, name, url, kind key, record ['p'|'f', id], image?].
     * $forClient: only what the client may have (the approved proof; print-ready files once that order is paid in full).
     */
    public static function files(PDO $pdo, array $c, bool $forClient = false): array
    {
        $o = Orders::get($pdo, (int) $c['source_order_id']); if (!$o) return [];
        $oid = (int) $o['id']; $out = [];
        $t = $forClient ? '&t=' . rawurlencode((string) $o['access_token']) : '';
        $pr = $pdo->prepare("SELECT * FROM order_proofs WHERE line_id = ? AND mime <> 'go-code' ORDER BY version, id"); $pr->execute([(int) $c['source_line_id']]);
        $proofs = $pr->fetchAll(PDO::FETCH_ASSOC);
        if ($forClient) $proofs = array_values(array_filter($proofs, fn ($p) => empty($p['retired_at'])));   // a retired file isn't the client's
        $appr = 0; foreach ($proofs as $p) if (($p['kind'] ?? 'proof') === 'proof' && $p['status'] === 'approved') $appr = max($appr, (int) $p['version']);
        $paid = ClientOrders::paidInFull($pdo, $o);
        foreach ($proofs as $p) {
            $final = ($p['kind'] ?? 'proof') === 'final';
            if (!$final && ((int) $p['version'] !== $appr || $p['status'] !== 'approved')) continue;
            if ($forClient && $final && !$paid) continue;
            $out[] = [$final ? 'Print-ready' : 'Approved proof v' . (int) $p['version'], (string) $p['file_name'], '/api/order-proof.php?o=' . $oid . '&p=' . (int) $p['id'] . $t, $final ? 'final' : 'proof', ['p', (int) $p['id']], str_starts_with((string) $p['mime'], 'image/')];
        }
        if (!$forClient && ClientOrders::hasInline($pdo)) {
            $f = $pdo->prepare("SELECT * FROM order_files WHERE line_id = ? AND kind IN ('" . implode("','", self::FILE_KINDS) . "') ORDER BY id"); $f->execute([(int) $c['source_line_id']]);
            foreach ($f->fetchAll(PDO::FETCH_ASSOC) as $r) $out[] = [ClientOrders::FILE_KINDS[$r['kind']] ?? 'File', (string) $r['file_name'], '/api/order-proof.php?o=' . $oid . '&f=' . (int) $r['id'] . '&download=1', (string) $r['kind'], ['f', (int) $r['id']], str_starts_with((string) $r['mime'], 'image/')];
        }
        return $out;
    }

    /** One client's released items (theirs to see and reorder), for their Your orders page. */
    public static function forClient(PDO $pdo, string $email, int $userId = 0): array
    {
        if (!self::ready($pdo) || (trim($email) === '' && !$userId)) return [];
        $st = $pdo->prepare("SELECT * FROM collateral WHERE status = 'active' AND released = 1 AND ((client_email = ? AND ? <> '')" . ($userId ? ' OR user_id = ' . $userId : '') . ') ORDER BY updated_at DESC');
        $st->execute([strtolower(trim($email)), trim($email)]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Ours: rename, release to the client (or not), archive (or bring back). */
    public static function edit(PDO $pdo, int $id, array $in): void
    {
        $c = self::get($pdo, $id) ?: throw new RuntimeException('That collateral item isn\'t here.');
        if (array_key_exists('name', $in)) { $n = mb_substr(trim((string) $in['name']), 0, 160); if ($n === '') throw new RuntimeException('Give it a name.'); $pdo->prepare('UPDATE collateral SET name = ? WHERE id = ?')->execute([$n, $id]); }
        if (array_key_exists('released', $in)) $pdo->prepare('UPDATE collateral SET released = ? WHERE id = ?')->execute([empty($in['released']) ? 0 : 1, $id]);
        if (array_key_exists('status', $in)) $pdo->prepare('UPDATE collateral SET status = ? WHERE id = ?')->execute([$in['status'] === 'archived' ? 'archived' : 'active', $id]);
        if (array_key_exists('released', $in) || array_key_exists('status', $in))
            Orders::event($pdo, (int) $c['source_order_id'], 'collateral', $c['name'] . ': ' . (array_key_exists('status', $in) ? ($in['status'] === 'archived' ? 'archived' : 'back in use') : (empty($in['released']) ? 'not shown to the client' : 'released to the client')), null);
    }

    /**
     * The client asks to reorder (from their Your artwork page, or from a completed order's page): a draft of the pieces
     * at these quantities ([collateral id => qty]), their note on it, and our team told. At most five asks an hour.
     * Returns the new order's id; our team checks it and sends it to them to approve.
     */
    public static function askReorder(PDO $pdo, array $qty, bool $changes, string $note, string $who, ?int $uid): int
    {
        $_SESSION['tv_uo_n'] = array_filter((array) ($_SESSION['tv_uo_n'] ?? []), fn ($t) => $t > time() - 3600);
        if (count($_SESSION['tv_uo_n']) >= 5) throw new RuntimeException('That\'s a lot of reorders at once: we\'ll be in touch about the ones you\'ve asked for.');
        $qty = array_filter(array_map('intval', $qty), fn ($n) => $n > 0);
        if (!$qty) throw new RuntimeException('Choose what to reorder, and how many.');
        $nid = self::reorder($pdo, array_keys($qty), $qty, !$changes, 0, true);
        $_SESSION['tv_uo_n'][] = time();
        $note = mb_substr(trim($note), 0, 600);
        if ($note !== '') Orders::event($pdo, $nid, 'note', 'From the client: ' . $note, $uid ?: null);
        $names = []; foreach (array_keys($qty) as $id) if ($c = self::get($pdo, (int) $id)) $names[] = $c['name'] . ' (' . number_format($qty[$id]) . ')';
        require_once __DIR__ . '/Mailer.php';
        try { Mailer::send(getenv('ORDERS_FROM_EMAIL') ?: 'support@traversence.com', 'Reorder asked for: ' . implode(', ', $names), $who . ' asked to reorder ' . implode(', ', $names) . ', ' . ($changes ? 'with changes' : 'the same art') . '.' . ($note !== '' ? "\n\nTheir note: " . $note : '') . "\n\nThe draft order (priced at today's rates, its costing re-run and waiting to be checked): " . rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/backoffice/orders/' . $nid . "\n\nCheck it and send it to them.", 'Traversence orders', 'ORDERS'); } catch (Throwable $x) { error_log('reorder ask mail: ' . $x->getMessage()); }
        return $nid;
    }

    /** The pieces on one order the client can reorder from its page: [collateral id => [item, its line]]. */
    public static function onOrder(PDO $pdo, int $oid): array
    {
        if (!self::ready($pdo)) return [];
        $out = [];
        foreach (Orders::lines($pdo, $oid) as $l) if (!empty($l['collateral_id']) && ($c = self::get($pdo, (int) $l['collateral_id'])) && $c['status'] === 'active') $out[(int) $c['id']] = [$c, $l];
        return $out;
    }

    /** Copies a stored file to a new record's place (S3 or the server). */
    private static function copyFile(string $from, string $dest): bool
    {
        require_once __DIR__ . '/Store.php';
        $src = Store::local($from);
        if ($src === '') return false;
        if (!is_dir(dirname($dest))) @mkdir(dirname($dest), Store::mode($dest), true);
        if (!@copy($src, $dest)) return false;
        Store::keep($dest);
        return true;
    }

    /**
     * A reorder: a new draft order for the client with these items, each at its quantity ($qty[id], else as before),
     * priced from today's catalog. $sameArt: the approved proof goes along as a reuse for the client to confirm; else
     * a new proof round (the files go along for our team). Returns the new order's id. $requested: the client asked.
     */
    public static function reorder(PDO $pdo, array $ids, array $qty, bool $sameArt, int $staff, bool $requested = false): int
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run the collateral update (2027-01-03_collateral.sql) first.');
        $items = array_values(array_filter(array_map(fn ($i) => self::get($pdo, (int) $i), $ids)));
        if (!$items) throw new RuntimeException('Choose what to reorder.');
        if (count(array_unique(array_column($items, 'client_email'))) > 1) throw new RuntimeException('Reorder one client\'s items at a time.');
        $src = Orders::get($pdo, (int) $items[0]['source_order_id']) ?: throw new RuntimeException('Its order isn\'t here any more.');
        $owner = $staff ?: (int) $src['created_by'];
        $nid = ClientOrders::create($pdo, $owner, ['name' => (string) $src['bill_name'], 'email' => (string) $src['bill_email'], 'company' => (string) $src['client_company'], 'phone' => (string) $src['client_phone']]);
        $keep = ['bill_street', 'bill_city', 'bill_state', 'bill_zip', 'ship_name', 'ship_street', 'ship_city', 'ship_state', 'ship_zip', 'pay_mode', 'deposit_pct', 'due_terms', 'ship_mode', 'delivery', 'no_ship_reason'];
        $set = []; $vals = []; foreach ($keep as $k) if (array_key_exists($k, $src)) { $set[] = "$k = ?"; $vals[] = $k === 'pay_mode' ? ClientOrders::offeredMode((string) $src[$k]) : $src[$k]; }   // invoice later isn't offered any more (decisions/0101 note, 2026-11-23)
        if ($set) { $vals[] = $nid; $pdo->prepare('UPDATE orders SET ' . implode(', ', $set) . ' WHERE id = ?')->execute($vals); }
        $skip = ['id', 'order_id', 'status', 'approved_at', 'created_at', 'item_status', 'tracking', 'project_id', 'ref_id', 'promo_off_cents', 'collateral_id'];
        $names = [];
        foreach ($items as $c) {
            $st = $pdo->prepare('SELECT * FROM order_lines WHERE id = ?'); $st->execute([(int) $c['source_line_id']]);
            $l = $st->fetch(PDO::FETCH_ASSOC); if (!$l) continue;
            $cols = array_values(array_diff(array_keys($l), $skip));
            $pdo->prepare('INSERT INTO order_lines (order_id, ' . implode(', ', $cols) . ', collateral_id) VALUES (?' . str_repeat(', ?', count($cols)) . ', ?)')->execute(array_merge([$nid], array_map(fn ($k) => $l[$k], $cols), [(int) $c['id']]));
            $lid = (int) $pdo->lastInsertId(); $names[] = $c['name'];
            if (preg_match('/^\d+$/', (string) ($l['ship_to'] ?? ''))) $pdo->prepare("UPDATE order_lines SET ship_to = '' WHERE id = ?")->execute([$lid]);
            $n = max(1, (int) ($qty[(int) $c['id']] ?? $c['qty']));
            if ($l['product'] === 'product') ClientOrders::updateLine($pdo, $nid, $lid, $n, '', (string) $l['note'], $owner);   // today's catalog price for the run
            elseif ($n !== (int) $l['qty']) $pdo->prepare('UPDATE order_lines SET qty = ? WHERE id = ?')->execute([$n, $lid]);
            require_once __DIR__ . '/Costing.php';
            Costing::carry($pdo, (int) $l['id'], $nid, $lid, $owner);   // its costing, re-run at today's costs for the new run (unchecked)
            // its files: the approved proof (a reuse to confirm, with the same art), print-ready files, setups, print files, natives
            foreach (self::files($pdo, $c) as [$label, $fname, $url, $kind, [$t, $rid]]) {
                if ($t === 'p') {
                    if ($kind === 'proof' && !$sameArt) continue;   // new art: a new proof round
                    $r = $pdo->prepare('SELECT * FROM order_proofs WHERE id = ?'); $r->execute([$rid]); $p = $r->fetch(PDO::FETCH_ASSOC); if (!$p) continue;
                    $final = $kind === 'final';
                    if ($final && !$sameArt) continue;
                    $pdo->prepare('INSERT INTO order_proofs (order_id, line_id, version, file_name, mime, status, created_by, kind, reuse_of) VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?)')
                        ->execute([$nid, $lid, $p['file_name'], $p['mime'], $final ? 'approved' : 'waiting', $owner, $final ? 'final' : 'proof', $final ? null : (int) $p['id']]);
                    $np = (int) $pdo->lastInsertId();
                    if (!self::copyFile(ClientOrders::proofPath($p), ClientOrders::proofPlace($pdo, ['id' => $np, 'order_id' => $nid, 'mime' => $p['mime']]))) $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$np]);
                } else {
                    $r = $pdo->prepare('SELECT * FROM order_files WHERE id = ?'); $r->execute([$rid]); $f = $r->fetch(PDO::FETCH_ASSOC); if (!$f) continue;
                    if (!$sameArt && in_array($f['kind'], ['setup', 'print'], true)) continue;   // output files are made again from the new art
                    $pdo->prepare('INSERT INTO order_files (order_id, line_id, kind, file_name, mime, created_by) VALUES (?, ?, ?, ?, ?, ?)')->execute([$nid, $lid, $f['kind'], $f['file_name'], $f['mime'], $owner]);
                    $nf = (int) $pdo->lastInsertId();
                    if (!self::copyFile(ClientOrders::filePath($f), ClientOrders::filePlace($pdo, ['id' => $nf, 'order_id' => $nid, 'mime' => $f['mime']]))) $pdo->prepare('DELETE FROM order_files WHERE id = ?')->execute([$nf]);
                }
            }
        }
        ClientOrders::recalcOrder($pdo, $nid);
        $what = implode(', ', $names) . ($sameArt ? ' (the same art: the client confirms it)' : ' (with changes: a new proof)');
        Orders::event($pdo, $nid, 'drafted', ($requested ? 'Reorder asked for by the client: ' : 'Reorder: ') . $what . ', from order #' . Orders::no($src), $requested ? null : $staff);
        return $nid;
    }
}
