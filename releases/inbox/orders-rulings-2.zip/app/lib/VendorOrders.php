<?php
// app/lib/VendorOrders.php — vendor orders and their jobs (decisions/0106), the way 4OVER publishes them: one vendor order
// (their order #, purchase date, payment, totals) holds jobs for one or more of our client orders. Each job has its
// Project/P.O. name, set name, Job ID, job status, tracking, specs, shipment, facility, completion date, artwork and
// costs. Staff only: a client never sees a vendor, a vendor status or a cost; they see our plain progress ("In
// production", "Work order issued", "Shipped"). Margin (the client's price against our vendor cost) shows to staff.
declare(strict_types=1);

final class VendorOrders
{
    public const KNOWN = ['4OVER', 'Signs365'];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM ' . Database::t('vendor_jobs') . ' LIMIT 1'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    public static function cents(mixed $v): ?int
    {
        $v = trim((string) $v);
        return $v === '' ? null : (int) round((float) preg_replace('/[^0-9.]/', '', $v) * 100);
    }

    /** Vendors used before, most used first, then the known ones. */
    public static function vendors(PDO $pdo): array
    {
        $k = [];
        try { $k = $pdo->query('SELECT vendor FROM ' . Database::t('vendor_orders') . ' GROUP BY vendor ORDER BY COUNT(*) DESC LIMIT 20')->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable) {}
        return array_values(array_unique(array_merge($k, self::KNOWN)));
    }

    /** Recent vendor orders, for adding another job to one ("017633948 · 4OVER"). */
    public static function recent(PDO $pdo, int $limit = 30): array
    {
        try { return $pdo->query('SELECT id, vendor, vendor_order_no, purchased_on FROM ' . Database::t('vendor_orders') . ' ORDER BY id DESC LIMIT ' . (int) $limit)->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) { return []; }
    }

    /** The vendor order with this vendor and number, made if new. */
    public static function findOrCreate(PDO $pdo, string $vendor, string $no, array $in, int $uid): int
    {
        $vendor = mb_substr(trim($vendor), 0, 80); $no = mb_substr(trim($no), 0, 60);
        if ($vendor === '') throw new RuntimeException('Which printer or vendor has it?');
        if ($no !== '') {
            $st = $pdo->prepare('SELECT id FROM ' . Database::t('vendor_orders') . ' WHERE vendor = ? AND vendor_order_no = ?'); $st->execute([$vendor, $no]);
            if ($id = (int) $st->fetchColumn()) return $id;
        }
        $pdo->prepare('INSERT INTO ' . Database::t('vendor_orders') . ' (vendor, vendor_order_no, purchased_on, payment, created_by) VALUES (?, ?, ?, ?, ?)')
            ->execute([$vendor, $no, self::date($in['purchased'] ?? '') ?? date('Y-m-d'), mb_substr(trim((string) ($in['payment'] ?? '')), 0, 60), $uid]);
        return (int) $pdo->lastInsertId();
    }

    private static function date(mixed $v): ?string { return preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $v) ? (string) $v : null; }

    /** Adds a job (a 4OVER "project") for one of our orders to a vendor order. Returns its id. */
    public static function addJob(PDO $pdo, int $oid, array $in, int $uid): int
    {
        require_once __DIR__ . '/Orders.php';
        if (!Orders::get($pdo, $oid)) throw new RuntimeException('That order isn\'t here.');
        if (!empty($in['line_id'])) { $st = $pdo->prepare('SELECT 1 FROM order_lines WHERE id = ? AND order_id = ?'); $st->execute([(int) $in['line_id'], $oid]); if (!$st->fetchColumn()) throw new RuntimeException('That item isn\'t on this order.'); }
        $vo = !empty($in['vendor_order_id']) ? (int) $in['vendor_order_id'] : self::findOrCreate($pdo, (string) ($in['vendor'] ?? ''), (string) ($in['vendor_order_no'] ?? ''), $in, $uid);
        $f = self::fields($in);
        $pdo->prepare('INSERT INTO ' . Database::t('vendor_jobs') . ' (vendor_order_id, order_id, line_id, ' . implode(', ', array_keys($f)) . ', created_by) VALUES (?, ?, ?, ' . implode(', ', array_fill(0, count($f), '?')) . ', ?)')
            ->execute(array_merge([$vo, $oid, !empty($in['line_id']) ? (int) $in['line_id'] : null], array_values($f), [$uid]));
        $id = (int) $pdo->lastInsertId();
        Orders::event($pdo, $oid, 'vendor', 'Sent to ' . self::label($pdo, $id), $uid);
        self::syncItems($pdo, $id, $uid);
        return $id;
    }

    /** Changes a job: its status, tracking, completion date, Job ID, names or costs (only the fields given). */
    public static function updateJob(PDO $pdo, int $jid, array $in, int $uid): void
    {
        $j = self::job($pdo, $jid);
        if (!$j) throw new RuntimeException('That job isn\'t here.');
        $all = self::fields($in);
        $f = array_intersect_key($all, array_flip(array_filter(['po_name', 'set_name', 'job_no', 'job_status', 'tracking', 'completion_on', 'facility', 'note'], fn ($k) => array_key_exists($k, $in))));
        foreach (['subtotal', 'shipping', 'tax'] as $k) if (array_key_exists($k, $in)) $f[$k . '_cents'] = $all[$k . '_cents'];
        if (array_intersect(['subtotal', 'shipping', 'tax', 'total'], array_keys($in))) {
            $m = ['subtotal' => $j['subtotal_cents'], 'shipping' => $j['shipping_cents'], 'tax' => $j['tax_cents']];
            foreach (['subtotal', 'shipping', 'tax'] as $k) if (array_key_exists($k, $in)) $m[$k] = $all[$k . '_cents'];
            $f['total_cents'] = trim((string) ($in['total'] ?? '')) !== '' ? self::cents($in['total']) : (array_filter($m, fn ($x) => $x !== null) ? array_sum(array_filter($m, fn ($x) => $x !== null)) : null);
        }
        if (!$f) return;
        $pdo->prepare('UPDATE ' . Database::t('vendor_jobs') . ' SET ' . implode(', ', array_map(fn ($k) => "$k = ?", array_keys($f))) . ' WHERE id = ?')->execute(array_merge(array_values($f), [$jid]));
        require_once __DIR__ . '/Orders.php';
        Orders::event($pdo, (int) $j['order_id'], 'vendor', 'Updated: ' . self::label($pdo, $jid), $uid);
        self::syncItems($pdo, $jid, $uid);
    }

    /** Ties a job to one item, or back to the whole order (0). */
    public static function setLine(PDO $pdo, int $jid, int $lineId, int $uid): void
    {
        $j = self::job($pdo, $jid);
        if (!$j) throw new RuntimeException('That job isn\'t here.');
        if ($lineId) { $st = $pdo->prepare('SELECT 1 FROM order_lines WHERE id = ? AND order_id = ?'); $st->execute([$lineId, (int) $j['order_id']]); if (!$st->fetchColumn()) throw new RuntimeException('That item isn\'t on this order.'); }
        $pdo->prepare('UPDATE ' . Database::t('vendor_jobs') . ' SET line_id = ? WHERE id = ?')->execute([$lineId ?: null, $jid]);
        // which job covers which item has changed, so every job on the order is applied again (each only moves forward)
        foreach (array_reverse(self::forOrder($pdo, (int) $j['order_id'])) as $x) self::syncItems($pdo, (int) $x['id'], $uid);
    }

    private static function fields(array $in): array
    {
        $s = fn (string $k, int $n) => mb_substr(trim((string) ($in[$k] ?? '')), 0, $n);
        return ['po_name' => $s('po_name', 120), 'set_name' => $s('set_name', 80), 'job_no' => $s('job_no', 60), 'job_status' => $s('job_status', 60),
            'tracking' => $s('tracking', 160), 'sku' => $s('sku', 160), 'specs' => $s('specs', 500), 'run_size' => $s('run_size', 30), 'turnaround' => $s('turnaround', 40),
            'facility' => $s('facility', 80), 'completion_on' => self::date($in['completion_on'] ?? ''), 'ship_to' => $s('ship_to', 200), 'ship_method' => $s('ship_method', 60),
            'artwork_url' => preg_match('#^https?://#i', (string) ($in['artwork_url'] ?? '')) ? $s('artwork_url', 500) : '',
            'subtotal_cents' => self::cents($in['subtotal'] ?? ''), 'shipping_cents' => self::cents($in['shipping'] ?? ''), 'tax_cents' => self::cents($in['tax'] ?? ''),
            'total_cents' => self::total($in),
            'note' => $s('note', 500)];
    }

    /** The total: as given, or the sum of subtotal, shipping and tax when any is given. */
    private static function total(array $in): ?int
    {
        if (trim((string) ($in['total'] ?? '')) !== '') return self::cents($in['total']);
        $parts = array_filter([self::cents($in['subtotal'] ?? ''), self::cents($in['shipping'] ?? ''), self::cents($in['tax'] ?? '')], fn ($x) => $x !== null);
        return $parts ? array_sum($parts) : null;
    }

    public static function job(PDO $pdo, int $jid): ?array
    {
        $st = $pdo->prepare('SELECT j.*, v.vendor, v.vendor_order_no FROM ' . Database::t('vendor_jobs') . ' j JOIN ' . Database::t('vendor_orders') . ' v ON v.id = j.vendor_order_id WHERE j.id = ?'); $st->execute([$jid]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** "4OVER #017633948 · Auto App Ai BC-Paul S. · job J6692184222-002 · Batch Imposition · $22.50" */
    public static function label(PDO $pdo, int $jid): string
    {
        $j = self::job($pdo, $jid);
        if (!$j) return '';
        return $j['vendor'] . ($j['vendor_order_no'] !== '' && !str_starts_with($j['vendor_order_no'], 'old-') ? ' #' . $j['vendor_order_no'] : '') . ($j['po_name'] !== '' ? ' · ' . $j['po_name'] : '')
            . ($j['job_no'] !== '' ? ' · job ' . $j['job_no'] : '') . ($j['job_status'] !== '' ? ' · ' . $j['job_status'] : '') . ($j['tracking'] !== '' ? ' · tracking ' . $j['tracking'] : '')
            . ($j['total_cents'] !== null ? ' · $' . number_format($j['total_cents'] / 100, 2) : '');
    }

    /** The items a job can be for: printed items on the order (not shipping, GO Codes or cancelled ones). */
    public static function items(PDO $pdo, int $oid): array
    {
        $st = $pdo->prepare("SELECT id, title FROM order_lines WHERE order_id = ? AND product NOT IN ('shipping', 'go_code') AND status <> 'cancelled' ORDER BY id"); $st->execute([$oid]);
        return array_map(fn ($r) => ['id' => (int) $r['id'], 'title' => (string) $r['title']], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /** The jobs on one of our orders, newest first. */
    public static function forOrder(PDO $pdo, int $oid): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT j.*, v.vendor, v.vendor_order_no, v.purchased_on FROM ' . Database::t('vendor_jobs') . ' j JOIN ' . Database::t('vendor_orders') . ' v ON v.id = j.vendor_order_id WHERE j.order_id = ? ORDER BY j.id DESC');
        $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Staff only: the client's price (before tax) against our vendor cost. null when no costs are recorded. */
    public static function margin(PDO $pdo, array $o): ?array
    {
        $cost = 0; $any = false;
        foreach (self::forOrder($pdo, (int) $o['id']) as $j) if ($j['total_cents'] !== null) { $cost += (int) $j['total_cents']; $any = true; }
        if (!$any) return null;
        $price = (int) $o['subtotal_cents'];
        return ['price' => $price, 'cost' => $cost, 'margin' => $price - $cost, 'pct' => $price ? round(($price - $cost) / $price * 100) : 0];
    }

    /** The latest tracking a vendor gave for this order (to fill Mark shipped). */
    public static function tracking(PDO $pdo, int $oid): string
    {
        foreach (self::forOrder($pdo, $oid) as $j) if ($j['tracking'] !== '') return (string) $j['tracking'];
        return '';
    }

    /** Vendor orders with their jobs for the list (4OVER's layout). $q searches order #, P.O., job ID, client, item. */
    public static function listing(PDO $pdo, string $vendor = '', string $q = '', bool $open = false, int $limit = 60): array
    {
        if (!self::ready($pdo)) return [];
        $w = []; $a = [];
        if ($vendor !== '') { $w[] = 'v.vendor = ?'; $a[] = $vendor; }
        if ($q !== '') { $w[] = '(v.vendor_order_no LIKE ? OR j.po_name LIKE ? OR j.job_no LIKE ? OR o.client_company LIKE ? OR o.bill_name LIKE ? OR l.title LIKE ?)'; array_push($a, ...array_fill(0, 6, '%' . $q . '%')); }
        if ($open) $w[] = "(j.id IS NULL OR j.job_status NOT LIKE '%Complete%')";
        $st = $pdo->prepare('SELECT v.*, j.id AS jid, j.order_id, j.po_name, j.set_name, j.job_no, j.job_status, j.tracking, j.ship_to, j.ship_method, j.artwork_url, j.total_cents AS job_total, j.completion_on, j.line_id, l.title AS line_title, l.item_status AS line_status,
              o.client_company, o.bill_name, o.subtotal_cents AS client_price, o.created_at AS o_created
            FROM ' . Database::t('vendor_orders') . ' v LEFT JOIN ' . Database::t('vendor_jobs') . ' j ON j.vendor_order_id = v.id LEFT JOIN orders o ON o.id = j.order_id LEFT JOIN order_lines l ON l.id = j.line_id'
            . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY v.id DESC, j.id LIMIT ' . (int) $limit);
        $st->execute($a);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $out[(int) $r['id']]['order'] = $r; if ($r['jid']) $out[(int) $r['id']]['jobs'][] = $r; }
        return $out;
    }

    // ---- Paste from 4OVER: the text of a 4OVER order page (Ctrl+A, Ctrl+C), read into a vendor order and its jobs ------

    /**
     * Reads a 4OVER order page's text. Returns [vendor, vendor_order_no, purchased (Y-m-d), payment ("MasterCard ••1852"),
     * subtotal, shipping, total (dollars), projects: [po_name, sku, specs, run_size, turnaround, subtotal, shipping, tax,
     * total, ship_to, ship_name, ship_company, ship_method, facility, completion_on, sets: [set_name, job_no, job_status,
     * tracking, cost]]]. Throws when it isn't a 4OVER order page.
     */
    public static function parse4over(string $text): array
    {
        $L = array_values(array_filter(array_map(fn ($l) => trim(preg_replace('/\s+/u', ' ', $l)), preg_split('/\R/u', $text)), fn ($l) => $l !== ''));
        $all = implode("\n", $L);
        if (!preg_match('/Order\s*#\s*(\d{5,})/i', $all, $m)) throw new RuntimeException('That doesn\'t look like a 4OVER order page: no "Order #" in it. Copy the whole page (Ctrl+A, Ctrl+C) and paste again.');
        $out = ['vendor' => '4OVER', 'vendor_order_no' => $m[1], 'purchased' => null, 'payment' => '', 'subtotal' => null, 'shipping' => null, 'total' => null, 'projects' => []];
        if (preg_match('#Purchased:\s*(\d{1,2})/(\d{1,2})/(\d{2,4})#i', $all, $d)) $out['purchased'] = sprintf('%04d-%02d-%02d', strlen($d[3]) === 2 ? 2000 + (int) $d[3] : (int) $d[3], $d[1], $d[2]);
        $type = preg_match('/Credit Card Type\s+([A-Za-z ]+?)\s*$/mi', $all, $c) ? trim($c[1]) : '';
        $last = preg_match('/Credit Card Number\s+[X*•x]*\s*(\d{4})/i', $all, $c) ? $c[1] : '';
        $out['payment'] = trim($type . ($last !== '' ? ' ••' . $last : ''));
        $year = $out['purchased'] ? (int) substr($out['purchased'], 0, 4) : (int) date('Y');
        $money = function (array $lines, string $label) {   // "$9.25" on the label's line or the next one
            foreach ($lines as $i => $l) {
                if (stripos($l, $label) !== 0) continue;
                if (preg_match('/\$\s*([\d,]+\.\d{2})/', $l, $m)) return (float) str_replace(',', '', $m[1]);
                if (isset($lines[$i + 1]) && preg_match('/^\$\s*([\d,]+\.\d{2})$/', $lines[$i + 1], $m)) return (float) str_replace(',', '', $m[1]);
            }
            return null;
        };
        $after = function (array $lines, string $label): string { foreach ($lines as $i => $l) if (strcasecmp($l, $label) === 0) return (string) ($lines[$i + 1] ?? ''); return ''; };
        // the order totals
        $tot = ($k = array_search('Order Totals', $L, true)) !== false ? array_slice($L, $k, 8) : [];
        $out['subtotal'] = $money($tot, 'Subtotal'); $out['shipping'] = $money($tot, 'Shipping & Processing'); $out['total'] = $money($tot, 'Grand Total');
        // each project, up to the next one or the order totals
        $starts = array_keys(array_filter($L, fn ($l) => stripos($l, 'Project/P.O. #:') === 0));
        foreach ($starts as $n => $st) {
            $end = $starts[$n + 1] ?? ($k !== false ? $k : count($L));
            $P = array_slice($L, $st, $end - $st);
            $pr = ['po_name' => trim(substr($P[0], strlen('Project/P.O. #:')))];
            $spec = [];
            foreach ($P as $l) if (preg_match('/^(SKU|Size|Shape|Stock|Colorspec|Coating|SPOT UV SIDES|Run Size|Turnaround Time):\s*(.+)$/i', $l, $m)) $spec[strtolower($m[1])] = $m[2];
            $pr['sku'] = str_replace(' ', '', (string) ($spec['sku'] ?? ''));
            $pr['specs'] = implode(' · ', array_filter([$spec['size'] ?? '', $spec['shape'] ?? '', $spec['stock'] ?? '', $spec['colorspec'] ?? '', isset($spec['coating']) ? $spec['coating'] . ' coating' : '', $spec['spot uv sides'] ?? '']));
            $pr['run_size'] = (string) ($spec['run size'] ?? ''); $pr['turnaround'] = (string) ($spec['turnaround time'] ?? '');
            $pc = ($a = array_search('Project Cost', $P, true)) !== false ? array_slice($P, $a, 9) : [];
            $pr['subtotal'] = $money($pc, 'Subtotal'); $pr['shipping'] = $money($pc, 'Shipping & Processing'); $pr['tax'] = $money($pc, 'Tax'); $pr['total'] = $money($pc, 'Grand Total');
            // ship to: the lines between "Ship to" and "Shipping method", less the country and the phone
            $ship = [];
            if (($a = array_search('Ship to', $P, true)) !== false) for ($i = $a + 1; $i < count($P) && strcasecmp($P[$i], 'Shipping method') !== 0; $i++) if (!preg_match('/^(United States|T:)/i', $P[$i])) $ship[] = $P[$i];
            $pr['ship_name'] = $ship[0] ?? ''; $pr['ship_company'] = isset($ship[1]) && !preg_match('/^\d/', $ship[1]) ? $ship[1] : '';
            $pr['ship_to'] = implode(', ', $ship);
            $pr['ship_method'] = $after($P, 'Shipping method'); $pr['facility'] = $after($P, 'Production Facility');
            $cd = $after($P, 'Turnaround Completion Date'); $pr['completion_on'] = null;
            if ($cd !== '' && ($ts = strtotime(preg_replace('/^[A-Za-z]+,\s*/', '', $cd) . ' ' . $year))) {
                if ($out['purchased'] && $ts < strtotime($out['purchased']) - 86400 * 30) $ts = strtotime('+1 year', $ts);   // ordered in December, done in January
                $pr['completion_on'] = date('Y-m-d', $ts);
            }
            // the sets: Set Name / Job ID / Job Status (Track Shipment, tracking) / View / cost
            $pr['sets'] = [];
            foreach ($P as $i => $l) {
                if (!preg_match('/^J\d{6,}-\d+$/', $l)) continue;
                $set = ['set_name' => $P[$i - 1] ?? '', 'job_no' => $l, 'job_status' => '', 'tracking' => '', 'cost' => null];
                $stat = [];
                for ($j = $i + 1; $j < count($P) && !preg_match('/^J\d{6,}-\d+$/', $P[$j]); $j++) {
                    if (strcasecmp($P[$j], 'Track Shipment') === 0) { $set['tracking'] = (string) ($P[$j + 1] ?? ''); $j++; continue; }
                    if (strcasecmp($P[$j], 'View') === 0) continue;
                    if (preg_match('/^\$\s*([\d,]+\.\d{2})$/', $P[$j], $m)) { $set['cost'] = (float) str_replace(',', '', $m[1]); break; }
                    $stat[] = $P[$j];
                }
                $set['job_status'] = implode(' ', $stat);
                $pr['sets'][] = $set;
            }
            if (!$pr['sets']) $pr['sets'][] = ['set_name' => '', 'job_no' => '', 'job_status' => '', 'tracking' => '', 'cost' => $pr['total']];
            $out['projects'][] = $pr;
        }
        if (!$out['projects']) throw new RuntimeException('No projects found on that page. Copy the order\'s own page (Order # … with its projects), not the order list.');
        return $out;
    }

    /** For each project of a parsed page: the job already saved (by Job ID), or the client order that best matches its ship-to. */
    public static function match4over(PDO $pdo, array $parsed): array
    {
        $orders = [];
        try { $orders = $pdo->query("SELECT id, created_at, bill_name, client_company, ship_name, status FROM orders WHERE created_by > 0 AND status NOT IN ('void','draft') ORDER BY id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) {}
        $norm = fn ($x) => preg_replace('/[^a-z0-9]/', '', strtolower((string) $x));
        $out = [];
        foreach ($parsed['projects'] as $n => $pr) {
            $known = null;
            foreach ($pr['sets'] as $set) if ($set['job_no'] !== '' && self::ready($pdo)) {
                $st = $pdo->prepare('SELECT order_id FROM ' . Database::t('vendor_jobs') . ' WHERE job_no = ? LIMIT 1'); $st->execute([$set['job_no']]);
                if ($o = (int) $st->fetchColumn()) { $known = $o; break; }
            }
            $best = 0; $score = 0;
            if (!$known) foreach ($orders as $o) {
                $sc = 0;
                if ($pr['ship_name'] !== '' && in_array($norm($pr['ship_name']), [$norm($o['ship_name']), $norm($o['bill_name'])], true)) $sc += 3;
                if ($pr['ship_company'] !== '' && $norm($pr['ship_company']) === $norm($o['client_company'])) $sc += 2;
                if ($o['client_company'] !== '' && str_contains($norm($pr['po_name']), $norm($o['client_company']))) $sc += 1;
                if ($sc > $score) { $score = $sc; $best = (int) $o['id']; }
            }
            $out[$n] = ['order_id' => $known ?: ($score >= 2 ? $best : 0), 'known' => (bool) $known];
        }
        return ['matches' => $out, 'orders' => array_map(fn ($o) => ['id' => (int) $o['id'], 'label' => date('Y-md', strtotime((string) $o['created_at'])) . '-' . str_pad((string) $o['id'], 5, '0', STR_PAD_LEFT) . ' · ' . ($o['client_company'] ?: $o['bill_name'])], $orders)];
    }

    /**
     * Saves a parsed page: the vendor order (made or updated by its number) and each set as a job, updated by its Job ID
     * when it's already saved, or added to the client order chosen for its project ($orderFor[project index]; 0 skips it).
     * Returns [added, updated, skipped].
     */
    public static function import4over(PDO $pdo, array $p, array $orderFor, int $uid): array
    {
        $vid = self::findOrCreate($pdo, '4OVER', (string) $p['vendor_order_no'], ['purchased' => $p['purchased'], 'payment' => $p['payment']], $uid);
        $pdo->prepare('UPDATE ' . Database::t('vendor_orders') . ' SET purchased_on = COALESCE(?, purchased_on), payment = IF(? <> \'\', ?, payment), subtotal_cents = ?, shipping_cents = ?, total_cents = ? WHERE id = ?')
            ->execute([$p['purchased'], $p['payment'], $p['payment'], self::cents($p['subtotal']), self::cents($p['shipping']), self::cents($p['total']), $vid]);
        $n = ['added' => 0, 'updated' => 0, 'skipped' => 0];
        foreach ($p['projects'] as $i => $pr) {
            $multi = count($pr['sets']) > 1;
            foreach ($pr['sets'] as $set) {
                $f = ['po_name' => $pr['po_name'], 'set_name' => $set['set_name'], 'job_no' => $set['job_no'], 'job_status' => $set['job_status'], 'tracking' => $set['tracking'],
                    'sku' => $pr['sku'], 'specs' => $pr['specs'], 'run_size' => $pr['run_size'], 'turnaround' => $pr['turnaround'], 'facility' => $pr['facility'],
                    'completion_on' => $pr['completion_on'], 'ship_to' => $pr['ship_to'], 'ship_method' => $pr['ship_method'],
                    'subtotal' => $multi ? '' : (string) $pr['subtotal'], 'shipping' => $multi ? '' : (string) $pr['shipping'], 'tax' => $multi ? '' : (string) $pr['tax'],
                    'total' => (string) ($multi ? $set['cost'] : ($pr['total'] ?? $set['cost']))];
                $jid = 0;
                if ($set['job_no'] !== '') { $st = $pdo->prepare('SELECT id FROM ' . Database::t('vendor_jobs') . ' WHERE job_no = ? LIMIT 1'); $st->execute([$set['job_no']]); $jid = (int) $st->fetchColumn(); }
                if ($jid) { self::updateJob($pdo, $jid, $f, $uid); $n['updated']++; continue; }
                $oid = (int) ($orderFor[$i] ?? 0);
                if (!$oid) { $n['skipped']++; continue; }
                self::addJob($pdo, $oid, $f + ['vendor_order_id' => $vid, 'line_id' => self::lineFor($pdo, $oid, $pr)], $uid); $n['added']++;
            }
        }
        return $n;
    }

    // ---- Item statuses from the vendor (decisions/0107) --------------------------------------------------------------

    /** The vendor's words as our item status: [status, tracking] or null when they don't say anything we act on. */
    public static function itemStatusFor(string $vendorStatus, string $tracking): ?string
    {
        $v = strtolower($vendorStatus);
        if ($v === '') return null;
        if (str_contains($v, 'deliver')) return 'delivered';
        if (str_contains($v, 'pickup') || str_contains($v, 'pick up') || str_contains($v, 'ready for')) return 'ready';
        if (str_contains($v, 'ship') || $tracking !== '') return 'shipped';
        if (preg_match('/cut|finish|pack|bindery|trim/', $v)) return 'finishing';
        if (preg_match('/print|press|imposition|prepress|processing|production|plate|queue/', $v)) return 'production';
        return null;
    }

    /**
     * Moves our items on from a vendor job: a job tied to an item moves that item; a job on the order (no item) moves
     * every printed item that hasn't a job of its own (Jason: the invoice's vendor unless the item says otherwise). Only
     * forward, never past what our team set by hand, never out of a hold or housekeeping status, and never out the door
     * before the order is paid in full (ClientOrders::shipHold). The client isn't emailed; our team sends updates.
     */
    public static function syncItems(PDO $pdo, int $jid, int $uid): int
    {
        require_once __DIR__ . '/ClientOrders.php';
        $j = self::job($pdo, $jid);
        if (!$j) return 0;
        $to = self::itemStatusFor((string) $j['job_status'], (string) $j['tracking']);
        if (!$to) return 0;
        $o = Orders::get($pdo, (int) $j['order_id']);
        if (!$o || !ClientOrders::isClient($o) || !ClientOrders::hasItems($pdo)) return 0;
        if (in_array($to, ClientOrders::OUT_DOOR, true) && ClientOrders::shipHold($pdo, $o) !== '') return 0;   // out the door waits for the balance (model 1.9); the order's Pulse case asks for it
        $rank = []; $i = 0;
        foreach (['Before approval', 'Approved', 'Out the door'] as $g) foreach (array_keys(ClientOrders::ITEM_STATUS[$g]) as $k) $rank[$k] = $i++;
        $own = [];
        foreach (self::forOrder($pdo, (int) $o['id']) as $x) if ($x['line_id']) $own[(int) $x['line_id']] = true;
        $n = 0;
        foreach (Orders::lines($pdo, (int) $o['id']) as $l) {
            if (in_array($l['product'], ['shipping', 'go_code'], true) || $l['status'] === 'cancelled') continue;
            if ($j['line_id'] ? (int) $l['id'] !== (int) $j['line_id'] : isset($own[(int) $l['id']])) continue;
            $cur = ClientOrders::itemStatus($o, $l);
            if (!isset($rank[$cur]) || $rank[$cur] >= $rank[$to]) continue;   // holds and housekeeping stay; never backwards
            ClientOrders::setItemStatus($pdo, (int) $o['id'], (int) $l['id'], $to, in_array($to, ['shipped', 'delivered'], true) ? (string) $j['tracking'] : (string) ($l['tracking'] ?? ''), $uid);
            $n++;
        }
        return $n;
    }

    /** The item a parsed 4OVER project is clearly for, by set name, ship-to name and address against each item; 0 when unclear. */
    public static function lineFor(PDO $pdo, int $oid, array $pr): int
    {
        require_once __DIR__ . '/Orders.php';
        $norm = fn ($x) => preg_replace('/[^a-z0-9 ]/', '', strtolower((string) $x));
        $first = strtok($norm($pr['ship_name'] ?? ''), ' ') ?: '';
        $street = strtok($norm(explode(',', (string) ($pr['ship_to'] ?? ''))[2] ?? ''), ' ') ?: '';   // the street number
        $best = 0; $bestScore = 0; $tie = false;
        foreach (Orders::lines($pdo, $oid) as $l) {
            if (in_array($l['product'], ['shipping', 'go_code'], true) || $l['status'] === 'cancelled') continue;
            $hay = $norm($l['title'] . ' ' . $l['note'] . ' ' . ($l['ship_address'] ?? '') . ' ' . ($l['ship_to'] ?? ''));
            $sc = 0;
            if ($first !== '' && preg_match('/\b' . preg_quote($first, '/') . '\b/', $hay)) $sc += 2;
            if ($pr['ship_name'] !== '' && str_contains($hay, $norm($pr['ship_name']))) $sc += 2;
            if ($street !== '' && preg_match('/\b' . preg_quote($street, '/') . '\b/', $hay)) $sc += 2;
            if ($sc > $bestScore) { $best = (int) $l['id']; $bestScore = $sc; $tie = false; } elseif ($sc && $sc === $bestScore) $tie = true;
        }
        return $bestScore >= 2 && !$tie ? $best : 0;
    }
}
