<?php
// app/admin/Workflow.php — the workflow engine (decisions/0109 A4). A workflow is stages, the moves between them (who
// may make each, what it checks, what it asks for, what happens after) and actions allowed at any stage. Workflows are
// built and edited in the admin (System Configuration → Workflows, Managers and up) and published as versions.
//
// The built-in workflows (app/admin/workflows.php) follow things the site already keeps (an order's status, a lead's
// stage…): each has an adapter that reads where an item is and does the protected moves through the library that
// owns them (ClientOrders::send…). Those moves and their checks can't be removed in the builder; stages can be renamed,
// timed, owned, and new ones added between them. A workflow made in the builder keeps its own items (wf_items).
//
// Every move goes through move(): allowed for this item, stage, person and version → its checks → the move → the
// history → what happens after (a failure there is recorded on the item, never half a move).
declare(strict_types=1);

require_once __DIR__ . '/Access.php';

final class Workflow
{
    /** What a move can check, by name (the builder offers these; code supplies them). key => [label, fn(PDO, id, def): true|string]. */
    public static function checks(): array
    {
        return [
            'note' => ['A note is written', fn () => true],   // asked for by the move; kept for the builder's list
            'proofs_approved' => ['Every proof is approved', function (PDO $pdo, int $id) {
                $n = (int) $pdo->query("SELECT COUNT(*) FROM order_proofs WHERE order_id = $id AND status IN ('waiting', 'changes')")->fetchColumn();
                return $n ? 'Some proofs aren\'t approved yet.' : true; }],
            'paid_in_full' => ['Paid in full', function (PDO $pdo, int $id) {
                require_once __DIR__ . '/../lib/Orders.php';
                $o = Orders::get($pdo, $id); if (!$o) return 'Not found.';
                require_once __DIR__ . '/../lib/ClientOrders.php';   // one rule on every path (decisions/0101, note of 2026-11-20, B.4)
                $why = ClientOrders::shipHold($pdo, $o);
                return $why === '' ? true : $why; }],
            'has_owner' => ['It has an owner', fn (PDO $pdo, int $id, array $item) => !empty($item['owner_id']) ? true : 'Assign it to someone first.'],
        ];
    }

    /** What can happen after a move, by name. key => [label, params (name => label), fn(PDO, wfKey, id, params, item, actor)]. */
    public static function effects(): array
    {
        return [
            'email' => ['Send an email', ['to' => 'To (owner, client, or an address)', 'subject' => 'Subject', 'body' => 'Message ({title} for the item)'], function (PDO $pdo, string $wf, int $id, array $p, array $item) {
                $to = (string) ($p['to'] ?? 'owner');
                if ($to === 'owner') { $st = $pdo->prepare('SELECT email FROM users WHERE id = ?'); $st->execute([(int) ($item['owner_id'] ?? 0)]); $to = (string) $st->fetchColumn(); }
                elseif ($to === 'client') $to = (string) ($item['client_email'] ?? '');
                if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return 'no address to email';
                require_once __DIR__ . '/../lib/Mailer.php';
                $t = fn (string $s) => str_replace('{title}', (string) ($item['title'] ?? ''), $s);
                Mailer::send($to, $t((string) ($p['subject'] ?? 'An update')), $t((string) ($p['body'] ?? '')) . "\n\nTraversence\n");
                return 'emailed ' . $to; }],
            'assign' => ['Give it to someone', ['user' => 'Staff member (member #)'], function (PDO $pdo, string $wf, int $id, array $p) {
                $pdo->prepare('UPDATE ' . Database::t('wf_items') . ' SET owner_id = ? WHERE wf_key = ? AND item_id = ?')->execute([(int) ($p['user'] ?? 0) ?: null, $wf, $id]);
                return 'assigned'; }],
        ];
    }

    // ---- definitions ---------------------------------------------------------------------------------------------------

    /** The built-in workflows' code: [key => ['name', 'module', 'entity', 'def' (defaults), 'adapter' => [...]]]. */
    public static function builtins(): array
    {
        static $b = null;
        return $b ??= require __DIR__ . '/workflows.php';
    }

    public static function ready(PDO $pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('wf_workflows') . ' LIMIT 0'); return true; } catch (Throwable) { return false; } }

    /** Built-in workflows get their first version from the code's defaults, once. */
    public static function seed(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        foreach (self::builtins() as $k => $b) {
            $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('wf_workflows') . ' WHERE wf_key = ?'); $st->execute([$k]);
            if ($st->fetchColumn()) continue;
            $pdo->prepare('INSERT INTO ' . Database::t('wf_workflows') . ' (wf_key, name, module, entity, builtin, version) VALUES (?, ?, ?, ?, 1, 1)')->execute([$k, $b['name'], $b['module'], $b['entity']]);
            $pdo->prepare("INSERT INTO " . Database::t('wf_versions') . " (wf_key, version, def, note) VALUES (?, 1, ?, 'Built in')")->execute([$k, json_encode($b['def'], JSON_UNESCAPED_UNICODE)]);
        }
    }

    public static function all(PDO $pdo): array
    {
        self::seed($pdo);
        return $pdo->query('SELECT * FROM ' . Database::t('wf_workflows') . ' ORDER BY module, name')->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function meta(PDO $pdo, string $key): array
    {
        self::seed($pdo);
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('wf_workflows') . ' WHERE wf_key = ?'); $st->execute([$key]);
        $w = $st->fetch(PDO::FETCH_ASSOC);
        if (!$w) throw new InvalidArgumentException('That workflow isn\'t here.');
        return $w;
    }

    /** A version's definition (the published one by default). */
    public static function def(PDO $pdo, string $key, int $version = 0): array
    {
        static $cache = [];
        $w = self::meta($pdo, $key);
        $v = $version ?: (int) $w['version'];
        if (isset($cache["$key/$v"])) return $cache["$key/$v"];
        $st = $pdo->prepare('SELECT def FROM ' . Database::t('wf_versions') . ' WHERE wf_key = ? AND version = ?'); $st->execute([$key, $v]);
        $d = json_decode((string) $st->fetchColumn(), true) ?: ['stages' => [], 'moves' => [], 'any' => []];
        return $cache["$key/$v"] = $d + ['moves' => [], 'any' => []];
    }

    public static function stageMap(array $def): array { $m = []; foreach ($def['stages'] as $s) $m[$s['key']] = $s; return $m; }

    // ---- items ---------------------------------------------------------------------------------------------------------

    /**
     * Where an item is: ['stage' => key, 'version', 'entered_at', 'owner_id', 'title', 'client_email'…]. A built-in
     * workflow reads the item's own state (its adapter); a stage added in the builder between system ones is kept in
     * wf_items as long as it stands for the same system state.
     */
    public static function item(PDO $pdo, string $key, int $id): array
    {
        $w = self::meta($pdo, $key);
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('wf_items') . ' WHERE wf_key = ? AND item_id = ?'); $st->execute([$key, $id]);
        $row = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        $ad = self::builtins()[$key]['adapter'] ?? null;
        $info = $ad ? (($ad['info'])($pdo, $id) ?: null) : null;
        if ($ad && !$info) throw new InvalidArgumentException('That item isn\'t here.');
        $version = $row ? (int) $row['version'] : (int) $w['version'];
        $def = self::def($pdo, $key, $version);
        $stages = self::stageMap($def);
        if ($ad) {
            $sys = (string) $info['stage'];   // the system's own stage key
            $stage = $sys;
            if ($row && isset($stages[$row['stage']]) && (($stages[$row['stage']]['system'] ?? $row['stage']) === $sys)) $stage = $row['stage'];
            foreach ($stages as $k => $s) if (!isset($stages[$stage]) && ($s['system'] ?? $k) === $sys) { $stage = $k; break; }
            return ['stage' => $stage, 'version' => $version, 'entered_at' => $row['entered_at'] ?? ($info['since'] ?? null), 'owner_id' => $row['owner_id'] ?? ($info['owner_id'] ?? null)] + $info;
        }
        if (!$row) throw new InvalidArgumentException('That item isn\'t here.');
        return ['stage' => $row['stage'], 'version' => $version, 'entered_at' => $row['entered_at'], 'owner_id' => $row['owner_id'], 'title' => $row['title']];
    }

    /** The moves from where the item is, each with whether this person may make it and why not. */
    public static function moves(PDO $pdo, string $key, int $id, ?array $item = null): array
    {
        $item ??= self::item($pdo, $key, $id);
        $def = self::def($pdo, $key, (int) $item['version']);
        $stages = self::stageMap($def);
        $out = [];
        foreach ($def['moves'] as $m) {
            $from = (array) ($m['from'] ?? []);
            if (!in_array('*', $from, true) && !in_array($item['stage'], $from, true)) continue;
            if (($m['to'] ?? '') === $item['stage'] && !in_array($item['stage'], $from, true)) continue;   // "send again" stays
            [$ok, $why] = !empty($m['auto']) ? [false, 'Happens on its own: ' . $m['auto']] : Access::can($key . '.move.' . $m['key'], self::who($m));
            $out[] = ['key' => $m['key'], 'label' => $m['label'] ?? ($stages[$m['to']]['label'] ?? $m['to']), 'to' => $m['to'], 'asks' => array_values((array) ($m['asks'] ?? [])), 'allowed' => $ok, 'why' => $why];
        }
        foreach ($def['any'] as $a) {
            [$ok, $why] = Access::can($key . '.act.' . $a['key'], self::who($a));
            $out[] = ['key' => $a['key'], 'label' => $a['label'], 'to' => '', 'any' => true, 'asks' => array_values((array) ($a['asks'] ?? [])), 'allowed' => $ok, 'why' => $why, 'link' => $a['link'] ?? ''];
        }
        return $out;
    }

    private static function who(array $m): array { $w = (array) ($m['who'] ?? []); return ['min' => (string) ($w['min'] ?? 'staff'), 'depts' => array_values((array) ($w['depts'] ?? []))]; }

    /** Makes a move (or an any-stage action) on an item. $in: what the move asked for (note, tracking…). Returns the item. */
    public static function move(PDO $pdo, string $key, int $id, string $moveKey, array $in, int $actor): array
    {
        $item = self::item($pdo, $key, $id);
        $def = self::def($pdo, $key, (int) $item['version']);
        $m = null; $any = false;
        foreach ($def['moves'] as $x) if ($x['key'] === $moveKey) { $m = $x; break; }
        if (!$m) foreach ($def['any'] as $x) if ($x['key'] === $moveKey) { $m = $x; $any = true; break; }
        if (!$m) throw new InvalidArgumentException('That move isn\'t part of this workflow.');
        if (!$any && !in_array('*', (array) $m['from'], true) && !in_array($item['stage'], (array) $m['from'], true)) throw new RuntimeException('It can\'t move that way from where it is now.');
        if (!empty($m['auto'])) throw new RuntimeException('That happens on its own: ' . $m['auto'] . '.');
        [$ok, $why] = Access::can($key . ($any ? '.act.' : '.move.') . $moveKey, self::who($m));
        if (!$ok) throw new RuntimeException($why . '.');
        foreach ((array) ($m['asks'] ?? []) as $a) if (trim((string) ($in[$a] ?? '')) === '') throw new RuntimeException('Add the ' . str_replace('_', ' ', $a) . ' first.');
        $checks = self::checks();
        foreach ((array) ($m['checks'] ?? []) as $c) if (isset($checks[$c])) { $r = ($checks[$c][1])($pdo, $id, $item); if ($r !== true) throw new RuntimeException((string) $r); }
        $ad = self::builtins()[$key]['adapter'] ?? null;
        $to = (string) ($m['to'] ?? '');
        $stages = self::stageMap($def);
        if (!$any && !isset($stages[$to])) throw new RuntimeException('That move leads to a stage that isn\'t in the workflow.');
        // the protected part: the library that owns the item does it
        $op = (string) ($m['op'] ?? ($to !== '' ? ($stages[$to]['op'] ?? '') : ''));
        if ($ad && $op !== '') {
            if (!isset($ad['ops'][$op])) throw new RuntimeException('This move\'s action isn\'t available.');
            ($ad['ops'][$op])($pdo, $id, $in, $actor, $to);
        }
        if (!$any) {
            $pdo->prepare('INSERT INTO ' . Database::t('wf_items') . ' (wf_key, item_id, version, stage, entered_at, owner_id, title) VALUES (?, ?, ?, ?, NOW(), ?, ?)
                           ON DUPLICATE KEY UPDATE stage = VALUES(stage), entered_at = NOW(), version = VALUES(version)')
                ->execute([$key, $id, (int) $item['version'], $to, $item['owner_id'] ?: null, mb_substr((string) ($item['title'] ?? ''), 0, 160)]);
        }
        $hist = $pdo->prepare('INSERT INTO ' . Database::t('wf_history') . ' (wf_key, item_id, version, move, from_stage, to_stage, actor, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $hist->execute([$key, $id, (int) $item['version'], $moveKey, $item['stage'], $any ? $item['stage'] : $to, $actor ?: null, mb_substr(trim((string) ($in['note'] ?? '')), 0, 1000)]);
        $hid = (int) $pdo->lastInsertId();
        // what happens after: each one recorded; a failure is noted on the item, the move stands
        $done = [];
        $fx = self::effects();
        foreach ((array) ($m['effects'] ?? []) as $e) {
            $k = (string) ($e['do'] ?? '');
            if (!isset($fx[$k])) continue;
            try { $done[] = (string) ($fx[$k][2])($pdo, $key, $id, (array) ($e['params'] ?? []), $item, $actor); }
            catch (Throwable $x) { $done[] = 'failed: ' . $fx[$k][0] . ' (' . mb_substr($x->getMessage(), 0, 120) . ')'; }
        }
        if ($done) $pdo->prepare('UPDATE ' . Database::t('wf_history') . ' SET effects = ? WHERE id = ?')->execute([mb_substr(implode('; ', $done), 0, 1000), $hid]);
        try { $pdo->prepare('INSERT INTO ' . Database::t('audit_log') . ' (actor_user, actor_staff, route, action, detail) VALUES (?, ?, ?, ?, ?)')
            ->execute([$actor ?: null, (int) (Access::staff()['id'] ?? 0) ?: null, 'workflow:' . $key . ':' . $id, 'workflow.' . $moveKey, mb_substr(($item['stage'] ?? '') . ' → ' . ($any ? '(action)' : $to), 0, 250)]); } catch (Throwable) {}
        return self::item($pdo, $key, $id);
    }

    public static function history(PDO $pdo, string $key, int $id): array
    {
        $st = $pdo->prepare('SELECT h.*, u.display_name, u.email FROM ' . Database::t('wf_history') . ' h LEFT JOIN users u ON u.id = h.actor WHERE h.wf_key = ? AND h.item_id = ? ORDER BY h.id DESC LIMIT 60');
        $st->execute([$key, $id]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Hours in the stage against its SLA: [hours, sla, late?]. */
    public static function clock(array $def, array $item): array
    {
        $s = self::stageMap($def)[$item['stage']] ?? [];
        $h = $item['entered_at'] ? (int) floor((time() - strtotime((string) $item['entered_at'])) / 3600) : 0;
        $sla = (int) ($s['sla_hours'] ?? 0);
        return [$h, $sla, $sla > 0 && $h > $sla];
    }

    // ---- the builder ---------------------------------------------------------------------------------------------------

    /** Problems that stop a definition being published (none: []). */
    public static function validate(string $key, array $d): array
    {
        $p = [];
        $stages = self::stageMap($d);
        if (!$stages) return ['Add at least one stage.'];
        $starts = array_filter($d['stages'], fn ($s) => ($s['kind'] ?? '') === 'start');
        if (count($starts) !== 1) $p[] = 'Mark exactly one stage as the start.';
        foreach ($d['stages'] as $s) {
            if (!preg_match('/^[a-z0-9_]{1,40}$/', (string) $s['key'])) $p[] = 'Stage "' . ($s['label'] ?? '') . '" needs a short key (letters, numbers, _).';
            if (trim((string) ($s['label'] ?? '')) === '') $p[] = 'Every stage needs a name.';
        }
        $reach = [];
        foreach ($d['moves'] as $m) {
            if (!isset($stages[$m['to'] ?? ''])) $p[] = 'The move "' . ($m['label'] ?? $m['key']) . '" leads to a stage that isn\'t there.';
            $reach[$m['to'] ?? ''] = true;
            foreach ((array) ($m['from'] ?? []) as $f) if ($f !== '*' && !isset($stages[$f])) $p[] = 'The move "' . ($m['label'] ?? $m['key']) . '" starts from a stage that isn\'t there.';
        }
        foreach ($d['stages'] as $s) {
            if (($s['kind'] ?? '') !== 'start' && empty($reach[$s['key']])) $p[] = 'Nothing leads to "' . $s['label'] . '".';
            if (($s['kind'] ?? '') !== 'end') {
                $out = array_filter($d['moves'], fn ($m) => in_array($s['key'], (array) $m['from'], true) || in_array('*', (array) $m['from'], true));
                if (!$out) $p[] = '"' . $s['label'] . '" has no way out (or mark it as an end).';
            }
        }
        // a built-in workflow keeps its protected stages and the moves that do something with money or data
        $b = self::builtins()[$key] ?? null;
        if ($b) {
            foreach ($b['def']['stages'] as $s) if (!empty($s['op']) || !empty($s['locked'])) if (!isset($stages[$s['key']])) $p[] = '"' . $s['label'] . '" is part of how the site works and can\'t be removed (rename it instead).';
            $mk = []; foreach ($d['moves'] as $m) $mk[$m['key']] = $m;
            foreach ($b['def']['moves'] as $m) if (!empty($m['op'])) {
                if (!isset($mk[$m['key']])) $p[] = 'The move "' . $m['label'] . '" does something on the order or account and can\'t be removed.';
                elseif (array_diff((array) ($m['checks'] ?? []), (array) ($mk[$m['key']]['checks'] ?? []))) $p[] = 'The checks on "' . $m['label'] . '" protect the money or the data and can\'t be removed.';
                elseif (($mk[$m['key']]['op'] ?? '') !== $m['op']) $p[] = 'The action behind "' . $m['label'] . '" can\'t be changed.';
            }
        }
        return array_values(array_unique($p));
    }

    public static function saveDraft(PDO $pdo, string $key, array $d, int $by): void
    {
        self::meta($pdo, $key);
        $pdo->prepare('UPDATE ' . Database::t('wf_workflows') . ' SET draft = ?, draft_by = ?, draft_at = NOW() WHERE wf_key = ?')->execute([json_encode($d, JSON_UNESCAPED_UNICODE), $by, $key]);
    }

    /**
     * Publishes the draft as a new version. $carry: 'keep' (items in progress stay on their version) or 'move' (they move
     * to the new one; $map: old stage => new stage for any stage that's gone).
     */
    public static function publish(PDO $pdo, string $key, string $note, string $carry, array $map, int $by): int
    {
        $w = self::meta($pdo, $key);
        $d = json_decode((string) $w['draft'], true);
        if (!is_array($d)) throw new RuntimeException('There\'s no draft to publish.');
        if ($p = self::validate($key, $d)) throw new RuntimeException('Fix these first: ' . implode(' ', $p));
        $v = (int) $w['version'] + 1;
        $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO ' . Database::t('wf_versions') . ' (wf_key, version, def, note, published_by) VALUES (?, ?, ?, ?, ?)')->execute([$key, $v, json_encode($d, JSON_UNESCAPED_UNICODE), mb_substr($note, 0, 300), $by]);
            $pdo->prepare('UPDATE ' . Database::t('wf_workflows') . ' SET version = ?, draft = NULL, draft_by = NULL, draft_at = NULL WHERE wf_key = ?')->execute([$v, $key]);
            if ($carry === 'move') {
                $new = self::stageMap($d);
                foreach ($pdo->query('SELECT item_id, stage FROM ' . Database::t('wf_items') . ' WHERE wf_key = ' . $pdo->quote($key))->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    $to = isset($new[$r['stage']]) ? $r['stage'] : (string) ($map[$r['stage']] ?? '');
                    if ($to === '' || !isset($new[$to])) throw new RuntimeException('Choose where items in "' . $r['stage'] . '" go.');
                    $pdo->prepare('UPDATE ' . Database::t('wf_items') . ' SET version = ?, stage = ? WHERE wf_key = ? AND item_id = ?')->execute([$v, $to, $key, (int) $r['item_id']]);
                }
            }
            $pdo->commit();
        } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        return $v;
    }

    /** A new workflow made in the builder (it keeps its own items). */
    public static function create(PDO $pdo, string $name, string $module, int $by): string
    {
        $name = trim($name);
        if ($name === '') throw new InvalidArgumentException('Name the workflow.');
        $key = substr(trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($name)), '_'), 0, 30) ?: 'workflow';
        $base = $key; $i = 2;
        while (true) { $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('wf_workflows') . ' WHERE wf_key = ?'); $st->execute([$key]); if (!$st->fetchColumn()) break; $key = $base . '_' . $i++; }
        $d = ['stages' => [['key' => 'new', 'label' => 'New', 'kind' => 'start'], ['key' => 'done', 'label' => 'Done', 'kind' => 'end', 'outcome' => 'done']],
              'moves' => [['key' => 'finish', 'label' => 'Mark done', 'from' => ['new'], 'to' => 'done']], 'any' => []];
        $pdo->prepare('INSERT INTO ' . Database::t('wf_workflows') . ' (wf_key, name, module, entity, builtin, version, draft, created_by) VALUES (?, ?, ?, \'\', 0, 0, ?, ?)')
            ->execute([$key, mb_substr($name, 0, 120), $module, json_encode($d), $by]);
        return $key;
    }

    /** A new item in a workflow made in the builder. */
    public static function addItem(PDO $pdo, string $key, string $title, int $by): int
    {
        $w = self::meta($pdo, $key);
        if ($w['builtin']) throw new RuntimeException('Items in this workflow come from the site itself.');
        if (!(int) $w['version']) throw new RuntimeException('Publish the workflow first.');
        $d = self::def($pdo, $key);
        $start = ''; foreach ($d['stages'] as $s) if (($s['kind'] ?? '') === 'start') $start = $s['key'];
        $id = (int) $pdo->query('SELECT COALESCE(MAX(item_id), 0) + 1 FROM ' . Database::t('wf_items') . ' WHERE wf_key = ' . $pdo->quote($key))->fetchColumn();
        $pdo->prepare('INSERT INTO ' . Database::t('wf_items') . ' (wf_key, item_id, version, stage, owner_id, title) VALUES (?, ?, ?, ?, ?, ?)')->execute([$key, $id, (int) $w['version'], $start, $by ?: null, mb_substr(trim($title), 0, 160)]);
        $pdo->prepare("INSERT INTO " . Database::t('wf_history') . " (wf_key, item_id, version, move, to_stage, actor, note) VALUES (?, ?, ?, 'create', ?, ?, '')")->execute([$key, $id, (int) $w['version'], $start, $by ?: null]);
        return $id;
    }
}
