<?php
// /admin/setup.php?t=… — setting up a staff login from the one-time link (decisions/0100): confirm the work email with
// the code we email to it, and choose a password. The link works once, for 72 hours (and stays on Staff logins until
// it's used). An authenticator app can be added afterwards, from Staff logins, as a fallback.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');
require_once __DIR__ . '/../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';

$pdo = Database::connection();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$tok = (string) ($_GET['t'] ?? $_POST['t'] ?? '');
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$err = ''; $msg = ''; $done = null;
$s = StaffLogin::ready($pdo) ? StaffLogin::bySetup($pdo, $tok) : null;

if ($s && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        switch ((string) ($_POST['do'] ?? '')) {
            case 'email':   // a login made before work emails were required
                StaffLogin::setEmail($pdo, (int) $s['id'], (string) ($_POST['email'] ?? ''), null);
                $s = StaffLogin::get($pdo, (int) $s['id']);
                $msg = 'Code sent to ' . StaffLogin::sendSetupCode($pdo, $s) . '.';
                break;
            case 'resend':
                $msg = 'New code sent to ' . StaffLogin::sendSetupCode($pdo, $s) . '. Use the newest one.';
                break;
            default:
                $done = StaffLogin::completeSetup($pdo, $tok, (string) ($_POST['password'] ?? ''), (string) ($_POST['password2'] ?? ''), (string) ($_POST['code'] ?? ''));
        }
    } catch (RuntimeException $ex) { $err = $ex->getMessage(); }
} elseif ($s && filter_var((string) $s['email'], FILTER_VALIDATE_EMAIL) && StaffLogin::codeSentTo('setup', (int) $s['id']) === '') {
    try { StaffLogin::sendSetupCode($pdo, $s); } catch (RuntimeException $ex) { $err = $ex->getMessage(); }   // the first visit sends the code
}
$sentTo = $s ? StaffLogin::codeSentTo('setup', (int) $s['id']) : '';

tv_page_start('Set up your staff login', ['no_crumbs' => true, 'description' => 'Set up your Traversence staff login.']);
?>
<style>
  .su{max-width:30rem;margin:1.5rem auto;background:#F7EFDC;border:1px solid #CBB98D;border-radius:1rem;padding:1.2rem;color:#3E2B1F}
  .su h1{font:700 1.45rem var(--tv-font-head,Georgia,serif);margin:0 0 .3rem}.su h2{font:700 1.05rem var(--tv-font-head,Georgia,serif);margin:1rem 0 .3rem}
  .su p,.su li{font-size:.9rem;line-height:1.5}.su ol{margin:.3rem 0 .3rem 1.2rem;list-style:decimal}
  .su label{display:block;font-size:.82rem;font-weight:700;margin:.6rem 0 .2rem}
  .su input{width:100%;font-size:1rem;padding:.55rem .65rem;border:1px solid #CBB98D;border-radius:.6rem;background:#FFFBF2;color:#3E2B1F}
  .su input.code{font-size:1.5rem;letter-spacing:.3em;text-align:center}
  .su code{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.3rem;padding:.1rem .3rem;font-size:.85rem;word-break:break-all}
  .su .b{width:100%;margin-top:.9rem;border:1px solid #92400E;background:var(--tv-btn);color:var(--tv-btn-text);border-radius:.6rem;padding:.6rem;font-weight:700;cursor:pointer;display:block;text-align:center;text-decoration:none}
  .su .no{background:#FEE2E2;border-radius:.5rem;padding:.45rem .6rem}.su .ok{background:#DCFCE7;border-radius:.5rem;padding:.45rem .6rem}
  @media (max-width:767px){.su{margin:.6rem 0}}
</style>
<div class="su tv-bleed">
<?php if ($done): ?>
  <h1>You're set up</h1>
  <p class="ok" role="status">Your staff login <b><?= $e($done['staff_id']) ?></b> is ready.</p>
  <p>To sign in: your staff ID, your password, then the code we email to <b><?= $e(StaffLogin::mask((string) $done['email'])) ?></b>. Forgot your password, or can't get the email? An owner resets it and you get a new setup link.</p>
  <p>Optional, for when email is slow: after you sign in, add an authenticator app under <b>Staff logins → Your staff login</b>.</p>
  <p>Google, Microsoft and Facebook never sign in to your staff login: they're for member accounts only. Your staff ID always signs in here, or in the site's own Sign in.</p>
  <a class="b" href="/admin/login.php">Sign in</a>
<?php elseif (!$s): ?>
  <h1>This link doesn't work</h1>
  <p>It has expired (setup links last <?= StaffLogin::SETUP_HOURS ?> hours), was already used, or a newer one was made. Ask an owner for a new one.</p>
<?php else: ?>
  <h1>Set up your staff login</h1>
  <p>Your staff ID is <b><?= $e($s['staff_id']) ?></b> (<?= $e($s['name']) ?>). You'll sign in at <b>traversence.com/admin/login.php</b> with it, your password, and a code we email to your work email.</p>
  <?php if ($err): ?><p class="no" role="alert"><?= $e($err) ?></p><?php endif; ?>
  <?php if ($msg): ?><p class="ok" role="status"><?= $e($msg) ?></p><?php endif; ?>
  <?php if (!filter_var((string) $s['email'], FILTER_VALIDATE_EMAIL)): ?>
  <h2>1. Your work email</h2>
  <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($tok) ?>"><input type="hidden" name="do" value="email">
    <label for="em">Work email</label><input id="em" type="email" name="email" placeholder="first.last@<?= $e(StaffLogin::workDomain()) ?>" autocomplete="email" required>
    <button class="b">Email me a code</button>
  </form>
  <?php else: ?>
  <form method="post" autocomplete="off">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($tok) ?>">
    <h2>1. Choose a password</h2>
    <input type="text" name="username" value="<?= $e($s['staff_id']) ?>" autocomplete="username" hidden>
    <label for="p1">Password (12 characters or more)</label><input id="p1" type="password" name="password" minlength="12" autocomplete="new-password" data-pw-not="<?= $e($s['staff_id']) ?>" required>
    <label for="p2">The same again</label><input id="p2" type="password" name="password2" minlength="12" autocomplete="new-password" data-pw-match="#p1" required>
    <h2>2. Confirm your work email</h2>
    <p><?= $sentTo !== '' ? 'We emailed a 6-digit code to <b>' . $e($sentTo) . '</b>.' : 'We couldn\'t send the code yet: use <b>Send a new code</b> below.' ?></p>
    <input class="code" name="code" inputmode="numeric" maxlength="7" placeholder="000000" autocomplete="one-time-code" aria-label="The code from the email" required>
    <button class="b">Finish setting up</button>
  </form>
  <form method="post" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($tok) ?>"><input type="hidden" name="do" value="resend">
    <button class="underline text-[#92400E]" style="background:none;border:0;padding:0;font-size:.85rem;cursor:pointer">No email? Send a new code</button></form>
  <?php endif; ?>
<?php endif; ?>
</div>
<?php tv_page_end();
