<?php
// /admin/quickbooks.php — E-Commerce → Payments (decisions/0095, 0096, 0097, 0098): the QuickBooks connection what
// Traversence sells is paid through, its health (the .env setting, the QuickBooks log, the last webhook) and this
// month's numbers. The orders themselves, and the carts, are on E-Commerce (admin/ecommerce.php, admin/order.php).
// This page is also the Intuit app's redirect, launch, connect (?connect=1) and disconnect (?disconnected=1) address.
//
// Rewritten 2026-10-16 to stand up on its own: every call into the libraries goes through $has(), so a library file
// older than this page shows a note instead of stopping the page.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/QrIssue.php';
require_once __DIR__ . '/../../app/lib/QuickBooksPay.php';
if (!class_exists('Qr') && is_file(__DIR__ . '/../../app/lib/Qr.php')) require_once __DIR__ . '/../../app/lib/Qr.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$money = fn ($c) => '$' . number_format(((int) $c) / 100, 2);
$has = fn (string $class, string $method) => class_exists($class) && method_exists($class, $method);
$old = [];   // library functions this page expected but didn't find (an older file on the server)
$need = function (string $class, string $method) use ($has, &$old): bool { if ($has($class, $method)) return true; $old[$class . '::' . $method] = true; return false; };
$self = '/admin/quickbooks.php' . (!empty($_GET['embed']) ? '?embed=1' : '');
$back = function () use ($self) { header('Location: ' . $self, true, 303); exit; };

if (is_file(__DIR__ . '/../../app/lib/Orders.php')) require_once __DIR__ . '/../../app/lib/Orders.php';
$ready = $need('QrIssue', 'ready') && $need('QuickBooksPay', 'ready') && $need('Orders', 'ready') && QrIssue::ready($pdo) && QuickBooksPay::ready($pdo) && Orders::ready($pdo);
$env = $has('QuickBooksPay', 'env') ? QuickBooksPay::env() : 'production';
$configured = $has('QuickBooksPay', 'configured') && QuickBooksPay::configured();
$startConnect = function (bool $cards = true) use ($configured) {
    if (!$configured) { tv_crawler_flash(['type' => 'error', 'text' => 'Add this mode\'s Intuit keys to .env first (see Mode, below).']); return; }
    $_SESSION['tv_qb_state'] = bin2hex(random_bytes(16));
    $_SESSION['tv_qb_env'] = QuickBooksPay::env();   // the way back connects the mode this was started in
    header('Location: ' . QuickBooksPay::authUrl($_SESSION['tv_qb_state'], $cards)); exit;
};

// ---- addresses the Intuit app sends people to ------------------------------------------------------------------------
if ($ready && isset($_GET['code'], $_GET['state'], $_GET['realmId'])) {          // back from QuickBooks after connecting
    $ok = hash_equals((string) ($_SESSION['tv_qb_state'] ?? ''), (string) $_GET['state']);
    if ($has('QuickBooksPay', 'useEnv')) QuickBooksPay::useEnv($_SESSION['tv_qb_env'] ?? null);
    unset($_SESSION['tv_qb_state'], $_SESSION['tv_qb_env']);
    try {
        if (!$ok) throw new RuntimeException('That sign-in to QuickBooks had expired. Connect again.');
        $name = QuickBooksPay::connect($pdo, (string) $_GET['code'], (string) $_GET['realmId'], (int) $me['id']);
        tv_crawler_flash(['type' => 'ok', 'text' => 'QuickBooks is connected' . ($name !== '' ? ' (' . $name . ')' : '') . '. Buying is open.']);
    } catch (Throwable $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    header('Location: /admin/quickbooks.php', true, 303); exit;
}
if (isset($_GET['error'])) { tv_crawler_flash(['type' => 'error', 'text' => 'QuickBooks wasn\'t connected (' . mb_substr((string) $_GET['error'], 0, 60) . ').']); header('Location: /admin/quickbooks.php', true, 303); exit; }
if ($ready && isset($_GET['connect'])) { $startConnect(); header('Location: /admin/quickbooks.php', true, 303); exit; }
if ($ready && isset($_GET['disconnected'])) {   // Intuit sends people here after disconnecting inside QuickBooks: check before forgetting
    try {
        if ($need('QuickBooksPay', 'stillConnected'))
            tv_crawler_flash(QuickBooksPay::stillConnected($pdo)
                ? ['type' => 'ok', 'text' => 'QuickBooks is still connected, so nothing changed.']
                : ['type' => 'ok', 'text' => 'QuickBooks is disconnected. Buying shows "opens soon" until it\'s connected again.']);
    } catch (Throwable $ex) { tv_crawler_flash(['type' => 'error', 'text' => 'Couldn\'t check with QuickBooks: ' . $ex->getMessage()]); }
    header('Location: /admin/quickbooks.php', true, 303); exit;
}
// the QuickBooks log, to share with Intuit support
$logFile = $has('QuickBooksPay', 'logPath') ? QuickBooksPay::logPath() : '';
$mask = fn (string $t) => preg_replace(['#/company/\d+#', '#/companyinfo/\d+#'], ['/company/{company}', '/companyinfo/{company}'], $t);   // lines from before the company id was kept out
if (isset($_GET['log'])) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="traversence-quickbooks-' . date('Y-m-d') . '.log"');
    $any = false;
    if ($logFile !== '') foreach ([$logFile . '.1', $logFile] as $f) if (is_readable($f)) { echo $mask((string) file_get_contents($f)); $any = true; }
    if (!$any) echo "No calls to QuickBooks logged yet.\n";
    exit;
}

// ---- buttons --------------------------------------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) { tv_crawler_flash(['type' => 'error', 'text' => 'This page had expired. Try again.']); $back(); }
    $id = (int) ($_POST['id'] ?? 0);
    try {
        if (!$ready) throw new RuntimeException('Run the GO Codes migrations first.');
        switch ((string) ($_POST['do'] ?? '')) {
            case 'connect': $startConnect(); break;
            case 'connect_books': $startConnect(false); break;   // accounting only: invoices and refunds in the books, no card form
            case 'mode':   // the sandbox/production switch
                $to = (string) ($_POST['to'] ?? '');
                QuickBooksPay::setMode($pdo, $to, (int) $me['id']);
                tv_crawler_flash(['type' => 'ok', 'text' => $to === 'sandbox'
                    ? 'Switched to Sandbox (testing). Checkout is open to our team only, and every order goes to the QuickBooks sandbox company. Switch back when you\'re done.'
                    : 'Switched to Production. Checkout is open to everyone, and orders go to the real QuickBooks company.']);
                break;
            case 'disconnect':
                QuickBooksPay::disconnect($pdo);
                tv_crawler_flash(['type' => 'ok', 'text' => 'QuickBooks is disconnected. Buying shows "opens soon" until it\'s connected again.']); break;
        }
    } catch (Throwable $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    $back();
}

// ---- what the page shows --------------------------------------------------------------------------------------------
$conn = $ready && $has('QuickBooksPay', 'connection') ? QuickBooksPay::connection($pdo) : null;
$lapsed = $conn && ($has('QuickBooksPay', 'needsReconnect') ? QuickBooksPay::needsReconnect($conn) : strtotime((string) $conn['refresh_until']) <= time());
$month = ['n' => 0, 't' => 0, 'x' => 0]; $free = 0;
if ($ready) {
    try {
        $st = $pdo->prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total_cents), 0) AS t, COALESCE(SUM(tax_cents), 0) AS x FROM orders WHERE paid_at IS NOT NULL AND status <> 'void' AND paid_at >= ?");
        $st->execute([date('Y-m-01')]); $month = $st->fetch(PDO::FETCH_ASSOC) ?: $month;
        $st = $pdo->prepare("SELECT COUNT(*) FROM qr_issued WHERE status = 'free' AND issued_at >= ?");
        $st->execute([date('Y-m-01')]); $free = (int) $st->fetchColumn();
    } catch (Throwable $ex) { error_log('admin quickbooks: ' . $ex->getMessage()); }
}

// health: the .env setting, the log's latest errors, the last webhook
$envRaw = $has('QuickBooksPay', 'envRaw') ? QuickBooksPay::envRaw() : strtolower(trim((string) getenv('QB_ENV')));
$envFile = $has('Database', 'envPath') ? Database::envPath() : '';
$envWhere = $envFile !== '' ? ' The site reads ' . $envFile . (is_readable($envFile) ? ', last changed ' . date('M j, Y g:i a', (int) filemtime($envFile)) . '.' : ', which it can\'t find.') : '';
$envNote = $envRaw === '' ? ''   // not set: production unless the Mode switch says sandbox
    : (!in_array($envRaw, ['production', 'sandbox', 'mock'], true) ? 'QB_ENV in .env reads "' . $envRaw . '", which isn\'t production or sandbox, so production is used.' . $envWhere : '');
$logLines = $logFile !== '' && is_readable($logFile) ? array_map($mask, array_slice(file($logFile, FILE_IGNORE_NEW_LINES) ?: [], -600)) : [];
$logErrors = array_slice(array_values(array_filter($logLines, fn ($l) => str_contains($l, ' error="'))), -5);
$lastHook = '';
foreach (array_reverse($logLines) as $l) if (str_contains($l, ' IN webhook')) { $lastHook = $l; break; }
$hookToken = $has('QuickBooksPay', 'key') ? QuickBooksPay::key('WEBHOOK_TOKEN') !== '' : trim((string) getenv('QB_WEBHOOK_TOKEN')) !== '';
$modeSet = $has('QuickBooksPay', 'mode') ? QuickBooksPay::mode() : '';
if ($modeSet !== '' && $envRaw !== 'mock') $envNote = '';
$base = rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/');
$flash = tv_crawler_flash();
$when = fn (string $t) => $t !== '' ? date('M j, g:i a', strtotime($t)) : '';

tv_page_start('Payments', ['no_crumbs' => true, 'description' => 'Payments through QuickBooks: the connection, its health and this month.']);
?>
<style>
  .qo{color:#3E2B1F;font-size:0.98rem}
  .qo h1{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.7rem;margin:0 0 .25rem}
  .qo h2{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.12rem;margin:1.1rem 0 .35rem}
  .qo .lead{color:#5C4632;margin:0 0 .5rem}
  .qo-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .9rem;margin:.45rem 0;overflow-wrap:anywhere}
  .qo-card .sub{font-size:0.88rem;color:#5C4632;margin-top:.2rem}
  .qo-row{display:flex;gap:.6rem;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;padding:.55rem 0;border-top:1px solid #EADFC4}.qo-row:first-child{border-top:0;padding-top:0}
  .qo-row .who{min-width:0;flex:1 1 16rem}
  .qo-acts{display:flex;gap:.3rem;flex-wrap:wrap}
  .qo-b{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:.5rem;padding:.32rem .7rem;font-weight:600;cursor:pointer;font-size:0.9rem}
  .qo-b.main{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text)}.qo-b.d{border-color:#B91C1C;color:#B91C1C}.qo-b[disabled]{opacity:.5;cursor:not-allowed}
  .qo-st{display:inline-block;border-radius:999px;padding:.05rem .5rem;font-size:0.8rem;font-weight:700;background:#E7CCAA}.qo-st.paid{background:#BBF7D0}.qo-st.pending{background:#FEF3C7}.qo-st.refunded{background:#E5E7EB}
  .qo-msg{padding:.5rem .7rem;border-radius:.5rem;background:#DCFCE7;margin:.45rem 0}.qo-msg.error{background:#FEE2E2}.qo-msg.warn{background:#FEF3C7}
  .qo-dot{display:inline-block;width:.6rem;height:.6rem;border-radius:999px;margin-right:.35rem;vertical-align:.05rem;background:#9CA3AF}.qo-dot.ok{background:#16A34A}.qo-dot.bad{background:#DC2626}.qo-dot.warn{background:#D97706}
  .qo-health{display:grid;gap:.35rem}
  .qo-nums{display:grid;grid-template-columns:repeat(auto-fit,minmax(9rem,1fr));gap:.45rem}
  .qo-nums div{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem;padding:.45rem .7rem}.qo-nums b{display:block;font-size:1.25rem}
  .qo code{background:#FFFBF2;padding:0 .25rem;border-radius:.25rem;font-size:0.86rem}
  .qo pre{font-size:0.78rem;white-space:pre-wrap;word-break:break-all;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.4rem;padding:.4rem;margin:.3rem 0 0}
  .qo details summary{cursor:pointer;font-size:0.9rem;color:#92400E;font-weight:600;margin-top:.4rem}
  .qo details ul{font-size:0.88rem;margin:.3rem 0 0 1.1rem;list-style:disc}
</style>
<div class="qo">
  <h1>Payments</h1>
  <p class="lead">What Traversence sells is paid through QuickBooks, which keeps the books. GO Codes sell at <?= $money(class_exists('QrIssue') && defined('QrIssue::PRICE_CENTS') ? QrIssue::PRICE_CENTS : 495) ?> each, to members and guests. Each checkout becomes a QuickBooks invoice (Automated Sales Tax adds the tax), paid by card on our checkout page through QuickBooks Payments (the card goes straight to Intuit), or on QuickBooks' own invoice page; the codes are issued as soon as it's paid. The orders, and refunds, credits and disputes on them, are on <a class="underline text-[#92400E]" href="/admin/ecommerce.php#orders" target="_top">E-Commerce → Orders</a>.</p>

  <?php if ($flash): ?><p class="qo-msg <?= $e($flash['type'] ?? '') ?>" role="status" data-tv-flash="<?= $e($flash['type'] ?? '') ?>"><?= $e($flash['text'] ?? '') ?></p><?php endif; ?>
  <?php if ($old): ?><p class="qo-msg warn">Some files on the server are older than this page (<?= $e(implode(', ', array_keys($old))) ?>). Upload the latest GO Codes zip so everything matches.</p><?php endif; ?>

  <?php if (!$ready): ?>
  <div class="qo-card tv-bleed">Run <code>app/migrations/2026-11-28_qr_orders.sql</code>, <code>2026-11-29_go_codes_guest.sql</code> and <code>2026-12-02_orders.sql</code> in phpMyAdmin first.</div>
  <?php else: ?>

  <?php if ($has('QuickBooksPay', 'modeStatus') && $env !== 'mock'): $ms = ['production' => QuickBooksPay::modeStatus($pdo, 'production'), 'sandbox' => QuickBooksPay::modeStatus($pdo, 'sandbox')]; ?>
  <h2>Mode</h2>
  <div class="qo-card tv-bleed">
    <?php if ($env === 'sandbox'): ?><p class="qo-msg warn" style="margin-top:0"><b>Sandbox (testing) is on.</b> Checkout is open to our team only; every order goes to the QuickBooks sandbox company and no real money moves. Switch back to Production when you're done.</p><?php endif; ?>
    <?php // which mode is on, said in words and colour (Jason, 2026-11-12: "cant tell what mode it is by the buttons?") ?>
    <style>.qo-b.qo-on,.qo-b.qo-on:disabled{opacity:1;background:#8FBCA8;border-color:#5E8F7A;color:#1F3B30;font-weight:700;cursor:default;box-shadow:0 0 8px rgba(143,188,168,.7)}</style>
    <p data-tv-status="<?= $env === 'sandbox' ? 'info' : 'ok' ?>" data-tv-label="Now in <?= $env === 'sandbox' ? 'Sandbox' : 'Production' ?>:"><?= $env === 'sandbox' ? 'testing: no real money moves, and checkout is for our team only.' : 'real payments: checkout is open to everyone.' ?></p>
    <div class="qo-acts" style="margin-bottom:.5rem">
      <?php foreach (['production' => 'Production', 'sandbox' => 'Sandbox (testing)'] as $k => $lab): $on = $env === $k; ?>
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="to" value="<?= $k ?>">
        <button class="qo-b<?= $on ? ' qo-on' : '' ?>" name="do" value="mode"<?= $on ? ' disabled aria-pressed="true" title="This mode is on"' : ' data-confirm="Switch to ' . $e($lab) . '? ' . ($k === 'sandbox' ? 'Checkout closes to everyone but our team while it\'s on.' : 'Checkout opens to everyone, with real payments.') . '" data-yes="Switch"' . ($k === 'production' && !$ms['production']['configured'] ? ' disabled title="Add the production keys to .env first"' : '') ?>><?= $on ? '&#10003; ' . $e($lab) : 'Switch to ' . $e($lab) ?></button></form>
      <?php endforeach; ?>
    </div>
    <?php foreach (['production' => 'Production', 'sandbox' => 'Sandbox'] as $k => $lab): $m = $ms[$k]; ?>
    <div class="sub"><b><?= $lab ?>:</b>
      <?= $m['configured'] ? 'keys in .env' : '<span style="color:#991B1B">no keys in .env</span> (' . ($k === 'production' ? 'QB_CLIENT_ID, QB_CLIENT_SECRET' : 'QB_SANDBOX_CLIENT_ID, QB_SANDBOX_CLIENT_SECRET') . ')' ?>
      · <?= $m['webhook'] ? 'webhook token in .env' : '<span style="color:#991B1B">no webhook token</span> (' . ($k === 'production' ? 'QB_WEBHOOK_TOKEN' : 'QB_SANDBOX_WEBHOOK_TOKEN') . ')' ?>
      · <?= $m['connected'] ? 'connected' . ($m['company'] !== '' ? ' to ' . $e($m['company']) : '') . ($m['cards'] ? ', card payments on' : ', <b>reconnect for card payments</b>') : ($m['lapsed'] ? '<b>needs reconnecting</b>' : 'not connected') ?></div>
    <?php endforeach; ?>
    <?php $cid = fn (string $m) => QuickBooksPay::key('CLIENT_ID', $m); $mask = fn (string $v) => $v === '' ? 'none' : substr($v, 0, 4) . '…' . substr($v, -4) . ' (' . strlen($v) . ' characters)'; ?>
    <div style="font-size:.82rem;color:#5C4632;margin-top:.3rem">Client ID in use: Production <code><?= $e($mask($cid('production'))) ?></code> · Sandbox <code><?= $e($mask($cid('sandbox'))) ?></code>. Compare with Intuit's Keys &amp; credentials: Production and Development each have their own.</div>
    <?php if ($cid('production') !== '' && $cid('production') === $cid('sandbox')): ?><p style="background:#FEE2E2;border-radius:.5rem;padding:.45rem .6rem;margin-top:.4rem;font-size:.85rem"><b>Production is using the Development (sandbox) Client ID.</b> Intuit refuses it for a real company ("undefined didn't connect"). Put the <b>Production</b> Client ID and Secret in QB_CLIENT_ID and QB_CLIENT_SECRET.</p><?php endif; ?>
    <details><summary>How the two modes are kept apart</summary><ul>
      <li>Each mode has its own Intuit keys in .env: production's are QB_CLIENT_ID, QB_CLIENT_SECRET and QB_WEBHOOK_TOKEN; the sandbox's are QB_SANDBOX_CLIENT_ID, QB_SANDBOX_CLIENT_SECRET and QB_SANDBOX_WEBHOOK_TOKEN.</li>
      <li>Each mode has its own connection: switch, then Connect, once for each.</li>
      <li>Every order remembers the mode it was made in; its QuickBooks work (payment checks, refunds, credits) only happens in that mode. Sandbox orders show a Test tag and stay out of Reports.</li>
      <li>Webhooks from either are taken whatever the switch says: each is signed with its own mode's token.</li>
    </ul></details>
  </div>
  <?php endif; ?>

  <h2>Connection</h2>
  <div class="qo-card tv-bleed">
    <?php if ($env === 'mock'): ?>
      <b>Local test mode</b> (QB_ENV=mock): orders get a made-up 8.6% tax and "Mark paid" stands in for paying.
    <?php elseif ($conn && $lapsed): ?>
      <span class="qo-dot bad"></span><b>QuickBooks needs reconnecting</b><?= ($conn['company_name'] ?? '') !== '' ? ' (' . $e($conn['company_name']) . ')' : '' ?>.
      <div class="sub">QuickBooks no longer accepts our connection (100 days unused, or disconnected), so buying shows "opens soon". Orders and codes are safe.</div>
      <form method="post" target="_top" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><button class="qo-b main" name="do" value="connect">Reconnect QuickBooks</button></form>
    <?php elseif ($conn): ?>
      <span class="qo-dot ok"></span><b>Connected</b><?= ($conn['company_name'] ?? '') !== '' ? ': ' . $e($conn['company_name']) : '' ?> <span class="qo-st"><?= $e($env) ?></span> · <?= $env === 'sandbox' ? 'buying is open to our team only (testing).' : 'buying is open.' ?>
      <div class="sub"><?php if ($has('QuickBooksPay', 'canRefundCards')): ?><?= QuickBooksPay::canRefundCards($pdo) ? 'Card refunds from an order: on.' : '<b>Card refunds from an order are off:</b> this connection was made before them. Disconnect and Connect again to allow QuickBooks Payments.' ?> <?php endif; ?>Reconnect before <?= $e(date('M j, Y', strtotime((string) $conn['refresh_until']))) ?> unless a sale renews it (QuickBooks asks after 100 days unused). Product in QuickBooks: <?= $e(defined('QuickBooksPay::ITEM_NAME') ? QuickBooksPay::ITEM_NAME : 'GO Code') ?>.</div>
      <form method="post" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><button class="qo-b d" name="do" value="disconnect" data-confirm="Disconnect QuickBooks? Buying shows 'opens soon' until it's connected again." data-yes="Disconnect" data-danger>Disconnect</button></form>
    <?php else: ?>
      <span class="qo-dot"></span><b>Not connected</b>, so buying shows "opens soon".
      <?php if (!$configured): ?><div class="sub">Add <code>QB_CLIENT_ID</code>, <code>QB_CLIENT_SECRET</code>, <code>QB_WEBHOOK_TOKEN</code> and <code>QB_ENV</code> to .env first (the Intuit developer app's keys).</div><?php endif; ?>
      <form method="post" target="_top" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><button class="qo-b main" name="do" value="connect"<?= $configured ? '' : ' disabled' ?>>Connect QuickBooks</button>
        <button class="qo-b" name="do" value="connect_books"<?= $configured ? '' : ' disabled' ?> title="Asks QuickBooks for accounting only. Invoices work and customers pay on QuickBooks' page; the card form on our checkout and card refunds from here need Payments, which Intuit approves separately for production.">Connect without card payments</button></form>
    <?php endif; ?>
    <details>
      <summary>Addresses for the Intuit app</summary>
      <ul>
        <li>Redirect URI, launch: <code><?= $e($has('QuickBooksPay', 'redirectUri') ? QuickBooksPay::redirectUri() : $base . '/admin/quickbooks.php') ?></code></li>
        <li>Connect / reconnect: <code><?= $e($base) ?>/admin/quickbooks.php?connect=1</code></li>
        <li>Disconnect: <code><?= $e($base) ?>/admin/quickbooks.php?disconnected=1</code></li>
        <li>Webhook (events: Invoice, Payment, RefundReceipt, CreditMemo): <code><?= $e($base) ?>/api/qb-webhook.php</code></li>
        <li>License agreement: <code><?= $e($base) ?>/terms.php</code> · Privacy: <code><?= $e($base) ?>/privacy.php</code></li>
      </ul>
    </details>
  </div>

  <h2>Health</h2>
  <div class="qo-card tv-bleed qo-health">
    <div><span class="qo-dot <?= $envNote === '' ? 'ok' : 'warn' ?>"></span><b>Setting:</b> <?= $envNote !== '' ? $e($envNote) : ($modeSet !== '' ? $e(ucfirst($modeSet)) . ', set under Mode above.' : ($envRaw === '' ? 'Production (the default). Switch to Sandbox under Mode above for testing.' : 'QB_ENV=' . $e($envRaw) . '.')) ?></div>
    <div><span class="qo-dot <?= !$hookToken ? 'bad' : ($lastHook === '' ? '' : (str_contains($lastHook, ' 200 ') ? 'ok' : 'bad')) ?>"></span><b>Webhook:</b>
      <?php if (!$hookToken): ?>This mode's webhook verifier token isn't in .env, so its webhooks are refused. Add it from the Intuit app's Webhooks page (see Mode, above).
      <?php elseif ($lastHook === ''): ?>none received yet. (Codes are still issued: the buyer's page asks QuickBooks itself.)
      <?php else: ?>last one <?= $e($when(substr($lastHook, 0, 25))) ?>, <?= str_contains($lastHook, ' 200 ') ? 'accepted' : 'refused: the verifier token in .env doesn\'t match Intuit\'s' ?>.
      <?php endif; ?></div>
    <div><span class="qo-dot <?= $logErrors ? 'warn' : 'ok' ?>"></span><b>QuickBooks log:</b> <?= $logLines ? count($logLines) . ' recent calls' . ($logErrors ? ', latest errors below' : ', no errors') : 'nothing yet' ?>. <a class="underline text-[#92400E]" href="/admin/quickbooks.php?log=1">Download the QuickBooks log</a> (each call with its intuit_tid, for Intuit support).</div>
    <?php if ($logErrors): ?><pre><?= $e(implode("\n", $logErrors)) ?></pre><?php endif; ?>
  </div>

  <h2>This month</h2>
  <div class="qo-nums tv-bleed">
    <div><b><?= (int) $month['n'] ?></b>orders paid</div>
    <div><b><?= $money($month['t']) ?></b>taken (<?= $money($month['x']) ?> of it tax)</div>
    <div><b><?= $free ?></b>free GO Codes issued</div>
  </div>

  <?php endif; ?>
</div>
<?php tv_page_end();
