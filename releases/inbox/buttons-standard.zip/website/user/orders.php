<?php
// /user/orders.php — Your orders: the orders we prepared for you (decisions/0101, addendum 2026-10-28), each with where
// it stands and a link to its page (proofs, payment, files). Orders sent to your confirmed email join your account
// here. GO Codes you bought yourself are on Manage GO Codes.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/ClientOrders.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
header('Content-Type: text/html; charset=utf-8');

$me = Auth::currentUser();
if (!$me) { header('Location: /login.php?next=' . rawurlencode('/user/orders.php'), true, 303); exit; }
$pdo = Database::connection();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$orders = Products::ready($pdo) ? ClientOrders::forMember($pdo, (int) $me['id']) : [];
$unconfirmed = empty($me['email_verified_at']);
// your artwork (decisions/0101, addendum 2026-10-28): the pieces we've released to you, to look at, download and reorder
require_once __DIR__ . '/../../app/lib/Collateral.php';
$verified = (function () use ($pdo, $me): bool { try { $v = $pdo->prepare('SELECT email_verified_at FROM users WHERE id = ?'); $v->execute([(int) $me['id']]); return (bool) $v->fetchColumn(); } catch (Throwable $x) { return false; } })();
$art = Collateral::forClient($pdo, $verified ? (string) $me['email'] : '', (int) $me['id']);   // by a confirmed email, or by the account itself
$flash = $_SESSION['tv_uo_flash'] ?? null; unset($_SESSION['tv_uo_flash']);
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['do'] ?? '') === 'reorder') {
    try {
        if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $id = (int) ($_POST['item'] ?? 0);
        if (!in_array($id, array_map(fn ($c) => (int) $c['id'], $art), true)) throw new RuntimeException('That piece isn\'t yours to reorder.');
        $n = (int) preg_replace('/\D/', '', (string) ($_POST['qty'] ?? ''));
        $c = Collateral::get($pdo, $id);
        Collateral::askReorder($pdo, [$id => $n ?: (int) $c['qty']], !empty($_POST['changes']), (string) ($_POST['note'] ?? ''), (string) ($me['display_name'] ?: $me['email']), (int) $me['id']);
        $_SESSION['tv_uo_flash'] = ['ok', 'We have your reorder of ' . $c['name'] . '. We\'ll send you the order to look over and approve' . (empty($_POST['changes']) ? '' : ', with a new proof for your changes') . '.'];
    } catch (Throwable $x) {
        if (!($x instanceof RuntimeException) || $x instanceof PDOException) error_log('reorder ask: ' . $x->getMessage());
        $_SESSION['tv_uo_flash'] = ['error', $x instanceof RuntimeException && !($x instanceof PDOException) ? $x->getMessage() : 'That didn\'t go through. Try again, or reply to any of our emails.'];
    }
    header('Location: /user/orders.php#art', true, 303); exit;
}

tv_page_start('Your orders', ['no_crumbs' => true, 'section' => 'member', 'description' => 'The orders Traversence prepared for you: proofs, payment, where each one is, and your files.']);
?>
<style>
  .uo{max-width:46rem;color:#3E2B1F}
  .uo h1{font:700 1.7rem var(--tv-font-head,Georgia,serif);margin:.2rem 0}.uo p.i{font-size:.92rem;color:#5C4632}
  .uo-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.2rem .8rem;margin-top:.6rem}
  .uo-row{display:flex;align-items:flex-start;gap:.6rem;padding:.65rem 0;border-top:1px solid #EADFC4}.uo-row:first-child{border-top:0}
  .uo-t{flex:1;min-width:0}.uo-t a{font-weight:700;color:#92400E;text-decoration:underline}.uo-t small{display:block;font-size:.82rem;color:#6B5640;margin-top:.1rem}
  .uo-st{display:inline-block;font-size:.78rem;font-weight:700;border-radius:999px;padding:.12rem .55rem;background:#FEF3C7;color:#7C2D12;margin-top:.25rem}.uo-st.ok{background:#DCFCE7;color:#14532D}
  .uo-amt{font-weight:700;white-space:nowrap}
  .uo-note{background:#FEF3C7;border:1px solid #F59E0B;border-radius:.6rem;padding:.5rem .7rem;font-size:.92rem;margin-top:.6rem}
  .uo h2{font:700 1.25rem var(--tv-font-head,Georgia,serif);margin:1.4rem 0 .2rem}
  .uo-art{display:grid;grid-template-columns:repeat(auto-fill,minmax(14rem,1fr));gap:.6rem;margin-top:.6rem}
  .uo-a{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.8rem;padding:.7rem;display:grid;gap:.4rem;align-content:start}
  .uo-a b{font-size:1rem}.uo-a small{color:#6B5640;font-size:.84rem}
  .uo-a .th{display:flex;align-items:center;justify-content:center;height:9rem;background:#fff;border:1px solid #EADFC4;border-radius:.5rem;overflow:hidden}.uo-a .th img{max-width:100%;max-height:100%}
  .uo-a .th span{font:700 .9rem system-ui,sans-serif;color:#92400E}
  .uo-a ul{margin:0;padding:0;list-style:none;font-size:.86rem}.uo-a li a{color:#92400E;text-decoration:underline;overflow-wrap:anywhere}
  .uo-a details summary{cursor:pointer;display:inline-block;background:#3E2B1F;color:#FFF8EA;border-radius:999px;padding:.35rem .9rem;font-weight:700;font-size:.9rem;list-style:none}
  .uo-a form{display:grid;gap:.4rem;margin-top:.5rem}.uo-a label{display:grid;gap:.15rem;font-size:.86rem;color:#5C4632}.uo-a .chk{display:flex;gap:.4rem;align-items:center}
  .uo-a input,.uo-a textarea{font:inherit;border:1px solid #CBB98D;border-radius:.45rem;padding:.4rem .5rem;background:#fff}.uo-a .chk input{width:auto}
  .uo-a button{justify-self:start;background:var(--tv-btn);color:var(--tv-btn-text);border:0;border-radius:999px;padding:.4rem 1rem;font-weight:700;cursor:pointer}
  @media (max-width:767px){.uo-card{border-radius:.5rem}.uo-a{border-radius:.5rem}}
</style>
<div class="uo">
  <h1>Your orders</h1>
  <p class="i">The orders we've prepared for you: open one for its proofs, payment, where it stands and your files. GO Codes you bought yourself are on <a class="underline" href="/qr/manage.php">Manage GO Codes</a>.</p>
  <?php if ($unconfirmed): ?><div class="uo-note">Confirm your email (the link we sent when you joined) and the orders sent to <b><?= $e($me['email']) ?></b> show up here.</div><?php endif; ?>
  <?php if (!$orders): ?><div class="uo-card tv-bleed"><p class="i" style="padding:.5rem 0">No orders yet<?= $unconfirmed ? '' : ' for ' . $e($me['email']) ?>. Orders we send to that email appear here.</p></div>
  <?php else: ?><div class="uo-card tv-bleed">
    <?php foreach ($orders as $o): $st = ClientOrders::clientStatus($pdo, $o); $done = ClientOrders::placed($o) || in_array($o['status'], ['paid', 'part_refunded'], true); ?>
    <div class="uo-row"><div class="uo-t"><a href="/order.php?t=<?= $e($o['access_token']) ?>">Order #<?= $e(Orders::no($o)) ?></a><?= $o['client_company'] !== '' ? ' · ' . $e($o['client_company']) : '' ?>
      <small><?= $e(date('M j, Y', strtotime((string) ($o['sent_at'] ?: $o['created_at'])))) ?><?= (int) $o['items'] ? ' · ' . (int) $o['items'] . ' item' . ((int) $o['items'] === 1 ? '' : 's') : '' ?><?= Orders::isTest($o) ? ' · test (sandbox)' : '' ?></small>
      <span class="uo-st<?= $done ? ' ok' : '' ?>"><?= $e($st) ?></span></div>
      <div class="uo-amt"><?= Orders::usd((int) ($o['total_cents'] ?: $o['subtotal_cents'])) ?></div></div>
    <?php endforeach; ?></div>
  <?php endif; ?>
  <?php if ($flash): ?><p data-tv-flash="<?= $e($flash[0]) ?>"><?= $e($flash[1]) ?></p><?php endif; ?>
  <?php if ($art): $csrf = (string) ($_SESSION['csrf_token'] ?? ''); ?>
  <h2 id="art">Your artwork</h2>
  <p class="i">The pieces we've made for you and released to you: look them over, download them, and reorder with the same art or with changes.</p>
  <div class="uo-art">
    <?php foreach ($art as $c): $fs = Collateral::files($pdo, $c, true); $img = array_values(array_filter($fs, fn ($f) => $f[5]))[0] ?? null; ?>
    <div class="uo-a tv-bleed">
      <div class="th"><?php if ($img): ?><img src="<?= $e($img[2]) ?>" alt="<?= $e($c['name']) ?>" loading="lazy"><?php else: ?><span><?= $fs ? 'PDF' : 'No preview' ?></span><?php endif; ?></div>
      <b><?= $e($c['name']) ?></b><small><?= number_format((int) $c['qty']) ?><?= $c['options'] !== '' ? ' · ' . $e($c['options']) : '' ?></small>
      <?php if ($fs): ?><ul><?php foreach ($fs as $f): ?><li><a href="<?= $e($f[2] . '&download=1') ?>"><?= $e($f[1]) ?></a> <small><?= $e($f[0]) ?></small></li><?php endforeach; ?></ul><?php endif; ?>
      <details><summary>Ask to reorder</summary>
        <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="reorder"><input type="hidden" name="item" value="<?= (int) $c['id'] ?>">
          <label>How many<input name="qty" inputmode="numeric" value="<?= (int) $c['qty'] ?>"></label>
          <label class="chk"><input type="checkbox" name="changes" value="1"> I want changes (a new proof)</label>
          <label>Anything to tell us (optional)<textarea name="note" rows="2" maxlength="600"></textarea></label>
          <button>Ask for this reorder</button></form></details>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php tv_page_end();
