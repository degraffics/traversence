/* js/tv-stock.js — the stock library (decisions/0143) on a page.
 *
 *   TvStock.pick({slot, q, place, title, mine}) → Promise of the chosen photo or null: a stock photo ({id, url, card,
 *       credit, label…}) or, with mine ('me', or a business's listing id), one of their own ({gallery: item id, card…}).
 *       One picker for all art: Your gallery and Stock, side by side. The Stock tab is only for illustrative slots (the
 *       server refuses authentic ones); a page for an authentic slot uses its own photos only and never opens this.
 *   <button data-stock-pick data-slot="home_door" data-owner="explore" data-q="landscape" data-post="/admin/api/config/stock"
 *           data-action="use">Choose a stock photo</button>
 *       Opens the picker, then sends {action, slot, owner, stock} to data-post and shows the answer as the site's notice.
 *       With data-mine (+ data-own-action, data-which) it opens on Your gallery; one of their own photos is sent as
 *       {action: data-own-action, which, item}.
 *   <button data-stock-use="<stock id>" data-slot=… data-owner=… data-post=… data-action=…>   the Gallery's Stock tab: use it there.
 *   <button data-stock-clear data-slot=… data-owner=… data-post=…>Automatic</button>   sends stock 0 (pick by itself again).
 *   <div data-stock-admin> … System Configuration → Stock library: search a source, add with tags, choose doors.
 *
 * Busy spinners on whatever was clicked (TvAsk.busy) and the site's own notices (TvAsk.say); never a browser pop-up.
 */
(function () {
  'use strict';
  var csrf = null;
  function tok() {
    if (csrf) return Promise.resolve(csrf);
    var m = document.querySelector('meta[name="csrf-token"]');
    if (m && m.content) return Promise.resolve(csrf = m.content);
    return fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrf = d.csrf_token || ''); });
  }
  function json(r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer properly. Try again.' } }; }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.'); return d; }); }
  function get(u) { return fetch(u, { credentials: 'include' }).then(json); }
  function post(u, body) {
    return tok().then(function (c) { return fetch(u, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); }).then(json);
  }
  /** A photo found at a source (not in the library yet): added to it now, then it's like any library photo. */
  function adopt(it, slot, q) {
    if (!it || !it.found) return Promise.resolve(it);
    return post('/api/stock.php', { action: 'adopt', slot: slot, source: it.source, id: it.source_id, q: q || '' }).then(function (d) { return d.item; });
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function busy(el, on) { if (window.TvAsk && TvAsk.busy) TvAsk.busy(el, on); else el.disabled = on; }
  function say(msg, el, bad) { if (window.TvAsk && TvAsk.say) TvAsk.say(msg, { anchor: el, bad: !!bad }); }

  var css = '.tvk-ov{position:fixed;inset:0;z-index:1995;background:rgba(30,19,12,.55);display:flex;align-items:flex-start;justify-content:center;padding:4vh 1rem;overflow-y:auto}'
    + '.tvk{background:#FFFBF2;border:1px solid #CBB98D;border-radius:1rem;width:100%;max-width:48rem;box-shadow:0 20px 50px rgba(0,0,0,.35);color:#3E2B1F}'
    + '.tvk-hd{display:flex;align-items:center;justify-content:space-between;gap:.5rem;padding:.8rem 1rem;border-bottom:1px solid #E5D7B6}'
    + '.tvk-hd b{font:700 1.1rem var(--tv-font-head,Georgia,serif)}.tvk-x{border:0;background:none;font-size:1.5rem;line-height:1;color:#8A7355;cursor:pointer;padding:.2rem .4rem}'
    + '.tvk-tabs{display:flex;gap:.3rem;padding:.6rem 1rem 0}.tvk-tabs button{font-weight:700;font-size:.85rem;border:1.5px solid #CBB98D;border-bottom:0;border-radius:.5rem .5rem 0 0;padding:.4rem .8rem;background:#FFFBF2;color:#5C4632;cursor:pointer}.tvk-tabs button[aria-selected="true"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}'
    + '.tvk-f{display:flex;gap:.4rem;padding:.7rem 1rem}.tvk-f input{flex:1;min-width:0;border:1px solid #CBB98D;border-radius:.6rem;padding:.55rem .7rem;font-size:1rem;background:#fff}'
    + '.tvk-f button,.tvk-use{border:0;border-radius:.6rem;background:var(--tv-btn);color:var(--tv-btn-text);font-weight:700;padding:.5rem .9rem;cursor:pointer}.tvk-f button:hover,.tvk-use:hover{background:var(--tv-btn-hover)}'
    + '.tvk-note{margin:0 1rem .6rem;font-size:.82rem;color:#5C4632}'
    + '.tvk-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(10.5rem,1fr));gap:.6rem;padding:0 1rem 1rem}'
    + '.tvk-i{border:1px solid #E5D7B6;border-radius:.7rem;overflow:hidden;background:#fff;display:flex;flex-direction:column}'
    + '.tvk-i img{width:100%;aspect-ratio:16/10;object-fit:cover;display:block;background:#E3D3AC}'
    + '.tvk-i small{display:block;padding:.35rem .5rem 0;font-size:.72rem;color:#5C4632;line-height:1.3;overflow-wrap:anywhere}'
    + '.tvk-i .tvk-use{margin:.4rem .5rem .5rem;padding:.4rem .6rem;font-size:.82rem}'
    + '.tvk-ft{border-top:1px solid #E5D7B6;padding:.6rem 1rem;font-size:.8rem;color:#5C4632}'
    + '@media (max-width:767px){.tvk-ov{padding:3px}.tvk{border-radius:.5rem}.tvk-g{grid-template-columns:repeat(2,minmax(0,1fr));gap:3px;padding:0 3px 3px}.tvk-i{border-radius:.5rem}.tvk-f,.tvk-hd{padding-left:.6rem;padding-right:.6rem}.tvk-note{margin:0 .6rem .6rem}}';
  function addCss() { if (document.getElementById('tvk-css')) return; var s = document.createElement('style'); s.id = 'tvk-css'; s.textContent = css; document.head.appendChild(s); }

  function pick(o) {
    o = o || {};
    addCss();
    return new Promise(function (resolve) {
      var back = document.activeElement;
      var ov = document.createElement('div'); ov.className = 'tvk-ov';
      ov.innerHTML = '<div class="tvk" role="dialog" aria-modal="true" aria-labelledby="tvk-h"><div class="tvk-hd"><b id="tvk-h">' + esc(o.title || 'Choose a photo') + '</b><button type="button" class="tvk-x" aria-label="Close">×</button></div>'
        + '<div class="tvk-tabs" role="tablist">' + (o.mine ? '<button type="button" role="tab" data-tab="mine" aria-selected="true">Your gallery</button>' : '') + '<button type="button" role="tab" data-tab="stock" aria-selected="' + (o.mine ? 'false' : 'true') + '">Stock</button></div>'
        + '<form class="tvk-f" role="search"><input type="search" name="q" placeholder="What should it show? (desert, main street, market…)" aria-label="Search the stock library" value="' + esc(o.q || '') + '"><button>Search</button></form>'
        + '<p class="tvk-note" aria-live="polite"></p><div class="tvk-g"></div>'
        + '<div class="tvk-ft">Your photos are yours. Stock photos aren\'t: they\'re always labelled "Stock photo", with their credit, and only illustrate. When you add your own, yours shows instead. All of them are in your Gallery.</div></div>';
      document.body.appendChild(ov);
      var f = ov.querySelector('form'), g = ov.querySelector('.tvk-g'), note = ov.querySelector('.tvk-note'), done = false;
      var tab = o.mine ? 'mine' : 'stock';
      if (tab === 'mine') f.q.placeholder = 'Search your photos\' captions';
      ov.querySelector('.tvk-tabs').addEventListener('click', function (e) {
        var t = e.target.closest('[data-tab]'); if (!t || t.getAttribute('data-tab') === tab) return;
        tab = t.getAttribute('data-tab');
        ov.querySelectorAll('.tvk-tabs [data-tab]').forEach(function (x) { x.setAttribute('aria-selected', x === t ? 'true' : 'false'); });
        f.q.placeholder = tab === 'mine' ? 'Search your photos\' captions' : 'What should it show? (desert, main street, market…)';
        load(f.querySelector('button'));
      });
      function close(v) { if (done) return; done = true; ov.remove(); document.removeEventListener('keydown', key); if (back && back.focus) back.focus(); resolve(v || null); }
      function key(e) { if (e.key === 'Escape') close(null); }
      document.addEventListener('keydown', key);
      ov.addEventListener('click', function (e) { if (e.target === ov || e.target.closest('.tvk-x')) close(null); });
      function load(btn) {
        busy(btn, true);
        var u = tab === 'mine' ? '/api/stock.php?mine=1' + (o.mine && o.mine !== 'me' ? '&b=' + encodeURIComponent(o.mine) : '') + '&q=' + encodeURIComponent(f.q.value.trim())
          : '/api/stock.php?slot=' + encodeURIComponent(o.slot || '') + '&sources=1&q=' + encodeURIComponent(f.q.value.trim()) + (o.place ? '&place=' + encodeURIComponent(o.place) : '');
        get(u).then(function (d) {
          busy(btn, false);
          var all = d.items.concat(d.found || []);
          note.textContent = d.note || (all.length + ' photo' + (all.length === 1 ? '' : 's') + (tab === 'mine' ? ' of yours.' : '. Hover or tap the credit to see where each is from.')) + (d.notes && d.notes.length ? ' ' + d.notes.join(' ') : '');
          d.items = all;
          g.innerHTML = d.items.map(function (it, i) {
            if (it.found) return '<div class="tvk-i"><img src="' + esc(it.card) + '" alt="' + esc(it.title) + '" loading="lazy" referrerpolicy="no-referrer" title="' + esc(it.source_name + ' · ' + it.credit) + '"><small><b>' + esc(it.source_name) + '</b> · ' + esc(it.credit) + '</small>'
              + '<button type="button" class="tvk-use" data-i="' + i + '">Use this</button></div>';
            return '<div class="tvk-i"><img src="' + esc(it.card) + '" alt="' + esc(it.title) + '" loading="lazy" title="' + esc(it.gallery ? it.credit : it.label + ' · ' + it.credit) + '"><small>' + (it.gallery ? esc(it.credit) : '<b>Stock photo</b> · ' + esc(it.credit) + (it.representative ? '' : ' · This place')) + '</small>'
              + '<button type="button" class="tvk-use" data-i="' + i + '">Use this</button></div>';
          }).join('');
          g.__items = d.items;
        }, function (x) { busy(btn, false); note.textContent = ''; say(x.message, btn, true); });
      }
      g.addEventListener('click', function (e) {
        var b = e.target.closest('[data-i]'); if (!b) return;
        var it = g.__items[+b.getAttribute('data-i')];
        if (!it.found) return close(it);
        busy(b, true);   // found at a source: into the library first, then chosen
        adopt(it, o.slot, f.q.value.trim()).then(function (x) { busy(b, false); close(x); }, function (x) { busy(b, false); say(x.message, b, true); });
      });
      f.addEventListener('submit', function (e) { e.preventDefault(); load(f.querySelector('button')); });
      load(f.querySelector('button'));
      f.q.focus();
    });
  }

  // a button that chooses a stock photo for a slot and saves it where data-post says
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-stock-pick]'); if (!b || b.disabled) return;
    e.preventDefault();
    pick({ slot: b.getAttribute('data-slot'), q: b.getAttribute('data-q') || '', place: b.getAttribute('data-place') || '', title: b.getAttribute('data-title') || '', mine: b.getAttribute('data-mine') || '' }).then(function (it) {
      if (!it) return;
      busy(b, true);
      post(b.getAttribute('data-post'), it.gallery ? { action: b.getAttribute('data-own-action'), which: b.getAttribute('data-which') || '', item: it.gallery }   // one of their own photos
        : { action: b.getAttribute('data-action') || 'use', slot: b.getAttribute('data-slot'), owner: b.getAttribute('data-owner') || '', stock: it.id })
        .then(function (d) { busy(b, false); say(d.message || 'Saved.', b); setTimeout(function () { location.reload(); }, 900); }, function (x) { busy(b, false); say(x.message, b, true); });
    });
  });

  // the Gallery's Stock tab: use this stock photo for one of your illustrative spots
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-stock-use]'); if (!b || b.disabled) return;
    e.preventDefault(); busy(b, true);
    var src = b.getAttribute('data-stock-adopt');   // found at a source: added to the library first
    (src ? adopt({ found: true, source: src, source_id: b.getAttribute('data-stock-sid') }, b.getAttribute('data-slot'), b.getAttribute('data-q') || '') : Promise.resolve({ id: +b.getAttribute('data-stock-use') }))
      .then(function (it) { return post(b.getAttribute('data-post'), { action: b.getAttribute('data-action') || 'use', slot: b.getAttribute('data-slot'), owner: b.getAttribute('data-owner') || '', stock: it.id }); })
      .then(function (d) { busy(b, false); say(d.message || 'Saved.', b); setTimeout(function () { location.reload(); }, 1200); }, function (x) { busy(b, false); say(x.message, b, true); });
  });

  // back to automatic: the slot picks from the library by itself again
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-stock-clear]'); if (!b || b.disabled) return;
    e.preventDefault(); busy(b, true);
    post(b.getAttribute('data-post'), { action: b.getAttribute('data-action') || 'use', slot: b.getAttribute('data-slot'), owner: b.getAttribute('data-owner') || '', stock: 0 })
      .then(function (d) { busy(b, false); say(d.message || 'Saved.', b); setTimeout(function () { location.reload(); }, 900); }, function (x) { busy(b, false); say(x.message, b, true); });
  });

  // ---- System Configuration → Stock library ------------------------------------------------------------------------------
  function admin(box) {
    var API = box.getAttribute('data-stock-admin') || '/admin/api/config/stock';
    var no = box.getAttribute('data-stk-no') || '';   // this person may search but not add: Add is greyed with the reason
    var f = box.querySelector('[data-stk-search]'), out = box.querySelector('[data-stk-results]'), more = box.querySelector('[data-stk-more]'), page = 1, items = [];
    var places = {}; (box.querySelectorAll('#stk-places option') || []).forEach(function (op) { places[op.value] = op.getAttribute('data-key'); });
    function card(it, i) {
      var st = it.state === 'ok' && no ? '<button type="button" class="ak-b go" disabled title="' + esc(no) + '">Add to the library</button><small class="stk-why">' + esc(no) + '</small>'
        : it.state === 'ok' ? '<button type="button" class="ak-b go" data-stk-add="' + i + '">Add to the library</button>'
        : '<button type="button" class="ak-b" disabled title="' + esc(it.why) + '">' + (it.state === 'in' ? 'In the library' : 'Can\'t add') + '</button><small class="stk-why">' + esc(it.why) + '</small>';
      return '<div class="stk-r' + (it.state === 'ok' ? '' : ' off') + '"><img src="' + esc(it.thumb) + '" alt="' + esc(it.title) + '" loading="lazy" referrerpolicy="no-referrer">'
        + '<div class="stk-t"><b>' + esc(it.title || '(untitled)') + '</b><small>' + esc(it.credit) + '</small><small>' + esc(it.licence || 'No licence stated') + ' · <a href="' + esc(it.source_url) + '" target="_blank" rel="noopener nofollow">Its page ↗</a></small>' + st + '<div data-stk-form></div></div></div>';
    }
    function run(btn, again) {
      if (!again) { page = 1; items = []; out.innerHTML = ''; }
      busy(btn, true);
      fetch(API + '?action=search&source=' + encodeURIComponent(f.source.value) + '&q=' + encodeURIComponent(f.q.value.trim()) + '&page=' + page, { credentials: 'include' }).then(json).then(function (d) {
        busy(btn, false);
        var start = items.length; items = items.concat(d.items);
        out.insertAdjacentHTML('beforeend', d.items.map(function (it, i) { return card(it, start + i); }).join(''));
        if (!items.length) out.innerHTML = '<p data-tv-status="info" data-tv-label="Nothing:">No photos there that we can use. Try other words or another source.</p>';
        more.hidden = !d.more;
      }, function (x) { busy(btn, false); say(x.message, btn, true); });
    }
    if (f) f.addEventListener('submit', function (e) { e.preventDefault(); run(f.querySelector('button')); });
    if (more) more.addEventListener('click', function () { page++; run(more, true); });
    if (out) out.addEventListener('click', function (e) {
      var b = e.target.closest('[data-stk-add]'); if (!b) return;
      var it = items[+b.getAttribute('data-stk-add')], fb = b.parentNode.querySelector('[data-stk-form]');
      if (fb.innerHTML) { fb.innerHTML = ''; return; }
      fb.innerHTML = '<form class="stk-addf"><label>Subjects (what it shows, with commas)<input class="ak-in" name="subjects" required value="' + esc(f.q.value.trim().toLowerCase()) + '"></label>'
        + '<label>Place (optional, from the places tree)<input class="ak-in" name="place" list="stk-places" placeholder="Type a region, area or town"></label>'
        + '<fieldset class="stk-sc"><legend>Does it show that place?</legend><label><input type="radio" name="scope" value="representative" checked> Representative (the kind of place)</label><label><input type="radio" name="scope" value="this_place"> This place itself</label></fieldset>'
        + '<button class="ak-b go">Add it</button></form>';
      fb.querySelector('form').addEventListener('submit', function (ev) {
        ev.preventDefault(); var ff = ev.target, go = ff.querySelector('button');
        var pl = ff.place.value.trim(), key = pl ? places[pl] : '';
        if (pl && !key) { say('Choose the place from the list, or leave it blank.', ff.place, true); return; }
        busy(go, true);
        post(API, { action: 'add', source: f.source.value, id: it.id, subjects: ff.subjects.value, place: key || '', scope: (ff.querySelector('input[name=scope]:checked') || {}).value || 'representative' })
          .then(function (d) {
            busy(go, false); say(d.message, b);
            it.state = 'in'; b.outerHTML = '<button type="button" class="ak-b" disabled>In the library</button>'; fb.innerHTML = '';
            document.querySelectorAll('[data-ak-table]').forEach(function (el) { if (el.__list && el.__list.C && el.__list.C.tool === 'config/stock') el.__list.load(); });   // the library's list, below
          }, function (x) { busy(go, false); say(x.message, go, true); });
      });
    });
  }
  function init() { document.querySelectorAll('[data-stock-admin]').forEach(admin); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  window.TvStock = { pick: pick, adopt: adopt };
})();
