// js/tv-pager.js — the lists' standard on the public pages, the same as the admin's (Jason, 2026-11-12: "the standard is 10
// records with page count optional from dropdown"): 10 a page unless the visitor chooses 25, 50 or 100 (kept in this
// browser for each list; a grid of cards rounds it up to whole rows), a full-width "Show 10 more" under the list, and a bar with the pages (‹ 1 2 … ›), the range
// ("11–20 of 64") and how many a page. With 10 or fewer in all, neither shows.
//
//   var pg = TvPager.mount(el, { key: 'directory', onMore: fn, onPage: fn(page), onPer: fn(per) });
//   pg.per                 how many a page (remembered)
//   pg.draw({ total: 64, page: 0, shown: 20 })   page: the first page shown (0-based), shown: how many are on screen
//   pg.busy(true|false)    the More button's spinner while the next ones load
//   pg.size()              how many a page really: rounded up to whole rows when the list is a grid of cards ({ grid: el }),
//                          so a page never ends on a half row (Jason, 2026-11-12: "count per row and show the correct
//                          amount of cards"): 4 across shows 12, 3 across 12, 2 across 10
//
//   TvPager.local(list, { key })   a list the page already holds (its children): shows a page of them at a time, with the
//                                  same bar under it; children added later (a "Show more" that fetches) are paged too
//
// Every page (js loaded by the header): any grid of cards is paged this way by itself (Jason, 2026-11-12: "this should be a
// function for all grids not just landmarks"): a grid (2 or more across) of more than 12 children all of one kind (the same
// tag and first class), found when the page loads and whenever a list is drawn later. Left alone: forms, tables, carousels,
// the admin's lists, lists a page pages itself (TvPager.mount with grid), and any list marked data-tv-pager="off".
(function () {
  'use strict';
  if (window.TvPager) return;
  var PER = [10, 25, 50, 100];
  function css() {
    if (document.getElementById('tvp-css')) return;
    var s = document.createElement('style'); s.id = 'tvp-css';
    s.textContent = '.tvp-more{display:block;width:100%;margin:.6rem 0 0;padding:.6rem 1rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;font:600 .95rem system-ui,sans-serif;color:#3E2B1F;cursor:pointer}.tvp-more:hover{border-color:#92400E;color:#92400E}.tvp-more[hidden]{display:none}'
      + '.tvp-bar{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .8rem;margin-top:.5rem;padding-top:.5rem;border-top:1px solid #EADFC4;font-size:.9rem;color:#8A7355}.tvp-bar:empty{display:none}'
      + '.tvp-pages{display:flex;flex-wrap:wrap;gap:.25rem;align-items:center}.tvp-b{min-width:34px;height:34px;padding:0 .5rem;border:1px solid #E7D9C4;border-radius:.4rem;background:#fff;color:#3E2B1F;font:inherit;cursor:pointer;font-variant-numeric:tabular-nums}'
      + '.tvp-b:hover:not(:disabled){border-color:#92400E;color:#92400E}.tvp-b[aria-current]{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text);font-weight:700}.tvp-b:disabled{opacity:.4;cursor:default}.tvp-gap{padding:0 .15rem}'
      + '.tvp-per{margin-left:auto;display:flex;align-items:center;gap:.4rem;white-space:nowrap;color:#57534E}.tvp-per select{padding:.35rem .5rem;border:1px solid #D6C7B0;border-radius:.4rem;background:#fff;font:inherit}'
      + '[data-tvp]>[hidden]{display:none!important}'
      + '@media (max-width:767px){.tvp-bar{margin-left:3px;margin-right:3px}.tvp-per{margin-left:0}}';
    document.head.appendChild(s);
  }
  function mount(el, o) {
    css(); o = o || {};
    var key = 'tvp:' + (o.key || location.pathname), per = 10;
    if (o.grid && !o.local) o.grid.setAttribute('data-tvp', 'own');   // paged by its page (the Marketplace, the Explore feed)
    try { var v = +localStorage.getItem(key); if (PER.indexOf(v) >= 0) per = v; } catch (e) {}
    el.innerHTML = '<button type="button" class="tvp-more" hidden></button><div class="tvp-bar"></div>';
    var more = el.firstChild, bar = el.lastChild;
    var self = {
      per: per,
      cols: function () {
        var g = o.grid; if (!g) return 1;
        var cs = getComputedStyle(g); if (cs.display.indexOf('grid') < 0) return 1;
        var n = cs.gridTemplateColumns.split(' ').filter(function (x) { return x && x !== 'none'; }).length;
        return Math.max(1, n || 1);
      },
      size: function () { var c = self.cols(); return Math.ceil(self.per / c) * c; },
      busy: function (on) { if (window.TvAsk && TvAsk.busy) TvAsk.busy(more, !!on); else more.disabled = !!on; },
      draw: function (d) {
        var total = +d.total || 0, a = +d.page || 0, shown = +d.shown || 0, p = self.size();
        var from = a * p, to = Math.min(total, from + shown), pages = Math.max(1, Math.ceil(total / p)), z = Math.max(a, Math.ceil(to / p) - 1), left = total - to;
        more.hidden = left <= 0 || total <= p; more.textContent = 'Show ' + Math.min(p, left).toLocaleString() + ' more';
        if (total <= p) { bar.innerHTML = ''; return; }
        var b = function (x, label, cur, aria, off) { return '<button type="button" class="tvp-b" data-pg="' + x + '"' + (cur ? ' aria-current="page"' : '') + (off ? ' disabled' : '') + ' aria-label="' + aria + '">' + label + '</button>'; };
        var nav = '';
        if (pages > 1) {
          var want = {}; [0, pages - 1, a - 1, z + 1].forEach(function (x) { if (x >= 0 && x < pages) want[x] = 1; }); for (var x = a; x <= z; x++) want[x] = 1;
          var last = -1; nav = b(a - 1, '‹', false, 'Previous page', a <= 0);
          Object.keys(want).map(Number).sort(function (m, n) { return m - n; }).forEach(function (x) { if (last >= 0 && x > last + 1) nav += '<span class="tvp-gap">…</span>'; nav += b(x, (x + 1).toLocaleString(), x >= a && x <= z, 'Page ' + (x + 1)); last = x; });
          nav += b(z + 1, '›', false, 'Next page', z >= pages - 1);
        }
        bar.innerHTML = '<nav class="tvp-pages" aria-label="Pages">' + nav + '</nav><span>' + (from + 1).toLocaleString() + '–' + to.toLocaleString() + ' of ' + total.toLocaleString() + '</span>'
          + '<label class="tvp-per">Show <select aria-label="How many a page">' + PER.map(function (n) { return '<option' + (n === p ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select> per page</label>';
      }
    };
    more.addEventListener('click', function () { if (o.onMore) o.onMore(); });
    bar.addEventListener('click', function (e) {
      var x = e.target.closest('[data-pg]'); if (!x || x.disabled) return;
      if (o.onPage) o.onPage(+x.getAttribute('data-pg'));
      var top = o.top || el.parentNode; if (top && top.getBoundingClientRect && top.getBoundingClientRect().top < 0) top.scrollIntoView({ block: 'start', behavior: 'smooth' });
    });
    bar.addEventListener('change', function (e) {
      if (e.target.tagName !== 'SELECT') return;
      self.per = +e.target.value; try { localStorage.setItem(key, String(self.per)); } catch (x) {}
      if (o.onPer) o.onPer(self.per);
    });
    return self;
  }
  function local(list, o) {
    if (!list || list.getAttribute('data-tvp')) return null;
    list.setAttribute('data-tvp', '1'); o = o || {};
    var host = document.createElement('div'); list.parentNode.insertBefore(host, list.nextSibling);
    var first = 0, pages = 1, pg;
    // the cards only: a style sheet or script that came with the first card isn't one (it made a page of 12 show 11, 2026-11-12)
    function items() { return Array.prototype.filter.call(list.children, function (c) { return c.nodeType === 1 && !/^(SCRIPT|STYLE|LINK|TEMPLATE|META)$/.test(c.tagName); }); }
    function show() {
      var all = items(), p = pg.size(), a = first * p, z = (first + pages) * p;
      all.forEach(function (c, i) { c.hidden = i < a || i >= z; });
      pg.draw({ total: all.length, page: first, shown: Math.max(0, Math.min(all.length, z) - a) });
    }
    pg = mount(host, { local: true, key: o.key || ('grid:' + location.pathname + ':' + (list.id || list.className.split(' ')[0] || 'list')), top: o.top || list, grid: list,
      onMore: function () { pages++; show(); },
      onPage: function (x) { first = x; pages = 1; show(); },
      onPer: function () { first = 0; pages = 1; show(); } });
    if (window.MutationObserver) new MutationObserver(function () { show(); }).observe(list, { childList: true });
    var lastCols = pg.cols();   // the window resized to another number across: whole rows again
    window.addEventListener('resize', function () { var c = pg.cols(); if (c !== lastCols) { lastCols = c; first = 0; pages = 1; show(); } });
    show();
    return pg;
  }
  window.TvPager = { mount: mount, local: local };
  // lists marked in the page: <div data-tv-pager="key">…</div>
  function cards(l) {
    var k = null, n = 0;
    for (var c = l.firstElementChild; c; c = c.nextElementSibling) {
      if (/^(SCRIPT|STYLE|LINK|TEMPLATE|META)$/.test(c.tagName)) continue;
      var sig = c.tagName + '.' + ((c.getAttribute('class') || '').trim().split(/\s+/)[0] || '');
      if (k === null) k = sig; else if (sig !== k) return 0;   // mixed children: a layout, not a list
      n++;
    }
    return n;
  }
  function found(l) {
    if (l.getAttribute('data-tvp') || l.getAttribute('data-tv-pager') === 'off') return false;
    if (l.closest('form,table,nav,select,.ak-list,[data-ak-table],.xh-ct,[data-tv-pager="off"],.tvm,.tva,.dr-pop')) return false;
    if (l.childElementCount <= 12 || cards(l) <= 12) return false;
    var cs = getComputedStyle(l); if (cs.display.indexOf('grid') < 0) return false;
    return cs.gridTemplateColumns.split(' ').filter(function (x) { return x && x !== 'none'; }).length >= 2;
  }
  var scanning = false;
  function auto() {
    if (scanning) return; scanning = true;
    try {
      document.querySelectorAll('[data-tv-pager]').forEach(function (l) { if (l.getAttribute('data-tv-pager') !== 'off') local(l, { key: l.getAttribute('data-tv-pager') }); });
      if (!/^\/admin\//.test(location.pathname)) {
        var all = document.body ? document.body.getElementsByTagName('*') : [];
        for (var i = 0; i < all.length; i++) if (all[i].childElementCount > 12 && found(all[i])) local(all[i], {});
      }
    } finally { scanning = false; }
  }
  var t = 0;
  function soon() { clearTimeout(t); t = setTimeout(auto, 350); }
  function start() {
    auto();
    if (window.MutationObserver && document.body) new MutationObserver(function (m) {   // lists drawn later (groups, results)
      for (var i = 0; i < m.length; i++) if (m[i].addedNodes.length && !(m[i].target.closest && m[i].target.closest('[data-tvp]'))) { soon(); return; }
    }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
