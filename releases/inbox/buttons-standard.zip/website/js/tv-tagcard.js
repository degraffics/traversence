/* js/tv-tagcard.js — the preview card of a highlighted name in a piece of content (decisions/0132 §2a): hover it (or
   focus it with the keyboard) and a small card shows what it is, where, a line about it and See more. On a phone the
   first tap opens the card and See more goes on; a tap elsewhere or Esc closes it. Names carry data-tag="entity:12". */
(function () {
  if (window.TvTagCard) return;
  var cache = {}, card = null, cur = null, showT = 0, hideT = 0;
  var touch = window.matchMedia && window.matchMedia('(hover: none)').matches;
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  var css = document.createElement('style');
  css.textContent = '.tv-tc{position:absolute;z-index:80;width:min(18rem,calc(100vw - 16px));background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;box-shadow:0 8px 24px rgba(62,43,31,.18);padding:.6rem .7rem;color:#3E2B1F;font:400 .85rem/1.35 system-ui,sans-serif}'
    + '.tv-tc img{width:100%;height:7rem;object-fit:cover;border-radius:.5rem;margin-bottom:.4rem;display:block}'
    + '.tv-tc b{display:block;font:700 1rem var(--tv-font-head,Georgia,serif);color:#92400E}.tv-tc small{display:block;color:#5C4632;font-size:.78rem;margin-top:.1rem}'
    + '.tv-tc p{margin:.35rem 0 0;color:#3E2B1F}.tv-tc .tv-tc-go{display:flex;justify-content:space-between;align-items:center;gap:.5rem;margin-top:.5rem}'
    + '.tv-tc .tv-tc-go a{font-weight:700;color:var(--tv-btn-text);background:var(--tv-btn);border-radius:999px;padding:.25rem .8rem;text-decoration:none;font-size:.8rem}'
    + '.tv-tc .tv-tc-go a.tel{background:none;color:#92400E;text-decoration:underline;padding:0}'
    + '.tv-tc .tv-tc-ic{display:flex;gap:.35rem;margin-left:auto;margin-right:.4rem}.tv-tc .tv-tc-ic a,.tv-tc .tv-tc-ic button{width:30px;height:30px;padding:0;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;border:1px solid #CBB98D;background:#FFFBF2;color:#B45309;cursor:pointer}'
    + '.tv-tc .tv-tc-ic svg{width:15px;height:15px}'
    + 'a.gl[data-tag]{text-decoration-style:dotted;text-underline-offset:3px}a.gl[data-tag]:hover,a.gl[data-tag].on{background:rgba(180,83,9,.1);border-radius:3px}';
  document.head.appendChild(css);

  function close() { if (card) card.remove(); card = null; if (cur) cur.classList.remove('on'); cur = null; }

  function place(a) {
    var r = a.getBoundingClientRect(), w = card.offsetWidth, left = Math.max(8, Math.min(window.scrollX + r.left, window.scrollX + document.documentElement.clientWidth - w - 8));
    var top = window.scrollY + r.bottom + 6;
    if (r.bottom + card.offsetHeight + 12 > window.innerHeight && r.top > card.offsetHeight + 12) top = window.scrollY + r.top - card.offsetHeight - 6;
    card.style.left = left + 'px'; card.style.top = top + 'px';
  }

  // where it is (Jason, 2026-11-08): See on our map, and Directions in the visitor's own maps app
  var SVG = function (p) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
  function icons(c) {
    if (c.lat == null || c.lon == null) return '';
    var dest = c.address ? c.address : (c.lat + ',' + c.lon);
    return '<span class="tv-tc-ic">' + (window.TvMap ? '<button type="button" data-tc-map title="See on map" aria-label="See ' + esc(c.name) + ' on the map">' + SVG('<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>') + '</button>' : '')
      + '<a href="https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(dest) + '" target="_blank" rel="noopener" title="Directions" aria-label="Directions to ' + esc(c.name) + '" data-out="directions"' + (c.e ? ' data-e="' + c.e + '"' : '') + '>' + SVG('<polygon points="3 11 22 2 13 21 11 13 3 11"/>') + '</a></span>';
  }
  function showOnMap(c) {
    close();
    var here = { lat: c.lat, lon: c.lon, radius: 5 }, pin = { id: 'tc:' + c.name, lat: c.lat, lon: c.lon, name: c.name, category: c.what || '' };
    TvMap.open({ panel: true, title: c.name, radius: 5, select: pin.id, titleFor: function () { return c.name; },
      load: function () { return Promise.resolve({ pins: [pin], center: here }); } });
  }

  function draw(a, c) {
    close();
    cur = a; a.classList.add('on');
    card = document.createElement('div');
    card.className = 'tv-tc'; card.setAttribute('role', 'dialog'); card.setAttribute('aria-label', c.name);
    var tel = (c.phone || '').replace(/[^\d+]/g, '');
    card.innerHTML = (c.image ? '<img src="' + esc(c.image) + '" alt="" loading="lazy">' : '')
      + '<b>' + esc(c.name) + '</b><small>' + esc([c.what, c.where].filter(Boolean).join(' · ')) + '</small>'
      + (c.line ? '<p>' + esc(c.line) + '</p>' : '')
      + '<div class="tv-tc-go">' + (tel ? '<a class="tel" href="tel:' + esc(tel) + '" data-out="call"' + (c.e ? ' data-e="' + c.e + '"' : '') + '>' + esc(c.phone) + '</a>' : '<span></span>') + icons(c) + '<a href="' + esc(c.url) + '">See more</a></div>';
    var mb = card.querySelector('[data-tc-map]');
    if (mb) mb.addEventListener('click', function () { showOnMap(c); });
    card.addEventListener('mouseenter', function () { clearTimeout(hideT); });
    card.addEventListener('mouseleave', function () { hideT = setTimeout(close, 250); });
    document.body.appendChild(card);
    place(a);
  }

  function open(a) {
    var ref = a.getAttribute('data-tag');
    if (cache[ref] === false) return;
    if (cache[ref]) { draw(a, cache[ref]); return; }
    fetch('/api/tag-card.php?ref=' + encodeURIComponent(ref)).then(function (r) { return r.json(); }).then(function (j) {
      cache[ref] = j && j.ok ? j.card : false;
      if (cache[ref] && (a.matches(':hover') || a === document.activeElement || touch)) draw(a, cache[ref]);
    }).catch(function () { cache[ref] = false; });
  }

  document.addEventListener('mouseover', function (e) {
    var a = e.target.closest && e.target.closest('a[data-tag]'); if (!a || touch) return;
    clearTimeout(hideT); clearTimeout(showT);
    if (a !== cur) showT = setTimeout(function () { open(a); }, 250);
  });
  document.addEventListener('mouseout', function (e) {
    var a = e.target.closest && e.target.closest('a[data-tag]'); if (!a || touch) return;
    clearTimeout(showT); hideT = setTimeout(close, 300);
  });
  document.addEventListener('focusin', function (e) { var a = e.target.closest && e.target.closest('a[data-tag]'); if (a) open(a); });
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[data-tag]');
    if (a && touch && a !== cur && cache[a.getAttribute('data-tag')] !== false) { e.preventDefault(); open(a); return; }   // a phone: the first tap opens the card
    if (card && !card.contains(e.target) && a !== cur) close();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  window.addEventListener('resize', close);
  window.TvTagCard = { close: close };
})();
