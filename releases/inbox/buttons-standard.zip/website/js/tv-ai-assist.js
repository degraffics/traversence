/*
 * js/tv-ai-assist.js — AI Assist where members write (Jason, 2026-10-30): a small "AI Assist" button under a writing box,
 * opening a panel to ask (a caption, a paragraph about the place, a question), answered from what we've researched by
 * /api/ai-assist.php, with Insert (adds it to the box) and Copy. Each ask is kept in the member's asks on /ai/ and counted
 * by where it came from (the source). It explains, never hides, why it isn't available: signed out, AI Assist & Learning
 * off, or no paid plan.
 *   TvAi.attach(textarea, { source: 'journey', place: function () { return placeKey; } })
 */
(function () {
  var st = null;
  function status() {
    if (st) return st;
    st = fetch('/api/ai-assist.php', { credentials: 'same-origin' }).then(function (r) { return r.json(); }).catch(function () { return { ok: false }; });
    return st;
  }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var css = '.tvai-b{display:inline-flex;align-items:center;gap:.35rem;margin-top:.35rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:999px;padding:.3rem .8rem;font-weight:600;color:#92400E;font-size:.85rem}'
    + '.tvai-p{margin-top:.4rem;background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:.7rem;padding:.7rem .75rem;font-size:.9rem}.tvai-p[hidden]{display:none}'
    + '.tvai-r{display:flex;gap:.4rem;flex-wrap:wrap}.tvai-r input{flex:1 1 14rem;min-width:0;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.55rem;padding:.5rem .65rem;font:inherit}'
    + '.tvai-go{background:var(--tv-btn);color:var(--tv-btn-text);border-radius:999px;padding:.45rem 1rem;font-weight:600}.tvai-out{white-space:pre-wrap;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.55rem;padding:.6rem .7rem;margin-top:.5rem;line-height:1.55}'
    + '.tvai-a{display:flex;gap:.4rem;margin-top:.4rem;flex-wrap:wrap}.tvai-a button{background:#FFFBF2;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .8rem;font-weight:600;color:#92400E}.tvai-n{color:#5C4632;font-size:.8rem;margin:.35rem 0 0}';
  function attach(box, o) {
    if (!box || box.__tvai) return; box.__tvai = true; o = o || {};
    if (!document.getElementById('tvai-css')) { var s = el('style'); s.id = 'tvai-css'; s.textContent = css; document.head.appendChild(s); }
    var btn = el('button', 'tvai-b', '✦ AI Assist'); btn.type = 'button'; btn.title = 'Help writing this, from what we\'ve researched';
    var panel = el('div', 'tvai-p'); panel.hidden = true;
    box.insertAdjacentElement('afterend', btn); btn.insertAdjacentElement('afterend', panel);
    btn.addEventListener('click', function () {
      panel.hidden = !panel.hidden; if (panel.hidden || panel.__ready) return;
      status().then(function (s) {
        panel.__ready = true;
        if (!s.signed_in) { panel.innerHTML = '<p data-tv-status="info" data-tv-label="Sign in first:">AI Assist is for members.</p>'; return; }
        if (!s.on) { panel.innerHTML = '<p data-tv-status="info" data-tv-label="Turned off:">Your words go to our AI only with AI Assist &amp; Learning on. <a class="underline" href="/ai/">Turn it on</a></p>'; return; }
        if (!s.funded) { panel.innerHTML = '<p data-tv-status="info" data-tv-label="Comes with a paid plan:">AI Assist is part of Personal Plus and Pro, and every paid business plan. <a class="underline" href="/plans.php">See the plans</a></p>'; return; }
        panel.innerHTML = '<div class="tvai-r"><input type="text" maxlength="1000" placeholder="e.g. A paragraph about the history of this place" aria-label="What should AI Assist write?"><button type="button" class="tvai-go">Write it</button></div>'
          + '<p class="tvai-n">Written only from what we\'ve researched, never guessed. ' + (s.free_left ? s.free_left + ' free ask' + (s.free_left === 1 ? '' : 's') + ' left today' : s.credits_left + ' credit' + (s.credits_left === 1 ? '' : 's') + ' left') + '. Your asks are kept on <a class="underline" href="/ai/#asks">AI Assist</a>.</p><div class="tvai-res"></div>';
        var input = panel.querySelector('input'), go = panel.querySelector('.tvai-go'), res = panel.querySelector('.tvai-res');
        var ask = function () {
          var q = input.value.trim(); if (q.length < 3) { input.focus(); return; }
          go.disabled = true; go.textContent = 'Writing…';
          var body = { ask: q, source: o.source || 'ai_page', place: typeof o.place === 'function' ? o.place() : (o.place || '') };
          fetch('/api/ai-assist.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': s.csrf },
            body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }).then(function (r) { return r.json(); }).then(function (j) {
            go.disabled = false; go.textContent = 'Write it';
            if (!j.ok) { if (window.TvAsk) TvAsk.say(j.error || 'AI Assist couldn\'t write that just now.', { anchor: go, bad: true }); return; }
            res.innerHTML = (j.known ? '' : '<p data-tv-status="info" data-tv-label="We\'re researching it:">We don\'t know enough yet; we\'ll email you when we do.</p>')
              + '<div class="tvai-out">' + esc(j.text) + '</div><div class="tvai-a"><button type="button" data-i>Insert</button><button type="button" data-c>Copy</button></div>'
              + '<p class="tvai-n">' + (j.left.free ? j.left.free + ' free left today' : j.left.credits + ' credits left') + ' · check it reads right: it\'s yours to edit.</p>';
            res.querySelector('[data-i]').onclick = function () { box.value = box.value.replace(/\s+$/, '') + (box.value.trim() ? '\n\n' : '') + j.text; box.dispatchEvent(new Event('input', { bubbles: true })); if (window.TvAsk) TvAsk.say('Added to what you\'re writing.', { anchor: this, bad: false }); };
            res.querySelector('[data-c]').onclick = function () { var b = this; if (navigator.clipboard) navigator.clipboard.writeText(j.text).then(function () { if (window.TvAsk) TvAsk.say('Copied.', { anchor: b, bad: false }); }); };
          }, function () { go.disabled = false; go.textContent = 'Write it'; if (window.TvAsk) TvAsk.say('AI Assist couldn\'t be reached. Try again in a moment.', { anchor: go, bad: true }); });
        };
        go.addEventListener('click', ask); input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); ask(); } });
        input.focus();
      });
    });
  }
  window.TvAi = { attach: attach };
})();
