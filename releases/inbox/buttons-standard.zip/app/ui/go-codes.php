<?php
// app/ui/go-codes.php — the shared look and nav of the GO Codes pages (decisions/0096): Create (/qr/), Cart (/qr/cart.php)
// and Manage GO Codes (/qr/manage.php). Their shared script is js/go-codes.js.
declare(strict_types=1);

/** The styles and the nav strip; $active: create | cart | manage. $nav false: the styles and script only (a client's order page). */
function tv_go_head(string $active, bool $nav = true): void
{
    $tabs = ['create' => ['Create', '/qr/'], 'cart' => ['Cart', '/qr/cart.php'], 'manage' => ['Manage GO Codes', '/qr/manage.php']];
    ?>
<style>
  .go{max-width:64rem;color:#3E2B1F}
  .go h1{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.9rem;margin:0 0 .3rem}
  .go h2{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.15rem;margin:0 0 .6rem}
  .go-lead{font-size:.95rem;line-height:1.55;max-width:46rem;margin:0 0 .8rem}
  .go-nav{display:flex;gap:.35rem;flex-wrap:wrap;margin:0 0 .8rem}
  .go-nav a{border:1px solid #CBB98D;background:#FFFBF2;color:#5C4632;border-radius:999px;padding:.35rem .8rem;font-size:.85rem;font-weight:600;text-decoration:none;display:inline-flex;gap:.35rem;align-items:center}
  .go-nav a.on{background:#8FBCA8;border-color:#6E9F8A;color:#1F3A2E;box-shadow:0 0 0 3px rgba(143,188,168,.3)}
  .go-nav b{background:#92400E;color:#fff;border-radius:999px;font-size:.7rem;padding:0 .4rem;min-width:1.1rem;text-align:center}
  .go-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.9rem;padding:1rem;margin:0 0 .9rem}
  .go-step{font-size:.78rem;font-weight:700;color:#8A7355;text-transform:uppercase;letter-spacing:.05em;margin:.9rem 0 .35rem}.go-step:first-child{margin-top:0}
  .go-types{display:flex;flex-wrap:wrap;gap:.35rem}
  .go-types button{border:1px solid #CBB98D;background:#FFFBF2;color:#5C4632;border-radius:999px;padding:.35rem .75rem;font-size:.85rem;font-weight:600;cursor:pointer;display:inline-flex;gap:.35rem;align-items:center}
  .go-types button small{font-size:.66rem;font-weight:700;border-radius:999px;padding:.05rem .4rem;background:#E7F3EC;color:#1F3A2E}
  .go-types button small.p{background:#FDE7C8;color:#7C2D12}
  .go-types button[aria-pressed="true"]{background:#8FBCA8;border-color:#6E9F8A;color:#1F3A2E;box-shadow:0 0 0 3px rgba(143,188,168,.3)}
  .go-grid{display:grid;grid-template-columns:1fr 18rem;gap:1rem;align-items:start}
  .go-f label{display:block;font-size:.8rem;font-weight:600;margin:.5rem 0 .15rem}
  .go-f input,.go-f textarea,.go-f select,.go-in{width:100%;border:1px solid #CBB98D;border-radius:.55rem;padding:.45rem .6rem;background:#fff;font:inherit;font-size:.92rem;color:#3E2B1F}
  .go-f textarea{min-height:4.5rem}
  .go-2{display:grid;grid-template-columns:1fr 1fr;gap:.5rem}
  .go-look{display:flex;flex-wrap:wrap;gap:.7rem;align-items:center;font-size:.82rem}
  .go-look input[type=color]{width:2rem;height:1.6rem;border:1px solid #CBB98D;border-radius:.3rem;padding:0;background:none;vertical-align:middle}
  .go-prev{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.8rem;padding:.8rem;text-align:center;position:sticky;top:1rem}
  .go-prev img{width:100%;max-width:15rem;aspect-ratio:1;display:block;margin:0 auto;background:#fff;border-radius:.3rem}
  .go-ph{width:100%;max-width:15rem;aspect-ratio:1;margin:0 auto;display:flex;align-items:center;justify-content:center;border:2px dashed #E3D3AC;border-radius:.4rem;color:#8A7355;font-size:.85rem;padding:1rem}
  .go-msg{font-size:.8rem;min-height:1.1rem;margin:.4rem 0 0;color:#5C4632}.go-msg.bad{color:#B91C1C}
  .go-price{font-size:.9rem;margin:.4rem 0}.go-price b{font-size:1.05rem}
  .go-btn{display:inline-flex;align-items:center;justify-content:center;gap:.35rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:.6rem;padding:.5rem .85rem;font-weight:600;font-size:.88rem;cursor:pointer;text-decoration:none}
  .go-btn.main{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text)}.go-btn[disabled]{opacity:.5;cursor:default}.go-btn.wide{width:100%}.go-btn.sm{padding:.2rem .55rem;font-size:.76rem}
  .go-ic{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
  .go-note{font-size:.8rem;color:#5C4632;line-height:1.45}
  .go-note a,.go-lead a{color:#92400E;text-decoration:underline;font-weight:600}
  .go-list{list-style:none;margin:0;padding:0;display:grid;gap:.6rem}
  .go-it{position:relative;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem 3rem .75rem .75rem;display:flex;gap:.7rem;min-height:7.6rem}
  .go-it img{width:4.5rem;height:4.5rem;flex:0 0 4.5rem;background:#fff;border-radius:.25rem}
  .go-it .nm{color:#92400E;text-decoration:underline;font-weight:700}
  .go-it .d{font-size:.8rem;color:#5C4632;line-height:1.45;min-width:0;overflow-wrap:anywhere}
  .go-it.off{opacity:.65}
  .go-tag{display:inline-block;border-radius:999px;padding:0 .45rem;font-size:.7rem;font-weight:700;background:#E7CCAA;color:#5C4632}
  .go-tag.free,.go-tag.paid,.go-tag.granted{background:#E7F3EC;color:#1F3A2E}.go-tag.cart{background:#FDE7C8;color:#7C2D12}.go-tag.pending{background:#FEF3C7}
  .go-acts{position:absolute;top:.6rem;right:.55rem;display:flex;flex-direction:column;gap:.35rem}
  .go-acts button,.go-acts a{width:30px;height:30px;border-radius:999px;border:1.5px solid #B8863B;background:#FFFBF2;color:#B45309;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0;font-size:.62rem;font-weight:800;text-decoration:none}
  .go-acts button:hover,.go-acts a:hover{background:#8FBCA8;border-color:#6E9F8A;color:#1F3A2E;box-shadow:0 0 6px rgba(143,188,168,.7)}
  .go-acts .go-ic{width:15px;height:15px}
  .go-sum{display:flex;justify-content:space-between;font-weight:700;margin:.6rem 0}
  .go-banner{background:#E7F3EC;border:1px solid #B7D9C7;border-radius:.7rem;padding:.7rem .8rem;margin:0 0 .8rem;font-size:.88rem}
  .go-banner.warm{background:#FEF3C7;border-color:#FCD34D}
  .go-stats{margin-top:.5rem;font-size:.75rem}
  .go-bars{display:flex;align-items:flex-end;gap:2px;height:3rem;margin:.3rem 0}
  .go-bars i{flex:1;background:#8FBCA8;min-height:1px;border-radius:1px}
  @media (max-width:767px){
    .go-grid{grid-template-columns:1fr}
    .go-prev{position:static}
    .go-card{border-radius:.5rem;padding:.8rem}
  }
</style>
<?php if ($nav): ?><nav class="go-nav" aria-label="GO Codes">
  <?php foreach ($tabs as $k => [$l, $u]): ?><a href="<?= $u ?>" class="<?= $k === $active ? 'on' : '' ?>"<?= $k === $active ? ' aria-current="page"' : '' ?>><?= htmlspecialchars($l) ?><?= $k === 'cart' ? ' <b data-go-count hidden>0</b>' : '' ?></a><?php endforeach; ?>
</nav><?php endif; ?>
<script src="/js/go-codes.js?v=<?= (int) @filemtime(__DIR__ . '/../../website/js/go-codes.js') ?>"></script>
<?php
}
