<?php
// app/ui/gallery-ui.php — the gallery's parts, the same wherever it plugs in (decisions/0126): a photo tile (its blurred
// tiny copy shows at once, the photo fades in as it nears the screen), brick rows on wide screens and two columns on
// phones, month groups that show six and "View all", and album cards (cover, title and date on a dark gradient so they
// read on any photo).
declare(strict_types=1);

function tv_gallery_css(): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    return '<style>
.gl{max-width:76rem;margin:0 auto}
.gl-h{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem;margin:.2rem 0 .8rem}.gl-h h1{font:700 1.6rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin-right:auto}
.gl-b{display:inline-flex;align-items:center;gap:.4rem;border:1.5px solid #CBB98D;background:#FFFBF2;color:#5C4632;border-radius:999px;padding:.45rem .85rem;font:600 .88rem system-ui,sans-serif;cursor:pointer;text-decoration:none;min-height:2.5rem}
.gl-b:hover{border-color:#B45309}.gl-b.go{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text)}.gl-b.go:hover{background:var(--tv-btn-hover)}.gl-b.danger{color:#991B1B;border-color:#E9B4B4}
.gl-b svg{width:1.1rem;height:1.1rem}.gl-b[aria-pressed="true"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3A2E;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
.gl-tabs{display:flex;gap:.4rem;margin:0 0 1rem}.gl-tabs a{padding:.45rem 1rem;border-radius:999px;border:1.5px solid #CBB98D;color:#5C4632;font-weight:600;text-decoration:none;font-size:.9rem}
.gl-tabs a[aria-current="page"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3A2E;box-shadow:0 0 0 3px rgba(143,188,168,.3)}
.gl-yr{font:700 1.35rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:1.6rem 0 .2rem}.gl-mo{display:flex;align-items:baseline;gap:.5rem;margin:.9rem 0 .5rem;font-weight:700;color:#5C4632}.gl-mo small{color:#8A7355;font-weight:400}
.gl-rows{display:flex;flex-wrap:wrap;gap:.6rem}.gl-rows::after{content:"";flex-grow:999}
.gl-t{position:relative;display:block;padding:0;border:0;border-radius:.5rem;overflow:hidden;cursor:zoom-in;background:#E3D3AC center/cover no-repeat;height:13rem;flex-grow:1}
.gl-t img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .35s}.gl-t img.on{opacity:1}
.gl-t:focus-visible{outline:3px solid #8FBCA8;outline-offset:2px}
.gl-t .vid{position:absolute;right:.4rem;bottom:.4rem;background:rgba(20,13,8,.65);color:#fff;border-radius:999px;padding:.12rem .5rem;font:600 .75rem system-ui}
.gl-t .chk{position:absolute;left:.45rem;top:.45rem;width:1.6rem;height:1.6rem;border-radius:50%;border:2px solid #fff;background:rgba(20,13,8,.35);display:none;align-items:center;justify-content:center;color:#fff;font-weight:700}
.gl.picking .gl-t{cursor:pointer}.gl.picking .gl-t .chk{display:flex}.gl-t[aria-pressed="true"] .chk{background:#8FBCA8;border-color:#8FBCA8}.gl-t[aria-pressed="true"]{box-shadow:0 0 0 3px #8FBCA8}
.gl-more[hidden],.gl-t.extra[hidden]{display:none}
.gl-albums{display:grid;grid-template-columns:repeat(auto-fill,minmax(15rem,1fr));gap:1rem}
.gl-al{position:relative;display:block;aspect-ratio:4/3;border-radius:.7rem;overflow:hidden;background:#CBB98D center/cover no-repeat;text-decoration:none;color:#FFFBF2}
.gl-al img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.gl-al .scrim{position:absolute;inset:auto 0 0 0;padding:2.2rem .8rem .7rem;background:linear-gradient(transparent,rgba(10,6,4,.78))}
.gl-al b{display:block;font:700 1.08rem var(--tv-font-head,Georgia,serif);text-shadow:0 1px 2px rgba(0,0,0,.5)}.gl-al small{font-size:.8rem;opacity:.92}
.gl-al .vis{position:absolute;top:.5rem;left:.5rem;background:rgba(255,251,242,.92);color:#5C4632;border-radius:999px;padding:.1rem .55rem;font:600 .72rem system-ui}
.gl-al.new{display:flex;align-items:center;justify-content:center;background:#F7EFDC;border:2px dashed #CBB98D;color:#92400E;font-weight:700}
.gl-hero{position:relative;border-radius:.8rem;overflow:hidden;min-height:13rem;background:#5C4632 center/cover no-repeat;color:#FFFBF2;margin-bottom:1rem;display:flex;align-items:flex-end}
.gl-hero .scrim{width:100%;padding:3.5rem 1rem 1rem;background:linear-gradient(transparent,rgba(10,6,4,.82))}
.gl-hero h1{font:700 1.7rem var(--tv-font-head,Georgia,serif);margin:0;text-shadow:0 1px 3px rgba(0,0,0,.5)}.gl-hero p{margin:.2rem 0 0;font-size:.9rem;opacity:.95}
.gl-tools{display:flex;flex-wrap:wrap;gap:.45rem;margin:-.2rem 0 1rem}
.gl-bar{position:fixed;left:50%;bottom:1rem;transform:translateX(-50%);z-index:60;display:flex;flex-wrap:wrap;align-items:center;gap:.4rem;background:#3E2B1F;color:#FFFBF2;border-radius:1rem;padding:.5rem .6rem;box-shadow:0 12px 30px -10px rgba(0,0,0,.5);max-width:calc(100vw - 1rem)}
.gl-bar[hidden]{display:none}.gl-bar b{padding:0 .4rem}.gl-bar .gl-b{background:#FFFBF2}.gl-bar .gl-b.go{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text)}.gl-bar .gl-b:disabled{opacity:.55}
.gl-sheet{position:fixed;inset:0;z-index:70;background:rgba(20,13,8,.55);display:flex;align-items:center;justify-content:center;padding:1rem}.gl-sheet[hidden]{display:none}
.gl-sheet>div{background:#FFFBF2;border-radius:1rem;max-width:28rem;width:100%;padding:1.1rem;max-height:calc(100vh - 2rem);max-height:calc(100dvh - 2rem);overflow:auto;box-sizing:border-box;box-shadow:0 20px 40px -12px rgba(0,0,0,.5)}
.gl-sheet h2{font:700 1.2rem var(--tv-font-head,Georgia,serif);margin:0 0 .6rem;color:#3E2B1F}.gl-sheet label.opt{display:flex;gap:.6rem;padding:.6rem;border:1.5px solid #E3D3AC;border-radius:.7rem;margin:.4rem 0;cursor:pointer}
.gl-sheet label.opt:has(input:checked){border-color:#8FBCA8;background:#EEF6F1}.gl-sheet label.opt b{display:block;color:#3E2B1F}.gl-sheet label.opt small{color:#5C4632}
.gl-sheet .row{display:flex;gap:.5rem;justify-content:flex-end;margin-top:.8rem}
.gl-sheet input,.gl-sheet select,.gl-sheet textarea{box-sizing:border-box;max-width:100%}.gl-sheet input[type=text],.gl-sheet input[type=date],.gl-sheet textarea{width:100%;border:1.5px solid #CBB98D;border-radius:.6rem;padding:.55rem .7rem;font:inherit;background:#fff}
.gl-prog{margin:0 0 1rem;background:#F7EFDC;border:1px solid #E3D3AC;border-radius:.7rem;padding:.6rem .8rem;font-size:.88rem;color:#5C4632}.gl-prog[hidden]{display:none}
.gl-prog div{height:.45rem;background:#E3D3AC;border-radius:999px;margin-top:.4rem;overflow:hidden}.gl-prog span{display:block;height:100%;width:0;background:#8FBCA8;transition:width .2s}
.gl-t .pkb{position:absolute;right:.4rem;top:.4rem;width:1.7rem;height:1.7rem;border-radius:50%;background:#8FBCA8;color:#1F3A2E;display:none;align-items:center;justify-content:center;box-shadow:0 0 0 3px rgba(143,188,168,.45)}
.gl-t.pk .pkb{display:flex}.gl-t .pkb svg{width:1rem;height:1rem}
.gl.choosing .gl-t{cursor:pointer}
.gl-mode{display:inline-block;background:rgba(255,251,242,.92);color:#5C4632;border-radius:999px;padding:.1rem .6rem;font:600 .75rem system-ui;margin-bottom:.4rem}
.gl-note{background:#F7EFDC;border:1px solid #E3D3AC;border-radius:.7rem;padding:.55rem .8rem;font-size:.86rem;color:#5C4632;margin:0 0 1rem}
.gl-files{display:grid;grid-template-columns:repeat(auto-fill,minmax(19rem,1fr));gap:.6rem;margin:0 0 1.2rem;padding:0;list-style:none}
.gl-f{position:relative;display:flex;gap:.7rem;align-items:flex-start;background:#FFFBF2;border:1px solid #E3D3AC;border-radius:.7rem;padding:.6rem .5rem .6rem .7rem;min-width:0}.gl-f>span:nth-child(2){flex:1;min-width:0}
.gl-f .ty{flex:none;width:3rem;height:3.4rem;border-radius:.4rem;background:#F1E4C6;color:#92400E;display:flex;align-items:flex-end;justify-content:center;font:700 .62rem system-ui;padding-bottom:.35rem;text-transform:uppercase;border:1px solid #E3D3AC}
.gl-f .nm{display:block;color:#92400E;text-decoration:underline;font-weight:700;overflow-wrap:anywhere}
.gl-f small{display:block;color:#8A7355;font-size:.78rem;margin-top:.15rem}
.gl-f .acts{flex:none;margin-left:auto;display:flex;flex-direction:column;gap:.3rem}
.gl-f .acts a,.gl-f .acts button{width:30px;height:30px;border-radius:50%;border:1.5px solid #CBB98D;background:#FFFBF2;color:#B45309;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}
.gl-f .acts svg{width:16px;height:16px}.gl-f .acts .danger{color:#991B1B;border-color:#E9B4B4}
.gl-empty{background:#F7EFDC;border:1px solid #E3D3AC;border-radius:.8rem;padding:1.4rem;text-align:center;color:#5C4632}
@media (max-width:767px){
  .gl-rows{display:grid;grid-template-columns:1fr 1fr;gap:3px}.gl-rows::after{display:none}
  .gl-t{height:auto!important;width:auto!important;aspect-ratio:1;border-radius:.5rem}
  .gl-albums{grid-template-columns:1fr 1fr;gap:3px}.gl-al{border-radius:.5rem}.gl-al b{font-size:.95rem}
  .gl-hero{border-radius:.5rem;min-height:11rem}.gl-hero h1{font-size:1.35rem}
  .gl-h h1{font-size:1.35rem}
  .gl-files{grid-template-columns:1fr;gap:3px}.gl-f{border-radius:.5rem}
}
</style>';
}

/** One photo or video tile. $i: its place in the page's list (the viewer opens there). */
function tv_gallery_tile(array $v, int $i, bool $extra = false): string
{
    $ratio = $v['w'] && $v['h'] ? max(0.5, min(2.5, $v['w'] / $v['h'])) : 1.0;
    $alt = $v['alt'] !== '' ? $v['alt'] : ($v['kind'] === 'video' ? 'Video' : 'Photo');
    $len = $v['kind'] === 'video' ? ($v['secs'] ? sprintf('%d:%02d', intdiv($v['secs'], 60), $v['secs'] % 60) : 'Video') : '';
    return '<button type="button" class="gl-t' . ($extra ? ' extra' : '') . (!empty($v['picked']) ? ' pk' : '') . '" data-gi="' . $i . '" data-id="' . (int) $v['id'] . '" aria-pressed="false"' . ($extra ? ' hidden' : '')
        . ' aria-label="' . tv_e(($v['kind'] === 'video' ? 'Video: ' : 'Photo: ') . $alt) . '"'
        . ' style="width:' . round(13 * $ratio, 2) . 'rem;flex-grow:' . round($ratio, 3) . ($v['blur'] !== '' ? ';background-image:url(\'' . tv_e($v['blur']) . '\')' : '') . '">'
        . '<img loading="lazy" decoding="async" src="' . tv_e($v['card']) . '" alt="' . tv_e($alt) . '" onload="this.classList.add(\'on\')">'
        . ($len !== '' ? '<span class="vid">&#9654; ' . tv_e($len) . '</span>' : '') . '<span class="chk" aria-hidden="true">&#10003;</span>'
        . (array_key_exists('picked', $v) ? '<span class="pkb" title="Picked" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7.5-4.6-9.5-9.3C1.1 8.3 3.2 5 6.6 5c2 0 3.4 1.1 4.4 2.5C12 6.1 13.4 5 15.4 5c3.4 0 5.5 3.3 4.1 6.7C19.5 16.4 12 21 12 21z"/></svg></span>' : '') . '</button>';
}

/** Items grouped by year and month (when taken, else when added), each month showing six and "View all". */
function tv_gallery_timeline(array $views): string
{
    if (!$views) return '';
    $h = ''; $year = ''; $month = ''; $n = 0; $inMonth = []; $flush = function () use (&$h, &$inMonth, &$month) {
        if (!$inMonth) return;
        $c = count($inMonth);
        $h .= '<section class="gl-month"><h3 class="gl-mo">' . tv_e(date('F', strtotime($month . '-01'))) . ' <small>' . $c . ($c === 1 ? ' item' : ' items') . '</small></h3><div class="gl-rows tv-bleed">';
        foreach ($inMonth as $k => [$v, $i]) $h .= tv_gallery_tile($v, $i, $k >= 6);
        $h .= '</div>' . ($c > 6 ? '<button type="button" class="gl-b gl-more" style="margin-top:.5rem" aria-expanded="false" data-more="' . ($c - 6) . '">View all ' . $c . '</button>' : '') . '</section>';
        $inMonth = [];
    };
    foreach ($views as $i => $v) {
        $ym = substr((string) $v['when'], 0, 7) ?: 'Undated';
        if ($ym !== $month) { $flush(); $month = $ym; }
        if (substr($ym, 0, 4) !== $year) { $year = substr($ym, 0, 4); $h .= '<h2 class="gl-yr">' . tv_e($year) . '</h2>'; }
        $inMonth[] = [$v, $i]; $n++;
    }
    $flush();
    return $h;
}

/** An album card: its cover with the title and date over a dark gradient. */
function tv_gallery_album_card(array $a, string $href, bool $own): string
{
    $c = $a['cover'] ?? null;
    $when = $a['event_date'] ? date('M j, Y', strtotime((string) $a['event_date'])) : '';
    $n = (int) ($a['n'] ?? 0);
    return '<a class="gl-al" href="' . tv_e($href) . '"' . ($c && $c['blur'] !== '' ? ' style="background-image:url(\'' . tv_e($c['blur']) . '\')"' : '') . '>'
        . ($c ? '<img loading="lazy" decoding="async" src="' . tv_e($c['card']) . '" alt="">' : '')
        . ($own ? '<span class="vis">' . tv_e(Gallery::VIS[$a['visibility']] ?? '') . '</span>' : '')
        . '<span class="scrim"><b>' . tv_e((string) $a['title']) . '</b><small>' . ($when !== '' ? tv_e($when) . ' · ' : '') . $n . ($n === 1 ? ' item' : ' items') . '</small></span></a>';
}

/** A file in a Brand & documents album: its type, name (the download), size and version; actions down the right edge. */
function tv_gallery_file(array $v, bool $mine): string
{
    $ic = fn (string $d) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
    $dl = (string) ($v['download'] ?? '');
    $size = (int) ($v['fbytes'] ?? 0);
    $sz = $size >= 1073741824 ? round($size / 1073741824, 1) . ' GB' : ($size >= 1048576 ? round($size / 1048576, 1) . ' MB' : max(1, (int) round($size / 1024)) . ' KB');
    $ver = (int) ($v['fver'] ?? 1);
    $name = (string) ($v['fname'] ?? 'File');
    return '<li class="gl-f tv-bleed" data-id="' . (int) $v['id'] . '" data-name="' . tv_e($name) . '"><span class="ty">' . tv_e((string) ($v['fext'] ?? '')) . '</span><span style="min-width:0">'
        . ($dl !== '' ? '<a class="nm" href="' . tv_e($dl) . '" download>' . tv_e($name) . '</a>' : '<b class="nm" style="text-decoration:none">' . tv_e($name) . '</b>')
        . '<small>' . tv_e((string) ($v['ftype'] ?? '')) . ' · ' . $sz . ' · version ' . $ver . '</small>'
        . ($v['caption'] !== '' ? '<small style="color:#5C4632">' . tv_e((string) $v['caption']) . '</small>' : '') . '</span><span class="acts">'
        . ($dl !== '' ? '<a href="' . tv_e($dl) . '" download title="Download" aria-label="Download ' . tv_e($name) . '">' . $ic('<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>') . '</a>' : '')
        . ($ver > 1 || $mine ? '<button type="button" data-f="versions" title="Versions" aria-label="Versions of ' . tv_e($name) . '">' . $ic('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>') . '</button>' : '')
        . ($mine ? '<button type="button" data-f="replace" title="New version" aria-label="Upload a new version of ' . tv_e($name) . '">' . $ic('<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>') . '</button>'
            . '<button type="button" data-f="about" title="Describe it" aria-label="Describe ' . tv_e($name) . '">' . $ic('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>') . '</button>'
            . '<button type="button" class="danger" data-f="delete" title="Delete" aria-label="Delete ' . tv_e($name) . '">' . $ic('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>') . '</button>' : '')
        . '</span></li>';
}

/**
 * The Videos tab (a profile) or section (a listing): the owner's Channel, newest first, then playlists (their other albums
 * with videos), with the Channel's short link and QR code (trvgo.us) to share (decisions/0153 §7). $page: the page this
 * shows on, for the short link. Returns '' when there's nothing to show a visitor.
 */
function tv_videos_section(PDO $pdo, string $kind, string $ref, bool $own, string $page, string $manage = '/gallery/'): string
{
    require_once __DIR__ . '/../lib/Gallery.php';
    [$ch, $vids, $lists] = Gallery::videos($pdo, $kind, $ref, $own);
    if (!$own && !$vids && !$lists) return '';
    $views = array_map(fn ($it) => Gallery::view($it), $vids);
    $h = tv_gallery_css() . '<div class="gl pf-card tv-bleed" style="max-width:none" id="videos"><div class="gl-h" style="margin:0"><h2 class="font-serif font-bold text-lg" style="margin-right:auto">Videos</h2>'
        . ($own ? '<a class="gl-b" href="' . tv_e($manage) . '">Manage your gallery</a>' : '') . '</div>';
    $short = '';
    if ($vids && $ch && $ch['visibility'] === 'public') {
        try { require_once __DIR__ . '/../lib/ShortCodes.php'; $short = ShortCodes::forPage($pdo, $page); } catch (Throwable) {}
    }
    if ($short !== '') $h .= '<p class="text-sm mt-1" style="display:flex;flex-wrap:wrap;gap:.4rem .8rem;align-items:center">Share: <a class="underline" href="' . tv_e($short) . '" data-link="' . tv_e($short) . '">' . tv_e(preg_replace('#^https?://#', '', $short)) . '</a>'
        . ' <a class="gl-b" href="/api/qr.php?page=' . rawurlencode($page) . '&format=png&download=1" title="Download its QR code">QR code</a></p>';
    if ($vids) {
        $h .= '<h3 class="gl-mo">Channel</h3><div class="gl-rows tv-bleed">';
        foreach ($views as $i => $v) $h .= tv_gallery_tile($v, $i);
        $h .= '</div>';
    }
    if ($lists) {
        $h .= '<h3 class="gl-mo">Playlists</h3><div class="gl-albums tv-bleed">';
        foreach ($lists as $a) $h .= tv_gallery_album_card($a, '/gallery/album.php?a=' . (int) $a['id'], $own);
        $h .= '</div>';
    }
    if (!$vids && !$lists) $h .= '<p class="text-sm mt-1 text-[#8A7355]">No videos yet. Keep a post with a video that you shared with everyone, and it goes to your Channel here; albums with videos show as playlists.</p>';
    elseif ($own && $ch && $ch['visibility'] !== 'public') $h .= '<p class="text-xs mt-2 text-[#8A7355]">Your Channel is ' . tv_e(strtolower(Gallery::VIS[$ch['visibility']] ?? 'private')) . ': only you see it. Make it public from its album in your gallery.</p>';
    $owner = Gallery::ownerName($pdo, $kind, $ref);
    return $h . '</div><script>window.TV_GAL = ' . json_encode(['items' => Gallery::mark($pdo, $views, null), 'album' => null, 'own' => false, 'csrf' => '', 'me' => null, 'owner' => $owner !== '' ? ['name' => $owner] : null], JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES) . ';</script>'
        . '<script src="/js/photo-viewer.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/photo-viewer.js') . '"></script><script src="/js/gallery.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/gallery.js') . '"></script>';
}
