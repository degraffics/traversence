<?php
// app/lib/ControlAlarms.php — the System Control Board's annunciator (decisions/0171 §5, §7; release 3a). One alarm list
// for the whole system, by level: a trip (stopped, crashed, can't run what's switched on), a warning (slow, retrying,
// near a limit, a wrong count) or a notice. An alarm is raised the moment its reading goes wrong (the ledger, a crawler
// run's report, a service failing; silence by the 5-minute watch), and the same problem again updates the open alarm,
// never a second. It clears by itself when its reading is good again, saying how. Acknowledging stops the repeat email;
// the alarm stays open until its reading is good. A trip is emailed to the Founder at once through the one dispatcher
// (Notify::send, kind alarm.trip, decisions/0172); a warning still unacknowledged after 24 hours, as alarm.warning.
// Ids, words and readings only: nothing about a person.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class ControlAlarms
{
    public const LEVELS = ['trip' => 'Trip', 'warning' => 'Warning', 'notice' => 'Notice'];
    /** What kind of problem (0171 §5's table). */
    public const KINDS = ['slow' => 'Slow', 'retry' => 'Retrying', 'crash' => 'Crashed', 'held' => 'Held or out', 'limit' => 'Near a limit',
                          'count' => 'Wrong count', 'silent' => 'Gone quiet', 'check' => 'Its check'];
    private const RANK = ['notice' => 0, 'warning' => 1, 'trip' => 2];
    private static bool $ready = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $pdo->exec("CREATE TABLE IF NOT EXISTS control_alarms (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            akey VARCHAR(120) NOT NULL, proc VARCHAR(60) NOT NULL DEFAULT '', level VARCHAR(10) NOT NULL, kind VARCHAR(12) NOT NULL,
            title VARCHAR(200) NOT NULL, means VARCHAR(400) NOT NULL DEFAULT '', todo VARCHAR(400) NOT NULL DEFAULT '', reading VARCHAR(255) NOT NULL DEFAULT '',
            fix VARCHAR(400) NOT NULL DEFAULT '', n_times INT UNSIGNED NOT NULL DEFAULT 1, first_at DATETIME NOT NULL, last_at DATETIME NOT NULL,
            ack_uid INT UNSIGNED NULL, ack_name VARCHAR(80) NULL, ack_at DATETIME NULL, cleared_at DATETIME NULL, cleared_how VARCHAR(255) NULL,
            mailed_at DATETIME NULL, KEY open_key (akey, cleared_at), KEY proc (proc), KEY cleared (cleared_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        self::$ready = true;
    }

    /** The board's process an endpoint serves: its workflow (a task named there counts as its task's workflow) or its worker. */
    public static function procOfEndpoint(PDO $pdo, string $ep): string
    {
        require_once __DIR__ . '/ControlRegister.php';
        $f = (string) (((array) (ControlRegister::ENDPOINTS[$ep][1] ?? []))[0] ?? '');
        if ($f === '') return 'ep:' . $ep;
        if ($f[0] === '@') return 'wk:' . substr($f, 1);
        if (preg_match('/^W\d+$/', $f)) return 'wf:' . $f;
        try { $wf = (string) (ControlRegister::taskWorkflows($pdo)[$f] ?? ''); if ($wf !== '') return 'wf:' . $wf; } catch (Throwable $x) {}
        return 't:' . $f;
    }

    /** The open alarm with this key, or null. */
    public static function openOf(PDO $pdo, string $key): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM control_alarms WHERE akey = ? AND cleared_at IS NULL ORDER BY id DESC LIMIT 1'); $st->execute([$key]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Raises an alarm, or updates the open one with the same key (its count, last seen, words, and a higher level if it
     * got worse). $fix: [label, action, id] a button the board and Pulse press in place ('' none), or a list of them.
     * $event false: a reading still bad, said again (a cap, a red line, a quiet worker): last seen moves, the count doesn't.
     * Returns its id. Never throws: a failing alarm must not break what raised it.
     */
    public static function raise(PDO $pdo, string $key, string $proc, string $level, string $kind, string $title, string $means = '', string $todo = '', string $reading = '', array $fix = [], bool $event = true): int
    {
        try {
            self::ensure($pdo);
            $level = isset(self::LEVELS[$level]) ? $level : 'warning'; $kind = isset(self::KINDS[$kind]) ? $kind : 'check';
            $cut = fn (string $s, int $n) => mb_substr(trim($s), 0, $n);
            $fx = $fix ? json_encode(isset($fix[0]) && is_array($fix[0]) ? array_slice($fix, 0, 4) : array_slice($fix, 0, 4), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';   // one button [label, action, id(, confirm|ask)], or a list of them
            // the column holds 400: whole buttons are dropped from the end, never a cut that breaks the list
            while (mb_strlen($fx) > 400 && isset($fix[0]) && is_array($fix[0]) && count($fix) > 1) { array_pop($fix); $fx = json_encode(array_slice($fix, 0, 4), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); }
            if (mb_strlen($fx) > 400) $fx = '';
            $o = self::openOf($pdo, $key);
            if ($o) {
                $lv = self::RANK[$level] > self::RANK[(string) $o['level']] ? $level : (string) $o['level'];
                $pdo->prepare('UPDATE control_alarms SET n_times = n_times + ' . ($event ? 1 : 0) . ', last_at = UTC_TIMESTAMP(), level = ?, title = ?, means = ?, todo = ?, reading = ?, fix = ? WHERE id = ?')
                    ->execute([$lv, $cut($title, 200), $cut($means, 400), $cut($todo, 400), $cut($reading, 255), mb_substr($fx, 0, 400), (int) $o['id']]);
                if ($lv === 'trip' && $o['level'] !== 'trip') self::mail($pdo, (int) $o['id']);   // it got worse: a trip now
                return (int) $o['id'];
            }
            $pdo->prepare('INSERT INTO control_alarms (akey, proc, level, kind, title, means, todo, reading, fix, first_at, last_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())')
                ->execute([$cut($key, 120), $cut($proc, 60), $level, $kind, $cut($title, 200), $cut($means, 400), $cut($todo, 400), $cut($reading, 255), mb_substr($fx, 0, 400)]);
            $id = (int) $pdo->lastInsertId();
            if ($level === 'trip') self::mail($pdo, $id);
            return $id;
        } catch (Throwable $x) { error_log('control alarm ' . $key . ': ' . $x->getMessage()); return 0; }
    }

    /** Clears the open alarm with this key, saying how. Returns whether one was open. Never throws. */
    public static function clear(PDO $pdo, string $key, string $how): bool
    {
        try {
            self::ensure($pdo);
            $st = $pdo->prepare('UPDATE control_alarms SET cleared_at = UTC_TIMESTAMP(), cleared_how = ? WHERE akey = ? AND cleared_at IS NULL');
            $st->execute([mb_substr($how, 0, 255), $key]);
            return $st->rowCount() > 0;
        } catch (Throwable $x) { error_log('control alarm clear ' . $key . ': ' . $x->getMessage()); return false; }
    }

    /** Clears every open alarm whose key starts with $prefix except those in $keep (the readings still bad). */
    public static function clearOthers(PDO $pdo, string $prefix, array $keep, string $how): int
    {
        $n = 0;
        try {
            self::ensure($pdo);
            $st = $pdo->prepare("SELECT akey FROM control_alarms WHERE cleared_at IS NULL AND akey LIKE ?"); $st->execute([addcslashes($prefix, '%_') . '%']);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $k) if (!in_array($k, $keep, true) && self::clear($pdo, (string) $k, $how)) $n++;
        } catch (Throwable $x) {}
        return $n;
    }

    /** Acknowledged by a person: stops the repeat email; it stays open until its reading is good. */
    public static function ack(PDO $pdo, int $id, int $uid, string $who): bool
    {
        self::ensure($pdo);
        $st = $pdo->prepare('UPDATE control_alarms SET ack_uid = ?, ack_name = ?, ack_at = UTC_TIMESTAMP() WHERE id = ? AND ack_at IS NULL');
        $st->execute([$uid ?: null, mb_substr($who, 0, 80) ?: null, $id]);
        return $st->rowCount() > 0;
    }

    /** Undo an acknowledgement (it emails again only if it's a new problem). */
    public static function unack(PDO $pdo, int $id): bool
    {
        self::ensure($pdo);
        $st = $pdo->prepare('UPDATE control_alarms SET ack_uid = NULL, ack_name = NULL, ack_at = NULL WHERE id = ? AND ack_at IS NOT NULL'); $st->execute([$id]);
        return $st->rowCount() > 0;
    }

    /**
     * The list: open alarms, worst first, then the trips that cleared before anyone saw them (kept 24 hours, 0171 §7).
     * Each row as stored, with 'fix' decoded.
     */
    public static function list(PDO $pdo, int $n = 100): array
    {
        try {
            self::ensure($pdo);
            $rows = $pdo->query("SELECT * FROM control_alarms WHERE cleared_at IS NULL OR cleared_at >= UTC_TIMESTAMP() - INTERVAL 48 HOUR
                                 ORDER BY cleared_at IS NOT NULL, FIELD(level, 'trip', 'warning', 'notice'), last_at DESC LIMIT " . max(1, min(500, $n)))->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as &$r) $r['fix'] = $r['fix'] !== '' ? (json_decode((string) $r['fix'], true) ?: []) : [];
            return $rows;
        } catch (Throwable $x) { return []; }
    }

    /** For the light: open trips and warnings, and the trips that cleared unseen. */
    public static function counts(PDO $pdo): array
    {
        $z = ['trip' => 0, 'warning' => 0, 'notice' => 0, 'unseen' => 0];
        try {
            self::ensure($pdo);
            foreach ($pdo->query('SELECT level, COUNT(*) FROM control_alarms WHERE cleared_at IS NULL GROUP BY level')->fetchAll(PDO::FETCH_KEY_PAIR) as $l => $c) if (isset($z[$l])) $z[$l] = (int) $c;
            $z['unseen'] = (int) $pdo->query("SELECT COUNT(*) FROM control_alarms WHERE level = 'trip' AND ack_at IS NULL AND cleared_at >= UTC_TIMESTAMP() - INTERVAL 24 HOUR")->fetchColumn();
        } catch (Throwable $x) {}
        return $z;
    }

    /** A process's open alarms (for its row on the board). */
    public static function ofProc(PDO $pdo, string $proc): array
    {
        try { self::ensure($pdo); $st = $pdo->prepare('SELECT * FROM control_alarms WHERE proc = ? AND cleared_at IS NULL ORDER BY FIELD(level, \'trip\', \'warning\', \'notice\'), last_at DESC'); $st->execute([$proc]); return $st->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $x) { return []; }
    }

    /**
     * The email (0171 §7, through 0172's one dispatcher): a trip at once; a warning unacknowledged 24 hours. Sent only
     * when the dispatcher knows the kind (Notify::KINDS has alarm.trip / alarm.warning); until then nothing is sent and
     * the alarm still stands on the board. Marks it mailed so it goes once.
     */
    private static function mail(PDO $pdo, int $id): void
    {
        try {
            $st = $pdo->prepare('SELECT * FROM control_alarms WHERE id = ?'); $st->execute([$id]); $a = $st->fetch(PDO::FETCH_ASSOC);
            if (!$a || $a['mailed_at'] !== null) return;
            $kind = $a['level'] === 'trip' ? 'alarm.trip' : 'alarm.warning';
            require_once __DIR__ . '/Notify.php'; require_once __DIR__ . '/CommsSetup.php';
            if (!isset(Notify::KINDS[$kind])) return;
            $to = CommsSetup::founders($pdo);
            if (!$to) return;
            $body = ($a['means'] !== '' ? 'What it means: ' . $a['means'] . "\n" : '') . ($a['todo'] !== '' ? 'What to do: ' . $a['todo'] . "\n" : '') . ($a['reading'] !== '' ? 'Reading: ' . $a['reading'] : '');
            Notify::send($pdo, $kind, ['staff' => $to], ['thing' => 'alarm:' . $id, 'url' => '/admin/config/control#cb-alarm-' . $id, 'from' => ['system', null, 'Control Board']],
                ['title' => (string) $a['title'], 'body' => trim($body)]);
            $pdo->prepare('UPDATE control_alarms SET mailed_at = UTC_TIMESTAMP() WHERE id = ?')->execute([$id]);
        } catch (Throwable $x) { error_log('control alarm mail ' . $id . ': ' . $x->getMessage()); }
    }

    /** The alarm inside its message in Pulse (Notify::BODIES): what happened, means, what to do, its state, Acknowledge. */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        $e = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES, 'UTF-8');
        $id = (int) preg_replace('/\D/', '', (string) ($m['thing'] ?? $m['about'] ?? ''));
        $st = $pdo->prepare('SELECT * FROM control_alarms WHERE id = ?'); $st->execute([$id]); $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) return ['html' => '<p>This alarm is no longer kept.</p>', 'state' => 'Gone'];
        $state = $a['cleared_at'] !== null ? 'Cleared: ' . (string) $a['cleared_how'] : ($a['ack_at'] !== null ? 'Acknowledged by ' . ($a['ack_name'] ?? 'staff') . '; open until its reading is good' : 'Open');
        $h = '<p><b>' . $e($a['title']) . '</b></p>' . ($a['means'] !== '' ? '<p>' . $e($a['means']) . '</p>' : '') . ($a['todo'] !== '' ? '<p><b>What to do:</b> ' . $e($a['todo']) . '</p>' : '')
           . '<p class="tv-msg-acts">' . ($a['cleared_at'] === null && $a['ack_at'] === null ? '<button type="button" class="tv-btn" data-msg-act="/admin/api/config/control" data-msg-body=\'' . $e(json_encode(['action' => 'ack', 'id' => $id])) . '\'>Acknowledge</button> ' : '')
           . '<a class="tv-btn" href="/admin/config/control#cb-alarm-' . $id . '">Open it on the board</a></p>';
        return ['html' => $h, 'state' => $state];
    }

    /**
     * Its Pulse item's steps (0171 §8): the same buttons as its row on the board, acting in place through Pulse::manage
     * (a cap's Raise the cap as a one-field form, Pause it, Check it now, Mark resolved), then the board itself.
     */
    public static function pulseSteps(PDO $pdo, int $id, callable $s): array
    {
        $st = $pdo->prepare('SELECT * FROM control_alarms WHERE id = ?'); $st->execute([$id]); $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) return [$s('Nothing to do', 'This alarm is no longer kept.', null, true)];
        $fx = json_decode((string) $a['fix'], true); $fx = is_array($fx) ? (isset($fx[0]) && is_array($fx[0]) ? $fx : [$fx]) : [];
        if (str_starts_with((string) $a['akey'], 'svc:issue:')) $fx[] = ['Mark resolved', 'svcresolve', substr((string) $a['akey'], 10)];
        $out = [];
        if ($a['cleared_at'] === null) foreach ($fx as $f) {
            $k = (string) ($f[1] ?? ''); $l = (string) ($f[0] ?? '');
            if ($k === 'peek') $out[] = $s($l, 'Opens beside this item.', ['tool', (string) $f[2]]);
            elseif ($k === 'opsask') $out[] = $s($l, 'Now ' . (string) ($f[3][1] ?? '') . '. Kept with who and when.', ['form', 'alarm_' . (string) $f[2], 'Set it', [['value', (string) ($f[3][0] ?? 'Value'), 'text', (string) ($f[3][1] ?? '')]]]);
            elseif ($k === 'ops') $out[] = $s($l, is_string($f[3] ?? null) ? (string) $f[3] : 'Done in place.', ['do', 'alarm_' . (string) $f[2], $l]);
            elseif ($k === 'svcresolve') $out[] = $s($l, 'Calls to it start again; a new failure opens a new issue and its alarm.', ['do', 'alarm_svcresolve:' . (string) $f[2], $l]);
        }
        $out[] = $s('Open it on the board', 'Where it sits in the system, with its evidence.', ['tool', '/admin/config/control#cb-alarm-' . $id]);
        return $out;
    }

    /** A step pressed on its Pulse item: the board's own action, with the board's permissions. */
    public static function pulseDo(PDO $pdo, int $id, string $what, array $in, int $uid, string $who): string
    {
        $st = $pdo->prepare('SELECT akey FROM control_alarms WHERE id = ?'); $st->execute([$id]); $akey = (string) ($st->fetchColumn() ?: '');
        if ($akey === '') throw new RuntimeException('This alarm is no longer kept.');
        if (preg_match('/^alarm_(ops_(cap|pause|runnext|task_off):[a-z0-9_]+)$/', $what, $m) && preg_match('/^ops:(cap|empty):/', $akey)) {
            require_once __DIR__ . '/Operations.php'; return Operations::pulseDo($pdo, $akey, $m[1], $in, $uid, $who);
        }
        if (preg_match('/^alarm_svcresolve:(osm|\d+)$/', $what, $m)) {
            require_once __DIR__ . '/ServiceHealth.php'; require_once __DIR__ . '/Preflight.php';
            [$ok, $why] = Preflight::can(); if (!$ok) throw new RuntimeException($why . '.');
            $ids = $m[1] === 'osm' ? array_map(fn ($i) => (int) $i['id'], array_filter(ServiceHealth::openAll($pdo), fn ($i) => $i['service'] === 'osm')) : [(int) $m[1]];
            $n = 0; foreach ($ids as $iid) if (ServiceHealth::resolve($pdo, $iid, $uid, 'Marked resolved by ' . $who . ' in Pulse.')) $n++;
            return $n ? 'Resolved: calls start again; a new failure opens a new issue and its alarm.' : 'Nothing to resolve: it was already resolved.';
        }
        throw new RuntimeException('Unknown step.');
    }

    /**
     * The watch (0171 §5, every 5 minutes: control_tick): what doesn't call in. W0 Indexer silent while it's switched on, a
     * crawler run past its time plus 5 minutes, a site job whose last run stopped, a job run that never finished; and the
     * warnings due their 24-hour email. Each raised, or cleared when its reading is good. Returns what it did, in words.
     */
    public static function tick(PDO $pdo): string
    {
        self::ensure($pdo);
        $did = [];
        if ($sd = self::seed($pdo)) $did[] = $sd . ' known problem(s) raised';
        require_once __DIR__ . '/Automation.php';
        $masterOn = Automation::master($pdo) === null;
        // W0 Indexer: its check-in (every minute or so while it runs)
        try {
            require_once __DIR__ . '/crawler/Frontier.php';
            $beat = (int) (Frontier::lastBeat($pdo)['at'] ?? 0); $on = $masterOn && Automation::wfOff($pdo, 'W0') === null;
            if ($on && $beat && time() - $beat > 15 * 60) { self::raise($pdo, 'silent:w0', 'wk:w0-indexer', 'trip', 'silent', 'W0 Indexer has gone quiet', 'It hasn\'t checked in for ' . (int) floor((time() - $beat) / 60) . ' minutes while it\'s switched on: no addresses are being logged.', 'Open its Railway service: if it crashed or its plan ran out, redeploy it; then press Check.', 'last check-in ' . gmdate('M j H:i', $beat) . ' UTC', ['Check', 'check', 'wk:w0-indexer'], false); $did[] = 'W0 quiet'; }
            elseif ($beat && time() - $beat <= 15 * 60 && self::clear($pdo, 'silent:w0', 'It checked in at ' . gmdate('H:i', $beat) . ' UTC.')) $did[] = 'W0 back';
            elseif (!$on) self::clear($pdo, 'silent:w0', 'It was switched off.');
        } catch (Throwable $x) {}
        // a crawler run that never reported: its time (RUN_LIMIT, 30 minutes) plus 5
        try {
            $late = $pdo->query("SELECT id, started_at FROM crawl_runs WHERE status = 'running' AND started_at < NOW() - INTERVAL 35 MINUTE ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
            if ($late) { self::raise($pdo, 'silent:run', 'wk:crawler', 'trip', 'silent', 'A crawler run never reported (#' . (int) $late['id'] . ')', 'It started over 35 minutes ago and hasn\'t said how it ended: it was stopped, or it crashed on Railway.', 'Open the crawler on Railway and read the run\'s last log lines; the site marks it abandoned.', 'started ' . (string) $late['started_at'], ['Check', 'check', 'wk:crawler'], false); $did[] = 'run quiet'; }
            elseif (self::clear($pdo, 'silent:run', 'No run is overdue (' . gmdate('H:i') . ' UTC).')) $did[] = 'run cleared';
        } catch (Throwable $x) {}
        // site jobs: the last run of each, stopped or never finished
        try {
            $t = Database::t('job_runs'); $bad = []; $stuck = [];
            foreach ($pdo->query("SELECT r.job, r.ok, r.note, r.started_at, r.finished_at FROM $t r JOIN (SELECT job, MAX(id) id FROM $t WHERE started_at > NOW() - INTERVAL 2 DAY GROUP BY job) m ON m.id = r.id")->fetchAll(PDO::FETCH_ASSOC) as $j) {
                $job = (string) $j['job'];
                if ($j['ok'] !== null && (int) $j['ok'] === 0) { $bad[] = 'job:' . $job; self::raise($pdo, 'job:' . $job, 'job:' . $job, 'trip', 'crash', 'The job "' . $job . '" stopped', 'Its last run ended with a problem; what it does waits until it runs well again.', 'Read its note in System Configuration → Scheduled tasks and fix the cause; it clears by itself when it next runs well.', mb_substr((string) $j['note'], 0, 255), [], false); }
                elseif ($j['finished_at'] === null && strtotime((string) $j['started_at']) < time() - 7200) { $stuck[] = 'job:' . $job . ':stuck'; self::raise($pdo, 'job:' . $job . ':stuck', 'job:' . $job, 'warning', 'slow', 'The job "' . $job . '" never finished', 'Its run started over 2 hours ago and never said it ended: it was killed, or it hangs.', 'Look at the server\'s error log for it; the next run starts as usual.', 'started ' . (string) $j['started_at'], [], false); }
            }
            $n = self::clearOthers($pdo, 'job:', array_merge($bad, $stuck), 'Its last run ended well (' . gmdate('H:i') . ' UTC).');
            if ($bad) $did[] = count($bad) . ' job(s) stopped'; if ($n) $did[] = $n . ' job alarm(s) cleared';
        } catch (Throwable $x) {}
        // Overpass: every server held is one trip a person resolves (3b); raised once from the issues already open
        try {
            require_once __DIR__ . '/ServiceHealth.php';
            $osm = array_values(array_filter(ServiceHealth::openAll($pdo), fn ($i) => $i['service'] === 'osm' && (ServiceHealth::KINDS[$i['kind']][1] ?? 'back') === 'stop'));
            if ($osm && !self::openOf($pdo, 'svc:osm:held')) { $l = (array) ((json_decode((string) $osm[0]['evidence'], true) ?: [])['latest'] ?? []);
                ServiceHealth::alarm($pdo, (int) $osm[0]['id'], 'osm', (string) $osm[0]['host'], (string) $osm[0]['kind'], ['status' => (int) ($l['status'] ?? 0), 'error' => (string) ($l['error'] ?? ''), 'body' => (string) ($l['body'] ?? '')], (string) $osm[0]['caller']); $did[] = 'Overpass held'; }
            $pdo->exec("UPDATE control_alarms SET cleared_at = UTC_TIMESTAMP(), cleared_how = 'Now part of \"Every Overpass server is held\".' WHERE cleared_at IS NULL AND proc = 'svc:osm' AND akey LIKE 'svc:issue:%'");
        } catch (Throwable $x) {}
        $m = self::mailStale($pdo); if ($m) $did[] = $m . ' warning(s) emailed';
        return $did ? implode('; ', $did) . '.' : 'Nothing new.';
    }

    /**
     * What's already known, raised once (0171, release 3a: the queue isn't empty on day one): the pre-flight's red lines,
     * the service issues open now, the worker calls that answered a server error in the last day, and sources outside
     * our region being read. After this, each is raised the moment it happens.
     */
    public static function seed(PDO $pdo): int
    {
        self::ensure($pdo);
        require_once __DIR__ . '/SearchIndex.php';
        if (SearchIndex::state($pdo, 'control:alarms_seeded') !== '') return 0;
        $n = 0;
        try { require_once __DIR__ . '/Preflight.php'; $lines = Preflight::lines($pdo);
            foreach (Preflight::results($pdo) as $id => $r) if (isset($lines[$id]) && in_array($r['s'] ?? '', ['bad', 'warn'], true)) { Preflight::alarm($pdo, (string) $id, $lines[$id], $r); $n++; } } catch (Throwable $x) {}
        try { require_once __DIR__ . '/ServiceHealth.php';
            foreach (ServiceHealth::openAll($pdo) as $i) { $ev = json_decode((string) $i['evidence'], true) ?: []; $l = (array) ($ev['latest'] ?? []);
                ServiceHealth::alarm($pdo, (int) $i['id'], (string) $i['service'], (string) $i['host'], (string) $i['kind'], ['status' => (int) ($l['status'] ?? 0), 'error' => (string) ($l['error'] ?? ''), 'body' => (string) ($l['body'] ?? '')], (string) $i['caller']); $n++; } } catch (Throwable $x) {}
        try { require_once __DIR__ . '/ControlRegister.php';
            foreach ($pdo->query("SELECT l.endpoint, l.code, l.reasons, l.at, c.n FROM control_ledger l JOIN (SELECT endpoint, MAX(id) id, COUNT(*) n FROM control_ledger WHERE code >= 500 AND at >= UTC_TIMESTAMP() - INTERVAL 1 DAY GROUP BY endpoint) c ON c.id = l.id WHERE l.id = (SELECT MAX(id) FROM control_ledger z WHERE z.endpoint = l.endpoint)")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $proc = self::procOfEndpoint($pdo, (string) $r['endpoint']);
                self::raise($pdo, 'ep:' . $r['endpoint'] . ':5xx', $proc, 'trip', 'crash', '/api/' . $r['endpoint'] . ' answers a server error (' . (int) $r['n'] . ' in the last day)',
                    'The worker\'s calls fail on our side; what they need is not done until it\'s fixed.', 'Read the error below; fix its cause on the site. It clears by itself at the next good answer.', mb_substr((string) preg_replace('/^answered \d+: /', '', (string) $r['reasons']), 0, 255), ['Check', 'check', $proc]); $n++;
            } } catch (Throwable $x) {}
        try {   // sources being read outside our region: a country domain other than .us (the source finder may follow links off-region)
            $hosts = array_values(array_filter($pdo->query("SELECT host FROM " . Database::t('reference_sources') . " WHERE status = 'read'")->fetchAll(PDO::FETCH_COLUMN), fn ($h) => preg_match('/\.(?!us$)[a-z]{2}$/', (string) $h) === 1));
            if ($hosts) { self::raise($pdo, 'w3:offregion', 'wf:W3', 'warning', 'check', count($hosts) . ' source' . (count($hosts) === 1 ? '' : 's') . ' outside our region being read (' . implode(', ', array_slice($hosts, 0, 3)) . (count($hosts) > 3 ? ' and more' : '') . ')',
                'W3 reads them every few days; their facts are likely about other places, and reading them uses the crawler\'s time.', 'Decide whether they belong: pause each on Insights → Sources, or say which kinds of outside sources are welcome.', implode(', ', array_slice($hosts, 0, 12))); $n++; }
        } catch (Throwable $x) {}
        SearchIndex::setState($pdo, 'control:alarms_seeded', gmdate('c'));
        return $n;
    }

    /** Warnings open and unacknowledged 24 hours: emailed once (the watch calls this). */
    public static function mailStale(PDO $pdo): int
    {
        $n = 0;
        try {
            self::ensure($pdo);
            foreach ($pdo->query("SELECT id FROM control_alarms WHERE level = 'warning' AND cleared_at IS NULL AND ack_at IS NULL AND mailed_at IS NULL AND first_at <= UTC_TIMESTAMP() - INTERVAL 24 HOUR")->fetchAll(PDO::FETCH_COLUMN) as $id) { self::mail($pdo, (int) $id); $n++; }
        } catch (Throwable $x) {}
        return $n;
    }
}
