<?php
/**
 * app/lib/PlacePhotos.php — a real photo for a public place's card and hero (Jason, 2026-11-19: "cant our system find
 * photos specific to these cards?"; approved "Both"; decisions/0143's note). The landmarks' finder (Landmarks::bestPhoto:
 * Wikimedia Commons, a free licence, every word of the name in the photo's file name or title, taken within 1.5 km or
 * named for the place within 5 miles, at least 640 px, its credit kept) run for the parks, monuments, visitor centres and
 * historic sites we list, and the National Park Service's places from Recreation.gov. One at a time, gently, by the
 * landmark photos job (W9: paused when W9 or Wikimedia is), each looked at again after 30 days. A place kept private
 * (ListingSafety) is never looked up. Cards and heroes show a found photo before any stock photo (3b-1's order).
 *   find($pdo, $n)                looks for up to $n places' photos: [looked at, found]
 *   for($pdo, $kind, $refs)       [ref => ['image', 'credit', 'page']] for 'listing' (entity ids) or 'rec' (RIDB ids)
 *   slides($pdo, $kind, $ref)     the hero's slide for one place, or [] (and the place is wanted: looked up first)
 *   want($pdo, $kind, $ref)       a place someone opened with no photo yet: the next run looks it up first (2026-11-19)
 */
declare(strict_types=1);

final class PlacePhotos
{
    /** The kinds of listing looked up: public places people visit. */
    public const CATEGORIES = "(c.name LIKE 'National Park%' OR c.name LIKE 'National Landmark%' OR c.name = 'Monuments' OR c.name = 'State Parks'
        OR c.name LIKE 'State Recreation%' OR c.name LIKE '%Visitor Cent%' OR c.name LIKE 'Historic%' OR c.name LIKE '%Historic Site%')";

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM place_photos LIMIT 0'); return true; } catch (Throwable) { return false; }
    }

    /** [looked at, found]. */
    public static function find(PDO $pdo, int $n = 15): array
    {
        if (!self::ready($pdo)) return [0, 0];
        require_once __DIR__ . '/Automation.php';
        if (Automation::gathering($pdo, 'wikimedia', 'W9') !== null) return [0, 0];   // paused (System Configuration → Automation)
        require_once __DIR__ . '/Clocks.php'; require_once __DIR__ . '/Landmarks.php'; require_once __DIR__ . '/stock/StockWikimedia.php'; require_once __DIR__ . '/ListingSafety.php';
        $cut = $pdo->quote(Clocks::sqlCutoff($pdo, 'W9', 30));
        $n = max(1, min(50, $n));
        require_once __DIR__ . '/PageCache.php';
        $wanted = array_values(array_filter(array_map('intval', (array) (PageCache::get($pdo, self::WANT) ?: [])), fn ($x) => $x > 0));   // opened by someone: first
        $first = $wanted ? 'e.id IN (' . implode(',', array_slice($wanted, 0, 50)) . ') DESC, ' : '';   // integers only
        $todo = [];
        try {   // our listings first (their own photo, when the owner adds one, comes before this one)
            $st = $pdo->query("SELECT 'listing' AS k, CAST(e.id AS CHAR) AS ref, e.name, e.latitude AS lat, e.longitude AS lon, e.category_id,
                                      (SELECT meta_value FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'state' LIMIT 1) AS state,
                                      (SELECT meta_value FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'city' LIMIT 1) AS city
                                 FROM entities e JOIN categories c ON c.id = e.category_id LEFT JOIN place_photos p ON p.owner_kind = 'listing' AND BINARY p.owner_ref = BINARY CAST(e.id AS CHAR)
                                WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.latitude IS NOT NULL AND e.longitude IS NOT NULL AND " . self::CATEGORIES . "
                                  AND (p.owner_ref IS NULL OR (p.image_url = '' AND (p.tried_at IS NULL OR p.tried_at < $cut)))
                                  AND NOT EXISTS (SELECT 1 FROM hero_media h WHERE h.owner_kind = 'listing' AND h.owner_ref = e.id AND h.kind = 'photo')
                                ORDER BY $first(c.name LIKE 'National%') DESC, e.id LIMIT $n");
            $todo = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { error_log('place photos (listings): ' . $e->getMessage()); }
        if (count($todo) < $n) {
            try {
                $st = $pdo->query("SELECT 'rec' AS k, r.ridb_id AS ref, r.name, r.lat, r.lon, NULL AS category_id, r.state, r.city
                                     FROM rec_places r LEFT JOIN place_photos p ON p.owner_kind = 'rec' AND BINARY p.owner_ref = BINARY r.ridb_id
                                    WHERE r.hidden = 0 AND r.kind = 'recarea' AND r.org LIKE '%National Park Service%' AND r.lat IS NOT NULL AND r.lon IS NOT NULL
                                      AND (p.owner_ref IS NULL OR (p.image_url = '' AND (p.tried_at IS NULL OR p.tried_at < $cut)))
                                    ORDER BY r.ridb_id LIMIT " . ($n - count($todo)));
                $todo = array_merge($todo, $st->fetchAll(PDO::FETCH_ASSOC));
            } catch (Throwable $e) { error_log('place photos (parks): ' . $e->getMessage()); }
        }
        $val = fn ($x) => is_string($d = json_decode((string) $x, true)) ? $d : (string) $x;
        $put = $pdo->prepare("INSERT INTO place_photos (owner_kind, owner_ref, image_url, image_page, image_credit, image_license, source, tried_at, found_at)
                              VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?) ON DUPLICATE KEY UPDATE image_url = VALUES(image_url), image_page = VALUES(image_page),
                              image_credit = VALUES(image_credit), image_license = VALUES(image_license), source = VALUES(source), tried_at = NOW(), found_at = VALUES(found_at)");
        $wm = new StockWikimedia(); $looked = 0; $found = 0;
        foreach ($todo as $r) {
            if ($r['k'] === 'listing' && ListingSafety::isConfidential($r['category_id'] !== null ? (int) $r['category_id'] : null, (string) $r['name'])) {   // kept private: never looked up
                $put->execute(['listing', (string) $r['ref'], '', '', '', '', 'private', null]); continue;
            }
            $name = (string) $r['name'];
            if ($r['k'] === 'rec' && is_file(__DIR__ . '/crawler/RecBulk.php')) { require_once __DIR__ . '/crawler/RecBulk.php'; $name = RecBulk::displayName($name); }
            if (is_file(__DIR__ . '/NameText.php')) { require_once __DIR__ . '/NameText.php'; $name = NameText::listing($name); }   // "Visitor Ctr" → "Visitor Center", as the page shows it
            $row = ['name' => $name, 'lat' => $r['lat'], 'lon' => $r['lon'], 'state' => strtoupper($val($r['state'])), 'county' => '', 'near_town' => ucwords(mb_strtolower($val($r['city'])))];
            try { $p = Landmarks::bestPhoto($wm, $row); } catch (Throwable $e) { error_log('place photos: ' . $e->getMessage()); break; }   // Commons slow or down: next hour
            $looked++;
            $ok = $p && preg_match('#^https://upload\.wikimedia\.org/#', (string) $p['full']);
            $put->execute([$r['k'], (string) $r['ref'], $ok ? mb_substr((string) $p['full'], 0, 500) : '',
                $ok && preg_match('#^https://commons\.wikimedia\.org/#', (string) $p['source_url']) ? mb_substr((string) $p['source_url'], 0, 500) : '',
                $ok ? self::clean((string) $p['author'], 200) : '', $ok ? self::clean((string) $p['licence'], 60) : '', $ok ? 'commons' : '', $ok ? date('Y-m-d H:i:s') : null]);
            if ($ok) $found++;
            sleep(2);   // one place at a time, gently: Commons slows down callers that hurry
        }
        if ($wanted) { $done = array_map(fn ($r) => (int) $r['ref'], array_filter($todo, fn ($r) => $r['k'] === 'listing'));   // what this run reached leaves the list
            PageCache::put($pdo, self::WANT, 7 * 86400, array_values(array_diff($wanted, $done))); }
        return [$looked, $found];
    }

    /** The listings someone opened with no photo yet (PageCache): looked up first, at the finder's own pace. */
    private const WANT = 'pp:want';

    public static function want(PDO $pdo, string $kind, string $ref): void
    {
        if ($kind !== 'listing' || (int) $ref <= 0) return;   // the finder's kinds and rules decide the rest (a private place is never looked up)
        try {
            require_once __DIR__ . '/PageCache.php';
            $l = array_map('intval', (array) (PageCache::get($pdo, self::WANT) ?: []));
            if (in_array((int) $ref, $l, true)) return;
            array_unshift($l, (int) $ref);
            PageCache::put($pdo, self::WANT, 7 * 86400, array_slice($l, 0, 50));
        } catch (Throwable $e) { error_log('place photos want: ' . $e->getMessage()); }
    }

    private static function clean(string $s, int $max): string
    {
        $s = html_entity_decode(strip_tags($s), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return mb_substr(trim((string) preg_replace('/\s+/u', ' ', $s)), 0, $max);
    }

    /** @return array<string, array{image: string, credit: string, page: string}> */
    public static function for(PDO $pdo, string $kind, array $refs): array
    {
        $refs = array_values(array_unique(array_filter(array_map('strval', $refs), fn ($x) => $x !== '')));
        if (!$refs || !in_array($kind, ['listing', 'rec'], true) || !self::ready($pdo)) return [];
        try {
            $st = $pdo->prepare("SELECT owner_ref, image_url, image_credit, image_page FROM place_photos WHERE owner_kind = ? AND image_url <> '' AND owner_ref IN (" . implode(',', array_fill(0, count($refs), '?')) . ')');
            $st->execute(array_merge([$kind], $refs));
            $out = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['owner_ref']] = ['image' => (string) $r['image_url'], 'credit' => (string) $r['image_credit'], 'page' => (string) $r['image_page']];
            return $out;
        } catch (Throwable $e) { error_log('place photos for: ' . $e->getMessage()); return []; }
    }

    /** The hero's slide for one place: its found photo, credited, or []. */
    public static function slides(PDO $pdo, string $kind, string $ref, string $name = ''): array
    {
        $p = self::for($pdo, $kind, [$ref])[$ref] ?? null;
        if (!$p) { self::want($pdo, $kind, $ref); return []; }   // opened without one: the next run looks for it first
        return [['image' => $p['image'], 'caption' => trim($name . ($p['credit'] !== '' ? ' · Photo: ' . mb_strimwidth($p['credit'], 0, 50, '…') . ', Wikimedia Commons' : ' · Wikimedia Commons'), ' ·')]];
    }
}
