-- Outside services' issues (app/lib/ServiceHealth.php; Jason, 2026-11-14: identify an API's issue, stop calling it until
-- it's resolved, ask for help while the rest carries on), and the month's OpenStreetMap asks by town and kind (the OSM
-- statement's third promise). Times are UTC. Safe to run twice (CREATE TABLE IF NOT EXISTS, INSERT … WHERE NOT EXISTS).
CREATE TABLE IF NOT EXISTS service_issues (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  service VARCHAR(40) NOT NULL,
  host VARCHAR(190) NOT NULL,
  caller VARCHAR(10) NOT NULL DEFAULT 'crawler',
  kind VARCHAR(12) NOT NULL,
  state VARCHAR(10) NOT NULL DEFAULT 'open',
  hits INT UNSIGNED NOT NULL DEFAULT 1,
  first_at DATETIME NOT NULL,
  last_at DATETIME NOT NULL,
  evidence TEXT NULL,
  hold_until DATETIME NULL,
  probe_url VARCHAR(255) NULL,
  probe_every_min INT UNSIGNED NULL,
  probe_agent VARCHAR(12) NULL,
  next_probe_at DATETIME NULL,
  last_probe TEXT NULL,
  resolved_at DATETIME NULL,
  resolved_by INT UNSIGNED NULL,
  resolved_how VARCHAR(255) NULL,
  KEY idx_si_open (state, caller, host),
  KEY idx_si_service (service, state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS crawl_osm_asks (
  qkey CHAR(16) NOT NULL PRIMARY KEY,
  asked_at DATETIME NOT NULL,
  found INT UNSIGNED NOT NULL DEFAULT 0,
  KEY idx_coa_at (asked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- What's known already: overpass-api.de has answered 406 to every crawler request from Railway since 2026-11-13 16:51 UTC
-- (research/osm-overpass-2026-11-13.md). Held until resolved; its status page is probed once at the first run, then daily.
INSERT INTO service_issues (service, host, caller, kind, state, hits, first_at, last_at, evidence, probe_url, probe_every_min, probe_agent, next_probe_at)
SELECT 'osm', 'overpass-api.de', 'crawler', 'ban', 'open', 1, '2026-11-13 16:51:00', '2026-11-13 22:10:00',
  '{"first":{"status":406,"body":"406 Not Acceptable nginx","error":"","what":"/api/interpreter","task":"coverage","at":"2026-11-13 16:51:00","retry_after":""},"latest":{"status":406,"body":"406 Not Acceptable nginx (the GET retry the same)","error":"","what":"/api/interpreter","task":"coverage","at":"2026-11-13 22:10:00","retry_after":""}}',
  'https://overpass-api.de/api/status', 1440, 'as_refused', UTC_TIMESTAMP()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM service_issues WHERE host = 'overpass-api.de' AND caller = 'crawler');
