<?php
declare(strict_types=1);

require_once __DIR__ . '/AutoImport.php';
require_once __DIR__ . '/SiteFetcher.php';
require_once __DIR__ . '/ListingExtractor.php';

/**
 * The deeper look (decisions/0076 §1): what Verify tries before a listing that can't be confirmed goes to a person.
 *
 *   1. OpenStreetMap as a second reference. An OSM entry with nearly the same name or the same phone at the same street
 *      number confirms the business is there (an independent source); the same name and phone at another street number
 *      says the address we have is probably old (it moved). OSM data is ODbL (decisions/0065): we keep only the yes or
 *      no and a link to the OSM entry, never its phone, hours or address. Its website tag is used only as a pointer.
 *   2. The business's own website (from the listing, or OSM's pointer): read like "Crawl a site" (a few pages). A
 *      location there at the same street number confirms it from its own site, with that location's phone and hours.
 *      A site that lists its locations but not this street number says this address is probably old.
 *
 * OSM asks share OpenPlaces' hourly budget (open_place_asks). Runs from Verify::lease, in the background, a few a call.
 */
final class DeepLook
{
    private const PER_HOUR = 40;   // all OSM asks together (OpenPlaces' fair use)
    /** Sites that list businesses but aren't one's own website. */
    private const NOT_OWN = '/(^|\.)(facebook|instagram|twitter|x|linkedin|yelp|google|goo|mapquest|yellowpages|yp|healthgrades|npiregistry\.cms\.hhs|npino|npidb|hipaaspace|zocdoc|webmd|vitals|bbb|manta|chamberofcommerce|superpages|citysearch|foursquare|tripadvisor|openstreetmap|wikipedia)\./i';
    private const GENERIC = ['the', 'and', 'inc', 'llc', 'pllc', 'plc', 'ltd', 'pc', 'co', 'corp', 'company', 'services', 'service', 'center', 'centre',
        'health', 'healthcare', 'care', 'medical', 'clinic', 'group', 'associates', 'family', 'white', 'mountain', 'mountains', 'show', 'low', 'gallup',
        'arizona', 'new', 'mexico', 'navajo', 'apache', 'county', 'of', 'for'];

    /**
     * Runs both steps for one waiting listing and returns what they found: Verify::complete items, and whether the
     * address looks old. Also returns what to save on the listing first (hours from its own site, the moved flag).
     * @return array{found:list<array>, moved:?array, hours:list<string>, website:string, checked:list<string>}
     */
    public static function look(PDO $pdo, array $c): array
    {
        $out = ['found' => [], 'moved' => null, 'hours' => [], 'website' => '', 'checked' => []];
        $o = self::osm($pdo, $c);
        if ($o !== null) {
            $out['checked'][] = 'openstreetmap';
            if ($o['confirm']) $out['found'][] = $o['confirm'];
            if ($o['moved']) $out['moved'] = $o['moved'];
            $out['website'] = $o['website'];
        }
        $site = (string) ($c['actions']['website'] ?? '') ?: $out['website'];
        if ($site !== '' && self::ownHost($site)) {
            $s = self::ownSite($c, $site);
            if ($s !== null) {
                $out['checked'][] = 'own website';
                if ($s['confirm']) { $out['found'][] = $s['confirm']; $out['hours'] = $s['hours']; $out['moved'] = null; }
                elseif ($s['moved'] && !$out['moved']) $out['moved'] = $s['moved'];
            }
        }
        return $out;
    }

    /** Whether a website looks like the business's own (not a directory or social page). */
    public static function ownHost(string $url): bool
    {
        $h = strtolower((string) parse_url(preg_match('#^https?://#i', $url) ? $url : 'https://' . $url, PHP_URL_HOST));
        return $h !== '' && !preg_match(self::NOT_OWN, preg_replace('/^www\./', '', $h) . '.');
    }

    /** The street number an address starts with ("249 W Ponderosa" → "249"), or ''. */
    public static function num(string $a): string
    {
        return preg_match('/^\s*#?\s*(\d+)/', $a, $m) ? ltrim($m[1], '0') : '';
    }

    // ---- 1. OpenStreetMap ---------------------------------------------------------------------------------------

    /** @return array{confirm:?array, moved:?array, website:string}|null  null: not asked (no point, no budget, no answer) */
    public static function osm(PDO $pdo, array $c): ?array
    {
        $lat = $c['geo']['latitude'] ?? null; $lon = $c['geo']['longitude'] ?? null;
        if ($lat === null || $lon === null) return null;
        $els = self::overpass($pdo, $c, (float) $lat, (float) $lon);
        if ($els === null) return null;
        $phone = substr(preg_replace('/\D/', '', (string) ($c['actions']['phone'] ?? '')), -10);
        $myNum = self::num((string) ($c['where']['address'] ?? ''));
        $res = ['confirm' => null, 'moved' => null, 'website' => ''];
        foreach ($els as $e) {
            $t = (array) ($e['tags'] ?? []);
            $name = (string) ($t['name'] ?? '');
            if ($name === '') continue;
            $sim = AutoImport::sameName((string) ($c['name'] ?? ''), $name);
            $ph = substr(preg_replace('/\D/', '', (string) ($t['phone'] ?? $t['contact:phone'] ?? '')), -10);
            $samePhone = $phone !== '' && $ph === $phone;
            $num = ltrim((string) ($t['addr:housenumber'] ?? ''), '0');
            $url = 'https://www.openstreetmap.org/' . ($e['type'] ?? 'node') . '/' . ($e['id'] ?? '');
            $web = (string) ($t['website'] ?? $t['contact:website'] ?? '');
            if ($myNum !== '' && $num !== '' && $num === $myNum && ($sim >= 0.5 || $samePhone)) {
                // the same business at the same street number: a second, independent reference (only that it's there)
                $res['confirm'] = ['url' => $url, 'kind' => 'open_data', 'evidence' => $samePhone ? 'both' : 'address', 'label' => 'OpenStreetMap: ' . mb_substr($name, 0, 80)];
                if ($web !== '') $res['website'] = $web;
                $res['moved'] = null;
                break;
            }
            if ($sim >= 0.75 && $samePhone && $num !== '' && $myNum !== '' && $num !== $myNum && !$res['moved']) {
                $res['moved'] = ['via' => 'OpenStreetMap', 'url' => $url, 'note' => 'OpenStreetMap has it at another street number'];
                if ($web !== '') $res['website'] = $web;
            }
        }
        return $res;
    }

    /**
     * Find it, the crawler's way (decisions/0131 §4, no AI): OpenStreetMap's places near a point whose name matches. Only
     * that it's there, its map link and its website as a pointer are used (ODbL, decisions/0065). [[name, osm url,
     * website, lat, lon, score]] best first; null when not asked (no budget, no answer).
     */
    public static function findByName(PDO $pdo, string $name, float $lat, float $lon): ?array
    {
        $els = self::overpass($pdo, ['name' => $name], $lat, $lon);
        if ($els === null) return null;
        $out = [];
        foreach ($els as $e) {
            $t = (array) ($e['tags'] ?? []); $n = (string) ($t['name'] ?? ''); if ($n === '') continue;
            $sim = AutoImport::sameName($name, $n); if ($sim < 0.8) continue;
            $la = (float) ($e['lat'] ?? $e['center']['lat'] ?? 0); $lo = (float) ($e['lon'] ?? $e['center']['lon'] ?? 0);
            $out[] = [$n, 'https://www.openstreetmap.org/' . ($e['type'] ?? 'node') . '/' . ($e['id'] ?? ''), (string) ($t['website'] ?? $t['contact:website'] ?? ''), $la, $lo, $sim];
        }
        usort($out, fn ($a, $b) => $b[5] <=> $a[5]);
        return $out;
    }

    /** Overpass elements named like it or with its phone, within 25 mi; null when not asked. */
    private static function overpass(PDO $pdo, array $c, float $lat, float $lon): ?array
    {
        if (($fx = getenv('OSM_VERIFY_FIXTURE')) && is_file($fx)) {
            $all = json_decode((string) file_get_contents($fx), true);
            return (array) ($all[(string) ($c['name'] ?? '')] ?? []);
        }
        if (!function_exists('curl_init')) return null;
        try {
            $n = (int) $pdo->query("SELECT COUNT(*) FROM open_place_asks WHERE asked_at >= '" . date('Y-m-d H:i:s', time() - 3600) . "'")->fetchColumn();
            if ($n >= self::PER_HOUR) return null;
        } catch (Throwable) { return null; }   // no budget table: don't ask
        $word = '';
        foreach (preg_split('/[^a-z0-9]+/', mb_strtolower((string) ($c['name'] ?? ''))) as $w) if (strlen($w) >= 4 && !in_array($w, self::GENERIC, true) && strlen($w) > strlen($word)) $word = $w;
        $phone = substr(preg_replace('/\D/', '', (string) ($c['actions']['phone'] ?? '')), -10);
        $parts = '';
        $around = '(around:40000,' . round($lat, 4) . ',' . round($lon, 4) . ')';
        if ($word !== '') $parts .= 'nwr["name"~"' . preg_quote($word, '"') . '",i]' . $around . ';';
        if (strlen($phone) === 10) {
            $rx = substr($phone, 3, 3) . '[^0-9]?' . substr($phone, 6, 4);
            $parts .= 'nwr["phone"~"' . $rx . '"]' . $around . ';nwr["contact:phone"~"' . $rx . '"]' . $around . ';';
        }
        if ($parts === '') return null;
        $q = '[out:json][timeout:20];(' . $parts . ');out tags center 60;';
        try { $pdo->prepare('INSERT INTO open_place_asks (qkey, found, asked_at) VALUES (?, 0, NOW()) ON DUPLICATE KEY UPDATE asked_at = NOW()')->execute(['verify:' . substr(sha1($q), 0, 40)]); } catch (Throwable) {}
        // through OpenPlaces' servers: overpass-api.de off until its maintainers answer, a held server skipped, one at a time
        require_once __DIR__ . '/../OpenPlaces.php';
        return OpenPlaces::overpass($pdo, $q, 18, 15);
    }

    // ---- 2. Its own website -------------------------------------------------------------------------------------

    /** @return array{confirm:?array, moved:?array, hours:list<string>}|null  null: the site couldn't be read */
    public static function ownSite(array $c, string $site, ?array $pages = null): ?array
    {
        try { $url = SiteFetcher::normalizeStartUrl(preg_match('#^https?://#i', $site) ? $site : 'https://' . $site); } catch (InvalidArgumentException $x) { return null; }   // not a website we read (social media)
        if ($pages === null) {
            try { $pages = (new SiteFetcher(['max_pages' => 6]))->fetch($url)['pages'] ?? []; } catch (Throwable $x) { error_log('deep look site: ' . $x->getMessage()); return null; }
        }
        if (!$pages) return null;
        $cands = ListingExtractor::extract($pages, $url);
        $myNum = self::num((string) ($c['where']['address'] ?? ''));
        $phone = substr(preg_replace('/\D/', '', (string) ($c['actions']['phone'] ?? '')), -10);
        $ours = 0;   // locations on the site that are this business's (its name, or its phone)
        foreach ($cands as $k) {
            $sim = AutoImport::sameName((string) ($c['name'] ?? ''), (string) ($k['name'] ?? ''));
            $kp = substr(preg_replace('/\D/', '', (string) ($k['actions']['phone'] ?? '')), -10);
            $isOurs = $sim >= 0.5 || ($phone !== '' && $kp === $phone) || count($cands) <= 12;   // a business's own site: its locations
            if (!$isOurs) continue;
            $kNum = self::num((string) ($k['where']['address'] ?? ''));
            if ($kNum === '') continue;
            $ours++;
            if ($myNum !== '' && $kNum === $myNum) {
                return ['confirm' => ['url' => (string) ($k['where']['location_page'] ?? $url), 'kind' => 'own_site', 'evidence' => $kp !== '' && $kp === $phone ? 'both' : 'address',
                                      'phone' => (string) ($k['actions']['phone'] ?? ''), 'label' => 'Its own website: ' . mb_substr((string) ($k['name'] ?? ''), 0, 80)],
                        'moved' => null, 'hours' => array_values(array_map('strval', (array) ($k['when']['hours'] ?? [])))];
            }
        }
        // its own site lists its locations, and this street number isn't one of them
        $moved = ($ours >= 1 && $myNum !== '') ? ['via' => 'its own website', 'url' => $url, 'note' => 'Its own website lists ' . $ours . ' location' . ($ours === 1 ? '' : 's') . ', not this address'] : null;
        return ['confirm' => null, 'moved' => $moved, 'hours' => []];
    }
}
