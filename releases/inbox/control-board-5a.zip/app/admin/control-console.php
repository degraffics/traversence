<?php
// app/admin/control-console.php — System Configuration → System Control Board (decisions/0171, release 2b; laid out again
// after Jason's example board, 2026-11-18: "adjust the page layout and presentation of data so I can better use and
// understand our system board"). From the top:
// - a status strip: what's held now, the three core hosts and when the pre-flight last ran;
// - the six stages, and where the system stands;
// - the system's own controls, with a filter and Open all / Close all;
// - two panels: what's holding now (each opens its process) and the four query timings against their limits;
// - each system a card, its processes rows in columns (Process, Where it stands, Last 24 hours). Each row opens under its
//   name to its whole process: Route, Its check, Needs (each source in order, ours first, which works), Last 24 hours
//   (what came in and where every one went), runs, Records touched, and its controls.
// Buttons answer in place (js/admin-control.js); the board draws itself again every 30 seconds while it's open. The data
// is ControlBoard's (app/lib/ControlBoard.php), read from the pre-flight's stored lines and the ledger: nothing is tested
// by opening the page.
declare(strict_types=1);

require_once __DIR__ . '/../lib/ControlBoard.php';
require_once __DIR__ . '/../lib/ControlAlarms.php';
require_once __DIR__ . '/../lib/ControlMaintenance.php';
if (!function_exists('tv_w_e')) require_once __DIR__ . '/widgets.php';

function tv_cb_mark(string $light): string
{
    // red only for a trip or a core host down; amber for what's held, timing out, on a backup or near a limit (Jason,
    // 2026-11-18: --tv-fail var(--cb-fail), --tv-hold var(--cb-hold), the palette's tokens shared with Pulse)
    // blue: out for maintenance on purpose (0171 §2.5), never a failure; a wrench
    if ($light === 'maint') return '<span class="cb-m" role="img" aria-label="In maintenance: out on purpose" title="In maintenance: out on purpose" style="background:var(--cb-maint-bg);color:var(--cb-maint)"><svg class="cb-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.5-.5-.5-2.5z"/></svg></span>';
    if ($light === 'hold') return '<span class="cb-m" role="img" aria-label="Held: waiting on what it needs" title="Held: waiting on what it needs" style="background:var(--cb-hold-bg);color:var(--cb-hold)"><svg class="cb-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M9 6v12M15 6v12"/></svg></span>';
    $m = ['ok' => ['#DCFCE7', '#15803D', 'check', 'Working'], 'bad' => ['var(--cb-fail-bg)', 'var(--cb-fail)', 'x', 'Stopped: needs an admin'], 'warn' => ['var(--cb-hold-bg)', 'var(--cb-hold)', 'check', 'On a backup or near a limit'],
          'off' => ['#F1EDE6', '#8a7a68', 'dash', 'Switched off'], 'wait' => ['#F1EDE6', '#8a7a68', 'clock', 'Not tested yet'], 'new' => ['#F1EDE6', '#8a7a68', 'clock', 'Not tested yet'], 'na' => ['#F1EDE6', '#8a7a68', 'dash', 'Nothing to do']][$light] ?? ['#F1EDE6', '#8a7a68', 'dash', ''];
    $ic = function_exists('tv_icon') ? tv_icon($m[2], 'cb-svg') : ($light === 'bad' ? '✗' : '✓');
    return '<span class="cb-m" role="img" aria-label="' . tv_w_e($m[3]) . '" title="' . tv_w_e($m[3]) . '" style="background:' . $m[0] . ';color:' . $m[1] . '">' . $ic . '</span>';
}

function tv_cb_record_link(string $kind, int $id, string $what = ''): string
{
    $u = $kind === 'listing' ? '/admin/listing-edit.php?id=' . $id : ($kind === 'review' ? '/admin/listing-intake.php?row=' . $id : '');
    $label = ($kind === 'listing' ? 'Listing #' : ($kind === 'review' ? 'Review item #' : ucfirst($kind) . ' #')) . $id . ($what !== '' ? ' (' . $what . ')' : '');
    return $u !== '' ? '<a href="' . tv_w_e($u) . '" data-peek-frame class="underline cb-rec">' . tv_w_e($label) . '</a>' : tv_w_e($label);
}

function tv_cb_time(int $at): string
{
    return $at ? '<time datetime="' . gmdate('c', $at) . '" data-tv-time>' . gmdate('M j, H:i', $at) . ' UTC</time>' : 'not run yet';
}

/** One line of a process's detail: its label, then what it says, on the same line (above it, on a phone). */
function tv_cb_kv(string $label, string $html): string
{
    return '<div class="cb-kv"><span class="cb-lb">' . tv_w_e($label) . ':</span><div class="cb-kd">' . $html . '</div></div>';
}

/**
 * A row's columns (laid out after Jason's example, 2026-11-18): the line under its name, its stage, where it stands in a
 * few words, the last 24 hours (runs; what came in and how much of it is accounted for), its speed, and its OK rate.
 */
function tv_cb_row(string $id, array $p, array $needs, string $sysStage = 'observe'): array
{
    require_once __DIR__ . '/../lib/Preflight.php';
    $c = $p['calls'];
    // under its name: the phases a workflow runs in (0164 §7), or what kind of thing it is
    $sub = '';
    if (str_starts_with($id, 'wf:')) { $ph = []; foreach (Preflight::PHASES as $n => [$pn, $wfs]) if (in_array(substr($id, 3), $wfs, true)) $ph[] = $n;
        $sub = $ph ? (count($ph) === 1 ? 'Phase ' . $ph[0] . ' · ' . Preflight::PHASES[$ph[0]][0] : 'Phases ' . implode(', ', $ph)) : 'Workflow'; }
    elseif (str_starts_with($id, 't:')) $sub = 'A task';
    elseif (str_starts_with($id, 'wk:')) $sub = 'A worker on Railway';
    elseif (str_starts_with($id, 'svc:')) $sub = 'An outside service';
    elseif (str_starts_with($id, 'job:')) $sub = 'A site job';
    // its stage
    $stage = $p['light'] === 'bad' ? ['bad', 'Tripped'] : ($p['light'] === 'maint' ? ['maint', 'In maintenance'] : ($p['switch'] === 'off' ? ['off', 'Shut down'] : ($p['light'] === 'hold' ? ['hold', $p['switch'] === 'on' ? 'Holding' : 'Held']
        : ($p['switch'] === 'on' ? ($sysStage === 'shutdown' ? ['new', 'Standby'] : ['ok', 'Observation']) : (in_array($p['light'], ['ok', 'warn'], true) ? ['ok', 'Working'] : ['new', 'Pre-flight'])))));
    // where it stands, in a few words: what holds it, else why it's off, else its needs
    $where = '';
    foreach ((array) ($p['line']['extra']['parts'] ?? []) as [$txt, $st]) if ($st === 'bad') { $where = 'Holds it: ' . $txt; break; }
    if ($where === '') $where = (string) preg_replace('/^[^:]{0,40} is paused: /u', 'Paused: ', $p['words']);
    if ($needs) { $ok = count(array_filter($needs, fn ($x) => in_array($x[1], ['ok', 'warn'], true))); $where = rtrim($where, '.') . '. ' . $ok . ' of ' . count($needs) . ' needs answered.'; }
    // the last 24 hours
    $nRuns = array_sum($p['outcomes']) + $p['jobs'][0] + $p['jobs'][1];
    $sorted = $c['stored'] + $c['updated'] + $c['review'] + $c['refused'];
    $runs = $nRuns ? [number_format($nRuns) . ' run' . ($nRuns === 1 ? '' : 's'), '', false] : ($c['calls'] ? [number_format($c['calls']) . ' call' . ($c['calls'] === 1 ? '' : 's'), '', false] : ['—', '', false]);
    if ($c['received'] > 0) { $pct = (int) floor(100 * min($sorted, $c['received']) / $c['received']); $runs[1] = number_format($c['received']) . ' in · ' . $pct . '% accounted'; $runs[2] = $pct === 100; }
    $speed = $c['calls'] ? [($c['received'] > 0 ? round($c['ms'] * $c['calls'] / $c['received']) . ' ms/rec' : $c['ms'] . ' ms a call'), $c['received'] > 0 ? $c['ms'] . ' ms a call' : ''] : ['—', ''];
    // its OK rate: calls without a server error, runs without a failure
    $good = ($c['calls'] - $c['errors']) + $p['jobs'][0] + (array_sum($p['outcomes']) - (int) ($p['outcomes']['failed'] ?? 0));
    $all = $c['calls'] + $p['jobs'][0] + $p['jobs'][1] + array_sum($p['outcomes']);
    return ['sub' => $sub, 'stage' => $stage, 'where' => $where, 'runs' => $runs, 'speed' => $speed, 'ok' => $all ? round(100 * $good / $all, 1) . '%' : '—'];
}

/**
 * Text that might be long: one line, and More opens the same line in place (Jason, 2026-11-18: "show a line of text with a
 * toggle or see more to expand its presentation, not repeat it in full"). Short text is just the text.
 */
function tv_cb_more(string $text, int $short = 140, string $lead = ''): string
{
    $e = 'tv_w_e';
    if (mb_strlen($text) <= $short) return $lead . $e($text);
    // a toggle, not "…" and More (Jason, 2026-11-18): closed, the line runs to the edge and fades; ▸ opens it in place
    return '<span class="cb-tg" data-cb-clamp><button type="button" class="cb-tgb" data-cb-more aria-expanded="false" aria-label="Show all of it" title="Show all of it">'
        . '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg></button>'
        . '<span class="cb-tgt" data-cb-more>' . $lead . $e($text) . '</span></span>';
}

/** Its check in a line: what holds it first, else that every part passes; the other parts on a toggle, never repeated. */
function tv_cb_check(array $line): string
{
    $e = 'tv_w_e'; $s = (string) ($line['s'] ?? 'new'); $parts = (array) ($line['extra']['parts'] ?? []);
    $at = ' <small>' . tv_cb_time((int) ($line['at'] ?? 0)) . '</small>';
    if ($parts) {
        $bad = array_values(array_filter($parts, fn ($x) => ($x[1] ?? null) === 'bad'));
        $rest = array_values(array_filter($parts, fn ($x) => ($x[1] ?? null) !== 'bad'));
        $head = $bad ? tv_cb_more(implode(' ', array_column($bad, 0)), 140, '<b class="cb-bad">Holds it:</b> ') : $e('Every part passes: ' . implode(', ', array_map(fn ($x) => strtolower((string) strtok((string) $x[0], ':')), array_filter($parts, fn ($x) => ($x[1] ?? null) !== null)))) . '.';
        $li = ''; foreach ($rest as [$txt, $st]) $li .= '<li>' . ($st !== null ? tv_cb_mark((string) $st) : '<span class="cb-m" aria-hidden="true"></span>') . '<span>' . tv_cb_more((string) $txt) . '</span></li>';
        return '<div class="cb-ck">' . tv_cb_mark($s) . (str_starts_with($head, '<span class="cb-tg"') ? $head : '<span class="cb-ckt">' . $head . '</span>') . '</div>' . $at . ($bad && $rest ? '<details class="cb-more"><summary>Its other ' . count($rest) . ' part' . (count($rest) === 1 ? '' : 's') . '</summary><ul class="cb-parts">' . $li . '</ul></details>' : '');
    }
    // a line from before checks were kept part by part: said so, with the way to run it again
    $said = (string) preg_replace('/^What holds it:\s*/u', '', (string) ($line['said'] ?? ''));
    $said = tv_cb_more($said);
    return '<div class="cb-ck">' . tv_cb_mark($s) . (str_starts_with($said, '<span class="cb-tg"') ? $said : '<span class="cb-ckt">' . $said . '</span>') . '</div>' . $at . ($s === 'bad' && str_contains((string) ($line['said'] ?? ''), 'What holds it:') ? ' <small class="cb-old">Tested before checks were shown part by part: press Check to see which part holds it.</small>' : '');
}

/** The needs as chips: each need, ✓ or ✗, and the source that answered it (all its sources in order on hover); a chip tests it. */
function tv_cb_needs(array $needs, bool $canTest, string $whyTest): string
{
    $e = 'tv_w_e'; $h = '<div class="cb-chips">';
    foreach ($needs as $k => [$name, $s, $src, $fallback, $soft, $at]) {
        $by = ''; foreach ($src as $x) if ($x[2] === true) { $by = (string) $x[0]; break; }
        $what = $s === 'new' ? 'not tested' : ($by !== '' ? ($s === 'warn' ? 'on a backup: ' : '') . preg_replace('/^Ours \((.*)\)$/u', '$1', $by) : 'nothing works: ' . $fallback);
        $title = 'Its sources, ours first: ' . implode(' → ', array_map(fn ($i, $x) => ($i + 1) . '. ' . $x[0] . ($x[2] === null ? '' : ($x[2] ? ' ✓' : ' ✗')), array_keys($src), $src)) . ($canTest ? '. Press to test it.' : '');
        $mk = ['ok' => '✓', 'warn' => '✓', 'bad' => '✗'][$s] ?? '…';
        $h .= '<button type="button" class="cb-chip cb-chip-' . $e(in_array($s, ['ok', 'warn', 'bad'], true) ? $s : 'new') . '" id="cb-nd-' . $e($k) . '" data-cb="check" data-cb-id="nd:' . $e($k) . '" title="' . $e($title) . '" aria-label="' . $e($name . ': ' . $what . '. ' . $title) . '"' . ($canTest ? '' : ' disabled') . '>'
            . $e($name) . ' <b>' . $mk . '</b> <small>(' . $e($what) . ')</small></button>';
    }
    return $h . '</div>';
}

/**
 * #maintenance (0171 §2.5, §12; release 4a): what's out and planned, with Put back and Cancel; a window set ahead (any
 * workflow, or a task with its own switch: from, Back by, why); and the upkeep calendar, what's due from what the code
 * already schedules. Its list and calendar are drawn again with the board; the form isn't, so what's typed stays.
 */
function tv_cb_maintenance(PDO $pdo, array $names, callable $btn, bool $canRun, string $wNo): string
{
    $e = 'tv_w_e';
    $rows = ControlMaintenance::listing($pdo);
    $out = array_values(array_filter($rows, fn ($r) => $r['state'] === 'out'));
    $plan = array_values(array_filter($rows, fn ($r) => $r['state'] === 'planned'));
    $nm = fn (string $p) => $names[$p] ?? $p;
    $at = fn (?string $d) => $d ? tv_cb_time((int) strtotime($d . ' UTC')) : '';
    $sum = $out ? count($out) . ' out' . ($plan ? ', ' . count($plan) . ' planned' : '') : ($plan ? count($plan) . ' planned' : 'nothing out');
    $h = '<details class="ak-card tv-bleed cb-panel" id="maintenance"' . ($out ? ' open' : '') . '><summary class="cb-ph"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($out ? 'maint' : 'na') . '<b>Maintenance</b> <small>' . $e($sum) . '</small></summary><div class="cb-mt">';
    // what's out, planned, and back in the last two days
    $li = '';
    foreach ($rows as $r) {
        $st = (string) $r['state'];
        $words = $st === 'out' ? 'Out since ' . $at($r['out_at']) . ', back by ' . $at($r['until_at'])
            : ($st === 'planned' ? 'Goes out ' . $at($r['from_at']) . ', back by ' . $at($r['until_at'])
            : ($st === 'back' ? 'Back ' . $at($r['back_at']) . ($r['back_by'] ? ' (' . $e((string) $r['back_by']) . ')' : '') : 'Cancelled'));
        $b = $st === 'out' ? $btn('maintback', 'Put back', $canRun, $wNo, (string) $r['id'], ['class' => 'ak-b cb-xs', 'data-confirm' => 'Put it back? Its check runs first; it starts again only if the check isn\'t red.', 'data-yes' => 'Put it back'])
            : ($st === 'planned' ? $btn('maintcancel', 'Cancel', $canRun, $wNo, (string) $r['id'], ['class' => 'ak-b cb-xs', 'data-confirm' => 'Cancel this window? It won\'t go out.', 'data-yes' => 'Cancel it']) : '');
        $li .= '<li id="cb-mt-' . (int) $r['id'] . '"><span class="cb-pill cb-pill-' . ($st === 'out' ? 'maint' : 'new') . '">' . $e(['out' => 'Out', 'planned' => 'Planned', 'back' => 'Back', 'cancelled' => 'Cancelled'][$st] ?? $st) . '</span>'
            . '<b>' . $e($nm((string) $r['proc'])) . '</b><span>' . $words . '</span><span>Why: ' . $e((string) $r['why']) . ($r['by_name'] ? ' (' . $e((string) $r['by_name']) . ')' : '') . '</span>'
            . ($r['note'] ? '<span data-tv-status="bad" data-tv-label="Still out:">' . $e((string) $r['note']) . '</span>' : '') . ($b !== '' ? '<span class="cb-acts">' . $b . '</span>' : '') . '</li>';
    }
    $h .= '<div class="cb-mlist">' . ($li !== '' ? '<ul class="cb-ml">' . $li . '</ul>' : '<p class="ak-note">Nothing is out for maintenance, and no window is planned.</p>') . '</div>';
    // a window set ahead (or now): any workflow, or a task with its own switch
    $opts = '';
    foreach ($names as $pid => $n) if (ControlMaintenance::canTake($pid)) $opts .= '<option value="' . $e($pid) . '">' . $e($n) . '</option>';
    if ($opts !== '') $h .= '<form id="cb-mt-form"><label>Process<select name="proc">' . $opts . '</select></label>'
        . '<label>Goes out<input type="datetime-local" name="from" aria-label="When it goes out (empty: now)"></label>'
        . '<label>Back by<input type="datetime-local" name="until" required aria-label="When it comes back by itself"></label>'
        . '<label class="cb-why">Why<input type="text" name="why" maxlength="255" required data-spell placeholder="New keys for its service"></label>'
        . $btn('maintplan', 'Take it out', $canRun, $wNo, '', ['data-cb-form' => 'cb-mt-form']) . '</form>'
        . '<p class="ak-note">Empty "Goes out" takes it out now. It\'s shut down in order (its tasks, then the workflow), shows blue, its alarms are notices and Start skips it. At its Back by it comes back by itself, after its check; a red check keeps it out and raises a warning. Times are in your time zone.</p>';
    // the upkeep calendar
    $up = '';
    // each opens in place: its process's row on the board, or its scheduled task in a drawer (the session manager's note)
    foreach (ControlMaintenance::upkeep($pdo) as [$what, $when, $often, $note, $proc]) {
        $rid = 'cb-p-' . str_replace(':', '-', $proc);
        $link = isset($names[$proc]) ? '<a class="underline" href="#' . $e($rid) . '" data-cb-go="' . $e($rid) . '">' . $e($what) . '</a>'
            : (str_starts_with($proc, 'job:') ? '<a class="underline" href="/admin/config/scheduler#job-' . $e(substr($proc, 4)) . '" data-peek-frame>' . $e($what) . '</a>' : $e($what));
        $up .= '<li><span class="cb-when">' . ($when ? tv_cb_time($when) : 'not scheduled') . '</span><b>' . $link . '</b><span>' . $e($often) . '</span><small class="ak-note">' . $e($note) . '</small></li>';
    }
    $h .= '<div class="cb-uplist"><h4 style="margin:.3rem 0 .2rem">Upkeep calendar: what\'s due</h4>' . ($up !== '' ? '<ul class="cb-up">' . $up . '</ul>' : '<p class="ak-note">Nothing scheduled.</p>') . '</div>';
    return $h . '</div></details>';
}

/**
 * The alarm list's one filter: a dropdown button like Shortcuts (icon, current choice, count, ▾), moved up into the page's
 * header by admin-kit.js (data-ak-cmd; it stays here inside a drawer). Its choices and their counts are kept by
 * admin-control.js through each redraw (CLAUDE.md "Filters on a list or queue are one dropdown button"; the session
 * manager, 2026-11-18: it was a native select and a gear on their own row).
 */
function tv_cb_afilter(): string
{
    $ic = function_exists('tv_icon') ? tv_icon('filter', 'ak-svg') : '';
    $h = '<span class="ak-fw cb-afw" data-ak-cmd><button type="button" class="ak-fb" aria-expanded="false" aria-haspopup="true" title="Which alarms to show" data-cb-afb>' . $ic . '<span data-cb-afname>Open alarms</span> <b data-cb-afcount>0</b></button><span class="ak-fl" hidden>';
    foreach (['open' => 'Open alarms', 'ack' => 'Acknowledged', 'cleared' => 'Cleared (2 days)', 'all' => 'All alarms', 'trip' => 'Trips', 'warning' => 'Warnings', 'notice' => 'Notices'] as $k => $l)
        $h .= '<button type="button" data-cb-afv="' . $k . '"' . ($k === 'open' ? ' class="on"' : '') . '>' . tv_w_e($l) . '<i data-cb-afn="' . $k . '">0</i></button>';
    return $h . '</span></span>';
}

/**
 * The logbook's rows (0171 §10, release 5a): newest first, 50 at a time, each with its time in the zone where it happened
 * (labelled), what happened, who (staff, or the system) and why; "Show older" carries on from the last one.
 */
function tv_cb_log_rows(PDO $pdo, string $scope = '', int $before = 0): string
{
    require_once __DIR__ . '/../lib/ControlLog.php';
    $e = 'tv_w_e'; $rows = ControlLog::feed($pdo, $scope, $before, 50);
    if (!$rows) return $before ? '<li class="cb-lg-end"><small class="ak-note">Nothing older.</small></li>' : '<li class="cb-lg-end"><small class="ak-note">Nothing logged yet' . ($scope !== '' ? ' for this' : '') . '.</small></li>';
    $h = '';
    foreach ($rows as [$at, $tz, $kind, $proc, $what, $who, $why])
        $h .= '<li><time datetime="' . gmdate('c', $at) . '" data-tv-time' . ($tz !== '' ? ' data-tz="' . $e($tz) . '"' : '') . '>' . gmdate('M j, H:i', $at) . ' UTC</time>'
            . '<span class="cb-pill cb-pill-new">' . $e(ControlLog::KINDS[$kind] ?? $kind) . '</span><span class="cb-lg-w">' . $e($what) . ($why !== '' ? ' <small>' . $e($why) . '</small>' : '') . '</span><small class="cb-lg-who">' . $e($who) . '</small></li>';
    $last = end($rows)[0];
    return $h . (count($rows) >= 50 ? '<li class="cb-lg-more"><button type="button" class="ak-b cb-xs" data-cb-logmore="' . (int) $last . '">Show older</button></li>' : '');
}

/** #log: the logbook, its one filter (the system, a system, or one process) and Log an entry (spell-checked, with its zone). */
function tv_cb_logbook(PDO $pdo, array $names, bool $canNote): string
{
    $e = 'tv_w_e';
    // the one filter, a dropdown button like Shortcuts (icon, current choice, ▾): the whole system, a system, or a process
    $ic = function_exists('tv_icon') ? tv_icon('filter', 'ak-svg') : '';
    $opts = '<button type="button" data-cb-logv="" class="on">The whole system</button>';
    foreach (ControlRegister::SYSTEMS as $sk => $sn) $opts .= '<button type="button" data-cb-logv="sys:' . $e($sk) . '">' . $e($sn) . '</button>';
    foreach ($names as $pid => $n) $opts .= '<button type="button" data-cb-logv="' . $e($pid) . '">' . $e($n) . '</button>';
    $nopts = '<option value="">The whole system</option>'; foreach ($names as $pid => $n) $nopts .= '<option value="' . $e($pid) . '">' . $e($n) . '</option>';
    return '<details class="ak-card tv-bleed cb-panel" id="log"><summary class="cb-ph"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark('na') . '<b>Logbook</b> <small>every switch, control, alarm and note, newest first</small></summary>'
        . '<div class="cb-lg"><span class="ak-fw cb-lgw"><button type="button" class="ak-fb" aria-expanded="false" aria-haspopup="true" title="Whose log to show" data-cb-logb>' . $ic . '<span data-cb-logname>The whole system</span></button><span class="ak-fl" hidden>' . $opts . '</span></span>'
        . '<ul class="cb-lgl" data-cb-loglist>' . tv_cb_log_rows($pdo) . '</ul>'
        . '<form class="cb-lg-n" id="cb-log-form"><label class="cb-why">Log an entry<textarea name="text" rows="2" maxlength="400" required data-spell placeholder="What happened, or what you did"></textarea></label>'
        . '<label>On<select name="scope">' . $nopts . '</select></label>'
        . '<button type="button" class="ak-b" data-cb-lognote' . ($canNote ? '' : ' disabled title="Only staff who can view the board log an entry."') . '>Log it</button></form>'
        . '<p class="ak-note">Read from where each is kept (switches, Start\'s sessions, the pre-flight\'s runs, outside services\' issues, site jobs that stopped, releases), and the board\'s own log. Who is a staff member or the system; times are where they happened.</p></div></details>';
}

/** A process's controls: short on its row (Check, Start, Shut down), named in full under it. */
function tv_cb_controls(string $id, array $p, array $res, callable $btn, bool $canPf, string $whyPf, bool $canRun, string $wNo, bool $short): string
{
    $x = ['class' => $short ? 'ak-b cb-xs' : 'ak-b'];
    $a = '';
    if (isset($res[$id]) || str_starts_with($id, 'wf:') || str_starts_with($id, 't:') || str_starts_with($id, 'svc:') || str_starts_with($id, 'site:') || (str_starts_with($id, 'wk:') && ControlRegister::WORKERS[substr($id, 3)][3] !== ''))
        $a .= $btn('check', $short ? 'Check' : 'Run its check', $canPf, $whyPf, $id, $x);
    // maintenance (0171 §2.5): Put back when it's out; Take out for a workflow or a task with its own switch
    $mt = $p['maint'] ?? null;
    if ($mt) return $a . $btn('maintback', 'Put back', $canRun, $wNo, (string) $mt['id'], $x + ['data-confirm' => 'Put ' . $p['name'] . ' back? Its check runs first; it starts again only if the check isn\'t red.', 'data-yes' => 'Put it back']);
    if ($p['switch'] === 'on') $a .= $btn('stop', $short ? 'Shut down' : 'Shut it down', $canRun, $wNo, $id, $x + ['data-confirm' => 'Shut ' . $p['name'] . ' down? Its tasks first, then the workflow. What\'s running finishes.', 'data-yes' => 'Shut it down']);
    if ($p['switch'] === 'off') $a .= $btn('start1', $short ? 'Start' : 'Start it', $canRun, $wNo, $id, $x);
    static $mh = null; if ($mh === null) { try { $mh = ControlMaintenance::defaultHours(Database::connection()); } catch (Throwable $x) { $mh = 2; } }
    if (!$short && ControlMaintenance::canTake($id)) $a .= $btn('maintout', 'Take out for maintenance', $canRun, $wNo, $id, $x + ['data-cb-ask' => 'Why is it going out? (It comes back by itself in ' . $mh . ' hour' . ($mh === 1 ? '' : 's') . '; set other times under Maintenance.)', 'data-cb-val' => '', 'data-cb-yes' => 'Take it out']);
    if (!$short && str_starts_with($id, 'svc:')) $a .= '<a class="ak-b" href="/admin/config/register#svc-' . tv_w_e(substr($id, 4)) . '" data-peek-frame>Its register entry</a>';
    return $a;
}

/** Where an alarm's evidence is, in a drawer: its runs, its card, its jobs, or its pre-flight line. */
function tv_cb_evidence(array $a): array
{
    $p = (string) $a['proc']; $k = (string) $a['akey'];
    if (str_starts_with($k, 'pf:')) return ['Open its line', '/admin/config/preflight#pf-' . str_replace(':', '-', substr($k, 3))];
    if ($p === 'wk:crawler' || str_starts_with($p, 'wf:') || str_starts_with($p, 't:')) return ['Open its runs', '/admin/insights/crawler'];
    if (str_starts_with($p, 'svc:')) return ['Open its card', '/admin/config/register#svc-' . substr($p, 4)];
    if (str_starts_with($p, 'job:')) return ['Open its runs', '/admin/config/scheduler'];
    return ['Open its process', ''];
}

/**
 * The queue (0171 §7, release 3a): one row per issue, never per process, Trip then Warning then Notice, newest first;
 * what happened, what it means, what to do, its fix in place, its evidence in a drawer, Acknowledge (Undo), its count and
 * last seen, and the processes it holds. One dropdown filters it (Open, Acknowledged, Cleared; by level). Open on load
 * whenever anything is open.
 */
function tv_cb_alarms(array $alarms, array $ac, array $names, callable $pid, bool $canPf, string $whyPf, callable $btn, array $redChecks = []): string
{
    $e = 'tv_w_e';
    require_once __DIR__ . '/../lib/Operations.php'; [$canOps, $whyOps] = Operations::can();   // the cap and empty steps' own permission
    [$canBoard, $whyBoard] = ControlBoard::can();   // an admin's Resolve (executive, 0171 §13)
    $nOpen = $ac['trip'] + $ac['warning'] + $ac['notice'];
    $sum = $nOpen ? implode(', ', array_filter([$ac['trip'] ? $ac['trip'] . ' trip' . ($ac['trip'] === 1 ? '' : 's') : '', $ac['warning'] ? $ac['warning'] . ' warning' . ($ac['warning'] === 1 ? '' : 's') : '', $ac['notice'] ? $ac['notice'] . ' notice' . ($ac['notice'] === 1 ? '' : 's') : ''])) . ' open' : 'nothing open';
    $h = '<details class="ak-card tv-bleed cb-panel cb-alarms" id="cb-alarms"' . ($nOpen ? ' open' : '') . '><summary class="cb-ph"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($ac['trip'] ? 'bad' : ($ac['warning'] ? 'hold' : 'ok')) . '<b>Alarms</b> <small>' . $e($sum) . '</small></summary>';
    if (!$alarms) return $h . '<p data-tv-status="ok" data-tv-label="All clear:">No alarm is open. A problem raises one the moment it happens; a warning clears by itself when its reading is good again.</p></details>';
    $h .= '<ul class="cb-al">';   // its filter is one dropdown button in the page's header (tv_cb_afilter)
    // one alarm's row; two or more sharing a system, level and kind are one group row that opens to them (0171 §8's
    // note, Jason 2026-11-18: "Board and Pulse"), each keeping its own buttons
    $one = function (array $a) use ($e, $btn, $canPf, $whyPf, $canOps, $whyOps, $canBoard, $whyBoard, $names, $pid): string {
        $cl = $a['cleared_at'] !== null; $lv = (string) $a['level']; $ack = $a['ack_at'] !== null; $id = (int) $a['id'];
        $state = $cl ? 'cleared' : ($ack ? 'ack' : 'open');
        $fx = (array) $a['fix']; $proc = (string) $a['proc'];
        $ev = tv_cb_evidence($a);
        $fxs = $fx && isset($fx[0]) && is_array($fx[0]) ? $fx : ($fx ? [$fx] : []);
        if (str_starts_with((string) $a['akey'], 'svc:issue:')) $fxs[] = ['Mark resolved', 'svcresolve', substr((string) $a['akey'], 10)];   // as its old Pulse case had
        $isTrip = $lv === 'trip' && !empty($a['tripped_at']);
        if ($isTrip && !$cl) $fxs = array_values(array_filter($fxs, fn ($f) => !in_array($f[1] ?? '', ['svcresolve', 'svccheck', 'check'], true)));   // an admin's Resolve stands for them
        $fb = ''; foreach ($fxs as $f) $fb .= ($f[1] ?? '') === 'link' ? '<a class="ak-b cb-xs" href="' . $e((string) $f[2]) . '" target="_blank" rel="noopener">' . $e((string) $f[0]) . ' ↗</a>'
            : (($f[1] ?? '') === 'peek' ? '<a class="ak-b cb-xs" href="' . $e((string) $f[2]) . '" data-peek-frame>' . $e((string) $f[0]) . '</a>'
            : (in_array($f[1] ?? '', ['ops', 'opsask'], true)   // the old Pulse case's steps, acting in place (0171 §7, §8): [label, 'ops'|'opsask', 'what', confirm|[ask label, value]]
                ? $btn('opsdo', (string) $f[0], $canOps, $whyOps, (string) $a['akey'] . '|' . (string) $f[2], ['class' => 'ak-b cb-xs']
                    + ($f[1] === 'opsask' ? ['data-cb-ask' => (string) ($f[3][0] ?? ''), 'data-cb-val' => (string) ($f[3][1] ?? '')] : (is_string($f[3] ?? null) ? ['data-confirm' => $f[3], 'data-yes' => (string) $f[0]] : [])))
            : (is_string($f[3] ?? null) && str_starts_with($f[3], '#wait:')   // a button the system holds for now, greyed with its reason (a 429's Check it now)
                ? $btn((string) $f[1], (string) $f[0], false, substr($f[3], 6), (string) ($f[2] ?? ''), ['class' => 'ak-b cb-xs'])
            : $btn((string) $f[1], (string) $f[0], $canPf, $whyPf, (string) ($f[2] ?? ''), ['class' => 'ak-b cb-xs'] + (($f[1] ?? '') === 'svcresolve' ? ['data-confirm' => 'Mark it resolved? Calls to it start again; a new failure opens a new issue.', 'data-yes' => 'Mark resolved'] : [])))));
        // a trip waits for an admin (decisions/0171 §7's note, release 3c): Resolve asks what fixed it; Undo for a day after
        $sw = ControlAlarms::stoppedWords($a);
        // the system does it: check, then start again what the trip stopped; never a question to get past (Jason, 2026-11-19)
        if ($isTrip && !$cl) {
            $redAt = ''; foreach ((array) json_decode((string) ($a['stopped'] ?? ''), true) as $sx) if (($sx[0] ?? '') === 'proc' && isset($redChecks[(string) $sx[1]])) { $redAt = (string) $sx[2] . '\'s check is red: ' . $redChecks[(string) $sx[1]]; break; }
            $fb = $btn('resolve', 'Check and start again', $canBoard && $redAt === '', $redAt !== '' ? $redAt . ' Fix that first (its Check is beside it); the system starts it again once it passes.' : $whyBoard, (string) $id, ['class' => 'ak-b cb-xs']) . $fb;
        }
        $undo = $cl && !empty($a['resolved_at']) && strtotime($a['resolved_at'] . ' UTC') > time() - 86400 ? $btn('unresolve', 'Undo the Resolve', $canBoard, $whyBoard, (string) $id, ['class' => 'ak-b cb-xs', 'data-confirm' => 'Open the trip again' . ($sw !== '' ? ' and stop ' . $sw . ' again' : '') . '?', 'data-yes' => 'Undo it']) : '';
        $acts = (!$cl ? $fb : $undo)
            . ($ev[1] !== '' && !in_array($ev[1], array_map(fn ($f) => (string) ($f[2] ?? ''), $cl ? [] : $fxs), true) ? '<a class="ak-b cb-xs" href="' . $e($ev[1]) . '" data-peek-frame>' . $e($ev[0]) . '</a>' : '')
            . ($ack ? $btn('unack', 'Undo', true, '', (string) $id, ['class' => 'ak-b cb-xs']) : $btn('ack', $cl ? 'Seen' : 'Acknowledge', true, '', (string) $id, ['class' => 'ak-b cb-xs']));
        $holds = isset($names[$proc]) ? '<a href="#' . $e($pid($proc)) . '" data-cb-go="' . $e($pid($proc)) . '" class="underline">' . $e($names[$proc]) . '</a>' : $e($proc);
        $li = '<li id="cb-alarm-' . $id . '" class="cb-al-' . $e($cl ? 'cleared' : $lv) . '" data-astate="' . $state . '" data-alevel="' . $e($lv) . '">' . tv_cb_mark($cl ? 'ok' : ($lv === 'trip' ? 'bad' : ($lv === 'warning' ? 'hold' : 'new')))
            . '<div><span class="cb-pill cb-pill-' . ($cl ? 'ok' : ($lv === 'trip' ? 'bad' : 'warn')) . '">' . $e($cl ? 'Cleared' : ControlAlarms::LEVELS[$lv]) . '</span> <b>' . $e((string) $a['title']) . '</b>'
            . '<div class="cb-am"><span><b>Holds:</b> ' . $holds . '</span>'
            . ($cl ? '<span><b>Cleared</b> ' . tv_cb_time((int) strtotime($a['cleared_at'] . ' UTC')) . ': ' . $e((string) $a['cleared_how']) . '</span>' : '')
            . ($a['means'] !== '' ? '<span><b>What it means:</b> ' . $e((string) $a['means']) . '</span>' : '')
            . ($a['todo'] !== '' && !$cl ? '<span><b>What to do:</b> ' . $e((string) $a['todo']) . '</span>' : '')
            . ($isTrip && !$cl ? '<span><b>Stopped:</b> ' . $e($sw !== '' ? $sw . ', until it\'s resolved.' : 'nothing could be stopped from here (it only trips).') . '</span>' : '')
            . ($isTrip && !$cl && !empty($a['good_at']) ? '<span class="cb-rd"><b class="cb-good">Reading good again</b> since ' . tv_cb_time((int) strtotime($a['good_at'] . ' UTC')) . ': ' . tv_cb_more((string) $a['good_how'] . ' Check it, then Resolve.', 90) . '</span>' : '')
            . (!$cl && str_starts_with((string) ($a['resolve_note'] ?? ''), 'Not resolved') ? '<span class="cb-rd">' . tv_cb_more((string) preg_replace('/^Not resolved at /', 'at ', (string) $a['resolve_note']), 90, '<b class="cb-bad">Not resolved:</b> ') . '</span>' : '')
            . ($a['reading'] !== '' ? '<span class="cb-rd">' . tv_cb_more((string) $a['reading'], 90, '<b>Reading:</b> ') . '</span>' : '')
            . '<span class="cb-mono">' . ControlAlarms::KINDS[$a['kind']] . ' · ' . (int) $a['n_times'] . ' time' . ((int) $a['n_times'] === 1 ? '' : 's') . ' · first ' . tv_cb_time((int) strtotime($a['first_at'] . ' UTC')) . ' · last ' . tv_cb_time((int) strtotime($a['last_at'] . ' UTC'))
            . ($ack ? ' · acknowledged by ' . $e((string) ($a['ack_name'] ?? 'staff')) : '') . '</span></div>'
            . '<div class="cb-acts">' . $acts . '</div></div></li>';
        return $li;
    };
    $groups = ControlAlarms::groups($alarms); $of = []; foreach ($groups as $gk => $g) foreach ($g['ids'] as $gid) $of[$gid] = $gk;
    $byId = array_column($alarms, null, 'id'); $done = [];
    foreach ($alarms as $a) {
        $id = (int) $a['id'];
        if (!isset($of[$id])) { $h .= $one($a); continue; }
        $gk = $of[$id]; if (isset($done[$gk])) continue; $done[$gk] = true; $g = $groups[$gk];
        $members = array_map(fn ($x) => $byId[$x], $g['ids']); $lv = $g['level'];
        $acked = !array_filter($members, fn ($x) => $x['ack_at'] === null);
        $nm = array_values(array_unique(array_map(fn ($x) => $names[$x['proc']] ?? (string) preg_replace('/:.*$/', '', (string) $x['title']), $members)));
        $h .= '<li id="cb-group-' . $e(str_replace(':', '-', $gk)) . '" class="cb-al-grp cb-al-' . $e($lv) . '" data-astate="' . ($acked ? 'ack' : 'open') . '" data-alevel="' . $e($lv) . '">' . tv_cb_mark($lv === 'trip' ? 'bad' : ($lv === 'warning' ? 'hold' : 'new'))
            . '<details class="cb-grp" id="cb-grpd-' . $e(str_replace(':', '-', $gk)) . '"><summary><span class="cb-pill cb-pill-' . ($lv === 'trip' ? 'bad' : 'hold') . '">' . $e(ControlAlarms::LEVELS[$lv]) . '</span> <b>' . $e($g['title']) . '</b> <span class="cb-caret" aria-hidden="true">▾</span>'
            . '<div class="cb-am"><span>' . tv_cb_more(implode(', ', $nm), 110, '<b>Holds:</b> ') . '</span></div></summary>'
            . '<div class="cb-acts">' . (!$acked ? $btn('ackgroup', 'Acknowledge all ' . count($members), true, '', $gk, ['class' => 'ak-b cb-xs']) : '') . '</div>'
            . '<ul class="cb-al cb-al-in">' . implode('', array_map($one, $members)) . '</ul></details></li>';
    }
    return $h . '</ul><p class="ak-note cb-anone" hidden>Nothing here for this filter.</p></details>';
}

/**
 * The statement to the OpenStreetMap community, opened in the board's drawer from the Overpass alarm (Jason, 2026-11-18:
 * a step never leaves the page). Its source is research/osm-overpass-2026-11-13.md §2 in the docs repo; kept the same.
 */
function tv_cb_statement_osm(): string
{
    $e = 'tv_w_e';
    $subject = 'Traversence: our Overpass requests get 406. What we did wrong, what we\'ve changed, and a question';
    $body = "Hello. I run Traversence (traversence.com), a local directory and travel guide for rural towns in Arizona and New Mexico. Our crawler uses the Overpass API to find the places in a town (cafés, garages, clinics, campgrounds) so we can check each one on its own website. Since 2026-11-13 our requests to overpass-api.de get 406 Not Acceptable. Our User-Agents were TraversenceCrawler/1.0 (+https://traversence.com; local directory of community resources) (the crawler, on Railway) and Traversence/1.0 (+https://traversence.com) (our site, when a visitor's search finds little nearby); both now end with our contact, support@traversence.com.\n\n"
        . "How we use OpenStreetMap. It's a layer of its own on our site, always credited \"© OpenStreetMap contributors\" with a link to the copyright page. We don't copy its data into our listings: a place OpenStreetMap shows tells us where to look, and what we list comes from the business's own website or official records.\n\n"
        . "How we recognized our failures. Our crawler's logs show every request to overpass-api.de answered 406 from 16:51 UTC on 2026-11-13, and again at 12:54 UTC on 2026-11-14. Reading your guidance, we saw that the fault was ours:\n- our queries were large: every kind of place in a town in one query, over a box around all its ZIP codes, with [timeout:110];\n- our crawler ran every 5 minutes and retried failed towns run after run, with no back-off;\n- when your server answered 406, our code asked again at once with the same query as a GET;\n- our site also asked overpass-api.de first, before any other instance;\n- nothing told us a server had refused us: the 406s were logged as ordinary failures, and nothing stopped.\n\n"
        . "What we've changed so it won't happen again.\n- We've stopped asking overpass-api.de, from the crawler and from our site, until we hear from you. We won't change our User-Agent or address to get round the block.\n- Each server has a circuit breaker. A 406, 403 or 401 stops every request to that server until a person on our team marks it resolved. A 429, a timeout or a server error backs off (10 minutes, doubling to 6 hours) before trying again.\n- Each refusal opens a case for our team naming the server, the status and what it said.\n- While a server blocks us, we don't contact it at all, not even its /api/status page. A person on our team turns it back on only after you tell us we may.\n- Our queries are split by kind (one kind of place per query), kept to a small area, with [timeout:25], and sent one at a time.\n- A town and kind that has been answered isn't asked again for 3 months.\n- Our own daily budget is a quarter of the published guidance for the public instances (2,500 queries and 250 MB a day, crawler and site together), and half that while any server blocks us and for two weeks after.\n\n"
        . "Could you tell us whether we're banned, and why, and what you'd like us to change to be allowed back? If our use is more than the public instance should carry, we'll stay on another instance or run our own.\n\nJason, Traversence, support@traversence.com";
    return '<div id="cb" class="cb-statement"><h2 class="ak-h">The statement to the OpenStreetMap community</h2>'
        . '<p data-tv-status="info" data-tv-label="Where to send it:">Post it on the OpenStreetMap Community Forum, in <b>Help and support</b> with the tag <b>overpass</b>: <a class="underline" href="https://community.openstreetmap.org/c/help/" target="_blank" rel="noopener">community.openstreetmap.org</a> (sign in with an OpenStreetMap account). FOSSGIS runs overpass-api.de; its terms are on fossgis.de. When they answer, come back to the alarm: Reactivate on OpenStreetMap\'s card, then Mark resolved.</p>'
        . '<p><b>Subject:</b> <span data-cb-copy-src="s">' . $e($subject) . '</span> <button type="button" class="ak-b cb-xs" data-cb-copy="s">Copy the subject</button></p>'
        . '<pre class="cb-stmt" data-cb-copy-src="b">' . $e($body) . '</pre><p><button type="button" class="ak-b" data-cb-copy="b">Copy the statement</button></p>'
        . '<p class="ak-note">Its source, with the evidence and where each fix stands: research/osm-overpass-2026-11-13.md in the docs repo.</p></div>'
        . '<style>.cb-statement{max-width:52rem}.cb-stmt{white-space:pre-wrap;font:14px/1.5 system-ui,sans-serif;background:#FFFDF8;border:1px solid #EFE6D6;border-radius:.4rem;padding:.7rem .8rem}</style>'
        . '<script>document.addEventListener("click",function(e){var b=e.target.closest("[data-cb-copy]");if(!b)return;var t=document.querySelector("[data-cb-copy-src=\'"+b.getAttribute("data-cb-copy")+"\']");if(!t)return;'
        . 'navigator.clipboard.writeText(t.textContent).then(function(){if(window.TvAsk)TvAsk.say("Copied.",{anchor:b});},function(){if(window.TvAsk)TvAsk.say("Your browser didn\'t allow copying: select the text and copy it.",{anchor:b,bad:true});});});</script>';
}

function tv_admin_mod_control(PDO $pdo): string
{
    if (($_GET['show'] ?? '') === 'osm-statement') return tv_cb_statement_osm();
    $e = 'tv_w_e';
    [$can, $why] = ControlBoard::can();
    if (!$can) return '<p data-tv-status="info" data-tv-label="Not for your role:">' . $e((string) $why) . '. The System Control Board is for executives: ask one, or write to support@traversence.com.</p>';
    require_once __DIR__ . '/../lib/SystemStart.php';
    require_once __DIR__ . '/../lib/Preflight.php';
    require_once __DIR__ . '/../lib/Staging.php';
    [$canRun, $whyRun] = SystemStart::can();
    [$canPf, $whyPf] = Preflight::can();
    $staging = Staging::here();
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $btn = function (string $act, string $label, bool $ok, string $why, string $id = '', array $attr = []) use ($e): string {
        $cls = $attr['class'] ?? 'ak-b'; unset($attr['class']);
        $a = ''; foreach ($attr as $k => $v) $a .= ' ' . $k . '="' . $e($v) . '"';
        return '<button type="button" class="' . $e($cls) . '" data-cb="' . $e($act) . '"' . ($id !== '' ? ' data-cb-id="' . $e($id) . '"' : '') . ($ok ? $a : ' disabled title="' . $e($why) . '"') . '>' . $e($label) . '</button>';
    };
    ControlBoard::settle($pdo);
    [$stage, $stageWords] = ControlBoard::stage($pdo);
    $wNo = $staging ? 'Nothing runs on staging: these work on the live site.' : $whyRun;

    // every process, read once
    $res = Preflight::results($pdo);
    $by = []; $held = [];
    // red is for a trip or a core host down only (Jason, 2026-11-18); a process held by its check, a timeout or a deferred
    // source is amber, "held"
    $tripped = []; foreach (ControlAlarms::list($pdo) as $x) if ($x['cleared_at'] === null && $x['level'] === 'trip') $tripped[(string) $x['proc']] = true;
    foreach (ControlRegister::processes($pdo) as $id => $p) {
        $row = ControlBoard::process($pdo, $id, $p, $res);
        // the board's light rules, shared with the historian so its trend shows what the board showed (release 4b)
        [$row['light'], $row['means']] = ControlBoard::boardLight($pdo, $id, $row, $tripped);
        if ($row['light'] === 'maint' && ($mt = ControlMaintenance::outFor($pdo, $id))) { $row['maint'] = $mt; $row['words'] = ControlMaintenance::words($mt) . '.'; }
        $by[$p[0]][$id] = $row;
        if (in_array($row['light'], ['bad', 'hold'], true)) $held[$id] = $row;
    }
    $siteNeeds = ControlBoard::needs($res, array_keys(array_filter(Preflight::NEEDS, fn ($n) => $n[0] === 'siteneeds')));
    $core = ControlBoard::core($res);
    $lastAt = 0; foreach ($res as $r) $lastAt = max($lastAt, (int) ($r['at'] ?? 0));
    $pid = fn (string $id) => 'cb-p-' . str_replace(':', '-', $id);

    $h = '<div id="cb" data-csrf="' . $e($csrf) . '">';

    // ---- the alarms first: the board's queue (decisions/0171 §7, release 3a), and what the result line says
    $alarms = ControlAlarms::list($pdo); $ac = ControlAlarms::counts($pdo);
    $names = []; foreach ($by as $rowsN) foreach ($rowsN as $idN => $pN) $names[$idN] = $pN['name'];
    $open = array_values(array_filter($alarms, fn ($x) => $x['cleared_at'] === null));
    // ---- the result line (Jason, 2026-11-18: "a result notice from a procedure where within the notice I should be able
    // to go to the report or section to further review"): the procedure and its time, what it found, each name opening its
    // alarm, the report in a drawer, and running it again in place; older than an hour, it says so
    $coreBad = array_filter($core, fn ($c) => $c[1] === 'bad');
    $runAt = 0; try { $runAt = (int) (Preflight::summary($pdo)['at'] ?? 0); } catch (Throwable $x) {}
    $pfOpen = array_values(array_filter($open, fn ($x) => str_starts_with((string) $x['akey'], 'pf:') && $x['level'] !== 'notice'));
    $go = fn (array $x) => '<a href="#cb-alarm-' . (int) $x['id'] . '" data-cb-go="cb-alarm-' . (int) $x['id'] . '" class="underline">' . $e($names[$x['proc']] ?? preg_replace('/:.*$/', '', (string) $x['title'])) . '</a>';
    $pfNames = []; foreach ($pfOpen as $x) { $nm = $names[$x['proc']] ?? (string) $x['proc']; if (!isset($pfNames[$nm])) $pfNames[$nm] = $go($x); }
    $old = $runAt && time() - $runAt > 3600;
    $result = $stage === 'shutdown' ? ['off', 'Stopped: the master switch is off.']
        : ($coreBad ? ['bad', 'A core host is down: everything holds.'] : null);
    $h .= '<div class="cb-top cb-strip" role="status">';
    if ($result) $h .= '<span class="cb-beacon cb-b-' . $result[0] . '">' . tv_cb_mark($result[0]) . $e($result[1]) . '</span>';
    // the worst real state (the session manager, 2026-11-18, against css-theme-brand.md): red only for a line really
    // tripped (tripped_at: the system tried and gave up) or a core host down; a line only held is amber with the pause mark
    $pfL = $pfOpen ? (array_filter($pfOpen, fn ($x) => $x['level'] === 'trip' && !empty($x['tripped_at'])) || $coreBad ? 'bad' : 'hold') : '';
    $h .= '<span class="cb-result cb-b-' . ($pfOpen ? $pfL : ($runAt ? 'ok' : 'off')) . '">' . tv_cb_mark($pfOpen ? $pfL : ($runAt ? 'ok' : 'new')) . '<span class="cb-rt"><b>Pre-flight, ' . ($runAt ? tv_cb_time($runAt) : 'not run yet') . ':</b> '
        . ($pfOpen ? '<a href="#cb-alarms" data-cb-go="cb-alarms" class="underline">' . count($pfNames) . ' held</a>: ' . implode(', ', array_slice(array_values($pfNames), 0, 3)) . (count($pfNames) > 3 ? ' and <a href="#cb-alarms" data-cb-go="cb-alarms" class="underline">' . (count($pfNames) - 3) . ' more</a>' : '') . '.' : ($runAt ? 'every line passed or is on a backup.' : 'press Run it again.'))
        . ($old ? ' <small class="cb-age">This result is over an hour old.</small>' : '') . '</span>'
        . '<span class="cb-ra"><a class="ak-b cb-xs" href="/admin/config/preflight" data-peek-frame>Open the report</a>' . $btn('preflight', 'Run it again', $canPf && !$staging, $staging ? $wNo : (string) $whyPf, '', ['class' => 'ak-b cb-xs']) . '</span></span>'
        . '<span class="cb-core"><b>Core hosts</b> ' . implode(' ', array_map(fn ($c) => '<span class="cb-ch">' . tv_cb_mark($c[1]) . $e($c[0]) . '</span>', $core)) . '</span></div>';

    // ---- the six stages, and where the system stands
    $h .= '<div class="cb-stages" role="list" aria-label="Stages">';
    $i = 0;
    foreach (ControlBoard::STAGES as $k => $label) {
        $i++; $soon = false;   // every stage is built (history: release 4b)
        $h .= '<div role="listitem" class="cb-st' . ($k === $stage ? ' on' : '') . ($soon ? ' soon' : '') . '"' . ($k === $stage ? ' aria-current="step"' : '') . ($soon ? ' title="Coming in the board\'s next release"' : '') . '><small>' . $i . ($soon ? ' · coming' : '') . '</small>' . $e($label) . '</div>';
    }
    $h .= '</div><p class="cb-stage" data-tv-status="' . ($stage === 'observe' ? 'ok' : 'info') . '" data-tv-label="' . $e(ControlBoard::STAGES[$stage]) . ':">' . $e($stageWords) . '</p>';

    // ---- the system's own controls; find, open all, close all
    $h .= '<div class="cb-bar"><div class="cb-acts">'
        . $btn('preflight', 'Run the pre-flight', $canPf && !$staging, $staging ? $wNo : $whyPf)
        . $btn('start', 'Start the system', $canRun && !$staging, $wNo, '', ['data-confirm' => 'Start the system? It confirms each workflow and task, then switches them on in order.', 'data-yes' => 'Start it'])
        . $btn('shutdown', 'Shut down in order', $canRun && !$staging, $wNo, '', ['data-confirm' => 'Shut the whole system down in order? The tasks, then the workflows in reverse order, then the master switch and the crawler\'s schedule. What\'s running finishes.', 'data-yes' => 'Shut it down'])
        . $btn('pauseall', 'Pause everything', $canRun && !$staging, $wNo, '', ['class' => 'ak-b cb-danger', 'data-confirm' => 'Pause everything at once? The emergency stop: the master switch off and the crawler\'s schedule removed.', 'data-yes' => 'Pause everything', 'data-danger' => '1'])
        . '</div><div class="cb-acts cb-find"><input type="search" class="ak-q" data-cb-filter placeholder="Find a process, need or source" aria-label="Find a process, need or source">'
        . '<button type="button" class="ak-b" data-cb-all="1">Open all</button><button type="button" class="ak-b" data-cb-all="0">Close all</button></div></div>';

    // ---- the queue: the alarm list, one row per issue (it replaces "Holding now": Jason, 2026-11-18, "does the system board
    // have a queue where issues can be found and addressed"); open on load whenever anything is open
    $h .= tv_cb_afilter();
    // a process whose check is red, with the part that holds it: Check and start again waits for it, greyed with the reason
    // (the session manager, 2026-11-19: never a silent restart)
    $redChecks = [];
    foreach ($res as $rid => $rr) if (($rr['s'] ?? '') === 'bad') { $hold = ''; foreach ((array) ($rr['extra']['parts'] ?? []) as [$pt, $ps]) if ($ps === 'bad') { $hold = (string) $pt; break; }
        $redChecks[(string) $rid] = ControlBoard::sentence($hold !== '' ? $hold : (string) ($rr['said'] ?? '')); }
    $h .= tv_cb_alarms($alarms, $ac, $names, $pid, $canPf, (string) $whyPf, $btn, $redChecks);
    $tms = ControlBoard::timings($pdo, $res); $slow = count(array_filter($tms, fn ($x) => $x[1] !== null && $x[3] === 'bad')); $untested = count(array_filter($tms, fn ($x) => $x[1] === null));
    $h .= '<div class="cb-panels"><details class="ak-card tv-bleed cb-panel" id="cb-times"><summary class="cb-ph"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($slow ? 'bad' : ($untested === count($tms) ? 'new' : 'ok')) . '<b>Query timings</b> <small>' . ($slow ? $slow . ' of ' . count($tms) . ' over its limit' : ($untested === count($tms) ? 'not run yet' : 'all ' . count($tms) . ' within their limits')) . '</small></summary><table class="cb-tt"><thead><tr><th>Query</th><th>Took</th><th><a class="underline" href="/admin/config/thresholds" title="Change a limit on Thresholds">Limit</a></th><th></th></tr></thead><tbody>';
    foreach ($tms as $k => [$what, $ms, $lim, $s, $at])
        $h .= '<tr><td>' . $e(preg_replace('/ \(.*$/', '', $what)) . '<br><small>' . $e((string) (preg_match('/\((.*)\)/', $what, $mm) ? $mm[1] : '')) . '</small></td><td class="cb-num">' . ($ms === null ? '—' : number_format($ms) . ' ms') . '</td><td class="cb-num">' . ($lim ? number_format($lim) . ' ms' : '—') . '</td><td>' . tv_cb_mark($ms === null ? 'new' : $s) . '</td></tr>';
    $h .= '</tbody></table><div class="cb-acts">' . $btn('timings', 'Re-test the four', $canPf, (string) $whyPf) . '<small class="ak-note">Read only; a slow one is noted and holds nothing.</small></div></details></div>';
    $h .= tv_cb_maintenance($pdo, $names, $btn, $canRun && !$staging, $wNo);
    $h .= tv_cb_logbook($pdo, $names, (bool) $can);

    // ---- the systems, each process a row in columns
    foreach (ControlRegister::SYSTEMS as $sk => $sname) {
        $rows = $by[$sk] ?? [];
        $n = array_count_values(array_column($rows, 'light'));
        $worst = !empty($n['bad']) ? 'bad' : (!empty($n['hold']) ? 'hold' : (!empty($n['warn']) ? 'warn' : (!empty($n['ok']) ? 'ok' : 'wait')));
        $sum = [];
        foreach (['ok' => 'working', 'bad' => 'tripped', 'hold' => 'held', 'warn' => 'on a backup', 'maint' => 'in maintenance', 'off' => 'off', 'wait' => 'not tested'] as $k => $w) if (!empty($n[$k])) $sum[] = $n[$k] . ' ' . $w;
        $h .= '<details class="ak-card tv-bleed cb-sys" id="cb-' . $e($sk) . '" data-cb-sys="' . $e($sk) . '">'   // closed on load, held or not (Jason, 2026-11-18): its header counts the held
            . '<summary class="cb-sh"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($worst) . '<h3 class="cb-title">' . $e($sname) . '</h3><small class="cb-sum">' . $e(implode(' · ', $sum)) . '</small></summary>'
            . '<div class="cb-sys-tr">' . tv_cb_kv('Trend', '<div class="cb-trend" data-cb-trend="sys:' . $e($sk) . '"><small class="ak-note">Opens with the system: its processes summed.</small></div>') . '</div>'   // the historian (0171 §6, 4b), loaded when the system opens
            . '<div class="cb-row cb-head" aria-hidden="true"><span></span><span></span><span>Process</span><span>Stage</span><span>Where it stands</span><span>Last 24 hours</span><span>Speed</span><span>OK</span><span></span></div>';
        foreach ($rows as $id => $p) {
            $c = $p['calls'];
            $needs = str_starts_with($id, 'wf:') ? ControlBoard::needs($res, (array) ($p['parts']['needs'] ?? [])) : [];
            $q = mb_strtolower($p['name'] . ' ' . $p['words'] . ' ' . implode(' ', array_map(fn ($x) => $x[0] . ' ' . implode(' ', array_column($x[2], 0)), $needs)));
            // its open alarms: a trip marks it red, and the alarm is where it stands
            $mine = array_values(array_filter($alarms, fn ($x) => $x['proc'] === $id && $x['cleared_at'] === null));
            if ($mine && $mine[0]['level'] === 'trip') $p['light'] = 'bad';
            $r = tv_cb_row($id, $p, $needs, $stage);
            if ($mine) $r['where'] = ControlAlarms::LEVELS[$mine[0]['level']] . ': ' . $mine[0]['title'] . (count($mine) > 1 ? ' (and ' . (count($mine) - 1) . ' more in the alarm list)' : '') . '.';   // switched on while the system is stopped: Standby, not Observation
            $h .= '<details class="cb-p" id="' . $e($pid($id)) . '" data-cb-p="' . $e($id) . '" data-q="' . $e($q) . '">'
                . '<summary class="cb-row"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($p['light'])
                . '<span class="cb-nm"><b class="cb-n">' . $e($p['name']) . '</b>' . ($r['sub'] !== '' ? '<small>' . $e($r['sub']) . '</small>' : '') . '</span>'
                . '<span class="cb-pill cb-pill-' . $e($r['stage'][0]) . '">' . $e($r['stage'][1]) . '</span>'
                . '<span class="cb-c">' . $e($r['where']) . (!empty($p['means']) ? ' <small class="cb-means">' . $e($p['means']) . '</small>' : '') . '</span>'
                . '<span class="cb-k' . ($r['runs'][0] === '—' ? ' cb-none0' : '') . '"><b>' . $e($r['runs'][0]) . '</b>' . ($r['runs'][1] !== '' ? '<small class="' . ($r['runs'][2] ? 'cb-good' : '') . '">' . $e($r['runs'][1]) . '</small>' : '') . '</span>'
                . '<span class="cb-k' . ($r['speed'][0] === '—' ? ' cb-none0' : '') . '"><b>' . $e($r['speed'][0]) . '</b>' . ($r['speed'][1] !== '' ? '<small>' . $e($r['speed'][1]) . '</small>' : '') . '</span>'
                . '<span class="cb-k cb-okr"><b>' . $e($r['ok']) . '</b></span>'
                . '<span class="cb-ra">' . tv_cb_controls($id, $p, $res, $btn, $canPf, (string) $whyPf, $canRun && !$staging, $wNo, true) . '</span></summary>'
                . '<div class="cb-b cb-l-' . $e($p['light']) . '">';
            // Route
            if ($p['route']) $h .= tv_cb_kv('Route', '<code class="cb-route">' . $e((string) $p['route']['said']) . '</code>');
            if ($mine) $h .= tv_cb_kv('Alarms', implode('<br>', array_map(fn ($x) => tv_cb_mark($x['level'] === 'trip' ? 'bad' : 'warn') . ' ' . $e($x['title']) . ' <small>(' . ControlAlarms::KINDS[$x['kind']] . ', ×' . (int) $x['n_times'] . ', since ' . tv_cb_time((int) strtotime($x['first_at'] . ' UTC')) . ')</small>', $mine)) . ' <a class="underline" href="#cb-alarms" data-cb-go="cb-alarms">The alarm list</a>');
            // Its check: one line, what holds it first; its parts on a toggle
            $h .= tv_cb_kv('Trend', '<div class="cb-trend" data-cb-trend="' . $e($id) . '"><small class="ak-note">Loads when the row opens.</small></div>');   // the historian (0171 §6, 4b)
            if ($p['line']) $h .= tv_cb_kv('Its check', tv_cb_check($p['line']));
            elseif (!str_starts_with($id, 'wk:') || ControlRegister::WORKERS[substr($id, 3)][3] !== '') $h .= tv_cb_kv('Its check', 'Not run yet: press Check.');
            // Needs, as chips
            if ($needs) $h .= tv_cb_kv('Needs', tv_cb_needs($needs, $canPf, (string) $whyPf));
            if (str_starts_with($id, 'svc:') && ($u = ControlBoard::usedBy(substr($id, 4)))) $h .= tv_cb_kv('Used by', $e(implode(', ', $u)) . '.');
            // Accounting: every one accounted for
            if ($c['calls']) {
                $rest = $c['received'] - ($c['stored'] + $c['updated'] + $c['review'] + $c['refused']);
                $h .= tv_cb_kv('Accounting', '<span class="cb-acct">Received <b>' . number_format($c['received']) . '</b> = Stored <b class="cb-good">' . number_format($c['stored']) . '</b> + Updated <b>' . number_format($c['updated']) . '</b> + To Review <b>' . number_format($c['review']) . '</b> + Refused <b>' . number_format($c['refused']) . '</b>'
                    . ($rest > 0 ? ' + No change <b>' . number_format($rest) . '</b>' : '') . ' <small>(' . number_format($c['calls']) . ' worker call' . ($c['calls'] === 1 ? '' : 's') . ', ' . $c['ms'] . ' ms each' . ($c['errors'] ? ', <b class="cb-bad">' . $c['errors'] . ' server error' . ($c['errors'] === 1 ? '' : 's') . '</b>' : '') . ')</small></span>');
            }
            if (!empty($c['last_error'])) { $le = $c['last_error'];
                $h .= tv_cb_kv('Last error', '<b class="cb-bad">' . $e('/api/' . $le['endpoint'] . ($le['code'] >= 500 ? ' answered ' . $le['code'] : ' set a record aside')) . ':</b> ' . $e((string) preg_replace('/^answered \d+: /', '', $le['said'])) . ' <small>' . tv_cb_time($le['at']) . '</small>'); }
            $runs = [];
            if ($p['outcomes']) foreach ($p['outcomes'] as $k => $v) $runs[] = $v . ' ' . str_replace('_', ' ', (string) $k);
            if ($p['jobs'][0] + $p['jobs'][1]) $runs[] = 'site jobs ' . $p['jobs'][0] . ' ran' . ($p['jobs'][1] ? ', ' . $p['jobs'][1] . ' stopped' : '');
            if ($runs) $h .= tv_cb_kv('Runs, 24 h', $e(implode(' · ', $runs)));
            $dry = ''; foreach ((array) ($p['line']['extra']['parts'] ?? []) as [$txt, $sst]) if (str_starts_with((string) $txt, 'Dry run: ')) $dry = (string) $txt;
            if ($dry !== '') $h .= tv_cb_kv('Dry run', $e(substr($dry, 9)));
            // Records touched lately
            $eps = $p['parts']['endpoints'] ?? [];
            if (str_starts_with($id, 'wk:')) { $k = substr($id, 3); $eps = ControlRegister::WORKERS[$k][2]; foreach (ControlRegister::ENDPOINTS as $ep => [, $for]) if (in_array('@' . $k, $for, true) || ($k === 'crawler' && !array_filter($for, fn ($f) => $f[0] === '@' || $f === 'W0'))) $eps[] = $ep; }
            $recs = ControlBoard::records($pdo, array_values(array_filter($eps, fn ($ep) => !in_array($ep, ['crawl/service', 'crawl/usage'], true))), 12);
            if ($recs) $h .= tv_cb_kv('Records touched lately', implode(' · ', array_map(fn ($r) => tv_cb_record_link((string) $r[0], (int) $r[1], (string) $r[2]), $recs)));
            if ($id === 'wk:crawler') {
                $rr = '';
                foreach (ControlBoard::runs($pdo, 5) as [$run, $calls, $rrs]) {
                    $sumc = ['stored' => 0, 'review' => 0, 'updated' => 0, 'refused' => 0]; foreach ($calls as $cl) foreach ($sumc as $k => $_) $sumc[$k] += (int) $cl['n_' . $k];
                    $rr .= '<details class="cb-run"><summary>Run #' . (int) $run['id'] . ' · ' . $e((string) $run['status']) . ' · ' . tv_cb_time((int) strtotime((string) $run['started_at'])) . ' · ' . count($calls) . ' calls: ' . $sumc['stored'] . ' stored, ' . $sumc['updated'] . ' updated, ' . $sumc['review'] . ' to Review, ' . $sumc['refused'] . ' refused</summary>'
                        . ($rrs ? '<p class="ak-note">' . implode(' · ', array_map(fn ($r) => tv_cb_record_link((string) $r['kind'], (int) $r['ref_id'], (string) $r['what']), $rrs)) . '</p>' : '<p class="ak-note">No records touched.</p>') . '</details>';
                }
                if ($rr !== '') $h .= tv_cb_kv('Its last runs', $rr);
            }
            // its controls, named in full
            $acts = tv_cb_controls($id, $p, $res, $btn, $canPf, (string) $whyPf, $canRun && !$staging, $wNo, false);
            if ($acts !== '') $h .= '<div class="cb-acts">' . $acts . '</div>';
            $h .= '</div></details>';
        }
        // the site: what it needs from outside, each with its sources
        if ($sk === 'site' && $siteNeeds) {
            $sn = array_count_values(array_column($siteNeeds, 1));
            $sl = !empty($sn['bad']) ? 'bad' : (!empty($sn['warn']) ? 'warn' : (!empty($sn['ok']) ? 'ok' : 'wait'));
            $h .= '<details class="cb-p" id="cb-p-site-needs" data-cb-p="site:needs" data-q="' . $e(mb_strtolower('what the site needs ' . implode(' ', array_map(fn ($x) => $x[0] . ' ' . implode(' ', array_column($x[2], 0)), $siteNeeds)))) . '">'
                . '<summary class="cb-row"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($sl) . '<span class="cb-nm"><b class="cb-n">What the site needs from outside</b><small>The site\'s own needs</small></span><span class="cb-pill cb-pill-' . $sl . '">' . ($sl === 'bad' ? 'Needs a look' : 'Working') . '</span><span class="cb-c">' . count($siteNeeds) . ' needs: ' . (int) ($sn['ok'] ?? 0) . ' answered first, ' . (int) ($sn['warn'] ?? 0) . ' on a backup or their fallback, ' . (int) ($sn['bad'] ?? 0) . ' with nothing working. None of them holds the engine.</span><span class="cb-k"><b>—</b></span><span class="cb-k"><b>—</b></span><span class="cb-k cb-okr"><b>—</b></span><span class="cb-ra"></span></summary>'
                . '<div class="cb-b cb-l-' . $sl . '">' . tv_cb_kv('Needs', tv_cb_needs($siteNeeds, $canPf, (string) $whyPf)) . '</div></details>';
        }
        $h .= '</details>';
    }

    // ---- the pre-flight, every line (its own section stays: /admin/config/preflight)
    $h .= '<details class="ak-card tv-bleed" id="preflight" style="margin-top:.6rem"><summary class="cb-sh"><span class="cb-caret" aria-hidden="true">▾</span><span></span><h3 class="cb-title">Pre-flight: every line, as tested last</h3></summary>'
        . '<p class="ak-note">The same lines as <a class="underline" href="/admin/config/preflight">Pre-flight</a>, with its Run all and each line\'s Test.</p>'
        . (function_exists('tv_admin_mod_preflight') ? tv_admin_mod_preflight($pdo) : '') . '</details>';
    $h .= '<div class="cb-none" hidden><p data-tv-status="info" data-tv-label="Nothing found:">No process, need or source has those words. Clear the box to see them all.</p></div></div>';

    $h .= '<style>'
        . '#cb .cb-m{display:inline-flex;width:1.35rem;height:1.35rem;border-radius:.3rem;align-items:center;justify-content:center;flex:0 0 auto;vertical-align:middle}#cb .cb-svg{width:.9rem;height:.9rem;fill:none;stroke:currentColor;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}'
        . '#cb summary{list-style:none;cursor:pointer}#cb summary::-webkit-details-marker{display:none}#cb details:not([open])>summary .cb-caret{display:inline-block;transform:rotate(-90deg)}#cb .cb-caret{color:#8a7a68;font-size:12px}'
        . '#cb .cb-strip{display:flex;flex-wrap:wrap;gap:.4rem .9rem;align-items:center;padding:.45rem .7rem;border:1px solid #E5D9C3;border-radius:.5rem;background:#F6F0E4;font-size:13px}'
        . '#cb .cb-beacon{display:inline-flex;gap:.4rem;align-items:center;font-weight:700;padding:.15rem .55rem .15rem .2rem;border-radius:.4rem}#cb .cb-b-ok{background:#E8F3EC;color:#15803D}#cb{--cb-fail:var(--tv-fail,#a62b2b);--cb-hold:var(--tv-hold,#8f5600);--cb-fail-bg:color-mix(in srgb,var(--cb-fail) 8%,#fff);--cb-fail-line:color-mix(in srgb,var(--cb-fail) 30%,#fff);--cb-hold-bg:color-mix(in srgb,var(--cb-hold) 11%,#fff);--cb-hold-line:color-mix(in srgb,var(--cb-hold) 35%,#fff);--cb-maint:var(--tv-maint,var(--tv-river,#3B5A6B));--cb-up:var(--tv-ok,#15803D);--cb-bar:var(--tv-copper,#B45309);--cb-none:var(--tv-line,#E5D9C3);--cb-maint-bg:color-mix(in srgb,var(--cb-maint) 10%,#fff);--cb-maint-line:color-mix(in srgb,var(--cb-maint) 32%,#fff)}#cb .cb-pill-maint{background:var(--cb-maint-bg);border-color:var(--cb-maint-line);color:var(--cb-maint)}#cb .cb-b.cb-l-maint{border-left-color:var(--cb-maint-line)}#cb .cb-sys-tr{padding:.3rem .8rem 0}#cb .cb-tr{display:grid;gap:.25rem;min-width:0}#cb .cb-trb{display:flex;gap:.25rem}#cb .cb-trb .on{background:var(--tv-sage,#8FBCA8);border-color:var(--tv-sage,#8FBCA8)}#cb .cb-trs{width:100%;max-width:32rem;height:3.4rem;display:block}#cb .cb-trw{margin:0;font-size:13px}#cb .cb-tre{margin:0;font-size:12.5px;color:#6b5d4f}#cb .cb-lg{display:grid;gap:.5rem;min-width:0}#cb .cb-lg>*{min-width:0;max-width:100%}#cb .cb-lgl{list-style:none;margin:0;padding:0;display:grid;gap:.3rem}#cb .cb-lgl li{display:flex;flex-wrap:wrap;gap:.2rem .55rem;align-items:baseline;padding:.3rem .5rem;border:1px solid #EFE6D6;border-radius:.4rem;background:#FFFDF8;min-width:0}#cb .cb-lgl time{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;color:#6b5d4f;white-space:nowrap}#cb .cb-lg-w{flex:1 1 14rem;min-width:0}#cb .cb-lg-w small,#cb .cb-lg-who{color:#6b5d4f}#cb .cb-lg-more,#cb .cb-lg-end{border:0 !important;background:none !important}#cb .cb-lg-n{display:flex;flex-wrap:wrap;gap:.4rem .6rem;align-items:flex-end}#cb .cb-lg-n label{display:flex;flex-direction:column;font-size:12.5px;color:#6b5d4f;min-width:0}#cb .cb-lg-n textarea,#cb .cb-lg-n select{font:inherit;font-size:13px;border:1px solid #E5D9C3;border-radius:.35rem;padding:.25rem .4rem;background:#FFFDF8;max-width:100%}#cb .cb-lg-n .cb-why{flex:1 1 16rem}#cb .cb-trw small{color:#6b5d4f}#cb .cb-mt{display:grid;gap:.5rem}#cb .cb-mt form{display:flex;flex-wrap:wrap;gap:.4rem .6rem;align-items:flex-end}#cb .cb-mt label{display:flex;flex-direction:column;font-size:12.5px;color:#6b5d4f;min-width:0}#cb .cb-mt input,#cb .cb-mt select{font:inherit;font-size:13px;border:1px solid #E5D9C3;border-radius:.35rem;padding:.2rem .4rem;background:#FFFDF8;max-width:100%}#cb .cb-mt .cb-why{flex:1 1 14rem}#cb .cb-ml,#cb .cb-up{list-style:none;margin:0;padding:0;display:grid;gap:.35rem}#cb .cb-ml li,#cb .cb-up li{display:flex;flex-wrap:wrap;gap:.2rem .6rem;align-items:baseline;padding:.35rem .5rem;border:1px solid #EFE6D6;border-radius:.4rem;background:#FFFDF8;min-width:0}#cb .cb-ml li>span,#cb .cb-up li>span{min-width:0}#cb .cb-up .cb-when{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px;min-width:9.5rem}#cb .cb-b-bad{background:var(--cb-fail-bg);color:var(--cb-fail)}#cb .cb-b-hold{background:var(--cb-hold-bg);color:var(--cb-hold)}#cb .cb-b-off{background:#F1EDE6;color:#6b5d4f}'
        . '#cb .cb-core{display:inline-flex;gap:.5rem;align-items:center;flex-wrap:wrap}#cb .cb-ch{display:inline-flex;gap:.25rem;align-items:center}#cb .cb-core .cb-m,#cb .cb-beacon .cb-m{width:1.1rem;height:1.1rem}#cb .cb-last{color:#6b5d4f;margin-left:auto}#cb .cb-means{display:block;color:#6b5d4f;font-size:12px}#cb .cb-result{display:flex;flex-wrap:wrap;gap:.3rem .6rem;align-items:center;padding:.25rem .5rem;border-radius:.4rem;flex:1 1 30rem}#cb .cb-result .cb-rt{flex:1 1 16rem}#cb .cb-afl{display:flex;gap:.5rem;align-items:center;margin:.2rem 0 .4rem}#cb .cb-dd select{font:inherit;font-size:13px;border:1px solid #E5D9C3;border-radius:.35rem;padding:.15rem .4rem;background:#FFFDF8}#cb .cb-am{display:grid;gap:.15rem;font-size:13px;margin-top:.2rem}#cb .cb-panels{grid-template-columns:1fr}'
        . '#cb .cb-stages{display:grid;grid-template-columns:repeat(6,1fr);gap:.35rem;margin:.6rem 0 .4rem}#cb .cb-st{border:1px solid #E5D9C3;border-radius:.4rem;padding:.4rem .55rem;font-size:13px;background:#FFFBF2}#cb .cb-st small{display:block;color:#8a7a68;font-size:11px}'
        . '#cb .cb-st.on{background:#E8F3EC;border-color:#8FBCA8;box-shadow:0 0 6px #8FBCA8;font-weight:600}#cb .cb-st.soon{opacity:.55}'
        . '#cb .cb-bar{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.4rem;margin:.5rem 0}#cb .cb-acts{display:flex;gap:.35rem;flex-wrap:wrap;align-items:center;margin:.4rem 0}#cb .cb-bar .cb-acts{margin:0}#cb .cb-find .ak-q{width:15rem;max-width:100%}'
        . '#cb .cb-danger{color:var(--cb-fail);border-color:var(--cb-fail-line)}#cb .cb-xs{padding:.15rem .5rem;font-size:12px;min-height:0}'
        . '#cb .cb-panels{display:grid;grid-template-columns:1fr;gap:.6rem;margin:.4rem 0 .6rem}#cb .cb-panel{padding:.6rem .8rem;margin:0}#cb .cb-ph{font-size:14px;display:flex;gap:.45rem;align-items:center;flex-wrap:wrap}#cb .cb-panel[open]>.cb-ph{margin:0 0 .4rem;padding-bottom:.3rem;border-bottom:1px solid #EFE6D6}#cb .cb-panels{align-items:start}#cb .cb-ph small{font-weight:400;color:#8a7a68;margin-left:.3rem}'
        . '#cb .cb-hl{list-style:none;margin:0;padding:0;display:grid;gap:.4rem}#cb .cb-hl li{display:flex;gap:.45rem;align-items:flex-start;font-size:13.5px}'
        . '#cb .cb-tt{width:100%;border-collapse:collapse;font-size:13px}#cb .cb-tt th{text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.03em;color:#8a7a68;padding:.2rem .3rem;border-bottom:1px solid #EFE6D6}#cb .cb-tt td{padding:.3rem;border-bottom:1px solid #F3ECE0;vertical-align:top}#cb .cb-tt small{color:#8a7a68}#cb .cb-num{white-space:nowrap;font-variant-numeric:tabular-nums}'
        . '#cb .cb-sys{margin:.0 0 .6rem;padding:0;overflow:hidden}#cb .cb-sh{display:flex;gap:.55rem;align-items:center;padding:.55rem .8rem;background:#F6F0E4}#cb .cb-title{margin:0;font-size:1.05rem;font-weight:700}#cb .cb-sum{margin-left:auto;color:#6b5d4f;text-align:right}'
        . '#cb .cb-row{display:grid;grid-template-columns:.9rem 1.35rem minmax(8rem,13rem) 6.6rem minmax(0,1fr) 9.5rem 6.5rem 3.6rem 10rem;gap:.2rem .7rem;align-items:center;padding:.5rem .8rem}#cb .cb-nm{display:flex;flex-direction:column}#cb .cb-nm small{color:#8a7a68;font-size:11.5px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}#cb .cb-pill{justify-self:start;font-size:11.5px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;padding:.12rem .45rem;border-radius:.3rem;border:1px solid;white-space:nowrap}#cb .cb-pill-ok{background:#E8F3EC;border-color:#B6D9C4;color:#14532D}#cb .cb-pill-bad{background:var(--cb-fail-bg);border-color:var(--cb-fail-line);color:var(--cb-fail)}#cb .cb-pill-hold{background:var(--cb-hold-bg);border-color:var(--cb-hold-line);color:var(--cb-hold)}#cb .cb-pill-off,#cb .cb-pill-new,#cb .cb-pill-warn,#cb .cb-pill-wait{background:#F6F0E4;border-color:#E5D9C3;color:#6b5d4f}#cb .cb-c{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}#cb .cb-k{display:flex;flex-direction:column;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px;font-variant-numeric:tabular-nums}#cb .cb-k b{font-weight:600}#cb .cb-k small{font-size:11.5px;color:#6b5d4f}#cb .cb-k small.cb-good{color:#15803D}#cb .cb-ra{display:flex;gap:.3rem;justify-content:flex-end}'
        . '#cb .cb-head{padding:.35rem .8rem;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#8a7a68;border-bottom:1px solid #EFE6D6;background:#FFFBF2}'
        . '#cb .cb-p{border-top:1px solid #EFE6D6}#cb .cb-p:first-of-type{border-top:0}#cb .cb-p>summary:hover{background:#FBF6EC}#cb .cb-c{font-size:13.5px;color:#4a3f35}#cb .cb-nc{color:#6b5d4f;white-space:nowrap}'
        . '#cb .cb-b{margin:0 .8rem .7rem 2.9rem;padding:.5rem .8rem;border-left:3px solid #8FBCA8;display:grid;gap:.4rem;background:#FAF5EA;border-radius:0 .4rem .4rem 0}#cb .cb-l-bad{border-left-color:var(--cb-fail)}#cb .cb-l-hold{border-left-color:var(--cb-hold-line)}#cb .cb-l-warn{border-left-color:var(--cb-hold-line)}#cb .cb-l-off,#cb .cb-l-wait,#cb .cb-l-na{border-left-color:#D6CBB8}'
        . '#cb .cb-kv{display:flex;flex-wrap:wrap;gap:.2rem .5rem;align-items:baseline;font-size:13.5px}#cb .cb-kd{flex:1 1 20rem;min-width:0}#cb .cb-lb{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;text-transform:uppercase;letter-spacing:.04em;color:#6b5d4f;white-space:nowrap}#cb .cb-chips{display:flex;flex-wrap:wrap;gap:.35rem}#cb .cb-chip{font:inherit;font-size:13px;padding:.2rem .55rem;border-radius:.35rem;border:1px solid #E5D9C3;background:#FFFDF8;color:#2b241d;cursor:pointer;text-align:left}#cb .cb-chip small{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;color:#6b5d4f}#cb .cb-chip-ok b,#cb .cb-chip-warn b{color:#15803D}#cb .cb-chip-bad{border-color:var(--cb-hold-line);background:var(--cb-hold-bg)}#cb .cb-chip-bad b{color:var(--cb-hold)}#cb .cb-chip-warn{border-color:var(--cb-hold-line)}#cb .cb-chip:hover{border-color:#B45309}#cb .cb-more>summary{font-size:12.5px;color:#92400E;text-decoration:underline;margin-top:.15rem}#cb .cb-rec{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px;color:#15803D}'
        . '#cb .cb-route{font-size:12.5px;background:#FFFBF2;border:1px solid #EFE6D6;border-radius:.3rem;padding:.15rem .45rem;display:inline-block;white-space:normal}'
        . '#cb .cb-parts{list-style:none;margin:.3rem 0 0;padding:0;display:grid;gap:.3rem}#cb .cb-parts li{display:flex;gap:.45rem;align-items:flex-start}#cb .cb-parts .cb-m{width:1.15rem;height:1.15rem;margin-top:.1rem}#cb .cb-alarms{margin:.4rem 0}#cb .cb-al{list-style:none;margin:.3rem 0 0;padding:0;display:grid;gap:.5rem}#cb .cb-al li{display:flex;gap:.5rem;align-items:flex-start;padding:.45rem .55rem;border:1px solid #EFE6D6;border-radius:.4rem;background:#FFFDF8}#cb .cb-al li.cb-al-trip{border-color:var(--cb-fail-line);background:var(--cb-fail-bg)}#cb .cb-al li.cb-al-warning{border-color:var(--cb-hold-line)}#cb .cb-al li.cb-al-grp{display:flex}#cb .cb-grp{flex:1 1 auto;min-width:0}#cb .cb-grp>summary{cursor:pointer;list-style:none}#cb .cb-grp>summary::-webkit-details-marker{display:none}#cb .cb-grp[open]>summary .cb-caret{transform:rotate(180deg)}#cb .cb-al-in{margin:.5rem 0 0}#cb .cb-al-in li{background:#fff}#cb .cb-al .cb-acts{margin:.3rem 0 0}#cb .cb-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;color:#6b5d4f}#cb .cb-b>*,#cb .cb-kd,#cb .cb-al li>div,#cb .cb-am>span{min-width:0}#cb .cb-al li>div{flex:1 1 auto}#cb .cb-ck{display:flex;gap:.35rem;align-items:flex-start;min-width:0}#cb .cb-ck>.cb-m{flex:none}#cb .cb-ck>.cb-tg,#cb .cb-ck>.cb-ckt{flex:1 1 auto;min-width:0}#cb .cb-tg{display:flex;gap:.3rem;align-items:flex-start;min-width:0;max-width:100%}#cb .cb-tgb{flex:none;display:inline-flex;align-items:center;justify-content:center;width:1.2rem;height:1.2rem;margin-top:.12rem;padding:0;border:1px solid #E5D9C3;border-radius:50%;background:#FFFDF8;color:#B45309;cursor:pointer;transition:transform .15s}#cb .cb-tgb:hover{border-color:#B45309}#cb .cb-tgt{flex:1 1 auto;min-width:0;overflow:hidden;white-space:nowrap;cursor:pointer;-webkit-mask-image:linear-gradient(90deg,#000 80%,transparent);mask-image:linear-gradient(90deg,#000 80%,transparent)}#cb .cb-tg.open .cb-tgb{transform:rotate(90deg)}#cb .cb-tg.open .cb-tgt{white-space:normal;-webkit-mask-image:none;mask-image:none}#cb .cb-old{display:block;color:#6b5d4f}#cb a{color:#92400E}#cb a.ak-b{color:inherit}#cb .cb-good{color:#15803D}#cb .cb-bad{color:var(--cb-fail)}#cb .cb-acct{font-variant-numeric:tabular-nums}#cb .cb-run>summary{font-size:13px;color:#4a3f35}'
        . '@media (max-width:900px){#cb .cb-panels{grid-template-columns:1fr}#cb .cb-stages{grid-template-columns:repeat(3,1fr)}#cb .cb-row{grid-template-columns:.9rem 1.35rem minmax(0,1fr) auto auto auto}#cb .cb-c{grid-column:3/-1;order:9}#cb .cb-head{display:none}}'
        . '@media (max-width:767px){#cb .cb-row{grid-template-columns:.9rem 1.35rem minmax(0,1fr) auto;padding:.5rem .6rem;row-gap:.3rem}#cb .cb-pill{grid-column:4;grid-row:1;justify-self:end}#cb .cb-c,#cb .cb-k,#cb .cb-ra{grid-column:3/-1}#cb .cb-c{order:0}#cb .cb-k{flex-direction:row;gap:.4rem;flex-wrap:wrap}#cb .cb-okr{display:none}#cb .cb-none0{display:none}#cb .cb-ra{justify-content:flex-start}#cb .cb-head{display:none}#cb .cb-b{margin:0 .4rem .6rem .4rem}#cb .cb-sh{flex-wrap:wrap;padding:.5rem .6rem}#cb .cb-sum{margin-left:0;flex-basis:100%;text-align:left}#cb .cb-last{margin-left:0}#cb .cb-find .ak-q{flex:1 1 100%;width:auto}}'
        . '</style>'
        . '<script src="/js/tv-time.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/tv-time.js') . '" defer></script>'
        . '<script src="/js/admin-control.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/admin-control.js') . '" defer></script>';
    return $h;
}
