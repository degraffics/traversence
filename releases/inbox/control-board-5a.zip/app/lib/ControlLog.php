<?php
// app/lib/ControlLog.php — the System Control Board's logbook (decisions/0171 §10, release 5a): every stage change,
// switch, control, alarm and acknowledgement, with who and why, newest first, filtered by system or process.
//   - New, in control_log: alarms raised, acknowledged, cleared and resolved; shut-downs, starts and maintenance; each
//     control pressed on the board; an operator's own note ("Log an entry"). Each keeps the device's time zone.
//   - Read where it is already kept: automation_log (switches), Start's sessions, preflight_runs, service issues opened
//     and resolved, job_runs failures, and releases going live (site_releases).
// "Who" is a staff member's name or "the system", never a member's: an action of a member's is logged by its kind only
// (the session manager's guard, 2026-11-19). Staging class: own (each site keeps its own log).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class ControlLog
{
    /** What an entry is: kind => its word on the log. */
    public const KINDS = ['alarm' => 'Alarm', 'ack' => 'Acknowledged', 'clear' => 'Cleared', 'resolve' => 'Resolved', 'control' => 'Control',
        'stop' => 'Shut down', 'start' => 'Started', 'maint' => 'Maintenance', 'note' => 'Note', 'switch' => 'Switch', 'session' => 'Start the system',
        'preflight' => 'Pre-flight', 'issue' => 'Outside service', 'job' => 'Site job', 'release' => 'Release'];
    private static bool $ready = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $pdo->exec("CREATE TABLE IF NOT EXISTS control_log (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, at DATETIME NOT NULL, tz VARCHAR(64) NOT NULL DEFAULT '',
            kind VARCHAR(20) NOT NULL, proc VARCHAR(60) NOT NULL DEFAULT '', what VARCHAR(400) NOT NULL, who VARCHAR(80) NOT NULL DEFAULT 'the system', why VARCHAR(400) NOT NULL DEFAULT '',
            KEY at (at), KEY proc_at (proc, at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        self::$ready = true;
    }

    /** One entry. $who: a staff member's name, else "the system". Never throws: a log that fails mustn't stop what it records. */
    public static function add(PDO $pdo, string $kind, string $proc, string $what, string $who = '', string $why = '', string $tz = ''): void
    {
        try {
            self::ensure($pdo);
            $tz = preg_match('~^[A-Za-z_]+(?:/[A-Za-z0-9_+\-]+){0,2}$~', $tz) ? $tz : '';
            $pdo->prepare('INSERT INTO control_log (at, tz, kind, proc, what, who, why) VALUES (UTC_TIMESTAMP(), ?, ?, ?, ?, ?, ?)')
                ->execute([$tz, isset(self::KINDS[$kind]) ? $kind : 'control', mb_substr($proc, 0, 60), mb_substr(trim($what), 0, 400), mb_substr(trim($who) !== '' ? trim($who) : 'the system', 0, 80), mb_substr(trim($why), 0, 400)]);
        } catch (Throwable $x) { error_log('control log: ' . $x->getMessage()); }
    }

    /** "Log an entry": an operator's own note, on the system or one process. Returns words for the page's notice. */
    public static function note(PDO $pdo, string $proc, string $text, string $who, string $tz): string
    {
        $text = trim($text);
        if (mb_strlen($text) < 3) throw new RuntimeException('Write the entry first: what happened, or what you did.');
        if ($who === '') throw new RuntimeException('Only a staff member can log an entry.');
        self::add($pdo, 'note', $proc, $text, $who, '', $tz);
        return 'Logged' . ($proc !== '' ? ' on ' . $proc : '') . '.';
    }

    /**
     * The log, newest first: [at (unix), tz, kind, proc, what, who, why]. $scope: '' everything, 'sys:<key>' one system,
     * or one process ('wf:W1'). $before: entries older than this moment (Show older). Never throws: a source that can't be
     * read is left out.
     */
    public static function feed(PDO $pdo, string $scope = '', int $before = 0, int $n = 50): array
    {
        $before = $before ?: time() + 60; $n = max(1, min(200, $n));
        $b = gmdate('Y-m-d H:i:s', $before); $out = [];
        $q = function (string $sql, array $args = []) use ($pdo): array { try { $st = $pdo->prepare($sql); $st->execute($args); return $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $x) { return []; } };
        $ts = fn ($d) => (int) strtotime((string) $d . ' UTC');
        try { self::ensure($pdo); } catch (Throwable $x) {}
        foreach ($q('SELECT at, tz, kind, proc, what, who, why FROM control_log WHERE at < ? ORDER BY at DESC, id DESC LIMIT ' . $n, [$b]) as $r)
            $out[] = [$ts($r['at']), (string) $r['tz'], (string) $r['kind'], (string) $r['proc'], (string) $r['what'], (string) $r['who'], (string) $r['why']];
        // switches (Automation's own log): a workflow, a service, a task, or the master switch
        foreach ($q('SELECT at, kind, ref, paused, why, by_name FROM automation_log WHERE at < ? ORDER BY at DESC LIMIT ' . $n, [$b]) as $r) {
            $k = (string) $r['kind']; $ref = (string) $r['ref'];
            $proc = $k === 'workflow' ? 'wf:' . $ref : ($k === 'service' ? 'svc:' . $ref : ($k === 'task' ? 't:' . $ref : ''));
            $out[] = [$ts($r['at']), '', 'switch', $proc, ($k === 'master' ? 'The master switch' : ucfirst($k) . ' ' . $ref) . ((int) $r['paused'] ? ' paused' : ' switched on'), (string) ($r['by_name'] ?: 'the system'), (string) $r['why']];
        }
        // Start the system's sessions
        try { require_once __DIR__ . '/SearchIndex.php'; require_once __DIR__ . '/SystemStart.php';
            $ss = (array) json_decode((string) SearchIndex::state($pdo, SystemStart::SESSIONS), true);
            $cur = SystemStart::state($pdo); if (!empty($cur['run'])) $ss[] = SystemStart::session($cur);
            foreach ($ss as $s) if ((int) ($s['run'] ?? 0) > 0 && (int) $s['run'] < $before) $out[] = [(int) $s['run'], '', 'session', '', 'Start the system: ' . SystemStart::runLabel($s), (string) (($s['by'] ?? '') ?: 'the system'), ''];
        } catch (Throwable $x) {}
        foreach ($q('SELECT finished, by_name, counts FROM preflight_runs WHERE finished < ? ORDER BY finished DESC LIMIT ' . $n, [$b]) as $r)
            $out[] = [$ts($r['finished']), '', 'preflight', '', 'The pre-flight ran: ' . (string) $r['counts'], (string) ($r['by_name'] ?: 'the system'), ''];
        foreach ($q('SELECT id, service, host, kind, first_at FROM service_issues WHERE first_at < ? ORDER BY first_at DESC LIMIT ' . $n, [$b]) as $r)
            $out[] = [$ts($r['first_at']), '', 'issue', 'svc:' . $r['service'], 'Issue #' . (int) $r['id'] . ' opened: ' . $r['host'] . ' (' . $r['kind'] . ')', 'the system', ''];
        foreach ($q("SELECT id, service, host, resolved_at, resolved_how FROM service_issues WHERE state = 'resolved' AND resolved_at < ? ORDER BY resolved_at DESC LIMIT " . $n, [$b]) as $r)
            $out[] = [$ts($r['resolved_at']), '', 'issue', 'svc:' . $r['service'], 'Issue #' . (int) $r['id'] . ' resolved: ' . $r['host'], 'the system', (string) $r['resolved_how']];
        foreach ($q('SELECT job, started_at, note FROM ' . Database::t('job_runs') . ' WHERE ok = 0 ORDER BY id DESC LIMIT ' . $n) as $r) {
            $at = (int) strtotime((string) $r['started_at']); if ($at >= $before) continue;
            $out[] = [$at, '', 'job', 'job:' . $r['job'], 'The job "' . $r['job'] . '" stopped with a problem', 'the system', (string) $r['note']];
        }
        foreach ($q("SELECT id, title, live_at, tz FROM site_releases WHERE state = 'live' AND live_at IS NOT NULL ORDER BY live_at DESC LIMIT " . $n) as $r) {
            $at = (int) strtotime((string) $r['live_at']); if ($at >= $before) continue;
            $out[] = [$at, (string) $r['tz'], 'release', '', 'Release #' . (int) $r['id'] . ' live: ' . $r['title'], 'the system', ''];
        }
        if ($scope !== '') {
            // a system is the board's own grouping (the unit register), so the log shows what its system shows
            $sysOf = []; if (str_starts_with($scope, 'sys:')) { try { require_once __DIR__ . '/ControlRegister.php'; foreach (ControlRegister::processes($pdo) as $pid => $p) $sysOf[$pid] = $p[0]; } catch (Throwable $x) {} }
            $out = array_values(array_filter($out, fn ($e) => str_starts_with($scope, 'sys:') ? ($e[3] !== '' && ($sysOf[$e[3]] ?? '') === substr($scope, 4)) : $e[3] === $scope));
        }
        usort($out, fn ($a, $b2) => $b2[0] <=> $a[0]);
        return array_slice($out, 0, $n);
    }
}
