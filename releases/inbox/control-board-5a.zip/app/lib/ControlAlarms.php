<?php
// app/lib/ControlAlarms.php — the System Control Board's annunciator (decisions/0171 §5, §7; release 3a). One alarm list
// for the whole system, by level: a trip (stopped, crashed, can't run what's switched on), a warning (slow, retrying,
// near a limit, a wrong count) or a notice. An alarm is raised the moment its reading goes wrong (the ledger, a crawler
// run's report, a service failing; silence by the 5-minute watch), and the same problem again updates the open alarm,
// never a second. A warning or notice clears by itself when its reading is good again, saying how. A trip doesn't (Jason,
// 2026-11-18, release 3c): a crash is first a warning while the system tries its own fix (control_fix_tries, or
// control_fix_minutes, whichever comes first); then it's a trip: the Founder is emailed, its Pulse item goes to the
// Director's level, what it holds is stopped (as narrow as its cause: one workflow, task or service; the master switch only
// when the crawler itself is down), and only an executive's Resolve clears it, starting again what it stopped once its check
// passes, with Undo. A refusal or running out of budget trips at once. Acknowledging stops the repeat email. A trip is emailed to the Founder at once through the one dispatcher
// (Notify::send, kind alarm.trip, decisions/0172); a warning still unacknowledged after 24 hours, as alarm.warning.
// Ids, words and readings only: nothing about a person.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class ControlAlarms
{
    public const LEVELS = ['trip' => 'Trip', 'warning' => 'Warning', 'notice' => 'Notice'];
    /** What kind of problem (0171 §5's table). */
    public const KINDS = ['slow' => 'Slow', 'retry' => 'Retrying', 'crash' => 'Crashed', 'held' => 'Held or out', 'limit' => 'Near a limit',
                          'count' => 'Wrong count', 'silent' => 'Gone quiet', 'check' => 'Its check'];
    private const RANK = ['notice' => 0, 'warning' => 1, 'trip' => 2];
    /** Kinds with nothing the system can try: a refusal, a key refused, a quota or budget used up. They trip at once. */
    public const AT_ONCE = ['held', 'limit'];
    private static bool $ready = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $pdo->exec("CREATE TABLE IF NOT EXISTS control_alarms (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            akey VARCHAR(120) NOT NULL, proc VARCHAR(60) NOT NULL DEFAULT '', level VARCHAR(10) NOT NULL, kind VARCHAR(12) NOT NULL,
            title VARCHAR(200) NOT NULL, means VARCHAR(400) NOT NULL DEFAULT '', todo VARCHAR(400) NOT NULL DEFAULT '', reading VARCHAR(255) NOT NULL DEFAULT '',
            fix VARCHAR(400) NOT NULL DEFAULT '', n_times INT UNSIGNED NOT NULL DEFAULT 1, first_at DATETIME NOT NULL, last_at DATETIME NOT NULL,
            ack_uid INT UNSIGNED NULL, ack_name VARCHAR(80) NULL, ack_at DATETIME NULL, cleared_at DATETIME NULL, cleared_how VARCHAR(255) NULL,
            mailed_at DATETIME NULL, tripped_at DATETIME NULL, good_at DATETIME NULL, good_how VARCHAR(255) NULL, stopped VARCHAR(400) NULL,
            resolved_uid INT UNSIGNED NULL, resolved_name VARCHAR(80) NULL, resolved_at DATETIME NULL, resolve_note VARCHAR(400) NULL, KEY open_key (akey, cleared_at), KEY proc (proc), KEY cleared (cleared_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        self::$ready = true;
    }

    /** The board's process an endpoint serves: its workflow (a task named there counts as its task's workflow) or its worker. */
    public static function procOfEndpoint(PDO $pdo, string $ep): string
    {
        require_once __DIR__ . '/ControlRegister.php';
        $f = (string) (((array) (ControlRegister::ENDPOINTS[$ep][1] ?? []))[0] ?? '');
        if ($f === '') return 'ep:' . $ep;
        if ($f[0] === '@') return 'wk:' . substr($f, 1);
        if (preg_match('/^W\d+$/', $f)) return 'wf:' . $f;
        try { $wf = (string) (ControlRegister::taskWorkflows($pdo)[$f] ?? ''); if ($wf !== '') return 'wf:' . $wf; } catch (Throwable $x) {}
        return 't:' . $f;
    }

    /** The open alarm with this key, or null. */
    /** An open alarm's words brought up to date (its title, and its reading when given), nothing else. Never throws. */
    public static function retitle(PDO $pdo, string $key, string $title, ?string $reading = null): void
    {
        try {
            self::ensure($pdo);
            $o = self::openOf($pdo, $key);
            if (!$o || ((string) $o['title'] === $title && ($reading === null || (string) $o['reading'] === $reading))) return;
            $pdo->prepare('UPDATE control_alarms SET title = ?' . ($reading !== null ? ', reading = ?' : '') . ' WHERE id = ?')
                ->execute(array_merge([mb_substr($title, 0, 200)], $reading !== null ? [mb_substr($reading, 0, 255)] : [], [(int) $o['id']]));
        } catch (Throwable $x) { error_log('control alarm retitle ' . $key . ': ' . $x->getMessage()); }
    }

    public static function openOf(PDO $pdo, string $key): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM control_alarms WHERE akey = ? AND cleared_at IS NULL ORDER BY id DESC LIMIT 1'); $st->execute([$key]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Raises an alarm, or updates the open one with the same key (its count, last seen, words, and a higher level if it
     * got worse). $fix: [label, action, id] a button the board and Pulse press in place ('' none), or a list of them.
     * $event false: a reading still bad, said again (a cap, a red line, a quiet worker): last seen moves, the count doesn't.
     * Returns its id. Never throws: a failing alarm must not break what raised it.
     */
    public static function raise(PDO $pdo, string $key, string $proc, string $level, string $kind, string $title, string $means = '', string $todo = '', string $reading = '', array $fix = [], bool $event = true, bool $tryFirst = true): int
    {
        try {
            self::ensure($pdo);
            $level = isset(self::LEVELS[$level]) ? $level : 'warning'; $kind = isset(self::KINDS[$kind]) ? $kind : 'check';
            // slow is never a trip (Jason, 2026-11-19: "no dead ends, system fixes first"): a slow call or job does less, it
            // isn't broken; stopping it made it do nothing. A warning that says how slow and clears itself when speed returns.
            if ($kind === 'slow' && $level === 'trip') $level = 'warning';
            // in maintenance (0171 §2.5, release 4a): what it raises is a notice, saying so; a trip already open stays a trip
            if ($level !== 'notice' && !str_starts_with($key, 'maint:')) {
                require_once __DIR__ . '/ControlMaintenance.php';
                $mt = ControlMaintenance::outFor($pdo, $proc);
                if ($mt) { $level = 'notice'; $means = trim(ControlMaintenance::words($mt) . '. ' . $means); }
            }
            // the system tries first (0171 §5, Jason 2026-11-18): a trip asked for is a warning until its tries or its time run out
            if ($level === 'trip' && $tryFirst && !in_array($kind, self::AT_ONCE, true)) {
                $o0 = self::openOf($pdo, $key);
                if (!$o0 || $o0['level'] !== 'trip') {
                    [$max, $mins] = self::limits($pdo, $kind);
                    $tries = $o0 ? (int) $o0['n_times'] + ($event ? 1 : 0) : 1;
                    $since = $o0 ? (int) strtotime($o0['first_at'] . ' UTC') : time();
                    if ($tries < $max && time() - $since < $mins * 60) {
                        $level = 'warning';
                        $means = trim($means . ' The system is trying again by itself (' . $tries . ' of ' . $max . ' tries, until ' . gmdate('H:i', $since + $mins * 60) . ' UTC); if that doesn\'t fix it, it\'s a trip for an admin.');
                    }
                }
            }
            $cut = fn (string $s, int $n) => mb_substr(trim($s), 0, $n);
            $fx = $fix ? json_encode(isset($fix[0]) && is_array($fix[0]) ? array_slice($fix, 0, 4) : array_slice($fix, 0, 4), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';   // one button [label, action, id(, confirm|ask)], or a list of them
            // the column holds 400: whole buttons are dropped from the end, never a cut that breaks the list
            while (mb_strlen($fx) > 400 && isset($fix[0]) && is_array($fix[0]) && count($fix) > 1) { array_pop($fix); $fx = json_encode(array_slice($fix, 0, 4), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); }
            if (mb_strlen($fx) > 400) $fx = '';
            $o = self::openOf($pdo, $key);
            if ($o) {
                // worse goes up; a trip raised before 3c's rule (no tripped_at) takes the level it's read at now
                $lv = self::RANK[$level] > self::RANK[(string) $o['level']] || ($o['level'] === 'trip' && empty($o['tripped_at'])) ? $level : (string) $o['level'];
                $pdo->prepare('UPDATE control_alarms SET n_times = n_times + ' . ($event ? 1 : 0) . ', last_at = UTC_TIMESTAMP(), level = ?, title = ?, means = ?, todo = ?, reading = ?, fix = ? WHERE id = ?')
                    ->execute([$lv, $cut($title, 200), $cut($means, 400), $cut($todo, 400), $cut($reading, 255), mb_substr($fx, 0, 400), (int) $o['id']]);
                if ($lv === 'trip' && $o['level'] !== 'trip') self::tripped($pdo, (int) $o['id']);   // it got worse: a trip now
                return (int) $o['id'];
            }
            $pdo->prepare('INSERT INTO control_alarms (akey, proc, level, kind, title, means, todo, reading, fix, first_at, last_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())')
                ->execute([$cut($key, 120), $cut($proc, 60), $level, $kind, $cut($title, 200), $cut($means, 400), $cut($todo, 400), $cut($reading, 255), mb_substr($fx, 0, 400)]);
            $id = (int) $pdo->lastInsertId();
            if (!str_starts_with($key, 'maint:')) self::log($pdo, 'alarm', $proc, self::LEVELS[$level] . ': ' . $cut($title, 200), '', $cut($means, 300));   // the logbook (0171 §10, 5a); maintenance logs itself
            if ($level === 'trip') self::tripped($pdo, $id);
            return $id;
        } catch (Throwable $x) { error_log('control alarm ' . $key . ': ' . $x->getMessage()); return 0; }
    }

    /**
     * Its reading is good again: a warning or notice clears, saying how. A trip doesn't clear by itself (0171 §7's note,
     * Jason 2026-11-18): it notes that its reading is good and waits for an admin's Resolve. A trip raised before that rule
     * (no tripped_at) still clears as it did. Returns whether one cleared. Never throws.
     */
    public static function clear(PDO $pdo, string $key, string $how): bool
    {
        try {
            self::ensure($pdo);
            $o = self::openOf($pdo, $key);
            if (!$o) return false;
            if ($o['level'] === 'trip' && !empty($o['tripped_at'])) {
                if (empty($o['good_at'])) $pdo->prepare('UPDATE control_alarms SET good_at = UTC_TIMESTAMP(), good_how = ? WHERE id = ?')->execute([mb_substr($how, 0, 255), (int) $o['id']]);
                return false;
            }
            return self::close($pdo, (int) $o['id'], $how);
        } catch (Throwable $x) { error_log('control alarm clear ' . $key . ': ' . $x->getMessage()); return false; }
    }

    /** Closed by a person's own act on its cause (Mark resolved, Reactivate): any level, trips included. */
    public static function closeKey(PDO $pdo, string $key, string $how): bool
    {
        $o = self::openOf($pdo, $key);
        return $o ? self::close($pdo, (int) $o['id'], $how) : false;
    }

    private static function close(PDO $pdo, int $id, string $how): bool
    {
        $st = $pdo->prepare('UPDATE control_alarms SET cleared_at = UTC_TIMESTAMP(), cleared_how = ? WHERE id = ? AND cleared_at IS NULL');
        $st->execute([mb_substr($how, 0, 255), $id]);
        $ok = $st->rowCount() > 0;
        if ($ok && ($a = self::byId($pdo, $id)) && !str_starts_with((string) $a['akey'], 'maint:')) self::log($pdo, 'clear', (string) $a['proc'], 'Cleared: ' . (string) $a['title'], '', $how);
        return $ok;
    }

    /** One line in the board's logbook (ControlLog, 0171 §10, release 5a). Never throws. */
    private static function log(PDO $pdo, string $kind, string $proc, string $what, string $who = '', string $why = ''): void
    {
        try { require_once __DIR__ . '/ControlLog.php'; ControlLog::add($pdo, $kind, $proc, $what, $who, $why); } catch (Throwable $x) {}
    }

    /** [tries, minutes] before a problem the system is fixing becomes a trip (slow has its own count). */
    public static function limits(PDO $pdo, string $kind): array
    {
        $g = function (string $k, int $d) use ($pdo): int { try { require_once __DIR__ . '/Thresholds.php'; $v = Thresholds::get($pdo, $k); return $v === null ? $d : max(1, (int) $v); } catch (Throwable $x) { return $d; } };
        return [$kind === 'slow' ? $g('control_slow_trips', 3) : $g('control_fix_tries', 3), $g('control_fix_minutes', 60)];
    }

    // ---- a trip: to an admin, and what it holds stopped -----------------------------------------------------------

    private const BY = 'the Control Board (a trip)';

    /**
     * It's a trip now: the Founder is emailed at once (§7), its Pulse item goes to the Director's level, and what it holds
     * is stopped, as narrow as its cause. What was stopped is kept, so Resolve starts only that again.
     */
    private static function tripped(PDO $pdo, int $id): void
    {
        try {
            $pdo->prepare('UPDATE control_alarms SET tripped_at = UTC_TIMESTAMP() WHERE id = ? AND tripped_at IS NULL')->execute([$id]);
            $a = self::byId($pdo, $id);
            if (!$a) return;
            $stopped = self::stop($pdo, $a);
            $pdo->prepare('UPDATE control_alarms SET stopped = ? WHERE id = ?')->execute([$stopped ? mb_substr(json_encode($stopped, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), 0, 400) : null, $id]);
            try { require_once __DIR__ . '/Pulse.php'; Pulse::escalateTo($pdo, 'alarm:' . $id, 2, 'A trip: the system couldn\'t fix it itself. The Founder was emailed; it waits for an admin\'s Resolve.'); } catch (Throwable $x) { error_log('trip pulse: ' . $x->getMessage()); }
        } catch (Throwable $x) { error_log('control trip ' . $id . ': ' . $x->getMessage()); }
        self::mail($pdo, $id);
    }

    public static function byId(PDO $pdo, int $id): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM control_alarms WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * What a trip stops (Jason, 2026-11-18; playbook §2, a hold as narrow as its cause), each [what, ref, words]:
     * a workflow (its tasks first, the board's Shut down), a task, an outside service out of budget, a service issue held
     * until resolved, W0 Indexer; the master switch only when the crawler itself is down (a run that failed outright or
     * never reported). A site job not tied to a workflow can't be stopped from here: it only trips. Only what was on.
     */
    public static function stop(PDO $pdo, array $a): array
    {
        $proc = (string) $a['proc']; $key = (string) $a['akey']; $out = [];
        require_once __DIR__ . '/Automation.php';
        try {
            if (in_array($key, ['run:failed', 'silent:run'], true)) {   // the crawler itself is down
                if (Automation::master($pdo) === null) { Automation::set($pdo, 'master', 'all', true, 'A trip on the Control Board: ' . $a['title'], 0, self::BY); $out[] = ['master', 'all', 'All gathering (the master switch)']; }
                return $out;
            }
            if (preg_match('/^svc:issue:(\d+)$/', $key, $m) || $key === 'svc:osm:held') {   // its calls already wait for Mark resolved; a back-off is held too
                if (isset($m[1])) { require_once __DIR__ . '/ServiceHealth.php'; if (ServiceHealth::holdForTrip($pdo, (int) $m[1])) $out[] = ['issue', $m[1], 'Calls to it']; }
                return $out;
            }
            if (str_starts_with($key, 'ops:cap:') && str_starts_with($proc, 'svc:')) {
                $svc = substr($proc, 4);
                if (Automation::serviceOff($pdo, $svc) === null) { try { Automation::set($pdo, 'service', $svc, true, 'Out of budget (a trip on the Control Board)', 0, self::BY); $out[] = ['service', $svc, 'Its automatic calls']; } catch (Throwable $x) {} }
                return $out;
            }
            $pid = $proc === 'wk:w0-indexer' ? 'wf:W0' : $proc;
            if (str_starts_with($pid, 'job:')) {   // a job tied to workflows stops them; any other site job only trips
                $wfs = Automation::JOBS[substr($pid, 4)] ?? []; if (!$wfs) return $out;
                $pid = 'wf:' . $wfs[0];
            }
            if (str_starts_with($pid, 'wf:') && Automation::wfOff($pdo, substr($pid, 3)) === null) {
                require_once __DIR__ . '/ControlBoard.php'; ControlBoard::stopOne($pdo, $pid, 0, self::BY); $out[] = ['proc', $pid, substr($pid, 3) . ' (its tasks first, then the workflow)'];
            } elseif (str_starts_with($pid, 't:')) {
                require_once __DIR__ . '/SystemStart.php'; $d = SystemStart::TASKS[substr($pid, 2)] ?? null;
                if ($d && $d[4]) { require_once __DIR__ . '/ControlBoard.php'; ControlBoard::stopOne($pdo, $pid, 0, self::BY); $out[] = ['proc', $pid, (string) $d[0]]; }
            }
        } catch (Throwable $x) { error_log('control trip stop ' . $key . ': ' . $x->getMessage()); }
        return $out;
    }

    /**
     * An admin resolves a trip (executive and above; starting again needs Automation's permission, checked by the caller):
     * what fixed it is kept; what the trip stopped starts again only once its check passes. A check still red: the trip
     * stays open with that reason on its row. Returns [ok, words].
     */
    public static function resolve(PDO $pdo, int $id, int $uid, string $who, string $note): array
    {
        $a = self::byId($pdo, $id);
        if (!$a || $a['cleared_at'] !== null) return [false, 'It isn\'t open any more.'];
        $note = trim($note);
        if ($note === '') $note = 'Checked and started again';   // never a question to get past (Jason, 2026-11-19): the system checks, then starts
        $started = []; $fail = '';
        foreach ((array) json_decode((string) ($a['stopped'] ?? ''), true) as [$what, $ref, $words]) {
            try {
                if ($what === 'proc') { require_once __DIR__ . '/ControlBoard.php'; ControlBoard::startOne($pdo, (string) $ref, $uid, $who); }
                elseif ($what === 'master') { require_once __DIR__ . '/Automation.php'; Automation::set($pdo, 'master', 'all', false, 'Trip resolved: ' . $note, $uid, $who); }
                elseif ($what === 'service') { require_once __DIR__ . '/Automation.php'; Automation::set($pdo, 'service', (string) $ref, false, 'Trip resolved: ' . $note, $uid, $who); }
                else continue;   // a held issue's calls start again with its resolve, below
                $started[] = (string) $words;
            } catch (Throwable $x) { $fail = (string) $words . ': ' . $x->getMessage(); break; }
        }
        if ($fail !== '') {
            $why = 'Not resolved at ' . gmdate('H:i') . ' UTC by ' . $who . ': ' . $fail;
            $pdo->prepare('UPDATE control_alarms SET resolve_note = ? WHERE id = ?')->execute([mb_substr($why, 0, 400), $id]);
            return [false, $why . ($started ? ' (' . implode(', ', $started) . ' started again first.)' : '')];
        }
        // its cause, closed by the person too: an outside service's issue, or every Overpass server held
        try {
            require_once __DIR__ . '/ServiceHealth.php';
            if (preg_match('/^svc:issue:(\d+)$/', (string) $a['akey'], $m)) ServiceHealth::resolve($pdo, (int) $m[1], $uid, 'Resolved on the Control Board by ' . $who . ': ' . $note);
            if ($a['akey'] === 'svc:osm:held') foreach (ServiceHealth::openAll($pdo) as $i) if ($i['service'] === 'osm') ServiceHealth::resolve($pdo, (int) $i['id'], $uid, 'Resolved on the Control Board by ' . $who . ': ' . $note);
        } catch (Throwable $x) {}
        $how = 'Resolved by ' . $who . ': ' . $note . ($started ? ' Started again: ' . implode(', ', $started) . '.' : '');
        $pdo->prepare('UPDATE control_alarms SET cleared_at = UTC_TIMESTAMP(), cleared_how = ?, resolved_uid = ?, resolved_name = ?, resolved_at = UTC_TIMESTAMP(), resolve_note = ? WHERE id = ? AND cleared_at IS NULL')
            ->execute([mb_substr($how, 0, 255), $uid ?: null, mb_substr($who, 0, 80) ?: null, mb_substr($note, 0, 400), $id]);
        self::log($pdo, 'resolve', (string) $a['proc'], 'Resolved: ' . (string) $a['title'], $who, $note . ($started ? ' Started again: ' . implode(', ', $started) . '.' : ''));
        return [true, $how];
    }

    // ---- grouped alarms (decisions/0171 §8's note, Jason 2026-11-18: "Board and Pulse") ------------------------------

    /** The system an alarm's process belongs to (0171's four): wf/t and the services a workflow reads → engine. */
    public static function systemOf(string $proc): string
    {
        if (str_starts_with($proc, 'wf:') || str_starts_with($proc, 't:')) return 'engine';
        if (str_starts_with($proc, 'wk:')) return 'workers';
        if (str_starts_with($proc, 'svc:')) {   // a source a workflow's needs read (not the site's own needs)
            try { require_once __DIR__ . '/Preflight.php'; foreach (Preflight::NEEDS as $n) if ($n[0] !== 'siteneeds') foreach ($n[3] as $sr) if ($sr[0] === 'svc' && $sr[1] === substr($proc, 4)) return 'engine'; } catch (Throwable $x) {}
            return 'services';
        }
        return 'site';
    }

    /** Its kind's family: held (held, out, quiet), failing (crashed, retrying), slow, or check (a red check, a wrong count). */
    public static function familyOf(string $kind): string
    {
        return in_array($kind, ['held', 'limit', 'silent'], true) ? 'held' : (in_array($kind, ['crash', 'retry'], true) ? 'failing' : ($kind === 'slow' ? 'slow' : 'check'));
    }

    public const GROUP_WORDS = ['engine' => ['engine feed', 'engine feeds'], 'workers' => ['worker', 'workers'], 'services' => ['outside service', 'outside services'], 'site' => ['site part', 'site parts']];
    public const FAMILY_WORDS = ['held' => 'held', 'failing' => 'failing', 'slow' => 'slow', 'check' => 'with a red check'];

    /** An open alarm's group key: system:level:family. */
    public static function groupKey(array $a): string
    {
        return self::systemOf((string) $a['proc']) . ':' . (string) $a['level'] . ':' . self::familyOf((string) $a['kind']);
    }

    /**
     * The open alarms that share a group with at least one other: key => [title, level, ids (worst first, as listed)].
     * A group of one isn't a group: that alarm stays its own row.
     */
    public static function groups(array $alarms): array
    {
        $g = [];
        foreach ($alarms as $a) if ($a['cleared_at'] === null) $g[self::groupKey($a)][] = (int) $a['id'];
        $out = [];
        foreach ($g as $k => $ids) {
            if (count($ids) < 2) continue;
            [$sys, $lv, $fam] = explode(':', $k);
            $out[$k] = ['title' => count($ids) . ' ' . self::GROUP_WORDS[$sys][1] . ' ' . self::FAMILY_WORDS[$fam], 'level' => $lv, 'ids' => $ids];
        }
        return $out;
    }

    /** The ids in a group ('alarms:<key>' or '<key>'), open now. */
    public static function groupMembers(PDO $pdo, string $key): array
    {
        $key = (string) preg_replace('/^alarms:/', '', $key);
        return self::groups(self::list($pdo, 300))[$key]['ids'] ?? [];
    }

    /**
     * Pulse's alarm items grouped (0171 §8's note): where two or more open alarm items share a group, one item
     * 'alarms:<key>' stands in their place, its 'children' the alarm items as they were (each keeps its own key, steps and
     * marks). Severity critical if any child is; the clock and escalation from its children.
     */
    public static function pulseGroups(PDO $pdo, array $items): array
    {
        $groups = self::groups(self::list($pdo, 300));
        if (!$groups) return $items;
        $of = []; foreach ($groups as $k => $g) foreach ($g['ids'] as $id) $of[$id] = $k;
        $kids = []; $rest = [];
        foreach ($items as $it) {
            $id = preg_match('/^alarm:(\d+)$/', (string) ($it['key'] ?? ''), $m) ? (int) $m[1] : 0;
            if ($id && isset($of[$id]) && ($it['state'] ?? '') !== 'done') $kids[$of[$id]][] = $it; else $rest[] = $it;
        }
        foreach ($kids as $k => $ch) {
            if (count($ch) < 2) { foreach ($ch as $c) $rest[] = $c; continue; }
            $first = $ch[0]; $whens = array_filter(array_map(fn ($c) => (string) $c['when'], $ch)); $dues = array_filter(array_map(fn ($c) => (string) ($c['sla_due'] ?? ''), $ch));
            $rest[] = ['key' => 'alarms:' . $k, 'source' => 'system', 'severity' => in_array('critical', array_column($ch, 'severity'), true) ? 'critical' : 'alert',
                'title' => count($ch) . ' ' . self::GROUP_WORDS[explode(':', $k)[0]][1] . ' ' . self::FAMILY_WORDS[explode(':', $k)[2]],
                'why' => implode('; ', array_map(fn ($c) => (string) $c['title'], $ch)) . '.', 'when' => $whens ? min($whens) : '', 'url' => '/admin/config/control#cb-alarms', 'action' => 'Open it',
                'about' => '', 'reply_to' => null, 'dept' => $first['dept'] ?? '', 'sla_due' => $dues ? min($dues) : null, 'state' => '', 'over' => (bool) array_filter(array_column($ch, 'over')),
                'mine' => false, 'who' => '', 'case_no' => 0, 'esc' => max(array_map(fn ($c) => (int) ($c['esc'] ?? 0), $ch)), 'esc_to_me' => (bool) array_filter(array_column($ch, 'esc_to_me')), 'children' => $ch];
        }
        return $rest;
    }

    /** Acknowledge every open alarm in a group (the board's group row). Returns how many. */
    public static function ackGroup(PDO $pdo, string $key, int $uid, string $who): int
    {
        $n = 0; foreach (self::groupMembers($pdo, $key) as $id) if (self::ack($pdo, $id, $uid, $who)) $n++;
        return $n;
    }

    /** What a trip stopped, in words ('' none). */
    public static function stoppedWords(array $a): string
    {
        $st = json_decode((string) ($a['stopped'] ?? ''), true);
        return is_array($st) && $st ? implode(', ', array_map(fn ($x) => (string) ($x[2] ?? ''), $st)) : '';
    }

    /** Undo a Resolve (within a day): the trip is open again and what it had stopped is stopped again. */
    public static function unresolve(PDO $pdo, int $id, int $uid, string $who): array
    {
        $a = self::byId($pdo, $id);
        if (!$a || $a['resolved_at'] === null || $a['cleared_at'] === null) return [false, 'It wasn\'t resolved, so there\'s nothing to undo.'];
        if (strtotime($a['resolved_at'] . ' UTC') < time() - 86400) return [false, 'A Resolve can be undone for a day; this one is older. If the problem is back, its alarm opens again by itself.'];
        if (self::openOf($pdo, (string) $a['akey'])) return [false, 'The same problem is already open again as a new alarm.'];
        $pdo->prepare('UPDATE control_alarms SET cleared_at = NULL, cleared_how = NULL, resolved_uid = NULL, resolved_name = NULL, resolved_at = NULL, resolve_note = ? WHERE id = ?')
            ->execute([mb_substr('Resolve undone by ' . $who . ' at ' . gmdate('H:i') . ' UTC.', 0, 400), $id]);
        $stopped = self::stop($pdo, self::byId($pdo, $id));
        $pdo->prepare('UPDATE control_alarms SET stopped = ? WHERE id = ?')->execute([$stopped ? mb_substr(json_encode($stopped, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), 0, 400) : null, $id]);
        self::log($pdo, 'resolve', (string) $a['proc'], 'Resolve undone: ' . (string) $a['title'], $who, $stopped ? implode(', ', array_column($stopped, 2)) . ' stopped again' : '');
        return [true, 'Undone: the trip is open again' . ($stopped ? ', and ' . implode(', ', array_column($stopped, 2)) . ' stopped again.' : '.')];
    }

    /** Clears every open alarm whose key starts with $prefix except those in $keep (the readings still bad). */
    public static function clearOthers(PDO $pdo, string $prefix, array $keep, string $how): int
    {
        $n = 0;
        try {
            self::ensure($pdo);
            $st = $pdo->prepare("SELECT akey FROM control_alarms WHERE cleared_at IS NULL AND akey LIKE ?"); $st->execute([addcslashes($prefix, '%_') . '%']);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $k) if (!in_array($k, $keep, true) && self::clear($pdo, (string) $k, $how)) $n++;
        } catch (Throwable $x) {}
        return $n;
    }

    /** Acknowledged by a person: stops the repeat email; it stays open until its reading is good. */
    public static function ack(PDO $pdo, int $id, int $uid, string $who): bool
    {
        self::ensure($pdo);
        $st = $pdo->prepare('UPDATE control_alarms SET ack_uid = ?, ack_name = ?, ack_at = UTC_TIMESTAMP() WHERE id = ? AND ack_at IS NULL');
        $st->execute([$uid ?: null, mb_substr($who, 0, 80) ?: null, $id]);
        $ok = $st->rowCount() > 0;
        if ($ok && ($a = self::byId($pdo, $id))) self::log($pdo, 'ack', (string) $a['proc'], 'Acknowledged: ' . (string) $a['title'], $who);
        return $ok;
    }

    /** Undo an acknowledgement (it emails again only if it's a new problem). */
    public static function unack(PDO $pdo, int $id): bool
    {
        self::ensure($pdo);
        $st = $pdo->prepare('UPDATE control_alarms SET ack_uid = NULL, ack_name = NULL, ack_at = NULL WHERE id = ? AND ack_at IS NOT NULL'); $st->execute([$id]);
        return $st->rowCount() > 0;
    }

    /**
     * The list: open alarms, worst first, then the trips that cleared before anyone saw them (kept 24 hours, 0171 §7).
     * Each row as stored, with 'fix' decoded.
     */
    public static function list(PDO $pdo, int $n = 100): array
    {
        try {
            self::ensure($pdo);
            $rows = $pdo->query("SELECT * FROM control_alarms WHERE cleared_at IS NULL OR cleared_at >= UTC_TIMESTAMP() - INTERVAL 48 HOUR
                                 ORDER BY cleared_at IS NOT NULL, FIELD(level, 'trip', 'warning', 'notice'), last_at DESC LIMIT " . max(1, min(500, $n)))->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as &$r) $r['fix'] = $r['fix'] !== '' ? (json_decode((string) $r['fix'], true) ?: []) : [];
            return $rows;
        } catch (Throwable $x) { return []; }
    }

    /** For the light: open trips and warnings, and the trips that cleared unseen. */
    public static function counts(PDO $pdo): array
    {
        $z = ['trip' => 0, 'warning' => 0, 'notice' => 0, 'unseen' => 0];
        try {
            self::ensure($pdo);
            foreach ($pdo->query('SELECT level, COUNT(*) FROM control_alarms WHERE cleared_at IS NULL GROUP BY level')->fetchAll(PDO::FETCH_KEY_PAIR) as $l => $c) if (isset($z[$l])) $z[$l] = (int) $c;
            $z['unseen'] = (int) $pdo->query("SELECT COUNT(*) FROM control_alarms WHERE level = 'trip' AND ack_at IS NULL AND cleared_at >= UTC_TIMESTAMP() - INTERVAL 24 HOUR")->fetchColumn();
        } catch (Throwable $x) {}
        return $z;
    }

    /** A process's open alarms (for its row on the board). */
    public static function ofProc(PDO $pdo, string $proc): array
    {
        try { self::ensure($pdo); $st = $pdo->prepare('SELECT * FROM control_alarms WHERE proc = ? AND cleared_at IS NULL ORDER BY FIELD(level, \'trip\', \'warning\', \'notice\'), last_at DESC'); $st->execute([$proc]); return $st->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $x) { return []; }
    }

    /**
     * The email (0171 §7, through 0172's one dispatcher): a trip at once; a warning unacknowledged 24 hours. Sent only
     * when the dispatcher knows the kind (Notify::KINDS has alarm.trip / alarm.warning); until then nothing is sent and
     * the alarm still stands on the board. Marks it mailed so it goes once.
     */
    private static function mail(PDO $pdo, int $id): void
    {
        try {
            $st = $pdo->prepare('SELECT * FROM control_alarms WHERE id = ?'); $st->execute([$id]); $a = $st->fetch(PDO::FETCH_ASSOC);
            if (!$a || $a['mailed_at'] !== null) return;
            $kind = $a['level'] === 'trip' ? 'alarm.trip' : 'alarm.warning';
            require_once __DIR__ . '/Notify.php'; require_once __DIR__ . '/CommsSetup.php';
            if (!isset(Notify::KINDS[$kind])) return;
            $to = CommsSetup::founders($pdo);
            if (!$to) return;
            $body = ($a['means'] !== '' ? 'What it means: ' . $a['means'] . "\n" : '') . ($a['todo'] !== '' ? 'What to do: ' . $a['todo'] . "\n" : '') . ($a['reading'] !== '' ? 'Reading: ' . $a['reading'] : '');
            Notify::send($pdo, $kind, ['staff' => $to], ['thing' => 'alarm:' . $id, 'url' => '/admin/config/control#cb-alarm-' . $id, 'from' => ['system', null, 'Control Board']],
                ['title' => (string) $a['title'], 'body' => trim($body)]);
            $pdo->prepare('UPDATE control_alarms SET mailed_at = UTC_TIMESTAMP() WHERE id = ?')->execute([$id]);
        } catch (Throwable $x) { error_log('control alarm mail ' . $id . ': ' . $x->getMessage()); }
    }

    /** The alarm inside its message in Pulse (Notify::BODIES): what happened, means, what to do, its state, Acknowledge. */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        $e = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES, 'UTF-8');
        $id = (int) preg_replace('/\D/', '', (string) ($m['thing'] ?? $m['about'] ?? ''));
        $st = $pdo->prepare('SELECT * FROM control_alarms WHERE id = ?'); $st->execute([$id]); $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) return ['html' => '<p>This alarm is no longer kept.</p>', 'state' => 'Gone'];
        $state = $a['cleared_at'] !== null ? 'Cleared: ' . (string) $a['cleared_how'] : ($a['ack_at'] !== null ? 'Acknowledged by ' . ($a['ack_name'] ?? 'staff') . '; open until its reading is good' : 'Open');
        $h = '<p><b>' . $e($a['title']) . '</b></p>' . ($a['means'] !== '' ? '<p>' . $e($a['means']) . '</p>' : '') . ($a['todo'] !== '' ? '<p><b>What to do:</b> ' . $e($a['todo']) . '</p>' : '')
           . '<p class="tv-msg-acts">' . ($a['cleared_at'] === null && $a['ack_at'] === null ? '<button type="button" class="tv-btn" data-msg-act="/admin/api/config/control" data-msg-body=\'' . $e(json_encode(['action' => 'ack', 'id' => $id])) . '\'>Acknowledge</button> ' : '')
           . '<a class="tv-btn" href="/admin/config/control#cb-alarm-' . $id . '">Open it on the board</a></p>';
        return ['html' => $h, 'state' => $state];
    }

    /**
     * Its Pulse item's steps (0171 §8): the same buttons as its row on the board, acting in place through Pulse::manage
     * (a cap's Raise the cap as a one-field form, Pause it, Check it now, Mark resolved), then the board itself.
     */
    public static function pulseSteps(PDO $pdo, int $id, callable $s): array
    {
        $st = $pdo->prepare('SELECT * FROM control_alarms WHERE id = ?'); $st->execute([$id]); $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) return [$s('Nothing to do', 'This alarm is no longer kept.', null, true)];
        $fx = json_decode((string) $a['fix'], true); $fx = is_array($fx) ? (isset($fx[0]) && is_array($fx[0]) ? $fx : [$fx]) : [];
        if (str_starts_with((string) $a['akey'], 'svc:issue:')) $fx[] = ['Mark resolved', 'svcresolve', substr((string) $a['akey'], 10)];
        $out = [];
        if ($a['cleared_at'] === null) foreach ($fx as $f) {
            $k = (string) ($f[1] ?? ''); $l = (string) ($f[0] ?? '');
            if ($k === 'peek') $out[] = $s($l, 'Opens beside this item.', ['tool', (string) $f[2]]);
            elseif ($k === 'opsask') $out[] = $s($l, 'Now ' . (string) ($f[3][1] ?? '') . '. Kept with who and when.', ['form', 'alarm_' . (string) $f[2], 'Set it', [['value', (string) ($f[3][0] ?? 'Value'), 'text', (string) ($f[3][1] ?? '')]]]);
            elseif ($k === 'ops') $out[] = $s($l, is_string($f[3] ?? null) ? (string) $f[3] : 'Done in place.', ['do', 'alarm_' . (string) $f[2], $l]);
            elseif ($k === 'svcresolve') $out[] = $s($l, 'Calls to it start again; a new failure opens a new issue and its alarm.', ['do', 'alarm_svcresolve:' . (string) $f[2], $l]);
        }
        if ($a['cleared_at'] === null && $a['level'] === 'trip' && !empty($a['tripped_at']))
            $out[] = $s('Check and start again', 'The system checks it first' . (self::stoppedWords($a) !== '' ? ', then starts again ' . self::stoppedWords($a) : '') . '; if the check is still red, it says which part holds it. Undo is kept for a day.', ['do', 'alarm_resolve', 'Check and start again']);
        elseif (!empty($a['resolved_at']) && strtotime($a['resolved_at'] . ' UTC') > time() - 86400)
            $out[] = $s('Undo the Resolve', 'Opens the trip again and stops again what it had stopped.', ['do', 'alarm_unresolve', 'Undo']);
        $out[] = $s('Open it on the board', 'Where it sits in the system, with its evidence.', ['tool', '/admin/config/control#cb-alarm-' . $id]);
        return $out;
    }

    /**
     * An operations step pressed on an alarm, on the board or in Pulse (each family's own permission, in Operations::pulseDo
     * and what it calls): its case's key and the steps that family carries. Unknown pairs are refused.
     */
    public static function opsDo(PDO $pdo, string $akey, string $what, array $in, int $uid, string $who): string
    {
        $fam = [
            '/^ops:(cap|empty):[a-z0-9_]+$/' => ['', '/^ops_(cap|pause|runnext|task_off):[a-z0-9_]+$/'],
            '/^ops:start:[a-f0-9]{10}$/' => ['ops:start', '/^ops_start_(go|skip|junk|tick)$/'],
            '/^ops:w0:[a-z0-9_.:-]+$/i' => ['ops:w0', '/^ops_w0_(reactivate|flag_ok):[a-z0-9_.:\/-]+$/i'],
            '/^ops:pf:stopped$/' => ['ops:preflight', '/^ops_pf_(continue|cancel)$/'],
        ];
        foreach ($fam as $kre => [$case, $wre]) if (preg_match($kre, $akey) && preg_match($wre, $what)) {
            require_once __DIR__ . '/Operations.php';
            return Operations::pulseDo($pdo, $case !== '' ? $case : $akey, $what, $in, $uid, $who);
        }
        throw new RuntimeException('That step isn\'t one the board does.');
    }

    /** A step pressed on its Pulse item: the board's own action, with the board's permissions. */
    public static function pulseDo(PDO $pdo, int $id, string $what, array $in, int $uid, string $who): string
    {
        $st = $pdo->prepare('SELECT akey FROM control_alarms WHERE id = ?'); $st->execute([$id]); $akey = (string) ($st->fetchColumn() ?: '');
        if ($akey === '') throw new RuntimeException('This alarm is no longer kept.');
        if (str_starts_with($what, 'alarm_ops_')) return self::opsDo($pdo, $akey, substr($what, 6), $in, $uid, $who);
        if (in_array($what, ['alarm_resolve', 'alarm_unresolve'], true)) {   // an admin's Resolve, and its Undo (executive; starting again, Automation's)
            require_once __DIR__ . '/ControlBoard.php'; [$ok, $why] = ControlBoard::can(); if (!$ok) throw new RuntimeException($why . '.');
            $a = self::byId($pdo, $id);
            if ($a && json_decode((string) ($a['stopped'] ?? ''), true)) { require_once __DIR__ . '/SystemStart.php'; [$ok, $why] = SystemStart::can(); if (!$ok) throw new RuntimeException($why . ': it would start again what the trip stopped.'); }
            [$done, $msg] = $what === 'alarm_resolve' ? self::resolve($pdo, $id, $uid, $who, (string) ($in['note'] ?? '')) : self::unresolve($pdo, $id, $uid, $who);
            if (!$done) throw new RuntimeException($msg);
            return $msg;
        }
        if (preg_match('/^alarm_svcresolve:(osm|\d+)$/', $what, $m)) {
            require_once __DIR__ . '/ServiceHealth.php'; require_once __DIR__ . '/Preflight.php';
            [$ok, $why] = Preflight::can(); if (!$ok) throw new RuntimeException($why . '.');
            $ids = $m[1] === 'osm' ? array_map(fn ($i) => (int) $i['id'], array_filter(ServiceHealth::openAll($pdo), fn ($i) => $i['service'] === 'osm')) : [(int) $m[1]];
            $n = 0; foreach ($ids as $iid) if (ServiceHealth::resolve($pdo, $iid, $uid, 'Marked resolved by ' . $who . ' in Pulse.')) $n++;
            return $n ? 'Resolved: calls start again; a new failure opens a new issue and its alarm.' : 'Nothing to resolve: it was already resolved.';
        }
        throw new RuntimeException('Unknown step.');
    }

    /**
     * The watch (0171 §5, every 5 minutes: control_tick): what doesn't call in. W0 Indexer silent while it's switched on, a
     * crawler run past its time plus 5 minutes, a site job whose last run stopped, a job run that never finished; and the
     * warnings due their 24-hour email. Each raised, or cleared when its reading is good. Returns what it did, in words.
     */
    public static function tick(PDO $pdo): string
    {
        self::ensure($pdo);
        $did = [];
        if ($sd = self::seed($pdo)) $did[] = $sd . ' known problem(s) raised';
        // maintenance windows (0171 §2.5, release 4a): one whose time has come goes out; one past its Back by comes back
        try { require_once __DIR__ . '/ControlMaintenance.php'; foreach (ControlMaintenance::tick($pdo) as $m) $did[] = 'maintenance: ' . $m; } catch (Throwable $x) {}
        require_once __DIR__ . '/Automation.php';
        $masterOn = Automation::master($pdo) === null;
        // W0 Indexer: its check-in (every minute or so while it runs)
        try {
            require_once __DIR__ . '/crawler/Frontier.php';
            $beat = (int) (Frontier::lastBeat($pdo)['at'] ?? 0); $on = $masterOn && Automation::wfOff($pdo, 'W0') === null;
            if ($on && $beat && time() - $beat > 15 * 60) { self::raise($pdo, 'silent:w0', 'wk:w0-indexer', 'trip', 'silent', 'W0 Indexer has gone quiet', 'It hasn\'t checked in for ' . (int) floor((time() - $beat) / 60) . ' minutes while it\'s switched on: no addresses are being logged.', 'Open its Railway service: if it crashed or its plan ran out, redeploy it; then press Check.', 'last check-in ' . gmdate('M j H:i', $beat) . ' UTC', ['Check', 'check', 'wk:w0-indexer']); $did[] = 'W0 quiet'; }
            elseif ($beat && time() - $beat <= 15 * 60 && self::clear($pdo, 'silent:w0', 'It checked in at ' . gmdate('H:i', $beat) . ' UTC.')) $did[] = 'W0 back';
            elseif (!$on) self::clear($pdo, 'silent:w0', 'It was switched off.');
        } catch (Throwable $x) {}
        // a crawler run that never reported: its time (RUN_LIMIT, 30 minutes) plus 5
        try {
            $late = $pdo->query("SELECT id, started_at FROM crawl_runs WHERE status = 'running' AND started_at < NOW() - INTERVAL 35 MINUTE ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
            if ($late) { self::raise($pdo, 'silent:run', 'wk:crawler', 'trip', 'silent', 'A crawler run never reported (#' . (int) $late['id'] . ')', 'It started over 35 minutes ago and hasn\'t said how it ended: it was stopped, or it crashed on Railway.', 'Open the crawler on Railway and read the run\'s last log lines; the site marks it abandoned.', 'started ' . (string) $late['started_at'], ['Check', 'check', 'wk:crawler']); $did[] = 'run quiet'; }
            elseif (self::clear($pdo, 'silent:run', 'No run is overdue (' . gmdate('H:i') . ' UTC).')) $did[] = 'run cleared';
        } catch (Throwable $x) {}
        // site jobs: the last run of each, stopped or never finished
        try {
            $t = Database::t('job_runs'); $bad = []; $stuck = [];
            foreach ($pdo->query("SELECT r.job, r.ok, r.note, r.started_at, r.finished_at FROM $t r JOIN (SELECT job, MAX(id) id FROM $t WHERE started_at > NOW() - INTERVAL 2 DAY GROUP BY job) m ON m.id = r.id")->fetchAll(PDO::FETCH_ASSOC) as $j) {
                $job = (string) $j['job'];
                if ($j['ok'] !== null && (int) $j['ok'] === 0) {   // its own next runs are the system's tries (3c): a trip once they fail too
                    $bad[] = 'job:' . $job;
                    $rs = $pdo->prepare("SELECT ok FROM $t WHERE job = ? AND finished_at IS NOT NULL ORDER BY id DESC LIMIT 20"); $rs->execute([$job]);
                    $fails = 0; foreach ($rs->fetchAll(PDO::FETCH_COLUMN) as $ok) { if ((int) $ok === 1) break; $fails++; }
                    [$max] = self::limits($pdo, 'crash');
                    self::raise($pdo, 'job:' . $job, 'job:' . $job, 'trip', 'crash', 'The job "' . $job . '" stopped', 'Its last run ended with a problem (' . $fails . ' in a row); what it does waits until it runs well again.', 'Read its note in System Configuration → Scheduled tasks and fix the cause.', mb_substr((string) $j['note'], 0, 255), [], false, $fails < $max);
                }
                elseif ($j['finished_at'] === null && strtotime((string) $j['started_at']) < time() - 7200) { $stuck[] = 'job:' . $job . ':stuck'; self::raise($pdo, 'job:' . $job . ':stuck', 'job:' . $job, 'warning', 'slow', 'The job "' . $job . '" never finished', 'Its run started over 2 hours ago and never said it ended: it was killed, or it hangs.', 'Look at the server\'s error log for it; the next run starts as usual.', 'started ' . (string) $j['started_at'], [], false); }
            }
            $n = self::clearOthers($pdo, 'job:', array_merge($bad, $stuck), 'Its last run ended well (' . gmdate('H:i') . ' UTC).');
            // slow (0171 §5, 3c): a job's last runs against its usual time (the middle of its last 20, 5 at least) × control_slow_factor,
            // and over a minute; a warning, a trip after control_slow_trips slow runs in a row
            require_once __DIR__ . '/Thresholds.php'; $f = (float) (Thresholds::get($pdo, 'control_slow_factor') ?? 3); [$sMax] = self::limits($pdo, 'slow'); $slow = [];
            foreach ($pdo->query("SELECT DISTINCT job FROM $t WHERE finished_at IS NOT NULL AND started_at > NOW() - INTERVAL 2 DAY")->fetchAll(PDO::FETCH_COLUMN) as $job) {
                $rs = $pdo->prepare("SELECT TIMESTAMPDIFF(SECOND, started_at, finished_at) FROM $t WHERE job = ? AND finished_at IS NOT NULL ORDER BY id DESC LIMIT 21"); $rs->execute([$job]);
                $d = array_map('intval', $rs->fetchAll(PDO::FETCH_COLUMN)); if (count($d) < 6) continue;
                $past = array_slice($d, 1); sort($past); $usual = $past[intdiv(count($past), 2)]; $lim = max(60, $usual * $f);
                $run = 0; foreach ($d as $x) { if ($x <= $lim) break; $run++; }
                if ($run > 0) { $slow[] = 'jobslow:' . $job; self::raise($pdo, 'jobslow:' . $job, 'job:' . $job, 'warning', 'slow', 'The job "' . $job . '" is slow',
                    'Its last run took ' . $d[0] . ' s against its usual ' . $usual . ' s (' . $run . ' slow in a row): what follows it waits.', 'Look at what it works through; a large backlog or a slow query is the usual cause.', $d[0] . ' s (usual ' . $usual . ')', [], false, false); }
            }
            self::clearOthers($pdo, 'jobslow:', $slow, 'Its last run took its usual time (' . gmdate('H:i') . ' UTC).');
            if ($bad) $did[] = count($bad) . ' job(s) stopped'; if ($n) $did[] = $n . ' job alarm(s) cleared';
        } catch (Throwable $x) {}
        // Overpass: every server held is one trip a person resolves (3b); raised once from the issues already open
        try {
            require_once __DIR__ . '/ServiceHealth.php';
            $osm = array_values(array_filter(ServiceHealth::openAll($pdo), fn ($i) => $i['service'] === 'osm' && (ServiceHealth::KINDS[$i['kind']][1] ?? 'back') === 'stop'));
            if ($osm && !self::openOf($pdo, 'svc:osm:held')) { $l = (array) ((json_decode((string) $osm[0]['evidence'], true) ?: [])['latest'] ?? []);
                ServiceHealth::alarm($pdo, (int) $osm[0]['id'], 'osm', (string) $osm[0]['host'], (string) $osm[0]['kind'], ['status' => (int) ($l['status'] ?? 0), 'error' => (string) ($l['error'] ?? ''), 'body' => (string) ($l['body'] ?? '')], (string) $osm[0]['caller']); $did[] = 'Overpass held'; }
            $pdo->exec("UPDATE control_alarms SET cleared_at = UTC_TIMESTAMP(), cleared_how = 'Now part of \"Every Overpass server is held\".' WHERE cleared_at IS NULL AND proc = 'svc:osm' AND akey LIKE 'svc:issue:%'");
        } catch (Throwable $x) {}
        // the last Pulse cases as alarms (0171 §8, 3c): Starting the system, W0 Indexer's needs, a pre-flight run that stopped;
        // and the cap and "returns empty" readings (3b)
        try { require_once __DIR__ . '/Operations.php'; Operations::alarms($pdo); } catch (Throwable $x) { error_log('ops alarms: ' . $x->getMessage()); }
        $m = self::mailStale($pdo); if ($m) $did[] = $m . ' warning(s) emailed';
        // each open pre-flight alarm's words from its line as it stands now (stored results; nothing is run again): a trip
        // raised before the board read a check part by part kept its old words (W0, 2026-11-18); now it names its red part,
        // or says its check passes and waits for a Resolve. Not a new event: its count doesn't move.
        try { require_once __DIR__ . '/Preflight.php'; $pl = Preflight::lines($pdo); $pr = Preflight::results($pdo); $nr = 0;
            $rerun = 0;
            foreach ($pdo->query("SELECT akey FROM control_alarms WHERE cleared_at IS NULL AND akey LIKE 'pf:%'")->fetchAll(PDO::FETCH_COLUMN) as $ak) {
                $lid = substr((string) $ak, 3);
                // a line not tested in 6 hours is tested again first (free and read only; three a watch), so its words are
                // today's (2026-11-19: W0's result was from before checks were stored part by part)
                if (isset($pl[$lid]) && $rerun < 3 && (int) ($pr[$lid]['at'] ?? 0) < time() - 6 * 3600) { try { $pr[$lid] = Preflight::run($pdo, $lid, 'the Control Board\'s watch', true); $rerun++; continue; } catch (Throwable $x) {} }
                if (isset($pl[$lid], $pr[$lid])) { Preflight::alarm($pdo, $lid, $pl[$lid], $pr[$lid], false); $nr++; }
            }
        } catch (Throwable $x) { error_log('pf words: ' . $x->getMessage()); }
        // a slow trip from before 4e (or a slow alarm still holding what it stopped): the system lifts it itself, checking
        // first, and tries again every watch while a check is red (Jason, 2026-11-19: "no dead ends, system fixes first")
        try { foreach ($pdo->query("SELECT id, level FROM control_alarms WHERE cleared_at IS NULL AND kind = 'slow' AND (level = 'trip' OR (stopped IS NOT NULL AND stopped <> '' AND stopped <> '[]'))")->fetchAll(PDO::FETCH_ASSOC) as $sa) {
                [$okL, $msgL] = self::resolve($pdo, (int) $sa['id'], 0, 'the system', 'A slow call is a warning, never a stop (Jason, 2026-11-19): checked and started again by the system');
                if ($okL) $did[] = 'lifted slow trip #' . (int) $sa['id'];
                elseif ($sa['level'] === 'trip') $pdo->prepare("UPDATE control_alarms SET level = 'warning', means = ? WHERE id = ?")->execute([mb_substr('Slow, not broken. What it stopped starts again once its check passes; the system tries every 5 minutes. ' . $msgL, 0, 400), (int) $sa['id']]);
            } } catch (Throwable $x) { error_log('slow lift: ' . $x->getMessage()); }
        // a site issue that backs off (a timeout, a server error) with its wait over and nothing calling it: the watch runs its
        // service's free check, at most once an hour each, two a watch; an answer closes it (4f, 2026-11-19: Claude's #19 sat
        // open from 20:05 with nothing calling). Never a refusal or a block: those wait for a person (principle 1).
        try { require_once __DIR__ . '/ServiceHealth.php'; require_once __DIR__ . '/Preflight.php'; require_once __DIR__ . '/SearchIndex.php'; $pl2 = Preflight::lines($pdo); $nc = 0;
            foreach (ServiceHealth::openAll($pdo) as $si) {
                if ($nc >= 2 || $si['caller'] !== 'site' || (ServiceHealth::KINDS[$si['kind']][1] ?? '') !== 'back' || ServiceHealth::holding($si) || !isset($pl2['svc:' . $si['service']])) continue;
                $k = 'sh:recheck:' . (int) $si['id'];
                if ((int) SearchIndex::state($pdo, $k) > time() - 3600) continue;
                SearchIndex::setState($pdo, $k, (string) time());
                Preflight::run($pdo, 'svc:' . $si['service'], 'the Control Board\'s watch', true); $nc++;
                $did[] = 'rechecked issue #' . (int) $si['id'];
            }
        } catch (Throwable $x) { error_log('issue recheck: ' . $x->getMessage()); }
        // the historian (0171 §6, release 4b): each process's state and the hour's counts kept over time; last, so the rest of
        // the watch never waits on it
        // its own time kept and watched like any slow job (the session manager, 2026-11-18): a heavy watch shows on the board
        try { require_once __DIR__ . '/ControlHistorian.php'; $h0 = microtime(true); foreach (ControlHistorian::tick($pdo) as $h) $did[] = 'history: ' . $h;
            ControlHistorian::timed($pdo, (int) round((microtime(true) - $h0) * 1000)); } catch (Throwable $x) {}
        return $did ? implode('; ', $did) . '.' : 'Nothing new.';
    }

    /**
     * What's already known, raised once (0171, release 3a: the queue isn't empty on day one): the pre-flight's red lines,
     * the service issues open now, the worker calls that answered a server error in the last day, and sources outside
     * our region being read. After this, each is raised the moment it happens.
     */
    public static function seed(PDO $pdo): int
    {
        self::ensure($pdo);
        require_once __DIR__ . '/SearchIndex.php';
        if (SearchIndex::state($pdo, 'control:alarms_seeded') !== '') return 0;
        $n = 0;
        try { require_once __DIR__ . '/Preflight.php'; $lines = Preflight::lines($pdo);
            foreach (Preflight::results($pdo) as $id => $r) if (isset($lines[$id]) && in_array($r['s'] ?? '', ['bad', 'warn'], true)) { Preflight::alarm($pdo, (string) $id, $lines[$id], $r); $n++; } } catch (Throwable $x) {}
        try { require_once __DIR__ . '/ServiceHealth.php';
            foreach (ServiceHealth::openAll($pdo) as $i) { $ev = json_decode((string) $i['evidence'], true) ?: []; $l = (array) ($ev['latest'] ?? []);
                ServiceHealth::alarm($pdo, (int) $i['id'], (string) $i['service'], (string) $i['host'], (string) $i['kind'], ['status' => (int) ($l['status'] ?? 0), 'error' => (string) ($l['error'] ?? ''), 'body' => (string) ($l['body'] ?? '')], (string) $i['caller']); $n++; } } catch (Throwable $x) {}
        try { require_once __DIR__ . '/ControlRegister.php';
            foreach ($pdo->query("SELECT l.endpoint, l.code, l.reasons, l.at, c.n FROM control_ledger l JOIN (SELECT endpoint, MAX(id) id, COUNT(*) n FROM control_ledger WHERE code >= 500 AND at >= UTC_TIMESTAMP() - INTERVAL 1 DAY GROUP BY endpoint) c ON c.id = l.id WHERE l.id = (SELECT MAX(id) FROM control_ledger z WHERE z.endpoint = l.endpoint)")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $proc = self::procOfEndpoint($pdo, (string) $r['endpoint']);
                self::raise($pdo, 'ep:' . $r['endpoint'] . ':5xx', $proc, 'trip', 'crash', '/api/' . $r['endpoint'] . ' answers a server error (' . (int) $r['n'] . ' in the last day)',
                    'The worker\'s calls fail on our side; what they need is not done until it\'s fixed.', 'Read the error below; fix its cause on the site. It clears by itself at the next good answer.', mb_substr((string) preg_replace('/^answered \d+: /', '', (string) $r['reasons']), 0, 255), ['Check', 'check', $proc]); $n++;
            } } catch (Throwable $x) {}
        try {   // sources being read outside our region: a country domain other than .us (the source finder may follow links off-region)
            $hosts = array_values(array_filter($pdo->query("SELECT host FROM " . Database::t('reference_sources') . " WHERE status = 'read'")->fetchAll(PDO::FETCH_COLUMN), fn ($h) => preg_match('/\.(?!us$)[a-z]{2}$/', (string) $h) === 1));
            if ($hosts) { self::raise($pdo, 'w3:offregion', 'wf:W3', 'warning', 'check', count($hosts) . ' source' . (count($hosts) === 1 ? '' : 's') . ' outside our region being read (' . implode(', ', array_slice($hosts, 0, 3)) . (count($hosts) > 3 ? ' and more' : '') . ')',
                'W3 reads them every few days; their facts are likely about other places, and reading them uses the crawler\'s time.', 'Decide whether they belong: pause each on Insights → Sources, or say which kinds of outside sources are welcome.', implode(', ', array_slice($hosts, 0, 12))); $n++; }
        } catch (Throwable $x) {}
        SearchIndex::setState($pdo, 'control:alarms_seeded', gmdate('c'));
        return $n;
    }

    /** Warnings open and unacknowledged 24 hours: emailed once (the watch calls this). */
    public static function mailStale(PDO $pdo): int
    {
        $n = 0;
        try {
            self::ensure($pdo);
            foreach ($pdo->query("SELECT id FROM control_alarms WHERE level = 'warning' AND cleared_at IS NULL AND ack_at IS NULL AND mailed_at IS NULL AND first_at <= UTC_TIMESTAMP() - INTERVAL 24 HOUR")->fetchAll(PDO::FETCH_COLUMN) as $id) { self::mail($pdo, (int) $id); $n++; }
        } catch (Throwable $x) {}
        return $n;
    }
}
