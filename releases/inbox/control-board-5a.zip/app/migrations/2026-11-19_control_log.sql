-- The System Control Board's logbook (decisions/0171 §10, release 5a): alarms raised, acknowledged, cleared and resolved;
-- shut-downs, starts and maintenance; each control pressed on the board; an operator's own note. Who is staff or "the
-- system", never a member. Staging class: own (app/lib/staging-tables.php). Safe to run twice; ControlLog::ensure() makes
-- the same table if this hasn't run yet.
CREATE TABLE IF NOT EXISTS control_log (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  at DATETIME NOT NULL,
  tz VARCHAR(64) NOT NULL DEFAULT '',
  kind VARCHAR(20) NOT NULL,
  proc VARCHAR(60) NOT NULL DEFAULT '',
  what VARCHAR(400) NOT NULL,
  who VARCHAR(80) NOT NULL DEFAULT 'the system',
  why VARCHAR(400) NOT NULL DEFAULT '',
  KEY at (at),
  KEY proc_at (proc, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
