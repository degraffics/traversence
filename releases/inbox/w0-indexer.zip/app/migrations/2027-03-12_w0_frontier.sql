-- W0 Indexer (decisions/0164 §1.1–1.4, the note of 2026-11-17): the URL frontier, junk kept compact, skip rules, the
-- append-only audit log and each batch's receipt. Add-only and safe to run twice: new tables only, each made only if it
-- is missing. The key is sha1 of the normalized address, the page log's own key (crawl_pages.url_hash), so a frontier row
-- and its page log row join (Jason, 2026-11-17). Index keys stay under 767 bytes (older InnoDB row formats). On staging every crawl_* table follows live (staging-tables.php).

CREATE TABLE IF NOT EXISTS crawl_frontier (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  url_hash CHAR(40) NOT NULL,
  url VARCHAR(1000) NULL,
  host VARCHAR(190) NOT NULL,
  site VARCHAR(150) NOT NULL,
  from_hash CHAR(40) NULL,
  link_text VARCHAR(160) NULL,
  state VARCHAR(12) NOT NULL DEFAULT 'pending',
  reason VARCHAR(24) NULL,
  verdict VARCHAR(8) NOT NULL DEFAULT 'normal',
  depth TINYINT UNSIGNED NOT NULL DEFAULT 0,
  links_in INT UNSIGNED NOT NULL DEFAULT 1,
  site_score SMALLINT NOT NULL DEFAULT 0,
  url_score SMALLINT NOT NULL DEFAULT 0,
  priority SMALLINT NOT NULL DEFAULT 0,
  tries TINYINT UNSIGNED NOT NULL DEFAULT 0,
  next_at DATETIME NULL,
  lease_until DATETIME NULL,
  first_at DATETIME NOT NULL,
  seen_at DATETIME NOT NULL,
  read_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_crawl_frontier_hash (url_hash),
  KEY idx_crawl_frontier_work (state, priority),
  KEY idx_crawl_frontier_due (state, next_at),
  KEY idx_crawl_frontier_host (host),
  KEY idx_crawl_frontier_site (site, state),
  KEY idx_crawl_frontier_seen (seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_junk (
  url_hash CHAR(40) NOT NULL,
  site VARCHAR(150) NOT NULL,
  reason VARCHAR(24) NOT NULL,
  pattern VARCHAR(80) NULL,
  at DATETIME NOT NULL,
  PRIMARY KEY (url_hash),
  KEY idx_crawl_junk_site (site, reason),
  KEY idx_crawl_junk_at (at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_skip_rules (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  rule_key CHAR(40) NOT NULL,
  site VARCHAR(150) NOT NULL,
  kind VARCHAR(12) NOT NULL,
  pattern VARCHAR(80) NOT NULL,
  reason VARCHAR(24) NOT NULL,
  hits INT UNSIGNED NOT NULL DEFAULT 0,
  made_by VARCHAR(12) NOT NULL DEFAULT 'machine',
  active TINYINT(1) NOT NULL DEFAULT 1,
  at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_crawl_skip_rules (rule_key),
  KEY idx_crawl_skip_rules_site (site, active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  at DATETIME NOT NULL,
  subject VARCHAR(6) NOT NULL,
  ref VARCHAR(150) NOT NULL,
  action VARCHAR(16) NOT NULL,
  was VARCHAR(16) NULL,
  now_is VARCHAR(16) NULL,
  reason VARCHAR(255) NULL,
  rule VARCHAR(40) NULL,
  by_uid INT UNSIGNED NULL,
  by_name VARCHAR(80) NULL,
  undone_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_crawl_audit_ref (subject, ref),
  KEY idx_crawl_audit_at (at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_batches (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  batch_key CHAR(40) NOT NULL,
  kind VARCHAR(8) NOT NULL,
  declared INT UNSIGNED NOT NULL DEFAULT 0,
  received INT UNSIGNED NOT NULL DEFAULT 0,
  stored INT UNSIGNED NOT NULL DEFAULT 0,
  rejected INT UNSIGNED NOT NULL DEFAULT 0,
  checksum CHAR(40) NULL,
  bytes INT UNSIGNED NOT NULL DEFAULT 0,
  ok TINYINT(1) NOT NULL DEFAULT 1,
  ms INT UNSIGNED NOT NULL DEFAULT 0,
  at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_crawl_batches_key (batch_key),
  KEY idx_crawl_batches_at (at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
