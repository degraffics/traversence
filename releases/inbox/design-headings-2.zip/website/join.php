<?php
// /join.php?i=… — a client's contact claims their place (decisions/0101, addendum 2026-10-28): the invite our team (or the
// business's Owner or Manager) sent them. Two boxes: activate my contact for the business, and create my Traversence
// account (or sign in, when the email already has one). The invite link proves the email, so the account is confirmed.
// It claims the person's place on the business's team, not the listing itself (that stays the claim process).
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/Clients.php';
require_once __DIR__ . '/../app/ui/page-shell.php';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');

$pdo = Database::connection();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$tok = (string) ($_GET['i'] ?? $_POST['i'] ?? '');
$i = Clients::inviteByToken($pdo, $tok);
$biz = $i ? Clients::get($pdo, (int) $i['listing_id']) : null;
$me = Auth::currentUser();
$err = '';
$hasAccount = false;
if ($i) { $st = $pdo->prepare('SELECT id FROM users WHERE email = ? AND deleted_at IS NULL'); $st->execute([strtolower((string) $i['email'])]); $hasAccount = (bool) $st->fetchColumn(); }
$mine = $me && $i && strcasecmp((string) $me['email'], (string) $i['email']) === 0;

if ($i && $biz && !$i['accepted_at'] && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    try {
        if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        if (empty($_POST['activate'])) throw new RuntimeException('Tick "Activate my contact" to claim your place.');
        if (!$mine) {
            if ($hasAccount) throw new RuntimeException('This email already has a Traversence account: sign in first.');
            if (empty($_POST['account'])) throw new RuntimeException('Tick "Create my Traversence account": your place needs an account to sign in with.');
            $pw = (string) ($_POST['password'] ?? '');
            if ($pw !== (string) ($_POST['password2'] ?? '')) throw new RuntimeException('The two passwords aren\'t the same.');
            $name = mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120);
            $u = Auth::register((string) $i['email'], $pw, $name !== '' ? $name : null);
            $pdo->prepare('UPDATE users SET email_verified_at = COALESCE(email_verified_at, NOW()) WHERE id = ?')->execute([(int) $u['id']]);   // the invite link proved the email
            Auth::attemptLogin((string) $i['email'], $pw);
            $me = Auth::currentUser();
        }
        Clients::claim($pdo, $i, (int) $me['id']);
        $_SESSION['tv_join_done'] = (string) $biz['name'];
        header('Location: /join.php?i=' . rawurlencode($tok), true, 303); exit;
    } catch (InvalidArgumentException | RuntimeException $x) {
        $err = $x instanceof PDOException ? 'That didn\'t go through. Try again.' : $x->getMessage();
        if ($x instanceof PDOException) error_log('join: ' . $x->getMessage());
    }
}
$done = $_SESSION['tv_join_done'] ?? ''; unset($_SESSION['tv_join_done']);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');

tv_page_start($biz ? 'Your place at ' . $biz['name'] : 'Your invitation', ['no_crumbs' => true, 'description' => 'Claim your place as a contact for a business on Traversence.']);
?>
<style>
  .jn{max-width:34rem;margin:0 auto;color:#3E2B1F}
  .jn h1{font:700 1.6rem var(--tv-font-head,Georgia,serif);margin:.3rem 0}
  .jn-card{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.8rem;padding:1rem;margin-top:.8rem}
  .jn form{display:grid;gap:.6rem}
  .jn label{display:grid;gap:.2rem;font-size:.92rem;color:#5C4632}
  .jn .chk{display:flex;gap:.55rem;align-items:flex-start;font-size:.98rem;color:#3E2B1F}.jn .chk input{width:1.15rem;height:1.15rem;margin-top:.15rem;accent-color:#3E2B1F;flex:none}
  .jn input[type=text],.jn input[type=password]{font:inherit;border:1px solid #CBB98D;border-radius:.5rem;padding:.55rem .65rem;background:#fff}
  .jn button,.jn a.go{justify-self:start;background:#92400E;color:#fff;border:0;border-radius:999px;padding:.6rem 1.3rem;font:700 1rem system-ui,sans-serif;cursor:pointer;text-decoration:none;display:inline-block}
  .jn .note{font-size:.88rem;color:#6B5640}
  @media (max-width:767px){.jn-card{border-radius:.5rem}}
</style>
<div class="jn">
<?php if (!$i || !$biz): ?>
  <h1>This invitation isn't here</h1>
  <div class="jn-card tv-bleed"><p>The link may be old, or the invitation was taken back. Ask the business (or reply to the email) for a new one.</p></div>
<?php elseif ($done !== '' || $i['accepted_at']): ?>
  <h1>You're in</h1>
  <div class="jn-card tv-bleed"><p>Your place at <b><?= $e($biz['name']) ?></b> is active. Your orders, proofs, invoices and artwork are on <b>Your orders</b>.</p>
    <p><a class="go" href="/user/orders.php">Open Your orders</a></p></div>
<?php else: ?>
  <h1>Your place at <?= $e($biz['name']) ?></h1>
  <p class="note">You're a contact for <?= $e($biz['name']) ?> as <b><?= $e(Team::roleName((string) $i['role'])) ?></b>: its orders, proofs, invoices and artwork with Traversence, in one place.</p>
  <?php if ($err !== ''): ?><p data-tv-flash="error"><?= $e($err) ?></p><?php endif; ?>
  <div class="jn-card tv-bleed">
  <?php if ($me && !$mine): ?>
    <p>You're signed in as <b><?= $e($me['email']) ?></b>, but this invitation is for <b><?= $e($i['email']) ?></b>. Sign out (from your account menu) and open this link again, or ask for the invitation to go to <?= $e($me['email']) ?>.</p>
  <?php elseif (!$me && $hasAccount): ?>
    <p><b><?= $e($i['email']) ?></b> already has a Traversence account. Sign in, and you'll come back here to activate your place.</p>
    <p><a class="go" href="/login.php?next=<?= $e(rawurlencode('/join.php?i=' . $tok)) ?>">Sign in to claim it</a></p>
  <?php else: ?>
    <form method="post" novalidate><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="i" value="<?= $e($tok) ?>">
      <label class="chk"><input type="checkbox" name="activate" value="1" checked> Activate my contact for <?= $e($biz['name']) ?></label>
      <?php if (!$mine): ?>
      <label class="chk"><input type="checkbox" name="account" value="1" checked data-join-acct> Create my Traversence account (free) with <?= $e($i['email']) ?></label>
      <div data-join-fields style="display:grid;gap:.6rem">
        <label>Your name<input type="text" name="name" value="<?= $e($i['name'] ?? '') ?>" maxlength="120" autocomplete="name"></label>
        <label>A password<input type="password" id="jn-pw" name="password" autocomplete="new-password" minlength="10" data-pw-not="<?= $e(strtok((string) $i['email'], '@')) ?>"></label>
        <label>The password again<input type="password" name="password2" autocomplete="new-password" data-pw-match="#jn-pw"></label>
      </div>
      <?php endif; ?>
      <button>Claim my place</button>
      <p class="note">This claims your place as a contact. Claiming the business's listing itself is separate, and the listing stays as it is.</p>
    </form>
  <?php endif; ?>
  </div>
<?php endif; ?>
</div>
<script>
(function () { var c = document.querySelector('[data-join-acct]'), f = document.querySelector('[data-join-fields]'); if (!c || !f) return;
  var set = function () { f.hidden = !c.checked; }; c.addEventListener('change', set); set(); })();
</script>
<?php tv_page_end();
