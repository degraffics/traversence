<?php
// ai/index.php — AI Assist for members (Jason, 2026-10-30): ask about anything, or write about it (a caption, a paragraph
// for a journey, a few lines for a post), answered only from what we've researched (AiAssist: the Topic index, vetted
// heritage facts, research, our guides), never from guesses. When we don't know enough yet it says so, the crawler
// researches it, and the member gets the answer by email and here when it arrives. Every ask is kept under Your asks
// (with Copy). Signed-in members with AI Assist & Learning on (their words go to Claude only then) and a paid plan, their
// own or a business's they own: a few free asks a day, then the plan's AI Assist credits (AiCredits). Restricted facts
// never leave the catalog; a story-only place is told without where it is.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/../../app/lib/Topics.php';
require_once __DIR__ . '/../../app/lib/Consent.php';
require_once __DIR__ . '/../../app/lib/Guides.php';
require_once __DIR__ . '/../../app/lib/AiCredits.php';
require_once __DIR__ . '/../../app/lib/Heritage.php';
require_once __DIR__ . '/../../app/lib/AiAssist.php';

$pdo = Database::connection();
$uid = (int) (Auth::currentUserId() ?? 0);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$on = $uid && Consent::allows($pdo, $uid, 'ai_learning');
$msg = '';
$slug = (string) ($_GET['topic'] ?? $_POST['topic'] ?? '');
if ($uid && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
    try {
        if (isset($_POST['turn_on'])) { Consent::set($pdo, $uid, 'ai_learning', true, '/ai/', true); $on = true; $msg = '<p data-tv-flash="ok">AI Assist & Learning is on. You can turn it off any time in your settings.</p>'; }
        elseif (isset($_POST['ask'])) {
            if (!$on) throw new InvalidArgumentException('Turn on AI Assist & Learning first: your words go to our AI only with it on.');
            $row = AiAssist::ask($pdo, $uid, ['ask' => (string) $_POST['ask'], 'topic' => $slug, 'pot' => (string) ($_POST['pot'] ?? ''), 'source' => $slug !== '' ? 'topic' : 'ai_page']);
            header('Location: /ai/?' . http_build_query(array_filter(['topic' => $slug, 'asked' => (int) $row['id']])) . '#a' . (int) $row['id'], true, 303); exit;   // a reload never asks (or charges) twice
        }
    } catch (Throwable $e) { $msg = '<p data-tv-flash="error">' . tv_e($e instanceof InvalidArgumentException ? $e->getMessage() : 'AI Assist couldn\'t write that just now. Please try again in a little while.') . '</p>'; if (!$e instanceof InvalidArgumentException) error_log('ai assist: ' . $e->getMessage()); }
}
$q = trim((string) ($_GET['q'] ?? ''));
$t = $slug !== '' ? Topics::record($pdo, $slug) : null;
if ($t && !$t['facts'] && trim((string) $t['summary']) === '') $t = null;   // nothing we may show about it
$list = array_values(array_filter(Topics::list($pdo, $q, 60), fn ($r) => (int) $r['vetted'] > 0));

tv_page_start('AI Assist', ['description' => 'Write about the places and topics our guides cover, from what we have researched.', 'no_crumbs' => true]);
?>
<style>
  .ai-wrap{max-width:46rem;margin:0 auto;padding:.6rem .75rem 2rem}
  .ai-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem;margin-top:.8rem}
  .ai-card h2{font:700 1.15rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:0 0 .4rem}
  .ai-note{font-size:.85rem;color:#5C4632}
  .ai-row{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.5rem}.ai-row input,.ai-row textarea{flex:1 1 14rem;min-width:0;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.55rem .7rem;font:inherit}
  .ai-btn{background:#92400E;color:#FFFBF2;border-radius:999px;padding:.5rem 1rem;font-weight:600}
  .ai-topics{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(14rem,100%),1fr));gap:3px;margin-top:.5rem}
  .ai-topic{display:block;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem;padding:.55rem .7rem}.ai-topic b{color:#92400E;text-decoration:underline}.ai-topic small{display:block;color:#8A7355}
  .ai-facts{margin:.4rem 0 0 1.1rem;list-style:disc;font-size:.92rem}.ai-facts li{margin:.2rem 0}.ai-cr{color:#8A7355}
  .ai-pot{flex:1 1 100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.45rem .6rem;font:inherit}.ai-pots{margin:.3rem 0 0 1.1rem;list-style:disc}
  .ai-ask{border-top:1px solid #EADFC4;padding:.6rem 0}.ai-ask:first-of-type{border-top:0}.ai-ask.is-new .ai-out{border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.25)}
  .ai-q{margin:0 0 .35rem}.ai-q small{color:#8A7355;font-weight:400}.ai-acts{display:flex;gap:.6rem;align-items:center;margin:.35rem 0 0}.ai-acts small{color:#8A7355}
  .ai-copy{background:#FFFBF2;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .8rem;font-weight:600;color:#92400E}
  .ai-out{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem;padding:.75rem .85rem;line-height:1.6;white-space:pre-wrap}
  @media (max-width:767px){ .ai-wrap{padding:.4rem 0 2rem}.ai-card{border-radius:.5rem;margin:3px 3px 0;padding:.85rem .8rem}.ai-wrap>h1,.ai-wrap>p{margin-left:.75rem;margin-right:.75rem} }
</style>
<main class="ai-wrap">
  <h1 class="font-serif font-bold text-2xl text-[#3E2B1F]">AI Assist</h1>
  <p class="ai-note">Write about the places and topics our guides cover: a caption, a paragraph for your journey, a few lines for a post. AI Assist writes only from what we've researched (historic records, public sources and our guides), not from guesses, and tells you when we're still learning about something.</p>
  <?= $msg ?>
  <?php if (!$uid): ?>
    <section class="ai-card tv-bleed"><p data-tv-status="info" data-tv-label="Sign in first:">AI Assist is for members. <a class="underline text-[#92400E]" href="/login.php?next=%2Fai%2F">Sign in</a> or <a class="underline text-[#92400E]" href="/register.php">create an account</a>.</p></section>
  <?php elseif (!$on): $c = Consent::TOOLS['ai_learning']; ?>
    <section class="ai-card tv-bleed">
      <h2><?= tv_e($c['name']) ?></h2>
      <p class="ai-note"><?= tv_e($c['summary']) ?></p>
      <p class="ai-note" style="white-space:pre-line;margin-top:.4rem"><?= tv_e($c['explanation']) ?></p>
      <p class="ai-note" style="margin-top:.4rem">What you ask AI Assist goes to our AI provider to write the answer. It's never shown to anyone else.</p>
      <form method="post" class="ai-row"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="topic" value="<?= tv_e($slug) ?>"><button class="ai-btn" name="turn_on" value="1">Turn on AI Assist &amp; Learning</button></form>
    </section>
  <?php endif; ?>

  <?php if ($on): ?>
    <section class="ai-card tv-bleed" id="ask">
      <h2><?= $t ? 'Ask about ' . tv_e((string) $t['name']) : 'Ask anything' ?></h2>
      <?php if ($on): $cr = AiCredits::state($pdo, $uid); $F = AiCredits::freePerDay($pdo); ?>
        <?php if (!$cr['funded']): ?>
          <p data-tv-status="info" data-tv-label="Comes with a paid plan:">AI Assist is part of Personal Plus and Personal Pro, and of every paid plan for a business (its owners share the business's credits). Each plan's AI Assist credits pay for what it writes<?= $cr['trial'] ? '. Your ' . tv_e($cr['trial']) . ' trial includes it from its first payment' : '' ?>. <a class="underline text-[#92400E]" href="/plans.php">See the plans</a></p>
        <?php else: ?>
          <form method="post" class="ai-row"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="topic" value="<?= tv_e($slug) ?>">
            <textarea name="ask" rows="2" maxlength="1000" required placeholder="<?= $t ? 'A short caption about ' . tv_e((string) $t['name']) : 'Ask anything: “Who founded St. Johns?” or “A caption for my photo of the river crossing”' ?>" aria-label="What should AI Assist write or answer?"></textarea>
            <?php $open = array_filter($cr['pots'], fn ($p) => $p['left'] > 0); if ($cr['next'] && $cr['next'] !== 'free' && count($open) > 1): ?>
              <select name="pot" aria-label="Use credits from" class="ai-pot"><?php foreach ($open as $k => $p): ?><option value="<?= tv_e($k) ?>"<?= $k === $cr['next'] ? ' selected' : '' ?>><?= tv_e($p['label']) ?>: <?= $p['left'] ?> left</option><?php endforeach; ?></select>
            <?php endif; ?>
            <button class="ai-btn"<?= $cr['next'] ? '' : ' disabled title="' . ($cr['why'] === 'cover' ? 'This month\'s limit for your plans is reached: add credits on the Plans page' : 'Today\'s free asks and this month\'s credits are used') . '"' ?>>Ask</button></form>
          <?php if ($cr['next'] === 'free'): ?>
            <p class="ai-note"><?= $cr['free_left'] ?> of <?= $F ?> free asks left today, then your AI Assist credits.</p>
          <?php elseif ($cr['next']): ?>
            <p data-tv-status="info" data-tv-label="Using credits:">Today's <?= $F ?> free asks are used, so each ask now uses one AI Assist credit<?= count($open) > 1 ? ' from the plan you choose' : ' from ' . tv_e($cr['pots'][$cr['next']]['label']) ?>.</p>
          <?php elseif ($cr['why'] === 'cover'): ?>
            <p data-tv-status="info" data-tv-label="Month's limit:">You've reached this month's AI Assist limit for your plans. It's back on the 1st, or add a +50 AI Assist credits pack (or a bigger plan) on the Plans page to keep going now. <a class="underline text-[#92400E]" href="/plans.php">Add 50 credits</a></p>
          <?php else: ?>
            <p data-tv-status="info" data-tv-label="All used:">That's today's <?= $F ?> free asks and this month's AI Assist credits. The free asks are back tomorrow. <a class="underline text-[#92400E]" href="/plans.php">Add 50 credits</a></p>
          <?php endif; ?>
          <ul class="ai-note ai-pots"><?php foreach ($cr['pots'] as $p): ?><li><?= tv_e($p['label']) ?>: <?= $p['left'] ?> of <?= $p['credits'] ?> credits left this month</li><?php endforeach; ?></ul>
        <?php endif; ?>
      <?php endif; ?>
    </section>
  <?php endif; ?>

  <?php $mine = $uid ? AiAssist::mine($pdo, $uid, 20) : []; $asked = (int) ($_GET['asked'] ?? 0); if ($mine): ?>
    <section class="ai-card tv-bleed" id="asks">
      <h2>Your asks</h2>
      <?php foreach ($mine as $m): $txt = (string) ($m['followup'] ?: $m['answer']); ?>
        <article class="ai-ask<?= (int) $m['id'] === $asked ? ' is-new' : '' ?>" id="a<?= (int) $m['id'] ?>">
          <p class="ai-q"><b><?= tv_e((string) $m['ask']) ?></b> <small><?= tv_e(date('M j, g:i a', strtotime((string) $m['created_at']))) ?></small></p>
          <?php if ($m['status'] === 'researching'): ?><p data-tv-status="info" data-tv-label="We're researching it:">We didn't know enough to answer fully yet, so our crawler is looking into it. We'll email you here and add the answer when it arrives.</p>
          <?php elseif ($m['status'] === 'followed_up'): ?><p data-tv-status="ok" data-tv-label="Answer ready:">We researched it: here's what we can tell you now (<?= tv_e(date('M j', strtotime((string) $m['followup_at']))) ?>).</p>
          <?php elseif ($m['status'] === 'closed'): ?><p data-tv-status="info" data-tv-label="Still learning:">We haven't found enough to say more about this yet.</p><?php endif; ?>
          <div class="ai-out"><?= tv_e($txt) ?></div>
          <p class="ai-acts"><button type="button" class="ai-copy" data-copy="#a<?= (int) $m['id'] ?> .ai-out">Copy</button><?php $nu = count(array_filter(explode(',', (string) $m['used']))); if ($nu): ?><small>From <?= $nu ?> of our researched facts</small><?php endif; ?></p>
        </article>
      <?php endforeach; ?>
      <p class="ai-note">Check it reads right before you post it: it's yours to edit.</p>
    </section>
  <?php endif; ?>

  <?php if ($t): $st = $t['state']; $p0 = $t['places'] ? Guides::place($pdo, (string) $t['places'][0]) : null; ?>
    <section class="ai-card tv-bleed">
      <h2><?= tv_e($t['name']) ?></h2>
      <?php if ($t['summary']): ?><p><?= tv_e((string) $t['summary']) ?></p><?php endif; ?>
      <?php if ($t['facts']): ?><ul class="ai-facts"><?php foreach (array_slice($t['facts'], 0, 6) as $f): ?><li><b><?= tv_e($f['title']) ?></b><?= $f['year_from'] ? ' (' . (int) $f['year_from'] . ')' : '' ?>: <?= tv_e($f['fact']) ?><?php $cr = Heritage::credits((string) $f['sources']); if ($cr): ?> <small class="ai-cr">(<?= tv_e(implode(', ', $cr)) ?>)</small><?php endif; ?></li><?php endforeach; ?></ul><?php endif; ?>
      <p data-tv-status="<?= $st['vetted'] >= Topics::THIN ? 'ok' : 'info' ?>" data-tv-label="What we know:"><?= $st['vetted'] ?> fact<?= $st['vetted'] === 1 ? '' : 's' ?> backed by historic records or two independent sources<?= $st['vetted'] < Topics::THIN ? '. We\'re still learning about this, and asking moves it up our research list' : '' ?>.</p>
      <?php if ($p0 && !empty($p0['url'])): ?><p class="ai-note"><a class="underline text-[#92400E]" href="<?= tv_e($p0['url']) ?>#g-footsteps">Walking in the footsteps in the <?= tv_e($p0['name']) ?> guide</a></p><?php endif; ?>
      <p class="ai-note" style="margin-top:.5rem"><a class="underline" href="/ai/">Choose another topic</a> · <a class="underline" href="/takedown.php?kind=topic&amp;ref=<?= tv_e(rawurlencode((string) $t['slug'])) ?>" rel="nofollow">Ask us to take this down</a></p>
    </section>
  <?php else: ?>
    <section class="ai-card tv-bleed">
      <h2>Choose a topic</h2>
      <form method="get" class="ai-row"><input name="q" value="<?= tv_e($q) ?>" placeholder="A place, a river, a trade, a tradition" aria-label="Find a topic"><button class="ai-btn">Find</button></form>
      <?php if ($list): ?><div class="ai-topics"><?php foreach ($list as $r): ?>
        <a class="ai-topic" href="/ai/?topic=<?= tv_e((string) $r['slug']) ?>"><b><?= tv_e((string) $r['name']) ?></b><small><?= tv_e(Topics::KINDS[$r['kind']] ?? 'Topic') ?> · <?= (int) $r['vetted'] ?> fact<?= (int) $r['vetted'] === 1 ? '' : 's' ?></small></a>
      <?php endforeach; ?></div>
      <?php else: ?><p data-tv-status="info" data-tv-label="Nothing yet:"><?= $q !== '' ? 'Our guides don\'t cover that yet.' : 'Our guides\' topics appear here as we research them.' ?></p><?php endif; ?>
    </section>
  <?php endif; ?>
</main>
<script>
document.addEventListener('click', function (e) {
  var b = e.target.closest && e.target.closest('.ai-copy'); if (!b) return;
  var el = document.querySelector(b.getAttribute('data-copy')); if (!el) return;
  var done = function () { if (window.TvAsk) TvAsk.say('Copied: paste it where you like.', { anchor: b, bad: false }); };
  if (navigator.clipboard) navigator.clipboard.writeText(el.textContent).then(done, function () {}); else { var r = document.createRange(); r.selectNodeContents(el); var sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); document.execCommand('copy'); done(); }
});
</script>
<?php tv_page_end();
