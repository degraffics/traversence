<?php
// /qr/cart.php — GO Codes: Cart and checkout (decisions/0096). Members and guests alike: a guest checks out with their
// name, email and billing address (no account needed; those details can open an account in one step afterwards).
// Checkout makes the QuickBooks invoice (sales tax from the address), then the card is taken right here: the card goes
// from the browser straight to Intuit (QuickBooks Payments), and the codes are ready the moment it's paid (decisions/0098).
// QuickBooks' own payment page stays as the other way to pay (card or bank transfer).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/QrIssue.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/go-codes.php';
tv_card_page_csp('go-cart', ['quickbooks']);   // a card page: only our scripts and Intuit's (0098; its script list there)
header('Content-Type: text/html; charset=utf-8');

$me = Auth::currentUser();
tv_page_start('GO Codes cart', ['no_crumbs' => true, 'description' => 'Your GO Codes cart and checkout.']);
?>
<div class="go">
  <h1>Cart</h1>
  <?php tv_go_head('cart'); ?>
  <p class="go-note">Plans, storage and services for you or your business are in the <a href="/shop/">Shop</a>.</p>
  <div id="go-next" style="display:flex;gap:.5rem;justify-content:flex-end;flex-wrap:wrap;margin:0 0 .5rem"></div>
  <section class="go-card tv-bleed" aria-label="Your cart">
    <ul class="go-list" id="go-items"><li class="go-note">Loading…</li></ul>
    <div id="go-totals"></div>
    <div id="go-promo" hidden style="margin-top:.5rem"><div style="display:flex;gap:.4rem"><input id="go-code" placeholder="Promo code" aria-label="Promo code" autocapitalize="characters" value="<?= htmlspecialchars(preg_replace('/[^A-Za-z0-9-]/', '', (string) ($_GET['promo'] ?? '')), ENT_QUOTES) ?>" style="flex:1;min-width:0;border:1px solid #CBB98D;border-radius:.6rem;padding:.45rem .6rem;background:#FFFBF2"><button type="button" class="go-btn" id="go-code-b">Apply</button></div><p class="go-note" id="go-code-m" style="margin-top:.3rem"></p></div>
  </section>
  <section class="go-card tv-bleed" id="go-plans-card" aria-labelledby="go-pl-h" hidden><h2 id="go-pl-h">Plans and storage</h2>
    <div id="go-plans"></div><div id="go-plans-pay" style="margin-top:.6rem"></div></section>
  <section class="go-card tv-bleed" id="go-checkout" aria-labelledby="go-co-h" hidden>
    <h2 id="go-co-h">Checkout</h2>
    <?php if (!$me): ?>
    <p class="go-note" style="margin-bottom:.4rem">Checking out as a guest: no account needed. Or <a href="/login.php?next=<?= rawurlencode('/qr/cart.php') ?>">sign in</a>
      to keep your GO Codes in one place (your cart comes with you). With an account you also get <?= QrIssue::FREE_TOTAL ?> free basic codes.</p>
    <?php endif; ?>
    <div class="go-f" id="go-bill">
      <div class="go-2"><div><label for="b-name">Name</label><input id="b-name" maxlength="120" autocomplete="name"></div><div><label for="b-email">Email (your receipt and your codes' link)</label><input id="b-email" type="email" maxlength="190" autocomplete="email"></div></div>
      <label for="b-street">Billing street</label><input id="b-street" maxlength="160" autocomplete="street-address">
      <div class="go-2"><div><label for="b-city">Town</label><input id="b-city" maxlength="80" autocomplete="address-level2"></div><div class="go-2"><div><label for="b-state">State</label><input id="b-state" maxlength="2" autocomplete="address-level1" placeholder="AZ"></div><div><label for="b-zip">ZIP</label><input id="b-zip" maxlength="10" inputmode="numeric" autocomplete="postal-code"></div></div></div>
      <button type="button" class="go-btn main wide" id="go-pay" style="margin-top:.8rem">Continue to payment</button>
      <p class="go-note" style="margin-top:.4rem">Next: sales tax is worked out from your billing address and you pay by card on this page. We never see your card number.</p>
    </div>
    <div id="go-paybox" hidden></div>
    <p class="go-note" id="go-soon" hidden style="font-weight:600">Buying opens soon. Your GO Codes stay in your cart until then.</p>
  </section>
</div>
<script<?= tv_nonce() ?>>
(function () {
  'use strict';
  var TYPES = <?= json_encode(Qr::TYPES) ?>, filled = false, showing = false;
  var items = document.getElementById('go-items'), totals = document.getElementById('go-totals'), co = document.getElementById('go-checkout');
  var plCard = document.getElementById('go-plans-card'), plList = document.getElementById('go-plans'), plPay = document.getElementById('go-plans-pay'), P = { groups: [], tokens: 0 };
  // plans and storage packs (decisions/0154 §6): by account, what's due now and how it's paid; paid with the GO Codes'
  // card entry when there are GO Codes too, else on their own here
  // domains (decisions/0169 §1a): due now for a year, on a card from the account's wallet (kept for its renewals) or a new one
  function domNote(g) {
    var opts = (g.cards || []).map(function (c) { return '<option value="' + Go.esc(c.pick) + '"' + (g.pick === c.pick ? ' selected' : '') + '>' + Go.esc(c.label) + '</option>'; }).join('');
    return 'Due now: <b>' + Go.money(g.due_now) + '</b>, for a year. ' + (opts ? '<label>Pay with <select data-plcard="' + Go.esc(g.owner_type + ':' + g.owner_id) + '" aria-label="The card that pays">' + opts + '<option value="new"' + (g.card === 'new' ? ' selected' : '') + '>A new card</option></select></label>. ' : 'On the card you enter. ')
      + 'The card is kept in ' + (g.owner_type === 'listing' ? 'the business\'s' : 'your') + ' wallet for its renewals (auto-renew, two weeks ahead; turn it off any time in Domains). Domain names aren\'t refundable once registered.';
  }
  plList.addEventListener('change', function (e) {   // which wallet card pays an account's domains
    var sel = e.target.closest('[data-plcard]'); if (!sel) return;
    var p = sel.getAttribute('data-plcard').split(':');
    TvAsk.busy(sel, true);
    Go.call('/api/domains.php', { action: 'cart_card', type: p[0], id: +p[1], pick: sel.value }).then(function () { return Go.status(); }).then(function (d) { TvAsk.busy(sel, false); paint(d); })
      .catch(function (x) { TvAsk.busy(sel, false); TvAsk.say(x.message, { anchor: sel, bad: true }); });
  });
  function paintPlans(d) {
    P.groups = d.plans || []; P.tokens = d.plan_tokens || 0;
    plCard.hidden = !P.groups.length; if (!P.groups.length) { plList.innerHTML = ''; plPay.innerHTML = ''; return; }
    plList.innerHTML = P.groups.map(function (g) {
      return '<h3 style="font:700 .95rem var(--tv-font-head,Georgia,serif);margin:.6rem 0 .2rem">' + Go.esc(g.name) + '</h3><ul class="go-list">' + g.lines.map(function (l) {
        return '<li class="go-it tv-bleed" style="min-height:0;grid-template-columns:1fr;padding-right:3rem"><div class="d"><b>' + Go.esc(l.name) + '</b><div>' + Go.money(l.cents) + (l.kind === 'oneoff' ? ', once' : ' ' + Go.esc(l.per)) + (l.kind === 'plan' ? ', renews until you stop it' : l.kind === 'oneoff' ? '' : l.kind === 'domain' ? ', then renews each year until you stop it' : ', renews with the plan') + '</div></div>'
          + '<div class="go-acts"><button type="button" data-plrm="' + l.id + '" title="Remove" aria-label="Remove from cart">×</button></div></li>';
      }).join('') + '</ul><p class="go-note">' + (g.type === 'domain' ? domNote(g) : g.type === 'oneoff' ? 'Due now: <b>' + Go.money(g.due_now) + '</b>, once. Nothing renews.' : g.card === 'new' ? 'Due now: <b>' + Go.money(g.due_now) + '</b>, then each ' + (g.cycle === 'year' ? 'year' : 'month') + ' on the card you enter (kept on file for renewals; stop any time on the Plans page).'
        : g.card === 'file' ? 'Due now: <b>' + Go.money(g.due_now) + '</b> (the rest of this period), on your card on file' + (g.card_label ? ' (' + Go.esc(g.card_label) + ')' : '') + '.'
        : '<b>' + Go.esc(g.why) + '</b>') + '</p>';
    }).join('');
    var blocked = P.groups.some(function (g) { return g.card === 'none'; }), goItems = (d.cart.items || []).length;
    if (goItems) { plPay.innerHTML = blocked ? '' : '<p class="go-note">Paid with your GO Codes below, from one card entry.</p>'; return; }
    if (blocked) { plPay.innerHTML = ''; return; }
    var due = P.groups.reduce(function (t, g) { return t + (g.due_now || 0); }, 0);
    plPay.innerHTML = '<button type="button" class="go-btn main wide" data-plpay>' + (P.tokens ? 'Continue to payment' : 'Pay ' + Go.money(due) + ' with your card on file') + '</button>';
  }
  document.getElementById('go-next').addEventListener('click', function (e) {   // Checkout: to the pay step (the plans' own when there are no GO Codes)
    var c = e.target.closest('[data-go-checkout]'); if (!c) return; e.preventDefault();
    var t = document.querySelector(c.getAttribute('href')); if (!t) return; t.scrollIntoView({ block: 'start', behavior: 'smooth' });
    var f = t.querySelector('[data-plpay], #b-name'); if (f) setTimeout(function () { f.focus(); }, 400);
  });
  plList.addEventListener('click', function (e) {
    var rm = e.target.closest('[data-plrm]'); if (!rm) return;
    if (!TvAsk.gate(rm, 'Take this out of your cart?', { yes: 'Remove', danger: true })) return;
    Go.go({ action: 'plan_remove', line: +rm.getAttribute('data-plrm') }).then(paint).catch(function (x) { TvAsk.say(x.message, { anchor: rm, bad: true }); });
  });
  plPay.addEventListener('click', function (e) {
    var b = e.target.closest('[data-plpay]'); if (!b) return;
    var due = P.groups.reduce(function (t, g) { return t + (g.due_now || 0); }, 0), done = function () {
      var dom = P.groups.filter(function (g) { return g.type === 'domain'; })[0];   // domains bought: their Domains tab
      location.href = dom && P.groups.every(function (g) { return g.type === 'domain' || g.type === 'oneoff'; }) ? (dom.owner_type === 'listing' ? '/business/' + dom.owner_id + '/domains' : '/user/domains/')
        : P.groups.every(function (g) { return g.type === 'oneoff'; }) ? '/user/dashboard.php' : '/plans.php?' + (P.groups[0] && P.groups[0].type === 'listing' ? 'listing=' + P.groups[0].id : 'me=1'); };
    if (!P.tokens) { TvAsk.busy(b, true); Go.go({ action: 'plans_pay', tokens: [] }).then(done).catch(function (x) { TvAsk.busy(b, false); TvAsk.say(x.message, { anchor: b, bad: true }); }); return; }
    var st = Go.last(); showing = true;
    Go.cardForm(plPay, { id: 'pl', subtotal_cents: due, tax_cents: 0, total_cents: due }, st ? st.pay : { test: false, token_url: '' }, {
      summary: false, amount: due, tokens: P.tokens, note: P.groups.some(function (g) { return g.type !== 'oneoff'; }) ? 'Your card is kept in your wallet (QuickBooks Payments holds it) for renewals. Stop any time on the Plans page' + (P.groups.some(function (g) { return g.type === 'domain'; }) ? ', or in Domains for a domain' : '') + '.' : 'Charged once; nothing renews.',
      pay: function (t) { return Go.go({ action: 'plans_pay', tokens: Array.isArray(t) ? t : [t] }); }, onPaid: done,
      onCancel: function () { showing = false; Go.status().then(paint); }
    });
  });
  function paint(d) {
    if (showing) return;   // paying: the cart is empty now; what's being bought and the card form stay as they are
    paintPlans(d);
    var it = d.cart.items;
    items.innerHTML = it.length ? it.map(function (i) {
      return '<li class="go-it tv-bleed" style="min-height:6rem"><img src="/api/qr.php?issued=' + i.id + '&format=png&px=200" alt="" loading="lazy">'
        + '<div class="d"><a class="nm" href="/qr/?fix=' + i.id + '">' + Go.esc(i.title) + '</a><div>' + Go.esc(TYPES[i.type] || i.type) + ' · ' + Go.money(i.price_cents) + '</div></div>'
        + '<div class="go-acts"><a href="/qr/?fix=' + i.id + '" title="Change what it says" aria-label="Change what it says"><?= str_replace("'", "\\'", tv_icon('pen', 'go-ic')) ?></a>'
        + '<button type="button" data-rm="' + i.id + '" title="Remove" aria-label="Remove from cart">×</button></div></li>';
    }).join('') : (d.plans && d.plans.length ? '' : '<li class="go-note">Your cart is empty. <a href="/shop/">Continue shopping</a> in the Shop, or <a href="/qr/">make a GO Code</a>.</li>');
    totals.innerHTML = it.length ? (d.cart.off_cents ? '<div class="go-sum" style="font-weight:400;color:#166534"><span>Code ' + Go.esc(d.promo.code) + ': ' + Go.esc(d.promo.offer) + '</span><span>−' + Go.money(d.cart.off_cents) + '</span></div>' : '')
      + '<div class="go-sum"><span>Subtotal (' + it.length + ' GO Code' + (it.length === 1 ? '' : 's') + ')</span><span>' + Go.money(d.cart.subtotal_cents) + '</span></div><p class="go-note">Plus sales tax, worked out at checkout.</p>' : '';
    document.getElementById('go-promo').hidden = !it.length;
    items.hidden = !it.length && !!(d.plans && d.plans.length);   // only plans in the cart: no empty GO Codes list above them
    var any = it.length + (d.plans || []).length;   // something in the cart: keep shopping, or go to checkout
    document.getElementById('go-next').innerHTML = any ? '<a class="go-btn" href="/shop/">Continue shopping</a><a class="go-btn main" href="#' + (it.length ? 'go-checkout' : 'go-plans-card') + '" data-go-checkout>Checkout</a>' : '';
    document.getElementById('go-code-m').innerHTML = d.promo ? 'Applied. <a href="#" id="go-unpromo">Remove the code</a>' : '';
    co.hidden = !it.length;   // plans alone pay in their own box above
    document.getElementById('go-bill').hidden = !d.buying_open; document.getElementById('go-soon').hidden = d.buying_open;
    if (!filled && d.bill) { filled = true; if (d.bill.name) document.getElementById('b-name').value = d.bill.name; if (d.bill.email) document.getElementById('b-email').value = d.bill.email; }
  }
  items.addEventListener('click', function (e) {
    var rm = e.target.closest('[data-rm]'); if (!rm) return;
    if (!TvAsk.gate(rm, 'Take this out of your cart?', { yes: 'Remove', danger: true })) return;
    Go.go({ action: 'remove', id: +rm.getAttribute('data-rm') }).then(paint).catch(function (x) { TvAsk.say(x.message, { anchor: rm }); });
  });
  function applyCode() {
    var c = document.getElementById('go-code').value.trim(), m = document.getElementById('go-code-m'); if (!c) return;
    Go.go({ action: 'promo', code: c }).then(paint).catch(function (x) { m.textContent = x.message; });
  }
  document.getElementById('go-code-b').addEventListener('click', applyCode);
  document.getElementById('go-promo').addEventListener('click', function (e) { if (e.target.id === 'go-unpromo') { e.preventDefault(); document.getElementById('go-code').value = ''; Go.go({ action: 'unpromo' }).then(paint); } });
  if (document.getElementById('go-code').value) setTimeout(applyCode, 300);
  var paybox = document.getElementById('go-paybox'), bill = document.getElementById('go-bill');
  document.getElementById('go-pay').addEventListener('click', function (e) {
    var b = e.currentTarget, v = function (id) { return document.getElementById(id).value; };
    b.disabled = true; b.textContent = 'Working out the tax…';
    Go.go({ action: 'checkout', bill: { name: v('b-name'), email: v('b-email'), street: v('b-street'), city: v('b-city'), state: v('b-state'), zip: v('b-zip') } }).then(function (d) {
      var o = d.order, st = Go.last();
      bill.hidden = true; paybox.hidden = false; showing = true;
      document.getElementById('go-co-h').textContent = 'Pay';
      var need = P.tokens, withPlans = P.groups.length > 0 && !P.groups.some(function (g) { return g.card === 'none'; });
      Go.cardForm(paybox, o, st ? st.pay : { test: false, token_url: '' }, {
        name: v('b-name'), zip: v('b-zip'),
        // plans and packs in the cart too: they're paid first (a plan that starts keeps this card on file), then the GO Codes
        tokens: withPlans ? need + 1 : 1,
        pay: withPlans ? function (t) { var ts = Array.isArray(t) ? t : [t];
          return Go.go({ action: 'plans_pay', tokens: ts.slice(0, need) }).then(function () { return Go.go({ action: 'pay', order_id: o.id, token: ts[need] }); }); } : undefined,
        note: withPlans ? 'This also pays your plans and storage: ' + P.groups.map(function (g) { return g.name + ' ' + Go.money(g.due_now); }).join(', ') + ', on top of the GO Codes total above. The card is kept on file for the plan\'s renewals.' : undefined,
        label: withPlans ? 'Pay ' + Go.money(o.total_cents + P.groups.reduce(function (t, g) { return t + (g.due_now || 0); }, 0)) + ' in all' : undefined,
        onPaid: function (r) { location.href = o.manage; },
        onCancel: function () { Go.go({ action: 'cancel', order_id: o.id }).then(function (s) { showing = false; paybox.hidden = true; paybox.innerHTML = ''; document.getElementById('go-co-h').textContent = 'Checkout'; paint(s); }).catch(function (x) { TvAsk.say(x.message); }); }
      });
      paybox.scrollIntoView({ block: 'start', behavior: 'smooth' });
    }).catch(function (x) { TvAsk.say(x.message, { anchor: b }); }).then(function () { b.disabled = false; b.textContent = 'Continue to payment'; });
  });
  Go.status().then(paint).catch(function (x) { items.innerHTML = '<li class="go-note">' + Go.esc(x.message) + '</li>'; });
})();
</script>
<?php tv_page_end(['footer' => 'checkout']); ?>
