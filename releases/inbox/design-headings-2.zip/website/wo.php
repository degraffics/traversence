<?php
// /wo.php?w=… — a work order for a vendor (decisions/0101, addendum 2026-10-28): what to make, how many, the specs, where
// it ships, when it's due, and its files to download (&f=<key>). A private link, emailed from orders@trvgo.us, that
// works for 30 days from when it's sent; an expired one offers Request a new link, emailed to the vendor's address on
// the work order, never shown here (decisions/0150). Never a dead end: every state where the link doesn't work also
// offers Send a new link to my email and Ask our team (Vendors::helpBox). No prices, no client billing. Printable.
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/WorkOrders.php';
header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$pdo = Database::connection();
$w = WorkOrders::byToken($pdo, (string) ($_GET['w'] ?? ''));
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$old = $w ? null : WorkOrders::byTokenAny($pdo, (string) ($_GET['w'] ?? ''));   // its link has expired
$canNew = $old && !in_array((string) ($old['status'] ?? 'sent'), WorkOrders::NO_NEW_LINK, true);

require_once __DIR__ . '/../app/lib/Vendors.php';
// the help box (when the link doesn't work): a new link to my email, or a note to our team
if (!$w && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['help'])) {
    $_SESSION['tv_wo_flash'] = Vendors::handleHelp($pdo, $_POST);
    header('Location: /wo.php?w=' . rawurlencode((string) ($_GET['w'] ?? '')), true, 303); exit;
}

// Request a new link (decisions/0150): it goes to the address on the work order, a few a day, each logged
if ($canNew && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $msg = ['ok', 'We\'ve sent a new link to the email address we have for you. It works for ' . WorkOrders::DAYS . ' days.'];
    try {
        if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        if (!Vendors::mayRequest($pdo, 'wo', (int) $old['id'])) { Vendors::logRequest($pdo, 'wo', (int) $old['id'], false); throw new RuntimeException('We\'ve already sent ' . Vendors::REQUESTS_A_DAY . ' new links today. Check your email (and spam), or ask our team below and we\'ll send one by hand.'); }
        WorkOrders::renewLink($pdo, $old, true);
        Vendors::logRequest($pdo, 'wo', (int) $old['id'], true);
    } catch (Throwable $x) {
        if (!($x instanceof RuntimeException) || $x instanceof PDOException) error_log('work order new link: ' . $x->getMessage());
        $msg = ['error', $x instanceof RuntimeException && !($x instanceof PDOException) ? $x->getMessage() : 'That didn\'t go through. Try again, or ask our team below.'];
    }
    $_SESSION['tv_wo_flash'] = $msg;
    header('Location: /wo.php?w=' . rawurlencode((string) $_GET['w']), true, 303); exit;
}

if ($w && isset($_GET['f'])) {   // one of its files
    $f = WorkOrders::file($pdo, $w, (string) $_GET['f']);
    $name = $f ? preg_replace('/[^A-Za-z0-9._-]+/', '-', $f[1]) : '';
    if ($f) { require_once __DIR__ . '/../app/lib/Store.php'; Store::redirect($f[0], $name, $f[2], false); }   // in S3
    if (!$f || !is_file($f[0])) { http_response_code(404); header('Content-Type: text/plain; charset=utf-8'); echo 'That file isn\'t here any more. Reply to the work order email and we\'ll send it again.'; exit; }
    header('Content-Type: ' . $f[2]);
    header('Content-Length: ' . filesize($f[0]));
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('X-Content-Type-Options: nosniff');
    readfile($f[0]); exit;
}

// our team sees the page as the vendor does (a preview): it isn't counted as opened, and its buttons are off
require_once __DIR__ . '/../app/lib/QuickBooksPay.php';
$preview = $w && QuickBooksPay::staffHere($pdo);

// the vendor moves it along from here (accept, decline, in production, shipped, ready, complete)
$ok = ''; $err = '';
if ($w && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    try {
        if ($preview) throw new RuntimeException('This is a preview: the vendor\'s buttons don\'t act from our side. Change the work order from its order.');
        if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $_SESSION['tv_wo_flash'] = ['ok', WorkOrders::vendorMove($pdo, $w, (string) ($_POST['to'] ?? ''), $_POST)];
    } catch (Throwable $x) {
        if (!($x instanceof RuntimeException) || $x instanceof PDOException) error_log('work order page: ' . $x->getMessage());
        $_SESSION['tv_wo_flash'] = ['error', $x instanceof RuntimeException && !($x instanceof PDOException) ? $x->getMessage() : 'That didn\'t go through. Try again, or reply to the email.'];
    }
    header('Location: /wo.php?w=' . rawurlencode((string) $w['token']), true, 303); exit;
}
if (isset($_SESSION['tv_wo_flash'])) { [$k, $m] = $_SESSION['tv_wo_flash']; unset($_SESSION['tv_wo_flash']); if ($k === 'ok') $ok = $m; else $err = $m; }

header('Content-Type: text/html; charset=utf-8');
if (!$w) http_response_code($canNew ? 410 : 404);   // expired: gone, with its way back
elseif (!$preview) WorkOrders::opened($pdo, $w);
$items = $w ? WorkOrders::items($pdo, $w) : [];
$files = $w ? WorkOrders::files($pdo, $w) : [];
$from = getenv('ORDERS_REPLY_TO') ?: (getenv('SMTP_REPLY_TO') ?: 'support@traversence.com');   // questions go to support@ (orders@ only sends)
$st = (string) ($w['status'] ?? 'sent'); $moves = $w ? (WorkOrders::VENDOR_MOVES[$st] ?? []) : []; $parts = $w ? WorkOrders::parts($w) : [];
$due = $w ? WorkOrders::dueAt($w) : null; $csrf = (string) ($_SESSION['csrf_token'] ?? '');
$hid = '<input type="hidden" name="csrf" value="' . $e($csrf) . '">';
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow">
<title><?= $w ? 'Work order ' . $e($w['wo_no']) : 'Work order' ?> · Traversence</title>
<style>
  :root{--ink:#3E2B1F;--brown:#92400E;--line:#E3D3AC;--cream:#FBF6EA;--card:#FFFDF8}
  *{box-sizing:border-box}
  body{margin:0;background:var(--cream);color:var(--ink);font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
  main{max-width:52rem;margin:0 auto;padding:1rem 3px 2rem}
  header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-end;gap:.5rem;border-bottom:2px solid var(--ink);padding:0 .6rem .5rem;margin-bottom:.8rem}
  h1{font:700 1.6rem var(--tv-font-head,Georgia,serif);margin:0}
  .wo-no{font:700 1.15rem var(--tv-font-head,Georgia,serif);color:var(--brown)}
  .card{background:var(--card);border:1px solid var(--line);border-radius:.5rem;padding:.8rem;margin:0 0 3px}
  h2{font:700 .78rem system-ui,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#7A5A3A;margin:0 0 .4rem}
  .meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(13rem,1fr));gap:3px;margin-bottom:3px}
  .meta .card{margin:0}
  pre{font:inherit;white-space:pre-wrap;margin:0}
  table{width:100%;border-collapse:collapse}
  th,td{text-align:left;padding:.45rem .3rem;border-bottom:1px solid var(--line);vertical-align:top}
  th{font-size:.75rem;letter-spacing:.06em;text-transform:uppercase;color:#7A5A3A}
  td.n{text-align:right;white-space:nowrap;font-weight:700}
  .opt{color:#6B5640;font-size:.9rem}
  ul.files{list-style:none;margin:0;padding:0}
  ul.files li{display:flex;flex-wrap:wrap;gap:.3rem .6rem;align-items:center;justify-content:space-between;padding:.45rem 0;border-bottom:1px solid var(--line)}
  ul.files b{overflow-wrap:anywhere}
  .kind{font-size:.8rem;color:#6B5640}
  a.dl{display:inline-block;background:var(--brown);color:#fff;text-decoration:none;border-radius:999px;padding:.3rem .9rem;font-weight:600;font-size:.9rem}
  .note{font-size:.88rem;color:#6B5640}.wo-pj{font:600 .95rem system-ui,sans-serif;color:#3E2B1F;margin-top:.1rem}
  .due{margin-top:.35rem}.due b{display:block}
  form :disabled{opacity:.5;cursor:not-allowed}
  .pv{background:#FFF4D6;border:1px solid #E8C872;border-radius:.5rem;padding:.5rem .7rem;margin:0 0 .7rem;font-size:.9rem;color:#6B4A0E}
  .acts{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.6rem}
  button.pr{background:none;border:1px solid var(--brown);color:var(--brown);border-radius:999px;padding:.3rem .9rem;font:600 .9rem system-ui,sans-serif;cursor:pointer}
  .st{display:inline-block;border-radius:999px;padding:.15rem .7rem;font-weight:700;font-size:.85rem;background:#E7F3EC;color:#1F5133}
  .st.warn{background:#FEF3C7;color:#7A4B00}.st.bad{background:#FBE3E3;color:#7F1D1D}
  .act{display:grid;gap:.5rem}.act form{display:grid;gap:.45rem;border-top:1px solid var(--line);padding-top:.6rem}.act form:first-child{border-top:0;padding-top:0}
  .act label{display:grid;gap:.15rem;font-size:.9rem;color:#5C4632}.act input,.act textarea,.act select{font:inherit;border:1px solid #CBB98D;border-radius:.45rem;padding:.45rem .55rem;background:#FFFBF2;width:100%;box-sizing:border-box}
  .act .row{display:grid;grid-template-columns:repeat(auto-fit,minmax(11rem,1fr));gap:.45rem}.act .chk{display:flex;gap:.45rem;align-items:center}.act .chk input{width:auto}
  button.go{background:var(--brown);color:#fff;border:0;border-radius:999px;padding:.5rem 1.1rem;font:700 .95rem system-ui,sans-serif;cursor:pointer;justify-self:start}
  .act button.go,.act button.no{justify-self:center;min-width:12rem}
  button.no{background:none;color:#7F1D1D;border:1px solid #E7A9A9;border-radius:999px;padding:.4rem 1rem;font:600 .9rem system-ui,sans-serif;cursor:pointer;justify-self:start}
  <?= Vendors::HELP_CSS ?>
  .msg{border-radius:.4rem;padding:.6rem .8rem;margin:0 0 3px;font-weight:600}.msg.ok{background:#E3F1D9;border:1px solid #A9D18E}.msg.err{background:#FBE3E3;border:1px solid #E7A9A9}
  /* printed: one sheet (Jason, 2026-10-28): tight margins and type, the four facts in one row, files listed by name */
  @page{size:letter;margin:.4in}
  @media print{
    body{background:#fff;font-size:10pt;line-height:1.3}
    main{max-width:none;padding:0}
    .acts,a.dl,.act,.msg,.pv,.no-print{display:none!important}
    header{padding:0 0 .3rem;margin-bottom:.4rem}h1{font-size:16pt}.wo-no{font-size:12pt}
    .card{border-color:#999;border-radius:0;padding:.35rem .5rem;margin:0 0 .25rem;break-inside:avoid}
    .meta{grid-template-columns:repeat(4,1fr);gap:.25rem;margin-bottom:.25rem}
    h2{font-size:7.5pt;margin:0 0 .15rem}
    th,td{padding:.15rem .2rem}th{font-size:7pt}.opt{font-size:8.5pt}.note{font-size:8.5pt}
    ul.files li{padding:.1rem 0;border-bottom:0}.kind{font-size:8pt}
    .due{margin-top:.15rem}
  }
</style></head>
<body><main>
<?php if (!$w): $where = $old ? 'work order ' . $old['wo_no'] . ' (' . $old['vendor'] . ', #' . (int) $old['id'] . ')' : 'a work order link we don\'t know'; ?>
  <header><h1>Traversence</h1></header>
  <?php if ($ok !== ''): ?><p class="msg ok" role="status">✓ <?= $e($ok) ?></p><?php endif; ?><?php if ($err !== ''): ?><p class="msg err" role="alert">! <?= $e($err) ?></p><?php endif; ?>
  <?php if ($canNew): ?>
  <div class="card"><h2>This link has expired</h2><p style="margin:0 0 .7rem">Work order links work for <?= (int) WorkOrders::DAYS ?> days. We'll email a new one to the address we have for you.</p>
    <form method="post"><?= $hid ?><button class="go">Request a new link</button></form></div>
  <?= Vendors::helpBox($csrf, $where, $err !== '') ?>
  <?php elseif ($old): ?>
  <div class="card"><h2>This work order is closed</h2><p style="margin:0">Work order <?= $e($old['wo_no']) ?> is <?= $e(strtolower(WorkOrders::STATUS[(string) $old['status']] ?? (string) $old['status'])) ?>, so its link no longer opens it. Ask our team if you still need it.</p></div>
  <?= Vendors::helpBox($csrf, $where, true) ?>
  <?php elseif ($ok !== ''): ?>
  <div class="card"><p style="margin:0">Open the link in that email. This one no longer works.</p></div>
  <?= Vendors::helpBox($csrf, $where, false) ?>
  <?php else: ?>
  <div class="card"><p style="margin:0">This work order link isn't right, or a newer one has replaced it. Use the link in our latest email, or get a new one here.</p></div>
  <?= Vendors::helpBox($csrf, $where, true) ?>
  <?php endif; ?>
<?php else: ?>
  <?php if ($preview): ?><div class="pv">Preview: this is the page <?= $e($w['vendor']) ?> sees. Its files download as theirs do; its buttons are off for you here.<?= $w['sent_at'] ? '' : ' Not sent yet.' ?></div><?php endif; ?>
  <header><div><h1>Traversence</h1><div class="note">Work order for <?= $e($w['vendor']) ?></div></div><div class="wo-no">Work order <?= $e($w['wo_no']) ?><?php if (($w['project'] ?? '') !== ''): ?><div class="wo-pj"><?= $e($w['project']) ?></div><?php endif; ?><?php if (isset($w['status'])): ?><br><span class="st<?= in_array($st, ['declined', 'rejected', 'cancelled'], true) ? ' bad' : ($st === 'sent' ? ' warn' : '') ?>"><?= $e(WorkOrders::STATUS[$st] ?? $st) ?></span><?php endif; ?></div></header>
  <?php if ($ok !== ''): ?><p class="msg ok" role="status">✓ <?= $e($ok) ?></p><?php endif; ?><?php if ($err !== ''): ?><p class="msg err" role="alert">! <?= $e($err) ?></p><?php endif; ?>
  <div class="meta">
    <div class="card"><h2>Ordered</h2><?= $e(date('F j, Y', strtotime((string) ($w['sent_at'] ?: $w['created_at'])))) ?><?php if ($due): ?><div class="due">Must Have By:<b><?= $e(date('l, F j, Y', $due)) ?></b><?php if (!empty($w['due_time'])): ?><b><?= $e(date('g:i a', $due)) ?></b><?php endif; ?></div><?php else: ?><div class="due">Must Have By:<b>Not set: ask us before you schedule it</b></div><?php endif; ?>
      <?php if (($w['po_no'] ?? '') !== ''): ?><br>P.O. <?= $e($w['po_no']) ?><?php endif; ?>
      <?php if (($w['job_no'] ?? '') !== '' || !empty($w['accepted_by'])): ?><br><?= !empty($w['accepted_by']) ? 'Received by ' . $e($w['accepted_by']) : '' ?><?= ($w['job_no'] ?? '') !== '' ? (!empty($w['accepted_by']) ? ' · ' : '') . 'Your job ' . $e($w['job_no']) : '' ?><?php endif; ?></div>
    <div class="card"><h2>Delivery</h2><?php if (($w['delivery'] ?? '') !== ''): ?><b><?= $e(WorkOrders::DELIVERY[$w['delivery']] ?? $w['delivery']) ?></b><br><?php endif; ?><?php $dv = (string) ($w['delivery'] ?? ''); ?>
      <?= $w['ship_to'] !== '' ? '<pre>' . $e($w['ship_to']) . '</pre>' : '' ?>
      <?php if ($dv === 'courier' && ($w['tracking'] ?? '') === ''): ?><span class="note">We book the courier and send you the tracking number once it's secured.</span>
      <?php elseif ($dv === 'will_call'): ?><span class="note">We pick it up: mark it ready below when it is.</span>
      <?php elseif ($dv === '' && $w['ship_to'] === ''): ?><span class="note">As each item says, or ask us.</span><?php endif; ?>
      <?php if (($w['tracking'] ?? '') !== ''): ?><br>Tracking: <?= $e(trim(($w['carrier'] ?? '') . ' ' . $w['tracking'])) ?><?php endif; ?></div>
    <?php if (isset($w['cost_cents']) && $w['cost_cents'] !== null): ?><div class="card"><h2>Total cost</h2><b><?= $e(Orders::usd((int) $w['cost_cents'])) ?></b>
</div><?php elseif ($preview && array_key_exists('cost_cents', $w)): ?><div class="card"><h2>Total cost</h2><b>Not set yet</b><div class="note">Our team only: add it on the work order (Use the vendor's share of the ticked items' COGS). It can't be sent without it; they accept or decline at that cost.</div></div><?php endif; ?>
    <div class="card"><h2>Bill and questions</h2>Traversence<br><a href="mailto:<?= $e($from) ?>?subject=<?= rawurlencode('Work order ' . $w['wo_no']) ?>"><?= $e($from) ?></a><br><span class="note">Never contact our client directly.</span></div>
  </div>
  <section class="card" aria-labelledby="it-h"><h2 id="it-h">What to make</h2>
    <table><tr><th>Item and specs</th><th style="text-align:right">How many</th></tr>
    <?php foreach ($items as $l): $n = $l['product'] === 'product' ? ClientOrders::runQty($l) : (int) $l['qty']; ?>
      <tr><td><b><?= $e(preg_replace('/ · [\d,]+$/', '', (string) $l['title'])) ?></b><?php $pt = $parts[(int) $l['id']] ?? ['', '']; if ($pt[0] !== '' || $pt[1] !== ''): ?><div class="opt"><?= $pt[0] !== '' ? 'Product ' . $e($pt[0]) : '' ?><?= $pt[1] !== '' ? ($pt[0] !== '' ? ' · ' : '') . 'your part # <b>' . $e($pt[1]) . '</b>' : '' ?></div><?php endif; ?><?php $sp = WorkOrders::specs($l, $pt); if ($sp !== ''): ?><div class="opt" style="white-space:pre-line"><?= $e($sp) ?></div><?php endif; ?><?php if (($l['ship_address'] ?? '') !== ''): ?><div class="opt">Ships to: <?= $e($l['ship_address']) ?></div><?php endif; ?></td>
        <td class="n"><?= number_format($n) ?></td></tr>
    <?php endforeach; ?></table>
  </section>
  <?php if ($w['note'] !== ''): ?><section class="card"><h2>Production notes</h2><pre><?= $e($w['note']) ?></pre></section><?php endif; ?>
  <section class="card" aria-labelledby="f-h"><h2 id="f-h">Files (<?= count($files) ?>)</h2>
    <?php if (!$files): ?><p class="note" style="margin:0">No files with this work order: we'll send them separately.</p><?php else: ?><ul class="files">
    <?php foreach ($files as $f): ?><li><span><b><?= $e($f[1]) ?></b> <span class="kind"><?= $e($f[2]) ?></span></span><a class="dl" href="/wo.php?w=<?= $e($w['token']) ?>&amp;f=<?= $e($f[0]) ?>" download>Download</a></li><?php endforeach; ?></ul><?php endif; ?>
    <p class="note no-print" style="margin:.5rem 0 0">This link works until <?= $e(date('F j, Y', strtotime((string) $w['expires_at']))) ?>.</p>
  </section>
  <?php $draftPv = $preview && $st === 'draft'; if ($draftPv) { $moves = WorkOrders::VENDOR_MOVES['sent'] ?? []; } ?>
  <?php if ($moves): ?>
  <section class="card act" aria-labelledby="up-h"><h2 id="up-h"><?= $st === 'sent' || $draftPv ? 'Accept this work order' : 'Update where it stands' ?></h2><?php if ($draftPv): ?><p class="note" style="margin:.2rem 0 .5rem">Not sent yet: once it's sent, the vendor accepts or rejects it here.</p><?php endif; ?>
    <?php if (in_array('accepted', $moves, true)): ?>
    <form method="post"><?= $hid ?><input type="hidden" name="to" value="accepted">
      <div class="row"><label>Received by (agent's name)<input name="accepted_by" maxlength="120" autocomplete="name"></label><label>Your job number<input name="job_no" maxlength="60" autocomplete="off"></label></div>
      <button class="go">Accept order</button></form>
    <form method="post"><?= $hid ?><input type="hidden" name="to" value="declined"><label>Production comments<textarea name="why" rows="2" maxlength="500"></textarea></label><button class="no">Reject order</button></form>
    <?php endif; ?>
    <?php if (in_array('production', $moves, true)): ?><form method="post"><?= $hid ?><input type="hidden" name="to" value="production"><button class="go">It's in production</button></form><?php endif; ?>
    <?php if (in_array('shipped', $moves, true)): ?><form method="post"><?= $hid ?><input type="hidden" name="to" value="shipped">
      <div class="row"><label>Carrier<select name="carrier"><option value="">Choose…</option><?php foreach (['USPS', 'UPS', 'FedEx', 'Courier', 'Freight', 'Other'] as $c): ?><option<?= ($w['delivery'] ?? '') !== '' && stripos(WorkOrders::DELIVERY[$w['delivery']] ?? '', $c) !== false ? ' selected' : '' ?>><?= $c ?></option><?php endforeach; ?></select></label><label>Tracking number<input name="tracking" maxlength="160" autocomplete="off"></label></div>
      <button class="go">It's shipped</button></form><?php endif; ?>
    <?php if (in_array('ready', $moves, true)): ?><form method="post"><?= $hid ?><input type="hidden" name="to" value="ready"><button class="go"><?= ($w['delivery'] ?? '') === 'will_call' ? 'Ready for us to pick up' : 'It\'s ready for pickup' ?></button></form><?php endif; ?>
    <?php if (in_array('complete', $moves, true)): ?><form method="post"><?= $hid ?><input type="hidden" name="to" value="complete"><button class="go"><?= $st === 'ready' ? 'Picked up: complete' : 'Delivered: complete' ?></button></form><?php endif; ?>
  </section>
  <?php endif; ?>
  <div class="acts"><button type="button" class="pr" onclick="window.print()">Print the work order</button></div>
<?php endif; ?>
<?php if ($preview): ?><script>document.querySelectorAll('form button, form input:not([type=hidden]), form textarea, form select').forEach(function (x) { x.disabled = true; x.title = 'The vendor uses this; it\'s off in your preview.'; });</script><?php endif; ?>
</main></body></html>
