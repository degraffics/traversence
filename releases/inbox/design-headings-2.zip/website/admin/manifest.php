<?php
// admin/manifest.php — printable shipping papers for a client order (Shipments, decisions/0101). Our team only.
//   ?id=        the master manifest: every destination, its lots and its packs
//   &dest=      one destination's manifest
//   &pack=      one pack's packing slip
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/Orders.php';
require_once __DIR__ . '/../../app/lib/Shipments.php';

$pdo = Database::connection();
tv_crawler_require_admin($pdo);
$oid = (int) ($_GET['id'] ?? 0);
$o = Orders::get($pdo, $oid);
if (!$o || !ClientOrders::isClient($o) || !Shipments::ready($pdo)) { http_response_code(404); echo 'That order isn\'t here.'; exit; }
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$dests = Shipments::destinations($pdo, $o); $lotsBy = Shipments::lots($pdo, $oid); $packs = Shipments::packs($pdo, $oid);
$lineBy = array_column(Orders::lines($pdo, $oid), null, 'id');
$lotName = function (array $lt) use ($lineBy): string { return ($lineBy[(int) $lt['line_id']]['title'] ?? '') . ($lt['label'] !== '' ? ' · ' . $lt['label'] : ''); };
$allLots = []; foreach ($lotsBy as $ls) foreach ($ls as $lt) $allLots[(int) $lt['id']] = $lt;
$onlyDest = (int) ($_GET['dest'] ?? 0); $onlyPack = (int) ($_GET['pack'] ?? 0);
if ($onlyPack && !isset($packs[$onlyPack])) { http_response_code(404); echo 'That pack isn\'t here.'; exit; }
$carr = ClientOrders::CARRIERS;
$title = $onlyPack ? 'Packing slip' : ($onlyDest ? 'Manifest' : 'Master manifest');
header('Content-Type: text/html; charset=utf-8');
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= $e($title . ' · ' . ClientOrders::ref($o)) ?></title><?php require_once __DIR__ . '/../../app/ui/favicon.php'; echo tv_favicon_links(); ?>
<style>
  body{font:14px/1.45 system-ui,sans-serif;color:#111;margin:24px auto;max-width:800px;padding:0 16px}
  h1{font:700 22px var(--tv-font-head,Georgia,serif);margin:0}h2{font:700 16px system-ui;margin:22px 0 6px;border-bottom:2px solid #111;padding-bottom:3px}h3{font:700 14px system-ui;margin:14px 0 4px}
  .hd{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;border-bottom:3px solid #111;padding-bottom:8px;margin-bottom:12px}.hd small{display:block;color:#444}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:16px}table{width:100%;border-collapse:collapse;margin-top:4px}th,td{text-align:left;border-bottom:1px solid #ccc;padding:5px 4px;vertical-align:top}
  th{font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#555}td.n{text-align:right;white-space:nowrap}.box{border:1px solid #999;padding:8px 10px;margin-top:10px}
  .chk{display:inline-block;width:14px;height:14px;border:1.5px solid #111;vertical-align:-2px}.warn{color:#b45309;font-weight:700}.p{page-break-after:always}
  .noprint{margin-bottom:12px}@media print{.noprint{display:none}body{margin:0}}
</style></head><body>
<p class="noprint"><button onclick="print()">Print</button></p>
<?php
$head = function (string $t, string $sub) use ($o, $e) { ?>
  <div class="hd"><div><h1>Traversence</h1><small><?= $e(implode(' · ', ClientOrders::FROM)) ?></small></div>
    <div style="text-align:right"><h1><?= $e($t) ?></h1><small>Order <?= $e(ClientOrders::ref($o)) ?><?= ($o['po_number'] ?? '') !== '' ? ' · P.O. ' . $e($o['po_number']) : '' ?></small><small><?= $e($sub) ?></small></div></div>
  <div class="two"><div><b>Client</b><br><?= $e($o['client_company'] ?: $o['bill_name']) ?><?= $o['client_company'] !== '' ? '<br>' . $e($o['bill_name']) : '' ?><br><?= $e($o['client_phone']) ?> <?= $e($o['bill_email']) ?></div><div></div></div>
<?php };
$destBlock = function (int $did, array $d, int $n) use ($lotsBy, $packs, $lotName, $carr, $e, $o) {
    $dl = []; foreach ($lotsBy as $ls) foreach ($ls as $lt) if ((int) $lt['dest_id'] === $did) $dl[] = $lt;
    $dp = array_filter($packs, fn ($p) => (int) $p['dest_id'] === $did); ?>
  <h2>Destination <?= $n ?>: <?= $e($d['label']) ?></h2>
  <div class="two"><div><b>Ship to</b><br><?= $e($d['name'] ?: ($o['client_company'] ?: $o['bill_name'])) ?><br><?= $e($d['street']) ?><br><?= $e(trim($d['city'] . ', ' . $d['state'] . ' ' . $d['zip'], ', ')) ?></div>
    <div><b>Method</b><br><?= $e($d['method'] ?: '—') ?><br><?= count($dp) ?> pack<?= count($dp) === 1 ? '' : 's' ?></div></div>
  <table><thead><tr><th>Item · lot</th><th class="n">Qty</th><th class="n">Packed</th><th>In packs</th></tr></thead><tbody>
  <?php foreach ($dl as $lt): $where = []; $pn = 0; foreach ($dp as $pid => $p) { $pn++; if (!empty($p['items'][(int) $lt['id']])) $where[] = 'Pack ' . $pn . ' (' . $p['items'][(int) $lt['id']] . ')'; } ?>
    <tr><td><?= $e($lotName($lt)) ?></td><td class="n"><?= (int) $lt['qty'] ?></td><td class="n<?= (int) $lt['packed'] < (int) $lt['qty'] ? ' warn' : '' ?>"><?= (int) $lt['packed'] ?></td><td><?= $e(implode(', ', $where)) ?></td></tr>
  <?php endforeach; ?></tbody></table>
  <?php $pn = 0; foreach ($dp as $p): $pn++; ?>
  <div class="box"><b>Pack <?= $pn ?></b> <?= $e($p['box']) ?><?= (float) $p['weight_lb'] ? ' · ' . $e(rtrim(rtrim((string) $p['weight_lb'], '0'), '.')) . ' lb' : '' ?><?= $p['carrier'] !== '' ? ' · ' . $e($carr[$p['carrier']] ?? '') . ' ' . $e($p['service']) : '' ?><?= $p['tracking'] !== '' ? ' · tracking ' . $e($p['tracking']) : '' ?></div>
  <?php endforeach;
};
if ($onlyPack) {   // one pack's slip: what's in this box, to check off
    $p = $packs[$onlyPack]; $d = $dests[(int) $p['dest_id']] ?? ['label' => '', 'name' => '', 'street' => '', 'city' => '', 'state' => '', 'zip' => '', 'method' => ''];
    $sameDest = array_values(array_filter($packs, fn ($x) => (int) $x['dest_id'] === (int) $p['dest_id']));
    $n = array_search($onlyPack, array_map(fn ($x) => (int) $x['id'], $sameDest), true) + 1;
    $head('Packing slip', 'Pack ' . $n . ' of ' . count($sameDest) . ' · ' . $d['label']); ?>
  <div class="two"><div><b>Ship to</b><br><?= $e($d['name'] ?: ($o['client_company'] ?: $o['bill_name'])) ?><br><?= $e($d['street']) ?><br><?= $e(trim($d['city'] . ', ' . $d['state'] . ' ' . $d['zip'], ', ')) ?></div>
    <div><b>This pack</b><br><?= $e($p['box'] ?: '—') ?><?= (float) $p['weight_lb'] ? '<br>' . $e(rtrim(rtrim((string) $p['weight_lb'], '0'), '.')) . ' lb' : '' ?><?= $p['carrier'] !== '' ? '<br>' . $e(($carr[$p['carrier']] ?? '') . ' ' . $p['service']) : '' ?><?= $p['tracking'] !== '' ? '<br>Tracking ' . $e($p['tracking']) : '' ?></div></div>
  <h2>In this pack</h2>
  <table><thead><tr><th></th><th>Item · lot</th><th class="n">Qty</th></tr></thead><tbody>
  <?php foreach ((array) ($p['items'] ?? []) as $lid => $q): ?><tr><td><span class="chk"></span></td><td><?= $e(isset($allLots[$lid]) ? $lotName($allLots[$lid]) : '') ?></td><td class="n"><?= (int) $q ?></td></tr><?php endforeach; ?>
  </tbody></table>
  <p style="margin-top:24px">Packed by ____________________ &nbsp; Checked by ____________________ &nbsp; Date __________</p>
<?php } else {
    $head($title, $onlyDest ? ($dests[$onlyDest]['label'] ?? '') : count($dests) . ' destination' . (count($dests) === 1 ? '' : 's'));
    $n = 0;
    foreach ($dests as $did => $d) { $n++; if ($onlyDest && $did !== $onlyDest) continue; $destBlock($did, $d, $n); }
}
?>
</body></html>
