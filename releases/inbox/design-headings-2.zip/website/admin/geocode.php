<?php
// admin/geocode.php — Admin → Crawler → Map points (decisions/0053 follow-up). Street addresses become map points
// through the U.S. Census geocoder (api/lib/Geocoder.php), 500 at a time. "Find points" keeps going batch after batch
// while the page is open; it can be stopped at any time and picks up where it left off. Also from the command line:
// php api/scripts/geocode_listings.php. Admin-only; the run is a POST with the session's CSRF token.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/Geocoder.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {   // one batch, as JSON
    header('Content-Type: application/json; charset=utf-8');
    if (!hash_equals($csrf, (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) { http_response_code(403); echo json_encode(['ok' => false, 'error' => 'Your session expired. Reload the page.']); exit; }
    @set_time_limit(240);
    try { echo json_encode(['ok' => true] + Geocoder::run($pdo, Geocoder::BATCH)); }
    catch (RuntimeException $e) { echo json_encode(['ok' => false, 'error' => $e->getMessage()]); }
    catch (Throwable $e) { error_log('geocode: ' . $e->getMessage()); echo json_encode(['ok' => false, 'error' => 'Something went wrong. The log has the details.']); }
    exit;
}
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
$n = Geocoder::counts($pdo);
tv_crawler_start('geocode', 'Map points', $pdo, 'Most listings were imported with the middle of their ZIP area as their map point, so a town&rsquo;s listings stack on one spot. This turns street addresses into real map points with the U.S. Census geocoder (free). It only replaces a point that is missing or is just the ZIP&rsquo;s middle, never one a person set, and never touches confidential listings.');
$pct = $n['total'] ? round(100 * $n['with_point'] / $n['total']) : 0;
?>
<style>
  .gc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:.6rem;margin-top:1rem;max-width:60rem}
  .gc-c{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;padding:.7rem .85rem}
  .gc-c b{display:block;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.5rem;color:#3E2B1F}.gc-c span{font-size:.8rem;color:#5C4632}
  .gc-bar{height:10px;border-radius:999px;background:#EADFC4;overflow:hidden;max-width:60rem;margin-top:1rem}.gc-bar i{display:block;height:100%;background:#15803D}
  .gc-run{margin-top:1rem;display:flex;flex-wrap:wrap;gap:.6rem;align-items:center}
  .gc-b{background:#3E2B1F;color:#FFFBF2;border:0;border-radius:.7rem;padding:.55rem 1.1rem;font-weight:600;cursor:pointer}.gc-b[disabled]{opacity:.55}
  .gc-b.no{background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D}
  .gc-log{margin-top:.8rem;font-size:.85rem;color:#3E2B1F;max-width:60rem;white-space:pre-line}
  .gc-note{font-size:.8rem;color:#5C4632;max-width:60rem;margin-top:1rem}
</style>
<div class="gc-bar" title="<?= $pct ?>% have a map point"><i style="width:<?= $pct ?>%"></i></div>
<div class="gc-grid">
  <div class="gc-c"><b id="gc-with"><?= number_format($n['with_point']) ?></b><span>of <?= number_format($n['total']) ?> listings have a map point (<?= $pct ?>%)</span></div>
  <div class="gc-c"><b id="gc-todo"><?= number_format($n['to_do']) ?></b><span>street addresses waiting to be placed</span></div>
  <div class="gc-c"><b><?= number_format($n['found']) ?></b><span>placed by the Census so far</span></div>
  <div class="gc-c"><b><?= number_format($n['not_found']) ?></b><span>the Census couldn&rsquo;t place (tried again in 90 days, or when the address changes)</span></div>
  <div class="gc-c"><b><?= number_format($n['mailonly']) ?></b><span>mailing address only: PO box, HC or rural route</span></div>
  <div class="gc-c"><b><?= number_format($n['milepost']) ?></b><span>mile markers (“Hwy 60 MP 342”): highway and milepost kept</span></div>
  <div class="gc-c"><b><?= number_format($n['nonumber']) ?></b><span>a road with no number (“Hwy 191”, “County Road 3140”)</span></div>
  <div class="gc-c"><b><?= number_format($n['private']) ?></b><span>confidential: never mapped, phone only</span></div>
  <div class="gc-c"><b><?= number_format($n['no_address']) ?></b><span>have no street address yet (the crawler&rsquo;s refresh fills these from their websites)</span></div>
</div>
<div class="gc-run">
  <button type="button" class="gc-b" id="gc-go"<?= $n['to_do'] ? '' : ' disabled' ?>>Find map points</button>
  <button type="button" class="gc-b no" id="gc-stop" hidden>Stop</button>
  <span class="gc-note" style="margin:0"><?= Geocoder::BATCH ?> at a time; keep this page open while it runs.</span>
</div>
<div class="gc-log" id="gc-log" aria-live="polite"></div>
<p class="gc-note"><b>Rural places without a street address</b> (mailing-only, mile markers, roads with no number) aren&rsquo;t dropped. They get their point another way:
  the business&rsquo;s own website map, read by the crawler; staff, with <b>Pick on the map</b> on Edit listing; or a visitor&rsquo;s pin through <b>Tell us</b> (drop a pin, or &ldquo;I&rsquo;m here now&rdquo;), applied from Review with <b>Use this map point</b>.
  Mile markers keep their highway and milepost for an Arizona milepost lookup (ADOT&rsquo;s milepost data) when it&rsquo;s loaded.</p>
<p class="gc-note">Points come from the Census Bureau&rsquo;s address ranges, so a point can be a few doors off. On the map, listings still without a point keep showing at the middle of their ZIP area, marked as approximate.
  From a server&rsquo;s cron: <code>php api/scripts/geocode_listings.php --all</code>.</p>
<script>
(function () {
  var go = document.getElementById('gc-go'), stop = document.getElementById('gc-stop'), log = document.getElementById('gc-log'), running = false, tot = { found: 0, not_found: 0, skipped: 0, private: 0 };
  function say(t) { log.textContent = t; }
  function batch() {
    if (!running) { say(log.textContent + '\nStopped. Press Find map points to carry on.'); return; }
    fetch(location.pathname, { method: 'POST', credentials: 'include', headers: { 'X-CSRF-Token': <?= json_encode($csrf) ?> } })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) throw new Error(d.error || 'That batch failed.');
        ['found', 'not_found', 'skipped', 'private'].forEach(function (k) { tot[k] += d[k] || 0; });
        document.getElementById('gc-todo').textContent = (d.left || 0).toLocaleString();
        say('Placed ' + tot.found.toLocaleString() + ' · couldn\'t place ' + tot.not_found.toLocaleString() + ' · no street address to send (mailing-only, mile markers, roads with no number, confidential) ' + (tot.skipped + tot.private).toLocaleString()
          + '\n' + (d.left ? d.left.toLocaleString() + ' to go…' : 'All done. Reload to see the totals.'));
        if (d.left && (d.sent || d.skipped || d.private)) setTimeout(batch, 800); else end();
      }).catch(function (e) { say(log.textContent + '\n' + e.message); end(); });
  }
  function end() { running = false; go.disabled = false; stop.hidden = true; }
  go.addEventListener('click', function () { running = true; go.disabled = true; stop.hidden = false; say('Sending the first ' + <?= Geocoder::BATCH ?> + ' addresses to the Census…'); batch(); });
  stop.addEventListener('click', function () { running = false; stop.hidden = true; });
})();
</script>
<?php tv_crawler_end();
