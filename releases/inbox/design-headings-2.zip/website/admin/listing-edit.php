<?php
// admin/listing-edit.php?id=N — an admin edits a live listing (Admin → Crawler).
//
// Every field shows what belongs in it and its limit (IntakeStager::FIELD_RULES); saving uses the same
// validation as approving. Edits are recorded as a person's (source 'admin', locked), so the crawler never
// overwrites them. Also: view on site, hide from site / put back. Admin-only; POSTs carry the CSRF token.

declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';

$pdo = Database::connection();
$me = tv_listing_staff_require($pdo);   // admins and regional managers (decisions/0073 §6)
require_once __DIR__ . '/../../app/lib/crawler/ListingExtractor.php';   // phone validation
require_once __DIR__ . '/../../app/lib/PageCache.php';
require_once __DIR__ . '/../../app/lib/ListingCategories.php';
require_once __DIR__ . '/../../app/ui/category-fields.php';
require_once __DIR__ . '/../../app/lib/Nexus.php';
require_once __DIR__ . '/../../app/lib/ListingSafety.php';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
$R = IntakeStager::FIELD_RULES;

$form = null;   // what was typed, when a save is refused
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $action = (string) ($_POST['action'] ?? 'save');
        if ($action === 'closed' || $action === 'reopen') {   // closed: still listed, shown as Closed (decisions/0072)
            require_once __DIR__ . '/../../app/lib/SuggestionActions.php';
            if ($action === 'closed') SuggestionActions::markClosed($pdo, $id, (int) $me['id']); else SuggestionActions::reopen($pdo, $id);
            tv_crawler_flash([true, $action === 'closed' ? 'Shown as Closed: still listed, last in search, never open now.' : 'Shown as open again.']);
        } elseif ($action === 'hide' || $action === 'show') {
            // Remove from the site (decisions/0076 §4): kept, with why and who, and put back in one tap
            IntakeStager::setSuppressed($pdo, $id, $action === 'hide');
            if ($action === 'hide') {
                $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at) VALUES (?, 'removed', ?, 'admin', 1, NOW(), NOW())
                               ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = 'admin', is_locked = 1, updated_at = NOW()")
                    ->execute([$id, json_encode(['at' => date('Y-m-d'), 'by' => (int) $me['id'], 'reason' => mb_substr(trim((string) ($_POST['reason'] ?? '')), 0, 300)], JSON_UNESCAPED_UNICODE)]);
            } else {
                $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = 'removed'")->execute([$id]);
            }
            try { require_once __DIR__ . '/../../app/lib/SearchIndex.php'; SearchIndex::indexListings($pdo, [$id]); } catch (Throwable) {}
            tv_crawler_flash([true, $action === 'hide' ? 'Removed from the site. It\'s kept here: Put back brings it back.' : 'Back on the site.']);
        } else {
            IntakeStager::adminSave($pdo, $id, $_POST, (int) $me['id']);
            if (array_key_exists('office_address', $_POST)) {   // a private-address shelter's public office (decisions/0076)
                $oa = mb_substr(trim((string) $_POST['office_address']), 0, 255);
                if ($oa === '') $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = 'office_address'")->execute([$id]);
                else $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at) VALUES (?, 'office_address', ?, 'admin', 1, NOW(), NOW())
                                    ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = 'admin', is_locked = 1, updated_at = NOW()")->execute([$id, json_encode($oa, JSON_UNESCAPED_UNICODE)]);
            }
            if (array_key_exists('aka', $_POST)) {   // its other names, one per line (decisions/0084)
                require_once __DIR__ . '/../../app/lib/Aliases.php';
                Aliases::set($pdo, $id, preg_split('/[\r\n]+/', (string) $_POST['aka']) ?: [], 'admin');
                try { require_once __DIR__ . '/../../app/lib/SearchIndex.php'; SearchIndex::indexListings($pdo, [$id]); } catch (Throwable) {}
            }
            if (!empty($_POST['also_cat_sent']) && ListingCategories::ready($pdo)) ListingCategories::set($pdo, $id, (array) ($_POST['also_cat'] ?? []), (int) $me['id']);   // also listed under (decisions/0073)
            tv_crawler_flash([true, 'Saved. The crawler won\'t overwrite these edits.']);
        }
        PageCache::forget($pdo, 'hub:support');
        header('Location: /admin/listing-edit.php?id=' . $id, true, 303);
        exit;
    } catch (InvalidArgumentException $e) {
        $form = $_POST;
        tv_crawler_flash([false, $e->getMessage()]);
    }
}

$e = IntakeStager::existingListing($pdo, $id);
tv_crawler_start('edit', $e ? 'Edit listing' : 'Listing not found', $pdo,
    $e ? 'Change what the public sees. Each field says what belongs in it. Saved edits are marked as a person\'s, so the crawler never overwrites them.' : '');
if (!$e) { tv_crawler_end(); exit; }

$meta = fn (string $k) => $e['meta'][$k]['value'] ?? '';
$val = function (string $k, $fallback) use ($form) {
    if ($form !== null) return (string) ($form[$k] ?? '');
    return is_array($fallback) ? implode("\n", array_map('strval', $fallback)) : (string) $fallback;
};
$lockedNote = fn (string $k) => !empty($e['meta'][$k]['locked']) ? ' <span class="le-lock">edited by ' . tv_e((string) $e['meta'][$k]['source']) . '</span>' : '';
$cats = IntakeStager::leafCategories($pdo);
$field = function (string $name, string $label, string $value, string $help, array $o = []) use ($lockedNote) {
    $metaKey = $o['meta'] ?? $name;
    $input = !empty($o['area'])
        ? '<textarea class="le-in" name="' . $name . '" rows="' . ($o['rows'] ?? 4) . '"' . (!empty($o['max']) ? ' maxlength="' . $o['max'] . '"' : '') . '>' . tv_e($value) . '</textarea>'
        : '<input class="le-in" name="' . $name . '" value="' . tv_e($value) . '"' . (!empty($o['max']) ? ' maxlength="' . $o['max'] . '"' : '') . (!empty($o['attrs']) ? ' ' . $o['attrs'] : '') . '>';
    return '<label class="le-f"><span class="le-l">' . tv_e($label) . $lockedNote($metaKey) . '</span>' . $input . '<span class="le-h">' . tv_e($help) . '</span></label>';
};
$limit = fn (string $k) => $R[$k]['help'] . (isset($R[$k]['items']) ? " Up to {$R[$k]['items']} lines, {$R[$k]['each']} characters each." : " Up to {$R[$k]['max']} characters.");
?>
<style>
  .le-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem;margin-top:1rem;max-width:52rem}
  .le-f{display:block;margin-top:.8rem}
  .le-l{display:block;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355;margin-bottom:.2rem}
  .le-in{width:100%;background:#FFFBF2;border:1px solid rgba(203,185,141,.8);border-radius:.6rem;padding:.45rem .6rem;font-size:.9rem;color:#3E2B1F;box-sizing:border-box}
  .le-h{display:block;font-size:.75rem;color:#8A7355;margin-top:.2rem}
  .le-lock{text-transform:none;letter-spacing:0;color:#166534;margin-left:.4rem}
  .le-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(12rem,100%),1fr));gap:0 .8rem}
  .le-b{font-weight:600;border-radius:.7rem;padding:.5rem 1.1rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;text-decoration:none;display:inline-block;font-size:.9rem}
  .le-b.go{background:#D97706;border-color:#D97706;color:#fff}.le-b.no{color:#991B1B;border-color:#FCA5A5}
  .le-sec{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.05rem;margin-top:0}
  .le-block{border-top:1px solid rgba(203,185,141,.6);padding-top:.8rem;margin-top:.9rem}
  .le-block:first-of-type{border-top:0;margin-top:0;padding-top:0}
</style>

<div class="flex flex-wrap items-center gap-2 mt-3 text-sm">
  <strong class="font-serif text-lg mr-1"><?= tv_e($e['name']) ?></strong>
  <span class="text-[#8A7355]">#<?= $e['id'] ?> · <?= tv_e((string) $e['status']) ?><?= $e['cluster_name'] ? ' · ' . tv_e(preg_replace('/\s*\(auto-seeded[^)]*\)/i', '', (string) $e['cluster_name'])) : '' ?><?= isset($e['meta']['closed']) ? ' · <strong class="text-red-800">Closed</strong>' : '' ?><?php $rm = (int) $e['is_suppressed'] ? (array) ($e['meta']['removed']['value'] ?? []) : []; ?><?= (int) $e['is_suppressed'] ? ' · <strong class="text-red-800">removed from the site</strong>' . (!empty($rm['at']) ? ' ' . tv_e((string) $rm['at']) : '') . (!empty($rm['reason']) ? ': ' . tv_e((string) $rm['reason']) : '') : '' ?></span>
  <a class="le-b" href="/listing/view.php?id=<?= $e['id'] ?>" data-peek-frame>View on site</a>
  <?php $siteUrl = (string) ($e['meta']['website']['value'] ?? ''); if ($siteUrl !== '' && IntakeStager::canUseIntake($pdo, $me)): ?><a class="le-b" href="/admin/listing-intake.php?url=<?= tv_e(rawurlencode(preg_match('#^https?://#i', $siteUrl) ? $siteUrl : 'https://' . $siteUrl)) ?>" title="Read its website for the about, offerings, hours and more">Crawl its website</a><?php endif; ?>
  <form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>">
    <?php if (isset($e['meta']['closed'])): ?><input type="hidden" name="action" value="reopen"><button class="le-b" type="submit">It's open again</button>
    <?php else: ?><input type="hidden" name="action" value="closed"><button class="le-b" type="submit" data-confirm="Mark it closed? It stays on the site, shown as Closed." data-yes="Mark it closed">Mark closed</button><?php endif; ?>
  </form>
  <form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>">
    <?php if ((int) $e['is_suppressed']): ?><input type="hidden" name="action" value="show"><button class="le-b" type="submit">Put back on the site</button>
    <?php else: ?><input type="hidden" name="action" value="hide"><input class="le-in" style="width:auto;display:inline-block;padding:.4rem .6rem" name="reason" maxlength="300" placeholder="Why remove it? (optional)" aria-label="Why remove it">
      <button class="le-b no" type="submit" data-confirm="Remove this listing from the site? It's kept here, and Put back brings it back." data-yes="Remove it" data-danger>Remove from the site</button><?php endif; ?>
  </form>
</div>
<?php // Part of a Nexus (decisions/0054): an organization with many locations
if (Nexus::ready($pdo)):
    $st0 = $pdo->prepare('SELECT nexus_id, nexus_role FROM entities WHERE id = ?'); $st0->execute([$e['id']]); $nxRow = $st0->fetch(PDO::FETCH_ASSOC) ?: [];
    $nxCur = !empty($nxRow['nexus_id']) ? Nexus::get($pdo, (int) $nxRow['nexus_id']) : null; ?>
<div class="le-card le-nx tv-bleed" id="le-nx" data-e="<?= (int) $e['id'] ?>" data-csrf="<?= tv_e($csrf) ?>">
  <p class="le-sec">Part of a Nexus <span class="text-xs font-normal text-[#8A7355]">one organization with many locations</span></p>
  <?php if ($nxCur): ?>
    <p class="text-sm mt-1">Part of <a class="underline text-[#92400E] font-bold" href="/admin/nexus.php?id=<?= (int) $nxCur['id'] ?>"><?= tv_e($nxCur['name']) ?></a>
      as its <select class="le-in" style="width:auto;display:inline-block;padding:.2rem .4rem" data-nx-role><?php foreach (Nexus::ROLES as $k => $l): ?><option value="<?= $k ?>"<?= $k === ($nxRow['nexus_role'] ?? 'location') ? ' selected' : '' ?>><?= tv_e(mb_strtolower($l)) ?></option><?php endforeach; ?></select>
      · <?= max(0, (int) $nxCur['members'] - 1) ?> other location<?= (int) $nxCur['members'] - 1 === 1 ? '' : 's' ?>
      · <button type="button" class="underline text-red-800" data-nx-out>Take it out</button></p>
  <?php else: ?>
    <div class="flex flex-wrap gap-2 items-center mt-1">
      <input class="le-in" style="flex:1 1 14rem" type="search" data-nx-find placeholder="Find a Nexus by name, e.g. Changepoint" autocomplete="off">
      <select class="le-in" style="width:auto" data-nx-newrole aria-label="Its role"><?php foreach (Nexus::ROLES as $k => $l): ?><option value="<?= $k ?>"><?= tv_e($l) ?></option><?php endforeach; ?></select>
      <a class="le-b" href="/admin/nexus.php?from=<?= (int) $e['id'] ?>">Create a Nexus from this listing</a>
    </div>
    <div data-nx-list class="mt-1"></div>
  <?php endif; ?>
</div>
<script>
(function () {
  var box = document.getElementById('le-nx'); if (!box) return;
  var EID = +box.getAttribute('data-e'), CSRF = box.getAttribute('data-csrf');
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function api(b) { return fetch('/admin/api/nexus.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF }, body: JSON.stringify(b) })
    .then(function (r) { return r.json(); }).then(function (j) { if (j && j.success === false) throw new Error((j.error && j.error.message) || 'Not saved.'); return j.data || j; }); }
  var role = box.querySelector('[data-nx-role]');
  if (role) role.addEventListener('change', function () { api({ action: 'role', entity: EID, role: role.value }).then(function () { TvAsk.say('Role saved.', { anchor: role }); }).catch(function (x) { TvAsk.say(x.message, { anchor: role }); }); });
  var out = box.querySelector('[data-nx-out]');
  if (out) out.addEventListener('click', function () {
    if (!TvAsk.gate(out, 'Take it out of this Nexus? It stays listed.', { yes: 'Take it out', danger: true })) return;
    api({ action: 'remove', entity: EID }).then(function () { location.reload(); }).catch(function (x) { TvAsk.say(x.message, { anchor: out }); });
  });
  var find = box.querySelector('[data-nx-find]'), list = box.querySelector('[data-nx-list]'), t = null;
  if (find) find.addEventListener('input', function () {
    clearTimeout(t); var q = find.value.trim(); if (q.length < 2) { list.innerHTML = ''; return; }
    t = setTimeout(function () {
      api({ action: 'find', q: q }).then(function (d) {
        var items = d.items || [];
        list.innerHTML = items.length ? items.map(function (n) { return '<p class="text-sm mt-1"><b>' + esc(n.name) + '</b> <span class="text-[#8A7355]">' + n.members + ' listing' + (n.members === 1 ? '' : 's') + '</span> <button type="button" class="le-b" style="padding:.25rem .7rem" data-nx-add="' + n.id + '">Add it to this</button></p>'; }).join('')
          : '<p class="text-sm mt-1 text-[#8A7355]">No Nexus by that name. Create one from this listing.</p>';
      });
    }, 250);
  });
  box.addEventListener('click', function (e) {
    var b = e.target.closest('[data-nx-add]'); if (!b) return;
    b.disabled = true;
    api({ action: 'add', entity: EID, nexus: +b.getAttribute('data-nx-add'), role: box.querySelector('[data-nx-newrole]').value }).then(function () { location.reload(); })
      .catch(function (x) { b.disabled = false; TvAsk.say(x.message, { anchor: b }); });
  });
})();
</script>
<?php endif; ?>
<?php if ($e['claimed']): ?><p class="text-sm mt-2 text-amber-900">This listing is claimed by its owner. Change only what's clearly wrong; the owner manages the rest.</p><?php endif; ?>

<form method="post" class="le-card">
  <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="action" value="save">

  <div class="le-block"><p class="le-sec">What</p>
  <?= $field('name', 'Business name', $val('name', $e['name']), $R['name']['help'], ['max' => $R['name']['max']]) ?>
  <?php require_once __DIR__ . '/../../app/lib/Aliases.php'; ?>
  <div class="le-f"><label class="le-l" for="le-aka">Other names it goes by</label>
    <textarea class="le-in" id="le-aka" name="aka" rows="2" placeholder="One per line: a former name, its legal name"><?= tv_e($form !== null ? (string) ($form['aka'] ?? '') : implode("\n", Aliases::get($pdo, $e['id']))) ?></textarea>
    <small class="block text-xs text-[#8A7355] mt-1">Shown on its page as "Also known as", found by search, and matched by the crawler, so the same place under another name isn't listed twice.</small></div>
  <?php $also = $form !== null ? array_map('intval', (array) ($form['also_cat'] ?? [])) : array_column(ListingCategories::get($pdo, $e['id']), 'id'); ?>
  <div class="le-f" data-cat-more data-max="<?= ListingCategories::MAX ?>"<?= tv_cat_staff_attrs($pdo) ?>><label class="le-l" for="le-cat">Category</label>
    <div class="tv-cat-line"><select class="le-in" id="le-cat" name="category_id" data-cat-pick required><?= tv_cat_options($cats, (int) ($form['category_id'] ?? $e['category_id'])) ?></select><?= ListingCategories::ready($pdo) ? tv_cat_add_button() : '' ?></div>
    <?= ListingCategories::ready($pdo) ? tv_cat_more_rows($cats, $also, 'le-in') : '' ?>
    <span class="le-h">The main category shows on its card. + lists it under up to <?= ListingCategories::MAX ?> more, so it's found there too (after the businesses whose main category it is).</span></div>
  <?= $field('offerings', 'Offerings', $val('offerings', $meta('offerings')), $limit('offerings'), ['area' => true, 'rows' => 6]) ?>
  <?= $field('description', 'Description', $val('description', $meta('description')), $limit('description'), ['area' => true, 'rows' => 5, 'max' => $R['description']['max']]) ?>

  </div>
  <div class="le-block"><p class="le-sec">Where</p>
  <?= $field('address', 'Street address', $val('address', $meta('address')), 'Street number and name. Leave the town and ZIP to their own fields.', ['max' => 255]) ?>
  <?php if (ListingSafety::isConfidential($e['category_id'] !== null ? (int) $e['category_id'] : null, (string) $e['name'])): ?>
  <p class="text-sm mt-2 text-amber-900">This is a domestic-violence shelter or safe house: its street address and map pin never show on the site. Its phone and the 24-hour lines do.</p>
  <?= $field('office_address', 'Public office address (optional)', $val('office_address', $meta('office_address')), 'Only an office or outreach address the shelter publishes itself, on its own website. Never the shelter\'s.', ['max' => 255]) ?>
  <?php endif; ?>
  <div class="le-grid">
    <?= $field('city', 'City', $val('city', $meta('city')), 'The town as people say it.', ['max' => 120]) ?>
    <?= $field('state', 'State', $val('state', $meta('state')), 'Two letters: AZ, NM.', ['max' => 2]) ?>
    <label class="le-f"><span class="le-l">ZIP</span><input class="le-in" value="<?= tv_e((string) $e['primary_zip']) ?>" disabled><span class="le-h">Moving a listing to another ZIP is done in Crawler → Places.</span></label>
  </div>
  <div class="le-grid">
    <?= $field('latitude', 'Latitude', $val('latitude', $e['latitude']), 'Map pin. Paste from Google Maps if the pin is wrong.', ['attrs' => 'inputmode="decimal"']) ?>
    <?= $field('longitude', 'Longitude', $val('longitude', $e['longitude']), ' ', ['attrs' => 'inputmode="decimal"']) ?>
  </div>
  <?php // rural places often have no street address the Census can place: staff set the pin here (decisions/0053, map points) ?>
  <p class="le-h" style="margin:.2rem 0 .4rem"><button type="button" id="le-pick" style="background:#FFFBF2;border:1px solid #CBB98D;border-radius:999px;padding:.3rem .8rem;font-weight:600;cursor:pointer"><?= tv_icon('map', 'tv-ei') ?> Pick on the map</button>
    Tap where the place is, then drag the pin to adjust. Pasting “34.5061, -109.3601” from Google Maps into Latitude fills both.</p>
  <div id="le-map" style="height:300px;border:1px solid #CBB98D;border-radius:.8rem;margin-bottom:.6rem" hidden></div>
  <script>
  (function () {
    var la = document.querySelector('[name="latitude"]'), lo = document.querySelector('[name="longitude"]'), el = document.getElementById('le-map'), map = null, mk = null;
    if (!la || !lo) return;
    la.addEventListener('input', function () {   // a pasted "lat, lon" pair
      var m = la.value.match(/^\s*(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)\s*$/); if (m) { la.value = m[1]; lo.value = m[2]; if (mk) { mk.setLatLng([+m[1], +m[2]]); map.panTo([+m[1], +m[2]]); } }
    });
    function put(p) { la.value = p.lat.toFixed(6); lo.value = p.lng.toFixed(6); }
    document.getElementById('le-pick').addEventListener('click', function () {
      el.hidden = false;
      var go = function () {
        if (map) { map.invalidateSize(); return; }
        var has = la.value !== '' && lo.value !== '', c = has ? [+la.value, +lo.value] : [34.2, -110.0];
        map = L.map(el).setView(c, has ? 15 : 7);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors', referrerPolicy: 'strict-origin-when-cross-origin' }).addTo(map);
        mk = L.marker(c, { draggable: true }).addTo(map);
        mk.on('dragend', function () { put(mk.getLatLng()); });
        map.on('click', function (e) { mk.setLatLng(e.latlng); put(e.latlng); });
      };
      if (window.L) return go();
      var cdn = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/', c = document.createElement('link'); c.rel = 'stylesheet'; c.href = cdn + 'leaflet.min.css'; document.head.appendChild(c);
      var s = document.createElement('script'); s.src = cdn + 'leaflet.min.js'; s.onload = go; document.head.appendChild(s);
    });
  })();
  </script>
  <?= $field('service_area', 'Service area', $val('service_area', $meta('service_area')), $limit('service_area'), ['area' => true, 'rows' => 3]) ?>

  </div>
  <div class="le-block"><p class="le-sec">When · Who · Why</p>
  <?= $field('hours', 'Hours', $val('hours', $meta('hours')), $limit('hours'), ['area' => true, 'rows' => 4]) ?>
  <?= $field('audience', 'Audience', $val('audience', $meta('audience')), $limit('audience'), ['area' => true, 'rows' => 3]) ?>
  <?= $field('highlights', 'Highlights', $val('highlights', $meta('highlights')), $limit('highlights'), ['area' => true, 'rows' => 3]) ?>

  </div>
  <div class="le-block"><p class="le-sec">How to reach them</p>
  <div class="le-grid">
    <?= $field('phone', 'Phone', $val('phone', $meta('phone')), 'The main public number, 10 digits.', ['attrs' => 'type="tel"']) ?>
    <?= $field('email', 'Email', $val('email', $meta('email')), 'A public contact address only. A link typed here moves to Contact or booking page.') ?>
    <?= $field('website', 'Website', $val('website', $meta('website')), 'Starts with https://', ['attrs' => 'type="url"']) ?>
    <?= $field('whatsapp', 'WhatsApp', $val('whatsapp', $meta('whatsapp')), 'Only if they publish one.', ['attrs' => 'type="tel"']) ?>
    <?= $field('contact_url', 'Contact or booking page', $val('contact_url', $meta('contact_url')), 'A contact form or booking link, when there\'s no public email.', ['attrs' => 'type="url"']) ?>
  </div>
  <?= $field('social', 'Social links', $val('social', $meta('social_links')), $limit('social'), ['area' => true, 'rows' => 2, 'meta' => 'social_links']) ?>

  </div>
  <div class="flex flex-wrap gap-2 mt-4"><button class="le-b go" type="submit">Save changes</button><a class="le-b" href="/admin/crawler-review.php">Back to Review</a></div>
</form>
<script src="/js/cat-more.js?v=<?= (int) @filemtime(__DIR__ . '/../js/cat-more.js') ?>"></script>
<script src="/js/section-edit.js?v=<?= (int) @filemtime(__DIR__ . '/../js/section-edit.js') ?>"></script>
<script>var TV_RULES = <?= json_encode(IntakeStager::FIELD_RULES, JSON_UNESCAPED_UNICODE) ?>;</script>
<script>
  // Read first; the pencil on each section opens its fields. After a refused save, everything opens.
  tvSections(document.querySelector('.le-card'), { sections: '.le-block', head: '.le-sec', check: window.tvFieldCheck });
  <?php if ($form !== null): ?>tvSectionsOpenAll(document.querySelector('.le-card'));<?php endif; ?>
</script>
<?php tv_crawler_end();
