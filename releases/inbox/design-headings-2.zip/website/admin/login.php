<?php
// /admin/login.php — the staff sign-in (decisions/0100): staff ID and password, then the 6-digit code we email to the
// work email (or, if they've added one, the authenticator app's code). Member accounts sign in at /login.php and don't
// open the admin side. ?next= a path on this site.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';

$pdo = Database::connection();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$next = (string) ($_GET['next'] ?? $_POST['next'] ?? '/admin/');
if (!preg_match('#^/(?!/)[^\s\\\\]*$#', $next)) $next = '/admin/';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$err = ''; $msg = '';

if (!StaffLogin::ready($pdo)) { tv_page_start('Staff sign-in', ['no_crumbs' => true, 'app' => true]); echo '<p class="p-4">Run <code>app/migrations/2026-12-05_staff_logins.sql</code> first.</p>'; tv_page_end(); exit; }
if (StaffLogin::inSession($pdo) && $_SERVER['REQUEST_METHOD'] === 'GET' && empty($_GET['again'])) { header('Location: ' . $next, true, 302); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        switch ((string) ($_POST['do'] ?? '')) {
            case 'password':
                $r = StaffLogin::checkPassword($pdo, (string) ($_POST['staff_id'] ?? ''), (string) ($_POST['password'] ?? ''));
                if ($r['mail_error'] !== '') $err = $r['mail_error'];
                break;
            case 'code':
                StaffLogin::checkCode($pdo, (string) ($_POST['code'] ?? ''));
                header('Location: ' . $next, true, 303); exit;
            case 'resend':
                $msg = 'New code sent to ' . StaffLogin::resendCode($pdo) . '. Use the newest one.';
                break;
            case 'restart':
                unset($_SESSION['tv_staff_step']);
                break;
        }
    } catch (Throwable $ex) { $err = $ex instanceof RuntimeException ? $ex->getMessage() : 'Something went wrong. Try again.'; if (!($ex instanceof RuntimeException)) error_log('staff login: ' . $ex->getMessage()); }
}

$step = $_SESSION['tv_staff_step'] ?? null;
$who = $step ? StaffLogin::get($pdo, (int) $step['id']) : null;
if ($step && (!$who || time() - (int) $step['at'] > 600)) { unset($_SESSION['tv_staff_step']); $who = null; }
$sentTo = $who ? StaffLogin::codeSentTo('signin', (int) $who['id']) : '';
$mailable = $who && filter_var((string) $who['email'], FILTER_VALIDATE_EMAIL);
$app = $who && StaffLogin::hasApp($who);

// the sign-in card alone: no admin menu and none of its counts until you're signed in as staff (Jason, 2026-11-05); signed in
// as yourself, the account bar says why you're here
if (class_exists('Auth') && Auth::currentUser() !== null) $GLOBALS['tv_bar_note'] = 'Staff sign-in needed below';
tv_page_start('Staff sign-in', ['no_crumbs' => true, 'app' => true, 'description' => 'Sign in to the Traversence admin side with your staff login.']);
?>
<style>
  .sl{max-width:24rem;margin:1.5rem auto;background:#F7EFDC;border:1px solid #CBB98D;border-radius:1rem;padding:1.2rem;color:#3E2B1F}
  .sl h1{font:700 1.5rem var(--tv-font-head,Georgia,serif);margin:0 0 .3rem}
  .sl p{font-size:.9rem;line-height:1.5;margin:.35rem 0}
  .sl label{display:block;font-size:.82rem;font-weight:700;margin:.6rem 0 .2rem}
  .sl input{width:100%;font-size:1rem;padding:.55rem .65rem;border:1px solid #CBB98D;border-radius:.6rem;background:#FFFBF2;color:#3E2B1F}
  .sl input.code{font-size:1.5rem;letter-spacing:.3em;text-align:center}
  .sl .b{width:100%;margin-top:.9rem;border:1px solid #92400E;background:#92400E;color:#fff;border-radius:.6rem;padding:.6rem;font-weight:700;font-size:.95rem;cursor:pointer}
  .sl .l{background:none;border:0;color:#92400E;text-decoration:underline;cursor:pointer;font-size:.85rem;padding:0}
  .sl .ok{background:#DCFCE7;border-radius:.5rem;padding:.45rem .6rem}.sl .no{background:#FEE2E2;border-radius:.5rem;padding:.45rem .6rem}
  .sl small{display:block;color:#8A7355;font-size:.78rem;margin-top:.6rem}
  @media (max-width:767px){.sl{margin:.6rem 0}}
</style>
<div class="sl tv-bleed">
  <h1>Staff sign-in</h1>
  <?php if ($err): ?><p class="no" role="alert"><?= $e($err) ?></p><?php endif; ?>
  <?php if ($msg): ?><p class="ok" role="status"><?= $e($msg) ?></p><?php endif; ?>
  <?php if (!$who): ?>
    <p>For the Traversence team. Members sign in <a class="underline" href="/login.php">here</a>.</p>
    <form method="post" autocomplete="on">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><input type="hidden" name="do" value="password">
      <label for="sid">Staff ID or work email</label><input id="sid" name="staff_id" placeholder="TRV-0001" autocomplete="username" autocapitalize="off" spellcheck="false" value="<?= $e((string) ($_POST['staff_id'] ?? '') !== '' ? mb_substr((string) $_POST['staff_id'], 0, 120) : (preg_match('/^TRV-\d{4}$/', (string) ($_GET['sid'] ?? '')) ? $_GET['sid'] : '')) ?>" required<?= empty($_GET['sid']) && empty($_POST['staff_id']) ? ' autofocus' : '' ?>>
      <label for="pw">Password</label><input id="pw" name="password" type="password" autocomplete="current-password" required<?= !empty($_GET['sid']) || !empty($_POST['staff_id']) ? ' autofocus' : '' ?>>
      <button class="b">Next</button>
    </form>
    <small>Forgot your password, or can't get the email? Ask an owner to reset your staff login: you'll get a new setup link by email.</small>
  <?php else: ?>
    <p><b><?= $e($who['staff_id']) ?></b> · <?= $e($who['name']) ?></p>
    <?php if ($sentTo !== ''): ?><p>We emailed a 6-digit code to <b><?= $e($sentTo) ?></b>. It works for <?= StaffLogin::CODE_MINUTES ?> minutes.</p><?php endif; ?>
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><input type="hidden" name="do" value="code">
      <label for="code"><?= $sentTo !== '' ? 'The code from the email' : 'The code from your authenticator app' ?></label>
      <input id="code" class="code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" placeholder="000000" required autofocus>
      <button class="b">Sign in</button>
    </form>
    <?php if ($app && $sentTo !== ''): ?><small>Email slow? The code your authenticator app shows works here too.</small><?php endif; ?>
    <?php if ($mailable): ?><form method="post" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><button class="l" name="do" value="resend">Send a new code</button></form><?php endif; ?>
    <form method="post" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><button class="l" name="do" value="restart">Not you? Start again</button></form>
  <?php endif; ?>
</div>
<script src="/js/code-link.js" defer></script>
<?php tv_page_end();
