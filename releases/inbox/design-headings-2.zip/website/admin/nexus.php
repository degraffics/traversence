<?php
// admin/nexus.php — Manage listings → Nexus (decisions/0054): organizations with many locations.
//   no id:      every Nexus, and a form to create one (?from=<listing id> starts it from a listing: its name and website,
//               and that listing goes in as its first location)
//   ?id=N:      its details; its locations with their roles (change, remove); find any listing and add it; listings on
//               the same website that aren't in it yet, one tap each (0054 §6: evidence, a person adds)
// Admins and regional managers. Forms POST with the CSRF token; adding and removing go through /admin/api/nexus.php.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/Nexus.php';

$pdo = Database::connection();
$me = tv_listing_staff_require($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
$from = (int) ($_GET['from'] ?? $_POST['from'] ?? 0);
$ready = Nexus::ready($pdo);
$form = $_POST;

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'create') {
            $nid = Nexus::create($pdo, $_POST, (int) $me['id']);
            if ($from > 0) Nexus::link($pdo, $from, $nid, (string) ($_POST['role'] ?? 'location'));
            tv_crawler_flash([true, 'Created. Now add its locations: find them below, or add the ones on its website.']);
            header('Location: /admin/nexus.php?id=' . $nid . (tv_embedded() ? '&embed=1' : ''), true, 303); exit;
        }
        if ($do === 'save' && $id) {
            Nexus::update($pdo, $id, $_POST);
            tv_crawler_flash([true, 'Saved.']);
            header('Location: /admin/nexus.php?id=' . $id . (tv_embedded() ? '&embed=1' : ''), true, 303); exit;
        }
        if ($do === 'delete' && $id) {
            Nexus::remove($pdo, $id);
            tv_crawler_flash([true, 'Removed. Its locations are still listed, each on its own.']);
            header('Location: /admin/nexus.php' . (tv_embedded() ? '?embed=1' : ''), true, 303); exit;
        }
    } catch (InvalidArgumentException $x) {
        tv_crawler_flash([false, $x->getMessage()]);
    }
}

$n = $ready && $id ? Nexus::get($pdo, $id) : null;
tv_crawler_start('listings', $n ? (string) $n['name'] : 'Nexus', $pdo,
    $n ? '' : 'One organization with many locations: Changepoint Integrated Health and its clinics, a grocery chain, the VA and its clinics. Each location stays its own listing; the Nexus ties them together, so each shows "Part of …" and its other locations.');
if (!$ready) { echo '<p class="mt-3 text-sm">Run <code>app/migrations/2026-11-16_nexus.sql</code> in phpMyAdmin first.</p>'; tv_crawler_end(); exit; }
$e = 'tv_e';
$kindSel = function (string $cur) use ($e): string {
    $h = ''; foreach (Nexus::KINDS as $k => $l) $h .= '<option value="' . $k . '"' . ($k === $cur ? ' selected' : '') . '>' . $e($l) . '</option>'; return $h;
};
$roleSel = function (string $cur, string $attrs = '') use ($e): string {
    $h = '<select class="nx-in nx-role" ' . $attrs . '>'; foreach (Nexus::ROLES as $k => $l) $h .= '<option value="' . $k . '"' . ($k === $cur ? ' selected' : '') . '>' . $e($l) . '</option>'; return $h . '</select>';
};
?>
<style>
  .nx{max-width:56rem;margin-top:.8rem}
  .nx-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .9rem;margin-top:.7rem}
  .nx-h{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.05rem;margin:0 0 .3rem}
  .nx-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.55rem;padding:.4rem .6rem;font-size:.9rem;color:#3E2B1F;box-sizing:border-box}
  .nx-l{display:block;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355;margin:.6rem 0 .2rem}
  .nx-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(14rem,100%),1fr));gap:0 .8rem}
  .nx-b{display:inline-flex;align-items:center;gap:.3rem;font-weight:700;font-size:.85rem;border-radius:.6rem;padding:.42rem .85rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;cursor:pointer;text-decoration:none}
  .nx-b.go{background:#15803D;border-color:#15803D;color:#fff}.nx-b.no{color:#991B1B;border-color:#F5C2C2}
  .nx-row{display:flex;gap:.6rem;align-items:center;justify-content:space-between;padding:.5rem 0;border-top:1px solid #EADFC4}
  .nx-row:first-child{border-top:0}
  .nx-row .nm{font-weight:700;color:#92400E;text-decoration:underline}
  .nx-row small{display:block;color:#8A7355;font-size:.78rem}
  .nx-row .acts{display:flex;gap:.35rem;align-items:center;flex-shrink:0}
  .nx-row .nx-role{width:auto;padding:.25rem .4rem;font-size:.8rem}
  .nx-x{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#991B1B;cursor:pointer;font-size:1rem;line-height:1}
  .nx-list a.nx-item{display:flex;justify-content:space-between;gap:.6rem;padding:.55rem .2rem;border-top:1px solid #EADFC4;text-decoration:none;color:#3E2B1F}
  .nx-list a.nx-item:first-child{border-top:0}
  .nx-pill{font-size:.72rem;background:#EADFC4;border-radius:999px;padding:.1rem .5rem;color:#5C4632;white-space:nowrap}
  @media (max-width:767px){ .nx-row{flex-wrap:wrap} .nx-row .acts{width:100%;justify-content:flex-end} }
</style>
<div class="nx">
<?php if (!$n):
    $q = trim((string) ($_GET['q'] ?? ''));
    $list = Nexus::all($pdo, $q);
    $seed = $from > 0 ? IntakeStager::existingListing($pdo, $from) : null;
    $seedWeb = $seed ? (string) ($seed['meta']['website']['value'] ?? '') : '';
?>
  <form method="post" class="nx-card tv-bleed">
    <p class="nx-h"><?= $seed ? 'Create a Nexus from ' . $e($seed['name']) : 'Create a Nexus' ?></p>
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="create"><input type="hidden" name="from" value="<?= $from ?>">
    <div class="nx-grid">
      <div><label class="nx-l" for="nx-name">Organization's name</label><input class="nx-in" id="nx-name" name="name" required maxlength="160" value="<?= $e((string) ($form['name'] ?? ($seed ? preg_replace('/\s*[-–—,:]\s*(Show Low|Lakeside|Snowflake|Holbrook|Winslow|St\.? Johns|Springerville|Eagar|Taylor|Pinetop|Heber).*$/i', '', (string) $seed['name']) : ''))) ?>" placeholder="Changepoint Integrated Health"></div>
      <div><label class="nx-l" for="nx-kind">What it is</label><select class="nx-in" id="nx-kind" name="kind"><?= $kindSel((string) ($form['kind'] ?? 'brand')) ?></select></div>
    </div>
    <label class="nx-l" for="nx-web">Its website</label><input class="nx-in" id="nx-web" name="website" maxlength="255" value="<?= $e((string) ($form['website'] ?? $seedWeb)) ?>" placeholder="https://mychangepoint.org">
    <p class="text-xs text-[#8A7355] mt-1">Listings with the same website are offered as its locations, for you to add.</p>
    <label class="nx-l" for="nx-about">About (optional)</label><textarea class="nx-in" id="nx-about" name="about" rows="3" maxlength="4000"><?= $e((string) ($form['about'] ?? '')) ?></textarea>
    <?php if ($seed): ?><label class="nx-l">This listing's role</label><?= str_replace('class="nx-in nx-role"', 'class="nx-in" name="role"', $roleSel('location')) ?><?php endif; ?>
    <p class="mt-3"><button class="nx-b go" type="submit">Create it</button></p>
  </form>

  <div class="nx-card tv-bleed">
    <form method="get" class="flex gap-2 items-center"><?php if (tv_embedded()): ?><input type="hidden" name="embed" value="1"><?php endif; ?>
      <p class="nx-h" style="margin:0;flex:1">Every Nexus <span class="text-sm font-normal text-[#8A7355]">(<?= count($list) ?>)</span></p>
      <input class="nx-in" style="max-width:14rem" type="search" name="q" value="<?= $e($q) ?>" placeholder="Find by name or website">
    </form>
    <div class="nx-list mt-2">
      <?php if (!$list): ?><p class="text-sm text-[#8A7355]">None yet. Create the first one above, or from a listing's editor ("Part of a Nexus").</p><?php endif; ?>
      <?php foreach ($list as $x): ?><a class="nx-item" href="/admin/nexus.php?id=<?= (int) $x['id'] ?><?= tv_embedded() ? '&embed=1' : '' ?>"><span><b class="text-[#92400E] underline"><?= $e($x['name']) ?></b><small class="block text-[#8A7355] text-xs"><?= $e(Nexus::KINDS[$x['kind']] ?? $x['kind']) ?><?= $x['website'] ? ' · ' . $e(Nexus::host((string) $x['website'])) : '' ?></small></span><span class="nx-pill"><?= (int) $x['members'] ?> listing<?= (int) $x['members'] === 1 ? '' : 's' ?></span></a><?php endforeach; ?>
    </div>
  </div>
<?php else:
    $members = Nexus::members($pdo, (int) $n['id']);
    $sugg = Nexus::suggestions($pdo, (int) $n['id']);
    $parents = array_filter(Nexus::all($pdo), fn ($x) => (int) $x['id'] !== (int) $n['id']);
?>
  <div class="flex flex-wrap gap-2 items-center">
    <a class="nx-b" href="/admin/nexus.php<?= tv_embedded() ? '?embed=1' : '' ?>">← Every Nexus</a>
    <a class="nx-b" href="/nexus.php?slug=<?= $e($n['slug']) ?>" data-peek-frame>See its page</a>
    <a class="nx-b go" href="/admin/rebuild.php?nexus=<?= (int) $n['id'] ?>" data-peek-frame="Rebuild from its website" data-peek-fit title="Read its website and match its listings to the places it lists (decisions/0083)">Rebuild from its website</a>
    <span class="text-sm text-[#8A7355]"><?= (int) $n['members'] ?> listing<?= (int) $n['members'] === 1 ? '' : 's' ?> · <?= $e(Nexus::KINDS[$n['kind']] ?? $n['kind']) ?></span>
  </div>

  <div class="nx-card tv-bleed" id="nx-members" data-nexus="<?= (int) $n['id'] ?>" data-csrf="<?= $e($csrf) ?>">
    <p class="nx-h">Its locations</p>
    <?php if (!$members): ?><p class="text-sm text-[#8A7355]" data-empty>None yet. Find them below.</p><?php endif; ?>
    <?php foreach ($members as $m): ?>
      <div class="nx-row" data-e="<?= $m['id'] ?>">
        <span><a class="nm" href="/listing/view.php?id=<?= $m['id'] ?>" data-peek-frame><?= $e($m['name']) ?></a>
          <small><?= $e(trim($m['address'] . ($m['city'] !== '' ? ', ' . $m['city'] : ''), ', ')) ?><?= $m['phone'] !== '' ? ' · ' . $e($m['phone']) : '' ?><?= $m['category'] !== '' ? ' · ' . $e($m['category']) : '' ?><?= $m['closed'] ? ' · <b class="text-red-800">Closed</b>' : '' ?><?= $m['hidden'] ? ' · <b class="text-red-800">hidden</b>' : '' ?></small></span>
        <span class="acts"><?= $roleSel($m['role'], 'data-role aria-label="Its role"') ?>
          <a class="nx-b" href="/admin/listing-edit.php?id=<?= $m['id'] ?>" data-peek-frame="Edit <?= $e($m['name']) ?>">Edit</a>
          <button type="button" class="nx-x" data-remove title="Take it out of <?= $e($n['name']) ?>" aria-label="Take it out">&times;</button></span>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if ($sugg): ?>
  <div class="nx-card tv-bleed" id="nx-sugg">
    <p class="nx-h">On its website, not in it yet <span class="text-sm font-normal text-[#8A7355]">(<?= count($sugg) ?>, same website: <?= $e(WebIdentity::brand((string) $n['website'])) ?>)</span></p>
    <?php foreach ($sugg as $s): ?>
      <div class="nx-row" data-e="<?= $s['id'] ?>"><span><a class="nm" href="/listing/view.php?id=<?= $s['id'] ?>" data-peek-frame><?= $e($s['name']) ?></a><small><?= $e(trim($s['address'] . ($s['city'] !== '' ? ', ' . $s['city'] : ''), ', ')) ?></small></span>
        <span class="acts"><?= $roleSel('location', 'data-role-new aria-label="Its role"') ?><button type="button" class="nx-b go" data-add>Add</button></span></div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <div class="nx-card tv-bleed">
    <p class="nx-h">Add a listing</p>
    <input class="nx-in" id="nx-find" type="search" placeholder="Name, phone, address or #id" autocomplete="off">
    <div id="nx-found" class="mt-1"></div>
  </div>

  <form method="post" class="nx-card tv-bleed">
    <p class="nx-h">Details</p>
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="save">
    <div class="nx-grid">
      <div><label class="nx-l" for="nx-name">Name</label><input class="nx-in" id="nx-name" name="name" required maxlength="160" value="<?= $e((string) $n['name']) ?>"></div>
      <div><label class="nx-l" for="nx-kind">What it is</label><select class="nx-in" id="nx-kind" name="kind"><?= $kindSel((string) $n['kind']) ?></select></div>
      <div><label class="nx-l" for="nx-web">Website</label><input class="nx-in" id="nx-web" name="website" maxlength="255" value="<?= $e((string) $n['website']) ?>"></div>
      <div><label class="nx-l" for="nx-parent">Part of (a system's branch)</label><select class="nx-in" id="nx-parent" name="parent_id"><option value="0">Nothing above it</option>
        <?php foreach ($parents as $p): ?><option value="<?= (int) $p['id'] ?>"<?= (int) $n['parent_id'] === (int) $p['id'] ? ' selected' : '' ?>><?= $e($p['name']) ?></option><?php endforeach; ?></select></div>
    </div>
    <label class="nx-l" for="nx-about">About</label><textarea class="nx-in" id="nx-about" name="about" rows="4" maxlength="4000"><?= $e((string) $n['about']) ?></textarea>
    <p class="mt-3 flex flex-wrap gap-2"><button class="nx-b go" type="submit">Save</button></p>
  </form>
  <form method="post" class="mt-3"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="delete">
    <button class="nx-b no" type="submit" data-confirm="Remove <?= $e($n['name']) ?>? Its locations stay listed, each on its own." data-yes="Remove it" data-danger>Remove this Nexus</button></form>

<script>
(function () {
  var box = document.getElementById('nx-members'), NID = +box.getAttribute('data-nexus'), CSRF = box.getAttribute('data-csrf');
  var ROLES = <?= json_encode(Nexus::ROLES) ?>;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function api(body) {
    return fetch('/admin/api/nexus.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }).then(function (r) { return r.json(); }).then(function (j) { if (j && j.success === false) throw new Error((j.error && j.error.message) || j.message || 'Not saved.'); return j; });
  }
  function roleSel(cur) { var h = '<select class="nx-in nx-role" data-role aria-label="Its role">'; for (var k in ROLES) h += '<option value="' + k + '"' + (k === cur ? ' selected' : '') + '>' + esc(ROLES[k]) + '</option>'; return h + '</select>'; }
  function addRow(id, name, sub, role) {
    var empty = box.querySelector('[data-empty]'); if (empty) empty.remove();
    if (box.querySelector('.nx-row[data-e="' + id + '"]')) return;
    var d = document.createElement('div'); d.className = 'nx-row'; d.setAttribute('data-e', id);
    d.innerHTML = '<span><a class="nm" href="/listing/view.php?id=' + id + '" data-peek-frame>' + esc(name) + '</a><small>' + esc(sub || '') + '</small></span><span class="acts">' + roleSel(role)
      + '<a class="nx-b" href="/admin/listing-edit.php?id=' + id + '" data-peek-frame="Edit">Edit</a><button type="button" class="nx-x" data-remove aria-label="Take it out">&times;</button></span>';
    box.appendChild(d);
  }
  function add(id, name, sub, role, btn) {
    btn.disabled = true;
    api({ action: 'add', nexus: NID, entity: id, role: role }).then(function () {
      addRow(id, name, sub, role);
      var row = btn.closest('.nx-row, .nx-fr'); if (row) row.remove();
      if (window.TvAsk) TvAsk.say(name + ' added.');
    }).catch(function (x) { btn.disabled = false; if (window.TvAsk) TvAsk.say(x.message, { anchor: btn }); });
  }
  document.addEventListener('change', function (e) {
    var s = e.target.closest('#nx-members [data-role]'); if (!s) return;
    var row = s.closest('.nx-row');
    api({ action: 'role', entity: +row.getAttribute('data-e'), role: s.value }).then(function () { if (window.TvAsk) TvAsk.say('Role saved.', { anchor: s }); })
      .catch(function (x) { if (window.TvAsk) TvAsk.say(x.message, { anchor: s }); });
  });
  document.addEventListener('click', function (e) {
    var b = e.target.closest('#nx-members [data-remove]');
    if (b) {
      var row = b.closest('.nx-row'), nm = row.querySelector('.nm').textContent;
      if (!TvAsk.gate(b, 'Take ' + nm + ' out of this Nexus? It stays listed.', { yes: 'Take it out', danger: true })) return;
      api({ action: 'remove', entity: +row.getAttribute('data-e') }).then(function () { row.remove(); }).catch(function (x) { TvAsk.say(x.message, { anchor: b }); });
      return;
    }
    var a = e.target.closest('[data-add]');
    if (a) {
      var r = a.closest('.nx-row, .nx-fr'), sel = r.querySelector('[data-role-new]');
      add(+r.getAttribute('data-e'), r.querySelector('.nm').textContent, (r.querySelector('small') || {}).textContent || '', sel ? sel.value : 'location', a);
    }
  });
  // find any listing (the same search as Review's Find box)
  var inp = document.getElementById('nx-find'), out = document.getElementById('nx-found'), t = null, seq = 0;
  inp.addEventListener('input', function () {
    clearTimeout(t); var q = inp.value.trim(); if (q.length < 2) { out.innerHTML = ''; return; }
    t = setTimeout(function () {
      var my = ++seq;
      fetch('/admin/api/find-listing.php?q=' + encodeURIComponent(q), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) {
        if (my !== seq) return;
        var items = ((j.data || j).items || []);
        out.innerHTML = items.length ? items.map(function (it) {
          var sub = [it.address, it.city].filter(Boolean).join(', ') + (it.category ? ' · ' + it.category : '');
          var inIt = box.querySelector('.nx-row[data-e="' + it.id + '"]');
          return '<div class="nx-row nx-fr" data-e="' + it.id + '"><span><a class="nm" href="/listing/view.php?id=' + it.id + '" data-peek-frame>' + esc(it.name) + '</a><small>' + esc(sub) + '</small></span>'
            + '<span class="acts">' + (inIt ? '<span class="nx-pill">In it</span>' : roleSel('location').replace('data-role', 'data-role-new') + '<button type="button" class="nx-b go" data-add>Add</button>') + '</span></div>';
        }).join('') : '<p class="text-sm text-[#8A7355] mt-1">Nothing by that name, phone or address.</p>';
      });
    }, 250);
  });
})();
</script>
<?php endif; ?>
</div>
<?php tv_crawler_end();
