<?php
// admin/review-item.php?row=N — one thing the crawler found, opened as a pop-up from Review (decisions/0074).
// Everything to decide it on one screen: what's wrong in plain words, the found listing's details (editable), and each
// listing it may duplicate side by side, field by field, with what matches ticked and what differs marked. Then one
// answer: Same business (merge: fills the existing listing's empty fields, never overwrites), Different business (add
// it as its own listing), or Reject. Done tells Review, which takes the card off its list without leaving the page.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
require_once __DIR__ . '/../../app/lib/crawler/AutoImport.php';
require_once __DIR__ . '/../../app/lib/ListingCategories.php';
require_once __DIR__ . '/../../app/ui/category-fields.php';
require_once __DIR__ . '/../../app/lib/Identity.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$rowId = (int) ($_GET['row'] ?? $_POST['row'] ?? 0);

/** The staged row and its candidate, or null. */
$load = function () use ($pdo, $rowId): ?array {
    $r = IntakeStager::oneRow($pdo, $rowId);
    if (!$r || !is_array($r['payload'])) return null;
    $r['eval'] = AutoImport::evaluate($r['payload']);
    return $r;
};
$row = $load();
$c = $row['payload'] ?? [];
// what the person typed over the found values
$edit = fn (string $k, $dflt) => array_key_exists($k, $_POST) ? trim((string) $_POST[$k]) : $dflt;
$lines = fn ($v) => is_array($v) ? implode("\n", array_map('strval', $v)) : (string) $v;
$found = [
    'name' => $edit('name', (string) ($c['name'] ?? '')), 'address' => $edit('address', (string) ($c['where']['address'] ?? '')),
    'city' => $edit('city', (string) ($c['where']['city'] ?? '')), 'state' => $edit('state', (string) ($c['where']['state'] ?? '')),
    'zip' => $edit('zip', (string) ($c['where']['zip'] ?? '')), 'phone' => $edit('phone', (string) ($c['actions']['phone'] ?? '')),
    'website' => $edit('website', (string) ($c['actions']['website'] ?? '')), 'email' => $edit('email', (string) ($c['actions']['email'] ?? '')),
    'offerings' => $edit('offerings', $lines($c['what']['offerings'] ?? [])), 'description' => $edit('description', (string) ($c['what']['description'] ?? '')),
    'hours' => $edit('hours', $lines($c['when']['hours'] ?? [])),
];
$catId = (int) ($_POST['category_id'] ?? ($row['eval']['category_id'] ?? 0));
$done = null; $err = '';

/** approve()/merge() input: the found candidate with the person's corrections. */
$input = function () use ($c, $found, $catId): array {
    $in = AutoImport::input($c, $catId);
    $split = fn (string $s) => array_values(array_filter(array_map('trim', preg_split('/[\r\n]+/', $s))));
    return array_merge($in, ['name' => $found['name'], 'address' => $found['address'], 'city' => $found['city'], 'state' => $found['state'], 'zip' => $found['zip'],
        'phone' => $found['phone'], 'website' => $found['website'], 'email' => $found['email'], 'description' => $found['description'],
        'offerings' => $split($found['offerings']), 'hours' => $split($found['hours'])]);
};

if ($row && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload and try again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'new') {
            if ($catId <= 0) throw new InvalidArgumentException('Choose its category first (above).');
            // a person's "a different business": recorded on each pair the page offered, for good (decisions/0164 §3.1, R11)
            $diff = [];
            try { foreach (IntakeStager::freshMatch($pdo, $c)['possible'] as $m) if (in_array($m['kind'] ?? 'maybe', ['same', 'covered', 'maybe'], true)) $diff[] = (int) $m['id']; } catch (Throwable) {}
            $r = IntakeStager::approve($pdo, $rowId, $input(), (int) $me['id'], 'Review: a different business, added as its own', $diff);
            $done = ['Added as its own listing', (int) $r['entity_id']];
        } elseif ($do === 'merge') {
            $into = (int) ($_POST['into'] ?? 0);
            // fill what the existing listing doesn't have; never overwrite what it has (a person's or the owner's)
            $r = AutoImport::fillGaps($pdo, $rowId, $into, $c, (int) $me['id'], 'Review: same business as #' . $into, $input(), $catId);
            $done = $r['action'] === 'merged'
                ? ['Merged into #' . $into . ': its empty fields were filled in', $into]
                : ['Same business as #' . $into . ': nothing new to add, so this one is closed', $into];
        } elseif ($do === 'reject') {
            IntakeStager::reject($pdo, $rowId, trim('Rejected in Review. ' . mb_substr(trim((string) ($_POST['note'] ?? '')), 0, 300)), (int) $me['id']);
            $done = ['Rejected', 0];
        } else {
            throw new InvalidArgumentException('Choose an answer.');
        }
    } catch (InvalidArgumentException $x) {
        $err = $x->getMessage();
    }
}

tv_page_start('Review: ' . ($found['name'] ?: 'listing'), ['no_crumbs' => true, 'description' => 'Decide one listing the crawler found.']);
$e = 'tv_e';
?>
<style>
  .ri{max-width:72rem;padding:.6rem .4rem 1.2rem}
  .ri h1{font:700 1.35rem var(--tv-font-head,Georgia,serif);margin:0}
  .ri-why{margin:.5rem 0;padding:.6rem .75rem;border:1px solid #F3D9A4;border-left:4px solid #B45309;border-radius:.6rem;background:#FFF8EA;font-size:.9rem}
  .ri-why li{margin:.15rem 0 .15rem 1rem}
  .ri-grid{display:grid;grid-template-columns:7.5rem repeat(var(--cols),minmax(12rem,1fr));gap:0;border:1px solid #E5D6B5;border-radius:.7rem;overflow:hidden;background:#FFFBF2;margin-top:.6rem}
  .ri-grid>div{padding:.45rem .55rem;border-top:1px solid #EEE3CA;font-size:.86rem;overflow-wrap:anywhere;min-width:0}
  .ri-grid>.h{background:#F3E7CC;font-weight:700;border-top:0}
  .ri-grid>.k{color:#8A7355;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em}
  .ri-grid .same{background:#F2FAF5}.ri-grid .diff{background:#FFF5E6}
  .ri-grid .same::before{content:'✓ ';color:#3F7A5E;font-weight:700}
  .ri-in{width:100%;background:#fff;border:1px solid #CBB98D;border-radius:.45rem;padding:.3rem .45rem;font:inherit;font-size:.86rem}
  .ri-b{display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem;border-radius:.6rem;padding:.45rem .8rem;cursor:pointer;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;text-decoration:none}
  .ri-b.go{background:#15803D;border-color:#15803D;color:#fff}.ri-b.am{background:#B8863B;border-color:#B8863B;color:#2A1B12}.ri-b.no{color:#991B1B;border-color:#F5C2C2}
  .ri-acts{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.8rem;align-items:center}
  .ri-done{padding:1rem;border:1px solid #BFE0CF;border-left:4px solid #3F7A5E;border-radius:.6rem;background:#F2FAF5;margin-top:.6rem}
  .ri-err{color:#991B1B;font-weight:600;margin:.4rem 0}
  .ri-scroll{overflow-x:auto}
  .ri-know{margin:.5rem 0;border:1px solid #E5D6B5;border-radius:.6rem;background:#FFFBF2}
  .ri-know>summary{cursor:pointer;padding:.55rem .75rem;font-weight:700;font-size:.9rem;list-style:none}
  .ri-know>summary::-webkit-details-marker{display:none}
  .ri-know>summary::before{content:'▸ ';color:#B45309}.ri-know[open]>summary::before{content:'▾ '}
  .ri-know small{font-weight:400;color:#8A7355}
  .ri-kr{display:grid;grid-template-columns:6.5rem 1fr;gap:.15rem .6rem;padding:.4rem .75rem;border-top:1px solid #EEE3CA;font-size:.85rem}
  .ri-kr>.k{color:#8A7355;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;padding-top:.15rem}
  .ri-kr .v{overflow-wrap:anywhere}
  .ri-st{display:inline-block;font-size:.7rem;font-weight:700;border-radius:999px;padding:.05rem .45rem;margin-left:.3rem;vertical-align:1px}
  .ri-st.ok{background:#E3F2EA;color:#2F6B4F}.ri-st.one{background:#F3E7CC;color:#7A5B2E}.ri-st.bad{background:#FDE2E2;color:#991B1B}
  .ri-src{display:block;font-size:.75rem;color:#8A7355;margin-top:.1rem}.ri-src a{color:#92400E;text-decoration:underline}
  @media (max-width:767px){.ri-kr{grid-template-columns:1fr}}
  /* phones: one column, each field with the found value and, under it, each match's value labelled with its number */
  @media (max-width:767px){
    .ri-grid{grid-template-columns:1fr}
    .ri-grid>.h{display:none}
    .ri-grid>.k{border-top:2px solid #E5D6B5;padding-bottom:0;background:#FFFBF2}
    .ri-grid>[data-c]{border-top:0;padding-top:.15rem}
    .ri-grid>[data-c]::after{content:'';display:block}
    .ri-grid>[data-c]::before{content:attr(data-c) ': ';font-weight:700;color:#8A7355;font-size:.75rem}
    .ri-grid>.same[data-c]::before{content:'✓ ' attr(data-c) ': ';color:#3F7A5E}
    .ri-grid>.ri-mb{border-top:0}
    .ri-scroll{overflow:visible}
  }
</style>
<div class="ri">
<?php if ($done): ?>
  <div class="ri-done"><b>✓ <?= $e($done[0]) ?>.</b>
    <?php if ($done[1]): ?> <a class="underline text-[#92400E]" href="/listing/view.php?id=<?= (int) $done[1] ?>" target="_blank">See the listing</a> · <a class="underline text-[#92400E]" href="/admin/listing-edit.php?id=<?= (int) $done[1] ?>">Edit it</a><?php endif; ?></div>
  <script>try { parent.postMessage({ tvReviewDone: <?= $rowId ?>, msg: <?= json_encode($done[0]) ?> }, location.origin); } catch (e) {}</script>
<?php elseif (!$row): ?>
  <p>This one was already decided, or it's gone. Close this and carry on.</p>
  <script>try { parent.postMessage({ tvReviewDone: <?= $rowId ?>, msg: '' }, location.origin); } catch (e) {}</script>
<?php else:
    $ev = $row['eval'];
    try { $c['match'] = IntakeStager::freshMatch($pdo, $c); } catch (Throwable) {}   // against what's listed now
    $cands = [];
    if (!empty($c['match']['exact']['id'])) $cands[(int) $c['match']['exact']['id']] = $c['match']['exact'] + ['why' => 'same name and address'];
    foreach ((array) ($c['match']['possible'] ?? []) as $m) if (!empty($m['id']) && !isset($cands[(int) $m['id']])) $cands[(int) $m['id']] = $m;
    // likely the same business first; others at the same facility under another name (providers, offices) after
    $ex = []; foreach ($cands as $m) if ($l = IntakeStager::existingListing($pdo, (int) $m['id'])) $ex[] = ['m' => $m, 'l' => $l, 'r' => AutoImport::relation($c, $l)];
    $ex = array_values(array_filter($ex, fn ($x) => $x['r']['kind'] !== 'other'));   // a different business sharing a line or a building
    usort($ex, fn ($a, $b) => in_array($a['r']['kind'], ['place', 'branch'], true) <=> in_array($b['r']['kind'], ['place', 'branch'], true) ?: $b['r']['name'] <=> $a['r']['name']);
    $ex = array_slice($ex, 0, 3);
    $dupes = array_values(array_filter($ex, fn ($x) => !in_array($x['r']['kind'], ['place', 'branch'], true)));
    $place = array_values(array_filter($ex, fn ($x) => $x['r']['kind'] === 'place'));
    $branch = array_values(array_filter($ex, fn ($x) => $x['r']['kind'] === 'branch'));
    $failing = array_values(array_filter($ev['checks'], fn ($k) => !$k['pass']));
    $cats = IntakeStager::leafCategories($pdo);
    $catName = ''; foreach ($cats as $cc) if ((int) $cc['id'] === $catId) $catName = (string) $cc['plain'];
    $norm = fn ($s) => preg_replace('/[^a-z0-9]/', '', strtolower((string) $s));
    $exv = function (array $l, string $f): string {
        return match ($f) {
            'name' => (string) $l['name'], 'category' => (string) ($l['category_name'] ?? ''),
            'offerings', 'hours' => is_array($l['meta'][$f]['value'] ?? null) ? implode("\n", $l['meta'][$f]['value']) : (string) ($l['meta'][$f]['value'] ?? ''),
            'zip' => (string) ($l['primary_zip'] ?? ''),
            default => is_array($l['meta'][$f]['value'] ?? null) ? implode(', ', $l['meta'][$f]['value']) : (string) ($l['meta'][$f]['value'] ?? ''),
        };
    };
    $fields = ['name' => 'Name', 'category' => 'Category', 'address' => 'Address', 'city' => 'Town', 'state' => 'State', 'zip' => 'ZIP', 'phone' => 'Phone',
               'website' => 'Website', 'email' => 'Email', 'offerings' => 'Offerings', 'hours' => 'Hours', 'description' => 'About'];
    $foundVal = fn (string $f) => $f === 'category' ? $catName : (string) ($found[$f] ?? '');
    $src = (string) ($c['where']['location_page'] ?? '') ?: (string) ($row['source_url'] ?? '');
?>
  <form method="post" id="ri-form">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="row" value="<?= $rowId ?>">
    <h1><?= $e($found['name'] ?: 'Unnamed') ?></h1>
    <p class="text-sm text-[#8A7355]">Found by the crawler<?= $src !== '' ? ' on <a class="underline" href="' . $e($src) . '" target="_blank" rel="noopener nofollow">' . $e(parse_url($src, PHP_URL_HOST) ?: $src) . '</a>' : '' ?> · confidence <?= (int) $ev['score'] ?></p>
    <?php if ($err !== ''): ?><p class="ri-err"><?= $e($err) ?></p><?php endif; ?>

    <div class="ri-why"><b>What needs you:</b><ul>
      <?php if ($dupes): ?><li><b>It may already be listed</b> (<?= $e(implode('; ', array_map(fn ($x) => '#' . $x['m']['id'] . ' ' . $x['l']['name'] . ': ' . $x['m']['why'], $dupes))) ?>). Compare below: same business, or different?</li><?php endif; ?>
      <?php if ($place): $pl = count($place) > 1; ?><li><b>Same place, different name<?= $pl ? 's' : '' ?>:</b> <?= $e(implode(', ', array_map(fn ($x) => '#' . $x['l']['id'] . ' ' . $x['l']['name'], $place))) ?> share<?= $pl ? '' : 's' ?> its <?= $e(implode(' and ', array_filter([$place[0]['r']['phone'] ? 'phone' : '', $place[0]['r']['addr'] ? 'address' : '']))) ?>. Most likely <?= $pl ? 'providers or offices' : 'a provider or office' ?> at the same facility, not a duplicate<?= $dupes ? '' : ': add it as its own unless you see otherwise' ?>.</li><?php endif; ?>
      <?php if ($catId <= 0): ?><li><b>No category.</b> Choose one in the Found column.</li><?php endif; ?>
      <?php foreach ($failing as $k): if (preg_match('/categor|already|duplicate/i', $k['label'])) continue; ?><li><?= $e(preg_replace('/ — .*$/', '', $k['label'])) ?></li><?php endforeach; ?>
      <?php if ($branch): ?><li><b>Another location:</b> <?= $e(implode(', ', array_map(fn ($x) => '#' . $x['l']['id'] . ' ' . $x['l']['name'], $branch))) ?> ha<?= count($branch) > 1 ? 've' : 's' ?> the same name at a different street address. Each location is its own listing<?= $dupes ? '' : ': add it unless it\'s really the same address written differently' ?>.</li><?php endif; ?>
      <?php if (!$dupes && !$place && !$branch && $catId > 0 && !$failing): ?><li>Nothing's wrong: check it and add it.</li><?php endif; ?>
    </ul></div>

    <?php
    // what we know about it, from every source that's seen it (its identity since the first sighting: decisions/0133)
    $know = Identity::card($pdo, Identity::INTAKE, $rowId, true);
    if (!array_filter($know['facts'])) { Identity::fromIntake($pdo, $rowId); $know = Identity::card($pdo, Identity::INTAKE, $rowId, true); }
    $kn = 0; $kc = 0; foreach ($know['facts'] as $fs) foreach ($fs as $f) if ($f['current']) { $kn++; if ($f['status'] === 'confirmed') $kc++; }
    $stLabel = ['confirmed' => ['ok', 'confirmed'], 'single' => ['one', 'one source'], 'conflict' => ['bad', 'sources disagree']];
    if ($kn): ?>
    <details class="ri-know tv-bleed"<?= $kc ? ' open' : '' ?>><summary>What we know about it <small>· <?= $kn ?> fact<?= $kn === 1 ? '' : 's' ?>, <?= $kc ?> confirmed</small></summary>
      <?php foreach ($know['facts'] as $w => $fs): foreach ($fs as $f): if (!$f['current']) continue;
          $st = $stLabel[$f['status']] ?? ['one', $f['status']];
          $srcs = array_values(array_filter($f['sources'], fn ($x) => !in_array($x['kind'], ['rejected', 'dismissed', 'replaced'], true))); ?>
        <div class="ri-kr"><div class="k"><?= $e($f['label']) ?></div><div class="v"><?= $e(mb_strimwidth((string) $f['value'], 0, 200, '…')) ?><span class="ri-st <?= $st[0] ?>"><?= $e($st[1]) ?></span>
          <?php foreach (array_slice($srcs, 0, 4) as $x): $host = $x['site'] !== '' ? $x['site'] : (parse_url((string) $x['url'], PHP_URL_HOST) ?: ''); ?>
            <span class="ri-src"><?= $x['kind'] === 'evidence' ? 'Link' : $e(ucfirst(str_replace('_', ' ', (string) $x['kind']))) ?>: <?= $x['url'] !== '' ? '<a href="' . $e((string) $x['url']) . '" target="_blank" rel="noopener nofollow">' . $e($x['label'] !== '' ? $x['label'] : $host) . '</a>' : $e($x['label'] !== '' ? $x['label'] : $host) ?><?= $host !== '' && $x['url'] !== '' && $x['label'] !== '' ? ' · ' . $e($host) : '' ?></span>
          <?php endforeach; ?><?= count($srcs) > 4 ? '<span class="ri-src">and ' . (count($srcs) - 4) . ' more</span>' : '' ?>
        </div></div>
      <?php endforeach; endforeach; ?>
      <p class="text-xs text-[#8A7355] px-3 pb-2 m-0">Confirmed: an official registry, the owner or our staff says so, or two independent websites agree (one site counts once, however it was found). One source: only one has said it so far. A link (Google, OpenStreetMap, Wikipedia, a directory) shows where to look; it isn't counted.</p>
    </details>
    <?php endif; ?>

    <div class="ri-scroll"><div class="ri-grid" style="--cols:<?= 1 + count($ex) ?>">
      <div class="h k"></div><div class="h">Found <span class="font-normal text-[#8A7355] text-xs">(you can correct it)</span></div>
      <?php foreach ($ex as $x): ?><div class="h">#<?= (int) $x['l']['id'] ?> <a class="underline text-[#92400E] font-normal text-xs" href="/listing/view.php?id=<?= (int) $x['l']['id'] ?>" data-peek-frame>see it</a><br><span class="font-normal text-xs text-[#8A7355]"><?= $e($x['l']['status']) ?> · <?= $x['r']['kind'] === 'place' ? 'same place, different name' : ($x['r']['kind'] === 'branch' ? 'another location' : $e($x['m']['why'])) ?></span></div><?php endforeach; ?>
      <?php foreach ($fields as $f => $label): ?>
        <div class="k"><?= $e($label) ?></div>
        <div>
          <?php if ($f === 'category'): ?>
            <select class="ri-in" name="category_id" data-cat-pick><?= tv_cat_options($cats, $catId) ?></select>
          <?php elseif (in_array($f, ['offerings', 'hours', 'description'], true)): ?>
            <textarea class="ri-in" name="<?= $f ?>" rows="<?= $f === 'description' ? 3 : 2 ?>"><?= $e($foundVal($f)) ?></textarea>
          <?php else: ?>
            <input class="ri-in" name="<?= $f ?>" value="<?= $e($foundVal($f)) ?>"<?= $f === 'state' ? ' maxlength="2"' : '' ?>>
          <?php endif; ?>
        </div>
        <?php foreach ($ex as $x): $v = $exv($x['l'], $f); $fv = $foundVal($f);
            $cls = $v === '' || $fv === '' ? '' : ($norm($v) === $norm($fv) || ($f === 'phone' && substr(preg_replace('/\D/', '', $v), -10) === substr(preg_replace('/\D/', '', $fv), -10)) ? 'same' : 'diff'); ?>
          <div class="<?= $cls ?>" data-c="#<?= (int) $x['l']['id'] ?>" style="white-space:pre-line"><?= $v !== '' ? $e(mb_strimwidth($v, 0, 300, '…')) : '<span class="text-[#B8A07A] italic">empty</span>' ?></div>
        <?php endforeach; ?>
      <?php endforeach; ?>
      <div class="k"></div><div></div>
      <?php foreach ($ex as $x): ?><div class="ri-mb"><button class="ri-b am" type="submit" name="do" value="merge" onclick="this.form.into.value='<?= (int) $x['l']['id'] ?>'"
        data-confirm="Same business as #<?= (int) $x['l']['id'] ?>? Its empty fields get filled from what was found; nothing it has is overwritten." data-yes="Yes, merge">Same business<?= count($ex) > 1 ? ' as #' . (int) $x['l']['id'] : '' ?>: merge</button> <a class="underline text-[#92400E] text-xs" href="/listing/view.php?id=<?= (int) $x['l']['id'] ?>" data-peek-frame>see #<?= (int) $x['l']['id'] ?></a></div><?php endforeach; ?>
    </div></div>
    <input type="hidden" name="into" value="">
    <p class="text-xs text-[#8A7355] mt-1"><span style="background:#F2FAF5">✓ green</span> is the same; <span style="background:#FFF5E6">amber</span> differs. Merging never overwrites: it only fills what the existing listing is missing.</p>

    <div class="ri-acts">
      <button class="ri-b go" type="submit" name="do" value="new"<?= $ex ? ' data-confirm="Add it as its own listing, separate from #' . implode(', #', array_map(fn ($x) => (int) $x['l']['id'], $ex)) . '?" data-yes="Add it"' : '' ?>><?= $ex ? 'Different business: add it' : 'Add it' ?></button>
      <input class="ri-in" name="note" placeholder="Why reject? (optional)" style="max-width:16rem">
      <button class="ri-b no" type="submit" name="do" value="reject" data-confirm="Reject <?= $e($found['name']) ?>? It won't be suggested again." data-yes="Reject" data-danger>Reject</button>
    </div>
  </form>
  <script src="/js/cat-more.js?v=<?= (int) @filemtime(__DIR__ . '/../js/cat-more.js') ?>"></script>
<?php endif; ?>
</div>
<?php tv_page_end();
