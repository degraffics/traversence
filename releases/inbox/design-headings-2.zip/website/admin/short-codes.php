<?php
// /admin/short-codes.php — Safety → Short codes (decisions/0094). The trvgo.us codes people and businesses made, newest
// first, to find one that's misused (a code pointing somewhere harmful) and switch it off for everyone. Kept, never
// deleted; its owner sees that our team switched it off and why. Pages shared by the site's own Share aren't listed.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/ShortCodes.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$ready = ShortCodes::ready($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $ready && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
    $id = (int) ($_POST['id'] ?? 0);
    try {
        if (($_POST['do'] ?? '') === 'off') { ShortCodes::staffOff($pdo, $id, (string) ($_POST['why'] ?? '') ?: 'misuse'); tv_crawler_flash(['type' => 'ok', 'text' => 'Switched off. Scanning it now says it isn\'t active.']); }
        if (($_POST['do'] ?? '') === 'on') { ShortCodes::staffOn($pdo, $id); tv_crawler_flash(['type' => 'ok', 'text' => 'Switched on again.']); }
    } catch (Throwable $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    header('Location: /admin/short-codes.php' . (isset($_GET['q']) ? '?q=' . rawurlencode((string) $_GET['q']) : '') . '#c' . $id); exit;
}

$q = trim((string) ($_GET['q'] ?? ''));
$rows = [];
if ($ready) {
    $sql = "SELECT c.*, u.display_name, u.email, en.name AS listing FROM short_codes c LEFT JOIN users u ON u.id = c.owner_user_id LEFT JOIN entities en ON en.id = c.entity_id
            WHERE c.kind <> 'page'" . ($q !== '' ? ' AND (c.code = ? OR c.target LIKE ? OR c.title LIKE ? OR u.email LIKE ?)' : '') . ' ORDER BY c.id DESC LIMIT 200';
    $st = $pdo->prepare($sql);
    $st->execute($q !== '' ? [ShortCodes::clean($q), '%' . $q . '%', '%' . $q . '%', '%' . $q . '%'] : []);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
}
$flash = tv_crawler_flash();
tv_page_start('Short codes', ['crumbs' => [['Home', '/'], ['Admin', '/admin/'], ['Safety', '/admin/safety.php'], ['Short codes']]]);
?>
<style>
  .sc{max-width:60rem}.sc h1{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.7rem;margin:0 0 .3rem}
  .sc-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .9rem;margin:.5rem 0;font-size:.85rem;overflow-wrap:anywhere}
  .sc-card.off{opacity:.7}.sc-card b a{color:#92400E}
  .sc-f{display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;margin-top:.4rem}
  .sc-f input{border:1px solid #CBB98D;border-radius:.5rem;padding:.3rem .5rem;flex:1;min-width:10rem}
  .sc-b{border:1px solid #CBB98D;background:#FFFBF2;border-radius:.5rem;padding:.3rem .7rem;font-weight:600;cursor:pointer}
  .sc-b.d{border-color:#B91C1C;color:#B91C1C}
  .sc-flash{padding:.5rem .7rem;border-radius:.5rem;background:#DCFCE7}.sc-flash.error{background:#FEE2E2}
</style>
<div class="sc">
  <h1>Short codes</h1>
  <p style="font-size:.9rem;color:#5C4632">trvgo.us codes people and businesses made. Switch off one that's misused (pointing somewhere harmful): scanning it then says it isn't
    active, and its owner sees why. Codes are kept, never deleted. Scans are counted by day and kind of phone, never who.</p>
  <?php if ($flash): ?><p class="sc-flash <?= $e($flash['type']) ?>" data-tv-flash="<?= $e($flash['type']) ?>"><?= $e($flash['text']) ?></p><?php endif; ?>
  <?php if (!$ready): ?><p class="sc-card">Run <code>app/migrations/2026-11-27_short_codes.sql</code> in phpMyAdmin first.</p><?php else: ?>
  <form method="get" class="sc-f"><input name="q" value="<?= $e($q) ?>" placeholder="A code, a web address, a name or an email"><button class="sc-b">Find</button></form>
  <?php if (!$rows): ?><p class="sc-card">None<?= $q !== '' ? ' match' : ' yet' ?>.</p><?php endif; ?>
  <?php foreach ($rows as $r): $off = !(int) $r['active']; ?>
  <div class="sc-card tv-bleed<?= $off ? ' off' : '' ?>" id="c<?= (int) $r['id'] ?>">
    <b><a href="<?= $e(ShortCodes::url((string) $r['code'])) ?>" target="_blank" rel="noopener noreferrer">trvgo.us/<?= $e($r['code']) ?></a></b>
    · <?= $e(ShortCodes::KINDS[$r['kind']] ?? $r['kind']) ?><?= $r['title'] !== '' ? ' · ' . $e($r['title']) : '' ?>
    <div>Goes to: <?= $r['kind'] === 'vcard' ? 'a contact card' : $e($r['target']) ?></div>
    <div>By <?= $e($r['display_name'] ?: $r['email'] ?: 'unknown') ?><?= $r['listing'] ? ' for ' . $e($r['listing']) : '' ?> · made <?= $e(substr((string) $r['created_at'], 0, 10)) ?> · scanned <?= (int) $r['scans'] ?></div>
    <?php if ($off): ?><div>Off: <?= $e($r['off_reason'] === 'owner' ? 'by its owner' : $r['off_reason']) ?></div><?php endif; ?>
    <form method="post" class="sc-f"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
      <?php if (!$off): ?><input name="why" placeholder="Why (the owner sees this)" maxlength="180"><button class="sc-b d" name="do" value="off" data-confirm="Switch this code off for everyone?" data-yes="Switch off" data-danger>Switch off</button>
      <?php elseif (str_starts_with((string) $r['off_reason'], 'staff:')): ?><button class="sc-b" name="do" value="on">Switch on again</button><?php endif; ?>
    </form>
  </div>
  <?php endforeach; endif; ?>
</div>
<?php tv_page_end(); ?>
