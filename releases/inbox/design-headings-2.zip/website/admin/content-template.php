<?php
// admin/content-template.php — one of the AI Content Crawler's templates (decisions/0133), inside System Configuration →
// Content templates at /admin/config/content/<id>. Shape it before anything is spent: what it applies to and when it
// runs, what it gathers, what it writes and in what voice, how long it lasts. Preview shows exactly what Claude would be
// sent for a place and what it would cost, for nothing; Try it writes that place under the template as it is in the form
// (saved or not) without touching the place's guide, and keeps what came back. Every save is a version; a copy can be
// shaped and then used as the running template. The exposure standard is shown, never edited here.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/ContentTemplates.php';
require_once __DIR__ . '/../../app/lib/Guides.php';
require_once __DIR__ . '/../../app/lib/AiClient.php';
require_once __DIR__ . '/../../app/lib/LiveEvents.php';
if (!class_exists('Access')) require_once __DIR__ . '/../../app/admin/Access.php';

$pdo = Database::connection();
tv_crawler_require_admin($pdo);
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$base = '/admin/config/content/';
if (!isset($tvItemRoute) && empty($_GET['embed']) && $_SERVER['REQUEST_METHOD'] === 'GET') { header('Location: ' . $base . $id, true, 301); exit; }
[$can, $why] = Access::can('config.content.edit', ['min' => 'director', 'depts' => ['eng', 'ops', 'con']]);
if (ContentTemplates::ready($pdo)) ContentTemplates::seed($pdo);
$t = ContentTemplates::get($pdo, $id);
$uid = (int) ($me['id'] ?? 0);
// a legal text (decisions/0142): its own editor, sections of plain text and Publish
require_once __DIR__ . '/../../app/lib/LegalTexts.php';
if (LegalTexts::isLegal($t)) { require_once __DIR__ . '/../../app/admin/legal-editor.php'; tv_legal_editor($pdo, $t, $me, $can, $why, $csrf); return; }

// the place a preview or a try is for: "St. Johns · City guide (town:2)" or a bare key
$placeOf = function (string $v): string {
    if (preg_match('/\(((?:hub|geo_hub|cluster|town|sub):\d+)\)\s*$/', $v, $m)) return $m[1];
    return preg_match('/^(?:hub|geo_hub|cluster|town|sub):\d+$/', trim($v)) ? trim($v) : '';
};

$shaping = null; $preview = null; $tried = null; $placeIn = ''; $flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $t) {
    $do = (string) ($_POST['do'] ?? '');
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        if (!$can) throw new RuntimeException($why);
        $go = null; $msg = '';
        switch ($do) {
            case 'save':
                $v = ContentTemplates::save($pdo, $id, ['name' => (string) ($_POST['name'] ?? $t['name']), 'status' => (string) ($_POST['status'] ?? $t['status']), 'spec' => ContentTemplates::fromForm($t['spec'], $_POST)], $uid, (string) ($_POST['note'] ?? ''));
                $msg = $v === (int) $t['version'] ? 'Nothing had changed.' : 'Saved as version ' . $v . '.' . ($t['status'] === 'active' && isset(ContentTemplates::RUNS[$t['slug']]) ? ' The next guide written uses it.' : '');
                $go = $base . $id; break;
            case 'preview':
            case 'try':
                $shaping = ContentTemplates::fromForm($t['spec'], $_POST);
                $placeIn = (string) ($_POST['place'] ?? '');
                $key = $placeOf($placeIn);
                if ($key === '' || !Guides::place($pdo, $key)) throw new InvalidArgumentException('Pick a place from the list.');
                $rec = $t['kind'] === 'records';   // Live events: records, found by the events finder; else a guide
                if ($do === 'preview') { $preview = $rec ? LiveEvents::preview($pdo, $key, $shaping) : Guides::preview($pdo, $key, $shaping); $preview['key'] = $key; }
                else {
                    $r = $rec ? LiveEvents::tryTemplate($pdo, $key, $shaping) : Guides::tryTemplate($pdo, $key, $shaping);
                    if ($rec) $r += ['sections' => ['events' => $r['events']], 'check' => $r['dropped'], 'cut' => [], 'confidence' => 0];
                    ContentTemplates::keepTry($pdo, $id, (int) $t['version'], $key, $shaping, $r, $uid);
                    $tried = $r + ['key' => $key];
                    $flash = '<p data-tv-flash="ok">' . $e($r['say']) . ' It cost $' . number_format($r['micros'] / 1e6, 3) . '. Nothing was saved' . ($rec ? '' : ' to the guide or the template') . '.</p>';
                }
                break;
            case 'duplicate':
                $name = trim((string) ($_POST['copy_name'] ?? '')) ?: $t['name'] . ' (copy)';
                $slug = $name; $n = 2; while (ContentTemplates::get($pdo, (string) preg_replace('/[^a-z0-9]+/', '_', strtolower($slug)))) $slug = $name . ' ' . $n++;
                $go = $base . ContentTemplates::duplicate($pdo, $id, $slug, $name, $uid); $msg = 'Copied. Shape it here; nothing runs it until you use it.'; break;
            case 'useas':
                $slug = (string) ($_POST['runs'] ?? 'place_guide');
                $v = ContentTemplates::useAs($pdo, $id, $slug, $uid);
                $go = $base . (int) ContentTemplates::get($pdo, $slug)['id']; $msg = 'It\'s running now (version ' . $v . '). The one it replaced is kept in its versions.'; break;
            case 'remove':
                ContentTemplates::remove($pdo, $id); $go = '/admin/config/content'; $msg = 'Removed.'; break;
            case 'restore':
                $v = ContentTemplates::restore($pdo, $id, (int) ($_POST['version'] ?? 0), $uid); $go = $base . $id; $msg = 'Back to version ' . (int) ($_POST['version'] ?? 0) . ', saved as version ' . $v . '.'; break;
        }
        if ($go !== null) { tv_crawler_flash(['type' => 'ok', 'text' => $msg]); header('Location: ' . $go, true, 303); exit; }
    } catch (Throwable $ex) {
        $bad = $ex instanceof InvalidArgumentException || ($ex instanceof RuntimeException && !($ex instanceof PDOException));
        if (!$bad) error_log('content-template: ' . $ex->getMessage());
        $flash = '<p data-tv-flash="error">' . $e($bad ? $ex->getMessage() : 'That didn\'t work. Try again.') . '</p>';
        if (in_array($do, ['preview', 'try'], true) && $shaping === null) $shaping = ContentTemplates::fromForm($t['spec'], $_POST);
    }
}

tv_admin_start('config', $t ? 'Template: ' . $t['name'] : 'Template', '', null, $t ? [['System Configuration', '/admin/config'], ['Content templates', '/admin/config/content'], [(string) $t['name'], null]] : []);   // the command strip takes the title's place
if (!ContentTemplates::ready($pdo)) { echo '<div class="hb-card tv-bleed"><p data-tv-status="info" data-tv-label="Not ready:">The database update for templates hasn\'t run yet: it runs within the hour, or open Database updates.</p></div>'; tv_admin_end(); return; }
if (!$t) { echo '<div class="hb-card tv-bleed"><p class="text-sm">That template isn\'t here. <a class="hb-go" href="/admin/config/content">All templates</a></p></div>'; tv_admin_end(); return; }

$spec = $shaping ?? $t['spec'];
$name = $shaping !== null ? (string) ($_POST['name'] ?? $t['name']) : (string) $t['name'];
$status = $shaping !== null ? (string) ($_POST['status'] ?? $t['status']) : (string) $t['status'];
$runs = ContentTemplates::RUNS[$t['slug']] ?? '';
$w = (array) ($spec['write'] ?? []); $ap = (array) ($spec['applies'] ?? []);
$dis = $can ? '' : ' disabled title="' . $e($why) . '"';
$hidden = fn (string $do) => '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="do" value="' . $do . '">';
$tries = ContentTemplates::tries($pdo, $id, 5);
$versions = ContentTemplates::versions($pdo, $id);
$who = function (int $u) use ($pdo): string { if (!$u) return 'the site'; try { $st = $pdo->prepare('SELECT COALESCE(NULLIF(display_name, \'\'), email) FROM users WHERE id = ?'); $st->execute([$u]); return (string) ($st->fetchColumn() ?: 'someone'); } catch (Throwable $x) { return 'someone'; } };
$prose = fn (string $t): string => '<p>' . nl2br((string) preg_replace('/\*\*(.+?)\*\*/', '<b>$1</b>', $e($t))) . '</p>';   // a section as visitors read it: **names** in bold
$placeName = function (string $k) use ($pdo): string { $p = Guides::place($pdo, $k); return $p ? $p['name'] . ' · ' . $p['kind'] : $k; };

// the places a preview or a try can be for: every place on the funnel, by name
$places = '';
foreach (Guides::tree($pdo) as $row) { [$k, $nm, $tier] = $row; $places .= '<option value="' . $e($nm . ' · ' . (Guides::TIERS[explode(':', $k)[0]][1] ?? '') . ' (' . $k . ')') . '"></option>'; }
if ($placeIn === '') { $last = $tries[0]['place_key'] ?? (string) ($pdo->query("SELECT place_key FROM place_guides WHERE status = 'live' ORDER BY updated_at DESC LIMIT 1")->fetchColumn() ?: ''); if ($last !== '') { $p = Guides::place($pdo, $last); if ($p) $placeIn = $p['name'] . ' · ' . $p['kind'] . ' (' . $last . ')'; } }

$news = [ContentTemplates::STATUSES[$t['status']] ?? $t['status'], 'Version ' . (int) $t['version'] . ', saved ' . date('M j, Y', strtotime((string) $t['updated_at'])) . ' by ' . $who((int) $t['updated_by'])];
$news[] = $runs !== '' ? ($t['status'] === 'active' ? 'Running: a save applies to the next guide written' : 'Run by ' . $runs . ', but not writing on its own while ' . mb_strtolower(ContentTemplates::STATUSES[$t['status']])) : 'A copy: nothing runs it until you use it';
$more = [['Preview and try', '#try'], ['Versions', '#versions']];
if ($runs === '') { $more[] = ['Use it as the running template', '#ct-useas-btn']; $more[] = ['Remove this copy', '#ct-remove-btn', 'danger']; }
require_once __DIR__ . '/../../app/ui/command-strip.php';
echo tv_command_strip(['noun' => 'template', 'title' => $name, 'news_key' => 'template-' . $id, 'news_tone' => $t['status'] === 'active' ? 'ok' : 'info', 'news' => $news,
    'back' => '/admin/config/content', 'close' => '/admin/config/content', 'root' => '.ct', 'more' => $more, 'new' => '.ct-dup']);
echo $flash;
$sel = fn (bool $on) => $on ? ' selected' : '';
?>
<style>
.ct .hb-card{margin-top:.5rem;margin-bottom:.5rem}.ct label.ct-f{display:block;margin:.6rem 0;font-weight:600;font-size:.9rem;color:#3B2A1A}.ct label.ct-f small{display:block;font-weight:400;color:#8A7355;font-size:.78rem;margin:.1rem 0 .3rem}
.ct textarea,.ct input.hb-in,.ct select.hb-in{width:100%;max-width:100%;box-sizing:border-box}.ct .ct-row{display:flex;flex-wrap:wrap;gap:.6rem 1.2rem}.ct .ct-row>label{flex:1 1 11rem}
.ct .ct-sec{border:1px solid #E8DCC6;border-radius:.5rem;padding:.6rem;margin:.5rem 0;background:#FFFDF8}.ct .ct-sec.off{opacity:.6}.ct .ct-sec h3{font:700 1rem var(--tv-font-head,Georgia,serif);margin:0 0 .3rem;display:flex;gap:.6rem;align-items:center;flex-wrap:wrap}
.ct .ct-sec h3 small{font:400 .78rem system-ui;color:#8A7355}.ct .ct-sec .ct-row>label{flex:0 1 9rem;font-size:.82rem}.ct .ct-lock li{margin:.3rem 0}.ct pre{white-space:pre-wrap;font-size:.78rem;max-height:24rem;overflow:auto;background:#FBF6EC;padding:.6rem;border-radius:.4rem}
.ct .ct-acts{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.6rem}.ct .ct-out h4{font:700 .95rem var(--tv-font-head,Georgia,serif);margin:.8rem 0 .2rem}.ct .ct-out p{margin:.2rem 0 .5rem;font-size:.92rem}
.ct table{width:100%;border-collapse:collapse;font-size:.85rem}.ct td,.ct th{padding:.35rem .4rem;border-bottom:1px solid #E8DCC6;text-align:left;vertical-align:top}.ct .ct-scroll{overflow-x:auto}
.ge-spin{display:inline-block;width:.85em;height:.85em;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;margin-right:.4em;vertical-align:-.1em;animation:ctspin .8s linear infinite}@keyframes ctspin{to{transform:rotate(360deg)}}
</style>
<div class="ct">
<form method="post" id="ct-form"><?= $hidden('save') ?>

  <h2 class="hb-h" id="what">What it is</h2>
  <div class="hb-card tv-bleed">
    <label class="ct-f">Name<input class="hb-in" name="name" maxlength="80" value="<?= $e($name) ?>"<?= $dis ?>></label>
    <label class="ct-f">Status<small><?= $runs === '' ? 'A copy is never run, whatever its status, until you use it as the running template (☰).' : ($t['kind'] === 'records' ? 'Running: it looks on its own as set below. Being shaped or Off: only when someone tries it here.' : 'Running: it writes on its own as set below. Being shaped or Off: it writes only what someone asks for (Write a draft on a guide).') ?></small>
      <select class="hb-in" name="status" style="max-width:16rem"<?= $dis ?>><?php foreach (ContentTemplates::STATUSES as $k => $l): ?><option value="<?= $e($k) ?>"<?= $sel($status === $k) ?>><?= $e($l) ?></option><?php endforeach; ?></select></label>
    <label class="ct-f">What it's for<textarea name="about" rows="2"<?= $dis ?>><?= $e((string) ($spec['about'] ?? '')) ?></textarea></label>
    <p class="text-sm" style="color:#8A7355">It makes <?= $e(mb_strtolower(ContentTemplates::KINDS[$t['kind']] ?? $t['kind'])) ?>. <?= $runs !== '' ? 'Run by ' . $e($runs) . '.' : '' ?></p>
  </div>

<?php if ($t['kind'] === 'records'): $flds = (array) ($w['fields'] ?? []); $rn = (array) ($spec['runs'] ?? []); ?>
  <h2 class="hb-h" id="runs">When it runs</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">It looks for each place's events once the place's guide is live, by the guide job, one place a run, every <?= $e((string) ($rn['every'] ?? '15 minutes')) ?>. For these kinds of guide:</p>
    <div class="ct-row" role="group" aria-label="Kinds of guide it looks for">
      <?php foreach (Guides::TIERS as $lvl => [$tier, $kind]): ?><label class="text-sm"><input type="checkbox" name="auto_tiers[]" value="<?= (int) $tier ?>"<?= in_array((int) $tier, array_map('intval', (array) ($ap['auto_tiers'] ?? [])), true) ? ' checked' : '' ?><?= $dis ?>> <?= $e($kind) ?></label><?php endforeach; ?>
    </div>
    <div class="ct-row">
      <label class="ct-f">Look again every<small>1 to 60 days</small><input class="hb-in" type="number" min="1" max="60" name="refresh_days" value="<?= (int) ($rn['refresh_days'] ?? 7) ?>"<?= $dis ?>></label>
      <label class="ct-f">Look this far ahead<small>7 to 365 days</small><input class="hb-in" type="number" min="7" max="365" name="horizon_days" value="<?= (int) ($rn['horizon_days'] ?? 120) ?>"<?= $dis ?>></label>
      <label class="ct-f">Places each run<small>1 to 5</small><input class="hb-in" type="number" min="1" max="5" name="per_run" value="<?= (int) ($rn['per_run'] ?? 1) ?>"<?= $dis ?>></label>
    </div>
    <p class="text-sm" style="color:#8A7355">How many a day and the monthly budget: <a class="underline" href="/admin/config/ai">AI use</a> → Live events.</p>
  </div>

  <h2 class="hb-h" id="gather">What it gathers</h2>
  <div class="hb-card tv-bleed">
    <ol class="text-sm" style="margin:.3rem 0 .6rem 1.2rem">
      <?php foreach ((array) ($spec['gather']['order'] ?? []) as $src): [$sn, $paid, $sw] = ContentTemplates::SOURCES[$src] ?? [$src, false, '']; ?>
      <li><b><?= $e($sn) ?></b><?= $paid ? ' <small style="color:#B45309">(paid)</small>' : ' <small style="color:#3F7A5E">(free)</small>' ?>: <?= $e($sw) ?></li>
      <?php endforeach; ?>
    </ol>
    <label class="ct-f" style="max-width:20rem">Web searches a place, at most<small>0 to 10, about 1¢ each; only for what its own pages don't list</small><input class="hb-in" type="number" min="0" max="10" name="searches" value="<?= (int) ($spec['gather']['searches'] ?? 3) ?>"<?= $dis ?>></label>
  </div>

  <h2 class="hb-h" id="write">What it writes</h2>
  <div class="hb-card tv-bleed">
    <label class="ct-f">What to find<small>{place} is the place's name, {days} how far ahead</small><textarea name="purpose" rows="4"<?= $dis ?>><?= $e((string) ($w['purpose'] ?? '')) ?></textarea></label>
    <label class="ct-f">The voice<textarea name="voice" rows="2"<?= $dis ?>><?= $e((string) ($w['voice'] ?? '')) ?></textarea></label>
    <label class="ct-f" style="max-width:20rem">Longest answer<small>1,000 to 16,000 tokens</small><input class="hb-in" type="number" min="1000" max="16000" step="500" name="max_tokens" value="<?= (int) ($w['max_tokens'] ?? 4000) ?>"<?= $dis ?>></label>
    <h3 style="font:700 1rem var(--tv-font-head,Georgia,serif);margin:1rem 0 .2rem">Each event's fields</h3>
    <?php foreach ($flds as $fd): $fk = (string) $fd['key']; $fon = !array_key_exists('on', $fd) || $fd['on']; ?>
    <div class="ct-sec<?= !$fon ? ' off' : '' ?>">
      <h3><?= $e((string) $fd['label']) ?> <small><?= !empty($fd['required']) ? 'always' : 'optional' ?></small></h3>
      <?php if (empty($fd['required'])): ?><label class="text-sm"><input type="checkbox" name="fld[<?= $e($fk) ?>][on]" value="1"<?= $fon ? ' checked' : '' ?><?= $dis ?>> Ask for it</label><?php endif; ?>
      <label class="ct-f" style="margin-bottom:0">Instruction<textarea name="fld[<?= $e($fk) ?>][instruction]" rows="2"<?= $dis ?>><?= $e((string) ($fd['instruction'] ?? '')) ?></textarea></label>
    </div>
    <?php endforeach; ?>
  </div>

  <h2 class="hb-h" id="check">How it's checked</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">An event shows only with a date ahead inside the window and the page that announces it; its venue is matched to our listings where we have it. One whose name or venue may mark a protected place waits for a person in <a class="underline" href="/admin/explore/events">Let's Explore → Live events</a>, where any event can be taken down (it stays down).</p>
  </div>

  <h2 class="hb-h" id="shelf">How long it lasts</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">An event shows until the day after it ends, then it's past. It shows in <?= $e(implode(', and on ', array_map('lcfirst', (array) ($spec['shows'] ?? [])))) ?>.</p>
  </div>
<?php else: ?>
  <h2 class="hb-h" id="runs">When it runs</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">Any place's guide can be written when someone asks. These guides are also written on their own, busiest first, by the guide job every <?= $e((string) ($spec['runs']['every'] ?? '15 minutes')) ?>:</p>
    <div class="ct-row" role="group" aria-label="Kinds of guide written on their own">
      <?php foreach (Guides::TIERS as $lvl => [$tier, $kind]): ?><label class="text-sm"><input type="checkbox" name="auto_tiers[]" value="<?= (int) $tier ?>"<?= in_array((int) $tier, array_map('intval', (array) ($ap['auto_tiers'] ?? [])), true) ? ' checked' : '' ?><?= $dis ?>> <?= $e($kind) ?></label><?php endforeach; ?>
    </div>
    <div class="ct-row">
      <label class="ct-f">Listings a place needs first<small>a place with fewer waits for someone to ask</small><input class="hb-in" type="number" min="1" max="200" name="min_listings" value="<?= (int) ($ap['min_listings'] ?? 5) ?>"<?= $dis ?>></label>
      <label class="ct-f">Guides written each run<small>1 to 10; each run is 15 minutes apart</small><input class="hb-in" type="number" min="1" max="10" name="per_run" value="<?= (int) ($spec['runs']['per_run'] ?? 1) ?>"<?= $dis ?>></label>
    </div>
    <p class="text-sm" style="color:#8A7355">A place picked for its first guide gathers its free sources for up to two days first. How many a day and the monthly budget are set per feature in <a class="underline" href="/admin/config/ai">AI use</a>.</p>
  </div>

  <h2 class="hb-h" id="gather">What it gathers</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">In this order, free first:</p>
    <ol class="text-sm" style="margin:.3rem 0 .6rem 1.2rem">
      <?php foreach ((array) ($spec['gather']['order'] ?? []) as $src): [$sn, $paid, $sw] = ContentTemplates::SOURCES[$src] ?? [$src, false, '']; ?>
      <li><b><?= $e($sn) ?></b><?= $paid ? ' <small style="color:#B45309">(paid)</small>' : ' <small style="color:#3F7A5E">(free)</small>' ?>: <?= $e($sw) ?></li>
      <?php endforeach; ?>
    </ol>
    <label class="ct-f" style="max-width:20rem">Web searches while writing, when a research brief is held<small>0 to 10, about 1¢ each; without a brief, the feature's own setting</small><input class="hb-in" type="number" min="0" max="10" name="searches_with_brief" value="<?= (int) ($spec['gather']['searches_with_brief'] ?? 2) ?>"<?= $dis ?>></label>
  </div>

  <h2 class="hb-h" id="write">What it writes</h2>
  <div class="hb-card tv-bleed">
    <label class="ct-f">What it must do<small>{place} is the place's name</small><textarea name="purpose" rows="4"<?= $dis ?>><?= $e((string) ($w['purpose'] ?? '')) ?></textarea></label>
    <label class="ct-f">What it writes from, in order of trust<textarea name="trust" rows="4"<?= $dis ?>><?= $e((string) ($w['trust'] ?? '')) ?></textarea></label>
    <label class="ct-f">The voice<textarea name="voice" rows="6"<?= $dis ?>><?= $e((string) ($w['voice'] ?? '')) ?></textarea></label>
    <label class="ct-f">Formatting<small>one rule a line; the one about **bold** names goes with the linking rule</small><textarea name="format" rows="3"<?= $dis ?>><?= $e(implode("\n", (array) ($w['format'] ?? []))) ?></textarea></label>
    <label class="ct-f" style="max-width:20rem">Longest a pass may run<small>2,000 to 32,000 tokens (about 3/4 of a word each)</small><input class="hb-in" type="number" min="2000" max="32000" step="1000" name="max_tokens" value="<?= (int) ($w['max_tokens'] ?? 16000) ?>"<?= $dis ?>></label>
    <h3 style="font:700 1rem var(--tv-font-head,Georgia,serif);margin:1rem 0 .2rem">Sections</h3>
    <p class="text-sm" style="color:#8A7355">The story sections are written in the first pass, the practical ones in the second, so each has room. Sections built from our data (no AI) are listed for their place in the order. The guide page keeps its own headings.</p>
    <?php foreach ((array) ($w['sections'] ?? []) as $i => $sx): $k = (string) $sx['key']; $on = !array_key_exists('on', $sx) || $sx['on']; ?>
    <div class="ct-sec<?= !empty($sx['written']) && !$on ? ' off' : '' ?>">
      <h3><?= $e((string) $sx['heading']) ?> <small><?= !empty($sx['written']) ? 'written by Claude' : 'built from our data' ?></small></h3>
      <div class="ct-row">
        <label>Order<input class="hb-in" type="number" name="sec[<?= $e($k) ?>][order]" value="<?= ($i + 1) * 10 ?>"<?= $dis ?>></label>
        <?php if (!empty($sx['written'])): ?>
        <label>Pass<select class="hb-in" name="sec[<?= $e($k) ?>][pass]"<?= $dis ?>><option value="story"<?= $sel(($sx['pass'] ?? '') === 'story') ?>>First: the story</option><option value="practical"<?= $sel(($sx['pass'] ?? '') !== 'story') ?>>Second: practical</option></select></label>
        <label style="align-self:end"><input type="checkbox" name="sec[<?= $e($k) ?>][on]" value="1"<?= $on ? ' checked' : '' ?><?= $dis ?>> Claude writes it</label>
        <?php endif; ?>
      </div>
      <?php if (!empty($sx['written'])): ?><label class="ct-f" style="margin-bottom:0">Instruction<textarea name="sec[<?= $e($k) ?>][instruction]" rows="3"<?= $dis ?>><?= $e((string) ($sx['instruction'] ?? '')) ?></textarea></label><?php else: ?><p class="text-sm" style="color:#8A7355;margin:0"><?= $e((string) ($sx['note'] ?? '')) ?></p><?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <h2 class="hb-h" id="check">How it's checked</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">Each guide gets a confidence score: <?= $e((string) ($spec['check']['score'] ?? '')) ?>. It goes live by itself at the score set in <a class="underline" href="/admin/config/thresholds">Thresholds &amp; gates</a> (Guides publish themselves); below it, it waits for a person.</p>
    <p class="text-sm">It waits as a draft whatever its score when: <?= $e(implode('; ', (array) ($spec['check']['holds'] ?? []))) ?>.</p>
  </div>

  <h2 class="hb-h" id="shelf">How long it lasts</h2>
  <div class="hb-card tv-bleed">
    <label class="ct-f" style="max-width:20rem">Check each live guide every<small>7 to 365 days; sooner when something changes (a place it names closes, the season turns, new records)</small><input class="hb-in" type="number" min="7" max="365" name="check_days" value="<?= (int) ($spec['shelf']['check_days'] ?? 30) ?>"<?= $dis ?>></label>
    <p class="text-sm" style="color:#8A7355">The crawler's dossier is renewed every <?= (int) ($spec['shelf']['dossier_days'] ?? 180) ?> days and the research brief every <?= (int) ($spec['shelf']['research_days'] ?? 365) ?>. What a check finds in Claude's own sections is fixed by the least costly model first, else written again; a person's sections get a note in their editor.</p>
  </div>

<?php endif; ?>
  <h2 class="hb-h" id="standard">The exposure standard</h2>
  <div class="hb-card tv-bleed">
    <p data-tv-status="info" data-tv-label="Locked:">The same in every template, and changed only by a decision (decisions/0133).</p>
    <ul class="ct-lock text-sm" style="margin:.4rem 0 0 1.2rem"><?php foreach (ContentTemplates::LOCKED as $l): ?><li><?= $e($l) ?></li><?php endforeach; ?></ul>
  </div>

  <div class="hb-card tv-bleed">
    <label class="ct-f">What changed<small>kept with the version</small><input class="hb-in" name="note" maxlength="300" placeholder="e.g. A warmer voice; Eat & drink in the first pass"<?= $dis ?>></label>
    <div class="ct-acts"><button class="hb-b go"<?= $dis ?>>Save template</button></div>
  </div>

  <h2 class="hb-h" id="try">Preview and try</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">For one place, with the template as it is in this form (saved or not). <b>Preview</b> shows exactly what Claude would be sent and what it would cost, and spends nothing. <b>Try it</b> has Claude write it, runs the same checks a guide gets, and shows what came back without saving anything to the guide or the template.</p>
    <label class="ct-f">Place<input class="hb-in" name="place" list="ct-places" value="<?= $e($placeIn) ?>" placeholder="Start typing a place" autocomplete="off"<?= $dis ?>></label>
    <datalist id="ct-places"><?= $places ?></datalist>
    <div class="ct-acts">
      <button class="hb-b" name="do" value="preview"<?= $dis ?>>Preview (free)</button>
      <button class="hb-b" name="do" value="try" data-confirm="Claude writes this place under the template as it is in the form. It costs about as much as one guide draft (Preview shows the estimate), and nothing is saved to the guide." data-yes="Try it"<?= $dis ?>>Try it</button>
    </div>
    <?php if ($preview): $est = $preview['estimate']; ?>
    <div class="ct-out">
      <p data-tv-status="<?= $preview['blocked'] !== '' ? 'bad' : 'info' ?>" data-tv-label="<?= $e($placeName($preview['key'])) ?>:"><?= $preview['passes'] ? count($preview['passes']) . ' pass' . (count($preview['passes']) === 1 ? '' : 'es') . ' with ' . $e(explode(' ', AiClient::MODELS[$preview['model']] ?? $preview['model'])[0]) . ', about $' . number_format($est[0], 2) . ($est[1] > $est[0] ? ' (up to $' . number_format($est[1], 2) . ' if every web search allowed is used)' : '') . '.' : 'Every section is written already: nothing for Claude to add.' ?>
        <?= !$preview['research_held'] && $preview['passes'] ? ' No research brief is held yet: it would be written first, about $' . number_format($preview['brief_usd'], 2) . ' of that.' : '' ?><?= isset($preview['pages']) ? ' It would read ' . (int) $preview['pages'] . ' official event page' . ((int) $preview['pages'] === 1 ? '' : 's') . ' first.' : '' ?><?= $preview['blocked'] !== '' ? ' Claude couldn\'t write it now: ' . $e($preview['blocked']) : '' ?></p>
      <?php foreach ($preview['passes'] as $i => $ps): ?>
      <h4>Pass <?= $i + 1 ?>: <?= $e(implode(', ', array_map(fn ($k) => Guides::SECTIONS[$k][0] ?? $k, $ps['sections']))) ?></h4>
      <p class="text-sm" style="color:#8A7355">About <?= number_format($ps['in']) ?> tokens in and <?= number_format($ps['out']) ?> out (up to <?= number_format($ps['max_tokens']) ?>), up to <?= (int) $ps['searches'] ?> web search<?= $ps['searches'] === 1 ? '' : 'es' ?>: about $<?= number_format($ps['usd'], 3) ?>, up to $<?= number_format($ps['usd_max'], 3) ?>.<?= $i > 0 ? ' It is also sent what the first pass wrote.' : '' ?></p>
      <details><summary class="text-sm" style="cursor:pointer;color:#92400E">What Claude would be sent (<?= number_format(mb_strlen($ps['prompt'])) ?> characters)</summary><pre><?= $e($ps['prompt']) ?></pre></details>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php if ($tried): ?>
    <div class="ct-out">
      <?php if ($t['kind'] === 'records'): ?>
      <p data-tv-status="info" data-tv-label="<?= $e($placeName($tried['key'])) ?>:"><?= $e($tried['say']) ?> Read <?= (int) ($tried['pages'] ?? 0) ?> official event page<?= (int) ($tried['pages'] ?? 0) === 1 ? '' : 's' ?> · cost $<?= number_format($tried['micros'] / 1e6, 3) ?>. Not saved.</p>
      <?= LiveEvents::html(array_map(fn ($r) => $r + ['venue_entity_id' => null], (array) $tried['events'])) ?>
      <?php if ($tried['dropped']): ?><h4>Left out by the checks</h4><ul class="text-sm" style="margin-left:1.2rem"><?php foreach ($tried['dropped'] as $c): ?><li><?= $e((string) $c) ?></li><?php endforeach; ?></ul><?php endif; ?>
      <?php else: ?>
      <p data-tv-status="info" data-tv-label="<?= $e($placeName($tried['key'])) ?>:">Confidence <?= (int) $tried['confidence'] ?> of 100 · cost $<?= number_format($tried['micros'] / 1e6, 3) ?>. Not saved to the guide.</p>
      <?php foreach ($tried['sections'] as $k => $txt): ?><h4><?= $e(Guides::SECTIONS[$k][0] ?? $k) ?></h4><?= $prose((string) $txt) ?><?php endforeach; ?>
      <?php if ($tried['check']): ?><h4>Claude says to check</h4><ul class="text-sm" style="margin-left:1.2rem"><?php foreach ($tried['check'] as $c): ?><li><?= $e((string) $c) ?></li><?php endforeach; ?></ul><?php endif; ?>
      <?php if ($tried['cut']): ?><h4>Taken out by the checks</h4><ul class="text-sm" style="margin-left:1.2rem"><?php foreach ($tried['cut'] as $c): ?><li><?= $e((string) $c) ?></li><?php endforeach; ?></ul><?php endif; ?>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</form>

<?php if ($tries): ?>
<h2 class="hb-h" id="tries">Earlier tries</h2>
<div class="hb-card tv-bleed">
  <?php foreach ($tries as $tr): $secs = json_decode((string) $tr['sections'], true) ?: []; $nt = json_decode((string) $tr['notes'], true) ?: []; ?>
  <details style="margin:.3rem 0"><summary class="text-sm" style="cursor:pointer"><b><?= $e($placeName((string) $tr['place_key'])) ?></b> · <?= $e(date('M j, g:ia', strtotime((string) $tr['tried_at']))) ?> · from version <?= (int) $tr['version'] ?> · confidence <?= (int) ($nt['confidence'] ?? 0) ?> · $<?= number_format((int) $tr['cost_micros'] / 1e6, 3) ?> · <?= $e($who((int) $tr['tried_by'])) ?></summary>
    <div class="ct-out"><?php if ($t['kind'] === 'records'): ?><?= LiveEvents::html(array_map(fn ($r) => (array) $r + ['venue_entity_id' => null], (array) ($secs['events'] ?? []))) ?: '<p class="text-sm">None found.</p>' ?><?php else: foreach ($secs as $k => $txt): ?><h4><?= $e(Guides::SECTIONS[$k][0] ?? $k) ?></h4><?= $prose((string) $txt) ?><?php endforeach; endif; ?></div>
  </details>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<h2 class="hb-h" id="versions">Versions</h2>
<div class="hb-card tv-bleed ct-scroll">
  <table><thead><tr><th>Version</th><th>Saved</th><th>By</th><th>What changed</th><th></th></tr></thead><tbody>
  <?php foreach ($versions as $v): ?>
    <tr><td><?= (int) $v['version'] ?></td><td><?= $e(date('M j, Y g:ia', strtotime((string) $v['saved_at']))) ?></td><td><?= $e($who((int) $v['saved_by'])) ?></td><td><?= $e((string) $v['note']) ?></td>
      <td><?php if ((int) $v['version'] !== (int) $t['version']): ?><form method="post" data-no-dirty><?= $hidden('restore') ?><input type="hidden" name="version" value="<?= (int) $v['version'] ?>"><button class="hb-b" data-confirm="Go back to version <?= (int) $v['version'] ?>? It's saved as a new version, so nothing is lost." data-yes="Go back"<?= $dis ?>>Go back to it</button></form><?php else: ?><small>Current</small><?php endif; ?></td></tr>
  <?php endforeach; ?>
  </tbody></table>
</div>

<h2 class="hb-h" id="copy">Copy</h2>
<div class="hb-card tv-bleed">
  <p class="text-sm">Shape a copy without changing what runs: try it on a few places, then use it as the running template (its spec becomes the running one's next version).</p>
  <form method="post" class="ct-dup" data-new><?= $hidden('duplicate') ?><label class="ct-f">Name of the copy<input class="hb-in" name="copy_name" maxlength="80" value="<?= $e($t['name'] . ' (copy)') ?>"<?= $dis ?>></label><div class="ct-acts"><button class="hb-b"<?= $dis ?>>Make a copy</button></div></form>
  <?php if ($runs === ''): ?>
  <div class="ct-acts">
    <form method="post" data-no-dirty><?= $hidden('useas') ?><input type="hidden" name="runs" value="<?= $t['kind'] === 'records' ? 'live_events' : 'place_guide' ?>"><button class="hb-b go" id="ct-useas-btn" data-confirm="Use this copy as the running Place guide template? The running one keeps it as its next version, so you can go back." data-yes="Use it"<?= $dis ?>>Use it as the running template</button></form>
    <form method="post" data-no-dirty><?= $hidden('remove') ?><button class="hb-b" id="ct-remove-btn" data-confirm="Remove this copy, with its versions and tries?" data-yes="Remove it" data-danger<?= $dis ?>>Remove this copy</button></form>
  </div>
  <?php endif; ?>
</div>
</div>
<script>
/* Try it takes a minute or two: the button shows it's working and the others wait */
(function () {
  var f = document.getElementById('ct-form'); if (!f) return;
  f.addEventListener('submit', function (ev) {
    var b = ev.submitter; if (!b || b.value !== 'try') return;
    setTimeout(function () {
      if (ev.defaultPrevented) return;
      f.querySelectorAll('button').forEach(function (x) { x.disabled = true; });
      b.innerHTML = '<span class="ge-spin" aria-hidden="true"></span>' + b.textContent;
      var n = document.createElement('p'); n.setAttribute('role', 'status'); n.className = 'text-sm'; n.textContent = 'Claude is writing it: this takes a minute or two. Stay on this page.'; b.parentNode.appendChild(n);
    }, 0);
  });
})();
</script>
<?php tv_admin_end();
