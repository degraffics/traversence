<?php
// /admin/search-learning.php — Search tools → Learning (decisions/0061, batch 3). Oversight, not approval: what search
// learned from what people open after their words, with the confidence score and the four signals behind it; the
// situation gaps and how the crawler is filling them (Tier 1 open data, then Tier 2 web search); the outside sources
// found; and new "<service> help" words. A person can hold a mapping at a status, or let learning decide again.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/UniversalSearch.php';
require_once __DIR__ . '/../../app/lib/Situations.php';
require_once __DIR__ . '/../../app/lib/Learning.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$ready = Learning::ready($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $ready) {
    if (hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        try {
            if (($_POST['do'] ?? '') === 'run') {
                @set_time_limit(180);
                $r = Learning::run($pdo, true);
                $g = $r['gaps'] ?? [];
                tv_crawler_flash(['type' => 'ok', 'text' => 'Scored ' . (int) ($r['scored'] ?? 0) . ' mapping(s), ' . count($r['changed'] ?? []) . ' changed. Gaps: '
                    . (int) ($g['gaps'] ?? 0) . ' in ' . (int) ($g['areas'] ?? 0) . ' area(s), ' . (int) ($g['tier1'] ?? 0) . ' with the crawler, ' . (int) ($g['tier2'] ?? 0) . ' for a web search, ' . (int) ($g['filled'] ?? 0) . ' filled.']);
            } elseif (($_POST['do'] ?? '') === 'set') {
                Learning::adminSet($pdo, (int) ($_POST['id'] ?? 0), (string) ($_POST['status'] ?? ''));
                tv_crawler_flash(['type' => 'ok', 'text' => ($_POST['status'] ?? '') === 'auto' ? 'Learning decides this one again.' : 'Held at ' . (Learning::STATUS[$_POST['status']] ?? '') . '.']);
            }
        } catch (Throwable $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    }
    header('Location: /admin/search-learning.php' . (isset($_POST['id']) ? '#l' . (int) $_POST['id'] : '')); exit;
}

$q1 = function (string $sql, array $a = []) use ($pdo): array { try { $st = $pdo->prepare($sql); $st->execute($a); return $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) { return []; } };
$show = (string) ($_GET['show'] ?? 'close'); if (!in_array($show, ['close', 'all', 'live', 'retired'], true)) $show = 'close';
$where = ['close' => "l.status IN ('live', 'may_help') OR l.score >= 0.5", 'all' => '1 = 1', 'live' => "l.status IN ('live', 'may_help')", 'retired' => "l.status = 'retired'"][$show];
$learned = $ready ? $q1("SELECT l.*, c.name AS cat, s.label AS sit FROM search_learned l JOIN categories c ON c.id = l.category_id LEFT JOIN situations s ON s.id = l.situation_id
                         WHERE $where ORDER BY FIELD(l.status, 'live', 'may_help', 'learning', 'retired'), l.score DESC LIMIT 120") : [];
$counts = []; foreach ($ready ? $q1('SELECT status, COUNT(*) AS n FROM search_learned GROUP BY status') : [] as $r) $counts[$r['status']] = (int) $r['n'];
$gaps = $ready ? $q1("SELECT g.*, s.label AS sit, m.name AS area FROM situation_gaps g JOIN situations s ON s.id = g.situation_id LEFT JOIN micro_clusters m ON m.id = g.cluster_id
                      WHERE g.status <> 'filled' OR g.updated_at >= ? ORDER BY FIELD(g.status, 'tier2', 'tier1', 'open', 'filled'), g.searches DESC LIMIT 80", [date('Y-m-d H:i:s', strtotime('-30 days'))]) : [];
$sources = $ready ? $q1("SELECT x.host, x.url, x.tier, x.found_at, c.name AS cat, s.label AS sit, x.phrase FROM situation_sources x JOIN categories c ON c.id = x.category_id
                         LEFT JOIN situations s ON s.id = x.situation_id ORDER BY x.found_at DESC LIMIT 40") : [];
$service = $ready ? Learning::serviceWords($pdo) : [];
$lastRun = $ready ? (int) SearchIndex::state($pdo, 'learning_run') : 0;
$pct = fn ($v) => round(100 * (float) $v);
$GAP = ['open' => 'Found', 'tier1' => 'Crawler (OpenStreetMap, Wikidata)', 'tier2' => 'Web search (.gov, .edu, sources we read)', 'filled' => 'Filled', 'none' => 'Nothing found'];

tv_page_start('Search learning', ['section' => 'admin', 'active' => 'learning', 'crumbs' => [['Admin', '/admin/'], ['Search tools', '/admin/search-misses.php'], ['Learning']],
    'description' => 'What search learned from what people open, and how the crawler fills the gaps.']);
$flash = tv_crawler_flash();
?>
<style>
  .lr{max-width:58rem}.lr h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.5rem;color:#3E2B1F;margin:0}.lr>p{font-size:.86rem;color:#5C4632;margin:.2rem 0 .8rem}
  .lr-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.8rem .9rem;margin-bottom:.8rem}
  .lr-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.05rem;margin:0 0 .15rem;color:#3E2B1F}.lr-card>p{font-size:.8rem;color:#5C4632;margin:0 0 .5rem}
  .lr-top{display:flex;flex-wrap:wrap;gap:.4rem;margin:.2rem 0 .6rem}.lr-top a{font-size:.8rem;border:1px solid #CBB98D;border-radius:999px;padding:.22rem .7rem;background:#FFFBF2;color:#3E2B1F;text-decoration:none}
  .lr-top a.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .lr-row{display:flex;gap:.6rem;align-items:flex-start;padding:.5rem 0;border-top:1px solid #EADFC4;font-size:.84rem}.lr-row .m{flex:1;min-width:0}
  .lr-row small{display:block;color:#7A6348;font-size:.74rem;overflow-wrap:anywhere}.lr-row a{color:#92400E}
  .lr-st{display:inline-block;font-size:.66rem;font-weight:700;border-radius:999px;padding:.05rem .5rem;margin-left:.3rem;vertical-align:1px}
  .lr-st.live{background:#8FBCA8;color:#1F3B30}.lr-st.may_help{background:#E5EFE9;color:#1F5137}.lr-st.learning{background:#F3E3CB;color:#7A4A1E}.lr-st.retired{background:#EADFC4;color:#7A6348}
  .lr-st.held{background:#3E2B1F;color:#FFFBF2}
  .lr-score{flex:0 0 3.3rem;text-align:right;font-weight:700;font-size:1rem;color:#3E2B1F}.lr-score small{font-weight:400}
  .lr-bars{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.3rem;margin:.3rem 0 .15rem;max-width:26rem}
  .lr-bar{font-size:.64rem;color:#7A6348}.lr-bar i{display:block;height:5px;border-radius:3px;background:#EADFC4;margin-top:.1rem;overflow:hidden}.lr-bar i b{display:block;height:100%;background:#B45309}
  .lr-acts{display:flex;flex-direction:column;gap:.3rem;flex:0 0 auto}
  .lr-acts select{border:1px solid #CBB98D;border-radius:.4rem;padding:.25rem .35rem;font-size:16px;background:#fff;color:#3E2B1F;max-width:9.5rem}
  .lr-btn{display:inline-flex;align-items:center;gap:.35rem;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.4rem .85rem;font:inherit;font-size:.84rem;font-weight:600;cursor:pointer}
  .lr-btn.main{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .lr-flash{padding:.5rem .7rem;border-radius:.4rem;margin:.4rem 0 .8rem;font-size:.86rem}.lr-flash.ok{background:#E5EFE9;color:#1F5137}.lr-flash.error{background:#FDE2D3;color:#9A3412}
  .lr-key{display:grid;gap:.25rem .8rem;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));font-size:.78rem;color:#5C4632}.lr-key b{color:#3E2B1F}
  @media (max-width:767px){ .lr-row{flex-wrap:wrap}.lr-acts{flex-direction:row;flex:1 1 100%} }
</style>
<div class="lr">
<?php require_once __DIR__ . '/../../app/ui/search-tools.php'; echo tv_search_tools_tabs('learning'); ?>
<h1>Learning</h1>
<p>What search learns about words and the kinds of things they mean, scored from 0 to 1 by relevance: the words themselves and outside sources that back them (decisions/0093). What people opened only suggests what to score and orders ties; it never raises a score. At <b><?= number_format(Learning::MAY_HELP, 2) ?></b> it's “May also help” (shown here only); at <b><?= number_format(Learning::PUBLISH, 2) ?></b> it's published: when it serves a situation, the words become one of its phrases. If its relevance falls, it retires on its own. Nobody has to approve it; anyone can hold one at a status here. Counts of words and areas only, never who.</p>
<?php if ($flash): ?><p class="lr-flash <?= $e($flash['type']) ?>" data-tv-flash="<?= $e($flash['type']) ?>"><?= $e($flash['text']) ?></p><?php endif; ?>
<?php if (!$ready): ?>
<p class="lr-card tv-bleed">Run <code>app/migrations/2026-10-23_search_learning.sql</code> in phpMyAdmin to start learning.</p>
<?php else: ?>
<section class="lr-card tv-bleed">
  <form method="post" style="display:flex;flex-wrap:wrap;gap:.6rem;align-items:center"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="run">
    <button type="submit" class="lr-btn main"><?= tv_icon('sparkle', '') ?> Run learning now</button>
    <span style="font-size:.8rem;color:#5C4632">It runs by itself every 6 hours when the crawler checks in<?= $lastRun ? '; last run ' . $e(date('M j, g:ia', $lastRun)) : '' ?>.
      Published <?= (int) ($counts['live'] ?? 0) ?> · May also help <?= (int) ($counts['may_help'] ?? 0) ?> · Learning <?= (int) ($counts['learning'] ?? 0) ?> · Retired <?= (int) ($counts['retired'] ?? 0) ?></span>
  </form>
</section>

<section class="lr-card tv-bleed" id="learned"><h2>What search learned</h2>
  <p>Each set of words and the kind of thing they may mean. ✎ the status to hold it there; “Let learning decide” undoes that.</p>
  <div class="lr-top"><?php foreach (['close' => 'Showing or close', 'live' => 'Showing', 'retired' => 'Retired', 'all' => 'All'] as $k => $l): ?><a class="<?= $show === $k ? 'on' : '' ?>" href="?show=<?= $k ?>#learned"><?= $e($l) ?></a><?php endforeach; ?></div>
  <?php if (!$learned): ?><p>Nothing yet. A mapping is scored once someone opens a kind of thing after some words; whether it shows depends on how well the words mean it.</p><?php endif; ?>
  <?php foreach ($learned as $l): $W = Learning::WEIGHTS; ?>
  <div class="lr-row" id="l<?= (int) $l['id'] ?>">
    <div class="lr-score"><?= number_format((float) $l['score'], 2) ?><small><br>score</small></div>
    <div class="m"><b>“<?= $e($l['phrase']) ?>”</b> → <?= $e(SearchText::catLabel((string) $l['cat'])) ?><?= $l['sit'] ? ' <span style="color:#7A6348">for ' . $e($l['sit']) . '</span>' : '' ?>
      <span class="lr-st <?= $e($l['status']) ?>"><?= $e(Learning::STATUS[$l['status']] ?? $l['status']) ?></span><?= (int) $l['held'] ? '<span class="lr-st held">Held</span>' : '' ?>
      <div class="lr-bars">
        <?php foreach ([['Words', 'text_match', $W['text']], ['Sources', 'sources', $W['sources']], ['Usage, ties only', 'behaviour', 0]] as [$bl, $bk, $bw]): ?>
        <span class="lr-bar"><?= $e($bl) ?> <?= $pct($l[$bk]) ?>% <small style="display:inline;font-size:.6rem">×<?= $bw ?></small><i><b style="width:<?= $pct($l[$bk]) ?>%"></b></i></span>
        <?php endforeach; ?>
      </div>
      <small><?= $e($l['why']) ?></small></div>
    <form method="post" class="lr-acts"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="set"><input type="hidden" name="id" value="<?= (int) $l['id'] ?>">
      <select name="status" aria-label="Status for &ldquo;<?= $e($l['phrase']) ?>&rdquo;" onchange="this.form.submit()">
        <option value="">✎ Status…</option>
        <?php foreach (Learning::STATUS as $k => $lab): ?><option value="<?= $k ?>">Hold: <?= $e($lab) ?></option><?php endforeach; ?>
        <?php if ((int) $l['held']): ?><option value="auto">Let learning decide</option><?php endif; ?>
      </select></form>
  </div>
  <?php endforeach; ?>
</section>

<section class="lr-card tv-bleed" id="gaps"><h2>Situation gaps</h2>
  <p>A situation people searched 3 or more times from an area (last 30 days) with nothing for one of its needs within 25 miles. Our own sources first, then <b>Tier 1</b>: the crawler looks in OpenStreetMap and Wikidata, and what it finds goes through the usual checks. <b>Tier 2</b>, a web search, only when Tier 1 can't: official sites only (.gov, .edu, state and local .us, and sources marked “Read regularly”), at most once a month each. Every useful page it finds becomes one of our sources, so the same search isn't paid for twice.</p>
  <?php if (!$gaps): ?><p>No gaps found yet (or none searched enough). They're looked for when learning runs.</p><?php endif; ?>
  <?php foreach ($gaps as $g): ?>
  <div class="lr-row"><div class="m"><b><?= $e($g['sit']) ?> › <?= $e($g['need_label']) ?></b> in <?= $e(PlaceScope::publicName((string) ($g['area'] ?? ''))) ?>
    <span class="lr-st <?= $g['status'] === 'filled' ? 'live' : ($g['status'] === 'tier2' ? 'learning' : 'may_help') ?>"><?= $e($GAP[$g['status']] ?? $g['status']) ?></span>
    <small><?= (int) $g['searches'] ?> search<?= (int) $g['searches'] === 1 ? '' : 'es' ?><?= $g['tier1_job_id'] ? ' · crawl job #' . (int) $g['tier1_job_id'] : '' ?><?= $g['tier2_at'] ? ' · web search ' . $e(date('M j', strtotime((string) $g['tier2_at']))) : '' ?><?= (int) $g['found'] ? ' · ' . (int) $g['found'] . ' found' : '' ?><?= $g['note'] !== '' ? ' · ' . $e($g['note']) : '' ?></small></div></div>
  <?php endforeach; ?>
</section>

<section class="lr-card tv-bleed"><h2>Outside sources found</h2>
  <p>Websites naming a kind of solution for a situation or for learned words: each counts once toward the score (3 or more is full). The pages also join <a href="/admin/sources.php" style="color:#92400E">Sources</a>.</p>
  <?php if (!$sources): ?><p>None yet.</p><?php endif; ?>
  <?php foreach ($sources as $x): ?>
  <div class="lr-row"><div class="m"><b><?= $e($x['host']) ?></b> <span class="lr-st <?= (int) $x['tier'] === 1 ? 'may_help' : 'learning' ?>">Tier <?= (int) $x['tier'] ?></span>
    <small><?= $e(SearchText::catLabel((string) $x['cat'])) ?> for <?= $e($x['sit'] ?: '“' . $x['phrase'] . '”') ?> · <?= $e(date('M j', strtotime((string) $x['found_at']))) ?><?= $x['url'] !== '' ? ' · <a href="' . $e($x['url']) . '" rel="nofollow noopener" target="_blank">page</a>' : '' ?></small></div></div>
  <?php endforeach; ?>
</section>

<section class="lr-card tv-bleed"><h2>New service words</h2>
  <p>“… help” and “help with …” searches (3 or more in 90 days). Words search doesn't know yet are marked; teach them in <a href="/admin/search-misses.php#mn-card" style="color:#92400E">Meanings</a> or add the phrase to a situation.</p>
  <?php if (!$service): ?><p>None yet.</p><?php endif; ?>
  <?php foreach ($service as $w): ?>
  <div class="lr-row"><div class="m"><b><?= $e($w['q']) ?></b> <span style="color:#7A6348">· <?= (int) $w['n'] ?> searches</span><?php foreach ($w['new'] as $nw): ?> <span class="lr-st learning">new: <?= $e($nw) ?></span><?php endforeach; ?></div></div>
  <?php endforeach; ?>
</section>

<section class="lr-card tv-bleed"><h2>How the score works</h2>
  <div class="lr-key">
    <div><b>Words × <?= Learning::WEIGHTS['text'] ?>:</b> how many of the words appear in the kind, the need and the situation.</div>
    <div><b>Sources × <?= Learning::WEIGHTS['sources'] ?>:</b> outside websites (Tier 1 open data, Tier 2 official pages) naming it for the situation or words: 3 or more is full.</div>
    <div><b>Usage × 0:</b> the share of searches for the words that opened that kind of thing. It never adds to the score; it only orders mappings that are equally relevant.</div>
    <div><b>Gate, whatever the score:</b> at least one listing of that kind with a phone. Tribal-land rules and sacred sites are handled where results are chosen, as everywhere.</div>
    <div><b>Thresholds:</b> <?= number_format(Learning::mayHelpAt($pdo), 2) ?> May also help, <?= number_format(Learning::publishAt($pdo), 2) ?> Published (<a class="underline" href="/admin/config/thresholds">Thresholds &amp; gates</a>).</div>
  </div>
</section>
<?php endif; ?>
</div>
<?php tv_page_end();
