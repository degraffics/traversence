<?php
// /admin/helper.php — the helper (decisions/0062, step 3): what needs a person, one item at a time, always
// Ask (what we know, already gathered) → Decide (the choices, the one we'd make marked, and why) → Act (one tap does
// it and goes to the next). Undo takes the last one back where that can be done; Skip leaves it for later. Today's
// order (safety first), or one queue only (?q=). Listings that pass every check that matters can be approved as a
// group after 5 samples; listings with one source go to the crawler for a second look on their own.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/Helper.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$uid = (int) $me['id'];
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
if (!isset($_SESSION['tv_helper']) || !is_array($_SESSION['tv_helper'])) $_SESSION['tv_helper'] = [];
$S = &$_SESSION['tv_helper'];
$S += ['skip' => [], 'undo' => null, 'done' => 0, 'note' => null, 'group_seen' => 0];
$q = preg_replace('/[^a-z]/', '', (string) ($_GET['q'] ?? ''));
$here = '/admin/helper.php' . ($q !== '' ? '?q=' . $q : '');

// ---- Act ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = ($_POST['json'] ?? '') !== '';
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        if ($json) { header('Content-Type: application/json'); http_response_code(403); echo json_encode(['error' => 'Your session expired. Reload the page.']); exit; }
        $S['note'] = ['error', 'Your session expired. Try again.']; header('Location: ' . $here, true, 303); exit;
    }
    $do = (string) ($_POST['do'] ?? '');
    try {
        if ($do === 'group') {
            @set_time_limit(120);
            $r = Helper::approveGroup($pdo, $uid, 100);
            $S['done'] += $r['approved'];
            header('Content-Type: application/json'); echo json_encode(['approved' => $r['approved'], 'tried' => $r['tried'], 'skipped' => count($r['skipped'])]); exit;
        }
        if ($do === 'batch') {   // "Do all as recommended" for this queue
            @set_time_limit(60);
            $r = Helper::doRecommended($pdo, (string) ($_POST['queue'] ?? ''), $uid, $S['skip'], 25);
            $S['skip'] = $r['skip']; $S['done'] += $r['done']; $S['undo'] = $r['undo'];
            $S['note'] = ['ok', 'Done as recommended: ' . $r['done'] . '.' . ($r['left_for_you'] ? ' ' . $r['left_for_you'] . ' had no clear recommendation and are left for you (Bring back what I skipped).' : '')
                               . ($r['more'] ? ' More are waiting: press it again.' : '')];
        } elseif ($do === 'undo') {
            if (!$S['undo']) throw new InvalidArgumentException('Nothing to undo.');
            $S['note'] = ['ok', Helper::undo($pdo, $S['undo'], $uid)]; $S['undo'] = null; $S['done'] = max(0, $S['done'] - 1);
        } elseif ($do === 'skip') {
            $S['skip'][] = (string) ($_POST['key'] ?? ''); $S['note'] = ['ok', 'Skipped for now.']; $S['undo'] = null;
        } elseif ($do === 'one_by_one') {
            $S['group_seen'] = 1; $S['note'] = null;
        } elseif ($do === 'restart') {
            $S['skip'] = []; $S['group_seen'] = 0; $S['note'] = ['ok', 'Skipped items are back.'];
        } else {
            $r = Helper::act($pdo, $_POST, $uid);
            $S['undo'] = $r['undo']; $S['done']++;
            $S['note'] = ['ok', $r['note']];
        }
    } catch (InvalidArgumentException $ex) { $S['note'] = ['error', $ex->getMessage()]; }
    catch (Throwable $ex) { error_log('admin/helper.php: ' . $ex->getMessage()); $S['note'] = ['error', 'That didn\'t work: ' . mb_substr($ex->getMessage(), 0, 160)]; }
    $back = (string) ($_POST['back'] ?? '');
    header('Location: ' . (str_starts_with($back, '/admin/') ? $back : $here), true, 303); exit;
}

// ---- Ask: the next item ----
$queues = Helper::queues($pdo);
$item = null; $tool = null; $group = null;
foreach ($q !== '' ? array_intersect_key($queues, [$q => 1]) : $queues as $k => $info) {
    if (!$info['handled']) {
        if (in_array('tool:' . $k, $S['skip'], true)) continue;
        $tool = [$k, $info]; break;
    }
    if ($k === 'listings' && !$S['group_seen'] && count(Helper::staged($pdo)['group']) >= 2) { $group = Helper::staged($pdo)['group']; break; }
    if ($item = Helper::next($pdo, $k, $S['skip'])) break;
}
$left = array_sum(array_map(fn ($x) => $x['n'], array_filter($queues, fn ($x) => $x['handled'])));
$note = $S['note']; $S['note'] = null;
$canUndo = (bool) $S['undo'];
$looking = Helper::staged($pdo)['looking'];

$STATUS = ['confirmed' => ['ok', 'Confirmed'], 'single' => ['warn', 'One source'], 'conflict' => ['bad', 'Sources disagree']];
$KIND = ['own_site' => 'Its own website', 'registry' => 'Official registry', 'government' => 'Government', 'chamber' => 'Chamber', 'community' => 'Community directory',
         'directory' => 'Directory', 'social' => 'Social page', 'tourism' => 'Tourism', 'open_data' => 'Open data', 'source' => 'Website', 'evidence' => 'Evidence link',
         'crawler' => 'Our records', 'owner' => 'Owner', 'admin' => 'Staff, checked', 'staff' => 'Staff, entered', 'member' => 'Member', 'import' => 'Import'];
$link = fn (string $url, string $text) => '<a href="' . $e($url) . '" target="_blank" rel="noopener nofollow">' . $e($text) . '</a>';
$host = fn (string $url) => preg_replace('/^www\./', '', (string) parse_url($url, PHP_URL_HOST));
$sources = function (array $list) use ($e, $KIND, $link): string {
    $h = '<ul class="hp-src">';
    foreach ($list as $s) $h .= '<li><em>' . $e($KIND[$s['kind']] ?? $s['kind']) . '</em>' . ($s['private'] ? ' <span class="p">private</span>' : '')
        . ($s['url'] !== '' ? ' · ' . $link($s['url'], $s['site'] !== '' ? $s['site'] : $s['label']) : ($s['label'] !== '' ? ' · ' . $e($s['label']) : ''))
        . ($s['note'] !== '' ? ' · “' . $e($s['note']) . '”' : '') . '</li>';
    return $h . '</ul>';
};
// "✎ I know this": a value staff know, saved with them as its source
$know = function (int $listing, string $fact = '', string $summary = '✎ I know this') use ($e, $csrf, $here): string {
    $h = '<details class="hp-know"><summary>' . $e($summary) . '</summary><form method="post"><input type="hidden" name="csrf" value="' . $e($csrf) . '">'
       . '<input type="hidden" name="do" value="know"><input type="hidden" name="listing" value="' . $listing . '"><input type="hidden" name="back" value="' . $e($here) . '">';
    if ($fact !== '') $h .= '<input type="hidden" name="fact" value="' . $e($fact) . '">';
    else {
        $h .= '<label>What<select name="fact">';
        foreach (array_keys(Identity::KNOWABLE) as $f) $h .= '<option value="' . $e($f) . '"' . ($f === 'phone' ? ' selected' : '') . '>' . $e(Identity::FACTS[$f][1]) . '</option>';
        $h .= '</select></label>';
    }
    return $h . '<label>The right value<input type="text" name="value" required autocomplete="off"></label>'
       . '<label>How do you know?<input type="text" name="note" placeholder="Called them · their sign · their own website" maxlength="300"></label>'
       . '<label class="hp-ck"><input type="checkbox" name="private" value="1"> Only staff see this note</label>'
       . '<button class="hp-btn main" type="submit">Save, with me as its source</button></form></details>';
};

tv_page_start('Helper', ['section' => 'admin', 'active' => 'helper', 'description' => 'Work through what needs doing, one item at a time.']);
?>
<style>
  .hp{max-width:46rem}.hp h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.5rem;color:#3E2B1F;margin:0}
  .hp-q{display:flex;flex-wrap:wrap;gap:.3rem;margin:.5rem 0}
  .hp-q a{font-size:.74rem;font-weight:600;border:1px solid #CBB98D;background:#FCFAEE;color:#5C4632;border-radius:999px;padding:.2rem .6rem;text-decoration:none}
  .hp-q a.on{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.3)}.hp-q a b{color:#B45309;margin-left:.2rem}.hp-q a.on b{color:#1F3B30}
  .hp-prog{display:flex;align-items:center;gap:.6rem;font-size:.78rem;color:#7A6348;margin:.2rem 0 .6rem}
  .hp-bar{flex:1;height:.45rem;border-radius:999px;background:#EADFC4;overflow:hidden}.hp-bar i{display:block;height:100%;background:#8FBCA8}
  .hp-note{display:flex;align-items:center;gap:.6rem;padding:.5rem .7rem;border-radius:.45rem;margin:.3rem 0 .7rem;font-size:.86rem}
  .hp-note.ok{background:#E5EFE9;color:#1F5137}.hp-note.error{background:#FDE2D3;color:#9A3412}.hp-note span{flex:1}
  .hp-card{position:relative;background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.8rem .9rem;margin-bottom:.7rem}
  .hp-kind{font-size:.66rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:#8A7355}
  .hp-name{display:inline-block;color:#92400E;text-decoration:underline;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.25rem;font-weight:700;margin:.1rem 2.6rem .2rem 0}
  span.hp-name{text-decoration:none}
  .hp-link{position:absolute;top:.6rem;right:.6rem;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:999px;border:1px solid #B88647;background:#FCFAEE;color:#B45309}
  .hp-link svg{width:15px;height:15px}.hp-link:hover{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8}
  .hp-step{font-size:.7rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#7A6348;margin:.8rem 0 .3rem;display:flex;align-items:center;gap:.4rem}
  .hp-step i{font-style:normal;display:inline-flex;width:1.3rem;height:1.3rem;border-radius:999px;background:#3E2B1F;color:#FFFBF2;align-items:center;justify-content:center;font-size:.68rem}
  .hp-dl{display:grid;grid-template-columns:auto 1fr;gap:.2rem .7rem;font-size:.84rem;margin:0}.hp-dl dt{color:#7A6348;font-size:.76rem;padding-top:.08rem}.hp-dl dd{margin:0;color:#3E2B1F;word-break:break-word}
  .hp-dl a,.hp-src a,.hp-p a{color:#92400E;text-decoration:underline}
  .hp-ck2{list-style:none;padding:0;margin:.3rem 0 0;font-size:.82rem}.hp-ck2 li{padding:.12rem 0}.hp-ck2 .y{color:#1F5137}.hp-ck2 .n{color:#9A3412}
  .hp-p{font-size:.84rem;color:#3E2B1F;margin:.3rem 0;white-space:pre-line}.hp-sm{font-size:.76rem;color:#7A6348;margin:.3rem 0}
  .hp-src{list-style:none;margin:.2rem 0 0;padding:0;font-size:.76rem;color:#5C4632}.hp-src li{padding:.08rem 0}.hp-src em{font-style:normal;font-weight:600;color:#3E2B1F}.hp-src .p{color:#9A3412;font-weight:700}
  .hp-cmp{width:100%;border-collapse:separate;border-spacing:0 3px;font-size:.8rem;table-layout:fixed}
  .hp-cmp th{font-size:.7rem;text-align:left;color:#7A6348;font-weight:700;padding:0 .35rem}.hp-cmp th:first-child{width:4.2rem}
  .hp-cmp td{padding:.3rem .35rem;vertical-align:top;background:#FFFBF2;word-break:break-word}.hp-cmp td:first-child{color:#7A6348;font-size:.72rem;border-radius:.35rem 0 0 .35rem}.hp-cmp td:last-child{border-radius:0 .35rem .35rem 0}
  .hp-cmp tr.same td{background:#E5EFE9}.hp-cmp tr.differs td,.hp-cmp tr.alike td{background:#FFF4CC}.hp-cmp tr.new_only td,.hp-cmp tr.old_only td{background:#FFFBF2}
  .hp-cmp label{display:flex;gap:.3rem;align-items:flex-start;cursor:pointer}.hp-cmp input{margin-top:.15rem;accent-color:#3E2B1F}.hp-cmp .none{color:#B7A587}
  .hp-legend{display:flex;flex-wrap:wrap;gap:.6rem;font-size:.7rem;color:#7A6348;margin:.25rem 0}.hp-legend i{display:inline-block;width:.7rem;height:.7rem;border-radius:.2rem;vertical-align:-1px;margin-right:.2rem}
  .hp-dec{display:flex;flex-direction:column;gap:.4rem}
  .hp-btn{display:inline-flex;align-items:center;justify-content:center;gap:.35rem;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.55rem .9rem;font:inherit;font-size:.9rem;font-weight:600;cursor:pointer;text-decoration:none;text-align:center}
  .hp-btn.main{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.hp-btn.main:hover{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}
  .hp-btn small{font-size:.66rem;font-weight:700;background:#8FBCA8;color:#1F3B30;border-radius:999px;padding:.05rem .4rem}
  .hp-why{font-size:.8rem;color:#1F5137;background:#E5EFE9;border-radius:.4rem;padding:.4rem .6rem;margin:0}
  .hp-row{display:flex;flex-wrap:wrap;gap:.45rem;align-items:center;margin-top:.6rem}
  .hp-row .hp-btn{padding:.4rem .8rem;font-size:.82rem}
  .hp-know{margin-top:.6rem;font-size:.84rem}.hp-know summary{cursor:pointer;color:#92400E;font-weight:600}
  .hp-know form,.hp-pick{display:grid;gap:.4rem;margin-top:.4rem}
  .hp label{font-size:.74rem;font-weight:600;color:#5C4632;display:grid;gap:.15rem}.hp label.hp-ck{display:flex;gap:.35rem;align-items:center;font-weight:400}
  .hp input[type=text],.hp select{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.4rem .5rem;font:inherit;font-size:16px;background:#fff;color:#3E2B1F}
  .hp-f{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.45rem;padding:.45rem .6rem;margin:.3rem 0;font-size:.84rem}
  .hp-st{display:inline-block;font-size:.66rem;font-weight:700;border-radius:999px;padding:.05rem .45rem;margin-left:.3rem}
  .hp-st.ok{background:#E5EFE9;color:#1F5137}.hp-st.warn{background:#FFF4CC;color:#7A5A00}.hp-st.bad{background:#FDE2D3;color:#9A3412}
  .hp-samp{border-top:1px solid #EADFC4;padding:.4rem 0;font-size:.82rem}.hp-samp b{color:#92400E}.hp-samp small{display:block;color:#7A6348;font-size:.74rem}
  .hp-done{background:#E5EFE9;color:#1F5137;border-radius:.5rem;padding:.8rem .9rem;font-size:.9rem}
</style>
<div class="hp">
<h1>Helper</h1>
<nav class="hp-q" aria-label="Queues">
  <a href="/admin/helper.php" class="<?= $q === '' ? 'on' : '' ?>">Everything, most urgent first</a>
  <?php foreach ($queues as $k => $x): ?><a href="/admin/helper.php?q=<?= $e($k) ?>" class="<?= $q === $k ? 'on' : '' ?>"><?= $e($x['label']) ?><b><?= $x['n'] > 999 ? '999+' : (int) $x['n'] ?></b></a><?php endforeach; ?>
</nav>
<div class="hp-prog"><span><?= (int) $S['done'] ?> done</span><span class="hp-bar"><i style="width:<?= $S['done'] + $left ? round(100 * $S['done'] / ($S['done'] + $left)) : 100 ?>%"></i></span><span><?= number_format($left) ?> left</span></div>
<?php if ($note || $canUndo): ?><div class="hp-note <?= $e($note[0] ?? 'ok') ?>"><span><?= $e($note[1] ?? 'You can still take back your last choice.') ?></span>
  <?php if ($canUndo && ($note[0] ?? 'ok') === 'ok'): ?><form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="undo"><input type="hidden" name="back" value="<?= $e($here) ?>"><button class="hp-btn" type="submit">Undo</button></form><?php endif; ?>
</div><?php endif; ?>

<?php if ($group): $n = count($group); ?>
  <section class="hp-card tv-bleed">
    <p class="hp-kind">Listings to approve · a group decision</p>
    <span class="hp-name"><?= number_format($n) ?> listings pass every check that matters</span>
    <p class="hp-p">Each is named by two or more independent websites or an official registry, has a sure kind, nothing wrong in its text, and no listing like it already. Only their confidence score is short of publishing on their own. Here are 5 of them:</p>
    <?php foreach (array_slice($group, 0, 5) as $r): $c = $r['payload']; ?>
      <div class="hp-samp"><b><?= $e($c['name'] ?? '') ?></b> · <?= $e($r['eval']['category_name']) ?><small><?= $e(trim(($c['where']['address'] ?? '') . ', ' . ($c['where']['city'] ?? ''), ', ')) ?> · <?= $e(implode(', ', AutoImport::sourceHosts($c))) ?></small></div>
    <?php endforeach; ?>
    <p class="hp-step"><i>2</i>Decide</p>
    <p class="hp-why">Recommended: approve all <?= number_format($n) ?>. They meet the same rules auto-import uses, except the score.</p>
    <div class="hp-row">
      <button class="hp-btn main" type="button" id="hpGroup">Approve all <?= number_format($n) ?></button>
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="one_by_one"><input type="hidden" name="back" value="<?= $e($here) ?>"><button class="hp-btn" type="submit">Go one by one</button></form>
    </div>
    <p class="hp-sm" id="hpGroupNote"></p>
  </section>
  <script>
  (function () {
    var b = document.getElementById('hpGroup'), note = document.getElementById('hpGroupNote'), done = 0;
    b.addEventListener('click', function () {
      b.disabled = true;
      (function step() {
        var f = new FormData(); f.append('csrf', <?= json_encode($csrf) ?>); f.append('do', 'group'); f.append('json', '1');
        fetch('/admin/helper.php', { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
          if (r.error) throw new Error(r.error);
          done += r.approved; note.textContent = 'Approved ' + done + '…';
          if (r.tried > 0) step(); else { note.textContent = 'Approved ' + done + '. Any it couldn\'t (a missing address…) come next, one by one.'; setTimeout(function () { location.reload(); }, 900); }
        }).catch(function (e) { b.disabled = false; note.textContent = 'Stopped: ' + e.message; });
      })();
    });
  })();
  </script>

<?php elseif ($tool): [$k, $x] = $tool; ?>
  <section class="hp-card tv-bleed">
    <p class="hp-kind"><?= $e($x['group']) ?></p>
    <span class="hp-name"><?= $e($x['label']) ?>: <?= number_format($x['n']) ?></span>
    <p class="hp-p">These are worked in their own tool for now. It opens with them listed.</p>
    <div class="hp-row">
      <a class="hp-btn main" href="<?= $e($x['url']) ?>">Open it</a>
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="skip"><input type="hidden" name="key" value="tool:<?= $e($k) ?>"><input type="hidden" name="back" value="<?= $e($here) ?>"><button class="hp-btn" type="submit">Next</button></form>
    </div>
  </section>

<?php elseif ($item): $d = $item['data']; $rec = array_values(array_filter($item['choices'], fn ($c) => $c[2])); ?>
  <section class="hp-card tv-bleed">
    <p class="hp-kind"><?= $e(Helper::QUEUES[$item['queue']][1]) ?></p>
    <?php
    // ---- each kind of item: its Ask ----
    $openUrl = ''; $extra = '';
    if ($item['queue'] === 'reports'):
        $openUrl = (string) ($d['url'] ?? ''); ?>
      <?= $openUrl !== '' ? '<a class="hp-name" href="' . $e($openUrl) . '" target="_blank">' . $e($item['title']) . '</a>' : '<span class="hp-name">' . $e($item['title']) . '</span>' ?>
      <p class="hp-step"><i>1</i>Ask</p>
      <dl class="hp-dl"><dt>Where</dt><dd><?= $e($d['where']) ?></dd><?php if ($d['author'] !== ''): ?><dt>By</dt><dd><?= $e($d['author']) ?></dd><?php endif; ?>
        <dt>Reported</dt><dd><?= (int) $d['count'] ?> time<?= $d['count'] == 1 ? '' : 's' ?>, first <?= $e(date('M j', strtotime((string) $d['first_at']))) ?><?= $d['hidden'] ? ' · hidden now' : '' ?></dd></dl>
      <p class="hp-p"><?= $e($d['text']) ?></p>
      <ul class="hp-src"><?php foreach (array_slice($d['reports'], 0, 8) as $rp): ?><li><em><?= $e(Reports::label((string) $rp['reason'])) ?></em><?= $rp['note'] ? ' · “' . $e($rp['note']) . '”' : '' ?></li><?php endforeach; ?></ul>

    <?php elseif ($item['queue'] === 'dupes'):
        $r = $d['row']; $c = $r['payload']; $into = (int) ($_GET['into'] ?? 0); if (!isset($d['cands'][$into])) $into = $d['best'];
        $b = $d['cands'][$into]; $old = $b['old']; $openUrl = '/admin/listing-intake.php?row=' . (int) $r['id']; ?>
      <a class="hp-name" href="<?= $e($openUrl) ?>"><?= $e($item['title']) ?></a>
      <p class="hp-sm">Found by the crawler<?= !empty($c['source']['start_url']) ? ' on ' . $e($host((string) $c['source']['start_url'])) : '' ?>. It may already be listed as <a class="underline text-amber-800" href="/listing/view.php?id=<?= (int) $old['id'] ?>" target="_blank">#<?= (int) $old['id'] ?> <?= $e($old['name']) ?></a><?= $old['claimed'] ? ' (claimed)' : '' ?><?= $b['why'] !== '' ? ': ' . $e(mb_strtolower($b['why'])) : '' ?>.</p>
      <p class="hp-step"><i>1</i>Ask: side by side</p>
      <div class="hp-legend"><span><i style="background:#E5EFE9;border:1px solid #8FBCA8"></i>the same</span><span><i style="background:#FFF4CC;border:1px solid #E3C766"></i>different: tap the one to keep</span></div>
      <?php ob_start(); ?>
      <table class="hp-cmp"><thead><tr><th></th><th>Found now</th><th>#<?= (int) $old['id'] ?><?= $old['claimed'] ? ' · claimed' : '' ?></th></tr></thead><tbody>
      <?php foreach ($b['cmp'] as $f => $x): $diff = in_array($x['state'], ['differs', 'alike', 'new_only'], true); ?>
        <tr class="<?= $e($x['state']) ?>"><td><?= $e($x['label']) ?></td>
        <?php foreach (['new', 'old'] as $side): $v = $x[$side]; ?>
          <td><?php if ($diff && $v !== ''): ?><label><input type="radio" name="pick[<?= $e($f) ?>]" value="<?= $side ?>" <?= $x['pick'] === $side ? 'checked' : '' ?>><span><?= $e($v) ?><?= $side === 'old' && $x['person'] ? ' <small>(entered by a person)</small>' : '' ?></span></label>
          <?php else: ?><?= $v !== '' ? $e($v) : '<span class="none">—</span>' ?><?php endif; ?></td>
        <?php endforeach; ?></tr>
      <?php endforeach; ?>
      </tbody></table>
      <input type="hidden" name="into" value="<?= (int) $old['id'] ?>">
      <?php $extra = (string) ob_get_clean(); ?>
      <?php if (count($d['cands']) > 1): ?><p class="hp-sm">Also alike: <?php foreach ($d['cands'] as $cid => $cx) if ($cid !== $into) echo '<a class="underline text-amber-800" href="' . $e($here . ($q !== '' ? '&' : '?') . 'into=' . $cid) . '">#' . $cid . ' ' . $e($cx['old']['name']) . '</a> '; ?>(compare with it instead)</p><?php endif; ?>
      <?php $item['choices'][0][1] = 'Same place: merge into #' . (int) $old['id']; ?>

    <?php elseif ($item['queue'] === 'listings'):
        $r = $d['row']; $c = $r['payload']; $ev = $r['eval']; $openUrl = '/admin/listing-intake.php?row=' . (int) $r['id']; ?>
      <a class="hp-name" href="<?= $e($openUrl) ?>"><?= $e($item['title']) ?></a>
      <p class="hp-step"><i>1</i>Ask</p>
      <dl class="hp-dl">
        <dt>Where</dt><dd><?= $e(trim(implode(', ', array_filter([$c['where']['address'] ?? '', $c['where']['city'] ?? '', trim(($c['where']['state'] ?? '') . ' ' . ($c['where']['zip'] ?? ''))])))) ?: '—' ?></dd>
        <dt>Phone</dt><dd><?= $e($c['actions']['phone'] ?? '') ?: '—' ?></dd>
        <dt>Website</dt><dd><?= !empty($c['actions']['website']) ? $link((string) $c['actions']['website'], $host((string) $c['actions']['website'])) : '—' ?></dd>
        <dt>Kind</dt><dd><?= $e($ev['category_name'] ?: 'not sure') ?></dd>
        <?php if (!empty($c['what']['description'])): ?><dt>About</dt><dd><?= $e(mb_strimwidth((string) $c['what']['description'], 0, 300, '…')) ?></dd><?php endif; ?>
        <dt>Sources</dt><dd><?= implode(', ', array_map(fn ($h) => $e($h), $d['hosts'])) ?: '—' ?></dd>
      </dl>
      <ul class="hp-ck2"><?php foreach ($ev['checks'] as $ck): ?><li class="<?= $ck['pass'] ? 'y' : 'n' ?>"><?= $ck['pass'] ? '✓' : '✗' ?> <?= $e($ck['label']) ?></li><?php endforeach; ?></ul>
      <?php ob_start(); $sugs = array_slice((array) ($c['category_suggestions'] ?? []), 0, 5); if ($sugs): ?>
        <label>Its kind, if you approve<select name="category"><?php foreach ($sugs as $sg): ?><option value="<?= (int) $sg['id'] ?>" <?= (int) $sg['id'] === (int) $ev['category_id'] ? 'selected' : '' ?>><?= $e($sg['name']) ?></option><?php endforeach; ?></select></label>
      <?php endif; $extra = (string) ob_get_clean(); ?>

    <?php elseif ($item['queue'] === 'conflicts'):
        $openUrl = '/admin/identities.php?id=' . (int) $d['entity']['id']; ?>
      <a class="hp-name" href="<?= $e($openUrl) ?>"><?= $e($item['title']) ?></a>
      <p class="hp-sm">#<?= (int) $d['entity']['id'] ?> · <?= $e($d['entity']['primary_zip']) ?> · <a class="underline text-amber-800" href="/listing/view.php?id=<?= (int) $d['entity']['id'] ?>" target="_blank">the listing</a></p>
      <p class="hp-step"><i>1</i>Ask: <?= $e(Identity::FACTS[$d['fact']][1] ?? $d['fact']) ?>, two values</p>
      <?php foreach ($d['values'] as $v): [$sc, $sw] = $STATUS[$v['status']] ?? ['warn', $v['status']]; ?>
        <div class="hp-f"><b><?= $e($v['value']) ?></b><?= $v['current'] ? '<span class="hp-st ok">on the listing now</span>' : '' ?><span class="hp-st warn"><?= (int) $v['sources_n'] ?> independent</span><?= $sources($v['sources']) ?></div>
      <?php endforeach; ?>
      <?php if (!$d['knowable']): ?><p class="hp-sm">This one is set in the listing's editor. <a class="underline text-amber-800" href="/admin/listing-edit.php?id=<?= (int) $d['entity']['id'] ?>">Edit the listing</a></p><?php endif; ?>
      <?php ob_start(); ?><label>How do you know? (optional)<input type="text" name="note" maxlength="300" placeholder="Called them · their own website"></label><?php $extra = (string) ob_get_clean(); ?>

    <?php elseif ($item['queue'] === 'found'):
        $f = $d['fact']; $openUrl = '/admin/identities.php?id=' . (int) $d['listing']; ?>
      <a class="hp-name" href="<?= $e($openUrl) ?>"><?= $e($item['title']) ?></a>
      <p class="hp-sm">#<?= (int) $d['listing'] ?> · <a class="underline text-amber-800" href="/listing/view.php?id=<?= (int) $d['listing'] ?>" target="_blank">the listing</a> has no <?= $e(mb_strtolower($d['label'])) ?>.</p>
      <p class="hp-step"><i>1</i>Ask: the crawler found <?= $e(mb_strtolower($d['label'])) ?></p>
      <div class="hp-f"><b><?= in_array($f['fact'], ['website'], true) ? $link((string) $f['value'], (string) $f['value']) : $e($f['value']) ?></b><?= $sources($f['sources']) ?></div>
      <p class="hp-sm">The crawler looked at its own website, the official registries and a web search, in that order. Google, Yelp and Facebook pages only confirm what another page gave.</p>

    <?php elseif ($item['queue'] === 'sources'):
        $openUrl = (string) ($d['home_url'] ?: 'https://' . $d['host'] . '/'); ?>
      <a class="hp-name" href="<?= $e($openUrl) ?>" target="_blank" rel="noopener nofollow"><?= $e($item['title']) ?></a>
      <p class="hp-step"><i>1</i>Ask</p>
      <dl class="hp-dl"><dt>Website</dt><dd><?= $e($d['host']) ?></dd><dt>Kind</dt><dd><?= $e(Sources::KINDS[$d['kind']] ?? $d['kind']) ?></dd>
        <dt>Confirmed</dt><dd><?= (int) $d['confirmations'] ?> listing<?= (int) $d['confirmations'] === 1 ? '' : 's' ?><?= !empty($d['last_listing']) ? ', last “' . $e($d['last_listing']) . '”' : '' ?></dd>
        <?php if (!empty($d['sample_url'])): ?><dt>Page</dt><dd><?= $link((string) $d['sample_url'], mb_strimwidth((string) $d['sample_url'], 0, 70, '…')) ?></dd><?php endif; ?></dl>

    <?php elseif ($item['queue'] === 'failed'): $again = class_exists('CrawlQueue') ? CrawlQueue::retryAt($d) : null; ?>
      <span class="hp-name"><?= $e($item['title']) ?></span>
      <p class="hp-step"><i>1</i>Ask</p>
      <dl class="hp-dl"><dt>Area</dt><dd><?= $e(preg_replace('/\s*\(auto-seeded[^)]*\)/i', '', (string) $d['cluster'])) ?: '—' ?></dd><dt>Failed</dt><dd><?= $e(substr((string) $d['updated_at'], 0, 16)) ?>, after <?= (int) $d['attempts'] ?> tries</dd>
        <dt>Why</dt><dd><?= $e(mb_strimwidth((string) $d['error'], 0, 300, '…')) ?: 'No reason given' ?></dd><dt>Next try</dt><dd><?= $again ? 'on its own, ' . $e(date('M j, g:ia', $again)) : 'none: it gave up' ?></dd></dl>
    <?php endif; ?>
    <?php if ($openUrl !== '' && $item['queue'] !== 'failed'): ?><a class="hp-link" href="<?= $e($openUrl) ?>" target="_blank" title="Open it" aria-label="Open it"><?= tv_icon('link', 'ta-svg') ?></a><?php endif; ?>

    <form method="post" class="hp-pick">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="key" value="<?= $e($item['key']) ?>"><input type="hidden" name="back" value="<?= $e($here) ?>">
      <?= $extra ?>
      <p class="hp-step"><i>2</i>Decide</p>
      <?php if ($rec && $rec[0][3] !== ''): ?><p class="hp-why"><b>Recommended:</b> <?= $e($rec[0][3]) ?></p><?php endif; ?>
      <?php if (!empty($item['note'])): ?><p class="hp-sm"><?= $e($item['note']) ?></p><?php endif; ?>
      <p class="hp-step"><i>3</i>Act</p>
      <div class="hp-dec">
        <?php foreach ($item['choices'] as [$do, $label, $isRec]): ?>
          <button class="hp-btn<?= $isRec ? ' main' : '' ?>" type="submit" name="do" value="<?= $e($do) ?>"<?= $do === 'd_merge' ? ' formnovalidate' : '' ?>><?= $e($label) ?><?= $isRec ? ' <small>Recommended</small>' : '' ?></button>
        <?php endforeach; ?>
      </div>
    </form>
    <div class="hp-row">
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="skip"><input type="hidden" name="key" value="<?= $e($item['key']) ?>"><input type="hidden" name="back" value="<?= $e($here) ?>"><button class="hp-btn" type="submit">Skip for now</button></form>
      <?php if (in_array($item['queue'], Helper::BATCH, true)): $bn = (int) ($queues[$item['queue']]['n'] ?? 0); ?>
        <form method="post" data-yes="Do them" data-confirm="Do all <?= $bn ?> <?= $e(mb_strtolower(Helper::QUEUES[$item['queue']][1])) ?> as recommended? Ones with no clear recommendation are left for you. One Undo takes the whole batch back.">
          <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="batch"><input type="hidden" name="queue" value="<?= $e($item['queue']) ?>"><input type="hidden" name="back" value="<?= $e($here) ?>">
          <button class="hp-btn main" type="submit">Do all <?= $bn ?> as recommended</button></form>
      <?php endif; ?>
      <?php if (in_array($item['queue'], ['dupes', 'listings'], true)): ?><a class="hp-btn" href="<?= $e($openUrl) ?>">Edit everything</a><?php endif; ?>
    </div>
    <?php if ($item['queue'] === 'conflicts' && $d['knowable']) echo $know((int) $d['entity']['id'], (string) $d['fact'], '✎ Neither: I know the right one'); ?>
    <?php if ($item['queue'] === 'found') echo $know((int) $d['listing'], (string) $d['fact']['fact'], '✎ I know the right one'); ?>
    <?php if ($item['queue'] === 'dupes') echo '<p class="hp-sm">Merging adds what\'s new to #' . (int) ($old['id'] ?? 0) . ' and keeps anything a person entered. It can\'t be undone from here.</p>'; ?>
  </section>

<?php else: ?>
  <div class="hp-done tv-bleed"><?= $q !== '' && isset(Helper::QUEUES[$q]) ? 'Nothing left in ' . $e(mb_strtolower(Helper::QUEUES[$q][1])) . '.' : 'All caught up.' ?>
    <?= $S['skip'] ? ' You skipped ' . count($S['skip']) . '.' : '' ?></div>
  <?php if ($S['skip']): ?><form method="post" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="restart"><input type="hidden" name="back" value="<?= $e($here) ?>"><button class="hp-btn" type="submit">Bring back what I skipped</button></form><?php endif; ?>
<?php endif; ?>

<?php if ($looking && in_array($q, ['', 'listings'], true)): ?><p class="hp-sm"><?= number_format($looking) ?> more listing<?= $looking === 1 ? ' is' : 's are' ?> with the crawler for a second look (its own website, the registries, our sources, then web search). They come here when it's done.</p><?php endif; ?>
</div>
<?php tv_page_end();
