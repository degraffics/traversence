<?php
// admin/people.php — People & roles, an area of the admin dashboard (decisions/0078, 0079).
//   Members  staff don't browse accounts (Jason, 2026-10-11): find one member by name, #number or the exact email from
//            their request, and open them with a reason, which is recorded. The card is the sign-up basics (confirmed,
//            18+, Verified, roles, choices) and their standing; email and phone are a separate, recorded reveal for
//            official contact only. Actions go through notices of action (app/lib/Standing.php): a warning, or revoke
//            now for a serious violation; and a notice can be lifted or upheld.
//   Staff    Traversence staff and regional managers, and what each can do; Owners add and remove roles
//            (the same as the member Dashboard's Staff & roles was, /user/api/context.php)
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/Standing.php';

$pdo = Database::connection();
[$me, $ctx] = tv_admin_require($pdo);
$canPeople = $ctx['kind'] === 'admin' && Roles::can($ctx, 'people');
tv_admin_start('people', 'People & roles', 'Open a member\'s account only for an issue or their request: say why, and it\'s recorded. See their sign-up basics and standing, send a notice, or decide a review. And the staff: who can do what.');

ob_start(); ?>
<?php if (!$canPeople): ?>
<div class="hb-card tv-bleed"><p class="text-sm">Looking up members is for staff with the People role (Owners and Managers). Your roles: <?= tv_e(implode(', ', array_map(fn ($r) => Roles::ROLES[$r] ?? $r, $ctx['roles'] ?? []))) ?: 'none on the staff side' ?>.</p></div>
<?php else: ?>
<div class="hb-card tv-bleed">
  <label class="text-sm font-bold" for="pp-q">Find a member</label>
  <input id="pp-q" class="hb-in mt-1" type="search" placeholder="Name, #number, or the exact email from their request" autocomplete="off">
  <p class="text-xs text-[#8A7355] mt-1">We don't browse accounts. Find the one you need for a report, their request, a claim or a flag.</p>
  <div id="pp-res" class="mt-2"></div>
  <div id="pp-why" class="mt-2" hidden>
    <p class="text-sm font-bold" id="pp-why-h">Why are you opening this account?</p>
    <div class="flex flex-wrap gap-2 mt-1">
      <select id="pp-why-s" class="hb-in" style="width:auto"><?php foreach (Standing::WHY as $k => $l): ?><option value="<?= $k ?>"><?= tv_e($l) ?></option><?php endforeach; ?></select>
      <input id="pp-why-n" class="hb-in" style="flex:1;min-width:10rem;width:auto" maxlength="200" placeholder="Report #, request or note (optional)">
      <button type="button" class="hb-b go" id="pp-why-go">Open</button>
    </div>
    <p class="text-xs text-[#8A7355] mt-1">Recorded with your name: who opened it, when and why.</p>
  </div>
</div>
<div id="pp-one" class="hb-card tv-bleed mt-2" hidden></div>
<?php endif; ?>
<?php $members = (string) ob_get_clean();

tv_admin_hub('People & roles', [
    'members' => ['label' => 'Members', 'html' => $members],
    'staff' => ['label' => 'Staff & roles', 'html' => '<div class="hb-card tv-bleed" id="team-box"><p class="text-sm">Loading…</p></div>'],
    'logins' => ['label' => 'Staff logins', 'url' => '/admin/staff.php'],   // staff ID, password, authenticator (decisions/0100)
]);
?>
<style>
  .pp-h{display:flex;justify-content:space-between;align-items:flex-start;gap:.6rem}
  .pp-h h2{font:700 1.2rem var(--tv-font-head,Georgia,serif);color:#92400E;margin:0;text-decoration:underline}
  .pp-sub{font-size:.85rem;color:#5C4632;margin-top:.15rem}
  .pp-acts{display:flex;flex-direction:column;gap:.35rem;align-items:flex-end}
  .tm-r{display:flex;justify-content:space-between;align-items:center;gap:.6rem;padding:.55rem .1rem;border-top:1px solid #EADFC4;flex-wrap:wrap}
  .tm-r:first-of-type{border-top:0}
  .tm-role{font-size:.75rem;font-weight:700;border:1px solid #CBB98D;border-radius:999px;padding:.1rem .55rem;background:#FFFBF2}
  .tm-add{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.8rem}
</style>
<script>
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function day(s) { return s ? String(s).slice(0, 10) : ''; }
  var csrf = null;
  function token() { return csrf ? Promise.resolve(csrf) : fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { csrf = d.csrf_token || (d.data && d.data.csrf_token) || ''; return csrf; }); }
  function get(u) { return fetch(u, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) { if (j.ok === false || j.success === false || j.error) throw new Error((j.error && j.error.message) || j.error || 'That didn\'t work.'); return j.data || j; }); }

  // ---- Members ----
  var inp = document.getElementById('pp-q'), out = document.getElementById('pp-res'), one = document.getElementById('pp-one'), why = document.getElementById('pp-why'), t = null, seq = 0, picked = 0, WHY = '';
  function post(body) {
    return token().then(function (c) { return fetch('/admin/api/people.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); })
      .then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work.'); return j; });
  }
  function list() {
    var q = inp.value.trim(), my = ++seq;
    why.hidden = true;
    if (q.length < 3 && !/^#?\d+$/.test(q)) { out.innerHTML = ''; return; }
    get('/admin/api/people.php?q=' + encodeURIComponent(q)).then(function (d) {
      if (my !== seq) return;
      out.innerHTML = d.items.length ? d.items.map(function (m) {
        return '<div class="hb-row"><span><button type="button" class="hb-nm" data-member="' + m.id + '" data-name="' + esc(m.name) + '">' + esc(m.name) + '</button>'
          + (m.staff ? '<span class="hb-pill ok">Staff</span>' : '') + (m.revoked ? '<span class="hb-pill red">Access revoked</span>' : '')
          + '<small>#' + m.id + ' · joined ' + esc(m.joined) + '</small></span>'
          + '<button type="button" class="hb-b" data-member="' + m.id + '" data-name="' + esc(m.name) + '">Open</button></div>';
      }).join('') : '<p class="text-sm text-[#8A7355]">No one by that name or number' + (q.indexOf('@') > 0 ? ', or with exactly that email' : '') + '.</p>';
    }).catch(function (x) { out.innerHTML = '<p class="text-sm">' + esc(x.message) + '</p>'; });
  }
  var STATE = { active: ['On', 'ok'], update: ['On, asked again (new wording)', ''], paused: ['Off', ''], not_asked: ['Not asked yet', ''] };
  var DEFAULT_STEPS = <?= json_encode(Standing::DEFAULT_STEPS) ?>;
  function noticeHtml(n, mine) {
    var due = n.due_at ? ' · next step ' + esc(String(n.due_at).slice(0, 16)) : '';
    var h = '<div class="hb-card" style="background:#FFFBF2;margin-top:.4rem"><p><span class="hb-pill ' + (n.step >= 2 && (n.status === 'open' || n.status === 'review') ? 'red' : '') + '" style="margin-left:0">' + esc(n.step_label) + '</span>'
      + '<span class="hb-pill">' + esc(n.status_label) + '</span>' + (n.serious ? '<span class="hb-pill red">Serious</span>' : '') + ' <small class="text-[#8A7355]">' + esc(String(n.created_at).slice(0, 10)) + (n.source === 'trust' ? ' · from the trust score' : ' · from staff') + due + '</small></p>'
      + '<p class="text-sm mt-1"><b>What happened:</b> ' + esc(n.reason) + '</p>'
      + (n.review_text ? '<p class="text-sm mt-1"><b>Their review request:</b> ' + esc(n.review_text) + '</p>' : '')
      + (n.decision_note ? '<p class="text-sm mt-1"><b>Decision:</b> ' + esc(n.decision_note) + '</p>' : '');
    if (mine && (n.status === 'open' || n.status === 'review')) h += '<div class="flex flex-wrap gap-2 mt-2"><input class="hb-in" style="flex:1;min-width:10rem;width:auto" data-note="' + n.id + '" maxlength="500" placeholder="A note they\'ll read (optional)">'
      + '<button type="button" class="hb-b go" data-decide="lift" data-action="' + n.id + '">Lift</button>'
      + '<button type="button" class="hb-b" data-decide="uphold" data-action="' + n.id + '">' + (n.status === 'review' ? 'Uphold' : 'Restart the 24 hours') + '</button></div>';
    return h + '</div>';
  }
  function show(m) {
    var st = function (ok, yes, no) { return '<span class="hb-pill ' + (ok ? 'ok' : '') + '" style="margin-left:0">' + (ok ? yes : no) + '</span>'; };
    var h = '<div class="pp-h"><div><h2>' + esc(m.name) + '</h2><p class="pp-sub">#' + m.id + ' · joined ' + day(m.joined) + (m.me ? ' · you' : '') + '</p>'
      + (m.revoked ? '<p class="mt-1"><span class="hb-pill red" style="margin-left:0">Access revoked</span></p>' : '') + '</div>'
      + '<div class="pp-acts"><button type="button" class="hb-b" data-close>Close</button></div></div>';
    h += '<h3 class="hb-h">Sign-up basics</h3><dl class="hb-dl">'
      + '<dt>Email</dt><dd>' + st(m.email_confirmed, 'Confirmed', 'Not confirmed') + '</dd>'
      + '<dt>18 or older</dt><dd>' + st(m.adult, 'Confirmed', 'Not confirmed') + '</dd>'
      + '<dt>Verified</dt><dd>' + st(m.verified, 'Verified', m.verification_on ? 'Switched on, not finished' : 'Not switched on') + '</dd>'
      + m.checks.filter(function (c) { return c[0] !== 'Email' && c[0] !== '18 or older'; }).map(function (c) { return '<dt>' + esc(c[0]) + '</dt><dd>' + st(c[1] === 'ok', 'Done', c[1] === 'coming' ? 'Coming' : 'Not yet') + '</dd>'; }).join('') + '</dl>';
    h += '<h3 class="hb-h">Roles</h3>' + (m.roles.length ? '<dl class="hb-dl">' + m.roles.map(function (r) { return '<dt>' + esc({ admin: 'Staff', org: 'Listing', steward: 'Communities' }[r.kind] || r.kind) + '</dt><dd>' + (r.url ? '<a class="underline text-[#92400E]" href="' + r.url + '" data-peek-frame>' + esc(r.label) + '</a>' : esc(r.label)) + ' · ' + esc(r.sub) + '</dd>'; }).join('') + '</dl>' : '<p class="text-sm mt-1">Member only.</p>');
    h += '<h3 class="hb-h">Privacy choices</h3>' + (m.choices.length ? '<dl class="hb-dl">' + m.choices.map(function (c) { var s = STATE[c.state] || [c.state, '']; return '<dt>' + esc(c.name) + '</dt><dd><span class="hb-pill ' + s[1] + '" style="margin-left:0">' + esc(s[0]) + '</span></dd>'; }).join('') + '</dl>' : '<p class="text-sm mt-1">Not recorded yet.</p>');
    h += '<h3 class="hb-h">Standing</h3>' + (m.notice ? noticeHtml(m.notice, true) : '<p class="text-sm mt-1">No notice in force.</p>');
    var past = m.history.filter(function (x) { return !m.notice || x.id !== m.notice.id; });
    if (past.length) h += '<details class="mt-2"><summary class="text-sm font-semibold text-amber-800 cursor-pointer">Earlier notices (' + past.length + ')</summary>' + past.map(function (x) { return noticeHtml(x, false); }).join('') + '</details>';
    if (m.can_act) {
      h += '<div class="flex flex-wrap gap-2 mt-3"><button type="button" class="hb-b" data-act="warn">Send a warning</button><button type="button" class="hb-b no" data-act="revoke">Revoke now (serious)</button>'
        + (m.revoked && !m.notice ? '<button type="button" class="hb-b go" data-restore="' + m.id + '">Restore access</button>' : '') + '</div>'
        + '<div id="pp-act" class="mt-2" hidden><label class="text-sm font-bold" for="pp-r">What happened (they read this)</label><textarea id="pp-r" class="hb-in mt-1" rows="3" maxlength="500"></textarea>'
        + '<label class="text-sm font-bold mt-2 block" for="pp-s">What to do to put it right</label><textarea id="pp-s" class="hb-in mt-1" rows="3" maxlength="1000"></textarea>'
        + '<p class="text-xs text-[#8A7355] mt-1" id="pp-act-note"></p><div class="flex gap-2 mt-2"><button type="button" class="hb-b go" id="pp-act-go">Send</button><button type="button" class="hb-b" id="pp-act-x">Cancel</button></div></div>';
    }
    h += '<h3 class="hb-h">Contact details</h3><p class="text-sm mt-1" id="pp-contact">Only for official contact when we can\'t reach them on Traversence. Showing them is recorded. '
      + '<button type="button" class="hb-b" data-contact="' + m.id + '">Show email and phone</button></p>';
    if (m.opened.length) h += '<details class="mt-3"><summary class="text-sm font-semibold text-amber-800 cursor-pointer">Who opened this account (' + m.opened.length + ')</summary>' + m.opened.map(function (o) { return '<p class="text-sm mt-1">' + esc(String(o.at).slice(0, 16)) + ' · ' + esc(o.by) + ' · ' + esc(o.why) + (o.note ? ': ' + esc(o.note) : '') + (o.contact ? ' <span class="hb-pill">Contact shown</span>' : '') + '</p>'; }).join('') + '</details>';
    one.innerHTML = h; one.hidden = false; one.setAttribute('data-id', m.id); one.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }
  function open(id, w, note) {
    WHY = w;
    get('/admin/api/people.php?id=' + id + '&why=' + encodeURIComponent(w) + '&note=' + encodeURIComponent(note || '')).then(function (d) { why.hidden = true; show(d.member); }).catch(function (x) { TvAsk.say(x.message); });
  }
  function reload() { var id = +one.getAttribute('data-id'); if (id) get('/admin/api/people.php?id=' + id + '&why=' + WHY + '&note=' + encodeURIComponent('after an action')).then(function (d) { show(d.member); }); }
  if (inp) {
    inp.addEventListener('input', function () { clearTimeout(t); t = setTimeout(list, 300); });
    var want = (location.hash.match(/^#members:(\d+)$/) || [])[1]; if (want) open(want, 'standing', 'from Safety → Standing');
    var actKind = '';
    document.addEventListener('click', function (e) {
      var b = e.target.closest('[data-member]');
      if (b) { picked = +b.getAttribute('data-member'); document.getElementById('pp-why-h').textContent = 'Why are you opening ' + b.getAttribute('data-name') + '\'s account?'; why.hidden = false; document.getElementById('pp-why-s').focus(); return; }
      if (e.target.id === 'pp-why-go') { if (picked) open(picked, document.getElementById('pp-why-s').value, document.getElementById('pp-why-n').value); return; }
      if (e.target.closest('[data-close]')) { one.hidden = true; return; }
      var c = e.target.closest('[data-contact]');
      if (c) {
        if (!TvAsk.gate(c, 'Show their email and phone? Only for official contact; it\'s recorded.', { yes: 'Show them' })) return;
        get('/admin/api/people.php?id=' + c.getAttribute('data-contact') + '&why=' + WHY + '&contact=1').then(function (d) {
          document.getElementById('pp-contact').innerHTML = '<b>Email:</b> ' + esc(d.contact.email) + '<br><b>Phone:</b> ' + (d.contact.phone ? esc(d.contact.phone) : 'none given') + '<br><span class="text-xs text-[#8A7355]">Use these only for official contact, and only when Traversence\'s own messages can\'t reach them.</span>';
        }).catch(function (x) { TvAsk.say(x.message, { anchor: c }); });
        return;
      }
      var a = e.target.closest('[data-act]');
      if (a) {
        actKind = a.getAttribute('data-act');
        document.getElementById('pp-act').hidden = false;
        document.getElementById('pp-s').value = DEFAULT_STEPS;
        document.getElementById('pp-act-note').textContent = actKind === 'revoke'
          ? 'For serious violations only (threats, scams, someone\'s private information). Access is revoked now and they\'re emailed what happened, how to recover, and a link to ask for a review.'
          : 'They see it on every page and have 24 hours to confirm or ask for a review. Then posting and messaging stop with a final warning, and 24 hours later access is revoked.';
        document.getElementById('pp-act-go').textContent = actKind === 'revoke' ? 'Revoke now' : 'Send the warning';
        document.getElementById('pp-r').focus();
        return;
      }
      if (e.target.id === 'pp-act-x') { document.getElementById('pp-act').hidden = true; return; }
      if (e.target.id === 'pp-act-go') {
        var g = e.target;
        if (actKind === 'revoke' && !TvAsk.gate(g, 'Revoke their access now?', { yes: 'Revoke', danger: true })) return;
        post({ id: +one.getAttribute('data-id'), do: actKind, reason: document.getElementById('pp-r').value, steps: document.getElementById('pp-s').value })
          .then(function (j) { show(j.member); TvAsk.say(actKind === 'revoke' ? 'Access revoked; they\'ve been emailed.' : 'Warning sent.'); }).catch(function (x) { TvAsk.say(x.message, { anchor: g }); });
        return;
      }
      var r = e.target.closest('[data-restore]');
      if (r) { if (!TvAsk.gate(r, 'Restore their access?', { yes: 'Restore' })) return; post({ id: +r.getAttribute('data-restore'), do: 'restore' }).then(function (j) { show(j.member); }).catch(function (x) { TvAsk.say(x.message, { anchor: r }); }); return; }
      var d = e.target.closest('[data-decide]');
      if (d) {
        var lift = d.getAttribute('data-decide') === 'lift', id = d.getAttribute('data-action');
        if (!TvAsk.gate(d, lift ? 'Lift this notice? Everything is restored.' : 'Uphold it? The 24 hours start again (a revoked account stays revoked).', lift ? { yes: 'Lift' } : { yes: 'Uphold' })) return;
        var nEl = document.querySelector('[data-note="' + id + '"]');
        post({ action: +id, do: d.getAttribute('data-decide'), note: nEl ? nEl.value : '' }).then(function () { reload(); TvAsk.say(lift ? 'Lifted.' : 'Upheld.'); }).catch(function (x) { TvAsk.say(x.message, { anchor: d }); });
      }
    });
  }

  // ---- Staff & roles ----
  var teamBox = document.getElementById('team-box'), tcsrf = null, loaded = false;
  function loadTeam() {
    loaded = true;
    fetch('/user/api/context.php?team=1', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) throw new Error(d.error && d.error.message);
      tcsrf = d.csrf;
      var h = '<p class="text-sm text-[#5C4632]">Traversence staff and regional managers, and what each can do. Each role sees only its own scope, and no role can read people\'s private messages or contact cards.</p>';
      h += (d.team || []).map(function (t) {
        return '<div class="tm-r"><span><b>' + esc(t.name) + '</b>' + (t.me ? ' <span class="text-xs text-[#8A7355]">(you)</span>' : '') + (t.scope ? ' <span class="text-xs text-[#8A7355]">' + esc(t.scope) + '</span>' : '') + '</span>'
          + '<span class="flex gap-2 items-center"><span class="tm-role" title="' + esc((d.what || {})[t.role] || '') + '">' + esc((d.roles || {})[t.role] || t.role) + '</span>'
          + (t.grant_id && (d.can_grant.indexOf(t.role) >= 0 || t.me) ? '<button type="button" class="hb-b no" data-revoke="' + t.grant_id + '">' + (t.me ? 'Step down' : 'Remove') + '</button>' : '') + '</span></div>';
      }).join('') || '<p class="text-sm mt-2">No one yet.</p>';
      if (d.can_grant && d.can_grant.length) {
        if (!d.ready) h += '<p class="text-sm mt-3">To add people, run <code>app/migrations/2026-10-04_role_grants.sql</code> first.</p>';
        else h += '<div class="tm-add"><input class="hb-in" style="flex:1;min-width:12rem;width:auto" type="email" id="tm-email" placeholder="Their Traversence account email" autocomplete="off">'
          + '<select class="hb-in" style="width:auto" id="tm-role">' + d.can_grant.map(function (r) { return '<option value="' + r + '">' + esc(d.roles[r]) + '</option>'; }).join('') + '</select>'
          + '<button type="button" class="hb-b go" id="tm-add">Add</button></div><p class="text-sm text-[#8A7355]" id="tm-msg" style="margin-top:.4rem">Staff need a confirmed email; Verified needs nothing switched on.</p>';
      }
      h += '<details class="mt-3"><summary class="text-sm font-semibold text-amber-800 cursor-pointer">What each role can do</summary>'
        + Object.keys(d.what || {}).map(function (r) { return '<p class="text-sm mt-1"><b>' + esc(d.roles[r]) + ':</b> ' + esc(d.what[r]) + '</p>'; }).join('') + '</details>';
      teamBox.innerHTML = h;
    }).catch(function (e) { teamBox.innerHTML = '<p class="text-sm">' + esc(e.message || 'Not available.') + '</p>'; });
  }
  function teamPost(body) {
    return fetch('/user/api/context.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': tcsrf || '' }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.'); return d; });
  }
  if (teamBox) teamBox.addEventListener('click', function (e) {
    if (e.target.id === 'tm-add') {
      var m = document.getElementById('tm-msg');
      teamPost({ grant: { email: document.getElementById('tm-email').value, role: document.getElementById('tm-role').value } })
        .then(function (d) { loadTeam(); TvAsk.say(d.name + ' added.'); }).catch(function (x) { m.textContent = x.message; });
    }
    var rv = e.target.closest('[data-revoke]');
    if (rv && TvAsk.gate(rv, 'Remove this role?', { yes: 'Remove', danger: true })) teamPost({ revoke: +rv.getAttribute('data-revoke') }).then(loadTeam).catch(function (x) { TvAsk.say(x.message, { anchor: rv }); });
  });
  document.addEventListener('tv-hub-show', function (e) { if (e.detail === 'staff' && !loaded) loadTeam(); });
  if (location.hash === '#staff') loadTeam();
})();
</script>
<?php tv_admin_end();
