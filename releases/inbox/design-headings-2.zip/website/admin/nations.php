<?php
// /admin/nations.php — tribal nations and their visitor rules (decisions/0058 §26).
// One row per nation whose land touches our regions: its own name, the Census areas that are its land, its website and
// visitor page, its tourism office, and the rules a visitor most often misses (permits, fees, guides, photography,
// drones, alcohol, its time zone). The rules show on its places' pages only after a person ticks "Checked against the
// nation's own site"; any later change clears the tick until it's checked again.
// Who: staff with a content role; saving needs an Editor.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/Nations.php';
require_once __DIR__ . '/../../app/lib/Landmarks.php';
require_once __DIR__ . '/../../app/lib/Journeys.php';

$pdo = Database::connection();
$me = Auth::currentUser();
$uid = $me ? (int) $me['id'] : 0;
$ready = Nations::ready($pdo);
$can = ['content' => $uid && Journeys::staffCan($pdo, $uid, 'content'), 'publish' => $uid && Journeys::staffCan($pdo, $uid, 'publish')];
if (!$can['content'] || !$ready) {
    http_response_code($me ? ($ready ? 403 : 503) : 401);
    tv_page_start('Nations', ['section' => 'admin', 'active' => 'nations']);
    echo '<div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">' . ($ready ? 'Staff only' : 'Not set up yet') . '</h1><p class="text-sm text-[#5C4632] mt-2">'
        . (!$ready ? 'Run app/migrations/2026-10-17_nations.sql first.' : ($me ? 'This is for Traversence staff with an Editor or Content Creator role.' : 'Please <a class="underline" href="/login.php?next=/admin/nations.php">sign in</a>.')) . '</p></div>';
    tv_page_end();
    exit;
}
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$edit = (int) ($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        if (!$can['publish']) throw new InvalidArgumentException('Saving a nation\'s details needs an Editor.');
        Nations::save($pdo, $uid, $edit, $_POST);
        $_SESSION['nt_flash'] = [true, !empty($_POST['verified']) ? 'Saved and checked. Its rules now show on its places\' pages.' : 'Saved. Its rules show on pages once someone ticks "Checked against the nation\'s own site".'];
        header('Location: /admin/nations.php', true, 303);
        exit;
    } catch (InvalidArgumentException $e) {
        $_SESSION['nt_flash'] = [false, $e->getMessage()];
        header('Location: /admin/nations.php?id=' . $edit, true, 303);
        exit;
    }
}
$flash = $_SESSION['nt_flash'] ?? null; unset($_SESSION['nt_flash']);
$all = Nations::all($pdo);
$n = $edit ? Nations::get($pdo, $edit) : null;
$open = [];   // places opened on each nation's land, for the list
try {
    foreach ($pdo->query("SELECT nation, COUNT(*) AS c FROM landmarks WHERE nation <> '' AND " . Landmarks::visibleSql() . " GROUP BY nation")->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $nn = Nations::byShape($pdo, (string) $r['nation']);
        if ($nn) $open[(int) $nn['id']] = ($open[(int) $nn['id']] ?? 0) + (int) $r['c'];
    }
} catch (PDOException) {}

tv_page_start('Nations', ['section' => 'admin', 'active' => 'nations', 'no_crumbs' => true]);
?>
<style>
  .nt{max-width:56rem}.nt h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.7rem;margin:0 0 .3rem}
  .nt-lead{font-size:.9rem;color:#5C4632;margin:0 0 .8rem;line-height:1.5}
  .nt-msg{border-radius:.6rem;padding:.5rem .75rem;font-size:.88rem;margin-bottom:.7rem}.nt-msg.ok{background:#E8F2EC;color:#2F5D4A}.nt-msg.err{background:#FEE2E2;color:#991B1B}
  .nt-list{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;overflow:hidden}
  .nt-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:.6rem;align-items:center;padding:.55rem .8rem;border-top:1px solid #EADFC4;text-decoration:none;color:#3E2B1F}
  .nt-row:first-child{border-top:0}.nt-row:hover{background:#F7EFDC}.nt-row b{color:#92400E;text-decoration:underline;text-decoration-color:rgba(146,64,14,.3)}
  .nt-row small{display:block;color:#8A7355;font-size:.76rem;margin-top:.1rem}
  .nt-tag{font-size:.7rem;font-weight:700;border-radius:999px;padding:.12rem .5rem;white-space:nowrap}.nt-tag.ok{background:#E8F2EC;color:#2F5D4A}.nt-tag.no{background:#F7EFDC;color:#8A7355}
  .nt-f{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;padding:.8rem .9rem;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.55rem .75rem}
  .nt-f label{display:flex;flex-direction:column;gap:.2rem;font-size:.78rem;font-weight:600;color:#5C4632}.nt-f .w{grid-column:1/-1}
  .nt-f input[type=text],.nt-f textarea{border:1px solid #CBB98D;border-radius:.45rem;padding:.42rem .5rem;font:inherit;font-size:.88rem;font-weight:400;background:#fff;color:#3E2B1F;min-width:0}
  .nt-f .ck{flex-direction:row;align-items:center;gap:.45rem;font-weight:600;color:#2F5D4A}
  .nt-f h2{grid-column:1/-1;margin:.4rem 0 0;font-size:.72rem;letter-spacing:.08em;text-transform:uppercase;color:#8A7355}
  .nt-b{border:1px solid #CBB98D;border-radius:999px;padding:.35rem .9rem;font-size:.85rem;font-weight:600;background:#FFFBF2;color:#3E2B1F;cursor:pointer;text-decoration:none}
  .nt-b.go{background:#2F5D4A;border-color:#2F5D4A;color:#fff}
  @media (max-width:640px){.nt-f{grid-template-columns:minmax(0,1fr)}}
</style>
<div class="nt">
  <h1><?= $n ? tv_e($n['name']) : 'Nations' ?></h1>
  <?php if ($flash): ?><p class="nt-msg <?= $flash[0] ? 'ok' : 'err' ?>"><?= tv_e($flash[1]) ?></p><?php endif; ?>
  <?php if (!$n): ?>
    <p class="nt-lead">On a nation's land Traversence shows what is public (established boundaries, key resources and infrastructure, public listings and places), each with the nation's own name and rules; what is sensitive or specific to the nation is held until the nation says (decisions/0066). Fill in each nation from its own website: its tourism office, its visitor page, and the rules visitors most often miss. Rules show on pages only once someone has checked them against the nation's own site. Places are opened in <a class="underline" href="/admin/landmarks.php">Landmarks</a>.<?= Landmarks::NATION_TOOLS ? '' : ' Until the nation tools (decisions/0058 §27), sensitive places stay held and unused; there\'s no review queue.' ?></p>
    <div class="nt-list tv-bleed">
      <?php foreach ($all as $x): ?>
        <a class="nt-row" href="?id=<?= (int) $x['id'] ?>"><span><b><?= tv_e($x['name']) ?></b><small><?= tv_e(implode(' · ', array_filter([$x['office'], $x['website'] !== '' ? preg_replace('#^https?://(www\.)?#', '', rtrim((string) $x['website'], '/')) : 'No website yet', ($open[(int) $x['id']] ?? 0) ? ($open[(int) $x['id']] . ' place' . ($open[(int) $x['id']] === 1 ? '' : 's') . ' open') : '']))) ?></small></span>
          <span class="nt-tag <?= $x['verified_at'] ? 'ok' : 'no' ?>"><?= $x['verified_at'] ? 'Checked ' . tv_e(date('M Y', strtotime((string) $x['verified_at']))) : 'Not checked' ?></span></a>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p class="nt-lead"><a class="underline" href="/admin/nations.php">‹ All nations</a> · Take everything from the nation's own site. A county's, a state's or a travel site's page isn't the nation's word.</p>
    <form method="post" class="nt-f tv-bleed">
      <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>">
      <label class="w">The nation's name, as it uses it <input type="text" name="name" maxlength="120" value="<?= tv_e($n['name']) ?>" required></label>
      <label class="w">Its land in the Census map (area names, separated by |) <input type="text" name="match_names" maxlength="400" value="<?= tv_e($n['match_names']) ?>"></label>
      <label>Website <input type="text" name="website" maxlength="300" value="<?= tv_e($n['website']) ?>" placeholder="https://…"></label>
      <label>Visitor page <input type="text" name="visitor_url" maxlength="300" value="<?= tv_e($n['visitor_url']) ?>" placeholder="https://… (tourism, parks, or visitor rules)"></label>
      <label class="w">Tourism or parks office <input type="text" name="office" maxlength="160" value="<?= tv_e($n['office']) ?>"></label>
      <label>Office phone <input type="text" name="office_phone" maxlength="60" value="<?= tv_e($n['office_phone']) ?>"></label>
      <label>Office email <input type="text" name="office_email" maxlength="160" value="<?= tv_e($n['office_email']) ?>"></label>
      <h2>Visitor rules, shown on each of its places</h2>
      <?php foreach (['permits' => 'Permits and licenses (e.g. a state fishing license isn\'t valid)', 'fees' => 'Fees', 'guides' => 'Where a tribal guide is required', 'photography' => 'Photography and recording',
                      'drones' => 'Drones', 'alcohol' => 'Alcohol', 'other_rules' => 'Anything else a visitor should know'] as $c => $l): ?>
        <label class="w"><?= tv_e($l) ?> <textarea name="<?= $c ?>" maxlength="1000" rows="2"><?= tv_e((string) $n[$c]) ?></textarea></label>
      <?php endforeach; ?>
      <label class="w">Time (e.g. "Observes daylight saving time, unlike the rest of Arizona") <input type="text" name="time_zone" maxlength="160" value="<?= tv_e($n['time_zone']) ?>"></label>
      <label class="w ck"><input type="checkbox" name="verified" value="1"<?= $n['verified_at'] ? ' checked' : '' ?>> Checked against the nation's own site today</label>
      <p class="w" style="margin:0;font-size:.78rem;color:#8A7355">On its land we show only the places the nation lists for visitors. Untick to stop showing these rules until they're checked again.<?= $n['verified_at'] ? ' Last checked ' . tv_e(date('M j, Y', strtotime((string) $n['verified_at']))) . '.' : '' ?></p>
      <p class="w" style="margin:0"><?php if ($can['publish']): ?><button class="nt-b go">Save</button><?php else: ?><span style="font-size:.82rem;color:#8A7355">Saving needs an Editor.</span><?php endif; ?> <a class="nt-b" href="/admin/nations.php">Cancel</a></p>
    </form>
  <?php endif; ?>
</div>
<?php tv_page_end();
