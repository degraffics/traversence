<?php
// /admin/journeys.php — Journey Management (decisions/0058 §2). The admin side of journeys, not anyone's own:
//   Waiting for an editor  Traversence pieces a Content Creator sent in; an Editor publishes them
//   Traversence            every Traversence article and guide (write one: "Write as Traversence")
//   Contributors           published journeys by members and businesses: open, hide with a reason
//   Reported / Hidden      what readers reported (decided on Reports), and what's hidden now
// Who: staff with a content role (Owner, Manager, Editor, Content Creator). Staff never edit a contributor's words;
// they hide or restore. Contributors' drafts are private and never listed.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/journey-ui.php';
require_once __DIR__ . '/../../app/lib/Journeys.php';

$pdo = Database::connection();
$me = Auth::currentUser();
$uid = $me ? (int) $me['id'] : 0;
$can = ['content' => false, 'publish' => false, 'journeys' => false];
if ($uid && Journeys::ready($pdo)) foreach ($can as $k => $_) $can[$k] = Journeys::staffCan($pdo, $uid, $k);
if (!$can['content'] && !$can['journeys']) {
    http_response_code($me ? 403 : 401);
    tv_page_start('Journeys', ['section' => 'admin', 'active' => 'journeys']);
    echo '<div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Staff only</h1><p class="text-sm text-[#5C4632] mt-2">'
        . ($me ? 'Journey Management is for Traversence staff with an Editor or Content Creator role. Your own journeys are in <a class="underline" href="/user/journeys/">Your journeys</a>.'
               : 'Please <a class="underline" href="/login.php?next=/admin/journeys.php">sign in</a>.') . '</p></div>';
    tv_page_end();
    exit;
}
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$view = isset(Journeys::VIEWS[$_GET['view'] ?? '']) ? (string) $_GET['view'] : ($can['publish'] ? 'waiting' : 'traversence');
$q = trim((string) ($_GET['q'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $id = (int) ($_POST['id'] ?? 0);
        $j = Journeys::get($pdo, $id);
        if (!$j) throw new InvalidArgumentException('That journey is gone.');
        switch ((string) ($_POST['do'] ?? '')) {
            case 'publish':   Journeys::setEditorial($pdo, $uid, $id, true);  $done = 'Published.'; break;
            case 'unpublish': Journeys::setEditorial($pdo, $uid, $id, false); $done = 'Back to a draft.'; break;
            case 'hide':
                if (!$can['journeys']) throw new InvalidArgumentException('Hiding journeys needs an Editor.');
                $why = mb_substr(trim(strip_tags((string) ($_POST['why'] ?? ''))), 0, 200);
                if ($why === '') throw new InvalidArgumentException('Say why it\'s hidden. Its author sees the reason.');
                Journeys::setHidden($pdo, $id, true, $why); $done = 'Hidden. Its author still sees it, with your reason.'; break;
            case 'restore':
                if (!$can['journeys']) throw new InvalidArgumentException('Restoring journeys needs an Editor.');
                Journeys::setHidden($pdo, $id, false, ''); $done = 'Restored.'; break;
            case 'delete':
                if ($j['voice'] !== 'traversence' || !$can['publish']) throw new InvalidArgumentException('Only an Editor can delete, and only Traversence pieces. Hide a contributor\'s journey instead.');
                Journeys::remove($pdo, $uid, $id); $done = 'Deleted.'; break;
            default: throw new InvalidArgumentException('Unknown action.');
        }
        $_SESSION['jm_flash'] = [true, $done];
    } catch (InvalidArgumentException $e) {
        $_SESSION['jm_flash'] = [false, $e->getMessage()];
    }
    header('Location: /admin/journeys.php?view=' . rawurlencode($view) . ($q !== '' ? '&q=' . rawurlencode($q) : ''), true, 303);
    exit;
}
$flash = $_SESSION['jm_flash'] ?? null; unset($_SESSION['jm_flash']);
$rows = Journeys::manage($pdo, $view, $q);
$counts = Journeys::manageCounts($pdo);
$needsSql = !Journeys::managed($pdo);

tv_page_start('Journeys', ['section' => 'admin', 'active' => 'journeys', 'description' => 'Journey Management',
                           'crumbs' => [['Admin', '/admin/'], ['Journeys']]]);
echo tv_journey_css();
?>
<style>
  .jm{max-width:64rem}
  .jm h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.5rem,2.6vw,2rem);color:#3E2B1F;margin:0}
  .jm-lead{color:#5C4632;font-size:.92rem;margin:.3rem 0 .9rem}
  .jm-top{display:flex;flex-wrap:wrap;gap:.6rem;align-items:center;justify-content:space-between}
  .jm-tabs{display:flex;flex-wrap:wrap;gap:.35rem;margin:.6rem 0}
  .jm-tabs a{font-size:.84rem;border:1px solid #CBB98D;border-radius:999px;padding:.3rem .8rem;background:#FFFBF2;color:#3E2B1F;text-decoration:none}
  .jm-tabs a.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.jm-tabs small{opacity:.75;margin-left:.2rem}
  .jm-find{display:flex;gap:.4rem}.jm-find input{border:1px solid #CBB98D;border-radius:.6rem;padding:.4rem .65rem;background:#FFFBF2;font-size:.88rem;min-width:14rem}
  .jm-b{display:inline-flex;align-items:center;gap:.35rem;background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D;border-radius:.6rem;padding:.35rem .75rem;font-weight:600;font-size:.8rem;cursor:pointer;text-decoration:none;white-space:nowrap}
  .jm-b.go{background:#15803D;border-color:#15803D;color:#fff}.jm-b.dark{background:#3E2B1F;border-color:#3E2B1F;color:#FFFBF2}.jm-b.no{color:#991B1B;border-color:#FCA5A5}
  .jm-list{background:#F7EFDC;border:1px solid #CBB98D;border-radius:1rem;padding:.2rem 1rem}
  .jm-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:.4rem 1rem;align-items:center;border-top:1px solid #E3D3AC;padding:.75rem 0}
  .jm-row:first-child{border-top:0}
  .jm-t{font-weight:700;color:#3E2B1F;font-size:.95rem}.jm-t a{color:inherit}
  .jm-s{font-size:.78rem;color:#7A6348;margin-top:.15rem}
  .jm-st{font-size:.66rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;border-radius:.3rem;padding:.08rem .4rem;margin-left:.3rem;vertical-align:middle}
  .jm-st.draft{background:#FEF3C7;color:#78350F}.jm-st.published{background:#DCFCE7;color:#14532D}.jm-st.hidden{background:#FEE2E2;color:#7F1D1D}.jm-st.wait{background:#E0E7FF;color:#312E81}
  .jm-acts{display:flex;flex-wrap:wrap;gap:.35rem;justify-content:flex-end}
  .jm-acts form{display:inline-flex;gap:.3rem}
  .jm-why{border:1px solid #CBB98D;border-radius:.5rem;padding:.3rem .5rem;font-size:.8rem;background:#FFFBF2;width:12rem}
  .jm-msg{border-radius:.7rem;padding:.55rem .8rem;font-size:.9rem;margin:.6rem 0}.jm-msg.ok{background:#DCFCE7;color:#14532D}.jm-msg.err{background:#FEE2E2;color:#7F1D1D}
  .jm-empty{padding:1rem 0;color:#5C4632;font-size:.92rem}
  @media (max-width:720px){.jm-row{grid-template-columns:1fr}.jm-acts{justify-content:flex-start}}
</style>
<div class="jm">
  <div class="jm-top">
    <div><h1>Journeys</h1>
      <p class="jm-lead">Traversence articles and guides, and the journeys members and businesses publish. Staff write as Traversence here; they hide or restore a contributor&rsquo;s journey but never change its words.</p></div>
    <?php if ($can['content']): ?><a class="jm-b dark" href="/user/journeys/compose.php?editorial=1">✎ Write as Traversence</a><?php endif; ?>
  </div>
  <?php if ($needsSql): ?><p class="jm-msg err">Run <code>app/migrations/2026-10-08_journey_management.sql</code> to switch on editor hand-off and business journeys.</p><?php endif; ?>
  <?php if ($flash): ?><p class="jm-msg <?= $flash[0] ? 'ok' : 'err' ?>"><?= tv_e($flash[1]) ?></p><?php endif; ?>

  <div class="jm-top">
    <nav class="jm-tabs" aria-label="Views">
      <?php foreach (Journeys::VIEWS as $k => $label): ?>
        <a href="?view=<?= tv_e($k) ?>" class="<?= $k === $view ? 'on' : '' ?>"<?= $k === $view ? ' aria-current="page"' : '' ?>><?= tv_e($label) ?><small><?= (int) $counts[$k] ?></small></a>
      <?php endforeach; ?>
    </nav>
    <form class="jm-find" method="get"><input type="hidden" name="view" value="<?= tv_e($view) ?>">
      <input type="search" name="q" value="<?= tv_e($q) ?>" placeholder="Find by title" aria-label="Find by title"><button class="jm-b">Find</button></form>
  </div>

  <div class="jm-list">
    <?php if (!$rows): ?>
      <p class="jm-empty"><?= match ($view) {
          'waiting' => 'Nothing waiting. When a Content Creator sends a piece in, it shows here for an editor.',
          'traversence' => 'No Traversence pieces yet.' . ($can['content'] ? ' Start one with “Write as Traversence”.' : ''),
          'reported' => 'Nothing reported.',
          'hidden' => 'Nothing hidden.',
          default => 'No published journeys yet.',
      } ?><?= $q !== '' ? ' (Searching for “' . tv_e($q) . '”.)' : '' ?></p>
    <?php endif; foreach ($rows as $r):
        $waiting = $r['voice'] === 'traversence' && $r['status'] === 'draft' && !empty($r['submitted_at']);
        $isT = $r['voice'] === 'traversence'; ?>
    <div class="jm-row">
      <div>
        <div class="jm-t"><a href="/journeys/view.php?id=<?= (int) $r['id'] ?>"><?= tv_e($r['category']) ?> | <?= tv_e($r['title']) ?></a>
          <span class="jr-voice <?= $isT ? 't' : 'c' ?>"><?= $isT ? 'Traversence' : ($r['shown_kind'] === 'listing' ? 'Business' : 'Contributor') ?></span>
          <span class="jm-st <?= $waiting ? 'wait' : tv_e($r['status']) ?>"><?= $waiting ? 'Waiting' : tv_e($r['status']) ?></span></div>
        <div class="jm-s">
          <?= $isT ? 'Written by ' . tv_e($r['writer']) : 'By ' . tv_e($r['shown_as']) . ($r['shown_kind'] === 'listing' ? ' (posted by ' . tv_e($r['writer']) . ')' : '') ?>
          · <?= tv_e($r['place_label'] ?: 'No place') ?>
          · updated <?= tv_e(date('M j, Y', strtotime((string) $r['updated_at']))) ?>
          <?php if ($waiting): ?>· sent <?= tv_e(date('M j', strtotime((string) $r['submitted_at']))) ?><?php endif; ?>
          · <?= tv_icon('eye', 'tv-ei') ?> <?= (int) $r['views'] ?> · <?= tv_icon('heart', 'tv-ei') ?> <?= (int) $r['likes'] ?> · <?= tv_icon('comment', 'tv-ei') ?> <?= (int) $r['comments'] ?>
          <?php if ((int) $r['reports'] > 0): ?>· <a class="underline" style="color:#991B1B" href="/admin/reports.php"><?= (int) $r['reports'] ?> open report<?= (int) $r['reports'] === 1 ? '' : 's' ?></a><?php endif; ?>
          <?php if ($r['status'] === 'hidden' && $r['hidden_reason'] !== ''): ?>· hidden: <?= tv_e($r['hidden_reason']) ?><?php endif; ?>
        </div>
      </div>
      <div class="jm-acts">
        <a class="jm-b" href="/journeys/view.php?id=<?= (int) $r['id'] ?>"><?= $r['status'] === 'published' ? 'View' : 'Preview' ?></a>
        <?php if ($isT && $can['content']): ?><a class="jm-b" href="/user/journeys/compose.php?id=<?= (int) $r['id'] ?>">Edit</a><?php endif; ?>
        <?php if ($isT && $can['publish'] && $r['status'] === 'draft'): ?>
          <form method="post"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="jm-b go" name="do" value="publish">Publish</button></form>
        <?php elseif ($isT && $can['publish'] && $r['status'] === 'published'): ?>
          <form method="post"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="jm-b" name="do" value="unpublish">Unpublish</button></form>
        <?php endif; ?>
        <?php if ($can['journeys'] && $r['status'] === 'published'): ?>
          <form method="post"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
            <input class="jm-why" name="why" placeholder="Why (the author sees it)" required maxlength="200" aria-label="Why it's hidden"><button class="jm-b no" name="do" value="hide">Hide</button></form>
        <?php elseif ($can['journeys'] && $r['status'] === 'hidden'): ?>
          <form method="post"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="jm-b go" name="do" value="restore">Restore</button></form>
        <?php endif; ?>
        <?php if ($isT && $can['publish']): ?>
          <form method="post" data-confirm="Delete this Traversence piece and its photos? This can’t be undone." data-yes="Delete" data-danger><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="jm-b no" name="do" value="delete">Delete</button></form>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <p class="jm-s" style="margin-top:.8rem">Roles: <b>Content Creator</b> writes and sends pieces to an editor. <b>Editor</b> publishes, hides and restores. Give roles in <a class="underline" href="/admin/people.php#staff">People &amp; roles → Staff</a>.</p>
</div>
<?php tv_page_end();
