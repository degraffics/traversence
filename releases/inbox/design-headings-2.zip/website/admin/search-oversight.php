<?php
// /admin/search-oversight.php — Search oversight (decisions/0061, batch 2): oversight, not approval. What changed in
// how search understands people (situations, phrases, meanings, resource guides) and by whom; the resource-guide
// numbers due a re-check; and the incomplete-listings report: businesses a situation's need found but couldn't offer,
// because they lack a phone, hours or a place; what's missing, by area; and what learning (batch 3) changed, with its
// score.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/Situations.php';
require_once __DIR__ . '/../../app/lib/ResourceGuides.php';
require_once __DIR__ . '/../../app/lib/UniversalSearch.php';
require_once __DIR__ . '/../../app/lib/People.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$days = (int) ($_GET['days'] ?? 30); if (!in_array($days, [7, 30, 90], true)) $days = 30;
$since = date('Y-m-d H:i:s', time() - $days * 86400);

// re-check resource-guide numbers: one, or every one that's due (up to 15 at a time: each reads a web page)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ResourceGuides::ready($pdo)) {
    if (hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        @set_time_limit(150);
        $ids = ($_POST['do'] ?? '') === 'check_due' ? array_slice(array_column(ResourceGuides::needsCheck($pdo), 'id'), 0, 15) : [(int) ($_POST['eid'] ?? 0)];
        $ok = 0; $bad = 0;
        foreach ($ids as $i) { $r = ResourceGuides::check($pdo, (int) $i); $r['ok'] ? $ok++ : $bad++; }
        tv_crawler_flash(['type' => $bad ? 'error' : 'ok', 'text' => 'Checked ' . count($ids) . ': ' . $ok . ' found on their source' . ($bad ? ', ' . $bad . ' not (they\'re hidden until fixed)' : '') . '.']);
    }
    header('Location: /admin/search-oversight.php?days=' . $days . '#due'); exit;
}

$who = function (?int $uid) use ($pdo): string {
    static $c = [];
    if (!$uid) return 'Traversence';
    if (!isset($c[$uid])) { $u = People::user($pdo, $uid); $c[$uid] = $u ? People::name($u) : 'Admin #' . $uid; }
    return $c[$uid];
};
$q1 = function (string $sql, array $a = []) use ($pdo): array { try { $st = $pdo->prepare($sql); $st->execute($a); return $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) { return []; } };

// what changed, newest first
$changes = [];
foreach ($q1("SELECT id, label, status, source, updated_by, updated_at FROM situations WHERE source = 'admin' AND updated_at >= ? ORDER BY updated_at DESC LIMIT 50", [$since]) as $r)
    $changes[] = [$r['updated_at'], 'Situation', $r['label'] . ($r['status'] !== 'live' ? ' (' . $r['status'] . ')' : ''), 'edited in the situation editor', $who((int) $r['updated_by']), '/admin/search-misses.php'];
foreach ($q1("SELECT kind, class, word, updated_by, created_at FROM search_meanings WHERE created_at >= ? ORDER BY created_at DESC LIMIT 50", [$since]) as $r)
    $changes[] = [$r['created_at'], 'Meaning', '"' . $r['word'] . '" is ' . ($r['kind'] === 'event' ? 'an event' : 'a thing') . ': ' . $r['class'], 'taught in Meanings', $who((int) $r['updated_by']), '/admin/search-misses.php#mn-card'];
foreach ($q1("SELECT f.event, f.things, f.slug, f.updated_by, f.created_at, s.label FROM search_frames f LEFT JOIN situations s ON s.slug = f.slug WHERE f.created_at >= ? ORDER BY f.created_at DESC LIMIT 50", [$since]) as $r)
    $changes[] = [$r['created_at'], 'Rule', $r['event'] . ($r['things'] !== '' ? ' + ' . str_replace(',', ' or ', $r['things']) : '') . ' → ' . ($r['label'] ?? $r['slug']), 'taught in Meanings', $who((int) $r['updated_by']), '/admin/search-misses.php#mn-card'];
foreach ($q1("SELECT e.name, e.guide_id, e.updated_by, e.updated_at, g.title FROM resource_entries e JOIN resource_guides g ON g.id = e.guide_id WHERE e.updated_at >= ? ORDER BY e.updated_at DESC LIMIT 50", [$since]) as $r)
    $changes[] = [$r['updated_at'], 'Resource', $r['name'] . ' in ' . $r['title'], 'added or edited', $who((int) $r['updated_by']), '/admin/resource-guides.php?id=' . (int) $r['guide_id']];
// what learning changed (decisions/0061, batch 3): with its score and why
foreach ($q1("SELECT l.id, l.phrase, l.status, l.score, l.held, l.changed_at, c.name AS cat, s.label AS sit FROM search_learned l JOIN categories c ON c.id = l.category_id LEFT JOIN situations s ON s.id = l.situation_id
              WHERE l.changed_at >= ? ORDER BY l.changed_at DESC LIMIT 50", [$since]) as $r)
    $changes[] = [$r['changed_at'], 'Learned', '"' . $r['phrase'] . '" → ' . SearchText::catLabel((string) $r['cat']) . ($r['sit'] ? ' for ' . $r['sit'] : ''),
                  ['live' => 'published', 'may_help' => 'shown as May also help', 'retired' => 'retired', 'learning' => 'back to learning'][$r['status']] . ' at ' . number_format((float) $r['score'], 2), (int) $r['held'] ? 'Admin' : 'Learning', '/admin/search-learning.php#l' . (int) $r['id']];
usort($changes, fn ($a, $b) => strcmp((string) $b[0], (string) $a[0]));
// what's missing, by area: words that found nothing, 3+ times in the period (decisions/0061, the missing report)
$missing = [];
foreach ($q1("SELECT place_key, q, SUM(n) AS n FROM search_outcomes WHERE outcome = 'zero' AND day >= ? GROUP BY place_key, q HAVING SUM(n) >= 3 ORDER BY SUM(n) DESC LIMIT 200", [substr($since, 0, 10)]) as $r)
    if (count($missing[(string) $r['place_key']] ?? []) < 6) $missing[(string) $r['place_key']][] = $r;
$areaName = function (string $k) use ($pdo): string { if ($k === '') return 'No place set'; try { [$l] = Links::resolve($pdo, 'place', $k); return (string) $l; } catch (Throwable) { return $k; } };
// phrases added to situations in Admin (they carry no date): how many each situation has
$addedPhrases = $q1("SELECT s.label, COUNT(*) AS n FROM situation_triggers t JOIN situations s ON s.id = t.situation_id WHERE t.source = 'admin' GROUP BY s.label ORDER BY n DESC LIMIT 30");

$due = ResourceGuides::ready($pdo) ? ResourceGuides::needsCheck($pdo) : [];

// the incomplete-listings report, for one area at a time
$areaList = [];
foreach ($q1('SELECT slug, name FROM micro_clusters ORDER BY name') as $mc) $areaList[(string) $mc['slug']] = PlaceScope::publicName((string) $mc['name']);
$slug = (string) ($_GET['area'] ?? '');
if (!isset($areaList[$slug])) $slug = (string) (array_key_first($areaList) ?? '');
$inc = []; $incPlace = null;
if ($slug !== '' && isset($_GET['report'])) {
    @set_time_limit(90);
    $incPlace = UniversalSearch::scopePlace($pdo, ['level' => 'cluster', 'slug' => $slug]);
    $center = null;
    if ($incPlace && !empty($incPlace['zips'][0])) { $z = $q1('SELECT latitude, longitude FROM zip_coordinates WHERE zip = ? LIMIT 1', [(string) $incPlace['zips'][0]]); if ($z) $center = [(float) $z[0]['latitude'], (float) $z[0]['longitude']]; }
    $inc = $incPlace ? Situations::incomplete($pdo, $incPlace, $center) : [];
}

tv_page_start('Search oversight', ['section' => 'admin', 'active' => 'oversight', 'crumbs' => [['Admin', '/admin/'], ['Search tools', '/admin/search-misses.php'], ['Search oversight']], 'description' => 'What changed in search, and what needs a person.']);
?>
<style>
  .so{max-width:56rem}.so h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.5rem;color:#3E2B1F;margin:0}.so>p{font-size:.86rem;color:#5C4632;margin:.2rem 0 .8rem}
  .so-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.8rem .9rem;margin-bottom:.8rem}
  .so-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.05rem;margin:0 0 .15rem;color:#3E2B1F}.so-card>p{font-size:.8rem;color:#5C4632;margin:0 0 .5rem}
  .so-top{display:flex;flex-wrap:wrap;gap:.4rem;margin:.2rem 0 .9rem}.so-top a{font-size:.82rem;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .75rem;background:#FFFBF2;color:#3E2B1F;text-decoration:none}
  .so-top a.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .so-row{display:flex;gap:.6rem;align-items:flex-start;padding:.4rem 0;border-top:1px solid #EADFC4;font-size:.84rem}.so-row .m{flex:1;min-width:0}
  .so-row small{display:block;color:#7A6348;font-size:.74rem}.so-row a{color:#92400E}
  .so-k{flex:0 0 5.2rem;font-size:.66rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#7A6348;padding-top:.15rem}
  .so-miss{display:inline-block;font-size:.66rem;font-weight:700;border-radius:999px;padding:.05rem .45rem;margin:.1rem .2rem 0 0;background:#FDE2D3;color:#9A3412}
  .so-btn{display:inline-flex;align-items:center;gap:.35rem;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.4rem .85rem;font:inherit;font-size:.84rem;font-weight:600;cursor:pointer;text-decoration:none}
  .so-btn.main{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .so-ib{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;flex:0 0 30px;border-radius:999px;border:1px solid #B88647;background:#FCFAEE;color:#B45309;cursor:pointer;padding:0}
  .so-ib svg{width:15px;height:15px}.so-ib:hover{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8}
  .so-flash{padding:.5rem .7rem;border-radius:.4rem;margin:.4rem 0 .8rem;font-size:.86rem}.so-flash.ok{background:#E5EFE9;color:#1F5137}.so-flash.error{background:#FDE2D3;color:#9A3412}
  .so form.inl{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}.so select{border:1px solid #CBB98D;border-radius:.4rem;padding:.35rem .45rem;font-size:16px;background:#fff;color:#3E2B1F;max-width:100%}
  .so-hint{font-size:.76rem;color:#8A7355}
</style>
<div class="so">
<?php require_once __DIR__ . '/../../app/ui/search-tools.php'; echo tv_search_tools_tabs('oversight'); ?>
<h1>Search oversight</h1>
<p>Oversight, not approval: nobody has to approve everyday changes. This shows what changed in how search understands people, and what needs a person: resource-guide numbers due a re-check, and listings a situation couldn't offer because they're incomplete.</p>
<?php if ($f = tv_crawler_flash()): ?><p class="so-flash <?= $e($f['type'] ?? 'ok') ?>"><?= $e($f['text'] ?? '') ?></p><?php endif; ?>

<section class="so-card tv-bleed" id="due"><h2>Resource-guide numbers to check (<?= count($due) ?>)</h2>
  <p>Never checked, not found on their source at the last check, checked over <?= ResourceGuides::STALE_DAYS ?> days ago, or with no official source. Ones not found aren't shown in search until they're fixed.</p>
  <?php if (!ResourceGuides::ready($pdo)): ?><p class="so-hint">Resource guides aren't set up yet: run <code>app/migrations/2026-10-22_resource_guides.sql</code>.</p>
  <?php elseif (!$due): ?><p class="so-hint">Every number is current.</p>
  <?php else: ?>
    <form method="post" style="margin:.2rem 0 .4rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="check_due">
      <button type="submit" class="so-btn main"><?= tv_icon('eye', '') ?> Re-check all due<?= count($due) > 15 ? ' (15 at a time)' : '' ?></button></form>
    <?php foreach ($due as $x): ?>
      <div class="so-row"><span class="m"><a href="/admin/resource-guides.php?id=<?= (int) $x['guide_id'] ?>#e<?= (int) $x['id'] ?>"><?= $e($x['name']) ?></a> <?= $x['phone'] !== '' ? '· ' . $e($x['phone']) : '' ?>
        <small><?= $e($x['guide']) ?> · <?= $x['source_url'] === '' ? 'No official source' : ($x['last_checked'] === null ? 'Never checked' : ((int) $x['verified'] ? 'Checked ' . $e(date('M j', strtotime((string) $x['last_checked']))) . ': due again' : $e($x['check_note'] ?: 'Not found on the source'))) ?></small></span>
        <?php if ($x['source_url'] !== ''): ?><form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="check_one"><input type="hidden" name="eid" value="<?= (int) $x['id'] ?>">
          <button type="submit" class="so-ib" title="Check it now" aria-label="Check <?= $e($x['name']) ?> now"><?= tv_icon('eye', '') ?></button></form><?php endif; ?></div>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<section class="so-card tv-bleed" id="incomplete"><h2>Incomplete listings</h2>
  <p>Businesses a situation's need found in the area but couldn't offer, because they lack what the need requires (a phone for urgent help, hours, a place). Completing them, or the business claiming them, puts them in front of people at the moment they need it. Most needs missed first.</p>
  <form method="get" class="inl"><input type="hidden" name="days" value="<?= $days ?>"><input type="hidden" name="report" value="1">
    <select name="area" aria-label="Area"><?php foreach ($areaList as $sl => $nm): ?><option value="<?= $e($sl) ?>"<?= $sl === $slug ? ' selected' : '' ?>><?= $e($nm) ?></option><?php endforeach; ?></select>
    <button type="submit" class="so-btn">Show the report</button><span class="so-hint">Reads every live situation's needs: it takes a few seconds.</span></form>
  <?php if (isset($_GET['report'])): ?>
    <?php if (!$inc): ?><p class="so-hint" style="margin-top:.6rem">Nothing incomplete in <?= $e($areaList[$slug] ?? 'this area') ?>: every listing a need found can be offered.</p>
    <?php else: ?><p class="so-hint" style="margin-top:.6rem"><?= count($inc) ?> listings in <?= $e($areaList[$slug] ?? '') ?><?= count($inc) >= 60 ? ' (the first 60)' : '' ?>.</p>
      <?php foreach ($inc as $x): ?>
        <div class="so-row"><span class="m"><a href="/listing/view.php?id=<?= (int) $x['id'] ?>"><?= $e($x['label']) ?></a> <small><?= $e($x['sub']) ?></small>
          <?php foreach ($x['missing'] as $mm): ?><span class="so-miss">no <?= $e($mm) ?></span><?php endforeach; ?>
          <small>Missed for: <?= $e(implode(' · ', array_slice($x['needs'], 0, 4))) ?><?= count($x['needs']) > 4 ? ' · +' . (count($x['needs']) - 4) . ' more' : '' ?></small></span>
          <a class="so-ib" href="/admin/listing-edit.php?id=<?= (int) $x['id'] ?>" title="Complete this listing" aria-label="Complete <?= $e($x['label']) ?>"><?= tv_icon('pen', '') ?></a></div>
      <?php endforeach; ?>
    <?php endif; ?>
  <?php endif; ?>
</section>

<section class="so-card tv-bleed" id="missing"><h2>What's missing, by area</h2>
  <p>Words that found nothing, searched 3 or more times from an area in the last <?= $days ?> days: leads for the crawler and for new listings. <a href="/admin/search-learning.php#gaps">Learning</a> shows the situation needs the crawler is filling.</p>
  <?php if (!$missing): ?><p class="so-hint">Nothing missing that often in this period.</p><?php endif; ?>
  <?php foreach ($missing as $pk => $rows): ?>
    <div class="so-row"><span class="so-k"><?= $e($areaName((string) $pk)) ?></span><span class="m"><?= implode(' · ', array_map(fn ($r) => '<a href="/admin/search-misses.php?days=90' . ($pk !== '' ? '&amp;area=' . rawurlencode((string) $pk) : '&amp;area=~none') . '">' . $e($r['q']) . '</a> <small style="display:inline">' . (int) $r['n'] . '×</small>', $rows)) ?></span></div>
  <?php endforeach; ?>
</section>

<section class="so-card tv-bleed" id="changes"><h2>What changed in search</h2>
  <p>Situations edited, meanings and rules taught, resource-guide entries, and what learning published, showed or retired (with its score), newest first.</p>
  <div class="so-top"><?php foreach ([7, 30, 90] as $d): ?><a class="<?= $d === $days ? 'on' : '' ?>" href="?days=<?= $d ?>#changes">Last <?= $d ?> days</a><?php endforeach; ?></div>
  <?php if (!$changes): ?><p class="so-hint">Nothing changed in this period.</p><?php endif; ?>
  <?php foreach (array_slice($changes, 0, 80) as [$when, $k, $what, $how, $by, $url]): ?>
    <div class="so-row"><span class="so-k"><?= $e($k) ?></span><span class="m"><a href="<?= $e($url) ?>"><?= $e($what) ?></a><small><?= $e($how) ?> by <?= $e($by) ?> · <?= $e(date('M j, g:ia', strtotime((string) $when))) ?></small></span></div>
  <?php endforeach; ?>
  <?php if ($addedPhrases): ?><p class="so-hint" style="margin-top:.6rem">Phrases added to built-in situations in Admin: <?= $e(implode(' · ', array_map(fn ($r) => $r['label'] . ' (' . $r['n'] . ')', $addedPhrases))) ?>.</p><?php endif; ?>
</section>
</div>
<?php tv_page_end();
