<?php
// /admin/search-demand.php — Search demand (decisions/0066): where people look and what for, as a funnel of state →
// county → town, from the searches they acted on and where those led (counts only, never who). It is the crawler's
// target list: "Develop with the crawler" queues a town and a kind of business; the worker finds the businesses,
// checks each on its own website, and stages them in Listing Intake, held for a person.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/SearchDemand.php';
require_once __DIR__ . '/../../app/lib/crawler/CrawlTargets.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$ready = SearchDemand::ready($pdo);
$days = in_array((int) ($_GET['days'] ?? 90), [7, 30, 90, 365], true) ? (int) ($_GET['days'] ?? 90) : 90;
$outside = ($_GET['where'] ?? 'outside') !== 'all';
$self = '/admin/search-demand.php?days=' . $days . '&where=' . ($outside ? 'outside' : 'all');

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) { tv_crawler_flash(['type' => 'error', 'text' => 'Your session expired. Try again.']); header('Location: ' . $self); exit; }
    try {
        if (($_POST['do'] ?? '') === 'target') {
            $tw = (string) ($_POST['town'] ?? ''); $tw = str_starts_with($tw, '(') ? '' : $tw;
            $co = (string) ($_POST['county'] ?? ''); $co = str_starts_with($co, '(') ? '' : $co;
            CrawlTargets::queue($pdo, (string) ($_POST['state'] ?? ''), $co, $tw, (string) ($_POST['anchor'] ?? ''), (string) ($_POST['kind'] ?? ''), (int) $me['id']);
            tv_crawler_flash(['type' => 'ok', 'text' => 'Queued for the crawler: it looks on its next run and stages what it finds in Listing Intake, held for you.']);
        }
    } catch (InvalidArgumentException $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    header('Location: ' . $self); exit;
}

$funnel = $ready ? SearchDemand::funnel($pdo, $days, $outside) : [];
$targets = CrawlTargets::byPlace($pdo);
$KINDS = array_map(fn ($k) => $k[0], OpenPlaces::KINDS);
$DEST = ['search' => 'searched', 'osm' => 'OpenStreetMap', 'gmaps' => 'Google Maps', 'place' => 'place card', 'tool' => 'tool', 'listing' => 'listing', 'lacking' => 'results lacking'];
$lacking = $ready ? SearchDemand::lacking($pdo, $days) : [];

tv_page_start('Search demand', ['section' => 'admin', 'active' => 'demand', 'description' => 'Where people search and what for: the crawler\'s target list.']);
?>
<style>
  .sd{max-width:56rem}.sd h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.5rem;color:#3E2B1F;margin:0}.sd>p{font-size:.86rem;color:#5C4632;margin:.2rem 0 .8rem}
  .sd-tabs{display:flex;flex-wrap:wrap;gap:.35rem;margin:0 0 .7rem}.sd-tab{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .7rem;color:#3E2B1F;background:#FFFBF2;text-decoration:none}
  .sd-tab.on{background:#8FBCA8;border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .sd-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.6rem .8rem;margin-bottom:.5rem}
  .sd details>summary{cursor:pointer;list-style:none;display:flex;justify-content:space-between;gap:.5rem;align-items:center;font-weight:700;color:#3E2B1F}
  .sd details>summary::-webkit-details-marker{display:none}.sd summary small{font-weight:400;color:#7A6348}
  .sd-co{margin:.4rem 0 0 .4rem;border-left:2px solid #E7D7BC;padding-left:.6rem}.sd-co>details{margin:.35rem 0}
  .sd-tw{border-top:1px solid #EADFC4;padding:.45rem 0;font-size:.86rem;color:#3E2B1F}.sd-tw b{color:#92400E}
  .sd-chip{display:inline-block;font-size:.72rem;border:1px solid #E7D7BC;border-radius:999px;padding:.05rem .45rem;margin:.1rem .15rem 0 0;background:#FFFBF2;color:#5C4632}
  .sd-in{font-size:.68rem;font-weight:700;border-radius:999px;padding:.05rem .45rem;background:#E5EFE9;color:#1F5137;margin-left:.3rem}
  .sd-f{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center;margin-top:.35rem}.sd-f select{font:inherit;font-size:.8rem;border:1px solid #CBB98D;border-radius:.4rem;padding:.2rem .3rem;background:#fff}
  .sd-btn{border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.25rem .65rem;font:inherit;font-size:.8rem;font-weight:600;cursor:pointer}
  .sd-flash{padding:.5rem .7rem;border-radius:.4rem;margin:.4rem 0 .8rem;font-size:.86rem}.sd-flash.ok{background:#E5EFE9;color:#1F5137}.sd-flash.error{background:#FDE2D3;color:#9A3412}
  .sd-t{font-size:.74rem;color:#7A6348;margin-top:.2rem}
</style>
<div class="sd">
<h1>Search demand</h1>
<p>Where people search and what for, as state → county → town, from the searches they acted on and where those led. Counts only, never who. It is the crawler's target list: <b>Develop with the crawler</b> queues a town and a kind of business; the worker finds the businesses (OpenStreetMap as the lead), checks each on its own website, and stages them in Listing Intake, held for you.</p>
<?php if ($f = tv_crawler_flash()): ?><p class="sd-flash <?= $e($f['type'] ?? 'ok') ?>"><?= $e($f['text'] ?? '') ?></p><?php endif; ?>
<?php if (!$ready): ?>
  <div class="sd-card tv-bleed"><b>Not set up yet.</b> Run <code>app/migrations/2026-11-06_search_demand.sql</code> in phpMyAdmin.</div>
<?php else: ?>
  <div class="sd-tabs">
    <?php foreach ([7, 30, 90, 365] as $d): ?><a class="sd-tab<?= $d === $days ? ' on' : '' ?>" href="/admin/search-demand.php?days=<?= $d ?>&where=<?= $outside ? 'outside' : 'all' ?>"><?= $d === 365 ? 'Year' : $d . ' days' ?></a><?php endforeach; ?>
    <a class="sd-tab<?= $outside ? ' on' : '' ?>" href="/admin/search-demand.php?days=<?= $days ?>&where=outside">Outside our areas</a>
    <a class="sd-tab<?= !$outside ? ' on' : '' ?>" href="/admin/search-demand.php?days=<?= $days ?>&where=all">Everywhere</a>
  </div>
  <?php if ($lacking): ?>
    <div class="sd-card tv-bleed">
      <b>Results lacking</b>
      <p class="sd-t">"Near me" searches that found fewer than <?= class_exists('UniversalSearch') ? (int) UniversalSearch::NEAR_ENOUGH : 3 ?> places within 5 miles, ours and OpenStreetMap's together. Each town was already sent to the crawler; develop the kind of business here when it needs more.</p>
      <?php foreach ($lacking as $L): ?>
        <form method="post" class="sd-tw sd-f">
          <span><b><?= $e($L['anchor'] !== '' ? $L['anchor'] : '(anything)') ?></b> near <?= $e(trim($L['town'] . ', ' . $L['state'], ', ')) ?> · <?= number_format((int) $L['n']) ?></span>
          <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="target">
          <input type="hidden" name="state" value="<?= $e($L['state']) ?>"><input type="hidden" name="county" value="<?= $e($L['county']) ?>">
          <input type="hidden" name="town" value="<?= $e($L['town']) ?>"><input type="hidden" name="anchor" value="<?= $e($L['anchor']) ?>">
          <select name="kind" aria-label="Kind of business"><?php foreach ($KINDS as $k => $lab): ?><option value="<?= $e($k) ?>"<?= $k === OpenPlaces::kindFor((string) $L['anchor']) ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></select>
          <button class="sd-btn" type="submit">Develop with the crawler</button>
        </form>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <?php if (!$funnel): ?><div class="sd-card tv-bleed">No searches with a place yet in this period.</div><?php endif; ?>
  <?php foreach ($funnel as $S): ?>
    <details class="sd-card tv-bleed" <?= count($funnel) <= 3 ? 'open' : '' ?>>
      <summary><span><?= $e($S['state']) ?></span><small><?= number_format($S['searches']) ?> searches<?= !$outside && $S['outside'] ? ' · ' . number_format($S['outside']) . ' outside our areas' : '' ?></small></summary>
      <div class="sd-co">
      <?php foreach ($S['counties'] as $C): ?>
        <details>
          <summary><span><?= $e($C['county']) ?><?= str_starts_with($C['county'], '(') ? '' : ' County' ?></span><small><?= number_format($C['searches']) ?></small></summary>
          <?php foreach ($C['towns'] as $T): $tk = $S['state'] . '|' . (str_starts_with($C['county'], '(') ? '' : $C['county']) . '|' . (str_starts_with($T['town'], '(') ? '' : $T['town']); $top = (string) (array_key_first($T['anchors']) ?? ''); ?>
            <div class="sd-tw"><b><?= $e($T['town']) ?></b><?= $T['inside'] ? '<span class="sd-in">in our areas</span>' : '' ?> · <?= number_format($T['searches']) ?> search<?= $T['searches'] === 1 ? '' : 'es' ?>
              <div><?php foreach ($T['anchors'] as $a => $n): ?><span class="sd-chip"><?= $e($a) ?> · <?= (int) $n ?></span><?php endforeach; ?></div>
              <div class="sd-t">Went to: <?= $e(implode(', ', array_map(fn ($k, $v) => ($DEST[$k] ?? $k) . ' ' . $v, array_keys($T['dests']), $T['dests']))) ?></div>
              <?php foreach ($targets[$tk] ?? [] as $tg): ?><div class="sd-t">Crawler: <?= $e($KINDS[$tg['kind']] ?? $tg['kind']) ?> · <?= $e($tg['status']) ?><?= isset($tg['result']['staged']) ? ' · ' . (int) $tg['result']['staged'] . ' staged for review' : '' ?><?= isset($tg['result']['error']) ? ' · ' . $e($tg['result']['error']) : '' ?></div><?php endforeach; ?>
              <form class="sd-f" method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="target">
                <input type="hidden" name="state" value="<?= $e($S['state']) ?>"><input type="hidden" name="county" value="<?= $e($C['county']) ?>"><input type="hidden" name="town" value="<?= $e($T['town']) ?>"><input type="hidden" name="anchor" value="<?= $e($top) ?>">
                <select name="kind" aria-label="What to look for"><?php $guess = OpenPlaces::kindFor($top); foreach ($KINDS as $k => $l): ?><option value="<?= $e($k) ?>"<?= $k === $guess ? ' selected' : '' ?>><?= $e($l) ?></option><?php endforeach; ?></select>
                <button class="sd-btn" type="submit">Develop with the crawler</button></form>
            </div>
          <?php endforeach; ?>
        </details>
      <?php endforeach; ?>
      </div>
    </details>
  <?php endforeach; ?>
<?php endif; ?>
</div>
<?php tv_page_end();
