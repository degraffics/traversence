<?php
// /admin/resource-guides.php — resource guides (decisions/0061, batch 2): the phone lines and services that answer a
// situation but aren't businesses, one guide per area. Each entry is checked against its official source: it shows
// in search only once its number is found there (api/lib/ResourceGuides.php).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/ResourceGuides.php';
require_once __DIR__ . '/../../app/lib/Situations.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$ready = ResourceGuides::ready($pdo);
$id = (int) ($_GET['id'] ?? 0);

// ---- actions (post, then back to the page with a note) ----
if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) { tv_crawler_flash(['type' => 'error', 'text' => 'Your session expired. Try again.']); header('Location: ' . $_SERVER['REQUEST_URI']); exit; }
    $do = (string) ($_POST['do'] ?? ''); $back = '/admin/resource-guides.php' . ($id ? '?id=' . $id : '');
    try {
        if ($do === 'guide') {
            $gid = ResourceGuides::saveGuide($pdo, $id, (string) ($_POST['area'] ?? ''), (string) ($_POST['title'] ?? ''), (string) ($_POST['intro'] ?? ''), (string) ($_POST['status'] ?? 'draft'), (int) $me['id']);
            tv_crawler_flash(['type' => 'ok', 'text' => 'Guide saved.']); $back = '/admin/resource-guides.php?id=' . $gid;
        } elseif ($do === 'entry' && $id) {
            $eid = ResourceGuides::saveEntry($pdo, $id, (int) ($_POST['eid'] ?? 0), $_POST, (int) $me['id']);
            $c = !empty($_POST['check_now']) ? ResourceGuides::check($pdo, $eid) : null;
            tv_crawler_flash(['type' => $c && !$c['ok'] ? 'error' : 'ok', 'text' => 'Entry saved.' . ($c ? ' ' . $c['note'] . '.' : ' Check it against its source to show it in search.')]);
            $back .= '#e' . $eid;
        } elseif ($do === 'check') {
            $c = ResourceGuides::check($pdo, (int) ($_POST['eid'] ?? 0));
            tv_crawler_flash(['type' => $c['ok'] ? 'ok' : 'error', 'text' => $c['note'] . '.']); $back .= '#e' . (int) ($_POST['eid'] ?? 0);
        } elseif ($do === 'delete') {
            ResourceGuides::deleteEntry($pdo, (int) ($_POST['eid'] ?? 0)); tv_crawler_flash(['type' => 'ok', 'text' => 'Entry removed.']);
        }
    } catch (InvalidArgumentException $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    catch (Throwable $ex) { error_log('admin/resource-guides.php: ' . $ex->getMessage()); tv_crawler_flash(['type' => 'error', 'text' => 'That didn\'t work: ' . mb_substr($ex->getMessage(), 0, 160)]); }
    header('Location: ' . $back); exit;
}

$areas = $ready ? ResourceGuides::areas($pdo) : [];
$g = $ready && $id ? ResourceGuides::guide($pdo, $id) : null;
$sits = [];
try { if (Situations::ready($pdo)) $sits = $pdo->query("SELECT slug, label FROM situations WHERE status IN ('live', 'may_help') ORDER BY label")->fetchAll(PDO::FETCH_KEY_PAIR); } catch (Throwable) {}
$stale = date('Y-m-d H:i:s', time() - ResourceGuides::STALE_DAYS * 86400);
$state = function (array $x) use ($stale): array {   // [css, words]
    if ($x['status'] === 'hidden') return ['off', 'Hidden'];
    if ($x['source_url'] === '') return ['bad', 'No official source: not shown'];
    if ($x['last_checked'] === null) return ['bad', 'Not checked yet: not shown'];
    if (!(int) $x['verified']) return ['bad', $x['check_note'] !== '' ? $x['check_note'] : 'Not found on the source: not shown'];
    if ($x['last_checked'] < $stale) return ['warn', 'Shown · checked ' . date('M j', strtotime($x['last_checked'])) . ': due a re-check'];
    return ['ok', 'Shown · found on the source ' . date('M j', strtotime($x['last_checked']))];
};

tv_page_start('Resource guides', ['section' => 'admin', 'active' => 'misses', 'crumbs' => [['Admin', '/admin/'], ['Search tools', '/admin/search-misses.php'], ['Resource guides']], 'description' => 'Phone lines and services for situations.']);
?>
<style>
  .rg{max-width:52rem}.rg h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.5rem;color:#3E2B1F;margin:0}.rg>p{font-size:.86rem;color:#5C4632;margin:.2rem 0 .8rem}
  .rg-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.8rem .9rem;margin-bottom:.7rem}
  .rg-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.05rem;margin:0 0 .4rem;color:#3E2B1F}
  .rg label{display:block;font-size:.74rem;font-weight:600;color:#5C4632;margin:.5rem 0 .15rem}
  .rg input[type=text],.rg input[type=url],.rg textarea,.rg select{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.4rem .5rem;font:inherit;font-size:16px;background:#fff;color:#3E2B1F}
  .rg textarea{min-height:5rem}.rg-grid{display:grid;gap:.1rem .8rem;grid-template-columns:repeat(auto-fit,minmax(200px,1fr))}
  .rg-btn{display:inline-flex;align-items:center;gap:.35rem;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.4rem .85rem;font:inherit;font-size:.85rem;font-weight:600;cursor:pointer;text-decoration:none}
  .rg-btn.main{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.rg-acts{display:flex;flex-wrap:wrap;gap:.45rem;margin-top:.7rem;align-items:center}
  .rg-row{display:flex;gap:.6rem;align-items:center;padding:.45rem 0;border-top:1px solid #EADFC4;font-size:.86rem}.rg-row a.n{color:#92400E;text-decoration:underline;font-weight:600}
  .rg-row span.m{flex:1;min-width:0}.rg-row small{display:block;color:#7A6348;font-size:.74rem}
  .rg-e{position:relative;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:.6rem 3rem .6rem .7rem;margin:.5rem 0;font-size:.84rem}
  .rg-e b.n{font-size:.95rem;color:#92400E}.rg-e p{margin:.15rem 0}.rg-e .ph{font-weight:600}
  .rg-tag{display:inline-block;font-size:.66rem;font-weight:700;border-radius:999px;padding:.05rem .45rem;margin:.1rem .2rem 0 0;background:#EADFC4;color:#5C4632}
  .rg-st{display:inline-block;font-size:.72rem;font-weight:600;border-radius:.3rem;padding:.1rem .45rem;margin-top:.25rem}
  .rg-st.ok{background:#E5EFE9;color:#1F5137}.rg-st.warn{background:#FFF4CC;color:#7A5A00}.rg-st.bad{background:#FDE2D3;color:#9A3412}.rg-st.off{background:#EADFC4;color:#5C4632}
  .rg-ib{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:999px;border:1px solid #B88647;background:#FCFAEE;color:#B45309;cursor:pointer;padding:0}
  .rg-ib svg{width:15px;height:15px}.rg-ib:hover{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8}
  .rg-eacts{position:absolute;top:.5rem;right:.5rem;display:flex;flex-direction:column;gap:.3rem}
  .rg-sits{display:flex;flex-wrap:wrap;gap:.15rem .8rem;max-height:10rem;overflow:auto;border:1px solid #EADFC4;border-radius:.4rem;padding:.4rem .5rem;background:#fff}
  .rg-sits label{display:inline-flex;align-items:center;gap:.25rem;margin:0;font-weight:400;font-size:.8rem;color:#3E2B1F}
  .rg-hint{font-size:.74rem;color:#8A7355;margin:.2rem 0 0}.rg-flash{padding:.5rem .7rem;border-radius:.4rem;margin:.4rem 0 .8rem;font-size:.86rem}
  .rg-flash.ok{background:#E5EFE9;color:#1F5137}.rg-flash.error{background:#FDE2D3;color:#9A3412}
  .rg details summary{cursor:pointer;color:#92400E;font-weight:600;font-size:.86rem}
</style>
<div class="rg">
<?php require_once __DIR__ . '/../../app/ui/search-tools.php'; echo tv_search_tools_tabs('guides'); ?>
<h1>Resource guides</h1>
<p>The phone lines and services that answer a situation but aren't businesses: the power company's outage line, highway patrol's non-emergency number, 211, poison control. One guide per area. An entry shows in search, under <b>Phone lines and services</b>, only once its number is found on its official source page; <a class="underline text-amber-700" href="/admin/search-oversight.php">Search oversight</a> lists the ones due a re-check.</p>
<?php if ($f = tv_crawler_flash()): ?><p class="rg-flash <?= $e($f['type'] ?? 'ok') ?>"><?= $e($f['text'] ?? '') ?></p><?php endif; ?>
<?php if (!$ready): ?>
  <p class="rg-card tv-bleed">Run <code>app/migrations/2026-10-22_resource_guides.sql</code> in phpMyAdmin, then reload this page.</p>
<?php elseif (!$g): $list = ResourceGuides::guides($pdo); ?>
  <section class="rg-card tv-bleed"><h2>Guides</h2>
    <?php if (!$list): ?><p class="rg-hint">No guides yet. Start with one for everywhere we cover (211, poison control), then one per town area.</p><?php endif; ?>
    <?php foreach ($list as $x): ?>
      <div class="rg-row"><span class="m"><a class="n" href="?id=<?= (int) $x['id'] ?>"><?= $e($x['title']) ?></a>
        <small><?= $e($areas[$x['area_key']] ?? $x['area_key']) ?> · <?= $x['status'] === 'live' ? 'Live' : 'Draft' ?> · <?= (int) $x['entries'] ?> entries, <?= (int) $x['shown'] ?> shown in search</small></span>
        <?php if ($x['status'] === 'live'): ?><a class="rg-ib" href="/guide/resources.php?id=<?= (int) $x['id'] ?>" title="See the public page" aria-label="See the public page"><?= tv_icon('eye', '') ?></a><?php endif; ?>
        <a class="rg-ib" href="?id=<?= (int) $x['id'] ?>" title="Edit" aria-label="Edit <?= $e($x['title']) ?>"><?= tv_icon('pen', '') ?></a></div>
    <?php endforeach; ?>
  </section>
  <section class="rg-card tv-bleed"><h2>New guide</h2>
    <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="guide">
      <div class="rg-grid"><div><label for="g-area">For</label><select id="g-area" name="area"><?php foreach ($areas as $k => $n): ?><option value="<?= $e($k) ?>"><?= $e($n) ?></option><?php endforeach; ?></select></div>
        <div><label for="g-title">Title</label><input type="text" id="g-title" name="title" maxlength="160" placeholder="Who to call in the St. Johns area"></div></div>
      <label for="g-intro">A few words at the top (the Traversence voice: plain, warm, local)</label><textarea id="g-intro" name="intro" maxlength="4000" placeholder="Numbers for the things that go wrong out here, checked against each provider's own site."></textarea>
      <input type="hidden" name="status" value="draft">
      <div class="rg-acts"><button type="submit" class="rg-btn main"><?= tv_icon('plus', '') ?> Create guide</button><span class="rg-hint">It starts as a draft; make it live when it has entries.</span></div>
    </form>
  </section>
<?php else: ?>
  <p><a class="underline text-amber-700" href="/admin/resource-guides.php">&larr; All guides</a><?php if ($g['status'] === 'live'): ?> · <a class="underline text-amber-700" href="/guide/resources.php?id=<?= (int) $g['id'] ?>">See the public page</a><?php endif; ?></p>
  <section class="rg-card tv-bleed"><h2>Guide</h2>
    <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="guide">
      <div class="rg-grid"><div><label for="g-area">For</label><select id="g-area" name="area"><?php foreach ($areas as $k => $n): ?><option value="<?= $e($k) ?>"<?= $k === $g['area_key'] ? ' selected' : '' ?>><?= $e($n) ?></option><?php endforeach; ?></select></div>
        <div><label for="g-status">Status</label><select id="g-status" name="status"><option value="draft"<?= $g['status'] !== 'live' ? ' selected' : '' ?>>Draft: not shown</option><option value="live"<?= $g['status'] === 'live' ? ' selected' : '' ?>>Live: its checked entries show</option></select></div></div>
      <label for="g-title">Title</label><input type="text" id="g-title" name="title" maxlength="160" value="<?= $e($g['title']) ?>">
      <label for="g-intro">A few words at the top</label><textarea id="g-intro" name="intro" maxlength="4000"><?= $e($g['intro']) ?></textarea>
      <div class="rg-acts"><button type="submit" class="rg-btn main">Save guide</button></div>
    </form>
  </section>
  <section class="rg-card tv-bleed"><h2>Entries (<?= count($g['entries']) ?>)</h2>
    <?php foreach ($g['entries'] as $x): [$sc, $sw] = $state($x); $xs = array_values(array_filter(explode(',', (string) $x['situations']))); ?>
      <div class="rg-e" id="e<?= (int) $x['id'] ?>">
        <b class="n"><?= $e($x['name']) ?></b><?= $x['phone'] !== '' ? ' · <span class="ph">' . $e($x['phone']) . '</span>' : '' ?>
        <?php if ($x['purpose'] !== ''): ?><p><?= $e($x['purpose']) ?></p><?php endif; ?>
        <?php if ($x['hours'] !== ''): ?><p class="rg-hint"><?= $e($x['hours']) ?></p><?php endif; ?>
        <p><?php foreach ($xs as $s0): ?><span class="rg-tag"><?= $e($sits[$s0] ?? $s0) ?></span><?php endforeach; ?></p>
        <?php if ($x['source_url'] !== ''): ?><p class="rg-hint">Source: <a class="underline" href="<?= $e($x['source_url']) ?>" target="_blank" rel="noopener"><?= $e(parse_url((string) $x['source_url'], PHP_URL_HOST) ?: $x['source_url']) ?></a></p><?php endif; ?>
        <span class="rg-st <?= $sc ?>"><?= $e($sw) ?></span>
        <div class="rg-eacts">
          <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="check"><input type="hidden" name="eid" value="<?= (int) $x['id'] ?>">
            <button type="submit" class="rg-ib" title="Check the number on its official source" aria-label="Check <?= $e($x['name']) ?> on its source"><?= tv_icon('eye', '') ?></button></form>
          <button type="button" class="rg-ib" data-editent="<?= (int) $x['id'] ?>" title="Edit" aria-label="Edit <?= $e($x['name']) ?>"><?= tv_icon('pen', '') ?></button>
          <form method="post" data-yes="Remove" data-danger data-confirm="Remove <?= $e($x['name']) ?>?"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="delete"><input type="hidden" name="eid" value="<?= (int) $x['id'] ?>">
            <button type="submit" class="rg-ib" title="Remove" aria-label="Remove <?= $e($x['name']) ?>">&times;</button></form>
        </div>
        <script type="application/json" data-ent="<?= (int) $x['id'] ?>"><?= json_encode(['name' => $x['name'], 'phone' => $x['phone'], 'hours' => $x['hours'], 'purpose' => $x['purpose'], 'source_url' => $x['source_url'], 'status' => $x['status'], 'situations' => $xs], JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
      </div>
    <?php endforeach; ?>
    <?php if (!$g['entries']): ?><p class="rg-hint">No entries yet. Add the first below.</p><?php endif; ?>
  </section>
  <section class="rg-card tv-bleed" id="ent-form"><h2 id="ent-h">Add an entry</h2>
    <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="entry"><input type="hidden" name="eid" id="ent-id" value="0">
      <div class="rg-grid"><div><label for="ent-name">Name</label><input type="text" id="ent-name" name="name" maxlength="160" placeholder="Navopache Electric outage line"></div>
        <div><label for="ent-phone">Phone</label><input type="text" id="ent-phone" name="phone" maxlength="40" placeholder="(800) 543-6324"></div></div>
      <label for="ent-purpose">What it's for, in plain words</label><input type="text" id="ent-purpose" name="purpose" maxlength="400" placeholder="Report a power outage or a downed line">
      <div class="rg-grid"><div><label for="ent-hours">Hours</label><input type="text" id="ent-hours" name="hours" maxlength="160" placeholder="24 hours"></div>
        <div><label for="ent-status">Show</label><select id="ent-status" name="status"><option value="live">Yes, once checked</option><option value="hidden">No, keep it hidden</option></select></div></div>
      <label for="ent-src">Official source: the provider's own page that shows this number</label><input type="url" id="ent-src" name="source_url" maxlength="500" placeholder="https://www.navopache.org/outages">
      <label>The situations it answers</label>
      <div class="rg-sits" id="ent-sits"><?php foreach ($sits as $sl => $nm): ?><label><input type="checkbox" name="situations[]" value="<?= $e($sl) ?>"> <?= $e($nm) ?></label><?php endforeach; ?></div>
      <label class="rg-hint" style="display:flex;gap:.35rem;align-items:center;font-weight:400"><input type="checkbox" name="check_now" value="1" checked> Check the number on the source when saving</label>
      <div class="rg-acts"><button type="submit" class="rg-btn main" id="ent-save"><?= tv_icon('plus', '') ?> Add entry</button><button type="button" class="rg-btn" id="ent-cancel" hidden>Cancel</button></div>
    </form>
  </section>
<?php endif; ?>
</div>
<script>
(function () {
  var f = document.getElementById('ent-form'); if (!f) return;
  var $ = function (id) { return document.getElementById(id); };
  function reset() { $('ent-id').value = 0; $('ent-h').textContent = 'Add an entry'; $('ent-save').lastChild.textContent = ' Add entry'; $('ent-cancel').hidden = true;
    ['ent-name', 'ent-phone', 'ent-purpose', 'ent-hours', 'ent-src'].forEach(function (k) { $(k).value = ''; }); $('ent-status').value = 'live';
    [].forEach.call($('ent-sits').querySelectorAll('input'), function (x) { x.checked = false; }); }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-editent]');
    if (b) {
      var d = JSON.parse(document.querySelector('[data-ent="' + b.getAttribute('data-editent') + '"]').textContent);
      $('ent-id').value = b.getAttribute('data-editent'); $('ent-h').textContent = 'Edit: ' + d.name; $('ent-save').lastChild.textContent = ' Save entry'; $('ent-cancel').hidden = false;
      $('ent-name').value = d.name; $('ent-phone').value = d.phone; $('ent-purpose').value = d.purpose; $('ent-hours').value = d.hours; $('ent-src').value = d.source_url; $('ent-status').value = d.status;
      [].forEach.call($('ent-sits').querySelectorAll('input'), function (x) { x.checked = d.situations.indexOf(x.value) >= 0; });
      f.scrollIntoView({ behavior: 'smooth', block: 'start' }); return;
    }
    if (e.target.closest('#ent-cancel')) reset();
  });
})();
</script>
<?php tv_page_end();
