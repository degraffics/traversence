<?php
// admin/staff-profile.php?id=… — a staff member's staff profile (decisions/0105), seen only inside the admin. Beside it
// sits their public profile (their member account, /user/profile.php), which shows a "Traversence team" badge only if
// they turn it on here. Shows: photo and name (from the public profile), TRV ID, level and department, who they report
// to and who assists them, the workspaces they open, work email and phone, availability, a short bio, and their open
// Pulse cases. Each person edits their own; owners edit anyone's.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../app/lib/Workspaces.php';
require_once __DIR__ . '/../../app/lib/Pulse.php';

$pdo = Database::connection();
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$mine = StaffLogin::ready($pdo) ? StaffLogin::inSession($pdo) : null;
$sid = (int) ($_GET['id'] ?? ($mine['id'] ?? 0));
$s = $sid ? StaffLogin::get($pdo, $sid) : null;
$can = $s && $mine && ((int) $mine['id'] === $sid || $mine['role'] === 'owner');
$has = array_key_exists('availability', (array) $s);
$msg = ''; $err = '';

if ($s && $can && $has && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $av = in_array($_POST['availability'] ?? '', ['in', 'away', 'out'], true) ? $_POST['availability'] : 'in';
        $until = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($_POST['away_until'] ?? '')) && $av !== 'in' ? $_POST['away_until'] : null;
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET phone = ?, availability = ?, away_until = ?, bio = ?, team_badge = ? WHERE id = ?')->execute([
            mb_substr(trim((string) ($_POST['phone'] ?? '')), 0, 40), $av, $until, mb_substr(trim((string) ($_POST['bio'] ?? '')), 0, 300), empty($_POST['team_badge']) ? 0 : 1, $sid]);
        StaffLogin::log($pdo, $sid, 'profile', 'Staff profile updated', (int) $mine['id']);
        $s = StaffLogin::get($pdo, $sid); $msg = 'Saved.';
    } catch (Throwable $x) { $err = $x->getMessage(); }
}

tv_admin_start('backoffice', 'Staff profile', '', null, [['Back-Office', '/admin/backoffice'], ['Staff', '/admin/backoffice/people'], ['Staff profile', null]]);
if (!$s) { echo '<div class="hb-card tv-bleed" style="margin-top:.6rem"><p>No staff login here. Staff profiles come with a staff login (Back-Office → Staff logins).</p></div>'; tv_admin_end(); exit; }

[$lv, $dep] = Workspaces::levelOf($s);
$member = null; $photo = '';
if (!empty($s['member_user_id'])) {
    $st = $pdo->prepare('SELECT u.id, u.display_name, p.avatar_path FROM users u LEFT JOIN member_profiles p ON p.user_id = u.id WHERE u.id = ?');
    try { $st->execute([(int) $s['member_user_id']]); $member = $st->fetch(PDO::FETCH_ASSOC) ?: null; $photo = (string) ($member['avatar_path'] ?? ''); } catch (Throwable) {}
}
// who they report to: Staff and Creators to their department's Manager (Creators' work to its Editor), Managers and
// Editors to its Director, Directors to an Executive, Executives to the Founder
$up = ['staff' => ['manager'], 'creator' => ['manager', 'editor'], 'manager' => ['director'], 'editor' => ['director'], 'director' => ['executive'], 'executive' => ['founder'], 'assistant' => []][$lv] ?? [];
$all = array_filter(StaffLogin::all($pdo), fn ($x) => $x['status'] !== 'ended' && (int) $x['id'] !== $sid);
$reports = array_filter($all, fn ($x) => in_array(Workspaces::levelOf($x)[0], $up, true) && (in_array(Workspaces::levelOf($x)[0], ['executive', 'founder'], true) || Workspaces::levelOf($x)[1] === $dep));
if ($lv === 'assistant' && !empty($s['assists'])) $reports = array_filter($all, fn ($x) => (int) $x['id'] === (int) $s['assists']);
$assistants = array_filter($all, fn ($x) => (int) ($x['assists'] ?? 0) === $sid);
$names = fn (array $xs) => $xs ? implode(', ', array_map(fn ($x) => '<a class="underline text-[#92400E]" href="/admin/staff-profile.php?id=' . (int) $x['id'] . '">' . $e($x['name'] ?: $x['staff_id']) . '</a>', $xs)) : '—';
$opens = Workspaces::opens($s, $pdo);
try {   // their open cases (assigned to their staff user)
    $st = $pdo->prepare('SELECT item_key, case_no FROM ' . Database::t('pulse_marks') . ' WHERE assigned_to = ? AND done_at IS NULL');
    $st->execute([(int) $s['user_id']]);
    $theirs = $st->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (Throwable) { $theirs = []; }
$byKey = array_column(Pulse::items($pdo, $mine, (int) $me['id']), null, 'key');
$avail = ['in' => 'In', 'away' => 'Away', 'out' => 'Out'][$s['availability'] ?? 'in'] ?? 'In';
?>
<style>
  .sp-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.3fr);gap:.6rem;margin-top:.6rem}
  .sp-id{display:flex;gap:.8rem;align-items:center}
  .sp-av{width:84px;height:84px;border-radius:999px;background:#EADFC4 center/cover no-repeat;display:flex;align-items:center;justify-content:center;font:700 2rem var(--tv-font-head,Georgia,serif);color:#5C4632;flex:none;border:2px solid #CBB98D}
  .sp-id h2{font:700 1.4rem var(--tv-font-head,Georgia,serif);margin:0;color:#3E2B1F}
  .sp-f{display:grid;gap:.4rem}.sp-f label{font-weight:600;font-size:.93rem}
  .sp-case{display:flex;justify-content:space-between;gap:.5rem;padding:.45rem 0;border-top:1px solid #EADFC4}
  @media (max-width:900px){.sp-grid{grid-template-columns:1fr}}
</style>
<?php if ($msg): ?><p class="hb-pill ok" role="status"><?= $e($msg) ?></p><?php endif; ?>
<?php if ($err): ?><p class="hb-pill red" role="alert"><?= $e($err) ?></p><?php endif; ?>
<div class="sp-grid">
  <section class="hb-card tv-bleed">
    <div class="sp-id"><div class="sp-av"<?= $photo !== '' ? ' style="background-image:url(\'' . $e($photo) . '\')"' : '' ?>><?= $photo === '' ? $e(mb_strtoupper(mb_substr((string) ($s['name'] ?: 'S'), 0, 1))) : '' ?></div>
      <div><h2><?= $e($s['name'] ?: $s['staff_id']) ?></h2><span class="hb-pill"><?= $e($s['staff_id']) ?></span> <span class="hb-pill <?= $avail === 'In' ? 'ok' : 'red' ?>"><?= $e($avail) ?><?= !empty($s['away_until']) && $avail !== 'In' ? ' until ' . $e(date('M j', strtotime((string) $s['away_until']))) : '' ?></span>
        <div class="hb-intro" style="margin-top:.2rem"><?= $e(StaffLogin::levelName($s)) ?></div></div></div>
    <dl class="hb-dl" style="margin-top:.7rem">
      <dt>Reports to</dt><dd><?= $names($reports) ?></dd>
      <dt>Assisted by</dt><dd><?= $names($assistants) ?></dd>
      <dt>Work email</dt><dd><?= $e($s['email'] ?? '') ?: '—' ?></dd>
      <dt>Phone</dt><dd><?= $e($s['phone'] ?? '') ?: '—' ?></dd>
      <dt>About</dt><dd><?= $e($s['bio'] ?? '') ?: '—' ?></dd>
      <dt>Opens</dt><dd><?= $e($opens ? implode(', ', array_map(fn ($k) => Workspaces::ALL[$k][0] . '. ' . Workspaces::ALL[$k][1], $opens)) : 'none') ?></dd>
      <dt>Public profile</dt><dd><?= $member ? '<a class="underline text-[#92400E]" href="/user/profile.php?id=' . (int) $member['id'] . '" target="_blank" rel="noopener">' . $e($member['display_name'] ?: 'Their profile') . '</a>' . (!empty($s['team_badge']) ? ' · shows the Traversence team badge' : ' · no team badge') : 'Not linked to a member account' ?></dd>
    </dl>
  </section>
  <section class="hb-card tv-bleed">
    <h2 class="hb-h" style="margin-top:0">Open cases</h2>
    <?php if (!$theirs): ?><p>No open cases assigned.</p><?php endif; ?>
    <?php foreach ($theirs as $k => $no): $it = $byKey[$k] ?? null; ?>
      <div class="sp-case"><span><?= $no ? '#' . (int) $no . ' · ' : '' ?><?= $e($it['title'] ?? $k) ?></span><span><?= $it && $it['over'] ? '<span class="hb-pill red">Over SLA</span>' : '' ?></span></div>
    <?php endforeach; ?>
    <?php if ($can && $has): ?>
    <h2 class="hb-h">Edit</h2>
    <form method="post" class="sp-f">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
      <label for="sp-av">Availability</label>
      <div style="display:flex;gap:.4rem;flex-wrap:wrap"><select id="sp-av" name="availability" class="hb-in" style="width:auto"><?php foreach (['in' => 'In', 'away' => 'Away', 'out' => 'Out'] as $k => $v): ?><option value="<?= $k ?>"<?= ($s['availability'] ?? 'in') === $k ? ' selected' : '' ?>><?= $v ?></option><?php endforeach; ?></select>
        <label class="sr-only" for="sp-until">Until</label><input id="sp-until" type="date" name="away_until" class="hb-in" style="width:auto" value="<?= $e($s['away_until'] ?? '') ?>"></div>
      <label for="sp-ph">Work phone</label><input id="sp-ph" name="phone" class="hb-in" value="<?= $e($s['phone'] ?? '') ?>" autocomplete="tel">
      <label for="sp-bio">About (a line for the team)</label><textarea id="sp-bio" name="bio" class="hb-in" rows="2" maxlength="300"><?= $e($s['bio'] ?? '') ?></textarea>
      <label style="font-weight:400"><input type="checkbox" name="team_badge" value="1"<?= !empty($s['team_badge']) ? ' checked' : '' ?>> Show "Traversence team" on my public profile</label>
      <div><button class="hb-b go" type="submit">Save</button></div>
    </form>
    <?php elseif (!$has): ?><p class="hb-intro">Run the Pulse update (2026-12-15_pulse_cases.sql) to edit staff profiles.</p><?php endif; ?>
  </section>
</div>
<?php
tv_admin_end();
