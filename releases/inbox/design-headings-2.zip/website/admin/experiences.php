<?php
// /admin/experiences.php — Experiences review (decisions/0059). Nothing a member or the system writes shows until a
// person approves it here.
//   Waiting      members' and Content Creators' experiences: approve (Editor), edit first, or reject with a note
//   Suggestions  the system's, from outdoor places, listings that offer an experience, and journeys: edit, approve
//                or reject (a rejected suggestion is never suggested again). "Find new suggestions" looks again.
//   Published / Not approved / Hidden
// Who: staff with a content role (Owner, Manager, Editor, Content Creator). Approving needs an Editor.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/experience-ui.php';

$pdo = Database::connection();
$me = Auth::currentUser();
$uid = $me ? (int) $me['id'] : 0;
$ready = Experiences::ready($pdo);
$can = ['content' => $uid && $ready && Experiences::staffCan($pdo, $uid, 'content'), 'publish' => $uid && $ready && Experiences::staffCan($pdo, $uid, 'publish')];
if (!$can['content']) {
    http_response_code($me ? 403 : 401);
    tv_page_start('Experiences', ['section' => 'admin', 'active' => 'experiences']);
    echo '<div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Staff only</h1><p class="text-sm text-[#5C4632] mt-2">'
        . (!$ready ? 'Run app/migrations/2026-10-12_experiences.sql first.' : ($me ? 'Reviewing experiences is for Traversence staff with an Editor or Content Creator role. Your own are in <a class="underline" href="/user/experiences/">Your experiences</a>.'
               : 'Please <a class="underline" href="/login.php?next=/admin/experiences.php">sign in</a>.')) . '</p></div>';
    tv_page_end();
    exit;
}
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$views = ['submitted' => 'Waiting', 'suggested' => 'Suggestions', 'auto' => 'Auto-posted', 'published' => 'Published', 'rejected' => 'Not approved', 'hidden' => 'Hidden'];
$view = isset($views[$_GET['view'] ?? '']) ? (string) $_GET['view'] : 'submitted';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'suggest') {
            $n = Experiences::suggest($pdo, 60);
            $done = $n ? $n . ' new suggestion' . ($n === 1 ? '' : 's') . '. They\'re under Suggestions.' : 'Nothing new to suggest right now.';
        } else {
            Experiences::review($pdo, $uid, (int) ($_POST['id'] ?? 0), $do, (string) ($_POST['note'] ?? ''));
            $done = ['confirm' => 'Checked. It stays up, and counts toward its author\'s record.', 'approve' => 'Approved. It shows on Let\'s Explore now.', 'restore' => 'Restored.', 'reject' => 'Not approved. Its author sees your note.', 'hide' => 'Hidden.'][$do] ?? 'Done.';
        }
        $_SESSION['xm_flash'] = [true, $done];
    } catch (InvalidArgumentException $e) {
        $_SESSION['xm_flash'] = [false, $e->getMessage()];
    }
    header('Location: /admin/experiences.php?view=' . rawurlencode($view), true, 303);
    exit;
}
$flash = $_SESSION['xm_flash'] ?? null; unset($_SESSION['xm_flash']);
$counts = Experiences::counts($pdo);
$rows = $view === 'auto' ? Experiences::autoQueue($pdo) : Experiences::queue($pdo, $view);

tv_page_start('Experiences', ['section' => 'admin', 'active' => 'experiences', 'no_crumbs' => true]);
$btn = fn (string $do, string $label, int $id, bool $note = false, string $cls = '') => '<form method="post" class="xm-f"><input type="hidden" name="csrf" value="' . tv_e($csrf) . '"><input type="hidden" name="do" value="' . $do . '"><input type="hidden" name="id" value="' . $id . '">'
    . ($note ? '<input type="text" name="note" maxlength="300" placeholder="Why (its author sees this)">' : '') . '<button type="submit" class="xm-b ' . $cls . '">' . $label . '</button></form>';
?>
<style>
  .xm{max-width:60rem}.xm h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.7rem;margin:0 0 .3rem}
  .xm-lead{font-size:.9rem;color:#5C4632;margin:0 0 .8rem}
  .xm-tabs{display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.8rem}.xm-tabs a{border:1px solid #CBB98D;border-radius:999px;padding:.3rem .8rem;font-size:.85rem;font-weight:600;color:#3E2B1F;text-decoration:none;background:#FFFBF2}
  .xm-tabs a.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.xm-tabs small{opacity:.7}
  .xm-it{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;padding:.75rem .9rem;margin-bottom:.5rem}
  .xm-it h3{margin:0;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.08rem}.xm-it h3 a{color:#92400E}
  .xm-meta{font-size:.76rem;color:#8A7355;margin:.15rem 0 .35rem}.xm-sum{font-size:.88rem;color:#3E2B1F;margin:0 0 .5rem;line-height:1.45}
  .xm-acts{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center}.xm-f{display:flex;gap:.3rem;align-items:center;margin:0}
  .xm-f input{border:1px solid #CBB98D;border-radius:.45rem;padding:.25rem .45rem;font-size:.8rem;width:14rem;max-width:50vw}
  .xm-b{border:1px solid #CBB98D;border-radius:999px;padding:.25rem .7rem;font-size:.8rem;font-weight:600;background:#FFFBF2;color:#3E2B1F;cursor:pointer;text-decoration:none}
  .xm-b.go{background:#2F5D4A;border-color:#2F5D4A;color:#fff}.xm-b.no{color:#991B1B}
  .xm-msg{border-radius:.6rem;padding:.5rem .75rem;font-size:.88rem;margin-bottom:.7rem}.xm-msg.ok{background:#E8F2EC;color:#2F5D4A}.xm-msg.err{background:#FEE2E2;color:#991B1B}
  .xm-cred{font-size:.78rem;color:#5C4632;margin:0 0 .5rem}.xm-cred b{display:inline-block;min-width:2.1rem;text-align:center;border-radius:999px;padding:.05rem .4rem;margin-right:.3rem;color:#fff;background:#B91C1C}
  .xm-cred b.mid{background:#B45309}.xm-cred b.hi{background:#2F5D4A}.xm-cred em{font-style:normal;font-weight:700;color:#2F5D4A}.xm-cred small{display:block;color:#8A7355;margin-top:.15rem}
  .xm-src{font-size:.62rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;border-radius:999px;padding:.1rem .45rem;background:#F7EFDC;color:#5C4632;margin-left:.3rem}
</style>
<div class="xm">
  <h1>Experiences</h1>
  <p class="xm-lead">Things to do worth the trip. Members post them, the system suggests them from outdoor places, listings and journeys, and staff add them. Each gets a credibility score: <?= Experiences::AUTO_POST ?> or more posts itself (check those under Auto-posted); the rest wait here for a person.<?= $can['publish'] ? '' : ' Approving needs an Editor; you can edit, reject and hide.' ?></p>
  <?php if ($flash): ?><p class="xm-msg <?= $flash[0] ? 'ok' : 'err' ?>"><?= tv_e($flash[1]) ?></p><?php endif; ?>
  <nav class="xm-tabs"><?php foreach ($views as $k => $l): ?><a href="?view=<?= $k ?>" class="<?= $k === $view ? 'on' : '' ?>"><?= tv_e($l) ?> <small><?= (int) ($counts[$k] ?? 0) ?></small></a><?php endforeach; ?>
    <a href="/user/experiences/#post">+ Add one</a>
    <form method="post" class="xm-f" style="margin-left:auto"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="do" value="suggest"><button class="xm-b" type="submit" title="Look at outdoor places, listings and journeys for new experiences">Find new suggestions</button></form></nav>
  <?php if (!$rows): ?><p class="xm-lead">Nothing here.</p><?php endif; ?>
  <?php foreach ($rows as $e): $id = (int) $e['id']; $l = Experiences::links($pdo, $id); ?>
    <div class="xm-it tv-bleed" id="x<?= $id ?>">
      <h3><a href="/experiences/view.php?id=<?= $id ?>"><?= tv_e($e['title']) ?></a><span class="xm-src"><?= tv_e(['member' => 'Member', 'system' => 'Suggested', 'staff' => 'Staff'][$e['source']] ?? $e['source']) ?></span></h3>
      <p class="xm-meta"><?= tv_e(implode(' · ', array_filter([$e['place_label'], Experiences::TYPES[$e['type']] ?? '', ...tv_experience_facts($e), $e['source'] === 'member' ? 'by ' . Experiences::credit($pdo, $e) : '',
          count($l['listing']) ? count($l['listing']) . ' business' . (count($l['listing']) === 1 ? '' : 'es') : '', count($l['rec']) ? 'outdoor place' : '', count($l['journey']) ? count($l['journey']) . ' journey' . (count($l['journey']) === 1 ? '' : 's') : ''])) ) ?></p>
      <p class="xm-sum"><?= tv_e($e['summary']) ?></p>
      <?php if ($e['review_note'] !== ''): ?><p class="xm-meta">Note: <?= tv_e($e['review_note']) ?></p><?php endif; ?>
      <?php if (isset($e['credibility']) && $e['source'] !== 'staff'): $cs = (int) $e['credibility']; ?>
        <p class="xm-cred"><b class="<?= $cs >= Experiences::AUTO_POST ? 'hi' : ($cs >= 45 ? 'mid' : 'lo') ?>"><?= $cs ?></b> credibility<?= !empty($e['auto_published']) ? ' · <em>posted itself</em>' : '' ?><small><?= tv_e((string) $e['credibility_why']) ?></small></p>
      <?php endif; ?>
      <div class="xm-acts">
        <?php if (in_array($e['status'], ['submitted', 'suggested'], true)): ?>
          <?php if ($can['publish']): ?><?= $btn('approve', 'Approve', $id, false, 'go') ?><?php endif; ?>
          <a class="xm-b" href="/user/experiences/?edit=<?= $id ?>#post">Edit first</a>
          <?= $btn('reject', 'Don\'t approve', $id, $e['source'] === 'member', 'no') ?>
        <?php elseif ($e['status'] === 'published' && !empty($e['auto_published']) && empty($e['reviewed_by'])): ?>
          <?= $btn('confirm', 'Looks good', $id, false, 'go') ?><a class="xm-b" href="/user/experiences/?edit=<?= $id ?>#post">Edit</a><?= $btn('hide', 'Hide', $id, true, 'no') ?>
        <?php elseif ($e['status'] === 'published'): ?>
          <a class="xm-b" href="/user/experiences/?edit=<?= $id ?>#post">Edit</a><?= $btn('hide', 'Hide', $id, true, 'no') ?>
        <?php elseif ($can['publish']): ?><?= $btn('restore', $e['status'] === 'rejected' ? 'Approve after all' : 'Restore', $id, false, 'go') ?><?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php tv_page_end();
