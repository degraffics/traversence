<?php
// /admin/identities.php — Identities (decisions/0062, step 2): each listing's facts by the 5 W's, every fact with its
// sources. Built from what we already hold (the listing, its details, what the crawler found and which websites
// confirmed it, the sources we read, the NPI and IRS registries, the owner's claim). "✎ I know this" saves a value with the
// person as its source and writes it to the listing; deciding between values is in the helper (/admin/helper.php).
// Finding what's missing is the crawler's identity job (step 4).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/Identity.php';
require_once __DIR__ . '/../../app/lib/IdentityJobs.php';
require_once __DIR__ . '/../../app/lib/crawler/SourceIndex.php';   // how each source page was read (decisions/0157 §6)

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$ready = Identity::ready($pdo);
// step 6: the same card for places and resource lines; 'outdoor' is Recreation.gov's areas and facilities together
$TABS = ['listing' => 'Listings', 'landmark' => 'Landmarks', 'outdoor' => 'Outdoor places', 'resource' => 'Resource lines'] + Identity::COMING;
$tab = (string) ($_GET['kind'] ?? 'listing');
if (in_array($tab, ['recarea', 'facility'], true)) $tab = 'outdoor';
if (!isset($TABS[$tab])) $tab = 'listing';
$rawId = trim((string) ($_GET['id'] ?? ''));
$ref = $rawId !== '' ? Identity::ref($tab === 'outdoor' ? 'outdoor' : $tab, $rawId) : null;
$id = $tab === 'listing' ? (int) $rawId : 0;
$q = trim((string) ($_GET['q'] ?? ''));
$self = fn (array $extra = []) => '/admin/identities.php?' . http_build_query(($tab !== 'listing' ? ['kind' => $tab] : []) + $extra);

// ---- building: in batches, from the page (each batch is one request, so a big directory never times out) ----
if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = ($_POST['json'] ?? '') !== '';
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        if ($json) { header('Content-Type: application/json'); http_response_code(403); echo json_encode(['error' => 'Your session expired. Reload the page.']); exit; }
        tv_crawler_flash(['type' => 'error', 'text' => 'Your session expired. Try again.']); header('Location: ' . $_SERVER['REQUEST_URI']); exit;
    }
    @set_time_limit(120);
    $do = (string) ($_POST['do'] ?? '');
    if ($do === 'build') {
        $bk = (string) ($_POST['kind'] ?? 'listing');
        $r = isset(Identity::KINDS[$bk]) ? Identity::buildKind($pdo, $bk, max(0, (int) ($_POST['after'] ?? 0)), 150) : ['done' => 0, 'last' => 0, 'more' => false];
        header('Content-Type: application/json'); echo json_encode($r); exit;
    }
    if ($do === 'know' && $id) {
        try {
            Identity::know($pdo, $id, (string) ($_POST['fact'] ?? ''), (string) ($_POST['value'] ?? ''), (string) ($_POST['note'] ?? ''), !empty($_POST['private']), (int) $me['id']);
            tv_crawler_flash(['type' => 'ok', 'text' => 'Saved, with you as its source. The listing shows it now.']);
        } catch (InvalidArgumentException $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
        header('Location: /admin/identities.php?id=' . $id); exit;
    }
    // evidence wins (2026-10-04): what it wrote to an unclaimed listing can be taken back; that value is then "Not right"
    if ($do === 'unapply') {
        try { $u = Identity::unapply($pdo, (int) ($_POST['applied'] ?? 0), (int) $me['id']); tv_crawler_flash(['type' => 'ok', 'text' => 'Undone: the listing has its old value back, and that value is marked Not right.']); }
        catch (InvalidArgumentException $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
        header('Location: /admin/identities.php' . (!empty($_POST['back']) ? '?id=' . (int) $_POST['back'] : '') . '#applied'); exit;
    }
    if ($do === 'look' && $id && IdentityJobs::ready($pdo)) {
        IdentityJobs::look($pdo, $id);
        tv_crawler_flash(['type' => 'ok', 'text' => 'First in the crawler\'s queue: it looks on its next run (its own website, the registries, then web search).']);
        header('Location: /admin/identities.php?id=' . $id); exit;
    }
    if ($do === 'queue' && IdentityJobs::ready($pdo)) {
        $n = IdentityJobs::queue($pdo, 2000);
        tv_crawler_flash(['type' => 'ok', 'text' => number_format($n) . ' more listings queued for the crawler to look up.']);
        header('Location: /admin/identities.php'); exit;
    }
    if ($do === 'one' && $ref) {
        $n = Identity::build($pdo, $ref[0], $ref[1]);
        tv_crawler_flash(['type' => $n ? 'ok' : 'error', 'text' => $n ? "Rebuilt: $n facts." : 'Nothing to build: not found, or not shown.']);
        header('Location: ' . $self(['id' => $rawId])); exit;
    }
    header('Location: /admin/identities.php'); exit;
}

$stats = $ready && $tab === 'listing' ? Identity::stats($pdo) : [];
$listing = null; $card = null; $rec = null;
if ($ready && $ref) {
    $rec = Identity::record($pdo, $ref[0], $ref[1]);
    if ($rec) {
        $card = Identity::card($pdo, $ref[0], $ref[1], true);
        // not built yet: build it now, so looking a record up always shows its card
        if (!array_filter($card['facts'])) { Identity::build($pdo, $ref[0], $ref[1]); $card = Identity::card($pdo, $ref[0], $ref[1], true); }
        if ($ref[0] === 'listing') $listing = ['id' => $ref[1]];
    }
}
$found = [];
if ($ready && !$ref && $q !== '' && !isset(Identity::COMING[$tab])) {
    if ($tab === 'listing' && ctype_digit($q)) { header('Location: /admin/identities.php?id=' . (int) $q); exit; }
    $like = '%' . $q . '%';
    $sql = match ($tab) {
        'listing' => "SELECT e.id AS ref, e.name, CONCAT(COALESCE(c.name, 'Listing'), ' · ', e.primary_zip, ' · #', e.id) AS sub FROM entities e LEFT JOIN categories c ON c.id = e.category_id WHERE e.entity_type = 'merchant' AND e.name LIKE ? ORDER BY e.name LIMIT 30",
        'landmark' => "SELECT gnis_id AS ref, name, CONCAT(fclass, ' · ', county, ', ', state) AS sub FROM landmarks WHERE name LIKE ? AND " . (function () { require_once __DIR__ . '/../../app/lib/Landmarks.php'; return Landmarks::visibleSql(); })() . " ORDER BY name LIMIT 30",
        'outdoor' => "SELECT ridb_id AS ref, name, CONCAT(type, ' · ', org, ' · ', state) AS sub FROM rec_places WHERE name LIKE ? AND hidden = 0 ORDER BY name LIMIT 30",
        'resource' => "SELECT id AS ref, name, CONCAT('Resource line · ', phone) AS sub FROM resource_entries WHERE name LIKE ? ORDER BY name LIMIT 30",
    };
    try { $st = $pdo->prepare($sql); $st->execute([$like]); $found = $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $ex) { error_log('identities search: ' . $ex->getMessage()); }
}
// what needs a person (the helper takes these over in step 3)
$lists = ['conflict' => [], 'reach' => []];
if ($ready && !$ref && $q === '' && $tab === 'listing') {
    try {
        $lists['conflict'] = $pdo->query("SELECT e.id, e.name, GROUP_CONCAT(DISTINCT f.fact) AS facts FROM " . Database::t('identity_facts') . " f JOIN entities e ON e.id = f.record_id
                                          WHERE f.record_kind = 'listing' AND f.status = 'conflict' GROUP BY e.id, e.name ORDER BY e.id DESC LIMIT 25")->fetchAll(PDO::FETCH_ASSOC);
        $lists['reach'] = $pdo->query("SELECT e.id, e.name, e.primary_zip FROM entities e JOIN (SELECT record_id FROM " . Database::t('identity_facts') . " WHERE record_kind = 'listing' GROUP BY record_id
                                       HAVING SUM(CASE WHEN fact IN ('phone', 'website') THEN 1 ELSE 0 END) = 0) x ON x.record_id = e.id WHERE e.is_suppressed = 0 ORDER BY e.id DESC LIMIT 25")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $ex) { error_log('admin/identities.php: ' . $ex->getMessage()); }
}

$KIND = ['own_site' => 'Its own website', 'registry' => 'Official registry', 'government' => 'Government', 'chamber' => 'Chamber', 'community' => 'Community directory',
         'directory' => 'Directory', 'social' => 'Social page', 'tourism' => 'Tourism', 'open_data' => 'Open data', 'source' => 'Website', 'evidence' => 'Evidence link',
         'crawler' => 'Our records', 'owner' => 'Owner', 'admin' => 'Staff, checked', 'staff' => 'Staff, entered', 'member' => 'Member', 'import' => 'Import'];
// "✎ I know this" (step 3): a value staff know, saved with them as its source and written to the listing
$know = function (int $lid, string $fact = '', string $value = '') use ($e, $csrf): string {
    $h = '<details class="id-know"><summary>' . ($fact === '' ? '✎ I know something about it' : '✎ I know this') . '</summary><form method="post" action="/admin/identities.php?id=' . $lid . '">'
       . '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="do" value="know">';
    if ($fact !== '') $h .= '<input type="hidden" name="fact" value="' . $e($fact) . '">';
    else { $h .= '<label>What<select name="fact">'; foreach (array_keys(Identity::KNOWABLE) as $f) $h .= '<option value="' . $e($f) . '">' . $e(Identity::FACTS[$f][1]) . '</option>'; $h .= '</select></label>'; }
    return $h . '<label>The right value<input type="text" name="value" value="' . $e($value) . '" required autocomplete="off"></label>'
       . '<label>How do you know?<input type="text" name="note" maxlength="300" placeholder="Called them · their sign · their own website"></label>'
       . '<label class="ck"><input type="checkbox" name="private" value="1"> Only staff see this note</label>'
       . '<button class="id-btn main" type="submit">Save, with me as its source</button></form></details>';
};
$STATUS = ['confirmed' => ['ok', 'Confirmed'], 'single' => ['warn', 'One source'], 'conflict' => ['bad', 'Sources disagree'], 'rejected' => ['off', 'Not right'], 'replaced' => ['off', 'Taken off the listing']];
$KIND['rejected'] = 'Marked not right';
$KIND['replaced'] = 'Taken off the listing';
$job = $listing ? IdentityJobs::of($pdo, (int) $listing['id']) : null;
$kstats = [];
if ($ready && !$ref && $q === '' && in_array($tab, ['landmark', 'outdoor', 'resource'], true)) {
    foreach ($tab === 'outdoor' ? ['recarea', 'facility'] : [$tab] as $k) foreach (Identity::kindStats($pdo, $k) as $n => $v) $kstats[$n] = ($kstats[$n] ?? 0) + $v;
}
$jobs = IdentityJobs::stats($pdo);
$JOB = ['queued' => 'Waiting for the crawler', 'leased' => 'The crawler is looking now', 'done' => 'Looked', 'nothing' => 'Looked, found nothing yet'];

tv_page_start('Identities', ['section' => 'admin', 'active' => 'listings', 'description' => 'What we know about each listing, place and resource line, and where each fact came from.']);
?>
<style>
  .id{max-width:52rem}.id h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.5rem;color:#3E2B1F;margin:0}.id>p{font-size:.86rem;color:#5C4632;margin:.2rem 0 .8rem}
  .id-card{position:relative;background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.8rem .9rem;margin-bottom:.7rem}
  .id-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.05rem;margin:0 0 .4rem;color:#3E2B1F}
  .id-nums{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:.5rem}
  .id-num{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.45rem;padding:.45rem .6rem}.id-num b{display:block;font-size:1.2rem;color:#3E2B1F}.id-num span{font-size:.74rem;color:#7A6348}
  .id-btn{display:inline-flex;align-items:center;gap:.35rem;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.4rem .85rem;font:inherit;font-size:.85rem;font-weight:600;cursor:pointer;text-decoration:none}
  .id-btn.main{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.id-btn[disabled]{opacity:.55;cursor:default}
  .id-acts{display:flex;flex-wrap:wrap;gap:.45rem;margin-top:.7rem;align-items:center}.id-acts small{color:#7A6348;font-size:.78rem}
  .id input[type=search]{flex:1;min-width:0;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.4rem .5rem;font:inherit;font-size:16px;background:#fff;color:#3E2B1F}
  .id-row{display:flex;gap:.6rem;align-items:center;padding:.45rem 0;border-top:1px solid #EADFC4;font-size:.86rem}.id-row a.n{color:#92400E;text-decoration:underline;font-weight:600}
  .id-row span.m{flex:1;min-width:0}.id-row small{display:block;color:#7A6348;font-size:.74rem}
  .id-name{color:#92400E;text-decoration:underline;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.2rem;font-weight:700;padding-right:2.6rem;display:inline-block}
  .id-sum{font-size:.84rem;color:#5C4632;margin:.25rem 0 0}
  .id-w{margin-top:.7rem}.id-w h3{font-size:.78rem;text-transform:uppercase;letter-spacing:.05em;color:#7A6348;margin:0 0 .25rem}
  .id-f{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.45rem;padding:.45rem .6rem;margin:.3rem 0;font-size:.84rem}
  .id-f.other{opacity:.8;border-style:dashed}.id-f .l{font-size:.72rem;font-weight:700;color:#7A6348}.id-f .v{color:#3E2B1F;word-break:break-word}
  .id-st{display:inline-block;font-size:.68rem;font-weight:700;border-radius:999px;padding:.05rem .45rem;margin-left:.3rem;vertical-align:1px}
  .id-st.ok{background:#E5EFE9;color:#1F5137}.id-st.warn{background:#FFF4CC;color:#7A5A00}.id-st.bad{background:#FDE2D3;color:#9A3412}.id-st.off{background:#EADFC4;color:#5C4632}
  .id-src{list-style:none;margin:.25rem 0 0;padding:0;font-size:.76rem;color:#5C4632}.id-src li{padding:.1rem 0}.id-src a{color:#92400E;text-decoration:underline;word-break:break-all}
  .id-src em{font-style:normal;font-weight:600;color:#3E2B1F}.id-src .p{color:#9A3412;font-weight:700}
  .id-miss{background:#FDE2D3;color:#9A3412;border-radius:.4rem;padding:.4rem .6rem;font-size:.82rem;margin-top:.5rem}
  .id-good{background:#E5EFE9;color:#1F5137;border-radius:.4rem;padding:.4rem .6rem;font-size:.82rem;margin-top:.5rem}
  .id-flash{padding:.5rem .7rem;border-radius:.4rem;margin:.4rem 0 .8rem;font-size:.86rem}.id-flash.ok{background:#E5EFE9;color:#1F5137}.id-flash.error{background:#FDE2D3;color:#9A3412}
  .id-link{position:absolute;top:.6rem;right:.6rem;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:999px;border:1px solid #B88647;background:#FCFAEE;color:#B45309}
  .id-link svg{width:15px;height:15px}.id-link:hover{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8}
  .id-know{margin-top:.3rem;font-size:.8rem}.id-know summary{cursor:pointer;color:#92400E;font-weight:600;font-size:.76rem}
  .id-know form{display:grid;gap:.35rem;margin-top:.35rem}.id-know label{display:grid;gap:.1rem;font-size:.72rem;font-weight:600;color:#5C4632}.id-know label.ck{display:flex;gap:.3rem;align-items:center;font-weight:400}
  .id-know input[type=text],.id-know select{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.35rem .5rem;font:inherit;font-size:16px;background:#fff;color:#3E2B1F}
  .id-tabs{display:flex;flex-wrap:wrap;gap:.35rem;margin:0 0 .7rem}.id-tab{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .7rem;color:#3E2B1F;background:#FFFBF2;text-decoration:none}
  .id-tab.on{background:#8FBCA8;border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.35)}.id-tab.soon{color:#8A7355;border-style:dashed}
  .id-bar{height:.45rem;border-radius:999px;background:#EADFC4;overflow:hidden;flex:1;min-width:6rem}.id-bar i{display:block;height:100%;background:#8FBCA8;width:0}
</style>
<div class="id">
<h1>Identities</h1>
<p>What we know about each listing, place and resource line, by the 5 W's, and <b>where each fact came from</b>. A fact is <b>confirmed</b> when two independent websites agree, or an official registry or the owner says so. Facts from our own records only are kept with that source, as one source. A confidential address (a shelter) is never kept: phone only.</p>
<?php if ($f = tv_crawler_flash()): ?><p class="id-flash <?= $e($f['type'] ?? 'ok') ?>"><?= $e($f['text'] ?? '') ?></p><?php endif; ?>
<?php if (!$ready): ?>
  <div class="id-card tv-bleed"><h2>Not set up yet</h2><p class="id-sum">Run <code>app/migrations/2026-10-26_identity_facts.sql</code> in phpMyAdmin, then come back here and build.</p></div>
<?php else: ?>

<nav class="id-tabs" aria-label="Kinds of record"><?php foreach ($TABS as $k => $l): ?><a class="id-tab<?= $k === $tab ? ' on' : '' ?><?= isset(Identity::COMING[$k]) ? ' soon' : '' ?>" href="/admin/identities.php<?= $k !== 'listing' ? '?kind=' . $k : '' ?>"><?= $e($l) ?><?= isset(Identity::COMING[$k]) ? ' · coming' : '' ?></a><?php endforeach; ?></nav>
<?php if (isset(Identity::COMING[$tab])): ?>
  <div class="id-card tv-bleed"><h2><?= $e($TABS[$tab]) ?></h2><p class="id-sum"><?= $e($TABS[$tab]) ?> aren't built yet. When they are, each gets this same card: its facts by the 5 W's, every fact with its sources.</p></div>
<?php else: ?>
<form class="id-card tv-bleed" method="get" action="/admin/identities.php" style="display:flex;gap:.45rem;align-items:center">
  <?php if ($tab !== 'listing'): ?><input type="hidden" name="kind" value="<?= $e($tab) ?>"><?php endif; ?>
  <input type="search" name="q" value="<?= $e($ref ? '' : $q) ?>" placeholder="<?= $e(['listing' => 'A listing\'s name or number', 'landmark' => 'A landmark\'s name', 'outdoor' => 'An outdoor place\'s name', 'resource' => 'A resource line\'s name'][$tab]) ?>" aria-label="Find one">
  <button class="id-btn main" type="submit"><?= tv_icon('search', 'ta-svg') ?>Find</button>
</form>

<?php if ($rawId !== '' && !$rec): ?>
  <div class="id-card tv-bleed"><p class="id-sum">Nothing with that number here<?= $tab === 'landmark' ? ', or it isn\'t shown (on a nation\'s land only what the nation opened has a card)' : '' ?>.</p></div>
<?php elseif ($rec && $card): $any = false; $KEYW = array_keys(Identity::KINDS[$ref[0]][2]); ?>
  <div class="id-card tv-bleed">
    <a class="id-link" href="<?= $e($rec['url']) ?>" target="_blank" title="Open its page" aria-label="Open its page"><?= tv_icon('link', 'ta-svg') ?></a>
    <a class="id-name" href="<?= $e($rec['url']) ?>" target="_blank"><?= $e($rec['name']) ?></a>
    <p class="id-sum"><?= $e($rec['sub']) ?></p>
    <?php if ($card['confirmed']): ?><p class="id-good">Confirmed: <?php $parts = array_map(fn ($w) => ['who' => 'its name', 'where' => 'where it is', 'how' => 'how to reach it'][$w], $KEYW); $last = array_pop($parts); echo $e(($parts ? implode(', ', $parts) . ' and ' : '') . $last) . (count($KEYW) > 1 ? ' are each' : ' is'); ?> confirmed by an official registry or independent sources.</p>
    <?php else: ?><p class="id-miss"><?php
        $why = [];
        if ($card['missing']) $why[] = 'Missing ' . implode(', ', $card['missing']);
        if ($card['conflicts']) $why[] = $card['conflicts'] . ' fact' . ($card['conflicts'] > 1 ? 's' : '') . ' where sources disagree';
        if (!$why) $why[] = 'Its key facts have only one source so far';
        echo $e(implode('. ', $why)) . '.'; ?></p><?php endif; ?>
    <?php if ($job): ?><p class="id-sum"><b>Crawler:</b> <?= $e($JOB[$job['status']] ?? $job['status']) ?> · <?= $e(date('M j', strtotime((string) $job['updated_at']))) ?><?= $job['note'] !== '' && $job['status'] !== 'nothing' ? ' · ' . $e($job['note']) : '' ?><?= $job['status'] === 'nothing' && $job['next_at'] ? ' · looks again ' . $e(date('M j', strtotime((string) $job['next_at']))) : '' ?></p><?php endif; ?>
    <?php if ($card['private_where']): ?><p class="id-sum">Confidential address: kept as phone only, never stored or mapped.</p><?php endif; ?>
    <?php foreach (Identity::W as $W => $wl): if (!$card['facts'][$W]) continue; $any = true; ?>
      <div class="id-w"><h3><?= $e($wl) ?></h3>
      <?php foreach ($card['facts'][$W] as $x): [$sc, $sw] = $STATUS[$x['status']] ?? ['off', $x['status']]; $isUrl = in_array($x['fact'], ['website', 'social'], true) && preg_match('#^https?://#i', $x['value']); ?>
        <div class="id-f<?= $x['current'] ? '' : ' other' ?>">
          <span class="l"><?= $e($x['label']) ?></span><span class="id-st <?= $sc ?>"><?= $e($sw) ?></span><?php if (!$x['current']): ?><span class="id-st off" title="Another value has more evidence; this one is kept, not used">Not chosen</span><?php endif; ?>
          <div class="v"><?= $isUrl ? '<a class="underline text-amber-800" href="' . $e($x['value']) . '" target="_blank" rel="noopener nofollow">' . $e($x['value']) . '</a>' : $e($x['value']) ?></div>
          <ul class="id-src">
          <?php foreach ($x['sources'] as $s): ?>
            <li><em><?= $e($KIND[$s['kind']] ?? $s['kind']) ?></em><?php if ($s['private']): ?> <span class="p">private</span><?php endif; ?>
              <?php if ($s['url'] !== ''): ?> · <a href="<?= $e($s['url']) ?>" target="_blank" rel="noopener nofollow"><?= $e($s['label'] !== '' ? $s['label'] : $s['site']) ?></a><?php if ($s['site'] !== '' && $s['label'] !== '') echo ' <small>(' . $e($s['site']) . ')</small>'; ?>
              <?php elseif ($s['label'] !== ''): ?> · <?= $e($s['label']) ?><?php endif; ?>
              <?php if ($s['note'] !== ''): ?> · “<?= $e($s['note']) ?>”<?php endif; ?>
              · <small><?= $e(date('M j, Y', strtotime((string) $s['checked_at']))) ?></small>
              <?php if ($s['url'] !== '' && ($ab = SourceIndex::about($pdo, (string) $s['url']))): ?><br><small class="id-how" title="What we know and where from (decisions/0157 §6)">Read <?= $e(date('M j', strtotime($ab['read_at']))) ?> from <?= $e($ab['how']) ?><?= $ab['page'] !== '' ? ' on ' . $e($ab['page']) : '' ?><?= $ab['use'] !== '' ? ' · we may ' . $e(mb_strtolower($ab['use'])) : '' ?><?= $ab['licence'] !== '' && $ab['licence'] !== 'Not known yet' ? ' (' . $e($ab['licence']) . ')' : '' ?></small><?php endif; ?></li>
          <?php endforeach; ?>
          </ul>
          <?php if ($listing && isset(Identity::KNOWABLE[$x['fact']]) && !($x['fact'] === 'address' && $card['private_where'])) echo $know((int) $listing['id'], (string) $x['fact'], (string) $x['value']); ?>
        </div>
      <?php endforeach; ?></div>
    <?php endforeach; ?>
    <?php if (!$any): ?><p class="id-sum">Nothing held for this yet.</p><?php endif; ?>
    <?php if ($listing): ?><?= $know((int) $listing['id']) ?><?php else: ?><p class="id-sum">To change a fact, change it where it's kept<?= $rec['edit'] !== '' ? '' : ' (Recreation.gov: it refreshes each month)' ?>, then Rebuild.</p><?php endif; ?>
    <form class="id-acts" method="post" action="<?= $e($self(['id' => $rawId])) ?>">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="one">
      <button class="id-btn" type="submit">Rebuild from what we hold</button>
      <?php if ($listing && IdentityJobs::ready($pdo)): ?><button class="id-btn" type="submit" name="do" value="look">Look now</button><?php endif; ?>
      <?php if ($rec['edit'] !== ''): ?><a class="id-btn" href="<?= $e($rec['edit']) ?>"><?= tv_icon('pen', 'ta-svg') ?><?= $listing ? 'Edit the listing' : 'Change it' ?></a><?php endif; ?>
      <?php if ($listing && $card['conflicts']): ?><a class="id-btn" href="/admin/helper.php?q=conflicts">Decide in the helper</a><?php endif; ?>
    </form>
  </div>

<?php elseif ($q !== ''): ?>
  <div class="id-card tv-bleed"><h2><?= count($found) ?> named like “<?= $e($q) ?>”</h2>
  <?php foreach ($found as $r): ?>
    <div class="id-row"><span class="m"><a class="n" href="<?= $e($self(['id' => (string) $r['ref']])) ?>"><?= $e($r['name']) ?></a><small><?= $e($r['sub']) ?></small></span></div>
  <?php endforeach; ?>
  </div>

<?php elseif ($tab !== 'listing'): $s = $kstats; ?>
  <div class="id-card tv-bleed"><h2><?= $e($TABS[$tab]) ?></h2>
    <p class="id-sum"><?= $e(['landmark' => 'From the federal names registry (USGS GNIS), with Wikidata and Wikipedia for what it is. On a nation\'s land only the places the nation opened to visitors have a card; nothing waiting or closed is kept here.',
                              'outdoor' => 'From Recreation.gov (RIDB), an official federal registry: name, who runs it, what to do there, phone, page and map point.',
                              'resource' => 'What staff entered in the resource guides, and the provider\'s own page. The page confirms the phone only when the last check found the number on it.'][$tab]) ?></p>
    <div class="id-nums" style="margin-top:.5rem">
      <div class="id-num"><b><?= number_format($s['built'] ?? 0) ?></b><span>of <?= number_format($s['records'] ?? 0) ?> built</span></div>
      <div class="id-num"><b><?= number_format($s['confirmed'] ?? 0) ?></b><span>name confirmed</span></div>
      <div class="id-num"><b><?= number_format($s['single'] ?? 0) ?></b><span>with a key fact from one source</span></div>
    </div>
    <div class="id-acts">
      <button class="id-btn main" type="button" id="idBuild" data-kinds="<?= $e($tab === 'outdoor' ? 'recarea,facility' : $tab) ?>" data-total="<?= (int) ($s['records'] ?? 0) ?>">Build from what we hold</button>
      <div class="id-bar" aria-hidden="true"><i id="idBar"></i></div>
      <small id="idNote">In batches of 150. Safe to run again.</small>
    </div>
  </div>

<?php else: $s = $stats; $pct = fn ($n) => $s['listings'] ? round(100 * $n / $s['listings']) : 0; ?>
  <div class="id-card tv-bleed"><h2>Listings</h2>
    <div class="id-nums">
      <div class="id-num"><b><?= number_format($s['built']) ?></b><span>of <?= number_format($s['listings']) ?> built (<?= $pct($s['built']) ?>%)</span></div>
      <div class="id-num"><b><?= number_format($s['confirmedName']) ?></b><span>name confirmed by independent sources</span></div>
      <div class="id-num"><b><?= number_format($s['noReach']) ?></b><span>no phone or website</span></div>
      <div class="id-num"><b><?= number_format($s['conflicts']) ?></b><span>where sources disagree</span></div>
      <div class="id-num"><b><?= number_format($s['sources']) ?></b><span>sources recorded</span></div>
    </div>
    <div class="id-acts">
      <button class="id-btn main" type="button" id="idBuild" data-kinds="listing" data-total="<?= (int) $s['listings'] ?>">Build from what we hold</button>
      <div class="id-bar" aria-hidden="true"><i id="idBar"></i></div>
      <small id="idNote">Reads every listing in batches of 150. Safe to run again: it refreshes what it built and keeps what people added.</small>
    </div>
  </div>

  <?php if (IdentityJobs::ready($pdo)): ?>
  <div class="id-card tv-bleed"><h2>The crawler's identity job</h2>
    <p class="id-sum">Listings with no phone or website are looked up on each crawler run: their own website, the official registries, then a web search. On a listing nobody has claimed, evidence wins: what has more independent sources than our records goes on the listing by itself, logged below with Undo. A claimed listing's owner is offered it instead.</p>
    <div class="id-nums" style="margin-top:.5rem">
      <div class="id-num"><b><?= number_format($jobs['queued'] + $jobs['leased']) ?></b><span>waiting to be looked up</span></div>
      <div class="id-num"><b><?= number_format($jobs['week']) ?></b><span>found something this week</span></div>
      <div class="id-num"><b><?= number_format($jobs['done']) ?></b><span>found something, in all</span></div>
      <div class="id-num"><b><?= number_format($jobs['nothing']) ?></b><span>nothing yet (looks again in 30 days)</span></div>
    </div>
    <form class="id-acts" method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="queue"><button class="id-btn" type="submit">Queue every listing with no phone or website</button><small>It also tops itself up as it goes.</small></form>
  </div>
  <?php endif; ?>
  <?php $applied = Identity::applied($pdo, 30); ?>
  <div class="id-card tv-bleed" id="applied"><h2>Applied from the evidence</h2>
    <p class="id-sum">On a listing nobody has claimed, evidence wins: when a value has more independent sources than any other (its own website, official registries, other pages that match it), it goes on the listing by itself. A field a person set is never changed, and a claimed listing's owner is offered the evidence instead. Undo puts the old value back and marks the new one Not right.</p>
    <?php if (!$applied): ?><p class="id-sum">Nothing yet.</p><?php endif; ?>
    <?php foreach ($applied as $a): ?>
      <div class="id-row"><span class="m"><a class="n" href="/admin/identities.php?id=<?= (int) $a['record_id'] ?>"><?= $e($a['name']) ?></a><small><?= $e($a['label']) ?>: <?= $e(mb_strimwidth($a['value'], 0, 80, '…')) ?><?= $a['before'] !== '' ? ' (was ' . $e(mb_strimwidth($a['before'], 0, 60, '…')) . ')' : ' (was empty)' ?> · <?= (int) $a['sources_n'] ?> source<?= $a['sources_n'] === 1 ? '' : 's' ?> · <?= $e(substr($a['applied_at'], 0, 10)) ?></small></span>
        <?php if ($a['undone_at']): ?><span class="id-st off">Undone</span><?php else: ?>
        <form method="post" style="margin:0"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="unapply"><input type="hidden" name="applied" value="<?= (int) $a['id'] ?>"><button class="id-btn" type="submit">Undo</button></form>
        <?php endif; ?></div>
    <?php endforeach; ?>
  </div>
  <div class="id-card tv-bleed"><h2>Sources disagree</h2>
    <p class="id-sum">Only a tie in the evidence lands here; a value with more sources wins on its own (above).</p>
    <?php if (!$lists['conflict']): ?><p class="id-sum">None right now.</p><?php endif; ?>
    <?php foreach ($lists['conflict'] as $r): ?>
      <div class="id-row"><span class="m"><a class="n" href="/admin/identities.php?id=<?= (int) $r['id'] ?>"><?= $e($r['name']) ?></a><small>#<?= (int) $r['id'] ?> · <?= $e(implode(', ', array_map(fn ($f) => Identity::FACTS[$f][1] ?? $f, explode(',', (string) $r['facts'])))) ?></small></span></div>
    <?php endforeach; ?>
  </div>
  <div class="id-card tv-bleed"><h2>No phone or website</h2>
    <p class="id-sum">The newest <?= count($lists['reach']) ?> of <?= number_format($s['noReach']) ?>. The crawler's identity job is looking these up.</p>
    <?php foreach ($lists['reach'] as $r): ?>
      <div class="id-row"><span class="m"><a class="n" href="/admin/identities.php?id=<?= (int) $r['id'] ?>"><?= $e($r['name']) ?></a><small>#<?= (int) $r['id'] ?> · <?= $e($r['primary_zip']) ?></small></span></div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?php endif; // the COMING tabs ?>
  <script>
  (function () {
    var b = document.getElementById('idBuild'), bar = document.getElementById('idBar'), note = document.getElementById('idNote');
    if (!b) return;
    var total = +b.getAttribute('data-total') || 0, done = 0, kinds = b.getAttribute('data-kinds').split(','), ki = 0;
    b.addEventListener('click', function () {
      b.disabled = true; done = 0; ki = 0;
      (function step(after) {
        var f = new FormData(); f.append('csrf', <?= json_encode($csrf) ?>); f.append('do', 'build'); f.append('json', '1'); f.append('after', after); f.append('kind', kinds[ki]);
        fetch('/admin/identities.php', { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
          if (r.error) throw new Error(r.error);
          done += r.done; bar.style.width = Math.min(100, total ? 100 * done / total : 100) + '%';
          note.textContent = 'Built ' + done.toLocaleString() + ' of ' + total.toLocaleString() + '…';
          if (r.more) step(r.last); else if (++ki < kinds.length) step(0); else { note.textContent = 'Done: ' + done.toLocaleString() + '. Reloading…'; setTimeout(function () { location.reload(); }, 700); }
        }).catch(function (e) { b.disabled = false; note.textContent = 'Stopped: ' + e.message + '. Press again to carry on.'; });
      })(0);
    });
  })();
  </script>
<?php endif; ?>
</div>
<?php tv_page_end();
