<?php
// /admin/how-guides.php — How-to guides (decisions/0063 §8). What people asked how to do (from searches, counts only),
// what the crawler found on official how-to pages (each step with its source), and the review: put the steps in our
// own words, check them against the sources, publish. Nothing shows before a person publishes it.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/HowGuides.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$ready = HowGuides::ready($pdo);
$id = (int) ($_GET['id'] ?? 0);

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) { tv_crawler_flash(['type' => 'error', 'text' => 'Your session expired. Try again.']); header('Location: ' . $_SERVER['REQUEST_URI']); exit; }
    $do = (string) ($_POST['do'] ?? '');
    $back = '/admin/how-guides.php' . ($id ? '?id=' . $id : '');
    try {
        if ($do === 'save' || $do === 'publish') {
            $r = HowGuides::save($pdo, $id, $_POST, (int) $me['id'], $do === 'publish');
            tv_crawler_flash(['type' => 'ok', 'text' => $do === 'publish' ? 'Published: it shows in search for these words, and on its own page.' : 'Saved (' . $r['steps'] . ' steps).']);
        } elseif ($do === 'request') {
            $id = HowGuides::request($pdo, (string) ($_POST['title'] ?? ''));
            tv_crawler_flash(['type' => 'ok', 'text' => 'Asked for: the crawler looks on its next run.']);
            $back = '/admin/how-guides.php?id=' . $id;
        } elseif (in_array($do, ['unpublish', 'reject', 'again', 'restore'], true)) {
            tv_crawler_flash(['type' => 'ok', 'text' => HowGuides::decide($pdo, (int) ($_POST['gid'] ?? $id), $do, (int) $me['id'])]);
            if (!$id) $back = '/admin/how-guides.php?s=' . rawurlencode((string) ($_GET['s'] ?? ''));
        } elseif ($do === 'refresh') {
            $r = HowGuides::refresh($pdo);
            tv_crawler_flash(['type' => 'ok', 'text' => 'Read the last 30 days of searches: ' . $r['seen'] . ' things people asked how to do, ' . $r['new'] . ' new.']);
        }
    } catch (InvalidArgumentException $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    header('Location: ' . $back); exit;
}

$counts = $ready ? HowGuides::counts($pdo) : [];
$g = $ready && $id ? HowGuides::get($pdo, $id) : null;
$tab = (string) ($_GET['s'] ?? '');
if (!isset(HowGuides::STATUS[$tab])) $tab = ($counts['draft'] ?? 0) ? 'draft' : 'wanted';
$rows = $ready && !$g ? HowGuides::list($pdo, $tab) : [];

tv_page_start('How-to guides', ['section' => 'admin', 'active' => 'howguides', 'description' => 'Guides the crawler drafts from official how-to pages, for a person to check and publish.']);
?>
<style>
  .hg{max-width:52rem}.hg h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.5rem;color:#3E2B1F;margin:0}.hg>p{font-size:.86rem;color:#5C4632;margin:.2rem 0 .8rem}
  .hg-card{position:relative;background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.8rem .9rem;margin-bottom:.7rem}
  .hg-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.05rem;margin:0 0 .4rem;color:#3E2B1F}
  .hg-tabs{display:flex;flex-wrap:wrap;gap:.35rem;margin:0 0 .7rem}.hg-tab{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .7rem;color:#3E2B1F;background:#FFFBF2;text-decoration:none}
  .hg-tab.on{background:#8FBCA8;border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.35)}.hg-tab b{margin-left:.2rem}
  .hg-row{display:flex;flex-wrap:wrap;gap:.4rem .6rem;align-items:center;padding:.5rem 0;border-top:1px solid #EADFC4;font-size:.86rem}
  .hg-row a.n{color:#92400E;text-decoration:underline;font-weight:600}.hg-row .m{flex:1;min-width:12rem}.hg-row small{display:block;color:#7A6348;font-size:.74rem}
  .hg-btn{display:inline-flex;align-items:center;gap:.35rem;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.35rem .8rem;font:inherit;font-size:.83rem;font-weight:600;cursor:pointer;text-decoration:none}
  .hg-btn.main{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.hg-btn.go{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}
  .hg-f{display:grid;gap:.5rem}.hg-f label{display:grid;gap:.15rem;font-size:.76rem;font-weight:700;color:#5C4632}.hg-f label.ck{display:flex;gap:.4rem;align-items:flex-start;font-weight:400;font-size:.84rem;color:#3E2B1F}
  .hg-f input[type=text],.hg-f textarea{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.45rem .55rem;font:inherit;font-size:16px;background:#fff;color:#3E2B1F}
  .hg-f textarea{min-height:5rem}.hg-f textarea[name=steps]{min-height:16rem;line-height:1.5}
  .hg-acts{display:flex;flex-wrap:wrap;gap:.45rem;align-items:center}
  .hg-src{margin:0;padding-left:1.3rem;font-size:.82rem;color:#3E2B1F}.hg-src li{padding:.15rem 0}.hg-src a{color:#92400E;text-decoration:underline;word-break:break-all}.hg-src small{color:#7A6348}
  .hg-hint{font-size:.76rem;color:#7A6348;margin:.1rem 0 0}
  .hg-flash{padding:.5rem .7rem;border-radius:.4rem;margin:.4rem 0 .8rem;font-size:.86rem}.hg-flash.ok{background:#E5EFE9;color:#1F5137}.hg-flash.error{background:#FDE2D3;color:#9A3412}
  .hg-st{display:inline-block;font-size:.68rem;font-weight:700;border-radius:999px;padding:.05rem .45rem;background:#EADFC4;color:#5C4632;margin-left:.3rem}
  .hg-link{position:absolute;top:.6rem;right:.6rem;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:999px;border:1px solid #B88647;background:#FCFAEE;color:#B45309}
  .hg-link svg{width:15px;height:15px}
</style>
<div class="hg">
<h1>How-to guides</h1>
<p>When people search for how to do something ("how to compost leaves"), the crawler gathers the steps from <b>official how-to pages only</b> (university extension services, government agencies), with each step's source. You put them in our own words, check them against the sources, and publish. Nothing shows before that; until then search leads to who does it.</p>
<?php if ($f = tv_crawler_flash()): ?><p class="hg-flash <?= $e($f['type'] ?? 'ok') ?>"><?= $e($f['text'] ?? '') ?></p><?php endif; ?>
<?php if (!$ready): ?>
  <div class="hg-card tv-bleed"><h2>Not set up yet</h2><p class="hg-hint">Run <code>app/migrations/2026-11-02_how_guides.sql</code> in phpMyAdmin.</p></div>
<?php elseif ($id && !$g): ?>
  <div class="hg-card tv-bleed"><p class="hg-hint">That guide is gone. <a class="underline" href="/admin/how-guides.php">Back to the list</a></p></div>
<?php elseif ($g): $lines = implode("\n", array_map(fn ($s) => $s['text'] . ($s['src'] ? ' [' . (int) $s['src'] . ']' : ''), $g['steps'])); ?>
  <div class="hg-card tv-bleed">
    <?php if ($g['status'] === 'published'): ?><a class="hg-link" href="/guide/how.php?id=<?= (int) $g['id'] ?>" target="_blank" title="Open the guide" aria-label="Open the guide"><?= tv_icon('link', 'ta-svg') ?></a><?php endif; ?>
    <p class="hg-hint"><a class="underline" href="/admin/how-guides.php?s=<?= $e($g['status']) ?>">← <?= $e(HowGuides::STATUS[$g['status']] ?? $g['status']) ?></a></p>
    <h2 style="padding-right:2.6rem"><?= $e($g['title']) ?><span class="hg-st"><?= $e(HowGuides::STATUS[$g['status']] ?? $g['status']) ?></span></h2>
    <p class="hg-hint"><?= (int) $g['asked_n'] ?> search<?= (int) $g['asked_n'] === 1 ? '' : 'es' ?> in 30 days<?= (int) $g['requested'] ? ' · asked for by staff' : '' ?><?= $g['note'] !== '' ? ' · ' . $e($g['note']) : '' ?></p>
    <?php if ($g['sources']): ?>
      <h3 style="font-size:.8rem;margin:.6rem 0 .2rem;color:#5C4632">Sources (official pages the crawler read)</h3>
      <ol class="hg-src"><?php foreach ($g['sources'] as $i => $s): ?><li><a href="<?= $e($s['url']) ?>" target="_blank" rel="noopener"><?= $e($s['title'] !== '' ? $s['title'] : $s['host']) ?></a> <small><?= $e($s['host']) ?> · <?= (int) ($s['n'] ?? 0) ?> steps found</small></li><?php endforeach; ?></ol>
    <?php endif; ?>
    <?php if (in_array($g['status'], ['draft', 'published'], true)): ?>
    <form class="hg-f" method="post" action="/admin/how-guides.php?id=<?= (int) $g['id'] ?>" style="margin-top:.7rem">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
      <label>Title<input type="text" name="title" maxlength="160" value="<?= $e($g['title']) ?>" required></label>
      <label>A line to start (optional)<textarea name="intro" maxlength="400" placeholder="What it's for, and anything to know first."><?= $e($g['intro']) ?></textarea></label>
      <label>Steps, one per line, each ending with its source's number<textarea name="steps"><?= $e($lines) ?></textarea></label>
      <p class="hg-hint">The crawler's lines are the source's own words: rewrite each one in ours, keep only what the source supports, and keep its [number]. At least 3 steps.</p>
      <label class="ck"><input type="checkbox" name="own_words" value="1"<?= $g['status'] === 'published' ? ' checked' : '' ?>> <span>The steps are in our own words, and I checked each one against its source.</span></label>
      <div class="hg-acts">
        <button class="hg-btn go" type="submit" name="do" value="publish"><?= $g['status'] === 'published' ? 'Save, published' : 'Publish' ?></button>
        <button class="hg-btn" type="submit" name="do" value="save"><?= $g['status'] === 'published' ? 'Save' : 'Save the draft' ?></button>
        <?php if ($g['status'] === 'published'): ?><button class="hg-btn" type="submit" name="do" value="unpublish">Take it down</button><?php endif; ?>
        <button class="hg-btn" type="submit" name="do" value="again">Have the crawler look again</button>
        <button class="hg-btn" type="submit" name="do" value="reject">Not a guide</button>
      </div>
    </form>
    <?php else: ?>
    <form class="hg-acts" method="post" action="/admin/how-guides.php?id=<?= (int) $g['id'] ?>" style="margin-top:.7rem">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>">
      <?php if ($g['status'] === 'rejected'): ?><button class="hg-btn" type="submit" name="do" value="restore">It is a guide: back to wanted</button>
      <?php else: ?><button class="hg-btn main" type="submit" name="do" value="again">Look now</button><button class="hg-btn" type="submit" name="do" value="reject">Not a guide</button><?php endif; ?>
    </form>
    <?php endif; ?>
  </div>
<?php else: ?>
  <nav class="hg-tabs" aria-label="Guides by state"><?php foreach (HowGuides::STATUS as $k => $l): ?><a class="hg-tab<?= $k === $tab ? ' on' : '' ?>" href="/admin/how-guides.php?s=<?= $k ?>"><?= $e($l) ?><b><?= (int) ($counts[$k] ?? 0) ?></b></a><?php endforeach; ?></nav>
  <div class="hg-card tv-bleed"><h2><?= $e(HowGuides::STATUS[$tab]) ?></h2>
    <p class="hg-hint"><?= $e(['wanted' => 'Asked ' . HowGuides::MIN_SEARCHES . '+ times in 30 days, or asked for by staff: the crawler takes two a run.', 'looking' => 'The crawler has these now.',
        'draft' => 'Found on official pages: check, put in our words, publish.', 'published' => 'Shown in search for these words, and on their own pages.',
        'nothing' => 'No official page had steps: the crawler looks again after 30 days.', 'rejected' => 'Set aside as not a how-to (directions, a name, a question for a person).'][$tab]) ?></p>
    <?php if (!$rows): ?><p class="hg-hint" style="margin-top:.4rem">None right now.</p><?php endif; ?>
    <?php foreach ($rows as $r): ?>
      <div class="hg-row"><span class="m"><a class="n" href="/admin/how-guides.php?id=<?= (int) $r['id'] ?>"><?= $e($r['title']) ?></a>
        <small><?= (int) $r['asked_n'] ?> search<?= (int) $r['asked_n'] === 1 ? '' : 'es' ?> on <?= (int) $r['asked_days'] ?> day<?= (int) $r['asked_days'] === 1 ? '' : 's' ?><?= (int) $r['requested'] ? ' · asked for by staff' : '' ?><?= $r['note'] !== '' ? ' · ' . $e($r['note']) : '' ?></small></span>
        <?php if (in_array($tab, ['wanted', 'nothing'], true)): ?>
          <form method="post" action="/admin/how-guides.php?s=<?= $e($tab) ?>" class="hg-acts"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="gid" value="<?= (int) $r['id'] ?>">
            <button class="hg-btn" type="submit" name="do" value="again">Look now</button><button class="hg-btn" type="submit" name="do" value="reject">Not a guide</button></form>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <form class="hg-card tv-bleed hg-f" method="post" action="/admin/how-guides.php">
    <h2>Ask for a guide</h2>
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="request">
    <label>What to do<input type="text" name="title" maxlength="160" placeholder="How to winterize a camper" required></label>
    <div class="hg-acts"><button class="hg-btn main" type="submit">Ask the crawler</button>
      <button class="hg-btn" type="submit" name="do" value="refresh" formnovalidate>Read recent searches now</button></div>
    <p class="hg-hint">Recent searches are read on their own every 6 hours, with the rest of search's learning.</p>
  </form>
<?php endif; ?>
</div>
<?php tv_page_end();
