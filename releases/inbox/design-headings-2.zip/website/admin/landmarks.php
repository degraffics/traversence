<?php
// /admin/landmarks.php — natural landmarks review (decisions/0058 §24).
//   Waiting   on a sovereign nation's land, or a name that may mark a sacred or protected site: approve (Editor; on a
//             nation's land only with "the nation welcomes visitors here" ticked) or hide with a reason
//   Shown     listed on their own: hide any that shouldn't be
//   Approved / Hidden   a person's decisions; kept across the monthly reload. "Undo" puts one back to what the site
//             would decide.
// Who: staff with a content role. Approving needs an Editor.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/Landmarks.php';
require_once __DIR__ . '/../../app/lib/Journeys.php';
require_once __DIR__ . '/../../app/lib/Nations.php';
require_once __DIR__ . '/../../app/lib/SearchIndex.php';
require_once __DIR__ . '/../../app/ui/explore-hero.php';

$pdo = Database::connection();
$me = Auth::currentUser();
$uid = $me ? (int) $me['id'] : 0;
$ready = Landmarks::ready($pdo);
$can = ['content' => $uid && Journeys::staffCan($pdo, $uid, 'content'), 'publish' => $uid && Journeys::staffCan($pdo, $uid, 'publish')];
if (!$can['content'] || !$ready) {
    http_response_code($me ? ($ready ? 403 : 503) : 401);
    tv_page_start('Landmarks', ['section' => 'admin', 'active' => 'landmarks']);
    echo '<div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">' . ($ready ? 'Staff only' : 'Not set up yet') . '</h1><p class="text-sm text-[#5C4632] mt-2">'
        . (!$ready ? 'Run app/migrations/2026-10-16_landmarks.sql first.' : ($me ? 'Reviewing landmarks is for Traversence staff with an Editor or Content Creator role.' : 'Please <a class="underline" href="/login.php?next=/admin/landmarks.php">sign in</a>.')) . '</p></div>';
    tv_page_end();
    exit;
}
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$views = Landmarks::views();   // no Waiting while the nation tools are off (decisions/0058 §27)
$view = isset($views[$_GET['view'] ?? '']) ? (string) $_GET['view'] : array_key_first($views);
$q = trim((string) ($_GET['q'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'approve' && !$can['publish']) throw new InvalidArgumentException('Approving needs an Editor.');
        if ($do === 'add') {   // one the data doesn't have (decisions/0058 §25)
            $id = Landmarks::add($pdo, $uid, $_POST, $can['publish']);
            try { if (SearchIndex::ready($pdo)) SearchIndex::refreshLandmark($pdo, $id); } catch (Throwable $e) { error_log('landmarks reindex: ' . $e->getMessage()); }
            $added = Landmarks::get($pdo, $id);
            $_SESSION['lmk_flash'] = [true, $added ? 'Added. It shows in search and on its page now.' : 'Added. It waits under Waiting for an Editor.'];
            header('Location: /admin/landmarks.php?' . http_build_query(['view' => $added ? 'public' : array_key_first(Landmarks::views())]), true, 303);
            exit;
        }
        $id = (int) ($_POST['id'] ?? 0);
        Landmarks::review($pdo, $uid, $id, $do, (string) ($_POST['note'] ?? ''), (string) ($_POST['evidence_url'] ?? ''), (string) ($_POST['contact'] ?? ''));
        try { if (SearchIndex::ready($pdo)) SearchIndex::refreshLandmark($pdo, $id); } catch (Throwable $e) { error_log('landmarks reindex: ' . $e->getMessage()); }
        $_SESSION['lmk_flash'] = [true, ['approve' => 'Approved. It shows in search and on its page now.', 'hide' => 'Hidden. It no longer shows anywhere.', 'restore' => 'Undone.',
            'nation_close' => 'Closed at the nation\'s request. It no longer shows, and only the nation can reopen it.', 'nation_reopen' => 'Reopened at the nation\'s request. It waits under Waiting for an Editor to confirm the nation\'s page.'][$do] ?? 'Done.'];
    } catch (InvalidArgumentException $e) {
        $_SESSION['lmk_flash'] = [false, $e->getMessage()];
    }
    header('Location: /admin/landmarks.php?' . http_build_query(['view' => $view, 'q' => $q !== '' ? $q : null]), true, 303);
    exit;
}
$flash = $_SESSION['lmk_flash'] ?? null; unset($_SESSION['lmk_flash']);
$counts = Landmarks::counts($pdo);
$rows = Landmarks::queue($pdo, $view, $q);
$st = Landmarks::status($pdo);

tv_page_start('Landmarks', ['section' => 'admin', 'active' => 'landmarks', 'no_crumbs' => true]);
$hidden = fn (string $do, int $id) => '<input type="hidden" name="csrf" value="' . tv_e($csrf) . '"><input type="hidden" name="do" value="' . $do . '"><input type="hidden" name="id" value="' . $id . '">';
?>
<style>
  .lk{max-width:60rem}.lk h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.7rem;margin:0 0 .3rem}
  .lk-lead{font-size:.9rem;color:#5C4632;margin:0 0 .8rem}
  .lk-tabs{display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.8rem;align-items:center}.lk-tabs a{border:1px solid #CBB98D;border-radius:999px;padding:.3rem .8rem;font-size:.85rem;font-weight:600;color:#3E2B1F;text-decoration:none;background:#FFFBF2}
  .lk-tabs a.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.lk-tabs small{opacity:.7}
  .lk-tabs form{margin-left:auto;display:flex;gap:.3rem}.lk-tabs input{border:1px solid #CBB98D;border-radius:999px;padding:.3rem .7rem;font-size:.85rem;background:#FFFBF2;width:12rem;max-width:40vw}
  .lk-it{display:grid;grid-template-columns:5.5rem minmax(0,1fr);gap:.7rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;padding:.7rem .8rem;margin-bottom:.5rem}
  .lk-ph{aspect-ratio:1;border-radius:.5rem;background:#5A4330 center/cover no-repeat}
  .lk-it h3{margin:0;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.05rem}.lk-it h3 a{color:#92400E}
  .lk-meta{font-size:.76rem;color:#8A7355;margin:.15rem 0 .3rem}.lk-sum{font-size:.86rem;color:#3E2B1F;margin:0 0 .4rem;line-height:1.45}
  .lk-tag{font-family:system-ui,sans-serif;font-size:.62rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;border-radius:999px;padding:.12rem .45rem;background:#F7EFDC;color:#5C4632;vertical-align:middle}
  .lk-why{font-size:.78rem;font-weight:600;color:#92400E;margin:0 0 .4rem}
  .lk-acts{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center}.lk-f{display:flex;flex-wrap:wrap;gap:.3rem;align-items:center;margin:0}
  .lk-f input[type=text]{border:1px solid #CBB98D;border-radius:.45rem;padding:.25rem .45rem;font-size:.8rem;width:13rem;max-width:50vw}.lk-f label{font-size:.78rem}
  .lk-b{border:1px solid #CBB98D;border-radius:999px;padding:.25rem .7rem;font-size:.8rem;font-weight:600;background:#FFFBF2;color:#3E2B1F;cursor:pointer;text-decoration:none}
  .lk-b.go{background:#2F5D4A;border-color:#2F5D4A;color:#fff}.lk-b.no{color:#991B1B}
  .lk-add{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;padding:.55rem .8rem;margin-bottom:.8rem}.lk-add summary{cursor:pointer;font-weight:700;font-size:.9rem;color:#92400E}
  .lk-addf{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.5rem .7rem;margin-top:.6rem}.lk-addf label{display:flex;flex-direction:column;gap:.2rem;font-size:.78rem;font-weight:600;color:#5C4632}
  .lk-addf .w{grid-column:1/-1}.lk-addf .ck{flex-direction:row;align-items:center;gap:.4rem;font-weight:500}
  .lk-addf input[type=text],.lk-addf select,.lk-addf textarea{border:1px solid #CBB98D;border-radius:.45rem;padding:.4rem .5rem;font:inherit;font-size:.88rem;font-weight:400;background:#fff;color:#3E2B1F;min-width:0}
  .lk-msg{border-radius:.6rem;padding:.5rem .75rem;font-size:.88rem;margin-bottom:.7rem}.lk-msg.ok{background:#E8F2EC;color:#2F5D4A}.lk-msg.err{background:#FEE2E2;color:#991B1B}
  @media (max-width:640px){.lk-it{grid-template-columns:4rem minmax(0,1fr)}}
</style>
<div class="lk">
  <h1>Natural landmarks</h1>
  <p class="lk-lead">Badlands, arches, canyons, buttes, waterfalls and hot springs from USGS Geographic Names, with Wikipedia's description and a Wikimedia Commons photo where there is one. The worker reloads them monthly<?= $st['last_finished'] ? ' (last: ' . tv_e(date('M j', strtotime((string) $st['last_finished']))) . ', ' . number_format($st['records']) . ' kept)' : ' (not loaded yet)' ?>.
    <?php if (Landmarks::NATION_TOOLS): ?>Public places show everywhere, a nation's land included (decisions/0066). Sensitive places wait here: a name that may mark a sacred or protected site, or a nation's springs. Open one on a nation's land only with the nation's own word (a link to its page). When a nation asks us to close something, use “Closed by the nation”: only the nation can reopen it. Each nation's rules are under <a class="underline" href="/admin/nations.php">Nations</a>.<?= $can['publish'] ? '' : ' Approving needs an Editor; you can hide.' ?>
    <?php else: ?>Public places show on Traversence. On a nation's land, only its public places (add one here with the nation's own page) and public businesses. Hide anything that shouldn't show; use “Closed by the nation” when a nation asks. Rules: <a class="underline" href="/admin/nations.php">Nations</a>.<?php endif; ?></p>
  <?php if ($flash): ?><p class="lk-msg <?= $flash[0] ? 'ok' : 'err' ?>"><?= tv_e($flash[1]) ?></p><?php endif; ?>
  <details class="lk-add"<?= ($_GET['add'] ?? '') !== '' ? ' open' : '' ?>><summary>+ Add a landmark the data doesn't have</summary>
    <form method="post" class="lk-addf">
      <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="do" value="add">
      <label>Name <input type="text" name="name" maxlength="200" required placeholder="Four Corners Monument"></label>
      <label>Kind <select name="kind" required><option value="">Choose…</option><?php foreach (Landmarks::ADD_KINDS as $k => $l): ?><option value="<?= $k ?>"><?= tv_e($l) ?></option><?php endforeach; ?></select></label>
      <label>State <select name="state" required><?php foreach (NpiBulk::STATES as $st2): ?><option><?= $st2 ?></option><?php endforeach; ?></select></label>
      <label>County <input type="text" name="county" maxlength="80" placeholder="Optional"></label>
      <label>Latitude <input type="text" name="lat" inputmode="decimal" required placeholder="36.9990"></label>
      <label>Longitude <input type="text" name="lon" inputmode="decimal" required placeholder="-109.0452"></label>
      <label class="w">On a tribal nation's land? <select name="nation"><option value="">No</option><?php foreach (Nations::all($pdo) as $nn): ?><option><?= tv_e($nn['name']) ?></option><?php endforeach; ?></select></label>
      <label class="w">The nation's own page that lists it for visitors <input type="text" name="evidence_url" maxlength="500" placeholder="Needed on a nation's land: https://… (the nation's site, not a county's or a travel site's)"></label>

      <label class="w">What it's like <textarea name="description" maxlength="1200" rows="3" placeholder="In your own words: what it is, why go, anything a visitor should know (fees, hours, permits)."></textarea></label>
      <label class="w">Wikipedia article title <input type="text" name="wiki_title" maxlength="200" placeholder="Optional, e.g. Four Corners Monument"></label>
      <label class="w">Photo from Wikimedia Commons <input type="text" name="image_url" maxlength="500" placeholder="Optional: the upload.wikimedia.org file link"></label>
      <label>Photo by <input type="text" name="image_credit" maxlength="200"></label>
      <label>License <input type="text" name="image_license" maxlength="60" placeholder="CC BY-SA 4.0"></label>
      <label class="w">Photo's Commons page <input type="text" name="image_page" maxlength="500" placeholder="https://commons.wikimedia.org/wiki/File:…"></label>
      <p class="w lk-meta">Right-click the spot in Google Maps to copy its latitude and longitude. Public places only, never a sacred or restricted site.<?= $can['publish'] ? '' : ' An Editor approves what you add.' ?></p>
      <p class="w"><button class="lk-b go">Add it</button></p>
    </form>
  </details>
  <nav class="lk-tabs"><?php foreach ($views as $k => $l): ?><a href="?view=<?= $k ?>" class="<?= $k === $view ? 'on' : '' ?>"><?= tv_e($l) ?> <small><?= number_format($counts[$k] ?? 0) ?></small></a><?php endforeach; ?>
    <form><input type="hidden" name="view" value="<?= tv_e($view) ?>"><input type="search" name="q" value="<?= tv_e($q) ?>" placeholder="Find by name"><button class="lk-b">Find</button></form></nav>
  <?php if (!Landmarks::NATION_TOOLS && ($counts['kept'] ?? 0) > 0): ?><p class="lk-meta" style="margin:-.3rem 0 .7rem"><?= number_format($counts['kept']) ?> more are held as sensitive, unused, until the nation tools: a name that may mark a sacred or protected site, or a nation's springs. They never show. Public places on a nation's land show like anywhere else.</p><?php endif; ?>
  <?php if (!$rows): ?><p class="lk-lead">Nothing here.</p><?php endif; ?>
  <?php foreach ($rows as $r): $id = (int) $r['gnis_id']; $vis = Landmarks::visible($r); $parked = !Landmarks::NATION_TOOLS && $r['status'] === 'waiting'; ?>
    <div class="lk-it tv-bleed">
      <div class="lk-ph" style="<?= $r['image_url'] !== '' ? 'background-image:url(\'' . tv_e($r['image_url']) . '\')' : tv_explore_art((string) $r['name'], true) ?>"></div>
      <div>
        <h3><?php if ($vis): ?><a href="/place/landmark.php?id=<?= $id ?>"><?= tv_e($r['name']) ?></a><?php else: ?><?= tv_e($r['name']) ?><?php endif; ?><?php if ($r['file'] === 'manual'): ?> <span class="lk-tag">Added by hand</span><?php elseif ($r['status'] === 'approved'): ?> <span class="lk-tag">Opened by a person</span><?php endif; ?></h3>
        <p class="lk-meta"><?= tv_e(implode(' · ', array_filter([Landmarks::kindLabel($r), $r['nation'] !== '' ? 'On ' . Nations::label($pdo, (string) $r['nation']) . ' land' : '', $r['near_town'] !== '' ? 'near ' . $r['near_town'] : '', $r['county'] !== '' ? $r['county'] . ' County, ' . $r['state'] : $r['state']]))) ?>
          · <a class="underline" href="https://www.google.com/maps/search/?api=1&query=<?= rawurlencode($r['lat'] . ',' . $r['lon']) ?>" target="_blank" rel="noopener">map</a><?= $r['wiki_title'] !== '' ? ' · <a class="underline" href="https://en.wikipedia.org/wiki/' . tv_e(rawurlencode(str_replace(' ', '_', (string) $r['wiki_title']))) . '" target="_blank" rel="noopener">Wikipedia</a>' : '' ?></p>
        <?php if ($parked): ?><p class="lk-why">Not shown: kept, unused, until the nation tools.</p><?php endif; ?>
        <?php if ($r['why'] !== '' && $r['status'] === 'waiting'): ?><p class="lk-why"><?= tv_e($r['why']) ?></p><?php endif; ?>
        <?php $sum = Landmarks::about($pdo, $r); if ($sum !== ''): ?><p class="lk-sum"><?= tv_e(mb_strimwidth($sum, 0, 320, '…')) ?></p><?php endif; ?>
        <?php if ($r['review_note'] !== ''): ?><p class="lk-meta">Note: <?= tv_e($r['review_note']) ?></p><?php endif; ?>
        <?php if ($r['evidence_url'] !== ''): ?><p class="lk-meta">Opened on: <a class="underline" href="<?= tv_e($r['evidence_url']) ?>" target="_blank" rel="noopener">the nation's page</a></p><?php endif; ?>
        <?php if ($r['nation'] !== ''): foreach (array_slice(Nations::history($pdo, 'landmark', (string) $id), 0, 3) as $hh): ?><p class="lk-meta">· <?= tv_e(date('M j, Y', strtotime((string) $hh['at'])) . ': ' . ($hh['from_status'] ?: 'new') . ' → ' . $hh['to_status'] . ($hh['nation_contact'] !== '' ? ', asked by ' . $hh['nation_contact'] : '') . ($hh['note'] !== '' ? ' (' . $hh['note'] . ')' : '')) ?></p><?php endforeach; endif; ?>
        <div class="lk-acts">
          <?php if ($r['status'] === 'waiting' && $can['publish'] && Landmarks::NATION_TOOLS): ?>
            <form method="post" class="lk-f"><?= $hidden('approve', $id) ?><?php if ($r['nation'] !== ''): ?><input type="text" name="evidence_url" maxlength="500" placeholder="The nation's own page that lists it" required><?php endif; ?><button class="lk-b go">Approve</button></form>
          <?php endif; ?>
          <?php if ($r['nation'] !== '' && $r['status'] !== 'closed'): ?>
            <form method="post" class="lk-f"><?= $hidden('nation_close', $id) ?><input type="text" name="contact" maxlength="200" placeholder="Who at the nation asked, and how" required><button class="lk-b no" title="The nation asked us to close it. Only the nation can reopen it.">Closed by the nation</button></form>
          <?php endif; ?>
          <?php if ($r['status'] === 'closed' && Landmarks::NATION_TOOLS): ?>
            <form method="post" class="lk-f"><?= $hidden('nation_reopen', $id) ?><input type="text" name="contact" maxlength="200" placeholder="Who at the nation asked to reopen it" required><button class="lk-b">Reopen at the nation's request</button></form>
          <?php endif; ?>
          <?php if (!in_array($r['status'], ['hidden', 'closed'], true)): ?>
            <form method="post" class="lk-f"><?= $hidden('hide', $id) ?><input type="text" name="note" maxlength="300" placeholder="Why it shouldn't show" required><button class="lk-b no">Hide</button></form>
          <?php endif; ?>
          <?php if (in_array($r['status'], ['approved', 'hidden'], true) && !$parked): ?>
            <form method="post" class="lk-f"><?= $hidden('restore', $id) ?><button class="lk-b" title="Back to what the site would decide on its own">Undo</button></form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php tv_page_end();
