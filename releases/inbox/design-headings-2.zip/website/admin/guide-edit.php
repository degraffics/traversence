<?php
// admin/guide-edit.php — one place's guide (decisions/0131), inside Let's Explore → Guides at
// /admin/explore/place_guides/<number> (Guides::num: tier × 10,000,000 + id). What our team writes for each section;
// the names it mentions and what each links to (and why one can't be, yet); the picks per section (pin or hide); live or
// draft. A guide goes live only when every name it mentions is linked or taken out.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/Guides.php';
require_once __DIR__ . '/../../app/lib/GuideLinks.php';
require_once __DIR__ . '/../../app/lib/AiClient.php';

$pdo = Database::connection();
tv_crawler_require_admin($pdo);
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$n = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$base = '/admin/explore/place_guides/';
if (!isset($tvItemRoute) && empty($_GET['embed']) && $_SERVER['REQUEST_METHOD'] === 'GET') { header('Location: ' . $base . $n, true, 301); exit; }
$key = Guides::keyOf($n);
$p = $key ? Guides::place($pdo, $key) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $p) {
    $to = $base . $n;
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $msg = '';
        switch ((string) ($_POST['do'] ?? '')) {
            case 'save': $msg = Guides::save($pdo, $key, (array) ($_POST['s'] ?? []) + ['elevation_ft' => (string) ($_POST['elevation_ft'] ?? ''), 'field_notes' => (string) ($_POST['field_notes'] ?? '')], (int) $me['id'], !empty($_POST['publish'])); break;
            case 'unpublish': Guides::unpublish($pdo, $key); $msg = 'Taken down: visitors see the guide built from our data, without the written sections. It stays down until someone publishes it.'; break;
            case 'link': GuideLinks::setLink($pdo, (int) ($_POST['mention'] ?? 0), (string) ($_POST['ref'] ?? ''), (int) $me['id']); $msg = ($_POST['ref'] ?? '') === 'dismiss' ? 'Set aside: it no longer holds the guide back.' : 'Linked.'; $to .= '#names'; break;
            case 'pick': Guides::setPick($pdo, $key, (string) ($_POST['section'] ?? ''), (string) ($_POST['ref'] ?? ''), (string) ($_POST['mode'] ?? ''), (int) $me['id']); $msg = 'Picks updated.'; $to .= '#picks'; break;
            case 'draft':   // Claude writes the empty sections now (or rewrites its own, untouched ones); if it can't finish here, the guide job does (decisions/0131)
                Guides::queueDraft($pdo, $key, (int) $me['id']);
                [$aiOk, $aiWhy] = AiClient::allow($pdo, 'guide_draft');
                $msg = $aiOk ? Guides::writeDraft($pdo, $key, !empty($_POST['rewrite'])) : 'Not written now: ' . $aiWhy . ' It\'s asked for, and the guide job writes it when it can.';
                $to .= '#write'; break;
            case 'factcheck':   // Check my facts: on request only, never changes their words
                $fcr = Guides::checkFacts($pdo, $key, (int) $me['id']);
                $nc = count(array_filter($fcr['items'], fn ($x) => $x['kind'] === 'conflict')); $nu = count($fcr['items']) - $nc;
                $msg = $fcr['items'] ? 'Checked: ' . ($nc ? $nc . ' thing' . ($nc === 1 ? '' : 's') . ' our sources disagree with' : '') . ($nc && $nu ? ', ' : '') . ($nu ? $nu . ' our sources don\'t cover' : '') . '. Each is noted under its section; nothing was changed.' : 'Checked: nothing in what our team wrote disagrees with what we hold.';
                $to .= '#ge-form'; break;
            case 'find': $r = GuideLinks::findTick($pdo, 5); $msg = 'Find it: ' . $r['found'] . ' found (in Review), ' . $r['notfound'] . ' not confirmed, ' . $r['relinked'] . ' linked' . ($r['waiting'] ? '. ' . $r['waiting'] . ' are waiting: Claude is off or over the monthly cap.' : '.'); $to .= '#names'; break;
        }
        if ($msg !== '') tv_crawler_flash(['type' => 'ok', 'text' => trim($msg)]);
    } catch (Throwable $ex) {
        if (!($ex instanceof RuntimeException) || $ex instanceof PDOException) error_log('guide-edit: ' . $ex->getMessage());
        tv_crawler_flash(['type' => 'error', 'text' => $ex instanceof RuntimeException && !($ex instanceof PDOException) ? $ex->getMessage() : 'That didn\'t work. Try again.']);
    }
    header('Location: ' . $to, true, 303); exit;
}

tv_admin_start('explore', $p ? $p['kind'] . ': ' . $p['name'] : 'Guide', '', null, $p ? [['Let\'s Explore', '/admin/explore'], ['Guides', '/admin/explore/place_guides'], [$p['name'], null]] : []);   // the command strip takes the title's place
if (!Guides::ready($pdo)) { echo '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2027-01-11_place_guides.sql</code> in phpMyAdmin first.</p></div>'; tv_admin_end(); return; }
if (!$p) { echo '<div class="hb-card tv-bleed"><p class="text-sm">That place isn\'t here. <a class="hb-go" href="/admin/explore/place_guides">All guides</a></p></div>'; tv_admin_end(); return; }

$g = Guides::get($pdo, $key);
$ments = GuideLinks::mentions($pdo, $key);
$block = array_values(array_filter($ments, fn ($m) => in_array($m['status'], GuideLinks::BLOCKING, true)));
$linked = count(array_filter($ments, fn ($m) => in_array($m['status'], ['linked', 'thin'], true)));
$hidden = fn (string $do) => '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="id" value="' . $n . '"><input type="hidden" name="do" value="' . $do . '">';
$chain = Guides::chain($pdo, $key);
$di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: [];
$waiting = count(array_filter($ments, fn ($m) => in_array($m['status'], GuideLinks::WAITING, true)));

require_once __DIR__ . '/../../app/ui/command-strip.php';
echo tv_command_strip(['noun' => 'guide', 'title' => $p['name'] . ' · ' . $p['kind'], 'news_key' => 'guide-' . $n, 'news_tone' => $block ? 'bad' : 'info',
    'news' => [$g['status'] === 'live' ? (!empty($di['auto_published']) ? 'Live: compiled by Claude ' . date('M j', strtotime((string) $di['auto_published'])) . '. Edit it or take it down any time' : 'Live')
                                       : (!empty($di['kept']) ? 'Taken down by our team: it stays a draft until someone publishes it' : ($g['updated_at'] ? 'Draft: visitors see the guide built from our data' : 'Nothing written yet: visitors see the guide built from our data')),
               $g['draft_status'] === 'gathering' ? 'Gathering its sources (free public records first)' : ($g['draft_status'] === 'queued' ? 'Claude is asked to compile it' : ($g['draft_status'] === 'writing' ? 'Claude is writing it' : ($g['draft_status'] === 'done' && $g['status'] !== 'live' && empty($di['kept']) ? 'Compiled by Claude ' . date('M j', strtotime((string) $g['draft_at'])) . ($block ? ': waiting for the names below' : (Guides::publishesItself($pdo) ? '' : ': publishing by itself is off (AI use), so publish it when it reads right')) : ($g['draft_status'] === 'failed' ? 'Claude\'s draft didn\'t finish: try again' : '')))),
               $ments ? $linked . ' of ' . count($ments) . ' names linked' . ($waiting ? ', ' . $waiting . ' being found (plain text until then)' : '') : '', $block ? count($block) . ' holding it back (see Names in this guide)' : ''],
    'back' => '/admin/explore/place_guides', 'close' => '/admin/explore/place_guides', 'root' => '.ge',
    'more' => array_values(array_filter([['See the guide' . ($g['status'] === 'live' ? '' : ' (preview)'), $p['url'] . ($g['status'] === 'live' ? '' : '&preview=1'), 'new'], ['Who to call (resource lines)', '/admin/explore/guides', ''],
               $g['status'] === 'live' ? ['Take it down', '#ge-unpub', 'danger'] : null]))]);
?>
<style>
  .ge .ge-in{font-size:.85rem;color:#5C4632;margin:.3rem 0 .6rem}
  .ge-spin{display:inline-block;width:1em;height:1em;border:2px solid currentColor;border-right-color:transparent;border-radius:999px;vertical-align:-.15em;margin-right:.45rem;animation:ge-spin .8s linear infinite}
  @keyframes ge-spin{to{transform:rotate(360deg)}} .ge-busy{flex-basis:100%;font-size:.85rem;color:#5C4632;margin:.2rem 0 0}.ge .ge-ul{margin:.2rem 0 .6rem 1.1rem;font-size:.85rem;color:#3E2B1F;list-style:disc;overflow-wrap:anywhere}
  .ge label.ge-f{display:grid;gap:.25rem;margin:.8rem 0 0;font-weight:700;color:#3E2B1F}.ge label.ge-f small{font-weight:400;color:#8A7355}
  .ge textarea,.ge input.hb-in{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.5rem;padding:.5rem .6rem;font:inherit;background:#fff}
  .ge textarea{min-height:7rem;line-height:1.5}
  .ge-acts{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.9rem}
  .ge-m{width:100%;border-collapse:collapse;font-size:.88rem}.ge-m th,.ge-m td{text-align:left;padding:.4rem .5rem .4rem 0;border-top:1px solid #EADFC4;vertical-align:top}.ge-m th{font-weight:600;color:#8A7355;font-size:.75rem;text-transform:uppercase}
  .ge-p{display:inline-block;border-radius:999px;padding:.05rem .55rem;font-size:.75rem;font-weight:700;background:#EADFC4;color:#5C4632}
  .ge-p.linked{background:#DCFCE7;color:#14532D}.ge-p.thin{background:#ECFCCB;color:#3F6212}.ge-p.finding,.ge-p.review{background:#FEF3C7;color:#7C2D12}.ge-p.unconfirmed,.ge-p.held,.ge-p.closed{background:#FEE2E2;color:#7F1D1D}
  .ge-link{display:flex;gap:.3rem;margin-top:.3rem}.ge-link input{flex:1;min-width:0;padding:.25rem .45rem!important;font-size:.82rem!important}.ge-link button{font-size:.8rem}
  .ge-pk{display:flex;justify-content:space-between;gap:.5rem;align-items:center;border-top:1px solid #EADFC4;padding:.35rem 0;font-size:.88rem}.ge-pk form{display:inline}
  @media (max-width:767px){ .ge-m thead{display:none} .ge-m tr{display:grid;border-top:1px solid #EADFC4;padding:.4rem 0} .ge-m td{border:0;padding:.1rem 0} }
</style>
<div class="ge">
  <p class="ge-in"><?= $e(implode(' < ', array_map(fn ($c) => $c['kind'] . ': ' . $c['name'], $chain))) ?>. The guide is built from our data (next stops, listings picked by the Chameleon Filter, outdoors, landmarks, who to call, weather and roads); what you write here goes above each part. Every name you write links to something we have: <b>[[Name]]</b> or <b>**Name**</b> marks one for sure.</p>

  <h2 class="hb-h" id="write">Written sections</h2>
  <?php $empty = !array_filter($g['sections'], fn ($t) => trim((string) $t) !== ''); ?>
  <div class="hb-card tv-bleed ge-draft">
    <?php // the monthly check (Guides::maintainTick, decisions/0133 Phase 6) ?>
    <?php if (!empty($di['renew'])): ?><p data-tv-status="info" data-tv-label="Being renewed:">The monthly check found <?= $e(implode('; ', (array) $di['renew'])) ?>. The guide job writes Claude's sections again (yours stay) and scores it under the same rules.</p><?php endif; ?>
    <?php if (!empty($di['flags'])): ?><p data-tv-status="bad" data-tv-label="Check this:">The monthly check found <?= $e(implode('; ', (array) $di['flags'])) ?>. That is in what a person wrote, so nothing there was changed.</p><?php endif; ?>
    <?php if (!empty($di['checked_at']) && empty($di['renew']) && empty($di['flags'])): ?><p data-tv-status="ok" data-tv-label="Checked:"><?= $e(date('M j', strtotime((string) $di['checked_at']))) ?><?= !empty($di['checked_for']) ? ' (because ' . $e(implode('; ', (array) $di['checked_for'])) . ')' : '' ?>: nothing out of date. Freshness <?= Guides::freshness($di) ?> of 100. The next check is in 30 days, or sooner if something changes.</p><?php endif; ?>
    <?php if (!empty($di['due'])): ?><p data-tv-status="info" data-tv-label="Check coming:"><?= $e(implode('; ', (array) $di['due'])) ?>: the guide job checks it on its next turn.</p><?php endif; ?>
    <?php if ($g['draft_status'] === 'done' && !empty($di['added'])): ?>
      <p data-tv-status="info" data-tv-label="Compiled by Claude:">Claude wrote <?= $e(implode(', ', $di['added'])) ?> on <?= $e(date('M j', strtotime((string) $di['at']))) ?><?= !empty($di['dossier']) ? ', from the dossier our crawler gathered (Wikipedia, Wikidata, the official website, our records)' : '' ?>. <?= $g['status'] === 'live' ? 'It\'s live: fix anything off here and save, or take it down from ☰.' : 'Fix anything off, then Save and go live.' ?></p>
      <?php if (!array_key_exists('confidence', $di) && empty($di['kept'])): ?><p data-tv-status="info" data-tv-label="Written the old way:">This was written before the crawler's dossier and the confidence score. The guide job writes Claude's sections again from them, one guide a run (the oldest first); anything you changed stays. Rewrite Claude's sections does it now.</p><?php endif; ?>
      <?php if (array_key_exists('confidence', $di)): [$sc, $why] = Guides::score($pdo, $key, $di); $min = AiClient::feature($pdo, 'guide_publish')['per_day']; ?>
      <p data-tv-status="<?= $sc >= $min ? 'ok' : 'info' ?>" data-tv-label="Confidence score <?= (int) $sc ?>:"><?= $e(implode(', ', array_map(fn ($k, $v) => $k . ' ' . ($v > 0 ? '+' : '') . $v, array_keys($why), $why))) ?>. <?= $sc >= $min ? 'Enough to go live by itself (' . $min . ').' : 'It needs ' . $min . ' to go live by itself; it rises as Find it links its names.' ?></p>
      <?php endif; ?>
      <?php if (array_key_exists('searches', $di) && !(int) $di['searches'] && !empty($di['dossier']) && ($di['search_error'] ?? '') === ''): ?><p class="ge-in">Written from the crawler's dossier: Claude didn't need the web this time.</p>
      <?php elseif (array_key_exists('searches', $di) && !(int) $di['searches']): ?><p data-tv-status="bad" data-tv-label="No web search:"><?= ($di['search_error'] ?? '') !== '' ? 'Claude\'s web search was refused (' . $e((string) $di['search_error']) . '). Turn on web search for your organization in the Claude Console (Settings → Privacy), then Rewrite Claude\'s sections.' : 'Claude didn\'t search the web this time, so the draft rests on our lists only. Rewrite Claude\'s sections to try again.' ?></p>
      <?php elseif (!empty($di['searches'])): ?><p class="ge-in">Claude searched the web <?= (int) $di['searches'] ?> time<?= (int) $di['searches'] === 1 ? '' : 's' ?> for this draft.</p><?php endif; ?>
      <?php if (!empty($di['check'])): ?><p class="ge-in"><b>Claude says to check:</b></p><ul class="ge-ul"><?php foreach ($di['check'] as $c): ?><li><?= $e($c) ?></li><?php endforeach; ?></ul><?php endif; ?>
      <?php if (!empty($di['sources'])): ?><details class="ge-in"><summary>Its sources (<?= count($di['sources']) ?>)</summary><ul class="ge-ul"><?php foreach ($di['sources'] as $src): ?><li><?php if (preg_match('~^https?://~', $src)) { $lab = (string) preg_replace('~^https?://(www\.)?~', '', urldecode($src)); $lab = preg_match('~^recreation\.gov/search\?q=(.+)$~', $lab, $rq) ? 'Recreation.gov: ' . $rq[1] : rtrim($lab, '/'); echo '<a class="hb-go" href="' . $e($src) . '" target="_blank" rel="noopener">' . $e($lab) . '</a>'; } else echo $e($src); ?></li><?php endforeach; ?></ul></details><?php endif; ?>
    <?php elseif ($g['draft_status'] === 'failed'): ?><p data-tv-status="bad" data-tv-label="Not finished:"><?= $e((string) ($di['error'] ?? 'Claude\'s draft didn\'t finish.')) ?></p>
    <?php elseif ($g['draft_status'] === 'gathering'): ?><p data-tv-status="info" data-tv-label="Gathering:">Before Claude writes it, the crawler is gathering the free public records: the dossier, the National Register, and the Library of Congress's catalog and historic newspapers. Then the research brief fills only the gaps. It's written within two days, or press Write a draft to write it now from what's in.</p>
    <?php elseif (in_array($g['draft_status'], ['queued', 'writing'], true)): ?><p data-tv-status="info" data-tv-label="On its way:">Claude is <?= $g['draft_status'] === 'writing' ? 'writing' : 'about to write' ?> this guide. Reload in a few minutes.</p>
    <?php else: ?><p class="ge-in"><?= $empty ? 'Nothing written yet.' : 'Some sections are still empty.' ?> Claude can draft them from what we have here (listings, landmarks, outdoors, towns) and what it confirms on the web. It fills only empty sections, from the dossier our crawler gathers (searching the web only for what that lacks), and the guide goes live by itself<?= Guides::publishesItself($pdo) ? '' : ' when that\'s switched on (System Configuration → AI use)' ?>. Edit it or take it down any time.</p><?php endif; ?>
    <form method="post" class="ge-acts" style="margin-top:.4rem" data-ge-busy="Claude is writing: this takes a minute or two. Stay on this page."><?= $hidden('draft') ?><button class="hb-b<?= $empty ? ' go' : '' ?>"<?= $empty ? '' : ' data-confirm="Claude fills only the empty sections; what\'s written stays. Go ahead?" data-yes="Write the empty sections"' ?>><?= $g['draft_status'] === 'done' ? 'Draft the empty sections again' : 'Write a draft with Claude' ?></button>
      <?php if ($g['draft_status'] === 'done'): ?><button class="hb-b" name="rewrite" value="1" data-confirm="Claude writes its own sections again, the ones nobody has changed. Anything you edited stays as it is." data-yes="Rewrite them">Rewrite Claude's sections</button><?php endif; ?></form>
  </div>
  <form method="post" class="hb-card tv-bleed" id="ge-form"><?= $hidden('save') ?>
    <label class="ge-f">From the ground <small>Only our team sees this. What you know from being there: favourite spots, local names, what a season is like, what visitors ask, what to skip. Notes are fine; Claude writes the guide from these first.</small><textarea name="field_notes" rows="5" placeholder="e.g. Locals call the reservoir 'the lake'. Pioneer Days is the first weekend of June. Best green chile: …"><?= $e((string) ($g['field_notes'] ?? '')) ?></textarea></label>
    <label class="ge-f">Elevation (feet)<input class="hb-in" name="elevation_ft" inputmode="numeric" value="<?= $e((string) ($g['elevation_ft'] ?? '')) ?>" style="max-width:10rem"></label>
    <?php $tsec = Guides::templateSections(Guides::template($pdo));   // the instruction Claude writes each from (Content templates)
      $tips = []; foreach (Guides::factTips($pdo, $key, $g) as [$tk, $tt, $tu]) $tips[$tk][] = ['info', $tt, $tu];   // free: their words against the facts we hold
      $fcx = (array) ($di['factcheck'] ?? []); $mineNow = Guides::personSections($g);
      foreach ((array) ($fcx['items'] ?? []) as $it) if (isset($mineNow[$it['section']]) && ($fcx['sections'][$it['section']] ?? '') === md5($mineNow[$it['section']]))   // only while the section reads as it did when checked
          $tips[$it['section']][] = [$it['kind'] === 'conflict' ? 'bad' : 'info', '"' . mb_strimwidth($it['quote'], 0, 140, '…') . '": ' . ($it['says'] !== '' ? $it['says'] : ($it['kind'] === 'conflict' ? 'our sources disagree' : 'nothing we hold says so')) . ($it['from'] !== '' ? ' (' . $it['from'] . ')' : ''), ''];
    ?>
    <?php foreach (Guides::SECTIONS as $k => [$label, $written, $hint]): if (!$written) continue; $hint = isset($tsec[$k]) ? $tsec[$k]['instruction'] : 'Claude doesn\'t write this section (switched off in the Place guide template); you can.'; ?>
    <label class="ge-f"><?= $e($label) ?><small><?= $e($hint) ?></small><textarea name="s[<?= $e($k) ?>]" rows="<?= in_array($k, ['glance', 'itineraries', 'do'], true) ? 7 : 4 ?>"><?= $e((string) ($g['sections'][$k] ?? '')) ?></textarea></label>
    <?php foreach ($tips[$k] ?? [] as [$tone, $tt, $tu]): ?><p data-tv-status="<?= $tone ?>" data-tv-label="<?= $tone === 'bad' ? 'Check this:' : 'Tip:' ?>"><?= $e($tt) ?><?= $tu !== '' ? ' <a class="underline" href="' . $e($tu) . '" target="_blank" rel="noopener">Source</a>' : '' ?> Your words stay as they are.</p><?php endforeach; ?>
    <?php endforeach; ?>
    <div class="ge-acts"><button class="hb-b go">Save guide</button><button class="hb-b" name="publish" value="1" data-confirm="Save and make it live? It waits only for a name that may mark a protected site or a closed business." data-yes="Save and go live">Save and go live</button></div>
  </form>
  <?php if ($mineNow): ?><form method="post" class="hb-card tv-bleed ge-acts" data-ge-busy="Claude is reading what our team wrote against our sources: about half a minute."><?= $hidden('factcheck') ?><span class="text-sm" style="flex:1 1 14rem">The tips under a section compare what our team wrote with the facts we hold, for free. <b>Check my facts</b> has Claude read it against the dossier, the research brief and the heritage catalog and note what disagrees or isn't supported<?= !empty($fcx['at']) ? ' (last checked ' . $e(date('M j', strtotime((string) $fcx['at']))) . ')' : '' ?>. Nothing is changed.</span><button class="hb-b" data-confirm="Have Claude check the facts in what our team wrote? It costs about a cent." data-yes="Check my facts">Check my facts</button></form><?php endif; ?>
  <?php if ($g['status'] === 'live'): ?><form method="post" hidden><?= $hidden('unpublish') ?><button id="ge-unpub" data-confirm="Take it down? Visitors will see the guide built from our data, without what's written here, and it stays down until someone publishes it." data-yes="Take it down" data-danger>Take it down</button></form><?php endif; ?>

  <h2 class="hb-h" id="names">Names in this guide</h2>
  <div class="hb-card tv-bleed">
    <?php if (!$ments): ?><p class="text-sm">No names yet: they're picked out of the written sections when you save.</p>
    <?php else: ?>
    <?php if ($block): $bn = array_values(array_unique(array_column($block, 'name'))); /* each name once, however often it's written (2026-11-12) */ ?><p data-tv-status="bad" data-tv-label="Holding it back:"><?= count($bn) ?> name<?= count($bn) === 1 ? '' : 's' ?>: <?= $e(implode(', ', array_slice($bn, 0, 8))) ?><?= count($bn) > 8 ? '…' : '' ?>. Each may mark a protected site or is a closed business: take it out of the text (or link it by hand, or reopen the listing, if it's open). Names we don't have yet don't hold it back: they show as plain text until Find it links them.</p>
    <?php else: ?><p data-tv-status="ok" data-tv-label="All linked:">every name in this guide links to something we have.</p><?php endif; ?>
    <table class="ge-m"><thead><tr><th>Name</th><th>Section</th><th>Kind</th><th>Status</th><th></th></tr></thead><tbody>
    <?php foreach ($ments as $m): $url = $m['ref'] !== '' ? GuideLinks::url($pdo, (string) $m['ref']) : ''; ?>
      <tr><td><?= $url !== '' && $url[0] !== '#' ? '<a class="hb-go" href="' . $e($url) . '" target="_blank">' . $e($m['name']) . '</a>' : '<b>' . $e($m['name']) . '</b>' ?></td>
        <td><?= $e(Guides::SECTIONS[$m['section']][0] ?? $m['section']) ?></td><td><?= $e(GuideLinks::KINDS[$m['kind']] ?? $m['kind']) ?></td>
        <td><span class="ge-p <?= $e($m['status']) ?>"><?= $e(GuideLinks::STATUS[$m['status']] ?? $m['status']) ?></span><?= $m['note'] !== '' ? '<br><small>' . $e($m['note']) . '</small>' : '' ?></td>
        <td><?php if (!in_array($m['status'], ['linked', 'dismissed', 'held'], true) || $m['status'] === 'thin'): ?>
          <form method="post" class="ge-link"><?= $hidden('link') ?><input type="hidden" name="mention" value="<?= (int) $m['id'] ?>"><input class="hb-in" name="ref" placeholder="Listing number or address" aria-label="Link <?= $e($m['name']) ?> to a listing"><button class="hb-b">Link</button></form>
          <?php if ($m['status'] !== 'thin'): ?><form method="post" class="ge-link"><?= $hidden('link') ?><input type="hidden" name="mention" value="<?= (int) $m['id'] ?>"><input type="hidden" name="ref" value="dismiss"><button class="hb-b" data-confirm="Not a place to link (a general word)? It stops holding the guide back." data-yes="Set aside">Not a place</button></form><?php endif; ?>
        <?php endif; ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    <?php if (array_filter($ments, fn ($m) => $m['status'] === 'finding')): ?><form method="post" class="ge-acts"><?= $hidden('find') ?><button class="hb-b">Find them now</button><span class="text-sm" style="align-self:center;color:#8A7355">Find it also runs every 15 minutes by itself: our crawler first (OpenStreetMap and the place's own website), Claude only if that finds nothing. What it finds goes to Review.</span></form><?php endif; ?>
    <?php endif; ?>
  </div>

  <h2 class="hb-h" id="picks">Picks per section</h2>
  <div class="hb-card tv-bleed">
    <p class="ge-in">The Chameleon Filter chooses these by what each section is about, how close they are, the kind of experience and the season; names you write are pinned first. Pin one to keep it at the top; hide one that doesn't belong. Paid plans never move a listing up.</p>
    <?php if ($p['level'] === 'hub'): ?><p class="text-sm">A regional guide shows counts, not lists: picks start at the area.</p>
    <?php else: foreach (['eat' => 'Eat & drink', 'stay' => 'Places to stay', 'do' => 'Things to do', 'shop' => 'Shopping', 'care' => 'Nearest care'] as $sk => $sl):
        $rows = Guides::picks($pdo, $p, $sk, 10, 'v', Guides::season());
        $hid = $pdo->prepare("SELECT ref FROM guide_picks WHERE place_key = ? AND section = ? AND mode = 'hide'"); $hid->execute([$key, $sk]); $hiddenRefs = $hid->fetchAll(PDO::FETCH_COLUMN);
        if (!$rows && !$hiddenRefs) continue; ?>
      <h3 style="font:700 1rem var(--tv-font-head,Georgia,serif);margin:.8rem 0 .2rem"><?= $e($sl) ?></h3>
      <?php foreach ($rows as $r): ?>
      <div class="ge-pk"><span><a class="hb-go" href="/listing/view.php?id=<?= (int) $r['id'] ?>" target="_blank"><?= $e($r['name']) ?></a> <small style="color:#8A7355"><?= $e(implode(' · ', array_filter([$r['category'], $r['city'], $r['miles'] !== null ? round((float) $r['miles']) . ' mi' : '', $r['pinned'] ? 'pinned' : '']))) ?></small></span>
        <span><form method="post"><?= $hidden('pick') ?><input type="hidden" name="section" value="<?= $e($sk) ?>"><input type="hidden" name="ref" value="entity:<?= (int) $r['id'] ?>"><input type="hidden" name="mode" value="<?= $r['pinned'] ? 'clear' : 'pin' ?>"><button class="hb-b"><?= $r['pinned'] ? 'Unpin' : 'Pin' ?></button></form>
          <form method="post"><?= $hidden('pick') ?><input type="hidden" name="section" value="<?= $e($sk) ?>"><input type="hidden" name="ref" value="entity:<?= (int) $r['id'] ?>"><input type="hidden" name="mode" value="hide"><button class="hb-b">Hide</button></form></span></div>
      <?php endforeach; foreach ($hiddenRefs as $hr): $hn = $pdo->query('SELECT name FROM entities WHERE id = ' . (int) substr((string) $hr, 7))->fetchColumn(); ?>
      <div class="ge-pk"><span style="color:#8A7355">Hidden: <?= $e((string) $hn) ?></span><form method="post"><?= $hidden('pick') ?><input type="hidden" name="section" value="<?= $e($sk) ?>"><input type="hidden" name="ref" value="<?= $e($hr) ?>"><input type="hidden" name="mode" value="clear"><button class="hb-b">Show again</button></form></div>
      <?php endforeach; ?>
    <?php endforeach; endif; ?>
  </div>
</div>
<script>
/* a Claude button shows it's working (it takes a minute or two): spinner, its own words, the others held */
Array.prototype.forEach.call(document.querySelectorAll('.ge form'), function (f) {
  var d = f.querySelector('input[name="do"]'); if (!d || (d.value !== 'draft' && d.value !== 'find' && d.value !== 'factcheck')) return;
  f.addEventListener('submit', function (ev) {
    var b = ev.submitter || f.querySelector('button');
    setTimeout(function () {   // after any "are you sure" has had its say
      if (ev.defaultPrevented) return;
      f.querySelectorAll('button').forEach(function (x) { x.disabled = true; });
      if (b) b.innerHTML = '<span class="ge-spin" aria-hidden="true"></span>' + b.textContent;
      var n = document.createElement('p'); n.className = 'ge-busy'; n.setAttribute('role', 'status');
      n.textContent = f.getAttribute('data-ge-busy') || 'Claude is looking: this can take a minute.'; f.appendChild(n);
    }, 0);
  });
});
</script>
<?php tv_admin_end();
