<?php
// admin/cluster-tools.php — ZIP population import, one-time micro-cluster merge, and cluster management
// (decisions/0042)
//
// Browser front end for api/scripts/import_zip_population.php and recluster_auto_seeded.php, for
// hosting without a terminal, plus hand edits to clusters (ClusterAdmin). Admin-only, checked server-side before anything renders. Both actions
// are POSTs with the session CSRF token; the merge only writes when "Apply" is pressed with the
// backup box ticked, and everything above that button is a preview computed from live data.

declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';   // Admin → Crawler frame (decisions/0046)
require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';

$pdo = Database::connection();
$me = Auth::currentUser();
if ($me === null || !IntakeStager::canUseIntake($pdo, $me)) {
    http_response_code($me === null ? 401 : 403);
    tv_page_start('Admin');
    echo '<div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Admin only</h1><p class="text-sm text-[#5C4632] mt-2">'
        . ($me === null ? 'Please <a class="underline text-amber-700" href="/login.php">sign in</a> with an admin account.' : 'This account is not an admin.')
        . '</p></div>';
    tv_page_end();
    exit;
}

// This page ships with new library files; if the upload was partial, say which instead of a bare 500.
$missing = [];
foreach (['app/lib/ZipPopulation.php', 'app/lib/crawler/ClusterRecluster.php', 'app/lib/crawler/ClusterAdmin.php', 'app/lib/crawler/Subgroups.php', 'app/lib/PlaceProfile.php', 'app/lib/SupportGroups.php', 'app/lib/crawler/CrawlQueue.php', 'app/lib/crawler/AutoImport.php', 'app/lib/ListingSafety.php', 'app/lib/PlaceScope.php'] as $f) {
    if (!is_file(__DIR__ . '/../../' . $f)) $missing[] = "$f — not on the server";
}
if (!defined('CrawlerIngest::AUTO_SEED_TOWN_CAP') || !method_exists('CrawlerIngest', 'loadClusters')) {
    $missing[] = 'app/lib/CrawlerIngest.php — the server still has the old version';
}
if ($missing) {
    http_response_code(500);
    tv_page_start('Cluster tools');
    echo '<div class="max-w-2xl"><h1 class="font-serif font-bold text-2xl">Cluster tools: files missing</h1>'
        . '<p class="text-sm mt-2">Upload these from the fix package, then reload:</p><ul class="list-disc ml-6 mt-2 text-sm">';
    foreach ($missing as $m) echo '<li><code>' . tv_e($m) . '</code></li>';
    echo '</ul></div>';
    tv_page_end();
    exit;
}
require_once __DIR__ . '/../../app/lib/crawler/ClusterRecluster.php';
require_once __DIR__ . '/../../app/lib/crawler/ClusterAdmin.php';
require_once __DIR__ . '/../../app/lib/crawler/Subgroups.php';
require_once __DIR__ . '/../../app/lib/ZipPopulation.php';
require_once __DIR__ . '/../../app/lib/PlaceProfile.php';
require_once __DIR__ . '/../../app/lib/SupportGroups.php';
require_once __DIR__ . '/../../app/lib/crawler/CrawlQueue.php';
require_once __DIR__ . '/../../app/lib/PageCache.php';
require_once __DIR__ . '/../../app/lib/PlaceScope.php';

// Admin-only page: show a crash as a readable message rather than a blank 500.
set_exception_handler(function (Throwable $e): void {
    http_response_code(500);
    echo '<div style="margin:1rem;padding:1rem;border:1px solid #FCA5A5;background:#FEF2F2;font:14px system-ui">'
        . '<strong>Cluster tools hit an error.</strong><br>' . tv_e($e->getMessage())
        . '<br><small>' . tv_e(basename($e->getFile()) . ':' . $e->getLine()) . '</small></div>';
});
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
@set_time_limit(300);
// One file, three Crawler pages: Places (clusters), Coverage (gaps + crawl queue), Data loads (Census).
$view = in_array($_GET['view'] ?? '', ['places', 'coverage', 'data'], true) ? (string) $_GET['view'] : 'places';

$notice = $_SESSION['ct_flash'] ?? null;   // [ok(bool), html] — carried across the redirect after an edit
unset($_SESSION['ct_flash']);

$geoHubs = $pdo->query('SELECT id, slug, name FROM geo_hubs ORDER BY sort_order, id')->fetchAll(PDO::FETCH_ASSOC);
$hubId = (int) ($_POST['hub'] ?? $_GET['hub'] ?? 0);
if (!in_array($hubId, array_map('intval', array_column($geoHubs, 'id')), true)) {
    $hubId = (int) ($pdo->query('SELECT geo_hub_id FROM micro_clusters GROUP BY geo_hub_id ORDER BY COUNT(*) DESC LIMIT 1')->fetchColumn() ?: ($geoHubs[0]['id'] ?? 0));
}

// Cluster edits (section 3): post, then redirect back to the edited cluster so a reload can't repeat it.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && str_starts_with((string) ($_POST['action'] ?? ''), 'c_')) {
    $jump = (int) ($_POST['cluster'] ?? 0);
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
            throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        }
        $cid = (int) ($_POST['cluster'] ?? 0);
        $zip = (string) ($_POST['zip'] ?? '');
        switch ((string) $_POST['action']) {
            case 'c_rename':
                ClusterAdmin::rename($pdo, $cid, (string) ($_POST['name'] ?? ''));
                $msg = 'Renamed.';
                break;
            case 'c_reviewed':
                ClusterAdmin::markReviewed($pdo, $cid, $hubId);
                $msg = 'Marked reviewed.';
                break;
            case 'c_reviewed_all':
                $n = ClusterAdmin::markReviewed($pdo, null, $hubId);
                $msg = "Marked $n cluster" . ($n === 1 ? '' : 's') . ' reviewed.';
                $jump = 0;
                break;
            case 'c_geohub':
                ClusterAdmin::moveToGeoHub($pdo, $cid, (int) ($_POST['geo_hub'] ?? 0));
                $hubId = (int) $_POST['geo_hub'];
                $msg = 'Moved to another geo-hub.';
                break;
            case 'c_anchor':
                ClusterAdmin::setAnchor($pdo, $cid, $zip);
                $msg = "$zip is now the anchor. Rename the cluster if its name should change too.";
                break;
            case 'c_addzip':
                ClusterAdmin::addZip($pdo, $cid, $zip);
                $msg = "Added $zip.";
                break;
            case 'c_movezip':
                $to = (string) ($_POST['to'] ?? '');
                $jump = ClusterAdmin::moveZip($pdo, $zip, $to === 'new' ? null : (int) $to);
                $msg = "Moved $zip, with its listings and user homes.";
                break;
            case 'c_merge':
                $into = (int) ($_POST['into'] ?? 0);
                ClusterAdmin::merge($pdo, $cid, $into);
                $jump = $into;
                $msg = 'Merged: every ZIP, listing, user home, override and saved place moved over.';
                break;
            case 'c_coords':
                if (!preg_match('/^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$/', (string) ($_POST['coords'] ?? ''), $m)) {
                    throw new InvalidArgumentException('Paste coordinates as "latitude, longitude", e.g. 35.1833, -109.4350.');
                }
                ClusterAdmin::setZipCoordinates($pdo, $zip, (float) $m[1], (float) $m[2]);
                $msg = "Coordinates for $zip updated.";
                break;
            case 'c_queue':
                if (!CrawlQueue::tableExists($pdo)) throw new InvalidArgumentException('Run migrations/2026-09-29_crawl_jobs_and_page_cache.sql in phpMyAdmin first.');
                $r = CrawlQueue::seed($pdo, $hubId, (int) $me['id']);
                $msg = "Queued {$r['added']} new gap" . ($r['added'] === 1 ? '' : 's') . " for the crawler" . ($r['reprioritised'] ? ", updated {$r['reprioritised']} already waiting" : '') . (!empty($r['retried']) ? ", retrying {$r['retried']} that failed" : '') . '.';
                $_SESSION['ct_queue_msg'] = $msg;   // also shown beside the button, which is where the eye is
                $jump = 0;
                $anchor = '#coverage';
                break;
            case 'c_sg_scan':
                $r = Subgroups::scan($pdo, $hubId);
                $msg = "Scanned listings: {$r['new']} new suggestion" . ($r['new'] === 1 ? '' : 's') . ", {$r['updated']} known name" . ($r['updated'] === 1 ? '' : 's') . ' refreshed'
                     . ($r['dropped'] ? ", {$r['dropped']} earlier suggestion" . ($r['dropped'] === 1 ? '' : 's') . ' dropped (no longer enough evidence)' : '') . '.';
                $jump = 0;
                break;
            case 'c_sg_accept':
                Subgroups::accept($pdo, (int) ($_POST['sg'] ?? 0), (string) ($_POST['name'] ?? ''), (string) ($_POST['aliases'] ?? ''));
                $msg = 'Sub-group accepted.';
                break;
            case 'c_sg_edit':
                Subgroups::edit($pdo, (int) ($_POST['sg'] ?? 0), (string) ($_POST['name'] ?? ''), (string) ($_POST['aliases'] ?? ''));
                $msg = 'Sub-group saved.';
                break;
            case 'c_sg_reject':
                Subgroups::reject($pdo, (int) ($_POST['sg'] ?? 0));
                $msg = 'Removed. Scans won\'t suggest that name again.';
                break;
            case 'c_sg_add':
                Subgroups::add($pdo, $cid, (string) ($_POST['name'] ?? ''), (string) ($_POST['aliases'] ?? ''));
                $msg = 'Sub-group added.';
                break;
            default:
                throw new InvalidArgumentException('Unknown action.');
        }
        $_SESSION['ct_flash'] = [true, tv_e($msg)];
    } catch (InvalidArgumentException $e) {
        $_SESSION['ct_flash'] = [false, tv_e($e->getMessage())];
    }
    $toView = ($anchor ?? '') === '#coverage' ? 'coverage' : 'places';
    header('Location: ?view=' . $toView . '&hub=' . $hubId . ($jump ? '#c' . $jump : ($anchor ?? '#manage')), true, 303);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
            throw new RuntimeException('Your session expired. Reload the page and try again.');
        }
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'pop_census') {   // (a saved file comes through /api/upload.php, target census_file)
            if (!ZipPopulation::hasColumn($pdo)) {
                throw new RuntimeException('Run migrations/2026-09-28_zip_population.sql in phpMyAdmin first.');
            }
            $raw = ZipPopulation::fetch(ZipPopulation::url((string) ($_POST['census_key'] ?? '')));
            $population = ZipPopulation::parse($raw);
            $p = ZipPopulation::preview($pdo, $population);
            ZipPopulation::apply($pdo, $population, true);
            $notice = [true, 'Population loaded: ' . number_format(count($population)) . ' Census ZIP areas; '
                . number_format($p['matched']) . ' of your ' . number_format($p['zips']) . ' US ZIPs matched, '
                . number_format($p['missing']) . ' set to 0 (PO box / no residents).'];
        } elseif ($action === 'pp_import') {
            if (!PlaceProfile::tableExists($pdo)) {
                throw new RuntimeException('Run migrations/2026-09-28_place_profile.sql in phpMyAdmin first.');
            }
            $n = PlaceProfile::import($pdo);
            PageCache::forget($pdo, 'hub:profile');
            $notice = [true, 'Place profiles loaded: ' . number_format($n['zcta']) . ' ZIP areas, ' . number_format($n['county'])
                . ' counties, ' . number_format($n['state']) . ' states (Census ACS 2019–2023).'];
        } elseif ($action === 'recluster_apply') {
            if (empty($_POST['backup'])) throw new RuntimeException('Tick the backup box first.');
            $done = [];
            foreach ($pdo->query('SELECT id, name FROM geo_hubs ORDER BY sort_order, id')->fetchAll(PDO::FETCH_ASSOC) as $hub) {
                $clusters = CrawlerIngest::loadClusters($pdo, (int) $hub['id']);
                if (!array_filter($clusters, [ClusterRecluster::class, 'isLegacyStub'])) continue;
                $c = ClusterRecluster::apply($pdo, (int) $hub['id'], $clusters, ClusterRecluster::plan($clusters));
                $done[] = tv_e($hub['name']) . ": {$c['clusters_before']} auto-seeded clusters → {$c['clusters_after']}; moved "
                    . "{$c['entities']} listings, {$c['users']} user homes, {$c['cluster_overrides']} overrides, {$c['user_places']} saved places.";
            }
            $notice = [true, $done ? 'Merged. ' . implode(' ', $done) : 'Nothing to merge.'];
        }
    } catch (Throwable $e) {
        $notice = [false, tv_e($e->getMessage())];
    }
}

$hasPop = ZipPopulation::hasColumn($pdo);
$hasPp = PlaceProfile::tableExists($pdo);
$ppStats = $hasPp ? PlaceProfile::stats($pdo) : null;
$stats = $hasPop ? ZipPopulation::stats($pdo) : null;

tv_crawler_start($view, ['places' => 'Places', 'coverage' => 'Coverage', 'data' => 'Data loads'][$view], $pdo, [
    'places' => 'Geo-hubs, clusters, ZIPs and anchors. A ZIP joins the nearest cluster within ' . (int) CrawlerIngest::AUTO_SEED_RADIUS_MILES
        . ' miles that has at most ' . CrawlerIngest::AUTO_SEED_TOWN_CAP . ' towns and, where population is known, at most '
        . number_format(CrawlerIngest::AUTO_SEED_POPULATION_CEILING) . ' residents.',
    'coverage' => 'Where the directory has gaps, ordered by how many residents live with them. Queue them and the crawler goes looking.',
    'data' => 'Census data the place pages are built on. Loaded once, refreshed rarely.',
][$view]);
?>
<style>
  .ct-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;box-shadow:0 4px 6px -1px rgba(0,0,0,.08);padding:1rem;margin-top:1.25rem;max-width:56rem}
  .ct-btn{background:#D97706;color:#fff;font-weight:600;border-radius:.75rem;padding:.55rem 1.1rem}
  .ct-btn:hover{background:#B45309}
  .ct-btn2{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;font-weight:600;border-radius:.75rem;padding:.45rem .9rem}
  .ct-t{width:auto;min-width:60%;font-size:.85rem;border-collapse:collapse;margin-top:.35rem}
  .ct-t td{padding:.2rem 1.5rem .2rem 0;border-top:1px solid rgba(203,185,141,.45);vertical-align:top}
  .ct-grp{margin-top:1rem}
  .ct-grp h3{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700}
  .ct-grp small{color:#8A7355;font-weight:400}
  .ct-cl{border-top:1px solid rgba(203,185,141,.7);margin-top:1rem;padding-top:.8rem;scroll-margin-top:5rem}
  .ct-cl:target{background:#FFF7E0;border-radius:.6rem;padding:.8rem;box-shadow:0 0 0 2px #F59E0B}
  .ct-tag{font-size:.7rem;border:1px solid #CBB98D;border-radius:999px;padding:.05rem .5rem;color:#5C4632;background:#FFFBF2}
  .ct-warn{background:#FEF3C7;border-color:#FCD34D;color:#78350F}
  .ct-in{background:#FFFBF2;border:1px solid rgba(203,185,141,.8);border-radius:.5rem;padding:.3rem .5rem;font-size:.85rem;width:100%}
  .ct-sel{background:#FFFBF2;border:1px solid rgba(203,185,141,.8);border-radius:.5rem;padding:.25rem .4rem;font-size:.8rem;max-width:14rem}
  .ct-lbl{display:block;font-size:.7rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355;margin-bottom:.15rem}
  .ct-lnk{color:#B45309;text-decoration:underline;font-size:.8rem;cursor:pointer;background:none}
  .ct-acts{white-space:nowrap}
  .ct-gap{display:inline-block;min-width:1.4rem;text-align:center;background:#FEE2E2;color:#991B1B;border-radius:.4rem;font-weight:600}
  .ct-sgbar{display:flex;flex-wrap:wrap;gap:.5rem .8rem;align-items:center;font-size:.85rem;background:#FFFBF2;border:1px dashed #CBB98D;border-radius:.75rem;padding:.6rem .8rem;margin-top:.6rem}
  .ct-sg{margin-top:.6rem;font-size:.85rem}
  .ct-chip{display:inline-block;cursor:pointer;background:#ECFDF5;border:1px solid #6EE7B7;border-radius:999px;padding:.1rem .6rem;margin:.15rem .2rem;list-style:none}
  .ct-chip::-webkit-details-marker{display:none}
  .ct-sug{margin-top:.4rem;padding:.35rem .5rem;border-left:3px solid #FCD34D;background:rgba(254,243,199,.35)}
  .ct-sgform{display:flex;flex-wrap:wrap;gap:.3rem;margin:.3rem 0}
  .ct-sgform .ct-in{width:13rem}
  .ct-t td:nth-child(4){white-space:nowrap}
  .ct-acts form,.ct-inline{display:inline-block;margin-right:.6rem;vertical-align:top}
  .ct-t tr:hover td{background:rgba(255,251,242,.7)}
  /* Phones: each ZIP row wraps, its actions on a second line, so the page never scrolls sideways. */
  @media (max-width: 700px) {
    .ct-card{padding:.8rem}
    .ct-zips,.ct-zips tbody{display:block;min-width:0;width:100%}
    .ct-zips tr{display:flex;flex-wrap:wrap;gap:.1rem .9rem;padding:.45rem 0;border-top:1px solid rgba(203,185,141,.45)}
    .ct-zips td{border:0;padding:0}
    .ct-zips td.ct-acts{flex-basis:100%;white-space:normal}
    .ct-acts form,.ct-inline{margin:.2rem .6rem .2rem 0}
    .ct-sel{max-width:100%}
  }
  .ct-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch;max-width:100%}
  .ct-sum{cursor:pointer;list-style:none;position:relative;padding-left:1.2rem}
  .ct-sum::-webkit-details-marker{display:none}
  .ct-sum::before{content:'\25B8';position:absolute;left:0;top:.1rem;color:#B45309;transition:transform .15s}
  details[open]>.ct-sum::before{transform:rotate(90deg)}
  .ct-sec>.ct-sum h2{display:inline}
  .ct-sec.solo>.ct-sum{display:none}   /* a page with one section: the page title already names it */
  .ct-cl>.ct-sum::before{top:.35rem}
</style>


<?php if ($notice): ?>
  <div class="ct-card" style="background:<?= $notice[0] ? '#ECFDF5' : '#FEF2F2' ?>;border-color:<?= $notice[0] ? '#6EE7B7' : '#FCA5A5' ?>" role="status">
    <?= $notice[1] ?>
  </div>
<?php endif; ?>

<?php if ($view === 'data'): ?>
<p class="ct-card text-sm" style="margin-bottom:.8rem"><b>Search index:</b> what universal search looks through (Who, What, When, Where, Why). <a class="underline text-amber-700" href="/admin/search-index.php">Build or check it</a>.</p>
<details class="ct-card ct-sec" id="sec-pop">
  <summary class="ct-sum"><h2 class="font-serif font-bold text-lg">ZIP population</h2></summary>
  <?php if (!$hasPop): ?>
    <p class="text-sm mt-1">The <code>population</code> column doesn't exist yet. Run <code>app/migrations/2026-09-28_zip_population.sql</code> in phpMyAdmin, then reload.</p>
  <?php else: ?>
    <p class="text-sm mt-1">
      <?= number_format($stats['zips']) ?> ZIPs:
      <?= number_format($stats['with_population']) ?> with residents,
      <?= number_format($stats['zero']) ?> with none (PO box),
      <?= number_format($stats['null']) ?> not loaded.
      <?= $stats['null'] === $stats['zips'] ? '<strong>Load it before merging</strong> so the biggest town in each group becomes its anchor.' : '' ?>
    </p>
    <form method="post" class="mt-3" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='Loading… (up to a minute)'">
      <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>">
      <input type="hidden" name="action" value="pop_census">
      <?php if (!getenv('CENSUS_API_KEY')): ?>
        <label class="block text-sm mb-1" for="ct-key">Census API key <span class="text-[#8A7355]">(free: <a class="underline text-amber-700" href="https://api.census.gov/data/key_signup.html" target="_blank" rel="noopener">sign up</a>, it arrives by email; used for this request only, not saved)</span></label>
        <input id="ct-key" name="census_key" type="password" autocomplete="off" required class="mb-3" style="width:100%;max-width:28rem;background:#FFFBF2;border:1px solid rgba(203,185,141,.8);border-radius:.6rem;padding:.45rem .6rem">
      <?php endif; ?>
      <button class="ct-btn" type="submit"><?= $stats['null'] === $stats['zips'] ? 'Load from the Census' : 'Reload from the Census' ?></button>
    </form>
    <details class="mt-3 text-sm">
      <summary class="cursor-pointer text-[#8A7355]">If the server can't reach the Census</summary>
      <p class="mt-2">Open this address with <code>&amp;key=YOUR_KEY</code> added to the end:
        <code class="break-all"><?= tv_e(ZipPopulation::CENSUS_URL) ?></code> — save the page as a <code>.json</code> file, and upload it here.</p>
      <div class="mt-2 flex flex-wrap gap-2 items-center" id="ct-census">
        <input type="file" id="ct-census-file" accept=".json,application/json,text/plain">
        <button class="ct-btn2" type="button" id="ct-census-go">Upload and load</button>
      </div>
      <script>
      document.getElementById('ct-census-go').addEventListener('click', function () {   // the site's one uploader (decisions/0127)
        var i = document.getElementById('ct-census-file'), box = document.getElementById('ct-census');
        if (!i.files.length) { TvAsk.say('Choose the saved Census .json file first.', { anchor: this }); return; }
        TvUpload.send(i.files, { target: 'census_file', el: box, csrf: <?= json_encode($csrf) ?> }).then(function (r) { TvUpload.reloadHere(r[0].message, box); }, function () {});
      });
      </script>
    </details>
  <?php endif; ?>
</details>

<details class="ct-card ct-sec" id="sec-profiles">
  <summary class="ct-sum"><h2 class="font-serif font-bold text-lg">Place profiles (Census)</h2></summary>
  <p class="text-sm mt-1">Population, age, income, poverty, education, jobs and housing for every ZIP area, county and state,
    from the American Community Survey 2019–2023. The Discovery pages show these with the source cited.</p>
  <?php if (!$hasPp): ?>
    <p class="text-sm mt-2">Run <code>app/migrations/2026-09-28_place_profile.sql</code> in phpMyAdmin, then reload.</p>
  <?php else: ?>
    <p class="text-sm mt-2">
      <?= $ppStats['zcta'] ? number_format($ppStats['zcta']) . ' ZIP areas, ' . number_format($ppStats['county']) . ' counties, '
          . number_format($ppStats['state']) . ' states loaded ' . tv_e(substr((string) $ppStats['imported_at'], 0, 10)) . '.' : 'Not loaded yet.' ?>
    </p>
    <form method="post" class="mt-3" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='Loading… (a minute or two)'">
      <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>">
      <input type="hidden" name="action" value="pp_import">
      <button class="ct-btn" type="submit"><?= $ppStats['zcta'] ? 'Reload place profiles' : 'Load place profiles' ?></button>
    </form>
  <?php endif; ?>
</details>

<details class="ct-card ct-sec" id="sec-merge">
  <summary class="ct-sum"><h2 class="font-serif font-bold text-lg">Merge auto-seeded clusters (one-time, done)</h2></summary>
<?php
$totalStubs = 0;
foreach ($pdo->query('SELECT id, slug, name FROM geo_hubs ORDER BY sort_order, id')->fetchAll(PDO::FETCH_ASSOC) as $hub) {
    $clusters = CrawlerIngest::loadClusters($pdo, (int) $hub['id']);
    $stubs = count(array_filter($clusters, [ClusterRecluster::class, 'isLegacyStub']));
    if ($stubs === 0) continue;
    $totalStubs += $stubs;
    $plan = ClusterRecluster::plan($clusters);
    $slugs = ClusterRecluster::slugs($clusters, $plan);
    $newCount = count(array_filter($plan, fn ($g) => $g['target'] === null));
    echo '<h3 class="font-serif font-bold mt-4">' . tv_e($hub['name']) . " <small class=\"text-[#8A7355] font-normal\">— $stubs auto-seeded → $newCount</small></h3>";
    foreach ($plan as $i => $g) {
        $curated = $g['target'] !== null;
        $title = $curated ? tv_e($clusters[$g['target']]['name']) . ' <small>(existing) gains</small>'
                          : tv_e(PlaceScope::publicName(ClusterRecluster::groupName($g))) . ' <small>' . tv_e($slugs[$i]) . '</small>';
        $pop = 0;
        foreach ($g['members'] as $m) $pop = ($pop === null || $m['population'] === null) ? null : $pop + $m['population'];
        echo '<div class="ct-grp"><h3>' . $title . ' <small>· ' . ($pop === null ? 'population not loaded' : number_format($pop) . ' residents') . '</small></h3><table class="ct-t">';
        foreach ($curated ? $g['added'] : $g['members'] as $m) {
            $d = ($g['lat'] !== null && $m['lat'] !== null) ? CrawlerIngest::miles($g['lat'], $g['lon'], $m['lat'], $m['lon']) : null;
            echo '<tr><td>' . tv_e($m['zip']) . '</td><td>' . tv_e(trim((string) $m['city']) . ', ' . (string) $m['state']) . '</td><td>'
                . ($m['population'] === null ? '—' : number_format($m['population'])) . '</td><td>'
                . ($d === null ? 'no coordinates' : ($d < 0.05 ? 'anchor' : sprintf('%.1f mi', $d))) . '</td></tr>';
        }
        echo '</table></div>';
    }
}
?>
<?php if ($totalStubs === 0): ?>
  <p class="text-sm mt-1">Done — no one-ZIP stubs left to merge.</p>
<?php else: ?>
  <p class="text-sm mt-3">Preview from live data. Nothing changes until you press Apply.</p>
  <form method="post" class="mt-5 border-t border-[#CBB98D]/60 pt-4" data-confirm="Merge these clusters now? This moves listings and deletes the old one-ZIP clusters." data-yes="Merge">
    <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>">
    <input type="hidden" name="action" value="recluster_apply">
    <label class="flex items-start gap-2 text-sm"><input type="checkbox" name="backup" value="1" class="accent-amber-600 w-4 h-4 mt-0.5" required>
      I've exported a backup of micro_clusters, entities, cluster_overrides, users and user_places in phpMyAdmin.</label>
    <button class="ct-btn mt-3" type="submit">Apply merge</button>
  </form>
<?php endif; ?>
</details>
<?php endif; ?>
<?php ob_start(); /* Places; the Coverage page reuses what it computes */ ?>
<details class="ct-card ct-sec solo" id="manage" open>
  <summary class="ct-sum"><h2 class="font-serif font-bold text-lg">Manage clusters</h2></summary>
<?php
$clusters = ClusterAdmin::overview($pdo, $hubId);
$hasSg = Subgroups::tableExists($pdo);
$subgroups = $hasSg ? Subgroups::forHub($pdo, $hubId) : [];
$waiting = 0;
foreach ($subgroups as $list) foreach ($list as $sg) if ($sg['status'] === 'suggested') $waiting++;
$hubName = '';
foreach ($geoHubs as $g) if ((int) $g['id'] === $hubId) $hubName = (string) $g['name'];

// ZIPs whose coordinates are a placeholder shared with a different town (the Red Valley problem).
$memberZips = [];
foreach ($clusters as $c) foreach ($c['members'] as $m) $memberZips[] = $m['zip'];
$suspect = [];
if ($memberZips) {
    $in = implode(',', array_fill(0, count($memberZips), '?'));
    $st = $pdo->prepare("SELECT DISTINCT z.zip FROM zip_coordinates z JOIN zip_coordinates o
                          ON o.latitude = z.latitude AND o.longitude = z.longitude AND o.city <> z.city
                         WHERE z.zip IN ($in)");
    $st->execute($memberZips);
    $suspect = array_flip($st->fetchAll(PDO::FETCH_COLUMN));
}

$sumListings = array_sum(array_column($clusters, 'listings'));
$needReview = count(array_filter($clusters, fn ($c) => $c['needs_review']));
$hidden = fn (string $action, int $cluster, string $zip = '') => '<input type="hidden" name="csrf" value="' . tv_e($csrf) . '"><input type="hidden" name="hub" value="' . $hubId
    . '"><input type="hidden" name="action" value="' . $action . '"><input type="hidden" name="cluster" value="' . $cluster . '">'
    . ($zip !== '' ? '<input type="hidden" name="zip" value="' . tv_e($zip) . '">' : '');
?>
  <form method="get" class="flex flex-wrap items-center gap-2 mt-2 text-sm">
    <label for="ct-hub">Geo-hub</label>
    <input type="hidden" name="view" value="places">
    <select id="ct-hub" name="hub" class="ct-sel" onchange="this.form.submit()">
      <?php foreach ($geoHubs as $g): ?>
        <option value="<?= (int) $g['id'] ?>" <?= (int) $g['id'] === $hubId ? 'selected' : '' ?>><?= tv_e($g['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <noscript><button class="ct-btn2" type="submit">Show</button></noscript>
  </form>
  <p class="text-sm mt-2">
    <?= count($clusters) ?> clusters, <?= count($memberZips) ?> ZIPs, <?= number_format($sumListings) ?> listings in <?= tv_e($hubName) ?>.
    <?php if ($needReview): ?>
      <?= $needReview ?> still marked "needs review".
      <form method="post" class="ct-inline" data-confirm="Mark all <?= $needReview ?> clusters in <?= tv_e($hubName) ?> as reviewed? Their names stay as they are, without the auto-seeded note." data-yes="Mark reviewed">
        <?= $hidden('c_reviewed_all', 0) ?><button class="ct-lnk" type="submit">Mark all reviewed</button>
      </form>
    <?php endif; ?>
    Every move takes that ZIP's listings and user homes with it.
    <br><button type="button" class="ct-lnk" data-ct-all="1">Expand all clusters</button> ·
    <button type="button" class="ct-lnk" data-ct-all="0">Collapse all clusters</button>
  </p>
  <div class="ct-sgbar">
    <?php if (!$hasSg): ?>
      <strong>Sub-groups:</strong> run <code>app/migrations/2026-09-28_cluster_subgroups.sql</code> in phpMyAdmin to turn them on.
    <?php else: ?>
      <form method="post" class="ct-inline"><?= $hidden('c_sg_scan', 0) ?><button class="ct-btn2" type="submit">Scan listings for local names</button></form>
      <span>Sub-groups are local names people use for part of a cluster — a ranch area, subdivision or neighborhood.
        The scan suggests names used at <?= Subgroups::MIN_MENTIONS ?>+ different addresses (<?= Subgroups::MIN_STREET_MENTIONS ?>+ if only as a road name); nothing is public until you accept it.
        <?= $waiting ? "<strong>$waiting suggestion" . ($waiting === 1 ? '' : 's') . ' waiting.</strong>' : '' ?></span>
    <?php endif; ?>
  </div>

<?php foreach ($clusters as $id => $c):
    $towns = [];
    $pop = 0;
    foreach ($c['members'] as $m) {
        $towns[strtolower((string) $m['city']) . '|' . $m['state']] = true;
        $pop = ($pop === null || $m['population'] === null) ? null : $pop + $m['population'];
    }
    // other clusters, nearest first, as move/merge targets
    $others = [];
    foreach ($clusters as $oid => $o) {
        if ($oid === $id) continue;
        $d = ($c['lat'] !== null && $o['lat'] !== null) ? CrawlerIngest::miles($c['lat'], $c['lon'], $o['lat'], $o['lon']) : null;
        $others[$oid] = [ClusterAdmin::displayName($o['name']), $d];
    }
    uasort($others, fn ($a, $b) => ($a[1] ?? INF) <=> ($b[1] ?? INF));
    $options = '';
    foreach ($others as $oid => [$oname, $d]) {
        $options .= '<option value="' . $oid . '">' . tv_e($oname) . ($d === null ? '' : sprintf(' (%.0f mi)', $d)) . '</option>';
    }
?>
  <details class="ct-cl" id="c<?= $id ?>">
    <summary class="ct-sum">
    <div class="flex flex-wrap items-baseline gap-x-2">
      <h3 class="font-serif font-bold text-lg"><?= tv_e(ClusterAdmin::displayName($c['name'])) ?></h3>
      <?php if ($c['needs_review']): ?><span class="ct-tag ct-warn">auto-seeded, needs review</span>
        <form method="post" class="ct-inline"><?= $hidden('c_reviewed', $id) ?><button class="ct-lnk" type="submit">Mark reviewed</button></form><?php endif; ?>
      <?php if ($c['source'] !== 'automated_seed'): ?><span class="ct-tag"><?= tv_e($c['source']) ?></span><?php endif; ?>
      <small class="text-[#8A7355]"><?= tv_e($c['slug']) ?> · #<?= $id ?></small>
    </div>
    <p class="text-xs text-[#8A7355] mt-0.5">
      <?= count($towns) ?> town<?= count($towns) === 1 ? '' : 's' ?> ·
      <?= $pop === null ? 'population not loaded' : number_format($pop) . ' residents' ?> ·
      <?= $c['listings'] ?> listing<?= $c['listings'] === 1 ? '' : 's' ?> ·
      <?= $c['homes'] ?> user home<?= $c['homes'] === 1 ? '' : 's' ?>
      <?php if (count($towns) > CrawlerIngest::AUTO_SEED_TOWN_CAP || ($pop !== null && $pop > CrawlerIngest::AUTO_SEED_POPULATION_CEILING)): ?>
        · <span class="text-amber-800">over the automatic limits (fine if intentional)</span>
      <?php endif; ?>
    </p>
    </summary>
    <table class="ct-t ct-zips">
      <?php foreach ($c['members'] as $m):
          $isAnchor = $m['zip'] === $c['primary_zip'];
          $d = ($c['lat'] !== null && $m['lat'] !== null) ? CrawlerIngest::miles($c['lat'], $c['lon'], $m['lat'], $m['lon']) : null; ?>
        <tr>
          <td><?= tv_e($m['zip']) ?></td>
          <td><?= tv_e(trim((string) $m['city']) . ', ' . (string) $m['state']) ?>
            <?php if (isset($suspect[$m['zip']])): ?><br><span class="text-xs text-red-700">shares its coordinates with another town — check them</span><?php endif; ?></td>
          <td><?= $m['population'] === null ? '—' : number_format($m['population']) ?></td>
          <td><?= $isAnchor ? '<strong>anchor</strong>' : ($d === null ? 'no coordinates' : sprintf('%.1f mi', $d)) ?></td>
          <td class="ct-acts">
            <?php if (!$isAnchor): ?>
              <form method="post"><?= $hidden('c_anchor', $id, $m['zip']) ?><button class="ct-lnk" type="submit">Make anchor</button></form>
            <?php endif; ?>
            <?php if (!$isAnchor || count($c['members']) === 1): ?>
              <form method="post" class="ct-inline" data-yes="Move" data-confirm="Move <?= tv_e($m['zip']) ?> and its listings?">
                <?= $hidden('c_movezip', $id, $m['zip']) ?>
                <select name="to" class="ct-sel" required>
                  <option value="">Move to…</option>
                  <?php if (count($c['members']) > 1): ?><option value="new">A new cluster (<?= tv_e((string) $m['city']) ?>)</option><?php endif; ?>
                  <?= $options ?>
                </select>
                <button class="ct-lnk" type="submit">Move</button>
              </form>
            <?php endif; ?>
            <details class="ct-inline"><summary class="ct-lnk">Coordinates</summary>
              <form method="post" class="mt-1"><?= $hidden('c_coords', $id, $m['zip']) ?>
                <input name="coords" class="ct-in" style="width:13rem" placeholder="lat, lon from Google Maps"
                       value="<?= $m['lat'] === null ? '' : tv_e(sprintf('%.4f, %.4f', $m['lat'], $m['lon'])) ?>">
                <button class="ct-lnk" type="submit">Save</button>
              </form>
            </details>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
    <?php if ($hasSg):
        $sgs = $subgroups[$id] ?? [];
        $acc = array_filter($sgs, fn ($s) => $s['status'] === 'accepted');
        $sug = array_filter($sgs, fn ($s) => $s['status'] === 'suggested'); ?>
      <div class="ct-sg">
        <span class="ct-lbl" style="display:inline">Sub-groups</span>
        <?php if (!$acc): ?><span class="text-xs text-[#8A7355]">none yet</span><?php endif; ?>
        <?php foreach ($acc as $s): ?>
          <details class="ct-inline"><summary class="ct-chip"><?= tv_e($s['name']) ?><?= $s['aliases'] ? ' <small>(' . tv_e(implode(', ', $s['aliases'])) . ')</small>' : '' ?></summary>
            <form method="post" class="ct-sgform"><?= $hidden('c_sg_edit', $id) ?><input type="hidden" name="sg" value="<?= (int) $s['id'] ?>">
              <input name="name" class="ct-in" value="<?= tv_e($s['name']) ?>" required>
              <input name="aliases" class="ct-in" value="<?= tv_e(implode(', ', $s['aliases'])) ?>" placeholder="other names, comma-separated">
              <button class="ct-lnk" type="submit">Save</button>
            </form>
            <form method="post" class="ct-inline" data-yes="Remove" data-danger data-confirm="Remove <?= tv_e($s['name']) ?>? Scans won't suggest it again."><?= $hidden('c_sg_reject', $id) ?><input type="hidden" name="sg" value="<?= (int) $s['id'] ?>"><button class="ct-lnk" type="submit">Remove</button></form>
          </details>
        <?php endforeach; ?>
        <?php foreach ($sug as $s): ?>
          <div class="ct-sug">
            <form method="post" class="ct-inline"><?= $hidden('c_sg_accept', $id) ?><input type="hidden" name="sg" value="<?= (int) $s['id'] ?>">
              <span class="ct-tag ct-warn">suggested · <?= (int) $s['mentions'] ?> listings</span>
              <input name="name" class="ct-in" style="width:13rem" value="<?= tv_e($s['name']) ?>" required>
              <input name="aliases" class="ct-in" style="width:13rem" placeholder="other names (optional)">
              <button class="ct-lnk" type="submit">Accept</button>
            </form>
            <form method="post" class="ct-inline"><?= $hidden('c_sg_reject', $id) ?><input type="hidden" name="sg" value="<?= (int) $s['id'] ?>"><button class="ct-lnk" type="submit">Reject</button></form>
            <?php foreach ($s['examples'] as $ex): ?>
              <div class="text-xs text-[#8A7355] ml-2">“<?= tv_e(mb_strimwidth((string) $ex['text'], 0, 140, '…')) ?>”</div>
            <?php endforeach; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <details class="mt-2 text-sm"><summary class="ct-lnk">Edit cluster</summary>
      <div class="grid gap-2 mt-2" style="grid-template-columns:repeat(auto-fit,minmax(15rem,1fr))">
        <form method="post"><?= $hidden('c_rename', $id) ?>
          <label class="ct-lbl">Name</label>
          <input name="name" class="ct-in" value="<?= tv_e(ClusterAdmin::displayName($c['name'])) ?>" required maxlength="120">
          <button class="ct-btn2 mt-1" type="submit">Rename</button>
        </form>
        <form method="post"><?= $hidden('c_addzip', $id) ?>
          <label class="ct-lbl">Add a ZIP no cluster has yet</label>
          <input name="zip" class="ct-in" inputmode="numeric" pattern="\d{5}" placeholder="85936" required>
          <button class="ct-btn2 mt-1" type="submit">Add</button>
        </form>
        <?php if ($hasSg): ?>
        <form method="post"><?= $hidden('c_sg_add', $id) ?>
          <label class="ct-lbl">Add a sub-group</label>
          <input name="name" class="ct-in" placeholder="Red Sky Ranch" required maxlength="120">
          <input name="aliases" class="ct-in mt-1" placeholder="other names, comma-separated (optional)">
          <button class="ct-btn2 mt-1" type="submit">Add</button>
        </form>
        <?php endif; ?>
        <form method="post"><?= $hidden('c_geohub', $id) ?>
          <label class="ct-lbl">Geo-hub</label>
          <select name="geo_hub" class="ct-sel" style="width:100%">
            <?php foreach ($geoHubs as $g): ?><option value="<?= (int) $g['id'] ?>" <?= (int) $g['id'] === $hubId ? 'selected' : '' ?>><?= tv_e($g['name']) ?></option><?php endforeach; ?>
          </select>
          <button class="ct-btn2 mt-1" type="submit">Move cluster</button>
        </form>
        <?php if ($options !== ''): ?>
        <form method="post" data-yes="Merge" data-danger data-confirm="Merge <?= tv_e(ClusterAdmin::displayName($c['name'])) ?> into the chosen cluster? All its ZIPs, listings and users move there and this cluster is deleted.">
          <?= $hidden('c_merge', $id) ?>
          <label class="ct-lbl">Merge this whole cluster into</label>
          <select name="into" class="ct-sel" style="width:100%" required><option value="">Choose…</option><?= $options ?></select>
          <button class="ct-btn2 mt-1" type="submit">Merge</button>
        </form>
        <?php endif; ?>
      </div>
    </details>
  </details>
<?php endforeach; ?>
<?php if ($clusters === []): ?>
  <p class="text-sm mt-3">No clusters in this geo-hub yet.</p>
<?php endif; ?>
</details>
<?php $manageHtml = ob_get_clean(); if ($view === 'places') echo $manageHtml; ?>
<?php if ($view === 'coverage'): ?>
<form method="get" class="flex flex-wrap items-center gap-2 mt-3 text-sm">
  <input type="hidden" name="view" value="coverage">
  <label for="ct-hub-cov">Geo-hub</label>
  <select id="ct-hub-cov" name="hub" class="ct-sel" onchange="this.form.submit()">
    <?php foreach ($geoHubs as $g): ?><option value="<?= (int) $g['id'] ?>" <?= (int) $g['id'] === $hubId ? 'selected' : '' ?>><?= tv_e($g['name']) ?></option><?php endforeach; ?>
  </select>
  <noscript><button class="ct-btn2" type="submit">Show</button></noscript>
</form>
<details class="ct-card ct-sec solo" id="coverage" open>
  <summary class="ct-sum"><h2 class="font-serif font-bold text-lg">Directory coverage</h2></summary>
  <p class="text-sm mt-1">Public listings per Support &amp; wellness group in each cluster of <?= tv_e($hubName) ?>, ordered by how many residents live with the gaps.
    These gaps are what the crawler goes looking for (ADR 0044).</p>
  <?php if (!CrawlQueue::tableExists($pdo)): ?>
    <p class="text-sm mt-2">To queue gaps for the crawler, run <code>app/migrations/2026-09-29_crawl_jobs_and_page_cache.sql</code> in phpMyAdmin.</p>
  <?php else: $q = CrawlQueue::stats($pdo); ?>
    <div class="ct-sgbar">
      <form method="post" class="ct-inline" style="margin-right:.6rem"><?= $hidden('c_queue', 0) ?><button id="coverage-q" class="ct-btn2" type="submit">Queue these gaps for the crawler</button></form>
      <span>Crawl queue: <?= $q['queued'] ?> waiting, <?= $q['leased'] ?> in progress, <?= $q['done'] ?> done, <?= $q['failed'] ?> failed<?= CrawlQueue::paused() ? ' · <strong>paused</strong> (CRAWL_QUEUE=off)' : '' ?>.
        The off-site worker takes up to 5 every 5 minutes; what it publishes appears in <a class="ct-lnk" href="/admin/auto-imports.php">Published</a>, and the rest waits in <a class="ct-lnk" href="/admin/crawler-review.php">Review</a>.</span>
      <?php if (!empty($_SESSION['ct_queue_msg'])): ?><span data-tv-status="ok"><?= tv_e((string) $_SESSION['ct_queue_msg']) ?></span><?php endif; unset($_SESSION['ct_queue_msg']); ?>
    </div>
<?php
    // Worker connection check: what the site sees of CRAWLER_API_TOKEN, without ever showing it.
    $authFile = __DIR__ . '/../api/crawl/_auth.php';
    $authNew = is_file($authFile) && str_contains((string) file_get_contents($authFile), 'connect before looking for the token');
    if ($authNew && function_exists('opcache_invalidate')) @opcache_invalidate($authFile, true); // drop a stale cached copy
    $seen = getenv('CRAWLER_API_TOKEN');
    $envPath = dirname((string) realpath(__DIR__ . '/../api'), 4) . '/.env';
    $envText = is_readable($envPath) ? (string) file_get_contents($envPath) : null;
    $lines = $envText === null ? [] : preg_grep('/CRAWLER_API_TOKEN/', preg_split('/\R/', ltrim($envText, "\xEF\xBB\xBF")));
    $active = array_filter($lines, fn ($l) => preg_match('/^\s*CRAWLER_API_TOKEN\s*=\s*\S/', $l));
    $commented = array_filter($lines, fn ($l) => preg_match('/^\s*#/', $l));
    $problems = [];
    if (!$authNew) $problems[] = '<code>api/crawl/_auth.php</code> on the server is the old version. Upload it from the latest zip into <code>website/api/crawl/</code>.';
    if ($envText === null) $problems[] = 'The site can\'t read its <code>.env</code> file.';
    elseif (!$lines) $problems[] = 'No <code>CRAWLER_API_TOKEN</code> line in the <code>.env</code> the site reads (the one with <code>CENSUS_API_KEY</code>).';
    elseif (!$active) $problems[] = 'The <code>CRAWLER_API_TOKEN</code> line in <code>.env</code> is ' . ($commented ? 'commented out (starts with <code>#</code>)' : 'empty or badly formed') . '. It should read <code>CRAWLER_API_TOKEN=yourtoken</code>.';
    elseif (count($active) > 1) $problems[] = '<code>CRAWLER_API_TOKEN</code> appears ' . count($active) . ' times in <code>.env</code>; only the first counts. Keep one.';
    if ($active && ($seen === false || $seen === '')) $problems[] = 'The <code>.env</code> line looks right but the site isn\'t getting it: a server setting (cPanel or <code>.htaccess</code>) may define <code>CRAWLER_API_TOKEN</code> as empty first.';
?>
    <p class="text-sm mt-2">Worker connection:
      <?php if (!$problems): ?>
        <span class="text-green-800">ready. The site sees a <?= strlen((string) $seen) ?>-character token; Railway's <code>CRAWLER_API_TOKEN</code> must be the same.</span>
      <?php else: ?>
        <span class="text-red-800"><?= implode(' ', $problems) ?></span>
      <?php endif; ?>
    </p>
  <?php endif; ?>
<?php
$cov = SupportGroups::countsByCluster($pdo, array_keys($clusters));
$groups = array_keys(SupportGroups::GROUPS);
$rowsC = [];
foreach ($clusters as $id => $c) {
    $pop = 0;
    foreach ($c['members'] as $m) $pop += (int) ($m['population'] ?? 0);
    $counts = [];
    $gaps = 0;
    foreach ($groups as $g) { $counts[$g] = $cov[$id][$g] ?? 0; if ($counts[$g] === 0) $gaps++; }
    $rowsC[] = ['id' => $id, 'name' => ClusterAdmin::displayName($c['name']), 'pop' => $pop, 'counts' => $counts, 'gaps' => $gaps];
}
usort($rowsC, fn ($a, $b) => $b['gaps'] * max(1, $b['pop']) <=> $a['gaps'] * max(1, $a['pop']) ?: $b['gaps'] <=> $a['gaps']);   // residents living with each gap
$tot = array_fill_keys($groups, 0);
foreach ($rowsC as $r) foreach ($groups as $g) $tot[$g] += $r['counts'][$g];
?>
  <div class="ct-scroll mt-3">
    <table class="ct-t" style="min-width:100%">
      <tr class="text-xs uppercase tracking-wide text-[#8A7355]"><td>Cluster</td><td>Residents</td>
        <?php foreach ($groups as $g): ?><td><?= tv_e($g) ?></td><?php endforeach; ?><td>Gaps</td></tr>
      <?php foreach ($rowsC as $r): ?>
      <tr><td><a class="ct-lnk" href="?view=places&amp;hub=<?= $hubId ?>#c<?= $r['id'] ?>"><?= tv_e($r['name']) ?></a></td>
        <td><?= number_format($r['pop']) ?></td>
        <?php foreach ($groups as $g): $n = $r['counts'][$g]; ?>
          <td><?= $n === 0 ? '<span class="ct-gap">0</span>' : $n ?></td>
        <?php endforeach; ?>
        <td><?= $r['gaps'] ?: '—' ?></td></tr>
      <?php endforeach; ?>
      <tr class="font-semibold"><td>All clusters</td><td><?= number_format(array_sum(array_column($rowsC, 'pop'))) ?></td>
        <?php foreach ($groups as $g): ?><td><?= $tot[$g] ?></td><?php endforeach; ?><td></td></tr>
    </table>
  </div>
</details>
<?php endif; ?>
<script>
// Collapsible sections and clusters: remember what was open (per browser), and open whatever a link or
// a post-action redirect points at (#c12, #manage) along with the section around it.
(function () {
  var KEY = 'ct-open', all = document.querySelectorAll('details.ct-sec, details.ct-cl'), saved = null;
  try { saved = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) {}
  if (saved) all.forEach(function (d) { if (d.id in saved) d.open = saved[d.id]; });
  function save() {
    var o = {};
    all.forEach(function (d) { o[d.id] = d.open; });
    try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {}
  }
  function reveal() {
    var t = location.hash && document.getElementById(location.hash.slice(1));
    for (var d = t; d; d = d.parentElement) if (d.tagName === 'DETAILS') d.open = true;
    if (t) t.scrollIntoView();
  }
  all.forEach(function (d) { d.addEventListener('toggle', save); });
  document.querySelectorAll('[data-ct-all]').forEach(function (b) {
    b.addEventListener('click', function () {
      var open = b.dataset.ctAll === '1';
      document.querySelectorAll('details.ct-cl').forEach(function (d) { d.open = open; });
    });
  });
  window.addEventListener('hashchange', reveal);
  reveal();
})();
</script>
<?php tv_crawler_end();
