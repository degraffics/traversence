<?php
// admin/suggestion.php?id=N — Review's one-step decisions on what a visitor sent (decisions/0072):
//   Suggested fix    each field as it is and as they sent it; tick what to change, Apply
//   Same business    both listings side by side; pick the one to keep, tick what to bring over, Merge
//   Something missing (outdoors)  the place's form, filled in from what they sent; Create the place
// Each marks the suggestion used and thanks a signed-in visitor by email. Admin-only; POSTs carry the CSRF token.

declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/SuggestionActions.php';
require_once __DIR__ . '/../../app/lib/Landmarks.php';
require_once __DIR__ . '/../../app/lib/Journeys.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$uid = (int) $me['id'];
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$sid = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$s = SuggestionActions::get($pdo, $sid);
$back = '/admin/crawler-review.php?type=suggest';
$what = $s ? ['fix' => 'fix', 'same' => 'same', 'missing' => $s['topic'] === 'outdoors' ? 'place' : ''][$s['kind']] ?? '' : '';
$form = $_POST;

if ($s && $what !== '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        if ($what === 'fix') {
            $vals = [];
            foreach ((array) ($_POST['use'] ?? []) as $k) $vals[(string) $k] = (string) ($_POST['v'][$k] ?? '');
            $done = SuggestionActions::apply($pdo, $sid, $vals, $uid);
            tv_crawler_flash([true, 'Updated: ' . implode(', ', $done) . '.' . ($s['user_id'] ? ' The visitor has been thanked.' : '')]);
        } elseif ($what === 'same') {
            $r = SuggestionActions::merge($pdo, $sid, (int) ($_POST['keep'] ?? 0), (array) ($_POST['fill'] ?? []), $uid);
            tv_crawler_flash([true, 'Merged: ' . $r['kept']['name'] . ' is kept' . ($r['copied'] ? ' (brought over: ' . implode(', ', $r['copied']) . ')' : '') . '; the other is hidden and its link goes here.']);
        } else {
            $r = SuggestionActions::createPlace($pdo, $sid, $_POST, $uid, Journeys::staffCan($pdo, $uid, 'publish'));
            tv_crawler_flash([true, $r['shown'] ? 'Created and live.' : 'Created. It\'s held: the name may mark a sensitive site, or it waits for an Editor (Admin → Landmarks).']);
        }
        header('Location: ' . $back . '&done=' . $sid, true, 303);   // Review shows what's true now
        exit;
    } catch (InvalidArgumentException $x) {
        tv_crawler_flash([false, $x->getMessage()]);
    }
}

$title = ['fix' => 'Apply a fix', 'same' => 'Merge a listing shown twice', 'place' => 'Create the place'][$what] ?? 'Suggestion';
tv_crawler_start('review', $title, $pdo, 'From a visitor. Check it, then one tap makes the change, marks it used and thanks them. <a class="underline text-amber-800" href="' . $back . '">Back to Review</a>');
$fail = function (string $m) { echo '<p class="text-sm mt-3">' . $m . '</p>'; tv_crawler_end(); exit; };
if (!$s) $fail('That suggestion is gone.');
if ($s['status'] !== 'new') $fail('This suggestion was already handled.');
if ($what === '') $fail('There\'s no one-step action for this kind yet. Use Review\'s buttons.');
$e = 'tv_e';
?>
<style>
  .sg{max-width:46rem;margin-top:.8rem}
  .sg-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .9rem;margin-top:.6rem}
  .sg-card h2{font:700 1rem var(--tv-font-head,Georgia,serif);margin:0 0 .35rem}
  .sg-row{display:grid;grid-template-columns:1.6rem 1fr;gap:.2rem .5rem;padding:.55rem 0;border-top:1px solid #EADFC4}.sg-row:first-of-type{border-top:0}
  .sg-k{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#8A7355}
  .sg-now{font-size:.85rem;color:#8A7355;text-decoration:line-through;overflow-wrap:anywhere}.sg-now.none{text-decoration:none;font-style:italic}
  .sg-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.55rem;padding:.4rem .6rem;font-size:.9rem;margin-top:.2rem}
  .sg-note{font-size:.78rem;color:#92400E;margin-top:.2rem}
  .sg-b{font-size:.9rem;font-weight:700;border:1px solid #15803D;background:#15803D;color:#fff;border-radius:.6rem;padding:.55rem 1.1rem;cursor:pointer}
  .sg-two{display:grid;grid-template-columns:1fr 1fr;gap:.5rem}
  .sg-pick{display:block;border:1px solid #CBB98D;border-radius:.7rem;padding:.6rem .7rem;background:#FFFBF2;cursor:pointer;font-size:.85rem}
  .sg-pick:has(input:checked){border-color:#8FBCA8;box-shadow:0 0 0 2px rgba(143,188,168,.5)}
  .sg-pick dl{display:grid;grid-template-columns:max-content 1fr;gap:.1rem .5rem;margin:.35rem 0 0}.sg-pick dt{color:#8A7355}.sg-pick dd{margin:0;overflow-wrap:anywhere}
  .sg-pick a{color:#92400E;text-decoration:underline;font-weight:700}
  .sg-said{font-size:.85rem}
  label.sg-l{display:block;font-size:.8rem;font-weight:600;margin:.55rem 0 .15rem}
  @media (max-width:767px){.sg-two{grid-template-columns:1fr;gap:3px}}
</style>
<div class="sg">
  <div class="sg-card tv-bleed sg-said"><b><?= $s['user_id'] ? 'A signed-in member' : 'A guest' ?></b> · <?= $e(date('M j, g:i a', strtotime((string) $s['created_at']))) ?>
    <?php if (trim((string) $s['note']) !== ''): ?><br>“<?= $e((string) $s['note']) ?>”<?php endif; ?>
    <?php if (!$s['user_id']): ?><br><span class="text-[#8A7355]">Guests leave no address, so there's no one to thank by email.</span><?php endif; ?></div>

<?php if ($what === 'fix'):
    try { $rows = SuggestionActions::diff($pdo, $s); } catch (InvalidArgumentException $x) { $fail($e($x->getMessage())); }
    if (!$rows) $fail('They didn\'t send a name, phone, website, address or hours to change. <a class="underline" href="/admin/listing-edit.php?id=' . (int) $s['entity_id'] . '">Open the editor</a> to act on their note.'); ?>
  <form method="post" class="sg-card tv-bleed">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= $sid ?>">
    <h2><a class="underline text-[#92400E]" href="/listing/view.php?id=<?= (int) $s['entity_id'] ?>" target="_blank"><?= $e((string) ($s['target_name'] ?: 'The listing')) ?></a></h2>
    <?php foreach ($rows as $r): $k = $r['field']; ?>
    <div class="sg-row">
      <input type="checkbox" name="use[]" value="<?= $e($k) ?>" aria-label="Change the <?= $e(strtolower($r['label'])) ?>"<?= !$r['same'] && !$r['owner'] ? ' checked' : '' ?><?= $r['owner'] ? ' disabled' : '' ?>>
      <div><span class="sg-k"><?= $e($r['label']) ?></span>
        <div class="sg-now<?= $r['now'] === '' ? ' none' : '' ?>"><?= $r['now'] !== '' ? $e($r['now']) : 'nothing yet' ?></div>
        <input class="sg-in" name="v[<?= $e($k) ?>]" value="<?= $e((string) ($form['v'][$k] ?? $r['sent'])) ?>" maxlength="<?= $k === 'hours' ? 600 : 300 ?>">
        <?php if ($r['owner']): ?><p class="sg-note">Set by the listing's owner: change it in the editor if you're sure.</p>
        <?php elseif ($r['same']): ?><p class="sg-note">Already the same.</p><?php endif; ?></div>
    </div>
    <?php endforeach; ?>
    <p class="text-xs text-[#8A7355] mt-2">You can correct what they sent before applying. Hours: one line per day or range.</p>
    <div class="mt-3 flex gap-2 flex-wrap items-center"><button class="sg-b" type="submit">Apply the fix</button>
      <a class="underline text-sm" href="/admin/listing-edit.php?id=<?= (int) $s['entity_id'] ?>">Open the full editor</a></div>
  </form>

<?php elseif ($what === 'same'):
    try { [$a, $b] = SuggestionActions::pair($pdo, $s); } catch (InvalidArgumentException $x) { $fail($e($x->getMessage())); }
    $keep = (int) ($form['keep'] ?? $a['id']);
    $show = function (array $l) use ($e) {
        $m = fn ($k) => is_array($l['meta'][$k]['value'] ?? null) ? implode('; ', $l['meta'][$k]['value']) : (string) ($l['meta'][$k]['value'] ?? '');
        $rows = array_filter(['Town' => trim($m('city') . ', ' . $m('state'), ', '), 'Phone' => $m('phone'), 'Address' => $m('address'), 'Website' => $m('website'),
                              'Hours' => $m('hours'), 'Category' => (string) ($l['category_name'] ?? ''), 'Added' => date('M j, Y', strtotime((string) $l['created_at']))]);
        $h = '<a href="/listing/view.php?id=' . $l['id'] . '" target="_blank">' . $e($l['name']) . '</a> <span class="text-[#8A7355]">#' . $l['id'] . '</span>'
           . (SuggestionActions::managed($l) ? ' <span class="text-xs font-bold text-[#92400E]">Managed by owner</span>' : '') . ((int) $l['is_suppressed'] ? ' <span class="text-xs text-red-800">hidden</span>' : '') . '<dl>';
        foreach ($rows as $k => $v) $h .= '<dt>' . $e($k) . '</dt><dd>' . $e(mb_strimwidth($v, 0, 90, '…')) . '</dd>';
        return $h . '</dl>';
    }; ?>
  <form method="post" class="sg-card tv-bleed">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= $sid ?>">
    <h2>Which one stays?</h2>
    <div class="sg-two">
      <?php foreach ([$a, $b] as $l): ?>
      <label class="sg-pick"><input type="radio" name="keep" value="<?= $l['id'] ?>"<?= $keep === $l['id'] ? ' checked' : '' ?><?= SuggestionActions::managed($a) && $l['id'] !== $a['id'] ? ' disabled' : '' ?>> Keep this one<br><?= $show($l) ?></label>
      <?php endforeach; ?>
    </div>
    <?php if (SuggestionActions::managed($a)): ?><p class="sg-note"><?= $e($a['name']) ?> is managed by its owner, so it stays.</p><?php endif; ?>
    <h2 class="mt-3">Bring over from the other one, where the kept one has nothing</h2>
    <div class="flex flex-wrap gap-x-4 gap-y-1 text-sm">
      <?php foreach (SuggestionActions::FILL as $k => $label): ?><label><input type="checkbox" name="fill[]" value="<?= $e($k) ?>" checked> <?= $e($label) ?></label><?php endforeach; ?>
    </div>
    <p class="text-xs text-[#8A7355] mt-2">The other listing is hidden, not deleted: its link opens the kept one, and anything waiting about it moves over.</p>
    <div class="mt-3"><button class="sg-b" type="submit">Merge these</button></div>
  </form>

<?php else:
    $f = $s['fields'];
    $v = fn (string $k, string $d = '') => $e((string) ($form[$k] ?? $d));
    $state = (string) ($form['state'] ?? 'AZ'); $kind = (string) ($form['kind'] ?? '');
    $name = (string) ($f['name'] ?? $s['target_name'] ?? ''); ?>
  <form method="post" class="sg-card tv-bleed">
    <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= $sid ?>">
    <h2>The place</h2>
    <?php if ($f): ?><p class="text-sm"><?php foreach ($f as $k => $x): ?><span class="text-[#8A7355]"><?= $e(Suggestions::FIELDS[$k] ?? $k) ?>:</span> <?= $e((string) $x) ?><br><?php endforeach; ?></p><?php endif; ?>
    <label class="sg-l">Name</label><input class="sg-in" name="name" required maxlength="200" value="<?= $v('name', $name) ?>">
    <label class="sg-l">What kind of place</label><select class="sg-in" name="kind" required><option value="">Choose…</option>
      <?php foreach (Landmarks::ADD_KINDS as $k => $label): ?><option value="<?= $e($k) ?>"<?= $kind === $k ? ' selected' : '' ?>><?= $e($label) ?></option><?php endforeach; ?></select>
    <label class="sg-l">Map point (latitude, longitude)</label><input class="sg-in" name="point" required maxlength="40" value="<?= $v('point', (string) ($f['point'] ?? '')) ?>" placeholder="34.505, -109.36">
    <p class="text-xs text-[#8A7355]"><?= !empty($f['point']) ? 'Their pin is filled in: check it on the map first.' : 'No pin from them: right-click the spot in Google Maps to copy it.' ?>
      <?php if (!empty($f['point'])): [$la, $lo] = explode(',', (string) $f['point']) + [1 => '']; ?><a class="underline" target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=<?= $e(trim($la)) ?>&amp;mlon=<?= $e(trim($lo)) ?>#map=16/<?= $e(trim($la)) ?>/<?= $e(trim($lo)) ?>">See their pin</a><?php endif; ?></p>
    <div style="display:grid;grid-template-columns:5rem 1fr;gap:.5rem">
      <div><label class="sg-l">State</label><select class="sg-in" name="state"><?php foreach (NpiBulk::STATES as $st): ?><option<?= $st === $state ? ' selected' : '' ?>><?= $e($st) ?></option><?php endforeach; ?></select></div>
      <div><label class="sg-l">County (optional)</label><input class="sg-in" name="county" maxlength="80" value="<?= $v('county') ?>"></div>
    </div>
    <label class="sg-l">About it (optional)</label><textarea class="sg-in" name="description" rows="3" maxlength="1200"><?= $v('description', trim((string) ($f['what'] ?? '') . (isset($f['offers']) ? "\n" . $f['offers'] : ''))) ?></textarea>
    <label class="sg-l">On a nation's land? Its name (optional)</label><input class="sg-in" name="nation" maxlength="120" value="<?= $v('nation') ?>">
    <p class="text-xs text-[#8A7355] mt-2">Shown at once<?= Journeys::staffCan($pdo, $uid, 'publish') ? '' : ' once an Editor approves it' ?>, unless its name may mark a sacred, burial or protected site: those are held (Admin → Landmarks). Events aren't built yet.</p>
    <div class="mt-3"><button class="sg-b" type="submit">Create the place</button></div>
  </form>
<?php endif; ?>
</div>
<?php tv_crawler_end();
