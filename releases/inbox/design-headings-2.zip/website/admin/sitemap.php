<?php
// admin/sitemap.php — the admin's site map (System Configuration), read from the code each time so it's never out of
// date: the 11 workspaces and their tools (where each opens, live / partial / coming), every admin page and the menus
// it's in (or "not in a menu"), every endpoint with who may call it, what it does and which pages call it, the public
// pages, and the scheduled scripts with their cron lines. A filter box narrows it all.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/Workspaces.php';

$pdo = Database::connection();
tv_admin_require($pdo);
$e = 'tv_e';
$web = realpath(__DIR__ . '/..');
$app = realpath(__DIR__ . '/../../app');

/** Every .php under a folder, as site paths ("/admin/sales.php"). */
$files = function (string $dir, bool $deep = true) use ($web): array {
    $out = [];
    $it = $deep ? new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)) : new DirectoryIterator($dir);
    foreach ($it as $f) if ($f->isFile() && $f->getExtension() === 'php') $out[] = str_replace('\\', '/', substr($f->getPathname(), strlen($web)));
    sort($out);
    return $out;
};
/** What a file says it is: the first line of its header comment (before any code), without the "path — " in front. */
$about = function (string $path): string {
    foreach (preg_split('/\R/', (string) @file_get_contents($path, false, null, 0, 4000)) as $l) {
        $l = trim($l);
        if ($l === '' || $l === '<?php' || str_starts_with($l, 'declare(')) continue;
        if (!preg_match('#^(//|/\*\*?|\*)\s*(.*)$#', $l, $m)) return '';   // code first: no header
        $t = trim(rtrim($m[2], '*/ '));
        if ($t === '') continue;
        return mb_substr(preg_replace('#^\S+\s+[—-]+\s+#u', '', $t) ?? $t, 0, 220);   // "admin/sales.php — Sales, …" → "Sales, …"
    }
    return '';
};
/** Who may open it, from the guard it uses (its own, or a shared guard file it loads). */
$who = function (string $src, string $file = '') use (&$who): string {
    if ($file !== '' && preg_match_all("#require(?:_once)?\s+__DIR__\s*\.\s*'([^']*(?:_common|guard|require_[a-z]+)[^']*\.php)'#", $src, $m))
        foreach ($m[1] as $inc) { $f = realpath(dirname($file) . $inc); if ($f && ($w = $who((string) file_get_contents($f), '')) !== 'public') return $w; }
    if (preg_match('/tv_admin_require|tv_crawler_require_admin|tv_listing_staff_require|requireAdmin|requireStaff|require_admin|canUseIntake|Admin access required/', $src)) return 'staff';
    if (preg_match("/PHP_SAPI !== 'cli'/", $src)) return 'cron';
    if (preg_match('/requireUser|requireAuth|require_auth|Auth::require/', $src) || (str_contains($src, 'Auth::currentUser()') && preg_match('/if \(!\$(me|user|u)\)\s*(\{\s*)?(header|Response::error|http_response_code|tv_|exit)/', $src))) return 'signed in';
    return 'public';
};
$methods = function (string $src): string {
    $m = [];
    if (preg_match("/requireMethod\('POST'\)|REQUEST_METHOD'\] === 'POST'|REQUEST_METHOD'\] !== 'POST'/", $src)) $m[] = 'POST';
    if (preg_match("/requireMethod\('GET'\)|\\\$_GET\[/", $src)) $m[] = 'GET';
    return $m ? implode(' · ', array_unique($m)) : 'GET';
};
$actions = function (string $src): array {
    preg_match_all("/case '([a-z_]+)'\s*:/", $src, $m);
    return array_slice(array_values(array_unique($m[1])), 0, 24);
};

// where each site path is referred to: pages, shared parts and scripts (for "called by")
$sources = [];
foreach ([$web, $app . '/ui', $app . '/lib'] as $d) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) if ($f->isFile() && in_array($f->getExtension(), ['php', 'js'], true) && !str_contains($f->getPathname(), '/storage/') && $f->getSize() < 400000)
        $sources[str_replace('\\', '/', substr($f->getPathname(), strlen(dirname($web))))] = (string) file_get_contents($f->getPathname());
}
$calledBy = function (string $sitePath) use ($sources): array {
    $out = [];
    $dir = dirname($sitePath) . '/'; $base = basename($sitePath, '.php');
    foreach ($sources as $name => $src) {
        if (str_ends_with($name, $sitePath)) continue;
        // the whole path, or its folder and its name apart (a script that builds the URL: API + 'candidates.php')
        if (str_contains($src, $sitePath) || (str_contains($src, $dir) && preg_match('/[\'"\/]' . preg_quote($base, '/') . '(\.php)?[\'"?]/', $src))) $out[] = $name;
    }
    return array_slice($out, 0, 12);
};

// the menus (decisions/0109): which section shows each old page (a bridge), and which ones are archived
require_once __DIR__ . '/../../app/admin/sections.php';
$menu = []; $arch = [];
foreach (Modules::all() as $mk => $_) { $mod = Modules::module($mk); foreach ($mod['sections'] as $sk => $sec) foreach ((array) ($sec['widgets'] ?? []) as $w)
    if ($w[0] === 'bridge') $menu[strtok($w[1], '?#')][] = $mod['num'] . '. ' . $mod['name'] . ' → ' . $sec['label']; }
foreach (Modules::archive() as $old => [$mk, $sk]) { $mod = Modules::module($mk); $arch[$old] = $mod['num'] . '. ' . $mod['name'] . ' → ' . $mod['sections'][$sk]['label']; }

tv_admin_start('settings', 'Site map', 'Every workspace, admin page, endpoint and scheduled script, read from the code just now. Filter by any word: a page, a table, an action.', $pdo, [['System Configuration', '/admin/config'], ['Site map', null]]);
$pill = fn (string $t, string $c) => '<span class="sm-p ' . $c . '">' . $e($t) . '</span>';
?>
<style>
  .sm-q{position:sticky;top:.4rem;z-index:5;width:100%;max-width:32rem;margin:.4rem 0 .8rem}
  .sm-h{font-family:var(--tv-font-head,Georgia,serif);font-size:1.15rem;margin:1.2rem 0 .4rem}
  .sm-ws>summary{cursor:pointer;font-weight:700;padding:.2rem 0}
  .sm-r{display:grid;grid-template-columns:minmax(10rem,16rem) 1fr;gap:.15rem .8rem;padding:.4rem 0;border-top:1px solid #EADFC4;font-size:.86rem}
  .sm-r a{color:#92400E;font-weight:600;word-break:break-all}.sm-r code{font-size:.78rem;word-break:break-all}
  .sm-r small{display:block;color:#6B5844}
  .sm-p{display:inline-block;border-radius:999px;padding:0 .45rem;font-size:.7rem;font-weight:700;margin:0 .25rem .1rem 0;background:#EADFC4;color:#5C4632}
  .sm-p.live{background:#8FBCA8;color:#1F3A2E}.sm-p.partial{background:#FEF3C7;color:#92400E}.sm-p.coming{background:#E5E7EB;color:#4B5563}
  .sm-p.staff{background:#3E2B1F;color:#fff}.sm-p.signedin{background:#DBEAFE;color:#1E3A8A}.sm-p.public{background:#DCFCE7;color:#166534}.sm-p.cron{background:#EDE9FE;color:#5B21B6}.sm-p.warn{background:#FEE2E2;color:#991B1B}
  .sm-r[hidden],.sm-g[hidden]{display:none}
  @media (max-width:640px){.sm-r{grid-template-columns:1fr}}
</style>
<input class="hb-in sm-q" type="search" placeholder="Filter: promo, plans.php, POST, coming…" aria-label="Filter the site map" data-sm-q>

<h2 class="sm-h">Modules and their sections</h2>
<p class="hb-intro">The admin's menu (decisions/0109): each module's sections at their addresses, what each is made of, and anything a section points at that isn't there.</p>
<?php foreach (Workspaces::ALL as $ws => $w): $mod = isset(Workspaces::MERGED[$ws]) ? null : Modules::module($ws); if (!$mod) continue;   /* Pulse: in the Dashboard */ ?>
<details class="hb-card tv-bleed sm-ws sm-g" open><summary><?= (int) $w[0] ?>. <?= $e($w[1]) ?> <a href="/admin/<?= $e($ws) ?>" target="_top" style="font-weight:400;color:#92400E;font-size:.82rem">open</a></summary>
  <small style="color:#6B5844"><?= $e($w[4]) ?><?= $mod['at_hand'] ? ' · At hand: ' . $e(implode(', ', $mod['at_hand'])) : '' ?></small>
  <?php foreach ($mod['sections'] as $k => $sec): $warn = []; $made = [];
    foreach ((array) ($sec['widgets'] ?? []) as $wd) {
      if ($wd[0] === 'bridge') { $made[] = 'shows ' . $wd[1]; if (!is_file($web . strtok($wd[1], '?#'))) $warn[] = 'page missing'; }
      elseif ($wd[0] === 'html') { $made[] = 'drawn by ' . $wd[1] . '()'; if (!function_exists($wd[1])) $warn[] = 'function missing'; }
      else { $made[] = $wd[0] . ' of ' . $wd[1]; if (!Modules::tool($wd[1])) $warn[] = 'tool missing'; }
    }
    if ($sec['status'] === 'coming') $made[] = $sec['about'] ?? ''; ?>
  <div class="sm-r"><div><a href="<?= $e(Modules::url($ws, $k)) ?>" target="_top"><?= $e($sec['label']) ?></a><br><?= $pill($sec['status'], $sec['status']) ?><?php foreach ($warn as $x) echo $pill($x, 'warn'); ?></div>
    <div><code><?= $e(Modules::url($ws, $k)) ?></code><small><?= $e(implode(' · ', array_filter($made))) ?></small><?= !empty($sec['replaces']) ? '<small>Replaces: ' . $e(implode(', ', $sec['replaces'])) . '</small>' : '' ?></div></div>
  <?php endforeach; ?>
  <?php foreach ($mod['at_hand'] as $h) { [$hm, $hs] = explode('/', $h) + ['', '']; if (!isset(Modules::module($hm)['sections'][$hs])) echo '<div class="sm-r"><div>' . $pill('at hand: not a section', 'warn') . '</div><div><code>' . $e($h) . '</code></div></div>'; } ?>
</details>
<?php endforeach; ?>

<h2 class="sm-h">Admin addresses</h2>
<div class="hb-card tv-bleed sm-g">
  <div class="sm-r"><div><code>/admin/&lt;module&gt;/&lt;section&gt;[/&lt;id&gt;]</code><br><?= $pill('staff', 'staff') ?></div><div>admin/router.php: the frame and a section's widgets. <small>?panel=1 draws only the section, for a drawer.</small></div></div>
  <div class="sm-r"><div><code>/admin/api/&lt;module&gt;/&lt;tool&gt;</code><br><?= $pill('staff', 'staff') ?><?= $pill('GET · POST', '') ?></div><div>admin/api.php: every tool's list, get, move and create; config/workflows and config/permissions.
    <small>Tools: <?= $e(implode(', ', array_keys(Modules::tools()))) ?></small></div></div>
</div>

<?php
$groups = [
    'Admin pages' => [$files($web . '/admin', false), false],
    'Admin endpoints (/admin/api)' => [is_dir($web . '/admin/api') ? $files($web . '/admin/api') : [], true],
    'Admin endpoints (/api/admin)' => [is_dir($web . '/api/admin') ? $files($web . '/api/admin') : [], true],
    'Site endpoints (/api)' => [array_values(array_filter($files($web . '/api'), fn ($p) => !str_starts_with($p, '/api/admin/'))), true],
    'Member endpoints (/user/api)' => [is_dir($web . '/user/api') ? $files($web . '/user/api') : [], true],
    'Listing endpoints (/listing/api)' => [is_dir($web . '/listing/api') ? $files($web . '/listing/api') : [], true],
];
$public = array_values(array_filter($files($web), fn ($p) => !preg_match('#^/(admin|api|user/api|listing/api)/#', $p)));
$groups['Public and member pages'] = [$public, false];
foreach ($groups as $title => [$list, $isApi]): if (!$list) continue; ?>
<h2 class="sm-h"><?= $e($title) ?> <small style="font-size:.8rem;color:#6B5844">(<?= count($list) ?>)</small></h2>
<div class="hb-card tv-bleed sm-g">
  <?php foreach ($list as $p): $src = $sources['/website' . $p] ?? (string) @file_get_contents($web . $p); $w = $who($src, $web . $p); $acts = $isApi ? $actions($src) : []; $by = $isApi ? $calledBy($p) : []; $where = $menu[$p] ?? []; ?>
  <div class="sm-r"><div><?= $isApi ? '<code>' . $e($p) . '</code>' : '<a href="' . $e($p) . '" target="_top">' . $e($p) . '</a>' ?><br><?= $pill($w, str_replace(' ', '', $w)) ?><?= $isApi ? $pill($methods($src), '') : '' ?></div>
    <div><?= $e($about($web . $p)) ?>
      <?php if (!$isApi && str_starts_with($p, '/admin/')): ?><small><?= isset($arch[$p]) ? $pill('archived', 'coming') . 'Its work is in ' . $e($arch[$p]) . ($where ? ' (shown there: ' . $e(implode('; ', $where)) . ')' : '') : ($where ? 'Shown inside: ' . $e(implode('; ', $where)) : 'Not in a menu (opened from another page, or a leftover)') ?></small><?php endif; ?>
      <?php if ($acts): ?><small>Actions: <?= $e(implode(', ', $acts)) ?></small><?php endif; ?>
      <?php if ($isApi): ?><small><?= $by ? 'Called by: ' . $e(implode(', ', array_map(fn ($b) => preg_replace('#^/website#', '', $b), $by))) : 'Called by: nothing found in the site\'s pages or scripts (an outside service, or unused)' ?></small><?php endif; ?></div></div>
  <?php endforeach; ?>
</div>
<?php endforeach; ?>

<h2 class="sm-h">Scheduled scripts (cPanel → Cron Jobs)</h2>
<div class="hb-card tv-bleed sm-g">
  <?php foreach (glob($app . '/scripts/*.php') ?: [] as $f): $src = (string) file_get_contents($f, false, null, 0, 3000); preg_match('#Cron Jobs[^:]*:\s*([^\n]+)#', $src, $cm); ?>
  <div class="sm-r"><div><code>app/scripts/<?= $e(basename($f)) ?></code><br><?= $cm ? $pill('scheduled', 'cron') : $pill('run by hand', '') ?></div>
    <div><?= $e(preg_replace('#^\S+\s+[—-]+\s+#u', '', (string) (preg_match('#//\s*(.+)#', $src, $m) ? $m[1] : ''))) ?><?= $cm ? '<small><code>' . $e(trim($cm[1])) . '</code></small>' : '' ?></div></div>
  <?php endforeach; ?>
</div>
<script>
(function () {
  var q = document.querySelector('[data-sm-q]');
  q.addEventListener('input', function () {
    var v = q.value.trim().toLowerCase();
    document.querySelectorAll('.sm-g').forEach(function (g) {
      var any = false;
      g.querySelectorAll('.sm-r').forEach(function (r) { var hit = !v || r.textContent.toLowerCase().indexOf(v) !== -1; r.hidden = !hit; any = any || hit; });
      g.hidden = !any && !!v; if (v && any && g.tagName === 'DETAILS') g.open = true;
    });
  });
})();
</script>
<?php tv_admin_end();
