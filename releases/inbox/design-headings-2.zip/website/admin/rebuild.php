<?php
// admin/rebuild.php — "Rebuild from its website" (decisions/0083). A school district and its schools, a health system
// and its clinics, a chain's stores: read the organization's own website, see the plan (which listing becomes which
// place, which merge, which are new, what's left over), change anything, apply it, undo it.
//   ?ids=1,2,3   the listings it should cover (from Find & edit's "select several")
//   ?nexus=N     rebuild a Nexus (its listings, its website)
//   ?url=…       the website to read
// Opens as a pop-up from Find & edit and the Nexus page; its three steps show as breadcrumbs.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/Rebuild.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$ids = array_values(array_filter(array_map('intval', explode(',', (string) ($_GET['ids'] ?? '')))));
$nexusId = (int) ($_GET['nexus'] ?? 0);
$url = trim((string) ($_GET['url'] ?? ''));
$picked = [];
foreach (array_slice($ids, 0, ListingBulk::MAX) as $i) if ($e = IntakeStager::existingListing($pdo, $i)) $picked[] = ListingBulk::card($e);
$nx = $nexusId && Nexus::ready($pdo) ? Nexus::get($pdo, $nexusId) : null;
if ($url === '' && $nx) $url = (string) $nx['website'];
if ($url === '') foreach ($picked as $p) if ($p['website'] !== '' && WebIdentity::brand($p['website']) !== '') { $url = 'https://' . explode('/', WebIdentity::brand($p['website']))[0] . '/'; break; }
$e = 'tv_e';

tv_crawler_start('listings', 'Rebuild from its website', $pdo,
    'For an organization with several places (a school district and its schools, a clinic group, a chain\'s stores): the crawler reads its website, and you see which of our listings becomes which place, which are the same place listed twice, which places are new, and what\'s left over. Nothing changes until you apply it, and you can undo it.');
?>
<style>
  .rb-steps{display:flex;flex-wrap:wrap;gap:.25rem;align-items:center;margin:.2rem 0 .6rem}
  .rb-steps button{font:inherit;font-size:.82rem;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .7rem;background:#FFFBF2;color:#5C4632;cursor:pointer}
  .rb-steps button.on{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA;font-weight:700}
  .rb-steps button:disabled{opacity:.5;cursor:default}
  .rb-steps i{font-style:normal;color:#8A7355}
  .rb-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .85rem;margin-top:.5rem}
  .rb-card.off{opacity:.55}
  .rb-in{width:100%;box-sizing:border-box;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.55rem;padding:.45rem .6rem;font:inherit;color:#3E2B1F}
  .rb-l{display:block;font-weight:700;font-size:.82rem;margin-top:.5rem;color:#3E2B1F}
  .rb-b{display:inline-flex;align-items:center;justify-content:center;font:inherit;font-weight:700;font-size:.85rem;border-radius:.6rem;padding:.45rem .9rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;cursor:pointer;text-decoration:none}
  .rb-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}
  .rb-row{display:flex;gap:.6rem;align-items:flex-start}
  .rb-row > input[type=checkbox]{width:1.25rem;height:1.25rem;margin-top:.15rem;accent-color:#3E2B1F;flex:0 0 auto}
  .rb-row > div{flex:1;min-width:0}
  .rb-what{font-size:.86rem;color:#3E2B1F;margin:.25rem 0 0}
  .rb-what b{color:#92400E}
  .rb-s{font-size:.78rem;color:#8A7355;display:block;overflow-wrap:anywhere}
  .rb-tag{display:inline-block;font-size:.7rem;font-weight:700;border-radius:999px;padding:.05rem .5rem;background:#EADFC4;color:#5C4632;margin-right:.3rem;text-transform:uppercase;letter-spacing:.03em}
  .rb-tag.new{background:#DCEFE5;color:#1F5C43}.rb-tag.upd{background:#FFF1D6;color:#92400E}.rb-tag.mrg{background:#FEE2E2;color:#991B1B}
  .rb-grid{display:grid;grid-template-columns:1fr 1fr;gap:.5rem}
  @media (max-width:767px){ .rb-grid{grid-template-columns:1fr} }
  .rb-h{font:700 1.05rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:1rem 0 0}
  .rb-chips span{display:inline-block;font-size:.78rem;background:#EADFC4;border-radius:999px;padding:.15rem .6rem;margin:.2rem .2rem 0 0}
  .rb-err{color:#991B1B;font-weight:700;margin-top:.5rem}
  .rb-wait{display:flex;gap:.5rem;align-items:center;color:#5C4632;margin-top:.6rem}
  .rb-wait i{width:1rem;height:1rem;border-radius:999px;border:2px solid #CBB98D;border-top-color:#3E2B1F;animation:rbs 1s linear infinite}
  @keyframes rbs{to{transform:rotate(360deg)}}
  .rb-foot{position:sticky;bottom:0;display:flex;gap:.5rem;align-items:center;justify-content:flex-end;flex-wrap:wrap;margin-top:.8rem;padding:.6rem .7rem;background:#3E2B1F;border-radius:.7rem;color:#FFF8EA}
  .rb-foot span{margin-right:auto;font-size:.88rem}
  .rb-foot .rb-b{background:#FFFBF2}.rb-foot .rb-b.go{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}
</style>

<nav class="rb-steps" aria-label="Steps"><button type="button" data-step="1" class="on">1 · Its website</button><i>›</i><button type="button" data-step="2" disabled>2 · The plan</button><i>›</i><button type="button" data-step="3" disabled>3 · Done</button></nav>

<section data-pane="1" class="rb-card tv-bleed">
  <label class="rb-l" for="rb-url" style="margin-top:0">The organization's website</label>
  <input id="rb-url" class="rb-in" type="url" value="<?= $e($url) ?>" placeholder="https://www.holbrook.k12.az.us/" autocomplete="off">
  <span class="rb-s">Its home page. The crawler reads the site's own list of its places (Schools, Locations, Clinics, Our stores…) and each place's page, the way a visitor would, and follows the site's robots.txt.</span>
  <?php if ($nx): ?><p class="rb-what">Rebuilding the Nexus <b><?= $e($nx['name']) ?></b> and its listings.</p><?php endif; ?>
  <?php if ($picked): ?><p class="rb-what">The listings you picked (others on the same website or phone, or with a look-alike name in the town, are found too):</p>
    <div class="rb-chips"><?php foreach ($picked as $p): ?><span><?= $e($p['name']) ?> <small>#<?= (int) $p['id'] ?></small></span><?php endforeach; ?></div><?php endif; ?>
  <div style="margin-top:.7rem"><button type="button" class="rb-b go" id="rb-read">Read the site</button></div>
  <div class="rb-wait" id="rb-wait" hidden><i></i><span>Reading the site. This can take a minute or so.</span></div>
  <p class="rb-err" id="rb-err1" hidden></p>
</section>

<section data-pane="2" hidden>
  <div id="rb-plan"></div>
  <p class="rb-err" id="rb-err2" hidden></p>
  <div class="rb-foot tv-bleed"><span id="rb-count"></span><button type="button" class="rb-b" data-go="1">◂ Back</button><button type="button" class="rb-b go" id="rb-apply">Apply</button></div>
</section>

<section data-pane="3" hidden>
  <div class="rb-card tv-bleed"><p class="rb-what" style="margin-top:0"><b>Done.</b></p><ul id="rb-done" style="margin:.4rem 0 0 1.1rem;font-size:.88rem"></ul>
    <div style="margin-top:.7rem;display:flex;gap:.5rem;flex-wrap:wrap"><a class="rb-b go" id="rb-open" href="#" target="_top">Open the Nexus</a><button type="button" class="rb-b" id="rb-undo">Undo all of it</button></div>
    <p class="rb-err" id="rb-err3" hidden></p></div>
</section>

<script>
(function () {
  var IDS = <?= json_encode($ids) ?>, NEXUS = <?= (int) $nexusId ?>, csrf = null, token = null, plan = null, KINDS = {}, ROLES = {};
  function $(s) { return document.querySelector(s); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function tok() { return csrf ? Promise.resolve(csrf) : fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrf = d.csrf_token || (d.data && d.data.csrf_token) || ''); }); }
  function api(body) {
    return tok().then(function (c) { return fetch('/admin/api/rebuild.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok || j.ok === false || j.success === false) throw new Error((j.error && (j.error.message || j.error)) || j.message || 'That didn\'t work.'); return j.data || j; }); });
  }
  function step(n) {
    document.querySelectorAll('[data-pane]').forEach(function (p) { p.hidden = +p.getAttribute('data-pane') !== n; });
    document.querySelectorAll('[data-step]').forEach(function (b) { b.classList.toggle('on', +b.getAttribute('data-step') === n); });
    window.scrollTo(0, 0);
  }
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-step],[data-go]'); if (b && !b.disabled) step(+(b.getAttribute('data-step') || b.getAttribute('data-go'))); });
  function err(n, m) { var x = $('#rb-err' + n); x.textContent = m || ''; x.hidden = !m; }
  function opts(o, sel) { return Object.keys(o).map(function (k) { return '<option value="' + esc(k) + '"' + (k === sel ? ' selected' : '') + '>' + esc(o[k]) + '</option>'; }).join(''); }
  function where(p) { return [p.address, [p.city, p.state].filter(Boolean).join(', '), p.phone].filter(Boolean).join(' · '); }
  function listing(x) { return '<b>#' + x.id + ' ' + esc(x.name) + '</b>' + (x.claimed ? ' (managed by its owner)' : '') + '<span class="rb-s">' + esc(where(x)) + (x.why ? ' · matched by ' + esc(x.why) : '') + '</span>'; }

  function draw() {
    var h = '<div class="rb-card tv-bleed"><p class="rb-what" style="margin-top:0">Read <b>' + plan.pages + '</b> page' + (plan.pages === 1 ? '' : 's') + ' of ' + esc(plan.url) + '.</p>'
      + '<div class="rb-grid"><label class="rb-l">The Nexus' + (plan.nexus.id ? ' (already made)' : ' (new)') + '<input class="rb-in" data-nx="name" value="' + esc(plan.nexus.name) + '"></label>'
      + '<label class="rb-l">What it is<select class="rb-in" data-nx="kind">' + opts(KINDS, plan.nexus.kind) + '</select></label></div></div>';
    h += '<p class="rb-h">Its places <span class="rb-s" style="display:inline">untick any you don\'t want</span></p>';
    plan.lines.forEach(function (L) {
      var p = L.place, what;
      if (L.keep) what = '<span class="rb-tag upd">Update</span>' + listing(L.keep) + (L.rename ? '<span class="rb-s">is renamed to the name above</span>' : '');
      else what = '<span class="rb-tag new">New listing</span>Listed unclaimed; the crawler fills in the rest.' + '<label class="rb-l">Category<select class="rb-in" data-k="category_id">' + L.categories.map(function (c) { return '<option value="' + c.id + '"' + (c.id === L.category_id ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('') + '</select></label>';
      var merges = (L.merge || []).map(function (m) { return '<p class="rb-what"><span class="rb-tag mrg">Merge in</span>' + listing(m) + '<span class="rb-s">the same place listed again: its details fill any gaps, then it\'s hidden and its link goes to the one kept</span></p>'; }).join('');
      h += '<div class="rb-card tv-bleed" data-line="' + esc(L.key) + '"><div class="rb-row"><input type="checkbox" data-k="accept" checked aria-label="Do this"><div>'
        + '<div class="rb-grid"><label class="rb-l" style="margin-top:0">' + (L.org ? 'The organization\'s own office' : 'Place') + '<input class="rb-in" data-k="name" value="' + esc(L.name) + '"></label>'
        + '<label class="rb-l" style="margin-top:0">Its role<select class="rb-in" data-k="role">' + opts(ROLES, L.role) + '</select></label></div>'
        + '<span class="rb-s">On its site: ' + esc(where(p) || 'no address given') + (p.page ? ' · ' + esc(p.page) : '') + ' · from ' + esc(p.from) + '</span>'
        + '<p class="rb-what">' + what + '</p>' + merges + '</div></div></div>';
    });
    if (plan.strays.length) {
      h += '<p class="rb-h">Left over <span class="rb-s" style="display:inline">listings that look related but aren\'t one of its places</span></p>';
      plan.strays.forEach(function (s) {
        h += '<div class="rb-card tv-bleed" data-stray="' + s.id + '"><p class="rb-what" style="margin-top:0">' + listing(Object.assign({}, s, { why: '' })) + '<span class="rb-s">Why it\'s here: ' + esc(s.why) + '</span></p>'
          + '<label class="rb-l">What to do<select class="rb-in" data-k="choice"><option value="leave">Leave it as it is</option><option value="nexus">Put it in the Nexus as it is</option>'
          + plan.lines.map(function (L) { return '<option value="merge:' + esc(L.key) + '">It\'s ' + esc(L.name) + ': merge it in</option>'; }).join('')
          + (s.claimed ? '' : '<option value="hide">Hide it from the site</option>') + '</select></label></div>';
      });
    }
    $('#rb-plan').innerHTML = h;
    count();
  }
  function count() {
    var n = document.querySelectorAll('[data-line] [data-k=accept]:checked').length, m = [].filter.call(document.querySelectorAll('[data-stray] [data-k=choice]'), function (s) { return s.value !== 'leave'; }).length;
    document.querySelectorAll('[data-line]').forEach(function (c) { c.classList.toggle('off', !c.querySelector('[data-k=accept]').checked); });
    $('#rb-count').textContent = n + ' of ' + plan.lines.length + ' places' + (m ? ', ' + m + ' left-over listing' + (m === 1 ? '' : 's') : '');
    $('#rb-apply').disabled = !n && !m;
  }
  document.addEventListener('change', function (e) { if (e.target.closest('#rb-plan')) count(); });

  $('#rb-read').addEventListener('click', function () {
    var b = this; err(1); b.disabled = true; $('#rb-wait').hidden = false;
    api({ do: 'read', url: $('#rb-url').value.trim(), ids: IDS, nexus_id: NEXUS }).then(function (r) {
      token = r.token; plan = r.plan; KINDS = r.kinds; ROLES = r.roles;
      draw(); document.querySelector('[data-step="2"]').disabled = false; step(2);
    }).catch(function (x) { err(1, x.message); }).then(function () { b.disabled = false; $('#rb-wait').hidden = true; });
  });
  $('#rb-apply').addEventListener('click', function () {
    var b = this;
    if (!TvAsk.gate(b, 'Apply this plan? You can undo it afterwards.', { yes: 'Apply it' })) return;
    err(2); b.disabled = true;
    var lines = [].map.call(document.querySelectorAll('[data-line]'), function (c) {
      var g = function (k) { var x = c.querySelector('[data-k=' + k + ']'); return x ? (x.type === 'checkbox' ? x.checked : x.value) : null; };
      return { key: c.getAttribute('data-line'), accept: g('accept'), name: g('name'), role: g('role'), category_id: +(g('category_id') || 0) };
    });
    var strays = [].map.call(document.querySelectorAll('[data-stray]'), function (c) { return { id: +c.getAttribute('data-stray'), choice: c.querySelector('[data-k=choice]').value }; });
    api({ do: 'apply', token: token, nexus: { name: document.querySelector('[data-nx=name]').value, kind: document.querySelector('[data-nx=kind]').value }, lines: lines, strays: strays }).then(function (r) {
      $('#rb-done').innerHTML = r.done.map(function (d) { return '<li>' + esc(d) + '</li>'; }).join('');
      $('#rb-open').href = '/admin/nexus.php?id=' + r.nexus;
      document.querySelector('[data-step="3"]').disabled = false; document.querySelector('[data-step="2"]').disabled = true; step(3);
    }).catch(function (x) { err(2, x.message); }).then(function () { b.disabled = false; });
  });
  $('#rb-undo').addEventListener('click', function () {
    var b = this;
    if (!TvAsk.gate(b, 'Put everything back as it was before?', { yes: 'Undo it', danger: true })) return;
    api({ do: 'undo' }).then(function (r) { $('#rb-done').innerHTML = '<li>' + esc(r.message) + '</li>'; b.disabled = true; $('#rb-open').hidden = true; }).catch(function (x) { err(3, x.message); });
  });
})();
</script>
<?php tv_crawler_end();
