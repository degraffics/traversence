<?php
// admin/listings.php — Listings & places, an area of the admin dashboard (decisions/0078); it began as Manage listings (Jason, 2026-10-10: "combine all listing tools under one admin page, like the
// user profile"). One page, its sections in a row at the top, switching in place like the dashboard's (data-sec):
//   Overview    what's waiting, how complete the listings are, and the routine that keeps them right
//   Find & edit any listing, hidden, closed and unclaimed ones included; Edit opens the editor in a pop-up
//   Review, Add a listing, Nexus, Claims, Identities, Published, Crawl a site, and the places (Experiences, Journeys,
//   Landmarks, Nations): each tool in its embedded view
//     (the page itself, without the admin frame), loaded the first time its section opens and filling the page,
//     so its own pop-ups and forms work as they do on their own page
// The section is kept in the address (#review), so Back and a bookmark return to it. Admins and regional managers.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/admin-dashboard.php';
require_once __DIR__ . '/../../app/lib/Nexus.php';

$pdo = Database::connection();
$me = tv_listing_staff_require($pdo);
$C = []; try { $C = tv_admin_counts($pdo); } catch (Throwable) {}
$n = fn (string ...$k) => array_sum(array_map(fn ($x) => (int) ($C[$x] ?? 0), $k));
$q = function (string $sql) use ($pdo): int { try { return (int) $pdo->query($sql)->fetchColumn(); } catch (Throwable) { return 0; } };
$live = "e.entity_type = 'merchant' AND e.status IN ('unclaimed','claimed-unverified','pending-verification','verified')";
$lacks = fn (string $key) => $q("SELECT COUNT(*) FROM entities e WHERE $live AND e.is_suppressed = 0 AND NOT EXISTS (SELECT 1 FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = '$key' AND m.meta_value NOT IN ('\"\"', '[]', 'null', ''))");

// listings that need a person: only what the pipeline has given up on (decisions/0076); the rest it's still working on
require_once __DIR__ . '/../../app/lib/crawler/AutoImport.php';
$needYou = 0; $working = 0;
try {
    foreach ($pdo->query("SELECT raw_payload, created_at FROM " . Database::t('crawler_raw_index') . " WHERE status = 'staged' AND payload_type = 'listing'")->fetchAll(PDO::FETCH_ASSOC) as $r0) {
        $c0 = json_decode((string) $r0['raw_payload'], true);
        if (is_array($c0)) AutoImport::exhausted($c0, (string) $r0['created_at']) ? $needYou++ : $working++;
    }
} catch (Throwable) {}
$waiting = $needYou + $n('suggestions', 'sources', 'names', 'clusters');
$claims = $n('claims', 'claims_held', 'claims_changes', 'claims_disputes');
$facts = $n('conflicts', 'found');
$total = $q("SELECT COUNT(*) FROM entities e WHERE $live");
$S = [
    'total' => $total,
    'claimed' => $q("SELECT COUNT(*) FROM entities e WHERE $live AND e.status <> 'unclaimed'"),
    'closed' => $q("SELECT COUNT(*) FROM entities e JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'closed' WHERE $live"),
    'hidden' => $q("SELECT COUNT(*) FROM entities e WHERE $live AND e.is_suppressed = 1"),
    'nopin' => $q("SELECT COUNT(*) FROM entities e WHERE $live AND e.is_suppressed = 0 AND e.latitude IS NULL"),
    'nophone' => $lacks('phone'), 'noweb' => $lacks('website'), 'nohours' => $lacks('hours'), 'noabout' => $lacks('description'),
    'new7' => $q("SELECT COUNT(*) FROM entities e WHERE $live AND e.created_at >= NOW() - INTERVAL 7 DAY"),
    'auto7' => $q("SELECT COUNT(*) FROM " . Database::t('crawler_raw_index') . " WHERE status = 'published' AND reviewed_by_user_id IS NULL AND reviewed_at >= NOW() - INTERVAL 7 DAY"),
    'nexus' => Nexus::ready($pdo) ? $q('SELECT COUNT(*) FROM nexus') : 0,
    'innexus' => Nexus::ready($pdo) ? $q("SELECT COUNT(*) FROM entities e WHERE $live AND e.nexus_id IS NOT NULL") : 0,
];
$pct = fn (int $k) => $total ? (int) round(100 * $k / $total) : 0;

// the sections: key => [label, embedded tool url or '' for one drawn here, badge]
$SECS = [
    'overview'   => ['Overview', '', 0],
    'review'     => ['Review', '/admin/crawler-review.php', $waiting],
    'find'       => ['Find & edit', '', 0],
    'add'        => ['Add a listing', '/admin/listing-add.php', 0],
    'nexus'      => ['Nexus', '/admin/nexus.php', 0],
    'claims'     => ['Claims', '/admin/claims.php', $claims],
    'identities' => ['Identities', '/admin/identities.php', $facts],
    'published'  => ['Published by the crawler', '/admin/auto-imports.php', 0],
    'crawl'      => ['Crawl a site', '/admin/listing-intake.php', 0],
    // the places (decisions/0078): Listings & places is one area of the admin dashboard
    'experiences' => ['Experiences', '/admin/experiences.php', $n('experiences')],
    'journeys'   => ['Journeys', '/admin/journeys.php', 0],
    'landmarks'  => ['Landmarks', '/admin/landmarks.php', 0],
    'nations'    => ['Nations', '/admin/nations.php', 0],
];
tv_crawler_start('listings', 'Listings & places', $pdo, '');
$e = 'tv_e';
$go = fn (string $sec, string $label) => '<a class="ml-go" href="#' . $sec . '" data-ml="' . $sec . '">' . $e($label) . ' &rarr;</a>';
?>
<style>
  .ml-tabs{display:flex;gap:.35rem;overflow-x:auto;padding:.2rem 0 .5rem;margin-top:.4rem;scrollbar-width:thin;position:sticky;top:0;z-index:5;background:inherit}
  .ml-tab{flex:0 0 auto;display:inline-flex;align-items:center;gap:.35rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.38rem .8rem;font-size:.85rem;font-weight:600;text-decoration:none;white-space:nowrap;cursor:pointer}
  .ml-tab.on{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}
  .ml-tab b{background:#D97706;color:#fff;border-radius:999px;font-size:.7rem;padding:.05rem .4rem}
  [data-sec][hidden]{display:none!important}
  .ml-frame{width:100%;border:0;display:block;background:transparent;min-height:15rem;height:15rem}
  .ml-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(15rem,100%),1fr));gap:.6rem;margin-top:.6rem}
  .ml-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .85rem}
  .ml-card .num{font:700 1.6rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;line-height:1.1}
  .ml-card .lab{font-size:.85rem;color:#5C4632;margin-top:.15rem}
  .ml-card.hot{border-color:#F3D9A4;background:#FFF8EA}
  .ml-go{display:inline-block;margin-top:.35rem;font-size:.82rem;font-weight:700;color:#92400E;text-decoration:underline}
  .ml-h{font:700 1.1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:1.2rem 0 0}
  .ml-bar{height:6px;border-radius:999px;background:#EADFC4;margin-top:.4rem;overflow:hidden}.ml-bar i{display:block;height:100%;background:#8FBCA8}
  .ml-steps{margin:.5rem 0 0;padding:0;list-style:none;counter-reset:s}
  .ml-steps li{counter-increment:s;position:relative;padding:.55rem .7rem .55rem 2.3rem;border:1px solid #EADFC4;background:#FFFBF2;border-radius:.7rem;margin-top:.4rem;font-size:.9rem;color:#3E2B1F}
  .ml-steps li::before{content:counter(s);position:absolute;left:.7rem;top:.55rem;width:1.2rem;height:1.2rem;border-radius:999px;background:#3E2B1F;color:#FFF8EA;font-size:.72rem;font-weight:700;display:flex;align-items:center;justify-content:center}
  .ml-steps li b{color:#3E2B1F}
  .ml-find{display:flex;gap:.4rem}
  .ml-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem .7rem;font-size:.95rem;color:#3E2B1F}
  .ml-res .r{display:flex;justify-content:space-between;align-items:center;gap:.6rem;padding:.55rem .1rem;border-top:1px solid #EADFC4}
  .ml-res .r:first-child{border-top:0}
  .ml-res .nm{font-weight:700;color:#92400E;text-decoration:underline}
  .ml-res small{display:block;color:#8A7355;font-size:.8rem}
  .ml-res .acts{display:flex;gap:.35rem;flex-shrink:0}
  .ml-b{display:inline-flex;align-items:center;font-weight:700;font-size:.82rem;border-radius:.6rem;padding:.35rem .75rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;text-decoration:none;cursor:pointer}
  .ml-pill{font-size:.7rem;border-radius:999px;padding:.05rem .45rem;background:#EADFC4;color:#5C4632;margin-left:.3rem;font-weight:600}
  .ml-pill.red{background:#FEE2E2;color:#991B1B}
  .ml-res .r{justify-content:flex-start}.ml-res .r > span:nth-child(2){flex:1;min-width:0}
  .ml-ck{flex:0 0 auto;width:1.25rem;height:1.25rem;accent-color:#3E2B1F;cursor:pointer}
  .ml-sel{position:sticky;bottom:0;z-index:6;display:flex;flex-wrap:wrap;align-items:center;gap:.4rem;margin-top:.6rem;padding:.55rem .65rem;border-radius:.7rem;background:#3E2B1F;color:#FFF8EA;box-shadow:0 -6px 18px -8px rgba(0,0,0,.35)}
  .ml-sel[hidden]{display:none}
  .ml-sel b{font-size:.88rem;margin-right:auto}
  .ml-sel .ml-b{background:#FFFBF2}.ml-sel .ml-b.go{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}.ml-sel .ml-b.x{background:transparent;color:#EADFC4;border-color:#8A7355}
  .ml-chips{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.5rem}
  .ml-chips span{display:inline-flex;align-items:center;gap:.3rem;font-size:.78rem;background:#EADFC4;color:#3E2B1F;border-radius:999px;padding:.15rem .25rem .15rem .6rem}
  .ml-chips button{border:0;background:#FFFBF2;border-radius:999px;width:1.2rem;height:1.2rem;line-height:1;cursor:pointer;color:#5C4632}
</style>

<nav class="ml-tabs" data-more role="tablist" aria-label="Listings & places">
  <?php foreach ($SECS as $k => [$label, , $badge]): ?><a class="ml-tab" role="tab" href="#<?= $k ?>" data-ml="<?= $k ?>"><?= $e($label) ?><?= $badge ? '<b>' . ($badge > 99 ? '99+' : $badge) . '</b>' : '' ?></a><?php endforeach; ?>
</nav>

<section data-sec="overview">
  <div class="ml-grid">
    <div class="ml-card<?= $waiting ? ' hot' : '' ?>"><div class="num"><?= number_format($waiting) ?></div><div class="lab">need you in Review: listings the crawler ran out of things to try on, and what visitors sent</div><?= $go('review', 'Review') ?></div>
    <div class="ml-card"><div class="num"><?= number_format($working) ?></div><div class="lab">the crawler is still working on: it publishes each one on its own when it's ready</div></div>
    <div class="ml-card<?= $claims ? ' hot' : '' ?>"><div class="num"><?= number_format($claims) ?></div><div class="lab">claims to decide: owners, changes, disputes</div><?= $go('claims', 'Claims') ?></div>
    <div class="ml-card<?= $facts ? ' hot' : '' ?>"><div class="num"><?= number_format($facts) ?></div><div class="lab">facts to check: sources that disagree, or found new</div><?= $go('identities', 'Identities') ?></div>
    <div class="ml-card"><div class="num"><?= number_format($S['auto7']) ?></div><div class="lab">published by the crawler on its own this week</div><?= $go('published', 'See them') ?></div>
  </div>

  <h2 class="ml-h">The listings</h2>
  <div class="ml-grid">
    <div class="ml-card"><div class="num"><?= number_format($S['total']) ?></div><div class="lab"><?= number_format($S['claimed']) ?> claimed by their owners · <?= number_format($S['total'] - $S['claimed']) ?> unclaimed</div><?= $go('find', 'Find one') ?> <a class="ml-go" href="/admin/sales.php#all" target="_top">Prospect the unclaimed &rarr;</a></div>
    <div class="ml-card hot"><div class="num"><?= number_format($S['new7']) ?></div><div class="lab">listings added this week: each one is a business to call</div><a class="ml-go" href="/admin/sales.php#new" target="_top">See them in Sales &rarr;</a></div>
    <div class="ml-card"><div class="num"><?= number_format($S['nexus']) ?></div><div class="lab">organizations with many locations (Nexus), holding <?= number_format($S['innexus']) ?> listings</div><?= $go('nexus', 'Nexus') ?></div>
    <div class="ml-card"><div class="num"><?= number_format($S['closed']) ?></div><div class="lab">shown as Closed (still listed, last in search) · <?= number_format($S['hidden']) ?> hidden from the site</div></div>
  </div>

  <h2 class="ml-h">How complete they are</h2>
  <div class="ml-grid">
    <?php foreach ([['nophone', 'have a phone'], ['noweb', 'have a website'], ['nohours', 'have their hours'], ['noabout', 'have an about'], ['nopin', 'are on the map']] as [$k, $lab]): $have = max(0, $S['total'] - $S['hidden'] - $S[$k]); ?>
    <div class="ml-card"><div class="num"><?= $pct($have) ?>%</div><div class="lab"><?= $e($lab) ?> · <?= number_format($S[$k]) ?> don't</div><div class="ml-bar"><i style="width:<?= $pct($have) ?>%"></i></div></div>
    <?php endforeach; ?>
  </div>
  <p class="text-sm mt-2 text-[#5C4632]">The crawler fills these in as it confirms them. Listings that search needed and couldn't offer are in <a class="underline" href="/admin/search-oversight.php#incomplete">Search → Oversight → Incomplete listings</a>.</p>

  <h2 class="ml-h">Keeping listings right</h2>
  <ol class="ml-steps">
    <li><b>Let the crawler build them.</b> Add a business or point the crawler at a website; it gathers the rest, sorts it, chooses the category, merges what's already listed, and publishes each listing unclaimed, ready to claim. Nothing waits on you while it can still try something.</li>
    <li><b>Review what it couldn't finish.</b> Only listings it ran out of things to try on, grouped by why, so a reason shared by many is one answer (publish them all, or leave them out). Open one to compare it side by side, fix, save, close. <?= $go('review', 'Review') ?></li>
    <li><b>Claims.</b> Confirm owners (the text step, then a call if needed), owners' changes to protected details, and disputes. <?= $go('claims', 'Claims') ?></li>
    <li><b>Facts.</b> When sources disagree on a phone, website or address, choose which is right; the listing keeps the source of each fact. <?= $go('identities', 'Identities') ?></li>
    <li><b>Organizations.</b> A business with several locations (Changepoint's clinics, a grocery chain) gets one Nexus: each location keeps its own listing and shows "Part of …" and its other locations. <?= $go('nexus', 'Nexus') ?></li>
    <li><b>Fix one.</b> Find it by name, phone, address or #id and edit it. Edits are marked as a person's, so the crawler never overwrites them. A business that closed: <b>Mark closed</b> (it stays listed, shown as Closed). <?= $go('find', 'Find & edit') ?></li>
    <li><b>Add what's missing.</b> Start one with its name, category and town (it goes live unclaimed and the crawler finds the rest), or point the crawler at a business's website. <?= $go('add', 'Add a listing') ?> <?= $go('crawl', 'Crawl a site') ?></li>
    <li><b>After big changes,</b> rebuild the search index once (<a class="underline" href="/admin/search-index.php">Search → Search index</a>). Everyday edits update it on their own.</li>
  </ol>
</section>

<section data-sec="find" hidden>
  <div class="ml-card tv-bleed">
    <label class="text-sm font-bold" for="ml-q">Find any listing to edit, or tick several to merge them or put them in a Nexus</label>
    <div class="ml-find mt-1"><input id="ml-q" class="ml-in" type="search" placeholder="Name, phone, address or #id" autocomplete="off"></div>
    <p class="text-xs text-[#8A7355] mt-1">Hidden, closed and unclaimed ones included. Edit opens the editor over this page; close it to come back here.</p>
    <div id="ml-res" class="ml-res mt-2"></div>
    <div class="ml-chips" id="ml-chips"></div>
    <div class="ml-sel" id="ml-sel" hidden><b id="ml-seln"></b>
      <button type="button" class="ml-b go" data-bulk="merge" title="They are one place: keep one, fill its gaps from the others, hide the others">Merge into one</button>
      <button type="button" class="ml-b" data-bulk="nexus" title="Locations of one organization: each stays its own listing, shown as Part of it">Put in a Nexus</button>
      <button type="button" class="ml-b" data-bulk="unnexus">Take out of its Nexus</button>
      <button type="button" class="ml-b" data-bulk="rebuild" title="Read the organization's website and match these to the places it lists">Rebuild from its website</button>
      <button type="button" class="ml-b x" data-bulk="clear">Clear</button></div>
  </div>
</section>

<?php foreach ($SECS as $k => [$label, $url]): if ($url === '') continue; ?>
<section data-sec="<?= $k ?>" hidden><iframe class="ml-frame" data-no-back data-fit title="<?= $e($label) ?>" data-src="<?= $e($url . (str_contains($url, '?') ? '&' : '?') . 'embed=1') ?>"></iframe></section>
<?php endforeach; ?>

<script>
(function () {
  var tabs = [].slice.call(document.querySelectorAll('.ml-tab')), secs = [].slice.call(document.querySelectorAll('[data-sec]'));
  // the tool grows to fit what's in it (TvAsk.fitFrame): one scroll bar, the page's, and its pop-ups open over the
  // whole page (js/tv-ask.js), never a frame inside a frame
  function size(f) { if (f && window.TvAsk && TvAsk.fitFrame) TvAsk.fitFrame(f); }
  function show(k) {
    if (!secs.some(function (s) { return s.getAttribute('data-sec') === k; })) k = 'overview';
    secs.forEach(function (s) { s.hidden = s.getAttribute('data-sec') !== k; });
    tabs.forEach(function (t) { var on = t.getAttribute('data-ml') === k; t.classList.toggle('on', on); t.setAttribute('aria-selected', on ? 'true' : 'false'); if (on && t.scrollIntoView) t.scrollIntoView({ block: 'nearest', inline: 'nearest' }); });
    var sec = secs.filter(function (s) { return s.getAttribute('data-sec') === k; })[0], f = sec && sec.querySelector('iframe');
    if (f && !f.getAttribute('src')) f.setAttribute('src', f.getAttribute('data-src'));
    size(f);
    if (k === 'find') { var q = document.getElementById('ml-q'); if (q) setTimeout(function () { q.focus(); }, 0); }
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-ml]'); if (!a) return;
    e.preventDefault(); var k = a.getAttribute('data-ml');
    if (location.hash !== '#' + k) history.pushState(null, '', '#' + k);
    show(k); window.scrollTo(0, 0);
  });
  window.addEventListener('popstate', function () { show(location.hash.slice(1) || 'overview'); });
  show(location.hash.slice(1) || 'overview');

  // Find & edit: the same search as Review's Find box
  var inp = document.getElementById('ml-q'), out = document.getElementById('ml-res'), t = null, seq = 0, SEL = {}, SHOWN = {};
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function find() {
    var q = inp.value.trim(); if (q.length < 2) { out.innerHTML = ''; return; }
    var my = ++seq;
    fetch('/admin/api/find-listing.php?q=' + encodeURIComponent(q), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) {
      if (my !== seq) return;
      var items = ((j.data || j).items || []);
      out.innerHTML = items.length ? items.map(function (it) {
        return '<div class="r"><input type="checkbox" class="ml-ck" data-pick="' + it.id + '"' + (SEL[it.id] ? ' checked' : '') + ' aria-label="Select ' + esc(it.name) + '"><span><a class="nm" href="/listing/view.php?id=' + it.id + '" data-peek-frame>' + esc(it.name) + '</a>'
          + (it.closed ? '<span class="ml-pill red">Closed</span>' : '') + (it.hidden ? '<span class="ml-pill red">Hidden</span>' : '') + (it.status && it.status !== 'unclaimed' ? '<span class="ml-pill">Claimed</span>' : '') + (it.nexus ? '<span class="ml-pill">Part of ' + esc(it.nexus) + '</span>' : '')
          + '<small>#' + it.id + ' · ' + esc([it.category, [it.address, it.city].filter(Boolean).join(', ')].filter(Boolean).join(' · ')) + '</small></span>'
          + '<span class="acts"><a class="ml-b" href="/admin/listing-edit.php?id=' + it.id + '" data-peek-frame="Edit ' + esc(it.name) + '">Edit</a></span></div>';
      }).join('') : '<p class="text-sm text-[#8A7355]">Nothing by that name, phone, address or number.</p>';
      items.forEach(function (it) { SHOWN[it.id] = it; });
    });
  }
  if (inp) inp.addEventListener('input', function () { clearTimeout(t); t = setTimeout(find, 250); });
  window.addEventListener('tv-peek-closed', function () { if (inp && inp.value.trim().length >= 2) find(); });

  // ---- Several at once (decisions/0083): tick listings across searches, then merge them or put them in a Nexus ----
  var bar = document.getElementById('ml-sel'), chips = document.getElementById('ml-chips'), csrf = null;
  function selIds() { return Object.keys(SEL).map(Number); }
  function drawSel() {
    var ids = selIds();
    bar.hidden = !ids.length;
    document.getElementById('ml-seln').textContent = ids.length + ' selected';
    bar.querySelector('[data-bulk="merge"]').disabled = ids.length < 2;
    chips.innerHTML = ids.map(function (id) { return '<span>' + esc(SEL[id].name) + ' <small>#' + id + '</small><button type="button" data-unpick="' + id + '" aria-label="Unselect">×</button></span>'; }).join('');
    out.querySelectorAll('[data-pick]').forEach(function (c) { c.checked = !!SEL[c.getAttribute('data-pick')]; });
  }
  out.addEventListener('change', function (e) { var c = e.target.closest('[data-pick]'); if (!c) return; var id = +c.getAttribute('data-pick'); if (c.checked) SEL[id] = SHOWN[id] || { name: '#' + id }; else delete SEL[id]; drawSel(); });
  chips.addEventListener('click', function (e) { var b = e.target.closest('[data-unpick]'); if (!b) return; delete SEL[b.getAttribute('data-unpick')]; drawSel(); });
  function tok() { return csrf ? Promise.resolve(csrf) : fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrf = d.csrf_token || (d.data && d.data.csrf_token) || ''); }); }
  function api(body, q) {
    var p = body ? tok().then(function (c) { return fetch('/admin/api/listings-bulk.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); })
                 : fetch('/admin/api/listings-bulk.php?' + q, { credentials: 'include' });
    return p.then(function (r) { return r.json().then(function (j) { if (!r.ok || j.success === false) throw new Error((j.error && (j.error.message || j.error)) || j.message || 'That didn\'t work.'); return j.data || j; }); });
  }
  // the pop-up opens on the top page, over everything, even when Find & edit is shown inside the admin dashboard
  function topWin() { var w = window; try { while (w.frameElement && w.parent && w.parent.document) w = w.parent; } catch (x) {} return w; }
  function popup(title, body, yes, onYes, danger) {
    var W = topWin(), D = W.document;
    if (!D.getElementById('ml-lb-css')) { var st = D.createElement('style'); st.id = 'ml-lb-css'; st.textContent =
      '.ml-lb{position:fixed;inset:0;z-index:210;background:rgba(42,27,18,.55);overflow-y:auto;padding:12px;display:flex;align-items:flex-start;justify-content:center}'
      + '.ml-lbx{width:min(40rem,100%);margin:6vh auto 12px;background:#F7EFDC;border-radius:.9rem;box-shadow:0 20px 50px rgba(0,0,0,.35);font-family:inherit;color:#3E2B1F}'
      + '.ml-lbh{display:flex;align-items:center;gap:.5rem;background:#3E2B1F;color:#FFF8EA;padding:.6rem .8rem;border-radius:.9rem .9rem 0 0}.ml-lbh b{flex:1;font:700 1rem var(--tv-font-head,Georgia,serif)}'
      + '.ml-lbh button{width:2rem;height:2rem;border-radius:.5rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;font-size:1.2rem;line-height:1;cursor:pointer}'
      + '.ml-lbb{padding:.8rem .9rem;font-size:.9rem}.ml-lbb p{margin:.2rem 0 .5rem;color:#5C4632}.ml-lbb label.o{display:flex;gap:.55rem;align-items:flex-start;padding:.55rem .6rem;border:1px solid #EADFC4;background:#FFFBF2;border-radius:.6rem;margin-top:.35rem;cursor:pointer}'
      + '.ml-lbb label.o:has(input:checked){border-color:#8FBCA8;box-shadow:0 0 0 2px rgba(143,188,168,.45)}.ml-lbb label.o b{color:#92400E}.ml-lbb small{display:block;color:#8A7355;font-size:.78rem}'
      + '.ml-lbb .f{display:block;margin-top:.6rem;font-weight:700;font-size:.82rem}.ml-lbb input[type=text],.ml-lbb input[type=search],.ml-lbb select{width:100%;box-sizing:border-box;margin-top:.25rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.55rem;padding:.45rem .6rem;font:inherit;color:#3E2B1F}'
      + '.ml-lbb .err{color:#991B1B;font-weight:700;margin-top:.5rem}.ml-lbf{display:flex;gap:.5rem;justify-content:flex-end;padding:.7rem .9rem;border-top:1px solid #EADFC4}'
      + '.ml-lbf button{font:inherit;font-weight:700;font-size:.85rem;border-radius:.55rem;padding:.45rem .9rem;cursor:pointer;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F}.ml-lbf button.yes{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}.ml-lbf button.yes.danger{background:#991B1B;border-color:#991B1B}'
      + '@media (max-width:767px){.ml-lb{padding:3px}.ml-lbx{margin:3px auto}}';
      D.head.appendChild(st); }
    var lb = D.createElement('div'); lb.className = 'ml-lb'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', title);
    lb.innerHTML = '<div class="ml-lbx"><div class="ml-lbh"><b>' + esc(title) + '</b><button type="button" data-x aria-label="Close">×</button></div><div class="ml-lbb">' + body + '<p class="err" data-err hidden></p></div>'
      + '<div class="ml-lbf"><button type="button" data-x>Cancel</button><button type="button" class="yes' + (danger ? ' danger' : '') + '" data-yes>' + esc(yes) + '</button></div></div>';
    D.body.appendChild(lb);
    function close() { lb.remove(); D.removeEventListener('keydown', key, true); }
    function key(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
    D.addEventListener('keydown', key, true);
    lb.addEventListener('click', function (e) {
      if (e.target === lb || e.target.closest('[data-x]')) { close(); return; }
      if (e.target.closest('[data-yes]')) {
        var btn = e.target.closest('[data-yes]'), er = lb.querySelector('[data-err]'); btn.disabled = true; er.hidden = true;
        Promise.resolve(onYes(lb)).then(function (ok) { if (ok !== false) close(); else btn.disabled = false; }).catch(function (x) { er.textContent = x.message; er.hidden = false; btn.disabled = false; });
      }
    });
    return lb;
  }
  function done(msg) {
    var A = topWin().TvAsk || window.TvAsk;
    if (A) A.say(msg + ' ', {});
    SEL = {}; drawSel(); if (inp.value.trim().length >= 2) find();
    // Undo: one tap, for a short while
    var u = document.createElement('div'); u.className = 'ml-sel'; u.innerHTML = '<b>' + esc(msg) + '</b><button type="button" class="ml-b">Undo</button>';
    bar.parentNode.insertBefore(u, bar);
    u.querySelector('button').addEventListener('click', function () { api({ do: 'undo' }).then(function (r) { u.remove(); if (A) A.say(r.message, {}); if (inp.value.trim().length >= 2) find(); }).catch(function (x) { if (A) A.say(x.message, {}); }); });
    setTimeout(function () { u.remove(); }, 60000);
  }
  bar.addEventListener('click', function (e) {
    var b = e.target.closest('[data-bulk]'); if (!b) return;
    var k = b.getAttribute('data-bulk'), ids = selIds();
    if (k === 'clear') { SEL = {}; drawSel(); return; }
    if (k === 'rebuild') { (topWin().TvAsk || TvAsk).peek('/admin/rebuild.php?ids=' + ids.join(','), 'Rebuild from its website', { fit: true }); return; }
    if (k === 'unnexus') {
      if (!TvAsk.gate(b, 'Take ' + ids.length + ' out of their Nexus? Each stays listed on its own.', { yes: 'Take them out' })) return;
      api({ do: 'unnexus', ids: ids }).then(function (r) { done(r.out + ' taken out of their Nexus.'); }).catch(function (x) { TvAsk.say(x.message, { anchor: b }); });
      return;
    }
    if (k === 'merge') {
      api(null, 'ids=' + ids.join(',')).then(function (r) {
        var L = r.items, best = L.slice().sort(function (a, c) { return (c.claimed - a.claimed) || (c.filled - a.filled) || (a.id - c.id); })[0];
        var body = '<p>They are <b>one place</b>, listed ' + L.length + ' times. The one you keep stays; anything missing from it is filled in from the others (what a person or the owner entered on it is never replaced); the others are hidden and their links go to it. You can undo it.</p>'
          + '<span class="f">Keep this one</span>' + L.map(function (x) {
            return '<label class="o"><input type="radio" name="keep" value="' + x.id + '"' + (x.id === best.id ? ' checked' : '') + (L.some(function (y) { return y.claimed && y.id !== x.id; }) ? ' disabled' : '') + '><span><b>' + esc(x.name) + '</b> <small style="display:inline">#' + x.id + (x.claimed ? ' · managed by its owner' : '') + (x.hidden ? ' · hidden' : '') + '</small>'
              + '<small>' + esc([x.category, [x.address, x.city].filter(Boolean).join(', '), x.phone, x.website].filter(Boolean).join(' · ')) + '</small><small>' + x.filled + ' details filled in · added ' + esc(x.created) + '</small></span></label>';
          }).join('')
          + '<label class="f">Name to use<select name="name_from">' + L.map(function (x) { return '<option value="' + x.id + '"' + (x.id === best.id ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select></label>';
        var lb = popup('Merge ' + L.length + ' listings into one', body, 'Merge into one', function (lb) {
          var keep = lb.querySelector('input[name=keep]:checked'); if (!keep) throw new Error('Choose which one to keep.');
          return api({ do: 'merge', ids: ids, keep: +keep.value, name_from: +lb.querySelector('select[name=name_from]').value }).then(function (r) {
            done('Merged into #' + r.kept + ' ' + r.name + (r.filled.length ? ': filled in ' + r.filled.join(', ') : '') + '; ' + r.hidden.length + ' hidden.');
          });
        }, true);
        lb.querySelectorAll('input[name=keep]').forEach(function (rd) { rd.addEventListener('change', function () { lb.querySelector('select[name=name_from]').value = rd.value; }); });
      }).catch(function (x) { TvAsk.say(x.message, { anchor: b }); });
      return;
    }
    if (k === 'nexus') {
      api(null, 'nexus=').then(function (r) {
        var kinds = Object.keys(r.kinds).map(function (k2) { return '<option value="' + k2 + '">' + esc(r.kinds[k2]) + '</option>'; }).join('');
        var roles = Object.keys(r.roles).map(function (k2) { return '<option value="' + k2 + '">' + esc(r.roles[k2]) + '</option>'; }).join('');
        var body = '<p>Locations of one organization: each stays its own listing with its own address, phone and owner, and shows <b>Part of</b> it, with its other locations.</p>'
          + '<span class="f">Which Nexus</span><input type="search" data-nq placeholder="Find one by name or website" autocomplete="off"><div data-nl></div>'
          + '<label class="o"><input type="radio" name="nx" value="0"><span><b>A new Nexus</b><small>Name it below</small></span></label>'
          + '<div data-new hidden><label class="f">Name<input type="text" name="name" placeholder="Holbrook Unified School District #3"></label>'
          + '<label class="f">What it is<select name="kind">' + kinds + '</select></label><label class="f">Website (optional)<input type="text" name="website" placeholder="holbrook.k12.az.us"></label></div>'
          + '<label class="f">Each one is a<select name="role">' + roles + '</select></label>';
        var lb = popup('Put ' + ids.length + ' in a Nexus', body, 'Put them in', function (lb) {
          var pick = lb.querySelector('input[name=nx]:checked'); if (!pick) throw new Error('Choose a Nexus, or a new one.');
          var q = { do: 'nexus', ids: ids, nexus_id: +pick.value, role: lb.querySelector('select[name=role]').value };
          if (!q.nexus_id) { q.name = lb.querySelector('input[name=name]').value.trim(); q.kind = lb.querySelector('select[name=kind]').value; q.website = lb.querySelector('input[name=website]').value.trim(); if (q.name.length < 2) throw new Error('Give the new Nexus a name.'); }
          return api(q).then(function (r2) { done(r2.moved + ' put in ' + r2.name + '.'); });
        });
        var list = lb.querySelector('[data-nl]'), nq = lb.querySelector('[data-nq]'), t2 = null;
        function nx(rows) { list.innerHTML = rows.map(function (n) { return '<label class="o"><input type="radio" name="nx" value="' + n.id + '"><span><b>' + esc(n.name) + '</b><small>' + esc(n.kind) + ' · ' + n.members + ' listing' + (n.members === 1 ? '' : 's') + (n.website ? ' · ' + esc(n.website) : '') + '</small></span></label>'; }).join(''); }
        nx(r.nexus.slice(0, 6));
        nq.addEventListener('input', function () { clearTimeout(t2); t2 = setTimeout(function () { api(null, 'nexus=' + encodeURIComponent(nq.value.trim())).then(function (r3) { nx(r3.nexus.slice(0, 8)); }); }, 200); });
        lb.addEventListener('change', function (e) { if (e.target.name === 'nx') lb.querySelector('[data-new]').hidden = e.target.value !== '0'; });
        // a new one is named after the first one picked, which is usually the main office
        lb.querySelector('input[name=name]').value = SEL[ids[0]] ? SEL[ids[0]].name : '';
      }).catch(function (x) { TvAsk.say(x.message, { anchor: b }); });
    }
  });
})();
</script>
<?php tv_crawler_end();
