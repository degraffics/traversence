<?php
// /admin/insights.php — how the platform is working (decisions/0058 §13): use, the routes people take between the
// sections, what they search for and whether they find it, what they do from listings, and what's read and seen.
// Everything here is counts (api/lib/PlatformCounts.php, api/lib/ListingActions.php): nothing about who. Search
// words appear only once 3 or more visits searched them.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/PlatformCounts.php';
require_once __DIR__ . '/../../app/lib/ListingActions.php';

$pdo = Database::connection();
tv_crawler_require_admin($pdo);
// the team's own use isn't counted (PlatformCounts::isTeam): this browser is marked, and can be unmarked to test as a visitor
if (isset($_GET['count_me'])) { PlatformCounts::markBrowser($_GET['count_me'] !== '1'); if ($_GET['count_me'] === '1') $_SESSION['tv_team_off'] = 1; else unset($_SESSION['tv_team_off']); header('Location: /admin/insights.php', true, 303); exit; }
if (empty($_SESSION['tv_team_off'])) PlatformCounts::isTeam($pdo);
$days = (int) ($_GET['days'] ?? 30); if (!in_array($days, [7, 30, 90], true)) $days = 30;
$ready = PlatformCounts::ready($pdo);
$since = date('Y-m-d', time() - $days * 86400);

const IN_SECTIONS = ['home' => 'Home', 'explore' => "Let's Explore", 'local' => 'Get Local', 'social' => 'Social', 'market' => 'Marketplace', 'member' => 'Dashboard', 'site' => 'Help and other pages'];
$secName = fn (string $k) => IN_SECTIONS[$k] ?? ($k === 'entry' ? 'Arriving from outside' : ucfirst($k));

// use
$secs = $ready ? PlatformCounts::top($pdo, 'view', $days, 20) : [];
$secs = array_intersect_key($secs, IN_SECTIONS);
$visits = array_sum(array_column($secs, 'visits'));
$views = array_sum(array_column($secs, 'n'));
$daily = [];
if ($ready) {   // section visits per day
    foreach (PlatformCounts::daily($pdo, 'view', $days) as $d => $v) $daily[$d] = 0;
    $st = $pdo->prepare("SELECT day, SUM(visits) AS v FROM platform_counts WHERE metric = 'view' AND day >= ? AND k IN ('" . implode("','", array_keys(IN_SECTIONS)) . "') GROUP BY day");
    $st->execute([$since]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (isset($daily[$r['day']])) $daily[$r['day']] = (int) $r['v'];
}
// routes
$flows = $ready ? PlatformCounts::top($pdo, 'flow', $days, 40) : [];
$entries = []; $routes = [];
foreach ($flows as $k => $v) { [$a, $b] = array_pad(explode('>', $k, 2), 2, ''); if ($a === $b) continue; if ($a === 'entry') $entries[$b] = $v; else $routes["$a>$b"] = $v; }
// search
$searches = $ready ? PlatformCounts::total($pdo, 'search', $days, 'q:%') : ['n' => 0, 'visits' => 0];
$zero = $ready ? PlatformCounts::total($pdo, 'search_zero', $days) : ['n' => 0, 'visits' => 0];
$topQ = $ready ? PlatformCounts::top($pdo, 'search', $days, 25, 'q:%', PlatformCounts::MIN_VISITS) : [];
$gapQ = $ready ? PlatformCounts::top($pdo, 'search_zero', $days, 20, '', PlatformCounts::MIN_VISITS) : [];
$noneHere = $ready ? PlatformCounts::top($pdo, 'search_none_here', $days, 20, '', PlatformCounts::MIN_VISITS) : [];
$whereQ = $ready ? PlatformCounts::top($pdo, 'search', $days, 12, 'in:%') : [];
// search term + place + results found (decisions/0058 §13): what people looked for, where, and how much they found
$locQ = [];
if ($ready) {
    $found = PlatformCounts::top($pdo, 'search_found', $days, 500);
    foreach (PlatformCounts::top($pdo, 'search_loc', $days, 30, '', PlatformCounts::MIN_VISITS) as $k => $v) {
        [$w, $pl] = array_pad(explode(' @ ', $k, 2), 2, '');
        $locQ[] = ['q' => $w, 'place' => $pl, 'n' => $v['n'], 'visits' => $v['visits'], 'avg' => $v['n'] ? ($found[$k]['n'] ?? 0) / $v['n'] : 0];
    }
}
// what's held back by the 3-visit rule, as numbers only (2026-10-14: "By place? No data?" while the site is new)
$heldQ = $ready ? PlatformCounts::heldBack($pdo, 'search', $days, PlatformCounts::MIN_VISITS, 'q:%') : ['keys' => 0, 'n' => 0];
$heldLoc = $ready ? PlatformCounts::heldBack($pdo, 'search_loc', $days, PlatformCounts::MIN_VISITS) : ['keys' => 0, 'n' => 0];
$held = fn (array $h, string $what) => $h['n'] ? '<p class="in-what">Held back: ' . number_format($h['n']) . ' search' . ($h['n'] === 1 ? '' : 'es') . ' for ' . number_format($h['keys']) . ' ' . $what . ($h['keys'] === 1 ? '' : 's') . ' that fewer than ' . PlatformCounts::MIN_VISITS . ' visits looked for, so their words aren\'t shown. Each one shows here once ' . PlatformCounts::MIN_VISITS . ' visits search it.</p>' : '';
$clicks = $ready ? PlatformCounts::top($pdo, 'search_click', $days, 12) : [];
$acts = $ready ? PlatformCounts::top($pdo, 'act', $days, 12) : [];
// from listings (what visitors did: the businesses' own counts, summed)
$la = array_fill_keys(array_keys(ListingActions::ACTIONS), 0);
if (ListingActions::ready($pdo)) {
    $st = $pdo->prepare('SELECT action, SUM(n) AS n FROM listing_actions WHERE day >= ? GROUP BY action'); $st->execute([$since]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $la[(string) $r['action']] = (int) $r['n'];
}
// content: the most seen, with names
$names = function (string $prefix, array $rows) use ($pdo): array {
    $out = [];
    foreach ($rows as $k => $v) {
        $id = substr($k, strlen($prefix));
        $label = $k; $url = '';
        try {
            if ($prefix === 'listing:') { $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([(int) $id]); $label = (string) ($st->fetchColumn() ?: $k); $url = '/listing/view.php?id=' . (int) $id; }
            elseif ($prefix === 'journey:') { $st = $pdo->prepare('SELECT title FROM journeys WHERE id = ?'); $st->execute([(int) $id]); $label = (string) ($st->fetchColumn() ?: $k); $url = '/journeys/view.php?id=' . (int) $id; }
            elseif ($prefix === 'rec:') { require_once __DIR__ . '/../../app/lib/crawler/RecBulk.php'; $r = RecBulk::get($pdo, $id); $label = $r ? RecBulk::displayName((string) $r['name']) : $k; $url = '/place/recreation.php?id=' . rawurlencode($id); }
            elseif ($prefix === 'place:') { require_once __DIR__ . '/../../app/lib/Links.php'; [$label, $url] = Links::resolve($pdo, 'place', $id); }
            elseif ($prefix === 'explore:') { $label = ucfirst($id); $url = '/discovery/' . ($id !== 'overview' ? '?view=' . rawurlencode($id) : ''); }
        } catch (Throwable) {}
        $out[] = ['label' => $label, 'url' => $url] + $v;
    }
    return $out;
};
$top = fn (string $prefix, int $n = 10) => $ready ? $names($prefix, PlatformCounts::top($pdo, 'view', $days, $n, $prefix . '%')) : [];
// pages by their address, the routes between them, and where visits from outside came from and landed (SEO proof)
$pages = $ready ? PlatformCounts::top($pdo, 'page', $days, 40) : [];
$pageFlows = $ready ? PlatformCounts::top($pdo, 'page_flow', $days, 40) : [];
$sources = $ready ? PlatformCounts::top($pdo, 'source', $days, 20) : [];
$landFrom = $ready ? PlatformCounts::top($pdo, 'land_from', $days, 60) : [];
$fromEngines = 0; $fromAi = 0; foreach ($sources as $k => $v) { if (in_array($k, PlatformCounts::ENGINES, true)) $fromEngines += $v['n']; if (in_array($k, PlatformCounts::AI, true)) $fromAi += $v['n']; }
$topListings = $top('listing:'); $topJourneys = $top('journey:'); $topRec = $top('rec:'); $topPlaces = $top('place:'); $exploreViews = $top('explore:', 12);

tv_page_start('Insights', ['section' => 'admin', 'active' => 'insights', 'crumbs' => [['Admin', '/admin/'], ['Insights']], 'description' => 'How the platform is working.']);
echo (tv_embedded() ? '' : '<h1 class="font-serif font-bold text-2xl text-[#3E2B1F]" style="margin:0">Insights</h1>') . '<p class="text-sm text-[#5C4632]" style="margin:.2rem 0 0">How the platform is working: use, the routes people take, what they search for and find, and what they do from listings. Counts only: nothing here is about who.</p>';
// what the menu's number on Insights counts (section-rails.php: missed, left, drafts, guides, due, gaps, failed), each with
// its way in, so the number is never a dead end (Jason, 2026-11-12: "shows 9 alerts, but I don't see them")
(function () use ($pdo) {
    require_once __DIR__ . '/../../app/ui/admin-dashboard.php';
    try { $C = tv_admin_counts($pdo); } catch (Throwable) { return; }
    $W = [
        ['missed', 'Searches that found nothing this week', '/admin/search-misses.php', 'Open the workbench'],
        ['drafts', 'Searches search couldn\'t answer on its own', '/admin/search-misses.php#drafts', 'Decide'],
        ['left', 'Words with nothing to predict', '/admin/search-misses.php#ms-pred', 'See them'],
        ['guides', 'How-to guides to check', '/admin/how-guides.php?s=draft', 'Review'],
        ['due', 'Phone numbers to re-check', '/admin/search-oversight.php#due', 'Re-check'],
        ['gaps', 'Situation needs with no answer nearby', '/admin/search-learning.php#gaps', 'See the gaps'],
        ['failed', 'Crawl jobs that failed', '/admin/crawler.php#fix-worker', 'Try again'],
    ];
    $h = '';
    foreach ($W as [$k, $t, $u, $b]) {
        $n = (int) ($C[$k] ?? 0); if ($n < 1) continue;
        $h .= '<li style="display:flex;align-items:center;gap:.6rem;padding:.45rem 0;border-top:1px solid #EADFC4"><b style="min-width:2.2rem;text-align:right;color:#B45309;font-variant-numeric:tabular-nums">' . $n . '</b><span style="flex:1">' . htmlspecialchars($t, ENT_QUOTES) . '</span>'
            . '<a class="ak-b" href="' . htmlspecialchars($u, ENT_QUOTES) . '" target="_top" style="white-space:nowrap">' . htmlspecialchars($b, ENT_QUOTES) . '</a></li>';
    }
    if ($h !== '') echo '<section class="hb-card tv-bleed" style="margin:.8rem 0 0;padding:.7rem .9rem;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem"><h2 class="font-serif font-bold" style="margin:0 0 .2rem;font-size:1.1rem;color:#3E2B1F">Waiting for you</h2><p class="text-sm text-[#5C4632]" style="margin:0 0 .3rem">The number beside Insights in the menu: what search and the crawler need from a person.</p><ul style="list-style:none;margin:0;padding:0">' . $h . '</ul></section>';
})();
$teamOff = !empty($_SESSION['tv_team_off']);
echo '<p class="text-xs text-[#5C4632]" style="margin:.35rem 0 0">' . ($teamOff
    ? 'This browser <b>is counted</b> for now, as a visitor would be. <a class="text-[#92400E] underline" href="/admin/insights.php?count_me=0">Stop counting it</a>'
    : 'The team\'s own use isn\'t counted: signed-in admins, and any browser an admin has used (signed out too), from 14 Oct 2026 on. Earlier days include it. A listing\'s owner on their own listing isn\'t counted on it either. <a class="text-[#92400E] underline" href="/admin/insights.php?count_me=1">Count this browser</a> (to test as a visitor)') . '</p>';
$pct = fn (int $a, int $b) => $b > 0 ? round(100 * $a / $b) : 0;
$bar = function (array $rows, callable $label, string $unit = 'visits') {
    $max = max(1, ...array_values(array_map(fn ($r) => $r['visits'] ?: $r['n'], $rows ?: [['visits' => 1, 'n' => 1]])));
    $h = '';
    foreach ($rows as $k => $r) {
        $v = $r['visits'] ?: $r['n'];
        $lbl = $label($k, $r);
        $h .= '<div class="in-row"><span class="in-l">' . $lbl . '</span><span class="in-bar"><i style="width:' . max(2, round(100 * $v / $max)) . '%"></i></span><b>' . number_format($v) . '</b></div>';
    }
    return $h !== '' ? $h : '<p class="in-empty">Nothing counted yet for this period.</p>';
};
?>
<style>
  .in-top{display:flex;flex-wrap:wrap;gap:.4rem;margin:.6rem 0 1rem}.in-top a{font-size:.82rem;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .75rem;background:#FFFBF2;color:#3E2B1F;text-decoration:none}
  .in-top a.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .in-tiles{display:grid;gap:.6rem;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));margin-bottom:1rem}
  .in-t{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;padding:.7rem .85rem}.in-t b{display:block;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.6rem;color:#3E2B1F;line-height:1.1}
  .in-t span{font-size:.78rem;color:#7A6348}
  .in-grid{display:grid;gap:.8rem;grid-template-columns:repeat(auto-fill,minmax(320px,1fr))}
  .in-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:1rem;padding:.85rem 1rem}
  .in-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.05rem;color:#3E2B1F;margin:0 0 .15rem}
  .in-card p.in-what{font-size:.78rem;color:#7A6348;margin:0 0 .6rem}
  .in-row{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr) auto;gap:.5rem;align-items:center;font-size:.84rem;color:#3E2B1F;padding:.18rem 0}
  .in-l{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.in-l a{color:#92400E}
  .in-bar{height:8px;background:#EADFC4;border-radius:999px;overflow:hidden}.in-bar i{display:block;height:100%;background:#B8863B;border-radius:999px}
  .in-row b{font-variant-numeric:tabular-nums;font-size:.8rem}
  .in-empty{font-size:.84rem;color:#7A6348;margin:0}
  .in-spark{display:flex;align-items:flex-end;gap:2px;height:70px;margin:.3rem 0 .2rem}.in-spark i{flex:1;background:#B8863B;border-radius:2px 2px 0 0;min-height:2px}
  .in-wide{grid-column:1/-1}.in-tbl{overflow-x:auto}.in-tbl table{width:100%;border-collapse:collapse;font-size:.82rem}
  .in-tbl th{text-align:left;font-size:.7rem;text-transform:uppercase;letter-spacing:.04em;color:#7A6348;padding:.3rem .4rem;border-bottom:1px solid #EADFC4}
  .in-tbl td{padding:.35rem .4rem;border-bottom:1px solid #F3EAD6;overflow-wrap:anywhere}.in-tbl td:nth-child(n+3),.in-tbl th:nth-child(n+3){text-align:right;font-variant-numeric:tabular-nums}
  .in-tbl a{color:#92400E}.in-gap td:last-child{color:#B91C1C;font-weight:600}
  .in-note{font-size:.75rem;color:#7A6348;margin-top:1rem}
</style>
<?php if (!$ready): ?><p class="in-card">Run <code>app/migrations/2026-10-11_platform_counts.sql</code> to start counting.</p><?php endif; ?>
<nav class="in-top" aria-label="Period"><?php foreach ([7, 30, 90] as $d): ?><a href="?days=<?= $d ?>" class="<?= $d === $days ? 'on' : '' ?>">Last <?= $d ?> days</a><?php endforeach; ?></nav>

<div class="in-tiles">
  <div class="in-t"><b><?= number_format($visits) ?></b><span>Visits to sections</span></div>
  <div class="in-t"><b><?= number_format($fromEngines) ?></b><span>Arrivals from search engines</span></div>
  <div class="in-t"><b><?= number_format($fromAi) ?></b><span>Arrivals from AI assistants</span></div>
  <div class="in-t"><b><?= number_format($views) ?></b><span>Page views</span></div>
  <div class="in-t"><b><?= number_format($searches['n']) ?></b><span>Searches acted on</span></div>
  <div class="in-t"><b><?= $pct($zero['n'], $searches['n']) ?>%</b><span>Searches that found nothing</span></div>
  <div class="in-t"><b><?= number_format(array_sum($la)) ?></b><span>Calls, directions, website and contact taps</span></div>
  <div class="in-t"><b><?= number_format(array_sum(array_column($topJourneys, 'visits'))) ?></b><span>Journey reads (top 10)</span></div>
</div>

<div class="in-grid">
  <section class="in-card"><h2>Visits per day</h2><p class="in-what">Distinct visits to the sections, each day of the period.</p>
    <div class="in-spark" aria-label="Visits per day"><?php $mx = max(1, ...array_values($daily ?: [0])); foreach ($daily as $d => $v): ?><i title="<?= tv_e(date('M j', strtotime($d))) ?>: <?= (int) $v ?>" style="height:<?= max(2, round(100 * $v / $mx)) ?>%"></i><?php endforeach; ?></div>
    <p class="in-what" style="margin:0"><?= tv_e(date('M j', strtotime(array_key_first($daily) ?? 'now'))) ?> – today</p></section>

<?php $pgLink = fn (string $p) => '<a href="' . tv_e($p) . '" target="_blank" rel="noopener">' . tv_e($p) . '</a>'; ?>
  <section class="in-card in-wide"><h2>Where visitors come from</h2><p class="in-what">The site that sent each visit from outside: search engines, AI assistants, social sites, other sites by name, short links and QR codes (trvgo.us), or Direct (typed, a bookmark, an app or an email; these send no site). Only the site's name is kept, never the address or the search.</p>
    <?= $bar($sources, fn ($k) => tv_e($k) . (in_array($k, PlatformCounts::ENGINES, true) ? ' <small style="color:#3E6B55">search engine</small>' : (in_array($k, PlatformCounts::AI, true) ? ' <small style="color:#3E6B55">AI assistant</small>' : '')), 'n') ?></section>
  <section class="in-card in-wide"><h2>Where they land, and from where</h2><p class="in-what">The first page of each visit from outside, with the site that sent it. A page landed on from Google or Bing is a page search engines send people to.</p>
    <div class="in-tbl"><?php if (!$landFrom): ?><p class="in-empty">Nothing counted yet for this period.</p><?php else: ?><table><tr><th>From</th><th>Landed on</th><th>Visits</th></tr>
    <?php foreach ($landFrom as $k => $v): [$src, $pg] = array_pad(explode(' > ', $k, 2), 2, ''); ?><tr><td><?= tv_e($src) ?></td><td><?= $pgLink($pg) ?></td><td><?= number_format($v['n']) ?></td></tr><?php endforeach; ?></table><?php endif; ?></div></section>
  <section class="in-card in-wide"><h2>Pages people see</h2><p class="in-what">Each page by its address, most visited first (a page seen more than once in a visit counts once in Visits). Admin pages aren't counted.</p>
    <div class="in-tbl"><?php if (!$pages): ?><p class="in-empty">Nothing counted yet for this period.</p><?php else: ?><table><tr><th>Page</th><th></th><th>Visits</th><th>Views</th></tr>
    <?php foreach ($pages as $k => $v): ?><tr><td><?= $pgLink($k) ?></td><td></td><td><?= number_format($v['visits']) ?></td><td><?= number_format($v['n']) ?></td></tr><?php endforeach; ?></table><?php endif; ?></div></section>
  <section class="in-card in-wide"><h2>The routes between pages</h2><p class="in-what">Each move from one page to the next within a visit, most taken first.</p>
    <div class="in-tbl"><?php if (!$pageFlows): ?><p class="in-empty">Nothing counted yet for this period.</p><?php else: ?><table><tr><th>From</th><th>To</th><th>Times</th></tr>
    <?php foreach ($pageFlows as $k => $v): [$a, $b] = array_pad(explode(' > ', $k, 2), 2, ''); ?><tr><td><?= $pgLink($a) ?></td><td><?= $pgLink($b) ?></td><td><?= number_format($v['n']) ?></td></tr><?php endforeach; ?></table><?php endif; ?></div></section>
  <section class="in-card"><h2>Where people go</h2><p class="in-what">Visits to each section.</p>
    <?= $bar($secs, fn ($k) => tv_e($secName($k))) ?></section>

  <section class="in-card"><h2>How they arrive</h2><p class="in-what">The first section of a visit, coming from outside Traversence.</p>
    <?= $bar($entries, fn ($k) => tv_e($secName($k)), 'n') ?></section>

  <section class="in-card"><h2>The routes they take</h2><p class="in-what">Moves from one section to another, most taken first. "Let's Explore → Get Local" is discovery turning into a visit to a business.</p>
    <?= $bar(array_slice($routes, 0, 12, true), fn ($k) => tv_e(implode(' → ', array_map($secName, explode('>', $k))))) ?></section>

  <section class="in-card"><h2>What they do from listings</h2><p class="in-what">Taps on a listing's actions, all businesses together.</p>
    <?= $bar(array_map(fn ($n) => ['n' => $n, 'visits' => $n], array_combine(array_values(ListingActions::ACTIONS), array_values($la))), fn ($k) => tv_e($k)) ?></section>

  <section class="in-card"><h2>Let's Explore, by view</h2><p class="in-what">Which views people use.</p>
    <?= $bar(array_column(array_map(fn ($r) => $r + ['k' => $r['label']], $exploreViews), null, 'k'), fn ($k, $r) => '<a href="' . tv_e($r['url']) . '">' . tv_e($k) . '</a>') ?></section>

  <section class="in-card"><h2>What people search for</h2><p class="in-what">Searched by <?= PlatformCounts::MIN_VISITS ?> or more visits (rarer words are never shown).</p>
    <?= $bar(array_combine(array_map(fn ($k) => substr($k, 2), array_keys($topQ)), array_values($topQ)) ?: [], fn ($k) => '<a href="/directory/?q=' . rawurlencode($k) . '">' . tv_e($k) . '</a>') ?><?= $held($heldQ, 'different term') ?></section>

  <section class="in-card"><h2>Gaps: searches that found nothing</h2><p class="in-what">What people looked for and didn't find. Leads for the crawler and for new listings. Everything search didn't catch, by words and area: <a class="underline text-amber-700" href="/admin/search-misses.php">Missed searches</a>.</p>
    <?= $bar($gapQ, fn ($k) => tv_e($k)) ?></section>

  <section class="in-card"><h2>None here, by place</h2><p class="in-what">Searches with none in the place, where it's found nearby: “words @ place”.</p>
    <?= $bar($noneHere, fn ($k) => tv_e($k)) ?></section>

  <section class="in-card"><h2>Where people search</h2><p class="in-what">The place each search was in.</p>
    <?= $bar(array_combine(array_map(fn ($k) => substr($k, 3), array_keys($whereQ)), array_values($whereQ)) ?: [], fn ($k) => tv_e($k)) ?></section>

  <section class="in-card in-wide"><h2>Searches by place</h2><p class="in-what">The search term, the place it was read in, how often, and the results found (on average). 0 found is a gap in that place.</p>
    <?php if (!$locQ): ?><p class="in-empty">Nothing to show yet: a term shows once <?= PlatformCounts::MIN_VISITS ?> visits search it in the same place, so one person's searches are never shown.</p><?php endif; ?>
    <?= $held($heldLoc, 'term-and-place pair') ?>
    <?php if ($locQ): ?>
    <div class="in-tbl"><table><thead><tr><th>Search term</th><th>Place</th><th>Searches</th><th>Results found</th></tr></thead><tbody>
    <?php foreach ($locQ as $r): ?><tr class="<?= $r['avg'] < 1 ? 'in-gap' : '' ?>"><td><a href="/directory/?q=<?= rawurlencode($r['q']) ?>"><?= tv_e($r['q']) ?></a></td><td><?= tv_e($r['place']) ?></td><td><?= number_format($r['n']) ?></td><td><?= $r['avg'] < 1 && $r['avg'] > 0 ? '&lt;1' : number_format($r['avg']) ?></td></tr><?php endforeach; ?>
    </tbody></table></div><?php endif; ?></section>

  <section class="in-card"><h2>What they open from a search</h2><p class="in-what">The kind of result opened, the map, and the nearby places offered when there are none here.</p>
    <?= $bar($clicks, fn ($k) => tv_e(['listing' => 'Listings', 'outdoors' => 'Outdoor places', 'story' => 'Stories & guides', 'group' => 'Groups', 'place' => 'Places', 'topic' => 'Topics', 'map' => 'The map', 'nearby' => 'Nearby (none here)'][$k] ?? $k)) ?></section>

  <section class="in-card"><h2>Recommendations and new listings</h2><p class="in-what">Taps on “Recommend one” and “Add a listing”.</p>
    <?= $bar($acts, fn ($k) => tv_e(['recommend' => 'Recommend one', 'add_listing' => 'Add a listing'][$k] ?? $k)) ?></section>

  <?php foreach ([['Most viewed listings', $topListings], ['Most read journeys', $topJourneys], ['Most viewed outdoor places', $topRec], ['Most viewed place pages', $topPlaces]] as [$h, $rows]): ?>
  <section class="in-card"><h2><?= tv_e($h) ?></h2><p class="in-what">Distinct visits.</p>
    <?= $bar(array_combine(array_map(fn ($r, $i) => $i . '|' . $r['label'], $rows, array_keys($rows)), $rows) ?: [], fn ($k, $r) => $r['url'] !== '' ? '<a href="' . tv_e($r['url']) . '">' . tv_e($r['label']) . '</a>' : tv_e($r['label'])) ?></section>
  <?php endforeach; ?>
</div>
<p class="in-note">Counts per day only. Nothing identifies a person, device or address: a visit is told apart only within its own session, and isn't stored. Staff pages and known bots aren't counted. Search words: numbers and email addresses are removed, words searched by fewer than <?= PlatformCounts::MIN_VISITS ?> visits are never shown, and are deleted after 90 days.</p>
<?php tv_page_end();
