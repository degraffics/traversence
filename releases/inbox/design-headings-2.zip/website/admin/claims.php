<?php
// /admin/claims.php: claims, requests on hold, owner changes waiting, and disputes (decisions/0070).
// Admins decide case by case: verify, keep as Managed by owner, ask for more, record a contact, decline, start a held
// request. ?doc=<claim id> streams a claim's document (the only way it's read).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/Claims.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$aid = (int) $me['id'];
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$ready = Claims::ready($pdo);

if ($ready && isset($_GET['doc'])) Claims::streamDocument($pdo, (int) $_GET['doc']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $ready) {
    $done = 'Done.';
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $id = (int) ($_POST['id'] ?? 0);
        $note = trim((string) ($_POST['note'] ?? ''));
        switch ((string) ($_POST['what'] ?? '')) {
            case 'verify':  Claims::verify($pdo, $id, $aid, 'admin', $note, !empty($_POST['group'])); $done = 'Verified. The owner was emailed.'; break;
            case 'contact': Claims::logContact($pdo, $id, $aid, (string) ($_POST['channel'] ?? 'call'), $note); $done = 'Noted.'; break;
            case 'ask':     Claims::askMore($pdo, $id, $aid, $note); $done = 'Sent to the claimant.'; break;
            case 'note':    if ($note !== '') Claims::note($pdo, $id, $note); $done = 'Noted.'; break;
            case 'decline': Claims::decline($pdo, $id, $aid, $note); $done = 'Declined. The claimant was emailed.'; break;
            case 'start':   Claims::startHeld($pdo, $id, $aid); $done = 'Started: they now manage the listing.'; break;
            case 'apply':   Claims::decideChange($pdo, $id, $aid, true); $done = 'Applied to the listing.'; break;
            case 'dismiss': Claims::decideChange($pdo, $id, $aid, false); $done = 'Dismissed.'; break;
            case 'dispute': Claims::decideDispute($pdo, $id, $aid, (string) ($_POST['decision'] ?? ''), $note); $done = 'Done. Both people were emailed.'; break;
            default: throw new InvalidArgumentException('Pick an action.');
        }
        $_SESSION['cl_flash'] = [true, $done];
    } catch (InvalidArgumentException $x) {
        $_SESSION['cl_flash'] = [false, $x->getMessage()];
    } catch (Throwable $x) {
        error_log('admin/claims.php: ' . $x->getMessage());
        $_SESSION['cl_flash'] = [false, 'Something went wrong: ' . $x->getMessage()];
    }
    header('Location: /admin/claims.php' . (!empty($_POST['anchor']) ? '#' . preg_replace('/[^a-z0-9-]/', '', (string) $_POST['anchor']) : ''));
    exit;
}
$flash = $_SESSION['cl_flash'] ?? null;
unset($_SESSION['cl_flash']);
if ($ready) Claims::purgeDocuments($pdo);
$queue = $ready ? Claims::queue($pdo) : [];
$claims = array_values(array_filter($queue, fn ($c) => $c['status'] === 'managed'));
$held = array_values(array_filter($queue, fn ($c) => $c['status'] === 'on_hold'));
$changes = $ready ? Claims::changesWaiting($pdo) : [];
$disputes = $ready ? Claims::disputesOpen($pdo) : [];
$names = [];
$who = function (?int $u) use ($pdo, &$names): string {
    if (!$u) return '';
    if (!isset($names[$u])) { $st = $pdo->prepare('SELECT COALESCE(NULLIF(display_name, \'\'), email) FROM users WHERE id = ?'); $st->execute([$u]); $names[$u] = (string) $st->fetchColumn(); }
    return $names[$u];
};

tv_page_start('Claims', ['section' => 'admin', 'active' => 'listings']);
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$ph = fn ($p) => Claims::fmtPhone((string) $p);
$form = function (array $c, string $anchor) use ($e, $csrf): string {
    return '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="id" value="' . (int) $c['id'] . '"><input type="hidden" name="anchor" value="' . $e($anchor) . '">';
};
?>
<style>
  .ck{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem 1.1rem;margin-top:.8rem}
  .ck.late{border-color:#B91C1C;box-shadow:0 0 0 1px #B91C1C inset}
  .ck-h{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.2rem;color:#3E2B1F;margin-top:1.4rem}
  .ck-s{font-size:.78rem;color:#8A7355}.ck-t{font-size:.85rem;color:#3E2B1F}
  .ck-b{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;border-radius:.6rem;padding:.35rem .8rem;cursor:pointer}
  .ck-b.go{background:#B8863B;border-color:#B8863B;color:#2A1B12}.ck-b.bad{background:#991B1B;border-color:#991B1B;color:#fff}
  .ck-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:.35rem .55rem;font-size:.82rem}
  .ck-pill{display:inline-block;font-size:.7rem;font-weight:700;border-radius:999px;padding:.1rem .55rem;background:#E3D3AC}
  .ck-pill.red{background:#FECACA;color:#7F1D1D}.ck-pill.grn{background:#8FBCA8}.ck-pill.amb{background:#F2C98A}
  .ck-grid{display:grid;grid-template-columns:auto 1fr;gap:.15rem .8rem;font-size:.82rem;margin-top:.5rem}.ck-grid dt{color:#8A7355}
  .ck-code{font-family:ui-monospace,monospace;font-weight:700}
  details.ck-act{margin-top:.6rem}details.ck-act summary{cursor:pointer;font-size:.82rem;font-weight:600;color:#92400E}
  .ck-row{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.5rem;align-items:center}
</style>
<div class="max-w-3xl">
  <h1 class="font-serif font-bold text-2xl text-[#3E2B1F]">Claims</h1>
  <p class="text-sm text-[#5C4632] mt-1">People claiming listings (decisions/0070). Step 1, an email code, makes them <b>Managed by owner</b>.
    Step 2 is a text of the claim's code to <b><?= $e(Claims::verifyNumber()) ?></b>: from the listed number, verify; from another number, contact them within 48 hours and decide.
    Your call, case by case.</p>
  <?php if ($flash): ?><p class="text-sm mt-2" style="color:<?= $flash[0] ? '#166534' : '#991B1B' ?>"><?= $e($flash[1]) ?></p><?php endif; ?>
  <?php if (!$ready): ?>
    <p class="tv-bleed ck text-sm">Run <code>app/migrations/2026-11-10_listing_claims.sql</code> first.</p>
  <?php else: ?>
  <p class="ck-s mt-2"><?= count($claims) ?> to confirm · <?= count($held) ?> on hold · <?= count($changes) ?> changes waiting · <?= count($disputes) ?> disputes</p>

  <?php if ($disputes): ?><h2 class="ck-h" id="disputes">Disputes</h2><?php endif;
  foreach ($disputes as $d): $ch = $d['claim_id'] ? Claims::get($pdo, (int) $d['claim_id']) : null; $h = Claims::holding($pdo, (int) $d['entity_id']); ?>
  <div class="tv-bleed ck" id="d<?= (int) $d['id'] ?>">
    <div class="flex justify-between gap-2 flex-wrap">
      <b><a class="underline text-[#92400E]" href="/listing/view.php?id=<?= (int) $d['entity_id'] ?>"><?= $e($d['listing']) ?></a></b>
      <span class="ck-s">filed <?= $e(substr((string) $d['created_at'], 0, 16)) ?> · answer due <?= $e(substr((string) $d['challenge_deadline'], 0, 10)) ?>
        <?= $d['accepted_at'] ? ' · <span class="ck-pill amb">edits frozen</span>' : '' ?></span>
    </div>
    <dl class="ck-grid">
      <dt>Filed by</dt><dd><?= $e($d['display_name'] ?: $d['email']) ?> (<?= $e($d['email']) ?>)<?= $ch && $ch['claimant_phone'] ? ' · ' . $e($ph($ch['claimant_phone'])) : '' ?></dd>
      <dt>Why</dt><dd style="white-space:pre-line"><?= $e($d['reason']) ?></dd>
      <?php if ($ch && $ch['doc_path'] !== ''): ?><dt>Their proof</dt><dd><a class="underline" target="_blank" href="/admin/claims.php?doc=<?= (int) $ch['id'] ?>"><?= $e($ch['doc_name'] ?: 'document') ?></a></dd><?php endif; ?>
      <dt>Owner now</dt><dd><?= $h ? $e($who((int) $h['user_id'])) . ' · ' . ($h['status'] === 'verified' ? 'verified' : 'managed') : 'none' ?></dd>
      <dt>Owner's answer</dt><dd style="white-space:pre-line"><?= $d['owner_answer'] ? $e($d['owner_answer']) : '<span class="ck-s">none yet</span>' ?></dd>
    </dl>
    <form method="post" class="mt-2"><?= $form($d, 'd' . $d['id']) ?><input type="hidden" name="what" value="dispute">
      <input class="ck-in" name="note" placeholder="Note (sent to both with the decision)">
      <div class="ck-row">
        <?php if (!$d['accepted_at']): ?><button class="ck-b" name="decision" value="accept" title="Freeze the owner's edits while you look">Look into it (freeze edits)</button><?php endif; ?>
        <button class="ck-b go" name="decision" value="kept">Keep the owner</button>
        <button class="ck-b" name="decision" value="transferred">Transfer to the filer</button>
        <button class="ck-b bad" name="decision" value="returned">Return to unclaimed</button>
      </div>
    </form>
  </div>
  <?php endforeach; ?>

  <h2 class="ck-h" id="claims">Claims to confirm</h2>
  <?php if (!$claims): ?><p class="tv-bleed ck text-sm">No claims waiting.</p><?php endif;
  foreach ($claims as $c): $d = $c['details']; $match = $c['listed_phone'] !== '' && $c['listed_phone'] === $c['claimant_phone']; $a = $d['appointment'] ?? null; ?>
  <div class="tv-bleed ck<?= $c['overdue'] ? ' late' : '' ?>" id="c<?= (int) $c['id'] ?>">
    <div class="flex justify-between gap-2 flex-wrap">
      <b><a class="underline text-[#92400E]" href="/listing/view.php?id=<?= (int) $c['entity_id'] ?>"><?= $e($c['listing']) ?></a></b>
      <span>
        <?php if ($c['overdue']): ?><span class="ck-pill red">Overdue</span><?php elseif ($c['due_at']): ?><span class="ck-s">contact by <?= $e(substr((string) $c['due_at'], 0, 16)) ?></span><?php else: ?><span class="ck-pill">contacted</span><?php endif; ?>
        <?= $c['group_n'] > 1 ? ' <span class="ck-pill amb">' . (int) $c['group_n'] . ' locations together</span>' : '' ?>
      </span>
    </div>
    <dl class="ck-grid">
      <dt>Claimant</dt><dd><?= $e($c['display_name'] ?: $c['email']) ?> · <?= $e($c['email']) ?><?= $c['role_note'] !== '' ? ' · ' . $e($c['role_note']) : '' ?></dd>
      <dt>Text code</dt><dd><span class="ck-code"><?= $e($c['text_code']) ?></span> to <?= $e(Claims::verifyNumber()) ?></dd>
      <dt>Listed phone</dt><dd><?= $c['listed_phone'] !== '' ? $e($ph($c['listed_phone'])) : '<span class="ck-s">none on the listing</span>' ?></dd>
      <dt>Texting from</dt><dd><?= $c['claimant_phone'] !== '' ? $e($ph($c['claimant_phone'])) . ($match ? ' <span class="ck-pill grn">same as listed</span>' : ' <span class="ck-pill">a different number</span>') : '<span class="ck-s">not given</span>' ?></dd>
      <?php if (!empty($d['domain_email'])): ?><dt>Domain email</dt><dd><?= $e($d['domain_email']) ?> (code sent, not entered yet)</dd><?php endif; ?>
      <?php if ($c['doc_path'] !== ''): ?><dt>Document</dt><dd><a class="underline" target="_blank" href="/admin/claims.php?doc=<?= (int) $c['id'] ?>"><?= $e($c['doc_name'] ?: 'open') ?></a></dd><?php endif; ?>
      <?php if ($a): ?><dt>Appointment</dt><dd><b><?= $e($a['how'] === 'visit' ? 'On-site visit' : 'Phone call') ?></b>, <?= $e(str_replace('T', ' ', (string) $a['when'])) ?> · <?= $e($ph($a['phone'])) ?> · <?= $e($a['email']) ?><?= $a['address'] !== '' ? ' · ' . $e($a['address']) : '' ?></dd><?php endif; ?>
      <dt>Claimed</dt><dd><?= $e(substr((string) $c['created_at'], 0, 16)) ?></dd>
      <?php if ($c['contact_log']): ?><dt>Contact</dt><dd><?php foreach ($c['contact_log'] as $l): ?><div><?= $e($l['at']) ?> · <?= $e($l['channel']) ?> · <?= $e($l['note']) ?> <span class="ck-s">(<?= $e($who((int) $l['by'])) ?>)</span></div><?php endforeach; ?></dd><?php endif; ?>
      <?php if ($c['admin_note']): ?><dt>Notes</dt><dd style="white-space:pre-line"><?= $e($c['admin_note']) ?></dd><?php endif; ?>
    </dl>
    <form method="post" class="ck-row"><?= $form($c, 'c' . $c['id']) ?>
      <input class="ck-in" style="flex:1 1 14rem" name="note" placeholder="Note (optional)">
      <?php if ($c['group_n'] > 1): ?><label class="ck-s"><input type="checkbox" name="group" value="1" checked> all <?= (int) $c['group_n'] ?> locations</label><?php endif; ?>
      <button class="ck-b go" name="what" value="verify">✓ Verify</button>
      <button class="ck-b" name="what" value="note" title="Leave it Managed by owner, with a note">Keep as managed</button>
    </form>
    <details class="ck-act"><summary>Record a contact, ask for more, or decline</summary>
      <form method="post" class="ck-row"><?= $form($c, 'c' . $c['id']) ?><input type="hidden" name="what" value="contact">
        <select class="ck-in" style="width:auto" name="channel">
          <option value="text-listed">Text received from the listed number</option><option value="text-other">Text received from another number</option>
          <option value="call">Called the claimant</option><option value="call-listed">Called the listed number</option><option value="visit">Visited</option><option value="email">Emailed</option>
        </select>
        <input class="ck-in" style="flex:1 1 12rem" name="note" placeholder="What you found">
        <button class="ck-b">Save</button>
      </form>
      <form method="post" class="ck-row"><?= $form($c, 'c' . $c['id']) ?><input type="hidden" name="what" value="ask">
        <input class="ck-in" style="flex:1 1 14rem" name="note" placeholder="What you need from them (emailed)"><button class="ck-b">Ask</button>
      </form>
      <form method="post" class="ck-row" data-confirm="Decline this claim? The listing returns to unclaimed." data-yes="Decline" data-danger><?= $form($c, 'c' . $c['id']) ?><input type="hidden" name="what" value="decline">
        <input class="ck-in" style="flex:1 1 14rem" name="note" placeholder="Reason (emailed to them)"><button class="ck-b bad">Decline</button>
      </form>
    </details>
  </div>
  <?php endforeach; ?>

  <h2 class="ck-h" id="held">Requests on hold</h2>
  <?php if (!$held): ?><p class="tv-bleed ck text-sm">None.</p><?php endif;
  foreach ($held as $c): $d = $c['details']; $h = Claims::holding($pdo, (int) $c['entity_id']); ?>
  <div class="tv-bleed ck" id="h<?= (int) $c['id'] ?>">
    <div class="flex justify-between gap-2 flex-wrap">
      <b><a class="underline text-[#92400E]" href="/listing/view.php?id=<?= (int) $c['entity_id'] ?>"><?= $e($c['listing']) ?></a></b>
      <span class="ck-pill amb">Notice: second request</span>
    </div>
    <dl class="ck-grid">
      <dt>Asked by</dt><dd><?= $e($c['display_name'] ?: $c['email']) ?> · <?= $e($c['email']) ?><?= ($d['role'] ?? $c['role_note']) ? ' · ' . $e($d['role'] ?? $c['role_note']) : '' ?><?= !empty($d['phone']) ? ' · ' . $e($ph($d['phone'])) : '' ?></dd>
      <?php if (!empty($d['note'])): ?><dt>Their note</dt><dd style="white-space:pre-line"><?= $e($d['note']) ?></dd><?php endif; ?>
      <?php if ($c['doc_path'] !== ''): ?><dt>Document</dt><dd><a class="underline" target="_blank" href="/admin/claims.php?doc=<?= (int) $c['id'] ?>"><?= $e($c['doc_name'] ?: 'open') ?></a></dd><?php endif; ?>
      <dt>Listing now</dt><dd><?= $h ? $e($who((int) $h['user_id'])) . ' · ' . ($h['status'] === 'verified' ? 'verified' : 'managed') . ' · <a class="underline" href="#c' . (int) $h['id'] . '">their claim</a>' : 'free: you can start this request' ?></dd>
      <dt>Asked</dt><dd><?= $e(substr((string) $c['created_at'], 0, 16)) ?></dd>
    </dl>
    <form method="post" class="ck-row"><?= $form($c, 'h' . $c['id']) ?>
      <input class="ck-in" style="flex:1 1 14rem" name="note" placeholder="Note (optional)">
      <?php if (!$h): ?><button class="ck-b go" name="what" value="start">Start as the claim</button><?php endif; ?>
      <button class="ck-b" name="what" value="note">Note</button>
      <button class="ck-b bad" name="what" value="decline" data-confirm="Decline this request? They are emailed." data-yes="Decline" data-danger>Decline</button>
    </form>
  </div>
  <?php endforeach; ?>

  <h2 class="ck-h" id="changes">Owner changes waiting</h2>
  <p class="ck-s">Name, phone, address and website changes from listings that are Managed by owner (not verified yet).</p>
  <?php if (!$changes): ?><p class="tv-bleed ck text-sm">None.</p><?php endif;
  foreach ($changes as $ch): ?>
  <div class="tv-bleed ck" id="x<?= (int) $ch['id'] ?>">
    <b><a class="underline text-[#92400E]" href="/listing/view.php?id=<?= (int) $ch['entity_id'] ?>"><?= $e($ch['listing']) ?></a></b> <span class="ck-s">· <?= $e($ch['field']) ?> · by <?= $e($who((int) $ch['user_id'])) ?> · <?= $e(substr((string) $ch['created_at'], 0, 16)) ?></span>
    <dl class="ck-grid"><dt>Now</dt><dd><?= $ch['old_value'] !== '' ? $e($ch['old_value']) : '<span class="ck-s">empty</span>' ?></dd><dt>Change to</dt><dd><b><?= $e($ch['new_value']) ?></b></dd></dl>
    <form method="post" class="ck-row"><?= $form($ch, 'changes') ?><button class="ck-b go" name="what" value="apply">Apply</button><button class="ck-b" name="what" value="dismiss">Dismiss</button></form>
  </div>
  <?php endforeach; ?>
  <?php endif; ?>
</div>
<?php tv_page_end();
