<?php
// /guide/how.php?id=3 — a how-to guide (decisions/0063 §8): steps the crawler gathered from official how-to pages
// (extension services, government pages), put in our words and checked by a person before it shows. Each step names
// its source. Content page standard (decisions/0058 §20): header with the kind (searches for more), the title and the
// Link button; Engage bar; the steps; who can help; comments.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/HowGuides.php';

$pdo = Database::connection();
$g = HowGuides::get($pdo, (int) ($_GET['id'] ?? 0));
if ($g && $g['status'] !== 'published') $g = null;   // nothing shows before a person publishes it
$title = $g ? (string) $g['title'] : 'Guide not found';
if (!$g) http_response_code(404);
tv_page_start($title, ['no_crumbs' => true, 'description' => $g ? 'A how-to guide, with each step\'s official source.' : '']);
if (!$g): ?>
  <div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Guide not found</h1><p class="text-sm text-[#5C4632] mt-2">It may not be published yet.</p></div>
<?php tv_page_end(); exit; endif;
tv_count_item('how:' . (int) $g['id']);   // the platform's counts
require_once __DIR__ . '/../../app/ui/engage-ui.php';
$words = mb_strtolower(trim(preg_replace('/^how to\s+/i', '', $title)));
$help = '';
if ($g['situation'] !== '') { try { $st = $pdo->prepare("SELECT label FROM situations WHERE slug = ? AND status = 'live'"); $st->execute([$g['situation']]); $help = (string) $st->fetchColumn(); } catch (Throwable) {} }
?>
<style>
  .hw{max-width:46rem}
  .hw-head{position:relative;background:#FFFBF2;border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.8rem 3rem .8rem .9rem}
  .hw-kick{font-size:.7rem;letter-spacing:.09em;text-transform:uppercase;color:#8A7355;margin:0}
  .hw-q{background:none;border:0;padding:0;font:inherit;letter-spacing:inherit;text-transform:inherit;color:#92400E;cursor:pointer;text-decoration:underline;text-decoration-color:rgba(146,64,14,.3);text-underline-offset:3px}
  .hw-head h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.45rem;color:#3E2B1F;margin:.25rem 0 .1rem}
  .hw-intro{font-size:.93rem;line-height:1.6;color:#3E2B1F;margin:.5rem 0 0}
  .hw-eng{margin:.6rem 0}
  .hw-steps{list-style:none;margin:.6rem 0 0;padding:0;display:grid;gap:.5rem;counter-reset:st}
  .hw-steps li{position:relative;background:#FFFBF2;border:1px solid rgba(203,185,141,.75);border-radius:.5rem;padding:.65rem .8rem .65rem 2.8rem;font-size:.95rem;line-height:1.55;color:#3E2B1F;counter-increment:st}
  .hw-steps li::before{content:counter(st);position:absolute;left:.7rem;top:.6rem;width:1.5rem;height:1.5rem;border-radius:999px;background:#8FBCA8;color:#1F3B30;font-weight:700;font-size:.8rem;display:flex;align-items:center;justify-content:center}
  .hw-steps sup a{color:#92400E;font-size:.7rem;text-decoration:none;margin-left:.15rem}
  .hw-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.7rem .9rem;margin-top:.8rem}
  .hw-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1rem;margin:0 0 .3rem;color:#3E2B1F}
  .hw-src{margin:0;padding-left:1.2rem;font-size:.84rem;color:#5C4632}.hw-src a{color:#92400E;text-decoration:underline;word-break:break-word}
  .hw-note{font-size:.8rem;color:#5C4632;margin:.6rem 0 0}
  .hw-b{display:inline-block;margin-top:.3rem;font-size:.85rem;font-weight:600;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.35rem .8rem;cursor:pointer}
</style>
<div class="hw">
  <header class="hw-head tv-bleed" data-link-host>
    <span data-link="place:how:<?= (int) $g['id'] ?>" data-link-label="<?= tv_e($title) ?>"></span>
    <p class="hw-kick"><button type="button" class="hw-q" data-q="how to" title="More how-to guides">How-to guide</button></p>
    <h1><?= tv_e($title) ?></h1>
    <?php require_once __DIR__ . '/../../app/lib/GuideLinks.php'; $hwL = fn (string $sec, string $html) => GuideLinks::linkify($pdo, 'howto:' . (int) $g['id'], $sec, $html);   // highlighted names (decisions/0132) ?>
    <?php if ($g['intro'] !== ''): ?><p class="hw-intro"><?= $hwL('intro', tv_e((string) $g['intro'])) ?></p><?php endif; ?>
  </header>
  <div class="hw-eng"><?= tv_engage_bar($pdo, 'how', (string) $g['id'], ['title' => $title]) ?></div>
  <ol class="hw-steps">
    <?php foreach ($g['steps'] as $s): $src = $g['sources'][(int) $s['src'] - 1] ?? null; ?>
      <li class="tv-bleed"><?= $hwL('steps', tv_e((string) $s['text'])) ?><?php if ($src): ?><sup><a href="#src<?= (int) $s['src'] ?>" title="Source: <?= tv_e($src['host']) ?>">[<?= (int) $s['src'] ?>]</a></sup><?php endif; ?></li>
    <?php endforeach; ?>
  </ol>
  <section class="hw-card tv-bleed"><h2>Sources</h2>
    <ol class="hw-src">
      <?php foreach ($g['sources'] as $i => $src): ?><li id="src<?= $i + 1 ?>"><a href="<?= tv_e($src['url']) ?>" target="_blank" rel="noopener"><?= tv_e($src['title'] !== '' ? $src['title'] : $src['host']) ?></a> <small>(<?= tv_e($src['host']) ?>)</small></li><?php endforeach; ?>
    </ol>
    <p class="hw-note">Gathered from official how-to pages (extension services and government agencies), put in our own words and checked by our team. Their pages have the details.</p>
  </section>
  <section class="hw-card tv-bleed"><h2>Rather have someone do it?</h2>
    <p class="hw-note" style="margin-top:0"><?= $help !== '' ? 'See who helps with ' . tv_e(mb_strtolower($help)) . ' near you.' : 'See who does it near you.' ?></p>
    <button type="button" class="hw-b" data-q="<?= tv_e($words) ?>">Find someone near you</button>
  </section>
  <p class="hw-note"><button type="button" class="underline" data-tv-suggest="<?= tv_e(json_encode(['target' => 'how:' . (int) $g['id'], 'target_name' => $title, 'topic' => 'help'], JSON_UNESCAPED_UNICODE)) ?>">A step wrong or missing? Tell us</button></p>
  <?= tv_engage_comments($pdo, 'how', (string) $g['id']) ?>
</div>
<script>
  document.querySelector('.hw').addEventListener('click', function (e) { var b = e.target.closest('[data-q]'); if (b && window.TvSearch) TvSearch.open(b.getAttribute('data-q')); });
</script>
<script src="/js/link-button.js?v=<?= (int) @filemtime(__DIR__ . '/../js/link-button.js') ?>" defer></script>
<?php echo '<script src="/js/tv-tagcard.js" defer></script>';   // the preview card of a highlighted name (decisions/0132)
tv_page_end();
