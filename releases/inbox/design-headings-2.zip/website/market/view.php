<?php
// market/view.php?id= — one Marketplace post (decisions/0031, 0135). Facebook Marketplace's item page is the base:
// the photos with a strip of thumbnails, the price and title, "Listed 3 days ago in Show Low", Message at the top and a
// quick message lower down ("Hi, is this available?"), the details, and the seller on their own card (name, since when,
// how many sold, the Link button). No Buy button and no checkout: no payment passes through Traversence (0135 §6).
// No public comments on a post: buyers talk to the seller in messages. Views, Share, QR and Report are the engage bar's.
// Roughly where only: the town or area the seller picked, never an address (0031).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/Market.php';
require_once __DIR__ . '/../../app/lib/MarketOffers.php';
require_once __DIR__ . '/../../app/ui/market-ui.php';

$pdo = Database::connection();
$uid = Auth::currentUserId();
$p = Market::ready($pdo) ? Market::get($pdo, (int) ($_GET['id'] ?? 0)) : null;
$staff = false;
if ($uid) { try { $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('admin_access') . ' WHERE user_id = ? LIMIT 1'); $st->execute([$uid]); $staff = (bool) $st->fetchColumn(); } catch (Throwable) {} }
if (!$p || !Market::canSee($pdo, $p, $uid, $staff)) {
    http_response_code(404);
    tv_page_start('Not on the Marketplace', ['no_crumbs' => true]);
    echo '<div class="text-center py-10"><h1 class="font-serif font-bold text-2xl mb-2">This post isn&rsquo;t up</h1><p class="text-sm">It may have sold or come off the Marketplace. <a class="underline" href="/market/">See what&rsquo;s there now</a></p></div>';
    tv_page_end();
    exit;
}
$id = (int) $p['id'];
$own = $uid && (int) $p['user_id'] === $uid;
$shown = in_array($p['status'], Market::SHOWN, true);
$photos = Market::photos($pdo, $id);
$seller = Market::seller($pdo, (int) $p['user_id']);
$more = $shown ? Market::moreFrom($pdo, (int) $p['user_id'], $id, 6, $uid) : [];
$saved = $uid && !$own && Market::isSaved($pdo, $uid, $id);
$offersOn = MarketOffers::ready($pdo);
$offers = $offersOn && $uid ? MarketOffers::forPost($pdo, $id, $uid) : [];   // the seller sees every offer; a buyer, their own
$openMine = array_values(array_filter($offers, fn ($o) => $o['role'] === 'buyer' && in_array($o['status'], MarketOffers::OPEN, true)));
$trades = $offersOn ? MarketOffers::trades($pdo, (int) $p['user_id']) : 0;
$notes = $offersOn ? MarketOffers::notesAbout($pdo, (int) $p['user_id'], 3) : [];
$fields = json_decode((string) ($p['fields'] ?? ''), true) ?: [];
if ($p['item_condition'] !== '') $fields = ['Condition' => Market::CONDITIONS[$p['item_condition']] ?? $p['item_condition']] + $fields;
$when = Market::ago($p['listed_at'] ?: $p['created_at']);
$notice = [
    'held' => ['info', 'Waiting for a look:', ($p['hold_note'] ?: 'A person looks before it shows.') . ' Only you' . ($staff && !$own ? ', the seller' : '') . ' and our team can see it.'],
    'pending' => ['info', 'Pending:', 'The seller has someone lined up. You can still message them in case it falls through.'],
    'sold' => ['ok', 'Sold:', 'This one has gone. Only the seller and our team see this page.'],
    'paused' => ['info', 'Off for now:', 'The seller took it off the Marketplace for now.'],
    'expired' => ['info', 'Expired:', 'Nobody confirmed it was still available, so it came off. The seller can put it back up in one tap.'],
    'removed' => ['bad', 'Taken down:', (string) $p['staff_note']],
][$p['status']] ?? null;
if (Market::isTest($p)) $notice = ['info', 'Test post:', 'Only our team sees it. Offers, messages and Sold / Got it work as usual between team members; nothing counts in the numbers or trust points.' . ($notice ? ' ' . $notice[1] . ' ' . $notice[2] : '')];
if ($own && $p['status'] === 'active' && $p['asked_at'] !== null) $notice = ['info', 'Still available?', 'Confirm it in Your posts, or it comes off at the next check.'];

tv_page_start($p['title'], ['no_crumbs' => true, 'description' => mb_strimwidth(Market::price($p) . ' · ' . $p['place_label'] . ' · ' . trim((string) $p['about']), 0, 180, '…')]);
if ($shown && !Market::isTest($p)) tv_count_item('market:' . $id);   // the platform's counts (never who)
echo tv_market_css();
?>
<style>
  .mv{max-width:64rem;display:grid;gap:1.2rem;grid-template-columns:minmax(0,3fr) minmax(0,2fr);align-items:start}
  .mv-gal{position:relative;background:#2A1B12;border-radius:.9rem;overflow:hidden}
  .mv-main{aspect-ratio:4/3;display:flex;align-items:center;justify-content:center}
  .mv-main img{max-width:100%;max-height:100%;object-fit:contain;display:block}
  .mv-main .ta-svg{width:56px;height:56px;color:#B8863B;opacity:.6}
  .mv-strip{display:flex;gap:4px;padding:4px;overflow-x:auto;scrollbar-width:none;background:#1E140C}.mv-strip::-webkit-scrollbar{display:none}
  .mv-strip button{flex:0 0 auto;width:62px;height:62px;border:2px solid transparent;border-radius:.4rem;padding:0;overflow:hidden;cursor:pointer;background:#3E2B1F}
  .mv-strip button[aria-current="true"]{border-color:#8FBCA8}
  .mv-strip img{width:100%;height:100%;object-fit:cover;display:block}
  .mv-side{display:grid;gap:.8rem}
  .mv-head{position:relative;padding-right:5.2rem}
  .mv-kind{display:inline-block;font-size:.72rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#92400E;text-decoration:none;border:1px solid #CBB98D;border-radius:999px;padding:.12rem .55rem;background:#FFFBF2}
  .mv h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.4rem,3.4vw,1.9rem);line-height:1.15;color:#3E2B1F;margin:.35rem 0 .15rem;overflow-wrap:anywhere}
  .mv-price{font-size:1.35rem;font-weight:700;color:#3E2B1F}
  .mv-where{font-size:.86rem;color:#5C4632;margin-top:.2rem}.mv-where a{color:#92400E;text-decoration:underline}
  .mv-acts{position:absolute;top:0;right:0;display:flex;gap:.35rem}
  .mv-ib{width:34px;height:34px;border-radius:999px;border:1.5px solid #B8863B;background:#FFFBF2;color:#B45309;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0;text-decoration:none}
  .mv-ib .ta-svg{width:16px;height:16px}
  .mv-ib[aria-pressed="true"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .mv-ib[aria-pressed="true"] .ta-svg{fill:currentColor}
  .mv-msgb{display:flex;align-items:center;justify-content:center;gap:.45rem;background:#3E2B1F;color:#FFFBF2;border:0;border-radius:999px;padding:.6rem 1rem;font-weight:700;font-size:.95rem;text-decoration:none;cursor:pointer;width:100%}
  .mv-msgb .ta-svg{width:17px;height:17px}
  .mv-card{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;padding:.85rem .95rem}
  .mv-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.08rem;color:#3E2B1F;margin:0 0 .45rem}
  .mv-dl{display:grid;grid-template-columns:auto 1fr;gap:.25rem .9rem;font-size:.9rem;margin:0 0 .5rem}.mv-dl dt{color:#8A7355}.mv-dl dd{margin:0;color:#3E2B1F}
  .mv-about{font-size:.95rem;line-height:1.6;color:#3E2B1F;white-space:pre-line;overflow-wrap:anywhere}
  .mv-q textarea{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem .6rem;font:inherit;font-size:.92rem;background:#fff;color:#3E2B1F}
  .mv-q .row{display:flex;gap:.5rem;align-items:center;margin-top:.45rem;flex-wrap:wrap}
  .mv-b{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.4rem .9rem;font-size:.86rem;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block}
  .mv-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFFBF2}
  .mv-seller{position:relative;padding-right:3rem}
  .mv-seller a.nm{color:#92400E;text-decoration:underline;font-weight:700;font-size:1rem}
  .mv-seller small{display:block;color:#8A7355;font-size:.8rem;margin-top:.15rem}
  .mv-safe{font-size:.8rem;color:#5C4632;line-height:1.5}
  .mv-notes{margin-top:.55rem;border-top:1px solid #EADFC4;padding-top:.45rem}
  .mv-note{font-size:.86rem;color:#3E2B1F;margin:.3rem 0;overflow-wrap:anywhere}.mv-note small{display:block;color:#8A7355;font-size:.74rem;margin-top:.1rem}
  .mv-rep{border:0;background:none;color:#8A7355;text-decoration:underline;cursor:pointer;font:inherit;padding:0}
  .mv-more{grid-column:1/-1}.mv-more h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.15rem;color:#3E2B1F;margin:.4rem 0 .5rem}
  .mv-full{grid-column:1/-1}
  @media (max-width:767px){.mv{grid-template-columns:minmax(0,1fr);gap:.7rem}.mv-gal{border-radius:.5rem}.mv-main{aspect-ratio:1/1}}
</style>
<div class="mv">
  <?php if ($notice): ?><p class="mv-full" data-tv-status="<?= $notice[0] ?>" data-tv-label="<?= tv_e($notice[1]) ?>"><?= tv_e($notice[2]) ?></p><?php endif; ?>
  <section class="mv-gal tv-bleed" aria-label="Photos">
    <div class="mv-main" id="mv-main"><?php if ($photos): ?><img src="<?= tv_e($photos[0]['full']) ?>" alt="<?= tv_e($photos[0]['alt'] ?: $p['title']) ?>"><?php else: echo tv_icon('store'); endif; ?></div>
    <?php if (count($photos) > 1): ?><div class="mv-strip" role="list"><?php foreach ($photos as $i => $ph): ?><button type="button" role="listitem" data-full="<?= tv_e($ph['full']) ?>" aria-current="<?= $i ? 'false' : 'true' ?>" aria-label="Photo <?= $i + 1 ?> of <?= count($photos) ?>"><img src="<?= tv_e($ph['card']) ?>" alt="" loading="lazy"></button><?php endforeach; ?></div><?php endif; ?>
  </section>

  <div class="mv-side">
    <div class="mv-head">
      <a class="mv-kind" href="/market/?category=<?= rawurlencode((string) $p['category']) ?>"><?= tv_e($p['category'] ?: Market::KINDS[$p['kind']]) ?></a>
      <h1><?= tv_e($p['title']) ?></h1>
      <div class="mv-price"><?= tv_e(Market::price($p)) ?></div>
      <div class="mv-where">Listed <?= tv_e($when) ?> in <a href="/market/?place=<?= rawurlencode((string) $p['place_key']) ?>"><?= tv_e($p['place_label']) ?></a></div>
      <span class="mv-acts">
        <?php if (!$own && $shown): ?><button type="button" class="mv-ib" data-mk-save="<?= $id ?>" aria-pressed="<?= $saved ? 'true' : 'false' ?>" title="<?= $saved ? 'Saved' : 'Save' ?>" aria-label="<?= $saved ? 'Saved: tap to unsave' : 'Save' ?>"><?= tv_icon('bookmark') ?></button>
        <a class="mv-ib" href="#mv-q" title="Message the seller" aria-label="Message the seller"><?= tv_icon('contact') ?></a><?php endif; ?>
      </span>
    </div>
    <?php if ($shown) { require_once __DIR__ . '/../../app/ui/engage-ui.php'; echo tv_engage_bar($pdo, 'mkt', (string) $id, ['title' => $p['title'], 'likes' => false, 'comments' => false, 'report' => $uid && !$own ? 'market_post:' . $id : '']); } ?>
    <?php if ($own): ?>
      <a class="mv-msgb" href="/user/market/?edit=<?= $id ?>"><?= tv_icon('pen') ?>Edit or mark sold</a>
    <?php elseif ($shown && $p['status'] !== 'sold'): ?>
      <a class="mv-msgb" href="#mv-q" data-mv-msg><?= tv_icon('contact') ?>Message the seller</a>
    <?php endif; ?>

    <?php if ($fields || trim((string) $p['about']) !== ''): ?>
    <section class="mv-card tv-bleed"><h2>Details</h2>
      <?php if ($fields): ?><dl class="mv-dl"><?php foreach ($fields as $k => $v): ?><dt><?= tv_e($k) ?></dt><dd><?= tv_e($v) ?></dd><?php endforeach; ?></dl><?php endif; ?>
      <?php if (trim((string) $p['about']) !== ''): ?><div class="mv-about"><?= tv_e($p['about']) ?></div><?php endif; ?>
    </section>
    <?php endif; ?>

    <?php if ($own && $offers): ?>
    <section class="mv-card tv-bleed" id="mv-offers"><h2>Offers</h2>
      <?php foreach ($offers as $o) echo tv_market_offer($o); ?>
    </section>
    <?php elseif (!$own && $shown && $offersOn): ?>
    <section class="mv-card tv-bleed" id="mv-offer"><h2><?= $p['price_mode'] === 'free' ? 'Ask for it' : 'Make an offer' ?></h2>
      <?php if ($offers) foreach ($offers as $o) echo tv_market_offer($o); ?>
      <?php if (!$uid): ?>
        <p class="text-sm"><a class="mv-b go" href="/login.php?next=<?= rawurlencode('/market/view.php?id=' . $id . '#mv-offer') ?>">Sign in to make an offer</a></p>
      <?php elseif (!$openMine): ?>
        <div class="mv-q"><div class="row" style="margin-top:0">
          <?php if ($p['price_mode'] !== 'free'): ?><label class="mv-safe" style="display:flex;align-items:center;gap:.35rem">$ <input type="number" id="mv-amt" min="0.01" step="0.01" inputmode="decimal" value="<?= $p['price_mode'] === 'fixed' && $p['price_cents'] !== null ? tv_e(rtrim(rtrim(number_format((int) $p['price_cents'] / 100, 2, '.', ''), '0'), '.')) : '' ?>" aria-label="Your offer in dollars" style="width:7rem;border:1px solid #CBB98D;border-radius:.5rem;padding:.4rem .5rem"></label><?php endif; ?>
          <button type="button" class="mv-b go" id="mv-offer-send"><?= $p['price_mode'] === 'free' ? 'I\'d like it' : 'Send offer' ?></button></div>
          <p class="mv-safe" style="margin:.4rem 0 0">The seller can accept, counter or decline. Once you agree and meet, the seller taps Sold and you tap Got it. No payment passes through Traversence.</p></div>
      <?php endif; ?>
    </section>
    <?php endif; ?>

    <?php if (!$own && $shown): ?>
    <section class="mv-card mv-q tv-bleed" id="mv-q"><h2>Message the seller</h2>
      <?php if ($uid): ?>
        <textarea id="mv-body" rows="3" maxlength="2000" aria-label="Your message">Hi, is this available?</textarea>
        <div class="row"><button type="button" class="mv-b go" id="mv-send">Send</button><span class="mv-safe">They see your name, never your email.</span></div>
      <?php else: ?>
        <p class="text-sm"><a class="mv-b go" href="/login.php?next=<?= rawurlencode('/market/view.php?id=' . $id . '#mv-q') ?>">Sign in to message</a></p>
      <?php endif; ?>
    </section>
    <?php endif; ?>

    <section class="mv-card mv-seller tv-bleed" data-link-host><h2>Seller</h2>
      <?php if (!$own): ?><span data-link="person:<?= (int) $seller['id'] ?>" data-link-label="<?= tv_e($seller['name']) ?>"></span><?php endif; ?>
      <a class="nm" href="<?= tv_e($seller['url']) ?>"><?= tv_e($seller['name']) ?></a>
      <small><?= $seller['since'] !== '' ? 'On Traversence since ' . tv_e($seller['since']) : '' ?><?= $seller['sold'] ? ' · ' . (int) $seller['sold'] . ' sold here' : '' ?><?= $trades ? ' · ' . $trades . ' confirmed trade' . ($trades === 1 ? '' : 's') : '' ?><?= $seller['showing'] > 1 ? ' · ' . (int) $seller['showing'] . ' posts up' : '' ?></small>
      <?php if ($notes): ?><div class="mv-notes"><?php foreach ($notes as $n): ?><p class="mv-note">&ldquo;<?= tv_e($n['body']) ?>&rdquo; <small><?= tv_e($n['from']) ?> · <?= tv_e($n['role']) ?> · <?= tv_e($n['when']) ?><?php if ($uid): ?> · <button type="button" class="mv-rep" data-note-report="<?= (int) $n['id'] ?>">Report</button><?php endif; ?></small></p><?php endforeach; ?></div><?php endif; ?>
    </section>

    <p class="mv-safe"><b>Roughly where:</b> <?= tv_e($p['place_label']) ?>. Agree the exact spot in messages, and meet somewhere public. Never send a deposit or payment to someone you haven&rsquo;t met: no one from Traversence will ever ask you to pay through the site.</p>
  </div>

  <?php if ($more): ?>
  <section class="mv-more"><h2>More from <?= tv_e($seller['name']) ?></h2>
    <div class="mk-grid"><?php foreach ($more as $c) echo tv_market_card($c, false, (bool) $uid); ?></div>
  </section>
  <?php endif; ?>
</div>
<?= tv_market_js() ?>
<script src="/js/link-button.js" defer></script>
<script>
(function () {
  var main = document.getElementById('mv-main');
  document.querySelectorAll('.mv-strip button').forEach(function (b) {
    b.addEventListener('click', function () {
      var img = main.querySelector('img'); if (img) img.src = b.getAttribute('data-full');
      document.querySelectorAll('.mv-strip button').forEach(function (x) { x.setAttribute('aria-current', x === b ? 'true' : 'false'); });
    });
  });
  var send = document.getElementById('mv-send');
  if (send) send.addEventListener('click', function () {
    var body = document.getElementById('mv-body');
    if (!body.value.trim()) { TvAsk.say('Write a message first.', { anchor: send, bad: true }); return; }
    send.disabled = true;
    tvMarketPost({ action: 'message', id: <?= $id ?>, body: body.value }).then(function (d) {
      TvAsk.say(d.message + ' ', { anchor: send });
      var a = document.createElement('a'); a.href = d.url; a.className = 'mv-b'; a.textContent = 'Open your messages'; send.insertAdjacentElement('afterend', a);
      body.value = '';
    }).catch(function (x) { TvAsk.say(x.message, { anchor: send, bad: true }); }).then(function () { send.disabled = false; });
  });
  var os = document.getElementById('mv-offer-send');
  if (os) os.addEventListener('click', function () {
    var amt = document.getElementById('mv-amt');
    if (amt && !amt.value.trim()) { TvAsk.say('Enter your offer in dollars.', { anchor: os, bad: true }); return; }
    os.disabled = true;
    tvMarketPost({ action: 'offer', id: <?= $id ?>, amount: amt ? amt.value : '' }).then(function (d) { TvAsk.say(d.message, { anchor: os }); setTimeout(function () { location.reload(); }, 1300); })
      .catch(function (x) { TvAsk.say(x.message, { anchor: os, bad: true }); os.disabled = false; });
  });
  document.addEventListener('click', function (e) {
    var r = e.target.closest('[data-note-report]'); if (!r) return;
    TvAsk.ask('What\'s wrong with this note? Our team reads it.', '', { anchor: r, multiline: true }).then(function (why) {
      if (why === null) return;
      fetch('/api/auth/session.php', { credentials: 'include' }).then(function (x) { return x.json(); }).then(function (s) {
        return fetch('/api/engage.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': s.csrf_token || '' },
          body: JSON.stringify({ action: 'report', what: 'market_note', id: +r.getAttribute('data-note-report'), reason: 'other', note: why }) });
      }).then(function (x) { return x.json(); }).then(function (d) { TvAsk.say(d.ok ? 'Thank you. Our team will look at it.' : ((d.error && d.error.message) || 'That didn\'t send.'), { anchor: r, bad: !d.ok }); });
    });
  });
  document.querySelectorAll('[data-mv-msg]').forEach(function (a) { a.addEventListener('click', function () { setTimeout(function () { var t = document.getElementById('mv-body'); if (t) t.focus(); }, 50); }); });
})();
</script>
<?php tv_page_end();
