<?php
// market/ticket.php?c=<code> — one event ticket (decisions/0141 §5, KindCheckout): the event, the seat and its code as a
// QR to show at the door, on a phone or printed. Anyone holding the code sees the ticket (that's what a printed ticket
// is); only its buyer sees whose it is. Someone on the business's team gets Check in, which works once.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/MarketCheckout.php';
require_once __DIR__ . '/../../app/lib/Qr.php';

$pdo = Database::connection();
$uid = (int) (Auth::currentUserId() ?? 0);
$code = strtoupper(trim((string) ($_GET['c'] ?? '')));
$tk = KindCheckout::ticket($pdo, $code);
$o = $tk ? MarketCheckout::get($pdo, (int) $tk['order_id']) : null;
if (!$tk || !$o) { http_response_code(404); tv_page_start('Ticket not found', ['no_crumbs' => true]); echo '<p class="py-8 text-center">That ticket isn&rsquo;t here.</p>'; tv_page_end(); exit; }
$it = MarketBiz::get($pdo, (int) $tk['item_id']);
[, $d] = $it ? KindCheckout::kindOf($it) : ['', []];
$biz = MarketBiz::entity($pdo, (int) $tk['entity_id']) ?: [];
$team = $uid && MarketBiz::onTeam($pdo, $uid, (int) $tk['entity_id'], 'orders', 'view');
$mine = $uid && (int) $o['buyer_id'] === $uid;
$facts = ItemKinds::facts('ticket', $d, (string) ($biz['address'] ?? ''));
$state = $o['status'] !== 'paid' ? ['bad', 'Not valid:', 'Its order isn\'t paid.'] : ($tk['checked_in_at'] ? ['info', 'Checked in:', date('M j \a\t g:i a', strtotime((string) $tk['checked_in_at'])) . '.'] : ['ok', 'Valid:', 'Not checked in yet.']);

tv_page_start('Ticket · ' . ($it['title'] ?? 'Event'), ['section' => 'market', 'no_crumbs' => true]);
?>
<style>
  .tk{max-width:26rem;margin:0 auto}.tk-card{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;padding:1rem;text-align:center}
  .tk h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.35rem;margin:0 0 .2rem;color:#3E2B1F}.tk-qr{width:min(15rem,70vw);margin:.7rem auto}.tk-qr svg{width:100%;height:auto;display:block}
  .tk-code{font:700 1.25rem ui-monospace,monospace;letter-spacing:.12em;color:#3E2B1F}.tk dl{text-align:left;font-size:.9rem;margin:.7rem 0 0;display:grid;grid-template-columns:auto 1fr;gap:.2rem .7rem}.tk dt{font-weight:700;color:#5C4632}.tk dd{margin:0}
  .tk-b{font:inherit;font-size:.95rem;border:0;border-radius:999px;padding:.55rem 1.3rem;background:#3E2B1F;color:#FFFBF2;cursor:pointer;font-weight:700;margin-top:.7rem}
  @media print{.tk-b,header,footer,nav{display:none!important}}
</style>
<div class="tk">
  <div class="tk-card tv-bleed">
    <h1><?= tv_e((string) ($it['title'] ?? 'Event')) ?></h1>
    <p class="text-sm" style="margin:0;color:#5C4632"><?= tv_e((string) ($biz['name'] ?? '')) ?> · seat <?= (int) $tk['seat'] ?></p>
    <div class="tk-qr" aria-label="The ticket's code"><?= Qr::svg('https://traversence.com/market/ticket.php?c=' . $tk['code'], ['ecc' => 'M', 'dark' => '#000000', 'light' => '#FFFFFF']) ?></div>
    <div class="tk-code"><?= tv_e($tk['code']) ?></div>
    <p data-tv-status="<?= $state[0] ?>" data-tv-label="<?= tv_e($state[1]) ?>" style="text-align:left"><?= tv_e($state[2]) ?></p>
    <dl><?php foreach ($facts as [$fl, $fv]): if ($fl === 'Your ticket') continue; ?><dt><?= tv_e($fl) ?></dt><dd><?= nl2br(tv_e($fv)) ?></dd><?php endforeach; ?>
      <?php if ($mine || $team): ?><dt>For</dt><dd><?= tv_e((string) $o['name']) ?>, order <?= (int) $o['id'] ?></dd><?php endif; ?></dl>
    <?php if ($team && $o['status'] === 'paid' && !$tk['checked_in_at']): ?><button type="button" class="tk-b" id="tk-in">Check in</button><?php endif; ?>
    <?php if ($mine): ?><p class="text-sm" style="margin:.7rem 0 0"><a class="underline" href="/market/order.php?t=<?= tv_e($o['token']) ?>">Your order</a></p><?php endif; ?>
  </div>
</div>
<script<?= tv_nonce() ?>>
(function () {
  var b = document.getElementById('tk-in'); if (!b) return;
  b.addEventListener('click', function () {
    TvAsk.busy(b, true);
    fetch('/api/market-pay.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode((string) ($_SESSION['csrf_token'] ?? '')) ?> }, body: JSON.stringify({ action: 'checkin', code: <?= json_encode($tk['code']) ?> }) })
      .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.'); TvAsk.say(d.message, { anchor: b }); setTimeout(function () { location.reload(); }, 900); })
      .catch(function (x) { TvAsk.busy(b, false); TvAsk.say(x.message, { anchor: b, bad: true }); });
  });
})();
</script>
<?php tv_page_end();
