<?php
// market/order.php?t=<token> — one Marketplace order, for its buyer (decisions/0135, "Step 4 decided"): where it stands,
// what's in it, the total, and for a direct way of paying, the business's instructions. Coming back from Stripe's or
// Square's checkout, it asks the gateway whether it's paid (never takes the return for it). Cancel while unpaid.
// By kind (decisions/0141 §5): each line's dates, window and answers; a deposit and the balance; tickets (a code each);
// download links; a subscription's state and Cancel; for the business's team, a rental's Returned (its deposit back).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/MarketCheckout.php';
tv_card_page_csp('market-order', ['stripe', 'square']);   // a card page: only our scripts and the business's gateway (0135; its script list there)

$pdo = Database::connection();
$uid = Auth::currentUserId();
$o = MarketCheckout::ready($pdo) ? MarketCheckout::byToken($pdo, (string) ($_GET['t'] ?? '')) : null;
$may = $o && $uid && ((int) $o['buyer_id'] === $uid || MarketBiz::onTeam($pdo, $uid, (int) $o['entity_id'], 'ledger') || Market::isStaff($pdo, $uid));
if (!$may && $o && !$uid) { header('Location: /login.php?next=' . rawurlencode((string) ($_SERVER['REQUEST_URI'] ?? '/')), true, 302); exit; }
if (!$may) { http_response_code(404); tv_page_start('Order not found', ['no_crumbs' => true]); echo '<p class="py-8 text-center">That order isn&rsquo;t here.</p>'; tv_page_end(); exit; }
if ($o['status'] === 'pending' && $o['method'] === 'card') {   // back from paying: ask the gateway
    try { if (MarketCheckout::confirmAndMark($pdo, (int) $o['id'])) $o = MarketCheckout::get($pdo, (int) $o['id']); } catch (Throwable $x) { error_log('market order confirm: ' . $x->getMessage()); }
}
// the setup's test purchase: its team goes back to E-commerce setup, step 5, where the result shows (Jason, 2026-11-03)
if (str_starts_with((string) $o['note'], MarketCheckout::TEST_NOTE) && MarketBiz::onTeam($pdo, $uid, (int) $o['entity_id'])) { header('Location: /business/' . (int) $o['entity_id'] . '/checkout#test', true, 303); exit; }
$biz = (string) (MarketBiz::entity($pdo, (int) $o['entity_id'])['name'] ?? 'The business');
$mine = (int) $o['buyer_id'] === $uid;
$kinds = array_values(array_unique(array_filter(array_column((array) $o['lines'], 'kind'))));
$shipped = array_intersect($kinds, KindCheckout::SHIPS) || !$kinds;
$st = ['paid' => ['ok', 'Paid:', $biz . ' has your payment' . (MarketCheckout::due($o) < (int) $o['total_cents'] ? ' of ' . MarketCheckout::money(MarketCheckout::due($o)) . ' (the deposit)' : '') . '.' . ($shipped ? ' They\'ll be in touch about ' . (stripos((string) $o['ship_name'], 'pick') !== false ? 'pickup.' : 'getting it to you.') : '')],
    'awaiting' => ['info', 'Waiting for your payment:', MarketCheckout::instructions($pdo, $o)],
    'pending' => ['info', 'Not paid yet:', 'If you closed the payment form, nothing was charged. Pay from your cart again, or cancel.'],
    'cancelled' => ['bad', 'Cancelled:', 'Nothing was charged.'], 'expired' => ['bad', 'Expired:', 'No payment arrived in time, so the items were released. If you paid, contact ' . $biz . '.'],
    'refunded' => ['info', 'Refunded:', 'The business refunded this order.']][$o['status']] ?? ['info', '', ''];

tv_page_start('Order ' . (int) $o['id'], ['section' => 'market', 'active' => 'cart', 'no_crumbs' => true]);
?>
<style>
  .od{max-width:42rem}.od h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.6rem;margin:0 0 .3rem;color:#3E2B1F}
  .od-card{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;padding:.85rem .95rem;margin:.7rem 0}
  .od-row{display:grid;grid-template-columns:1fr auto;gap:.2rem .8rem;font-size:.93rem}.od-row b{font-size:1.05rem}
  .od-h{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.08rem;margin:0 0 .4rem;color:#3E2B1F}.od-tk{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;padding:.3rem 0}.od-tk small{color:#8A7355}
  .od-b{font:inherit;font-size:.86rem;border:1px solid #CBB98D;border-radius:999px;padding:.35rem .9rem;background:#FFFBF2;color:#3E2B1F;cursor:pointer;font-weight:600;text-decoration:none;display:inline-block}
</style>
<div class="od">
  <h1>Order <?= (int) $o['id'] ?> from <?= tv_e($biz) ?></h1>
  <p data-tv-status="<?= $st[0] ?>" data-tv-label="<?= tv_e($st[1]) ?>"><?= tv_e($st[2]) ?></p>
  <section class="od-card tv-bleed"><div class="od-row">
    <?php foreach ($o['lines'] as $l): $lx = (array) ($l['kx'] ?? []); $more = [];   // what the buyer chose for it, by kind
      if (!empty($lx['guests'])) $more[] = (int) $lx['guests'] . ' guest' . ((int) $lx['guests'] === 1 ? '' : 's');
      if (!empty($lx['window'])) $more[] = 'Pickup: ' . $lx['window'];
      if (!empty($lx['starts'])) $more[] = date('D, M j, g:i a', strtotime((string) $lx['starts']));
      foreach ((array) ($lx['specs'] ?? []) as $q => $a) $more[] = $q . ': ' . $a;
      if (!empty($lx['interval'])) $more[] = 'Every ' . $lx['interval']; ?>
      <span><?= tv_e($l['title']) ?><?= (int) $l['qty'] > 1 || empty($l['extra']) ? ' × ' . (int) $l['qty'] : '' ?><?php if ($more): ?><small style="display:block;color:#8A7355"><?= tv_e(implode(' · ', $more)) ?></small><?php endif; ?></span><span><?= tv_e(MarketCheckout::money((int) $l['qty'] * (int) $l['unit_cents'])) ?></span><?php endforeach; ?>
    <?php if ($shipped || (int) $o['ship_cents']): ?><span><?= tv_e($o['ship_name']) ?></span><span><?= tv_e(MarketCheckout::money((int) $o['ship_cents'])) ?></span><?php endif; ?>
    <span>Sales tax</span><span><?= tv_e(MarketCheckout::money((int) $o['tax_cents'])) ?></span>
    <b>Total</b><b><?= tv_e(MarketCheckout::money((int) $o['total_cents'])) ?></b>
    <?php if (MarketCheckout::due($o) < (int) $o['total_cents']): ?><span>Deposit, paid now</span><span><?= tv_e(MarketCheckout::money(MarketCheckout::due($o))) ?></span><span>When it&rsquo;s ready (an invoice from <?= tv_e($biz) ?>)</span><span><?= tv_e(MarketCheckout::money((int) $o['total_cents'] - MarketCheckout::due($o))) ?></span><?php endif; ?>
  </div>
  <p class="text-sm text-[#5C4632]" style="margin:.6rem 0 0">Placed <?= tv_e(date('M j, Y, g:i a', strtotime((string) $o['created_at']))) ?> · <?= tv_e($o['method'] === 'card' ? 'Card, through ' . $biz . '\'s ' . (MarketPay::PROVIDERS[$o['provider']] ?? 'gateway') : (MarketCheckout::METHODS[$o['method']] ?? $o['method'])) ?><?= $o['ship_address'] !== '' ? ' · to ' . tv_e($o['ship_address']) : '' ?></p></section>
  <?php if ($o['status'] === 'paid'): /* what the buyer gets, by kind */
    $tix = KindCheckout::tickets($pdo, (int) $o['id']); $dls = KindCheckout::downloads($pdo, (int) $o['id']); ?>
    <?php if ($tix): ?><section class="od-card tv-bleed"><h2 class="od-h">Your tickets</h2><p class="text-sm" style="margin:0 0 .4rem">Show each at the door, on your phone or printed. Each is checked in once.</p>
      <?php foreach ($tix as $tk): ?><div class="od-tk"><a class="od-b" href="/market/ticket.php?c=<?= tv_e($tk['code']) ?>">Seat <?= (int) $tk['seat'] ?> · <?= tv_e($tk['code']) ?></a><small><?= $tk['checked_in_at'] ? 'Checked in ' . tv_e(date('M j, g:i a', strtotime((string) $tk['checked_in_at']))) : 'Not checked in' ?></small></div><?php endforeach; ?></section><?php endif; ?>
    <?php if ($dls && $mine): ?><section class="od-card tv-bleed"><h2 class="od-h">Your download<?= count($dls) > 1 ? 's' : '' ?></h2>
      <?php foreach ($dls as $dl): $dlIt = MarketBiz::get($pdo, (int) $dl['item_id']); $dlLeft = max(0, (int) $dl['max_uses'] - (int) $dl['uses']); $dlOn = $dlLeft > 0 && strtotime((string) $dl['expires_at']) > time(); ?>
        <div class="od-tk"><?php if ($dlOn): ?><a class="od-b" href="/market/download.php?t=<?= tv_e($dl['token']) ?>">Download <?= tv_e((string) ($dlIt['title'] ?? 'the file')) ?></a><?php else: ?><b><?= tv_e((string) ($dlIt['title'] ?? 'The file')) ?></b><?php endif; ?>
          <small><?= $dlOn ? $dlLeft . ' download' . ($dlLeft === 1 ? '' : 's') . ' left, until ' . tv_e(date('M j, Y', strtotime((string) $dl['expires_at']))) : 'This link is used up or expired. Ask ' . tv_e($biz) . ' for a new one.' ?></small></div><?php endforeach; ?></section><?php endif; ?>
    <?php if ((string) ($o['pay_mode'] ?? '') === 'subscription' && (string) ($o['sub_ref'] ?? '') !== ''):
      $sub = null; try { $g = MarketCheckout::gateway($pdo, (int) $o['entity_id']); if ($g) $sub = MarketPay::subscription($g, (string) $o['sub_ref']); } catch (Throwable $x) { error_log('market subscription read: ' . $x->getMessage()); } ?>
      <section class="od-card tv-bleed"><h2 class="od-h">Your subscription</h2>
        <?php if (!$sub): ?><p data-tv-status="info" data-tv-label="Can't check it now:">Ask <?= tv_e($biz) ?> how it stands.</p>
        <?php elseif ($sub['status'] === 'cancelled'): ?><p data-tv-status="info" data-tv-label="Ended:">Nothing more is charged.</p>
        <?php elseif ($sub['status'] === 'cancelling'): ?><p data-tv-status="info" data-tv-label="Cancelled:">It ends <?= tv_e(date('M j, Y', strtotime($sub['ends']))) ?>; nothing more is charged.</p>
        <?php else: ?><p data-tv-status="ok" data-tv-label="Active:"><?= $sub['renews'] !== '' ? 'Renews ' . tv_e(date('M j, Y', strtotime($sub['renews']))) . '.' : 'Charged each period until you cancel.' ?></p>
          <?php if ($mine): ?><button type="button" class="od-b" id="od-subcancel">Cancel the subscription</button><?php endif; ?><?php endif; ?></section><?php endif; ?>
    <?php if (in_array('rental', $kinds, true) && MarketCheckout::onOrderTeam($pdo, $uid, $o)): $dep = 0; foreach ($o['lines'] as $l) if (($l['extra'] ?? '') === 'deposit') $dep += (int) $l['unit_cents']; ?>
      <?php if ($dep): ?><section class="od-card tv-bleed"><h2 class="od-h">The rental's return</h2>
        <?php if ((string) ($o['pay_mode'] ?? '') === 'returned'): ?><p data-tv-status="ok" data-tv-label="Returned:">The deposit is settled (see the order's notes).</p>
        <?php else: ?><p class="text-sm" style="margin:0 0 .4rem">When it comes back, mark it returned: the deposit of <?= tv_e(MarketCheckout::money($dep)) ?> <?= (string) ($o['pay_mode'] ?? '') === 'hold' ? 'held on the card is released' : 'goes back' ?>, less any damage you keep.</p>
          <label class="text-sm">Kept for damage ($) <input id="od-damage" type="number" min="0" max="<?= $dep / 100 ?>" step="0.01" value="0" style="width:7rem;border:1px solid #CBB98D;border-radius:.5rem;padding:.3rem .4rem"></label> <button type="button" class="od-b" id="od-returned">Mark returned</button><?php endif; ?></section><?php endif; ?>
    <?php endif; ?>
  <?php endif; ?>
  <p><a class="od-b" href="/listing/view.php?id=<?= (int) $o['entity_id'] ?>">Contact <?= tv_e($biz) ?></a>
    <?php if ($mine && in_array($o['status'], ['pending', 'awaiting'], true)): ?> <button type="button" class="od-b" id="od-cancel">Cancel the order</button><?php endif; ?></p>
  <?php   // the store policies this order was placed under: its own copy, never today's (decisions/0142 §2)
  $odSnap = json_decode((string) ($o['policy_json'] ?? ''), true);
  if (is_array($odSnap) && !empty($odSnap['lines'])) { require_once __DIR__ . '/../../app/lib/StorePolicies.php'; echo StorePolicies::css() . StorePolicies::box($pdo, (int) $o['entity_id'], $odSnap, false, 'Store policies for this order'); } ?>
  <p class="text-sm text-[#8A7355]">Traversence never holds your money or sees your card. Refunds and questions about this order are with <?= tv_e($biz) ?>.</p>
</div>
<script<?= tv_nonce() ?>>
(function () {
  function act(b, body, ask, yes) {
    if (!b) return;
    b.addEventListener('click', function () {
      if (!TvAsk.gate(b, ask, { yes: yes, danger: true })) return;
      if (b.id === 'od-returned') body.damage = document.getElementById('od-damage').value;
      TvAsk.busy(b, true);
      fetch('/api/market-pay.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode((string) ($_SESSION['csrf_token'] ?? '')) ?> }, body: JSON.stringify(body) })
        .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.'); location.reload(); })
        .catch(function (x) { TvAsk.busy(b, false); TvAsk.say(x.message, { anchor: b, bad: true }); });
    });
  }
  var tok = <?= json_encode($o['token']) ?>;
  act(document.getElementById('od-cancel'), { action: 'cancel', order: tok }, 'Cancel this order? Nothing is charged, and the items are released.', 'Cancel it');
  act(document.getElementById('od-subcancel'), { action: 'sub_cancel', order: tok }, 'Cancel the subscription? It ends at the close of the period you\'ve paid for.', 'Cancel it');
  act(document.getElementById('od-returned'), { action: 'returned', order: tok }, 'Mark it returned? The deposit goes back, less what you keep for damage. This is done once.', 'Mark returned');
})();
</script>
<?php tv_page_end();
