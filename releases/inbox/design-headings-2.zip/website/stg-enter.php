<?php
// /stg-enter.php — on the staging copy only (decisions/0145 Phase 5): the way in from the live admin's Open on staging.
// The live site signs a link (good for 10 minutes, once) with the key it keeps in staging's .env (RELEASE_BAR_KEY); this
// checks it, gives the browser staging's pass (so the viewing password isn't asked) and the staging bar, signs in as the
// person who opened it (staging's copy of their own account and staff login: the same ids, its personal details replaced
// by the refresh, so their name is put back), or as one of the audit's test accounts, or signed out, and opens the page.
declare(strict_types=1);

define('TV_STAGING_ENTER', true);   // Staging::guard() lets this one page through: it checks its own signature
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/Staging.php';
require_once __DIR__ . '/../app/lib/Releases.php';
if (!Staging::here()) { http_response_code(404); exit; }
header('Cache-Control: no-store');

$fail = function (string $why): void {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Staging</title></head>'
       . '<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7EFDC;color:#3E2B1F;font:16px/1.5 var(--tv-font-head,Georgia,serif);padding:16px">'
       . '<div style="max-width:28rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:1.25rem"><p style="margin:0 0 .5rem;color:#92400E;font-weight:700">This way into staging didn\'t work</p>'
       . '<p style="margin:0 0 .75rem">' . htmlspecialchars($why) . '</p>'
       . '<p style="margin:0"><a href="https://traversence.com/admin/config/releases" style="color:#92400E">Open it again from Releases on the live site</a>, or ask us at <a href="mailto:support@traversence.com" style="color:#92400E">support@traversence.com</a>.</p></div></body></html>';
    exit;
};

Database::readEnv();
$key = (string) (getenv('RELEASE_BAR_KEY') ?: '');
$d = Releases::verify((string) ($_GET['t'] ?? ''), $key);
if (!$d) $fail('The link has run out (it works for 10 minutes) or wasn\'t made by the live site.');
$pdo = Database::connection();
try {
    $pdo->exec('CREATE TABLE IF NOT EXISTS stg_bar_used (n CHAR(16) NOT NULL PRIMARY KEY, at DATETIME NOT NULL) ENGINE=InnoDB');
    $pdo->prepare('INSERT INTO stg_bar_used (n, at) VALUES (?, NOW())')->execute([(string) $d['n']]);
    if (random_int(1, 20) === 1) $pdo->exec('DELETE FROM stg_bar_used WHERE at < NOW() - INTERVAL 1 DAY');
} catch (Throwable $e) { $fail('That link was used already: each one opens staging once.'); }

$cookie = fn (string $k, string $v) => setcookie($k, $v, ['expires' => time() + 12 * 3600, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax']);
if (Staging::pass() !== '') $cookie('tv_stg_pass', Staging::pass());
$cookie('tv_stg_bar', Releases::sign(['rel' => (int) $d['rel'], 'uid' => (int) $d['uid'], 'name' => (string) $d['name'], 'perms' => (array) $d['perms'], 'exp' => time() + 12 * 3600], $key));

// the test account chosen: a test member, a test staff login, or signed out
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
foreach (['user_id', 'logged_in_at', 'session_version', 'tv_staff', 'tv_2s_ok', 'tv_staff_auth', 'tv_test'] as $k) unset($_SESSION[$k]);
$as = (string) ($d['as'] ?? '');
$uid = 0; $sid = 0;
try {
    require_once __DIR__ . '/../app/lib/TestAccounts.php';
    if ($as === 'me') {   // their own account on staging: the same user id, and their staff login if they have one
        $st = $pdo->prepare('SELECT id FROM users WHERE id = ?'); $st->execute([(int) $d['uid']]);
        $uid = (int) $st->fetchColumn();
        if ($uid && (int) ($d['sid'] ?? 0)) { $st = $pdo->prepare('SELECT id FROM ' . Database::t('staff_accounts') . " WHERE id = ? AND user_id = ? AND status = 'active'"); $st->execute([(int) $d['sid'], $uid]); $sid = (int) $st->fetchColumn(); }
        if ($uid && trim((string) $d['name']) !== '') { try { $pdo->prepare('UPDATE users SET display_name = ? WHERE id = ?')->execute([mb_substr(trim((string) $d['name']), 0, 100), $uid]); } catch (Throwable) {} }   // their own name, not "Test Person"
        if (!$uid) $fail('Your account isn\'t on staging yet (it\'s newer than staging\'s last refresh): refresh staging, or look as one of the test accounts.');
    } elseif (preg_match('/^m:([a-z0-9-]+)$/', $as, $m) && isset(TestAccounts::MEMBERS[$m[1]])) {
        $st = $pdo->prepare('SELECT id FROM users WHERE email = ? AND is_test = 1'); $st->execute(['check+' . $m[1] . '@traversence.com']);
        $uid = (int) $st->fetchColumn();
    } elseif (preg_match('/^s:([a-z0-9-]+)$/', $as, $m) && isset(TestAccounts::STAFF[$m[1]])) {
        $sid = (int) (TestAccounts::made($pdo)['staff|' . $m[1]] ?? 0);
        if ($sid) { $st = $pdo->prepare('SELECT user_id FROM ' . Database::t('staff_accounts') . " WHERE id = ? AND status = 'active'"); $st->execute([$sid]); $uid = (int) $st->fetchColumn(); }
    }
} catch (Throwable $e) { error_log('stg-enter: ' . $e->getMessage()); }
if ($uid) {
    $st = $pdo->prepare('SELECT session_version FROM users WHERE id = ?'); $st->execute([$uid]);
    $v = (int) $st->fetchColumn();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $uid; $_SESSION['logged_in_at'] = time(); $_SESSION['session_version'] = $v; $_SESSION['tv_test'] = $as !== 'me';
    if ($sid) { $_SESSION['tv_staff'] = $sid; $_SESSION['tv_2s_ok'] = $uid; $_SESSION['tv_staff_auth'] = ['id' => $sid, 'at' => time(), 'sv' => $v]; }
}
$to = (string) ($d['to'] ?? '/');
header('Location: ' . (preg_match('#^/[^\s]*$#', $to) && !str_starts_with($to, '//') ? $to : '/'), true, 302);
exit;
