<?php
// /listing/businessportal.php: your business dashboard (decisions/0070). Your claims and where each stands, the last
// step to confirm, your plan, any question about a listing you hold, and the editor for each listing you manage.
//   ?id=<entity id> opens that listing's editor.
require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
$me = Auth::currentUser();
if ($me === null) { header('Location: /login.php?next=' . urlencode('/listing/businessportal.php')); exit; }
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/Claims.php';

$pdo = Database::connection();
$uid = (int) $me['id'];
$ready = Claims::ready($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$claims = $ready ? Claims::forUser($pdo, $uid) : [];
// every listing this person manages (owner or manager), with or without a claim behind it
require_once __DIR__ . '/../../app/lib/Team.php';
$managed = array_map(fn ($l) => $l + ['access_level' => $l['role'] === 'owner' ? 'owner' : 'manager'], array_values(Team::listingsOf($pdo, $uid)));
$ids = array_map(fn ($r) => (int) $r['id'], $managed);
$sel = (int) ($_GET['id'] ?? ($ids[0] ?? 0));
if (!in_array($sel, $ids, true)) $sel = $ids[0] ?? 0;
$cur = $sel ? Claims::listing($pdo, $sel) : null;
$meta = [];
if ($cur) {
    $q = $pdo->prepare("SELECT meta_key, meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key IN ('description','hours','phone','address','city','state','website','offerings')");
    $q->execute([$sel]);
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { $v = json_decode((string) $r['meta_value'], true) ?? $r['meta_value']; $meta[$r['meta_key']] = is_array($v) ? implode("\n", array_map('strval', $v)) : (string) $v; }
    $meta['name'] = (string) $cur['name'];
}
$waiting = $cur && $ready ? array_column(Claims::changes($pdo, $sel), 'new_value', 'field') : [];
$dispute = $cur && $ready ? Claims::openDispute($pdo, $sel) : null;
$frozen = $cur && $ready && Claims::frozen($pdo, $sel);
$verified = $cur && $cur['status'] === 'verified';

// one business's editor (?id=) is part of its portal (Jason, 2026-11-05: "the listing profile is not associated to the
// listing dashboard"): the portal's own menu, Edit listing lit; without ?id it's the list of everything you manage
$inPortal = !empty($_GET['id']) && $cur;
if ($inPortal) {
    require_once __DIR__ . '/../../app/business/portal.php';
    tv_page_start('Edit ' . $cur['name'], ['no_crumbs' => true, 'description' => 'Edit your listing on Traversence.',
        'rail' => tv_biz_rail($pdo, $sel, $uid, false, (string) $cur['name']), 'rail_label' => (string) $cur['name'], 'active' => 'edit']);
} else {
    tv_page_start('Your business', ['no_crumbs' => true, 'back' => '/user/dashboard.php', 'description' => 'Manage your listings on Traversence.']);
}
$e = 'tv_e';
?>
<style>
  .bp{max-width:44rem}.bp-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem 1.1rem;margin-top:.8rem}
  .bp-card h2{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.15rem}
  .bp-s{font-size:.8rem;color:#5C4632}.bp-m{font-size:.75rem;color:#8A7355}
  .bp-idea{font-size:.78rem;border:1px solid #CBB98D;background:#FFFBF2;color:#92400E;border-radius:999px;padding:.15rem .55rem;margin:.15rem .1rem 0 0;cursor:pointer}
  .bp-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.45rem .65rem;font-size:.9rem}
  .bp-lb{display:flex;justify-content:space-between;gap:.5rem;font-size:.75rem;font-weight:600;margin:.65rem 0 .2rem}
  .bp-b{display:inline-flex;font-size:.85rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;border-radius:.7rem;padding:.45rem .9rem;cursor:pointer;color:#3E2B1F}
  .bp-b.go{background:#B8863B;border-color:#B8863B;color:#2A1B12}
  .bp-pill{display:inline-block;font-size:.72rem;font-weight:700;border-radius:999px;padding:.12rem .6rem;background:#E3D3AC}.bp-pill.v{background:#8FBCA8}.bp-pill.h{background:#F2C98A}
  .bp-row{display:flex;justify-content:space-between;gap:.6rem;flex-wrap:wrap;align-items:center;padding:.55rem 0;border-top:1px solid rgba(203,185,141,.5)}
  .bp-row:first-of-type{border-top:0}.bp-row a.n{color:#92400E;text-decoration:underline;font-weight:700}
  .bp-code{font-family:ui-monospace,monospace;font-weight:700;background:#3E2B1F;color:#F7EFDC;border-radius:.4rem;padding:.05rem .45rem}
  .bp-lock{font-weight:500;color:#8A7355}.bp-msg{font-size:.85rem;margin-top:.6rem}.bp-msg.bad{color:#991B1B}.bp-msg.ok{color:#166534}
  @media (max-width:767px){.bp-card{border-radius:.5rem}}
</style>
<div class="bp" data-csrf="<?= $e($csrf) ?>">
  <h1 class="font-serif font-bold text-3xl"><?= $inPortal ? 'Edit listing' : 'Your business' ?></h1>
  <?php if ($sel && !$inPortal): // the new business portal (decisions/0115): this business's tools, opened by its plan ?>
  <p class="tv-bleed bp-card" style="display:flex;justify-content:space-between;align-items:center;gap:.6rem;flex-wrap:wrap"><span><b>New: the business portal.</b> Your customers, and soon quotes, catalog and orders, in one place for your team.</span>
    <a href="/business/<?= (int) $sel ?>" style="background:#3E2B1F;color:#FFFBF2;border-radius:999px;padding:.4rem 1rem;font-weight:700;text-decoration:none">Open the portal</a></p>
  <?php endif; ?>

  <?php if (!$inPortal): // inside the portal the switcher and the portal's own pages cover this list ?>
  <div class="tv-bleed bp-card">
    <h2>Your listings and claims</h2>
    <?php if (!$claims && !$managed): ?>
      <p class="bp-s mt-1">You haven't claimed a listing yet. Find your business in the <a class="underline" href="/directory/">directory</a> and tap Claim, or <a class="underline" href="/claim.php?new=1">add it</a> if it isn't listed.</p>
    <?php endif;
    $shown = [];
    foreach ($claims as $c): $shown[(int) $c['entity_id']] = true; ?>
      <div class="bp-row">
        <div>
          <a class="n" href="?id=<?= (int) $c['entity_id'] ?>"><?= $e($c['name']) ?></a>
          <?php if ($c['status'] === 'verified'): ?><span class="bp-pill v">✓ Verified</span>
          <?php elseif ($c['status'] === 'managed'): ?><span class="bp-pill">Managed by owner</span>
          <?php else: ?><span class="bp-pill h">Claim Request On Hold</span><?php endif; ?>
          <?php if ($c['status'] === 'managed'): ?>
            <p class="bp-m mt-1">Last step: text <span class="bp-code"><?= $e($c['text_code']) ?></span> to <?= $e(Claims::verifyNumber()) ?> from the phone on your listing<?= $c['listed_phone'] ? ', ' . $e(Claims::fmtPhone((string) $c['listed_phone'])) : '' ?>. From another number? An admin will contact you within 48 hours.</p>
          <?php elseif ($c['status'] === 'on_hold'): ?>
            <p class="bp-m mt-1">Another claim for this listing is in progress. Your request is saved and an admin will be in touch.</p>
          <?php endif; ?>
        </div>
        <div class="flex gap-2 flex-wrap">
          <?php if ($c['status'] !== 'on_hold'): ?><span class="bp-m">Plan: <?= $e(Claims::PLANS[$c['plan'] ?: ($c['plan_tier'] ?: 'free')] ?? 'Free') ?><?= Claims::onTrial($pdo, (int) $c['entity_id']) ? ' (trial)' : '' ?> · <a href="/plans.php?listing=<?= (int) $c['entity_id'] ?>" style="color:#92400E;text-decoration:underline">Manage plan</a></span><?php endif; ?>
          <a class="bp-b" href="/claim.php?listing=<?= (int) $c['entity_id'] ?>"><?= $c['status'] === 'on_hold' ? 'Your request' : ($c['plan'] ? 'Claim and plan' : 'Choose a plan') ?></a>
        </div>
      </div>
    <?php endforeach;
    foreach ($managed as $m): if (isset($shown[(int) $m['id']])) continue; ?>
      <div class="bp-row"><div><a class="n" href="?id=<?= (int) $m['id'] ?>"><?= $e($m['name']) ?></a> <span class="bp-pill"><?= $m['access_level'] === 'owner' ? ($m['status'] === 'verified' ? '✓ Verified' : 'Owner') : 'Manager' ?></span></div></div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if ($cur): ?>
    <?php if ($dispute && (int) $cur['owner_user_id'] === $uid): ?>
    <form class="tv-bleed bp-card" id="bp-answer" data-dispute="<?= (int) $dispute['id'] ?>" style="border-color:#B45309">
      <h2>Someone has questioned this listing</h2>
      <p class="bp-s mt-1">Someone believes they own or run <?= $e($cur['name']) ?>. Nothing changes on your listing for now<?= $frozen ? ', but editing is paused while an admin looks into it' : '' ?>. Answer by <?= $e(substr((string) $dispute['challenge_deadline'], 0, 10)) ?>; an admin decides.</p>
      <textarea class="bp-in mt-2" name="answer" rows="3" maxlength="4000" placeholder="Why the listing is yours"><?= $e((string) ($dispute['owner_answer'] ?? '')) ?></textarea>
      <div class="mt-2"><button class="bp-b go" type="submit"><?= $dispute['owner_answer'] ? 'Update my answer' : 'Send my answer' ?></button>
        <?php if (!$verified): ?> <a class="bp-b" href="/claim.php?listing=<?= (int) $sel ?>">Add a document</a><?php endif; ?></div>
      <p class="bp-msg" role="status"></p>
    </form>
    <?php endif; ?>

    <form class="tv-bleed bp-card" id="bp-edit" data-entity="<?= (int) $sel ?>">
      <div class="flex justify-between gap-2 flex-wrap"><h2>Edit <?= $e($cur['name']) ?></h2><a class="underline text-sm text-[#92400E]" href="/listing/view.php?id=<?= (int) $sel ?>">See it as visitors do</a></div>
      <?php if ($frozen): ?><p class="bp-msg bad">Editing is paused while an admin looks into a question about this listing.</p><?php endif; ?>
      <?php if (!$verified): ?><p class="bp-m mt-1">Until you confirm by text, changes to the name, phone, address and website go to an admin first. The rest shows at once. Photos and video: <a class="underline" href="/listing/view.php?id=<?= (int) $sel ?>">on your listing</a>, with the camera in its top corner.</p><?php endif; ?>
      <?php
      $f = [['name', 'Business name', 'text'], ['phone', 'Phone', 'tel'], ['address', 'Street address', 'text'], ['city', 'Town', 'text'], ['state', 'State', 'text'],
            ['website', 'Website', 'text'], ['hours', 'Hours', 'text'], ['description', 'About the business', 'area']];
      foreach ($f as [$k, $label, $type]):
          $locked = !$verified && in_array($k, Claims::PROTECTED, true); ?>
        <label class="bp-lb" for="f-<?= $k ?>"><span><?= $e($label) ?></span><?php if ($locked): ?><span class="bp-lock"><?= isset($waiting[$k]) ? 'Waiting for an admin: ' . $e(mb_strimwidth($waiting[$k], 0, 40, '…')) : 'An admin approves changes' ?></span><?php endif; ?></label>
        <?php if ($type === 'area'): ?>
          <textarea class="bp-in" id="f-<?= $k ?>" name="<?= $k ?>" rows="5" maxlength="2000" <?= $frozen ? 'disabled' : '' ?>><?= $e($meta[$k] ?? '') ?></textarea>
        <?php else: ?>
          <input class="bp-in" id="f-<?= $k ?>" name="<?= $k ?>" type="<?= $type === 'tel' ? 'tel' : 'text' ?>" value="<?= $e($meta[$k] ?? '') ?>" <?= $frozen ? 'disabled' : '' ?> <?= $k === 'hours' ? 'placeholder="Mon–Fri 9am–5pm, Sat 10am–2pm"' : '' ?>>
        <?php endif;
      endforeach; ?>
      <?php // categories and offerings (decisions/0073): saved at once
      require_once __DIR__ . '/../../app/lib/ListingCategories.php'; require_once __DIR__ . '/../../app/ui/category-fields.php'; require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
      if (ListingCategories::ready($pdo)):
          $pc = $pdo->prepare('SELECT e.category_id, c.name FROM entities e LEFT JOIN categories c ON c.id = e.category_id WHERE e.id = ?'); $pc->execute([$sel]); $pc = $pc->fetch(PDO::FETCH_ASSOC) ?: [];
          $alsoNow = ListingCategories::get($pdo, $sel);
          $ideas = ListingCategories::offeringIdeas($pdo, array_merge([(int) ($pc['category_id'] ?? 0)], array_column($alsoNow, 'id')), preg_split('/\n/', $meta['offerings'] ?? '')); ?>
        <div data-cat-more data-max="<?= ListingCategories::MAX ?>" class="mt-3">
          <span class="bp-lb"><span>Categories</span></span>
          <div class="tv-cat-line"><span class="bp-in" style="background:#F7EFDC">Main: <b><?= $e((string) ($pc['name'] ?? 'not set')) ?></b></span><?= tv_cat_add_button() ?></div>
          <?= tv_cat_more_rows(IntakeStager::leafCategories($pdo), array_column($alsoNow, 'id'), 'bp-in') ?>
          <p class="bp-m mt-1">Tap + to list your business under up to <?= ListingCategories::MAX ?> more categories, so people find it there too. Pick the ones that match what you really do: they work best that way. To change the main one, <button type="button" class="underline" data-tv-suggest='<?= $e(json_encode(['kind' => 'fix', 'entity_id' => $sel, 'target_name' => $cur['name']])) ?>'>tell us</button>.</p>
        </div>
      <?php endif; ?>
      <label class="bp-lb" for="f-offerings"><span>What you offer</span></label>
      <textarea class="bp-in" id="f-offerings" name="offerings" rows="4" maxlength="2000" placeholder="One per line: Matinees, Private screenings, Concessions" <?= $frozen ? 'disabled' : '' ?>><?= $e($meta['offerings'] ?? '') ?></textarea>
      <?php if (!empty($ideas)): ?><p class="bp-m mt-1">Others like you list: <?php foreach ($ideas as $i): ?><button type="button" class="bp-idea" data-idea="<?= $e($i) ?>">+ <?= $e($i) ?></button> <?php endforeach; ?></p><?php endif; ?>
      <p class="bp-m mt-1">Short names, one per line. People searching for any of them find you.</p>
      <div class="mt-3"><button class="bp-b go" type="submit" <?= $frozen ? 'disabled' : '' ?>>Save</button></div>
      <p class="bp-msg" role="status"></p>
    </form>
  <?php endif; ?>
</div>
<script src="/js/cat-more.js?v=<?= (int) @filemtime(__DIR__ . '/../js/cat-more.js') ?>"></script>
<script>
(function () {
  var root = document.querySelector('.bp'); if (!root) return;
  var csrf = root.getAttribute('data-csrf') || '';
  function post(url, body) {
    return fetch(url, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false }; }); });
  }
  function say(form, d) {
    var m = form.querySelector('.bp-msg'); m.className = 'bp-msg ' + (d.ok ? 'ok' : 'bad');
    m.textContent = d.ok ? (d.message || 'Saved.') : ((d.error && d.error.message) || 'Something went wrong. Please try again.');
  }
  var ed = document.getElementById('bp-edit');
  if (ed) {
    var cats = function () { return Array.prototype.map.call(ed.querySelectorAll('select[name="also_cat[]"]'), function (s) { return s.value; }).filter(Boolean); };
    var start = {}; Array.prototype.forEach.call(ed.elements, function (el) { if (el.name && el.name !== 'also_cat[]' && el.name !== 'also_cat_sent') start[el.name] = el.value; });
    var startCats = cats().join(',');
    ed.addEventListener('click', function (ev) {   // an offering idea: added as a line
      var b = ev.target.closest('[data-idea]'); if (!b) return;
      var t = ed.elements.offerings; t.value = (t.value.trim() ? t.value.trim() + '\n' : '') + b.getAttribute('data-idea'); b.remove();
    });
    ed.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var fields = {};
      Array.prototype.forEach.call(ed.elements, function (el) { if (el.name && el.name !== 'also_cat[]' && el.name !== 'also_cat_sent' && el.value !== start[el.name]) fields[el.name] = el.value; });
      if (cats().join(',') !== startCats) fields.also_categories = cats();
      if (!Object.keys(fields).length) return say(ed, { ok: true, message: 'Nothing changed.' });
      post('/listing/api/update-metadata.php', { entity_id: parseInt(ed.getAttribute('data-entity'), 10), fields: fields }).then(function (d) {
        say(ed, d);
        if (d.ok) { Object.keys(fields).forEach(function (k) { start[k] = fields[k]; }); startCats = cats().join(','); }
        if (d.ok && d.waiting && d.waiting.length) setTimeout(function () { location.reload(); }, 1400);
      });
    });
  }
  var an = document.getElementById('bp-answer');
  if (an) an.addEventListener('submit', function (ev) {
    ev.preventDefault();
    post('/listing/api/claim.php', { action: 'answer', dispute_id: parseInt(an.getAttribute('data-dispute'), 10), answer: an.elements.answer.value }).then(function (d) { say(an, d); });
  });
})();
</script>
<?php tv_page_end();
