<?php
// /place/recreation.php?id=f234567 — one public recreation place, on Traversence (decisions/0048).
// Everything people need is here; Recreation.gov is cited as the source, and linked only where a campground's
// reservations can only be made there.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/crawler/RecBulk.php';
require_once __DIR__ . '/../../app/lib/PlaceScope.php';

$pdo = Database::connection();
$r = RecBulk::get($pdo, (string) ($_GET['id'] ?? ''));
$name = $r ? RecBulk::displayName((string) $r['name']) : 'Place not found';

// The nearest town cluster we cover, for context and the way back.
$near = null;
if ($r && $r['lat'] !== null) {
    try {
        $st = $pdo->query('SELECT mc.id, mc.name, COALESCE(mc.center_lat, z.latitude) AS lat, COALESCE(mc.center_lon, z.longitude) AS lon
                             FROM micro_clusters mc LEFT JOIN zip_coordinates z ON z.zip = mc.primary_zip');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $c) {
            if ($c['lat'] === null) continue;
            $x = deg2rad((float) $c['lon'] - (float) $r['lon']) * cos(deg2rad(((float) $c['lat'] + (float) $r['lat']) / 2));
            $y = deg2rad((float) $c['lat'] - (float) $r['lat']);
            $d = 3959 * sqrt($x * $x + $y * $y);
            if ($near === null || $d < $near[2]) $near = [(int) $c['id'], PlaceScope::publicName((string) $c['name']), $d];
        }
    } catch (Throwable) { $near = null; }
    if ($near && $near[2] > 40) $near = null;   // too far to be "near": say the place's own town instead (decisions/0058 §23)
}
// No breadcrumbs: the page says where it is, and its kind, agency and name each search for more like it (decisions/0058 §10)
tv_page_start($name, ['no_crumbs' => true]);
if ($r) tv_count_item('rec:' . $r['ridb_id']);   // the platform's counts
if (!$r): ?>
  <div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Place not found</h1><p class="text-sm text-[#5C4632] mt-2">It may have closed, or it's no longer listed.</p></div>
<?php tv_page_end(); exit; endif;
$kind = RecBulk::kindLabel($r);
$acts = array_values(array_filter(array_map(fn ($a) => ucwords(mb_strtolower(trim($a))), explode(',', (string) $r['activities']))));
$reserve = str_contains((string) $r['url'], 'recreation.gov/camping/') ? (string) $r['url'] : '';
$where = $near ? (string) $near[1] : trim((string) $r['city']);
$in = $where !== '' ? ' near ' . $where : '';
$q = fn (string $words) => tv_e($words . $in);   // what a tap searches for: "Fishing near The Show Low District"
$hasPt = $r['lat'] !== null && $r['lon'] !== null;
$dir = $hasPt ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode((float) $r['lat'] . ',' . (float) $r['lon']) : '';
$tel = trim((string) $r['phone']) !== '' ? preg_replace('/[^\d+]/', '', (string) $r['phone']) : '';
$plural = fn (string $k) => preg_match('/s$/i', $k) ? $k : (preg_match('/y$/i', $k) ? substr($k, 0, -1) . 'ies' : $k . 's');
?>
<style>
  .rp{max-width:46rem;margin-top:.8rem}
  .rp-card{position:relative;background:#FFFBF2;border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.8rem .9rem .9rem}
  .rp-kick{display:flex;flex-wrap:wrap;gap:.15rem .5rem;font-size:.7rem;letter-spacing:.09em;text-transform:uppercase;color:#8A7355;padding-right:2.6rem}
  .rp-q{background:none;border:0;padding:0;font:inherit;text-align:left;letter-spacing:inherit;text-transform:inherit;color:#92400E;cursor:pointer;text-decoration:underline;text-decoration-color:rgba(146,64,14,.3);text-underline-offset:3px}
  .rp-q:hover{text-decoration-color:currentColor}
  .rp h1{margin:.2rem 0 .15rem;padding-right:2.6rem;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.45rem,4.6vw,2.1rem);line-height:1.15;color:#3E2B1F}
  .rp h1 .rp-q{color:#3E2B1F;text-transform:none;letter-spacing:0;text-decoration-color:rgba(62,43,31,.25)}
  .rp-near{font-size:.86rem;color:#5C4632}.rp-near a{color:#92400E;text-decoration:underline}
  /* actions: a column of round icons down the right edge under the Link button, the details on the left (as on listings and directory cards) */
  .rp-card{padding-right:.55rem}
  .rp-body{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:.75rem;margin-top:.5rem;align-items:start}
  .rp-acts{grid-column:2;grid-row:1;display:flex;flex-direction:column;gap:.3rem}
  .rp-info{grid-column:1;grid-row:1}
  .rp-a{display:flex;align-items:center;justify-content:center;width:30px;height:30px;color:#B45309;background:#FFFBF2;border:1px solid #CBB98D;border-radius:999px;cursor:pointer;padding:0;text-decoration:none}
  .rp-a svg{width:17px;height:17px}.rp-a:hover{border-color:#B45309;background:#FEF3C7}
  .rp-info .rp-sum{margin-top:0}
  .rp-sum{font-size:.93rem;line-height:1.6;color:#3E2B1F;margin:.7rem 0 0}
  .rp-pills{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.6rem}
  .rp-pill{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.2rem .65rem;font-size:.8rem;cursor:pointer}
  .rp-pill:hover{border-color:#B45309;color:#92400E}
  .rp-dl{font-size:.86rem;margin-top:.7rem;display:grid;gap:.15rem}.rp-dl dt{display:inline;color:#8A7355}.rp-dl dd{display:inline;margin:0}
  .rp-src{font-size:.72rem;color:#8A7355;margin-top:.6rem}
  /* phones: edge to edge, the phone standard (includes/app-shell.php) */
  /* the action icons: a column under the Link button, the same 30px, the same right edge, .3rem apart (decisions/0058 §11) */
  .rp-card{min-height:11.5rem}
  .rp-body{display:block !important}.rp-info{padding-right:2.6rem}
  .rp-acts{position:absolute;top:calc(.55rem + 30px + .3rem);right:.55rem;display:flex;flex-direction:column;gap:.3rem;z-index:4}
</style>
<?php   // the hero (decisions/0058 §23): the name said once, what it is and where, and its views, likes, comments and Share
require_once __DIR__ . '/../../app/ui/explore-hero.php';
require_once __DIR__ . '/../../app/ui/engage-ui.php';
$nearLine = $near ? 'About ' . max(1, (int) round($near[2])) . ' mi from ' . $near[1] : (trim((string) $r['city']) !== '' ? 'Near ' . trim($r['city'] . ', ' . $r['state'], ', ') : '');
$share = '/user/journeys/compose.php?' . http_build_query(array_filter(['about' => $name, 'key' => $near ? 'cluster:' . (int) $near[0] : '', 'pin' => $hasPt ? (float) $r['lat'] . ',' . (float) $r['lon'] : '']));   // "Share a photo" (decisions/0058 §30)
echo tv_explore_hero($pdo, ['name' => $name, 'heading' => $name, 'edit' => false, 'photos_of' => $name, 'share' => $share, 'share_label' => 'Share a photo', 'near' => $hasPt ? [(float) $r['lat'], (float) $r['lon']] : null, 'scope' => '-',
    'sub' => implode(' · ', array_filter([(string) $kind, $nearLine])),
    'actions' => tv_engage_bar($pdo, 'rec', (string) $r['ridb_id'], ['title' => $name])]); ?>
<div class="rp">
  <article class="rp-card tv-bleed" data-link-host>
    <span data-link="place:rec:<?= tv_e((string) $r['ridb_id']) ?>" data-link-label="<?= tv_e($name) ?>"></span>
    <p class="rp-kick">
      <?php if ($kind): ?><button type="button" class="rp-q" data-q="<?= $q($plural($kind)) ?>" title="Find more <?= tv_e(mb_strtolower($plural($kind))) ?><?= tv_e($in) ?>"><?= tv_e($kind) ?></button><?php endif; ?>
      <?php if (trim((string) $r['org']) !== ''): ?><span aria-hidden="true">·</span><button type="button" class="rp-q" data-q="<?= $q((string) $r['org']) ?>" title="Other places <?= tv_e($r['org']) ?> runs<?= tv_e($in) ?>"><?= tv_e($r['org']) ?></button><?php endif; ?>
    </p>
    <div class="rp-body"><div class="rp-acts" aria-label="Map, directions and contact">
      <?php if ($hasPt): ?><button type="button" class="rp-a" id="rp-map" title="See on map" aria-label="See on map"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><path d="M8 2v16M16 6v16"/></svg></button>
      <a class="rp-a" href="<?= tv_e($dir) ?>" target="_blank" rel="noopener" title="Get directions" aria-label="Get directions"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg></a><?php endif; ?>
      <?php if ($tel): ?><a class="rp-a" href="tel:<?= tv_e($tel) ?>" title="Call" aria-label="Call"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg></a><?php endif; ?>
      <?php if ($reserve): ?><a class="rp-a" href="<?= tv_e($reserve) ?>" target="_blank" rel="noopener" title="Reserve a campsite on Recreation.gov" aria-label="Reserve a campsite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 20 12 4l9 16z"/><path d="M12 20v-6"/></svg></a><?php endif; ?>
    </div><div class="rp-info">
    <?php if (trim((string) $r['summary']) !== ''): ?><p class="rp-sum"><?= tv_e($r['summary']) ?><?= mb_strlen((string) $r['summary']) >= 400 ? '…' : '' ?></p><?php endif; ?>
    <?php if ($acts): // each activity looks for more of it around here ?>
    <div class="rp-pills" aria-label="Activities: find more nearby"><?php foreach (array_slice($acts, 0, 12) as $a): ?><button type="button" class="rp-pill" data-q="<?= $q($a) ?>" title="Find more <?= tv_e(mb_strtolower($a)) ?><?= tv_e($in) ?>"><?= tv_e($a) ?></button><?php endforeach; ?></div>
    <?php endif; ?>
    <dl class="rp-dl">
      <?php if ($tel): ?><div><dt>Phone:</dt> <dd><?= tv_e($r['phone']) ?></dd></div><?php endif; ?>
      <?php if (trim((string) $r['org']) !== ''): ?><div><dt>Managed by:</dt> <dd><?= tv_e($r['org']) ?></dd></div><?php endif; ?>
      <?php if (trim((string) $r['city']) !== ''): ?><div><dt>Near:</dt> <dd><?= tv_e(trim($r['city'] . ', ' . $r['state'], ', ')) ?></dd></div><?php endif; ?>
    </dl>
    <p class="rp-src">Source: Recreation.gov (RIDB), updated <?= tv_e(date('M Y', strtotime((string) $r['loaded_at']))) ?>. Check hours, fees and permits with the managing agency before you go.
      <button type="button" class="underline" data-tv-suggest="<?= tv_e(json_encode(['target' => 'rec:' . $r['ridb_id'], 'target_name' => $name, 'topic' => 'outdoors'] + ($near ? ['place_name' => (string) $near[1], 'place_key' => 'cluster:' . (int) $near[0]] : []), JSON_UNESCAPED_UNICODE)) ?>">Something wrong or missing? Tell us</button></p>
    </div></div>
  </article>
  <?php if ($near): ?><p class="text-sm" style="margin:.7rem .2rem 0"><a class="font-semibold text-amber-800 hover:underline" href="/hub/?cluster=<?= (int) $near[0] ?>#rec-h">More outdoors near <?= tv_e($near[1]) ?> &rsaquo;</a></p><?php endif; ?>
</div>
<script>
  (function () {
    // the kind, the agency, the name and each activity search for more like it, around here (the search panel)
    document.querySelector('.rp').addEventListener('click', function (e) {
      var b = e.target.closest('[data-q]'); if (b && window.TvSearch) TvSearch.open(b.getAttribute('data-q'));
    });
    // See on map: this place and the outdoors around it (10 mi), on the full-screen map, with this one chosen
    var m = document.getElementById('rp-map');
    if (m) m.addEventListener('click', function () {
      if (!window.TvMap) return;
      var here = { lat: <?= $hasPt ? (float) $r['lat'] : 'null' ?>, lon: <?= $hasPt ? (float) $r['lon'] : 'null' ?>, radius: 10 }, id = <?= json_encode('rec:' . $r['ridb_id']) ?>;
      TvMap.open({ panel: true,
        title: <?= json_encode($name) ?>, radius: 10, select: id,
        titleFor: function (d) { return 'Outdoor places around ' + <?= json_encode($name) ?>; },
        load: function (area, words) {
          var a = area || here, qs = new URLSearchParams({ pins: 1, kinds: words ? 'listing,outdoors' : 'outdoors', lat: a.lat, lon: a.lon, radius: a.radius });
          if (words) qs.set('q', words);
          return fetch('/api/search.php?' + qs.toString(), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
            if (!(d.pins || []).some(function (p) { return p.id === id; })) (d.pins = d.pins || []).push({ id: id, lat: here.lat, lon: here.lon, name: <?= json_encode($name) ?>, category: <?= json_encode($kind) ?> });
            d.center = a; return d;
          });
        }
      });
    });
  })();
</script>
<?php require_once __DIR__ . '/../../app/ui/featured-in.php'; echo tv_featured_in($pdo, 'rec:' . $r['ridb_id']);   // what names it (decisions/0132) ?>
<?= tv_engage_comments($pdo, 'rec', (string) $r['ridb_id']) ?>
<script src="/js/link-button.js?v=<?= (int) @filemtime(__DIR__ . '/../js/link-button.js') ?>" defer></script>
<?php tv_page_end();
