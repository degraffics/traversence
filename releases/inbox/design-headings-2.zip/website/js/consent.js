// js/consent.js — privacy choices on every page (decisions/0077).
//
// Two choices, both off until someone says yes, neither needed to use the site:
//   analytics  the analytics service's script loads only when allowed (window.TV_ANALYTICS = {src, name}, set from .env)
//   video      a video from YouTube or Vimeo shows a Play cover and loads only when allowed, or when tapped
// Choices live in the tv_choices cookie (this browser) and, when signed in, on the account (/api/choices.php).
// A slim bar asks a visitor once, only when an analytics service is configured; it never blocks the page.
// TvConsent.allows(tool), TvConsent.set(tool, on) → Promise, TvConsent.open() (the choices card), event 'tv-consent'.
(function () {
  'use strict';
  if (window.TvConsent) return;
  var NAME = 'tv_choices', VER = { analytics: 1, video: 1 };
  function read() {
    var m = document.cookie.match(/(?:^|;\s*)tv_choices=([^;]*)/), o = {};
    try { o = m ? JSON.parse(decodeURIComponent(m[1])) : {}; } catch (e) { o = {}; }
    return o || {};
  }
  // a signed-in person's account choice (window.TV_CHOICES, from the page) wins over this browser's
  function choice(tool) {
    var A = window.TV_CHOICES; if (A && A[tool] !== undefined && A[tool] !== null) return !!A[tool];
    var v = read()[tool]; return v && +v[1] >= (VER[tool] || 1) ? !!+v[0] : null;   // null: not asked yet
  }
  function writeLocal(tool, on) {
    var o = read(), d = new Date(); o[tool] = [on ? 1 : 0, VER[tool] || 1, '' + d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2)];
    document.cookie = NAME + '=' + encodeURIComponent(JSON.stringify(o)) + ';path=/;max-age=' + 365 * 86400 + ';samesite=lax' + (location.protocol === 'https:' ? ';secure' : '');
  }
  var csrf = null;
  function token() {
    if (csrf) return Promise.resolve(csrf);
    if (window.appCsrfToken) return Promise.resolve(csrf = window.appCsrfToken);
    return fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (j) { return (csrf = j.csrf_token || ''); });
  }
  function set(tool, on) {
    writeLocal(tool, on); if (window.TV_CHOICES) window.TV_CHOICES[tool] = !!on; apply();
    try { document.dispatchEvent(new CustomEvent('tv-consent', { detail: { tool: tool, on: on } })); } catch (e) {}
    return token().then(function (t) {
      return fetch('/api/choices.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': t },
        body: JSON.stringify({ tool: tool, on: !!on, page: location.pathname }) });
    }).catch(function () {});
  }

  // ---- analytics: the service's script, only when allowed ----
  var loaded = false;
  function analytics() {
    var A = window.TV_ANALYTICS;
    if (loaded || !A || !A.src || choice('analytics') !== true) return;
    loaded = true;
    var s = document.createElement('script'); s.async = true; s.src = A.src;
    if (A.attrs) for (var k in A.attrs) s.setAttribute(k, A.attrs[k]);
    document.head.appendChild(s);
  }

  // ---- videos: a Play cover until allowed ----
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function load(box) {
    if (box.querySelector('iframe')) return;
    var src = box.getAttribute('data-vsrc');
    box.innerHTML = '<iframe src="' + esc(src) + (src.indexOf('?') < 0 ? '?' : '&') + 'autoplay=' + (box.hasAttribute('data-tapped') ? '1' : '0') + '" title="' + esc(box.getAttribute('data-vtitle') || 'Video') + '" loading="lazy" allow="accelerometer; autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen style="position:absolute;inset:0;width:100%;height:100%;border:0"></iframe>';
  }
  function cover(box) {
    if (box.querySelector('.tvv-cover') || box.querySelector('iframe')) return;
    var src = box.getAttribute('data-vsrc') || '', yt = /youtube/.test(src), id = (src.match(/embed\/([A-Za-z0-9_-]+)/) || [])[1] || (src.match(/video\/(\d+)/) || [])[1] || '';
    var watch = yt ? 'https://www.youtube.com/watch?v=' + id : 'https://vimeo.com/' + id;
    box.innerHTML = '<div class="tvv-cover"><button type="button" class="tvv-play" aria-label="Play video"><svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true"><path d="M8 5v14l11-7z" fill="currentColor"/></svg></button>'
      + '<p class="tvv-note">Plays from ' + (yt ? 'YouTube' : 'Vimeo') + ', which may set its cookies. <a href="' + esc(watch) + '" target="_blank" rel="noopener">Open it there</a> · <button type="button" class="tvv-always">Always play videos</button></p></div>';
  }
  function videos() {
    var on = choice('video') === true;
    [].forEach.call(document.querySelectorAll('.tv-vid[data-vsrc]'), function (b) { on ? load(b) : cover(b); });
  }
  document.addEventListener('click', function (e) {
    var p = e.target.closest('.tvv-play');
    if (p) { var b = p.closest('.tv-vid'); b.setAttribute('data-tapped', ''); load(b); return; }   // this one video, because they tapped it
    if (e.target.closest('.tvv-always')) { set('video', true); return; }
    var o = e.target.closest('[data-choices]'); if (o) { e.preventDefault(); open(); }
  });

  // ---- the choices card (Privacy page, the bar's "Choose", any [data-choices] link) ----
  var TXT = {
    analytics: ['Usage analytics', 'Let us count how Traversence is used, with an analytics service, so we can fix and improve it. Never sold, never used for ads.'],
    video: ['Videos from YouTube', 'Play videos from YouTube or Vimeo right on the page. Playing one lets them see your visit and set their cookies.']
  };
  function card(host) {
    var h = '<div class="tvc-card"><p class="tvc-h">Your privacy choices</p><p class="tvc-sub">Both are off until you say yes. Traversence works the same either way. We never sell your information.</p>';
    ['analytics', 'video'].forEach(function (t) {
      var c = choice(t);
      h += '<label class="tvc-row"><span><b>' + TXT[t][0] + '</b><small>' + TXT[t][1] + '</small></span><input type="checkbox" role="switch" data-tvc="' + t + '"' + (c ? ' checked' : '') + ' aria-label="' + TXT[t][0] + '"></label>';
    });
    h += '<p class="tvc-foot">Necessary cookies keep you signed in and keep forms safe; they can\'t be turned off. <a href="/privacy.php#cookies">What we store</a></p></div>';
    host.innerHTML = h;
  }
  document.addEventListener('change', function (e) {
    var c = e.target.closest('[data-tvc]'); if (!c) return;
    set(c.getAttribute('data-tvc'), c.checked).then(function () { if (window.TvAsk) TvAsk.say('Saved.', { anchor: c }); });
  });
  function open() {
    var bar = document.getElementById('tvc-bar'); if (bar) bar.remove();
    var wrap = document.createElement('div'); wrap.className = 'tvc-pop'; wrap.innerHTML = '<div class="tvc-dim"></div><div class="tvc-box" role="dialog" aria-label="Privacy choices"><button type="button" class="tvc-x" aria-label="Close">&times;</button><div></div></div>';
    document.body.appendChild(wrap); card(wrap.querySelector('.tvc-box > div'));
    wrap.addEventListener('click', function (e) { if (e.target.closest('.tvc-x') || e.target.classList.contains('tvc-dim')) wrap.remove(); });
  }

  // ---- the visitor bar: once, only when an analytics service is set up and nothing was chosen ----
  function bar() {
    if (!window.TV_ANALYTICS || !window.TV_ANALYTICS.src || choice('analytics') !== null || document.getElementById('tvc-bar')) return;
    if (/\/privacy\.php/.test(location.pathname)) return;   // the page itself has the choices
    var b = document.createElement('div'); b.id = 'tvc-bar'; b.setAttribute('role', 'region'); b.setAttribute('aria-label', 'Privacy choice');
    b.innerHTML = '<p>May we count how you use Traversence' + (window.TV_ANALYTICS.name ? ' with ' + esc(window.TV_ANALYTICS.name) : '') + ', to improve it? Never sold, never for ads.</p>'
      + '<div><button type="button" class="tvc-b yes" data-bar="1">Allow</button><button type="button" class="tvc-b" data-bar="0">No thanks</button><button type="button" class="tvc-link" data-choices>Choices</button></div>';
    document.body.appendChild(b);
    b.addEventListener('click', function (e) { var x = e.target.closest('[data-bar]'); if (!x) return; set('analytics', x.getAttribute('data-bar') === '1'); b.remove(); });
  }

  function apply() { analytics(); videos(); }
  var css = '.tv-vid{position:relative;width:100%;aspect-ratio:16/9;background:#2A1B12;border-radius:.6rem;overflow:hidden}'
    + '.tvv-cover{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.6rem;padding:.8rem;text-align:center;background:linear-gradient(180deg,#3E2B1F,#2A1B12);color:#EFE3C8}'
    + '.tvv-play{width:64px;height:64px;border-radius:999px;border:2px solid #EFE3C8;background:rgba(239,227,200,.12);color:#EFE3C8;display:flex;align-items:center;justify-content:center;cursor:pointer}'
    + '.tvv-play:hover{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}.tvv-note{font-size:.78rem;margin:0;color:#E3D3AC}.tvv-note a,.tvv-note button{color:#F3D9A4;text-decoration:underline;background:none;border:0;font:inherit;cursor:pointer;padding:0}'
    + '#tvc-bar{position:fixed;left:8px;right:8px;bottom:8px;z-index:70;max-width:44rem;margin:0 auto;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:.5rem .8rem;background:#3E2B1F;color:#EFE3C8;border-radius:.8rem;padding:.6rem .8rem;box-shadow:0 8px 24px rgba(0,0,0,.25);font-size:.88rem}'
    + '#tvc-bar p{margin:0;flex:1 1 16rem}#tvc-bar div{display:flex;gap:.4rem;align-items:center}'
    + '.tvc-b{border-radius:.55rem;padding:.35rem .8rem;font-weight:700;border:1px solid #CBB98D;background:transparent;color:#EFE3C8;cursor:pointer}.tvc-b.yes{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}'
    + '.tvc-link{background:none;border:0;color:#F3D9A4;text-decoration:underline;cursor:pointer;font:inherit}'
    + '.tvc-pop{position:fixed;inset:0;z-index:80;display:flex;align-items:center;justify-content:center;padding:12px}.tvc-dim{position:absolute;inset:0;background:rgba(42,27,18,.45)}'
    + '.tvc-box{position:relative;background:#FFFBF2;border-radius:1rem;max-width:30rem;width:100%;padding:1rem;box-shadow:0 20px 50px rgba(0,0,0,.3)}.tvc-x{position:absolute;right:.5rem;top:.3rem;border:0;background:none;font-size:1.5rem;color:#5C4632;cursor:pointer}'
    + '.tvc-card .tvc-h{font:700 1.1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:0}.tvc-sub{font-size:.85rem;color:#5C4632;margin:.25rem 0 .4rem}'
    + '.tvc-row{display:flex;justify-content:space-between;align-items:center;gap:.8rem;padding:.6rem 0;border-top:1px solid #EADFC4;cursor:pointer}.tvc-row b{display:block;color:#3E2B1F}.tvc-row small{display:block;color:#5C4632;font-size:.8rem;line-height:1.35}'
    + '.tvc-row input{width:2.6rem;height:1.4rem;accent-color:#3F7A5E;flex-shrink:0}.tvc-foot{font-size:.75rem;color:#8A7355;margin:.4rem 0 0}.tvc-foot a{text-decoration:underline}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  function boot() { apply(); bar(); [].forEach.call(document.querySelectorAll('[data-choices-card]'), card); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.TvConsent = { allows: function (t) { return choice(t) === true; }, choice: choice, set: set, open: open, card: card };
})();
