// js/short-link.js — short trvgo.us links for sharing, and a page's QR code (decisions/0094). Loaded on every page.
//
//   tvShort(url)       -> Promise of the short address (https://trvgo.us/k7qm2x), or the url itself if it can't be
//                         shortened (another site, an admin page) or the network fails. Asked once per page.
//   tvShort.now(url)   the short address if it's already known, else the url: for a Share button, which must open
//                      the phone's share sheet straight away. Share buttons are warmed as they come into view or
//                      are touched, so the short one is ready by the time they're tapped.
//   tvQr(url, {anchor, title})   a small card with the page's QR code (its trvgo.us address), to scan or download.
//   [data-qr="/path"] (or [data-qr] for this page) on any button opens it.
(function () {
  'use strict';
  if (window.tvShort) return;
  var cache = {}, known = {};
  function abs(u) { try { return new URL(u || location.href, location.href).href.replace(/#.*$/, ''); } catch (e) { return u; } }
  function tvShort(u) {
    u = abs(u);
    if (known[u]) return Promise.resolve(known[u]);
    if (!cache[u]) {
      cache[u] = fetch('/api/short.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(window.tvSafe ? tvSafe({ url: u }) : { url: u }) })
        .then(function (r) { return r.json(); })
        .then(function (d) { if (d.ok && d.short) { known[u] = d.short; return d.short; } return u; })
        .catch(function () { delete cache[u]; return u; });
    }
    return cache[u];
  }
  tvShort.now = function (u) { u = abs(u); if (!known[u]) tvShort(u); return known[u] || u; };
  tvShort.warm = function (u) { tvShort(u); };
  window.tvShort = tvShort;

  // Share buttons: warm the short link when one is in view or touched (never for a page nobody looks at)
  var SEL = '[data-eg-share],#jv-share,[data-short-warm]';
  function urlOf(el) { return el.getAttribute('data-short-warm') || location.href; }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { tvShort(urlOf(e.target)); io.unobserve(e.target); } }); });
    var watch = function () { document.querySelectorAll(SEL).forEach(function (el) { if (!el._tvW) { el._tvW = 1; io.observe(el); } }); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch); else watch();
  }
  document.addEventListener('pointerdown', function (e) { var el = e.target.closest && e.target.closest(SEL); if (el) tvShort(urlOf(el)); }, true);

  // ---- the QR card -----------------------------------------------------------------------------------------------
  var css = '.tvq-dim{position:fixed;inset:0;background:rgba(62,43,31,.4);z-index:1800}'
    + '.tvq{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:1801;width:min(19rem,calc(100vw - 2rem));background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;box-shadow:0 18px 40px -12px rgba(0,0,0,.5);padding:1rem;text-align:center;color:#3E2B1F;font-size:.85rem}'
    + '.tvq h3{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1rem;margin:0 1.4rem .5rem;line-height:1.3}'
    + '.tvq img{width:100%;max-width:14rem;aspect-ratio:1;background:#fff;border-radius:.3rem;display:block;margin:0 auto}'
    + '.tvq .u{margin:.45rem 0;font-weight:600;word-break:break-all}.tvq .x{position:absolute;top:.3rem;right:.5rem;border:0;background:none;font-size:1.3rem;color:#8A7355;cursor:pointer}'
    + '.tvq .r{display:flex;gap:.4rem;justify-content:center;flex-wrap:wrap;margin-top:.4rem}.tvq a,.tvq button.b{border:1px solid #CBB98D;background:#fff;color:#3E2B1F;border-radius:.55rem;padding:.35rem .65rem;font-weight:600;font-size:.8rem;text-decoration:none;cursor:pointer}'
    + '.tvq .n{font-size:.75rem;color:#8A7355;margin-top:.5rem}.tvq .n a{border:0;padding:0;background:none;color:#92400E;text-decoration:underline;font-weight:600}';
  var styled = false;
  function close() { var a = document.querySelector('.tvq'), b = document.querySelector('.tvq-dim'); if (a) a.remove(); if (b) b.remove(); document.removeEventListener('keydown', key, true); }
  function key(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
  function tvQr(u, o) {
    o = o || {};
    if (!styled) { var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st); styled = true; }
    close();
    var page = abs(u), path;
    try { var p = new URL(page); path = p.pathname + p.search; } catch (e) { path = page; }
    var src = '/api/qr.php?page=' + encodeURIComponent(path);
    var dim = document.createElement('div'); dim.className = 'tvq-dim'; dim.addEventListener('click', close);
    var box = document.createElement('div'); box.className = 'tvq'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'QR code');
    box.innerHTML = '<button type="button" class="x" aria-label="Close">×</button><h3></h3>'
      + '<img alt="QR code for this page" src="' + src + '&format=svg">'
      + '<div class="u">…</div>'
      + '<div class="r"><a href="' + src + '&format=svg&download=1">Download for print</a><a href="' + src + '&format=png&px=1200&download=1">PNG</a><button type="button" class="b" data-c>Copy link</button></div>'
      + '<div class="n">Scan it, or print it. Want your own colors, your logo, or a code you can change later? <a href="/qr/">GO Codes</a></div>';
    box.querySelector('h3').textContent = o.title || document.title.replace(/\s*[·|–-]\s*Traversence.*$/, '');
    box.querySelector('.x').addEventListener('click', close);
    document.body.appendChild(dim); document.body.appendChild(box);
    document.addEventListener('keydown', key, true);
    tvShort(page).then(function (s) {
      var el = box.querySelector('.u'); if (el) el.textContent = s.replace(/^https?:\/\//, '');
      box.querySelector('[data-c]').addEventListener('click', function (e) {
        var b = e.currentTarget;
        (navigator.clipboard ? navigator.clipboard.writeText(s) : Promise.reject()).then(function () { b.textContent = 'Copied'; }, function () { TvAsk.ask('Copy this link', s, { yes: 'Done' }); });
      });
    });
    box.querySelector('.x').focus();
  }
  window.tvQr = tvQr;
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-qr]');
    if (!b) return;
    e.preventDefault();
    tvQr(b.getAttribute('data-qr') || location.href, { anchor: b, title: b.getAttribute('data-qr-title') || '' });
  });
})();
