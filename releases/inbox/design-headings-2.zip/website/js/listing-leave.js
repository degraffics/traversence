// js/listing-leave.js — Leave a message on an unclaimed listing (decisions/0172 §3.3), in Message's place on its page.
// <div id="lm" data-e data-name data-route="email|held" data-before data-button data-signed-in data-call></div>
// The words before and the button come from the server by the route (ListingMessages::words): held reads "Leave it for
// them", emailed "Send by email", never Send. A message needs a way to answer its sender: an account, a confirmed email
// or a phone with the guest's say-so; with none, the form doesn't send. A guest gets a reply code: "Keep this code: it's
// the only way back to your message". Check a reply shows where it stands; Withdraw takes it back any time before it's
// delivered. Every press shows a spinner and answers beside the button (TvAsk), never a browser dialog.
(function () {
  'use strict';
  var root = document.getElementById('lm');
  if (!root) return;
  var API = '/listing/api/leave.php', e = +root.getAttribute('data-e'), listing = root.getAttribute('data-name') || 'this business';
  var signedIn = root.getAttribute('data-signed-in') === '1', call = root.getAttribute('data-call') || '';
  var csrf = null, ch = null;
  var css = '#lm{scroll-margin-top:5rem}#lm [hidden]{display:none!important}.lm-h{font:700 1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:0 0 .3rem}.lm-p{font-size:.82rem;color:#5C4632;margin:.3rem 0;line-height:1.45}'
    + '.lm-b{display:inline-flex;align-items:center;justify-content:center;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:.7rem;padding:.45rem .8rem;font-size:.85rem;font-weight:600;cursor:pointer;text-decoration:none}'
    + '.lm-b.go{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.lm-row{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.5rem}'
    + '.lm-l{display:block;font-size:.78rem;color:#5C4632;margin-top:.55rem}.lm-in{display:block;width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.6rem;background:#FFFBF2;padding:.45rem .55rem;font-size:.92rem;margin-top:.15rem;color:#3E2B1F}'
    + '.lm-hp{position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden}.lm-ch{display:flex;flex-wrap:wrap;gap:.25rem .9rem;font-size:.86rem;margin-top:.25rem;color:#3E2B1F}'
    + '.lm-ok{display:flex;gap:.45rem;align-items:flex-start;font-size:.8rem;color:#5C4632;margin-top:.4rem}.lm-ok input{margin-top:.2rem}'
    + '.lm-code{font-family:ui-monospace,monospace;font-size:1.3rem;font-weight:700;letter-spacing:.08em;background:#FFFBF2;border:1px dashed #B8863B;border-radius:.6rem;padding:.35rem .6rem;display:inline-block;margin:.3rem 0}'
    + '.lm-st{display:inline-block;font-size:.72rem;font-weight:700;border-radius:999px;padding:.12rem .55rem;border:1px solid #B45309;color:#92400E;background:#FFF8EA}'
    + '.lm-st.ok{border-color:#15803D;color:#15803D;background:#F0FAF2}.lm-msg{border:1px solid #E3D3AC;border-radius:.6rem;padding:.4rem .55rem;margin-top:.4rem;font-size:.85rem;background:#FFFBF2;white-space:pre-line;overflow-wrap:anywhere}'
    + '.lm-msg.biz{background:#F7EFDC}.lm-msg small{display:block;font-size:.68rem;color:#8A7355;white-space:normal}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function get() {
    return fetch(API + '?challenge=' + e, { credentials: 'include', headers: { Accept: 'application/json' } }).then(function (r) { return r.json(); })
      .then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'Not available right now.'); csrf = d.csrf; ch = d; return d; });
  }
  function post(body) {
    var go = function () {
      return fetch(API, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
        .then(function (r) { return r.json().then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn’t go through. Try again.'); return d; }); });
    };
    return csrf ? go() : get().then(go);
  }
  // a press: a spinner on the button, then the answer beside it
  function press(btn, p, ok) {
    if (window.TvAsk) TvAsk.busy(btn, true);
    return p.then(function (d) { if (window.TvAsk) TvAsk.busy(btn, false); return ok(d); })
      .catch(function (x) { if (window.TvAsk) { TvAsk.busy(btn, false); TvAsk.say(x.message, { anchor: btn, bad: true }); } });
  }
  function remember(code) { try { localStorage.setItem('tv_lm_' + e, code); } catch (x) {} }
  function remembered() { try { return localStorage.getItem('tv_lm_' + e) || ''; } catch (x) { return ''; } }
  function forget() { try { localStorage.removeItem('tv_lm_' + e); } catch (x) {} }
  function stateTag(t) { return '<span class="lm-st' + (t.state === 'delivered' || t.state === 'answered' ? ' ok' : '') + '">' + esc(t.state_label) + '</span>'; }
  function callLine() { return call ? ' <a class="lm-b" href="' + esc(call) + '" data-out="call" data-e="' + e + '">Call them</a>' : ''; }

  function home() {
    root.innerHTML = '<p class="lm-p">Loading…</p>';
    get().then(function (d) {
      var mine = (d.mine || [])[0];
      if (mine) return showMine(mine);
      root.innerHTML = '<p class="lm-h">Leave ' + esc(listing) + ' a message</p><p class="lm-p">' + esc(d.before) + '</p>'
        + '<div class="lm-row"><button type="button" class="lm-b go" data-leave>Leave a message</button><button type="button" class="lm-b" data-check>Check a reply</button>' + callLine() + '</div>';
    }).catch(function (x) { root.innerHTML = '<p class="lm-p">' + esc(x.message) + '</p>' + (call ? '<div class="lm-row">' + callLine() + '</div>' : ''); });
  }

  function form() {
    var d = ch || {};
    root.innerHTML = '<form class="lm-f" autocomplete="on" novalidate><p class="lm-h">Leave ' + esc(listing) + ' a message</p><p class="lm-p">' + esc(d.before) + '</p>'
      + (signedIn ? '' : '<label class="lm-l">Your first name<input class="lm-in" name="name" maxlength="40" required autocomplete="given-name" data-spell></label>')
      + '<label class="lm-l">Your message<textarea class="lm-in" name="body" rows="4" maxlength="2000" required data-spell></textarea></label>'
      + '<p class="lm-p" style="font-size:.74rem">Words only: links are taken out. Up to 2,000 characters.</p>'
      + (signedIn ? '<p class="lm-p">It waits in your Pulse, marked where it stands, and any answer comes there.</p>'
        : '<span class="lm-l">How should they answer you? (one is needed)</span><div class="lm-ch">'
          + '<label><input type="radio" name="answer_by" value="email"> By email</label><label><input type="radio" name="answer_by" value="phone"> By phone</label></div>'
          + '<label class="lm-l" data-by="email" hidden>Your email (we confirm it first; the business never sees it)<input class="lm-in" type="email" name="email" maxlength="160" autocomplete="email" spellcheck="false"></label>'
          + '<div data-by="phone" hidden><label class="lm-l">Your phone number<input class="lm-in" type="tel" name="phone" maxlength="40" autocomplete="tel" spellcheck="false"></label>'
          + '<label class="lm-ok"><input type="checkbox" name="phone_ok"> <span>' + esc(listing) + ' may have my number once it claims its listing, to call me back.</span></label></div>'
          + '<div class="lm-hp" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>'
          + '<label class="lm-l">Quick check: ' + esc(d.question || '') + '<input class="lm-in" name="answer" inputmode="numeric" maxlength="3" required style="max-width:6rem" spellcheck="false"></label>')
      + '<div class="lm-row"><button class="lm-b go" type="submit">' + esc(d.button || 'Leave it for them') + '</button><button type="button" class="lm-b" data-home>Cancel</button></div></form>';
    var f = root.querySelector('form');
    f.addEventListener('change', function (ev) {
      if (ev.target.name !== 'answer_by') return;
      f.querySelectorAll('[data-by]').forEach(function (x) { x.hidden = x.getAttribute('data-by') !== ev.target.value; });
    });
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var btn = f.querySelector('[type=submit]'), by = f.querySelector('[name=answer_by]:checked');
      if (!signedIn && !by) { if (window.TvAsk) TvAsk.say('Choose how they can answer you: by email or by phone.', { anchor: btn, bad: true }); return; }
      var body = { do: 'leave', entity_id: e, body: f.body.value };
      if (!signedIn) {
        body.nonce = ch && ch.nonce; body.answer = f.answer.value; body.website = f.website.value; body.name = f.name.value; body.answer_by = by.value;
        body.email = f.email.value; body.phone = f.phone.value; body.phone_ok = f.phone_ok.checked;
      }
      press(btn, post(body), function (r) { if (r.code) remember(r.code); left(r); })
        .then(function () { if (!signedIn && document.body.contains(f)) get().then(function (c) { f.answer.value = ''; f.answer.parentNode.firstChild.textContent = 'Quick check: ' + c.question; }); });   // each check is used once
    });
  }

  function left(r) {
    root.innerHTML = '<p class="lm-h">' + (r.state === 'confirm' ? 'One more step' : 'Left for ' + esc(listing)) + '</p><p class="lm-p">' + esc(r.said) + '</p>'
      + (r.code ? '<p class="lm-p" style="color:#3E2B1F">Your reply code:</p><div class="lm-code">' + esc(r.code) + '</div>'
        + '<p class="lm-p"><b>Keep this code: it’s the only way back to your message</b>, here under "Check a reply"' + (r.state === 'confirm' ? ' (it’s in the email too)' : '') + '.</p>' : '')
      + '<div class="lm-row"><button type="button" class="lm-b" data-home>Done</button></div>';
  }

  function check(prefill) {
    root.innerHTML = '<form class="lm-c"><p class="lm-h">Check a reply</p><label class="lm-l">Reply code<input class="lm-in" name="code" required maxlength="12" autocapitalize="characters" placeholder="ABCD-EFGH" spellcheck="false" value="' + esc(prefill) + '"></label>'
      + '<div class="lm-row"><button class="lm-b go" type="submit">Open</button><button type="button" class="lm-b" data-home>Cancel</button></div>'
      + '<p class="lm-p" style="font-size:.74rem">Lost your code? With no email given, the message can’t be found again; leave a new one.</p></form>';
    var f = root.querySelector('form');
    f.addEventListener('submit', function (ev) { ev.preventDefault(); var btn = f.querySelector('[type=submit]'), code = f.code.value; press(btn, post({ do: 'check', code: code }), function (r) { remember(code); show(code, r.thread); }); });
  }

  function thread(name, t) {
    return (t.messages || []).map(function (m) {
      return '<div class="lm-msg' + (m.from_business ? ' biz' : '') + '"><small>' + (m.from_business ? esc(name) : 'You') + ' · ' + esc(String(m.at).slice(0, 16)) + '</small>' + esc(m.body) + '</div>';
    }).join('');
  }

  function show(code, t) {
    root.innerHTML = '<p class="lm-h">Your message to ' + esc(t.listing) + '</p>' + (t.state_label ? '<p>' + stateTag(t) + '</p><p class="lm-p">' + esc(t.state_note) + '</p>' : '')
      + thread(t.listing, t)
      + (t.can_write ? '<form class="lm-r" style="margin-top:.5rem"><textarea class="lm-in" name="body" rows="2" maxlength="2000" required data-spell placeholder="Write back"></textarea><button class="lm-b go" type="submit" style="margin-top:.35rem">Send</button></form>' : '')
      + '<div class="lm-row">' + (t.state === 'confirm' ? '<button type="button" class="lm-b" data-resend>Send the confirm link again</button>' : '')
      + (t.can_withdraw ? '<button type="button" class="lm-b" data-withdraw>Withdraw it</button>' : '') + '<button type="button" class="lm-b" data-home>Close</button></div>'
      + (signedIn ? '<p class="lm-p">Signed in: <button type="button" class="lm-b" data-move style="padding:.25rem .6rem">Keep it in my account</button> moves it to your Pulse; the code stops working.</p>' : '');
    root.__code = code;
    var f = root.querySelector('.lm-r');
    if (f) f.addEventListener('submit', function (ev) { ev.preventDefault(); press(f.querySelector('[type=submit]'), post({ do: 'reply', code: code, body: f.body.value }), function (r) { show(code, r.thread); }); });
  }

  function showMine(m) {
    root.innerHTML = '<p class="lm-h">Your message to ' + esc(listing) + '</p><p>' + stateTag(m) + '</p><p class="lm-p">' + esc(m.state_note) + '</p>'
      + thread(listing, m)
      + (m.can_write ? '<form class="lm-r" style="margin-top:.5rem"><textarea class="lm-in" name="body" rows="2" maxlength="2000" required data-spell placeholder="Write back"></textarea><button class="lm-b go" type="submit" style="margin-top:.35rem">Send</button></form>' : '')
      + '<div class="lm-row">' + (m.can_withdraw ? '<button type="button" class="lm-b" data-withdraw-id="' + m.id + '">Withdraw it</button>' : '') + callLine() + '</div>'
      + '<p class="lm-p">It’s in your <a href="/user/dashboard.php#pulse" style="color:#92400E;font-weight:600">Pulse</a> too.</p>';
    var f = root.querySelector('.lm-r');
    if (f) f.addEventListener('submit', function (ev) { ev.preventDefault(); press(f.querySelector('[type=submit]'), post({ do: 'reply', id: m.id, entity_id: e, body: f.body.value }), function (r) { if (r.mine && r.mine[0]) showMine(r.mine[0]); }); });
  }

  root.addEventListener('click', function (ev) {
    var t = ev.target;
    if (t.closest('[data-leave]')) { var b = t.closest('[data-leave]'); press(b, ch ? Promise.resolve(ch) : get(), form); return; }
    if (t.closest('[data-check]')) { check(remembered()); return; }
    if (t.closest('[data-home]')) { home(); return; }
    var w = t.closest('[data-withdraw],[data-withdraw-id]');
    if (w) {
      if (window.TvAsk && !TvAsk.gate(w, 'Withdraw your message? It’s deleted, with your email, and never delivered.', { yes: 'Withdraw it', danger: true })) return;
      var id = +(w.getAttribute('data-withdraw-id') || 0);
      press(w, post(id ? { do: 'withdraw', id: id } : { do: 'withdraw', code: root.__code }), function () { forget(); home(); if (window.TvAsk) TvAsk.say('Withdrawn: your message is deleted.', { anchor: root.querySelector('.lm-b') || root }); });
      return;
    }
    var rs = t.closest('[data-resend]');
    if (rs) { press(rs, post({ do: 'resend', code: root.__code }), function () { if (window.TvAsk) TvAsk.say('Sent: a new link is on its way to your email.', { anchor: rs }); }); return; }
    var mv = t.closest('[data-move]');
    if (mv) press(mv, fetch('/api/guest-inquiry.php?challenge=' + e, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (c) {
      return fetch('/api/guest-inquiry.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c.csrf || '' }, body: JSON.stringify({ code: root.__code, move: true }) })
        .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn’t move.'); return d; });
    }), function () { forget(); home(); });
  });
  // the Leave a message icon on the card opens the form here
  document.addEventListener('click', function (ev) {
    var o = ev.target.closest('[data-lm-open]'); if (!o) return;
    ev.preventDefault(); root.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (!root.querySelector('form') && !root.querySelector('.lm-st')) press(o, ch ? Promise.resolve(ch) : get(), form);
  });
  home();
  if (location.hash === '#lm') setTimeout(function () { root.scrollIntoView({ block: 'start' }); }, 300);
})();
