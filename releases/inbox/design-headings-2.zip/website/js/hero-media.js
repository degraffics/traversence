// js/hero-media.js — the owner's "Photos & video" panel on a listing's or a profile's hero (decisions/0058 §21;
// /api/hero-media.php). Add photos (several at once), add a YouTube or Vimeo link, put one first, remove one.
// The page reloads when the panel closes after a change, so the hero shows them.
(function () {
  if (window.tvHeroMedia) return;
  window.tvHeroMedia = true;
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var css = document.createElement('style');
  css.textContent = '.hm-bg{position:fixed;inset:0;z-index:90;background:rgba(30,20,12,.55);display:flex;align-items:flex-end;justify-content:center}'
    + '@media (min-width:768px){.hm-bg{align-items:center}}'
    + '.hm{background:#FFFBF2;color:#3E2B1F;width:min(34rem,100%);max-height:88vh;overflow:auto;border-radius:1rem 1rem 0 0;padding:1rem 1.1rem;box-shadow:0 -10px 30px -10px rgba(0,0,0,.5)}'
    + '@media (min-width:768px){.hm{border-radius:1rem}}'
    + '.hm h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.2rem;margin:0 0 .2rem}.hm p{font-size:.84rem;color:#5C4632;margin:.2rem 0 .7rem}'
    + '.hm-list{display:grid;grid-template-columns:repeat(3,1fr);gap:.4rem;margin:.5rem 0 .8rem}.hm-it{position:relative;aspect-ratio:1;border-radius:.5rem;background:#3E2B1F center/cover no-repeat;overflow:hidden}'
    + '.hm-it span{position:absolute;inset:auto 0 0 0;display:flex;gap:.2rem;padding:.25rem;background:linear-gradient(transparent,rgba(0,0,0,.65))}.hm-it button{flex:1;border:0;border-radius:.35rem;font-size:.68rem;font-weight:700;padding:.2rem;cursor:pointer;background:#FFFBF2;color:#3E2B1F}'
    + '.hm-it .v{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.6rem}.hm-it.first{outline:3px solid #8FBCA8}'
    + '.hm-row{display:flex;gap:.4rem;margin:.4rem 0}.hm-row input[type=text]{flex:1;min-width:0;border:1px solid #CBB98D;border-radius:.5rem;padding:.45rem .55rem;font:inherit;font-size:.88rem}'
    + '.hm-b{border:1px solid #CBB98D;border-radius:999px;background:#FFFBF2;color:#3E2B1F;font:inherit;font-size:.85rem;font-weight:700;padding:.45rem .9rem;cursor:pointer}.hm-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFFBF2}'
    + '.hm-msg{font-size:.82rem;min-height:1.1em;margin:.3rem 0}.hm-msg.err{color:#B91C1C}';
  document.head.appendChild(css);

  var csrf = null, kind, ref, changed = false, bg;
  function api(method, body, isForm) {
    var h = { 'X-CSRF-Token': csrf || '' }; if (!isForm) h['Content-Type'] = 'application/json';
    return fetch('/api/hero-media.php' + (method === 'GET' ? '?kind=' + kind + '&ref=' + ref : ''), { method: method, credentials: 'include', headers: method === 'GET' ? {} : h, body: method === 'GET' ? undefined : (isForm ? body : JSON.stringify(body)) })
      .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error(d.error && d.error.message ? d.error.message : 'That didn’t work.'); return d; });
  }
  function msg(t, err) { var m = bg.querySelector('.hm-msg'); m.textContent = t || ''; m.className = 'hm-msg' + (err ? ' err' : ''); }
  function paint() {
    return api('GET').then(function (d) {
      csrf = d.csrf || csrf;
      bg.querySelector('.hm-list').innerHTML = d.items.length ? d.items.map(function (m, i) {
        return '<div class="hm-it' + (i === 0 ? ' first' : '') + '"' + (m.kind === 'photo' ? ' style="background-image:url(\'' + esc(m.card_path) + '\')"' : '') + '>' + (m.kind === 'video' ? '<b class="v">▶</b>' : '')
          + '<span>' + (i ? '<button type="button" data-first="' + m.id + '">First</button>' : '') + '<button type="button" data-rm="' + m.id + '">Remove</button></span></div>';
      }).join('') : '<p style="grid-column:1/-1">Nothing yet. The hero shows the brand’s art until you add some.</p>';
    }).catch(function (x) { msg(x.message, true); });
  }
  function open(k, r) {
    kind = k; ref = r; changed = false;
    bg = document.createElement('div'); bg.className = 'hm-bg';
    bg.innerHTML = '<div class="hm" role="dialog" aria-modal="true" aria-label="Photos and video"><h2>Photos &amp; video</h2>'
      + '<p>Up to 8, shown across the top of ' + (kind === 'user' ? 'your profile' : 'the listing') + '. The first one shows first. Use your own photos, or ones you have permission to use; nothing from the original file (like where it was taken) is kept.</p>'
      + '<div class="hm-list"></div>'
      + '<div class="hm-row"><label class="hm-b go" style="display:inline-block">Add photos<input type="file" accept="image/jpeg,image/png,image/webp" multiple hidden data-up' + (kind === 'listing' ? ' data-art-b="' + ref + '"' : '') + '></label></div>'
      + '<div class="hm-row"><input type="text" placeholder="YouTube or Vimeo link" data-url><button type="button" class="hm-b" data-vid>Add video</button></div>'
      + '<p class="hm-msg"></p><div class="hm-row" style="justify-content:flex-end"><button type="button" class="hm-b go" data-close>Done</button></div></div>';
    document.body.appendChild(bg);
    paint();
    bg.addEventListener('click', function (e) {
      if (e.target === bg || e.target.closest('[data-close]')) { bg.remove(); if (changed) location.reload(); return; }
      var rm = e.target.closest('[data-rm]'), fi = e.target.closest('[data-first]');
      if (rm) { api('POST', { action: 'remove', id: +rm.getAttribute('data-rm') }).then(function () { changed = true; paint(); }).catch(function (x) { msg(x.message, true); }); return; }
      if (fi) { api('POST', { action: 'first', id: +fi.getAttribute('data-first') }).then(function () { changed = true; paint(); }).catch(function (x) { msg(x.message, true); }); return; }
      if (e.target.closest('[data-vid]')) {
        var u = bg.querySelector('[data-url]');
        api('POST', { action: 'video', kind: kind, ref: ref, url: u.value }).then(function () { u.value = ''; changed = true; msg('Video added.'); paint(); }).catch(function (x) { msg(x.message, true); });
      }
    });
    bg.querySelector('[data-up]').addEventListener('change', function (e) {
      var files = [].slice.call(e.target.files || []); e.target.value = ''; if (!files.length || !window.TvUpload) return;
      // the site's one uploader (js/tv-upload.js, decisions/0127): made a sensible size on the phone, a progress bar
      TvUpload.send(files, { target: 'hero_photo', ctx: { kind: kind, ref: ref }, shrink: 2400, el: e.target.closest('label') || e.target })
        .then(function () { changed = true; msg(''); paint(); }, function () { paint(); });
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-hm-kind]'); if (!b) return;
    open(b.getAttribute('data-hm-kind'), +b.getAttribute('data-hm-ref'));
  });
})();
