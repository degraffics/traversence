/*
 * js/tv-proof.js — a proof in a lightbox (Jason, 2026-10-16; decisions/0101). Only the proof shows, whole, on a dark
 * backdrop; a bar across the top of the window stays in view: "PROOF: title", what to do about it (Approve, Make
 * changes) and ×. The proof is 60% of the window's width (80% on a small laptop, the full width less 12px on a phone); a long
 * one shows at full length and the backdrop scrolls, like a page, never a box with its own scroll bar.
 * Shown square, to its edges, with a red dashed line on the edge for the cut (Jason: no rounded corners unless the
 * piece is cut that way). Images show at their own resolution scaled to fit; a PDF is drawn page by page at the screen's full sharpness
 * (pdf.js, without eval: order.php is a card page and its policy forbids it, decisions/0098); a GO Code shows as its vector
 * QR beside everything it holds.
 *
 * How it's shown (the buttons in the bar, remembered on this device; Jason, 2026-10-28): Width (the default above),
 * Page (each page whole, top to bottom of the window) and 2, 3 or 4 pages across, in rows.
 *
 * Declarative: <button data-proof="image|pdf|go" data-proof-src="…" data-proof-title="…"
 *                      data-proof-info="#template" data-proof-acts="#template">
 * The templates' content is copied in: info under a GO Code's QR, acts into the bar (forms post as usual).
 */
(function () {
  if (window.TvProof) return;
  var PDFJS = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/';
  // the backdrop scrolls (not a box inside it), so a long proof shows whole, like a page; the bar sits on top of it
  var css = '.tvpf-lb{position:fixed;inset:0;z-index:1950;background:rgba(18,11,6,.86);overflow-y:auto;overscroll-behavior:contain;padding:0 0 50px;box-sizing:border-box;animation:tvpfIn .15s ease-out}'
    + '.tvpf{width:60vw;margin:0 auto;display:flex;flex-direction:column;background:transparent;box-shadow:0 24px 60px -18px rgba(0,0,0,.8)}'
    + '.tvpf-body{background:transparent}.tvpf-body.go{background:#FFFBF2}.tvpf-body iframe{background:#fff}'
    + '.tvpf-body>img,.tvpf-body>canvas{display:block;width:100%;height:auto;background:#fff;outline:2px dashed #DC2626;outline-offset:-1px}.tvpf-body canvas+canvas{margin-top:24px}'
    + '.tvpf-wait{padding:3rem 1rem;text-align:center;color:#F3DDB0;font:600 .9rem system-ui,sans-serif}'
    + '.tvpf-go{display:flex;flex-wrap:wrap;gap:1rem 1.5rem;align-items:flex-start;justify-content:center;padding:1.5rem}'
    + '.tvpf-go>img{width:min(22rem,100%);height:auto;flex:none}.tvpf-go>.i{flex:1 1 16rem;min-width:0;color:#3E2B1F}'
    + '.tvpf-go .gc-v b{display:block;font:700 1.25rem var(--tv-font-head,Georgia,serif)}.tvpf-go .gc-v span{color:#6B5640}.tvpf-go h3{margin:0 0 .5rem;font:700 .8rem system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;color:#8A7355}'
    + '.tvpf-go .gc-dl{margin:.6rem 0 0;display:grid;grid-template-columns:auto 1fr;gap:.35rem .8rem}.tvpf-go dt{font:600 .78rem system-ui,sans-serif;color:#8A7355;padding-top:.15rem}.tvpf-go dd{margin:0;word-break:break-word}'
    + '.tvpf-foot{position:sticky;top:0;z-index:3;display:flex;flex-wrap:wrap;gap:.5rem .6rem;align-items:center;padding:.6rem .8rem .6rem 1.1rem;margin-bottom:30px;background:#3E2B1F;color:#FFF8EA;box-shadow:0 6px 18px -8px rgba(0,0,0,.6)}'
    + '.tvpf-x{flex:none;width:36px;height:36px;border-radius:999px;border:1px solid rgba(255,248,234,.45);background:transparent;color:#FFF8EA;font-size:1.4rem;line-height:1;cursor:pointer}.tvpf-x:hover{background:rgba(255,248,234,.12)}'
    + '.tvpf-foot .t{flex:1 1 12rem;min-width:0;font:600 1rem system-ui,sans-serif;color:#FFF8EA;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.25}.tvpf-foot .t b{color:#F3D9A4;letter-spacing:.06em;margin-right:.35rem}.tvpf-foot .t .cut{display:block;font-weight:500;font-size:.78rem;color:#FCA5A5}'
    + '.tvpf-foot form{margin:0}.tvpf-foot details{flex:none}.tvpf-foot details[open]{flex:1 1 100%;order:9}.tvpf-foot details[open]>summary{display:none!important}'
    + '.tvpf-foot textarea{width:100%;box-sizing:border-box;min-height:4.5rem;color:#3E2B1F}.tvpf-foot .go-f label{display:block;font-weight:600;font-size:.92rem;color:#FFF8EA}.tvpf-foot details[open]{max-width:40rem;margin-left:auto}'
    + '@media (max-width:1100px){.tvpf{width:80vw}}@media (max-width:767px){.tvpf-lb{padding:0 0 12px}.tvpf{width:calc(100% - 24px)}.tvpf-foot{margin-bottom:12px}.tvpf-foot .t{flex-basis:calc(100% - 50px);order:1}.tvpf-x{order:2}.tvpf-foot>form,.tvpf-foot>details{order:3}.tvpf-foot>details[open]{order:9}}'
    + '.tvpf-view{display:inline-flex;flex:none;gap:2px;padding:2px;border-radius:.55rem;background:rgba(255,248,234,.1)}.tvpf-view button{border:0;background:transparent;color:#FFF8EA;font:600 .8rem system-ui,sans-serif;padding:.32rem .55rem;border-radius:.45rem;cursor:pointer;min-width:2rem}'
    + '.tvpf-view button[aria-pressed=true]{background:#8FBCA8;color:#1F3A2E;box-shadow:0 0 0 2px rgba(143,188,168,.35)}.tvpf-view button:hover{background:rgba(255,248,234,.18)}'
    + '.tvpf.m-page{width:auto;max-width:96vw}.tvpf.m-page .tvpf-body>canvas,.tvpf.m-page .tvpf-body>img{width:auto;max-width:96vw;max-height:calc(100vh - var(--tvpf-bar,64px) - 46px);margin-left:auto;margin-right:auto}'
    + '.tvpf.m-c2,.tvpf.m-c3,.tvpf.m-c4{width:96vw}.tvpf.m-c2 .tvpf-body,.tvpf.m-c3 .tvpf-body,.tvpf.m-c4 .tvpf-body{display:grid;gap:20px;align-items:start}'
    + '.tvpf.m-c2 .tvpf-body{grid-template-columns:repeat(2,minmax(0,1fr))}.tvpf.m-c3 .tvpf-body{grid-template-columns:repeat(3,minmax(0,1fr))}.tvpf.m-c4 .tvpf-body{grid-template-columns:repeat(4,minmax(0,1fr))}'
    + '.tvpf.m-c2 .tvpf-body canvas+canvas,.tvpf.m-c3 .tvpf-body canvas+canvas,.tvpf.m-c4 .tvpf-body canvas+canvas{margin-top:0}.tvpf.m-c2 .tvpf-wait,.tvpf.m-c3 .tvpf-wait,.tvpf.m-c4 .tvpf-wait{grid-column:1/-1}'
    + '@media (max-width:767px){.tvpf-view [data-m=c3],.tvpf-view [data-m=c4]{display:none}.tvpf.m-c2,.tvpf.m-c3,.tvpf.m-c4{width:calc(100% - 12px)}.tvpf.m-c3 .tvpf-body,.tvpf.m-c4 .tvpf-body{grid-template-columns:repeat(2,minmax(0,1fr))}.tvpf-view{order:4}}'
    + '@keyframes tvpfIn{from{opacity:0}to{opacity:1}}';
  var st = document.createElement('style'); st.textContent = css; (document.head || document.documentElement).appendChild(st);

  function el(t, c, x) { var n = document.createElement(t); if (c) n.className = c; if (x != null) n.textContent = x; return n; }
  function fill(box, sel) {
    var t = sel && document.querySelector(sel);
    if (t) box.appendChild(t.content ? t.content.cloneNode(true) : t.cloneNode(true));
  }
  var pdfLib = null;
  function loadPdf() {
    if (pdfLib) return pdfLib;
    pdfLib = new Promise(function (ok, no) {
      if (window.pdfjsLib) return ok(window.pdfjsLib);
      var s = document.createElement('script'); s.src = PDFJS + 'pdf.min.js';
      s.onload = function () { window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS + 'pdf.worker.min.js'; ok(window.pdfjsLib); };
      s.onerror = function () { pdfLib = null; no(new Error('pdf')); };
      document.head.appendChild(s);
    });
    return pdfLib;
  }
  // each page at the width it's shown × the screen's density (×2 at least), so text and lines stay crisp
  function drawPdf(body, src) {
    var wait = el('div', 'tvpf-wait', 'Opening the proof…'); body.appendChild(wait);
    loadPdf().then(function (lib) { return lib.getDocument({ url: src, withCredentials: true, isEvalSupported: false }).promise; }).then(function (doc) {
      wait.remove();
      var w = body.clientWidth || 800, k = Math.max(2, window.devicePixelRatio || 1), chain = Promise.resolve();
      for (var i = 1; i <= doc.numPages; i++) (function (n) {
        chain = chain.then(function () { return doc.getPage(n); }).then(function (pg) {
          var v1 = pg.getViewport({ scale: 1 }), sc = Math.min(8, w * k / v1.width), vp = pg.getViewport({ scale: sc });
          var c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height);
          c.setAttribute('aria-label', 'Proof, page ' + n); body.appendChild(c);
          return pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
        });
      })(i);
    }).catch(function () {
      wait.textContent = '';
      var o = document.createElement('iframe'); o.src = src; o.title = 'Proof'; o.style.cssText = 'display:block;width:100%;height:80vh;border:0';
      body.appendChild(o);
    });
  }

  var openBox = null;
  function close() {
    if (!openBox) return;
    openBox.lb.remove(); document.removeEventListener('keydown', openBox.key, true); if (openBox.bar) window.removeEventListener('resize', openBox.bar);
    document.documentElement.style.overflow = openBox.ov; openBox = null;
  }
  function open(o) {
    close();
    var lb = el('div', 'tvpf-lb'), box = el('div', 'tvpf'), body = el('div', 'tvpf-body'), foot = el('div', 'tvpf-foot'), x = el('button', 'tvpf-x', '×');
    box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', o.title || 'Proof');
    x.type = 'button'; x.setAttribute('aria-label', 'Close');
    if (o.kind === 'pdf') drawPdf(body, o.src);
    else if (o.kind === 'go') {
      var g = el('div', 'tvpf-go'), im = el('img'), i = el('div', 'i');
      im.src = o.src; im.alt = 'The GO Code'; g.appendChild(im); fill(i, o.info); g.appendChild(i); body.appendChild(g);
      body.classList.add('go');
    } else { var img = el('img'); img.src = o.src; img.alt = o.title || 'Proof'; img.decoding = 'async'; body.appendChild(img); }
    var set = null;
    var t = el('span', 't'); t.appendChild(el('b', '', 'PROOF:')); t.appendChild(document.createTextNode(o.title || ''));
    if (o.kind !== 'go') { var c = el('small', 'cut', 'Red dashed line: where it\'s cut'); t.appendChild(c); }   // the proof is shown to its edges, square, as it's trimmed
    foot.appendChild(t);
    if (o.kind !== 'go') {   // how it's shown: Width, Page, or 2–4 across
      var view = el('span', 'tvpf-view'), modes = [['width', 'Width', 'Fill the width'], ['page', 'Page', 'Each page whole, top to bottom'], ['c2', '2', '2 pages across'], ['c3', '3', '3 pages across'], ['c4', '4', '4 pages across']];
      set = function (m) {
        box.classList.remove('m-page', 'm-c2', 'm-c3', 'm-c4'); if (m !== 'width') box.classList.add('m-' + m);
        view.querySelectorAll('button').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-m') === m ? 'true' : 'false'); });
        try { localStorage.setItem('tvpf-mode', m); } catch (e) {}
        lb.scrollTop = 0;
      };
      view.setAttribute('role', 'group'); view.setAttribute('aria-label', 'How the proof is shown');
      modes.forEach(function (m) { var b = el('button', '', m[1]); b.type = 'button'; b.title = m[2]; b.setAttribute('data-m', m[0]); b.addEventListener('click', function () { set(m[0]); }); view.appendChild(b); });
      foot.appendChild(view);
    }
    fill(foot, o.acts); foot.appendChild(x);   // the bar across the top: PROOF: title · Approve · Make changes · ×
    box.appendChild(body); lb.appendChild(foot); lb.appendChild(box);
    lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
    x.addEventListener('click', close);
    var key = function (e) { if (e.key === 'Escape' && !document.querySelector('.tv-ask-lb')) { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', key, true);
    document.body.appendChild(lb);
    var bar = function () { box.style.setProperty('--tvpf-bar', foot.offsetHeight + 'px'); };
    openBox = { lb: lb, key: key, ov: document.documentElement.style.overflow, bar: bar };
    document.documentElement.style.overflow = 'hidden';   // the page behind stays put; only the proof scrolls
    if (set) { var m0 = 'width'; try { m0 = localStorage.getItem('tvpf-mode') || 'width'; } catch (e) {} set(['width', 'page', 'c2', 'c3', 'c4'].indexOf(m0) >= 0 ? m0 : 'width'); }
    bar(); window.addEventListener('resize', bar);
    setTimeout(function () { try { x.focus({ preventScroll: true }); } catch (e) {} }, 0);
  }

  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('[data-proof]');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button > 0) return;
    e.preventDefault();
    open({ kind: a.getAttribute('data-proof') || 'image', src: a.getAttribute('data-proof-src') || a.getAttribute('href'), title: a.getAttribute('data-proof-title') || '',
           info: a.getAttribute('data-proof-info'), acts: a.getAttribute('data-proof-acts') });
  });
  window.TvProof = { open: open, close: close };
})();
