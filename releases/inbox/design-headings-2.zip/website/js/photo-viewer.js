/* photo-viewer.js: one photo viewer for the site (draft 2026-10-09, from Jason's reference): the photo on the left with
   zoom, fullscreen and arrows; a side panel with where it's from, who posted it and when, a ⋯ menu, likes, comments,
   Share and a "Comment as" box. Likes, comments, Share and tags show the layout only; they're coming.

   TvPhotos.open(items, index, opts)
     items: [{full, caption, from: {text, link, url}, who: {name, avatar}, when, public, photo: 'avatar'|'cover'|''}]
     opts:  {owner: bool (your own photos: make profile/cover photo), me: {name, avatar} (signed in) or null,
             api: '/user/api/member-profile.php', csrf}
   Touch (phones): the photos are a strip: swipe side to side and the next one slides in. Swipe up to scroll from the photo into its
   likes, caption and comments, which sit right under it. Pulling the photo down shows a × at the foot of the screen: drop it there to close
   (anywhere else and it springs back), or tap × at the top.
   Pages can also mark photos with data-tv-photos="<group>" data-i="<n>" and call TvPhotos.bind(group, items, opts).
   The gallery (decisions/0126, 2026-10-24): items may be videos ({video, full = its poster}) and carry alt text ({alt}) and a small
   copy ({thumb}); opts.thumbs shows a row of them under the photo on wide screens. Everywhere: tapping the dark background closes,
   the arrows stop (greyed) at the first and last photo instead of going round, "3 of 24" shows on every screen, and two fingers
   pinch to zoom.
   opts.social = {load(it), like(it), comment(it, body), uncomment(id)} (each a Promise; the gallery's, decisions/0126 phase 2) makes likes and
   comments real for items with an id: pinned to that photo, double-tap to like on phones, remove your own (or any on your photo), report.
   opts.edit = {save(it, fields), del(it)} with it.mine (phase 3): the ⋯ menu edits the caption, the alt text and when it was taken, and
   deletes it; opts.onChange(it, gone) tells the page. it.download (when allowed) is the original's address for "Save to phone". */
(function () {
  if (window.TvPhotos) return;
  var css = ''
    + '.pv{position:fixed;inset:0;z-index:300;display:flex;background:rgba(20,13,8,.84);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px);color:#3E2B1F}'   /* the page you came from shows faintly behind */
    + '.pv-stage{flex:1;min-width:0;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden;touch-action:pan-y}'
    + '.pv-track{position:absolute;inset:0;will-change:transform}'
    + '.pv-pane{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}.pv-pane.prev{transform:translateX(calc(-100% - 16px))}.pv-pane.next{transform:translateX(calc(100% + 16px))}'
    + '.pv-pane img{max-width:100%;max-height:100%;object-fit:contain;transform-origin:center;user-select:none;-webkit-user-drag:none}.pv-cur{cursor:zoom-in}'
    + '.pv-stage.z .pv-cur{cursor:grab}'
    + '.pv-b{position:absolute;width:2.6rem;height:2.6rem;border-radius:50%;border:0;background:rgba(255,251,242,.14);color:#FFFBF2;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:2}'
    + '.pv-b:hover{background:rgba(255,251,242,.28)}.pv-b svg{width:1.25rem;height:1.25rem}'
    + '.pv-x{top:.8rem;left:.8rem;font-size:1.6rem;line-height:1}'
    + '.pv-tools{position:absolute;top:.8rem;right:.8rem;display:flex;gap:.45rem;z-index:2}.pv-tools .pv-b{position:static}'
    + '.pv-p,.pv-n{top:50%;transform:translateY(-50%);width:3rem;height:3rem;font-size:2rem}.pv-p{left:.8rem}.pv-n{right:.8rem}'
    + '.pv-side{width:23rem;flex:none;background:#F7EFDC;display:flex;flex-direction:column;min-height:0}'
    + '.pv-from{display:flex;align-items:center;gap:.5rem;padding:.7rem .9rem;border-bottom:1px solid #E3D3AC;font-size:.82rem;color:#5C4632}'
    + '.pv-from svg{width:1rem;height:1rem;flex:none;color:#8A7355}.pv-from a{margin-left:auto;font-weight:700;color:#92400E;text-decoration:none;white-space:nowrap}.pv-from a:hover{text-decoration:underline}'
    + '.pv-who{display:flex;align-items:center;gap:.6rem;padding:.8rem .9rem .4rem;position:relative}'
    + '.pv-av{width:2.6rem;height:2.6rem;border-radius:50%;background:#CBB98D center/cover no-repeat;flex:none;display:flex;align-items:center;justify-content:center;font:700 1rem var(--tv-font-head,Georgia,serif);color:#92400E;border:2px solid #FFFBF2}'
    + '.pv-who b{display:block;font:700 1rem var(--tv-font-head,Georgia,serif);color:#92400E}.pv-who small{display:flex;align-items:center;gap:.3rem;font-size:.75rem;color:#8A7355}.pv-who small svg{width:.85rem;height:.85rem}'
    + '.pv-more{margin-left:auto;width:2.2rem;height:2.2rem;border-radius:50%;border:0;background:none;color:#5C4632;cursor:pointer;font-size:1.3rem;line-height:1}.pv-more:hover,.pv-more[aria-expanded="true"]{background:#E3D3AC}'
    + '.pv-menu{position:absolute;right:.6rem;top:3.4rem;z-index:5;width:17rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.7rem;box-shadow:0 16px 36px -12px rgba(0,0,0,.45);padding:.35rem}'
    + '.pv-menu[hidden]{display:none}.pv-menu hr{border:0;border-top:1px solid #E3D3AC;margin:.3rem .2rem}'
    + '.pv-menu button,.pv-menu a{display:flex;align-items:center;gap:.7rem;width:100%;text-align:left;border:0;background:none;padding:.5rem .55rem;border-radius:.5rem;font:inherit;font-size:.9rem;color:#3E2B1F;cursor:pointer;text-decoration:none}'
    + '.pv-menu button:hover,.pv-menu a:hover{background:#F3E7CD}.pv-menu svg{width:1.15rem;height:1.15rem;color:#B45309;flex:none}.pv-menu small{display:block;font-size:.72rem;color:#8A7355}'
    + '.pv-cap{padding:.1rem .9rem .5rem;font-size:.92rem;white-space:pre-line}'
    + '.pv-bar{display:flex;align-items:center;gap:.3rem;padding:.4rem .9rem .6rem;border-bottom:1px solid #E3D3AC}'
    + '.pv-bar button{display:inline-flex;align-items:center;gap:.3rem;border:0;background:none;color:#5C4632;cursor:pointer;padding:.3rem .45rem;border-radius:.5rem;font:inherit;font-size:.85rem}'
    + '.pv-bar button:hover{background:#EFE3C8}.pv-bar svg{width:1.35rem;height:1.35rem;color:#B45309}.pv-bar [aria-pressed="true"] svg{fill:#B45309}'
    + '.pv-bar .views{margin-left:auto;display:inline-flex;align-items:center;gap:.3rem;font-size:.8rem;color:#8A7355}.pv-bar .views svg{width:1.05rem;height:1.05rem;color:#8A7355}'
    + '.pv-cms{flex:1;min-height:6rem;overflow:auto;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:1rem;color:#8A7355}'
    + '.pv-cms b{font:700 1.15rem var(--tv-font-head,Georgia,serif);color:#5C4632}.pv-cms svg{width:2.6rem;height:2.6rem;color:#CBB98D;margin-bottom:.4rem}'
    + '.pv-say{display:flex;gap:.55rem;padding:.7rem .9rem .9rem;border-top:1px solid #E3D3AC}'
    + '.pv-say .pv-av{width:2.2rem;height:2.2rem;font-size:.85rem}'
    + '.pv-box{flex:1;min-width:0;background:#FFFBF2;border:1px solid #CBB98D;border-radius:1rem;padding:.45rem .7rem .3rem}'
    + '.pv-box textarea{width:100%;border:0;background:none;resize:none;font:inherit;font-size:.9rem;outline:none;min-height:1.6rem}'
    + '.pv-box div{display:flex;align-items:center;gap:.15rem}.pv-box div .sp{flex:1}'
    + '.pv-box button{border:0;background:none;color:#8A7355;cursor:pointer;padding:.2rem;border-radius:.4rem;display:inline-flex}.pv-box button:hover{color:#B45309}.pv-box svg{width:1.15rem;height:1.15rem}'
    + '.pv-in{font-size:.85rem;padding:.7rem .9rem;border-top:1px solid #E3D3AC;color:#5C4632}.pv-in a{color:#92400E;font-weight:700}'
    + '.pv-msg{font-size:.78rem;color:#92400E;padding:0 .9rem .5rem;min-height:0}.pv-msg:empty{display:none}'
    + '.pv-ph,.pv-drop{display:none}'
    + '.pv-count{position:absolute;top:1.15rem;left:50%;transform:translateX(-50%);z-index:2;color:#FFFBF2;font-weight:700;font-size:.95rem;text-shadow:0 1px 3px rgba(0,0,0,.8);white-space:nowrap}'
    + '.pv-b[disabled]{opacity:.28;cursor:default;pointer-events:none}'
    + '.pv-pane video{width:100%;height:100%;object-fit:contain;background:transparent}'
    + '.pv-thumbs{position:absolute;left:0;right:0;bottom:.6rem;display:flex;gap:.35rem;justify-content:center;overflow-x:auto;padding:.2rem 3.5rem;z-index:2;scrollbar-width:none}.pv-thumbs::-webkit-scrollbar{display:none}'
    + '.pv-thumbs button{flex:none;width:3.4rem;height:3.4rem;border:2px solid transparent;border-radius:.4rem;padding:0;background:#3E2B1F center/cover no-repeat;opacity:.6;cursor:pointer}'
    + '.pv-thumbs button[aria-current="true"]{opacity:1;border-color:#FFFBF2}.pv-thumbs button:hover{opacity:.95}.pv-thumbs i{display:block;font-style:normal;color:#fff;font-size:.8rem;text-align:right;padding:.1rem .25rem;text-shadow:0 1px 2px #000}'
    + '.pv.thumbed .pv-pane{bottom:4.8rem}'
    + '.pv~.tv-ask-lb{z-index:400}.pv~.tv-ask-toast{z-index:410}'   /* the site's own prompts over the viewer */
    + '.pv-cl{order:6;list-style:none;margin:0;padding:.4rem .9rem;flex:1;min-height:6rem;overflow:auto;text-align:left}.pv-cl li{display:flex;gap:.55rem;padding:.45rem 0;border-bottom:1px solid #EFE3C8}'
    + '.pv-cl .pv-av{width:2rem;height:2rem;font-size:.8rem}.pv-cl b{font-size:.85rem;color:#3E2B1F}.pv-cl p{margin:.1rem 0 0;font-size:.9rem;white-space:pre-line;word-break:break-word}'
    + '.pv-cl small{display:flex;gap:.6rem;font-size:.72rem;color:#8A7355;margin-top:.15rem}.pv-cl small button{border:0;background:none;padding:0;color:#92400E;cursor:pointer;font:inherit;text-decoration:underline}'
    + '.pv-heart{position:absolute;left:50%;top:50%;width:6rem;height:6rem;margin:-3rem 0 0 -3rem;color:#fff;opacity:0;pointer-events:none;z-index:4;filter:drop-shadow(0 2px 8px rgba(0,0,0,.5));transition:opacity .2s,transform .35s}'
    + '.pv-heart.on{opacity:.95;transform:scale(1.15)}.pv-heart svg{width:100%;height:100%;fill:#fff}'
    /* phones (Jason's phone references, 2026-10-09): one scrolling page. The photo fills the first screen with who posted it and the
       likes, comments and Share bar just under it; scrolling up brings the caption and comments; ×, "6 of 7", tag, place and ⋮ stay on top */
    + '@media (max-width:820px){.pv{display:block;overflow-y:auto;overscroll-behavior:contain;background:rgba(20,13,8,.92);-webkit-backdrop-filter:none;backdrop-filter:none;-webkit-overflow-scrolling:touch}'   /* no blur here: it would unpin the top bar */
    + '.pv::before{content:"";position:fixed;top:0;left:0;right:0;height:4.6rem;background:linear-gradient(rgba(10,6,4,.7),transparent);z-index:2;pointer-events:none}'
    + '.pv-stage{height:calc(100vh - 7.6rem);height:calc(100svh - 7.6rem);touch-action:pan-y}'
    + '.pv-tools [data-pv="zin"],.pv-tools [data-pv="zout"],.pv-tools [data-pv="full"],.pv-p,.pv-n,.pv-who .pv-more{display:none!important}'
    + '.pv-x,.pv-tools,.pv-count{position:fixed;z-index:3}'
    + '.pv-b{background:none}.pv-b svg{width:1.6rem;height:1.6rem;filter:drop-shadow(0 1px 2px rgba(0,0,0,.7))}.pv-x{font-size:2.2rem;text-shadow:0 1px 3px rgba(0,0,0,.7)}'
    + '.pv-ph{display:flex}.pv-tools{gap:.1rem;right:.3rem}'
    + '.pv-count{display:block;top:1.25rem;left:50%;transform:translateX(-50%);color:#fff;font-weight:700;font-size:1.05rem;text-shadow:0 1px 3px rgba(0,0,0,.8);white-space:nowrap}.pv-thumbs{display:none}.pv.thumbed .pv-pane{bottom:0}'
    + '.pv-side{width:auto;min-height:calc(100vh - 4.6rem);min-height:calc(100svh - 4.6rem);border-radius:1rem 1rem 0 0;box-shadow:0 -8px 24px rgba(0,0,0,.35)}'
    + '.pv-who{order:1;padding-top:.9rem}.pv-bar{order:2}.pv-msg{order:3;padding-top:.4rem}.pv-cap{order:4;padding-top:.6rem}.pv-from{order:5}.pv-cms{order:6;flex:none;min-height:9rem}.pv-say,.pv-in{order:7}'
    + '.pv.pull .pv-pane.prev,.pv.pull .pv-pane.next{visibility:hidden}.pv-side{transition:opacity .15s}.pv.pull .pv-side{opacity:0}.pv.pull .pv-stage{overflow:visible;z-index:5}.pv.pull::before{opacity:0}'
    + '.pv-drop{position:fixed;left:50%;bottom:2.2rem;transform:translateX(-50%) scale(.85);z-index:6;display:flex!important;flex-direction:column;align-items:center;gap:.4rem;opacity:0;pointer-events:none;transition:opacity .15s,transform .15s;color:#fff;font-size:.8rem;font-weight:600;text-shadow:0 1px 3px rgba(0,0,0,.8)}'
    + '.pv-drop i{width:4rem;height:4rem;border-radius:50%;border:2px solid rgba(255,255,255,.85);background:rgba(20,13,8,.55);display:flex;align-items:center;justify-content:center;font:400 2.3rem/1 system-ui;font-style:normal}'
    + '.pv.pull .pv-drop{opacity:1;transform:translateX(-50%) scale(1)}.pv-drop.on{transform:translateX(-50%) scale(1.15)!important}.pv-drop.on i{background:#B45309;border-color:#B45309}'
    + '.pv.menu::after{content:"";position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:4}'
    + '.pv-menu{position:fixed;left:0;right:0;bottom:0;top:auto;width:auto;z-index:5;border-radius:1rem 1rem 0 0;border:0;padding:.6rem 0 1rem;max-height:75vh;overflow:auto}'
    + '.pv-menu,.pv-menu button,.pv-menu a{color:#3E2B1F}.pv-menu small{color:#8A7355!important}.pv-menu button,.pv-menu a{padding:1rem 1.4rem;font-size:1.08rem;gap:1.2rem;border-radius:0}.pv-menu svg{width:1.6rem;height:1.6rem;color:#5C4632}.pv-menu hr{display:none}}';
  var S = function (d, w) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 2) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>'; };
  var I = {
    zin: S('<circle cx="11" cy="11" r="7"/><path d="m21 21-5-5M11 8v6M8 11h6"/>'), zout: S('<circle cx="11" cy="11" r="7"/><path d="m21 21-5-5M8 11h6"/>'),
    tag: S('<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/>'),
    full: S('<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>'), post: S('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/>'),
    pub: S('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>'), lock: S('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'),
    like: S('<path d="M7 10v11H3V10zM7 10l4-8a3 3 0 0 1 3 3v4h6a2 2 0 0 1 2 2.3l-1.4 8A2 2 0 0 1 18.6 21H7"/>'),
    cm: S('<path d="M21 12a8.5 8.5 0 0 1-12.6 7.4L3 21l1.6-5.4A8.5 8.5 0 1 1 21 12z"/>'), share: S('<path d="M14 5l7 6-7 6V13c-6 0-9 2-11 6 0-6 3-11 11-11z"/>'),
    eye: S('<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>'),
    doc: S('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>', 1.5),
    save: S('<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>'), bell: S('<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0M3 3l18 18"/>'),
    dl: S('<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>'), me: S('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.5 18.5a6 6 0 0 1 11 0"/>'),
    img: S('<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.5"/><path d="m21 16-5-5-9 8"/>'), pen: S('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>'),
    flag: S('<path d="M4 22V4M4 4h13l-2 4 2 4H4"/>'), cam: S('<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>'),
    pin: S('<path d="M12 2.5a7 7 0 0 0-7 7c0 5.2 7 12 7 12s7-6.8 7-12a7 7 0 0 0-7-7z"/><circle cx="12" cy="9.5" r="2.5"/>'),
    dots: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5" r="2.2"/><circle cx="12" cy="12" r="2.2"/><circle cx="12" cy="19" r="2.2"/></svg>',
    trash: S('<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>'), alt: S('<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m8 17 4-10 4 10M9.5 13.5h5"/>'),
    smile: S('<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/>'), send: S('<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>')
  };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function av(p) { return p && p.avatar ? '<span class="pv-av" style="background-image:url(\'' + esc(p.avatar) + '\')"></span>' : '<span class="pv-av">' + esc(((p && p.name) || '?').charAt(0).toUpperCase()) + '</span>'; }
  function date(w) { if (!w) return ''; var d = new Date(String(w).replace(' ', 'T')); return isNaN(d) ? '' : d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' }); }
  var box = null, L = [], at = 0, O = {}, back = null, zoom = 1, pan = { x: 0, y: 0 };

  function view() { var img = box.querySelector('.pv-cur'); img.style.transform = 'translate(' + pan.x + 'px,' + pan.y + 'px) scale(' + zoom + ')'; box.querySelector('.pv-stage').classList.toggle('z', zoom > 1); }
  function setZoom(z) { zoom = Math.max(1, Math.min(4, z)); if (zoom === 1) pan = { x: 0, y: 0 }; view(); }
  function say(t) { box.querySelector('.pv-msg').textContent = t || ''; }
  function menu(it) {
    var h = '';
    if (O.edit && it.mine) {   // the gallery (decisions/0126 phase 3): your own photo
      h += '<button type="button" data-pv="e-caption">' + I.pen + '<span>Edit caption</span></button>'
        + '<button type="button" data-pv="e-alt">' + I.alt + '<span>Edit alt text<small>Describes the photo for people who use screen readers</small></span></button>'
        + '<button type="button" data-pv="e-taken">' + I.post + '<span>When it was taken<small>' + esc(date(it.when) || 'Not set') + '</small></span></button>'
        + (it.deletable ? '<button type="button" data-pv="e-del">' + I.trash + '<span>Delete</span></button>' : '');
    } else if (O.owner) {
      if (it.photo !== 'cover') h += '<button type="button" data-pv="as-cover">' + I.img + '<span>Make cover photo</span></button>';
      if (it.photo !== 'avatar') h += '<button type="button" data-pv="as-avatar">' + I.me + '<span>Make profile picture</span></button>';
      if (it.photo) h += '<button type="button" data-pv="edit">' + I.pen + '<span>Change, reposition or remove</span></button>';
      else h += '<button type="button" data-pv="caption">' + I.pen + '<span>Edit caption</span></button><button type="button" data-pv="delete">' + I.trash + '<span>Delete photo</span></button>';
    } else h += '<button type="button" data-pv="save">' + I.save + '<span>Save photo<small>Add it to your saved items</small></span></button>';
    if (it.download !== false) h += '<a href="' + esc(it.download || it.full) + '" download>' + I.dl + '<span>Save to ' + (phone() ? 'phone' : 'computer') + (it.dlNote ? '<small>' + esc(it.dlNote) + '</small>' : '') + '</span></a>';
    h += '<button type="button" data-pv="share-out">' + I.share + '<span>Share outside Traversence</span></button>';
    if (O.owner) h += '<button type="button" data-pv="privacy">' + I.lock + '<span>Who sees it<small>' + esc(it.audience || (it.public === false ? 'Only you' : 'Public')) + '</small></span></button>'
      + '<button type="button" data-pv="alt">' + I.alt + '<span>Edit alt text<small>Describes the photo for people who use screen readers</small></span></button>';
    else if (O.me) h += '<button type="button" data-pv="mute">' + I.bell + '<span>Turn off notifications for this photo</span></button><button type="button" data-pv="report">' + I.flag + '<span>Report photo</span></button>';
    if (!phone()) h += '<button type="button" data-pv="full">' + I.full + '<span>Enter fullscreen</span></button>';
    return h;
  }
  function show() {
    var it = L[at], img = box.querySelector('.pv-cur');
    zoom = 1; pan = { x: 0, y: 0 }; img.src = it.full; img.alt = it.alt || it.caption || 'Photo'; view();
    var cur = img.parentNode, old = cur.querySelector('video'); if (old) old.remove();
    img.hidden = !!it.video;
    if (it.video) { var v = document.createElement('video'); v.controls = true; v.playsInline = true; v.preload = 'metadata'; v.poster = it.full; v.src = it.video; v.setAttribute('aria-label', it.alt || it.caption || 'Video'); cur.appendChild(v); }
    var nb = function (k) { return L[at + k]; };   // the neighbours wait just off screen, so a swipe slides them in (none past the ends)
    box.querySelector('.pv-pane.prev img').src = nb(-1) ? nb(-1).full : '';
    box.querySelector('.pv-pane.next img').src = nb(1) ? nb(1).full : '';
    var f = it.from || null, side = box.querySelector('.pv-side');
    side.innerHTML = (f ? '<div class="pv-from">' + I.post + '<span>' + esc(f.text) + '</span>' + (f.url ? '<a href="' + esc(f.url) + '" data-pv-go>' + esc(f.link) + '</a>' : '') + '</div>' : '')
      + '<div class="pv-who">' + av(it.who) + '<span style="min-width:0"><b>' + esc(it.who && it.who.name) + '</b><small>' + esc(date(it.when))
      + (it.when ? ' · ' : '') + (it.audience ? (it.audience === 'Public' ? I.pub : I.lock) + ' ' + esc(it.audience) : (it.public === false ? I.lock + ' Only you' : I.pub + ' Public')) + '</small></span>'
      + '<button type="button" class="pv-more" aria-haspopup="menu" aria-expanded="false" aria-label="More" title="More">&middot;&middot;&middot;</button>'
      + '<div class="pv-menu" role="menu" hidden>' + menu(it) + '</div></div>'
      + (it.caption ? '<p class="pv-cap">' + esc(it.caption) + '</p>' : '')
      + '<div class="pv-bar"><button type="button" data-pv="like" aria-pressed="false" title="Like">' + I.like + '<span>0</span></button>'
      + '<button type="button" data-pv="comment" title="Comment">' + I.cm + '</button><button type="button" data-pv="share" title="Share">' + I.share + '</button>'
      + '<span class="views" title="Views">' + I.eye + '0</span></div>'
      + '<p class="pv-msg" role="status"></p>'
      + '<div class="pv-cms">' + I.doc + '<b>No comments yet</b><span>Be the first to comment.</span></div>'
      + (O.me ? '<div class="pv-say">' + av(O.me) + '<div class="pv-box"><textarea rows="1" placeholder="Comment as ' + esc(O.me.name) + '" aria-label="Comment"></textarea>'
          + '<div><button type="button" data-pv="emoji" title="Emoji" aria-label="Emoji">' + I.smile + '</button><button type="button" data-pv="cphoto" title="Add a photo" aria-label="Add a photo">' + I.cam + '</button><span class="sp"></span>'
          + '<button type="button" data-pv="send" title="Post" aria-label="Post">' + I.send + '</button></div></div></div>'
        : '<p class="pv-in"><a href="/login.php?next=' + encodeURIComponent(location.pathname + location.search) + '">Sign in</a> to like or comment.</p>');
    box.querySelectorAll('.pv-p,.pv-n').forEach(function (b) { b.hidden = L.length < 2; });
    box.querySelector('.pv-p').disabled = at === 0; box.querySelector('.pv-n').disabled = at === L.length - 1;   // greyed at the ends
    box.querySelector('.pv-count').textContent = L.length > 1 ? (at + 1) + ' of ' + L.length : '';
    var th = box.querySelector('.pv-thumbs');
    if (th) th.querySelectorAll('button').forEach(function (b, k) { b.setAttribute('aria-current', String(k === at)); if (k === at && b.scrollIntoView) b.scrollIntoView({ block: 'nearest', inline: 'center' }); });
    box.querySelector('.pv-bar [data-pv="comment"]').insertAdjacentHTML('beforeend', '<span>0</span>');
    if (O.social && it.id) social(it);
  }
  function ago(w) { var d = new Date(String(w).replace(' ', 'T')), s = (Date.now() - d) / 1000; if (isNaN(s)) return ''; if (s < 60) return 'now'; if (s < 3600) return Math.floor(s / 60) + 'm'; if (s < 86400) return Math.floor(s / 3600) + 'h'; if (s < 604800) return Math.floor(s / 86400) + 'd'; return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }); }
  function paint(d) {   // the like count, whether you liked it, and the comments, pinned to this photo
    if (!box) return;
    var lb = box.querySelector('.pv-bar [data-pv="like"]'), cb = box.querySelector('.pv-bar [data-pv="comment"] span');
    if (lb) { lb.setAttribute('aria-pressed', String(!!d.liked)); lb.querySelector('span').textContent = d.likes || 0; }
    if (cb) cb.textContent = (d.comments || []).length;
    var area = box.querySelector('.pv-cms, .pv-cl'); if (!area) return;
    var html = (d.comments || []).length ? '<ul class="pv-cl">' + d.comments.map(function (c) {
      return '<li data-c="' + c.id + '">' + av({ name: c.name }) + '<div style="min-width:0"><b>' + esc(c.name) + '</b><p>' + esc(c.body) + '</p><small><span>' + esc(ago(c.when)) + '</span>'
        + (c.mine ? '<button type="button" data-pv-rm="' + c.id + '">Remove</button>' : (O.me ? '<button type="button" data-pv-rep="' + c.id + '">Report</button>' : '')) + '</small></div></li>';
    }).join('') + '</ul>' : '<div class="pv-cms">' + I.doc + '<b>No comments yet</b><span>' + (O.me ? 'Be the first to comment.' : 'Sign in to comment.') + '</span></div>';
    var tmp = document.createElement('div'); tmp.innerHTML = html; area.replaceWith(tmp.firstChild);
  }
  function social(it) { var me = it; O.social.load(it).then(function (d) { if (box && L[at] === me) { me._s = d; paint(d); } }).catch(function () {}); }
  function heart() { var h = box.querySelector('.pv-heart'); if (!h) return; h.classList.add('on'); setTimeout(function () { h.classList.remove('on'); }, 600); }
  function likeIt(force) {
    var it = L[at];
    if (!O.me) return say('Sign in to like photos.');
    if (force && it._s && it._s.liked) return heart();   // a double-tap only ever likes
    O.social.like(it).then(function (d) { if (!it._s) it._s = { comments: [] }; it._s.liked = d.liked; it._s.likes = d.likes; if (L[at] === it) { paint(it._s); if (d.liked) heart(); } }).catch(function (x) { say(x.message); });
  }
  function send() {
    var it = L[at], t = box.querySelector('.pv-box textarea'); if (!t || !t.value.trim()) return;
    var body = t.value;
    O.social.comment(it, body).then(function (c) { t.value = ''; if (!it._s) it._s = { comments: [] }; it._s.comments = (it._s.comments || []).concat([c]); paint(it._s); say(''); })
      .catch(function (x) {
        if (/18 or older/.test(x.message)) {
          var m = box.querySelector('.pv-msg'); m.innerHTML = esc(x.message) + ' <button type="button" class="pv-age" style="border:0;background:none;color:#92400E;font-weight:700;text-decoration:underline;cursor:pointer">I&rsquo;m 18 or older</button>';
          m.querySelector('.pv-age').onclick = function () { fetch('/api/engage.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': O.csrf || '' }, body: JSON.stringify({ action: 'age' }) }).then(function () { say(''); send(); }); };
          return;
        }
        say(x.message);
      });
  }
  function phone() { return window.matchMedia('(max-width: 820px)').matches; }
  var SOON = { caption: 'Editing captions here is coming. For now, edit it where the photo lives.', delete: 'Deleting from here is coming. For now, remove it where it lives.',
    privacy: 'A photo is seen by whoever can see where it lives: the albums it\'s in (each album\'s Edit & who sees it), its journey, or the eye on your profile and cover photos. Choosing for one photo on its own is coming.', alt: 'Alt text is coming.', place: 'Where a photo was taken, on the map, is coming.', save: 'Saving photos is coming.', mute: 'Notification settings for photos are coming.', report: 'Reporting a photo is coming. For now, use Report on its page.',
    like: 'Likes on photos are coming.', comment: '', share: 'Sharing photos is coming.', emoji: 'Emoji are coming.', cphoto: 'Photos in comments are coming.',
    send: 'Comments on photos are coming.', tag: 'Tagging people in photos is coming.' };
  function use(kind) {
    var it = L[at];
    say('Saving…');
    fetch(O.api, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': O.csrf || '' }, body: JSON.stringify({ use_photo: it.full, as: kind }) })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) { say((d.error && d.error.message) || 'That didn\'t work. Try again.'); return; }
        say(kind === 'avatar' ? 'It\'s your profile picture now. Use its pencil to reposition or size it.' : 'It\'s your cover photo now.');
        setTimeout(function () { location.reload(); }, 900);
      }).catch(function () { say('That didn\'t work. Try again.'); });
  }
  function act(a, el) {
    var m = box.querySelector('.pv-menu');
    if (a === 'full') { m.hidden = true; var el2 = box; if (document.fullscreenElement) document.exitFullscreen(); else if (el2.requestFullscreen) el2.requestFullscreen(); return; }
    if (a === 'share-out') {
      m.hidden = true; box.classList.remove('menu');
      var url = new URL(L[at].full, location.href).href;
      if (window.tvShort) url = tvShort.now(url);   // trvgo.us (decisions/0094)
      if (navigator.share) navigator.share({ url: url, title: L[at].caption || 'A photo on Traversence' }).catch(function () {});
      else if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { say('Link copied.'); }, function () { say(url); });
      else say(url);
      return;
    }
    if (a === 'zin') return setZoom(zoom + 0.5);
    if (a === 'zout') return setZoom(zoom - 0.5);
    if (a === 'as-avatar' || a === 'as-cover') { m.hidden = true; return use(a === 'as-avatar' ? 'avatar' : 'cover'); }
    if (a === 'edit') { var ph = L[at].photo; close(); var b = document.querySelector('.pf2 [data-photo="' + ph + '"]'); if (b) b.click(); return; }
    if (a === 'comment') {
      if (phone()) { box.scrollTo({ top: box.querySelector('.pv-side').offsetTop - 70, behavior: 'smooth' }); return; }   // the comments are right under the photo
      var t = box.querySelector('.pv-box textarea'); if (t) t.focus(); return;
    }
    if (O.social && L[at].id && (a === 'like' || a === 'send')) { m.hidden = true; return a === 'like' ? likeIt(false) : send(); }
    if (O.edit && /^e-/.test(a)) {   // edit your own photo
      m.hidden = true; box.classList.remove('menu');
      var it = L[at], f = { 'e-caption': ['caption', 'Caption', it.caption], 'e-alt': ['alt', 'Alt text: what\'s in the photo, for people who can\'t see it', it.alt], 'e-taken': ['taken', 'When was it taken? (like 2026-07-04 or 2026-07-04 18:30)', (it.when || '').slice(0, 16)] }[a];
      if (a === 'e-del') {
        if (!window.TvAsk) return;
        return TvAsk.confirm('Delete this ' + (it.video ? 'video' : 'photo') + ' for good?', { yes: 'Delete', danger: true }).then(function (yes) {
          if (!yes) return;
          O.edit.del(it).then(function () { if (O.onChange) O.onChange(it, true); L.splice(at, 1); if (!L.length) return close(); if (at >= L.length) at = L.length - 1; show(); }).catch(function (x) { say(x.message); });
        });
      }
      return (window.TvAsk ? TvAsk.ask(f[1], f[2] || '', { multiline: a !== 'e-taken' }) : Promise.resolve(null)).then(function (v) {
        if (v === null || v === undefined) return;
        var body = {}; body[f[0]] = v;
        O.edit.save(it, body).then(function (n) { it.caption = n.caption; it.alt = n.alt; it.when = n.when; if (O.onChange) O.onChange(it, false); show(); say('Saved.'); }).catch(function (x) { say(x.message); });
      });
    }
    if (a === 'like') el.setAttribute('aria-pressed', el.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
    m.hidden = true; box.classList.remove('menu'); say(SOON[a]);
  }
  function close() {
    if (!box) return;
    if (document.fullscreenElement) document.exitFullscreen().catch(function () {});
    box.remove(); box = null; document.documentElement.style.overflow = ''; if (back && back.focus) back.focus();
  }
  var busy = false;
  function step(d) {   // slide the strip one photo, then the next one becomes the current
    if (L.length < 2 || busy || !box || at + d < 0 || at + d >= L.length) return;   // the first and last photo are the ends
    var tr = box.querySelector('.pv-track'), w = box.querySelector('.pv-stage').clientWidth + 16;
    busy = true; tr.style.transition = 'transform .24s ease-out'; tr.style.transform = 'translateX(' + (-d * w) + 'px)';
    setTimeout(function () { busy = false; if (!box) return; at += d; tr.style.transition = 'none'; tr.style.transform = ''; show(); }, 240);
  }
  function open(items, i, opts, from) {
    if (!document.getElementById('pv-css')) { var st = document.createElement('style'); st.id = 'pv-css'; st.textContent = css; document.head.appendChild(st); }
    L = items; at = i || 0; O = opts || {}; back = from || null;
    box = document.createElement('div'); box.className = 'pv'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'Photo');
    box.innerHTML = '<div class="pv-stage"><div class="pv-track"><div class="pv-pane prev"><img alt="" draggable="false"></div><div class="pv-pane"><img class="pv-cur" alt="" draggable="false"></div><div class="pv-pane next"><img alt="" draggable="false"></div></div><button type="button" class="pv-b pv-x" aria-label="Close" title="Close">&times;</button>'
      + '<div class="pv-tools"><button type="button" class="pv-b" data-pv="zin" title="Zoom in" aria-label="Zoom in">' + I.zin + '</button><button type="button" class="pv-b" data-pv="zout" title="Zoom out" aria-label="Zoom out">' + I.zout + '</button>'
      + '<button type="button" class="pv-b" data-pv="tag" title="Tag people" aria-label="Tag people">' + I.tag + '</button>'
      + '<button type="button" class="pv-b pv-ph" data-pv="place" title="Where it was taken" aria-label="Where it was taken">' + I.pin + '</button>'
      + '<button type="button" class="pv-b" data-pv="full" title="Fullscreen" aria-label="Fullscreen">' + I.full + '</button>'
      + '<button type="button" class="pv-b pv-ph pv-more2" aria-haspopup="menu" aria-label="More" title="More">' + I.dots + '</button></div><span class="pv-count"></span><span class="pv-heart" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z"/></svg></span>'
      + '<button type="button" class="pv-b pv-p" aria-label="Previous photo">&lsaquo;</button><button type="button" class="pv-b pv-n" aria-label="Next photo">&rsaquo;</button></div>'
      + '<aside class="pv-side"></aside><div class="pv-drop" aria-hidden="true"><i>&times;</i><span>Drag here to close</span></div>';
    if (O.thumbs && L.length > 1) {   // a row of small copies under the photo (wide screens)
      var tb = document.createElement('div'); tb.className = 'pv-thumbs'; tb.setAttribute('aria-label', 'All photos');
      tb.innerHTML = L.map(function (x, k) { return '<button type="button" data-pv-to="' + k + '" aria-label="' + esc((x.video ? 'Video ' : 'Photo ') + (k + 1)) + '" style="background-image:url(\'' + esc(x.thumb || x.full) + '\')">' + (x.video ? '<i>&#9654;</i>' : '') + '</button>'; }).join('');
      box.querySelector('.pv-stage').appendChild(tb); box.classList.add('thumbed');
    }
    document.body.appendChild(box); document.documentElement.style.overflow = 'hidden'; show(); box.querySelector('.pv-x').focus();
    var stage = box.querySelector('.pv-stage'), img = stage.querySelector('.pv-cur'), track = stage.querySelector('.pv-track'), drag = null;
    box.addEventListener('click', function (e) {
      if (e.target.closest('.pv-x')) return close();
      var to = e.target.closest('[data-pv-to]'); if (to) { at = +to.getAttribute('data-pv-to'); show(); return; }
      var rm = e.target.closest('[data-pv-rm]');
      if (rm) { if (window.TvAsk && !TvAsk.gate(rm, 'Remove this comment?', { yes: 'Remove', danger: true })) return; var cid = +rm.getAttribute('data-pv-rm'), it0 = L[at];
        O.social.uncomment(cid).then(function () { it0._s.comments = it0._s.comments.filter(function (c) { return c.id !== cid; }); paint(it0._s); }).catch(function (x) { say(x.message); }); return; }
      var rp = e.target.closest('[data-pv-rep]');
      if (rp) { var rid = +rp.getAttribute('data-pv-rep'); (window.TvAsk ? TvAsk.ask('What\'s wrong with this comment?', '') : Promise.resolve('')).then(function (why) {
          if (why === null || why === undefined) return;
          fetch('/api/engage.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': O.csrf || '' }, body: JSON.stringify({ action: 'report', what: 'comment', id: rid, reason: 'other', note: why }) })
            .then(function (r) { return r.json(); }).then(function (d) { say(d.ok ? 'Thanks. Our team will look at it.' : ((d.error && d.error.message) || 'That didn\'t send.')); });
        }); return; }
      if (zoom === 1 && (e.target.classList.contains('pv-pane') || e.target.classList.contains('pv-stage') || e.target.classList.contains('pv-track'))) return close();   // the dark background: out
      if (e.target.closest('.pv-p')) return step(-1);
      if (e.target.closest('.pv-n')) return step(1);
      if (e.target.closest('[data-pv-go]')) { var u = e.target.closest('[data-pv-go]').getAttribute('href'); if (u.charAt(0) === '#') close(); return; }
      var more = e.target.closest('.pv-more, .pv-more2'), m = box.querySelector('.pv-menu');
      if (more) { m.hidden = !m.hidden; box.classList.toggle('menu', !m.hidden); more.setAttribute('aria-expanded', String(!m.hidden)); if (!m.hidden && window.tvShort) tvShort.warm(new URL(L[at].full, location.href).href); return; }
      if (m && !m.hidden && !e.target.closest('.pv-menu')) { m.hidden = true; box.classList.remove('menu'); if (phone()) return; }
      if (e.target.closest('.pv-menu a[download]')) { m.hidden = true; box.classList.remove('menu'); return; }
      var a = e.target.closest('[data-pv]'); if (a) return act(a.getAttribute('data-pv'), a);
      if (e.target === img && zoom === 1 && !phone()) setZoom(2);
    });
    img.addEventListener('dblclick', function () { setZoom(zoom > 1 ? 1 : 2); });
    stage.addEventListener('wheel', function (e) { e.preventDefault(); setZoom(zoom * (e.deltaY < 0 ? 1.15 : 1 / 1.15)); }, { passive: false });
    img.addEventListener('pointerdown', function (e) { if (zoom === 1) return; drag = { x: e.clientX - pan.x, y: e.clientY - pan.y }; img.setPointerCapture(e.pointerId); });
    img.addEventListener('pointermove', function (e) { if (!drag) return; pan = { x: e.clientX - drag.x, y: e.clientY - drag.y }; view(); });
    img.addEventListener('pointerup', function () { drag = null; });
    // touch: side to side, the strip follows the finger and snaps to the next photo; up scrolls the page (the browser's own scroll);
    // down from the top pulls the photo away and closes. Not while zoomed in.
    var t0 = null, axis = null, drop = box.querySelector('.pv-drop');
    function overDrop(t) { var r = drop.querySelector('i').getBoundingClientRect(); return t.clientY > r.top - 70 && Math.abs(t.clientX - (r.left + r.width / 2)) < 110; }   // close only when dropped on the × (not mistaken for pull to refresh)
    var pinch = null;   // two fingers: zoom (and one finger then moves the zoomed photo)
    stage.addEventListener('touchstart', function (ev) {
      if (ev.touches.length === 2) { var a = ev.touches[0], b = ev.touches[1]; pinch = { d: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY), z: zoom }; t0 = null; return; }
      var vid = ev.target.closest('video'), vr = vid && vid.getBoundingClientRect();   // a video swipes like a photo; only its control bar along the bottom is left to the video (Jason, 2026-11-09)
      if (zoom !== 1 || ev.touches.length > 1 || busy || ev.target.closest('button') || (vid && ev.touches[0].clientY > vr.bottom - 72)) { t0 = null; return; }
      t0 = { x: ev.touches[0].clientX, y: ev.touches[0].clientY, top: box.scrollTop }; axis = null; track.style.transition = 'none';
    }, { passive: true });
    stage.addEventListener('touchmove', function (ev) {
      if (pinch && ev.touches.length === 2) { if (ev.cancelable) ev.preventDefault(); var a = ev.touches[0], b = ev.touches[1]; setZoom(pinch.z * Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY) / (pinch.d || 1)); stage.style.touchAction = zoom > 1 ? 'none' : ''; return; }
      if (!t0) return;
      var dx = ev.touches[0].clientX - t0.x, dy = ev.touches[0].clientY - t0.y;
      if (!axis && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) axis = Math.abs(dx) > Math.abs(dy) * 1.2 ? 'x' : (dy > 0 && box.scrollTop <= 0 ? 'down' : 'y');
      if ((axis === 'x' || axis === 'down') && ev.cancelable) ev.preventDefault();   // ours, not the browser's scroll or pull-to-refresh
      if (axis === 'x') track.style.transform = 'translateX(' + ((dx > 0 && at === 0) || (dx < 0 && at === L.length - 1) ? dx / 4 : dx) + 'px)';   // at an end it gives a little, then springs back
      else if (axis === 'down' && dy > 0) { box.classList.add('pull'); var on = overDrop(ev.touches[0]); drop.classList.toggle('on', on); drop.querySelector('span').textContent = on ? 'Let go to close' : 'Drag here to close'; track.style.transform = 'translate(' + dx * .8 + 'px,' + dy * .8 + 'px) scale(' + Math.max(.35, 1 - dy / 650) + ')';   /* it shrinks as it goes, so it fits on the × */ box.style.background = 'rgba(20,13,8,' + Math.max(.15, .9 - dy / 500) + ')'; }
    }, { passive: false });
    stage.addEventListener('touchcancel', function () {   // the browser took the gesture after all: put everything back
      if (!t0) return; t0 = null;
      track.style.transition = 'transform .2s ease-out'; track.style.transform = ''; box.style.background = ''; box.classList.remove('pull'); drop.classList.remove('on');
    });
    var lastTap = 0;
    stage.addEventListener('touchend', function (ev) {
      if (O.social && L[at] && L[at].id && !pinch && t0 && ev.changedTouches.length === 1 && Math.abs(ev.changedTouches[0].clientX - t0.x) < 10 && Math.abs(ev.changedTouches[0].clientY - t0.y) < 10 && !ev.target.closest('button,video')) {
        var now = Date.now(); if (now - lastTap < 320) { lastTap = 0; likeIt(true); } else lastTap = now;   // double-tap: like
      }
      if (pinch) { if (ev.touches.length < 2) pinch = null; stage.style.touchAction = zoom > 1 ? 'none' : ''; return; }
      if (!t0) return;
      var dx = ev.changedTouches[0].clientX - t0.x, dy = ev.changedTouches[0].clientY - t0.y; t0 = null;
      if (axis === 'down' && overDrop(ev.changedTouches[0])) { drop.classList.remove('on'); track.style.transition = 'transform .2s ease-in'; track.style.transform = 'translateY(100vh)'; setTimeout(close, 190); return; }
      if (axis === 'x' && Math.abs(dx) > Math.min(90, stage.clientWidth / 4) && L.length > 1 && at + (dx < 0 ? 1 : -1) >= 0 && at + (dx < 0 ? 1 : -1) < L.length) {   // far enough: carry on to the next photo from where the finger let go
        var w = stage.clientWidth + 16, d = dx < 0 ? 1 : -1;
        busy = true; track.style.transition = 'transform .2s ease-out'; track.style.transform = 'translateX(' + (-d * w) + 'px)';
        setTimeout(function () { busy = false; if (!box) return; at += d; track.style.transition = 'none'; track.style.transform = ''; show(); }, 200);
        return;
      }
      track.style.transition = 'transform .2s ease-out'; track.style.transform = ''; box.style.background = ''; box.classList.remove('pull'); drop.classList.remove('on');   // not on the ×: back into place
    });
  }
  document.addEventListener('keydown', function (e) {
    if (!box) return;
    if (e.target.tagName === 'TEXTAREA') { if (e.key === 'Escape') e.target.blur(); return; }
    if (e.key === 'Escape') close(); else if (e.key === 'ArrowLeft') step(-1); else if (e.key === 'ArrowRight') step(1);
    else if (e.key === '+' || e.key === '=') setZoom(zoom + 0.5); else if (e.key === '-') setZoom(zoom - 0.5);
  });
  var groups = {};
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-tv-photos]'); if (!t || e.target.closest('a, button:not([data-tv-photos])')) return;
    var g = groups[t.getAttribute('data-tv-photos')]; if (!g) return;
    e.preventDefault(); open(g.items, +t.getAttribute('data-i') || 0, g.opts, t);
  });
  document.addEventListener('keydown', function (e) {
    if (box || (e.key !== 'Enter' && e.key !== ' ')) return;
    var t = e.target.closest && e.target.closest('[data-tv-photos]'); if (!t) return;
    var g = groups[t.getAttribute('data-tv-photos')]; if (!g) return;
    e.preventDefault(); open(g.items, +t.getAttribute('data-i') || 0, g.opts, t);
  });
  window.TvPhotos = { open: open, close: close, bind: function (name, items, opts) { groups[name] = { items: items, opts: opts || {} }; } };
})();
