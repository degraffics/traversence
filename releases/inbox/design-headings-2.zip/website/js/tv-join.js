// js/tv-join.js — the account panel for guests (decisions/0009, 0051; 0058 §20 as changed 2026-11-05).
// A guest is an unregistered identity: likes, shares and views work without an account. What comes back to a person
// (comments, saving or linking, messages, joining a group, becoming a contributor) suggests an account right where they
// are: Google, Microsoft or Facebook, or Create account / Sign in, then back to the same page. Never a wall: "Not now".
//   TvJoin.open({why, next, more})     the panel ("why" says what the account is for; next: where to come back; more: a
//                                      guest may carry on without one, Keep going as a guest calls it)
//   TvJoin.askLearning(anchor, cb)     once a visit: "Allow AI & Learning for this visit?" (decisions/0051 §1); cb(true|false)
//   <a|button data-needs-account="why" [data-next="/path"]>   opens the panel for a guest; a member's tap goes through
(function () {
  if (window.TvJoin) return;
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var css = '.tvj-bg{position:fixed;inset:0;z-index:1550;background:rgba(42,27,18,.45);display:flex;align-items:flex-end;justify-content:center}'
    + '@media (min-width:768px){.tvj-bg{align-items:center}}'
    + '.tvj{width:min(26rem,100%);box-sizing:border-box;background:#E3D3AC;color:#3E2B1F;border-radius:1rem 1rem 0 0;padding:1.2rem 1.2rem calc(1.2rem + env(safe-area-inset-bottom));box-shadow:0 -10px 30px -12px rgba(0,0,0,.5);font:400 .95rem/1.45 system-ui,sans-serif}'
    + '@media (min-width:768px){.tvj{border-radius:1rem}}'
    + '.tvj h2{font:700 1.25rem/1.2 var(--tv-font-head,Georgia,serif);margin:0 0 .35rem}.tvj p{margin:.2rem 0 .6rem}'
    + '.tvj-go{display:flex;gap:.5rem;margin-top:.8rem}.tvj-go a{flex:1;text-align:center;border-radius:.6rem;padding:.65rem;font-weight:700;text-decoration:none}'
    + '.tvj-up{background:#C85A17;color:#fff}.tvj-in{border:1px solid #92400E;color:#92400E}'
    + '.tvj-more{display:block;width:100%;margin:.6rem 0 0;border:1px solid #CBB98D;background:#F7EFDC;color:#3E2B1F;border-radius:.6rem;padding:.6rem;font:600 .9rem system-ui,sans-serif;cursor:pointer}'
    + '.tvj-x{display:block;margin:.8rem auto 0;border:0;background:none;color:#7B4A1E;text-decoration:underline;cursor:pointer;font:inherit}'
    + '.tvj-ln{position:absolute;z-index:1500;max-width:18rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.7rem;padding:.7rem .8rem;box-shadow:0 12px 26px -12px rgba(0,0,0,.45);font:400 .85rem/1.4 system-ui,sans-serif;color:#3E2B1F}'
    + '.tvj-ln b{display:block;font-size:.9rem;margin-bottom:.2rem}.tvj-ln button{margin:.5rem .4rem 0 0;border-radius:999px;padding:.3rem .8rem;font:700 .8rem system-ui,sans-serif;cursor:pointer;border:1px solid #92400E;background:#fff;color:#92400E}'
    + '.tvj-ln button.y{background:#92400E;color:#fff}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  function social(next) {
    var t = document.getElementById('tv-join-social'); if (!t) return '';
    var n = encodeURIComponent(next);
    return t.innerHTML.split('%2F__NEXT__').join(n).split('/__NEXT__').join(next);
  }
  function close() { var b = document.querySelector('.tvj-bg'); if (b) b.remove(); document.documentElement.style.overflow = ''; }
  var J = {
    open: function (o) {
      o = o || {}; close();
      var next = o.next || (location.pathname + location.search);
      if (!/^\/(?!\/)/.test(next)) next = '/';
      var q = 'next=' + encodeURIComponent(next);
      var bg = document.createElement('div'); bg.className = 'tvj-bg'; bg.setAttribute('role', 'dialog'); bg.setAttribute('aria-modal', 'true'); bg.setAttribute('aria-label', 'Create a free account');
      bg.innerHTML = '<div class="tvj"><h2>' + esc(o.title || 'Create a free account') + '</h2><p>' + esc(o.why || 'This comes back to you, so it needs an account. It takes a minute.') + '</p>'
        + social(next)
        + '<div class="tvj-go"><a class="tvj-up" href="/login.php?tab=create&' + q + '">Create account</a><a class="tvj-in" href="/login.php?' + q + '">Sign in</a></div>'
        + (typeof o.more === 'function' ? '<button type="button" class="tvj-more">Keep going as a guest</button>' : '')
        + '<button type="button" class="tvj-x">Not now</button></div>';
      document.body.appendChild(bg); document.documentElement.style.overflow = 'hidden';
      bg.addEventListener('click', function (e) {
        if (e.target.closest('.tvj-more')) { close(); o.more(); return; }
        if (e.target === bg || e.target.closest('.tvj-x')) close();
      });
      var f = bg.querySelector('a'); if (f) f.focus();
    },
    askLearning: function (anchor, cb) {
      try { if (sessionStorage.getItem('tvj_learning')) return; sessionStorage.setItem('tvj_learning', '1'); } catch (x) {}
      var d = document.createElement('div'); d.className = 'tvj-ln'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-label', 'AI & Learning for this visit');
      d.innerHTML = '<b>Help improve Traversence?</b>Let it learn from how this visit uses the site, so guides and suggestions get better for everyone. Nothing about you is kept, and it ends with your visit.'
        + '<br><button type="button" class="y" data-a="1">Allow for this visit</button><button type="button" data-a="0">Not now</button>';
      document.body.appendChild(d);
      var r = anchor.getBoundingClientRect();
      d.style.top = (window.scrollY + r.bottom + 8) + 'px';
      d.style.left = Math.max(8, Math.min(window.scrollX + r.left, window.scrollX + document.documentElement.clientWidth - d.offsetWidth - 8)) + 'px';
      d.addEventListener('click', function (e) { var b = e.target.closest('[data-a]'); if (!b) return; d.remove(); if (cb) cb(b.getAttribute('data-a') === '1'); });
    },
    close: close
  };
  window.TvJoin = J;
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  // a guest's tap on something that needs an account opens the panel; a member's goes straight through
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-needs-account]'); if (!a || window.appAuthActive) return;
    if (!document.getElementById('tv-join-social') && !document.body.hasAttribute('data-guest')) return;   // the header marks guests
    e.preventDefault(); e.stopPropagation();
    J.open({ why: a.getAttribute('data-needs-account'), next: a.getAttribute('data-next') || a.getAttribute('href') || (location.pathname + location.search) });
  }, true);
})();
