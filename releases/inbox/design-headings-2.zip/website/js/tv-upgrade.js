// js/tv-upgrade.js — the one upgrade sheet (decisions/0154 §5): offered where someone reaches for more (a full Gallery, the
// 2-minute recording limit), beside a free way to carry on; never banners or pop-ups on page load, at most once a visit
// for the same thing, never for what the account already has. The choices come from /api/upgrade.php; plans and packs
// pay in place on the Plans page, so whatever was in progress (a draft, a recording) stays where it was.
//   TvUpgrade.offer(feature, {anchor, listing}) -> Promise of 'free' | 'chose' | 'closed' | 'have' | 'shown'
(function () {
  'use strict';
  if (window.TvUpgrade) return;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  var css = '.tvup-bg{position:fixed;inset:0;z-index:2100;background:rgba(42,27,18,.45);display:flex;align-items:center;justify-content:center;padding:1rem}'
    + '.tvup{background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D;border-radius:1rem;max-width:26rem;width:100%;padding:1rem 1.1rem;box-shadow:0 18px 40px -16px rgba(0,0,0,.55);font:400 .92rem system-ui,sans-serif}'
    + '.tvup h2{font:700 1.15rem var(--tv-font-head,Georgia,serif);margin:0 1.8rem .3rem 0}.tvup p{margin:0 0 .7rem;color:#5C4632;line-height:1.4}'
    + '.tvup-x{position:absolute;top:.55rem;right:.6rem;width:30px;height:30px;border-radius:50%;border:1px solid #CBB98D;background:#FFFBF2;color:#5C4632;font-size:1.1rem;cursor:pointer}'
    + '.tvup-c{display:block;text-decoration:none;color:#3E2B1F;border:1px solid #CBB98D;border-radius:.7rem;padding:.55rem .75rem;margin:0 0 .45rem;background:#F7EFDC}.tvup-c:hover{border-color:#B8863B}'
    + '.tvup-c b{display:block;color:#92400E}.tvup-c small{color:#5C4632}'
    + '.tvup-f{display:block;width:100%;margin-top:.3rem;border:0;background:none;color:#5C4632;text-decoration:underline;font:600 .9rem system-ui,sans-serif;cursor:pointer;padding:.4rem}'
    + '@media (max-width:767px){.tvup-bg{align-items:flex-end;padding:0}.tvup{border-radius:1rem 1rem 0 0;max-width:none;padding-bottom:1.4rem}}';
  function style() { if (document.getElementById('tvup-css')) return; var s = document.createElement('style'); s.id = 'tvup-css'; s.textContent = css; document.head.appendChild(s); }
  function seen(f) { try { return sessionStorage.getItem('tvup_' + f) === '1'; } catch (e) { return false; } }
  function mark(f) { try { sessionStorage.setItem('tvup_' + f, '1'); } catch (e) {} }
  function offer(feature, o) {
    o = o || {};
    if (seen(feature) && !o.again) return Promise.resolve('shown');
    if (o.anchor && window.TvAsk && TvAsk.busy) TvAsk.busy(o.anchor, true);
    return fetch('/api/upgrade.php?feature=' + encodeURIComponent(feature) + (o.listing ? '&listing=' + (+o.listing) : ''), { credentials: 'include', headers: { Accept: 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (o.anchor && window.TvAsk && TvAsk.busy) TvAsk.busy(o.anchor, false);
        if (!d || !d.ok) throw new Error((d && d.error && d.error.message) || 'That isn\'t available right now.');
        if (d.have) return 'have';
        mark(feature); style();
        return new Promise(function (done) {
          var bg = document.createElement('div'); bg.className = 'tvup-bg';
          bg.innerHTML = '<div class="tvup" role="dialog" aria-modal="true" aria-labelledby="tvup-h" style="position:relative"><button type="button" class="tvup-x" aria-label="Close">&times;</button>'
            + '<h2 id="tvup-h">' + esc(d.title) + '</h2><p>' + esc(d.why) + '</p>'
            + (d.choices || []).map(function (c) { return '<a class="tvup-c" href="' + esc(c[2]) + '" target="_blank" rel="noopener" data-chose><b>' + esc(c[0]) + '</b><small>' + esc(c[1]) + '</small></a>'; }).join('')
            + (d.free ? (d.free[1] ? '<a class="tvup-f" href="' + esc(d.free[1]) + '" data-free style="text-align:center">' + esc(d.free[0]) + '</a>' : '<button type="button" class="tvup-f" data-free>' + esc(d.free[0]) + '</button>') : '')
            + '</div>';
          function close(why) { document.removeEventListener('keydown', key); bg.remove(); done(why); }
          function key(e) { if (e.key === 'Escape') close('closed'); }
          bg.addEventListener('click', function (e) {
            if (e.target === bg || e.target.closest('.tvup-x')) { close('closed'); return; }
            if (e.target.closest('[data-chose]')) { setTimeout(function () { close('chose'); }, 0); return; }   // the Plans page opens in a new tab, so this page (a draft, a recording) stays as it was
            var f = e.target.closest('[data-free]'); if (f) { if (f.tagName === 'BUTTON') close('free'); else done('free'); }
          });
          document.addEventListener('keydown', key);
          document.body.appendChild(bg);
          var first = bg.querySelector('.tvup-c, .tvup-f'); if (first) first.focus();
        });
      })
      .catch(function (e) {
        if (o.anchor && window.TvAsk && TvAsk.busy) TvAsk.busy(o.anchor, false);
        if (window.TvAsk && TvAsk.say) TvAsk.say(e.message, { anchor: o.anchor, bad: true });
        return 'closed';
      });
  }
  window.TvUpgrade = { offer: offer };
})();
