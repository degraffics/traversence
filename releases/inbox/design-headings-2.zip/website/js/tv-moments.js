/* js/tv-moments.js — Moments and Keep (decisions/0153): the composer, the 2-minute recorder and the posts feed.
 *   TvMoments.composer(el)            "What's on your mind?" for the signed-in member: words, photos and videos (picked,
 *                                     or recorded here: press record, the ring counts 2:00 down to 0 and stops), who sees
 *                                     it, how long it lasts (3 or 7 days), and Keep.
 *   TvMoments.feed(el, {owner, grid}) a member's posts this viewer may see: reactions, comments, Share, the ⋯ menu, and
 *                                     for the owner who saw it, Keep and the rest. List or Grid.
 *   TvMoments.post(el, id)            one post (its own page).
 * Talks to /user/api/posts.php; files go through the one uploader (TvUpload, target 'moment'). Notices through TvAsk. */
(function () {
  if (window.TvMoments) return;
  var API = '/user/api/posts.php', ME = null, meP = null, csrfV = '';
  var REACT = {   // flat line icons in the brand's style, never emoji
    like: '<path d="M7 11v9H4v-9z"/><path d="M7 11l4-7c1.3 0 2.2 1 2 2.3L12.5 10H18a2 2 0 0 1 2 2.3l-1.2 6A2 2 0 0 1 16.8 20H7"/>',
    love: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
    care: '<circle cx="12" cy="12" r="9"/><path d="M12 16.5s-3.2-2-3.2-4.4a1.8 1.8 0 0 1 3.2-1.1 1.8 1.8 0 0 1 3.2 1.1c0 2.4-3.2 4.4-3.2 4.4z"/>',
    haha: '<circle cx="12" cy="12" r="9"/><path d="M8 13.5h8a4 4 0 0 1-8 0z"/><path d="M8 9.5l1.5 1M16 9.5l-1.5 1"/>',
    wow: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="15" r="2"/><circle cx="9" cy="9.5" r=".6"/><circle cx="15" cy="9.5" r=".6"/>',
    sad: '<circle cx="12" cy="12" r="9"/><path d="M8.5 16.5a4 4 0 0 1 7 0"/><circle cx="9" cy="10" r=".6"/><circle cx="15" cy="10" r=".6"/><path d="M16.5 11.5v2"/>',
    angry: '<circle cx="12" cy="12" r="9"/><path d="M8.5 16.5a4 4 0 0 1 7 0"/><path d="M7.5 8.5l3 1.5M16.5 8.5l-3 1.5"/>'
  };
  var NAMES = { like: 'Like', love: 'Love', care: 'Care', haha: 'Haha', wow: 'Wow', sad: 'Sad', angry: 'Angry' };
  var REASONS = [['spam', 'Spam or scam'], ['harassment', 'Harassment or hate'], ['private_info', 'Someone\'s private information'], ['people', 'Shows people without their consent'],
                 ['sacred_site', 'Shows a sacred or restricted site'], ['unsafe', 'Breaks the law or puts someone in danger'], ['other', 'Something else']];
  function svg(d, w) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 1.8) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>'; }
  var IC = {
    photo: svg('<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5-8 8"/>'),
    rec: svg('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.5" fill="currentColor"/>'),
    more: svg('<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>'),
    comment: svg('<path d="M4 5h16v11H9l-5 4z"/>'), share: svg('<path d="M12 4v11"/><path d="M8 8l4-4 4 4"/><path d="M5 13v6h14v-6"/>'),
    eye: svg('<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    keep: svg('<path d="M6 3h12v18l-6-4-6 4z"/>'), play: svg('<path d="M8 5l11 7-11 7z" fill="currentColor"/>'),
    globe: svg('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>'), users: svg('<circle cx="9" cy="8" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M16 4.5a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>'),
    lock: svg('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'), flip: svg('<path d="M4 9h13l-3-3M20 15H7l3 3"/>'),
    grid: svg('<rect x="4" y="4" width="7" height="7"/><rect x="13" y="4" width="7" height="7"/><rect x="4" y="13" width="7" height="7"/><rect x="13" y="13" width="7" height="7"/>'),
    list: svg('<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>'), x: svg('<path d="M6 6l12 12M18 6L6 18"/>', 2.2)
  };
  var AUD_IC = { public: IC.globe, followers: IC.users, connections: IC.users, only_me: IC.lock };

  var css = '.tmo-vw{position:relative}.tmo-vw video{width:100%;display:block}.tmo-hd{position:absolute;top:.5rem;right:.5rem;font-size:.78rem!important;padding:.2rem .6rem!important;opacity:.92}.tmo [hidden]{display:none!important}.tmo{--b:#CBB98D;--br:#92400E;--ic:#B45309;--ink:#3E2B1F;--mut:#8A7355;--cr:#FFFBF2;--sg:#8FBCA8;font-size:.92rem;color:var(--ink)}'
    + '.tmo-card{background:var(--cr);border:1px solid var(--b);border-radius:.8rem;padding:.75rem .85rem;margin:0 0 .6rem}'
    + '.tmo-h{display:flex;gap:.6rem;align-items:center}.tmo-av{width:40px;height:40px;border-radius:999px;background:#3E2B1F center/cover;color:#B8863B;display:flex;align-items:center;justify-content:center;font:700 1.1rem var(--tv-font-head,ui-serif,Georgia,serif);flex:0 0 auto}'
    + '.tmo-who{flex:1;min-width:0}.tmo-who a{color:var(--br);font-weight:700;text-decoration:underline}.tmo-sub{font-size:.78rem;color:var(--mut);display:flex;gap:.35rem;align-items:center;flex-wrap:wrap}.tmo-sub svg{width:13px;height:13px}'
    + '.tmo-i{width:30px;height:30px;border-radius:999px;border:1px solid var(--b);background:var(--cr);color:var(--ic);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;flex:0 0 auto;padding:0}.tmo-i svg{width:16px;height:16px}'
    + '.tmo-body{white-space:pre-line;overflow-wrap:anywhere;margin:.55rem 0 .2rem;line-height:1.45}'
    + '.tmo-media{display:grid;gap:3px;margin:.5rem -.85rem 0;grid-template-columns:repeat(2,1fr)}.tmo-media.n1{grid-template-columns:1fr}.tmo-m{position:relative;background:#E3D3AC center/cover;aspect-ratio:1;cursor:pointer;overflow:hidden;border:0;padding:0}'
    + '.tmo-media.n1 .tmo-m{aspect-ratio:auto;min-height:12rem;max-height:34rem}.tmo-m img{width:100%;height:100%;object-fit:cover;display:block}.tmo-media.n1 .tmo-m img{object-fit:contain;background:#1b130d;max-height:34rem}'
    + '.tmo-m video{width:100%;max-height:34rem;display:block;background:#000}.tmo-play{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}.tmo-play span{width:56px;height:56px;border-radius:999px;background:rgba(0,0,0,.55);color:#fff;display:flex;align-items:center;justify-content:center}.tmo-play svg{width:24px;height:24px}'
    + '.tmo-len{position:absolute;right:.4rem;bottom:.4rem;background:rgba(0,0,0,.6);color:#fff;font-size:.72rem;border-radius:.3rem;padding:.05rem .35rem}'
    + '.tmo-sum{display:flex;justify-content:space-between;gap:.5rem;font-size:.8rem;color:var(--mut);margin:.5rem 0 .3rem}.tmo-sum .rx{display:inline-flex;align-items:center;gap:.1rem}.tmo-sum .rx svg{width:15px;height:15px;color:var(--ic)}'
    + '.tmo-acts{display:flex;border-top:1px solid var(--b);padding-top:.35rem;gap:.2rem}.tmo-a{flex:1;display:inline-flex;gap:.35rem;align-items:center;justify-content:center;background:none;border:0;border-radius:.5rem;padding:.4rem;color:var(--ink);font-weight:600;cursor:pointer;font-size:.85rem}.tmo-a:hover{background:#F2E7CF}.tmo-a svg{width:18px;height:18px;color:var(--ic)}.tmo-a.on{color:var(--br)}.tmo-a.on svg{color:var(--br)}'
    + '.tmo-pick{display:flex;gap:.15rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:999px;padding:.25rem;box-shadow:0 6px 18px -8px rgba(0,0,0,.4);position:fixed;z-index:1500}.tmo-pick button{width:38px;height:38px;border:0;border-radius:999px;background:none;color:#B45309;cursor:pointer}.tmo-pick button svg{width:26px;height:26px}.tmo-pick button:hover,.tmo-pick button.on{background:#E4F0E9;color:#3F6F5A}'
    + '.tmo-com{border-top:1px solid var(--b);margin-top:.35rem;padding-top:.45rem}.tmo-c{display:flex;gap:.45rem;margin:0 0 .4rem}.tmo-cb{background:#F2E7CF;border-radius:.8rem;padding:.35rem .6rem;flex:1;min-width:0}.tmo-cb b{font-size:.8rem}.tmo-cb p{margin:0;white-space:pre-line;overflow-wrap:anywhere}'
    + '.tmo-cf{display:flex;gap:.4rem}.tmo-in{flex:1;border:1px solid var(--b);border-radius:.7rem;padding:.45rem .6rem;background:#fff;font:inherit;min-width:0}.tmo-b{border:1px solid var(--b);background:var(--cr);color:var(--ink);border-radius:.6rem;padding:.4rem .8rem;font-weight:600;cursor:pointer;font-size:.85rem}.tmo-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFFBF2}'
    + '.tmo-menu{position:fixed;z-index:1500;max-height:calc(100vh - 16px);overflow:auto;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;box-shadow:0 10px 28px -8px rgba(0,0,0,.5);min-width:15rem;max-width:calc(100vw - 16px);padding:.3rem;font:500 .92rem system-ui,sans-serif;color:#3E2B1F}.tmo-menu button{display:block;width:100%;text-align:left;background:none;border:0;border-radius:.4rem;padding:.55rem .7rem;cursor:pointer;font:inherit;color:#3E2B1F}.tmo-menu button:hover,.tmo-menu button:focus-visible{background:#F2E7CF}.tmo-menu button small{display:block;color:#8A7355;font-size:.78rem;margin-top:.1rem}.tmo-menu .bad{color:#991B1B}.tmo-menu button+button{border-top:1px solid #EFE3C8}'
    + '.tmo-tag{display:inline-flex;gap:.25rem;align-items:center;font-size:.72rem;font-weight:700;border-radius:999px;padding:.05rem .5rem;background:#E4F0E9;color:#1F5C43}.tmo-tag.end{background:#FFF4DC;color:#92400E}'
    + '.tmo-comp textarea{width:100%;border:1px solid var(--b);border-radius:.7rem;padding:.6rem .7rem;font:inherit;background:#fff;resize:vertical;min-height:4.5rem}.tmo-open{display:flex;gap:.6rem;align-items:center}.tmo-open button.tmo-say{flex:1;text-align:left;border:1px solid var(--b);background:#fff;border-radius:999px;padding:.6rem 1rem;color:var(--mut);cursor:text;font:inherit}'
    + '.tmo-tools{display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;margin-top:.5rem}.tmo-tools .tmo-b{display:inline-flex;gap:.35rem;align-items:center}.tmo-tools .tmo-b svg{width:18px;height:18px;color:var(--ic)}.tmo-sel{border:1px solid var(--b);border-radius:.6rem;padding:.35rem .5rem;background:var(--cr);font:inherit;font-size:.85rem}'
    + '.tmo-keep{display:inline-flex;gap:.35rem;align-items:center;font-size:.85rem;font-weight:600}.tmo-strip{display:flex;gap:.35rem;flex-wrap:wrap;margin-top:.5rem}.tmo-th{position:relative;width:76px;height:76px;border-radius:.5rem;background:#E3D3AC center/cover;border:1px solid var(--b)}.tmo-th button{position:absolute;top:-6px;right:-6px;width:22px;height:22px;border-radius:999px;border:0;background:#3E2B1F;color:#fff;cursor:pointer;padding:0}.tmo-th button svg{width:12px;height:12px}.tmo-th i{position:absolute;left:4px;bottom:4px;color:#fff;font-style:normal;font-size:.7rem;background:rgba(0,0,0,.55);border-radius:.25rem;padding:0 .25rem}'
    + '.tmo-to{display:flex;flex-wrap:wrap;gap:.3rem;align-items:center;border:1px solid #CBB98D;border-radius:.7rem;background:#fff;padding:.3rem .5rem;margin:0 0 .45rem;position:relative}.tmo-to>b{font-size:.85rem;color:#8A7355;margin-right:.1rem}'
    + '.tmo-to input{flex:1;min-width:8rem;border:0;outline:0;font:inherit;padding:.25rem 0;background:none}.tmo-chip{display:inline-flex;gap:.25rem;align-items:center;background:#E4F0E9;color:#1F5C43;border-radius:999px;padding:.15rem .25rem .15rem .6rem;font-size:.82rem;font-weight:600}'
    + '.tmo-chip button{width:20px;height:20px;border:0;border-radius:999px;background:rgba(0,0,0,.08);cursor:pointer;padding:0;display:inline-flex;align-items:center;justify-content:center}.tmo-chip button svg{width:11px;height:11px}'
    + '.tmo-sug{position:absolute;left:0;right:0;top:100%;margin-top:4px;z-index:40;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;box-shadow:0 10px 24px -10px rgba(0,0,0,.45);max-height:16rem;overflow:auto}'
    + '.tmo-sug button{display:block;width:100%;text-align:left;border:0;background:none;padding:.5rem .7rem;cursor:pointer;font:inherit;color:#3E2B1F}.tmo-sug button+button{border-top:1px solid #EFE3C8}.tmo-sug button:hover{background:#F2E7CF}.tmo-sug button[disabled]{color:#8A7355;cursor:default;background:none}.tmo-sug small{display:block;color:#8A7355;font-size:.76rem}'
    + '.tmo-snapto{font-size:.78rem;color:#5C4632;margin:.35rem 0 0}.tmo-ov{position:fixed;inset:0;z-index:1800;background:rgba(30,20,12,.55);display:flex;align-items:flex-start;justify-content:center;padding:max(3vh,12px) 8px;overflow:auto}.tmo-ov>div{width:100%;max-width:36rem}'
    + '.tmo-note{font-size:.78rem;color:var(--mut);margin:.4rem 0 0}.tmo-top{display:flex;align-items:center;gap:.4rem;margin:0 0 .55rem}.tmo-top h2{margin:0 auto 0 0;font:700 1.15rem var(--tv-font-head,ui-serif,Georgia,serif)}'
    + '.tmo-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:3px}.tmo-grid .tmo-m{aspect-ratio:1}.tmo-empty{color:var(--mut);font-size:.88rem}'
    + '.tmo-rec [hidden]{display:none!important}.tmo-rec{position:fixed;inset:0;z-index:2000;background:#000;color:#fff;overflow:hidden;touch-action:none;font-family:system-ui,sans-serif}'
    + '.tmo-rec-f{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);overflow:hidden;background:#000}.tmo-rec video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000}.tmo-rec video.mirror{transform:scaleX(-1)}'
    + '.tmo-rec-fr{display:flex;justify-content:center;gap:.4rem;margin:0 0 .9rem}.tmo-rec-fr button{border:1px solid rgba(255,255,255,.55);background:rgba(0,0,0,.45);color:#fff;border-radius:999px;padding:.35rem .8rem;font:600 .85rem system-ui;cursor:pointer}.tmo-rec-fr button[aria-pressed=true]{background:#FFFBF2;color:#3E2B1F;border-color:#FFFBF2}.tmo-rec.on .tmo-rec-fr{visibility:hidden}'
    + '.tmo-rec-top{position:absolute;left:0;right:0;top:0;display:flex;justify-content:space-between;align-items:center;padding:calc(env(safe-area-inset-top,0px) + .8rem) .9rem .8rem;background:linear-gradient(rgba(0,0,0,.45),transparent)}'
    + '.tmo-rec-bot{position:absolute;left:0;right:0;bottom:0;padding:1.2rem .9rem calc(env(safe-area-inset-bottom,0px) + 1.4rem);background:linear-gradient(transparent,rgba(0,0,0,.55))}'
    + '.tmo-rec-row{display:grid;grid-template-columns:1fr auto 1fr;align-items:center}.tmo-rec-row>:first-child{justify-self:start}.tmo-rec-row>:last-child{justify-self:end}'
    + '.tmo-rec-x{width:44px;height:44px;border-radius:999px;border:0;background:rgba(0,0,0,.45);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}.tmo-rec-x svg{width:22px;height:22px}'
    + '.tmo-rec-t{display:inline-flex;align-items:center;gap:.45rem;background:rgba(0,0,0,.45);border-radius:999px;padding:.35rem .8rem;font:700 1rem system-ui;font-variant-numeric:tabular-nums}.tmo-rec-t i{width:10px;height:10px;border-radius:999px;background:#9a9a9a}.tmo-rec.on .tmo-rec-t i{background:#E5484D;animation:tmoblink 1s infinite}'
    + '@keyframes tmoblink{50%{opacity:.25}}'
    + '.tmo-shut{position:relative;width:82px;height:82px;border:0;background:none;padding:0;cursor:pointer}.tmo-shut svg{position:absolute;inset:0;width:82px;height:82px;transform:rotate(-90deg)}'
    + '.tmo-shut span{position:absolute;left:50%;top:50%;width:62px;height:62px;margin:-31px 0 0 -31px;border-radius:999px;background:#E5484D;transition:all .2s}.tmo-rec.on .tmo-shut span{width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:7px}'
    + '.tmo-rec-i{width:48px;height:48px;border-radius:999px;border:0;background:rgba(0,0,0,.45);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}.tmo-rec-i svg{width:24px;height:24px}.tmo-rec.on .tmo-rec-i.still{visibility:hidden}'
    + '.tmo-rec-z{min-width:48px;height:48px;border-radius:999px;border:0;background:rgba(0,0,0,.45);color:#fff;font:700 .95rem system-ui;cursor:pointer;padding:0 .6rem}.tmo-rec.review .tmo-rec-z{display:none}'
    + '.tmo-rec-hint{text-align:center;font-size:.85rem;margin:0 0 .8rem;text-shadow:0 1px 3px rgba(0,0,0,.7)}'
    + '.tmo-rec-b{border:1px solid rgba(255,255,255,.6);background:rgba(0,0,0,.45);color:#fff;border-radius:999px;padding:.7rem 1.3rem;font:700 1rem system-ui;cursor:pointer}.tmo-rec-b.go{background:#FFFBF2;color:#3E2B1F;border-color:#FFFBF2}'
    + '.tmo-rec-play{position:absolute;left:50%;top:50%;width:76px;height:76px;margin:-38px 0 0 -38px;border-radius:999px;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;pointer-events:none}.tmo-rec-play svg{width:34px;height:34px}'
    + '.tmo-lb{position:fixed;inset:0;z-index:2000;background:rgba(18,12,8,.94);display:flex;align-items:center;justify-content:center}.tmo-lb img{max-width:96vw;max-height:92vh}.tmo-lb button{position:absolute;top:.8rem;right:.8rem}'
    + '@media (max-width:767px){.tmo-card{border-radius:.5rem}.tmo-media{margin:.5rem -.85rem 0}}';
  function style() { if (document.getElementById('tmo-css')) return; var s = document.createElement('style'); s.id = 'tmo-css'; s.textContent = css; document.head.appendChild(s); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function el(h) { var d = document.createElement('div'); d.innerHTML = h.trim(); return d.firstChild; }
  function say(msg, at, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: at, bad: bad }); }
  function busy(b, on) { if (window.TvAsk && b) TvAsk.busy(b, on); }

  function me() {
    if (!meP) meP = fetch(API + '?me=1', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { if (d.ok) { ME = d; csrfV = d.csrf || ''; } return d.ok ? d : null; }).catch(function () { return null; });
    return meP;
  }
  function csrf() {
    if (csrfV) return Promise.resolve(csrfV);
    var m = document.querySelector('meta[name="csrf-token"]'); if (m && m.content) return Promise.resolve(csrfV = m.content);
    return fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrfV = (d && d.csrf_token) || ''); });
  }
  function send(body) {
    return csrf().then(function (t) {
      return fetch(API, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': t }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) });
    }).then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer properly. Try again.' } }; }); })
      .then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work. Try again.'); return d; });
  }
  function get(q) { return fetch(API + '?' + q, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That isn\'t available.'); return d; }); }
  // times where they happened: in the zone the post was made in, labeled (js/tv-time.js; loaded here if the page hasn't)
  if (!window.TvTime && !document.querySelector('script[src^="/js/tv-time.js"]')) { var tt = document.createElement('script'); tt.src = '/js/tv-time.js'; tt.defer = true; (document.head || document.documentElement).appendChild(tt); }
  function when(iso, tz) {
    if (window.TvTime) try { return TvTime.fmt(iso, tz || undefined); } catch (e) {}
    var d = new Date(iso), o = { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short' };
    if (isNaN(d)) return '';
    try { return d.toLocaleString([], tz ? Object.assign({ timeZone: tz }, o) : o); } catch (e) { return d.toLocaleString([], o); }
  }
  function left(iso) {
    var h = (new Date(iso) - Date.now()) / 3600000; if (isNaN(h)) return '';
    return h <= 1 ? 'Ends within the hour' : h < 24 ? 'Ends in ' + Math.round(h) + ' h' : 'Ends in ' + Math.round(h / 24) + ' day' + (Math.round(h / 24) === 1 ? '' : 's');
  }
  function mmss(s) { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function menu(anchor, items) {
    document.querySelectorAll('.tmo-menu').forEach(function (m) { m.remove(); });
    var m = el('<div class="tmo-menu" role="menu"></div>');
    items.forEach(function (it) {
      if (!it) return;
      var b = el('<button type="button" role="menuitem"' + (it.bad ? ' class="bad"' : '') + '>' + esc(it.t) + (it.s ? '<small>' + esc(it.s) + '</small>' : '') + '</button>');
      b.addEventListener('click', function (e) { e.stopPropagation(); m.remove(); it.go(anchor); });
      m.appendChild(b);
    });
    document.body.appendChild(m);
    // pinned to the screen beside the button (never moves the page; above it when there's more room there); a scroll closes it
    var r = anchor.getBoundingClientRect(), h = m.offsetHeight, below = window.innerHeight - r.bottom;
    m.style.top = Math.max(8, below < h + 8 && r.top > below ? r.top - h - 4 : r.bottom + 4) + 'px';
    m.style.left = Math.max(8, Math.min(r.right - m.offsetWidth, document.documentElement.clientWidth - m.offsetWidth - 8)) + 'px';
    function off() { m.remove(); document.removeEventListener('click', off); document.removeEventListener('keydown', esc1, true); window.removeEventListener('scroll', off, true); }
    function esc1(e) { if (e.key === 'Escape') { e.stopPropagation(); off(); } }
    setTimeout(function () { document.addEventListener('click', off); document.addEventListener('keydown', esc1, true); window.addEventListener('scroll', off, true); }, 0);
    return m;
  }
  function choose(anchor, label, list, cur) {   // a short list to pick from, beside what was tapped
    return new Promise(function (res) {
      menu(anchor, list.map(function (o) { return { t: (o[0] === cur ? '✓ ' : '') + o[1], s: o[2] || '', go: function () { res(o[0]); } }; }));
    });
  }

  // ---- the composer ---------------------------------------------------------------------------------------------------
  function composer(host, opts) {
    style(); opts = opts || {};
    host.classList.add('tmo');
    me().then(function (d) {
      if (!d) { host.innerHTML = ''; return; }
      var aud = d.audience, win = 72, keep = false, media = [], sending = 0, to = (opts.to || []).slice(), feed = false, as = +(opts.as || 0);
      var bizs = d.businesses || [];
      var avatar = opts.avatar || '';
      host.innerHTML = '<div class="tmo-card tmo-comp tv-bleed"><div class="tmo-open"><span class="tmo-av"' + (avatar ? ' style="background-image:url(\'' + esc(avatar) + '\')"' : '') + '>' + (avatar ? '' : esc((opts.name || '?').charAt(0).toUpperCase())) + '</span>'
        + '<button type="button" class="tmo-say">What\'s on your mind?</button></div>'
        + '<div class="tmo-form" hidden>' + (bizs.length && !opts.to && !opts.as ? '<label class="tmo-keep" style="margin:0 0 .45rem">Post as <select class="tmo-sel" data-as aria-label="Post as"><option value="0">' + esc(opts.name || 'You') + '</option>'
          + bizs.map(function (b) { return '<option value="' + b.id + '"' + (b.id === as ? ' selected' : '') + '>' + esc(b.name) + '</option>'; }).join('') + '</select></label>' : '')
        + '<div class="tmo-to" data-tobox><b>To</b><span data-chips></span><input data-toq autocomplete="off" placeholder="Your feed, or people and groups" aria-label="Send to people or groups (leave empty to post to your feed)"><div class="tmo-sug" data-sug hidden role="listbox"></div></div>'
        + '<textarea data-spell maxlength="5000" placeholder="What\'s on your mind?" aria-label="What\'s on your mind?"></textarea><div class="tmo-strip"></div>'
        + '<div class="tmo-tools"><button type="button" class="tmo-b" data-pick>' + IC.photo + 'Photo/video</button><button type="button" class="tmo-b" data-rec>' + IC.rec + 'Record</button>'
        + '<select class="tmo-sel" data-aud aria-label="Who sees it"></select><select class="tmo-sel" data-win aria-label="How long it lasts"></select>'
        + '<label class="tmo-keep" data-feedbox hidden title="Also show it on your profile and in your followers\' Pulse"><input type="checkbox" data-feed> Also post to my feed</label>'
        + '<label class="tmo-keep" title="Kept posts stay, and their photos and videos go into your Gallery (they count toward your storage)"><input type="checkbox" data-keep> Keep</label>'
        + '<span style="flex:1"></span><button type="button" class="tmo-b" data-cancel>Cancel</button><button type="button" class="tmo-b go" data-post>Post</button></div>'
        + '<p class="tmo-note" data-lim></p><input type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" multiple hidden></div></div>';
      var q = function (s) { return host.querySelector(s); };
      var form = q('.tmo-form'), ta = q('textarea'), strip = q('.tmo-strip'), file = q('input[type=file]');
      function audOpts() {   // a business posts to everyone, or to the people who linked it
        var sel = q('[data-aud]'); sel.innerHTML = '';
        var list = as ? [['public', 'Public', 'Anyone on or off Traversence.'], ['followers', 'People who linked it', 'Only people who linked the business.']] : d.audiences;
        if (as && aud !== 'followers') aud = 'public'; if (!as && !list.some(function (a) { return a[0] === aud; })) aud = d.audience;
        list.forEach(function (a) { var o = document.createElement('option'); o.value = a[0]; o.textContent = a[1]; o.title = a[2]; if (a[0] === aud) o.selected = true; sel.appendChild(o); });
      }
      audOpts();
      d.windows.forEach(function (w) { var o = document.createElement('option'); o.value = w[0]; o.textContent = 'Lasts ' + w[1]; q('[data-win]').appendChild(o); });
      function lim() {
        var l = d.limits, bn = as ? ((bizs.filter(function (b) { return b.id === as; })[0] || {}).name || opts.name || 'the business') : '';
        var t = keep ? 'Kept: it stays, and its photos and videos go into ' + (as ? bn + '\'s' : 'your') + ' Gallery.' : 'It ends in ' + (win === 168 ? '7 days' : '3 days') + ' and is deleted, unless you tap Keep before then.';
        if (as) { q('[data-lim]').textContent = t + ' Posts as ' + bn + ' have no daily limit; kept photos and videos use its plan\'s storage.'; return; }   // a business isn't capped (decisions/0141 §2.4)
        t += ' ' + (l.left > 0 ? l.left + ' photo or video post' + (l.left === 1 ? '' : 's') + ' left today.' : 'No photo or video posts left today: words only until tomorrow, or delete one of your active ones.');
        if (!l.video) t += ' Video is paused on free accounts until the 1st.';
        q('[data-lim]').textContent = t;
      }
      lim();
      // the To line: empty posts to your feed; people or groups make it a Snap (Send); "Also post to my feed" does both
      var toq = q('[data-toq]'), sug = q('[data-sug]'), tq = null;
      function label() {
        var b = q('[data-post]'), snap = to.length > 0;
        q('[data-tobox]').hidden = !!as;   // a business doesn't send Snaps
        b.textContent = !snap ? 'Post' : (feed ? 'Post & send' : 'Send');
        q('[data-feedbox]').hidden = !snap;
        q('[data-aud]').hidden = snap && !feed;
        q('[data-chips]').innerHTML = to.map(function (t, i) { return '<span class="tmo-chip">' + esc(t.name) + (t.kind === 'group' ? ' (group)' : '') + '<button type="button" data-untok="' + i + '" aria-label="Take ' + esc(t.name) + ' off">' + IC.x + '</button></span>'; }).join('');
        toq.placeholder = snap ? 'Add someone' : 'Your feed, or people and groups';
      }
      if (q('[data-as]')) q('[data-as]').addEventListener('change', function (e) {
        if (media.length) { say('Take off the photos and videos first: they were added for ' + (as ? 'the business' : 'you') + '.', e.target, true); e.target.value = String(as); return; }
        as = +e.target.value; if (as) { to = []; feed = false; } audOpts(); label(); lim();
      });
      q('[data-chips]').addEventListener('click', function (e) { var x = e.target.closest('[data-untok]'); if (x) { to.splice(+x.getAttribute('data-untok'), 1); label(); toq.focus(); } });
      q('[data-feed]').addEventListener('change', function (e) { feed = e.target.checked; label(); });
      toq.addEventListener('input', function () {
        clearTimeout(tq); var v = toq.value.trim();
        tq = setTimeout(function () {
          get('to=' + encodeURIComponent(v)).then(function (r) {
            var list = r.to.filter(function (x) { return !to.some(function (t) { return t.kind === x.kind && t.id === x.id; }); });
            sug.innerHTML = (list.length ? list.map(function (x, i) { return '<button type="button" role="option" data-pick-to="' + i + '"' + (x.ok ? '' : ' disabled') + '>' + esc(x.name) + (x.kind === 'group' ? ' (group)' : '') + (x.why ? '<small>' + esc(x.why) + '</small>' : '') + '</button>'; }).join('')
              : '<button type="button" disabled>' + (v.length < 2 ? 'Type a name' : 'No one by that name on Traversence yet') + '</button>')
              + (v.length >= 2 ? '<button type="button" data-invite>Invite “' + esc(v) + '” to Traversence<small>By email or phone. Once they join, you\'re asked to connect, and they\'ll be here.</small></button>' : '');
            sug.hidden = false;
            sug.onclick = function (e) {
              if (e.target.closest('[data-invite]')) { sug.hidden = true; invite(v, toq); return; }
              var b = e.target.closest('[data-pick-to]'); if (!b || b.disabled) return; var x = list[+b.getAttribute('data-pick-to')]; to.push({ kind: x.kind, id: x.id, name: x.name }); toq.value = ''; sug.hidden = true; label(); toq.focus(); };
          }).catch(function () { sug.hidden = true; });
        }, 200);
      });
      // someone not on Traversence: the Address Book's invite (an email with a link; for a phone, a message and link to send yourself)
      function invite(name, at) {
        if (!window.TvAsk) return;
        TvAsk.ask('Invite ' + name + ': their email address or phone number', /@|\d{7}/.test(name) ? name : '', { yes: 'Invite' }).then(function (c) {
          if (!c || !c.trim()) return;
          csrf().then(function (t) {
            return fetch('/user/api/people.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': t }, body: JSON.stringify(window.tvSafe ? tvSafe({ action: 'invite', contact: c.trim() }) : { action: 'invite', contact: c.trim() }) });
          }).then(function (r) { return r.json().catch(function () { return { ok: false }; }); }).then(function (r) {
            if (!r.ok) throw new Error((r.error && r.error.message) || 'The invite didn\'t go. Try again, or invite them from Contacts in your Address Book.');
            if (r.sent === 'phone' && r.text) { toq.value = ''; textInvite(name, c.trim(), r.text); return; }   // we don't send texts: the member sends it
            toq.value = ''; say('Invited. Once ' + name + ' joins, you\'re asked to connect, and they\'ll show on the To line.', at);
          }).catch(function (x) { say(x.message, at, true); });
        });
      }
      // a phone invite: our own panel with the message, Copy, and on a phone "Text it" (opens Messages with it filled in), never the
      // computer's share sheet (Jason, 2026-11-11: "weird popup after sending invite")
      function textInvite(name, phone, text) {
        var digits = phone.replace(/[^\d+]/g, ''), mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
        var ov = el('<div class="tmo-ov" role="dialog" aria-modal="true" aria-label="Text your invite"><div class="tmo"><div class="tmo-card"><p><b>Send ' + esc(name) + ' this in a text.</b> We don\'t send texts ourselves.</p>'
          + '<textarea class="tmo-in" rows="4" readonly style="width:100%;margin:.5rem 0">' + esc(text) + '</textarea><div class="tmo-tools">'
          + (mobile ? '<a class="tmo-b go" href="sms:' + esc(digits) + (/iPhone|iPad|iPod/i.test(navigator.userAgent) ? '&' : '?') + 'body=' + encodeURIComponent(text) + '">Text it</a>' : '')
          + '<button type="button" class="tmo-b' + (mobile ? '' : ' go') + '" data-copy>Copy the message</button><span style="flex:1"></span><button type="button" class="tmo-b" data-done>Done</button></div>'
          + '<p class="tmo-note">Once ' + esc(name) + ' joins with the link, you\'re asked to connect, and they\'ll show on the To line.</p></div></div></div>');
        document.body.appendChild(ov);
        function shut() { ov.remove(); }
        ov.addEventListener('click', function (e) { if (e.target === ov || e.target.closest('[data-done]')) shut(); });
        ov.querySelector('[data-copy]').addEventListener('click', function (e) {
          var b = e.currentTarget, ta = ov.querySelector('textarea');
          (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).catch(function () { ta.select(); document.execCommand && document.execCommand('copy'); })
            .then(function () { say('Copied. Paste it in a text to ' + name + '.', b); });
        });
      }
      toq.addEventListener('focus', function () { toq.dispatchEvent(new Event('input')); });
      toq.addEventListener('blur', function () { setTimeout(function () { sug.hidden = true; }, 200); });
      label();
      function open() { host.querySelector('.tmo-open').hidden = true; form.hidden = false; ta.focus(); }
      function close() { form.hidden = true; host.querySelector('.tmo-open').hidden = false; ta.value = ''; media = []; paint(); to = (opts.to || []).slice(); feed = false; q('[data-feed]').checked = false; label(); if (opts.onClose) opts.onClose(); }
      q('.tmo-say').addEventListener('click', open);
      q('[data-cancel]').addEventListener('click', close);
      q('[data-aud]').addEventListener('change', function (e) { aud = e.target.value; });
      q('[data-win]').addEventListener('change', function (e) { win = +e.target.value; lim(); });
      q('[data-keep]').addEventListener('change', function (e) { keep = e.target.checked; q('[data-win]').disabled = keep; lim(); });
      q('[data-pick]').addEventListener('click', function () { file.click(); });
      file.addEventListener('change', function () { var f = Array.prototype.slice.call(file.files || []); file.value = ''; add(f, q('[data-pick]')); });
      q('[data-rec]').addEventListener('click', function () { recorder(as ? 600 : d.limits.secs).then(function (f) { if (f) add([f], q('[data-rec]')); }); });
      function paint() {
        strip.innerHTML = '';
        media.forEach(function (m, i) {
          var t = el('<div class="tmo-th" style="background-image:url(\'' + esc(m.card) + '\')"><button type="button" aria-label="Take it off">' + IC.x + '</button>' + (m.kind === 'video' ? '<i>' + mmss(m.secs) + '</i>' : '') + '</div>');
          t.querySelector('button').addEventListener('click', function () { media.splice(i, 1); paint(); });
          strip.appendChild(t);
        });
      }
      function add(files, at) {
        if (!files.length) return;
        if (!window.TvUpload) { say('Uploads aren\'t ready on this page yet. Reload and try again.', at, true); return; }
        var big = files.filter(function (f) { return /^video/.test(f.type) && f.size > d.limits.mb * 1048576; });
        if (big.length) { say(big[0].name + ' is over ' + d.limits.mb + ' MB. Record it here instead (2 minutes at most, made small as it records), or trim it first.', at, true); return; }
        sending++;
        TvUpload.send(files, { target: 'moment', ctx: as ? { b: as } : {}, el: strip, inside: false, ask: false, shrink: function (f) { return /^image/.test(f.type) ? 2000 : 0; },
          extra: function (f) { return /^video/.test(f.type) ? TvUpload.poster(f).then(function (p) { return p ? { poster: p.data, secs: p.secs, w: p.w, h: p.h } : {}; }).catch(function () { return {}; }) : {}; } })
          .then(function (res) { (res || []).forEach(function (r) { if (r && r.media && r.media.id) media.push(r.media); }); paint(); })
          .catch(function (e) { say(e.message || 'That didn\'t upload. Try again.', at, true); })
          .then(function () { sending--; });
      }
      q('[data-post]').addEventListener('click', function () {
        var b = q('[data-post]');
        if (sending) { say('Wait for the photos and videos to finish sending.', b, true); return; }
        if (!ta.value.trim() && !media.length) { say('Write something, or add a photo or video.', b, true); return; }
        busy(b, true);
        var snap = to.length > 0, ends = win === 168 ? '7 days' : '3 days';
        send({ action: 'post', body: ta.value, media: media.map(function (m) { return m.id; }), audience: aud, window: win, keep: keep, to: as ? [] : to.map(function (t) { return { kind: t.kind, id: t.id }; }), feed: feed, as: as,
               tz: window.TvTime ? TvTime.zone() : (Intl.DateTimeFormat().resolvedOptions().timeZone || '') })
          .then(function (r) {
            busy(b, false);
            var s = r.post.sent, msg = !snap ? (keep ? 'Posted and kept.' : 'Posted. It ends in ' + ends + ' unless you Keep it.')
              : (s && s.to.length ? 'Sent to ' + s.to.join(', ') + (feed ? ', and posted to your feed' : '') + '.' : 'Not sent.') + (s && s.failed.length ? ' Not sent to ' + s.failed.map(function (f) { return f.name + ' (' + f.why + ')'; }).join('; ') + '.' : '') + (keep ? '' : ' It ends in ' + ends + ' unless one of you keeps it.');
            var bad = !!(s && s.failed.length && !s.to.length);
            close(); say(msg, host.querySelector('.tmo-open'), bad); meP = null; me().then(function (n) { if (n) { d.limits = n.limits; lim(); } });
            if (!snap || feed) document.dispatchEvent(new CustomEvent('tvm:posted', { detail: r.post }));
            if (opts.onSent) opts.onSent(r.post, msg);
          })
          .catch(function (e) { busy(b, false); say(e.message, b, true); });
      });
      if (opts.openNow) open();
    });
  }

  // ---- the recorder: full screen, controls over the picture. Choose the frame first (Portrait 9:16, Square, Landscape
  // 16:9): what's inside it is exactly what's recorded (drawn to a canvas, so a phone's landscape camera still makes a
  // portrait video). Tap to start, tap again to stop (or it stops at 0:00), then review it in the same frame: Retake or Use
  // video. × closes, asking first when there's something to lose. -------------------------------------------------------
  var FRAMES = [['tall', 9, 16, 'Portrait'], ['square', 1, 1, 'Square'], ['wide', 16, 9, 'Landscape']];
  function recorder(max) {
    max = max || 120;
    function upsell() { function go() { window.TvUpgrade.offer('record_long'); } if (window.TvUpgrade) { go(); return; } var sc = document.createElement('script'); sc.src = '/js/tv-upgrade.js'; sc.onload = go; document.head.appendChild(sc); }
    style();
    return new Promise(function (done) {
      if (!navigator.mediaDevices || !window.MediaRecorder) { say('This browser can\'t record here. Record with your camera app, then add it with Photo/video (2 minutes at most).', document.querySelector('[data-rec]'), true); done(null); return; }
      var facing = 'user', stream = null, rec = null, chunks = [], t0 = 0, timer = null, out = null, url = '', secs = 0, ended = false, raf = 0, cv = null, zoom = 1, caps = null;
      var frame = 'tall'; try { frame = localStorage.getItem('tmo-frame') || (window.innerHeight > window.innerWidth ? 'tall' : 'wide'); } catch (e) {}
      var C = 2 * Math.PI * 38;
      var box = el('<div class="tmo-rec" role="dialog" aria-modal="true" aria-label="Record a video"><div class="tmo-rec-f"><video playsinline muted autoplay></video></div>'
        + '<div class="tmo-rec-top"><span class="tmo-rec-t" aria-live="off"><i></i><b data-t>' + mmss(max) + '</b></span><button type="button" class="tmo-rec-x" data-x aria-label="Close">' + IC.x + '</button></div>'
        + '<div class="tmo-rec-bot" data-cam><p class="tmo-rec-hint" data-msg>Choose the frame, then tap the red button to record, up to ' + mmss(max) + '.</p>'
        + '<div class="tmo-rec-fr" role="group" aria-label="Frame">' + FRAMES.map(function (f) { return '<button type="button" data-fr="' + f[0] + '" aria-pressed="false">' + f[3] + '</button>'; }).join('') + '</div>'
        + '<div class="tmo-rec-row"><button type="button" class="tmo-rec-z" data-zoom aria-label="Zoom: 1×, tap for more, or pinch the picture" title="Zoom (or pinch the picture)">1×</button><button type="button" class="tmo-shut" data-go aria-label="Start recording"><svg viewBox="0 0 82 82"><circle cx="41" cy="41" r="38" fill="none" stroke="#fff" stroke-width="5"/>'
        + '<circle cx="41" cy="41" r="38" fill="none" stroke="#E5484D" stroke-width="5" stroke-linecap="round" stroke-dasharray="' + C + '" stroke-dashoffset="' + C + '" data-arc/></svg><span></span></button>'
        + '<button type="button" class="tmo-rec-i" data-flip aria-label="Switch camera" title="Switch camera">' + IC.flip + '</button></div></div>'
        + '<div class="tmo-rec-bot" data-rev hidden><p class="tmo-rec-hint" data-len></p><div class="tmo-rec-row"><button type="button" class="tmo-rec-b" data-again>Retake</button><span></span><button type="button" class="tmo-rec-b go" data-use>Use video</button></div></div>'
        + '<span class="tmo-rec-play" data-paused hidden>' + IC.play + '</span></div>');
      document.body.appendChild(box);
      var keepScroll = document.documentElement.style.overflow; document.documentElement.style.overflow = 'hidden';
      var q = function (x) { return box.querySelector(x); };
      var v = q('video'), fb = q('.tmo-rec-f'), go = q('[data-go]'), arc = q('[data-arc]'), tl = q('[data-t]'), msg = q('[data-msg]');
      function ratio() { for (var i = 0; i < FRAMES.length; i++) if (FRAMES[i][0] === frame) return FRAMES[i][1] / FRAMES[i][2]; return 9 / 16; }
      function fit() {   // the frame, as big as the screen allows
        var W = window.innerWidth, H = window.innerHeight, r = ratio(), w = W, h = W / r;
        if (h > H) { h = H; w = H * r; }
        fb.style.width = Math.round(w) + 'px'; fb.style.height = Math.round(h) + 'px';
        box.querySelectorAll('[data-fr]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-fr') === frame)); });
      }
      fit(); window.addEventListener('resize', fit);
      function stopAll() { if (timer) { clearInterval(timer); timer = null; } if (raf) { cancelAnimationFrame(raf); raf = 0; } if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; } }
      function finish(f) { stopAll(); window.removeEventListener('resize', fit); document.removeEventListener('keydown', key, true); document.documentElement.style.overflow = keepScroll; box.remove(); if (url && !f) URL.revokeObjectURL(url); done(f); }
      function cam() {
        if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
        return navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 30, max: 30 } }, audio: true })
          .then(function (s) {
            stream = s; v.srcObject = s; v.muted = true; v.play().catch(function () {});
            var tr = s.getVideoTracks()[0], c = tr && tr.getCapabilities ? tr.getCapabilities() : {};
            caps = c && c.zoom && c.zoom.max > 1 ? c.zoom : null;   // the camera's own zoom, where the browser offers it (sharp)
            zoom = 1; if (caps) tr.applyConstraints({ advanced: [{ zoom: Math.max(1, caps.min || 1) }] }).catch(function () {});
            look();
          })
          .catch(function () { msg.textContent = 'The camera or microphone isn\'t allowed. Allow them in your browser\'s site settings, or record with your camera app and add it with Photo/video.'; go.disabled = true; });
      }
      // zoom: the camera's own where offered, else the middle of the picture made bigger (digital, at most 3×)
      function zmax() { return caps ? Math.min(caps.max, 8) : 3; }
      function look() {
        v.style.transform = (facing === 'user' && !box.classList.contains('review') ? 'scaleX(-1) ' : '') + (!caps && !box.classList.contains('review') && zoom > 1 ? 'scale(' + zoom + ')' : '');
        var zb = q('[data-zoom]'); zb.textContent = (Math.round(zoom * 10) / 10) + '×'; zb.setAttribute('aria-label', 'Zoom: ' + zb.textContent + ', tap for more, or pinch the picture');
      }
      function setZoom(z) {
        zoom = Math.max(caps ? Math.max(1, caps.min || 1) : 1, Math.min(zmax(), z));
        if (caps && stream) { var tr = stream.getVideoTracks()[0]; tr.applyConstraints({ advanced: [{ zoom: zoom }] }).catch(function () { caps = null; look(); }); }
        look();
      }
      function type() { var c = ['video/mp4;codecs=avc1,mp4a', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']; for (var i = 0; i < c.length; i++) if (MediaRecorder.isTypeSupported(c[i])) return c[i]; return ''; }
      // the frame drawn to a canvas: the middle of the camera's picture cut to the frame (as on screen), at most 1280 px long
      function framed() {
        cv = document.createElement('canvas');
        if (!cv.captureStream) { cv = null; return null; }
        var sw = v.videoWidth || 1280, sh = v.videoHeight || 720, r = ratio(), cw = sw, ch = sw / r;
        if (ch > sh) { ch = sh; cw = sh * r; }
        var k = Math.min(1, 1280 / Math.max(cw, ch));
        cv.width = Math.round(cw * k / 2) * 2; cv.height = Math.round(ch * k / 2) * 2;
        var g = cv.getContext('2d');
        (function draw() {   // the frame, made bigger by a digital zoom (the camera's own zoom is already in the picture); worked
          // out from the picture each time, so a camera switched mid-recording (another size) fills the frame the same way
          var vw = v.videoWidth, vh = v.videoHeight;
          if (vw && vh) {
            var fw = vw, fh = vw / r; if (fh > vh) { fh = vh; fw = vh * r; }
            var z = caps ? 1 : zoom, zw = fw / z, zh = fh / z;
            try { g.drawImage(v, (vw - zw) / 2, (vh - zh) / 2, zw, zh, 0, 0, cv.width, cv.height); } catch (e) {}
          }
          raf = requestAnimationFrame(draw);
        })();
        var cs = cv.captureStream(30);
        stream.getAudioTracks().forEach(function (t) { cs.addTrack(t); });
        return cs;
      }
      function start() {
        if (!stream) return;
        var t = type(), src = framed() || stream; chunks = []; ended = false;
        q('[data-flip]').classList.toggle('still', src === stream);   // switching cameras while recording needs the drawn frame
        try { rec = new MediaRecorder(src, t ? { mimeType: t, videoBitsPerSecond: 1200000, audioBitsPerSecond: 64000 } : { videoBitsPerSecond: 1200000 }); } catch (e) { msg.textContent = 'Recording couldn\'t start. Try again.'; return; }
        rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
        rec.onstop = function () {
          if (ended) return; ended = true;
          secs = Math.min(max, (Date.now() - t0) / 1000);
          var mt = (rec.mimeType || t || 'video/webm').split(';')[0];
          out = new File(chunks, 'moment-' + Date.now() + '.' + (/mp4/.test(mt) ? 'mp4' : 'webm'), { type: mt });
          stopAll(); review();
        };
        rec.start(1000); t0 = Date.now();
        box.classList.add('on'); go.setAttribute('aria-label', 'Stop recording'); msg.textContent = 'Tap to stop.';
        timer = setInterval(function () {
          var s = (Date.now() - t0) / 1000, rem = max - s;
          tl.textContent = mmss(rem); arc.setAttribute('stroke-dashoffset', String(C * (1 - Math.min(1, s / max))));
          if (rem <= 0) { stop(); if (max < 600) upsell(); }   // past 2:00: Pro records up to 10 minutes, beside keeping these 2 (decisions/0154 §5)
        }, 200);
      }
      function stop() { if (timer) { clearInterval(timer); timer = null; } if (rec && rec.state !== 'inactive') rec.stop(); }
      function review() {   // the recording in the same frame it was taken in
        box.classList.remove('on'); box.classList.add('review'); box.setAttribute('aria-label', 'Your video');
        q('[data-cam]').hidden = true; q('[data-rev]').hidden = false;
        tl.textContent = mmss(secs); q('[data-len]').textContent = mmss(secs) + ' recorded. Watch it back, then use it or retake it.';
        url = URL.createObjectURL(out);
        v.srcObject = null; v.style.transform = ''; v.muted = false; v.loop = true; v.src = url; v.play().catch(function () { q('[data-paused]').hidden = false; });
      }
      v.addEventListener('click', function () { if (!box.classList.contains('review')) return; if (v.paused) { v.play(); q('[data-paused]').hidden = true; } else { v.pause(); q('[data-paused]').hidden = false; } });
      go.addEventListener('click', function () { if (!rec || rec.state === 'inactive') start(); else stop(); });
      box.querySelectorAll('[data-fr]').forEach(function (b) { b.addEventListener('click', function () { if (rec && rec.state === 'recording') return; frame = b.getAttribute('data-fr'); try { localStorage.setItem('tmo-frame', frame); } catch (e) {} fit(); }); });
      q('[data-zoom]').addEventListener('click', function () { var m = zmax(), steps = [1, 2, 3, 5, 8].filter(function (x) { return x <= m; }); var n = steps.filter(function (x) { return x > zoom + .05; })[0]; setZoom(n || steps[0]); });
      var pinch = null;   // two fingers on the picture zoom in and out
      box.addEventListener('touchstart', function (e) { if (e.touches.length === 2 && !box.classList.contains('review')) pinch = { d: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), z: zoom }; }, { passive: true });
      box.addEventListener('touchmove', function (e) { if (pinch && e.touches.length === 2) { e.preventDefault(); setZoom(pinch.z * Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY) / pinch.d); } }, { passive: false });
      box.addEventListener('touchend', function (e) { if (e.touches.length < 2) pinch = null; });
      box.addEventListener('wheel', function (e) { if (box.classList.contains('review')) return; e.preventDefault(); setZoom(zoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1)); }, { passive: false });
      // switch cameras, also while recording: only the picture changes; the microphone and the recording carry on as one clip
      // (the recording is drawn from the picture, so the new camera simply takes over the drawing)
      var swapping = false;
      q('[data-flip]').addEventListener('click', function () {
        facing = facing === 'user' ? 'environment' : 'user';
        if (!(rec && rec.state === 'recording')) { cam(); return; }
        if (swapping || !cv || !stream) { facing = facing === 'user' ? 'environment' : 'user'; return; }
        swapping = true;
        stream.getVideoTracks().forEach(function (t) { t.stop(); stream.removeTrack(t); });   // many phones can't open both cameras at once
        navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 30, max: 30 } } })
          .then(function (s2) {
            var tr = s2.getVideoTracks()[0]; stream.addTrack(tr);
            v.srcObject = new MediaStream([tr]); v.muted = true; v.play().catch(function () {});
            var c = tr.getCapabilities ? tr.getCapabilities() : {}; caps = c && c.zoom && c.zoom.max > 1 ? c.zoom : null; zoom = 1; look();
          })
          .catch(function () { facing = facing === 'user' ? 'environment' : 'user'; msg.textContent = 'That camera couldn\'t be opened. Tap to stop, or keep recording.'; })
          .then(function () { swapping = false; });
      });
      q('[data-again]').addEventListener('click', function () {
        v.pause(); v.removeAttribute('src'); v.load(); if (url) { URL.revokeObjectURL(url); url = ''; } out = null; rec = null;
        box.classList.remove('review'); box.setAttribute('aria-label', 'Record a video'); q('[data-rev]').hidden = true; q('[data-cam]').hidden = false; q('[data-paused]').hidden = true;
        tl.textContent = mmss(max); arc.setAttribute('stroke-dashoffset', String(C)); go.setAttribute('aria-label', 'Start recording'); msg.textContent = 'Choose the frame, then tap the red button to record, up to ' + mmss(max) + '.';
        cam();
      });
      q('[data-use]').addEventListener('click', function () { v.pause(); finish(out); });
      function closeAsk() {
        var busy = (rec && rec.state === 'recording') || out;
        if (!busy || !window.TvAsk) { if (rec && rec.state === 'recording') { ended = true; rec.stop(); } finish(null); return; }
        TvAsk.confirm('Throw this video away?', { yes: 'Throw it away', no: 'Keep going', danger: true }).then(function (ok) {
          if (ok) { if (rec && rec.state !== 'inactive') { ended = true; rec.stop(); } finish(null); }
        });
      }
      q('[data-x]').addEventListener('click', closeAsk);
      function key(e) { if (e.key === 'Escape') { e.stopPropagation(); closeAsk(); } }
      document.addEventListener('keydown', key, true);
      cam();
    });
  }

  // ---- the feed ------------------------------------------------------------------------------------------------------
  var seenQ = [], seenT = null, seenIO = null;
  function markSeen(id) {
    seenQ.push(id);
    if (seenT) return;
    seenT = setTimeout(function () { var ids = seenQ.splice(0); seenT = null; if (ids.length && ME) send({ action: 'seen', ids: ids }).catch(function () {}); }, 2000);
  }
  function watch(card, p) {
    if (p.mine || p.preview || !('IntersectionObserver' in window)) return;
    if (!seenIO) seenIO = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting && e.intersectionRatio > .5) { seenIO.unobserve(e.target); markSeen(+e.target.getAttribute('data-post')); } }); }, { threshold: [.5] });
    seenIO.observe(card);
  }
  function rxSummary(p) {
    var keys = Object.keys(p.reactions || {}).sort(function (a, b) { return p.reactions[b] - p.reactions[a]; }), n = 0;
    keys.forEach(function (k) { n += p.reactions[k]; });
    return n ? '<span class="rx">' + keys.slice(0, 3).map(function (k) { return '<span title="' + NAMES[k] + '">' + svg(REACT[k]) + '</span>'; }).join('') + ' ' + n + '</span>' : '<span></span>';
  }
  function mediaHtml(p, grid) {
    var m = p.media || []; if (!m.length) return '';
    return '<div class="' + (grid ? 'tmo-grid' : 'tmo-media n' + Math.min(m.length, 2)) + '">' + m.map(function (x, i) {
      return '<button type="button" class="tmo-m" data-m="' + i + '" aria-label="' + (x.kind === 'video' ? 'Play the video' : 'Open the photo') + '" style="background-image:url(\'' + esc(x.blur || '') + '\')"><img loading="lazy" alt="" src="' + esc(m.length === 1 && !grid ? x.full : x.card) + '">'
        + (x.kind === 'video' ? '<span class="tmo-play"><span>' + IC.play + '</span></span>' + (x.secs ? '<span class="tmo-len">' + mmss(x.secs) + '</span>' : '') : '') + '</button>';
    }).join('') + '</div>';
  }
  function card(p) {
    var c = el('<article class="tmo-card tv-bleed" data-post="' + p.id + '"></article>');
    function paint() {
      var o = p.owner, tag = !p.mine ? '' : p.kept ? '<span class="tmo-tag">' + IC.keep + 'Kept</span>' : (p.ends ? '<span class="tmo-tag end" title="It\'s deleted when it ends, unless kept">' + esc(left(p.ends)) + '</span>' : '');
      c.innerHTML = '<div class="tmo-h"><a class="tmo-av" href="' + esc(o.url) + '" aria-label="' + esc(o.name) + '"' + (o.avatar ? ' style="background-image:url(\'' + esc(o.avatar) + '\')"' : '') + '>' + (o.avatar ? '' : esc(o.name.charAt(0).toUpperCase())) + '</a>'
        + '<div class="tmo-who"><a href="' + esc(o.url) + '">' + esc(o.name) + '</a><div class="tmo-sub"><a href="' + esc(p.url) + '" style="color:inherit"><time datetime="' + esc(p.at) + '">' + esc(when(p.at, p.tz)) + '</time></a>'
        + '<span title="' + esc(p.audience_label) + '" aria-label="Shared with: ' + esc(p.audience_label) + '">' + (AUD_IC[p.audience] || '') + '</span>' + (p.edited ? '<span>Edited</span>' : '') + tag + (p.pinned ? '<span class="tmo-tag">Pinned</span>' : '') + (p.held ? '<span class="tmo-tag end">Hidden while it\'s looked at</span>' : '') + '</div></div>'
        + (ME && !p.preview ? '<button type="button" class="tmo-i" data-more title="More" aria-label="More">' + IC.more + '</button>' : '') + '</div>'
        + (p.snap ? '<p class="tmo-snapto">' + (p.mine && p.to ? 'Sent to ' + esc(p.to.map(function (t) { return t.name + (t.kept ? ' (kept it)' : ''); }).join(', ')) : 'Sent to you') + (p.shareable ? '' : ' · just between you') + '</p>' : '')
        + (p.body ? '<div class="tmo-body">' + esc(p.body) + '</div>' : '') + mediaHtml(p, false)
        + '<div class="tmo-sum">' + rxSummary(p) + '<span>' + (p.comments ? '<button type="button" class="tmo-a" style="flex:none;padding:0;font-weight:500" data-com>' + p.comments + ' comment' + (p.comments === 1 ? '' : 's') + '</button>' : '')
        + (p.mine ? ' <button type="button" class="tmo-a" style="flex:none;padding:0 0 0 .5rem;font-weight:500" data-views>' + IC.eye + ' Seen by ' + (p.views || 0) + '</button>' : '') + '</span></div>'
        + (p.preview ? '<p class="tmo-note" style="text-align:center">Preview: visitors can like, comment and share here.</p><div class="tmo-acts" hidden>' : '<div class="tmo-acts">') + (ME ? '<button type="button" class="tmo-a' + (p.reacted ? ' on' : '') + '" data-react aria-label="React">' + svg(REACT[p.reacted || 'like']) + esc(p.reacted ? NAMES[p.reacted] : 'Like') + '</button>' : '')
        + (p.can_comment || p.comments ? '<button type="button" class="tmo-a" data-com>' + IC.comment + 'Comment</button>' : '')
        + (p.shareable !== false ? '<button type="button" class="tmo-a" data-share>' + IC.share + 'Share</button>' : '') + ((p.mine || p.can_keep) && !p.kept ? '<button type="button" class="tmo-a" data-keep title="Keep it: it stays, and its photos and videos go into your Gallery">' + IC.keep + 'Keep</button>' : '') + '</div>'
        + '<div class="tmo-com" hidden></div>';
    }
    paint();
    c.addEventListener('click', function (e) {
      var t = e.target.closest('button,[data-m]'); if (!t || !c.contains(t)) return;
      if (t.hasAttribute('data-m')) return openMedia(t, p.media[+t.getAttribute('data-m')]);
      if (t.hasAttribute('data-react')) return react(t);
      if (t.hasAttribute('data-com')) return comments();
      if (t.hasAttribute('data-share')) return share(t);
      if (t.hasAttribute('data-keep')) return keep(t);
      if (t.hasAttribute('data-views')) return viewers(t);
      if (t.hasAttribute('data-more')) return more(t);
    });
    function update(np) { p = np; paint(); }
    function react(b) {
      var pick = el('<div class="tmo-pick" role="menu" aria-label="React"></div>');
      Object.keys(REACT).forEach(function (k) { var x = el('<button type="button" title="' + NAMES[k] + '" aria-label="' + NAMES[k] + '"' + (p.reacted === k ? ' class="on"' : '') + '>' + svg(REACT[k], 1.6) + '</button>'); x.addEventListener('click', function (e) { e.stopPropagation(); pick.remove(); go(k); }); pick.appendChild(x); });
      document.querySelectorAll('.tmo-pick').forEach(function (x) { x.remove(); });
      document.body.appendChild(pick);
      var r = b.getBoundingClientRect(); pick.style.top = Math.max(8, r.top - pick.offsetHeight - 6) + 'px'; pick.style.left = Math.max(8, Math.min(r.left, document.documentElement.clientWidth - pick.offsetWidth - 8)) + 'px';
      function poff() { pick.remove(); document.removeEventListener('click', poff); window.removeEventListener('scroll', poff, true); }
      setTimeout(function () { document.addEventListener('click', poff); window.addEventListener('scroll', poff, true); }, 0);
      function go(k) {
        send({ action: 'react', id: p.id, reaction: k }).then(function (d) { p.reactions = d.reactions; p.reacted = d.reacted; paint(); })
          .catch(function (e) { say(e.message, b, true); });
      }
    }
    function comments() {
      var box = c.querySelector('.tmo-com');
      if (!box.hidden && box.getAttribute('data-loaded')) { box.hidden = true; return; }
      box.hidden = false; box.innerHTML = '<p class="tmo-note">Loading…</p>';
      get('comments=' + p.id).then(function (d) {
        box.setAttribute('data-loaded', '1');
        box.innerHTML = d.comments.map(function (x) {
          return '<div class="tmo-c"><div class="tmo-cb"><b>' + esc(x.name) + '</b><p>' + esc(x.body) + '</p></div>' + (x.can_remove ? '<button type="button" class="tmo-i" data-unc="' + x.id + '" title="Remove" aria-label="Remove this comment">' + IC.x + '</button>' : '') + '</div>';
        }).join('') + (p.can_comment ? '<form class="tmo-cf"><input class="tmo-in" maxlength="2000" placeholder="Write a comment" aria-label="Write a comment" data-spell><button class="tmo-b go">Send</button></form>' : '<p class="tmo-note">' + (p.comments_from === 'off' ? 'Comments are off on this post.' : 'Only the poster\'s connections can comment.') + '</p>');
        var f = box.querySelector('form');
        if (f) f.addEventListener('submit', function (e) {
          e.preventDefault(); var i = f.querySelector('input'), b = f.querySelector('button'); if (!i.value.trim()) return;
          busy(b, true);
          send({ action: 'comment', id: p.id, body: i.value }).then(function () { busy(b, false); p.comments++; box.removeAttribute('data-loaded'); box.hidden = true; paint(); comments(); })
            .catch(function (er) { busy(b, false); say(er.message, b, true); });
        });
        box.querySelectorAll('[data-unc]').forEach(function (b) {
          b.addEventListener('click', function (e) {
            e.stopPropagation();
            if (!window.TvAsk || !TvAsk.gate(b, 'Remove this comment?', { yes: 'Remove', danger: true })) return;
            send({ action: 'uncomment', comment: +b.getAttribute('data-unc') }).then(function () { p.comments = Math.max(0, p.comments - 1); box.removeAttribute('data-loaded'); box.hidden = true; paint(); comments(); }).catch(function (er) { say(er.message, b, true); });
          });
        });
      }).catch(function (e) { box.innerHTML = '<p class="tmo-note">' + esc(e.message) + '</p>'; });
    }
    function share(b) {
      var url = location.origin + p.url;
      if (navigator.share) { navigator.share({ title: p.owner.name + ' on Traversence', url: url }).catch(function () {}); return; }
      (navigator.clipboard ? navigator.clipboard.writeText(url) : Promise.reject()).then(function () { say('Link copied. ' + (p.audience === 'public' ? 'Anyone with it can see the post.' : 'Only the people it\'s shared with can open it.'), b); })
        .catch(function () { if (window.TvAsk) TvAsk.ask('The post\'s link', url); });
    }
    function keep(b) {
      busy(b, true);
      send({ action: 'keep', id: p.id }).then(function (d) { busy(b, false); update(d.post); say(d.message, c.querySelector('.tmo-acts')); })
        .catch(function (e) { busy(b, false); say(e.message, b, true); });
    }
    function viewers(b) {
      busy(b, true);
      get('viewers=' + p.id).then(function (d) {
        busy(b, false);
        var v = d.viewers, names = v.named.map(function (x) { return x.name; });
        say(!v.total ? 'No one has seen it yet.' : (names.length ? names.slice(0, 12).join(', ') + (names.length > 12 ? ' and ' + (names.length - 12) + ' more you know' : '') + (v.others ? ', and ' + v.others + ' other' + (v.others === 1 ? '' : 's') : '') : v.others + ' people') + ' saw it. Names show for people in your Address Book or who follow you, or you follow.', b, false);
      }).catch(function (e) { busy(b, false); say(e.message, b, true); });
    }
    function edit(field, value, b) {
      var body = { action: 'edit', id: p.id }; body[field] = value;
      return send(body).then(function (d) { update(d.post); say('Saved.', c.querySelector('.tmo-h')); }).catch(function (e) { say(e.message, b, true); });
    }
    function more(b) {
      var items;
      if (p.mine) {
        items = [
          !p.kept ? { t: 'Keep it', s: 'It stays, and its photos and videos go into your Gallery', go: function () { keep(b); } } : null,
          p.keep4k && p.keep4k.length ? { t: 'Keep in 4K · $0.99', s: 'Keeps the post with its video at full size, not your plan\'s smaller copy. Paid in your cart', go: function () {   // decisions/0154 §5
            csrf().then(function (t) { return fetch('/api/go-codes.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': t }, body: JSON.stringify({ action: 'keep4k_add', media: p.keep4k[0] }) }); })
              .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.'); location.href = '/qr/cart.php'; })
              .catch(function (x) { say(x.message, b, true); }); } } : null,
          { t: 'Edit the words', go: function () { if (window.TvAsk) TvAsk.ask('Your post', p.body, { multiline: true, yes: 'Save' }).then(function (v) { if (v !== null) edit('body', v, b); }); } },
          { t: 'Who sees it: ' + p.audience_label, go: function () { choose(b, 'Who sees it', (ME && ME.audiences) || [], p.audience).then(function (a) { edit('audience', a, b); }); } },
          !p.kept ? { t: 'Lasts: ' + (p.window === 168 ? '7 days' : '3 days'), s: 'From when you posted it', go: function () { choose(b, 'How long it lasts', [[72, '3 days'], [168, '7 days']], p.window).then(function (w) { edit('window', w, b); }); } } : null,
          { t: p.pinned ? 'Unpin from your profile' : 'Pin to your profile', s: p.pinned ? '' : 'It shows first on your Posts', go: function () { edit('pinned', !p.pinned, b); } },
          { t: 'Who can comment', go: function () { choose(b, 'Who can comment', (ME && ME.comments_from) || [], p.comments_from).then(function (w) { edit('comments_from', w, b); }); } },
          { t: 'Who reacted', go: function () { get('reactors=' + p.id).then(function (d) { var r = d.reactors; say(r.named.length || r.others ? r.named.map(function (x) { return x.name + ' (' + NAMES[x.reaction] + ')'; }).join(', ') + (r.others ? (r.named.length ? ', and ' : '') + r.others + ' other' + (r.others === 1 ? '' : 's') : '') : 'No reactions yet.', b); }).catch(function (e) { say(e.message, b, true); }); } },
          p.edited ? { t: 'Edit history', go: function () { get('history=' + p.id).then(function (d) { say(d.history.map(function (h) { return when(h.edited_at.replace(' ', 'T')) + ': ' + (h.body || '(no words)'); }).join('\n') || 'No earlier versions.', b); }); } } : null,
          { t: 'Delete', bad: true, go: function () { if (window.TvAsk) TvAsk.confirm('Delete this post now? Its photos and videos go too, unless you kept it (kept ones stay in your Gallery).', { anchor: b, yes: 'Delete', danger: true }).then(function (ok) { if (!ok) return; send({ action: 'delete', id: p.id }).then(function () { c.remove(); }).catch(function (e) { say(e.message, b, true); }); }); } }
        ];
      } else {
        items = [
          p.can_keep && !p.kept ? { t: 'Keep it', s: 'It stays, and its photos and videos go into your Gallery', go: function () { keep(b); } } : null,
          p.shareable !== false ? { t: 'Copy the link', go: function () { share(b); } } : null,
          { t: 'Report it', s: 'Our team looks at it; the person isn\'t told who reported it', go: function () { choose(b, 'Why?', REASONS, '').then(function (why) { send({ action: 'report', id: p.id, reason: why, note: '' }).then(function (d) { say(d.message, b); }).catch(function (e) { say(e.message, b, true); }); }); } }
        ];
      }
      menu(b, items);
    }
    watch(c, p);
    return c;
  }
  function openMedia(t, m) {
    if (!m) return;
    if (m.kind === 'video') {
      var v = document.createElement('video'); v.controls = true; v.playsInline = true; v.preload = 'metadata'; v.src = m.video; v.poster = m.full;
      if (!m.hd) { t.replaceWith(v); v.play().catch(function () {}); return; }
      // Watch in 4K (or HD): feeds play the 720p copy; the original is a tap away, from where it was (decisions/0153 §8)
      var w = document.createElement('div'); w.className = 'tmo-vw'; w.appendChild(v);
      var hb = el('<button type="button" class="tmo-b tmo-hd" aria-pressed="false">Watch in ' + esc(m.hd_label || 'HD') + '</button>'); w.appendChild(hb);
      hb.addEventListener('click', function () { var at = v.currentTime, on = hb.getAttribute('aria-pressed') !== 'true'; v.src = on ? m.hd : m.video; hb.setAttribute('aria-pressed', on ? 'true' : 'false');
        hb.textContent = on ? 'Back to the smaller copy' : 'Watch in ' + (m.hd_label || 'HD'); v.addEventListener('loadedmetadata', function f() { v.removeEventListener('loadedmetadata', f); try { v.currentTime = at; } catch (e) {} v.play().catch(function () {}); }); });
      t.replaceWith(w); v.play().catch(function () {}); return;
    }
    var lb = el('<div class="tmo-lb" role="dialog" aria-modal="true" aria-label="Photo"><img alt="" src="' + esc(m.full) + '"><button type="button" class="tmo-i" aria-label="Close">' + IC.x + '</button></div>');
    function off() { lb.remove(); document.removeEventListener('keydown', key); }
    function key(e) { if (e.key === 'Escape') off(); }
    lb.addEventListener('click', function (e) { if (e.target === lb || e.target.closest('button')) off(); });
    document.addEventListener('keydown', key);
    document.body.appendChild(lb);
  }

  function feed(host, o) {
    style(); o = o || {};
    host.classList.add('tmo');
    var grid = false; try { grid = localStorage.getItem('tmo-grid') === '1'; } catch (e) {}
    var oldest = 0, posts = [];
    host.innerHTML = '<div class="tmo-top tv-bleed"><h2>Posts</h2><button type="button" class="tmo-i" data-lay title="List or grid" aria-label="Show as a list or a grid">' + (grid ? IC.list : IC.grid) + '</button></div><div data-list></div><p class="tmo-note" data-foot></p>';
    var list = host.querySelector('[data-list]'), foot = host.querySelector('[data-foot]');
    function paint() {
      list.innerHTML = '';
      host.hidden = !posts.length && !!o.hideEmpty && !o.self;   // a business with no posts shows nothing to its visitors
      if (!posts.length) { list.innerHTML = '<p class="tmo-empty tmo-card tv-bleed">' + (o.self ? 'Nothing posted yet. ' + (o.business ? 'The business\'s posts show here' : 'Your posts show here') + ': each lasts 3 or 7 days, unless you Keep it.' : (o.as ? 'Nothing they could see.' : 'Nothing shared with you yet.')) + '</p>'; return; }
      if (grid) {
        var g = el('<div class="tmo-grid tv-bleed"></div>');
        posts.forEach(function (p) { (p.media || []).forEach(function (m) { var b = el('<button type="button" class="tmo-m" style="background-image:url(\'' + esc(m.card) + '\')" aria-label="Open the post"></button>'); if (m.kind === 'video') b.innerHTML = '<span class="tmo-play"><span>' + IC.play + '</span></span>'; b.addEventListener('click', function () { location.href = p.url; }); g.appendChild(b); }); });
        if (!g.children.length) g.outerHTML = '<p class="tmo-empty">No photos or videos in these posts.</p>';
        list.appendChild(g.children.length ? g : el('<p class="tmo-empty tmo-card tv-bleed">No photos or videos in these posts.</p>'));
      } else posts.forEach(function (p) { list.appendChild(card(p)); });
    }
    function load() {
      foot.textContent = 'Loading…';
      get((o.business ? 'business=' + o.business : 'owner=' + o.owner + (o.as ? '&as=' + encodeURIComponent(o.as) : '')) + (oldest ? '&before=' + oldest : '')).then(function (d) {
        d.posts.forEach(function (p) { posts.push(p); oldest = oldest ? Math.min(oldest, p.id) : p.id; });
        paint();
        foot.innerHTML = d.posts.length >= 20 ? '<button type="button" class="tmo-b" data-older>Older posts</button>' : '';
        var ob = foot.querySelector('[data-older]'); if (ob) ob.addEventListener('click', load);
      }).catch(function (e) { foot.textContent = e.message; });
    }
    host.querySelector('[data-lay]').addEventListener('click', function (e) { grid = !grid; try { localStorage.setItem('tmo-grid', grid ? '1' : '0'); } catch (x) {} e.currentTarget.innerHTML = grid ? IC.list : IC.grid; paint(); });
    document.addEventListener('tvm:posted', function (e) { if (o.self) { posts.unshift(e.detail); paint(); } });
    me().then(load);
  }

  function post(host, id) {
    style(); host.classList.add('tmo');
    me().then(function () { return get('id=' + id); }).then(function (d) { host.innerHTML = ''; host.appendChild(card(d.post)); host.querySelector('[data-com]') && d.post.comments && host.querySelector('[data-com]').click(); })
      .catch(function (e) { host.innerHTML = '<div class="tmo-card tv-bleed"><p>' + esc(e.message) + '</p><p class="tmo-note">Posts last 3 or 7 days unless their poster keeps them. Ask them to share it again, or ask our team at <a class="underline" href="mailto:support@traversence.com">support@traversence.com</a> if something seems wrong.</p></div>'; });
  }

  /** Shows one post first in el (a post just made, where it was written). */
  function show(el, p) { if (!el || !p) return; style(); el.classList.add('tmo'); el.insertBefore(card(p), el.firstChild); }

  /** A Snap to one person, from their profile: the composer in a panel, addressed to them. */
  function snapTo(id, name) {
    style();
    var ov = el('<div class="tmo-ov" role="dialog" aria-modal="true" aria-label="Snap to ' + esc(name) + '"><div></div></div>');
    document.body.appendChild(ov);
    function shut() { ov.remove(); document.removeEventListener('keydown', k, true); }
    function k(e) { if (e.key === 'Escape' && !document.querySelector('.tmo-rec')) shut(); }
    document.addEventListener('keydown', k, true);
    ov.addEventListener('click', function (e) { if (e.target === ov) shut(); });
    composer(ov.firstChild, { to: [{ kind: 'person', id: id, name: name }], openNow: true, onClose: shut, onSent: function (p, msg) { shut(); say(msg); } });
  }

  window.TvMoments = { composer: composer, feed: feed, post: post, recorder: recorder, show: show, snapTo: snapTo };
})();
