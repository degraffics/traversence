/* claim.js: the claim page (decisions/0070). Talks to /listing/api/claim.php; adding a business goes to /api/suggestion.php. */
(function () {
  var root = document.getElementById('claim');
  if (!root) return;
  var csrf = root.getAttribute('data-csrf') || '';
  var entity = parseInt(root.getAttribute('data-entity'), 10) || 0;
  var claim = {};
  try { claim = JSON.parse(root.getAttribute('data-claim') || '{}'); } catch (x) {}
  var API = '/listing/api/claim.php';

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(el, text, ok) { if (!el) return; el.textContent = text || ''; el.className = 'cl-msg ' + (ok ? 'ok' : 'bad'); }
  function post(body, form) {
    var opt = { method: 'POST', credentials: 'include', headers: { 'X-CSRF-Token': csrf } };
    if (form) { opt.body = form; } else { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(window.tvSafe ? tvSafe(body) : body); }
    return fetch(API, opt).then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'Something went wrong. Please try again.' } }; }); });
  }
  function err(d) { return (d && d.error && d.error.message) || 'Something went wrong. Please try again.'; }
  function val(form, name) { var f = form.elements[name]; return f ? (f.type === 'checkbox' ? f.checked : f.value) : ''; }
  function busy(btn, on) { if (btn) btn.disabled = !!on; }

  // ---- Step 1: email code
  var start = document.getElementById('cl-start');
  if (start) {
    var msg = start.querySelector('.cl-msg');
    start.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var btn = start.querySelector('button[type=submit]'); busy(btn, true);
      post({ action: 'start', entity_id: entity, verify: val(start, 'verify') ? 1 : 0, age: val(start, 'age') ? 1 : 0, account_phone: val(start, 'account_phone') }).then(function (d) {
        busy(btn, false);
        if (!d.ok) return say(msg, err(d));
        if (d.held) { location.reload(); return; }
        document.getElementById('cl-code').hidden = false;
        btn.textContent = 'Send a new code';
        say(msg, d.message, true);
        document.getElementById('c-code').focus();
      });
    });
    document.getElementById('cl-confirm').addEventListener('click', function () {
      var btn = this; busy(btn, true);
      post({ action: 'confirm', entity_id: entity, code: val(start, 'code').trim(), role: val(start, 'role'), phone: val(start, 'phone') }).then(function (d) {
        busy(btn, false);
        if (!d.ok) return say(msg, err(d));
        if (d.held) { location.reload(); return; }
        claim = d.claim;
        start.hidden = true;
        var steps = document.querySelector('.cl-steps'); if (steps) steps.hidden = true;
        mine(true);
      });
    });
  }

  // ---- A second request: on hold
  var hold = document.getElementById('cl-hold');
  if (hold) {
    var hmsg = hold.querySelector('.cl-msg');
    hold.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var btn = hold.querySelector('button[type=submit]'); busy(btn, true);
      post({ action: 'hold', entity_id: entity, role: val(hold, 'role'), phone: val(hold, 'phone'), note: val(hold, 'note'),
             verify: val(hold, 'verify') ? 1 : 0, age: val(hold, 'age') ? 1 : 0 }).then(function (d) {
        busy(btn, false);
        if (!d.ok) return say(hmsg, err(d));
        say(hmsg, d.message, true);
        if (!claim.id) setTimeout(function () { location.reload(); }, 900);
      });
    });
    var w = hold.querySelector('[data-withdraw]');
    if (w) w.addEventListener('click', function () { withdraw(hmsg); });
  }
  document.querySelectorAll('.cl-doc').forEach(function (f) { docForm(f); });

  // ---- Dispute
  var disp = document.getElementById('cl-dispute');
  if (disp) {
    disp.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var fd = new FormData(disp); fd.append('action', 'dispute'); fd.append('entity_id', entity);
      var proof = fd.get('file'); fd.delete('file');   // the proof follows, through the site's one uploader (decisions/0127)
      var btn = disp.querySelector('button[type=submit]'); busy(btn, true);
      post(null, fd).then(function (d) {
        busy(btn, false);
        say(disp.querySelector('.cl-msg'), d.ok ? d.message : err(d), d.ok);
        if (!d.ok) return;
        btn.hidden = true;
        if (proof && proof.size && d.claim_id && window.TvUpload) TvUpload.send([proof], { target: 'claim_doc', ctx: { claim: d.claim_id }, el: btn, csrf: csrf });
      });
    });
  }

  // ---- Add your business (decisions/0071): signed in, a code by email, live; "Is this yours?" first
  var nw = document.getElementById('cl-new');
  if (nw) {
    var KEY = 'tv_add_business', msgN = nw.querySelector('.cl-msg');
    var fields = ['name', 'kind', 'town', 'state', 'phone', 'email', 'address', 'point', 'facebook', 'website', 'hours', 'offers'];
    var alsoCats = function () { return Array.prototype.map.call(nw.querySelectorAll('select[name="also_cat[]"]'), function (s) { return s.value; }).filter(Boolean); };
    var data = function () { var o = {}; fields.forEach(function (k) { o[k] = val(nw, k); }); o.also_cat = alsoCats(); return o; };
    try { var saved = JSON.parse(localStorage.getItem(KEY) || 'null'); if (saved) {
      fields.forEach(function (k) { if (saved[k] && nw.elements[k]) nw.elements[k].value = saved[k]; });
      var addB = nw.querySelector('[data-cat-add]');   // the extra categories they had picked
      (saved.also_cat || []).forEach(function (c) { if (!addB) return; addB.click(); var ss = nw.querySelectorAll('select[name="also_cat[]"]'); ss[ss.length - 1].value = c; });
    } } catch (x) {}
    nw.addEventListener('change', function () { try { localStorage.setItem(KEY, JSON.stringify(data())); } catch (x) {} });
    // a recommendation, never a rule (Jason, 2026-10-10): a name carrying a slogan or a list of services gets a tip
    var tip = nw.querySelector('[data-name-tip]'), nm = nw.elements.name;
    var nameTip = function () { if (tip && nm) tip.hidden = !/\s[-–—|:]\s|\s&\s.*\s&\s|,.*,/.test(nm.value) && nm.value.trim().split(/\s+/).length < 7; };
    if (nm) { nm.addEventListener('input', nameTip); nameTip(); }
    var keep = function () { try { localStorage.setItem(KEY, JSON.stringify(data())); } catch (x) {} };
    nw.addEventListener('input', keep);
    var pin = nw.querySelector('[data-pin]');
    if (nw.elements.point.value) pin.textContent = 'Pin set ✓';
    nw.querySelector('[data-here]').addEventListener('click', function () {
      if (!navigator.geolocation) { pin.textContent = 'Your browser can\'t share where you are.'; return; }
      pin.textContent = 'Finding you…';
      navigator.geolocation.getCurrentPosition(function (p) {
        nw.elements.point.value = p.coords.latitude.toFixed(6) + ',' + p.coords.longitude.toFixed(6); pin.textContent = 'Pin set ✓ (where you are now)'; keep();
      }, function () { pin.textContent = 'We couldn\'t get your location. Type the address instead.'; }, { enableHighAccuracy: true, timeout: 15000 });
    });
    var send = function (notMine) {
      var b = data(); b.action = 'add_start'; b.not_mine = !!notMine;
      ['account_phone', 'verify', 'age'].forEach(function (k) { if (nw.elements[k]) b[k] = val(nw, k); });
      var btn = nw.querySelector('button[type=submit]'); busy(btn, true); say(msgN, 'Checking…', true);
      post(b).then(function (d) {
        busy(btn, false);
        if (!d.ok) { say(msgN, err(d), false); return; }
        var dups = nw.querySelector('[data-dups]');
        if (d.duplicates && d.duplicates.length) {
          dups.hidden = false; say(msgN, '', true);
          dups.innerHTML = '<p class="cl-s"><b>Is this yours?</b> It may already be on Traversence:</p>'
            + d.duplicates.map(function (x) { return '<div class="flex gap-2 items-center mt-2" style="justify-content:space-between;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.45rem .6rem"><span class="cl-s"><b>' + esc(x.name) + '</b>' + (x.city ? ', ' + esc(x.city) : '') + '<br><span class="cl-m">' + esc(x.why) + '</span></span><a class="cl-b go" href="/claim.php?listing=' + x.id + '">Claim it</a></div>'; }).join('')
            + '<div class="mt-2"><button class="cl-b" type="button" data-notmine>None of these: add mine</button></div>';
          return;
        }
        dups.hidden = true;
        nw.querySelector('[data-code]').hidden = false; say(msgN, d.message, true); nw.elements.code.focus();
      });
    };
    nw.addEventListener('submit', function (ev) {
      ev.preventDefault(); keep();
      var to = ev.submitter && ev.submitter.getAttribute('data-to');
      if (nw.getAttribute('data-signed') !== '1') { location.href = (to || '/login.php') + '?next=' + encodeURIComponent(nw.getAttribute('data-next')); return; }
      send(false);
    });
    nw.addEventListener('click', function (ev) {
      if (ev.target.closest('[data-notmine]')) { send(true); return; }
      if (ev.target.closest('[data-golive]')) {
        var b = ev.target.closest('[data-golive]'); busy(b, true);
        post({ action: 'add_confirm', code: val(nw, 'code') }).then(function (d) {
          busy(b, false);
          if (!d.ok) { say(msgN, err(d), false); return; }
          try { localStorage.removeItem(KEY); } catch (x) {}
          location.href = d.url + '&added=1';
        });
      }
    });
  }
  document.addEventListener('click', function (ev) {
    var r = ev.target.closest('[data-resend]'); if (!r) return;
    busy(r, true);
    post({ action: 'resend_email' }).then(function (d) { busy(r, false); say(r.closest('.cl-card').querySelector('.cl-msg'), d.ok ? d.message : err(d), d.ok); });
  });

  // ---- Add a business / help complete a listing (a suggestion that goes to Review)
  var add = document.getElementById('cl-add');
  if (add) {
    add.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var kind = add.getAttribute('data-kind');
      var fields = {};
      ['name', 'what', 'address', 'phone', 'website', 'hours'].forEach(function (k) { var v = val(add, k); if (v) fields[k] = v; });
      var body = { kind: kind, topic: 'business', entity_id: entity || null, target_name: fields.name || '', fields: fields, hp: val(add, 'hp'),
                   note: (kind === 'missing' ? 'Added by someone who wants to claim it. ' : '') + val(add, 'note') };
      var btn = add.querySelector('button'); busy(btn, true);
      fetch('/api/suggestion.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
        .then(function (r) { return r.json(); }).then(function (d) {
          busy(btn, false);
          say(add.querySelector('.cl-msg'), d.ok ? (kind === 'missing' ? 'Thank you. We\'ll check it and email you when it\'s on the site, so you can claim it.' : 'Thank you. It goes to our review.') : err(d), d.ok);
          if (d.ok) btn.hidden = true;
        });
    });
  }

  // ---- Your claim: step 2 (text), other ways, other locations, plan
  function mine(fresh) {
    var box = document.getElementById('cl-mine');
    if (!box || !claim.id) return;
    box.hidden = false;
    var verified = claim.status === 'verified';
    var listed = claim.listed_phone || '';
    var h = '';
    h += '<div class="tv-bleed cl-card"><span class="cl-pill' + (verified ? ' v' : '') + '">' + (verified ? '✓ Verified' : 'Managed by owner') + '</span>';
    h += fresh ? '<p class="cl-s mt-2"><b>Step 1 done.</b> You now manage this listing: edit its description, hours, services and photos from your business dashboard.</p>' : '';
    if (!verified) {
      // decisions/0071 §4: one tap sends the admins a request; they verify from their email
      var rq = claim.request || null;
      h += '<h2 class="mt-3">Step 2: get verified</h2>';
      if (rq && rq.status === 'waiting') h += '<p class="cl-s mt-1"><b>Your verification request is with us</b> (sent ' + esc(String(rq.created_at).slice(0, 10)) + '). We\'ll email you as soon as it\'s verified.</p>';
      else {
        if (rq && rq.status === 'not_yet') h += '<p class="cl-s mt-1" style="background:#FFF8EA;border:1px solid #F3D9A4;border-radius:.6rem;padding:.5rem .7rem"><b>Before we can verify it:</b> ' + esc(rq.note) + '</p>';
        h += '<p class="cl-s mt-1">Tap to send your listing to us. We check it, usually the same day, and it shows ✓ Verified.</p>'
          + '<div class="mt-2"><button class="cl-b go" type="button" id="cl-vreq">Send verification request</button></div><p class="cl-msg" role="status" id="cl-vmsg"></p>';
      }
      h += '<details class="cl-more"><summary>Or confirm by text</summary>'
        + '<p class="cl-s mt-1">Text this code to <b><a href="sms:' + esc(claim.verify_number.replace(/\D/g, '')) + '?&body=' + esc(claim.text_code) + '">' + esc(claim.verify_number) + '</a></b>:</p>'
        + '<p class="mt-2"><span class="cl-code">' + esc(claim.text_code) + '</span></p>'
        + '<p class="cl-s mt-2">' + (listed ? 'Text it from the phone number on your listing, <b>' + esc(listed) + '</b>, to finish right away.' : 'Your listing has no phone number on file.')
        + ' Texting from a different number? An admin will contact you within 48 hours to confirm your role with the company.</p>'
        + '<form class="mt-2" id="cl-det"><label class="cl-lb" for="m-phone">The phone you\'re texting from</label>'
        + '<div class="flex gap-2"><input class="cl-in" id="m-phone" name="phone" inputmode="tel" maxlength="20" value="' + esc(claim.claimant_phone) + '">'
        + '<button class="cl-b" type="submit">Save</button></div><input type="hidden" name="role" value="' + esc(claim.role) + '"><p class="cl-msg" role="status"></p></form>'
        + '</details>'
        + '<p class="cl-m mt-2">Until then, changes to the name, phone, address or website go to an admin first.</p>';
      h += '<details class="cl-more"><summary>Other ways to confirm</summary>';
      if (claim.domain) {
        h += '<form class="mt-2" id="cl-dom"><p class="cl-s"><b>An email at @' + esc(claim.domain) + '.</b> We send a code there; entering it confirms you at once.</p>'
          + '<div class="flex gap-2 mt-1"><input class="cl-in" name="email" type="email" placeholder="you@' + esc(claim.domain) + '"><button class="cl-b" type="submit">Send code</button></div>'
          + '<div data-dc hidden class="flex gap-2 mt-2"><input class="cl-in" name="code" inputmode="numeric" maxlength="6" placeholder="6-digit code"><button class="cl-b go" type="button" data-domok>Confirm</button></div>'
          + '<p class="cl-msg" role="status"></p></form>';
      }
      h += '<form class="cl-doc mt-3"><p class="cl-s"><b>A document.</b> A business license, utility bill, lease, photos of the location or back office, or a brochure. PDF, JPG or PNG, up to 25 MB. Only admins see it; it\'s deleted as soon as your claim is decided.'
        + (claim.has_document ? ' <i>We have one from you; sending another replaces it.</i>' : '') + '</p>'
        + '<input type="file" name="file" accept=".pdf,.jpg,.jpeg,.png" required class="mt-2 text-sm"> <button class="cl-b mt-2" type="submit">Send</button><p class="cl-msg" role="status"></p></form>';
      h += '<form class="mt-3" id="cl-appt"><p class="cl-s"><b>Meet with an agent.</b> We call you, or visit the business, at a time that suits you.</p>'
        + '<label class="cl-lb">Email</label><input class="cl-in" name="email" type="email" required>'
        + '<label class="cl-lb">Phone</label><input class="cl-in" name="phone" inputmode="tel" required value="' + esc(claim.claimant_phone || listed) + '">'
        + '<label class="cl-lb">Address</label><input class="cl-in" name="address" maxlength="200">'
        + '<label class="cl-lb">Preferred date and time</label><input class="cl-in" name="when" type="datetime-local" required>'
        + '<label class="cl-lb">How</label><select class="cl-in" name="how"><option value="call">A phone call</option><option value="visit">An on-site visit</option></select>'
        + '<div class="mt-2"><button class="cl-b" type="submit">Request</button></div><p class="cl-msg" role="status"></p></form>';
      h += '</details>';
    } else {
      h += '<p class="cl-s mt-2">Your listing is confirmed. Its name, phone, address and website are yours to edit.</p>';
    }
    h += '</div>';
    // other locations
    h += '<div class="tv-bleed cl-card" id="cl-locs" hidden><h2>Your other locations?</h2><p class="cl-s mt-1">These listings share your name, phone or website. Claim them together: each stays its own listing, and one confirmation can cover all of them if it shows every location (your website lists them, or a brochure or photos do).</p><div data-list class="mt-2"></div><div class="mt-2"><button class="cl-b" type="button" data-addlocs>Claim the ones I ticked</button></div><p class="cl-msg" role="status"></p></div>';
    // plan
    // each tier is a full row: pick it on the left, ▸ on the right opens what it offers (commercial.md §1)
    var plans = [
      ['free', 'Free', '', 'Your listing in the regional directory', ['Your full listing: details, hours, photos, map pin', 'Your catalog of what you offer, managed yourself', 'Messages and comments from visitors', '2 GB storage', 'No AI writing']],
      ['basic', 'Basic Partner', '$29.95/mo', 'Your profile in sections, with AI help', ['Everything in Free', 'Your profile in sections, in the right categories', 'AI help drafting your catalog: 5 drafts a month', '10 AI Assist credits a month', '10 GB storage']],
      ['core', 'Core Partner', '$79.95/mo', 'Your own storefront and QR codes', ['Everything in Basic', 'Your own domain and a storefront', 'GO Codes: QR codes that you can change any time', 'Local search markup kept up to date for you', '50 AI Assist credits a month', '25 GB storage']],
      ['strategic', 'Strategic Partner', '$229.95/mo', 'More content, set up for you', ['Everything in Core', 'Up to 25 catalog articles and 4 custom posts a month', 'White Glove setup and upkeep, with your agent\'s access included (see Terms)', 'A customer list (CRM) with email, SMS and push', '250 AI Assist credits a month', '100 GB storage']],
      ['cornerstone', 'Cornerstone', '$399.95/mo', 'Several locations, fully supported', ['Everything in Strategic', 'Several locations or a co-op, run as one', 'Joint regional campaigns', 'Team roles and dedicated support', '500 AI Assist credits a month', '250 GB storage']]
    ];
    h += '<form class="tv-bleed cl-card" id="cl-plan"><h2>' + (claim.plan ? 'Your plan' : 'Step 3: choose a plan') + '</h2>'
      + '<p class="cl-s mt-1">Paid plans start with a 30-day free trial. Nothing is charged unless you add a card and keep the plan; otherwise it goes back to Free on its own. We\'ll remind you before it ends. No plan ranks you higher in search.</p><div class="cl-plan">';
    plans.forEach(function (p) {
      var on = (claim.plan || 'free') === p[0];
      h += '<div class="cl-tier' + (on ? ' on' : '') + '"><div class="cl-tier-h"><label><input type="radio" name="plan" value="' + p[0] + '"' + (on ? ' checked' : '') + '>'
        + '<span><b>' + p[1] + '</b>' + (p[2] ? ' <span class="cl-price">' + p[2] + '</span>' : '') + '<br><span class="cl-m">' + p[3] + '</span></span></label>'
        + '<button type="button" class="cl-tog" aria-expanded="false" aria-controls="cl-t-' + p[0] + '" title="What ' + p[1] + ' offers" aria-label="What ' + p[1] + ' offers">▸</button></div>'
        + '<ul class="cl-tier-f" id="cl-t-' + p[0] + '" hidden>' + p[4].map(function (f) { return '<li>' + f + '</li>'; }).join('') + '</ul></div>';
    });
    h += '</div><div class="mt-3 flex gap-2 flex-wrap"><button class="cl-b go" type="submit">' + (claim.plan ? 'Change plan' : 'Continue') + '</button>'
      + '<a class="cl-b" href="/listing/businessportal.php">Business dashboard</a></div><p class="cl-msg" role="status"></p></form>';
    if (!verified) h += '<p class="cl-m mt-3"><button type="button" class="underline" data-withdraw>Withdraw my claim</button></p>';
    box.innerHTML = h;

    var vreq = document.getElementById('cl-vreq');
    if (vreq) vreq.addEventListener('click', function () {
      busy(vreq, true);
      post({ action: 'verify_request', claim_id: claim.id }).then(function (d) {
        busy(vreq, false);
        say(document.getElementById('cl-vmsg'), d.ok ? d.message : err(d), d.ok);
        if (d.ok) { vreq.hidden = true; claim.request = { status: 'waiting', created_at: new Date().toISOString() }; }
      });
    });
    var det = document.getElementById('cl-det');
    if (det) det.addEventListener('submit', function (ev) {
      ev.preventDefault();
      post({ action: 'details', claim_id: claim.id, phone: val(det, 'phone'), role: val(det, 'role') }).then(function (d) {
        say(det.querySelector('.cl-msg'), d.ok ? 'Saved.' : err(d), d.ok); if (d.ok) claim = d.claim;
      });
    });
    var dom = document.getElementById('cl-dom');
    if (dom) {
      dom.addEventListener('submit', function (ev) {
        ev.preventDefault();
        post({ action: 'domain_start', claim_id: claim.id, email: val(dom, 'email') }).then(function (d) {
          say(dom.querySelector('.cl-msg'), d.ok ? d.message : err(d), d.ok); if (d.ok) dom.querySelector('[data-dc]').hidden = false;
        });
      });
      dom.querySelector('[data-domok]').addEventListener('click', function () {
        post({ action: 'domain_confirm', claim_id: claim.id, code: val(dom, 'code').trim() }).then(function (d) {
          if (!d.ok) return say(dom.querySelector('.cl-msg'), err(d));
          claim = d.claim; mine(false);
        });
      });
    }
    box.querySelectorAll('.cl-doc').forEach(function (f) { docForm(f); });
    var appt = document.getElementById('cl-appt');
    if (appt) appt.addEventListener('submit', function (ev) {
      ev.preventDefault();
      post({ action: 'appointment', claim_id: claim.id, email: val(appt, 'email'), phone: val(appt, 'phone'), address: val(appt, 'address'), when: val(appt, 'when'), how: val(appt, 'how') })
        .then(function (d) { say(appt.querySelector('.cl-msg'), d.ok ? d.message : err(d), d.ok); });
    });
    var plan = document.getElementById('cl-plan');
    plan.querySelectorAll('.cl-tog').forEach(function (b) {
      b.addEventListener('click', function () {
        var open = b.getAttribute('aria-expanded') !== 'true';
        b.setAttribute('aria-expanded', open ? 'true' : 'false'); b.textContent = open ? '▾' : '▸';
        document.getElementById(b.getAttribute('aria-controls')).hidden = !open;
      });
    });
    plan.addEventListener('change', function () {
      plan.querySelectorAll('.cl-tier').forEach(function (t) { t.classList.toggle('on', t.querySelector('input').checked); });
    });
    function activate(p, agreed, done) {
      post({ action: 'activate', claim_id: claim.id, plan: p, agreed: agreed ? 1 : 0 }).then(function (d) {
        if (done) done(d);
        say(plan.querySelector('.cl-msg'), d.ok ? (p === 'free' ? 'You\'re on the Free plan.' : 'Your 30-day free trial has started. We\'ve emailed you the details, and we\'ll remind you 5 days before it ends.') : err(d), d.ok);
        if (d.ok) claim = d.claim;
      });
    }
    // a paid plan's checkout: what they're starting, the dates, what happens at the end, and the Terms, before anything starts
    function checkout(p) {
      var t = plans.filter(function (x) { return x[0] === p; })[0]; if (!t) return;
      var fmt = function (d) { return d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' }); };
      var start = new Date(), end = new Date(); end.setDate(end.getDate() + 30);
      var remind = new Date(end); remind.setDate(remind.getDate() - 5);
      var m = document.createElement('div');
      m.setAttribute('style', 'position:fixed;inset:0;z-index:80;background:rgba(20,13,8,.55);display:flex;align-items:center;justify-content:center;padding:.6rem');
      var row = function (a, b) { return '<div style="display:flex;justify-content:space-between;gap:.8rem;padding:.4rem 0;border-top:1px solid #EFE3C8"><span style="color:#5C4632">' + a + '</span><b style="text-align:right">' + b + '</b></div>'; };
      m.innerHTML = '<div role="dialog" aria-modal="true" aria-labelledby="cl-co-h" style="background:#FFFBF2;border-radius:1rem;max-width:30rem;width:100%;max-height:calc(100dvh - 1.2rem);overflow:auto;padding:1.1rem;box-sizing:border-box;box-shadow:0 20px 40px -12px rgba(0,0,0,.5)">'
        + '<h2 id="cl-co-h" style="font:700 1.25rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:0 0 .2rem">Start your free ' + t[1] + ' trial</h2>'
        + '<p style="font-size:.88rem;color:#5C4632;margin:0 0 .7rem">' + t[3] + '. Review it before it starts.</p>'
        + '<div style="font-size:.9rem">' + row('Plan', t[1]) + row('Today', '$0.00, no card needed') + row('Trial', '30 days: ' + fmt(start) + ' to ' + fmt(end))
        + row('After the trial', t[2] + ', only if you choose to keep it') + row('Reminder emails', fmt(remind) + ', the day before, and the day it ends') + '</div>'
        + '<ul style="font-size:.85rem;color:#3E2B1F;margin:.7rem 0 .2rem;padding-left:1.1rem;line-height:1.45">'
        + '<li>Nothing is charged during the trial.</li>'
        + '<li><b>To keep the plan</b>, set up billing before ' + fmt(end) + ': add a card on the Plans page and choose <i>Keep my plan</i>. It then renews monthly at ' + t[2] + ' until you cancel.</li>'
        + '<li><b>If you don\'t</b>, it goes back to the Free plan on its own. Nothing is charged, and your listing and content stay; the paid tools pause.</li>'
        + '<li>You can end the trial early, or change plans, any time.</li></ul>'
        + '<details style="font-size:.85rem;margin:.4rem 0"><summary style="cursor:pointer;color:#92400E;font-weight:600">What ' + t[1] + ' includes</summary><ul style="padding-left:1.1rem;margin:.3rem 0">' + t[4].map(function (f) { return '<li>' + f + '</li>'; }).join('') + '</ul></details>'
        + '<label style="display:flex;gap:.55rem;align-items:flex-start;font-size:.88rem;margin:.7rem 0 .2rem;cursor:pointer"><input type="checkbox" data-co-ok style="margin-top:.2rem;width:1.1rem;height:1.1rem;flex:none">'
        + '<span>I agree to the <a href="/terms.php#plans" target="_blank" rel="noopener" class="underline" style="color:#92400E">Terms of Service</a>, including the plan and free trial terms above.</span></label>'
        + '<p data-co-msg role="status" style="font-size:.85rem;color:#991B1B;margin:.3rem 0 0"></p>'
        + '<div style="display:flex;gap:.5rem;justify-content:flex-end;flex-wrap:wrap;margin-top:.7rem"><button type="button" class="cl-b" data-co-x>Back</button><button type="button" class="cl-b go" data-co-go disabled>Start my free trial</button></div></div>';
      document.body.appendChild(m);
      var ok = m.querySelector('[data-co-ok]'), go = m.querySelector('[data-co-go]'), close = function () { m.remove(); document.removeEventListener('keydown', key); };
      var key = function (e) { if (e.key === 'Escape') close(); };
      document.addEventListener('keydown', key);
      ok.addEventListener('change', function () { go.disabled = !ok.checked; });
      m.addEventListener('click', function (e) {
        if (e.target === m || e.target.closest('[data-co-x]')) return close();
        if (!e.target.closest('[data-co-go]') || !ok.checked) return;
        go.disabled = true; go.textContent = 'Starting…';
        activate(p, true, function (d) { if (d.ok) close(); else { go.disabled = false; go.textContent = 'Start my free trial'; m.querySelector('[data-co-msg]').textContent = err(d); } });
      });
      ok.focus();
    }
    plan.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var p = (plan.querySelector('input[name=plan]:checked') || {}).value;
      if (!p) return;
      if (p === 'free') return activate('free', false);
      checkout(p);
    });
    var wd = box.querySelector('[data-withdraw]');
    if (wd) wd.addEventListener('click', function () { withdraw(plan.querySelector('.cl-msg')); });

    // other locations we found
    post({ action: 'locations', claim_id: claim.id }).then(function (d) {
      if (!d.ok || !d.locations || !d.locations.length) return;
      var locs = document.getElementById('cl-locs');
      locs.querySelector('[data-list]').innerHTML = d.locations.map(function (l) {
        return '<label class="cl-chk"><input type="checkbox" value="' + l.id + '"> <span><b>' + esc(l.name) + '</b>' + (l.address || l.city ? ', ' + esc(l.address || l.city) : '') + '</span></label>';
      }).join('');
      locs.hidden = false;
      locs.querySelector('[data-addlocs]').addEventListener('click', function () {
        var ids = Array.prototype.map.call(locs.querySelectorAll('input:checked'), function (i) { return parseInt(i.value, 10); });
        if (!ids.length) return say(locs.querySelector('.cl-msg'), 'Tick the locations that are yours.');
        post({ action: 'add_locations', claim_id: claim.id, ids: ids }).then(function (r) {
          say(locs.querySelector('.cl-msg'), r.ok ? (r.added + ' location' + (r.added === 1 ? '' : 's') + ' added. Each one shows in your business dashboard; one confirmation can cover them all.') : err(r), r.ok);
        });
      });
    });
  }

  function docForm(f) {
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var inp = f.querySelector('input[type=file]'), files = Array.prototype.slice.call((inp && inp.files) || []);
      if (!files.length || !window.TvUpload) return say(f.querySelector('.cl-msg'), 'Choose the file first.');
      var btn = f.querySelector('button'); busy(btn, true);   // through the site's one uploader (decisions/0127)
      TvUpload.send(files.slice(0, 1), { target: 'claim_doc', ctx: { claim: claim.id }, el: btn, csrf: csrf })
        .then(function () { busy(btn, false); inp.value = ''; claim.has_document = true; }, function () { busy(btn, false); });
    });
  }

  function withdraw(msgEl) {
    TvAsk.confirm('Withdraw your claim? The listing goes back to unclaimed.', { anchor: document.querySelector('[data-withdraw]'), yes: 'Withdraw', danger: true }).then(function (ok) {
    if (ok) post({ action: 'withdraw', claim_id: claim.id }).then(function (d) {
      if (!d.ok) return say(msgEl, err(d));
      location.reload();
    });
    });
  }

  if (claim.id && claim.status !== 'on_hold') mine(false);
})();
