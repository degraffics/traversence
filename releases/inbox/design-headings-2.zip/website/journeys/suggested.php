<?php
// journeys/suggested.php?id= — one suggested journey (decisions/0146): built by rules from a guide's own places and
// labelled "Suggested by Traversence". The kind (searches for more), the title, the place (its guide), the engage bar,
// the stops in order with their times and the travel between them, the whole route in the visitor's maps app, comments.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/JourneyPlan.php';
require_once __DIR__ . '/../../app/ui/suggested-journeys.php';
require_once __DIR__ . '/../../app/ui/engage-ui.php';

$pdo = Database::connection();
$j = JourneyPlan::get($pdo, (int) ($_GET['id'] ?? 0));
$p = $j ? Guides::place($pdo, (string) $j['place_key']) : null;
if (!$j || !$p || $j['status'] !== 'live') {
    http_response_code(404);
    tv_page_start('Journey not found');
    echo '<div class="text-center py-10"><h1 class="font-serif font-bold text-2xl mb-2">Journey not found</h1><p class="text-sm">It may have been rebuilt or taken down. <a class="underline" href="/discovery/">Back to Discovery</a></p></div>';
    tv_page_end();
    exit;
}
$id = (int) $j['id'];
$place = $p['name'] . ($p['level'] === 'town' && $p['state'] ? ', ' . $p['state'] : '');
tv_page_start($j['title'], ['no_crumbs' => true, 'description' => (string) ($j['why'] ?: $j['title'])]);
tv_count_item('suggested:' . $id);   // after the page start, which loads app-shell.php where it lives (it stopped every journey page before: site audit 2026-11-13)
?>
<?= tv_sj_css() ?>
<style>
  .sjp-head{position:relative;margin:.6rem 0 .5rem;padding-right:2.6rem}
  .sjp-kind{font:700 .74rem system-ui,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#8A7355;background:none;border:0;padding:0;cursor:pointer;text-decoration:underline}
  .sjp-head h1{font:700 1.6rem/1.2 var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:.2rem 0}
  .sjp-place a{color:#92400E;text-decoration:underline;font-weight:600}
</style>
<div class="sjp-head" data-link-host>
  <button type="button" class="sjp-kind" onclick="window.TvSearch && TvSearch.open(<?= tv_e(json_encode('journeys near ' . $place)) ?>)">Suggested journey</button>
  <h1><?= tv_e($j['title']) ?></h1>
  <p class="sjp-place"><a href="<?= tv_e($p['url']) ?>"><?= tv_e($place) ?></a> · <?= tv_e($p['kind']) ?></p>
</div>
<?= tv_engage_bar($pdo, 'sj', (string) $id, ['title' => $j['title']]) ?>
<div class="sj-list" style="margin-top:.6rem"><?= tv_sj_card($j, true) ?></div>
<p class="sj-note" style="margin-top:.6rem">Built from the places in the <a href="<?= tv_e($p['url']) ?>"><?= tv_e($p['name']) ?> guide</a>. A business is here because it fits the route, never because it pays. Something wrong? <a href="/takedown.php?<?= tv_e(http_build_query(['kind' => 'guide', 'ref' => (string) $j['place_key'], 'section' => 'journeys'])) ?>" rel="nofollow">Tell us</a>.</p>
<?= tv_engage_comments($pdo, 'sj', (string) $id) ?>
<?php tv_page_end();
