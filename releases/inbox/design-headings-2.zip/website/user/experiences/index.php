<?php
// user/experiences/index.php — Your experiences, in the member Dashboard (decisions/0059). Signed in, 18 or older.
// Post an experience (a thing to do worth the trip, in a place), see where yours stand (waiting for review, published,
// not approved with the reviewer's note), edit and resubmit, delete one that isn't published. Staff with a content
// role can also post as Traversence (an Editor's is published at once).
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../../app/ui/page-shell.php';
require_once __DIR__ . '/../../../app/ui/experience-ui.php';
require_once __DIR__ . '/../../../app/lib/Journeys.php';

$uid = Auth::currentUserId();
if ($uid === null) { header('Location: /login.php?next=' . rawurlencode('/user/experiences/'), true, 302); exit; }
$pdo = Database::connection();
$ready = Experiences::ready($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$staff = $ready && Experiences::staffCan($pdo, $uid, 'content');
$msg = null; $form = null;
$edit = $ready && isset($_GET['edit']) ? Experiences::get($pdo, (int) $_GET['edit']) : null;
if ($edit && !(((int) $edit['author_id'] === $uid && $edit['source'] === 'member') || $staff)) $edit = null;

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'delete') {
            Experiences::remove($pdo, $uid, (int) ($_POST['id'] ?? 0));
            $_SESSION['xp_flash'] = 'Deleted.';
        } else {
            if (!empty($_POST['over_18'])) AgeGate::confirm($pdo, $uid);
            if (!AgeGate::confirmed($pdo, $uid)) throw new InvalidArgumentException('Please confirm you are 18 or older.');
            $asStaff = $staff && !empty($_POST['as_traversence']);
            $id = Experiences::save($pdo, $uid, $_POST, (int) ($_POST['id'] ?? 0) ?: null, $asStaff);
            $e = Experiences::get($pdo, $id);
            $_SESSION['xp_flash'] = $e && $e['status'] === 'published'
                ? (!empty($e['auto_published']) ? 'Posted. Your record here let it go up at once; our editors may still look it over.' : 'Published.')
                : 'Thank you. It\'s with our editors now; you\'ll see it here when it\'s approved.';
        }
        header('Location: /user/experiences/', true, 303);
        exit;
    } catch (InvalidArgumentException $x) {
        $msg = $x->getMessage();
        $form = $_POST;
    }
}
$flash = $_SESSION['xp_flash'] ?? null; unset($_SESSION['xp_flash']);
$mine = $ready ? Experiences::mine($pdo, $uid) : [];
$ageOk = AgeGate::confirmed($pdo, $uid);
$myJ = [];
try { $st = $pdo->prepare("SELECT id, title FROM journeys WHERE author_id = ? AND status = 'published' ORDER BY published_at DESC LIMIT 30"); $st->execute([$uid]); $myJ = $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) {}

// the form's values: what was just sent back with a problem, the one being edited, or empty
$f = $form ?? ($edit ? $edit + ['listings' => [], 'journeys' => []] : []);
$links = $edit ? Experiences::links($pdo, (int) $edit['id']) : ['listing' => [], 'rec' => [], 'journey' => []];
$pickedL = [];
foreach ((array) ($form['listings'] ?? $links['listing']) as $lid) {
    $st = $pdo->prepare('SELECT id, name FROM entities WHERE id = ?'); $st->execute([(int) $lid]);
    if ($r = $st->fetch(PDO::FETCH_ASSOC)) $pickedL[] = $r;
}
$pickedJ = array_map('intval', (array) ($form['journeys'] ?? $links['journey']));
$seasonsOn = isset($f['seasons']) ? (is_array($f['seasons']) ? $f['seasons'] : ((string) $f['seasons'] === 'all' ? [] : explode(',', (string) $f['seasons']))) : [];
$val = fn (string $k) => tv_e((string) ($f[$k] ?? ''));

tv_page_start('Your experiences', ['section' => 'member', 'active' => 'experiences', 'no_crumbs' => true]);
?>
<style>
  .xp{max-width:46rem}
  .xp h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.7rem;margin:0 0 .3rem;color:#3E2B1F}
  .xp-lead{font-size:.92rem;color:#5C4632;line-height:1.5;margin:0 0 1rem}
  .xp-card{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;padding:.9rem 1rem;margin-bottom:.8rem}
  .xp-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.15rem;margin:0 0 .6rem;color:#3E2B1F}
  .xp-f{display:grid;gap:.6rem}.xp-f label{display:grid;gap:.2rem;font-size:.78rem;font-weight:700;color:#5C4632}
  .xp-f input[type=text],.xp-f textarea,.xp-f select{font:inherit;font-size:.92rem;font-weight:400;border:1px solid #CBB98D;border-radius:.5rem;padding:.45rem .55rem;background:#fff;color:#3E2B1F;width:100%;box-sizing:border-box}
  .xp-f small{font-weight:400;color:#8A7355}
  .xp-row{display:grid;grid-template-columns:repeat(3,1fr);gap:.5rem}
  .xp-checks{display:flex;flex-wrap:wrap;gap:.3rem .8rem;font-weight:400}.xp-checks label{display:flex;align-items:center;gap:.3rem;font-weight:400;font-size:.88rem}
  .xp-ac{position:relative}.xp-list{position:absolute;left:0;right:0;top:100%;z-index:20;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;box-shadow:0 10px 20px -12px rgba(0,0,0,.4);max-height:16rem;overflow:auto}
  .xp-list button{display:flex;justify-content:space-between;gap:.5rem;width:100%;text-align:left;border:0;border-bottom:1px solid #EADFC4;background:none;padding:.5rem .6rem;font:inherit;font-size:.88rem;cursor:pointer;color:#3E2B1F}
  .xp-list small{color:#8A7355}
  .xp-chips{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.3rem}.xp-chips span{display:inline-flex;align-items:center;gap:.3rem;border-radius:999px;background:#3E2B1F;color:#FFFBF2;font-size:.8rem;padding:.2rem .55rem}
  .xp-chips button{border:0;background:none;color:#F3DDB0;cursor:pointer;font-size:.95rem;padding:0}
  .xp-btn{display:inline-block;border-radius:999px;border:0;background:#3E2B1F;color:#FFFBF2;font-weight:700;padding:.55rem 1.1rem;cursor:pointer;font-size:.9rem;text-decoration:none}
  .xp-btn.l{background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D}
  .xp-msg{border-radius:.6rem;padding:.55rem .75rem;font-size:.88rem;margin-bottom:.8rem}.xp-msg.ok{background:#E8F2EC;color:#2F5D4A}.xp-msg.err{background:#FEE2E2;color:#991B1B}
  .xp-item{display:flex;gap:.7rem;align-items:flex-start;padding:.6rem 0;border-top:1px solid #EADFC4}.xp-item:first-of-type{border-top:0}
  .xp-item b{display:block;color:#3E2B1F}.xp-item small{color:#8A7355}.xp-item .xp-note{display:block;color:#991B1B;font-size:.8rem;margin-top:.15rem}
  .xp-st{flex:0 0 auto;font-size:.66rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;border-radius:999px;padding:.15rem .5rem;background:#FEF3C7;color:#92400E}
  .xp-st.published{background:#E8F2EC;color:#2F5D4A}.xp-st.rejected,.xp-st.hidden{background:#FEE2E2;color:#991B1B}
  .xp-acts{margin-left:auto;display:flex;gap:.3rem;flex:0 0 auto}.xp-acts a,.xp-acts button{font-size:.78rem;border:1px solid #CBB98D;border-radius:999px;padding:.2rem .6rem;background:#FFFBF2;color:#3E2B1F;text-decoration:none;cursor:pointer}
  .xp-item{flex-wrap:wrap}.xp-item>span:nth-child(2){flex:1 1 14rem;min-width:0}.xp-item small{display:block}
  @media (max-width:640px){.xp-row{grid-template-columns:1fr 1fr}.xp-acts{margin-left:0;width:100%}}
</style>
<div class="xp">
  <h1>Your experiences</h1>
  <p class="xp-lead">An experience is something to do that&rsquo;s worth the trip: you take part, it belongs to the place, and someone local can make it happen. Post one and our editors review it before it shows on Let&rsquo;s Explore.</p>
  <?php if (!$ready): ?><p class="xp-msg err">Experiences aren&rsquo;t switched on yet (app/migrations/2026-10-12_experiences.sql).</p><?php else: ?>
  <?php if ($flash): ?><p class="xp-msg ok"><?= tv_e($flash) ?></p><?php endif; ?>
  <?php if ($msg): ?><p class="xp-msg err"><?= tv_e($msg) ?></p><?php endif; ?>

  <?php if ($mine): ?>
  <section class="xp-card tv-bleed"><h2>Posted</h2>
    <?php foreach ($mine as $e): ?>
      <div class="xp-item"><span class="xp-st <?= tv_e($e['status']) ?>"><?= tv_e(Experiences::STATUSES[$e['status']] ?? $e['status']) ?></span>
        <span><a href="/experiences/view.php?id=<?= (int) $e['id'] ?>"><b><?= tv_e($e['title']) ?></b></a><small><?= tv_e($e['place_label']) ?> · <?= tv_e(Experiences::TYPES[$e['type']] ?? '') ?></small>
          <?php if ($e['review_note'] !== '' && in_array($e['status'], ['rejected', 'hidden'], true)): ?><span class="xp-note">Editor&rsquo;s note: <?= tv_e($e['review_note']) ?></span><?php endif; ?></span>
        <span class="xp-acts"><?php if ($e['status'] !== 'published'): ?><a href="?edit=<?= (int) $e['id'] ?>#post">Edit</a>
          <form method="post" data-confirm="Delete this experience?" data-yes="Delete" data-danger><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= (int) $e['id'] ?>"><button type="submit">Delete</button></form><?php endif; ?></span></div>
    <?php endforeach; ?>
  </section>
  <?php endif; ?>

  <form class="xp-card xp-f tv-bleed" method="post" id="post">
    <h2><?= $edit ? 'Edit your experience' : 'Post an experience' ?></h2>
    <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="id" value="<?= $edit ? (int) $edit['id'] : '' ?>">
    <label>What you do <small>Start with the doing: &ldquo;Paddle Lyman Lake at sunrise&rdquo;, &ldquo;Rodeo weekend in Springerville&rdquo;</small><input type="text" name="title" maxlength="140" required value="<?= $val('title') ?>"></label>
    <label class="xp-ac">Where <small>The town, area or local name it&rsquo;s in</small>
      <input type="text" id="xp-place" autocomplete="off" placeholder="Start typing a town" value="<?= $val('place_label') ?>" required><input type="hidden" name="place_key" id="xp-place-key" value="<?= $val('place_key') ?>"><input type="hidden" name="place_label" value="<?= $val('place_label') ?>">
      <div class="xp-list" id="xp-place-list" hidden></div></label>
    <label>What it&rsquo;s like <small>A sentence or two. Why is it worth the trip?</small><textarea name="summary" rows="3" maxlength="600" required><?= $val('summary') ?></textarea></label>
    <label>How to do it <small>Optional: when to go, what to bring, where to start, tips</small><textarea name="body" rows="5" maxlength="6000"><?= $val('body') ?></textarea></label>
    <div class="xp-row">
      <label>Kind<select name="type"><?php foreach (Experiences::TYPES as $k => $l): ?><option value="<?= $k ?>"<?= ($f['type'] ?? '') === $k ? ' selected' : '' ?>><?= tv_e($l) ?></option><?php endforeach; ?></select></label>
      <label>How long<select name="duration"><?php foreach (Experiences::DURATIONS as $k => $l): ?><option value="<?= $k ?>"<?= ($f['duration'] ?? 'half') === $k ? ' selected' : '' ?>><?= tv_e($l) ?></option><?php endforeach; ?></select></label>
      <label>Effort<select name="effort"><?php foreach (Experiences::EFFORTS as $k => $l): ?><option value="<?= $k ?>"<?= ($f['effort'] ?? 'easy') === $k ? ' selected' : '' ?>><?= tv_e($l) ?></option><?php endforeach; ?></select></label>
    </div>
    <label>Best seasons <small>Leave all unticked for any time of year</small><span class="xp-checks"><?php foreach (Experiences::SEASONS as $k => $l): ?><label><input type="checkbox" name="seasons[]" value="<?= $k ?>"<?= in_array($k, $seasonsOn, true) ? ' checked' : '' ?>> <?= tv_e($l) ?></label><?php endforeach; ?></span></label>
    <label class="xp-ac">Who can take you, where to eat or stay <small>Optional: local businesses that make it happen</small>
      <input type="text" id="xp-biz" autocomplete="off" placeholder="Search listings by name"><div class="xp-list" id="xp-biz-list" hidden></div>
      <span class="xp-chips" id="xp-biz-chips"><?php foreach ($pickedL as $b): ?><span><?= tv_e($b['name']) ?><input type="hidden" name="listings[]" value="<?= (int) $b['id'] ?>"><button type="button" aria-label="Remove">&times;</button></span><?php endforeach; ?></span></label>
    <?php if ($myJ): ?><label>Your journeys about it <small>Optional: their photos show on the experience</small><span class="xp-checks"><?php foreach ($myJ as $j): ?><label><input type="checkbox" name="journeys[]" value="<?= (int) $j['id'] ?>"<?= in_array((int) $j['id'], $pickedJ, true) ? ' checked' : '' ?>> <?= tv_e($j['title']) ?></label><?php endforeach; ?></span></label><?php endif; ?>
    <label>Go with respect <small>Optional: anything visitors should know: permits, quiet hours, a nation&rsquo;s guidance on its land</small><textarea name="respect_note" rows="2" maxlength="400"><?= $val('respect_note') ?></textarea></label>
    <p class="xp-lead" style="margin:0;font-size:.8rem">Public places and events only. On a sovereign nation&rsquo;s land, only what the nation offers visitors, and never the location of a sacred or restricted site.</p>
    <?php if (!$ageOk): ?><label class="xp-checks"><label><input type="checkbox" name="over_18" value="1" required> I am 18 or older</label></label><?php endif; ?>
    <?php if ($staff): ?><label class="xp-checks"><label><input type="checkbox" name="as_traversence" value="1"<?= !empty($f['as_traversence']) || ($edit && $edit['source'] !== 'member') ? ' checked' : '' ?>> Post as Traversence<?= Experiences::staffCan($pdo, $uid, 'publish') ? ' (published at once)' : ' (an Editor publishes it)' ?></label></label><?php endif; ?>
    <div><button class="xp-btn" type="submit"><?= $staff && Experiences::staffCan($pdo, $uid, 'publish') ? 'Save' : ($edit ? 'Save and send for review' : 'Send for review') ?></button> <?php if ($edit): ?><a class="xp-btn l" href="/user/experiences/">Cancel</a><?php endif; ?></div>
  </form>
  <?php endif; ?>
</div>
<script>
(function () {
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  function ac(inp, list, url, show, pick) {
    var t = null, seq = 0, opts = [];
    inp.addEventListener('input', function () {
      clearTimeout(t); var q = inp.value.trim(); if (q.length < 2) { list.hidden = true; return; }
      t = setTimeout(function () { var my = ++seq;
        fetch(url + encodeURIComponent(q), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
          if (my !== seq) return; opts = show(d) || [];
          list.innerHTML = opts.length ? opts.map(function (o, i) { return '<button type="button" data-i="' + i + '"><span>' + esc(o.label) + '</span><small>' + esc(o.sub || '') + '</small></button>'; }).join('') : '<button type="button" disabled>Nothing by that name</button>';
          list.hidden = false; }).catch(function () {});
      }, 220);
    });
    list.addEventListener('click', function (e) { var b = e.target.closest('[data-i]'); if (!b) return; pick(opts[+b.getAttribute('data-i')]); list.hidden = true; });
    document.addEventListener('click', function (e) { if (!e.target.closest('.xp-ac')) list.hidden = true; });
  }
  var pi = document.getElementById('xp-place'); if (!pi) return;
  var pk = document.getElementById('xp-place-key'), pl = document.querySelector('[name=place_label]');
  pi.addEventListener('input', function () { pk.value = ''; });
  ac(pi, document.getElementById('xp-place-list'), '/api/journeys.php?places=', function (d) { return d.places; }, function (o) { pi.value = o.label; pk.value = o.key; pl.value = o.label; });
  var chips = document.getElementById('xp-biz-chips'), bi = document.getElementById('xp-biz');
  ac(bi, document.getElementById('xp-biz-list'), '/api/journeys.php?listings=', function (d) { return (d.listings || []).map(function (l) { return { label: l.name, sub: l.city, id: l.id }; }); }, function (o) {
    if (chips.querySelector('input[value="' + o.id + '"]')) return;
    var s = document.createElement('span'); s.innerHTML = esc(o.label) + '<input type="hidden" name="listings[]" value="' + o.id + '"><button type="button" aria-label="Remove">&times;</button>'; chips.appendChild(s); bi.value = '';
  });
  chips.addEventListener('click', function (e) { if (e.target.closest('button')) e.target.closest('span').remove(); });
  document.getElementById('post').addEventListener('submit', function (e) { if (!pk.value) { e.preventDefault(); pi.focus(); TvAsk.say('Choose the place from the list as you type.', { anchor: pi }); } });
})();
</script>
<script src="/js/tv-ai-assist.js?v=<?= (int) @filemtime(__DIR__ . '/../../js/tv-ai-assist.js') ?>"></script>
<script>if (window.TvAi) TvAi.attach(document.querySelector('textarea[name=body]'), { source: 'experience', place: function () { var k = document.getElementById('xp-place-key'); return k ? k.value : ''; } });   // AI Assist where members write (source-tagged)</script>
<?php tv_page_end();
