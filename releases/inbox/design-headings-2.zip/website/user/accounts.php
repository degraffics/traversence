<?php
// /user/accounts.php — Your accounts: everything you can act as, on one page (decisions/0055 §4, 0100). Your personal
// account, your Traversence staff login (when linked), Steward and Admin roles, and every listing you're on the team
// of, grouped by its Nexus (a brand or system's locations together), with a search box when there are many. The
// account menu shows the few top-level accounts and sends you here for listings, so a Nexus owner with dozens of
// locations isn't scrolling a menu.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Roles.php';
require_once __DIR__ . '/../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
header('Content-Type: text/html; charset=utf-8');

$me = Auth::currentUser();
if (!$me) { header('Location: /login.php?next=' . rawurlencode('/user/accounts.php'), true, 303); exit; }
$pdo = Database::connection();
$uid = (int) $me['id'];
$ctx = Roles::current($pdo, $uid);
$all = Roles::contexts($pdo, $uid);
$other = null;
try { $other = StaffLogin::otherAccount($pdo, $me); } catch (Throwable $e) { error_log('accounts: ' . $e->getMessage()); }
$name = trim((string) ($me['display_name'] ?? '')) ?: (string) strstr((string) $me['email'], '@', true);
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);

// listings, grouped by Nexus
$orgs = array_values(array_filter($all, fn ($c) => $c['kind'] === 'org'));
$groups = [];
$nx = [];
$ids = array_values(array_filter(array_map(fn ($c) => (int) ($c['scope']['entity'] ?? 0), $orgs)));
if ($ids) {
    try {
        $in = implode(',', $ids);
        foreach ($pdo->query("SELECT e.id, e.primary_zip, n.id AS nid, n.name AS nname FROM entities e LEFT JOIN nexus n ON n.id = e.nexus_id AND n.status = 'active' WHERE e.id IN ($in)")->fetchAll(PDO::FETCH_ASSOC) as $r) $nx[(int) $r['id']] = $r;
    } catch (PDOException) {
        try { foreach ($pdo->query('SELECT id, primary_zip FROM entities WHERE id IN (' . implode(',', $ids) . ')')->fetchAll(PDO::FETCH_ASSOC) as $r) $nx[(int) $r['id']] = $r; } catch (PDOException) {}
    }
}
foreach ($orgs as $c) {
    $id = (int) ($c['scope']['entity'] ?? 0); $r = $nx[$id] ?? [];
    $g = !empty($r['nid']) ? (string) $r['nname'] : '';
    $c['place'] = (string) ($r['primary_zip'] ?? '');
    $groups[$g][] = $c;
}
uksort($groups, fn ($a, $b) => [$a === '', $a] <=> [$b === '', $b]);   // Nexus groups first, then the rest
foreach ($groups as &$list) usort($list, fn ($a, $b) => strcasecmp($a['label'], $b['label']));
unset($list);

$row = function (array $c, string $title, string $sub, string $href = '') use ($ctx, $e): string {
    $on = $c['key'] === $ctx['key'];
    return '<div class="ac-row' . ($on ? ' on' : '') . '" data-find="' . $e(mb_strtolower($title . ' ' . $sub)) . '"><div class="ac-t">'
        . ($href !== '' ? '<a class="ac-n" href="' . $e($href) . '">' . $e($title) . '</a>' : '<b class="ac-n">' . $e($title) . '</b>')
        . '<small>' . $e($sub) . '</small></div>'
        . ($on ? '<span class="ac-cur">Current</span>' : '<button type="button" class="ac-b" data-ctx="' . $e($c['key']) . '" data-kind="' . $e($c['kind']) . '">Switch</button>') . '</div>';
};

tv_page_start('Your accounts', ['no_crumbs' => true, 'section' => 'member', 'description' => 'Switch between your personal account, your staff login and the listings you manage.']);
?>
<style>
  .ac{max-width:44rem;color:#3E2B1F}
  .ac h1{font:700 1.7rem var(--tv-font-head,Georgia,serif);margin:.2rem 0}.ac h2{font:700 1.05rem var(--tv-font-head,Georgia,serif);margin:1.1rem 0 .3rem}
  .ac p.i{font-size:.9rem;color:#5C4632}
  .ac-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.2rem .8rem}
  .ac-row{display:flex;align-items:center;gap:.6rem;padding:.55rem 0;border-top:1px solid #EADFC4}.ac-row:first-child{border-top:0}
  .ac-row.on{box-shadow:inset 3px 0 0 #8FBCA8;padding-left:.5rem}
  .ac-t{flex:1;min-width:0}.ac-t small{display:block;font-size:.78rem;color:#8A7355}
  .ac-n{font-weight:700;color:#3E2B1F}a.ac-n{color:#92400E;text-decoration:underline}
  .ac-b{border:1px solid #92400E;background:#92400E;color:#fff;border-radius:.6rem;padding:.35rem .8rem;font-weight:700;font-size:.82rem;cursor:pointer;white-space:nowrap}
  .ac-b.lt{background:#FFFBF2;color:#92400E}
  .ac-cur{font-size:.78rem;font-weight:700;color:#1F5C43;background:#DCFCE7;border-radius:999px;padding:.15rem .55rem}
  .ac-q{width:100%;font-size:.95rem;padding:.5rem .7rem;border:1px solid #CBB98D;border-radius:.6rem;background:#FFFBF2;margin:.2rem 0 .4rem}
  .ac-g{font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#8A7355;margin:.7rem 0 .2rem}
</style>
<div class="ac">
  <h1>Your accounts</h1>
  <p class="i">Everything you can act as. Switching changes your toolbar and Pulse; it doesn't sign you out.</p>

  <h2>You</h2>
  <div class="ac-card tv-bleed">
    <?php foreach ($all as $c): if ($c['kind'] === 'org') continue;
      $t = match ($c['kind']) { 'member' => [$name, 'Personal Account'], 'steward' => [$name, 'Steward · ' . $c['sub']], 'admin' => [$name, (($c['staff'] ?? '') !== '' ? 'Traversence staff · ' : 'System Admin · ') . $c['sub']], default => [(string) $c['label'], (string) $c['sub']] };
      echo $row($c, $t[0], $t[1]);
    endforeach; ?>
    <?php if ($other): ?>
    <div class="ac-row"><div class="ac-t"><b class="ac-n"><?= $e($other['name']) ?></b><small><?= $e($other['sub']) ?><?= $other['to'] === 'staff_signin' ? ' · sign in with your staff login' : '' ?></small></div>
      <?php if ($other['to'] === 'member' || $other['to'] === 'staff'): ?><button type="button" class="ac-b" data-acct="<?= $e($other['to']) ?>">Switch</button>
      <?php elseif ($other['to'] === 'staff_signin'): ?><a class="ac-b lt" href="/admin/login.php">Sign in</a>
      <?php else: ?><a class="ac-b lt" href="/admin/staff.php">How to link</a><?php endif; ?></div>
    <?php endif; ?>
  </div>

  <?php if ($orgs): ?>
  <h2>Listings you manage (<?= count($orgs) ?>)</h2>
  <?php if (count($orgs) > 6): ?><input class="ac-q" type="search" id="ac-q" placeholder="Find a listing, ZIP or brand" aria-label="Find a listing"><?php endif; ?>
  <div class="ac-card tv-bleed" id="ac-list">
    <?php foreach ($groups as $g => $list): ?>
      <?php if ($g !== '' || count($groups) > 1): ?><div class="ac-g" data-grp><?= $e($g !== '' ? $g . ' · ' . count($list) . ' location' . (count($list) === 1 ? '' : 's') : 'Other listings') ?></div><?php endif; ?>
      <?php foreach ($list as $c): $id = (int) ($c['scope']['entity'] ?? 0);
        echo $row($c, (string) $c['label'], trim($c['sub'] . ($c['place'] !== '' ? ' · ' . $c['place'] : '') . ($g !== '' ? ' · ' . $g : '')), $id > 0 ? '/listing/view.php?id=' . $id : '');
      endforeach; ?>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<script>
(function () {
  var q = document.getElementById('ac-q');
  if (q) q.addEventListener('input', function () {
    var v = q.value.trim().toLowerCase();
    document.querySelectorAll('#ac-list .ac-row').forEach(function (r) { r.hidden = v !== '' && r.getAttribute('data-find').indexOf(v) < 0; });
    document.querySelectorAll('#ac-list [data-grp]').forEach(function (h) {
      var n = h.nextElementSibling, any = false;
      while (n && !n.hasAttribute('data-grp')) { if (!n.hidden) any = true; n = n.nextElementSibling; }
      h.hidden = !any;
    });
  });
  function post(body, b) {
    b.disabled = true; b.textContent = 'Switching…';
    return fetch('/user/api/context.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      return fetch('/user/api/context.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': d.csrf || '' }, body: JSON.stringify(body) });
    }).then(function (r) { return r.json(); }).then(function (r) {
      if (!r.ok) { b.disabled = false; b.textContent = 'Switch'; if (window.TvAsk) TvAsk.say((r.error && r.error.message) || 'That didn\'t work.', { anchor: b }); return null; }
      return r;
    });
  }
  document.querySelectorAll('.ac [data-ctx]').forEach(function (b) { b.addEventListener('click', function () {
    var kind = b.getAttribute('data-kind');
    post({ context: b.getAttribute('data-ctx') }, b).then(function (r) { if (r) location.href = kind === 'admin' ? '/admin/' : '/user/dashboard.php#pulse'; });
  }); });
  document.querySelectorAll('.ac [data-acct]').forEach(function (b) { b.addEventListener('click', function () {
    post({ account: b.getAttribute('data-acct') }, b).then(function (r) { if (r) location.href = r.go || '/'; });
  }); });
})();
</script>
<?php tv_page_end();
