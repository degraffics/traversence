<?php
// user/staff-link.php — a member confirms the staff link an owner asked for (decisions/0100, addendum 2026-10-23).
// Reached from the email. Signed in as the member it was sent to: what linking means, and Link / Not me. A linked
// staff login can switch into this account without its password, which is why the member says yes here.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
header('Content-Type: text/html; charset=utf-8');

$tok = preg_match('/^[A-Za-z0-9_-]+\.[a-f0-9]{32}$/', (string) ($_GET['t'] ?? '')) ? (string) $_GET['t'] : '';
$me = Auth::currentUser();
if (!$me) { header('Location: /login.php?next=' . rawurlencode('/user/staff-link.php?t=' . $tok), true, 303); exit; }
$pdo = Database::connection();
$s = $tok !== '' && !StaffLogin::isStaffUser((string) $me['email']) ? StaffLogin::memberLinkFor($pdo, $tok, (int) $me['id']) : null;
$done = $s && (int) $s['member_user_id'] === (int) $me['id'];
$e = 'tv_e';
tv_page_start('Link your staff login', ['no_crumbs' => true, 'section' => 'member', 'description' => 'Confirm the link between your member account and your Traversence staff login.']);
?>
<style>
  .sl{max-width:40rem;color:#3E2B1F}
  .sl-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.9rem;padding:.9rem 1rem;margin-top:.7rem}
  .sl h1{font:700 1.3rem var(--tv-font-head,Georgia,serif);margin:.4rem 0}
  .sl p{margin:.4rem 0;font-size:.95rem;line-height:1.55}
  .sl-b{display:inline-block;border-radius:.6rem;padding:.5rem .9rem;font-weight:600;font-size:.9rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;text-decoration:none}
  .sl-b.go{background:#92400E;border-color:#92400E;color:#fff}
</style>
<div class="sl">
  <h1>Link your staff login</h1>
  <?php if (!$s): ?>
  <div class="sl-card tv-bleed"><p>This link has expired, or it's for a different account than the one you're signed in as (<b><?= $e($me['email']) ?></b>). Sign in as the account the email went to, or ask an owner to send a new one.</p>
    <p><a class="sl-b" href="/user/dashboard.php">Your dashboard</a></p></div>
  <?php elseif ($done): ?>
  <div class="sl-card tv-bleed"><p>Done: <b><?= $e($s['staff_id']) ?></b> is linked to this account. Switch between them from your account menu.</p>
    <p><a class="sl-b" href="/user/accounts.php">Your accounts</a></p></div>
  <?php else: ?>
  <div class="sl-card tv-bleed">
    <p>An owner asked to link staff login <b><?= $e($s['staff_id']) ?></b> (<?= $e($s['name']) ?>) to this member account, <b><?= $e($me['email']) ?></b>.</p>
    <p>Once linked, that staff login can switch into this account from its menu without your password, and staff notices reach you here. This account still can't open the admin side.</p>
    <p>Only link it if the staff login is yours.</p>
    <p style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.7rem"><button type="button" class="sl-b go" id="sl-go">Link them</button><a class="sl-b" href="/user/dashboard.php">Not me</a></p>
  </div>
  <script>
  (function () {
    var b = document.getElementById('sl-go');
    b.addEventListener('click', async function () {
      b.disabled = true;
      try {
        var s = await (await fetch('/api/auth/session.php', { credentials: 'include' })).json();
        var r = await (await fetch('/user/api/staff-link.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': s.csrf_token }, body: JSON.stringify({ confirm: <?= json_encode($tok) ?> }) })).json();
        if (r.ok) { location.reload(); return; }
        TvAsk.say((r.error && r.error.message) || 'That didn\'t work.', { anchor: b });
      } catch (x) { TvAsk.say('That didn\'t work. Try again.', { anchor: b }); }
      b.disabled = false;
    });
  })();
  </script>
  <?php endif; ?>
</div>
<?php tv_page_end();
