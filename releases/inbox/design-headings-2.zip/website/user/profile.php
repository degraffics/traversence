<?php
// /user/profile.php?id=N — a person's public profile (decisions/0047).
// Shows only what anyone may see: their name and when they joined. Never their email, home area, saved
// places or whereabouts. Signed-in visitors get Link (follow), Connect, Message, Ask for contact info, Block.

declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/People.php';
require_once __DIR__ . '/../../app/lib/MemberVerification.php';

$pdo = Database::connection();
$id = (int) ($_GET['id'] ?? 0);
$me = Auth::currentUser();
$u = People::tableExists($pdo) ? People::user($pdo, $id) : null;
if ($u !== null && $me !== null && People::blocked($pdo, (int) $me['id'], $id) && !People::relation($pdo, (int) $me['id'], $id)['blocked']) {
    $u = null;   // they blocked you: the profile simply isn't there
}
$name = $u ? People::name($u) : 'Profile not found';
tv_page_start($name, ['no_crumbs' => true]);   // the hero says who it is (decisions/0058 §21)
if ($u === null): ?>
  <div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Profile not found</h1><p class="text-sm text-[#5C4632] mt-2">This person isn't available.</p></div>
<?php tv_page_end(); exit; endif;
$self = $me !== null && (int) $me['id'] === $id;
$rel = ($me !== null && !$self) ? People::relation($pdo, (int) $me['id'], $id) : null;
// "See it as others do" (?as=visitor): your own profile drawn as a visitor would see it, as anyone, a follower or a connection
// (?see=), with no tools of yours and their buttons shown as a preview (they do nothing here)
$preview = $self && ($_GET['as'] ?? '') === 'visitor';
$see = in_array($_GET['see'] ?? '', ['anyone', 'follower', 'connection'], true) ? (string) $_GET['see'] : 'anyone';
if ($preview) {
    $self = false;
    $rel = ['connection' => $see === 'connection' ? 'connected' : 'none', 'following' => $see !== 'anyone', 'blocked' => false, 'can_message' => true,
            'message_mode' => 'direct', 'private' => (bool) People::settings($pdo, $id)['profile_private']];
}
?>
<style>
  .pf-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1.2rem;max-width:40rem}
  .pf-av{width:64px;height:64px;border-radius:999px;background:#3E2B1F;color:#B8863B;display:flex;align-items:center;justify-content:center;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.7rem;flex:0 0 auto}
  .pf-b{font-size:.85rem;font-weight:600;border-radius:.65rem;padding:.45rem .9rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;cursor:pointer;text-decoration:none;display:inline-block}
  .pf-b.go{background:#15803D;border-color:#15803D;color:#fff}.pf-b.no{color:#991B1B;border-color:#FCA5A5}
  .pf-b[disabled]{opacity:.6;cursor:default}
  .pf-ver{display:inline-flex;align-items:center;gap:.25rem;font-size:.78rem;font-weight:700;color:#3F6F5A;background:#E4F0E9;border:1px solid #8FBCA8;border-radius:999px;padding:.05rem .55rem;margin:0 0 .2rem}
  .pf-ver svg{width:13px;height:13px}
</style>
<?php
$open = !(($rel['private'] ?? false) && ($rel['connection'] ?? '') !== 'connected') && !($rel['blocked'] ?? false);   // a private profile shows its photos to connections only
// the profile frame (draft 2026-10-09, Jason's mockup): cover, card, published details, tabs. Only what the person published shows.
require_once __DIR__ . '/../../app/lib/MemberProfile.php';
$pf2 = MemberProfile::ready($pdo);
if ($pf2) {
    require_once __DIR__ . '/../../app/ui/profile-header.php';
    $pfPub = MemberProfile::public($pdo, $id);
    if (!$open) { $pfPub['details'] = []; $pfPub['status_line'] = ''; $pfPub['cover'] = ''; }
    require_once __DIR__ . '/../../app/lib/MemberPosts.php';
    $pfPosts = MemberPosts::ready($pdo);   // Moments and Keep (decisions/0153): the profile opens on its Posts
    $pfTab = (string) ($_GET['tab'] ?? ($pfPosts ? 'posts' : 'about'));
    $pfKeys = array_filter(array_map(fn ($t) => $t[2], MemberProfile::TABS));
    if (!in_array($pfTab, $pfKeys, true) || ($pfTab === 'posts' && !$pfPosts)) $pfTab = 'about';
    ob_start();
} else {
    require_once __DIR__ . '/../../app/ui/explore-hero.php';
    require_once __DIR__ . '/../../app/lib/HeroMedia.php';
    echo tv_explore_hero($pdo, ['name' => $name, 'heading' => $name, 'edit' => false, 'empty' => $self && HeroMedia::ready($pdo) ? 'Add photos or a video to the top of your profile.' : '',
        'slides' => $open ? HeroMedia::slides($pdo, 'user', $id) : [], 'manage' => $self && HeroMedia::ready($pdo) ? ['user', $id] : null]);
} ?>
<div class="pf-card<?= $pf2 ? '' : ' tv-bleed' ?>" data-user="<?= $id ?>"<?= $pf2 ? ' style="background:none;border:0;padding:.5rem 0 0"' : '' ?>>
  <div class="flex items-center gap-4" data-link-host style="padding-right:3rem">
    <?php if (!$pf2): ?><div class="pf-av" aria-hidden="true"><?= tv_e(mb_strtoupper(mb_substr($name, 0, 1))) ?></div><?php endif; ?>
    <div class="flex-1">
      <?php /* a staff member who turned on the team badge (decisions/0105) */ try { $tvTeam = $pdo->prepare("SELECT 1 FROM " . Database::t('staff_accounts') . " WHERE member_user_id = ? AND team_badge = 1 AND status = 'active'"); $tvTeam->execute([$id]); if ($tvTeam->fetchColumn()) echo '<span class="hb-pill" style="display:inline-block;background:#DCEFE5;color:#1F5C43;border-radius:999px;padding:.1rem .55rem;font-size:.8rem;font-weight:700">Traversence team</span>'; } catch (Throwable) {} ?>
      <div class="flex items-center gap-3">
        <?php if (!$self && !$preview && !($rel['blocked'] ?? false) && !(($rel['private'] ?? false) && ($rel['connection'] ?? '') !== 'connected')): ?>
          <span data-link="person:<?= $id ?>" data-link-label="<?= tv_e($name) ?>"></span>
        <?php endif; ?>
      </div>
      <?php if (MemberVerification::verified($pdo, $id)): ?><p class="pf-ver" title="They agreed to have the details they gave us checked, and their email and age are confirmed"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg> Verified</p><?php endif; ?>
      <p class="text-sm text-[#8A7355]">Member since <?= tv_e(date('F Y', strtotime((string) $u['created_at']))) ?><?= ($rel['private'] ?? false) ? ' · private profile' : '' ?></p>
    </div>
  </div>

  <?php if ($preview): $pvBase = '/user/profile.php?id=' . $id . '&amp;as=visitor&amp;tab=' . rawurlencode((string) ($_GET['tab'] ?? 'posts')) . '&amp;see='; ?>
    <div class="mt-4" style="border:1px dashed #CBB98D;border-radius:.7rem;padding:.6rem .75rem;background:#FFFBF2">
      <p class="text-sm"><b>Preview:</b> your profile as <?= ['anyone' => 'anyone (not linked to you)', 'follower' => 'someone who follows you', 'connection' => 'one of your connections'][$see] ?> sees it. <a class="underline text-amber-800" href="/user/profile.php?id=<?= $id ?>">Back to your profile</a></p>
      <p class="text-sm mt-2" role="group" aria-label="See it as">See it as:
        <?php foreach (['anyone' => 'Anyone', 'follower' => 'A follower', 'connection' => 'A connection'] as $k => $l): ?><a class="pf-b<?= $see === $k ? ' go' : '' ?>" style="padding:.25rem .7rem;margin:.15rem .1rem" href="<?= $pvBase . $k ?>"<?= $see === $k ? ' aria-current="true"' : '' ?>><?= $l ?></a><?php endforeach; ?></p>
      <div class="flex flex-wrap gap-2 mt-2" title="Preview: this is what visitors can tap">
        <span class="pf-b" aria-disabled="true" style="opacity:.6"><?= $see === 'anyone' ? 'Follow' : 'Following' ?></span>
        <span class="pf-b<?= $see === 'connection' ? ' go' : '' ?>" aria-disabled="true" style="opacity:.6"><?= $see === 'connection' ? 'Connected' : 'Connect' ?></span>
        <span class="pf-b" aria-disabled="true" style="opacity:.6">Message</span><span class="pf-b" aria-disabled="true" style="opacity:.6">Snap</span>
      </div>
      <p class="text-xs text-[#8A7355] mt-2">Preview: these are what visitors can tap. Who can message you, and so send you a Snap, follows your message settings.</p>
    </div>
  <?php elseif ($self): ?>
    <p class="text-sm mt-4">This is how others see you. <a class="underline text-amber-800" href="/user/dashboard.php#addressbook">Your Address Book</a></p>
  <?php elseif ($me === null): ?>
    <p class="text-sm mt-4"><a class="underline text-amber-800" href="/login.php">Sign in</a> to follow, connect or message.</p>
  <?php elseif ($rel['blocked']): ?>
    <p class="text-sm mt-4">You've blocked this person.</p>
    <div class="mt-3"><button class="pf-b" data-act="unblock">Unblock</button></div>
  <?php else: ?>
    <div class="flex flex-wrap gap-2 mt-4">
      <?php if ($rel['connection'] === 'connected'): ?>
        <span class="pf-b go" style="cursor:default">Connected</span>
        <button class="pf-b" data-act="request_contact">Ask for contact info</button>
      <?php elseif ($rel['connection'] === 'asked'): ?>
        <button class="pf-b" disabled>Request sent</button>
      <?php elseif ($rel['connection'] === 'asked_you'): ?>
        <button class="pf-b go" data-act="connect">Accept connection</button>
      <?php elseif ($rel['connection'] === 'none'): ?>
        <button class="pf-b go" data-act="connect">Connect</button>
      <?php endif; ?>
      <?php if ($rel['can_message']): ?><a class="pf-b" href="/user/dashboard.php#addressbook:to=<?= $id ?>">Message</a><?php endif; ?>
      <?php if (is_file(__DIR__ . '/../../app/lib/MemberPosts.php') && (require_once __DIR__ . '/../../app/lib/MemberPosts.php') && MemberPosts::ready($pdo)): /* a Snap to them (decisions/0153 §3): a photo, video or words, just between you */ ?>
        <?php if ($rel['can_message']): ?><button type="button" class="pf-b" data-snap-to="<?= $id ?>" data-snap-name="<?= tv_e($name) ?>">Snap</button>
        <?php else: ?><button type="button" class="pf-b" disabled title="<?= tv_e($name) ?> takes messages only from people they've linked or connected with">Snap</button><?php endif; ?>
      <?php endif; ?>
      <?php if ($rel['connection'] === 'connected'): ?><button class="pf-b" data-act="disconnect">Remove connection</button><?php endif; ?>
      <span data-contact-save="person:<?= $id ?>" data-link-label="<?= tv_e($name) ?>"></span>
      <button class="pf-b no" data-act="block">Block</button>
    </div>
    <p class="text-xs text-[#8A7355] mt-3">Following shows you what they choose to share publicly. Connecting lets you share contact details with each other<?= $rel['can_message'] ? '' : ' and message' ?>.</p>
  <?php endif; ?>
  <p class="text-sm mt-2" id="pf-msg" role="status"></p>
</div>
<?php
if ($pf2) {
    $pfActions = ob_get_clean();
    echo tv_profile_open($pfPub, ['owner' => false, 'active' => array_search($pfTab, array_map(fn ($t) => $t[2], MemberProfile::TABS), true) ?: 'about', 'actions' => $pfActions]
        + ($preview ? ['base' => '/user/profile.php?id=' . $id . '&as=visitor&see=' . $see] : []));
    if (!$open) {
        echo '<div class="pf-card tv-bleed"><p class="text-sm">' . (($rel['blocked'] ?? false) ? 'You\'ve blocked this person.' : 'This profile is private. Connect to see what they share.') . '</p></div>';
    } elseif ($pfTab === 'posts') {   // their posts this visitor may see (decisions/0153); yours, with the composer
        echo '<div id="tvm-comp"></div><div id="tvm-feed"></div>'
            . '<script src="/js/tv-moments.js?v=' . (int) @filemtime(__DIR__ . '/../js/tv-moments.js') . '"></script><script>'
            . ($self ? 'TvMoments.composer(document.getElementById("tvm-comp"), ' . json_encode(['name' => $name, 'avatar' => (string) (MemberProfile::get($pdo, $id)['avatar'] ?? '')], JSON_HEX_TAG | JSON_HEX_AMP) . ');' : '')
            . 'TvMoments.feed(document.getElementById("tvm-feed"), ' . json_encode(['owner' => $id, 'self' => $self] + ($preview ? ['as' => $see] : [])) . ');</script>';
    } elseif ($pfTab === 'about') {
        $d = $pfPub['details'];
        echo '<div class="pf-card tv-bleed" style="max-width:none"><h2 class="font-serif font-bold text-lg">About</h2>'
            . (($d['about'] ?? '') !== '' ? '<p class="text-sm mt-1" style="white-space:pre-line">' . tv_e($d['about']) . '</p>' : '<p class="text-sm mt-1 text-[#8A7355]">' . ($self ? 'Nothing published yet. Add About me in your dashboard and switch on its eye.' : 'Nothing shared yet.') . '</p>')
            . '<p class="text-xs text-[#8A7355] mt-3">Member since ' . tv_e(date('F Y', strtotime((string) $u['created_at']))) . '</p></div>';
    } elseif ($pfTab === 'gallery') {   // the gallery module (decisions/0126): their public albums, then the photos they've made public
        require_once __DIR__ . '/../../app/lib/Gallery.php';
        require_once __DIR__ . '/../../app/ui/gallery-ui.php';
        if ($self) Gallery::sync($pdo, $id);
        $gAlbums = Gallery::albums($pdo, 'members', $id, false);
        $gViews = array_slice(array_map(fn ($it) => Gallery::view($it), Gallery::items($pdo, 'members', $id, 'public')), 0, 60);
        echo tv_gallery_css() . '<div class="gl pf-card tv-bleed" style="max-width:none"><div class="gl-h" style="margin:0"><h2 class="font-serif font-bold text-lg" style="margin-right:auto">Gallery</h2>'
            . ($self ? '<a class="gl-b" href="/gallery/">Manage your gallery</a>' : '') . '</div>';
        if ($gAlbums) { echo '<h3 class="gl-mo">Albums</h3><div class="gl-albums tv-bleed">'; foreach ($gAlbums as $ga) echo tv_gallery_album_card($ga, '/gallery/album.php?a=' . (int) $ga['id'], false); echo '</div>'; }
        if ($gViews) { echo '<h3 class="gl-mo">Photos &amp; videos</h3><div class="gl-rows tv-bleed">'; foreach ($gViews as $gi => $gv) echo tv_gallery_tile($gv, $gi); echo '</div>'; }
        if (!$gAlbums && !$gViews) echo '<p class="text-sm mt-1 text-[#8A7355]">' . ($self ? 'Nothing public yet. Your photos stay private until you share an album or publish them on a journey or your profile.' : 'No photos shared yet.') . '</p>';
        echo '</div><script>window.TV_GAL = ' . json_encode(['items' => Gallery::mark($pdo, $gViews, null), 'album' => null, 'own' => false, 'csrf' => '', 'me' => null, 'owner' => ($gOwn = Gallery::ownerName($pdo, 'members', $id)) !== '' ? ['name' => $gOwn] : null], JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES) . ';</script>'
            . '<script src="/js/photo-viewer.js?v=' . (int) @filemtime(__DIR__ . '/../js/photo-viewer.js') . '"></script><script src="/js/gallery.js?v=' . (int) @filemtime(__DIR__ . '/../js/gallery.js') . '"></script>';
    } elseif ($pfTab === 'videos') {   // the Channel and playlists (decisions/0153 §7)
        require_once __DIR__ . '/../../app/ui/gallery-ui.php';
        if ($self && !$preview) { try { MemberPosts::fillChannel($pdo, 'members', (string) $id, $id); } catch (Throwable $x) { error_log('fillChannel: ' . $x->getMessage()); } }
        $vh = tv_videos_section($pdo, 'members', (string) $id, $self && !$preview, '/user/profile.php?id=' . $id . '&tab=videos');
        echo $vh !== '' ? $vh : '<div class="pf-card tv-bleed" style="max-width:none"><h2 class="font-serif font-bold text-lg">Videos</h2><p class="text-sm mt-1 text-[#8A7355]">No videos shared yet.</p></div>';
    } elseif ($pfTab === 'connections') {
        echo '<div class="pf-card tv-bleed" style="max-width:none"><h2 class="font-serif font-bold text-lg">Connections</h2><p class="text-sm mt-1">'
            . ($pfPub['followers'] !== null ? (int) $pfPub['followers'] . ' ' . ((int) $pfPub['followers'] === 1 ? 'person follows' : 'people follow') . ' ' . tv_e($name) . '.' : 'Not shared.')
            . '</p><p class="text-xs text-[#8A7355] mt-2">Who someone follows is never shown.</p></div>';
    } elseif ($pfTab !== 'journeys') {
        echo '<div class="pf-card tv-bleed" style="max-width:none"><p class="text-sm">Coming.</p></div>';
    }
}
// their published journeys (decisions/0058 §1): what they chose to share, nothing else about what they do
require_once __DIR__ . '/../../app/lib/Journeys.php';
require_once __DIR__ . '/../../app/ui/journey-ui.php';
$pfJourneys = ($rel['blocked'] ?? false) || !$open ? [] : Journeys::cardsFor($pdo, 'person', $id, 24);
if ((!$pf2 || $pfTab === 'journeys') && ($pfJourneys || $self || $pf2)):
    echo tv_journey_css(); ?>
<section class="<?= $pf2 ? "" : "mt-6" ?>" style="max-width:64rem" aria-labelledby="pf-j">
  <h2 id="pf-j" class="font-serif font-bold text-xl text-[#3E2B1F] mb-3">Journeys<?= $pfJourneys ? ' <span class="text-sm font-normal text-[#8A7355]">' . count($pfJourneys) . '</span>' : '' ?></h2>
  <?php if ($pfJourneys): ?><div class="jr-grid"><?php foreach ($pfJourneys as $it) echo tv_journey_card($it); ?></div>
  <?php else: ?><p class="jr-empty"><?= $self ? 'Your published journeys show here, and on Let&rsquo;s Explore for their place. <a class="underline" href="/user/journeys/">Your journeys</a>' : 'No journeys shared yet.' ?></p><?php endif; ?>
</section>
<?php endif;
if ($pf2) echo tv_profile_close(); ?>
<script>
(function () {
  var card = document.querySelector('.pf-card'), msg = document.getElementById('pf-msg'), csrf = null;
  var CONFIRM = { block: 'Block this person? It removes follows, your connection and any shared contact details, both ways.',
                  disconnect: 'Remove this connection? Contact details you shared with each other are taken back.' };
  fetch('/user/api/links.php?check=', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { csrf = d.csrf; });
  card.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-act]'); if (!b) return;
    var act = b.getAttribute('data-act');
    if (CONFIRM[act] && !TvAsk.gate(b, CONFIRM[act], { yes: act === 'block' ? 'Block' : 'Remove', danger: true })) return;
    b.disabled = true;
    fetch('/user/api/people.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' },
      body: JSON.stringify({ action: act, user_id: +card.getAttribute('data-user') }) })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error(d.error && d.error.message); return d; }); })
      .then(function () { if (act === 'request_contact') { msg.textContent = 'Asked. They choose what to share.'; } else { location.reload(); } })
      .catch(function (err) { msg.textContent = err.message || 'Something went wrong.'; b.disabled = false; });
  });
})();
</script>
<script src="/js/link-button.js" defer></script>
<script>
document.addEventListener('click', function (e) {   // Snap: the composer addressed to them, loaded when first wanted
  var b = e.target.closest('[data-snap-to]'); if (!b) return;
  var go = function () { TvMoments.snapTo(+b.getAttribute('data-snap-to'), b.getAttribute('data-snap-name')); };
  if (window.TvMoments) return go();
  var s = document.createElement('script'); s.src = '/js/tv-moments.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-moments.js') ?>'; s.onload = go; document.head.appendChild(s);
});
</script>
<?php tv_page_end();
