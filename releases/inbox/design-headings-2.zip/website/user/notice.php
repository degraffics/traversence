<?php
// user/notice.php — a member's notice of action (decisions/0079): what happened, what to do and by when, the three
// steps and where they are, and the two ways forward: confirm the steps, or ask a person to review it. Reached from
// the bar on every page, the Pulse, or (when access is revoked and they can't sign in) the link in the email.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/../../app/lib/Standing.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';

$pdo = Database::connection();
$me = Auth::currentUser();
$token = preg_match('/^[a-f0-9]{40}$/', (string) ($_GET['t'] ?? '')) ? (string) $_GET['t'] : '';
$a = null; $byLink = false;
if (Standing::ready($pdo)) {
    if ($token !== '') { $a = Standing::byToken($pdo, $token); $byLink = (bool) $a; }
    elseif ($me) { $a = Standing::current($pdo, (int) $me['id']); }
}
$n = $a ? Standing::shape($a) : null;
$hist = (!$byLink && $me && Standing::ready($pdo)) ? array_values(array_filter(Standing::history($pdo, (int) $me['id'], 5), fn ($h) => !$n || $h['id'] !== $n['id'])) : [];
$e = 'tv_e';
$when = function (?string $t): string {
    if (!$t) return '';
    $s = strtotime($t) - time();
    $abs = date('M j, g:i a', strtotime($t));
    return $abs . ($s > 0 ? ' (in ' . ($s >= 3600 ? (int) floor($s / 3600) . ' h ' : '') . (int) floor(($s % 3600) / 60) . ' min)' : '');
};
tv_page_start('Your account notice', ['no_crumbs' => true, 'section' => 'member', 'description' => 'A notice about your Traversence account.']);
?>
<style>
  .nt{max-width:44rem;color:#3E2B1F}
  .nt-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.9rem;padding:.9rem 1rem;margin-top:.7rem}
  .nt-card.hot{background:#FFF8EA;border-color:#F3D9A4}
  .nt-h{font:700 1.05rem var(--tv-font-head,Georgia,serif);margin:0 0 .3rem}
  .nt p{margin:.35rem 0;font-size:.95rem;line-height:1.55}
  .nt-ladder{display:grid;grid-template-columns:repeat(3,1fr);gap:.35rem;margin-top:.6rem;padding:0;list-style:none}
  .nt-ladder li{border:1px solid #EADFC4;background:#FFFBF2;border-radius:.6rem;padding:.45rem .5rem;font-size:.8rem;color:#5C4632}
  .nt-ladder li b{display:block;font-size:.85rem;color:#3E2B1F}
  .nt-ladder li.on{background:#3E2B1F;border-color:#3E2B1F;color:#EADFC4}.nt-ladder li.on b{color:#FFF8EA}
  .nt-ladder li.past{opacity:.6}
  .nt-pill{display:inline-block;font-size:.75rem;font-weight:700;border-radius:999px;padding:.1rem .55rem;background:#EADFC4;color:#5C4632}
  .nt-pill.red{background:#FEE2E2;color:#991B1B}.nt-pill.ok{background:#DCEFE5;color:#1F5C43}
  .nt-b{display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem;border-radius:.65rem;padding:.55rem .95rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;cursor:pointer}
  .nt-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}
  .nt-acts{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.7rem}
  .nt-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.55rem .7rem;font-size:.95rem;color:#3E2B1F}
  .nt-msg{font-size:.88rem;margin-top:.4rem;color:#5C4632}
  @media (max-width:420px){ .nt-ladder{grid-template-columns:1fr} }
</style>
<div class="nt">
  <h1 class="font-serif font-bold text-3xl">Your account notice</h1>
<?php if (!Standing::ready($pdo)): ?>
  <div class="nt-card"><p>There's nothing here yet.</p></div>
<?php elseif (!$n && $token !== ''): ?>
  <div class="nt-card"><p>That link isn't valid any more (a newer one may have been sent). Enter your account's email below and we'll send the link again.</p></div>
<?php elseif (!$n && !$me): ?>
  <div class="nt-card"><p>If access to your account was revoked, we emailed you what happened, how to recover, and a link to ask for a review. If you can't find it, enter your account's email and we'll send it again.</p></div>
<?php elseif (!$n): ?>
  <div class="nt-card"><p class="font-bold">Your account is in good standing.</p><p>There's no notice on it.</p></div>
<?php else:
  $st = $n['step']; $open = in_array($n['status'], ['open', 'review'], true); ?>
  <div class="nt-card<?= $open ? ' hot' : '' ?>">
    <p><span class="nt-pill <?= $st >= 2 && $open ? 'red' : '' ?>"><?= $e($n['step_label']) ?></span> <span class="nt-pill <?= in_array($n['status'], ['corrected', 'lifted'], true) ? 'ok' : '' ?>"><?= $e($n['status_label']) ?></span></p>
    <h2 class="nt-h mt-2">What happened</h2>
    <p><?= $e($n['reason']) ?></p>
    <h2 class="nt-h mt-3">What to do</h2>
    <p><?= preg_replace('#\((/[a-z][^\s)]*)\)#', '(<a class="underline text-[#92400E]" href="$1">open them</a>)', $e($n['steps'])) ?></p>
    <?php if ($n['status'] === 'open' && $n['due_at'] && $st < 3): ?>
      <p class="font-bold">Please confirm by <?= $e($when($n['due_at'])) ?>. <?= $st === 1 ? 'If we don\'t hear from you, posting, commenting and messaging stop, with a final warning.' : 'This is the final warning: if we don\'t hear from you, access to your account is revoked.' ?></p>
    <?php elseif ($n['status'] === 'review'): ?>
      <p class="font-bold">You asked for a review on <?= $e(date('M j, g:i a', strtotime((string) $n['review_asked_at']))) ?>. Nothing more happens until a person at Traversence has looked at it; they'll reply by email.</p>
    <?php elseif ($n['status'] === 'closed' && $n['decided_at']): ?>
      <p class="font-bold">Reviewed on <?= $e(date('M j', strtotime((string) $n['decided_at']))) ?>: the action stands.</p><?php if ($n['decision_note']): ?><p><?= $e($n['decision_note']) ?></p><?php endif; ?>
    <?php elseif ($n['status'] === 'lifted'): ?>
      <p class="font-bold">Reviewed and lifted. Your account is fully restored.</p><?php if ($n['decision_note']): ?><p><?= $e($n['decision_note']) ?></p><?php endif; ?>
    <?php elseif ($n['status'] === 'corrected'): ?>
      <p class="font-bold">You confirmed the steps. Thank you: this notice is closed.</p>
    <?php endif; ?>
    <?php if ($st >= 2 && $open && $st < 3): ?><p>While limited you can still browse, save and read your messages, but you can't post, comment or send messages.</p><?php endif; ?>
    <?php if ($st >= 3 && $open): ?><p>Access is revoked, so you can't sign in. Your posts aren't deleted.</p><?php endif; ?>

    <ol class="nt-ladder" aria-label="The three steps">
      <?php foreach ([1 => ['Warning', '24 hours to confirm the steps or ask for a review'], 2 => ['Limited', 'No posting or messaging; a final warning and 24 more hours'], 3 => ['Access revoked', 'An email with how to recover and a review link']] as $k => [$t, $d]): ?>
      <li class="<?= $k === $st ? 'on' : ($k < $st ? 'past' : '') ?>"><b><?= $k ?>. <?= $e($t) ?></b><?= $e($d) ?></li>
      <?php endforeach; ?>
    </ol>

    <?php if ($n['status'] === 'open'): ?>
    <div class="nt-acts">
      <?php if ($st < 3 && !$byLink): ?><button type="button" class="nt-b go" id="nt-ok" data-id="<?= $n['id'] ?>">I'll follow these steps</button><?php endif; ?>
      <button type="button" class="nt-b" id="nt-rv-open">Ask for a review</button>
    </div>
    <div id="nt-rv" hidden class="mt-3">
      <label class="text-sm font-bold" for="nt-text">Why should we look again?</label>
      <textarea id="nt-text" class="nt-in mt-1" rows="4" maxlength="1000" placeholder="Tell us what we got wrong, or what you've put right."></textarea>
      <div class="nt-acts"><button type="button" class="nt-b go" id="nt-send" data-id="<?= $n['id'] ?>">Send for review</button></div>
      <p class="nt-msg">Asking stops the clock: nothing more happens until a person has looked at it. They'll reply by email.</p>
    </div>
    <?php endif; ?>
    <p class="nt-msg" id="nt-msg" role="status"></p>
  </div>
<?php endif; ?>

<?php if (!$me && (!$n || $token !== '')): ?>
  <div class="nt-card">
    <label class="text-sm font-bold" for="nt-email">Send me the review link again</label>
    <input id="nt-email" class="nt-in mt-1" type="email" autocomplete="email" placeholder="Your account's email">
    <div class="nt-acts"><button type="button" class="nt-b go" id="nt-resend">Send it</button></div>
    <p class="nt-msg" id="nt-msg2" role="status"></p>
  </div>
<?php endif; ?>

<?php if ($hist): ?>
  <h2 class="font-serif font-bold text-lg mt-5">Earlier notices</h2>
  <?php foreach ($hist as $h): ?>
  <div class="nt-card"><p><span class="nt-pill"><?= $e($h['step_label']) ?></span> <span class="nt-pill"><?= $e($h['status_label']) ?></span> <small class="text-[#8A7355]"><?= $e(date('M j, Y', strtotime($h['created_at']))) ?></small></p><p><?= $e($h['reason']) ?></p></div>
  <?php endforeach; ?>
<?php endif; ?>
  <p class="text-sm text-[#5C4632] mt-4">How notices work: <a class="underline text-[#92400E]" href="/faq.php#can-my-account-be-limited-or-revoked">Can my account be limited or revoked?</a></p>
</div>
<script>
(function () {
  var token = <?= json_encode($byLink ? $token : '') ?>, csrf = null;
  function tok() { return csrf ? Promise.resolve(csrf) : fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrf = d.csrf_token || ''); }); }
  function post(body) {
    return tok().then(function (c) { return fetch('/user/api/notice.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); })
      .then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work.'); return j; });
  }
  var msg = document.getElementById('nt-msg');
  var ok = document.getElementById('nt-ok');
  if (ok) ok.addEventListener('click', function () {
    if (!TvAsk.gate(ok, 'Confirm you\'ll follow these steps?', { yes: 'Confirm' })) return;
    post({ do: 'confirm', id: +ok.getAttribute('data-id') }).then(function () { location.reload(); }).catch(function (x) { msg.textContent = x.message; });
  });
  var ro = document.getElementById('nt-rv-open');
  if (ro) ro.addEventListener('click', function () { var f = document.getElementById('nt-rv'); f.hidden = !f.hidden; if (!f.hidden) document.getElementById('nt-text').focus(); });
  var send = document.getElementById('nt-send');
  if (send) send.addEventListener('click', function () {
    var body = { do: 'review', text: document.getElementById('nt-text').value };
    if (token) body.token = token; else body.id = +send.getAttribute('data-id');
    send.disabled = true;
    post(body).then(function () { location.reload(); }).catch(function (x) { send.disabled = false; msg.textContent = x.message; });
  });
  var rs = document.getElementById('nt-resend');
  if (rs) rs.addEventListener('click', function () {
    var m2 = document.getElementById('nt-msg2');
    post({ do: 'resend', email: document.getElementById('nt-email').value }).then(function () { m2.textContent = 'If that email belongs to an account whose access was revoked, the link is on its way (once an hour at most).'; })
      .catch(function (x) { m2.textContent = x.message; });
  });
})();
</script>
<?php tv_page_end();
