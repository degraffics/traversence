<?php
// user/transfer.php — someone asked to take over a business answers (decisions/0103 §2 "By hand", 0120). From the email,
// signed in as the account it was sent to: what taking over means, then Accept or Decline. Nothing changes until they
// accept; then they're its Owner, the one before stays on as Manager, and the team is told.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Team.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
header('Content-Type: text/html; charset=utf-8');

$tid = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$me = Auth::currentUser();
if (!$me) { header('Location: /login.php?next=' . rawurlencode('/user/transfer.php?id=' . $tid), true, 303); exit; }
$pdo = Database::connection();
$uid = (int) $me['id'];
$t = $tid ? Team::transfer($pdo, $tid) : null;
$mine = $t && (int) $t['to_user'] === $uid;
$err = '';
if ($mine && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    try {
        if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $yes = ($_POST['do'] ?? '') === 'accept';
        Team::answerTransfer($pdo, $tid, $uid, $yes);
        if ($yes) {
            require_once __DIR__ . '/../../app/lib/Roles.php';
            try { Roles::setCurrent($pdo, $uid, 'entity:' . (int) $t['ref']); } catch (Throwable) {}
            header('Location: /business/' . (int) $t['ref'] . '/settings', true, 303); exit;
        }
        $t = Team::transfer($pdo, $tid);
    } catch (RuntimeException $x) { $err = $x->getMessage(); }
}
$open = $mine && !$t['accepted_at'] && !$t['declined_at'] && !$t['cancelled_at'] && strtotime((string) $t['expires_at']) > time();
$plan = '';
if ($open) { try { require_once __DIR__ . '/../../app/lib/Billing.php'; $s = Billing::current($pdo, 'listing', (int) $t['ref']); if ($s && in_array($s['status'], ['trial', 'active', 'past_due'], true)) $plan = (string) (Billing::PLANS[$s['plan']][0] ?? $s['plan']); } catch (Throwable) {} }
$csrf = (string) ($_SESSION['csrf_token'] ??= bin2hex(random_bytes(32)));
$e = 'tv_e';
tv_page_start('Take over a business', ['no_crumbs' => true, 'section' => 'member', 'description' => 'Answer a request to take over a business on Traversence.']);
?>
<style>
  .xf{max-width:40rem;color:#3E2B1F}
  .xf-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.9rem;padding:.9rem 1rem;margin-top:.7rem}
  .xf h1{font:700 1.3rem var(--tv-font-head,Georgia,serif);margin:.4rem 0}
  .xf p,.xf li{font-size:.95rem;line-height:1.55}.xf ul{margin:.3rem 0 .3rem 1.1rem;list-style:disc}
  .xf-b{display:inline-block;border-radius:.6rem;padding:.5rem .9rem;font-weight:600;font-size:.9rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;text-decoration:none;cursor:pointer}
  .xf-b.go{background:#92400E;border-color:#92400E;color:#fff}
  .xf-err{background:#F6DADA;color:#7F1D1D;border-radius:.7rem;padding:.6rem .8rem;margin-top:.7rem;font-weight:600}
</style>
<div class="xf">
  <h1>Take over a business</h1>
  <?php if ($err): ?><div class="xf-err" role="alert"><?= $e($err) ?></div><?php endif; ?>
  <?php if (!$mine): ?>
  <div class="xf-card tv-bleed"><p>This request isn't for the account you're signed in as (<b><?= $e($me['email']) ?></b>). Sign in as the account the email went to.</p></div>
  <?php elseif (!$open): ?>
  <div class="xf-card tv-bleed"><p><?= $t['accepted_at'] ? 'You accepted: you\'re the Owner of <b>' . $e($t['biz']) . '</b>.' : ($t['declined_at'] ? 'You declined this request.' : 'This request isn\'t open any more (it was cancelled or it lapsed).') ?></p>
    <?php if ($t['accepted_at']): ?><p><a class="xf-b go" href="/business/<?= (int) $t['ref'] ?>">Open <?= $e($t['biz']) ?></a></p><?php endif; ?></div>
  <?php else: ?>
  <div class="xf-card tv-bleed">
    <p><b><?= $e(trim((string) $t['from_name']) ?: $t['from_email']) ?></b> asks you to take over <a class="underline" href="/listing/view.php?id=<?= (int) $t['ref'] ?>"><b><?= $e($t['biz']) ?></b></a> on Traversence as its Owner.</p>
    <p>If you accept:</p>
    <ul>
      <li>You're its Owner: its listing, tools, team, plan and data are yours to run.</li>
      <li><?= $e(trim((string) $t['from_name']) ?: 'They') ?> stays on the team as Manager (and can leave, or you can take them off).</li>
      <?php if ($plan): ?><li>Its <?= $e($plan) ?> plan was paid with their card, which comes off it. The plan runs to the end of the period that's paid; to keep it after that, add your card on its Plans page.</li><?php endif; ?>
      <li>Everyone on its team is told.</li>
    </ul>
    <p>Nothing changes until you accept. This request lapses on <?= $e(date('F j', strtotime((string) $t['expires_at']))) ?>.</p>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.7rem">
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="do" value="accept"><button class="xf-b go" data-confirm="Take over <?= $e($t['biz']) ?> as its Owner?" data-yes="Yes, take it over">Accept</button></form>
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="do" value="decline"><button class="xf-b" data-confirm="Decline? They stay the Owner." data-yes="Decline" data-danger>Decline</button></form>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php tv_page_end();
