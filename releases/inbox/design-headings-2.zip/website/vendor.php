<?php
// /vendor.php?v=… — a vendor's own page (decisions/0150): every work order we've sent them, open ones first, each opening
// the full work order (/wo.php). A private link, one per vendor, emailed from orders@ with each work order or from
// Back-Office → Vendors. It works for 30 days; after that this page offers Request a new link, which emails a fresh one
// to the vendor's address on file (never shown here), a few a day. Never a dead end (Jason, 2026-11-09): every state
// also offers Send a new link to my email and Ask our team (Vendors::helpBox). No prices, no client billing, no client contacts.
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/Vendors.php';
require_once __DIR__ . '/../app/lib/WorkOrders.php';
header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$pdo = Database::connection();
$tok = (string) ($_GET['v'] ?? '');
$v = Vendors::byLink($pdo, $tok);
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$self = '/vendor.php?v=' . rawurlencode($tok);

// the help box (any state): a new link to my email, or a note to our team
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['help'])) {
    $_SESSION['tv_vd_flash'] = Vendors::handleHelp($pdo, $_POST);
    header('Location: ' . $self, true, 303); exit;
}

// open one: its full work order, with a working link (renewed when its own has run out)
if ($v && !$v['expired'] && isset($_GET['wo']) && ctype_digit((string) $_GET['wo'])) {
    $st = $pdo->prepare("SELECT * FROM order_work_orders WHERE id = ? AND vendor_id = ? AND status <> 'draft'"); $st->execute([(int) $_GET['wo'], (int) $v['id']]);
    if ($w = $st->fetch(PDO::FETCH_ASSOC)) {
        try { header('Location: ' . WorkOrders::urlForVendor($pdo, $w), true, 303); exit; }
        catch (Throwable $x) { error_log('vendor page open: ' . $x->getMessage()); }
    }
    $_SESSION['tv_vd_flash'] = ['error', 'That work order isn\'t open to you any more. Ask our team below if you need it.'];
    header('Location: ' . $self, true, 303); exit;
}

// Request a new link: emailed to the address on file, a few a day, each logged
if ($v && $v['expired'] && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $msg = ['ok', 'We\'ve sent a new link to the email address we have for you. It works for ' . Vendors::LINK_DAYS . ' days.'];
    try {
        if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        if (!Vendors::mayRequest($pdo, 'vendor', (int) $v['id'])) { Vendors::logRequest($pdo, 'vendor', (int) $v['id'], false); throw new RuntimeException('We\'ve already sent ' . Vendors::REQUESTS_A_DAY . ' new links today. Check your email (and spam), or ask our team below and we\'ll send one by hand.'); }
        if (!(int) $v['active']) throw new RuntimeException('We don\'t have work for you at the moment. If that\'s wrong, ask our team below.');
        Vendors::emailLink($pdo, $v, null);
    } catch (Throwable $x) {
        if (!($x instanceof RuntimeException) || $x instanceof PDOException) error_log('vendor new link: ' . $x->getMessage());
        $msg = ['error', $x instanceof RuntimeException && !($x instanceof PDOException) ? $x->getMessage() : 'That didn\'t go through. Try again, or ask our team below.'];
    }
    $_SESSION['tv_vd_flash'] = $msg;
    header('Location: ' . $self, true, 303); exit;   // the old link: it now shows the notice and the button again
}
$ok = ''; $err = '';
if (isset($_SESSION['tv_vd_flash'])) { [$k, $m] = $_SESSION['tv_vd_flash']; unset($_SESSION['tv_vd_flash']); if ($k === 'ok') $ok = $m; else $err = $m; }

header('Content-Type: text/html; charset=utf-8');
if (!$v) http_response_code(404); elseif ($v['expired']) http_response_code(410);
$rows = $v && !$v['expired'] && WorkOrders::statusReady($pdo) ? Vendors::workOrders($pdo, (int) $v['id']) : [];
$open = ['sent', 'accepted', 'production', 'shipped', 'ready'];
$from = getenv('ORDERS_REPLY_TO') ?: (getenv('SMTP_REPLY_TO') ?: 'support@traversence.com');
$hid = '<input type="hidden" name="csrf" value="' . $e((string) ($_SESSION['csrf_token'] ?? '')) . '">';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$help = fn (bool $open) => Vendors::helpBox($csrf, $v ? 'the work orders page of ' . $v['name'] . ' (vendor #' . (int) $v['id'] . ')' : 'a vendor page with a link we don\'t know', $open);
$tone = fn (string $s) => in_array($s, ['declined', 'rejected', 'cancelled'], true) ? ' bad' : ($s === 'sent' ? ' warn' : '');
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow">
<title><?= $v ? 'Work orders for ' . $e($v['name']) : 'Work orders' ?> · Traversence</title>
<style>
  :root{--ink:#3E2B1F;--brown:#92400E;--line:#E3D3AC;--cream:#FBF6EA;--card:#FFFDF8}
  *{box-sizing:border-box}
  body{margin:0;background:var(--cream);color:var(--ink);font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
  main{max-width:52rem;margin:0 auto;padding:1rem 3px 2rem}
  header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-end;gap:.5rem;border-bottom:2px solid var(--ink);padding:0 .6rem .5rem;margin-bottom:.8rem}
  h1{font:700 1.6rem var(--tv-font-head,Georgia,serif);margin:0}
  h2{font:700 .78rem system-ui,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#7A5A3A;margin:0 0 .4rem}
  .note{font-size:.88rem;color:#6B5640}
  .card{background:var(--card);border:1px solid var(--line);border-radius:.5rem;padding:.8rem;margin:0 0 3px}
  .wo{display:flex;gap:.6rem;align-items:flex-start;justify-content:space-between;padding:.6rem 0;border-top:1px solid var(--line)}
  .wo:first-of-type{border-top:0;padding-top:0}
  .wo a.nm{font:700 1.05rem var(--tv-font-head,Georgia,serif);color:var(--brown);text-decoration:underline;overflow-wrap:anywhere}
  .wo .pj{display:block;font-weight:600}
  .wo .due{display:block;font-size:.88rem;color:#6B5640}
  .st{display:inline-block;flex:none;border-radius:999px;padding:.15rem .7rem;font-weight:700;font-size:.85rem;background:#E7F3EC;color:#1F5133;white-space:nowrap}
  .st.warn{background:#FEF3C7;color:#7A4B00}.st.bad{background:#FBE3E3;color:#7F1D1D}
  button.go{background:var(--brown);color:#fff;border:0;border-radius:999px;padding:.5rem 1.1rem;font:700 .95rem system-ui,sans-serif;cursor:pointer}
  <?= Vendors::HELP_CSS ?>
  .msg{border-radius:.4rem;padding:.6rem .8rem;margin:0 0 3px;font-weight:600}.msg.ok{background:#E3F1D9;border:1px solid #A9D18E}.msg.err{background:#FBE3E3;border:1px solid #E7A9A9}
</style></head>
<body><main>
  <header><div><h1>Traversence</h1><?php if ($v): ?><div class="note">Work orders for <?= $e($v['name']) ?></div><?php endif; ?></div></header>
  <?php if ($ok !== ''): ?><p class="msg ok" role="status">✓ <?= $e($ok) ?></p><?php endif; ?><?php if ($err !== ''): ?><p class="msg err" role="alert">! <?= $e($err) ?></p><?php endif; ?>
<?php if (!$v && $ok !== ''): ?>
  <div class="card"><p style="margin:0">Open the link in that email. This one no longer works.</p></div>
  <?= $help(false) ?>
<?php elseif (!$v): ?>
  <div class="card"><p style="margin:0">This link isn't right, or a newer one has replaced it. Use the link in our latest email, or get a new one here.</p></div>
  <?= $help(true) ?>
<?php elseif ($v['expired']): ?>
  <div class="card"><h2>This link has expired</h2><p style="margin:0 0 .7rem">Your link to our work orders works for <?= (int) Vendors::LINK_DAYS ?> days. We'll email a new one to the address we have for you.</p>
    <form method="post"><?= $hid ?><button class="go">Request a new link</button></form>
  </div>
  <?= $help($err !== '') ?>
<?php else: $shown = ['open' => false, 'done' => false]; ?>
  <?php if (!$rows): ?><div class="card"><p style="margin:0">No work orders from us right now. When we send one, it shows here and in your email.</p></div><?php endif; ?>
  <?php foreach ([['open', 'Open'], ['done', 'Finished in the last 90 days']] as [$grp, $label]):
      $list = array_values(array_filter($rows, fn ($w) => in_array((string) $w['status'], $open, true) === ($grp === 'open')));
      if (!$list) continue; ?>
  <section class="card" aria-labelledby="g-<?= $grp ?>"><h2 id="g-<?= $grp ?>"><?= $e($label) ?> (<?= count($list) ?>)</h2>
    <?php foreach ($list as $w): $s = (string) $w['status']; $due = WorkOrders::dueAt($w); ?>
    <div class="wo"><div><a class="nm" href="<?= $e($self) ?>&amp;wo=<?= (int) $w['id'] ?>">Work order <?= $e($w['wo_no']) ?></a>
      <?php if (($w['project'] ?? '') !== ''): ?><span class="pj"><?= $e($w['project']) ?></span><?php endif; ?>
      <span class="due"><?= $due ? 'Must have by ' . $e(date('l, F j', $due)) : 'Sent ' . $e(date('F j', strtotime((string) ($w['sent_at'] ?: $w['created_at'])))) ?><?= ($w['job_no'] ?? '') !== '' ? ' · your job ' . $e($w['job_no']) : '' ?></span></div>
      <span class="st<?= $tone($s) ?>"><?= $e(WorkOrders::STATUS[$s] ?? $s) ?></span></div>
    <?php endforeach; ?>
  </section>
  <?php endforeach; ?>
  <?= $err !== '' ? $help(true) : '' ?>
  <p class="note" style="margin:.6rem .6rem 0">This link works until <?= $e(date('F j, Y', strtotime((string) $v['portal_expires_at']))) ?>. Bill Traversence; never contact our client directly. Questions? <a href="mailto:<?= $e($from) ?>"><?= $e($from) ?></a></p>
<?php endif; ?>
</main></body></html>
