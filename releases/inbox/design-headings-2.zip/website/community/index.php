<?php
// /community/ — public community groups (decisions/0047): find, join, or start one. Starting one writes its first
// charter (decisions/0137 §3), as yourself or as a business you run (its one group, 0137 §1).
// Searching by topic and place (decisions/0136 §4): with a place, local groups and chapters there and nearby come first,
// nearest first, then groups about places nearby, then interest groups that match ("Anywhere"). Cards show a group's
// tags and, for a chapter, the group it's part of; a topic shows its popular tags.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';

tv_page_start('Community groups', ['no_crumbs' => true]);   // no breadcrumbs (decisions/0058 §11)
?>
<style>
  .cg-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem 1.1rem}
  .cg-in{width:100%;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem .7rem;background:#FFFBF2;font-size:.9rem}
  .cg-b{font-size:.85rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;border-radius:.6rem;padding:.45rem .9rem;cursor:pointer;white-space:nowrap}
  .cg-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#EFE3C8}
  .cg-list{display:grid;gap:.6rem;grid-template-columns:repeat(auto-fill,minmax(16rem,1fr))}
  .cg-g{display:block;background:#E3D3AC;border:1px solid #CBB98D;border-radius:.9rem;padding:.8rem .95rem;color:#3E2B1F}
  .cg-g:hover{border-color:#B45309}
  .cg-gn{color:#92400E;text-decoration:underline}
  .cg-card,.cg-g{border-radius:.5rem}
  .cg-chip{font-size:.78rem;border:1px solid #CBB98D;background:#FFFBF2;border-radius:999px;padding:.25rem .7rem;cursor:pointer;color:#3E2B1F}
  .cg-chip.on{background:#3E2B1F;border-color:#3E2B1F;color:#EFE3C8}
  #cg-mine .cg-b{display:inline-block;max-width:100%;overflow:hidden;text-overflow:ellipsis;vertical-align:top}
  .cg-h{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.1rem;color:#3E2B1F;margin:.9rem 0 .4rem}.cg-s{font-size:.75rem;color:#8A7355}
</style>
<div class="max-w-4xl space-y-4">
  <div>
    <h1 class="font-serif font-bold text-2xl sm:text-3xl text-[#3E2B1F]">Community groups</h1>
    <p class="text-sm text-[#5C4632] mt-1">Groups for any interest, pastime or cause, and local groups for a town or area. Anyone can find a group; only members see its posts and who belongs. Joining lets that group's members see your name there, never your email or where you are.</p>
  </div>
  <p id="cg-here" class="text-sm text-[#5C4632]"></p>
  <form id="cg-find" style="display:flex;gap:.5rem"><input class="cg-in" style="flex:1;min-width:0" name="q" placeholder="Find a group"><button class="cg-b" type="submit">Find</button></form>
  <div id="cg-mine"></div>
  <div id="cg-topics" style="display:flex;flex-wrap:wrap;gap:.35rem"></div>
  <div id="cg-pop" style="display:flex;flex-wrap:wrap;gap:.35rem;align-items:center"></div>
  <div id="cg-all"><p class="text-sm">Loading…</p></div>
  <div id="cg-new" class="cg-card" hidden>
    <h2 class="font-serif font-bold text-lg text-[#3E2B1F]">Start a group</h2>
    <form class="space-y-2 mt-2" autocomplete="off">
      <input class="cg-in" name="name" maxlength="80" required placeholder="Name, e.g. White Mountains Trail Runners">
      <label class="text-sm block" data-as hidden>Start it as <select class="cg-in" name="as" style="width:auto"><option value="0">Myself</option></select>
        <span class="cg-s block">A business has one group, run by its team; you'll add chapters for its places and topics later.</span></label>
      <textarea class="cg-in" name="about" rows="3" maxlength="1000" placeholder="What it's about, and who it's for"></textarea>
      <label class="text-sm block" data-kind>Kind of group <select class="cg-in" name="kind" style="width:auto"><option value="interest">Interest group</option><option value="local">Local group</option><option value="support">Support group</option></select></label>
      <h3 class="font-serif font-bold text-[#3E2B1F] mt-3">Its charter</h3>
      <p class="cg-s">What people read before joining. You can change any of it later on the group's page; members are told.</p>
      <label class="text-sm block">Purpose <textarea class="cg-in" name="purpose" rows="2" maxlength="600" required placeholder="What the group is for, in a sentence or two"></textarea></label>
      <label class="text-sm block">Who it's for <input class="cg-in" name="who_for" maxlength="200"></label>
      <label class="text-sm block">House rules <span class="cg-s">one per line</span><textarea class="cg-in" name="house_rules" rows="3"></textarea></label>
      <label class="text-sm block">If you step down <select class="cg-in" name="transfer" style="width:auto"></select></label>
      <p class="cg-s">Every charter also carries Traversence's ground rules (no harassment, no one's private information, no sacred sites, selling only through Traversence). Who sees the member list, reports and selling are set on the group's page.</p>
      <label class="text-sm block">Topic <select class="cg-in" name="topic" style="width:auto"></select></label>
      <label class="text-sm flex items-center gap-2"><input type="checkbox" name="approval"> New members need my approval</label>
      <p data-verify hidden class="text-sm" data-tv-status="info" data-tv-label="First:">Running a community needs a confirmed email: open the link we sent you, or send it again from <a class="underline" href="/login.php">Sign in</a>.</p>
      <button class="cg-b go" type="submit">Create group</button>
      <p class="cg-s">Public places and events only: never pinpoint sacred or restricted sites. Tribal nations' own groups are theirs to start.</p>
    </form>
  </div>
</div>
<script src="/js/tv-pager.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-pager.js') ?>"></script>
<script>
(function () {
  var qs = new URLSearchParams(location.search), API = '/user/api/community.php', csrf = null, place = qs.get('place') || '', topic = qs.get('topic') || '', lastQ = '', started = false;
  // the starting charter for the kind of group (or the business), filled into the form for the owner to edit
  function startCharter(first) {
    var f = document.querySelector('#cg-new form'); if (!f) return;
    var as = +(f.as ? f.as.value : 0), kind = as ? 'business' : f.kind.value;
    fetch(API + '?start=1&kind=' + kind + (as ? '&listing=' + as : ''), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) return;
      if (first) {
        var free = (d.businesses || []).filter(function (b) { return !b.group_id; });
        if (free.length) { f.as.innerHTML += free.map(function (b) { return '<option value="' + b.id + '">' + esc(b.name) + '</option>'; }).join(''); f.querySelector('[data-as]').hidden = false; }
        f.transfer.innerHTML = Object.keys(d.options.transfer).filter(function (k) { return k !== 'successor'; }).map(function (k) { return '<option value="' + k + '">' + esc(d.options.transfer[k]) + '</option>'; }).join('');
      }
      var t = d.template;
      f.who_for.value = t.who_for || ''; f.house_rules.value = (t.house_rules || []).join('\n'); f.transfer.value = t.transfer || 'end';
      f.querySelector('[data-kind]').hidden = !!as;
    });
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  var WHERE = { here: 'Here', near: 'Nearby', about: 'Talks about places nearby', anywhere: 'Anywhere' };
  function card(g) {
    return '<a class="cg-g" href="/community/group.php?id=' + g.id + '&src=' + (place ? 'place' : 'search') + '"><b class="font-serif cg-gn">' + esc(g.name) + '</b>'
      + '<span class="cg-s block">' + (g.where ? '<b>' + esc(WHERE[g.where] || '') + '</b> · ' : '') + g.members + ' member' + (g.members === 1 ? '' : 's') + (g.join_mode === 'approval' ? ' · ask to join' : '') + (g.topic_label ? ' · ' + esc(g.topic_label) : '') + '</span>'
      + (g.parent ? '<span class="cg-s block">Part of ' + esc(g.parent.name) + '</span>' : '')
      + (g.about ? '<span class="text-xs text-[#5C4632] block mt-1">' + esc(g.about) + '</span>' : '')
      + (g.tags && g.tags.length ? '<span class="cg-s block mt-1">' + g.tags.map(function (t) { return '#' + esc(t); }).join(' ') + '</span>' : '') + '</a>';
  }
  function load(q) {
    lastQ = q || '';
    fetch(API + '?q=' + encodeURIComponent(lastQ) + (place ? '&place=' + encodeURIComponent(place) + '&near=1' : '') + (topic ? '&topic=' + encodeURIComponent(topic) : ''), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      var all = document.getElementById('cg-all');
      if (!d.ok) { all.textContent = (d.error && d.error.message) || 'Not available yet.'; if (place) { place = ''; } return; }
      csrf = d.csrf;
      var here = document.getElementById('cg-here');
      if (d.place && d.place.key) {
        here.innerHTML = 'Groups in <a class="font-semibold text-amber-800 hover:underline" href="' + esc(d.place.url) + '">' + esc(d.place.label) + '</a> · <a class="underline" href="/community/">all groups</a>';
        document.querySelector('#cg-new h2').textContent = 'Start a group in ' + d.place.label;
      }
      document.getElementById('cg-topics').innerHTML = [['', 'All']].concat(Object.keys(d.topics).map(function (k) { return [k, d.topics[k]]; })).map(function (t) {
        return '<button type="button" class="cg-chip' + (t[0] === d.topic ? ' on' : '') + '" data-topic="' + t[0] + '">' + esc(t[1]) + '</button>';
      }).join('');
      var pop = document.getElementById('cg-pop');
      pop.innerHTML = d.popular && d.popular.length ? '<span class="cg-s">Popular' + (d.topic ? ' in ' + esc(d.topics[d.topic]) : '') + ':</span> ' + d.popular.map(function (t) { return '<button type="button" class="cg-chip" data-tag="' + esc(t) + '">#' + esc(t) + '</button>'; }).join(' ') : '';
      var sel = document.querySelector('#cg-new select[name=topic]');
      if (sel && !sel.options.length) sel.innerHTML = Object.keys(d.topics).map(function (k) { return '<option value="' + k + '">' + esc(d.topics[k]) + '</option>'; }).join('');
      if (sel && d.topic) sel.value = d.topic;
      var none = '<p class="text-sm">' + (q || d.topic ? 'No groups match. Start one below.' : 'No groups yet. Start the first one below.') + '</p>';
      if (d.place && d.place.key) { all.innerHTML = d.groups.length ? '<p class="cg-s mb-1">Nearest first: groups here and nearby, then groups about places nearby' + (q || d.topic ? ', then groups anywhere that match' : '') + '.</p><div class="cg-list">' + d.groups.map(card).join('') + '</div>' : none; }
      else {
        var interest = d.groups.filter(function (g) { return !g.local; }), local = d.groups.filter(function (g) { return g.local; });
        all.innerHTML = !d.groups.length ? none
          : (interest.length ? '<h2 class="cg-h">Interest groups</h2><div class="cg-list">' + interest.map(card).join('') + '</div>' : '')
          + (local.length ? '<h2 class="cg-h">Local groups</h2><p class="cg-s mb-1">Groups that belong to a town or area. Each also shows on that place\'s page.</p><div class="cg-list">' + local.map(card).join('') + '</div>' : '');
      }
      // the lists' standard (2026-11-12, js/tv-pager.js): 10 a page or the visitor's choice, Show more, and the pages
      if (window.TvPager) all.querySelectorAll('.cg-list').forEach(function (l, i) { TvPager.local(l, { key: 'groups' + i }); });
      document.getElementById('cg-mine').innerHTML = d.mine.length ? '<p class="text-sm font-semibold text-[#3E2B1F] mb-1">Your groups</p><div class="flex flex-wrap gap-2">'
        + d.mine.map(function (g) { return '<a class="cg-b" href="/community/group.php?id=' + g.id + '">' + esc(g.name) + (g.status === 'pending' ? ' (asked)' : g.role !== 'member' ? ' · ' + g.role : '') + '</a>'; }).join('') + '</div>' : '';
      var nw = document.getElementById('cg-new');
      nw.hidden = false;
      var vf = nw.querySelector('[data-verify]');
      if (vf && d.signed_in && d.verify && !d.verify.on) vf.hidden = false;   // only when the email isn't confirmed yet (decisions/0062 as amended 2026-11-05)
      if (!d.signed_in) nw.querySelector('form').outerHTML = '<p class="text-sm mt-1"><a class="text-amber-800 font-semibold" href="/login.php">Sign in</a> to start or join a group.</p>';
      else if (!started) { started = true; var nf = nw.querySelector('form'); if (place) nf.kind.value = 'local'; startCharter(true); }
    }).catch(function () { document.getElementById('cg-all').textContent = 'Not available yet.'; });
  }
  document.getElementById('cg-topics').addEventListener('click', function (e) {
    var b = e.target.closest('[data-topic]'); if (!b) return;
    topic = b.getAttribute('data-topic');
    history.replaceState(null, '', '/community/' + (place || topic ? '?' + [place ? 'place=' + encodeURIComponent(place) : '', topic ? 'topic=' + topic : ''].filter(Boolean).join('&') : ''));
    load(lastQ);
  });
  document.getElementById('cg-pop').addEventListener('click', function (e) {
    var b = e.target.closest('[data-tag]'); if (!b) return;
    var f = document.getElementById('cg-find'); f.q.value = b.getAttribute('data-tag'); load(f.q.value);
  });
  document.getElementById('cg-new').addEventListener('change', function (e) { if (e.target.name === 'as' || e.target.name === 'kind') startCharter(false); });
  document.getElementById('cg-find').addEventListener('submit', function (e) { e.preventDefault(); load(e.target.q.value.trim()); });
  document.getElementById('cg-new').addEventListener('submit', function (e) {
    e.preventDefault();
    var f = e.target, sub = f.querySelector('button[type=submit]'), as = +(f.as ? f.as.value : 0);
    var body = { action: 'create', name: f.name.value, about: f.about.value, join_mode: f.approval.checked ? 'approval' : 'open', place: place, topic: f.topic.value,
                 verify: !!(f.verify && f.verify.checked), listing_id: as,
                 charter: { kind: as ? 'business' : f.kind.value, purpose: f.purpose.value, who_for: f.who_for.value, house_rules: f.house_rules.value, transfer: f.transfer.value } };
    fetch(API, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (d.ok) location.href = '/community/group.php?id=' + d.group_id; else TvAsk.say(d.error.message, { anchor: sub, bad: true });
      }).catch(function () { TvAsk.say('Couldn\'t reach the site. Try again.', { anchor: sub, bad: true }); });
  });
  load('');
})();
</script>
<?php tv_page_end();
