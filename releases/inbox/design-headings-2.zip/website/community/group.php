<?php
// /community/group.php?id=N — one community group (decisions/0047). Anyone sees what it's about and how many
// belong; members see its posts and each other's names; the owner and moderators manage it.
// The charter (decisions/0137 §3): "What you're agreeing to" for everyone, the whole charter and its versions, Agree and
// join, the owner's editor, and a member's "Got it" when it changes. A business's group shows who runs it (0137 §1),
// and its team posts as the business or as its rep.
// The layout (decisions/0137 §4, the content-page standard 0058 §11, §20–21): the hero, then the kind and topic as pills
// that search, the about, the engage bar (views, Share, QR) and "at a glance"; Join sits top right where other pages
// have Link, since joining is a group's link (0132). No breadcrumbs. The charter, posts and members follow (below, JS).
// Topic groups, chapters and growing a group (decisions/0136): its tags as pills that search, "Part of <group>" for a
// chapter, the pinned welcome post anyone can read; then (JS) an invitation waiting, its tags and the places it's about,
// its chapters, Share & invite (invitations and invite codes), how it's growing, and groups like it. ?code= and ?src=
// carry an invite code and how the person came into Join.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/Community.php';
require_once __DIR__ . '/../../app/ui/explore-hero.php';
require_once __DIR__ . '/../../app/ui/engage-ui.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';   // tv_icon for the Join button, drawn before the page starts

$pdo = Database::connection();
$gid = (int) ($_GET['id'] ?? 0);
$uid = (int) (Auth::currentUserId() ?? 0);
$admin = false;
if ($uid) {   // the same test as the API: a row in admin_access
    try { $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('admin_access') . ' WHERE user_id = ? LIMIT 1'); $st->execute([$uid]); $admin = (bool) $st->fetchColumn(); } catch (Throwable) {}
}
$g = null;
try { if (Community::ready($pdo)) $g = Community::group($pdo, $gid, $admin); } catch (Throwable $x) { error_log('group page: ' . $x->getMessage()); }
if (!$g) {
    http_response_code(404);
    tv_page_start('Group not found', ['no_crumbs' => true]);
    echo '<div class="cg-card tv-bleed max-w-3xl" style="background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:.5rem;padding:1rem 1.1rem"><h1 class="font-serif font-bold text-2xl text-[#3E2B1F]">Group not found</h1>'
        . '<p class="text-sm mt-2">It may have been hidden or closed. <a class="font-semibold text-[#92400E] underline" href="/community/">Find another group</a>.</p></div>';
    tv_page_end();
    return;
}
$owner = Community::owner($pdo, $g);
$pk = ''; $plabel = ''; $purl = '';
try { [$pk, $plabel, $purl] = Community::place($pdo, (string) ($g['place_key'] ?? '')); } catch (Throwable) {}
$topicLabel = Community::TOPICS[(string) ($g['topic'] ?? '')] ?? '';
$kind = $owner['kind'] === 'listing' ? 'Business group' : ($pk !== '' ? 'Local group' : 'Interest group');
$role = $uid ? Community::roleIn($pdo, $gid, $uid, $g) : null;
$week = Community::postsSince($pdo, $gid, 7);
$near = $plabel !== '' ? ' near ' . $plabel : '';
$grow = Community::growReady($pdo);
$tags = $grow ? GroupGrowth::tags($pdo, $gid) : [];
$parent = $grow && $g['parent_id'] > 0 ? Community::group($pdo, $g['parent_id']) : null;
if ($parent) $kind = 'Chapter';
$welcome = $grow ? Community::welcomePost($pdo, $g) : null;

// Join, top right: the group's own Link (0132: membership is how a person is linked to a group)
if (!$uid) $join = '<a class="cg-join" href="/login.php">Sign in to join</a>';
elseif ($role && $role['status'] === 'active') $join = '<span class="cg-join on" title="' . ($role['via'] === 'business' ? 'You run it with ' . tv_e($owner['name']) : 'You\'re a member') . '">' . tv_icon('users') . ($role['via'] === 'business' ? 'Your team\'s' : 'Joined') . '</span>';
elseif ($role && $role['status'] === 'pending') $join = '<span class="cg-join" title="The moderators will decide">Asked to join</span>';
else $join = '<button type="button" class="cg-join go" data-cg-join>' . ($g['join_mode'] === 'approval' ? 'Ask to join' : 'Join') . '</button>';

$desc = mb_strimwidth(trim(($g['about'] !== '' ? $g['about'] . ' · ' : '') . $kind . ($plabel !== '' ? ' in ' . $plabel : '') . ' · ' . $g['members'] . ' member' . ($g['members'] === 1 ? '' : 's')), 0, 180, '…');
$url = 'https://' . preg_replace('/[^a-z0-9.\-:]/i', '', (string) ($_SERVER['HTTP_HOST'] ?? 'traversence.com')) . '/community/group.php?id=' . $gid;
$head = '<meta property="og:type" content="website"><meta property="og:title" content="' . tv_e($g['name']) . '"><meta property="og:description" content="' . tv_e($desc) . '">'
    . '<meta property="og:url" content="' . tv_e($url) . '"><meta name="twitter:card" content="summary">';

tv_page_start($g['name'], ['no_crumbs' => true, 'description' => $desc, 'head' => $head]);
if ($g['status'] === 'active') tv_count_item('group:' . $gid);
// the hero: a local group shows journeys' photos of its place; others the brand's band (their own photos: coming)
echo tv_explore_hero($pdo, ['name' => $g['name'], 'heading' => $g['name'], 'edit' => false, 'link' => $join, 'empty' => '', 'photos_of' => $g['name'],
                            'scope' => $pk, 'slides' => $pk !== '' ? null : [],
                            'within' => $pk !== '' ? [[$plabel, $purl]] : [], 'sub' => $pk !== '' ? '' : ($topicLabel !== '' ? $topicLabel : $kind)]);
?>
<div class="cg-head cg-card tv-bleed mt-3" id="cg-head">
  <div class="cg-pills">
    <button type="button" class="cg-pill" data-q="<?= tv_e(($topicLabel !== '' ? $topicLabel . ' ' : '') . 'groups' . $near) ?>"><?= tv_e($kind) ?></button>
    <?php if ($topicLabel !== ''): ?><button type="button" class="cg-pill" data-q="<?= tv_e($topicLabel . $near) ?>"><?= tv_e($topicLabel) ?></button><?php endif; ?>
    <?php foreach ($tags as $t): ?><button type="button" class="cg-pill cg-tag" data-q="<?= tv_e($t . ' groups') ?>">#<?= tv_e($t) ?></button><?php endforeach; ?>
    <?php if ($parent): ?><span class="cg-s">Part of <a class="cg-name" href="/community/group.php?id=<?= (int) $parent['id'] ?>"><?= tv_e($parent['name']) ?></a></span><?php endif; ?>
    <?php if ($owner['kind'] === 'listing'): ?><span class="cg-s">Run by <a class="cg-name" href="<?= tv_e($owner['url']) ?>"><?= tv_e($owner['name']) ?></a><?= $role && $role['via'] === 'business' ? ' (you: ' . tv_e((string) $role['team_role']) . ')' : '' ?></span><?php endif; ?>
    <?php if ($g['status'] === 'hidden'): ?><span class="cg-s"><b style="color:#991B1B">Hidden</b></span><?php endif; ?>
  </div>
  <?php if ((string) $g['about'] !== ''): ?><p class="cg-about"><?= nl2br(tv_e((string) $g['about'])) ?></p><?php endif; ?>
  <?= tv_engage_bar($pdo, 'group', (string) $gid, ['title' => $g['name'], 'likes' => false, 'comments' => false]) ?>
  <div class="cg-glance" aria-label="At a glance">
    <div><b><?= number_format((int) $g['members']) ?></b><span>member<?= (int) $g['members'] === 1 ? '' : 's' ?></span></div>
    <div><b><?= number_format($week) ?></b><span>post<?= $week === 1 ? '' : 's' ?> this week</span></div>
    <div><b><?= $g['join_mode'] === 'approval' ? 'Approval' : 'Open' ?></b><span>to join</span></div>
    <div><b><?= tv_e(date('M Y', strtotime((string) $g['created_at']))) ?></b><span>since</span></div>
  </div>
</div>
<?php if ($welcome): ?>
<div class="cg-card tv-bleed mt-3" id="welcome">
  <p class="cg-s"><b>Welcome</b> · pinned by the group, for anyone to read · <a class="cg-name" href="<?= tv_e($welcome['author_url']) ?>"><?= tv_e($welcome['author']) ?></a>, <?= tv_e(date('M j, Y', strtotime($welcome['at']))) ?></p>
  <p class="text-sm mt-1" style="white-space:pre-line"><?= tv_e($welcome['body']) ?></p>
</div>
<?php endif; ?>
<script>
  document.getElementById('cg-head').addEventListener('click', function (e) { var b = e.target.closest('[data-q]'); if (b && window.TvSearch) TvSearch.open(b.getAttribute('data-q')); });
</script>
<style>
  .cg-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:.5rem;padding:1rem 1.1rem}
  .cg-pills{display:flex;flex-wrap:wrap;align-items:center;gap:.35rem}
  .cg-pill{font-size:.78rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;border-radius:999px;padding:.25rem .75rem;cursor:pointer;color:#3E2B1F}
  .cg-pill:hover{border-color:#B45309}
  .cg-tag{font-weight:500;background:#F7EFDC}
  .cg-chips{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.4rem}
  .cg-chip{display:inline-flex;align-items:center;gap:.3rem;font-size:.78rem;border:1px solid #CBB98D;background:#FFFBF2;border-radius:999px;padding:.2rem .6rem;color:#3E2B1F}
  .cg-chip a{color:#92400E;text-decoration:none}.cg-chip button{border:0;background:none;color:#8A7355;cursor:pointer;font-size:.85rem;line-height:1}
  .cg-list{display:grid;gap:3px}.cg-li{display:flex;justify-content:space-between;align-items:center;gap:.5rem;padding:.45rem 0;border-top:1px solid rgba(203,185,141,.5);font-size:.88rem}
  .cg-li:first-child{border-top:0}
  .cg-bar{display:flex;align-items:center;gap:.5rem;font-size:.82rem;margin-top:.25rem}.cg-bar i{display:block;height:.45rem;background:#8FBCA8;border-radius:999px}
  .cg-name{color:#92400E;text-decoration:underline;font-weight:600}
  .cg-about{font-size:.92rem;color:#5C4632;margin:.6rem 0 0}
  .cg-glance{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.4rem;text-align:center;margin-top:.7rem;border-top:1px solid rgba(203,185,141,.6);padding-top:.6rem}
  .cg-glance b{display:block;font:700 1.05rem var(--tv-font-head,ui-serif,Georgia,serif);color:#3E2B1F}.cg-glance span{font-size:.72rem;color:#8A7355}
  .cg-join{display:inline-flex;align-items:center;gap:.3rem;font-size:.82rem;font-weight:700;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.35rem .9rem;cursor:pointer;text-decoration:none;white-space:nowrap}
  .cg-join.go{background:#3E2B1F;border-color:#3E2B1F;color:#EFE3C8}
  .cg-join.on{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 2px rgba(143,188,168,.3)}
  .cg-join svg{width:15px;height:15px}
  .cg-in{width:100%;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem .7rem;background:#FFFBF2;font-size:.9rem}
  .cg-b{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;border-radius:.6rem;padding:.35rem .8rem;cursor:pointer;white-space:nowrap}
  .cg-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#EFE3C8}
  .cg-s{font-size:.75rem;color:#8A7355}
  .cg-post{border-top:1px solid rgba(203,185,141,.7);padding:.65rem 0}
  .cg-row{display:flex;align-items:center;justify-content:space-between;gap:.5rem;padding:.35rem 0;border-top:1px solid rgba(203,185,141,.5);font-size:.88rem}
  .cg-acts{display:flex;flex-wrap:wrap;gap:.3rem}
  .cg-grid{display:grid;gap:1rem;grid-template-columns:minmax(0,1fr)}
  @media (min-width:900px){.cg-grid{grid-template-columns:minmax(0,1fr) 18rem}}
  .cg-ch dt{font-weight:700;color:#3E2B1F;font-size:.88rem;margin-top:.55rem}.cg-ch dd{margin:0;font-size:.88rem;color:#5C4632}
  .cg-ch ul{margin:.2rem 0 0 1.1rem;list-style:disc;font-size:.88rem;color:#5C4632}
  .cg-ed label{display:block;font-size:.82rem;font-weight:600;color:#3E2B1F;margin-top:.6rem}.cg-ed .cg-s{font-weight:400}
</style>
<div id="cg" class="max-w-5xl" data-id="<?= $gid ?>"><p class="text-sm">Loading…</p></div>
<script src="/js/at-tags.js?v=<?= (int) @filemtime(__DIR__ . '/../js/at-tags.js') ?>"></script>
<script>
(function () {
  var lastAbout = '', lastMode = 'open', reasons = {}, API = '/user/api/community.php', root = document.getElementById('cg'), gid = +root.getAttribute('data-id'), csrf = null, D = null;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function btn(l, a, c) { return '<button type="button" class="cg-b ' + (c || '') + '" ' + a + '>' + l + '</button>'; }
  function post(body) {
    return fetch(API, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error((d.error && d.error.message) || 'Could not save'); return d; }); });
  }
  function day(s) { var t = new Date(String(s).replace(' ', 'T')); return isNaN(t) ? String(s).slice(0, 10) : t.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); }
  function opts(map, cur) { return Object.keys(map).map(function (k) { return '<option value="' + esc(k) + '"' + (String(k) === String(cur) ? ' selected' : '') + '>' + esc(map[k]) + '</option>'; }).join(''); }
  function list(a) { return a && a.length ? '<ul>' + a.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' : '<dd>None set.</dd>'; }
  // The charter (decisions/0137 §3): the short card, the whole charter, its versions, and the owner's editor.
  function charterCard(d) {
    if (!d.charters_ready) return '';
    var c = d.charter, me = d.me, o = d.charter_options, member = me.status === 'active', g = d.group;
    if (!c) {
      return '<div class="cg-card tv-bleed mt-3" id="charter"><h2 class="font-serif font-bold text-[#3E2B1F]">The ground rules</h2>'
        + (me.can.run ? '<p data-tv-status="info" data-tv-label="No charter yet:">Every group needs one: its purpose, house rules, and what happens if you step down. Members are told when you add it.</p>' : '<p class="cg-s">This group hasn\'t written its charter yet. These apply here, as in every group.</p>')
        + '<dl class="cg-ch">' + list(o.ground) + '</dl>'
        + (me.can.run ? '<div class="cg-acts mt-2">' + btn('Write the charter', 'data-a="charter-edit"', 'go') + '</div><div class="cg-edit"></div>' : '') + '</div>';
    }
    var h = '<div class="cg-card tv-bleed mt-3" id="charter"><h2 class="font-serif font-bold text-[#3E2B1F]">What you\'re agreeing to</h2><dl class="cg-ch">'
      + c.summary.map(function (r) { return '<dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd>'; }).join('') + '</dl>';
    if (d.charter_pending) h += '<p class="mt-2" data-tv-status="info" data-tv-label="Coming:">' + esc(d.charter_pending.note) + '.</p>';
    if (me.member_row && member && me.charter_read !== null && me.charter_read < c.version)
      h += '<p class="mt-2" data-tv-status="info" data-tv-label="Changed:">The charter changed on ' + esc(day(c.changed_at)) + ': ' + esc(c.note) + '. ' + btn('Got it', 'data-a="charter-read"') + '</p>';
    if (me.member_row && member && ((d.charter_pending && d.charter_pending.opens_list) || me.list_hidden))
      h += '<p class="mt-2 text-sm">' + (me.list_hidden ? 'Your name is hidden from the member list; the moderators still see it. ' + btn('Show my name', 'data-a="list-show"')
        : 'The member list opens to all members on ' + esc(day(d.charter_pending.takes_effect_at)) + '. ' + btn('Hide my name from the list', 'data-a="list-hide"')) + '</p>';
    h += '<div class="cg-acts mt-3">' + btn('Read the whole charter', 'data-a="charter-full"')
      + (me.signed_in && !me.status ? btn(g.join_mode === 'approval' ? 'Agree and ask to join' : 'Agree and join', 'data-a="join"', 'go') : '')
      + (!me.signed_in ? '<a class="cg-b go" href="/login.php">Sign in to join</a>' : '')
      + (me.can.run ? btn('Edit the charter', 'data-a="charter-edit"') : '') + '</div>'
      + (me.signed_in && !me.status ? '<p class="cg-s mt-2">Joining is agreeing to this charter (version ' + c.version + ').</p>' : '');
    var who = d.owner.kind === 'listing' ? 'the business' : 'the owner';
    h += '<div class="cg-full" hidden><dl class="cg-ch mt-3">'
      + '<dt>Purpose</dt><dd>' + esc(c.purpose) + '</dd>'
      + (c.who_for ? '<dt>Who it\'s for</dt><dd>' + esc(c.who_for) + '</dd>' : '')
      + '<dt>House rules</dt>' + list(c.house_rules)
      + '<dt>The ground rules</dt><dd class="cg-s">Set by Traversence, on every charter.</dd>' + list(o.ground)
      + '<dt>Joining</dt><dd>' + (g.join_mode === 'approval' ? 'A moderator approves new members.' : 'Open: anyone can join.')
        + (g.join_mode === 'approval' ? ' Invitations: ' + esc(o.invites_skip[c.invites_skip]) + '. Invite codes ' + (c.codes_skip ? 'let people straight in.' : 'still need approval.') : '') + '</dd>'
      + (c.join_questions.length ? '<dt>Questions for new members</dt>' + list(c.join_questions) : '')
      + '<dt>Who sees the member list</dt><dd>' + esc(o.member_list[c.member_list]) + '.</dd>'
      + '<dt>Reports</dt><dd>Handled by ' + esc(o.reports_by[c.reports_by]).toLowerCase() + '. A reported post is hidden: ' + esc(o.hide_after[c.hide_after]).toLowerCase() + '.</dd>'
      + '<dt>Selling</dt><dd>' + esc(o.selling[c.selling]) + '.</dd>'
      + (c.publishes ? '<dt>What the business publishes</dt><dd>' + esc(c.publishes) + ' The business contacts you outside the group only if you ask it to, or Link with it.</dd>' : '')
      + '<dt>If ' + who + ' leaves</dt><dd>' + esc(c.transfer === 'successor' && c.successor_name ? c.successor_name + ' is offered the group' : o.transfer[c.transfer]) + '.</dd>'
      + '<dt>When a group goes quiet</dt><dd>' + esc(o.inactivity) + '</dd>'
      + '<dt>Versions</dt>' + (d.charter_history || []).map(function (v) { return '<dd>' + v.version + '. ' + esc(day(v.changed_at)) + ': ' + esc(v.note || 'Changed') + '</dd>'; }).join('')
      + '</dl></div><div class="cg-edit"></div></div>';
    return h;
  }
  function charterForm(d) {
    var o = d.charter_options, c = d.charter || d.template || {}, biz = d.owner.kind === 'listing';
    var people = (d.members || []).filter(function (m) { return m.status === 'active' && m.id !== d.me_id; });
    return '<form class="cg-ed mt-3" autocomplete="off"><h3 class="font-serif font-bold text-[#3E2B1F]">' + (d.charter ? 'Edit the charter' : 'Write the charter') + '</h3>'
      + '<label>Purpose <span class="cg-s">What the group is for, in a sentence or two</span><textarea class="cg-in" name="purpose" rows="2" maxlength="600" required>' + esc(c.purpose || '') + '</textarea></label>'
      + '<label>Who it\'s for<input class="cg-in" name="who_for" maxlength="200" value="' + esc(c.who_for || '') + '"></label>'
      + '<label>House rules <span class="cg-s">One per line</span><textarea class="cg-in" name="house_rules" rows="4">' + esc((c.house_rules || []).join('\n')) + '</textarea></label>'
      + '<label>Questions for new members <span class="cg-s">Up to 3, one per line; for groups that approve members</span><textarea class="cg-in" name="join_questions" rows="2">' + esc((c.join_questions || []).join('\n')) + '</textarea></label>'
      + '<label>Who sees the member list<select class="cg-in" name="member_list">' + opts(o.member_list, c.member_list) + '</select></label>'
      + '<label>Invitations that skip approval<select class="cg-in" name="invites_skip">' + opts(o.invites_skip, c.invites_skip) + '</select></label>'
      + '<label class="flex items-center gap-2"><input type="checkbox" name="codes_skip"' + (c.codes_skip ? ' checked' : '') + '> Invite codes let people straight in</label>'
      + '<label>Who handles reports<select class="cg-in" name="reports_by">' + opts(o.reports_by, c.reports_by) + '</select></label>'
      + '<label>When a reported post is hidden<select class="cg-in" name="hide_after">' + opts(o.hide_after, c.hide_after) + '</select></label>'
      + '<label>Selling in the group<select class="cg-in" name="selling">' + opts(o.selling, c.selling) + '</select></label>'
      + (biz ? '<label>What the business publishes here<textarea class="cg-in" name="publishes" rows="2" maxlength="600">' + esc(c.publishes || '') + '</textarea></label>' : '')
      + '<label>If ' + (biz ? 'the business' : 'you') + ' leave' + (biz ? 's' : '') + ' or step' + (biz ? 's' : '') + ' down<select class="cg-in" name="transfer">' + opts(o.transfer, c.transfer) + '</select></label>'
      + '<label class="cg-succ"' + (c.transfer === 'successor' ? '' : ' hidden') + '>Who is offered the group<select class="cg-in" name="successor_id"><option value="">Choose a member</option>'
        + people.map(function (m) { return '<option value="' + m.id + '"' + (m.id === c.successor_id ? ' selected' : '') + '>' + esc(m.name) + '</option>'; }).join('') + '</select></label>'
      + '<p class="cg-s mt-2">The ground rules and the inactivity rule are on every charter. Changes to what happens if you leave' + (d.charter && d.charter.member_list === 'moderators' ? ', and opening the member list,' : '') + ' take effect after ' + o.notice_days + ' days; everything else at once. Members are told.</p>'
      + '<div class="cg-acts mt-2"><button class="cg-b go" type="submit">Save the charter</button>' + btn('Cancel', 'data-a="charter-cancel"') + '</div></form>';
  }
  function load() {
    fetch(API + '?id=' + gid, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) { root.innerHTML = '<h1 class="font-serif font-bold text-2xl">Group not found</h1><p class="text-sm mt-2">' + esc(d.error && d.error.message) + '</p>'; return; }
      csrf = d.csrf; reasons = d.reasons || {}; D = d;
      lastAbout = d.group.about; lastMode = d.group.join_mode;
      var g = d.group, me = d.me, member = me.status === 'active', mod = member && me.can.moderate, runs = me.can.run;
      // the group's name, kind, about and numbers are drawn on the server above (the content-page standard); here: the
      // tools for whoever runs it, joining and leaving, then the charter, posts and members
      var head = '<div class="cg-card tv-bleed mt-3"' + (mod || me.signed_in ? '' : ' hidden') + '>'
        + (mod && d.topics ? '<label class="cg-s block mt-2">Topic <select class="cg-in" data-topic-set="1" style="width:auto;padding:.2rem .4rem;font-size:.8rem"><option value="">None</option>'
            + Object.keys(d.topics).map(function (k) { return '<option value="' + k + '"' + (k === g.topic ? ' selected' : '') + '>' + esc(d.topics[k]) + '</option>'; }).join('') + '</select></label>' : '')
        + (g.place && g.place.key ? '<p class="text-sm mt-1">In <a class="font-semibold text-amber-800 hover:underline" href="' + esc(g.place.url) + '">' + esc(g.place.label) + '</a>'
            + (mod ? ' ' + btn('Change', 'data-a="place"') + btn('Remove', 'data-a="noplace"') : '') + '</p>'
          : (mod ? '<p class="cg-s mt-2">Not tied to a place. ' + btn('Add a place', 'data-a="place"') + '</p>' : ''))
        + '<div class="cg-pick" hidden><input class="cg-in mt-2" placeholder="Town or area name" autocomplete="off"><div class="cg-pick-out"></div>'
        + '<p class="cg-s mt-1">The group will also show on that place\'s page.</p></div>'
        + '<div class="cg-acts' + (mod ? ' mt-3' : '') + '">'
        + (!me.signed_in ? ''
          : member ? (me.role === 'owner' || !me.member_row ? '' : btn('Leave group', 'data-a="leave"'))
          : me.status === 'pending' ? '<span class="cg-s">You asked to join. The group\'s moderators will decide.</span> ' + btn('Cancel request', 'data-a="leave"')
          : '')   // Join itself is in the hero, top right
        + (runs ? btn('Edit', 'data-a="edit"') : mod ? btn('Edit', 'data-a="edit"') : '') + (me.can.hide ? btn('Hide group', 'data-a="hide"') : '')
        + (me.signed_in && !runs ? btn('Report', 'data-rep="group" data-t="' + gid + '"') : '')
        + (me.admin ? btn(g.status === 'hidden' ? 'Show again (admin)' : 'Hide (admin)', 'data-a="' + (g.status === 'hidden' ? 'unhide' : 'hide') + '"') : '')
        + '</div></div>'
        + charterCard(d);
      var feed = !member ? '<div class="cg-card tv-bleed"><p class="text-sm">Posts are for members.</p></div>'
        : '<div class="cg-card tv-bleed"><form class="cg-new"><textarea class="cg-in" name="body" rows="3" maxlength="2000" required placeholder="Share with the group. Type @ to tag a place or topic."></textarea>'
          + (me.can.business || me.can.rep ? '<label class="cg-s block mt-1">Post as <select class="cg-in" name="voice" style="width:auto;padding:.2rem .4rem;font-size:.8rem"><option value="person">Yourself</option>'
              + (me.can.business ? '<option value="business">' + esc(d.owner.name) + '</option>' : '') + (me.can.rep ? '<option value="sales">Yourself · Sales, ' + esc(d.owner.name) + '</option>' : '') + '</select></label>' : '')
          + '<div class="flex items-center justify-between mt-2"><span class="cg-s">Members only. Public places and events; never pinpoint sacred or restricted sites. Tagging a place or topic shares only the tag, never your words or name.</span><button class="cg-b go" type="submit">Post</button></div></form>'
          + (d.posts.length ? d.posts.map(function (p) {
              return '<div class="cg-post"><div class="flex justify-between gap-2"><a class="font-semibold text-sm text-[#3E2B1F]" href="' + esc(p.author_url || ('/user/profile.php?id=' + p.author_id)) + '">' + esc(p.author) + '</a>'
                + '<span class="cg-s">' + esc(String(p.at).slice(0, 16)) + (p.can_remove ? ' ' + btn('Remove', 'data-rm="' + p.id + '"') : '')
                + (p.author_id !== d.me_id ? ' ' + btn('Report', 'data-rep="group_post" data-t="' + p.id + '"') : '')
                + (d.grow && runs && !p.held ? ' ' + btn(p.pinned ? 'Unpin' : 'Pin as welcome', 'data-pin="' + (p.pinned ? 0 : p.id) + '"') : '') + '</span></div>'
                + (p.from ? '<p class="cg-s">From <a class="cg-name" href="/community/group.php?id=' + p.from.id + '">' + esc(p.from.name) + '</a>, to all its chapters</p>' : '')
                + (p.pinned ? '<p class="cg-s">Pinned: anyone can read this post</p>' : '')
                + (p.held ? '<p class="mt-1" data-tv-status="info" data-tv-label="Hidden while it\'s looked at:">' + (p.author_id === d.me_id ? 'People reported this post. Only you and the group\'s moderators see it until they decide.' : 'Reported; only the moderators and its author see it.') + '</p>' : '')
                + '<p class="text-sm mt-1" style="white-space:pre-line">' + (window.tvTags ? tvTags.html(p.body) : esc(p.body)) + '</p></div>';
            }).join('') : '<p class="text-sm mt-3">No posts yet. Say hello.</p>') + '</div>';
      var people = !member ? '' : '<div class="cg-card tv-bleed"><h2 class="font-serif font-bold text-[#3E2B1F]">Members</h2>' + d.members.map(function (m) {
          return '<div class="cg-row"><a href="/user/profile.php?id=' + m.id + '">' + esc(m.name) + '</a><span class="cg-acts">'
            + (m.status === 'pending' ? '<span class="cg-s">asked' + (m.invited_by ? ', invited by ' + esc(m.invited_by) : m.via === 'code' ? ', with an invite code' : '') + '</span>' + (mod ? btn('Accept', 'data-m="accept" data-u="' + m.id + '"', 'go') + btn('Decline', 'data-m="decline" data-u="' + m.id + '"') : '')
              : (m.role !== 'member' ? '<span class="cg-s">' + m.role + '</span>' : '') + (m.list_hidden && mod ? '<span class="cg-s">hidden from the list</span>' : '')
                + (mod && m.role !== 'owner' && m.id !== undefined ? (me.role === 'owner' ? btn(m.role === 'moderator' ? 'Unmod' : 'Make mod', 'data-m="' + (m.role === 'moderator' ? 'member' : 'moderator') + '" data-u="' + m.id + '"') : '')
                  + btn('Remove', 'data-m="remove" data-u="' + m.id + '"') : ''))
            + '</span></div>'
            + (m.answers && m.answers.length ? '<div class="cg-s" style="padding:0 0 .4rem">' + m.answers.map(function (q) { return '<b>' + esc(q[0]) + '</b> ' + esc(q[1] || '(no answer)'); }).join('<br>') + '</div>' : '');
        }).join('') + '</div>';
      // the group's own reports (decisions/0137 §5), for whoever handles them; reporters are never shown
      var queue = !d.handles_reports ? '' : '<div class="cg-card tv-bleed" id="reports"><h2 class="font-serif font-bold text-[#3E2B1F]">Reports to decide</h2>'
        + (d.reports.length ? d.reports.map(function (q) {
            return '<div class="cg-post"><div class="flex justify-between gap-2"><span class="font-semibold text-sm">' + esc(q.author) + '</span><span class="cg-s">'
              + q.reports + ' report' + (q.reports === 1 ? '' : 's') + ' · ' + (q.days ? q.days + ' day' + (q.days === 1 ? '' : 's') : 'today') + (q.held ? ' · hidden' : '') + '</span></div>'
              + '<p class="cg-s mt-1">' + esc(q.reasons.join(', ')) + '</p><p class="text-sm mt-1" style="white-space:pre-line">' + esc(q.body) + '</p>'
              + (q.days >= 7 ? '<p class="mt-1" data-tv-status="bad" data-tv-label="Waiting:">' + (q.days >= 14 ? 'Traversence has been asked to help with this one.' : 'After 14 days, Traversence is asked to help.') + '</p>' : '')
              + '<div class="cg-acts mt-2">' + btn('Keep it', 'data-dec="keep" data-p="' + q.post_id + '"') + btn('Remove the post', 'data-dec="remove" data-p="' + q.post_id + '"')
              + btn('Remove it and its author', 'data-dec="remove_member" data-p="' + q.post_id + '"') + '</div></div>';
          }).join('') : '<p class="cg-s mt-1">Nothing to decide. Reports on posts here come to you, never to Traversence, unless someone says it breaks the law or puts someone in danger.</p>')
        + '</div>';
      var help = !(runs || mod) ? '' : '<div class="cg-card tv-bleed"><h2 class="font-serif font-bold text-[#3E2B1F]">Ask Traversence for help</h2>'
        + '<p class="cg-s mt-1">For what the group can\'t settle: a member harassing people across groups, a moderator\'s account taken over, a dispute you\'re stuck on. Our support team gets it as a case.</p>'
        + '<form class="cg-help mt-2"><textarea class="cg-in" name="body" rows="3" maxlength="3000" required placeholder="What\'s happening?"></textarea><div class="cg-acts mt-2"><button class="cg-b go" type="submit">Ask for help</button></div></form></div>';
      root.innerHTML = head + '<div id="cg-grow-top"></div><div class="cg-grid mt-3"><div>' + queue + feed + '</div><div><div id="cg-grow-side"></div>' + people + help + '</div></div>';
      if (d.grow) growUI(d);
      var f = root.querySelector('.cg-new');
      if (f && window.tvTags) tvTags.attach(f.body, { group: gid });
      if (f && d.grow && mod && d.grow.chapters.some(function (c) { return c.status === 'active'; })) f.querySelector('.flex').insertAdjacentHTML('beforebegin', '<label class="cg-s flex items-center gap-2 mt-1"><input type="checkbox" name="all_chapters"> Post to all its chapters too</label>');
      if (f) f.addEventListener('submit', function (e) { e.preventDefault(); post({ action: 'post', group_id: gid, body: f.body.value, voice: f.voice ? f.voice.value : 'person', all_chapters: !!(f.all_chapters && f.all_chapters.checked) })
        .then(function (r) { if (r.chapters) TvAsk.say('Posted here and in ' + r.chapters + ' chapter' + (r.chapters === 1 ? '' : 's') + '.', { anchor: f }); load(); }).catch(function (x) { TvAsk.say(x.message, { anchor: f, bad: true }); }); });
      if (location.hash === '#charter') { var ch = document.getElementById('charter'); if (ch) { var fl = ch.querySelector('.cg-full'); if (fl) fl.hidden = false; ch.scrollIntoView(); } }
    }).catch(function () { root.textContent = 'Not available yet.'; });
  }
  var pickT = null;
  root.addEventListener('input', function (e) {
    if (!e.target.closest('.cg-pick')) return;
    clearTimeout(pickT);
    var q = e.target.value.trim(), out = root.querySelector('.cg-pick-out');
    pickT = setTimeout(function () {
      if (q.length < 2) { out.innerHTML = ''; return; }
      fetch(API + '?places=' + encodeURIComponent(q), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        out.innerHTML = d.places && d.places.length ? '<div class="cg-acts mt-1">' + d.places.map(function (p) { return btn(esc(p.label) + ' <span class="cg-s">' + esc(p.level) + '</span>', 'data-pk="' + esc(p.key) + '"'); }).join('') + '</div>'
          : '<p class="cg-s mt-1">No place by that name.</p>';
      });
    }, 250);
  });
  root.addEventListener('submit', function (e) {
    if (e.target.classList.contains('cg-help')) {
      e.preventDefault(); var hf = e.target, hb = hf.querySelector('button[type=submit]');
      post({ action: 'help', group_id: gid, body: hf.body.value }).then(function (r) {
        hf.body.value = ''; TvAsk.say('Sent' + (r.case ? ': case #' + r.case : '') + '. Our support team will reply to you by email.', { anchor: hb });
      }).catch(function (x) { TvAsk.say(x.message, { anchor: hb, bad: true }); });
      return;
    }
    var f = e.target; if (!f.classList.contains('cg-ed')) return;
    e.preventDefault();
    var c = { purpose: f.purpose.value, who_for: f.who_for.value, house_rules: f.house_rules.value, join_questions: f.join_questions.value,
              member_list: f.member_list.value, invites_skip: f.invites_skip.value, codes_skip: f.codes_skip.checked, reports_by: f.reports_by.value,
              hide_after: f.hide_after.value, selling: f.selling.value, transfer: f.transfer.value, successor_id: f.successor_id.value || null };
    if (f.publishes) c.publishes = f.publishes.value;
    post({ action: 'charter', group_id: gid, charter: c }).then(function (r) {
      TvAsk.say(r.waits_until ? 'Saved. Members are told now; the change to what happens if the owner leaves, or to the member list, takes effect on ' + day(r.waits_until) + '.' : 'Saved. Members are told of the change.', { anchor: f.querySelector('button[type=submit]') });
      load();
    }).catch(function (x) { TvAsk.say(x.message, { anchor: f.querySelector('button[type=submit]'), bad: true }); });
  });
  root.addEventListener('change', function (e) {
    if (e.target.name === 'transfer' && e.target.closest('.cg-ed')) { e.target.closest('.cg-ed').querySelector('.cg-succ').hidden = e.target.value !== 'successor'; return; }
    if (!e.target.hasAttribute('data-topic-set')) return;
    post({ action: 'edit', group_id: gid, about: lastAbout, join_mode: lastMode, topic: e.target.value }).then(load).catch(function (x) { TvAsk.say(x.message, { anchor: e.target }); });
  });
  root.addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b || b.type === 'submit') return;
    var a = b.getAttribute('data-a'), fail = function (x) { TvAsk.say(x.message, { anchor: b }); };
    var sure = function (msg, yes, then) { TvAsk.confirm(msg, { anchor: b, yes: yes, danger: true }).then(function (ok) { if (ok) then(); }); };
    if (a === 'place') { var pk = root.querySelector('.cg-pick'); pk.hidden = !pk.hidden; if (!pk.hidden) pk.querySelector('input').focus(); return; }
    if (a === 'noplace') sure('Remove the place? The group stays, but leaves that place\'s page.', 'Remove it', function () { post({ action: 'edit', group_id: gid, about: lastAbout, join_mode: lastMode, place: '' }).then(load).catch(fail); });
    if (b.hasAttribute('data-pk')) post({ action: 'edit', group_id: gid, about: lastAbout, join_mode: lastMode, place: b.getAttribute('data-pk') }).then(load).catch(fail);
    if (a === 'join') { joinNow(b); return; }
    if (a === 'to-charter') { var cc = document.getElementById('charter'); if (cc) { cc.querySelector('.cg-full').hidden = false; cc.scrollIntoView({ behavior: 'smooth' }); } return; }
    if (a === 'charter-full') { var fu = b.closest('.cg-card').querySelector('.cg-full'); fu.hidden = !fu.hidden; b.textContent = fu.hidden ? 'Read the whole charter' : 'Hide the whole charter'; return; }
    if (a === 'charter-read') { post({ action: 'charter_read', group_id: gid }).then(load).catch(fail); return; }
    if (a === 'list-hide' || a === 'list-show') { post({ action: 'list_hide', group_id: gid, hidden: a === 'list-hide' }).then(load).catch(fail); return; }
    if (a === 'charter-cancel') { b.closest('.cg-edit').innerHTML = ''; return; }
    if (a === 'charter-edit') {
      var box = b.closest('.cg-card').querySelector('.cg-edit');
      var show = function (t) { box.innerHTML = charterForm(t ? Object.assign({}, D, { template: t }) : D); box.querySelector('textarea').focus(); };
      if (D.charter) show(null);
      else fetch(API + '?start=1&kind=' + (D.owner.kind === 'listing' ? 'business' : (D.group.place && D.group.place.key ? 'local' : 'interest')) + (D.owner.kind === 'listing' ? '&listing=' + D.owner.id : ''), { credentials: 'include' })
        .then(function (r) { return r.json(); }).then(function (t) { show(t.template); }).catch(fail);
      return;
    }
    if (a === 'leave') sure('Leave this group?', 'Leave', function () {
      var mine = D && D.grow ? D.grow.chapters.filter(function (c) { return c.mine; }) : [];
      var go = function (ch) { post({ action: 'leave', group_id: gid, chapters: ch }).then(function () { location.reload(); }).catch(fail); };
      if (!mine.length) { go(false); return; }
      TvAsk.confirm('Leave its chapters too? (' + mine.map(function (c) { return c.short; }).join(', ') + ')', { anchor: b, yes: 'Leave them too', no: 'Stay in the chapters' }).then(function (ok) { go(!!ok); });
    });
    if (a === 'hide' || a === 'unhide') TvAsk.confirm(a === 'hide' ? 'Hide this group? It disappears for everyone.' : 'Show this group again?', { anchor: b, yes: a === 'hide' ? 'Hide it' : 'Show it', danger: a === 'hide' })
      .then(function (ok) { if (ok) post({ action: a, group_id: gid }).then(load).catch(fail); });
    if (a === 'edit') {
      TvAsk.ask('What the group is about', (root.querySelector('.cg-card p.text-sm') || {}).textContent || '', { multiline: true, yes: 'Next' }).then(function (about) {
        if (about === null) return;
        TvAsk.confirm('Should new members need approval to join?', { yes: 'Yes, approve them', no: 'No, open to all' })
          .then(function (appr) { post({ action: 'edit', group_id: gid, about: about, join_mode: appr ? 'approval' : 'open' }).then(load).catch(fail); });
      });
    }
    if (b.hasAttribute('data-rep')) {
      var host = b.closest('.cg-post') || b.closest('.cg-card'), old = host.querySelector('.cg-rep');
      if (old) { old.remove(); return; }
      var box = document.createElement('div'); box.className = 'cg-rep mt-2';
      box.innerHTML = '<p class="cg-s">' + (b.getAttribute('data-rep') === 'group' ? 'Report this group to Traversence\'s Safety team.' : 'Reports on posts go to this group\'s moderators. If it breaks the law or puts someone in danger, choose that reason and it comes to Traversence too.')
        + ' Nobody learns who reported it.</p>'
        + '<select class="cg-in mt-1">' + Object.keys(reasons).map(function (k) { return '<option value="' + k + '">' + esc(reasons[k]) + '</option>'; }).join('') + '</select>'
        + '<input class="cg-in mt-1" maxlength="500" placeholder="Anything we should know (optional)"><div class="cg-acts mt-1">' + btn('Send report', 'data-send-rep="1"', 'go') + '</div>';
      box.setAttribute('data-kind', b.getAttribute('data-rep')); box.setAttribute('data-t', b.getAttribute('data-t'));
      host.appendChild(box);
      return;
    }
    if (b.hasAttribute('data-send-rep')) {
      var r = b.closest('.cg-rep');
      post({ action: 'report', kind: r.getAttribute('data-kind'), target_id: +r.getAttribute('data-t'), reason: r.querySelector('select').value, note: r.querySelector('input').value })
        .then(function (res) { r.innerHTML = '<p data-tv-status="ok" data-tv-label="Thanks:">' + (res.to === 'group' ? 'The group\'s moderators will look at it.' : 'Traversence\'s Safety team will look at it.') + '</p>'; }).catch(fail);
      return;
    }
    if (b.hasAttribute('data-dec')) {
      var dw = b.getAttribute('data-dec'), dp = +b.getAttribute('data-p');
      var go = function () { post({ action: 'report_decide', post_id: dp, what: dw }).then(load).catch(fail); };
      if (dw === 'keep') go(); else sure(dw === 'remove' ? 'Remove this post?' : 'Remove the post, and its author from the group?', dw === 'remove' ? 'Remove' : 'Remove both', go);
      return;
    }
    if (b.hasAttribute('data-rm')) sure('Remove this post?', 'Remove', function () { post({ action: 'remove_post', post_id: +b.getAttribute('data-rm') }).then(load).catch(fail); });
    if (b.hasAttribute('data-m')) {
      var w = b.getAttribute('data-m');
      var doIt = function () { post({ action: 'manage', group_id: gid, user_id: +b.getAttribute('data-u'), what: w }).then(load).catch(fail); };
      if (w === 'remove') sure('Remove them from the group?', 'Remove', doIt); else doIt();
    }
  });
  // Join, top right of the hero: with a charter, it opens the charter to agree to first; without one, it joins
  var hj = document.querySelector('[data-cg-join]');
  if (hj) hj.addEventListener('click', function () {
    if (D && D.charter) { var cc = document.getElementById('charter'); if (cc) { cc.querySelector('.cg-full').hidden = false; cc.scrollIntoView({ behavior: 'smooth' }); } return; }
    joinNow(hj);
  });
  // ---- joining: an invite code or how they came (?code=, ?src=), and answers to the join questions (decisions/0136 §5c)
  var QS = new URLSearchParams(location.search), CODE = QS.get('code') || '', SRC = QS.get('src') || 'page';
  function joinNow(anchor) {
    var c = D && D.charter, appr = D && D.group.join_mode === 'approval', qs = c && appr ? (c.join_questions || []) : [];
    var send = function (answers) {
      post({ action: 'join', group_id: gid, charter_version: c ? c.version : null, code: CODE, src: SRC, answers: answers || null }).then(function (r) {
        TvAsk.say(r.status === 'active' ? 'You\'re in. Welcome!' : 'Asked. The group\'s moderators will decide, and you\'ll get a notice.', { anchor: anchor });
        setTimeout(function () { location.href = '/community/group.php?id=' + gid; }, 900);
      }).catch(function (x) { TvAsk.say(x.message, { anchor: anchor, bad: true }); });
    };
    if (!qs.length || (D.grow && D.grow.invitation && c.invites_skip !== 'never')) { send(null); return; }
    var box = document.querySelector('#charter .cg-edit') || anchor.parentNode;
    box.innerHTML = '<form class="cg-qs cg-ed mt-3"><h3 class="font-serif font-bold text-[#3E2B1F]">The group asks</h3>'
      + qs.map(function (q, i) { return '<label>' + esc(q) + '<textarea class="cg-in" name="a' + i + '" rows="2" maxlength="500"></textarea></label>'; }).join('')
      + '<p class="cg-s mt-1">Only the group\'s moderators see your answers.</p><div class="cg-acts mt-2"><button class="cg-b go" type="submit">Send my request</button></div></form>';
    var f = box.querySelector('.cg-qs'); f.scrollIntoView({ behavior: 'smooth', block: 'center' });
    f.addEventListener('submit', function (e) { e.preventDefault(); send(qs.map(function (q, i) { return f['a' + i].value; })); });
  }

  // ---- tags, places it's about, chapters, Share & invite, growth, groups like this (decisions/0136)
  function growUI(d) {
    var G = d.grow, me = d.me, member = me.status === 'active', mod = member && me.can.moderate, runs = me.can.run, top = document.getElementById('cg-grow-top'), side = document.getElementById('cg-grow-side');
    var h = '';
    if (G.invitation && !me.status) h += '<div class="cg-card tv-bleed mt-3"><p data-tv-status="info" data-tv-label="Invited:">' + esc(G.invitation.from) + ' invited you to this group. Read what you\'re agreeing to below, then join if it\'s for you.</p>'
      + '<div class="cg-acts mt-2">' + btn('Join', 'data-g="join"', 'go') + btn('No thanks', 'data-g="decline-invite"') + '</div></div>';
    if (CODE && !me.status) h += '<div class="cg-card tv-bleed mt-3"><p data-tv-status="info" data-tv-label="Invite code:">You came with an invite code. ' + (d.group.join_mode === 'approval' ? 'If the group lets codes in, you join at once; otherwise the moderators decide.' : '') + '</p></div>';
    (G.offers || []).forEach(function (o) {
      h += '<div class="cg-card tv-bleed mt-3"><p data-tv-status="info" data-tv-label="Chapter:">' + (o.side === 'parent' ? esc(o.parent) + ' invites this group to be its chapter. Members keep everything; it gains the whole group behind it.' : esc(o.group) + ' asks to be a chapter of this group.') + '</p>'
        + '<div class="cg-acts mt-2">' + btn('Agree', 'data-g="offer-yes" data-o="' + o.id + '"', 'go') + btn('No', 'data-g="offer-no" data-o="' + o.id + '"') + '</div></div>';
    });
    if (G.leaving_at) h += '<div class="cg-card tv-bleed mt-3"><p data-tv-status="info" data-tv-label="Leaving:">This chapter leaves ' + esc(G.parent ? G.parent.name : 'its group') + ' on ' + esc(day(G.leaving_at)) + ' and carries on as its own group.' + (runs ? ' ' + btn('Stay a chapter', 'data-g="stay"') : '') + '</p></div>';
    // what it's about: tags and places
    var tags = G.tags || [], places = G.places || [];
    if (tags.length || places.length || mod) {
      h += '<div class="cg-card tv-bleed mt-3" id="about"><h2 class="font-serif font-bold text-[#3E2B1F]">What it\'s about</h2>'
        + '<div class="cg-chips">' + (tags.length ? tags.map(function (t) {
            return '<span class="cg-chip">' + (t.status === 'held' ? '<span title="Waiting for our team: it may name a sacred or protected site">#' + esc(t.tag) + ' (waiting)</span>' : '<a href="#" data-gq="' + esc(t.tag + ' groups') + '">#' + esc(t.tag) + '</a>') + '</span>';
          }).join('') : '<span class="cg-s">No tags yet.</span>') + (mod ? ' ' + btn('Edit tags', 'data-g="tags"') : '') + '</div>'
        + '<div class="cg-tagedit" hidden><input class="cg-in mt-2" placeholder="Type a tag, then Enter (up to ' + G.max_tags + ')" autocomplete="off"><div class="cg-sugg cg-chips"></div>'
        + '<p class="cg-s mt-1">What the group is about, under its topic: baking, cast iron, trail running. Tags help people find it; they never rank it higher.</p>'
        + '<div class="cg-acts mt-1">' + btn('Save tags', 'data-g="tags-save"', 'go') + '</div></div>'
        + '<h3 class="font-serif font-bold text-[#3E2B1F] mt-3">Places we\'re about</h3>'
        + (places.length ? '<div class="cg-list">' + places.map(function (pl) {
            return '<div class="cg-li"><span><a class="cg-name" href="' + esc(pl.url) + '">' + esc(pl.label) + '</a> <span class="cg-s">' + esc(pl.kind) + (pl.note ? ' · ' + esc(pl.note) : '') + '</span></span>'
              + (mod ? btn('Take off', 'data-g="place-off" data-r="' + esc(pl.ref) + '"') : pl.mine ? btn('Take my business off', 'data-g="place-off" data-r="' + esc(pl.ref) + '"') : '') + '</div>';
          }).join('') + '</div>' : '<p class="cg-s">None named yet.' + (mod ? ' Name up to ' + G.max_places + ': towns, businesses, outdoor places and landmarks the group goes to or talks about. Each shows the group on its page.' : '') + '</p>')
        + (mod && places.length < G.max_places ? '<div class="cg-acts mt-2">' + btn('Add a place', 'data-g="place-add"') + '</div><div class="cg-placeadd" hidden><input class="cg-in mt-2" placeholder="Town, business, trail or landmark" autocomplete="off">'
            + '<input class="cg-in mt-1" name="note" maxlength="80" placeholder="A short note (optional): planned for June, our home water"><div class="cg-placeout"></div></div>' : '')
        + '</div>';
    }
    // chapters
    var chs = G.chapters || [], isChapter = !!G.parent;
    if (G.can_parent && (chs.length || member || runs)) {
      h += '<div class="cg-card tv-bleed mt-3" id="chapters"><h2 class="font-serif font-bold text-[#3E2B1F]">Chapters</h2>'
        + '<p class="cg-s">Local or topic branches of this group, each with its own members and posts. ' + esc(G.join_rules[G.chapter_join] || '') + '.</p>'
        + (chs.length ? '<div class="cg-list mt-1">' + chs.map(function (c) {
            return '<div class="cg-li"><span>' + (c.status === 'proposed' ? '<b>' + esc(c.short) + '</b> <span class="cg-s">asked to start</span>' : '<a class="cg-name" href="/community/group.php?id=' + c.id + '">' + esc(c.short) + '</a>')
              + ' <span class="cg-s">' + (c.place ? esc(c.place) + ' · ' : 'Topic · ') + c.members + ' member' + (c.members === 1 ? '' : 's') + (c.mine ? ' · you\'re in' : '') + (c.leaving ? ' · leaving' : '') + '</span></span>'
              + (c.status === 'proposed' && runs ? '<span class="cg-acts">' + btn('Open it', 'data-g="ch-yes" data-c="' + c.id + '"', 'go') + btn('Decline', 'data-g="ch-no" data-c="' + c.id + '"') + '</span>' : '') + '</div>';
          }).join('') + '</div>' : '<p class="cg-s mt-1">No chapters yet.</p>')
        + (member || runs ? '<div class="cg-acts mt-2">' + btn(runs ? 'Open a chapter' : 'Ask to start a chapter', 'data-g="ch-open"') + (runs ? btn('Invite a group to be a chapter', 'data-g="ch-offer"') : '') + '</div>' : '')
        + '<div class="cg-chopen" hidden><div class="cg-acts mt-2"><label class="cg-s"><input type="radio" name="chk" value="place" checked> For a place</label><label class="cg-s"><input type="radio" name="chk" value="topic"> For a topic</label></div>'
        + '<input class="cg-in mt-1 cg-chplace" placeholder="Town or area" autocomplete="off"><div class="cg-chout"></div>'
        + '<input class="cg-in mt-1 cg-chname" maxlength="60" placeholder="Name after the colon (the place, or the topic: Beginners)">'
        + '<p class="cg-s mt-1">' + (runs ? 'You lead it to start; you can hand it to a member later.' : 'You\'d lead it (Verification needed); the group\'s owner decides.') + '</p>'
        + '<div class="cg-acts mt-1">' + btn(runs ? 'Open it' : 'Ask', 'data-g="ch-send"', 'go') + '</div></div>'
        + '<div class="cg-choffer" hidden><input class="cg-in mt-2" placeholder="The group\'s name" autocomplete="off"><div class="cg-offerout"></div></div>'
        + (runs ? '<label class="cg-s block mt-2">How chapters are joined <select class="cg-in" data-g-rule style="max-width:100%;padding:.2rem .4rem;font-size:.8rem">'
            + Object.keys(G.join_rules).map(function (k) { return '<option value="' + k + '"' + (k === G.chapter_join ? ' selected' : '') + '>' + esc(G.join_rules[k]) + '</option>'; }).join('') + '</select></label>' : '')
        + '</div>';
    }
    if (isChapter) {
      h += '<div class="cg-card tv-bleed mt-3" id="chapters"><p class="text-sm">A chapter of <a class="cg-name" href="/community/group.php?id=' + G.parent.id + '">' + esc(G.parent.name) + '</a>. ' + esc(G.parent.join) + '.'
        + (member && !G.parent.member ? ' ' + btn('Join ' + G.parent.name + ' too', 'data-g="join-parent"') : '') + '</p>'
        + (G.parent.runs ? '<div class="cg-acts mt-2">' + btn('Change the lead', 'data-g="ch-lead"') + '</div>' : '')
        + (runs && !G.leaving_at ? '<p class="cg-s mt-2">Leading it? It can leave ' + esc(G.parent.name) + ' and carry on as its own group, after ' + 14 + ' days\' notice to its members. ' + btn('Leave ' + G.parent.name, 'data-g="leave-parent"') + '</p>' : '')
        + '</div>';
    } else if (runs && !chs.length && !G.can_parent) {
      h += '<div class="cg-card tv-bleed mt-3"><p class="cg-s">A group for a town or area can become a chapter of a larger group. ' + btn('Ask a group to take it as a chapter', 'data-g="ch-ask"') + '</p><div class="cg-choffer" hidden><input class="cg-in mt-2" placeholder="The larger group\'s name" autocomplete="off"><div class="cg-offerout"></div></div></div>';
    }
    top.innerHTML = h;
    // the side: Share & invite, how it's growing, the welcome message, groups like this
    var sh = '';
    if (member) {
      var link = location.origin + '/community/group.php?id=' + gid;
      sh += '<div class="cg-card tv-bleed"><h2 class="font-serif font-bold text-[#3E2B1F]">Share &amp; invite</h2>'
        + '<p class="cg-s mt-1">Share and QR are under the group\'s name. Invite your connections: each gets one invitation, and can turn group invitations off.</p>'
        + '<div class="cg-acts mt-2">' + btn('Invite connections', 'data-g="invite"', 'go') + '</div><div class="cg-inv"></div>'
        + (mod ? '<h3 class="font-serif font-bold text-[#3E2B1F] mt-3">Invite codes</h3><p class="cg-s">For a meeting, a class or a customer list: a link that ends when you say.'
            + (d.group.join_mode === 'approval' ? (d.charter && d.charter.codes_skip ? ' Codes can let people straight in (your charter allows it).' : ' Your charter says codes still need approval.') : '') + '</p>'
            + (G.codes.length ? '<div class="cg-list mt-1">' + G.codes.map(function (c) {
                return '<div class="cg-li"><span><b>' + esc(c.label || c.code) + '</b> <span class="cg-s">' + (c.live ? 'on' : 'off') + ' · used ' + c.used + (c.uses_allowed ? ' of ' + c.uses_allowed : '') + (c.ends_at ? ' · ends ' + esc(day(c.ends_at)) : '') + (c.skip ? ' · lets people in' : '') + '</span></span>'
                  + '<span class="cg-acts">' + (c.live ? btn('Copy link', 'data-g="code-copy" data-k="' + esc(c.code) + '"') + btn('Switch off', 'data-g="code-off" data-c="' + c.id + '"') : '') + '</span></div>';
              }).join('') + '</div>' : '')
            + '<div class="cg-acts mt-2">' + btn('Make a code', 'data-g="code-make"') + '</div>' : '')
        + '</div>';
    }
    if (G.growth) {
      var mx = Math.max.apply(null, [1].concat(G.growth.joins.map(function (j) { return j[1]; })));
      sh += '<div class="cg-card tv-bleed"><h2 class="font-serif font-bold text-[#3E2B1F]">How it\'s growing</h2><p class="cg-s mt-1">The last 90 days: ' + G.growth.views + ' page view' + (G.growth.views === 1 ? '' : 's') + '. Joins by how people came (counts only, never who):</p>'
        + (G.growth.joins.length ? G.growth.joins.map(function (j) { return '<div class="cg-bar"><span style="min-width:8.5rem">' + esc(j[0]) + '</span><i style="width:' + Math.max(4, Math.round(j[1] / mx * 100)) + '%"></i><b>' + j[1] + '</b></div>'; }).join('') : '<p class="cg-s">No joins yet.</p>')
        + '</div>';
    }
    if (runs) sh += '<div class="cg-card tv-bleed"><h2 class="font-serif font-bold text-[#3E2B1F]">Welcome</h2><p class="cg-s mt-1">A message each new member gets. Pin one post (Pin as welcome) for anyone to read, members or not.</p>'
      + '<textarea class="cg-in mt-2 cg-wmsg" rows="3" maxlength="1000" placeholder="Glad you\'re here! Start with…">' + esc(G.welcome_msg || '') + '</textarea><div class="cg-acts mt-1">' + btn('Save the message', 'data-g="welcome"') + '</div></div>';
    if (G.like && G.like.length) sh += '<div class="cg-card tv-bleed"><h2 class="font-serif font-bold text-[#3E2B1F]">Groups like this</h2><div class="cg-list mt-1">'
      + G.like.map(function (x) { return '<div class="cg-li"><a class="cg-name" href="/community/group.php?id=' + x.id + '&src=like">' + esc(x.name) + '</a><span class="cg-s">' + x.members + '</span></div>'; }).join('') + '</div></div>';
    side.innerHTML = sh;
    wireGrow(d, top, side);
  }
  function wireGrow(d, top, side) {
    var G = d.grow, tagList = (G.tags || []).map(function (t) { return t.tag; }), timer = null;
    var drawTags = function (box) { box.querySelector('.cg-sugg').innerHTML = tagList.map(function (t) { return '<span class="cg-chip">#' + esc(t) + '<button type="button" data-g="tag-x" data-t="' + esc(t) + '" aria-label="Remove">×</button></span>'; }).join(''); };
    var search = function (input, url, out, draw) {
      clearTimeout(timer); var q = input.value.trim();
      timer = setTimeout(function () { if (q.length < 2) { out.innerHTML = ''; return; } fetch(API + url + encodeURIComponent(q), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (r) { out.innerHTML = draw(r); }); }, 250);
    };
    [top, side].forEach(function (el) {
      el.addEventListener('input', function (e) {
        var t = e.target;
        if (t.closest('.cg-placeadd') && t.name !== 'note') search(t, '?about=', t.closest('.cg-placeadd').querySelector('.cg-placeout'), function (r) {
          return r.places && r.places.length ? '<div class="cg-acts mt-1">' + r.places.map(function (p) { return btn(esc(p.label) + ' <span class="cg-s">' + esc(p.kind) + '</span>', 'data-g="place-pick" data-r="' + esc(p.ref) + '"'); }).join('') + '</div>' : '<p class="cg-s mt-1">Nothing by that name.</p>';
        });
        if (t.classList.contains('cg-chplace')) search(t, '?places=', t.parentNode.querySelector('.cg-chout'), function (r) {
          return r.places && r.places.length ? '<div class="cg-acts mt-1">' + r.places.map(function (p) { return btn(esc(p.label) + ' <span class="cg-s">' + esc(p.level) + '</span>', 'data-g="ch-place" data-k="' + esc(p.key) + '" data-l="' + esc(p.label) + '"'); }).join('') + '</div>' : '<p class="cg-s mt-1">No place by that name.</p>';
        });
        if (t.closest('.cg-choffer')) search(t, '?q=', t.closest('.cg-choffer').querySelector('.cg-offerout'), function (r) {
          var gs = (r.groups || []).filter(function (x) { return x.id !== gid && !x.parent; });
          return gs.length ? '<div class="cg-acts mt-1">' + gs.slice(0, 8).map(function (x) { return btn(esc(x.name), 'data-g="offer-pick" data-id="' + x.id + '"'); }).join('') + '</div>' : '<p class="cg-s mt-1">No group by that name.</p>';
        });
        if (t.closest('.cg-tagedit')) search(t, '?tags=', t.closest('.cg-tagedit').querySelector('.cg-sugg'), function (r) {
          var cur = tagList.map(function (x) { return '<span class="cg-chip">#' + esc(x) + '<button type="button" data-g="tag-x" data-t="' + esc(x) + '" aria-label="Remove">×</button></span>'; }).join('');
          return cur + (r.tags || []).filter(function (x) { return tagList.indexOf(x[0]) < 0; }).map(function (x) { return btn('+ ' + esc(x[0]) + ' <span class="cg-s">' + x[1] + '</span>', 'data-g="tag-add" data-t="' + esc(x[0]) + '"'); }).join('');
        });
      });
      el.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter' || !e.target.closest('.cg-tagedit')) return;
        e.preventDefault(); var v = e.target.value.trim().toLowerCase(); if (v && tagList.indexOf(v) < 0) tagList.push(v); e.target.value = ''; drawTags(e.target.closest('.cg-tagedit'));
      });
      el.addEventListener('change', function (e) {
        if (e.target.hasAttribute('data-g-rule')) post({ action: 'chapter_rule', group_id: gid, rule: e.target.value }).then(function () { TvAsk.say('Saved. Members already in are never removed by it.', { anchor: e.target }); load(); }).catch(function (x) { TvAsk.say(x.message, { anchor: e.target, bad: true }); });
        if (e.target.name === 'chk') { var box = e.target.closest('.cg-chopen'); box.querySelector('.cg-chplace').hidden = e.target.value !== 'place'; box.querySelector('.cg-chout').innerHTML = ''; box.removeAttribute('data-k'); }
      });
      el.addEventListener('click', function (e) {
        var a = e.target.closest('[data-gq]'); if (a) { e.preventDefault(); if (window.TvSearch) TvSearch.open(a.getAttribute('data-gq')); return; }
        var b = e.target.closest('[data-g]'); if (!b) return;
        var g = b.getAttribute('data-g'), fail = function (x) { TvAsk.say(x.message, { anchor: b, bad: true }); }, ok = function (m) { return function () { if (m) TvAsk.say(m, { anchor: b }); load(); }; };
        var card = b.closest('.cg-card');
        switch (g) {
          case 'join': joinNow(b); break;
          case 'join-parent': location.href = '/community/group.php?id=' + G.parent.id + '&src=chapter#charter'; break;
          case 'decline-invite': post({ action: 'invite_decline', group_id: gid }).then(ok('No problem. You won\'t be asked again for 30 days.')).catch(fail); break;
          case 'offer-yes': case 'offer-no': post({ action: 'offer_answer', offer_id: +b.getAttribute('data-o'), yes: g === 'offer-yes' }).then(ok(g === 'offer-yes' ? 'Done: it\'s a chapter now.' : 'Declined.')).catch(fail); break;
          case 'stay': post({ action: 'chapter_leave', group_id: gid, stay: true }).then(ok('It stays a chapter.')).catch(fail); break;
          case 'leave-parent': TvAsk.confirm('Leave ' + G.parent.name + '? Members get 14 days\' notice, then it carries on as its own group.', { anchor: b, yes: 'Leave it', danger: true }).then(function (y) { if (y) post({ action: 'chapter_leave', group_id: gid }).then(ok('Members are told. It leaves in 14 days.')).catch(fail); }); break;
          case 'tags': var te = card.querySelector('.cg-tagedit'); te.hidden = !te.hidden; if (!te.hidden) { drawTags(te); te.querySelector('input').focus(); } break;
          case 'tag-add': if (tagList.indexOf(b.getAttribute('data-t')) < 0) tagList.push(b.getAttribute('data-t')); drawTags(card.querySelector('.cg-tagedit')); card.querySelector('.cg-tagedit input').value = ''; break;
          case 'tag-x': tagList = tagList.filter(function (x) { return x !== b.getAttribute('data-t'); }); drawTags(card.querySelector('.cg-tagedit')); break;
          case 'tags-save': var pend = card.querySelector('.cg-tagedit input').value.trim(); if (pend && tagList.indexOf(pend.toLowerCase()) < 0) tagList.push(pend.toLowerCase());
            post({ action: 'tags', group_id: gid, tags: tagList }).then(function (r) { TvAsk.say(r.held && r.held.length ? 'Saved. ' + r.held.join(', ') + ' waits for our team: it may name a sacred or protected site.' : 'Tags saved.', { anchor: b }); load(); }).catch(fail); break;
          case 'place-add': var pa = card.querySelector('.cg-placeadd'); pa.hidden = !pa.hidden; if (!pa.hidden) pa.querySelector('input').focus(); break;
          case 'place-pick': post({ action: 'place_add', group_id: gid, ref: b.getAttribute('data-r'), note: card.querySelector('.cg-placeadd [name=note]').value }).then(ok('Added. Its page shows the group under Featured in.')).catch(fail); break;
          case 'place-off': TvAsk.confirm('Take it off the group\'s list?', { anchor: b, yes: 'Take it off', danger: true }).then(function (y) { if (y) post({ action: 'place_remove', group_id: gid, ref: b.getAttribute('data-r') }).then(ok('Taken off.')).catch(fail); }); break;
          case 'ch-open': var co = card.querySelector('.cg-chopen'); co.hidden = !co.hidden; card.querySelector('.cg-choffer').hidden = true; break;
          case 'ch-offer': case 'ch-ask': var cf = card.querySelector('.cg-choffer'); cf.hidden = !cf.hidden; if (card.querySelector('.cg-chopen')) card.querySelector('.cg-chopen').hidden = true; cf.setAttribute('data-side', g === 'ch-offer' ? 'parent' : 'group'); if (!cf.hidden) cf.querySelector('input').focus(); break;
          case 'ch-place': var bx = b.closest('.cg-chopen'); bx.setAttribute('data-k', b.getAttribute('data-k')); bx.querySelector('.cg-chplace').value = b.getAttribute('data-l'); bx.querySelector('.cg-chout').innerHTML = ''; if (!bx.querySelector('.cg-chname').value) bx.querySelector('.cg-chname').value = b.getAttribute('data-l'); break;
          case 'ch-send': var cb = b.closest('.cg-chopen'), topic = cb.querySelector('[name=chk]:checked').value === 'topic';
            if (!topic && !cb.getAttribute('data-k')) { TvAsk.say('Pick the chapter\'s place from the list first.', { anchor: b, bad: true }); break; }
            post({ action: 'chapter_open', group_id: gid, place: topic ? '' : cb.getAttribute('data-k'), name: cb.querySelector('.cg-chname').value }).then(function (r) {
              if (r.status === 'active') location.href = '/community/group.php?id=' + r.chapter_id; else { TvAsk.say('Asked. The group\'s owner decides; you\'ll get a notice.', { anchor: b }); load(); }
            }).catch(fail); break;
          case 'ch-yes': case 'ch-no': post({ action: 'chapter_decide', chapter_id: +b.getAttribute('data-c'), yes: g === 'ch-yes' }).then(ok(g === 'ch-yes' ? 'Opened. Its lead is told.' : 'Declined. They\'re told.')).catch(fail); break;
          case 'offer-pick': var side2 = b.closest('.cg-choffer').getAttribute('data-side'), other = +b.getAttribute('data-id');
            post({ action: 'chapter_offer', parent_id: side2 === 'parent' ? gid : other, group_id: side2 === 'parent' ? other : gid, side: side2 }).then(ok('Sent. Whoever runs it answers on their page.')).catch(fail); break;
          case 'ch-lead': TvAsk.ask('The new lead\'s name, as in the member list', '', { yes: 'Next' }).then(function (nm) {
              if (!nm) return; var m = (d.members || []).filter(function (x) { return x.name.toLowerCase() === nm.trim().toLowerCase() && x.status === 'active'; })[0];
              if (!m) { TvAsk.say('No member by that name here. Join the chapter to see its members.', { anchor: b, bad: true }); return; }
              post({ action: 'chapter_lead', chapter_id: gid, user_id: m.id }).then(ok('Done. The chapter is told.')).catch(fail);
            }); break;
          case 'invite': var iv = card.querySelector('.cg-inv'); if (iv.innerHTML) { iv.innerHTML = ''; break; }
            fetch(API + '?invitable=' + gid, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (r) {
              var ps = r.people || [];
              iv.innerHTML = !ps.length ? '<p class="cg-s mt-2">No connections to invite. Connect with people in your Address Book first, or share the group\'s link.</p>'
                : '<div class="cg-list mt-2">' + ps.map(function (p) { return '<label class="cg-li"><span>' + esc(p.name) + (p.invited ? ' <span class="cg-s">invited</span>' : '') + '</span><input type="checkbox" value="' + p.id + '"' + (p.invited ? ' disabled' : '') + '></label>'; }).join('') + '</div>'
                  + '<div class="cg-acts mt-2">' + btn('Send invitations', 'data-g="invite-send"', 'go') + '</div>';
            }).catch(fail); break;
          case 'invite-send': var ids = Array.prototype.map.call(card.querySelectorAll('.cg-inv input:checked'), function (x) { return +x.value; });
            if (!ids.length) { TvAsk.say('Tick who to invite.', { anchor: b, bad: true }); break; }
            post({ action: 'invite', group_id: gid, user_ids: ids }).then(function (r) { TvAsk.say('Sent ' + r.sent + (r.skipped ? '; ' + r.skipped + ' skipped (already in, or invited lately)' : '') + '.', { anchor: b }); card.querySelector('.cg-inv').innerHTML = ''; }).catch(fail); break;
          case 'code-make': TvAsk.ask('What it\'s for (shown only to you): a meeting, a class, a list', '', { yes: 'Next' }).then(function (label) {
              if (label === null) return;
              TvAsk.ask('How many days it works (blank: until you switch it off)', '30', { yes: 'Next' }).then(function (days) {
                if (days === null) return;
                var mk = function (skip) { post({ action: 'code_make', group_id: gid, label: label, days: +days || 0, uses: 0, skip: skip }).then(function (r) { copyCode(r.code, b); load(); }).catch(fail); };
                if (d.group.join_mode === 'approval' && d.charter && d.charter.codes_skip) TvAsk.confirm('Let people with this code straight in, without approval?', { anchor: b, yes: 'Yes, let them in', no: 'No, still approve them' }).then(function (y) { mk(!!y); });
                else mk(false);
              });
            }); break;
          case 'code-copy': copyCode(b.getAttribute('data-k'), b); break;
          case 'code-off': TvAsk.confirm('Switch this code off? Its link stops letting people in.', { anchor: b, yes: 'Switch off', danger: true }).then(function (y) { if (y) post({ action: 'code_off', group_id: gid, code_id: +b.getAttribute('data-c') }).then(ok('Switched off.')).catch(fail); }); break;
          case 'welcome': post({ action: 'welcome', group_id: gid, message: card.querySelector('.cg-wmsg').value }).then(ok('Saved. New members get it when they join.')).catch(fail); break;
        }
      });
    });
  }
  function copyCode(code, anchor) {
    var url = location.origin + '/community/group.php?id=' + gid + '&code=' + code + '&src=code';
    var done = function () { TvAsk.say('Link copied: ' + url, { anchor: anchor }); };
    if (navigator.clipboard) navigator.clipboard.writeText(url).then(done, done); else done();
  }
  // pin or unpin a post as the welcome post anyone can read
  root.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pin]'); if (!b) return;
    post({ action: 'welcome', group_id: gid, post_id: +b.getAttribute('data-pin') }).then(function () { location.reload(); }).catch(function (x) { TvAsk.say(x.message, { anchor: b, bad: true }); });
  });
  load();
})();
</script>
<?php tv_page_end();
