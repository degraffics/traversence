<?php
// app/lib/LegalTexts.php — every legal text is a template (decisions/0142 §1): Platform Terms, Privacy Policy, Seller
// Agreement, the store policies' master clauses and the checkout line. They live with the content templates
// (ContentTemplates, the `legal` family: spec family = legal), edited in System Configuration → Content templates, where
// every save keeps a version. Publishing one gives it a version label (v2026.1), an effective date and, when the change
// matters, "needs acceptance"; a published version is the text people see from its date. Until one is published, the
// site keeps today's page (terms.php, privacy.php) and the built-in wording.
//
// Placeholders fill from identity, never by hand: Traversence's own from System Configuration → Settings (the LEGAL_*
// settings, with the interim details of decisions/0142 until they're set), a business's from its listing (and later its
// Business Identification, 0141 §3). Written {legal_name}, {address}, {email}, {state}, {county}, {platform}; a store's
// {business}, {days}, {rules}.
//
// A section's text is a small Markdown: paragraphs, "- " and "1. " lists, ### a sub-heading, **bold**, *italic*, `code`,
// [links](/page), | tables |, and {choices_card} (the Privacy Policy's live choices box).
declare(strict_types=1);

require_once __DIR__ . '/ContentTemplates.php';

final class LegalTexts
{
    /** doc => [name, its public page or '', who accepts it and when] */
    public const DOCS = [
        'terms' => ['Platform Terms', '/terms.php', 'Everyone: on signing up, and again when a published version needs it.'],
        'privacy' => ['Privacy Policy', '/privacy.php', 'Shown with the Terms.'],
        'seller' => ['Seller Agreement', '', 'A business, before its shop goes live, and again on a version that needs it (coming next).'],
        'store_policies' => ['Store policies master', '', 'Buyers, at checkout: each business\'s choices pick its clauses; the locked ones are in every store\'s policies.'],
        'checkout' => ['Checkout disclosures', '', 'Buyers: the line above Place order.'],
    ];

    /** Sections added to a first draft later: doc => [section key => the key it goes after]. */
    private const ADDED = ['seller' => ['warranties' => 'selling', 'indemnity' => 'customers', 'records' => 'pausing']];
    /** Sections reworded later: doc => [key => its first draft's text]; replaced only if still exactly that. */
    private const REWORDED = ['seller' => ['pausing' => 'If a shop breaks this agreement or the law, or repeats a problem after we\'ve told you, we may pause it. Pausing closes the shop only: your listing and map pin stay. We tell you why and how to reopen it.']];

    /** Traversence's identity: setting => [placeholder, its default until set (decisions/0142 §1, interim)] */
    public const IDENTITY = [
        'LEGAL_NAME' => ['legal_name', 'Traversence.com'],
        'LEGAL_ADDRESS' => ['address', 'PO Box 3570, Saint Johns, AZ 85936'],
        'LEGAL_EMAIL' => ['email', 'support@traversence.com'],
        'LEGAL_STATE' => ['state', 'Arizona'],
        'LEGAL_COUNTY' => ['county', 'Apache County'],
    ];

    public static function slug(string $doc): string { return 'legal_' . $doc; }

    public static function isLegal(?array $t): bool { return $t !== null && ($t['spec']['family'] ?? '') === 'legal'; }

    /** Sets up any legal template not there yet, from the first drafts. Returns how many it made. */
    public static function seed(PDO $pdo): int
    {
        if (!ContentTemplates::ready($pdo)) return 0;
        $n = 0; $seed = null;
        // sections added to a first draft after it was set up (Jason, 2026-11-03: the Seller Agreement's shield clauses):
        // put into the template once, as a version of their own; one someone removed later isn't put back
        foreach (self::ADDED as $doc => $adds) {
            $t = ContentTemplates::get($pdo, self::slug($doc));
            if (!self::isLegal($t)) continue;
            $spec = $t['spec']; $done = (array) ($spec['added'] ?? []); $have = array_column((array) $spec['sections'], 'key'); $changed = [];
            $seed ??= require __DIR__ . '/legal-seed.php';
            $from = array_column((array) ($seed[$doc] ?? []), null, 'key');
            foreach ($adds as $key => $after) {
                if (in_array($key, $done, true)) continue;
                $done[] = $key;
                if (in_array($key, $have, true) || !isset($from[$key])) continue;
                $at = array_search($after, array_column($spec['sections'], 'key'), true);
                array_splice($spec['sections'], $at === false ? count($spec['sections']) : $at + 1, 0, [$from[$key]]);
                $changed[] = $from[$key]['title'];
            }
            foreach (self::REWORDED[$doc] ?? [] as $key => $oldBody) {   // a section's new wording, only where nobody has changed it
                if (in_array('reword:' . $key, $done, true)) continue;
                $done[] = 'reword:' . $key;
                foreach ($spec['sections'] as $i => $sec) if ($sec['key'] === $key && trim((string) $sec['body']) === $oldBody && isset($from[$key])) { $spec['sections'][$i] = $from[$key]; $changed[] = $from[$key]['title'] . ' (reworded)'; }
            }
            if ($done !== (array) ($spec['added'] ?? [])) { $spec['added'] = $done; ContentTemplates::save($pdo, (int) $t['id'], ['spec' => $spec], 0, $changed ? 'Added (decisions/0142): ' . implode(', ', $changed) . '. A draft until published.' : 'Noted the added sections.'); }
        }
        foreach (self::DOCS as $doc => [$name]) {
            if (ContentTemplates::get($pdo, self::slug($doc))) continue;
            $seed ??= require __DIR__ . '/legal-seed.php';
            ContentTemplates::create($pdo, self::slug($doc), $name, 'sections', ['family' => 'legal', 'doc' => $doc, 'sections' => self::clean((array) ($seed[$doc] ?? [])), 'published' => []], 0,
                'First draft (decisions/0142), for the attorney\'s review.', 'draft');
            $n++;
        }
        return $n;
    }

    /** seed() at most once a request, where a legal text is shown before anyone has opened Content templates. */
    private static function seedOnce(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        try { self::seed($pdo); } catch (Throwable $x) { error_log('legal seed: ' . $x->getMessage()); }
    }

    /** The legal templates, in DOCS order: [doc => row]. */
    public static function all(PDO $pdo): array
    {
        $out = [];
        foreach (array_keys(self::DOCS) as $doc) if ($t = ContentTemplates::get($pdo, self::slug($doc))) $out[$doc] = $t;
        return $out;
    }

    /** Traversence's own placeholders. */
    public static function identity(): array
    {
        $v = ['platform' => 'Traversence'];
        foreach (self::IDENTITY as $k => [$ph, $dflt]) { $s = trim((string) getenv($k)); $v[$ph] = $s !== '' ? $s : $dflt; }
        return $v;
    }

    /** Sections as kept: [key, title, body, locked]. */
    public static function clean(array $secs): array
    {
        $out = []; $seen = [];
        foreach ($secs as $s) {
            $title = mb_substr(trim((string) ($s['title'] ?? '')), 0, 160);
            $body = mb_substr(str_replace("\r", '', trim((string) ($s['body'] ?? ''))), 0, 20000);
            if ($title === '' && $body === '') continue;
            $key = trim((string) preg_replace('/[^a-z0-9_]+/', '-', strtolower((string) ($s['key'] ?? '') !== '' ? (string) $s['key'] : $title)), '-') ?: 's';
            $k = $key; $i = 2; while (isset($seen[$k])) $k = $key . '-' . $i++;
            $seen[$k] = true;
            $out[] = ['key' => $k, 'title' => $title, 'body' => $body] + (!empty($s['locked']) ? ['locked' => true] : []);
        }
        return $out;
    }

    // ---- publishing -----------------------------------------------------------------------------------------------------

    /**
     * Publishes the template as it's saved now: its version gets a label, an effective date and whether people must
     * accept it again. Kept as a new version of its own (the record of publishing), so the text published never moves.
     */
    public static function publish(PDO $pdo, int $id, string $label, string $effective, bool $needs, int $uid): string
    {
        $t = ContentTemplates::get($pdo, $id);
        if (!self::isLegal($t)) throw new InvalidArgumentException('That isn\'t a legal text.');
        $label = trim($label);
        if (!preg_match('/^v\d{4}\.\d{1,3}$/', $label)) throw new InvalidArgumentException('Write the version like v2026.1.');
        foreach ((array) ($t['spec']['published'] ?? []) as $p) if (($p['label'] ?? '') === $label) throw new InvalidArgumentException($label . ' is published already: use the next number.');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $effective) || strtotime($effective) === false) throw new InvalidArgumentException('Choose the date it takes effect.');
        if ($effective < date('Y-m-d')) throw new InvalidArgumentException('It can take effect today or later, not before.');
        if (!$t['spec']['sections']) throw new InvalidArgumentException('There\'s nothing in it to publish.');
        $spec = $t['spec'];
        $spec['published'][] = ['version' => (int) $t['version'], 'label' => $label, 'effective' => $effective, 'needs' => $needs, 'at' => date('Y-m-d H:i:s'), 'by' => $uid];
        ContentTemplates::save($pdo, $id, ['spec' => $spec, 'status' => 'active'], $uid, 'Published ' . $label . ', in effect ' . $effective . ($needs ? ', needs acceptance' : '') . '.');
        return $label;
    }

    /** The published version in effect today for a doc: [label, effective, needs, version, sections] or null (none yet). */
    public static function live(PDO $pdo, string $doc): ?array
    {
        $t = ContentTemplates::get($pdo, self::slug($doc));
        if (!self::isLegal($t)) return null;
        $now = null; $today = date('Y-m-d');
        foreach ((array) ($t['spec']['published'] ?? []) as $p) if (($p['effective'] ?? '9') <= $today && (!$now || $p['effective'] >= $now['effective'])) $now = $p;
        if (!$now) return null;
        $st = $pdo->prepare('SELECT spec FROM content_template_versions WHERE template_id = ? AND version = ?'); $st->execute([(int) $t['id'], (int) $now['version']]);
        $spec = json_decode((string) $st->fetchColumn(), true) ?: [];
        return $now + ['sections' => (array) ($spec['sections'] ?? []), 'template_id' => (int) $t['id']];
    }

    /** One clause's wording by key: the published version's, else the first draft's (store policies, the checkout line). */
    public static function clause(PDO $pdo, string $doc, string $key): array
    {
        $all = self::clauses($pdo, $doc);
        return ($all['by'][$key] ?? ['key' => $key, 'title' => '', 'body' => '']) + ['version' => $all['label']];
    }

    /** All of a doc's clauses: ['label' => its version, 'by' => key => section]. */
    public static function clauses(PDO $pdo, string $doc): array
    {
        static $cache = [];
        if (!isset($cache[$doc])) {
            $l = null; try { $l = self::live($pdo, $doc); } catch (Throwable $x) { error_log('legal clause: ' . $x->getMessage()); }
            $secs = $l ? $l['sections'] : (array) ((require __DIR__ . '/legal-seed.php')[$doc] ?? []);
            $cache[$doc] = ['label' => $l['label'] ?? 'draft', 'by' => array_column(self::clean($secs), null, 'key')];
        }
        return $cache[$doc];
    }

    /** What someone accepting a doc is shown now: [version label, the exact text]. Unpublished: today's page, as 'site'
     *  (or, for a text with no page, its saved draft, as 'draft'). */
    public static function current(PDO $pdo, string $doc): array
    {
        $l = null; try { $l = self::live($pdo, $doc); } catch (Throwable $x) { error_log('legal current: ' . $x->getMessage()); }
        if ($l) return [$l['label'], self::text($l['sections'], self::identity())];
        $page = self::DOCS[$doc][1] ?? '';
        if ($page === '') {   // no page of its own (the Seller Agreement): the template's text as saved, else the first draft, as 'draft'
            self::seedOnce($pdo);
            $t = null; try { $t = ContentTemplates::get($pdo, self::slug($doc)); } catch (Throwable) {}
            $secs = self::isLegal($t) ? (array) $t['spec']['sections'] : (array) ((require __DIR__ . '/legal-seed.php')[$doc] ?? []);
            return ['draft', self::text($secs, self::identity())];
        }
        $file = $page !== '' ? dirname(__DIR__, 2) . '/website' . $page : '';
        return ['site', $file !== '' && is_file($file) ? (string) file_get_contents($file) : $doc];
    }

    // ---- filling and showing -------------------------------------------------------------------------------------------

    public static function fill(string $s, array $vars): string
    {
        $map = [];
        foreach ($vars as $k => $v) $map['{' . $k . '}'] = (string) $v;
        return strtr($s, $map);
    }

    /** Plain text of sections, filled: what a fingerprint is taken of. */
    public static function text(array $secs, array $vars): string
    {
        $out = '';
        foreach ($secs as $s) $out .= self::fill((string) ($s['title'] ?? ''), $vars) . "\n" . self::fill((string) ($s['body'] ?? ''), $vars) . "\n\n";
        return trim($out);
    }

    /** Sections as the page shows them: a heading each (its key the anchor) and its text. $opt: choices (the live box's HTML). */
    public static function html(array $secs, array $vars, array $opt = []): string
    {
        $h = '';
        foreach ($secs as $s) {
            $h .= '<h2 class="lg-h" id="' . htmlspecialchars((string) $s['key'], ENT_QUOTES) . '">' . htmlspecialchars(self::fill((string) $s['title'], $vars), ENT_QUOTES) . '</h2>'
                . self::md(self::fill((string) $s['body'], $vars), $opt);
        }
        return $h;
    }

    /** The small Markdown, escaped first. */
    public static function md(string $s, array $opt = []): string
    {
        $e = fn (string $x) => htmlspecialchars($x, ENT_QUOTES);
        $inline = function (string $x) use ($e): string {
            $x = $e($x);
            $x = (string) preg_replace_callback('/\[([^\]]+)\]\(([^)\s]+)\)/', function ($m) {
                $u = html_entity_decode($m[2], ENT_QUOTES);
                $ok = preg_match('#^(/(?!/)|https://|mailto:)#', $u) === 1;
                return $ok ? '<a class="underline" href="' . htmlspecialchars($u, ENT_QUOTES) . '"' . (str_starts_with($u, 'https://') ? ' target="_blank" rel="noopener"' : '') . '>' . $m[1] . '</a>' : $m[1];
            }, $x);
            $x = (string) preg_replace('/\*\*(.+?)\*\*/', '<b>$1</b>', $x);
            $x = (string) preg_replace('/(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])/', '<i>$1</i>', $x);
            return (string) preg_replace('/`([^`]+)`/', '<code>$1</code>', $x);
        };
        $h = '';
        foreach (preg_split('/\n\s*\n/', trim($s)) ?: [] as $b) {
            $b = trim($b);
            if ($b === '') continue;
            if ($b === '{choices_card}') { $h .= $opt['choices'] ?? ''; continue; }
            $lines = explode("\n", $b);
            if (str_starts_with($b, '### ')) { $h .= '<h3 class="lg-h3">' . $inline(substr($lines[0], 4)) . '</h3>'; $lines = array_slice($lines, 1); if (!$lines) continue; $b = implode("\n", $lines); }
            if (preg_match('/^\|.*\|$/', $lines[0])) {
                $rows = array_values(array_filter($lines, fn ($l) => !preg_match('/^\|[\s|:-]+\|$/', trim($l))));
                $h .= '<div class="lg-tw"><table class="lg-t">';
                foreach ($rows as $i => $r) {
                    $cells = array_map('trim', explode('|', trim(trim($r), '|')));
                    $tag = $i === 0 ? 'th' : 'td';
                    $h .= ($i === 0 ? '<thead>' : ($i === 1 ? '<tbody>' : '')) . '<tr>' . implode('', array_map(fn ($c) => "<$tag>" . $inline($c) . "</$tag>", $cells)) . '</tr>' . ($i === 0 ? '</thead>' : '');
                }
                $h .= (count($rows) > 1 ? '</tbody>' : '') . '</table></div>';
            } elseif (preg_match('/^(- |1\. )/', $lines[0])) {
                $ol = str_starts_with($lines[0], '1. ');
                $h .= $ol ? '<ol>' : '<ul>';
                foreach ($lines as $l) if (preg_match('/^(?:- |\d+\. )(.*)$/', $l, $m)) $h .= '<li>' . $inline($m[1]) . '</li>'; elseif (trim($l) !== '') $h .= '<li>' . $inline(trim($l)) . '</li>';
                $h .= $ol ? '</ol>' : '</ul>';
            } else $h .= '<p>' . $inline(implode(' ', array_map('trim', $lines))) . '</p>';
        }
        return $h;
    }

    /** A doc as shown to someone accepting it now (the Seller Agreement in E-commerce setup): its sections, filled. */
    public static function shown(PDO $pdo, string $doc): string
    {
        $l = null; try { $l = self::live($pdo, $doc); } catch (Throwable) {}
        if ($l) return self::html($l['sections'], self::identity());
        self::seedOnce($pdo);
        $t = null; try { $t = ContentTemplates::get($pdo, self::slug($doc)); } catch (Throwable) {}
        return self::html(self::isLegal($t) ? (array) $t['spec']['sections'] : (array) ((require __DIR__ . '/legal-seed.php')[$doc] ?? []), self::identity());
    }

    /** The public page for a published Terms or Privacy Policy: its version and date, then the sections. */
    public static function page(array $live, string $title, array $opt = []): string
    {
        return '<h1 class="font-serif font-bold text-3xl">' . htmlspecialchars($title, ENT_QUOTES) . '</h1>'
            . '<p class="text-sm text-[#8A7355]">Version ' . htmlspecialchars((string) $live['label'], ENT_QUOTES) . ' · in effect ' . date('F j, Y', strtotime((string) $live['effective'])) . '</p>'
            . self::html($live['sections'], self::identity(), $opt);
    }

    public static function css(): string
    {
        return '<style>.lg-h{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.125rem;color:#3E2B1F;margin:1.5rem 0 .25rem}.lg-h3{font-weight:600;margin:.8rem 0 .2rem}'
            . '.lg-tw{overflow-x:auto;margin:.4rem 0 .8rem}.lg-t{width:100%;border-collapse:collapse;font-size:.88rem}.lg-t th,.lg-t td{border-bottom:1px solid #EADFC4;padding:.35rem .45rem;text-align:left;vertical-align:top}'
            . '.pv ol{margin:.3rem 0 .6rem 1.2rem;list-style:decimal}</style>';
    }
}
