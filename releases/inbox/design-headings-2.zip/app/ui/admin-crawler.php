<?php
/**
 * includes/admin-crawler.php — the Admin → Crawler workspace frame (decisions/0046).
 *
 * One place for the website's data: what the crawler finds, what needs a person, what went live, where
 * it came from, and how places are organized. Every Crawler page opens with tv_crawler_start() and ends
 * with tv_crawler_end(); between them is the page's own content.
 *
 * Navigation is an icon rail: a column on the left on wider screens, a single swipeable row across the
 * top of the content on a phone. Icons follow the main nav's states: flat gold at rest, green with a
 * glow on the page you're on. The Review icon carries a count of what's waiting for you.
 *
 *   require_once __DIR__ . '/../../app/ui/admin-crawler.php';   // from website/admin/
 *   tv_crawler_start('review', 'Review', $pdo);
 *   ...page content...
 *   tv_crawler_end();
 */

require_once __DIR__ . '/page-shell.php';

/**
 * The signed-in admin, or an "Admin only" page and exit. Needs api/bootstrap.php loaded first.
 */
function tv_crawler_require_admin(PDO $pdo): array
{
    require_once __DIR__ . '/../lib/crawler/IntakeStager.php';
    $me = Auth::currentUser();
    if ($me !== null && IntakeStager::canUseIntake($pdo, $me)) return $me;
    http_response_code($me === null ? 401 : 403);
    tv_page_start('Admin');
    echo '<div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Admin only</h1><p class="text-sm text-[#5C4632] mt-2">'
        . ($me === null ? 'Please <a class="underline text-amber-700" href="/login.php?next=' . htmlspecialchars(rawurlencode((string) ($_SERVER['REQUEST_URI'] ?? '/admin/')), ENT_QUOTES) . '">sign in</a> with an admin account.' : 'This account is not an admin.')
        . '</p></div>';
    tv_page_end();
    exit;
}

/**
 * Staff who add and edit listings (decisions/0073 §6): admins, and regional managers (admin_access regional_admin).
 * The rest of the crawler (sources, intake) stays admin-only.
 */
function tv_listing_staff_require(PDO $pdo): array
{
    $me = Auth::currentUser();
    if ($me !== null) {
        require_once __DIR__ . '/../lib/crawler/IntakeStager.php';
        if (IntakeStager::canUseIntake($pdo, $me)) return $me;
        try { $st = $pdo->prepare("SELECT 1 FROM " . Database::t('admin_access') . " WHERE user_id = ? AND tier = 'regional_admin' LIMIT 1"); $st->execute([(int) $me['id']]); if ($st->fetchColumn()) return $me; } catch (Throwable) {}
    }
    return tv_crawler_require_admin($pdo);   // "Admin only", and stops
}

/** A short message carried across the redirect after a POST, shown as a toast on the next page. */
function tv_crawler_flash(?array $set = null): ?array
{
    if ($set !== null) { $_SESSION['tc_flash'] = $set; return null; }
    $f = $_SESSION['tc_flash'] ?? null;
    unset($_SESSION['tc_flash']);
    return $f;
}

/** The Crawler pages, in rail order: key => [label, url, what it's for, svg paths]. */
function tv_crawler_pages(): array
{
    return [
        'overview' => ['Overview', '/admin/crawler.php', 'Is the crawler running, and how far along it is',
            '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>'],
        'review' => ['Review', '/admin/crawler-review.php', 'Everything waiting for your decision',
            '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>'],
        'published' => ['Published', '/admin/auto-imports.php', 'What the crawler published on its own',
            '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>'],
        'sources' => ['Sources', '/admin/sources.php', 'Websites that confirm places',
            '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>'],
        'stories' => ['Stories', '/admin/stories.php', 'Guide stories for place pages: write, check, publish',
            '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>'],
        'places' => ['Places', '/admin/cluster-tools.php?view=places', 'Geo-hubs, clusters, ZIPs and anchors',
            '<polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>'],
        'coverage' => ['Coverage', '/admin/cluster-tools.php?view=coverage', 'Gaps in the directory, and the crawl queue',
            '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>'],
        'crawl' => ['Crawl a site', '/admin/listing-intake.php', 'Point the crawler at one website',
            '<path d="m8 2 1.88 1.88"/><path d="M14.12 3.88 16 2"/><path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"/><path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/><path d="M12 20v-9"/><path d="M6.53 9C4.6 8.8 3 7.1 3 5"/><path d="M6 13H2"/><path d="M3 21c0-2.1 1.7-3.9 3.8-4"/><path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/><path d="M22 13h-4"/><path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/>'],
        'geocode' => ['Map points', '/admin/geocode.php', 'Street addresses turned into map points (U.S. Census)',
            '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>'],
        'data' => ['Data loads', '/admin/cluster-tools.php?view=data', 'Census populations and place profiles',
            '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>'],
    ];
}

/** How many things are waiting for a person, by kind. Each count is skipped if its table isn't there yet. */
/** Found listings that need a person: the ones the pipeline ran out of things to try on (AutoImport::exhausted). */
function tv_listings_need_person(PDO $pdo): int
{
    static $n = null;
    if ($n !== null) return $n;
    require_once __DIR__ . '/../lib/crawler/AutoImport.php';
    $n = 0;
    try {
        foreach ($pdo->query("SELECT raw_payload, created_at FROM " . Database::t('crawler_raw_index') . " WHERE status = 'staged' AND payload_type = 'listing'")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $c = json_decode((string) $r['raw_payload'], true);
            if (is_array($c) && AutoImport::exhausted($c, (string) $r['created_at'])) $n++;
        }
    } catch (Throwable) {}
    return $n;
}

function tv_crawler_waiting(PDO $pdo): array
{
    $q = function (string $sql) use ($pdo): int {
        try { return (int) $pdo->query($sql)->fetchColumn(); } catch (Throwable) { return 0; }
    };
    return [
        'listings' => tv_listings_need_person($pdo),   // only what the pipeline gave up on (decisions/0076, 0081), as Review shows
        'sources' => $q("SELECT COUNT(*) FROM " . Database::t('reference_sources') . " WHERE status = 'suggested'"),
        'names' => $q("SELECT COUNT(*) FROM cluster_subgroups WHERE status = 'suggested'"),
        'clusters' => $q("SELECT COUNT(*) FROM micro_clusters WHERE name LIKE '%(auto-seeded%'"),
        'suggestions' => $q("SELECT COUNT(*) FROM suggestions WHERE status = 'new'"),   // from visitors (decisions/0053)
    ];
}

function tv_crawler_icon(string $paths, string $cls = 'tc-svg'): string
{
    return '<svg class="' . $cls . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths . '</svg>';
}

function tv_crawler_start(string $active, string $title, ?PDO $pdo = null, string $intro = ''): void
{
    // The crawler's own toolbar, in the one layout (decisions/0055 §1): full height on the left, the page on the right.
    $waiting = $pdo ? array_sum(tv_crawler_waiting($pdo)) : 0;
    // the admin menu, with the crawler's pages open as a group, so the menu stays the same at every level
    require_once __DIR__ . '/section-rails.php';
    // the listing tools are sections of Manage listings (admin/listings.php): its menu entry stays lit on each of them
    $key = in_array($active, ['review', 'listings', 'published', 'edit'], true) ? 'listings' : 'crawler:' . $active;
    $rail = tv_admin_rail($key, false, $waiting);
    tv_page_start($title, ['wide' => true, 'description' => 'Traversence admin: crawler.', 'rail' => $rail, 'rail_label' => 'Admin', 'active' => $key,
        'crumbs' => [['Admin', '/admin/'], ['Crawler', '/admin/crawler.php'], [$title]]]);
    ?>
<style>
  .tc-main a.ov-card,.tc-main a.rv-b,.ta-work a.ov-card,.ta-work a.rv-b{color:inherit;text-decoration:none}
  .ta-work a.rv-chip{text-decoration:none}
  .tc-h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.5rem,2.6vw,1.9rem);line-height:1.15;margin:0}
  .tc-intro{font-size:.9rem;color:#5C4632;margin-top:.3rem;max-width:52rem}
</style>
  <div class="tc-main">
    <h1 class="tc-h1"><?= tv_e($title) ?></h1>
    <?php if ($intro !== ''): ?><p class="tc-intro"><?= $intro ?></p><?php endif; ?>
<?php
}

function tv_crawler_end(): void
{
    $flash = tv_crawler_flash();
    ?>
  </div>
<?php if ($flash): ?>
<div id="tc-toast" role="status" data-tv-flash="<?= $flash[0] ? 'ok' : 'error' ?>" style="position:fixed;left:50%;bottom:1.2rem;transform:translateX(-50%);z-index:60;max-width:92vw;
  background:<?= $flash[0] ? '#14532D' : '#7F1D1D' ?>;color:#fff;border-radius:.8rem;padding:.6rem 1rem;font-size:.9rem;box-shadow:0 8px 20px rgba(0,0,0,.3)"><?= tv_e($flash[1]) ?></div>
<script>setTimeout(function () { var t = document.getElementById('tc-toast'); if (t) t.style.display = 'none'; }, 5000);</script>
<?php endif; ?>
<script>
  // After an action the page reloads where you were, not at the top.
  (function () {
    var key = 'tc-scroll:' + location.pathname + location.search;
    try { var y = sessionStorage.getItem(key); if (y !== null) { sessionStorage.removeItem(key); window.scrollTo(0, +y); } } catch (e) {}
    document.addEventListener('submit', function (e) {
      if ((e.target.method || '').toLowerCase() === 'post') { try { sessionStorage.setItem(key, String(window.scrollY)); } catch (x) {} }
    }, true);
  })();
</script>
<?php
    tv_page_end();
}
