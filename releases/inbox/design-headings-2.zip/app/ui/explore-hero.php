<?php
// includes/explore-hero.php — the Explore hero (decisions/0058 §18): the standard top of Let's Explore and of every
// place page (region, area, town area). Photos from the published journeys for that place and the places inside it
// (Journeys::hero by scope key), the title "Explore: <place>" with a pencil to change the place, the place's
// context (the region and area it's in) and, on Let's Explore, its tabs. One name, said once.
//
//   echo tv_explore_hero($pdo, ['name' => 'St. Johns', 'scope' => 'cluster:1', 'within' => [['Ancient Borderlands', '/hub/?geo=…']],
//                               'tabs' => [[key, label, icon, url], …], 'active' => 'regions', 'link' => '<span data-link=…>']);
//
// Also: tv_explore_art($seed) — a card's background when it has no photo (the brand's colours, a quiet topo line).

declare(strict_types=1);

function tv_explore_hero(?PDO $pdo, array $o): string
{
    static $n = 0; $n++;
    $name = (string) ($o['name'] ?? 'North America');
    $scope = (string) ($o['scope'] ?? '');
    $own = $o['slides'] ?? null;   // a listing's or a profile's own photos and videos (HeroMedia); a landmark's Commons photo
    // journeys' photos: for a level, its journeys; for one place ('near') or a listing ('tagged'), the journeys shared
    // there, shown after the owner's own (decisions/0058 §30)
    $slides = [];
    if ($pdo && ($own === null || !empty($o['tagged']) || !empty($o['near']))) {
        try {
            if (!class_exists('Journeys')) require_once __DIR__ . '/../lib/Journeys.php';
            if (Journeys::ready($pdo)) $slides = !empty($o['tagged']) ? Journeys::heroTagged($pdo, (int) $o['tagged'])
                : (!empty($o['near']) ? Journeys::heroNear($pdo, (float) $o['near'][0], (float) $o['near'][1]) : Journeys::hero($pdo, $scope, 5));
        } catch (Throwable $e) { error_log('explore hero: ' . $e->getMessage()); }
    }
    // no photo of its own and none shared: a stock photo from the library, labelled (decisions/0143), until a real one is
    // added (then this isn't reached). 'stock' => [subject, place, owner, representative, fallback, nudge (HTML)]
    $stk = null;
    if ($pdo && !$own && !$slides && !empty($o['stock'])) {
        try {
            require_once __DIR__ . '/../lib/StockLibrary.php';
            $so = (array) $o['stock'];
            $stk = StockLibrary::forSlot($pdo, 'hero', (string) ($so['owner'] ?? ''), (string) ($so['subject'] ?? ''), (string) ($so['place'] ?? ''),
                ['representative' => !empty($so['representative']), 'fallback' => (string) ($so['fallback'] ?? 'landscape')]);
        } catch (Throwable $e) { error_log('explore hero stock: ' . $e->getMessage()); }
    }
    // none of those either: the page's own photos of what's there ('fallback_slides': Let's Explore passes its landmarks' Commons
    // photos, credited; Jason, 2026-11-12: "put photos in the library: this requires manual work")
    if (!$own && !$slides && !$stk && !empty($o['fallback_slides'])) $own = (array) $o['fallback_slides'];
    $id = 'xh-' . $n;
    $h = $n === 1 ? tv_explore_hero_css() : '';
    $none = !$own && !$slides && !$stk;   // no photos or video at all: the hero shrinks to a band (decisions/0058 §33)
    $h .= '<section class="xh' . (empty($o['tabs']) ? ' xh-solo' : '') . ($none ? ' xh-nophoto' : '') . '"' . (!empty($o['link']) ? ' data-link-host' : '') . ' aria-label="' . tv_e('Explore ' . $name) . '"><div class="xh-track" id="' . $id . '">';
    $ownHtml = '';
    foreach ((array) $own as $s) {
        // a video loads from YouTube or Vimeo only when allowed or tapped (js/consent.js, decisions/0077)
        if (!empty($s['video'])) $ownHtml .= '<div class="xh-slide xh-vid"><div class="tv-vid" style="height:100%;aspect-ratio:auto;border-radius:0" data-vsrc="' . tv_e($s['video']) . '" data-vtitle="' . tv_e($s['caption'] ?: 'Video') . '"></div></div>';
        else $ownHtml .= '<div class="xh-slide xh-zoom" data-lb="' . tv_e($s['image']) . '" data-lb-cap="' . tv_e($s['caption']) . '" role="button" tabindex="0" aria-label="Open the photo" style="background-image:url(\'' . tv_e($s['image']) . '\')">'   // a tap opens the lightbox (decisions/0058 §28)
            . ($s['caption'] !== '' ? '<span class="xh-cap"><span>' . tv_e($s['caption']) . '</span></span>' : '') . '</div>';
    }
    $journeys = $slides;
    $slides = array_merge((array) $own, $journeys);   // counted for the arrows and "no photos"
    $jHtml = '';
    foreach ($journeys as $s) {
        $jHtml .= '<a class="xh-slide" href="' . tv_e($s['url']) . '" style="background-image:url(\'' . tv_e($s['image']) . '\')"><span class="xh-cap"><span>' . tv_e($s['caption'])
            . ($s['place'] ? ' · ' . tv_e($s['place']) : '') . '</span><span class="xh-cred"><span class="jr-av" aria-hidden="true">' . tv_e(mb_strtoupper(mb_substr((string) $s['author'], 0, 1)))
            . '</span><b>' . tv_e($s['author']) . '</b><span>♥ ' . (int) $s['likes'] . '</span></span></span></a>';
    }
    // the owner's photos lead (a listing, a profile); a landmark's Commons photo goes after visitors' journeys ('own_last')
    $h .= !empty($o['own_last']) ? $jHtml . $ownHtml : $ownHtml . $jHtml;
    if (!$slides && $stk) {   // a stock photo, labelled, with "Add your own photo" for whoever runs the page
        require_once __DIR__ . '/stock-ui.php';
        $h .= '<div class="xh-slide xh-stock" style="background-image:url(\'' . tv_e($stk['url']) . '\')"><div class="xh-stkw">'
            . tv_stock_tag($stk, ['at' => 'in', 'nudge' => (string) ($o['stock']['nudge'] ?? '')]) . '</div></div>';
    } elseif (!$slides) {   // no photos: the brand's art. "Be the first" is the camera button below, not a box (decisions/0058 §34)
        $h .= '<div class="xh-slide xh-empty" style="' . tv_explore_art($name, true) . '">'
            . (empty($o['manage']) && (string) ($o['empty'] ?? '') !== '' ? '<span class="xh-cap"><span>' . tv_e((string) $o['empty']) . '</span></span>' : '') . '</div>';
    }
    $h .= '</div><div class="xh-head' . (!empty($o['link']) ? ' xh-haslink' : '') . '"><h1 class="xh-title">' . (isset($o['heading']) ? '' : tv_icon('compass')) . '<span>' . tv_e(isset($o['heading']) ? (string) $o['heading'] : 'Explore: ' . $name) . '</span></h1>'
        . (($o['edit'] ?? true) ? '<button type="button" class="xh-edit" onclick="if(window.openLocationModal)openLocationModal()" title="Change the place" aria-label="Change the place">'
        . '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg></button>' : '')
        . (string) ($o['link'] ?? '')
        . (!empty($o['corner']) ? '<span class="xh-corner">' . $o['corner'] . '</span>' : '');   // the top-right corner: Claim or Manage on a listing
    // the line about the page sits right under the title, in the same block, so a long name pushes it down
    if (!empty($o['sub'])) $h .= '<p class="xh-in">' . tv_e((string) $o['sub']) . '</p>';   // a line about the page (Regions, Destinations…)
    elseif (!empty($o['trail'])) {   // a guide: the places above it from the top down, as the funnel runs (Ancient America › Ancient Borderlands › …)
        $h .= '<p class="xh-in xh-trail">' . implode(' <span aria-hidden="true">›</span> ', array_map(fn ($w) => $w[1] ? '<a href="' . tv_e($w[1]) . '">' . tv_e($w[0]) . '</a>' : tv_e($w[0]), $o['trail'])) . '</p>';
    }
    elseif (!empty($o['within'])) {   // the region and area it's in, each a way up
        $h .= '<p class="xh-in">in ' . implode(' · ', array_map(fn ($w) => $w[1] ? '<a href="' . tv_e($w[1]) . '">' . tv_e($w[0]) . '</a>' : tv_e($w[0]), $o['within'])) . '</p>';
    }
    $h .= '</div>';
    $acts = (string) ($o['actions'] ?? '');   // views, likes, Share, Save, Claim: over the hero's foot (decisions/0058 §22)
    if (!empty($o['manage'])) {   // the owner chooses the photos and videos (decisions/0058 §21)
        [$mk, $mr] = $o['manage'];
        $acts .= '<button type="button" class="xh-own" title="Photos and video" aria-label="Photos and video" data-hm-kind="' . tv_e((string) $mk) . '" data-hm-ref="' . (int) $mr . '"><svg class="ta-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg><span>Photos &amp; video</span></button>';
        $acts .= '<script src="/js/hero-media.js" defer></script>';
    }
    // one camera per person (decisions/0058 §34): whoever runs the page chooses its photos and video ('manage' above);
    // everyone else shares theirs as a journey, which then shows here, credited
    if (empty($o['manage']) && !(array_key_exists('empty', $o) && !isset($o['share']))) {
        $acts .= '<a class="xh-a xh-shr" href="' . tv_e((string) ($o['share'] ?? '/user/journeys/compose.php')) . '" title="' . tv_e($slides ? 'Share your photos or video of ' . (string) ($o['photos_of'] ?? $name) : 'No photos of ' . (string) ($o['photos_of'] ?? $name) . ' yet. Be the first: share a photo or video') . '" aria-label="Share a photo or video">'
            . '<svg class="ta-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><path d="M12 10v6M9 13h6"/></svg></a>';
    }
    if ($acts !== '') $h .= '<div class="xh-acts">' . $acts . '</div>';
    if (count($slides) > 1) $h .= '<button type="button" class="xh-arr l" data-xh="' . $id . '" data-d="-1" aria-label="Previous photo">&lsaquo;</button><button type="button" class="xh-arr r" data-xh="' . $id . '" data-d="1" aria-label="Next photo">&rsaquo;</button>';
    $h .= '</section>';
    if (!empty($o['tabs'])) {
        $h .= '<nav class="xh-tabs" aria-label="Explore by" style="grid-template-columns:repeat(' . count($o['tabs']) . ',1fr)">';
        foreach ($o['tabs'] as [$k, $label, $icon, $href]) {
            $on = ($o['active'] ?? '') === $k;
            $h .= '<a href="' . tv_e($href) . '"' . ($on ? ' class="on" aria-current="page"' : '') . '>' . tv_icon($icon) . '<span>' . tv_e($label) . '</span></a>';
        }
        $h .= '</nav>';
    }
    if (!empty($o['carousel'])) {   // cards of their own under the hero, two side by side on a phone, swiped left and right
        $cid = $id . '-c';
        $h .= '<section class="xh-car" aria-label="' . tv_e((string) ($o['carousel_label'] ?? 'More')) . '"><div class="xh-ct" id="' . $cid . '">' . $o['carousel'] . '</div>'
            . '<button type="button" class="xh-cn l" data-xh="' . $cid . '" data-d="-1" aria-label="Previous">&lsaquo;</button><button type="button" class="xh-cn r" data-xh="' . $cid . '" data-d="1" aria-label="Next">&rsaquo;</button></section>';
    }
    return $h;
}

/**
 * A photo card (decisions/0058 §18): regions, destinations, parks, experiences. $c: name, url ('' = not linked, shown
 * quieter), image ('' = the brand's art), badge, icon, kicker (under the name), text, stats (HTML pieces), chips.
 */
function tv_explore_card(array $c): string
{
    static $css = false;
    $c += ['image' => '', 'badge' => '', 'icon' => 'compass', 'kicker' => '', 'text' => '', 'stats' => [], 'chips' => [], 'url' => ''];
    $h = $css ? '' : tv_explore_card_css();
    $css = true;
    $bg = $c['image'] !== '' ? "background:url('" . tv_e($c['image']) . "') center/cover no-repeat" : tv_explore_art((string) $c['name']);
    $tag = $c['url'] !== '' ? 'a href="' . tv_e($c['url']) . '"' : 'div aria-disabled="true"';
    return $h . '<' . $tag . ' class="xc' . ($c['url'] === '' ? ' off' : '') . '"><span class="xc-art" style="' . $bg . '">' . ($c['badge'] !== '' ? '<em class="xc-badge' . ($c['url'] === '' ? ' soon' : '') . '">' . tv_e($c['badge']) . '</em>' : '')
        . '<span class="xc-ic">' . tv_icon((string) $c['icon']) . '</span><b>' . tv_e((string) $c['name']) . '</b>' . ($c['kicker'] !== '' ? '<small>' . tv_e((string) $c['kicker']) . '</small>' : '') . '</span>'
        . '<span class="xc-body">' . ($c['text'] !== '' ? '<span class="xc-text">' . tv_e((string) $c['text']) . '</span>' : '')
        . ($c['stats'] ? '<span class="xc-stats">' . implode('', array_map(fn ($x) => '<span>' . $x . '</span>', $c['stats'])) . '</span>' : '')
        . ($c['chips'] ? '<span class="xc-chips">' . implode('', array_map(fn ($x) => '<i>' . tv_e($x) . '</i>', $c['chips'])) . '</span>' : '')
        . '</span></' . ($c['url'] !== '' ? 'a' : 'div') . '>';
}

function tv_explore_card_css(): string
{
    return "<style>\n  /* the landing pages' cards (decisions/0058 §18) */
  .xl-lead{font-size:.95rem;color:#5C4632;line-height:1.5;margin:0 0 .9rem;max-width:46rem}
  .xc-grid{display:grid;gap:.8rem;grid-template-columns:repeat(auto-fill,minmax(270px,1fr))}
  .xc{display:flex;flex-direction:column;background:#FFFBF2;border:1px solid #CBB98D;border-radius:1rem;overflow:hidden;text-decoration:none;color:#3E2B1F;box-shadow:0 6px 16px -12px rgba(62,43,31,.45);transition:transform .15s,box-shadow .15s}
  a.xc:hover{transform:translateY(-2px);box-shadow:0 14px 24px -14px rgba(62,43,31,.55);border-color:#B8863B}
  .xc-art{position:relative;display:flex;flex-direction:column;justify-content:flex-end;aspect-ratio:16/9;padding:.8rem .9rem;color:#FFFBF2}
  .xc-art::before{content:\"\";position:absolute;inset:0;background:linear-gradient(180deg,rgba(30,20,12,0) 35%,rgba(30,20,12,.72))}
  .xc-art>*{position:relative}
  .xc-art b{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.3rem;line-height:1.15;text-shadow:0 2px 8px rgba(0,0,0,.5)}
  .xc-art small{font-size:.78rem;color:#F3DDB0;margin-top:.15rem}
  .xc-ic{position:absolute;top:.75rem;left:.85rem;width:34px;height:34px;border-radius:999px;background:rgba(255,251,242,.18);border:1px solid rgba(255,251,242,.45);display:flex;align-items:center;justify-content:center}
  .xc-ic .ta-svg{color:#FFFBF2;width:18px;height:18px}
  .xc-badge{position:absolute;top:.75rem;right:.75rem;font-style:normal;font-size:.62rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;border-radius:999px;padding:.2rem .55rem;background:#8FBCA8;color:#1F3B30}
  .xc-badge.soon{background:rgba(255,251,242,.85);color:#5C4632}
  .xc-body{display:flex;flex-direction:column;gap:.45rem;padding:.7rem .9rem .85rem}
  .xc-text{font-size:.85rem;color:#5C4632;line-height:1.45}
  .xc-stats{display:flex;flex-wrap:wrap;gap:.25rem .8rem;font-size:.78rem;color:#8A7355}.xc-stats b{color:#3E2B1F}
  .xc-chips{display:flex;flex-wrap:wrap;gap:.3rem}.xc-chips i{font-style:normal;font-size:.72rem;border:1px solid #E3D3AC;border-radius:999px;padding:.1rem .5rem;color:#5C4632;background:#F7EFDC}
  .xc.off{opacity:.78}.xc.off .xc-art{filter:saturate(.35)}
  @media (max-width:767px){.xc-grid{gap:3px}.xc{border-radius:.5rem}.xl-lead{margin:.2rem 0 .7rem}}
</style>";
}

/** A card's background with no photo: a gradient in the brand's earth tones picked by name, with a quiet topo line. */
function tv_explore_art(string $seed, bool $dark = false): string
{
    $pal = [['#7A5A3A', '#3E2B1F'], ['#8C6A3F', '#4A3523'], ['#5E6B4A', '#2F3A26'], ['#8A5A44', '#47291D'], ['#6B5B7A', '#352B40'], ['#4F6D73', '#24363A'], ['#9A7B4F', '#4E3B22']];
    [$a, $b] = $pal[abs(crc32($seed)) % count($pal)];
    $topo = "url('data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27240%27 height=%27160%27 viewBox=%270 0 240 160%27%3E%3Cg fill=%27none%27 stroke=%27%23FFFBF2%27 stroke-opacity=%27.13%27 stroke-width=%271.2%27%3E%3Cpath d=%27M-10 120c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3Cpath d=%27M-10 95c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3Cpath d=%27M-10 145c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3Cpath d=%27M-10 70c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3C/g%3E%3C/svg%3E')";   // no double quotes: it goes in a style=\"\" attribute
    return 'background:' . $topo . ',linear-gradient(135deg,' . $a . ' 0%,' . $b . ' ' . ($dark ? '70' : '100') . '%)';
}

function tv_explore_hero_css(): string
{
    return <<<'CSS'
<style>
  .xh{position:relative;border-radius:1.1rem 1.1rem 0 0;overflow:hidden;background:#3E2B1F;aspect-ratio:21/9;min-height:250px}
  .xh.xh-solo{border-radius:1.1rem}
  .xh-track{display:flex;height:100%;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none}.xh-track::-webkit-scrollbar{display:none}
  .xh-slide{flex:0 0 100%;scroll-snap-align:start;position:relative;background:#5A4330 center/cover no-repeat;text-decoration:none;color:#3E2B1F}
  .xh-slide::after{content:"";position:absolute;inset:0 0 auto 0;height:50%;background:linear-gradient(180deg,rgba(30,20,12,.72),rgba(30,20,12,.35) 55%,rgba(30,20,12,0));pointer-events:none}
  /* the photo's credit: small words in the bottom-left corner, no card (decisions/0058 §28) */
  .xh-slide::before{content:"";position:absolute;inset:auto 0 0 0;height:38%;background:linear-gradient(0deg,rgba(20,13,8,.62),rgba(20,13,8,0));pointer-events:none}
  .xh-cap{position:absolute;z-index:1;left:1rem;bottom:.8rem;max-width:min(17rem,44%);background:rgba(255,251,242,.14);border:1px solid rgba(255,251,242,.45);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);color:#FFFBF2;text-shadow:0 1px 3px rgba(0,0,0,.75);border-radius:.45rem;padding:.32rem .5rem .36rem;font-size:.66rem;line-height:1.35;box-shadow:0 6px 16px -10px rgba(0,0,0,.6)}
  .xh-cap>span:first-child{display:block;font-weight:600}
  .xh-stkw{position:absolute;z-index:3;left:1rem;bottom:.8rem;max-width:44%;display:flex;flex-direction:column;align-items:flex-start;gap:.35rem}
  @media (max-width:767px){.xh-stkw{left:.6rem;bottom:3.4rem;max-width:calc(100% - 1.2rem)}}
  .xh-cred{display:flex;align-items:center;gap:.3rem;margin-top:.2rem;font-size:.62rem;color:#F3DDB0}.xh-cred b{flex:1;font-weight:700;text-transform:uppercase;letter-spacing:.03em}.xh-cred .jr-av{width:15px;height:15px;font-size:.52rem}
  .xh-capb{display:inline-block;margin-top:.25rem;background:rgba(255,251,242,.16);border:1px solid rgba(255,251,242,.55);color:#FFFBF2;text-shadow:none;border-radius:999px;padding:.16rem .55rem;font-size:.64rem;font-weight:600;text-decoration:none}
  .xh-head{position:absolute;z-index:2;left:1rem;right:1rem;top:.85rem;display:flex;flex-wrap:wrap;align-items:center;gap:.25rem .5rem;pointer-events:none}
  .xh-head>*{pointer-events:auto}
  .xh-title{margin:0;display:flex;align-items:center;gap:.5rem;min-width:0;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.2rem,2.4vw,1.7rem);line-height:1.15;color:#FFFBF2;text-shadow:0 2px 8px rgba(0,0,0,.6);pointer-events:none}
  .xh-title .ta-svg{color:#FFFBF2;width:26px;height:26px;flex:0 0 26px}
  .xh-edit{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:999px;border:1px solid rgba(255,251,242,.6);background:rgba(62,43,31,.45);color:#FFFBF2;cursor:pointer;padding:0;backdrop-filter:blur(2px)}
  .xh-edit svg{width:15px;height:15px}.xh-edit:hover{background:rgba(62,43,31,.75);border-color:#FFFBF2}
  .xh-head [data-link]{margin-left:auto}
  .xh-in{order:9;flex:0 0 100%;margin:0;font-size:.82rem;color:#F3DDB0;text-shadow:0 1px 6px rgba(0,0,0,.8)}
  .xh-in a{color:#FFFBF2;text-decoration:underline;text-decoration-color:rgba(255,251,242,.45);text-underline-offset:3px}
  .xh-arr{position:absolute;top:50%;transform:translateY(-50%);width:34px;height:52px;border:0;background:rgba(62,43,31,.55);color:#FFFBF2;font-size:1.8rem;cursor:pointer}
  .xh-arr.l{left:0;border-radius:0 .6rem .6rem 0}.xh-arr.r{right:0;border-radius:.6rem 0 0 .6rem}
  .xh-tabs{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid #CBB98D;border-top:0;border-radius:0 0 .9rem .9rem;overflow:hidden;background:#FFFBF2;margin-bottom:1rem}
  .xh-tabs a{display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.65rem .5rem;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.05rem;color:#3E2B1F;text-decoration:none;border-left:1px solid #CBB98D;position:relative}
  .xh-tabs a:first-child{border-left:0}.xh-tabs a:hover{background:#F7EFDC}.xh-tabs .ta-svg{color:#B8863B}
  .xh-tabs a.on{background:#F7EFDC}.xh-tabs a.on::after{content:"";position:absolute;left:18%;right:18%;bottom:0;height:3px;border-radius:3px 3px 0 0;background:#8FBCA8}
  .xh-tabs a.on .ta-svg{color:#2F5D4A}
  .xh-solo{margin-bottom:1rem}
  .tv-page > .xh{margin-top:0 !important}   /* Tailwind's space-y on the page wrapper: the hero is the page's top (decisions/0058 §21) */
  .xh-vid{background:#000}.xh-vid iframe{width:100%;height:100%;border:0;display:block}
  .xh-own{flex:0 0 auto;margin-left:auto;display:inline-flex;align-items:center;gap:.35rem;border-radius:999px;border:1px solid rgba(255,251,242,.5);background:rgba(255,251,242,.12);-webkit-backdrop-filter:blur(6px);color:#FFFBF2;font:inherit;font-size:.78rem;font-weight:700;padding:.35rem .7rem;cursor:pointer;backdrop-filter:blur(2px)}
  .xh-own .ta-svg{width:15px;height:15px;color:#FFFBF2}.xh-own:hover{background:rgba(255,251,242,.24)}
  .xh-head.xh-haslink{padding-right:3.4rem}.xh-title{flex:0 1 auto}
  .xh-title span{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
  /* the foot of the hero: the page's actions over the photo, on a dark band */
  /* the page's buttons: the bottom-right corner; the credit keeps the left (decisions/0058 §28) */
  .xh-acts{position:absolute;left:auto;right:0;bottom:0;z-index:2;max-width:58%;display:flex;flex-wrap:wrap-reverse;justify-content:flex-end;align-items:center;gap:.3rem;padding:0 .75rem .65rem}
  .xh-acts .eg-bar{margin:0;justify-content:flex-end}.xh-acts .eg-bar .eg-n{color:#FFFBF2;text-shadow:0 1px 4px rgba(0,0,0,.8);padding:0 .25rem}.xh-acts .eg-bar .eg-n svg{color:#F3DDB0}
  .xh-acts .eg-b,.xh-acts [data-contact-save] button,.xh-acts .xh-a{border-color:rgba(255,251,242,.5);background:rgba(255,251,242,.12);color:#FFFBF2;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);text-shadow:0 1px 3px rgba(0,0,0,.6)}
  .xh-acts .eg-b svg{color:#F3DDB0}.xh-acts .eg-b[aria-pressed="true"]{background:#8FBCA8;color:#1F3B30}
  .xh-acts .tv-save{border-color:rgba(255,251,242,.5) !important;background:rgba(255,251,242,.12) !important;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);color:#FFFBF2 !important;font-size:.8rem !important;padding:.28rem .7rem !important;border-radius:999px !important}.xh-acts .tv-save svg{color:#F3DDB0 !important}
  .xh-acts .tv-save span{display:none}.xh-acts .tv-save::after{content:"Save"}.xh-acts .tv-save.on::after{content:"Saved"}   /* short on the hero; its title says it's private */
  .xh-a{display:inline-flex;align-items:center;gap:.3rem;border:1px solid;border-radius:999px;padding:.28rem .75rem;font-size:.8rem;font-weight:700;text-decoration:none;line-height:1.2}
  .xh-a.go{background:rgba(184,134,59,.28) !important;border-color:#E2B66B !important;color:#FFF3D6 !important}
  .xh:has(.xh-acts) .xh-cap{bottom:.85rem}
  .xh:not(:has(.xh-cap)) .xh-acts{max-width:none;flex-wrap:nowrap}   /* no credit card: the buttons get the whole row */
  .xh-acts .eg-b{min-height:32px;padding:.28rem .65rem;gap:.35rem}.xh-acts .eg-b span{font-weight:700;color:#FFFBF2;font-variant-numeric:tabular-nums}
  .xh-acts .eg-b svg{width:16px;height:16px}
  /* a phone: one row. Counts keep their numbers; Share and Photos & video become icons (their titles say what they are) */
  @media (max-width:640px){.xh-acts{gap:.25rem;padding:0 .6rem .55rem}.xh-acts .eg-bar{flex-wrap:wrap-reverse;justify-content:flex-end}
    .xh-acts .eg-bar{flex-wrap:nowrap;gap:.3rem}
    .xh-acts .tv-save::after{content:none !important}.xh-acts .tv-save{width:32px;height:32px;padding:0 !important;justify-content:center}   /* Save: an icon on a phone */
    .xh-acts [data-eg-share] span,.xh-own span{display:none}.xh-acts [data-eg-share],.xh-own{width:32px;height:32px;padding:0;justify-content:center}
    .xh-acts .eg-b.r{display:none}}
  /* the carousel under the hero: whole cards snap into place; two on a phone, three or four on wider screens */
  .xh-car{position:relative;margin:0 0 1.1rem}
  .xh-ct{display:flex;gap:.7rem;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;padding:2px 0 6px}.xh-ct::-webkit-scrollbar{display:none}
  .xh-ct>*{flex:0 0 calc((100% - 2.1rem) / 4);scroll-snap-align:start;min-width:0}
  .xh-ct .xc-art{aspect-ratio:4/3}.xh-ct .xc-art b{font-size:1.1rem}
  .xh-ct .xc-text{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
  .xh-cn{position:absolute;top:35%;width:34px;height:34px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;font-size:1.3rem;line-height:1;cursor:pointer;box-shadow:0 6px 14px -8px rgba(0,0,0,.5);z-index:2}
  .xh-cn.l{left:-10px}.xh-cn.r{right:-10px}.xh-cn:hover{border-color:#B8863B}
  @media (max-width:1100px){.xh-ct>*{flex-basis:calc((100% - 1.4rem) / 3)}}
  /* phones: edge to edge, right under the tool bar (decisions/0058 §11) */
  @media (max-width:767px){.ta-body:has(.xh),.tv-main:has(> .xh),body:not(.tv-back):has(#ta-rail) .ta-body:has(.xh){margin-top:0}   /* the rail's 1.1rem (app-shell) outranked the plain rule: a 23px band above the hero (2026-11-10, layout probe) */
    .tv-page > .xh{margin-top:-.8rem !important}
    .xh{margin:-.8rem calc(-1 * var(--tv-pad, .85rem)) 0;border-radius:0}.xh.xh-solo{border-radius:0;margin-bottom:.8rem}
    .xh-tabs{margin:0 calc(-1 * var(--tv-pad, .85rem)) .8rem;border-radius:0;border-left:0;border-right:0}
    .xh-car{margin:0 calc(3px - var(--tv-pad, .85rem)) .8rem}.xh-ct{gap:3px;padding:0}
    .xh-ct>*{flex-basis:calc((100% - 3px) / 2)}.xh-ct .xc{border-radius:.5rem}.xh-ct .xc-art{aspect-ratio:4/5;padding:.6rem .65rem}.xh-ct .xc-art b{font-size:1rem}
    .xh-ct .xc-body{padding:.5rem .6rem .6rem;gap:.3rem}.xh-ct .xc-text{font-size:.78rem;-webkit-line-clamp:2}.xh-ct .xc-stats{font-size:.72rem;gap:.15rem .5rem}
    .xh-ct .xc-chips{display:none}.xh-ct .xc-ic{width:28px;height:28px;top:.5rem;left:.55rem}.xh-ct .xc-badge{top:.55rem;right:.5rem}
    .xh-cn{display:none}}
  @media (max-width:640px){.xh{aspect-ratio:4/3}.xh-tabs a{font-size:.88rem;flex-direction:column;gap:.2rem}.xh-cap{left:.6rem;bottom:.6rem;max-width:46%}.xh-head{left:.75rem;right:.75rem}.xh-title{font-size:1.25rem}}
  /* wider screens, as on a phone (decisions/0058 §33): flush with the top bar and the toolbar, square corners, and a
     height that fits the screen instead of a wide 21:9 frame */
  @media (min-width:768px){.ta-body:has(.xh),body:not(.tv-back):has(#ta-rail) .ta-body:has(.xh){margin-top:0}
    .ta-work .xh{margin:-1.1rem calc(-1 * clamp(1rem,3vw,2.5rem)) 0;border-radius:0;aspect-ratio:auto;min-height:0;height:clamp(300px,50vh,480px)}
    .ta-work .tv-page > .xh{margin-top:-1.1rem !important}
    .ta-work .xh.xh-solo{border-radius:0;margin-bottom:1rem}
    .ta-work .xh-tabs{margin-left:calc(-1 * clamp(1rem,3vw,2.5rem));margin-right:calc(-1 * clamp(1rem,3vw,2.5rem));border-radius:0;border-left:0;border-right:0}
  }
  /* no photos: a band as tall as its title and the line under it, with the buttons' row below (decisions/0058 §34) */
  .xh.xh-nophoto,.ta-work .xh.xh-nophoto{aspect-ratio:auto;min-height:0;height:auto}
  .xh-nophoto .xh-track{position:absolute;inset:0}
  .xh-nophoto .xh-head{position:relative;left:auto;right:auto;top:auto;padding:.85rem 1rem 3.4rem}
  @media (max-width:640px){.xh-nophoto .xh-head{padding:.75rem .75rem 3.1rem}}
  /* the top-right corner (Claim, Manage); the camera button is an icon like Share */
  .xh-corner{margin-left:auto;align-self:flex-start;display:flex;gap:.3rem}
  .xh-corner .xh-a{border-color:rgba(255,251,242,.5);background:rgba(255,251,242,.12);color:#FFFBF2;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);text-shadow:0 1px 3px rgba(0,0,0,.6)}
  .xh-acts .xh-shr{width:32px;height:32px;padding:0;justify-content:center}.xh-shr .ta-svg{width:16px;height:16px;color:#F3DDB0}
</style>
<style>
  .xh-zoom{cursor:zoom-in}
  .xlb{position:fixed;inset:0;z-index:3000;background:rgba(15,10,6,.9);-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;flex-direction:column;align-items:center;justify-content:center;touch-action:pan-y}
  .xlb img{max-width:100vw;max-height:76vh;max-height:76dvh;object-fit:contain;display:block;user-select:none;-webkit-user-drag:none}
  .xlb-cap{color:#F3DDB0;font-size:.82rem;line-height:1.4;text-align:center;max-width:40rem;padding:.6rem 1rem 0}
  .xlb-n{color:#CBB98D;font-size:.72rem;margin-top:.2rem}
  .xlb button{position:absolute;border:1px solid rgba(255,251,242,.45);background:rgba(255,251,242,.12);color:#FFFBF2;border-radius:999px;cursor:pointer;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}
  .xlb .x{top:max(.8rem,env(safe-area-inset-top));right:.8rem;width:40px;height:40px;font-size:1.5rem;line-height:1}
  .xlb-acts{position:absolute;left:0;right:0;bottom:max(1rem,env(safe-area-inset-bottom));display:flex;justify-content:center;padding:0 .75rem}
  .xlb-acts .eg-bar{margin:0;justify-content:center;flex-wrap:wrap;gap:.35rem}
  .xlb-acts .eg-n{color:#FFFBF2;display:inline-flex;align-items:center;gap:.3rem;font-size:.82rem;font-weight:700;padding:0 .3rem}.xlb-acts .eg-n svg{width:16px;height:16px;color:#F3DDB0}
  .xlb-acts .eg-b{position:static;transform:none;width:auto;height:auto;min-height:34px;font-size:.82rem;border:1px solid rgba(255,251,242,.45);background:rgba(255,251,242,.12);color:#FFFBF2}
  .xlb-acts .eg-b svg{color:#F3DDB0;width:16px;height:16px}.xlb-acts .eg-b[aria-pressed="true"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}.xlb-acts .eg-b[aria-pressed="true"] svg{color:#1F3B30}
  .xlb-acts .eg-b.r{display:inline-flex}
  .xlb .p,.xlb .n{top:50%;transform:translateY(-50%);width:40px;height:56px;font-size:1.8rem}.xlb .p{left:.5rem}.xlb .n{right:.5rem}
</style>
<script>
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-xh]'); if (!b) return;
    var tr = document.getElementById(b.getAttribute('data-xh')); if (tr) tr.scrollBy({ left: tr.clientWidth * +b.getAttribute('data-d'), behavior: 'smooth' });
  });
  // the lightbox: a tap on a hero photo opens it full screen; arrows, swipe and the keys move between the hero's photos (decisions/0058 §28)
  (function () {
    if (window.tvLightbox) return; window.tvLightbox = true;
    var box = null, list = [], at = 0, back = null, x0 = null;
    function show() {
      var it = list[at]; box.querySelector('img').src = it.src; box.querySelector('img').alt = it.cap || 'Photo';
      box.querySelector('.xlb-cap').textContent = it.cap || '';
      box.querySelector('.xlb-n').textContent = list.length > 1 ? (at + 1) + ' of ' + list.length : '';
    }
    function step(d) { if (list.length > 1) { at = (at + d + list.length) % list.length; show(); } }
    var src = null;   // the hero's own bar, kept in step with the lightbox's copy (a like made here shows there)
    function close() {
      if (!box) return;
      var copy = box.querySelector('.xlb-acts .eg-bar');
      if (copy && src) { var a = copy.querySelector('[data-eg-like]'), b = src.querySelector('[data-eg-like]'); if (a && b) b.outerHTML = a.outerHTML; }
      box.remove(); box = null; src = null; document.documentElement.style.overflow = ''; if (back) back.focus();
    }
    function open(slide) {
      var track = slide.parentNode;
      list = Array.prototype.map.call(track.querySelectorAll('[data-lb]'), function (s) { return { src: s.getAttribute('data-lb'), cap: s.getAttribute('data-lb-cap') || (s.querySelector('.xh-cap') ? s.querySelector('.xh-cap').textContent : '') }; });
      at = Math.max(0, Array.prototype.indexOf.call(track.querySelectorAll('[data-lb]'), slide)); back = slide;
      box = document.createElement('div'); box.className = 'xlb'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'Photo');
      box.innerHTML = '<img alt=""><p class="xlb-cap"></p><p class="xlb-n"></p><button type="button" class="x" aria-label="Close">&times;</button>'
        + (list.length > 1 ? '<button type="button" class="p" aria-label="Previous photo">&lsaquo;</button><button type="button" class="n" aria-label="Next photo">&rsaquo;</button>' : '');
      // the page's social buttons come along: views, likes, comments, Share (js/engage.js handles them by their bar's data)
      var bar = slide.closest('.xh') && slide.closest('.xh').querySelector('.xh-acts .eg-bar');
      if (bar) { var acts = document.createElement('div'); acts.className = 'xlb-acts'; acts.appendChild(bar.cloneNode(true)); box.appendChild(acts); src = bar; }
      document.body.appendChild(box); document.documentElement.style.overflow = 'hidden'; show(); box.querySelector('.x').focus();
      box.addEventListener('click', function (ev) {
        if (ev.target.closest('.xlb-acts')) {   // Comments: close and go to them; the rest work in place
          if (ev.target.closest('a[href="#comments"]')) close();
          return;
        }
        if (ev.target.closest('.p')) return step(-1);
        if (ev.target.closest('.n')) return step(1);
        if (ev.target.closest('.x') || !ev.target.closest('img')) close();
      });
      box.addEventListener('touchstart', function (ev) { x0 = ev.touches[0].clientX; }, { passive: true });
      box.addEventListener('touchend', function (ev) { if (x0 === null) return; var dx = ev.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) > 40) step(dx < 0 ? 1 : -1); });
    }
    document.addEventListener('click', function (e) {
      var s = e.target.closest('[data-lb]'); if (!s || e.target.closest('a, button')) return;
      e.preventDefault(); open(s);
    });
    document.addEventListener('keydown', function (e) {
      if (!box) { var s = e.target.closest && e.target.closest('[data-lb]'); if (s && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); open(s); } return; }
      if (e.key === 'Escape') close(); else if (e.key === 'ArrowLeft') step(-1); else if (e.key === 'ArrowRight') step(1);
    });
  })();
</script>
CSS;
}
