<?php
// app/ui/lead-panel.php — the Single Lead Workspace (decisions/0108): one lead beside the list (full screen on a
// phone), opened from its name in any Sales list or by /admin/sales.php?lead=N#all (the link to send a teammate).
// Its score and why, stage, owner and territory, contact log, claim link, business cards and history. Also the
// Territories tab (Directors set them up). Uses /admin/api/sales.php.
declare(strict_types=1);

require_once __DIR__ . '/../lib/Leads.php';

function tv_lead_territories(): string
{
    ob_start(); ?>
<div class="hb-card tv-bleed" id="tr-box">
  <p class="text-sm text-[#5C4632]">A territory is a state, a Geo-Hub Zone or a cluster with its rep. New leads, inbound claims and listings worth a call there go to that rep; a cluster's territory beats its zone's, and a zone's beats its state's. Leads with no rep wait in the shared queue (Whose: Shared queue).</p>
  <div id="tr-list"><p class="text-sm">Loading…</p></div>
  <div id="tr-form" hidden></div>
</div>
<?php
    return (string) ob_get_clean();
}

function tv_lead_panel(): string
{
    ob_start(); ?>
<style>
  .ld{position:fixed;top:0;right:0;bottom:0;width:min(34rem,100%);z-index:1800;background:#FFFBF2;border-left:1px solid #CBB98D;box-shadow:-18px 0 40px -20px rgba(0,0,0,.45);display:flex;flex-direction:column}
  .ld[hidden]{display:none}
  .ld-bar{display:flex;align-items:center;gap:.5rem;padding:.6rem .8rem;background:#3E2B1F;color:#FFF8EA}.ld-bar b{flex:1;font:700 1.05rem var(--tv-font-head,Georgia,serif);min-width:0}
  .ld-x{width:34px;height:34px;border-radius:999px;border:1px solid rgba(255,248,234,.45);background:transparent;color:#FFF8EA;font-size:1.3rem;cursor:pointer}
  .ld-body{flex:1;overflow-y:auto;padding:.8rem 1rem 2rem}
  .ld-body h4{margin:1rem 0 .35rem;font:700 .78rem system-ui,sans-serif;letter-spacing:.07em;text-transform:uppercase;color:#8A7355}
  .ld-top{display:flex;gap:.7rem;align-items:flex-start}
  .ld-score{flex:none;width:58px;height:58px;border-radius:999px;display:flex;flex-direction:column;align-items:center;justify-content:center;font:700 1.3rem system-ui,sans-serif;background:#EADFC4;color:#3E2B1F}
  .ld-score small{font-size:.6rem;font-weight:600;letter-spacing:.05em}.ld-score.hi{background:#DCEFE5;color:#1F5C43}.ld-score.mid{background:#FDE68A;color:#78350F}
  .ld-ct{display:flex;flex-wrap:wrap;gap:.2rem .8rem;font-size:.92rem;margin-top:.3rem}.ld-ct a{color:#92400E;text-decoration:underline}
  .ld-why{margin:0;padding-left:1.1rem;font-size:.9rem;color:#3E2B1F}.ld-why li{margin:.15rem 0}
  .ld-row{display:grid;grid-template-columns:1fr 1fr;gap:.5rem}.ld-row label{display:grid;gap:.15rem;font-size:.82rem;font-weight:700;color:#5C4632;min-width:0}
  .ld-row .hb-in{width:100%;box-sizing:border-box;padding:.4rem .5rem;font-weight:400}
  .ld-hist p{margin:.25rem 0;font-size:.88rem;padding-top:.25rem;border-top:1px solid #EADFC4}
  .ld-cards{display:flex;gap:.4rem;flex-wrap:wrap}.ld-cards img{width:110px;height:68px;object-fit:cover;border-radius:.35rem;border:1px solid #CBB98D}
  .ld-acts{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;margin-top:.4rem}
  .sl-sc{display:inline-block;min-width:1.9rem;text-align:center;font:700 .72rem system-ui,sans-serif;border-radius:999px;padding:.08rem .35rem;background:#EADFC4;color:#3E2B1F;margin-left:.35rem;vertical-align:middle}
  .sl-sc.hi{background:#DCEFE5;color:#1F5C43}.sl-sc.mid{background:#FDE68A;color:#78350F}
  .tr-row{display:flex;justify-content:space-between;gap:.6rem;align-items:center;padding:.55rem 0;border-top:1px solid #EADFC4}.tr-row:first-child{border-top:0}
  .tr-row b{color:#3E2B1F}.tr-row small{display:block;color:#8A7355}
  @media (max-width:520px){.ld-row{grid-template-columns:1fr}}
</style>
<aside class="ld" id="ld" hidden role="dialog" aria-label="The lead">
  <div class="ld-bar"><b id="ld-title">Lead</b><button type="button" class="ld-x" id="ld-close" aria-label="Close" title="Close">×</button></div>
  <div class="ld-body" id="ld-body"></div>
</aside>
<?php require_once __DIR__ . '/../lib/Sales.php'; ?>
<script>var OUTL = <?= json_encode(array_map(fn ($o) => $o[2], Sales::OUTCOMES), JSON_UNESCAPED_UNICODE) ?>;</script>
<script>
(function () {
  var csrf = null, cur = null, D = null;
  var P = document.getElementById('ld'), B = document.getElementById('ld-body');
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function tok() { return csrf ? Promise.resolve(csrf) : fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrf = d.csrf_token || ''); }); }
  function api(q, body) {
    var p = body ? tok().then(function (c) { return fetch('/admin/api/sales.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); })
      : fetch('/admin/api/sales.php?' + q, { credentials: 'include' });
    return p.then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work.'); return j; });
  }
  function fmt(d) { if (!d) return ''; var t = new Date(String(d).replace(' ', 'T')); return isNaN(t) ? d : t.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }); }
  function band(s) { return s == null ? '' : (s >= 60 ? 'hi' : (s >= 35 ? 'mid' : '')); }
  window.slScore = function (p) { return p.score == null ? '' : '<span class="sl-sc ' + band(p.score) + '" title="' + esc('Lead score ' + p.score + ': ' + (p.why || []).join('; ')) + '">' + p.score + '</span>'; };

  function open(id) {
    cur = id; P.hidden = false; B.innerHTML = '<p class="text-sm">Loading…</p>';
    if (history.replaceState) { var u = new URL(location.href); u.searchParams.set('lead', id); history.replaceState(null, '', u); }
    api('lead=' + id).then(function (j) { D = j; show(); }).catch(function (x) { B.innerHTML = '<p>' + esc(x.message) + '</p>'; });
  }
  function close() { P.hidden = true; cur = null; if (history.replaceState) { var u = new URL(location.href); u.searchParams.delete('lead'); history.replaceState(null, '', u); } }
  document.getElementById('ld-close').addEventListener('click', close);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && cur && !document.querySelector('.tv-ask-box')) close(); });
  document.addEventListener('click', function (e) { var a = e.target.closest('[data-lead]'); if (!a || e.ctrlKey || e.metaKey) return; e.preventDefault(); open(+a.getAttribute('data-lead')); });

  function show() {
    var p = D.item, s = D.score;
    document.getElementById('ld-title').textContent = p.name;
    var ct = [p.phone ? '<a href="tel:' + esc(p.phone.replace(/[^\d+]/g, '')) + '" data-out="call" data-e="' + p.id + '">' + esc(p.phone) + '</a>' : 'No phone',
      p.email ? '<a href="mailto:' + esc(p.email) + '">' + esc(p.email) + '</a>' : '', p.website ? '<a href="' + esc(p.website) + '" target="_blank" rel="noopener">Website</a>' : ''].filter(Boolean).join('');
    var stOpts = Object.keys(D.stages).map(function (k) { return '<option value="' + k + '"' + (k === p.lead_stage ? ' selected' : '') + '>' + esc(D.stages[k]) + '</option>'; }).join('');
    var reps = '<option value="0">The shared queue</option>' + D.reps.map(function (r) { return '<option value="' + r.id + '"' + (+r.id === D.owner_id ? ' selected' : '') + '>' + esc(r.name) + '</option>'; }).join('');
    var ownerName = (D.reps.filter(function (r) { return +r.id === D.owner_id; })[0] || {}).name || (D.owner_id ? p.owner : 'The shared queue');
    var milestone = { claimed: 'Claimed by the owner', verified: 'Claimed and verified', paid: 'Paying' }[p.stage];
    B.innerHTML = '<div class="ld-top"><div class="ld-score ' + band(s) + '" title="Lead score, 0 to 100">' + (s == null ? '–' : s) + '<small>SCORE</small></div><div>'
      + '<div><a href="/listing/view.php?id=' + p.id + '" data-peek-frame style="color:#92400E;text-decoration:underline;font-weight:700">' + esc(p.name) + '</a></div>'
      + '<div class="text-sm" style="color:#8A7355">' + esc([p.category, p.city, p.address].filter(Boolean).join(' · ')) + '</div><div class="ld-ct">' + ct + '</div>'
      + (milestone ? '<div class="text-sm" style="margin-top:.3rem"><span class="sl-pill claimed">' + milestone + '</span></div>' : '')
      + (D.claim ? '<div class="text-sm" style="color:#5C4632;margin-top:.2rem">Claim ' + esc(D.claim.status) + (D.claim.by ? ' by ' + esc(D.claim.by) : '') + ', ' + fmt(D.claim.at) + '</div>' : '') + '</div></div>'
      + '<h4>Why this score</h4><ul class="ld-why">' + (D.why.length ? D.why.map(function (w) { return '<li>' + esc(w) + '</li>'; }).join('') : '<li>Not scored yet.</li>') + '</ul>'
      + '<h4>Stage and owner</h4><div class="ld-row"><label>Stage<select class="hb-in" data-ld="stage">' + stOpts + '</select></label>'
      + (D.can_manage ? '<label>Whose lead<select class="hb-in" data-ld="owner">' + reps + '</select></label>' : '<label>Whose lead<input class="hb-in" value="' + esc(ownerName) + '" readonly></label>') + '</div>'
      + '<p class="text-sm" style="color:#8A7355;margin:.3rem 0 0">Territory: ' + (D.territory ? esc(D.territory.name) : 'none (shared queue)') + (D.source ? ' · came in by ' + esc({ crawler: 'the crawler', field: 'a visit', staff: 'our team', inbound: 'the owner claiming it', card: 'a business card' }[D.source] || D.source) : '') + (p.next_at ? ' · follow up ' + fmt(p.next_at) : '') + '</p>'
      + '<h4>Log a contact</h4><p class="text-sm" style="color:#8A7355;margin:0 0 .3rem">Anyone at the business answering confirms its name and phone (a visit, its address too): it goes on the listing as our team\'s check.</p>'
      + '<div class="ld-acts" aria-label="The listing">' + ['confirmed', 'wrong_number', 'closed', 'moved'].map(function (k) { return '<button type="button" class="sl-out" data-o="' + k + '">' + esc(OUTL[k] || k) + '</button>'; }).join('') + '</div>'
      + '<div class="ld-acts" aria-label="The conversation">' + ['no_answer', 'left_message', 'met', 'interested', 'meeting', 'invited', 'quote', 'not_now', 'no'].map(function (k) { return '<button type="button" class="sl-out" data-o="' + k + '">' + esc(OUTL[k] || k) + '</button>'; }).join('') + '</div>'
      + '<div class="ld-row" style="margin-top:.4rem"><label>Who you spoke with<input class="hb-in" data-ld="cn" value="' + esc(p.contact_name) + '"></label><label>Follow up on<input class="hb-in" type="date" data-ld="nx"></label></div>'
      + '<textarea class="hb-in" rows="2" data-ld="nt" placeholder="What they said (optional)" style="width:100%;box-sizing:border-box;margin-top:.4rem"></textarea>'
      + '<div class="ld-acts"><button type="button" class="hb-b go" data-ld-do="log">Save the contact</button><span class="text-sm" data-ld-msg></span></div>'
      + '<h4>Claim link</h4><div class="ld-acts"><button type="button" class="hb-b" data-ld-do="copy">Copy the claim link</button>' + (p.email ? '<button type="button" class="hb-b" data-ld-do="invite">Email the claim invite</button>' : '') + '</div>'
      + '<h4>Quotes</h4><p class="text-sm" style="color:#8A7355;margin:0">Quotes come with the next step: build one here, send it, and Won opens billing and onboarding.</p>'
      + (D.cards.length ? '<h4>Business cards</h4><div class="ld-cards">' + D.cards.map(function (c) { return '<a href="/admin/api/cards.php?img=' + c.id + '&side=1" target="_blank" rel="noopener" title="' + esc(c.at + (c.by ? ' · ' + c.by : '')) + '"><img src="/admin/api/cards.php?img=' + c.id + '&side=1" alt="Business card"></a>'; }).join('') + '</div>' : '')
      + '<h4>History</h4><div class="ld-hist">' + (D.history.length ? D.history.map(function (h) { return '<p>' + esc(h.at) + ' · ' + esc(h.kind) + (h.outcome ? ': ' + esc(h.outcome) : '') + (h.note ? ' · ' + esc(h.note) : '') + (h.by ? ' · ' + esc(h.by) : '') + '</p>'; }).join('') : '<p>Nothing yet.</p>') + '</div>'
      + (p.notes ? '<h4>Notes</h4><p class="text-sm" style="white-space:pre-line;margin:0">' + esc(p.notes) + '</p>' : '')
      + '<div class="ld-acts" style="margin-top:1rem"><button type="button" class="hb-b" data-ld-do="link">Copy a link to this lead</button><a class="hb-b" href="/admin/listing-edit.php?id=' + p.id + '" data-peek-frame>Edit the listing</a></div>';
  }
  function after(item, msg) { if (window.slRefreshRow) window.slRefreshRow(item); TvAsk.say(msg); open(cur); }
  B.addEventListener('change', function (e) {
    var t = e.target.getAttribute('data-ld');
    if (t === 'stage') api('', { do: 'stage', id: cur, stage: e.target.value }).then(function (j) { after(j.item, 'Stage: ' + D.stages[e.target.value] + '.'); }).catch(function (x) { TvAsk.say(x.message); });
    if (t === 'owner') api('', { do: 'owner', id: cur, to: +e.target.value }).then(function (j) { after(j.item, 'Lead moved.'); }).catch(function (x) { TvAsk.say(x.message); });
  });
  B.addEventListener('click', function (e) {
    var o = e.target.closest('.sl-out'); if (o) { B.querySelectorAll('.sl-out').forEach(function (b) { b.classList.toggle('on', b === o); }); return; }
    var a = e.target.closest('[data-ld-do]'); if (!a) return; var w = a.getAttribute('data-ld-do'), p = D.item;
    if (w === 'log') {
      var on = B.querySelector('.sl-out.on'), m = B.querySelector('[data-ld-msg]'); if (!on) { m.textContent = 'Choose what happened.'; return; }
      api('', { do: 'log', id: cur, kind: 'call', outcome: on.getAttribute('data-o'), note: B.querySelector('[data-ld=nt]').value, next_at: B.querySelector('[data-ld=nx]').value, contact_name: B.querySelector('[data-ld=cn]').value })
        .then(function (j) { after(j.item, 'Saved' + (j.item.next_at ? ': follow up ' + fmt(j.item.next_at) : '') + '.'); }).catch(function (x) { m.textContent = x.message; });
    }
    var copy = function (t, said) { (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { TvAsk.say(said); }, function () { TvAsk.ask('Copy it', t); }); };
    if (w === 'copy') copy(p.claim_link, 'Claim link copied.');
    if (w === 'link') copy(location.origin + D.full, 'Link to this lead copied.');
    if (w === 'invite') { if (!TvAsk.gate(a, 'Email the claim link to ' + p.email + '?', { yes: 'Send it' })) return;
      api('', { do: 'invite', id: cur }).then(function (j) { after(j.item, 'Claim invite emailed.'); }).catch(function (x) { TvAsk.say(x.message); }); }
  });
  var m0 = /[?&]lead=(\d+)/.exec(location.search); if (m0) open(+m0[1]);

  // ---- Territories ----
  var TB = document.getElementById('tr-list'), TF = document.getElementById('tr-form'), T = null;
  function trLoad() { if (!TB) return; api('territories=1').then(function (j) { T = j; trList(); }).catch(function (x) { TB.innerHTML = '<p class="text-sm">' + esc(x.message) + '</p>'; }); }
  function trList() {
    TB.innerHTML = (T.items.length ? T.items.map(function (t) { return '<div class="tr-row"><span><b>' + esc(t.name) + '</b><small>' + esc(T.kinds[t.kind] + ': ' + t.area) + ' · ' + (t.rep ? 'rep ' + esc(t.rep) : 'no rep: shared queue') + (t.manager ? ' · manager ' + esc(t.manager) : '') + ' · ' + t.leads + ' leads' + (+t.active ? '' : ' · off') + '</small></span>'
      + (T.can_set_up ? '<span class="ld-acts" style="margin:0"><button type="button" class="hb-b" data-tr-edit="' + t.id + '">Edit</button><button type="button" class="hb-b" data-tr-del="' + t.id + '">Remove</button></span>' : '') + '</div>'; }).join('') : '<p class="text-sm">No territories yet: every lead is in the shared queue.</p>')
      + (T.can_set_up ? '<p style="margin-top:.6rem"><button type="button" class="hb-b go" data-tr-edit="0">+ Add a territory</button></p>' : '<p class="text-sm" style="color:#8A7355">A Director, an Executive or the Founder sets up territories.</p>');
  }
  function trForm(id) {
    var t = T.items.filter(function (x) { return +x.id === id; })[0] || { kind: 'zone', ref: '', name: '', rep_id: 0, manager_id: 0, active: 1 };
    var ppl = function (sel) { return '<option value="0">None</option>' + T.reps.map(function (r) { return '<option value="' + r.id + '"' + (+r.id === +sel ? ' selected' : '') + '>' + esc(r.name) + '</option>'; }).join(''); };
    var refs = function (k) { return (T.areas[k] || []).map(function (a) { return '<option value="' + esc(a[0]) + '"' + (String(a[0]) === String(t.ref) ? ' selected' : '') + '>' + esc(a[1]) + '</option>'; }).join(''); };
    TF.hidden = false;
    TF.innerHTML = '<div class="sl-panel"><b>' + (id ? 'Edit the territory' : 'A new territory') + '</b><div class="ld-row" style="margin-top:.5rem">'
      + '<label>Covers<select class="hb-in" name="kind">' + Object.keys(T.kinds).map(function (k) { return '<option value="' + k + '"' + (k === t.kind ? ' selected' : '') + '>' + esc(T.kinds[k]) + '</option>'; }).join('') + '</select></label>'
      + '<label>Which<select class="hb-in" name="ref">' + refs(t.kind) + '</select></label>'
      + '<label>Name (optional)<input class="hb-in" name="name" value="' + esc(t.name) + '" placeholder="Its area\'s name"></label>'
      + '<label>Rep (gets its leads)<select class="hb-in" name="rep_id">' + ppl(t.rep_id) + '</select></label>'
      + '<label>Manager<select class="hb-in" name="manager_id">' + ppl(t.manager_id) + '</select></label>'
      + (id ? '<label>On<select class="hb-in" name="off"><option value="">On</option><option value="1"' + (+t.active ? '' : ' selected') + '>Off</option></select></label>' : '') + '</div>'
      + '<div class="ld-acts"><button type="button" class="hb-b go" data-tr-save="' + id + '">Save</button><button type="button" class="hb-b" data-tr-close>Close</button><span class="text-sm" data-tr-msg></span></div>'
      + '<p class="text-xs" style="color:#8A7355;margin:.4rem 0 0">Saving gives its unowned leads to the rep now; new ones follow on their own.</p></div>';
    TF.querySelector('[name=kind]').addEventListener('change', function () { t.ref = ''; TF.querySelector('[name=ref]').innerHTML = refs(this.value); });
  }
  if (TB) {
    document.addEventListener('tv-hub-show', function (e) { if (e.detail === 'territories' && !T) trLoad(); });
    if ((location.hash.slice(1) || new URLSearchParams(location.search).get('sec')) === 'territories') trLoad();
    document.getElementById('tr-box').addEventListener('click', function (e) {
      var ed = e.target.closest('[data-tr-edit]'); if (ed) { trForm(+ed.getAttribute('data-tr-edit')); return; }
      if (e.target.closest('[data-tr-close]')) { TF.hidden = true; return; }
      var dl = e.target.closest('[data-tr-del]'); if (dl) { if (!TvAsk.gate(dl, 'Remove this territory? Its leads keep their rep.', { yes: 'Remove', danger: true })) return;
        api('', { do: 'territory_delete', id: +dl.getAttribute('data-tr-del') }).then(function (j) { T.items = j.items; trList(); }).catch(function (x) { TvAsk.say(x.message); }); return; }
      var sv = e.target.closest('[data-tr-save]'); if (sv) { var v = { do: 'territory', id: +sv.getAttribute('data-tr-save') };
        TF.querySelectorAll('[name]').forEach(function (i) { v[i.name] = i.value; });
        api('', v).then(function (j) { T.items = j.items; trList(); TF.hidden = true; TvAsk.say('Territory saved.'); }).catch(function (x) { TF.querySelector('[data-tr-msg]').textContent = x.message; }); }
    });
  }
})();
</script>
<?php
    return (string) ob_get_clean();
}
