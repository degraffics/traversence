<?php
/**
 * includes/collections.php — lists that consolidate instead of repeating (decisions/0055 §3).
 *
 * tv_outdoor_collections(): public recreation places grouped so four "Luna Lake …" entries read as one place with
 * four parts, and the rest sit under what they are (Lakes & water, Trails, Campgrounds, Day use & picnic, Scenic
 * overlooks, Wilderness & forests, Visitor centers). Each collection opens and closes, with a count.
 *
 * Each item: ['name', 'kind' (e.g. "Campground"), 'org', 'miles' (float|null), 'url'].
 */
require_once __DIR__ . '/page-shell.php';

const TV_OUTDOOR_KINDS = [
    'Lakes & water'        => '/\b(lakes?|reservoirs?|rivers?|creeks?|boat|boating|marina|fishing|swim\w*|ponds?)\b/i',
    'Trails & trailheads'  => '/\b(trails?|trailheads?|hiking|hikes?|biking|horse)\b/i',
    'Campgrounds'          => '/\b(camp\w*|rv|cabins?)\b/i',
    'Day use & picnic'     => '/\b(day use|picnic\w*)\b/i',
    'Scenic & overlooks'   => '/\b(scenic|overlooks?|vista|viewpoint|observation|point of)\b/i',
    'Wilderness & forests' => '/\b(wilderness|national forests?|study area|recreation areas?|forests?|monuments?)\b/i',
    'Visitor centers'      => '/\b(visitor|ranger|information|station|center)\b/i',
];

/** One of each kind, for "Missing a lake? Tell us". */
const TV_OUTDOOR_ONE = ['Lakes & water' => 'a lake or river', 'Trails & trailheads' => 'a trail', 'Campgrounds' => 'a campground', 'Day use & picnic' => 'a picnic or day-use area',
                        'Scenic & overlooks' => 'a scenic spot', 'Wilderness & forests' => 'a forest or wilderness area', 'Visitor centers' => 'a visitor center'];

/** What kind of outdoors place it is, from its name and type. */
function tv_outdoor_kind(array $it): string
{
    // most specific first: "Big Lake Campground" is a campground; "…Scenic Overlook" (type Picnicking) is scenic
    foreach (['Campgrounds', 'Trails & trailheads', 'Scenic & overlooks', 'Visitor centers', 'Day use & picnic', 'Lakes & water', 'Wilderness & forests'] as $k) {
        if (preg_match(TV_OUTDOOR_KINDS[$k], (string) $it['name'])) return $k;
    }
    foreach (TV_OUTDOOR_KINDS as $k => $re) if (preg_match($re, (string) ($it['kind'] ?? ''))) return $k;   // then by its type
    return 'Other public places';
}

/** The words a family of places shares ("Luna Lake Campground", "Luna Lake Day Use" -> "Luna Lake"). */
function tv_outdoor_stem(string $name): string
{
    $w = preg_split('/\s+/', trim(preg_replace('/[^\p{L}\p{N}\' ]+/u', ' ', $name)));
    return mb_strtolower(implode(' ', array_slice($w, 0, 2)));
}

/** @return array{families: list<array>, kinds: array<string, list<array>>} */
function tv_outdoor_group(array $items): array
{
    $byStem = [];
    foreach ($items as $it) $byStem[tv_outdoor_stem((string) $it['name'])][] = $it;
    $families = []; $kinds = [];
    foreach ($byStem as $stem => $list) {
        if (count($list) >= 2 && mb_strlen($stem) >= 4) {
            // the family's name: the shared words as the agency wrote them
            $first = preg_split('/\s+/', trim((string) $list[0]['name']));
            $families[] = ['name' => implode(' ', array_slice($first, 0, 2)), 'items' => $list,
                           'miles' => min(array_map(fn ($x) => $x['miles'] ?? INF, $list))];
        } else {
            foreach ($list as $it) $kinds[tv_outdoor_kind($it)][] = $it;
        }
    }
    usort($families, fn ($a, $b) => $a['miles'] <=> $b['miles']);
    $order = array_keys(TV_OUTDOOR_KINDS);
    uksort($kinds, fn ($a, $b) => (array_search($a, $order, true) === false ? 99 : array_search($a, $order, true)) <=> (array_search($b, $order, true) === false ? 99 : array_search($b, $order, true)));
    return ['families' => $families, 'kinds' => $kinds];
}

function tv_outdoor_collections(array $items, array $opt = []): string
{
    if (!$items) return '';
    $g = tv_outdoor_group($items);
    $mi = fn ($m) => $m === null || $m === INF ? '' : ($m < 1 ? '<1 mi' : round($m) . ' mi');
    $row = function (array $it, bool $short = false) use ($mi): string {
        $name = (string) $it['name'];
        if ($short && !empty($it['_stem'])) {   // inside a family, show what this part is
            $rest = trim(mb_substr($name, mb_strlen($it['_stem'])));
            if ($rest !== '') $name = $rest;
        }
        return '<li class="tvo-it"><a href="' . tv_e($it['url']) . '">' . tv_e($name) . '</a><span>'
            . tv_e(implode(' · ', array_filter([$short ? '' : ($it['kind'] ?? ''), $it['org'] ?? '', $mi($it['miles'] ?? null)]))) . '</span></li>';
    };
    $open = (int) ($opt['open'] ?? 1);   // how many collections start open
    $h = '<div class="tvo">';
    $n = 0;
    foreach ($g['families'] as $f) {
        $parts = array_map(fn ($x) => $x + ['_stem' => $f['name']], $f['items']);
        $h .= '<details class="tvo-c tvo-fam"' . ($n++ < $open ? ' open' : '') . '><summary><b>' . tv_e($f['name']) . '</b> <small>' . count($f['items']) . ' places'
            . ($mi($f['miles']) !== '' ? ' · ' . $mi($f['miles']) : '') . '</small></summary><ul>' . implode('', array_map(fn ($x) => $row($x, true), $parts)) . tv_suggest_link($opt['suggest'] ?? [], $f['name'], 'Missing a part of ' . $f['name'] . '? Tell us') . '</ul></details>';
    }
    foreach ($g['kinds'] as $k => $list) {
        $h .= '<details class="tvo-c"' . ($n++ < $open ? ' open' : '') . '><summary><b>' . tv_e($k) . '</b> <small>' . count($list) . '</small></summary><ul>'
            . implode('', array_map(fn ($x) => $row($x), $list)) . tv_suggest_link($opt['suggest'] ?? [], (string) $k, 'Missing ' . (TV_OUTDOOR_ONE[$k] ?? 'something from ' . $k) . '? Tell us') . '</ul></details>';
    }
    return $h . (!empty($opt['suggest']) ? '<p class="tvo-more"><button type="button" data-tv-suggest="' . tv_e(json_encode($opt['suggest'] + ['kind' => 'missing'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '">Know a place that isn\'t here? Tell us</button></p>' : '') . '</div>';
}

/**
 * "Missing something?" at the foot of a collection (js/suggest.js). $base: what the whole list is about
 * (topic, place_name, place_key); the collection's title becomes the section ("Lakes").
 */
function tv_suggest_link(array $base, string $section = '', string $label = 'Missing something? Tell us'): string
{
    if (!$base) return '';
    $o = $base + ($section !== '' ? ['section' => $section] : []) + ['kind' => 'missing'];
    return '<li class="tvo-sg"><button type="button" data-tv-suggest="' . tv_e(json_encode($o, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '">' . tv_e($label) . '</button></li>';
}

/** The styles for the collections above (print once per page). */
function tv_collections_css(): string
{
    return '<style>
  .tvo{display:grid;gap:.5rem}
  .tvo-c{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.9rem;overflow:hidden}
  .tvo-c>summary{cursor:pointer;list-style:none;display:flex;align-items:baseline;gap:.5rem;padding:.6rem .9rem;color:#3E2B1F}
  .tvo-c>summary::-webkit-details-marker{display:none}
  .tvo-c>summary::before{content:"\25B8";color:#B8863B;font-size:.8rem}
  .tvo-c[open]>summary::before{content:"\25BE"}
  .tvo-c>summary b{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1rem}
  .tvo-c>summary small{color:#8A7355;font-size:.78rem}
  .tvo-fam>summary b::after{content:"";}
  .tvo-c ul{list-style:none;margin:0;padding:0 .9rem .6rem 2rem;display:grid;gap:.15rem}
  .tvo-it{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.1rem .8rem;padding:.3rem 0;border-top:1px solid #EADFC4;font-size:.9rem}
  .tvo-it a{color:#3E2B1F;font-weight:600;text-decoration:none}.tvo-it a:hover{text-decoration:underline}
  .tvo-it span{color:#8A7355;font-size:.78rem}
  .tvo-sg{padding:.35rem 0 .1rem;border-top:1px dashed #EADFC4}
  .tvo-sg button,.tvo-more button{background:none;border:0;padding:0;color:#7A5A2E;font:inherit;font-size:.82rem;text-decoration:underline;cursor:pointer}
  .tvo-more{margin:.2rem 0 0;text-align:right}
</style>';
}

/**
 * Any list in named groups, each collapsible with a count: [group title => [['name', 'url', 'sub'], ...]].
 * An item with 'peek' => listing id opens the search peek card instead of leaving the page.
 */
function tv_grouped_list(array $groups, array $opt = []): string
{
    $open = (int) ($opt['open'] ?? 2);
    $h = '<div class="tvo">';
    $n = 0;
    foreach ($groups as $title => $items) {
        if (!$items) continue;
        $h .= '<details class="tvo-c"' . ($n++ < $open ? ' open' : '') . '><summary><b>' . tv_e($title) . '</b> <small>' . count($items) . '</small></summary><ul>';
        foreach ($items as $it) {
            $h .= '<li class="tvo-it"><a href="' . tv_e($it['url']) . '"' . (!empty($it['peek']) ? ' data-tv-peek="' . tv_e((string) $it['peek']) . '"' : '') . '>' . tv_e($it['name']) . '</a>'
                . (!empty($it['sub']) ? '<span>' . tv_e($it['sub']) . '</span>' : '') . '</li>';
        }
        $h .= tv_suggest_link($opt['suggest'] ?? [], (string) $title) . '</ul></details>';
    }
    return $h . (!empty($opt['suggest']) ? '<p class="tvo-more"><button type="button" data-tv-suggest="' . tv_e(json_encode($opt['suggest'] + ['kind' => 'missing'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '">Know a place that isn\'t here? Tell us</button></p>' : '') . '</div>';
}
