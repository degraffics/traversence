<?php
/**
 * profile-header.php: the profile frame shared by the owner's dashboard and the public profile (draft, 2026-10-09,
 * from Jason's mockup). Cover photo across the top; on the left, the identity card and the details; on the right, the
 * tabs (quick access to each tool) and whatever the page puts under them (the Pulse for the owner, the tab's content
 * for visitors).
 *
 *   echo tv_profile_open($p, ['owner' => true, 'active' => 'about', 'actions' => '<html>']);
 *   … the page's own content …
 *   echo tv_profile_close();
 *
 * The owner sees everything they entered, each item with a publish switch (eye) and a pencil; visitors see only what
 * was published (MemberProfile::public()).
 */
declare(strict_types=1);

require_once __DIR__ . '/../lib/MemberProfile.php';

function tv_profile_css(): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    return <<<'CSS'
<style>
  .pf2,.pf2-ed{--brn:#3E2B1F;--cr:#F7EFDC;--ln:rgba(203,185,141,.75);--gd:#B8863B;--rst:#92400E}
  .pf2{margin-top:0 !important}   /* flush under the top bar: no gap from the page's spacing */
  .ta-body .pf2-cover{margin-top:calc(-1.1rem - 1.1rem)}   /* the workspace's padding and its body's top margin (app-shell) */
  @media (min-width:768px){html.tv-brand-min.tv-nav-min .ta-body .pf2-cover{margin-top:calc(-1.1rem - 1.1rem - var(--ta-top,48px));height:calc(clamp(200px,32vh,300px) + var(--ta-top,48px))}}   /* slim header: the cover runs up to the top of the screen */
  .pf2-cover{position:relative;height:clamp(200px,32vh,300px);border-radius:0;background:#5C4632 center/cover no-repeat;overflow:hidden;margin:-1.1rem calc(-1 * clamp(1rem,3vw,2.5rem)) 0}
  .pf2-cover.none{background:linear-gradient(135deg,#5C4632,#8A6B45 60%,#B8863B)}
  .pf2-cbtn{position:absolute;right:.8rem;bottom:.8rem;background:#B45309;color:#FFF7EA;border-radius:.6rem;padding:.35rem .8rem;font-size:.8rem;font-weight:700;border:0;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.3)}
  .pf2-grid{display:grid;grid-template-columns:17.5rem 1fr;gap:1rem;align-items:start;margin-top:-4.5rem;position:relative;padding:0 .8rem}
  .pf2-grid{pointer-events:none}.pf2-grid>*>*{pointer-events:auto}   /* the empty space over the cover lets clicks through to its button */
  .pf2-side{display:flex;flex-direction:column;gap:.7rem}
  .pf2-dt{display:none;align-items:center;gap:.3rem;margin-top:.4rem;border:1px solid #CBB98D;background:#FFFBF2;color:#92400E;border-radius:999px;padding:.2rem .75rem;font:700 .78rem var(--tv-font-head,Georgia,serif);cursor:pointer}
  .pf2-dt[aria-expanded="true"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}.pf2-dt[aria-expanded="true"] span{display:inline-block;transform:rotate(180deg)}
  @media (max-width:900px){.pf2-dt{display:inline-flex}.pf2[data-owner="1"]:not(.det-open) .pf2-det{display:none}}   /* the owner's details fold away on narrow screens */
  .pf2-card{background:var(--cr);border:1px solid var(--ln);border-radius:.8rem;padding:.75rem;box-shadow:0 4px 14px rgba(42,27,18,.18)}
  .pf2-id{display:flex;gap:.65rem;align-items:flex-start}
  .pf2-av{width:4.6rem;height:4.6rem;border-radius:.5rem;background:#CBB98D center/cover no-repeat;flex:none;display:flex;align-items:center;justify-content:center;font:700 1.8rem var(--tv-font-head,Georgia,serif);color:var(--brn);position:relative;border:2px solid #FFFBF2}
  .pf2-av button{position:absolute;right:-.3rem;bottom:-.3rem;width:1.3rem;height:1.3rem;padding:0;border-radius:50%;background:var(--gd);color:#2A1B12;border:2px solid #FFFBF2;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 1px 3px rgba(0,0,0,.3)}
  .pf2-av button svg{width:.7rem;height:.7rem;stroke-width:2.6}
  .pf2-cbtn{display:inline-flex;align-items:center;gap:.35rem}.pf2-cbtn svg{width:.8rem;height:.8rem;flex:none}
  [data-tv-photos]{cursor:zoom-in}
  .pf2-nm{font:700 1.15rem/1.15 var(--tv-font-head,Georgia,serif);color:var(--brn);word-break:break-word}
  .pf2-sub{font-size:.75rem;color:#5C4632;margin-top:.15rem}.pf2-sub a{color:var(--rst);text-decoration:underline}
  .pf2-st{font-size:.8rem;color:#3E2B1F;margin-top:.15rem}
  .pf2-tl{display:flex;gap:.3rem;margin-left:auto}
  .pf2-i{width:1.6rem;height:1.6rem;border-radius:50%;border:1px solid #CBB98D;background:#FFFBF2;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;color:#B45309;flex:none}
  .pf2-i svg{width:.85rem;height:.85rem}.pf2-i.on{background:#8FBCA8;border-color:#8FBCA8;color:#2A1B12}
  .pf2-sec>summary{display:flex;align-items:center;list-style:none;cursor:pointer}
  .pf2-sec>summary::-webkit-details-marker{display:none}
  .pf2-sec>summary::after{content:'◂';margin-left:auto;color:#8A7355;font-size:.8rem}.pf2-sec[open]>summary::after{content:'▾'}
  .pf2-sec h3{display:flex;align-items:center;gap:.4rem;font:700 .95rem var(--tv-font-head,Georgia,serif);color:var(--brn);margin:0}
  .pf2-note{display:flex;gap:.35rem;align-items:flex-start}.pf2-note svg{width:.9rem;height:.9rem;flex:none;margin-top:.1rem;color:#8A7355}
  .pf2-sec+.pf2-sec{border-top:1px solid var(--ln);margin-top:.6rem;padding-top:.6rem}
  .pf2-dl{list-style:none;margin:.45rem 0 0;padding:0;font-size:.8rem;color:#3E2B1F;background:#EFE3C8;border-radius:.5rem;padding:.4rem .55rem}
  .pf2-dl li{display:flex;gap:.45rem;align-items:center;padding:.18rem 0}
  .pf2-dl li .k{color:#5C4632;font-weight:600}.pf2-dl li .v{flex:1;min-width:0;word-break:break-word}
  .pf2-dl li.off .v,.pf2-dl li.off .k{opacity:.55}
  .pf2-dl .ic{width:.9rem;height:.9rem;color:#B45309;flex:none}.pf2-dl .ic svg{width:.9rem;height:.9rem}
  .pf2-empty{font-size:.75rem;color:#8A7355;padding:.25rem 0}
  .pf2-main{min-width:0}
  .pf2-tabs{display:flex;align-items:center;gap:.25rem;background:var(--cr);border:1px solid var(--ln);border-radius:.6rem;padding:.25rem;overflow-x:auto;scrollbar-width:none;margin-top:4.8rem}
  .pf2-tabs::-webkit-scrollbar{display:none}
  .pf2-tab{white-space:nowrap;font:700 .78rem var(--tv-font-head,Georgia,serif);color:var(--brn);padding:.35rem .65rem;border-radius:.4rem;text-decoration:none}
  .pf2-tab:hover{background:#E3D3AC}.pf2-tab.on{background:#3E2B1F;color:#F7EFDC}.pf2-tab.soon{opacity:.55}
  .pf2-tabs .sp{flex:1}
  .pf2-body{margin-top:.7rem}
  .pf2-lock{font-size:.72rem;color:#8A7355;margin-top:.45rem}
  .pf2-ed{position:fixed;inset:0;background:rgba(42,27,18,.55);z-index:200;color:#3E2B1F;display:flex;align-items:flex-start;justify-content:center;padding:4vh .6rem;overflow:auto}
  .pf2-ed[hidden]{display:none}
  .pf2-edb{background:#F7EFDC;border-radius:.8rem;max-width:34rem;width:100%;padding:1rem 1.1rem;box-shadow:0 10px 30px rgba(0,0,0,.35)}
  .pf2-edb h2{font:700 1.2rem var(--tv-font-head,Georgia,serif)}
  .pf2-row{display:grid;grid-template-columns:1fr auto;gap:.5rem;align-items:end;margin-top:.55rem}
  .pf2-row label{font-size:.75rem;font-weight:600;display:block;margin-bottom:.15rem}
  .pf2-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:.4rem .6rem;font-size:.9rem}
  .pf2-pub{display:flex;align-items:center;gap:.3rem;font-size:.72rem;color:#5C4632;white-space:nowrap;padding-bottom:.45rem}
  .pf2-b{font-size:.85rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;border-radius:.6rem;padding:.4rem .9rem;cursor:pointer}
  .pf2-b.go{background:var(--gd);border-color:var(--gd);color:#2A1B12}
  .pf2-lt{border:1px dashed #CBB98D;border-radius:.6rem;padding:.4rem .55rem;margin-top:.45rem}
  .pf2-lt .r{display:grid;grid-template-columns:1fr 1fr 5rem 1.5rem;gap:.3rem;margin-top:.3rem}
  .pf2-msg{font-size:.82rem;margin-top:.5rem}.pf2-msg.bad{color:#991B1B}.pf2-msg.ok{color:#166534}
  /* Pulse only (the layout button): no cover, card or tabs; just the Pulse */
  .pf2.pulse-only .pf2-cover,.pf2.pulse-only .pf2-side,.pf2.pulse-only .pf2-tabs{display:none}
  .pf2.pulse-only .pf2-grid{grid-template-columns:1fr;margin-top:0;padding:0}
  .pf2.pulse-only .pf2-body{margin-top:0}
  .pf2-lay svg{width:.95rem;height:.95rem}
  .pf2-lay-top{display:none}
  /* phones, your account (slim header): the layout switcher lives in the top corner, left of your photo; the tools list covers it when open */
  @media (max-width:767px){
    html.tv-brand-min.tv-nav-min body.tv-back .pf2-lay-top{display:flex;position:fixed;top:.5rem;right:66px;z-index:43;width:2.3rem;height:2.3rem;box-shadow:0 2px 8px rgba(42,27,18,.35)}   /* no box: the round button, over the cover or the cream page */
    html.tv-brand-min.tv-nav-min body.tv-back .pf2-lay-top svg{width:1.1rem;height:1.1rem}
    html.tv-brand-min.tv-nav-min body.tv-back .pf2.pulse-only .pf2-lay-top{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}
    html.tv-brand-min.tv-nav-min body.tv-back .pf2-lay:not(.pf2-lay-top){display:none}
    html:has(.ta-rail.open) .pf2-lay-top{visibility:hidden!important}   /* the tools list covers it while open */
  }
  @media (max-width:900px){
    .pf2-grid{grid-template-columns:1fr;margin-top:-3rem;padding:0 3px}
    .pf2-tabs{margin-top:0}
  }
  @media (max-width:767px){
    .pf2-cover{height:170px;margin:-.8rem calc(-1 * var(--tv-pad, .85rem)) 0}
    .ta-body .pf2-cover{margin-top:calc(-.8rem - 1.1rem)}
    html.tv-brand-min.tv-nav-min body.tv-back .ta-body .pf2-cover{margin-top:calc(-.8rem - var(--ta-top,50px) - .6rem);height:calc(170px + var(--ta-top,50px))}   /* slim header: the cover runs to the top, behind the corner blocks */
    .pf2-cbtn{top:.6rem;bottom:auto}   /* the card overlaps the cover's foot on a phone */
    html.tv-brand-min.tv-nav-min .pf2-cbtn{top:auto;bottom:3.7rem;right:.6rem}   /* slim header: the top corners are the menu; the button sits just above the card */
  }
</style>
CSS;
}

/** One detail line: icon, label, value; for the owner an eye that publishes or hides it. */
function tv_profile_line(string $key, string $label, string $value, string $icon, bool $owner, bool $published): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $eye = $owner ? '<button type="button" class="pf2-i' . ($published ? ' on' : '') . '" data-pub="' . $e($key) . '" title="' . ($published ? 'Public: tap to hide' : 'Only you: tap to publish') . '" aria-label="' . ($published ? 'Hide' : 'Publish') . ' ' . $e($label) . '" aria-pressed="' . ($published ? 'true' : 'false') . '">' . tv_icon('eye', '') . '</button>' : '';
    return '<li' . ($owner && !$published ? ' class="off"' : '') . '><span class="ic">' . tv_icon($icon, '') . '</span><span class="v"><span class="k">' . $e($label) . ':</span> ' . $e($value) . '</span>' . $eye . '</li>';
}

/**
 * Opens the profile frame. $p is MemberProfile::get() for the owner, ::public() for visitors.
 * $opt: owner (bool), active (tab key), actions (HTML under the card: Link, Message…), tabs (override), base (public URL for tabs).
 */
function tv_profile_open(array $p, array $opt = []): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $owner = !empty($opt['owner']);
    $pub = array_flip($p['published'] ?? []);
    $on = fn (string $k) => isset($pub[$k]);
    $d = $p['details'] ?? [];
    $h = tv_profile_css();
    $h .= '<div class="pf2" data-owner="' . ($owner ? '1' : '0') . '">';
    if ($owner) $h .= str_replace('class="pf2-i pf2-lay"', 'class="pf2-i pf2-lay pf2-lay-top"', tv_profile_layout_button());   // phones: in the top corner, left of your photo
    if ($owner) $h .= '<script>try{if(localStorage.getItem("tv-pf-layout")==="pulse"){document.currentScript.parentNode.classList.add("pulse-only");if(!location.hash)history.replaceState(null,"","#pulse");}}catch(e){}</script>';

    // cover
    $cover = (string) ($p['cover'] ?? '');
    // public view: the photos open in the photo viewer (js/photo-viewer.js, tv_profile_lightbox): the profile photo first, then the cover
    $lbN = ['avatar' => 0, 'cover' => (string) ($p['avatar'] ?? '') !== '' ? 1 : 0];
    $lb = fn (string $src, string $cap) => !$owner && $src !== '' ? ' data-tv-photos="profile" data-i="' . $lbN[$cap === 'Cover photo' ? 'cover' : 'avatar'] . '" role="button" tabindex="0" aria-label="Open the ' . $e(strtolower($cap)) . '"' : '';
    $h .= '<div class="pf2-cover' . ($cover === '' ? ' none' : '') . '"' . $lb($cover, 'Cover photo') . ($cover !== '' ? ' style="background-image:url(\'' . $e($cover) . '\');background-position:center ' . (int) ($p['cover_y'] ?? 50) . '%"' : '') . '>';
    if ($owner) $h .= '<button type="button" class="pf2-cbtn" data-photo="cover">' . ($cover === '' ? tv_icon('plus', '') . 'Add a cover photo' : tv_icon('pen', '') . 'Cover photo') . '</button>';
    $h .= '</div><div class="pf2-grid"><aside class="pf2-side">';

    // identity card
    $av = (string) ($p['avatar'] ?? '');
    $name = (string) ($p['name'] ?? '');
    $h .= '<div class="pf2-card tv-bleed"><div class="pf2-id"><div class="pf2-av"' . $lb($av, 'Profile photo') . ($av !== '' ? ' style="background-image:url(\'' . $e($av) . '\')"' : '') . '>'
        . ($av === '' ? $e(mb_strtoupper(mb_substr($name, 0, 1))) : '')
        . ($owner ? '<button type="button" data-photo="avatar" title="' . ($av === '' ? 'Add' : 'Change') . ' your profile photo" aria-label="' . ($av === '' ? 'Add' : 'Change') . ' your profile photo">' . tv_icon($av === '' ? 'plus' : 'pen', '') . '</button>' : '') . '</div>'
        . '<div style="min-width:0;flex:1"><div class="pf2-nm">' . $e($name) . '</div>';
    if (($p['handle'] ?? '') !== '' && ($owner || $on('handle'))) $h .= '<div class="pf2-sub">@' . $e($p['handle']) . ($owner && !$on('handle') ? ' · <i>only you</i>' : '') . '</div>';
    if ($p['followers'] !== null && ($owner || $on('followers'))) $h .= '<div class="pf2-sub">' . (int) $p['followers'] . ' ' . ((int) $p['followers'] === 1 ? 'follower' : 'followers') . ($owner && !$on('followers') ? ' · <i>only you</i>' : '') . '</div>';
    if (($p['status_line'] ?? '') !== '') $h .= '<div class="pf2-st">' . $e($p['status_line']) . '</div>';
    $quick = [];
    if (!empty($d['lives_in'])) $quick[] = '<a href="#pf2-personal">Location</a>';
    if (!empty($d['work'])) $quick[] = '<a href="#pf2-work">Work</a>';
    if (!empty($d['education'])) $quick[] = '<a href="#pf2-edu">Education</a>';
    if ($quick) $h .= '<div class="pf2-sub">' . implode(' | ', $quick) . '</div>';
    // phones: your details start folded away so the Pulse is near the top; this opens them (remembered, js/profile.js)
    if ($owner) $h .= '<button type="button" class="pf2-dt" data-det aria-expanded="false" aria-controls="pf2-det">Details <span aria-hidden="true">&#9662;</span></button>';
    $h .= '</div>';
    if ($owner) $h .= '<div class="pf2-tl"><button type="button" class="pf2-i" data-edit="card" title="Edit your card" aria-label="Edit your card">' . tv_icon('pen', '') . '</button></div>';
    $h .= '</div>' . ($opt['actions'] ?? '') . '</div>';

    // details
    $icons = ['about' => 'user', 'lives_in' => 'home', 'hometown' => 'map', 'relationship' => 'users', 'languages' => 'globe', 'views' => 'eye', 'mantra' => 'sparkle', 'website' => 'link'];
    $lines = '';
    foreach (MemberProfile::FIELDS as $k => [$label]) {
        if ($k === 'about' || ($d[$k] ?? '') === '') continue;
        $lines .= tv_profile_line($k, $label, (string) $d[$k], $icons[$k] ?? 'sparkle', $owner, $on($k));
    }
    $h .= '<div class="pf2-card tv-bleed pf2-det" id="pf2-det">';
    if (($d['about'] ?? '') !== '') {
        $h .= '<p class="text-sm" style="white-space:pre-line' . ($owner && !$on('about') ? ';opacity:.6' : '') . '">' . $e($d['about']) . '</p>'
            . ($owner ? '<p class="pf2-lock"><button type="button" class="pf2-i' . ($on('about') ? ' on' : '') . '" data-pub="about" style="width:1.3rem;height:1.3rem;vertical-align:middle" aria-label="Publish About me">' . tv_icon('eye', '') . '</button> About me is ' . ($on('about') ? 'public' : 'only you') . '</p>' : '')
            . '<div style="border-top:1px solid rgba(203,185,141,.75);margin:.6rem 0"></div>';
    }
    $h .= '<details class="pf2-sec" id="pf2-personal" open><summary><h3>Personal details' . ($owner ? ' <button type="button" class="pf2-i" data-edit="personal" title="Edit" aria-label="Edit personal details" style="margin-left:.3rem">' . tv_icon('pen', '') . '</button>' : '') . '</h3></summary>'
        . ($lines !== '' ? '<ul class="pf2-dl">' . $lines . '</ul>' : '<p class="pf2-empty">' . ($owner ? 'Nothing yet. Tap the pencil to add where you live, your languages, a mantra…' : 'Nothing shared yet.') . '</p>') . '</details>';
    foreach (MemberProfile::LISTS as $k => [$label, $cols]) {
        $rows = $d[$k] ?? [];
        $id = $k === 'work' ? 'pf2-work' : 'pf2-edu';
        $h .= '<details class="pf2-sec" id="' . $id . '"' . ($rows ? ' open' : '') . '><summary><h3>' . $e($label) . ' details' . ($owner ? ' <button type="button" class="pf2-i" data-edit="' . $k . '" aria-label="Edit ' . $e(strtolower($label)) . '" style="margin-left:.3rem">' . tv_icon('pen', '') . '</button>' : '') . '</h3></summary>';
        if ($rows) {
            $h .= '<ul class="pf2-dl">';
            foreach ($rows as $r) {
                $vals = array_values(array_filter([$r[array_key_first($cols)] ?? '', ($r[array_keys($cols)[1]] ?? '') !== '' ? ($k === 'work' ? 'at ' : '') . $r[array_keys($cols)[1]] : '', $r[array_keys($cols)[2]] ?? '']));
                $h .= '<li' . ($owner && !$on($k) ? ' class="off"' : '') . '><span class="ic">' . tv_icon($k === 'work' ? 'store' : 'book', '') . '</span><span class="v">' . $e(implode(' · ', $vals)) . '</span></li>';
            }
            $h .= '</ul>' . ($owner ? '<p class="pf2-lock"><button type="button" class="pf2-i' . ($on($k) ? ' on' : '') . '" data-pub="' . $k . '" style="width:1.3rem;height:1.3rem;vertical-align:middle" aria-label="Publish ' . $e(strtolower($label)) . '">' . tv_icon('eye', '') . '</button> ' . ($on($k) ? 'Public' : 'Only you') . '</p>' : '');
        } else {
            $h .= '<p class="pf2-empty">' . ($owner ? 'Nothing yet.' : 'Nothing shared yet.') . '</p>';
        }
        $h .= '</details>';
    }
    if ($owner) $h .= '<p class="pf2-lock pf2-note">' . tv_icon('eye', '') . '<span>Only what you publish (green eye) shows on your public profile. <a class="underline" href="/user/profile.php?id=' . (int) $p['id'] . '&amp;as=visitor">See it as others do</a></span></p>';
    $h .= '</div></aside><section class="pf2-main">';

    // tabs: quick access to each tool
    $active = (string) ($opt['active'] ?? '');
    $base = (string) ($opt['base'] ?? '/user/profile.php?id=' . (int) $p['id']);
    $h .= '<nav class="pf2-tabs tv-bleed" data-more aria-label="Profile tools">';
    foreach (MemberProfile::TABS as $k => [$label, $ownerUrl, $pubKey, $soon]) {
        if (!$owner && $pubKey === null) continue;
        $url = $owner ? (str_starts_with($ownerUrl, '@') ? '/user/profile.php?id=' . (int) $p['id'] . '&tab=' . substr($ownerUrl, 1) : $ownerUrl) : $base . '&tab=' . $pubKey;
        $h .= '<a class="pf2-tab' . ($active === $k ? ' on' : '') . ($soon ? ' soon' : '') . '" href="' . $e($url) . '"' . ($owner && str_starts_with($ownerUrl, '#') ? ' data-go="' . $e(substr($ownerUrl, 1)) . '"' : '') . ($soon ? ' title="Coming"' : '') . '>' . $e($label) . '</a>';
    }
    $h .= '<span class="sp" data-keep></span>' . ($owner ? '<span data-keep style="display:inline-flex;align-items:center;gap:.3rem;flex:none"><a class="pf2-i" href="#journeys:new" title="New journey" aria-label="New journey">' . tv_icon('plus', '') . '</a>' . tv_profile_layout_button() . '</span>' : '') . '</nav><div class="pf2-body">';   // + and the layout switch never fold under More (data-keep)
    if (!$owner) $h .= tv_profile_lightbox($p);
    return $h;
}

/** The layout button: switches between the full profile and the Pulse only. Remembered on this device. */
function tv_profile_layout_button(): string
{
    return '<button type="button" class="pf2-i pf2-lay" data-layout title="Switch between your full profile and the Pulse only" aria-label="Switch layout: full profile or Pulse only">'
        . '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="9" y1="12" x2="21" y2="12"/></svg></button>';
}

function tv_profile_close(): string
{
    return '</div></section></div></div>';
}

/** The owner's editor (a lightbox) and the photo picker: one per page. */
function tv_profile_editor(array $p): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $data = ['profile' => $p, 'fields' => MemberProfile::FIELDS, 'lists' => MemberProfile::LISTS, 'csrf' => $_SESSION['csrf_token'] ?? ''];
    return '<div class="pf2-ed" id="pf2-ed" hidden role="dialog" aria-modal="true" aria-label="Edit your profile"><div class="pf2-edb" id="pf2-edb"></div></div>'
        . '<input type="file" id="pf2-file" accept="image/jpeg,image/png,image/webp" hidden>'
        . '<script id="pf2-data" type="application/json">' . json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>'
        . '<script src="/js/profile.js?v=' . (int) @filemtime(dirname(__DIR__, 2) . '/website/js/profile.js') . '" defer></script>';
}

/** The public view's photos: the profile and cover photos (when published) open in the photo viewer, with who posted them,
 *  likes, comments and Share (layout only for now, draft 2026-10-09). */
function tv_profile_lightbox(array $p): string
{
    $who = ['name' => (string) ($p['name'] ?? ''), 'avatar' => (string) ($p['avatar'] ?? '')];
    $items = [];
    foreach (['avatar' => 'Profile photo', 'cover' => 'Cover photo'] as $k => $label) {
        if ((string) ($p[$k] ?? '') !== '') $items[] = ['full' => $p[$k], 'caption' => '', 'from' => ['text' => $who['name'] . '’s ' . strtolower($label), 'link' => '', 'url' => ''], 'who' => $who, 'when' => '', 'public' => true, 'photo' => ''];
    }
    if (!$items) return '';
    $me = null;
    if (class_exists('Auth') && ($u = Auth::currentUser())) {
        $me = ['name' => trim((string) ($u['display_name'] ?? '')) ?: 'you', 'avatar' => ''];
        try { if (class_exists('MemberProfile') && class_exists('Database')) $me['avatar'] = (string) (MemberProfile::get(Database::connection(), (int) $u['id'])['avatar'] ?? ''); } catch (Throwable) {}
    }
    $j = fn ($v) => json_encode($v, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
    return '<script src="/js/photo-viewer.js?v=' . (int) @filemtime(dirname(__DIR__, 2) . '/website/js/photo-viewer.js') . '"></script>'
        . '<script>TvPhotos.bind("profile", ' . $j($items) . ', {owner: false, me: ' . $j($me) . '});</script>';
}
