<?php
// app/ui/not-found.php — the site's own "page not found" (404): the site's frame, a plain message, search, and the main
// places to go. Shown by Apache for any address that isn't there (ErrorDocument 404 /website/_errors/404.php) and by any page
// that finds nothing at its address (tv_not_found()). Search engines are told there's nothing to list (status 404).
declare(strict_types=1);

require_once __DIR__ . '/page-shell.php';

function tv_not_found(string $what = ''): never
{
    if (!headers_sent()) { http_response_code(404); header('Content-Type: text/html; charset=utf-8'); }
    tv_page_start('Page not found', ['description' => 'This page isn\'t here.', 'no_crumbs' => true]);
    $go = [['/', 'Home', 'Back to the start'], ['/directory/', 'Get Local', 'Businesses and services near you'], ['/discovery/', 'Let\'s Explore', 'Places, trails and things to do'], ['/faq.php', 'FAQ', 'Answers to common questions']];
    ?>
<style>
  .nf{max-width:34rem;margin:1.5rem auto 2rem;text-align:center}
  .nf-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;box-shadow:0 4px 10px rgba(62,43,31,.08);padding:1.6rem 1.25rem}
  .nf-mark{width:64px;height:64px;margin:0 auto .8rem;color:#B45309}
  .nf h1{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.6rem;color:#2A1D14;margin:0 0 .4rem}
  .nf p{color:#5C4632;line-height:1.55;margin:0 0 1rem}
  .nf-search{display:inline-flex;align-items:center;gap:.45rem;background:#3E2B1F;color:#FFFBF2;border-radius:999px;padding:.6rem 1.3rem;font-weight:700;margin-bottom:1.2rem}
  .nf-search:hover{background:#2A1D14}
  .nf-go{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(14rem,100%),1fr));gap:.5rem;text-align:left}
  .nf-go a{display:block;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.7rem;padding:.6rem .8rem;text-decoration:none}
  .nf-go a:hover{border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.25)}
  .nf-go b{display:block;color:#92400E;text-decoration:underline}.nf-go small{color:#8A7355}
</style>
<div class="nf">
  <div class="nf-card tv-bleed">
    <svg class="nf-mark" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="32" cy="32" r="26"/><path d="M40 24l-5 11-11 5 5-11z"/><path d="M32 6v5M32 53v5M6 32h5M53 32h5"/></svg>
    <h1>We couldn't find that page</h1>
    <p><?= $what !== '' ? tv_e($what) : 'The link may be old, or the page may have moved. Nothing is wrong on your side.' ?></p>
    <button type="button" class="nf-search" onclick="if (window.TvSearch) TvSearch.open(''); else location.href = '/';"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>Search Traversence</button>
    <nav class="nf-go" aria-label="Places to go">
      <?php foreach ($go as [$u, $l, $d]): ?><a href="<?= tv_e($u) ?>"><b><?= tv_e($l) ?></b><small><?= tv_e($d) ?></small></a><?php endforeach; ?>
    </nav>
  </div>
</div>
<?php
    tv_page_end();
    exit;
}
