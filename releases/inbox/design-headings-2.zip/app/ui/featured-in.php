<?php
// app/ui/featured-in.php — "Featured in" (decisions/0132): the published pieces that name this listing, landmark or
// outdoor place (its content tags), each a way into the deeper story. Guides now; journeys, stories and the rest as they
// move onto the tag store. Nothing shows when nothing names it.
declare(strict_types=1);

require_once __DIR__ . '/../lib/ContentTags.php';

function tv_featured_in(PDO $pdo, string $ref): string
{
    try { $rows = ContentTags::featuredIn($pdo, $ref); } catch (Throwable $e) { error_log('featured-in: ' . $e->getMessage()); return ''; }
    if (!$rows) return '';
    $h = '<section class="tv-fi tv-bleed" aria-labelledby="tv-fi-h"><h2 id="tv-fi-h">Featured in</h2><div class="tv-fi-g">';
    foreach ($rows as [$title, $url, $kind]) $h .= '<a class="tv-fi-c" href="' . tv_e($url) . '"><small>' . tv_e($kind) . '</small><b>' . tv_e($title) . '</b></a>';
    return $h . '</div></section><style>
  .tv-fi{margin-top:1.5rem;background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem 1.1rem}
  .tv-fi h2{font:700 1.1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:0 0 .6rem}
  .tv-fi-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(13rem,100%),1fr));gap:.5rem}
  .tv-fi-c{display:block;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.7rem;padding:.55rem .7rem;text-decoration:none}
  .tv-fi-c small{display:block;font-size:.7rem;letter-spacing:.06em;text-transform:uppercase;color:#8A7355}
  .tv-fi-c b{font:700 1rem var(--tv-font-head,Georgia,serif);color:#92400E;text-decoration:underline}.tv-fi-c:hover{border-color:#B45309}
  @media (max-width:767px){ .tv-fi{border-radius:.5rem;padding:.8rem .7rem} .tv-fi-g{gap:3px} }
</style>';
}
