<?php
// app/ui/tag-chips.php — a piece's tags as its author sees them (decisions/0132 §2a): each a chip with ×, so the author
// keeps the say over what their piece is tied to. Right after publishing it's the confirmation they land on, with
// "Looks good"; later it sits on the piece for them alone. Nobody else sees it.
declare(strict_types=1);

require_once __DIR__ . '/../lib/ContentTags.php';

function tv_tag_chips(PDO $pdo, string $src, bool $justPublished = false): string
{
    $tags = ContentTags::forSource($pdo, $src);
    if (!$tags) return $justPublished ? '<p data-tv-status="ok" data-tv-label="Published:">It\'s live.</p>' : '';
    $h = '<section class="tv-tc-own tv-bleed" id="tv-tags" aria-labelledby="tv-tags-h">'
       . ($justPublished ? '<p data-tv-status="ok" data-tv-label="Published:">It\'s live. These are what it\'s tied to: each one is highlighted in your text and your piece shows on its page. Take off any that aren\'t right.</p>' : '')
       . '<h2 id="tv-tags-h">Tagged in your piece <small>only you see this</small></h2><div class="tv-tc-chips">';
    foreach ($tags as $t) $h .= '<span class="tv-tc-chip"><a href="' . tv_e($t['url']) . '">' . tv_e($t['name']) . '</a><button type="button" data-tag-off="' . (int) $t['id'] . '" title="Take this tag off" aria-label="Take ' . tv_e($t['name']) . ' off">×</button></span>';
    $h .= '</div>' . ($justPublished ? '<button type="button" class="tv-tc-ok" data-tag-ok>Looks good</button>' : '') . '</section>';
    return $h . '<style>
  .tv-tc-own{margin:1rem 0;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.8rem;padding:.7rem .8rem}
  .tv-tc-own h2{font:700 .95rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:.2rem 0 .5rem}.tv-tc-own h2 small{font:400 .72rem system-ui,sans-serif;color:#8A7355;margin-left:.4rem}
  .tv-tc-chips{display:flex;flex-wrap:wrap;gap:.35rem}
  .tv-tc-chip{display:inline-flex;align-items:center;gap:.25rem;background:#F3EAD3;border:1px solid #CBB98D;border-radius:999px;padding:.15rem .25rem .15rem .65rem;font-size:.85rem}
  .tv-tc-chip a{color:#92400E;font-weight:700;text-decoration:none}
  .tv-tc-chip button{width:22px;height:22px;border-radius:999px;border:0;background:#FFFBF2;color:#92400E;font-weight:700;cursor:pointer;line-height:1}
  .tv-tc-chip button:hover{background:#B45309;color:#fff}
  .tv-tc-ok{margin-top:.6rem;font-weight:700;color:#fff;background:#B45309;border:0;border-radius:999px;padding:.35rem 1rem;cursor:pointer}
  @media (max-width:767px){ .tv-tc-own{border-radius:.5rem} }
</style><script>
(function () {
  var box = document.getElementById("tv-tags"); if (!box) return;
  var csrf = null, token = function () { return csrf ? Promise.resolve(csrf) : fetch("/api/content-tags.php", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (d) { csrf = d.csrf; return csrf; }); };
  box.addEventListener("click", function (e) {
    var ok = e.target.closest("[data-tag-ok]"); if (ok) { box.remove(); return; }
    var b = e.target.closest("[data-tag-off]"); if (!b) return;
    b.disabled = true;
    token().then(function (t) { return fetch("/api/content-tags.php", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", "X-CSRF-Token": t || "" }, body: JSON.stringify({ action: "remove", id: +b.getAttribute("data-tag-off") }) }); })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) { b.disabled = false; window.TvAsk && TvAsk.say((d.error && d.error.message) || "That didn’t work.", { anchor: b, bad: true }); return; }
        var chip = b.closest(".tv-tc-chip"), name = chip.querySelector("a").textContent;
        document.querySelectorAll("a.gl[data-tag]").forEach(function (a) { if (a.textContent === name) a.replaceWith(document.createTextNode(a.textContent)); });   // the highlight comes out of the text at once
        chip.remove();
        window.TvAsk && TvAsk.say(d.message, { anchor: box, bad: false });
      }).catch(function () { b.disabled = false; });
  });
})();
</script>';
}
