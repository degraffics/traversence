<?php
/**
 * includes/journey-ui.php — the journey card, its styles, and the contributor guidelines (decisions/0056).
 * Every card says whose it is: Traversence (our editorial), Contributor (a named member) or Business (a listing's team).
 */
require_once __DIR__ . '/page-shell.php';

function tv_journey_css(): string
{
    return '<style>
  .jr-grid{display:grid;gap:.9rem;grid-template-columns:repeat(auto-fill,minmax(260px,1fr))}
  /* the card, as in the concept (decisions/0058 §29): a title bar with the Link button, "Posted" and the read time on the
     photo, the author and the counts along the foot. The wrap holds the Link button beside the card link, never inside it. */
  .jr-wrap{position:relative;display:flex}.jr-wrap>.jr-card{flex:1;min-width:0}
  .jr-wrap .tv-corner{top:.42rem;right:.5rem}.jr-wrap .tv-link{background:rgba(255,251,242,.1);border-color:rgba(232,214,174,.7);color:#E8D6AE}
  .jr-card{display:flex;flex-direction:column;background:#3E2B1F;border:1px solid #5A4330;border-radius:.8rem;overflow:hidden;color:#FFFBF2;text-decoration:none;box-shadow:0 8px 20px -14px rgba(0,0,0,.6)}
  .jr-card:hover{box-shadow:0 12px 26px -12px rgba(0,0,0,.7)}
  .jr-head{display:flex;align-items:center;gap:.5rem;padding:.5rem .75rem;min-height:2.6rem;box-sizing:border-box}.jr-wrap .jr-head{padding-right:2.9rem}
  .jr-head b{flex:1;min-width:0;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:600;font-size:1rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .jr-head small{font-weight:400;color:#E8D6AE}
  .jr-img{position:relative;aspect-ratio:16/10;background:#5A4330 center/cover no-repeat;margin:0 .35rem;border-radius:.45rem;overflow:hidden}
  .jr-img::after{content:"";position:absolute;inset:0 0 auto 0;height:38%;background:linear-gradient(180deg,rgba(20,13,8,.55),rgba(20,13,8,0));pointer-events:none}
  .jr-img.none{display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#7A5A3A,#3E2B1F)}
  .jr-img.none .jr-t{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.05rem;color:#F3DDB0;padding:1rem;text-align:center}
  .jr-img.jr-mat{background:repeating-linear-gradient(135deg,#3E2B1F 0 14px,#46321F 14px 28px)}.jr-mat small{font-family:system-ui,sans-serif;font-size:.75rem;color:#E8D6AE}
  .jr-posted{position:absolute;z-index:1;top:.45rem;left:.55rem;font-size:.66rem;font-weight:600;color:#FFFBF2;text-shadow:0 1px 3px rgba(0,0,0,.85)}
  .jr-pill{position:absolute;z-index:1;top:.4rem;display:inline-flex;align-items:center;gap:.25rem;font-size:.64rem;font-weight:700;background:rgba(255,251,242,.92);color:#3E2B1F;border-radius:999px;padding:.12rem .5rem}
  .jr-pill.l{left:.5rem}.jr-pill.r{right:.5rem}.jr-pill svg{width:11px;height:11px}
  .jr-play{position:absolute;z-index:1;inset:0;margin:auto;width:46px;height:46px;border-radius:999px;background:rgba(255,251,242,.85);display:flex;align-items:center;justify-content:center;color:#3E2B1F;font-size:1.1rem}
  .jr-foot{display:flex;align-items:center;gap:.4rem;padding:.5rem .7rem .55rem;font-size:.76rem}
  .jr-av{width:22px;height:22px;border-radius:999px;background:#B8863B;color:#2A1B12;box-shadow:0 0 0 2px #FFFBF2;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:.72rem;flex:0 0 auto}
  .jr-by{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600;letter-spacing:.03em;text-transform:uppercase;font-size:.7rem}
  .jr-by small{text-transform:none;letter-spacing:0;font-weight:400;color:#E8D6AE}
  .jr-stats{display:inline-flex;align-items:center;gap:.2rem;background:#B8863B;color:#2A1B12;border-radius:999px;padding:.08rem .45rem;font-weight:700;font-size:.66rem;white-space:nowrap}
  .jr-stats svg{width:11px;height:11px}
  .jr-like{display:inline-flex;align-items:center;gap:.2rem;font-weight:700;font-size:.7rem;color:#FFFBF2}.jr-like svg{width:14px;height:14px;fill:#FFFBF2}
  .jr-voice{font-size:.56rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;border-radius:.3rem;padding:.06rem .3rem;white-space:nowrap}
  .jr-voice.t{background:#DCFCE7;color:#14532D}.jr-voice.c{background:#F3E6C8;color:#5C4632}.jr-voice.p{background:#FDE68A;color:#78350F}
  .jr-empty{background:#FFFBF2;border:1px dashed #CBB98D;border-radius:1rem;padding:1rem;color:#3E2B1F;font-size:.92rem}
</style>';
}

/** Small flat icons for the card (the brand's line icons, not emoji). */
function tv_journey_ic(string $k): string
{
    $p = ['eye' => '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
          'chat' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
          'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
          'heart' => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>'][$k] ?? '';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

/**
 * One card in the feed. $it from Journeys::feed(). As in the concept (decisions/0058 §29): the title bar (kind | title)
 * with the Link button in its corner, "Posted" and the read time on the photo, the author with views and comments as
 * gold pills and the likes along the foot. js/link-button.js puts the Link button in the wrap's corner.
 */
function tv_journey_card(array $it): string
{
    $date = $it['date'] ? date('M j, Y', strtotime((string) $it['date'])) : '';
    $voice = $it['voice'] === 'traversence' ? '<span class="jr-voice t" title="Written by Traversence">Traversence</span>'
           : (($it['author_kind'] ?? '') === 'listing' ? '<span class="jr-voice c" title="A journey by a local business">Business</span>' : '<span class="jr-voice c" title="A journey by a contributor">Contributor</span>');
    $img = !empty($it['mature']) ? '<div class="jr-img none jr-mat"><span class="jr-t">Mature themes<br><small>Open to read</small></span>'   // gated (decisions/0058 §7)
         : ($it['image'] !== ''
        ? '<div class="jr-img" style="background-image:url(\'' . tv_e($it['image']) . '\')">'
        : '<div class="jr-img none"><span class="jr-t">' . tv_e($it['place'] ?: $it['title']) . '</span>');
    $stats = $it['type'] === 'journey'
        ? '<span class="jr-stats" title="Views">' . tv_journey_ic('eye') . (int) $it['views'] . '</span><span class="jr-stats" title="Comments">' . tv_journey_ic('chat') . (int) $it['comments'] . '</span>'
          . '<span class="jr-like" title="Likes">' . tv_journey_ic('heart') . (int) $it['likes'] . '</span>'
        : '<span class="jr-stats">Guide</span>';
    $card = '<a class="jr-card" href="' . tv_e($it['url']) . '">'
        . '<div class="jr-head"><b>' . tv_e($it['category']) . ' <small>|</small> ' . tv_e($it['title']) . '</b></div>'
        . $img . ($date ? '<span class="jr-posted">Posted ' . tv_e($date) . '</span>' : '') . '<span class="jr-pill r">' . tv_journey_ic('clock') . (int) $it['minutes'] . ' min read</span>'
        . (!empty($it['video']) ? '<span class="jr-play" aria-label="Has a video">▶</span>' : '') . '</div>'
        . '<div class="jr-foot"><span class="jr-av" aria-hidden="true">' . tv_e(mb_strtoupper(mb_substr((string) $it['author'], 0, 1))) . '</span><span class="jr-by">' . tv_e($it['author'])
        . ($it['place'] ? ' <small>· ' . tv_e($it['place']) . '</small>' : '') . '</span>' . $voice . (!empty($it['partnership']) ? '<span class="jr-voice p">Partnership</span>' : '') . $stats . '</div></a>';
    if ($it['type'] !== 'journey' || empty($it['id'])) return $card;
    return '<div class="jr-wrap" data-link-host>' . $card . '<span data-link="place:jr:' . (int) $it['id'] . '" data-link-label="' . tv_e($it['title']) . '"></span></div>';
}

/** The contributor guidelines (decisions/0056 §4–5): guidance, not advice. */
function tv_contributor_guidelines(): string
{
    return '<div class="cg">
  <h3>Your journeys are yours</h3>
  <p>You keep ownership of what you post. Traversence shows it on the site with your name. Remove it any time.</p>
  <h3>Was Here, and your location</h3>
  <p>We never expose anyone&rsquo;s location; you may share your own. Journeys are about places you were (<b>Was Here</b>). When you upload a photo,
     everything hidden in the file (GPS coordinates, your device, the time) is removed. If you want to show where a photo was taken, tag it yourself.
     Live check-ins (<b>Am Here</b>) are a separate feature you&rsquo;ll be able to switch on, with their own rules.</p>
  <h3>Tribal lands</h3>
  <p>Tribal nations are sovereign nations, and many restrict photography and filming; some villages don&rsquo;t allow it at all, and commercial filming
     needs permits. Follow each nation&rsquo;s rules for visitors, and don&rsquo;t point others to sacred or restricted places.</p>
  <h3>People and private property</h3>
  <p>Ask before you show people, and take extra care with children. Private homes and property need the owner&rsquo;s permission.
     You can say so on your journey (people shown, with permission, on private property).</p>
  <h3>What gets reported</h3>
  <p>Spam or scams, harassment or hate, sacred or restricted sites, someone&rsquo;s private information, people shown without their consent,
     private property without permission, and unsafe or illegal content. Journeys publish when you post them; reported ones are looked at by our team,
     and a hidden journey stays visible to you.</p>
  <h3>Partnerships</h3>
  <p>If you were paid, or given something free, for a journey, mark it <b>Partnership</b>. U.S. law requires the disclosure.</p>
  <p class="cg-note">This is guidance, not legal advice. You&rsquo;re responsible for what you post.</p>
</div>';
}
