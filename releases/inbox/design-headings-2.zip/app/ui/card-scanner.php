<?php
// app/ui/card-scanner.php — Sales → Scan cards (decisions/0108). Phone first: Scan a card opens the camera; the photo
// is made small on the phone, sent, and read in seconds; Check it opens the card beside the list (full screen on a
// phone) with every field filled, the listings it may already be, and Save. No signal: scans wait on the phone and
// go when it's back. Uses /admin/api/cards.php.
declare(strict_types=1);

require_once __DIR__ . '/../lib/CardScan.php';

function tv_card_scanner(PDO $pdo, string $catOptions): string
{
    $e = 'tv_e';
    $connected = AiClient::providerFor('card') !== '';
    ob_start(); ?>
<script src="/js/tv-time.js?v=<?= (int) @filemtime(__DIR__ . '/../../website/js/tv-time.js') ?>"></script>
<style>
  .cs-go{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}
  .cs-big{display:inline-flex;align-items:center;gap:.5rem;font:700 1.05rem system-ui,sans-serif;padding:.75rem 1.2rem;border-radius:999px;border:0;background:#3E2B1F;color:#FFF8EA;cursor:pointer}
  .cs-big svg{width:22px;height:22px}
  .cs-tray{display:flex;gap:.6rem;align-items:center;flex-wrap:wrap;margin-top:.6rem;padding:.6rem;border:1px dashed #CBB98D;border-radius:.7rem;background:#FFFBF2}
  .cs-tray[hidden]{display:none}
  .cs-tray img{width:96px;height:60px;object-fit:cover;border-radius:.35rem;border:1px solid #CBB98D}
  .cs-wait{font-size:.9rem;color:#78350F;font-weight:600}
  .cs-list{margin-top:.8rem}
  .cs-row{display:flex;gap:.6rem;align-items:center;justify-content:space-between;padding:.6rem .1rem;border-top:1px solid #EADFC4;cursor:pointer}
  .cs-row:first-child{border-top:0}.cs-row b{color:#92400E;text-decoration:underline}.cs-row small{display:block;color:#8A7355}
  .cs-st{flex:none;font:700 .75rem system-ui,sans-serif;border-radius:999px;padding:.15rem .6rem;background:#EADFC4;color:#5C4632}
  .cs-st.ready{background:#FDE68A;color:#78350F}.cs-st.saved{background:#DCEFE5;color:#1F5C43}.cs-st.failed{background:#FEE2E2;color:#991B1B}
  .cs-ip{position:fixed;top:0;right:0;bottom:0;width:min(32rem,100%);z-index:1800;background:#FFFBF2;border-left:1px solid #CBB98D;box-shadow:-18px 0 40px -20px rgba(0,0,0,.45);display:flex;flex-direction:column}
  .cs-ip[hidden]{display:none}
  .cs-bar{display:flex;align-items:center;gap:.5rem;padding:.6rem .8rem;background:#3E2B1F;color:#FFF8EA}.cs-bar b{flex:1;font:700 1.02rem var(--tv-font-head,Georgia,serif);min-width:0}
  .cs-x{width:34px;height:34px;border-radius:999px;border:1px solid rgba(255,248,234,.45);background:transparent;color:#FFF8EA;font-size:1.3rem;cursor:pointer}
  .cs-body{flex:1;overflow-y:auto;padding:.8rem 1rem 2rem}
  .cs-pics{display:grid;grid-template-columns:repeat(auto-fit,minmax(8rem,1fr));gap:.4rem;margin-bottom:.6rem}.cs-pics img{width:100%;border-radius:.4rem;border:1px solid #CBB98D;cursor:zoom-in}
  .cs-f{display:grid;grid-template-columns:1fr 1fr;gap:.5rem}.cs-f label{display:grid;gap:.15rem;font-size:.82rem;font-weight:700;color:#5C4632;min-width:0}
  .cs-f .w{grid-column:1/-1}.cs-f .hb-in{width:100%;box-sizing:border-box;padding:.4rem .5rem;font-size:.95rem;font-weight:400}
  .cs-m{margin:.7rem 0;padding:.6rem;border:1px solid #E8C77A;border-radius:.6rem;background:#FEF9E7}.cs-m b{display:block;margin-bottom:.3rem}
  .cs-m div{display:flex;justify-content:space-between;align-items:center;gap:.5rem;padding:.3rem 0;border-top:1px solid #F3E2B3}.cs-m div:first-of-type{border-top:0}
  .cs-m a{color:#92400E;text-decoration:underline;font-weight:600}.cs-m small{display:block;color:#8A7355}
  .cs-acts{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.8rem;align-items:center}
  .cs-msg{font-weight:600;color:#1F3B30}.cs-msg.no{color:#991B1B}
  .cs-hint{font-size:.8rem;color:#8A7355;font-weight:400}
  @media (max-width:520px){.cs-f{grid-template-columns:1fr}}
</style>
<div class="hb-card tv-bleed">
  <p class="text-sm text-[#5C4632]">Photograph a business card: it's read in seconds and opens with every field filled in. Check it, choose the category, and save: it joins the listing that's already here or becomes a new one. <b>Save the lead</b> also makes it your lead with the visit logged; <b>Save as a listing</b> adds only the listing (a receipt, a menu or a sign from somewhere you went as a customer).</p>
  <?php if (!$connected): ?><p class="text-sm" style="color:#991B1B"><b>Card reading isn't connected yet</b> (ANTHROPIC_API_KEY in .env). You can still scan: each card is kept, and you fill it in by hand or read it later with <b>Try again</b>.</p><?php endif; ?>
  <div class="cs-go">
    <button type="button" class="cs-big" id="cs-scan"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>Scan a card</button>
    <span class="cs-wait" id="cs-wait" hidden></span>
  </div>
  <input type="file" accept="image/*" capture="environment" id="cs-cam" hidden>
  <div class="cs-tray" id="cs-tray" hidden>
    <img id="cs-f1" alt="Front"><img id="cs-f2" alt="Back" hidden>
    <button type="button" class="hb-b" id="cs-back">Add the back</button>
    <button type="button" class="hb-b go" id="cs-send">Read it</button>
    <button type="button" class="hb-b" id="cs-drop" aria-label="Drop this photo">×</button>
  </div>
  <h2 class="hb-h" style="margin:1rem 0 0">Your cards</h2>
  <div class="cs-list" id="cs-list"><p class="text-sm">Loading…</p></div>
</div>
<aside class="cs-ip" id="cs-ip" hidden role="dialog" aria-label="Check the card">
  <div class="cs-bar"><b id="cs-title">Card</b><button type="button" class="cs-x" id="cs-close" aria-label="Close" title="Close">×</button></div>
  <div class="cs-body" id="cs-body"></div>
</aside>
<template id="cs-cats"><?= $catOptions ?></template>
<script>
(function () {
  var csrf = null, cur = null, shot = [], pos = null, LIST = document.getElementById('cs-list');
  var F = <?= json_encode(CardScan::FIELDS, JSON_UNESCAPED_UNICODE) ?>, OUT = <?= json_encode(array_map(fn ($o) => $o[2], array_diff_key(Sales::OUTCOMES, ['note' => 1, 'no_answer' => 1, 'closed' => 1, 'won' => 1, 'lost' => 1, 'quote' => 1])), JSON_UNESCAPED_UNICODE) ?>;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  // when a card was scanned, in the zone it was scanned in, labeled (js/tv-time.js); the bare time if that script is missing
  function when(c) { return c.at ? (window.TvTime ? TvTime.fmt(c.at, c.tz || '') : String(c.at).slice(0, 16).replace('T', ' ')) : ''; }
  function tok() { return csrf ? Promise.resolve(csrf) : fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { return (csrf = d.csrf_token || ''); }); }
  function api(q, body, form) {
    var p = body || form ? tok().then(function (c) {
      var o = { method: 'POST', credentials: 'include', headers: { 'X-CSRF-Token': c } };
      if (form) o.body = form; else { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(window.tvSafe ? tvSafe(body) : body); }
      return fetch('/admin/api/cards.php', o);
    }) : fetch('/admin/api/cards.php' + q, { credentials: 'include' });
    return p.then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer (' + r.status + ').' } }; }); })
      .then(function (j) { if (!j.ok && j.success !== true && !j.data) throw new Error((j.error && j.error.message) || 'That didn\'t work.'); return j.data || j; });
  }
  var ST = { reading: 'Reading…', ready: 'Check it', saved: 'Saved', failed: 'Couldn\'t read' };
  function list() {
    return api('?list=1').then(function (d) {
      LIST.innerHTML = d.items.length ? d.items.map(function (c) {
        return '<div class="cs-row" data-card="' + c.id + '"><span><b>' + esc(c.name || 'Card ' + c.id) + '</b><small>' + esc([c.person, c.town, when(c)].filter(Boolean).join(' · ')) + '</small></span><span class="cs-st ' + c.status + '">' + ST[c.status] + '</span></div>';
      }).join('') : '<p class="text-sm">No cards yet. Tap <b>Scan a card</b>.</p>';
      d.items.forEach(function (c) { if (c.status === 'reading') watch(c.id); });
    }).catch(function (x) { LIST.innerHTML = '<p class="text-sm">' + esc(x.message) + '</p>'; });
  }
  var watching = {};
  function watch(id) {   // a card being read: check every 2 seconds for a minute
    if (watching[id]) return; watching[id] = 1; var n = 0;
    (function tick() { setTimeout(function () {
      api('?id=' + id).then(function (d) { if (d.card.status === 'reading' && ++n < 30) return tick(); delete watching[id]; list(); if (cur === id) show(d.card); }).catch(function () { delete watching[id]; });
    }, 2000); })();
  }

  // ---- the camera: front, then the back if it has one; made small on the phone (1600 px JPEG) ----
  var cam = document.getElementById('cs-cam'), tray = document.getElementById('cs-tray');
  function small(file) {
    return new Promise(function (ok, no) {
      var img = new Image(), u = URL.createObjectURL(file);
      img.onload = function () { var k = Math.min(1, 1600 / Math.max(img.width, img.height)), c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u);
        c.toBlob(function (b) { b ? ok(b) : no(new Error('The photo couldn\'t be read.')); }, 'image/jpeg', 0.85); };
      var tried = false;
      img.onerror = function () {   // a blocked or odd blob: link — read the file another way once before giving up
        URL.revokeObjectURL(u);
        if (tried) { no(new Error('The photo couldn\'t be opened. Try taking it again, or send a JPEG or PNG.')); return; }
        tried = true; var r = new FileReader(); r.onload = function () { img.src = r.result; }; r.onerror = function () { img.onerror(); }; r.readAsDataURL(file);
      };
      img.src = u;
    });
  }
  function where() { if (!navigator.geolocation) return; navigator.geolocation.getCurrentPosition(function (p) { pos = [p.coords.latitude, p.coords.longitude]; }, function () {}, { timeout: 8000, maximumAge: 300000 }); }
  document.getElementById('cs-scan').addEventListener('click', function () { shot = []; where(); cam.click(); });
  document.getElementById('cs-back').addEventListener('click', function () { cam.click(); });
  document.getElementById('cs-drop').addEventListener('click', function () { shot = []; tray.hidden = true; });
  cam.addEventListener('change', function () {
    var f = cam.files[0]; cam.value = ''; if (!f) return;
    small(f).then(function (b) {
      shot.push(b); shot = shot.slice(-2);
      var a = document.getElementById('cs-f1'), z = document.getElementById('cs-f2');
      // previews as data URLs: they show even where a security policy blocks blob: images
      var pv = function (blob, img) { var r = new FileReader(); r.onload = function () { img.src = r.result; }; r.readAsDataURL(blob); };
      pv(shot[0], a); z.hidden = shot.length < 2; if (shot[1]) pv(shot[1], z);
      document.getElementById('cs-back').hidden = shot.length > 1; tray.hidden = false;
    }).catch(function (x) { TvAsk.say(x.message); });
  });
  document.getElementById('cs-send').addEventListener('click', function () {
    if (!shot.length) return;
    var item = { front: shot[0], back: shot[1] || null, lat: pos ? pos[0] : '', lon: pos ? pos[1] : '', at: new Date().toISOString(), tz: window.TvTime ? TvTime.zone() : '' };   // the moment (UTC, marked Z) and the phone's zone
    shot = []; tray.hidden = true;
    send(item).catch(function () { hold(item); });   // no signal: keep it on the phone
  });
  // through the one uploader (/api/upload.php, target card_scan, decisions/0127): the front makes the card, the back
  // joins it. A card half sent keeps its id, so when it's sent again only the back goes.
  function off(x) { return !navigator.onLine || x instanceof TypeError || /connection dropped/.test((x && x.message) || ''); }
  function up(blob, name, ctx) { return TvUpload.send([new File([blob], name, { type: 'image/jpeg' })], { target: 'card_scan', ctx: ctx, el: tray, ask: false }).then(function (r) { return r[0].card; }); }
  function send(item) {
    if (!navigator.onLine) return Promise.reject(new Error('offline'));
    var front = item.card ? Promise.resolve({ id: item.card, status: 'reading' }) : up(item.front, 'front.jpg', { lat: item.lat, lon: item.lon, at: item.at, tz: item.tz || '', more: item.back ? 1 : 0 });
    return front.then(function (c) {
      if (!item.back) return c;
      item.card = c.id;
      return up(item.back, 'back.jpg', { card: c.id });
    }).then(function (c) { list(); if (c.status === 'reading') watch(c.id); else if (c.status === 'ready') open(c.id); },
      function (x) { if (off(x)) throw x; list(); });   // refused: TvUpload has said why beside the tray; nothing to hold
  }

  // ---- held on the phone until there's a signal (IndexedDB) ----
  function db() { return new Promise(function (ok, no) { var r = indexedDB.open('tv-cards', 1); r.onupgradeneeded = function () { r.result.createObjectStore('q', { autoIncrement: true }); }; r.onsuccess = function () { ok(r.result); }; r.onerror = function () { no(r.error); }; }); }
  function hold(item) { db().then(function (d) { d.transaction('q', 'readwrite').objectStore('q').add(item).onsuccess = waiting; }).catch(function () { TvAsk.say('No signal, and this phone can\'t hold the card. Try again when you have a signal.'); }); }
  function waiting() { db().then(function (d) { var r = d.transaction('q').objectStore('q').count(); r.onsuccess = function () { var w = document.getElementById('cs-wait'); w.hidden = !r.result; w.textContent = r.result + ' card' + (r.result > 1 ? 's' : '') + ' waiting for a signal'; }; }).catch(function () {}); }
  var flushing = false;
  function flush() {   // one at a time: two 'online' signals mustn't send a card twice
    if (!navigator.onLine || flushing) return; flushing = true;
    var done = function () { flushing = false; waiting(); };
    db().then(function (d) {
      var st = d.transaction('q').objectStore('q'), keys = [], vals = [];
      st.openCursor().onsuccess = function (ev) { var c = ev.target.result; if (c) { keys.push(c.key); vals.push(c.value); c.continue(); return; }
        (function next(i) { if (i >= keys.length) { done(); return; }
          send(vals[i]).then(function () { d.transaction('q', 'readwrite').objectStore('q').delete(keys[i]).onsuccess = function () { next(i + 1); }; })
            .catch(function () { d.transaction('q', 'readwrite').objectStore('q').put(vals[i], keys[i]); done(); });   // keeps a half-sent card's id
        })(0); };
    }).catch(done);
  }
  window.addEventListener('online', flush); waiting(); flush();

  // ---- checking a card: the panel ----
  var P = document.getElementById('cs-ip'), B = document.getElementById('cs-body');
  function open(id) { cur = id; P.hidden = false; B.innerHTML = '<p class="text-sm">Loading…</p>'; api('?id=' + id).then(function (d) { show(d.card); if (d.card.status === 'reading') watch(id); }).catch(function (x) { B.innerHTML = '<p>' + esc(x.message) + '</p>'; }); }
  function close() { P.hidden = true; cur = null; }
  document.getElementById('cs-close').addEventListener('click', close);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && cur) close(); });
  LIST.addEventListener('click', function (e) { var r = e.target.closest('[data-card]'); if (r) open(+r.getAttribute('data-card')); });
  function show(c) {
    var f = c.fields || {}, pics = '<div class="cs-pics">' + [1, 2].slice(0, c.sides).map(function (s) { return '<a href="/admin/api/cards.php?img=' + c.id + '&side=' + s + '" target="_blank" rel="noopener"><img src="/admin/api/cards.php?img=' + c.id + '&side=' + s + '" alt="' + (s === 1 ? 'Front' : 'Back') + ' of the card"></a>'; }).join('') + '</div>';
    document.getElementById('cs-title').textContent = f.name || 'Card ' + c.id;
    var mine = c.tz && window.TvTime && c.tz !== TvTime.zone() ? TvTime.fmt(c.at, '') : '';   // where you are now, when that's elsewhere
    var meta = '<p class="cs-hint">Scanned ' + esc(when(c)) + (c.place ? ' in ' + esc(c.place) : '') + (mine && mine !== when(c) ? ' (' + esc(mine) + ' your time)' : '') + (c.by ? ' by ' + esc(c.by) : '') + (c.where ? ' · <a href="https://www.google.com/maps?q=' + esc(c.where) + '" target="_blank" rel="noopener" style="color:#92400E;text-decoration:underline">where</a>' : '') + '</p>';
    if (c.status === 'reading') { B.innerHTML = pics + '<p><b>Reading the card…</b> a few seconds.</p>' + meta; return; }
    if (c.status === 'failed') {
      B.innerHTML = pics + '<p class="cs-msg no">' + esc(c.error || 'It couldn\'t be read.') + '</p><div class="cs-acts"><button type="button" class="hb-b go" data-cs="byhand">Fill it in by hand</button><button type="button" class="hb-b" data-cs="retry">Try again</button><button type="button" class="hb-b" data-cs="discard">Discard</button></div>' + meta; return;
    }
    if (c.status === 'saved') {
      B.innerHTML = pics + '<p class="cs-msg">' + (f._saved_as === 'listing' ? 'Saved as a listing.' : 'Saved as a lead.') + '</p><div class="cs-acts"><a class="hb-b" href="/listing/view.php?id=' + c.entity_id + '" data-peek-frame>See the listing</a><a class="hb-b" href="/admin/listing-edit.php?id=' + c.entity_id + '" data-peek-frame>Edit it</a>' + (f.email ? '<button type="button" class="hb-b go" data-cs="invite">Email the claim invite</button>' : '') + '<button type="button" class="hb-b" data-cs="link">Copy the claim link</button></div>' + meta; return;
    }
    var inp = function (k, w, t) { return '<label' + (w ? ' class="w"' : '') + '>' + esc(F[k]) + '<input class="hb-in" name="' + k + '" value="' + esc(f[k] || '') + '"' + (t ? ' type="' + t + '"' : '') + '></label>'; };
    var cats = document.getElementById('cs-cats').innerHTML.replace('value="' + (f.category_id || 0) + '"', 'value="' + (f.category_id || 0) + '" selected');
    var m = (c.matches || []).length ? '<div class="cs-m"><b>It may already be listed:</b>' + c.matches.map(function (d) { return '<div><span><a href="/listing/view.php?id=' + d.id + '" data-peek-frame>' + esc(d.name) + '</a><small>' + esc([d.city, d.why].filter(Boolean).join(' · ')) + '</small></span><button type="button" class="hb-b" data-use="' + d.id + '">It\'s this one</button></div>'; }).join('') + '</div>' : '';
    B.innerHTML = pics + m + '<form class="cs-f" id="cs-form" onsubmit="return false">' + inp('name', 1)
      + '<label class="w">Category<select class="hb-in" name="category_id"><option value="0">Choose…</option>' + cats + '</select>' + (f.business_type ? '<span class="cs-hint">The card says: ' + esc(f.business_type) + '</span>' : '') + '</label>'
      + inp('person') + inp('title') + inp('phone', 0, 'tel') + inp('mobile', 0, 'tel') + inp('email', 1, 'email') + inp('website', 1) + inp('street', 1) + inp('town') + inp('state') + inp('zip') + inp('social')
      + '<label class="w">' + esc(F.other) + '<textarea class="hb-in" name="other" rows="2">' + esc(f.other || '') + '</textarea></label>'
      + '<label>What happened<select class="hb-in" name="outcome">' + Object.keys(OUT).map(function (k) { return '<option value="' + k + '"' + (k === 'met' ? ' selected' : '') + '>' + esc(OUT[k]) + '</option>'; }).join('') + '</select></label>'
      + '<label>Follow up on<input class="hb-in" name="next_at" type="date"></label><input type="hidden" name="business_type" value="' + esc(f.business_type || '') + '"></form>'
      + '<div class="cs-acts"><button type="button" class="hb-b go" data-cs="save">Save the lead</button><button type="button" class="hb-b" data-cs="listing" title="Adds the listing only: no lead, no visit logged">Save as a listing</button><button type="button" class="hb-b" data-cs="discard">Discard</button><span class="cs-msg" id="cs-msg" role="status"></span></div>' + meta;
  }
  function form() { var o = {}, fd = new FormData(document.getElementById('cs-form')); fd.forEach(function (v, k) { o[k] = v; }); return o; }
  var lead = true;   // Save the lead, or Save as a listing (the listing only); "It's this one" and "add it" keep the choice
  function save(use, anyway) {
    var v = form(), msg = document.getElementById('cs-msg'); msg.className = 'cs-msg'; msg.textContent = 'Saving…';
    api('', { do: 'save', id: cur, fields: v, use: use || 0, anyway: !!anyway, outcome: v.outcome, next_at: v.next_at, lead: lead }).then(function (d) {
      if (d.duplicates) { msg.textContent = ''; var box = document.createElement('div'); box.className = 'cs-m';
        box.innerHTML = '<b>These look like the same business:</b>' + d.duplicates.map(function (x) { return '<div><span><a href="/listing/view.php?id=' + x.id + '" data-peek-frame>' + esc(x.name) + '</a><small>' + esc([x.city, x.why].join(' · ')) + '</small></span><button type="button" class="hb-b" data-use="' + x.id + '">It\'s this one</button></div>'; }).join('') + '<p style="margin:.5rem 0 0"><button type="button" class="hb-b go" data-cs="anyway">It\'s a different business: add it</button></p>';
        B.insertBefore(box, B.querySelector('.cs-acts')); return; }
      list(); open(cur); TvAsk.say(lead ? 'Saved: the lead is yours, with the visit logged.' : 'Saved as a listing. No lead or visit was logged.');
    }).catch(function (x) { msg.className = 'cs-msg no'; msg.textContent = x.message; });
  }
  B.addEventListener('click', function (e) {
    var u = e.target.closest('[data-use]'); if (u) { save(+u.getAttribute('data-use')); return; }
    var a = e.target.closest('[data-cs]'); if (!a) return; var w = a.getAttribute('data-cs');
    if (w === 'save' || w === 'listing') { lead = w === 'save'; save(0); } if (w === 'anyway') save(0, true);
    if (w === 'discard') { if (!TvAsk.gate(a, 'Discard this card? Its photos are deleted.', { yes: 'Discard', danger: true })) return; api('', { do: 'discard', id: cur }).then(function () { close(); list(); }); }
    if (w === 'byhand' || w === 'retry') api('', { do: w, id: cur }).then(function (d) { show(d.card); list(); if (d.card.status === 'reading') watch(cur); }).catch(function (x) { TvAsk.say(x.message); });
    if (w === 'invite' || w === 'link') {
      var id = +B.querySelector('a[href*="listing/view.php"]').getAttribute('href').split('=')[1];
      if (w === 'link') { var l = location.origin + '/claim.php?listing=' + id; (navigator.clipboard ? navigator.clipboard.writeText(l) : Promise.reject()).then(function () { TvAsk.say('Claim link copied.'); }, function () { TvAsk.ask('Claim link', l); }); return; }
      tok().then(function (c) { return fetch('/admin/api/sales.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': c }, body: JSON.stringify({ do: 'invite', id: id }) }); })
        .then(function (r) { return r.json(); }).then(function (j) { TvAsk.say(j.ok === false || j.error ? (j.error.message || 'Not sent.') : 'Claim invite emailed.'); });
    }
  });
  list();
})();
</script>
<?php
    return (string) ob_get_clean();
}
