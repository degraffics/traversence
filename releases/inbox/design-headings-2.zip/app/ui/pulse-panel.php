<?php
// app/ui/pulse-panel.php — the Pulse (decisions/0055 §5; FAQ 2026-10-09): one list of what's coming in (From, Subject,
// Received), each row opening in place (▾). One panel for every page it shows on: your Dashboard, and a business's
// Overview (/business/<id>; Jason, 2026-11-11: "The dashboard here needs the pulse"). Its rows come from
// /user/api/pulse.php for the context you're acting in, drawn by js/tv-pulse.js.
//   tv_pulse_css($wrap)   its styles (once a page; $wrap false: inside the page's own <style>)
//   tv_pulse_head($o)     the name (▾ switch account), source pills, bell, settings, + and search
//                         $o: label (the business's name, beside "Pulse"), compose (the + for a new message), layout (html)
//   tv_pulse_list($o)     "Needs you" and the list. $o: me (the name comments are written as), needs (open at first)
declare(strict_types=1);

function tv_pulse_css(bool $wrap = true): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    $css = <<<'CSS'
    /* the Pulse */
    .pu-h{display:flex;flex-wrap:wrap;align-items:baseline;gap:.3rem .9rem}
    .pu-ctx{font-size:.85rem;color:#8A7355}
    .pu-new{margin-left:auto;background:#3E2B1F;color:#FFFBF2;border:0;border-radius:.7rem;padding:.45rem .9rem;font-size:.86rem;font-weight:600;cursor:pointer}
    .pu-comp{background:#FFFBF2;border:1px solid #CBB98D;border-radius:1rem;padding:.8rem .9rem;margin-top:.8rem;display:grid;gap:.35rem}
    .pu-comp[hidden]{display:none}
    .pu-to{display:flex;align-items:center;gap:.4rem}
    .pu-who{display:inline-flex;align-items:center;gap:.3rem;background:#3E2B1F;color:#FFFBF2;border-radius:999px;padding:.2rem .65rem;font-size:.85rem;white-space:nowrap}
    .pu-who button{background:none;border:0;color:#E0C68E;cursor:pointer;font-size:1rem;line-height:1;padding:0}
    .pu-sug{display:flex;flex-wrap:wrap;gap:.3rem}
    .pu-sug button{border:1px solid #CBB98D;background:#F7EFDC;border-radius:999px;padding:.2rem .7rem;font-size:.82rem;cursor:pointer;color:#3E2B1F}
    .pu-sug button small{color:#8A7355}
    .pu-cacts{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem;margin-top:.2rem}
    .pu-needs{background:#F7EFDC;border:1px solid #CBB98D;border-radius:1rem;padding:.7rem .9rem;margin-top:.8rem}
    .pu-needs h2{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#8A7355;margin:0 0 .3rem}
    .pu-needs li{font-size:.9rem;margin-top:.35rem;list-style:none}
    .pu-needs ul{margin:0;padding:0}
    .pu-needs a{color:#B45309;text-decoration:underline}
    .pu-needs .ah-n{display:inline-block;min-width:1.4rem;text-align:center;background:#D97706;color:#fff;border-radius:999px;font-size:.72rem;font-weight:700;padding:.05rem .4rem;margin-right:.4rem}
    .pu-bar{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:.5rem;margin-top:1rem}
    .pu-chips{display:flex;flex-wrap:wrap;gap:.35rem}
    .pu-chip{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.25rem .75rem;font-size:.82rem;font-weight:600;cursor:pointer}
    .pu-chip.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
    .pu-chip small{opacity:.7;font-weight:400}
    .pu-set{position:relative;font-size:.82rem}
    .pu-set summary{cursor:pointer;list-style:none;color:#5C4632;border:1px solid #CBB98D;border-radius:.6rem;padding:.25rem .6rem;background:#FFFBF2}
    .pu-set summary::-webkit-details-marker{display:none}
    .pu-setp{position:absolute;right:0;top:calc(100% + .3rem);z-index:20;width:15rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;padding:.6rem .8rem;box-shadow:0 12px 24px -12px rgba(0,0,0,.4)}
    .pu-setp label{display:flex;align-items:center;gap:.4rem;margin-top:.25rem}
    @media (max-width:767px){.pu-setp{position:fixed;left:.75rem;right:.75rem;width:auto;max-height:70vh;overflow:auto}}   /* on a phone, inside the screen whatever the gear's place: never a sideways scroll */
    .pu-lbl{font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#8A7355;margin:.5rem 0 0}
    .pu-muted{font-size:.8rem;color:#8A7355}
    .pu-list{margin-top:.6rem}
    .pu-logo{width:2.6rem;height:2.6rem;border-radius:50%;border:2.5px solid #8A7355;color:#B8863B;display:inline-flex;align-items:center;justify-content:center;flex:none;margin-right:.2rem}
    .pu-logo svg{width:1.4rem;height:1.4rem}
    .pu-h .pf2-lay{margin-left:.4rem}
    .pu-find{margin-top:.6rem}.pu-find input{width:100%;border-radius:999px;padding:.45rem .9rem}
    /* the Pulse, as in Jason's mockup (draft 2026-10-09): name ▾ (switch account), source pills, bell, settings; + and search; then the list */
    .pv-h{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .7rem}
    .pv-logo{width:3.6rem;height:3.6rem;border-radius:50%;border:3px solid #8A7355;background:#FFFBF2;color:#B8863B;display:inline-flex;align-items:center;justify-content:center;flex:none;margin-right:-1.4rem;position:relative;z-index:1}
    .pv-logo svg{width:2.1rem;height:2.1rem;stroke-width:2.6}
    .pv-name{display:inline-flex;align-items:center;gap:.7rem;border:2px solid #B8863B;background:#FFFBF2;border-radius:.2rem;padding:.15rem .7rem .15rem 1.8rem;font:700 1.9rem/1.15 var(--tv-font-head,Georgia,serif);color:#3E2B1F;cursor:pointer}
    .pv-name small{font:600 .75rem system-ui,sans-serif;color:#8A7355;max-width:10rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .pv-name i{font-style:normal;font-size:.9rem;color:#5C4632}
    .pv-cats{display:flex;flex-wrap:wrap;gap:.35rem;flex:1;justify-content:center;min-width:0}
    .pv-cat{display:inline-flex;align-items:center;gap:.6rem;border:2px solid #B8863B;background:#FFFBF2;color:#5C4632;border-radius:999px;padding:.12rem .75rem;font:700 .8rem var(--tv-font-head,Georgia,serif);cursor:pointer}
    .pv-cat small{font-weight:400;color:#8A7355}.pv-cat.on{background:#3E2B1F;border-color:#3E2B1F;color:#FFFBF2}.pv-cat.on small{color:#E0C68E}
    .pv-cat.soon{opacity:.6}
    .pv-tools{display:flex;align-items:center;gap:.35rem;margin-left:auto}
    .pv-ic{position:relative;width:2.3rem;height:2.3rem;border:0;background:none;color:#8A7355;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;border-radius:50%;list-style:none}
    .pv-ic::-webkit-details-marker{display:none}.pv-ic svg{width:1.7rem;height:1.7rem}.pv-ic:hover,.pv-ic[aria-pressed="true"]{color:#B45309;background:#F3E7CD}
    .pv-ic b{position:absolute;top:0;right:0;min-width:1rem;height:1rem;border-radius:999px;background:#D97706;color:#fff;font-size:.62rem;display:flex;align-items:center;justify-content:center;padding:0 .2rem}
    .pv-tools .pu-set summary{border:0;background:none;padding:0}
    .pv-q{display:flex;align-items:center;gap:.6rem;margin-top:.7rem}
    .pv-plus{flex:none;width:2.3rem;height:2.3rem;border-radius:50%;border:2.5px solid #3E2B1F;background:#FFFBF2;color:#3E2B1F;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}
    .pv-plus svg{width:1.3rem;height:1.3rem;stroke-width:2.6}.pv-plus[aria-expanded="true"]{background:#8FBCA8}
    .pv-find{flex:1;display:flex;align-items:center;border:2px solid #B8863B;border-radius:999px;background:#FFFBF2;padding:0 .4rem 0 .9rem}
    .pv-find input{flex:1;min-width:0;border:0;background:none;padding:.45rem 0;font-size:.92rem;outline:none}.pv-find svg{width:1.3rem;height:1.3rem;color:#5C4632}
    .pu-needs[hidden]{display:none}
    .pl-h,.pl-r{display:grid;grid-template-columns:2rem minmax(7rem,10rem) 1.5rem minmax(0,1fr) 8.5rem auto;gap:.6rem;align-items:center;padding:.45rem .7rem}
    .pu-list.pl{background:#F7EFDC;border:1px solid #CBB98D;padding:0 .5rem .5rem}
    .pl-h{font:700 .82rem var(--tv-font-head,Georgia,serif);color:#5C4632}
    .pl-r{background:#EFE3C8;border-top:1px solid rgba(203,185,141,.7);font-size:.86rem;color:#3E2B1F}
    .pl-r.open{background:#E8D8B8}.pl-r.new .pl-sub{font-weight:700}
    .pl-av{width:1.9rem;height:1.9rem;border-radius:50%;border:1.5px solid #8A7355;background:#FFFBF2;display:flex;align-items:center;justify-content:center;font:700 .8rem var(--tv-font-head,Georgia,serif);color:#92400E}
    .pl-r.new .pl-av{box-shadow:0 0 0 2px #D97706}
    .pl-from{font-family:var(--tv-font-head,Georgia,serif);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pl-from small{display:block;font:400 .68rem system-ui,sans-serif;color:#8A7355}
    .pl-ln{width:1.4rem;height:1.4rem;border-radius:50%;background:#8FBCA8;color:#1F3B30;display:inline-flex;align-items:center;justify-content:center}.pl-ln svg{width:.8rem;height:.8rem}
    .pl-sub{font-family:var(--tv-font-head,Georgia,serif);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pl-when{font-family:var(--tv-font-head,Georgia,serif);color:#5C4632;font-size:.8rem}
    .pl-act{display:flex;gap:.1rem;justify-content:flex-end;align-items:center}
    .pl-i{width:1.75rem;height:1.75rem;border:0;background:none;color:#5C4632;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;border-radius:50%;padding:0}
    .pl-i svg{width:1.3rem;height:1.3rem}.pl-i:hover{color:#B45309;background:#F7EFDC}.pl-i[aria-pressed="true"]{color:#1F3B30;background:#8FBCA8}
    .pl-i.x svg{width:.9rem;height:.9rem;transition:none}.pl-r.open .pl-i.x svg{transform:rotate(180deg)}
    .pl-note{grid-column:1/-1;font-size:.78rem;color:#92400E;margin:-.2rem 0 0 2.6rem}.pl-note:empty{display:none}
    .pl-body{grid-column:1/-1;margin:.2rem -.3rem -.1rem;background:#FFFBF2;border:1px solid #CBB98D;box-shadow:0 8px 18px -10px rgba(42,27,18,.45)}
    .pl-x{display:grid;grid-template-columns:1fr}.pl-x.media{grid-template-columns:minmax(0,1.1fr) minmax(0,1fr)}
    .pl-media{position:relative;display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:4px;background:#F3E4CC;padding:6px;border-right:1px solid #CBB98D}
    .pl-main{position:relative;min-height:15rem;background:#5C4632 center/cover no-repeat}
    .pl-thumbs{display:grid;grid-template-columns:1fr 1fr;gap:4px;align-content:start}
    .pl-thumbs button{aspect-ratio:4/3;border:0;padding:0;background:#CBB98D center/cover no-repeat;cursor:pointer}.pl-thumbs button.on{outline:2px solid #8FBCA8;outline-offset:-2px}
    .pl-open{position:absolute;right:.5rem;bottom:.45rem;color:#FFFBF2;filter:drop-shadow(0 1px 2px rgba(0,0,0,.6))}.pl-open svg{width:1.1rem;height:1.1rem}
    .pl-text{padding:.9rem 1rem;display:flex;flex-direction:column;gap:.7rem;min-width:0}
    .pl-text>p{font-family:var(--tv-font-head,Georgia,serif);font-size:.95rem;line-height:1.45;color:#2A1B12;margin:0;white-space:pre-line}.pl-text>p a{color:#B45309}
    .pl-msg{font-size:.78rem;color:#92400E;margin:-.3rem 0 0}.pl-msg:empty{display:none}
    /* a row's icon that can't act on it: greyed, its title says why (decisions/0172); a conversation opened in place */
    .pl-i[aria-disabled="true"]{opacity:.4;cursor:not-allowed}.pl-i[aria-disabled="true"]:hover{background:none;color:#5C4632}
    .pl-more{display:none}
    .pl-conv{padding:.7rem .9rem;display:grid;gap:.5rem}
    .pl-msgs{display:flex;flex-direction:column;gap:.4rem;max-height:22rem;overflow-y:auto}
    .pl-m{max-width:85%;align-self:flex-start;background:#F7EFDC;border:1px solid #CBB98D;border-radius:.8rem;padding:.4rem .65rem}
    .pl-m.me{align-self:flex-end;background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.pl-m.me small{color:#E0C68E}
    .pl-m small{display:block;font-size:.7rem;color:#8A7355}.pl-m p{margin:.15rem 0 0;white-space:pre-line;overflow-wrap:anywhere;font-size:.9rem}
    .pl-reply{display:grid;gap:.35rem}.pl-reply textarea{width:100%;box-sizing:border-box;font:inherit;font-size:.9rem;border:1px solid #CBB98D;border-radius:.5rem;padding:.45rem .55rem;background:#fff}
    .pl-send,.tv-btn-link{justify-self:start;display:inline-flex;align-items:center;font:600 .82rem system-ui,sans-serif;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:.55rem;padding:.35rem .9rem;cursor:pointer;text-decoration:none;min-height:2rem}
    .pl-send:hover,.tv-btn-link:hover{background:#F7EFDC}
    .pl-alone{background:#FFFBF2;border:1px solid #CBB98D;padding:.6rem .8rem;margin-top:.8rem}
    .pl-act2{display:none}
    @media (max-width:900px){.pl-x.media{grid-template-columns:1fr}.pl-media{border-right:0;border-bottom:1px solid #CBB98D}}
    @media (max-width:767px){.pl-h{display:none}.pu-list.pl{padding:0 3px 3px}
      .pl-r{grid-template-columns:2rem minmax(0,1fr) 1.75rem;row-gap:.1rem;padding:.45rem .5rem}
      .pl-av{grid-row:1/span 3}.pl-from{grid-column:2}.pl-sub{grid-column:2;grid-row:2;white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.pl-when{grid-column:2;grid-row:3;font-size:.72rem}
      .pl-r{grid-template-columns:2rem minmax(0,1fr) auto}
      .pl-ln{display:none}.pl-act{grid-column:3;grid-row:1/span 3;align-self:start;flex-wrap:wrap;justify-content:flex-end;max-width:9rem}.pl-act .pl-i:not(.x):not(.pl-more){display:none}.pl-act .pl-more{display:inline-flex}
      .pl-act.more .pl-i:not(.x):not(.pl-more){display:inline-flex}   /* the six fold into ⋯ beside ▾ (decisions/0172) */
      .pl-act2{display:none}.pl-m{max-width:92%}
      .pl-note{margin-left:0}.pl-main{min-height:12rem}
      .pv-logo{width:2.8rem;height:2.8rem;margin-right:-1.1rem}.pv-logo svg{width:1.6rem;height:1.6rem}.pv-name{font-size:1.45rem;padding-left:1.4rem}
      .pv-cats{order:3;flex-basis:100%;justify-content:flex-start;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none}.pv-cat{flex:none}}
    .pu-it{display:flex;gap:.7rem;align-items:flex-start;padding:.6rem .75rem;border-radius:.8rem;background:#FFFBF2;border:1px solid rgba(203,185,141,.6);margin-top:.45rem;color:inherit;text-decoration:none}
    .pu-it:hover{border-color:#B8863B}
    .pu-it.new{border-left:3px solid #D97706}
    .pu-it b{font-family:var(--tv-font-head,ui-serif,Georgia,serif)}
    .pu-it small{display:block;color:#8A7355;font-size:.75rem;margin-top:.1rem}
    .pu-src{flex:0 0 auto;font-size:.62rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#8A7355;border:1px solid #EADFC4;border-radius:999px;padding:.1rem .45rem;margin-top:.15rem}
    .pu-tabs{display:flex;gap:.2rem;border-bottom:1px solid #CBB98D;margin-top:.8rem;overflow-x:auto;scrollbar-width:none}
    .pu-tab{flex:0 0 auto;padding:.4rem .85rem;font-size:.86rem;border:1px solid transparent;border-bottom:0;border-radius:.6rem .6rem 0 0;background:none;color:#5C4632;cursor:pointer}
    .pu-tab.on{background:#F7EFDC;border-color:#CBB98D;color:#3E2B1F;font-weight:600;margin-bottom:-1px}
CSS;
    return $wrap ? '<style>' . $css . '</style>' : $css;
}

function tv_pulse_head(array $o = []): string
{
    $o += ['label' => '', 'compose' => false, 'layout' => ''];
    if (!function_exists('tv_icon')) require_once __DIR__ . '/app-shell.php';
    ob_start(); ?>
        <?php $pvI = fn (string $d) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>'; ?>
        <div class="pv-h">
          <span class="pv-logo" aria-hidden="true"><?= tv_icon('pulse', '') ?></span>
          <h1 style="margin:0"><button type="button" class="pv-name" id="pv-name" data-cx-under aria-haspopup="menu" title="Switch account: personal, a business you manage, staff">Pulse<?php if ($o['label'] !== ''): ?> <small><?= htmlspecialchars($o['label']) ?></small><?php endif; ?> <i aria-hidden="true">&#9660;</i></button></h1>
          <div class="pv-cats pu-chips" id="pu-chips" data-more role="tablist" aria-label="Show"></div>
          <span class="pv-tools">
            <button type="button" class="pv-ic" id="pu-bell" aria-pressed="false" title="What needs you" aria-label="What needs you"><?= $pvI('<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>') ?><b id="pu-bell-n" hidden></b></button>
            <details class="pu-set"><summary class="pv-ic" title="Pulse settings" aria-label="Pulse settings"><?= $pvI('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>') ?></summary>
              <div class="pu-setp"><p class="pu-lbl">Show as</p>
                <label><input type="radio" name="pu-mode" value="list"> A list: from, subject, received</label>
                <label><input type="radio" name="pu-mode" value="stream"> One combined stream</label>
                <label><input type="radio" name="pu-mode" value="tabs"> Each source as its own tab</label>
                <p class="pu-lbl">Sources</p><div id="pu-srcs"></div>
                <p class="pu-muted">Kept in this browser.</p></div></details>
            <?= $o['layout'] /* the profile's layout button, on your own Dashboard */ ?>
          </span>
        </div>
        <div class="pv-q">
          <?php if ($o['compose']): ?><button type="button" class="pv-plus" id="pu-new" aria-expanded="false" title="New message" aria-label="New message"><?= $pvI('<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>') ?></button><?php endif; ?>
          <label class="pv-find"><input id="pu-q" type="search" placeholder="Search your Pulse" aria-label="Search your Pulse"><?= $pvI('<circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.8-4.8"/>') ?></label>
        </div>
<?php return (string) ob_get_clean();
}

function tv_pulse_list(array $o = []): string
{
    $o += ['me' => 'you', 'needs' => false];
    return '<div class="pu-needs" id="pu-needs" aria-live="polite"' . ($o['needs'] ? '' : ' hidden') . '><p class="pu-muted">Loading…</p></div>'
        . '<div class="pu-list" id="pu-list" data-me="' . htmlspecialchars((string) $o['me'], ENT_QUOTES) . '"></div>';
}
