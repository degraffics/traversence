<?php
// admin/listing-intake.php — Listing Intake (spec Section 31)
//
// Point the crawler at a business website, review the proposed listings it finds
// (one per physical location, organized by the 5Ws), edit, then approve into the
// directory or reject. Admin-only, checked server-side before anything renders
// (decisions/0022 §2, decisions/0029). Data comes from /api/admin/intake/*.

declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';   // same session cookie as the rest of the site
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';   // Admin → Crawler → Crawl a site (decisions/0046)
require_once __DIR__ . '/../../app/lib/crawler/SiteFetcher.php';
require_once __DIR__ . '/../../app/lib/crawler/ListingExtractor.php';
require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$rowId = (int) ($_GET['row'] ?? 0);   // one listing, opened from Review
tv_crawler_start('crawl', $rowId ? 'Edit listing' : 'Crawl a site', $pdo, $rowId
    ? 'Check and complete this listing, then approve, merge or reject it. <a class="underline text-amber-800" href="/admin/crawler-review.php">Back to Review</a>'
    : 'Point the crawler at a business website. Each physical location it finds becomes a proposed listing, organized by the 5Ws; they wait in Review until you approve them.');
?>
<meta name="tv-csrf" content="<?= tv_e($csrf) ?>">
<meta name="tv-row" content="<?= $rowId ?>">
<script src="/js/section-edit.js?v=<?= (int) @filemtime(__DIR__ . '/../js/section-edit.js') ?>"></script>
<script>var TV_RULES = <?= json_encode(IntakeStager::FIELD_RULES, JSON_UNESCAPED_UNICODE) ?>;</script>
<style>
  .li-in{width:100%;background:#FFFBF2;border:1px solid rgba(203,185,141,.8);border-radius:.6rem;padding:.5rem .65rem;font-size:.9rem;color:#3E2B1F}
  .li-in:focus{outline:2px solid #D97706;outline-offset:1px}
  .li-lbl{display:block;font-size:.7rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355;margin:.6rem 0 .2rem}
  .li-w summary{cursor:pointer;list-style:none;display:flex;align-items:center;gap:.5rem;padding:.55rem 0;font-weight:700;font-family:ui-serif,Georgia,serif}
  .li-w summary::-webkit-details-marker{display:none}
  .li-w summary::before{content:'▸';color:#B45309;transition:transform .15s}
  .li-w[open] summary::before{transform:rotate(90deg)}
  .li-w summary small{font-weight:400;font-family:ui-sans-serif,system-ui,sans-serif;color:#8A7355;font-size:.75rem}
  .li-src{font-size:.7rem;color:#8A7355;word-break:break-all;margin-top:.15rem}
  .li-help{font-size:.75rem;color:#8A7355;margin-top:.2rem}
  .mg-wrap{overflow-x:auto;margin-top:.6rem}
  table.mg{width:100%;border-collapse:collapse;font-size:.82rem;min-width:36rem}
  table.mg th,table.mg td{padding:.4rem .5rem;border-top:1px solid rgba(203,185,141,.55);vertical-align:top;text-align:left}
  table.mg thead th{font-size:.7rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355;border-top:0}
  table.mg tbody th{font-weight:600;color:#5C4632;white-space:nowrap;width:7rem}
  table.mg td.mg-on{background:#ECFDF5}
  table.mg tr.mg-same td,table.mg tr.mg-nothing td,table.mg tr.mg-kept td{color:#8A7355}
  table.mg tr.mg-same td.mg-on,table.mg tr.mg-nothing td.mg-on,table.mg tr.mg-kept td.mg-on{background:transparent}
  table.mg em{color:#B8A07A}
  .mg-seg{display:inline-flex;border:1px solid #CBB98D;border-radius:.5rem;overflow:hidden;white-space:nowrap}
  .mg-seg button{font-size:.75rem;padding:.2rem .55rem;background:#FFFBF2;border-left:1px solid #CBB98D;cursor:pointer}
  .mg-seg button:first-child{border-left:0}
  .mg-seg button.on{background:#3E2B1F;color:#FFFBF2}
  .mg-note{font-size:.72rem;color:#8A7355;white-space:nowrap}
  .mg-help{font-size:.75rem;color:#8A7355;margin-top:.4rem}
  .li-head{cursor:pointer}
  .li-head h3::before{content:'▸';color:#B45309;display:inline-block;margin-right:.4rem;transition:transform .15s;font-size:.9em}
  .li-card.open .li-head h3::before{transform:rotate(90deg)}
  .li-quick{font-size:.8rem;color:#B45309;text-decoration:underline;background:none}
  .li-fl{margin-top:.2rem}
  .li-fr{display:flex;width:100%;justify-content:space-between;align-items:center;gap:.6rem;text-align:left;background:#FFFBF2;border:1px solid rgba(203,185,141,.8);border-radius:.8rem;padding:.5rem .7rem;margin-top:.35rem;cursor:pointer}
  .li-fr:hover{background:#FFF7E6;border-color:#D97706}.li-fr small{display:block;font-size:.75rem;color:#8A7355}.li-fr.is-done{opacity:.65}
  .li-fs{flex:0 0 auto;font-size:.7rem;border-radius:999px;padding:.1rem .5rem;border:1px solid #CBB98D;background:#E3D3AC;color:#3E2B1F;white-space:nowrap}
  .li-fs.dup{background:#E0F2FE;border-color:#7DD3FC;color:#0C4A6E}.li-fs.done{background:#DCFCE7;border-color:#86EFAC;color:#14532D}
  .li-dim{position:fixed;inset:0;background:rgba(62,43,31,.45);z-index:900}
  .li-lb{position:fixed;z-index:901;left:50%;top:4vh;transform:translateX(-50%);width:min(52rem,calc(100vw - 1.5rem));max-height:92vh;display:flex;flex-direction:column;background:#EFE3C8;border:1px solid #CBB98D;border-radius:1rem;box-shadow:0 20px 50px -12px rgba(0,0,0,.5)}
  .li-lb-h{display:flex;justify-content:space-between;align-items:center;gap:.5rem;padding:.55rem .9rem;border-bottom:1px solid #CBB98D}
  .li-lb-x{font-size:1.5rem;line-height:1;color:#8A7355;background:none;padding:0 .2rem}
  .li-lb-b{overflow:auto;padding:.8rem}
</style>

<div<?= $rowId ? ' hidden' : '' ?>>   <!-- the crawl form, tabs and bulk links; hidden when editing one listing -->

<section class="bg-[#F7EFDC] border border-[#CBB98D]/70 rounded-2xl shadow-md p-4 mt-5 max-w-3xl">
  <h2 class="font-serif font-bold text-lg">Crawl a website</h2>
  <form id="li-crawl" class="mt-2" autocomplete="off">
    <label class="li-lbl" for="li-url">Website</label>
    <input id="li-url" class="li-in" type="text" inputmode="url" placeholder="shedscontainersandtanks.com" required value="<?= htmlspecialchars(mb_substr(trim((string) ($_GET['url'] ?? '')), 0, 300), ENT_QUOTES) ?>"><?php // ?url= from a visitor's suggestion in Review ?>
    <fieldset class="mt-1">
      <legend class="li-lbl">Why crawl it (audit trail)</legend>
      <div class="grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
        <label class="flex items-center gap-2"><input type="checkbox" name="li-purpose" value="create_listings" checked class="accent-amber-600 w-4 h-4"> Create listing(s)</label>
        <label class="flex items-center gap-2"><input type="checkbox" name="li-purpose" value="content_topics" class="accent-amber-600 w-4 h-4"> Content topics</label>
        <label class="flex items-center gap-2"><input type="checkbox" name="li-purpose" value="guide_create" class="accent-amber-600 w-4 h-4"> Guide create</label>
        <label class="flex items-center gap-2"><input type="checkbox" name="li-purpose" value="other" id="li-other-cb" class="accent-amber-600 w-4 h-4"> Other</label>
      </div>
      <input id="li-other" class="li-in mt-2" type="text" maxlength="500" placeholder="Other reason" hidden>
    </fieldset>
    <div class="flex flex-wrap items-end gap-3 mt-3">
      <div>
        <label class="li-lbl" for="li-max" style="margin-top:0">Page limit</label>
        <select id="li-max" class="li-in" style="width:auto"><option>10</option><option selected>20</option><option>30</option><option>40</option></select>
      </div>
      <button id="li-go" type="submit" class="bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl px-5 py-2.5 disabled:opacity-60">Crawl</button>
    </div>
  </form>
  <div id="li-crawl-status" class="text-sm mt-3" aria-live="polite"></div>
</section>

<div class="mt-6 flex gap-2 flex-wrap" role="tablist" id="li-tabs">
  <button data-st="staged" class="li-tab">To review</button>
  <button data-st="published" class="li-tab">Published</button>
  <button data-st="merged" class="li-tab">Merged</button>
  <button data-st="rejected" class="li-tab">Rejected</button>
</div>
<p class="mt-3 text-sm" id="li-all"><button type="button" class="li-quick" data-all="1">Expand all</button> · <button type="button" class="li-quick" data-all="0">Collapse all</button></p>
</div>
<div id="li-list" class="mt-2 space-y-4 max-w-3xl" aria-live="polite"></div>

<script>
(function () {
  'use strict';
  var CSRF = document.querySelector('meta[name="tv-csrf"]').content;
  var API = '/api/admin/intake/';
  var ROW = +(document.querySelector('meta[name="tv-row"]') || {}).content || 0;   // one listing, from Review
  var state = { status: 'staged', categories: null };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function lines(a) { return (a || []).join('\n'); }
  // After one is done: back to Review as it was (filters, sort), and the next one in that list (crawler-review.php).
  function afterLinks() {
    var back = '/admin/crawler-review.php', next = null;
    try {
      back = sessionStorage.getItem('tv_rv_back') || back;
      var q = JSON.parse(sessionStorage.getItem('tv_rv_queue') || '[]'), i = q.map(function (x) { return x[0]; }).indexOf(ROW);
      if (i >= 0 && q[i + 1]) next = q[i + 1];
    } catch (x) {}
    return '<p class="mt-2 text-sm flex flex-wrap gap-3 items-center">'
      + (next ? '<a class="inline-block bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl px-4 py-2" href="/admin/listing-intake.php?row=' + (+next[0]) + '">Next: ' + esc(next[1]) + (next[2] === 'merge' ? ' (possible duplicate)' : '') + ' &rarr;</a>' : '')
      + '<a class="underline text-amber-800" href="' + esc(back) + '">Back to Review</a></p>';
  }
  function isLink(x) { return /^https?:\/\/\S+$/i.test(String(x || '').trim()); }
  function api(path, body) {
    var opt = { credentials: 'include', headers: { 'Accept': 'application/json' } };
    if (body) { opt.method = 'POST'; opt.headers['Content-Type'] = 'application/json'; opt.headers['X-CSRF-Token'] = CSRF; opt.body = JSON.stringify(window.tvSafe ? tvSafe(body) : body); }
    return fetch(API + path, opt).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok || d.success === false) { var e = new Error(d.error || d.message || ('HTTP ' + r.status)); e.data = d; throw e; }
        return d;
      });
    });
  }

  // ---------- tabs ----------
  function paintTabs() {
    document.querySelectorAll('.li-tab').forEach(function (b) {
      var on = b.dataset.st === state.status;
      b.setAttribute('aria-selected', on);
      b.className = 'li-tab rounded-full px-4 py-1.5 text-sm border ' + (on ? 'bg-[#3E2B1F] text-[#EFE3C8] border-[#3E2B1F]' : 'bg-[#F7EFDC] border-[#CBB98D] text-[#3E2B1F]');
    });
  }
  document.getElementById('li-tabs').addEventListener('click', function (e) {
    var b = e.target.closest('.li-tab'); if (!b) return;
    state.status = b.dataset.st; paintTabs(); load();
  });

  // ---------- crawl ----------
  var PURPOSE_LABELS = { create_listings: 'Create listing(s)', content_topics: 'Content topics', guide_create: 'Guide create', other: 'Other' };
  document.getElementById('li-other-cb').addEventListener('change', function () {
    var o = document.getElementById('li-other'); o.hidden = !this.checked; if (this.checked) o.focus();
  });
  function purposes() {
    return Array.prototype.map.call(document.querySelectorAll('input[name="li-purpose"]:checked'), function (c) { return c.value; });
  }
  document.getElementById('li-crawl').addEventListener('submit', function (e) {
    e.preventDefault();
    var go = document.getElementById('li-go'), out = document.getElementById('li-crawl-status');
    var ps = purposes();
    if (!ps.length) { out.innerHTML = '<p class="text-red-800">Check at least one reason.</p>'; return; }
    go.disabled = true; go.textContent = 'Crawling…';
    out.innerHTML = '<span class="text-[#5C4632]">Reading the site politely, one page at a time. This can take up to a minute.</span>';
    api('crawl.php', { url: document.getElementById('li-url').value, purposes: ps, other_note: document.getElementById('li-other').value, max_pages: +document.getElementById('li-max').value })
      .then(function (d) {
        if (d.saved_only) { out.innerHTML = '<p class="text-[#5C4632]">' + esc(d.message) + '</p>'; return; }
        var n = d.staged.length;
        out.innerHTML = '<p class="text-green-800 font-semibold">Read ' + d.pages + ' page' + (d.pages === 1 ? '' : 's') + ', found ' + d.found + ' location' + (d.found === 1 ? '' : 's') + '. '
          + n + ' new to review' + (d.auto_imported && d.auto_imported.length ? ', ' + d.auto_imported.length + ' published automatically (see Crawler → Published)' : '')
          + (d.already_known ? ', ' + d.already_known + ' already seen before' : '') + '.</p>' + registerHtml(d.register) + '<div class="li-found"></div>' + logHtml(d.log);
        state.status = 'staged'; paintTabs(); load();
        showFound(d, out.querySelector('.li-found'));
      })
      .catch(function (err) { out.innerHTML = '<p class="text-red-800">' + esc(err.message) + '</p>' + logHtml(err.data && err.data.log); })
      .finally(function () { go.disabled = false; go.textContent = 'Crawl'; });
  });
  // what the crawl left for the crawler (review W3): the page log, the source register and the place store
  function registerHtml(r) {
    if (!r || !r.pages_logged) return '';
    var rule = { cite: 'cite only', evidence: 'used as evidence only', pointer: 'a pointer only', ignore: 'ignore this site' }[r.use_rule];
    return '<p data-tv-status="info" data-tv-label="For the crawler:">' + r.pages_logged + ' page' + (r.pages_logged === 1 ? '' : 's') + ' in its page log, the site on the source register'
      + (rule ? ', and its places not kept: the register says ' + esc(rule) : (r.places_kept ? ', ' + r.places_kept + ' place' + (r.places_kept === 1 ? '' : 's') + ' in the place store, so search finds them' : '')) + '.</p>';
  }
  // ---------- what this crawl found: a list to work on now, each opening in a lightbox ----------
  var found = [], foundDone = {}, foundBox = null;
  function showFound(d, box) {
    foundBox = box; found = []; foundDone = {};
    var unread = d.unread_locations || [];
    var unreadHtml = unread.length ? '<p class="text-xs text-amber-900 mt-2">No address could be read on ' + unread.length + ' location page' + (unread.length === 1 ? '' : 's') + ': '
      + unread.map(function (u) { return '<a class="underline" href="' + esc(u) + '" target="_blank" rel="noopener">' + esc(u.replace(/^https?:\/\/[^/]+/, '') || u) + '</a>'; }).join(', ')
      + '. Open them to check; a location there may need adding by hand.</p>' : '';
    if (!d.staged.length) { box.innerHTML = unreadHtml; return; }
    box.innerHTML = '<p class="text-xs text-[#8A7355] mt-2">Loading what it found…</p>';
    api('candidates.php?status=staged&ids=' + d.staged.join(',')).then(function (r) {
      found = r.rows; paintFound(); box.insertAdjacentHTML('beforeend', unreadHtml);
    }).catch(function (x) { box.innerHTML = '<p class="text-red-800 text-xs">' + esc(x.message) + '</p>' + unreadHtml; });
  }
  function paintFound() {
    var list = foundBox.querySelector('.li-fl');
    if (!list) { list = document.createElement('div'); list.className = 'li-fl'; foundBox.innerHTML = ''; foundBox.appendChild(list); }
    list.innerHTML = '<p class="li-lbl" style="margin-top:.6rem">Found in this crawl · tap one to work on it</p>' + found.map(function (r) {
      var p = r.payload || {}, w = p.where || {}, m = p.match || {}, done = foundDone[r.id];
      var tag = done ? '<span class="li-fs done">' + esc(done) + '</span>'
        : m.exact ? '<span class="li-fs dup">Already listed #' + (+m.exact.id) + '</span>' : (m.possible && m.possible.length ? '<span class="li-fs dup">May exist</span>' : '<span class="li-fs">New</span>');
      return '<button type="button" class="li-fr' + (done ? ' is-done' : '') + '" data-found="' + r.id + '"><span><b>' + esc(p.name || 'Unnamed') + '</b><small>'
        + esc([w.address, w.city].filter(Boolean).join(', ') || 'No street address') + '</small></span>' + tag + '</button>';
    }).join('');
    list.onclick = function (e) { var b = e.target.closest('[data-found]'); if (b) openFound(+b.getAttribute('data-found')); };
  }
  function openFound(id) {
    closeLightbox();
    var r = found.filter(function (x) { return +x.id === id; })[0]; if (!r) return;
    var dim = document.createElement('div'); dim.className = 'li-dim';
    var lb = document.createElement('div'); lb.className = 'li-lb'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true');
    lb.innerHTML = '<div class="li-lb-h"><span class="text-xs text-[#8A7355]">' + (found.indexOf(r) + 1) + ' of ' + found.length + ' found</span>'
      + '<span class="flex gap-2"><button type="button" class="li-quick" data-lb-nav="-1">&larr; Previous</button><button type="button" class="li-quick" data-lb-nav="1">Next &rarr;</button>'
      + '<button type="button" class="li-lb-x" aria-label="Close">&times;</button></span></div><div class="li-lb-b"></div>';
    document.body.appendChild(dim); document.body.appendChild(lb);
    document.documentElement.style.overflow = 'hidden';
    // The same card as in the list below (moved here, then put back), so its fields and ids stay unique.
    var card = document.querySelector('#li-list .li-card[data-row="' + id + '"]'), ph = null;
    if (card) { ph = document.createComment('lb'); card.parentNode.replaceChild(ph, card); }
    else card = reviewCard(r);
    lb.querySelector('.li-lb-b').appendChild(card);
    if (window.tvSections) tvSections(lb, { sections: 'details.li-w', head: 'summary', check: window.tvFieldCheck });
    if (card.setOpen) card.setOpen(true);
    card._onDone = function (d) {
      foundDone[id] = d.applied ? 'Merged into #' + d.entity_id : d.entity_id ? 'Published #' + d.entity_id : 'Rejected';
      paintFound();
      var nx = nextPending(id);
      if (nx) card.insertAdjacentHTML('beforeend', '<p class="mt-3"><button type="button" class="bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl px-4 py-2" data-lb-go="' + nx.id + '">Next: ' + esc(nx.payload.name || 'Unnamed') + ' &rarr;</button></p>');
      else card.insertAdjacentHTML('beforeend', '<p class="mt-3 text-sm text-green-800 font-semibold">That\'s everything from this crawl.</p>');
    };
    lb._restore = function () { if (ph && ph.parentNode) ph.parentNode.replaceChild(card, ph); };
    lb.addEventListener('click', function (e) {
      if (e.target.closest('.li-lb-x')) { closeLightbox(); return; }
      var g = e.target.closest('[data-lb-go]'); if (g) { openFound(+g.getAttribute('data-lb-go')); return; }
      var n = e.target.closest('[data-lb-nav]');
      if (n) { var i = found.indexOf(r) + (+n.getAttribute('data-lb-nav')); if (found[i]) openFound(+found[i].id); }
    });
    dim.addEventListener('click', closeLightbox);
  }
  function nextPending(id) {
    var i = found.map(function (x) { return +x.id; }).indexOf(id);
    for (var j = 1; j <= found.length; j++) { var x = found[(i + j) % found.length]; if (!foundDone[x.id]) return x; }
    return null;
  }
  function closeLightbox() {
    var lb = document.querySelector('.li-lb'); if (!lb) return;
    if (lb._restore) lb._restore();
    lb.remove(); var d = document.querySelector('.li-dim'); if (d) d.remove();
    document.documentElement.style.overflow = '';
    if (Object.keys(foundDone).length) load();   // the list below catches up with what was done
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeLightbox(); });

  function logHtml(log) {
    if (!log || !log.length) return '';
    return '<details class="mt-2 text-xs text-[#5C4632]"><summary class="cursor-pointer">Crawl log (' + log.length + ')</summary><ul class="mt-1 space-y-0.5">'
      + log.map(function (l) { return '<li class="break-all">' + esc(l) + '</li>'; }).join('') + '</ul></details>';
  }

  // ---------- list ----------
  function load() {
    var list = document.getElementById('li-list');
    list.innerHTML = '<p class="text-sm text-[#8A7355]">Loading…</p>';
    api('candidates.php?status=' + state.status + (ROW ? '&id=' + ROW : '') + (state.categories ? '' : '&categories=1')).then(function (d) {
      if (d.categories) state.categories = d.categories;
      if (d.csrf) CSRF = d.csrf;
      if (!d.rows.length) {
        list.innerHTML = '<p class="text-sm text-[#5C4632] bg-[#F7EFDC] border border-[#CBB98D]/60 rounded-2xl p-4">'
          + (ROW ? 'This listing has already been handled.' + afterLinks()
             : state.status === 'staged' ? 'Nothing waiting for review. Crawl a website above to find listings.' : 'Nothing here yet.') + '</p>';
        return;
      }
      list.innerHTML = '';
      var lastSource = null;
      d.rows.forEach(function (r) {
        if (r.source_id !== lastSource) {
          lastSource = r.source_id;
          var h = document.createElement('p');
          h.className = 'text-xs text-[#8A7355] pt-2';
          h.innerHTML = 'From <span class="font-semibold text-[#5C4632]">' + esc(r.source_start_url || r.source_url) + '</span>' + (r.source_purposes ? ' · ' + esc(r.source_purposes.split(',').map(function (k) { return PURPOSE_LABELS[k] || k; }).join(', ')) : '') + (r.source_rationale ? ' (' + esc(r.source_rationale) + ')' : '');
          list.appendChild(h);
        }
        list.appendChild(state.status === 'staged' || state.status === 'quarantined' ? reviewCard(r) : doneCard(r));
      });
      if (ROW) list.querySelectorAll('.li-card').forEach(function (c) { if (c.setOpen) c.setOpen(true); });
      // Each 5W section reads as plain text; its pencil opens the inputs.
      if (window.tvSections) tvSections(list, { sections: 'details.li-w', head: 'summary', check: window.tvFieldCheck });
    }).catch(function (err) { list.innerHTML = '<p class="text-red-800 text-sm">' + esc(err.message) + '</p>'; });
  }

  function confPill(n) {
    var c = n >= 75 ? 'bg-green-100 text-green-900 border-green-300' : n >= 50 ? 'bg-amber-100 text-amber-900 border-amber-300' : 'bg-red-100 text-red-900 border-red-300';
    return '<span class="text-xs border rounded-full px-2 py-0.5 ' + c + '" title="How complete the crawled data is (0–100). Not a trust score.">' + n + '% complete</span>';
  }

  function doneCard(r) {
    var p = (r.status === 'merged' ? r.payload : r.reviewed || r.payload) || {}, w = p.where || p;
    var el = document.createElement('article');
    el.className = 'bg-[#F7EFDC] border border-[#CBB98D]/70 rounded-2xl p-4';
    el.innerHTML = '<div class="flex flex-wrap justify-between gap-2"><h3 class="font-serif font-bold">' + esc(p.name) + '</h3>'
      + (r.entity_id ? '<span class="text-xs text-green-800">' + (r.status === 'merged' ? 'Merged into #' : 'Entity #') + r.entity_id
          + ' · <a class="underline text-amber-800" href="/listing/view.php?id=' + r.entity_id + '" target="_blank">View</a> · <a class="underline text-amber-800" href="/admin/listing-edit.php?id=' + r.entity_id + '">Edit</a></span>' : '') + '</div>'
      + '<p class="text-sm text-[#5C4632]">' + esc([w.address, w.city, w.state, w.zip].filter(Boolean).join(', ')) + '</p>'
      + '<p class="text-xs text-[#8A7355] mt-1">' + esc(r.status) + ' ' + esc(r.reviewed_at || '') + (r.review_note ? ' · “' + esc(r.review_note) + '”' : '') + '</p>';
    return el;
  }

  function field(id, label, value, opts) {
    opts = opts || {};
    var input = opts.area
      ? '<textarea id="' + id + '" class="li-in" rows="' + (opts.rows || 3) + '">' + esc(value) + '</textarea>'
      : '<input id="' + id + '" class="li-in" type="' + (opts.type || 'text') + '" value="' + esc(value) + '"' + (opts.attrs || '') + '>';
    var src = opts.src && opts.src.length ? '<p class="li-src">from ' + opts.src.map(esc).join(' · ') + '</p>' : '';
    var r = opts.rule && window.TV_RULES ? TV_RULES[opts.rule] : null;
    var help = r ? '<p class="li-help">' + esc(r.help) + (r.items ? ' Up to ' + r.items + ' lines, ' + r.each + ' characters each.' : (r.max ? ' Up to ' + r.max + ' characters.' : '')) + '</p>' : '';
    return '<div class="' + (opts.cls || '') + '"><label class="li-lbl" for="' + id + '">' + esc(label) + (opts.hint ? ' <span class="normal-case tracking-normal">(' + esc(opts.hint) + ')</span>' : '') + '</label>' + input + help + src + '</div>';
  }

  function categorySelect(id, sugg) {
    var h = '<select id="' + id + '" class="li-in"><option value="">Choose a category…</option>';
    if (sugg && sugg.length) {
      h += '<optgroup label="Suggested">' + sugg.map(function (s, i) { return '<option value="' + s.id + '"' + (i === 0 ? ' selected' : '') + '>' + esc(s.name) + ' — ' + esc(s.group) + '</option>'; }).join('') + '</optgroup>';
    }
    var g = null;
    (state.categories || []).forEach(function (c) {
      if (c.group !== g) { if (g !== null) h += '</optgroup>'; g = c.group; h += '<optgroup label="' + esc(g) + '">'; }
      h += '<option value="' + c.id + '">' + esc(c.name) + '</option>';
    });
    return h + (g !== null ? '</optgroup>' : '') + '</select>';
  }

  function reviewCard(r) {
    var p = r.payload, k = 'c' + r.id + '-', s = p.sources || {}, geo = p.geo || {}, m = p.match || {};
    var el = document.createElement('article');
    el.className = 'li-card bg-[#F7EFDC] border border-[#CBB98D]/70 rounded-2xl shadow-md p-4';
    el.setAttribute('data-row', r.id);
    var badge = m.exact ? '<span class="text-xs rounded-full px-2 py-0.5 bg-sky-100 text-sky-900 border border-sky-300">Already listed #' + m.exact.id + '</span>'
                        : (m.possible && m.possible.length ? '<span class="text-xs rounded-full px-2 py-0.5 bg-sky-50 text-sky-900 border border-sky-200">May exist</span>'
                        : '<span class="text-xs rounded-full px-2 py-0.5 bg-[#E3D3AC] text-[#3E2B1F] border border-[#CBB98D]">New listing</span>');
    var flags = (p.flags || []).map(function (f) { return '<li>' + esc(f.message) + '</li>'; }).join('');
    // Where this data goes: a new listing, or merged into one that already exists
    var targets = [];
    if (m.exact) targets.push({ id: m.exact.id, name: m.exact.name, status: m.exact.status, why: 'same name + address' });
    (m.possible || []).forEach(function (d) { targets.push(d); });
    var radio = function (val, label, checked) {
      return '<label class="flex items-start gap-2 py-1"><input type="radio" name="' + k + 'target" value="' + val + '"' + (checked ? ' checked' : '') + ' class="accent-amber-600 mt-1 w-4 h-4"><span>' + label + '</span></label>';
    };
    var targetHtml = '<fieldset class="mt-3 text-sm bg-[#FFFBF2] border border-[#CBB98D]/70 rounded-xl p-3"><legend class="px-1 font-semibold">Save to</legend>'
      + radio('new', 'A new listing', !m.exact)
      + targets.map(function (d, i) {
          return radio(d.id, 'Existing listing #' + d.id + ' ' + esc(d.name) + ' <span class="text-[#8A7355]">(' + esc(d.status) + ' · ' + esc(d.why) + ')</span>', !!m.exact && i === 0);
        }).join('')
      + '<label class="flex items-center gap-2 py-1"><input type="radio" name="' + k + 'target" value="other" class="accent-amber-600 w-4 h-4"><span>Another listing #</span>'
      + '<input id="' + k + 'otherid" class="li-in" style="width:7rem" inputmode="numeric" placeholder="id"></label>'
      + '<div data-existing class="mt-2"></div></fieldset>';
    var where = p.where || {}, act = p.actions || {};

    var catGuess = (p.category_suggestions && p.category_suggestions[0]) ? p.category_suggestions[0].name : '';
    el.innerHTML =
      // Collapsed by default: the header shows enough to decide, and a quick Reject for the obvious ones.
      '<div class="li-head flex flex-wrap items-start justify-between gap-2" data-toggle>'
      + '<div><h3 class="font-serif font-bold text-lg leading-tight">' + esc(p.name) + '</h3>'
      + '<p class="text-sm text-[#5C4632]">' + esc([where.address, where.city, where.state].filter(Boolean).join(', ') || 'No address found')
      + (p.location_count > 1 ? (p.from_list ? ' · entry ' + p.location_index + ' of ' + p.location_count + ' in a list' : ' · location ' + p.location_index + ' of ' + p.location_count) : '')
      + (catGuess ? ' · ' + esc(catGuess) : '') + '</p></div>'
      + '<div class="flex gap-1.5 flex-wrap items-center">' + badge + confPill(r.confidence_score)
      // every line can be decided where it is (Jason, 2026-10-14): Accept as found, Edit (opens it), or Reject
      + '<button type="button" data-act="approve" class="li-quick ml-1" title="Publish it as found (or merge, as chosen below)">Accept</button>'
      + '<button type="button" data-edit class="li-quick ml-1">Edit</button>'
      + '<button type="button" data-act="reject" class="li-quick ml-1">Reject</button></div></div>'
      + '<p class="text-sm" data-msg aria-live="polite"></p>'
      + '<div data-body hidden>'
      + (flags ? '<ul class="mt-3 text-sm bg-amber-50 border border-amber-300/70 rounded-xl p-3 space-y-1 list-disc pl-6 text-amber-950">' + flags + '</ul>' : '')
      + targetHtml

      + '<details class="li-w mt-2" open><summary>What <small>name, category, offerings</small></summary>'
      + field(k + 'name', 'Business name', p.name, { src: s.name })
      + '<div data-cmp="name"></div>'
      + '<label class="li-lbl" for="' + k + 'cat">Category</label>' + categorySelect(k + 'cat', p.category_suggestions)
      + '<div data-cmp="category_id"></div>'
      + field(k + 'offerings', 'Offerings', lines(p.what && p.what.offerings), { area: true, rows: 5, rule: 'offerings' })
      + '<div data-cmp="offerings"></div>'
      + field(k + 'desc', 'Description', p.what && p.what.description, { area: true, rows: 4, src: s.description, rule: 'description' })
      + '<div data-cmp="description"></div>'
      + '</details>'

      + '<details class="li-w" open><summary>Where <small>address, map pin, service area</small></summary>'
      + field(k + 'addr', 'Street address', where.address, { src: s.address })
      + '<div data-cmp="address"></div>'
      + '<div class="grid grid-cols-6 gap-2">'
      + field(k + 'city', 'City', where.city, { cls: 'col-span-3' })
      + field(k + 'state', 'State', where.state, { cls: 'col-span-1', attrs: ' maxlength="2"' })
      + field(k + 'zip', 'ZIP', where.zip, { cls: 'col-span-2', attrs: ' inputmode="numeric" maxlength="5"' })
      + field(k + 'lat', 'Latitude', geo.latitude, { cls: 'col-span-3', attrs: ' inputmode="decimal"' })
      + field(k + 'lon', 'Longitude', geo.longitude, { cls: 'col-span-3', attrs: ' inputmode="decimal"' })
      + '</div>'
      + '<div data-cmp="city"></div><div data-cmp="state"></div><div data-cmp="zip"></div><div data-cmp="pin"></div>'
      + '<p class="li-src">' + (geo.resolved ? 'Pin from the ZIP centroid. Replace it with the real spot if you know it.' : 'No pin yet.') + '</p>'
      + '<div class="mt-2 text-sm bg-[#FFFBF2] border border-[#CBB98D]/70 rounded-xl p-3">'
      + '<div class="flex flex-wrap items-center justify-between gap-2"><p data-cluster-line>' + (geo.cluster
          ? 'Cluster: <span class="font-semibold">' + esc(geo.cluster.name) + '</span>'
          : '<span class="text-amber-900">No cluster covers this ZIP. Approving would add it to a nearby cluster or auto-seed a new one.</span>') + '</p>'
      + '<button type="button" data-cluster-open class="text-xs font-semibold rounded-lg px-3 py-1.5 bg-[#E3D3AC] hover:bg-[#CBB98D]">Manage cluster</button></div>'
      + '<div data-cluster-panel data-no-read hidden class="mt-2"></div></div>'
      + field(k + 'area', 'Service area', lines(where.service_area), { area: true, rows: 3, rule: 'service_area' })
      + '<div data-cmp="service_area"></div>'
      + (where.location_page ? '<p class="li-src">Location page: ' + esc(where.location_page) + '</p>' : '')
      + '</details>'

      + '<details class="li-w"' + ((p.when && p.when.hours && p.when.hours.length) ? '' : ' open') + '><summary>When <small>hours</small></summary>'
      + field(k + 'hours', 'Hours', lines(p.when && p.when.hours), { area: true, rows: 3, rule: 'hours' })
      + '<div data-cmp="hours"></div>'
      + '</details>'

      + '<details class="li-w"><summary>Who <small>audience it serves</small></summary>'
      + field(k + 'aud', 'Audience', lines(p.who && p.who.audience), { area: true, rows: 3, rule: 'audience' })
      + '<div data-cmp="audience"></div>'
      + '</details>'

      + '<details class="li-w"><summary>Why <small>what sets it apart</small></summary>'
      + field(k + 'why', 'Highlights', lines(p.why && p.why.highlights), { area: true, rows: 4, rule: 'highlights' })
      + '<div data-cmp="highlights"></div>'
      + '</details>'

      + '<details class="li-w" open><summary>Actions <small>how people reach them</small></summary>'
      + '<div class="grid grid-cols-1 sm:grid-cols-2 gap-x-3">'
      + field(k + 'phone', 'Phone', act.phone, { type: 'tel', src: s.phone })
      + field(k + 'email', 'Email', isLink(act.email) ? '' : act.email, { type: 'text', src: s.email })
      + field(k + 'web', 'Website', act.website, { type: 'url' })
      + field(k + 'wa', 'WhatsApp', act.whatsapp, { type: 'tel' })
      + field(k + 'contact', 'Contact or booking page', act.contact_url || (isLink(act.email) ? act.email : ''), { type: 'url', hint: 'a contact form or booking link, when there\'s no public email' })
      + '</div>'
      + '<div data-cmp="phone"></div><div data-cmp="email"></div><div data-cmp="website"></div><div data-cmp="whatsapp"></div><div data-cmp="contact_url"></div>'
      + field(k + 'social', 'Social links', lines(act.social), { area: true, rows: 2, hint: 'one per line' })
      + '<div data-cmp="social"></div>'
      + '</details>'

      + '<div class="flex flex-wrap gap-2 mt-4 items-center">'
      + '<button type="button" data-act="approve" class="bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl px-5 py-2.5 disabled:opacity-60">Approve & publish</button>'
      + '<button type="button" data-act="reject" class="bg-[#E3D3AC] hover:bg-[#CBB98D] text-[#3E2B1F] font-semibold rounded-xl px-5 py-2.5 disabled:opacity-60">Reject</button>'
      + '</div></div>';
    function setOpen(open) { el.querySelector('[data-body]').hidden = !open; el.classList.toggle('open', open); }
    el.setOpen = setOpen;
    el.querySelector('[data-edit]').addEventListener('click', function () { setOpen(el.querySelector('[data-body]').hidden); });
    el.querySelector('[data-toggle]').addEventListener('click', function (e) {
      if (e.target.closest('button, a, input, select')) return;
      setOpen(el.querySelector('[data-body]').hidden);
    });

    function v(id) { var n = document.getElementById(k + id); return n ? n.value.trim() : ''; }
    function arr(id) { return v(id).split('\n').map(function (x) { return x.trim(); }).filter(Boolean); }
    var msg = el.querySelector('[data-msg]');
    var approveBtn = el.querySelector('[data-body] button[data-act=approve]');
    // the line's own Accept does what the card's main button does; when that can't go yet (a listing # to choose), it opens the card
    el.querySelector('.li-head button[data-act=approve]').addEventListener('click', function (e) {
      if (approveBtn && approveBtn.disabled) { e.stopImmediatePropagation(); setOpen(true); approveBtn.scrollIntoView({ block: 'center' }); }
    }, true);
    var mergeInto = null;   // the existing listing (from existing.php) while in merge mode

    function currentTarget() {
      var c = el.querySelector('input[name="' + k + 'target"]:checked');
      if (!c || c.value === 'new') return null;
      if (c.value === 'other') { var n = parseInt(v('otherid'), 10); return n > 0 ? n : null; }
      return parseInt(c.value, 10);
    }
    function setTarget() {
      var id = currentTarget(), box = el.querySelector('[data-existing]');
      el.querySelectorAll('[data-cmp]').forEach(function (d) { d.innerHTML = ''; });
      mergeInto = null;
      if (!id) {
        box.innerHTML = '';
        approveBtn.textContent = 'Approve & publish';
        return;
      }
      box.innerHTML = '<p class="text-[#8A7355]">Loading listing #' + id + '…</p>';
      approveBtn.disabled = true;
      api('existing.php?entity_id=' + id).then(function (d) {
        if (currentTarget() !== id) return;           // selection changed while loading
        mergeInto = d.listing;
        box.innerHTML = existingSummary(mergeInto);
        paintComparisons(mergeInto);
        approveBtn.textContent = 'Merge into #' + id;
        approveBtn.disabled = false;
      }).catch(function (err) {
        box.innerHTML = '<p class="text-red-800">' + esc(err.message) + '</p>';
      });
    }
    el.addEventListener('change', function (e) {
      if (e.target.name === k + 'target') setTarget();
    });
    el.addEventListener('input', function (e) {
      if (e.target.id === k + 'otherid') {
        el.querySelector('input[name="' + k + 'target"][value="other"]').checked = true;
        clearTimeout(el._t); el._t = setTimeout(setTarget, 600);
      }
    });

    // field -> [kind, where the existing value lives]; mirrors IntakeStager::MERGE_FIELDS
    var MERGE = {
      name: ['core', 'name', 'Name'], category_id: ['core', 'category_name', 'Category'], zip: ['core', 'primary_zip', 'ZIP'], pin: ['core', 'pin', 'Map pin'],
      address: ['meta', 'address', 'Address'], city: ['meta', 'city', 'City'], state: ['meta', 'state', 'State'], phone: ['meta', 'phone', 'Phone'],
      description: ['meta', 'description', 'Description'], email: ['meta', 'email', 'Email'], website: ['meta', 'website', 'Website'], whatsapp: ['meta', 'whatsapp', 'WhatsApp'],
      contact_url: ['meta', 'contact_url', 'Contact or booking page'],
      hours: ['list', 'hours', 'Hours'], service_area: ['list', 'service_area', 'Service area'], offerings: ['list', 'offerings', 'Offerings'],
      audience: ['list', 'audience', 'Audience'], highlights: ['list', 'highlights', 'Highlights'], social: ['list', 'social_links', 'Social links']
    };
    var SOURCE = { owner: 'entered by the owner', user: 'entered by a user', admin: 'entered by an admin', ai_crawler: 'from a crawl' };

    function fmt(val) {
      if (val == null || val === '') return '';
      return Array.isArray(val) ? val.join(' · ') : String(val);
    }
    function existingSummary(L) {
      var people = Object.keys(L.meta).filter(function (key) {
        var x = L.meta[key]; return x.locked || (x.source && x.source !== 'ai_crawler');
      });
      return '<div class="border-t border-[#CBB98D]/60 pt-2">'
        + '<p><span class="font-semibold">#' + L.id + ' ' + esc(L.name) + '</span> · ' + esc(L.status)
        + (L.is_suppressed == 1 ? ' · <span class="text-red-800">suppressed</span>' : '')
        + (L.category_name ? ' · ' + esc(L.category_name) : ' · no category') + (L.cluster_name ? ' · ' + esc(L.cluster_name) : '') + '</p>'
        + ((L.access || []).length
            ? '<p class="font-semibold mt-2">Who manages it:</p><ul class="list-disc pl-6">'
              + L.access.map(function (a) { return '<li>' + esc(a.display_name || a.email) + ' <span class="text-[#8A7355]">(' + esc(a.email) + ') · ' + esc(a.access_level)
                  + ' since ' + esc(String(a.created_at || '').slice(0, 10)) + (a.granted_by ? ', added by ' + esc(a.granted_by) : '') + '</span></li>'; }).join('') + '</ul>'
            : (L.claimed ? '<p class="text-amber-900 mt-2">Marked claimed, but no owner or manager is on record in listing_access.</p>' : ''))
        + (L.claimed ? '<p class="text-[#5C4632] mt-1">Claimed listing: name, ZIP and pin are owner-controlled and won\'t change. Other fields can take new data unless a person entered them.</p>' : '')
        + (people.length
            ? '<p class="font-semibold mt-2">Entered by people (never overwritten):</p><ul class="list-disc pl-6">'
              + people.map(function (key) { var x = L.meta[key]; return '<li><span class="text-[#8A7355]">' + esc(key) + ':</span> ' + esc(fmt(x.value)) + ' <span class="text-[#8A7355]">(' + esc(SOURCE[x.source] || x.source) + (x.locked ? ', locked' : '') + ')</span></li>'; }).join('')
              + '</ul>'
            : '<p class="text-[#8A7355] mt-1">No owner- or user-entered data on this listing yet.</p>')
        + '</div>';
    }
    function existingValue(L, key) {
      var def = MERGE[key];
      if (def[0] === 'core') {
        if (key === 'pin') return { value: L.latitude != null ? L.latitude + ', ' + L.longitude : '', locked: L.claimed };
        return { value: L[def[1]], locked: L.claimed && !(key === 'category_id' && !L.category_id), owner: L.claimed };
      }
      var x = L.meta[def[1]];
      return x ? { value: x.value, locked: x.locked || (x.source && x.source !== 'ai_crawler'), source: x.source } : { value: '' };
    }
    // Side by side: what's listed (left) and what the crawler found (right), one choice per field.
    var FOUND = {
      name: function () { return v('name'); },
      category_id: function () { var c = document.getElementById(k + 'cat'); return c && c.value ? c.options[c.selectedIndex].text.replace(/ — .*$/, '') : ''; },
      zip: function () { return v('zip'); }, pin: function () { return v('lat') && v('lon') ? v('lat') + ', ' + v('lon') : ''; },
      address: function () { return v('addr'); }, city: function () { return v('city'); }, state: function () { return v('state'); },
      phone: function () { return v('phone'); }, description: function () { return v('desc'); },
      website: function () { return v('web'); }, whatsapp: function () { return v('wa'); },
      email: function () { return isLink(v('email')) ? '' : v('email'); },   // a link typed into Email counts as the contact page
      contact_url: function () { return v('contact') || (isLink(v('email')) ? v('email') : ''); },
      hours: function () { return arr('hours'); }, service_area: function () { return arr('area'); }, offerings: function () { return arr('offerings'); },
      audience: function () { return arr('aud'); }, highlights: function () { return arr('why'); }, social: function () { return arr('social'); }
    };
    var ABBR = { street: 'st', avenue: 'ave', road: 'rd', drive: 'dr', boulevard: 'blvd', highway: 'hwy', lane: 'ln', north: 'n', south: 's', east: 'e', west: 'w', center: 'ctr', centre: 'ctr' };
    function norm(x) {
      return fmt(x).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().split(' ').map(function (w) { return ABBR[w] || w; }).join(' ');
    }
    var picks = {};   // field -> 'keep' | 'replace' | 'append', kept across repaints
    function paintComparisons(L) {
      var box = el.querySelector('[data-existing]');
      var rows = Object.keys(MERGE).map(function (key) {
        var def = MERGE[key], ex = existingValue(L, key), isList = def[0] === 'list';
        var have = fmt(ex.value), found = FOUND[key](), got = fmt(found);
        if (!have && !got) return '';
        var state, choices = [];
        if (ex.locked) state = 'kept';
        else if (!got) state = 'nothing';
        else if (key === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(got)) state = 'bad';   // e.g. a booking URL the site labelled "email"
        else if (key === 'website' && !/^https?:\/\/\S+$/i.test(got)) state = 'bad';
        else if (norm(have) === norm(got)) state = 'same';
        else {
          state = 'choose';
          choices = isList ? [['keep', 'Keep'], ['replace', 'Use new'], ['append', 'Combine']] : [['keep', 'Keep'], ['replace', 'Use new']];
          if (!picks[key]) picks[key] = !have ? 'replace' : (isList ? 'append' : 'keep');
        }
        var pick = state === 'choose' ? picks[key] : 'keep';
        var note = { kept: ex.source && ex.source !== 'ai_crawler' ? 'kept: ' + (SOURCE[ex.source] || ex.source) : 'kept: owner-controlled', nothing: 'nothing new', same: 'same', bad: 'not valid, left out (fix it below to use it)' }[state] || '';
        return '<tr class="mg-' + state + '"><th>' + esc(def[2]) + '</th>'
          + '<td class="' + (pick === 'keep' || state !== 'choose' ? 'mg-on' : '') + '">' + (have ? esc(have) : '<em>empty</em>') + '</td>'
          + '<td class="' + (state === 'choose' && pick !== 'keep' ? 'mg-on' : '') + '">' + (got ? esc(got) : '<em>—</em>') + '</td>'
          + '<td>' + (state === 'choose'
              ? '<span class="mg-seg">' + choices.map(function (c) { return '<button type="button" data-pick="' + key + '" data-v="' + c[0] + '" class="' + (pick === c[0] ? 'on' : '') + '">' + c[1] + '</button>'; }).join('') + '</span>'
                + '<select data-choice="' + key + '" hidden><option value="' + pick + '" selected></option></select>'
              : '<span class="mg-note">' + note + '</span>') + '</td></tr>';
      }).join('');
      var t = box.querySelector('.mg-wrap');
      if (!t) { t = document.createElement('div'); t.className = 'mg-wrap'; box.appendChild(t); }
      t.innerHTML = '<table class="mg"><thead><tr><th></th><th>Already listed (#' + L.id + ')</th><th>Crawler found</th><th></th></tr></thead><tbody>' + rows + '</tbody></table>'
        + '<p class="mg-help">Only differences need a choice. Fields a person entered on the listing are always kept. Change anything on the right in the sections below; this table updates.</p>'
        + '<button type="button" class="li-quick" data-separate>Not the same place: publish it as a new listing</button>';
    }
    el.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-pick]');
      if (b) { picks[b.getAttribute('data-pick')] = b.getAttribute('data-v'); if (mergeInto) paintComparisons(mergeInto); return; }
      if (e.target.closest('button[data-separate]')) {
        el.querySelector('input[name="' + k + 'target"][value="new"]').checked = true; setTarget();
      }
    });
    el.addEventListener('input', function (e) {
      if (mergeInto && e.target.closest('.li-w')) { clearTimeout(el._mg); el._mg = setTimeout(function () { paintComparisons(mergeInto); }, 400); }
    });
    el.addEventListener('change', function (e) {
      if (mergeInto && e.target.closest('.li-w')) paintComparisons(mergeInto);
    });
    if (m.exact) setTarget();

    // ---------- inline cluster management ----------
    var cPanel = el.querySelector('[data-cluster-panel]'), cLine = el.querySelector('[data-cluster-line]');
    function hubOptions(hubs, selected) {
      return hubs.map(function (g) { return '<option value="' + g.id + '"' + (g.id === selected ? ' selected' : '') + '>' + esc(g.label) + '</option>'; }).join('');
    }
    function loadClusters() {
      var zip = v('zip');
      if (!/^\d{5}$/.test(zip)) { cPanel.hidden = false; cPanel.innerHTML = '<p class="text-red-800">Enter a 5-digit ZIP first.</p>'; return; }
      cPanel.hidden = false; cPanel.innerHTML = '<p class="text-[#8A7355]">Loading clusters…</p>';
      api('clusters.php?zip=' + zip).then(function (d) { paintClusters(d); })
        .catch(function (err) { cPanel.innerHTML = '<p class="text-red-800">' + esc(err.message) + '</p>'; });
    }
    function paintClusters(d) {
      var c = d.cluster, near = d.nearby || [];
      cLine.innerHTML = c ? 'Cluster: <span class="font-semibold">' + esc(c.name) + '</span> <span class="text-[#8A7355]">(' + esc(c.geo_hub) + ')</span>'
                          : '<span class="text-amber-900">No cluster covers ZIP ' + esc(d.zip) + ' yet.</span>';
      var h = '';
      if (c) {
        h += '<p class="text-[#5C4632]">ZIP ' + esc(d.zip) + ' is in <span class="font-semibold">' + esc(c.name) + '</span>, geo-hub ' + esc(c.geo_hub)
          + (c.needs_review ? ' <span class="text-xs rounded-full px-2 py-0.5 bg-amber-100 text-amber-900 border border-amber-300">auto-seeded, needs a name</span>' : '') + '.</p>'
          + '<label class="li-lbl">Rename cluster</label><div class="flex gap-2"><input data-c="name" class="li-in" value="' + esc(c.needs_review ? (v('city') || '') : c.name) + '">'
          + '<button type="button" data-c-act="rename" class="text-xs font-semibold rounded-lg px-3 bg-[#E3D3AC] hover:bg-[#CBB98D]">Save</button></div>'
          + '<label class="li-lbl">Geo-hub</label><div class="flex gap-2"><select data-c="hub" class="li-in">' + hubOptions(d.geo_hubs, c.geo_hub_id) + '</select>'
          + '<button type="button" data-c-act="move" class="text-xs font-semibold rounded-lg px-3 bg-[#E3D3AC] hover:bg-[#CBB98D]">Move</button></div>';
      } else {
        var nearHub = near.length ? near[0].geo_hub_id : null;
        var defHub = (d.geo_hubs.filter(function (g) { return g.slug === d.default_geo_hub; })[0] || {}).id;
        h += (d.zip_known ? '' : '<p class="text-amber-900">This ZIP isn\'t in zip_coordinates, so distances aren\'t available.</p>')
          + '<label class="li-lbl">Add ZIP ' + esc(d.zip) + ' to an existing cluster</label><div class="flex gap-2"><select data-c="attach" class="li-in">'
          + near.map(function (n) { return '<option value="' + n.id + '">' + esc(n.name) + ' · ' + esc(n.geo_hub) + (n.miles != null ? ' · ' + n.miles + ' mi' : '') + '</option>'; }).join('')
          + '</select><button type="button" data-c-act="attach" class="text-xs font-semibold rounded-lg px-3 bg-amber-600 hover:bg-amber-700 text-white"' + (near.length ? '' : ' disabled') + '>Add</button></div>'
          + '<p class="li-lbl" style="margin-top:.9rem">Or create a new cluster for it</p>'
          + '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2"><input data-c="newname" class="li-in" placeholder="Cluster name" value="' + esc(v('city')) + '">'
          + '<select data-c="newhub" class="li-in">' + hubOptions(d.geo_hubs, nearHub || defHub) + '</select></div>'
          + '<button type="button" data-c-act="create" class="mt-2 text-xs font-semibold rounded-lg px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white">Create cluster</button>';
      }
      cPanel.innerHTML = h + '<p data-c-msg class="text-xs mt-2" aria-live="polite"></p>';
      cPanel._data = d;
    }
    el.querySelector('[data-cluster-open]').addEventListener('click', function () {
      if (!cPanel.hidden && cPanel._zip === v('zip')) { cPanel.hidden = true; return; }
      cPanel._zip = v('zip'); loadClusters();
    });
    cPanel.addEventListener('click', function (e) {
      var b = e.target.closest('[data-c-act]'); if (!b) return;
      var d = cPanel._data, q = function (n) { return cPanel.querySelector('[data-c="' + n + '"]').value; }, body;
      switch (b.dataset.cAct) {
        case 'attach': body = { action: 'attach', cluster_id: +q('attach'), zip: d.zip }; break;
        case 'create': body = { action: 'create', name: q('newname'), geo_hub_id: +q('newhub'), zip: d.zip }; break;
        case 'rename': body = { action: 'rename', cluster_id: d.cluster.id, name: q('name') }; break;
        case 'move':   body = { action: 'move', cluster_id: d.cluster.id, geo_hub_id: +q('hub') }; break;
      }
      var msgEl = cPanel.querySelector('[data-c-msg]');
      b.disabled = true; msgEl.className = 'text-xs mt-2 text-[#5C4632]'; msgEl.textContent = 'Saving…';
      api('clusters.php', body).then(function () {
        // the "no cluster" warning no longer applies once the ZIP is covered
        el.querySelectorAll('ul li').forEach(function (li) { if (/No micro-cluster covers ZIP/.test(li.textContent)) li.remove(); });
        loadClusters();
      }).catch(function (err) { msgEl.className = 'text-xs mt-2 text-red-800'; msgEl.textContent = err.message; b.disabled = false; });
    });

    el.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-act]'); if (!b) return;
      var buttons = el.querySelectorAll('button[data-act]');
      var body;
      if (b.dataset.act === 'reject' && !b.dataset.note) {   // the reason, in the site's own form; then this runs again with it
        TvAsk.ask('Why reject this one? (optional)', '', { yes: 'Reject' }).then(function (note) { if (note === null) return; b.dataset.note = note || ' '; b.click(); delete b.dataset.note; });
        return;
      }
      if (b.dataset.act === 'reject') {
        body = { id: r.id, action: 'reject', note: b.dataset.note.trim() };
      } else {
        body = { id: r.id, action: mergeInto ? 'merge' : 'approve', fields: {
          name: v('name'), category_id: v('cat'), offerings: arr('offerings'), description: v('desc'),
          address: v('addr'), city: v('city'), state: v('state'), zip: v('zip'), latitude: v('lat'), longitude: v('lon'),
          service_area: arr('area'), hours: arr('hours'), audience: arr('aud'), highlights: arr('why'),
          phone: v('phone'), email: v('email'), website: v('web'), whatsapp: v('wa'), contact_url: v('contact'), social: arr('social'),
          source_url: where.location_page || (p.source && p.source.start_url) || ''
        } };
        if (mergeInto) {
          body.entity_id = mergeInto.id;
          body.choices = {};
          el.querySelectorAll('select[data-choice]').forEach(function (sel) { body.choices[sel.dataset.choice] = sel.value; });
        }
      }
      buttons.forEach(function (x) { x.disabled = true; });
      msg.className = 'text-sm text-[#5C4632]'; msg.textContent = 'Saving…';
      api('review.php', body).then(function (d) {
        if (el._clearDraft) el._clearDraft();
        if (el._onDone) setTimeout(function () { el._onDone(d); }, 0);   // after the card shows its result
        if (d.applied) {
          var sk = Object.keys(d.skipped || {});
          el.innerHTML = '<p class="text-sm text-green-800">Merged into #' + d.entity_id + ': ' + esc(d.applied.join(', ') || 'nothing changed') + '. <a class="underline text-amber-800" href="/listing/view.php?id=' + d.entity_id + '" target="_blank">View</a> · <a class="underline text-amber-800" href="/admin/listing-edit.php?id=' + d.entity_id + '">Edit</a></p>'
            + (sk.length ? '<p class="text-xs text-[#5C4632] mt-1">Left as is: ' + esc(sk.map(function (f) { return f + ' (' + d.skipped[f] + ')'; }).join(', ')) + '</p>' : '')
            + (ROW ? afterLinks() : '');
          return;
        }
        el.innerHTML = '<p class="text-sm ' + (d.entity_id ? 'text-green-800' : 'text-[#5C4632]') + '">'
          + (d.entity_id ? esc(v('name') || p.name) + ' is live as entity #' + d.entity_id + (d.action === 'updated' ? ' (existing listing updated).' : '.')
             + ' <a class="underline text-amber-800" href="/listing/view.php?id=' + d.entity_id + '" target="_blank">View</a> · <a class="underline text-amber-800" href="/admin/listing-edit.php?id=' + d.entity_id + '">Edit</a>' : 'Rejected.') + '</p>'
          + (ROW ? afterLinks() : '');
      }).catch(function (err) {
        msg.className = 'text-sm text-red-800'; msg.textContent = err.message;
        // also beside the buttons, where the admin is looking
        var near = el.querySelector('[data-msg-near]');
        if (!near) { near = document.createElement('p'); near.setAttribute('data-msg-near', ''); near.setAttribute('role', 'alert'); near.className = 'text-sm text-red-800 mt-2'; approveBtn.parentNode.after(near); }
        near.textContent = err.message;
        buttons.forEach(function (x) { x.disabled = false; });
      });
    });
    // Unsaved edits survive a reload: kept in this browser per proposed listing until it's approved, merged or rejected.
    var DK = 'tv_li_draft_' + r.id, init = {};
    var inputs = [].slice.call(el.querySelectorAll('input[id^="' + k + '"], textarea[id^="' + k + '"], select[id^="' + k + '"]'));
    inputs.forEach(function (n) { init[n.id] = n.value; });
    try {
      var dr = JSON.parse(localStorage.getItem(DK) || 'null');
      if (dr && dr.v && Object.keys(dr.v).length) {
        Object.keys(dr.v).forEach(function (id) { var n = el.querySelector('#' + CSS.escape(id)); if (n) n.value = dr.v[id]; });
        var note = document.createElement('p'); note.className = 'text-sm text-[#166534] mt-2';
        note.innerHTML = 'Restored your unsaved edits from ' + esc(String(dr.at || '').replace('T', ' ').slice(0, 16)) + '. <button type="button" class="li-quick" data-discard>Discard them</button>';
        msg.after(note);
        note.querySelector('[data-discard]').addEventListener('click', function () {
          try { localStorage.removeItem(DK); } catch (x) {}
          inputs.forEach(function (n) { n.value = init[n.id]; }); note.remove(); if (mergeInto) paintComparisons(mergeInto);
        });
      }
    } catch (x) {}
    function saveDraft() {
      var v = {}; inputs.forEach(function (n) { if (n.value !== init[n.id]) v[n.id] = n.value; });
      try { if (Object.keys(v).length) localStorage.setItem(DK, JSON.stringify({ at: new Date().toISOString(), v: v })); else localStorage.removeItem(DK); } catch (x) {}
    }
    el.addEventListener('input', function () { clearTimeout(el._dr); el._dr = setTimeout(saveDraft, 400); });
    el.addEventListener('change', saveDraft);
    el._clearDraft = function () { try { localStorage.removeItem(DK); } catch (x) {} };
    return el;
  }

  document.getElementById('li-all').addEventListener('click', function (e) {
    var b = e.target.closest('button[data-all]'); if (!b) return;
    document.querySelectorAll('#li-list .li-card').forEach(function (c) { if (c.setOpen) c.setOpen(b.dataset.all === '1'); });
  });
  paintTabs(); load();
})();
</script>
<?php tv_crawler_end();
