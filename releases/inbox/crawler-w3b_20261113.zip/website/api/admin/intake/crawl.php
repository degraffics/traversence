<?php
// POST /api/admin/intake/crawl.php  {url, purposes:[create_listings|content_topics|guide_create|other], other_note?, max_pages?}
// Crawls ONE site now (admin-triggered, bounded — spec §31's narrow exception to §12.3)
// and stages one proposed listing per physical location. Publishes nothing.

declare(strict_types=1);
require_once __DIR__ . '/_common.php';

$body = intake_require_post_csrf();
session_write_close();                 // a crawl takes a while; don't hold the session lock meanwhile
set_time_limit(150);
ignore_user_abort(true);

try {
    $url = SiteFetcher::normalizeStartUrl((string) ($body['url'] ?? ''));
} catch (InvalidArgumentException $e) {
    intake_fail($e->getMessage());
}
$purposes = array_values(array_intersect(array_keys(IntakeStager::PURPOSES), (array) ($body['purposes'] ?? [])));
if (!$purposes) intake_fail('Check at least one reason for crawling this site (it goes in the audit trail).');
$note = trim((string) ($body['other_note'] ?? ''));
if (in_array('other', $purposes, true) && mb_strlen($note) < 3) intake_fail('Describe the "Other" reason.');
$note = $note === '' ? null : mb_substr($note, 0, 500);
$maxPages = max(1, min(40, (int) ($body['max_pages'] ?? 20)));

$pdo = Database::connection();

// One crawl of a given site per minute (a double-tap shouldn't crawl twice).
$recent = $pdo->prepare('SELECT id FROM ' . Database::t('crawler_sources') . ' WHERE domain = :d AND last_crawled_at > (NOW() - INTERVAL 60 SECOND) LIMIT 1');
$recent->execute(['d' => SiteFetcher::siteKey((string) parse_url($url, PHP_URL_HOST))]);
if ($recent->fetchColumn() !== false) intake_fail('This site was just crawled. Wait a minute before crawling it again.', 429);

$sourceId = IntakeStager::createSource($pdo, $url, $purposes, $note, (int) $INTAKE_ADMIN['id']);

// Only listing creation is built. Other purposes are recorded on the source so the content-topic
// and guide pipelines (§21 / §30) can pick it up later; crawling now would fetch pages for nothing.
if (!in_array('create_listings', $purposes, true)) {
    intake_json(['source_id' => $sourceId, 'saved_only' => true,
        'message' => 'Source saved. Crawling for content topics and guides isn\'t built yet, so nothing was fetched. It\'s recorded for when it is.']);
}

try {
    $fetch = (new SiteFetcher(['max_pages' => $maxPages]))->fetch($url);
} catch (Throwable $e) {
    IntakeStager::recordRun($pdo, $sourceId, 0, [], $e->getMessage());
    intake_fail('Crawl failed: ' . $e->getMessage());
}

if (!$fetch['pages']) {
    IntakeStager::recordRun($pdo, $sourceId, 0, $fetch['log'], 'No pages could be fetched.');
    intake_json(['error' => 'No pages could be fetched from that site.', 'log' => $fetch['log'], 'source_id' => $sourceId], 422);
}

try {
    $candidates = ListingExtractor::extract($fetch['pages'], $url);
    $result = IntakeStager::stage($pdo, $sourceId, $candidates);
    IntakeStager::recordRun($pdo, $sourceId, count($fetch['pages']), $fetch['log'], null);
} catch (Throwable $e) {
    error_log('intake crawl.php: ' . $e->getMessage());
    IntakeStager::recordRun($pdo, $sourceId, count($fetch['pages']), $fetch['log'], $e->getMessage());
    intake_fail('Crawled the site but could not stage the results. The details are in the server error log.', 500);
}

// the page log, the source register and the place store, as for every page the crawler reads (review W3, decisions/0160):
// the next read knows what changed, the register knows the site, and its places are kept where its use rule allows
$kept = ['logged' => 0, 'kept' => 0, 'rule' => ''];
try {
    require_once __DIR__ . '/../../../../app/lib/crawler/SourceIndex.php';
    $kept = SourceIndex::keepRead($pdo, $url, $fetch['pages'], $candidates, 'intake');
} catch (Throwable $e) { error_log('intake crawl.php keepRead: ' . $e->getMessage()); }

// Pages listed under the site's Locations menu that gave no address: likely locations to add by hand.
$canon = fn ($u) => rtrim(strtolower(preg_replace('#^https?://(www\.)?#i', '', (string) $u)), '/');
$read = [];
foreach ($candidates as $c) {
    if (!empty($c['where']['location_page'])) $read[$canon($c['where']['location_page'])] = true;
    foreach ((array) ($c['sources']['address'] ?? []) as $u) $read[$canon($u)] = true;
}
$unread = array_values(array_filter($fetch['location_pages'] ?? [], fn ($u) => !isset($read[$canon($u)])));

intake_json([
    'source_id'      => $sourceId,
    'pages'          => count($fetch['pages']),
    'log'            => $fetch['log'],
    'found'          => count($candidates),
    'staged'         => $result['staged'],
    'already_known'  => $result['already_known'],
    'auto_imported'  => $result['auto_imported'] ?? [],
    'unread_locations' => $unread,
    'register'       => ['pages_logged' => $kept['logged'], 'places_kept' => $kept['kept'], 'use_rule' => $kept['rule']],
]);
