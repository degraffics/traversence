/* Long settings kept whole (2026-11-17). search_index_state.v is VARCHAR(200) (2026-10-02_search_index.sql), and the
   server cuts a longer value short without an error: Start the system's state (SystemStart, a JSON document with its log),
   the pre-flight's W0 test ask, W0's flagged list and size history, Geofabrik's test results, the identity check's last
   run, the worker's key report, search presets and Gemini's comparison were cut and read back as nothing. Add-only
   (decisions/0162): a new column, v_long, holds the whole value; SearchIndex::state() reads it first and setState() writes
   both (v keeps its first 200 characters for anything that reads the table directly). Safe to run twice; no rows change. */
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE search_index_state ADD COLUMN v_long MEDIUMTEXT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'search_index_state' AND COLUMN_NAME = 'v_long');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
