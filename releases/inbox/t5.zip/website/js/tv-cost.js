// js/tv-cost.js — an order item's Cost tab works its sheet out again as you type (Costing::sheet() in app/lib/Costing.php
// does the same sums; the one saved is the server's). Our team only.
(function () {
  function n(v) { var x = parseFloat(String(v || '').replace(/[,$\s]/g, '')); return isFinite(x) ? x : 0; }
  function usd(c) { c = Math.round(c); return (c < 0 ? '−' : '') + '$' + (Math.abs(c) / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function num(x) { return String(+(+x).toFixed(5)); }
  function th(x) { return Math.round(x).toLocaleString('en-US'); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function recipe(f) {
    var val = function (row, k) { var el = row.querySelector('[name$="[' + k + ']"]'); return el ? (el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value) : ''; };
    var r = { parts: [], items: [], spoil: Math.max(0, Math.min(50, n(f.elements.spoil && f.elements.spoil.value))), tiers: [] };
    f.querySelectorAll('[data-cost-part]').forEach(function (row) { if (!val(row, 'name').trim()) return;
      r.parts.push({ name: val(row, 'name').trim(), pages: Math.max(1, Math.trunc(n(val(row, 'pages')) || 1)), sides: +val(row, 'sides') === 1 ? 1 : 2, up: Math.max(1, Math.trunc(n(val(row, 'up')) || 1)), click: Math.max(0, n(val(row, 'click'))), stock: +val(row, 'stock') || 0, stock_rate: Math.max(0, n(val(row, 'stock_rate'))), own: +val(row, 'own') ? 1 : 0, vendor: val(row, 'vendor') }); });
    f.querySelectorAll('[data-cost-item]').forEach(function (row) { if (!val(row, 'name').trim()) return;
      r.items.push({ name: val(row, 'name').trim(), item: +val(row, 'item') || 0, rate: Math.max(0, n(val(row, 'rate'))), per: ['run', 'c', 'n'].indexOf(val(row, 'per')) >= 0 ? val(row, 'per') : 'book', n: Math.max(1, Math.trunc(n(val(row, 'n')) || 1)), own: +val(row, 'own') ? 1 : 0, vendor: val(row, 'vendor') }); });
    var seen = {}; f.querySelectorAll('input[name^="tiers["][name$="[0]"]').forEach(function (q) { var m = f.querySelector('input[name="' + q.name.replace(/\[0\]$/, '[1]') + '"]'), qq = Math.trunc(n(q.value)), mm = n(m && m.value); if (qq > 0 && mm > 0) seen[qq] = [qq, mm]; });
    r.tiers = Object.keys(seen).map(Number).sort(function (a, b) { return a - b; }).map(function (k) { return seen[k]; });
    return r;
  }
  function sheet(r, run, items, tiers) {
    run = Math.max(1, run); var lines = [];
    r.parts.forEach(function (p) {
      var leaves = Math.ceil(p.pages / p.sides), sheets = Math.ceil(run * leaves / p.up * (1 + r.spoil / 100) - 1e-9);
      var how = th(run) + ' × ' + leaves + ' ' + (leaves === 1 ? 'leaf' : 'leaves') + (p.sides === 2 ? ' (both sides)' : '') + ' ÷ ' + p.up + ' to a sheet' + (r.spoil ? ' + ' + num(r.spoil) + '%' : '') + ' = ' + th(sheets) + ' sheets';
      lines.push({ label: p.name + ' printing', work: how + ' × ' + num(p.click), cents: Math.round(sheets * p.click * 100), vendor: p.vendor });
      var st = items[p.stock], ov = st && p.own && p.stock_rate > 0, rate = st && !ov ? st.unit : p.stock_rate;
      if (st || rate > 0) lines.push({ label: p.name + ' stock' + (st ? ': ' + st.name : ''), work: th(sheets) + ' sheets × ' + num(rate) + (ov ? ' (this order; the list has ' + num(st.unit) + ')' : ''), cents: Math.round(sheets * rate * 100), vendor: p.vendor });
    });
    r.items.forEach(function (i) { var it = items[i.item], ov = it && i.own, rate = it && !ov ? it.unit : i.rate;
      var times = i.per === 'run' ? 1 : i.per === 'c' ? run / 100 : i.per === 'n' ? Math.ceil(run / i.n) : run;
      lines.push({ label: i.name + (it && it.name.trim().toLowerCase() !== i.name.trim().toLowerCase() ? ': ' + it.name : ''), work: i.per === 'run' ? 'once for the run' : i.per === 'c' ? th(run) + ' ÷ 100 = ' + num(times) + ' × ' + num(rate) : i.per === 'n' ? th(run) + ' ÷ ' + th(i.n) + ' to one = ' + th(times) + ' × ' + num(rate) : th(run) + ' × ' + num(rate), cents: Math.round((times * rate) * 100), vendor: i.vendor });
      if (ov) lines[lines.length - 1].work += ' (this order; the list has ' + num(it.unit) + ')'; });
    var cogs = lines.reduce(function (t, l) { return t + l.cents; }, 0), out = { run: run, lines: lines, cogs: cogs, vendor: lines.reduce(function (t, l) { return t + (l.vendor ? l.cents : 0); }, 0), tiers: [] };
    if (tiers) r.tiers.forEach(function (t) { var c = sheet(r, t[0], items, false).cogs, each = Math.ceil(c * t[1] / t[0] - 1e-9); out.tiers.push({ qty: t[0], mult: t[1], cogs: c, each: each, total: each * t[0] }); });
    return out;
  }
  function draw(ws, price) {
    var h = ws.lines.map(function (l) { return '<div class="cx-l' + (l.vendor ? '' : ' us') + '"><div>' + esc(l.label) + '<small>' + esc(l.work) + '</small></div><div class="cx-a">' + usd(l.cents) + '</div></div>'; }).join('');
    h += '<div class="cx-tot"><b>COGS (' + th(ws.run) + ')</b><b>' + usd(ws.cogs) + '</b><span>Each</span><span style="text-align:right">$' + (ws.cogs / 100 / ws.run).toFixed(4) + '</span><span>The vendor\'s share</span><span style="text-align:right">' + usd(ws.vendor) + '</span>';
    if (price > 0) h += '<span>Price on the order</span><span style="text-align:right">' + usd(price) + ' ($' + (price / 100 / ws.run).toFixed(2) + ' each)</span><b>Margin</b><b>' + usd(price - ws.cogs) + ' (' + Math.round((price - ws.cogs) / price * 100) + '%, ' + (price / Math.max(1, ws.cogs)).toFixed(2) + '× COGS)</b>';
    h += '</div>';
    if (ws.tiers.length) h += '<table class="cx-tt" data-tv-table><tr><th>Run</th><th>COGS</th><th>×</th><th>Each</th><th>Price</th></tr>' + ws.tiers.map(function (t) { return '<tr' + (t.qty === ws.run ? ' class="here"' : '') + '><td>' + th(t.qty) + '</td><td>' + usd(t.cogs) + '</td><td>' + t.mult + '</td><td>$' + (t.each / 100).toFixed(2) + '</td><td>' + usd(t.total) + '</td></tr>'; }).join('') + '</table>';
    return h;
  }
  function wire(f) {
    if (f.__cx) return; f.__cx = true;
    var items = {}; try { items = JSON.parse(f.querySelector('[data-cost-items]').content.textContent || '{}'); } catch (x) {}
    var run = +f.querySelector('[data-cost-run]').value, price = +f.querySelector('[data-cost-price]').value, out = f.querySelector('[data-cost-sheet]');
    var redo = function () { out.innerHTML = draw(sheet(recipe(f), run, items, true), price); if (window.TvTable) TvTable.all(out); };   // the tiers on the table standard again (T5)
    f.addEventListener('input', redo); f.addEventListener('change', redo);
    var k = 1000;   // + Printed part / + Cost: a line from its template, numbered after the rest; × takes one out
    f.addEventListener('click', function (e) {
      var add = e.target.closest('[data-cost-add]'), del = e.target.closest('[data-cost-del]');
      if (add) {
        var t = f.querySelector('template[data-cost-new="' + add.getAttribute('data-cost-add') + '"]'), box = document.createElement('div');
        box.innerHTML = t.innerHTML.replace(/__K__/g, String(k++)); var row = box.firstElementChild;
        f.querySelector('[data-cost-lines]').appendChild(row); var none = f.querySelector('[data-cost-none]'); if (none) none.hidden = true;
        var first = row.querySelector('input'); if (first) first.focus(); redo();
      } else if (del) { del.closest('.cx-row').remove(); redo(); }
    });
    // a listed stock or cost: its price comes from the list (the box says so); typing one there is this order's own price
    // (an override, shown with the list's beside it). None picked: type it. "To one" only for "1 per N, whole"
    f.addEventListener('input', function (e) {
      if (!e.target.hasAttribute('data-cost-rate')) return;
      var own = e.target.parentNode.querySelector('[data-cost-own]'), row = e.target.closest('.cx-row'), pick = row && row.querySelector('select[name$="[stock]"], select[name$="[item]"]');
      if (own) own.value = pick && items[pick.value] && e.target.value.trim() !== '' ? '1' : '0'; redo();
    });
    f.addEventListener('change', function (e) {
      var nm = e.target.name || '', m = /\[(stock|item|per)\]$/.exec(nm); if (!m) return;
      if (m[1] === 'per') { var nb = f.querySelector('[name="' + nm.replace(/\[per\]$/, '[n]') + '"]'); if (nb) { nb.disabled = e.target.value !== 'n'; if (nb.disabled) nb.value = ''; } redo(); return; }
      var box = f.querySelector('[name="' + nm.replace(/\[(stock|item)\]$/, m[1] === 'stock' ? '[stock_rate]' : '[rate]') + '"]'), it = items[e.target.value];
      if (!box) return; if (it) box.value = ''; var ow = box.parentNode.querySelector('[data-cost-own]'); if (ow) ow.value = '0'; box.placeholder = it ? num(it.unit) + ' from the list' : 'type it'; redo();
    });
  }
  var go = function () { document.querySelectorAll('form[data-cost]').forEach(wire); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
})();
