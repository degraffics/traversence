// js/tv-vault.js — the Vault in the browser (decisions/0156). Everything is sealed and opened here, never on the server:
// a random vault key seals each item's own key; the vault key is sealed for each device (the vault passphrase, slowed
// by PBKDF2, joined with the passkey's PRF secret where the browser gives it) and once by the 24 recovery words. Each
// login's password is sealed to its exact sign-in address. The server sees only sealed data, checks the passkey, and
// hands back one sealed login at a time after a fresh check and a single-use token. The vault key lives only in this
// page's memory and is forgotten on Lock, on leaving, and after 5 minutes unused plus 2 minutes of "Still there?".
// Recovery words: the BIP39 English list (2,048 words; MIT licence, from @scure/bip39).
(function () {
  'use strict';
  var root = document.getElementById('tvv'); if (!root) return;
  var C = window.crypto, S = C && C.subtle, te = new TextEncoder(), td = new TextDecoder();
  var WORDS = 'abandon ability able about above absent absorb abstract absurd abuse access accident account accuse achieve acid acoustic acquire across act action actor actress actual adapt add addict address adjust admit adult advance advice aerobic affair afford afraid again age agent agree ahead aim air airport aisle alarm album alcohol alert alien all alley allow almost alone alpha already also alter always amateur amazing among amount amused analyst anchor ancient anger angle angry animal ankle announce annual another answer antenna antique anxiety any apart apology appear apple approve april arch arctic area arena argue arm armed armor army around arrange arrest arrive arrow art artefact artist artwork ask aspect assault asset assist assume asthma athlete atom attack attend attitude attract auction audit august aunt author auto autumn average avocado avoid awake aware away awesome awful awkward axis baby bachelor bacon badge bag balance balcony ball bamboo banana banner bar barely bargain barrel base basic basket battle beach bean beauty because become beef before begin behave behind believe below belt bench benefit best betray better between beyond bicycle bid bike bind biology bird birth bitter black blade blame blanket blast bleak bless blind blood blossom blouse blue blur blush board boat body boil bomb bone bonus book boost border boring borrow boss bottom bounce box boy bracket brain brand brass brave bread breeze brick bridge brief bright bring brisk broccoli broken bronze broom brother brown brush bubble buddy budget buffalo build bulb bulk bullet bundle bunker burden burger burst bus business busy butter buyer buzz cabbage cabin cable cactus cage cake call calm camera camp can canal cancel candy cannon canoe canvas canyon capable capital captain car carbon card cargo carpet carry cart case cash casino castle casual cat catalog catch category cattle caught cause caution cave ceiling celery cement census century cereal certain chair chalk champion change chaos chapter charge chase chat cheap check cheese chef cherry chest chicken chief child chimney choice choose chronic chuckle chunk churn cigar cinnamon circle citizen city civil claim clap clarify claw clay clean clerk clever click client cliff climb clinic clip clock clog close cloth cloud clown club clump cluster clutch coach coast coconut code coffee coil coin collect color column combine come comfort comic common company concert conduct confirm congress connect consider control convince cook cool copper copy coral core corn correct cost cotton couch country couple course cousin cover coyote crack cradle craft cram crane crash crater crawl crazy cream credit creek crew cricket crime crisp critic crop cross crouch crowd crucial cruel cruise crumble crunch crush cry crystal cube culture cup cupboard curious current curtain curve cushion custom cute cycle dad damage damp dance danger daring dash daughter dawn day deal debate debris decade december decide decline decorate decrease deer defense define defy degree delay deliver demand demise denial dentist deny depart depend deposit depth deputy derive describe desert design desk despair destroy detail detect develop device devote diagram dial diamond diary dice diesel diet differ digital dignity dilemma dinner dinosaur direct dirt disagree discover disease dish dismiss disorder display distance divert divide divorce dizzy doctor document dog doll dolphin domain donate donkey donor door dose double dove draft dragon drama drastic draw dream dress drift drill drink drip drive drop drum dry duck dumb dune during dust dutch duty dwarf dynamic eager eagle early earn earth easily east easy echo ecology economy edge edit educate effort egg eight either elbow elder electric elegant element elephant elevator elite else embark embody embrace emerge emotion employ empower empty enable enact end endless endorse enemy energy enforce engage engine enhance enjoy enlist enough enrich enroll ensure enter entire entry envelope episode equal equip era erase erode erosion error erupt escape essay essence estate eternal ethics evidence evil evoke evolve exact example excess exchange excite exclude excuse execute exercise exhaust exhibit exile exist exit exotic expand expect expire explain expose express extend extra eye eyebrow fabric face faculty fade faint faith fall false fame family famous fan fancy fantasy farm fashion fat fatal father fatigue fault favorite feature february federal fee feed feel female fence festival fetch fever few fiber fiction field figure file film filter final find fine finger finish fire firm first fiscal fish fit fitness fix flag flame flash flat flavor flee flight flip float flock floor flower fluid flush fly foam focus fog foil fold follow food foot force forest forget fork fortune forum forward fossil foster found fox fragile frame frequent fresh friend fringe frog front frost frown frozen fruit fuel fun funny furnace fury future gadget gain galaxy gallery game gap garage garbage garden garlic garment gas gasp gate gather gauge gaze general genius genre gentle genuine gesture ghost giant gift giggle ginger giraffe girl give glad glance glare glass glide glimpse globe gloom glory glove glow glue goat goddess gold good goose gorilla gospel gossip govern gown grab grace grain grant grape grass gravity great green grid grief grit grocery group grow grunt guard guess guide guilt guitar gun gym habit hair half hammer hamster hand happy harbor hard harsh harvest hat have hawk hazard head health heart heavy hedgehog height hello helmet help hen hero hidden high hill hint hip hire history hobby hockey hold hole holiday hollow home honey hood hope horn horror horse hospital host hotel hour hover hub huge human humble humor hundred hungry hunt hurdle hurry hurt husband hybrid ice icon idea identify idle ignore ill illegal illness image imitate immense immune impact impose improve impulse inch include income increase index indicate indoor industry infant inflict inform inhale inherit initial inject injury inmate inner innocent input inquiry insane insect inside inspire install intact interest into invest invite involve iron island isolate issue item ivory jacket jaguar jar jazz jealous jeans jelly jewel job join joke journey joy judge juice jump jungle junior junk just kangaroo keen keep ketchup key kick kid kidney kind kingdom kiss kit kitchen kite kitten kiwi knee knife knock know lab label labor ladder lady lake lamp language laptop large later latin laugh laundry lava law lawn lawsuit layer lazy leader leaf learn leave lecture left leg legal legend leisure lemon lend length lens leopard lesson letter level liar liberty library license life lift light like limb limit link lion liquid list little live lizard load loan lobster local lock logic lonely long loop lottery loud lounge love loyal lucky luggage lumber lunar lunch luxury lyrics machine mad magic magnet maid mail main major make mammal man manage mandate mango mansion manual maple marble march margin marine market marriage mask mass master match material math matrix matter maximum maze meadow mean measure meat mechanic medal media melody melt member memory mention menu mercy merge merit merry mesh message metal method middle midnight milk million mimic mind minimum minor minute miracle mirror misery miss mistake mix mixed mixture mobile model modify mom moment monitor monkey monster month moon moral more morning mosquito mother motion motor mountain mouse move movie much muffin mule multiply muscle museum mushroom music must mutual myself mystery myth naive name napkin narrow nasty nation nature near neck need negative neglect neither nephew nerve nest net network neutral never news next nice night noble noise nominee noodle normal north nose notable note nothing notice novel now nuclear number nurse nut oak obey object oblige obscure observe obtain obvious occur ocean october odor off offer office often oil okay old olive olympic omit once one onion online only open opera opinion oppose option orange orbit orchard order ordinary organ orient original orphan ostrich other outdoor outer output outside oval oven over own owner oxygen oyster ozone pact paddle page pair palace palm panda panel panic panther paper parade parent park parrot party pass patch path patient patrol pattern pause pave payment peace peanut pear peasant pelican pen penalty pencil people pepper perfect permit person pet phone photo phrase physical piano picnic picture piece pig pigeon pill pilot pink pioneer pipe pistol pitch pizza place planet plastic plate play please pledge pluck plug plunge poem poet point polar pole police pond pony pool popular portion position possible post potato pottery poverty powder power practice praise predict prefer prepare present pretty prevent price pride primary print priority prison private prize problem process produce profit program project promote proof property prosper protect proud provide public pudding pull pulp pulse pumpkin punch pupil puppy purchase purity purpose purse push put puzzle pyramid quality quantum quarter question quick quit quiz quote rabbit raccoon race rack radar radio rail rain raise rally ramp ranch random range rapid rare rate rather raven raw razor ready real reason rebel rebuild recall receive recipe record recycle reduce reflect reform refuse region regret regular reject relax release relief rely remain remember remind remove render renew rent reopen repair repeat replace report require rescue resemble resist resource response result retire retreat return reunion reveal review reward rhythm rib ribbon rice rich ride ridge rifle right rigid ring riot ripple risk ritual rival river road roast robot robust rocket romance roof rookie room rose rotate rough round route royal rubber rude rug rule run runway rural sad saddle sadness safe sail salad salmon salon salt salute same sample sand satisfy satoshi sauce sausage save say scale scan scare scatter scene scheme school science scissors scorpion scout scrap screen script scrub sea search season seat second secret section security seed seek segment select sell seminar senior sense sentence series service session settle setup seven shadow shaft shallow share shed shell sheriff shield shift shine ship shiver shock shoe shoot shop short shoulder shove shrimp shrug shuffle shy sibling sick side siege sight sign silent silk silly silver similar simple since sing siren sister situate six size skate sketch ski skill skin skirt skull slab slam sleep slender slice slide slight slim slogan slot slow slush small smart smile smoke smooth snack snake snap sniff snow soap soccer social sock soda soft solar soldier solid solution solve someone song soon sorry sort soul sound soup source south space spare spatial spawn speak special speed spell spend sphere spice spider spike spin spirit split spoil sponsor spoon sport spot spray spread spring spy square squeeze squirrel stable stadium staff stage stairs stamp stand start state stay steak steel stem step stereo stick still sting stock stomach stone stool story stove strategy street strike strong struggle student stuff stumble style subject submit subway success such sudden suffer sugar suggest suit summer sun sunny sunset super supply supreme sure surface surge surprise surround survey suspect sustain swallow swamp swap swarm swear sweet swift swim swing switch sword symbol symptom syrup system table tackle tag tail talent talk tank tape target task taste tattoo taxi teach team tell ten tenant tennis tent term test text thank that theme then theory there they thing this thought three thrive throw thumb thunder ticket tide tiger tilt timber time tiny tip tired tissue title toast tobacco today toddler toe together toilet token tomato tomorrow tone tongue tonight tool tooth top topic topple torch tornado tortoise toss total tourist toward tower town toy track trade traffic tragic train transfer trap trash travel tray treat tree trend trial tribe trick trigger trim trip trophy trouble truck true truly trumpet trust truth try tube tuition tumble tuna tunnel turkey turn turtle twelve twenty twice twin twist two type typical ugly umbrella unable unaware uncle uncover under undo unfair unfold unhappy uniform unique unit universe unknown unlock until unusual unveil update upgrade uphold upon upper upset urban urge usage use used useful useless usual utility vacant vacuum vague valid valley valve van vanish vapor various vast vault vehicle velvet vendor venture venue verb verify version very vessel veteran viable vibrant vicious victory video view village vintage violin virtual virus visa visit visual vital vivid vocal voice void volcano volume vote voyage wage wagon wait walk wall walnut want warfare warm warrior wash wasp waste water wave way wealth weapon wear weasel weather web wedding weekend weird welcome west wet whale what wheat wheel when where whip whisper wide width wife wild will win window wine wing wink winner winter wire wisdom wise wish witness wolf woman wonder wood wool word work world worry worth wrap wreck wrestle wrist write wrong yard year yellow you young youth zebra zero zone zoo'.split(' ');
  var ITER = 600000, IDLE = 300000, WARN = 120;   // 5 minutes unused, then "Still there?" for 2 minutes (Jason, 2026-11-12: like a bank's sign-in)
  var st = { vk: null, vkRaw: null, siteKey: null, pass: null, items: [], devices: [], state: null, prfOut: null, idle: 0, me: root.getAttribute('data-me') || '' };
  var $ = function (s, el) { return (el || root).querySelector(s) || (el ? null : document.querySelector(s)); };   // the vault's bar sits in the page's command bar
  // the time left and the vault's buttons go in the page's command bar, in its tab on the right (Jason's mock-up, 2026-11-12)
  (function () { var cmdr = document.getElementById('ak-cmdr'), bar = document.getElementById('tvv-bar'); if (cmdr && bar) cmdr.appendChild(bar); })();
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return '&#' + c.charCodeAt(0) + ';'; }); };
  var say = function (m, o) { if (window.TvAsk && TvAsk.say) TvAsk.say(m, o || {}); };
  var busy = function (b, on) { if (b && window.TvAsk && TvAsk.busy) TvAsk.busy(b, on); };
  var tz = function () { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { return ''; } };

  // ---- bytes -----------------------------------------------------------------------------------------------------------
  function b64u(buf) { var b = new Uint8Array(buf), s = ''; for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64u(s) { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var r = atob(s), b = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) b[i] = r.charCodeAt(i); return b; }
  function rnd(n) { var b = new Uint8Array(n); C.getRandomValues(b); return b; }
  function cat(a, b) { var r = new Uint8Array(a.length + b.length); r.set(a); r.set(b, a.length); return r; }
  function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
  function wipe(b) { if (b && b.fill) b.fill(0); }

  // ---- the server ------------------------------------------------------------------------------------------------------
  var csrf = null;
  async function api(body, soft) {   // soft: a closed vault is the caller's to handle (Keep Vault Open)
    if (!csrf) csrf = (await (await fetch('/api/auth/session.php', { credentials: 'include' })).json()).csrf_token;
    body.tz = tz();
    var r = await fetch('/admin/api/vault.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) });
    var j; try { j = await r.json(); } catch (e) { throw new Error('The vault didn\'t answer. Try again.'); }
    if (!j.ok && !soft && j.error && j.error.code === 'vault_closed' && st.vk) { keepDrop(); forget(); show('unlock'); status(j.error.message, 'info', 'Closed:'); }
    if (!j.ok) { var x = new Error((j.error && j.error.message) || 'That didn\'t work.'); x.code = j.error && j.error.code; throw x; }
    return j;
  }

  // ---- keys ------------------------------------------------------------------------------------------------------------
  async function aes(raw, use) { return S.importKey('raw', raw, { name: 'AES-GCM' }, false, use || ['encrypt', 'decrypt']); }
  async function seal(key, bytes, aad) { var iv = rnd(12); var ct = await S.encrypt({ name: 'AES-GCM', iv: iv, additionalData: te.encode(aad) }, key, bytes); return { v: 1, iv: b64u(iv), ct: b64u(ct) }; }
  async function open(key, box, aad) { return new Uint8Array(await S.decrypt({ name: 'AES-GCM', iv: unb64u(box.iv), additionalData: te.encode(aad) }, key, unb64u(box.ct))); }
  async function hkdf(ikm, info, salt) { var k = await S.importKey('raw', ikm, 'HKDF', false, ['deriveKey']); return S.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: salt || new Uint8Array(32), info: te.encode(info) }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); }
  async function passBits(pass, salt, iter) { var k = await S.importKey('raw', te.encode(pass.normalize('NFKC')), 'PBKDF2', false, ['deriveBits']); return new Uint8Array(await S.deriveBits({ name: 'PBKDF2', salt: salt, iterations: iter, hash: 'SHA-256' }, k, 256)); }
  /** A device's key: the passphrase's slow bits, joined with the passkey's PRF secret when it has one. */
  async function slotKey(bits, prf) { return hkdf(prf ? cat(bits, new Uint8Array(prf)) : bits, 'tv-vault-slot-v1'); }
  /** Seals the vault key for this device (or, with no PRF, by the passphrase alone, for a device that adds its PRF when next used). */
  async function makeSlot(prf) {
    var salt = st.pass.salt, iter = st.pass.iter;
    var box = await seal(await slotKey(st.pass.bits, prf), st.vkRaw, 'vault');
    box.salt = b64u(salt); box.iter = iter; box.kdf = prf ? 'pbkdf2+prf' : 'pbkdf2'; box.prf = prf ? 1 : 0; return box;
  }
  async function useVault(raw) {
    st.vkRaw = raw; st.vk = await aes(raw);
    var hk = await S.importKey('raw', raw, 'HKDF', false, ['deriveKey']);
    st.siteKey = await S.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: new Uint8Array(32), info: te.encode('tv-vault-site-v1') }, hk, { name: 'HMAC', hash: 'SHA-256', length: 256 }, false, ['sign']);
  }
  async function siteOf(url) { return hex(await S.sign('HMAC', st.siteKey, te.encode(new URL(url).origin.toLowerCase()))); }
  /** The exact sign-in address a login is sealed to: its origin and path, no query or #. */
  function loginAddr(u) { var x = new URL(/^https?:\/\//i.test(u) ? u : 'https://' + u); if (!/^https?:$/.test(x.protocol)) throw new Error('Use a web address.'); return x.origin.toLowerCase() + x.pathname; }

  // ---- recovery words (BIP39: 256 bits + an 8-bit checksum = 24 words) ---------------------------------------------------
  async function toWords(ent) {
    var h = new Uint8Array(await S.digest('SHA-256', ent)), bits = '';
    for (var i = 0; i < ent.length; i++) bits += ('0000000' + ent[i].toString(2)).slice(-8);
    bits += ('0000000' + h[0].toString(2)).slice(-8);
    var out = []; for (var j = 0; j < 24; j++) out.push(WORDS[parseInt(bits.slice(j * 11, j * 11 + 11), 2)]); return out;
  }
  async function fromWords(text) {
    var w = String(text).toLowerCase().replace(/[^a-z\s]/g, ' ').trim().split(/\s+/).filter(Boolean);
    if (w.length !== 24) throw new Error('Enter all 24 words (you entered ' + w.length + ').');
    var bits = '';
    for (var i = 0; i < 24; i++) { var n = WORDS.indexOf(w[i]); if (n < 0) throw new Error('Word ' + (i + 1) + ' ("' + w[i] + '") isn\'t one of the recovery words. Check its spelling.'); bits += ('0000000000' + n.toString(2)).slice(-11); }
    var ent = new Uint8Array(32); for (var k = 0; k < 32; k++) ent[k] = parseInt(bits.slice(k * 8, k * 8 + 8), 2);
    var h = new Uint8Array(await S.digest('SHA-256', ent));
    if (parseInt(bits.slice(256), 2) !== h[0]) throw new Error('Those words don\'t fit together: one may be wrong or out of order.');
    return ent;
  }
  async function wordsKey(ent, salt) { return hkdf(ent, 'tv-vault-words-v1', salt); }
  /** New words: the vault key sealed by them, and the words to show once. */
  async function newWords() {
    var ent = rnd(32), salt = rnd(16), words = await toWords(ent);
    var box = await seal(await wordsKey(ent, salt), st.vkRaw, 'vault'); box.salt = b64u(salt); box.kdf = 'words'; wipe(ent);
    return { box: box, words: words };
  }

  // ---- passkeys --------------------------------------------------------------------------------------------------------
  function hasPasskeys() { return !!(window.PublicKeyCredential && navigator.credentials && S); }
  /** A new passkey. 'device' (this computer: Windows Hello, Touch ID) or 'spare' (a security key or a phone). The hint
   *  tells the browser where we mean it to go, so it can skip asking (it may still ask: the choice is the browser's). */
  async function createPasskey(where) {
    var o = (await api({ do: 'add_options' })).options;
    o.challenge = unb64u(o.challenge); o.user.id = unb64u(o.user.id);
    o.excludeCredentials = (o.excludeCredentials || []).map(function (c) { return { type: c.type, id: unb64u(c.id) }; });
    o.extensions = { prf: {} };
    if (where === 'spare') { o.hints = ['security-key', 'hybrid']; o.authenticatorSelection.authenticatorAttachment = 'cross-platform'; }
    else { o.hints = ['client-device']; o.authenticatorSelection.authenticatorAttachment = 'platform'; }
    var c = await navigator.credentials.create({ publicKey: o });
    var ext = c.getClientExtensionResults ? c.getClientExtensionResults() : {};
    return { credential: { clientDataJSON: b64u(c.response.clientDataJSON), attestationObject: b64u(c.response.attestationObject) }, prf: !!(ext.prf && ext.prf.enabled) };
  }
  /** A passkey check: the device's fingerprint, face or PIN. Returns the server's answer and keeps the PRF secret in memory. */
  async function checkPasskey() {
    var o = (await api({ do: 'get_options' })).options;
    o.challenge = unb64u(o.challenge);
    o.allowCredentials = (o.allowCredentials || []).map(function (c) { return { type: c.type, id: unb64u(c.id) }; });
    o.extensions = { prf: { eval: { first: unb64u(o.extensions.prf.eval.first) } } };
    var a = await navigator.credentials.get({ publicKey: o });
    var ext = a.getClientExtensionResults ? a.getClientExtensionResults() : {};
    st.prfOut = ext.prf && ext.prf.results && ext.prf.results.first ? ext.prf.results.first : null;
    return api({ do: 'check', credential: { id: a.id, response: { clientDataJSON: b64u(a.response.clientDataJSON), authenticatorData: b64u(a.response.authenticatorData), signature: b64u(a.response.signature) } } });
  }
  function passkeyErr(e) {
    if (e && (e.name === 'NotAllowedError' || e.name === 'AbortError')) return 'The passkey check was cancelled or timed out. Try again.';
    if (e && e.name === 'InvalidStateError') return 'This device already has a passkey for the vault: use Unlock.';
    return (e && e.message) || 'That didn\'t work.';
  }

  // ---- views -----------------------------------------------------------------------------------------------------------
  var VIEWS = ['setup', 'phrase', 'unlock', 'adddev', 'recover', 'kit', 'extra', 'main', 'nokeys'];
  function show(v) {
    var vb = document.getElementById('tvv-bar'); if (vb) vb.hidden = v !== 'main';
    if (v !== 'main') { panelsShut(); clockOff(); } if (v === 'extra') moveExtra('#tvv-extra');
    VIEWS.forEach(function (n) { var el = $('#tvv-' + n); if (el) el.hidden = n !== v; });
    var step = { setup: 1, phrase: 2, kit: 3, extra: 4 }[v], bar = $('#tvv-steps');
    bar.hidden = !(st.setupMode && step);
    if (step) Array.prototype.forEach.call(bar.children, function (li, i) { li.className = i + 1 < step ? 'done' : (i + 1 === step ? 'now' : ''); li.removeAttribute('aria-current'); if (i + 1 === step) li.setAttribute('aria-current', 'step'); });
    var f = $('#tvv-' + v + ' input:not([type=checkbox])'); if (f && v !== 'main') setTimeout(function () { try { f.focus(); } catch (e) {} }, 50);
  }
  /** The status line: the site's own (js/tv-ask.js turns each data-tv-status line into its notice look). */
  function statuses(el) { if (window.TvAsk && TvAsk.statuses) TvAsk.statuses(el); }
  function status(text, kind, label) {
    var box = $('#tvv-status'); box.innerHTML = '<p data-tv-status="' + esc(kind || 'info') + '" data-tv-label="' + esc(label || '') + '">' + esc(text) + '</p>'; statuses(box);
  }
  /** Shows the authenticator-code boxes only where the vault has an app. */
  function appBoxes() { Array.prototype.forEach.call(root.querySelectorAll('.tvv-needapp'), function (el) { el.hidden = !(st.state && st.state.app); }); }

  async function boot() {
    if (!hasPasskeys()) { status('This browser can\'t use passkeys, so it can\'t open the vault. Use a current Chrome, Edge, Safari or Firefox.', 'bad', 'Not here:'); return; }
    var j = await api({ do: 'state' }); st.state = j.state; appBoxes();
    if (!j.state.devices.length) { st.setupMode = true; status('Five short steps. Nothing is saved until your recovery words are checked.', 'info', 'Set up your vault:'); show('setup'); return; }
    if (!j.state.ready) { st.setupMode = true; st.hasKey = true; status('This device\'s passkey is made; choose your vault passphrase.', 'info', 'Step 2 of 5:'); show('phrase'); return; }
    if (!j.state.locked && await keepLoad()) {   // a reload of this tab within the open time: still open
      await openMain(); return;   // the bar says it's open, and for how long
    }
    status(j.state.locked ? 'The vault is locked. Unlocking it needs your passkey and passphrase, and tells you by email.' : 'Unlock with your passkey and your vault passphrase.', j.state.locked ? 'bad' : 'info', j.state.locked ? 'Locked:' : 'Closed:');
    drawWays(); show('unlock');
  }

  // ---- the passphrase: its own rules (it's not a password: it never leaves this browser, and no one can reset it) ----------
  var COMMON = /^(password|passphrase|letmein|welcome|qwerty|iloveyou|admin|secret|changeme|vault)/i;
  /** A careful guess at how many guesses it would take, in bits: list words 11 each, ordinary words up to 12, the rest by character. */
  function bitsOf(v) {
    var toks = v.trim().split(/[\s\-_.,]+/).filter(Boolean), b = 0, seen = {};
    toks.forEach(function (t) {
      var l = t.toLowerCase(); if (seen[l]) { b += 1; return; } seen[l] = 1;
      if (WORDS.indexOf(l) >= 0) b += 11;
      else if (/^[a-z]+$/.test(l)) b += Math.min(12, l.length * 2);
      else { var pool = (/[a-z]/.test(t) ? 26 : 0) + (/[A-Z]/.test(t) ? 26 : 0) + (/[0-9]/.test(t) ? 10 : 0) + (/[^A-Za-z0-9]/.test(t) ? 20 : 0); b += t.length * Math.log2(pool || 1) * 0.6; }
    });
    return Math.round(b);
  }
  function ppRules(v) {
    var me = (st.me.split('@')[0] || '').toLowerCase(), lv = v.toLowerCase(), words = v.trim().split(/\s+/).filter(Boolean).length, bits = bitsOf(v);
    return [
      ['len', 'At least 4 words, or 20 characters', words >= 4 || v.length >= 20],
      ['bits', 'Hard to guess (' + (bits < 40 ? 'weak' : bits < 60 ? 'fair' : bits < 80 ? 'strong' : 'very strong') + ')', bits >= 60],
      ['own', 'Not your name, email or "Traversence"', v !== '' && lv.indexOf('traversence') < 0 && !(me.length >= 3 && lv.indexOf(me) >= 0)],
      ['rep', 'No long repeats or runs (aaaa, 1234, a common phrase)', v !== '' && !/(.)\1{3}/.test(v) && !/(0123|1234|2345|3456|4567|5678|6789|abcd|qwer|asdf)/i.test(v) && !COMMON.test(v.trim())]
    ];
  }
  function drawRules(inp) {
    var ul = $(inp.getAttribute('data-rules')); if (!ul) return true;
    var all = true, v = inp.value, rs = ppRules(v), bits = bitsOf(v), m = $(inp.getAttribute('data-meter'));
    ul.innerHTML = rs.map(function (r) { if (!r[2]) all = false; return '<li class="' + (r[2] ? 'ok' : (v ? 'no' : '')) + '">' + esc(r[1]) + '</li>'; }).join('');
    if (m) { var pct = Math.min(100, Math.round(bits / 90 * 100)); m.firstElementChild.style.width = (v ? Math.max(6, pct) : 0) + '%'; m.className = 'tvv-meter ' + (bits < 40 ? 'w' : bits < 60 ? 'f' : 'g'); }
    return all;
  }
  function matchRule(inp) {
    var o = $(inp.getAttribute('data-same')), ok = inp.value !== '' && o && inp.value === o.value, li = $(inp.getAttribute('data-rules'));
    if (li) li.innerHTML = '<li class="' + (ok ? 'ok' : (inp.value ? 'no' : '')) + '">The same as above</li>';
    return ok;
  }
  /** Checks a passphrase pair and its "not used elsewhere" tick; says what's missing beside the button. */
  function passOk(p1, p2, tick, btn) {
    if (!drawRules(p1)) { say('Your passphrase doesn\'t meet the list under it yet.', { anchor: btn, bad: true }); return false; }
    if (!matchRule(p2)) { say('The two passphrases don\'t match.', { anchor: btn, bad: true }); return false; }
    if (tick && !tick.checked) { say('Tick that it isn\'t your sign-in password or one you use anywhere else.', { anchor: btn, bad: true }); return false; }
    return true;
  }
  /** Suggests six list words (66 bits): easy to type, hard to guess. */
  function suggest(btn) {
    var tgt = $(btn.getAttribute('data-for')), out = [], b = new Uint16Array(6); C.getRandomValues(b);
    for (var i = 0; i < 6; i++) out.push(WORDS[b[i] % 2048]);
    tgt.value = out.join(' '); tgt.classList.remove('tvv-mask'); var eye = tgt.parentNode.querySelector('.tvv-eye'); if (eye) eye.setAttribute('aria-pressed', 'true');
    drawRules(tgt); var two = $(tgt.getAttribute('data-pair')); if (two) { two.value = ''; matchRule(two); two.focus(); }
    say('Learn it or write it down somewhere safe, then type it again below. It\'s yours alone: we never see it.', { anchor: btn });
  }

  // ---- setup: 1 this device's passkey, 2 the passphrase, 3 the recovery words (checked), 4 extra checks, 5 open --------------
  async function setup(btn) {
    busy(btn, true);
    try {
      if (!st.hasKey) {
        var made = await createPasskey('device');
        await api({ do: 'add', credential: made.credential, label: $('#tvv-label').value, prf: made.prf });
        st.hasKey = true;
      }
      await checkPasskey(); st.checkedAt = Date.now();
      status(st.prfOut ? 'This device\'s passkey is made, and it adds its own secret to your vault\'s lock.' : 'This device\'s passkey is made. (This browser doesn\'t add a passkey secret, so your passphrase carries the lock: make it a strong one.)', 'ok', 'Step 1 done:');
      show('phrase');
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  async function setupPass(btn) {
    var p1 = $('#tvv-p1'), p2 = $('#tvv-p2');
    if (!passOk(p1, p2, $('#tvv-ptick'), btn)) return;
    busy(btn, true);
    try {
      if (!st.checkedAt || Date.now() - st.checkedAt > 240000 || !st.prfOut && st.hasKey && !st.checkedAt) { await checkPasskey(); st.checkedAt = Date.now(); }
      var salt = rnd(16); st.pass = { bits: await passBits(p1.value, salt, ITER), salt: salt, iter: ITER };
      p1.value = p2.value = ''; drawRules(p1); matchRule(p2);
      await useVault(rnd(32));
      var w = await newWords();
      kit(w.words, w.box, 'setup');
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // ---- the three ways in (Jason, 2026-11-12): 1 the passphrase, 2 the authenticator app's code, 3 an emailed code; for 2
  // and 3 this device's passkey (PIN, fingerprint or face) then opens its PIN-sealed copy of the key. The way used last on
  // this browser comes first.
  var PININFO = 'tv-vault-pin-v1';
  function drawWays() {
    var s = st.state || {}, ways = $('#tvv-ways'), last = null; try { last = localStorage.getItem('tvv-way'); } catch (e) {}
    var why = { app: !s.app ? 'Add an authenticator app under Devices first (open the vault with way 1)' : (!s.pin_any ? 'Unlock once with your passphrase on this computer to turn on PIN unlock' : 'Then this device\'s PIN'),
      email: !s.pin_any ? 'Unlock once with your passphrase on this computer to turn on PIN unlock' : 'We email a code to the email on your account; then this device\'s PIN' };
    ['app', 'email'].forEach(function (k) { var w = ways.querySelector('[data-way=' + k + ']'); w.querySelector('.tvv-why').textContent = why[k]; w.querySelector('.tvv-wayb').disabled = !s.pin_any || (k === 'app' && !s.app); });
    if (last && ways.querySelector('[data-way=' + last + ']')) ways.insertBefore(ways.querySelector('[data-way=' + last + ']'), ways.firstChild);
  }
  async function pickWay(b) {
    var w = b.closest('.tvv-way'), k = w.getAttribute('data-way'), opening = !w.classList.contains('on');
    Array.prototype.forEach.call(root.querySelectorAll('.tvv-way'), function (x) { x.classList.remove('on'); x.querySelector('.tvv-wayf').hidden = true; x.querySelector('.tvv-wayb').setAttribute('aria-expanded', 'false'); });
    if (!opening) return;
    w.classList.add('on'); w.querySelector('.tvv-wayf').hidden = false; b.setAttribute('aria-expanded', 'true');
    var f = w.querySelector('input'); if (f) setTimeout(function () { try { f.focus(); } catch (e) {} }, 30);
    if (k === 'email' && !w.getAttribute('data-sent')) await sendUnlockCode(b);
  }
  async function sendUnlockCode(btn) {
    var w = root.querySelector('.tvv-way[data-way=email]'); busy(btn, true);
    try { var r = await api({ do: 'unlock_code' }); w.setAttribute('data-sent', '1'); $('#tvv-umailsent').textContent = r.message; }
    catch (e) { say(e.message, { anchor: btn, bad: true }); } finally { busy(btn, false); }
  }
  /** Ways 2 and 3: the code (step one), then the passkey opens this device's PIN-sealed key. */
  async function pinUnlock(how, btn) {
    var code = ($(how === 'app' ? '#tvv-uapp' : '#tvv-umail').value || '').replace(/\D/g, '');
    if (!/^\d{6,8}$/.test(code)) return say('Enter the 6-digit code.', { anchor: btn, bad: true });
    busy(btn, true);
    try {
      await api({ do: 'unlock_step', how: how, code: code });
      var r = await checkPasskey();
      if (r.locked) {
        if (!(await TvAsk.confirm('Your vault was locked (from a vault email, the admin, or by itself after many passwords). Unlock it now?', { anchor: btn, yes: 'Unlock it' }))) return;
        await api({ do: 'release' });
      }
      if (!r.pin) throw new Error(r.has_pin ? 'That check ran out. Enter a new code.' : 'PIN unlock isn\'t on for the passkey you used. Use your passphrase (way 1) on this device once and it turns on, or use the device it\'s on.');
      if (!st.prfOut) throw new Error('This browser didn\'t give the passkey\'s secret this time. Try again, or use your passphrase.');
      var raw;
      try { raw = await open(await hkdf(new Uint8Array(st.prfOut), PININFO), r.pin, 'vault'); }
      catch (e) { throw new Error('This device\'s PIN key didn\'t open the vault. Use your passphrase (way 1); that sets PIN unlock up again.'); }
      st.pass = null; await useVault(raw);
      $(how === 'app' ? '#tvv-uapp' : '#tvv-umail').value = ''; root.querySelector('.tvv-way[data-way=email]').removeAttribute('data-sent'); $('#tvv-umailsent').textContent = '';
      try { localStorage.setItem('tvv-way', how); } catch (e) {}
      api({ do: 'opened', how: how }).catch(function () {});
      if (r.rotate) { show('unlock'); status('Your recovery words were used: open the vault with your passphrase (way 1) to save new ones.', 'bad', 'New words:'); forget(); return; }
      await openMain();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  /** After a passphrase unlock on a device whose passkey gives its secret: seal a PIN copy for ways 2 and 3 (announced). */
  async function pinOn(r) {
    if (!st.prfOut || r.has_pin) return;
    try { await api({ do: 'set_pin_slot', slot: await seal(await hkdf(new Uint8Array(st.prfOut), PININFO), st.vkRaw, 'vault') }); say('PIN unlock is on for this device: next time, way 2 or 3 and your PIN open the vault. Turn it off under Devices.', {}); }
    catch (e) {}
  }

  // Way 1: the passkey, then the passphrase opens this device's sealed vault key.
  async function unlock(btn) {
    var pass = $('#tvv-pass').value;
    if (!pass) return say('Enter your vault passphrase.', { anchor: btn, bad: true });
    busy(btn, true);
    try {
      var r = await checkPasskey();
      if (r.locked) {
        if (!(await TvAsk.confirm('Your vault was locked (from a vault email, the admin, or by itself after many passwords). Unlock it now?', { anchor: btn, yes: 'Unlock it' }))) return;
        await api({ do: 'release' });
      }
      if (!r.slot) { show('nokeys'); status('This device\'s passkey is saved but it can\'t open the vault yet.', 'info', 'Not yet:'); return; }
      var salt = unb64u(r.slot.salt), bits = await passBits(pass, salt, r.slot.iter);
      var raw;
      try { raw = await open(await slotKey(bits, r.slot.prf ? st.prfOut : null), r.slot, 'vault'); }
      catch (e) { throw new Error(r.slot.prf && !st.prfOut ? 'This browser didn\'t give the passkey\'s secret this time. Try again, or use the same browser you set it up in.' : 'That passphrase didn\'t open the vault.'); }
      st.pass = { bits: bits, salt: salt, iter: r.slot.iter };
      await useVault(raw);
      if (!r.slot.prf && st.prfOut) { try { await api({ do: 'set_slot', slot: await makeSlot(st.prfOut) }); } catch (e) {} }   // a key given by another device: now tied to this passkey too
      $('#tvv-pass').value = '';
      try { localStorage.setItem('tvv-way', 'pass'); } catch (e) {}
      api({ do: 'opened', how: 'pass' }).catch(function () {});
      await pinOn(r);
      if (r.rotate) { var w = await newWords(); kit(w.words, w.box, 'rotate'); status('Your recovery words were used, so they no longer work. Save these new ones before the vault opens.', 'bad', 'New words:'); return; }
      await openMain();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // A new device: an emailed code (and the authenticator app's, if the vault has one), then a passkey here. It opens nothing until given the key.
  async function sendCode(btn) { busy(btn, true); try { say((await api({ do: 'add_code' })).message, { anchor: btn }); } catch (e) { say(e.message, { anchor: btn, bad: true }); } finally { busy(btn, false); } }
  async function addDevice(btn) {
    if (!/^\d{6}$/.test($('#tvv-code').value.replace(/\D/g, ''))) return say('Enter the 6-digit code from the email (or send one first).', { anchor: btn, bad: true });
    busy(btn, true);
    try {
      var made = await createPasskey('device');
      await api({ do: 'add', credential: made.credential, label: $('#tvv-dlabel').value, prf: made.prf, code: $('#tvv-code').value, app: $('#tvv-dapp').value });
      say('This device is added. Open the vault from a device that has it to give this one the key, or use your recovery words.', { anchor: btn });
      $('#tvv-code').value = $('#tvv-dapp').value = ''; show('nokeys'); status('This device\'s passkey is saved but it can\'t open the vault yet.', 'info', 'Not yet:');
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // Recovery: the 24 words open the vault key; a passphrase for this device; new words at once (the old ones are dead).
  async function recover(btn) {
    var p1 = $('#tvv-rp1'), p2 = $('#tvv-rp2'), ent;
    try { ent = await fromWords($('#tvv-words').value); } catch (e) { return say(e.message, { anchor: btn, bad: true }); }
    if (st.state && st.state.app && !/^\d{6}$/.test($('#tvv-rapp').value.replace(/\D/g, ''))) return say('Enter the code your authenticator app shows for Traversence Vault.', { anchor: btn, bad: true });
    if (!passOk(p1, p2, null, btn)) return;
    if (!(await TvAsk.confirm('Using your words retires them: you\'ll save 24 new words straight after. Go ahead?', { anchor: btn, yes: 'Use my words' }))) return;
    busy(btn, true);
    try {
      await checkPasskey();
      var box = (await api({ do: 'recovery_key', app: $('#tvv-rapp').value })).recovery, raw;
      try { raw = await open(await wordsKey(ent, unb64u(box.salt)), box, 'vault'); } catch (e) { throw new Error('Those words aren\'t this vault\'s current words. (Trying them still retires the current ones, so you\'ll be asked for new words when you next open the vault.)'); }
      wipe(ent); $('#tvv-words').value = ''; $('#tvv-rapp').value = '';
      var salt = rnd(16); st.pass = { bits: await passBits(p1.value, salt, ITER), salt: salt, iter: ITER };
      p1.value = p2.value = '';
      await useVault(raw);
      await api({ do: 'set_slot', slot: await makeSlot(st.prfOut) });
      var w = await newWords(); kit(w.words, w.box, 'rotate');
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // The Emergency Kit: shown once, downloaded or printed, never sent anywhere; saved only after three words are typed back.
  var kitWords = null, kitBox = null, kitMode = '', kitAsk = [];
  function kit(words, box, mode) {
    kitWords = words; kitBox = box; kitMode = mode;
    $('#tvv-kitwords').innerHTML = words.map(function (w, i) { return '<li><span>' + (i + 1) + '</span>' + esc(w) + '</li>'; }).join('');
    var pick = []; while (pick.length < 3) { var n = 1 + (rnd(1)[0] % 24); if (pick.indexOf(n) < 0) pick.push(n); } kitAsk = pick.sort(function (a, b) { return a - b; });
    $('#tvv-kitcheck').innerHTML = kitAsk.map(function (n, i) { return '<label class="tvv-f tvv-kw"><span>Word ' + n + '</span><input type="text" id="tvv-kc' + i + '" autocomplete="off" autocapitalize="none" spellcheck="false"></label>'; }).join('');
    $('#tvv-kitlist').hidden = false; $('#tvv-kitverify').hidden = true; show('kit');
    if (mode === 'setup') status('Your 24 recovery words: the only way back in if you lose your devices or forget your passphrase. Save them, then type three back.', 'bad', 'Step 3 of 5:');
    else status('Save your new recovery words now: they\'re shown only this once, and the old ones stop working when these are saved.', 'bad', 'Important:');
  }
  function kitText() {
    var d = new Date();
    return 'TRAVERSENCE VAULT: EMERGENCY KIT\n\nFor: ' + st.me + '\nMade: ' + d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short' }) + '\n\nYour 24 recovery words, in order:\n\n'
      + kitWords.map(function (w, i) { return (i + 1 < 10 ? ' ' : '') + (i + 1) + '. ' + w; }).join('\n')
      + '\n\nThese words open your vault if you lose your devices or forget your passphrase. Using them retires them: you get new ones at once.\n'
      + 'Keep this offline (printed, or on a drive you keep safe). Never email it, photograph it or store it in the cloud.\n'
      + 'Traversence can\'t open your vault and keeps nothing that could. Lost words with no other device means a lost vault.\n';
  }
  function kitDownload() {
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([kitText()], { type: 'text/plain' }));
    a.download = 'Traversence-Vault-Emergency-Kit.txt'; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  function kitNext() { $('#tvv-kitlist').hidden = true; $('#tvv-kitverify').hidden = false; var f = $('#tvv-kc0'); if (f) f.focus(); }
  function kitBack() { $('#tvv-kitlist').hidden = false; $('#tvv-kitverify').hidden = true; }
  async function kitDone(btn) {
    for (var i = 0; i < kitAsk.length; i++) {
      if ($('#tvv-kc' + i).value.trim().toLowerCase() !== kitWords[kitAsk[i] - 1]) return say('Word ' + kitAsk[i] + ' doesn\'t match. Check your saved copy (Back shows the words again).', { anchor: btn, bad: true });
    }
    busy(btn, true);
    try {
      var run = async function () {
        if (kitMode === 'setup') await api({ do: 'setup', slot: await makeSlot(st.prfOut), recovery: kitBox });
        else await api({ do: 'new_recovery', recovery: kitBox });
      };
      try { await run(); } catch (x) { if (x.code !== 'vault_fresh') throw x; await checkPasskey(); await run(); }
      kitWords = kitBox = null; $('#tvv-kitwords').innerHTML = ''; $('#tvv-kitcheck').innerHTML = '';
      if (kitMode === 'setup') { st.state = (await api({ do: 'state' })).state; status('Your vault is made and your words are saved. Two extra checks are recommended; you can add them later too.', 'ok', 'Step 3 done:'); show('extra'); drawApp(); }
      else await openMain();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // ---- extra checks: the authenticator app (for new devices and recovery) and a spare passkey ---------------------------------
  function drawApp() {
    var on = st.state && st.state.app;
    $('#tvv-appon').hidden = !on; $('#tvv-appoff').hidden = !!on; $('#tvv-appnew').hidden = true;
  }
  async function appStart(btn, fresh) {
    busy(btn, true);
    try {
      var run = function () { return api({ do: 'app_start', fresh: fresh ? 1 : 0 }); }, r;
      try { r = await run(); } catch (x) { if (x.code !== 'vault_fresh') throw x; await checkPasskey(); r = await run(); }
      $('#tvv-appqr').innerHTML = r.qr; $('#tvv-appkey').textContent = r.key; $('#tvv-appnew').hidden = false; $('#tvv-appoff').hidden = true; $('#tvv-appcode').focus();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  async function appAdd(btn) {
    busy(btn, true);
    try {
      say((await api({ do: 'app_add', code: $('#tvv-appcode').value })).message, { anchor: btn });
      $('#tvv-appcode').value = ''; $('#tvv-appqr').innerHTML = ''; $('#tvv-appkey').textContent = '';
      st.state = (await api({ do: 'state' })).state; appBoxes(); drawApp(); if (st.vk) loadLog();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  async function appRemove(btn) {
    var code = await TvAsk.ask('The code your authenticator app shows now', '');
    if (code == null) return;
    busy(btn, true);
    try { say((await api({ do: 'app_remove', code: String(code) })).message, { anchor: btn }); st.state = (await api({ do: 'state' })).state; appBoxes(); drawApp(); }
    catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  /** The extra checks' boxes live in one place at a time: the setup step (#tvv-extra) or the open vault's side panel. */
  function moveExtra(to) { var from = to === '#tvv-extrabody' ? $('#tvv-extra') : $('#tvv-extrabody'), dest = $(to), first = $('#tvv-extra > .tvv-row');
    Array.prototype.slice.call(from.querySelectorAll(':scope > .tvv-box')).forEach(function (b) { if (to === '#tvv-extra') dest.insertBefore(b, first); else dest.appendChild(b); }); }
  async function extraDone() { st.setupMode = false; await openMain(); }
  /** The extra checks (the authenticator app, a spare passkey) live under Devices once the vault is open (Jason, 2026-11-12). */
  function toExtra() { moveExtra('#tvv-extrabody'); drawApp(); var d = $('#tvv-devfold'); if (d) { d.open = true; d.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }

  // ---- the vault, open ---------------------------------------------------------------------------------------------------
  async function openMain() {
    keepSave(); show('main'); moveExtra('#tvv-extrabody'); drawApp(); $('#tvv-status').innerHTML = ''; poke();   // the bar at the top says it's open, and for how long
    await loadItems(); await loadDevices(); await loadLog();
    // opening the vault reconnects this browser's extension when it has let go of the key (it was connected here before)
    try { var hi = await extSend({ t: 'hello' }), was = hi && hi.install && ((st.state && st.state.ext) || []).some(function (x) { return x.install === hi.install; });
      if (hi && !hi.connected && (was || st.backTab || localStorage.getItem('tvv-ext-on') === '1')) await extOn(null, true);
      // came from the extension's Connect: back to the tab it was pressed on (the extension closes this one)
      if (st.backTab && hi) { var now = await extSend({ t: 'hello' }); if (now && now.connected) { var bt = st.backTab; st.backTab = 0; await extSend({ t: 'connected', back: bt }); } } } catch (e) {}
  }
  async function itemKey(it) { return aes(await open(st.vk, it.key, 'item')); }
  async function loadItems() {
    var list = (await api({ do: 'items' })).items, out = [];
    for (var i = 0; i < list.length; i++) {
      try { var ik = await itemKey(list[i]); var m = JSON.parse(td.decode(await open(ik, list[i].meta, 'meta'))); out.push({ id: list[i].id, site: list[i].site, name: m.name, url: m.url, user: m.user, ph: m.ph || '', updated: list[i].updated, added: list[i].added }); }
      catch (e) { out.push({ id: list[i].id, bad: true }); }
    }
    st.items = out; drawAccounts(); drawItems();
  }
  // ---- clean-up: Show (a filter), tick boxes, Select all shown, Delete selected ------------------------------------------
  var sel = {}, selMode = true, shown = [], page = 0, extra = 1, reusedCount = {};
  function siteKey(it) { try { return new URL(it.url).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
  var SHOWS = {
    all: ['All logins', function () { return true; }],
    multi: ['Sites with more than one login', function (it, n) { return n[siteKey(it)] > 1; }],
    nouser: ['No user name', function (it) { return !it.user; }],
    http: ['Not secure (http://)', function (it) { return /^http:/.test(it.url || ''); }],
    // the same password on more than one login, found from each login's sealed mark (nothing is opened to compare)
    reused: ['Reused passwords', function (it, n, r) { return !!it.ph && r[it.ph] > 1; }]
  };
  function drawShow() {
    var n = {}, r = {}; st.items.forEach(function (it) { var k = siteKey(it); n[k] = (n[k] || 0) + 1; if (it.ph) r[it.ph] = (r[it.ph] || 0) + 1; }); reusedCount = r;
    var cur = $('#tvv-showsel').value || 'all';
    $('#tvv-showsel').innerHTML = Object.keys(SHOWS).map(function (k) { var c = st.items.filter(function (it) { return !it.bad && SHOWS[k][1](it, n, r); }).length; return '<option value="' + k + '"' + (k === cur ? ' selected' : '') + '>Show: ' + esc(SHOWS[k][0]) + ' (' + c + ')</option>'; }).join('');
    return n;
  }
  /** Selecting: a tick box on every login and one for the page; while any are ticked, the selection bar takes the
   *  toolbar's place (how many, select all matching, Delete, × or Esc to clear). */
  function pageIds() { return Array.prototype.map.call(root.querySelectorAll('#tvv-items [data-sel]'), function (x) { return +x.getAttribute('data-sel'); }); }
  function drawSel() {
    var c = Object.keys(sel).length, on = pageIds(), n = on.filter(function (id) { return sel[id]; }).length;
    $('#tvv-selbar').hidden = !c; $('#tvv-thc').hidden = !!c;   // the column names give way to the selection while any are ticked
    $('#tvv-selcount').textContent = c >= shown.length && c > 1 ? 'All ' + c + ' selected.' : c + ' selected.';
    $('#tvv-seldel').querySelector('span').textContent = 'Delete (' + c + ')';
    var all = $('#tvv-selall'); all.hidden = !c || c >= shown.length; all.textContent = 'Select all ' + shown.length + ' ' + (shown.length === st.items.length ? 'logins' : 'matching');
    Array.prototype.forEach.call(root.querySelectorAll('.tvv-pageall'), function (b) { b.checked = on.length > 0 && n === on.length; b.indeterminate = n > 0 && n < on.length; });
  }
  function pageAll(box) { var ids = pageIds(), to = box.checked; ids.forEach(function (id) { if (to) sel[id] = 1; else delete sel[id]; }); Array.prototype.forEach.call(root.querySelectorAll('#tvv-items [data-sel]'), function (x) { x.checked = !!sel[+x.getAttribute('data-sel')]; }); drawSel(); }
  function drawAccounts() {   // the account box suggests every user name in the vault, with how many logins use it
    var c = {}; st.items.forEach(function (it) { if (it.user) c[it.user] = (c[it.user] || 0) + 1; var k = siteKey(it); if (k) c[k] = (c[k] || 0) + 1; });
    $('#tvv-accts').innerHTML = Object.keys(c).sort(function (a, b) { return c[b] - c[a] || a.localeCompare(b); }).slice(0, 500).map(function (u) { return '<option value="' + esc(u) + '">' + c[u] + ' login' + (c[u] === 1 ? '' : 's') + '</option>'; }).join('');
  }
  /** The list in pages (Jason, 2026-11-12): 10 a page by default; "Show 10 more" adds the next page under these; the bar
   *  under it has ‹ pages › and how many a page. mode: undefined = a new search or filter (back to page 1), 'more', 'page'. */
  function pageBtn(p, label, cur, aria, off) { return '<button type="button" class="tvv-pg" data-tvv="pg" data-p="' + p + '"' + (cur ? ' aria-current="page"' : '') + (off ? ' disabled' : '') + ' aria-label="' + esc(aria) + '">' + label + '</button>'; }
  function drawPager(total, per, from, to) {
    var pg = $('#tvv-pager'); pg.hidden = total <= 10;   // 10 or fewer: no page bar (Jason, 2026-11-12)
    var pages = per ? Math.ceil(total / per) : 1, a = per ? Math.floor(from / per) : 0, z = per ? Math.ceil(to / per) - 1 : 0, h = [];
    if (pages > 1) {
      h.push(pageBtn(a - 1, '‹', false, 'Previous page', a <= 0));
      var want = {}; [0, pages - 1, a - 1, z + 1].forEach(function (x) { if (x >= 0 && x < pages) want[x] = 1; }); for (var x = a; x <= z; x++) want[x] = 1;
      var last = -1; Object.keys(want).map(Number).sort(function (m, n) { return m - n; }).forEach(function (x) {
        if (last >= 0 && x > last + 1) h.push('<span class="tvv-gap" aria-hidden="true">…</span>');
        h.push(pageBtn(x, x + 1, x >= a && x <= z, 'Page ' + (x + 1))); last = x;
      });
      h.push(pageBtn(z + 1, '›', false, 'Next page', z >= pages - 1));
    }
    $('#tvv-pages').innerHTML = h.join('');
    $('#tvv-range').textContent = total ? (from + 1) + '–' + to + ' of ' + total : '';
  }
  function drawItems(mode) {
    var per = +($('#tvv-per').value || 0);
    if (!mode) { page = 0; extra = 1; } else if (mode === 'more') extra++; else if (mode === 'page') extra = 1;   // 'keep': as it is (ticking, selecting)
    // one search box: the site, the login's name, its address or the account (user name or email)
    var q = ($('#tvv-q').value || '').trim().toLowerCase(), box = $('#tvv-items'), n = drawShow(), f = SHOWS[$('#tvv-showsel').value || 'all'] || SHOWS.all;
    var rows = st.items.filter(function (it) { return it.bad || ((!q || (it.name + ' ' + it.url + ' ' + (it.user || '') + ' ' + siteKey(it)).toLowerCase().indexOf(q) >= 0) && f[1](it, n, reusedCount)); })
      .sort(sorter());
    shown = rows.filter(function (it) { return !it.bad; }).map(function (it) { return it.id; });
    var all = rows, total = all.length, from = 0, to = total;
    if (per) { var pages = Math.max(1, Math.ceil(total / per)); if (page > pages - 1) page = pages - 1; from = page * per; to = Math.min(total, from + per * extra); rows = rows.slice(from, to); }
    var more = total - to; $('#tvv-more').hidden = more <= 0; $('#tvv-more').textContent = 'Show ' + Math.min(more, per || more) + ' more';
    drawPager(total, per, from, to);
    $('#tvv-count').textContent = st.items.length ? (shown.length === st.items.length ? st.items.length + ' login' + (st.items.length === 1 ? '' : 's') : shown.length + ' of ' + st.items.length + ' logins match') + '' : '';
    $('#tvv-lcount').textContent = '(' + st.items.length + ')';
    drawSel();
    drawHead();
    if (!rows.length) { box.innerHTML = '<div class="tvv-tr"><div class="tvv-full"><p data-tv-status="info" data-tv-label="Empty:">' + (st.items.length ? 'Nothing matches.' : 'No logins yet: add your first with +.') + '</p></div></div>'; statuses(box); drawSel(); return; }
    var cols = colsOn();
    box.innerHTML = rows.map(function (it) {
      if (it.bad) return '<div class="tvv-tr"><div class="tvv-full"><p data-tv-status="bad" data-tv-label="Can\'t open:">Item ' + it.id + ' didn\'t open with this vault\'s key (it may have been changed on the server).</p></div></div>';
      var host = ''; try { host = new URL(it.url).host; } catch (e) {}
      return '<div class="tvv-tr tv-bleed" role="row" data-id="' + it.id + '"><label class="tvv-tick tvv-c0" title="Select"><input type="checkbox" data-sel="' + it.id + '"' + (sel[it.id] ? ' checked' : '') + ' aria-label="Select ' + esc(it.name) + '"></label>'
        + '<div class="tvv-c tvv-site" role="cell"><a class="tvv-name" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer" title="Sign in at ' + esc(it.url) + '">' + esc(it.name) + '</a><span class="tvv-sub">' + esc(host) + '</span></div>'
        + cols.map(function (k) { return '<div class="tvv-c tvv-opt" role="cell" data-label="' + esc(COLS[k][0]) + '">' + COLS[k][3](it) + '</div>'; }).join('')
        + '<div class="tvv-r" role="cell">' + ICON('copy', 'Copy the password', 'copy') + ICON('eye', 'Show the password for 10 seconds', 'show') + ICON('user', 'Copy the user name', 'user') + ICON('pen', 'Change it', 'edit') + ICON('trash', 'Delete it', 'del') + '</div>'
        + '<div class="tvv-show" hidden></div></div>';
    }).join('');
    statuses(box); drawSel();
  }
  // ---- the list as a table (Jason, 2026-11-12): a header with the page's tick box, sortable columns, and Columns to
  // choose the optional ones (kept in this browser). Password strength isn't one: it would mean opening every password.
  function dshort(iso) { var d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }); }
  var COLS = {   // key => [name, width, on at first, cell, sort value]
    user: ['Account', 'minmax(9rem,1.2fr)', true, function (it) { return it.user ? esc(it.user) : '<span class="tvv-sub">none</span>'; }, function (it) { return String(it.user || '').toLowerCase(); }],
    changed: ['Last changed', '10.5rem', true, function (it) { return esc(when(it.updated)); }, function (it) { return it.updated || ''; }],
    added: ['Added', '10.5rem', false, function (it) { return esc(when(it.added)); }, function (it) { return it.added || ''; }],
    addr: ['Sign-in address', 'minmax(10rem,1.4fr)', false, function (it) { var p = ''; try { var u = new URL(it.url); p = u.host + u.pathname; } catch (e) {} return '<span title="' + esc(it.url) + '">' + esc(p) + '</span>'; }, function (it) { return String(it.url || '').toLowerCase(); }],
    warn: ['Watch for', 'minmax(7rem,.9fr)', false, function (it) { var f = []; if (it.ph && reusedCount[it.ph] > 1) f.push('<span class="tvv-flag bad">Reused</span>'); if (/^http:/.test(it.url || '')) f.push('<span class="tvv-flag bad">Not secure</span>'); if (!it.user) f.push('<span class="tvv-flag">No user name</span>'); return f.join('') || '<span class="tvv-sub">—</span>'; },
      function (it) { return (it.ph && reusedCount[it.ph] > 1 ? 0 : 1) + (/^http:/.test(it.url || '') ? 0 : 1) + (it.user ? 1 : 0); }]
  };
  var sortBy = 'site', sortDir = 1;
  try { var sv = JSON.parse(localStorage.getItem('tvv-sort') || 'null'); if (sv && (sv[0] === 'site' || COLS[sv[0]])) { sortBy = sv[0]; sortDir = sv[1] === -1 ? -1 : 1; } } catch (e) {}
  function colsOn() {
    var on = null; try { on = JSON.parse(localStorage.getItem('tvv-cols') || 'null'); } catch (e) {}
    return Object.keys(COLS).filter(function (k) { return on ? on.indexOf(k) >= 0 : COLS[k][2]; });
  }
  function sorter() {
    var site = function (it) { return String(it.name || '').toLowerCase() + ' ' + siteKey(it); };   // by the name shown, then its site
    var f = sortBy === 'site' ? site : COLS[sortBy][4];
    return function (a, b) { var x = f(a), y = f(b); return (x < y ? -1 : x > y ? 1 : 0) * sortDir || site(a).localeCompare(site(b)) || String(a.user || '').localeCompare(String(b.user || '')); };
  }
  function drawHead() {
    var cols = colsOn(), t = $('#tvv-table');
    t.style.setProperty('--tvv-cols', '2.6rem minmax(12rem,1.6fr) ' + cols.map(function (k) { return COLS[k][1]; }).join(' ') + ' 12rem');   // a fixed actions column, so the header lines up with the rows
    var th = function (k, name, extra) { var on = sortBy === k; return '<button type="button" class="tvv-sort' + (extra || '') + '" data-tvv="sort" data-k="' + k + '"' + (on ? ' aria-sort="' + (sortDir > 0 ? 'ascending' : 'descending') + '"' : '') + ' title="Sort by ' + esc(name.toLowerCase()) + '">' + esc(name) + ' <i aria-hidden="true">' + (on ? (sortDir > 0 ? '↑' : '↓') : '↕') + '</i></button>'; };
    var open = !!root.querySelector('.tvv-colsdd[open]');
    $('#tvv-thc').innerHTML = th('site', 'Site') + cols.map(function (k) { return th(k, COLS[k][0], ' tvv-opt'); }).join('')
      + '<div class="tvv-thact"><span>Actions</span><details class="tvv-colsdd"' + (open ? ' open' : '') + '><summary title="Choose the columns">⚙ Columns</summary><div class="tvv-colsl">'
      + Object.keys(COLS).map(function (k) { return '<label><input type="checkbox" data-col="' + k + '"' + (cols.indexOf(k) >= 0 ? ' checked' : '') + '> ' + esc(COLS[k][0]) + '</label>'; }).join('')
      + '<p>Password strength isn\'t offered: it would mean opening every password.</p></div></details></div>';
  }
  document.addEventListener('click', function (e) { var d = root.querySelector('.tvv-colsdd[open]'); if (d && !d.contains(e.target)) d.open = false; });

  var ICONS = {}; try { ICONS = JSON.parse(root.getAttribute('data-icons') || '{}'); } catch (e) {}
  function ICON(n, t, act) { return '<button type="button" class="tvv-ib" data-act="' + act + '" title="' + esc(t) + '" aria-label="' + esc(t) + '">' + (ICONS[n] || '') + '</button>'; }
  function byId(id) { for (var i = 0; i < st.items.length; i++) if (st.items[i].id === id) return st.items[i]; return null; }

  /** One login's password: a fresh passkey check if the last was over 5 minutes ago, a token, then the sealed login. */
  async function reveal(it, how) {
    var t;
    try { t = await api({ do: 'token', id: it.id }); }
    catch (e) { if (e.code !== 'vault_fresh') throw e; await checkPasskey(); t = await api({ do: 'token', id: it.id }); }
    var r = await api({ do: 'reveal', id: it.id, token: t.token, how: how + ': ' + it.name });
    var ik = await aes(await open(st.vk, r.key, 'item'));
    try { return JSON.parse(td.decode(await open(ik, r.secret, 'login:' + loginAddr(it.url)))); }
    catch (e) { throw new Error('This login is sealed to another address than the one shown, so it wasn\'t opened. It may have been tampered with.'); }
  }
  var clipTimer = 0;
  async function copy(text, btn, what) {
    await navigator.clipboard.writeText(text);
    say(what + ' copied. The clipboard clears in 30 seconds.', { anchor: btn });
    clearTimeout(clipTimer); clipTimer = setTimeout(function () { navigator.clipboard.writeText('').catch(function () {}); }, 30000);
  }
  /** A shown password: gone after 10 seconds, or at once with its × (or the eye again). */
  function hidePass(card) { var sh = card && card.querySelector('.tvv-show'); if (!sh) return; clearInterval(sh._t); sh.innerHTML = ''; sh.hidden = true; var e = card.querySelector('[data-act=show]'); if (e) e.removeAttribute('aria-pressed'); }
  async function onItem(e) {
    var b = e.target.closest('button[data-act]'); if (!b) return;
    var card = b.closest('[data-id]'), it = byId(+card.getAttribute('data-id')), act = b.getAttribute('data-act'); if (!it) return;
    poke();
    if (act === 'user') { if (!it.user) return say('No user name saved.', { anchor: b, bad: true }); return copy(it.user, b, 'User name').catch(function (x) { say(x.message, { anchor: b, bad: true }); }); }
    if (act === 'edit') return editItem(it);
    if (act === 'hide') return hidePass(card);
    if (act === 'show' && !card.querySelector('.tvv-show').hidden) return hidePass(card);   // the eye again hides it
    if (act === 'del') {
      if (!TvAsk.gate(b, 'Delete the login for ' + it.name + '?', { yes: 'Delete', danger: true })) return;
      busy(b, true); try { await api({ do: 'delete', id: it.id }); await loadItems(); say('Deleted.', { anchor: $('#tvv-add') }); } catch (x) { say(x.message, { anchor: b, bad: true }); } finally { busy(b, false); }
      return;
    }
    busy(b, true);
    try {
      var s = await reveal(it, act === 'copy' ? 'Password copied' : 'Password shown');
      if (act === 'copy') await copy(s.pass || '', b, 'Password');
      else {
        var sh = card.querySelector('.tvv-show'), left = 10; hidePass(card);
        sh.innerHTML = '<span class="tvv-pw"></span><span class="tvv-pwt" aria-hidden="true">10s</span><button type="button" class="tvv-pwx" data-act="hide" aria-label="Hide the password" title="Hide">×</button>';
        sh.querySelector('.tvv-pw').textContent = s.pass || '(no password)'; sh.hidden = false; b.setAttribute('aria-pressed', 'true');
        sh._t = setInterval(function () { left--; var t = sh.querySelector('.tvv-pwt'); if (t) t.textContent = left + 's'; if (left <= 0) hidePass(card); }, 1000);
      }
      s = null; loadLog();
    } catch (x) { say(passkeyErr(x), { anchor: b, bad: true }); }
    finally { busy(b, false); }
  }

  /** Import, Recovery words, Extra checks and the extension's install steps open as a side panel (a sheet from the
   *  bottom on a phone), one at a time, over the vault; × , the shade, Esc or the same button again closes it. */
  var PANELS = ['#tvv-import', '#tvv-wordspanel', '#tvv-extpanel', '#tvv-form', '#tvv-notifypanel'], panelFrom = null;
  function panelsShut() { var fp = $('#tvv-fpass'); if (fp) fp.value = '';  /* a password typed into the form never outlives it */ PANELS.forEach(function (x) { var p = $(x); if (p) p.hidden = true; }); var sh = $('#tvv-shade'); if (sh) sh.hidden = true; document.documentElement.style.overflow = ''; if (panelFrom) { try { panelFrom.focus(); } catch (e) {} panelFrom = null; } }
  function panel(id) {
    var b = $(id), open = b.hidden, from = document.activeElement;
    panelsShut(); if (!open) return;
    panelFrom = from; b.hidden = false; $('#tvv-shade').hidden = false; document.documentElement.style.overflow = 'hidden';
    b.scrollTop = 0; var x = b.querySelector('.tvv-x'); if (x) setTimeout(function () { try { x.focus(); } catch (e) {} }, 30);
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !warnBox && Object.keys(sel).length && PANELS.every(function (x) { var p = $(x); return !p || p.hidden; })) { selNone(); return; } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !warnBox && PANELS.some(function (x) { var p = $(x); return p && !p.hidden; })) panelsShut(); });
  function selAll() { shown.forEach(function (id) { sel[id] = 1; }); drawItems('keep'); }
  function selNone() { sel = {}; drawItems('keep'); }
  async function selDelete(btn) {
    var ids = Object.keys(sel).map(Number); if (!ids.length) return;
    if (!TvAsk.gate(btn, 'Delete ' + ids.length + ' login' + (ids.length === 1 ? '' : 's') + ' from your vault? This can\'t be undone.', { yes: 'Delete (' + ids.length + ')', danger: true })) return;
    busy(btn, true);
    try {
      var run = function () { return api({ do: 'delete_many', ids: ids }); }, r;
      try { r = await run(); } catch (x) { if (x.code !== 'vault_fresh') throw x; await checkPasskey(); r = await run(); }
      sel = {}; await loadItems(); say(r.message, { anchor: $('#tvv-add') }); loadLog();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // Add or change a login. Changing one needs its password opened first (a reveal, announced like any other).
  var editing = 0;
  async function editItem(it) {
    var f = $('#tvv-form'); editing = it ? it.id : 0;
    $('#tvv-fname').value = it ? it.name : ''; $('#tvv-furl').value = it ? it.url : ''; $('#tvv-fuser').value = it ? it.user || '' : ''; $('#tvv-fpass').value = ''; $('#tvv-fnotes').value = '';
    $('#tvv-ftitle').textContent = it ? 'Change ' + it.name : 'Add a login';
    if (f.hidden) panel('#tvv-form'); setTimeout(function () { try { $('#tvv-fname').focus(); } catch (e) {} }, 60);   // a side panel, like Import
    if (it) { try { var s = await reveal(it, 'Opened to change'); $('#tvv-fpass').value = s.pass || ''; $('#tvv-fnotes').value = s.notes || ''; } catch (x) { say(passkeyErr(x), { anchor: $('#tvv-fsave'), bad: true }); } }
  }
  async function saveItem(btn) {
    var name = $('#tvv-fname').value.trim(), url, user = $('#tvv-fuser').value.trim(), pass = $('#tvv-fpass').value, notes = $('#tvv-fnotes').value;
    if (!name) return say('Give it a name (the company or service).', { anchor: btn, bad: true });
    try { url = loginAddr($('#tvv-furl').value.trim()); } catch (e) { return say('Enter the page where you sign in, like https://dash.cloudflare.com/login.', { anchor: btn, bad: true }); }
    if (!/^https:/.test(url) && !(await TvAsk.confirm('That address isn\'t https, so the password would travel unprotected there. Save it anyway?', { anchor: btn, yes: 'Save anyway' }))) return;
    busy(btn, true);
    try {
      var ikRaw = rnd(32), ik = await aes(ikRaw);
      var body = { do: 'save', id: editing, site: await siteOf(url), key: await seal(st.vk, ikRaw, 'item'),
        meta: await seal(ik, te.encode(JSON.stringify({ name: name, url: url, user: user, ph: hex(await S.sign('HMAC', st.siteKey, te.encode('pw:' + pass))).slice(0, 32) })), 'meta'),
        secret: await seal(ik, te.encode(JSON.stringify({ user: user, pass: pass, notes: notes })), 'login:' + url) };
      wipe(ikRaw);
      try { await api(body); } catch (e) { if (e.code !== 'vault_fresh') throw e; await checkPasskey(); await api(body); }
      panelsShut(); $('#tvv-fnotes').value = '';
      await loadItems(); say(editing ? 'Changed.' : 'Saved.', { anchor: $('#tvv-add') }); loadLog();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  function generate() {
    var set = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!#$%&*+-=?@^_', out = '', b = rnd(64);
    for (var i = 0; out.length < 20 && i < b.length; i++) if (b[i] < 256 - (256 % set.length)) out += set[b[i] % set.length];
    var p = $('#tvv-fpass'); p.value = out; p.classList.remove('tvv-mask'); setTimeout(function () { p.classList.add('tvv-mask'); }, 10000);
  }

  // ---- import: a Google Password Manager or 1Password export (CSV), read and sealed here; the file never leaves this browser ----
  function csvRows(text) {
    var rows = [], row = [], f = '', q = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; continue; }
      if (c === '"') q = true; else if (c === ',') { row.push(f); f = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(f); f = ''; if (row.some(function (x) { return x !== ''; })) rows.push(row); row = []; } else f += c;
    }
    row.push(f); if (row.some(function (x) { return x !== ''; })) rows.push(row);
    return rows;
  }
  var pending = null;
  function importRead(input) {
    var file = input.files && input.files[0]; if (!file) return;
    var r = new FileReader();
    r.onload = function () {
      var rows = csvRows(String(r.result).replace(/^\uFEFF/, '')), head = (rows.shift() || []).map(function (h) { return h.trim().toLowerCase(); });
      var col = function (names) { for (var i = 0; i < names.length; i++) { var k = head.indexOf(names[i]); if (k >= 0) return k; } return -1; };
      var cN = col(['name', 'title']), cU = col(['url', 'website', 'login_uri', 'login url', 'urls']), cL = col(['username', 'login', 'user', 'login_username', 'email']), cP = col(['password', 'login_password']), cT = col(['note', 'notes', 'notesplain']);
      input.value = '';
      if (cU < 0 || cP < 0) { pending = null; $('#tvv-impsum').textContent = 'That file has no url and password columns. Use the CSV file from Google Password Manager (Export passwords) or 1Password (Export, CSV).'; $('#tvv-impgo').hidden = true; return; }
      var have = {}; st.items.forEach(function (it) { try { have[new URL(it.url).origin + '|' + (it.user || '')] = 1; } catch (e) {} });
      var out = [], dup = 0, bad = 0;
      rows.forEach(function (x) {
        var url = (x[cU] || '').trim(), pass = x[cP] || '', u;
        try { u = loginAddr(url); } catch (e) { bad++; return; }
        if (!pass || !/^https?:/.test(url)) { bad++; return; }
        var user = cL >= 0 ? (x[cL] || '').trim() : '';
        if (have[new URL(u).origin + '|' + user]) { dup++; return; }
        have[new URL(u).origin + '|' + user] = 1;
        out.push({ name: (cN >= 0 && (x[cN] || '').trim()) || new URL(u).hostname.replace(/^www\./, ''), url: u, user: user, pass: pass, notes: cT >= 0 ? (x[cT] || '') : '' });
      });
      pending = out;
      $('#tvv-impsum').textContent = out.length + ' login' + (out.length === 1 ? '' : 's') + ' ready to add' + (dup ? ', ' + dup + ' already in your vault (left as they are)' : '') + (bad ? ', ' + bad + ' skipped (no web address or password, e.g. phone apps)' : '') + '.';
      $('#tvv-implist').innerHTML = out.slice(0, 200).map(function (it) { return '<li>' + esc(it.name) + ' <span class="tvv-sub">' + esc(new URL(it.url).host) + (it.user ? ' · ' + esc(it.user) : '') + '</span></li>'; }).join('');
      $('#tvv-impgo').hidden = !out.length;
    };
    r.readAsText(file);
  }
  async function importGo(btn) {
    if (!pending || !pending.length) return;
    busy(btn, true);
    var done = 0, fail = 0, list = pending; pending = null;
    try {
      for (var i = 0; i < list.length; i++) {
        var it = list[i], ikRaw = rnd(32), ik = await aes(ikRaw);
        var body = { do: 'save', id: 0, site: await siteOf(it.url), key: await seal(st.vk, ikRaw, 'item'),
          meta: await seal(ik, te.encode(JSON.stringify({ name: it.name, url: it.url, user: it.user, ph: hex(await S.sign('HMAC', st.siteKey, te.encode('pw:' + it.pass))).slice(0, 32) })), 'meta'),
          secret: await seal(ik, te.encode(JSON.stringify({ user: it.user, pass: it.pass, notes: it.notes })), 'login:' + it.url) };
        wipe(ikRaw); it.pass = '';
        try { try { await api(body); } catch (x) { if (x.code !== 'vault_fresh') throw x; await checkPasskey(); await api(body); } done++; }
        catch (x) { fail++; }
        $('#tvv-impsum').textContent = 'Adding… ' + (i + 1) + ' of ' + list.length; poke();
      }
      $('#tvv-implist').innerHTML = ''; $('#tvv-impgo').hidden = true;
      $('#tvv-impsum').textContent = done + ' added' + (fail ? ', ' + fail + ' couldn\'t be added (try those by hand)' : '') + '. Now delete the exported file and empty your Recycle Bin: it holds every password unprotected.';
      say(done + ' logins added to your vault.', { anchor: btn }); await loadItems(); loadLog();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); list.length = 0; }
  }

  // Devices: the passkeys that can open it, and ones waiting for the key.
  async function loadDevices() {
    st.state = (await api({ do: 'state' })).state; st.devices = st.state.devices;
    $('#tvv-devices').innerHTML = st.devices.map(function (d) {
      return '<li data-cred="' + d.id + '"><span class="tvv-lt"><b>' + esc(d.label) + '</b><span class="tvv-sub">added ' + when(d.created_at + 'Z') + (d.used_at ? ', last used ' + when(d.used_at + 'Z') : '') + (+d.prf ? '' : ', passphrase only') + (+d.pin ? ' · PIN unlock on' : '') + '</span></span>'
        + (+d.pin ? '<button type="button" class="ak-b" data-dev="pinoff">Turn off PIN unlock</button> ' : '') + (+d.ready ? '' : '<button type="button" class="ak-b" data-dev="give">Give it the key</button> ') + '<button type="button" class="ak-b" data-dev="remove">Remove</button></li>';
    }).join('');
    drawExt();
    $('#tvv-kitdate').textContent = st.state.kit_at ? 'Your recovery words were made ' + when(st.state.kit_at + 'Z') + '.' : '';
  }
  async function onDevice(e) {
    var b = e.target.closest('button[data-dev]'); if (!b) return;
    var id = +b.closest('[data-cred]').getAttribute('data-cred'); poke();
    if (b.getAttribute('data-dev') === 'remove' && !TvAsk.gate(b, 'Remove this device from the vault?', { yes: 'Remove', danger: true })) return;
    busy(b, true);
    try {
      var act = b.getAttribute('data-dev');
      if (act === 'give' && !st.pass) throw new Error('Open the vault with your passphrase (way 1) to give another device the key.');
      var run = function () { return act === 'pinoff' ? api({ do: 'pin_off', cred: id }) : act === 'give' ? makeSlot(null).then(function (slot) { return api({ do: 'set_slot_for', cred: id, slot: slot }); }) : api({ do: 'remove_device', cred: id }); };
      var r; try { r = await run(); } catch (x) { if (x.code !== 'vault_fresh') throw x; await checkPasskey(); r = await run(); }
      say(r.message, { anchor: b }); await loadDevices(); loadLog();
    } catch (x) { say(passkeyErr(x), { anchor: b, bad: true }); }
    finally { busy(b, false); }
  }
  async function addSpare(btn) {
    busy(btn, true);
    try {
      var made = await createPasskey('spare');
      var r = await api({ do: 'add', credential: made.credential, label: $('#tvv-slabel').value || 'Spare passkey', prf: made.prf });
      await api({ do: 'set_slot_for', cred: r.cred, slot: await makeSlot(null) });
      say('Spare passkey added. It opens the vault with your passphrase.', { anchor: btn }); await loadDevices(); loadLog();
    } catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  async function rotateWords(btn) {
    if (!TvAsk.gate(btn, 'Make new recovery words? The old ones stop working at once.', { yes: 'Make new words' })) return;
    busy(btn, true);
    try { var w = await newWords(); kit(w.words, w.box, 'rotate'); }
    catch (e) { say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // ---- the browser extension: this page gives it the vault key (it keeps it in the browser's memory) and a 12-hour token ----
  function extSend(msg) {
    var id = root.getAttribute('data-ext');
    return new Promise(function (res) {
      try { if (!id || !window.chrome || !chrome.runtime || !chrome.runtime.sendMessage) return res(null); chrome.runtime.sendMessage(id, msg, function (r) { void chrome.runtime.lastError; res(r || null); }); }
      catch (e) { res(null); }
    });
  }
  /** How long an extension connection has left: "11 h 42 min left", ticking with the vault's clock. */
  function leftText(iso) {
    var m = Math.ceil((Date.parse(iso) - Date.now()) / 60000); if (!(m > 0)) return 'ended';
    return (m >= 60 ? Math.floor(m / 60) + ' h ' : '') + (m % 60 ? (m % 60) + ' min ' : '') + 'left';
  }
  function extTick() { Array.prototype.forEach.call(root.querySelectorAll('.tvv-exleft'), function (b) { var t = leftText(b.getAttribute('data-until')); if (b.textContent !== t) b.textContent = t; b.classList.toggle('low', !/h /.test(t)); }); }
  async function drawExt() {
    var box = $('#tvv-ext'); if (!box) return;
    var here = await extSend({ t: 'hello' }), list = (st.state && st.state.ext) || [];
    var inst = '<button type="button" class="ak-b' + (here ? '' : ' go') + '" data-tvv="toinstall" aria-controls="tvv-extpanel">' + (ICONS.download || '') + ' ' + (here ? 'Install steps' : 'Download and install') + '</button>';
    // this browser's row says what the extension itself says: a connection the server still lists but the extension has
    // let go of (30 minutes unused, the browser restarted) shows as not connected, with Connect (Jason, 2026-11-12)
    var h = list.map(function (x) {
      var mine = here && here.install && x.install === here.install, gone = mine && !here.connected;
      return '<li data-ext-id="' + x.id + '"' + (mine ? ' data-mine="1"' : '') + '><span class="tvv-lt"><b>' + esc(x.label) + '</b>' + (mine ? ' <span class="tvv-sub" style="display:inline">· this browser' + (here.connected && here.email ? ', ' + esc(here.email) : '') + '</span>' : '')
        + (gone ? '<span class="tvv-sub"><b style="color:#991B1B">Not connected now</b> · the extension let go of the key' + (here.ended ? ' (' + esc(here.ended.replace(/\.$/, '')) + ')' : ' (the browser was closed or restarted)') + '</span></span>'
          : '<span class="tvv-sub"><b class="tvv-exleft" data-until="' + esc(x.until_at) + 'Z">' + leftText(x.until_at + 'Z') + '</b> · until ' + when(x.until_at + 'Z') + (x.used_at ? ' · last used ' + when(x.used_at + 'Z') : '') + '</span></span>')
        + (mine ? '<button type="button" class="ak-b go" data-tvv="exton" title="12 more hours from now">' + (gone ? 'Connect' : 'Renew') + '</button>' : '') + '<button type="button" class="ak-b" data-tvv="extoff">Disconnect</button></li>';
    }).join('');
    var mineListed = here && list.some(function (x) { return here.install && x.install === here.install; });
    box.innerHTML = (h ? '<ul class="tvv-lis">' + h + '</ul>' : '')
      + (here ? '<div class="tvv-row">' + (mineListed ? '' : '<button type="button" class="ak-b go" data-tvv="exton">Connect this browser\'s extension</button>') + inst + '</div>'
        : '<p data-tv-status="info" data-tv-label="Not installed here:">It isn\'t in this browser yet (or this page was open before it was added: reload it).</p><div class="tvv-row">' + inst + '</div>');
    statuses(box);
  }
  async function extOn(btn, quiet) {
    busy(btn, true);
    try {
      var hi = await extSend({ t: 'hello' }) || {}, ua = navigator.userAgent;
      var label = (ua.indexOf('Edg/') >= 0 ? 'Edge' : 'Chrome') + (/Windows/.test(ua) ? ' on Windows' : /Mac OS X/.test(ua) ? ' on a Mac' : /CrOS/.test(ua) ? ' on a Chromebook' : /Linux/.test(ua) ? ' on Linux' : '');
      var run = function () { return api({ do: 'ext_pair', label: label, install: hi.install || '' }); }, r;
      try { r = await run(); } catch (x) { if (x.code !== 'vault_fresh') throw x; await checkPasskey(); r = await run(); }
      var ok = await extSend({ t: 'pair', vk: b64u(st.vkRaw), token: r.token, until: r.until, email: r.email, api: r.api });
      if (!ok || !ok.ok) throw new Error((ok && ok.error) || 'The extension didn\'t answer. Reload this page and try again.');
      try { localStorage.setItem('tvv-ext-on', '1'); } catch (x) {}   // connected from this browser: reconnect it on later unlocks
      if (!quiet) say('Connected. The extension fills your logins on their own sites for the next 12 hours, or until the browser closes.', { anchor: btn });
      st.state = (await api({ do: 'state' })).state; drawExt(); loadLog();
    } catch (e) { if (!quiet) say(passkeyErr(e), { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }
  async function extOff(btn) {
    var row = btn.closest('[data-ext-id]'), id = +row.getAttribute('data-ext-id'), mine = row.hasAttribute('data-mine');
    busy(btn, true);
    try { await api({ do: 'ext_remove', id: id }); if (mine) await extSend({ t: 'unpair' }); /* another browser's: this one stays connected */ say('Disconnected.', { anchor: btn }); st.state = (await api({ do: 'state' })).state; drawExt(); loadLog(); }
    catch (e) { say(e.message, { anchor: btn, bad: true }); }
    finally { busy(btn, false); }
  }

  // The record: what was done, when, from where (never what was in it).
  var ACTS = { created: 'Vault set up', device_added: 'Device added', device_ready: 'Device given the key', device_removed: 'Device removed', recovery_used: 'Recovery words used', recovery_new: 'New recovery words',
    added: 'Login added', changed: 'Login changed', deleted: 'Login deleted', revealed: 'Password opened', check_failed: 'Passkey check failed', unlocked: 'Vault unlocked',
    app_added: 'Authenticator app added', app_removed: 'Authenticator app removed', ext_paired: 'Browser extension connected', ext_removed: 'Browser extension disconnected', ext_wrong_site: 'Extension asked from the wrong site (refused)', notify_changed: 'Email settings changed', pin_on: 'PIN unlock turned on', pin_off: 'PIN unlock turned off',
    'opened:pass': 'Opened with the passphrase', 'opened:app': 'Opened with the app\'s code and PIN', 'opened:email': 'Opened with an emailed code and PIN' };
  function when(iso, zone) { return window.TvTime && TvTime.fmt ? TvTime.fmt(iso, zone || undefined) : new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }); }
  var logShown = 10;   // 10 at first, "Show 10 more" under them (Jason, 2026-11-12: no scroll box)
  async function loadLog(more) {
    if (more) logShown += 10;
    try {
      var log = (await api({ do: 'history', limit: logShown + 1 })).log, names = {}, extra = log.length > logShown; log = log.slice(0, logShown);
      $('#tvv-logmore').hidden = !extra;
      st.items.forEach(function (it) { names[it.id] = it.name; });
      $('#tvv-log').innerHTML = log.map(function (l) {
        var a = l.action.indexOf('deleted_many:') === 0 ? l.action.slice(13) + ' logins deleted at once' : l.action.indexOf('locked:') === 0 ? 'Vault locked (' + ({ owner: 'by you', link: 'from an email link', cap: 'by itself: many passwords' }[l.action.slice(7)] || l.action.slice(7)) + ')' : (ACTS[l.action] || l.action);
        return '<li><time datetime="' + esc(l.at) + '" data-tv-time data-tz="' + esc(l.tz) + '">' + esc(when(l.at, l.tz)) + '</time> ' + esc(a) + (l.item && names[l.item] ? ': ' + esc(names[l.item]) : '') + '<span class="tvv-sub"> ' + esc([l.device, l.ip].filter(Boolean).join(', ')) + '</span></li>';
      }).join('');
    } catch (e) {}
  }

  // Kept open across a reload of this tab (Jason, 2026-11-12: like a bank's sign-in): while open, the vault key is kept
  // sealed in this tab's sessionStorage (gone when the tab closes), under a key the browser holds in IndexedDB that can't
  // be read out (non-extractable), only used. It's good until the vault would close for being unused; Close, Lock, the
  // idle close and a closed server session all delete both. Another tab or browser never gets it.
  var KEEP = 'tvv-keep', keptAt = 0;
  function idb(mode, fn) {
    return new Promise(function (res, rej) {
      var q = indexedDB.open('tvv', 1);
      q.onupgradeneeded = function () { q.result.createObjectStore('k'); };
      q.onerror = function () { rej(q.error); };
      q.onsuccess = function () { var db = q.result, tx = db.transaction('k', mode), r = fn(tx.objectStore('k')); tx.oncomplete = function () { db.close(); res(r && r.result); }; tx.onerror = function () { db.close(); rej(tx.error); }; };
    });
  }
  async function keepSave() {
    try {
      if (!st.vkRaw || !window.indexedDB) return;
      var k = await S.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
      var p = te.encode(JSON.stringify({ vk: b64u(st.vkRaw), pb: st.pass ? b64u(st.pass.bits) : '', ps: st.pass ? b64u(st.pass.salt) : '', pi: st.pass ? st.pass.iter : 0 }));
      var box = await seal(k, p, 'tv-vault-keep'); wipe(p);
      await idb('readwrite', function (o) { return o.put(k, 'k'); });
      sessionStorage.setItem(KEEP, JSON.stringify({ box: box, until: Date.now() + IDLE })); keptAt = Date.now();
    } catch (e) {}
  }
  function keepTouch(now) {
    if (!now && Date.now() - keptAt < 5000) return; keptAt = Date.now();
    try { var j = JSON.parse(sessionStorage.getItem(KEEP) || 'null'); if (j) { j.until = idleAt; sessionStorage.setItem(KEEP, JSON.stringify(j)); } } catch (e) {}
  }
  function keepDrop() {
    try { sessionStorage.removeItem(KEEP); } catch (e) {}
    try { if (window.indexedDB) idb('readwrite', function (o) { return o.delete('k'); }).catch(function () {}); } catch (e) {}
  }
  async function keepLoad() {
    var j = null; try { j = JSON.parse(sessionStorage.getItem(KEEP) || 'null'); } catch (e) {}
    if (!j || !(j.until > Date.now()) || !window.indexedDB) { keepDrop(); return false; }
    try {
      var k = await idb('readonly', function (o) { return o.get('k'); }); if (!k) { keepDrop(); return false; }
      var raw = await open(k, j.box, 'tv-vault-keep'), p = JSON.parse(td.decode(raw)); wipe(raw);
      await useVault(unb64u(p.vk)); if (p.pb) st.pass = { bits: unb64u(p.pb), salt: unb64u(p.ps), iter: p.pi };
      return true;
    } catch (e) { keepDrop(); forget(); return false; }
  }

  // What the vault emails, and how often (the bar's Emails): each kind with Each time / Hourly / Daily / Don't email.
  async function toNotify() {
    panel('#tvv-notifypanel'); var box = $('#tvv-notify');
    try {
      var r = await api({ do: 'notify' }), h = Object.keys(r.kinds).map(function (k) {
        var d = r.kinds[k];
        return '<div class="tvv-nk" data-k="' + esc(k) + '"><span class="tvv-nkt"><b id="tvn-' + esc(k) + '">' + esc(d[0]) + '</b><span class="tvv-sub">' + esc(d[1]) + '</span></span><select aria-labelledby="tvn-' + esc(k) + '">'
          + Object.keys(r.freq).map(function (f) { return '<option value="' + esc(f) + '" title="' + esc(r.freq[f][1]) + '"' + (r.notify[k] === f ? ' selected' : '') + '>' + esc(r.freq[f][0]) + '</option>'; }).join('') + '</select></div>';
      }).join('');
      box.innerHTML = h + '<div class="tvv-nk always"><span class="tvv-nkt"><b>Always at once</b><span class="tvv-sub">' + esc(r.always) + '</span></span></div>';
    } catch (e) { box.innerHTML = ''; say(e.message, { anchor: $('[data-tvv=tonotify]'), bad: true }); }
  }
  async function saveNotify(btn) {
    var out = {}; Array.prototype.forEach.call(root.querySelectorAll('#tvv-notify .tvv-nk[data-k]'), function (n) { var c = n.querySelector('select'); if (c) out[n.getAttribute('data-k')] = c.value; });
    busy(btn, true);
    try { var r = await api({ do: 'notify_set', notify: out }); say(r.message || 'Saved.', { anchor: btn }); loadLog(); }
    catch (e) { say(e.message, { anchor: btn, bad: true }); } finally { busy(btn, false); }
  }

  // Lock, close, idle.
  function forget() { wipe(st.vkRaw); if (st.pass) wipe(st.pass.bits); st.vk = st.vkRaw = st.siteKey = st.pass = st.prfOut = null; st.items = []; var b = $('#tvv-items'); if (b) b.innerHTML = ''; var fm = $('#tvv-form'); if (fm && !fm.hidden) panelsShut(); }
  async function close(why) { endWarn(); keepDrop(); forget(); try { await api({ do: 'close' }); } catch (e) {} show('unlock'); status(why || 'The vault is closed on this device.', 'info', 'Closed:'); }
  // Unused for 5 minutes: "Still there?" with a 2-minute countdown, then the vault closes and forgets its key. Using the
  // page (a click, a key, scrolling) counts, and tells the server the vault is still in use at most every 2 minutes.
  var lastPing = Date.now(), warnTimer = 0, warnBox = null, idleAt = 0, clockTimer = 0;
  function mmss(n) { n = Math.max(0, Math.ceil(n)); return Math.floor(n / 60) + ':' + ('0' + (n % 60)).slice(-2); }
  function clockTick() {
    var c = $('#tvv-bar'); if (!c) return;
    if (!st.vk) { clockOff(); return; }
    var left = (idleAt - Date.now()) / 1000;
    var mm = mmss(left); $('#tvv-left').textContent = mm.length < 5 ? '0' + mm : mm; c.classList.toggle('low', left <= 60); extTick();
  }
  function clockOff() { clearInterval(clockTimer); clockTimer = 0; }
  // The times are kept by the clock, not by counting: Chrome slows the timers of a tab in the background, so a count
  // could run late while the server's own 10 minutes ran out (Jason, 2026-11-12: Keep Vault Open, then "already closed").
  var lastAct = Date.now();
  function poke() {
    clearTimeout(st.idle); if (!st.vk || warnBox) return;
    lastAct = Date.now();
    st.idle = setTimeout(stillThere, IDLE); idleAt = Date.now() + IDLE;
    if (!clockTimer) clockTimer = setInterval(clockTick, 1000); clockTick(); keepTouch();
    if (Date.now() - lastPing > 120000) { lastPing = Date.now(); api({ do: 'ping' }).catch(function () {}); }
  }
  function stillThere() {
    if (!st.vk || warnBox) return;
    var end = lastAct + IDLE + WARN * 1000, left = Math.ceil((end - Date.now()) / 1000);
    if (left <= 0) { close('The vault closed after 7 minutes unused (this tab was in the background). Unlock it again when you need it.'); return; }
    api({ do: 'ping' }, true).catch(function () {});   // the server keeps it open through the 2 minutes, so Keep works
    warnBox = document.createElement('div'); warnBox.className = 'tvv-warn'; warnBox.setAttribute('role', 'alertdialog'); warnBox.setAttribute('aria-modal', 'true'); warnBox.setAttribute('aria-labelledby', 'tvv-warn-t');
    warnBox.innerHTML = '<div class="tvv-warn-b"><button type="button" class="tvv-warn-x" data-w="close" aria-label="Close the vault now" title="Close the vault now">' + (ICONS.power || '×') + '</button>'
      + '<p id="tvv-warn-t"><b>Still there?</b></p><p>Your vault closes in <b class="tvv-warn-n">' + mmss(left) + '</b> to keep your passwords safe.</p>'
      + '<button type="button" class="ak-b go tvv-warn-keep" data-w="keep">Keep Vault Open</button></div>';
    document.body.appendChild(warnBox);
    var n = warnBox.querySelector('.tvv-warn-n'); warnBox.querySelector('[data-w=keep]').focus();
    idleAt = end; clockTick(); keepTouch(true);
    warnTimer = setInterval(function () {
      left = Math.ceil((end - Date.now()) / 1000); n.textContent = mmss(left);
      if (left <= 0) { endWarn(); close('The vault closed after 7 minutes unused. Unlock it again when you need it.'); }
    }, 1000);
    warnBox.addEventListener('click', function (e) {
      var b = e.target.closest('[data-w]'); if (!b) return;
      var keep = b.getAttribute('data-w') === 'keep'; endWarn();
      if (keep) {
        lastPing = Date.now();
        // the server's side closed anyway (asleep, offline): this device's passkey (PIN, fingerprint) opens it again here,
        // the key still in this page; only if that's refused does the vault close
        api({ do: 'ping' }, true).then(poke, function () {
          checkPasskey().then(function () { lastPing = Date.now(); poke(); say('Still open. The server had closed its side, so it asked for your passkey.', {}); },
            function () { close('The vault had closed on the server, and the passkey check didn\'t go through. Unlock it again.'); });
        });
      }
      else close();
    });
  }
  function endWarn() { clearInterval(warnTimer); if (warnBox) { warnBox.remove(); warnBox = null; } }
  // back to this tab: if the time ran out while it was in the background, act on it now
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState !== 'visible' || !st.vk) return;
    if (warnBox) return;
    if (Date.now() - lastAct >= IDLE) { clearTimeout(st.idle); stillThere(); }
  });
  ['pointerdown', 'keydown', 'scroll'].forEach(function (ev) { document.addEventListener(ev, function () { if (st.vk && !warnBox) poke(); }, { passive: true, capture: true }); });
  async function lockAll(btn) {
    if (!TvAsk.gate(btn, 'Lock the vault everywhere? It closes on every device and disconnects the extension, and nothing opens until you unlock it here with your passkey and passphrase (we email you both times). For when something seems wrong; to just step away, use Close.', { yes: 'Lock it', danger: true })) return;
    busy(btn, true); try { await api({ do: 'lock' }); extSend({ t: 'unpair' }); keepDrop(); forget(); show('unlock'); status('The vault is locked everywhere.', 'bad', 'Locked:'); } catch (e) { say(e.message, { anchor: btn, bad: true }); } finally { busy(btn, false); }
  }

  document.addEventListener('click', function (e) {
    var dd = document.querySelector('#tvv-bar .tvv-tdd[open]'); if (dd && !dd.contains(e.target)) dd.open = false;
    var b = e.target.closest('[data-tvv]'); if (!b || !(root.contains(b) || b.closest('#tvv-bar'))) return; e.preventDefault();
    if (dd && dd.contains(b)) dd.open = false;
    var a = b.getAttribute('data-tvv');
    ({ setup: setup, pass: setupPass, suggest: suggest, kitnext: kitNext, kitback: kitBack, appstart: function (x) { appStart(x, false); }, appnew: function (x) { appStart(x, true); },
       more: function () { drawItems('more'); },
       pg: function (x) { page = +x.getAttribute('data-p'); drawItems('page'); var f = $('#tvv-items'); if (f && f.getBoundingClientRect().top < 0) f.scrollIntoView({ behavior: 'smooth', block: 'start' }); },
       selall: selAll, selnone: selNone, seldel: selDelete,
       toimport: function () { panel('#tvv-import'); }, towords: function () { panel('#tvv-wordspanel'); }, toinstall: function () { panel('#tvv-extpanel'); }, tonotify: toNotify, notifysave: saveNotify, keepopen: function (x) { lastPing = 0; poke(); say('Kept open: 5 more minutes.', { anchor: x }); }, sort: function (x) { var k = x.getAttribute('data-k'); if (sortBy === k) sortDir = -sortDir; else { sortBy = k; sortDir = 1; } try { localStorage.setItem('tvv-sort', JSON.stringify([sortBy, sortDir])); } catch (e) {} drawItems('keep'); }, logmore: function (x) { busy(x, true); loadLog(true).then(function () { busy(x, false); }); }, way: pickWay, pinapp: function (x) { pinUnlock('app', x); }, pinmail: function (x) { pinUnlock('email', x); }, umailagain: sendUnlockCode, panelx: panelsShut, impgo: importGo,
       exton: extOn, extoff: extOff, appadd: appAdd, appremove: appRemove, extradone: extraDone, toextra: toExtra,
       eye: function (x) { var i = x.parentNode.querySelector('input'), on = i.classList.contains('tvv-mask'); i.classList.toggle('tvv-mask', !on); x.setAttribute('aria-pressed', on ? 'true' : 'false'); x.setAttribute('aria-label', on ? 'Hide' : 'Show'); x.title = on ? 'Hide' : 'Show'; i.focus(); },
       unlock: unlock, code: sendCode, adddev: addDevice, recover: recover, kitdl: kitDownload, kitprint: function () { document.body.classList.add('tvv-printing'); window.print(); setTimeout(function () { document.body.classList.remove('tvv-printing'); }, 500); },
       kitdone: kitDone, add: function () { editItem(null); }, save: saveItem, cancel: panelsShut, gen: generate,
       spare: addSpare, words: rotateWords, lock: lockAll, close: function () { close(); }, toadd: function () { show('adddev'); }, torecover: function () { show('recover'); }, tounlock: function () { show('unlock'); } }[a] || function () {})(b);
  });
  root.addEventListener('click', function (e) { if (e.target.closest('#tvv-items')) onItem(e); else if (e.target.closest('#tvv-devices')) onDevice(e); });
  root.addEventListener('change', function (e) {
    if (e.target.id === 'tvv-impfile') importRead(e.target);
    if (e.target.id === 'tvv-showsel') drawItems();
    if (e.target.id === 'tvv-per') { try { localStorage.setItem('tvv-perpage', e.target.value); } catch (x) {} drawItems(); }
    if (e.target.classList.contains('tvv-pageall')) pageAll(e.target);
    if (e.target.hasAttribute('data-col')) { var on = Array.prototype.filter.call(root.querySelectorAll('.tvv-colsl [data-col]'), function (x) { return x.checked; }).map(function (x) { return x.getAttribute('data-col'); }); try { localStorage.setItem('tvv-cols', JSON.stringify(on)); } catch (x) {} drawItems('keep'); }
    if (e.target.hasAttribute('data-sel')) { var id = +e.target.getAttribute('data-sel'); if (e.target.checked) sel[id] = 1; else delete sel[id]; drawSel(); }
  });
  root.addEventListener('input', function (e) {
    var t = e.target;
    if (t.id === 'tvv-q') drawItems();
    if (t.hasAttribute('data-meter')) { drawRules(t); var two = $(t.getAttribute('data-pair')); if (two && two.value) matchRule(two); }
    if (t.hasAttribute('data-same')) matchRule(t);
    poke();
  });
  root.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'tvv-pass') { e.preventDefault(); unlock($('[data-tvv="unlock"]')); }
    if (e.target.id === 'tvv-uapp') { e.preventDefault(); pinUnlock('app', $('[data-tvv="pinapp"]')); }
    if (e.target.id === 'tvv-umail') { e.preventDefault(); pinUnlock('email', $('[data-tvv="pinmail"]')); }
  });
  try { var per = localStorage.getItem('tvv-perpage'); if (per !== null) $('#tvv-per').value = per; } catch (e) {}
  Array.prototype.forEach.call(root.querySelectorAll('details[data-fold]'), function (d) {   // which sections you leave open (this browser only)
    var k = 'tvv-fold-' + d.getAttribute('data-fold');
    try { var v = localStorage.getItem(k); if (v !== null) d.open = v === '1'; } catch (e) {}
    d.addEventListener('toggle', function () { try { localStorage.setItem(k, d.open ? '1' : '0'); } catch (e) {} });
  });
  // Leaving the vault page by a link closes the vault, so it asks first. Reloading keeps it open (below); closing the tab
  // ends it, with the tab's own storage.
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href]'); if (!a || !st.vk || e.defaultPrevented) return;
    if (a.hasAttribute('download') || (a.target && a.target !== '_self') || e.ctrlKey || e.metaKey || e.shiftKey || e.button) return;
    var to; try { to = new URL(a.href, location.href); } catch (x) { return; }
    if (!/^https?:$/.test(to.protocol) || (to.pathname === location.pathname && to.search === location.search)) return;
    e.preventDefault(); e.stopPropagation();
    TvAsk.confirm('Leaving this page closes your vault. Leave?', { yes: 'Close it and leave', no: 'Stay here' }).then(function (yes) {
      if (!yes) return; close().then(function () { location.href = to.href; });
    });
  }, true);
  window.addEventListener('pagehide', forget);
  // #connect=<tab> from the extension's Connect button: connect once the vault is open, then go back to that tab
  (function () { var m = /(?:^|[#&])connect=(\d+)/.exec(location.hash || ''); if (m) { st.backTab = +m[1] || 0; try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {} if (!st.backTab) st.backTab = -1; } })();
  boot().catch(function (e) { status(e.message, 'bad', 'Error:'); });
})();
