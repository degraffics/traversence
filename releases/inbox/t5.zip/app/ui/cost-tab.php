<?php
// app/ui/cost-tab.php — an order item's Cost tab (Jason, 2026-10-29): the costing worksheet laid out like his own (each
// line with its working), COGS against the item's price, the price tiers, and who checked it. The form posts
// do=line_cost to the order page; js/tv-cost.js works the sheet out again as you type (the server's sum is the one kept).
declare(strict_types=1);

require_once __DIR__ . '/../lib/Costing.php';
require_once __DIR__ . '/table-kit.php';   // the table standard for the price tiers (design/table-standard.md, T5)

function tv_cost_css(): string
{
    return '<style>.cx-f{display:grid;gap:.5rem}.cx-f h4{margin:.4rem 0 0}.cx-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(6.2rem,1fr));gap:.3rem;border:1px solid #EADFC4;border-radius:.5rem;padding:.4rem;background:#FFFCF3}'
        . '.cx-row label{display:grid;gap:.1rem;font-size:.74rem;color:var(--tv-meta,#5E4F3C)}.cx-row .cx-w2{grid-column:span 2}.cx-row .cx-chk{display:flex;gap:.3rem;align-items:center;font-size:.8rem;color:#5C4632}.cx-row .cx-chk input{width:auto}'
        . '.cx-row input,.cx-row select{padding:.3rem .4rem;font-size:.86rem}.cx-new{opacity:.75}.cx-tiers{display:grid;grid-template-columns:repeat(auto-fit,minmax(11rem,1fr));gap:.3rem .8rem}.cx-tiers label{display:flex;gap:.25rem;align-items:center;font-size:.8rem;color:#5C4632;min-width:0}'
        . '.cx-tiers input{flex:1 1 0;min-width:0;width:auto;padding:.25rem .35rem}.cx-ws{border-top:2px solid #EADFC4;margin-top:.3rem}.cx-l{display:grid;grid-template-columns:1fr auto;gap:0 .6rem;padding:.3rem 0;border-bottom:1px solid #F1E7D0;font-size:.88rem}'
        . '.cx-l small{display:block;color:var(--tv-meta,#5E4F3C);font-size:.78rem}.cx-l .cx-a{text-align:right;font-weight:700;white-space:nowrap}.cx-l.us small:after{content:" · ours";color:#3E6B55}.cx-tot{display:grid;grid-template-columns:1fr auto;gap:.1rem .6rem;padding:.4rem 0;font-size:.92rem}'
        . '.cx-tot b:nth-child(2n){text-align:right}.cx-tt tr.here td{background:color-mix(in srgb,var(--tv-sage,#8FBCA8) 22%,var(--tv-card-a,#FFFBF2));font-weight:700}.cx-btns{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center}.cx-row{position:relative}.cx-del{position:absolute;top:.2rem;right:.3rem;border:0;background:transparent;color:#991B1B;font-size:1.1rem;line-height:1;cursor:pointer;padding:.15rem .35rem}.cx-row>label.cx-w2:first-child{padding-right:1.6rem}.cx-from{display:flex;flex-wrap:wrap;gap:.4rem;align-items:end;margin:.3rem 0 .6rem}.cx-from label{display:grid;gap:.1rem;font-size:.8rem;color:#8A7355;flex:1 1 12rem;min-width:0}</style>';
}

/** The Cost tab's contents for one item. */
function tv_cost_pane(PDO $pdo, array $l, callable $hidden): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES); $usd = fn ($c) => Orders::usd((int) $c);
    if (!Costing::ready($pdo)) return '<p class="co-note">Run <code>app/migrations/2027-01-08_costing.sql</code> in phpMyAdmin to cost items here.</p>';
    $lid = (int) $l['id']; $items = Costing::items($pdo); [$r, $row] = Costing::forLine($pdo, $l);
    $run = ClientOrders::runQty($l); $ws = Costing::sheet($r, $run, $items); $price = (int) $l['unit_cents'] * (int) $l['qty'];
    $isProd = ($l['product'] ?? '') === 'product' && !empty($l['product_id']);
    $num = fn ($x) => rtrim(rtrim(number_format((float) $x, 5, '.', ''), '0'), '.');
    $opt = function (array $list, int $sel, string $none) use ($e): string {
        $o = '<option value="0">' . $e($none) . '</option>';
        foreach ($list as $id => $c) $o .= '<option value="' . $id . '"' . ($id === $sel ? ' selected' : '') . '>' . $e($c['name'] . ($c['size'] !== '' ? ' ' . $c['size'] : '') . ' · ' . rtrim(rtrim(number_format($c['unit'], 5), '0'), '.') . ($c['active'] ? '' : ' (retired)')) . '</option>';
        return $o;
    };
    $papers = array_filter($items, fn ($c) => $c['kind'] === 'paper');

    // where it stands
    if (Costing::isChecked($row)) $state = '<p data-tv-status="ok" data-tv-label="Checked:">' . $e(trim((string) ($row['checked_name'] ?? '')) ?: 'Someone') . ' checked this COGS ' . $e(date('M j, g:i a', strtotime((string) $row['checked_at']))) . '.</p>';
    elseif ($row && $row['checked_at'] !== null) $state = '<p data-tv-status="bad" data-tv-label="Changed since its check:">It was checked at ' . $usd($row['checked_cents']) . '; it\'s ' . $usd($row['cogs_cents']) . ' now. Check it again before the work order goes.</p>';
    else $state = '<p data-tv-status="info" data-tv-label="Not checked yet:">' . ($row ? 'Saved, not checked.' : ($r['parts'] || $r['items'] ? 'This is the product\'s recipe at this item\'s run of ' . number_format($run) . '. Set it right, then Save and mark checked.' : 'No costing yet. Start from a template, or add its lines below (this item\'s run is ' . number_format($run) . ').')) . '</p>';

    // the cost list's prices today, against the COGS saved: a paper or coil repriced since → say so (Save picks it up)
    if ($row && (int) $row['cogs_cents'] !== $ws['cogs']) $state .= '<p data-tv-status="info" data-tv-label="Prices changed:">With today\'s cost list this is ' . $usd($ws['cogs']) . ' (saved at ' . $usd($row['cogs_cents']) . '). Save it to keep the new figure' . ($row['checked_at'] !== null ? ', and check it again' : '') . '.</p>';
    // start from the product's recipe or another costed item on this order (DE → EN), at this item's run
    $src = Costing::sources($pdo, $l);
    if ($src) $state .= '<form method="post" class="cx-from" novalidate>' . $hidden('line_cost', $lid) . '<input type="hidden" name="ip" value="1"><input type="hidden" name="act" value="load">'
        . '<label>Start from<select class="hb-in" name="from">' . implode('', array_map(fn ($k, $v) => '<option value="' . $e($k) . '">' . $e($v) . '</option>', array_keys($src), $src)) . '</select></label>'
        . '<button class="hb-b" data-confirm="Replace this item\'s costing with that one, at this item\'s run of ' . number_format($run) . '? Rates come from today\'s cost list; it isn\'t checked until you check it." data-yes="Replace it">Use it</button></form>';

    $h = $state . '<form method="post" class="cx-f" data-cost novalidate>' . $hidden('line_cost', $lid) . '<input type="hidden" name="ip" value="1">'
        . '<template data-cost-items>' . $e(json_encode(array_map(fn ($c) => ['name' => $c['name'] . ($c['size'] !== '' ? ' ' . $c['size'] : ''), 'unit' => $c['unit']], $items), JSON_FORCE_OBJECT)) . '</template>'
        . '<input type="hidden" data-cost-run value="' . $run . '"><input type="hidden" data-cost-price value="' . $price . '">';

    // its lines: only what's been added (Jason, 2026-10-29: "start with zero items, an add to pull items in"); + Printed
    // part / + Cost add one from the templates below, × takes one out
    $partRow = function ($k, array $p) use ($e, $num, $opt, $papers): string {
        $n = 'parts[' . $k . ']';
        return '<div class="cx-row" data-cost-part><label class="cx-w2">Printed part<input class="hb-in" name="' . $n . '[name]" value="' . $e($p['name']) . '" placeholder="Covers, guts, inserts"></label>'
            . '<button type="button" class="cx-del" data-cost-del title="Take this line out" aria-label="Take this line out">×</button>'
            . '<label>Pages<input class="hb-in" name="' . $n . '[pages]" inputmode="numeric" value="' . $e($p['pages']) . '"></label>'
            . '<label>Printed<select class="hb-in" name="' . $n . '[sides]"><option value="2"' . ($p['sides'] == 2 ? ' selected' : '') . '>Both sides</option><option value="1"' . ($p['sides'] == 1 ? ' selected' : '') . '>One side</option></select></label>'
            . '<label>To a sheet<input class="hb-in" name="' . $n . '[up]" inputmode="numeric" value="' . $e($p['up']) . '"></label>'
            . '<label>Printing a sheet<input class="hb-in" name="' . $n . '[click]" inputmode="decimal" value="' . $e($p['click'] === '' ? '' : $num($p['click'])) . '"></label>'
            . '<label class="cx-w2">Stock<select class="hb-in" name="' . $n . '[stock]">' . $opt($papers, (int) $p['stock'], 'Type its price a sheet') . '</select></label>'
            . '<label>Stock a sheet<input class="hb-in" name="' . $n . '[stock_rate]" inputmode="decimal" data-cost-rate' . (isset($papers[(int) $p['stock']]) ? ' value="' . (!empty($p['own']) && (float) $p['stock_rate'] ? $num($p['stock_rate']) : '') . '" placeholder="' . $num($papers[(int) $p['stock']]['unit']) . ' from the list"' : ' value="' . $e($p['stock_rate'] === '' || !(float) $p['stock_rate'] ? '' : $num($p['stock_rate'])) . '" placeholder="type it"') . '>'
            . '<input type="hidden" name="' . $n . '[own]" value="' . (!empty($p['own']) ? 1 : 0) . '" data-cost-own></label>'
            . '<label class="cx-chk"><input type="checkbox" name="' . $n . '[vendor]" value="1"' . ($p['vendor'] ? ' checked' : '') . '> The vendor charges it</label></div>';
    };
    $itemRow = function ($k, array $i) use ($e, $num, $opt, $items): string {
        $n = 'items[' . $k . ']';
        return '<div class="cx-row" data-cost-item><label class="cx-w2">Cost<input class="hb-in" name="' . $n . '[name]" value="' . $e($i['name']) . '" placeholder="Binding, labor, boxes"></label>'
            . '<button type="button" class="cx-del" data-cost-del title="Take this line out" aria-label="Take this line out">×</button>'
            . '<label class="cx-w2">From the cost list<select class="hb-in" name="' . $n . '[item]">' . $opt($items, (int) $i['item'], 'No: type the rate') . '</select></label>'
            . '<label>Rate<input class="hb-in" name="' . $n . '[rate]" inputmode="decimal" data-cost-rate' . (isset($items[(int) $i['item']]) ? ' value="' . (!empty($i['own']) ? $num($i['rate']) : '') . '" placeholder="' . $num($items[(int) $i['item']]['unit']) . ' from the list"' : ' value="' . $e($i['rate'] === '' ? '' : $num($i['rate'])) . '" placeholder="type it"') . '>'
            . '<input type="hidden" name="' . $n . '[own]" value="' . (!empty($i['own']) ? 1 : 0) . '" data-cost-own><input type="hidden" name="' . $n . '[cat]" value="' . (!empty($i['cat']) ? 1 : 0) . '"></label>'
            . '<label>To one (1 per N)<input class="hb-in" name="' . $n . '[n]" inputmode="numeric" value="' . $e(($i['per'] ?? '') === 'n' ? (int) ($i['n'] ?? 1) : '') . '" placeholder="40 to a box"' . (($i['per'] ?? '') === 'n' ? '' : ' disabled') . '></label>'
            . '<label>How<select class="hb-in" name="' . $n . '[per]">' . implode('', array_map(fn ($k2, $v) => '<option value="' . $k2 . '"' . ($i['per'] === $k2 ? ' selected' : '') . '>' . $e($v) . '</option>', array_keys(Costing::PER), Costing::PER)) . '</select></label>'
            . '<label class="cx-chk"><input type="checkbox" name="' . $n . '[vendor]" value="1"' . ($i['vendor'] ? ' checked' : '') . '> The vendor charges it</label></div>';
    };
    $h .= '<div data-cost-lines>';
    foreach ($r['parts'] as $k => $p) $h .= $partRow($k, $p);
    foreach ($r['items'] as $k => $i) $h .= $itemRow($k, $i);
    $h .= '</div>' . (!$r['parts'] && !$r['items'] ? '<p class="co-note" data-cost-none style="margin:0">Nothing on it yet. Add what goes into it, one line at a time, or start from a template above.</p>' : '')
        . '<div class="cx-btns"><button type="button" class="hb-b" data-cost-add="part">+ Printed part</button><button type="button" class="hb-b" data-cost-add="item">+ Cost</button></div>'
        . '<p class="co-note" style="margin:0">A printed part: its pages (a cover printed both sides is 2), how many to a sheet, printing a sheet and its stock. A cost: binding, labor, boxes, a service; each, per 100, 1 per N or once a run.</p>'
        . '<template data-cost-new="part">' . $partRow('__K__', ['name' => '', 'pages' => '', 'sides' => 2, 'up' => '', 'click' => '', 'stock' => 0, 'stock_rate' => '', 'vendor' => 1]) . '</template>'
        . '<template data-cost-new="item">' . $itemRow('__K__', ['name' => '', 'item' => 0, 'rate' => '', 'per' => 'book', 'n' => 1, 'vendor' => 1]) . '</template>';
    $h .= '<div class="cx-tiers"><label>Spoilage <input class="hb-in" name="spoil" inputmode="decimal" value="' . $e($num($r['spoil'])) . '">%</label></div>'
        . '<h4>Price tiers</h4><p class="co-note" style="margin:0">Each run\'s price: its COGS × the multiplier, the price each rounded up to the cent.</p><div class="cx-tiers">';
    foreach (array_merge($r['tiers'], [[null, null]]) as $k => $t) $h .= '<label>Run <input class="hb-in" name="tiers[' . $k . '][0]" inputmode="numeric" value="' . $e($t[0] ?? '') . '"> × <input class="hb-in" name="tiers[' . $k . '][1]" inputmode="decimal" value="' . $e($t[1] ?? '') . '"></label>';
    $h .= '</div>';

    // the worksheet (js/tv-cost.js redraws it as you type)
    $h .= '<div class="cx-ws" data-cost-sheet>' . tv_cost_sheet($ws, $price) . '</div>';
    $h .= '<div class="cx-btns"><button class="hb-b" name="act" value="save">Save costing</button><button class="hb-b go" name="act" value="check">Save and mark checked</button>'
        . '<button class="hb-b" name="act" value="none" data-confirm="No hard cost: check this item\'s COGS at $0 (your own time, nothing bought)? Its lines come off." data-yes="Yes, $0">No hard cost</button>'
        . ($isProd ? '<button class="hb-b" name="act" value="recipe" data-confirm="Keep this as the product\'s recipe? New orders of it start from it, and the catalog\'s run sizes take its tiers: each run\'s COGS as its cost and the tier price as its price (this order\'s other items keep theirs)." data-yes="Keep it">Keep as the product\'s recipe</button>' : '') . '</div>'
        . '<small class="co-note">Our team only. Rates come from the <a href="/admin/backoffice/cost_list" data-peek-frame data-title="Cost list">cost list</a>: change a paper\'s price there and every new costing uses it.</small></form>';
    return $h;
}

/** The worksheet's lines, totals and tiers (also drawn by js/tv-cost.js with the same words). */
function tv_cost_sheet(array $ws, int $price): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES); $usd = fn ($c) => Orders::usd((int) round($c));
    $h = '';
    foreach ($ws['lines'] as $l) $h .= '<div class="cx-l' . ($l['vendor'] ? '' : ' us') . '"><div>' . $e($l['label']) . '<small>' . $e($l['work']) . '</small></div><div class="cx-a">' . $usd($l['cents']) . '</div></div>';
    $h .= '<div class="cx-tot"><b>COGS (' . number_format($ws['run']) . ')</b><b>' . $usd($ws['cogs']) . '</b><span>Each</span><span style="text-align:right">$' . number_format($ws['each'] / 100, 4) . '</span>'
        . '<span>The vendor\'s share</span><span style="text-align:right">' . $usd($ws['vendor']) . '</span>';
    if ($price > 0) $h .= '<span>Price on the order</span><span style="text-align:right">' . $usd($price) . ' ($' . number_format($price / 100 / $ws['run'], 2) . ' each)</span><b>Margin</b><b>' . $usd($price - $ws['cogs']) . ' (' . round(($price - $ws['cogs']) / $price * 100) . '%, ' . number_format($price / max(1, $ws['cogs']), 2) . '× COGS)</b>';
    $h .= '</div>';
    if ($ws['tiers']) {
        $h .= tv_table_kit() . '<table class="cx-tt" data-tv-table><tr><th>Run</th><th>COGS</th><th>×</th><th>Each</th><th>Price</th></tr>';
        foreach ($ws['tiers'] as $t) $h .= '<tr' . ($t['qty'] === $ws['run'] ? ' class="here"' : '') . '><td>' . number_format($t['qty']) . '</td><td>' . $usd($t['cogs']) . '</td><td>' . $e($t['mult']) . '</td><td>$' . number_format($t['each'] / 100, 2) . '</td><td>' . $usd($t['total']) . '</td></tr>';
        $h .= '</table>';
    }
    return $h;
}
