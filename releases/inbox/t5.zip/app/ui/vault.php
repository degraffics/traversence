<?php
// app/ui/vault.php — System Configuration → Vault (decisions/0156): the page. All the work is in js/tv-vault.js, in the
// browser; this draws the views it switches between. Owners and executives first (Access 'config.vault').
declare(strict_types=1);

function tv_vault_page(PDO $pdo): string
{
    [$can, $why] = Access::can('config.vault', ['min' => 'executive', 'depts' => []]);
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    if (!$can) return '<p data-tv-status="info" data-tv-label="Not yours:">' . $e($why) . '. The vault is for owners and executives first; logins for the team stay in the password manager (Outside services links to them).</p>';
    require_once __DIR__ . '/../lib/Vault.php';
    $me = Vault::who($pdo, Auth::currentUser() ?: []);
    $icons = [];
    foreach (['copy', 'eye', 'user', 'pen', 'trash', 'power', 'download'] as $n) $icons[$n] = tv_icon($n, 'tvv-svg');
    // the bar's lock shows the vault as it is: open (the bar only shows while it's open). Shut is shown only when locked.
    $lockOpen = '<svg class="tvv-svg tvv-open-l" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>';
    $js = (int) @filemtime(__DIR__ . '/../../website/js/tv-vault.js');
    // a vault passphrase box: its own Show/Hide inside the box, and (for a new one) its own rules and strength meter
    $pp = function ($id, $label, $new, $pair = '', $same = '') use ($e) {
        $a = ' id="' . $id . '" type="text" class="tvv-mask" data-tvpw="1" spellcheck="false" autocapitalize="none" autocorrect="off" autocomplete="off" data-lpignore="true" data-1p-ignore';   // a text box shown as dots: browsers' password managers don't offer to save it (they ignore autocomplete="off" on password boxes)
        if ($new && $same === '') $a .= ' data-rules="#' . $id . '-r" data-meter="#' . $id . '-m"' . ($pair !== '' ? ' data-pair="#' . $pair . '"' : '');
        if ($same !== '') $a .= ' data-same="#' . $same . '" data-rules="#' . $id . '-r"';
        return '<label class="tvv-f"><span>' . $label . '</span><span class="tvv-pp"><input' . $a . '><button type="button" class="tvv-eye" data-tvv="eye" aria-label="Show" title="Show" aria-pressed="false">'
            . tv_icon('eye', 'tvv-svg') . '</button></span></label>'
            . ($new && $same === '' ? '<span class="tvv-meter" id="' . $id . '-m" aria-hidden="true"><i></i></span>' : '')
            . ($new ? '<ul class="tvv-rules" id="' . $id . '-r" aria-live="polite"></ul>' : '');
    };
    ob_start(); ?>
<style>
#tvv{max-width:84rem}
#tvv .tvv-tb{display:flex;flex-wrap:wrap;gap:.45rem;align-items:center;margin:.2rem 0 .6rem}
#tvv .tvv-tb #tvv-q{flex:1 1 18rem;max-width:none}
#tvv .tvv-tb select{flex:0 1 auto;max-width:15rem}
#tvv .tvv-tb .tvv-cnt{margin-left:auto;white-space:nowrap}
#tvv #tvv-table{border:1px solid #E7D9C4;border-radius:.5rem;background:#fff}
#tvv .tvv-th,#tvv .tvv-tr{display:grid;grid-template-columns:var(--tvv-cols,2.6rem minmax(12rem,1.6fr) auto);align-items:center;column-gap:.75rem;padding:.45rem .75rem .45rem 0}
#tvv .tvv-th{position:sticky;top:calc(var(--ta-top,56px) + var(--as-h,0px) + 2.5rem);z-index:29;background:var(--tv-sec,#EDE6D5);border-bottom:1px solid var(--tv-line,#E7D9C4);border-radius:.5rem .5rem 0 0;min-height:2.6rem;font-size:.85rem}
#tvv .tvv-thc{display:contents}
#tvv .tvv-th .tvv-c0,#tvv .tvv-tr .tvv-c0{justify-self:center;padding:0}
#tvv .tvv-sort{border:0;background:none;font:600 .8rem var(--tv-font-ui);color:var(--tv-meta,#5E4F3C);cursor:pointer;padding:.2rem 0;text-align:left;display:inline-flex;align-items:center;justify-content:flex-start;justify-self:start;gap:.3rem}
#tvv .tvv-sort i{font-style:normal;color:var(--tv-taupe,#7A6A52);font-size:.8rem}#tvv .tvv-sort[aria-sort] i{color:var(--tv-link,#92400E)}
#tvv .tvv-sort:hover{color:var(--tv-link,#92400E)}
#tvv .tvv-thact{justify-self:end;display:flex;align-items:center;gap:.5rem;font-weight:700;color:var(--tv-ink,#2A1D14)}
#tvv .tvv-colsdd{position:relative}#tvv .tvv-colsdd>summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;gap:.3rem;padding:.25rem .55rem;border:1px solid var(--tv-line-strong,#D6C7B0);border-radius:999px;background:#fff;font-weight:600;color:var(--tv-meta,#57534E)}
#tvv .tvv-colsdd>summary::-webkit-details-marker{display:none}#tvv .tvv-colsdd[open]>summary{border-color:var(--tv-link,#92400E);color:var(--tv-link,#92400E)}
#tvv .tvv-colsl{position:absolute;right:0;top:calc(100% + .3rem);z-index:31;background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;box-shadow:0 12px 28px -12px rgba(0,0,0,.4);padding:.5rem .7rem;min-width:13rem;font-weight:400}
#tvv .tvv-colsl label{display:flex;align-items:center;gap:.45rem;padding:.25rem 0;cursor:pointer;white-space:nowrap}#tvv .tvv-colsl input{accent-color:var(--tv-link,#92400E)}
#tvv .tvv-colsl p{margin:.3rem 0 0;font-size:.75rem;color:var(--tv-meta,#78716C);white-space:normal}
#tvv .tvv-th .tvv-selbar{grid-column:2/-1;display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;position:static;border:0;box-shadow:none;background:none;padding:0}
#tvv .tvv-tr{border-bottom:1px solid var(--tv-line,#F0E6D6);min-height:2.75rem;background:var(--tv-card-a,#F6F1E4)}#tvv .tvv-tr:last-child{border-bottom:0;border-radius:0 0 .5rem .5rem}
#tvv .tvv-tr:hover{background:color-mix(in srgb,var(--tv-sec,#EDE6D5) 60%,var(--tv-card-a,#F6F1E4))}
#tvv .tvv-tr:has(.tvv-c0 input:checked){background:color-mix(in srgb,var(--tv-link,#92400E) 7%,var(--tv-card-a,#F6F1E4));box-shadow:inset 3px 0 0 var(--tv-link,#92400E)}
#tvv .tvv-c{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.9rem}
#tvv .tvv-site .tvv-name{display:block;overflow:hidden;text-overflow:ellipsis}#tvv .tvv-site .tvv-sub{display:block;overflow:hidden;text-overflow:ellipsis;font-size:.78rem}
#tvv .tvv-tr .tvv-r{max-width:none;flex-wrap:nowrap;justify-self:end;align-items:center}
#tvv .tvv-tr .tvv-show{grid-column:2/-1;margin:.1rem 0 .1rem}
#tvv .tvv-tr .tvv-full{grid-column:1/-1;padding-left:.75rem}
#tvv .tvv-flag{display:inline-block;font-size:.72rem;font-weight:700;padding:.1rem .4rem;border-radius:999px;margin-right:.25rem;background:#FEF3C7;color:#92400E}#tvv .tvv-flag.bad{background:#FEE2E2;color:#991B1B}
@media (max-width:767px){
  #tvv .tvv-th,#tvv .tvv-tr{grid-template-columns:2.4rem 1fr auto;row-gap:.15rem}
  #tvv .tvv-thc>.tvv-opt{display:none}
  #tvv .tvv-tr .tvv-opt{grid-column:2/3;font-size:.8rem;color:var(--tv-meta,#57534E)}#tvv .tvv-tr .tvv-opt:before{content:attr(data-label) ": ";color:var(--tv-meta,#5E4F3C)}
  #tvv .tvv-tr .tvv-r{grid-column:3;grid-row:1 / span 4;flex-wrap:wrap;max-width:5rem;align-self:start}
}
#tvv .tvv-lis{list-style:none;padding:0;margin:.2rem 0}
#tvv .tvv-lis li{display:flex;flex-wrap:wrap;align-items:center;gap:.35rem .6rem;padding:.45rem 0;border-bottom:1px solid #F0E6D6}
#tvv .tvv-lis li:last-child{border-bottom:0}
#tvv .tvv-lt{flex:1 1 16rem;min-width:0}
#tvv .tvv-lt .tvv-sub{display:block}
#tvv .tvv-exleft{color:#1F5C43;font-variant-numeric:tabular-nums}#tvv .tvv-exleft.low{color:#991B1B}
#tvv .tvv-ways{display:flex;flex-direction:column;gap:.5rem;max-width:36rem;margin:.6rem 0}
#tvv .tvv-way{background:#fff;border:1px solid #E7D9C4;border-radius:.6rem;overflow:hidden}
#tvv .tvv-way.on{border-color:#92400E;box-shadow:0 0 0 3px rgba(146,64,14,.12)}
#tvv .tvv-wayb{display:flex;align-items:center;gap:.75rem;width:100%;text-align:left;border:0;background:none;padding:.75rem .9rem;font:inherit;color:#3E2B1F;cursor:pointer}
#tvv .tvv-wayb:hover:not(:disabled){background:#FFFBF2}
#tvv .tvv-wayb b{flex:0 0 2rem;height:2rem;border-radius:50%;background:#92400E;color:#fff;display:inline-flex;align-items:center;justify-content:center}
#tvv .tvv-wayb span{font-weight:700}#tvv .tvv-wayb small{display:block;font-weight:400;color:#78716C;font-size:.82rem}
#tvv .tvv-wayb:disabled{cursor:default;opacity:.6}#tvv .tvv-wayb:disabled b{background:#A8A29E}
#tvv .tvv-wayf{padding:0 .9rem .8rem}
#tvv-bar{display:flex;align-items:center;gap:.4rem;color:#3B2416;font:inherit}
#tvv-bar[hidden]{display:none!important}
#tvv-bar .tvv-open{white-space:nowrap;font:700 .92rem var(--tv-font-head,ui-serif,Georgia,serif);margin-right:.3rem}#tvv-bar .tvv-open b{font-variant-numeric:tabular-nums}
#tvv-bar.low .tvv-open b{color:#B91C1C}
#tvv-bar .tvv-cib{width:28px;height:28px;border-radius:50%;border:1.5px solid #fff;background:#E07F3C;color:#fff;display:inline-flex;align-items:center;justify-content:center;padding:0;cursor:pointer}
#tvv-bar .tvv-cib .tvv-svg{width:15px;height:15px}
#tvv-bar .tvv-cib:hover,#tvv-bar .tvv-cib:focus-visible{background:#B91C1C;box-shadow:0 0 0 3px rgba(185,28,28,.25)}
#tvv-bar .tvv-cib[data-tvv=keepopen]:hover{background:#2F7D5B;box-shadow:0 0 0 3px rgba(47,125,91,.25)}
#tvv-bar .tvv-tdd{position:relative;margin-left:.5rem}
#tvv-bar .tvv-tdd>summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;gap:.3rem;background:#fff;border:1.5px solid #E07F3C;border-radius:.3rem;padding:.15rem 0 .15rem .4rem;color:#2B1D14}
#tvv-bar .tvv-tdd>summary::-webkit-details-marker{display:none}#tvv-bar .tvv-tdd>summary::after{content:"▼";font-size:.8em;border-left:1px solid #E07F3C;padding:0 .3rem}
#tvv-bar .tvv-tdd>summary .tvv-svg{width:18px;height:18px}
#tvv-bar .tvv-tdl{position:absolute;right:0;top:calc(100% + .35rem);z-index:40;min-width:13rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;box-shadow:0 14px 30px -14px rgba(0,0,0,.45);padding:.3rem}
#tvv-bar .tvv-tdl button{display:block;width:100%;text-align:left;border:0;background:none;padding:.45rem .6rem;border-radius:.4rem;font:600 .95rem system-ui,sans-serif;color:#3E2B1F;cursor:pointer}
#tvv-bar .tvv-tdl button:hover{background:#F3EAD3}
#tvv section > #tvv-bar{background:#F1B48C;border-radius:.5rem;padding:.35rem .6rem;margin:0 0 .6rem;justify-content:flex-end}   /* on its own (no command bar on the page) */
#tvv .tvv-nk{display:flex;align-items:center;gap:.4rem .8rem;flex-wrap:wrap;padding:.55rem 0;border-bottom:1px solid #F0E6D6}#tvv .tvv-nk:last-child{border-bottom:0}
#tvv .tvv-nk .tvv-nkt{flex:1 1 12rem;min-width:0}#tvv .tvv-nk b{display:block;color:#3E2B1F;font-size:.95rem}#tvv .tvv-nk .tvv-sub{display:block;font-size:.8rem;margin-top:.1rem}
#tvv .tvv-nk select{flex:0 0 auto;padding:.4rem .5rem;border:1px solid #D6C7B0;border-radius:.4rem;background:#fff;font:inherit;font-size:.9rem;max-width:12rem}
#tvv .tvv-seg{display:flex;flex-wrap:wrap;gap:.3rem}#tvv .tvv-seg label{display:inline-flex;align-items:center;gap:.3rem;padding:.35rem .65rem;border:1px solid #D6C7B0;border-radius:999px;background:#fff;cursor:pointer;font-size:.9rem}
#tvv .tvv-seg input{accent-color:#92400E;margin:0}#tvv .tvv-seg label:has(input:checked){border-color:#92400E;background:#FFFBF2;color:#92400E;font-weight:600}
#tvv .tvv-nk.always{opacity:.75}
#tvv .tvv-foldb>.tvv-sub:first-child{margin-top:0}
#tvv [hidden]{display:none!important}
#tvv section{margin:.75rem 0}
#tvv .tvv-f{display:block;margin:.5rem 0}#tvv .tvv-f span{display:block;font-size:.85rem;color:#57534E;margin-bottom:.2rem}
#tvv input[type=text],#tvv input[type=search],#tvv input[type=password],#tvv input[type=url],#tvv textarea{width:100%;max-width:28rem;box-sizing:border-box;padding:.5rem .6rem;border:1px solid #D6C7B0;border-radius:.4rem;font:inherit}
#tvv textarea{max-width:100%}
#tvv .tvv-row{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin:.6rem 0}
#tvv .tvv-card{display:flex;justify-content:space-between;gap:.75rem;background:#fff;border:1px solid #E7D9C4;border-radius:.5rem;padding:.6rem .75rem;margin:.4rem 0}
#tvv .tvv-name{color:#92400E;text-decoration:underline;font-weight:600}
#tvv .tvv-sub{color:#78716C;font-size:.85rem}
#tvv .tvv-r{display:flex;gap:.35rem;align-items:flex-start;flex-wrap:wrap;justify-content:flex-end;max-width:11rem}
#tvv .tvv-ib{width:30px;height:30px;border-radius:50%;border:1.5px solid #92400E;background:#FFFBF2;color:#B45309;display:inline-flex;align-items:center;justify-content:center;padding:0;cursor:pointer}
#tvv .tvv-ib:hover,#tvv .tvv-ib:focus-visible{background:#8FBCA8;color:#1F2937;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
#tvv .tvv-svg{width:16px;height:16px}
#tvv .tvv-plus{width:38px;height:38px;background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text)}#tvv .tvv-plus .tvv-svg{width:20px;height:20px}
@media (min-width:768px){#tvv #tvv-q::-webkit-calendar-picker-indicator{display:none!important}}
#tvv .tvv-show{display:flex;align-items:center;gap:.5rem;margin-top:.35rem;padding:.2rem .25rem .2rem .5rem;background:#F5EFE6;border-radius:.3rem}
#tvv .tvv-pw{flex:1;min-width:0;font-family:ui-monospace,Menlo,monospace;word-break:break-all;filter:blur(4px);transition:filter .15s}
#tvv .tvv-show:hover .tvv-pw,#tvv .tvv-pw:focus{filter:none}
#tvv .tvv-pwt{font-size:.8rem;color:#8A7355;font-variant-numeric:tabular-nums}
#tvv .tvv-pwx{width:28px;height:28px;border:0;border-radius:50%;background:none;color:#92400E;font-size:1.3rem;line-height:1;cursor:pointer;padding:0}
#tvv .tvv-pwx:hover,#tvv .tvv-pwx:focus-visible{background:#E7D9C4}
#tvv .tvv-ib[aria-pressed=true]{background:#8FBCA8;color:#1F2937;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
#tvv #tvv-kitwords{display:grid;grid-template-columns:repeat(auto-fill,minmax(9rem,1fr));gap:.35rem;list-style:none;padding:0;margin:.75rem 0;counter-reset:w}
#tvv #tvv-kitwords li{background:#fff;border:1px solid #E7D9C4;border-radius:.4rem;padding:.35rem .5rem;font-family:ui-monospace,Menlo,monospace}
#tvv #tvv-kitwords li span{display:inline-block;min-width:1.6rem;color:#78716C}
#tvv .tvv-list{list-style:none;padding:0;margin:.4rem 0}#tvv .tvv-list li{padding:.35rem 0;border-bottom:1px solid #F0E6D6}
#tvv #tvv-log{list-style:none;padding:0;margin:.4rem 0;font-size:.82rem;line-height:1.35}#tvv #tvv-log li{padding:.25rem 0;border-bottom:1px solid #F0E6D6}#tvv #tvv-log time{color:#57534E;font-variant-numeric:tabular-nums;margin-right:.35rem}#tvv #tvv-log .tvv-sub{font-size:.78rem}

#tvv .tvv-pp{position:relative;display:block;max-width:28rem}#tvv .tvv-pp input{padding-right:2.8rem}
#tvv .tvv-eye{position:absolute;top:50%;right:.35rem;transform:translateY(-50%);width:34px;height:34px;border:0;background:none;color:#8A7355;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:.4rem}
#tvv .tvv-mask{-webkit-text-security:disc;text-security:disc}
#tvv .tvv-eye[aria-pressed=true]{color:#92400E;background:rgba(146,64,14,.08)}
#tvv .tvv-f .tvpw{max-width:28rem}
#tvv .tvv-rules{list-style:none;margin:.3rem 0 .5rem;padding:0;font-size:.8rem;line-height:1.55}#tvv .tvv-rules li{color:#8A7355}#tvv .tvv-rules li:before{content:"○ "}
#tvv .tvv-rules li.ok{color:#1F5C43}#tvv .tvv-rules li.ok:before{content:"✓ ";font-weight:700}#tvv .tvv-rules li.no{color:#991B1B}#tvv .tvv-rules li.no:before{content:"✕ "}
#tvv .tvv-meter{display:block;max-width:28rem;height:6px;background:#EFE6D8;border-radius:3px;margin-top:.35rem;overflow:hidden}#tvv .tvv-meter i{display:block;height:100%;width:0;transition:width .2s,background .2s}
#tvv .tvv-meter.w i{background:#B91C1C}#tvv .tvv-meter.f i{background:#D97706}#tvv .tvv-meter.g i{background:#2F7D5B}
#tvv #tvv-steps{display:flex;flex-wrap:wrap;gap:.25rem .9rem;list-style:none;padding:0;margin:.5rem 0 .25rem;counter-reset:s;font-size:.85rem}
#tvv #tvv-steps li{counter-increment:s;color:#8A7355}#tvv #tvv-steps li:before{content:counter(s);display:inline-flex;align-items:center;justify-content:center;width:1.4rem;height:1.4rem;border-radius:50%;border:1.5px solid #D6C7B0;margin-right:.35rem;font-size:.75rem}
#tvv #tvv-steps li.now{color:#92400E;font-weight:700}#tvv #tvv-steps li.now:before{border-color:#92400E;background:#FFFBF2}
#tvv #tvv-steps li.done{color:#1F5C43}#tvv #tvv-steps li.done:before{content:"✓";background:#8FBCA8;border-color:#8FBCA8;color:#1F2937}
#tvv .tvv-tick{display:flex;align-items:flex-start;padding-top:.15rem}#tvv .tvv-tick input{width:18px;height:18px;accent-color:var(--tv-link,#92400E)}
#tvv .tvv-l{flex:1;min-width:0}
#tvv .tvv-selbar{position:sticky;top:calc(var(--ta-top,56px) + var(--as-h,0px) + 2.5rem);z-index:29;background:#FFFBF2;border:1px solid #92400E;border-radius:.5rem;padding:.35rem .5rem .35rem 0;box-shadow:0 6px 16px -10px rgba(0,0,0,.35)}
#tvv .tvv-all{display:inline-flex;align-items:center;height:38px;padding:0 .35rem 0 calc(.75rem + 1px);cursor:pointer}   /* over the rows' boxes */
#tvv .tvv-selbar .tvv-all{padding-left:.75rem}#tvv .tvv-all input,#tvv .tvv-tick input{width:18px;height:18px;accent-color:var(--tv-link,#92400E);cursor:pointer}
#tvv .tvv-tick{opacity:.55;transition:opacity .15s}#tvv .tvv-tr:hover .tvv-tick,#tvv .tvv-th .tvv-tick,#tvv .tvv-tick:has(input:checked),#tvv .tvv-tick:focus-within{opacity:1}
#tvv .tvv-card:has(.tvv-tick input:checked){background:var(--tv-card-a,#FFFBF2);border-color:var(--tv-link,#92400E)}
#tvv .tvv-link{border:0;background:none;color:#92400E;text-decoration:underline;font:inherit;cursor:pointer;padding:.2rem .3rem}
#tvv .tvv-selbar .tvv-sp{flex:1}
#tvv .tvv-selbar .ak-b.no{display:inline-flex;align-items:center;gap:.35rem;background:#B91C1C;border-color:#B91C1C;color:#fff}#tvv .tvv-selbar .ak-b.no:hover{background:#991B1B}
#tvv .tvv-selbar .tvv-div{width:1px;align-self:stretch;background:#E7D9C4;margin:0 .2rem}
#tvv .tvv-morebtn{display:block;width:100%;margin:.6rem 0 0;padding:.65rem 1rem}
#tvv .tvv-pager{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .8rem;margin:.6rem 0 0;padding:.5rem 0 0;border-top:1px solid var(--tv-line,#F0E6D6)}
#tvv #tvv-pages{display:flex;flex-wrap:wrap;gap:.25rem;align-items:center}
#tvv .tvv-pg{min-width:34px;height:34px;padding:0 .5rem;border:1px solid var(--tv-line,#E7D9C4);border-radius:.4rem;background:#fff;color:var(--tv-ink,#2A1D14);font:inherit;cursor:pointer;font-variant-numeric:tabular-nums}
#tvv .tvv-pg:hover:not(:disabled){border-color:var(--tv-link,#92400E);color:var(--tv-link,#92400E)}
#tvv .tvv-pg[aria-current]{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text);font-weight:700}
#tvv .tvv-pg:disabled{opacity:.4;cursor:default}
#tvv .tvv-gap{color:var(--tv-meta,#5E4F3C);padding:0 .2rem}
#tvv .tvv-perl{margin-left:auto;display:flex;align-items:center;gap:.4rem;font-size:.9rem;color:var(--tv-meta,#57534E);white-space:nowrap}
#tvv #tvv-per{padding:.45rem .6rem;border:1px solid var(--tv-line-strong,#D6C7B0);border-radius:.4rem;background:#fff;font:inherit}
#tvv #tvv-showsel{padding:.45rem .6rem;border:1.5px solid #92400E;border-radius:999px;background:#FFFBF2;color:#92400E;font:inherit;font-weight:600}
#tvv .tvv-fold{background:#fff;border:1px solid #E7D9C4;border-radius:.5rem;margin:.6rem 0}
#tvv .tvv-fold>summary{cursor:pointer;list-style:none;padding:.6rem .8rem;font:700 1.05rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;display:flex;align-items:center;gap:.5rem}
#tvv .tvv-fold>summary::-webkit-details-marker{display:none}
#tvv .tvv-fold>summary:before{content:"▸";color:#92400E;transition:transform .15s}#tvv .tvv-fold[open]>summary:before{transform:rotate(90deg)}
#tvv .tvv-foldb{padding:0 .8rem .7rem}
#tvv .tvv-panel{position:fixed;top:0;right:0;bottom:0;width:min(32rem,100%);z-index:1450;margin:0;background:#FFFBF2;border-left:1px solid #E7D9C4;box-shadow:-10px 0 28px rgba(0,0,0,.2);padding:0 1.1rem 1.25rem;overflow:auto;overscroll-behavior:contain;box-sizing:border-box}
#tvv #tvv-shade{position:fixed;inset:0;z-index:1449;background:rgba(31,41,55,.35)}
#tvv .tvv-ph{position:sticky;top:0;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:.5rem;font:700 1.1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:0 -1.1rem .4rem;padding:.8rem 1.1rem .6rem;background:#FFFBF2;border-bottom:1px solid #E7D9C4}
#tvv .tvv-panel .tvv-box{margin:.5rem 0}
#tvv .tvv-steps2{margin:.4rem 0;padding-left:1.3rem}#tvv .tvv-steps2 li{margin:.3rem 0}
@media (max-width:767px){#tvv .tvv-panel{top:auto;max-height:90vh;max-height:90dvh;border-left:0;border-top:1px solid #E7D9C4;border-radius:.75rem .75rem 0 0;box-shadow:0 -10px 28px rgba(0,0,0,.2)}}
#tvv .tvv-x{border:0;background:none;color:#92400E;font-size:1.4rem;line-height:1;cursor:pointer;padding:.1rem .4rem}
#tvv .tvv-box{background:#fff;border:1px solid #E7D9C4;border-radius:.5rem;padding:.75rem;margin:.6rem 0}
#tvv .tvv-box h3{margin:0 0 .3rem;font-size:1rem}
#tvv #tvv-appqr svg{width:180px;height:180px;background:#fff;padding:6px;border-radius:.3rem}
#tvv .tvv-kw input{max-width:12rem}
.tvv-warn{position:fixed;inset:0;z-index:2147483000;background:rgba(31,41,55,.45);display:flex;align-items:center;justify-content:center;padding:1rem}
.tvv-warn-b{background:#FFFBF2;border:1px solid #E7D9C4;border-radius:.6rem;box-shadow:0 12px 32px rgba(0,0,0,.25);padding:1.1rem 1.2rem;max-width:22rem;width:100%;font:inherit;color:#1F2937}
.tvv-warn-b{position:relative}.tvv-warn-b p{margin:.2rem 0 .5rem}.tvv-warn-b #tvv-warn-t{color:#92400E;font-size:1.1rem;padding-right:2.5rem}.tvv-warn-n{font-variant-numeric:tabular-nums}
.tvv-warn-x{position:absolute;top:.7rem;right:.7rem;width:34px;height:34px;border-radius:50%;border:1.5px solid #991B1B;background:#FFFBF2;color:#991B1B;display:inline-flex;align-items:center;justify-content:center;padding:0;cursor:pointer}.tvv-warn-x svg{width:16px;height:16px}
.tvv-warn-x:hover,.tvv-warn-x:focus-visible{background:#FEE2E2}
.tvv-warn-keep{display:block;width:100%;margin-top:.8rem;padding:.75rem 1rem;font-size:1.05rem}
@media print{body.tvv-printing *{visibility:hidden}body.tvv-printing #tvv-kit,body.tvv-printing #tvv-kit *{visibility:visible}body.tvv-printing #tvv-kit{position:absolute;left:0;top:0}body.tvv-printing #tvv-kit .tvv-row{display:none}}
@media (max-width:767px){#tvv .tvv-card{border-radius:.5rem}}
</style>
<div id="tvv" data-ext="<?= $e(getenv('VAULT_EXTENSION_ID') ?: 'leflbllgieloanpllabjmbjimemcjicj') ?>" data-me="<?= $e($me['email'] ?? '') ?>" data-icons="<?= $e(json_encode($icons)) ?>">
  <div id="tvv-status" aria-live="polite"><p class="tvv-sub">Checking your vault…</p></div>
  <ol id="tvv-steps" hidden aria-label="Setting up your vault"><li>This device</li><li>Passphrase</li><li>Recovery words</li><li>Extra checks</li><li>Your vault</li></ol>
  <noscript><p data-tv-status="bad" data-tv-label="Needs JavaScript:">The vault opens only in your browser, so it needs JavaScript.</p></noscript>

  <section id="tvv-setup" hidden>
    <p>Your vault keeps the logins for our outside services where only you can open them: they're sealed here in your browser before they're saved, and opened only with this device's passkey and your vault passphrase. No one at Traversence can read them, or reset the vault for you.</p>
    <p><b>First, this device's passkey.</b> Your computer or phone asks for your fingerprint, face or PIN (Windows Hello, Touch ID, or your phone). Only its signature reaches us, never the fingerprint.</p>
    <label class="tvv-f"><span>Name this device (so you know it in the list later)</span><input type="text" id="tvv-label" maxlength="80" placeholder="Office computer" data-spell></label>
    <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="setup">Make this device's passkey</button></div>
  </section>

  <section id="tvv-phrase" hidden>
    <p><b>Now your vault passphrase.</b> It isn't a password: it never leaves this browser, we never see it, and no one can reset it. A few unrelated words is easiest to remember and hardest to guess (e.g. four or more words with spaces). Use it only here.</p>
    <?= $pp('tvv-p1', 'Vault passphrase', true, 'tvv-p2') ?>
    <div class="tvv-row" style="margin-top:0"><button type="button" class="ak-b" data-tvv="suggest" data-for="#tvv-p1">Suggest one for me</button></div>
    <?= $pp('tvv-p2', 'Type it again', true, '', 'tvv-p1') ?>
    <label class="tvv-row"><input type="checkbox" id="tvv-ptick"> It isn't my sign-in password, or one I use anywhere else</label>
    <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="pass">Continue</button></div>
    <p class="tvv-sub">Next: your 24 recovery words, in case you ever forget it.</p>
  </section>

  <section id="tvv-unlock" hidden>
    <p class="tvv-sub">Check it's you one of three ways; then this device's PIN, fingerprint or face (or your phone or security key) opens the vault.</p>
    <div class="tvv-ways" id="tvv-ways">
      <div class="tvv-way" data-way="pass"><button type="button" class="tvv-wayb" data-tvv="way" aria-expanded="false"><b>1</b><span>Unlock with my passphrase<small>Works on any device with a passkey for the vault</small></span></button>
        <div class="tvv-wayf" hidden><?= $pp('tvv-pass', 'Vault passphrase', false) ?><div class="tvv-row"><button type="button" class="ak-b go" data-tvv="unlock">Unlock</button></div></div></div>
      <div class="tvv-way" data-way="app"><button type="button" class="tvv-wayb" data-tvv="way" aria-expanded="false"><b>2</b><span>Unlock with my authenticator app<small class="tvv-why"></small></span></button>
        <div class="tvv-wayf" hidden><label class="tvv-f"><span>The code your authenticator app shows for Traversence Vault</span><input type="text" id="tvv-uapp" inputmode="numeric" autocomplete="one-time-code" maxlength="8" spellcheck="false" style="max-width:10rem"></label>
          <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="pinapp">Continue to my PIN</button></div></div></div>
      <div class="tvv-way" data-way="email"><button type="button" class="tvv-wayb" data-tvv="way" aria-expanded="false"><b>3</b><span>Unlock with an emailed code<small class="tvv-why"></small></span></button>
        <div class="tvv-wayf" hidden><p class="tvv-sub" id="tvv-umailsent" aria-live="polite"></p><label class="tvv-f"><span>The code from the email</span><input type="text" id="tvv-umail" inputmode="numeric" autocomplete="one-time-code" maxlength="8" spellcheck="false" style="max-width:10rem"></label>
          <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="pinmail">Continue to my PIN</button><button type="button" class="ak-b" data-tvv="umailagain">Send it again</button></div></div></div>
    </div>
    <div class="tvv-row"><button type="button" class="ak-b" data-tvv="toadd">Add this device</button>
      <button type="button" class="ak-b" data-tvv="torecover">Forgot everything? Use your recovery words</button></div>
  </section>

  <section id="tvv-adddev" hidden>
    <p>A new computer or browser: we email you a code, then this device makes its passkey. It can't open anything until a device that has the vault gives it the key (Devices, "Give it the key"), or you use your recovery words.</p>
    <label class="tvv-f"><span>Name this device</span><input type="text" id="tvv-dlabel" maxlength="80" placeholder="Laptop" data-spell></label>
    <div class="tvv-row"><button type="button" class="ak-b" data-tvv="code">Email me a code</button></div>
    <label class="tvv-f"><span>The code from the email</span><input type="text" id="tvv-code" inputmode="numeric" autocomplete="one-time-code" maxlength="8" spellcheck="false" style="max-width:10rem"></label>
    <label class="tvv-f tvv-needapp" hidden><span>The code your authenticator app shows for Traversence Vault</span><input type="text" id="tvv-dapp" inputmode="numeric" autocomplete="one-time-code" maxlength="8" spellcheck="false" style="max-width:10rem"></label>
    <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="adddev">Add this device</button><button type="button" class="ak-b" data-tvv="tounlock">Back</button></div>
    <p class="tvv-sub">No email? Send a new code, or ask our team at <a href="mailto:support@traversence.com">support@traversence.com</a> (we can help with your sign-in, never open the vault).</p>
  </section>

  <section id="tvv-nokeys" hidden>
    <p>This device has a passkey for the vault but not the key yet. Either open the vault on a device that has it and press <b>Give it the key</b> under Devices, then come back and Unlock; or use your recovery words here.</p>
    <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="tounlock">I gave it the key: Unlock</button><button type="button" class="ak-b" data-tvv="torecover">Use my recovery words</button></div>
  </section>

  <section id="tvv-recover" hidden>
    <p>Enter your 24 recovery words, in order. Using them retires them: you'll save 24 new words straight after, and we email you that they were used.</p>
    <label class="tvv-f"><span>Your 24 words</span><textarea id="tvv-words" rows="4" spellcheck="false" autocomplete="off" autocapitalize="none"></textarea></label>
    <label class="tvv-f tvv-needapp" hidden><span>The code your authenticator app shows for Traversence Vault</span><input type="text" id="tvv-rapp" inputmode="numeric" autocomplete="one-time-code" maxlength="8" spellcheck="false" style="max-width:10rem"></label>
    <?= $pp('tvv-rp1', 'A vault passphrase for this device (your old one, or a new one)', true, 'tvv-rp2') ?>
    <?= $pp('tvv-rp2', 'Type it again', true, '', 'tvv-rp1') ?>
    <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="recover">Open with my words</button><button type="button" class="ak-b" data-tvv="tounlock">Back</button></div>
    <p class="tvv-sub">Lost the words too, and no device opens the vault? Then it can't be opened, by anyone: each service's own "forgot password" is the way back. Ask our team for help with your Traversence sign-in at <a href="mailto:support@traversence.com">support@traversence.com</a>.</p>
  </section>

  <section id="tvv-kit" hidden>
    <div id="tvv-kitlist">
      <h2 class="hb-h">Your Emergency Kit</h2>
      <p><b>Traversence Vault</b> for <?= $e($me['email'] ?? '') ?>. Your 24 recovery words, in order:</p>
      <ol id="tvv-kitwords"></ol>
      <p>Keep them offline: printed, or the text file on a drive you keep safe. Never email them, photograph them or put them in the cloud. We never send them and can't show them again.</p>
      <div class="tvv-row"><button type="button" class="ak-b" data-tvv="kitdl">Download as a text file</button><button type="button" class="ak-b" data-tvv="kitprint">Print</button></div>
      <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="kitnext">I've saved them: check my copy</button></div>
    </div>
    <div id="tvv-kitverify" hidden>
      <p><b>Check your saved copy.</b> Type these three words from it (not from memory), so we know the kit you kept is right.</p>
      <div id="tvv-kitcheck"></div>
      <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="kitdone">Save my words</button><button type="button" class="ak-b" data-tvv="kitback">Back to the words</button></div>
    </div>
  </section>

  <section id="tvv-extra" hidden>
    <div class="tvv-box">
      <h3>Authenticator app (recommended)</h3>
      <p class="tvv-sub">Microsoft Authenticator, Google Authenticator or 1Password on your phone. Once added, its code is needed to add a device or use your recovery words, so someone with your email or sign-in can't do either; and with this device's PIN it opens the vault (way 2). On its own it never opens anything.</p>
      <div id="tvv-appoff"><div class="tvv-row"><button type="button" class="ak-b go" data-tvv="appstart">Add an authenticator app</button></div></div>
      <div id="tvv-appnew" hidden>
        <p class="tvv-sub">In the app, add an account and scan this code. Then type the code it shows.</p>
        <div id="tvv-appqr" aria-label="Authenticator setup code"></div>
        <details class="tvv-sub"><summary style="cursor:pointer;color:#92400E;font-weight:600">Can't scan? Show the key</summary><p>Type this key into the app: <code id="tvv-appkey"></code><br>It's a secret: don't share it or put it in a screenshot.</p></details>
        <div class="tvv-row"><input type="text" id="tvv-appcode" inputmode="numeric" autocomplete="one-time-code" maxlength="8" placeholder="000000" aria-label="The code the app shows" spellcheck="false" style="max-width:9rem"><button type="button" class="ak-b go" data-tvv="appadd">Add it</button><button type="button" class="ak-b" data-tvv="appnew">New key</button></div>
      </div>
      <div id="tvv-appon" hidden><p data-tv-status="ok" data-tv-label="Added:">Its code is needed to add a device or use your recovery words.</p><div class="tvv-row"><button type="button" class="ak-b" data-tvv="appremove">Remove it</button></div></div>
    </div>
    <div class="tvv-box">
      <h3>A spare passkey (recommended)</h3>
      <p class="tvv-sub">A second passkey kept somewhere other than this computer, so a lost or broken computer doesn't lock you out: the spare opens the vault with your passphrase, without using your recovery words. It can be <b>your phone</b> (press the button, choose "Use a phone or tablet", scan the code with your phone's camera, and confirm on the phone: the passkey is saved there) or a <b>security key</b> such as a YubiKey (plug it in and touch it). Nothing is sent to your phone number; there's no text message.</p>
      <label class="tvv-f"><span>Name the spare, so you know it in the list (e.g. My iPhone, YubiKey)</span><input type="text" id="tvv-slabel" placeholder="My iPhone" maxlength="80" data-spell style="max-width:16rem"></label>
      <div class="tvv-row"><button type="button" class="ak-b" data-tvv="spare">Add a spare passkey</button></div>
    </div>
    <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="extradone">Open my vault</button></div>
    <p class="tvv-sub">You can add or change these any time under the vault's <b>Devices</b>.</p>
  </section>

  <section id="tvv-main" hidden>
    <div id="tvv-bar" role="toolbar" aria-label="Vault" hidden>
      <span class="tvv-open">Vault expires: <b id="tvv-left" title="Time before the vault asks if you're still there">05:00</b></span>
      <button type="button" class="tvv-cib" data-tvv="keepopen" aria-label="Keep it open: 5 more minutes" title="Keep it open: 5 more minutes"><svg class="tvv-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path d="M3.5 15a9 9 0 1 0 2.1-9.4L1 10"/></svg></button>
      <button type="button" class="tvv-cib" data-tvv="close" aria-label="Close the vault on this device" title="Close the vault on this device"><?= tv_icon('power', 'tvv-svg') ?></button>
      <button type="button" class="tvv-cib tvv-lk" data-tvv="lock" aria-label="Lock the vault everywhere: nothing opens on any device or the extension until you unlock it with your passkey" title="Lock the vault everywhere (all devices and the extension)"><?= $lockOpen ?></button>
      <details class="tvv-tdd"><summary aria-label="Vault tools" title="Vault tools"><svg class="tvv-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/><path d="M15 15l6 6"/><path d="M19 4l2 2-5 5"/></svg></summary>
        <div class="tvv-tdl" role="menu"><button type="button" role="menuitem" data-tvv="toimport" aria-controls="tvv-import">Import passwords</button>
        <button type="button" role="menuitem" data-tvv="towords" aria-controls="tvv-wordspanel">Recovery words</button>
        <button type="button" role="menuitem" data-tvv="tonotify" aria-controls="tvv-notifypanel">Emails</button></div></details></div>
    <div id="tvv-shade" hidden data-tvv="panelx"></div>
    <div id="tvv-notifypanel" class="tvv-panel" role="dialog" aria-label="Emails from the vault" hidden><div class="tvv-ph"><b>Emails from the vault</b><button type="button" class="tvv-x" data-tvv="panelx" aria-label="Close" title="Close">×</button></div>
      <p class="tvv-sub">What the vault emails you, and how often. Everything is still kept in <b>What's been done</b>; this only decides the email. Summaries list what happened but not which login (only your browser can read their names).</p>
      <div id="tvv-notify"><p class="tvv-sub">Loading…</p></div>
      <div class="tvv-row"><button type="button" class="ak-b go" data-tvv="notifysave">Save</button></div>
    </div>
    <div id="tvv-extpanel" class="tvv-panel" role="dialog" aria-label="Install the browser extension" hidden><div class="tvv-ph"><b>Install the browser extension</b><button type="button" class="tvv-x" data-tvv="panelx" aria-label="Close" title="Close">×</button></div>
      <p class="tvv-sub">For Chrome or Edge on a computer (not phones yet). It's ours, not in the browser's store, so it's added by hand, once per browser:</p>
      <ol class="tvv-steps2">
        <li><a class="ak-b go" href="/admin/api/vault.php?extension=1" download>Download the extension</a></li>
        <li>Unzip it (Windows: right-click the file → <b>Extract All</b>; Mac: double-click it). You get a folder named <b>traversence-vault</b>. Keep it where it won't be deleted: the browser uses it from there.</li>
        <li>Open <b>chrome://extensions</b> in Chrome, or <b>edge://extensions</b> in Edge (type it in the address bar).</li>
        <li>Turn on <b>Developer mode</b> (top right in Chrome, left side in Edge).</li>
        <li>Press <b>Load unpacked</b> and choose the <b>traversence-vault</b> folder.</li>
        <li>Pin it: the puzzle piece by the address bar → the pin beside Traversence Vault.</li>
        <li>Come back here and reload this page, then press <b>Connect this browser's extension</b>.</li>
      </ol>
      <p class="tvv-sub">Updating: download it again, replace the folder's files, and press the ↻ on the extension's card in chrome://extensions. Chrome may say "Disable developer mode extensions" at start-up: choose <b>Keep</b> (or close the note).</p>
    </div>
    <div id="tvv-form" class="tvv-panel" role="dialog" aria-labelledby="tvv-ftitle" hidden><div class="tvv-ph"><b id="tvv-ftitle">Add a login</b><button type="button" class="tvv-x" data-tvv="panelx" aria-label="Close" title="Close">×</button></div>
      <label class="tvv-f"><span>Name (the company or service)</span><input type="text" id="tvv-fname" maxlength="80" data-spell></label>
      <label class="tvv-f"><span>Where you sign in (the exact page: the password opens only for it)</span><input type="url" id="tvv-furl" placeholder="https://dash.cloudflare.com/login" spellcheck="false"></label>
      <label class="tvv-f"><span>User name or email</span><input type="text" id="tvv-fuser" autocomplete="off" spellcheck="false"></label>
      <?= $pp('tvv-fpass', 'Password', false) ?>
      <div class="tvv-row"><button type="button" class="ak-b" data-tvv="gen">Make a strong one</button></div>
      <label class="tvv-f"><span>Notes (sealed with the password)</span><textarea id="tvv-fnotes" rows="2" data-spell></textarea></label>
      <div class="tvv-row"><button type="button" class="ak-b go" id="tvv-fsave" data-tvv="save">Save login</button><button type="button" class="ak-b" data-tvv="cancel">Cancel</button></div>
    </div>
    <div id="tvv-import" class="tvv-panel" role="dialog" aria-label="Import" hidden><div class="tvv-ph"><b>Import your saved passwords</b><button type="button" class="tvv-x" data-tvv="panelx" aria-label="Close import" title="Close">×</button></div>
      <p class="tvv-sub"><b>From Google Password Manager:</b> open <b>chrome://password-manager/settings</b> in Chrome (Edge: <b>edge://wallet/passwords</b>, then ⋯ → Export), choose <b>Export passwords</b>, confirm with your computer's PIN, and save the file. <b>From 1Password:</b> File → Export → choose the account → CSV.</p>
      <p class="tvv-sub">Then pick the file here. It's read and sealed in this browser; the file itself is never uploaded. Logins already in your vault are left as they are, and entries without a web address (phone apps) are skipped.</p>
      <label class="tvv-f"><span>The exported file (.csv)</span><input type="file" id="tvv-impfile" accept=".csv,text/csv" data-art="off"></label>
      <p class="tvv-sub" id="tvv-impsum" aria-live="polite"></p>
      <ul class="tvv-list" id="tvv-implist" style="max-height:16rem;overflow:auto"></ul>
      <div class="tvv-row"><button type="button" class="ak-b go" id="tvv-impgo" data-tvv="impgo" hidden>Add them to my vault</button></div>
    </div>
    <div id="tvv-wordspanel" class="tvv-panel" role="dialog" aria-label="Recovery words" hidden><div class="tvv-ph"><b>Recovery words</b><button type="button" class="tvv-x" data-tvv="panelx" aria-label="Close recovery words" title="Close">×</button></div>
      <p class="tvv-sub"><span id="tvv-kitdate"></span> Lost them, or think someone saw them? Make new ones: the old ones stop working.</p>
      <div class="tvv-row"><button type="button" class="ak-b" data-tvv="words">Make new recovery words</button></div>
    </div>
    <details class="tvv-fold" data-fold="ext" open><summary>Browser extension</summary><div class="tvv-foldb">
    <p class="tvv-sub">Fills your logins on their own sites in Chrome and Edge (only the exact site), and offers to save new ones. Connected for 12 hours at a time; locking the vault disconnects it.</p>
    <div id="tvv-ext"></div>
    </div></details>
    <details class="tvv-fold" data-fold="logins" open><summary>Manage logins <span class="tvv-sub" id="tvv-lcount"></span></summary><div class="tvv-foldb">
    <div class="tvv-tb" id="tvv-tb"><button type="button" class="tvv-ib tvv-plus" id="tvv-add" data-tvv="add" aria-label="Add a login" title="Add a login"><?= tv_icon('plus', 'tvv-svg') ?></button>
      <input type="search" id="tvv-q" list="tvv-accts" placeholder="Search sites, names and accounts" aria-label="Search your logins" autocomplete="off" spellcheck="false"><datalist id="tvv-accts"></datalist>
      <select id="tvv-showsel" aria-label="Show"><option value="all">Show: All logins</option></select>
      <span class="tvv-sub tvv-cnt" id="tvv-count"></span></div>
    <div id="tvv-table" role="table" aria-label="Your logins">
    <div class="tvv-th" id="tvv-th" role="row"><label class="tvv-tick tvv-c0" title="Select the logins on this page"><input type="checkbox" class="tvv-pageall" aria-label="Select the logins on this page"></label>
      <div class="tvv-thc" id="tvv-thc"></div>
      <div class="tvv-selbar" id="tvv-selbar" role="toolbar" aria-label="Selected logins" hidden>
      <b id="tvv-selcount" aria-live="polite">0 selected</b><button type="button" class="tvv-link" data-tvv="selall" id="tvv-selall">Select all matching</button><span class="tvv-sp"></span>
      <button type="button" class="ak-b" data-tvv="selnone" title="Clear the selection (Esc)">Clear</button>
      <button type="button" class="ak-b no" id="tvv-seldel" data-tvv="seldel"><?= tv_icon('trash', 'tvv-svg') ?><span>Delete</span></button></div>
    </div>
    <div id="tvv-items" role="rowgroup"></div>
    </div>
    <button type="button" class="ak-b tvv-morebtn" id="tvv-more" data-tvv="more" hidden>Show more</button>
    <div class="tvv-pager" id="tvv-pager" hidden><nav id="tvv-pages" aria-label="Pages of logins"></nav><span class="tvv-sub" id="tvv-range"></span>
      <label class="tvv-perl">Show <select id="tvv-per" aria-label="Logins per page"><option value="10" selected>10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option><option value="0">All</option></select> per page</label></div>
    </div></details>
    <div class="tvv-two">
    <details class="tvv-fold" data-fold="devices" id="tvv-devfold"><summary>Devices and checks</summary><div class="tvv-foldb">
    <p class="tvv-sub">The passkeys that open this vault. A device added on another computer waits here for its key.</p>
    <ul id="tvv-devices" class="tvv-lis"></ul>
    <p class="tvv-sub" style="margin-top:.8rem">The extra checks below protect the vault if someone gets your sign-in. They never open it on their own.</p>
    <div id="tvv-extrabody"></div>
    </div></details>
    <details class="tvv-fold" data-fold="log"><summary>What's been done</summary><div class="tvv-foldb">
    <p class="tvv-sub">Every password opened, device added and change, with where it came from, newest first. Emailed as you chose in <b>Emails</b>, each with a link to lock the vault.</p>
    <ul id="tvv-log"></ul>
    <button type="button" class="ak-b tvv-morebtn" id="tvv-logmore" data-tvv="logmore" hidden>Show 10 more</button>
    </div></details>
    </div>
  </section>
</div>
<script src="/js/tv-time.js?v=<?= (int) @filemtime(__DIR__ . '/../../website/js/tv-time.js') ?>"></script>
<script src="/js/tv-vault.js?v=<?= $js ?>" defer></script>
<?php
    return (string) ob_get_clean();
}
