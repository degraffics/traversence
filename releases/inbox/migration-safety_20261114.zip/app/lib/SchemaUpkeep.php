<?php
// app/lib/SchemaUpkeep.php — what's left in the database that nothing uses (Jason, 2026-11-14; decisions/0162).
// Migrations only add, so Roll back takes a release's files out and leaves what its migrations made (tables, columns,
// indexes). Those are recorded here as "left by release #N" (app/storage/schema/leftovers.json: never served or synced).
// A later release whose migrations make the same thing takes it up again. One still left after DUE_DAYS is proposed for
// removal: removal is a normal release (its migration copies the table first, then drops; release.json names it under
// "removes"), and Jason approves it. Keep holds one where it is.
declare(strict_types=1);

require_once __DIR__ . '/DbUpdates.php';

final class SchemaUpkeep
{
    public const DUE_DAYS = 30;

    private static function file(): string { return dirname(__DIR__) . '/storage/schema/leftovers.json'; }

    private static function read(): array
    {
        $j = json_decode((string) @file_get_contents(self::file()), true);
        return is_array($j) && isset($j['items']) && is_array($j['items']) ? $j : ['items' => []];
    }

    private static function write(array $j): void
    {
        $d = dirname(self::file());
        if (!is_dir($d)) @mkdir($d, 0750, true);
        @file_put_contents(dirname($d) . '/schema/.htaccess', "Require all denied\n");
        @file_put_contents(self::file(), json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    /** "table t", "column t.c", "index t.i" for one of DbUpdates::checks()'s items. */
    public static function key(array $c): string { return $c[0] === 'table' ? 'table ' . $c[1] : $c[0] . ' ' . $c[1] . '.' . $c[2]; }

    /** What a release's migrations make: key => [check, file]. $dir is where its files are (…/new/). */
    private static function made(array $files, string $dir): array
    {
        $out = [];
        foreach ($files as $p) {
            $sql = (string) @file_get_contents($dir . $p);
            foreach (DbUpdates::checks($sql) as $c) $out[self::key($c)] = [$c, basename($p)];
        }
        return $out;
    }

    /** On Roll back: records what the release's migrations made that's still there. Returns the keys recorded. */
    public static function recordLeftovers(PDO $pdo, array $r, array $migs, string $dir): array
    {
        $s = DbUpdates::schema($pdo);
        $j = self::read(); $got = [];
        foreach (self::made($migs, $dir) as $k => [$c, $file]) {
            $there = $c[0] === 'table' ? isset($s['t'][$c[1]]) : isset($s[$c[0] === 'column' ? 'c' : 'i'][$c[1] . '.' . $c[2]]);
            if (!$there) continue;
            $j['items'][$k] = ['check' => $c, 'release' => (int) $r['id'], 'title' => (string) $r['title'], 'file' => $file, 'at' => gmdate('c')];
            $got[] = $k;
        }
        if ($got) self::write($j);
        return $got;
    }

    /** On a publish: anything its migrations make again is taken up (no longer a leftover). Returns the keys taken up. */
    public static function takenUp(array $r, array $migs, string $dir): array
    {
        $j = self::read(); $got = [];
        foreach (array_keys(self::made($migs, $dir)) as $k) if (isset($j['items'][$k]) && (int) $j['items'][$k]['release'] !== (int) $r['id']) { unset($j['items'][$k]); $got[] = $k; }
        if ($got) self::write($j);
        return $got;
    }

    /** What's left now, oldest first (ones that are gone from the database are forgotten): key => item + ['due' => bool]. */
    public static function leftovers(PDO $pdo): array
    {
        $j = self::read();
        if (!$j['items']) return [];
        $s = DbUpdates::schema($pdo); $gone = false; $out = [];
        foreach ($j['items'] as $k => $it) {
            $c = (array) $it['check'];
            $there = $c[0] === 'table' ? isset($s['t'][$c[1]]) : isset($s[$c[0] === 'column' ? 'c' : 'i'][$c[1] . '.' . ($c[2] ?? '')]);
            if (!$there) { unset($j['items'][$k]); $gone = true; continue; }
            $it['due'] = empty($it['kept_at']) && strtotime((string) $it['at']) < time() - self::DUE_DAYS * 86400;
            $out[$k] = $it;
        }
        if ($gone) self::write($j);
        uasort($out, fn ($a, $b) => strcmp((string) $a['at'], (string) $b['at']));
        return $out;
    }

    /** Keep one where it is: not proposed for removal again. */
    public static function keep(string $key, int $uid): void
    {
        $j = self::read();
        if (!isset($j['items'][$key])) throw new RuntimeException('That isn\'t on the list any more.');
        $j['items'][$key]['kept_at'] = gmdate('c'); $j['items'][$key]['kept_by'] = $uid;
        self::write($j);
    }

    /** What a removal release may drop: the recorded leftovers (kept ones too, if a person sends their removal). */
    public static function removable(): array
    {
        return array_keys(self::read()['items']);
    }

    /**
     * What a migration drops: ["table t", "column t.c", "index t.i"], and anything else it does that isn't adding (a
     * rename, a changed column: never allowed). Drops inside the information_schema guard's strings count.
     */
    public static function drops(string $sql): array
    {
        $sql = implode(";\n", DbUpdates::statements($sql)) . ';';
        $q = '`?(\w+)`?'; $out = []; $other = [];
        preg_match_all("~\bDROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?(?:`?\w+`?\.)?$q~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) $out[] = 'table ' . strtolower($x[1]);
        preg_match_all("~\bALTER\s+TABLE\s+(?:`?\w+`?\.|`',\s*@\w+,\s*'`\.)?$q([^;']*)~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) {
            $t = strtolower($x[1]);
            preg_match_all("~\bDROP\s+(?:(COLUMN|INDEX|KEY)\s+)?$q~i", $x[2], $ds, PREG_SET_ORDER);
            foreach ($ds as $d) {
                $kind = strtoupper((string) $d[1]);
                if (in_array(strtoupper($d[2]), ['PRIMARY', 'FOREIGN', 'CONSTRAINT', 'CHECK'], true)) { $other[] = 'DROP ' . strtoupper($d[2]) . ' on ' . $t; continue; }
                $out[] = ($kind === 'INDEX' || $kind === 'KEY' ? 'index ' : 'column ') . $t . '.' . strtolower($d[2]);
            }
        }
        preg_match_all("~\bDROP\s+INDEX\s+$q\s+ON\s+(?:`?\w+`?\.)?$q~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) $out[] = 'index ' . strtolower($x[2]) . '.' . strtolower($x[1]);
        if (preg_match_all('/\b(DROP\s+(?:DATABASE|VIEW|TRIGGER)|RENAME\s+(?:TABLE|COLUMN|TO)|TRUNCATE|MODIFY\s+(?:COLUMN\s+)?\w+|CHANGE\s+(?:COLUMN\s+)?\w+)\b/i', $sql, $m)) foreach ($m[1] as $x) $other[] = strtoupper(preg_replace('/\s+/', ' ', $x));
        return ['drops' => array_values(array_unique($out)), 'other' => array_values(array_unique($other))];
    }
}
