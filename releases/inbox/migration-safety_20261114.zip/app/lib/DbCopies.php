<?php
// app/lib/DbCopies.php — a copy of the tables a migration touches, taken just before it runs (Jason, 2026-11-14;
// decisions/0162). Every migration the site runs (at a release's publish, on staging, or the hourly backup run) goes
// through DbUpdates::autoRun, which calls before() first: the tables its ALTER, UPDATE, DELETE, INSERT, REPLACE, DROP or
// TRUNCATE statements name are found (in main or the realm a table has moved to, decisions/0110) and each is written,
// compressed, to app/storage/db-copies/<id>/ (never served, never synced), kept 14 days. System Configuration →
// Database updates lists them, each with Restore. Bluehost's disk is minded: a table over MAX_BYTES, or one the disk has
// no room for, is skipped with the reason recorded. A migration that changes rows (UPDATE, DELETE, a drop) is never run
// without its copy: a skip or a failure there stops it, and it's tried again on the next run.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class DbCopies
{
    public const KEEP_DAYS = 14;
    public const MAX_BYTES = 300 * 1024 * 1024;     // one table bigger than this (data and indexes) isn't copied
    public const ALL_BYTES = 1536 * 1024 * 1024;    // all the copies kept together stay under this
    private const BATCH = 500;
    private const NOT_TABLES = ['if', 'set', 'table', 'into', 'from', 'where', 'select', 'ignore', 'low_priority', 'quick', 'exists', 'not', 'information_schema', 'db_updates_log'];

    public static function dir(): string { return dirname(__DIR__) . '/storage/db-copies'; }

    private static function strip(string $sql): string
    {
        require_once __DIR__ . '/DbUpdates.php';
        $sql = implode(";\n", DbUpdates::statements($sql)) . ';';   // comments out, outside quotes only
        return (string) preg_replace('~\bON\s+(?:DUPLICATE\s+KEY\s+)?(?:UPDATE|DELETE)\b~i', ' ', $sql);   // not an UPDATE or DELETE of its own
    }

    /**
     * The tables a migration writes to: [[database or '', table, how]], how alter|update|delete|insert|drop. Statements
     * inside the strings of the information_schema guard (CLAUDE.md) count too, and a database the file finds for itself
     * (`', @db, '`.t) is left for where() to find.
     */
    public static function targets(string $sql): array
    {
        $sql = self::strip($sql);
        $t = '(?:`?(\w+)`?\s*\.\s*|`\'\s*,\s*@\w+\s*,\s*\'`\.)?`?(\w+)`?';
        $pats = [
            'alter' => "~\bALTER\s+(?:IGNORE\s+)?TABLE\s+$t~i",
            'update' => "~\bUPDATE\s+(?:LOW_PRIORITY\s+|IGNORE\s+)*$t~i",
            'delete' => "~\bDELETE\b[^;']*?\bFROM\s+$t~i",
            'insert' => "~\b(?:INSERT\s+(?:LOW_PRIORITY\s+|DELAYED\s+|HIGH_PRIORITY\s+|IGNORE\s+)*(?:INTO\s+)?|REPLACE\s+(?:LOW_PRIORITY\s+|DELAYED\s+)*INTO\s+)$t~i",
            'drop' => "~\b(?:DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?|TRUNCATE\s+(?:TABLE\s+)?|RENAME\s+TABLE\s+)$t~i",
        ];
        $out = [];
        foreach ($pats as $how => $p) {
            preg_match_all($p, $sql, $m, PREG_SET_ORDER);
            foreach ($m as $x) {
                $name = (string) $x[2];
                if (in_array(strtolower($name), self::NOT_TABLES, true) || is_numeric($name)) continue;
                $db = (string) ($x[1] ?? '');
                $k = strtolower($db . '.' . $name);
                $rank = ['insert' => 1, 'alter' => 2, 'update' => 3, 'delete' => 4, 'drop' => 5];
                if (!isset($out[$k]) || $rank[$how] > $rank[$out[$k][2]]) $out[$k] = [$db, $name, $how];
            }
        }
        return array_values($out);
    }

    /** Does the migration change or remove rows or tables (UPDATE, DELETE, TRUNCATE, a drop)? Those need a reason and their copy. */
    public static function changesData(string $sql): bool
    {
        $sql = self::strip($sql);
        return (bool) preg_match('~\bUPDATE\s+(?:LOW_PRIORITY\s+|IGNORE\s+)*`?\w+`?(?:\s*\.\s*`?\w+`?)?[^;]{0,4000}?\bSET\b|\bDELETE\b[^;\']*?\bFROM\b|\bTRUNCATE\b|\bDROP\s+(?:TABLE|COLUMN)\b|\bALTER\s+TABLE\s+[^;]*?\bDROP\s+(?!INDEX|KEY|PRIMARY|FOREIGN)~i', $sql);
    }

    /** Where a table is now: [connection, database, bytes, rows] or null (it doesn't exist yet: nothing to copy). */
    public static function where(PDO $pdo, string $db, string $table): ?array
    {
        $cands = [];
        if ($db !== '') $cands[] = $db;
        else { try { $cands[] = Database::schemaOf($table); } catch (Throwable) {} $cands[] = Database::mainName(); }
        $conns = ['' => $pdo];
        foreach (array_keys(Database::REALMS) as $r) {
            try { [$rdb] = Database::realmConfig($r); if ($rdb) { $conns[(string) $rdb] = $r; if ($db === '') $cands[] = (string) $rdb; } } catch (Throwable) {}
        }
        foreach (array_unique(array_filter($cands)) as $d) {
            foreach ([$pdo, $conns[$d] ?? null] as $c) {
                if ($c === null) continue;
                try {
                    if (is_string($c)) $c = Database::realm($c);
                    $st = $c->prepare('SELECT DATA_LENGTH + INDEX_LENGTH, TABLE_ROWS FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND TABLE_TYPE = \'BASE TABLE\'');
                    $st->execute([$d, $table]); $row = $st->fetch(PDO::FETCH_NUM);
                    if ($row) return [$c, $d, (int) $row[0], (int) $row[1]];
                } catch (Throwable) {}
            }
        }
        return null;
    }

    private static function q(string $db, string $t): string { return '`' . str_replace('`', '', $db) . '`.`' . str_replace('`', '', $t) . '`'; }

    /** Bytes all the kept copies take. */
    private static function used(): int
    {
        $n = 0;
        foreach (glob(self::dir() . '/*/*.gz') ?: [] as $f) $n += (int) @filesize($f);
        return $n;
    }

    /**
     * Copies the tables $sql writes to, before it runs. Returns ['id', 'tables' => [[db, table, rows, bytes, file]],
     * 'skipped' => ["db.table" => reason], 'error' => ''] — error is set only when the migration must not run without it
     * (it changes data and a table couldn't be copied).
     */
    public static function before(PDO $pdo, string $file, string $sql, string $context): array
    {
        self::prune();
        $must = self::changesData($sql);
        $out = ['id' => '', 'tables' => [], 'skipped' => [], 'error' => ''];
        $targets = self::targets($sql);
        if (!$targets) return $out;
        $id = gmdate('Ymd-His') . '-' . substr(sha1($file . microtime()), 0, 6);
        $dir = self::dir() . '/' . $id;
        if (!is_dir($dir) && !@mkdir($dir, 0750, true)) {
            $out['error'] = $must ? 'Its copy first couldn\'t be made (no folder in app/storage), so it didn\'t run.' : '';
            $out['skipped']['*'] = 'no folder in app/storage';
            return $out;
        }
        @file_put_contents(self::dir() . '/.htaccess', "Require all denied\n");
        $out['id'] = $id;
        foreach ($targets as [$db, $t, $how]) {
            $at = self::where($pdo, $db, $t);
            $label = ($db !== '' ? $db . '.' : '') . $t;
            if (!$at) { $out['skipped'][$label] = 'not there yet (this migration makes it): nothing to copy'; continue; }
            [$c, $d, $bytes, $rows] = $at;
            $label = $d . '.' . $t;
            $free = @disk_free_space(self::dir());
            if ($bytes > self::MAX_BYTES) { $out['skipped'][$label] = 'too large to copy here (' . self::mb($bytes) . '; the limit is ' . self::mb(self::MAX_BYTES) . ')'; continue; }
            if (self::used() + $bytes > self::ALL_BYTES) { $out['skipped'][$label] = 'the copies kept already take ' . self::mb(self::used()) . ' of ' . self::mb(self::ALL_BYTES) . ' (older ones go after ' . self::KEEP_DAYS . ' days)'; continue; }
            if ($free !== false && $free < $bytes * 2 + 100 * 1024 * 1024) { $out['skipped'][$label] = 'not enough free disk (' . self::mb((int) $free) . ' free)'; continue; }
            try {
                $out['tables'][] = self::dump($c, $d, $t, $dir) + ['how' => $how];
            } catch (Throwable $x) {
                $out['skipped'][$label] = 'couldn\'t be copied: ' . mb_substr($x->getMessage(), 0, 200);
                error_log('db copy ' . $label . ': ' . $x->getMessage());
            }
        }
        $missing = array_filter($out['skipped'], fn ($r) => !str_starts_with($r, 'not there yet'));
        if ($must && $missing) $out['error'] = 'It changes data, and its copy first couldn\'t be made (' . implode('; ', array_map(fn ($k, $v) => $k . ': ' . $v, array_keys($missing), $missing)) . '), so it didn\'t run. It\'s tried again on the next run.';
        $man = ['id' => $id, 'file' => $file, 'context' => $context, 'at' => gmdate('c'), 'changes_data' => $must, 'tables' => $out['tables'], 'skipped' => $out['skipped'], 'restored' => []];
        if (!$out['tables'] && !$missing) { @rmdir($dir); $out['id'] = ''; return $out; }   // only new tables: nothing to keep
        @file_put_contents($dir . '/copy.json', json_encode($man, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        return $out;
    }

    private static function mb(int $b): string { return $b >= 1048576 ? round($b / 1048576, 1) . ' MB' : max(1, (int) round($b / 1024)) . ' KB'; }

    /** Writes one table: a first line with its CREATE TABLE (JSON), then INSERT lines of BATCH rows each. */
    private static function dump(PDO $c, string $db, string $t, string $dir): array
    {
        $q = self::q($db, $t);
        $create = (string) ($c->query('SHOW CREATE TABLE ' . $q)->fetch(PDO::FETCH_NUM)[1] ?? '');
        $cols = $c->query('SHOW COLUMNS FROM ' . $q)->fetchAll(PDO::FETCH_COLUMN);
        $pk = array_column(array_filter($c->query('SHOW KEYS FROM ' . $q)->fetchAll(PDO::FETCH_ASSOC), fn ($k) => $k['Key_name'] === 'PRIMARY'), 'Column_name');
        $name = preg_replace('/[^\w.-]/', '_', $db . '.' . $t) . '.sql.gz';
        $tmp = $dir . '/' . $name . '.part';
        $gz = gzopen($tmp, 'wb6');
        if (!$gz) throw new RuntimeException('couldn\'t write in app/storage');
        gzwrite($gz, '-- tv-copy ' . json_encode(['db' => $db, 'table' => $t, 'create' => $create, 'cols' => $cols, 'at' => gmdate('c')], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n");
        $colList = implode(', ', array_map(fn ($x) => '`' . str_replace('`', '', (string) $x) . '`', $cols));
        $n = 0; $last = null; $off = 0;
        $one = count($pk) === 1 ? (string) $pk[0] : '';
        while (true) {
            if ($one !== '') {
                $st = $c->prepare('SELECT * FROM ' . $q . ($last === null ? '' : ' WHERE `' . $one . '` > ?') . ' ORDER BY `' . $one . '` LIMIT ' . self::BATCH);
                $st->execute($last === null ? [] : [$last]);
            } else {
                $st = $c->query('SELECT * FROM ' . $q . ($pk ? ' ORDER BY ' . implode(', ', array_map(fn ($x) => '`' . $x . '`', $pk)) : '') . ' LIMIT ' . self::BATCH . ' OFFSET ' . $off);
            }
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
            if (!$rows) break;
            $vals = [];
            foreach ($rows as $r) $vals[] = '(' . implode(', ', array_map(fn ($v) => $v === null ? 'NULL' : $c->quote((string) $v), array_values($r))) . ')';
            gzwrite($gz, 'INSERT INTO `__T__` (' . $colList . ') VALUES ' . implode(', ', $vals) . ";\n");
            $n += count($rows); $off += count($rows);
            if ($one !== '') $last = end($rows)[$one];
            if (count($rows) < self::BATCH) break;
        }
        gzclose($gz);
        if (!@rename($tmp, $dir . '/' . $name)) { @unlink($tmp); throw new RuntimeException('couldn\'t keep the copy'); }
        return ['db' => $db, 'table' => $t, 'rows' => $n, 'bytes' => (int) filesize($dir . '/' . $name), 'file' => $name];
    }

    /** The copies kept, newest first (each one's copy.json). */
    public static function all(): array
    {
        $out = [];
        foreach (glob(self::dir() . '/*/copy.json') ?: [] as $f) { $m = json_decode((string) file_get_contents($f), true); if (is_array($m)) $out[] = $m; }
        usort($out, fn ($a, $b) => strcmp((string) $b['at'], (string) $a['at']));
        return $out;
    }

    /** Copies older than KEEP_DAYS go. Returns how many. */
    public static function prune(): int
    {
        $n = 0;
        foreach (glob(self::dir() . '/*', GLOB_ONLYDIR) ?: [] as $d) {
            $m = json_decode((string) @file_get_contents($d . '/copy.json'), true);
            $at = is_array($m) ? strtotime((string) $m['at']) : @filemtime($d);
            if ($at && $at < time() - self::KEEP_DAYS * 86400) { foreach (glob($d . '/*') ?: [] as $f) @unlink($f); if (@rmdir($d)) $n++; }
        }
        return $n;
    }

    /**
     * Puts a copy's rows back, table by table: a copy of each table as it is now is taken first (so a restore can be
     * undone too), then, in one transaction per table, its rows are replaced by the copy's. The table keeps the columns it
     * has now (a column a later migration added keeps its default); a table that's gone is made again from the copy.
     * Returns the line to show.
     */
    public static function restore(PDO $pdo, string $id, int $uid): string
    {
        if (!preg_match('/^\d{8}-\d{6}-[0-9a-f]{6}$/', $id) || !is_file(self::dir() . '/' . $id . '/copy.json')) throw new RuntimeException('That copy isn\'t here any more (copies are kept ' . self::KEEP_DAYS . ' days).');
        $dir = self::dir() . '/' . $id;
        $man = json_decode((string) file_get_contents($dir . '/copy.json'), true);
        if (!$man || !$man['tables']) throw new RuntimeException('That copy holds no tables to put back.');
        @set_time_limit(600);
        $sqlNow = implode(";\n", array_map(fn ($x) => 'DELETE FROM `' . $x['db'] . '`.`' . $x['table'] . '`', $man['tables']));
        $now = self::before($pdo, 'restore of ' . $id, $sqlNow, 'before restoring the copy from ' . $man['file']);
        if ($now['error'] !== '') throw new RuntimeException('Nothing was put back: ' . preg_replace('/, so it didn\'t run\. It\'s tried again on the next run\.$/', '.', $now['error']));
        $done = []; $bad = [];
        foreach ($man['tables'] as $x) {
            $label = $x['db'] . '.' . $x['table'];
            try { $done[] = $label . ' (' . self::load($pdo, $x, $dir . '/' . $x['file']) . ' rows)'; }
            catch (Throwable $e) { $bad[] = $label . ': ' . mb_substr(preg_replace('/^SQLSTATE\[\w+\]:?\s*/', '', $e->getMessage()), 0, 240); error_log('db copy restore ' . $label . ': ' . $e->getMessage()); }
        }
        $man['restored'][] = ['at' => gmdate('c'), 'by' => $uid, 'done' => $done, 'failed' => $bad, 'copy_of_now' => $now['id']];
        @file_put_contents($dir . '/copy.json', json_encode($man, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        if ($bad && !$done) throw new RuntimeException('Nothing was put back: ' . implode('; ', $bad) . '. The tables are as they were.');
        return 'Put back ' . implode(', ', $done) . ($bad ? '. Not put back (left as they were): ' . implode('; ', $bad) : '') . '. A copy of how ' . (count($man['tables']) === 1 ? 'it was' : 'they were') . ' just now is kept as well' . ($now['id'] ? ' (the newest copy in the list)' : '') . '.';
    }

    /** One table's rows from its copy file, in a transaction. Returns how many rows went back. */
    private static function load(PDO $pdo, array $x, string $file): int
    {
        $at = self::where($pdo, (string) $x['db'], (string) $x['table']);
        $gz = @gzopen($file, 'rb');
        if (!$gz) throw new RuntimeException('its copy file can\'t be read');
        $head = (string) gzgets($gz);
        $meta = json_decode(substr($head, strlen('-- tv-copy ')), true);
        if (!is_array($meta)) { gzclose($gz); throw new RuntimeException('its copy file isn\'t one of ours'); }
        $q = self::q((string) $x['db'], (string) $x['table']);
        if (!$at) {   // gone (a later removal): made again from the copy
            $pdo->exec(preg_replace('/^CREATE TABLE `[^`]+`/', 'CREATE TABLE IF NOT EXISTS ' . $q, (string) $meta['create'], 1));
            $c = $pdo;
        } else $c = $at[0];
        $c->beginTransaction();
        try {
            $c->exec('SET FOREIGN_KEY_CHECKS = 0');
            $c->exec('DELETE FROM ' . $q);
            while (($line = gzgets($gz)) !== false) {
                $line = rtrim($line, "\r\n");
                if (!str_starts_with($line, 'INSERT INTO `__T__` ')) continue;
                $c->exec('INSERT INTO ' . $q . substr($line, strlen('INSERT INTO `__T__`'), -1));
            }
            $c->commit();
        } catch (Throwable $e) { if ($c->inTransaction()) $c->rollBack(); gzclose($gz); try { $c->exec('SET FOREIGN_KEY_CHECKS = 1'); } catch (Throwable) {} throw $e; }
        gzclose($gz);
        $c->exec('SET FOREIGN_KEY_CHECKS = 1');
        return (int) $x['rows'];
    }
}
