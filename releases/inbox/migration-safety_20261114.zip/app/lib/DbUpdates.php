<?php
// app/lib/DbUpdates.php — which of the files in app/migrations have been run on this database (Jason, 2026-10-28: a file
// used once is deleted once it's been used). Each file is read for what it makes (tables, columns, indexes) and the
// database is asked whether they're there: all there = run; none or some = not run yet; nothing to look for (a file
// that only changes data) = can't tell, so a person says. Clearing a run file deletes it from the server; the sync
// (traverse-3way-sync) then deletes it from OneDrive too (to its recycle bin) and keeps its history in git.
// Since 2026-11-14 (decisions/0162) a release's migrations run as the first step of its publish (Releases::publish), the
// hourly run staying as a backup, and just before each one runs a copy of the tables it touches is kept (DbCopies).
declare(strict_types=1);

final class DbUpdates
{
    private const NOT_COLUMNS = ['INDEX', 'KEY', 'UNIQUE', 'PRIMARY', 'CONSTRAINT', 'FULLTEXT', 'SPATIAL', 'FOREIGN', 'CHECK', 'PARTITION'];

    public static function dir(): string { return dirname(__DIR__) . '/migrations'; }

    /** What a migration makes: [['table', t], ['column', t, c], ['index', t, i]]. */
    public static function checks(string $sql): array
    {
        $sql = preg_replace(['~/\*.*?\*/~s', '~^\s*(--|#).*$~m'], '', $sql);
        $q = '`?(\w+)`?'; $out = [];
        preg_match_all("~CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:`?\w+`?\.|`',\s*@\w+,\s*'`\.)?$q~i", $sql, $m, PREG_SET_ORDER);   // also a table made in a database the file finds (`', @db, '`.t)
        foreach ($m as $x) $out['t:' . strtolower($x[1])] = ['table', strtolower($x[1])];
        preg_match_all("~ALTER\s+TABLE\s+(?:`?\w+`?\.)?$q(.*?)(?:;|'\s*,|\"\s*,|$)~is", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) {
            $t = strtolower($x[1]);
            preg_match_all("~\bADD\s+(?:COLUMN\s+)?(?:IF\s+NOT\s+EXISTS\s+)?$q~i", $x[2], $cs, PREG_SET_ORDER);
            foreach ($cs as $c) if (!in_array(strtoupper($c[1]), self::NOT_COLUMNS, true)) $out["c:$t:" . strtolower($c[1])] = ['column', $t, strtolower($c[1])];
            preg_match_all("~\bADD\s+(?:UNIQUE\s+|FULLTEXT\s+|SPATIAL\s+)?(?:INDEX|KEY)\s+(?:IF\s+NOT\s+EXISTS\s+)?$q~i", $x[2], $is, PREG_SET_ORDER);
            foreach ($is as $i) $out["i:$t:" . strtolower($i[1])] = ['index', $t, strtolower($i[1])];
        }
        preg_match_all("~CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?$q\s+ON\s+$q~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) $out['i:' . strtolower($x[2]) . ':' . strtolower($x[1])] = ['index', strtolower($x[2]), strtolower($x[1])];
        // the MySQL-safe form (CLAUDE.md): information_schema is asked first, and the ALTER is in a string
        preg_match_all("~TABLE_NAME\s*=\s*'(\w+)'\s+AND\s+COLUMN_NAME\s*=\s*'(\w+)'~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) $out['c:' . strtolower($x[1]) . ':' . strtolower($x[2])] = ['column', strtolower($x[1]), strtolower($x[2])];
        preg_match_all("~TABLE_NAME\s*=\s*'(\w+)'\s+AND\s+INDEX_NAME\s*=\s*'(\w+)'~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) $out['i:' . strtolower($x[1]) . ':' . strtolower($x[2])] = ['index', strtolower($x[1]), strtolower($x[2])];
        // a table a file makes and later drops (a rename, a move) isn't looked for
        preg_match_all("~(?:DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?|RENAME\s+TABLE\s+)$q~i", $sql, $m);
        foreach ($m[1] as $t) foreach ($out as $k => $c) if ($c[1] === strtolower($t)) unset($out[$k]);
        return array_values($out);
    }

    /** What the databases hold: ['t' => [table => true], 'c' => ["t.c" => true], 'i' => ["t.i" => true]], across main and the realms. */
    public static function schema(PDO $pdo): array
    {
        $s = ['t' => [], 'c' => [], 'i' => []];
        $conns = [$pdo];
        foreach (array_keys(Database::REALMS) as $r) { try { $conns[] = Database::realm($r); } catch (Throwable) {} }
        foreach ($conns as $c) {
            try {
                foreach ($c->query('SELECT LOWER(TABLE_NAME) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()')->fetchAll(PDO::FETCH_COLUMN) as $t) $s['t'][$t] = true;
                foreach ($c->query('SELECT LOWER(CONCAT(TABLE_NAME, ".", COLUMN_NAME)) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()')->fetchAll(PDO::FETCH_COLUMN) as $k) $s['c'][$k] = true;
                foreach ($c->query('SELECT DISTINCT LOWER(CONCAT(TABLE_NAME, ".", INDEX_NAME)) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE()')->fetchAll(PDO::FETCH_COLUMN) as $k) $s['i'][$k] = true;
            } catch (Throwable $x) { error_log('db updates schema: ' . $x->getMessage()); }
        }
        return $s;
    }

    /** Every file: [file, size, state run|notrun|partial|unknown, have, of, missing (words)], oldest first. */
    public static function all(PDO $pdo): array
    {
        $s = self::schema($pdo); $out = [];
        foreach (glob(self::dir() . '/*.sql') ?: [] as $f) {
            $checks = self::checks((string) file_get_contents($f)); $have = 0; $miss = [];
            foreach ($checks as $c) {
                $ok = $c[0] === 'table' ? isset($s['t'][$c[1]]) : isset($s[$c[0] === 'column' ? 'c' : 'i'][$c[1] . '.' . $c[2]]);
                if ($ok) $have++; else $miss[] = $c[0] === 'table' ? 'table ' . $c[1] : $c[0] . ' ' . $c[1] . '.' . $c[2];
            }
            $state = !$checks ? 'unknown' : ($have === count($checks) ? 'run' : ($have ? 'partial' : 'notrun'));
            $out[] = ['file' => basename($f), 'size' => (int) filesize($f), 'state' => $state, 'have' => $have, 'of' => count($checks), 'missing' => $miss];
        }
        return $out;
    }

    // ---- the site runs them itself (Jason, 2026-10-30: "this feels unnecessary"): no phpMyAdmin ------------------------
    // Every file is written to run twice safely (CLAUDE.md), so the site runs each new one in date order through its own
    // database connection, records it, and clears it. One that fails stays, with its error, and isn't tried again until the
    // file changes; the files after it wait (they may need it).

    private static function ensureLog(PDO $pdo): void
    {
        $pdo->exec('CREATE TABLE IF NOT EXISTS db_updates_log (file VARCHAR(120) NOT NULL PRIMARY KEY, hash CHAR(40) NOT NULL, ok TINYINT(1) NOT NULL DEFAULT 0,
                    error VARCHAR(600) NOT NULL DEFAULT \'\', ran_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    /** What the site has run: file => [ok, error, ran_at, hash]. */
    public static function log(PDO $pdo): array
    {
        try { self::ensureLog($pdo); return array_column($pdo->query('SELECT * FROM db_updates_log ORDER BY ran_at DESC LIMIT 200')->fetchAll(PDO::FETCH_ASSOC), null, 'file'); } catch (Throwable) { return []; }
    }

    /** Forgets that these files failed, so the next run tries them again (a release's publish is a real retry). */
    public static function retry(PDO $pdo, array $files): void
    {
        try {
            self::ensureLog($pdo);
            $st = $pdo->prepare('DELETE FROM db_updates_log WHERE file = ? AND ok = 0');
            foreach ($files as $f) $st->execute([basename((string) $f)]);
        } catch (Throwable $x) { error_log('db updates retry: ' . $x->getMessage()); }
    }

    /** Has this file, exactly as it is, run already (recorded ok with the same contents)? */
    public static function ranAlready(PDO $pdo, string $name, string $sql): bool
    {
        $l = self::log($pdo)[basename($name)] ?? null;
        return $l && (int) $l['ok'] && $l['hash'] === sha1($sql);
    }

    /**
     * Runs the files waiting in app/migrations, oldest first, and clears each one that ran. $throttle: at most once an
     * hour (the scheduled jobs call it). Just before each one runs, a copy of the tables it touches is kept (DbCopies);
     * one that changes data doesn't run without it (not logged as failed: tried again next time). $context says what ran
     * it ("hourly", "publish of release #N"), kept with the copy. Returns [ran => [files], failed => [file => error],
     * copies => [file => DbCopies::before()]].
     */
    public static function autoRun(PDO $pdo, bool $throttle = true, string $context = 'hourly'): array
    {
        $out = ['ran' => [], 'failed' => [], 'copies' => []];
        $stamp = dirname(__DIR__) . '/storage/db-updates-ran';
        if ($throttle && is_file($stamp) && filemtime($stamp) > time() - 3600) return $out;
        @touch($stamp);
        try { self::ensureLog($pdo); } catch (Throwable $x) { error_log('db updates log: ' . $x->getMessage()); return $out; }
        $log = self::log($pdo);
        $state = array_column(self::all($pdo), 'state', 'file');
        foreach (glob(self::dir() . '/*.sql') ?: [] as $f) {
            $name = basename($f); $sql = (string) file_get_contents($f); $hash = sha1($sql);
            $was = $log[$name] ?? null;
            if ($was && $was['hash'] === $hash && !(int) $was['ok']) break;   // failed as it is: it and the files after it wait for a fix
            if (($state[$name] ?? '') === 'run') {   // everything it makes is there already (run by hand before): just cleared
                $pdo->prepare('REPLACE INTO db_updates_log (file, hash, ok, error, ran_at) VALUES (?, ?, 1, \'already there\', NOW())')->execute([$name, $hash]);
                @unlink($f); $out['ran'][] = $name; continue;
            }
            // a copy of what it touches first (decisions/0162): kept 14 days, Restore on Database updates
            try {
                require_once __DIR__ . '/DbCopies.php';
                $copy = DbCopies::before($pdo, $name, $sql, $context);
            } catch (Throwable $x) {
                error_log('db copy before ' . $name . ': ' . $x->getMessage());
                $copy = ['id' => '', 'tables' => [], 'skipped' => ['*' => $x->getMessage()], 'error' => ''];
                if (DbCopies::changesData($sql)) $copy['error'] = 'It changes data, and its copy first couldn\'t be made (' . mb_substr($x->getMessage(), 0, 200) . '), so it didn\'t run. It\'s tried again on the next run.';
            }
            $out['copies'][$name] = $copy;
            if ($copy['error'] !== '') { error_log('db update ' . $name . ': ' . $copy['error']); $out['failed'][$name] = $copy['error']; break; }
            try {
                foreach (self::statements($sql) as $q) { $st = $pdo->query($q); if ($st) $st->closeCursor(); }
                $pdo->prepare('REPLACE INTO db_updates_log (file, hash, ok, error, ran_at) VALUES (?, ?, 1, \'\', NOW())')->execute([$name, $hash]);
                @unlink($f);   // used once: cleared, and the sync takes it off OneDrive
                $out['ran'][] = $name;
            } catch (Throwable $x) {
                // an older file not written to run twice, run before by hand: what it makes is already there (a table,
                // column or index that exists, or one it drops that's gone), so it counts as run
                if (preg_match('/\b(1050|1060|1061|1091)\b|already exists|Duplicate (column|key) name/i', $x->getMessage())) {
                    $pdo->prepare('REPLACE INTO db_updates_log (file, hash, ok, error, ran_at) VALUES (?, ?, 1, \'already there\', NOW())')->execute([$name, $hash]);
                    @unlink($f); $out['ran'][] = $name; continue;
                }
                $msg = mb_substr(preg_replace('/^SQLSTATE\[\w+\]:?\s*/', '', $x->getMessage()), 0, 600);
                $pdo->prepare('REPLACE INTO db_updates_log (file, hash, ok, error, ran_at) VALUES (?, ?, 0, ?, NOW())')->execute([$name, $hash, $msg]);
                error_log('db update ' . $name . ': ' . $msg);
                $out['failed'][$name] = $msg;
                break;
            }
        }
        return $out;
    }

    /** A file's statements, split on the semicolons outside quotes and comments. */
    public static function statements(string $sql): array
    {
        $out = []; $cur = ''; $n = strlen($sql); $q = '';
        for ($i = 0; $i < $n; $i++) {
            $c = $sql[$i];
            if ($q !== '') { $cur .= $c; if ($c === '\\' && $q !== '`') { $cur .= $sql[++$i] ?? ''; continue; } if ($c === $q) { if (($sql[$i + 1] ?? '') === $q) { $cur .= $sql[++$i]; continue; } $q = ''; } continue; }
            if ($c === '-' && ($sql[$i + 1] ?? '') === '-' && (($sql[$i + 2] ?? ' ') === ' ' || ($sql[$i + 2] ?? '') === "\t" || ($sql[$i + 2] ?? "\n") === "\n")) { $e = strpos($sql, "\n", $i); $i = $e === false ? $n : $e; $cur .= "\n"; continue; }
            if ($c === '#') { $e = strpos($sql, "\n", $i); $i = $e === false ? $n : $e; $cur .= "\n"; continue; }
            if ($c === '/' && ($sql[$i + 1] ?? '') === '*') { $e = strpos($sql, '*/', $i + 2); $i = $e === false ? $n : $e + 1; continue; }
            if ($c === "'" || $c === '"' || $c === '`') { $q = $c; $cur .= $c; continue; }
            if ($c === ';') { if (trim($cur) !== '') $out[] = trim($cur); $cur = ''; continue; }
            $cur .= $c;
        }
        if (trim($cur) !== '') $out[] = trim($cur);
        return $out;
    }

    /** Deletes the named files from app/migrations: only ones that are run, or that a person says were (unknown). Returns how many. */
    public static function clear(PDO $pdo, array $files, bool $sayRun = false): int
    {
        $byName = array_column(self::all($pdo), null, 'file'); $n = 0;
        foreach ($files as $f) {
            $f = basename((string) $f); $r = $byName[$f] ?? null;
            if (!$r || !($r['state'] === 'run' || ($sayRun && in_array($r['state'], ['unknown', 'partial'], true)))) continue;
            if (@unlink(self::dir() . '/' . $f)) $n++;
        }
        return $n;
    }
}
