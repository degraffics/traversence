<?php
/**
 * includes/context-switcher.php — who you are and the role you're acting in, at the top of the toolbar
 * (decisions/0055 §4). Tapping your name (or your initial, when the toolbar is narrow; the first icon on phones)
 * opens the roles you hold: Member, each listing you're on the team of, Steward, Admin. Choosing one switches the
 * whole toolbar and workspace; the workspace itself stays free for the work.
 * Wider screens (decisions/0058 §33): the menu is at the top bar's person icon instead. A click on the icon opens your
 * dashboard; hovering it (or ArrowDown) opens this menu. header.php renders the menu with $button = false; the toolbar's
 * own button shows on phones only.
 * Returns '' when no one is signed in. The menu is rendered once per page.
 */
require_once __DIR__ . '/page-shell.php';

function tv_context_switcher(bool $button = true): string
{
    static $menuDone = false;
    try {
        if (!class_exists('Auth') || !class_exists('Database')) return '';
        $me = Auth::currentUser();
        if ($me === null) return '';
        require_once __DIR__ . '/../lib/Roles.php';
        $pdo = Database::connection();
        $ctx = Roles::current($pdo, (int) $me['id']);
        $all = Roles::contexts($pdo, (int) $me['id']);
        require_once __DIR__ . '/../lib/StaffLogin.php';
        $other = StaffLogin::otherAccount($pdo, $me);   // the staff login and its linked member account (decisions/0100)
    } catch (Throwable $e) {
        error_log('context switcher: ' . $e->getMessage());
        return '';
    }
    $name = trim((string) ($me['display_name'] ?? '')) ?: (string) strstr((string) $me['email'], '@', true);
    $role = $ctx['label'] . ($ctx['kind'] !== 'member' ? ' · ' . $ctx['sub'] : '');
    $h = !$button ? '' : '<button type="button" class="cx" id="cx-btn" aria-haspopup="menu" aria-expanded="false" title="' . tv_e($name . ' · acting as ' . $role . (count($all) > 1 ? ' (tap to switch)' : '')) . '">'
       . '<span class="cx-av" aria-hidden="true">' . tv_e(mb_strtoupper(mb_substr($name, 0, 1))) . '</span>'
       . '<span class="cx-txt"><span class="cx-n">' . tv_e($name) . '</span><span class="cx-r">' . tv_e($role) . (count($all) > 1 ? ' &#9662;' : '') . '</span></span></button>';
    if ($menuDone) return $h;
    $menuDone = true;
    $h .= '<style>' . "\n" . <<<'CSS'
  .cx-menu{position:fixed;z-index:1400;width:17rem;max-width:calc(100vw - 16px);max-height:70vh;overflow:auto;background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:.9rem;
    box-shadow:0 18px 40px -14px rgba(0,0,0,.5);padding:.35rem;color:var(--tv-ink)}
  .cx-mh{font-size:.62rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--tv-meta);margin:.3rem .55rem .2rem}
  .cx-o{position:relative;display:block;width:100%;text-align:left;background:none;border:0;border-radius:.6rem;padding:.45rem 2rem .45rem .55rem;cursor:pointer;color:var(--tv-ink);text-decoration:none}
  .cx-o:hover,.cx-o:focus-visible{background:var(--tv-canvas);outline:none}
  .cx-o b{display:block;font-size:.9rem}.cx-o small{display:block;font-size:.74rem;color:var(--tv-meta)}
  .cx-pf{border-top:1px solid var(--tv-line);border-radius:0 0 .6rem .6rem;margin-top:.25rem}
  .cx-o.on{background:var(--tv-canvas)}.cx-o i{position:absolute;right:.7rem;top:50%;transform:translateY(-50%);font-style:normal;color:color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink));font-weight:700}
  .cx-link{border-top:1px solid var(--tv-line);border-radius:0 0 .6rem .6rem;margin-top:.2rem}
  .cx-menu{background:var(--tv-card-a);border-color:var(--tv-line-strong);border-radius:0 0 .8rem .8rem;padding:.3rem .35rem .4rem;width:15.5rem}
  .cx-who{display:flex;align-items:center;gap:.55rem;padding:.25rem .3rem .45rem;border-bottom:1px solid var(--tv-line-strong);margin-bottom:.3rem}
  .cx-wi{flex:0 0 36px;width:36px;height:36px;border-radius:999px;border:2px solid var(--tv-umber);display:flex;align-items:center;justify-content:center;color:var(--tv-ink)}
  .cx-wt{flex:1;min-width:0;text-decoration:none;border-radius:.4rem}.cx-wt:hover small,.cx-wt:focus-visible small{text-decoration:underline}.cx-wt b{display:block;font-family:var(--tv-font-head);font-weight:400;font-size:.98rem;color:var(--tv-ink)}.cx-wt small{display:block;font-size:.74rem;color:var(--tv-meta)}
  .cx-pen{flex:0 0 24px;width:24px;height:24px;border-radius:999px;border:1.5px solid var(--tv-umber);display:flex;align-items:center;justify-content:center;color:var(--tv-ink)}
  .cx-pen:hover,.cx-pen:focus-visible{background:var(--tv-sage);color:var(--tv-umber);outline:0}
  .cx-menu .cx-o{background:var(--tv-canvas);border-radius:.15rem;margin:0 0 3px;padding:.35rem 2rem .35rem .7rem}
  .cx-menu .cx-o b{font-family:var(--tv-font-head);font-weight:400;font-size:.92rem;color:var(--tv-ink)}.cx-menu .cx-o small{color:var(--tv-meta);font-size:.72rem}
  .cx-menu .cx-o:hover,.cx-menu .cx-o:focus-visible{background:var(--tv-card-b)}
  .cx-menu .cx-o.on{background:var(--tv-canvas);box-shadow:inset 3px 0 0 var(--tv-sage)}
  .cx-menu .cx-fold .cx-chev{color:var(--tv-meta);font-style:normal;transition:transform var(--tv-ease)}.cx-menu .cx-fold[aria-expanded=true] .cx-chev{transform:rotate(180deg)}
  .cx-sub{margin:-.1rem 0 .2rem .7rem;padding-left:.45rem;border-left:2px solid var(--tv-line)}
  .cx-sub .cx-o{padding:.35rem .6rem}.cx-sub .cx-more b{color:var(--tv-link);text-decoration:underline;font-family:var(--tv-font-ui);font-size:.85rem;font-weight:700}
  .cx-none{font-size:.78rem;color:var(--tv-meta);margin:.2rem .6rem}
  .cx-all-pop{position:fixed;inset:0;z-index:1500;background:rgba(30,20,12,.45);display:flex;align-items:flex-start;justify-content:center;padding:max(3vh,12px) 3px}
  .cx-all-pop[hidden]{display:none}
  .cx-all-box{width:min(26rem,100%);max-height:88vh;display:flex;flex-direction:column;background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:.5rem;box-shadow:0 18px 40px -14px rgba(0,0,0,.5);color:var(--tv-ink);padding:.6rem}
  .cx-all-hd{display:flex;align-items:center;justify-content:space-between;margin:0 .2rem .4rem}.cx-all-hd b{font:700 1.05rem var(--tv-font-head)}
  .cx-all-x{width:30px;height:30px;border-radius:999px;border:1px solid var(--tv-line-strong);background:var(--tv-card-a);color:var(--tv-link);font-size:1.1rem;line-height:1;cursor:pointer}
  .cx-all-q{width:100%;border:1px solid var(--tv-line-strong);border-radius:.6rem;padding:.45rem .6rem;background:var(--tv-card-a);margin-bottom:.4rem;font-size:.95rem}
  .cx-all-list{overflow:auto;display:flex;flex-direction:column;gap:3px}
  .cx-all-list .cx-o{display:flex;flex-direction:column;align-items:flex-start;position:relative;width:100%;text-align:left;border:0;border-radius:.6rem;padding:.45rem .7rem;background:var(--tv-canvas);cursor:pointer}
  .cx-all-list .cx-o b{font-family:var(--tv-font-head);font-weight:400;font-size:.95rem}.cx-all-list .cx-o small{color:var(--tv-meta);font-size:.74rem}
  .cx-all-list .cx-o.on{box-shadow:inset 3px 0 0 var(--tv-sage)}.cx-all-list .cx-o i{position:absolute;right:.7rem;top:.6rem;font-style:normal;color:color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink))}
  .cx-all-list .cx-o[hidden]{display:none}
  .cx-all-pg{display:block;text-align:right;margin-top:.45rem;font-size:.78rem;color:var(--tv-link);text-decoration:underline}
  .cx-menu .cx-all{background:none;padding:.3rem .7rem;text-align:right}.cx-menu .cx-all small{color:var(--tv-link);text-decoration:underline;font-size:.76rem}
CSS . '</style>';
    // the menu, as in the account mockup (decisions/0058 §35): Current Account and the role you act as, ✎ for your
    // profile; then every account you can act as, each saying what kind it is
    $kind = fn (array $c) => match ($c['kind']) {
        'member' => [$name, 'Personal Account'],
        'org' => [(string) $c['label'], 'Listing Account · ' . $c['sub']],
        'steward' => [$name, 'Steward Account · ' . $c['sub']],
        'admin' => [$name, (($c['staff'] ?? '') !== '' ? 'Traversence Staff · ' : 'System Admin Account · ') . $c['sub']],
        default => [(string) $c['label'], (string) $c['sub']],
    };
    // no "Current Account" box (Jason, 2026-11-05): the bar above it already says who; its name and ✎ open and edit it
    $h .= '<div class="cx-menu" id="cx-menu" role="menu" data-name="' . tv_e($name) . '" hidden>';
    // listings aren't all listed here (a Nexus owner may have dozens): the one you're acting as, then "Your listings"
    $orgs = array_values(array_filter($all, fn ($c) => $c['kind'] === 'org'));
    // a staff login has no listings of its own: show its linked member account's, each opening by switching to that
    // account (decisions/0100 addendum, Jason 2026-11-02: "I don't see my listings when I'm in admin view")
    $viaMember = false;
    if (!$orgs && !empty($other['uid']) && ($other['to'] ?? '') === 'member') {
        try { $orgs = array_values(array_filter(Roles::contexts($pdo, (int) $other['uid']), fn ($c) => $c['kind'] === 'org')); $viaMember = (bool) $orgs; } catch (Throwable $x) { $orgs = []; }
    }
    // the order (Jason, 2026-11-05): Traversence first, then you, then your listings under you, then Steward. Each comes
    // from Roles::contexts (an admin grant; a listing you own or are on the team of; a community you steward) and
    // StaffLogin::otherAccount (a staff login linked to this account, or the member account a staff login is linked to)
    $opt = function (array $c) use ($ctx, $kind): string {
        [$cn, $ck] = $kind($c); $on = $c['key'] === $ctx['key'];
        return '<button type="button" role="menuitemradio" aria-checked="' . ($on ? 'true' : 'false') . '" class="cx-o' . ($on ? ' on' : '') . '" data-ctx="' . tv_e($c['key']) . '" data-kind="' . tv_e($c['kind']) . '">'
            . '<b>' . tv_e($cn) . '</b><small>' . tv_e($ck) . '</small>' . ($on ? '<i aria-hidden="true">&#10003;</i>' : '') . '</button>';
    };
    $oth = function (array $o): string {
        $sub = $o['sub'] . ($o['to'] === 'staff_signin' ? ' · sign in' : ($o['to'] === 'link' ? ' · how to link' : ''));
        return in_array($o['to'], ['member', 'staff'], true)
            ? '<button type="button" role="menuitem" class="cx-o" data-acct="' . tv_e($o['to']) . '"><b>' . tv_e($o['name']) . '</b><small>' . tv_e($sub) . '</small></button>'
            : '<a role="menuitem" class="cx-o" href="' . ($o['to'] === 'staff_signin' ? '/admin/login.php' : '/faq.php#i-m-on-the-traversence-team-how-do-my-staff-login-and-my-own') . '"><b>' . tv_e($o['name']) . '</b><small>' . tv_e($sub) . '</small></a>';
    };
    $byKind = fn (string $k) => array_values(array_filter($all, fn ($c) => $c['kind'] === $k));
    $otherIsStaff = !empty($other) && in_array($other['to'], ['staff', 'staff_signin'], true);
    // 1. Traversence
    foreach ($byKind('admin') as $c) $h .= $opt($c);
    if ($otherIsStaff) $h .= $oth($other);
    // 2. you
    foreach ($byKind('member') as $c) $h .= $opt($c);
    if (!empty($other) && !$otherIsStaff) $h .= $oth($other);
    // 3. your listings, under you: each one when there are a few; a search pop-up when there are many
    if ($orgs) {
        usort($orgs, fn ($a, $b) => strcasecmp((string) $a['label'], (string) $b['label']));
        $row = fn (array $c) => '<button type="button" role="menuitemradio" aria-checked="' . ($c['key'] === $ctx['key'] ? 'true' : 'false') . '" class="cx-o cx-li' . ($c['key'] === $ctx['key'] ? ' on' : '') . '" ' . ($viaMember ? 'data-acct="member" data-then="' . tv_e($c['key']) . '"' : 'data-ctx="' . tv_e($c['key']) . '"') . ' data-kind="org"><b>' . tv_e((string) $c['label']) . '</b><small>Listing Account · ' . tv_e((string) $c['sub']) . ($viaMember ? ' · opens as you' : '') . '</small>' . ($c['key'] === $ctx['key'] ? '<i aria-hidden="true">&#10003;</i>' : '') . '</button>';
        $cur = array_values(array_filter($orgs, fn ($c) => $c['key'] === $ctx['key']));
        $rest = array_values(array_filter($orgs, fn ($c) => $c['key'] !== $ctx['key']));
        $show = array_merge($cur, array_slice($rest, 0, count($orgs) > 5 ? 3 : 5));
        $h .= '<div class="cx-sub cx-ls" role="group" aria-label="Your listings">' . implode('', array_map($row, $show))
            . (count($orgs) > 5 ? '<button type="button" class="cx-o cx-more" data-cx-all><b>See all ' . count($orgs) . ' listings</b></button>' : '') . '</div>';
        if (count($orgs) > 5) $h .= '<div class="cx-all-pop" id="cx-all" role="dialog" aria-modal="true" aria-label="Your listings" hidden><div class="cx-all-box"><div class="cx-all-hd"><b>Your listings</b><button type="button" class="cx-all-x" aria-label="Close" data-cx-close>&times;</button></div>'
            . '<input type="search" class="cx-all-q" placeholder="Find a listing" aria-label="Find a listing"><div class="cx-all-list">' . implode('', array_map($row, $orgs)) . '</div>'
            . '<a class="cx-all-pg" href="/user/accounts.php">Grouped by brand, on Your accounts</a></div></div>';
    }
    // 4. Steward
    foreach ($byKind('steward') as $c) $h .= $opt($c);
    // no separate "Business portal" item: a listing here opens its Overview, where all its tools are (0115 addendum)
    $h .= '<a role="menuitem" class="cx-o cx-all" href="/user/accounts.php"><small>All your accounts</small></a>';
    $h .= '</div>';
    $h .= '<script' . tv_nonce() . '>' . <<<'JS'

(function () { function init() {   // after the page: the toolbar's button comes after the top bar
  var btn = document.getElementById('cx-btn'), pf = document.getElementById('icon-profile-btn'), menu = document.getElementById('cx-menu');
  if (!menu) return;
  document.body.appendChild(menu);   // above everything, whatever the toolbar's width
  var anchor = btn || pf, hideT = 0;
  function wide() { return window.matchMedia('(min-width: 768px)').matches; }
  function place() {
    var a = anchor; if (!a) return;
    var r = a.getBoundingClientRect(), under = a === pf || !wide() || a.hasAttribute('data-cx-under');
    var w = menu.offsetWidth || 260;
    // under the top bar's icon, or on phones under the button at the right edge: open leftwards so it stays on screen
    menu.style.top = (under ? r.bottom + 6 : r.top) + 'px';
    menu.style.left = (under ? Math.max(8, Math.min(r.right - w, window.innerWidth - w - 8)) : r.right + 8) + 'px';
  }
  function toggle(open, a, quiet) {
    if (a) anchor = a;
    menu.hidden = !open;
    [btn, pf].forEach(function (b) { if (b) b.setAttribute('aria-expanded', String(open && b === anchor)); });
    if (open) { place(); if (!quiet) { var o = menu.querySelector('.cx-o.on') || menu.querySelector('.cx-o'); if (o) o.focus(); } }
  }
  if (btn) btn.addEventListener('click', function (e) { e.stopPropagation(); toggle(menu.hidden, btn); });
  window.tvCx = function (a) { toggle(menu.hidden, a); };   // other openers, like the Pulse's name (data-cx-under opens it below)
  if (pf) {   // wider screens: a click opens the dashboard (header-nav.js); hovering opens this menu
    pf.setAttribute('aria-haspopup', 'menu'); pf.setAttribute('aria-expanded', 'false');
    pf.title = menu.getAttribute('data-name') + '. Click for your dashboard.';
    var later = function () { clearTimeout(hideT); hideT = setTimeout(function () { if (anchor === pf) toggle(false); }, 280); };
    pf.addEventListener('mouseenter', function () { if (!wide()) return; clearTimeout(hideT); toggle(true, pf, true); });
    pf.addEventListener('mouseleave', later);
    menu.addEventListener('mouseenter', function () { clearTimeout(hideT); });
    menu.addEventListener('mouseleave', function () { if (anchor === pf) later(); });
    pf.addEventListener('keydown', function (e) { if (e.key === 'ArrowDown') { e.preventDefault(); toggle(true, pf); } });
  }
  document.addEventListener('click', function (e) { if (!menu.hidden && !menu.contains(e.target)) toggle(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) { toggle(false); if (anchor) anchor.focus(); } });
  window.addEventListener('resize', function () { if (!menu.hidden) place(); });
  var pop = document.getElementById('cx-all');
  if (pop) {   // every listing, in a pop-up over the page, with a search
    document.body.appendChild(pop);
    var q = pop.querySelector('.cx-all-q');
    var shut = function () { pop.hidden = true; };
    pop.addEventListener('click', function (e) { if (e.target === pop || e.target.closest('[data-cx-close]')) shut(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !pop.hidden) shut(); });
    q.addEventListener('input', function () { var t = q.value.trim().toLowerCase(); Array.prototype.forEach.call(pop.querySelectorAll('.cx-o'), function (o) { o.hidden = t !== '' && o.textContent.toLowerCase().indexOf(t) < 0; }); });
    pop.addEventListener('click', function (e) { pick(e); });
  }
  menu.addEventListener('click', function (e) {
    var f = e.target.closest('.cx-fold');
    if (f) { e.stopPropagation(); var sub = document.getElementById(f.getAttribute('aria-controls')), o = sub.hidden; sub.hidden = !o; f.setAttribute('aria-expanded', String(o)); try { localStorage.setItem('tv_cx_lsub', o ? '1' : '0'); } catch (x) {} return; }
    if (e.target.closest('[data-cx-all]') && pop) { e.stopPropagation(); pop.hidden = false; q.value = ''; q.dispatchEvent(new Event('input')); setTimeout(function () { q.focus(); }, 30); return; }
    pick(e);
  });
  try { if (localStorage.getItem('tv_cx_lsub') === '1') { var f0 = menu.querySelector('.cx-fold'); if (f0) { document.getElementById('cx-lsub').hidden = false; f0.setAttribute('aria-expanded', 'true'); } } } catch (x) {}
  function pick(e) {
    var a = e.target.closest('[data-acct]');
    if (a) {   // the staff login <-> its linked member account
      a.querySelector('small').textContent = 'Switching…';
      fetch('/user/api/context.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        return fetch('/user/api/context.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': d.csrf || '' }, body: JSON.stringify(a.getAttribute('data-then') ? { account: a.getAttribute('data-acct'), then: a.getAttribute('data-then') } : { account: a.getAttribute('data-acct') }) });
      }).then(function (r) { return r.json(); }).then(function (r) {
        if (r.ok) location.href = r.go || '/'; else { a.querySelector('small').textContent = (r.error && r.error.message) || 'That didn\'t work.'; }
      });
      return;
    }
    var o = e.target.closest('[data-ctx]'); if (!o) return;
    if (o.classList.contains('on')) { toggle(false); if (pop) pop.hidden = true; return; }
    var kind = o.getAttribute('data-kind');
    o.querySelector('small').textContent = 'Switching…';
    fetch('/user/api/context.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      return fetch('/user/api/context.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': d.csrf || '' },
        body: JSON.stringify({ context: o.getAttribute('data-ctx') }) });
    }).then(function () {
      // staff pages stay put when switching to Admin; everywhere else, the new role opens on its dashboard (Admin's is /admin/)
      if (kind === 'admin' && location.pathname.indexOf('/admin/') === 0) location.reload();
      else if (kind === 'admin') location.href = '/admin/';   // the admin dashboard (decisions/0078)
      else if (kind === 'org' && /^entity:\d+$/.test(o.getAttribute('data-ctx'))) location.href = '/business/' + o.getAttribute('data-ctx').slice(7);   // a listing opens on its Overview
      else if (location.pathname === '/user/dashboard.php') { location.hash = '#pulse'; location.reload(); }
      else location.href = '/user/dashboard.php#pulse';
    });
  }
} if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init(); })();
</script>
JS;
    return $h;
}

/** The current account's own dashboard and its editor (Jason, 2026-11-05): the bar's name opens the first, its ✎ the
 *  second; a listing's are its Overview and its page editor, yours your dashboard and profile, staff's the admin. */
function tv_acting_links(array $ctx): array
{
    $id = preg_match('/^entity:(\d+)$/', (string) ($ctx['key'] ?? ''), $m) ? (int) $m[1] : 0;
    if (($ctx['kind'] ?? '') === 'org' && $id) return ['/business/' . $id, '/listing/businessportal.php?id=' . $id, 'Edit ' . ($ctx['label'] ?? 'the listing') . '\'s listing'];
    if (($ctx['kind'] ?? '') === 'admin') return ['/admin/', '/user/dashboard.php#profile', 'Your profile'];
    return ['/user/dashboard.php', '/user/dashboard.php#profile', 'Your profile: name, bio, public or private'];
}

/**
 * Who you're acting as, when it isn't just you (Jason, 2026-10-23: "maybe more of a visual indicator"): ['kind', 'label',
 * 'sub'] for a listing, Steward or Admin; null as yourself or signed out. Read once per page.
 */
function tv_acting(): ?array
{
    static $memo = false;
    if ($memo !== false) return $memo;
    $memo = null;
    try {
        if (!class_exists('Auth') || !class_exists('Database') || !($me = Auth::currentUser())) return null;
        require_once __DIR__ . '/../lib/Roles.php';
        if (Roles::staffLogin(Database::connection(), (int) $me['id'])) return null;   // a staff login is only ever staff: its side says so
        $c = Roles::current(Database::connection(), (int) $me['id']);
        if (in_array($c['kind'], ['org', 'steward', 'admin'], true)) $memo = ['kind' => $c['kind'], 'label' => (string) $c['label'], 'sub' => (string) $c['sub']];
    } catch (Throwable) {}
    return $memo;
}

/** The colour and icon of each mode, one brand colour each (Jason, 2026-11-05): [icon, background, border, text, accent].
 *  User rust #8C3A23 (Jason: espresso too dark, taupe too hard against the header); Listing orange #C85A17; Traversence
 *  sage #92BEA5; Steward taupe #7A6A52; espresso #2A1D14 behind your initial. */
function tv_acting_look(string $kind): array
{
    return ['org' => ['store', '#C85A17', '#8C3A23', '#FFF8EA', '#8C3A23'], 'steward' => ['users', '#7A6A52', '#5C4F3C', '#FFF8EA', '#2A1D14'],
        'admin' => ['shield', '#92BEA5', '#7A6A52', '#2A1D14', '#2A1D14']][$kind] ?? ['user', '#8C3A23', '#6E2C1A', '#FFF8EA', '#2A1D14'];
}

/**
 * The account bar (Jason, 2026-11-05): a slim full-width bar at the very top of every page for anyone signed in, above
 * the header, so it never sits between the header and a hero. It is the one place for who you are:
 *   left:  your photo, which opens the switcher (your own account, each listing you manage, Steward, Traversence),
 *          then the mode and the name: "User: Jason DeGraff", "Listing: M2 ServCore", "Traversence: Jason DeGraff (TRV-0001)"
 *   right: the sign-out icon.
 * Each mode has its own colour (tv_acting_look). No End button: going back to yourself is the first choice in the switcher.
 * A page may add a short note after the name ($GLOBALS['tv_bar_note'], e.g. the staff sign-in page).
 * Nothing for a visitor who isn't signed in.
 */
function tv_acting_bar(): string
{
    $nonce = function_exists('tv_nonce') ? tv_nonce() : '';
    $me = null; $staff = false; $photo = '';
    try {
        if (class_exists('Auth') && class_exists('Database')) {
            $me = Auth::currentUser();
            if ($me) {
                require_once __DIR__ . '/../lib/Roles.php';
                $staff = Roles::staffLogin(Database::connection(), (int) $me['id']);
                if (is_file(__DIR__ . '/../lib/MemberProfile.php')) { require_once __DIR__ . '/../lib/MemberProfile.php'; $photo = (string) (MemberProfile::get(Database::connection(), (int) $me['id'])['avatar'] ?? ''); }
            }
        }
    } catch (Throwable) { $me = $me ?: null; }
    if (!$me) return '';
    $a = tv_acting();
    $name = trim((string) ($me['display_name'] ?? '')) ?: (string) strstr((string) ($me['email'] ?? ''), '@', true);
    $kind = $a ? $a['kind'] : ($staff ? 'admin' : 'user');
    [$ic, $bg, $bd, $fg, $ik] = tv_acting_look($kind);
    if (!function_exists('tv_icon')) { try { require_once __DIR__ . '/app-shell.php'; } catch (Throwable) {} }
    $mode = ['org' => 'Listing', 'admin' => 'Traversence', 'steward' => 'Steward'][$kind] ?? 'User';
    $who = $kind === 'org' ? (string) $a['label'] : $name;
    $tip = ['org' => 'You\'re working as ' . $who . ': what you post, reply and change is in its name',
        'admin' => 'You\'re working as Traversence staff', 'steward' => 'You\'re working as a Steward'][$kind] ?? 'Your own account';
    $note = trim((string) ($GLOBALS['tv_bar_note'] ?? ''));
    $cur = ['kind' => $a ? $a['kind'] : ($staff ? 'admin' : 'member'), 'label' => $who, 'key' => ''];
    try { $cur = Roles::current(Database::connection(), (int) $me['id']) + $cur; } catch (Throwable) {}
    [$dashUrl, $editUrl, $editTip] = tv_acting_links($cur);
    $pen = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>';
    $initial = mb_strtoupper(mb_substr($name, 0, 1));
    $out = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>';
    // linking a sign-in (Google, Apple, Microsoft, Facebook; decisions/0090): say how it went right here, on the page you
    // land on, not only in Privacy (Jason, 2026-11-05: "Google notification needs to be clear")
    $linked = '';
    if (!empty($_SESSION['tv_link_done'])) {
        $ld = (string) $_SESSION['tv_link_done']; unset($_SESSION['tv_link_done']);
        $bad = $ld[0] === '!';
        $linked = '<div class="tv-ln' . ($bad ? ' bad' : '') . '" role="' . ($bad ? 'alert' : 'status') . '"><span class="tv-ln-i" aria-hidden="true">' . ($bad ? '!' : '&#10003;') . '</span><span class="tv-ln-t">'
            . ($bad ? '<b>That sign-in wasn\'t linked.</b> ' . tv_e(substr($ld, 1)) : '<b>' . tv_e($ld) . ' is now linked to your account.</b> Next time, Continue with ' . tv_e($ld) . ' signs you straight in.')
            . '</span><a class="tv-ln-a" href="/user/dashboard.php#sign-ins">Ways to sign in</a><button type="button" class="tv-ln-x" aria-label="Close" data-tv-ln-x>&times;</button></div>'
            . '<style>.tv-ln{display:flex;align-items:center;gap:.6rem;padding:.55rem max(.8rem,env(safe-area-inset-right)) .55rem max(.8rem,env(safe-area-inset-left));background:color-mix(in srgb,var(--tv-moss) 18%,var(--tv-canvas));color:color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink));border-bottom:1px solid color-mix(in srgb,var(--tv-moss) 40%,var(--tv-canvas));font:500 .9rem/1.35 var(--tv-font-ui);position:relative;z-index:41}'
            . '.tv-ln.bad{background:color-mix(in srgb,var(--tv-crimson) 10%,var(--tv-canvas));color:var(--tv-crimson);border-color:color-mix(in srgb,var(--tv-crimson) 35%,var(--tv-canvas))}.tv-ln-i{flex:none;width:24px;height:24px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink));color:#fff;font-weight:800}'
            . '.tv-ln.bad .tv-ln-i{background:var(--tv-crimson)}.tv-ln-t{flex:1;min-width:0}.tv-ln-a{flex:none;color:inherit;font-weight:700;text-decoration:underline;white-space:nowrap}'
            . '.tv-ln-x{flex:none;border:0;background:none;color:inherit;font-size:1.3rem;line-height:1;cursor:pointer;padding:0 .2rem}@media (max-width:480px){.tv-ln{flex-wrap:wrap}.tv-ln-a{order:3;margin-left:30px}}</style>'
            . '<script' . $nonce . '>document.addEventListener("click",function(e){var x=e.target.closest("[data-tv-ln-x]");if(x)x.closest(".tv-ln").remove();});</script>';
    }
    return '<div class="tv-as k-' . $kind . '" role="region" aria-label="Your account" style="--as-bg:' . $bg . ';--as-bd:' . $bd . ';--as-fg:' . $fg . ';--as-ik:' . $ik . '">'
        . '<button type="button" class="tv-as-me" data-tv-as-sw aria-haspopup="menu" aria-expanded="false" title="Switch account: ' . tv_e($tip) . '" aria-label="Switch account (now ' . tv_e($mode . ': ' . $who) . ')">'
        . '<span class="tv-as-av"' . ($photo !== '' ? ' style="background-image:url(\'' . tv_e($photo) . '\')"' : '') . '>' . ($photo === '' ? tv_e($initial) : '') . '</span>'
        . ($kind !== 'user' ? '<span class="tv-as-k" aria-hidden="true">' . (function_exists('tv_icon') ? tv_icon($ic, 'tv-as-svg') : '') . '</span>' : '')
        . '<svg class="tv-as-ch" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg></button>'
        . '<a class="tv-as-t" href="' . tv_e($dashUrl) . '" title="' . tv_e($tip . ' · open its dashboard') . '"><span class="tv-as-m">' . $mode . ':</span> <b>' . tv_e($who) . '</b>' . ($note !== '' ? '<span class="tv-as-n"> · ' . tv_e($note) . '</span>' : '') . '</a>'
        . '<a class="tv-as-ed" href="' . tv_e($editUrl) . '" title="' . tv_e($editTip) . '" aria-label="' . tv_e($editTip) . '">' . $pen . '</a><span class="tv-as-sp"></span>'
        // Edit site (Jason, 2026-11-18: "move the edit button up to a edit site icon in the row of icons by dashboard"): page
        // editing, off until switched on, for this device (Blocks::editingOn); lit while on. Only for staff with Pages: edit.
        . (function () {
            try {
                require_once __DIR__ . '/../lib/Blocks.php';
                if (!Blocks::can('pages.edit')[0]) return '';
                $on = Blocks::editingOn();
                $tip = $on ? 'Editing this site is on (this device): tap to see pages as visitors do' : 'Edit site: show each page\'s sections to edit (this device)';
                return '<button type="button" class="tv-as-out tv-as-edit' . ($on ? ' on' : '') . '" data-tv-as-edit aria-pressed="' . ($on ? 'true' : 'false') . '" title="' . tv_e($tip) . '" aria-label="' . tv_e($tip) . '">'
                    . '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.4 2.6a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/></svg></button>';
            } catch (Throwable $x) { error_log('edit site: ' . $x->getMessage()); return ''; }
        })()
        // the dashboard of whoever you're acting as, one tap from any page (Jason, 2026-11-11: "add a dashboard icon to the top bar
        // of the logged in person"): your own, a business's Overview (/business/<id>, never its Edit listing), or the admin
        . '<a class="tv-as-out tv-as-dash" href="' . tv_e($dashUrl) . '" title="' . tv_e($kind === 'org' ? $who . '\'s dashboard' : ($kind === 'admin' ? 'The admin dashboard' : 'Your dashboard')) . '" aria-label="' . tv_e($kind === 'org' ? $who . '\'s dashboard' : ($kind === 'admin' ? 'The admin dashboard' : 'Your dashboard')) . '">'
        . (function_exists('tv_icon') ? tv_icon('home', 'tv-as-di') : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>') . '</a>'
        . '<button type="button" class="tv-as-out" data-tv-as-out title="Sign out of Traversence" aria-label="Sign out">' . $out . '</button></div>'
        . '<style>.tv-as{display:flex;align-items:center;gap:.5rem;min-height:34px;box-sizing:border-box;padding:.15rem max(.5rem,env(safe-area-inset-right)) .15rem max(.4rem,env(safe-area-inset-left));background:var(--as-bg);border-bottom:1px solid var(--as-bd);color:var(--as-fg);font:600 .82rem/1.2 var(--tv-font-ui);position:relative;z-index:41}'
        . '.tv-as-me{position:relative;flex:none;display:inline-flex;align-items:center;gap:.15rem;border:0;background:none;color:inherit;padding:0;cursor:pointer;border-radius:999px}'
        . '.tv-as-av{width:26px;height:26px;border-radius:999px;background:var(--as-ik) center/cover no-repeat;border:2px solid var(--as-fg);display:inline-flex;align-items:center;justify-content:center;font:700 .8rem var(--tv-font-head);color:var(--tv-on-umber);box-sizing:border-box}'
        . '.tv-as-k{position:absolute;left:16px;bottom:-3px;width:15px;height:15px;border-radius:999px;background:var(--as-ik);border:1.5px solid var(--as-bg);display:inline-flex;align-items:center;justify-content:center;color:var(--tv-on-umber)}.tv-as-svg{width:9px;height:9px}'
        . '.tv-as:not(.k-user) .tv-as-av{animation:tv-as-glow 2.4s ease-in-out infinite}'
        . '@keyframes tv-as-glow{0%,100%{box-shadow:0 0 0 0 color-mix(in srgb,var(--as-fg) 45%,transparent)}50%{box-shadow:0 0 0 4px color-mix(in srgb,var(--as-fg) 0%,transparent)}}'
        . '@media (prefers-reduced-motion:reduce){.tv-as:not(.k-user) .tv-as-av{animation:none;box-shadow:0 0 0 2px color-mix(in srgb,var(--as-fg) 35%,transparent)}}'
        . '.tv-as-ch{width:12px;height:12px;opacity:.8}.tv-as-me[aria-expanded=true] .tv-as-ch{transform:rotate(180deg)}'
        . '.tv-as-me:focus-visible,.tv-as-out:focus-visible{outline:2px solid var(--as-fg);outline-offset:2px}'
        . '.tv-as-t{flex:0 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:inherit;text-decoration:none}.tv-as-t:hover b{text-decoration:underline}.tv-as-sp{flex:1}'
        . '.tv-as-ed{flex:none;width:24px;height:24px;border-radius:999px;border:1px solid color-mix(in srgb,var(--as-fg) 45%,transparent);color:var(--as-fg);display:inline-flex;align-items:center;justify-content:center}.tv-as-ed svg{width:13px;height:13px}.tv-as-ed:hover{background:color-mix(in srgb,var(--as-fg) 15%,transparent)}.tv-as-ed:focus-visible,.tv-as-t:focus-visible{outline:2px solid var(--as-fg);outline-offset:2px}.tv-as-m{font-weight:600;opacity:.85}.tv-as-t b{font-weight:800}.tv-as-n{font-weight:500}'
        . '.tv-as-out{flex:none;width:30px;height:30px;border-radius:999px;border:1px solid color-mix(in srgb,var(--as-fg) 45%,transparent);background:none;color:var(--as-fg);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0}'
        . '.tv-as-out svg{width:16px;height:16px}.tv-as-out:hover{background:color-mix(in srgb,var(--as-fg) 15%,transparent)}'
        . '.tv-as-edit.on{background:var(--tv-sage);border-color:var(--tv-sage);color:var(--tv-umber);box-shadow:0 0 8px color-mix(in srgb,var(--tv-sage) 75%,transparent)}'   // lit while editing is on (the site's active look)
        . 'a.tv-as-dash{text-decoration:none;box-sizing:border-box}.tv-as-dash:focus-visible{outline:2px solid var(--as-fg);outline-offset:2px}'
        . '@media (max-width:420px){.tv-as-n{display:none}}'
        // where the header shrinks to corners pinned to the top (the signed-in side, app-shell.php), the bar is pinned above them
        // and everything pinned under it (the corners, the tools list) starts below it, so nothing hides behind it
        // above the header again (Jason, 2026-11-12, after a morning below it: "above header please"), where the page writes it, and
        // both stay as the page scrolls: the bar pinned at the top, the header pinned under it
        . 'body>.tv-as{position:sticky;top:0;z-index:40}body:has(>.tv-as) :is(#top-bar,#tv-nav){top:var(--as-h,34px)}'
        . ':root:has(body>.tv-as){--as-h:34px}'   // its height, for what sticks below it (the admin's command bar); app-shell.php measures it
        . 'html.tv-brand-min.tv-nav-min body.tv-back:has(#ta-rail) .tv-as{position:fixed;top:0;left:0;right:0;height:34px;z-index:46}'
        . 'html.tv-brand-min.tv-nav-min body.tv-back:has(#ta-rail):has(.tv-as) :is(#top-bar,#tv-nav){top:34px}'
        . 'html.tv-brand-min.tv-nav-min body.tv-back:has(#ta-rail):has(.tv-as) .ta-body{margin-top:calc(var(--ta-top,50px) + .6rem + 34px)}'
        . '@media (max-width:767px){body.tv-back:has(#ta-rail):has(.tv-as) .ta-list{top:34px!important;max-height:calc(100dvh - 34px)!important}'
        . 'html:not(.tv-brand-min) body:has(.tv-as) .ta-list{top:calc(var(--ta-top,56px) + 34px)!important}}'
        . '@media (min-width:768px){html.tv-brand-min.tv-nav-min body:has(.tv-as) .ta-rail{top:34px}}</style>'
        . '<script' . $nonce . '>(function(){var s=document.querySelector("[data-tv-as-sw]");'
        . 'if(s)s.addEventListener("click",function(e){e.stopPropagation();s.setAttribute("data-cx-under","");if(window.tvCx){tvCx(s);var m=document.getElementById("cx-menu");s.setAttribute("aria-expanded",String(!!m&&!m.hidden));}else location.href="/user/accounts.php";});'
        . 'var ed=document.querySelector("[data-tv-as-edit]");if(ed)ed.addEventListener("click",function(){var on=ed.getAttribute("aria-pressed")!=="true";if(window.TvAsk&&TvAsk.busy)TvAsk.busy(ed,true);'
        . 'document.cookie="tv_edit="+(on?"1; max-age=31536000":"; max-age=0")+"; path=/; SameSite=Lax"+(location.protocol==="https:"?"; Secure":"");location.reload();});'   // Edit site: this device only, until switched off
        . 'var o=document.querySelector("[data-tv-as-out]");if(o)o.addEventListener("click",function(){if(window.TvAsk)TvAsk.busy(o,true);'   // the header's own sign-out (js/header-nav.js)
        . 'var tk=' . json_encode((string) ($_SESSION['csrf_token'] ?? '')) . ';'
        . 'if(window.siteLogout)siteLogout(tk,o);else fetch("/api/auth/logout.php",{method:"POST",credentials:"include",headers:{"X-CSRF-Token":tk,"Content-Type":"application/json"}}).then(function(r){if(!r.ok)throw 0;location.href="/";}).catch(function(){location.href="/login.php";});});})();</script>' . $linked;
}
