<?php
// app/lib/ListingConfidence.php — how sure we are of a listing, 0 to 100 (decisions/0133, "Listing confidence").
//
// Worked out from the listing's identity record: each independent source counts once (a website once, however it was
// found), weighted by what it is (an official registry, a government page, its own website, a chamber…), and counting
// for less as it gets older. Links (Google, OpenStreetMap, social pages) are where to look; only a Google match adds a
// little, as our own verdict that the place exists there. Visitors' "Is this right? Yes" adds a little, counted per
// device a day, never who. Disagreements lower it: a dead website, a closure report, sources that disagree.
//
// Green means a person stands behind it: machine evidence alone stops at 75; our team's check, or the owner's claim
// ("a claim is a claim", Jason 2026-11-01), lifts it; the ✓ is the owner's proved link (a verified claim). A green
// listing whose evidence turns against it drops out of green until someone looks again.
//
// The score orders upkeep and shows visitors how sure we are; publishing still rests on the readiness rules (0076).
declare(strict_types=1);

require_once __DIR__ . '/Identity.php';

final class ListingConfidence
{
    /** Each independent source's weight, by its kind (tuned later in Thresholds & gates). */
    // our team's own input (checked, or typed in the editor) and the owner's word are the strongest: a rural business often
    // has no website or registry record, and we, its owner and its neighbours are the sources (Jason, 2026-11-01)
    public const WEIGHTS = ['admin' => 30, 'staff' => 30, 'owner' => 30, 'member' => 12, 'registry' => 22, 'government' => 18, 'own_site' => 18, 'chamber' => 12, 'community' => 10,
                            'source' => 8, 'open_data' => 6, 'directory' => 4];
    /** The bands: [lowest score, colour key, what the card says, its colour]. */
    public const BANDS = [
        'red' => [0, 'Unconfirmed', 'Found by our crawler, not checked yet', '#C2410C'],
        'orange' => [26, 'Being checked', 'Some sources agree; it\'s being confirmed', '#EA8A1E'],
        'yellow' => [51, 'Qualified', 'Enough independent sources agree', '#C99A06'],
        'green' => [76, 'Confirmed', 'Confirmed by Traversence', '#3F8A5E'],
    ];
    public const MACHINE_CAP = 75;

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT 1 FROM listing_confidence LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    public static function band(int $score): string
    {
        $b = 'red';
        foreach (self::BANDS as $k => $v) if ($score >= $v[0]) $b = $k;
        return $b;
    }

    /** The stored score for the card: ['score', 'band', 'label', 'lines' => [[text, when]], 'colour', 'meaning', 'updated_at'] or null. */
    public static function get(PDO $pdo, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM listing_confidence WHERE entity_id = ?'); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) { self::refresh($pdo, $id); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC); }
        if (!$r) return null;
        $b = self::BANDS[$r['band']] ?? self::BANDS['red'];
        return ['score' => (int) $r['score'], 'band' => (string) $r['band'], 'label' => (string) $r['label'], 'colour' => $b[3], 'meaning' => $b[2],
                'lines' => json_decode((string) $r['lines_json'], true) ?: [], 'updated_at' => (string) $r['updated_at']];
    }

    /** Works the score out again and stores it. Never fails the caller. */
    public static function refresh(PDO $pdo, int $id): ?array
    {
        try {
            if (!self::ready($pdo) || !Identity::ready($pdo)) return null;
            $c = self::compute($pdo, $id);
            if ($c === null) return null;
            $pdo->prepare('INSERT INTO listing_confidence (entity_id, score, band, label, lines_json, updated_at) VALUES (?, ?, ?, ?, ?, NOW())
                           ON DUPLICATE KEY UPDATE score = VALUES(score), band = VALUES(band), label = VALUES(label), lines_json = VALUES(lines_json), updated_at = NOW()')
                ->execute([$id, $c['score'], $c['band'], $c['label'], json_encode($c['lines'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
            return $c;
        } catch (Throwable $x) { error_log('confidence #' . $id . ': ' . $x->getMessage()); return null; }
    }

    /** ['score', 'band', 'label', 'lines' => [[text, 'Mon YYYY']], 'why' => [debug]] from the identity record, or null. */
    public static function compute(PDO $pdo, int $id): ?array
    {
        $e = $pdo->prepare("SELECT id, name, status, owner_user_id FROM entities WHERE id = ? AND entity_type = 'merchant'"); $e->execute([$id]);
        $e = $e->fetch(PDO::FETCH_ASSOC);
        if (!$e) return null;
        $F = Database::t('identity_facts'); $S = Database::t('identity_fact_sources');
        $st = $pdo->prepare("SELECT f.fact, f.value, f.status, f.is_current, s.kind, s.site, s.url, s.label, s.checked_at FROM $F f JOIN $S s ON s.fact_id = f.id
                             WHERE f.record_kind = 'listing' AND f.record_id = ? AND f.is_current = 1 AND f.status NOT IN ('rejected', 'replaced')");
        $st->execute([$id]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $now = time();
        $age = fn (string $at) => max(0.4, 1 - max(0, $now - (int) strtotime($at)) / (86400 * 1095));   // three years to its floor
        $src = [];       // independent source key => [weight, facts, kind, label, newest]
        $keyOk = ['who' => false, 'where' => false, 'how' => false];
        $person = false; $conflicts = 0; $seenConf = [];
        foreach ($rows as $r) {
            $k = (string) $r['kind']; $site = (string) $r['site'];
            if ($r['status'] === 'conflict' && !isset($seenConf[$r['fact']])) { $conflicts++; $seenConf[$r['fact']] = 1; }
            if ($r['status'] === 'confirmed') {
                if ($r['fact'] === 'name') $keyOk['who'] = true;
                if (in_array($r['fact'], ['address', 'point'], true)) $keyOk['where'] = true;
                if (in_array($r['fact'], ['phone', 'website'], true)) $keyOk['how'] = true;
            }
            if (in_array($k, ['admin', 'staff'], true) && in_array($r['fact'], ['name', 'address', 'phone', 'website', 'point'], true)) $person = true;   // our team stands behind it
            if ($k === 'evidence') {   // a link: only a Google match counts, a little, as our verdict that it's there
                if (!preg_match('/(^|\.)google\.com$/', $site) && !str_contains((string) $r['url'], 'google.com/maps')) continue;
                $w = 10; $key = 'google';
            } else {
                $w = self::WEIGHTS[$k] ?? 0;
                if ($w === 0) continue;   // the crawler's copy, an import, social pages: where it came from, not evidence
                $key = $site !== '' ? $site : $k . ':' . $r['label'];
            }
            $w = self::collab($pdo, $k, $site, (string) $r['url'], $key, $w, $rows);   // the collaborative score's weight where its source is one of 0163 §12's kinds
            $w *= $age((string) $r['checked_at']);
            if (!isset($src[$key]) || $src[$key][0] < $w) $src[$key] = [$w, $src[$key][1] ?? [], $k, (string) $r['label'], (string) $r['checked_at'], $site];
            $src[$key][1][$r['fact']] = 1;
            if (strtotime((string) $r['checked_at']) > strtotime($src[$key][4])) $src[$key][4] = (string) $r['checked_at'];
        }
        // independent sources, strongest first, each counting a little less than the one before
        uasort($src, fn ($a, $b) => $b[0] <=> $a[0]);
        $score = 10.0;   // found and listed
        $i = 0; foreach ($src as $s) { $score += $s[0] * max(0.35, 1 - 0.2 * $i); $i++; }
        $score += 5 * count(array_filter($keyOk));
        // visitors' "Yes", the last year: one per detail a day
        $yes = 0;
        try { $y = $pdo->prepare('SELECT COUNT(*) FROM listing_confirms WHERE entity_id = ? AND day >= ?'); $y->execute([$id, date('Y-m-d', strtotime('-365 days'))]); $yes = (int) $y->fetchColumn(); } catch (Throwable) {}
        $score += min(24, 6 * $yes);   // local people saying it's right: a strong signal where nothing else is online
        // what speaks against it
        $against = [];
        $meta = $pdo->prepare("SELECT meta_key, meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key IN ('website_dead', 'closed', 'site_moved', 'closed_signal', 'unconfirmed')"); $meta->execute([$id]);
        $m = $meta->fetchAll(PDO::FETCH_KEY_PAIR);
        if (isset($m['website_dead'])) { $score -= 10; $against[] = 'Its website stopped working'; }
        if (isset($m['closed'])) { $score -= 20; $against[] = 'Reported closed'; }
        elseif (isset($m['closed_signal'])) {   // one source (decisions/0133); Data cleanup's caution names the site that said it (0164 R12)
            $cs = json_decode((string) $m['closed_signal'], true);
            $score -= self::against($pdo, 'closure', 10); $against[] = is_array($cs) && ($cs['from'] ?? '') === 'cleanup' ? 'Still open? One site said it closed' . (!empty($cs['line']) ? ' (' . mb_strimwidth((string) $cs['line'], 0, 90, '…') . ')' : '') : 'Possibly closed: its own website says so';
        }
        if (isset($m['unconfirmed'])) {   // values from OpenStreetMap only (Data cleanup, 0164 R9): shown as not yet confirmed until re-sourced
            $uf = array_keys((array) (json_decode((string) $m['unconfirmed'], true)['fields'] ?? []));
            if ($uf) { $score -= min(10, 3 * count($uf)); $against[] = 'Not yet confirmed: its ' . implode(', ', str_replace('point', 'map point', $uf)) . ' (from OpenStreetMap only)'; }
        }
        if (isset($m['site_moved'])) { $score -= 8; $against[] = 'Its website says it moved'; }
        try {
            $sg = $pdo->prepare("SELECT COUNT(*) FROM suggestions WHERE entity_id = ? AND status = 'new' AND kind IN ('closed', 'moved', 'fix', 'wrong')"); $sg->execute([$id]);
            if ($n = (int) $sg->fetchColumn()) { $score -= min(10, 5 * $n); $against[] = 'A visitor reported something to check'; }
        } catch (Throwable) {}
        if ($conflicts) { $score -= min(15, 5 * $conflicts); $against[] = 'Sources disagree on ' . $conflicts . ' detail' . ($conflicts === 1 ? '' : 's'); }
        $score = (int) round(max(0, min(self::MACHINE_CAP, $score)));
        // a person stands behind it: our team's check, or the owner's claim ("a claim is a claim")
        $label = '';
        $claimed = (int) $e['owner_user_id'] > 0 && in_array($e['status'], ['claimed-unverified', 'verified', 'pending-verification'], true);
        // on top of a person's floor, the listing's own evidence still counts: up to 10 more (a proved claim with strong
        // outside sources reaches 100; one with none stays at 90)
        // a claim keeps its band whatever the crawler says against it (gap review P3-4): each item against shows as a caution
        // line and lowers it within the band (80 to 89 claimed, 90 to 99 proved); only a claim found false, or Closed, leaves it
        if ($against && $claimed) {
            $more = max(0, min(9, (int) floor(10 * $score / self::MACHINE_CAP) - 3 * count($against)));
            if ($e['status'] === 'verified') { $score = 90 + $more; $label = 'Claimed by the owner ✓'; }
            else { $score = 80 + $more; $label = 'Claimed by the owner'; }
        } elseif (!$against) {
            $more = (int) floor(10 * $score / self::MACHINE_CAP);
            if ($claimed && $e['status'] === 'verified') { $score = 90 + $more; $label = 'Claimed by the owner ✓'; }
            elseif ($claimed) { $score = 80 + $more; $label = 'Claimed by the owner'; }
            elseif ($person) { $score = 80 + $more; $label = 'Confirmed by Traversence'; }
        }
        $band = self::band($score);
        if ($label === '') $label = self::BANDS[$band][1];
        // How we know: the strongest evidence, newest date, in plain words
        $lines = [];
        if ($claimed) $lines[] = [$e['status'] === 'verified' ? 'The owner claimed it and proved it\'s theirs' : 'The owner claimed it', ''];
        if ($person) $lines[] = ['Checked by our team', ''];
        foreach (array_slice($src, 0, 6, true) as $key => $s) $lines[] = [self::phrase($s[2], $s[3], (string) $s[5], array_keys($s[1]), $key), $s[4] !== '' ? date('M Y', strtotime($s[4])) : ''];
        if ($yes) $lines[] = [$yes . ' visitor confirmation' . ($yes === 1 ? '' : 's') . ' this year', ''];
        foreach ($against as $a) $lines[] = ['⚠ ' . $a, ''];
        if (!$src && !$claimed && !$person) $lines[] = ['Found by our crawler; no other source has confirmed it yet', ''];
        return ['score' => $score, 'band' => $band, 'label' => $label, 'lines' => $lines];
    }

    /**
     * The collaborative score (decisions/0164 §3.5, 0163 §12): an independent source of one of §12's kinds adds its weight
     * when it agrees on the name plus the phone or the address (the weights are W1's settings, tuned by a director); it
     * feeds the confidence, never a gate. Other kinds keep their 0133 weight ($w).
     */
    private static function collab(PDO $pdo, string $kind, string $site, string $url, string $key, float $w, array $rows): float
    {
        $k12 = null;
        if ($key === 'google') $k12 = 'google_address';
        elseif (preg_match('/(^|\.)(overturemaps\.org|foursquare\.com)$/', $site)) $k12 = 'open_dataset';
        elseif (preg_match('/(^|\.)(openstreetmap\.org|osm\.org)$/', $site)) $k12 = 'osm';
        elseif (preg_match('/(^|\.)facebook\.com$/', $site)) $k12 = 'facebook';
        elseif ($kind === 'chamber') $k12 = 'chamber';
        elseif (in_array($kind, ['directory', 'community'], true)) $k12 = 'directory';
        if ($k12 === null) return $w;
        $facts = [];
        foreach ($rows as $r) if (((string) $r['site'] === $site && $site !== '') || ($key === 'google' && (string) $r['kind'] === 'evidence' && str_contains((string) $r['url'], 'google'))) $facts[(string) $r['fact']] = true;
        if ($key === 'google' && isset($facts['phone'])) $k12 = 'google_phone';
        if ($key !== 'google' && !(isset($facts['name']) && (isset($facts['phone']) || isset($facts['address'])))) return 0.0;   // agreeing on the name plus the phone or the address
        return (float) self::weights($pdo)[$k12];
    }

    /** W1's weights (WorkflowSettings, a director's settings with who and when, and a Reset), else 0163 §12's to start. */
    public static function weights(PDO $pdo): array
    {
        static $w = null;
        if ($w !== null) return $w;
        require_once __DIR__ . '/WorkflowSettings.php';
        $w = array_map(fn ($x) => $x[1], WorkflowSettings::WEIGHTS);
        try { foreach ((array) (WorkflowSettings::current($pdo, 'W1')['weights'] ?? []) as $k => $v) if (isset($w[$k]) && is_numeric($v)) $w[$k] = (float) $v; } catch (Throwable) {}
        return $w;
    }

    /** A signal against, from the settings (−40 a closure signal, −60 a dissolved licence): its size as a positive number. */
    private static function against(PDO $pdo, string $k, float $old): float
    {
        $v = self::weights($pdo)[$k] ?? -$old;
        return abs((float) $v);
    }

    /** One line of How we know: "Phone and address on its own website". */
    private static function phrase(string $kind, string $label, string $site, array $facts, string $key): string
    {
        $names = ['name' => 'name', 'address' => 'address', 'point' => 'place', 'phone' => 'phone', 'website' => 'website', 'hours' => 'hours', 'city' => 'town', 'zip' => 'ZIP', 'email' => 'email'];
        $what = array_values(array_filter(array_map(fn ($f) => $names[$f] ?? '', $facts)));
        $what = array_values(array_unique(array_filter($what, fn ($w) => $w !== 'name' || count($facts) === 1)));
        $list = count($what) > 1 ? implode(', ', array_slice($what, 0, -1)) . ' and ' . end($what) : ($what[0] ?? 'it');
        $list = ucfirst($list);
        if ($key === 'google') return 'It\'s on Google Maps at this place';
        return match ($kind) {
            'registry' => $list . ' in the ' . ($label !== '' ? preg_replace('/\s*\(.*\)$/', '', $label) : 'official registry'),
            'government' => $list . ' on a government page (' . $site . ')',
            'own_site' => $list . ' on its own website',
            'chamber' => $list . ' listed by the chamber of commerce (' . $site . ')',
            'community' => $list . ' in a community directory (' . $site . ')',
            'open_data' => $list . ' in open data (' . $site . ')',
            'directory' => $list . ' in a directory (' . $site . ')',
            'admin' => $list . ' checked by our team',
            'staff' => $list . ' entered by our team',
            'owner' => $list . ' from the owner',
            'member' => $list . ' corrected by a local and checked by our team',
            default => $list . ' on ' . ($site !== '' ? $site : 'another source'),
        };
    }

    /** A visitor says a detail is right: one count per listing, detail and day (the browser keeps it to once a day per device; never who). */
    public static function yes(PDO $pdo, int $id, string $fact): void
    {
        if (!in_array($fact, ['name', 'address', 'phone', 'website', 'hours', 'open', 'closed'], true)) throw new InvalidArgumentException('Which detail?');
        $e = $pdo->prepare("SELECT 1 FROM entities WHERE id = ? AND entity_type = 'merchant' AND is_suppressed = 0"); $e->execute([$id]);
        if (!$e->fetchColumn()) throw new InvalidArgumentException('That listing isn\'t here.');
        $pdo->prepare('INSERT INTO listing_confirms (entity_id, fact, day, yes_n) VALUES (?, ?, CURDATE(), 1) ON DUPLICATE KEY UPDATE yes_n = LEAST(yes_n + 1, 999)')->execute([$id, $fact]);
        self::refresh($pdo, $id);
    }

    /** How many visitors (devices, a day each) answered "open" and "It's closed" since a moment. */
    public static function answersSince(PDO $pdo, int $id, string $since): array
    {
        $st = $pdo->prepare("SELECT fact, COALESCE(SUM(yes_n), 0) FROM listing_confirms WHERE entity_id = ? AND fact IN ('open', 'closed') AND day >= ? GROUP BY fact");
        $st->execute([$id, substr($since, 0, 10)]);
        $r = $st->fetchAll(PDO::FETCH_KEY_PAIR);
        return ['open' => (int) ($r['open'] ?? 0), 'closed' => (int) ($r['closed'] ?? 0)];
    }

    /**
     * "Still open?" (decisions/0163 §8, gap review P5-2): why a listing with a closure signal now needs our team, or null.
     * After 30 days with fewer than 3 visitors saying it's open; at once when a second origin says closed (a visitor
     * besides the site or dataset); at once when 3 visitors say closed and none open since (F2). Nothing closes a listing by
     * itself: our team confirms it (a call, a visit, a photo of the sign: P5-1).
     */
    public static function stillOpenDue(PDO $pdo, int $id): ?string
    {
        $st = $pdo->prepare("SELECT meta_value, created_at FROM entity_metadata WHERE entity_id = ? AND meta_key = 'closed_signal'");
        $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
        $sig = $r ? (json_decode((string) $r['meta_value'], true) ?: []) : [];
        $since = (string) ($sig['at'] ?? ($r['created_at'] ?? date('Y-m-d', strtotime('-30 days'))));
        $a = self::answersSince($pdo, $id, $since);
        if ($a['closed'] >= 3 && $a['open'] === 0) return $a['closed'] . ' visitors say it\'s closed, none that it\'s open';
        if (!$r) return null;
        if ($a['closed'] >= 1) return 'Its signal (' . (string) ($sig['from'] ?? 'a source') . ') and a visitor both say it closed';
        if (strtotime($since) <= strtotime('-30 days') && $a['open'] < 3) return 'Possibly closed for 30 days; ' . $a['open'] . ' visitor' . ($a['open'] === 1 ? '' : 's') . ' said it\'s open';
        return null;
    }

    /**
     * The daily "Still open?" pass: each listing that's due gets the ask (meta still_open_ask, which puts it first on the
     * Call list), or, with no phone, a step in "The engine needs a person". An answered one (a call or visit logged after
     * the ask, the signal gone, or it closed) loses the ask. How many asked.
     */
    public static function stillOpenTick(PDO $pdo, int $limit = 300): int
    {
        if (!self::ready($pdo)) return 0;
        $n = 0;
        try {
            $ids = $pdo->query("SELECT DISTINCT e.id FROM entities e
                                  LEFT JOIN entity_metadata s ON s.entity_id = e.id AND s.meta_key = 'closed_signal'
                                  LEFT JOIN listing_confirms lc ON lc.entity_id = e.id AND lc.fact = 'closed' AND lc.day >= CURDATE() - INTERVAL 90 DAY
                                  LEFT JOIN entity_metadata cl ON cl.entity_id = e.id AND cl.meta_key = 'closed'
                                 WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND cl.entity_id IS NULL AND (s.entity_id IS NOT NULL OR lc.entity_id IS NOT NULL)
                                 LIMIT " . max(1, min(2000, $limit)))->fetchAll(PDO::FETCH_COLUMN);
            $has = $pdo->prepare("SELECT meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key = 'still_open_ask'");
            $phone = $pdo->prepare("SELECT 1 FROM entity_metadata WHERE entity_id = ? AND meta_key = 'phone' AND meta_value NOT IN ('', '\"\"', 'null')");
            require_once __DIR__ . '/CrawlerIngest.php';
            foreach ($ids as $id) {
                $id = (int) $id;
                $why = self::stillOpenDue($pdo, $id);
                $has->execute([$id]); $cur = $has->fetchColumn();
                if ($why === null) { if ($cur !== false) $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = 'still_open_ask'")->execute([$id]); continue; }
                if ($cur !== false) continue;
                CrawlerIngest::upsertMetadataKey($pdo, $id, 'still_open_ask', ['why' => $why, 'at' => date('Y-m-d')]);
                $phone->execute([$id]);
                if (!$phone->fetchColumn()) {
                    require_once __DIR__ . '/EngineCase.php';
                    $nm = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $nm->execute([$id]);
                    EngineCase::raise($pdo, 'closure', 'closure:' . $id, 'Still open? ' . (string) $nm->fetchColumn() . ' (#' . $id . '): ' . $why, ['id' => $id, 'why' => $why]);
                }
                $n++;
            }
        } catch (Throwable $x) { error_log('still open tick: ' . $x->getMessage()); }
        return $n;
    }

    /** Listings whose score is missing or more than a week old: refreshed, $limit a run (scheduled jobs). */
    public static function backfill(PDO $pdo, int $limit = 200): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->query("SELECT e.id FROM entities e LEFT JOIN listing_confidence c ON c.entity_id = e.id WHERE e.entity_type = 'merchant'
                            AND (c.entity_id IS NULL OR c.updated_at < NOW() - INTERVAL 7 DAY) ORDER BY c.updated_at IS NOT NULL, c.updated_at, e.id DESC LIMIT " . max(1, min(1000, $limit)));
        $n = 0; foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) { self::refresh($pdo, (int) $id); $n++; }
        return $n;
    }
}
