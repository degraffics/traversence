<?php
// app/lib/EngineCase.php — "The engine needs a person": the Knowledge Engine's one Pulse case (decisions/0164 §6.1, gap
// review X3; 0163 §10). Every item the engine raises for a person is a step of it, each a button that does it, grouped
// by kind and ordered by value (claimed listings' items first), so nothing lands in Review without a prompt:
//   identity       the identity queue (§6.1): a pair the vetting couldn't settle, or one where a listing is claimed or a
//                  person entered or decided something: Merge (choose which stays), Keep apart, Make a sales lead (the
//                  existing pipeline, Leads::route, the Call list; the call's outcome answers it), Make an admin task
//   identity_mass  the recheck would merge more than 5% of a town's listings in one run: OK it, or hold
//   site           a site that blocks us (P1-2, §1.2): held, never retried by itself; Reactivate, or keep it held
//   service        a banned outside service (§6.1): "looks lifted" or still refused after 3 days: Reactivate, keep
//                  checking daily or weekly, or stop checking
//   intake         Listing Intake's out-of-options finds, by AutoImport::reason() group (derived, not stored): List them
//                  anyway where the group allows it, else open them in Review
// The steps live in `engine_steps` (one row per kind and ref); the Pulse case is rebuilt from them on each load, as every
// Pulse case is. A step answered is kept (done, with who and the answer) so the same ask is never raised twice.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class EngineCase
{
    public const KEY = 'engine:person';
    /** Kinds, in the order the case shows them: [heading, what a step of it asks]. */
    public const KINDS = [
        'identity' => ['The identity queue', 'Two listings that may be one business: what the evidence couldn\'t settle, or one a person entered or claimed. Both stay public meanwhile.'],
        'identity_mass' => ['Many merges in one town', 'The identity recheck would merge more than its share of a town in one run.'],
        'service' => ['Outside services that refused us', 'A ban or a refused key is never lifted by itself (decisions/0164 §6.1).'],
        'site' => ['Sites that block us', 'Held, never retried by itself: its facts keep showing with "last checked" while its other sources refresh it.'],
        'closure' => ['Still open? with no phone to call', 'A listing that may have closed and has no number: a visit, a photo of the sign or the owner settles it; nothing closes it by itself (P5-1, P5-2).'],
        'intake' => ['Finds out of options', 'Listing Intake\'s finds the engine has tried everything on; it keeps retrying on the ladder.'],
    ];

    private static ?bool $ready = null;

    public static function ready(PDO $pdo): bool
    {
        if (self::$ready !== null) return self::$ready;
        try { $pdo->query('SELECT 1 FROM engine_steps LIMIT 0'); return self::$ready = true; } catch (Throwable) { return self::$ready = false; }
    }

    /** Raises (or refreshes) a step. A step already answered isn't raised again unless $again. Returns its id (0 before the update). */
    public static function raise(PDO $pdo, string $kind, string $ref, string $title, array $data = [], bool $again = false, int $value = 0): int
    {
        if (!self::ready($pdo) || !isset(self::KINDS[$kind])) return 0;
        try {
            $st = $pdo->prepare('SELECT id, status FROM engine_steps WHERE kind = ? AND ref = ?'); $st->execute([$kind, $ref]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            $claimed = 0;
            foreach (['a', 'b', 'entity'] as $k) if (!empty($data[$k])) { $c = $pdo->prepare("SELECT status <> 'unclaimed' FROM entities WHERE id = ?"); $c->execute([(int) $data[$k]]); $claimed = max($claimed, (int) $c->fetchColumn()); }
            $value = $value ?: ($claimed ? 100 : 10);   // claimed listings' items first (R4)
            if ($r) {
                if (in_array($r['status'], ['done', 'held'], true) && !$again) return (int) $r['id'];
                $pdo->prepare("UPDATE engine_steps SET title = ?, data = ?, value = ?, status = 'open', updated_at = UTC_TIMESTAMP(), done_at = IF(? , NULL, done_at) WHERE id = ?")
                    ->execute([mb_substr($title, 0, 500), json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $value, $again ? 1 : 0, (int) $r['id']]);
                return (int) $r['id'];
            }
            $pdo->prepare("INSERT INTO engine_steps (kind, ref, title, data, value, status, opened_at, updated_at) VALUES (?, ?, ?, ?, ?, 'open', UTC_TIMESTAMP(), UTC_TIMESTAMP())")
                ->execute([$kind, mb_substr($ref, 0, 120), mb_substr($title, 0, 500), json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $value]);
            return (int) $pdo->lastInsertId();
        } catch (Throwable $x) { error_log('engine raise ' . $kind . ': ' . $x->getMessage()); return 0; }
    }

    public static function step(PDO $pdo, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM engine_steps WHERE id = ?'); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $r['data'] = json_decode((string) $r['data'], true) ?: [];
        return $r;
    }

    public static function find(PDO $pdo, string $kind, string $ref): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT id FROM engine_steps WHERE kind = ? AND ref = ?'); $st->execute([$kind, $ref]);
        $id = (int) $st->fetchColumn();
        return $id ? self::step($pdo, $id) : null;
    }

    /** Closes a step with its answer. */
    public static function done(PDO $pdo, int $id, string $answer, int $uid = 0): void
    {
        if (!self::ready($pdo)) return;
        $pdo->prepare("UPDATE engine_steps SET status = 'done', answer = ?, done_by = ?, done_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP() WHERE id = ?")->execute([mb_substr($answer, 0, 500), $uid ?: null, $id]);
    }

    /** Open steps, by kind's order then value. */
    public static function open(PDO $pdo, int $limit = 300): array
    {
        if (!self::ready($pdo)) return [];
        $rows = $pdo->query("SELECT * FROM engine_steps WHERE status = 'open' ORDER BY value DESC, opened_at LIMIT " . max(1, min(2000, $limit)))->fetchAll(PDO::FETCH_ASSOC);
        $order = array_flip(array_keys(self::KINDS));
        foreach ($rows as &$r) $r['data'] = json_decode((string) $r['data'], true) ?: [];
        unset($r);
        usort($rows, fn ($a, $b) => [$order[$a['kind']] ?? 99, -(int) $a['value'], $a['opened_at']] <=> [$order[$b['kind']] ?? 99, -(int) $b['value'], $b['opened_at']]);
        return $rows;
    }

    // ---- sites that block us (P1-2) ----------------------------------------------------------------------------------

    /** A site's host as held: why, or null. Its readers skip it (never retried by itself) until a person's Reactivate. */
    public static function siteHeld(PDO $pdo, string $host): ?string
    {
        if (!self::ready($pdo)) return null;
        $h = self::host($host);
        if ($h === '') return null;
        static $held = null;
        if ($held === null) {
            $held = [];
            try { foreach ($pdo->query("SELECT ref, title FROM engine_steps WHERE kind = 'site' AND status IN ('open', 'held')")->fetchAll(PDO::FETCH_ASSOC) as $r) $held[substr((string) $r['ref'], 5)] = (string) $r['title']; } catch (Throwable) {}
        }
        return $held[$h] ?? null;
    }

    /** Sites held (open or kept held), for the switch-on check and Outside services: [host => [why, status, at]]. */
    public static function heldSites(PDO $pdo): array
    {
        $out = [];
        if (!self::ready($pdo)) return $out;
        try { foreach ($pdo->query("SELECT ref, title, status, opened_at FROM engine_steps WHERE kind = 'site' AND status IN ('open', 'held') ORDER BY opened_at")->fetchAll(PDO::FETCH_ASSOC) as $r) $out[substr((string) $r['ref'], 5)] = [(string) $r['title'], (string) $r['status'], (string) $r['opened_at']]; } catch (Throwable) {}
        return $out;
    }

    /** A person's Reactivate for a held site. */
    public static function reactivateSite(PDO $pdo, string $host, int $uid, string $who): bool
    {
        if (!self::ready($pdo)) return false;
        $st = $pdo->prepare("UPDATE engine_steps SET status = 'done', answer = ?, done_by = ?, done_at = UTC_TIMESTAMP() WHERE kind = 'site' AND ref = ? AND status IN ('open', 'held')");
        $st->execute(['Reactivated by ' . $who, $uid ?: null, 'site:' . self::host($host)]);
        return $st->rowCount() > 0;
    }

    /** Whether an answer means the site blocks us: 401/403/406/418/451, a login wall, robots, a challenge page. */
    public static function blocks(int $status, string $body = ''): bool
    {
        if (in_array($status, [401, 403, 406, 418, 451], true)) return true;
        return $status === 200 && $body !== '' && (bool) preg_match('/(cf-chl|challenge-platform|captcha|verify you are (a )?human|access denied|attention required)/i', mb_substr($body, 0, 4000));
    }

    /** A site that blocked us: held, with its evidence, as a step with Reactivate. $why: "answered 403", "robots.txt disallows us". */
    public static function blockedSite(PDO $pdo, string $hostOrUrl, string $why, string $from = ''): void
    {
        $h = self::host($hostOrUrl);
        if ($h === '') return;
        self::raise($pdo, 'site', 'site:' . $h, $h . ' blocks us: ' . $why . ($from !== '' ? ' (' . $from . ')' : '') . '. Held, not retried; its facts keep showing with "last checked".', ['host' => $h, 'why' => $why, 'from' => $from, 'at' => gmdate('c')], true);
    }

    private static function host(string $u): string
    {
        $u = trim($u);
        if ($u === '') return '';
        $h = str_contains($u, '/') || str_contains($u, ':') ? (string) parse_url(preg_match('#^[a-z]+://#i', $u) ? $u : 'https://' . $u, PHP_URL_HOST) : $u;
        return (string) preg_replace('/^www\./', '', strtolower($h));
    }

    // ---- the Pulse case ----------------------------------------------------------------------------------------------

    /** The derived steps: Listing Intake's out-of-options finds, by reason group. [reasonKey => [count, text, publish]]. */
    public static function intakeGroups(PDO $pdo): array
    {
        $out = [];
        try {
            require_once __DIR__ . '/crawler/AutoImport.php';
            $st = $pdo->query("SELECT raw_payload, created_at FROM " . Database::t('crawler_raw_index') . " WHERE status = 'staged' AND payload_type = 'listing' ORDER BY id DESC LIMIT 3000");
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $c = json_decode((string) $r['raw_payload'], true);
                if (!is_array($c) || !AutoImport::exhausted($c, (string) $r['created_at'])) continue;
                $g = AutoImport::reason($c);
                $out[$g['key']] ??= [0, (string) $g['text'], !empty($g['publish'])];
                $out[$g['key']][0]++;
            }
        } catch (Throwable $x) { error_log('engine intake: ' . $x->getMessage()); }
        return $out;
    }

    /** Pulse::items' row: [key, severity, title, why, when] or none. */
    public static function pulseItems(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [];
        self::settleLeads($pdo);
        $open = self::open($pdo, 2000);
        $intake = array_sum(array_column(self::intakeGroups($pdo), 0));
        $n = count($open) + ($intake ? 1 : 0);
        if (!$n) return [];
        $by = [];
        foreach ($open as $r) $by[$r['kind']] = ($by[$r['kind']] ?? 0) + 1;
        $parts = [];
        foreach (self::KINDS as $k => [$h]) if (!empty($by[$k])) $parts[] = $by[$k] . ' ' . mb_strtolower($h);
        if ($intake) $parts[] = $intake . ' finds out of options';
        $when = $open ? max(array_column($open, 'updated_at')) : gmdate('Y-m-d H:i:s');
        $sev = !empty($by['service']) || !empty($by['identity_mass']) ? 'alert' : 'update';
        return [[self::KEY, $sev, 'The engine needs a person', ucfirst(implode('; ', $parts)) . '. Each is a step with a button that does it; the engine keeps trying the rest meanwhile.', $when . ' UTC']];
    }

    /** Pulse::playbook's steps. $s: Pulse's step factory ($t, $h, ?$act, $auto, $ext). */
    public static function pulseSteps(PDO $pdo, callable $s): array
    {
        $st = [];
        $staff = self::staffChoices($pdo);
        $shown = 0;
        foreach (self::open($pdo, 300) as $r) {
            if ($shown++ >= 120) { $st[] = $s('And more', 'The next steps show as these are answered.', null); break; }
            $id = (int) $r['id']; $d = $r['data']; $t = (string) $r['title'];
            $who = !empty($r['assigned_to']) ? ' Assigned to ' . self::staffName($pdo, (int) $r['assigned_to']) . '.' : '';
            switch ($r['kind']) {
                case 'identity':
                    $a = (int) ($d['a'] ?? 0); $b = (int) ($d['b'] ?? 0);
                    $na = self::name($pdo, $a); $nb = self::name($pdo, $b);
                    $st[] = $s($t, 'Both stay public until this is answered.' . $who . ' Open them: /listing/view.php?id=' . $a . ' and /listing/view.php?id=' . $b . '.', ['form', 'eng_identity:' . $id, 'Answer it', [
                        ['do', 'What to do', 'select', 'keep_a', [['keep_a', 'Merge: keep ' . $na . ' (#' . $a . ')'], ['keep_b', 'Merge: keep ' . $nb . ' (#' . $b . ')'], ['apart', 'Keep apart: two businesses'], ['lead', 'Make a sales lead: call to ask'], ['task', 'Make an admin task']]],
                        ['to', 'Admin task for', 'select', '', $staff]]]);
                    break;
                case 'identity_mass':
                    $st[] = $s($t, 'The recheck stopped in this ZIP for now; nothing merged yet.', ['form', 'eng_mass:' . $id, 'Decide', [['do', 'What to do', 'select', 'ok', [['ok', 'OK: carry on merging there'], ['hold', 'Hold: send them to the identity queue']]]]]);
                    break;
                case 'service':
                    $st[] = $s($t, 'Its checks are paused until you decide.', ['form', 'eng_service:' . $id, 'Decide', [['do', 'What to do', 'select', !empty($d['lifted']) ? 'reactivate' : 'daily', [['reactivate', 'Reactivate it (then half budget for 14 days)'], ['daily', 'Keep it held, check daily'], ['weekly', 'Keep it held, check weekly'], ['stop', 'Keep it held, stop checking']]]]]);
                    break;
                case 'closure':
                    $lid = (int) ($d['id'] ?? 0);
                    $st[] = $s($t, 'Open it: /listing/view.php?id=' . $lid . '. Answer from a visit, a photo of its sign or its owner.' . $who, ['form', 'eng_closure:' . $id, 'Answer it', [['do', 'What we found', 'select', 'open', [['open', 'Still open: clear the notice'], ['closed', 'Closed: our team confirmed it (it stays findable, marked Closed)'], ['task', 'Make an admin task']]],
                        ['note', 'How we know (a visit, the sign, the owner)', 'text', ''], ['to', 'Admin task for', 'select', '', $staff]]]);
                    break;
                case 'site':
                    $st[] = $s($t, 'Reactivate only once the site allows us (its owner said so, or its terms changed).', ['form', 'eng_site:' . $id, 'Decide', [['do', 'What to do', 'select', 'keep', [['keep', 'Keep it held'], ['reactivate', 'Reactivate it: read it again']]]]]);
                    break;
            }
        }
        foreach (self::intakeGroups($pdo) as $k => [$n, $text, $publish]) {
            $st[] = $s($n . ' finds out of options: ' . $text, 'The engine retries them on the ladder; answer here to settle them now.', $publish ? ['do', 'eng_intake:' . $k, 'List them anyway'] : ['tool', '/admin/listings/intake?reason=' . rawurlencode((string) $k)]);
        }
        return $st ?: [$s('Nothing waits on a person', 'The case closes by itself.', ['resolve'])];
    }

    /** Pulse::manage for engine:person. Returns what to say. */
    public static function pulseDo(PDO $pdo, string $what, array $a, int $uid, string $who): string
    {
        if (!preg_match('/^eng_(identity|mass|service|site|intake|closure):([a-z0-9_]+)$/', $what, $m)) throw new InvalidArgumentException('Unknown step.');
        if ($m[1] === 'intake') {
            require_once __DIR__ . '/crawler/AutoImport.php';
            $ids = [];
            $st = $pdo->query("SELECT id, raw_payload, created_at FROM " . Database::t('crawler_raw_index') . " WHERE status = 'staged' AND payload_type = 'listing' ORDER BY id DESC LIMIT 3000");
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $c = json_decode((string) $r['raw_payload'], true); if (is_array($c) && AutoImport::exhausted($c, (string) $r['created_at']) && AutoImport::reason($c)['key'] === $m[2] && !empty(AutoImport::reason($c)['publish'])) $ids[] = (int) $r['id']; }
            $r = AutoImport::quickApprove($pdo, array_slice($ids, 0, 200), $uid);   // each still through the identity check (IntakeStager::approve)
            return $r['approved'] . ' listed' . ($r['skipped'] ? ', ' . count($r['skipped']) . ' left with their reason (may already be listed, no category)' : '') . '.';
        }
        $step = self::step($pdo, (int) $m[2]);
        if (!$step || $step['status'] !== 'open') throw new InvalidArgumentException('That step was already answered.');
        $d = $step['data']; $do = (string) ($a['do'] ?? '');
        require_once __DIR__ . '/ListingIdentity.php';
        switch ($m[1]) {
            case 'identity':
                $x = (int) ($d['a'] ?? 0); $y = (int) ($d['b'] ?? 0);
                if ($do === 'keep_a' || $do === 'keep_b') {
                    [$keep, $drop] = $do === 'keep_a' ? [$x, $y] : [$y, $x];
                    ListingIdentity::merge($pdo, $keep, $drop, 'Merged by ' . ($who ?: 'staff') . ' from the identity queue', $uid, 'person', true);
                    self::done($pdo, (int) $step['id'], 'Merged into #' . $keep, $uid);
                    return 'Merged: #' . $drop . ' now opens #' . $keep . '. Undo is in Data cleanup\'s identity ledger.';
                }
                if ($do === 'apart') { ListingIdentity::different($pdo, $x, $y, $uid); self::done($pdo, (int) $step['id'], 'Kept apart', $uid); return 'Kept apart, for good: no check offers them again.'; }
                if ($do === 'lead') {
                    require_once __DIR__ . '/Leads.php';
                    [$keep] = ListingIdentity::keeper($pdo, $x, $y);
                    $rep = Leads::route($pdo, $keep, 'crawler');
                    try { $pdo->prepare("UPDATE " . Database::t('prospects') . " SET notes = CONCAT(?, COALESCE(notes, '')) WHERE entity_id = ?")->execute(['Ask: is this the same business as #' . ($keep === $x ? $y : $x) . ' (' . self::name($pdo, $keep === $x ? $y : $x) . ')? (identity queue)' . "\n", $keep]); } catch (Throwable) {}
                    $pdo->prepare('UPDATE engine_steps SET data = ?, assigned_to = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?')->execute([json_encode($d + ['lead' => $keep, 'lead_at' => gmdate('Y-m-d H:i:s')]), $rep ?: null, (int) $step['id']]);
                    return 'A sales lead now: #' . $keep . ' is on ' . ($rep ? self::staffName($pdo, $rep) . '\'s' : 'the territory\'s') . ' list with the question; the call\'s outcome answers this step.';
                }
                if ($do === 'task') {
                    $to = (int) ($a['to'] ?? 0);
                    if ($to <= 0) throw new InvalidArgumentException('Choose who it\'s for.');
                    $pdo->prepare('UPDATE engine_steps SET assigned_to = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?')->execute([$to, (int) $step['id']]);
                    return 'An admin task for ' . self::staffName($pdo, $to) . ', done from this case.';
                }
                throw new InvalidArgumentException('Choose what to do.');
            case 'closure':
                $lid = (int) ($d['id'] ?? 0); $note = trim((string) ($a['note'] ?? ''));
                require_once __DIR__ . '/SuggestionActions.php';
                if ($do === 'open') {
                    $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key IN ('closed_signal', 'still_open_ask')")->execute([$lid]);
                    require_once __DIR__ . '/ListingConfidence.php'; ListingConfidence::refresh($pdo, $lid);
                    self::done($pdo, (int) $step['id'], 'Still open' . ($note !== '' ? ': ' . $note : ''), $uid);
                    return 'Marked still open: the notice is gone.';
                }
                if ($do === 'closed') {
                    if ($note === '') throw new InvalidArgumentException('Say how we know it closed (a visit, its sign, the owner).');
                    SuggestionActions::markClosed($pdo, $lid, $uid, 0, 'Our team: ' . $note);
                    $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = 'still_open_ask'")->execute([$lid]);
                    self::done($pdo, (int) $step['id'], 'Closed: ' . $note, $uid);
                    return 'Marked Closed: it stays findable, with "Reopened? Tell us".';
                }
                if ($do === 'task') {
                    $to = (int) ($a['to'] ?? 0);
                    if ($to <= 0) throw new InvalidArgumentException('Choose who it\'s for.');
                    $pdo->prepare('UPDATE engine_steps SET assigned_to = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?')->execute([$to, (int) $step['id']]);
                    return 'An admin task for ' . self::staffName($pdo, $to) . ', done from this case.';
                }
                throw new InvalidArgumentException('Choose what we found.');
            case 'mass':
                if ($do === 'ok') { require_once __DIR__ . '/SearchIndex.php'; SearchIndex::setState($pdo, 'identity:town_ok:' . (string) ($d['zip'] ?? ''), gmdate('c')); self::done($pdo, (int) $step['id'], 'OK by ' . $who, $uid); return 'OK: the next recheck carries on there.'; }
                self::done($pdo, (int) $step['id'], 'Held by ' . $who, $uid); return 'Held: its pairs go to the identity queue on the next run.';
            case 'service':
                require_once __DIR__ . '/ServiceHealth.php';
                $iid = (int) ($d['issue'] ?? 0);
                if ($do === 'reactivate') { ServiceHealth::resolve($pdo, $iid, $uid, 'Reactivated by ' . ($who ?: 'staff') . ' (decisions/0164 §6.1)'); self::done($pdo, (int) $step['id'], 'Reactivated', $uid); return 'Reactivated: it returns at half budget for 14 days.'; }
                $every = ['daily' => 1440, 'weekly' => 10080][$do] ?? 0;
                $pdo->prepare('UPDATE service_issues SET probe_every_min = ?, next_probe_at = ' . ($every ? 'UTC_TIMESTAMP() + INTERVAL ' . $every . ' MINUTE' : 'NULL') . ', first_at = UTC_TIMESTAMP() WHERE id = ?')->execute([$every ?: 1440, $iid]);
                self::done($pdo, (int) $step['id'], $every ? 'Held, checked ' . $do : 'Held, checks stopped', $uid);
                return $every ? 'Held; its status is checked ' . $do . ', and you\'ll be asked again in 3 days if it\'s still refused.' : 'Held; no more checks until someone Reactivates it on its card.';
            case 'site':
                if ($do === 'reactivate') { self::done($pdo, (int) $step['id'], 'Reactivated by ' . $who, $uid); return 'Reactivated: its readers take it up on their next turn.'; }
                $pdo->prepare("UPDATE engine_steps SET status = 'held', answer = ?, done_by = ?, done_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP() WHERE id = ?")->execute(['Kept held by ' . $who, $uid ?: null, (int) $step['id']]);
                return 'Kept held. It stays off the readers\' lists; Reactivate it from Outside services → Sites held when it allows us.';
        }
        throw new InvalidArgumentException('Unknown step.');
    }

    /** A sales lead's call answers its step (Sales::log's outcome); a claim on the call ends it. */
    private static function settleLeads(PDO $pdo): void
    {
        try {
            foreach ($pdo->query("SELECT id, data FROM engine_steps WHERE status = 'open' AND kind = 'identity' AND data LIKE '%\"lead\"%' LIMIT 200")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $d = json_decode((string) $r['data'], true) ?: [];
                $st = $pdo->prepare('SELECT outcome, staff_id FROM ' . Database::t('prospect_log') . ' WHERE entity_id = ? AND created_at >= ? ORDER BY id DESC LIMIT 1');
                $st->execute([(int) $d['lead'], (string) $d['lead_at']]);
                if ($o = $st->fetch(PDO::FETCH_ASSOC)) self::done($pdo, (int) $r['id'], 'The call: ' . $o['outcome'], (int) ($o['staff_id'] ?? 0));
            }
        } catch (Throwable) {}
    }

    private static function name(PDO $pdo, int $id): string
    {
        $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([$id]);
        return (string) ($st->fetchColumn() ?: '#' . $id);
    }

    private static function staffName(PDO $pdo, int $uid): string
    {
        try { $st = $pdo->prepare('SELECT display_name FROM users WHERE id = ?'); $st->execute([$uid]); return (string) ($st->fetchColumn() ?: 'staff #' . $uid); } catch (Throwable) { return 'staff #' . $uid; }
    }

    private static function staffChoices(PDO $pdo): array
    {
        $out = [['', 'Nobody (choose for an admin task)']];
        try { foreach ($pdo->query("SELECT s.user_id, s.name AS display_name FROM " . Database::t('staff_accounts') . " s WHERE s.status = 'active' AND s.user_id IS NOT NULL ORDER BY s.name LIMIT 100")->fetchAll(PDO::FETCH_ASSOC) as $r) $out[] = [(string) $r['user_id'], (string) $r['display_name']]; } catch (Throwable) {}
        return $out;
    }
}
