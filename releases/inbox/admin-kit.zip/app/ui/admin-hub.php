<?php
// app/ui/admin-hub.php — the admin dashboard's areas (decisions/0078). Each entry of the admin menu is one page whose
// tools are its sections, in a row of tabs at the top, switching in place like the member dashboard's (and like
// Manage listings, admin/listings.php, where the pattern started):
//
//   tv_admin_start('search', 'Search', 'What search learns…');      // checks access, opens the admin frame
//   tv_admin_hub('Search tools', [
//       'workbench' => ['label' => 'Workbench', 'url' => '/admin/search-misses.php', 'badge' => 3],   // a tool, embedded
//       'overview'  => ['label' => 'Overview', 'html' => '<p>…</p>'],                                   // drawn here
//   ]);
//   tv_admin_end();
//
// A tool section shows the tool's own page in its embedded view (no admin frame, no back button), loaded the first time
// its tab opens and filling the page below the tabs, so its forms and pop-ups work as they do on their own page. The
// open section is kept in the address (#workbench), so Back and a bookmark return to it.
declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
header('Content-Type: text/html; charset=utf-8');   // bootstrap defaults to JSON
require_once __DIR__ . '/admin-crawler.php';
require_once __DIR__ . '/../lib/Roles.php';

/**
 * Staff only. Returns [user, ctx]: an admin is put in their Admin role here (the admin pages are that role's
 * dashboard); staff who add and edit listings (regional managers) come in with the context they have.
 */
function tv_admin_require(PDO $pdo): array
{
    $me = tv_listing_staff_require($pdo);   // "Admin only", and stops, for anyone else
    $uid = (int) $me['id'];
    $ctx = Roles::current($pdo, $uid);
    if ($ctx['kind'] !== 'admin') { try { $ctx = Roles::setCurrent($pdo, $uid, 'admin'); } catch (Throwable) {} }
    return [$me, $ctx];
}

/**
 * Opens an admin area page: the admin menu with this area lit, the title and a line about it. $crumbs (Jason,
 * 2026-10-16): where the page sits, [label, url|null] each, shown top right ("E-Commerce › Orders › Order #5");
 * a tool shown inside its area's tab (embed=1) leaves its title and crumbs to the area page around it.
 */
function tv_admin_start(string $area, string $title, string $intro = '', ?PDO $pdo = null, array $crumbs = []): void
{
    $embedded = !empty($_GET['embed']) || (function_exists('tv_embedded') && tv_embedded());   // still in its frame after a form reloads it
    require_once __DIR__ . '/section-rails.php';
    tv_page_start($title, ['wide' => true, 'no_crumbs' => true, 'description' => 'Traversence admin: ' . $title . '.',
        'rail' => tv_admin_rail($area), 'rail_label' => 'Admin', 'active' => $area]);
    ?>
<style>
  .hb-top{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:.3rem 1rem}
  .hb-crumbs{display:flex;flex-wrap:wrap;align-items:baseline;gap:.4rem;font-size:1rem;color:var(--tv-meta,#5E4F3C);margin-left:auto}
  .hb-crumbs a{color:#92400E;text-decoration:underline;font-weight:600}.hb-crumbs b{color:#3E2B1F}
  .hb-h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.5rem,2.6vw,1.9rem);line-height:1.15;margin:0;color:#3E2B1F}
  .hb-intro{font-size:0.98rem;color:#5C4632;margin-top:.3rem;max-width:70rem}
  .hb-tabs{display:flex;gap:.35rem;overflow-x:auto;padding:.2rem 0 .5rem;margin-top:.5rem;scrollbar-width:thin;position:sticky;top:0;z-index:5;background:inherit}
  .hb-tab{flex:0 0 auto;display:inline-flex;align-items:center;gap:.35rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.38rem .8rem;font-size:0.93rem;font-weight:600;text-decoration:none;white-space:nowrap;cursor:pointer}
  .hb-tab.on{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}
  .hb-tab b{background:#D97706;color:#fff;border-radius:999px;font-size:0.78rem;padding:.05rem .4rem}
  [data-hsec][hidden]{display:none!important}
  .hb-frame{width:100%;border:0;display:block;background:transparent;min-height:15rem;height:15rem}
  .hb-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(15rem,100%),1fr));gap:.6rem;margin-top:.6rem}
  .hb-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .85rem}
  .hb-card.hot{border-color:#F3D9A4;background:#FFF8EA}
  .hb-card .num{font:700 1.6rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;line-height:1.1}
  .hb-card .lab{font-size:0.93rem;color:#5C4632;margin-top:.15rem}
  .hb-h{font:700 1.1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:1.1rem 0 0}
  .hb-go{display:inline-block;margin-top:.35rem;font-size:0.9rem;font-weight:700;color:#92400E;text-decoration:underline;cursor:pointer}
  .hb-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem .7rem;font-size:1rem;color:#3E2B1F}
  .hb-b{display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:0.9rem;border-radius:.6rem;padding:.38rem .75rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;text-decoration:none;cursor:pointer;white-space:nowrap}
  .hb-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}
  .hb-b.no{color:#991B1B;border-color:#E5B4B4}
  .hb-row{display:flex;justify-content:space-between;align-items:center;gap:.6rem;padding:.55rem .1rem;border-top:1px solid #EADFC4}
  .hb-row:first-child{border-top:0}
  .hb-row small{display:block;color:var(--tv-meta,#5E4F3C);font-size:0.88rem}
  .hb-nm{font-weight:700;color:#92400E;text-decoration:underline;cursor:pointer;background:none;border:0;padding:0;text-align:left;font-size:inherit}
  .hb-pill{display:inline-block;font-size:0.78rem;border-radius:999px;padding:.05rem .45rem;background:#EADFC4;color:#5C4632;margin-left:.3rem;font-weight:600;white-space:nowrap}
  .hb-pill.ok{background:#DCEFE5;color:#1F5C43}.hb-pill.red{background:#FEE2E2;color:#991B1B}
  .hb-steps{margin:.4rem 0 0;padding:0;list-style:none}
  .hb-steps li{padding:.5rem .7rem;border:1px solid #EADFC4;background:#FFFBF2;border-radius:.7rem;margin-top:.35rem;font-size:0.98rem;color:#3E2B1F}
  .hb-steps a{color:#92400E;text-decoration:underline;font-weight:600}
  .hb-dl{display:grid;grid-template-columns:minmax(8rem,14rem) 1fr;gap:.35rem .8rem;font-size:0.98rem;margin-top:.4rem}
  .hb-dl dt{color:var(--tv-meta,#5E4F3C)}.hb-dl dd{margin:0;color:#3E2B1F;min-width:0;overflow-wrap:anywhere}
  @media (max-width:767px){ .hb-dl{grid-template-columns:1fr;gap:.05rem} .hb-dl dd{margin-bottom:.35rem} }
</style>
<?php if (!$embedded) { echo tv_admin_bar(); echo tv_admin_archived(); } ?>
<?php if (($crumbs || ($_GET['sec'] ?? '') !== '') && $embedded): /* inside a workspace tab, which titles it */ ?>
<?php elseif ($crumbs): ?>
<div class="hb-top"><h1 class="hb-h1" data-hub-title><?= tv_e($title) ?></h1>
  <nav class="hb-crumbs" aria-label="Where you are"><?php foreach ($crumbs as $i => [$lab, $url]): ?><?= $i ? '<span aria-hidden="true">›</span>' : '' ?><?php if ($url !== null && $i < count($crumbs) - 1): ?><a href="<?= tv_e($url) ?>"><?= tv_e($lab) ?></a><?php else: ?><b<?= $i === count($crumbs) - 1 ? ' data-hub-crumb aria-current="page"' : '' ?>><?= tv_e($lab) ?></b><?php endif; ?><?php endforeach; ?></nav></div>
<?php else: ?>
<h1 class="hb-h1"><?= tv_e($title) ?></h1>
<?php endif; ?>
<?php if ($intro !== '' && !(($_GET['sec'] ?? '') !== '' && $embedded)): ?><p class="hb-intro"><?= $intro ?></p><?php endif;
}

/**
 * An old admin page opened on its own (decisions/0109 A9): archived, out of the menus, still there by its address and
 * the site map. A line at the top says where its work is now.
 */
function tv_admin_archived(): string
{
    require_once __DIR__ . '/../admin/AdminModules.php';
    $p = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    if ($p === '/admin/w.php') { $w = (string) ($_GET['w'] ?? ''); $to = isset(Modules::all()[$w]) ? [$w, ''] : null; }
    else $to = Modules::archive()[$p] ?? null;
    if (!$to) return '';
    $m = Modules::module($to[0]);
    if (!$m) return '';
    $label = $to[1] !== '' ? $m['sections'][$to[1]]['label'] . ' in ' . $m['name'] : $m['name'];
    return '<p class="ak-arch" style="background:#FEF3C7;border:1px solid #F3D9A4;border-radius:.6rem;padding:.5rem .8rem;font-size:.92rem;margin:0 0 .6rem">This page is archived: it\'s kept for reference and isn\'t in the menus. Its work is now in <a style="color:#92400E;text-decoration:underline;font-weight:700" href="'
        . tv_e(Modules::url($to[0], $to[1])) . '">' . tv_e($label) . '</a>.</p>';
}

/**
 * The shortcut bar across the top of the admin (Jason, 2026-10-21): Dashboards, Operations, Security, Users, Content,
 * Logs, System, each opening the workspaces and tools it groups. The 11 workspaces stay in the menu on the left; the
 * bar shows only what the person's role opens.
 */
function tv_admin_bar(): string
{
    require_once __DIR__ . '/../lib/Workspaces.php';
    require_once __DIR__ . '/../lib/StaffLogin.php';
    $pdo = Database::connection();
    $staff = StaffLogin::inSession($pdo) ?: null;
    $opens = Workspaces::opens($staff, $pdo);
    $ws = fn (string $k, string $hash = '', string $label = '') => in_array($k, $opens, true)
        ? [$label !== '' ? $label : Workspaces::ALL[$k][0] . '. ' . Workspaces::ALL[$k][1], '/admin/' . $k . ($hash !== '' ? '/' . ltrim($hash, '#') : '')] : null;
    $area = fn (string $a, string $label, string $url) => Workspaces::allowsArea($staff, $a, $pdo) ? [$label, $url] : null;
    $menus = [
        'Dashboards' => [$ws('dashboard'), $ws('dashboard', '#stream', 'Pulse stream'), $ws('insights')],   // Pulse is in the Dashboard (2026-11-12)
        'Operations' => [$ws('local'), $ws('market'), $ws('backoffice'), $ws('growth'), $ws('concierge')],
        'Security' => [$ws('social', '#reports', 'Reports'), $ws('social', '#standing', 'Standing'), $area('people', 'Staff logins', '/admin/backoffice/people'), $area('settings', 'Logs', '/admin/config/logs')],
        'Users' => [$area('people', 'Members', '/admin/backoffice/people'), $area('people', 'Staff & roles', '/admin/backoffice/people'), $area('people', 'Levels & departments', '/admin/backoffice/levels'), ['Your staff profile', '/admin/staff-profile.php']],
        'Content' => [$ws('explore'), $ws('local', '#listings', 'Listings'), $ws('local', '#review', 'Review')],
        'Logs' => [$area('settings', 'Logs', '/admin/config/logs')],
        'System' => [$ws('insights', '#crawler', 'Crawler'), $ws('config')],
    ];
    require_once __DIR__ . '/app-shell.php';   // tv_icon()
    // one compact button beside the page title; its list opens downward, grouped (Jason, 2026-10-21)
    $h = '<details class="ab"><summary aria-label="Admin shortcuts">' . tv_icon('compass', 'ab-svg') . '<span>Shortcuts</span></summary><nav class="ab-list" aria-label="Admin shortcuts">';
    foreach ($menus as $name => $links) {
        $links = array_values(array_filter($links));
        if (!$links) continue;
        $h .= '<div class="ab-g"><b>' . tv_e($name) . '</b>';
        foreach ($links as [$l, $u]) $h .= '<a href="' . tv_e($u) . '">' . tv_e($l) . '</a>';
        $h .= '</div>';
    }
    return $h . '</nav></details><style>'
        . '.ab{float:right;position:relative;z-index:35;margin:.15rem 0 .4rem .6rem}'
        . '.ab>summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;gap:.35rem;border:1px solid #CBB98D;background:#FFF8EA;color:#3E2B1F;border-radius:999px;padding:.35rem .75rem;font:700 .92rem system-ui,sans-serif}'
        . '.ab>summary::-webkit-details-marker{display:none}.ab>summary::after{content:"▾";color:#8A7355;font-size:.8em}'
        . '.ab[open]>summary{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}'
        . '.ab-svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}'
        . '.ab-list{position:absolute;right:0;top:calc(100% + .35rem);width:min(20rem,calc(100vw - 6px));max-height:70vh;overflow-y:auto;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.7rem;box-shadow:0 16px 32px -14px rgba(0,0,0,.4);padding:.4rem .6rem}'
        . '.ab-g{padding:.35rem 0;border-top:1px solid #EADFC4}.ab-g:first-child{border-top:0}'
        . '.ab-g b{display:block;font:700 .75rem system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;color:var(--tv-meta,#5E4F3C);margin-bottom:.1rem}'
        . '.ab-g a{display:block;color:#92400E;text-decoration:underline;font:600 .95rem system-ui,sans-serif;padding:.22rem 0}'
        . '@media (max-width:767px){.ab-list{position:fixed;left:3px;right:3px;width:auto;top:auto}}</style>'
        . '<script>document.addEventListener("click",function(e){var d=document.querySelector(".ab[open]");if(d&&!d.contains(e.target))d.removeAttribute("open")});document.addEventListener("keydown",function(e){if(e.key==="Escape"){var d=document.querySelector(".ab[open]");if(d)d.removeAttribute("open")}})</script>';
}

function tv_admin_end(): void
{
    tv_page_end();
}

/** A tool's address for showing it inside a workspace or area tab: ?embed=1 added before any #section. */
function tv_admin_embed_url(string $u): string
{
    $h = ''; if (($i = strpos($u, '#')) !== false) { $h = substr($u, $i); $u = substr($u, 0, $i); }
    return $u . (str_contains($u, '?') ? '&' : '?') . 'embed=1' . $h;
}

/** The section tabs and their sections. $secs: key => ['label', 'url' (an embedded tool) or 'html' (drawn), 'badge']. */
function tv_admin_hub(string $label, array $secs): void
{
    $e = 'tv_e';
    // a workspace shows one section of an area page as its own tab (?sec=, embedded): just that section, no tab row
    $one = (string) ($_GET['sec'] ?? '');
    if ($one !== '' && isset($secs[$one]) && tv_embedded()) {
        $s = $secs[$one];
        if (!empty($s['url'])) { $u = (string) $s['url']; echo '<script>location.replace(' . json_encode($u . (str_contains($u, '?') ? '&' : '?') . 'embed=1') . ')</script>'; return; }
        echo '<section data-hsec="' . $e($one) . '">' . ($s['html'] ?? '') . '</section>';
        return;
    }
    ?>
<nav class="hb-tabs" data-more role="tablist" aria-label="<?= $e($label) ?>">
  <?php foreach ($secs as $k => $s): $b = (int) ($s['badge'] ?? 0); ?><a class="hb-tab" role="tab" href="#<?= $e($k) ?>" data-hgo="<?= $e($k) ?>"><?= $e($s['label']) ?><?= $b ? '<b>' . ($b > 99 ? '99+' : $b) . '</b>' : '' ?></a><?php endforeach; ?>
</nav>
<?php foreach ($secs as $k => $s): ?>
<section data-hsec="<?= $e($k) ?>" hidden><?php if (!empty($s['url'])): $u = (string) $s['url']; ?><iframe class="hb-frame" data-no-back data-fit title="<?= $e($s['label']) ?>" data-src="<?= $e(tv_admin_embed_url($u)) ?>"></iframe><?php else: echo $s['html'] ?? ''; endif; ?></section>
<?php endforeach; ?>
<script>
(function () {
  var tabs = [].slice.call(document.querySelectorAll('.hb-tab')), secs = [].slice.call(document.querySelectorAll('[data-hsec]'));
  var first = secs.length ? secs[0].getAttribute('data-hsec') : '', baseTitle = document.title;
  // the tool grows to fit what's in it (TvAsk.fitFrame): one scroll bar, the page's, and its pop-ups open over the
  // whole page (js/tv-ask.js), never a frame inside a frame
  function size(f) { if (f && window.TvAsk && TvAsk.fitFrame) TvAsk.fitFrame(f); }
  function show(k) {
    if (!secs.some(function (s) { return s.getAttribute('data-hsec') === k; })) k = first;
    secs.forEach(function (s) { s.hidden = s.getAttribute('data-hsec') !== k; });
    tabs.forEach(function (t) { var on = t.getAttribute('data-hgo') === k; t.classList.toggle('on', on); t.setAttribute('aria-selected', on ? 'true' : 'false'); if (on && t.scrollIntoView) t.scrollIntoView({ block: 'nearest', inline: 'nearest' }); });
    var sec = secs.filter(function (s) { return s.getAttribute('data-hsec') === k; })[0], f = sec && sec.querySelector('iframe');
    if (f && !f.getAttribute('src')) f.setAttribute('src', f.getAttribute('data-src'));
    size(f);
    var on = tabs.filter(function (t) { return t.getAttribute('data-hgo') === k; })[0], h = document.querySelector('[data-hub-title]'), c = document.querySelector('[data-hub-crumb]');
    if (on && h) { var lab = on.firstChild && on.firstChild.nodeType === 3 ? on.firstChild.nodeValue.trim() : on.textContent.trim(); h.textContent = lab; if (c) c.textContent = lab; document.title = lab + ' · ' + baseTitle; }
    document.dispatchEvent(new CustomEvent('tv-hub-show', { detail: k }));
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-hgo]'); if (!a) return;
    e.preventDefault(); var k = a.getAttribute('data-hgo');
    if (location.hash !== '#' + k) history.pushState(null, '', '#' + k);
    show(k); window.scrollTo(0, 0);
  });
  window.addEventListener('popstate', function () { show(location.hash.slice(1)); });
  window.tvHubShow = show;
  show(location.hash.slice(1));
})();
</script>
<?php
}
