<?php
// app/lib/Releases.php — planned, phased releases (decisions/0145 §5, §6; site-audit/phase-5-releases.md). A release is a
// zip of files at their real paths (app/…, website/…, trvgo/…, as every delivery), uploaded on System Configuration →
// Releases or dropped on the site manager on staging (decisions/0159 §5), which approve its plan (from its release.json)
// and put it on staging at once. From there:
//   planned   the zip is in, its files listed; the plan is read (its release.json, if any: title, why, proposals, switch)
//   approved  the plan is approved (title, why, switch, how it advances)
//   staged    its files are on staging.trvgo.us, its migrations ran there, and the checks ran: they passed, or say what failed
//   vetted    signed off after staging passed (since decisions/0159 §5, by Publish or Schedule itself, once someone has
//             opened it on staging: that look is the review and Publish is the sign-off)
//   scheduled waiting for its date and time
//   live      its files are on the live site, the previous copy of each kept; step 1 staff and test accounts, 2 a share of
//             members, 3 everyone (its switch: Switches). Each step advances on schedule (only when its checks are clean,
//             inside the release window) or on Publish next step. A failed check pauses it and tells whoever runs it.
//   off       Turn off: its switch off for everyone, at once (the files stay)
//   rolled_back  Roll back: the previous copy of every file put back, its new files removed (migrations only ever add, so
//             no data is touched)
// An urgent fix can be published at once with a reason; it's checked on live straight after and recorded like any other.
// Its files and the previous copies are kept in app/storage/releases/<id>/ (never served, never synced). Once the plan is
// approved, the release's zip and its rollback zip can be downloaded, for an upload by FTP instead.
// Each change is written to git (deliveries/releases/, DocsRepo with GITHUB_DOCS_TOKEN) and shows as a Pulse case.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Releases
{
    /** The four permissions (decisions/0145 §5): Founder only until a role is given one (System Configuration → Permissions). */
    public const PERMS = [
        'releases.publish'  => 'Releases: upload, approve, stage, sign off, publish and step on',
        'releases.schedule' => 'Releases: schedule a release',
        'releases.turn_off' => 'Releases: turn a release off (its switch, for everyone)',
        'releases.rollback' => 'Releases: roll a release back (its files)',
    ];
    public const STATES = [
        'planned' => 'Planned', 'approved' => 'Plan approved', 'staged' => 'On staging', 'vetted' => 'Vetted', 'scheduled' => 'Scheduled',
        'live' => 'Live', 'off' => 'Turned off', 'rolled_back' => 'Rolled back', 'withdrawn' => 'Withdrawn',
    ];
    public const STEPS = [1 => 'Staff and test accounts', 2 => 'A share of members', 3 => 'Everyone'];
    public const DEFAULTS = ['share_pct' => 25, 'members_after_h' => 24, 'everyone_after_h' => 72, 'days' => '1,2,3,4,5', 'from_h' => 6, 'to_h' => 18, 'tz' => 'America/Phoenix'];
    private const TOPS = ['app', 'website', 'trvgo'];
    private const NEVER = ['bootstrap-super-admin.php', 'error_log'];
    private const NEVER_DIRS = ['_notes', '_SUPPORT', '_pending', '_concepts', '_gsdata_'];
    private const MAX_FILES = 400;
    private const CHECK_USER = 'tv-releases';

    private static bool $made = false;
    /** While the staging bar acts (website/api/release-bar.php): the permissions its signed token carries, from when it was given. */
    private static ?array $grant = null;

    public static function ensure(PDO $pdo): void
    {
        if (self::$made) return;
        $pdo->exec("CREATE TABLE IF NOT EXISTS site_releases (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(160) NOT NULL DEFAULT '', why TEXT NULL, proposals VARCHAR(255) NOT NULL DEFAULT '',
            switch_key VARCHAR(64) NOT NULL DEFAULT '', advance VARCHAR(10) NOT NULL DEFAULT 'schedule',
            state VARCHAR(20) NOT NULL DEFAULT 'planned', step TINYINT NOT NULL DEFAULT 0, step_at DATETIME NULL, paused TINYINT NOT NULL DEFAULT 0,
            schedule_at DATETIME NULL, urgent TEXT NULL, zip_name VARCHAR(190) NOT NULL DEFAULT '',
            files MEDIUMTEXT NULL, checks MEDIUMTEXT NULL, checks_ok TINYINT NULL, log MEDIUMTEXT NULL, tz VARCHAR(64) NOT NULL DEFAULT '',
            plan_by INT NULL, plan_at DATETIME NULL, staged_at DATETIME NULL, vetted_by INT NULL, vetted_at DATETIME NULL, live_at DATETIME NULL,
            created_by INT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
            KEY state (state)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS site_release_settings (k VARCHAR(40) NOT NULL PRIMARY KEY, v TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        self::$made = true;
    }

    // ---- who may -------------------------------------------------------------------------------------------------------

    /** [allowed, why not] for one of the four permissions. */
    public static function can(string $perm): array
    {
        if (!isset(self::PERMS[$perm])) return [false, 'Not a release permission.'];
        if (self::$grant !== null) return in_array($perm, self::$grant, true) ? [true, ''] : [false, 'Your role can\'t do this (System Configuration → Permissions).'];
        if (PHP_SAPI === 'cli') return [true, ''];   // the scheduled job acts on what a person already approved
        require_once __DIR__ . '/../admin/Access.php';
        [$ok, $why] = Access::can($perm, ['min' => 'founder', 'depts' => []]);
        return [$ok, $ok ? '' : (($why ?: 'Your role can\'t do this') . '. It\'s given in System Configuration → Permissions.')];
    }

    private static function need(string $perm): void
    {
        [$ok, $why] = self::can($perm);
        if (!$ok) throw new RuntimeException($why);
    }

    // ---- settings: the rollout defaults and the release window ---------------------------------------------------------

    public static function settings(PDO $pdo): array
    {
        self::ensure($pdo);
        $out = self::DEFAULTS;
        try { foreach ($pdo->query('SELECT k, v FROM site_release_settings')->fetchAll(PDO::FETCH_KEY_PAIR) as $k => $v) if (array_key_exists($k, $out)) $out[$k] = is_int(self::DEFAULTS[$k]) ? (int) $v : (string) $v; } catch (Throwable) {}
        return $out;
    }

    public static function saveSettings(PDO $pdo, array $in): string
    {
        self::need('releases.schedule');
        $s = self::settings($pdo);
        $s['share_pct'] = max(1, min(99, (int) ($in['share_pct'] ?? $s['share_pct'])));
        $s['members_after_h'] = max(1, min(720, (int) ($in['members_after_h'] ?? $s['members_after_h'])));
        $s['everyone_after_h'] = max(1, min(720, (int) ($in['everyone_after_h'] ?? $s['everyone_after_h'])));
        $days = array_values(array_unique(array_filter(array_map('intval', (array) ($in['days'] ?? explode(',', $s['days']))), fn ($d) => $d >= 0 && $d <= 6)));
        if (!$days) throw new RuntimeException('Choose at least one day releases may go live on schedule.');
        sort($days); $s['days'] = implode(',', $days);
        $s['from_h'] = max(0, min(23, (int) ($in['from_h'] ?? $s['from_h'])));
        $s['to_h'] = max(1, min(24, (int) ($in['to_h'] ?? $s['to_h'])));
        if ($s['to_h'] <= $s['from_h']) throw new RuntimeException('The window has to end after it starts.');
        $st = $pdo->prepare('REPLACE INTO site_release_settings (k, v) VALUES (?, ?)');
        foreach (['share_pct', 'members_after_h', 'everyone_after_h', 'days', 'from_h', 'to_h'] as $k) $st->execute([$k, (string) $s[$k]]);
        return 'Saved: members after ' . $s['members_after_h'] . ' h (' . $s['share_pct'] . '%), everyone after ' . $s['everyone_after_h'] . ' h more, inside the window.';
    }

    /** Is it inside the release window now (Arizona time by default)? */
    public static function inWindow(PDO $pdo, ?int $at = null): bool
    {
        $s = self::settings($pdo);
        $d = (new DateTimeImmutable('@' . ($at ?? time())))->setTimezone(new DateTimeZone($s['tz']));
        $h = (int) $d->format('G');
        return in_array((int) $d->format('w'), array_map('intval', explode(',', $s['days'])), true) && $h >= $s['from_h'] && $h < $s['to_h'];
    }

    // ---- where things are ---------------------------------------------------------------------------------------------

    private static function liveRoot(): string { return dirname(__DIR__, 2); }

    public static function dir(int $id): string { return dirname(__DIR__) . '/storage/releases/' . $id; }

    /** Staging's site root (it holds website/, app/, trvgo/ as live does), or null when staging isn't set up. */
    private static function stagingRoot(PDO $pdo): ?string
    {
        require_once __DIR__ . '/StagingSite.php';
        if (!StagingSite::isSetUp($pdo)) return null;
        $s = (array) StagingSite::get($pdo, 'setup');
        $L = StagingSite::layout((string) $s['base']);
        return is_dir($L['root']) ? $L['root'] : null;
    }

    // ---- the record ----------------------------------------------------------------------------------------------------

    public static function get(PDO $pdo, int $id): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM site_releases WHERE id = ?'); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ? self::decode($r) : null;
    }

    /** The newest releases first. */
    public static function all(PDO $pdo, int $limit = 30): array
    {
        self::ensure($pdo);
        return array_map([self::class, 'decode'], $pdo->query('SELECT * FROM site_releases ORDER BY id DESC LIMIT ' . max(1, $limit))->fetchAll(PDO::FETCH_ASSOC));
    }

    private static function decode(array $r): array
    {
        foreach (['files', 'checks', 'log'] as $k) $r[$k] = json_decode((string) ($r[$k] ?? ''), true) ?: [];
        foreach (['id', 'step', 'paused', 'plan_by', 'vetted_by', 'created_by'] as $k) $r[$k] = (int) ($r[$k] ?? 0);
        $r['checks_ok'] = $r['checks_ok'] === null ? null : (bool) (int) $r['checks_ok'];
        return $r;
    }

    private static function save(PDO $pdo, array $r): void
    {
        $cols = ['title', 'why', 'proposals', 'switch_key', 'advance', 'state', 'step', 'step_at', 'paused', 'schedule_at', 'urgent', 'checks_ok', 'tz',
                 'plan_by', 'plan_at', 'staged_at', 'vetted_by', 'vetted_at', 'live_at'];
        $set = []; $vals = [];
        foreach ($cols as $c) { $set[] = "$c = ?"; $vals[] = $r[$c] === null ? null : (is_bool($r[$c]) ? (int) $r[$c] : $r[$c]); }
        foreach (['files', 'checks', 'log'] as $c) { $set[] = "$c = ?"; $vals[] = json_encode($r[$c], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); }
        $vals[] = $r['id'];
        $pdo->prepare('UPDATE site_releases SET ' . implode(', ', $set) . ', updated_at = NOW() WHERE id = ?')->execute($vals);
    }

    private static function note(array &$r, string $msg, int $by): void
    {
        $r['log'][] = ['at' => gmdate('c'), 'by' => $by, 'msg' => $msg];
        if (count($r['log']) > 200) $r['log'] = array_slice($r['log'], -200);
    }

    /** Where it stands, in a line: [text, tone ok|info|bad]. */
    public static function standing(array $r): array
    {
        $st = $r['state'];
        if ($st === 'live' && $r['paused']) return ['Paused at step ' . $r['step'] . ' of 3 (' . self::STEPS[$r['step']] . '): ' . self::lastWord($r), 'bad'];
        return match ($st) {
            'planned' => ['Planned: ' . count($r['files']) . ' files. Approve the plan to go on.', 'info'],
            'approved' => ['Plan approved: put it on staging to check it there.', 'info'],
            'staged' => $r['checks_ok'] ? ['On staging and its checks passed: look at it there, then Publish or Schedule.', 'ok'] : ['On staging, and a check failed: see the checks. Upload a fixed zip as a new release, or put it on staging again.', 'bad'],
            'vetted' => ['Vetted: ready to publish now or on a schedule.', 'ok'],
            'scheduled' => ['Scheduled for ' . self::when((string) $r['schedule_at'], (string) $r['tz']) . '.', 'info'],
            'live' => $r['step'] >= 3 ? ['Live for everyone' . ($r['switch_key'] === '' ? ' (no switch: all at once)' : '') . '.', 'ok']
                : ['Live at step ' . $r['step'] . ' of 3: ' . self::STEPS[$r['step']] . ($r['advance'] === 'schedule' ? '; the next step comes on schedule.' : '; the next step waits for Publish next step.'), 'ok'],
            'off' => ['Turned off: its switch is off for everyone. Its files are still live; Roll back takes them out.', 'bad'],
            'rolled_back' => ['Rolled back: the previous copy of every file is live again.', 'info'],
            'withdrawn' => ['Withdrawn before it went live.', 'info'],
            default => [$st, 'info'],
        };
    }

    private static function lastWord(array $r): string
    {
        $l = end($r['log']);
        return $l ? (string) $l['msg'] : '';
    }

    private static function when(string $utc, string $tz): string
    {
        if ($utc === '') return '';
        try { $z = new DateTimeZone($tz !== '' ? $tz : 'America/Phoenix'); } catch (Throwable) { $z = new DateTimeZone('America/Phoenix'); }
        return (new DateTimeImmutable($utc, new DateTimeZone('UTC')))->setTimezone($z)->format('M j, g:i A T');
    }

    // ---- 1. the upload -------------------------------------------------------------------------------------------------

    /** A path a release may carry: [ok, why not]. */
    public static function pathOk(string $p): array
    {
        if (!preg_match('#^(app|website|trvgo)/[A-Za-z0-9._\-/]+$#', $p) || str_contains($p, '..') || str_contains($p, '//')) return [false, 'not at a real path under app/, website/ or trvgo/'];
        foreach (explode('/', $p) as $seg) {
            if ($seg === '' || $seg[0] === '.') return [false, 'a dotfile (.htaccess, .env): those are delivered by hand, never in a release'];
            if (in_array($seg, self::NEVER_DIRS, true)) return [false, 'a notes folder, never on the server'];
        }
        if (in_array(basename($p), self::NEVER, true)) return [false, 'never delivered'];
        if (str_starts_with($p, 'app/storage/')) return [false, 'app/storage is the site\'s own, never delivered'];
        return [true, ''];
    }

    /** A zip uploaded on the Releases page (the release_zip upload target). Returns what the page shows. */
    public static function fromUpload(PDO $pdo, int $uid, string $zipPath, string $zipName, string $tz = ''): array
    {
        self::need('releases.publish');
        self::ensure($pdo);
        if (!class_exists('ZipArchive')) throw new RuntimeException('The server\'s PHP can\'t open zips (its zip extension is off). Ask Bluehost to turn it on, or send releases by FTP for now.');
        $z = new ZipArchive();
        if ($z->open($zipPath) !== true) throw new RuntimeException('That isn\'t a zip the server can open. Make it again and upload it.');
        $files = []; $refused = []; $plan = [];
        for ($i = 0; $i < $z->numFiles; $i++) {
            $n = (string) $z->getNameIndex($i);
            if ($n === '' || str_ends_with($n, '/') || str_starts_with($n, '__MACOSX/')) continue;
            if ($n === 'release.json') { $plan = json_decode((string) $z->getFromIndex($i), true) ?: []; continue; }
            if (!in_array(strtok($n, '/'), self::TOPS, true)) { $refused[] = $n . ' (not under app/, website/ or trvgo/)'; continue; }
            [$ok, $why] = self::pathOk($n);
            if (!$ok) { $refused[] = $n . ' (' . $why . ')'; continue; }
            $files[$n] = $i;
        }
        if ($refused) { $z->close(); throw new RuntimeException('Not taken: ' . implode('; ', array_slice($refused, 0, 6)) . (count($refused) > 6 ? ' and ' . (count($refused) - 6) . ' more' : '') . '. Take them out of the zip and upload it again.'); }
        if (!$files) { $z->close(); throw new RuntimeException('The zip has no files at app/…, website/… or trvgo/….'); }
        if (count($files) > self::MAX_FILES) { $z->close(); throw new RuntimeException('That\'s ' . count($files) . ' files; a release carries at most ' . self::MAX_FILES . '. Split it into smaller releases.'); }
        $title = trim((string) ($plan['title'] ?? '')) ?: preg_replace('/\.zip$/i', '', $zipName);
        $props = $plan['proposals'] ?? '';
        $props = is_array($props) ? implode(', ', array_map('strval', $props)) : (string) $props;
        $sw = preg_match('/^[a-z0-9_]{2,64}$/', (string) ($plan['switch'] ?? '')) ? (string) $plan['switch'] : '';
        $pdo->prepare('INSERT INTO site_releases (title, why, proposals, switch_key, zip_name, tz, state, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, \'planned\', ?, NOW(), NOW())')
            ->execute([mb_substr($title, 0, 160), mb_substr(trim((string) ($plan['why'] ?? '')), 0, 4000), mb_substr($props, 0, 255), $sw, mb_substr($zipName, 0, 190), $tz, $uid ?: null]);
        $id = (int) $pdo->lastInsertId();
        $dir = self::dir($id);
        if (!is_dir($dir . '/new') && !@mkdir($dir . '/new', 0750, true)) throw new RuntimeException('Couldn\'t make the release\'s folder in app/storage.');
        @file_put_contents(dirname($dir) . '/.htaccess', "Require all denied\n");
        $list = [];
        foreach ($files as $n => $i) {
            $data = $z->getFromIndex($i);
            if ($data === false) { $z->close(); throw new RuntimeException('Couldn\'t read ' . $n . ' from the zip.'); }
            $to = $dir . '/new/' . $n;
            if (!is_dir(dirname($to))) @mkdir(dirname($to), 0750, true);
            file_put_contents($to, $data);
            $list[$n] = ['sha' => hash('sha256', $data), 'size' => strlen($data), 'live_was' => self::liveSha($n)];
        }
        $z->close();
        @copy($zipPath, $dir . '/release.zip');
        $r = self::get($pdo, $id);
        $r['files'] = $list;
        $same = array_filter($list, fn ($f) => $f['live_was'] === $f['sha']);
        self::note($r, 'Uploaded ' . $zipName . ': ' . count($list) . ' files' . ($same ? ' (' . count($same) . ' already the same as live)' : '') . '.', $uid);
        self::save($pdo, $r);
        self::record($pdo, $r);
        return ['id' => $id, 'message' => 'Release #' . $id . ' is in: ' . count($list) . ' files. Read its plan and approve it to go on.'];
    }

    private static function liveSha(string $p): ?string
    {
        $f = self::liveRoot() . '/' . $p;
        return is_file($f) ? hash_file('sha256', $f) : null;
    }

    private static function migrations(array $r): array
    {
        return array_values(array_filter(array_keys($r['files']), fn ($p) => preg_match('#^app/migrations/[^/]+\.sql$#', $p)));
    }

    // ---- the actions -----------------------------------------------------------------------------------------------------

    /** One action on a release, from the page or a Pulse case. Returns the line to show. */
    public static function act(PDO $pdo, int $id, string $what, array $a, int $uid): string
    {
        $r = self::get($pdo, $id);
        if (!$r) throw new RuntimeException('That release isn\'t here.');
        $tz = preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($a['tz'] ?? '')) ? (string) $a['tz'] : '';
        switch ($what) {
            case 'approve': return self::approve($pdo, $r, $a, $uid);
            case 'stage': return self::stage($pdo, $r, $uid);
            case 'signoff': return self::signOff($pdo, $r, $uid);
            case 'publish': return self::publish($pdo, $r, $uid, '');
            case 'urgent': return self::publish($pdo, $r, $uid, trim((string) ($a['reason'] ?? '')));
            case 'schedule': return self::schedule($pdo, $r, (string) ($a['at'] ?? ''), $tz ?: (string) $r['tz'], $uid);
            case 'unschedule': return self::unschedule($pdo, $r, $uid);
            case 'next': return self::nextStep($pdo, $r, $uid, false);
            case 'pause': return self::pause($pdo, $r, $uid, true, 'Paused by hand.');
            case 'resume': return self::pause($pdo, $r, $uid, false, 'Carried on.');
            case 'off': return self::turnOff($pdo, $r, $uid);
            case 'back': return self::rollBack($pdo, $r, $uid);
            case 'withdraw': return self::withdraw($pdo, $r, $uid);
            case 'note': return self::addNote($pdo, $r, (string) ($a['text'] ?? ''), (string) ($a['page'] ?? ''), $uid, (string) ($a['name'] ?? ''));
        }
        throw new RuntimeException('That can\'t be done to a release.');
    }

    /** A note on the release (from the staging bar, while looking): what was seen, on which page. Kept in its record. */
    private static function addNote(PDO $pdo, array $r, string $text, string $page, int $uid, string $name): string
    {
        $text = trim(preg_replace('/\s+/', ' ', $text));
        if ($text === '') throw new RuntimeException('Write what you saw.');
        $page = preg_match('#^/[^\s]{0,300}$#', $page) ? $page : '';
        self::note($r, 'Note' . ($name !== '' ? ' from ' . $name : '') . ($page !== '' ? ' on ' . $page : '') . ': ' . mb_substr($text, 0, 1000), $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Noted on release #' . $r['id'] . '.';
    }

    // ---- the staging bar: from the live admin to staging and back ---------------------------------------------------------

    /** A signed value: base64url(json) . '.' . base64url(hmac). */
    public static function sign(array $data, string $key): string
    {
        $j = json_encode($data, JSON_UNESCAPED_SLASHES);
        return rtrim(strtr(base64_encode($j), '+/', '-_'), '=') . '.' . rtrim(strtr(base64_encode(hash_hmac('sha256', $j, $key, true)), '+/', '-_'), '=');
    }

    /** The data of a signed value, if its signature is right and it hasn't run out ('exp'); else null. */
    public static function verify(string $tok, string $key): ?array
    {
        if ($key === '' || !preg_match('/^([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/', $tok, $m)) return null;
        $j = base64_decode(strtr($m[1], '-_', '+/'), true);
        $sig = base64_decode(strtr($m[2], '-_', '+/'), true);
        if ($j === false || $sig === false || !hash_equals(hash_hmac('sha256', $j, $key, true), $sig)) return null;
        $d = json_decode($j, true);
        return is_array($d) && (int) ($d['exp'] ?? 0) >= time() ? $d : null;
    }

    /**
     * Open on staging: the address that takes this staff member onto staging.trvgo.us, past its viewing password, signed in
     * as themselves ('me': staging's copy of their own account and staff login, the default), or as one of the audit's test
     * accounts ('m:<key>' a test member, 's:<key>' a test staff login), or signed out (''), with the staging bar. Good for 10 minutes, once. The bar carries what this person may do with releases.
     */
    public static function enterUrl(PDO $pdo, int $id, string $as, string $to, int $uid, string $name, int $sid = 0): string
    {
        require_once __DIR__ . '/StagingSite.php';
        $k = StagingSite::barKeys($pdo);
        if (!$k) throw new RuntimeException('Staging isn\'t set up: System Configuration → Staging → Set up staging.');
        if (StagingSite::running($pdo)) throw new RuntimeException('Staging is being refreshed: try again once it\'s done (you get an email).');
        if ($id) { $r = self::get($pdo, $id); if (!$r) throw new RuntimeException('That release isn\'t here.'); }
        if (!preg_match('/^(me|[ms]:[a-z0-9-]{2,40})?$/', $as)) $as = 'me';
        if (!preg_match('#^/[A-Za-z0-9/_.\-?=&%]{0,300}$#', $to)) $to = '/';
        $perms = [];
        foreach (array_keys(self::PERMS) as $p) if (self::can($p)[0]) $perms[] = $p;
        if ($id && in_array($r['state'], ['staged', 'vetted', 'scheduled'], true)) {   // the look a sign-off needs
            self::note($r, 'Opened on staging' . ($name !== '' ? ' by ' . $name : '') . '.', $uid);
            self::save($pdo, $r);
        }
        $tok = self::sign(['rel' => $id, 'uid' => $uid, 'sid' => $sid, 'name' => mb_substr($name, 0, 60), 'perms' => $perms, 'as' => $as, 'to' => $to, 'n' => bin2hex(random_bytes(8)), 'exp' => time() + 600], $k[0]);
        return 'https://staging.trvgo.us/stg-enter.php?t=' . rawurlencode($tok);
    }

    /** Acts for the staging bar with the permissions its token carries (website/api/release-bar.php). */
    public static function actFromBar(PDO $pdo, array $bar, int $id, string $what, array $a): string
    {
        if (!in_array($what, ['note', 'signoff', 'schedule', 'unschedule', 'publish', 'stage', 'withdraw', 'next', 'off', 'back'], true)) throw new RuntimeException('That isn\'t done from the staging bar: open the release on the live admin.');
        self::$grant = array_values(array_filter((array) ($bar['perms'] ?? []), fn ($p) => isset(self::PERMS[$p])));
        try { return self::act($pdo, $id, $what, $a + ['name' => (string) ($bar['name'] ?? '')], (int) ($bar['uid'] ?? 0)); }
        finally { self::$grant = null; }
    }

    /**
     * What the site manager shows (decisions/0159 §5): its Releases ▾ (on staging now, waiting, live and at which step),
     * the release chosen (or the newest on staging), its line, pages, checks and notes, and its Publish ▾ (Publish now,
     * Schedule, the next step; Turn off and Roll back once it's live), each only where the bar's permissions allow.
     */
    public static function barState(PDO $pdo, int $id, array $perms): array
    {
        self::ensure($pdo);
        $can = fn ($p) => in_array($p, $perms, true);
        $group = fn (string $st) => in_array($st, ['staged', 'vetted'], true) ? 'staging' : (in_array($st, ['planned', 'approved', 'scheduled'], true) ? 'waiting' : 'live');
        $list = [];
        foreach ($pdo->query("SELECT id, title, state, step, switch_key FROM site_releases WHERE state IN ('planned', 'approved', 'staged', 'vetted', 'scheduled', 'live', 'off') ORDER BY id DESC LIMIT 25")->fetchAll(PDO::FETCH_ASSOC) as $x)
            $list[] = ['id' => (int) $x['id'], 'title' => (string) $x['title'], 'state' => self::STATES[$x['state']] ?? $x['state'], 'group' => $group((string) $x['state']),
                       'step' => $x['state'] === 'live' && (string) $x['switch_key'] !== '' ? 'step ' . (int) $x['step'] . ' of 3' : ''];
        $r = $id ? self::get($pdo, $id) : null;
        if (!$r) foreach ($list as $x) if ($x['group'] === 'staging') { $r = self::get($pdo, $x['id']); break; }   // the newest on staging
        $base = ['releases' => $list, 'can_upload' => $can('releases.publish')];
        if (!$r) return $base + ['release' => null];
        [$line, $tone] = self::standing($r);
        $notes = array_values(array_map(fn ($l) => ['at' => $l['at'], 'msg' => $l['msg']], array_filter($r['log'], fn ($l) => str_starts_with((string) $l['msg'], 'Note'))));
        $st = $r['state']; $pub = [];   // Publish ▾: [action, label, needs a yes]
        if ($st === 'approved' && $can('releases.publish')) $pub[] = ['stage', 'Put it on staging', 0];
        if (in_array($st, ['staged', 'vetted', 'scheduled'], true) && ($st !== 'staged' || $r['checks_ok'])) {
            if ($can('releases.publish')) $pub[] = ['publish', 'Publish now', 1];
            if ($can('releases.schedule')) $pub[] = ['schedule', $st === 'scheduled' ? 'Change the time' : 'Schedule', 0];
            if ($st === 'scheduled' && $can('releases.schedule')) $pub[] = ['unschedule', 'Take off the schedule', 0];
        }
        if ($st === 'staged' && $can('releases.publish')) $pub[] = ['stage', $r['checks_ok'] ? 'Put it on staging again' : 'Try staging again', 0];
        if ($st === 'live' && $r['step'] < 3 && $r['switch_key'] !== '' && $can('releases.publish')) $pub[] = ['next', $r['step'] === 1 ? 'Next step: a share of members' : 'Next step: everyone', 1];
        if ($st === 'live' && $r['switch_key'] !== '' && $can('releases.turn_off')) $pub[] = ['off', 'Turn off', 2];
        if (in_array($st, ['live', 'off'], true) && $can('releases.rollback')) $pub[] = ['back', 'Roll back', 2];
        if (in_array($st, ['planned', 'approved', 'staged', 'vetted', 'scheduled'], true) && $can('releases.publish')) $pub[] = ['withdraw', 'Withdraw', 2];
        return $base + ['release' => [
            'id' => (int) $r['id'], 'title' => (string) $r['title'], 'state' => $st, 'state_name' => self::STATES[$st] ?? $st, 'line' => $line, 'tone' => $tone,
            'group' => $group($st), 'step' => (int) $r['step'], 'switch' => (string) $r['switch_key'], 'pages' => self::pagesOf($r), 'files' => array_keys($r['files']), 'why' => (string) $r['why'],
            'checks' => $r['checks'] ? array_map(fn ($i) => ['name' => $i[0], 'ok' => $i[1], 'detail' => $i[2]], $r['checks']['items']) : [],
            'notes' => array_slice(array_reverse($notes), 0, 20), 'acts' => $pub, 'admin' => 'https://traversence.com/admin/config/releases#rel-' . (int) $r['id'],
            'stale' => in_array($st, ['staged', 'vetted'], true) && self::refreshedSince($pdo, $r),
        ]];
    }

    private static function approve(PDO $pdo, array $r, array $a, int $uid): string
    {
        self::need('releases.publish');
        if (!in_array($r['state'], ['planned', 'approved'], true)) throw new RuntimeException('Its plan was approved already.');
        $title = trim((string) ($a['title'] ?? $r['title']));
        if ($title === '') throw new RuntimeException('Give the release a title.');
        $sw = trim((string) ($a['switch'] ?? $r['switch_key']));
        if ($sw !== '' && !preg_match('/^[a-z0-9_]{2,64}$/', $sw)) throw new RuntimeException('A switch\'s key is lower case letters, numbers and _.');
        if ($sw !== '' && !self::switchKnown($r, $sw)) throw new RuntimeException('There\'s no switch "' . $sw . '" on the live site or in this release\'s Switches.php. Leave it empty for a release without one (it goes to everyone at once).');
        $r['title'] = mb_substr($title, 0, 160);
        $r['why'] = mb_substr(trim((string) ($a['why'] ?? $r['why'])), 0, 4000);
        $r['proposals'] = mb_substr(trim((string) ($a['proposals'] ?? $r['proposals'])), 0, 255);
        $r['switch_key'] = $sw;
        $r['advance'] = ($a['advance'] ?? $r['advance']) === 'publish' ? 'publish' : 'schedule';
        $r['state'] = 'approved'; $r['plan_by'] = $uid; $r['plan_at'] = gmdate('Y-m-d H:i:s');
        self::note($r, 'Plan approved' . ($sw !== '' ? ' (switch ' . $sw . ')' : ' (no switch: everyone at once when published)') . ', advancing ' . ($r['advance'] === 'schedule' ? 'on schedule' : 'on Publish next step') . '.', $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Plan approved. Next: put it on staging.';
    }

    /** Is the switch on the live site already, or added by this release's own Switches.php? */
    private static function switchKnown(array $r, string $key): bool
    {
        require_once __DIR__ . '/Switches.php';
        if (isset(Switches::DEFS[$key])) return true;
        $mine = self::dir((int) $r['id']) . '/new/app/lib/Switches.php';
        return is_file($mine) && str_contains((string) file_get_contents($mine), "'" . $key . "' =>");
    }

    // ---- 2. staging ----------------------------------------------------------------------------------------------------

    private static function stage(PDO $pdo, array $r, int $uid): string
    {
        self::need('releases.publish');
        if (!in_array($r['state'], ['approved', 'staged'], true)) throw new RuntimeException($r['state'] === 'planned' ? 'Approve the plan first.' : 'It\'s past staging already.');
        $root = self::stagingRoot($pdo);
        if (!$root) throw new RuntimeException('Staging isn\'t set up: System Configuration → Staging → Set up staging.');
        require_once __DIR__ . '/StagingSite.php';
        if (StagingSite::running($pdo)) throw new RuntimeException('Staging is being refreshed: put it on staging once that\'s done (you get an email).');
        @set_time_limit(300);
        $n = 0;
        foreach ($r['files'] as $p => $f) {
            $to = $root . '/' . $p;
            if (!is_dir(dirname($to)) && !@mkdir(dirname($to), 0755, true)) throw new RuntimeException('Couldn\'t make staging\'s folder for ' . $p . '.');
            if (!@copy(self::dir((int) $r['id']) . '/new/' . $p, $to)) throw new RuntimeException('Couldn\'t copy ' . $p . ' to staging.');
            $n++;
        }
        if (function_exists('opcache_reset')) @opcache_reset();
        $r['staged_at'] = gmdate('Y-m-d H:i:s');
        $c = self::checks($pdo, $r, 'staging');
        $r['checks'] = $c; $r['checks_ok'] = $c['ok']; $r['state'] = 'staged';
        self::note($r, 'Put on staging (' . $n . ' files); its checks ' . ($c['ok'] ? 'passed.' : 'found a problem: ' . $c['first_fail'] . '.'), $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return $c['ok'] ? 'On staging, and its checks passed. Look at it on staging.trvgo.us, then Publish or Schedule.' : 'On staging, but a check failed: ' . $c['first_fail'] . '.';
    }

    private static function signOff(PDO $pdo, array $r, int $uid): string
    {
        self::need('releases.publish');
        if ($r['state'] !== 'staged') throw new RuntimeException('Put it on staging first.');
        if (!$r['checks_ok']) throw new RuntimeException('Its checks on staging didn\'t pass, so it can\'t be signed off.');
        if (self::refreshedSince($pdo, $r)) throw new RuntimeException('Staging was refreshed from live since it went there, so it isn\'t on staging any more: put it on staging again.');
        if (!self::lookedAt($r)) throw new RuntimeException('Look at it on staging first (Open on staging): a release is signed off only after someone has looked at it there (Jason, 2026-11-13).');
        $r['state'] = 'vetted'; $r['vetted_by'] = $uid; $r['vetted_at'] = gmdate('Y-m-d H:i:s');
        self::note($r, 'Signed off after staging.', $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Signed off: Publish and Schedule are open now.';
    }

    /**
     * Publish (or Schedule) on a release that's on staging is its sign-off (decisions/0159 §5: the separate Sign it off
     * goes): the same conditions as signOff (its checks passed, staging not refreshed since, someone looked at it there),
     * then vetted, in place, for the action to carry on.
     */
    private static function signedByPublish(PDO $pdo, array &$r, int $uid, string $by): void
    {
        if (!$r['checks_ok']) throw new RuntimeException('Its checks on staging didn\'t pass: put it on staging again, or upload a fixed zip.');
        if (self::refreshedSince($pdo, $r)) throw new RuntimeException('Staging was refreshed from live since it went there, so it isn\'t on staging any more: put it on staging again.');
        if (!self::lookedAt($r)) throw new RuntimeException('Look at it on staging first (Open on staging): a release goes live only after someone has looked at it there (Jason, 2026-11-13).');
        $r['state'] = 'vetted'; $r['vetted_by'] = $uid; $r['vetted_at'] = gmdate('Y-m-d H:i:s');
        self::note($r, 'Signed off by ' . $by . ', after a look on staging.', $uid);
    }

    /**
     * Upload, straight onto staging (decisions/0159 §5): a release just uploaded gets its plan approved as its release.json
     * gives it and goes onto staging, where its checks run; no separate Approve the plan or Put it on staging. When it
     * can't go on yet (staging refreshing, not set up), it waits approved and says why. Returns the line to show.
     */
    public static function straightOn(PDO $pdo, int $id, int $uid): string
    {
        $r = self::get($pdo, $id);
        if (!$r) throw new RuntimeException('That release isn\'t here.');
        try { self::approve($pdo, $r, [], $uid); }
        catch (RuntimeException $e) { return 'Release #' . $id . ' is in, but its plan needs a look: ' . $e->getMessage() . ' Approve it on System Configuration → Releases.'; }
        try { return 'Release #' . $id . ': ' . self::stage($pdo, (array) self::get($pdo, $id), $uid); }
        catch (RuntimeException $e) { return 'Release #' . $id . ' is in and approved, but not on staging yet: ' . $e->getMessage(); }
    }

    /**
     * Upload from the site manager on staging: the zip the bar's upload kept in staging's own inbox (target release_zip_bar,
     * app/storage/release-inbox/ on staging, which this live server can read: the same hosting account) becomes a release
     * and goes straight onto staging, as the person the bar belongs to with the permissions it carries.
     */
    public static function fromStagingInbox(PDO $pdo, array $bar, string $inbox, string $name, string $tz): array
    {
        if (!preg_match('/^[a-f0-9]{32}\.zip$/', $inbox)) throw new RuntimeException('That upload isn\'t here: upload the zip again.');
        $root = self::stagingRoot($pdo);
        $f = $root ? $root . '/app/storage/release-inbox/' . $inbox : '';
        if ($f === '' || !is_file($f)) throw new RuntimeException('That upload isn\'t on staging any more: upload the zip again.');
        $name = preg_match('/^[A-Za-z0-9 ._()-]{1,120}\.zip$/', $name) ? $name : 'release.zip';
        self::$grant = array_values(array_filter((array) ($bar['perms'] ?? []), fn ($p) => isset(self::PERMS[$p])));
        try {
            $up = self::fromUpload($pdo, (int) ($bar['uid'] ?? 0), $f, $name, $tz);
            $msg = self::straightOn($pdo, (int) $up['id'], (int) ($bar['uid'] ?? 0));
        } finally { self::$grant = null; @unlink($f); }
        return ['id' => (int) $up['id'], 'message' => $msg];
    }

    /**
     * Builds from git (decisions/0159 §5, Phase 6): each release zip Claude merged into releases/inbox on
     * degraffics/traversence's main is fetched (its bytes checked against git's id), made a release and put straight onto
     * staging, then taken out of the inbox (the history keeps it). Once its checks there pass it goes live by itself
     * (autoPublish), unless its release.json holds it for a look. Run by releases_tick every 10 minutes, and by Check for
     * builds on the site manager. A zip taken before (its git id remembered) is only taken out again. Returns a line each.
     */
    public static function fromGit(PDO $pdo, int $uid = 0): array
    {
        self::ensure($pdo);
        require_once __DIR__ . '/DocsRepo.php';
        $list = DocsRepo::inbox();
        if ($list === null) return !$uid ? [] : (DocsRepo::canSave() ? ['GitHub didn\'t answer: try again in a minute (the site also looks every 10 minutes).'] : ['No GITHUB_DOCS_TOKEN in .env: builds can\'t come from git.']);   // the job stays quiet
        $out = [];
        foreach (array_slice($list, 0, 5) as $f) {
            $gk = 'g:' . substr($f['sha'], 0, 38);   // the settings key holds 40 characters
            $st = $pdo->prepare('SELECT v FROM site_release_settings WHERE k = ?'); $st->execute([$gk]);
            $had = (int) $st->fetchColumn();
            if ($had) { DocsRepo::takeFromInbox($f['path'], $f['sha'], 'Release #' . $had . ': taken from the inbox (it was already in)'); $out[] = $f['name'] . ': already release #' . $had . '.'; continue; }
            $data = DocsRepo::blob($f['sha']);
            if ($data === null) { $out[] = $f['name'] . ': couldn\'t fetch it whole from GitHub; tried again next time.'; continue; }
            $tmp = tempnam(sys_get_temp_dir(), 'tvrel');
            file_put_contents($tmp, $data);
            $id = 0;
            try {
                $up = self::fromUpload($pdo, $uid, $tmp, $f['name'], '');
                $id = (int) $up['id'];
                try { $pdo->prepare('REPLACE INTO site_release_settings (k, v) VALUES (?, ?)')->execute([$gk, (string) $id]); } catch (Throwable $e) { error_log('release from git, remembering ' . $gk . ': ' . $e->getMessage()); }
                $r = self::get($pdo, $id);
                if ($r) { self::note($r, 'Came from git: ' . $f['path'] . ' (git ' . substr($f['sha'], 0, 10) . ').', $uid); self::save($pdo, $r); }
                $out[] = self::straightOn($pdo, $id, $uid);
                // Jason approved it in chat before it was sent (2026-11-13): once its staging checks pass it goes live by itself,
                // unless its release.json says "hold": true (he asked to see it on staging first). Failed checks stop it there.
                $out[] = self::autoPublish($pdo, $id, $uid, self::planHold($data));
            } catch (Throwable $e) {
                $out[] = $f['name'] . ': ' . ($id ? 'release #' . $id . ' made, then stopped: ' : 'not taken: ') . $e->getMessage();
            } finally {
                @unlink($tmp);
                // once it's a release, it leaves the inbox whatever happened next, so it's never made twice
                if ($id) { $t = DocsRepo::takeFromInbox($f['path'], $f['sha'], 'Release #' . $id . ': ' . $f['name'] . ' taken from the inbox onto staging'); if (empty($t['ok'])) $out[] = 'Release #' . $id . ' stays in the inbox for now (' . ($t['error'] ?? '') . '); it won\'t be made again.'; }
            }
        }
        return array_values(array_filter($out, fn ($l) => $l !== ''));
    }

    /** Does a release zip's release.json ask to wait on staging for a look ("hold": true)? */
    private static function planHold(string $zipData): bool
    {
        if (!class_exists('ZipArchive')) return true;   // can't read it: wait, to be safe
        $tmp = tempnam(sys_get_temp_dir(), 'tvhold'); file_put_contents($tmp, $zipData);
        $z = new ZipArchive(); $hold = false;
        if ($z->open($tmp) === true) { $p = json_decode((string) $z->getFromName('release.json'), true); $hold = is_array($p) && !empty($p['hold']); $z->close(); }
        @unlink($tmp);
        return $hold;
    }

    /**
     * A build from git goes live by itself once its checks on staging pass (Jason, 2026-11-13: "I would have already
     * approved it in claude before it got pushed"; Publish is for work done on staging). Held ones, failed checks and a
     * refresh in the way leave it on staging, saying why. Returns the line to show.
     */
    private static function autoPublish(PDO $pdo, int $id, int $uid, bool $hold): string
    {
        $r = self::get($pdo, $id);
        if (!$r) return '';
        if ($hold) { self::note($r, 'Held on staging for a look (its release.json says hold): Publish when it\'s seen.', $uid); self::save($pdo, $r); return 'Release #' . $id . ' waits on staging for your look (held).'; }
        if ($r['state'] !== 'staged' || !$r['checks_ok']) return 'Release #' . $id . ' stays on staging: ' . (self::standing($r)[0]) . '';
        $r['state'] = 'vetted'; $r['vetted_by'] = $uid ?: null; $r['vetted_at'] = gmdate('Y-m-d H:i:s');
        self::note($r, 'Approved in chat before it was sent through git, and its checks on staging passed: publishing by itself.', $uid);
        self::save($pdo, $r);
        try { return 'Release #' . $id . ': ' . self::publish($pdo, $r, $uid, ''); }
        catch (RuntimeException $e) { return 'Release #' . $id . ' passed on staging but didn\'t go live: ' . $e->getMessage() . ' Publish it from the site manager.'; }
    }

    /** Check for builds, from the site manager: fromGit now, as the bar's person with its permissions. */
    public static function pullFromBar(PDO $pdo, array $bar): string
    {
        self::$grant = array_values(array_filter((array) ($bar['perms'] ?? []), fn ($p) => isset(self::PERMS[$p])));
        try { self::need('releases.publish'); $l = self::fromGit($pdo, (int) ($bar['uid'] ?? 0)); }
        finally { self::$grant = null; }
        return $l ? implode(' ', $l) : 'No new builds in git: nothing is waiting.';
    }

    /** The staging bar showed this release to someone on staging: that's a look, for its sign-off (once each time it's staged). */
    public static function sawOnStaging(PDO $pdo, int $id, int $uid, string $name): void
    {
        $r = self::get($pdo, $id);
        if (!$r || !in_array($r['state'], ['staged', 'vetted', 'scheduled'], true) || self::lookedAt($r)) return;
        self::note($r, 'Opened on staging' . ($name !== '' ? ' by ' . $name : '') . ' (the staging bar).', $uid);
        self::save($pdo, $r);
    }

    /** Has someone opened it on staging since it was last put there (Open on staging, or the staging bar on it)? */
    private static function lookedAt(array $r): bool
    {
        $since = strtotime((string) $r['staged_at'] . ' UTC');
        foreach ($r['log'] as $l) if (str_starts_with((string) $l['msg'], 'Opened on staging') && strtotime((string) $l['at']) >= $since) return true;
        return false;
    }

    /** Was staging refreshed from live after this release went there (wiping it)? */
    private static function refreshedSince(PDO $pdo, array $r): bool
    {
        require_once __DIR__ . '/StagingSite.php';
        $last = StagingSite::get($pdo, 'last');
        return $last && !empty($last['at']) && !empty($r['staged_at']) && strtotime((string) $last['at']) > strtotime((string) $r['staged_at'] . ' UTC');
    }

    // ---- the checks ----------------------------------------------------------------------------------------------------

    /**
     * The release's checks, on staging (before) or live (after each step): every PHP file parses; migrations only add; on
     * staging its migrations run there; its pages and the home page answer without a server error; no new fatal errors
     * in the site's error logs while they were asked. ['ok', 'where', 'at', 'items' => [[name, ok true|false|null, detail]], 'first_fail'].
     */
    public static function checks(PDO $pdo, array $r, string $where): array
    {
        $items = [];
        $dir = self::dir((int) $r['id']) . '/new/';
        // PHP that doesn't parse
        $bad = [];
        foreach (array_keys($r['files']) as $p) {
            if (!str_ends_with($p, '.php')) continue;
            try { token_get_all((string) file_get_contents($dir . $p), TOKEN_PARSE); } catch (Throwable $e) { $bad[] = $p . ' line ' . $e->getLine() . ': ' . $e->getMessage(); }
        }
        $php = count(array_filter(array_keys($r['files']), fn ($p) => str_ends_with($p, '.php')));
        $items[] = ['PHP files parse', !$bad, $bad ? implode('; ', array_slice($bad, 0, 3)) : $php . ' checked'];
        // migrations: add-only, nothing the site's runner can't run
        $migs = self::migrations($r); $mBad = [];
        foreach ($migs as $p) {
            $sql = (string) file_get_contents($dir . $p);
            if (preg_match('/\b(DROP\s+(TABLE|COLUMN|INDEX|KEY|DATABASE|VIEW|TRIGGER)|RENAME\s+(TABLE|COLUMN|TO)|TRUNCATE|DELIMITER|CREATE\s+(DEFINER\S*\s+)?PROCEDURE|MODIFY\s+(COLUMN\s+)?\w+|CHANGE\s+(COLUMN\s+)?\w+)\b/i', $sql, $m)) $mBad[] = basename($p) . ' (' . strtoupper(preg_replace('/\s+/', ' ', $m[1])) . ')';
        }
        if ($migs) $items[] = ['Migrations only add', !$mBad, $mBad ? 'Not add-only: ' . implode(', ', $mBad) . '. A removal comes in a later release (decisions/0145 §6).' : count($migs) . ' checked'];
        if ($where === 'staging' && $migs && !$mBad) {
            [$ok, $detail] = self::runStagingMigrations($pdo);
            $items[] = ['Migrations ran on staging', $ok, $detail];
        }
        // pages answer, and the error logs stay quiet while they're asked
        $base = $where === 'staging' ? 'https://staging.trvgo.us' : 'https://traversence.com';
        $root = $where === 'staging' ? self::stagingRoot($pdo) : self::liveRoot();
        $auth = $where === 'staging' ? self::checkLogin($pdo) : null;
        $urls = self::pagesOf($r);
        $logs = $root ? self::errorLogs($root, $r) : [];
        $sizes = []; foreach ($logs as $f) $sizes[$f] = (int) @filesize($f);
        $fails = []; $silent = 0;
        foreach ($urls as $u) {
            [$code, $body] = self::fetch($base . $u, $auth);
            if ($code === 0) { $silent++; continue; }
            if ($code >= 500 || preg_match('/<b>(Fatal|Parse) error<\/b>|PHP (Fatal|Parse) error|Fatal error: Uncaught/i', $body)) $fails[] = $u . ' (' . $code . ')';
        }
        if ($silent === count($urls)) $items[] = ['Pages answer', null, 'The server couldn\'t reach ' . parse_url($base, PHP_URL_HOST) . ' to ask (not counted as a failure; the error logs below still are)'];
        else $items[] = ['Pages answer', !$fails && !$silent, $fails || $silent ? 'Server errors: ' . implode(', ', array_slice(array_merge($fails, $silent ? [$silent . ' gave no answer'] : []), 0, 5)) : count($urls) . ' pages answered on ' . parse_url($base, PHP_URL_HOST)];
        clearstatcache();
        $fatal = []; $warn = 0;
        foreach ($sizes as $f => $was) {
            $now = (int) @filesize($f);
            if ($now <= $was) continue;
            $h = @fopen($f, 'rb'); if (!$h) continue;
            fseek($h, $was); $new = (string) fread($h, min(200000, $now - $was)); fclose($h);
            foreach (explode("\n", $new) as $l) {
                if (preg_match('/PHP (Fatal|Parse) error/i', $l)) $fatal[] = trim(mb_substr(preg_replace('/^\[[^\]]+\]\s*/', '', $l), 0, 220));
                elseif (preg_match('/PHP (Warning|Deprecated)/i', $l)) $warn++;
            }
        }
        $items[] = ['No new fatal errors in the logs', !$fatal, $fatal ? implode(' · ', array_slice(array_unique($fatal), 0, 3)) : ($warn ? $warn . ' warning' . ($warn === 1 ? '' : 's') . ' (not blocking)' : count($sizes) . ' logs read')];
        $first = '';
        foreach ($items as $i) if ($i[1] === false) { $first = $i[0] . ': ' . $i[2]; break; }
        return ['ok' => $first === '', 'where' => $where, 'at' => gmdate('c'), 'items' => $items, 'first_fail' => $first];
    }

    /** The pages a release touches, as addresses (its website/*.php that aren't endpoints), with the home and FAQ pages. */
    private static function pagesOf(array $r): array
    {
        $out = ['/', '/faq.php'];
        foreach (array_keys($r['files']) as $p) {
            if (!preg_match('#^website/(.+\.php)$#', $p, $m)) continue;
            if (preg_match('#(^|/)(api|includes|_[a-z]+)/#', $m[1])) continue;
            $out[] = '/' . preg_replace('#(^|/)index\.php$#', '$1', $m[1]);
        }
        return array_slice(array_values(array_unique($out)), 0, 25);
    }

    private static function errorLogs(string $root, array $r): array
    {
        $dirs = ['website', 'website/admin', 'website/api'];
        foreach (array_keys($r['files']) as $p) if (str_starts_with($p, 'website/')) $dirs[] = dirname($p);
        $out = [];
        foreach (array_unique($dirs) as $d) { $f = $root . '/' . $d . '/error_log'; $out[] = $f; }
        return $out;
    }

    private static function fetch(string $url, ?array $auth): array
    {
        $ch = curl_init($url);
        $o = [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 8,
              CURLOPT_USERAGENT => 'Traversence release check', CURLOPT_HTTPHEADER => ['X-Tv-Check: release']];
        if ($auth) { $o[CURLOPT_USERPWD] = $auth[0] . ':' . $auth[1]; $o[CURLOPT_HTTPAUTH] = CURLAUTH_BASIC; }
        curl_setopt_array($ch, $o);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$code, is_string($body) ? $body : ''];
    }

    /**
     * The checks' own sign-in on staging: a second line in its viewing-password file, its password kept here on the live
     * server only (never shown). Put back if a new viewing password rewrote the file.
     */
    public static function checkLogin(PDO $pdo): ?array   // public for Check the way in (StagingSite::checkWayIn)
    {
        require_once __DIR__ . '/StagingSite.php';
        $s = (array) StagingSite::get($pdo, 'setup');
        if (empty($s['base'])) return null;
        $f = StagingSite::layout((string) $s['base'])['htpasswd'];
        $st = $pdo->prepare("SELECT v FROM site_release_settings WHERE k = 'check_pw'"); $st->execute();
        $pw = (string) $st->fetchColumn();
        if ($pw === '') { $pw = bin2hex(random_bytes(18)); $pdo->prepare("REPLACE INTO site_release_settings (k, v) VALUES ('check_pw', ?)")->execute([$pw]); }
        $lines = is_file($f) ? (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: []) : [];
        $have = null;
        foreach ($lines as $l) if (str_starts_with($l, self::CHECK_USER . ':')) $have = substr($l, strlen(self::CHECK_USER) + 1);
        if ($have === null || !password_verify($pw, $have)) {
            $lines = array_values(array_filter($lines, fn ($l) => !str_starts_with($l, self::CHECK_USER . ':')));
            $lines[] = self::CHECK_USER . ':' . password_hash($pw, PASSWORD_BCRYPT);
            $tmp = $f . '.new-' . bin2hex(random_bytes(4));
            if (@file_put_contents($tmp, implode("\n", $lines) . "\n") !== false) { @chmod($tmp, 0644); @rename($tmp, $f); }
        }
        return [self::CHECK_USER, $pw];
    }

    /** Asks staging to run the migrations waiting in its app/migrations (website/api/staging-updates.php, staging only). */
    private static function runStagingMigrations(PDO $pdo): array
    {
        require_once __DIR__ . '/StagingSite.php';
        $s = (array) StagingSite::get($pdo, 'setup');
        $env = StagingSite::readEnvFile(StagingSite::layout((string) $s['base'])['env']);
        $tok = (string) ($env['HEALTH_TOKEN'] ?? '');
        if ($tok === '') return [false, 'Staging has no HEALTH_TOKEN in its .env: press Set up staging again.'];
        $auth = self::checkLogin($pdo);
        $ch = curl_init('https://staging.trvgo.us/api/staging-updates.php');
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => '', CURLOPT_TIMEOUT => 240,
            CURLOPT_HTTPHEADER => ['X-Health-Token: ' . $tok], CURLOPT_USERPWD => $auth[0] . ':' . $auth[1], CURLOPT_HTTPAUTH => CURLAUTH_BASIC]);
        $body = (string) curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $j = json_decode($body, true);
        if ($code !== 200 || !is_array($j)) return [false, 'Staging didn\'t run them (HTTP ' . ($code ?: 'no answer') . ').'];
        $failed = (array) ($j['failed'] ?? []);
        if ($failed) return [false, implode('; ', array_map(fn ($k, $v) => $k . ': ' . $v, array_keys($failed), $failed))];
        $ran = (array) ($j['ran'] ?? []);
        return [true, $ran ? 'Ran ' . implode(', ', $ran) : 'Nothing waiting (run already)'];
    }

    // ---- 3. live ---------------------------------------------------------------------------------------------------------

    private static function publish(PDO $pdo, array $r, int $uid, string $urgent): string
    {
        self::need('releases.publish');
        if ($urgent !== '') {
            if (mb_strlen($urgent) < 10) throw new RuntimeException('Say why it can\'t wait (a sentence): it\'s recorded with the release.');
            if (!in_array($r['state'], ['planned', 'approved', 'staged', 'vetted', 'scheduled'], true)) throw new RuntimeException('It\'s gone out already.');
        } elseif ($r['state'] === 'staged') {
            self::signedByPublish($pdo, $r, $uid, 'Publish');   // the look on staging was the review; Publish is the sign-off (decisions/0159 §5)
        } elseif (!in_array($r['state'], ['vetted', 'scheduled'], true)) {
            throw new RuntimeException('Publish opens once it\'s on staging, its checks passed and someone has looked at it there.');
        }
        @set_time_limit(300);
        $dir = self::dir((int) $r['id']); $root = self::liveRoot();
        // a live file changed since the release was built (another upload, another release): never written over unseen
        $moved = [];
        foreach ($r['files'] as $p => $f) { $now = self::liveSha($p); if ($now !== $f['live_was'] && $now !== $f['sha']) $moved[] = $p; }
        if ($moved && $urgent === '') throw new RuntimeException('Changed on the live site since this release was built: ' . implode(', ', array_slice($moved, 0, 5)) . (count($moved) > 5 ? ' and ' . (count($moved) - 5) . ' more' : '') . '. Nothing was published: rebuild the release on the live copy (upload it again as a new release).');
        if ($moved) self::note($r, 'Published over files changed on live since it was built (urgent): ' . implode(', ', array_slice($moved, 0, 5)) . '.', $uid);
        // the previous copy of every file first, so a rollback always has it
        foreach ($r['files'] as $p => &$f) {
            $live = $root . '/' . $p;
            $f['existed'] = is_file($live);
            if ($f['existed']) {
                $old = $dir . '/old/' . $p;
                if (!is_dir(dirname($old))) @mkdir(dirname($old), 0750, true);
                if (!@copy($live, $old)) throw new RuntimeException('Couldn\'t keep the previous copy of ' . $p . ', so nothing was published.');
                $f['old_sha'] = hash_file('sha256', $old);
            }
        }
        unset($f);
        $done = [];
        foreach ($r['files'] as $p => $f) {
            $live = $root . '/' . $p;
            if (!is_dir(dirname($live)) && !@mkdir(dirname($live), 0755, true)) { self::putBack($r, $done); throw new RuntimeException('Couldn\'t make the folder for ' . $p . '; the files already copied were put back.'); }
            $tmp = $live . '.rel-' . bin2hex(random_bytes(3));
            if (!@copy($dir . '/new/' . $p, $tmp) || !@rename($tmp, $live)) { @unlink($tmp); self::putBack($r, $done); throw new RuntimeException('Couldn\'t write ' . $p . '; the files already copied were put back.'); }
            $done[] = $p;
        }
        if (function_exists('opcache_reset')) @opcache_reset();
        $wasDue = $r['state'] === 'scheduled';   // the job publishing it at its time, not a build going live by itself
        $r['state'] = 'live'; $r['live_at'] = gmdate('Y-m-d H:i:s'); $r['step_at'] = $r['live_at']; $r['paused'] = 0; $r['schedule_at'] = null;
        if ($urgent !== '') $r['urgent'] = $urgent;
        if ($r['switch_key'] !== '') { self::switchTo($pdo, $r['switch_key'], 'test', 0, $uid, 'Release #' . $r['id'] . ': step 1'); $r['step'] = 1; }
        else $r['step'] = 3;
        $migs = self::migrations($r);
        self::note($r, ($urgent !== '' ? 'Published at once (urgent: ' . $urgent . ')' : ($uid || !$wasDue ? 'Published' : 'Published on schedule')) . ': ' . count($done) . ' files'
            . ($migs ? ', ' . count($migs) . ' migration' . (count($migs) === 1 ? '' : 's') . ' (they run themselves within the hour)' : '')
            . ($r['step'] === 1 ? '; step 1, staff and test accounts.' : '; everyone at once (no switch).'), $uid);
        $c = self::checks($pdo, $r, 'live');
        $r['checks'] = $c; $r['checks_ok'] = $c['ok'];
        if (!$c['ok']) { $r['paused'] = 1; self::note($r, 'A check on live failed: ' . $c['first_fail'] . '. Paused: Turn off or Roll back is your call.', 0); self::alert($pdo, $r, $c['first_fail']); }
        self::save($pdo, $r); self::record($pdo, $r);
        return $c['ok'] ? 'Published: ' . count($done) . ' files are live' . ($r['step'] === 1 ? ', on for staff and test accounts.' : '.') . ' Its checks on live passed.'
                        : 'Published, but a check on live failed (' . $c['first_fail'] . '): it\'s paused. Turn it off or roll it back if it needs it.';
    }

    /** After a failed write: the files already copied go back to their previous copy (or away, if they were new). */
    private static function putBack(array $r, array $paths): void
    {
        $dir = self::dir((int) $r['id']); $root = self::liveRoot();
        foreach ($paths as $p) {
            if (!empty($r['files'][$p]['existed'])) @copy($dir . '/old/' . $p, $root . '/' . $p); else @unlink($root . '/' . $p);
        }
    }

    /** Sets a switch (one this release may have just added, so the class loaded on this request may not know it yet). */
    private static function switchTo(PDO $pdo, string $key, string $state, int $pct, int $by, string $note, bool $killed = false): void
    {
        require_once __DIR__ . '/Switches.php';
        if (isset(Switches::DEFS[$key])) { Switches::set($pdo, $key, $state, $pct, $killed, $note, $by); return; }
        $pdo->prepare('INSERT INTO feature_switches (switch_key, state, share_pct, killed, note, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, NOW())
                       ON DUPLICATE KEY UPDATE state = VALUES(state), share_pct = VALUES(share_pct), killed = VALUES(killed), note = VALUES(note), updated_by = VALUES(updated_by), updated_at = NOW()')
            ->execute([$key, $state, max(0, min(100, $pct)), $killed ? 1 : 0, mb_substr($note, 0, 255), $by ?: null]);
    }

    private static function schedule(PDO $pdo, array $r, string $at, string $tz, int $uid): string
    {
        self::need('releases.schedule');
        if ($r['state'] === 'staged') self::signedByPublish($pdo, $r, $uid, 'Schedule');
        elseif (!in_array($r['state'], ['vetted', 'scheduled'], true)) throw new RuntimeException('Schedule opens once it\'s on staging, its checks passed and someone has looked at it there.');
        try { $z = new DateTimeZone($tz !== '' ? $tz : 'America/Phoenix'); $d = new DateTimeImmutable($at, $z); } catch (Throwable) { throw new RuntimeException('Choose a date and time.'); }
        if ($d->getTimestamp() < time() + 60) throw new RuntimeException('Choose a time in the future (or Publish now).');
        $r['schedule_at'] = $d->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'); $r['tz'] = $z->getName(); $r['state'] = 'scheduled';
        self::note($r, 'Scheduled for ' . self::when($r['schedule_at'], $r['tz']) . '.', $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Scheduled for ' . self::when($r['schedule_at'], $r['tz']) . '.';
    }

    private static function unschedule(PDO $pdo, array $r, int $uid): string
    {
        self::need('releases.schedule');
        if ($r['state'] !== 'scheduled') throw new RuntimeException('It isn\'t scheduled.');
        $r['state'] = 'vetted'; $r['schedule_at'] = null;
        self::note($r, 'Schedule taken off.', $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Taken off the schedule: it\'s ready to publish or schedule again.';
    }

    private static function nextStep(PDO $pdo, array $r, int $uid, bool $auto): string
    {
        self::need('releases.publish');
        if ($r['state'] !== 'live' || $r['step'] >= 3) throw new RuntimeException($r['state'] === 'live' ? 'It\'s live for everyone already.' : 'It isn\'t live.');
        if ($r['paused'] && $auto) return 'Paused: waiting for you.';
        $c = self::checks($pdo, $r, 'live');
        $r['checks'] = $c; $r['checks_ok'] = $c['ok'];
        if (!$c['ok']) {
            $r['paused'] = 1;
            self::note($r, 'A check failed at step ' . $r['step'] . ' (' . $c['first_fail'] . '): paused before the next step. Turn off or Roll back is your call.', $uid);
            self::save($pdo, $r); self::record($pdo, $r);
            self::alert($pdo, $r, $c['first_fail']);
            return 'Not moved on: a check failed (' . $c['first_fail'] . '). It\'s paused.';
        }
        $s = self::settings($pdo);
        $r['step']++; $r['step_at'] = gmdate('Y-m-d H:i:s'); $r['paused'] = 0;
        if ($r['step'] === 2) self::switchTo($pdo, $r['switch_key'], 'share', (int) $s['share_pct'], $uid, 'Release #' . $r['id'] . ': step 2');
        else self::switchTo($pdo, $r['switch_key'], 'on', 100, $uid, 'Release #' . $r['id'] . ': step 3, everyone');
        self::note($r, ($auto ? 'On schedule: ' : '') . 'step ' . $r['step'] . ', ' . ($r['step'] === 2 ? $s['share_pct'] . '% of members (and staff and test accounts).' : 'everyone.'), $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return $r['step'] === 2 ? 'Step 2: on for ' . $s['share_pct'] . '% of members as well.' : 'Step 3: on for everyone.';
    }

    private static function pause(PDO $pdo, array $r, int $uid, bool $on, string $why): string
    {
        self::need('releases.publish');
        if ($r['state'] !== 'live') throw new RuntimeException('Only a release that\'s live can be paused.');
        $r['paused'] = $on ? 1 : 0;
        if (!$on) $r['step_at'] = gmdate('Y-m-d H:i:s');   // its clock starts again
        self::note($r, $why, $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return $on ? 'Paused: it stays at step ' . $r['step'] . ' until you carry on.' : 'Carrying on from step ' . $r['step'] . '.';
    }

    private static function turnOff(PDO $pdo, array $r, int $uid): string
    {
        self::need('releases.turn_off');
        if (!in_array($r['state'], ['live', 'off'], true)) throw new RuntimeException('It isn\'t live.');
        if ($r['switch_key'] === '') throw new RuntimeException('It has no switch, so it can\'t be turned off: Roll back takes its files out.');
        self::switchTo($pdo, $r['switch_key'], 'off', 0, $uid, 'Release #' . $r['id'] . ': turned off', true);
        $r['state'] = 'off'; $r['paused'] = 1;
        self::note($r, 'Turned off for everyone (switch ' . $r['switch_key'] . ').', $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Turned off for everyone. Its files are still there; Roll back takes them out.';
    }

    private static function rollBack(PDO $pdo, array $r, int $uid): string
    {
        self::need('releases.rollback');
        if (!in_array($r['state'], ['live', 'off'], true)) throw new RuntimeException('Only a release that went live can be rolled back.');
        $dir = self::dir((int) $r['id']); $root = self::liveRoot();
        $back = 0; $gone = 0; $changed = [];
        foreach ($r['files'] as $p => $f) {
            if (preg_match('#^app/migrations/#', $p)) continue;   // migrations only add, and run once: nothing to undo
            $live = $root . '/' . $p;
            if (is_file($live) && hash_file('sha256', $live) !== $f['sha']) $changed[] = $p;   // changed again since: still put back, but said
            if (!empty($f['existed'])) { if (@copy($dir . '/old/' . $p, $live)) $back++; }
            elseif (is_file($live) && @unlink($live)) $gone++;
        }
        if (function_exists('opcache_reset')) @opcache_reset();
        if ($r['switch_key'] !== '') self::switchTo($pdo, $r['switch_key'], 'off', 0, $uid, 'Release #' . $r['id'] . ': rolled back');
        $r['state'] = 'rolled_back'; $r['paused'] = 0;
        self::note($r, 'Rolled back: ' . $back . ' file' . ($back === 1 ? '' : 's') . ' put back to their previous copy, ' . $gone . ' new file' . ($gone === 1 ? '' : 's') . ' removed' . ($changed ? '; ' . count($changed) . ' had changed again since (' . implode(', ', array_slice($changed, 0, 3)) . ')' : '') . '. Migrations stay (they only added).', $uid);
        $c = self::checks($pdo, $r, 'live');
        $r['checks'] = $c; $r['checks_ok'] = $c['ok'];
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Rolled back: ' . $back . ' file' . ($back === 1 ? '' : 's') . ' put back, ' . $gone . ' removed.' . ($c['ok'] ? ' The checks on live passed.' : ' A check on live still fails: ' . $c['first_fail'] . '.');
    }

    private static function withdraw(PDO $pdo, array $r, int $uid): string
    {
        self::need('releases.publish');
        if (!in_array($r['state'], ['planned', 'approved', 'staged', 'vetted', 'scheduled'], true)) throw new RuntimeException('It went live: roll it back instead.');
        $r['state'] = 'withdrawn'; $r['schedule_at'] = null;
        self::note($r, 'Withdrawn before it went live' . ($r['staged_at'] ? ' (staging keeps its files until its next refresh)' : '') . '.', $uid);
        self::save($pdo, $r); self::record($pdo, $r);
        return 'Withdrawn.';
    }

    /** A failed check: an email to whoever approved the plan (and the Pulse case turns red). A system email: no cost. */
    private static function alert(PDO $pdo, array $r, string $what): void
    {
        try {
            $uid = (int) ($r['plan_by'] ?: $r['created_by']);
            if (!$uid) return;
            $st = $pdo->prepare('SELECT email FROM users WHERE id = ?'); $st->execute([$uid]);
            $to = (string) $st->fetchColumn();
            if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return;
            require_once __DIR__ . '/Mailer.php';
            Mailer::send($to, 'Release #' . $r['id'] . ' is paused: a check failed', 'Release #' . $r['id'] . ' (' . $r['title'] . ') is paused at step ' . $r['step'] . ' of 3: ' . $what
                . "\n\nNothing was undone. Open System Configuration → Releases to carry on, turn it off or roll it back: https://traversence.com/admin/config/releases"
                . "\n\nSomething not right? Write to support@traversence.com.");
        } catch (Throwable $e) { error_log('release alert: ' . $e->getMessage()); }
    }

    // ---- the scheduled job -----------------------------------------------------------------------------------------------

    /** Publishes what's due and moves live releases on when their time comes (releases_tick). Returns lines for its log. */
    public static function tick(PDO $pdo): array
    {
        self::ensure($pdo);
        $out = [];
        foreach ($pdo->query("SELECT id FROM site_releases WHERE state IN ('scheduled', 'live') ORDER BY id")->fetchAll(PDO::FETCH_COLUMN) as $id) {
            $r = self::get($pdo, (int) $id);
            try {
                if ($r['state'] === 'scheduled' && strtotime((string) $r['schedule_at'] . ' UTC') <= time()) { $out[] = '#' . $id . ': ' . self::publish($pdo, $r, 0, ''); continue; }
                if ($r['state'] !== 'live' || $r['paused'] || $r['step'] >= 3 || $r['advance'] !== 'schedule' || $r['switch_key'] === '') continue;
                $s = self::settings($pdo);
                $after = $r['step'] === 1 ? $s['members_after_h'] : $s['everyone_after_h'];
                if (strtotime((string) $r['step_at'] . ' UTC') + $after * 3600 > time() || !self::inWindow($pdo)) continue;
                $out[] = '#' . $id . ': ' . self::nextStep($pdo, $r, 0, true);
            } catch (Throwable $e) { $out[] = '#' . $id . ': ' . $e->getMessage(); error_log('releases tick #' . $id . ': ' . $e->getMessage()); }
        }
        return $out;
    }

    // ---- the zips, for FTP ---------------------------------------------------------------------------------------------

    /** The release's own zip, or its rollback zip (the previous copies, and a list of its new files to delete): [path, name]. */
    public static function zip(PDO $pdo, int $id, string $which): array
    {
        self::need('releases.publish');
        $r = self::get($pdo, $id);
        if (!$r) throw new RuntimeException('That release isn\'t here.');
        if ($r['state'] === 'planned') throw new RuntimeException('The zips are ready once the plan is approved.');
        $dir = self::dir($id);
        if ($which === 'release') {
            if (!is_file($dir . '/release.zip')) throw new RuntimeException('Its zip isn\'t kept any more.');
            return [$dir . '/release.zip', 'release-' . $id . '.zip'];
        }
        if (!class_exists('ZipArchive')) throw new RuntimeException('The server\'s PHP can\'t make zips.');
        $f = $dir . '/rollback.zip';
        $z = new ZipArchive();
        if ($z->open($f, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new RuntimeException('Couldn\'t make the rollback zip.');
        $new = []; $root = self::liveRoot();
        foreach ($r['files'] as $p => $x) {
            if (preg_match('#^app/migrations/#', $p)) continue;
            $existed = array_key_exists('existed', $x) ? (bool) $x['existed'] : $x['live_was'] !== null;
            if (!$existed) { $new[] = $p; continue; }
            $src = is_file($dir . '/old/' . $p) ? $dir . '/old/' . $p : ($r['state'] === 'live' || $r['state'] === 'off' ? null : $root . '/' . $p);   // not live yet: today's live copy is the previous one
            if ($src && is_file($src)) $z->addFile($src, $p);
        }
        $z->addFromString('ROLLBACK.txt', "Rollback for release #$id (" . $r['title'] . ").\nUpload these files over the live ones. Then delete these files, which the release added:\n" . ($new ? implode("\n", $new) : '(none)') . "\nMigrations aren't undone: they only added.\n");
        $z->close();
        return [$f, 'rollback-' . $id . '.zip'];
    }

    // ---- the record in git -------------------------------------------------------------------------------------------------

    /** Writes the release to deliveries/releases/ in the docs repo (best effort: the page says when it couldn't). */
    private static function record(PDO $pdo, array $r): void
    {
        try {
            require_once __DIR__ . '/DocsRepo.php';
            if (!DocsRepo::canSave()) return;
            $slug = gmdate('Y-m-d', strtotime((string) $r['created_at'] . ' UTC')) . '-' . $r['id'] . '-' . (substr(trim(preg_replace('/[^a-z0-9]+/', '-', strtolower((string) $r['title'])), '-'), 0, 40) ?: 'release');
            $doc = ['id' => $r['id'], 'title' => $r['title'], 'why' => $r['why'], 'proposals' => $r['proposals'], 'zip' => $r['zip_name'], 'switch' => $r['switch_key'],
                    'advance' => $r['advance'], 'state' => $r['state'], 'step' => $r['step'], 'paused' => (bool) $r['paused'], 'urgent' => $r['urgent'],
                    'schedule_at' => $r['schedule_at'], 'plan_at' => $r['plan_at'], 'staged_at' => $r['staged_at'], 'vetted_at' => $r['vetted_at'], 'live_at' => $r['live_at'],
                    'files' => $r['files'], 'migrations' => self::migrations($r), 'checks' => $r['checks'], 'log' => $r['log']];
            $res = DocsRepo::saveRecord('deliveries/releases/' . $slug . '.json', json_encode($doc, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n", 'Release #' . $r['id'] . ': ' . self::STATES[$r['state']]);
            if (empty($res['ok'])) error_log('release record #' . $r['id'] . ': ' . ($res['error'] ?? ''));
        } catch (Throwable $e) { error_log('release record: ' . $e->getMessage()); }
    }

    // ---- Pulse -------------------------------------------------------------------------------------------------------------

    /** The releases waiting on someone or paused: [key, severity, title, why, when, action word]. */
    public static function pulseItems(PDO $pdo): array
    {
        self::ensure($pdo);
        $out = [];
        foreach ($pdo->query("SELECT * FROM site_releases WHERE state IN ('planned', 'approved', 'staged', 'vetted', 'scheduled', 'live', 'off') ORDER BY id DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $r = self::decode($row);
            if ($r['state'] === 'live' && $r['step'] >= 3 && !$r['paused']) continue;   // done: nothing to do
            if ($r['state'] === 'live' && !$r['paused'] && $r['advance'] === 'schedule') continue;   // moving on by itself
            if ($r['state'] === 'scheduled') continue;
            [$line, $tone] = self::standing($r);
            $sev = $tone === 'bad' ? 'alert' : 'update';
            $out[] = ['release:' . $r['id'], $sev, 'Release #' . $r['id'] . ': ' . $r['title'], $line, (string) $r['updated_at'], self::nextWord($r)];
        }
        return $out;
    }

    private static function nextWord(array $r): string
    {
        if ($r['state'] === 'live' && $r['paused']) return 'Decide';
        return match ($r['state']) { 'planned' => 'Approve the plan', 'approved' => 'Put it on staging', 'staged' => $r['checks_ok'] ? 'Look, then Publish' : 'See the checks', 'vetted' => 'Publish', 'live' => 'Publish next step', 'off' => 'Roll back', default => 'Open' };
    }

    /** The Pulse case's steps: its next move as a button (decisions: a step doable from the case is a button). */
    public static function pulseSteps(PDO $pdo, int $id, callable $s): array
    {
        $r = self::get($pdo, $id);
        $page = '/admin/config/releases#rel-' . $id;
        if (!$r) return [$s('Open Releases', 'The release isn\'t here any more.', ['tool', '/admin/config/releases'])];
        $read = $s('Read the release', 'Its files, plan and checks are on System Configuration → Releases.', ['tool', $page]);
        if ($r['state'] === 'live' && $r['paused']) return [$read,
            $s('Carry on', 'If the failed check doesn\'t matter, carry on from this step.', ['do', 'rel_resume', 'Carry on']),
            $s('Turn it off', 'Its switch off for everyone at once; the files stay.', ['do', 'rel_off', 'Turn off']),
            $s('Roll it back', 'The previous copy of every file goes back.', ['do', 'rel_back', 'Roll back'])];
        return match ($r['state']) {
            'planned' => [$read, $s('Approve the plan', 'Check its title, switch and how it advances on the page first (it can be changed there).', ['do', 'rel_approve', 'Approve the plan'])],
            'approved' => [$read, $s('Put it on staging', 'Copies its files to staging.trvgo.us, runs its migrations there and its checks.', ['do', 'rel_stage', 'Put it on staging'])],
            'staged' => $r['checks_ok'] ? [$read, $s('Look at it on staging, then publish it', 'Open staging (its site manager has Publish ▾); Publish here works once someone has looked at it there.', ['do', 'rel_publish', 'Publish'])]
                                        : [$read, $s('Fix what failed', 'Upload a fixed zip as a new release, or put this one on staging again.', ['do', 'rel_stage', 'Put it on staging again'])],
            'vetted' => [$read, $s('Publish it', 'Or schedule it on the page.', ['do', 'rel_publish', 'Publish'])],
            'live' => [$read, $s('Publish the next step', 'It waits for you (it advances on Publish next step).', ['do', 'rel_next', 'Publish next step'])],
            'off' => [$read, $s('Roll it back', 'Its files are still live behind the switch.', ['do', 'rel_back', 'Roll back'])],
            default => [$read],
        };
    }
}
