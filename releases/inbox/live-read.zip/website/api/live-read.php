<?php
// /api/live-read.php — read-only views of the live site for building it (Jason, 2026-11-23: "for building we must use
// live data"; his Approve of this channel, the same day, reviewed by the session manager). Locked by its own token:
// Authorization: Bearer <LIVE_READ_TOKEN> (in .env; given to a build session through its secure credential form, never
// in chat or the repo). Off while LIVE_READ_TOKEN isn't set.
//   /api/live-read.php?make=1   the Founder, signed in: a page with Make the key (or, once set, Make a new one: the old one
//                               stops working). Only the button's POST, with the site's security token, makes it: the site
//                               writes it to .env through the one writer (EnvSettings::setSecret, WRITE_ONLY) and shows it
//                               this once, to give to the build session's form. A GET writes nothing. Never on staging.
//   GET /api/live-read.php?read=orders_open      the open client orders (decisions/0101): number, client, status, stage,
//                                                pay terms, total, paid, balance, from QuickBooks or not, next step
//   GET /api/live-read.php?read=order&id=N       one client order: its numbers, items, payments, history, work orders
// Only these named reads, each one fixed SELECTs with bound values: nothing here writes, and nothing else can be asked.
// No emails, phones, addresses, tokens or payment links are returned (any in a note or title is masked). At most 60 reads an hour. Every read goes in the
// Control Board's Logbook (ControlLog, kind 'read'): which read, when, by "a build session". What it returns stays out
// of the repo (CLAUDE.md, "Build with live data").
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');

Database::readEnv();
if (($_GET['make'] ?? '') === '1') {   // the key, made by the site and shown this once to the Founder
    require_once __DIR__ . '/../../app/ui/page-shell.php';
    require_once __DIR__ . '/../../app/admin/Access.php';
    require_once __DIR__ . '/../../app/lib/Staging.php';
    require_once __DIR__ . '/../../app/lib/EnvSettings.php';
    require_once __DIR__ . '/../../app/lib/ControlLog.php';
    header('Content-Type: text/html; charset=utf-8');
    $me = Auth::currentUser();
    $say = function (string $title, string $body) { tv_page_start($title); echo '<div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">' . htmlspecialchars($title) . '</h1>' . $body . '</div>'; tv_page_end(); exit; };
    if ($me === null) $say('Sign in first', '<p class="text-sm mt-2">Sign in as the Founder, then open this link again: <a class="underline" href="/login.php?next=' . rawurlencode('/api/live-read.php?make=1') . '">Sign in</a>.</p>');
    if (empty($me['is_admin']) || (Access::who()[0] ?? '') !== 'founder') $say('The Founder makes this key', '<p class="text-sm mt-2">Only the Founder can make the live reads\' key. Ask Jason, or write to support@traversence.com.</p>');
    if (Staging::here()) $say('Not on staging', '<p class="text-sm mt-2">Staging never writes .env. Open this on the live site: <a class="underline" href="https://traversence.com/api/live-read.php?make=1">traversence.com/api/live-read.php?make=1</a>.</p>');
    $have = trim((string) (getenv('LIVE_READ_TOKEN') ?: '')) !== '';
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $button = fn (bool $again) => '<form method="post" action="/api/live-read.php?make=1" style="margin-top:.8rem" data-lr-make><input type="hidden" name="csrf" value="' . htmlspecialchars($csrf) . '"><input type="hidden" name="do" value="make">'
        . '<button class="go-btn main"' . ($again ? ' data-confirm="Make a new key? The old one stops working at once, and the build session needs the new one." data-yes="Make a new key" data-danger' : ' data-confirm="Make the live reads key? It\'s shown once." data-yes="Make the key"') . '>' . ($again ? 'Make a new one' : 'Make the key') . '</button></form>'
        . '<script>document.querySelectorAll("[data-lr-make]").forEach(function (f) { f.addEventListener("submit", function () { var b = f.querySelector("button"); if (window.TvAsk && TvAsk.busy) TvAsk.busy(b, true); }); });</script>';
    // a page shows the button; only its POST (with the site's security token) makes or replaces the key
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST' || ($_POST['do'] ?? '') !== 'make') {
        if ($have) $say('The live reads\' key is set', '<p class="text-sm mt-2">It was shown once when it was made, and isn\'t shown again. Lost it? Make a new one: the old one stops working, and the build session needs the new one.</p>' . $button(true));
        $say('Make the live reads key', '<p class="text-sm mt-2">The site makes it, keeps it in its settings and shows it to you once, to paste into the secure form in your Orders session.</p>' . $button(false));
    }
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? '')) || $csrf === '') $say('This page had expired', '<p class="text-sm mt-2">Nothing was changed. <a class="underline" href="/api/live-read.php?make=1">Open it again</a> and press the button.</p>');
    $key = bin2hex(random_bytes(24));
    try { EnvSettings::setSecret('LIVE_READ_TOKEN', $key); } catch (Throwable $x) { $say('It couldn\'t be saved', '<p class="text-sm mt-2">' . htmlspecialchars($x->getMessage()) . ' Nothing was changed. Try again, or write to support@traversence.com.</p>'); }
    try { ControlLog::add(Database::connection(), 'read', 'live-read', $have ? 'A new live reads key was made (the old one stops working)' : 'The live reads key was made', (string) ($me['display_name'] ?? 'the Founder')); } catch (Throwable $x) {}
    $say('Your live reads key', '<p class="text-sm mt-2">Saved in the site\'s settings. Copy it now: it isn\'t shown again.</p>'
        . '<section data-copy="Live reads key" style="margin:.8rem 0;padding:.8rem;border:1px solid #EADFC4;border-radius:.5rem;background:#FFFBF2"><code style="word-break:break-all;font-size:1rem">' . htmlspecialchars($key) . '</code></section>'
        . '<p class="text-sm">Paste it into the secure form in your Orders session (for traversence.com). Don\'t paste it into a chat.</p>'
        . '<script src="/js/tv-copy.js"></script>');
}
$want = (string) (getenv('LIVE_READ_TOKEN') ?: '');
if ($want === '' || strlen($want) < 32) Response::error('Live reads are off (no LIVE_READ_TOKEN of 32 characters or more).', 503, 'off');
$got = '';
if (preg_match('/^Bearer\s+(\S+)$/i', (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ''), $m)) $got = $m[1];
if ($got === '') $got = (string) ($_SERVER['HTTP_X_LIVE_READ_TOKEN'] ?? '');
if (!hash_equals($want, $got)) Response::error('Not allowed.', 401, 'not_allowed');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') Response::error('Reads only.', 405, 'reads_only');

require_once __DIR__ . '/../../app/lib/Orders.php';
require_once __DIR__ . '/../../app/lib/ControlLog.php';
$pdo = Database::connection();
$read = (string) ($_GET['read'] ?? '');
$reads = ['orders_open' => 'The open client orders', 'order' => 'One client order'];
if (!isset($reads[$read])) Response::error('Ask for one of: ' . implode(', ', array_keys($reads)) . '.', 400, 'unknown_read');

// at most 60 reads an hour (a build reads a few; more is a loop going wrong)
// counted in page_cache; if it can't be read or written the read is refused, never let through uncounted (fail closed)
$hour = 'live-read:' . gmdate('YmdH');
try {
    $st = $pdo->prepare('SELECT body FROM page_cache WHERE cache_key = ? AND expires_at > NOW()'); $st->execute([$hour]);
    $v = json_decode((string) ($st->fetchColumn() ?: '{"v":0}'), true); $n = (int) ($v['v'] ?? 0);
    if ($n >= 60) Response::error('That\'s 60 reads this hour: try again next hour.', 429, 'rate');
    $pdo->prepare('DELETE FROM page_cache WHERE cache_key = ?')->execute([$hour]);
    $pdo->prepare('INSERT INTO page_cache (cache_key, body, expires_at) VALUES (?, ?, ?)')->execute([$hour, json_encode(['v' => $n + 1]), date('Y-m-d H:i:s', time() + 3700)]);
} catch (PDOException $x) {
    error_log('live-read limit: ' . $x->getMessage());
    Response::error('Live reads are paused: the limit can\'t be checked. Nothing was read; try again later, or write to support@traversence.com.', 503, 'limit_unchecked');
}

$rows = function (string $sql, array $a = []) use ($pdo): array { $st = $pdo->prepare($sql); $st->execute($a); return $st->fetchAll(PDO::FETCH_ASSOC); };
// words people wrote (history notes, titles) can carry an email or a phone number: masked, so none leaves the site
$mask = fn (string $s) => preg_replace(['/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/', '/\+?\d[\d ().\-]{8,}\d/'], ['[email]', '[phone]'], $s);
$paidOf = fn (int $id) => (int) ($rows("SELECT COALESCE(SUM(amount_cents), 0) AS p FROM order_ledger WHERE order_id = ? AND kind IN ('charge', 'deposit')", [$id])[0]['p'] ?? 0);
$next = function (array $o): string { try { require_once __DIR__ . '/../../app/lib/Pulse.php'; $f = Pulse::orderSteps($o); return $f['next'] ? (string) $f['next'][1] : ''; } catch (Throwable $x) { return ''; } };
$card = fn (array $o) => ['id' => (int) $o['id'], 'no' => Orders::no($o), 'client' => $mask((string) ($o['client_company'] ?: $o['bill_name'])), 'status' => (string) $o['status'],
    'stage' => (string) ($o['stage'] ?? ''), 'pay_mode' => (string) ($o['pay_mode'] ?? ''), 'total_cents' => (int) $o['total_cents'], 'paid_cents' => $paidOf((int) $o['id']),
    'from_quickbooks' => str_starts_with((string) ($o['approved_name'] ?? ''), 'QuickBooks invoice '), 'test' => in_array((string) ($o['qb_env'] ?? ''), ['sandbox', 'mock'], true),
    'next_step' => $next($o), 'created_at' => (string) ($o['created_at'] ?? ''), 'updated_at' => (string) ($o['updated_at'] ?? '')];

if ($read === 'orders_open') {
    $list = [];
    foreach ($rows("SELECT * FROM orders WHERE created_by IS NOT NULL AND created_by > 0 AND status NOT IN ('void', 'refunded') AND COALESCE(stage, '') <> 'complete' ORDER BY id DESC LIMIT 400") as $o) {
        $c = $card($o); $c['balance_cents'] = max(0, $c['total_cents'] - $c['paid_cents']); $list[] = $c;
    }
    $out = ['read' => $read, 'at' => gmdate('c'), 'count' => count($list), 'orders' => $list];
    $what = 'Read the open client orders (' . count($list) . ')';
} else {
    $id = (int) ($_GET['id'] ?? 0);
    $o = $id > 0 ? ($rows('SELECT * FROM orders WHERE id = ? AND created_by IS NOT NULL AND created_by > 0', [$id])[0] ?? null) : null;
    if (!$o) Response::error('There\'s no client order ' . $id . '.', 404, 'not_found');
    $c = $card($o);
    $c += ['subtotal_cents' => (int) $o['subtotal_cents'], 'tax_cents' => (int) $o['tax_cents'], 'deposit_pct' => (int) ($o['deposit_pct'] ?? 0), 'deposit_cents' => (int) ($o['deposit_cents'] ?? 0),
           'invoice_no' => (string) ($o['invoice_no'] ?? ''), 'sent_at' => (string) ($o['sent_at'] ?? ''), 'approved_at' => (string) ($o['approved_at'] ?? ''), 'paid_at' => (string) ($o['paid_at'] ?? ''),
           'expires_at' => (string) ($o['expires_at'] ?? ''), 'delivery' => (string) ($o['delivery'] ?? ''), 'ship_mode' => (string) ($o['ship_mode'] ?? ''), 'qb_env' => (string) ($o['qb_env'] ?? '')];
    $c['balance_cents'] = max(0, $c['total_cents'] - $c['paid_cents']);
    $c['items'] = array_map(fn ($l) => ['id' => (int) $l['id'], 'product' => (string) $l['product'], 'title' => $mask((string) $l['title']), 'options' => $mask((string) ($l['options'] ?? '')), 'qty' => (int) $l['qty'],
        'unit_cents' => (int) $l['unit_cents'], 'ship_cents' => (int) ($l['ship_cents'] ?? 0), 'taxable' => (int) ($l['taxable'] ?? 0), 'status' => (string) $l['status'], 'item_status' => (string) ($l['item_status'] ?? '')], Orders::lines($pdo, $id));
    $c['payments'] = $rows('SELECT kind, amount_cents, method, created_at FROM order_ledger WHERE order_id = ? ORDER BY id', [$id]);
    $c['history'] = array_map(fn ($e) => ['event' => (string) $e['event'], 'note' => $mask((string) $e['note']), 'created_at' => (string) $e['created_at']], $rows('SELECT event, note, created_at FROM order_events WHERE order_id = ? ORDER BY id DESC LIMIT 60', [$id]));
    try { $c['work_orders'] = $rows('SELECT wo_no, vendor, status, cost_cents, sent_at, status_at FROM order_work_orders WHERE order_id = ? ORDER BY id', [$id]); } catch (Throwable $x) { $c['work_orders'] = []; }
    $out = ['read' => $read, 'at' => gmdate('c'), 'order' => $c];
    $what = 'Read client order ' . $c['no'];
}
ControlLog::add($pdo, 'read', 'live-read', $what, 'a build session', 'For building with live data (Jason, 2026-11-23)');
Response::json(['ok' => true] + $out);
