<?php

declare(strict_types=1);

/**
 * Mailer.php
 *
 * Minimal authenticated SMTP client — no Composer dependency (matches
 * the rest of this project's approach: Database.php's hand-rolled .env
 * parser, no external libraries). Sends through a real BlueHost mailbox
 * (e.g. noreply@traversence.com) over STARTTLS, not PHP's built-in
 * mail(), so outgoing messages are properly authenticated as coming
 * from the actual domain — meaningfully better inbox placement, which
 * matters specifically because several of this app's emails contain
 * short-lived OTP codes (10-minute expiry): a message that lands in
 * spam and gets seen late is a broken feature, not just an annoyance.
 *
 * Configuration (.env): SMTP_HOST, SMTP_PORT, SMTP_USERNAME,
 * SMTP_PASSWORD, SMTP_FROM_EMAIL, SMTP_FROM_NAME.
 *
 * This talks raw SMTP protocol directly over a socket. It supports the
 * common case (STARTTLS on port 587) correctly; it does not implement
 * every edge case a full library like PHPMailer would (no attachments,
 * no multi-recipient batching, no DKIM signing of its own — DKIM/SPF
 * authentication comes from BlueHost's mail server itself once the
 * mailbox is properly configured in cPanel, not from this class).
 */
final class Mailer
{
    /**
     * @throws RuntimeException on any SMTP-level failure (connection,
     *         auth, or send rejection) — callers should catch this and
     *         decide how to handle a failed send (log and continue is
     *         usually right for non-critical notifications; a claim/
     *         registration flow may want to surface the failure).
     */
    /**
     * $as: another sender set in .env by prefix, e.g. 'ORDERS' reads ORDERS_FROM_EMAIL, ORDERS_FROM_NAME, ORDERS_REPLY_TO and,
     * when that mailbox signs in on its own, ORDERS_SMTP_HOST / _PORT / _USERNAME / _PASSWORD (each falls back to SMTP_*).
     * $html: an HTML version as well (multipart/alternative); mail apps that don't show HTML show $textBody.
     */
    /**
     * A one-time code by email (Jason, 2026-11-11: "can we have the email with the copy code action"; "it is clunky … can we
     * have a url for sending the code to the sign in page?"). The code first in the subject ("297597 is your Traversence
     * staff sign-in code"), which Gmail and phones read to offer Copy code and fill the code box. One card, laid out in
     * tables so Outlook draws it as other mail apps do: the code once, large, in a box that selects with one click; and,
     * with $url, a button that opens the sign-in page with the code filled in (after #, so it never reaches the server,
     * its logs or a mail scanner, and it signs no one in by itself). Plain text kept for mail apps without HTML.
     */
    public static function sendCode(string $toEmail, string $code, string $what, string $textBody, ?string $toName = null, string $url = ''): void
    {
        $e = fn (string $s) => htmlspecialchars($s, ENT_QUOTES);
        $rest = '';
        foreach (preg_split('/\n{2,}/', trim($textBody)) as $para) {
            $para = trim($para);
            if ($para === '' || str_contains($para, $code) || $para === 'Traversence') continue;   // the code and the sign-off are drawn
            $rest .= '<p style="margin:0 0 10px;font-size:14px;line-height:21px;color:#5C4632">' . nl2br($e($para)) . '</p>';
        }
        $font = 'font-family:Segoe UI,Roboto,Helvetica,Arial,sans-serif;';
        $btn = $url !== '' ? '<tr><td align="center" style="padding:6px 28px 22px"><table role="presentation" cellpadding="0" cellspacing="0"><tr>'
             . '<td bgcolor="#92400E" style="border-radius:8px;padding:12px 28px;mso-padding-alt:12px 28px"><a href="' . $e($url) . '" style="display:inline-block;' . $font . 'font-size:16px;font-weight:700;color:#FFFBF2;text-decoration:none"><span style="color:#FFFBF2;text-decoration:none">Sign in with this code</span></a></td>'   // Outlook: its padding on the cell, its colour on the text (2026-11-11: purple and tight)
             . '</tr></table><p style="margin:10px 0 0;' . $font . 'font-size:12px;color:#8A7355">Opens the sign-in page with the code filled in, on the device where you signed in.</p></td></tr>' : '';
        $html = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" bgcolor="#EFE3C8" style="background:#EFE3C8"><tr><td align="center" style="padding:24px 12px">'
              . '<table role="presentation" width="480" cellpadding="0" cellspacing="0" bgcolor="#FFFBF2" style="width:480px;max-width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:12px">'
              . '<tr><td bgcolor="#3E2B1F" style="padding:14px 28px;border-radius:12px 12px 0 0;font-family:Georgia,serif;font-size:20px;font-weight:700;color:#F7EFDC">Traversence</td></tr>'
              . '<tr><td style="padding:24px 28px 8px;' . $font . 'font-size:17px;font-weight:700;color:#3E2B1F">Your ' . $e($what) . '</td></tr>'
              . '<tr><td align="center" style="padding:8px 28px 6px"><table role="presentation" cellpadding="0" cellspacing="0"><tr><td bgcolor="#F7EFDC" style="border:1px solid #CBB98D;border-radius:10px;padding:14px 26px;font-family:Consolas,Menlo,monospace;font-size:34px;font-weight:700;letter-spacing:10px;color:#3E2B1F;user-select:all;-webkit-user-select:all">' . $e($code) . '</td></tr></table></td></tr>'
              . '<tr><td align="center" style="padding:4px 28px 18px;' . $font . 'font-size:12px;color:#8A7355">Click the code once to select it, then copy.</td></tr>'
              . $btn
              . '<tr><td style="padding:0 28px 18px;' . $font . '">' . $rest . '</td></tr>'
              . '<tr><td style="padding:12px 28px;border-top:1px solid #EADFC4;' . $font . 'font-size:12px;color:#8A7355">Traversence · traversence.com · a code is never asked for by phone or chat</td></tr>'
              . '</table></td></tr></table>';
        self::send($toEmail, $code . ' is your Traversence ' . $what, $textBody . ($url !== '' ? "\n\nOr open the sign-in page with the code filled in:\n" . $url : ''), $toName, '', $html);
    }

    public static function send(string $toEmail, string $subject, string $textBody, ?string $toName = null, string $as = '', string $html = ''): void
    {
        require_once __DIR__ . '/Staging.php';
        if (Staging::holdMail($toEmail, $subject, $textBody, $html, $as !== '' ? strtolower($as) : 'smtp')) return;   // the staging copy keeps it to read, never sends it (decisions/0145 Phase 3)
        require_once __DIR__ . '/TestAccounts.php';
        if (TestAccounts::isTestEmail($toEmail)) return;   // a test account: the live site sends it nothing (decisions/0145 §3)
        $env = fn (string $k) => ($as !== '' ? (getenv($as . '_' . $k) ?: '') : '') ?: (getenv($k === 'FROM_EMAIL' || $k === 'FROM_NAME' || $k === 'REPLY_TO' ? 'SMTP_' . $k : $k) ?: '');
        $own = $as !== '' && (getenv($as . '_SMTP_USERNAME') ?: '') !== '';   // its own login: its host and password go with it
        $host = $own ? (getenv($as . '_SMTP_HOST') ?: (getenv('SMTP_HOST') ?: '')) : (getenv('SMTP_HOST') ?: '');
        $port = (int) (($own ? getenv($as . '_SMTP_PORT') : '') ?: (getenv('SMTP_PORT') ?: 587));
        $username = $own ? (string) getenv($as . '_SMTP_USERNAME') : (getenv('SMTP_USERNAME') ?: '');
        $password = $own ? (string) (getenv($as . '_SMTP_PASSWORD') ?: '') : (getenv('SMTP_PASSWORD') ?: '');
        $fromEmail = $env('FROM_EMAIL') ?: $username;
        $fromName = $env('FROM_NAME') ?: 'Traversence';
        // donotreply@ and orders@ are system senders nobody reads (Jason, 2026-10-28): replies go to support@ unless a reply-to is set
        $replyTo = $env('REPLY_TO') ?: (getenv('SMTP_REPLY_TO') ?: 'support@traversence.com');

        // the source map (decisions/0163's note, 2026-11-17): Bluehost's SMTP first; when it fails, Amazon SES (SesMail, the
        // site's existing sender, which asks StagingGate first); when both fail, the SMTP error is thrown as before, so the
        // caller's "waits" (log, retry, tell the person) still happens
        try {
            self::smtp($host, $port, $username, $password, $fromEmail, $fromName, $replyTo, $toEmail, $toName, $subject, $textBody, $html);
        } catch (Throwable $smtpErr) {
            if (!self::viaSes($toEmail, $toName, $subject, $textBody, $html, $fromEmail, $fromName, $replyTo, $smtpErr->getMessage())) throw $smtpErr;
        }
    }

    /**
     * The backup: the same message through Amazon SES's personal account, only when SES is live and set up (SES_MODE=live,
     * its keys, its database update). Logs the switch. True when SES took it; false sends the caller back to the SMTP error.
     */
    private static function viaSes(string $toEmail, ?string $toName, string $subject, string $textBody, string $html, string $fromEmail, string $fromName, string $replyTo, string $why): bool
    {
        try {
            require_once __DIR__ . '/SesMail.php';
            if (SesMail::mode() !== 'live' || !SesMail::hasKeys('personal')) { error_log('site email: Bluehost SMTP failed (' . mb_substr($why, 0, 160) . '); no backup (Amazon SES isn\'t live)'); return false; }
            require_once __DIR__ . '/Database.php';
            $pdo = Database::connection();
            if (!SesMail::ready($pdo)) { error_log('site email: Bluehost SMTP failed (' . mb_substr($why, 0, 160) . '); no backup (SES\'s database update hasn\'t run)'); return false; }
            $local = strtolower((string) strstr($fromEmail, '@', true)) ?: 'notices';
            $r = SesMail::send($pdo, ['account' => 'personal', 'from_local' => $local, 'from_domain' => 'send.traversence.com', 'from_name' => $fromName,
                'to' => $toEmail, 'to_name' => (string) $toName, 'subject' => $subject, 'text' => $textBody, 'html' => $html, 'reply_to' => $replyTo,
                'sender' => 'traversence', 'purpose' => 'site_email', 'scope' => 'site_email',
                'why' => 'This is the site\'s own email (sign-in codes, account notices, receipts), sent through our backup mail service.']);
            $ok = ($r['status'] ?? '') === 'sent';
            error_log('site email: Bluehost SMTP failed (' . mb_substr($why, 0, 160) . '); switched to the backup, Amazon SES: ' . ($ok ? 'sent' : 'not sent (' . ($r['status'] ?? '?') . ', send #' . (int) ($r['id'] ?? 0) . ')'));
            return $ok;
        } catch (Throwable $x) {
            error_log('site email: Bluehost SMTP failed (' . mb_substr($why, 0, 160) . '); the backup, Amazon SES, failed too: ' . mb_substr($x->getMessage(), 0, 160));
            return false;
        }
    }

    /** One message through Bluehost's SMTP (the first source). Throws on any failure before the server accepts the message. */
    private static function smtp(string $host, int $port, string $username, string $password, string $fromEmail, string $fromName, string $replyTo, string $toEmail, ?string $toName, string $subject, string $textBody, string $html): void
    {
        // @gate: called only from send(), after Staging::holdMail has kept staging's mail (decisions/0165)
        if ($host === '' || $username === '' || $password === '') {
            throw new RuntimeException(
                'SMTP is not configured. Set SMTP_HOST, SMTP_USERNAME, SMTP_PASSWORD in .env.'
            );
        }

        // Port 465 = implicit SSL/TLS: the encrypted handshake must happen
        // the instant the socket connects, before any SMTP commands are
        // exchanged — connecting with a plain tcp:// socket here (as an
        // earlier version of this file did for every port) doesn't work,
        // since a real port-465 server never sends a plaintext greeting.
        // Port 587 (and others) use the STARTTLS upgrade path instead:
        // connect plaintext, greet, then upgrade mid-conversation.
        $scheme = $port === 465 ? 'ssl' : 'tcp';
        $socket = @stream_socket_client(
            "{$scheme}://{$host}:{$port}",
            $errno,
            $errstr,
            15,
            STREAM_CLIENT_CONNECT
        );
        if ($socket === false) {
            throw new RuntimeException("SMTP connection failed: {$errstr} ({$errno})");
        }
        stream_set_timeout($socket, 15);

        try {
            self::expect($socket, 220); // server greeting (already TLS-wrapped if port 465)

            self::command($socket, 'EHLO ' . self::localHostname(), 250);

            // STARTTLS upgrade — only for the plaintext-then-upgrade path
            // (port 587 and similar). Port 465 is already fully encrypted
            // from the initial connection above; issuing STARTTLS again
            // on an already-TLS connection would be a protocol error.
            if ($port !== 465) {
                self::command($socket, 'STARTTLS', 220);
                if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    throw new RuntimeException('SMTP STARTTLS negotiation failed.');
                }
                // EHLO must be resent after STARTTLS per RFC 3207.
                self::command($socket, 'EHLO ' . self::localHostname(), 250);
            }

            self::command($socket, 'AUTH LOGIN', 334);
            self::command($socket, base64_encode($username), 334);
            self::command($socket, base64_encode($password), 235);

            self::command($socket, "MAIL FROM:<{$fromEmail}>", 250);
            self::command($socket, "RCPT TO:<{$toEmail}>", 250);
            self::command($socket, 'DATA', 354);

            $headers = self::buildHeaders($fromEmail, $fromName, $toEmail, $toName, $subject, $replyTo);
            if ($html !== '') {   // both versions, each base64 so no line runs past SMTP's limit
                $b = 'tv' . bin2hex(random_bytes(12));
                $headers = str_replace("Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit", 'Content-Type: multipart/alternative; boundary="' . $b . '"', $headers);
                $part = fn (string $type, string $body) => "--{$b}\r\nContent-Type: {$type}; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . rtrim(chunk_split(base64_encode($body), 76, "\r\n")) . "\r\n";
                $textBody = "This message has an HTML version.\r\n" . $part('text/plain', $textBody) . $part('text/html', $html) . "--{$b}--";
            }
            // the blank line between the headers and the body (RFC 5322): without it the first line of the message was read as a header
            $message = $headers . "\r\n\r\n" . self::escapeDots($textBody) . "\r\n.";
            self::command($socket, $message, 250);

            // the server has the message: a failed goodbye isn't a failed send (the backup would send it twice)
            try { self::command($socket, 'QUIT', 221); } catch (Throwable $x) {}
        } finally {
            fclose($socket);
        }
    }

    private static function buildHeaders(
        string $fromEmail,
        string $fromName,
        string $toEmail,
        ?string $toName,
        string $subject,
        string $replyTo = 'support@traversence.com'
    ): string {
        $to = $toName !== null ? "\"{$toName}\" <{$toEmail}>" : $toEmail;
        $lines = [
            'From: "' . str_replace('"', '', $fromName) . "\" <{$fromEmail}>",
            "To: {$to}",
            // replies to any site email (sent from a no-reply address) reach a person: support@ (SMTP_REPLY_TO overrides)
            'Reply-To: ' . $replyTo,
            'Subject: ' . self::encodeSubject($subject),
            'Date: ' . date('r'),
            'Message-ID: <' . bin2hex(random_bytes(16)) . '@' . self::localHostname() . '>',
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: 8bit',
        ];
        return implode("\r\n", $lines);
    }

    private static function encodeSubject(string $subject): string
    {
        // RFC 2047 encoding for non-ASCII subjects; plain ASCII subjects
        // pass through unmodified for readability in transit logs.
        return preg_match('/[^\x20-\x7E]/', $subject)
            ? '=?UTF-8?B?' . base64_encode($subject) . '?='
            : $subject;
    }

    /**
     * SMTP DATA section requires any line starting with a literal "."
     * to be escaped as ".." — otherwise the server would interpret a
     * lone "." line in the body as the end-of-message marker early.
     */
    private static function escapeDots(string $body): string
    {
        $normalized = str_replace(["\r\n", "\r"], "\n", $body);
        $lines = explode("\n", $normalized);
        foreach ($lines as &$line) {
            if (str_starts_with($line, '.')) {
                $line = '.' . $line;
            }
        }
        return implode("\r\n", $lines);
    }

    private static function localHostname(): string
    {
        $host = getenv('APP_URL') ?: 'traversence.com';
        return preg_replace('#^https?://#', '', rtrim($host, '/'));
    }

    private static function command($socket, string $command, int $expectedCode): string
    {
        fwrite($socket, $command . "\r\n");
        return self::expect($socket, $expectedCode);
    }

    private static function expect($socket, int $expectedCode): string
    {
        $response = '';
        while (($line = fgets($socket, 512)) !== false) {
            $response .= $line;
            // Multi-line SMTP responses use a hyphen after the code on
            // every line except the last (e.g. "250-" ... "250 ").
            if (strlen($line) >= 4 && $line[3] === ' ') {
                break;
            }
        }
        if ($response === '') {
            throw new RuntimeException('SMTP server closed the connection unexpectedly.');
        }
        $code = (int) substr($response, 0, 3);
        if ($code !== $expectedCode) {
            throw new RuntimeException("SMTP error: expected {$expectedCode}, got: " . trim($response));
        }
        return $response;
    }
}
