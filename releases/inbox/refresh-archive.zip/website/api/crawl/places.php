<?php
// api/crawl/places.php — the worker's Google check (decisions/0085). Crawler token only.
//   GET ?limit=N                 -> {listings: [{id, name, address, city, state, zip, lat, lon}]}   the next to check
//   POST {results: [{id, found, place_id, name, address, status}]} -> {matched, closed}           what Google said
//
// Which listings: on the site, never one whose address is kept private (a shelter: ListingSafety), never checked or
// checked more than 90 days ago (never longer: decisions/0133, cadence by band), the newest first. What's kept (Google's terms allow keeping only its place ID): the
// place ID when Google's place is this listing (its name, and its street number or ZIP), when it was checked, and
// whether it matched. Google's name, address and status aren't stored. A listing Google lists as permanently closed
// becomes a "Closed?" item in Review for a person to check; nothing is closed on Google's word alone.
declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/ListingSafety.php';
require_once __DIR__ . '/../../../app/lib/crawler/AutoImport.php';

$meta = fn (array $r, string $k) => is_string($v = json_decode((string) ($r[$k] ?? ''), true)) ? $v : '';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $limit = max(1, min(25, (int) ($_GET['limit'] ?? 5)));
    $old = date('Y-m-d', time() - 90 * 86400);
    $st = $pdo->prepare("SELECT e.id, e.name, e.category_id, e.primary_zip, e.latitude, e.longitude, a.meta_value AS address, c.meta_value AS city, s.meta_value AS state, g.meta_value AS google
                           FROM entities e
                           LEFT JOIN entity_metadata a ON a.entity_id = e.id AND a.meta_key = 'address'
                           LEFT JOIN entity_metadata c ON c.entity_id = e.id AND c.meta_key = 'city'
                           LEFT JOIN entity_metadata s ON s.entity_id = e.id AND s.meta_key = 'state'
                           LEFT JOIN entity_metadata g ON g.entity_id = e.id AND g.meta_key = 'google'
                           LEFT JOIN entity_metadata cl ON cl.entity_id = e.id AND cl.meta_key = 'closed'
                           LEFT JOIN entity_metadata w ON w.entity_id = e.id AND w.meta_key = 'website' AND w.meta_value NOT IN ('', '\"\"', 'null')
                           LEFT JOIN entity_metadata ph ON ph.entity_id = e.id AND ph.meta_key = 'phone' AND ph.meta_value NOT IN ('', '\"\"', 'null')
                           LEFT JOIN listing_confidence lc ON lc.entity_id = e.id
                           LEFT JOIN entity_metadata cs ON cs.entity_id = e.id AND cs.meta_key = 'closed_signal'
                          WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND cl.entity_id IS NULL
                            AND (g.entity_id IS NULL OR JSON_UNQUOTE(JSON_EXTRACT(g.meta_value, '$.checked')) < ?)
                          -- §12's order (decisions/0163, F5): never checked first; then a phone with no website (Google lifts those most),
                          -- then a find already at the score line (35, W1's setting), then the newest. Order only: the paced budget decides how many
                          -- ours first (decisions/0163's source map, W2 Still open?): a listing our own copies or its website flag as
                          -- possibly closed (closed_signal) is checked before the rest
                          ORDER BY cs.entity_id IS NULL, g.entity_id IS NOT NULL, CASE WHEN w.entity_id IS NULL AND ph.entity_id IS NOT NULL THEN 0 WHEN COALESCE(lc.score, 0) >= ? THEN 1 ELSE 2 END, e.created_at DESC LIMIT " . ($limit * 4));
    $line = 35;
    try { require_once __DIR__ . '/../../../app/lib/WorkflowSettings.php'; $line = (int) (WorkflowSettings::current($pdo, 'W1')['google_line'] ?? 35) ?: 35; } catch (Throwable $e) {}
    $st->execute([$old, $line]);
    $out = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
        if (ListingSafety::isConfidential($r['category_id'] !== null ? (int) $r['category_id'] : null, (string) $r['name'])) continue;   // never sent anywhere
        $city = $meta($r, 'city');
        if ($city === '' && $meta($r, 'address') === '') continue;
        $out[] = ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'address' => $meta($r, 'address'), 'city' => $city, 'state' => $meta($r, 'state'),
                  'zip' => (string) $r['primary_zip'], 'lat' => $r['latitude'] !== null ? (float) $r['latitude'] : null, 'lon' => $r['longitude'] !== null ? (float) $r['longitude'] : null];
        if (count($out) >= $limit) break;
    }
    Response::json(['ok' => true, 'listings' => $out]);
}

Response::requireMethod('POST');
$b = Response::jsonBody();
$matched = 0; $closed = 0;
$put = $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at) VALUES (?, 'google', ?, 'ai_crawler', 0, NOW(), NOW())
                      ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), updated_at = NOW()");
foreach (array_slice((array) ($b['results'] ?? []), 0, 50) as $x) {
    $id = (int) ($x['id'] ?? 0);
    if ($id <= 0) continue;
    $st = $pdo->prepare("SELECT e.id, e.name, e.primary_zip, a.meta_value AS address FROM entities e LEFT JOIN entity_metadata a ON a.entity_id = e.id AND a.meta_key = 'address' WHERE e.id = ? AND e.entity_type = 'merchant'");
    $st->execute([$id]);
    $e = $st->fetch(PDO::FETCH_ASSOC);
    if (!$e) continue;
    // Google's place is this listing when it has this listing's name (or one of its other names), and its street
    // number (or, with none, its ZIP)
    $gName = (string) ($x['name'] ?? ''); $gAddr = (string) ($x['address'] ?? '');
    $names = [(string) $e['name']];
    $aka = $pdo->prepare("SELECT meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key = 'aka'"); $aka->execute([$id]);
    foreach ((array) json_decode((string) $aka->fetchColumn(), true) as $n) if (is_string($n)) $names[] = $n;
    $nameOk = false; foreach ($names as $n) if (AutoImport::sameName($n, $gName) >= 0.6) { $nameOk = true; break; }
    $addr = $meta($e, 'address');
    $num = preg_match('/^\s*(\d+)/', $addr, $m) ? $m[1] : '';
    $zip = substr((string) $e['primary_zip'], 0, 5);
    // a street number must be Google's too; a listing with none (a route, a junction) matches on its ZIP only when
    // Google's address has no street number either
    $gNum = preg_match('/^\s*(\d+)/', $gAddr, $mm) ? $mm[1] : '';
    $placeOk = $num !== '' ? $gNum === $num : ($gNum === '' && $zip !== '' && str_contains($gAddr, $zip));
    $isIt = !empty($x['found']) && $nameOk && $placeOk;
    $pid = $isIt ? substr(preg_replace('/[^A-Za-z0-9_-]/', '', (string) ($x['place_id'] ?? '')), 0, 200) : '';
    $put->execute([$id, json_encode(['place_id' => $pid, 'checked' => date('Y-m-d'), 'matched' => $isIt], JSON_UNESCAPED_SLASHES)]);
    if (!$isIt) continue;
    $matched++;
    // its Google place, kept as a link in the listing's identity: where to look, never evidence (decisions/0133)
    try {
        require_once __DIR__ . '/../../../app/lib/Identity.php';
        if ($pid !== '' && Identity::ready($pdo)) {
            Identity::add($pdo, 'listing', $id, 'social', 'https://www.google.com/maps/place/?q=place_id:' . $pid, ['kind' => 'evidence', 'url' => 'https://www.google.com/maps/place/?q=place_id:' . $pid, 'label' => 'Google Maps', 'by' => 0]);
            Identity::recompute($pdo, 'listing', $id);
        }
    } catch (Throwable $ix) { error_log('places identity: ' . $ix->getMessage()); }
    // Google lists it as permanently closed: a person checks (Review → Closed?), once
    if (($x['status'] ?? '') === 'CLOSED_PERMANENTLY') {
        $dup = $pdo->prepare("SELECT 1 FROM suggestions WHERE entity_id = ? AND kind = 'closed' AND status = 'new' LIMIT 1"); $dup->execute([$id]);
        if (!$dup->fetchColumn()) {
            $pdo->prepare("INSERT INTO suggestions (kind, topic, entity_id, target, target_name, place_key, section, note, context, site_key, phone10, user_id, device_hash, created_at)
                            VALUES ('closed', 'business', ?, '', ?, '', '', ?, 'google', '', '', NULL, 'system:google', NOW())")
                ->execute([$id, mb_substr((string) $e['name'], 0, 200), 'Google lists this place as permanently closed. Check before marking it closed (call it, or look for a recent sign it\'s open).']);
            $closed++;
        }
    }
}
Response::json(['ok' => true, 'matched' => $matched, 'closed' => $closed]);
