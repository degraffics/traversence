<?php
// app/lib/StagingSync.php — keeping staging a mirror of live while keeping staging's work (decisions/0165 §3). Runs on
// the live site only (the push job, the nightly pass, Catch up now): each realm's live login reaches its live database
// and its staging copy on the same server (StagingSite: "live's may write to their staging copies"), so every pass runs
// per pair, by that realm's own login, and no login crosses a wall (0110).
//
//   the base     stg_base (in each staging database): per row, the two fingerprints taken when the sides last matched,
//                live's (lh) and staging's (sh, which differs: staging's copy of a person's row is stripped)
//   the changes  stg_changes: triggers on staging's tables (staging only) keep each row as it was the first time staging
//                changed it since the base, with who changed it (@stg_actor, @stg_test: Staging::tag). Catch-up's own
//                writes run with @stg_sync set, which the triggers skip
//   the outbox   stg_outbox (in each live database, beside the tables it notes): a one-statement trigger notes the table,
//                key and kind of each write on live; the push job (staging_push_tick, every minute) sends each to staging
//                and clears it. Installed only when "Keep staging caught up" is switched on (shipped off); Publish's own
//                writes run with @stg_pub set, which it skips
//   catch-up     a live change comes into staging for a row staging didn't touch; a row both changed goes on the
//                conflicts list, untouched; a row staging made under a number live now uses is moved to the next free
//                number first, every reference with it (stg_renumber)
//   the night    the full pass (staging_night_tick, 02:13 Arizona): every row's fingerprint against the base, which finds
//                a failed push, a delete the database cascaded and a change made outside the code
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/staging-tables.php';
require_once __DIR__ . '/StagingIds.php';
require_once __DIR__ . '/StagingMerge.php';

final class StagingSync
{
    /** realm => [PDO (live's login for that realm), live database, staging database]; from StagingSite, or set by tests. */
    private static ?array $pairs = null;
    private static array $meta = [];
    private static ?array $refs = null;
    /** [test user ids, test staff ids, salt]; from StagingSite, or set by tests. */
    private static ?array $strip = null;
    public const BATCH = 500;

    public static function usePairs(array $pairs, array $strip = [[], [], 'test-salt']): void { self::$pairs = $pairs; self::$strip = $strip; self::$meta = []; self::$refs = null; }

    public static function pairs(): array
    {
        if (self::$pairs !== null) return self::$pairs;
        require_once __DIR__ . '/StagingSite.php';
        return self::$pairs = StagingSite::pairs(Database::connection());
    }

    private static function pair(string $realm): array
    {
        $p = self::pairs()[$realm] ?? null;
        if (!$p) throw new RuntimeException('Staging has no ' . $realm . ' database.');
        return $p;
    }

    public static function q(string $db, string $t): string { return '`' . str_replace('`', '', $db) . '`.`' . str_replace('`', '', $t) . '`'; }
    private static function c(string $col): string { return '`' . str_replace('`', '', $col) . '`'; }

    // ---- staging's own tables, in each staging database ----------------------------------------------------------------

    public static function ensure(string $realm): void
    {
        static $done = [];
        if (isset($done[$realm])) return;
        [$c, , $s] = self::pair($realm);
        $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($s, 'stg_base') . ' (tbl VARCHAR(64) NOT NULL, k VARCHAR(191) NOT NULL, lh CHAR(32) NOT NULL, sh CHAR(32) NOT NULL, at DATETIME NOT NULL, PRIMARY KEY (tbl, k)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($s, 'stg_changes') . ' (tbl VARCHAR(64) NOT NULL, k VARCHAR(191) NOT NULL, op CHAR(1) NOT NULL, before_row LONGTEXT NULL, actor VARCHAR(40) NOT NULL DEFAULT \'\', test TINYINT NOT NULL DEFAULT 0, at DATETIME NOT NULL, mark VARCHAR(8) NOT NULL DEFAULT \'\', PRIMARY KEY (tbl, k), KEY idx_stg_changes_at (at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($s, 'stg_renumber') . ' (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tbl VARCHAR(64) NOT NULL, old_id BIGINT NOT NULL, new_id BIGINT NOT NULL, why VARCHAR(20) NOT NULL, refs INT NOT NULL DEFAULT 0, at DATETIME NOT NULL, KEY idx_stg_renumber (tbl, old_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($s, 'stg_conflicts') . ' (tbl VARCHAR(64) NOT NULL, k VARCHAR(191) NOT NULL, found_at DATETIME NOT NULL, base_row LONGTEXT NULL, stg_row LONGTEXT NULL, live_row LONGTEXT NULL, clash TEXT NULL, why VARCHAR(255) NOT NULL DEFAULT \'\', choice TEXT NULL, settled_at DATETIME NULL, settled_by INT NULL, PRIMARY KEY (tbl, k)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($s, 'pub_journal') . ' (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, pub VARCHAR(16) NOT NULL, seq INT NOT NULL, tbl VARCHAR(64) NOT NULL, k VARCHAR(191) NOT NULL, op VARCHAR(8) NOT NULL,
            before_row LONGTEXT NULL, after_h CHAR(32) NULL, new_k VARCHAR(191) NULL, done TINYINT NOT NULL DEFAULT 0, undone TINYINT NOT NULL DEFAULT 0, note VARCHAR(255) NOT NULL DEFAULT \'\', at DATETIME NOT NULL, KEY idx_pub_journal (pub, seq)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $done[$realm] = true;
    }

    // ---- what a table is like (from information_schema, on live's side) ------------------------------------------------

    /** ['cols' => [name => type], 'pk' => [cols], 'auto' => bool (one integer key the database numbers), 'bin' => [binary cols], 'gen' => [generated cols]] or null (no such table / no key). */
    public static function meta(string $realm, string $t): ?array
    {
        $ck = $realm . '.' . $t;
        if (array_key_exists($ck, self::$meta)) return self::$meta[$ck];
        [$c, $l] = self::pair($realm);
        $st = $c->prepare('SELECT COLUMN_NAME, DATA_TYPE, COLUMN_KEY, EXTRA FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION');
        $st->execute([$l, $t]);
        $cols = []; $bin = []; $gen = []; $auto = false;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $x) {
            $n = (string) $x['COLUMN_NAME']; $ty = strtolower((string) $x['DATA_TYPE']);
            $cols[$n] = $ty;
            if (preg_match('/binary|blob/', $ty)) $bin[] = $n;
            if (preg_match('/GENERATED|VIRTUAL|STORED|PERSISTENT/i', (string) $x['EXTRA'])) $gen[] = $n;
            if (stripos((string) $x['EXTRA'], 'auto_increment') !== false) $auto = $n;
        }
        if (!$cols) return self::$meta[$ck] = null;
        $st = $c->prepare("SELECT COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND CONSTRAINT_NAME = 'PRIMARY' ORDER BY ORDINAL_POSITION");
        $st->execute([$l, $t]);
        $pk = array_map('strval', $st->fetchAll(PDO::FETCH_COLUMN));
        if (!$pk) return self::$meta[$ck] = null;   // no primary key: it can't be merged row by row; it follows live
        $one = count($pk) === 1 && preg_match('/int/', $cols[$pk[0]]) === 1;
        return self::$meta[$ck] = ['cols' => $cols, 'pk' => $pk, 'auto' => $one && $auto === $pk[0], 'int' => $one, 'bin' => $bin, 'gen' => $gen];
    }

    /** The tables of a realm worth keeping row by row: Records and Money with a primary key (live's list). */
    public static function tables(string $realm, bool $withMoney = true): array
    {
        [$c, $l] = self::pair($realm);
        $st = $c->prepare("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME");
        $st->execute([$l]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $t) {
            $cl = StagingTables::classOf((string) $t);
            if ($cl === 'records' || ($withMoney && $cl === 'money')) if (self::meta($realm, (string) $t)) $out[] = (string) $t;
        }
        return $out;
    }

    /** SQL for a row's fingerprint (the same on both sides): md5 of each value's bytes in hex, N for null. */
    public static function hashSql(array $cols, string $a): string
    {
        $p = [];
        foreach ($cols as $col) $p[] = 'IFNULL(HEX(CAST(' . $a . '.' . self::c($col) . ' AS BINARY)), \'N\')';
        return 'MD5(CONCAT_WS(\'|\', ' . implode(', ', $p) . '))';
    }

    /** SQL for a row's key as text (the base's k): the key's columns joined by an invisible mark. */
    public static function keySql(array $pk, string $a): string
    {
        if (count($pk) === 1) return 'CAST(' . $a . '.' . self::c($pk[0]) . ' AS CHAR)';
        return 'CONCAT_WS(CHAR(31), ' . implode(', ', array_map(fn ($x) => $a . '.' . self::c($x), $pk)) . ')';
    }

    /** WHERE for one key: [sql, params]. */
    private static function keyWhere(array $pk, string $k, string $a = ''): array
    {
        $vals = count($pk) === 1 ? [$k] : explode(chr(31), $k);
        if (count($vals) !== count($pk)) throw new RuntimeException('A key doesn\'t fit its table.');
        $w = [];
        foreach ($pk as $col) $w[] = ($a !== '' ? $a . '.' : '') . self::c($col) . ' = ?';
        return [implode(' AND ', $w), $vals];
    }

    public static function row(string $realm, string $side, string $t, string $k): ?array
    {
        [$c, $l, $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        [$w, $p] = self::keyWhere($m['pk'], $k);
        $st = $c->prepare('SELECT * FROM ' . self::q($side === 'live' ? $l : $s, $t) . ' WHERE ' . $w . ' LIMIT 1');
        $st->execute($p);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r === false ? null : $r;
    }

    public static function hashOf(string $realm, string $side, string $t, string $k): ?string
    {
        [$c, $l, $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        [$w, $p] = self::keyWhere($m['pk'], $k, 'a');
        $st = $c->prepare('SELECT ' . self::hashSql(array_keys($m['cols']), 'a') . ' FROM ' . self::q($side === 'live' ? $l : $s, $t) . ' a WHERE ' . $w . ' LIMIT 1');
        $st->execute($p);
        $h = $st->fetchColumn();
        return $h === false ? null : (string) $h;
    }

    // ---- staging's triggers (what staging changed, field by field) -------------------------------------------------

    /** The name of one of our triggers (64 characters at most). */
    public static function trigName(string $pre, string $t, string $ev): string
    {
        $n = $pre . '_' . $t . '_' . $ev;
        return strlen($n) <= 64 ? $n : $pre . '_' . substr(md5($t), 0, 16) . '_' . $ev;
    }

    /** JSON_OBJECT of a row (every value as text; binary as base64), for the triggers' before-copy. */
    private static function jsonSql(array $m, string $a): string
    {
        $p = [];
        foreach (array_keys($m['cols']) as $col) {
            $v = $a . '.' . self::c($col);
            $p[] = "'" . str_replace("'", "''", $col) . "', " . (in_array($col, $m['bin'], true) ? 'TO_BASE64(' . $v . ')' : 'CAST(' . $v . ' AS CHAR)');
        }
        return 'JSON_OBJECT(' . implode(', ', $p) . ')';
    }

    /**
     * Staging's triggers on one table: the first change since the base keeps the row as it was, and who changed it. One
     * statement each (no DELIMITER). Throws when the database refuses (no TRIGGER right): the fallback (§3) then asks
     * about every differing field of a row both sides changed.
     */
    public static function stagingTriggers(string $realm, string $t): void
    {
        [$c, , $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        if (!$m) return;
        self::ensure($realm);
        $ch = self::q($s, 'stg_changes'); $tq = self::q($s, $t); $tn = $c->quote($t);
        $who = "IFNULL(@stg_actor, ''), IFNULL(@stg_test, 0), NOW()";
        $defs = [
            'bu' => ['BEFORE UPDATE', "INSERT IGNORE INTO $ch (tbl, k, op, before_row, actor, test, at) SELECT $tn, " . self::keySql($m['pk'], 'OLD') . ", 'u', " . self::jsonSql($m, 'OLD') . ", $who FROM DUAL WHERE @stg_sync IS NULL"],
            'bd' => ['BEFORE DELETE', "INSERT IGNORE INTO $ch (tbl, k, op, before_row, actor, test, at) SELECT $tn, " . self::keySql($m['pk'], 'OLD') . ", 'd', " . self::jsonSql($m, 'OLD') . ", $who FROM DUAL WHERE @stg_sync IS NULL"],
            'ai' => ['AFTER INSERT', "INSERT IGNORE INTO $ch (tbl, k, op, before_row, actor, test, at) SELECT $tn, " . self::keySql($m['pk'], 'NEW') . ", 'i', NULL, $who FROM DUAL WHERE @stg_sync IS NULL"],
        ];
        foreach ($defs as $ev => [$when, $body]) {
            $name = '`' . str_replace('`', '', $s) . '`.`' . self::trigName('stgc', $t, $ev) . '`';
            $c->exec('DROP TRIGGER IF EXISTS ' . $name);
            $c->exec('CREATE TRIGGER ' . $name . ' ' . $when . ' ON ' . $tq . ' FOR EACH ROW ' . $body);
        }
    }

    /** Live's outbox on one table (one statement each, in the database that owns the table; skipped for Publish's own writes). */
    public static function outboxTriggers(string $realm, string $t): void
    {
        [$c, $l] = self::pair($realm);
        $m = self::meta($realm, $t);
        if (!$m) return;
        $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($l, 'stg_outbox') . ' (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tbl VARCHAR(64) NOT NULL, k VARCHAR(191) NOT NULL, op CHAR(1) NOT NULL, at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $ob = self::q($l, 'stg_outbox'); $tq = self::q($l, $t); $tn = $c->quote($t);
        foreach (['ai' => ['AFTER INSERT', 'NEW', 'i'], 'au' => ['AFTER UPDATE', 'NEW', 'u'], 'ad' => ['AFTER DELETE', 'OLD', 'd']] as $ev => [$when, $row, $op]) {
            $name = '`' . str_replace('`', '', $l) . '`.`' . self::trigName('stgo', $t, $ev) . '`';
            $c->exec('DROP TRIGGER IF EXISTS ' . $name);
            $c->exec('CREATE TRIGGER ' . $name . ' ' . $when . ' ON ' . $tq . " FOR EACH ROW INSERT INTO $ob (tbl, k, op, at) SELECT $tn, " . self::keySql($m['pk'], $row) . ", '$op', NOW() FROM DUAL WHERE @stg_pub IS NULL");
        }
    }

    /** Takes live's outbox triggers off (Keep staging caught up switched off): live is as it was. Returns how many. */
    public static function dropOutbox(string $realm): int
    {
        [$c, $l] = self::pair($realm);
        $st = $c->prepare("SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = ? AND TRIGGER_NAME LIKE 'stgo\\_%'");
        $st->execute([$l]);
        $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $tr) { $c->exec('DROP TRIGGER IF EXISTS `' . str_replace('`', '', $l) . '`.`' . str_replace('`', '', (string) $tr) . '`'); $n++; }
        return $n;
    }

    /** Is the TRIGGER right there? (Release 3's first check: the fallback runs without it.) */
    public static function canTrigger(string $realm, string $side): bool
    {
        [$c, $l, $s] = self::pair($realm);
        $db = $side === 'live' ? $l : $s;
        try {
            $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($db, 'stg_probe') . ' (id INT NOT NULL PRIMARY KEY) ENGINE=InnoDB');
            $c->exec('DROP TRIGGER IF EXISTS `' . $db . '`.`stg_probe_t`');
            $c->exec('CREATE TRIGGER `' . $db . '`.`stg_probe_t` BEFORE INSERT ON ' . self::q($db, 'stg_probe') . ' FOR EACH ROW SET @stg_probe = 1');
            $c->exec('DROP TRIGGER `' . $db . '`.`stg_probe_t`');
            $c->exec('DROP TABLE ' . self::q($db, 'stg_probe'));
            return true;
        } catch (Throwable $e) { error_log('staging trigger probe (' . $realm . ' ' . $side . '): ' . $e->getMessage()); try { $c->exec('DROP TABLE IF EXISTS ' . self::q($db, 'stg_probe')); } catch (Throwable) {} return false; }
    }

    // ---- the base --------------------------------------------------------------------------------------------------

    /** Takes the base of a whole table again (the sides are taken to match now): every row's two fingerprints; staging's change record for it cleared. */
    public static function baseTable(string $realm, string $t): int
    {
        self::ensure($realm);
        [$c, $l, $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        if (!$m) return 0;
        $cols = array_keys($m['cols']);
        $tn = $c->quote($t);
        $c->exec('DELETE FROM ' . self::q($s, 'stg_base') . ' WHERE tbl = ' . $tn);
        $c->exec('DELETE FROM ' . self::q($s, 'stg_changes') . ' WHERE tbl = ' . $tn);
        $on = implode(' AND ', array_map(fn ($x) => 'l.' . self::c($x) . ' <=> s.' . self::c($x), $m['pk']));
        return (int) $c->exec('INSERT INTO ' . self::q($s, 'stg_base') . ' (tbl, k, lh, sh, at) SELECT ' . $tn . ', ' . self::keySql($m['pk'], 'l') . ', ' . self::hashSql($cols, 'l') . ', ' . self::hashSql($cols, 's') . ', NOW() FROM '
            . self::q($l, $t) . ' l JOIN ' . self::q($s, $t) . ' s ON ' . $on);
    }

    /** One row's base, now (both fingerprints; '' for a side without the row), and its change record cleared. */
    public static function baseRow(string $realm, string $t, string $k): void
    {
        [$c, , $s] = self::pair($realm);
        $lh = self::hashOf($realm, 'live', $t, $k); $sh = self::hashOf($realm, 'staging', $t, $k);
        if ($lh === null && $sh === null) $c->prepare('DELETE FROM ' . self::q($s, 'stg_base') . ' WHERE tbl = ? AND k = ?')->execute([$t, $k]);
        else $c->prepare('INSERT INTO ' . self::q($s, 'stg_base') . ' (tbl, k, lh, sh, at) VALUES (?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE lh = VALUES(lh), sh = VALUES(sh), at = NOW()')->execute([$t, $k, (string) $lh, (string) $sh]);
        $c->prepare('DELETE FROM ' . self::q($s, 'stg_changes') . ' WHERE tbl = ? AND k = ?')->execute([$t, $k]);
    }

    public static function base(string $realm, string $t, string $k): ?array
    {
        [$c, , $s] = self::pair($realm);
        $st = $c->prepare('SELECT lh, sh FROM ' . self::q($s, 'stg_base') . ' WHERE tbl = ? AND k = ?'); $st->execute([$t, $k]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    public static function change(string $realm, string $t, string $k): ?array
    {
        [$c, , $s] = self::pair($realm);
        $st = $c->prepare('SELECT * FROM ' . self::q($s, 'stg_changes') . ' WHERE tbl = ? AND k = ?'); $st->execute([$t, $k]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $r['before'] = $r['before_row'] !== null ? self::decodeRow($realm, $t, (string) $r['before_row']) : null;
        return $r;
    }

    /** A before-copy back to a row (binary columns were kept as base64). */
    public static function decodeRow(string $realm, string $t, string $json): ?array
    {
        $r = json_decode($json, true);
        if (!is_array($r)) return null;
        $m = self::meta($realm, $t);
        foreach ($m['bin'] ?? [] as $b) if (isset($r[$b])) $r[$b] = base64_decode((string) $r[$b]);
        return $r;
    }

    // ---- catch-up: one row from live ------------------------------------------------------------------------------

    /**
     * Brings one live row's change to staging, if staging didn't touch it (decisions/0165 §3). Returns what happened:
     * 'same' | 'applied' | 'removed' | 'renumbered' (then applied) | 'conflict' | 'left' (staging's own row, live has none) | 'skipped'.
     */
    public static function catchUpKey(string $realm, string $t, string $k): string
    {
        require_once __DIR__ . '/Staging.php';
        if ($t === 'feature_switches' && in_array($k, Staging::STAGING_ONLY, true)) return 'left';   // a staging-only switch: live's row never comes in
        $m = self::meta($realm, $t);
        if (!$m) return 'skipped';
        self::ensure($realm);
        $base = self::base($realm, $t, $k);
        $lh = self::hashOf($realm, 'live', $t, $k);
        $sh = self::hashOf($realm, 'staging', $t, $k);
        $ch = self::change($realm, $t, $k);
        if ($base === null) {
            if ($lh === null) return $sh === null ? 'same' : 'left';
            $moved = false;
            if ($sh !== null && $ch && $ch['op'] === 'i') {   // staging made a row under a number live now uses: staging gives way
                if (!$m['auto']) return self::conflict($realm, $t, $k, null, 'Both sides added a row with the same key.');
                self::renumber($realm, $t, (int) $k, 'clash');
                $moved = true;
            } elseif ($sh !== null && $ch) {
                return self::conflict($realm, $t, $k, null, 'Staging changed a row the base doesn\'t know, and live has it too.');
            }
            self::applyLive($realm, $t, $k);
            return $moved ? 'renumbered' : 'applied';
        }
        if ($lh !== null && $lh === $base['lh']) return 'same';          // live didn't change it
        $stagingTouched = $ch !== null || $sh !== ($base['sh'] !== '' ? $base['sh'] : null);
        if (!$stagingTouched) {
            self::applyLive($realm, $t, $k);
            return $lh === null ? 'removed' : 'applied';
        }
        // both sides changed it: never touched here; a conflict only where the same field went two ways
        $live = self::row($realm, 'live', $t, $k);
        $stg = self::row($realm, 'staging', $t, $k);
        if ($ch === null) return self::conflict($realm, $t, $k, null, 'Changed on both sides (staging\'s change wasn\'t recorded, so every differing field is a question).');
        $merge = StagingMerge::row($ch['before'], $stg, $live, self::skipCols($realm, $t));
        if ($merge['do'] === StagingMerge::CONFLICT) return self::conflict($realm, $t, $k, $merge, $merge['why']);
        return 'left';   // merged at Publish (each side's fields)
    }

    /** Writes live's row (or its removal) into staging, stripped, with the triggers skipped; then that row's base. */
    public static function applyLive(string $realm, string $t, string $k): void
    {
        [$c, $l, $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        $c->exec('SET @stg_sync = 1');
        try {
            [$w, $p] = self::keyWhere($m['pk'], $k);
            $have = self::hashOf($realm, 'live', $t, $k) !== null;
            if (!$have) $c->prepare('DELETE FROM ' . self::q($s, $t) . ' WHERE ' . $w)->execute($p);
            else {
                $cols = array_values(array_diff(array_keys($m['cols']), $m['gen']));
                $cl = implode(', ', array_map([self::class, 'c'], $cols));
                $upd = implode(', ', array_map(fn ($x) => self::c($x) . ' = VALUES(' . self::c($x) . ')', array_diff($cols, $m['pk'])));
                $c->prepare('INSERT INTO ' . self::q($s, $t) . ' (' . $cl . ') SELECT ' . $cl . ' FROM ' . self::q($l, $t) . ' WHERE ' . $w . ($upd !== '' ? ' ON DUPLICATE KEY UPDATE ' . $upd : ''))->execute($p);
                self::stripRow($realm, $t, $k);
            }
        } finally { $c->exec('SET @stg_sync = NULL'); }
        self::baseRow($realm, $t, $k);
        try { $c->prepare('DELETE FROM ' . self::q($s, 'stg_conflicts') . ' WHERE tbl = ? AND k = ? AND settled_at IS NULL')->execute([$t, $k]); } catch (Throwable) {}
    }

    /** People's details replaced on the way in, the same as the refresh's strip, with staging's one salt (a person keeps the same stand-in). */
    private static function stripRow(string $realm, string $t, string $k): void
    {
        [$c, , $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        [$users, $staff, $salt] = self::stripping();
        if (count($m['pk']) !== 1) return;   // the strip goes by one key column
        require_once __DIR__ . '/StagingSite.php';
        StagingSite::strip($c, $s, $users, $staff, $salt, $t, self::c($m['pk'][0]) . ' = ' . $c->quote($k));
    }

    /** [test user ids, test staff ids]: work data and test data told apart (§3). */
    public static function testIds(): array { $s = self::stripping(); return [$s[0], $s[1]]; }

    private static function stripping(): array
    {
        if (self::$strip !== null) return self::$strip;
        require_once __DIR__ . '/StagingSite.php';
        return self::$strip = StagingSite::stripping(Database::connection());
    }

    /** The columns the strip replaces in a table (never carried: staging's stand-ins). */
    public static function skipCols(string $realm, string $t): array
    {
        require_once __DIR__ . '/StagingSite.php';
        $m = self::meta($realm, $t);
        return $m ? StagingSite::strippedCols($t, $m['cols']) : [];
    }

    private static function conflict(string $realm, string $t, string $k, ?array $merge, string $why): string
    {
        [$c, , $s] = self::pair($realm);
        $ch = self::change($realm, $t, $k);
        $c->prepare('INSERT INTO ' . self::q($s, 'stg_conflicts') . ' (tbl, k, found_at, base_row, stg_row, live_row, clash, why) VALUES (?, ?, NOW(), ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE settled_at = IF(stg_row <=> VALUES(stg_row) AND live_row <=> VALUES(live_row), settled_at, NULL), choice = IF(settled_at IS NULL, NULL, choice),
                found_at = IF(settled_at IS NULL, NOW(), found_at), stg_row = VALUES(stg_row), live_row = VALUES(live_row), clash = VALUES(clash), why = VALUES(why)')
          ->execute([$t, $k, $ch && $ch['before'] !== null ? json_encode($ch['before']) : null, self::js(self::row($realm, 'staging', $t, $k)), self::js(self::row($realm, 'live', $t, $k)),
                     $merge ? json_encode($merge['clash']) : json_encode(['*' => ['?', '?', '?']]), mb_substr($why, 0, 250)]);
        return 'conflict';
    }

    private static function js(?array $r): ?string { return $r === null ? null : (string) json_encode(array_map(fn ($v) => is_string($v) && !mb_check_encoding($v, 'UTF-8') ? 'base64:' . base64_encode($v) : $v, $r), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }

    // ---- renumbering: staging gives way -------------------------------------------------------------------------------

    /**
     * Moves staging's own row to a new number (the next free on both sides, or $to), and every reference to it in staging's
     * databases (the register of record numbers: columns, JSON, kind:id strings, links, store keys). Logged in stg_renumber.
     * Stops, changing nothing, when a column that looks like a record number but isn't in the register holds the old one.
     * Returns the new number.
     */
    public static function renumber(string $realm, string $t, int $old, string $why, ?int $to = null): int
    {
        [$c, $l, $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        if (!$m || !$m['int']) throw new RuntimeException('The ' . $t . ' table has no single number key, so its rows can\'t be renumbered.');
        $pk = self::c($m['pk'][0]);
        if ($to === null) {
            $max = 0;
            foreach ([$l, $s] as $db) $max = max($max, (int) $c->query('SELECT IFNULL(MAX(' . $pk . '), 0) FROM ' . self::q($db, $t))->fetchColumn());
            if ($m['auto']) foreach ([$l, $s] as $db) { $st = $c->prepare('SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?'); $st->execute([$db, $t]); $max = max($max, (int) $st->fetchColumn() - 1); }
            $to = $max + 1;
        }
        $map = [$t => [$old => $to]];
        self::stopOnUnknown($map);
        $c->prepare('UPDATE ' . self::q($s, $t) . ' SET ' . $pk . ' = ? WHERE ' . $pk . ' = ?')->execute([$to, $old]);   // staging's own work: its change record moves with it
        $c->prepare('UPDATE IGNORE ' . self::q($s, 'stg_changes') . ' SET k = ? WHERE tbl = ? AND k = ?')->execute([(string) $to, $t, (string) $old]);
        $n = self::rewriteRefs($map);
        $c->prepare('INSERT INTO ' . self::q($s, 'stg_renumber') . ' (tbl, old_id, new_id, why, refs, at) VALUES (?, ?, ?, ?, ?, NOW())')->execute([$t, $old, $to, $why, $n]);
        self::clearCaches();
        return $to;
    }

    /** The register of record numbers, from live's columns (built once a run, kept in staging's stg_id_refs for the page). */
    public static function refs(): array
    {
        if (self::$refs !== null) return self::$refs;
        $cols = [];
        foreach (self::pairs() as $realm => [$c, $l]) {
            $st = $c->prepare("SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? ORDER BY TABLE_NAME, ORDINAL_POSITION");
            $st->execute([$l]);
            foreach ($st->fetchAll(PDO::FETCH_NUM) as [$t, $col, $ty]) if (StagingTables::classOf((string) $t) !== 'never' && $t !== 'stg_outbox') $cols[] = [$realm, (string) $t, (string) $col, (string) $ty];
        }
        return self::$refs = StagingIds::build($cols);
    }

    /** Saves the register in staging's main database (stg_id_refs), for the Staging page. Returns [refs, unknown]. */
    public static function saveRefs(): array
    {
        $r = self::refs();
        $p = self::pairs(); $realm = isset($p['main']) ? 'main' : (string) array_key_first($p);
        [$c, , $s] = self::pair($realm);
        $c->exec('CREATE TABLE IF NOT EXISTS ' . self::q($s, 'stg_id_refs') . ' (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, realm VARCHAR(12) NOT NULL, tbl VARCHAR(64) NOT NULL, col VARCHAR(64) NOT NULL, place VARCHAR(6) NOT NULL, points VARCHAR(64) NOT NULL, path VARCHAR(190) NOT NULL DEFAULT \'\', known TINYINT NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $c->exec('DELETE FROM ' . self::q($s, 'stg_id_refs'));
        $ins = $c->prepare('INSERT INTO ' . self::q($s, 'stg_id_refs') . ' (realm, tbl, col, place, points, path, known) VALUES (?, ?, ?, ?, ?, ?, ?)');
        foreach ($r['refs'] as $x) $ins->execute([$x[0], $x[1], $x[2], $x[3], $x[4], $x[5], 1]);
        foreach ($r['unknown'] as $x) $ins->execute([$x[0], $x[1], $x[2], 'col', '?', '', 0]);
        return [count($r['refs']), count($r['unknown'])];
    }

    /**
     * An unknown reference stops it (§4): a column that looks like a record number, isn't in the register, and holds one of
     * the numbers being moved, in a Records table on staging. Throws naming the table and field.
     */
    public static function stopOnUnknown(array $map): void
    {
        $hits = [];
        foreach (self::refs()['unknown'] as [$realm, $t, $col]) {
            if (!StagingTables::carried($t) || !isset(self::pairs()[$realm])) continue;
            [$c, , $s] = self::pair($realm);
            $ids = []; foreach ($map as $olds) foreach (array_keys($olds) as $o) $ids[] = (int) $o;
            if (!$ids) return;
            try { $n = (int) $c->query('SELECT COUNT(*) FROM ' . self::q($s, $t) . ' WHERE ' . self::c($col) . ' IN (' . implode(',', array_unique($ids)) . ')')->fetchColumn(); } catch (Throwable) { continue; }
            if ($n) $hits[] = $t . '.' . $col;
        }
        if ($hits) throw new RuntimeException('Stopped: ' . implode(', ', $hits) . ' hold' . (count($hits) === 1 ? 's' : '') . ' what looks like a record number being moved, and the register of record numbers doesn\'t say what it points to. Add it to the register (app/lib/staging-tables.php, REFS) in a release, then go on: nothing was changed.');
    }

    /** Rewrites every reference to the numbers in $map across staging's databases. Returns how many were rewritten. */
    public static function rewriteRefs(array $map, string $side = 'staging'): int
    {
        $n = 0;
        $byTable = [];
        foreach (self::refs()['refs'] as [$realm, $t, $col, $place, $points, $path]) $byTable[$realm][$t][] = [$col, $place, $points, $path];
        foreach ($byTable as $realm => $tables) {
            if (!isset(self::pairs()[$realm])) continue;
            [$c, $l, $s] = self::pair($realm);
            $db = $side === 'live' ? $l : $s;
            foreach ($tables as $t => $list) {
                if (!StagingTables::carried($t) && StagingTables::classOf($t) !== 'money' && StagingTables::classOf($t) !== 'own') continue;
                $m = self::meta($realm, $t);
                if (!$m) continue;
                foreach ($list as [$col, $place, $points, $path]) {
                    if ($place === 'col' && $points[0] !== '?' && isset($map[$points])) {
                        $inKey = in_array($col, $m['pk'], true);
                        foreach ($map[$points] as $o => $nw) {
                            $old = [];
                            if ($inKey && $side === 'staging') {   // part of the row's key: its change record moves with it (the row stays staging's own, as it was)
                                $st = $c->prepare('SELECT ' . self::keySql($m['pk'], 'a') . ' FROM ' . self::q($db, $t) . ' a WHERE a.' . self::c($col) . ' = ?'); $st->execute([$o]);
                                $old = array_map('strval', $st->fetchAll(PDO::FETCH_COLUMN));
                                $c->exec('SET @stg_sync = 1');
                            }
                            try { $st = $c->prepare('UPDATE ' . self::q($db, $t) . ' SET ' . self::c($col) . ' = ? WHERE ' . self::c($col) . ' = ?'); $st->execute([$nw, $o]); $n += $st->rowCount(); }
                            finally { if ($inKey && $side === 'staging') $c->exec('SET @stg_sync = NULL'); }
                            $pos = array_search($col, $m['pk'], true);
                            foreach ($old as $ok) {
                                $parts = count($m['pk']) === 1 ? [$ok] : explode(chr(31), $ok);
                                $parts[$pos] = (string) $nw;
                                $c->prepare('UPDATE IGNORE ' . self::q($s, 'stg_changes') . ' SET k = ? WHERE tbl = ? AND k = ?')->execute([implode(chr(31), $parts), $t, $ok]);
                            }
                        }
                        continue;
                    }
                    if ($place === 'col' && $points[0] === '?') {   // a kind column beside it says which table
                        $kc = substr($points, 1);
                        foreach (StagingTables::KINDS as $kind => $kt) if (isset($map[$kt])) foreach ($map[$kt] as $o => $nw) {
                            $st = $c->prepare('UPDATE ' . self::q($db, $t) . ' SET ' . self::c($col) . ' = ? WHERE ' . self::c($col) . ' = ? AND ' . self::c($kc) . ' = ?'); $st->execute([$nw, $o, $kind]); $n += $st->rowCount();
                        }
                        continue;
                    }
                    if ($place === 'json' || $place === 'kind') $n += self::rewriteTextCol($c, $db, $t, $m, $col, $place === 'json' ? [$path => $points] : [], $map);
                }
            }
        }
        return $n;
    }

    /** Text and JSON in one column: only the rows that mention one of the old numbers are read and written. */
    private static function rewriteTextCol(PDO $c, string $db, string $t, array $m, string $col, array $paths, array $map): int
    {
        $like = []; $p = [];
        foreach ($map as $olds) foreach (array_keys($olds) as $o) { $like[] = self::c($col) . ' LIKE ?'; $p[] = '%' . $o . '%'; }
        if (!$like) return 0;
        $pk = $m['pk'];
        $st = $c->prepare('SELECT ' . implode(', ', array_map([self::class, 'c'], $pk)) . ', ' . self::c($col) . ' AS v FROM ' . self::q($db, $t) . ' WHERE ' . implode(' OR ', $like) . ' LIMIT 5000');
        $st->execute($p);
        $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            [$v, $k] = $paths ? StagingIds::json((string) $r['v'], $paths, $map) : StagingIds::text((string) $r['v'], $map);
            if (!$k) continue;
            $w = []; $wp = [$v];
            foreach ($pk as $x) { $w[] = self::c($x) . ' = ?'; $wp[] = $r[$x]; }
            $c->prepare('UPDATE ' . self::q($db, $t) . ' SET ' . self::c($col) . ' = ? WHERE ' . implode(' AND ', $w))->execute($wp);
            $n += $k;
        }
        return $n;
    }

    /** After a renumber or a publish: caches cleared on both sides (page cache, search state), so nothing points at an old number. */
    public static function clearCaches(): void
    {
        foreach (self::pairs() as [$c, $l, $s]) foreach ([$l, $s] as $db) foreach (['page_cache'] as $t) { try { $c->exec('DELETE FROM ' . self::q($db, $t)); } catch (Throwable) {} }
    }

    // ---- the push job and the passes ------------------------------------------------------------------------------

    /** The push (every minute): live's outbox, each key once, in order, a batch per realm. Returns counts by outcome. */
    public static function push(int $max = self::BATCH): array
    {
        $out = [];
        foreach (self::pairs() as $realm => [$c, $l]) {
            try { $rows = $c->query('SELECT id, tbl, k FROM ' . self::q($l, 'stg_outbox') . ' ORDER BY id LIMIT ' . (int) $max)->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) { continue; }   // no outbox: Keep staging caught up is off
            if (!$rows) continue;
            $seen = []; $last = 0;
            foreach ($rows as $r) {
                $last = (int) $r['id'];
                $key = $r['tbl'] . "\n" . $r['k'];
                if (isset($seen[$key])) continue;
                $seen[$key] = true;
                if (!in_array(StagingTables::classOf((string) $r['tbl']), ['records', 'money'], true)) continue;
                try { $o = self::catchUpKey($realm, (string) $r['tbl'], (string) $r['k']); }
                catch (Throwable $e) { error_log('staging push ' . $r['tbl'] . ' ' . $r['k'] . ': ' . $e->getMessage()); $o = 'error'; }
                $out[$o] = ($out[$o] ?? 0) + 1;
            }
            $c->prepare('DELETE FROM ' . self::q($l, 'stg_outbox') . ' WHERE id <= ?')->execute([$last]);
        }
        return $out;
    }

    /**
     * The full pass for one table (nightly, Catch up now, before every preview): every row whose fingerprint on live
     * differs from the base, every row the base has that live doesn't (a cascaded delete), every row live has that the
     * base doesn't. A chunk at a time by key. Returns counts by outcome.
     */
    public static function passTable(string $realm, string $t, int $chunk = 2000): array
    {
        self::ensure($realm);
        [$c, $l, $s] = self::pair($realm);
        $m = self::meta($realm, $t);
        if (!$m) return [];
        $tn = $c->quote($t); $cols = array_keys($m['cols']);
        $keys = [];
        // live's rows that differ from the base, or that the base doesn't have
        $after = null;
        do {
            $sql = 'SELECT ' . self::keySql($m['pk'], 'l') . ' AS k' . ($m['int'] ? ', l.' . self::c($m['pk'][0]) . ' AS n' : '') . ' FROM ' . self::q($l, $t) . ' l LEFT JOIN ' . self::q($s, 'stg_base') . ' b ON b.tbl = ' . $tn . ' AND b.k = ' . self::keySql($m['pk'], 'l')
                 . ' WHERE (b.k IS NULL OR b.lh <> ' . self::hashSql($cols, 'l') . ')' . ($m['int'] && $after !== null ? ' AND l.' . self::c($m['pk'][0]) . ' > ' . (int) $after : '')
                 . ($m['int'] ? ' ORDER BY l.' . self::c($m['pk'][0]) . ' LIMIT ' . (int) $chunk : '');
            $rows = $c->query($sql)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $r) $keys[(string) $r['k']] = true;
            $after = $m['int'] && $rows ? (int) end($rows)['n'] : null;
        } while ($m['int'] && count($rows) === $chunk);
        // what the base has that live no longer does
        foreach ($c->query('SELECT b.k FROM ' . self::q($s, 'stg_base') . ' b LEFT JOIN ' . self::q($l, $t) . ' l ON b.k = ' . self::keySql($m['pk'], 'l') . ' WHERE b.tbl = ' . $tn . ' AND b.lh <> \'\' AND l.' . self::c($m['pk'][0]) . ' IS NULL')->fetchAll(PDO::FETCH_COLUMN) as $k) $keys[(string) $k] = true;
        $out = [];
        foreach (array_keys($keys) as $k) {
            try { $o = self::catchUpKey($realm, $t, (string) $k); } catch (Throwable $e) { error_log('staging pass ' . $t . ' ' . $k . ': ' . $e->getMessage()); $o = 'error'; }
            $out[$o] = ($out[$o] ?? 0) + 1;
        }
        return $out;
    }

    /** Follows-live tables: copied again when live's checksum differs (a whole table, on the night). Returns tables copied. */
    public static function followTables(string $realm): array
    {
        [$c, $l, $s] = self::pair($realm);
        $st = $c->prepare("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = 'BASE TABLE'"); $st->execute([$l]);
        $done = [];
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $t) {
            $t = (string) $t;
            if (StagingTables::classOf($t) !== 'follows' || $t === 'stg_outbox') continue;
            $a = $c->query('CHECKSUM TABLE ' . self::q($l, $t))->fetch(PDO::FETCH_NUM);
            $b = null; try { $b = $c->query('CHECKSUM TABLE ' . self::q($s, $t))->fetch(PDO::FETCH_NUM); } catch (Throwable) {}
            if ($b && (string) $a[1] === (string) $b[1]) continue;
            $c->exec('SET FOREIGN_KEY_CHECKS = 0');
            $c->exec('DROP TABLE IF EXISTS ' . self::q($s, $t));
            $c->exec('CREATE TABLE ' . self::q($s, $t) . ' LIKE ' . self::q($l, $t));
            $m = self::meta($realm, $t);
            $cols = $m ? array_values(array_diff(array_keys($m['cols']), $m['gen'])) : null;
            $cl = $cols ? implode(', ', array_map([self::class, 'c'], $cols)) : '*';
            $c->exec('INSERT INTO ' . self::q($s, $t) . ($cols ? ' (' . $cl . ')' : '') . ' SELECT ' . $cl . ' FROM ' . self::q($l, $t));
            $c->exec('SET FOREIGN_KEY_CHECKS = 1');
            $done[] = $t;
        }
        return $done;
    }

    /** The conflicts not settled yet, newest first. */
    public static function conflicts(int $limit = 100): array
    {
        $out = [];
        foreach (self::pairs() as $realm => [$c, , $s]) {
            try { foreach ($c->query('SELECT * FROM ' . self::q($s, 'stg_conflicts') . ' WHERE settled_at IS NULL ORDER BY found_at DESC LIMIT ' . (int) $limit)->fetchAll(PDO::FETCH_ASSOC) as $r) $out[] = ['realm' => $realm] + $r; } catch (Throwable) {}
        }
        return $out;
    }

    /** Settles a conflict: 'live', 'staging', or per field. Kept with the conflict; applied by Publish (or now, for Keep live). */
    public static function settle(string $realm, string $t, string $k, $choice, int $uid): void
    {
        [$c, , $s] = self::pair($realm);
        if ($choice === 'live') {   // Keep live: staging takes live's row now and the row is in step again
            $c->prepare('UPDATE ' . self::q($s, 'stg_conflicts') . ' SET choice = ?, settled_at = NOW(), settled_by = ? WHERE tbl = ? AND k = ?')->execute(['"live"', $uid, $t, $k]);
            $c->prepare('DELETE FROM ' . self::q($s, 'stg_changes') . ' WHERE tbl = ? AND k = ?')->execute([$t, $k]);
            self::applyLive($realm, $t, $k);
            return;
        }
        $c->prepare('UPDATE ' . self::q($s, 'stg_conflicts') . ' SET choice = ?, settled_at = NOW(), settled_by = ? WHERE tbl = ? AND k = ?')->execute([json_encode($choice), $uid, $t, $k]);
    }

    /** Keep live for the rest: every open conflict settled as live's. Returns how many. */
    public static function keepLiveForRest(int $uid): int
    {
        $n = 0;
        foreach (self::conflicts(10000) as $x) { self::settle((string) $x['realm'], (string) $x['tbl'], (string) $x['k'], 'live', $uid); $n++; }
        return $n;
    }
}
