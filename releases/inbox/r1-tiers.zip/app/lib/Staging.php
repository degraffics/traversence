<?php
// app/lib/Staging.php — the staging copy of the site at staging.trvgo.us (decisions/0145 §5 step 5, site-audit/phase-3-staging.md).
// The copy runs the same code as the live site, with its own .env (STAGING=1), its own databases and its own folder. This
// file is what the code asks there. On the live site STAGING isn't set, so here() is false and nothing here does anything.
// On staging:
//   - every page asks for the staging viewing password (guard(); the folder's .htaccess asks first), says "Staging" in a
//     corner and tells search engines not to index it (X-Robots-Tag, and robots.txt says Disallow);
//   - email is held, not sent: kept in the held ledger, staging_held (StagingGate; it took in staging_mail), and read in
//     Held on the site manager and System Configuration → Staging (holdMail());
//   - every page carries a Content Security Policy (StagingGate::csp(): only what pages need loads) (decisions/0165 §1);
//   - its database connections say who's acting (tag(): @stg_actor, @stg_test), for staging's change record (StagingSync);
//   - payments run in their sandboxes (QuickBooksPay::testHere() is true for everyone), SES only records;
//   - paid AI and the crawler stay off unless their switch is on (allow(): Switches staging_ai, staging_crawler);
//   - files it stores go under staging/ in the file store, and it never deletes a live file there (s3Key(), s3Mine()).
// Setting staging up and refreshing it from live is StagingSite.php, which runs on the live site.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Staging
{
    public const HOST = 'staging.trvgo.us';
    public const S3_PREFIX = 'staging/';
    /** Switches that let a paid service run on staging for a test (Switches::DEFS). */
    public const SWITCHES = ['ai' => 'staging_ai', 'crawler' => 'staging_crawler'];
    /**
     * Switches that act only on the staging copy: catch-up never brings live's row for them, and Publish never carries
     * staging's to live (StagingSync::catchUpKey, StagingPublish::candidates). The Team's runner is one (TeamRunner::blocked).
     */
    public const STAGING_ONLY = ['staging_ai', 'staging_crawler', 'team_runner'];
    /**
     * What a fresh copy starts with on staging (StagingSite::finish): the Team's runner on for everyone (CLAUDE.md's standing
     * OK, "the build session may switch on staging's Team runner"; decisions/0180's note "run it now"). Turned off there, it
     * stays off until the next fresh copy. The tree's approval and the ceiling stay the Founder's own presses.
     */
    public const ON_AFTER_COPY = ['team_runner' => ['on', 'Switched on for staging by the build (CLAUDE.md standing OK; decisions/0180 run it now)']];

    private static ?bool $here = null;
    private static ?array $s3 = null;

    /** Is this the staging copy? (STAGING=1 in its .env; never in live's.) It reads only that line, so on the live site
     *  asking loads nothing early and changes nothing. */
    public static function here(): bool
    {
        if (self::$here !== null) return self::$here;
        $v = getenv('STAGING');
        if ($v === false) { $f = @file_get_contents(Database::envPath()); $v = is_string($f) && preg_match('/^\s*STAGING\s*=\s*["\']?1["\']?\s*$/m', $f) ? '1' : ''; }
        return self::$here = trim((string) $v) === '1';
    }

    public static function siteBase(): string { return 'https://' . self::HOST; }

    /** The folder staging's .env, viewing password and refresh flag are in (the one above its public_html). */
    public static function home(): string { return dirname(Database::envPath()); }

    /** May this paid service run here? Always on the live site; on staging only while its switch is on. */
    public static function allow(string $what): bool
    {
        if (!self::here()) return true;
        $key = self::SWITCHES[$what] ?? '';
        if ($key === '') return false;
        try { require_once __DIR__ . '/Switches.php'; return Switches::on(Database::connection(), $key); } catch (Throwable) { return false; }
    }

    // ---- every page on staging --------------------------------------------------------------------------------------

    /**
     * Called first thing on every page (app/ui/security-headers.php) and by the trvgo.us router: on staging, asks for the
     * viewing password, says it isn't indexed, waits out a refresh, and marks the page "Staging". Nothing on live.
     */
    public static function guard(): void
    {
        if (PHP_SAPI === 'cli' || !self::here() || headers_sent()) return;
        header('X-Robots-Tag: noindex, nofollow');
        require_once __DIR__ . '/StagingGate.php';
        header('Content-Security-Policy: ' . StagingGate::csp());   // decisions/0165 §1: nothing that tracks or reports out runs on staging
        if (defined('TV_STAGING_ENTER')) return;   // /stg-enter.php: the live admin's signed way in checks itself (Releases, the staging bar)
        if (!self::viewer()) {
            http_response_code(401);
            header('WWW-Authenticate: Basic realm="Traversence staging", charset="UTF-8"');
            header('X-Tv-Stg-Gate: page');   // which layer asked (Check the way in, decisions/0159 step 1): this one; the guard file says guard-file, the web server neither
            self::page('This is Traversence\'s staging copy', 'It\'s where changes are tried before they reach traversence.com, and it needs its viewing password. Looking for Traversence? It\'s at <a href="https://traversence.com">traversence.com</a>. On our team and lost the password? Ask for a new one at <a href="mailto:support@traversence.com">support@traversence.com</a>.');
        }
        $flag = self::home() . '/.refreshing';
        if (is_file($flag) && filemtime($flag) > time() - 6 * 3600) {   // a refresh is copying live over it (a stuck one stops counting after 6 hours)
            http_response_code(503);
            header('Retry-After: 120');
            self::page('Staging is being refreshed', 'A fresh copy of the live site is going in. It takes a few minutes: try again shortly. If it stays like this, open System Configuration → Staging on the live site, or write to <a href="mailto:support@traversence.com">support@traversence.com</a>.');
        }
        self::ribbon();
    }

    /** Has the viewer given the staging password? Apache checks it first (REMOTE_USER); this checks it again for PHP pages. */
    private static function viewer(): bool
    {
        if ((string) ($_SERVER['REMOTE_USER'] ?? $_SERVER['REDIRECT_REMOTE_USER'] ?? '') !== '') return true;
        $pass = self::pass();   // came in from the live admin (Open on staging): its pass cookie
        if ($pass !== '' && hash_equals($pass, (string) ($_COOKIE['tv_stg_pass'] ?? ''))) return true;
        $u = $_SERVER['PHP_AUTH_USER'] ?? null; $p = $_SERVER['PHP_AUTH_PW'] ?? null;
        if ($u === null) {
            $h = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
            if (stripos($h, 'basic ') === 0) { $d = base64_decode(substr($h, 6), true); if ($d !== false && str_contains($d, ':')) [$u, $p] = explode(':', $d, 2); }
        }
        if ($u === null || $p === null || $u === '') return false;
        foreach (@file(self::home() . '/.htpasswd', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            [$lu, $lh] = array_pad(explode(':', trim($line), 2), 2, '');
            if ($lh !== '' && hash_equals($lu, (string) $u) && password_verify((string) $p, $lh)) return true;
        }
        return false;
    }

    /** Staging's pass for those who came in from the live admin (STAGING_PASS in its .env; '' until the first Open on staging). */
    public static function pass(): string
    {
        Database::readEnv();
        $p = (string) (getenv('STAGING_PASS') ?: '');
        return preg_match('/^[A-Za-z0-9]{32,}$/', $p) ? $p : '';
    }

    private static function page(string $title, string $html): void
    {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . htmlspecialchars($title) . '</title></head>'
           . '<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7EFDC;color:#3E2B1F;font:16px/1.5 var(--tv-font-head,Georgia,serif);padding:16px">'
           . '<div style="max-width:28rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:1.25rem"><p style="margin:0 0 .5rem;color:#92400E;font-weight:700">' . htmlspecialchars($title) . '</p><p style="margin:0">' . $html . '</p></div></body></html>';
        exit;
    }

    /** A small "Staging" mark in the corner of every HTML page (added as the page goes out; JSON and files are left alone). */
    private static function ribbon(): void
    {
        $mark = '<div aria-label="Staging copy, not the live site" style="position:fixed;left:8px;bottom:8px;z-index:2147483647;pointer-events:none;background:#92400E;color:#FFFBF2;'
              . 'font:700 12px/20px system-ui,sans-serif;padding:0 10px;border-radius:999px;box-shadow:0 1px 4px rgba(0,0,0,.25);opacity:.92">Staging · safe mode</div>';
        ob_start(function (string $buf) use ($mark): string {
            static $done = false;
            if ($done) return $buf;
            foreach (headers_list() as $h) if (stripos($h, 'content-type:') === 0 && stripos($h, 'text/html') === false) { $done = true; return $buf; }
            $i = stripos($buf, '<body');
            if ($i === false) return $buf;
            $j = strpos($buf, '>', $i);
            if ($j === false) return $buf;
            $done = true;
            // came in from the live admin: the staging bar (its release, notes, sign off, schedule, publish) instead of the mark
            if (isset($_COOKIE['tv_stg_bar'])) $mark = '<div id="tv-stg-bar" data-tv-stg-bar></div><script src="/js/stg-bar.js?v=' . (int) @filemtime(dirname(__DIR__, 2) . '/website/js/stg-bar.js') . '" defer></script>';
            return substr($buf, 0, $j + 1) . $mark . substr($buf, $j + 1);
        }, 16384);
    }

    // ---- email: held on staging ---------------------------------------------------------------------------------------

    /**
     * On staging, keeps a message instead of sending it, and says so (true). On live, false: send as usual. Called by
     * Mailer::send and SesMail::send before anything goes out.
     */
    public static function holdMail(string $to, string $subject, string $text, string $html = '', string $via = 'smtp'): bool
    {
        if (!self::here()) return false;
        require_once __DIR__ . '/StagingGate.php';
        StagingGate::mail($to, $subject, $text, $html, $via);   // the held ledger (decisions/0165 §1); it never throws
        return true;   // held, never sent, even when it couldn't be kept
    }

    /** The held email, newest first (to one address, when given): the ledger's mail. For System Configuration → Staging and Held. */
    public static function heldMail(PDO $pdo, int $limit = 30, string $to = ''): array
    {
        if (!self::here()) return [];
        require_once __DIR__ . '/StagingGate.php';
        StagingGate::ensure($pdo);
        $sql = "SELECT id, target AS to_addr, subject, body_text, body_html, via, created_at FROM staging_held WHERE kind = 'mail'" . ($to !== '' ? ' AND target = ?' : '') . ' ORDER BY id DESC LIMIT ' . max(1, min(200, $limit));
        $st = $pdo->prepare($sql);
        $st->execute($to !== '' ? [$to] : []);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Who's acting, on one of staging's database connections (decisions/0165 §3): @stg_actor ('u<user id>', with
     * 's<staff id>' when a staff login is signed in; 'job:<script>' on the command line) and @stg_test (a test account).
     * Staging's triggers keep it with each change, so Publish can tell work data from test data. Database::connection()
     * calls it on staging; the bootstrap again once the session has started. Nothing on live.
     */
    public static function tag(?PDO $pdo = null): void
    {
        static $conns = [];
        if (!self::here()) return;
        if ($pdo !== null) $conns[spl_object_id($pdo)] = $pdo;
        if (PHP_SAPI === 'cli') $actor = 'job:' . basename((string) ($_SERVER['argv'][0] ?? 'cli'), '.php');
        else {
            $u = (int) ($_SESSION['user_id'] ?? 0); $s = (int) ($_SESSION['tv_staff'] ?? 0);
            $actor = ($u ? 'u' . $u : 'guest') . ($s ? 's' . $s : '');
        }
        $test = (int) (!empty($_SESSION['tv_is_test']));
        foreach ($conns as $c) { try { $c->prepare('SET @stg_actor = ?, @stg_test = ?')->execute([mb_substr($actor, 0, 40), $test]); } catch (Throwable) {} }
    }

    /** Staging's own tables (made on staging; a refresh keeps them as they are). */
    public const OWN_TABLES = ['staging_mail', 'staging_s3', 'staging_held', 'staging_allow', 'staging_pace', 'stg_base', 'stg_changes', 'stg_renumber', 'stg_conflicts', 'stg_plan', 'stg_id_refs', 'pub_journal'];

    public static function ensure(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $pdo->exec('CREATE TABLE IF NOT EXISTS staging_mail (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, to_addr VARCHAR(190) NOT NULL, subject VARCHAR(255) NOT NULL DEFAULT \'\',
            body_text MEDIUMTEXT NULL, body_html MEDIUMTEXT NULL, via VARCHAR(12) NOT NULL DEFAULT \'smtp\', created_at DATETIME NOT NULL, KEY idx_staging_mail_to (to_addr, id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $pdo->exec('CREATE TABLE IF NOT EXISTS staging_s3 (kh CHAR(64) NOT NULL PRIMARY KEY, k TEXT NOT NULL, created_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $done = true;
    }

    // ---- the file store: staging never changes a live file ------------------------------------------------------------

    /**
     * The key to use in the file store. On staging a file it writes goes under staging/ (and is remembered), and a file it
     * reads is its own copy when it wrote one, else the live file (read only). On live, the key as it is.
     */
    public static function s3Key(string $key, bool $write): string
    {
        if ($key === '' || !self::here()) return $key;
        if ($write) {
            if (!self::s3Mine($key)) {
                try { $pdo = Database::connection(); self::ensure($pdo); $pdo->prepare('INSERT IGNORE INTO staging_s3 (kh, k, created_at) VALUES (?, ?, NOW())')->execute([hash('sha256', $key), $key]); } catch (Throwable $e) { error_log('staging s3: ' . $e->getMessage()); }
                self::$s3[hash('sha256', $key)] = true;
            }
            return self::S3_PREFIX . $key;
        }
        return self::s3Mine($key) ? self::S3_PREFIX . $key : $key;
    }

    /** Did staging write this file? (Only those can be deleted from staging.) */
    public static function s3Mine(string $key): bool
    {
        if (!self::here()) return true;
        if (self::$s3 === null) {
            self::$s3 = [];
            try { $pdo = Database::connection(); self::ensure($pdo); foreach ($pdo->query('SELECT kh FROM staging_s3')->fetchAll(PDO::FETCH_COLUMN) as $h) self::$s3[(string) $h] = true; } catch (Throwable) {}
        }
        return isset(self::$s3[hash('sha256', $key)]);
    }

    /** A file staging wrote and has now deleted. */
    public static function s3Forget(string $key): void
    {
        if (!self::here()) return;
        unset(self::$s3[hash('sha256', $key)]);
        try { Database::connection()->prepare('DELETE FROM staging_s3 WHERE kh = ?')->execute([hash('sha256', $key)]); } catch (Throwable) {}
    }
}
