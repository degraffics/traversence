-- A found photo for a public place's card and hero (app/lib/PlacePhotos.php; Jason, 2026-11-19, decisions/0143's note):
-- one row a place (a listing, or a Recreation.gov park), its Commons photo with credit and licence, and when it was looked for.
CREATE TABLE IF NOT EXISTS place_photos (
  owner_kind VARCHAR(10) NOT NULL,
  owner_ref VARCHAR(40) NOT NULL,
  image_url VARCHAR(500) NOT NULL DEFAULT '',
  image_page VARCHAR(500) NOT NULL DEFAULT '',
  image_credit VARCHAR(200) NOT NULL DEFAULT '',
  image_license VARCHAR(60) NOT NULL DEFAULT '',
  source VARCHAR(20) NOT NULL DEFAULT '',
  tried_at DATETIME NULL,
  found_at DATETIME NULL,
  PRIMARY KEY (owner_kind, owner_ref),
  KEY idx_place_photos_tried (owner_kind, tried_at)
) ENGINE=InnoDB;
