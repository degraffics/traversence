<?php
// app/scripts/landmark_photos_tick.php — photos for landmarks without one (Landmarks::findPhotos): Wikimedia Commons,
// free, a photo taken nearby and named for the landmark, with its credit and licence. 20 an hour, one request at a time;
// sets itself up in cPanel (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('landmark_photos_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Landmarks.php';
try { [$looked, $found] = Landmarks::findPhotos(Database::connection(), 20); echo "Looked for photos for $looked landmarks; found $found.\n"; }
catch (PDOException $e) { echo 'Not ready yet: ' . $e->getMessage() . "\n"; }
// and the public places' cards and heroes (parks, monuments, visitor centres, historic sites): the same finder, the same pace (2026-11-19)
require_once __DIR__ . '/../lib/PlacePhotos.php';
try { [$looked, $found] = PlacePhotos::find(Database::connection(), 15); echo "Looked for photos for $looked places; found $found.\n"; }
catch (PDOException $e) { echo 'Places not ready yet: ' . $e->getMessage() . "\n"; }
