/*
 * push-sw.js — the service worker for push (decisions/0172 §4.6), at the site root so its scope is "/".
 * It only shows pushes and opens their links: no caching and no fetch handler, so how the site loads doesn't change.
 * A push's data (app/lib/WebPush.php payload()): {title, body, url (the item in Pulse), stop (Stop these), tag, level,
 * renotify (alert again under the same tag: only when asked)}.
 */
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });

self.addEventListener('push', function (e) {
  var d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { body: e.data ? e.data.text() : '' }; }
  var url = d.url || '/';
  var stop = d.stop || '/user/dashboard.php#communications';
  var opts = {
    body: d.body || '',
    icon: '/image/apple-touch-icon.png',
    // Android draws the status bar's badge from its transparency alone: the North Star in white on clear, never the
    // square tile (2026-11-19, Jason: "Our icon?")
    badge: '/image/push-badge.png',
    data: { url: url, stop: stop },
    actions: [{ action: 'open', title: 'Open' }, { action: 'stop', title: 'Stop these' }]
  };
  // the same thing replaces its notification; it alerts again only when the sender asks (something got worse), never for
  // a repeat or a second Test: repeated alerts are what Chrome's spam filter counts against a site (2026-11-19)
  if (d.tag) { opts.tag = d.tag; opts.renotify = !!d.renotify; }
  if (d.level === 'critical') opts.requireInteraction = true;
  e.waitUntil(self.registration.showNotification(d.title || 'Traversence', opts));
});

self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  var data = e.notification.data || {};
  var target = new URL(e.action === 'stop' ? (data.stop || '/user/dashboard.php#communications') : (data.url || '/'), self.location.origin).href;
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      if (c.url === target && 'focus' in c) return c.focus();
    }
    // a new tab otherwise: never take over a tab the person is working in
    return self.clients.openWindow ? self.clients.openWindow(target) : null;
  }));
});
