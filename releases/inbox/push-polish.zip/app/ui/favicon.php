<?php
/**
 * app/ui/favicon.php — the site's icon lines for a page's <head> (2026-11-17).
 *
 * Every head prints these, so the tab shows the Traversence mark on every route, however deep: root-absolute paths,
 * never relative ones (image/favicon.png broke under /admin/… and /listing/…). /favicon.ico sits at the web root as the
 * browser's own fallback, so a page that misses this still gets the icon.
 *
 *   <?= tv_favicon_links() ?>                         // a traversence.com page
 *   tv_favicon_links($site)                           // a trvgo.us page: our files live on traversence.com
 *   tv_favicon_links($site, $logo)                    // a storefront: the business's own logo, else ours
 *
 * Files: /image/favicon.png (64 px, the T mark), /favicon.ico (16, 32, 48 and 64 px of the same) and
 * /image/apple-touch-icon.png (180 px, the North Star compass on the bar's brown, for a phone's home screen);
 * /manifest.json with /image/app-icon-192.png, -512.png and -maskable-512.png (the site installed as an app), and
 * /image/push-badge.png (96 px, the star in white on clear: a notification's status-bar badge).
 */
declare(strict_types=1);

function tv_favicon_links(string $base = '', string $own = ''): string
{
    $base = rtrim($base, '/');
    $e = function (string $u): string { return htmlspecialchars($u, ENT_QUOTES, 'UTF-8'); };
    if ($own !== '') {   // a business's own picture (a storefront): its tab and home-screen icon
        return '<link rel="icon" href="' . $e($own) . '"><link rel="apple-touch-icon" href="' . $e($own) . '">';
    }
    return '<link rel="icon" href="' . $e($base . '/favicon.ico') . '">'
        . '<link rel="icon" type="image/png" sizes="64x64" href="' . $e($base . '/image/favicon.png') . '">'
        . '<link rel="apple-touch-icon" href="' . $e($base . '/image/apple-touch-icon.png') . '">'
        // the site as an app (2026-11-19): installed from Chrome ("Install app" / "Add to Home screen"), its notifications
        // carry Traversence's own name and icon, not Chrome's. Only on traversence.com, where the manifest and push live.
        . ($base === '' ? '<link rel="manifest" href="/manifest.json"><meta name="theme-color" content="#92400E">' : '');
}
