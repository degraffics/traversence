<?php
// app/lib/WebPush.php — the push engine (decisions/0172 §4.6): our own keys (0108: needs no outside account), a
// subscription per device, each push linking to its message in Pulse and to "Stop these". Free to us: the browsers'
// push services carry it.
//   Keys (VAPID, RFC 8292): made by the site the first time and kept in .env as VAPID_PRIVATE_PEM_B64 (base64url of the
//   raw 32-byte private scalar d; the PEM is rebuilt from it when signing) and VAPID_PUBLIC_B64U (base64url of the
//   65-byte uncompressed point, the browser's applicationServerKey).
//   Payloads are encrypted per RFC 8291 (aes128gcm content coding, RFC 8188), one record.
//   Table push_subs (the release's migration). A 404/410 from a push service deletes the subscription; 5 failures in a
//   row mark it failed (tried again once a day until the device subscribes again).
// PHP 8.0 syntax; needs openssl and curl.

declare(strict_types=1);

final class WebPush
{
    public const SUBJECT = 'mailto:support@traversence.com';
    public const ENV_PRIVATE = 'VAPID_PRIVATE_PEM_B64';
    public const ENV_PUBLIC = 'VAPID_PUBLIC_B64U';
    public const MAX_PAYLOAD = 3072;
    public const STOP_URL = 'https://traversence.com/user/dashboard.php#communications';
    /** Push services a subscription may point at: exact hosts, and suffixes (a leading dot). */
    public const HOSTS = ['fcm.googleapis.com', 'updates.push.services.mozilla.com', 'web.push.apple.com', '.notify.windows.com', '.push.apple.com'];
    /** SubjectPublicKeyInfo for a P-256 point: this prefix, then the 65-byte uncompressed point. */
    private const SPKI_PREFIX = '3059301306072a8648ce3d020106082a8648ce3d030107034200';
    private const FAILS_TO_MARK = 5;

    /** For tests: swap the HTTP call (fn(string $url, array $headers, string $body): int status). */
    public static $transport = null;

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM push_subs LIMIT 0'); $ok = true; } catch (Throwable $e) { $ok = false; } }
        return $ok;
    }

    // ---- keys ---------------------------------------------------------------------------------------------------------

    /** [d (raw 32 bytes), public point (raw 65 bytes)]; made and written to .env the first time. */
    public static function keys(): array
    {
        [$d, $pub] = self::stored();
        if ($d !== '' && $pub !== '') return [$d, $pub];
        if (!class_exists('EnvSettings', false)) require_once __DIR__ . '/EnvSettings.php';
        // one maker at a time, so two first requests can't write a mismatched pair
        $lock = @fopen(rtrim(sys_get_temp_dir(), '/') . '/tv-vapid.lock', 'c');
        if ($lock) flock($lock, LOCK_EX);
        try {
            [$d, $pub] = self::stored(true);
            if ($d !== '' && $pub !== '') return [$d, $pub];
            [$d, $pub] = self::newPair();
            EnvSettings::setSecret(self::ENV_PUBLIC, self::b64u($pub));
            EnvSettings::setSecret(self::ENV_PRIVATE, self::b64u($d));
            return [$d, $pub];
        } finally { if ($lock) { flock($lock, LOCK_UN); fclose($lock); } }
    }

    /** The browser's applicationServerKey: base64url of the uncompressed point. */
    public static function publicKey(): string { return self::b64u(self::keys()[1]); }

    /** A fresh P-256 pair: [d (32 bytes), point (65 bytes)]. */
    public static function newPair(): array
    {
        $k = openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']);
        if ($k === false) throw new RuntimeException('openssl couldn\'t make a P-256 key.');
        $ec = openssl_pkey_get_details($k)['ec'];
        return [self::pad32($ec['d']), "\x04" . self::pad32($ec['x']) . self::pad32($ec['y'])];
    }

    private static function stored(bool $fresh = false): array
    {
        $get = function (string $k) use ($fresh): string {
            if ($fresh && class_exists('Database') && method_exists('Database', 'envPath')) {
                $p = Database::envPath();
                if (is_file($p) && preg_match('/^\s*' . $k . '\s*=\s*"?([A-Za-z0-9_-]+)"?\s*$/m', (string) file_get_contents($p), $m)) return $m[1];
            }
            if (class_exists('Database') && method_exists('Database', 'readEnv')) Database::readEnv();
            return trim((string) (getenv($k) ?: ($_ENV[$k] ?? '')));
        };
        $d = self::unb64u($get(self::ENV_PRIVATE)); $pub = self::unb64u($get(self::ENV_PUBLIC));
        return strlen($d) === 32 && strlen($pub) === 65 && $pub[0] === "\x04" ? [$d, $pub] : ['', ''];
    }

    /** An openssl public key from a raw 65-byte point. */
    public static function publicFromPoint(string $point)
    {
        if (strlen($point) !== 65 || $point[0] !== "\x04") throw new InvalidArgumentException('That isn\'t a P-256 public key.');
        $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode(hex2bin(self::SPKI_PREFIX) . $point), 64, "\n") . "-----END PUBLIC KEY-----\n";
        $k = openssl_pkey_get_public($pem);
        if ($k === false) throw new InvalidArgumentException('That public key isn\'t on the curve.');
        return $k;
    }

    /** An openssl private key from d and its point (SEC1 ECPrivateKey, RFC 5915). */
    public static function privateFromRaw(string $d, string $point)
    {
        $der = "\x02\x01\x01" . "\x04\x20" . $d
            . "\xa0\x0a\x06\x08" . hex2bin('2a8648ce3d030107')
            . "\xa1\x44\x03\x42\x00" . $point;
        $der = "\x30" . chr(strlen($der)) . $der;
        $pem = "-----BEGIN EC PRIVATE KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END EC PRIVATE KEY-----\n";
        $k = openssl_pkey_get_private($pem);
        if ($k === false) throw new RuntimeException('The push key in .env can\'t be read.');
        return $k;
    }

    // ---- subscriptions ------------------------------------------------------------------------------------------------

    /** Is this a push service we send to? https and a known host. */
    public static function allowedEndpoint(string $endpoint): bool
    {
        if (strlen($endpoint) > 600 || !preg_match('#^https://#i', $endpoint)) return false;
        $host = strtolower((string) parse_url($endpoint, PHP_URL_HOST));
        if ($host === '' || parse_url($endpoint, PHP_URL_PORT) !== null || parse_url($endpoint, PHP_URL_USER) !== null) return false;
        foreach (self::HOSTS as $h) {
            if ($h[0] === '.' ? (strlen($host) > strlen($h) && substr($host, -strlen($h)) === $h) : $host === $h) return true;
        }
        return false;
    }

    /** $sub is the browser's PushSubscription JSON: {endpoint, keys: {p256dh, auth}}. One row per device (endpoint). */
    public static function subscribe(PDO $pdo, int $uid, array $sub, string $device): void
    {
        $endpoint = trim((string) ($sub['endpoint'] ?? ''));
        $p256 = (string) ($sub['keys']['p256dh'] ?? ''); $auth = (string) ($sub['keys']['auth'] ?? '');
        if ($uid <= 0) throw new InvalidArgumentException('Please sign in.');
        if (!self::allowedEndpoint($endpoint)) throw new InvalidArgumentException('That browser\'s push service isn\'t one we send to.');
        if (!preg_match('/^[A-Za-z0-9_-]+=*$/', $p256) || strlen(self::unb64u($p256)) !== 65 || strlen($p256) > 200) throw new InvalidArgumentException('That device\'s push key isn\'t right. Try turning push off and on again.');
        if (!preg_match('/^[A-Za-z0-9_-]+=*$/', $auth) || strlen(self::unb64u($auth)) !== 16) throw new InvalidArgumentException('That device\'s push secret isn\'t right. Try turning push off and on again.');
        self::publicFromPoint(self::unb64u($p256));   // on the curve
        $device = mb_substr(trim(preg_replace('/[\x00-\x1f\x7f]+/u', ' ', $device) ?? ''), 0, 120);
        $pdo->prepare('INSERT INTO push_subs (user_id, endpoint, endpoint_hash, p256dh, auth_key, device, created_at, fails)
                       VALUES (?, ?, ?, ?, ?, ?, UTC_TIMESTAMP(), 0)
                       ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), endpoint = VALUES(endpoint), p256dh = VALUES(p256dh),
                         auth_key = VALUES(auth_key), device = VALUES(device), fails = 0, failed_at = NULL')
            ->execute([$uid, $endpoint, hash('sha256', $endpoint), rtrim($p256, '='), rtrim($auth, '='), $device]);
    }

    public static function unsubscribe(PDO $pdo, int $uid, string $endpoint): void
    {
        $pdo->prepare('DELETE FROM push_subs WHERE user_id = ? AND endpoint_hash = ?')->execute([$uid, hash('sha256', trim($endpoint))]);
    }

    /** Take one of the person's devices off by its id (from devices()). */
    public static function remove(PDO $pdo, int $uid, int $id): void
    {
        $pdo->prepare('DELETE FROM push_subs WHERE user_id = ? AND id = ?')->execute([$uid, $id]);
    }

    /** The person's devices: [{id, device, hash (sha256 of the endpoint, so a page can tell its own), created, last_ok, failed}]. */
    public static function devices(PDO $pdo, int $uid): array
    {
        $st = $pdo->prepare('SELECT id, device, endpoint_hash, created_at, last_ok_at, failed_at FROM push_subs WHERE user_id = ? ORDER BY created_at DESC');
        $st->execute([$uid]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $out[] = ['id' => (int) $r['id'], 'device' => (string) $r['device'], 'hash' => (string) $r['endpoint_hash'],
                      'created' => self::iso($r['created_at']), 'last_ok' => self::iso($r['last_ok_at']), 'failed' => self::iso($r['failed_at'])];
        }
        return $out;
    }

    // ---- sending ------------------------------------------------------------------------------------------------------

    /**
     * $msg: title, body, url (https://traversence.com/… the item in Pulse), stop (the "Stop these" link), tag, level
     * (critical|urgent|alert|notice|general|special). → ['sent', 'failed', 'held', 'none' (no devices)]
     */
    public static function sendToUser(PDO $pdo, int $uid, array $msg): array
    {
        $res = ['sent' => 0, 'failed' => 0, 'held' => 0, 'none' => true];
        $st = $pdo->prepare('SELECT id, endpoint, p256dh, auth_key FROM push_subs
                              WHERE user_id = ? AND (failed_at IS NULL OR failed_at < UTC_TIMESTAMP() - INTERVAL 1 DAY)');
        $st->execute([$uid]);
        $subs = $st->fetchAll(PDO::FETCH_ASSOC);
        if (!$subs) return $res;
        $res['none'] = false;
        $level = strtolower((string) ($msg['level'] ?? 'notice'));
        $payload = self::payload($msg);
        $headers = [
            'TTL: ' . (in_array($level, ['critical', 'urgent'], true) ? 86400 : 43200),
            'Urgency: ' . (in_array($level, ['critical', 'urgent'], true) ? 'high' : ($level === 'alert' ? 'normal' : 'low')),
            'Content-Type: application/octet-stream',
            'Content-Encoding: aes128gcm',
        ];
        $tag = (string) ($msg['tag'] ?? '');
        if (preg_match('/^[A-Za-z0-9_-]{1,32}$/', $tag)) $headers[] = 'Topic: ' . $tag;
        [$d, $pub] = self::keys();
        $priv = self::privateFromRaw($d, $pub);
        $jwts = [];
        foreach ($subs as $s) {
            $sid = (int) $s['id']; $endpoint = (string) $s['endpoint'];
            if (!self::allowedEndpoint($endpoint)) { self::drop($pdo, $sid); $res['failed']++; continue; }
            if (!class_exists('StagingGate', false)) require_once __DIR__ . '/StagingGate.php';
            if (StagingGate::hold($endpoint, 'Push to a device', 'user:' . $uid) !== null) { $res['held']++; continue; }   // staging: recorded there, not sent
            try {
                $body = self::encrypt($payload, (string) $s['p256dh'], (string) $s['auth_key']);
            } catch (Throwable $e) { self::failed($pdo, $sid); $res['failed']++; continue; }
            $aud = self::origin($endpoint);
            $jwt = $jwts[$aud] ??= self::jwt($aud, $priv);
            $h = array_merge($headers, ['Authorization: vapid t=' . $jwt . ', k=' . self::b64u($pub), 'Content-Length: ' . strlen($body)]);
            $code = self::post($endpoint, $h, $body);
            if ($code === 201 || $code === 202 || $code === 200) {
                $pdo->prepare('UPDATE push_subs SET last_ok_at = UTC_TIMESTAMP(), fails = 0, failed_at = NULL WHERE id = ?')->execute([$sid]);
                $res['sent']++;
            } elseif ($code === 404 || $code === 410) {
                self::drop($pdo, $sid); $res['failed']++;   // the device unsubscribed or expired: never tried again
            } else {
                self::failed($pdo, $sid); $res['failed']++;   // 400, 413, 429, 5xx, no answer
            }
        }
        return $res;
    }

    /** "Push works on this device", to each of the person's devices. */
    public static function test(PDO $pdo, int $uid): array
    {
        return self::sendToUser($pdo, $uid, [
            'title' => 'Push works on this device',
            'body' => 'This is how Traversence will reach you here. Choose what comes by push in your Communications setting.',
            'url' => self::STOP_URL, 'stop' => self::STOP_URL, 'tag' => 'push-test', 'level' => 'notice',
        ]);
    }

    /** The JSON the service worker reads, kept under 3 KB (the body is shortened first, then the title). */
    public static function payload(array $msg): string
    {
        $p = [
            'title' => mb_substr(trim((string) ($msg['title'] ?? 'Traversence')), 0, 120),
            'body' => trim((string) ($msg['body'] ?? '')),
            'url' => self::safeUrl((string) ($msg['url'] ?? ''), 'https://traversence.com/'),
            'stop' => self::safeUrl((string) ($msg['stop'] ?? ''), self::STOP_URL),
            'tag' => mb_substr((string) ($msg['tag'] ?? ''), 0, 64),
            'level' => strtolower((string) ($msg['level'] ?? 'notice')),
            'renotify' => !empty($msg['renotify']),   // alert again under the same tag only when the sender asks (push-sw.js)
        ];
        $enc = function (array $p): string { return (string) json_encode($p, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); };
        $j = $enc($p);
        while (strlen($j) > self::MAX_PAYLOAD && $p['body'] !== '') {
            $p['body'] = mb_substr($p['body'], 0, max(0, mb_strlen($p['body']) - max(16, (int) ((strlen($j) - self::MAX_PAYLOAD) / 2) + 1))) . '…';
            if (mb_strlen($p['body']) <= 1) $p['body'] = '';
            $j = $enc($p);
        }
        if (strlen($j) > self::MAX_PAYLOAD) { $p['url'] = 'https://traversence.com/'; $p['stop'] = self::STOP_URL; $j = $enc($p); }
        return $j;
    }

    // ---- RFC 8291 / RFC 8188 ------------------------------------------------------------------------------------------

    /**
     * Encrypts $payload for a subscription (ua public key and auth secret, base64url) as one aes128gcm record:
     * salt(16) | rs(4) | idlen(1)=65 | as_public(65) | ciphertext. $asPrivate (raw 32-byte d) and $salt are for tests
     * (RFC 8291 §5's vector); left out, a fresh ephemeral key and salt are made.
     */
    public static function encrypt(string $payload, string $uaPublicB64u, string $authB64u, ?string $asPrivate = null, ?string $salt = null): string
    {
        $uaPub = self::unb64u($uaPublicB64u); $auth = self::unb64u($authB64u);
        if (strlen($auth) !== 16) throw new InvalidArgumentException('The auth secret must be 16 bytes.');
        if (strlen($payload) > 4096 - 16 - 1) throw new InvalidArgumentException('That push is too long.');
        $uaKey = self::publicFromPoint($uaPub);
        if ($asPrivate === null) {
            $as = openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']);
            if ($as === false) throw new RuntimeException('openssl couldn\'t make a key.');
        } else {
            $as = self::privateFromD($asPrivate);
        }
        $ec = openssl_pkey_get_details($as)['ec'];
        $asPub = "\x04" . self::pad32($ec['x']) . self::pad32($ec['y']);
        $secret = openssl_pkey_derive($uaKey, $as, 32);
        if ($secret === false || strlen($secret) !== 32) throw new RuntimeException('The key agreement failed.');
        $salt = $salt ?? random_bytes(16);
        if (strlen($salt) !== 16) throw new InvalidArgumentException('The salt must be 16 bytes.');
        [$cek, $nonce] = self::derive($secret, $auth, $uaPub, $asPub, $salt);
        $tag = '';
        $ct = openssl_encrypt($payload . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
        if ($ct === false) throw new RuntimeException('Encryption failed.');
        return $salt . pack('N', 4096) . chr(65) . $asPub . $ct . $tag;
    }

    /** RFC 8291 §3.3–3.4: [CEK (16), NONCE (12)] from the ECDH secret, the auth secret and both public keys. */
    public static function derive(string $ecdh, string $auth, string $uaPub, string $asPub, string $salt): array
    {
        $ikm = hash_hkdf('sha256', $ecdh, 32, "WebPush: info\x00" . $uaPub . $asPub, $auth);
        return [
            hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\x00", $salt),
            hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\x00", $salt),
        ];
    }

    /** A private key from d alone (openssl works out the public point). */
    public static function privateFromD(string $d)
    {
        if (strlen($d) !== 32) throw new InvalidArgumentException('A P-256 private key is 32 bytes.');
        $der = "\x02\x01\x01\x04\x20" . $d . "\xa0\x0a\x06\x08" . hex2bin('2a8648ce3d030107');
        $der = "\x30" . chr(strlen($der)) . $der;
        $k = openssl_pkey_get_private("-----BEGIN EC PRIVATE KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END EC PRIVATE KEY-----\n");
        if ($k === false) throw new InvalidArgumentException('That private key can\'t be read.');
        return $k;
    }

    // ---- VAPID (RFC 8292) ---------------------------------------------------------------------------------------------

    /** An ES256 JWT for the push service's origin, good for 12 hours. */
    public static function jwt(string $aud, $privateKey = null, ?int $now = null): string
    {
        if ($privateKey === null) { [$d, $pub] = self::keys(); $privateKey = self::privateFromRaw($d, $pub); }
        $now = $now ?? time();
        $head = self::b64u('{"typ":"JWT","alg":"ES256"}');
        $claims = self::b64u((string) json_encode(['aud' => $aud, 'exp' => $now + 12 * 3600 - 60, 'sub' => self::SUBJECT], JSON_UNESCAPED_SLASHES));
        $sig = '';
        if (!openssl_sign($head . '.' . $claims, $sig, $privateKey, OPENSSL_ALGO_SHA256)) throw new RuntimeException('Signing the push key failed.');
        return $head . '.' . $claims . '.' . self::b64u(self::derToRaw($sig));
    }

    /** openssl's DER ECDSA signature (SEQUENCE of two INTEGERs) → raw r||s, 64 bytes. */
    public static function derToRaw(string $der): string
    {
        $i = 0;
        if (ord($der[$i++]) !== 0x30) throw new RuntimeException('Not a DER signature.');
        $len = ord($der[$i++]); if ($len & 0x80) $i += $len & 0x7f;
        $out = '';
        for ($n = 0; $n < 2; $n++) {
            if (ord($der[$i++]) !== 0x02) throw new RuntimeException('Not a DER signature.');
            $l = ord($der[$i++]);
            $out .= self::pad32(ltrim(substr($der, $i, $l), "\x00"));
            $i += $l;
        }
        return $out;
    }

    /** Raw r||s → DER (for checking a JWT with openssl_verify). */
    public static function rawToDer(string $raw): string
    {
        $int = function (string $b): string { $b = ltrim($b, "\x00"); if ($b === '' || ord($b[0]) & 0x80) $b = "\x00" . $b; return "\x02" . chr(strlen($b)) . $b; };
        $seq = $int(substr($raw, 0, 32)) . $int(substr($raw, 32, 32));
        return "\x30" . chr(strlen($seq)) . $seq;
    }

    // ---- helpers ------------------------------------------------------------------------------------------------------

    public static function b64u(string $b): string { return rtrim(strtr(base64_encode($b), '+/', '-_'), '='); }
    public static function unb64u(string $s): string
    {
        $s = strtr(rtrim(trim($s), '='), '-_', '+/');
        $r = base64_decode($s . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
        return $r === false ? '' : $r;
    }

    private static function pad32(string $b): string { return str_pad(substr($b, -32), 32, "\x00", STR_PAD_LEFT); }

    private static function origin(string $url): string
    {
        return 'https://' . strtolower((string) parse_url($url, PHP_URL_HOST));
    }

    private static function safeUrl(string $u, string $fallback): string
    {
        $u = trim($u);
        if ($u !== '' && $u[0] === '/' && (strlen($u) < 2 || $u[1] !== '/')) $u = 'https://traversence.com' . $u;
        return preg_match('#^https://([a-z0-9-]+\.)*(traversence\.com|trvgo\.us)(/|$)#i', $u) && strlen($u) <= 600 ? $u : $fallback;
    }

    private static function iso($t): ?string { return $t ? str_replace(' ', 'T', (string) $t) . 'Z' : null; }

    private static function drop(PDO $pdo, int $id): void { $pdo->prepare('DELETE FROM push_subs WHERE id = ?')->execute([$id]); }

    private static function failed(PDO $pdo, int $id): void
    {
        $pdo->prepare('UPDATE push_subs SET fails = fails + 1, failed_at = IF(fails >= ?, UTC_TIMESTAMP(), failed_at) WHERE id = ?')
            ->execute([self::FAILS_TO_MARK, $id]);
    }

    /** One POST; the status, 0 when nothing answered. */
    private static function post(string $url, array $headers, string $body): int
    {
        if (self::$transport !== null) return (int) (self::$transport)($url, $headers, $body);
        // @gate: called only from sendToUser(), after StagingGate::hold() was asked for this device's endpoint (decisions/0165)
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        ]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $code;
    }
}
