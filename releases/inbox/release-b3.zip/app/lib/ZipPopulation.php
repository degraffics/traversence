<?php

declare(strict_types=1);

/**
 * api/lib/ZipPopulation.php — 2020 Census population into zip_coordinates.population (decisions/0042).
 *
 * Used by admin/cluster-tools.php (browser) and api/scripts/import_zip_population.php (command line).
 * Needs migrations/2026-09-28_zip_population.sql first.
 *
 * Source: 2020 Decennial Census DHC, total population (P1_001N) for every ZIP Code Tabulation Area,
 * one request. The Census API needs a free key (https://api.census.gov/data/key_signup.html): set
 * CENSUS_API_KEY in the server .env, or paste it on the admin page. US ZIPs with no ZCTA (PO boxes, single-business ZIPs) are set to 0 — the
 * Census counts those residents under the surrounding ZIP — unless $fillMissing is false.
 */
final class ZipPopulation
{
    public const CENSUS_URL = 'https://api.census.gov/data/2020/dec/dhc?get=P1_001N&for=zip%20code%20tabulation%20area:*';

    /** The Census URL with the API key attached ($key, else CENSUS_API_KEY from .env). */
    public static function url(?string $key = null): string
    {
        $key = trim((string) ($key ?: getenv('CENSUS_API_KEY') ?: ''));
        return self::CENSUS_URL . ($key !== '' ? '&key=' . rawurlencode($key) : '');
    }

    /** Fetches the Census table. Throws RuntimeException with a readable reason on failure. */
    public static function fetch(?string $url = null): string
    {
        $url ??= self::url();
        if (function_exists('curl_init')) {
            require_once __DIR__ . '/ServiceHealth.php'; if (($held = ServiceHealth::held($url)) !== null) throw new RuntimeException('Census is held: ' . $held);
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 120]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err = curl_error($ch);
            curl_close($ch);
            ServiceHealth::seen($url, $code, $body, $err, 'Census populations');
            if ($body === false || $code !== 200) {
                throw new RuntimeException("Census request failed (HTTP $code" . ($err !== '' ? ", $err" : '') . ').');
            }
            return (string) $body;
        }
        $body = @file_get_contents($url);
        if ($body === false) {
            throw new RuntimeException('Census request failed (no curl, and file_get_contents could not reach it).');
        }
        return $body;
    }

    /**
     * Census API JSON -> [zip => population]. Throws if it isn't the full national table.
     *
     * @return array<string,int>
     */
    public static function parse(string $raw): array
    {
        if (preg_match('/<title>\s*(Missing|Invalid) Key\s*</i', $raw, $m)) {
            throw new RuntimeException(ucfirst(strtolower($m[1])) === 'Missing'
                ? 'The Census API wants a key. Get a free one at https://api.census.gov/data/key_signup.html (it arrives by email), then paste it into the key box.'
                : 'The Census API rejected that key. Check it was copied in full, and that you clicked the activation link in the Census email.');
        }
        $rows = json_decode($raw, true);
        if (!is_array($rows) || count($rows) < 2 || !is_array($rows[0])) {
            throw new RuntimeException('Not a Census API table. It starts with: ' . substr($raw, 0, 120));
        }
        $header = array_map('strtolower', $rows[0]);
        $popCol = array_search('p1_001n', $header, true);
        $zipCol = array_search('zip code tabulation area', $header, true);
        if ($popCol === false || $zipCol === false) {
            throw new RuntimeException('Missing the P1_001N or "zip code tabulation area" column; got: ' . implode(', ', $rows[0]));
        }
        $out = [];
        foreach (array_slice($rows, 1) as $r) {
            $zip = (string) ($r[$zipCol] ?? '');
            $pop = $r[$popCol] ?? null;
            if (preg_match('/^\d{5}$/', $zip) && is_numeric($pop) && (int) $pop >= 0) {
                $out[$zip] = (int) $pop;
            }
        }
        if (count($out) < 30000) {
            throw new RuntimeException('Only ' . count($out) . " ZCTAs — that's not the full national table (about 33,000).");
        }
        return $out;
    }

    public static function hasColumn(PDO $pdo): bool
    {
        return $pdo->query("SHOW COLUMNS FROM zip_coordinates LIKE 'population'")->fetch() !== false;
    }

    /** @return array{zips:int, with_population:int, zero:int, null:int} */
    public static function stats(PDO $pdo): array
    {
        $r = $pdo->query(
            'SELECT COUNT(DISTINCT zip) AS zips,
                    COUNT(DISTINCT CASE WHEN population > 0 THEN zip END) AS with_population,
                    COUNT(DISTINCT CASE WHEN population = 0 THEN zip END) AS zero,
                    COUNT(DISTINCT CASE WHEN population IS NULL THEN zip END) AS nulls
               FROM zip_coordinates'
        )->fetch(PDO::FETCH_ASSOC);
        return ['zips' => (int) $r['zips'], 'with_population' => (int) $r['with_population'], 'zero' => (int) $r['zero'], 'null' => (int) $r['nulls']];
    }

    /**
     * How the table would change, without writing.
     *
     * @param array<string,int> $population
     * @return array{zips:int, matched:int, missing:int}
     */
    public static function preview(PDO $pdo, array $population): array
    {
        $ours = $pdo->query("SELECT DISTINCT zip FROM zip_coordinates WHERE country_code = 'US' OR country_code IS NULL")->fetchAll(PDO::FETCH_COLUMN);
        $matched = 0;
        foreach ($ours as $zip) {
            if (isset($population[$zip])) $matched++;
        }
        return ['zips' => count($ours), 'matched' => $matched, 'missing' => count($ours) - $matched];
    }

    /**
     * Writes the populations in bulk (staging table + one joined UPDATE), so it finishes well inside
     * shared hosting's request time limit. Explicit collation: the live tables don't all share one
     * (see PlaceScope::C).
     *
     * @param array<string,int> $population
     */
    public static function apply(PDO $pdo, array $population, bool $fillMissing = true): void
    {
        $pdo->exec('DROP TEMPORARY TABLE IF EXISTS tv_zip_population');
        $pdo->exec('CREATE TEMPORARY TABLE tv_zip_population (zip CHAR(5) NOT NULL PRIMARY KEY, population INT UNSIGNED NOT NULL) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci');
        foreach (array_chunk($population, 1000, true) as $chunk) {
            $values = [];
            $args = [];
            foreach ($chunk as $zip => $pop) {
                $values[] = '(?, ?)';
                $args[] = (string) $zip;
                $args[] = $pop;
            }
            $pdo->prepare('INSERT INTO tv_zip_population (zip, population) VALUES ' . implode(',', $values))->execute($args);
        }
        $set = $fillMissing ? 'COALESCE(p.population, 0)' : 'p.population';
        $pdo->exec(
            "UPDATE zip_coordinates z LEFT JOIN tv_zip_population p ON p.zip = z.zip COLLATE utf8mb4_general_ci
                SET z.population = $set
              WHERE z.country_code = 'US' OR z.country_code IS NULL"
        );
        $pdo->exec('DROP TEMPORARY TABLE IF EXISTS tv_zip_population');
    }
}
