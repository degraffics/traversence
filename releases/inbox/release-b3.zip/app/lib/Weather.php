<?php
// app/lib/Weather.php — current weather and alerts for a guide's place (decisions/0131 §5), from the National Weather
// Service (api.weather.gov: free, official, no key; it asks for a User-Agent that says who we are). Our server asks
// for the place's point, never the visitor's location. Kept 40 minutes per place and renewed ahead of visitors by the
// guide_live_tick job (the grid lookup 30 days); one lookup asks for everything at once. When it's out of date or the
// service is down, the last good forecast shows (up to 12 hours). Anything that fails gives no weather card, never a broken page.
declare(strict_types=1);

require_once __DIR__ . '/PageCache.php';

final class Weather
{
    public const UA = 'Traversence guides (support@traversence.com)';
    private const API = 'https://api.weather.gov';

    /** @var callable|null for tests: fn(string $url): ?array */
    public static $fetch = null;

    /**
     * The weather at a point: now (temp_f, text, wind, humidity, pop, at), periods (the next fourteen: name, temp,
     * short, wind, pop, day, start), hours (the next 24: at, temp, pop, wind mph, short, day), days (up to seven: day,
     * hi, lo, short, pop, from the day and night periods), alerts (event, headline, severity, ends, instruction), link (the NWS forecast page). Null when it can't be had.
     */
    public static function at(PDO $pdo, float $lat, float $lon, bool $renew = false): ?array
    {
        $lat = round($lat, 3); $lon = round($lon, 3); $pt = $lat . ',' . $lon;
        if (!$renew) {
            $v = PageCache::get($pdo, 'wx3:' . $pt);
            if (is_array($v)) return empty($v['none']) ? $v : (PageCache::get($pdo, 'wxs:' . $pt) ?: null);   // failed lately: the last good one
            $old = PageCache::get($pdo, 'wxs:' . $pt);
            if (is_array($old)) { self::$later[$pt] = [$lat, $lon]; return $old; }   // out of date: shown now, renewed after the answer is sent
        }
        $v = self::build($pdo, $lat, $lon);
        if (!$v) { PageCache::put($pdo, 'wx3:' . $pt, 300, ['none' => 1]); return PageCache::get($pdo, 'wxs:' . $pt) ?: null; }   // another try in 5 minutes
        PageCache::put($pdo, 'wx3:' . $pt, self::FRESH, $v);
        PageCache::put($pdo, 'wxs:' . $pt, 12 * 3600, $v);   // the last good one, for when the service is slow or down
        return $v;
    }

    /** What's stored for a point (current, else the last good one), without asking the weather service: for drawing a page at once. */
    public static function stored(PDO $pdo, float $lat, float $lon): ?array
    {
        $pt = round($lat, 3) . ',' . round($lon, 3);
        $v = PageCache::get($pdo, 'wx3:' . $pt);
        if (is_array($v) && empty($v['none']) && !empty($v['now'])) return $v;
        $v = PageCache::get($pdo, 'wxs:' . $pt);
        return is_array($v) && !empty($v['now']) ? $v : null;
    }

    /**
     * What the weather means for what to do right now (decisions/0131 §3, Jason 2026-10-30): ['lead' => indoor|outdoor|'',
     * 'why' => a line for the page, 'warn' => true when an alert is out]. Indoor when there's a storm or a warning, rain
     * now or likely in the next hours, a heat or a cold that keeps people in, or a strong wind; outdoor on a fair day;
     * snow without a warning is left to the season (it's what the ski hill is for).
     */
    public static function conditions(?array $w): array
    {
        $none = ['lead' => '', 'why' => '', 'warn' => false];
        if (!$w || empty($w['now'])) return $none;
        $now = $w['now']; $t = $now['temp_f'] ?? null; $text = strtolower((string) ($now['text'] ?? ''));
        $soon = array_slice((array) ($w['hours'] ?? []), 0, 6);
        $pop = 0; $wet = ''; foreach ($soon as $h) { if ((int) $h['pop'] > $pop) { $pop = (int) $h['pop']; $wet = strtolower((string) $h['short']); } }
        $mph = (int) preg_replace('/\D.*/', '', (string) ($now['wind'] ?? '')) ?: (int) max(array_merge([0], array_column($soon, 'mph')));
        foreach ((array) ($w['alerts'] ?? []) as $a) if (in_array($a['severity'] ?? '', ['Extreme', 'Severe'], true))
            return ['lead' => 'indoor', 'why' => $a['event'] . ': indoor places first, and check the roads before you go.', 'warn' => true];
        if (str_contains($text, 'thunder') || str_contains($wet, 'thunder') && $pop >= 40) return ['lead' => 'indoor', 'why' => 'Thunderstorms ' . ($pop ? 'likely (' . $pop . '%)' : 'now') . ': indoor places first.', 'warn' => false];
        $snow = (bool) preg_match('/snow|flurr|sleet|blizzard/', $text . ' ' . $wet);
        if (!$snow && (preg_match('/rain|shower|drizzle/', $text) || $pop >= 50)) return ['lead' => 'indoor', 'why' => (preg_match('/rain|shower|drizzle/', $text) ? 'Raining now' : 'Rain likely in the next few hours (' . $pop . '%)') . ': indoor places first.', 'warn' => false];
        if ($t !== null && $t >= 95) return ['lead' => 'indoor', 'why' => $t . '° now: somewhere cool first, and water if you head out.', 'warn' => false];
        if ($t !== null && $t <= 20 && !$snow) return ['lead' => 'indoor', 'why' => $t . '° now: warm places first.', 'warn' => false];
        if ($mph >= 30) return ['lead' => 'indoor', 'why' => 'Strong wind (' . $mph . ' mph): sheltered places first.', 'warn' => false];
        if ($snow) return ['lead' => '', 'why' => '', 'warn' => false];
        if ($t !== null && $t >= 50 && $t <= 88 && $pop < 30 && preg_match('/sun|clear|fair|few clouds|partly/', $text)) return ['lead' => 'outdoor', 'why' => $t . '° and ' . strtolower((string) $now['text']) . ': a good time to be outside.', 'warn' => false];
        return $none;
    }

    /** How long a forecast counts as current; guide_live_tick renews each before it runs out, so visitors never wait. */
    public const FRESH = 2400;

    /** @var array<string, array{0: float, 1: float}> points shown out of date in this request, renewed at its end */
    private static array $later = [];

    /** After the answer is sent (guide-live.php's shutdown): renew what was shown out of date. */
    public static function renewLater(PDO $pdo): void
    {
        if (!self::$later) return;
        if (function_exists('fastcgi_finish_request')) fastcgi_finish_request(); elseif (function_exists('litespeed_finish_request')) litespeed_finish_request();
        foreach (self::$later as [$lat, $lon]) self::at($pdo, $lat, $lon, true);
        self::$later = [];
    }

    /**
     * Keep each point current (guide_live_tick): renews those running out within $ahead seconds, the soonest first,
     * until $budget seconds have gone. Returns [renewed, failed].
     */
    public static function warm(PDO $pdo, array $points, int $ahead = 1200, int $budget = 240): array
    {
        $t0 = time(); $ok = 0; $bad = 0; $due = [];
        foreach ($points as [$lat, $lon]) {
            $pt = round((float) $lat, 3) . ',' . round((float) $lon, 3);
            $st = $pdo->prepare('SELECT UNIX_TIMESTAMP(expires_at) FROM page_cache WHERE cache_key = ?'); $st->execute(['wx3:' . $pt]);
            $exp = (int) $st->fetchColumn();
            if ($exp - time() < $ahead) $due[$pt] = [$exp, (float) $lat, (float) $lon];
        }
        uasort($due, fn ($a, $b) => $a[0] <=> $b[0]);
        foreach ($due as [, $lat, $lon]) {
            if (time() - $t0 > $budget) break;
            if (self::at($pdo, $lat, $lon, true)) $ok++; else $bad++;
        }
        return [$ok, $bad];
    }

    private static function build(PDO $pdo, float $lat, float $lon): ?array
    {
        // the point's forecast addresses and its nearest stations: kept 30 days (they don't move); a failed lookup isn't kept
        $ptKey = 'wx:pt3:' . $lat . ',' . $lon;
        $pt = PageCache::get($pdo, $ptKey);
        if (!is_array($pt)) {
            $p = self::get(self::API . '/points/' . $lat . ',' . $lon)['properties'] ?? null;
            if (!$p || empty($p['forecast'])) return null;
            $ids = [];
            if (!empty($p['observationStations'])) foreach (array_slice((array) (self::get((string) $p['observationStations'])['features'] ?? []), 0, 3) as $st)
                if (($sid = (string) ($st['properties']['stationIdentifier'] ?? '')) !== '') $ids[] = $sid;
            $pt = ['forecast' => (string) $p['forecast'], 'hourly' => (string) ($p['forecastHourly'] ?? ''), 'stations' => $ids, 'tz' => (string) ($p['timeZone'] ?? '')];
            PageCache::put($pdo, $ptKey, 30 * 86400, $pt);
        }
        // everything else at once: the forecast, the hours, the alerts and the latest from the nearest stations
        $urls = ['f' => $pt['forecast'], 'a' => self::API . '/alerts/active?point=' . $lat . ',' . $lon];
        if ($pt['hourly'] !== '') $urls['h'] = $pt['hourly'];
        foreach ($pt['stations'] as $i => $sid) $urls['o' . $i] = self::API . '/stations/' . rawurlencode($sid) . '/observations/latest';
        $r = self::getMany($urls);
        $out = ['now' => null, 'periods' => [], 'alerts' => [], 'tz' => $pt['tz'],
                'link' => 'https://forecast.weather.gov/MapClick.php?lat=' . $lat . '&lon=' . $lon, 'at' => date('c')];
        $f = $r['f'] ?? null;
        $em = $f['properties']['elevation']['value'] ?? null;   // the forecast's own elevation (meters): a guide's elevation when nobody has set it
        if (is_numeric($em)) $out['elev_ft'] = (int) round((float) $em * 3.28084);
        foreach (array_slice((array) ($f['properties']['periods'] ?? []), 0, 14) as $p)
            $out['periods'][] = ['name' => (string) ($p['name'] ?? ''), 'temp' => isset($p['temperature']) ? (int) $p['temperature'] : null, 'unit' => (string) ($p['temperatureUnit'] ?? 'F'),
                                 'short' => (string) ($p['shortForecast'] ?? ''), 'wind' => trim(($p['windSpeed'] ?? '') . ' ' . ($p['windDirection'] ?? '')),
                                 'pop' => isset($p['probabilityOfPrecipitation']['value']) ? (int) $p['probabilityOfPrecipitation']['value'] : null, 'day' => !empty($p['isDaytime']),
                                 'start' => (string) ($p['startTime'] ?? '')];
        if (!$out['periods']) return null;
        $out['days'] = self::days($out['periods']);
        // the next 24 hours, for the graph (and "now" when no station has reported)
        $hours = [];
        foreach ((array) ($r['h']['properties']['periods'] ?? []) as $h) {
            if (strtotime((string) ($h['endTime'] ?? '')) <= time()) continue;
            $hours[] = ['at' => (string) ($h['startTime'] ?? ''), 'temp' => isset($h['temperature']) ? (int) $h['temperature'] : null, 'short' => (string) ($h['shortForecast'] ?? ''),
                        'pop' => (int) ($h['probabilityOfPrecipitation']['value'] ?? 0), 'mph' => (int) ($h['windSpeed'] ?? 0), 'wind' => trim(($h['windSpeed'] ?? '') . ' ' . ($h['windDirection'] ?? '')),
                        'humidity' => isset($h['relativeHumidity']['value']) ? (int) $h['relativeHumidity']['value'] : null, 'day' => !empty($h['isDaytime'])];
            if (count($hours) === 24) break;
        }
        $out['hours'] = $hours;
        // now: the latest observation from the nearest station that has reported in the last two hours (the nearest is
        // often a remote one that reports rarely: the three nearest are asked), else this hour's forecast, never the day's high
        foreach ($pt['stations'] as $i => $sid) {
            $o = $r['o' . $i]['properties'] ?? null;
            $c = $o['temperature']['value'] ?? null;
            if (!$o || $c === null || strtotime((string) ($o['timestamp'] ?? '')) < time() - 7200) continue;
            $w = $o['windSpeed']['value'] ?? null; $unit = (string) ($o['windSpeed']['unitCode'] ?? '');
            $mph = $w === null ? null : (int) round(str_contains($unit, 'km_h') ? $w * 0.621371 : (str_contains($unit, 'm_s') ? $w * 2.23694 : $w));
            $rh = $o['relativeHumidity']['value'] ?? null;
            $out['now'] = ['temp_f' => (int) round($c * 9 / 5 + 32), 'text' => (string) ($o['textDescription'] ?? ''), 'wind' => $mph !== null ? $mph . ' mph' . self::compass($o['windDirection']['value'] ?? null) : '',
                           'humidity' => $rh !== null ? (int) round($rh) : ($hours[0]['humidity'] ?? null), 'pop' => $hours[0]['pop'] ?? null,
                           'at' => (string) $o['timestamp'], 'station' => $sid, 'forecast' => false];
            break;
        }
        if (!$out['now'] && $hours) {
            $h = $hours[0];
            $out['now'] = ['temp_f' => $h['temp'], 'text' => $h['short'], 'wind' => $h['wind'], 'humidity' => $h['humidity'], 'pop' => $h['pop'], 'at' => '', 'station' => '', 'forecast' => true];
        }
        if (!$out['now'] || $out['now']['temp_f'] === null) return null;   // no reading and no hourly forecast: no card, rather than a wrong number
        foreach ((array) ($r['a']['features'] ?? []) as $a) {
            $p = $a['properties'] ?? [];
            if (($p['status'] ?? 'Actual') !== 'Actual' || ($p['messageType'] ?? '') === 'Cancel') continue;
            $out['alerts'][] = ['event' => (string) ($p['event'] ?? 'Weather alert'), 'headline' => (string) ($p['headline'] ?? ''), 'severity' => (string) ($p['severity'] ?? ''),
                                'ends' => (string) ($p['ends'] ?? $p['expires'] ?? ''), 'instruction' => mb_substr(trim((string) ($p['instruction'] ?? '')), 0, 600),
                                'description' => mb_substr(trim((string) ($p['description'] ?? '')), 0, 900)];
        }
        usort($out['alerts'], fn ($x, $y) => self::rank($y['severity']) <=> self::rank($x['severity']));
        return $out;
    }

    /** The day and night periods as days: Thu 74° / 41° (a night with no day before it, as on the evening of today, starts its own). */
    private static function days(array $periods): array
    {
        $days = [];
        foreach ($periods as $p) {
            try { $d = new DateTime($p['start'] !== '' ? $p['start'] : 'now'); } catch (Throwable $e) { continue; }   // keeps the place's own offset, so a night stays on its day
            $date = $d->format('Y-m-d'); $last = $days ? count($days) - 1 : -1;
            if ($p['day'] || $last < 0 || $days[$last]['date'] !== $date) {
                if (count($days) === 7) break;
                $days[] = ['date' => $date, 'day' => $d->format('D'), 'hi' => $p['day'] ? $p['temp'] : null, 'lo' => $p['day'] ? null : $p['temp'],
                           'short' => $p['short'], 'pop' => (int) ($p['pop'] ?? 0), 'night' => !$p['day']];
            } else {
                $days[$last]['lo'] = $p['temp']; $days[$last]['pop'] = max($days[$last]['pop'], (int) ($p['pop'] ?? 0));
            }
        }
        return $days;
    }

    private static function rank(string $s): int { return ['Extreme' => 4, 'Severe' => 3, 'Moderate' => 2, 'Minor' => 1][$s] ?? 0; }

    private static function compass($deg): string
    {
        if ($deg === null) return '';
        return ' ' . ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][(int) round(((float) $deg % 360) / 45) % 8];
    }

    /** GET several JSON documents at once (key => url): each answer, or null for one that failed. */
    private static function getMany(array $urls): array
    {
        if (self::$fetch || !function_exists('curl_multi_init')) return array_map(fn ($u) => self::get($u), $urls);
        $mh = curl_multi_init(); $hs = [];
        foreach ($urls as $k => $u) {
            $ch = curl_init($u);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 6, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_FOLLOWLOCATION => true, CURLOPT_ENCODING => '',
                                    CURLOPT_HTTPHEADER => ['User-Agent: ' . self::UA, 'Accept: application/geo+json']]);
            curl_multi_add_handle($mh, $ch); $hs[$k] = $ch;
        }
        do { $st = curl_multi_exec($mh, $running); if ($running) curl_multi_select($mh, 1.0); } while ($running && $st === CURLM_OK);
        $out = [];
        foreach ($hs as $k => $ch) {
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $body = curl_multi_getcontent($ch);
            if ($code >= 500 || $code === 0) error_log('weather: ' . $code . ' ' . $urls[$k]);
            $j = $code > 0 && $code < 400 && is_string($body) ? json_decode($body, true) : null;
            $out[$k] = is_array($j) ? $j : null;
            curl_multi_remove_handle($mh, $ch); curl_close($ch);
        }
        curl_multi_close($mh);
        return $out;
    }

    /** GET a JSON document (the NWS asks for a User-Agent and geo+json). */
    private static function get(string $url): ?array
    {
        if (self::$fetch) return (self::$fetch)($url);
        if (!function_exists('curl_init')) return null;
        require_once __DIR__ . '/ServiceHealth.php'; if (ServiceHealth::held($url) !== null) return null;   // held or paused (0163 stage 2)
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 6, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_FOLLOWLOCATION => true, CURLOPT_ENCODING => '',
                                CURLOPT_HTTPHEADER => ['User-Agent: ' . self::UA, 'Accept: application/geo+json']]);
        $body = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        ServiceHealth::seen($url, $code, $body, '', 'Weather');
        if (!is_string($body) || $code >= 400) { if ($code >= 500 || $code === 0) error_log('weather: ' . $code . ' ' . $url); return null; }
        $j = json_decode($body, true);
        return is_array($j) ? $j : null;
    }

    /** "Snow" → the icon to draw (tv_icon has no weather icons: a small inline set, flat like the brand's). */
    public static function icon(string $text, bool $day = true): string
    {
        $t = strtolower($text);
        $k = str_contains($t, 'thunder') ? 'storm' : (preg_match('/snow|flurr|blizzard|sleet|ice/', $t) ? 'snow' : (preg_match('/rain|shower|drizzle/', $t) ? 'rain'
            : (preg_match('/fog|haze|smoke|dust/', $t) ? 'fog' : (preg_match('/cloud|overcast/', $t) ? (str_contains($t, 'partly') || str_contains($t, 'mostly sunny') ? 'part' : 'cloud') : ($day ? 'sun' : 'moon')))));
        $p = ['sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
              'moon' => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
              'part' => '<path d="M12 2v2M4.9 4.9l1.4 1.4M2 12h2M19.1 4.9l-1.4 1.4"/><path d="M16 12a4 4 0 0 0-7.7-1.5"/><path d="M17.5 21H9a5 5 0 1 1 4.6-7h1.9a3.5 3.5 0 0 1 0 7z"/>',
              'cloud' => '<path d="M17.5 19H9a7 7 0 1 1 6.7-9h1.8a4.5 4.5 0 0 1 0 9z"/>',
              'rain' => '<path d="M16 13v8M8 13v8M12 15v8"/><path d="M20 16.6A5 5 0 0 0 18 7h-1.3A8 8 0 1 0 4 15.3"/>',
              'snow' => '<path d="M20 17.6A5 5 0 0 0 18 8h-1.3A8 8 0 1 0 4 16.3"/><path d="M8 16h.01M8 20h.01M12 18h.01M12 22h.01M16 16h.01M16 20h.01"/>',
              'storm' => '<path d="M19 16.9A5 5 0 0 0 18 7h-1.3A8 8 0 1 0 4 15.3"/><path d="M13 11l-4 6h6l-4 6"/>',
              'fog' => '<path d="M4 14h16M4 18h16M6 10h12M8 6h8"/>'][$k];
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
    }
}
