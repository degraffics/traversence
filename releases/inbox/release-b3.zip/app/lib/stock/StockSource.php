<?php
// app/lib/stock/StockSource.php — one place the stock library (decisions/0143) finds photos. Each source is one adapter
// in this folder and one line in StockLibrary::SOURCES; adding the Park Service, Unsplash or Pexels later is one more
// of each. An adapter only asks its source and says what it found, in the same shape for every source:
//   id, title, about, tags, thumb (for the search's own results only), full (what we copy), width, height,
//   licence, licence_url, author, credit, source_url, rights (the source's own rights line, when it has one), and
//   held ('copy': we keep a WebP copy; 'link': shown from the source, for a source that asks for that).
// Whether a licence allows our use, and whether a photo may show a protected place, is decided by StockLibrary, never
// here, so every source is held to the same rules (decisions/0133: the licence decides the use).
declare(strict_types=1);

abstract class StockSource
{
    /** Requests carry who we are and how to reach us (Wikimedia asks for it; it's polite everywhere). */
    public const UA = 'Traversence stock library/1.0 (https://traversence.com; support@traversence.com)';

    abstract public function key(): string;
    abstract public function name(): string;
    /** The hosts a photo may be fetched from (anything else is refused). */
    abstract public function hosts(): array;
    /** [items, more?] for a search, page 1 first. */
    abstract public function search(string $q, int $page): array;
    /** One photo, fresh from the source (adding never trusts what a page sent). Null when it isn't there. */
    abstract public function item(string $id): ?array;

    /** Whether it can be used now ('' = yes, else why not: a missing key). */
    public function missing(): string { return ''; }
    /** How its photos are held: 'copy' (WebP in our storage) or 'link'. */
    public function held(): string { return 'copy'; }
    /** How long its searches are kept (seconds). */
    public function cacheFor(): int { return 86400; }

    protected static function getJson(string $url, array $headers = []): ?array
    {
        require_once __DIR__ . '/../StagingGate.php';
        if (StagingGate::hold($url, 'stock photo search') !== null) return null;   // staging: held or paced (decisions/0165 §1); nothing on live
        require_once __DIR__ . '/../ServiceHealth.php'; if (ServiceHealth::held($url) !== null) return null;
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_ENCODING => '',
            CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_HTTPHEADER => array_merge(['User-Agent: ' . self::UA, 'Accept: application/json'], $headers)]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        ServiceHealth::seen($url, $code, $body, '', 'Stock photos');
        curl_close($ch);
        if (!is_string($body) || $code >= 400 || $code === 0) { error_log('stock ' . parse_url($url, PHP_URL_HOST) . ': HTTP ' . $code); return null; }
        $d = json_decode($body, true);
        return is_array($d) ? $d : null;
    }

    /** Plain text from a source's HTML field. */
    protected static function text($v, int $max = 300): string
    {
        if (is_array($v)) $v = implode('; ', array_map(fn ($x) => is_scalar($x) ? (string) $x : '', $v));
        $t = html_entity_decode(strip_tags((string) $v), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return mb_substr(trim((string) preg_replace('/\s+/u', ' ', $t)), 0, $max);
    }
}
