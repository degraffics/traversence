<?php
// app/lib/MarketRules.php — what can be sold on the Marketplace (decisions/0142 §4): written rules, applied the same way to
// every business, checked when an item is published, never a silent removal (the business sees the reason). At least as
// strict as Stripe's and Square's own restricted lists; each gateway's own list still applies on top.
//   prohibited   never listed: the item doesn't go up, and the business is told why
//   restricted   allowed once the business confirms its license and the conditions (a record, Acceptance); card checkout
//                is off for it (a direct way of paying or a quote): Stripe and Square restrict these themselves
//   confirm      lawful with conditions (meat, eggs, homemade food, animals, lodging): the business confirms them once (a
//                record); card checkout stays on, and buyers see the conditions
//   notice       fine, with a notice buyers see on the item
//   review       a word our team looks at first (the Marketplace's "hold" list): it waits in the admin's Business items
// Plus the Marketplace's own lists (System Configuration → the Marketplace's settings): "blocked" words are prohibited,
// "hold" words go to review. Reports use the takedown path; repeats, the standing ladder (decisions/0079).
declare(strict_types=1);

require_once __DIR__ . '/Market.php';
require_once __DIR__ . '/Database.php';

final class MarketRules
{
    /** key => [tier, name, words (a regex, matched whole-word in the title, description and category), why or conditions] */
    public const RULES = [
        // prohibited
        'weapons' => ['prohibited', 'Weapons and ammunition', '(fire ?arms?|guns?|rifles?|shotguns?|pistols?|handguns?|revolvers?|ammo|ammunition|silencers?|suppressors?|explosives?|fireworks|grenades?|switchblades?|brass knuckles)', 'Weapons, firearms, ammunition, explosives and their parts can\'t be sold here.'],
        'drugs' => ['prohibited', 'Drugs', '(marijuana|cannabis|thc|weed edibles?|psilocybin|magic mushrooms|cocaine|meth|kratom|bongs?|pipes? for smoking|drug paraphernalia)', 'Illegal drugs, marijuana and drug paraphernalia can\'t be sold here.'],
        'medicine' => ['prohibited', 'Prescription medicine', '(prescription|rx only|opioids?|oxycodone|adderall|xanax|insulin|antibiotics?)', 'Prescription medicines can\'t be sold here.'],
        'fakes' => ['prohibited', 'Counterfeit or stolen goods', '(counterfeit|replica|knock ?off|bootleg|stolen|fake (?:id|designer))', 'Counterfeit, infringing or stolen goods can\'t be sold here.'],
        'hazmat' => ['prohibited', 'Hazardous materials', '(hazardous|toxic waste|asbestos|lead paint|pesticides? \(restricted\)|radioactive)', 'Hazardous materials can\'t be sold here.'],
        'adult' => ['prohibited', 'Adult content and services', '(adult entertainment|escorts?|xxx|porn\w*|sexual services)', 'Adult sexual content and services can\'t be sold here.'],
        'gambling' => ['prohibited', 'Gambling and raffles', '(raffles?|lottery|lotteries|sweepstakes|casino chips|betting)', 'Gambling, lotteries and raffles can\'t be sold here.'],
        'finance' => ['prohibited', 'Investments and schemes', '(crypto ?currency|bitcoin|nfts?|securities|stocks? and shares|investment opportunity|mlm|multi-level marketing|get rich)', 'Securities, crypto, investment schemes and multi-level marketing can\'t be sold here.'],
        'documents' => ['prohibited', 'Government IDs and documents', '(passports?|driver\'?s licen[cs]es?|social security cards?|birth certificates?|license plates?)', 'Government IDs and documents can\'t be sold here.'],
        'remains' => ['prohibited', 'Human remains and protected sites', '(human (?:remains|skulls?|bones?)|grave goods|burial (?:items|artifacts?)|from a grave)', 'Human remains, and anything taken from a burial, sacred or protected site, can\'t be sold here.'],
        'wildlife' => ['prohibited', 'Endangered species', '(ivory|eagle feathers?|rhino horn|tortoise ?shell|endangered)', 'Endangered species and their parts can\'t be sold here.'],
        // restricted: [conditions]: the payment processors restrict these themselves, so card checkout is off for them
        'alcohol' => ['restricted', 'Alcohol', '(beer|wine|wines|spirits|whiske?y|vodka|tequila|bourbon|mead|hard cider|liquor|brewery|winery)', 'You hold the state liquor license for selling it; it\'s not shipped where that isn\'t allowed; buyers are 21 or older, checked at pickup.'],
        'tobacco' => ['restricted', 'Tobacco and vapes', '(tobacco|cigars?|cigarettes?|vapes?|vaping|e-?liquid|nicotine)', 'You hold the license to sell it; buyers are 21 or older, checked at pickup.'],
        'cbd' => ['restricted', 'CBD and hemp', '(cbd|hemp oil|delta[- ]?8)', 'It\'s lab-tested and legal in its content, with the test results available to buyers.'],
        // confirm: [conditions]: lawful with conditions; the business confirms them once, card checkout stays on (Jason, 2026-11-03)
        'cottage' => ['confirm', 'Homemade food', '(cottage food|baked goods|jams?|jelly|jellies|salsa|tamales|cookies?|pies?|cakes?|cupcakes?|brownies?|fudge|candy|tortillas?|pickles|granola|cinnamon rolls?)', 'Made by a licensed kitchen, or registered under Arizona\'s cottage food program (or your state\'s) and labeled as made in a home kitchen; not a food that needs refrigeration unless it\'s from a licensed kitchen.'],
        'meat' => ['confirm', 'Meat and dairy', '(beef|pork|lamb|goat meat|poultry|chicken meat|raw milk|cheese|butcher\w*)', 'Made or processed by a USDA- or state-inspected processor (meat) or a licensed dairy, packaged and labeled, and kept cold until it\'s handed over. Homemade meat products can\'t be sold.'],
        'eggs' => ['confirm', 'Eggs', '(eggs)', 'Clean, kept at 45°F or below, in cartons labeled with your farm\'s name and the pack date.'],
        'animals' => ['confirm', 'Live animals and plants', '(puppies|puppy|kittens?|baby chicks|live ?stock for sale|live animals?|(?:horses?|cattle|goats?|sheep|pigs?|cows?|chickens?) for sale|seedlings|live plants)', 'It meets your state\'s rules for selling animals or plants (health papers, permits, age).'],
        'lodging' => ['confirm', 'Lodging', '(lodging|cabin rental|vacation rental|overnight stay|airbnb)', 'You collect and pay local lodging tax and follow local short-term rental rules.'],
        'tickets' => ['confirm', 'Resold tickets', '(resale tickets?|resold tickets?|ticket resale)', 'Resale above face value only where the law allows it.'],
        // notice: [what buyers see]
        'perishable' => ['notice', 'Perishable', '(fresh|produce|perishable|harvest|flowers|bread)', 'Perishable: pick it up or receive it promptly; freshness is the seller\'s to describe.'],
        'used' => ['notice', 'Used or as-is', '(used|as[- ]is|refurbished|vintage|second-?hand|pre-?owned)', 'Used or sold as-is: its condition is as described by the seller.'],
        'madetoorder' => ['notice', 'Made to order', '(custom|made to order|personali[sz]ed|commission(?:ed)?)', 'Made to order: no returns once it\'s made, unless the store policies say otherwise.'],
        'digital' => ['notice', 'Digital goods', '(download|digital file|printable|ebook|e-book|pdf)', 'Digital: no refunds after download, unless the store policies say otherwise.'],
    ];

    private const RANK = ['prohibited' => 5, 'review' => 4, 'restricted' => 3, 'confirm' => 2, 'notice' => 1, 'ok' => 0];

    /**
     * Reading a name the way search reads a query (Jason, 2026-11-03: "a wine rack isn't wine"): for these rules a word
     * counts only when it's the thing itself, the last noun of its phrase. "wine rack", "beer mug", "gun safe", "cheese
     * board": the thing is the rack, the mug, the safe, the board. A following word in the list still means the thing
     * ("beef jerky", "CBD oil", "rifle parts"). Rules not listed are describing words that count wherever they stand
     * ("counterfeit", "stolen", "hazardous").
     */
    private const HEADS = [
        'alcohol' => '(merlot|cabernet|chardonnay|pinot|zinfandel|ros[eé]|blend|ipa|lager|ale|stout|porter|pack|packs|flight|sampler|tasting|gift|club)',
        'tobacco' => '(pens?|juice|kits?|mods?|pods?|cartridges?|carts?|leaf|pouches|cans?)',
        'cbd' => '(oil|gummies|tinctures?|creams?|balms?|capsules|edibles|isolate|flower|lotions?|salves?|drops|pens?|cartridges?)',
        'cottage' => '(jars?|box|boxes|dozen|platter|basket)',
        'meat' => '(jerky|sticks?|patties|steaks?|roasts?|sausages?|bundles?|shares?|quarters?|halves|cuts|curds|wheels?|blocks?|dozen|cartons? full)',
        'weapons' => '(parts?|kits?|magazines?|mags?|barrels?|triggers?|receivers?|frames?|slides?|bolts?|stocks?|uppers?|lowers?|rounds?|shells?|cartridges?)',
        'drugs' => '(seeds?|oil|flower|edibles|gummies|cartridges?|carts?|plants?|clones?)',
        'medicine' => '(pills?|tablets?|capsules|bottles? full)',
        'wildlife' => '(carvings?|figurines?|jewelry|necklaces?|earrings?|bracelets?|tusks?|pieces?|fans?)',
        'gambling' => '(tickets?|boards?|machines?)',
        'documents' => '(numbers?)',
        'animals' => '',
        'eggs' => '(dozen|cartons?|flats?)',
        'listed' => '(parts?|kits?|sets?|pieces?|accessor(?:y|ies)|lots?|bundles?|packs?)',   // a word on the Marketplace's own lists: "gun parts" is guns; a "gun holster" is a holster
    ];
    private const JOINS = ['and', 'or', 'with', 'plus', 'by', 'from', 'in', 'at', 'on', 'of', 'per', 'x', 'the', 'a', 'an', 'to', 'n'];   // words between two things, not one describing the other

    /** Is the match at $at (bytes) in $text the thing itself, or a word describing something else? */
    private static function isThing(string $text, int $at, int $len, string $key): bool
    {
        if (!array_key_exists($key, self::HEADS)) return true;   // a describing rule: counts wherever it stands
        $keep = self::HEADS[$key];
        $after = substr($text, $at + $len);
        if (preg_match('/^-(\p{L}+)/u', $after, $m)) return $keep !== '' && preg_match('/^' . $keep . '$/iu', $m[1]) === 1;   // "wine-making kit": a compound describing the kit
        if (preg_match('/(?:^|\s)(for|holds?|holder|holding|fits?|stores?|storing)(?:\s+[^\s.;!?]+){0,3}\s*$/iu', substr($text, 0, $at))) return false;   // "a rack for wine", "holds 10 rifles and ammo"
        if (!preg_match('/^[ \t]+(\p{L}[\p{L}\'-]*)/u', $after, $m)) return true;   // nothing after it, or punctuation, a number ("beer, 6-pack"): it's the thing
        $next = mb_strtolower($m[1]);
        if (in_array($next, self::JOINS, true)) return true;   // "wine and cheese": both are things
        if ($keep !== '' && preg_match('/^' . $keep . '$/iu', $next)) return true;   // "beef jerky": still the thing
        require_once __DIR__ . '/WordFamilies.php';
        return !str_contains(WordFamilies::partsOf($next), 'n');   // another noun after it: that's the thing ("wine rack")
    }

    /**
     * Checks an item. Returns the strongest match: ['tier' => ok|notice|restricted|review|prohibited, 'key', 'name', 'why',
     * 'word' (what matched)]. Prohibited beats review beats restricted beats notice.
     */
    public static function check(?PDO $pdo, string $title, string $about, string $category = '', string $kind = ''): array
    {
        // the name decides; the description only sends a prohibited word to our team (prose like "holds 10 rifles" in a gun safe's)
        $best = ['tier' => 'ok', 'key' => '', 'name' => '', 'why' => '', 'word' => ''];
        $take = function (array $r) use (&$best) { if (self::RANK[$r['tier']] > self::RANK[$best['tier']]) $best = $r; };
        foreach (['name' => mb_strtolower($title), 'about' => mb_strtolower($about)] as $where => $text) {
            if ($text === '') continue;
            foreach (self::RULES as $k => [$tier, $name, $re, $why]) {
                if ($where === 'about' && $tier !== 'prohibited') continue;
                if (!preg_match_all('/(?<![\p{L}\p{N}])' . $re . '(?![\p{L}\p{N}])/iu', $text, $ms, PREG_OFFSET_CAPTURE)) continue;
                foreach ($ms[0] as [$word, $at]) {
                    if (!self::isThing($text, (int) $at, strlen($word), $k)) continue;
                    if ($where === 'about') $take(['tier' => 'review', 'key' => $k, 'name' => $name, 'why' => 'Its description mentions ' . mb_strtolower($name) . ' (“' . $word . '”), so our team looks first, usually within a day.', 'word' => $word]);
                    else $take(['tier' => $tier, 'key' => $k, 'name' => $name, 'why' => $why, 'word' => $word]);
                    break;
                }
            }
        }
        // the kind's own notice or conditions (decisions/0141 §5): Digital, Made to order, Harvest, Bookings, whatever the words say
        if ($kind !== '') {
            require_once __DIR__ . '/ItemKinds.php';
            $rk = ItemKinds::RULE[ItemKinds::key($kind)] ?? '';
            if ($rk !== '' && isset(self::RULES[$rk])) { [$tier, $name, , $why] = self::RULES[$rk]; $take(['tier' => $tier, 'key' => $rk, 'name' => $name, 'why' => $why, 'word' => '']); }
        }
        if ($pdo) try {
            [$w, $where] = self::listed($pdo, 'blocked', $title, $about);
            if ($w !== '' && $where === 'name') $take(['tier' => 'prohibited', 'key' => 'listed', 'name' => '“' . $w . '”', 'why' => '“' . $w . '” is on the list of what can\'t be sold on the Marketplace.', 'word' => $w]);
            elseif ($w !== '') $take(['tier' => 'review', 'key' => 'hold', 'name' => '“' . $w . '”', 'why' => 'Its description mentions “' . $w . '”, so our team looks first, usually within a day.', 'word' => $w]);
            [$w] = self::listed($pdo, 'hold', $title, $about);
            if ($w !== '') $take(['tier' => 'review', 'key' => 'hold', 'name' => '“' . $w . '”', 'why' => 'A word in it (“' . $w . '”) is one our team looks at first, usually within a day.', 'word' => $w]);
        } catch (Throwable $x) { error_log('market rules lists: ' . $x->getMessage()); }
        return $best;
    }

    /**
     * A word from the Marketplace's own lists (System Configuration: "blocked", "hold"), read the way the rules read a name
     * (Jason, 2026-11-04: "Gun Holster" isn't a gun): in the name it counts only where it's the thing itself, not a word
     * describing something else; in the description it counts anywhere. [word, 'name'|'about'], or ['', ''].
     */
    public static function listed(PDO $pdo, string $list, string $title, string $about = ''): array
    {
        foreach (['name' => mb_strtolower($title), 'about' => mb_strtolower($about)] as $where => $text) {
            if ($text === '') continue;
            foreach (preg_split('/\R/', (string) Market::setting($pdo, $list)) ?: [] as $w) {
                $w = trim(mb_strtolower($w));
                if ($w === '' || !preg_match_all('/(?<![\p{L}\p{N}])' . preg_quote($w, '/') . '(?:s|es)?(?![\p{L}\p{N}])/iu', $text, $ms, PREG_OFFSET_CAPTURE)) continue;
                foreach ($ms[0] as [$word, $at]) if ($where === 'about' || self::isThing($text, (int) $at, strlen($word), 'listed')) return [$w, $where];
            }
        }
        return ['', ''];
    }

    /**
     * What a catalog item would meet on the Marketplace, said while the business is still shaping it (Jason, 2026-11-03:
     * no one should do the work and find out at Publish). [pill, sentence]. The catalog itself stays private: anything can
     * be kept there for quotes and invoices.
     */
    public static function forCatalog(string $title, string $about = '', string $kind = ''): array
    {
        $main = null; try { $main = Database::connection(); } catch (Throwable) {}   // the Marketplace's own lists are in the main database
        $r = self::check($main, $title, $about, '', $kind);
        $w = $r['word'] !== '' ? '“' . $r['word'] . '” ' : '';
        $lead = $r['word'] !== '' && mb_strtolower($r['word']) !== mb_strtolower($r['name']) ? '“' . $r['word'] . '” sounds like ' . mb_strtolower($r['name']) . '. ' : '';   // "eggs" is eggs: no need to say so
        switch ($r['tier']) {
            case 'prohibited': return ['Can\'t be published', 'Can\'t go on the Marketplace or your storefront: ' . $r['why'] . ' It can stay in your catalog for quotes and invoices.'];
            case 'restricted': return ['May need your license', $w . 'sounds like ' . mb_strtolower($r['name']) . '. If it is, publishing asks you to confirm your license: ' . $r['why'] . ' Card processors restrict it, so buyers pay you directly or ask for a quote. If it isn\'t, you\'ll say so once when you publish.'];
            case 'review': return ['Our team looks first', $r['why'] . ' It can be published; it shows once we\'ve looked.'];
            case 'confirm': return ['Confirm conditions', $lead . $r['name'] . ' can be sold here, paid by card too. When you publish it, you confirm once: ' . $r['why'] . ($r['word'] !== '' ? ' If it isn\'t ' . mb_strtolower($r['name']) . ', you\'ll say so instead.' : '')];
            case 'notice': return ['Can publish', 'Can be published. Buyers will see a notice: ' . $r['why']];
        }
        return ['Can publish', 'Can be published on the Marketplace and your storefront.'];
    }

    /**
     * A recall that matches this item's name (the CPSC's recall database, free: saferproducts.gov), or null. A strong match
     * only: two or more of the name's words, all of them in a recalled product's name, recalled in the last 10 years. A
     * match sends the item to our team for a look, never a block on its own. A slow or failed look never stops a publish.
     */
    public static function recall(string $title, ?array $answer = null): ?array
    {
        $words = array_values(array_filter(preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($title)) ?: [], fn ($w) => mb_strlen($w) >= 3 && !in_array($w, ['the', 'and', 'for', 'with', 'set', 'new', 'used', 'large', 'small', 'pack', 'size', 'inch', 'kids'], true)));
        if (count($words) < 2) return null;   // one word ("crib") matches too much to say anything
        if ($answer === null) {
            try {
                require_once __DIR__ . '/ServiceHealth.php'; if (ServiceHealth::held('https://www.saferproducts.gov/') !== null) return null;
                $ch = curl_init('https://www.saferproducts.gov/RestWebServices/Recall?' . http_build_query(['format' => 'json', 'ProductName' => implode(' ', array_slice($words, 0, 4)), 'RecallDateStart' => date('Y-m-d', strtotime('-10 years'))]));
                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 4, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
                $raw = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
                ServiceHealth::seen('https://www.saferproducts.gov/RestWebServices/Recall', $code, $raw, '', 'CPSC recalls');
                if ($raw === false || $code >= 400) return null;
                $answer = json_decode((string) $raw, true);
            } catch (Throwable $x) { error_log('recall check: ' . $x->getMessage()); return null; }
        }
        foreach ((array) $answer as $rc) {
            $names = array_merge([(string) ($rc['Title'] ?? '')], array_map(fn ($p) => (string) ($p['Name'] ?? ''), (array) ($rc['Products'] ?? [])));
            foreach ($names as $n) {
                $n = mb_strtolower($n);
                if ($n === '') continue;
                $all = true; foreach ($words as $w) if (!preg_match('/(?<![\p{L}\p{N}])' . preg_quote($w, '/') . '(?:s|es)?(?![\p{L}\p{N}])/u', $n)) { $all = false; break; }
                if ($all) return ['title' => (string) ($rc['Title'] ?? $n), 'url' => (string) ($rc['URL'] ?? ''), 'date' => substr((string) ($rc['RecallDate'] ?? ''), 0, 10), 'number' => (string) ($rc['RecallNumber'] ?? '')];
            }
        }
        return null;
    }

    /** An item's stored flag ('restricted:alcohol', 'notice:used', 'review:hold') as [tier, key]. */
    public static function flag(array $it): array
    {
        $f = (string) ($it['rule_flag'] ?? '');
        return $f === '' ? ['ok', ''] : array_pad(explode(':', $f, 2), 2, '');
    }

    /** The notice buyers see on an item, or ''. */
    public static function notice(array $it): string
    {
        [$tier, $k] = self::flag($it);
        if ($tier === 'notice') return (string) (self::RULES[$k][3] ?? '');
        if ($tier === 'restricted' && isset(self::RULES[$k])) return self::RULES[$k][1] . ': sold under the conditions its seller confirmed. ' . self::RULES[$k][3];
        if ($tier === 'confirm' && isset(self::RULES[$k])) return self::RULES[$k][1] . ': its seller confirmed it\'s sold under these conditions. ' . self::RULES[$k][3];
        return '';
    }

    /** May this item be paid by card? Restricted items: no (a direct way or a quote). */
    public static function cardOk(array $it): bool { return self::flag($it)[0] !== 'restricted'; }

    /** Can items carry a flag yet (the database update)? */
    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT rule_flag FROM market_items LIMIT 0'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }
}

/** Publishing a restricted item needs the business's answer first: is it what the rule matched, and if so its license. */
final class MarketRuleAsk extends RuntimeException
{
    public array $rule;
    public function __construct(array $rule) { $this->rule = $rule; parent::__construct($rule['word'] !== '' ? '“' . $rule['word'] . '” sounds like ' . mb_strtolower($rule['name']) . '.' : $rule['name'] . ':'); }   // no word: its kind brought it, so it is that
}
