<?php
// app/lib/Services.php — Services & usage (decisions/0133): every paid or limited service the engine uses, its cap, use
// today and this month, the month's projection and cost (warnings at 50%, 75% and 95% are Pulse cases, from the service
// register, app/lib/Operations.php, decisions/0163 §4), a report on the 1st for the month before, and how independent we are (how much our own crawler and records
// answered, against paid lookups). Counts only, never who. Read by System Configuration → Services & usage and the
// services_tick job.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/SearchIndex.php';
require_once __DIR__ . '/AiClient.php';
require_once __DIR__ . '/Mailer.php';

final class Services
{
    /**
     * Plans we pay for each month at a flat price (Jason, 2026-11-01: Railway's Hobby plan "is active now. Need to add to
     * monthly cost management"): key => [name, plan, dollars a month, the .env key that overrides the price, what it
     * includes, the outside service (Pulse::SERVICES) where its bill is]. Added to the month's total and the report.
     */
    public const PLANS = [
        'railway' => ['Railway', 'Hobby', 5.00, 'RAILWAY_USD_MONTH', 'Runs the crawler worker. $5 a month includes $5 of usage; more is billed only if the worker uses over $5 in a month (Usage on Railway).', 'railway'],
    ];

    /** The plans with this month's price: [key => [name, plan, usd, note, service]] and their total. */
    public static function plans(): array
    {
        $out = []; $total = 0.0;
        foreach (self::PLANS as $k => [$name, $plan, $usd, $env, $note, $svc]) {
            $v = getenv($env); $usd = $v !== false && $v !== '' && is_numeric($v) ? (float) $v : $usd;
            $out[$k] = ['name' => $name, 'plan' => $plan, 'usd' => $usd, 'note' => $note, 'service' => $svc, 'env' => $env];
            $total += $usd;
        }
        return [$out, $total];
    }

    /** The warning levels, in percent of the cap (Jason, 2026-11-14, decisions/0163 §4): one Pulse case per service, raised
     *  by Operations::warnings (they replaced the emails at 80% and 100%, Release A). */
    public const LEVELS = [50, 75, 95];

    /** Each service: [key, name, unit, used this month, used today, cap, where it stops, cost this month, projected cost, note]. */
    public static function all(PDO $pdo): array
    {
        $days = (int) date('t'); $today = max(1, (int) date('j'));
        $proj = fn (float $n) => $n / $today * $days;   // at this month's pace
        $out = [];
        foreach (['websearch' => ['Web search (Tavily)', 'searches', 'tavily', 0.0, 'The plan\'s allowance (SEARCH_MONTHLY on the worker). The site stops it at its stop line and paces it over the month.'],
                  'places' => ['Google Places check', 'checks', 'google_places', 0.032, 'GOOGLE_PLACES_MONTHLY on the worker; stops at its stop line. The cost is an estimate at the rate shown: check it against Google\'s bill.']] as $k => [$name, $unit, $env, $rate, $note]) {
            $month = self::state($pdo, $k . '_month') === date('Y-m');
            $used = $month ? (int) self::state($pdo, $k . '_used') : 0;
            $day = self::state($pdo, $k . '_day') === date('Y-m-d') ? (int) self::state($pdo, $k . '_day_used') : 0;
            $cap = (int) self::state($pdo, $k . '_monthly');
            $stop = (int) self::state($pdo, $k . '_stop');
            require_once __DIR__ . '/crawler/CrawlService.php';
            $usd = CrawlService::price($env); $env = CrawlService::priceEnv($env);   // one price per service: the ledger's
            $seen = (int) self::state($pdo, $k . '_seen');
            $out[$k] = ['key' => $k, 'name' => $name, 'unit' => $unit, 'used' => $used, 'today' => $day, 'cap' => $cap, 'stop' => $stop ?: null,
                        'cost' => $used * $usd, 'projected' => $proj($used) * $usd, 'projected_units' => (int) round($proj($used)), 'rate' => $usd, 'rate_env' => $env,
                        'note' => $note . ($seen ? '' : ' The worker hasn\'t reported yet.'), 'money' => false];
        }
        $usd = AiClient::monthUsd($pdo); $cap = AiClient::capUsd();
        $out['claude'] = ['key' => 'claude', 'name' => 'Claude (AI)', 'unit' => 'dollars', 'used' => $usd, 'today' => self::claudeToday($pdo), 'cap' => $cap, 'stop' => $cap,
                          'cost' => $usd, 'projected' => $proj($usd), 'projected_units' => $proj($usd), 'rate' => 1.0, 'rate_env' => '',
                          'note' => 'The cap is in the service register (System Configuration → Service register; it was AI_MONTHLY_CAP_USD in .env); each feature also has its own runs a day and budget (AI use). Everything stops for the month at the cap.', 'money' => true];
        if (is_file(__DIR__ . '/SesMail.php')) {   // email through Amazon SES (decisions/0137 §8): tracked like Claude, no cost without a cap
            require_once __DIR__ . '/SesMail.php';
            try {
                [$n, $usd] = SesMail::month($pdo); require_once __DIR__ . '/Thresholds.php'; $cap = (float) Thresholds::get($pdo, 'ses_month_usd');
                $out['ses'] = ['key' => 'ses', 'name' => 'Amazon SES (email)', 'unit' => 'dollars', 'used' => $usd, 'today' => 0.0, 'cap' => $cap, 'stop' => $cap,
                               'cost' => $usd, 'projected' => $proj($usd), 'projected_units' => $proj($usd), 'rate' => 1.0, 'rate_env' => 'SES_USD_PER_1000',
                               'note' => number_format($n) . ' emails this month, at about $0.10 per 1,000 (SES_USD_PER_1000). The cap is in the service register (it was SES_MONTHLY_CAP_USD in .env): bulk mail stops at the cap; notices and receipts keep going, with the alerts.', 'money' => true];
            } catch (Throwable) {}
        }
        foreach ($out as &$s) {
            $s['pct'] = $s['cap'] > 0 ? (int) floor($s['used'] / $s['cap'] * 100) : 0;
            $s['tone'] = $s['pct'] >= 95 ? 'bad' : ($s['pct'] >= 50 ? 'info' : 'ok');
        }
        return $out;
    }

    /**
     * Independence (decisions/0133, the principle): this month, how much our own crawler and records answered.
     * find_free/find_paid: Find it answered by our crawler / by Claude's web search; listings: crawler listings published
     * this month; paid: paid lookups (web searches + Places checks); per_listing: paid lookups per new listing (lower is
     * more independent); share: the Find it share our crawler answered, in percent (null before any).
     */
    public static function independence(PDO $pdo, ?string $month = null): array
    {
        $month = $month ?? date('Y-m'); $from = $month . '-01'; $to = date('Y-m-01', strtotime($from . ' +1 month'));
        $free = 0; $paidFind = 0; $listings = 0;
        try {
            $st = $pdo->prepare("SELECT result FROM guide_finds WHERE status = 'found' AND done_at >= ? AND done_at < ?"); $st->execute([$from, $to]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $r) { $by = (string) ((json_decode((string) $r, true) ?: [])['by'] ?? ''); if ($by === 'our crawler') $free++; elseif ($by !== '') $paidFind++; }
        } catch (Throwable $e) {}
        try {
            $st = $pdo->prepare("SELECT COUNT(*) FROM entities WHERE created_by_type = 'ai_crawler' AND created_at >= ? AND created_at < ?"); $st->execute([$from, $to]);
            $listings = (int) $st->fetchColumn();
        } catch (Throwable $e) {}
        $paid = 0;
        if ($month === date('Y-m')) foreach (['websearch', 'places'] as $k) $paid += self::state($pdo, $k . '_month') === $month ? (int) self::state($pdo, $k . '_used') : 0;
        else $paid = (int) self::state($pdo, 'svc_paid_' . $month);   // kept by the report when the month closed
        return ['find_free' => $free, 'find_paid' => $paidFind, 'share' => ($free + $paidFind) ? (int) round($free / ($free + $paidFind) * 100) : null,
                'listings' => $listings, 'paid' => $paid, 'per_listing' => $listings ? round($paid / $listings, 2) : null];
    }

    /**
     * The job (hourly): the service register's upkeep (Operations::tick: today's caps recorded once, the watch when it's
     * on), and the report on the first run of a new month. The warnings at 50/75/95% are Pulse cases now (Operations::
     * warnings), so the level emails no longer go (decisions/0163 §6: replace, never add beside). Returns what it did.
     */
    public static function tick(PDO $pdo): array
    {
        $sent = [];
        $month = date('Y-m');
        if (is_file(__DIR__ . '/Operations.php')) { try { require_once __DIR__ . '/Operations.php'; $sent = array_merge($sent, Operations::tick($pdo)); } catch (Throwable $x) { error_log('ops tick: ' . $x->getMessage()); } }
        $last = date('Y-m', strtotime('first day of last month'));
        if (self::state($pdo, 'svc_report') !== $last && (int) date('j') <= 3) {   // the month before, once, in the first days of the new one
            if (self::tellAdmins($pdo, 'Services & usage for ' . date('F Y', strtotime($last . '-01')), self::report($pdo, $last))) {
                SearchIndex::setState($pdo, 'svc_report', $last);
                $sent[] = 'report for ' . $last;
            }
        }
        // what was paid for, kept as the month goes, for that month's report and independence later
        $paid = 0; foreach (['websearch', 'places'] as $k) $paid += self::state($pdo, $k . '_month') === $month ? (int) self::state($pdo, $k . '_used') : 0;
        SearchIndex::setState($pdo, 'svc_paid_' . $month, (string) $paid);
        foreach (['websearch', 'places'] as $k) if (self::state($pdo, $k . '_month') === $month) SearchIndex::setState($pdo, 'svc_used_' . $k . '_' . $month, self::state($pdo, $k . '_used'));
        return $sent;
    }

    /** The month's report, in words (by email on the 1st; also on the page). */
    public static function report(PDO $pdo, string $month): string
    {
        $from = $month . '-01';
        $lines = ['Services & usage, ' . date('F Y', strtotime($from)) . '.', ''];
        foreach (['websearch' => ['Web search (Tavily)', 'searches'], 'places' => ['Google Places check', 'checks']] as $k => [$name, $unit]) {
            $n = (int) self::state($pdo, 'svc_used_' . $k . '_' . $month);
            $cap = (int) self::state($pdo, $k . '_monthly');
            $lines[] = '- ' . $name . ': ' . number_format($n) . ' ' . $unit . ($cap ? ' of ' . number_format($cap) . ' (' . (int) floor($n / $cap * 100) . '%)' : '');
        }
        try {
            $usd = (int) $pdo->query("SELECT COALESCE(SUM(cost_micros), 0) FROM " . Database::t('ai_jobs') . " WHERE created_at >= '" . $from . "' AND created_at < '" . date('Y-m-01', strtotime($from . ' +1 month')) . "'")->fetchColumn() / 1e6;
            $lines[] = '- Claude: $' . number_format($usd, 2) . ' of the $' . number_format(AiClient::capUsd(), 2) . ' cap';
        } catch (Throwable $e) {}
        [$plans, $fixed] = self::plans();
        foreach ($plans as $pl) $lines[] = '- ' . $pl['name'] . ' (' . $pl['plan'] . ' plan): $' . number_format($pl['usd'], 2) . ' a month';
        if ($plans) $lines[] = '- Monthly plans in all: $' . number_format($fixed, 2);
        $i = self::independence($pdo, $month);
        $lines[] = '';
        $lines[] = 'Independence: ' . ($i['share'] !== null ? 'our own crawler answered ' . $i['share'] . '% of Find it (' . $i['find_free'] . ' of ' . ($i['find_free'] + $i['find_paid']) . ')' : 'no Find it answers yet')
                 . '; ' . $i['listings'] . ' listings published from the crawler, ' . ($i['per_listing'] !== null ? $i['per_listing'] . ' paid lookups each.' : 'with ' . $i['paid'] . ' paid lookups.');
        return implode("\n", $lines) . "\n\n" . rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/admin/config/services';
    }

    public static function fmt(array $s, $n): string
    {
        return $s['money'] ? '$' . number_format((float) $n, 2) : number_format((int) $n) . ' ' . $s['unit'];
    }

    private static function claudeToday(PDO $pdo): float
    {
        try { return (int) $pdo->query("SELECT COALESCE(SUM(cost_micros), 0) FROM " . Database::t('ai_jobs') . " WHERE created_at >= '" . date('Y-m-d') . "'")->fetchColumn() / 1e6; } catch (Throwable $e) { return 0.0; }
    }

    private static function state(PDO $pdo, string $k): string
    {
        try { return SearchIndex::state($pdo, $k); } catch (Throwable $e) { return ''; }
    }

    /** Emails the admins; true when at least one went. */
    private static function tellAdmins(PDO $pdo, string $subject, string $body): bool
    {
        try {
            $to = $pdo->query("SELECT u.email FROM users u WHERE u.is_admin = 1 AND u.is_suspended = 0
                                UNION SELECT u.email FROM " . Database::t('admin_access') . " a JOIN users u ON u.id = a.user_id WHERE a.tier = 'super_admin'")->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable $e) { $to = []; }
        $ok = false;
        foreach (array_unique($to) as $email) {
            try { Mailer::send((string) $email, '[Traversence] ' . $subject, $body); $ok = true; } catch (Throwable $t) { error_log('services mail: ' . $t->getMessage()); }
        }
        return $ok;
    }
}
