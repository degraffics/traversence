<?php
// api/crawl/sources.php — the worker reads our "Read regularly" sources (decisions/0045).
//   GET  -> {source: {host, home_url, kind, pages: {url: {etag, modified, links}}} | null, describe: [{host, home_url}]}
//        (pages: what the page log knows; describe: sites waiting for a call whose home page to read, decisions/0157 §7)
//   GET also: extract (pages Tavily may read this run), scans [{host, url, text}] (Textract's text for the worker to read)
//   POST {scan_page, host, facts}  -> {kept}   a scan's places, for that page alone
//   POST {about: [{host, title, site_name, description, types, terms, terms_url}]}  -> {judged}   what those sites say they
//        are, and their terms page's text when they have one (read by Claude when the source_terms feature is on)
//   POST {host, pages, facts: [{url, name, address, phone, zip, town, state, website, hours, lat, lng, schema_type, kinds,
//         words, section, page_kind, how}], log: [{url, status, type, bytes, etag, modified, fingerprint, page_kind, named,
//         links, title}], unchanged: [url]}  -> {kept}        (decisions/0157 §1-§2; an older worker sends only facts)
//        Each page read replaces its own places; a read that reached nothing answers {handed_back: true} and changes nothing.

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/crawler/SourceIndex.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // the register decides what it can first (decisions/0157 §7), so a public body is read from its first visit
    try { Sources::sweep($pdo); } catch (Throwable $e) { error_log('sources sweep: ' . $e->getMessage()); }
    require_once __DIR__ . '/../../../app/lib/crawler/SecondTier.php';
    $paused = CrawlQueue::paused();
    Response::json(['ok' => true, 'source' => $paused ? null : SourceIndex::next($pdo),
                    'describe' => $paused ? [] : array_map(fn ($r) => ['host' => $r[0], 'home_url' => $r[1]], Sources::toDescribe($pdo, 3)),
                    // the second tier (decisions/0157): pages Tavily may read this run, and scans Textract read for the worker to read
                    'extract' => $paused ? 0 : SecondTier::extractAllowance($pdo), 'scans' => $paused ? [] : SecondTier::scansToRead($pdo, 3)]);
}
Response::requireMethod('POST');
$b = Response::jsonBody();
// a scan's places, read by the worker from Textract's text: that page's alone (decisions/0157 §7.2)
if (!empty($b['scan_page'])) {
    Response::json(['ok' => true, 'kept' => SourceIndex::storePage($pdo, (string) ($b['host'] ?? ''), (string) $b['scan_page'], (array) ($b['facts'] ?? []))]);
}
// what sites waiting for a call say they are (their home page): kept, then judged (decisions/0157 §7)
if (isset($b['about']) && is_array($b['about'])) {
    foreach (array_slice($b['about'], 0, 10) as $d) if (is_array($d) && !empty($d['host'])) Sources::describe($pdo, (string) $d['host'], $d);
    $judged = Sources::sweep($pdo);
    // what address and description couldn't decide, its terms can (the second tier: Claude, while its feature is on)
    require_once __DIR__ . '/../../../app/lib/crawler/SecondTier.php';
    foreach (array_slice($b['about'], 0, 3) as $d) {
        if (!is_array($d) || empty($d['host']) || empty($d['terms'])) continue;
        $about = trim(implode(' · ', array_filter([(string) ($d['site_name'] ?? ''), (string) ($d['title'] ?? ''), (string) ($d['description'] ?? '')])));
        $t = SecondTier::judgeTerms($pdo, (string) $d['host'], $about, (string) $d['terms'], (string) ($d['terms_url'] ?? ''));
        if (!empty($t['decided'])) $judged++;
    }
    Response::json(['ok' => true, 'judged' => $judged]);
}
$kept = SourceIndex::store($pdo, (string) ($b['host'] ?? ''), (array) ($b['facts'] ?? []), (array) ($b['log'] ?? []), (array) ($b['unchanged'] ?? []));
if ($kept < 0) Response::json(['ok' => true, 'kept' => 0, 'handed_back' => true, 'new_sites' => 0]);   // nothing read: nothing changed (review B6)
if (!empty($b['extracted'])) { require_once __DIR__ . '/../../../app/lib/crawler/SecondTier.php'; SecondTier::recordExtracts($pdo, (int) $b['extracted']); }   // their cost, against the budget
// the words used here, built again once a day off the visitor's path (decisions/0157 §4)
try { require_once __DIR__ . '/../../../app/lib/LocalWords.php'; LocalWords::refresh($pdo); } catch (Throwable $e) { error_log('local words: ' . $e->getMessage()); }
// the sites its pages link to: onto the register (decisions/0157 §8)
$newSites = 0;
if (!empty($b['outlinks']) && is_array($b['outlinks'])) { try { $newSites = Sources::addLinked($pdo, $b['outlinks'], (string) ($b['host'] ?? '')); } catch (Throwable $e) { error_log('sources outlinks: ' . $e->getMessage()); } }
Response::json(['ok' => true, 'kept' => $kept, 'new_sites' => $newSites]);
