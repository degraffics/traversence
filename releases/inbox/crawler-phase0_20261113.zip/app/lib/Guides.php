<?php
// app/lib/Guides.php — a guide for every place on the six-tier funnel (decisions/0131). A place is a key:
//   hub:ID (a Regional guide) · geo_hub:ID (Area) · cluster:ID (Community) · town:ID (City, the anchors table) ·
//   sub:ID (Neighborhood, an accepted local name in cluster_subgroups)
// Each place has its guide from the start: the page is built from our data (next stops, picks, outdoors, the profile,
// who to call, weather); what our team writes (place_guides.sections) fills in the words. The Chameleon Filter picks
// the listings each section shows (picks()): relevance, proximity, kind of experience and the season; pins first, never
// paid placement (decisions/0007). Names a guide mentions are linked by GuideLinks.
declare(strict_types=1);

require_once __DIR__ . '/PlaceScope.php';

final class Guides
{
    /** level => [tier, kind of guide, the word for its places one step down] */
    public const TIERS = [
        'hub' => [2, 'Regional guide', 'Areas'],
        'geo_hub' => [3, 'Area guide', 'Communities'],
        'cluster' => [4, 'Community guide', 'Towns'],
        'town' => [5, 'City guide', 'Nearby communities'],
        'sub' => [6, 'Neighborhood guide', ''],
    ];

    /**
     * The sections, in the Visiting order: key => [title, written by our team?, what it is for (the editor's hint)].
     * 'live' is the Live here order (the Chameleon dial, decisions/0131 §3).
     */
    public const SECTIONS = [   // [heading, written by our team or Claude, what the section is for]: the brief Claude writes each from (Jason, 2026-10-30: rich with history and culture, and the experience of being there)
        'essentials' => ['Essentials', true, 'What a visitor needs to enjoy it well, said warmly as a local would: cell coverage, fuel, the nearest hospital, closures by season, local customs and courtesies. Who to call, weather and roads are added for you.'],
        'do' => ['Things to do', true, 'The experiences, and what each is like: on the water at dawn, a Friday-night game, a walk through the old town, the trails and the sky. By season, for families and the curious, with the story behind them.'],
        'journeys' => ['Suggested journeys', false, ''],   // built by rules from the guide's own places (decisions/0146, JourneyPlan)
        'glance' => ['At a glance', true, 'The opening: the place\'s character, setting and story in brief, and why someone should come. Three to five rich paragraphs that make a reader want to go.'],
        'getting' => ['Getting there & around', true, 'The main roads and the older routes they follow, drive times, winter driving, parking. Roads you name (SR 260) get their 511 conditions.'],
        'next' => ['Next stops', false, ''],
        'landmarks' => ['Landmarks & heritage', true, 'The place\'s story told through the places that hold it, from its first peoples to today: each landmark, church, museum and historic site with who, when and why it matters. Each name links to the place.'],
        'footsteps' => ['Walking in the footsteps', true, 'The place\'s story, told where a visitor can stand today (decisions/0133): from its first peoples to now, each turning point, family, trade, building material, water and hardship anchored to a building, a street, a crossing or a view they can visit, with people and land told together. Write it from the HERITAGE CATALOG first. A place marked story only is told, never located or given directions to, and carries the courtesy line: look, don\'t touch, and follow the rules of the nation or the land\'s managers.'],
        'eat' => ['Eat & drink', true, 'Local favorites and what the place is known for (a dish, a tradition, a gathering place): what to order, when to go, who you\'ll meet. Each business you name is pinned here.'],
        'stay' => ['Places to stay', true, 'Lodges, cabins, campgrounds and inns, what each is like and who it suits.'],
        'events' => ['Events & seasons', true, 'The year here, month by month: festivals, rodeos, fairs, feast days and seasons, what each celebrates or remembers, and what it\'s like to be there.'],
        'itineraries' => ['Itineraries & insider tips', true, 'Start each itinerary with a line "## Its title" (a weekend, a family day): a real day, where to start, eat and go, in order, and why. Tips: the quieter times, local know-how.'],
        'living' => ['Living here', false, ''],
        'local' => ['Local', false, ''],
    ];
    public const LIVE_ORDER = ['essentials', 'local', 'next', 'getting', 'eat', 'do', 'journeys', 'events', 'glance', 'landmarks', 'footsteps', 'stay', 'itineraries', 'living'];

    /** Which listings a section draws from: top category, and the category names that belong (and those that don't). */
    private const PICKS = [
        'eat' => [7, '', 'Mfrs|Suppl|Equip|Wholesale|Distribut|Making'],
        'stay' => [11, '', 'Suppl|Equip|Consult|Manage'],
        'do' => [5, 'Museum|Park|Golf Courses|Outfitter|Guide Serv|Tours|Rodeo|Theat|Family Entertain|Skiing|Fishing Lakes|Monument|Landmark|Arts & Culture|Art Galler|Craft Galler|Music|Performing|Recreation Areas|Casino|Camps|Rental|Hatcher|Stadium', 'Vehicle|Trailer|Party'],
        'shop' => [19, 'Antique|Gift|Art|Craft|Book|Farm|Market|Western|Jewel|Boutique|Souvenir|Sporting|Trading|Indian|Pottery|Rug|Clothing', ''],
        'care' => [9, 'Hospital|Urgent|Emergenc|Clinic|Medical Center|Medical Clinic|Health Care', 'Eqpt|Supl|Whls|Equip|Supply|Billing'],
    ];
    /**
     * Essentials by who needs them (Jason, 2026-10-30): everyone, visitors (the Visiting dial) or residents (Live here).
     * key => [label, who: all|v|l, category name pattern, not pattern (category and name), reach in miles (0: the
     * place's own reach), and optionally a pattern that leads (the town hall before a county yard)]. Nearest first, three each; a listing that keeps its address private (a shelter) is never one of them.
     */
    public const ESSENTIALS = [
        'care' => ['Emergency & urgent care', 'all', 'Hospital|Urgent|Emergenc|Medical Center|^Clinics', 'Eqpt|Supl|Whls|Equip|Supply|Billing|Therap|Chiro|Dent|Eye|Vision|Optom|Massage|Spa\\b|Wellness|Counsel|Veterin|Beauty|Cosmetic|Hearing|Podiatr|Pain|Weight|Sleep|Fertil|Dialys|Oncol|Cancer|Imaging|Laborator', 45],
        'pharmacy' => ['Pharmacies', 'all', '^Pharmacies|Drug ?Stores', '', 30],
        'safety' => ['Police, fire & ambulance', 'all', 'Police|Sheriff|Fire Departments|Fire Protection|Ambulance', '', 20],
        'fuel' => ['Fuel & charging', 'all', 'Service Stations|Gasoline|Electric Charging|Truck Stops|Travel Plazas', 'Equip|Supl', 20],
        'grocery' => ['Groceries & everyday needs', 'all', 'Grocers|Supermarket|Convenience Stores|Variety Stores|General Merchandise|Department Stores', 'Whls|Wholesale', 20],
        'money' => ['Banks & ATMs', 'all', '^Banks|^Atm|Credit Unions', 'Virtual Currency|Equip', 20],
        'info' => ['Visitor info, libraries & Wi-Fi', 'all', 'Libraries|Chambers Of Commerce|Visitor|Tourist Information', '', 25],
        'car' => ['Car trouble', 'v', 'Towing|Wrecker|Road Service|Automobile Repairing|Tire-Dealers|Tire.*Repair|Glass-Auto|Automobile Glass', '', 25],
        'around' => ['Getting around', 'v', 'Airports|Taxi|Shuttle|Automobile Renting|Car Rental|Bus Lines|Transportation Services', 'Aircraft|Equip', 45],
        'vet' => ['Pet emergencies', 'v', 'Veterinarians|Animal Hospital|Pet Boarding|Kennels', 'Supl|Equip', 30],
        'laundry' => ['Laundry, mail & shipping', 'v', 'Laundr|Mailing & Shipping Services|Post Offices', 'Equip|Supl', 20],
        'civic' => ['Town hall & government', 'l', 'City Government|Government Offices-City|Government Offices-County|County Government|Courts|Motor Vehicle|Government Offices-Native American|Public Works|Post Offices', 'Fair|Racing|Rodeo|Yard|Mntnc|Maint|Shop', 25, 'City Government|Government Offices-City|Town Hall|City Hall|Motor Vehicle|Courts'],
        'utility' => ['Utilities, trash & internet', 'l', 'Electric Companies|Water & Sewage|Gas Companies|Garbage Collection|Rubbish|Recycling|Propane \\(Lp\\)|Internet Service|Telephone Companies|Cable', 'Equip|Contractor|Generating|Plant|Substation', 30],
        'school' => ['Schools & childcare', 'l', 'School Districts|^Schools|Child Care|Day Care|Preschool|Junior-Community College|Youth Organizations', 'Driving|Beauty|Cosmetology', 25],
        'doctor' => ['Doctors, dentists & counseling', 'l', '^Physicians & Surgeons$|Dentists|Optometrists|Mental Health|Counseling|Counselors|Chiropract|Physical Therapists|Pediatric', 'Equip|Supl', 30],
        'home' => ['Home repairs', 'l', 'Plumbing Contractors|Electric Contractors|Heating|Air Conditioning|Roofing|Locksmith|Pest Control|Water Well|Septic', 'Equip|Supl', 25],
        'help' => ['Community help', 'l', 'Food Bank|Food Pantr|Social Service|Welfare|Animal Shelter|Humane Soc|Senior Citizen|Community Center', '', 30],
    ];

    /** The Essentials groups for a place: [key, label, who, rows] (rows as picks(): nearest first), empty groups left out. Kept 30 minutes. */
    public static function essentials(PDO $pdo, array $p, int $n = 3): array
    {
        if ($p['level'] === 'hub' || $p['lat'] === null) return [];
        require_once __DIR__ . '/PageCache.php';
        $groups = PageCache::remember($pdo, 'guides:ess:' . $p['key'], 1800, function () use ($pdo, $p, $n) {
            require_once __DIR__ . '/ListingSafety.php';
            $far = max(array_column(self::ESSENTIALS, 4));
            $dLat = $far / 69; $dLon = $far / max(1, 69 * cos(deg2rad($p['lat'])));
            $st = $pdo->prepare("SELECT e.id, e.name, e.status, e.trust_score, e.latitude, e.longitude, e.primary_zip, e.category_id, c.name AS category FROM entities e JOIN categories c ON c.id = e.category_id
                WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ('unclaimed','claimed-unverified','pending-verification','verified') AND " . self::OPEN . "
                  AND e.latitude BETWEEN ? AND ? AND e.longitude BETWEEN ? AND ? AND c.name REGEXP ? LIMIT 4000");
            $st->execute([$p['lat'] - $dLat, $p['lat'] + $dLat, $p['lon'] - $dLon, $p['lon'] + $dLon, implode('|', array_column(self::ESSENTIALS, 2))]);
            // a listing named for this town comes first, one named for another town last ("Mc Nary Town Sheriff" filed at a St. Johns address)
            $sq = fn (string $x) => (string) preg_replace(['/\bst\.?\s/', '/[^a-z]/'], ['saint ', ''], strtolower($x . ' '));
            $own = [$sq(preg_replace('/^(The\s+)?(Greater\s+)?|\s+(Area|District|Corridor)$/i', '', (string) $p['name']))];   // the place, and a community's own towns
            if ($p['level'] === 'cluster' || $p['level'] === 'sub') foreach (self::townsOf($pdo, (int) ($p['level'] === 'cluster' ? $p['id'] : $p['cluster'])) as $t) $own[] = $sq((string) $t['name']);
            $own = array_values(array_filter(array_unique($own), fn ($t) => strlen($t) >= 4));
            $towns = self::ready($pdo) ? array_values(array_filter(array_map($sq, $pdo->query('SELECT DISTINCT name FROM anchors')->fetchAll(PDO::FETCH_COLUMN)), fn ($t) => strlen($t) >= 4 && !in_array($t, $own, true))) : [];
            $by = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                if (ListingSafety::isConfidential((int) $r['category_id'], (string) $r['name'])) continue;
                $r['miles'] = self::miles((float) $p['lat'], (float) $p['lon'], (float) $r['latitude'], (float) $r['longitude']);
                $nm = $sq((string) $r['name']);
                $r['named'] = array_filter($own, fn ($t) => str_contains($nm, $t)) ? 0 : (array_filter($towns, fn ($t) => str_contains($nm, $t)) ? 2 : 1);
                if (preg_match('/\b(City|Town) Hall\b/i', (string) $r['name']) && $r['miles'] <= 25) { $by['civic'][] = $r; continue; }   // a town hall is one, whatever it's filed under
                foreach (self::ESSENTIALS as $k => [, , $re, $not, $reach]) {   // (a group's lead pattern, if any, is ESSENTIALS[$k][5])
                    if (!preg_match('/' . $re . '/i', (string) $r['category']) || ($not !== '' && preg_match('/' . $not . '/i', (string) $r['category'] . ' ' . $r['name']))) continue;
                    if ($r['miles'] <= ($reach ?: (self::REACH[$p['level']] ?? 25))) $by[$k][] = $r;
                    break;   // a listing sits in its first group only
                }
            }
            $out = [];
            foreach (self::ESSENTIALS as $k => [$label, $who]) {
                $rows = $by[$k] ?? [];
                $lead = self::ESSENTIALS[$k][5] ?? '';
                $band = fn ($r) => $r['miles'] < 3 ? 0 : (int) round($r['miles'] / 5) + 1;   // close enough to count as the same distance: then the town's own name leads
                usort($rows, fn ($a, $b) => [$lead !== '' && !preg_match('/' . $lead . '/i', $a['category'] . ' ' . $a['name']), $band($a), $a['named'], $a['miles']] <=> [$lead !== '' && !preg_match('/' . $lead . '/i', $b['category'] . ' ' . $b['name']), $band($b), $b['named'], $b['miles']]);
                $seen = []; $keep = [];
                $one = function (array $r) use (&$seen, &$keep): void { $nk = (string) preg_replace('/[^a-z0-9]+/', '', strtolower((string) $r['name'])); if (!isset($seen[$nk])) { $seen[$nk] = 1; $keep[] = $r; } };
                if ($k === 'care') {   // the two nearest emergency rooms or hospitals and the nearest walk-in clinic, nearest first
                    $er = fn ($r) => (bool) preg_match('/Hospital|Urgent|Emergenc|Medical Center/i', $r['category'] . ' ' . $r['name']);
                    foreach (array_filter($rows, $er) as $r) if (count($keep) < $n - 1) $one($r);
                    foreach ($rows as $r) if (count($keep) < $n && !$er($r) && $r['miles'] <= 15 && preg_match('/Clinic|Health Cent|Medical|Walk.?In/i', (string) $r['name'])) { $one($r); break; }   // a clinic close by, by name (not a doctor's office filed as one)
                    foreach (array_filter($rows, $er) as $r) if (count($keep) < $n) $one($r);
                    usort($keep, fn ($a, $b) => $a['miles'] <=> $b['miles']);
                } else foreach ($rows as $r) { if (count($keep) >= $n) break; $one($r); }
                if (!$keep) continue;
                self::withMeta($pdo, $keep);
                $out[] = [$k, $label, $who, $keep];
            }
            return $out;
        });
        return is_array($groups) ? $groups : [];
    }

    /** Kinds of experience inside a section, for its groups: [label, category name pattern] in order; the rest are the last group. */
    public const KINDS = [
        'eat' => [['Coffee, bakeries & quick bites', 'Coffee|Bakery|Bakeries|Bagel|Donut|Doughnut|Fast Food|Pizza|Deli|Ice Cream|Yogurt|Snack|Sandwich|Food Truck|Candy|Subway|Subs\\b|Burger|Mc ?Donald|Taco|Sonic|Dairy Queen|Drive.?In'],
                  ['Drinks & nightlife', 'Bar|Cocktail|Brewer|Brew Pub|Winer|Tavern|Saloon|Night Club|Pub'],
                  ['Sit-down dining', '']],
        'do' => [['Outdoors & recreation', 'Park|Golf|Outfitter|Guide|Fishing|Skiing|Recreation|Camps|Rental|Hatcher|Rodeo|Stadium'],
                 ['Culture & entertainment', '']],
    ];
    /** What leads in the weather (Weather::conditions): indoor places when it keeps people in, outdoor ones on a fair day. */
    public const WEATHER_LEAD = ['indoor' => 'Museum|Theat|Galler|Casino|Bowling|Librar|Arts|Cinema|Movie|Aquarium|Spa\\b|Escape|Arcade|Skating|Gymnas|Health Club|Historic|Craft|Antique|Book|Gift|Trading',
                                 'outdoor' => 'Park|Lake|Trail|Golf|Outfitter|Guide Serv|Fishing|Camp|Recreation|Rodeo|Stadium|Hatcher|Boat|Tours|Monument'];
    /** The season's leaders in Things to do: month ranges and what leads then. */
    private const SEASON = ['winter' => 'Ski|Snow|Sled', 'summer' => 'Fishing|Lake|Water|Golf|Boat|Rodeo|Camp|Park'];

    /** How far a section's picks reach, by tier (miles from the guide's anchor; 0 = the place's own listings only). */
    private const REACH = ['geo_hub' => 0, 'cluster' => 25, 'town' => 10, 'sub' => 6];
    /** Care is the nearest, however far (a mountain town's hospital is the next town's). */
    private const CARE_REACH = 45;

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT 1 FROM place_guides LIMIT 0'); $pdo->query('SELECT zips FROM anchors LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    /** A local name as people write it: no stray marks ("?Windsor", zero-width spaces). */
    public static function clean(string $s): string { return trim((string) preg_replace('/[\p{Cf}\p{Co}?]+/u', '', $s)); }

    public static function slug(string $s): string { return trim((string) preg_replace('/[^a-z0-9]+/', '-', strtolower(str_replace(['St. ', 'Saint '], ['st-', 'st-'], $s))), '-'); }

    // ---- the places ---------------------------------------------------------------------------------------------------

    /**
     * Towns (tier 5) from each cluster's ZIP areas: one per town name in the cluster, its ZIPs, state and middle point.
     * New towns are added, names kept; a town no longer in any cluster stays (a guide may have words for it).
     * At most once an hour unless $force.
     */
    public static function syncTowns(PDO $pdo, bool $force = false): int
    {
        if (!self::ready($pdo)) return 0;
        require_once __DIR__ . '/PageCache.php';
        if (!$force) return (int) PageCache::remember($pdo, 'guides:towns-synced', 3600, fn () => self::syncTowns($pdo, true));
        $have = [];
        foreach ($pdo->query('SELECT id, cluster_id, slug, name FROM anchors')->fetchAll(PDO::FETCH_ASSOC) as $a) $have[(int) $a['cluster_id'] . '|' . strtolower($a['name'])] = $a;
        $slugs = array_flip(array_column($have, 'slug'));
        $n = 0;
        foreach ($pdo->query('SELECT id, primary_zip, associated_zips FROM micro_clusters')->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $zips = array_values(array_unique(array_filter(array_merge([trim((string) $c['primary_zip'])], (array) (json_decode((string) ($c['associated_zips'] ?? ''), true) ?: [])))));
            if (!$zips) continue;
            $st = $pdo->prepare('SELECT zip, city, state, latitude, longitude FROM zip_coordinates WHERE zip IN (' . implode(',', array_fill(0, count($zips), '?')) . ') ORDER BY id');
            $st->execute($zips);
            $towns = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $z) {
                $name = self::townName((string) $z['city']); if ($name === '') continue;
                $k = strtolower($name);
                $towns[$k]['name'] = $name; $towns[$k]['state'] = (string) $z['state'];
                $towns[$k]['zips'][$z['zip']] = true;
                if ($z['latitude'] !== null) { $towns[$k]['pts'][] = [(float) $z['latitude'], (float) $z['longitude']]; }
            }
            foreach ($towns as $k => $t) {
                $zipList = implode(',', array_keys($t['zips']));
                $lat = !empty($t['pts']) ? array_sum(array_column($t['pts'], 0)) / count($t['pts']) : null;
                $lon = !empty($t['pts']) ? array_sum(array_column($t['pts'], 1)) / count($t['pts']) : null;
                $cur = $have[(int) $c['id'] . '|' . $k] ?? null;
                if ($cur) { $pdo->prepare('UPDATE anchors SET zips = ?, state = ?, lat = ?, lon = ? WHERE id = ?')->execute([$zipList, $t['state'], $lat, $lon, (int) $cur['id']]); continue; }
                $base = self::slug($t['name'] . '-' . $t['state']); $slug = $base; $i = 2;
                while (isset($slugs[$slug])) $slug = $base . '-' . $i++;
                $slugs[$slug] = 1;
                $pdo->prepare('INSERT INTO anchors (cluster_id, slug, name, zips, state, lat, lon) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([(int) $c['id'], $slug, $t['name'], $zipList, $t['state'], $lat, $lon]);
                $n++;
            }
        }
        return $n;
    }

    /** "SAINT JOHNS" / "Saint Johns" → "St. Johns"; the post office's spelling otherwise, in title case. */
    public static function townName(string $city): string
    {
        $c = trim($city); if ($c === '') return '';
        if ($c === strtoupper($c)) $c = ucwords(strtolower($c));
        return (string) preg_replace('/^Saint /', 'St. ', $c);
    }

    /** A place key as one number for admin addresses (/admin/explore/place_guides/50000004 is town:4): tier × 10,000,000 + id. */
    public static function num(string $key): int
    {
        if (!preg_match('/^(hub|geo_hub|cluster|town|sub):(\d+)$/', $key, $m)) return 0;
        return self::TIERS[$m[1]][0] * 10000000 + (int) $m[2];
    }

    public static function keyOf(int $n): ?string
    {
        $tier = intdiv($n, 10000000); $id = $n % 10000000;
        foreach (self::TIERS as $level => [$t]) if ($t === $tier && $id > 0) return $level . ':' . $id;
        return null;
    }

    /** The place a page asks for (?hub= ?geo= ?cluster= ?town= ?sub=), or null. */
    public static function fromQuery(PDO $pdo, array $q): ?array
    {
        if (!empty($q['town'])) { $st = $pdo->prepare('SELECT id FROM anchors WHERE slug = ?' . (ctype_digit((string) $q['town']) ? ' OR id = ' . (int) $q['town'] : '') . ' LIMIT 1'); $st->execute([(string) $q['town']]); $id = (int) $st->fetchColumn(); return $id ? self::place($pdo, 'town:' . $id) : null; }
        if (!empty($q['sub'])) return self::place($pdo, 'sub:' . (int) $q['sub']);
        $s = PlaceScope::resolve($pdo, $q);
        return $s && $s['found'] ? self::place($pdo, $s['level'] . ':' . (int) $s['id']) : null;
    }

    /**
     * A place: key, level, id, name, tier, kind (Regional guide…), url, parent (key), lat, lon, zips, sql (which
     * listings are in it), cluster (its cluster id, from tier 4 down), slug, state. Null when it isn't there.
     */
    public static function place(PDO $pdo, string $key): ?array
    {
        static $memo = [];
        if (array_key_exists($key, $memo)) return $memo[$key];
        if (!preg_match('/^(hub|geo_hub|cluster|town|sub):(\d+)$/', $key, $m)) return null;
        [$level, $id] = [$m[1], (int) $m[2]];
        $p = null;
        $center = fn (string $where, array $a) => (function () use ($pdo, $where, $a) { $st = $pdo->prepare('SELECT AVG(COALESCE(mc.center_lat, z.latitude)) AS lat, AVG(COALESCE(mc.center_lon, z.longitude)) AS lon FROM micro_clusters mc LEFT JOIN zip_coordinates z ON z.zip = mc.primary_zip WHERE ' . $where); $st->execute($a); return $st->fetch(PDO::FETCH_ASSOC) ?: ['lat' => null, 'lon' => null]; })();
        if ($level === 'hub') {
            $st = $pdo->prepare('SELECT id, slug, name, description FROM hubs WHERE id = ?'); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if ($r) { $c = $center('mc.geo_hub_id IN (SELECT id FROM geo_hubs WHERE hub_id = ?)', [$id]); $p = ['name' => $r['name'], 'slug' => $r['slug'], 'parent' => null, 'about' => (string) $r['description'], 'lat' => $c['lat'], 'lon' => $c['lon'], 'url' => '/hub/?hub=' . rawurlencode($r['slug'])]; }
        } elseif ($level === 'geo_hub') {
            $st = $pdo->prepare('SELECT id, slug, name, description, hub_id, status FROM geo_hubs WHERE id = ?'); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if ($r) { $c = $center('mc.geo_hub_id = ?', [$id]); $p = ['name' => $r['name'], 'slug' => $r['slug'], 'parent' => 'hub:' . (int) $r['hub_id'], 'about' => (string) $r['description'], 'planned' => $r['status'] === 'planned', 'lat' => $c['lat'], 'lon' => $c['lon'], 'url' => '/hub/?geo=' . rawurlencode($r['slug'])]; }
        } elseif ($level === 'cluster') {
            $st = $pdo->prepare('SELECT mc.id, mc.slug, mc.name, mc.geo_hub_id, mc.primary_zip, mc.associated_zips, COALESCE(mc.center_lat, z.latitude) AS lat, COALESCE(mc.center_lon, z.longitude) AS lon, z.state
                                   FROM micro_clusters mc LEFT JOIN zip_coordinates z ON z.zip = mc.primary_zip WHERE mc.id = ? LIMIT 1'); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if ($r) $p = ['name' => PlaceScope::publicName((string) $r['name']), 'slug' => $r['slug'], 'parent' => 'geo_hub:' . (int) $r['geo_hub_id'], 'lat' => $r['lat'], 'lon' => $r['lon'], 'state' => (string) $r['state'], 'cluster' => $id,
                          'zips' => array_values(array_unique(array_filter(array_merge([trim((string) $r['primary_zip'])], (array) (json_decode((string) ($r['associated_zips'] ?? ''), true) ?: []))))), 'url' => '/hub/?cluster=' . $id];
        } elseif ($level === 'town') {
            $st = $pdo->prepare('SELECT * FROM anchors WHERE id = ?'); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if ($r) $p = ['name' => $r['name'], 'slug' => $r['slug'], 'parent' => 'cluster:' . (int) $r['cluster_id'], 'lat' => $r['lat'], 'lon' => $r['lon'], 'state' => (string) $r['state'], 'cluster' => (int) $r['cluster_id'],
                          'zips' => array_values(array_filter(explode(',', (string) $r['zips']))), 'url' => '/hub/?town=' . rawurlencode($r['slug'])];
        } else {
            $st = $pdo->prepare("SELECT id, cluster_id, name FROM cluster_subgroups WHERE id = ? AND status = 'accepted'"); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if ($r) { $cl = self::place($pdo, 'cluster:' . (int) $r['cluster_id']); $p = ['name' => self::clean((string) $r['name']), 'slug' => (string) $id, 'parent' => 'cluster:' . (int) $r['cluster_id'], 'lat' => $cl['lat'] ?? null, 'lon' => $cl['lon'] ?? null, 'state' => $cl['state'] ?? '', 'cluster' => (int) $r['cluster_id'], 'zips' => $cl['zips'] ?? [], 'url' => '/hub/?sub=' . $id]; }
        }
        if (!$p) return $memo[$key] = null;
        $p += ['key' => $key, 'level' => $level, 'id' => $id, 'tier' => self::TIERS[$level][0], 'kind' => self::TIERS[$level][1], 'zips' => [], 'state' => '', 'cluster' => 0, 'about' => '', 'planned' => false];
        $p['lat'] = $p['lat'] !== null ? (float) $p['lat'] : null; $p['lon'] = $p['lon'] !== null ? (float) $p['lon'] : null;
        $p['sql'] = self::scopeSql($pdo, $p);
        return $memo[$key] = $p;
    }

    /** Which listings belong to a place (e.* columns). */
    private static function scopeSql(PDO $pdo, array $p): string
    {
        if (in_array($p['level'], ['hub', 'geo_hub', 'cluster'], true)) {
            $s = PlaceScope::resolve($pdo, [['hub' => 'hub', 'geo_hub' => 'geo', 'cluster' => 'cluster'][$p['level']] => $p['level'] === 'cluster' ? (string) $p['id'] : $p['slug']]);
            if ($s && $s['found']) return $s['sql'];
        }
        if ($p['level'] === 'town' && $p['zips']) return 'e.primary_zip IN (' . implode(',', array_map(fn ($z) => $pdo->quote((string) $z), $p['zips'])) . ')';
        if ($p['level'] === 'sub') return '(' . (self::place($pdo, 'cluster:' . $p['cluster'])['sql'] ?? '0') . ')';
        return '0';
    }

    /** The place and every place above it, nearest first. */
    public static function chain(PDO $pdo, string $key): array
    {
        $out = [];
        for ($k = $key, $i = 0; $k !== null && $i < 6; $i++) { $p = self::place($pdo, $k); if (!$p) break; if (!$out || !self::sole($pdo, $p)) $out[] = $p; $k = $p['parent']; }   // a one-town community isn't a step of its own
        return $out;
    }

    /** The towns a region's or area's weather strip shows: the busiest of its communities, up to five, as places. */
    public static function stripTowns(PDO $pdo, array $p): array
    {
        if (!in_array($p['level'], ['hub', 'geo_hub'], true)) return [];
        $kids = $p['level'] === 'hub' ? array_merge([], ...array_map(fn ($g) => self::children($pdo, self::place($pdo, $g[0]) ?: $p), self::children($pdo, $p))) : self::children($pdo, $p);
        usort($kids, fn ($a, $b) => $b[4] <=> $a[4]);
        $out = [];
        foreach ($kids as $k) { if ($k[5]) continue; $c = self::place($pdo, $k[0]); if ($c && $c['lat'] !== null) $out[] = $c; if (count($out) === 5) break; }
        return $out;
    }

    /** A community of one town and no neighborhoods (Farmington): that town, whose guide stands for both. Null otherwise. */
    public static function sole(PDO $pdo, array $p): ?array
    {
        if ($p['level'] !== 'cluster') return null;
        $t = self::townsOf($pdo, (int) $p['id']);
        return count($t) === 1 && !self::subsOf($pdo, (int) $p['id']) ? self::place($pdo, 'town:' . (int) $t[0]['id']) : null;
    }

    /** The places one step down, as cards: [key, name, url, line, listings, planned]. */
    public static function children(PDO $pdo, array $p): array
    {
        require_once __DIR__ . '/PageCache.php';
        return PageCache::remember($pdo, 'guides:kids:' . $p['key'], 3600, function () use ($pdo, $p) {
            $out = [];
            $count = fn (string $sql) => (int) $pdo->query("SELECT COUNT(*) FROM entities e WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ('unclaimed','claimed-unverified','pending-verification','verified') AND $sql")->fetchColumn();
            if ($p['level'] === 'hub') {
                $st = $pdo->prepare('SELECT id FROM geo_hubs WHERE hub_id = ? ORDER BY sort_order, name'); $st->execute([$p['id']]);
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $gid) { $g = self::place($pdo, 'geo_hub:' . (int) $gid); if ($g) $out[] = [$g['key'], $g['name'], $g['url'], $g['about'], $g['planned'] ? 0 : $count($g['sql']), $g['planned']]; }
            } elseif ($p['level'] === 'geo_hub') {
                $st = $pdo->prepare('SELECT id FROM micro_clusters WHERE geo_hub_id = ?'); $st->execute([$p['id']]);
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $cid) { $c = self::place($pdo, 'cluster:' . (int) $cid); if ($c) $out[] = [$c['key'], $c['name'], ($one = self::sole($pdo, $c)) ? $one['url'] : $c['url'], implode(', ', array_column(self::townsOf($pdo, (int) $cid), 'name')), $count($c['sql']), false]; }
                usort($out, fn ($a, $b) => strcasecmp($a[1], $b[1]));
            } elseif ($p['level'] === 'cluster') {
                foreach (self::townsOf($pdo, $p['id']) as $t) { $tp = self::place($pdo, 'town:' . (int) $t['id']); if ($tp) $out[] = [$tp['key'], $tp['name'], $tp['url'], 'ZIP ' . implode(', ', $tp['zips']), $count($tp['sql']), false]; }
                foreach (self::subsOf($pdo, $p['id']) as $s) $out[] = ['sub:' . (int) $s['id'], self::clean((string) $s['name']), '/hub/?sub=' . (int) $s['id'], '', 0, false];
            } elseif ($p['level'] === 'town') {
                foreach (self::subsOf($pdo, $p['cluster']) as $s) $out[] = ['sub:' . (int) $s['id'], self::clean((string) $s['name']), '/hub/?sub=' . (int) $s['id'], '', 0, false];
            }
            return $out;
        });
    }

    public static function townsOf(PDO $pdo, int $clusterId): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT id, name, zips FROM anchors WHERE cluster_id = ? ORDER BY name'); $st->execute([$clusterId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function subsOf(PDO $pdo, int $clusterId): array
    {
        try { $st = $pdo->prepare("SELECT id, name FROM cluster_subgroups WHERE cluster_id = ? AND status = 'accepted' ORDER BY name"); $st->execute([$clusterId]); return $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) { return []; }
    }

    /** Every place for the admin tree: [key, name, tier, parent key, kind]. */
    public static function tree(PDO $pdo): array
    {
        self::syncTowns($pdo);
        $out = [];
        foreach ($pdo->query('SELECT id, name FROM hubs ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $h) $out[] = ['hub:' . $h['id'], $h['name'], 2, null];
        foreach ($pdo->query('SELECT id, name, hub_id FROM geo_hubs ORDER BY sort_order, name')->fetchAll(PDO::FETCH_ASSOC) as $g) $out[] = ['geo_hub:' . $g['id'], $g['name'], 3, 'hub:' . $g['hub_id']];
        foreach ($pdo->query('SELECT id, name, geo_hub_id FROM micro_clusters ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $c) $out[] = ['cluster:' . $c['id'], PlaceScope::publicName((string) $c['name']), 4, 'geo_hub:' . $c['geo_hub_id']];
        if (self::ready($pdo)) foreach ($pdo->query('SELECT id, name, cluster_id FROM anchors ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $t) $out[] = ['town:' . $t['id'], $t['name'], 5, 'cluster:' . $t['cluster_id']];
        try { foreach ($pdo->query("SELECT id, name, cluster_id FROM cluster_subgroups WHERE status = 'accepted' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC) as $s) $out[] = ['sub:' . $s['id'], self::clean((string) $s['name']), 6, 'cluster:' . $s['cluster_id']]; } catch (Throwable) {}
        return $out;
    }

    // ---- what our team writes -------------------------------------------------------------------------------------------

    /** The guide's row: sections (decoded), elevation_ft, status… Defaults when nothing is written yet. */
    public static function get(PDO $pdo, string $key): array
    {
        $row = null;
        if (self::ready($pdo)) { $st = $pdo->prepare('SELECT * FROM place_guides WHERE place_key = ?'); $st->execute([$key]); $row = $st->fetch(PDO::FETCH_ASSOC) ?: null; }
        $row = ($row ?: ['place_key' => $key, 'sections' => '', 'elevation_ft' => null, 'status' => 'draft', 'published_at' => null, 'linked_at' => null, 'updated_at' => null]) + ['draft_status' => '', 'draft_at' => null, 'draft_info' => null, 'field_notes' => null];
        $s = json_decode((string) $row['sections'], true);
        $row['sections'] = is_array($s) ? $s : [];
        return $row;
    }

    /**
     * What a live guide says about a thing it names (2026-11-10, Jason: "fold the guide into the results where it raises
     * the level of available experiences"): the sentence naming it, from the guide that names it ('landmark:12',
     * 'entity:34'), as ['line', 'title', 'url'], or null. Kept a day.
     */
    public static function lineAbout(PDO $pdo, string $ref, string $name): ?array
    {
        $name = trim($name);
        if ($ref === '' || mb_strlen($name) < 4) return null;
        require_once __DIR__ . '/PageCache.php';
        $ck = 'guides:line:' . md5($ref . '|' . $name);
        $hit = PageCache::get($pdo, $ck);
        if (is_array($hit)) return $hit ?: null;
        $out = [];
        try {
            $st = $pdo->prepare("SELECT DISTINCT src FROM content_tags WHERE ref = ? AND status IN ('linked','thin') AND src LIKE 'guide:%' LIMIT 4");
            $st->execute([$ref]);
            $first = mb_strtolower(implode(' ', array_slice(preg_split('/\s+/u', $name), 0, 2)));
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $src) {
                $key = substr((string) $src, 6);
                $g = self::shown($pdo, $key);
                $text = '';
                array_walk_recursive($g['sections'], function ($v) use (&$text) { if (is_string($v)) $text .= ' ' . $v; });
                $text = trim((string) preg_replace(['/\[([^\]]+)\]\([^)]*\)/u', '/<[^>]+>/', '/[*_#>`]+/', '/\s+/u'], ['$1', ' ', '', ' '], $text));
                foreach (preg_split('/(?<=[.!?])\s+/u', $text) as $sen) {
                    $l = mb_strtolower($sen);
                    if (mb_strpos($l, mb_strtolower($name)) !== false || ($first !== '' && mb_strpos($l, $first) !== false && mb_strlen($first) >= 8)) {
                        $p = self::place($pdo, $key);
                        $out = ['line' => mb_strimwidth(trim($sen), 0, 280, '…'), 'title' => ($p['name'] ?? 'the') . ' guide', 'url' => (string) ($p['url'] ?? '')];
                        break 2;
                    }
                }
            }
        } catch (Throwable $e) { error_log('guide line ' . $ref . ': ' . $e->getMessage()); }
        PageCache::put($pdo, $ck, 86400, $out);
        return $out ?: null;
    }

    /** What visitors see of the written sections: only a published guide's, less any section taken down (Takedowns). */
    public static function shown(PDO $pdo, string $key): array
    {
        $g = self::get($pdo, $key);
        if ($g['status'] !== 'live') return ['sections' => [], 'elevation_ft' => $g['elevation_ft']] + $g;
        require_once __DIR__ . '/Takedowns.php';
        $held = Takedowns::heldSections($pdo, $key);   // taken down while we look (decisions/0133)
        if (in_array('', $held, true)) return ['sections' => [], 'elevation_ft' => $g['elevation_ft'], 'held' => true] + $g;
        foreach ($held as $sec) unset($g['sections'][$sec]);
        return $g;
    }

    /**
     * Saves the written sections (a draft until $publish). Publishing waits only for held or closed names (GuideLinks::blocking());
     * saving picks the names out again and queues what we don't have. Returns what to say.
     */
    public static function save(PDO $pdo, string $key, array $in, int $uid, bool $publish): string
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run the guides update (2027-01-11_place_guides.sql) first.');
        $p = self::place($pdo, $key) ?: throw new RuntimeException('That place isn\'t here.');
        $sec = [];
        foreach (self::SECTIONS as $k => [, $written]) if ($written) { $t = trim(str_replace("\r", '', (string) ($in[$k] ?? ''))); if ($t !== '') $sec[$k] = mb_substr($t, 0, 12000); }
        $elev = trim((string) ($in['elevation_ft'] ?? '')) === '' ? null : max(-300, min(20000, (int) preg_replace('/[^\d-]/', '', (string) $in['elevation_ft'])));
        $old = self::get($pdo, $key);
        $pdo->prepare('INSERT INTO place_guides (place_key, sections, elevation_ft, status, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, NOW())
                       ON DUPLICATE KEY UPDATE sections = VALUES(sections), elevation_ft = VALUES(elevation_ft), updated_by = VALUES(updated_by), updated_at = NOW()')
            ->execute([$key, json_encode($sec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $elev, $old['status'] === 'live' ? 'live' : 'draft', $uid]);
        if (array_key_exists('field_notes', $in)) {   // what our team knows from being there: never shown, the first thing a draft is written from
            try { $pdo->prepare('UPDATE place_guides SET field_notes = ? WHERE place_key = ?')->execute([mb_substr(trim(str_replace("\r", '', (string) $in['field_notes'])), 0, 20000), $key]); } catch (Throwable) {}
        }
        require_once __DIR__ . '/GuideLinks.php';
        $r = GuideLinks::scan($pdo, $p, $sec);
        $say = $r['names'] ? $r['linked'] . ' of ' . $r['names'] . ' name' . ($r['names'] === 1 ? '' : 's') . ' linked' . ($r['queued'] ? ', ' . $r['queued'] . ' sent to Find it' : '') . '.' : '';
        if ($publish) {
            require_once __DIR__ . '/Jurisdictions.php';
            if ($why = Jurisdictions::closedWhy($pdo, (string) ($p['state'] ?? ''))) { self::forget($pdo, $key); return 'Saved as a draft. ' . $say . ' It can\'t go live yet: ' . $why; }   // decisions/0133: a region opens only after its records are reviewed
            $block = GuideLinks::blocking($pdo, $key);
            if ($block) {
                $pdo->prepare("UPDATE place_guides SET status = 'draft' WHERE place_key = ?")->execute([$key]);
                return 'Saved as a draft. ' . $say . ' It can go live when these are taken out (a protected site or a closed business): ' . implode(', ', array_slice($block, 0, 6)) . (count($block) > 6 ? '…' : '') . '.';
            }
            $di = json_decode((string) ($old['draft_info'] ?? ''), true) ?: []; unset($di['kept'], $di['auto_published']);   // published by a person: the score no longer decides
            $pdo->prepare("UPDATE place_guides SET status = 'live', published_at = COALESCE(published_at, NOW()), linked_at = NOW(), draft_info = ? WHERE place_key = ?")->execute([$di ? json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null, $key]);
            self::forget($pdo, $key);
            return 'Saved and live. ' . $say;
        }
        self::forget($pdo, $key);
        return 'Saved' . ($old['status'] === 'live' ? ' (live)' : ' as a draft') . '. ' . $say;
    }

    // ---- Claude's drafts (Jason, 2026-10-30: the site writes, a person reviews and confirms) -------------------------------

    /** Is Claude on and under the month's AI cap? */
    public static function aiOn(PDO $pdo, string $feature = 'guide_draft'): bool
    {
        require_once __DIR__ . '/AiClient.php';
        return AiClient::allow($pdo, $feature)[0];   // on, under the month's cap, and within the feature's settings (System Configuration → AI use)
    }

    /**
     * What a draft is written from besides our listings: the guide's field notes (our team, from being there), published
     * journeys and experiences here (a member's only with their AI & Learning consent), the place's story, and what people
     * search for here (counts only, never who). Empty when there's none.
     */
    private static function groundTruth(PDO $pdo, array $p, array $g): string
    {
        $out = [];
        $notes = trim((string) ($g['field_notes'] ?? ''));
        if ($notes !== '') $out[] = "FIELD NOTES (from our team, on the ground):\n" . mb_substr($notes, 0, 6000);
        $keys = array_values(array_unique(array_filter([$p['key'], $p['cluster'] ? 'cluster:' . $p['cluster'] : null, $p['parent'] ?? null])));
        $consent = function (?int $uid) use ($pdo): bool { if (!$uid) return false; require_once __DIR__ . '/Consent.php'; try { return Consent::allows($pdo, $uid, 'ai_learning'); } catch (Throwable) { return false; } };
        try {   // local accounts: journeys, then experiences, about this place
            $in = implode(',', array_map(fn ($k) => $pdo->quote($k), $keys));
            $like = implode(' OR ', array_map(fn ($k) => 'scope_keys LIKE ' . $pdo->quote('%' . $k . '%'), $keys));
            $acc = [];
            foreach ($pdo->query("SELECT title, body, voice, author_id FROM journeys WHERE status = 'published' AND (place_key IN ($in) OR $like) ORDER BY published_at DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC) as $j)
                if ($j['voice'] === 'traversence' || $consent((int) $j['author_id'])) $acc[] = '- Journey "' . $j['title'] . '": ' . mb_substr(trim(preg_replace('/\s+/', ' ', (string) $j['body'])), 0, 900);
            foreach ($pdo->query("SELECT title, summary, body, source, author_id FROM experiences WHERE status = 'published' AND (place_key IN ($in) OR $like) ORDER BY published_at DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC) as $x)
                if ($x['source'] !== 'member' || $consent($x['author_id'] ? (int) $x['author_id'] : null)) $acc[] = '- Experience "' . $x['title'] . '": ' . mb_substr(trim($x['summary'] . ' ' . $x['body']), 0, 600);
            if ($acc) $out[] = "LOCAL ACCOUNTS (journeys and experiences people published here):\n" . implode("\n", array_slice($acc, 0, 10));
        } catch (Throwable) {}
        try {   // the story we hold for this place or the community it's in
            require_once __DIR__ . '/Stories.php';
            foreach ($keys as $k) if ($st = Stories::published($pdo, $k)) { $out[] = 'OUR STORY OF ' . strtoupper($st['title'] ?: $p['name']) . ":\n" . mb_substr((string) $st['body'], 0, 3000); break; }
        } catch (Throwable) {}
        try {   // visitors' intent: what people search for here, the last half year
            $towns = array_values(array_unique(array_filter(array_merge([$p['name'], str_replace('St.', 'Saint', $p['name']), str_replace('St. ', 'St ', $p['name'])], $p['level'] === 'cluster' ? array_column(self::townsOf($pdo, (int) $p['id']), 'name') : []))));
            $in = implode(',', array_map(fn ($t) => $pdo->quote($t), $towns));
            $rows = $pdo->query("SELECT anchor, SUM(n) n FROM search_demand WHERE town IN ($in) AND anchor <> '' AND day >= CURDATE() - INTERVAL 180 DAY GROUP BY anchor ORDER BY n DESC LIMIT 15")->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) $out[] = "VISITORS' INTENT (what people searched for here, last 6 months, most first): " . implode(', ', array_map(fn ($r) => $r['anchor'] . ' (' . (int) $r['n'] . ')', $rows));
        } catch (Throwable) {}
        try {   // what members asked AI Assist about here (decisions/0133 step 6): subjects and counts only, never their words
            $askKeys = $keys; if ($p['level'] === 'cluster') foreach (self::townsOf($pdo, (int) $p['id']) as $tw) $askKeys[] = 'town:' . (int) $tw['id'];   // a community's guide: its towns' too
            $in = implode(',', array_map(fn ($k) => $pdo->quote($k), array_unique($askKeys)));
            $rows = $pdo->query("SELECT t.name, COUNT(*) n FROM ai_asks a JOIN topics t ON t.id = a.topic_id
                                  WHERE (a.place_key IN ($in) OR t.place_key IN ($in)) AND a.created_at >= CURDATE() - INTERVAL 180 DAY GROUP BY t.id ORDER BY n DESC, t.name LIMIT 12")->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) $out[] = "WHAT MEMBERS ASKED ABOUT HERE (AI Assist, last 6 months, most first; cover these where what you write from supports it): " . implode(', ', array_map(fn ($r) => $r['name'] . ' (' . (int) $r['n'] . ')', $rows));
        } catch (Throwable) {}
        return implode("\n\n", $out);
    }

    /** Ask for a draft of a guide (the editor's button): it's written now if it can be, else by the next guide job. */
    public static function queueDraft(PDO $pdo, string $key, int $uid): void
    {
        $pdo->prepare("INSERT INTO place_guides (place_key, sections, status, updated_by, updated_at, draft_status, draft_at) VALUES (?, '{}', 'draft', ?, NOW(), 'queued', NOW())
                       ON DUPLICATE KEY UPDATE draft_status = 'queued', draft_at = NOW()")->execute([$key, $uid]);
    }

    /**
     * The guide job's share of drafting: the guides asked for first, then (one at a time) the city and community guides
     * nobody has written yet, busiest first, while Claude is on and under the cap. Returns how many it wrote.
     */
    /**
     * Content maintenance for guides (decisions/0133 Phase 6): every live guide is checked every 30 days, the ones
     * visitors opened since their last check first. The checks are free: the crawler's dossier renewed when it's due
     * (every 6 months), a date in the guide that has passed (an event), a name it links that has closed, research a
     * year old. Something found: a guide Claude wrote is renewed (written again, its own sections only, and scored under
     * the same gates); a guide a person wrote gets the list in its editor (Review). Returns how many were checked.
     */
    /**
     * An event that brings a guide's check forward (decisions/0133 Phase 6): a place it names closed, a visitor suggested a
     * change, new historic records arrived. The check runs on its next turn, ahead of the clock; never on the spot.
     */
    public static function due(PDO $pdo, string $key, string $why): void
    {
        try {
            $st = $pdo->prepare("SELECT draft_info FROM place_guides WHERE place_key = ? AND status = 'live'"); $st->execute([$key]);
            $raw = $st->fetchColumn(); if ($raw === false) return;
            $di = json_decode((string) $raw, true) ?: [];
            $di['due'] = array_slice(array_values(array_unique(array_merge((array) ($di['due'] ?? []), [$why]))), -5);
            $pdo->prepare('UPDATE place_guides SET draft_info = ? WHERE place_key = ?')->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
        } catch (Throwable $e) { error_log('guide due ' . $key . ': ' . $e->getMessage()); }
    }

    /** Every live guide that names this listing (a closure, a move). */
    public static function dueForEntity(PDO $pdo, int $entityId, string $why): void
    {
        try {
            $st = $pdo->prepare("SELECT DISTINCT place_key FROM content_tags WHERE ref = ? AND src LIKE 'guide:%'"); $st->execute(['entity:' . $entityId]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $k) self::due($pdo, (string) $k, $why);
        } catch (Throwable $e) {}
    }

    /** The season now (meteorological, northern hemisphere): when it turns, every live guide is checked. */
    public static function quarter(int $t = 0): string
    {
        $m = (int) date('n', $t ?: time());
        return date('Y', $t ?: time()) . '-' . ($m >= 3 && $m <= 5 ? 'spring' : ($m >= 6 && $m <= 8 ? 'summer' : ($m >= 9 && $m <= 11 ? 'autumn' : 'winter')));
    }

    /** How fresh a guide is, 0-100: down two a day since its last check, and fifteen for each thing found out of date. */
    public static function freshness(array $di): int
    {
        $last = strtotime((string) ($di['checked_at'] ?? $di['at'] ?? '2000-01-01'));
        $days = max(0, (int) floor((time() - $last) / 86400));
        return max(0, min(100, 100 - min(60, $days * 2) - 15 * (count((array) ($di['renew'] ?? [])) + count((array) ($di['flags'] ?? [])))));
    }

    /** The background reader's link check: links in the text that no longer answer or show a parked or suspended page. */
    public static function deadLinks(array $sec, int $max = 5): array
    {
        $urls = [];
        foreach ($sec as $t) if (is_string($t) && preg_match_all('#https?://[^\s)\]>"\']+#i', $t, $m)) foreach ($m[0] as $u) $urls[rtrim($u, '.,;:')] = true;
        $dead = [];
        require_once __DIR__ . '/Dossier.php';
        foreach (array_slice(array_keys($urls), 0, $max) as $u) {
            if (!empty(self::$linkCheck)) { $html = (self::$linkCheck)($u); }
            else {
                $ch = curl_init($u);
                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 4, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_USERAGENT => 'TraversenceBot/1.0 (+https://traversence.com)', CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS]);
                $body = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
                $html = ($body === false || $code >= 400 || $code === 0) ? null : (string) $body;
            }
            if ($html === null || Dossier::dead($html)) $dead[] = $u;
        }
        return $dead;
    }
    /** Tests only: fn (string $url): ?string returning the page, or null when it doesn't answer. */
    public static $linkCheck = null;

    public static function maintainTick(PDO $pdo, int $n = 2): int
    {
        if (!self::ready($pdo)) return 0;
        require_once __DIR__ . '/Dossier.php';
        // the season turned: every live guide is checked (what a visitor needs changes with it)
        try {
            require_once __DIR__ . '/SearchIndex.php';
            $was = SearchIndex::state($pdo, 'guides_season');
            if ($was !== self::quarter()) {
                if ($was !== '') foreach ($pdo->query("SELECT place_key FROM place_guides WHERE status = 'live'")->fetchAll(PDO::FETCH_COLUMN) as $k) self::due($pdo, (string) $k, 'the season turned');
                SearchIndex::setState($pdo, 'guides_season', self::quarter());
            }
        } catch (Throwable $e) {}
        // demand spikes: a guide opened at least three times as often this week as in the four before (and 20 or more times)
        $spike = [];
        try {
            foreach ($pdo->query("SELECT k, SUM(IF(day >= CURDATE() - INTERVAL 7 DAY, n, 0)) AS wk, SUM(IF(day < CURDATE() - INTERVAL 7 DAY, n, 0)) / 4 AS avg4
                                   FROM platform_counts WHERE metric = 'view' AND k LIKE 'place:%' AND day >= CURDATE() - INTERVAL 35 DAY GROUP BY k")->fetchAll(PDO::FETCH_ASSOC) as $v)
                if ((int) $v['wk'] >= 20 && (float) $v['wk'] >= 3 * max(1.0, (float) $v['avg4'])) $spike[substr((string) $v['k'], 6)] = true;
        } catch (Throwable $e) {}
        $rows = $pdo->query("SELECT place_key, sections, draft_info, updated_at FROM place_guides WHERE status = 'live' AND draft_status IN ('', 'done', 'failed')")->fetchAll(PDO::FETCH_ASSOC);
        $seen = [];   // the last day each guide was opened (the platform's counts: views only, never who)
        try { $seen = $pdo->query("SELECT k, MAX(day) FROM platform_counts WHERE metric = 'view' AND k LIKE 'place:%' AND day >= CURDATE() - INTERVAL 60 DAY GROUP BY k")->fetchAll(PDO::FETCH_KEY_PAIR); } catch (Throwable $e) {}
        $due = []; $every = max(7, (int) (self::template($pdo)['shelf']['check_days'] ?? 30));   // the template's shelf life: how often a live guide is checked
        foreach ($rows as $r) {
            $r['seen'] = $seen['place:' . $r['place_key']] ?? null;
            $di = json_decode((string) ($r['draft_info'] ?? ''), true) ?: [];
            if (!empty($di['renew'])) continue;   // already waiting to be written again
            $last = (string) ($di['checked_at'] ?? $di['at'] ?? $r['updated_at'] ?? '2000-01-01');
            $event = !empty($di['due']) || (isset($spike[$r['place_key']]) && strtotime($last) < time() - 7 * 86400);
            if (!$event && strtotime($last) > time() - $every * 86400) continue;
            if (isset($spike[$r['place_key']]) && empty($di['due'])) $di['due'] = ['visitors are looking at it far more than usual'];
            $due[] = [$r, $di, $r['seen'] !== null && strtotime((string) $r['seen']) >= strtotime(substr($last, 0, 10)), $last, $event];
        }
        usort($due, fn ($a, $b) => [$b[4], $b[2], $a[3]] <=> [$a[4], $a[2], $b[3]]);   // an event first, then opened since its last check, then the longest unchecked
        $done = 0;
        foreach (array_slice($due, 0, max(1, $n)) as [$r, $di, , , $event]) {
            $key = (string) $r['place_key'];
            $p = self::place($pdo, $key); if (!$p) continue;
            $why = []; $theirs = [];   // what Claude's renewal can fix; what's in a section a person wrote
            [$h0] = Dossier::stamp($pdo, $key);
            try { Dossier::forPlace($pdo, $p); } catch (Throwable $e) { error_log('guide check dossier ' . $key . ': ' . $e->getMessage()); }
            [$h1, $resAt] = Dossier::stamp($pdo, $key);
            if ($h0 !== '' && $h1 !== $h0) $why[] = 'what the crawler knows about the place changed';
            if ($resAt !== '' && strtotime($resAt) < time() - 365 * 86400) $why[] = 'its research is a year old';
            try { require_once __DIR__ . '/Heritage.php'; $hv = Heritage::lastVetted($pdo, $key); if ($hv !== '' && strtotime($hv) > strtotime((string) ($di['at'] ?? '2000-01-01'))) $why[] = 'the heritage catalog has new vetted facts'; } catch (Throwable $e) {}
            $sec = json_decode((string) $r['sections'], true) ?: [];
            $own = [];   // sections still Claude's own (unchanged since it wrote them)
            foreach ((array) ($di['hash'] ?? []) as $k => $h) if (isset($sec[$k]) && md5(trim((string) $sec[$k])) === $h) $own[$k] = true;
            $fix = [];   // what the cheapest model may fix with exact edits before a full rewrite: [line => [kind, what]]
            foreach (self::pastDates($sec) as [$k, $d]) {
                $line = 'a date has passed (' . $d . ', ' . (self::SECTIONS[$k][0] ?? $k) . ')';
                if (isset($own[$k])) { $why[] = $line; $fix[$line] = ['date', $d]; } else $theirs[] = $line;
            }
            try {
                $all = implode("\n", array_map('strval', $sec));
                $st = $pdo->prepare("SELECT name FROM content_tags WHERE src = ? AND status = 'closed' LIMIT 5"); $st->execute(['guide:' . $key]);
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $nm) { if (mb_stripos($all, (string) $nm) === false) continue; $why[] = $l = 'it names ' . $nm . ', which has closed'; $fix[$l] = ['closed', (string) $nm]; }   // only while the text still names it
                $st = $pdo->prepare("SELECT DISTINCT t.name FROM content_tags t JOIN entity_metadata m ON m.entity_id = CAST(SUBSTRING(t.ref, 8) AS UNSIGNED) AND m.meta_key = 'closed'
                                      WHERE t.src = ? AND t.ref LIKE 'entity:%' LIMIT 5"); $st->execute(['guide:' . $key]);   // marked closed since its names were last matched
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $nm) { if (mb_stripos($all, (string) $nm) === false) continue; $why[] = $l = 'it names ' . $nm . ', which has closed'; $fix[$l] = ['closed', (string) $nm]; }   // only while the text still names it
            } catch (Throwable $e) {}
            foreach (self::deadLinks(array_intersect_key($sec, $own)) as $u) { $why[] = $l = 'a link in it no longer works (' . $u . ')'; $fix[$l] = ['link', (string) $u]; }   // the background reader: links alive
            foreach (self::deadLinks(array_diff_key($sec, $own)) as $u) $theirs[] = 'a link in it no longer works (' . $u . ')';
            $why = array_values(array_unique($why));
            // the cheapest model first (decisions/0133): when everything found is a small fix in Claude's own sections, exact edits
            // instead of a full rewrite; whatever they don't fix (or anything new to write from) still renews the guide
            if ($why && $own && empty($di['kept']) && !array_diff($why, array_keys($fix))) {
                $t = self::triage($pdo, $p, $sec, $own, array_intersect_key($fix, array_flip($why)));
                if ($t['fixed']) {
                    // only the sections triage changed, and only where nobody saved since the check read them (review B8)
                    [$sec, $theirs] = self::keepNewer($pdo, $key, json_decode((string) $r['sections'], true) ?: [], $t['sections']);
                    foreach ($t['changed'] as $k) if (!in_array($k, $theirs, true)) $di['hash'][$k] = md5(trim((string) $sec[$k]));   // still Claude's own
                    foreach ($theirs as $k) unset($di['hash'][$k]);
                    $pdo->prepare('UPDATE place_guides SET sections = ?, updated_at = NOW() WHERE place_key = ?')->execute([json_encode($sec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
                    $di['triage'] = ['at' => date('c'), 'fixed' => $t['fixed']];
                    self::forget($pdo, $key);
                }
                $why = $t['left'];
            }
            $di['checked_at'] = date('c');
            if (!empty($di['due'])) $di['checked_for'] = $di['due'];   // what brought the check forward
            unset($di['flags'], $di['due']);
            if ($why && $own && empty($di['kept'])) $di['renew'] = $why;   // draftTick writes Claude's sections again
            elseif ($why) $theirs = array_merge($why, $theirs);             // nothing of Claude's left to renew
            if ($theirs) $di['flags'] = array_values(array_unique($theirs)); // a person's sections: shown in the editor
            $di['fresh'] = self::freshness($di);
            $pdo->prepare('UPDATE place_guides SET draft_info = ? WHERE place_key = ?')->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
            $done++;
        }
        return $done;
    }

    /**
     * The cheapest model fixes what the free checks found (a passed date, a closed business, a dead link) with exact edits
     * to Claude's own sections. An edit is applied only when its text appears once, it adds no link and nothing the
     * protected-information scrub would cut, and the finding is gone afterwards. $fix: [line => [kind, what]].
     * Returns ['sections', 'changed' => section keys, 'fixed' => lines, 'left' => lines still needing a rewrite].
     */
    public static function triage(PDO $pdo, array $p, array $sec, array $own, array $fix): array
    {
        $out = ['sections' => $sec, 'changed' => [], 'fixed' => [], 'left' => array_keys($fix)];
        if (!$fix) return $out;
        require_once __DIR__ . '/AiClient.php';
        try { [$ok] = AiClient::allow($pdo, 'guide_triage'); } catch (Throwable $e) { $ok = false; }
        if (!$ok) return $out;
        $fc = AiClient::feature($pdo, 'guide_triage');
        $text = '';
        foreach (array_intersect_key($sec, $own) as $k => $t) $text .= '[' . $k . "]\n" . mb_substr((string) $t, 0, 6000) . "\n\n";
        $prompt = 'This is part of a travel guide to ' . $p['name'] . ". Our checks found:\n- " . implode("\n- ", array_keys($fix))
            . "\n\nFix each with the smallest exact edits: for a date that has passed, drop the date or say the event is held each year if the text says it recurs, else drop the sentence; "
            . "for a business that has closed, remove it from the sentence or drop the sentence; for a link that no longer works, remove the link and keep the words. "
            . "Each edit: the section key, the exact text to find (copied character for character, a full sentence or less) and what replaces it (empty to delete). "
            . "Add nothing new: no new places, facts, links or dates. If a finding needs more than a few edits, leave it out.\n\n" . $text;
        $schema = ['type' => 'object', 'additionalProperties' => false, 'required' => ['edits'], 'properties' => ['edits' => ['type' => 'array', 'items' => ['type' => 'object', 'additionalProperties' => false,
            'required' => ['section', 'find', 'replace'], 'properties' => ['section' => ['type' => 'string'], 'find' => ['type' => 'string'], 'replace' => ['type' => 'string']]]]]];
        try {
            $r = AiClient::claudeAsk(mb_substr($prompt, 0, 30000), $schema, $fc['model'], 0, 2000, 'low');
            AiClient::record($pdo, 'guide_triage', 0, 'done', $r);
        } catch (Throwable $e) { error_log('guide triage ' . $p['key'] . ': ' . $e->getMessage()); return $out; }
        $new = $sec; $changed = [];
        foreach (array_slice((array) ($r['data']['edits'] ?? []), 0, 20) as $ed) {
            $k = (string) ($ed['section'] ?? ''); $find = (string) ($ed['find'] ?? ''); $rep = trim((string) ($ed['replace'] ?? ''));
            if (!isset($own[$k], $new[$k]) || trim($find) === '' || substr_count((string) $new[$k], $find) !== 1) continue;
            if (preg_match('#https?://|www\.#i', $rep) || mb_strlen($rep) > mb_strlen($find) + 40) continue;   // adds no link, nothing much new
            [, $cut] = self::scrub([$k => $rep], [$k]);
            if ($rep !== '' && $cut) continue;
            $new[$k] = trim((string) preg_replace('/[ \t]{2,}/', ' ', str_replace($find, $rep, (string) $new[$k])));
            $changed[$k] = true;
        }
        if (!$changed) return $out;
        // which findings are gone now
        $still = [];
        foreach ($fix as $line => [$kind, $what]) {
            $gone = true;
            foreach (array_intersect_key($new, $own) as $t) if (mb_stripos((string) $t, $what) !== false) { $gone = false; break; }
            if ($kind === 'date') foreach (self::pastDates(array_intersect_key($new, $own)) as [, $d]) if ($d === $what) $gone = false;
            if (!$gone) $still[] = $line;
        }
        $fixed = array_values(array_diff(array_keys($fix), $still));
        if (!$fixed) return $out;
        return ['sections' => $new, 'changed' => array_keys($changed), 'fixed' => $fixed, 'left' => $still];
    }

    /** Full dates in a guide's sections that are before today: [[section, the date as written]]. Bare months and years
     *  ("every June") are a year's rhythm, not a date that passes. */
    public static function pastDates(array $sec): array
    {
        $out = [];
        $mon = 'jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?';
        foreach ($sec as $k => $t) {
            if (!is_string($t)) continue;
            preg_match_all('/\b((?:' . $mon . ')\.?\s+\d{1,2}(?:\s*[-–]\s*\d{1,2})?,?\s+(20\d\d))\b|\b(\d{1,2})\/(\d{1,2})\/(20\d\d)\b/i', $t, $m, PREG_SET_ORDER);
            foreach ($m as $x) {
                $txt = $x[0];
                $ts = !empty($x[1]) ? strtotime(preg_replace('/\s*[-–]\s*\d{1,2}/', '', str_replace('.', '', $x[1]))) : mktime(0, 0, 0, (int) $x[3], (int) $x[4], (int) $x[5]);
                if ($ts && $ts < strtotime('today')) $out[] = [$k, $txt];
            }
        }
        return array_slice($out, 0, 5);
    }

    public static function draftTick(PDO $pdo, int $n = 1, bool $auto = true): int
    {
        if (!self::ready($pdo)) return 0;
        $done = 0;
        $tpl = self::template($pdo); $ap = (array) ($tpl['applies'] ?? []);   // the Place guide template: runs, which tiers write themselves, how busy a place must be
        $n = max(1, min(10, (int) ($tpl['runs']['per_run'] ?? $n)));
        $auto = $auto && $tpl['status'] === 'active';   // a template being shaped or switched off writes only what's asked for
        $autoTiers = array_map('intval', (array) ($ap['auto_tiers'] ?? [4, 5])); $minListings = max(1, (int) ($ap['min_listings'] ?? 5));
        if ($auto) self::gatherTick($pdo, 2);   // places gathering for their first guide move on when their sources are in
        if (self::publishesItself($pdo))   // Claude's drafts from before guides published themselves, and ones a name no longer holds back
            foreach ($pdo->query("SELECT place_key FROM place_guides WHERE status = 'draft' AND draft_status = 'done' LIMIT 50")->fetchAll(PDO::FETCH_COLUMN) as $k) { try { self::autoPublish($pdo, (string) $k); } catch (Throwable $e) { error_log('guide publish ' . $k . ': ' . $e->getMessage()); } }
        for ($i = 0; $i < $n; $i++) {
            $key = self::aiOn($pdo, 'guide_draft') ? (string) $pdo->query("SELECT place_key FROM place_guides WHERE draft_status = 'queued' OR (draft_status = 'writing' AND draft_at < NOW() - INTERVAL 15 MINUTE) ORDER BY draft_at LIMIT 1")->fetchColumn() : '';
            $feature = 'guide_draft'; $again = false;
            if ($key === '' && $auto && self::aiOn($pdo, 'guide_draft_auto')) {   // a guide Claude wrote before the crawler's dossier and the confidence score: written again from them (its own sections only; a person's stay)
                $key = (string) $pdo->query("SELECT place_key FROM place_guides WHERE draft_status = 'done' AND (COALESCE(draft_info, '') NOT LIKE '%\"v\":" . self::DRAFT_V . "%' OR draft_info LIKE '%\"renew\":[%') AND COALESCE(draft_info, '') NOT LIKE '%\"kept\"%' ORDER BY draft_info LIKE '%\"renew\":[%' DESC, draft_at LIMIT 1")->fetchColumn();   // a renewal (maintainTick) first
                if ($key !== '') { $feature = 'guide_draft_auto'; $again = true; }
            }
            if ($key === '' && $auto && self::aiOn($pdo, 'guide_draft_auto')) {   // only while drafting on its own is on and within its day and budget
                $feature = 'guide_draft_auto';   // the next unwritten city or community guide, the one with the most listings first
                $have = array_flip($pdo->query("SELECT place_key FROM place_guides WHERE draft_status <> '' OR (sections <> '' AND sections <> '{}' AND sections <> '[]')")->fetchAll(PDO::FETCH_COLUMN));
                $best = null;
                foreach (self::tree($pdo) as [$k, , $tier]) if (in_array($tier, $autoTiers, true) && !isset($have[$k])) {
                    $p = self::place($pdo, $k); if (!$p || $p['lat'] === null || self::sole($pdo, $p)) continue;   // a one-town community is its town's guide
                    $c = (int) $pdo->query("SELECT COUNT(*) FROM entities e WHERE e.is_suppressed = 0 AND " . $p['sql'])->fetchColumn();
                    if (!$best || $c > $best[1]) $best = [$k, $c];
                }
                if ($best && $best[1] >= $minListings) { self::gather($pdo, $best[0]); $key = ''; }   // free sources first: it's written once they're gathered (gatherTick)
            }
            if ($key === '') break;
            try { self::writeDraft($pdo, $key, $again, $feature); $done++; } catch (Throwable $e) { error_log('guide draft ' . $key . ': ' . $e->getMessage()); }
        }
        return $done;
    }

    /**
     * The Place guide template (the AI Content Crawler's templates, System Configuration → Content templates): what the
     * template saved says, over what the code has, part by part; the code's when there's no template yet.
     */
    public static function template(PDO $pdo): array
    {
        static $memo = null;
        if (self::$override !== null) { require_once __DIR__ . '/ContentTemplates.php'; $spec = ContentTemplates::placeGuide(); foreach (self::$override as $part => $v) if (is_array($v) && isset($spec[$part]) && is_array($spec[$part])) $spec[$part] = array_replace($spec[$part], $v); elseif ($v !== null) $spec[$part] = $v; $spec['status'] = 'draft'; return $spec; }   // a template being shaped (preview, try)
        if ($memo !== null) return $memo;
        require_once __DIR__ . '/ContentTemplates.php';
        $code = ContentTemplates::placeGuide();
        $t = null; try { $t = ContentTemplates::get($pdo, 'place_guide'); } catch (Throwable $e) {}
        $spec = $code;
        if ($t) foreach ((array) $t['spec'] as $part => $v) if (is_array($v) && isset($code[$part]) && is_array($code[$part])) $spec[$part] = array_replace($code[$part], $v); elseif ($v !== null) $spec[$part] = $v;
        $spec['status'] = $t ? (string) $t['status'] : 'active';
        return $memo = $spec;
    }

    /**
     * The template's sections the writer may write, in its order: key => [heading, written, instruction, pass]. Only the
     * guide's own sections (a section the guide page doesn't draw yet isn't written; step 4 adds new ones).
     */
    public static function templateSections(array $tpl): array
    {
        $out = [];
        foreach ((array) ($tpl['write']['sections'] ?? []) as $sx) {
            $k = (string) ($sx['key'] ?? '');
            if (!isset(self::SECTIONS[$k]) || isset($out[$k])) continue;
            if (array_key_exists('on', $sx) && !$sx['on']) continue;   // switched off in the template
            $out[$k] = ['heading' => trim((string) ($sx['heading'] ?? '')) ?: self::SECTIONS[$k][0], 'written' => (bool) ($sx['written'] ?? false) && self::SECTIONS[$k][1],
                        'instruction' => (string) ($sx['instruction'] ?? self::SECTIONS[$k][2]), 'pass' => (string) ($sx['pass'] ?? '')];
        }
        return $out;
    }

    /** A template's text for one place: {place} is its name. */
    private static function fill(string $text, array $p): string
    {
        return str_replace('{place}', (string) $p['name'], $text);
    }

    /**
     * The sections a person wrote (or changed since Claude wrote them): key => text. Claude's own, still exactly as written,
     * are left out (decisions/0133: never overwrite what a person entered; tips only, for their words).
     */
    public static function personSections(array $g): array
    {
        $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: []; $own = (array) ($di['hash'] ?? []); $out = [];
        foreach ((array) ($g['sections'] ?? []) as $k => $t) { $t = trim((string) $t); if ($t !== '' && !(isset($own[$k]) && $own[$k] === md5($t)) && !empty(self::SECTIONS[$k][1])) $out[$k] = $t; }
        return $out;
    }

    /**
     * Free fact tips for what a person wrote (Jason, 2026-10-30: curator, not controller): where their words disagree with
     * the facts our crawler holds (Wikidata via the dossier: when the town was founded, its elevation, its population), a tip
     * in the editor saying what the source says. Nothing is changed. [[section, tip, source url]].
     */
    public static function factTips(PDO $pdo, string $key, ?array $g = null): array
    {
        require_once __DIR__ . '/Dossier.php';
        $g = $g ?? self::get($pdo, $key);
        $f = Dossier::facts($pdo, $key); $src = (string) (!empty($f['wikidata']) ? 'https://www.wikidata.org/wiki/' . $f['wikidata'] : ($f['wikipedia'] ?? ''));
        $out = [];
        foreach (self::personSections($g) as $k => $t) {
            $label = self::SECTIONS[$k][0] ?? $k;
            if (!empty($f['founded']) && preg_match_all('/\b(?:founded|settled|established|incorporated|laid out)\b[^.]{0,40}?\b(1[5-9]\d\d|20[0-2]\d)\b/i', $t, $m, PREG_SET_ORDER))
                foreach ($m as $x) if ((int) $x[1] !== (int) $f['founded']) { $out[] = [$k, $label . ': you wrote "' . mb_strimwidth(trim($x[0]), 0, 70, '…') . '"; Wikidata gives ' . (int) $f['founded'] . ' as the year it was founded. Both can be right (settled, then founded): check which you mean.', $src]; break; }
            $elev = (int) ($f['elevation_ft'] ?? 0) ?: (int) ($g['elevation_ft'] ?? 0);
            if ($elev > 0 && preg_match_all('/\b(\d{1,2},?\d{3})\s*(?:feet|ft)\b[^.]{0,30}?\b(?:elevation|above sea level)|\b(?:elevation|altitude) of (?:about |around |nearly |some )?(\d{1,2},?\d{3})\s*(?:feet|ft)?/i', $t, $m, PREG_SET_ORDER))
                foreach ($m as $x) { $v = (int) str_replace(',', '', $x[1] !== '' ? $x[1] : ($x[2] ?? '')); if ($v > 0 && abs($v - $elev) > max(150, $elev * 0.05)) { $out[] = [$k, $label . ': you wrote ' . number_format($v) . ' feet; ' . (!empty($f['elevation_ft']) ? 'Wikidata gives' : 'the weather service gives') . ' about ' . number_format($elev) . ' feet for the town.', $src]; break; } }
            if (!empty($f['population']) && preg_match('/\bpopulation (?:of |is |was )?(?:about |around |nearly |some |roughly )?(\d{1,3}(?:,\d{3})+|\d{3,7})\b|\b(\d{1,3}(?:,\d{3})+|\d{3,7}) (?:people|residents)\b/i', $t, $x)) {
                $v = (int) str_replace(',', '', ($x[1] ?? '') !== '' ? $x[1] : ($x[2] ?? ''));
                if ($v > 0 && abs($v - (int) $f['population']) > (int) $f['population'] * 0.25) $out[] = [$k, $label . ': you wrote ' . number_format($v) . ' people; Wikidata\'s latest count is ' . number_format((int) $f['population']) . '.', $src];
            }
        }
        return $out;
    }

    /**
     * Check my facts (on request only: AI acts on a person's words only when they ask): Claude reads what a person wrote
     * against what we hold (the dossier, the research brief, the heritage catalog) and lists what disagrees or what nothing
     * we hold supports, each with the words in question. Nothing is changed; the list is kept with the guide for its editor.
     * Spends like any check (fact_check in AI use). Returns what it found.
     */
    public static function checkFacts(PDO $pdo, string $key, int $uid): array
    {
        $p = self::place($pdo, $key) ?: throw new RuntimeException('That place isn\'t here.');
        require_once __DIR__ . '/AiClient.php'; require_once __DIR__ . '/Dossier.php';
        [$ok, $why] = AiClient::allow($pdo, 'fact_check'); if (!$ok) throw new RuntimeException($why);
        $g = self::get($pdo, $key); $mine = self::personSections($g);
        if (!$mine) throw new RuntimeException('There\'s nothing a person wrote in this guide to check.');
        [$dos] = Dossier::forPlace($pdo, $p); [$res] = Dossier::research($pdo, $p, $dos, false, false);   // only what's held: a check spends on the check alone
        $cat = ''; try { require_once __DIR__ . '/Heritage.php'; $cat = Heritage::forGuide($pdo, $key); } catch (Throwable $e) {}
        $text = ''; foreach ($mine as $k => $t) $text .= '[' . $k . "]\n" . mb_substr($t, 0, 6000) . "\n\n";
        $prompt = 'Our team wrote these sections of the guide to ' . $p['name'] . ($p['state'] ? ', ' . $p['state'] : '') . ". Check their facts (names, dates, numbers, distances, what happened) against the material below, which is all you may use. "
            . "List each statement that the material contradicts (kind: conflict) and each specific fact the material doesn't support either way (kind: unsupported); leave out opinions, descriptions and anything the material agrees with. "
            . "For each: the section key, the exact words in question (copied, a sentence or less), what the material says (or that it says nothing), and which material says it (dossier, brief or catalog). Never rewrite their text.\n\n"
            . "THEIR SECTIONS:\n" . $text . ($dos !== '' ? "DOSSIER:\n" . mb_substr($dos, 0, 12000) . "\n\n" : '') . ($res !== '' ? "RESEARCH BRIEF:\n" . mb_substr($res, 0, 12000) . "\n\n" : '') . ($cat !== '' ? "HERITAGE CATALOG:\n" . mb_substr($cat, 0, 8000) : '');
        $schema = ['type' => 'object', 'additionalProperties' => false, 'required' => ['items'], 'properties' => ['items' => ['type' => 'array', 'items' => ['type' => 'object', 'additionalProperties' => false,
            'required' => ['section', 'quote', 'kind', 'says', 'from'], 'properties' => ['section' => ['type' => 'string'], 'quote' => ['type' => 'string'], 'kind' => ['type' => 'string', 'enum' => ['conflict', 'unsupported']], 'says' => ['type' => 'string'], 'from' => ['type' => 'string']]]]]];
        $fc = AiClient::feature($pdo, 'fact_check');
        $r = AiClient::claudeAsk(mb_substr($prompt, 0, 50000), $schema, (string) $fc['model'], 0, 3000, 'low');
        AiClient::record($pdo, 'fact_check', 0, 'done', $r, $uid);
        $items = [];
        foreach (array_slice((array) ($r['data']['items'] ?? []), 0, 20) as $it) {
            $k = (string) ($it['section'] ?? ''); $q = trim((string) ($it['quote'] ?? ''));
            if (!isset($mine[$k]) || $q === '' || mb_stripos($mine[$k], mb_substr($q, 0, 60)) === false) continue;   // only words that are really there
            $items[] = ['section' => $k, 'quote' => mb_substr($q, 0, 300), 'kind' => (string) ($it['kind'] ?? 'unsupported') === 'conflict' ? 'conflict' : 'unsupported', 'says' => mb_substr(trim((string) ($it['says'] ?? '')), 0, 400), 'from' => mb_substr(trim((string) ($it['from'] ?? '')), 0, 40)];
        }
        $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: [];
        $di['factcheck'] = ['at' => date('c'), 'by' => $uid, 'items' => $items, 'micros' => (int) ($r['micros'] ?? 0), 'sections' => array_map(fn ($t) => md5($t), $mine)];
        $pdo->prepare('UPDATE place_guides SET draft_info = ? WHERE place_key = ?')->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
        return $di['factcheck'];
    }

    /** How long a place waits for the Library of Congress before its brief is written anyway, and for everything before its guide is. */
    public const GATHER_LOC_HOURS = 24;
    public const GATHER_MAX_HOURS = 48;

    /**
     * Free sources first (decisions/0133, the AI Content Crawler's templates step 3): a place picked for its first guide
     * starts by gathering. The crawler's dossier now (Wikipedia, Wikidata, the official site, the National Register,
     * our landmarks), then the worker's Library of Congress reading (its catalog and historic newspapers); gatherTick
     * moves it on. Free so far.
     */
    public static function gather(PDO $pdo, string $key): void
    {
        $pdo->prepare("INSERT INTO place_guides (place_key, sections, status, updated_by, updated_at, draft_status, draft_at) VALUES (?, '{}', 'draft', 0, NOW(), 'gathering', NOW())
                       ON DUPLICATE KEY UPDATE draft_status = IF(draft_status = '', 'gathering', draft_status), draft_at = IF(draft_status = 'gathering', NOW(), draft_at)")->execute([$key]);
        $p = self::place($pdo, $key);
        if ($p) { require_once __DIR__ . '/Dossier.php'; try { Dossier::forPlace($pdo, $p); } catch (Throwable $e) { error_log('gather dossier ' . $key . ': ' . $e->getMessage()); } }
    }

    /**
     * Moves gathering places on: once the Library of Congress has been read (or a day has passed), the research brief is
     * written, told what the free sources already hold so it searches only for the gaps, and the place's passages are read
     * into heritage facts; then it's queued, so its first guide is written from all of it (and its "Walking in the
     * footsteps" chapter has facts from the start). After two days it's queued whatever has come in. Returns how many moved on.
     */
    public static function gatherTick(PDO $pdo, int $n = 1): int
    {
        if (!self::ready($pdo)) return 0;
        require_once __DIR__ . '/Dossier.php';
        require_once __DIR__ . '/Heritage.php';
        require_once __DIR__ . '/AiClient.php';
        $moved = 0;
        foreach ($pdo->query("SELECT place_key, draft_at FROM place_guides WHERE draft_status = 'gathering' ORDER BY draft_at LIMIT " . max(1, min(5, $n)))->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $key = (string) $r['place_key'];
            $p = self::place($pdo, $key);
            if (!$p) { $pdo->prepare("UPDATE place_guides SET draft_status = '' WHERE place_key = ?")->execute([$key]); continue; }
            $hours = (time() - strtotime((string) $r['draft_at'])) / 3600;
            if ($hours < self::GATHER_MAX_HOURS) {
                $st = $pdo->prepare('SELECT loc_at FROM heritage_places WHERE place_key = ?'); $st->execute([$key]);
                if (!$st->fetchColumn() && $hours < self::GATHER_LOC_HOURS) continue;   // the worker reads the Library of Congress first
                try {
                    [$dos] = Dossier::forPlace($pdo, $p);
                    [$res] = Dossier::research($pdo, $p, $dos);   // gap-only when the free sources are rich; kept a year, so the writer reuses it
                    if ($res === '' && !AiClient::allow($pdo, 'guide_research')[0]) continue;   // the brief can't be written now: wait (up to two days)
                    Heritage::extractPlace($pdo, $key);
                } catch (Throwable $e) { error_log('gather ' . $key . ': ' . $e->getMessage()); continue; }
            }
            $pdo->prepare("UPDATE place_guides SET draft_status = 'queued' WHERE place_key = ? AND draft_status = 'gathering'")->execute([$key]);
            $moved++;
        }
        return $moved;
    }

    /**
     * A section a person saved after $from was read wins over what a draft or a triage is about to write (review B8,
     * 2026-11-13): [sections to save, the keys that are theirs, draft_info as it is now (null if unreadable)].
     */
    private static function keepNewer(PDO $pdo, string $key, array $from, array $sec): array
    {
        try { $st = $pdo->prepare('SELECT sections, draft_info FROM place_guides WHERE place_key = ?'); $st->execute([$key]); $row = $st->fetch(PDO::FETCH_ASSOC); }
        catch (Throwable $e) { return [$sec, [], null]; }
        if (!$row) return [$sec, [], null];
        $now = json_decode((string) $row['sections'], true); $now = is_array($now) ? $now : [];
        $theirs = [];
        foreach (array_unique(array_merge(array_keys($now), array_keys($from))) as $k) {
            $a = trim((string) ($from[$k] ?? '')); $b = trim((string) ($now[$k] ?? ''));
            if ($a === $b) continue;   // untouched since it was read
            $theirs[] = $k;
            if ($b === '') unset($sec[$k]); else $sec[$k] = $now[$k];   // cleared or rewritten by a person: theirs stands
        }
        $info = json_decode((string) ($row['draft_info'] ?? ''), true);
        return [$sec, $theirs, is_array($info) ? $info : []];
    }

    /**
     * A draft that failed keeps its record (review B7, 2026-11-13): the "kept down" mark, the hashes of Claude's own
     * sections, a renewal still due, and what its passes cost so far. Only the error and when are added.
     */
    private static function draftFailed(PDO $pdo, string $key, string $error, int $micros, int $pass): void
    {
        try {
            $st = $pdo->prepare('SELECT draft_info FROM place_guides WHERE place_key = ?'); $st->execute([$key]);
            $di = json_decode((string) $st->fetchColumn(), true); $di = is_array($di) ? $di : [];
            $di['error'] = mb_substr($error, 0, 500);
            $di['failed_at'] = date('c');
            $di['failed_pass'] = $pass + 1;
            if ($micros > 0) $di['failed_micros'] = (int) ($di['failed_micros'] ?? 0) + $micros;   // passes already paid for before it failed
            $pdo->prepare("UPDATE place_guides SET draft_status = 'failed', draft_info = ? WHERE place_key = ?")->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
        } catch (Throwable $e) { error_log('guide draft failed ' . $key . ': ' . $e->getMessage()); }
    }

    /**
     * Claude writes the guide's empty sections (never one a person wrote) from what we have (the place, its listings,
     * landmarks, outdoor places and towns) and what it can confirm on the web, naming only real places. Saved as a
     * draft, names matched; what Claude says to check and its sources are kept for the reviewer. Returns a line saying
     * what it did.
     */
    public static function writeDraft(PDO $pdo, string $key, bool $rewrite = false, string $feature = 'guide_draft', array $avoid = []): string
    {
        return (string) self::compose($pdo, $key, $rewrite, $feature, $avoid, 'write')['say'];
    }

    /**
     * What Claude would be sent for this place under the template in use (or $spec, a template being shaped), without
     * sending it or spending anything: the research brief is used only if one is held. ['passes' => [[sections, prompt,
     * searches, max_tokens]], 'model', 'research_held', 'estimate' => [usd, usd_max], 'say'].
     */
    public static function preview(PDO $pdo, string $key, ?array $spec = null): array
    {
        $was = self::$override; self::$override = $spec;
        try { return self::compose($pdo, $key, true, 'guide_draft', [], 'preview'); } finally { self::$override = $was; }
    }

    /**
     * Writes this place's guide under $spec (a template being shaped) as a try: Claude writes, the same checks run, and
     * nothing is saved to the guide: the result is returned for the template's page. Spends like a draft (guide_draft).
     * ['sections', 'cut', 'check', 'confidence', 'micros', 'added', 'say'].
     */
    public static function tryTemplate(PDO $pdo, string $key, ?array $spec): array
    {
        $was = self::$override; self::$override = $spec;
        try { return self::compose($pdo, $key, true, 'guide_draft', [], 'try'); } finally { self::$override = $was; }
    }

    /** A template being shaped, used in place of the saved one for a preview or a try. */
    private static ?array $override = null;

    /**
     * A first look (decisions/0147 §1a): written at once for a place someone searched, from what's held and the free
     * sources only (no research brief is bought now; that comes with the full guide), shorter, and quicker.
     */
    public static bool $firstLook = false;

    /** The writer: 'write' saves to the guide (as writeDraft always has), 'preview' builds the prompts only, 'try' writes without saving. */
    private static function compose(PDO $pdo, string $key, bool $rewrite, string $feature, array $avoid, string $mode): array
    {
        $p = self::place($pdo, $key) ?: throw new RuntimeException('That place isn\'t here.');
        require_once __DIR__ . '/AiClient.php';
        [$ok, $why] = AiClient::allow($pdo, $feature);
        if (!$ok && $mode !== 'preview') throw new RuntimeException($why);
        $fc = AiClient::feature($pdo, $feature);
        $saving = $mode === 'write';
        if ($saving) $pdo->prepare("UPDATE place_guides SET draft_status = 'writing', draft_at = NOW() WHERE place_key = ?")->execute([$key]);
        @set_time_limit(240); @ignore_user_abort(true);
        $g = self::get($pdo, $key);
        if (!$g['elevation_ft'] && $p['lat'] !== null) {   // the elevation from the weather service's forecast for the place, before Claude is asked
            require_once __DIR__ . '/Weather.php';
            try { $w = Weather::stored($pdo, (float) $p['lat'], (float) $p['lon']); if (empty($w['elev_ft'])) $w = Weather::at($pdo, (float) $p['lat'], (float) $p['lon'], true); } catch (Throwable) { $w = null; }
            if (!empty($w['elev_ft'])) { $g['elevation_ft'] = (int) $w['elev_ft']; if ($saving) $pdo->prepare('UPDATE place_guides SET elevation_ft = ? WHERE place_key = ? AND elevation_ft IS NULL')->execute([$g['elevation_ft'], $key]); }
        }
        $written = array_filter($g['sections'], fn ($t) => trim((string) $t) !== ''); $mine = [];
        if ($rewrite) {   // Claude's own sections, still exactly as it wrote them, are written again; anything a person touched stays
            $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: [];
            $was = (array) ($di['hash'] ?? []);
            if (!$was) foreach (self::SECTIONS as $k => [$label]) if (in_array($label, (array) ($di['added'] ?? []), true) && isset($written[$k])) $was[$k] = md5(trim((string) $written[$k]));   // a draft from before hashes were kept: the sections it says it wrote
            foreach ($written as $k => $t) if (isset($was[$k]) && $was[$k] === md5(trim((string) $t))) { $mine[$k] = $t; unset($written[$k]); }
        }
        $tpl = self::template($pdo); $tw = (array) ($tpl['write'] ?? []);   // the Place guide template (System Configuration → Content templates)
        $todo = []; $pass = [];
        foreach (self::templateSections($tpl) as $k => $sx) if ($sx['written'] && !isset($written[$k])) { $todo[$k] = $sx['heading'] . ': ' . $sx['instruction']; $pass[$k] = $sx['pass'] !== '' ? $sx['pass'] : 'practical'; }
        if (!$todo) { if ($saving) $pdo->prepare("UPDATE place_guides SET draft_status = 'done' WHERE place_key = ?")->execute([$key]); return ['say' => 'Every section is written already: nothing for Claude to add.', 'passes' => [], 'sections' => [], 'cut' => [], 'check' => [], 'confidence' => 0, 'micros' => 0, 'added' => [], 'estimate' => [0.0, 0.0], 'model' => $fc['model'], 'research_held' => false]; }
        // what we have, for Claude to write from (and to name only what's real)
        $list = fn (array $rows) => implode('; ', array_map(fn ($r) => $r['name'] . ' (' . trim(preg_replace('/\s*\([^)]*$/', '', (string) ($r['category'] ?? $r['fclass'] ?? $r['type'] ?? ''))) . (!empty($r['city']) ? ', ' . $r['city'] : '') . (isset($r['miles']) && $r['miles'] !== null ? ', ' . round((float) $r['miles']) . ' mi' : '') . ')', $rows));
        $ctx = ['Place: ' . $p['name'] . ($p['state'] ? ', ' . $p['state'] : '') . ' (' . $p['kind'] . ')',
                'Within: ' . implode(' < ', array_map(fn ($c) => $c['name'], array_slice(self::chain($pdo, $key), 1)))];
        if ($g['elevation_ft']) $ctx[] = 'Elevation: ' . (int) $g['elevation_ft'] . ' ft';
        foreach (['eat' => 'Places to eat and drink', 'stay' => 'Places to stay', 'do' => 'Things to do', 'shop' => 'Shops'] as $sec => $label) {
            $rows = self::picks($pdo, $p, $sec, 14, 'v'); if ($rows) $ctx[] = $label . ' we list: ' . $list($rows);
        }
        $lm = self::landmarks($pdo, $p, 12); if ($lm) $ctx[] = 'Landmarks we list: ' . $list($lm);
        if (is_file(__DIR__ . '/crawler/RecBulk.php') && $p['lat'] !== null) { require_once __DIR__ . '/crawler/RecBulk.php'; try { $rec = RecBulk::near($pdo, [[$p['lat'], $p['lon']]], 30, 12); if ($rec) $ctx[] = 'Outdoor places we list: ' . $list($rec); } catch (Throwable) {} }
        $kids = self::children($pdo, $p); if ($kids) $ctx[] = 'Places within it: ' . implode(', ', array_map(fn ($k) => $k[1], $kids));
        foreach ($written as $k => $t) $ctx[] = 'Already written (' . self::SECTIONS[$k][0] . ', keep consistent, don\'t repeat): ' . mb_substr((string) $t, 0, 1200);
        $ground = self::groundTruth($pdo, $p, $g);   // boots on the ground, history we hold, and what visitors look for here
        require_once __DIR__ . '/Dossier.php';   // what our crawler gathered for free (Wikipedia, Wikidata, the official site, our landmarks), so Claude searches only for the gaps
        try { [$dos, $dosSrc] = Dossier::forPlace($pdo, $p); } catch (Throwable $x) { error_log('dossier ' . $key . ': ' . $x->getMessage()); [$dos, $dosSrc] = ['', []]; }
        if (!$g['elevation_ft'] && !empty(($fx = Dossier::facts($pdo, $key))['elevation_ft'])) { $g['elevation_ft'] = (int) $fx['elevation_ft']; if ($saving) $pdo->prepare('UPDATE place_guides SET elevation_ft = ? WHERE place_key = ? AND elevation_ft IS NULL')->execute([$g['elevation_ft'], $key]); }
        try { [$res, $resSrc] = Dossier::research($pdo, $p, $dos, false, $mode !== 'preview' && !self::$firstLook); }   /* a preview spends nothing: the brief only if one is held */ catch (Throwable $x) { error_log('research ' . $key . ': ' . $x->getMessage()); [$res, $resSrc] = ['', []]; }
        $cat = '';   // the heritage catalog (decisions/0133): vetted facts, tiered by the law of the place
        try { require_once __DIR__ . '/Heritage.php'; $cat = Heritage::forGuide($pdo, $key); } catch (Throwable $x) { error_log('heritage for guide ' . $key . ': ' . $x->getMessage()); }
        $fmtLink = ''; $fmtOther = [];   // the template's formatting: how names are written goes with the linking rule; the rest are rules of their own
        foreach ((array) ($tw['format'] ?? []) as $f) { $f = trim((string) $f); if ($f === '') continue; if (str_contains($f, '**bold**')) $fmtLink = trim($fmtLink . ' ' . $f); else $fmtOther[] = $f; }
        $base = "You are writing the " . $p['kind'] . " for " . $p['name'] . ($p['state'] ? ', ' . $p['state'] : '') . " on Traversence, a regional travel guide and local directory. "
            . "It's published as you write it, so everything you say must be true and supported (by the notes, the research brief, our lists or pages you cite).\n\n"
            . self::fill((string) ($tw['purpose'] ?? ''), $p) . "\n\n"
            . self::fill((string) ($tw['trust'] ?? ''), $p) . "\n\n"
            . ($ground !== '' ? $ground . "\n\n" : '')
            . ($res !== '' ? "RESEARCH BRIEF:\n" . mb_substr($res, 0, 24000) . "\n\n" : '')
            . ($cat !== '' ? "HERITAGE CATALOG (vetted facts about the place's past and land, each from a primary record or two independent sources; where marked, where a visitor can stand today. A fact marked STORY ONLY is told but never located: no place name that leads there, no directions):\n" . mb_substr($cat, 0, 12000) . "\n\n" : '')
            . ($dos !== '' ? "DOSSIER (Wikipedia, Wikidata, the official website and our records; facts only, never copy wording):\n" . mb_substr($dos, 0, $res !== '' ? 8000 : 16000) . "\n\n" : '')
            . ($res === '' ? "RESEARCH: there's no research brief yet, so use web search to learn the place's history, culture, events and what it's like to be there before you write.\n\n" : "Use web search only to fill a gap the brief leaves (a current event date, whether a place is open).\n\n")
            . self::fill((string) ($tw['voice'] ?? ''), $p) . "\n\n"
            . "RULES:\n"
            . "- Our lists below are for linking, not a checklist: name the places worth a visitor's or a resident's time, never filler (a chain store, a generic area name)." . ($fmtLink !== '' ? ' ' . $fmtLink : '') . "\n"
            . "- Name a place only if it's in our lists, in the brief, or confirmed on a page you cite. Never invent phone numbers, hours, prices or dates; say 'about' for drive times and 'usually' for a festival's month when the brief says so.\n"
            . "- The guide speaks about the place, never about our research: never mention our dossier, brief, lists or sources, Wikipedia or Wikidata, a website being down, or what you couldn't confirm. Those go in the notes for our team.\n"
            . "- Tribal nations: use the nation's own name and say visitors follow the nation's rules.\n"
            . "- Protected places (sacred, burial or archaeological: rock art, ruins, kivas, graves, a cemetery on a nation's land or of its peoples) have three levels. PUBLIC: its managing authority invites visitors (a state park's ruins tour, a museum, a town's public cemetery): name it, tell its story and say how to get there like any place. "
            . "KNOWN, NOT OPEN: a public source you cite names it, but it isn't open to visitors: name it and tell its story as the source does, never how to reach it (no directions, distances, roads, trailheads or coordinates), and say it may be visited only with the authorization of the nation or the land's managers. "
            . "HELD: anything else: never name or locate it; you may say in general that the area holds places sacred to the nation (by its own name) that aren't open without its permission.\n"
            . ($avoid ? "- Leave these names out entirely: " . implode('; ', $avoid) . ".\n" : '')
            . implode('', array_map(fn ($f) => '- ' . $f . "\n", $fmtOther))
            . "- Also give the elevation in feet if you can confirm it (0 if not), every page you used, short notes for our team on anything to check later, and your honest confidence (0-100) that everything you wrote is accurate and supported.\n\n"
            . implode("\n", $ctx);
        require_once __DIR__ . '/AiClient.php';
        // passes, so each section has room (the template's: the story of the place, then the practical sections)
        $byPass = []; foreach ($todo as $k => $v) $byPass[$pass[$k]][$k] = $v;
        $order = array_values(array_unique(array_merge(['story', 'practical'], array_keys($byPass))));
        $groups = array_values(array_filter(array_map(fn ($ps) => $byPass[$ps] ?? [], $order)));
        $maxTok = max(2000, min(self::$firstLook ? 6000 : 32000, (int) ($tw['max_tokens'] ?? 16000))); $withBrief = max(0, (int) ($tpl['gather']['searches_with_brief'] ?? 2));
        if ($mode === 'preview') return self::previewOf($pdo, $p, $base, $groups, $res !== '' ? min($withBrief, $fc['searches']) : $fc['searches'], $maxTok, (string) $fc['model'], $res !== '', $ok ? '' : $why);
        $d = ['sections' => [], 'elevation_ft' => 0, 'sources' => [], 'check' => [], 'confidence' => 100]; $r = ['searches' => 0, 'search_error' => '']; $micros = 0;
        foreach ($groups as $gi => $grp) {
            $schemaSec = []; foreach ($grp as $k => $_) $schemaSec[$k] = ['type' => 'string'];
            $prompt = $base . "\n\nWRITE THESE SECTIONS NOW (each one full: several paragraphs, or a well-told list, as the section needs; leave one empty only if there's truly nothing reliable to say):\n- "
                . implode("\n- ", array_map(fn ($k, $v) => "$k: $v", array_keys($grp), $grp))
                . ($gi > 0 && $d['sections'] ? "\n\nALREADY WRITTEN FOR THIS GUIDE (keep consistent, don't repeat):\n" . implode("\n\n", array_map(fn ($k, $t) => (self::templateSections($tpl)[$k]['heading'] ?? self::SECTIONS[$k][0]) . ":\n" . mb_substr((string) $t, 0, 1500), array_keys($d['sections']), $d['sections'])) : '');
            $schema = ['type' => 'object', 'additionalProperties' => false, 'required' => ['sections', 'elevation_ft', 'sources', 'check', 'confidence'],
                       'properties' => ['sections' => ['type' => 'object', 'additionalProperties' => false, 'required' => array_keys($schemaSec), 'properties' => $schemaSec],
                                        'elevation_ft' => ['type' => 'integer'], 'sources' => ['type' => 'array', 'items' => ['type' => 'string']], 'check' => ['type' => 'array', 'items' => ['type' => 'string']], 'confidence' => ['type' => 'integer']]];
            try {
                $one = AiClient::claudeAsk(mb_substr($prompt, 0, 60000), $schema, $fc['model'], $res !== '' ? min($withBrief, $fc['searches']) : $fc['searches'], $maxTok, self::$firstLook ? 'low' : 'medium');
            } catch (Throwable $e) {
                if ($saving) self::draftFailed($pdo, $key, $e->getMessage(), $micros, $gi);
                throw $e;
            }
            AiClient::record($pdo, $feature, 0, 'done', $one); $micros += (int) ($one['micros'] ?? 0);
            $od = (array) ($one['data'] ?? []);
            $d['sections'] += (array) ($od['sections'] ?? []);
            $d['sources'] = array_merge($d['sources'], (array) ($od['sources'] ?? [])); $d['check'] = array_merge($d['check'], (array) ($od['check'] ?? []));
            $d['confidence'] = min($d['confidence'], (int) ($od['confidence'] ?? 0)); if (!$d['elevation_ft']) $d['elevation_ft'] = (int) ($od['elevation_ft'] ?? 0);
            $r['searches'] += (int) ($one['searches'] ?? 0); if ((string) ($one['search_error'] ?? '') !== '') $r['search_error'] = (string) $one['search_error'];
        }
        if (!$groups) $d['confidence'] = 0;
        $dosSrc = array_merge($resSrc, $dosSrc);
        $sec = $written; $added = [];
        foreach ((array) ($d['sections'] ?? []) as $k => $t) { $t = trim((string) $t); if (isset($todo[$k]) && $t !== '') { $sec[$k] = mb_substr($t, 0, 12000); $added[] = self::templateSections($tpl)[$k]['heading'] ?? self::SECTIONS[$k][0]; } }
        // a place that may be sacred or protected is named only when a public source already publishes it (Jason, 2026-10-30:
        // "if a source publishes something we can too"): the dossier, and the pages Claude cites, read by our crawler
        $ev = static function () use ($dos, $d): string { static $t = null; if ($t === null) { $t = $dos; foreach (array_slice((array) ($d['sources'] ?? []), 0, 5) as $u) $t .= "\n" . Dossier::pageText((string) $u); } return $t; };
        require_once __DIR__ . '/Landmarks.php'; Landmarks::loadPeoples($pdo);   // a cemetery of a nation's peoples is protected
        [$sec, $cut, $pub] = self::scrub($sec, array_keys($todo), $ev);   // never a word to visitors about our sources or a broken website
        if ($cut) $d['check'] = array_merge((array) ($d['check'] ?? []), array_map(fn ($c) => 'Taken out of the guide: "' . mb_strimwidth($c, 0, 160, '…') . '"', $cut));
        foreach ($mine as $k => $t) if (!isset($sec[$k])) $sec[$k] = $t;   // a section Claude had nothing new for keeps what it wrote before
        if ($mode === 'try') return ['say' => $added ? 'Claude wrote ' . implode(', ', $added) . '.' : 'Claude found nothing reliable to add.', 'sections' => array_intersect_key($sec, $todo), 'cut' => $cut,
                                     'check' => array_slice(array_values(array_filter(array_map('strval', (array) ($d['check'] ?? [])))), 0, 12), 'confidence' => max(0, min(100, (int) ($d['confidence'] ?? 0))), 'micros' => $micros, 'added' => $added];
        $elev = $g['elevation_ft'] ?: ((int) ($d['elevation_ft'] ?? 0) > 0 ? (int) $d['elevation_ft'] : null);
        // a section a person saved while Claude was writing is theirs: it stays, and isn't marked as Claude's (review B8)
        [$sec, $theirs, $nowInfo] = self::keepNewer($pdo, $key, $g['sections'], $sec);
        foreach ($theirs as $k) $written[$k] = $sec[$k] ?? '';
        if ($theirs) $added = array_values(array_diff($added, array_map(fn ($k) => self::templateSections($tpl)[$k]['heading'] ?? self::SECTIONS[$k][0] ?? $k, $theirs)));
        $hash = []; foreach ($sec as $k => $t) if (!isset($written[$k])) $hash[$k] = md5(trim((string) $t));   // to know later which sections are still Claude's own
        $old = $nowInfo ?? (json_decode((string) ($g['draft_info'] ?? ''), true) ?: []);   // as it is now: a "kept down" set while writing holds
        $info = ['at' => date('c'), 'added' => $added, 'hash' => $hash, 'searches' => (int) ($r['searches'] ?? 0), 'search_error' => (string) ($r['search_error'] ?? ''),
                 'sources' => array_slice(array_values(array_unique(array_filter(array_map('strval', array_merge($dosSrc, (array) ($d['sources'] ?? [])))))), 0, 30), 'dossier' => $dos !== '', 'research' => $res !== '',
                 'published' => array_values(array_unique(array_merge((array) ($old['published'] ?? []), $pub))), 'ground' => $ground !== '', 'confidence' => max(0, min(100, (int) ($d['confidence'] ?? 0))), 'v' => self::DRAFT_V,
                 'check' => array_slice(array_values(array_filter(array_map('strval', (array) ($d['check'] ?? [])))), 0, 12)] + array_intersect_key($old, ['kept' => 1, 'auto_published' => 1, 'first_look' => 1]);   // a guide our team took down stays down; one that went live by itself keeps answering to its score
        $pdo->prepare("UPDATE place_guides SET sections = ?, elevation_ft = ?, draft_status = 'done', draft_at = NOW(), draft_info = ?, updated_at = NOW() WHERE place_key = ?")
            ->execute([json_encode($sec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $elev, json_encode($info, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
        require_once __DIR__ . '/GuideLinks.php';
        $s = GuideLinks::scan($pdo, $p, $sec);   // its names matched, the ones we don't have sent to Find it
        self::forget($pdo, $key);
        if (!$added) return ['say' => 'Claude found nothing reliable to add.'];
        $say = 'Claude drafted ' . implode(', ', $added) . '. ' . $s['linked'] . ' of ' . $s['names'] . ' names linked' . ($s['queued'] ? ', ' . $s['queued'] . ' sent to Find it' : '') . '.';
        $block = GuideLinks::blocking($pdo, $key);
        if ($block && !$avoid) return ['say' => self::writeDraft($pdo, $key, true, $feature, $block)];   // a held or closed name: written once more without it
        return ['say' => $say . ' ' . self::autoPublish($pdo, $key)];
    }

    /**
     * A preview's answer: each pass's prompt as it would be sent (a later pass also gets what the first wrote, which a
     * preview can't know), and what it would cost: tokens in from the prompt's length, out from the sections asked for,
     * each web search about 1¢; the upper figure if every search allowed is used. A brief not held yet adds its own cost.
     */
    private static function previewOf(PDO $pdo, array $p, string $base, array $groups, int $searches, int $maxTok, string $model, bool $held, string $blocked): array
    {
        $passes = []; $usd = 0.0; $max = 0.0;
        foreach ($groups as $grp) {
            $prompt = mb_substr($base . "\n\nWRITE THESE SECTIONS NOW (each one full: several paragraphs, or a well-told list, as the section needs; leave one empty only if there's truly nothing reliable to say):\n- "
                . implode("\n- ", array_map(fn ($k, $v) => "$k: $v", array_keys($grp), $grp)), 0, 60000);
            $in = (int) ceil(mb_strlen($prompt) / 3.6); $out = min($maxTok, 1100 * count($grp));
            $c = AiClient::estimate($model, $in, $out, 0); $cMax = AiClient::estimate($model, $in + 2500 * $searches, $maxTok, $searches);   // searches bring their pages in
            $usd += $c; $max += $cMax;
            $passes[] = ['sections' => array_keys($grp), 'prompt' => $prompt, 'searches' => $searches, 'max_tokens' => $maxTok, 'in' => $in, 'out' => $out, 'usd' => $c, 'usd_max' => $cMax];
        }
        $brief = 0.0;
        if (!$held) { $rf = AiClient::feature($pdo, 'guide_research'); $brief = AiClient::estimate((string) $rf['model'], 9000, 4500, max(2, (int) $rf['searches'])); }   // the brief would be written first
        return ['say' => '', 'passes' => $passes, 'model' => $model, 'research_held' => $held, 'brief_usd' => $brief, 'estimate' => [$usd + $brief, $max + $brief], 'blocked' => $blocked];
    }

    /** Claude's guides written before the current rules are written again by the guide job (2: the dead-website fix). */
    public const DRAFT_V = 4;   // 3: the research brief and the immersive brief (Jason, 2026-10-30); 4: Walking in the footsteps, from the heritage catalog

    /**
     * Takes out of Claude's sections any sentence that talks about our research instead of the place: our dossier, lists
     * or sources, Wikipedia or Wikidata, a website that's down, suspended or out of date; and any naming what may be a sacred,
     * burial or protected site (rock art, ruins, graves: Landmarks::SENSITIVE) unless a public source already publishes it:
     * $evidence gives the published text (the dossier and the pages Claude cites), read only when such a sentence comes up.
     * Returns [sections, what was cut, the protected-sounding names kept because a source publishes them].
     */
    /** How to get somewhere: never said of a sacred, burial or archaeological place (decisions/0133: tell the story, never the way in). */
    public const WAY_IN = '/\b(\d+(\.\d+)?\s*(miles?|mi|km|kilomet\w+|feet|ft|yards?)\b|(north|south|east|west|northeast|northwest|southeast|southwest)\s+of\b|turn(\s+(left|right))?\s+(on|onto|at)|trailhead|park(ing)?\s+(at|in|area|lot)|pull-?off|dirt road|forest road|FR\s*\d+|county road|CR\s*\d+|gps|coordinates?|\d{1,3}\.\d{3,},?\s*-?\d{1,3}\.\d{3,}|mile marker|milepost|hike\s+(to|in)|scramble|climb\s+(up\s+)?to|follow\s+the\s+(wash|trail|road|fence)|access(ed)?\s+(from|via|by)|how to (get|find)|located\s+(at|on|off|near))\b/i';
    /** An access point the managing authority offers publicly (a state park's rock-art tour) may be named. */
    public const PUBLIC_ACCESS = '/\b(ranger-?led|guided tours?|tours? (leave|run|start|depart)|visitor cent(er|re)|state park|national (park|monument)|museum|open to the public|interpretive (trail|site))\b/i';

    /** Where one sentence ends and the next begins: never after St., Mt., Ft., Dr., Mr., Mrs. or No. ("St. Johns" is one name). */
    public const SENTENCE = '/(?<!\bSt\.)(?<!\bMt\.)(?<!\bFt\.)(?<!\bDr\.)(?<!\bMr\.)(?<!\bMrs\.)(?<!\bNo\.)(?<=[.!?])\s+(?=[A-Z*"(])/';

    /** Said wherever a guide tells of a protected place that isn't open to visitors, when the guide doesn't say it already. */
    public const AUTH_LINE = 'Places like these may be visited only with the authorization of the nation or the land\'s managers; follow their rules, look and don\'t touch.';
    /** Words that already say a visit needs someone's permission. */
    public const ASKS = '/\b(authori[sz]\w*|permission|permits?|not open to (visitors|the public)|closed to (visitors|the public))\b/i';

    /**
     * A general acknowledgement of protected places we hold (the third level): it names none, says nothing of the way in,
     * and says a visit needs permission. "The mesas hold places sacred to the Zuni people; they aren't open without the
     * Pueblo's permission" is one; "Rattlesnake Ruins are sacred" names a place and isn't.
     */
    public static function acknowledges(string $sent): bool
    {
        if (str_contains($sent, '**') || preg_match(self::WAY_IN, $sent) || !preg_match(self::ASKS, $sent)) return false;
        $words = substr(Landmarks::SENSITIVE, 4, strrpos(Landmarks::SENSITIVE, ')') - 4);
        $sent = trim($sent);
        if (preg_match('/(?<!^)\b[A-Z][\w\'’-]*\s+(?i:' . $words . ')\b/u', $sent)) return false;   // "Concho Ruins": a capitalized word before it, not at the start
        if (preg_match('/(?<!^)\b(?:' . implode('|', array_map('ucfirst', explode('|', $words))) . ')\b/u', $sent)) return false;    // "… the Ruins …": the word itself capitalized mid-sentence
        if (preg_match('/\b(?i:' . $words . ')\s+(?:at|near|on|in|of|called|named|known as)\s+(?:the\s+)?[A-Z]/u', $sent)) return false;   // "ruins at Kinishba"
        return true;
    }

    public static function scrub(array $sec, array $keys, ?callable $evidence = null): array
    {
        require_once __DIR__ . '/Landmarks.php';   // and never a place that may be sacred, burial or protected (decisions/0066)
        $rx = '/\b(dossier|wikidata|wikipedia|our (lists?|records|sources|data)|(web)?site(\s+address)?\s+(\([^)]*\)\s+)?(is|was|has been|appears|seems)\s+(currently\s+)?(down|suspended|offline|broken|unavailable|out of date|outdated|not working|defunct)|suspended|could ?n.t (be )?(confirm|verif)|unable to (confirm|verify)|as of (my|our) (research|sources)|I (have ?n.t|have not|did ?n.t|did not|could ?n.t|could not|can.?t|cannot|was unable|was n.t able)|I (found|checked|searched|looked up|confirmed|verified)|n.t (been )?(confirmed|verified)|not (yet )?(been )?(confirmed|verified))\b/i';   // Claude speaking of itself or its checking, as in "I haven't confirmed drive times", is kept from visitors
        $cut = []; $pub = [];
        foreach ($keys as $k) {
            if (!isset($sec[$k])) continue;
            $lines = []; $askFirst = false;
            foreach (preg_split('/\n/', (string) $sec[$k]) as $line) {
                $keep = [];
                foreach (preg_split(self::SENTENCE, $line) as $sent) { if (preg_match($rx, $sent)) $cut[] = trim($sent);
                    elseif (Landmarks::isProtected($sent)) {   // a town's public cemetery is a public place like any other (the three levels)
                        if (self::acknowledges($sent)) { $keep[] = $sent; continue; }   // held, acknowledged in general: that sacred places are there and whose permission they need
                        $n = $evidence ? self::publishedIn($sent, $evidence()) : null;
                        if ($n === null) $cut[] = trim($sent);   // held: no public source presents it
                        elseif (preg_match(self::PUBLIC_ACCESS, $sent)) { $keep[] = $sent; $pub = array_merge($pub, $n); }   // public: its managing authority invites visitors
                        elseif (preg_match(self::WAY_IN, $sent)) $cut[] = trim($sent);   // known, not open: the story, never the way in
                        else { $keep[] = $sent; $pub = array_merge($pub, $n); $askFirst = true; }
                    }
                    else $keep[] = $sent; }
                $l = trim(implode(' ', $keep));
                if ($l !== '' && !preg_match('/^(-|##)\s*$/', $l)) $lines[] = $l; elseif (trim($line) === '') $lines[] = '';
            }
            $t = trim((string) preg_replace('/\n{3,}/', "\n\n", implode("\n", $lines)));
            if ($t !== '' && $askFirst && !preg_match(self::ASKS, $t)) $t .= "\n\n" . self::AUTH_LINE;   // a place known but not open: whose authorization it needs
            if ($t === '') unset($sec[$k]); else $sec[$k] = $t;
        }
        return [$sec, $cut, array_values(array_unique($pub))];
    }

    /**
     * Is what this sentence names published by the evidence? Every name in it (its **bold** names, and the capitalized name
     * around a protected-sounding word, else the word itself) must be found there. The names, or null when one isn't.
     */
    public static function publishedIn(string $sent, string $evidence): ?array
    {
        $norm = fn ($x) => ' ' . trim((string) preg_replace('/[^a-z0-9]+/', ' ', strtolower((string) $x))) . ' ';
        $ev = $norm($evidence);
        if (trim($ev) === '') return null;
        preg_match_all('/\*\*([^*]+)\*\*/', $sent, $b); $names = $b[1]; $kinds = [];
        $plain = str_replace('**', '', $sent);
        if (preg_match_all('/(?:[A-Z][\w\'’.-]*\s+){0,5}(?i:' . substr(Landmarks::SENSITIVE, 4, strrpos(Landmarks::SENSITIVE, ')') - 4) . ')(?:\s+[A-Z][\w\'’.-]*){0,3}/u', $plain, $m))
            foreach ($m[0] as $x) { $x = trim($x); if (preg_match('/^(?i:' . substr(Landmarks::SENSITIVE, 4, strrpos(Landmarks::SENSITIVE, ')') - 4) . ')$/u', $x)) $kinds[] = $x; else $names[] = $x; }   // a bare kind ("petroglyphs") counts only when nothing is named
        if (!$names) $names = $kinds;
        if (!$names) return null;
        foreach ($names as $n) if (!str_contains($ev, $norm($n))) return null;
        return array_values(array_filter($names, fn ($n) => (bool) preg_match(Landmarks::SENSITIVE, $n)));
    }

    /**
     * How sure we are of Claude's guide, 0-100, and what made it: Claude's own confidence (up to 30), the crawler's
     * dossier (15), the research brief (10), notes from the ground (10), its sources (up to 10), and how many of its names link (up to 25; a name
     * still being found counts against it), less 4 for each thing Claude says to check (up to 16) and 10 when its web
     * search was refused. Worked out each time, so a guide's score rises as Find it links its names.
     */
    public static function score(PDO $pdo, string $key, ?array $di = null): array
    {
        if ($di === null) $di = json_decode((string) (self::get($pdo, $key)['draft_info'] ?? ''), true) ?: [];
        require_once __DIR__ . '/GuideLinks.php';
        $linked = 0; $open = 0;
        foreach (GuideLinks::mentions($pdo, $key) as $m) { if (in_array($m['status'], ['linked', 'thin'], true)) $linked++; elseif (in_array($m['status'], GuideLinks::WAITING, true)) $open++; }
        $parts = ['Claude\'s own confidence' => (int) round(0.30 * (int) ($di['confidence'] ?? 0)), 'the crawler\'s dossier' => !empty($di['dossier']) ? 15 : 0, 'the research brief' => !empty($di['research']) ? 10 : 0,
                  'notes from the ground' => !empty($di['ground']) ? 10 : 0, 'its sources' => min(10, 2 * count((array) ($di['sources'] ?? []))),
                  'names linked' => $linked + $open ? (int) round(25 * $linked / ($linked + $open)) : 15,
                  'things to check' => -4 * min(4, count((array) ($di['check'] ?? []))), 'web search refused' => ($di['search_error'] ?? '') !== '' ? -10 : 0];
        return [max(0, min(100, array_sum($parts))), array_filter($parts)];
    }

    /** Does Claude's guide go live by itself (System Configuration → AI use; on unless switched off)? */
    public static function publishesItself(PDO $pdo): bool
    {
        require_once __DIR__ . '/AiClient.php';
        return AiClient::feature($pdo, 'guide_publish')['enabled'];
    }

    /**
     * Jason (2026-10-30): the crawler and Claude compile the guide and it goes live by itself; our team edits or takes it
     * down later. It waits only for a name that may mark a protected site or a closed business, and for a guide our team
     * took down. Names we don't have yet stay plain text until Find it links them. Returns what to say.
     */
    public static function autoPublish(PDO $pdo, string $key): string
    {
        $g = self::get($pdo, $key);
        $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: [];
        if ($g['status'] === 'live') {   // a guide that went live by itself stays live only while its score holds; one a person published stays
            if (empty($di['auto_published']) || !array_key_exists('confidence', $di)) return 'It\'s live with the changes.';
            [$score] = self::score($pdo, $key, $di); $min = AiClient::feature($pdo, 'guide_publish')['per_day'];
            if ($score >= $min) return 'It\'s live with the changes (confidence score ' . $score . ').';
            unset($di['auto_published']);
            $pdo->prepare("UPDATE place_guides SET status = 'draft', draft_info = ? WHERE place_key = ?")->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
            self::forget($pdo, $key);
            return 'Its confidence score is now ' . $score . ', under the ' . $min . ' it needs, so it\'s back to a draft until a person publishes it or Find it raises the score.';
        }
        if (!self::publishesItself($pdo) || !empty($di['kept'])) return 'It\'s a draft: read it through, then publish.';
        require_once __DIR__ . '/Jurisdictions.php';
        $pl = self::place($pdo, $key);
        if ($pl && ($why = Jurisdictions::closedWhy($pdo, (string) ($pl['state'] ?? '')))) return 'It waits as a draft: ' . $why;
        require_once __DIR__ . '/GuideLinks.php';
        if ($block = GuideLinks::blocking($pdo, $key)) return 'It waits as a draft for: ' . implode(', ', array_slice($block, 0, 6)) . '.';
        [$score] = self::score($pdo, $key, $di); $min = AiClient::feature($pdo, 'guide_publish')['per_day'];
        if ($score < $min) return 'Its confidence score is ' . $score . ', under the ' . $min . ' it needs to go live by itself: it waits as a draft for a person.';
        $di['auto_published'] = date('c'); $di['score'] = $score;
        $pdo->prepare("UPDATE place_guides SET status = 'live', published_at = COALESCE(published_at, NOW()), linked_at = NOW(), draft_info = ? WHERE place_key = ?")
            ->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
        self::forget($pdo, $key);
        return 'It\'s live: edit it or take it down any time.';
    }

    public static function unpublish(PDO $pdo, string $key): void
    {
        $g = self::get($pdo, $key);   // taken down by our team: it stays down until someone publishes it
        $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: []; $di['kept'] = date('c');
        $pdo->prepare("UPDATE place_guides SET status = 'draft', draft_info = ? WHERE place_key = ?")->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
        self::forget($pdo, $key);
    }

    /** Pages built from a guide are kept for a while; a change clears them. */
    public static function forget(PDO $pdo, string $key): void
    {
        require_once __DIR__ . '/PageCache.php';
        PageCache::forget($pdo, 'guides:picks:' . $key . ':');
        PageCache::forget($pdo, 'guides:kids:' . $key);
    }

    /**
     * Light formatting for written sections: paragraphs, "## " headings, "- " lists, **bold**; [[Name]] or a linked name
     * becomes its link (GuideLinks::linkify).
     */
    public static function html(PDO $pdo, string $key, string $section, string $text): string
    {
        require_once __DIR__ . '/GuideLinks.php';
        $out = '';
        foreach (preg_split("/\n\s*\n/", trim($text)) as $b) {
            $b = trim($b); if ($b === '') continue;
            $esc = fn (string $s) => GuideLinks::linkify($pdo, $key, $section, (string) preg_replace('/\*\*(.+?)\*\*/u', '<b>$1</b>', htmlspecialchars($s, ENT_QUOTES)));
            if (str_starts_with($b, '## ')) { $lines = explode("\n", $b); $out .= '<h3>' . $esc(substr(array_shift($lines), 3)) . '</h3>'; $b = trim(implode("\n", $lines)); if ($b === '') continue; }
            $lines = explode("\n", $b);
            if (count(array_filter($lines, fn ($l) => preg_match('/^\s*[-*•] /', $l))) === count($lines)) $out .= '<ul>' . implode('', array_map(fn ($l) => '<li>' . $esc((string) preg_replace('/^\s*[-*•] /', '', $l)) . '</li>', $lines)) . '</ul>';
            else $out .= '<p>' . implode('<br>', array_map($esc, $lines)) . '</p>';
        }
        return $out;
    }

    // ---- the Chameleon Filter's picks -----------------------------------------------------------------------------------

    /** Is it winter or summer here now (or by the weather: snow in the forecast is winter)? '' for spring and autumn. */
    public static function season(?array $weather = null): string
    {
        if ($weather && preg_match('/snow|blizzard|flurr/i', (string) ($weather['now']['text'] ?? '') . ' ' . (string) ($weather['periods'][0]['short'] ?? ''))) return 'winter';
        $m = (int) date('n');
        return in_array($m, [12, 1, 2, 3], true) ? 'winter' : (in_array($m, [6, 7, 8, 9], true) ? 'summer' : '');
    }

    /**
     * A section's listings for a place (decisions/0131 §3): the names the guide mentions and our pins first, then the
     * filter's choice by relevance (the section's categories), proximity (the tier's reach), kind of experience and the
     * season; hidden picks out; one per business name. $mode 'v' Visiting, 'l' Live here. Each: id, name, category, kind
     * (its group), city, address, phone, website, miles, lat, lon, pinned.
     */
    public static function picks(PDO $pdo, array $p, string $section, int $n = 6, string $mode = 'v', string $season = '', string $wx = ''): array
    {
        if (!isset(self::PICKS[$section]) || $p['level'] === 'hub') return [];
        require_once __DIR__ . '/PageCache.php';
        $wx = isset(self::WEATHER_LEAD[$wx]) ? $wx : '';
        $rows = PageCache::remember($pdo, 'guides:picks:' . $p['key'] . ':' . $section . ':' . $mode . ':' . $season . ':' . $wx, 1800, fn () => self::pickRows($pdo, $p, $section, $mode, $season, $wx));
        if ($wx === 'indoor' && $section === 'do' && is_array($rows)) {   // the indoor group first when the weather keeps people in; the writer's pins stay first within theirs
            $i = 0; $rows = array_map(function ($r) use (&$i) { $r['_i'] = $i++; return $r; }, $rows);
            usort($rows, fn ($a, $b) => [$a['kind'] === self::KINDS['do'][0][0], $a['_i']] <=> [$b['kind'] === self::KINDS['do'][0][0], $b['_i']]);
        }
        return array_slice($rows, 0, $n);
    }

    /** A listing marked closed (decisions/0072) is never a pick, pinned or not. */
    private const OPEN = "NOT EXISTS (SELECT 1 FROM entity_metadata cl WHERE cl.entity_id = e.id AND cl.meta_key = 'closed')";

    private static function pickRows(PDO $pdo, array $p, string $section, string $mode, string $season, string $wx = ''): array
    {
        [$top, $want, $not] = self::PICKS[$section];
        $where = ["e.entity_type = 'merchant'", 'e.is_suppressed = 0', "e.status IN ('unclaimed','claimed-unverified','pending-verification','verified')", '(c.parent_id = ' . (int) $top . ' OR c.id = ' . (int) $top . ')', self::OPEN];
        $a = [];
        if ($want !== '') { $where[] = 'c.name REGEXP ?'; $a[] = $want; }
        if ($not !== '') { $where[] = 'c.name NOT REGEXP ?'; $a[] = $not; }
        $reach = $section === 'care' && $p['level'] !== 'geo_hub' ? self::CARE_REACH : (self::REACH[$p['level']] ?? 0);
        $inPlace = $p['sql'];
        if ($reach > 0 && $p['lat'] !== null) {
            $dLat = $reach / 69; $dLon = $reach / max(1, 69 * cos(deg2rad($p['lat'])));
            $where[] = '(' . $inPlace . ' OR (e.latitude BETWEEN ' . ($p['lat'] - $dLat) . ' AND ' . ($p['lat'] + $dLat) . ' AND e.longitude BETWEEN ' . ($p['lon'] - $dLon) . ' AND ' . ($p['lon'] + $dLon) . '))';
        } else $where[] = $inPlace;
        $st = $pdo->prepare('SELECT e.id, e.name, e.status, e.trust_score, e.latitude, e.longitude, e.primary_zip, c.name AS category FROM entities e JOIN categories c ON c.id = e.category_id WHERE ' . implode(' AND ', $where) . ' LIMIT 400');
        $st->execute($a);
        $cands = $st->fetchAll(PDO::FETCH_ASSOC);
        // pins and hides (the editor), and the names the guide mentions in this section (pinned, in their order)
        $pins = []; $hide = [];
        try {
            $ps = $pdo->prepare('SELECT ref, mode, pos FROM guide_picks WHERE place_key = ? AND section = ? ORDER BY pos'); $ps->execute([$p['key'], $section]);
            foreach ($ps->fetchAll(PDO::FETCH_ASSOC) as $r) if (preg_match('/^entity:(\d+)$/', (string) $r['ref'], $m)) { if ($r['mode'] === 'hide') $hide[(int) $m[1]] = 1; else $pins[(int) $m[1]] = count($pins); }
            if ($section !== 'shop') {   // shopping has no written section of its own: only its pins (Things to do's names stay in Things to do)
                $ms = $pdo->prepare("SELECT ref FROM content_tags WHERE src = ? AND section = ? AND status IN ('linked','thin') AND ref LIKE 'entity:%' ORDER BY id"); $ms->execute(['guide:' . $p['key'], $section]);
                foreach ($ms->fetchAll(PDO::FETCH_COLUMN) as $ref) { $id = (int) substr((string) $ref, 7); if (!isset($pins[$id])) $pins[$id] = count($pins); }
            }
        } catch (Throwable) {}
        if ($pins) {   // a pinned listing outside the reach still shows (the writer chose it)
            $have = array_flip(array_map('intval', array_column($cands, 'id')));
            $missing = array_diff(array_keys($pins), array_keys($have));
            if ($missing) { $st = $pdo->query("SELECT e.id, e.name, e.status, e.trust_score, e.latitude, e.longitude, e.primary_zip, c.name AS category FROM entities e LEFT JOIN categories c ON c.id = e.category_id WHERE e.is_suppressed = 0 AND " . self::OPEN . " AND e.id IN (" . implode(',', array_map('intval', $missing)) . ')'); $cands = array_merge($cands, $st->fetchAll(PDO::FETCH_ASSOC)); }
        }
        $lead = $section === 'care' ? 'Hospital|Urgent|Emergenc|Medical Center' : ($season !== '' && $section === 'do' ? self::SEASON[$season] : '');
        $out = [];
        foreach ($cands as $r) {
            $id = (int) $r['id']; if (isset($hide[$id])) continue;
            $mi = ($p['lat'] !== null && $r['latitude'] !== null) ? self::miles((float) $p['lat'], (float) $p['lon'], (float) $r['latitude'], (float) $r['longitude']) : null;
            $score = (float) ($r['trust_score'] ?? 0) / 10 + ($r['status'] === 'verified' ? 3 : ($r['status'] === 'claimed-unverified' ? 1.5 : 0))
                   + ($lead !== '' && preg_match('/' . $lead . '/i', $r['category'] . ' ' . $r['name']) ? ($section === 'care' ? 8 : 4) : 0)
                   - ($mi !== null ? $mi / ($section === 'care' ? 15 : ($p['level'] === 'town' ? 3 : 8)) : 1)
                   + ($mode === 'l' && in_array($p['level'], ['town', 'sub'], true) && $mi !== null && $mi < 3 ? 1 : 0)
                   // the weather right now: indoor places forward when it keeps people in, outdoor ones on a fair day
                   + ($wx !== '' && in_array($section, ['do', 'shop'], true) && preg_match('/' . self::WEATHER_LEAD[$wx] . '/i', $r['category'] . ' ' . $r['name']) ? ($wx === 'indoor' ? 5 : 2) : 0)
                   - ($wx === 'indoor' && $section === 'do' && preg_match('/' . self::WEATHER_LEAD['outdoor'] . '/i', $r['category'] . ' ' . $r['name']) ? 3 : 0);
            $r['miles'] = $mi; $r['pinned'] = isset($pins[$id]); $r['score'] = $r['pinned'] ? 1000 - $pins[$id] : $score;
            $r['kind'] = self::kindOf($section, (string) $r['category'], (string) $r['name']);
            $out[] = $r;
        }
        usort($out, fn ($x, $y) => $y['score'] <=> $x['score']);
        $seen = []; $keep = [];   // one per business name ("American Legion" three times reads as a mistake)
        foreach ($out as $r) { $k = (string) preg_replace('/[^a-z0-9]+/', '', strtolower((string) $r['name'])); if (isset($seen[$k])) continue; $seen[$k] = 1; $keep[] = $r; if (count($keep) >= 24) break; }
        self::withMeta($pdo, $keep);
        return $keep;
    }

    public static function kindOf(string $section, string $category, string $name): string
    {
        foreach (self::KINDS[$section] ?? [] as [$label, $re]) if ($re === '' || preg_match('/' . $re . '/i', $category . ' ' . $name)) return $label;
        return '';
    }

    /** Adds city, address, phone and website to listing rows. */
    public static function withMeta(PDO $pdo, array &$rows): void
    {
        if (!$rows) return;
        $ids = array_map(fn ($r) => (int) $r['id'], $rows);
        $meta = [];
        foreach ($pdo->query("SELECT entity_id, meta_key, meta_value FROM entity_metadata WHERE entity_id IN (" . implode(',', $ids) . ") AND meta_key IN ('city','address','phone','website','state','hours','description')")->fetchAll(PDO::FETCH_ASSOC) as $m) {
            $v = json_decode((string) $m['meta_value'], true); $meta[(int) $m['entity_id']][$m['meta_key']] = is_string($v) ? $v : (is_scalar($m['meta_value']) && !is_array($v) ? (string) $m['meta_value'] : '');
        }
        foreach ($rows as &$r) { $mm = $meta[(int) $r['id']] ?? []; foreach (['city', 'address', 'phone', 'website', 'state', 'hours', 'description'] as $k) $r[$k] = trim((string) ($mm[$k] ?? '')); }
        unset($r);
    }

    /** Pin, hide or clear a listing in a section (the editor). */
    public static function setPick(PDO $pdo, string $key, string $section, string $ref, string $mode, int $uid): void
    {
        if (!preg_match('/^entity:\d+$/', $ref)) throw new RuntimeException('Pick a listing.');
        if ($mode === 'clear') $pdo->prepare('DELETE FROM guide_picks WHERE place_key = ? AND section = ? AND ref = ?')->execute([$key, $section, $ref]);
        else {
            $pos = (int) $pdo->query('SELECT COALESCE(MAX(pos), 0) + 1 FROM guide_picks WHERE place_key = ' . $pdo->quote($key) . ' AND section = ' . $pdo->quote($section))->fetchColumn();
            $pdo->prepare('INSERT INTO guide_picks (place_key, section, ref, mode, pos, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE mode = VALUES(mode), updated_by = VALUES(updated_by), updated_at = NOW()')
                ->execute([$key, $section, $ref, $mode === 'hide' ? 'hide' : 'pin', $pos, $uid]);
        }
        self::forget($pdo, $key);
    }

    public static function miles(float $la1, float $lo1, float $la2, float $lo2): float
    {
        $dLat = deg2rad($la2 - $la1); $dLon = deg2rad($lo2 - $lo1);
        $x = sin($dLat / 2) ** 2 + cos(deg2rad($la1)) * cos(deg2rad($la2)) * sin($dLon / 2) ** 2;
        return 2 * 3959 * asin(min(1, sqrt($x)));
    }

    /** Landmarks people can see, near the place (decisions/0066: visibleSql only). */
    public static function landmarks(PDO $pdo, array $p, int $n = 8): array
    {
        if ($p['lat'] === null || $p['level'] === 'hub') return [];
        require_once __DIR__ . '/Landmarks.php';
        $reach = ['geo_hub' => 60, 'cluster' => 25, 'town' => 12, 'sub' => 8][$p['level']] ?? 20;
        $dLat = $reach / 69; $dLon = $reach / max(1, 69 * cos(deg2rad($p['lat'])));
        try {
            $st = $pdo->prepare('SELECT gnis_id, name, fclass, near_town, lat, lon, wd_desc, image_url FROM landmarks WHERE ' . Landmarks::visibleSql() . ' AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? LIMIT 300');
            $st->execute([$p['lat'] - $dLat, $p['lat'] + $dLat, $p['lon'] - $dLon, $p['lon'] + $dLon]);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return []; }
        foreach ($rows as &$r) { $r['miles'] = self::miles($p['lat'], $p['lon'], (float) $r['lat'], (float) $r['lon']); $r['score'] = ($r['image_url'] ? 3 : 0) + ($r['wd_desc'] ? 2 : 0) - $r['miles'] / 6; }
        unset($r);
        usort($rows, fn ($a, $b) => $b['score'] <=> $a['score']);
        return array_slice($rows, 0, $n);
    }
}
