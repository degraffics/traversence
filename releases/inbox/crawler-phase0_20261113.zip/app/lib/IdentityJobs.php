<?php

declare(strict_types=1);

require_once __DIR__ . '/Identity.php';
require_once __DIR__ . '/CrawlerIngest.php';
require_once __DIR__ . '/PlaceScope.php';
require_once __DIR__ . '/crawler/ListingExtractor.php';
require_once __DIR__ . '/crawler/IntakeStager.php';
require_once __DIR__ . '/WebIdentity.php';

/**
 * The crawler's "build the identity" job (decisions/0062, step 4). Listings with no phone or website are queued; the
 * worker looks each one up in order (its own website, the NPI Registry, then web search) and sends back what it found,
 * each value with the page it's on and what that page matched (the name with the address, the phone, or both).
 *
 *   queue()     adds listings that have no way to reach them (topped up on its own when the queue runs low)
 *   lease()     the next few for the worker
 *   complete()  stores what it found as facts with their sources (added_by 0: the identity job, kept through rebuilds).
 *               A value confirmed by two independent websites, an official registry, a government page or the
 *               listing's own website goes on the listing when the listing has none. Since 2026-10-04 evidence wins on
 *               any listing nobody has claimed: Identity::recompute() applies the value with the most independent
 *               sources, one other website included, logged with Undo (Identity::applyEvidence); a claimed listing's
 *               owner is offered it instead. Google, Yelp and Facebook pages never give a value: they only confirm
 *               one, and are kept as links.
 *   look()      a person's "Look now": first in the queue
 */
final class IdentityJobs
{
    public const FINDS = ['phone', 'website', 'email', 'social', 'hours'];
    /** Hosts whose pages are evidence only (their terms don't allow copying): they confirm, and we keep the link. */
    public const EVIDENCE_ONLY = ['google.com', 'maps.google.com', 'g.page', 'yelp.com', 'facebook.com', 'm.facebook.com', 'instagram.com'];
    private const LEASE_MINUTES = 20;
    private const AGAIN_DAYS = 30;     // after a look that found nothing
    private const MAX_ATTEMPTS = 3;    // looks taken and not reported don't count (review B5); a look that keeps failing is set aside

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM ' . Database::t('identity_jobs') . ' LIMIT 1'); return $r = Identity::ready($pdo); } catch (Throwable) { return $r = false; }
    }

    /** Listings with no phone and no website on the listing itself, not looked up yet: queued. Returns how many. */
    public static function queue(PDO $pdo, int $limit = 300): int
    {
        if (!self::ready($pdo)) return 0;
        $pub = implode(',', array_map(fn ($s) => $pdo->quote($s), PlaceScope::PUBLIC_STATUSES));
        $st = $pdo->query("SELECT e.id, (SELECT COUNT(*) FROM entity_metadata a WHERE a.entity_id = e.id AND a.meta_key = 'address') AS has_addr
                             FROM entities e
                            WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ($pub)
                              AND NOT EXISTS (SELECT 1 FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key IN ('phone', 'website') AND m.meta_value NOT IN ('', '\"\"', 'null'))
                              AND NOT EXISTS (SELECT 1 FROM " . Database::t('identity_jobs') . " j WHERE j.record_kind = 'listing' AND j.record_id = e.id)
                            ORDER BY e.id DESC LIMIT " . max(1, min(2000, $limit)));
        $ins = $pdo->prepare("INSERT INTO " . Database::t('identity_jobs') . " (record_kind, record_id, need, status, priority, next_at) VALUES ('listing', ?, 'phone,website', 'queued', ?, NOW())");
        $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { try { $ins->execute([(int) $r['id'], (int) $r['has_addr'] ? 1 : 0]); $n++; } catch (PDOException) {} }
        return $n;
    }

    /**
     * Listings with a way to reach them but no website of their own (none, or only a Facebook or other social page):
     * queued to find it (decisions/0086). Unclaimed ones only (an owner adds their own); the ones Sales would call
     * first go first: being worked in Sales, or looked at in the last 30 days (3), the rest of the unclaimed (2). A
     * listing looked up before that still has no website of its own comes back after 30 days. Returns how many.
     */
    public static function queueWebsites(PDO $pdo, int $limit = 300): int
    {
        if (!self::ready($pdo)) return 0;
        $pub = implode(',', array_map(fn ($s) => $pdo->quote($s), PlaceScope::PUBLIC_STATUSES));
        $since = date('Y-m-d', strtotime('-30 days'));
        $hasProspects = true; try { $pdo->query('SELECT 1 FROM ' . Database::t('prospects') . ' LIMIT 0'); } catch (Throwable) { $hasProspects = false; }
        $st = $pdo->query("SELECT e.id, w.meta_value AS website, j.id AS job, j.status AS jstatus, j.updated_at AS jwhen,
                                  " . ($hasProspects ? '(SELECT COUNT(*) FROM ' . Database::t('prospects') . ' pr WHERE pr.entity_id = e.id)' : '0') . " AS worked,
                                  (SELECT COUNT(*) FROM platform_counts pc WHERE pc.metric = 'view' AND pc.k = CONCAT('listing:', e.id) AND pc.day >= '$since') AS viewed
                             FROM entities e
                             LEFT JOIN entity_metadata w ON w.entity_id = e.id AND w.meta_key = 'website'
                             LEFT JOIN " . Database::t('identity_jobs') . " j ON j.record_kind = 'listing' AND j.record_id = e.id
                            WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status = 'unclaimed' AND e.status IN ($pub)
                              AND (j.id IS NULL OR (j.status = 'done' AND j.updated_at < NOW() - INTERVAL " . self::AGAIN_DAYS . " DAY))
                            ORDER BY e.id DESC LIMIT " . max(1, min(5000, $limit * 4)));
        $ins = $pdo->prepare("INSERT INTO " . Database::t('identity_jobs') . " (record_kind, record_id, need, status, priority, next_at) VALUES ('listing', ?, 'website', 'queued', ?, NOW())");
        $again = $pdo->prepare("UPDATE " . Database::t('identity_jobs') . " SET status = 'queued', need = 'website', priority = ?, attempts = 0, next_at = NOW(), updated_at = NOW() WHERE id = ?");
        $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $w = json_decode((string) $r['website'], true); $w = is_string($w) ? $w : '';
            if ($w !== '' && WebIdentity::brand($w) !== '') continue;   // it has a website of its own
            $prio = ((int) $r['worked'] || (int) $r['viewed']) ? 3 : 2;
            try { $r['job'] ? $again->execute([$prio, (int) $r['job']]) : $ins->execute([(int) $r['id'], $prio]); $n++; } catch (PDOException) {}
            if ($n >= $limit) break;
        }
        return $n;
    }

    /** A person's "Look now": the listing goes first in the queue, whatever it found before. */
    public static function look(PDO $pdo, int $id): void
    {
        $up = $pdo->prepare("UPDATE " . Database::t('identity_jobs') . " SET status = 'queued', priority = 9, attempts = 0, next_at = NOW(), lease_until = NULL, updated_at = NOW() WHERE record_kind = 'listing' AND record_id = ?");
        $up->execute([$id]);
        if ($up->rowCount() === 0) $pdo->prepare("INSERT INTO " . Database::t('identity_jobs') . " (record_kind, record_id, need, status, priority, next_at) VALUES ('listing', ?, 'phone,website', 'queued', 9, NOW())")->execute([$id]);
    }

    /** The job for one listing, for its card: ['status', 'when', 'found_n', 'checked', 'note'] or null. */
    public static function of(PDO $pdo, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare("SELECT status, updated_at, next_at, found_n, checked, note FROM " . Database::t('identity_jobs') . " WHERE record_kind = 'listing' AND record_id = ?");
        $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** The next listings for the worker, marked as leased so two runs don't take the same one. */
    public static function lease(PDO $pdo, int $limit): array
    {
        if (!self::ready($pdo)) return [];
        $limit = max(1, min(20, $limit));
        if ((int) $pdo->query("SELECT COUNT(*) FROM " . Database::t('identity_jobs') . " WHERE status = 'queued'")->fetchColumn() < $limit * 3) { self::queue($pdo, 300); self::queueWebsites($pdo, 300); }
        $now = date('Y-m-d H:i:s');
        $st = $pdo->prepare("SELECT * FROM " . Database::t('identity_jobs') . " WHERE ((status IN ('queued', 'nothing') AND (next_at IS NULL OR next_at <= ?)) OR (status = 'leased' AND lease_until < ?))
                                AND attempts < " . self::MAX_ATTEMPTS . " ORDER BY priority DESC, id LIMIT $limit");
        $st->execute([$now, $now]);
        $out = [];
        // a look that found nothing comes back after 30 days with a fresh count of tries; a lease that ran out with no
        // report (the run ran out of time) is not a try (review B5, 2026-11-13): it keeps its count
        $mark = $pdo->prepare("UPDATE " . Database::t('identity_jobs') . " SET attempts = CASE WHEN status = 'nothing' THEN 1 WHEN status = 'leased' THEN attempts ELSE attempts + 1 END, status = 'leased', lease_until = ?, updated_at = NOW() WHERE id = ?");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $j) {
            $l = self::listing($pdo, (int) $j['record_id']);
            if (!$l) { $pdo->prepare('DELETE FROM ' . Database::t('identity_jobs') . ' WHERE id = ?')->execute([(int) $j['id']]); continue; }
            $mark->execute([date('Y-m-d H:i:s', time() + self::LEASE_MINUTES * 60), (int) $j['id']]);
            $out[] = ['job_id' => (int) $j['id']] + $l;
        }
        return $out;
    }

    /** What the worker needs to look a listing up. A confidential address is never sent: it searches by name and town. */
    private static function listing(PDO $pdo, int $id): ?array
    {
        $l = IntakeStager::existingListing($pdo, $id);
        if (!$l || (int) $l['is_suppressed']) return null;
        $mv = function (string $k) use ($l): string { $v = $l['meta'][$k]['value'] ?? ''; return is_array($v) ? (string) ($v[0] ?? '') : (string) $v; };
        $hidden = ListingSafety::isConfidential($l['category_id'] !== null ? (int) $l['category_id'] : null, (string) $l['name']);
        $hosts = []; $rejected = [];
        if (Identity::ready($pdo)) {
            $st = $pdo->prepare("SELECT DISTINCT s.site FROM " . Database::t('identity_fact_sources') . " s JOIN " . Database::t('identity_facts') . " f ON f.id = s.fact_id WHERE f.record_kind = 'listing' AND f.record_id = ? AND s.site <> ''");
            $st->execute([$id]); $hosts = $st->fetchAll(PDO::FETCH_COLUMN);
            $st = $pdo->prepare("SELECT f.fact, f.value_norm FROM " . Database::t('identity_facts') . " f WHERE f.record_kind = 'listing' AND f.record_id = ? AND f.status = 'rejected'");
            $st->execute([$id]); foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $rejected[] = $r['fact'] . ':' . $r['value_norm'];
        }
        // a Facebook or other social page isn't a website of its own: it's still to find (decisions/0086)
        $site = $mv('website'); $social = $site !== '' && WebIdentity::brand($site) === '';
        $need = array_values(array_filter(['phone', 'website', 'email'], fn ($k) => $k === 'website' ? ($site === '' || $social) : $mv($k) === ''));
        return ['entity_id' => $id, 'name' => (string) $l['name'], 'category' => (string) ($l['category_name'] ?? ''),
                'address' => $hidden ? '' : $mv('address'), 'city' => $mv('city'), 'state' => $mv('state'), 'zip' => (string) $l['primary_zip'],
                'phone' => $mv('phone'), 'website' => $social ? '' : $site, 'need' => $need ?: ['confirm'], 'known_hosts' => array_values($hosts),
                'rejected' => $rejected, 'confidential' => $hidden];
    }

    /**
     * What the worker found for one job: found = [{fact, value, url, kind, evidence, label}], checked = steps taken.
     * Returns ['stored' => n, 'applied' => [facts put on the listing], 'waiting' => n for a person].
     */
    public static function complete(PDO $pdo, int $jobId, array $found, array $checked, string $error = ''): array
    {
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('identity_jobs') . ' WHERE id = ?'); $st->execute([$jobId]);
        $j = $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('No such job.');
        $id = (int) $j['record_id'];
        $checked = array_values(array_intersect(array_map('strval', $checked), ['own_site', 'npi', 'sources', 'search']));
        if ($error !== '') {
            $pdo->prepare("UPDATE " . Database::t('identity_jobs') . " SET status = 'queued', lease_until = NULL, next_at = ?, note = ?, updated_at = NOW() WHERE id = ?")
                ->execute([date('Y-m-d H:i:s', time() + 6 * 3600), mb_substr('Stopped: ' . $error, 0, 300), $jobId]);
            return ['stored' => 0, 'applied' => [], 'waiting' => 0];
        }
        $l = IntakeStager::existingListing($pdo, $id);
        if (!$l) { $pdo->prepare('DELETE FROM ' . Database::t('identity_jobs') . ' WHERE id = ?')->execute([$jobId]); return ['stored' => 0, 'applied' => [], 'waiting' => 0]; }
        // what we hold already (our sources, the registries we keep): rebuilt first, so the job's finds count with it
        Identity::fromListing($pdo, $id);
        $stored = 0; $touched = [];
        foreach (array_slice($found, 0, 30) as $f) {
            if (!is_array($f)) continue;
            $fact = (string) ($f['fact'] ?? ''); $url = trim((string) ($f['url'] ?? ''));
            $value = trim((string) ($f['value'] ?? ''));
            if (!in_array($fact, self::FINDS, true) || !preg_match('#^https?://#i', $url)) continue;
            $host = Identity::host($url);
            $evOnly = self::evidenceOnly($host);
            $ev = (string) ($f['evidence'] ?? '');
            if (!in_array($ev, ['address', 'phone', 'both', 'own_site', 'registry'], true)) continue;   // a page must match more than the name
            if ($fact === 'phone') { $value = ListingExtractor::phone($value) ?? ''; if ($value === '') continue; }
            if ($fact === 'website' || $fact === 'social') { if (!preg_match('#^https?://#i', $value)) continue; }
            if ($fact === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) continue;
            if ($fact === 'hours') $value = mb_substr($value, 0, 300);
            // Google, Yelp, Facebook: only a link to their page, or a confirmation of a value another source gave
            if ($evOnly && $fact !== 'social' && !self::heldAlready($pdo, $id, $fact, $value)) continue;
            if ($fact === 'social' && !$evOnly && !in_array(Identity::kindFor($value), ['social', 'directory'], true)) continue;
            $kind = (string) ($f['kind'] ?? '');
            $kind = $evOnly ? 'evidence' : ($kind === 'registry' ? 'registry' : Identity::kindFor($url, $kind === 'own_site' ? 'own_site' : ''));
            $label = mb_substr(trim((string) ($f['label'] ?? '')), 0, 150);
            $label = ($label !== '' ? $label : $host) . ($ev === 'own_site' ? '' : ' · matched ' . ['address' => 'the name and address', 'phone' => 'the name and phone', 'both' => 'the name, address and phone', 'own_site' => '', 'registry' => 'the registry'][$ev]);
            if (Identity::add($pdo, 'listing', $id, $fact, $value, ['kind' => $kind, 'url' => $url, 'label' => $label, 'by' => 0])) { $stored++; $touched[$fact] = 1; }
        }
        Identity::recompute($pdo, 'listing', $id);
        // a confirmed value (or one from its own website, a registry or a government page) goes on the listing when the
        // listing has none; anything a person entered is never touched
        $applied = []; $waiting = 0;
        foreach (['phone', 'website', 'email'] as $fact) {
            if (!isset($touched[$fact])) continue;
            $now = $l['meta'][$fact] ?? null;
            $have = $now !== null && ($now['locked'] || (is_string($now['value']) ? trim($now['value']) !== '' : !empty($now['value'])));
            // a Facebook or other social page as its website isn't a website of its own (decisions/0086): its own site,
            // once found and trusted, takes the place, and the social page moves to its social links
            $socialSite = $fact === 'website' && $now !== null && !$now['locked'] && is_string($now['value']) && trim($now['value']) !== '' && WebIdentity::brand($now['value']) === '';
            if ($socialSite) $have = false;
            $best = self::best($pdo, $id, $fact);
            if (!$best) continue;
            if ($socialSite && WebIdentity::brand((string) $best['value']) === '') continue;   // only another social page: keep what it has
            if (!$have && $best['trusted']) {
                if ($socialSite) {
                    $links = is_array($l['meta']['social_links']['value'] ?? null) ? $l['meta']['social_links']['value'] : [];
                    if (!in_array($now['value'], $links, true)) { $links[] = $now['value']; CrawlerIngest::upsertMetadataKey($pdo, $id, 'social_links', $links); }
                }
                CrawlerIngest::upsertMetadataKey($pdo, $id, $fact, $best['value']); $applied[] = $fact;
            }
            elseif (!$have) $waiting++;
        }
        if (isset($touched['social'])) {
            $now = $l['meta']['social_links'] ?? null;
            if (!$now || !$now['locked']) {
                $links = is_array($now['value'] ?? null) ? $now['value'] : [];
                $st = $pdo->prepare("SELECT value FROM " . Database::t('identity_facts') . " WHERE record_kind = 'listing' AND record_id = ? AND fact = 'social' AND status <> 'rejected'");
                $st->execute([$id]);
                $all = array_values(array_unique(array_merge($links, $st->fetchAll(PDO::FETCH_COLUMN))));
                if (count($all) > count($links)) { CrawlerIngest::upsertMetadataKey($pdo, $id, 'social_links', array_slice($all, 0, 20)); $applied[] = 'social'; }
            }
        }
        if ($applied) { try { require_once __DIR__ . '/SearchIndex.php'; if (SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, [$id]); } catch (Throwable) {} }
        $note = $stored ? 'Found ' . implode(', ', array_keys($touched)) . ($applied ? '; on the listing: ' . implode(', ', $applied) : '') . ($waiting ? "; $waiting for a person" : '') : 'Nothing found yet';
        $pdo->prepare("UPDATE " . Database::t('identity_jobs') . " SET status = ?, lease_until = NULL, next_at = ?, found_n = ?, checked = ?, note = ?, priority = 0, updated_at = NOW() WHERE id = ?")
            ->execute([$stored ? 'done' : 'nothing', $stored ? null : date('Y-m-d H:i:s', time() + self::AGAIN_DAYS * 86400), $stored, implode(',', $checked), mb_substr($note, 0, 300), $jobId]);
        return ['stored' => $stored, 'applied' => $applied, 'waiting' => $waiting];
    }

    public static function evidenceOnly(string $host): bool
    {
        foreach (self::EVIDENCE_ONLY as $h) if ($host === $h || str_ends_with($host, '.' . $h)) return true;
        return (bool) preg_match('/(^|\.)google\.[a-z.]+$/', $host);
    }

    /** True when another (non-evidence) source already gives this value for the listing. */
    private static function heldAlready(PDO $pdo, int $id, string $fact, string $value): bool
    {
        $st = $pdo->prepare("SELECT COUNT(*) FROM " . Database::t('identity_facts') . " f JOIN " . Database::t('identity_fact_sources') . " s ON s.fact_id = f.id WHERE f.record_kind = 'listing' AND f.record_id = ? AND f.fact = ? AND f.value_norm = ? AND s.kind <> 'evidence'");
        $st->execute([$id, $fact, Identity::norm($fact, $value)]);
        return (int) $st->fetchColumn() > 0;
    }

    /** The shown value of a fact, and whether it may go on the listing without a person: confirmed, or from a trusted kind of source. */
    public static function best(PDO $pdo, int $id, string $fact): ?array
    {
        $st = $pdo->prepare("SELECT f.id, f.value, f.status, GROUP_CONCAT(s.kind) AS kinds FROM " . Database::t('identity_facts') . " f JOIN " . Database::t('identity_fact_sources') . " s ON s.fact_id = f.id
                              WHERE f.record_kind = 'listing' AND f.record_id = ? AND f.fact = ? AND f.is_current = 1 AND f.status <> 'rejected' GROUP BY f.id, f.value, f.status ORDER BY f.id DESC LIMIT 1");
        $st->execute([$id, $fact]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $kinds = explode(',', (string) $r['kinds']);
        return ['id' => (int) $r['id'], 'value' => (string) $r['value'], 'status' => (string) $r['status'],
                'trusted' => $r['status'] === 'confirmed' || (bool) array_intersect($kinds, ['own_site', 'registry', 'government'])];
    }

    /** For Admin: queued, being looked up, found something, found nothing yet; and finds waiting for a person. */
    public static function stats(PDO $pdo): array
    {
        $out = ['queued' => 0, 'leased' => 0, 'done' => 0, 'nothing' => 0, 'week' => 0];
        if (!self::ready($pdo)) return $out;
        foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM ' . Database::t('identity_jobs') . ' GROUP BY status')->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['status']] = (int) $r['n'];
        $st = $pdo->prepare("SELECT COUNT(*) FROM " . Database::t('identity_jobs') . " WHERE status = 'done' AND updated_at >= ?"); $st->execute([date('Y-m-d H:i:s', time() - 7 * 86400)]);
        $out['week'] = (int) $st->fetchColumn();
        return $out;
    }

    /**
     * What the crawler found that waits for a person: a phone, website or email from one website (not its own, not a
     * registry), on a listing that has none. [['fact_id', 'listing', 'name', 'fact', 'value', 'sources']]
     */
    public static function waiting(PDO $pdo, int $limit = 50): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->query("SELECT f.id, f.record_id, f.fact, f.value, e.name FROM " . Database::t('identity_facts') . " f JOIN entities e ON e.id = f.record_id
                            WHERE f.record_kind = 'listing' AND f.fact IN ('phone', 'website', 'email') AND f.is_current = 1 AND f.status = 'single'
                              AND EXISTS (SELECT 1 FROM " . Database::t('identity_fact_sources') . " s WHERE s.fact_id = f.id AND s.added_by = 0)
                              AND NOT EXISTS (SELECT 1 FROM entity_metadata m WHERE m.entity_id = f.record_id AND m.meta_key = f.fact AND m.meta_value NOT IN ('', '\"\"', 'null'))
                            ORDER BY f.id LIMIT " . max(1, min(500, $limit)));
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
