<?php
// app/admin/cleanup-console.php — Insights → Data cleanup (decisions/0163 §8 stage 1b, 0164 §6.1b; Jason, 2026-11-14).
// Finds what the old crawler made that fails today's rules (app/lib/DataCleanup.php), in listings, staged finds, the place
// store and landmarks, and previews it by reason with counts and examples, before anything changes. This release only
// finds and previews: acting (reversibly, with a ledger and Undo, never deleting) comes in the next one.
declare(strict_types=1);

function tv_admin_mod_cleanup(PDO $pdo): string
{
    require_once __DIR__ . '/../lib/DataCleanup.php';
    $e = 'tv_w_e';
    [$can, $why] = Access::can('insights.cleanup', DataCleanup::RULE_RUN);
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $only = '';
    $res = null; $msg = '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['dc_do']) && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        try {
            if (!$can) throw new RuntimeException($why);
            if ((string) $_POST['dc_do'] !== 'preview') throw new RuntimeException('Unknown action.');
            $only = (string) ($_POST['rule'] ?? '');
            if ($only !== '' && !isset(DataCleanup::RULES[$only])) $only = '';
            $res = DataCleanup::preview($pdo, $only);
            $n = array_sum(array_map(fn ($r) => $r['act'] + $r['check'], $res['rules']));
            $msg = '<p data-tv-flash="ok">' . $e($n ? 'Preview ready: ' . number_format($n) . ' record' . ($n === 1 ? '' : 's') . ' fail today\'s rules. Nothing was changed.' : 'Preview ready: nothing fails today\'s rules. Nothing was changed.') . '</p>';
        } catch (Throwable $x) {
            $msg = '<p data-tv-flash="error">' . $e($x instanceof RuntimeException ? $x->getMessage() : 'The preview didn\'t finish: try one rule at a time.') . '</p>';
            if (!($x instanceof RuntimeException)) error_log('cleanup preview: ' . $x->getMessage());
        }
    }
    $dis = $can ? '' : ' disabled title="' . $e($why) . '"';
    $info = fn (string $title, string $html) => '<details class="dc-i"><summary aria-label="' . $e($title) . '" title="' . $e($title) . '">ⓘ</summary><div>' . $html . '</div></details>';

    $h = '<style>.dc-i{display:inline-block;margin-left:.3rem}.dc-i>summary{cursor:pointer;list-style:none;color:#B45309;font-weight:700}.dc-i>div{background:#FFFBF2;border:1px solid #E7D9C2;border-radius:.5rem;padding:.6rem .8rem;margin:.4rem 0;max-width:46rem}'
        . '.dc-f{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;margin:.4rem 0}.dc-n{font-variant-numeric:tabular-nums;text-align:right}.dc-x>summary{cursor:pointer;color:#92400E}.dc-x ul{margin:.3rem 0 .5rem 1.1rem;padding:0}.dc-x li{margin:.15rem 0}'
        . '.dc-g{font-size:.8rem;color:#6B5B45}.dc-t th,.dc-t td{white-space:normal!important;text-align:left!important;vertical-align:top}.dc-t .dc-n{text-align:right!important;white-space:nowrap!important}</style>';
    $h .= $msg . '<p class="ak-note">Finds what the crawler made before today\'s rules (decisions/0164) and fails them: listings, staged finds, the place store and landmarks, newest first. '
        . 'Preview shows, by reason, how many and which, before anything changes. ' . ($can ? '' : '<b>' . $e($why) . '</b>')
        . $info('How Data cleanup works', '<p><b>Find and preview, then act.</b> This first step only finds and previews: nothing is changed. The next release adds the actions, each reversible and logged, with Undo for one change or a whole pass.</p>'
            . '<p><b>What the actions will be, by rule:</b></p><ul>' . implode('', array_map(fn ($v) => '<li>' . $e($v) . '</li>', DataCleanup::ACTIONS)) . '</ul>'
            . '<p><b>Never deleted, never a person\'s work:</b> a record a person entered, a claimed listing\'s owner\'s fields, and anything a person already decided (approved in the intake, a field they set, a landmark they approved) is never changed. Those are counted under <b>Check these</b>, for a person to look at.</p>'
            . '<p><b>Left</b> counts records the rule looked at and leaves as they are (a closure its own website states, a pair already asked about in Review).</p>'
            . '<p>It works while automation is paused: it changes what\'s stored, it gathers nothing.</p>') . '</p>';
    $h .= '<p data-tv-status="info" data-tv-label="Preview only:">This release finds and previews. Nothing is quarantined, re-sourced or changed until the actions arrive (they wait for Jason\'s approval).</p>';

    // the form: a pass per reason, or all
    $opts = '<option value="">Every rule</option>';
    foreach (DataCleanup::STORES as $sk => $sl) {
        $opts .= '<optgroup label="' . $e($sl) . '">';
        foreach (DataCleanup::RULES as $k => $r) if ($r[0] === $sk) $opts .= '<option value="' . $e($k) . '"' . ($only === $k ? ' selected' : '') . '>' . $e($r[1]) . '</option>';
        $opts .= '</optgroup>';
    }
    $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Preview</h3>'
        . '<form method="post" class="dc-f" data-dc-form><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="dc_do" value="preview">'
        . '<label class="ak-note" for="dc-rule">Rule</label><select id="dc-rule" class="ak-in" name="rule"' . $dis . '>' . $opts . '</select>'
        . '<button class="ak-b go" type="submit"' . $dis . '>Preview</button></form>'
        . '<p class="ak-note">Reads up to ' . number_format(DataCleanup::READ) . ' of each store, newest first. Every rule at once can take a minute.</p></div>';

    // the rules, with what each finds (shown before any preview, so the page explains itself)
    if ($res === null) {
        $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">The rules</h3><div class="ak-aa"><table class="dc-t"><thead><tr><th>Rule</th><th>Store</th><th>What it finds</th><th>What happens</th><th>Decision</th></tr></thead><tbody>';
        foreach (DataCleanup::RULES as $k => [$store, $title, $what, $act, $dec])
            $h .= '<tr><td><b>' . $e($title) . '</b></td><td>' . $e(DataCleanup::STORES[$store]) . '</td><td>' . $e($what) . '</td><td>' . $e(DataCleanup::ACTIONS[$act]) . '</td><td class="dc-g">' . $e($dec) . '</td></tr>';
        $h .= '</tbody></table></div></div>';
    } else {
        $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">What the preview found</h3><p class="ak-note">As of <time datetime="' . $e($res['at']) . '" data-tv-time>' . $e(date('M j, g:i a', (int) strtotime($res['at']))) . '</time>. ';
        $parts = [];
        foreach ($res['stores'] as $sk => $s) $parts[] = DataCleanup::STORES[$sk] . ': ' . ($s['error'] !== '' && !$s['read'] ? $s['error'] : 'read ' . number_format($s['read']) . ' of ' . number_format($s['of']) . ($s['error'] !== '' ? ' (' . $s['error'] . ')' : ''));
        $h .= $e(implode(' · ', $parts)) . '</p>';
        $h .= '<div class="ak-aa"><table class="dc-t"><thead><tr><th>Rule</th><th>What happens</th><th class="dc-n">Would change</th><th class="dc-n">Check these</th><th class="dc-n">Left</th></tr></thead><tbody>';
        $tot = ['act' => 0, 'check' => 0, 'left' => 0];
        foreach ($res['rules'] as $k => $r) {
            [$store, $title, $what, $act] = DataCleanup::RULES[$k];
            foreach ($tot as $g => $_) $tot[$g] += $r[$g];
            $ex = '';
            foreach (['act' => 'Would change', 'check' => 'Check these (a person entered or decided something: never changed)', 'left' => 'Left as they are'] as $g => $gl) {
                if (!$r['examples'][$g]) continue;
                $ex .= '<p class="dc-g"><b>' . $e($gl) . '</b>' . ($r[$g] > count($r['examples'][$g]) ? ', the newest ' . count($r['examples'][$g]) . ' of ' . number_format($r[$g]) : '') . ':</p><ul>';
                foreach ($r['examples'][$g] as $it) $ex .= '<li><a href="' . $e($it['link']) . '" data-peek-frame>' . $e($it['name'] !== '' ? $it['name'] : '(no name)') . '</a>: ' . $e($it['why'])
                    . ($g === 'act' && $it['target'] !== $act ? ' <span class="dc-g">(' . $e(DataCleanup::ACTIONS[strtok($it['target'], ':')] ?? $it['target']) . ')</span>' : '') . '</li>';
                $ex .= '</ul>';
            }
            $h .= '<tr><td><b>' . $e($title) . '</b><br><span class="dc-g">' . $e(DataCleanup::STORES[$store]) . '</span>'
                . ($ex !== '' ? '<details class="dc-x"><summary>Examples</summary>' . $ex . '</details>' : '') . '</td>'
                . '<td>' . $e(DataCleanup::ACTIONS[$act]) . '</td><td class="dc-n">' . number_format($r['act']) . '</td><td class="dc-n">' . number_format($r['check']) . '</td><td class="dc-n">' . number_format($r['left']) . '</td></tr>';
        }
        if (count($res['rules']) > 1) $h .= '<tr><td><b>Every rule</b></td><td></td><td class="dc-n"><b>' . number_format($tot['act']) . '</b></td><td class="dc-n"><b>' . number_format($tot['check']) . '</b></td><td class="dc-n"><b>' . number_format($tot['left']) . '</b></td></tr>';
        $h .= '</tbody></table></div><p class="ak-note">A listing is counted under one reason, the first it fails in this order: its name, the floor, its sources; then OpenStreetMap values, a one-site Closed and duplicates.</p></div>';
    }
    // the spinner while it works (a preview can take a minute)
    $h .= '<script>document.addEventListener("submit",function(e){var f=e.target;if(!f||!f.hasAttribute||!f.hasAttribute("data-dc-form"))return;var b=f.querySelector("button[type=submit]");if(b&&window.TvAsk)setTimeout(function(){TvAsk.busy(b,true)},0);});</script>';
    return $h;
}
