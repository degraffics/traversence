/* js/admin-control.js — System Configuration → System Control Board (decisions/0171, release 2b). Each button asks first
 * where it changes something (data-confirm), shows its spinner (TvAsk.busy), answers beside itself (TvAsk.say), and the
 * board is drawn again in place: the stages, where the system stands and each system with its processes, keeping what's
 * open. The board also looks again every 30 seconds while it's showing, and at once when its tab is shown again. The
 * pre-flight fold below is left as it is (its own script runs it). The find box narrows the rows to those whose words,
 * needs or sources hold what's typed; Open all and Close all open or close every row; a held process's link in Holding now
 * opens it; Re-test the four runs the query timings one after another (2026-11-18, laid out after Jason's example board). */
(function () {
  var box = document.getElementById('cb');
  if (!box) return;
  var csrf = box.getAttribute('data-csrf') || '', going = false;

  function post(url, body) {
    return fetch(url, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again; still stuck? Write to support@traversence.com.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again.'); return j; });
  }
  function say(msg, el, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: el, bad: !!bad }); }

  // a report's downloads (release 5b): the server builds the CSV or the page as a file; saved here as a file
  box.addEventListener('click', function (e) {
    var b = e.target.closest('[data-cb-dl]'); if (!b) return;
    e.preventDefault(); if (window.TvAsk) TvAsk.busy(b, true);
    post('/admin/api/config/control', { action: 'report', format: b.getAttribute('data-cb-dl'), scope: b.getAttribute('data-cb-scope') || '', range: b.getAttribute('data-cb-range') || 'day' }).then(function (j) {
      if (window.TvAsk) TvAsk.busy(b, false);
      var url = URL.createObjectURL(new Blob([j.body], { type: j.type + ';charset=utf-8' })), a = document.createElement('a');
      a.href = url; a.download = j.name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
      say(j.message, b);
    }, function (err) { if (window.TvAsk) TvAsk.busy(b, false); say(err.message, b, true); });
  });

  // the board drawn again in place
  function redraw() {
    if (going) return; going = true;
    var open = {}; box.querySelectorAll('details[id]').forEach(function (d) { open[d.id] = d.open; });
    fetch(location.pathname + location.search, { credentials: 'include' }).then(function (r) { return r.ok ? r.text() : ''; }).then(function (html) {
      if (!html) return;
      var doc = new DOMParser().parseFromString(html, 'text/html'), nb = doc.getElementById('cb');
      if (!nb) return;
      if (box.querySelector('[aria-busy="true"]')) return;   // a press is still working: next time
      ['.cb-strip', '.cb-stages', '.cb-stage', '#cb-alarms', '#cb-times', '#maintenance > summary', '#maintenance .cb-mlist', '#maintenance .cb-uplist', '#cb-p-site-needs'].forEach(function (sel) { var a = box.querySelector(sel), b = nb.querySelector(sel); if (!a || !b) return; var nu = document.importNode(b, true);
        if (nu.id && nu.id in open) nu.open = open[nu.id]; nu.querySelectorAll('details[id]').forEach(function (d) { if (d.id in open) d.open = open[d.id]; });   // what's open stays open
        a.parentNode.replaceChild(nu, a); });
      nb.querySelectorAll('details.cb-sys').forEach(function (n) {
        var cur = document.getElementById(n.id), nu = document.importNode(n, true);
        nu.querySelectorAll('details[id]').forEach(function (d) { if (d.id in open) d.open = open[d.id]; });
        if (n.id in open) nu.open = open[n.id];
        // a notice or an "are you sure" under a row stays where it was (the redraw would wipe it a second after a press)
        var keep = cur ? Array.prototype.map.call(cur.querySelectorAll('.tv-note, .tv-ask'), function (n) { var p = n.previousElementSibling; return [n, p && p.id]; }) : [];
        if (cur) cur.parentNode.replaceChild(nu, cur);
        keep.forEach(function (k) { var after = k[1] && nu.querySelector('#' + CSS.escape(k[1])); if (after) after.parentNode.insertBefore(k[0], after.nextSibling); });
      });
      filter(); afilter(); loadOpen();
      if (window.TvTime) TvTime.paint(box);
    }).catch(function () {}).then(function () { going = false; });
  }
  // the logbook (0171 §10, release 5a): its one filter (a dropdown button), Show older, and Log an entry with the device's zone
  var logScope = '';
  function logLoad(before, btn) {
    var list = box.querySelector('[data-cb-loglist]'); if (!list) return;
    if (btn) TvAsk.busy(btn, true);
    post('/admin/api/config/control', { action: 'logfeed', scope: logScope, before: before || 0 }).then(function (j) {
      if (btn) { TvAsk.busy(btn, false); var li = btn.closest('li'); if (li) li.remove(); list.insertAdjacentHTML('beforeend', j.html || ''); } else list.innerHTML = j.html || '';
      if (window.TvTime) TvTime.paint(list);
    }, function (err) { if (btn) TvAsk.busy(btn, false); say(err.message, btn || list, true); });
  }
  box.addEventListener('click', function (e) {
    var lb = e.target.closest('[data-cb-logb]'), lw = e.target.closest('.cb-lgw');
    if (lb) { var l = lw.querySelector('.ak-fl'), open = l.hidden; l.hidden = !open; lb.setAttribute('aria-expanded', open ? 'true' : 'false'); return; }
    var lv = e.target.closest('[data-cb-logv]');
    if (lv && lw) { logScope = lv.getAttribute('data-cb-logv'); lw.querySelectorAll('[data-cb-logv]').forEach(function (x) { x.classList.toggle('on', x === lv); });
      lw.querySelector('[data-cb-logname]').textContent = lv.textContent; lw.querySelector('.ak-fl').hidden = true; lw.querySelector('[data-cb-logb]').setAttribute('aria-expanded', 'false'); logLoad(0); return; }
    var more = e.target.closest('[data-cb-logmore]');
    if (more) { logLoad(parseInt(more.getAttribute('data-cb-logmore'), 10) || 0, more); return; }
    var note = e.target.closest('[data-cb-lognote]');
    if (note && !note.disabled) { var f = document.getElementById('cb-log-form'); if (!f || !f.reportValidity()) return;
      var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (x) {}
      TvAsk.busy(note, true);
      post('/admin/api/config/control', { action: 'lognote', text: f.elements.text.value, scope: f.elements.scope.value, tz: tz }).then(function (j) { TvAsk.busy(note, false); f.reset(); say(j.message || 'Logged.', note); logLoad(0); },
        function (err) { TvAsk.busy(note, false); say(err.message, note, true); }); }
  });
  box.addEventListener('submit', function (e) { if (e.target.id === 'cb-log-form') { e.preventDefault(); var b = e.target.querySelector('[data-cb-lognote]'); if (b) b.click(); } });

  // the historian's trends (0171 §6, release 4b): each loads when its row or system opens, its range buttons switch it in
  // place, and a redraw puts it back from a 5-minute cache (with the range chosen) instead of asking again
  var trCache = {}, trRange = {};
  function loadTrend(h, range, btn) {
    var id = h.getAttribute('data-cb-trend'); range = range || trRange[id] || '24h'; trRange[id] = range;
    var k = id + '|' + range, c = trCache[k];
    if (c && Date.now() - c[0] < 300000) { h.innerHTML = c[1]; h.setAttribute('data-loaded', range); return; }
    if (btn) TvAsk.busy(btn, true); else h.setAttribute('aria-busy', 'true');
    post('/admin/api/config/control', { action: 'trend', id: id, range: range }).then(function (j) {
      trCache[k] = [Date.now(), j.html || '']; h.removeAttribute('aria-busy'); if (btn) TvAsk.busy(btn, false);
      h.innerHTML = j.html || ''; h.setAttribute('data-loaded', range);
    }, function (err) { h.removeAttribute('aria-busy'); if (btn) TvAsk.busy(btn, false); say(err.message, btn || h, true); });
  }
  function loadOpen() {
    box.querySelectorAll('details.cb-p[open] .cb-trend, details.cb-sys[open] > .cb-sys-tr .cb-trend').forEach(function (h) {
      var id = h.getAttribute('data-cb-trend'); if (h.getAttribute('data-loaded') !== (trRange[id] || '24h')) loadTrend(h); });
  }
  box.addEventListener('toggle', function (e) { if (e.target.open && e.target.matches && e.target.matches('details.cb-p, details.cb-sys')) loadOpen(); }, true);
  box.addEventListener('click', function (e) {
    var r = e.target.closest('[data-cb-range]'); if (!r) return;
    var h = r.closest('.cb-trend'); if (h) { e.preventDefault(); loadTrend(h, r.getAttribute('data-cb-range'), r); }
  });
  loadOpen();
  // find: each process row whose words, needs or sources hold every word typed; its system opens
  var q = box.querySelector('[data-cb-filter]');
  function filter() {
    var words = ((q && q.value) || '').toLowerCase().split(/\s+/).filter(Boolean), any = false;
    box.querySelectorAll('details.cb-sys').forEach(function (sys) {
      var shown = 0;
      sys.querySelectorAll('details.cb-p').forEach(function (p) {
        var hay = p.getAttribute('data-q') || '', hit = words.every(function (w) { return hay.indexOf(w) >= 0; });
        p.hidden = !hit; if (hit) shown++;
      });
      sys.hidden = words.length > 0 && shown === 0;
      if (words.length && shown) sys.open = true;
      if (shown) any = true;
    });
    var none = box.querySelector('.cb-none'); if (none) none.hidden = any || !words.length;
  }
  if (q) q.addEventListener('input', filter);
  // the queue's one filter: a dropdown button (icon, current choice, count, ▾) that admin-kit.js moves into the page's header
  // (Open, Acknowledged, Cleared, All; or a level), kept through each redraw, with each choice's count
  var aShow = 'open', fw = document.querySelector('.cb-afw');
  function hit(li, k) { var st = li.getAttribute('data-astate'), lv = li.getAttribute('data-alevel');
    return k === 'all' || k === st || (['trip', 'warning', 'notice'].indexOf(k) >= 0 && lv === k && st !== 'cleared'); }
  function afilter() {
    var list = box.querySelectorAll('#cb-alarms ul.cb-al:not(.cb-al-in) > li[data-astate]'), n = 0;   // a group counts once; its alarms show inside it
    list.forEach(function (li) { var h = hit(li, aShow); li.hidden = !h; if (h) n++; });
    var none = box.querySelector('#cb-alarms .cb-anone'); if (none) none.hidden = n > 0 || !list.length;
    if (!fw) return;
    fw.querySelectorAll('[data-cb-afv]').forEach(function (b) { var k = b.getAttribute('data-cb-afv'), c = 0; list.forEach(function (li) { if (hit(li, k)) c++; });
      b.querySelector('i').textContent = c; b.classList.toggle('on', k === aShow); if (k === aShow) fw.querySelector('[data-cb-afname]').textContent = b.firstChild.textContent; });
    fw.querySelector('[data-cb-afcount]').textContent = n;
  }
  if (fw) fw.addEventListener('click', function (e) {
    var b = e.target.closest('[data-cb-afb]'), l = fw.querySelector('.ak-fl');
    if (b) { var open = l.hidden; l.hidden = !open; b.setAttribute('aria-expanded', open ? 'true' : 'false'); return; }
    var v = e.target.closest('[data-cb-afv]');
    if (v) { aShow = v.getAttribute('data-cb-afv'); l.hidden = true; fw.querySelector('[data-cb-afb]').setAttribute('aria-expanded', 'false'); afilter();
      var al = document.getElementById('cb-alarms'); if (al) al.open = true; }
  });
  afilter();
  box.addEventListener('click', function (e) {
    // More / Less: the same line opens in place, nothing repeated
    var mb = e.target.closest('[data-cb-more]');
    if (mb) { var c = mb.closest('[data-cb-clamp]'); if (c) { if (e.target.closest('a')) return; e.preventDefault(); var on = !c.classList.contains('open'), t = c.querySelector('button[data-cb-more]'); c.classList.toggle('open', on);
      if (t) { t.setAttribute('aria-expanded', on ? 'true' : 'false'); t.setAttribute('aria-label', on ? 'Fold it to one line' : 'Show all of it'); t.title = t.getAttribute('aria-label'); } } return; }
    var all = e.target.closest('[data-cb-all]');
    if (all) { var on = all.getAttribute('data-cb-all') === '1'; box.querySelectorAll('details.cb-sys, details.cb-p').forEach(function (d) { if (!d.hidden) d.open = on; }); return; }
    var go = e.target.closest('[data-cb-go]');
    if (go) { var t = document.getElementById(go.getAttribute('data-cb-go')); if (t) { e.preventDefault(); var s = t.closest('details.cb-sys'); if (s) s.open = true; t.open = true; t.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }
  });
  // opened from a link to a part of the board (the top bar's light: #cb-alarms): that part opens, everything else stays closed
  function openHash() { var t = location.hash && document.getElementById(location.hash.slice(1)); if (!t || !box.contains(t)) return;
    for (var d = t; d && d !== box; d = d.parentElement) if (d.tagName === 'DETAILS') d.open = true;
    setTimeout(function () { t.scrollIntoView({ block: 'start' }); }, 50); }
  openHash(); window.addEventListener('hashchange', openHash);
  setInterval(function () { if (!document.hidden) redraw(); }, 30000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) redraw(); });

  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-cb]');
    if (!b || b.disabled || !box.contains(b)) return;
    if (b.closest('summary')) e.preventDefault();   // a button on a row's line works without opening or closing it
    // a button on a row's line answers under the whole row, full width: beside it, its narrow cell squeezed the words into a
    // column a letter wide (Jason, 2026-11-18, the Workers' Check)
    var at = b.closest('summary') ? b.closest('details') : b;
    if (b.hasAttribute('data-confirm') && !TvAsk.gate(b, b.getAttribute('data-confirm'), { yes: b.getAttribute('data-yes') || 'Yes', danger: b.hasAttribute('data-danger'), anchor: at })) return;
    var act = b.getAttribute('data-cb'), id = b.getAttribute('data-cb-id') || '';
    TvAsk.busy(b, true);
    var req = act === 'timings'
      ? ['ms:radius', 'ms:rollup', 'ms:graph', 'ms:index'].reduce(function (p, k) { return p.then(function (bad) { return post('/admin/api/config/control', { action: 'check', id: k }).then(function (j) { return bad || !!j.bad; }); }); }, Promise.resolve(false))
          .then(function (bad) { return { message: bad ? 'Re-tested: one or more is over its limit (noted; it holds nothing).' : 'Re-tested: all four are within their limits.', bad: bad }; })
      : act === 'preflight'
      ? post('/admin/api/config/preflight', { action: 'start', mode: 'new' }).then(function () { return { message: 'The pre-flight is running on the server; the board shows it as it goes.' }; })
      : b.hasAttribute('data-cb-form')   // a form's fields (a maintenance window: its times sent as moments, from this device's zone)
      ? (function () { var f = document.getElementById(b.getAttribute('data-cb-form')), body = { action: act, id: id };
          if (!f) return Promise.reject(new Error('The form isn\'t on the page; reload it.'));
          if (!f.reportValidity()) return Promise.resolve({ message: '', skip: true });
          Array.prototype.forEach.call(f.elements, function (el) { if (!el.name) return; body[el.name] = el.type === 'datetime-local' ? (el.value ? String(Math.floor(new Date(el.value).getTime() / 1000)) : '') : el.value; });
          return post('/admin/api/config/control', body).then(function (j) { f.reset(); return j; }); })()
      : b.hasAttribute('data-cb-ask')   // a step that needs one value first (Raise the cap): asked in the site's own box
      ? TvAsk.ask(b.getAttribute('data-cb-ask'), b.getAttribute('data-cb-val') || '', { yes: b.getAttribute('data-cb-yes') || 'Set it' }).then(function (v) { if (v === null || v === undefined || v === false) return { message: '', skip: true }; return post('/admin/api/config/control', { action: act, id: id, value: String(v) }); })
      : post('/admin/api/config/control', { action: act, id: id });
    req.then(function (j) { TvAsk.busy(b, false); if (j.skip) return; say(j.message || 'Done.', at, !!j.bad); setTimeout(redraw, 1200); },
      function (err) { TvAsk.busy(b, false); say(err.message, at, true); });
  });
})();
