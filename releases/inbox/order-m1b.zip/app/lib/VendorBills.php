<?php
// app/lib/VendorBills.php — the vendor's side of an order's money (M1b: research/order-management-design-2026-11-23.md
// §3.6.2–4; decisions/0178 note (c), Jason 2026-11-23: "Yes, create it"). What the work orders agreed to pay the vendor,
// the bills they sent (typed, or read from their dropped invoice in the browser, never by AI), and the Vendor line's
// words. A recorded bill is also made in QuickBooks as a Bill against the vendor (QuickBooksPay::createBill); paying
// vendors stays a separate decision. Money never has Undo (decisions/0178's note): a bill recorded here and not yet in
// QuickBooks has Cancel the record; one in QuickBooks is voided there (↗). Facts are corrected with Edit, History kept.
declare(strict_types=1);

require_once __DIR__ . '/Orders.php';
require_once __DIR__ . '/WorkOrders.php';

final class VendorBills
{
    /** Work orders whose cost is owed to the vendor: sent and not stopped (a draft isn't agreed yet). */
    private const LIVE_WO = ['sent', 'accepted', 'production', 'shipped', 'ready', 'complete', 'received'];
    /** The vendor has made it: their bill is expected now. */
    private const DONE_WO = ['shipped', 'ready', 'complete', 'received'];
    /** Pickup at the vendor or us (no carrier): a bill that says it shipped by a carrier is a question. */
    private const NO_CARRIER = ['will_call', 'internal', 'local', 'courier'];

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT qb_bill_id FROM order_vendor_bills LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    /** The bills on an order, newest first (cancelled ones too, for History). */
    public static function forOrder(PDO $pdo, int $oid): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM order_vendor_bills WHERE order_id = ? ORDER BY id DESC'); $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function get(PDO $pdo, int $oid, int $bid): array
    {
        $st = $pdo->prepare('SELECT * FROM order_vendor_bills WHERE id = ? AND order_id = ?'); $st->execute([$bid, $oid]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: throw new RuntimeException('That bill isn\'t on this order.');
    }

    /** The work orders that owe the vendor (with an agreed cost), for the line and the dropped invoice's check. */
    public static function workOrders(PDO $pdo, int $oid): array
    {
        return array_values(array_filter(WorkOrders::forOrder($pdo, $oid), fn ($w) => in_array((string) ($w['status'] ?? ''), self::LIVE_WO, true) && $w['cost_cents'] !== null));
    }

    /**
     * Where the vendor's side stands, for the Vendor line and the board ('' key: no vendor line at all). Returns ['key' =>
     * '' | unbilled | billed | not_billed | disputed, 'owed' (agreed cents), 'billed' (cents), 'wos', 'bills' (live ones),
     * 'due' (the vendor has made it, so their bill is expected now), 'sentence'].
     */
    public static function state(PDO $pdo, array $o, ?array $wos = null): array
    {
        $oid = (int) $o['id'];
        $wos ??= self::workOrders($pdo, $oid);
        $bills = array_values(array_filter(self::forOrder($pdo, $oid), fn ($b) => $b['status'] !== 'cancelled'));
        $owed = array_sum(array_map(fn ($w) => (int) $w['cost_cents'], $wos));
        $billed = array_sum(array_map(fn ($b) => in_array($b['status'], ['recorded', 'disputed'], true) ? (int) $b['total_cents'] : 0, $bills));
        $out = ['key' => '', 'owed' => $owed, 'billed' => $billed, 'wos' => $wos, 'bills' => $bills, 'due' => false, 'sentence' => ''];
        if (!$wos && !$bills) return $out;
        $day = fn ($d) => $d ? date('M j', strtotime((string) $d)) : '';
        $who = count(array_unique(array_map(fn ($w) => (string) $w['vendor'], $wos))) === 1 ? 'the print vendor' : 'the vendors';
        $woNos = implode(', ', array_map(fn ($w) => (string) $w['wo_no'], $wos));
        $none = array_values(array_filter($bills, fn ($b) => $b['status'] === 'none'));
        $disp = array_values(array_filter($bills, fn ($b) => $b['status'] === 'disputed'));
        $rec = array_values(array_filter($bills, fn ($b) => in_array($b['status'], ['recorded', 'disputed'], true)));
        if ($disp) {
            $b = $disp[0];
            $out['key'] = 'disputed';
            $out['sentence'] = 'Disputed: their invoice ' . $b['bill_no'] . ' for ' . Orders::usd((int) $b['total_cents']) . ($b['why'] !== '' ? ' (' . $b['why'] . ')' : '') . '.';
        } elseif ($rec && $billed >= $owed) {
            $b = $rec[0];
            $out['key'] = 'billed';
            $out['sentence'] = 'Billed ' . Orders::usd($billed) . (count($rec) === 1 ? ' (inv ' . $b['bill_no'] . ($b['bill_date'] ? ', ' . $day($b['bill_date']) : '') . ')' : ' on ' . count($rec) . ' invoices')
                . ($b['due_date'] ? ' · due ' . $day($b['due_date']) : '') . '.';
        } elseif ($none && !$rec) {
            $b = $none[0];
            $out['key'] = 'not_billed';
            $out['sentence'] = 'Not billed by them' . ($b['why'] !== '' ? ': ' . $b['why'] : '') . ' (recorded ' . $day($b['created_at']) . ').';
        } else {
            $out['key'] = 'unbilled';
            $out['sentence'] = $rec
                ? Orders::usd($billed) . ' billed of ' . Orders::usd($owed) . ' to ' . $who . ' (work order' . (count($wos) === 1 ? ' ' : 's ') . $woNos . '); ' . Orders::usd($owed - $billed) . ' not billed yet.'
                : Orders::usd($owed) . ' to ' . $who . ' (work order' . (count($wos) === 1 ? ' ' : 's ') . $woNos . '), not billed yet.';
            $out['due'] = (bool) array_filter($wos, fn ($w) => in_array((string) $w['status'], self::DONE_WO, true));
        }
        return $out;
    }

    /** The work order a PO names (our work order number, or the PO we gave them), or null. */
    public static function woForPo(array $wos, string $po): ?array
    {
        $n = fn ($s) => strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $s));
        if ($n($po) === '') return null;
        foreach ($wos as $w) if ($n($po) === $n($w['wo_no']) || ($n($w['po_no'] ?? '') !== '' && $n($po) === $n($w['po_no']))) return $w;
        return null;
    }

    /** What the page's check needs about each work order (the dropped invoice is read and compared in the browser). */
    public static function expected(array $wos): array
    {
        return array_map(fn ($w) => ['id' => (int) $w['id'], 'wo' => (string) $w['wo_no'], 'po' => (string) ($w['po_no'] ?? ''), 'vendor' => (string) $w['vendor'],
            'cost' => (int) $w['cost_cents'], 'delivery' => (string) ($w['delivery'] ?? ''), 'deliveryName' => WorkOrders::DELIVERY[$w['delivery'] ?? ''] ?? '',
            'pickup' => in_array((string) ($w['delivery'] ?? ''), self::NO_CARRIER, true)], $wos);
    }

    private static function cents($v): int
    {
        $s = preg_replace('/[^0-9.\-]/', '', (string) $v);
        if ($s === '' || !is_numeric($s)) return 0;
        return (int) round((float) $s * 100);
    }

    private static function day($v): ?string
    {
        $v = trim((string) $v);
        if ($v === '') return null;
        $t = strtotime($v);
        if (!$t) throw new RuntimeException('"' . $v . '" isn\'t a date.');
        return date('Y-m-d', $t);
    }

    /**
     * Records the vendor's bill (decisions/0178 note (c)): typed, or read from their invoice. $in: wo, bill_no, bill_date,
     * due_date, po, amount, tax, ship, total, ship_via, answers (JSON: each mismatch asked and its answer), file (the
     * dropped invoice's order file), dispute (the answer that ours is right: kept as disputed), why, tracking. Then it's made
     * in QuickBooks; if QuickBooks can't take it now, it's kept here and the line says why, with Send it to QuickBooks.
     * Returns what happened, in words.
     */
    public static function record(PDO $pdo, int $oid, array $in, int $staff): string
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run 2026-11-23_m1b_vendor_bills.sql first (it runs by itself within the hour).');
        $o = Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.');
        $wos = self::workOrders($pdo, $oid);
        $w = null;
        foreach ($wos as $x) if ((int) $x['id'] === (int) ($in['wo'] ?? 0)) $w = $x;
        if (!$w && ($p = self::woForPo($wos, (string) ($in['po'] ?? '')))) $w = $p;
        if (!$w && count($wos) === 1) $w = $wos[0];
        if (!$w) throw new RuntimeException($wos ? 'Which work order is it for? Choose it.' : 'This order has no work order with an agreed cost to bill.');
        $billNo = mb_substr(trim((string) ($in['bill_no'] ?? '')), 0, 40);
        if ($billNo === '') throw new RuntimeException('Their invoice number, please: it\'s how the bill is found again.');
        $tax = self::cents($in['tax'] ?? ''); $ship = self::cents($in['ship'] ?? '');
        $total = self::cents($in['total'] ?? ''); $amount = self::cents($in['amount'] ?? '');
        if ($total <= 0 && $amount > 0) $total = $amount + $tax + $ship;
        if ($amount <= 0 && $total > 0) $amount = $total - $tax - $ship;
        if ($total <= 0) throw new RuntimeException('The bill\'s total, please.');
        $dup = $pdo->prepare("SELECT id FROM order_vendor_bills WHERE order_id = ? AND bill_no = ? AND status IN ('recorded', 'disputed') LIMIT 1"); $dup->execute([$oid, $billNo]);
        if ($dup->fetchColumn()) throw new RuntimeException('Their invoice ' . $billNo . ' is recorded on this order already: ✎ to edit it.');
        $answers = json_decode((string) ($in['answers'] ?? '[]'), true); if (!is_array($answers)) $answers = [];
        $answers = array_slice(array_map(fn ($a) => ['q' => mb_substr((string) ($a['q'] ?? ''), 0, 300), 'a' => mb_substr((string) ($a['a'] ?? ''), 0, 160)], $answers), 0, 8);
        $dispute = !empty($in['dispute']);
        $why = mb_substr(trim(preg_replace('/\s+/u', ' ', (string) ($in['why'] ?? ''))), 0, 300);
        if ($dispute && $why === '') $why = 'the work order agreed ' . Orders::usd((int) $w['cost_cents']);
        $file = (int) ($in['file'] ?? 0);
        if ($file) { $f = $pdo->prepare('SELECT id FROM order_files WHERE id = ? AND order_id = ?'); $f->execute([$file, $oid]); if (!$f->fetchColumn()) $file = 0; }
        $pdo->prepare('INSERT INTO order_vendor_bills (order_id, wo_id, vendor, vendor_id, status, bill_no, bill_date, due_date, po, amount_cents, tax_cents, ship_cents, total_cents, ship_via, answers, why, file_id, source, created_by, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())')
            ->execute([$oid, (int) $w['id'], (string) $w['vendor'], $w['vendor_id'] ?? null, $dispute ? 'disputed' : 'recorded', $billNo, self::day($in['bill_date'] ?? ''), self::day($in['due_date'] ?? ''),
                mb_substr(trim((string) ($in['po'] ?? '')), 0, 60), $amount, $tax, $ship, $total, mb_substr(trim((string) ($in['ship_via'] ?? '')), 0, 80),
                json_encode($answers, JSON_UNESCAPED_UNICODE), $dispute ? $why : '', $file ?: null, $file ? 'read' : 'typed', $staff]);
        $bid = (int) $pdo->lastInsertId();
        // the answer that it shipped, with its tracking: kept on the work order too when it has none
        $trk = mb_substr(trim((string) ($in['tracking'] ?? '')), 0, 160);
        if ($trk !== '' && ($w['tracking'] ?? '') === '') { try { $pdo->prepare("UPDATE order_work_orders SET tracking = ? WHERE id = ? AND COALESCE(tracking, '') = ''")->execute([$trk, (int) $w['id']]); } catch (Throwable) {} }
        Orders::event($pdo, $oid, 'vendor_bill', 'Vendor bill recorded: ' . $w['vendor'] . '\'s invoice ' . $billNo . ', ' . Orders::usd($total) . ' (work order ' . $w['wo_no'] . ($file ? ', read from their invoice' : ', typed')
            . ')' . implode('', array_map(fn ($a) => '; ' . $a['q'] . ' ' . $a['a'], $answers)) . ($dispute ? '; disputed: ' . $why : ''), $staff);
        $qb = self::toQuickBooks($pdo, $oid, $bid);
        return 'Recorded ' . $w['vendor'] . '\'s invoice ' . $billNo . ' (' . Orders::usd($total) . ')' . ($dispute ? ', disputed' : '') . '. ' . $qb;
    }

    /** The bill made in QuickBooks against the vendor; its Id kept, or why not (shown on the line with Send it to QuickBooks). */
    public static function toQuickBooks(PDO $pdo, int $oid, int $bid): string
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $b = self::get($pdo, $oid, $bid); $o = Orders::get($pdo, $oid);
        if (!empty($b['qb_bill_id'])) return 'It\'s in QuickBooks as bill ' . $b['qb_bill_id'] . '.';
        if (!in_array($b['status'], ['recorded', 'disputed'], true)) throw new RuntimeException('Only a recorded bill goes to QuickBooks.');
        $env = (string) (($o['qb_env'] ?? '') ?: QuickBooksPay::env());
        try {
            $r = QuickBooksPay::withEnv($env === 'mock' ? '' : $env, fn () => QuickBooksPay::createBill($pdo, $b, $o, self::account($pdo))); $id = (string) $r['id'];
            $pdo->prepare("UPDATE order_vendor_bills SET qb_bill_id = ?, qb_env = ?, qb_account = ?, qb_error = '', updated_at = NOW() WHERE id = ?")->execute([$id, QuickBooksPay::env(), mb_substr((string) $r['account'], 0, 120), $bid]);
            Orders::event($pdo, $oid, 'vendor_bill', 'Vendor bill ' . $b['bill_no'] . ' made in QuickBooks (bill ' . $id . ', ' . $r['account'] . ')');
            return 'It\'s in QuickBooks as a bill against ' . $b['vendor'] . ', in ' . $r['account'] . '.';
        } catch (Throwable $x) {
            $why = mb_substr(preg_replace('/\s*\[intuit_tid [^\]]*\]/', '', $x->getMessage()), 0, 300);
            $pdo->prepare('UPDATE order_vendor_bills SET qb_error = ?, updated_at = NOW() WHERE id = ?')->execute([$why, $bid]);
            error_log('vendor bill to QuickBooks, order ' . $oid . ': ' . $x->getMessage());
            return 'QuickBooks didn\'t take it yet (' . $why . '): it\'s kept here; Send it to QuickBooks on the Vendor line tries again.';
        }
    }

    // ---- where vendor bills post in QuickBooks (the session manager for Jason, 2026-11-24): a setting chosen in the admin,
    // never .env; the choices read from QuickBooks' Cost of Goods Sold accounts; History keeps its changes. The Vendor line
    // names it before Record ("Posts to 5000 · Cost of Goods Sold ✎"). QB_COGS_ACCOUNT_ID, if an .env has it, is read once
    // only, to seed the setting.

    public const ACCOUNT = 'vendor_bill_account';

    private static function qbSetting(PDO $pdo, string $name): string
    {
        try { $st = $pdo->prepare('SELECT value FROM ' . Database::t('qb_settings') . ' WHERE name = ?'); $st->execute([$name]); return (string) ($st->fetchColumn() ?: ''); } catch (Throwable) { return ''; }
    }

    private static function label(array $a): string { return trim(($a[1] !== '' ? $a[1] . ' · ' : '') . $a[2]); }

    /** QuickBooks' Cost of Goods Sold accounts (one read per request), or [] when QuickBooks can't be read now. */
    public static function accounts(PDO $pdo): array
    {
        static $c = [];   // kept for the request once read; a failed read isn't kept, so the next ask tries again
        if ($c) return $c;
        require_once __DIR__ . '/QuickBooksPay.php';
        try { $c = QuickBooksPay::env() === 'mock' || (QuickBooksPay::ready($pdo) && QuickBooksPay::connection($pdo)) ? QuickBooksPay::cogsAccounts($pdo) : []; } catch (Throwable $x) { error_log('qb cogs accounts: ' . $x->getMessage()); $c = []; }
        return $c;
    }

    /**
     * Where a vendor bill posts: [id, label, chosen (bool)]. The setting when chosen; else seeded once from an old .env's
     * QB_COGS_ACCOUNT_ID (kept as the setting, with History); else the first Cost of Goods Sold account, preselected, not
     * yet chosen. ['', '', false] when QuickBooks has none to offer (or can't be read now).
     */
    public static function account(PDO $pdo): array
    {
        $v = self::qbSetting($pdo, self::ACCOUNT);
        if ($v !== '') { [$id, $lab] = array_pad(explode('|', $v, 2), 2, ''); return [$id, $lab, true]; }
        $acc = self::accounts($pdo);
        $seed = trim((string) (getenv('QB_COGS_ACCOUNT_ID') ?: ''));
        if ($seed !== '') foreach ($acc as $a) if ($a[0] === $seed) { self::putAccount($pdo, $a, null, 'Seeded once from QB_COGS_ACCOUNT_ID in .env'); return [$a[0], self::label($a), true]; }
        return $acc ? [$acc[0][0], self::label($acc[0]), false] : ['', '', false];
    }

    private static function putAccount(PDO $pdo, array $a, ?int $uid, string $note): void
    {
        $old = self::qbSetting($pdo, self::ACCOUNT); $new = $a[0] . '|' . self::label($a);
        if ($old === $new) return;
        $pdo->prepare('INSERT INTO ' . Database::t('qb_settings') . ' (name, value, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_by = VALUES(updated_by)')->execute([self::ACCOUNT, $new, $uid]);
        try { $pdo->prepare('INSERT INTO qb_settings_log (name, old_value, new_value, note, changed_by) VALUES (?, ?, ?, ?, ?)')->execute([self::ACCOUNT, $old === '' ? '' : (string) explode('|', $old, 2)[1], self::label($a), $note, $uid]); } catch (Throwable $x) { error_log('qb settings log: ' . $x->getMessage()); }
    }

    /** Choose where vendor bills post: one of QuickBooks' Cost of Goods Sold accounts, the change kept in History. */
    public static function setAccount(PDO $pdo, string $id, int $uid): string
    {
        foreach (self::accounts($pdo) as $a) if ($a[0] === $id) { self::putAccount($pdo, $a, $uid, 'Chosen in System Configuration → Settings'); return self::label($a); }
        throw new RuntimeException('That account isn\'t one of QuickBooks\' Cost of Goods Sold accounts now: open the list again.');
    }

    /** The setting's History, newest first: [when, from, to, note, who]. */
    public static function accountHistory(PDO $pdo, int $n = 10): array
    {
        try { return $pdo->query("SELECT l.changed_at, l.old_value, l.new_value, l.note, u.display_name FROM qb_settings_log l LEFT JOIN users u ON u.id = l.changed_by WHERE l.name = '" . self::ACCOUNT . "' ORDER BY l.id DESC LIMIT " . (int) $n)->fetchAll(PDO::FETCH_NUM); } catch (Throwable) { return []; }
    }

    /**
     * System Configuration → Settings: "Vendor bills post to" (its own post, as the page's other cards do). The choices come
     * from QuickBooks now; the first is preselected until one is chosen. Who may change it: finance and operations managers.
     */
    public static function settingsCard(PDO $pdo): string
    {
        require_once __DIR__ . '/../admin/Access.php';
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
        [$can, $why] = Access::can('backoffice/orders.edit', ['min' => 'manager', 'depts' => ['fin', 'ops']]);
        $csrf = (string) ($_SESSION['csrf_token'] ?? ''); $msg = '';
        if ($can && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['vb_account']) && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
            try { $msg = '<p data-tv-flash="ok">Vendor bills post to ' . $e(self::setAccount($pdo, (string) $_POST['vb_account'], (int) (Auth::currentUserId() ?? 0))) . ' now; the change is in its History.</p>'; }
            catch (Throwable $x) { $msg = '<p data-tv-flash="error">' . $e($x->getMessage()) . '</p>'; }
        }
        [$cur, $lab, $chosen] = self::account($pdo); $acc = self::accounts($pdo);
        // drawn in the admin kit's fold (System Configuration → Settings' other groups), opened; #vendor-bills is its anchor (the Vendor line's ✎)
        $b = '<div id="vendor-bills"><p class="ak-note" style="margin:0 0 .5rem">The QuickBooks account a vendor bill recorded on an order is made in. The list is QuickBooks\' Cost of Goods Sold accounts, read now.</p>';
        if (!$acc) $b .= '<p data-tv-status="info" data-tv-label="Not readable now:">QuickBooks didn\'t answer, or has no Cost of Goods Sold account. ' . ($lab !== '' ? 'Bills post to ' . $e($lab) . ' until it does.' : 'Add one in QuickBooks: <a href="https://qbo.intuit.com/app/chartofaccounts" target="_blank" rel="noopener">https://qbo.intuit.com/app/chartofaccounts</a>.') . '</p>';
        else {
            $b .= '<form method="post" style="display:flex;flex-wrap:wrap;gap:.4rem;align-items:end"><input type="hidden" name="csrf" value="' . $e($csrf) . '"><label style="display:grid;gap:.15rem;flex:1 1 16rem;max-width:24rem">Account<select class="ak-in" name="vb_account"' . ($can ? '' : ' disabled title="' . $e($why) . '"') . '>';
            foreach ($acc as $a) $b .= '<option value="' . $e($a[0]) . '"' . ($a[0] === $cur ? ' selected' : '') . '>' . $e(self::label($a)) . '</option>';
            $b .= '</select></label><button class="ak-b go"' . ($can ? '' : ' disabled title="' . $e($why) . '"') . '>' . ($chosen ? 'Save' : 'Choose it') . '</button>'
               . (!$chosen ? '<small style="flex-basis:100%;color:var(--tv-meta)">Not chosen yet: bills post to the first one, ' . $e($lab) . ', until you choose.</small>' : '') . '</form>';
            $hist = self::accountHistory($pdo);
            if ($hist) $b .= '<details style="margin-top:.5rem"><summary>History</summary><ul style="margin:.3rem 0 0;padding-left:1.1rem">' . implode('', array_map(fn ($r) => '<li><time datetime="' . $e(date('c', strtotime((string) $r[0]))) . '" data-tv-time>' . $e(date('M j, g:i A T', strtotime((string) $r[0]))) . '</time>: ' . ($r[1] !== '' ? $e($r[1]) . ' → ' : '') . $e($r[2]) . ' · ' . $e($r[3]) . ($r[4] ? ' · ' . $e($r[4]) : '') . '</li>', $hist)) . '</ul></details>';
        }
        $b .= '</div><script src="/js/tv-time.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/tv-time.js') . '" defer></script>';
        $status = $lab !== '' ? $lab . ($chosen ? '' : ' (not chosen yet)') : 'Not readable now';
        return $msg . (function_exists('tv_admin_fold') ? tv_admin_fold('Vendor bills post to', $status, $chosen ? '' : 'warn', '', $b, true) : '<div class="hb-card tv-bleed"><h3>Vendor bills post to</h3>' . $b . '</div>');
    }

    /** ✎ a recorded bill's facts, the old values to History. One already in QuickBooks is changed there (↗), not here. */
    public static function edit(PDO $pdo, int $oid, int $bid, array $in, int $staff): void
    {
        $b = self::get($pdo, $oid, $bid);
        if (!empty($b['qb_bill_id'])) throw new RuntimeException('It\'s in QuickBooks as bill ' . $b['qb_bill_id'] . ': change it there, so the two stay the same.');
        if (!in_array($b['status'], ['recorded', 'disputed'], true)) throw new RuntimeException('Only a recorded bill is edited.');
        $new = ['bill_no' => mb_substr(trim((string) ($in['bill_no'] ?? $b['bill_no'])), 0, 40), 'bill_date' => self::day($in['bill_date'] ?? (string) $b['bill_date']),
                'due_date' => self::day($in['due_date'] ?? (string) $b['due_date']), 'total_cents' => isset($in['total']) ? self::cents($in['total']) : (int) $b['total_cents']];
        if ($new['bill_no'] === '' || $new['total_cents'] <= 0) throw new RuntimeException('Their invoice number and the total, please.');
        $was = [];
        foreach ($new as $k => $v) if ((string) $v !== (string) $b[$k]) $was[] = ['bill_no' => 'invoice', 'bill_date' => 'date', 'due_date' => 'due', 'total_cents' => 'total'][$k] . ' ' . ($k === 'total_cents' ? Orders::usd((int) $b[$k]) : ((string) $b[$k] ?: 'none')) . ' → ' . ($k === 'total_cents' ? Orders::usd((int) $v) : ((string) $v ?: 'none'));
        if (!$was) return;
        $pdo->prepare('UPDATE order_vendor_bills SET bill_no = ?, bill_date = ?, due_date = ?, total_cents = ?, amount_cents = ? - tax_cents - ship_cents, updated_at = NOW() WHERE id = ?')
            ->execute([$new['bill_no'], $new['bill_date'], $new['due_date'], $new['total_cents'], $new['total_cents'], $bid]);
        Orders::event($pdo, $oid, 'vendor_bill', 'Vendor bill ' . $b['bill_no'] . ' edited: ' . implode('; ', $was), $staff);
    }

    /** Cancel the record (decisions/0178's note): a bill recorded here and not in QuickBooks goes, as if never recorded; History keeps a line. */
    public static function cancel(PDO $pdo, int $oid, int $bid, int $staff): void
    {
        $b = self::get($pdo, $oid, $bid);
        if (!empty($b['qb_bill_id'])) throw new RuntimeException('It\'s in QuickBooks as bill ' . $b['qb_bill_id'] . ': void it there, so the two stay the same.');
        if ($b['status'] === 'cancelled') return;
        $pdo->prepare("UPDATE order_vendor_bills SET status = 'cancelled', updated_at = NOW() WHERE id = ?")->execute([$bid]);
        Orders::event($pdo, $oid, 'vendor_bill', $b['status'] === 'none' ? 'No longer "not billed by them": their bill is expected' : 'Vendor bill ' . $b['bill_no'] . ' (' . Orders::usd((int) $b['total_cents']) . ') cancelled as a record', $staff);
    }

    /** Not billed by them (their own job, a sample, a remake on them): no bill is coming, with why. */
    public static function notBilled(PDO $pdo, int $oid, string $why, int $staff): void
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run 2026-11-23_m1b_vendor_bills.sql first.');
        $why = mb_substr(trim(preg_replace('/\s+/u', ' ', $why)), 0, 300);
        if (mb_strlen($why) < 3) throw new RuntimeException('Say why no bill is coming: it\'s kept on the order.');
        $o = Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.');
        $st = self::state($pdo, $o);
        if (in_array($st['key'], ['billed', 'disputed'], true)) throw new RuntimeException('They billed it already.');
        if ($st['key'] === 'not_billed') return;
        $w = $st['wos'][0] ?? null;
        $pdo->prepare("INSERT INTO order_vendor_bills (order_id, wo_id, vendor, status, why, created_by, created_at) VALUES (?, ?, ?, 'none', ?, ?, NOW())")
            ->execute([$oid, $w ? (int) $w['id'] : null, $w ? (string) $w['vendor'] : '', $why, $staff]);
        Orders::event($pdo, $oid, 'vendor_bill', 'Not billed by the vendor: ' . $why, $staff);
    }

    /** Dispute… a recorded bill, with why (kept on the bill and in History); Settled puts it back to recorded. */
    public static function dispute(PDO $pdo, int $oid, int $bid, string $why, bool $on, int $staff): void
    {
        $b = self::get($pdo, $oid, $bid);
        if (!in_array($b['status'], ['recorded', 'disputed'], true)) throw new RuntimeException('Only a recorded bill is disputed.');
        $why = mb_substr(trim(preg_replace('/\s+/u', ' ', $why)), 0, 300);
        if ($on && mb_strlen($why) < 3) throw new RuntimeException('Say what\'s wrong with it: it\'s kept on the bill.');
        $pdo->prepare('UPDATE order_vendor_bills SET status = ?, why = ?, updated_at = NOW() WHERE id = ?')->execute([$on ? 'disputed' : 'recorded', $on ? $why : '', $bid]);
        Orders::event($pdo, $oid, 'vendor_bill', $on ? 'Vendor bill ' . $b['bill_no'] . ' disputed: ' . $why : 'Vendor bill ' . $b['bill_no'] . ': the dispute is settled' . ($why !== '' ? ' (' . $why . ')' : ''), $staff);
    }
}
