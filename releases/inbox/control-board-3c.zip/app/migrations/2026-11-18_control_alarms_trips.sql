-- decisions/0171 §7's note (Jason, 2026-11-18, release 3c): a trip waits for an admin's Resolve. control_alarms keeps when
-- it tripped, when its reading was good again, what it stopped, and who resolved it with what fixed it. Add-only, safe to
-- run twice; the table is the site's own (ControlAlarms::ensure makes it), so nothing runs where it isn't there yet.
SET @s = (SELECT IF((SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'control_alarms') = 1 AND COUNT(*) = 0,
  'ALTER TABLE control_alarms ADD COLUMN tripped_at DATETIME NULL, ADD COLUMN good_at DATETIME NULL, ADD COLUMN good_how VARCHAR(255) NULL, ADD COLUMN stopped VARCHAR(400) NULL, ADD COLUMN resolved_uid INT UNSIGNED NULL, ADD COLUMN resolved_name VARCHAR(80) NULL, ADD COLUMN resolved_at DATETIME NULL, ADD COLUMN resolve_note VARCHAR(400) NULL',
  'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'control_alarms' AND COLUMN_NAME = 'tripped_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
