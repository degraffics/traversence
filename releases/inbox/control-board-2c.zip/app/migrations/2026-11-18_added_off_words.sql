-- The services added switched off on 2026-11-15 still read "nothing calls it until Release B and a person's switch".
-- Release B has shipped, so each gets its real reason (Operations::ADDED_OFF_WHY). Only rows still holding the old words
-- change: a person's later switch or reason stands. Safe to run twice (the second run finds no old words).
UPDATE automation_switches SET why = CASE ref
    WHEN 'azcc' THEN 'Off until a person switches it on: the Commission''s new site (arizonabusinesscenter.azcc.gov) blocks us until our records request is answered'
    WHEN 'nmsos' THEN 'Off until a person switches it on: waits on its address fix and our records request'
    WHEN 'azlicences' THEN 'Off until a person switches it on: the licence sites need Cloudflare set up by hand first (queue 3a)'
    ELSE 'Off until a person switches it on: added switched off (2026-11-15)' END
  WHERE kind = 'service' AND why LIKE 'Added switched off (Jason, 2026-11-15)%';
