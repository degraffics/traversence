// js/tv-domains.js — Shop → Domains and the account's Domains tab (decisions/0169 §1a), with the account's wallet
// (decisions/0166 §6a). One script for both, drawn into [data-dm-root] from /api/domains.php:
//   data-dm-mode="shop": search a name, see our price a year, the registrant's details, Add to cart;
//   data-dm-mode="tab": the account's domains (renew, auto-renew, where it points, DNS, email records, transfer away,
//   history, Something isn't right), a domain owned elsewhere listed for pointing only, the storefront's domain read
//   only, and the wallet (cards, the default, what each pays for, Replace).
// No browser dialogs: TvAsk.gate / say / busy. Cards go from the browser to Intuit for a one-time token (Go.cardForm).
(function () {
  'use strict';
  var root = document.querySelector('[data-dm-root]');
  if (!root || !window.Go) return;
  var mode = root.getAttribute('data-dm-mode'), acct = { type: root.getAttribute('data-type') || 'user', id: +(root.getAttribute('data-id') || 0) };
  var S = null, open = {}, E = Go.esc, M = Go.money;
  function api(b) { b.type = b.type || acct.type; b.id = b.id || acct.id; return Go.call('/api/domains.php', b); }
  function say(m, el, bad) { if (window.TvAsk) TvAsk.say(m, { anchor: el, bad: !!bad }); }
  function busy(el, on) { if (window.TvAsk && el) TvAsk.busy(el, on); }
  function day(iso) { if (!iso) return ''; var d = new Date(iso); return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }); }
  function when(iso) { return window.TvTime && TvTime.fmt ? TvTime.fmt(iso) : new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short', timeZoneName: 'short' }); }
  function status(kind, label, text) { return '<p data-tv-status="' + kind + '" data-tv-label="' + E(label) + '">' + text + '</p>'; }
  // status lines drawn after the page loaded become the site's notice boxes as they appear (TvAsk.statuses; it replaces
  // each <p data-tv-status>, so this never loops). Before, the Test mode note showed as plain text (Jason, 2026-11-17).
  if (window.MutationObserver && window.TvAsk && TvAsk.statuses) new MutationObserver(function () { if (root.querySelector('p[data-tv-status]')) TvAsk.statuses(root); }).observe(root, { childList: true, subtree: true });
  function act(btn, b, done) {
    busy(btn, true);
    return api(b).then(function (d) { busy(btn, false); if (d.message) say(d.message, btn); return done ? done(d) : load(); })
      .catch(function (x) { busy(btn, false); say(x.message, btn, true); });
  }
  function cardsUsable() { return (S.cards || []).filter(function (c) { return c.usable; }); }
  function cardPicker(name, withNew) {
    var cs = cardsUsable();
    return '<select name="' + name + '" class="dm-in" aria-label="The card">' + cs.map(function (c) { return '<option value="wallet:' + c.id + '">' + E(c.label) + (c['default'] ? ' (default)' : '') + '</option>'; }).join('')
      + (withNew ? '<option value="new"' + (cs.length ? '' : ' selected') + '>A new card</option>' : '') + '</select>';
  }
  // a new card's one-time token, from the card form drawn into host (amount 0: only saved)
  function withNewCard(host, amount, label, note, pay) {
    host.hidden = false;
    Go.cardForm(host, { id: 'dm' + Date.now(), subtotal_cents: amount, tax_cents: 0, total_cents: amount }, S.pay, {
      summary: false, amount: amount, tokens: 1, label: label, note: note, pay: pay, onPaid: function () { host.innerHTML = ''; host.hidden = true; load(); },
      onCancel: function () { host.innerHTML = ''; host.hidden = true; }
    });
  }

  function load() {
    return api({ action: 'status' }).then(function (d) { S = d; (mode === 'shop' ? paintShop : paintTab)(); })
      .catch(function (x) { root.innerHTML = status('bad', 'Error:', E(x.message) + ' Questions: <a href="mailto:support@traversence.com">support@traversence.com</a>.'); });
  }

  // ---- Shop → Domains ----------------------------------------------------------------------------------------------
  var R = [];
  function paintShop() {
    var acs = S.accounts || [];
    var h = (S.test ? status('info', 'Test mode:', 'Search shows which names are really free and Name.com\'s real prices. Buying is a test: registered in Name.com\'s sandbox and paid in QuickBooks\' sandbox, so nothing real is bought or charged. A name the sandbox holds can\'t be test-bought.') : '')
      + (!S.open ? status('info', 'Coming soon:', E(S.why) + ' You can still list a domain you own in <a href="' + tabUrl() + '">your Domains</a>.') : '');
    h += '<section class="dm-card tv-bleed"><h2 class="dm-h">Find your domain</h2><p class="dm-note">Search a name: we show it and the usual endings with our price a year. It\'s registered in your name with privacy on (your details stay out of public records), and it\'s yours to keep, renew or move.</p>'
      + (acs.length > 1 ? '<label class="dm-l">Buying for <select id="dm-for" class="dm-in">' + acs.map(function (a) { return '<option value="' + a.type + ':' + a.id + '"' + (a.type === acct.type && a.id === acct.id ? ' selected' : '') + '>' + E(a.name) + '</option>'; }).join('') + '</select></label>' : '')
      + '<form id="dm-q" class="dm-row"><input class="dm-in" name="q" maxlength="80" placeholder="The name you\'d like, like pinecafe" aria-label="Search for a domain" autocapitalize="none" spellcheck="false"' + (S.open ? '' : ' disabled') + ' style="flex:1;min-width:12rem"><button class="go-btn main"' + (S.open ? '' : ' disabled title="' + E(S.why) + '"') + '>Search</button></form>'
      + '<div id="dm-res"></div><div id="dm-buy" hidden></div></section>'
      + '<p class="dm-note"><a href="' + tabUrl() + '">Your domains</a> · <a href="/qr/cart.php">Your cart</a> · <a href="/faq.php#can-i-buy-a-domain-on-traversence">About domains</a></p>';
    root.innerHTML = h;
    var f = document.getElementById('dm-for');
    if (f) f.addEventListener('change', function () { var p = f.value.split(':'); acct = { type: p[0], id: +p[1] }; load(); });
    document.getElementById('dm-q').addEventListener('submit', function (e) {
      e.preventDefault(); var b = e.target.querySelector('button'), q = e.target.q.value.trim();
      if (!q) return say('Type the name you\'d like.', b, true);
      busy(b, true);
      api({ action: 'search', q: q }).then(function (d) { busy(b, false); R = d.results || []; TERMS = d.terms || TERMS; paintResults(); }).catch(function (x) { busy(b, false); say(x.message, b, true); });
    });
  }
  var TERMS = [1, 2, 3, 4, 5, 10];   // years a domain can be bought for; the search's answer says (AccountDomains::TERMS)
  // a term chosen on a row: Name.com's real total for those years (its first-year discount, then its price for the rest)
  root.addEventListener('change', function (e) {
    var sel = e.target.closest('[data-yrs]'); if (!sel || mode !== 'shop') return;
    var i = +sel.getAttribute('data-yrs'), r = R[i], span = root.querySelector('[data-price="' + i + '"]'), was = r.years || 1, row = sel.closest('.dm-res');
    var clear = function () { if (row.__note) { row.__note.remove(); row.__note = null; } };   // a notice under the row goes once it's answered
    busy(span, true); sel.disabled = true;
    api({ action: 'quote', domain: r.domain, years: +sel.value }).then(function (d) {
      clear(); d.result.terms = d.result.terms || r.terms; R[i] = d.result; span.innerHTML = E(d.result.label) + ' <small class="dm-note">(' + E(d.result.renew_label) + ')</small>';
      var buy = document.getElementById('dm-buy'); if (buy && !buy.hidden && buy.getAttribute('data-for') === r.domain) { buy.hidden = true; buy.innerHTML = ''; }   // its form showed the old term
    }).catch(function (x) { sel.value = String(was); clear(); row.__note = window.TvAsk ? TvAsk.say(x.message, { anchor: row, bad: true }) : null; })   // under the row, not inside it
      .then(function () { busy(span, false); sel.disabled = false; });
  });
  function paintResults() {
    var el = document.getElementById('dm-res');
    el.innerHTML = R.length ? R.map(function (r, i) {
      return '<div class="dm-res"><b>' + E(r.domain) + '</b>' + (r.premium ? '<span class="dm-note">Premium name, priced by its owner</span><a class="go-btn" href="mailto:support@traversence.com?subject=' + encodeURIComponent('A premium domain: ' + r.domain) + '">Ask us its price</a>'
        : r.ok ? '<select class="dm-yrs" data-yrs="' + i + '" aria-label="Years for ' + E(r.domain) + '" title="How many years">' + (r.terms && r.terms.length ? r.terms : TERMS).map(function (y) { return '<option value="' + y + '"' + (y === (r.years || 1) ? ' selected' : '') + '>' + y + (y === 1 ? ' year' : ' years') + '</option>'; }).join('') + '</select>'
          + '<span data-price="' + i + '">' + E(r.label) + ' <small class="dm-note">(' + E(r.renew_label) + ')</small></span><button type="button" class="go-btn main" data-pick="' + i + '"' + (S.can.pay ? '' : ' disabled title="Buying for this business needs Domain and Plan & billing (edit) on its team"') + '>Add to cart</button>'
        : '<span class="dm-note">Taken</span>') + '</div>';
    }).join('') : '<p class="dm-note">Nothing to offer for that. Try another name.</p>';
    if (R.length && R[0].test_buy && R[0].real === false) el.insertAdjacentHTML('afterbegin', status('info', 'From the test system:', 'Name.com\'s live lookup didn\'t answer, so these are its sandbox\'s answers and prices, not the real ones. Search again in a minute for real ones.'));   // never passed off as real
  }
  root.addEventListener('click', function (e) {
    var p = e.target.closest('[data-pick]'); if (!p || mode !== 'shop') return;
    var r = R[+p.getAttribute('data-pick')], box = document.getElementById('dm-buy');
    var me = S.me || {};
    var fld = function (k, l, ac, extra) { return '<label class="dm-l">' + l + '<input class="dm-in" name="' + k + '" autocomplete="' + ac + '" maxlength="120"' + (extra || '') + '></label>'; };
    box.hidden = false; box.setAttribute('data-for', r.domain);
    box.innerHTML = '<h3 class="dm-h3">' + E(r.domain) + ', ' + E(r.label) + '</h3><p class="dm-note">The registrant: the person it\'s registered to' + (acct.type === 'listing' ? ', for ' + E(S.name) : '') + '. Use real details: Name.com emails them to confirm (ICANN\'s rule). WHOIS privacy keeps them out of public records.</p>'
      + '<form id="dm-who"><div class="dm-who">' + fld('first', 'First name', 'given-name', ' data-spell') + fld('last', 'Last name', 'family-name', ' data-spell') + fld('email', 'Email', 'email', ' type="email" spellcheck="false"') + fld('phone', 'Phone', 'tel', ' type="tel" spellcheck="false"')
      + fld('address1', 'Street address', 'street-address', ' data-spell') + fld('city', 'Town', 'address-level2', ' data-spell') + fld('state', 'State', 'address-level1', ' maxlength="2" spellcheck="false"') + fld('zip', 'ZIP', 'postal-code', ' spellcheck="false"') + '</div>'
      + '<label class="dm-tick"><input type="checkbox" name="adult"> I\'m 18 or older, and so is the registrant.</label>'
      + '<p class="dm-note">Paid in the cart, before it\'s registered. Domain names aren\'t refundable once registered; one that can\'t be registered is refunded at once.</p>'
      + '<div class="dm-row"><button class="go-btn main">Add to cart</button><button type="button" class="go-btn" data-dm-back>Back</button></div></form>';
    box.querySelector('[name=email]').value = me.email || '';
    box.querySelector('[data-dm-back]').addEventListener('click', function () { box.hidden = true; box.innerHTML = ''; });
    box.querySelector('#dm-who').addEventListener('submit', function (ev) {
      ev.preventDefault(); var f = ev.target, b = f.querySelector('button'), who = {};
      ['first', 'last', 'email', 'phone', 'address1', 'city', 'state', 'zip'].forEach(function (k) { who[k] = f[k].value.trim(); });
      busy(b, true);
      api({ action: 'cart_add', domain: r.domain, years: r.years || 1, price: r.price, who: who, adult: f.adult.checked }).then(function () {
        busy(b, false); box.innerHTML = status('ok', 'Success:', E(r.domain) + ' is in your cart. <a href="/qr/cart.php">Open the cart</a> to pay, or search for another.');
        Go.status && Go.status().catch(function () {});
      }).catch(function (x) { busy(b, false); say(x.message, b, true); });
    });
    box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  });
  function tabUrl() { return acct.type === 'listing' ? '/business/' + acct.id + '/domains' : '/user/domains/'; }

  // ---- the Domains tab -------------------------------------------------------------------------------------------------
  function paintTab() {
    var h = (S.test ? status('info', 'Test mode:', 'This account\'s domains are bought in Name.com\'s sandbox and paid in QuickBooks\' sandbox: nothing real is registered or charged.') : '');
    h += '<div class="dm-row" style="margin-bottom:.6rem"><a class="go-btn main" href="/shop/domains.php?for=' + acct.type + ':' + acct.id + '">Find a domain</a><button type="button" class="go-btn" data-dm-own>Add a domain you own</button></div>'
      + '<div id="dm-ownbox" hidden></div>';
    if (S.storefront) h += '<section class="dm-card tv-bleed"><div class="dm-top"><a class="dm-name" href="https://' + E(S.storefront.domain) + '" target="_blank" rel="noopener">' + E(S.storefront.domain) + '</a></div>'
      + '<p class="dm-note">Your storefront\'s domain · ' + E(S.storefront.status) + ' · ' + E(S.storefront.source) + (S.storefront.expires ? ' · paid until ' + E(S.storefront.expires) : '') + '. It\'s managed on the storefront page.</p><a class="go-btn" href="' + E(S.storefront.url) + '">Open Storefront &amp; pages</a></section>';
    h += (S.domains || []).length ? S.domains.map(domCard).join('') : '<section class="dm-card tv-bleed"><p class="dm-note">No domains yet. Find one in the Shop, or list one you own elsewhere.</p></section>';
    h += walletHtml();
    root.innerHTML = h;
    Object.keys(open).forEach(function (k) { var p = open[k]; if (p) showPanel(+k, p); });
  }
  function domCard(d) {
    var bought = d.source === 'bought', live = d.status === 'active';
    var lines = [];
    if (bought) lines.push((d.expires_at ? (d.status === 'expired' ? 'Expired ' : 'Paid until ') + day(d.expires_at) : '') + (d.auto_renew ? ' · renews ' + M(d.renew_cents) + ' a year on ' + E(d.card ? d.card.label : 'no card yet') + ', two weeks before' : ' · won\'t renew by itself'));
    else lines.push('Registered elsewhere: listed here for pointing only. Its records are set where it\'s registered.');
    if (bought) lines.push('Points: ' + E(d.points_label) + (d.points === 'forward' ? ' (' + E(d.forward_to) + ')' : d.points === 'nameservers' ? ' (' + E(d.nameservers.join(', ')) + ')' : ''));
    var warn = d.attention ? status('bad', 'Needs attention:', E(d.attention) + ' Our team has been told.') : d.renew_fails ? status('bad', 'Renewal declined:', 'Its card was declined' + (d.renew_next ? '; tried again ' + day(d.renew_next) : '') + '. Replace the card in the wallet below, or Renew now.') : '';
    var b = function (k, l, dis) { return '<button type="button" class="go-btn" data-dm="' + k + '" data-d="' + d.id + '"' + (dis ? ' disabled title="' + E(dis) + '"' : '') + '>' + l + '</button>'; };
    var notLive = live ? '' : 'Renew it first';
    var acts = bought ? b('renew', 'Renew now', d.status === 'transferred' ? 'It has moved away' : '') + b(d.auto_renew ? 'auto_off' : 'auto_on', d.auto_renew ? 'Stop auto-renew' : 'Auto-renew', d.status === 'transferred' ? 'It has moved away' : '')
      + b('points', 'Where it points', notLive) + b('dns', 'DNS records', notLive) + (d.email.length ? b('email', 'Email records') : '') + b('transfer', 'Transfer away', notLive)
      : b('own_remove', 'Take it off the list');
    acts += b('history', 'History') + b('ticket', 'Something isn\'t right');
    return '<section class="dm-card tv-bleed" id="d' + d.id + '"><div class="dm-top"><a class="dm-name" href="https://' + E(d.domain) + '" target="_blank" rel="noopener">' + E(d.domain) + '</a><span class="dm-pill">' + E(d.status_label) + (d.test ? ' · test' : '') + '</span></div>'
      + warn + '<p class="dm-note">' + lines.join('<br>') + '</p><div class="dm-row dm-acts">' + acts + '</div><div class="dm-panel" data-panel="' + d.id + '" hidden></div></section>';
  }
  function dom(id) { return (S.domains || []).filter(function (d) { return d.id === id; })[0]; }
  function panel(id) { return root.querySelector('[data-panel="' + id + '"]'); }
  function showPanel(id, what) {
    var d = dom(id), p = panel(id); if (!d || !p) return;
    open[id] = what; p.hidden = false;
    var close = '<button type="button" class="go-btn" data-dm="close" data-d="' + id + '">Close</button>';
    if (what === 'renew') {
      p.innerHTML = '<h3 class="dm-h3">Renew ' + E(d.domain) + ' for a year</h3><p class="dm-note">' + M(d.renew_cents) + ' (Name.com\'s price now, plus ours: it\'s checked again when you pay). Paid now; a year is added to ' + E(day(d.expires_at)) + '.</p>'
        + (S.can.pay ? '<div class="dm-row"><label class="dm-l">Pay with ' + cardPicker('pick', true) + '</label><button type="button" class="go-btn main" data-dm="renew_go" data-d="' + id + '">Renew it</button>' + close + '</div><div data-cardbox hidden></div>'
          : '<p class="dm-note">Paying needs Plan &amp; billing (edit) on the team.</p><div class="dm-row"><button type="button" class="go-btn" data-dm="renew_cart" data-d="' + id + '">Put it in the cart instead</button>' + close + '</div>');
    } else if (what === 'auto_on') {
      p.innerHTML = '<h3 class="dm-h3">Auto-renew ' + E(d.domain) + '</h3><p class="dm-note">Charged two weeks before it runs out, each year, on the card you choose. That card is locked in the wallet while it pays for this: it can be replaced, not removed.</p>'
        + (cardsUsable().length ? '<div class="dm-row"><label class="dm-l">On ' + cardPicker('pick', false) + '</label><button type="button" class="go-btn main" data-dm="auto_go" data-d="' + id + '">Turn it on</button>' + close + '</div>'
          : status('info', 'First:', 'Add a card to the wallet below, then turn auto-renew on.') + '<div class="dm-row">' + close + '</div>');
    } else if (what === 'points') {
      p.innerHTML = '<h3 class="dm-h3">Where ' + E(d.domain) + ' points</h3>'
        + '<form data-f="forward" data-d="' + id + '" class="dm-sub"><b>Forward to another address</b><div class="dm-row"><input class="dm-in" name="to" maxlength="480" placeholder="https://example.com/page" value="' + E(d.forward_to) + '" aria-label="Forward to" spellcheck="false" style="flex:1;min-width:12rem"><button class="go-btn main">Forward it</button></div></form>'
        + '<div class="dm-sub"><b>Its own DNS records</b><p class="dm-note">Edit them here (DNS records): an A record for a website elsewhere, MX for email, TXT to prove it\'s yours.</p><button type="button" class="go-btn" data-dm="dns" data-d="' + id + '">DNS records</button></div>'
        + '<form data-f="ns" data-d="' + id + '" class="dm-sub"><b>Nameservers set elsewhere</b><p class="dm-note">If your DNS is hosted elsewhere (Cloudflare, your web host), put its nameservers here, one a line. Empty goes back to Name.com\'s, edited here.</p><textarea class="dm-in" name="list" rows="3" spellcheck="false" aria-label="Nameservers">' + E((d.nameservers || []).join('\n')) + '</textarea><div class="dm-row"><button class="go-btn main">Save nameservers</button>' + close + '</div></form>'
        + '<p class="dm-note">Using it for a storefront comes with the Storefront app.</p>';
    } else if (what === 'dns') {
      p.innerHTML = '<h3 class="dm-h3">DNS records for ' + E(d.domain) + '</h3><p class="dm-note">Loading…</p>';
      api({ action: 'records', domain: id }).then(function (r) {
        var rows = (r.records || []).map(function (x) {
          return '<div class="dm-r" role="row"><span><code>' + E(x.host || '@') + '</code></span><span>' + E(x.type) + '</span><span class="dm-v"><code>' + E(x.answer) + '</code>' + (x.type === 'MX' ? ' <small>(priority ' + x.priority + ')</small>' : '') + '</span>'
            + '<span><button type="button" class="dm-x" data-dm="rec_del" data-d="' + id + '" data-rid="' + x.id + '" title="Remove this record" aria-label="Remove this record">×</button></span></div>';
        }).join('');
        p.innerHTML = '<h3 class="dm-h3">DNS records for ' + E(d.domain) + '</h3>' + (d.points === 'nameservers' ? status('info', 'Note:', 'Its nameservers are elsewhere, so these records aren\'t used until you go back to Name.com\'s (Where it points).') : '')
          + '<div class="dm-tbl" role="table"><div class="dm-r dm-hd" role="row"><span>Name</span><span>Type</span><span>Value</span><span></span></div>' + (rows || '<p class="dm-note">No records yet.</p>') + '</div>'
          + '<form data-f="rec" data-d="' + id + '" class="dm-sub"><b>Add a record</b><div class="dm-who"><label class="dm-l">Name<input class="dm-in" name="host" placeholder="@ or www" spellcheck="false" maxlength="120"></label>'
          + '<label class="dm-l">Type<select class="dm-in" name="type">' + (S.types || []).map(function (t) { return '<option>' + t + '</option>'; }).join('') + '</select></label>'
          + '<label class="dm-l">Value<input class="dm-in" name="answer" placeholder="203.0.113.10" spellcheck="false" maxlength="1000"></label><label class="dm-l">Priority (MX)<input class="dm-in" name="priority" type="number" min="0" max="65535" value="10"></label></div>'
          + '<div class="dm-row"><button class="go-btn main">Add it</button>' + close + '</div></form>';
      }).catch(function (x) { p.innerHTML = status('bad', 'Error:', E(x.message)) + close; });
    } else if (what === 'email') {
      p.innerHTML = '<h3 class="dm-h3">Email records for ' + E(d.domain) + '</h3><p class="dm-note">These let mail from Traversence go out as @' + E(d.domain) + ' (coming with email from your account). ' + (d.email_ok ? '<b>Found.</b>' : 'Not found yet.') + '</p>'
        + '<div class="dm-tbl" role="table">' + d.email.map(function (r) { return '<div class="dm-r" role="row"><span><code>' + E(r[0]) + '</code></span><span>' + E(r[1]) + '</span><span class="dm-v"><code>' + E(r[2]) + '</code></span><span></span></div>'; }).join('') + '</div>'
        + '<div class="dm-row"><button type="button" class="go-btn main" data-dm="email_go" data-d="' + id + '">Add them for me</button>' + close + '</div>';
    } else if (what === 'history') {
      p.innerHTML = '<h3 class="dm-h3">History</h3><p class="dm-note">Loading…</p>';
      api({ action: 'history', domain: id }).then(function (r) {
        p.innerHTML = '<h3 class="dm-h3">History</h3><ul class="dm-hist">' + ((r.history || []).map(function (x) { return '<li><time datetime="' + E(x.at) + '" data-tv-time>' + E(when(x.at)) + '</time> ' + E(x.note) + (x.order ? ' <small>(order ' + x.order + ')</small>' : '') + '</li>'; }).join('') || '<li>Nothing yet.</li>') + '</ul><div class="dm-row">' + close + '</div>';
      }).catch(function (x) { p.innerHTML = status('bad', 'Error:', E(x.message)) + close; });
    } else if (what === 'ticket') {
      p.innerHTML = '<form data-f="ticket" data-d="' + id + '"><h3 class="dm-h3">Something isn\'t right with ' + E(d.domain) + '?</h3><p class="dm-note">Tell us what\'s happening. It opens a support ticket; our team writes back by email (or write to <a href="mailto:support@traversence.com">support@traversence.com</a>).</p>'
        + '<textarea class="dm-in" name="words" rows="4" maxlength="2000" data-spell aria-label="What isn\'t right"></textarea><div class="dm-row"><button class="go-btn main">Send it to our team</button>' + close + '</div></form>';
    } else if (what === 'transfer') {
      p.innerHTML = '<h3 class="dm-h3">Move ' + E(d.domain) + ' to another registrar</h3><p class="dm-note">We unlock it and show its transfer code once (it isn\'t kept here). Auto-renew stops: the new registrar renews it. A transfer usually adds a year there.</p>'
        + '<div class="dm-row"><button type="button" class="go-btn main" data-dm="transfer_go" data-d="' + id + '">Unlock and show the code</button>' + close + '</div><p class="dm-code" hidden></p>';
    }
  }
  root.addEventListener('click', function (e) {
    if (mode !== 'tab') return;
    if (e.target.closest('[data-dm-own]')) {
      var ob = document.getElementById('dm-ownbox'); ob.hidden = !ob.hidden;
      ob.innerHTML = '<form data-f="own" class="dm-card tv-bleed"><b>A domain you own elsewhere</b><p class="dm-note">Listed here for pointing only: its records stay where it\'s registered (GoDaddy, Namecheap…).</p><div class="dm-row"><input class="dm-in" name="domain" placeholder="yourname.com" maxlength="190" autocapitalize="none" spellcheck="false" aria-label="Your domain" style="flex:1;min-width:12rem"><button class="go-btn main">Add it</button></div></form>';
      return;
    }
    var b = e.target.closest('[data-dm]'); if (!b) return;
    var k = b.getAttribute('data-dm'), id = +b.getAttribute('data-d'), d = dom(id), p = panel(id);
    if (k === 'close') { open[id] = null; p.hidden = true; p.innerHTML = ''; return; }
    if (['renew', 'auto_on', 'points', 'dns', 'email', 'history', 'ticket', 'transfer'].indexOf(k) >= 0) return showPanel(id, k);
    if (k === 'auto_off') { if (!TvAsk.gate(b, 'Stop auto-renew for ' + d.domain + '? It stays yours until ' + day(d.expires_at) + '.', { yes: 'Stop it' })) return; return act(b, { action: 'auto_renew', domain: id, on: false }); }
    if (k === 'auto_go') return act(b, { action: 'auto_renew', domain: id, on: true, pick: p.querySelector('[name=pick]').value }, function () { open[id] = null; return load(); });
    if (k === 'renew_cart') return act(b, { action: 'renew_cart', domain: id }, function () { location.href = '/qr/cart.php'; });
    if (k === 'renew_go') {
      var pick = p.querySelector('[name=pick]').value;
      if (pick === 'new') return withNewCard(p.querySelector('[data-cardbox]'), d.renew_cents, 'Renew for ' + M(d.renew_cents), 'Your card is kept in the wallet for its renewals.', function (t) { return api({ action: 'renew_now', domain: id, pick: t }); });
      if (!TvAsk.gate(b, 'Renew ' + d.domain + ' for a year, about ' + M(d.renew_cents) + '?', { yes: 'Renew it' })) return;
      return act(b, { action: 'renew_now', domain: id, pick: pick }, function () { open[id] = null; return load(); });
    }
    if (k === 'email_go') return act(b, { action: 'email_add', domain: id });
    if (k === 'rec_del') { if (!TvAsk.gate(b, 'Remove this record?', { yes: 'Remove', danger: true })) return; return act(b, { action: 'record_delete', domain: id, rid: +b.getAttribute('data-rid') }, function () { showPanel(id, 'dns'); }); }
    if (k === 'transfer_go') {
      if (!TvAsk.gate(b, 'Unlock ' + d.domain + ' and show its transfer code?', { yes: 'Unlock it' })) return;
      return act(b, { action: 'transfer', domain: id }, function (r) { var c = p.querySelector('.dm-code'); c.hidden = false; c.innerHTML = status('ok', 'Transfer code:', '<code>' + E(r.code) + '</code> Copy it now: it isn\'t shown again.'); });
    }
    if (k === 'own_remove') { if (!TvAsk.gate(b, 'Take ' + d.domain + ' off your list?', { yes: 'Take it off', danger: true })) return; return act(b, { action: 'own_remove', domain: id }); }
    // the wallet
    var cid = +b.getAttribute('data-card');
    if (k === 'w_add') return withNewCard(document.getElementById('dm-wbox'), 0, 'Save the card', 'Saved in the wallet; nothing is charged now.', function (t) { return api({ action: 'wallet_add', token: t }); });
    if (k === 'w_default') return act(b, { action: 'wallet_default', card: cid });
    if (k === 'w_remove') { if (!TvAsk.gate(b, 'Remove this card from the wallet?', { yes: 'Remove', danger: true })) return; return act(b, { action: 'wallet_remove', card: cid }); }
    if (k === 'w_replace') {
      var box = root.querySelector('[data-wrep="' + cid + '"]'); box.hidden = false;
      var others = cardsUsable().filter(function (c) { return c.id !== cid; });
      box.innerHTML = '<div class="dm-row"><label class="dm-l">Replace it with <select class="dm-in" name="rep">' + others.map(function (c) { return '<option value="wallet:' + c.id + '">' + E(c.label) + '</option>'; }).join('') + '<option value="new">A new card</option></select></label>'
        + '<button type="button" class="go-btn main" data-dm="w_rep_go" data-card="' + cid + '">Replace it</button></div><div data-cardbox hidden></div>';
      return;
    }
    if (k === 'w_rep_go') {
      var bx = root.querySelector('[data-wrep="' + cid + '"]'), v = bx.querySelector('[name=rep]').value;
      if (v === 'new') return withNewCard(bx.querySelector('[data-cardbox]'), 0, 'Save and replace', 'The new card pays for everything this one did; a declined renewal is tried on it at once.', function (t) { return api({ action: 'wallet_replace', card: cid, pick: t }); });
      return act(b, { action: 'wallet_replace', card: cid, pick: v });
    }
  });
  root.addEventListener('submit', function (e) {
    var f = e.target.closest('[data-f]'); if (!f || mode !== 'tab') return; e.preventDefault();
    var k = f.getAttribute('data-f'), id = +f.getAttribute('data-d'), b = f.querySelector('button');
    if (k === 'own') return act(b, { action: 'own_add', domain: f.domain.value.trim() });
    if (k === 'forward') return act(b, { action: 'forward', domain: id, to: f.to.value.trim() });
    if (k === 'ns') return act(b, { action: 'nameservers', domain: id, list: f.list.value.split(/[\s,]+/).filter(Boolean) });
    if (k === 'rec') return act(b, { action: 'record_save', domain: id, rec: { host: f.host.value.trim(), type: f.type.value, answer: f.answer.value.trim(), priority: +f.priority.value } }, function () { showPanel(id, 'dns'); });
    if (k === 'ticket') return act(b, { action: 'ticket', domain: id, words: f.words.value }, function () { open[id] = null; return load(); });
  });

  function walletHtml() {
    var cs = S.cards || [];
    var rows = cs.map(function (c) {
      return '<div class="dm-wc"><div><b>' + E(c.label) + '</b>' + (c['default'] ? ' <span class="dm-pill">Default</span>' : '') + (c.test ? ' <span class="dm-pill">Test card</span>' : '')
        + '<small class="dm-note">' + (c.exp ? 'Expires ' + E(c.exp.slice(5) + '/' + c.exp.slice(2, 4)) : '') + (c.expiring ? ' · <b>expiring soon: replace it</b>' : '') + (c.uses.length ? ' · Pays for ' + E(c.uses.join(', ')) : '') + '</small></div>'
        + (S.can.wallet ? '<div class="dm-row">' + (c['default'] ? '' : '<button type="button" class="go-btn" data-dm="w_default" data-card="' + c.id + '">Make default</button>')
          + '<button type="button" class="go-btn" data-dm="w_replace" data-card="' + c.id + '">Replace</button>'
          + '<button type="button" class="go-btn no" data-dm="w_remove" data-card="' + c.id + '"' + (c.locked ? ' disabled title="It pays for ' + E(c.uses.join(', ')) + ': replace it instead"' : '') + '>Remove</button></div>' : '')
        + '<div data-wrep="' + c.id + '" hidden></div></div>';
    }).join('');
    var test = S.side === 'test';
    var live = (S.live_cards || []).length ? '<section class="dm-card tv-bleed"><h2 class="dm-h">Live wallet</h2>' + status('info', 'Not used now:', 'This is a test, so only the test wallet above pays. These real cards are never charged by a test; they\'re managed when testing is off.')
      + S.live_cards.map(function (c) { return '<div class="dm-wc"><div><b>' + E(c.label) + '</b>' + (c['default'] ? ' <span class="dm-pill">Default</span>' : '') + '<small class="dm-note">' + (c.uses.length ? 'Pays for ' + E(c.uses.join(', ')) : '') + '</small></div></div>'; }).join('') + '</section>' : '';
    return '<section class="dm-card tv-bleed" id="wallet"><h2 class="dm-h">' + (test ? 'Test wallet' : 'Wallet') + '</h2>'
      + (test ? status('info', 'Test wallet:', 'Cards here are saved in QuickBooks\' sandbox and only ever charged there: use Intuit\'s test card numbers (like 4111 1111 1111 1111). Nothing real is charged, and a real card can\'t be used while testing.') : '')
      + '<p class="dm-note">' + (acct.type === 'listing' ? E(S.name) + '\'s' : 'Your') + ' saved cards. QuickBooks Payments holds them; we keep only a label. A card that pays for something that renews (a plan, a domain) is locked: replace it, it can\'t be removed. We remind you 30 days before it expires.</p>'
      + (rows || '<p class="dm-note">No cards yet.</p>') + (S.can.wallet ? '<div class="dm-row"><button type="button" class="go-btn" data-dm="w_add">Add a card</button></div><div id="dm-wbox" hidden></div>' : '<p class="dm-note">Only the owner, or someone they let handle billing, changes these cards.</p>') + '</section>' + live;
  }

  load();
})();
