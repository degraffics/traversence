/* js/admin-preflight.js — System Configuration → Pre-flight (decisions/0163 §10's note of 2026-11-16). Run all runs on the
 * server (2026-11-17) and the page watches it: each line's mark a spinner while it runs, then drawn again with its answer,
 * like a log filling in; it carries on if the page is left, and the page picks it up when opened again. Each line's Test
 * runs it alone; a fix button runs its fix, then tests the line again. Every slow press shows its spinner (TvAsk.busy) and
 * a notice only when a request fails: a line's ✓ or ✗ is its answer (Jason, 2026-11-17). Answers come from /admin/api/config/preflight. */
(function () {
  var box = document.getElementById('pf');
  if (!box) return;
  var csrf = box.getAttribute('data-csrf') || '', running = false;

  function post(body) {
    return fetch('/admin/api/config/preflight', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again.'); return j; });
  }
  function say(msg, el, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: el, bad: !!bad }); }
  /** A line's notice: at the top of its opened body, the full width (never in the header row beside the name). */
  function sayLine(msg, li, bad) {
    var d = li && li.querySelector('details'), b = li && li.querySelector('.pf-b');
    if (d) d.open = true;
    var first = b && b.firstElementChild;
    if (!first) { say(msg, li, bad); return; }
    say(msg, first, bad);
  }
  function busy(el, on) { if (el && window.TvAsk && TvAsk.busy) TvAsk.busy(el, on); }
  function counts(html) { var c = box.querySelector('[data-pf-counts]'); if (c && html) c.innerHTML = html; paint(c); }
  function paint(root) { if (window.TvTime && root) TvTime.paint(root); }
  function groups() {
    box.querySelectorAll('.pf-g').forEach(function (g) {
      var n = { ok: 0, bad: 0, na: 0 };
      g.querySelectorAll('.pf-l').forEach(function (l) { var s = l.getAttribute('data-s'); if (n[s] !== undefined) n[s]++; });
      var marks = g.querySelectorAll('[data-pf-gc] .pf-m'), gc = g.querySelector('[data-pf-gc]');
      if (!gc || marks.length < 3) return;
      gc.innerHTML = marks[0].outerHTML + n.ok + ' ' + marks[1].outerHTML + n.bad + ' ' + marks[2].outerHTML + n.na;
    });
  }

  /** Runs one line: its spinner, then the line drawn again. Resolves with its state. */
  function runLine(li, open) {
    var id = li.getAttribute('data-pf'), wasOpen = li.querySelector('details') && li.querySelector('details').open;
    li.setAttribute('data-busy', '1');
    return post({ action: 'run', id: id }).then(function (j) {
      var t = document.createElement('div'); t.innerHTML = j.html;
      var fresh = t.firstElementChild;
      li.replaceWith(fresh);
      if (open || wasOpen || j.s === 'bad') { var d = fresh.querySelector('details'); if (d && (open || wasOpen)) d.open = true; }
      paint(fresh); live(); groups(); applyRed();   // the page's own counts: it opens fresh, so stored results never mix in
      return { s: j.s, li: fresh };
    }, function (e) { li.removeAttribute('data-busy'); throw e; });
  }

  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  // a run starts fresh (Jason, 2026-11-17: "it needs to refresh the preflight"): every line back to queued, the counts from 0,
  // then each line fills in as its answer comes, like a log, with "Testing 34 of 87: OpenStreetMap" above
  var prog = box.querySelector('[data-pf-prog]'), total = 0;
  function progress(text) { if (!prog) return; prog.hidden = !text; prog.textContent = text || ''; }
  function live() {
    var n = { ok: 0, warn: 0, bad: 0, na: 0, wait: 0, queued: 0, 'new': 0 };
    box.querySelectorAll('.pf-l').forEach(function (l) { var s = l.getAttribute('data-s'); n[s] = (n[s] || 0) + 1; });
    var c = box.querySelector('[data-pf-counts]'), marks = c ? c.querySelectorAll('.pf-m') : [];
    if (c && marks.length >= 3) c.innerHTML = '<span class="pf-c">' + marks[0].outerHTML + n.ok + '</span> · <span class="pf-c">' + marks[1].outerHTML + n.bad + '</span> · <span class="pf-c">' + marks[2].outerHTML + n.na + ' not needed yet</span>' + (n.warn ? ' · ' + n.warn + ' on a backup' : '') + (n.wait ? ' · ' + n.wait + ' waiting' : '') + ' · ' + (n.queued + n['new']) + ' to test';
  }
  function reset() {
    box.querySelectorAll('.pf-l').forEach(function (l) {
      l.setAttribute('data-s', 'queued'); l.removeAttribute('data-slow');
      var m = l.querySelector('.pf-m'); if (m) { m.className = 'pf-m pf-new'; m.title = 'Queued'; var svg = m.querySelector('svg'); if (svg) svg.innerHTML = '<circle cx="12" cy="12" r="2.5"/>'; }
      var sl = l.querySelector('.pf-slow'); if (sl) sl.remove();
      var w = l.querySelector('.pf-w'); if (w) w.textContent = 'queued';
    });
    groups(); live();
  }

  // Run all runs on the server (Jason, 2026-11-17: "Preflight only works if I stay on that page"): the page asks it to start,
  // then only watches, every 2 seconds, drawing each line as it finishes; leave and come back, and the page picks the run up
  // where it is. A run that stopped part way waits for the person (Jason: "a prompt to answer continue, cancel"): opening
  // the page asks Continue or Cancel; Run all asks Continue, Start a new run or Cancel.
  var shown = 0, polling = false, allBtn = box.querySelector('[data-pf-all]');
  function draw(lv) {
    Object.keys(lv.lines || {}).forEach(function (id) {
      var li = box.querySelector('[data-pf="' + id + '"]'); if (!li) return;
      var wasOpen = li.querySelector('details') && li.querySelector('details').open;
      var t = document.createElement('div'); t.innerHTML = lv.lines[id];
      var fresh = t.firstElementChild; li.replaceWith(fresh);
      if (wasOpen) { var d = fresh.querySelector('details'); if (d) d.open = true; }
      paint(fresh);
    });
    box.querySelectorAll('.pf-l[data-busy]').forEach(function (l) { l.removeAttribute('data-busy'); });
    if (lv.current) { var cur = box.querySelector('[data-pf="' + lv.current + '"]'); if (cur) cur.setAttribute('data-busy', '1'); }
    shown = Math.max(shown, lv.i || 0);
    progress(lv.text || '');
    live(); groups(); applyRed();
  }
  function idle(lv) {
    polling = false; running = false; busy(allBtn, false);
    if (lv && lv.log) { var lg = box.querySelector('[data-pf-runs]'); if (lg) { lg.innerHTML = lv.log; paint(lg); } }
  }
  // poll(opts): opts.runAll, the poll began from Run all (a stop then offers Start a new run); opts.after, Run all's press
  // (seconds): until the new run shows as running, an earlier run's ended state is not this run's end, so it asks again
  var gen = 0;
  function poll(opts) {
    opts = opts || {};
    if (polling) return; polling = true;
    var me = ++gen, t0 = Date.now();
    (function tick() {
      if (me !== gen) return;   // stopped (start answered that the run had stopped part way)
      post({ action: 'status', from: shown }).then(function (j) {
        if (me !== gen) return;
        var lv = j.live || {};
        if (opts.after && !(lv.state === 'running' || (lv.start || 0) >= opts.after - 60)) {
          if (Date.now() - t0 < 30000) { setTimeout(tick, 1000); return; }   // not started yet: asked again in a second
          opts.after = 0;
        }
        if (lv.state === 'running') { opts.after = 0; busy(allBtn, false); }   // under way: the button stops spinning, the lines fill in
        if (lv.state === 'none') { idle(lv); progress(''); return; }
        draw(lv);
        if (lv.state === 'done' || lv.state === 'cancelled') { idle(lv); progress(''); if (lv.counts) counts(lv.counts); return; }
        if (lv.state === 'interrupted') { idle(lv); stopped(lv, !!opts.runAll); return; }
        setTimeout(tick, 2000);
      }, function () { if (me === gen) setTimeout(tick, 5000); });   // a missed answer: asked again a little later
    })();
  }
  /** A run stopped part way: the person chooses (the site's own chooser, never a browser dialog). */
  function stopped(lv, fromRunAll) {
    box.setAttribute('data-pf-live', 'interrupted');
    progress(lv.text || lv.note || '');
    if (!window.TvAsk || !TvAsk.choose) return;
    var where = (lv.i || 0) + ' of ' + (lv.total || 0);
    var choices = [['continue', 'Continue', 'From ' + where + ', on the server: the lines already done keep their answers.']];
    if (fromRunAll) choices.push(['new', 'Start a new run', 'This one is logged as cancelled at ' + where + ', and every line runs again.']);
    choices.push(['cancel', 'Cancel it', 'Logged as cancelled at ' + where + ', with its report so far. The page opens fresh.']);
    TvAsk.choose('A run stopped at ' + where + '. Continue it, or cancel it?', choices, 'continue', { yes: 'Go on', note: lv.note || '' }).then(function (v) {
      if (!v) return;   // closed: it keeps waiting (the page asks again next time, and Pulse has it)
      if (v === 'cancel') {
        busy(allBtn, true);
        post({ action: 'cancel' }).then(function (j) {
          busy(allBtn, false); box.removeAttribute('data-pf-live'); progress('');
          reset(); var lg = box.querySelector('[data-pf-runs]'); if (lg && j.log) { lg.innerHTML = j.log; paint(lg); }
        }).catch(function (e) { busy(allBtn, false); say(e.message, allBtn, true); });
        return;
      }
      begin(v);
    });
  }
  function begin(mode) {
    if (running) { say('A run is going on the server. This page follows it as each line finishes.', allBtn); return; }
    running = true; busy(allBtn, true);   // spins only until the run is under way
    redOnly = false; slowOnly = false; applyRed();
    var going = box.getAttribute('data-pf-live');
    if (!going || mode === 'new') { reset(); shown = 0; }   // a new run starts fresh; a run going on, or continued, is only watched
    box.setAttribute('data-pf-live', 'running');
    var after = Math.floor(Date.now() / 1000), seen = false;
    // the page follows at once, never waiting for start's answer: where the server can't end the request early, that
    // answer comes only when the run ends (2026-11-17: the button spun and the counts stayed at 0 while the run went on)
    setTimeout(function () { if (running && !seen) { seen = true; poll({ runAll: true, after: after }); } }, 800);
    post({ action: 'start', mode: mode || '' }).then(function (j) {
      var lv = j.live || {};
      if (lv.state === 'interrupted') { gen++; polling = false; running = false; busy(allBtn, false); stopped(lv, true); return; }
      if (!seen) { seen = true; draw(lv); poll({ runAll: true, after: after }); }
    }).catch(function (e) {
      if (polling) return;   // the run is being followed: a late or cut-off answer from start changes nothing
      gen++; busy(allBtn, false); running = false; progress(''); box.removeAttribute('data-pf-live'); say(e.message, allBtn, true);
    });
  }
  function runAll(btn) { begin(''); }
  var opened = box.getAttribute('data-pf-live');
  if (opened === 'running') {   // opened while a run is going: watch it from where it is
    shown = parseInt(box.getAttribute('data-pf-from') || '0', 10) || 0;
    running = true; live(); groups(); poll();   // the button doesn't spin: the progress line and the lines show the run
  } else if (opened === 'interrupted') {   // opened after a run stopped: ask what to do
    shown = parseInt(box.getAttribute('data-pf-from') || '0', 10) || 0;
    live(); groups();
    var pg = box.querySelector('[data-pf-prog]'), m = (pg && pg.textContent || '').match(/at (\d+) of (\d+)/);
    stopped({ i: m ? +m[1] : shown, total: m ? +m[2] : 0, note: pg ? pg.textContent : '' }, false);
  }

  var redOnly = false, slowOnly = false;
  function applyRed() {
    box.querySelectorAll('.pf-l').forEach(function (l) { l.hidden = (redOnly && l.getAttribute('data-s') !== 'bad') || (slowOnly && !l.hasAttribute('data-slow')); });
    box.querySelectorAll('.pf-g').forEach(function (g) { g.hidden = (redOnly || slowOnly) && !g.querySelector('.pf-l:not([hidden])'); });   // a group with nothing to show folds away
    var b = box.querySelector('[data-pf-red]'); if (b) b.textContent = redOnly ? 'Show every line' : 'Show only what\'s red';
    var s = box.querySelector('[data-pf-slow]'); if (s) s.textContent = slowOnly ? 'Show every line' : 'Show the slow ones';
  }
  function openLine(hash) {
    var li = hash && hash.length > 1 ? document.getElementById(hash.slice(1)) : null;
    if (!li || !li.classList.contains('pf-l')) return;
    var g = li.closest('details.pf-g'); if (g) g.open = true;
    var d = li.querySelector('details'); if (d) d.open = true;
    li.hidden = false; li.scrollIntoView({ block: 'center' });
  }

  box.addEventListener('click', function (ev) {
    var b = ev.target.closest('button, a[data-pf-first]');
    if (!b || !box.contains(b)) return;
    if (b.hasAttribute('data-pf-all')) { ev.preventDefault(); runAll(b); return; }
    if (b.hasAttribute('data-pf-red')) { ev.preventDefault(); redOnly = !redOnly; slowOnly = false; applyRed(); return; }
    if (b.hasAttribute('data-pf-slow')) { ev.preventDefault(); slowOnly = !slowOnly; redOnly = false; applyRed(); return; }
    if (b.hasAttribute('data-pf-first')) { ev.preventDefault(); openLine(b.getAttribute('href')); return; }
    if (b.hasAttribute('data-pf-run')) {
      ev.preventDefault(); ev.stopPropagation();   // a button in the summary: test, don't fold
      var li = b.closest('.pf-l'); busy(b, true);
      runLine(li, false).catch(function (e) { busy(b, false); sayLine(e.message, li, true); });   // its ✓ or ✗ is the answer: no notice
      return;
    }
    if (b.hasAttribute('data-pf-fix')) {
      ev.preventDefault();
      var li2 = b.closest('.pf-l'); busy(b, true);
      post({ action: 'fix', fix: b.getAttribute('data-pf-fix') }).then(function (j) {
        busy(b, false);
        return runLine(li2, true);   // what the fix did shows as the line's new mark and answer
      }).catch(function (e) { busy(b, false); say(e.message, b.closest('.pf-fx') || b, true); });
    }
  });
  window.addEventListener('hashchange', function () { openLine(location.hash); });
  openLine(location.hash);
})();
