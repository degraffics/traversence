<?php
// app/lib/SchemaUpkeep.php — what's left in the database that nothing uses (Jason, 2026-11-14; decisions/0162).
// Migrations only add, so Roll back takes a release's files out and leaves what its migrations made (tables, columns,
// indexes). Those are recorded here as "left by release #N" (app/storage/schema/leftovers.json: never served or synced).
// A later release whose migrations make the same thing takes it up again. One still left after DUE_DAYS is proposed for
// removal: removal is a normal release (its migration copies the table first, then drops; release.json names it under
// "removes"), and Jason approves. Keep holds one where it is.
// Once a month (Scheduler::sync, scanDue()) the tables and columns no live code mentions are listed too (scanUnused():
// every identifier in the live app/, website/ and trvgo/ code, the same files the mirror records, against main and the
// realms), in app/storage/schema/unused.json. Both lists are one Pulse case each, a step per item; Jason decides.
declare(strict_types=1);

require_once __DIR__ . '/DbUpdates.php';

final class SchemaUpkeep
{
    public const DUE_DAYS = 30;
    public const SCAN_DAYS = 30;
    private const SCAN_SKIP = ['storage', 'uploads', 'image', 'images', 'node_modules', '.git', '_notes', '_SUPPORT', '_pending', '_concepts'];
    private const STEPS = 40;   // steps shown in a case; the rest are counted

    private static function file(): string { return dirname(__DIR__) . '/storage/schema/leftovers.json'; }

    private static function read(): array
    {
        $j = json_decode((string) @file_get_contents(self::file()), true);
        return is_array($j) && isset($j['items']) && is_array($j['items']) ? $j : ['items' => []];
    }

    private static function write(array $j): void
    {
        $d = dirname(self::file());
        if (!is_dir($d)) @mkdir($d, 0750, true);
        @file_put_contents(dirname($d) . '/schema/.htaccess', "Require all denied\n");
        @file_put_contents(self::file(), json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    /** "table t", "column t.c", "index t.i" for one of DbUpdates::checks()'s items. */
    public static function key(array $c): string { return $c[0] === 'table' ? 'table ' . $c[1] : $c[0] . ' ' . $c[1] . '.' . $c[2]; }

    /** What a release's migrations make: key => [check, file]. $dir is where its files are (…/new/). */
    private static function made(array $files, string $dir): array
    {
        $out = [];
        foreach ($files as $p) {
            $sql = (string) @file_get_contents($dir . $p);
            foreach (DbUpdates::checks($sql) as $c) $out[self::key($c)] = [$c, basename($p)];
        }
        return $out;
    }

    /** On Roll back: records what the release's migrations made that's still there. Returns the keys recorded. */
    public static function recordLeftovers(PDO $pdo, array $r, array $migs, string $dir): array
    {
        $s = DbUpdates::schema($pdo);
        $j = self::read(); $got = [];
        foreach (self::made($migs, $dir) as $k => [$c, $file]) {
            $there = $c[0] === 'table' ? isset($s['t'][$c[1]]) : isset($s[$c[0] === 'column' ? 'c' : 'i'][$c[1] . '.' . $c[2]]);
            if (!$there) continue;
            $j['items'][$k] = ['check' => $c, 'release' => (int) $r['id'], 'title' => (string) $r['title'], 'file' => $file, 'at' => gmdate('c')];
            $got[] = $k;
        }
        if ($got) self::write($j);
        return $got;
    }

    /** On a publish: anything its migrations make again is taken up (no longer a leftover). Returns the keys taken up. */
    public static function takenUp(array $r, array $migs, string $dir): array
    {
        $j = self::read(); $got = [];
        foreach (array_keys(self::made($migs, $dir)) as $k) if (isset($j['items'][$k]) && (int) $j['items'][$k]['release'] !== (int) $r['id']) { unset($j['items'][$k]); $got[] = $k; }
        if ($got) self::write($j);
        return $got;
    }

    /** What's left now, oldest first (ones that are gone from the database are forgotten): key => item + ['due' => bool]. */
    public static function leftovers(PDO $pdo): array
    {
        $j = self::read();
        if (!$j['items']) return [];
        $s = DbUpdates::schema($pdo); $gone = false; $out = [];
        foreach ($j['items'] as $k => $it) {
            $c = (array) $it['check'];
            $there = $c[0] === 'table' ? isset($s['t'][$c[1]]) : isset($s[$c[0] === 'column' ? 'c' : 'i'][$c[1] . '.' . ($c[2] ?? '')]);
            if (!$there) { unset($j['items'][$k]); $gone = true; continue; }
            $it['due'] = empty($it['kept_at']) && strtotime((string) $it['at']) < time() - self::DUE_DAYS * 86400;
            $out[$k] = $it;
        }
        if ($gone) self::write($j);
        uasort($out, fn ($a, $b) => strcmp((string) $a['at'], (string) $b['at']));
        return $out;
    }

    /** Keep one where it is: not proposed for removal again (a leftover, or an item of the unused-schema check). */
    public static function keep(string $key, int $uid): void
    {
        $j = self::read();
        if (isset($j['items'][$key])) { $j['items'][$key]['kept_at'] = gmdate('c'); $j['items'][$key]['kept_by'] = $uid; self::write($j); return; }
        $u = self::unused();
        if (!in_array($key, array_merge(array_column($u['tables'], 'key'), array_column($u['columns'], 'key')), true)) throw new RuntimeException('That isn\'t on the list any more.');
        $j['kept_unused'][$key] = ['at' => gmdate('c'), 'by' => $uid];
        self::write($j);
    }

    /** What a removal release may drop: the recorded leftovers and what the unused-schema check listed (kept ones too, if a person sends their removal). */
    public static function removable(): array
    {
        $u = self::unused();
        return array_values(array_unique(array_merge(array_keys(self::read()['items']), array_column($u['tables'], 'key'), array_column($u['columns'], 'key'))));
    }

    // ---- the monthly unused-schema check --------------------------------------------------------------------------------

    private static function unusedFile(): string { return dirname(__DIR__) . '/storage/schema/unused.json'; }

    /** The last check: ['at', 'tables' => [[key, db, table, rows, bytes]], 'columns' => [[key, db, table, column]], 'files']. */
    public static function unused(): array
    {
        $j = json_decode((string) @file_get_contents(self::unusedFile()), true);
        return is_array($j) && isset($j['tables'], $j['columns']) ? $j : ['at' => '', 'tables' => [], 'columns' => [], 'files' => 0];
    }

    public static function scanDue(): bool
    {
        $at = self::unused()['at'];
        return $at === '' || strtotime((string) $at) < time() - self::SCAN_DAYS * 86400;
    }

    /** Every identifier in the live code, lowercased (and the prefixes code builds names from, "crawl_" . $x). */
    private static function words(string $root): array
    {
        $words = []; $files = 0;
        foreach (['app', 'website', 'trvgo'] as $top) {
            if (!is_dir($root . '/' . $top)) continue;
            $it = new RecursiveIteratorIterator(new RecursiveCallbackFilterIterator(new RecursiveDirectoryIterator($root . '/' . $top, FilesystemIterator::SKIP_DOTS),
                fn ($f) => !($f->isDir() && in_array($f->getFilename(), self::SCAN_SKIP, true))));
            foreach ($it as $f) {
                if (!$f->isFile() || !preg_match('/\.(php|js|inc|sql)$/i', $f->getFilename()) || $f->getSize() > 3 * 1048576) continue;
                $src = (string) @file_get_contents($f->getPathname());
                if (preg_match_all('/[A-Za-z_][A-Za-z0-9_]{1,63}/', $src, $m)) foreach ($m[0] as $w) $words[strtolower($w)] = true;
                $files++;
            }
        }
        return [$words, $files];
    }

    /** The monthly check: tables, and columns of used tables, that no live code names. Returns what it found. */
    public static function scanUnused(PDO $pdo): array
    {
        @set_time_limit(300);
        [$words, $files] = self::words(dirname(__DIR__, 2));
        if ($files < 50) throw new RuntimeException('The live code wasn\'t found to read (' . $files . ' files): the check didn\'t run.');
        $prefixes = array_values(array_filter(array_keys($words), fn ($w) => str_ends_with((string) $w, '_') && strlen((string) $w) >= 4));
        $used = function (string $name) use ($words, $prefixes): bool {
            $n = strtolower($name);
            if (isset($words[$n])) return true;
            foreach ($prefixes as $p) if (str_starts_with($n, (string) $p)) return true;   // a name the code builds
            return false;
        };
        $conns = [Database::mainName() => $pdo];
        foreach (array_keys(Database::REALMS) as $r) { try { [$db] = Database::realmConfig($r); if ($db && !isset($conns[(string) $db])) $conns[(string) $db] = Database::realm($r); } catch (Throwable) {} }
        $out = ['at' => gmdate('c'), 'tables' => [], 'columns' => [], 'files' => $files];
        foreach ($conns as $db => $c) {
            try {
                $st = $c->prepare('SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH + INDEX_LENGTH FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = \'BASE TABLE\'');
                $st->execute([$db]); $tables = $st->fetchAll(PDO::FETCH_NUM);
                $st = $c->prepare('SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ?');
                $st->execute([$db]); $cols = $st->fetchAll(PDO::FETCH_NUM);
            } catch (Throwable $x) { error_log('unused schema ' . $db . ': ' . $x->getMessage()); continue; }
            $unusedT = [];
            foreach ($tables as [$t, $rows, $bytes]) if (!$used((string) $t)) { $unusedT[strtolower((string) $t)] = true; $out['tables'][] = ['key' => 'table ' . strtolower((string) $t), 'db' => (string) $db, 'table' => (string) $t, 'rows' => (int) $rows, 'bytes' => (int) $bytes]; }
            foreach ($cols as [$t, $col]) if (!isset($unusedT[strtolower((string) $t)]) && !$used((string) $col)) $out['columns'][] = ['key' => 'column ' . strtolower($t . '.' . $col), 'db' => (string) $db, 'table' => (string) $t, 'column' => (string) $col];
        }
        $d = dirname(self::unusedFile());
        if (!is_dir($d)) @mkdir($d, 0750, true);
        @file_put_contents(self::unusedFile(), json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
        return $out;
    }

    // ---- Pulse: one case for each chore (CLAUDE.md), a step per item ---------------------------------------------------

    /** [key, severity, title, why, when, action word] for Pulse::items. */
    public static function pulseItems(PDO $pdo): array
    {
        $out = [];
        $due = array_filter(self::leftovers($pdo), fn ($i) => $i['due']);
        if ($due) {
            $first = reset($due);
            $out[] = ['schema:leftovers', 'update', 'Database leftovers from rolled-back releases: ' . count($due), count($due) . ' thing' . (count($due) === 1 ? '' : 's') . ' made by migrations of releases rolled back over ' . self::DUE_DAYS . ' days ago, not sent again. Remove them (a release, copied first) or keep them.', (string) $first['at'], 'Decide'];
        }
        $u = self::unused(); $kept = (array) (self::read()['kept_unused'] ?? []);
        $n = count(array_filter(array_merge($u['tables'], $u['columns']), fn ($x) => !isset($kept[$x['key']])));
        if ($n) $out[] = ['schema:unused', 'update', 'Database tables and columns no code uses: ' . $n, 'The monthly check read ' . number_format((int) $u['files']) . ' live files and found ' . $n . ' name' . ($n === 1 ? '' : 's') . ' none of them mention. Remove what isn\'t needed (a release, copied first) or keep it.', (string) $u['at'], 'Decide'];
        return $out;
    }

    /** The steps of a schema case: a step per item, Keep it as a button; removal is a release (copied first, then dropped). */
    public static function pulseSteps(PDO $pdo, string $key, callable $s): array
    {
        $st = [];
        $how = $s('Remove the ones not needed', 'Removal goes as a release, which the Founder approves: ask Claude for a removal release naming them (its migration copies each table first, then drops; release.json lists them under "removes"). Database updates lists them too.', ['tool', '/admin/config/dbupdates']);
        $btn = fn (string $k) => ['do', 'schema_keep:' . bin2hex($k), 'Keep it'];
        if ($key === 'schema:leftovers') {
            $items = array_filter(self::leftovers($pdo), fn ($i) => $i['due']);
            foreach (array_slice($items, 0, self::STEPS, true) as $k => $i)
                $st[] = $s(ucfirst((string) $k), 'Left by release #' . (int) $i['release'] . ' (' . $i['title'] . '), from ' . $i['file'] . '. Its removal: ' . self::dropSql((array) $i['check']) . '.', $btn((string) $k));
            if (count($items) > self::STEPS) $st[] = $s('And ' . (count($items) - self::STEPS) . ' more', 'Listed on System Configuration → Database updates.', ['tool', '/admin/config/dbupdates']);
        } else {
            $u = self::unused(); $kept = (array) (self::read()['kept_unused'] ?? []);
            $items = array_values(array_filter(array_merge($u['tables'], $u['columns']), fn ($x) => !isset($kept[$x['key']])));
            foreach (array_slice($items, 0, self::STEPS) as $x)
                $st[] = $s(ucfirst((string) $x['key']), (isset($x['column']) ? 'In ' . $x['db'] . '.' . $x['table'] . '.' : 'In ' . $x['db'] . ', ' . number_format((int) $x['rows']) . ' rows.') . ' No live file names it (a name built in code may still use it: check before removing).', $btn((string) $x['key']));
            if (count($items) > self::STEPS) $st[] = $s('And ' . (count($items) - self::STEPS) . ' more', 'Shown here as these are decided.');
        }
        $st[] = $how;
        return $st;
    }

    /** The drop a removal release would carry for one item (shown in its step). */
    private static function dropSql(array $c): string
    {
        if ($c[0] === 'table') return 'DROP TABLE IF EXISTS ' . $c[1];
        return 'ALTER TABLE ' . $c[1] . ' DROP ' . ($c[0] === 'column' ? 'COLUMN ' : 'INDEX ') . $c[2] . ' (guarded by information_schema)';
    }

    /** Pulse::manage: Keep it, from a step (schema_keep:<hex key>). */
    public static function pulseKeep(string $what, int $uid): string
    {
        $k = (string) @hex2bin(substr($what, strlen('schema_keep:')));
        self::keep($k, $uid);
        return 'Kept ' . $k . ': it isn\'t proposed for removal again.';
    }

    /**
     * What a migration drops: ["table t", "column t.c", "index t.i"], and anything else it does that isn't adding (a
     * rename, a changed column: never allowed). Drops inside the information_schema guard's strings count.
     */
    public static function drops(string $sql): array
    {
        $sql = implode(";\n", DbUpdates::statements($sql)) . ';';
        $q = '`?(\w+)`?'; $out = []; $other = [];
        preg_match_all("~\bDROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?(?:`?\w+`?\.)?$q~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) $out[] = 'table ' . strtolower($x[1]);
        preg_match_all("~\bALTER\s+TABLE\s+(?:`?\w+`?\.|`',\s*@\w+,\s*'`\.)?$q([^;']*)~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) {
            $t = strtolower($x[1]);
            preg_match_all("~\bDROP\s+(?:(COLUMN|INDEX|KEY)\s+)?$q~i", $x[2], $ds, PREG_SET_ORDER);
            foreach ($ds as $d) {
                $kind = strtoupper((string) $d[1]);
                if (in_array(strtoupper($d[2]), ['PRIMARY', 'FOREIGN', 'CONSTRAINT', 'CHECK'], true)) { $other[] = 'DROP ' . strtoupper($d[2]) . ' on ' . $t; continue; }
                $out[] = ($kind === 'INDEX' || $kind === 'KEY' ? 'index ' : 'column ') . $t . '.' . strtolower($d[2]);
            }
        }
        preg_match_all("~\bDROP\s+INDEX\s+$q\s+ON\s+(?:`?\w+`?\.)?$q~i", $sql, $m, PREG_SET_ORDER);
        foreach ($m as $x) $out[] = 'index ' . strtolower($x[2]) . '.' . strtolower($x[1]);
        if (preg_match_all('/\b(DROP\s+(?:DATABASE|VIEW|TRIGGER)|RENAME\s+(?:TABLE|COLUMN|TO)|TRUNCATE|MODIFY\s+(?:COLUMN\s+)?\w+|CHANGE\s+(?:COLUMN\s+)?\w+)\b/i', $sql, $m)) foreach ($m[1] as $x) $other[] = strtoupper(preg_replace('/\s+/', ' ', $x));
        return ['drops' => array_values(array_unique($out)), 'other' => array_values(array_unique($other))];
    }
}
