-- decisions/0175 §3 (Jason, 2026-11-20): a trip places the system's pause on what its fault touches, kept here with its
-- alarm, never written into a person's switch; it lifts when its check passes. Safe to run twice.
CREATE TABLE IF NOT EXISTS system_pauses (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(10) NOT NULL, ref VARCHAR(60) NOT NULL,
  alarm_id INT UNSIGNED NULL, why VARCHAR(255) NOT NULL DEFAULT '', at DATETIME NOT NULL, cleared_at DATETIME NULL, cleared_how VARCHAR(255) NULL,
  KEY open_ref (kind, ref, cleared_at), KEY alarm (alarm_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
