<?php
/**
 * includes/footer.php  ->  tv_footer()
 *
 * The one site footer, used by every page: a boxed "claim or create your listing"
 * call-out, basic business information, and the site links.
 *
 * EDIT THE BUSINESS DETAILS BELOW. Anything left blank is simply not shown, so
 * nothing is invented. Links to pages that do not exist yet are left out.
 */
require_once __DIR__ . '/routes.php';

function tv_footer(): void
{
    // ---- Business details (edit here; blank = hidden) -------------------------
    $biz = [
        'name'    => 'Traversence',
        'tagline' => 'Regional business directory and travel guide',
        'email'   => 'support@traversence.com',   // support: a live inbox (Jason, 2026-10-15)
        'phone'   => '',          // e.g. '(928) 555-0100'
        'address' => '',          // e.g. 'PO Box 123, Saint Johns, AZ 85936'
    ];
    // ---------------------------------------------------------------------------
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $explore   = tv_route(['discovery/index.php' => '/discovery/']);
    $directory = tv_route(['directory/index.php' => '/directory/']);
    $claim     = tv_route(['claim.php' => '/claim.php', 'claim/index.php' => '/claim/']);
    $privacy   = tv_route(['privacy.php' => '/privacy.php']);
    $terms     = tv_route(['terms.php' => '/terms.php']);
    $link = 'hover:text-[#3E2B1F] underline-offset-2 hover:underline';
    // the "Own a business?" call-out is for people who don't run one yet: not for a business's team, nor our staff
    $runs = false;
    try {
        if (class_exists('Auth') && class_exists('Database') && ($fme = Auth::currentUser())) {
            require_once __DIR__ . '/../lib/Roles.php'; require_once __DIR__ . '/../lib/Team.php';
            $fpdo = Database::connection();
            $runs = (bool) Roles::staffLogin($fpdo, (int) $fme['id']) || (bool) Team::listingsOf($fpdo, (int) $fme['id']);
        }
    } catch (Throwable) {}
    // the zone on every page above the footer (decisions/0159 step 4c): drawn where the header's zone may be
    if (class_exists('Blocks')) { try { echo Blocks::site('site.bottom'); } catch (Throwable $e) { error_log('site zone: ' . $e->getMessage()); } }
    ?>
<footer class="border-t border-[#CBB98D] bg-[#EFE3C8] px-4 sm:px-8 pt-8 pb-6 text-xs text-[#5C4632]">
  <div class="max-w-5xl mx-auto space-y-6">

    <?php if (($claim || $directory) && !$runs): ?>
    <!-- Claim / create call-out -->
    <section aria-labelledby="ft-claim-h" class="rounded-2xl border-2 border-amber-600/60 bg-[#F7EFDC] px-5 py-4 flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-6">
      <div class="flex-1">
        <h2 id="ft-claim-h" class="font-serif font-bold text-base text-[#3E2B1F]">Own a business? Claim or create your listing.</h2>
        <p class="mt-0.5">Be visible where it matters most: anchored directly to the community and travelers looking to connect with the offerings you provide. Let&rsquo;s get local.</p>
      </div>
      <div class="flex flex-wrap gap-2">
        <?php if ($directory): ?><a href="<?= $e($directory) ?>" class="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold no-underline transition">Find &amp; claim yours</a><?php endif; ?>
        <?php if ($claim): ?><a href="<?= $e($claim) ?>?new=1" class="px-4 py-2 rounded-lg border border-amber-700/60 text-[#3E2B1F] hover:bg-amber-100 font-semibold no-underline transition">Create your listing</a><?php endif; ?>
      </div>
    </section>
    <?php endif; ?>

    <div class="grid gap-6 sm:grid-cols-3">
      <div>
        <p class="font-serif font-bold text-sm text-[#3E2B1F]"><?= $e($biz['name']) ?></p>
        <?php if ($biz['tagline'] !== ''): ?><p class="mt-1"><?= $e($biz['tagline']) ?></p><?php endif; ?>
      </div>
      <nav aria-label="Footer" class="flex flex-col gap-1">
        <a href="/" class="<?= $link ?>">Home</a>
        <?php if ($explore): ?><a href="<?= $e($explore) ?>" class="<?= $link ?>">Let's Explore</a><?php endif; ?>
        <?php if ($directory): ?><a href="<?= $e($directory) ?>" class="<?= $link ?>">Get Local (Directory)</a><?php endif; ?>
        <?php if ($claim): ?><a href="<?= $e($claim) ?>?new=1" class="<?= $link ?>">Add or claim a business</a><?php endif; ?>
      </nav>
      <div class="flex flex-col gap-1">
        <?php if ($biz['address'] !== ''): ?><span><?= $e($biz['address']) ?></span><?php endif; ?>
        <?php if ($biz['phone'] !== ''): ?><a href="tel:<?= $e(preg_replace('/[^\d+]/', '', $biz['phone'])) ?>" class="<?= $link ?>"><?= $e($biz['phone']) ?></a><?php endif; ?>
        <?php if ($biz['email'] !== ''): ?><a href="mailto:<?= $e($biz['email']) ?>" class="<?= $link ?>"><?= $e($biz['email']) ?></a><?php endif; ?>
        <a href="/faq.php" class="<?= $link ?>">FAQ</a>
        <a href="/our-approach.php" class="<?= $link ?>">Our approach</a>
        <?php if ($privacy): ?><a href="<?= $e($privacy) ?>" class="<?= $link ?>">Privacy</a><?php endif; ?>
        <?php if ($terms): ?><a href="<?= $e($terms) ?>" class="<?= $link ?>">Terms</a><?php endif; ?>
      </div>
    </div>

    <p class="text-center text-[#8A7355] pt-2 border-t border-[#CBB98D]/60">&copy; <?= date('Y') ?> <?= $e($biz['name']) ?></p>
  </div>
</footer>
<?php
}

/**
 * The cart and checkout's footer: no call-outs or site links to lead away from paying, just customer service: how to
 * reach us about an order, how payment is handled, and the order policies (tv_page_end(['footer' => 'checkout'])).
 */
function tv_footer_checkout(): void
{
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $link = 'underline underline-offset-2 hover:text-[#3E2B1F]';
    ?>
<footer class="border-t border-[#CBB98D] bg-[#EFE3C8] px-4 sm:px-8 pt-6 pb-6 text-xs text-[#5C4632]">
  <div class="max-w-3xl mx-auto grid gap-4 sm:grid-cols-2">
    <div>
      <p class="font-serif font-bold text-sm text-[#3E2B1F]">Questions about your order?</p>
      <p class="mt-1">Email <a class="<?= $link ?>" href="mailto:support@traversence.com">support@traversence.com</a>, or reply to your receipt email, with your order number. We fix it first, then a credit, then a refund if neither works.</p>
    </div>
    <div>
      <p class="font-serif font-bold text-sm text-[#3E2B1F]">Secure payment</p>
      <p class="mt-1">Cards are processed by QuickBooks Payments (Intuit). Your card goes straight to them: we never see or keep your card number.</p>
    </div>
  </div>
  <nav aria-label="Order help" class="max-w-3xl mx-auto mt-4 flex flex-wrap gap-x-4 gap-y-1">
    <a class="<?= $link ?>" href="/faq.php#what-if-something-s-wrong-with-my-order">Order help</a>
    <a class="<?= $link ?>" href="/terms.php#fix-credit-refund">Fixes, credits &amp; refunds</a>
    <a class="<?= $link ?>" href="/terms.php#buying">Terms of purchase</a>
    <a class="<?= $link ?>" href="/privacy.php">Privacy</a>
    <span>&copy; <?= $e(date('Y')) ?> Traversence</span>
  </nav>
</footer>
<?php
}
