/* js/tv-table.js: the table standard for tables the server writes (design/table-standard.md, T3-T5).
 * .ak-aa and .cs-t tables (the consoles) and any table[data-tv-table]; table[data-tv-plain] is left alone (a form laid out
 * as a table). A tap on a heading sorts (again, the other way; a third time, the server's order); numbers right; a column
 * with nothing in it said once under the table; each row a card on a phone; past 25 rows the count, Show 10/25/50/100
 * (remembered per table) and the page bar. Rows are only shown or hidden, never rebuilt, so their buttons and forms keep
 * working. Loaded by js/admin-kit.js in the admin, and by tv_table_kit() (app/ui/table-kit.php) on the admin's older
 * pages. Moved from admin-kit.js in T4. */
(function () {
  if (window.TvTable) return;
  var STATIC_SEL = '.ak-aa > table, table.ak-aa, table.cs-t, table[data-tv-table]';
  function staticTable(t) {
    if (t.dataset.tvDone || t.hasAttribute('data-tv-plain') || t.closest('[data-tv-plain]')) return; t.dataset.tvDone = '1';
    t.classList.add('akt-s');
    var body = t.tBodies[0]; if (!body) return;
    var head = t.tHead && t.tHead.rows[0];
    if (!head && body.rows[0] && body.rows[0].cells.length && [].every.call(body.rows[0].cells, function (c) { return c.tagName === 'TH'; })) {   // no <thead>: a first row of headings is the head (T4)
      var th = t.createTHead(); th.appendChild(body.rows[0]); head = th.rows[0]; }
    var names = head ? [].map.call(head.cells, function (c) { return c.textContent.trim(); }) : [];
    var all = [].slice.call(body.rows).filter(function (r) { return r.cells.length > 1 || !r.cells[0] || r.cells[0].colSpan < 2; });
    if (!all.length) return;
    var cols = Math.max.apply(null, all.map(function (r) { return r.cells.length; }));
    all.forEach(function (r) { [].forEach.call(r.cells, function (c, i) { if (names[i] && !c.hasAttribute('data-l')) c.setAttribute('data-l', names[i]); }); });   // phone cards
    var NUM = /^[\s$€£]*[-–+]?[\d.,]+\s*(%|ms|s|h|d|mb|kb|gb|k|m)?\s*$/i;
    var empty = [];
    for (var i = 0; i < cols; i++) {
      var cellv = function (c) { if (!c) return ''; if (c.querySelector('input,select,textarea,button,a,img,svg')) return '\u0001'; return c.textContent.trim(); };   // a field or a button is something
      var vals = all.map(function (r) { return cellv(r.cells[i]); }).filter(function (v) { return v !== '' && v !== '—' && v !== '–' && v !== '-'; });
      if (!vals.length && names[i]) empty.push(names[i]);
      if (vals.length && vals.every(function (v) { return v !== '\u0001' && NUM.test(v); })) { all.forEach(function (r) { if (r.cells[i]) r.cells[i].classList.add('akt-num'); }); if (head && head.cells[i]) head.cells[i].classList.add('akt-num'); }
    }
    var tail = t.closest('.ak-aa') || t.closest('.cs-scroll') || t, after = function (n) { tail.parentNode.insertBefore(n, tail.nextSibling); };
    var note = null; if (empty.length) { note = document.createElement('p'); note.className = 'akt-note'; note.textContent = empty.join(', ') + ': nothing here yet.'; after(note); }   // never hidden (principle 4)
    // sort by a header: a tap sorts it, again the other way, a third time back to the server's order
    var order = all.slice(), S = { i: -1, dir: 1 };
    if (head && all.length > 1) [].forEach.call(head.cells, function (c, i) {
      if (!names[i] || c.querySelector('a,button,input,select')) return;
      c.classList.add('akt-sortable'); c.tabIndex = 0; c.setAttribute('role', 'button'); c.title = 'Sort by ' + names[i].toLowerCase();
      var go = function () {
        if (S.i === i) { if (S.dir === 1) S.dir = -1; else S.i = -1; } else { S.i = i; S.dir = 1; }
        [].forEach.call(head.cells, function (h) { h.removeAttribute('aria-sort'); }); if (S.i >= 0) c.setAttribute('aria-sort', S.dir > 0 ? 'ascending' : 'descending');
        var num = c.classList.contains('akt-num'), key = function (r) { var v = r.cells[i] ? r.cells[i].textContent.trim() : ''; return num ? parseFloat(v.replace(/[^\d.-]/g, '')) || 0 : v.toLowerCase(); };
        var rows = S.i < 0 ? order.slice() : all.slice().sort(function (a, b) { var x = key(a), y = key(b); return (x < y ? -1 : x > y ? 1 : 0) * S.dir; });
        rows.forEach(function (r) { body.appendChild(r); }); P.p = 0; paintPages();
      };
      c.addEventListener('click', go); c.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
    });
    // past 25 rows: the count, Show N a page (remembered per table), the page bar
    var P = { p: 0, per: 25 }, key = 'akt:' + location.pathname + ':' + (names.join('|') || 't'), bar = null;
    try { var pp = +localStorage.getItem(key); if ([10, 25, 50, 100].indexOf(pp) >= 0) P.per = pp; } catch (x) {}
    function paintPages() {
      var n = all.length; if (n <= 25) { all.forEach(function (r) { r.hidden = false; }); if (bar) bar.innerHTML = ''; return; }
      if (!bar) { bar = document.createElement('div'); bar.className = 'ak-pg akt-pg'; (note || tail).parentNode.insertBefore(bar, (note || tail).nextSibling);
        bar.addEventListener('click', function (e) { var b = e.target.closest('[data-pg]'); if (!b || b.disabled) return; P.p = +b.dataset.pg; paintPages(); });
        bar.addEventListener('change', function (e) { if (!e.target.matches('[data-per]')) return; var first = P.p * P.per; P.per = +e.target.value; P.p = Math.floor(first / P.per); try { localStorage.setItem(key, P.per); } catch (x) {} paintPages(); }); }
      var pages = Math.ceil(n / P.per); if (P.p >= pages) P.p = pages - 1;
      var cur = [].slice.call(body.rows).filter(function (r) { return all.indexOf(r) >= 0; }), a = P.p * P.per, z = Math.min(n, a + P.per);
      cur.forEach(function (r, k) { r.hidden = k < a || k >= z; });
      var pb = function (p, l, on, aria, off) { return '<button type="button" class="ak-pgb" data-pg="' + p + '"' + (on ? ' aria-current="page"' : '') + (off ? ' disabled' : '') + ' aria-label="' + aria + '">' + l + '</button>'; };
      var want = {}; [0, pages - 1, P.p - 1, P.p, P.p + 1].forEach(function (x) { if (x >= 0 && x < pages) want[x] = 1; }); var nav = pb(P.p - 1, '‹', false, 'Previous page', P.p <= 0), last = -1;
      Object.keys(want).map(Number).sort(function (m, k) { return m - k; }).forEach(function (x) { if (last >= 0 && x > last + 1) nav += '<span class="ak-gap">…</span>'; nav += pb(x, x + 1, x === P.p, 'Page ' + (x + 1)); last = x; });
      nav += pb(P.p + 1, '›', false, 'Next page', P.p >= pages - 1);
      bar.innerHTML = '<nav class="ak-pages" aria-label="Pages">' + nav + '</nav><span class="ak-range">' + (a + 1) + '–' + z + ' of ' + n.toLocaleString() + '</span>'
        + '<label class="ak-per">Show <select data-per aria-label="How many a page">' + [10, 25, 50, 100].map(function (k) { return '<option' + (k === P.per ? ' selected' : '') + '>' + k + '</option>'; }).join('') + '</select> a page</label>';
    }
    paintPages();
    function toHash() { var id = decodeURIComponent((location.hash || '').slice(1)), r = id && document.getElementById(id); r = r && r.closest('tr');
      if (!r || all.indexOf(r) < 0 || !r.hidden) return; var k = [].slice.call(body.rows).filter(function (x) { return all.indexOf(x) >= 0; }).indexOf(r);
      P.p = Math.floor(k / P.per); paintPages(); r.scrollIntoView({ block: 'center' }); }
    toHash(); window.addEventListener('hashchange', toHash);
  }
  function staticTables(root) { (root || document).querySelectorAll(STATIC_SEL).forEach(staticTable); }
  window.TvTable = { enhance: staticTable, all: staticTables };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { staticTables(); }); else staticTables();
  document.addEventListener('toggle', function (e) { if (e.target.tagName === 'DETAILS' && e.target.open) staticTables(e.target); }, true);   // a fold opened later
})();
