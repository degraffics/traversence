<?php
// /admin/search-misses.php — Missed searches (decisions/0061): what people searched for that search didn't catch,
// by the words typed, area and week. Counts only (api/lib/Situations.php logOutcome): nothing about who. Words show
// only once 3 or more searches used them, so a name typed once never appears.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/Links.php';
require_once __DIR__ . '/../../app/lib/Situations.php';
require_once __DIR__ . '/../../app/lib/UniversalSearch.php';
require_once __DIR__ . '/../../app/lib/SearchTrace.php';
require_once __DIR__ . '/../../app/lib/SituationReasoner.php';
require_once __DIR__ . '/../../app/lib/Lexicon.php';
require_once __DIR__ . '/../../app/lib/SuggestionFlags.php';
require_once __DIR__ . '/../../app/lib/SearchEdits.php';
require_once __DIR__ . '/../../app/lib/SearchDrafts.php';

$pdo = Database::connection();

// ---- the situation editor's data (decisions/0061, batch 2): JSON for the Teach search box and the editor ----------
if (isset($_GET['json']) || $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
    $me = Auth::currentUser();
    if ($me === null || !IntakeStager::canUseIntake($pdo, $me)) Response::error('Admin only.', 403, 'forbidden');
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_POST['csrf'] ?? ''))) Response::error('Your session expired. Reload the page.', 403, 'csrf');
    $ctx = ['level' => (string) ($_REQUEST['level'] ?? ''), 'slug' => (string) ($_REQUEST['slug'] ?? '')];
    $centerOf = function (?array $pl) use ($pdo): ?array {
        $z = (string) ($pl['zips'][0] ?? '');
        if ($z === '') return null;
        $st = $pdo->prepare('SELECT latitude, longitude FROM zip_coordinates WHERE zip = ? LIMIT 1'); $st->execute([$z]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ? [(float) $r['latitude'], (float) $r['longitude']] : null;
    };
    try {
        $do = (string) ($_GET['json'] ?? $_POST['do'] ?? '');
        $q = mb_substr(trim((string) ($_REQUEST['q'] ?? '')), 0, 120);
        if ($do === 'find') {   // what search reads the words as now, and the situations they might belong to
            $reads = null;
            if (mb_strlen($q) >= 2) {
                $r = UniversalSearch::search($pdo, $q, $ctx);
                $reads = ['situations' => $r['situation']['labels'] ?? [], 'unread' => !empty($r['unread']), 'parse' => $r['parse'] ?? null,
                          'found' => count(array_filter((array) ($r['results']['items'] ?? []), fn ($x) => ($x['kind'] ?? '') !== 'topic'))];
            }
            $list = Situations::adminFind($pdo, $q);
            // no situation has these words: every situation, so they can be added to any of them
            Response::json(['ok' => true, 'reads' => $reads, 'list' => $list ?: Situations::adminFind($pdo, ''), 'all' => !$list && $q !== '']);
        }
        if ($do === 'analyze') {
            if (is_file(__DIR__ . '/../../app/lib/WordSenses.php')) require_once __DIR__ . '/../../app/lib/WordSenses.php';   // how search reads the words, step by step (the 5 W's), from the reader's own trace
            if (mb_strlen($q) < 2) Response::error('Type at least two letters.', 422, 'bad_request');
            SearchTrace::on();
            $r = UniversalSearch::search($pdo, $q, $ctx);
            $steps = SearchTrace::get();
            $sug = UniversalSearch::suggest($pdo, $q, $ctx);
            // each typed word and the W that used it (the first step to name it); the rest weren't used
            $typed = array_values(array_filter(preg_split('/\s+/u', mb_strtolower($q)) ?: [], fn ($w) => $w !== ''));
            // each word's final role: a later step that uses it again decides ("park" read as Parks, then as the situation's verb)
            $role = [];
            foreach ($steps as $st0) {
                if ($st0['w'] === 'How') continue;
                foreach ($st0['words'] as $ph) foreach (preg_split('/\s+/u', mb_strtolower((string) $ph)) ?: [] as $w0) {
                    foreach ($typed as $i => $tw) if ($tw === $w0 || Situations::norm($tw) === Situations::norm($w0) || trim($tw, ".,!?'\"") === $w0) $role[$i] = $st0['w'];
                }
            }
            $little = array_merge(SearchIndex::STOP, ['a', 'an', 'the', 'of', 'to', 'in', 'on', 'at', 'is', 'was', 'and', 'or', 'it', 'by', 'got', 'get', 'im', 'just', 'so', 'some']);
            $words = []; foreach ($typed as $i => $tw) $words[] = ['w' => $tw, 'role' => $role[$i] ?? (in_array(trim($tw, ".,!?'\""), $little, true) ? 'little' : '')];
            $five = [];
            foreach (['Why', 'What', 'Where', 'When', 'Who'] as $W) {
                $mine = array_values(array_filter($steps, fn ($x) => $x['w'] === $W));
                $five[$W] = $mine ? array_map(fn ($x) => ['what' => $x['what'], 'because' => $x['because']], $mine) : [];
            }
            Response::json(['ok' => true, 'q' => $q, 'words' => $words, 'five' => $five, 'steps' => $steps,
                'result' => ['situation' => $r['situation']['labels'] ?? [], 'need_place' => !empty($r['situation']['need_place']), 'unread' => !empty($r['unread']),
                             'found' => count(array_filter((array) ($r['results']['items'] ?? []), fn ($x) => ($x['kind'] ?? '') !== 'topic')), 'beyond' => count((array) ($r['results']['beyond']['items'] ?? [])),
                             'top' => $r['top']['label'] ?? null, 'offers' => array_column((array) ($r['situation_near'] ?? []), 'label')],
                // everything the panel shows while the words are typed, in its order (decisions/0061)
                'typing' => ['complete' => array_column((array) ($sug['complete'] ?? []), 'q'),
                             'preview' => !empty($sug['preview']['labels']) ? ['labels' => $sug['preview']['labels'], 'needs' => array_values(array_map(fn ($n) => ['label' => $n['label'], 'n' => count($n['items'] ?? [])], (array) ($sug['preview']['needs'] ?? [])))] : null,
                             'rows' => array_values(array_map(fn ($x) => ['label' => (string) $x['label'], 'crumb' => (string) ($x['crumb'] ?? ''), 'kind' => (string) ($x['kind'] ?? '')], (array) ($sug['items'] ?? []))),
                             'dym' => array_values(array_map(fn ($x) => ['q' => $x['q'], 'situation' => $x['situation'] ?? null], (array) ($sug['did_you_mean'] ?? [])))],
                // the workbench (Jason, 2026-10-03): what a visitor sees after Enter, each word's senses, and the situations
                'after' => ['situation' => $r['situation']['labels'] ?? [],
                            'needs' => array_values(array_map(fn ($n) => ['label' => (string) $n['label'], 'n' => count($n['items'] ?? []), 'first' => array_slice(array_column($n['items'] ?? [], 'label'), 0, 2)], (array) ($r['situation']['needs'] ?? []))),
                            'items' => array_values(array_map(fn ($x) => ['label' => (string) $x['label'], 'sub' => (string) ($x['sub'] ?? ''), 'kind' => (string) ($x['kind'] ?? '')],
                                       array_slice(array_values(array_filter((array) ($r['results']['items'] ?? []), fn ($x) => ($x['kind'] ?? '') !== 'topic')), 0, 5))),
                            'kinds' => array_values(array_map(fn ($x) => (string) $x['label'], array_slice(array_values(array_filter((array) ($r['results']['items'] ?? []), fn ($x) => ($x['kind'] ?? '') === 'topic')), 0, 3))),
                            'elsewhere' => array_values(array_map(fn ($t) => $t['town'] . ' (' . $t['count'] . ')', (array) ($r['elsewhere']['towns'] ?? []))),
                            'dym' => array_values(array_map(fn ($x) => ['q' => $x['q'], 'situation' => $x['situation'] ?? null, 'score' => $x['score']], (array) ($r['did_you_mean_all'] ?? []))),
                            'learned' => (array) ($r['learned'] ?? []), 'when' => $r['parse']['when'] ?? null],
                'senses' => class_exists('WordSenses') ? WordSenses::explain($pdo, $q) : [],
                'kinds' => (function () use ($pdo, $q) { SituationReasoner::load($pdo); return SituationReasoner::kinds($q); })(),
                // each word: its lexical category, its job and W, and whether search recognizes it (decisions/0063)
                'lexicon' => array_map(fn ($x) => array_diff_key($x, ['at' => 1]), Lexicon::read($pdo, $q)),
                'edits' => SearchEdits::recent($pdo, 6),
                'audiences' => SearchIndex::AUDIENCE_LABEL,
                'removed' => (function () use ($pdo, $q) {
                    if (!SuggestionFlags::ready($pdo)) return [];
                    $st = $pdo->prepare('SELECT id, shown, kind, blocked, removed_n FROM search_suggestion_flags WHERE q = ? AND (blocked = 1 OR removed_n > 0) ORDER BY updated_at DESC');
                    $st->execute([SuggestionFlags::norm($q)]); return $st->fetchAll(PDO::FETCH_ASSOC);
                })(),
                'situations' => Situations::adminFind($pdo, $q),
                'near' => array_values(array_map(fn ($x) => (string) $x['label'], (array) ($r['situation_near'] ?? [])))]);
        }
        // ---- Meanings: the words and rules the meaning layer reads situations with (built-in, and taught here) ----
        // a suggestion removed by staff (decisions/0063 §3): blocked for these words at once; Undo restores it
        if ($do === 'sugg_block' || $do === 'sugg_restore') {
            if (!SuggestionFlags::ready($pdo)) Response::error('Run app/migrations/2026-10-28_lexicon.sql in phpMyAdmin first.', 503, 'not_configured');
            if ($do === 'sugg_block') Response::json(['ok' => true, 'id' => SuggestionFlags::remove($pdo, $q, (string) ($_POST['shown'] ?? ''), (string) ($_POST['kind'] ?? 'pred'), (int) $me['id'])]);
            SuggestionFlags::restore($pdo, (int) ($_POST['id'] ?? 0)); Response::json(['ok' => true]);
        }
        if (in_array($do, ['meanings', 'meaning_add', 'meaning_set', 'forms_add', 'meaning_del', 'frame_add', 'frame_del', 'sense_add', 'sense_del'], true)) {
            try { $pdo->query('SELECT 1 FROM search_meanings LIMIT 1'); } catch (Throwable) { Response::error('Run app/migrations/2026-10-21_search_meanings.sql in phpMyAdmin first.', 503, 'not_configured'); }
            SituationReasoner::load($pdo);
            $classes = SituationReasoner::classes();
            $cls = fn (string $c) => (bool) preg_match('/^[a-z][a-z0-9-]{1,29}$/', $c);
            $hasPos = true; try { $pdo->query('SELECT pos FROM search_meanings LIMIT 1'); } catch (Throwable) { $hasPos = false; }
            $pos = (string) ($_POST['pos'] ?? '');
            if ($pos !== '' && !isset(Lexicon::POS[$pos])) Response::error('Pick its category (noun, verb…).', 422, 'bad_request');
            // the word's reading, set in one go from the Workbench lightbox: its taught rows are replaced (built-in ones stay)
            if ($do === 'meaning_set' || $do === 'forms_add') {
                $kind = (string) ($_POST['kind'] ?? ''); $c = mb_strtolower(trim((string) ($_POST['class'] ?? '')));
                if (!isset(SituationReasoner::KINDS[$kind]) || !$cls($c)) Response::error('Pick what job it does and its meaning.', 422, 'bad_request');
                if ($kind === 'time' && !isset(SituationReasoner::TIME_CLASSES[$c])) Response::error('Pick when it means: now, today, upcoming, a season…', 422, 'bad_request');
                $weak = !empty($_POST['weak']) && in_array($kind, ['event', 'action'], true) ? 1 : 0;
                $list = $do === 'meaning_set' ? [(string) ($_POST['word'] ?? '')] : explode(',', (string) ($_POST['forms'] ?? ''));
                $list = array_values(array_filter(array_map(fn ($x) => mb_strtolower(trim(preg_replace('/\s+/', ' ', $x))), $list), fn ($x) => mb_strlen($x) >= 2 && mb_strlen($x) <= 60));
                if (!$list) Response::error('A word or short phrase, 2 to 60 characters.', 422, 'bad_request');
                $ins = $hasPos ? $pdo->prepare('INSERT INTO search_meanings (kind, class, word, weak, pos, updated_by) VALUES (?, ?, ?, ?, ?, ?)')
                               : $pdo->prepare('INSERT INTO search_meanings (kind, class, word, weak, updated_by) VALUES (?, ?, ?, ?, ?)');
                foreach ($list as $w) {
                    if ($do === 'meaning_set') $pdo->prepare('DELETE FROM search_meanings WHERE word = ?')->execute([$w]);
                    else { $st = $pdo->prepare('SELECT 1 FROM search_meanings WHERE kind = ? AND class = ? AND word = ?'); $st->execute([$kind, $c, $w]); if ($st->fetchColumn()) continue; }
                    $ins->execute($hasPos ? [$kind, $c, $w, $weak, $pos, (int) $me['id']] : [$kind, $c, $w, $weak, (int) $me['id']]);
                }
                Response::json(['ok' => true, 'words' => $list, 'new_class' => !in_array($c, $classes[$kind] ?? [], true)]);
            }
            if ($do === 'meaning_add') {
                $kind = (string) ($_POST['kind'] ?? ''); $c = mb_strtolower(trim((string) ($_POST['class'] ?? ''))); $w = mb_strtolower(trim(preg_replace('/\s+/', ' ', (string) ($_POST['word'] ?? ''))));
                if (!isset(SituationReasoner::KINDS[$kind]) || !$cls($c)) Response::error('Pick what kind of meaning it is (a class of 2 to 30 letters).', 422, 'bad_request');
                if ($kind === 'time' && !isset(SituationReasoner::TIME_CLASSES[$c])) Response::error('Pick when it means: now, today, upcoming, a season…', 422, 'bad_request');
                if (mb_strlen($w) < 2 || mb_strlen($w) > 60) Response::error('A word or short phrase, 2 to 60 characters.', 422, 'bad_request');
                $st = $pdo->prepare('SELECT 1 FROM search_meanings WHERE kind = ? AND class = ? AND word = ?'); $st->execute([$kind, $c, $w]);
                if (!$st->fetchColumn()) {
                    $wk = !empty($_POST['weak']) && in_array($kind, ['event', 'action'], true) ? 1 : 0;
                    if ($hasPos) $pdo->prepare('INSERT INTO search_meanings (kind, class, word, weak, pos, updated_by) VALUES (?, ?, ?, ?, ?, ?)')->execute([$kind, $c, $w, $wk, $pos, (int) $me['id']]);
                    else $pdo->prepare('INSERT INTO search_meanings (kind, class, word, weak, updated_by) VALUES (?, ?, ?, ?, ?)')->execute([$kind, $c, $w, $wk, (int) $me['id']]);
                }
                Response::json(['ok' => true, 'new_class' => !in_array($c, $classes[$kind], true)]);
            }
            if ($do === 'meaning_del') { $pdo->prepare('DELETE FROM search_meanings WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]); Response::json(['ok' => true]); }
            if ($do === 'frame_add') {
                $ev = (string) ($_POST['event'] ?? ''); $th = array_values(array_filter(array_map('trim', explode(',', (string) ($_POST['things'] ?? '')))));
                $slug = (string) ($_POST['slug'] ?? ''); $why = mb_substr(trim((string) ($_POST['why'] ?? '')), 0, 200);
                if (!in_array($ev, array_merge($classes['event'], $classes['action']), true)) Response::error('Pick an event or an action.', 422, 'bad_request');
                foreach ($th as $t0) if (!in_array($t0, array_merge($classes['thing'], $classes['tool']), true)) Response::error('"' . $t0 . '" isn\'t a kind of thing or tool yet. Teach a word for it first.', 422, 'bad_request');
                $st = $pdo->prepare('SELECT 1 FROM situations WHERE slug = ?'); $st->execute([$slug]);
                if (!$st->fetchColumn()) Response::error('Pick the situation it means.', 422, 'bad_request');
                $pdo->prepare('INSERT INTO search_frames (event, things, slug, why, updated_by) VALUES (?, ?, ?, ?, ?)')->execute([$ev, implode(',', $th), $slug, $why, (int) $me['id']]);
                Response::json(['ok' => true]);
            }
            if ($do === 'frame_del') { $pdo->prepare('DELETE FROM search_frames WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]); Response::json(['ok' => true]); }
            // the 5 W's per word (word senses): a word's meaning by the words around it
            require_once __DIR__ . '/../../app/lib/WordSenses.php';
            $sensesReady = true; try { $pdo->query('SELECT 1 FROM search_senses LIMIT 1'); } catch (Throwable) { $sensesReady = false; }
            if ($do === 'sense_add') {
                if (!$sensesReady) Response::error('Run app/migrations/2026-10-24_word_senses.sql in phpMyAdmin first.', 503, 'not_configured');
                $word = mb_strtolower(trim((string) ($_POST['word'] ?? ''))); $W = (string) ($_POST['w'] ?? '');
                $forms = implode(', ', array_values(array_filter(array_map(fn ($f) => mb_strtolower(trim($f)), explode(',', (string) ($_POST['forms'] ?? ''))), fn ($f) => preg_match('/^[a-z0-9]{2,30}$/', $f))));
                $label = mb_substr(trim((string) ($_POST['label'] ?? '')), 0, 80); $why = mb_substr(trim((string) ($_POST['why'] ?? '')), 0, 200);
                $cues = implode(', ', array_values(array_filter(array_map(fn ($c) => mb_strtolower(trim($c)), explode(',', (string) ($_POST['cues'] ?? ''))), fn ($c) => $c !== '')));
                if (!preg_match('/^[a-z0-9]{2,30}$/', $word)) Response::error('One word, 2 to 30 letters, as people type it.', 422, 'bad_request');
                if (!isset(WordSenses::W[$W])) Response::error('Pick its W.', 422, 'bad_request');
                $effect = 'none';
                if ($W === 'why') { $slug = (string) ($_POST['slug'] ?? ''); $st = $pdo->prepare('SELECT 1 FROM situations WHERE slug = ?'); $st->execute([$slug]); if (!$st->fetchColumn()) Response::error('Pick the situation it means.', 422, 'bad_request'); $effect = 'sit:' . $slug; }
                elseif ($W === 'when') { $k = (string) ($_POST['season'] ?? ''); if (!isset(WordSenses::SEASONS[$k])) Response::error('Pick the season.', 422, 'bad_request'); $effect = 'season:' . $k; }
                elseif ($W === 'where' || $W === 'what') { $as = mb_strtolower(trim((string) ($_POST['as'] ?? ''))); if (!preg_match('/^[a-z0-9 &\'-]{2,60}$/', $as)) Response::error('Say what to read it as (2 to 60 letters).', 422, 'bad_request'); $effect = 'words:' . $as; }
                if ($label === '') $label = $W === 'none' ? 'A passing remark' : ($W === 'why' ? 'A situation' : ucfirst(substr($effect, strpos($effect, ':') + 1)));
                if (mb_strlen($cues) > 400) Response::error('Fewer words around it, please (400 characters at most).', 422, 'bad_request');
                $pdo->prepare('INSERT INTO search_senses (word, forms, w, label, cues, effect, why, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')->execute([$word, $forms, $W, $label, $cues, $effect, $why, (int) $me['id']]);
                Response::json(['ok' => true]);
            }
            if ($do === 'sense_del') { if ($sensesReady) $pdo->prepare('DELETE FROM search_senses WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]); Response::json(['ok' => true]); }
            $senses = $sensesReady ? $pdo->query('SELECT id, word, forms, w, label, cues, effect, why FROM search_senses ORDER BY word, id')->fetchAll(PDO::FETCH_ASSOC) : [];
            $sits = $pdo->query("SELECT slug, label FROM situations WHERE status IN ('live', 'may_help', 'draft') ORDER BY label")->fetchAll(PDO::FETCH_KEY_PAIR);
            $words = $pdo->query('SELECT id, kind, class, word, weak' . ($hasPos ? ', pos' : ", '' AS pos") . ' FROM search_meanings ORDER BY kind, class, word')->fetchAll(PDO::FETCH_ASSOC);
            $frames = $pdo->query('SELECT id, event, things, slug, why FROM search_frames ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
            foreach ($frames as &$f0) $f0['label'] = $sits[$f0['slug']] ?? $f0['slug'];
            unset($f0);
            Response::json(['ok' => true, 'builtin' => SituationReasoner::builtIn(), 'classes' => $classes, 'kinds' => SituationReasoner::KINDS, 'pos' => Lexicon::POS, 'kind_pos' => Lexicon::KIND_POS, 'time_classes' => SituationReasoner::TIME_CLASSES, 'words' => $words, 'frames' => $frames,
                            'senses' => $senses, 'senses_ready' => $sensesReady, 'senses_builtin' => WordSenses::builtIn(), 'groups' => array_keys(WordSenses::GROUPS),
                            'situations' => array_map(fn ($k, $v) => ['slug' => $k, 'label' => $v], array_keys($sits), array_values($sits))]);
        }
        if ($do === 'get') { $s0 = Situations::adminGet($pdo, (int) ($_GET['id'] ?? 0)); $s0 ? Response::json(['ok' => true, 'situation' => $s0]) : Response::error('That situation is gone.', 404, 'not_found'); }
        // ---- the 5 W's, corrected one at a time (decisions/0063 §4) ----
        // a reading of the searches with the word, without the change or with it (written in a transaction and rolled
        // back: nothing is kept). The Workbench asks for both, each in its own request, and shows what would change.
        if ($do === 'edit_read') {
            $c = json_decode((string) ($_POST['change'] ?? ''), true);
            if (!is_array($c)) Response::error('Nothing to try.', 422, 'bad_request');
            $chk = SearchEdits::check($pdo, $c);   // throws with the reason
            $qs = SearchEdits::samples($pdo, $q, $chk['word']);
            $with = !empty($_POST['with']);
            Response::json(['ok' => true, 'summary' => $chk['summary'], 'samples' => $qs, 'readings' => SearchEdits::readings($pdo, $qs, $with ? $chk : null, (int) $me['id'])]);
        }
        if ($do === 'edit_save') {
            if (!SearchEdits::ready($pdo)) Response::error('Run app/migrations/2026-10-29_search_edits.sql in phpMyAdmin first.', 503, 'not_configured');
            $c = json_decode((string) ($_POST['change'] ?? ''), true);
            $chk = SearchEdits::check($pdo, is_array($c) ? $c : []);
            $id = SearchEdits::save($pdo, $chk, (int) $me['id'], (int) ($_POST['changed'] ?? 0));
            Response::json(['ok' => true, 'id' => $id, 'summary' => $chk['summary']]);
        }
        if ($do === 'edit_undo') Response::json(['ok' => true, 'note' => SearchEdits::undo($pdo, (int) ($_POST['id'] ?? 0), (int) $me['id'])]);
        // ---- drafts from missed searches (decisions/0063 §7): proposed by the nightly run, decided here ----
        if (in_array($do, ['drafts', 'drafts_refresh', 'draft_approve', 'draft_dismiss'], true)) {
            if (!SearchDrafts::ready($pdo)) Response::error('Run app/migrations/2026-10-31_search_drafts.sql in phpMyAdmin first.', 503, 'not_configured');
            $note = '';
            if ($do === 'drafts_refresh') { $r = SearchDrafts::refresh($pdo); $note = $r['new'] . ' new, ' . $r['seen'] . ' proposed in all.'; }
            if ($do === 'draft_approve') {
                if (!SearchEdits::ready($pdo)) Response::error('Run app/migrations/2026-10-29_search_edits.sql in phpMyAdmin first.', 503, 'not_configured');
                $over = array_filter(['name' => $_POST['name'] ?? null, 'parent' => $_POST['parent'] ?? null, 'terms' => $_POST['terms'] ?? null, 'also' => $_POST['also'] ?? null], fn ($v) => $v !== null);   // a missing kind, as edited
                $note = 'Saved: ' . SearchDrafts::approve($pdo, (int) ($_POST['id'] ?? 0), (int) $me['id'], $over) . '. Undo is under “Recent corrections”.';
            }
            if ($do === 'draft_dismiss') { SearchDrafts::dismiss($pdo, (int) ($_POST['id'] ?? 0), (int) $me['id']); $note = 'Dismissed. It comes back only if three times as many searches miss.'; }
            $rows = array_map(fn ($d) => ['id' => (int) $d['id'], 'type' => $d['type'], 'proposal' => $d['proposal'], 'change' => json_decode((string) $d['change_json'], true),
                                          'evidence' => $d['evidence'], 'examples' => array_values(array_filter(explode("\n", (string) $d['examples']))), 'score' => (int) $d['score']], SearchDrafts::list($pdo));
            $tops = $pdo->query('SELECT name FROM categories WHERE parent_id IS NULL AND is_active = 1 ORDER BY name')->fetchAll(PDO::FETCH_COLUMN);
            Response::json(['ok' => true, 'note' => $note, 'drafts' => $rows, 'tops' => $tops]);
        }
        // ---- words for each kind of place (decisions/0067, category_terms): read by search at once ----
        if (in_array($do, ['terms_get', 'term_add', 'term_del', 'also_set'], true)) {
            try { $pdo->query('SELECT 1 FROM category_terms LIMIT 1'); } catch (Throwable) { Response::error('Run app/migrations/2026-11-07_category_terms.sql in phpMyAdmin first.', 503, 'not_configured'); }
            $st = $pdo->prepare('SELECT id, name FROM categories WHERE name = ? AND is_active = 1'); $st->execute([trim((string) ($_POST['category'] ?? ''))]);
            $cat = $st->fetch(PDO::FETCH_ASSOC) ?: Response::error('Pick a kind of place from the list.', 422, 'no_category');
            $term = mb_substr(mb_strtolower(trim((string) ($_POST['term'] ?? ''))), 0, 80);
            if ($do === 'term_add') {
                if (mb_strlen($term) < 2) Response::error('Type the word or phrase people search.', 422, 'short');
                $has = $pdo->prepare('SELECT 1 FROM category_terms WHERE category_id = ? AND term = ?'); $has->execute([(int) $cat['id'], $term]);
                if (!$has->fetchColumn()) $pdo->prepare("INSERT INTO category_terms (category_id, term, source, created_by) VALUES (?, ?, 'staff', ?)")->execute([(int) $cat['id'], $term, (int) $me['id']]);
            }
            if ($do === 'term_del') $pdo->prepare('DELETE FROM category_terms WHERE category_id = ? AND term = ?')->execute([(int) $cat['id'], $term]);
            // the other main groups it also shows under (decisions/0082)
            require_once __DIR__ . '/../../app/lib/CategoryAlso.php';
            if ($do === 'also_set') { try { CategoryAlso::set($pdo, (int) $cat['id'], array_filter(explode('|', (string) ($_POST['also'] ?? '')))); } catch (RuntimeException $x) { Response::error($x->getMessage(), 503, 'not_configured'); } }
            $hm = $pdo->prepare('SELECT g.name FROM categories c LEFT JOIN categories g ON g.id = c.parent_id WHERE c.id = ?'); $hm->execute([(int) $cat['id']]);
            $st = $pdo->prepare('SELECT term, source FROM category_terms WHERE category_id = ? ORDER BY term'); $st->execute([(int) $cat['id']]);
            Response::json(['ok' => true, 'category' => $cat['name'], 'terms' => $st->fetchAll(PDO::FETCH_ASSOC), 'home' => (string) ($hm->fetchColumn() ?: ''),
                            'also' => array_column(CategoryAlso::groupsOf($pdo, (int) $cat['id']), 'name'), 'also_ready' => CategoryAlso::ready($pdo),
                            'tops' => $pdo->query('SELECT name FROM categories WHERE parent_id IS NULL AND is_active = 1 ORDER BY name')->fetchAll(PDO::FETCH_COLUMN)]);
        }
        if ($do === 'places') {   // towns and our areas, as typed (for "a local name for…")
            $st = $pdo->prepare("SELECT DISTINCT city FROM zip_coordinates WHERE city LIKE ? ORDER BY (city LIKE ?) DESC, city LIMIT 10");
            $st->execute(['%' . $q . '%', $q . '%']);
            $out = array_map(fn ($c) => ucwords(mb_strtolower((string) $c)), $st->fetchAll(PDO::FETCH_COLUMN));
            try { $st = $pdo->prepare("SELECT name FROM micro_clusters WHERE name LIKE ? AND name NOT LIKE '%(auto-seeded%' LIMIT 6"); $st->execute(['%' . $q . '%']); $out = array_merge($out, $st->fetchAll(PDO::FETCH_COLUMN)); } catch (Throwable) {}
            Response::json(['ok' => true, 'places' => array_values(array_unique($out))]);
        }
        if ($do === 'cats') {   // category names for a need, as typed
            $st = $pdo->prepare("SELECT name FROM categories WHERE is_active = 1 AND name LIKE ? ORDER BY (name LIKE ?) DESC, name LIMIT 12");
            $st->execute(['%' . $q . '%', $q . '%']);
            Response::json(['ok' => true, 'cats' => $st->fetchAll(PDO::FETCH_COLUMN)]);
        }
        if ($do === 'phrase') { $r = Situations::adminAddPhrase($pdo, (int) ($_POST['id'] ?? 0), $q); isset($r['error']) ? Response::error($r['error'], 422, 'bad_request') : Response::json(['ok' => true] + $r); }
        if ($do === 'unphrase') { Situations::adminRemovePhrase($pdo, (int) ($_POST['id'] ?? 0), $q); Response::json(['ok' => true]); }
        // the frame-first builder's check (decisions/0063 §6): the example searches and recent searches, read without
        // the situation as edited or with it (rolled back). The builder asks for both and compares.
        // "Build it from these" (Jason, 2026-10-04): the rule read straight from how people search. Each example's
        // first event or action is the first part, its things and tools the second. A word search doesn't know is
        // offered to teach: a verb with no event or action is what happened, a noun with no thing is what it's about.
        if ($do === 'auto_rules') {
            SituationReasoner::load($pdo);
            $rules = []; $teach = []; $notes = [];
            foreach (array_slice(array_filter(array_map('trim', preg_split('/\r?\n/', (string) ($_POST['examples'] ?? '')))), 0, 12) as $ex) {
                $read = Lexicon::read($pdo, $ex);
                $lead = ''; $things = []; $unk = [];
                foreach ($read as $i => $x) {
                    if ($x['little'] || str_contains($x['word'], ' ') && !$x['known']) continue;
                    if (in_array($x['kind'], ['event', 'action'], true)) { if ($lead === '') $lead = $x['class']; continue; }
                    if (in_array($x['kind'], ['thing', 'tool'], true)) { $things[] = $x['class']; continue; }
                    if (!$x['known'] || in_array($x['kind'], ['category', 'name', ''], true)) $unk[] = [$x['word'], $x['pos'], $i, $x['known'], $x['kind']];
                }
                $after = mb_strtolower($ex);
                foreach ($unk as [$w, $pos, $i, $known, $kind]) {
                    if (!preg_match('/^[a-z][a-z\'-]{1,29}$/', $w) || in_array($w, ['someone', 'someones', 'my', 'a', 'the'], true)) continue;
                    $prev = $read[$i - 1]['word'] ?? ''; $nextW = $read[$i + 1]['word'] ?? '';
                    // what happened: a verb, a past form ("spotted", "broken", "found", "lost"), or the word right before
                    // "a", "my", "someone's"… ("found a wallet": "found" is done to the wallet)
                    $verbish = $pos === 'verb' || preg_match('/(ed|en|ing)$/', $w)
                        || in_array($w, ['found', 'lost', 'left', 'saw', 'seen', 'hit', 'broke', 'stuck', 'dropped', 'ran', 'got', 'took', 'stole', 'stolen', 'need', 'want'], true)
                        || in_array($nextW, ['a', 'an', 'the', 'my', 'your', 'his', 'her', 'their', 'our', 'someones', "someone's", 'someone', 'some'], true);
                    if ($lead === '' && $verbish) {
                        $k = in_array($prev, ['to', 'need', 'want', 'get', 'how to'], true) ? 'action' : 'event';
                        $teach[$w] = ['word' => $w, 'kind' => $k, 'class' => $w, 'plain' => $k === 'action' ? 'what they want done' : 'what happened'];
                        $lead = $w;
                    } elseif ($pos === 'noun' || !$known || $kind === 'category') {
                        if ($known && $kind === 'name') continue;   // a word that's part of a name ("Show Low") stays as it is
                        $teach[$w] = ['word' => $w, 'kind' => 'thing', 'class' => $w, 'plain' => 'what it\'s about'];
                        $things[] = $w;
                    }
                }
                if ($lead === '') { $notes[] = '"' . $ex . '": no word says what happened or what they want done.'; continue; }
                $rules[$lead] = array_values(array_unique(array_merge($rules[$lead] ?? [], $things)));
            }
            $out = [];
            foreach ($rules as $l => $t) $out[] = ['lead' => (string) $l, 'things' => $t];
            Response::json(['ok' => true, 'rules' => $out, 'teach' => array_values($teach), 'notes' => $notes]);
        }
        if ($do === 'sit_test') {
            $in = json_decode((string) ($_POST['form'] ?? ''), true);
            if (!is_array($in)) Response::error('Nothing to test.', 422, 'bad_request');
            // testing comes before it's complete: no rule, need or name is needed yet (saving still asks for them)
            if (trim((string) ($in['label'] ?? '')) === '') $in['label'] = 'This situation';
            [$c, $err] = Situations::adminClean($in);
            if (!$c['needs']) $c['needs'] = [['label' => 'Answers', 'track' => 'resident', 'cats' => '', 'words' => 'test', 'kinds' => 'listing', 'requires' => '']];
            SituationReasoner::load($pdo); $cls = SituationReasoner::classes(); SituationReasoner::reset();
            foreach ($c['frames'] as $f) {
                if (!in_array($f['lead'], array_merge($cls['event'], $cls['action']), true)) Response::error('"' . $f['lead'] . '" isn\'t an event or action we know. Teach it first.', 422, 'bad_request');
                foreach ($f['things'] as $t) if (!in_array($t, array_merge($cls['thing'], $cls['tool']), true)) Response::error('"' . $t . '" isn\'t a thing or tool we know.', 422, 'bad_request');
            }
            $recent = [];
            try { $st = $pdo->prepare('SELECT q, SUM(n) AS n FROM search_terms WHERE day >= ? GROUP BY q ORDER BY n DESC LIMIT 60'); $st->execute([date('Y-m-d', time() - 90 * 86400)]); $recent = $st->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable) {}
            $searches = array_values(array_unique(array_merge($c['examples'], array_map('strval', $recent))));
            Response::json(['ok' => true, 'examples' => $c['examples']] + Situations::adminTest($pdo, (int) ($in['id'] ?? 0), $c, $searches, !empty($_POST['with']), (int) $me['id']));
        }
        if ($do === 'save' || $do === 'preview') {
            $in = json_decode((string) ($_POST['form'] ?? ''), true);
            if (!is_array($in)) Response::error('Nothing to save.', 422, 'bad_request');
            [$c, $err] = Situations::adminClean($in);
            if ($do === 'preview') {
                $place = UniversalSearch::scopePlace($pdo, $ctx);
                Response::json(['ok' => true, 'problems' => $err, 'answer' => Situations::adminPreview($pdo, $c, $place, ['center' => $centerOf($place), 'reach' => 'all'])]);
            }
            if ($err) Response::error(implode(' ', $err), 422, 'bad_request');
            SituationReasoner::load($pdo); $cls = SituationReasoner::classes();
            foreach ($c['frames'] as $f) if (!in_array($f['lead'], array_merge($cls['event'], $cls['action']), true)) Response::error('"' . $f['lead'] . '" isn\'t an event or action we know.', 422, 'bad_request');
            $id = Situations::adminSave($pdo, (int) ($in['id'] ?? 0), $c, (int) $me['id']);
            Response::json(['ok' => true, 'id' => $id, 'situation' => Situations::adminGet($pdo, $id)]);
        }
        Response::error('What should this do?', 400, 'bad_request');
    } catch (InvalidArgumentException $ex) {
        Response::error($ex->getMessage(), 422, 'bad_request');
    } catch (Throwable $ex) {
        error_log('admin/search-misses.php editor: ' . $ex->getMessage());
        Response::error('That didn\'t work: ' . mb_substr($ex->getMessage(), 0, 200), 500, 'server_error');
    }
}

tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$areaList = [];
try { foreach ($pdo->query('SELECT slug, name FROM micro_clusters ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $mc) $areaList[(string) $mc['slug']] = PlaceScope::publicName((string) $mc['name']); } catch (Throwable) {}
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$days = (int) ($_GET['days'] ?? 30); if (!in_array($days, [7, 30, 90], true)) $days = 30;
$area = mb_substr((string) ($_GET['area'] ?? ''), 0, 40);
$since = date('Y-m-d', time() - $days * 86400);
const MISS_MIN = 3;   // words searched fewer times than this are never shown
const MISS_KINDS = [
    'unread'   => ["Couldn't tell", "Search couldn't read what was meant (no thing, place or situation it knows)."],
    'zero'     => ['Nothing found', 'It read the words but found nothing for them.'],
    'noplace'  => ['No place set', 'A situation needed a place first ("Where are you?").'],
    'again'    => ['Searched again', 'Nothing opened, and another search within a minute: the first answer probably missed.'],
    'no_open'  => ['Nothing opened', 'Results showed, but nothing was opened, called or peeked.'],
    'ignored'  => ['Offer ignored', '"Maybe you mean" was offered and not taken.'],
    'feedback' => ['Feedback', '"Feedback on these results" was tapped.'],
];

$ready = true;
try { $pdo->query('SELECT 1 FROM search_outcomes LIMIT 1'); } catch (PDOException) { $ready = false; }

$areaSql = $area !== '' ? ' AND place_key = ?' : '';
$args = $area !== '' ? [$since, $area === '~none' ? '' : $area] : [$since];   // '~none': searched with no place set
$tot = []; $rows = []; $pred = []; $areas = []; $err = '';
if ($ready) {
    try {
        $st = $pdo->prepare("SELECT outcome, SUM(n) AS n FROM search_outcomes WHERE day >= ?$areaSql GROUP BY outcome");
        $st->execute($args);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $tot[(string) $r['outcome']] = (int) $r['n'];
        // each set of words: how often searched, and how each search turned out; the most missed first. The totals are
        // written out, not referred to by name: MySQL won't take an alias of a SUM inside HAVING or ORDER BY arithmetic.
        $sum = fn (string $in) => "SUM(CASE WHEN outcome IN ($in) THEN n ELSE 0 END)";
        $cols = implode(', ', array_map(fn ($k) => $sum("'$k'") . " AS `$k`", array_merge(['search'], array_keys(MISS_KINDS))));
        $missSql = $sum("'unread','zero','noplace','again','no_open','feedback'");
        $st = $pdo->prepare("SELECT q, $cols, $missSql AS misses, COUNT(DISTINCT place_key) AS areas FROM search_outcomes WHERE day >= ?$areaSql GROUP BY q
                             HAVING " . $sum("'search'") . " >= " . MISS_MIN . " AND $missSql > 0 ORDER BY misses DESC, `search` DESC LIMIT 60");
        $st->execute($args);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        // the predictions while typing (decisions/0061): for each set of words typed, how often a prediction was picked,
        // the words were searched, or they were left: with predictions showing (they didn't connect) or with nothing to
        // predict (missing). Written out in full again for MySQL.
        $leftSql = $sum("'left_pred','left_none'");
        $st = $pdo->prepare("SELECT q, " . $sum("'picked'") . " AS picked, " . $sum("'search'") . " AS searched, " . $sum("'left_pred'") . " AS left_pred, " . $sum("'left_none'") . " AS left_none
                             FROM search_outcomes WHERE day >= ?$areaSql AND outcome IN ('picked', 'search', 'left_pred', 'left_none') GROUP BY q
                             HAVING " . $sum("'picked','search','left_pred','left_none'") . " >= " . MISS_MIN . " AND $leftSql > 0
                             ORDER BY $leftSql DESC, " . $sum("'left_none'") . " DESC LIMIT 60");
        $st->execute($args);
        $pred = $st->fetchAll(PDO::FETCH_ASSOC);
        $st = $pdo->prepare("SELECT place_key, SUM(n) AS n FROM search_outcomes WHERE day >= ? AND outcome = 'search' GROUP BY place_key ORDER BY n DESC LIMIT 40");
        $st->execute([$since]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $k = (string) $r['place_key']; $label = $k === '' ? 'No place set' : $k;
            if ($k !== '') { try { [$label] = Links::resolve($pdo, 'place', $k); } catch (Throwable) {} }
            $areas[$k === '' ? '~none' : $k] = $label . ' (' . number_format((int) $r['n']) . ')';
        }
    } catch (Throwable $ex) {   // say what went wrong rather than a blank page
        error_log('admin/search-misses.php: ' . $ex->getMessage());
        $err = $ex->getMessage();
    }
}
$searches = $tot['search'] ?? 0;
$pct = fn (int $a) => $searches > 0 ? round(100 * $a / $searches) : 0;

tv_page_start('Missed searches', ['section' => 'admin', 'active' => 'misses', 'crumbs' => [['Admin', '/admin/'], ['Search tools', '/admin/search-misses.php'], ['Missed searches']],
    'description' => 'What people searched for that search did not catch.']);
require_once __DIR__ . '/../../app/ui/table-kit.php'; echo tv_table_kit();   // the table standard (design/table-standard.md, T4)
?>
<style>
  .ms-top{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem;margin:.6rem 0 1rem}
  .ms-top a{font-size:.82rem;border:1px solid #CBB98D;border-radius:999px;padding:.25rem .75rem;background:#FFFBF2;color:#3E2B1F;text-decoration:none}
  .ms-top a.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .ms-top select{font-size:.82rem;border:1px solid #CBB98D;border-radius:.5rem;padding:.25rem .4rem;background:#FFFBF2;color:#3E2B1F;max-width:100%}
  .ms-tiles{display:grid;gap:.5rem;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));margin-bottom:1rem}
  .ms-t{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:.6rem .75rem}.ms-t b{display:block;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.4rem;color:#3E2B1F;line-height:1.1}
  .ms-t span{font-size:.75rem;color:#7A6348}
  .ms-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:.5rem;padding:.8rem .9rem;margin-bottom:.8rem}
  .ms-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.05rem;color:#3E2B1F;margin:0 0 .15rem}.ms-card p{font-size:.8rem;color:#5C4632;margin:0 0 .5rem}
  .ms-wrap{overflow-x:auto}.ms-tab{width:100%;border-collapse:collapse;font-size:.8rem;color:#3E2B1F}
  .ms-tab th{text-align:right;font-weight:600;font-size:.7rem;color:#7A6348;padding:.3rem .35rem;border-bottom:1px solid #CBB98D;white-space:nowrap}.ms-tab th:first-child{text-align:left}
  .ms-tab td{text-align:right;padding:.3rem .35rem;border-bottom:1px solid #EADFC4}.ms-tab td:first-child{text-align:left;max-width:16rem;overflow-wrap:anywhere}
  .ms-tab td.z{color:#C9B89A}.ms-tab td.hot{color:#9A3412;font-weight:700}
  .ms-try{border:1px solid #CBB98D;background:#FFFBF2;color:#92400E;border-radius:999px;padding:.1rem .55rem;font-size:.72rem;cursor:pointer;margin-left:.3rem}
  /* phones: each row a small block, only what happened */
  @media (max-width:767px){
    .ms-tab thead{display:none}.ms-tab tr{display:flex;flex-wrap:wrap;gap:.15rem .7rem;padding:.45rem 0;border-bottom:1px solid #EADFC4}
    .ms-tab td{border:0;padding:0;text-align:left}.ms-tab td:first-child{flex:0 0 100%;max-width:none;font-weight:600}
    .ms-tab td[data-l]::before{content:attr(data-l) ' ';color:#7A6348;font-weight:400}.ms-tab td.z{display:none}
  }
  /* collapsed cards and forms: a summary line, open on a tap */
  .ms-fold>summary{list-style:none;cursor:pointer;display:flex;flex-wrap:wrap;align-items:baseline;gap:.2rem .6rem}.ms-fold>summary::-webkit-details-marker{display:none}
  .ms-fold>summary h2{display:inline;margin:0}.ms-fold>summary::after{content:'▸';margin-left:auto;color:#B45309;font-size:.85rem}.ms-fold[open]>summary::after{content:'▾'}
  .ms-fold[open]>summary{margin-bottom:.5rem}.ms-sum{font-size:.78rem;color:#7A6348}
  .mn-fd{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem}.mn-fd>summary{cursor:pointer;padding:.55rem .7rem;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;color:#3E2B1F;font-size:.92rem}
  .mn-fd>.mn-f{border:0;background:none;padding-top:0}
  .se-link{background:none;border:0;padding:0;color:#92400E;text-decoration:underline;font:inherit;font-size:.82rem;cursor:pointer}
  /* the workbench */
  .wb{display:grid;gap:.4rem 1rem;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr))}
  .wb h3{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:.92rem;color:#3E2B1F;margin:.5rem 0 .25rem}
  .wb-l{list-style:none;margin:0;padding:0}.wb-l li{padding:.3rem 0;border-top:1px solid #EADFC4;font-size:.82rem;color:#3E2B1F}
  .wb-l li small{display:block;color:#7A6348;font-size:.72rem}.wb-k{display:inline-block;min-width:4.4rem;font-size:.6rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#7A6348}
  .wb-sense{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.45rem;padding:.45rem .6rem;margin:.35rem 0;font-size:.8rem}
  .wb-sense ol{margin:.25rem 0 .3rem;padding-left:1.1rem}.wb-sense li{margin:.12rem 0}.wb-sense li.used{font-weight:700}.wb-sense li.used::marker{color:#1F5137}
  .wb-sense li small{display:block;font-weight:400;color:#7A6348;font-size:.72rem}.wb-w{display:inline-block;font-size:.6rem;font-weight:700;border-radius:999px;padding:0 .4rem;margin-right:.3rem;background:#F3E3CB;color:#7A4A1E;text-transform:uppercase;letter-spacing:.04em}
  .wb-acts{display:flex;flex-wrap:wrap;gap:.35rem;margin:.3rem 0}.wb-btn{border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:999px;padding:.2rem .65rem;font:inherit;font-size:.76rem;font-weight:600;cursor:pointer}
  .wb-btn:hover{background:#8FBCA8;border-color:#8FBCA8}
  .dr-l li{display:flex;flex-direction:column;gap:.1rem}.dr-l li>b{font-weight:600}.dr-ex{font-style:italic}.dr-b{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.25rem}.dr-ok{background:#8FBCA8;border-color:#8FBCA8}
  .ms-key{display:grid;gap:.25rem .8rem;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));font-size:.78rem;color:#5C4632}.ms-key b{color:#3E2B1F}
</style>
<?php require_once __DIR__ . '/../../app/ui/search-tools.php'; echo tv_search_tools_tabs('misses'); ?>
<h1 class="font-serif font-bold text-2xl text-[#3E2B1F]" style="margin:0">Search workbench</h1>
<p class="text-sm text-[#5C4632]" style="margin:.2rem 0 0">Try any words to see how search reads them and teach it, then the searches it missed below.
  Counts of the words, area and day only: nothing here is about who. Words show once <?= MISS_MIN ?> or more searches used them.</p>
<section class="ms-card tv-bleed se-teach" id="se-teach"><h2>Search workbench</h2>
  <p>Type a word, a phrase or a whole search. You'll see what a visitor sees (while typing, and after Enter), how each word is read (its W and its senses), and the situations that apply. The buttons under each part open the right form, already filled in.</p>
  <div class="se-box"><?= tv_icon('search', 'se-i') ?><input id="se-q" type="search" autocomplete="off" placeholder="fall, need a bathroom, stuck in the snow…" aria-label="Words someone might search"></div>
  <div class="se-an" id="se-an" aria-live="polite"><p class="se-hint" style="margin:0">Start typing: it reads as you go.</p></div>
  <div id="se-browse" hidden><p class="se-reads" id="se-reads"></p><div class="se-list" id="se-list"></div></div>
  <p style="margin:.5rem 0 0"><button type="button" class="se-link" data-browse aria-expanded="false">Browse all situations</button></p>
</section>
<?php $nDrafts = SearchDrafts::count($pdo); ?>
<details class="ms-card tv-bleed ms-fold" id="drafts"<?= $nDrafts ? ' open' : '' ?>><summary><h2>Drafts</h2><span class="ms-sum"><?= $nDrafts ? $nDrafts . ' word' . ($nDrafts === 1 ? '' : 's') . ' and rules to approve' : 'Words and rules proposed from missed searches' ?></span></summary>
  <p>Search learns words on its own (decisions/0064): words the dictionary knows are read at once, and every 6 hours the missed searches teach it new words, words that lead to one kind of place, and rules to situations that exist. When no situation answers searches yet, it makes one: named from the words people used, offering the kinds of places they opened, or that carry the words. All of it is applied and logged as <i>learned on its own</i> under Recent corrections, each with Undo; change any situation it made in Browse all situations. What shows here is only what it couldn't do on its own (too few searches yet, or nothing to offer). <b>Dismiss</b> sets one aside until three times as many searches miss.</p>
  <div id="dr-list"><p class="se-hint">Loading…</p></div>
  <p style="margin:.5rem 0 0"><button type="button" class="wb-btn" data-drrefresh>Refresh drafts now</button></p>
</details>
<details class="ms-card tv-bleed ms-fold" id="ct-card"><summary><h2>Words for each kind</h2><span class="ms-sum">The everyday words people search a kind of place by</span></summary>
  <p class="se-hint" style="margin:.5rem 0">Search reads these at once: add “cooking class” to Cooking Classes and that search finds it on the next try. The built-in words stay too; these are added on top.</p>
  <div class="ct-row"><input id="ct-cat" list="ct-cats" placeholder="A kind of place, e.g. Barbers" aria-label="Kind of place" autocomplete="off">
    <datalist id="ct-cats"><?php foreach ($pdo->query('SELECT name FROM categories WHERE is_active = 1 ORDER BY name')->fetchAll(PDO::FETCH_COLUMN) as $cn) echo '<option value="' . $e((string) $cn) . '">'; ?></datalist></div>
  <div id="ct-list"></div>
  <form class="ct-row" id="ct-add"><input id="ct-term" placeholder="A word or phrase people search, e.g. fade" aria-label="Word or phrase"><button type="submit" class="se-btn main"><?= tv_icon('plus', 'se-ii') ?> Add</button></form>
</details>
<details class="ms-card tv-bleed ms-fold" id="mn-card"><summary><h2>Meanings</h2><span class="ms-sum">Words, rules and senses search reads with</span></summary>
  <p>How search reads a situation from what words mean, with no phrase needed. Every <b>word</b> is one of five kinds: an <b>event</b> (what happened: bit, broke → Why), a <b>thing</b> (what it happened to: wallet, pipe → What), an <b>action</b> (how it's done: fix, install, register → who does it), a <b>tool</b> (generator, saw, app → narrows What) or a <b>time</b> (asap, upcoming, this morning → When). <b>Rules</b> say what an event or an action with a thing or tool means (harm + creature → An injury; repair + generator → Small engine repair). Teach new ones here; yours are checked before the built-in ones. ✦ Analyze shows each word's kind and which were used. How-to guides for actions are coming; for now an action leads to who does it.</p>
  <div class="mn-forms">
    <details class="mn-fd" id="mn-fd-word"><summary>Teach a word</summary><form class="mn-f" id="mn-word" novalidate>
      <label for="mn-w">Word or short phrase, as people type it</label><input type="text" id="mn-w" maxlength="60" placeholder="chewed, wallet, won't open">
      <label for="mn-kind">It is</label><select id="mn-kind"><?php foreach (SituationReasoner::KINDS as $k => [$kl, $kw]): ?><option value="<?= $k ?>"><?= htmlspecialchars($kl) ?> → <?= ucfirst($kw) ?></option><?php endforeach; ?></select>
      <label for="mn-class">Meaning</label><select id="mn-class"></select>
      <input type="text" id="mn-newc" maxlength="30" placeholder="name the new meaning: wallet, documents…" hidden aria-label="New meaning">
      <label class="mn-chk" id="mn-weakw"><input type="checkbox" id="mn-weak"> <span id="mn-weakt">Only with a thing or "got / was / by / my" (a word with other uses, like "cut")</span></label>
      <button type="submit" class="se-btn main"><?= tv_icon('plus', 'se-ii') ?> Add word</button></form></details>
    <details class="mn-fd" id="mn-fd-rule"><summary>Teach a rule</summary><form class="mn-f" id="mn-rule" novalidate>
      <label for="mn-ev">When the event or action is</label><select id="mn-ev"></select>
      <label>with any of these things or tools (none ticked: the event or action alone)</label><div class="mn-things" id="mn-things"></div>
      <label for="mn-sit">it means</label><select id="mn-sit"></select>
      <label for="mn-why">Because (shown in ✦ Analyze, optional)</label><input type="text" id="mn-why" maxlength="200" placeholder="a lost wallet means replacing an ID">
      <button type="submit" class="se-btn main"><?= tv_icon('plus', 'se-ii') ?> Add rule</button></form></details>
    <details class="mn-fd" id="mn-fd-sense"><summary>Teach a sense: the 5 W's per word</summary><form class="mn-f" id="mn-sense" novalidate>
      <p class="se-hint" style="margin:0 0 .3rem">A word with more than one meaning (“fall”: an injury, the season, a waterfall). Each sense says which W it is and the words around it that pick it; the first that fits wins.</p>
      <div class="mn-two"><div><label for="mn-sw">Word</label><input type="text" id="mn-sw" maxlength="30" placeholder="fall"></div>
        <div><label for="mn-sf">Its other forms</label><input type="text" id="mn-sf" maxlength="200" placeholder="falls, fell, falling"></div></div>
      <label for="mn-sW">It's a</label><select id="mn-sW"><option value="why">Why: what happened (a situation)</option><option value="when">When: a season</option><option value="where">Where: a place or feature</option><option value="what">What: a thing to find</option><option value="none">Nothing to search: a passing remark</option></select>
      <div id="mn-se-why"><label for="mn-ssit">It means</label><select id="mn-ssit"></select></div>
      <div id="mn-se-when" hidden><label for="mn-sseason">The season</label><select id="mn-sseason"><option value="fall">Fall (September to November)</option><option value="spring">Spring</option><option value="summer">Summer</option><option value="winter">Winter</option></select></div>
      <div id="mn-se-as" hidden><label for="mn-sas">Read it as</label><input type="text" id="mn-sas" maxlength="60" placeholder="waterfall"></div>
      <label for="mn-scues">When these are near (comma separated; empty: always)</label><input type="text" id="mn-scues" maxlength="400" placeholder="before:@person, next:down, stairs">
      <p class="se-hint" style="margin:.15rem 0 0">A word anywhere: <code>stairs</code>. Right after it: <code>next:festival</code>. Right before: <code>prev:this</code>. Before or after it: <code>before:tree</code>, <code>after:lawyer</code>. As typed: <code>form:falls</code>. Not with: <code>!@person</code>. Groups: <span id="mn-sgroups"></span>.</p>
      <label for="mn-slabel">What it means here (shown in ✦ Analyze)</label><input type="text" id="mn-slabel" maxlength="80" placeholder="An injury">
      <label for="mn-swhy">Because (optional)</label><input type="text" id="mn-swhy" maxlength="200" placeholder="a person fell: an accident">
      <button type="submit" class="se-btn main"><?= tv_icon('plus', 'se-ii') ?> Add sense</button></form></details>
  </div>
  <p class="se-err" id="mn-err" role="alert"></p>
  <h3 class="mn-h">Taught here</h3><div id="mn-taught"><p class="se-hint">Loading…</p></div>
  <details class="mn-built"><summary>Built-in meanings</summary><div id="mn-builtin"></div></details>
  <details class="mn-built"><summary>Built-in senses (the 5 W's per word)</summary><div id="mn-sbuiltin"></div></details>
</details>
<?php if (!$ready): ?>
<p class="ms-card tv-bleed">Run <code>app/migrations/2026-10-19_search_outcomes.sql</code> in phpMyAdmin to start counting.</p>
<?php else: ?>
<?php if ($err !== ''): ?><p class="ms-card tv-bleed">The counts couldn't be read: <code><?= $e(mb_substr($err, 0, 300)) ?></code></p><?php endif; ?>
<div class="ms-top">
  <?php foreach ([7, 30, 90] as $d): ?><a class="<?= $d === $days ? 'on' : '' ?>" href="?days=<?= $d ?><?= $area !== '' ? '&area=' . rawurlencode($area) : '' ?>">Last <?= $d ?> days</a><?php endforeach; ?>
  <form method="get" style="display:inline"><input type="hidden" name="days" value="<?= $days ?>">
    <select name="area" onchange="this.form.submit()" aria-label="Area"><option value="">All areas</option>
      <?php foreach ($areas as $k => $l): ?><option value="<?= $e($k) ?>"<?= $k === $area ? ' selected' : '' ?>><?= $e($l) ?></option><?php endforeach; ?></select></form>
</div>
<div class="ms-tiles">
  <div class="ms-t"><b><?= number_format($searches) ?></b><span>searches</span></div>
  <?php foreach (MISS_KINDS as $k => [$label]): ?><div class="ms-t"><b><?= number_format($tot[$k] ?? 0) ?></b><span><?= $e($label) ?> · <?= $pct($tot[$k] ?? 0) ?>%</span></div><?php endforeach; ?>
</div>
<details class="ms-card tv-bleed ms-fold"><summary><h2>Most missed</h2><span class="ms-sum"><?= count($rows) ?> set<?= count($rows) === 1 ? '' : 's' ?> of words missed <?= MISS_MIN ?>+ times</span></summary>
  <p>Each set of words, how often it was searched, and how those searches turned out. ✎ puts the words in <b>Teach search</b> above, where you can add them to a situation or start a new one; the eye tries them in search.</p>
  <?php if (!$rows): ?><p>Nothing missed <?= MISS_MIN ?> or more times in this period.</p><?php else: ?>
  <div class="ms-wrap"><table class="ms-tab" data-tv-table><thead><tr><th>Words</th><th>Searches</th><?php foreach (MISS_KINDS as [$label]): ?><th><?= $e($label) ?></th><?php endforeach; ?></tr></thead><tbody>
  <?php foreach ($rows as $r): $s = max(1, (int) $r['search']); ?>
    <tr><td><?= $e($r['q']) ?> <button type="button" class="se-ib" data-teach="<?= $e($r['q']) ?>" title="Teach search these words" aria-label="Teach search &ldquo;<?= $e($r['q']) ?>&rdquo;"><?= tv_icon('pen', 'se-ii') ?></button><button type="button" class="se-ib" data-try="<?= $e($r['q']) ?>" title="Try it in search" aria-label="Try &ldquo;<?= $e($r['q']) ?>&rdquo; in search"><?= tv_icon('eye', 'se-ii') ?></button><?= $area === '' && (int) $r['areas'] > 1 ? ' <span style="color:#8A7355">· ' . (int) $r['areas'] . ' areas</span>' : '' ?></td>
      <td data-l="Searches"><?= number_format((int) $r['search']) ?></td>
      <?php foreach (MISS_KINDS as $k => [$label]): $v = (int) $r[$k]; ?><td data-l="<?= $e($label) ?>" class="<?= $v === 0 ? 'z' : ($v * 2 >= $s ? 'hot' : '') ?>"><?= $v ?></td><?php endforeach; ?></tr>
  <?php endforeach; ?></tbody></table></div>
  <?php endif; ?>
</details>
<details class="ms-card tv-bleed ms-fold" id="ms-pred"><summary><h2>Predictions while typing</h2><span class="ms-sum">Picked <?= number_format((int) ($tot['picked'] ?? 0)) ?> · left with predictions <?= number_format((int) ($tot['left_pred'] ?? 0)) ?> · nothing to predict <?= number_format((int) ($tot['left_none'] ?? 0)) ?></span></summary>
  <?php $pk = $tot['picked'] ?? 0; $lp = $tot['left_pred'] ?? 0; $ln = $tot['left_none'] ?? 0; $pt = max(1, $pk + $lp + $ln + $searches); ?>
  <p>What happened to the words people typed: a prediction tapped (<b>Picked</b>), the words searched with Enter or “Search for…” (<b>Searched</b>), or the box closed or cleared with neither: <b>Left, predictions showed</b> (they didn't connect) or <b>Left, nothing to predict</b> (only “Search for…” showed: missing). ✦ shows what search predicts for the words now. Counts of the words, area and day only.</p>
  <div class="ms-tiles" style="margin:.2rem 0 .6rem">
    <div class="ms-t"><b><?= number_format($pk) ?></b><span>Picked · <?= round(100 * $pk / $pt) ?>%</span></div>
    <div class="ms-t"><b><?= number_format($lp) ?></b><span>Left, predictions showed · <?= round(100 * $lp / $pt) ?>%</span></div>
    <div class="ms-t"><b><?= number_format($ln) ?></b><span>Left, nothing to predict · <?= round(100 * $ln / $pt) ?>%</span></div>
  </div>
  <?php if (!$pred): ?><p>No words left <?= MISS_MIN ?> or more times in this period.</p><?php else: ?>
  <div class="ms-wrap"><table class="ms-tab" data-tv-table><thead><tr><th>Words typed</th><th>Picked</th><th>Searched</th><th>Left, predictions showed</th><th>Left, nothing to predict</th></tr></thead><tbody>
  <?php foreach ($pred as $r): $all = max(1, (int) $r['picked'] + (int) $r['searched'] + (int) $r['left_pred'] + (int) $r['left_none']); ?>
    <tr><td><?= $e($r['q']) ?> <button type="button" class="se-ib se-ai" data-predan="<?= $e($r['q']) ?>" title="What search predicts for these words now" aria-label="See predictions for &ldquo;<?= $e($r['q']) ?>&rdquo;"><?= tv_icon('sparkle', 'se-ii') ?></button><button type="button" class="se-ib" data-teach="<?= $e($r['q']) ?>" title="Teach search these words" aria-label="Teach search &ldquo;<?= $e($r['q']) ?>&rdquo;"><?= tv_icon('pen', 'se-ii') ?></button></td>
      <?php foreach (['picked' => 'Picked', 'searched' => 'Searched', 'left_pred' => 'Left, predictions showed', 'left_none' => 'Left, nothing to predict'] as $k => $label): $v = (int) $r[$k]; ?><td data-l="<?= $e($label) ?>" class="<?= $v === 0 ? 'z' : (in_array($k, ['left_pred', 'left_none'], true) && $v * 2 >= $all ? 'hot' : '') ?>"><?= $v ?></td><?php endforeach; ?></tr>
  <?php endforeach; ?></tbody></table></div>
  <?php endif; ?>
</details>
<details class="ms-card tv-bleed ms-fold"><summary><h2>What each column means</h2></summary>
  <div class="ms-key"><?php foreach (MISS_KINDS as [$label, $what]): ?><div><b><?= $e($label) ?>:</b> <?= $e($what) ?></div><?php endforeach; ?></div>
</details>
<?php endif; ?>
<style>
  /* Teach search and the situation editor (decisions/0061, batch 2) */
  .se-box{display:flex;align-items:center;gap:.4rem;background:#FFFBF2;border:1px solid #B88647;border-radius:.5rem;padding:.35rem .6rem}
  .se-box input{flex:1;min-width:0;border:0;background:transparent;font-size:16px;color:#3E2B1F;outline:none}
  .se-box input::-webkit-search-cancel-button{display:none}
  .se-i{width:18px;height:18px;color:#B45309;flex:0 0 auto}.se-ii{width:15px;height:15px}
  /* the term analysis (✦): how the 5 W's were read */
  .se-ai{margin-left:0}.se-ai[aria-expanded="true"]{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .se-an{margin:.6rem 0 .2rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:.65rem .75rem;font-size:.8rem;color:#3E2B1F}
  .se-an h3{font-size:.72rem;letter-spacing:.05em;text-transform:uppercase;color:#7A6348;margin:.7rem 0 .3rem}.se-an h3:first-child{margin-top:0}
  .se-words{display:flex;flex-wrap:wrap;gap:.3rem}.se-w{border-radius:.3rem;padding:.12rem .45rem;border:1px solid #CBB98D;background:#fff}
  .se-w small{display:block;font-size:.6rem;letter-spacing:.04em;text-transform:uppercase;color:#7A6348}
  .se-w.Why{background:#FDE7D3;border-color:#E9A66A}.se-w.What{background:#E5EFE9;border-color:#8FBCA8}.se-w.Where{background:#E7EEF7;border-color:#93ADCF}
  .se-w.When{background:#F3E8F5;border-color:#C29BCB}.se-w.Who{background:#FFF4CC;border-color:#D9B84A}.se-w.none{color:#9C8468;border-style:dashed}
  .se-five{display:grid;gap:.4rem;grid-template-columns:repeat(auto-fill,minmax(210px,1fr))}
  .se-5{border-left:3px solid #CBB98D;padding:.2rem .5rem;background:#F7EFDC;border-radius:.25rem}.se-5 b{display:block;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:#5C4632}
  .se-5.Why{border-color:#E9A66A}.se-5.What{border-color:#8FBCA8}.se-5.Where{border-color:#93ADCF}.se-5.When{border-color:#C29BCB}.se-5.Who{border-color:#D9B84A}
  .se-5 p{margin:.15rem 0 0;font-size:.8rem}.se-5 small{display:block;color:#7A6348;font-size:.72rem;margin-top:.1rem}.se-5 .none{color:#9C8468}
  .se-pred{margin:0 0 .4rem;padding-left:1.2rem}.se-pred li{margin:.2rem 0}.se-pred .wt{display:inline-block;min-width:4.6rem;font-size:.62rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#7A6348}.se-pred small{display:block;color:#7A6348;font-size:.72rem}
  .se-steps{margin:0;padding-left:1.2rem}.se-steps li{margin:.25rem 0}.se-steps .wt{display:inline-block;min-width:3.4rem;font-size:.62rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#7A6348}
  .se-steps small{display:block;color:#7A6348;font-size:.72rem}
  /* Meanings */
  .mn-forms{display:grid;gap:.6rem;grid-template-columns:repeat(auto-fit,minmax(260px,1fr))}
  .mn-f{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:.6rem .7rem;font-size:.82rem}
  .mn-two{display:grid;gap:0 .5rem;grid-template-columns:1fr 1fr}.mn-two input{width:100%}
  .mn-f h3,.mn-h{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:.95rem;margin:0 0 .3rem;color:#3E2B1F}.mn-h{margin:.8rem 0 .3rem}
  .mn-f label{display:block;font-size:.72rem;font-weight:600;color:#5C4632;margin:.45rem 0 .15rem}
  .mn-f input[type=text],.mn-f select{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.35rem .45rem;font-size:16px;background:#fff;color:#3E2B1F}
  .mn-f #mn-newc{margin-top:.3rem}.mn-f .se-btn{margin-top:.6rem}
  .mn-chk{display:flex!important;align-items:flex-start;gap:.35rem;font-weight:400!important;color:#3E2B1F!important}
  .mn-chk[hidden]{display:none!important}
  .mn-things{display:flex;flex-wrap:wrap;gap:.2rem .7rem;max-height:9rem;overflow:auto;border:1px solid #EADFC4;border-radius:.4rem;padding:.35rem .45rem;background:#fff}
  .mn-things label{display:inline-flex;align-items:center;gap:.25rem;margin:0;font-weight:400;color:#3E2B1F;font-size:.78rem}
  .mn-row{display:flex;align-items:center;gap:.5rem;padding:.35rem .1rem;border-top:1px solid #EADFC4;font-size:.8rem}.mn-row span{flex:1;min-width:0}
  .mn-row small{color:#7A6348}.mn-built{margin-top:.7rem;font-size:.78rem}.mn-built summary{cursor:pointer;color:#92400E;font-weight:600}
  .mn-built p{margin:.25rem 0}.mn-built b{color:#3E2B1F}
  .se-w.none{cursor:pointer}.se-w.little{color:#9C8468;border-style:dotted;background:transparent}
  .se-reads{font-size:.8rem;color:#5C4632;margin:.45rem 0 .3rem;min-height:1em}.se-reads b{color:#3E2B1F}.se-reads .miss{color:#9A3412;font-weight:600}
  .se-list{max-height:26rem;overflow:auto}
  .se-row{display:flex;align-items:center;gap:.5rem;padding:.4rem .2rem;border-top:1px solid #EADFC4}
  .se-row .se-t{flex:1;min-width:0}.se-row .se-t a{color:#92400E;text-decoration:underline;font-weight:600;font-size:.86rem;cursor:pointer}
  .se-row .se-t small{display:block;font-size:.72rem;color:#7A6348;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .se-tag{display:inline-block;font-size:.62rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;border-radius:999px;padding:0 .4rem;margin-left:.3rem;vertical-align:1px}
  .dr-kind{display:flex;flex-wrap:wrap;gap:.4rem .8rem;margin:.4rem 0}.dr-kind label{display:flex;flex-direction:column;font-size:.78rem;color:#5C4632;flex:1 1 12rem}
  .dr-kind input,.dr-kind select,.ct-row input{border:1px solid #D9C7A5;border-radius:.4rem;padding:.35rem .5rem;font:inherit;background:#fff;min-width:0;width:100%;box-sizing:border-box}
  .ct-row{display:flex;gap:.5rem;margin:.4rem 0}.ct-l{list-style:none;padding:0;margin:.3rem 0;display:flex;flex-wrap:wrap;gap:.35rem}.ct-l li{border:1px solid #E0C68E;background:#FFFBEB;border-radius:999px;padding:.15rem .3rem .15rem .7rem;font-size:.9rem}
  .se-tag.reads{background:#8FBCA8;color:#1F3B30}.se-tag.draft,.se-tag.retired{background:#EADFC4;color:#5C4632}.se-tag.danger{background:#FEE2E2;color:#7F1D1D}.se-tag.mine{background:#FFFBEB;color:#92400E;border:1px solid #E0C68E}
  .se-ib{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;flex:0 0 30px;border-radius:999px;border:1px solid #B88647;background:#FCFAEE;color:#B45309;cursor:pointer;vertical-align:middle;margin-left:.2rem}
  .se-ib:hover,.se-ib:focus-visible{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.35);outline:0}
  .se-new{display:flex;align-items:center;gap:.5rem;width:100%;border:0;border-top:1px solid #EADFC4;background:none;padding:.5rem .2rem;font:inherit;font-size:.86rem;color:#92400E;font-weight:600;cursor:pointer;text-align:left}
  .se-toast{position:fixed;left:50%;bottom:1.2rem;transform:translateX(-50%);background:#3E2B1F;color:#FFFBF2;font-size:.85rem;padding:.55rem .9rem;border-radius:.5rem;z-index:90;max-width:92vw}
  .se-modal{position:fixed;inset:0;z-index:80;background:rgba(40,28,20,.45);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:2rem 1rem}
  .se-modal[hidden]{display:none}
  .se-sec{border-top:1px solid #EADFC4;margin-top:.6rem}.se-sec>summary{list-style:none;cursor:pointer;display:flex;flex-wrap:wrap;align-items:center;gap:.1rem .6rem;padding:.55rem 0 .2rem}
  .se-sec>summary::-webkit-details-marker{display:none}.se-sec>summary{position:relative;padding-right:1.4rem}.se-sec>summary::after{content:'▸';position:absolute;right:.2rem;top:.6rem;color:#B45309}.se-sec[open]>summary::after{content:'▾'}
  .se-sec>summary .se-step{border:0;margin:0;padding:0}.se-ssum{font-size:.74rem;color:#7A6348;flex-basis:100%;padding-left:1.9rem}.se-sec[open] .se-ssum{display:none}
  #lx-modal{z-index:95}.se-step{display:flex;align-items:center;gap:.4rem;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:.98rem;margin:1rem 0 .2rem;color:#3E2B1F;border-top:1px solid #EADFC4;padding-top:.6rem}
  .se-step span{display:inline-flex;width:1.35rem;height:1.35rem;border-radius:999px;background:#3E2B1F;color:#FFFBF2;align-items:center;justify-content:center;font-size:.72rem;font-family:system-ui,sans-serif}
  .se-frow{display:flex;align-items:center;gap:.4rem;background:#E5EFE9;border:1px solid #8FBCA8;border-radius:.4rem;padding:.25rem .5rem;margin:.25rem 0;font-size:.84rem}.se-frow .se-ib{margin-left:auto}
  .se-fadd{background:#FCFAEE;border:1px dashed #CBB98D;border-radius:.45rem;padding:.4rem .55rem;margin:.35rem 0}
  .se-tl{list-style:none;padding:0;margin:.25rem 0}.se-tl li{padding:.3rem .45rem;border-radius:.35rem;margin:.2rem 0;font-size:.82rem;background:#FFFBF2;border:1px solid #EADFC4}
  .se-tl li.ok{background:#E5EFE9;border-color:#8FBCA8}.se-tl li.no{background:#FDE2D3;border-color:#E9A66A}.se-tu{display:flex;flex-wrap:wrap;gap:.3rem;align-items:center;margin-top:.25rem;font-size:.78rem}
  #se-tests h4{font-size:.78rem;text-transform:uppercase;letter-spacing:.05em;color:#7A6348;margin:.6rem 0 .1rem}
  .lx-dlg{max-width:34rem}.lx-tabs{display:flex;gap:.3rem;border-bottom:1px solid #EADFC4;margin-bottom:.4rem}
  .ca-pick{display:flex;flex-direction:column;gap:.2rem;font-size:.8rem}.ca-l{font-weight:600;color:#5C4632}
  .ca-d{position:relative}.ca-d summary{cursor:pointer;border:1px solid #CBB98D;border-radius:.5rem;padding:.45rem .6rem;background:#FFFBF2;font-size:.9rem;list-style:none}
  .ca-d summary::-webkit-details-marker{display:none}.ca-d summary::after{content:' ▾';color:#B45309}
  .ca-box{position:absolute;z-index:30;left:0;right:0;top:calc(100% + 3px);background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;box-shadow:0 10px 24px rgba(42,27,18,.18);padding:.4rem .6rem;display:grid;gap:.2rem;max-height:16rem;overflow:auto}
  .ca-box label{display:flex;gap:.4rem;align-items:center;font-size:.88rem;font-weight:400}.ca-box label[hidden]{display:none}
  .dr-kind .ca-pick{flex:1 1 12rem}
  .ct-also{margin:.6rem 0;display:grid;gap:.3rem;max-width:28rem}
  .lx-tabs button{border:0;background:none;padding:.35rem .7rem;font:inherit;font-size:.82rem;font-weight:600;color:#7A6348;cursor:pointer;border-bottom:2px solid transparent}
  .lx-tabs button.on{color:#3E2B1F;border-bottom-color:#8FBCA8}.lx-pane select,.lx-pane input[type=text]{width:100%;box-sizing:border-box;font-size:16px}
  .lx-pane ol{margin:.2rem 0 .4rem;padding-left:1.2rem}.lx-pane li.used b{color:#1F5137}
  .se-w.lx{font:inherit;font-size:.82rem;cursor:pointer;text-align:left;color:#3E2B1F}.se-w.lx small+small{text-transform:none;letter-spacing:0}
  .se-w.lx:hover{box-shadow:0 0 0 3px rgba(143,188,168,.45)}.se-w.unk{background:#FDE2D3;border:1px dashed #C2410C}.se-w.How{background:#EFE7DA;border-color:#B88647}
  .wb-rec{padding:.45rem .6rem;border-radius:.4rem;margin:0 0 .5rem;font-size:.84rem;display:flex;flex-wrap:wrap;gap:.35rem;align-items:center}
  .wb-rec small{flex-basis:100%;color:#7A6348;font-size:.72rem}.wb-rec.ok{background:#E5EFE9;color:#1F5137}.wb-rec.no{background:#FDE2D3;color:#9A3412}
  .se-w.lx.sel{box-shadow:0 0 0 3px #8FBCA8}.wb-sel{font-size:.8rem;color:#5C4632;margin:.45rem 0 0;display:flex;flex-wrap:wrap;gap:.35rem;align-items:center}
  .se-5.sel{box-shadow:0 0 0 3px rgba(143,188,168,.55)}.se-5.editing{grid-column:1/-1}.se-5>b{display:flex;align-items:center;gap:.35rem}
  .wb-wedit{margin-left:auto;width:26px;height:26px;border-radius:999px;border:1px solid #B88647;background:#FCFAEE;color:#B45309;cursor:pointer;padding:0;font-size:.85rem;line-height:1}
  .wb-wedit:hover{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8}.wb-wed{margin-top:.4rem;padding-top:.4rem;border-top:1px solid #EADFC4;font-size:.82rem}
  .wb-wed label{display:block;font-size:.72rem;font-weight:600;color:#5C4632;margin:.4rem 0 .15rem}.wb-wed .mn-chk{display:flex;gap:.35rem;font-weight:400;font-size:.8rem;margin:.15rem 0}
  .wb-wed select,.wb-wed input[type=text]{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.35rem .5rem;font:inherit;font-size:16px;background:#fff}
  .wb-wh{font-weight:700;margin:0 0 .2rem;color:#3E2B1F}.wb-wacts{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.55rem}.wb-wres p{margin:.45rem 0 .2rem}
  .wb-chg li{font-size:.78rem}.se-5 .wb-wed b,.se-5 .wb-wed .wb-wh{text-transform:none;letter-spacing:0;font-size:inherit;display:inline}.se-5 .wb-wed .wb-wh{display:block}
  .se-5 .wb-wed .wb-l{margin:.2rem 0 0}.se-5 .wb-wed .wb-k{text-transform:none}
  .wb-rmw{position:relative;padding-right:2rem}.wb-rm{position:absolute;right:0;top:.15rem;width:24px;height:24px;border-radius:999px;border:1px solid #CBB98D;background:#FCFAEE;color:#8A7355;cursor:pointer;padding:0;line-height:1}
  .wb-rm:hover{background:#8FBCA8;color:#1F3B30;border-color:#8FBCA8}
  .se-dlg{background:#FFFBF2;border:1px solid #B88647;border-radius:.6rem;width:100%;max-width:46rem;padding:1rem 1.1rem;color:#3E2B1F;font-size:.85rem}
  .se-dlg h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.15rem;margin:0 0 .6rem;display:flex;justify-content:space-between;align-items:center}
  .se-dlg label{display:block;font-size:.75rem;font-weight:600;color:#5C4632;margin:.55rem 0 .2rem}
  .se-dlg input[type=text],.se-dlg textarea,.se-dlg select{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.4rem;padding:.4rem .5rem;font:inherit;font-size:16px;background:#fff;color:#3E2B1F}
  .se-dlg textarea{min-height:6.5rem}.se-hint{font-size:.72rem;color:#8A7355;margin:.15rem 0 0}
  .se-grid{display:grid;gap:.2rem .8rem;grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
  .se-checks{display:flex;flex-wrap:wrap;gap:.3rem .9rem;font-size:.8rem}.se-checks label{display:inline-flex;align-items:center;gap:.3rem;margin:0;font-weight:400;color:#3E2B1F}
  .se-need{border:1px solid #CBB98D;border-radius:.5rem;padding:.55rem .65rem;margin:.6rem 0;background:#F7EFDC}
  .se-need-h{display:flex;gap:.4rem;align-items:center}.se-need-h input{flex:1}
  .se-chips{display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.3rem}.se-chip{display:inline-flex;align-items:center;gap:.25rem;background:#3E2B1F;color:#FFFBF2;border-radius:999px;padding:.1rem .55rem;font-size:.75rem}
  .se-chip button{background:none;border:0;color:#E0C68E;cursor:pointer;font-size:.9rem;padding:0}
  .se-catin{position:relative}.se-catl{position:absolute;left:0;right:0;top:100%;background:#fff;border:1px solid #CBB98D;border-radius:.4rem;z-index:5;max-height:14rem;overflow:auto}
  .se-catl button{display:block;width:100%;text-align:left;border:0;background:none;padding:.35rem .5rem;font:inherit;font-size:.8rem;cursor:pointer}.se-catl button:hover{background:#F3E3CB}
  .se-acts{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.9rem;align-items:center}
  .se-btn{display:inline-flex;align-items:center;gap:.35rem;border:1px solid #B88647;background:#FCFAEE;color:#3E2B1F;border-radius:.5rem;padding:.45rem .9rem;font:inherit;font-weight:600;cursor:pointer}
  .se-btn.main{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.se-btn.lnk{border:0;background:none;color:#92400E;text-decoration:underline;padding:.45rem .3rem}
  .se-err{color:#9A3412;font-size:.8rem;margin:.5rem 0 0}
  .se-auto{background:#E5EFE9;border-radius:.5rem;padding:.6rem .7rem;margin:.4rem 0}.se-auto p{margin:0 0 .4rem;font-size:.84rem;color:#1F3B30}
  .se-auto ul{margin:.4rem 0;padding-left:1.1rem;font-size:.84rem;color:#1F3B30}.se-fhand>summary{cursor:pointer;font-size:.82rem;font-weight:600;color:#92400E;margin:.5rem 0}
  .se-fword{margin:.5rem 0;border:1px dashed #CBB98D;border-radius:.5rem;padding:.45rem .6rem;background:#FFFBF2}.se-fword summary{cursor:pointer;font-size:.82rem;font-weight:600;color:#92400E}
  .se-pv{margin-top:.8rem;border-top:1px solid #EADFC4;padding-top:.6rem}.se-pv h3{font-size:.8rem;margin:.5rem 0 .2rem;text-transform:uppercase;letter-spacing:.04em;color:#5C4632}
  .se-pv li{font-size:.8rem;margin:.1rem 0}.se-pv ul{margin:0;padding-left:1.1rem}
  @media (max-width:767px){.se-modal{padding:0;background:#FFFBF2}.se-dlg{min-height:100vh;border-radius:0;border:0}}
</style>
<div class="se-modal" id="lx-modal" hidden role="dialog" aria-modal="true" aria-labelledby="lx-title"><div class="se-dlg lx-dlg">
  <h2><span id="lx-title">Word</span><button type="button" class="se-ib" data-lxclose title="Close" aria-label="Close">&times;</button></h2>
  <p class="se-hint" id="lx-now" style="margin:0 0 .5rem"></p>
  <div class="lx-tabs" role="tablist"><button type="button" role="tab" data-lxtab="word" class="on" aria-selected="true">Word</button><button type="button" role="tab" data-lxtab="senses" aria-selected="false">Senses</button><button type="button" role="tab" data-lxtab="forms" aria-selected="false">Forms</button></div>
  <form class="lx-pane" id="lx-word" novalidate>
    <div class="mn-two"><div><label for="lx-pos">Category (part of speech)</label><select id="lx-pos"></select></div><div><label for="lx-kind">Job it does</label><select id="lx-kind"></select></div></div>
    <label for="lx-class">Meaning</label><select id="lx-class"></select>
    <input type="text" id="lx-newc" maxlength="30" placeholder="name the new meaning: compost, documents…" hidden aria-label="New meaning">
    <label class="mn-chk" id="lx-weakw"><input type="checkbox" id="lx-weak"> Only with a partner (a thing, a tool, or "got / was / by / my")</label>
    <p class="se-hint" id="lx-taught"></p>
    <button type="submit" class="se-btn main">Save this reading</button>
  </form>
  <form class="lx-pane" id="lx-senses" hidden novalidate>
    <div id="lx-slist"></div>
    <p class="se-hint" id="lx-sw-note" hidden>Senses are for single words.</p>
    <div class="mn-two"><div><label for="lx-sW">A new sense: it's a</label><select id="lx-sW"><option value="why">Why: what happened (a situation)</option><option value="when">When: a season</option><option value="where">Where: a place or feature</option><option value="what">What: a thing to find</option><option value="none">Nothing to search: a passing remark</option></select></div>
      <div><div id="lx-se-why"><label for="lx-ssit">It means</label><select id="lx-ssit"></select></div>
        <div id="lx-se-when" hidden><label for="lx-sseason">The season</label><select id="lx-sseason"><option value="fall">Fall</option><option value="spring">Spring</option><option value="summer">Summer</option><option value="winter">Winter</option></select></div>
        <div id="lx-se-as" hidden><label for="lx-sas">Read it as</label><input type="text" id="lx-sas" maxlength="60" placeholder="waterfall"></div></div></div>
    <div class="mn-two"><div><label for="lx-scues">When these are near (empty: always)</label><input type="text" id="lx-scues" maxlength="400" placeholder="before:@person, next:down"></div>
      <div><label for="lx-slabel">What it means here</label><input type="text" id="lx-slabel" maxlength="80" placeholder="An injury"></div></div>
    <button type="submit" class="se-btn main">Add sense</button>
  </form>
  <form class="lx-pane" id="lx-forms" hidden novalidate>
    <div id="lx-flist"></div>
    <label for="lx-fin">Other forms, comma separated (plural, past tense, spellings)</label><input type="text" id="lx-fin" maxlength="300" placeholder="composting, composted, composts">
    <p class="se-hint">They get the same job and meaning as set on the Word tab.</p>
    <button type="submit" class="se-btn main">Add forms</button>
  </form>
  <p class="se-err" id="lx-err" role="alert"></p>
</div></div>
<div class="se-modal" id="se-modal" hidden role="dialog" aria-modal="true" aria-labelledby="se-title"><form class="se-dlg" id="se-form" novalidate>
  <h2><span id="se-title">Situation</span><button type="button" class="se-ib" data-close title="Close" aria-label="Close">&times;</button></h2>
  <p class="se-hint" style="margin:0">Built frame-first (decisions/0063): what it is and what would help, then what triggers it, then example searches that prove it.</p>
  <details class="se-sec" id="se-sec1"><summary><h3 class="se-step"><span>1</span>What it is</h3><small class="se-ssum" id="se-sum1"></small></summary>
  <label for="se-label">Name people see</label><input type="text" id="se-label" maxlength="120" placeholder="e.g. Composting">
  <div class="se-grid">
    <div><label for="se-status">Status</label><select id="se-status"><option value="live">Live: search answers it</option><option value="draft">Draft: not used yet</option><option value="retired">Retired: no longer used</option></select></div>
    <div><label for="se-track">Mostly for</label><select id="se-track"><option value="resident">Residents (Get Local)</option><option value="traveler">Travelers (Let's Explore)</option><option value="community">Community</option><option value="mixed">A mix</option></select></div>
  </div>
  <div class="se-checks" style="margin-top:.6rem"><label><input type="checkbox" id="se-urgent"> Urgent: Call and open-now first</label>
    <label><input type="checkbox" id="se-danger"> Danger: show "If anyone is in danger, call 911" (Admin only)</label></div>
  <label>What would help (each need is one group of answers)</label>
  <div id="se-needs"></div>
  <button type="button" class="se-btn" data-addneed><?= tv_icon('plus', 'se-ii') ?> Add a need</button>
  </details>
  <details class="se-sec" id="se-sec2"><summary><h3 class="se-step"><span>2</span>What triggers it</h3><small class="se-ssum" id="se-sum2"></small></summary>
  <p class="se-hint">A rule is <b>what happened, or what they want done</b> + <b>what it's about</b>. "Found" + "wallet" catches "found a wallet", "I found someone's wallet", "wallet found by the road": every way of saying it, with no list of phrases. Pick the first part, tick the second, then <b>Add this rule</b>. Add more than one rule if people say it more than one way ("found" + wallet or purse).</p>
  <div class="se-auto"><p><b>The easy way:</b> write how people would search for it in step 3 (one per line), then</p>
    <button type="button" class="se-btn main" data-autorules><?= tv_icon('sparkle', 'se-ii') ?> Build the rule from my example searches</button>
    <div id="se-autoout" aria-live="polite"></div></div>
  <div id="se-frames"></div>
  <details class="se-fhand"><summary>Or build a rule by hand</summary>
  <div class="se-fadd"><label for="se-flead">When the event or action is</label><select id="se-flead"></select>
    <label>with any of these things or tools</label><div class="mn-things" id="se-fthings"></div>
    <button type="button" class="se-btn" data-addframe><?= tv_icon('plus', 'se-ii') ?> Add this rule</button></div>
  <details class="se-fword" id="se-fword"><summary>A word you need isn't in the lists? Add it here</summary>
    <div class="se-grid">
      <div><label for="se-fw">The word, as people type it</label><input type="text" id="se-fw" maxlength="60" placeholder="found"></div>
      <div><label for="se-fwk">It is</label><select id="se-fwk"><option value="event">what happened (an event: lost, found, broke)</option><option value="action">what they want done (an action: fix, install)</option><option value="thing">what it's about (a thing: wallet, pipe)</option><option value="tool">a tool (generator, saw)</option></select></div>
    </div>
    <label for="se-fwc">It means the same as</label><select id="se-fwc"></select>
    <input type="text" id="se-fwn" maxlength="30" placeholder="name the new meaning: found" aria-label="New meaning">
    <p class="se-hint">Pick a word it means the same as, and it gets that word's rules too ("purse" → wallet). Or keep "Its own meaning" for something new.</p>
    <button type="button" class="se-btn" data-fwadd><?= tv_icon('plus', 'se-ii') ?> Add the word</button>
  </details>
  </details>
  <p class="se-hint" id="se-fbuiltin"></p>
  </details>
  <details class="se-sec" id="se-sec3"><summary><h3 class="se-step"><span>3</span>Example searches: the tests</h3><small class="se-ssum" id="se-sum3"></small></summary>
  <label for="se-examples">How people would say it, one per line. They prove the rules work; they don't trigger anything themselves.</label>
  <textarea id="se-examples" placeholder="how to compost&#10;start a compost pile&#10;composting bins"></textarea>
  <button type="button" class="se-btn" data-sittest><?= tv_icon('search', 'se-ii') ?> Test them, and recent searches</button>
  <div id="se-tests" aria-live="polite"></div>
  </details>
  <details class="se-sec" id="se-sec4"><summary><h3 class="se-step"><span>4</span>Fixed phrases: only for idioms</h3><small class="se-ssum" id="se-sum4"></small></summary>
  <label for="se-phrases">Sayings that can't be built from their parts ("fender bender", "tow truck"), one per line</label><textarea id="se-phrases" placeholder="fender bender"></textarea>
  <p class="se-hint">Capitals, apostrophes and plurals don't matter. A phrase may have up to two other words in between when searched. Most situations need none once their rules work.</p>
  </details>
  <label for="se-note">Note for the team (optional)</label><input type="text" id="se-note" maxlength="300">
  <p class="se-hint" id="se-mine"></p>
  <p class="se-err" id="se-err" role="alert"></p>
  <p class="se-hint">A situation works everywhere: what would help is found near wherever the person searching is. The place below only picks where to <b>preview</b> it.</p>
  <div class="se-acts"><button type="button" class="se-btn" data-preview><?= tv_icon('eye', 'se-ii') ?> Preview</button>
    <select id="se-pvplace" aria-label="Preview as if searching from" style="width:auto;max-width:14rem"><option value="">Where I am</option><?php foreach ($areaList as $sl => $nm): ?><option value="<?= $e($sl) ?>"><?= $e($nm) ?></option><?php endforeach; ?></select></div>
  <div class="se-acts"><button type="submit" class="se-btn" value="draft">Save draft</button>
    <button type="submit" class="se-btn main" value="live">Publish</button>
    <button type="button" class="se-btn" data-reset title="Put it back as it was last saved">Reset</button>
    <button type="button" class="se-btn lnk" data-close>Cancel</button></div>
  <div class="se-pv" id="se-pv" hidden></div>
</form></div>
<script>
(function () {
  var csrf = <?= json_encode($csrf) ?>, IC = <?= json_encode(['plus' => tv_icon('plus', 'se-ii'), 'pen' => tv_icon('pen', 'se-ii'), 'x' => '&times;']) ?>;
  var TR = { resident: 'Get Local', traveler: "Let's Explore", community: 'Community', mixed: 'A mix' };
  var KINDS = [['listing', 'Businesses'], ['outdoors', 'Outdoor places'], ['story', 'Stories'], ['group', 'Groups'], ['experience', 'Experiences']];
  var REQ = [['phone', 'a phone'], ['hours', 'hours'], ['where', 'a place']];
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  function scopeQS() { try { var l = typeof currentLocation !== 'undefined' && currentLocation && currentLocation.scope; return l && l.slug ? '&level=' + encodeURIComponent(l.level) + '&slug=' + encodeURIComponent(l.slug) : ''; } catch (x) { return ''; } }
  function toast(m) { var t = document.createElement('div'); t.className = 'se-toast'; t.textContent = m; document.body.appendChild(t); setTimeout(function () { t.remove(); }, 3200); }
  function post(data) {
    var f = new FormData(); f.append('csrf', csrf); Object.keys(data).forEach(function (k) { f.append(k, data[k]); });
    // the server's errors are {code, message}: the message is what's shown
    return fetch(location.pathname, { method: 'POST', body: f, credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { if (d && d.error && typeof d.error === 'object') d.error = d.error.message || 'That didn\u2019t work.'; return d; });
  }
  // ---- the Search workbench (Jason, 2026-10-03): type, and see what a visitor sees, each word's W and senses, and the
  // situations; every part has the button that opens the right form, already filled in ----
  var q = $('se-q'), seq = 0, timer, LAST = null, SEL = null, SELN = 1;
  // the selection: one word, or a run of words joined into a phrase ("first thing tomorrow")
  function selTok() {
    if (!LAST || SEL === null || !LAST.lexicon[SEL]) return null;
    if (SELN <= 1) return LAST.lexicon[SEL];
    return { word: LAST.lexicon.slice(SEL, SEL + SELN).map(function (y) { return y.word; }).join(' '), pos: '', kind: '', class: '', w: '', known: false, little: false, phrase: true };
  }
  var POSL = <?= json_encode(Lexicon::POS) ?>, KL = <?= json_encode(Lexicon::KIND_LABEL) ?>;
  function sitRows(list, w) {
    return (list || []).map(function (s) {
      var tags = (s.reads ? '<span class="se-tag reads">reads as</span>' : '') + (s.status !== 'live' ? '<span class="se-tag ' + s.status + '">' + s.status + '</span>' : '')
        + (s.danger ? '<span class="se-tag danger">911</span>' : '') + (s.source === 'admin' ? '<span class="se-tag mine">edited</span>' : '');
      return '<div class="se-row"><div class="se-t"><a data-edit="' + s.id + '">' + esc(s.label) + '</a>' + tags
        + '<small>' + esc(s.phrases.join(' · ')) + (s.count > s.phrases.length ? ' · +' + (s.count - s.phrases.length) + ' more' : '') + (s.needs.length ? ' — ' + esc(s.needs.join(', ')) : '') + '</small></div>'
        + (w.length >= 2 && !s.reads ? '<button type="button" class="se-ib" data-add="' + s.id + '" title="Add “' + esc(w) + '” to ' + esc(s.label) + '" aria-label="Add “' + esc(w) + '” to ' + esc(s.label) + '">' + IC.plus + '</button>' : '')
        + '<button type="button" class="se-ib" data-edit="' + s.id + '" title="Edit ' + esc(s.label) + '" aria-label="Edit ' + esc(s.label) + '">' + IC.pen + '</button></div>';
    }).join('');
  }
  // every situation, A to Z, only when asked ("Browse all situations")
  function browseList() {
    var w = q.value.trim(), my = ++seq;
    fetch(location.pathname + '?json=find&q=' + scopeQS(), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (my !== seq) return;
      $('se-reads').innerHTML = '<span class="se-box" style="display:flex;margin:.4rem 0 .3rem"><input id="se-filt" type="search" autocomplete="off" placeholder="Find a situation by name" aria-label="Find a situation by name"></span>';
      $('se-list').innerHTML = sitRows(d.list, w) + '<button type="button" class="se-new" data-new>' + IC.plus + (w.length >= 2 ? 'New situation for “' + esc(w) + '”' : 'New situation') + '</button>';
    }).catch(function () { $('se-reads').textContent = 'Couldn’t load the situations. Reload the page.'; });
  }
  function find() { if (!$('se-browse').hidden) browseList(); analyze(); }
  q.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(analyze, 300); });
  var aseq = 0, WN = { why: 'Why', when: 'When', where: 'Where', what: 'What', none: 'Set aside' };
  function analyze() {
    var w = q.value.trim(), box = $('se-an'), my = ++aseq;
    box.hidden = false;
    if (w.length < 2) { box.innerHTML = '<p class="se-hint" style="margin:0">Start typing: it reads as you go.</p>'; return; }
    fetch(location.pathname + '?json=analyze&q=' + encodeURIComponent(w) + scopeQS(), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (my !== aseq) return;
      if (!LAST || LAST.q !== d.q) SEL = null;
      paint(d);
    }).catch(function () { box.innerHTML = '<p class="se-err">Couldn’t read it. Reload the page.</p>'; });
  }
  // the analysis, drawn (again when a word is selected, without asking the server)
  function paint(d) {
    var w = q.value.trim(), box = $('se-an');
      if (!d.ok) { box.innerHTML = '<p class="se-err">' + esc(d.error || 'Couldn’t read it.') + '</p>'; return; }
      var KN = { situation: 'Situation', tool: 'Tool', group: 'Group', category: 'Kind', tag: 'Kind', place: 'Town', listing: 'Listing', outdoors: 'Outdoors', story: 'Story', experience: 'Experience' };
      var T = d.typing, A = d.after, L = function (k, t, sm) { return '<li><span class="wb-k">' + esc(k) + '</span> ' + t + (sm ? '<small>' + esc(sm) + '</small>' : '') + '</li>'; };
      // a suggestion that doesn't fit is removed, never edited (decisions/0063 §3): × blocks it for these words
      var Lr = function (k, t, sm, shown, kind) { return '<li class="wb-rmw"><span class="wb-k">' + esc(k) + '</span> ' + t + (sm ? '<small>' + esc(sm) + '</small>' : '') + '<button type="button" class="wb-rm" data-wbrm="' + esc(shown) + '" data-kind="' + kind + '" title="Doesn\u2019t fit: remove it for these words" aria-label="Remove ' + esc(shown) + '">&times;</button></li>'; };
      LAST = d;
      // 0. recognized or not, first (decisions/0063 §2)
      var LX = d.lexicon || [], unk = [];
      LX.forEach(function (x, i) { if (!x.known && !x.little) unk.push(i); });
      var rec = unk.length
        ? '<div class="wb-rec no"><b>Not recognized:</b> ' + unk.map(function (i) { return '\u201C' + esc(LX[i].word) + '\u201D'; }).join(', ') + '. ' + unk.map(function (i) { return '<button type="button" class="wb-btn" data-lxopen="' + i + '">Add \u201C' + esc(LX[i].word) + '\u201D</button>'; }).join(' ') + '<small>Visitors see \u201CWe don\u2019t recognize\u2026\u201D with Suggest it; staff see Add it.</small></div>'
        : (d.result.unread ? '<div class="wb-rec no"><b>Words recognized, the phrase isn\u2019t:</b> each word is known, but together they don\u2019t name anything yet. <button type="button" class="wb-btn" data-new>New situation for it</button></div>'
          : '<div class="wb-rec ok"><b>\u2713 Recognized</b>' + (A.situation.length ? ': reads as ' + esc(A.situation.join(' + ')) : '') + '</div>');
      // 1. what a visitor sees
      var v = rec + '<h3>While typing</h3><ul class="wb-l">';
      (T.dym || []).forEach(function (x) { v += Lr('Did you mean', '<b>' + esc(x.q) + '</b>', x.situation || '', x.q, 'dym'); });
      T.complete.forEach(function (c) { v += Lr('Completes', esc(c), '', c, 'pred'); });
      if (T.preview) v += L('Answer', '<b>' + esc(T.preview.labels.join(' + ')) + '</b>', T.preview.needs.map(function (n) { return n.label + ' (' + n.n + ')'; }).join(' · '));
      T.rows.forEach(function (r) { v += L(KN[r.kind] || r.kind, esc(r.label), r.crumb); });
      if (!(T.dym || []).length && !T.complete.length && !T.preview && !T.rows.length) v += '<li>Only “Search for …”: nothing to predict yet.</li>';
      v += '</ul><h3>After Enter</h3><ul class="wb-l">';
      (A.dym || []).forEach(function (x, i) { v += Lr(i ? 'or' : 'Did you mean', '<b>' + esc(x.q) + '</b>', (x.situation ? x.situation + ' · ' : '') + 'keeps ' + Math.round(x.score * 100) + '% of what was typed', x.q, 'dym'); });
      if (A.situation.length) { v += L('Situation', '<b>' + esc(A.situation.join(' + ')) + '</b>'); A.needs.forEach(function (n) { v += L('Need', esc(n.label) + ' · ' + n.n, n.first.join(', ')); }); }
      else if (d.result.unread) v += L('Result', '<b>Can’t tell what’s wanted.</b> Nothing searched.');
      else { A.items.forEach(function (x) { v += L(KN[x.kind] || 'Result', esc(x.label), x.sub); }); if (!A.items.length) v += L('Result', 'Nothing found here' + (A.elsewhere.length ? '; nearest: ' + esc(A.elsewhere.join(', ')) : '')); }
      if (A.when) v += L('When', esc(A.when));
      A.kinds.forEach(function (k) { v += L('Kind', esc(k), 'All of this kind'); });
      (d.near || []).forEach(function (n) { v += L('Maybe', esc(n), 'Offered as “Maybe you mean”'); });
      (A.learned || []).forEach(function (x) { v += Lr(x.status === 'live' ? 'Most opened' : 'May help', esc(x.label), 'Learned · ' + x.score, x.label, 'learned'); });
      v += '</ul>';
      if ((d.removed || []).length) v += '<h3>Removed for these words</h3><ul class="wb-l">' + d.removed.map(function (x) {
        return '<li><span class="wb-k">' + esc(x.kind === 'dym' ? 'Did you mean' : (x.kind === 'learned' ? 'May help' : 'Prediction')) + '</span> <s>' + esc(x.shown) + '</s><small>' + (+x.blocked ? 'removed by staff' : '') + (+x.removed_n ? (+x.blocked ? ' · ' : '') + x.removed_n + ' visitor' + (+x.removed_n === 1 ? '' : 's') + ' removed it' : '') + '</small>'
          + (+x.blocked ? '<button type="button" class="wb-btn" data-wbrestore="' + x.id + '">Undo</button>' : '') + '</li>'; }).join('') + '</ul>';
      // 2. each word: its W, and every sense of a word that has some
      // each word: its lexical category, the job it does and its W; tap one to edit it, its senses or its forms
      var WC = { why: 'Why', what: 'What', where: 'Where', when: 'When', who: 'Who', how: 'How' };
      if (SEL === null || !LX[SEL] || (LX[SEL].little && SELN <= 1)) { SEL = null; SELN = 1; LX.forEach(function (x, i) { if (SEL === null && !x.little) SEL = i; }); }
      if (SEL !== null && SEL + SELN > LX.length) SELN = LX.length - SEL;
      var words = LX.map(function (x, i) {
        var cls = x.little ? 'little' : (!x.known ? 'unk' : (WC[x.w] || 'none'));
        var pos = x.pos ? (POSL[x.pos] || x.pos) + (x.pos_from === 'guessed' ? '?' : '') : '?';
        var job = x.little ? 'little word' : (x.kind ? (KL[x.kind] || x.kind) + (x.w ? ' \u2192 ' + (WC[x.w] || x.w) : '') : 'not recognized');
        return '<button type="button" class="se-w lx ' + cls + (SEL !== null && i >= SEL && i < SEL + SELN ? ' sel' : '') + '" data-lx="' + i + '" aria-pressed="' + (SEL !== null && i >= SEL && i < SEL + SELN ? 'true' : 'false') + '" title="' + esc(x.why || 'Select it, then correct its W below') + '">' + esc(x.word) + '<small>' + esc(pos) + '</small><small>' + esc(job) + '</small></button>';
      }).join('');
      var r2 = '<h3>Each word <small class="se-hint">select one: its W lights up below, ✎ corrects it</small></h3><div class="se-words">' + words + '</div>';
      (d.senses || []).forEach(function (sn) {
        r2 += '<div class="wb-sense"><b>“' + esc(sn.word) + '”</b> ' + (sn.none_fits ? 'no sense fits here, so it’s read as a plain word. It could mean:' : 'has more than one meaning. Here it reads as the one in bold:')
          + '<ol>' + sn.senses.map(function (x) { return '<li class="' + (x.used ? 'used' : '') + '"><span class="wb-w">' + esc(WN[x.w] || x.w) + '</span>' + esc(x.label) + (x.taught ? ' (taught)' : '') + '<small>' + esc(x.when) + '</small></li>'; }).join('') + '</ol>'
          + '<div class="wb-acts"><button type="button" class="wb-btn" data-tsense="' + esc(sn.base) + '" data-forms="' + esc(sn.forms.join(', ')) + '">Teach “' + esc(sn.base) + '” another sense</button></div></div>';
      });
      // the selected word: its W lights up; ✎ on any W corrects that W for it (decisions/0063 §4)
      var sx = selTok(), sW = sx ? (WC[sx.w] || '') : '';
      if (sx) r2 += '<div class="wb-sel">Selected: <b>\u201C' + esc(sx.word) + '\u201D</b> \u00b7 ' + (sx.phrase ? 'a phrase' : esc(POSL[sx.pos] || sx.pos || 'category not set') + ' \u00b7 ' + esc(sx.kind ? (KL[sx.kind] || sx.kind) + (sx.w ? ' \u2192 ' + (WC[sx.w] || sx.w) : '') : 'not recognized'))
        + (SEL > 0 ? ' <button type="button" class="wb-btn" data-selext="-1" title="Join the word before">\uFF0B word before</button>' : '')
        + (SEL + SELN < LX.length ? ' <button type="button" class="wb-btn" data-selext="1" title="Join the word after">word after \uFF0B</button>' : '')
        + (SELN > 1 ? ' <button type="button" class="wb-btn" data-selext="0">One word</button>' : ' <button type="button" class="wb-btn" data-lxopen="' + SEL + '">Word, senses &amp; forms</button>') + '</div>';
      r2 += '<h3>The 5 W\u2019s</h3><div class="se-five">' + ['Why', 'What', 'Where', 'When', 'Who'].map(function (W) {
        var l = d.five[W] || [];
        return '<div class="se-5 ' + W + (W === sW ? ' sel' : '') + '" data-wcard="' + W + '"><b>' + W + (W === 'Why' ? ' (intent)' : '')
          + (sx ? '<button type="button" class="wb-wedit" data-wedit="' + W + '" title="Correct the ' + W + ' for \u201C' + esc(sx.word) + '\u201D" aria-label="Correct the ' + W + ' for ' + esc(sx.word) + '">\u270E</button>' : '') + '</b>'
          + (l.length ? l.map(function (x) { return '<p>' + esc(x.what) + (x.because ? '<small>' + esc(x.because) + '</small>' : '') + '</p>'; }).join('') : '<p class="none">Nothing said</p>')
          + '<div class="wb-wed" hidden></div></div>';
      }).join('') + '</div>';
      if ((d.edits || []).length) r2 += '<details class="mn-built"><summary>Recent corrections</summary><ul class="wb-l">' + d.edits.map(function (x) {
        return '<li><span class="wb-k">' + esc(x.w) + '</span> ' + (x.undone_at ? '<s>' + esc(x.summary) + '</s><small>undone</small>' : esc(x.summary) + '<small>' + (+x.made_by === 0 ? 'learned on its own \u00b7 ' : '') + esc(x.created_at.slice(0, 16)) + ' \u00b7 changed ' + x.changed_n + ' recent search' + (+x.changed_n === 1 ? '' : 'es') + '</small><button type="button" class="wb-btn" data-eundo="' + x.id + '">Undo</button>') + '</li>'; }).join('') + '</ul></details>';
      // 3. the situations: those that read it first, then those whose name or phrases share its words
      var sits = (d.situations || []).slice().sort(function (a, b) { return (b.reads ? 1 : 0) - (a.reads ? 1 : 0); }).slice(0, 8);
      var r3 = '<h3>Situations</h3>' + (sits.length ? '<div class="se-list" style="max-height:none">' + sitRows(sits, w) + '</div>'
        : '<p class="se-reads">No situation uses these words. Add them to one (Browse all situations, then ＋), or start a new one.</p>')
        + '<button type="button" class="se-new" data-new>' + IC.plus + 'New situation for “' + esc(w) + '”</button>';
      box.innerHTML = '<div class="wb"><div><h3 style="margin-top:.2rem">What a visitor sees</h3>' + v + '</div><div>' + r2 + r3 + '</div></div>'
        + '<details class="mn-built"><summary>Step by step</summary><ol class="se-steps">' + d.steps.map(function (x) { return '<li><span class="wt">' + esc(x.w) + '</span> ' + esc(x.what) + (x.because ? '<small>' + esc(x.because) + '</small>' : '') + '</li>'; }).join('') + '</ol>'
        + '<p class="se-hint">The search’s own rule-based reading, the same steps a visitor’s search takes (no AI).</p></details>';
  }
  document.addEventListener('input', function (e) {   // narrowing the full list by name, without changing the words to add
    if (e.target.id !== 'se-filt') return;
    var f = e.target.value.trim().toLowerCase();
    [].forEach.call($('se-list').querySelectorAll('.se-row'), function (r) { r.hidden = f !== '' && r.textContent.toLowerCase().indexOf(f) < 0; });
  });
  // ---- the editor ----
  var cur = null;
  function needHtml(n, i) {
    // from the server these are text ("listing,outdoors"); read back from the form they're lists: take either
    var list = function (v, sep, dflt) { return Array.isArray(v) ? v : String(v == null || v === '' ? dflt : v).split(sep).filter(Boolean); };
    var cats = list(n.cats, '|', ''), kinds = list(n.kinds, ',', 'listing'), req = list(n.requires, ',', '');
    return '<div class="se-need" data-i="' + i + '"><div class="se-need-h"><input type="text" data-f="label" value="' + esc(n.label || '') + '" placeholder="e.g. Turn it in to the police" aria-label="Need name">'
      + '<button type="button" class="se-ib" data-up title="Move up" aria-label="Move up">&uarr;</button><button type="button" class="se-ib" data-rm title="Remove this need" aria-label="Remove this need">&times;</button></div>'
      + '<div class="se-grid"><div><label>Shown under</label><select data-f="track">' + Object.keys(TR).filter(function (k) { return k !== 'mixed'; }).map(function (k) { return '<option value="' + k + '"' + (n.track === k ? ' selected' : '') + '>' + esc(TR[k]) + '</option>'; }).join('') + '</select></div>'
      + '<div><label>Words (outdoor places, stories, groups)</label><input type="text" data-f="words" value="' + esc(n.words || '') + '" placeholder="e.g. trailhead (empty for businesses)"></div></div>'
      + '<label>Business categories that answer it</label><div class="se-chips">' + cats.map(function (c) { return '<span class="se-chip" data-cat="' + esc(c) + '">' + esc(c) + '<button type="button" data-uncat aria-label="Remove ' + esc(c) + '">&times;</button></span>'; }).join('') + '</div>'
      + '<div class="se-catin"><input type="text" data-catq placeholder="Type to add one, e.g. Police" aria-label="Add a category"><div class="se-catl" hidden></div></div>'
      + '<label>Finds</label><div class="se-checks">' + KINDS.map(function (k) { return '<label><input type="checkbox" data-kind="' + k[0] + '"' + (kinds.indexOf(k[0]) >= 0 ? ' checked' : '') + '> ' + k[1] + '</label>'; }).join('') + '</div>'
      + '<label>An answer must have</label><div class="se-checks">' + REQ.map(function (k) { return '<label><input type="checkbox" data-req="' + k[0] + '"' + (req.indexOf(k[0]) >= 0 ? ' checked' : '') + '> ' + k[1] + '</label>'; }).join('') + '</div></div>';
  }
  function readNeeds() {
    return [].map.call($('se-needs').querySelectorAll('.se-need'), function (b) {
      var g = function (f) { var x = b.querySelector('[data-f="' + f + '"]'); return x ? x.value : ''; };
      return { label: g('label'), track: g('track'), words: g('words'),
        cats: [].map.call(b.querySelectorAll('[data-cat]'), function (c) { return c.getAttribute('data-cat'); }).join('|'),
        kinds: [].filter.call(b.querySelectorAll('[data-kind]'), function (c) { return c.checked; }).map(function (c) { return c.getAttribute('data-kind'); }),
        requires: [].filter.call(b.querySelectorAll('[data-req]'), function (c) { return c.checked; }).map(function (c) { return c.getAttribute('data-req'); }) };
    });
  }
  function drawNeeds(list) { $('se-needs').innerHTML = list.map(needHtml).join(''); }
  // what each closed step holds, in a line
  function secSums() {
    var nd = readNeeds().filter(function (n) { return (n.label || '').trim(); });
    var ex = $('se-examples').value.split('\n').filter(function (x) { return x.trim(); }).length, ph = $('se-phrases').value.split('\n').filter(function (x) { return x.trim(); }).length;
    $('se-sum1').textContent = ($('se-label').value.trim() || 'No name yet') + ' · ' + ($('se-status').options[$('se-status').selectedIndex] || {}).text.split(':')[0] + ' · ' + (nd.length ? nd.length + ' need' + (nd.length === 1 ? '' : 's') + ': ' + nd.map(function (n) { return n.label; }).join(', ') : 'no needs yet');
    $('se-sum2').textContent = FR.length ? FR.map(function (f) { return f.lead + (f.things.length ? ' + ' + f.things.join(' or ') : ''); }).join(' · ') : 'No rules yet';
    $('se-sum3').textContent = ex ? ex + ' example search' + (ex === 1 ? '' : 'es') : 'No examples yet';
    $('se-sum4').textContent = ph ? ph + ' phrase' + (ph === 1 ? '' : 's') : 'None (most situations need none)';
  }
  document.addEventListener('toggle', function (e) { if (e.target.classList && e.target.classList.contains('se-sec')) secSums(); }, true);
  function form() {
    return { id: cur ? cur.id : 0, label: $('se-label').value, phrases: $('se-phrases').value, status: $('se-status').value, track: $('se-track').value,
      urgency: $('se-urgent').checked ? 'urgent' : 'normal', danger: $('se-danger').checked, note: $('se-note').value, needs: readNeeds(),
      frames: FR, examples: $('se-examples').value };
  }
  // ---- the frame (decisions/0063 §6): the rules that lead to this situation ----
  var FR = [];
  function drawFrames() {
    $('se-frames').innerHTML = FR.length ? FR.map(function (f, i) { return '<div class="se-frow"><b>' + esc(f.lead) + '</b>' + (f.things.length ? ' + ' + esc(f.things.join(' or ')) : ' <small>(alone)</small>') + ' <button type="button" class="se-ib" data-unframe="' + i + '" title="Remove this rule" aria-label="Remove this rule">&times;</button></div>'; }).join('')
      : '<p class="se-hint" style="margin:.2rem 0">No rules yet. Add one below, or test example searches to have one suggested.</p>';
  }
  function frameInputs() {
    if (!MN) { setTimeout(frameInputs, 300); return; }
    var C = MN.classes, o = function (c) { return '<option value="' + esc(c) + '">' + esc(c) + '</option>'; };
    $('se-flead').innerHTML = '<optgroup label="Actions (how it\u2019s done)">' + C.action.map(o).join('') + '</optgroup><optgroup label="Events (what happened)">' + C.event.map(o).join('') + '</optgroup>';
    $('se-fthings').innerHTML = C.thing.map(function (c) { return '<label><input type="checkbox" value="' + esc(c) + '"> ' + esc(c) + '</label>'; }).join('') + C.tool.map(function (c) { return '<label><input type="checkbox" value="' + esc(c) + '"> ' + esc(c) + ' <small>(tool)</small></label>'; }).join('');
  }
  function addFrame(f) {
    var k = f.lead + '|' + f.things.join(',');
    if (!FR.some(function (x) { return x.lead + '|' + x.things.join(',') === k; })) FR.push({ lead: f.lead, things: f.things, why: f.why || '' });
    drawFrames(); $('se-tests').innerHTML = '';
  }
  function sitTest() {
    var box = $('se-tests'), f = JSON.stringify(form());
    box.innerHTML = '<p class="se-hint">Testing\u2026</p>';
    Promise.all([post({ do: 'sit_test', form: f, with: '' }), post({ do: 'sit_test', form: f, with: 1 })]).then(function (r) {
      var a = r[0], b = r[1];
      if (!a.ok || !b.ok) { box.innerHTML = '<p class="se-err">' + esc((a.ok ? b : a).error || 'Couldn\u2019t test it.') + '</p>'; return; }
      var lab = function (l) { return l && l.length ? l.map(function (x) { return x.label; }).join(' + ') : 'nothing'; };
      var mine = function (l) { return (l || []).filter(function (x) { return x.slug === b.slug; })[0]; };
      var pass = 0, h = '<h4>Tests</h4><ul class="se-tl">';
      b.examples.forEach(function (ex) {
        var m0 = mine(b.searches[ex]), unk = b.unknown[ex] || [], sg = b.suggest[ex];
        if (m0) pass++;
        h += '<li class="' + (m0 ? 'ok' : 'no') + '"><b>' + (m0 ? '\u2713' : '\u2717') + ' \u201C' + esc(ex) + '\u201D</b> '
          + (m0 ? 'reads as this, by ' + esc(m0.how) : 'reads as ' + esc(lab(b.searches[ex])))
          + (unk.length ? '<span class="se-tu">Not recognized: ' + unk.map(function (w) { return '<button type="button" class="wb-btn" data-lxword="' + esc(w) + '" data-lxq="' + esc(ex) + '">Add \u201C' + esc(w) + '\u201D</button>'; }).join(' ') + '</span>' : '')
          + (!m0 && sg ? '<span class="se-tu">Suggested rule: <b>' + esc(sg.lead) + (sg.things.length ? ' + ' + esc(sg.things.join(' or ')) : '') + '</b> <button type="button" class="wb-btn" data-usefr="' + esc(JSON.stringify(sg)) + '">Use this rule</button></span>' : '')
          + '</li>';
      });
      h += '</ul>' + (b.examples.length ? '<p class="se-hint">' + pass + ' of ' + b.examples.length + ' pass.' + (pass === b.examples.length ? ' Ready to set Live.' : ' Fix the ones that don\u2019t before setting it Live.') + '</p>' : '<p class="se-hint">Add example searches above to test the rules.</p>');
      var ch = [];
      Object.keys(b.searches).forEach(function (q0) { if (b.examples.indexOf(q0) >= 0) return; var x0 = lab(a.searches[q0]), y0 = lab(b.searches[q0]); if (x0 !== y0) ch.push('<li><b>\u201C' + esc(q0) + '\u201D</b> ' + esc(x0) + ' \u2192 ' + esc(y0) + '</li>'); });
      h += '<h4>Dry run: recent searches</h4>' + (ch.length ? '<p class="se-hint">' + ch.length + ' would read differently:</p><ul class="se-tl">' + ch.join('') + '</ul>' : '<p class="se-hint">None of the ' + (Object.keys(b.searches).length - b.examples.length) + ' most-searched recent searches would read differently.</p>');
      box.innerHTML = h;
    });
  }
  function openEditor(s, words) {
    cur = s || null;
    $('se-title').textContent = s ? 'Edit: ' + s.label : 'New situation';
    // a new one is named from the words being worked on ("found a wallet" → "Found a wallet"); change it freely
    $('se-label').value = s ? s.label : (words ? words.charAt(0).toUpperCase() + words.slice(1) : '');
    // frame-first: the words being worked on become an example (a test), not a phrase
    $('se-phrases').value = s ? s.phrases.map(function (p) { return p.phrase; }).join('\n') : '';
    $('se-examples').value = ((s && s.examples) ? s.examples + (words ? '\n' : '') : '') + (words || '');
    FR = s && s.frames ? s.frames.slice() : []; drawFrames(); frameInputs(); $('se-tests').innerHTML = '';
    $('se-fbuiltin').textContent = s && s.frames_builtin && s.frames_builtin.length ? 'Built in (in code): ' + s.frames_builtin.map(function (f) { return f.lead + (f.things.length ? ' + ' + f.things.join(' or ') : ''); }).join(' \u00b7 ') : '';
    $('se-status').value = s ? s.status : 'draft'; $('se-track').value = s ? s.track : 'resident';
    $('se-urgent').checked = !!(s && s.urgency === 'urgent'); $('se-danger').checked = !!(s && s.danger); $('se-note').value = s ? (s.note || '') : '';
    drawNeeds(s && s.needs.length ? s.needs : [{ label: '', track: 'resident', kinds: 'listing', requires: 'where' }]);
    $('se-mine').textContent = s && s.source === 'seed' ? 'This one came with Traversence. Saving makes it yours: later updates to it in code won’t change it.' : '';
    $('se-err').textContent = ''; $('se-pv').hidden = true;
    $('se-pvplace').value = ''; $('se-fword').open = false; $('se-fw').value = ''; fwMeanings();
    // new: step 1 open; editing: all closed, each with what's in it, so nothing needs scrolling past
    ['1', '2', '3', '4'].forEach(function (n) { $('se-sec' + n).open = !s && n === '1'; });
    secSums();
    $('se-modal').hidden = false; $('se-label').focus();
  }
  function edit(id, words) {
    fetch(location.pathname + '?json=get&id=' + id, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { if (d.ok) openEditor(d.situation, words); else toast(d.error || 'Couldn’t open it.'); });
  }
  function close() { $('se-modal').hidden = true; cur = null; }
  document.addEventListener('click', function (e) {
    var t;
    if ((t = e.target.closest('[data-browse]'))) { var bw = $('se-browse'), op = bw.hidden; bw.hidden = !op; t.setAttribute('aria-expanded', String(op)); t.textContent = op ? 'Hide the list' : 'Browse all situations'; if (op) browseList(); return; }
    // prefilled forms: open Meanings at the right form with the word in it
    if ((t = e.target.closest('[data-tsense]')) || (t = e.target.closest('[data-tword]'))) {
      var sense = t.hasAttribute('data-tsense'), wd = t.getAttribute(sense ? 'data-tsense' : 'data-tword');
      $('mn-card').open = true; var fd = $(sense ? 'mn-fd-sense' : 'mn-fd-word'); fd.open = true;
      if (sense) { $('mn-sw').value = wd; $('mn-sf').value = (t.getAttribute('data-forms') || '').split(', ').filter(function (f) { return f && f !== wd; }).join(', '); $('mn-scues').value = ''; $('mn-slabel').value = ''; }
      else $('mn-w').value = wd;
      fd.scrollIntoView({ behavior: 'smooth', block: 'start' }); setTimeout(function () { (sense ? $('mn-scues') : $('mn-kind')).focus(); }, 350);
      return;
    }
    if ((t = e.target.closest('[data-try]'))) { if (window.TvSearch && TvSearch.open) TvSearch.open(t.getAttribute('data-try')); return; }
    if ((t = e.target.closest('[data-predan]'))) {   // the words into Teach search, with ✦ Analyze open on them (the predictions are in it)
      q.value = t.getAttribute('data-predan'); analyze();
      $('se-teach').scrollIntoView({ behavior: 'smooth', block: 'start' }); return;
    }
    if ((t = e.target.closest('[data-teach]'))) { q.value = t.getAttribute('data-teach'); analyze(); $('se-teach').scrollIntoView({ behavior: 'smooth', block: 'start' }); q.focus(); return; }
    if ((t = e.target.closest('[data-add]'))) {
      var w = q.value.trim();
      post({ do: 'phrase', id: t.getAttribute('data-add'), q: w }).then(function (d) {
        if (!d.ok) { toast(d.error || 'Couldn’t add it.'); return; }
        toast(d.already ? '“' + w + '” was already a phrase of ' + d.label + '.' : 'Added “' + d.phrase + '” to ' + d.label + (d.also && d.also.length ? ' (also in ' + d.also.join(', ') + ')' : '') + '. Search answers it now.');
        find(); if (!$('se-an').hidden) analyze();
      });
      return;
    }
    if ((t = e.target.closest('[data-edit]'))) { edit(t.getAttribute('data-edit')); return; }
    if (e.target.closest('[data-new]')) { openEditor(null, q.value.trim()); return; }
    if (e.target.closest('[data-close]') || e.target === $('se-modal')) { close(); return; }
    if (e.target.closest('[data-addneed]')) { var l = readNeeds(); l.push({ label: '', track: 'resident', kinds: 'listing', requires: 'where' }); drawNeeds(l); return; }
    if ((t = e.target.closest('[data-rm]'))) { var l2 = readNeeds(); l2.splice(+t.closest('.se-need').getAttribute('data-i'), 1); drawNeeds(l2); return; }
    if ((t = e.target.closest('[data-up]'))) { var i = +t.closest('.se-need').getAttribute('data-i'), l3 = readNeeds(); if (i > 0) { var x = l3[i]; l3[i] = l3[i - 1]; l3[i - 1] = x; drawNeeds(l3); } return; }
    if ((t = e.target.closest('[data-uncat]'))) { t.closest('.se-chip').remove(); return; }
    if ((t = e.target.closest('[data-pickcat]'))) {
      var nb = t.closest('.se-need'), c = t.getAttribute('data-pickcat');
      if (![].some.call(nb.querySelectorAll('[data-cat]'), function (x) { return x.getAttribute('data-cat') === c; }))
        nb.querySelector('.se-chips').insertAdjacentHTML('beforeend', '<span class="se-chip" data-cat="' + esc(c) + '">' + esc(c) + '<button type="button" data-uncat aria-label="Remove ' + esc(c) + '">&times;</button></span>');
      var ci = nb.querySelector('[data-catq]'); ci.value = ''; t.parentNode.hidden = true; ci.focus(); return;
    }
    if (e.target.closest('[data-preview]')) {
      // "Where I am": the place the page is set to; otherwise the first area, only as an example
      var pvs = $('se-pvplace').value, pvm = scopeQS().match(/level=([^&]+)&slug=([^&]+)/);
      var pvl = pvs ? 'cluster' : (pvm ? decodeURIComponent(pvm[1]) : 'cluster');
      if (!pvs) pvs = pvm ? decodeURIComponent(pvm[2]) : ($('se-pvplace').options[1] ? $('se-pvplace').options[1].value : '');
      post({ do: 'preview', form: JSON.stringify(form()), level: pvl, slug: pvs }).then(function (d) {
        var pv = $('se-pv'); pv.hidden = false;
        if (!d.ok) { pv.innerHTML = '<p class="se-err">' + esc(d.error || 'Couldn’t preview it.') + '</p>'; return; }
        var a = d.answer;
        pv.innerHTML = (d.problems.length ? '<p class="se-err">' + esc(d.problems.join(' ')) + '</p>' : '')
          + '<p><b>' + esc(a.labels[0] || 'This situation') + '</b>' + (a.place ? ' near ' + esc(a.place) : '') + (a.danger ? ' · shows the 911 line' : '') + '</p>'
          + a.needs.map(function (n) { return '<h3>' + esc(n.label || 'A need') + '</h3>' + (n.items.length ? '<ul>' + n.items.map(function (it) { return '<li>' + esc(it.label) + ' <span style="color:#8A7355">' + esc([it.sub, it.miles != null ? it.miles + ' mi' : ''].filter(Boolean).join(' · ')) + '</span></li>'; }).join('') + '</ul>' : '<p class="se-hint">Nothing found for this yet.</p>')
            + (n.incomplete ? '<p class="se-hint">' + n.incomplete + ' more matched but are missing ' + esc(n.requires.split(',').join(' or ')) + '.</p>' : ''); }).join('');
      });
    }
  });
  // categories as typed
  var ct;
  document.addEventListener('input', function (e) {
    var ci = e.target.closest('[data-catq]'); if (!ci) return;
    clearTimeout(ct); var list = ci.nextElementSibling, w = ci.value.trim();
    if (w.length < 2) { list.hidden = true; return; }
    ct = setTimeout(function () {
      fetch(location.pathname + '?json=cats&q=' + encodeURIComponent(w), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        var c = (d.cats || []);
        list.innerHTML = c.map(function (n) { return '<button type="button" data-pickcat="' + esc(n) + '">' + esc(n) + '</button>'; }).join('') + '<button type="button" data-pickcat="' + esc(w) + '%"><i>Every category starting “' + esc(w) + '”</i></button>';
        list.hidden = false;
      });
    }, 200);
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('se-modal').hidden) close(); });
  // ---- Meanings: teach words and rules for the meaning layer ----
  var MN = null;
  function mnLoad() {
    fetch(location.pathname + '?json=meanings', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) { $('mn-taught').innerHTML = '<p class="se-err">' + esc(d.error || 'Couldn\u2019t load the meanings.') + '</p>'; return; }
      MN = d; mnClasses();
      var opt = function (c) { return '<option value="' + esc(c) + '">' + esc(c) + '</option>'; };
      $('mn-ev').innerHTML = '<optgroup label="Events (what happened)">' + d.classes.event.map(opt).join('') + '</optgroup><optgroup label="Actions (how it\u2019s done)">' + (d.classes.action || []).map(opt).join('') + '</optgroup>';
      var box = function (c, k) { return '<label><input type="checkbox" value="' + esc(c) + '"> ' + esc(c) + (k ? ' <small>(' + k + ')</small>' : '') + '</label>'; };
      $('mn-things').innerHTML = d.classes.thing.map(function (c) { return box(c, ''); }).join('') + (d.classes.tool || []).map(function (c) { return box(c, 'tool'); }).join('');
      $('mn-sit').innerHTML = d.situations.map(function (x) { return '<option value="' + esc(x.slug) + '">' + esc(x.label) + '</option>'; }).join('');
      var h = d.words.map(function (w) { return '<div class="mn-row"><span><b>' + esc(w.word) + '</b> <small>' + esc(w.kind) + ': ' + esc(w.class) + (+w.weak ? ' (needs a thing or a cue)' : '') + '</small></span><button type="button" class="se-ib" data-mndel="' + w.id + '" title="Remove" aria-label="Remove ' + esc(w.word) + '">&times;</button></div>'; }).join('')
        + d.frames.map(function (f) { return '<div class="mn-row"><span><b>' + esc(f.event) + (f.things ? ' + ' + esc(f.things.split(',').join(' or ')) : '') + '</b> \u2192 ' + esc(f.label) + (f.why ? ' <small>(' + esc(f.why) + ')</small>' : '') + '</span><button type="button" class="se-ib" data-frdel="' + f.id + '" title="Remove" aria-label="Remove this rule">&times;</button></div>'; }).join('');
      var WN = { why: 'Why', when: 'When', where: 'Where', what: 'What', none: 'Set aside' };
      h += (d.senses || []).map(function (x) { return '<div class="mn-row"><span><b>' + esc(x.word) + '</b> \u2192 ' + esc(WN[x.w] || x.w) + ': ' + esc(x.label) + ' <small>when near: ' + esc(x.cues || 'always') + ' \u00b7 ' + esc(x.effect) + '</small></span><button type="button" class="se-ib" data-sedel="' + x.id + '" title="Remove" aria-label="Remove this sense">&times;</button></div>'; }).join('');
      $('mn-taught').innerHTML = h || '<p class="se-hint">Nothing taught yet. The built-in meanings are below.</p>';
      $('mn-ssit').innerHTML = $('mn-sit').innerHTML;
      $('mn-sgroups').innerHTML = (d.groups || []).map(function (g) { return '<code>@' + esc(g) + '</code>'; }).join(' ');
      var sb = d.senses_builtin || {};
      $('mn-sbuiltin').innerHTML = Object.keys(sb).map(function (w) { return '<p><b>' + esc(w) + '</b> <small>(' + esc(sb[w][0].forms) + ')</small></p>' + sb[w].map(function (x, i) { return '<p style="margin-left:.8rem">' + (i + 1) + '. ' + esc(WN[x.w] || x.w) + ': ' + esc(x.label) + ' <small>when near: ' + esc(x.cues) + '</small></p>'; }).join(''); }).join('')
        + (d.senses_ready ? '' : '<p class="se-err">Run app/migrations/2026-10-24_word_senses.sql to teach senses.</p>');
      var b = d.builtin;
      var KT = { event: 'Events (what happened \u2192 Why)', thing: 'Things (what it happened to \u2192 What)', action: 'Actions (how it\u2019s done \u2192 who does it)', tool: 'Tools (narrow What)', time: 'Time (\u2192 When)' };
      $('mn-builtin').innerHTML = Object.keys(KT).map(function (k) { return '<p><i>' + KT[k] + '</i></p>' + Object.keys(b[k] || {}).map(function (c) { return '<p><b>' + esc(c) + ':</b> ' + esc(b[k][c].join(', ')) + '\u2026</p>'; }).join(''); }).join('');
    });
  }
  function mnClasses() {
    if (!MN) return;
    var k = $('mn-kind').value;
    var TL = MN.time_classes || {};
    $('mn-class').innerHTML = (MN.classes[k] || []).map(function (c) { return '<option value="' + esc(c) + '">' + esc(c) + (k === 'time' && TL[c] ? ' \u2192 ' + esc(TL[c][1]) : '') + '</option>'; }).join('')
      + (k === 'time' ? '' : '<option value="__new">A new meaning\u2026</option>');
    $('mn-newc').hidden = true; $('mn-weakw').hidden = !(k === 'event' || k === 'action');
    $('mn-weakt').textContent = k === 'action' ? 'Only with a thing or a tool (a word with other uses, like "make" or "set up")' : 'Only with a thing or "got / was / by / my" (a word with other uses, like "cut")';
  }
  $('mn-kind').addEventListener('change', mnClasses);
  $('mn-class').addEventListener('change', function () { $('mn-newc').hidden = this.value !== '__new'; if (this.value === '__new') $('mn-newc').focus(); });
  $('mn-word').addEventListener('submit', function (e) {
    e.preventDefault(); $('mn-err').textContent = '';
    var c = $('mn-class').value === '__new' ? $('mn-newc').value.trim().toLowerCase().replace(/\s+/g, '-') : $('mn-class').value;
    post({ do: 'meaning_add', kind: $('mn-kind').value, class: c, word: $('mn-w').value, weak: $('mn-weak').checked ? 1 : '' }).then(function (d) {
      if (!d.ok) { $('mn-err').textContent = d.error || 'Couldn\u2019t add it.'; return; }
      toast('Taught \u201C' + $('mn-w').value.trim() + '\u201D as ' + c + (d.new_class ? ' (a new meaning: add a rule for it next)' : '') + '.');
      $('mn-w').value = ''; $('mn-newc').value = ''; mnLoad(); if (!$('se-an').hidden) analyze();
    });
  });
  function mnSenseW() { var w = $('mn-sW').value; $('mn-se-why').hidden = w !== 'why'; $('mn-se-when').hidden = w !== 'when'; $('mn-se-as').hidden = !(w === 'where' || w === 'what'); }
  $('mn-sW').addEventListener('change', mnSenseW);
  $('mn-sense').addEventListener('submit', function (e) {
    e.preventDefault(); $('mn-err').textContent = '';
    post({ do: 'sense_add', word: $('mn-sw').value, forms: $('mn-sf').value, w: $('mn-sW').value, slug: $('mn-ssit').value, season: $('mn-sseason').value, as: $('mn-sas').value,
           cues: $('mn-scues').value, label: $('mn-slabel').value, why: $('mn-swhy').value }).then(function (d) {
      if (!d.ok) { $('mn-err').textContent = d.error || 'Couldn\u2019t add it.'; return; }
      toast('Sense added for \u201C' + $('mn-sw').value.trim() + '\u201D. Search reads it now.');
      ['mn-scues', 'mn-slabel', 'mn-swhy', 'mn-sas'].forEach(function (k) { $(k).value = ''; });
      mnLoad(); if (!$('se-an').hidden) analyze();
    });
  });
  $('mn-rule').addEventListener('submit', function (e) {
    e.preventDefault(); $('mn-err').textContent = '';
    var th = [].filter.call($('mn-things').querySelectorAll('input'), function (x) { return x.checked; }).map(function (x) { return x.value; });
    post({ do: 'frame_add', event: $('mn-ev').value, things: th.join(','), slug: $('mn-sit').value, why: $('mn-why').value }).then(function (d) {
      if (!d.ok) { $('mn-err').textContent = d.error || 'Couldn\u2019t add it.'; return; }
      toast('Rule added. Search reads it now.'); $('mn-why').value = '';
      [].forEach.call($('mn-things').querySelectorAll('input'), function (x) { x.checked = false; });
      mnLoad(); find(); if (!$('se-an').hidden) analyze();
    });
  });
  document.addEventListener('click', function (e) {
    var t;
    if ((t = e.target.closest('[data-mndel]'))) { post({ do: 'meaning_del', id: t.getAttribute('data-mndel') }).then(function () { mnLoad(); if (!$('se-an').hidden) analyze(); }); return; }
    if ((t = e.target.closest('[data-sedel]'))) { post({ do: 'sense_del', id: t.getAttribute('data-sedel') }).then(function () { mnLoad(); if (!$('se-an').hidden) analyze(); }); return; }
    if ((t = e.target.closest('[data-frdel]'))) { post({ do: 'frame_del', id: t.getAttribute('data-frdel') }).then(function () { mnLoad(); find(); if (!$('se-an').hidden) analyze(); }); return; }
    if ((t = e.target.closest('[data-lxopen]'))) { openLx(+t.getAttribute('data-lxopen')); return; }
    if ((t = e.target.closest('[data-addframe]'))) {
      var th = [].map.call($('se-fthings').querySelectorAll('input:checked'), function (x) { return x.value; });
      addFrame({ lead: $('se-flead').value, things: th }); [].forEach.call($('se-fthings').querySelectorAll('input:checked'), function (x) { x.checked = false; }); return;
    }
    if ((t = e.target.closest('[data-unframe]'))) { FR.splice(+t.getAttribute('data-unframe'), 1); drawFrames(); $('se-tests').innerHTML = ''; return; }
    if ((t = e.target.closest('[data-usefr]'))) { addFrame(JSON.parse(t.getAttribute('data-usefr'))); toast('Rule added. Test again to see it work.'); return; }
    if ((t = e.target.closest('[data-sittest]'))) { sitTest(); return; }
    if ((t = e.target.closest('[data-lxword]'))) {   // a word an example uses that search doesn't know: teach it here, then test again
      var ww = t.getAttribute('data-lxword'); q.value = t.getAttribute('data-lxq'); analyze();
      var tries = 0; (function wait() { var i = (LAST && LAST.q === q.value.trim() && LAST.lexicon || []).findIndex(function (y) { return y.word === ww; }); if (i >= 0 && MN) openLx(i); else if (++tries < 40) setTimeout(wait, 200); })();
      return;
    }
    if ((t = e.target.closest('[data-lx]'))) { SEL = +t.getAttribute('data-lx'); SELN = 1; paint(LAST); return; }
    if ((t = e.target.closest('[data-selext]'))) { var dx = +t.getAttribute('data-selext'); if (dx < 0) { SEL--; SELN++; } else if (dx > 0) SELN++; else SELN = 1; paint(LAST); return; }
    if ((t = e.target.closest('[data-wedit]'))) { wOpen(t.closest('[data-wcard]')); return; }
    if ((t = e.target.closest('[data-wcancel]'))) { var c0 = t.closest('[data-wcard]'); c0.classList.remove('editing'); c0.querySelector('.wb-wed').hidden = true; return; }
    if ((t = e.target.closest('[data-wdry]'))) { wDry(t.closest('[data-wcard]')); return; }
    if ((t = e.target.closest('[data-wsave]'))) { wSave(t.closest('[data-wcard]')); return; }
    if ((t = e.target.closest('[data-eundo]'))) { post({ do: 'edit_undo', id: t.getAttribute('data-eundo') }).then(function (d) { toast(d.ok ? d.note : (d.error || 'Couldn\u2019t undo it.')); mnLoad(); analyze(); }); return; }
    if ((t = e.target.closest('[data-wbrm]'))) {
      post({ do: 'sugg_block', q: q.value.trim(), shown: t.getAttribute('data-wbrm'), kind: t.getAttribute('data-kind') }).then(function (d) {
        if (!d.ok) { toast(d.error || 'Couldn\u2019t remove it.'); return; }
        toast('Removed for \u201C' + q.value.trim() + '\u201D. Undo is under \u201CRemoved for these words\u201D.'); analyze();
      }); return;
    }
    if ((t = e.target.closest('[data-wbrestore]'))) { post({ do: 'sugg_restore', id: t.getAttribute('data-wbrestore') }).then(function () { toast('Back as it was.'); analyze(); }); return; }
    if ((t = e.target.closest('.se-w.none'))) {   // a word search didn't use: teach it
      $('mn-card').open = true; $('mn-fd-word').open = true;
      $('mn-w').value = t.firstChild.textContent.trim(); $('mn-fd-word').scrollIntoView({ behavior: 'smooth', block: 'start' }); $('mn-w').focus();
    }
  });
  mnLoad();
  // ---- drafts (decisions/0063 §7): approve with one tap, open in the workbench, or dismiss ----
  var DR = [];
  function drDraw(d) {
    if (!d.ok) { $('dr-list').innerHTML = '<p class="se-hint">' + esc(d.error || 'Couldn\u2019t load the drafts.') + '</p>'; return; }
    DR = d.drafts || [];
    var TL = { word: 'Word', category: 'Category', rule: 'Rule', kind: 'New kind' }, TOPS = d.tops || [];
    $('dr-list').innerHTML = DR.length ? '<ul class="wb-l dr-l">' + DR.map(function (x, i) {
      var start = x.type === 'rule' && !(x.change && x.change.slug);
      // a missing kind: its name, where it belongs and its words, editable before it's added (decisions/0067)
      var kf = x.type === 'kind' && x.change ? '<span class="dr-kind"><label>Name <input data-kname value="' + esc(x.change.name || '') + '"></label>'
        + '<label>Under <select data-kparent><option value="">(a main kind of its own)</option>' + TOPS.map(function (t) { return '<option' + (t === x.change.parent ? ' selected' : '') + '>' + esc(t) + '</option>'; }).join('') + '</select></label>'
        + alsoPick(TOPS, [], x.change.parent)
        + '<label>Words people search <input data-kterms value="' + esc((x.change.terms || []).join(', ')) + '"></label></span>' : '';
      return '<li><span class="wb-k">' + esc(TL[x.type] || x.type) + '</span><b>' + esc(x.proposal) + '</b><small>' + esc(x.evidence) + '</small>' + kf
        + (x.examples.length ? '<small class="dr-ex">' + x.examples.map(function (e) { return '\u201C' + esc(e) + '\u201D'; }).join(' \u00b7 ') + '</small>' : '')
        + '<span class="dr-b">' + (start ? '<button type="button" class="wb-btn" data-drstart="' + i + '">Start a situation</button>' : '<button type="button" class="wb-btn dr-ok" data-drok="' + x.id + '">Approve</button>')
        + '<button type="button" class="wb-btn" data-dropen="' + i + '">Open in workbench</button><button type="button" class="wb-btn" data-drno="' + x.id + '">Dismiss</button></span></li>';
    }).join('') + '</ul>' : '<p class="se-hint">No drafts waiting. New ones come from the nightly run, or tap Refresh.</p>';
    var sm = document.querySelector('#drafts .ms-sum'); if (sm) sm.textContent = DR.length ? DR.length + ' word' + (DR.length === 1 ? '' : 's') + ' and rules to approve' : 'Words and rules proposed from missed searches';
  }
  // "Also show under" (decisions/0082): the other main groups a kind is listed under when browsing; its home stays one
  function alsoPick(tops, on, home) {
    return '<span class="ca-pick"><span class="ca-l">Also show under</span><details class="ca-d"><summary data-casum>' + (on.length ? esc(on.join(', ')) : 'No other group') + '</summary><span class="ca-box">'
      + tops.map(function (t) { return '<label' + (t === home ? ' hidden' : '') + '><input type="checkbox" data-ca value="' + esc(t) + '"' + (on.indexOf(t) >= 0 ? ' checked' : '') + '> ' + esc(t) + '</label>'; }).join('') + '</span></details></span>';
  }
  function alsoOf(root) { return [].map.call(root.querySelectorAll('[data-ca]:checked'), function (c) { return c.value; }).filter(function (v, i, a) { var h = root.querySelector('[data-kparent]'); return !h || v !== h.value; }).join('|'); }
  document.addEventListener('change', function (e) {
    var c = e.target.closest('[data-ca]'); if (!c) return;
    var d = c.closest('.ca-pick'), on = [].map.call(d.querySelectorAll('[data-ca]:checked'), function (x) { return x.value; });
    d.querySelector('[data-casum]').textContent = on.length ? on.join(', ') : 'No other group';
    var hp = e.target.closest('li') && e.target.closest('li').querySelector('[data-kparent]');
    if (c.closest('#ct-also')) ctCall('also_set', '', on.join('|'));
  });
  document.addEventListener('change', function (e) {   // a new home group can't also be an "also"
    var s = e.target.closest('[data-kparent]'); if (!s) return;
    s.closest('li').querySelectorAll('[data-ca]').forEach(function (c) { var l = c.closest('label'); l.hidden = c.value === s.value; if (l.hidden) c.checked = false; });
  });
  function drLoad(what, id, more) { var b = { do: what || 'drafts', id: id || 0 }; Object.keys(more || {}).forEach(function (k) { b[k] = more[k]; }); return post(b).then(function (d) { drDraw(d); if (d.ok && d.note) toast(d.note); else if (!d.ok && what) toast(d.error || 'That didn\u2019t work.'); return d; }); }
  drLoad();
  // ---- words for each kind (category_terms) ----
  function ctDraw(d) {
    if (!d.ok) { $('ct-list').innerHTML = '<p class="se-hint">' + esc(d.error || 'Pick a kind of place from the list.') + '</p>'; return; }
    $('ct-list').innerHTML = d.terms.length ? '<ul class="ct-l">' + d.terms.map(function (t) { return '<li>' + esc(t.term) + (t.source === 'draft' ? ' <small>from a draft</small>' : '') + ' <button type="button" class="se-ib" data-ctdel="' + esc(t.term) + '" title="Remove" aria-label="Remove ' + esc(t.term) + '">&times;</button></li>'; }).join('') + '</ul>'
      : '<p class="se-hint">No words added for ' + esc(d.category) + ' yet.</p>';
    $('ct-list').insertAdjacentHTML('beforeend', '<div id="ct-also" class="ct-also"><span class="se-hint">' + esc(d.category) + ' lives in <b>' + esc(d.home || 'its own main group') + '</b>.</span> '
      + (d.also_ready ? alsoPick(d.tops || [], d.also || [], d.home) : '<span class="se-hint">To show it under other groups too, run app/migrations/2026-11-19_category_also.sql.</span>') + '</div>');
  }
  function ctCall(what, term, also) { return post({ do: what, category: $('ct-cat').value, term: term || '', also: also || '' }).then(function (d) { ctDraw(d); if (what === 'also_set' && d.ok) toast('Saved: ' + (d.also.length ? 'also shown under ' + d.also.join(', ') : 'only in ' + d.home) + '.'); }); }
  var ctLast = '';   // reload only when the kind itself changed (leaving the field also fires change)
  $('ct-cat').addEventListener('change', function () { var v = this.value.trim(); if (v && v !== ctLast) { ctLast = v; ctCall('terms_get'); } });
  $('ct-add').addEventListener('submit', function (e) { e.preventDefault(); var v = $('ct-term').value.trim(); if (!v) return; ctCall('term_add', v).then(function () { $('ct-term').value = ''; }); });
  document.addEventListener('click', function (e) { var t = e.target.closest('[data-ctdel]'); if (t) ctCall('term_del', t.getAttribute('data-ctdel')); });
  document.addEventListener('click', function (e) {
    var t;
    if ((t = e.target.closest('[data-drrefresh]'))) { t.disabled = true; drLoad('drafts_refresh').then(function () { t.disabled = false; }); return; }
    if ((t = e.target.closest('[data-drok]'))) { var li0 = t.closest('li'), kn = li0 && li0.querySelector('[data-kname]'), ov = kn ? { name: kn.value, parent: li0.querySelector('[data-kparent]').value, terms: li0.querySelector('[data-kterms]').value, also: alsoOf(li0) } : {};
      t.disabled = true; drLoad('draft_approve', t.getAttribute('data-drok'), ov).then(function (d) { if (d.ok) { mnLoad(); if (q.value.trim()) analyze(); } else t.disabled = false; }); return; }
    if ((t = e.target.closest('[data-drno]'))) { drLoad('draft_dismiss', t.getAttribute('data-drno')); return; }
    if ((t = e.target.closest('[data-dropen]'))) {   // the searches behind it, read in the workbench, where every W can be changed
      var x = DR[+t.getAttribute('data-dropen')]; if (!x) return;
      q.value = x.examples[0] || (x.change && x.change.word) || ''; analyze();
      $('se-teach').scrollIntoView({ behavior: 'smooth', block: 'start' }); return;
    }
    if ((t = e.target.closest('[data-drstart]'))) {   // a rule with no situation yet: the builder, with its examples and the rule
      var y = DR[+t.getAttribute('data-drstart')]; if (!y) return;
      openEditor(null, y.examples.join('\n'));
      addFrame({ lead: y.change.lead, things: y.change.things || [] });
    }
  });
  // ---- correcting one W for the selected word (decisions/0063 §4): a guided form, a dry run, then save ----
  function opts(list, sel) { return list.map(function (o) { var v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o; return '<option value="' + esc(v) + '"' + (v === sel ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join(''); }
  function radios(list, sel) { return '<div class="wb-wt">' + list.map(function (o) { return '<label class="mn-chk"><input type="radio" name="wt" value="' + o[0] + '"' + (o[0] === sel ? ' checked' : '') + '> ' + esc(o[1]) + '</label>'; }).join('') + '</div>'; }
  function wForm(W, x) {
    var sits = (MN.situations || []).map(function (y) { return [y.slug, y.label]; }), one = x.word.indexOf(' ') < 0, C = MN.classes;
    if (W === 'Why') {
      var lead = (x.kind === 'event' || x.kind === 'action') ? x.class : '', thing = (x.kind === 'thing' || x.kind === 'tool') ? x.class : '';
      var def = !one || lead || thing ? 'rule' : 'situation';
      return radios([['situation', 'It names a situation by itself'], ['rule', 'With other words: a rule (event or action + thing or tool)']].filter(function (o) { return one || o[0] === 'rule'; }), def)
        + '<div data-wt="situation"' + (def === 'situation' ? '' : ' hidden') + '><label>It means</label><select data-f="slug">' + opts(sits) + '</select><label>Only when these are near (optional)</label><input type="text" data-f="cues" placeholder="next:down, before:@person"></div>'
        + '<div data-wt="rule"' + (def === 'rule' ? '' : ' hidden') + '><label>When the event or action is</label><select data-f="lead"><optgroup label="Events">' + opts(C.event, lead) + '</optgroup><optgroup label="Actions">' + opts(C.action, lead) + '</optgroup></select>'
        + '<label>with any of these things or tools (none: alone)</label><div class="mn-things">' + C.thing.concat(C.tool).map(function (c) { return '<label><input type="checkbox" data-thing value="' + esc(c) + '"' + (c === thing ? ' checked' : '') + '> ' + esc(c) + '</label>'; }).join('') + '</div>'
        + '<label>it means</label><select data-f="slug2">' + opts(sits) + '</select></div>';
    }
    if (W === 'What') {
      var k0 = ['thing', 'tool', 'modifier'].indexOf(x.kind) >= 0 ? x.kind : 'thing';
      return radios([['category', 'An everyday word for a category'], ['kind', 'A thing, a tool or a modifier']], one ? 'category' : 'kind')
        + '<div data-wt="category"' + (one ? '' : ' hidden') + '><label>The category</label><input type="text" data-f="category" data-catlook list="wb-catl" placeholder="Type: Bars, Plumbers\u2026" autocomplete="off"><datalist id="wb-catl"></datalist></div>'
        + '<div data-wt="kind"' + (one ? ' hidden' : '') + '><label>It is</label><select data-f="kind">' + opts([['thing', 'a thing'], ['tool', 'a tool'], ['modifier', 'a modifier (what kind of it)']], k0) + '</select>'
        + '<label>Its meaning (one we have, or name a new one)</label><input type="text" data-f="class" list="wb-clsl" value="' + esc(x.kind === k0 ? x.class : '') + '" placeholder="creature, quality\u2026"><datalist id="wb-clsl">' + opts(C.thing.concat(C.tool, C.modifier)) + '</datalist></div>';
    }
    if (W === 'Where') return radios([['place', 'A local name for a town or area we hold'], ['notplace', 'Never a place']], x.kind === 'place' ? 'notplace' : 'place')
        + '<div data-wt="place"' + (x.kind === 'place' ? ' hidden' : '') + '><label>The town or area</label><input type="text" data-f="place" data-placelook list="wb-plcl" placeholder="Type: Saint Johns, Show Low\u2026" autocomplete="off"><datalist id="wb-plcl"></datalist>'
        + '<p class="se-hint">Search reads the true place; whether it can be shown (a nation\u2019s rules, a confidential address) is decided when it\u2019s shown.</p></div><div data-wt="notplace"' + (x.kind === 'place' ? '' : ' hidden') + '><p class="se-hint">It will never be read as a town or area, even where one has that name.</p></div>';
    if (W === 'When') return '<input type="hidden" name="wt" value="time"><label>It means</label><select data-f="class">' + opts(Object.keys(MN.time_classes).map(function (k) { return [k, MN.time_classes[k][1]]; }), x.kind === 'time' ? x.class : '') + '</select>';
    if (W === 'Who') return '<input type="hidden" name="wt" value="audience"><label>Who it\u2019s for</label><select data-f="audience">' + opts(Object.keys(LAST.audiences || {}).map(function (k) { return [k, LAST.audiences[k]]; }), x.kind === 'audience' ? x.class : '') + '</select><p class="se-hint">Who a place serves, or a public office. Never a person.</p>';
    return '';
  }
  function wOpen(card) {
    if (!MN || !LAST || !selTok()) return;
    var W = card.getAttribute('data-wcard'), x = selTok(), ed = card.querySelector('.wb-wed');
    [].forEach.call(document.querySelectorAll('[data-wcard].editing'), function (c) { if (c !== card) { c.classList.remove('editing'); c.querySelector('.wb-wed').hidden = true; } });
    ed.innerHTML = '<p class="wb-wh">Correct the ' + W + ' for \u201C' + esc(x.word) + '\u201D</p>' + wForm(W, x)
      + '<div class="wb-wacts"><button type="button" class="se-btn" data-wdry>Dry run</button><button type="button" class="se-btn main" data-wsave disabled title="Run the dry run first">Save</button><button type="button" class="se-btn" data-wcancel>Cancel</button></div><div class="wb-wres" aria-live="polite"></div>';
    ed.hidden = false; card.classList.add('editing');
    if (ed.wired) return; ed.wired = true;
    ed.addEventListener('change', function (e) {
      if (e.target.name === 'wt') [].forEach.call(ed.querySelectorAll('[data-wt]'), function (p0) { p0.hidden = p0.getAttribute('data-wt') !== e.target.value; });
      wDirty(card);
    });
    ed.addEventListener('input', function (e) {
      wDirty(card);
      var look = e.target.hasAttribute('data-catlook') ? 'cats' : (e.target.hasAttribute('data-placelook') ? 'places' : '');
      if (!look || e.target.value.trim().length < 2) return;
      fetch(location.pathname + '?json=' + look + '&q=' + encodeURIComponent(e.target.value.trim()), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        var dl = ed.querySelector(look === 'cats' ? '#wb-catl' : '#wb-plcl'); if (dl) dl.innerHTML = opts(d.cats || d.places || []);
      });
    });
  }
  function wDirty(card) { var b = card.querySelector('[data-wsave]'); if (b) { b.disabled = true; card.removeAttribute('data-dry'); } }
  function wChange(card) {
    var ed = card.querySelector('.wb-wed'), W = card.getAttribute('data-wcard').toLowerCase(), x = selTok();
    var t = ed.querySelector('[name=wt]:checked') || ed.querySelector('[name=wt]'), f = function (k) { var el = ed.querySelector('[data-f="' + k + '"]'); return el ? el.value : ''; };
    var c = { w: W, type: t ? t.value : '', word: x.word };
    if (c.type === 'situation') { c.slug = f('slug'); c.cues = f('cues'); }
    if (c.type === 'rule') { c.lead = f('lead'); c.slug = f('slug2'); c.things = [].map.call(ed.querySelectorAll('[data-thing]:checked'), function (i) { return i.value; }); }
    if (c.type === 'category') c.category = f('category');
    if (c.type === 'kind') { c.kind = f('kind'); c.class = f('class').trim().toLowerCase().replace(/\s+/g, '-'); }
    if (c.type === 'place') c.place = f('place');
    if (c.type === 'time') c.class = f('class');
    if (c.type === 'audience') c.audience = f('audience');
    return c;
  }
  var WK = ['why', 'what', 'where', 'when', 'who'];
  function wDry(card) {
    var c = wChange(card), res = card.querySelector('.wb-wres'), js = JSON.stringify(c);
    res.innerHTML = '<p class="se-hint">Trying it on recent searches with \u201C' + esc(c.word) + '\u201D\u2026</p>';
    Promise.all([post({ do: 'edit_read', q: q.value.trim(), change: js, with: '' }), post({ do: 'edit_read', q: q.value.trim(), change: js, with: 1 })]).then(function (r) {
      var a = r[0], b = r[1];
      if (!a.ok || !b.ok) { res.innerHTML = '<p class="se-err">' + esc((a.ok ? b : a).error || 'Couldn\u2019t try it.') + '</p>'; return; }
      var changed = [];
      b.samples.forEach(function (s0) {
        var x0 = a.readings[s0] || {}, y0 = b.readings[s0] || {}, diffs = [];
        WK.forEach(function (k) { if ((x0[k] || '') !== (y0[k] || '')) diffs.push('<b>' + k.charAt(0).toUpperCase() + k.slice(1) + ':</b> ' + (esc(x0[k]) || '<i>nothing</i>') + ' \u2192 ' + (esc(y0[k]) || '<i>nothing</i>')); });
        if (diffs.length) changed.push('<li><span class="wb-k">\u201C' + esc(s0) + '\u201D</span> ' + diffs.join(' \u00b7 ') + '</li>');
      });
      res.innerHTML = '<p><b>' + esc(b.summary) + '.</b> ' + (changed.length ? changed.length + ' of ' + b.samples.length + ' searches would read differently:' : 'None of the ' + b.samples.length + ' searches tried would read differently; it applies to new ones.') + '</p>'
        + (changed.length ? '<ul class="wb-l wb-chg">' + changed.join('') + '</ul>' : '');
      card.setAttribute('data-dry', js); card.setAttribute('data-changed', String(changed.length));
      var sv = card.querySelector('[data-wsave]'); sv.disabled = false; sv.title = '';
    });
  }
  function wSave(card) {
    var js = card.getAttribute('data-dry'); if (!js) return;
    post({ do: 'edit_save', q: q.value.trim(), change: js, changed: card.getAttribute('data-changed') || 0 }).then(function (d) {
      if (!d.ok) { card.querySelector('.wb-wres').innerHTML = '<p class="se-err">' + esc(d.error || 'Couldn\u2019t save it.') + '</p>'; return; }
      toast('Saved: ' + d.summary + '. Undo is under \u201CRecent corrections\u201D.'); mnLoad(); analyze();
    });
  }
  // ---- the word lightbox (decisions/0063): a word's category, job and meaning, its senses, its forms; no scrolling ----
  function lxClasses(kind, cur) {
    var TL = (MN && MN.time_classes) || {};
    $('lx-class').innerHTML = ((MN && MN.classes[kind]) || []).map(function (c) { return '<option value="' + esc(c) + '"' + (c === cur ? ' selected' : '') + '>' + esc(c) + (kind === 'time' && TL[c] ? ' \u2192 ' + esc(TL[c][1]) : '') + '</option>'; }).join('')
      + (kind === 'time' ? '' : '<option value="__new">A new meaning\u2026</option>');
    $('lx-newc').hidden = true; $('lx-weakw').hidden = !(kind === 'event' || kind === 'action');
  }
  function lxTab(t) {
    [].forEach.call(document.querySelectorAll('[data-lxtab]'), function (b) { b.classList.toggle('on', b.getAttribute('data-lxtab') === t); b.setAttribute('aria-selected', b.getAttribute('data-lxtab') === t ? 'true' : 'false'); });
    ['word', 'senses', 'forms'].forEach(function (k) { $('lx-' + k).hidden = k !== t; });
  }
  var LXW = null;
  function openLx(i) {
    if (!LAST || !LAST.lexicon || !LAST.lexicon[i]) return;
    if (!MN) { setTimeout(function () { openLx(i); }, 300); return; }
    var x = LAST.lexicon[i]; LXW = x; $('lx-err').textContent = '';
    $('lx-title').textContent = '\u201C' + x.word + '\u201D';
    var now = x.little ? 'A little word (' + (POSL[x.pos] || x.pos) + '): structure, not meaning.'
      : (!x.known ? 'Not recognized. ' + (x.pos ? 'Guessed ' + (POSL[x.pos] || x.pos).toLowerCase() + ': ' + x.why + '.' : 'Its category can\u2019t be told from where it sits.')
      : 'Read as ' + (POSL[x.pos] || x.pos || '?').toLowerCase() + ' \u00b7 ' + (KL[x.kind] || x.kind) + (x.class ? ' (' + x.class + ')' : '') + (x.w ? ' \u2192 ' + x.w : '') + (x.pos_from === 'guessed' ? ' (category guessed: ' + x.why + ')' : '') + '.'
        + (x.also && x.also.length ? ' Also: ' + x.also.map(function (a) { return (KL[a.kind] || a.kind) + ' (' + a.class + ')'; }).join(', ') + '.' : ''));
    $('lx-now').textContent = now;
    $('lx-pos').innerHTML = '<option value="">Not set</option>' + Object.keys(MN.pos).map(function (k) { return '<option value="' + k + '"' + (k === x.pos ? ' selected' : '') + '>' + esc(MN.pos[k]) + '</option>'; }).join('');
    var guessKind = { verb: 'action', noun: 'thing', adjective: 'modifier', adverb: 'time', particle: 'wrapper' };
    var k = MN.kinds[x.kind] ? x.kind : (guessKind[x.pos] || 'thing');
    $('lx-kind').innerHTML = Object.keys(MN.kinds).map(function (kk) { return '<option value="' + kk + '"' + (kk === k ? ' selected' : '') + '>' + esc(MN.kinds[kk][0]) + ' \u2192 ' + esc(MN.kinds[kk][1]) + '</option>'; }).join('');
    lxClasses(k, x.class);
    // a word search doesn't know yet gets a meaning of its own, named after it (change it to join an existing one)
    if (!x.known && !x.little && k !== 'time') { $('lx-class').value = '__new'; $('lx-newc').hidden = false; $('lx-newc').value = x.word.replace(/\s+/g, '-'); }
    var taught = (MN.words || []).filter(function (w) { return w.word === x.word; });
    $('lx-taught').innerHTML = taught.length ? 'Taught here: ' + taught.map(function (w) { return esc(w.kind + ' / ' + w.class + (w.pos ? ' / ' + w.pos : '')) + ' <button type="button" class="se-ib" data-mndel="' + w.id + '" aria-label="Remove">&times;</button>'; }).join(' ') + ' (saving replaces these)' : 'Nothing taught for it yet; saving adds it. Built-in meanings stay.';
    // senses of this word
    var sn = (LAST.senses || []).filter(function (s0) { return s0.base === x.word || (s0.forms || []).indexOf(x.word) >= 0; })[0];
    $('lx-slist').innerHTML = sn ? '<ol>' + sn.senses.map(function (y) { return '<li class="' + (y.used ? 'used' : '') + '"><b>' + esc(WN[y.w] || y.w) + ':</b> ' + esc(y.label) + ' <small>' + esc(y.when) + '</small></li>'; }).join('') + '</ol>' : '<p class="se-hint">No senses yet: it means the same wherever it sits.</p>';
    $('lx-ssit').innerHTML = $('mn-sit').innerHTML; $('lx-sw-note').hidden = x.word.indexOf(' ') < 0;
    // its forms: the words taught with the same meaning
    var same = (MN.words || []).filter(function (w) { return w.kind === k && w.class === (x.class || '') && w.word !== x.word; });
    $('lx-flist').innerHTML = same.length ? '<p>Same meaning: ' + same.map(function (w) { return esc(w.word); }).join(', ') + '</p>' : '<p class="se-hint">No other forms taught yet.</p>';
    lxTab(x.known || x.little ? 'word' : 'word');
    $('lx-modal').hidden = false; $('lx-pos').focus();
  }
  function lxClose() { $('lx-modal').hidden = true; }
  $('lx-kind').addEventListener('change', function () { lxClasses(this.value, ''); });
  $('lx-class').addEventListener('change', function () { $('lx-newc').hidden = this.value !== '__new'; if (this.value === '__new') $('lx-newc').focus(); });
  $('lx-modal').addEventListener('click', function (e) {
    var t = e.target;
    if (t === this || t.closest('[data-lxclose]')) { lxClose(); return; }
    if ((t = e.target.closest('[data-lxtab]'))) { lxTab(t.getAttribute('data-lxtab')); return; }
    if ((t = e.target.closest('[data-mndel]'))) { post({ do: 'meaning_del', id: t.getAttribute('data-mndel') }).then(function () { lxAfter('Removed.'); }); }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('lx-modal').hidden) lxClose(); });
  function lxAfter(msg) { toast(msg); mnLoad(); analyze(); setTimeout(function () { var i = (LAST && LAST.lexicon || []).findIndex(function (y) { return LXW && y.word === LXW.word; }); if (i >= 0 && !$('lx-modal').hidden) openLx(i); }, 900); }
  function lxClass() { return $('lx-class').value === '__new' ? $('lx-newc').value.trim().toLowerCase().replace(/\s+/g, '-') : $('lx-class').value; }
  $('lx-word').addEventListener('submit', function (e) {
    e.preventDefault(); $('lx-err').textContent = '';
    post({ do: 'meaning_set', word: LXW.word, kind: $('lx-kind').value, class: lxClass(), pos: $('lx-pos').value, weak: $('lx-weak').checked ? 1 : '' }).then(function (d) {
      if (!d.ok) { $('lx-err').textContent = d.error || 'Couldn\u2019t save it.'; return; }
      lxAfter('\u201C' + LXW.word + '\u201D is now ' + $('lx-kind').value + ' / ' + lxClass() + (d.new_class ? ' (a new meaning: add a rule for it next)' : '') + '. Search reads it now.');
    });
  });
  $('lx-forms').addEventListener('submit', function (e) {
    e.preventDefault(); $('lx-err').textContent = '';
    post({ do: 'forms_add', forms: $('lx-fin').value, kind: $('lx-kind').value, class: lxClass(), pos: $('lx-pos').value, weak: $('lx-weak').checked ? 1 : '' }).then(function (d) {
      if (!d.ok) { $('lx-err').textContent = d.error || 'Couldn\u2019t add them.'; return; }
      $('lx-fin').value = ''; lxAfter('Added ' + d.words.join(', ') + ' with the same meaning.');
    });
  });
  function lxSenseW() { var w = $('lx-sW').value; $('lx-se-why').hidden = w !== 'why'; $('lx-se-when').hidden = w !== 'when'; $('lx-se-as').hidden = !(w === 'where' || w === 'what'); }
  $('lx-sW').addEventListener('change', lxSenseW); lxSenseW();
  $('lx-senses').addEventListener('submit', function (e) {
    e.preventDefault(); $('lx-err').textContent = '';
    post({ do: 'sense_add', word: LXW.word, forms: '', w: $('lx-sW').value, slug: $('lx-ssit').value, season: $('lx-sseason').value, as: $('lx-sas').value,
           cues: $('lx-scues').value, label: $('lx-slabel').value, why: '' }).then(function (d) {
      if (!d.ok) { $('lx-err').textContent = d.error || 'Couldn\u2019t add it.'; return; }
      $('lx-scues').value = ''; $('lx-slabel').value = ''; lxAfter('Sense added for \u201C' + LXW.word + '\u201D.');
    });
  });
  // "Add it" from the search box: /admin/search-misses.php?q=how to compost&word=compost
  (function () {
    var u = new URLSearchParams(location.search), qq = u.get('q'), ww = u.get('word');
    if (!qq) return;
    q.value = qq; analyze();
    if (ww) { var tries = 0; (function wait() { var i = (LAST && LAST.lexicon || []).findIndex(function (y) { return y.word === ww.toLowerCase(); }); if (i >= 0 && MN) openLx(i); else if (++tries < 30) setTimeout(wait, 200); })(); }
  })();
  $('se-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var act = e.submitter && e.submitter.value, f = form(); $('se-err').textContent = '';
    if (act === 'draft') f.status = 'draft';
    var go = function () { return post({ do: 'save', form: JSON.stringify(f) }); };
    var ready = Promise.resolve(true);
    if (act === 'live') {
      f.status = 'live';
      // publishing runs the tests first: if any example search fails, say so before it goes live
      ready = f.examples && String(f.examples).trim() ? post({ do: 'sit_test', form: JSON.stringify(f), with: 1 }).then(function (b) {
        if (!b.ok) return true;
        var fail = b.examples.filter(function (ex) { return !(b.searches[ex] || []).some(function (x) { return x.slug === b.slug; }); });
        return !fail.length || TvAsk.confirm(fail.length + ' of ' + b.examples.length + ' example searches don\u2019t read as this yet (' + fail.join(', ') + '). Publish anyway?', { yes: 'Publish anyway' });
      }) : TvAsk.confirm('There are no example searches to test it with. Publish anyway?', { yes: 'Publish anyway' });
    }
    ready.then(function (okGo) { if (!okGo) return; go().then(function (d) {
      if (!d.ok) { $('se-err').textContent = d.error || 'Couldn’t save it.'; ['1', '2', '3', '4'].forEach(function (n) { $('se-sec' + n).open = true; }); return; }   // open them all, so what's missing shows
      toast('Saved ' + d.situation.label + (d.situation.status === 'live' ? '. Search answers it now.' : (d.situation.status === 'draft' ? ' as a draft. Set it Live once its tests pass.' : ' as ' + d.situation.status + '.')));
      close(); find(); if (!$('se-an').hidden) analyze();
    }); });
  });
  // "Build the rule from my example searches": read them, show in plain words what it will do, then do it
  var AUTO = null;
  document.addEventListener('click', function (e) {
    var t;
    if (e.target.closest('[data-autorules]')) {
      var ex = $('se-examples').value.trim(), out = $('se-autoout');
      if (!ex) { $('se-sec3').open = true; $('se-examples').focus(); out.innerHTML = '<p>Write at least one example search in step 3 first.</p>'; return; }
      out.innerHTML = '<p>Reading them\u2026</p>';
      post({ do: 'auto_rules', examples: ex }).then(function (d) {
        if (!d.ok) { out.innerHTML = '<p class="se-err">' + esc(d.error || 'Couldn\u2019t read them.') + '</p>'; return; }
        AUTO = d;
        if (!d.rules.length) { out.innerHTML = '<p>' + esc(d.notes.join(' ') || 'Nothing to build from these yet.') + '</p>'; return; }
        out.innerHTML = '<p><b>It will:</b></p><ul>'
          + d.teach.map(function (w) { return '<li>teach \u201C' + esc(w.word) + '\u201D as ' + esc(w.plain) + '</li>'; }).join('')
          + d.rules.map(function (r) { return '<li>show this situation when people search <b>' + esc(r.lead) + '</b>' + (r.things.length ? ' with <b>' + r.things.map(esc).join('</b> or <b>') + '</b>' : ' (on its own)') + '</li>'; }).join('')
          + '</ul>' + (d.notes.length ? '<p>' + esc(d.notes.join(' ')) + '</p>' : '')
          + '<button type="button" class="se-btn main" data-autouse>Use this</button>';
      });
      return;
    }
    if ((t = e.target.closest('[data-autouse]')) && AUTO) {
      t.disabled = true;
      var teach = AUTO.teach.slice(), rules = AUTO.rules.slice();
      (function next() {
        var w = teach.shift();
        if (w) { post({ do: 'meaning_add', kind: w.kind, class: w.class, word: w.word, weak: '' }).then(next); return; }
        fetch(location.pathname + '?json=meanings', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (m) {
          if (m.ok) MN = m;
          frameInputs(); fwMeanings();
          rules.forEach(function (r) { addFrame({ lead: r.lead, things: r.things }); });
          $('se-autoout').innerHTML = '<p>Done. Testing your example searches\u2026</p>';
          $('se-sec3').open = true; sitTest(); secSums();
        });
      })();
    }
  });
  // Reset: back to how it was last saved (a new one: empty)
  document.addEventListener('click', function (e) {
    var rb = e.target.closest('[data-reset]'); if (!rb) return;
    TvAsk.confirm('Put it back as it was last saved? What you changed here is lost.', { anchor: rb, yes: 'Put it back', danger: true }).then(function (ok) {
      if (ok) { if (cur && cur.id) edit(cur.id); else openEditor(null, ''); }
    });
  });
  // a word added from inside the builder (step 2): no going back and forth to Meanings
  function fwMeanings() {
    if (!MN) { setTimeout(fwMeanings, 300); return; }
    var k = $('se-fwk').value, list = (MN.classes[k] || []);
    $('se-fwc').innerHTML = '<option value="__new">Its own meaning (new)</option>' + list.map(function (c) { return '<option value="' + esc(c) + '">' + esc(c) + '</option>'; }).join('');
    $('se-fwn').hidden = false;
  }
  $('se-fwk').addEventListener('change', fwMeanings);
  $('se-fwc').addEventListener('change', function () { $('se-fwn').hidden = $('se-fwc').value !== '__new'; });
  document.addEventListener('click', function (e) {
    if (!e.target.closest('[data-fwadd]')) return;
    var w = $('se-fw').value.trim().toLowerCase(), k = $('se-fwk').value;
    var c = $('se-fwc').value === '__new' ? ($('se-fwn').value.trim() || w).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') : $('se-fwc').value;
    if (!w) { $('se-fw').focus(); return; }
    post({ do: 'meaning_add', kind: k, class: c, word: w, weak: '' }).then(function (d) {
      if (!d.ok) { $('se-err').textContent = d.error || 'Couldn\u2019t add it.'; return; }
      fetch(location.pathname + '?json=meanings', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (m) {
        if (m.ok) MN = m;
        var checked = [].map.call($('se-fthings').querySelectorAll('input:checked'), function (x) { return x.value; }), lead = $('se-flead').value;
        frameInputs(); fwMeanings();
        // what was just added is picked, ready for "Add this rule"
        if (k === 'event' || k === 'action') $('se-flead').value = c; else { $('se-flead').value = lead; checked.push(c); }
        [].forEach.call($('se-fthings').querySelectorAll('input'), function (x) { x.checked = checked.indexOf(x.value) >= 0; });
        toast('Added \u201C' + w + '\u201D (' + c + '). It\u2019s picked: tap Add this rule.');
        $('se-fw').value = ''; $('se-fwn').value = '';
      });
    });
  });
})();
</script>
<?php tv_page_end();
