<?php
/**
 * app/ui/table-kit.php: the table standard for tables the server writes (design/table-standard.md, T3-T5), shared by the
 * admin (app/admin/kit-css.php prints tv_table_css()) and its older pages, shown in a frame without the admin kit, which
 * call tv_table_kit() once after tv_page_start(). js/tv-table.js does the work. Moved from kit-css.php in T4.
 */

if (!function_exists('tv_table_css')) {
    /** The CSS: static tables (.akt-s), their page bar and phone cards. */
    function tv_table_css(): string
    {
        return <<<'CSS'
  /* tables the server writes, on the standard (T3-T5): TvAdmin.staticTable() adds .akt-s */
  table.akt-s{width:100%;border-collapse:separate;border-spacing:0;background:var(--tv-card-a);border:1px solid var(--tv-line);border-radius:var(--tv-r);font-size:.92rem}
  table.akt-s th{text-align:left;font:600 .8rem var(--tv-font-ui);letter-spacing:0;text-transform:none;color:var(--tv-meta);padding:.45rem .65rem;border-bottom:1px solid var(--tv-line);background:var(--tv-sec,#EDE6D5)}
  table.akt-s td{padding:.45rem .65rem;border-top:1px solid var(--tv-line);vertical-align:top;line-height:1.35}table.akt-s tbody tr:first-child td{border-top:0}
  table.akt-s tbody tr:hover td{background:color-mix(in srgb,var(--tv-sec,#EDE6D5) 60%,var(--tv-card-a))}table.akt-s .akt-num{text-align:right;white-space:nowrap}
  table.akt-s th.akt-sortable{cursor:pointer}table.akt-s th.akt-sortable::after{content:' ↕';color:var(--tv-taupe)}table.akt-s th[aria-sort=ascending]::after{content:' ▲';color:var(--tv-link)}table.akt-s th[aria-sort=descending]::after{content:' ▼';color:var(--tv-link)}
  .akt-pg{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .8rem;margin:.5rem .2rem 0;font-size:.88rem;color:var(--tv-meta)}.akt-pg:empty{display:none}@media (prefers-reduced-motion:reduce){.akt-skel i{animation:none}}
  .ak-pg{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .8rem;margin-top:.5rem;padding-top:.5rem;border-top:1px solid var(--tv-line);font-size:.9rem;color:var(--tv-meta)}
  .ak-pg:empty{display:none}
  .ak-pages{display:flex;flex-wrap:wrap;gap:.25rem;align-items:center}
  .ak-pgb{min-width:34px;height:34px;padding:0 .5rem;border:1px solid var(--tv-line);border-radius:.4rem;background:#fff;color:var(--tv-ink);font:inherit;cursor:pointer;font-variant-numeric:tabular-nums}
  .ak-pgb:hover:not(:disabled){border-color:var(--tv-link);color:var(--tv-link)}.ak-pgb[aria-current]{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text);font-weight:700}.ak-pgb:disabled{opacity:.4;cursor:default}
  .ak-gap{color:var(--tv-meta);padding:0 .15rem}
  .ak-per{margin-left:auto;display:flex;align-items:center;gap:.4rem;white-space:nowrap;color:var(--tv-meta)}.ak-per select{padding:.35rem .5rem;border:1px solid var(--tv-line-strong);border-radius:.4rem;background:#fff;font:inherit}
  @media (max-width:767px){
    table.akt-s,table.akt-s tbody,table.akt-s tr,table.akt-s td{display:block;width:auto}table.akt-s{background:transparent;border:0}table.akt-s thead{display:none}
    table.akt-s tbody tr{background:var(--tv-card-a);border:1px solid var(--tv-line);border-radius:.5rem;margin:0 0 3px;padding:.45rem .65rem}table.akt-s tbody tr[hidden]{display:none}
    table.akt-s td{border:0;padding:.08rem 0;display:flex;gap:.5rem}table.akt-s td[data-l]::before{content:attr(data-l);color:var(--tv-meta);font-size:.82rem;min-width:6.5rem;flex:none}table.akt-s .akt-num{text-align:left}
  }
CSS;
    }
}

if (!function_exists('tv_table_kit')) {
    /** For a page outside the admin router: the CSS and the script, once. Its list tables carry data-tv-table. */
    function tv_table_kit(): string
    {
        static $done = false; if ($done) return ''; $done = true;
        $v = (int) @filemtime(__DIR__ . '/../../website/js/tv-table.js');
        return '<style>' . tv_table_css() . '</style><script src="/js/tv-table.js?v=' . $v . '" defer></script>';
    }
}
