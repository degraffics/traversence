<?php
// app/lib/Vault.php — the Vault (decisions/0156): passwords only their owner's browser can open. The server keeps only
// sealed data it can't open (each item sealed with its own key, that key sealed with the vault key; the vault key sealed
// once per passkey and once by the recovery words, all in the browser). What the server does: checks passkeys
// (WebAuthn), hands over one sealed item at a time after a fresh check and a single-use token, logs and announces every
// reveal, locks on request, and makes the recovery words single-use (a recovery must save new ones before the vault opens
// again). Stage 1: staff (owners and executives first). Tables are made here on first use; they belong with "Staff and
// access" in the data separation (decisions/0110).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/WebAuthn.php';

final class Vault
{
    public const FRESH = 300;      // a reveal needs a passkey check within 5 minutes
    public const IDLE = 600;       // the vault locks itself after 10 minutes unused
    public const TOKEN = 60;       // a reveal token lasts a minute and works once
    public const HOUR_CAP = 40;    // reveals an hour before the vault locks itself
    public const EXT_HOURS = 12;   // a browser extension's connection lasts 12 hours (or until the browser closes, or Lock)
    private const MAXBLOB = 20000; // a sealed item's largest size (characters)

    public const TABLES = [
        'vault_meta' => '(user_id INT UNSIGNED NOT NULL PRIMARY KEY, handle VARCHAR(64) NOT NULL, prf_salt VARCHAR(64) NOT NULL, recovery TEXT NULL,
            recovery_used_at DATETIME NULL, kit_at DATETIME NULL, locked_at DATETIME NULL, lock_hash CHAR(64) NOT NULL DEFAULT \'\', totp TEXT NULL,
            totp_step BIGINT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL)',
        'vault_creds' => '(id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, cred_id VARCHAR(512) NOT NULL, pem TEXT NOT NULL,
            sign_count INT UNSIGNED NOT NULL DEFAULT 0, label VARCHAR(80) NOT NULL DEFAULT \'\', prf TINYINT(1) NOT NULL DEFAULT 0, slot TEXT NULL,
            created_at DATETIME NOT NULL, used_at DATETIME NULL, revoked_at DATETIME NULL, KEY idx_vc_user (user_id))',
        'vault_items' => '(id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, site CHAR(64) NOT NULL DEFAULT \'\', meta TEXT NOT NULL,
            secret MEDIUMTEXT NOT NULL, item_key TEXT NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, deleted_at DATETIME NULL, KEY idx_vi_user (user_id, site))',
        'vault_ext' => '(id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL, label VARCHAR(80) NOT NULL DEFAULT \'\', install VARCHAR(40) NOT NULL DEFAULT \'\', email VARCHAR(190) NOT NULL DEFAULT \'\', name VARCHAR(120) NOT NULL DEFAULT \'\',
            created_at DATETIME NOT NULL, used_at DATETIME NULL, until_at DATETIME NOT NULL, revoked_at DATETIME NULL, UNIQUE KEY uq_vx_token (token_hash), KEY idx_vx_user (user_id))',
        'vault_log' => '(id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, item_id INT UNSIGNED NULL, action VARCHAR(24) NOT NULL,
            device VARCHAR(80) NOT NULL DEFAULT \'\', ip VARCHAR(45) NOT NULL DEFAULT \'\', tz VARCHAR(64) NOT NULL DEFAULT \'\', at DATETIME NOT NULL, KEY idx_vl_user (user_id, at))',
    ];

    private static function t(string $x): string { return Database::t($x); }

    public static function ensure(PDO $pdo): void
    {
        static $done = false; if ($done) return;
        foreach (self::TABLES as $t => $def) $pdo->exec('CREATE TABLE IF NOT EXISTS ' . self::t($t) . ' ' . $def . ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        // added after the first build: the vault's own authenticator app (an extra check, never a key)
        if (!$pdo->query('SHOW COLUMNS FROM ' . self::t('vault_meta') . " LIKE 'totp'")->fetch())
            $pdo->exec('ALTER TABLE ' . self::t('vault_meta') . ' ADD COLUMN totp TEXT NULL, ADD COLUMN totp_step BIGINT NOT NULL DEFAULT 0');
        if (!$pdo->query('SHOW COLUMNS FROM ' . self::t('vault_ext') . " LIKE 'install'")->fetch())   // which browser's extension: reconnecting replaces its old connection
            $pdo->exec('ALTER TABLE ' . self::t('vault_ext') . " ADD COLUMN install VARCHAR(40) NOT NULL DEFAULT ''");
        if (!$pdo->query('SHOW COLUMNS FROM ' . self::t('vault_ext') . " LIKE 'email'")->fetch())   // where its alerts go (the extension's calls can't look up staff logins)
            $pdo->exec('ALTER TABLE ' . self::t('vault_ext') . " ADD COLUMN email VARCHAR(190) NOT NULL DEFAULT '', ADD COLUMN name VARCHAR(120) NOT NULL DEFAULT ''");
        if (!$pdo->query('SHOW COLUMNS FROM ' . self::t('vault_creds') . " LIKE 'pin_slot'")->fetch())   // the key sealed by this device's passkey alone: PIN unlock (Jason, 2026-11-12)
            $pdo->exec('ALTER TABLE ' . self::t('vault_creds') . ' ADD COLUMN pin_slot TEXT NULL');
        if (!$pdo->query('SHOW COLUMNS FROM ' . self::t('vault_meta') . " LIKE 'notify'")->fetch())   // what's emailed, and how often (Jason, 2026-11-12)
            $pdo->exec('ALTER TABLE ' . self::t('vault_meta') . ' ADD COLUMN notify TEXT NULL');
        if (!$pdo->query('SHOW COLUMNS FROM ' . self::t('vault_log') . " LIKE 'who'")->fetch())   // who did it, kept when it happened, for the summaries (Jason, 2026-11-13)
            $pdo->exec('ALTER TABLE ' . self::t('vault_log') . " ADD COLUMN who VARCHAR(160) NOT NULL DEFAULT ''");
        $done = true;
    }

    // ---- what's emailed, and how often (Jason, 2026-11-12: "control what gets emailed and how often"). Everything is
    // still in the vault's own record ("What's been done"); this only decides the email. What would tell you someone else
    // is in your vault (devices, recovery words, the authenticator app, locks, many deletes, and changing these settings)
    // is always emailed at once and can't be turned down. Summaries never name the logins: the server can't read names.

    /** Kinds of email: key => [name, what's in it, default]. */
    public const NOTIFY = [
        'opened' => ['Passwords opened', 'Each password shown or copied here, or filled by the browser extension.', 'each'],
        'changes' => ['Logins saved by the extension', 'A login the extension saved or updated. Summaries also count logins added, changed or deleted on this page.', 'each'],
        'ext' => ['Extension connected', 'A browser connected (or renewed) its extension.', 'each'],
        'unlock' => ['Vault unlocked after a lock', 'The vault was opened again after a Lock.', 'each'],
        'opened_vault' => ['Vault opened', 'Each time the vault is opened: with the passphrase, or with a code and this device\'s PIN.', 'each'],
    ];
    public const NOTIFY_ALWAYS = 'Devices added or removed, recovery words used or replaced, the authenticator app added or removed, the vault locked, many logins deleted at once, and changes to these settings: always emailed at once, so you\'d see someone else in your vault.';
    /** How often: key => [name, what it means]. */
    public const FREQ = [
        'each' => ['Each time', 'An email as it happens.'],
        'first' => ['First time each day', 'An email the first time it happens each day (your time), then none until the next day.'],
        'hourly' => ['Hourly summary', 'One email an hour with what happened, only when something did.'],
        'daily' => ['Daily summary', 'One email a day with what happened, only when something did.'],
        'off' => ['Don\'t email', 'Kept in What\'s been done only.'],
    ];
    /** The record's actions in each kind, for the summaries. */
    private const NOTIFY_ACTS = ['opened' => ['revealed'], 'changes' => ['added', 'changed', 'deleted'], 'ext' => ['ext_paired'], 'unlock' => ['unlocked'], 'opened_vault' => ['opened:pass', 'opened:app', 'opened:email']];
    private const ACT_NAMES = ['revealed' => 'Password opened', 'added' => 'Login added', 'changed' => 'Login changed', 'deleted' => 'Login deleted', 'ext_paired' => 'Extension connected', 'unlocked' => 'Vault unlocked', 'opened:pass' => 'Vault opened with the passphrase', 'opened:app' => 'Vault opened with the app\'s code and PIN', 'opened:email' => 'Vault opened with an emailed code and PIN'];

    /** Whether this kind already happened earlier today, in the owner's time zone (the record is written before the email). */
    private static function seenToday(PDO $pdo, int $uid, string $kind, string $tz): bool
    {
        try { $z = new DateTimeZone($tz !== '' ? $tz : 'UTC'); } catch (Throwable) { $z = new DateTimeZone('UTC'); }
        $from = (new DateTime('today', $z))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        $acts = self::NOTIFY_ACTS[$kind] ?? []; if (!$acts) return false;
        $in = implode(',', array_fill(0, count($acts), '?'));
        $st = $pdo->prepare('SELECT COUNT(*) FROM ' . self::t('vault_log') . " WHERE user_id = ? AND at >= ? AND action IN ($in)");
        $st->execute(array_merge([$uid, $from], $acts));
        return (int) $st->fetchColumn() > 1;
    }

    /** The owner's choices: kind => how often (the defaults filled in). */
    public static function notify(PDO $pdo, int $uid): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT notify FROM ' . self::t('vault_meta') . ' WHERE user_id = ?'); $st->execute([$uid]);
        $j = json_decode((string) ($st->fetchColumn() ?: ''), true); $j = is_array($j) ? $j : [];
        $out = [];
        foreach (self::NOTIFY as $k => $d) $out[$k] = isset($j[$k], self::FREQ[$j[$k]]) ? (string) $j[$k] : $d[2];
        return $out;
    }

    /** Saves the choices (the vault open on this device). Always emailed at once, saying what changed. */
    public static function setNotify(PDO $pdo, array $me, array $in, array $ctx): array
    {
        [$uid] = self::session((int) $me['id']);
        $old = self::notify($pdo, $uid); $new = $old; $said = [];
        foreach (self::NOTIFY as $k => $d) {
            $v = (string) ($in[$k] ?? $old[$k]);
            if (!isset(self::FREQ[$v])) throw new InvalidArgumentException('Choose how often for ' . $d[0] . '.');
            if ($v !== $old[$k]) $said[] = $d[0] . ': ' . self::FREQ[$v][0];
            $new[$k] = $v;
        }
        if (!$said) return $new;
        $st = $pdo->prepare('SELECT notify FROM ' . self::t('vault_meta') . ' WHERE user_id = ?'); $st->execute([$uid]);
        $j = json_decode((string) ($st->fetchColumn() ?: ''), true); $j = is_array($j) ? $j : [];
        foreach ($new as $k => $v) $j[$k] = $v;
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET notify = ? WHERE user_id = ?')->execute([json_encode($j), $uid]);
        self::log($pdo, $uid, null, 'notify_changed', $ctx);
        self::alert($pdo, $me, 'Your vault\'s email settings changed', 'What your Traversence vault emails you was changed' . self::where($ctx) . ":\n- " . implode("\n- ", $said), $ctx);
        return $new;
    }

    /**
     * The hourly and daily summaries (app/scripts/vault_digest_tick.php, hourly): for each vault with a kind set to a
     * summary that's due, one email listing what the record holds for those kinds since the last one. Nothing happened,
     * no email. Returns how many were sent.
     */
    public static function digests(PDO $pdo): int
    {
        self::ensure($pdo);
        $sent = 0; $now = time();
        foreach ($pdo->query('SELECT user_id, notify, locked_at FROM ' . self::t('vault_meta') . " WHERE notify LIKE '%hourly%' OR notify LIKE '%daily%'")->fetchAll(PDO::FETCH_ASSOC) as $m) {
            $uid = (int) $m['user_id']; $j = json_decode((string) $m['notify'], true); if (!is_array($j)) continue;
            $pref = self::notify($pdo, $uid); $last = is_array($j['_sent'] ?? null) ? $j['_sent'] : []; $lines = []; $changed = false;
            foreach (['hourly' => 3300, 'daily' => 86100] as $f => $gap) {   // a few minutes' slack, so the hourly run never skips
                $kinds = array_keys(array_filter($pref, fn ($v) => $v === $f)); if (!$kinds) continue;
                $since = (int) ($last[$f] ?? 0);
                if ($since && $now - $since < $gap) continue;
                $from = gmdate('Y-m-d H:i:s', $since ?: $now - ($f === 'hourly' ? 3600 : 86400));
                $acts = []; foreach ($kinds as $k) $acts = array_merge($acts, self::NOTIFY_ACTS[$k]);
                $in = implode(',', array_fill(0, count($acts), '?'));
                $st = $pdo->prepare('SELECT action, device, ip, tz, at, who FROM ' . self::t('vault_log') . " WHERE user_id = ? AND at >= ? AND action IN ($in) ORDER BY id");
                $st->execute(array_merge([$uid, $from], $acts));
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    try { $z = new DateTimeZone((string) $r['tz'] ?: 'UTC'); } catch (Throwable) { $z = new DateTimeZone('UTC'); }
                    $t = (new DateTime($r['at'] . ' UTC'))->setTimezone($z)->format('M j, g:i A T');
                    $lines[] = '- ' . $t . ': ' . (self::ACT_NAMES[$r['action']] ?? $r['action']) . ((string) $r['who'] !== '' ? ' by ' . $r['who'] : '')
                             . ' (' . trim(implode(', ', array_filter([(string) $r['device'], $r['ip'] !== '' ? 'from ' . $r['ip'] : '']))) . ')';
                }
                $last[$f] = $now; $changed = true;
            }
            if ($changed) { $j['_sent'] = $last; $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET notify = ? WHERE user_id = ?')->execute([json_encode($j), $uid]); }
            if (!$lines) continue;
            $u = $pdo->prepare('SELECT id, email, display_name, is_admin FROM users WHERE id = ?'); $u->execute([$uid]);
            $me = $u->fetch(PDO::FETCH_ASSOC); if (!$me) continue;
            $me = self::who($pdo, $me);
            self::alert($pdo, $me, 'Summary: ' . count($lines) . ' thing' . (count($lines) === 1 ? '' : 's') . ' in your vault',
                "What happened in your Traversence vault since the last summary:\n" . implode("\n", array_slice($lines, 0, 200)) . (count($lines) > 200 ? "\n…and " . (count($lines) - 200) . ' more.' : '')
                . "\n\nThe Vault page's What's been done names each login (only your browser can read the names). Change these emails from the vault's Emails button.", ['tz' => '']);
            $sent++;
        }
        return $sent;
    }

    private static function now(): string { return gmdate('Y-m-d H:i:s'); }

    /**
     * The vault's owner as people know them: a staff login's own user record has a placeholder address
     * (<id>@staff.traversence.invalid) that's never mailed, so the staff account's work email is used (else its linked
     * member account's), with its name and staff ID. Alerts go there, and the passkey is named with it.
     */
    public static function who(PDO $pdo, array $me): array
    {
        if (!str_ends_with(strtolower((string) ($me['email'] ?? '')), '.invalid')) return $me;
        try {
            $st = $pdo->prepare('SELECT s.staff_id, s.name, s.email, m.email AS member_email FROM ' . self::t('staff_accounts') . ' s LEFT JOIN users m ON m.id = s.member_user_id WHERE s.user_id = ? ORDER BY s.id DESC LIMIT 1');
            $st->execute([(int) $me['id']]);
            if ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                $mail = filter_var((string) $r['email'], FILTER_VALIDATE_EMAIL) ? (string) $r['email'] : (filter_var((string) $r['member_email'], FILTER_VALIDATE_EMAIL) ? (string) $r['member_email'] : '');
                $me['email'] = $mail;
                $me['display_name'] = trim((string) $r['name']) . ' (' . $r['staff_id'] . ')';
            }
        } catch (Throwable $e) { error_log('vault who: ' . $e->getMessage()); }
        return $me;
    }

    /** The vault's row, made on first use: its passkey handle and PRF salt (random, not secret). */
    public static function meta(PDO $pdo, int $uid): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM ' . self::t('vault_meta') . ' WHERE user_id = ?'); $st->execute([$uid]);
        $m = $st->fetch(PDO::FETCH_ASSOC);
        if ($m) return $m;
        $pdo->prepare('INSERT INTO ' . self::t('vault_meta') . ' (user_id, handle, prf_salt, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$uid, WebAuthn::b64u(random_bytes(16)), WebAuthn::b64u(random_bytes(32)), self::now()]);
        return self::meta($pdo, $uid);
    }

    /** Where it stands: [ready (has its recovery words), devices, items, locked, must rotate the words]. */
    public static function state(PDO $pdo, int $uid): array
    {
        $m = self::meta($pdo, $uid);
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT id, cred_id, label, prf, slot IS NOT NULL AS ready, pin_slot IS NOT NULL AS pin, created_at, used_at FROM ' . self::t('vault_creds') . ' WHERE user_id = ? AND revoked_at IS NULL ORDER BY id');
        $st->execute([$uid]); $devs = $st->fetchAll(PDO::FETCH_ASSOC);
        $n = $pdo->prepare('SELECT COUNT(*) FROM ' . self::t('vault_items') . ' WHERE user_id = ? AND deleted_at IS NULL'); $n->execute([$uid]);
        return ['ready' => $m['recovery'] !== null, 'devices' => $devs, 'items' => (int) $n->fetchColumn(), 'pin_any' => (bool) array_filter($devs, fn ($d) => (int) $d['pin'] === 1),
                'locked' => $m['locked_at'] !== null, 'rotate' => $m['recovery_used_at'] !== null, 'kit_at' => $m['kit_at'], 'prf_salt' => $m['prf_salt'],
                'app' => (string) ($m['totp'] ?? '') !== '', 'ext' => self::extList($pdo, $uid)];
    }

    // ---- passkeys ----------------------------------------------------------------------------------------------------

    /** Options for navigator.credentials.create(): a new passkey for this vault. */
    public static function createOptions(PDO $pdo, array $me): array
    {
        $m = self::meta($pdo, (int) $me['id']);
        $ex = $pdo->prepare('SELECT cred_id FROM ' . self::t('vault_creds') . ' WHERE user_id = ? AND revoked_at IS NULL'); $ex->execute([(int) $me['id']]);
        return ['challenge' => WebAuthn::challenge('register'), 'rp' => ['id' => WebAuthn::rpId(), 'name' => 'Traversence Vault'],
                'user' => ['id' => $m['handle'], 'name' => (string) (($me['email'] ?? '') ?: ($me['display_name'] ?? 'Vault')), 'displayName' => 'Traversence Vault: ' . (string) (($me['display_name'] ?? '') ?: ($me['email'] ?? ''))],
                'pubKeyCredParams' => [['type' => 'public-key', 'alg' => -7], ['type' => 'public-key', 'alg' => -257]],
                'authenticatorSelection' => ['residentKey' => 'preferred', 'userVerification' => 'required'], 'attestation' => 'none', 'timeout' => 300000,
                'excludeCredentials' => array_map(fn ($id) => ['type' => 'public-key', 'id' => $id], $ex->fetchAll(PDO::FETCH_COLUMN)),
                'extensions' => ['prf' => new stdClass()]];
    }

    /** Saves a new passkey (not yet able to open the vault: its sealed copy of the vault key comes after it's used once). */
    public static function addPasskey(PDO $pdo, array $me, array $resp, string $label, bool $prf, array $ctx): int
    {
        $uid = (int) $me['id'];
        $k = WebAuthn::register($resp);
        $pdo->prepare('INSERT INTO ' . self::t('vault_creds') . ' (user_id, cred_id, pem, sign_count, label, prf, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$uid, $k['id'], $k['pem'], $k['count'], mb_substr(trim($label) ?: 'This device', 0, 80), $prf ? 1 : 0, self::now()]);
        $id = (int) $pdo->lastInsertId();
        self::log($pdo, $uid, null, 'device_added', $ctx);
        self::alert($pdo, $me, 'A new device was added to your vault', 'A new device ("' . (trim($label) ?: 'This device') . '") was added to your Traversence vault' . self::where($ctx) . '. It can\'t open anything without your passphrase.', $ctx);
        return $id;
    }

    /** Options for navigator.credentials.get(): any of this vault's passkeys, with the PRF salt. */
    public static function getOptions(PDO $pdo, int $uid): array
    {
        $m = self::meta($pdo, $uid);
        $st = $pdo->prepare('SELECT cred_id FROM ' . self::t('vault_creds') . ' WHERE user_id = ? AND revoked_at IS NULL'); $st->execute([$uid]);
        return ['challenge' => WebAuthn::challenge('assert'), 'rpId' => WebAuthn::rpId(), 'userVerification' => 'required', 'timeout' => 300000,
                'allowCredentials' => array_map(fn ($id) => ['type' => 'public-key', 'id' => $id], $st->fetchAll(PDO::FETCH_COLUMN)),
                'extensions' => ['prf' => ['eval' => ['first' => $m['prf_salt']]]]];
    }

    /**
     * A passkey check: verifies it, marks the session fresh for this vault and device, and returns that passkey's sealed
     * copy of the vault key (null for a device that hasn't been given one yet).
     */
    public static function check(PDO $pdo, int $uid, array $resp, array $ctx): array
    {
        $m = self::meta($pdo, $uid);
        $st = $pdo->prepare('SELECT * FROM ' . self::t('vault_creds') . ' WHERE user_id = ? AND cred_id = ? AND revoked_at IS NULL'); $st->execute([$uid, (string) ($resp['id'] ?? '')]);
        $c = $st->fetch(PDO::FETCH_ASSOC);
        if (!$c) throw new InvalidArgumentException('That passkey isn\'t one of this vault\'s devices.');
        try { $n = WebAuthn::verify((array) ($resp['response'] ?? []), (string) $c['pem'], (int) $c['sign_count']); }
        catch (InvalidArgumentException $x) { self::log($pdo, $uid, null, 'check_failed', $ctx); throw $x; }
        $slotPrf = $c['slot'] !== null && !empty(json_decode((string) $c['slot'], true)['prf']);   // the list says what the key really uses
        $pdo->prepare('UPDATE ' . self::t('vault_creds') . ' SET sign_count = ?, used_at = ?, prf = ? WHERE id = ?')->execute([$n, self::now(), $slotPrf ? 1 : (int) $c['prf'], (int) $c['id']]);
        $_SESSION['tv_vault'] = ['uid' => $uid, 'cred' => (int) $c['id'], 'fresh' => time(), 'seen' => time()];
        // PIN unlock: this device's key sealed by its passkey alone, handed over only after a step-one check (the
        // authenticator app's code or an emailed code) in the last 10 minutes, used once
        $pin = null; $s1 = $_SESSION['tv_vault_step1'] ?? null;
        if ($s1 && (int) $s1['uid'] === $uid && time() - (int) $s1['at'] <= 600) {
            unset($_SESSION['tv_vault_step1']);
            if ($c['pin_slot'] !== null) $pin = json_decode((string) $c['pin_slot'], true);
        }
        return ['cred' => (int) $c['id'], 'slot' => $c['slot'] !== null ? json_decode((string) $c['slot'], true) : null, 'prf' => (bool) $c['prf'], 'pin' => $pin, 'has_pin' => $c['pin_slot'] !== null,
                'ready' => $m['recovery'] !== null, 'locked' => $m['locked_at'] !== null, 'rotate' => $m['recovery_used_at'] !== null];
    }

    /** The session's vault, if it was opened here and hasn't sat unused for 10 minutes; [uid, cred]. */
    public static function session(int $uid, bool $fresh = false): array
    {
        $s = $_SESSION['tv_vault'] ?? null;
        if (!$s || (int) $s['uid'] !== $uid) throw new InvalidArgumentException('Unlock the vault first.');
        if (time() - (int) $s['seen'] > self::IDLE) { unset($_SESSION['tv_vault']); throw new InvalidArgumentException('The vault locked itself after 10 minutes. Unlock it again.'); }
        if ($fresh && time() - (int) $s['fresh'] > self::FRESH) throw new InvalidArgumentException('Check it\'s you again (your passkey) to see a password.');
        $_SESSION['tv_vault']['seen'] = time();
        return [$uid, (int) $s['cred']];
    }

    private static function open(PDO $pdo, int $uid): void
    {
        $m = self::meta($pdo, $uid);
        if ($m['locked_at'] !== null) throw new InvalidArgumentException('The vault is locked. Unlock it from the Vault page with your passkey.');
        if ($m['recovery_used_at'] !== null) throw new InvalidArgumentException('Your recovery words were used: save your new words first.');
    }

    /** Validates a sealed blob from the browser: JSON with iv and ct (base64url), nothing readable. */
    private static function sealed($v, string $what): string
    {
        $a = is_string($v) ? json_decode($v, true) : $v;
        if (!is_array($a) || !preg_match('/^[A-Za-z0-9_-]{16,}$/', (string) ($a['iv'] ?? '')) || !preg_match('/^[A-Za-z0-9_-]{16,}$/', (string) ($a['ct'] ?? '')))
            throw new InvalidArgumentException($what . ' wasn\'t sealed.');
        $keep = array_intersect_key($a, array_flip(['v', 'iv', 'ct', 'salt', 'iter', 'kdf', 'prf']));
        $j = json_encode($keep);
        if (strlen($j) > self::MAXBLOB) throw new InvalidArgumentException($what . ' is too large.');
        return $j;
    }

    /** First setup: this device's sealed vault key, and the recovery words' (both sealed in the browser). */
    public static function setup(PDO $pdo, array $me, array $slot, array $recovery, array $ctx): void
    {
        [$uid, $cred] = self::session((int) $me['id'], true);
        $m = self::meta($pdo, $uid);
        if ($m['recovery'] !== null) throw new InvalidArgumentException('This vault is already set up.');
        $pdo->prepare('UPDATE ' . self::t('vault_creds') . ' SET slot = ?, prf = ? WHERE id = ? AND user_id = ?')->execute([self::sealed($slot, 'The device\'s key'), !empty($slot['prf']) ? 1 : 0, $cred, $uid]);
        $lock = bin2hex(random_bytes(24));
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET recovery = ?, kit_at = ?, lock_hash = ? WHERE user_id = ?')->execute([self::sealed($recovery, 'The recovery key'), self::now(), hash('sha256', $lock), $uid]);
        $_SESSION['tv_vault_lock'] = $lock;
        self::log($pdo, $uid, null, 'created', $ctx);
        self::alert($pdo, $me, 'Your vault is ready', "Your Traversence vault is set up. Keep your Emergency Kit (the 24 words) somewhere safe and offline: we can't open or reset your vault.", $ctx);
    }

    /** A device given its sealed copy of the vault key (after a recovery, or a passkey added on a device that can open it). */
    public static function setSlot(PDO $pdo, array $me, array $slot, array $ctx): void
    {
        [$uid, $cred] = self::session((int) $me['id'], true);
        $pdo->prepare('UPDATE ' . self::t('vault_creds') . ' SET slot = ?, prf = ? WHERE id = ? AND user_id = ?')->execute([self::sealed($slot, 'The device\'s key'), !empty($slot['prf']) ? 1 : 0, $cred, $uid]);
        self::log($pdo, $uid, null, 'device_ready', $ctx);
    }

    // ---- PIN unlock (Jason, 2026-11-12: "three buttons, log in with 1, 2 or 3"): step one is the passphrase, the
    // authenticator app's code or an emailed code; step two is this device's passkey (its PIN, fingerprint or face). Only
    // step two can open the vault: its key comes from the passkey's own secret (PRF), which we never see. The app's and
    // the email's codes are ours, so they only decide whether the PIN-sealed copy is handed over.

    /** Step one by the app's code or an emailed code. */
    public static function step1(PDO $pdo, int $uid, string $how, string $code): void
    {
        $code = preg_replace('/\D/', '', $code);
        if ($how === 'app') {
            $m = self::meta($pdo, $uid);
            if ((string) ($m['totp'] ?? '') === '') throw new InvalidArgumentException('This vault has no authenticator app yet: add one under Devices (open the vault with your passphrase), or use an emailed code.');
            self::appCheck($pdo, $uid, $code, 'unlock');
        } elseif ($how === 'email') {
            $c = $_SESSION['tv_vault_ucode'] ?? null;
            if (!$c || (int) $c['uid'] !== $uid || $c['exp'] < time()) throw new InvalidArgumentException('That code ran out. Send a new one.');
            if (++$_SESSION['tv_vault_ucode']['tries'] > 5) { unset($_SESSION['tv_vault_ucode']); throw new InvalidArgumentException('Too many tries. Send a new code.'); }
            if (!hash_equals((string) $c['h'], hash('sha256', $code))) throw new InvalidArgumentException('That code doesn\'t match the one we emailed. Check the newest email, or send a new one.');
            unset($_SESSION['tv_vault_ucode']);
        } else throw new InvalidArgumentException('Choose how to check it\'s you.');
        $_SESSION['tv_vault_step1'] = ['uid' => $uid, 'how' => $how, 'at' => time()];
    }

    /** An emailed code for step one (10 minutes, 5 tries). */
    public static function unlockCode(int $uid): string
    {
        $code = (string) random_int(100000, 999999);
        $_SESSION['tv_vault_ucode'] = ['uid' => $uid, 'h' => hash('sha256', $code), 'exp' => time() + 600, 'tries' => 0];
        return $code;
    }

    /** This device's key sealed by its passkey alone (the vault open here with the passphrase and this passkey's secret). */
    public static function setPinSlot(PDO $pdo, array $me, array $slot, array $ctx): void
    {
        [$uid, $cred] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $st = $pdo->prepare('SELECT label, pin_slot FROM ' . self::t('vault_creds') . ' WHERE id = ? AND user_id = ? AND revoked_at IS NULL'); $st->execute([$cred, $uid]);
        $c = $st->fetch(PDO::FETCH_ASSOC); if (!$c) throw new InvalidArgumentException('This device isn\'t one of the vault\'s.');
        $pdo->prepare('UPDATE ' . self::t('vault_creds') . ' SET pin_slot = ? WHERE id = ?')->execute([self::sealed($slot, 'The PIN key'), $cred]);
        if ($c['pin_slot'] !== null) return;   // replaced (a new seal), already announced
        self::log($pdo, $uid, null, 'pin_on', $ctx);
        self::alert($pdo, $me, 'PIN unlock is on for a device', 'PIN unlock was turned on for "' . $c['label'] . '" in your Traversence vault' . self::where($ctx) . '. On that device the vault now opens with your authenticator app\'s code or an emailed code, then the device\'s PIN, fingerprint or face. Turn it off under Devices.', $ctx);
    }

    /** Turns PIN unlock off for a device (its PIN-sealed copy is deleted). */
    public static function pinOff(PDO $pdo, array $me, int $credId, array $ctx): void
    {
        [$uid] = self::session((int) $me['id']);
        $st = $pdo->prepare('UPDATE ' . self::t('vault_creds') . ' SET pin_slot = NULL WHERE id = ? AND user_id = ? AND pin_slot IS NOT NULL'); $st->execute([$credId, $uid]);
        if (!$st->rowCount()) return;
        self::log($pdo, $uid, null, 'pin_off', $ctx);
        self::alert($pdo, $me, 'PIN unlock was turned off for a device', 'PIN unlock was turned off for a device in your Traversence vault' . self::where($ctx) . '. It opens with the passphrase again.', $ctx);
    }

    /** The page says the vault opened here, and how: in the record, and emailed as the owner chose ("Vault opened"). */
    public static function opened(PDO $pdo, array $me, string $how, array $ctx): void
    {
        [$uid] = self::session((int) $me['id']);
        $how = in_array($how, ['pass', 'app', 'email'], true) ? $how : 'pass';
        self::log($pdo, $uid, null, 'opened:' . $how, $ctx);
        $w = ['pass' => 'with the passphrase', 'app' => 'with the authenticator app\'s code and the device\'s PIN', 'email' => 'with an emailed code and the device\'s PIN'][$how];
        // who: the account and the staff login that opened it (Jason, 2026-11-12: "the vault was opened by who?")
        self::alert($pdo, $me, 'Your vault was opened', 'Your Traversence vault was opened by ' . self::byWhom($me) . ' ' . $w . self::where($ctx) . '.', $ctx, 'opened_vault');
    }

    /** Another device given the vault key from this one (it must have been added and checked first). */
    public static function setSlotFor(PDO $pdo, array $me, int $credId, array $slot, array $ctx): void
    {
        [$uid] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $st = $pdo->prepare('UPDATE ' . self::t('vault_creds') . ' SET slot = ?, prf = ? WHERE id = ? AND user_id = ? AND revoked_at IS NULL');
        $st->execute([self::sealed($slot, 'The device\'s key'), !empty($slot['prf']) ? 1 : 0, $credId, $uid]);
        if (!$st->rowCount()) throw new InvalidArgumentException('That device isn\'t waiting for a key.');
        self::log($pdo, $uid, null, 'device_ready', $ctx);
    }

    public static function removeDevice(PDO $pdo, array $me, int $credId, array $ctx): void
    {
        [$uid, $cred] = self::session((int) $me['id'], true);
        if ($credId === $cred) throw new InvalidArgumentException('Remove this device from another one.');
        $pdo->prepare('UPDATE ' . self::t('vault_creds') . ' SET revoked_at = ?, slot = NULL WHERE id = ? AND user_id = ?')->execute([self::now(), $credId, $uid]);
        self::log($pdo, $uid, null, 'device_removed', $ctx);
        self::alert($pdo, $me, 'A device was removed from your vault', 'A device was removed from your Traversence vault' . self::where($ctx) . '.', $ctx);
    }

    // ---- recovery: the 24 words, used once -----------------------------------------------------------------------------

    /** The recovery words' sealed vault key, for a device that has a passkey here but no key yet. Using it retires the words.
     *  With an authenticator app on the vault, its code too. */
    public static function recoveryKey(PDO $pdo, array $me, array $ctx, string $appCode = ''): array
    {
        [$uid] = self::session((int) $me['id'], true);
        $m = self::meta($pdo, $uid);
        if ($m['recovery'] === null) throw new InvalidArgumentException('This vault has no recovery words yet.');
        self::appCheck($pdo, $uid, $appCode, 'recovery');
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET recovery_used_at = ? WHERE user_id = ?')->execute([self::now(), $uid]);
        self::log($pdo, $uid, null, 'recovery_used', $ctx);
        self::alert($pdo, $me, 'Your recovery words were used', 'Your vault\'s recovery words were used' . self::where($ctx) . '. They no longer work: new ones are made now. If this wasn\'t you, lock your vault.', $ctx);
        return json_decode((string) $m['recovery'], true);
    }

    /** New recovery words (after using the old ones, or by choice): the old ones stop working. */
    public static function newRecovery(PDO $pdo, array $me, array $recovery, array $ctx): void
    {
        [$uid] = self::session((int) $me['id'], true);
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET recovery = ?, recovery_used_at = NULL, kit_at = ? WHERE user_id = ?')->execute([self::sealed($recovery, 'The recovery key'), self::now(), $uid]);
        self::log($pdo, $uid, null, 'recovery_new', $ctx);
        self::alert($pdo, $me, 'New recovery words for your vault', 'New recovery words were made for your Traversence vault' . self::where($ctx) . '. The old ones no longer work.', $ctx);
    }

    // ---- items -------------------------------------------------------------------------------------------------------

    /** The list: each item's sealed name and address (opened in the browser), never its password. */
    public static function items(PDO $pdo, array $me): array
    {
        [$uid] = self::session((int) $me['id']); self::open($pdo, $uid);
        $st = $pdo->prepare('SELECT id, site, meta, item_key, created_at, updated_at FROM ' . self::t('vault_items') . ' WHERE user_id = ? AND deleted_at IS NULL ORDER BY id'); $st->execute([$uid]);
        return array_map(fn ($r) => ['id' => (int) $r['id'], 'site' => (string) $r['site'], 'meta' => json_decode((string) $r['meta'], true), 'key' => json_decode((string) $r['item_key'], true), 'added' => $r['created_at'] . 'Z', 'updated' => $r['updated_at'] . 'Z'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /** Adds or changes an item: its sealed name and address, sealed secret, sealed key and the address's blind index. */
    public static function saveItem(PDO $pdo, array $me, int $id, array $in, array $ctx): int
    {
        [$uid] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $site = (string) ($in['site'] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/', $site)) throw new InvalidArgumentException('The item has no address.');
        $meta = self::sealed($in['meta'] ?? null, 'The name'); $secret = self::sealed($in['secret'] ?? null, 'The login'); $key = self::sealed($in['key'] ?? null, 'The item\'s key');
        if ($id > 0) {
            $st = $pdo->prepare('UPDATE ' . self::t('vault_items') . ' SET site = ?, meta = ?, secret = ?, item_key = ?, updated_at = ? WHERE id = ? AND user_id = ? AND deleted_at IS NULL');
            $st->execute([$site, $meta, $secret, $key, self::now(), $id, $uid]);
            if (!$st->rowCount()) throw new InvalidArgumentException('That item isn\'t here.');
            self::log($pdo, $uid, $id, 'changed', $ctx);
            return $id;
        }
        $pdo->prepare('INSERT INTO ' . self::t('vault_items') . ' (user_id, site, meta, secret, item_key, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([$uid, $site, $meta, $secret, $key, self::now(), self::now()]);
        $id = (int) $pdo->lastInsertId();
        self::log($pdo, $uid, $id, 'added', $ctx);
        return $id;
    }

    public static function deleteItem(PDO $pdo, array $me, int $id, array $ctx): void
    {
        [$uid] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $pdo->prepare('UPDATE ' . self::t('vault_items') . ' SET deleted_at = ?, secret = \'{}\' WHERE id = ? AND user_id = ?')->execute([self::now(), $id, $uid]);
        self::log($pdo, $uid, $id, 'deleted', $ctx);
    }

    /** Deletes many logins at once (the vault's clean-up); one email says how many. Their sealed passwords are wiped. */
    public static function deleteMany(PDO $pdo, array $me, array $ids, array $ctx): int
    {
        [$uid] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn ($i) => $i > 0)));
        if (!$ids || count($ids) > 2000) throw new InvalidArgumentException('Choose between 1 and 2,000 logins.');
        $n = 0;
        foreach (array_chunk($ids, 200) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            $st = $pdo->prepare('UPDATE ' . self::t('vault_items') . " SET deleted_at = ?, secret = '{}' WHERE user_id = ? AND deleted_at IS NULL AND id IN ($in)");
            $st->execute(array_merge([self::now(), $uid], $chunk));
            $n += $st->rowCount();
        }
        if ($n) {
            self::log($pdo, $uid, null, 'deleted_many:' . $n, $ctx);
            self::alert($pdo, $me, $n . ' logins deleted from your vault', $n . ' logins were deleted from your Traversence vault' . self::where($ctx) . '. They can\'t be brought back.', $ctx);
        }
        return $n;
    }

    /** A single-use reveal token for one item (a fresh passkey check within 5 minutes; a minute to use it). */
    public static function token(PDO $pdo, array $me, int $id): string
    {
        [$uid, $cred] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $n = $pdo->prepare('SELECT COUNT(*) FROM ' . self::t('vault_log') . " WHERE user_id = ? AND action = 'revealed' AND at > ?"); $n->execute([$uid, gmdate('Y-m-d H:i:s', time() - 3600)]);
        if ((int) $n->fetchColumn() >= self::HOUR_CAP) { self::lock($pdo, $uid, 'cap'); throw new InvalidArgumentException('That\'s a lot of passwords in an hour: the vault locked itself. Unlock it with your passkey.'); }
        $t = bin2hex(random_bytes(16));
        $_SESSION['tv_vault_tok'] = ['h' => hash('sha256', $t), 'item' => $id, 'cred' => $cred, 'exp' => time() + self::TOKEN];
        return $t;
    }

    /** One item's sealed login, for its token (used once). Logged and announced to the owner. */
    public static function reveal(PDO $pdo, array $me, int $id, string $token, string $how, array $ctx): array
    {
        [$uid, $cred] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $t = $_SESSION['tv_vault_tok'] ?? null; unset($_SESSION['tv_vault_tok']);
        if (!$t || $t['exp'] < time() || (int) $t['item'] !== $id || (int) $t['cred'] !== $cred || !hash_equals((string) $t['h'], hash('sha256', $token)))
            throw new InvalidArgumentException('That reveal ran out. Try again.');
        $st = $pdo->prepare('SELECT secret, item_key FROM ' . self::t('vault_items') . ' WHERE id = ? AND user_id = ? AND deleted_at IS NULL'); $st->execute([$id, $uid]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That item isn\'t here.');
        self::log($pdo, $uid, $id, 'revealed', $ctx);
        $what = trim(mb_substr(preg_replace('/[\r\n]+/', ' ', $how), 0, 90)) ?: 'A password was opened';   // "Password copied: Railway" (the page knows the name; we don't)
        self::alert($pdo, $me, $what, $what . ', from your Traversence vault' . self::where($ctx) . '.', $ctx, 'opened');
        return ['secret' => json_decode((string) $r['secret'], true), 'key' => json_decode((string) $r['item_key'], true)];
    }

    // ---- the browser extension (decisions/0156 §8, stage 1): the vault page, open after a passkey check, gives this
    // browser's extension the vault key (it stays in the browser's memory) and a token for this API. The token alone opens
    // nothing: everything it fetches is sealed. It lasts EXT_HOURS, ends on Lock or Disconnect, and every password filled
    // is logged and emailed like any other.

    /** Connects an extension: returns its token (shown to the extension once; we keep only its hash). */
    public static function extPair(PDO $pdo, array $me, string $label, array $ctx, string $install = ''): array
    {
        [$uid] = self::session((int) $me['id'], true); self::open($pdo, $uid);
        $install = preg_match('/^[A-Za-z0-9_-]{8,40}$/', $install) ? $install : '';
        if ($install !== '') $pdo->prepare('UPDATE ' . self::t('vault_ext') . ' SET revoked_at = ? WHERE user_id = ? AND install = ? AND revoked_at IS NULL')->execute([self::now(), $uid, $install]);   // the same browser connecting again: its old connection ends
        $tok = bin2hex(random_bytes(32)); $until = gmdate('Y-m-d H:i:s', time() + self::EXT_HOURS * 3600);
        $label = mb_substr(trim($label) ?: (string) ($ctx['device'] ?? 'Browser extension'), 0, 80);
        $pdo->prepare('INSERT INTO ' . self::t('vault_ext') . ' (user_id, token_hash, label, install, email, name, created_at, until_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$uid, hash('sha256', $tok), $label, $install, mb_substr((string) ($me['email'] ?? ''), 0, 190), mb_substr((string) ($me['display_name'] ?? ''), 0, 120), self::now(), $until]);
        self::log($pdo, $uid, null, 'ext_paired', $ctx);
        self::alert($pdo, $me, 'A browser extension was connected to your vault', 'The Traversence Vault extension was connected to your vault (' . $label . ')' . self::where($ctx) . '. It can fill your saved logins on their own sites until ' . gmdate('M j, g:i A', strtotime($until . ' UTC')) . ' UTC, or until you lock the vault.', $ctx, 'ext');
        return ['token' => $tok, 'until' => $until . 'Z', 'id' => (int) $pdo->lastInsertId()];
    }

    public static function extList(PDO $pdo, int $uid): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT id, label, install, created_at, used_at, until_at FROM ' . self::t('vault_ext') . ' WHERE user_id = ? AND revoked_at IS NULL AND until_at > ? ORDER BY id DESC');
        $st->execute([$uid, self::now()]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function extRemove(PDO $pdo, array $me, int $id, array $ctx): void
    {
        [$uid] = self::session((int) $me['id']);
        $pdo->prepare('UPDATE ' . self::t('vault_ext') . ' SET revoked_at = ? WHERE id = ? AND user_id = ?')->execute([self::now(), $id, $uid]);
        self::log($pdo, $uid, null, 'ext_removed', $ctx);
    }

    /** The extension's token: [owner (id, email, name), connection id]. Refused once it's ended, locked or the owner isn't staff. */
    public static function extAuth(PDO $pdo, string $tok): array
    {
        self::ensure($pdo);
        if (!preg_match('/^[a-f0-9]{64}$/', $tok)) throw new InvalidArgumentException('Connect the extension from the Vault page.');
        $st = $pdo->prepare('SELECT * FROM ' . self::t('vault_ext') . ' WHERE token_hash = ?'); $st->execute([hash('sha256', $tok)]);
        $x = $st->fetch(PDO::FETCH_ASSOC);
        if (!$x || $x['revoked_at'] !== null || strtotime($x['until_at'] . ' UTC') < time()) throw new InvalidArgumentException('This connection has ended. Open the Vault page and connect the extension again.');
        $u = $pdo->prepare('SELECT id, email, display_name, is_admin FROM users WHERE id = ?'); $u->execute([(int) $x['user_id']]);
        $me = $u->fetch(PDO::FETCH_ASSOC);
        if (!$me || empty($me['is_admin'])) throw new InvalidArgumentException('This vault is for staff, and this account isn\'t staff now.');
        // its owner's real address and name, kept when it was connected from the Vault page (a staff login's own record has a
        // placeholder address, and the staff accounts may sit in the admin database this endpoint doesn't open)
        if ((string) ($x['email'] ?? '') !== '') { $me['email'] = (string) $x['email']; $me['display_name'] = (string) $x['name']; } else $me = self::who($pdo, $me);
        self::open($pdo, (int) $me['id']);
        $pdo->prepare('UPDATE ' . self::t('vault_ext') . ' SET used_at = ? WHERE id = ?')->execute([self::now(), (int) $x['id']]);
        return [$me, (int) $x['id']];
    }

    /** Every item's sealed name and address and its sealed key, for the extension to open in the browser. */
    public static function extItems(PDO $pdo, int $uid): array
    {
        $st = $pdo->prepare('SELECT id, site, meta, item_key, updated_at FROM ' . self::t('vault_items') . ' WHERE user_id = ? AND deleted_at IS NULL ORDER BY id'); $st->execute([$uid]);
        return array_map(fn ($r) => ['id' => (int) $r['id'], 'site' => (string) $r['site'], 'meta' => json_decode((string) $r['meta'], true), 'key' => json_decode((string) $r['item_key'], true), 'updated' => $r['updated_at'] . 'Z'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /** One sealed login for the extension, only for a site it's asked from (the blind index must match). Logged and emailed. */
    public static function extReveal(PDO $pdo, array $me, int $id, string $site, string $how, array $ctx): array
    {
        $uid = (int) $me['id'];
        $n = $pdo->prepare('SELECT COUNT(*) FROM ' . self::t('vault_log') . " WHERE user_id = ? AND action = 'revealed' AND at > ?"); $n->execute([$uid, gmdate('Y-m-d H:i:s', time() - 3600)]);
        if ((int) $n->fetchColumn() >= self::HOUR_CAP) { self::lock($pdo, $uid, 'cap'); throw new InvalidArgumentException('That\'s a lot of passwords in an hour: the vault locked itself. Unlock it on the Vault page.'); }
        $st = $pdo->prepare('SELECT site, secret, item_key FROM ' . self::t('vault_items') . ' WHERE id = ? AND user_id = ? AND deleted_at IS NULL'); $st->execute([$id, $uid]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That login isn\'t in the vault.');
        if (!hash_equals((string) $r['site'], $site)) { self::log($pdo, $uid, $id, 'ext_wrong_site', $ctx); throw new InvalidArgumentException('That login is for another site.'); }
        self::log($pdo, $uid, $id, 'revealed', $ctx);
        $what = trim(mb_substr(preg_replace('/[\r\n]+/', ' ', $how), 0, 90)) ?: 'A password was filled';
        self::alert($pdo, $me, $what, $what . ', by the browser extension' . self::where($ctx) . '.', $ctx, 'opened');
        return ['secret' => json_decode((string) $r['secret'], true), 'key' => json_decode((string) $r['item_key'], true)];
    }

    /** A login saved (or its password changed) from the extension. */
    public static function extSave(PDO $pdo, array $me, int $id, array $in, array $ctx): int
    {
        $uid = (int) $me['id'];
        $site = (string) ($in['site'] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/', $site)) throw new InvalidArgumentException('The login has no address.');
        $meta = self::sealed($in['meta'] ?? null, 'The name'); $secret = self::sealed($in['secret'] ?? null, 'The login'); $key = self::sealed($in['key'] ?? null, 'The item\'s key');
        if ($id > 0) {
            $st = $pdo->prepare('UPDATE ' . self::t('vault_items') . ' SET meta = ?, secret = ?, item_key = ?, updated_at = ? WHERE id = ? AND user_id = ? AND site = ? AND deleted_at IS NULL');
            $st->execute([$meta, $secret, $key, self::now(), $id, $uid, $site]);
            if (!$st->rowCount()) throw new InvalidArgumentException('That login isn\'t here.');
            self::log($pdo, $uid, $id, 'changed', $ctx);
        } else {
            $pdo->prepare('INSERT INTO ' . self::t('vault_items') . ' (user_id, site, meta, secret, item_key, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([$uid, $site, $meta, $secret, $key, self::now(), self::now()]);
            $id = (int) $pdo->lastInsertId();
            self::log($pdo, $uid, $id, 'added', $ctx);
        }
        self::alert($pdo, $me, 'A login was saved to your vault', 'A login was ' . ($in['how'] ?? 'saved') . ' from the browser extension' . self::where($ctx) . '.', $ctx, 'changes');
        return $id;
    }

    // ---- the authenticator app: an extra check for recovery and new devices (decisions/0156 §5). The server knows its
    // secret, so it never opens anything; it only stops someone with your sign-in from adding a device or using the words.

    private static function sk(): string
    {
        return sodium_crypto_generichash('tv-vault-app|' . (string) (getenv('APP_SECRET') ?: getenv('DB_PASSWORD') ?: ''), '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES);
    }

    private static function b32(string $bin): string
    {
        $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
        foreach (str_split($bin) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
        foreach (str_split($bits, 5) as $b) $out .= $a[bindec(str_pad($b, 5, '0'))];
        return $out;
    }

    /** A new key for the app, kept in the session until its first code proves it was added: [key, otpauth link]. */
    public static function appStart(PDO $pdo, array $me, bool $fresh): array
    {
        [$uid] = self::session((int) $me['id'], true);
        if ($fresh || empty($_SESSION['tv_vault_app'])) $_SESSION['tv_vault_app'] = self::b32(random_bytes(20));
        $k = (string) $_SESSION['tv_vault_app'];
        $label = 'Traversence Vault:' . (string) ($me['email'] ?? $uid);
        return [$k, 'otpauth://totp/' . rawurlencode($label) . '?' . http_build_query(['secret' => $k, 'issuer' => 'Traversence Vault', 'digits' => 6, 'period' => 30], '', '&', PHP_QUERY_RFC3986)];
    }

    public static function appAdd(PDO $pdo, array $me, string $code, array $ctx): void
    {
        [$uid] = self::session((int) $me['id'], true);
        require_once __DIR__ . '/StaffLogin.php';
        $k = (string) ($_SESSION['tv_vault_app'] ?? '');
        $step = StaffLogin::totpMatch($k, preg_replace('/\D/', '', $code), 0);
        if (!$step) throw new InvalidArgumentException('That code doesn\'t match. Check the app shows Traversence Vault, and type the code it shows now.');
        $n = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET totp = ?, totp_step = ? WHERE user_id = ?')->execute([base64_encode($n . sodium_crypto_secretbox($k, $n, self::sk())), $step, $uid]);
        unset($_SESSION['tv_vault_app']);
        self::log($pdo, $uid, null, 'app_added', $ctx);
        self::alert($pdo, $me, 'An authenticator app was added to your vault', 'An authenticator app was added to your Traversence vault' . self::where($ctx) . '. Its code is now needed to add a device or use your recovery words.', $ctx);
    }

    public static function appRemove(PDO $pdo, array $me, string $code, array $ctx): void
    {
        [$uid] = self::session((int) $me['id'], true);
        self::appCheck($pdo, $uid, $code, 'remove');
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET totp = NULL, totp_step = 0 WHERE user_id = ?')->execute([$uid]);
        self::log($pdo, $uid, null, 'app_removed', $ctx);
        self::alert($pdo, $me, 'The authenticator app was removed from your vault', 'The authenticator app was removed from your Traversence vault' . self::where($ctx) . '.', $ctx);
    }

    /** With an app on the vault, its current code (each used once); without one, nothing to check. */
    public static function appCheck(PDO $pdo, int $uid, string $code, string $for): void
    {
        $m = self::meta($pdo, $uid);
        if ((string) ($m['totp'] ?? '') === '') return;
        $raw = base64_decode((string) $m['totp'], true) ?: '';
        $k = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), self::sk());
        if ($k === false) throw new InvalidArgumentException('The vault\'s authenticator key couldn\'t be read (the site\'s secret changed). Ask our team at support@traversence.com.');
        require_once __DIR__ . '/StaffLogin.php';
        $step = StaffLogin::totpMatch($k, preg_replace('/\D/', '', $code), (int) $m['totp_step']);
        if (!$step) throw new InvalidArgumentException($code === '' ? 'Enter the code your authenticator app shows for Traversence Vault.' : 'That authenticator code doesn\'t match. Type the code the app shows now.');
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET totp_step = ? WHERE user_id = ?')->execute([$step, $uid]);
    }

    // ---- lock, log, alerts ---------------------------------------------------------------------------------------------

    /** Locks the vault (by its owner, the link in every alert, or by itself); every open session ends. */
    public static function lock(PDO $pdo, int $uid, string $why): void
    {
        self::ensure($pdo);
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET locked_at = COALESCE(locked_at, ?) WHERE user_id = ?')->execute([self::now(), $uid]);
        $pdo->prepare('UPDATE ' . self::t('vault_ext') . ' SET revoked_at = COALESCE(revoked_at, ?) WHERE user_id = ?')->execute([self::now(), $uid]);   // every extension disconnected
        if ((int) ($_SESSION['tv_vault']['uid'] ?? 0) === $uid) unset($_SESSION['tv_vault'], $_SESSION['tv_vault_tok']);
        self::log($pdo, $uid, null, 'locked:' . mb_substr($why, 0, 16), []);
    }

    /** The link in an alert: locks the vault it belongs to, no sign-in needed. */
    public static function lockByLink(PDO $pdo, string $token): bool
    {
        self::ensure($pdo);
        if (!preg_match('/^[a-f0-9]{48}$/', $token)) return false;
        $st = $pdo->prepare('SELECT user_id FROM ' . self::t('vault_meta') . ' WHERE lock_hash = ?'); $st->execute([hash('sha256', $token)]);
        $uid = (int) $st->fetchColumn();
        if (!$uid) return false;
        self::lock($pdo, $uid, 'link');
        return true;
    }

    /** Unlocks a locked vault: a fresh passkey check on one of its devices. Announced. */
    public static function release(PDO $pdo, array $me, array $ctx): void
    {
        [$uid] = self::session((int) $me['id'], true);
        $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET locked_at = NULL WHERE user_id = ?')->execute([$uid]);
        self::log($pdo, $uid, null, 'unlocked', $ctx);
        self::alert($pdo, $me, 'Your vault was unlocked', 'Your Traversence vault was unlocked' . self::where($ctx) . '.', $ctx, 'unlock');
    }

    /** The last things done in the vault, newest first (never what was in it): up to $limit (the page asks 10 more at a time). */
    public static function history(PDO $pdo, array $me, int $limit = 50): array
    {
        [$uid] = self::session((int) $me['id']);
        $limit = max(1, min(1000, $limit));
        $st = $pdo->prepare('SELECT item_id, action, device, ip, tz, at FROM ' . self::t('vault_log') . ' WHERE user_id = ? ORDER BY id DESC LIMIT ' . $limit); $st->execute([$uid]);
        return array_map(fn ($r) => ['item' => $r['item_id'] !== null ? (int) $r['item_id'] : null, 'action' => (string) $r['action'], 'device' => (string) $r['device'], 'ip' => (string) $r['ip'], 'tz' => (string) $r['tz'], 'at' => $r['at'] . 'Z'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    private static function log(PDO $pdo, int $uid, ?int $item, string $action, array $ctx): void
    {
        try {
            self::ensure($pdo);
            $pdo->prepare('INSERT INTO ' . self::t('vault_log') . ' (user_id, item_id, action, device, ip, tz, at, who) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$uid, $item, $action, mb_substr((string) ($ctx['device'] ?? ''), 0, 80), mb_substr((string) ($ctx['ip'] ?? ''), 0, 45), mb_substr((string) ($ctx['tz'] ?? ''), 0, 64), self::now(), mb_substr((string) ($ctx['who'] ?? ''), 0, 160)]);
        } catch (Throwable $e) { error_log('vault log: ' . $e->getMessage()); }
    }

    /** " (this computer, from 203.0.113.4, Nov 11 10:02 AM MST)" for an alert. */
    /** Who is acting, for the log and the summaries (the same words as the alerts). */
    public static function actor(array $me): string { return self::byWhom($me); }

    /** Who is acting: the account's name and the staff login signed in with ("Jason DeGraff, staff login JD01"). */
    private static function byWhom(array $me): string
    {
        $name = trim((string) ($me['display_name'] ?? $me['name'] ?? '')) ?: (string) ($me['email'] ?? 'your account');
        $sl = '';
        try { if (class_exists('Access')) { $s = Access::staff(); $sl = trim((string) ($s['staff_id'] ?? '')); } } catch (Throwable) {}
        if ($sl !== '' && str_contains($name, '(' . $sl . ')')) return $name . ', signed in with that staff login';
        return $name . ($sl !== '' ? ', staff login ' . $sl : ', signed in to the account');
    }

    private static function where(array $ctx): string
    {
        $tz = (string) ($ctx['tz'] ?? '');
        try { $z = new DateTimeZone($tz !== '' ? $tz : 'UTC'); } catch (Throwable) { $z = new DateTimeZone('UTC'); }
        $t = (new DateTime('now', $z))->format('M j, g:i A T');
        return ' (' . trim(implode(', ', array_filter([(string) ($ctx['device'] ?? ''), ($ctx['ip'] ?? '') !== '' ? 'from ' . $ctx['ip'] : '', $t]))) . ')';
    }

    /** An email to the owner about their vault, with the lock link. System email: free (CLAUDE.md). */
    private static function alert(PDO $pdo, array $me, string $subject, string $body, array $ctx, string $kind = ''): void
    {
        if ($kind !== '' && isset(self::NOTIFY[$kind])) {
            $f = self::notify($pdo, (int) $me['id'])[$kind];
            if ($f === 'first' && self::seenToday($pdo, (int) $me['id'], $kind, (string) ($ctx['tz'] ?? ''))) return;   // already emailed today
            if ($f !== 'each' && $f !== 'first') return;   // summarised later, or not emailed (still in the record)
        }
        $to = (string) ($me['email'] ?? '');
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return;
        $lock = '';
        try {
            $m = self::meta($pdo, (int) $me['id']);
            $tok = bin2hex(random_bytes(24));   // a fresh lock link each alert; the newest one works
            $pdo->prepare('UPDATE ' . self::t('vault_meta') . ' SET lock_hash = ? WHERE user_id = ?')->execute([hash('sha256', $tok), (int) $me['id']]);
            $lock = rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/api/vault-lock.php?t=' . $tok;   // outside /admin/: it must work without signing in
        } catch (Throwable) {}
        try {
            require_once __DIR__ . '/Mailer.php';
            Mailer::send($to, 'Vault: ' . $subject, $body . ($lock !== '' ? "\n\nNot you? Lock the vault now (no sign-in needed):\n" . $lock : '') . "\n\nTraversence");
        } catch (Throwable $e) { error_log('vault alert: ' . $e->getMessage()); }
    }
}
