<?php
// /api/vault-ext.php — the Traversence Vault browser extension's endpoint (decisions/0156 §8). Outside /admin/ on purpose:
// the admin side opens only for a signed-in staff login, and the extension uses no sign-in, only its own token. POST JSON {do, …}
// with the X-Vault-Token header the Vault page gave the extension when it was connected (no cookies, so no CSRF). All it
// hands out is sealed: the extension opens it in the browser with the vault key it holds in memory. A password is handed
// over only for the site it was saved for (the blind index of the page asking), and each one is logged and emailed.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Vault.php';

header('Cache-Control: no-store');
Response::requireMethod('POST');
// No cookies are used here, so there's no session for a form token to protect; instead only the extension itself may
// call (the browser sets Origin to the extension's own address, which a web page can't fake).
$ext = 'chrome-extension://' . (getenv('VAULT_EXTENSION_ID') ?: 'leflbllgieloanpllabjmbjimemcjicj');
if (!hash_equals($ext, (string) ($_SERVER['HTTP_ORIGIN'] ?? ''))) Response::error('Only the Traversence Vault extension can use this.', 403, 'forbidden');
$pdo = Database::connection();
$b = Response::jsonBody();
$do = (string) ($b['do'] ?? '');
$ctx = ['device' => mb_substr('Extension: ' . trim((string) ($b['device'] ?? 'browser')), 0, 80), 'ip' => (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
        'tz' => preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($b['tz'] ?? '')) ? (string) $b['tz'] : ''];
try {
    [$me, $cx] = Vault::extAuth($pdo, (string) ($_SERVER['HTTP_X_VAULT_TOKEN'] ?? ''));
    $ctx['who'] = trim((string) ($me['display_name'] ?? '')) . ' (the extension)';   // who connected it: kept with each entry for the summaries
    $uid = (int) $me['id'];
    switch ($do) {
        case 'ping':   Response::success(['email' => (string) $me['email']]);
        case 'bye':    $pdo->prepare('UPDATE ' . Database::t('vault_ext') . ' SET revoked_at = ? WHERE id = ?')->execute([gmdate('Y-m-d H:i:s'), $cx]); Response::success(['message' => 'Disconnected.']);
        case 'items':  Response::success(['items' => Vault::extItems($pdo, $uid)]);
        case 'reveal': Response::success(Vault::extReveal($pdo, $me, (int) ($b['id'] ?? 0), (string) ($b['site'] ?? ''), (string) ($b['how'] ?? ''), $ctx));
        case 'save':   Response::success(['id' => Vault::extSave($pdo, $me, (int) ($b['id'] ?? 0), $b, $ctx)]);
    }
    Response::error('Not a vault action.', 400, 'bad_request');
} catch (InvalidArgumentException $x) { Response::error($x->getMessage(), 401, 'vault_ext'); }
catch (Throwable $x) { error_log('vault-ext ' . $do . ': ' . $x->getMessage()); Response::error('The vault couldn\'t do that just now. Try again.', 500, 'vault_error'); }
