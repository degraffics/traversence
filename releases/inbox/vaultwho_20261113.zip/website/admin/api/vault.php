<?php
// /admin/api/vault.php — the Vault (decisions/0156). POST JSON {do, …} with X-CSRF-Token, for staff who may use it
// (owners and executives first). Everything sent here is already sealed in the browser; the server checks passkeys, keeps
// the sealed data, hands back one sealed item at a time and tells the owner. GET ?lock=<token> is the "Lock the vault" link
// in every vault email: it works without signing in, and only locks.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/admin/Access.php';
require_once __DIR__ . '/../../../app/lib/Vault.php';

$pdo = Database::connection();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && isset($_GET['lock'])) {
    $ok = Vault::lockByLink($pdo, (string) $_GET['lock']);
    header('Content-Type: text/html; charset=utf-8');
    header('X-Frame-Options: DENY');
    $msg = $ok ? '<b>Your vault is locked.</b> Nothing can be opened from it until you unlock it with your passkey on the Vault page.'
               : 'That link has been replaced by a newer one (each vault email carries a fresh link). Use the link in your latest vault email, or sign in and press <b>Lock the vault</b>. Need help? Email <a href="mailto:support@traversence.com">support@traversence.com</a>.';
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vault</title>'
        . '<body style="font:16px/1.5 system-ui,sans-serif;background:#FFFBF2;color:#1F2937;margin:0;padding:2rem 1rem"><div style="max-width:30rem;margin:auto;background:#fff;border:1px solid #E7D9C4;border-radius:.5rem;padding:1.25rem">'
        . '<p style="margin:0 0 .75rem;color:#92400E;font-weight:700">Traversence Vault</p><p data-tv-status="' . ($ok ? 'ok' : 'info') . '">' . $msg . '</p>'
        . '<p><a href="/admin/config/vault" style="color:#92400E">Open the Vault page</a></p></div></body>';
    exit;
}

// GET ?extension=1: the browser extension's zip, for staff who may use the vault (kept in app/, never served directly).
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && isset($_GET['extension'])) {
    $u = Auth::currentUser();
    [$can] = $u && !empty($u['is_admin']) ? Access::can('config.vault', ['min' => 'executive', 'depts' => []]) : [false];
    $zip = __DIR__ . '/../../../app/data/vault-extension.zip';
    if (!$can || !is_file($zip)) {
        header('Content-Type: text/html; charset=utf-8', true, $can ? 404 : 403);
        echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vault extension</title>'
            . '<body style="font:16px/1.5 system-ui,sans-serif;background:#FFFBF2;color:#1F2937;margin:0;padding:2rem 1rem"><div style="max-width:30rem;margin:auto;background:#fff;border:1px solid #E7D9C4;border-radius:.5rem;padding:1.25rem">'
            . '<p style="margin:0 0 .75rem;color:#92400E;font-weight:700">Traversence Vault extension</p><p>'
            . ($can ? 'The extension file isn\'t on the server yet.' : 'Sign in with a staff account that may use the vault, then try again.')
            . ' Need it now? Ask our team at <a href="mailto:support@traversence.com">support@traversence.com</a>.</p><p><a href="/admin/config/vault" style="color:#92400E">Back to the Vault page</a></p></div></body>';
        exit;
    }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="traversence-vault.zip"');
    header('Content-Length: ' . filesize($zip));
    header('Cache-Control: no-store');
    readfile($zip);
    exit;
}

Response::requireMethod('POST');
Response::requireCsrf();
$me = Auth::currentUser();
if (!$me || empty($me['is_admin'])) Response::error('Staff only for now: the vault for members and businesses comes later, with its own terms.', 403, 'forbidden');
[$ok, $why] = Access::can('config.vault', ['min' => 'executive', 'depts' => []]);
if (!$ok) Response::error($why . '. The vault is for owners and executives first.', 403, 'forbidden');

$me = Vault::who($pdo, $me);   // a staff login's real work email and name, not its placeholder address
$b = Response::jsonBody();
$do = (string) ($b['do'] ?? '');
$ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
$device = trim((string) ($b['device'] ?? '')) ?: (preg_match('/Edg\//', $ua) ? 'Edge' : (preg_match('/Chrome\//', $ua) ? 'Chrome' : (preg_match('/Firefox\//', $ua) ? 'Firefox' : (preg_match('/Safari\//', $ua) ? 'Safari' : 'A browser'))))
    . (preg_match('/Windows/', $ua) ? ' on Windows' : (preg_match('/Mac OS X/', $ua) && !preg_match('/iPhone|iPad/', $ua) ? ' on a Mac' : (preg_match('/iPhone|iPad/', $ua) ? ' on an iPhone' : (preg_match('/Android/', $ua) ? ' on Android' : ''))));
$ctx = ['device' => mb_substr($device, 0, 80), 'ip' => (string) ($_SERVER['REMOTE_ADDR'] ?? ''), 'tz' => preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($b['tz'] ?? '')) ? (string) $b['tz'] : ''];
$ctx['who'] = Vault::actor($me);   // who did it, kept with each entry for the emailed summaries
$uid = (int) $me['id'];

try {
    switch ($do) {
        case 'state':        Response::success(['state' => Vault::state($pdo, $uid), 'open' => (int) ($_SESSION['tv_vault']['uid'] ?? 0) === $uid]);
        case 'add_options':  Response::success(['options' => Vault::createOptions($pdo, $me)]);
        case 'add':
            // a first passkey needs no other; a further one needs the vault open on a device it already knows
            // a new computer without the vault open: the code we just emailed (it still can't open anything without
            // the recovery words, or a key from a device that can)
            $has = Vault::state($pdo, $uid)['devices'];
            if ($has) {
                $open = false; try { Vault::session($uid, true); $open = true; } catch (InvalidArgumentException $x) {}
                if (!$open) {
                    $c = $_SESSION['tv_vault_code'] ?? null;
                    if (!$c || $c['exp'] < time() || ++$_SESSION['tv_vault_code']['tries'] > 5 || !hash_equals((string) $c['h'], hash('sha256', preg_replace('/\D/', '', (string) ($b['code'] ?? '')))))
                        Response::error('Enter the code we emailed you (or send a new one).', 422, 'vault_code');
                    unset($_SESSION['tv_vault_code']);
                    Vault::appCheck($pdo, $uid, (string) ($b['app'] ?? ''), 'device');
                }
            }
            $id = Vault::addPasskey($pdo, $me, (array) ($b['credential'] ?? []), (string) ($b['label'] ?? ''), !empty($b['prf']), $ctx);
            Response::success(['cred' => $id, 'first' => !$has]);
        case 'add_code':
            $code = (string) random_int(100000, 999999);
            $_SESSION['tv_vault_code'] = ['h' => hash('sha256', $code), 'exp' => time() + 600, 'tries' => 0];
            require_once __DIR__ . '/../../../app/lib/Mailer.php';
            Mailer::sendCode((string) $me['email'], $code, 'add a device to your vault', "Your code to add a device to your Traversence vault is $code. It works for 10 minutes.\n\nIf this wasn't you, sign in and lock your vault: someone has your sign-in.");
            Response::success(['message' => 'We sent a code to the email on your account.']);   // never the address (Jason, 2026-11-12)
        case 'unlock_code':
            $code = Vault::unlockCode($uid);
            require_once __DIR__ . '/../../../app/lib/Mailer.php';
            Mailer::sendCode((string) $me['email'], $code, 'open your vault', "Your code to open your Traversence vault is $code. It works for 10 minutes, and the vault still needs your device's PIN, fingerprint or face.\n\nIf this wasn't you, sign in and lock your vault: someone has your sign-in.");
            Response::success(['message' => 'We sent a code to the email on your account. It works for 10 minutes.']);
        case 'unlock_step':  Vault::step1($pdo, $uid, (string) ($b['how'] ?? ''), (string) ($b['code'] ?? '')); Response::success(['ok' => true]);
        case 'set_pin_slot': Vault::setPinSlot($pdo, $me, (array) ($b['slot'] ?? []), $ctx); Response::success(['message' => 'PIN unlock is on for this device.']);
        case 'pin_off':      Vault::pinOff($pdo, $me, (int) ($b['cred'] ?? 0), $ctx); Response::success(['message' => 'PIN unlock is off for that device.']);
        case 'opened':       Vault::opened($pdo, $me, (string) ($b['how'] ?? ''), $ctx); Response::success(['ok' => true]);
        case 'get_options':  Response::success(['options' => Vault::getOptions($pdo, $uid)]);
        case 'check':        Response::success(Vault::check($pdo, $uid, (array) ($b['credential'] ?? []), $ctx));
        case 'setup':        Vault::setup($pdo, $me, (array) ($b['slot'] ?? []), (array) ($b['recovery'] ?? []), $ctx); Response::success(['message' => 'Your vault is ready.']);
        case 'set_slot':     Vault::setSlot($pdo, $me, (array) ($b['slot'] ?? []), $ctx); Response::success(['message' => 'This device can open the vault.']);
        case 'set_slot_for': Vault::setSlotFor($pdo, $me, (int) ($b['cred'] ?? 0), (array) ($b['slot'] ?? []), $ctx); Response::success(['message' => 'That device can open the vault now.']);
        case 'remove_device': Vault::removeDevice($pdo, $me, (int) ($b['cred'] ?? 0), $ctx); Response::success(['message' => 'Device removed.']);
        case 'recovery_key': Response::success(['recovery' => Vault::recoveryKey($pdo, $me, $ctx, (string) ($b['app'] ?? ''))]);
        case 'app_start':
            [$key, $uri] = Vault::appStart($pdo, $me, !empty($b['fresh']));
            require_once __DIR__ . '/../../../app/lib/Qr.php';
            Response::success(['key' => trim(chunk_split($key, 4, ' ')), 'qr' => Qr::svg($uri, ['ecc' => 'M', 'dark' => '#000000', 'light' => '#FFFFFF'])]);
        case 'app_add':      Vault::appAdd($pdo, $me, (string) ($b['code'] ?? ''), $ctx); Response::success(['message' => 'Authenticator app added.']);
        case 'app_remove':   Vault::appRemove($pdo, $me, (string) ($b['code'] ?? ''), $ctx); Response::success(['message' => 'Authenticator app removed.']);
        case 'new_recovery': Vault::newRecovery($pdo, $me, (array) ($b['recovery'] ?? []), $ctx); Response::success(['message' => 'New recovery words saved; the old ones no longer work.']);
        case 'items':        Response::success(['items' => Vault::items($pdo, $me)]);
        case 'save':         Response::success(['id' => Vault::saveItem($pdo, $me, (int) ($b['id'] ?? 0), $b, $ctx), 'message' => 'Saved.']);
        case 'delete':       Vault::deleteItem($pdo, $me, (int) ($b['id'] ?? 0), $ctx); Response::success(['message' => 'Deleted.']);
        case 'delete_many':  $n = Vault::deleteMany($pdo, $me, (array) ($b['ids'] ?? []), $ctx); Response::success(['deleted' => $n, 'message' => $n . ' login' . ($n === 1 ? '' : 's') . ' deleted.']);
        case 'token':        Response::success(['token' => Vault::token($pdo, $me, (int) ($b['id'] ?? 0))]);
        case 'reveal':       Response::success(Vault::reveal($pdo, $me, (int) ($b['id'] ?? 0), (string) ($b['token'] ?? ''), (string) ($b['how'] ?? ''), $ctx));
        case 'lock':         Vault::lock($pdo, $uid, 'owner'); Response::success(['message' => 'The vault is locked.']);
        case 'release':      Vault::release($pdo, $me, $ctx); Response::success(['message' => 'The vault is unlocked.']);
        case 'ext_pair':     Response::success(Vault::extPair($pdo, $me, (string) ($b['label'] ?? ''), $ctx, (string) ($b['install'] ?? '')) + ['api' => '/api/vault-ext.php', 'email' => (string) $me['email']]);
        case 'ext_remove':   Vault::extRemove($pdo, $me, (int) ($b['id'] ?? 0), $ctx); Response::success(['message' => 'Extension disconnected.']);
        case 'history':      Response::success(['log' => Vault::history($pdo, $me, (int) ($b['limit'] ?? 50))]);
        case 'notify':       Vault::session((int) $me['id']); Response::success(['notify' => Vault::notify($pdo, (int) $me['id']), 'kinds' => Vault::NOTIFY, 'freq' => Vault::FREQ, 'always' => Vault::NOTIFY_ALWAYS]);
        case 'notify_set':   Response::success(['notify' => Vault::setNotify($pdo, $me, is_array($b['notify'] ?? null) ? $b['notify'] : [], $ctx), 'message' => 'Saved. We emailed you that it changed.']);
        case 'ping':         Vault::session($uid); Response::success(['ok' => true]);   // still in use (the page's "Keep it open" and activity)
        case 'close':        unset($_SESSION['tv_vault'], $_SESSION['tv_vault_tok']); Response::success(['message' => 'Closed.']);
    }
    Response::error('Not a vault action.', 400, 'bad_request');
} catch (InvalidArgumentException $x) {
    $m = $x->getMessage();   // the page acts on these two: check the passkey again, or show Unlock
    Response::error($m, 422, str_starts_with($m, 'Check it\'s you again') ? 'vault_fresh' : (str_starts_with($m, 'Unlock the vault first') || str_contains($m, 'locked itself after 10') ? 'vault_closed' : 'vault'));
}
catch (Throwable $x) { error_log('vault ' . $do . ': ' . $x->getMessage()); Response::error('The vault couldn\'t do that just now. Try again, or ask our team at support@traversence.com.', 500, 'vault_error'); }
