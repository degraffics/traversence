<?php
// gallery/index.php — your gallery (decisions/0126): every photo and video you keep, newest first by when it was taken,
// in years and months (six a month, then View all), and your albums. Upload photos and videos, pick several to put in an
// album or delete. ?tab=albums; ?pick=<album> picks photos to add to that album. ?cat=<catalog>: one catalog
// (GalleryCatalogs: uploaded here, journeys, profile, listing, Marketplace, Storefront; and Orders: artwork from their orders
// released to them, decisions/0101). ?tab=docs: every document, with
// where it's been used (GalleryUses). ?tab=stock: the stock library
// (decisions/0143), kept apart from what's yours: found here and used only where a photo illustrates.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/gallery-ui.php';
require_once __DIR__ . '/../../app/lib/Gallery.php';
require_once __DIR__ . '/../../app/lib/MemberProfile.php';

$uid = Auth::currentUserId();
if ($uid === null) { header('Location: /login.php?next=' . rawurlencode('/gallery/'), true, 302); exit; }
$pdo = Database::connection();
$b = (int) ($_GET['b'] ?? 0);   // a business's gallery (phase 3), for its team
if ($b && !Gallery::canManage($pdo, $uid, 'businesses', (string) $b)) {
    http_response_code(403); tv_page_start('Gallery', ['section' => 'member']);
    echo '<div class="max-w-xl mx-auto py-10 text-center"><h1 class="font-serif font-bold text-2xl">You can&rsquo;t manage this gallery</h1><p class="mt-2 text-sm text-[color:var(--tv-meta)]">A business&rsquo;s gallery is for its team members who can edit its Catalog &amp; content. Ask its owner.</p></div>';
    tv_page_end(); exit;
}
[$okind, $oref] = $b ? ['businesses', (string) $b] : ['members', (string) $uid];
$qs = $b ? '&b=' . $b : '';
if ($b) Gallery::syncBusiness($pdo, $b); else Gallery::sync($pdo, $uid);   // photos already kept elsewhere join in where they are
$tab = in_array($_GET['tab'] ?? '', ['albums', 'stock', 'docs'], true) ? (string) $_GET['tab'] : 'photos';
$pickFor = (int) ($_GET['pick'] ?? 0);
$pickAlbum = $pickFor ? Gallery::album($pdo, $pickFor) : null;
if ($pickAlbum && !Gallery::canContribute($pdo, $pickAlbum, $uid)) $pickAlbum = null;   // the owner, or someone who can contribute
if ($pickAlbum) $tab = 'photos';
$views = Gallery::mark($pdo, array_map(fn ($it) => Gallery::view($it), Gallery::items($pdo, $okind, $oref)), $uid);
// its catalogs: each photo by where it belongs (uploaded here, journeys, profile, listing, Marketplace, Storefront)
require_once __DIR__ . '/../../app/lib/GalleryCatalogs.php';
$cats = GalleryCatalogs::of($pdo, $okind, $oref, $views);
$catList = GalleryCatalogs::counts($cats, $okind);
// the Orders catalog: artwork from their orders with us that's been released to them (decisions/0101, RecordFiles::clientArt)
require_once __DIR__ . '/../../app/lib/RecordFiles.php';
$art = RecordFiles::clientArt($pdo, $okind, $oref);
if ($art) $catList[] = ['orders', 'Orders', 'Artwork from your orders with us, released to you', count($art)];
$cat = (string) ($_GET['cat'] ?? '');
if (!isset(GalleryCatalogs::ALL[$cat]) && $cat !== 'orders') $cat = '';
$allN = count($views);
// where each has been used (GalleryUses): shown on the photo, and beside each document
require_once __DIR__ . '/../../app/lib/GalleryUses.php';
require_once __DIR__ . '/../../app/lib/Uploads.php';   // its size wording
$docs = GalleryCatalogs::documents($pdo, $okind, $oref);
$uses = GalleryUses::forItems($pdo, array_merge(array_column($views, 'id'), array_column($docs, 'id')));
foreach ($views as &$uv) { $uv['used'] = GalleryUses::summary($uses[(int) $uv['id']] ?? [], 3); } unset($uv);
if ($cat === 'orders') $views = [];
elseif ($cat !== '') $views = array_values(array_filter($views, fn ($v) => ($cats[(int) $v['id']] ?? '') === $cat));
$albums = Gallery::albums($pdo, $okind, $oref, true);
$shared = $b ? [] : Gallery::sharedWith($pdo, $uid);   // albums you were invited to (phase 2)
$bizName = $b ? Gallery::ownerName($pdo, 'businesses', $b) : '';
$p = MemberProfile::get($pdo, $uid);
$me = ['name' => (string) ($p['name'] ?? ''), 'avatar' => (string) ($p['avatar'] ?? '')];
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$nPhotos = count(array_filter($views, fn ($v) => $v['kind'] === 'photo')); $nVideos = count($views) - $nPhotos;

tv_page_start($b ? $bizName . ': gallery' : 'Your gallery', ['description' => 'Photos and videos, and albums.', 'section' => 'member', 'active' => 'gallery',
    'crumbs' => $b ? [['Business', '/business/' . $b], ['Gallery']] : [['Dashboard', '/user/dashboard.php'], ['Gallery']]]);
echo tv_gallery_css();
$cam = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
?>
<div class="gl" data-tab="<?= $tab ?>">
  <div class="gl-h">
    <h1><?= $pickAlbum ? 'Add to ' . tv_e($pickAlbum['title']) : ($b ? tv_e($bizName) . ' gallery' : 'Your gallery') ?></h1>
    <?php if (!$pickAlbum): ?>
    <button type="button" class="gl-b go" data-gl="upload"><?= $cam ?>Upload</button>
    <?php if ($tab === 'photos' && $views): ?><button type="button" class="gl-b" data-gl="select" aria-pressed="false">Select</button><?php endif; ?>
    <?php if ($tab !== 'stock'): ?><button type="button" class="gl-b" data-gl="new-album">New album</button><?php endif; ?>
    <?php endif; ?>
    <input type="file" id="gl-file" accept="image/*,video/*" multiple hidden data-art="upload">
  </div>
  <?php if (!$pickAlbum): ?>
  <style>@media (max-width:767px){.gl-tabs{flex-wrap:wrap;gap:.3rem}.gl-tabs a{padding:.4rem .75rem}}</style>
  <nav class="gl-tabs" aria-label="Gallery">
    <a href="/gallery/<?= $b ? '?b=' . $b : '' ?>"<?= $tab === 'photos' ? ' aria-current="page"' : '' ?>>Photos &amp; videos <small><?= $allN ?></small></a>
    <a href="/gallery/?tab=docs<?= $qs ?>"<?= $tab === 'docs' ? ' aria-current="page"' : '' ?>>Documents <small><?= count($docs) ?></small></a>
    <a href="/gallery/?tab=albums<?= $qs ?>"<?= $tab === 'albums' ? ' aria-current="page"' : '' ?>>Albums <small><?= count($albums) ?></small></a>
    <a href="/gallery/?tab=stock<?= $qs ?>"<?= $tab === 'stock' ? ' aria-current="page"' : '' ?> title="Photos no one on Traversence took, for illustration only">Stock photos</a>
  </nav>
  <?php else: ?>
  <p class="text-sm text-[color:var(--tv-meta)] mb-3">Tap the photos to add, then <b>Add to album</b>.</p>
  <?php endif; ?>
  <div class="gl-prog" hidden role="status"><b></b><div><span></span></div></div>
  <?php if ($tab === 'photos'): ?>
    <?php if ($catList && !$pickAlbum): $cn = $cat === 'orders' ? 'Orders' : ($cat !== '' ? GalleryCatalogs::ALL[$cat][0] : 'All catalogs'); ?>
    <details class="gl-cat"><summary><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4 2v-8z"/></svg><span>Catalog: <b><?= tv_e($cn) ?></b></span> <small><?= $cat === 'orders' ? count($art) : count($views) ?></small> ▾</summary>
      <div class="gl-catl" role="menu">
        <a role="menuitem" href="/gallery/<?= $b ? '?b=' . $b : '' ?>"<?= $cat === '' ? ' aria-current="true"' : '' ?>><span>All catalogs</span><i><?= $allN ?></i></a>
        <?php foreach ($catList as [$ck, $cname, $cabout, $cnum]): ?><a role="menuitem" href="/gallery/?cat=<?= $ck . $qs ?>"<?= $cat === $ck ? ' aria-current="true"' : '' ?> title="<?= tv_e($cabout) ?>"><span><?= tv_e($cname) ?></span><i><?= $cnum ?></i></a><?php endforeach; ?>
      </div>
    </details>
    <style>.gl-cat{position:relative;display:inline-block;margin:0 0 .8rem}.gl-cat summary{list-style:none;display:inline-flex;align-items:center;gap:.4rem;border:1.5px solid var(--tv-line-strong);background:var(--tv-card-a);color:var(--tv-meta);border-radius:999px;padding:.4rem .85rem;font:600 .88rem system-ui,sans-serif;cursor:pointer;min-height:2.4rem}
      .gl-cat summary::-webkit-details-marker{display:none}.gl-cat summary svg{width:1rem;height:1rem;color:var(--tv-icon,#B45309)}.gl-cat summary small{color:var(--tv-meta)}.gl-cat[open] summary{border-color:var(--tv-icon,#B45309)}
      .gl-catl{position:absolute;z-index:20;left:0;top:calc(100% + .3rem);min-width:15rem;background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:.7rem;box-shadow:0 10px 24px rgba(62,43,31,.2);padding:.3rem;display:grid}
      .gl-catl a{display:flex;justify-content:space-between;gap:1rem;padding:.5rem .7rem;border-radius:.5rem;color:var(--tv-ink);text-decoration:none;font-size:.9rem}.gl-catl a:hover{background:var(--tv-canvas)}.gl-catl a[aria-current="true"]{background:var(--tv-sage);color:var(--tv-umber)}.gl-catl i{font-style:normal;color:var(--tv-meta)}</style>
    <?php endif; ?>
    <?php if ($cat === 'orders'): ?>
    <p class="gl-dn">Artwork from your orders with us that&rsquo;s been released to you: the approved proof, and the print-ready files once the order is paid in full. It stays with each order; here you can see it, download it, use it anywhere you add a photo or a file, or <a class="underline" href="/user/orders.php#art">ask to reorder</a>.</p>
    <div class="gl-docs">
      <?php foreach ($art as $x): ?>
        <div class="gl-doc tv-bleed"><?php if ($x['image']): ?><img class="gl-dx" src="<?= tv_e($x['url']) ?>" alt="<?= tv_e($x['piece']) ?>" loading="lazy" style="object-fit:cover;padding:0"><?php else: ?><span class="gl-dx"><?= tv_e($x['ext']) ?></span><?php endif; ?><div class="gl-dt">
          <a class="gl-dnm" href="<?= tv_e($x['download']) ?>"><?= tv_e($x['name']) ?></a>
          <small><?= tv_e($x['what']) ?></small>
          <small><a class="underline" href="/user/orders.php#art">Your artwork and reorders</a></small>
        </div></div>
      <?php endforeach; ?></div>
    <style>.gl-dn{font-size:.9rem;color:var(--tv-meta);max-width:52rem;margin:0 0 .8rem}.gl-docs{display:grid;gap:.5rem}.gl-doc{display:flex;gap:.75rem;align-items:flex-start;background:var(--tv-card-a);border:1px solid var(--tv-line);border-radius:.7rem;padding:.7rem .8rem}
      .gl-dx{flex:none;width:3.2rem;height:3.2rem;border-radius:.5rem;background:var(--tv-canvas);border:1.5px solid var(--tv-line-strong);color:var(--tv-link);font:700 .82rem var(--tv-font-head,Georgia,serif);display:flex;align-items:center;justify-content:center}
      .gl-dt{display:grid;gap:.15rem;min-width:0}.gl-dnm{color:var(--tv-link);font-weight:700;text-decoration:underline;overflow-wrap:anywhere}.gl-dt small{color:var(--tv-meta);font-size:.8rem}.gl-dt small a{color:var(--tv-link)}
      @media (max-width:767px){.gl-docs{gap:3px}.gl-doc{border-radius:.5rem}}</style>
    <?php elseif ($views): echo tv_gallery_timeline($views);
    else: ?><div class="gl-empty tv-bleed"><p class="font-serif font-bold text-lg">Nothing here yet</p><p class="text-sm mt-1">Upload photos and videos, or they&rsquo;ll appear here as you add them to journeys and your profile.</p></div><?php endif; ?>
    <p class="text-xs text-[color:var(--tv-meta)] mt-6"><?= $nPhotos ?> photo<?= $nPhotos === 1 ? '' : 's' ?><?= $nVideos ? ', ' . $nVideos . ' video' . ($nVideos === 1 ? '' : 's') : '' ?>. What you upload here is private until you put it in an album you share.<?= $b ? ' The business&rsquo;s gallery counts toward its plan&rsquo;s storage. Public albums show on its listing page.' : ' Photos from journeys and your profile keep the settings they have there.' ?></p>
  <?php elseif ($tab === 'docs'): $dq = mb_strtolower(trim((string) ($_GET['q'] ?? ''))); $dl = $dq === '' ? $docs : array_values(array_filter($docs, fn ($d) => str_contains(mb_strtolower($d['name']), $dq))); ?>
    <p class="gl-dn">Every file you&rsquo;ve added anywhere on Traversence (proofs, artwork, quotes, brand files) is kept here, with where it&rsquo;s been used. Choose one from any page&rsquo;s file button, under <b>Your gallery</b>.</p>
    <div class="gl-dbar"><form method="get" action="/gallery/" role="search"><input type="hidden" name="tab" value="docs"><?= $b ? '<input type="hidden" name="b" value="' . $b . '">' : '' ?><input type="search" name="q" value="<?= tv_e($dq) ?>" placeholder="Search your documents" aria-label="Search your documents"><button class="gl-b">Search</button></form>
      <label class="gl-b go">Add documents<input type="file" id="gl-docs" multiple hidden data-art="upload"></label></div>
    <?php if (!$dl): ?><div class="gl-empty tv-bleed"><p class="font-serif font-bold text-lg"><?= $dq !== '' ? 'Nothing matches' : 'No documents yet' ?></p><p class="text-sm mt-1">Files you add to orders, quotes or Brand &amp; documents albums show here.</p></div>
    <?php else: ?><div class="gl-docs">
      <?php foreach ($dl as $d): $du = $uses[$d['id']] ?? []; ?>
        <div class="gl-doc tv-bleed"><span class="gl-dx"><?= tv_e(strtoupper($d['ext'])) ?></span><div class="gl-dt">
          <a class="gl-dnm" href="/gallery/m.php?i=<?= (int) $d['id'] ?>&amp;s=orig"><?= tv_e($d['name']) ?></a>
          <small><?= tv_e(Uploads::size($d['bytes'])) ?><?= $d['version'] > 1 ? ' · version ' . (int) $d['version'] : '' ?> · <?= tv_e(date('M j, Y', strtotime($d['when']))) ?><?= $d['albums'] !== '' ? ' · in ' . tv_e($d['albums']) : '' ?></small>
          <?php if ($du): ?><small class="gl-du">Used in <?= implode(', ', array_map(fn ($u) => $u[1] !== '' ? '<a href="' . tv_e($u[1]) . '">' . tv_e($u[0]) . '</a>' : tv_e($u[0]), array_slice($du, 0, 6))) ?><?= count($du) > 6 ? ' and ' . (count($du) - 6) . ' more' : '' ?></small><?php else: ?><small class="gl-du none">Not used anywhere yet</small><?php endif; ?>
        </div></div>
      <?php endforeach; ?></div><?php endif; ?>
    <style>.gl-dn{font-size:.9rem;color:var(--tv-meta);max-width:52rem;margin:0 0 .8rem}.gl-dbar{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin:0 0 1rem}.gl-dbar form{display:flex;gap:.4rem;flex:1 1 16rem}
      .gl-dbar input[type=search]{flex:1;min-width:0;border:1.5px solid var(--tv-line-strong);border-radius:999px;padding:.5rem .9rem;font-size:1rem;background:var(--tv-field)}
      .gl-docs{display:grid;gap:.5rem}.gl-doc{display:flex;gap:.75rem;align-items:flex-start;background:var(--tv-card-a);border:1px solid var(--tv-line);border-radius:.7rem;padding:.7rem .8rem}
      .gl-dx{flex:none;width:3.2rem;height:3.2rem;border-radius:.5rem;background:var(--tv-canvas);border:1.5px solid var(--tv-line-strong);color:var(--tv-link);font:700 .82rem var(--tv-font-head,Georgia,serif);display:flex;align-items:center;justify-content:center}
      .gl-dt{display:grid;gap:.15rem;min-width:0}.gl-dnm{color:var(--tv-link);font-weight:700;text-decoration:underline;overflow-wrap:anywhere}.gl-dt small{color:var(--tv-meta);font-size:.8rem}.gl-du{color:color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink))!important}.gl-du.none{color:var(--tv-meta)!important}.gl-du a{color:color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink));text-decoration:underline}
      @media (max-width:767px){.gl-docs{gap:3px}.gl-doc{border-radius:.5rem}}</style>
    <script src="/js/tv-upload.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-upload.js') ?>"></script>
    <script>(function () {   // new documents go into the Documents album, then the list shows them
      var inp = document.getElementById('gl-docs'); if (!inp || !window.TvUpload) return;
      inp.addEventListener('change', function () {
        var fs = [].slice.call(inp.files || []); if (!fs.length) return; var lab = inp.closest('label');
        if (window.TvAsk) TvAsk.busy(lab, true);
        var tok = <?= json_encode($csrf) ?>;
        fetch('/api/stock.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': tok }, body: JSON.stringify({ action: 'docs_album', b: <?= (int) $b ?> }) })
          .then(function (r) { return r.json(); }).then(function (d) {
            if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.');
            return TvUpload.send(fs, { target: 'gallery_file', ctx: { album: d.album }, el: lab, csrf: tok });
          }).then(function (r) { if (window.TvAsk) TvAsk.busy(lab, false); TvUpload.reloadHere(TvUpload.summary(r), lab); },
            function (x) { if (window.TvAsk) { TvAsk.busy(lab, false); if (x && x.message !== 'cancelled') TvAsk.say(x.message, { anchor: lab, bad: true }); } inp.value = ''; });
      });
    })();</script>
  <?php elseif ($tab === 'stock'): require_once __DIR__ . '/../../app/ui/stock-ui.php'; ?>
    <?= tv_stock_gallery_tab($pdo, (int) $uid, $b, mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 80)) ?>
    <script src="/js/tv-stock.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-stock.js') ?>" defer></script>
  <?php else: ?>
    <div class="gl-albums tv-bleed">
      <a class="gl-al new" href="#" data-gl="new-album">+ New album</a>
      <?php foreach ($albums as $a) echo tv_gallery_album_card($a, '/gallery/album.php?a=' . (int) $a['id'], true); ?>
    </div>
    <?php if ($shared): ?>
    <h2 class="gl-yr">Shared with you</h2>
    <div class="gl-albums tv-bleed"><?php foreach ($shared as $a) echo tv_gallery_album_card($a, '/gallery/album.php?a=' . (int) $a['id'], false); ?></div>
    <?php endif; ?>
  <?php endif; ?>
  <div class="gl-bar" hidden role="toolbar" aria-label="Selected">
    <b data-n></b>
    <?php if ($pickAlbum): ?><button type="button" class="gl-b go" data-do="add-here" data-need>Add to album</button><a class="gl-b" href="/gallery/album.php?a=<?= (int) $pickAlbum['id'] ?>">Cancel</a>
    <?php else: ?><button type="button" class="gl-b" data-do="add" data-need>Add to album</button><button type="button" class="gl-b danger" data-do="delete" data-need>Delete</button><button type="button" class="gl-b" data-do="cancel">Cancel</button><?php endif; ?>
  </div>
</div>
<script>window.TV_GAL = <?= json_encode(['b' => $b, 'items' => $views, 'albums' => array_map(fn ($a) => ['id' => (int) $a['id'], 'title' => $a['title'], 'n' => (int) $a['n']], $albums), 'album' => null, 'own' => true, 'csrf' => $csrf, 'me' => $me, 'owner' => $b ? ['name' => $bizName] : null, 'pickFor' => $pickAlbum ? (int) $pickAlbum['id'] : 0], JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES) ?>;</script>
<script src="/js/photo-viewer.js?v=<?= (int) @filemtime(__DIR__ . '/../js/photo-viewer.js') ?>"></script>
<script src="/js/gallery.js?v=<?= (int) @filemtime(__DIR__ . '/../js/gallery.js') ?>"></script>
<?php tv_page_end();
