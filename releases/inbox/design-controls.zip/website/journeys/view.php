<?php
// journeys/view.php?id= — one journey (decisions/0056). Who wrote it (Traversence or a named contributor), the
// category and title, the place, "Was here", the read time, the photos and video, the story, the contributor's own
// flags, the listings it links (connection points to Get Local), views, likes, public comments, and Report.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/journey-ui.php';
require_once __DIR__ . '/../../app/lib/Journeys.php';

$pdo = Database::connection();
$uid = Auth::currentUserId();
$j = Journeys::ready($pdo) ? Journeys::get($pdo, (int) ($_GET['id'] ?? 0)) : null;
if (!$j || !Journeys::visible($pdo, $j, $uid)) {
    http_response_code(404);
    tv_page_start('Journey not found');
    echo '<div class="text-center py-10"><h1 class="font-serif font-bold text-2xl mb-2">Journey not found</h1><p class="text-sm">It may have been removed. <a class="underline" href="/discovery/">Back to Let&rsquo;s Explore</a></p></div>';
    tv_page_end();
    exit;
}
$id = (int) $j['id'];
if ($j['status'] === 'published' && $uid !== (int) $j['author_id']) {   // one view a day per person (or device)
    require_once __DIR__ . '/../../app/lib/GuestInquiries.php';
    Journeys::view($pdo, $id, $uid ? 'u' . $uid : GuestInquiries::deviceHash());
}
$au = Journeys::author($pdo, $j);   // Traversence, a listing, or the person (decisions/0058 §2)
$isT = $au['kind'] === 'traversence';
$by = $au['name'];
$con = !$isT ? Journeys::contributor($pdo, (int) $j['author_id']) : null;
$media = Journeys::media($pdo, $id);
$embed = Journeys::embed((string) $j['video_url']);
$flags = array_values(array_intersect_key(Journeys::FLAGS, array_flip(array_filter(explode(',', (string) $j['flags'])))));
$listings = [];
if ($ids = array_filter(array_map('intval', explode(',', (string) $j['listings'])))) {
    $st = $pdo->query("SELECT e.id, e.name, JSON_UNQUOTE(c.meta_value) AS city FROM entities e LEFT JOIN entity_metadata c ON c.entity_id = e.id AND c.meta_key = 'city'
                        WHERE e.id IN (" . implode(',', $ids) . ") AND e.is_suppressed = 0");
    $listings = $st->fetchAll(PDO::FETCH_ASSOC);
}
$placeUrl = '';
if ($j['place_key'] !== '') { try { require_once __DIR__ . '/../../app/lib/Links.php'; [, $placeUrl] = Links::resolve($pdo, 'place', (string) $j['place_key']); } catch (Throwable) {} }
$liked = Journeys::liked($pdo, $id, $uid);
$comments = Journeys::comments($pdo, $id);
$mine = $uid && Journeys::canEdit($pdo, $j, $uid);
$cos = Journeys::coauthors($pdo, $id);   // accepted co-authors
$tidy = $uid && ($uid === (int) $j['author_id'] || Journeys::staffCan($pdo, $uid, 'journeys'));   // may remove comments here
$ageOk = $uid ? AgeGate::confirmed($pdo, $uid) : false;
require_once __DIR__ . '/../../app/lib/Reports.php';

tv_page_start($j['title'], ['description' => mb_strimwidth(strip_tags((string) $j['body']), 0, 180, '…'), 'no_crumbs' => true, 'back' => ['/user/journeys/', 'Your journeys']]);   // 'back' shows only inside the dashboard   // no breadcrumbs on content pages (decisions/0058 §10)
tv_count_item('journey:' . (int) $id);   // the platform's counts
echo tv_journey_css();
?>
<style>
  .jv{max-width:50rem}
  .jv-top{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .7rem;font-size:.82rem;color:var(--tv-meta)}
  .jv h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.6rem,3vw,2.3rem);color:var(--tv-ink);margin:.3rem 0 .4rem;line-height:1.15}
  .jv-cat{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--tv-link)}
  .jv-by{display:flex;align-items:center;gap:.55rem;margin:.6rem 0 1rem}.jv-by .jr-av{width:34px;height:34px;font-size:.95rem}
  .jv-by b{color:var(--tv-ink)}.jv-by small{display:block;color:var(--tv-meta);font-size:.78rem}
  .jv-gal{display:grid;gap:.4rem;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));margin:.6rem 0 1rem}
  .jv-gal figure{margin:0}.jv-gal img{width:100%;height:auto;aspect-ratio:3/2;object-fit:cover;border-radius:.7rem;display:block}
  .jv-gal figure:first-child{grid-column:1/-1}.jv-gal figure:first-child img{aspect-ratio:auto;max-height:70vh}
  .jv-gal figcaption{font-size:.78rem;color:var(--tv-meta);margin-top:.2rem}
  .jv-video{position:relative;padding-top:56.25%;border-radius:.8rem;overflow:hidden;margin:.6rem 0 1rem;background:#000}.jv-video iframe{position:absolute;inset:0;width:100%;height:100%;border:0}
  .jv-body p{font-size:1.02rem;line-height:1.7;color:var(--tv-ink);margin:0 0 1rem}
  .jv-flags{display:flex;flex-wrap:wrap;gap:.35rem;margin:.4rem 0}.jv-flag{font-size:.74rem;border:1px solid var(--tv-line-strong);background:var(--tv-card-a);border-radius:999px;padding:.15rem .6rem;color:var(--tv-meta)}
  .jv-sec{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.1rem;color:var(--tv-ink);margin:1.4rem 0 .5rem}
  .jv-lst{display:flex;flex-wrap:wrap;gap:.5rem}.jv-lst a{display:block;background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:.8rem;padding:.5rem .8rem;color:var(--tv-ink);text-decoration:none;font-size:.88rem}
  .jv-lst a:hover{border-color:var(--tv-line-strong)}.jv-lst small{display:block;color:var(--tv-meta);font-size:.75rem}
  .jv-acts{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;border-top:1px solid var(--tv-line);border-bottom:1px solid var(--tv-line);padding:.6rem 0;margin:1rem 0}
  .jv-b{display:inline-flex;align-items:center;gap:.35rem;background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:999px;padding:.35rem .85rem;font-size:.85rem;font-weight:600;color:var(--tv-ink);cursor:pointer;text-decoration:none}
  .jv-b.on{background:var(--tv-umber);color:var(--tv-on-umber);border-color:var(--tv-umber)}.jv-b.dark{background:var(--tv-umber);color:var(--tv-on-umber)}
  .jv-cm{border-top:1px solid var(--tv-line);padding:.6rem 0}.jv-cm b{font-size:.88rem;color:var(--tv-ink)}.jv-cm small{color:var(--tv-meta);font-size:.74rem;margin-left:.4rem}
  .jv-cm p{margin:.2rem 0 0;font-size:.92rem;color:var(--tv-ink);white-space:pre-line}.jv-cm button{background:none;border:0;color:var(--tv-meta);font-size:.74rem;cursor:pointer;text-decoration:underline;margin-left:.4rem}
  .jv-in{width:100%;box-sizing:border-box;border:1px solid var(--tv-line-strong);border-radius:.6rem;padding:.5rem .65rem;background:var(--tv-field);font:inherit;font-size:.92rem;min-height:4rem}
  .jv-note{font-size:.82rem;color:var(--tv-meta)}
  .jv-rep{background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:.8rem;padding:.7rem .8rem;margin-top:.4rem}
  .jv-caution{background:var(--tv-hold-bg);border:1px solid color-mix(in srgb,var(--tv-hold) 35%,var(--tv-canvas));color:color-mix(in srgb,var(--tv-hold) 75%,var(--tv-ink));border-radius:.6rem;padding:.5rem .8rem;font-size:.9rem;margin:0 0 .8rem}
  .jv-mature{background:var(--tv-umber);color:var(--tv-on-umber);border-radius:.9rem;padding:1.2rem;text-align:center;margin:.4rem 0 1rem}.jv-mature p{margin:.3rem 0 .8rem;font-size:.9rem;color:var(--tv-on-umber-meta)}
  .jv-mature .jv-b.dark{background:var(--tv-card-a);color:var(--tv-ink)}
  .jv-hidden{background:var(--tv-fail-bg);color:var(--tv-fail);border-radius:.6rem;padding:.5rem .8rem;font-size:.88rem}
</style>
<?php   // pins posted before the nations' boundaries were loaded follow the same rule when shown (decisions/0058 §26)
if (isset($j['pin_lat']) && $j['pin_lat'] !== null) { [$j['pin_lat'], $j['pin_lon']] = Journeys::nationPin($pdo, (float) $j['pin_lat'], (float) $j['pin_lon']); }
foreach ($media as $mi => $mm) if ($mm['tag_lat'] !== null) { [$media[$mi]['tag_lat'], $media[$mi]['tag_lon']] = Journeys::nationPin($pdo, (float) $mm['tag_lat'], (float) $mm['tag_lon']); }
?>
<article class="jv" data-link-host style="position:relative">
  <?php if ($j['status'] === 'published'): ?><span style="position:absolute;top:0;right:0" data-link="place:jr:<?= $id ?>" data-link-label="<?= tv_e($j['title']) ?>"></span><?php endif; ?>
  <?php if ($j['status'] !== 'published'): ?><p class="jv-hidden"><?= $j['status'] === 'draft' ? 'A draft: only you (and our team) can see it.' : 'Hidden after reports' . ($j['hidden_reason'] ? ' (' . tv_e($j['hidden_reason']) . ')' : '') . '. Only you and our team can see it.' ?></p><?php endif; ?>
  <div class="jv-top" style="padding-right:3rem">
    <span class="jr-voice <?= $isT ? 't' : 'c' ?>"><?= $isT ? 'Traversence' : ($au['kind'] === 'listing' ? 'Business' : 'Contributor') ?></span>
    <?php if ($j['partnership']): ?><span class="jr-voice p">Partnership</span><?php endif; ?>
    <?php if ($j['place_label']): ?><span><?= tv_icon('pin', 'tv-ei') ?> <?= $placeUrl ? '<a class="underline" href="' . tv_e($placeUrl) . '">' . tv_e($j['place_label']) . '</a>' : tv_e($j['place_label']) ?></span><?php endif; ?>
    <?php if ($j['was_here']): ?><span>Was here <?= tv_e(date('M Y', strtotime((string) $j['was_here']))) ?><?= !empty($j['was_time']) ? ' · ' . tv_e(date('g:i A', strtotime('2000-01-01 ' . $j['was_time']))) : '' ?></span><?php endif; ?>
    <?php if (isset($j['pin_lat']) && $j['pin_lat'] !== null): ?><a class="underline" target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=<?= tv_e((string) (float) $j['pin_lat']) ?>&amp;mlon=<?= tv_e((string) (float) $j['pin_lon']) ?>#map=14/<?= tv_e((float) $j['pin_lat'] . '/' . (float) $j['pin_lon']) ?>">Where it happened ↗</a><?php endif; ?>
  </div>
  <p class="jv-cat" style="margin:.6rem 0 0"><?= tv_e($j['category']) ?></p>
  <h1><?= tv_e($j['title']) ?></h1>
  <div class="jv-by"><span class="jr-av" aria-hidden="true"><?= tv_e(mb_strtoupper(mb_substr($by, 0, 1))) ?></span>
    <span><b><?= $au['url'] !== '' ? '<a class="underline" href="' . tv_e($au['url']) . '">' . tv_e($by) . '</a>' : tv_e($by) ?></b>
      <small><?= $j['published_at'] ? 'Posted ' . tv_e(date('M j, Y', strtotime((string) $j['published_at']))) . ' · ' : '' ?><?= Journeys::readMinutes((string) $j['body']) ?> min read · <?= tv_icon('eye', 'tv-ei') ?> <?= (int) $j['views'] ?><?= $au['kind'] === 'person' && $con && $con['bio'] !== '' ? ' · ' . tv_e($con['bio']) : '' ?></small>
      <?php if ($cos): ?><small>With <?= implode(', ', array_map(fn ($c) => '<a class="underline" href="/user/profile.php?id=' . (int) $c['id'] . '">' . tv_e($c['name']) . '</a>', $cos)) ?></small><?php endif; ?></span></div>
  <?php if (!empty($j['caution'])): ?><p class="jv-caution" role="note"><b>⚠ Caution:</b> <?= tv_e((string) $j['caution']) ?></p><?php endif; ?>
  <?php $gated = !empty($j['mature']) && !$mine; ?>
  <?php if (!empty($j['mature'])): ?><div class="jv-mature" id="jv-mature"<?= $gated ? '' : ' hidden' ?>>
    <b>Mature themes</b><p>The writer marked this journey as having mature themes. It&rsquo;s for adult readers.</p>
    <button type="button" class="jv-b dark" id="jv-show">Show the journey</button></div><?php endif; ?>
  <div id="jv-content"<?= $gated ? ' hidden' : '' ?>>

  <?php if ($media): ?><div class="jv-gal"><?php foreach ($media as $m): ?>
    <figure><img src="<?= tv_e($m['path']) ?>" alt="<?= tv_e($m['caption'] ?: $j['title']) ?>" loading="lazy" width="<?= (int) $m['width'] ?>" height="<?= (int) $m['height'] ?>">
      <?php $credit = ($m['source'] ?? 'own') === 'permission' && ($m['credit'] ?? '') !== '' ? 'Photo: ' . $m['credit'] : '';
            $taken = !empty($m['taken_at']) ? 'Taken ' . date('M j, Y', strtotime((string) $m['taken_at'])) : ''; ?>
      <?php if ($m['caption'] !== '' || $m['tag_place'] !== '' || $m['tag_lat'] !== null || $credit || $taken): ?><figcaption><?= tv_e(implode(' · ', array_filter([$m['caption'], $taken, $credit]))) ?><?= $m['tag_place'] !== '' ? ' · ' . tv_icon('pin', 'tv-ei') . ' ' . tv_e($m['tag_place']) : '' ?>
        <?= $m['tag_lat'] !== null ? ' · <a class="underline" target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=' . tv_e((string) $m['tag_lat']) . '&amp;mlon=' . tv_e((string) $m['tag_lon']) . '#map=15/' . tv_e($m['tag_lat'] . '/' . $m['tag_lon']) . '">where it was taken</a>' : '' ?></figcaption><?php endif; ?></figure>
  <?php endforeach; ?></div><?php endif; ?>
  <?php if ($embed): // loads from YouTube or Vimeo only when allowed or tapped (js/consent.js, decisions/0077) ?><div class="jv-video"><div class="tv-vid" style="position:absolute;inset:0;aspect-ratio:auto;border-radius:0" data-vsrc="<?= tv_e($embed) ?>" data-vtitle="<?= tv_e((string) ($j['title'] ?? 'Video')) ?>"></div></div><?php endif; ?>

  <?php require_once __DIR__ . '/../../app/lib/GuideLinks.php';   // the names the Chameleon Filter found, highlighted (decisions/0132)
  $jvBody = ''; foreach (preg_split("/\n\s*\n/", trim((string) $j['body'])) as $p) $jvBody .= '<p>' . nl2br(tv_e(trim($p))) . '</p>';
  if ($j['status'] === 'published') $jvBody = GuideLinks::linkify($pdo, 'journey:' . (int) $j['id'], 'body', $jvBody); ?>
  <div class="jv-body"><?= $jvBody ?></div>
  <?php if ($uid && $uid === (int) $j['author_id'] && $j['status'] === 'published') { require_once __DIR__ . '/../../app/ui/tag-chips.php'; echo tv_tag_chips($pdo, 'journey:' . (int) $j['id']); } ?>
  <?php if ($flags): ?><div class="jv-flags" aria-label="About this journey"><?php foreach ($flags as $f): ?><span class="jv-flag"><?= tv_e($f) ?></span><?php endforeach; ?></div><?php endif; ?>
  </div>
  <?php if (isset($j['reuse'])): ?><p class="jv-note">&copy; <?= tv_e($by) ?><?= $cos ? ' and co-authors' : '' ?>. <?= tv_e(Journeys::REUSE[$j['reuse']] ?? Journeys::REUSE['traversence']) ?>.</p><?php endif; ?>

  <?php if ($listings): ?>
    <h2 class="jv-sec">Places on this journey</h2>
    <div class="jv-lst"><?php foreach ($listings as $l): ?><a href="/listing/view.php?id=<?= (int) $l['id'] ?>"><?= tv_e($l['name']) ?><small><?= tv_e((string) ($l['city'] ?? '')) ?> · on Get Local</small></a><?php endforeach; ?></div>
  <?php endif; ?>

  <div class="jv-acts">
    <?php if ($j['status'] === 'published'): ?>
      <button type="button" class="jv-b<?= $liked ? ' on' : '' ?>" id="jv-like" aria-pressed="<?= $liked ? 'true' : 'false' ?>">♥ <span><?= (int) $j['likes'] ?></span></button>
      <span class="jv-note"><?= tv_icon('comment', 'tv-ei') ?> <?= count($comments) ?></span>
      <button type="button" class="jv-b" id="jv-share" data-short-warm="?id=<?= $id ?>"><?= tv_icon('link', 'tv-ei') ?> Copy link</button>
      <button type="button" class="jv-b" data-qr="?id=<?= $id ?>">QR code</button>
      <?php if (!$mine): ?><button type="button" class="jv-b" id="jv-report">⚑ Report</button><?php endif; ?>
    <?php endif; ?>
    <?php if ($mine): ?><a class="jv-b dark" href="/user/journeys/compose.php?id=<?= $id ?>">✎ Edit</a><?php endif; ?>
  </div>
  <div class="jv-rep" id="jv-rep" hidden>
    <b style="font-size:.9rem">What&rsquo;s wrong?</b>
    <select class="jv-in" id="jv-reason" style="min-height:0;margin-top:.4rem"><?php foreach (Reports::REASONS as $k => $r): ?><option value="<?= tv_e($k) ?>"><?= tv_e($r) ?></option><?php endforeach; ?></select>
    <textarea class="jv-in" id="jv-rnote" maxlength="500" placeholder="Anything our team should know (optional)" style="margin-top:.4rem"></textarea>
    <p style="margin:.4rem 0 0"><button type="button" class="jv-b dark" id="jv-rsend">Send report</button> <span class="jv-note" id="jv-rmsg"></span></p>
  </div>

  <?php if ($j['status'] === 'published'): ?>
  <h2 class="jv-sec" id="comments">Comments</h2>
  <div id="jv-comments">
    <?php if (!$comments): ?><p class="jv-note" id="jv-none">No comments yet.</p><?php endif; ?>
    <?php foreach ($comments as $c): ?>
      <div class="jv-cm" data-c="<?= (int) $c['id'] ?>"><b><?= tv_e($c['name']) ?></b><small><?= tv_e(date('M j, Y', strtotime((string) $c['created_at']))) ?></small>
        <?php if ($uid && ($uid === (int) $c['user_id'] || $tidy)): ?><button type="button" data-del="<?= (int) $c['id'] ?>">Remove</button><?php elseif ($uid): ?><button type="button" data-rep="<?= (int) $c['id'] ?>">Report</button><?php endif; ?>
        <p><?= tv_e($c['body']) ?></p></div>
    <?php endforeach; ?>
  </div>
  <?php if (!$uid): ?><p class="jv-note"><a class="underline" href="/login.php?next=<?= tv_e(rawurlencode('/journeys/view.php?id=' . $id . '#comments')) ?>">Sign in</a> to comment. Comments are public.</p>
  <?php else: ?>
    <form id="jv-cform" style="margin-top:.6rem">
      <textarea class="jv-in" id="jv-cbody" maxlength="2000" placeholder="Add a comment (public)"></textarea>
      <?php if (!$ageOk): ?><label class="jv-note" style="display:flex;gap:.4rem;margin-top:.35rem"><input type="checkbox" id="jv-age"> <?= tv_e(AgeGate::TEXT) ?></label><?php endif; ?>
      <p style="margin:.4rem 0 0"><button class="jv-b dark" type="submit">Post comment</button> <span class="jv-note" id="jv-cmsg"></span></p>
    </form>
  <?php endif; ?>
  <?php endif; ?>
  <p class="jv-note" style="margin-top:1.4rem"><?= $isT ? 'Written by Traversence.' : 'A journey shared by a contributor. Traversence doesn&rsquo;t check contributors&rsquo; journeys before they publish; report anything wrong.' ?>
    <a class="underline" href="/user/journeys/">Share your own journey</a>.</p>
</article>
<script>
  // mature themes: the reader chooses to open it (remembered for this visit)
  (function () {
    var g = document.getElementById('jv-mature'), c = document.getElementById('jv-content'), b = document.getElementById('jv-show'), k = 'tv_jv_open_<?= (int) $id ?>';
    function show() { if (g) g.hidden = true; if (c) c.hidden = false; try { sessionStorage.setItem(k, '1'); } catch (x) {} }
    try { if (g && !g.hidden && sessionStorage.getItem(k) === '1') show(); } catch (x) {}
    if (b) b.addEventListener('click', show);
  })();
</script>
<script>
(function () {
  var ID = <?= $id ?>, csrf = null, signed = <?= $uid ? 'true' : 'false' ?>;
  function token() { return csrf ? Promise.resolve(csrf) : fetch('/api/journeys.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { csrf = d.csrf; return csrf; }); }
  function post(body) {
    return token().then(function (t) { return fetch('/api/journeys.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': t || '' }, body: JSON.stringify(body) }); })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok || !d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work. Try again.'); return d; }); });
  }
  function needSign() { location.href = '/login.php?next=' + encodeURIComponent(location.pathname + location.search); }
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var like = document.getElementById('jv-like');
  if (like) like.addEventListener('click', function () {
    if (!signed) return needSign();
    post({ action: 'like', id: ID }).then(function (d) { like.classList.toggle('on', d.liked); like.setAttribute('aria-pressed', String(d.liked)); like.querySelector('span').textContent = d.likes; }).catch(function (e) { TvAsk.say(e.message, { anchor: like }); });
  });
  var share = document.getElementById('jv-share');
  if (share) share.addEventListener('click', function () {
    var u = location.origin + location.pathname + '?id=' + ID;
    if (window.tvShort) u = tvShort.now(u);   // trvgo.us (decisions/0094)
    (navigator.clipboard ? navigator.clipboard.writeText(u) : Promise.reject()).then(function () { share.textContent = '✓ Link copied'; }, function () { TvAsk.ask('Copy this link', u, { yes: 'Done' }); });
  });
  var rep = document.getElementById('jv-report'), box = document.getElementById('jv-rep'), repKind = 'journey', repId = ID;
  if (rep) rep.addEventListener('click', function () { if (!signed) return needSign(); repKind = 'journey'; repId = ID; box.hidden = !box.hidden; });
  document.getElementById('jv-rsend').addEventListener('click', function () {
    var m = document.getElementById('jv-rmsg');
    post({ action: 'report', kind: repKind, id: repId, reason: document.getElementById('jv-reason').value, note: document.getElementById('jv-rnote').value })
      .then(function () { m.textContent = 'Thank you. Our team will look at it.'; setTimeout(function () { box.hidden = true; m.textContent = ''; }, 2500); }).catch(function (e) { m.textContent = e.message; });
  });
  var list = document.getElementById('jv-comments');
  if (list) list.addEventListener('click', function (e) {
    var d = e.target.closest('[data-del]'), r = e.target.closest('[data-rep]');
    if (d && TvAsk.gate(d, 'Remove this comment?', { yes: 'Remove', danger: true })) post({ action: 'uncomment', comment: +d.getAttribute('data-del') }).then(function () { d.closest('.jv-cm').remove(); }).catch(function (x) { TvAsk.say(x.message, { anchor: d }); });
    if (r) { repKind = 'journey_comment'; repId = +r.getAttribute('data-rep'); box.hidden = false; box.scrollIntoView({ block: 'center' }); }
  });
  var form = document.getElementById('jv-cform');
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    var t = document.getElementById('jv-cbody'), msg = document.getElementById('jv-cmsg'), age = document.getElementById('jv-age');
    if (!t.value.trim()) return;
    if (age && !age.checked) { msg.textContent = 'Please confirm you are 18 or older.'; return; }
    (age ? post({ action: 'age' }) : Promise.resolve()).then(function () { return post({ action: 'comment', id: ID, body: t.value }); }).then(function (d) {
      var n = document.getElementById('jv-none'); if (n) n.remove();
      list.insertAdjacentHTML('beforeend', '<div class="jv-cm" data-c="' + d.comment.id + '"><b>' + esc(d.comment.name) + '</b><small>just now</small><button type="button" data-del="' + d.comment.id + '">Remove</button><p>' + esc(d.comment.body) + '</p></div>');
      t.value = ''; msg.textContent = ''; if (age) age.closest('label').remove();
    }).catch(function (x) { msg.textContent = x.message; });
  });
})();
</script>
<script src="/js/link-button.js" defer></script>
<?php echo '<script src="/js/tv-tagcard.js" defer></script>';   // the preview card of a highlighted name (decisions/0132)
tv_page_end();
