<?php
// admin/release.php — one release, inside System Configuration → Releases at /admin/config/releases/<id> (Jason,
// 2026-11-18: the list is the standard table; each release opens as its own page). Drawn by the section's own code
// (tv_admin_mod_releases with the release's number): where it stands, its files, its checks folded to one line, its
// buttons, What happened. It keeps itself current (js/admin-releases.js) and each press answers in place.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/admin/widgets.php';
require_once __DIR__ . '/../../app/admin/sections.php';
if (!class_exists('Access')) require_once __DIR__ . '/../../app/admin/Access.php';

$pdo = Database::connection();
[$me, $ctx] = tv_admin_require($pdo);
$id = (int) ($_GET['id'] ?? 0);
$base = '/admin/config/releases/';
if (!isset($tvItemRoute) && empty($_GET['embed']) && $_SERVER['REQUEST_METHOD'] === 'GET') { header('Location: ' . $base . $id, true, 301); exit; }
require_once __DIR__ . '/../../app/lib/Releases.php';
$r = Releases::get($pdo, $id);
tv_admin_start('config', $r ? 'Release #' . $id : 'Release', '', null, [['System Configuration', '/admin/config'], ['Releases', '/admin/config/releases'], ['#' . $id, '']]);
[$can, $why] = Access::can('config.releases', ['min' => 'executive', 'depts' => []]);   // as the section's list (tools.php config/releases)
echo $can ? tv_admin_mod_releases($pdo, max(1, $id)) : '<p data-tv-status="info" data-tv-label="Not for your role:">' . tv_w_e((string) $why) . '. Releases are run by executives: ask one, or write to support@traversence.com.</p>';
tv_admin_end();
