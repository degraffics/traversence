<?php
// app/scripts/page_read_tick.php — Stage 9's reader (decisions/0164 §2.3; gap review P1-1): pages waiting to be read are
// read into facts by the AI that AI use routes page_read to (Gemini's free tier for public pages, else Claude inside the
// cap). Shipped off: it runs only while automation, W3 and AI use's "page_read" are on. Not in Scheduler::AUTO: added in
// System Configuration → Scheduled tasks when wanted.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('page_read_tick');
require_once __DIR__ . '/../lib/crawler/PageRead.php';
$pdo = Database::connection();
$r = PageRead::tick($pdo, 3);
echo 'Pages read: ' . $r['read'] . ', facts: ' . $r['facts'] . ', still waiting: ' . $r['waiting'] . ($r['why'] !== '' ? ' (' . $r['why'] . ')' : '') . "\n";
