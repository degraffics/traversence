<?php
// /api/engage.php — likes, comments and reports on content pages (decisions/0058 §20; api/lib/Engage.php).
// POST JSON with X-CSRF-Token. A guest may like ({guest:true, ask_learning}) and answer {action: learning, on}; the rest
// needs an account (401 'account', which opens the account panel, js/tv-join.js). Signed in:
//   {action: like, kind, ref}                 -> {liked, likes}; or 428 'check' (the human check first: {sitekey}),
//                                                429 'daily' (today's 100 used: Keep liking, after the check)
//   {action: like_pass, token}                -> {}      the human check passed (guests too)
//   {action: like_more, token}                -> {}      Keep liking: another 100 today
//   {action: guest_more}                      -> {}      a guest's Keep going as a guest (401 'account' carries more: true)
//   {action: comment, kind, ref, body, parent?} -> {comment}   parent: the comment it replies to (one level)
//   {action: uncomment, comment}              -> {}
//   {action: report, what: comment|experience|market_post|market_note, id, reason, note}
//   {action: age}                             -> {}      "I am 18 or older"
// GET -> {signed_in, csrf}
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Engage.php';
require_once __DIR__ . '/../../app/lib/AgeGate.php';

$pdo = Database::connection();
$uid = Auth::currentUserId();
try {
    // GET counts=1&kind&ref: a page's views, likes and comments, for the photo viewer (Jason, 2026-11-19: "the social numbers
    // should always be present"). Read only; never who.
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['counts'])) {
        $k = (string) ($_GET['kind'] ?? ''); $r = substr(preg_replace('/[^\w:.-]/', '', (string) ($_GET['ref'] ?? '')), 0, 60);
        if (!in_array($k, Engage::KINDS, true) || $r === '' || !Engage::ready($pdo)) Response::error('Nothing to count.', 404, 'not_found');
        if ($uid) $on = Engage::liked($pdo, $k, $r, $uid); else { require_once __DIR__ . '/../../app/lib/Guest.php'; $on = !empty(Guest::liked()[$k . ':' . $r]); }
        Response::json(['ok' => true, 'views' => Engage::views($pdo, $k, $r), 'likes' => Engage::likes($pdo, $k, $r), 'comments' => Engage::commentCount($pdo, $k, $r), 'liked' => $on, 'like' => $k !== 'listing']);   // listings: no Like (0058 §20)
    }
    // GET trip=1&key or lat&lon: Plan a trip here (decisions/0146): the place's ready-made journeys, then the Trip Planner set to it
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['trip'])) {
        require_once __DIR__ . '/../../app/lib/Guides.php'; require_once __DIR__ . '/../../app/lib/JourneyPlan.php';
        $key = (string) ($_GET['key'] ?? '');
        if (!preg_match('/^(hub|geo_hub|cluster|town|sub):\d+$/', $key) && is_numeric($_GET['lat'] ?? null) && is_numeric($_GET['lon'] ?? null)) {   // a point: its nearest area, within 40 miles
            $la = (float) $_GET['lat']; $lo = (float) $_GET['lon'];
            $st = $pdo->prepare("SELECT id, (POW(center_lat - ?, 2) + POW((center_lon - ?) * COS(RADIANS(?)), 2)) d FROM micro_clusters WHERE status = 'active' AND center_lat IS NOT NULL ORDER BY d LIMIT 1");
            $st->execute([$la, $lo, $la]); $c = $st->fetch(PDO::FETCH_ASSOC);
            $key = $c && sqrt((float) $c['d']) * 69 <= 40 ? 'cluster:' . (int) $c['id'] : '';
        }
        $p = $key !== '' ? Guides::place($pdo, $key) : null;
        if (!$p) Response::json(['ok' => true, 'place' => null, 'journeys' => [], 'plan' => '/discovery/?view=plan']);
        $js = []; try { foreach (array_slice(JourneyPlan::forPlace($pdo, $key), 0, 6) as $j) $js[] = ['title' => (string) $j['title'], 'why' => (string) ($j['why'] ?? ''), 'minutes' => (int) ($j['minutes'] ?? 0), 'url' => '/journeys/suggested.php?id=' . (int) $j['id']]; } catch (Throwable $e) {}
        $q = ['view' => 'plan'];
        if ($p['level'] === 'cluster') $q['cluster'] = (int) $p['id']; elseif ($p['level'] === 'geo_hub') $q['geo'] = (string) $p['slug']; elseif ($p['level'] === 'hub') $q['hub'] = (string) $p['slug'];
        elseif ((int) $p['cluster'] > 0) { $q['cluster'] = (int) $p['cluster']; $q['town'] = (string) $p['name']; }
        Response::json(['ok' => true, 'place' => ['name' => (string) $p['name'], 'url' => (string) ($p['url'] ?? '')], 'journeys' => $js, 'plan' => '/discovery/?' . http_build_query($q)]);
    }
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        Response::json(['ok' => true, 'signed_in' => $uid !== null, 'csrf' => $_SESSION['csrf_token'], 'age_ok' => $uid ? AgeGate::confirmed($pdo, $uid) : false]);   // a guest's likes: see the POST below
    }
    Response::requireMethod('POST');
    Response::requireCsrf();
    if (!Engage::ready($pdo)) Response::error('Comments aren\'t switched on yet.', 503, 'not_configured');
    $b = Response::jsonBody();
    // the checks on likes (app/lib/LikeGuard.php): the human check, guests and members alike
    $act0 = (string) ($b['action'] ?? '');
    if ($act0 === 'like_pass' || $act0 === 'like_more') {
        require_once __DIR__ . '/../../app/lib/LikeGuard.php';
        try { if ($act0 === 'like_more' && $uid) LikeGuard::more((string) ($b['token'] ?? '')); else LikeGuard::pass((string) ($b['token'] ?? '')); }
        catch (RuntimeException $x) { Response::error($x->getMessage(), 422, 'check_failed'); }
        Response::json(['ok' => true]);
    }
    $guarded = function (callable $f) {   // a like: the checks' answers become what the page acts on
        try { return $f(); }
        catch (RuntimeException $x) {
            if ($x->getCode() === 428 || $x->getCode() === 429) { require_once __DIR__ . '/../../app/lib/Captcha.php'; Response::error($x->getMessage(), $x->getCode(), $x->getCode() === 428 ? 'check' : 'daily', ['sitekey' => Captcha::siteKey()]); }
            if ($x->getCode() === 401) { $m = $x->getMessage(); $more = str_ends_with($m, '|more'); Response::error($more ? substr($m, 0, -5) : $m, 401, 'account', ['more' => $more]); }
            throw $x;
        }
    };
    // a guest (decisions/0009, 0058 §20 as changed 2026-11-05): likes count without an account; AI & Learning is asked once
    // a visit (decisions/0051 §1); everything that comes back to a person (comments, reports) suggests an account
    if ($uid === null) {
        require_once __DIR__ . '/../../app/lib/Guest.php';
        $act = (string) ($b['action'] ?? '');
        if ($act === 'like') {
            [$on, $n] = $guarded(fn () => Engage::toggleGuestLike($pdo, (string) ($b['kind'] ?? ''), (string) ($b['ref'] ?? '')));   // a few likes in: the account panel, with Keep going as a guest
            Response::json(['ok' => true, 'liked' => $on, 'likes' => $n, 'guest' => true, 'ask_learning' => Guest::learning() === null]);
        }
        if ($act === 'guest_more') { Guest::setMore(); Response::json(['ok' => true]); }
        if ($act === 'learning') { Guest::setLearning(!empty($b['on'])); Response::json(['ok' => true]); }
        Response::error($act === 'comment' ? 'Comments come back to you (replies, edits), so they need an account.' : 'This needs an account.', 401, 'account');
    }
    $kind = (string) ($b['kind'] ?? ''); $ref = (string) ($b['ref'] ?? '');
    if ($kind === 'photo') Response::error('Photos are liked and commented on in the gallery.', 422, 'not_allowed');   // gallery/api.php checks who may see each one
    switch ((string) ($b['action'] ?? '')) {
        case 'like':
            [$on, $n] = $guarded(fn () => Engage::toggleLike($pdo, $uid, $kind, $ref));
            Response::json(['ok' => true, 'liked' => $on, 'likes' => $n]);
        case 'comment':
            Response::json(['ok' => true, 'comment' => Engage::comment($pdo, $uid, $kind, $ref, (string) ($b['body'] ?? ''), (int) ($b['parent'] ?? 0))]);   // parent: a reply (one level, decisions/0172 §2.3)
        case 'uncomment':
            Engage::removeComment($pdo, $uid, (int) ($b['comment'] ?? 0));
            Response::json(['ok' => true]);
        case 'report':
            require_once __DIR__ . '/../../app/lib/Reports.php';
            $what = (string) ($b['what'] ?? '');
            Reports::file($pdo, $uid, in_array($what, ['experience', 'market_post', 'market_note', 'market_item', 'personal_guide'], true) ? $what : 'content_comment', (int) ($b['id'] ?? 0), (string) ($b['reason'] ?? ''), (string) ($b['note'] ?? ''));
            Response::json(['ok' => true]);
        case 'age':
            AgeGate::confirm($pdo, $uid);
            Response::json(['ok' => true]);
        default:
            Response::error('Unknown action.', 422, 'bad_action');
    }
} catch (InvalidArgumentException $x) {
    Response::error($x->getMessage(), 422, str_contains($x->getMessage(), '18 or older') ? 'age' : 'not_allowed');
}
