<?php
// api/lib/PlatformCounts.php — how the platform is used (decisions/0058 §13): what's viewed, how people move between
// the sections, what they search for and whether they find it, and what they do from a listing. Counts per day,
// metric and key. Never who: no user, device, IP address or session is stored. A visit is told apart only inside its
// own session (in memory on the server), so `visits` counts distinct visits without keeping anything that identifies one.
//
// Metrics (k is the key):
//   view        what was looked at: section ("explore") or item ("listing:12", "rec:abc", "journey:5", "place:cluster:3")
//   flow        a move between sections: "explore>local", "entry>explore" (arrived from outside), "local>listing"
//   search      a search someone acted on: its words, cleaned (k = "q:<words>"), and its reading (k = "in:<place>")
//   search_zero a search that found nothing where they were (k = words), search_none_here (k = "<words> @ <place>")
//   search_loc  a search with where it was read (k = "<words> @ <place>"); search_found, same key, n = the results it found
//   search_click what was opened from a search (k = listing|outdoors|story|group|place|topic|map|nearby)
//   act         an action from a listing or page (k = "recommend", "add_listing", "map_open", …)
//   page        a page's address (k = "/listing/view.php?id=12": its path, with ?id= or ?view= only)
//   page_flow   a move between pages in a visit (k = "/discovery/ > /listing/view.php?id=12")
//   land        the first page of a visit from outside (k = path); source, where it came from (k = "Google", "Direct",
//               "trvgo.us (short links, QR)", or the sending site's name); land_from, both (k = "Google > /path")
// Words are shown in reports only once 3 or more visits searched them; rarer ones are deleted after 90 days.

declare(strict_types=1);

final class PlatformCounts
{
    public const METRICS = ['view', 'flow', 'search', 'search_zero', 'search_none_here', 'search_loc', 'search_found', 'search_click', 'act', 'page', 'page_flow', 'land', 'source', 'land_from', 'trip'];   // trip: a place added to a trip (decisions/0174 §1), k = kind:ref, never who
    /** The sites that send visitors, by name: search engines first (decisions/0058 §13, SEO proof). */
    public const SOURCES = ['gemini.google.com' => 'Gemini', 'mail.google.com' => 'Gmail', 'google.' => 'Google', 'bing.com' => 'Bing', 'duckduckgo.com' => 'DuckDuckGo', 'search.yahoo.' => 'Yahoo', 'yahoo.com' => 'Yahoo', 'ecosia.org' => 'Ecosia',
        'search.brave.com' => 'Brave Search', 'yandex.' => 'Yandex', 'baidu.com' => 'Baidu', 'chatgpt.com' => 'ChatGPT', 'openai.com' => 'ChatGPT', 'perplexity.ai' => 'Perplexity',
        'copilot.microsoft.com' => 'Copilot', 'claude.ai' => 'Claude', 'facebook.com' => 'Facebook', 'fb.com' => 'Facebook', 'instagram.com' => 'Instagram',
        't.co' => 'X', 'x.com' => 'X', 'twitter.com' => 'X', 'linkedin.com' => 'LinkedIn', 'lnkd.in' => 'LinkedIn', 'pinterest.' => 'Pinterest', 'reddit.com' => 'Reddit',
        'youtube.com' => 'YouTube', 'tiktok.com' => 'TikTok', 'nextdoor.com' => 'Nextdoor', 'trvgo.us' => 'trvgo.us (short links, QR)'];
    public const ENGINES = ['Google', 'Bing', 'DuckDuckGo', 'Yahoo', 'Ecosia', 'Brave Search', 'Yandex', 'Baidu'];
    public const AI = ['ChatGPT', 'Perplexity', 'Gemini', 'Copilot', 'Claude'];

    /** A page's address as counted: its path, with ?id= or ?view= when given; '' for one that isn't counted (admin, API, odd). */
    public static function path(string $p): string
    {
        $p = trim($p);
        if (!preg_match('~^(/[A-Za-z0-9/_.\-]{0,110})(\?(?:id=[A-Za-z0-9_\-:]{1,40}|view=[a-z0-9_\-]{1,30}))?$~', $p, $m)) return '';
        if (preg_match('~^/(admin|api)(/|$)~', $m[1]) || str_contains($m[1], '..')) return '';
        return $m[1] . ($m[2] ?? '');
    }

    /** Where a visit came from, by name: a known site, else the sending site's own name; "Direct" when none was sent. */
    public static function source(string $host, string $utm = ''): string
    {
        $utm = mb_substr(preg_replace('/[^a-z0-9_.\- ]/i', '', $utm) ?? '', 0, 40);
        if ($utm !== '') return 'Campaign: ' . strtolower($utm);
        $h = strtolower(preg_replace('/^www\.|^m\.|^l\.|^lm\./', '', trim($host)) ?? '');
        if ($h === '' || !preg_match('/^[a-z0-9.\-]{3,80}(:\d+)?$/', $h)) return 'Direct (typed, a bookmark or an app)';
        foreach (self::SOURCES as $k => $v) if (str_starts_with($h, $k) || str_contains($h, '.' . $k) || ($k[-1] === '.' && preg_match('/(^|\.)' . preg_quote($k, '/') . '/', $h))) return $v;
        return $h;
    }
    private const WORDS = "'search', 'search_zero', 'search_none_here', 'search_loc', 'search_found'";   // keys that hold search words
    public const MIN_VISITS = 3;   // words searched by fewer visits than this are never shown

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM platform_counts LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    /** Search words as stored: lower case, no email addresses, no long numbers (phones, house numbers), at most 60 characters. */
    public static function cleanWords(string $q): string
    {
        $q = mb_strtolower(trim($q));
        $q = preg_replace('/\S+@\S+/u', '', $q) ?? '';
        $q = preg_replace('/\d[\d\s().-]{4,}\d/u', '', $q) ?? '';
        $q = preg_replace('/[^\p{L}\p{N}\s&\'-]/u', ' ', $q) ?? '';
        return mb_substr(trim(preg_replace('/\s+/u', ' ', $q) ?? ''), 0, 60);
    }

    public static function isBot(): bool
    {
        return (bool) preg_match('/bot|crawl|spider|slurp|preview|monitor|curl|wget|python|headless/i', (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    }

    /**
     * The team's own use isn't counted (2026-10-14): a signed-in admin, and any browser an admin has used (a cookie,
     * tv_nocount, kept a year, so signing out doesn't start counting them). Nothing about who is stored by it.
     */
    public static function isTeam(PDO $pdo): bool
    {
        if (!empty($_SESSION['tv_team_off'])) return false;   // an admin testing as a visitor (Insights → Count this browser)
        if (($_COOKIE['tv_nocount'] ?? '') === '1') return true;
        $uid = (int) ($_SESSION['user_id'] ?? 0);
        if ($uid <= 0) return false;
        if (!isset($_SESSION['tv_team'])) {
            try {
                require_once __DIR__ . '/TestAccounts.php';   // a test account counts no more than our team does (decisions/0145 §3)
                $st = $pdo->prepare('SELECT is_admin' . (TestAccounts::ready($pdo) ? ' OR is_test' : '') . ' FROM users WHERE id = ?'); $st->execute([$uid]); $_SESSION['tv_team'] = (int) (bool) $st->fetchColumn();
            }
            catch (PDOException) { return false; }
        }
        if ($_SESSION['tv_team']) { self::markBrowser(true); return true; }
        return false;
    }

    /** Mark this browser as the team's (not counted) or clear the mark. */
    public static function markBrowser(bool $on): void
    {
        if (headers_sent()) return;
        setcookie('tv_nocount', $on ? '1' : '', ['expires' => $on ? time() + 365 * 86400 : time() - 3600, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']), 'httponly' => true, 'samesite' => 'Lax']);
        if ($on) $_COOKIE['tv_nocount'] = '1'; else unset($_COOKIE['tv_nocount']);
    }

    /** A listing's own people (its owner or manager) looking at it aren't counted on it either. */
    public static function runsListing(PDO $pdo, int $entityId): bool
    {
        $uid = (int) ($_SESSION['user_id'] ?? 0);
        if ($uid <= 0 || $entityId <= 0) return false;
        try {
            $st = $pdo->prepare("SELECT 1 FROM " . Database::t('role_grants') . " WHERE user_id = ? AND side = 'org' AND scope_type = 'entity' AND scope_id = ? AND revoked_at IS NULL LIMIT 1");
            $st->execute([$uid, $entityId]);
            return (bool) $st->fetchColumn();
        } catch (PDOException) { return false; }
    }

    /** Count one (or $by). $once: count a view only once per visit and day (a reload doesn't add another). */
    public static function add(PDO $pdo, string $metric, string $k, bool $once = false, int $by = 1): bool
    {
        if (!self::ready($pdo) || !in_array($metric, self::METRICS, true) || self::isBot()) return false;
        $k = mb_substr($k, 0, 160);
        $day = date('Y-m-d');
        $seenKey = $metric . '|' . $k . '|' . $day;
        $first = true;
        if (session_status() === PHP_SESSION_ACTIVE) {
            $first = empty($_SESSION['tv_pc'][$seenKey]);
            if ($first) {
                if (count($_SESSION['tv_pc'] ?? []) > 400) $_SESSION['tv_pc'] = [];   // keep the session small
                $_SESSION['tv_pc'][$seenKey] = 1;
            }
        }
        if ($once && !$first) return false;
        $v = $first ? 1 : 0;
        $by = max(0, min($by, 1000000));
        $up = $pdo->prepare('UPDATE platform_counts SET n = n + ?, visits = visits + ? WHERE day = ? AND metric = ? AND k = ?');
        $up->execute([$by, $v, $day, $metric, $k]);
        if ($up->rowCount() === 0) {
            try { $pdo->prepare('INSERT INTO platform_counts (day, metric, k, n, visits) VALUES (?, ?, ?, ?, ?)')->execute([$day, $metric, $k, $by, $v]); }
            catch (PDOException) { $up->execute([$by, $v, $day, $metric, $k]); }
        }
        if (mt_rand(1, 500) === 1) self::tidy($pdo);
        return true;
    }

    /** Rare search words (fewer than MIN_VISITS in total) older than 90 days are deleted. */
    public static function tidy(PDO $pdo): void
    {
        try {
            $cut = date('Y-m-d', time() - 90 * 86400);
            $pdo->prepare('DELETE FROM platform_counts WHERE metric IN (' . self::WORDS . ') AND day < ? AND k IN (
                             SELECT k FROM (SELECT k FROM platform_counts WHERE metric IN (' . self::WORDS . ') GROUP BY k HAVING SUM(visits) < ?) x)')
                ->execute([$cut, self::MIN_VISITS]);
        } catch (Throwable) {}
    }

    /** Totals over the last $days days: [k => ['n', 'visits']], biggest first. $like narrows the keys ("q:%"). */
    public static function top(PDO $pdo, string $metric, int $days, int $limit = 20, string $like = '', int $minVisits = 0): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT k, SUM(n) AS n, SUM(visits) AS visits FROM platform_counts WHERE metric = ? AND day >= ?' . ($like !== '' ? ' AND k LIKE ?' : '')
                          . ' GROUP BY k' . ($minVisits > 0 ? ' HAVING SUM(visits) >= ' . (int) $minVisits : '') . ' ORDER BY SUM(visits) DESC, SUM(n) DESC LIMIT ' . max(1, $limit));
        $st->execute(array_merge([$metric, date('Y-m-d', time() - $days * 86400)], $like !== '' ? [$like] : []));
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['k']] = ['n' => (int) $r['n'], 'visits' => (int) $r['visits']];
        return $out;
    }

    /** What's held back for being rarer than $minVisits: how many different keys, and how many times, never the words. */
    public static function heldBack(PDO $pdo, string $metric, int $days, int $minVisits, string $like = ''): array
    {
        if (!self::ready($pdo)) return ['keys' => 0, 'n' => 0];
        $st = $pdo->prepare('SELECT COUNT(*), COALESCE(SUM(t.n), 0) FROM (SELECT SUM(n) AS n FROM platform_counts WHERE metric = ? AND day >= ?' . ($like !== '' ? ' AND k LIKE ?' : '')
                          . ' GROUP BY k HAVING SUM(visits) < ' . (int) $minVisits . ') t');
        $st->execute(array_merge([$metric, date('Y-m-d', time() - $days * 86400)], $like !== '' ? [$like] : []));
        [$keys, $n] = $st->fetch(PDO::FETCH_NUM) ?: [0, 0];
        return ['keys' => (int) $keys, 'n' => (int) $n];
    }

    /** Sum of a metric (optionally keys LIKE) over the period. */
    public static function total(PDO $pdo, string $metric, int $days, string $like = ''): array
    {
        if (!self::ready($pdo)) return ['n' => 0, 'visits' => 0];
        $st = $pdo->prepare('SELECT COALESCE(SUM(n), 0) AS n, COALESCE(SUM(visits), 0) AS visits FROM platform_counts WHERE metric = ? AND day >= ?' . ($like !== '' ? ' AND k LIKE ?' : ''));
        $st->execute(array_merge([$metric, date('Y-m-d', time() - $days * 86400)], $like !== '' ? [$like] : []));
        $r = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        return ['n' => (int) ($r['n'] ?? 0), 'visits' => (int) ($r['visits'] ?? 0)];
    }

    /** Per day, for a sparkline: [Y-m-d => visits]. */
    public static function daily(PDO $pdo, string $metric, int $days, string $like = ''): array
    {
        $out = [];
        for ($i = $days - 1; $i >= 0; $i--) $out[date('Y-m-d', time() - $i * 86400)] = 0;
        if (!self::ready($pdo)) return $out;
        $st = $pdo->prepare('SELECT day, SUM(visits) AS v FROM platform_counts WHERE metric = ? AND day >= ?' . ($like !== '' ? ' AND k LIKE ?' : '') . ' GROUP BY day');
        $st->execute(array_merge([$metric, date('Y-m-d', time() - ($days - 1) * 86400)], $like !== '' ? [$like] : []));
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['day']] = (int) $r['v'];
        return $out;
    }
}
