<?php
// app/lib/AccountDeletion.php — Delete my account, by the person themselves (decisions/0091).
//
// What happens, in one transaction:
//   deleted     what is only theirs: profile (and its photos), address book and contact cards, connections, groups of
//               people, saved places and searches, settings, privacy choices, likes, mutes, the sign-ins linked to it,
//               their team access to listings, pending email links and codes
//   erased      what they wrote for others to read: journeys, stories, posts, group posts and comments are hidden and
//               their text erased; their messages to other people read "[Deleted]" (the other person's side stays)
//   released    a business listing they ran goes back to unclaimed (it stays on the site, for the business); a claim
//               still in progress is withdrawn; their roles are revoked
//   kept        records the site needs without their name: reports they made, enforcement records, decisions staff
//               made, counts (which never record who)
//   the account a placeholder: its email becomes deleted-<id>@deleted.invalid, every personal field is cleared, it can
//               never sign in, and every session on it ends. The row stays so the records above still point somewhere.
//
// Not allowed until fixed first: an admin (another admin removes admin first), and someone who owns a group with other
// members (hand it over or hide it first; a group with only them is hidden with the account).
declare(strict_types=1);

final class AccountDeletion
{
    /** Reasons the account can't be deleted yet: [[message, link]]. */
    public static function blockers(PDO $pdo, int $uid): array
    {
        $out = [];
        $u = self::user($pdo, $uid);
        if (!$u) return [['This account doesn\'t exist.', '']];
        if ((int) $u['is_admin'] === 1) $out[] = ['You\'re an admin. Ask another admin to remove admin from your account first, so the site always has someone who can run it.', '/admin/people.php'];
        foreach (self::q($pdo, "SELECT g.id, g.name FROM community_groups g WHERE g.owner_id = ? AND g.status = 'active'
                                 AND EXISTS (SELECT 1 FROM community_group_members m WHERE m.group_id = g.id AND m.user_id <> ? AND m.status = 'active')", [$uid, $uid]) as $g) {
            $out[] = ['You own the group "' . $g['name'] . '", which has other members. Make someone else its owner, or hide it, first.', '/community/group.php?id=' . (int) $g['id']];
        }
        return $out;
    }

    /** What deleting will do, for the confirm page: [label => count], only the non-zero ones. */
    public static function summary(PDO $pdo, int $uid): array
    {
        $n = fn (string $sql, array $a = []) => (int) (self::q($pdo, $sql, $a ?: [$uid])[0]['n'] ?? 0);
        $s = [
            'journeys' => $n("SELECT COUNT(*) n FROM journeys WHERE author_id = ? AND status <> 'hidden'"),
            'stories' => $n('SELECT COUNT(*) n FROM place_stories WHERE author_id = ?'),
            'posts and comments' => $n('SELECT (SELECT COUNT(*) FROM posts WHERE user_id = ? AND is_deleted = 0) + (SELECT COUNT(*) FROM community_posts WHERE user_id = ? AND removed_at IS NULL)'
                                     . ' + (SELECT COUNT(*) FROM content_comments WHERE user_id = ?) + (SELECT COUNT(*) FROM journey_comments WHERE user_id = ?) n', [$uid, $uid, $uid, $uid]),
            'messages you sent' => $n('SELECT COUNT(*) n FROM messages WHERE sender_id = ?'),
            'contacts in your address book' => $n('SELECT COUNT(*) n FROM address_contacts WHERE owner_id = ?'),
            'connections' => $n('SELECT COUNT(*) n FROM people_connections WHERE requester_id = ? OR addressee_id = ?', [$uid, $uid]),
            'saved places' => $n('SELECT COUNT(*) n FROM user_places WHERE user_id = ?'),
            'trips' => $n('SELECT COUNT(*) n FROM trips WHERE user_id = ?'),
            'business listings you run' => $n('SELECT COUNT(*) n FROM entities WHERE owner_user_id = ?'),
        ];
        return array_filter($s);
    }

    /** Deletes the account. Throws RuntimeException when blocked. Returns the email it had (for the goodbye email). */
    public static function run(PDO $pdo, int $uid): string
    {
        if ($b = self::blockers($pdo, $uid)) throw new RuntimeException($b[0][0]);
        $u = self::user($pdo, $uid);
        $email = (string) $u['email'];
        $files = [];
        foreach (self::q($pdo, 'SELECT avatar_path, cover_path FROM member_profiles WHERE user_id = ?', [$uid]) as $r) foreach ($r as $p) if ($p) $files[] = (string) $p;
        $qrLogos = array_map(fn ($r) => (int) $r['id'], self::q($pdo, 'SELECT id FROM qr_issued WHERE user_id = ?', [$uid]));   // QR code logos (decisions/0095)

        $do = function (string $sql, array $a) use ($pdo): void {
            try { $pdo->prepare($sql)->execute($a); }
            catch (PDOException $e) {
                // a table or column this site doesn't have yet (an update not run) is skipped; anything else stops it all
                if (!preg_match('/doesn\'t exist|Unknown column|42S02|42S22/', $e->getMessage())) throw $e;
            }
        };
        $pdo->beginTransaction();
        try {
            // deleted: only theirs
            foreach ([
                'address_contacts' => ['owner_id'], 'contact_cards' => ['user_id'], 'contact_requests' => ['requester_id', 'owner_id'],
                'contact_shares' => ['owner_id', 'viewer_id'], 'people_connections' => ['requester_id', 'addressee_id'],
                'people_group_members' => ['user_id'], 'user_blocks' => ['user_id'], 'user_links' => ['user_id'], 'user_places' => ['user_id'],
                'user_settings' => ['user_id'], 'saved_searches' => ['user_id'], 'tool_consents' => ['user_id'], 'tool_consent_log' => ['user_id'],
                'age_confirmations' => ['user_id'], 'email_confirmations' => ['user_id'], 'user_otp_challenges' => ['user_id'],
                'user_identities' => ['user_id'], 'marketing_optins' => ['user_id'], 'member_profiles' => ['user_id'], 'content_likes' => ['user_id'],
                'journey_likes' => ['user_id'], 'business_message_mutes' => ['user_id'], 'business_message_reads' => ['user_id'],
                'business_contact_shares' => ['user_id'], 'message_members' => ['user_id'], 'journey_coauthors' => ['user_id'],
                'community_group_members' => ['user_id'], 'listing_access' => ['user_id'], 'admin_access' => ['user_id'], 'contributors' => ['user_id'],
                'saved_items' => ['user_id'], 'member_plans' => ['user_id'], 'qr_issued' => ['user_id'], 'ai_asks' => ['user_id'], 'like_events' => ['user_id'], 'like_watch' => ['user_id'],
            ] as $t => $cols) $do('DELETE FROM ' . Database::t($t) . " WHERE " . implode(' OR ', array_map(fn ($c) => "`$c` = ?", $cols)), array_fill(0, count($cols), $uid));
            $do("UPDATE personal_guides SET status = 'hidden', hidden_reason = 'The author deleted their account', title = '', intro = '', updated_at = NOW() WHERE user_id = ?", [$uid]);   // as journeys (0174 §6)
            $do('DELETE s FROM trip_stops s JOIN trips t ON t.id = s.trip_id WHERE t.user_id = ?', [$uid]);   // their trips (decisions/0174 §6)
            $do('DELETE FROM trips WHERE user_id = ?', [$uid]);
            $do('DELETE m FROM people_group_members m JOIN people_groups g ON g.id = m.group_id WHERE g.owner_id = ?', [$uid]);
            $do('DELETE FROM people_groups WHERE owner_id = ?', [$uid]);
            // trvgo.us codes (decisions/0094): their own are switched off and emptied; a listing's stay with the business.
            // QR orders stay as sales and tax records (decisions/0095).
            $do("UPDATE short_codes SET active = 0, off_reason = 'owner', target = '', payload = NULL, title = '' WHERE owner_user_id = ? AND entity_id IS NULL", [$uid]);
            $do('UPDATE short_codes SET owner_user_id = NULL WHERE owner_user_id = ?', [$uid]);

            // erased: what they wrote for others
            $do("UPDATE journeys SET status = 'hidden', hidden_reason = 'The author deleted their account', title = '', body = '', video_url = '', updated_at = NOW() WHERE author_id = ?", [$uid]);
            $do("UPDATE journey_comments SET status = 'hidden', body = '' WHERE user_id = ?", [$uid]);
            $do("UPDATE content_comments SET status = 'hidden', body = '' WHERE user_id = ?", [$uid]);
            $do("UPDATE place_stories SET status = 'draft', body = '' WHERE author_id = ?", [$uid]);
            $do("UPDATE posts SET is_deleted = 1, body = '' WHERE user_id = ?", [$uid]);
            $do("UPDATE community_posts SET removed_at = COALESCE(removed_at, NOW()), body = '' WHERE user_id = ?", [$uid]);
            $do("UPDATE experiences SET status = 'hidden' WHERE author_id = ?", [$uid]);
            $do("UPDATE messages SET body = '[Deleted]' WHERE sender_id = ?", [$uid]);
            $do("UPDATE business_messages SET body = '[Deleted]' WHERE user_id = ? AND (sent_by = ? OR sent_by IS NULL)", [$uid, $uid]);
            $do("UPDATE community_groups SET status = 'hidden' WHERE owner_id = ?", [$uid]);   // only their own: others' were a blocker

            // released: listings go back to unclaimed, claims in progress withdrawn, roles revoked
            $do("UPDATE entities SET owner_user_id = NULL, status = CASE WHEN status IN ('claimed-unverified', 'pending-verification', 'verified') THEN 'unclaimed' ELSE status END WHERE owner_user_id = ?", [$uid]);
            $do("UPDATE listing_claims SET status = 'withdrawn' WHERE user_id = ? AND status IN ('emailing', 'on_hold')", [$uid]);
            $do('UPDATE ' . Database::t('role_grants') . ' SET revoked_at = NOW(), revoked_by = ? WHERE user_id = ? AND revoked_at IS NULL', [$uid, $uid]);
            $do('UPDATE suggestions SET user_id = NULL WHERE user_id = ?', [$uid]);

            $do("UPDATE account_closures SET status = 'deleted', deleted_at = NOW(), token_hash = NULL, hidden = NULL WHERE user_id = ?", [$uid]);   // nothing left to restore

            // the account itself: a placeholder that can never sign in; every session on it ends
            $do("UPDATE users SET email = CONCAT('deleted-', id, '@deleted.invalid'), phone = NULL, display_name = NULL, password_hash = ?, email_verified_at = NULL,
                         google_sub = NULL, home_cluster_id = NULL, area_zip = NULL, area_city = NULL, area_state = NULL, area_lat = NULL, area_lon = NULL, area_label = NULL,
                         session_version = session_version + 1, deleted_at = NOW(), updated_at = NOW() WHERE id = ?", [password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), $uid]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('account deletion ' . $uid . ': ' . $e->getMessage());
            throw new RuntimeException('Your account couldn\'t be deleted just now. Nothing was changed. Try again, or email support@traversence.com.');
        }
        // their profile photos, from uploads/ only
        require_once __DIR__ . '/Store.php';   // on the server or in S3 (decisions/0123)
        foreach ($qrLogos as $qid) Store::remove(__DIR__ . '/../storage/qr-logos/' . (int) $qid . '.png');   // from before owner folders
        try {   // their gallery (decisions/0126): its records; the files go with their folder just below
            $pdo->prepare("DELETE ai FROM gallery_album_items ai JOIN gallery_albums a ON a.id = ai.album_id WHERE a.owner_kind = 'members' AND a.owner_ref = ?")->execute([(string) $uid]);
            $pdo->prepare("DELETE FROM gallery_albums WHERE owner_kind = 'members' AND owner_ref = ?")->execute([(string) $uid]);
            $pdo->prepare("DELETE FROM gallery_items WHERE owner_kind = 'members' AND owner_ref = ?")->execute([(string) $uid]);
        } catch (PDOException) {}   // no gallery yet
        try { require_once __DIR__ . '/MemberPosts.php'; MemberPosts::wipeOwner($pdo, $uid); } catch (Throwable $x) { error_log('account deletion posts ' . $uid . ': ' . $x->getMessage()); }   // their posts (decisions/0153); held copies keep their time
        try { Store::wipe('members', $uid); } catch (Throwable $x) { error_log('account deletion files ' . $uid . ': ' . $x->getMessage()); }   // everything in their folder (decisions/0124); their orders' files stay with the orders
        foreach ($files as $p) {
            $rel = '/' . ltrim((string) preg_replace('#^https?://[^/]+#', '', (string) $p), '/');
            if (str_starts_with($rel, '/uploads/') && !str_contains($rel, '..')) Store::remove(Store::web($rel));
        }
        return $email;
    }

    // ---- Closing first: 30 days to change your mind (decisions/0091, 2026-10-15) ------------------------------------
    //
    // close()    what they posted is hidden (the way each kind is hidden, with what it was before kept in the closure's
    //            record), every session ends, and the account waits 30 days. Nothing is erased yet; a listing they run
    //            stays as it is. An email has a Restore link.
    //   restore()  puts back exactly what close() hid (only where nobody has changed it since), and the account is open
    //   sweep()    on day 30, run() does the full deletion. Page loads run it (tickSoon, at most every 30 minutes).
    // Signing in while it's closing (password, Google, Apple, Microsoft, Facebook) goes to /user/restore-account.php,
    // which offers Restore or Keep it closed; nothing else opens until then.

    public const GRACE_DAYS = 30;

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM account_closures LIMIT 0'); return true; } catch (PDOException) { return false; }
    }

    /** The closure waiting on this account, or null. */
    public static function closing(PDO $pdo, int $uid): ?array
    {
        return self::q($pdo, "SELECT * FROM account_closures WHERE user_id = ? AND status = 'closing' LIMIT 1", [$uid])[0] ?? null;
    }

    /** The account a Restore link is for, or null. */
    public static function byToken(PDO $pdo, string $token): ?int
    {
        if (!preg_match('/^[a-f0-9]{40}$/', $token)) return null;
        $r = self::q($pdo, "SELECT user_id FROM account_closures WHERE token_hash = ? AND status = 'closing' LIMIT 1", [hash('sha256', $token)]);
        return $r ? (int) $r[0]['user_id'] : null;
    }

    /** Closes the account for 30 days. Returns ['email', 'delete_after', 'token']. Throws RuntimeException when blocked. */
    public static function close(PDO $pdo, int $uid): array
    {
        if ($b = self::blockers($pdo, $uid)) throw new RuntimeException($b[0][0]);
        if (!self::ready($pdo)) throw new RuntimeException('Closing accounts isn\'t set up yet (a database update). Try again later.');
        $u = self::user($pdo, $uid);
        $hidden = [];
        // each kind the way it's hidden: [table, id column, owner column, column, its hidden value, which rows]
        foreach ([
            ['journeys', 'id', 'author_id', 'status', 'hidden', "status <> 'hidden'"],
            ['journey_comments', 'id', 'user_id', 'status', 'hidden', "status <> 'hidden'"],
            ['content_comments', 'id', 'user_id', 'status', 'hidden', "status <> 'hidden'"],
            ['place_stories', 'id', 'author_id', 'status', 'draft', "status = 'published'"],
            ['posts', 'id', 'user_id', 'is_deleted', '1', 'is_deleted = 0'],
            ['experiences', 'id', 'author_id', 'status', 'hidden', "status <> 'hidden'"],
            ['member_profiles', 'user_id', 'user_id', 'published', '0', 'published = 1'],
            ['community_groups', 'id', 'owner_id', 'status', 'hidden', "status = 'active'"],
        ] as [$t, $idc, $own, $col, $to, $where]) {
            foreach (self::q($pdo, "SELECT `$idc` AS id, `$col` AS v FROM `$t` WHERE `$own` = ? AND $where", [$uid]) as $r) $hidden[] = [$t, $idc, $r['id'], $col, $r['v'], $to];
        }
        foreach (self::q($pdo, 'SELECT id FROM community_posts WHERE user_id = ? AND removed_at IS NULL', [$uid]) as $r) $hidden[] = ['community_posts', 'id', $r['id'], 'removed_at', null, 'now'];
        $token = bin2hex(random_bytes(20));
        $pdo->beginTransaction();
        try {
            foreach ($hidden as [$t, $idc, $id, $col, , $to]) {
                $pdo->prepare("UPDATE `$t` SET `$col` = " . ($to === 'now' ? 'NOW()' : '?') . " WHERE `$idc` = ?")->execute($to === 'now' ? [$id] : [$to, $id]);
            }
            $pdo->prepare("INSERT INTO account_closures (user_id, requested_at, delete_after, status, hidden, token_hash) VALUES (?, NOW(), DATE_ADD(NOW(), INTERVAL " . self::GRACE_DAYS . " DAY), 'closing', ?, ?)
                           ON DUPLICATE KEY UPDATE requested_at = NOW(), delete_after = VALUES(delete_after), status = 'closing', hidden = VALUES(hidden), token_hash = VALUES(token_hash), restored_at = NULL, deleted_at = NULL")
                ->execute([$uid, json_encode($hidden), hash('sha256', $token)]);
            $pdo->prepare('UPDATE users SET session_version = session_version + 1, updated_at = NOW() WHERE id = ?')->execute([$uid]);   // signed out everywhere
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('account close ' . $uid . ': ' . $e->getMessage());
            throw new RuntimeException('Your account couldn\'t be closed just now. Nothing was changed. Try again, or email support@traversence.com.');
        }
        $after = (string) (self::closing($pdo, $uid)['delete_after'] ?? '');
        return ['email' => (string) $u['email'], 'delete_after' => $after, 'token' => $token];
    }

    /** Opens a closing account again: what close() hid comes back (where nobody has changed it since). */
    public static function restore(PDO $pdo, int $uid): void
    {
        $c = self::closing($pdo, $uid);
        if (!$c) throw new RuntimeException('There\'s nothing to restore: this account isn\'t closing.');
        $pdo->beginTransaction();
        try {
            foreach ((array) json_decode((string) $c['hidden'], true) as $h) {
                [$t, $idc, $id, $col, $was, $to] = $h + [null, null, null, null, null, null];
                if (!preg_match('/^[a-z_]+$/', (string) $t . $idc . $col)) continue;
                if ($to === 'now') $pdo->prepare("UPDATE `$t` SET `$col` = NULL WHERE `$idc` = ? AND `$col` IS NOT NULL")->execute([$id]);
                else $pdo->prepare("UPDATE `$t` SET `$col` = ? WHERE `$idc` = ? AND `$col` = ?")->execute([$was, $id, $to]);
            }
            $pdo->prepare("UPDATE account_closures SET status = 'restored', restored_at = NOW(), token_hash = NULL WHERE user_id = ?")->execute([$uid]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('account restore ' . $uid . ': ' . $e->getMessage());
            throw new RuntimeException('Your account couldn\'t be restored just now. Try again, or email support@traversence.com.');
        }
    }

    /** Day 30: the full deletion for every closure that's due. Returns how many. */
    public static function sweep(PDO $pdo): int
    {
        if (!self::ready($pdo)) return 0;
        $n = 0;
        foreach (self::q($pdo, "SELECT user_id FROM account_closures WHERE status = 'closing' AND delete_after <= NOW() LIMIT 20", []) as $r) {
            $uid = (int) $r['user_id'];
            try {
                $email = self::run($pdo, $uid);
                $pdo->prepare("UPDATE account_closures SET status = 'deleted', deleted_at = NOW(), token_hash = NULL, hidden = NULL WHERE user_id = ?")->execute([$uid]);
                self::mail($email, 'Your Traversence account is deleted',
                    "The 30 days are up, and your Traversence account has been deleted, as you asked.\n\nYour profile, address book, connections, saved places and settings are gone, "
                    . "and what you wrote (journeys, stories, posts and comments) has been erased.\n\nThank you for being part of Traversence.");
                $n++;
            } catch (Throwable $e) { error_log('account sweep ' . $uid . ': ' . $e->getMessage()); }   // tried again on the next sweep
        }
        return $n;
    }

    /** sweep(), from page loads, at most every 30 minutes. */
    public static function tickSoon(PDO $pdo): void
    {
        $f = dirname(__DIR__) . '/storage/closures.tick';
        $last = @filemtime($f);
        if ($last !== false && $last > time() - 1800) return;
        @touch($f);
        try { self::sweep($pdo); } catch (Throwable $e) { error_log('closures tick: ' . $e->getMessage()); }
    }

    /** Signing in to a closing account: remember who (15 minutes), so /user/restore-account.php can offer Restore. */
    public static function holdForRestore(int $uid): void
    {
        $_SESSION['tv_closing'] = ['uid' => $uid, 'at' => time()];
    }

    public static function mail(string $to, string $subject, string $body): void
    {
        try { require_once __DIR__ . '/Mailer.php'; Mailer::send($to, $subject, $body); } catch (Throwable $e) { error_log('account closure email: ' . $e->getMessage()); }
    }

    private static function user(PDO $pdo, int $uid): ?array
    {
        $r = self::q($pdo, 'SELECT id, email, is_admin FROM users WHERE id = ?', [$uid]);
        return $r[0] ?? null;
    }

    /** A read that returns [] when a table isn't there yet. */
    private static function q(PDO $pdo, string $sql, array $a): array
    {
        try { $st = $pdo->prepare($sql); $st->execute($a); return $st->fetchAll(PDO::FETCH_ASSOC); } catch (PDOException) { return []; }
    }
}
