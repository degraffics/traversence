<?php
// app/admin/comms-console.php — System Configuration → Communications (decisions/0167 §1, §3, §4; 0172 §4.3, §4.6, §4.7):
// where the mail is set up (Pulse is where it's handled). Senders (Check, Send me a test, their settings, a password typed
// or made), every mailbox on every domain of the cPanel account (make, suspend, unsuspend, reset; who oversees it; read it
// in Pulse), routing (each kind of email and its sender), domain health (SPF, DKIM, DMARC, with fixes), message control
// (what's paused, the last 7 days by channel, the Sent view), Amazon SES receiving, Sign in with Microsoft's app keys, and
// the channels: Pulse, email, push (built) and text (its own decision, coming). Every button answers beside itself and
// the page is drawn again in place (js/admin-comms.js); disallowed ones are greyed with the reason.
declare(strict_types=1);

function tv_admin_mod_comms(PDO $pdo): string
{
    require_once __DIR__ . '/../lib/CommsSetup.php';
    require_once __DIR__ . '/../lib/EnvSettings.php';
    require_once __DIR__ . '/../lib/Mailboxes.php';
    require_once __DIR__ . '/../lib/Notify.php';
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    [$canSee, $whySee] = Access::can('config.communications', ['min' => 'manager', 'depts' => []]);
    if (!$canSee) return '<p data-tv-status="info" data-tv-label="Not for you:">' . $e($whySee) . '.</p>';
    [$can, $why] = Access::can('config.communications.manage', ['min' => 'founder', 'depts' => []]);   // owner-level (0167 §3)
    $dis = $can ? '' : ' disabled title="' . $e($why) . '" aria-disabled="true"';
    $btn = fn (string $label, array $body, string $cls = '', string $confirm = '', string $yes = '') => '<button type="button" class="ak-btn' . $cls . '" data-cs="' . $e(json_encode($body)) . '"'
        . ($confirm !== '' ? ' data-confirm="' . $e($confirm) . '" data-yes="' . $e($yes ?: $label) . '"' . (str_contains($cls, 'danger') ? ' data-danger' : '') : '') . $dis . '>' . $e($label) . '</button>';
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $h = '<div id="cs" data-csrf="' . $e($csrf) . '">';
    if (!CommsSetup::ready($pdo)) $h .= '<p data-tv-status="info" data-tv-label="Waiting:">Routing, overseers and the setup log switch on once the site\'s database update runs (within the hour, or open <a href="/admin/config/dbupdates">Database updates</a>). Senders and Check work now.</p>';
    if (!$can) $h .= '<p data-tv-status="info" data-tv-label="Read only:">' . $e($why) . '. Making, resetting and routing are owner-level (decisions/0167 §3).</p>';

    // ---- senders
    $h .= '<h2 class="hb-h" id="cs-senders">Senders</h2><div class="cs-cards">';
    $me = Auth::currentUser();
    foreach (CommsSetup::SENDERS as $k => $d) {
        $s = CommsSetup::sender($k);
        $last = CommsSetup::ready($pdo) ? CommsSetup::lastOf($pdo, $k) : ['sent' => null, 'failed' => null, 'failed_why' => '', 'sent_24h' => 0, 'failed_24h' => 0];
        $h .= '<section class="cs-card tv-bleed" id="cs-' . $e($k) . '"><h3>' . $e($d[0]) . '</h3><p class="ak-note">' . $e($d[3]) . '</p>';
        if ($d[4] === 'coming') { $h .= '<p data-tv-status="info" data-tv-label="Coming:">With the campaigns build.</p></section>'; continue; }
        $h .= '<dl class="cs-dl"><dt>From</dt><dd>' . $e(($s['name'] !== '' ? $s['name'] . ' ' : '') . '<' . $s['address'] . '>') . '</dd>';
        if ($d[4] === 'bluehost') $h .= '<dt>Reply-to</dt><dd>' . $e($s['reply_to']) . '</dd><dt>Signs in as</dt><dd>' . $e($s['login'] ?: 'Not set') . ($s['own_login'] || $d[1] === '' ? '' : ' (the system sender\'s mailbox)') . '</dd>'
            . '<dt>Server</dt><dd>' . $e(($s['host'] ?: 'Not set') . ':' . $s['port']) . '</dd><dt>Password</dt><dd>' . ($s['has_password'] ? 'In .env (never shown)' : 'Not set') . (EnvSettings::hasOld($s['pw_key']) ? ' · an older one kept until Check passes' : '') . '</dd>';
        $h .= '<dt>Last sent</dt><dd>' . ($last['sent'] ? '<time datetime="' . $e($last['sent']) . '" data-tv-time>' . $e($last['sent']) . '</time> · ' . (int) $last['sent_24h'] . ' in 24 h' : 'Nothing logged yet') . '</dd>'
            . '<dt>Last failure</dt><dd>' . ($last['failed'] ? '<time datetime="' . $e($last['failed']) . '" data-tv-time>' . $e($last['failed']) . '</time>: ' . $e($last['failed_why']) : 'None') . '</dd></dl>';
        $h .= '<p class="cs-acts"><button type="button" class="ak-btn" data-cs="' . $e(json_encode(['action' => 'check', 'sender' => $k])) . '">Check</button> <button type="button" class="ak-btn ghost" data-cs="' . $e(json_encode(['action' => 'test', 'sender' => $k])) . '">Send me a test</button>';
        if ($d[4] === 'bluehost') {
            $h .= ' ' . $btn('Edit settings', ['action' => 'fields_open', 'sender' => $k], ' ghost');
            if (EnvSettings::hasOld($s['pw_key'])) $h .= ' ' . $btn('Undo the reset', ['action' => 'undo', 'sender' => $k], ' ghost', 'Put the old password back, in .env and on the mailbox?', 'Put it back');
        } else $h .= ' <a class="ak-btn ghost" href="/admin/config/register#svc-aws" data-peek-frame>Amazon\'s card</a>';
        $h .= '</p>';
        if ($d[4] === 'bluehost') {
            $h .= '<form class="cs-fields" data-cs-form="' . $e(json_encode(['action' => 'fields', 'sender' => $k])) . '" hidden>';
            foreach (CommsSetup::fields($k) as $f => $key) $h .= '<label>' . $e(EnvSettings::EDITABLE[$key][0] ?? $f) . '<input name="' . $e($f) . '" value="' . $e(EnvSettings::value($key)) . '" ' . ($f === 'name' ? 'data-spell' : 'spellcheck="false"') . '><small>' . $e(EnvSettings::EDITABLE[$key][1] ?? '') . '</small></label>';
            $h .= '<label>Its mailbox password <input type="password" name="password" autocomplete="new-password" placeholder="Leave empty to keep it" spellcheck="false"><small>Typed only if you know it; or Reset the mailbox below and the site writes a new one. Never shown back.</small></label>'
                . '<p><button class="ak-btn"' . $dis . '>Save ' . $e(strtolower($d[0])) . '</button></p></form>';
        }
        $h .= '</section>';
    }
    $h .= '</div>';

    // ---- mailboxes on cPanel
    $h .= '<h2 class="hb-h" id="cs-mailboxes">Mailboxes</h2>';
    require_once __DIR__ . '/../lib/CPanel.php';
    if (!CPanel::ready()) $h .= '<p data-tv-status="info" data-tv-label="Not connected:">cPanel\'s API token isn\'t in .env, so the mailboxes can\'t be listed here; the mail itself keeps working from .env. Add CPANEL_HOST, CPANEL_USER and CPANEL_TOKEN (cPanel → Security → Manage API Tokens: sign in at https://my.bluehost.com, then Advanced → cPanel).</p>';
    else {
        try {
            $boxes = CommsSetup::mailboxes($pdo);
            $staff = $pdo->query("SELECT user_id, name FROM " . Database::t('staff_accounts') . " WHERE status = 'active' AND user_id IS NOT NULL ORDER BY name")->fetchAll(PDO::FETCH_KEY_PAIR);
            $read = [];
            if (Mailboxes::ready($pdo)) foreach ($pdo->query("SELECT address, status FROM comms_mailboxes WHERE owner_type = 'system'")->fetchAll(PDO::FETCH_KEY_PAIR) as $a => $st) $read[$a] = $st;
            $h .= '<div class="cs-scroll"><table class="cs-t"><thead><tr><th>Mailbox</th><th>Kind</th><th>Used</th><th>Who reads it in Pulse</th><th>Actions</th></tr></thead><tbody>';
            foreach ($boxes as $b) {
                $ov = implode(', ', array_map(fn ($u) => $staff[$u] ?? ('#' . $u), $b['overseers']));
                $h .= '<tr><td><strong>' . $e($b['email']) . '</strong>' . ($b['suspended'] ? ' <span class="cs-bad">suspended</span>' : '') . '</td><td>' . $e($b['kind'] === 'system' ? 'system (' . CommsSetup::SENDERS[$b['sender']][0] . ')' : ($b['kind'] === 'staff' ? 'staff: ' . $b['staff_name'] : 'inbox')) . '</td>'
                    . '<td>' . $e($b['used'] . ' MB' . ($b['quota'] ? ' of ' . $b['quota'] : '')) . '</td><td>' . $e($ov ?: 'No one') . ' ' . $btn('Change', ['action' => 'overseer_open', 'mailbox' => $b['email']], ' ghost sm')
                    . ' <span class="ak-note">' . (isset($read[$b['email']]) ? 'In Pulse (' . $e($read[$b['email']]) . ')' : '') . '</span></td><td class="cs-acts">'
                    . ($b['suspended'] ? $btn('Unsuspend', ['action' => 'mailbox', 'do' => 'unsuspend', 'email' => $b['email']], ' ghost sm') : $btn('Suspend', ['action' => 'mailbox', 'do' => 'suspend', 'email' => $b['email']], ' ghost sm danger', 'Stop ' . $b['email'] . ' signing in? Its mail is kept; Unsuspend lets it in again.', 'Suspend'))
                    . ' ' . $btn('Reset', ['action' => 'reset_open', 'email' => $b['email']], ' ghost sm')
                    . ' ' . $btn(isset($read[$b['email']]) ? 'Reconnect in Pulse' : 'Read in Pulse', ['action' => 'read_open', 'email' => $b['email']], ' ghost sm') . '</td></tr>';
            }
            $h .= '</tbody></table></div>';
            $h .= '<form class="cs-inline" id="cs-overseer" data-cs-form="' . $e(json_encode(['action' => 'overseer'])) . '" hidden><input type="hidden" name="mailbox"><label>Reads it in their Pulse inbox <select name="user">'
                . implode('', array_map(fn ($u, $n) => '<option value="' . (int) $u . '">' . $e($n) . '</option>', array_keys($staff), $staff)) . '</select></label><label><input type="checkbox" name="on" value="1" checked> Reads it (untick to remove)</label> <button class="ak-btn"' . $dis . '>Save who reads it</button></form>';
            $h .= '<form class="cs-inline" id="cs-reset" data-cs-form="' . $e(json_encode(['action' => 'mailbox', 'do' => 'reset'])) . '" hidden><input type="hidden" name="email"><p class="ak-note" data-cs-label></p>'
                . '<label>New password (optional) <input type="password" name="password" autocomplete="new-password" minlength="12" spellcheck="false" placeholder="Empty: the site makes a strong one"></label>'
                . '<p class="ak-note">Never shown. If a sender signs in with this mailbox, the new password goes straight into .env for it and Check runs at once; the old one is kept until Check passes, so Undo can put it back.</p><button class="ak-btn"' . $dis . '>Reset the password</button></form>';
            $h .= '<form class="cs-inline" id="cs-read" data-cs-form="' . $e(json_encode(['action' => 'read'])) . '" hidden><input type="hidden" name="email"><p class="ak-note" data-cs-label></p>'
                . '<label>Its password <input type="password" name="password" autocomplete="current-password" spellcheck="false" placeholder="Empty: Reset it first, then type the new one here"></label>'
                . '<p class="ak-note">Read by the site over IMAP and sealed in the database; its overseers see it in their Pulse inbox (https://traversence.com/admin/dashboard/inbox).</p><button class="ak-btn"' . $dis . '>Read it in Pulse</button></form>';
            $doms = CommsSetup::domains();
            $h .= '<details class="cs-make"><summary>Make a mailbox</summary><form data-cs-form="' . $e(json_encode(['action' => 'mailbox', 'do' => 'make'])) . '"><label>Address <span class="cs-row"><input name="local" required spellcheck="false" placeholder="hello"> @ <select name="domain">'
                . implode('', array_map(fn ($d) => '<option>' . $e($d) . '</option>', $doms)) . '</select></span></label><label>Password (optional) <input type="password" name="password" autocomplete="new-password" minlength="12" spellcheck="false" placeholder="Empty: the site makes a strong one"></label>'
                . '<p class="ak-note">A staff member\'s own mailbox is made on <a href="/admin/staff.php#mailboxes">Staff logins</a>, because it comes with a login.</p><button class="ak-btn"' . $dis . '>Make it</button></form></details>';
        } catch (Throwable $x) { $h .= '<p data-tv-status="bad" data-tv-label="Error:">cPanel: ' . $e($x->getMessage()) . '</p>'; }
    }

    // ---- routing
    if (CommsSetup::ready($pdo)) {
        $route = CommsSetup::routing($pdo);
        $h .= '<h2 class="hb-h" id="cs-routing">Routing</h2><p class="ak-note">Each kind of email and the sender it goes from. Code asks for a kind, never a sender.</p><div class="cs-scroll"><table class="cs-t"><tbody>';
        foreach (CommsSetup::MAIL_KINDS as $k => [$n, $w]) {
            $h .= '<tr><td><strong>' . $e($n) . '</strong><br><span class="ak-note">' . $e($w) . '</span></td><td><select data-cs-route="' . $e($k) . '" aria-label="Sender for ' . $e($n) . '"' . $dis . '>';
            foreach (CommsSetup::SENDERS as $sk => $sd) $h .= '<option value="' . $e($sk) . '"' . ($route[$k] === $sk ? ' selected' : '') . ($sd[4] === 'coming' ? ' disabled' : '') . '>' . $e($sd[0]) . ($sd[4] === 'coming' ? ' (coming)' : '') . '</option>';
            $h .= '</select></td></tr>';
        }
        $h .= '</tbody></table></div>';
    }

    // ---- domain health
    $h .= '<h2 class="hb-h" id="cs-dns">Domain health</h2>';
    if (CPanel::ready()) {
        $h .= '<details class="cs-lazy" data-cs-lazy="dns"><summary>Read SPF, DKIM and DMARC for our mail domains</summary><div class="cs-lazy-body"><p class="ak-note">Reading through cPanel…</p></div></details>';
    } else $h .= '<p class="ak-note">Needs cPanel\'s API token (above).</p>';

    // ---- message control
    $h .= '<h2 class="hb-h" id="cs-controls">Message control</h2>';
    if (CommsSetup::ready($pdo)) {
        $c = CommsSetup::controls($pdo);
        $paused = array_filter($c, fn ($r) => (int) $r['paused'] === 1);
        $h .= $paused ? '' : '<p data-tv-status="ok" data-tv-label="All flowing:">Nothing is paused.</p>';
        foreach ($paused as $r) $h .= '<p data-tv-status="bad" data-tv-label="Paused:">' . $e($r['ckey']) . ': ' . $e($r['why']) . ' (' . $e($r['display_name'] ?: 'by itself') . ', <time datetime="' . $e($r['changed_at']) . '" data-tv-time>' . $e($r['changed_at']) . '</time>) ' . $btn('Resume', ['action' => 'resume', 'ckey' => $r['ckey']]) . '</p>';
        $h .= '<form class="cs-inline" data-cs-form="' . $e(json_encode(['action' => 'pause'])) . '"><label>Pause <select name="ckey"><option value="channel:email">All email</option><option value="channel:push">All push</option>'
            . implode('', array_map(fn ($k, $d) => '<option value="kind:' . $e($k) . '">' . $e($d[0]) . '</option>', array_keys(Notify::kinds()), Notify::kinds())) . '</select></label><label>Why <input name="why" data-spell maxlength="200" required></label><button class="ak-btn ghost"' . $dis . '>Pause it</button></form>';
        $rep = CommsSetup::report($pdo);
        if ($rep) { $h .= '<p class="ak-note">The last 7 days, by channel and stage:</p><div class="cs-scroll"><table class="cs-t"><tbody>'; foreach ($rep as $r) $h .= '<tr><td>' . $e($r['via']) . '</td><td>' . $e($r['stage']) . '</td><td>' . (int) $r['n'] . '</td></tr>'; $h .= '</tbody></table></div>'; }
        $h .= '<details class="cs-lazy" data-cs-lazy="sent"><summary>Sent: everything the site emailed</summary><div class="cs-lazy-body"></div></details>';
    }

    // ---- outside mail: SES receiving, Microsoft, Gmail
    $h .= '<h2 class="hb-h" id="cs-outside">Mailboxes from outside</h2>';
    require_once __DIR__ . '/../lib/SesInbound.php'; require_once __DIR__ . '/../lib/MsGraphMail.php';
    try { $si = SesInbound::status($pdo); } catch (Throwable) { $si = ['topic' => '', 'rules' => '', 'mx' => '', 'confirmed' => '']; }
    $h .= '<section class="cs-card tv-bleed"><h3>Amazon SES receiving</h3><p class="ak-note">Addresses on ' . $e(SesInbound::DOMAIN) . ' received by Amazon SES, with no mail host, read in Pulse. About $0.10 per 1,000 messages, counted on the route. Mail Bluehost receives for traversence.com and trvgo.us isn\'t touched.</p>'
        . '<p data-tv-status="' . ($si['rules'] && $si['confirmed'] ? 'ok' : 'info') . '" data-tv-label="' . ($si['rules'] ? 'Set up:' : 'Not set up:') . '">' . ($si['rules'] ? 'Rule made ' . $e($si['rules']) . ($si['confirmed'] ? ', subscription confirmed.' : ', waiting for AWS to confirm the subscription.') : 'Nothing received yet.') . '</p>'
        . '<p class="cs-acts">' . $btn($si['rules'] ? 'Set it up again' : 'Set up receiving', ['action' => 'ses_setup'], '', 'Set up Amazon SES receiving for ' . SesInbound::DOMAIN . '? It adds an MX record for that subdomain only.', 'Set it up') . '</p></section>';
    $h .= '<section class="cs-card tv-bleed"><h3>Sign in with Microsoft</h3><p class="ak-note">Microsoft 365 and Outlook.com connect by sign-in (Microsoft no longer takes passwords). Make an app at https://entra.microsoft.com → Applications → App registrations → New registration (any organization and personal accounts), redirect https://traversence.com/api/ms-mail.php, API permissions Mail.ReadWrite, Mail.Send, offline_access, User.Read; then Certificates &amp; secrets → New client secret. Publisher verification is free.</p>'
        . '<p data-tv-status="' . (MsGraphMail::ready() ? 'ok' : 'info') . '" data-tv-label="' . (MsGraphMail::ready() ? 'Ready:' : 'Not set up:') . '">' . (MsGraphMail::ready() ? 'The app\'s keys are in .env.' : 'Add the app\'s keys below.') . '</p>'
        . '<form class="cs-inline" data-cs-form="' . $e(json_encode(['action' => 'ms_keys'])) . '"><label>Application (client) ID <input name="id" spellcheck="false" autocomplete="off"></label><label>Client secret value <input type="password" name="secret" autocomplete="new-password" spellcheck="false"></label><button class="ak-btn"' . $dis . '>Save the keys</button></form></section>';
    [$gok, $gwhy] = Mailboxes::gmailGate($pdo);
    $h .= '<section class="cs-card tv-bleed"><h3>Gmail</h3><p class="ak-note">Gmail and Google Workspace connect by IMAP with an app password now (free). Sign in with Google needs Google\'s yearly security assessment to read mail, so it waits for revenue to cover it (No income, no expense).</p>'
        . '<p data-tv-status="' . ($gok ? 'ok' : 'info') . '" data-tv-label="' . ($gok ? 'Covered:' : 'Waiting:') . '">' . $e($gok ? 'Revenue covers the assessment: Sign in with Google can be built.' : $gwhy) . '</p></section>';

    // ---- channels, and the log
    $h .= '<h2 class="hb-h" id="cs-channels">Channels</h2><ul class="cs-ch"><li><strong>Pulse</strong>: always on; every message lands there.</li><li><strong>Email</strong>: the senders above (Bluehost, and Amazon SES).</li>'
        . '<li><strong>Push</strong>: our own keys, free; each person turns it on for their device in their Communications setting.</li><li><strong>Text</strong>: coming, after its own decision (decisions/0172 §5).</li></ul>';
    if (CommsSetup::ready($pdo) && ($hist = CommsSetup::history($pdo, 20))) {
        $h .= '<details><summary>Changes made here</summary><ul class="cs-ch">';
        foreach ($hist as $r) $h .= '<li><time datetime="' . $e($r['created_at']) . '" data-tv-time>' . $e($r['created_at']) . '</time> · ' . $e($r['display_name'] ?: 'the site') . ': ' . $e(str_replace('_', ' ', $r['what'])) . ' ' . $e($r['target']) . ($r['detail'] !== '' ? ' (' . $e($r['detail']) . ')' : '') . '</li>';
        $h .= '</ul></details>';
    }
    $h .= '</div>';
    $h .= '<style>#cs .cs-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(19rem,1fr));gap:.75rem}#cs .cs-card{border:1px solid #CBB98D;border-radius:.5rem;padding:.75rem;background:#FFFBF2;margin:.5rem 0}#cs .cs-card h3{margin:0 0 .25rem}'
        . '#cs .cs-dl{display:grid;grid-template-columns:auto 1fr;gap:.15rem .6rem;font-size:.9rem;margin:.4rem 0}#cs .cs-dl dt{color:#8A7355}#cs .cs-dl dd{margin:0;overflow-wrap:anywhere}#cs .cs-acts{display:flex;flex-wrap:wrap;gap:.35rem}'
        . '#cs .cs-scroll{overflow-x:auto}#cs .cs-t{width:100%;border-collapse:collapse;font-size:.9rem}#cs .cs-t td,#cs .cs-t th{border-bottom:1px solid #EADFC4;padding:.35rem;text-align:left;vertical-align:top}#cs .cs-bad{color:#B91C1C;font-weight:700}'
        . '#cs form label{display:block;margin:.35rem 0}#cs form input:not([type=checkbox]),#cs form select{width:100%;max-width:28rem;box-sizing:border-box}#cs form small{display:block;color:#8A7355}#cs .cs-row{display:flex;gap:.3rem;align-items:center}'
        . '#cs .cs-inline{border:1px dashed #CBB98D;border-radius:.5rem;padding:.6rem;margin:.5rem 0}#cs .cs-ch{padding-left:1.1rem}'
        . '@media (max-width:767px){#cs .cs-cards{grid-template-columns:1fr}#cs .cs-t thead{display:none}#cs .cs-t tr{display:block;border-bottom:1px solid #EADFC4;padding:.3rem 0}#cs .cs-t td{display:block;border:0;padding:.15rem .2rem}}</style>'
        . '<script src="/js/admin-comms.js" defer></script>';
    return $h;
}

/** The lazy parts (opened on demand): domain health, and the Sent view. */
function tv_comms_lazy(PDO $pdo, string $part): string
{
    require_once __DIR__ . '/../lib/CommsSetup.php';
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    [$can, $why] = Access::can('config.communications.manage', ['min' => 'founder', 'depts' => []]);
    if ($part === 'dns') {
        $h = '<div class="cs-scroll"><table class="cs-t"><tbody>';
        foreach (CommsSetup::domainHealth() as [$dom, $what, $ok, $found, $fix]) {
            $h .= '<tr><td>' . $e($dom) . '</td><td>' . $e($what) . '</td><td><span data-tv-status="' . ($ok ? 'ok' : 'bad') . '">' . $e($found) . '</span></td><td>'
                . (!$ok && $fix ? '<button type="button" class="ak-btn sm" data-cs="' . $e(json_encode(['action' => 'dnsfix', 'domain' => $dom, 'what' => $what])) . '"' . ($can ? '' : ' disabled title="' . $e($why) . '"') . '>Fix ' . $e($what) . '</button>' : '') . '</td></tr>';
        }
        return $h . '</tbody></table></div>';
    }
    if ($part === 'sent') {
        $rows = CommsSetup::sent($pdo, (string) ($_GET['q'] ?? ''), (string) ($_GET['stage'] ?? ''), 100);
        if (!$rows) return '<p class="ak-note">Nothing sent is logged yet.</p>';
        $h = '<div class="cs-scroll"><table class="cs-t"><thead><tr><th>When</th><th>Sender</th><th>Subject</th><th>How it went</th></tr></thead><tbody>';
        foreach ($rows as $r) $h .= '<tr><td><time datetime="' . $e($r['happened_at']) . '" data-tv-time>' . $e($r['happened_at']) . '</time></td><td>' . $e($r['sender_key'] ?: $r['kind']) . '</td><td>' . $e($r['subject']) . '</td><td' . ($r['stage'] === 'failed' ? ' class="cs-bad"' : '') . '>' . $e($r['stage']) . ': ' . $e($r['detail']) . '</td></tr>';
        return $h . '</tbody></table></div>';
    }
    return '';
}
