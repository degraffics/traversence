<?php
// app/lib/ServiceStages.php — each outside service's stage (decisions/0173 §2): Proposed, Added off, Key in, Active, Paused,
// Retired, Removed. A stage comes from what's true now (Automation's switch, its keys, the retired records), never a word
// typed in; each change is logged here with who, when and why (service_stages), the switch's own presses included
// (Automation::set writes here too), so a card's history is one list.
declare(strict_types=1);

final class ServiceStages
{
    /** stage => [its word, 0169 §5's step, what it means]. */
    public const STAGES = [
        'proposed' => ['Proposed', 'Choose', 'Named on the register as a build request; no code calls it.'],
        'added'    => ['Added', 'Install', 'A release shipped it; it waits for its key (and, if it shipped off, for a person to activate it).'],
        'keyin'    => ['Key in', 'Configure', 'Its key is in place; it waits, paused, for a person to activate it.'],
        'active'   => ['Active', 'Use', 'Called by its workflows, inside its caps and paces.'],
        'paused'   => ['Paused', 'Update', 'Nothing of ours calls it until it\'s activated again; its key stays.'],
        'retired'  => ['Retired', 'Remove', 'Kept as a record: nothing calls it, and the card says why and what replaced it.'],
        'removed'  => ['Removed', 'Remove', 'Its code and key are gone; the record stays.'],
    ];

    /** The register's tone for each stage (the admin's one status look). */
    public const TONE = ['proposed' => 'info', 'added' => 'info', 'keyin' => 'info', 'active' => 'ok', 'paused' => 'info', 'retired' => 'info', 'removed' => 'info'];

    /**
     * Retired services that have no card of their own (decisions/0173 §4: Overpass is the first record). key => [name, why,
     * what replaced it, when, where it was said]. OpenStreetMap itself stays Active: our copy, the tiles and the credit.
     */
    public const RETIRED = [
        'overpass' => ['Overpass (OpenStreetMap\'s live query server)',
            'Its community asked, on its forum, that its public servers not be used as a back end for apps and websites (release #204).',
            'our own copy from Geofabrik (Arizona, New Mexico, Utah, Colorado and Nevada)', '2026-11-19',
            'https://community.openstreetmap.org/t/150369'],
    ];

    /**
     * A service's stage now: [stage, words]. $keys is Operations::keys() for it ([[name, where, present|null]]), $off its
     * paused line (Automation::serviceOff) or null, $addedOff whether it shipped paused (Operations::ADDED_OFF).
     */
    public static function decide(array $keys, ?string $off, bool $addedOff, bool $everActive): array
    {
        $missing = array_values(array_filter($keys, fn ($k) => $k[2] === false));
        if ($off !== null) {
            if ($addedOff && !$everActive) return $missing ? ['added', 'Off, waiting for its key: ' . implode(', ', array_column($missing, 0)) . '.'] : ['keyin', 'Its key is in place; it waits for Activate.'];
            return ['paused', $off];
        }
        if ($missing) return ['added', 'Switched on, but its key isn\'t in place yet: ' . implode(', ', array_column($missing, 0)) . '. Nothing can call it until it is.'];
        return ['active', $keys ? 'Its key is in place and it\'s switched on.' : 'Needs no key; it\'s switched on.'];
    }

    /** Every service's stage for the register: key => [stage, words]. One read of the log for "ever active". */
    public static function all(PDO $pdo): array
    {
        require_once __DIR__ . '/Operations.php'; require_once __DIR__ . '/Automation.php'; require_once __DIR__ . '/OutsideServices.php';
        $was = [];
        // switched on by a person at some point: Automation's own log reaches back before this table
        try { foreach ($pdo->query("SELECT DISTINCT ref FROM automation_log WHERE kind = 'service' AND paused = 0")->fetchAll(PDO::FETCH_COLUMN) as $s) $was[(string) $s] = true; } catch (Throwable $x) {}
        try { foreach ($pdo->query("SELECT DISTINCT service FROM service_stages WHERE stage = 'active'")->fetchAll(PDO::FETCH_COLUMN) as $s) $was[(string) $s] = true; } catch (Throwable $x) {}
        $out = [];
        foreach (array_keys(OutsideServices::COMPANIES) as $k)
            $out[$k] = self::decide(Operations::keys($k), Automation::serviceOff($pdo, $k), in_array($k, Operations::ADDED_OFF, true), isset($was[$k]));
        return $out;
    }

    /** One change, logged: never a key or its value, only who, when, which stage and why. */
    public static function log(PDO $pdo, string $svc, string $stage, string $why, int $uid, string $who, string $replacedBy = ''): void
    {
        if (!isset(self::STAGES[$stage])) throw new InvalidArgumentException('Unknown stage.');
        try {
            $pdo->prepare('INSERT INTO service_stages (service, stage, why, replaced_by, by_uid, by_name, at) VALUES (?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())')
                ->execute([mb_substr($svc, 0, 40), $stage, mb_substr(trim($why), 0, 255) ?: null, mb_substr($replacedBy, 0, 255) ?: null, $uid ?: null, mb_substr($who, 0, 80) ?: null]);
        } catch (Throwable $x) { error_log('service stages: ' . $x->getMessage()); }   // its table comes with the release's database update
    }

    /** A service's changes, newest first. */
    public static function history(PDO $pdo, string $svc, int $n = 8): array
    {
        try { $st = $pdo->prepare('SELECT * FROM service_stages WHERE service = ? ORDER BY id DESC LIMIT ' . max(1, min(50, $n))); $st->execute([$svc]); return $st->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $x) { return []; }
    }
}
