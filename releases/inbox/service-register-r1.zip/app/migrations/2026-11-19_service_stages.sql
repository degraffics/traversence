-- decisions/0173 §2: each outside service's stage changes, with who, when and why (never a key or its value).
-- Safe to run twice: the table only if missing, Overpass's retirement only if it isn't recorded yet.
CREATE TABLE IF NOT EXISTS service_stages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  service VARCHAR(40) NOT NULL,
  stage VARCHAR(16) NOT NULL,
  why VARCHAR(255) DEFAULT NULL,
  replaced_by VARCHAR(255) DEFAULT NULL,
  by_uid INT UNSIGNED DEFAULT NULL,
  by_name VARCHAR(80) DEFAULT NULL,
  at DATETIME NOT NULL,
  KEY service_id (service, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO service_stages (service, stage, why, replaced_by, by_uid, by_name, at)
  SELECT 'overpass', 'retired', 'Its community asked, on its forum, that its public servers not be used as a back end for apps and websites (release #204).',
         'Our own copy from Geofabrik', NULL, 'Release #204', '2026-11-19 21:45:00'
  FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM service_stages WHERE service = 'overpass' AND stage = 'retired');
