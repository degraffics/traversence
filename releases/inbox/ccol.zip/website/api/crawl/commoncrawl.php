<?php
// api/crawl/commoncrawl.php — the worker's Common Crawl step (decisions/0157 §8.3): the public archive's newest crawl, read
// for us without touching the sites. Free.
//   GET ?crawl=CC-MAIN-2026-44  -> {discover: [states whose local public sites to list this crawl], hosts: [{host, read: [urls
//        already read from this crawl]}]}   (sources we read regularly not yet read from this crawl, at most 3)
//   POST {state, crawl, discovered: [{url, text}]}  -> {new_sites}   the sites under az.us, nm.us … it captured: onto the register
//   POST {host, crawl, done, facts, log, outlinks}  -> {kept, new_sites}   a source's pages read from the archive
//   GET also answers {urlmap: {files, map}}: the crawl's URL Index file map, read a few files a run and kept here, so the
//        runs every few minutes never read it again (decisions/0164's note of 2026-11-20; Common Crawl's terms §2(f))
//   POST {crawl, urlmap: {file: [lowest, highest host key]}, files: [...]}  -> {have}   more of that map
declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/crawler/SourceIndex.php';
require_once __DIR__ . '/../../../app/lib/crawler/NpiBulk.php';
require_once __DIR__ . '/../../../app/lib/PageCache.php';

$crawlOk = fn (string $c): bool => (bool) preg_match('/^CC-MAIN-\d{4}-\d{2}$/', $c);
Sources::ensureJudge($pdo);
SourceIndex::ensure($pdo);
$R = Database::t('reference_sources');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $crawl = (string) ($_GET['crawl'] ?? '');
    if (!$crawlOk($crawl) || CrawlQueue::paused()) Response::json(['ok' => true, 'discover' => [], 'hosts' => []]);
    // our states' local public sites, once a crawl each
    $discover = array_values(array_filter(NpiBulk::STATES, fn ($st) => !PageCache::get($pdo, 'cc:disc:' . $crawl . ':' . $st)));
    $hosts = [];
    try {
        $st = $pdo->prepare("SELECT host FROM $R WHERE status = 'read' AND (cc_crawl IS NULL OR cc_crawl <> ?) ORDER BY cc_crawl IS NULL DESC, confirmations DESC, id LIMIT 3");
        $st->execute([$crawl]);
        $read = $pdo->prepare('SELECT url FROM ' . Database::t('crawl_pages') . " WHERE host = ? AND via = 'commoncrawl' AND fetched_at > NOW() - INTERVAL 35 DAY LIMIT 500");
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $h) {
            $read->execute([(string) $h]);
            $hosts[] = ['host' => (string) $h, 'read' => $read->fetchAll(PDO::FETCH_COLUMN)];
        }
    } catch (Throwable $e) { error_log('commoncrawl hosts: ' . $e->getMessage()); }
    $map = PageCache::get($pdo, 'cc:map:' . $crawl);
    Response::json(['ok' => true, 'discover' => $discover, 'hosts' => $hosts, 'urlmap' => is_array($map) ? $map : (object) []]);
}

Response::requireMethod('POST');
$b = Response::jsonBody();
$crawl = (string) ($b['crawl'] ?? '');
if (!$crawlOk($crawl)) Response::error('Which crawl?', 422);

if (isset($b['urlmap'])) {   // more of the crawl's URL Index file map: file => [lowest, highest host key], kept 60 days
    $map = PageCache::get($pdo, 'cc:map:' . $crawl); $map = is_array($map) ? $map : ['files' => [], 'map' => []];
    $files = array_values(array_filter(array_map('strval', (array) ($b['files'] ?? [])), fn ($f) => (bool) preg_match('#^[\w./=-]{1,300}\.parquet$#', $f)));
    if ($files) $map['files'] = array_slice($files, 0, 2000);
    foreach ((array) $b['urlmap'] as $f => $r) {
        if (!in_array((string) $f, $map['files'], true) || !is_array($r) || count($r) !== 2) continue;
        $map['map'][(string) $f] = [mb_substr((string) $r[0], 0, 120), mb_substr((string) $r[1], 0, 120)];
    }
    PageCache::put($pdo, 'cc:map:' . $crawl, 60 * 86400, $map);
    Response::json(['ok' => true, 'have' => count($map['map']), 'of' => count($map['files'])]);
}

if (isset($b['state'])) {
    $st = strtoupper((string) $b['state']);
    if (!in_array($st, NpiBulk::STATES, true)) Response::error('Not one of our states.', 422);
    $n = Sources::addLinked($pdo, (array) ($b['discovered'] ?? []), 'Common Crawl (' . strtolower($st) . '.us)', 400);
    PageCache::put($pdo, 'cc:disc:' . $crawl . ':' . $st, 60 * 86400, 1);
    Response::json(['ok' => true, 'new_sites' => $n]);
}

$host = (string) ($b['host'] ?? '');
$h = Sources::host('https://' . preg_replace('#^https?://#i', '', $host));
$ok = $pdo->prepare("SELECT 1 FROM $R WHERE host = ? AND status = 'read'"); $ok->execute([$h]);
if (!$ok->fetchColumn()) Response::error('Not a source we read.', 422);   // only what the register says we read
$kept = SourceIndex::storeMore($pdo, $h, (array) ($b['facts'] ?? []), (array) ($b['log'] ?? []));
$new = !empty($b['outlinks']) ? Sources::addLinked($pdo, (array) $b['outlinks'], $h) : 0;
if (!empty($b['done'])) $pdo->prepare("UPDATE $R SET cc_crawl = ? WHERE host = ?")->execute([$crawl, $h]);
Response::json(['ok' => true, 'kept' => $kept, 'new_sites' => $new]);
