<?php
// app/lib/ControlLedger.php — the System Control Board's sensors (decisions/0171 §4, release 2a; Jason, 2026-11-18:
// "neither of them, especially START, does not include endpoints or a way to see what data is being captured and or
// stored"). Every call a worker makes to the site (/api/crawl/*, /api/video/*) leaves one row in control_ledger: what it
// handed out, received, stored, updated, sent to Review and refused (refusals counted by reason), its answer code, how
// long it took and the crawler run it belonged to. The ids of the records it touched go to control_records (at most
// control_records_per_call; beyond that, the count), so a run opens to what it brought in.
//
// How: the endpoints' shared _auth.php calls begin() once the worker is signed in. It keeps the answer in a buffer, and
// after the endpoint has answered (a shutdown function, before the buffer is sent) the row is written from the request,
// the answer and what the libraries marked with touched() on the way (IntakeStager::stage: a Review item or a listing;
// CrawlerIngest::upsertMetadataKey: a listing's field). No endpoint changes; a new one is measured by itself. It never
// changes the answer and never stops the call: a failure here is logged and forgotten.
// Ids and counts only, never a person's name, email, phone or a page's text. Kept control_ledger_days and
// control_records_days (Thresholds), trimmed in small batches. Release 2b draws it on the board.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class ControlLedger
{
    /** Request keys that aren't records (the worker's log, its own checks, the run report's items). */
    private const NOT_RECORDS = ['log', 'checked', 'items', 'calls', 'issues', 'keys', 'holds', 'probes', 'errors', 'plan'];
    /** Answer keys => what they count. */
    private const COUNTS = [
        'stored' => ['stored', 'added', 'kept', 'inserted', 'imported', 'auto_imported', 'created', 'saved', 'loaded'],
        'review' => ['staged', 'to_review', 'review'],
        'updated' => ['updated', 'filled', 'applied', 'refreshed', 'changed', 'merged'],
        'refused' => ['refused', 'already_known', 'skipped', 'rejected', 'dropped', 'junk', 'held', 'duplicates'],
    ];

    private static ?array $on = null;      // the call being measured: [pdo, endpoint, t0, method]
    private static array $touched = [];    // [kind, id, what]
    private static int $over = 0;          // touched beyond the cap: counted only
    private static array $at = [];         // kind:id => its line in $touched

    /** Starts measuring this call (from _auth.php once the worker is signed in). */
    public static function begin(PDO $pdo, string $endpoint): void
    {
        if (self::$on !== null) return;
        self::$on = [$pdo, mb_substr($endpoint, 0, 40), microtime(true), (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')];
        ob_start();
        register_shutdown_function([self::class, 'finish']);
    }

    /** A record this call touched: kind (listing, review, …), its id, what happened (stored, updated: phone, to Review). */
    public static function touched(string $kind, int $id, string $what): void
    {
        if (self::$on === null || $id <= 0) return;
        // one line per record: a listing whose fields were written one by one is one "updated: phone, website"; stored
        // (new) outranks updated, and a field kept because a person entered it stays named
        $k = $kind . ':' . $id;
        if (isset(self::$at[$k])) {
            $i = self::$at[$k]; $was = self::$touched[$i][2];
            if (str_starts_with($what, 'refused') && !str_starts_with($was, 'refused')) $what = $was . '; ' . substr($what, 9);   // a field kept on a record otherwise written
            elseif (str_starts_with($what, 'stored') || str_starts_with($was, 'stored')) $what = 'stored';
            elseif (str_starts_with($what, 'updated: ') && str_starts_with($was, 'updated: ')) $what = $was . (str_contains($was, substr($what, 9)) ? '' : ', ' . substr($what, 9));
            self::$touched[$i][2] = mb_substr($what, 0, 60);
            return;
        }
        if (count(self::$touched) >= 2000) { self::$over++; return; }   // a hard ceiling; the setting trims further when written
        self::$at[$k] = count(self::$touched);
        self::$touched[] = [mb_substr($kind, 0, 20), $id, mb_substr($what, 0, 60)];
    }

    /** Is a call being measured (for libraries that would do extra work only then)? */
    public static function active(): bool { return self::$on !== null; }

    private static function isList(array $a): bool
    {
        $i = 0;
        foreach ($a as $k => $_) { if ($k !== $i++) return false; }
        return true;
    }

    /** Items in a JSON object's top-level lists of records. */
    private static function listed($j): int
    {
        if (!is_array($j)) return 0;
        $n = 0;
        foreach ($j as $k => $v) {
            if (!is_string($k) || in_array($k, self::NOT_RECORDS, true) || !is_array($v) || !$v || !self::isList($v)) continue;
            if (is_array($v[0]) || is_string($v[0])) $n += count($v);
        }
        return $n;
    }

    /** The answer's counts: [stored, review, updated, refused, reasons]. */
    public static function counts($answer): array
    {
        $out = ['stored' => 0, 'review' => 0, 'updated' => 0, 'refused' => 0];
        $reasons = [];
        if (!is_array($answer)) return $out + ['reasons' => $reasons];
        foreach (self::COUNTS as $col => $keys) foreach ($keys as $k) {
            if (!array_key_exists($k, $answer)) continue;
            $v = $answer[$k];
            $n = is_int($v) ? $v : (is_array($v) ? count($v) : (is_numeric($v) ? (int) $v : 0));
            if ($n <= 0) continue;
            $out[$col] += $n;
            if ($col === 'refused') $reasons[str_replace('_', ' ', $k)] = $n;
        }
        return $out + ['reasons' => $reasons];
    }

    /** After the endpoint has answered: its row, and the records it touched. */
    public static function finish(): void
    {
        if (self::$on === null) return;
        [$pdo, $ep, $t0, $method] = self::$on;
        self::$on = null;
        try {
            $ms = (int) round((microtime(true) - $t0) * 1000);
            $code = (int) (http_response_code() ?: 200);
            $answer = json_decode((string) ob_get_contents(), true);
            $request = $method === 'GET' ? null : json_decode((string) file_get_contents('php://input'), true);
            $c = self::counts($answer);
            // what the libraries marked is the record of what happened; the answer's counts fill what they didn't mark
            $by = ['stored' => 0, 'review' => 0, 'updated' => 0, 'refused' => 0];
            foreach (self::$touched as [, , $what]) { $w = strtok($what, ':'); if (isset($by[$w])) $by[$w]++; }
            if ($by['stored'] + $by['review'] + $by['updated'] > 0) foreach (['stored', 'review', 'updated'] as $col) $c[$col] = $by[$col];
            if ($by['refused'] > 0) { $c['refused'] += $by['refused']; $c['reasons']['kept what a person entered'] = $by['refused']; }
            $received = self::listed($request);
            $sent = $method === 'GET' || $received === 0 ? self::listed($answer) : 0;
            $reasons = [];
            foreach ($c['reasons'] as $k => $n) $reasons[] = $k . ': ' . $n;
            if ($code >= 400 && is_array($answer) && isset($answer['error'])) $reasons[] = 'answered ' . $code . ': ' . (is_string($answer['error']) ? $answer['error'] : json_encode($answer['error']));
            // what an endpoint set aside with its error (Verify::lease, 2026-11-18): kept, so a hidden failure shows on the board
            if (is_array($answer) && is_array($answer['set_aside'] ?? null)) foreach (array_slice($answer['set_aside'], 0, 5) as $sa) $reasons[] = 'set aside #' . (int) ($sa['row_id'] ?? 0) . ': ' . (string) ($sa['error'] ?? '');
            $runId = null;
            if (str_starts_with($ep, 'crawl/')) {
                try { $r = $pdo->query("SELECT id FROM crawl_runs WHERE status = 'running' AND started_at >= NOW() - INTERVAL 40 MINUTE ORDER BY id DESC LIMIT 1")->fetchColumn(); $runId = $r !== false ? (int) $r : null; } catch (Throwable $x) {}
            }
            $cap = 500;
            try { require_once __DIR__ . '/Thresholds.php'; $cap = max(0, (int) Thresholds::get($pdo, 'control_records_per_call')); } catch (Throwable $x) {}
            $keep = array_slice(self::$touched, 0, $cap);
            $pdo->prepare('INSERT INTO control_ledger (at, endpoint, method, code, ms, run_id, n_sent, n_received, n_stored, n_updated, n_review, n_refused, reasons, records) VALUES (UTC_TIMESTAMP(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$ep, mb_substr($method, 0, 6), $code, $ms, $runId, $sent, $received, $c['stored'], $c['updated'], $c['review'], $c['refused'], $reasons ? mb_substr(implode('; ', $reasons), 0, 500) : null, count(self::$touched) + self::$over]);
            $id = (int) $pdo->lastInsertId();
            if ($keep) {
                $rows = []; $args = [];
                foreach ($keep as [$kind, $ref, $what]) { $rows[] = '(?, UTC_TIMESTAMP(), ?, ?, ?)'; array_push($args, $id, $kind, $ref, $what); }
                $pdo->prepare('INSERT INTO control_records (ledger_id, at, kind, ref_id, what) VALUES ' . implode(', ', $rows))->execute($args);
            }
            if (random_int(1, 200) === 1) self::trim($pdo);
        } catch (Throwable $x) {
            if (!str_contains($x->getMessage(), "doesn't exist")) error_log('ControlLedger: ' . $x->getMessage());   // before its database update has run: nothing to record yet
        } finally {
            self::$touched = []; self::$over = 0; self::$at = [];
        }
    }

    /** Rows past their days, in small batches. */
    public static function trim(PDO $pdo): void
    {
        require_once __DIR__ . '/Thresholds.php';
        $d1 = max(1, (int) Thresholds::get($pdo, 'control_ledger_days'));
        $d2 = max(1, (int) Thresholds::get($pdo, 'control_records_days'));
        $pdo->exec('DELETE FROM control_records WHERE at < UTC_TIMESTAMP() - INTERVAL ' . $d2 . ' DAY LIMIT 5000');
        $pdo->exec('DELETE FROM control_ledger WHERE at < UTC_TIMESTAMP() - INTERVAL ' . $d1 . ' DAY LIMIT 5000');
    }

    /** A crawler run's calls and the records they touched (for the board and the crawler console, release 2b). */
    public static function forRun(PDO $pdo, int $runId): array
    {
        $st = $pdo->prepare('SELECT * FROM control_ledger WHERE run_id = ? ORDER BY id'); $st->execute([$runId]);
        $calls = $st->fetchAll(PDO::FETCH_ASSOC);
        $recs = [];
        if ($calls) {
            $ids = implode(',', array_map(fn ($c) => (int) $c['id'], $calls));
            $recs = $pdo->query('SELECT ledger_id, kind, ref_id, what FROM control_records WHERE ledger_id IN (' . $ids . ') ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
        }
        return ['calls' => $calls, 'records' => $recs];
    }
}
