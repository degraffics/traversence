<?php

declare(strict_types=1);

require_once __DIR__ . '/AutoImport.php';
require_once __DIR__ . '/../PageCache.php';
require_once __DIR__ . '/Sources.php';
require_once __DIR__ . '/SourceIndex.php';
require_once __DIR__ . '/NpiBulk.php';
require_once __DIR__ . '/IrsBulk.php';
require_once __DIR__ . '/DeepLook.php';
require_once __DIR__ . '/../ListingSafety.php';

/**
 * api/lib/crawler/Verify.php — second look at listings waiting for review (decisions/0044).
 *
 * The off-site worker takes staged listings that have fewer than the references auto-import needs,
 * looks each one up by name, address and city in the NPI Registry (health-care providers) and, with a
 * search key, on the web (chamber of commerce listings, well-known directories, government pages,
 * the place's own website), and sends back every page that names the place AND shows its street
 * address or phone. The site decides what that is worth:
 *   - an NPI Registry match is a trusted registry (guardrail 1 on its own), +20 confidence;
 *   - each other independent website adds +10 (at most +40 in all), weighed by its record (decisions/0157 §5): +15 for a
 *     site whose finds were borne out nine times in ten, +5 or nothing for one often shown wrong.
 * Then the four guardrails run again: it publishes if they pass, or stays in Quick approve with its
 * references listed. Each listing is verified once; a lease stops two runs checking the same one.
 */
final class Verify
{
    public const KINDS = ['registry' => 'registry', 'chamber' => 'chamber of commerce', 'directory' => 'directory',
                          'government' => 'government', 'own_site' => 'own website', 'website' => 'website', 'open_data' => 'open data',
                          // Google's place at the find's address: the paid backup, only by a director's override (PaidOverride); it
                          // raises the find's confidence, never makes it keepable (AutoImport::isGoogleHost; Jason, 2026-11-17)
                          'google' => 'Google Maps (paid backup)'];
    private const LEASE_MINUTES = 20;
    private const MAX_ATTEMPTS = 3;
    private const MAX_BUMP = 40;
    private const DEEP_PER_CALL = 3;   // deeper looks per lease call (they reach outside)

    /**
     * The next staged listings to verify, leased to the caller.
     * @return list<array<string,mixed>>
     */
    public static function lease(PDO $pdo, int $limit): array
    {
        $limit = max(1, min(20, $limit));
        $st = $pdo->query("SELECT id, raw_payload FROM " . Database::t('crawler_raw_index') . "
                            WHERE status = 'staged' AND payload_type = 'listing'
                            ORDER BY confidence_score DESC, id ASC LIMIT 500");
        $now = time();
        $out = [];
        $deep = 0;   // deeper looks this call (they reach outside: a few at a time)
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            if (count($out) >= $limit) break;
            // each listing on its own (2026-11-18: one listing that threw failed every W2 run with a hidden 500): its
            // error is kept on it, it's set aside 6 hours, and the rest go to the worker
            try {
            $c = json_decode((string) $row['raw_payload'], true);
            if (!is_array($c)) continue;
            // the deeper look (decisions/0076), for any waiting listing that isn't ready, already looked up or not:
            // OpenStreetMap as a second reference, and the business's own website
            if (empty($c['deep']['at']) && $deep < self::DEEP_PER_CALL && isset($c['geo']['latitude']) && !self::confidential($c) && !AutoImport::evaluate($c)['eligible']) {
                $deep++;
                $d = DeepLook::look($pdo, $c);
                $c['deep'] = ['at' => date('c'), 'checked' => $d['checked'], 'found' => count($d['found'])];
                if ($d['moved']) $c['moved'] = $d['moved'];
                if ($d['hours'] && empty($c['when']['hours'])) $c['when']['hours'] = $d['hours'];
                if ($d['website'] !== '' && empty($c['leads']['website'])) $c['leads']['website'] = $d['website'];   // a pointer only (ODbL)
                self::save($pdo, (int) $row['id'], $c);
                if ($d['found']) {
                    $done = !empty($c['verify']['done_at']);
                    $r = self::complete($pdo, (int) $row['id'], $d['found'], $d['checked']);
                    if ($r['auto_imported']) continue;
                    $st2 = $pdo->prepare('SELECT raw_payload FROM ' . Database::t('crawler_raw_index') . ' WHERE id = ?');
                    $st2->execute([(int) $row['id']]);
                    $c = json_decode((string) $st2->fetchColumn(), true);
                    if (!$done) { unset($c['verify']['done_at']); self::save($pdo, (int) $row['id'], $c); }   // not ready yet: the worker's web search still takes its turn
                }
            }
            if (!self::wanted($c, $now)) continue;
            // Our own sources first (decisions/0045): free, and if they confirm it, no paid search at all.
            if (empty($c['verify']['index_at'])) {
                $found = SourceIndex::matches($pdo, $c, AutoImport::sourceHosts($c));
                // Our own copy of the NPI Registry (decisions/0048): a trusted registry, no web call.
                if (($c['source']['kind'] ?? '') !== 'npi_bulk' && !in_array('npi', (array) ($c['registries'] ?? []), true)) {
                    $found = array_merge($found, NpiBulk::matches($pdo, $c));
                }
                $found = array_merge($found, IrsBulk::matches($pdo, $c));   // the IRS nonprofit list: a government reference
                if ($found) {
                    $r = self::complete($pdo, (int) $row['id'], $found, ['sources']);
                    if ($r['auto_imported']) continue;
                    $st2 = $pdo->prepare('SELECT raw_payload FROM ' . Database::t('crawler_raw_index') . ' WHERE id = ?');
                    $st2->execute([(int) $row['id']]);
                    $c = json_decode((string) $st2->fetchColumn(), true);
                    unset($c['verify']['done_at']);        // not confirmed yet: the worker still takes a look
                }
                $c['verify']['index_at'] = date('c');
                if (!self::wanted($c, $now)) { self::save($pdo, (int) $row['id'], $c); continue; }
            }
            if (self::confidential($c)) {   // a confidential service (decisions/0076, 0133): our own records only, never sent to a search or map service
                $c['verify'] = array_merge((array) ($c['verify'] ?? []), ['done_at' => date('c'), 'note' => 'A confidential service: checked in our own records only, never sent outside.']);
                self::save($pdo, (int) $row['id'], $c);
                continue;
            }
            $c['verify'] = array_merge((array) ($c['verify'] ?? []), [
                'leased_until' => date('c', $now + self::LEASE_MINUTES * 60),
                'attempts' => (int) ($c['verify']['attempts'] ?? 0) + 1,
            ]);
            self::save($pdo, (int) $row['id'], $c);
            $out[] = self::describe((int) $row['id'], $c);
            } catch (InvalidArgumentException $x) {
                continue;   // it moved on while we looked (taken, imported or gone): nothing wrong
            } catch (Throwable $x) {
                $why = mb_substr(get_class($x) . ': ' . $x->getMessage(), 0, 300);
                error_log('Verify::lease row ' . (int) $row['id'] . ': ' . $why);
                self::$problems[(int) $row['id']] = $why;
                try {
                    $c2 = json_decode((string) $row['raw_payload'], true) ?: [];
                    $c2['verify'] = array_merge((array) ($c2['verify'] ?? []), ['leased_until' => date('c', $now + 6 * 3600), 'error' => $why, 'error_at' => date('c')]);
                    self::save($pdo, (int) $row['id'], $c2);
                } catch (Throwable $y) {}
            }
        }
        return $out;
    }

    /** The listings lease() set aside this call: row id => the error, in words (the endpoint says them; the ledger keeps them). */
    public static array $problems = [];

    /** A confidential service (a shelter, a safe house): by any category it's suggested for, or by its name. */
    private static function confidential(array $c): bool
    {
        foreach ((array) ($c['category_suggestions'] ?? []) as $s) if (ListingSafety::isConfidential((int) ($s['id'] ?? 0) ?: null, null)) return true;
        return ListingSafety::isConfidential(isset($c['category_id']) ? (int) $c['category_id'] : null, (string) ($c['name'] ?? ''));
    }

    /** Not yet verified, not leased right now, not given up on, and something to check it against. */
    private static function wanted(array $c, int $now): bool
    {
        $v = (array) ($c['verify'] ?? []);
        if (!empty($v['done_at'])) return false;
        if ((int) ($v['attempts'] ?? 0) >= self::MAX_ATTEMPTS) return false;
        if (!empty($v['leased_until']) && strtotime((string) $v['leased_until']) > $now) return false;
        if (AutoImport::evaluate($c)['eligible']) return false;
        $hasStreet = preg_match('/\d/', (string) ($c['where']['address'] ?? '')) === 1;
        return $hasStreet || !empty($c['actions']['phone']);   // pages must show one of these to count
    }

    /** What the worker needs to look the listing up. */
    private static function describe(int $rowId, array $c): array
    {
        return [
            'row_id' => $rowId,
            'name' => (string) ($c['name'] ?? ''),
            'address' => (string) ($c['where']['address'] ?? ''),
            'city' => (string) ($c['where']['city'] ?? ''),
            'state' => (string) ($c['where']['state'] ?? ''),
            'zip' => (string) ($c['where']['zip'] ?? ''),
            'phone' => (string) ($c['actions']['phone'] ?? ''),
            'website' => (string) ($c['actions']['website'] ?? ''),
            'category' => (string) (AutoImport::evaluate($c)['category_name'] ?? ''),
            'offerings' => array_values((array) ($c['what']['offerings'] ?? [])),
            'known_hosts' => AutoImport::sourceHosts($c),
            'from_npi' => ($c['source']['kind'] ?? '') === 'npi_bulk',   // already an NPI record: look for a different reference
        ];
    }

    /**
     * Merges the worker's findings into the staged listing, then re-runs the guardrails.
     * found: [{url, kind, label?, evidence: address|phone|both, registry?, phone?, taxonomy?}]
     * @return array{added:int, auto_imported:bool, score:int}
     */
    public static function complete(PDO $pdo, int $rowId, array $found, array $checked): array
    {
        $st = $pdo->prepare("SELECT raw_payload FROM " . Database::t('crawler_raw_index') . " WHERE id = ? AND status = 'staged'");
        $st->execute([$rowId]);
        $c = json_decode((string) $st->fetchColumn(), true);
        if (!is_array($c)) throw new InvalidArgumentException("Listing #$rowId is no longer waiting for review.");

        $known = array_flip(AutoImport::sourceHosts($c));
        $ignored = array_flip(Sources::ignoredHosts($pdo));          // websites a person said not to count
        $corr = [];
        foreach ((array) ($c['corroboration'] ?? []) as $u) $corr[] = is_array($u) ? $u : ['url' => (string) $u, 'kind' => 'own_site'];
        $bump = 0;
        $added = 0;
        foreach (array_slice($found, 0, 12) as $f) {
            if (!is_array($f)) continue;
            $url = (string) ($f['url'] ?? '');
            $host = preg_replace('/^www\./', '', strtolower((string) parse_url($url, PHP_URL_HOST)));
            $kind = (string) ($f['kind'] ?? '');
            $evidence = (string) ($f['evidence'] ?? '');
            if (!preg_match('#^https?://#i', $url) || $host === '' || isset($known[$host]) || isset($ignored[$host])) continue;
            if (!isset(self::KINDS[$kind]) || !in_array($evidence, ['address', 'phone', 'both'], true)) continue;
            $registry = $kind === 'registry' ? preg_replace('/[^a-z0-9_]/', '', strtolower((string) ($f['registry'] ?? ''))) : '';
            if ($kind === 'registry' && !isset(AutoImport::TRUSTED_REGISTRIES[$registry])) continue;

            $known[$host] = true;
            Sources::note($pdo, $url, $kind, (string) ($c['name'] ?? ''), (string) ($f['label'] ?? ''));
            $corr[] = ['url' => mb_substr($url, 0, 500), 'kind' => $kind, 'evidence' => $evidence,
                       'label' => mb_substr(strip_tags((string) ($f['label'] ?? '')), 0, 120)];
            $added++;
            if ($registry !== '') {
                $c['registries'] = array_values(array_unique(array_merge((array) ($c['registries'] ?? []), [$registry])));
                $bump += 20;
                $tax = mb_substr(strip_tags((string) ($f['taxonomy'] ?? '')), 0, 120);
                if ($tax !== '') $c['what']['offerings'] = array_values(array_unique(array_merge((array) ($c['what']['offerings'] ?? []), [$tax])));
            } else {
                $bump += (int) round(10 * Sources::trustWeight($pdo, $host));   // its record: borne out counts more, often wrong less (decisions/0157 §5)
            }
            // The business's own site wins for its location's phone over a registry's head-office number (decisions/0076):
            // the NPI file carried Changepoint's Show Low line on its Snowflake and Holbrook clinics.
            if ($kind === 'own_site' && !empty($f['phone']) && in_array($evidence, ['address', 'both'], true) && ($c['source']['kind'] ?? '') === 'npi_bulk') {
                $p = ListingExtractor::phone((string) $f['phone']);
                if ($p && preg_replace('/\D/', '', $p) !== preg_replace('/\D/', '', (string) ($c['actions']['phone'] ?? ''))) {
                    if (!empty($c['actions']['phone'])) $c['actions']['registry_phone'] = $c['actions']['phone'];
                    $c['actions']['phone'] = $p;
                }
            }
            // Fill a missing phone or website from what the reference showed.
            if (empty($c['actions']['phone']) && !empty($f['phone'])) {
                $p = ListingExtractor::phone((string) $f['phone']);
                if ($p) $c['actions']['phone'] = $p;
            }
            if (empty($c['actions']['website']) && $kind === 'own_site') {
                $c['actions']['website'] = preg_replace('#^(https?://[^/]+).*$#i', '$1', $url);
            }
        }
        $bump = min(self::MAX_BUMP, $bump);
        $c['corroboration'] = $corr;
        $c['verify'] = array_merge((array) ($c['verify'] ?? []), [
            'done_at' => date('c'), 'leased_until' => null, 'added' => $added, 'bump' => $bump,
            'checked' => array_values(array_slice(array_map(fn ($x) => mb_substr((string) $x, 0, 40), $checked), 0, 10)),
        ]);
        $c['confidence'] = min(100, (int) ($c['confidence'] ?? 0) + $bump);
        self::save($pdo, $rowId, $c);
        $pdo->prepare('UPDATE ' . Database::t('crawler_raw_index') . ' SET confidence_score = ? WHERE id = ?')->execute([$c['confidence'], $rowId]);
        require_once __DIR__ . '/../Identity.php'; Identity::fromIntake($pdo, $rowId);   // what the references confirmed, into its identity once (decisions/0133)

        $imported = AutoImport::tryImport($pdo, $rowId, $c);
        if ($imported !== null) PageCache::forget($pdo, 'hub:support');
        return ['added' => $added, 'auto_imported' => $imported !== null, 'score' => AutoImport::evaluate($c)['score']];
    }

    /** Queues a listing for another second look (Review → Check again), e.g. after a search key was added. */
    public static function reset(PDO $pdo, int $rowId): void
    {
        $st = $pdo->prepare("SELECT raw_payload FROM " . Database::t('crawler_raw_index') . " WHERE id = ? AND status = 'staged'");
        $st->execute([$rowId]);
        $c = json_decode((string) $st->fetchColumn(), true);
        if (!is_array($c)) throw new InvalidArgumentException('That listing is no longer waiting for review.');
        unset($c['verify']);
        self::save($pdo, $rowId, $c);
    }

    private static function save(PDO $pdo, int $rowId, array $c): void
    {
        $pdo->prepare("UPDATE " . Database::t('crawler_raw_index') . " SET raw_payload = ? WHERE id = ? AND status = 'staged'")
            ->execute([json_encode($c, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $rowId]);
    }

    /** Short "kind: host" list of a listing's references, for the admin page. */
    public static function references(array $c): array
    {
        $out = [];
        $seen = [];
        $start = (string) ($c['source']['start_url'] ?? '');
        $items = array_merge($start !== '' ? [['url' => $start, 'kind' => 'found']] : [], (array) ($c['corroboration'] ?? []));
        foreach ($items as $u) {
            $url = is_array($u) ? (string) ($u['url'] ?? '') : (string) $u;
            $host = preg_replace('/^www\./', '', strtolower((string) parse_url($url, PHP_URL_HOST)));
            if ($host === '' || isset($seen[$host])) continue;
            $seen[$host] = true;
            $kind = is_array($u) ? (string) ($u['kind'] ?? 'website') : 'own_site';   // older rows: the place's homepage
            $label = $host === 'openstreetmap.org' ? 'found in OpenStreetMap' : ($kind === 'found' ? 'found on' : (self::KINDS[$kind] ?? 'website'));
            $out[] = ['kind' => $label, 'host' => $host, 'url' => $url, 'evidence' => is_array($u) ? (string) ($u['evidence'] ?? '') : ''];
        }
        return $out;
    }
}
