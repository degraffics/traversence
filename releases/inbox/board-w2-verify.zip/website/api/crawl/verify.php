<?php
// api/crawl/verify.php — second look at listings waiting for review (decisions/0044).
//   GET  ?limit=10                                   -> {"listings": [{row_id, name, address, city, state, zip, phone, ...}]}
//   POST {"row_id": 12, "found": [{url, kind, evidence, label?, registry?, phone?, taxonomy?}], "checked": ["npi", "search"]}
//        -> {"added": 2, "auto_imported": true, "score": 95}
// Findings are merged by Verify::complete(), so every ADR 0044 guardrail still decides what publishes.

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/crawler/Verify.php';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (CrawlQueue::paused()) Response::json(['ok' => true, 'paused' => true, 'listings' => []]);
        $l = Verify::lease($pdo, (int) ($_GET['limit'] ?? 10));
        Response::json(['ok' => true, 'paused' => false, 'listings' => $l] + (Verify::$problems ? ['set_aside' => array_map(fn ($k, $v) => ['row_id' => $k, 'error' => $v], array_keys(Verify::$problems), Verify::$problems)] : []));
    }
    Response::requireMethod('POST');
    $body = Response::jsonBody();
    $r = Verify::complete($pdo, (int) ($body['row_id'] ?? 0), (array) ($body['found'] ?? []), (array) ($body['checked'] ?? []));
    Response::json(['ok' => true, 'row_id' => (int) ($body['row_id'] ?? 0)] + $r);
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 409, 'row_state');
} catch (Throwable $e) {
    error_log('api/crawl/verify.php: ' . $e->getMessage());
    // the cause, not hidden (2026-11-18): the worker's log and the board's W2 row show it (the ledger keeps the answer's words)
    Response::error(($_SERVER['REQUEST_METHOD'] === 'GET' ? 'Could not hand out listings to verify: ' : 'Could not record the verification: ') . mb_substr(get_class($e) . ': ' . $e->getMessage(), 0, 300), 500, 'server_error');
}
