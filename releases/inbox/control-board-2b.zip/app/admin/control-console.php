<?php
// app/admin/control-console.php — System Configuration → System Control Board (decisions/0171, release 2b; Jason,
// 2026-11-18: "start to finish system management and control. Organized by how an operator can see and understand each
// system and everything within its process. Each gauge holds the entire process for whatever system feature it
// represents along with the ability manage that feature"). Laid out like the admin's lists (as Releases): each system a
// fold with its count of green and red, each process a row that opens under its name to its whole process: its route,
// its check, its last 24 hours (worker calls in and what they stored, crawler task runs, site jobs), the records it
// touched, and its controls. Above: the six stages, where the system is now, and the system's own controls (Start, Shut
// down in order, Pause everything, Run the pre-flight). Buttons answer in place (js/admin-control.js); the board draws
// itself again every 30 seconds while it's open. The data is ControlBoard's (app/lib/ControlBoard.php).
declare(strict_types=1);

require_once __DIR__ . '/../lib/ControlBoard.php';
if (!function_exists('tv_w_e')) require_once __DIR__ . '/widgets.php';

function tv_cb_mark(string $light): string
{
    $m = ['ok' => ['#DCFCE7', '#15803D', 'check', 'Working'], 'bad' => ['#FEE2E2', '#B91C1C', 'x', 'Needs a look'], 'warn' => ['#FEF3C7', '#B45309', 'check', 'On a backup or near a limit'],
          'off' => ['#F1EDE6', '#8a7a68', 'dash', 'Switched off'], 'wait' => ['#F1EDE6', '#8a7a68', 'clock', 'Not tested yet'], 'na' => ['#F1EDE6', '#8a7a68', 'dash', 'Nothing to do']][$light] ?? ['#F1EDE6', '#8a7a68', 'dash', ''];
    $ic = function_exists('tv_icon') ? tv_icon($m[2], 'cb-svg') : ($light === 'bad' ? '✗' : '✓');
    return '<span class="cb-m" role="img" aria-label="' . tv_w_e($m[3]) . '" title="' . tv_w_e($m[3]) . '" style="background:' . $m[0] . ';color:' . $m[1] . '">' . $ic . '</span>';
}

function tv_cb_record_link(string $kind, int $id): string
{
    $u = $kind === 'listing' ? '/admin/listing-edit.php?id=' . $id : ($kind === 'review' ? '/admin/listing-intake.php?row=' . $id : '');
    $label = ($kind === 'listing' ? 'Listing #' : ($kind === 'review' ? 'Review item #' : ucfirst($kind) . ' #')) . $id;
    return $u !== '' ? '<a href="' . tv_w_e($u) . '" data-peek-frame class="underline">' . tv_w_e($label) . '</a>' : tv_w_e($label);
}

function tv_admin_mod_control(PDO $pdo): string
{
    $e = 'tv_w_e';
    [$can, $why] = ControlBoard::can();
    if (!$can) return '<p data-tv-status="info" data-tv-label="Not for your role:">' . $e((string) $why) . '. The System Control Board is for executives: ask one, or write to support@traversence.com.</p>';
    require_once __DIR__ . '/../lib/SystemStart.php';
    require_once __DIR__ . '/../lib/Preflight.php';
    require_once __DIR__ . '/../lib/Staging.php';
    [$canRun, $whyRun] = SystemStart::can();
    [$canPf, $whyPf] = Preflight::can();
    $staging = Staging::here();
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $btn = function (string $act, string $label, bool $ok, string $why, string $id = '', array $attr = []) use ($e): string {
        $a = ''; foreach ($attr as $k => $v) $a .= ' ' . $k . '="' . $e($v) . '"';
        return '<button type="button" class="ak-b" data-cb="' . $e($act) . '"' . ($id !== '' ? ' data-cb-id="' . $e($id) . '"' : '') . ($ok ? $a : ' disabled title="' . $e($why) . '"') . '>' . $e($label) . '</button>';
    };
    ControlBoard::settle($pdo);
    [$stage, $stageWords] = ControlBoard::stage($pdo);

    $h = '<div id="cb" data-csrf="' . $e($csrf) . '">';
    $h .= '<p class="ak-note">The whole system in one place: each system and every process in it, where it stands, what it took in and stored in the last day, and its controls. A process opens under its name. Pre-flight, Start the system and Pause everything are here too (decisions/0171).</p>';
    // the six stages, the one the system is in now lit
    $h .= '<div class="cb-stages" role="list">';
    foreach (ControlBoard::STAGES as $k => $label) {
        $soon = in_array($k, ['maintenance', 'history'], true);
        $h .= '<div role="listitem" class="cb-st' . ($k === $stage ? ' on' : '') . ($soon ? ' soon' : '') . '"' . ($soon ? ' title="Coming in the board\'s release 4"' : '') . '><small>' . (array_search($k, array_keys(ControlBoard::STAGES), true) + 1) . '</small>' . $e($label) . '</div>';
    }
    $h .= '</div><p data-tv-status="' . ($stage === 'observe' ? 'ok' : 'info') . '" data-tv-label="' . $e(ControlBoard::STAGES[$stage]) . ':">' . $e($stageWords) . '</p>';
    // the system's own controls
    $wNo = $staging ? 'Nothing runs on staging: these work on the live site.' : $whyRun;
    $h .= '<div class="cb-acts">'
        . $btn('preflight', 'Run the pre-flight', $canPf && !$staging, $staging ? $wNo : $whyPf)
        . $btn('start', 'Start the system', $canRun && !$staging, $wNo, '', ['data-confirm' => 'Start the system? It confirms each workflow and task, then switches them on in order.', 'data-yes' => 'Start it'])
        . $btn('shutdown', 'Shut down in order', $canRun && !$staging, $wNo, '', ['data-confirm' => 'Shut the whole system down in order? The tasks, then the workflows in reverse order, then the master switch and the crawler\'s schedule. What\'s running finishes.', 'data-yes' => 'Shut it down'])
        . $btn('pauseall', 'Pause everything', $canRun && !$staging, $wNo, '', ['data-confirm' => 'Pause everything at once? The emergency stop: the master switch off and the crawler\'s schedule removed.', 'data-yes' => 'Pause everything', 'data-danger' => '1'])
        . '<a class="ak-b" href="/admin/config/automation#start" data-peek-frame>Start the system\'s card</a></div>';

    // the systems, each process a row
    $res = Preflight::results($pdo);
    $by = [];
    foreach (ControlRegister::processes($pdo) as $id => $p) $by[$p[0]][$id] = ControlBoard::process($pdo, $id, $p, $res);
    foreach (ControlRegister::SYSTEMS as $sk => $sname) {
        $rows = $by[$sk] ?? [];
        $n = array_count_values(array_column($rows, 'light'));
        $worst = !empty($n['bad']) ? 'bad' : (!empty($n['warn']) ? 'warn' : (!empty($n['ok']) ? 'ok' : 'wait'));
        $sum = [];
        foreach (['ok' => 'working', 'bad' => 'need a look', 'warn' => 'on a backup', 'off' => 'off', 'wait' => 'not tested'] as $k => $w) if (!empty($n[$k])) $sum[] = $n[$k] . ' ' . $w;
        $h .= '<details class="ak-card tv-bleed cb-sys" id="cb-' . $e($sk) . '" data-cb-sys="' . $e($sk) . '"' . (!empty($n['bad']) ? ' open' : '') . '>'
            . '<summary class="cb-row cb-sh">' . '<span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($worst) . '<h3 class="ak-h" style="margin:0;font-size:1.1rem">' . $e($sname) . '</h3><small class="ak-note cb-c" style="margin:0">' . $e(implode(' · ', $sum)) . '</small></summary>'
            . '<div class="cb-head cb-row" aria-hidden="true"><span></span><span></span><span>Process</span><span>Where it stands</span></div>';
        foreach ($rows as $id => $p) {
            $h .= '<details class="cb-p" id="cb-p-' . $e(str_replace(':', '-', $id)) . '" data-cb-p="' . $e($id) . '"' . ($p['light'] === 'bad' ? ' open' : '') . '>'
                . '<summary class="cb-row"><span class="cb-caret" aria-hidden="true">▾</span>' . tv_cb_mark($p['light']) . '<b class="cb-n">' . $e($p['name']) . '</b><small class="ak-note cb-c" style="margin:0">' . $e($p['words']) . '</small></summary><div class="cb-b">';
            // its route
            if ($p['route']) $h .= '<p class="ak-note"><b>Route:</b> ' . $e((string) $p['route']['said']) . '</p>';
            // its last day
            $c = $p['calls'];
            if ($c['calls']) $h .= '<p class="ak-note"><b>Last 24 hours, worker calls:</b> ' . number_format($c['calls']) . ' (' . number_format($c['received']) . ' received: ' . number_format($c['stored']) . ' stored, ' . number_format($c['updated']) . ' updated, ' . number_format($c['review']) . ' to Review, ' . number_format($c['refused']) . ' refused; ' . $c['ms'] . ' ms on average' . ($c['errors'] ? '; <b style="color:#B42318">' . $c['errors'] . ' server error' . ($c['errors'] === 1 ? '' : 's') . '</b>' : '') . ').</p>';
            if ($p['outcomes']) { $o = []; foreach ($p['outcomes'] as $k => $v) $o[] = $v . ' ' . str_replace('_', ' ', (string) $k); $h .= '<p class="ak-note"><b>Crawler task runs:</b> ' . $e(implode(', ', $o)) . '.</p>'; }
            if ($p['jobs'][0] + $p['jobs'][1]) $h .= '<p class="ak-note"><b>Site jobs:</b> ' . $p['jobs'][0] . ' ran' . ($p['jobs'][1] ? ', ' . $p['jobs'][1] . ' stopped' : '') . '.</p>';
            // its check
            if ($p['line']) $h .= '<p class="ak-note"><b>Its check</b> (' . (Preflight::MARKS[$p['line']['s'] ?? 'new'] ?? '') . ', ' . ($p['line']['at'] ? '<time datetime="' . gmdate('c', (int) $p['line']['at']) . '" data-tv-time>' . gmdate('M j, H:i', (int) $p['line']['at']) . ' UTC</time>' : 'not run') . '): ' . $e(mb_strlen((string) ($p['line']['said'] ?? '')) > 600 ? preg_replace('/\s+\S*$/u', '', mb_substr((string) $p['line']['said'], 0, 600)) . ' …' : (string) ($p['line']['said'] ?? '')) . '</p>';
            // the records it touched
            $eps = $p['parts']['endpoints'] ?? [];
            if (str_starts_with($id, 'wk:')) { $k = substr($id, 3); $eps = ControlRegister::WORKERS[$k][2]; foreach (ControlRegister::ENDPOINTS as $ep => [, $for]) if (in_array('@' . $k, $for, true) || ($k === 'crawler' && !array_filter($for, fn ($f) => $f[0] === '@' || $f === 'W0'))) $eps[] = $ep; }
            $recs = ControlBoard::records($pdo, array_values(array_filter($eps, fn ($ep) => !in_array($ep, ['crawl/service', 'crawl/usage'], true))), 12);
            if ($recs) $h .= '<p class="ak-note"><b>Records it touched lately:</b> ' . implode(' · ', array_map(fn ($r) => tv_cb_record_link((string) $r[0], (int) $r[1]) . ' <small>(' . $e((string) $r[2]) . ')</small>', $recs)) . '</p>';
            if ($id === 'wk:crawler') {
                foreach (ControlBoard::runs($pdo, 5) as [$run, $calls, $rr]) {
                    $sumc = ['stored' => 0, 'review' => 0, 'updated' => 0, 'refused' => 0]; foreach ($calls as $cl) foreach ($sumc as $k => $_) $sumc[$k] += (int) $cl['n_' . $k];
                    $h .= '<details class="cb-run"><summary class="ak-note">Run #' . (int) $run['id'] . ' · ' . $e((string) $run['status']) . ' · <time datetime="' . $e(gmdate('c', (int) strtotime((string) $run['started_at']))) . '" data-tv-time>' . $e((string) $run['started_at']) . '</time> · ' . count($calls) . ' calls, ' . $sumc['stored'] . ' stored, ' . $sumc['review'] . ' to Review, ' . $sumc['updated'] . ' updated, ' . $sumc['refused'] . ' refused</summary>'
                        . ($rr ? '<p class="ak-note">' . implode(' · ', array_map(fn ($r) => tv_cb_record_link((string) $r['kind'], (int) $r['ref_id']) . ' <small>(' . $e((string) $r['what']) . ')</small>', $rr)) . '</p>' : '<p class="ak-note">No records touched.</p>') . '</details>';
                }
            }
            // its controls
            $acts = '';
            if (isset($res[$id]) || str_starts_with($id, 'wf:') || str_starts_with($id, 't:') || str_starts_with($id, 'svc:') || str_starts_with($id, 'site:')) $acts .= $btn('check', 'Run its check', $canPf, (string) $whyPf, $id);
            if ($p['switch'] === 'on') $acts .= $btn('stop', 'Shut it down', $canRun && !$staging, $wNo, $id, ['data-confirm' => 'Shut ' . $p['name'] . ' down? Its tasks first, then the workflow. What\'s running finishes.', 'data-yes' => 'Shut it down']);
            if ($p['switch'] === 'off') $acts .= $btn('start1', 'Start it', $canRun && !$staging, $wNo, $id);
            if ($acts !== '') $h .= '<div class="cb-acts">' . $acts . '</div>';
            $h .= '</div></details>';
        }
        $h .= '</details>';
    }

    // the pre-flight, every line (its own page stays reachable: archive.md)
    $h .= '<details class="ak-card tv-bleed" id="preflight" style="margin-top:.6rem"><summary class="ak-h" style="cursor:pointer">Pre-flight: every line, as tested last</summary>'
        . '<p class="ak-note">The same lines as <a class="underline" href="/admin/config/preflight">Pre-flight</a>, with its Run all and each line\'s Test.</p>'
        . (function_exists('tv_admin_mod_preflight') ? tv_admin_mod_preflight($pdo) : '') . '</details>';
    $h .= '</div>';
    $h .= '<style>#cb .cb-m{display:inline-flex;width:1.35rem;height:1.35rem;border-radius:.3rem;align-items:center;justify-content:center;flex:0 0 auto;margin-top:.05rem}#cb .cb-svg{width:.9rem;height:.9rem;fill:none;stroke:currentColor;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}'
        . '#cb .cb-row{display:grid;grid-template-columns:.9rem 1.35rem minmax(10rem,22rem) minmax(0,1fr);gap:.2rem .6rem;align-items:start;cursor:pointer;list-style:none}#cb summary::-webkit-details-marker{display:none}'
        . '#cb details:not([open])>summary .cb-caret{display:inline-block;transform:rotate(-90deg)}#cb .cb-p{border-top:1px solid #EFE6D6;padding:.45rem 0}#cb .cb-b{padding:.3rem 0 .2rem 2.6rem}'
        . '#cb .cb-head{padding:.4rem 0 0;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.03em;color:#8a7a68;cursor:default}#cb .cb-acts{display:flex;gap:.35rem;flex-wrap:wrap;margin:.5rem 0}'
        . '#cb .cb-stages{display:grid;grid-template-columns:repeat(6,1fr);gap:.35rem;margin:.6rem 0}#cb .cb-st{border:1px solid #E5D9C3;border-radius:.4rem;padding:.4rem .5rem;font-size:13px;background:#FFFBF2}#cb .cb-st small{display:block;color:#8a7a68}'
        . '#cb .cb-st.on{background:#E8F3EC;border-color:#8FBCA8;box-shadow:0 0 6px #8FBCA8;font-weight:600}#cb .cb-st.soon{opacity:.55}'
        . '@media (max-width:767px){#cb .cb-row{grid-template-columns:.9rem 1.35rem minmax(0,1fr)}#cb .cb-c{grid-column:3}#cb .cb-head{display:none}#cb .cb-b{padding-left:0}#cb .cb-stages{grid-template-columns:repeat(3,1fr)}}</style>'
        . '<script src="/js/tv-time.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/tv-time.js') . '" defer></script>'
        . '<script src="/js/admin-control.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/admin-control.js') . '" defer></script>';
    return $h;
}
