<?php
// app/lib/ControlBoard.php — the System Control Board's view and controls (decisions/0171 §1, §2, release 2b; Jason,
// 2026-11-18: "start to finish system management and control. Organized by how an operator can see and understand each
// system and everything within its process"). It reads what exists and adds nothing of its own to the database:
//   the systems and processes (ControlRegister), each process's pre-flight line and route as last tested (Preflight), its
//   switch (Automation), the last 24 hours of its worker calls (ControlLedger's control_ledger), its crawler task
//   outcomes (crawl_run_items), its site jobs' runs (job_runs), and Start the system's state (SystemStart);
// and acts through what exists: a process is started only after its pre-flight line is tested green (the interlock), shut
// down in order (its tasks, then the workflow), and the whole system shut down in reverse start-up order, ending
// "stopped, safe" once no crawler run is still going. Pause everything stays the emergency stop (SystemStart::pauseAll).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Automation.php';
require_once __DIR__ . '/ControlRegister.php';

final class ControlBoard
{
    public const STAGES = [
        'preflight' => 'Pre-flight', 'startup' => 'Start-up', 'observe' => 'Observation and reporting',
        'shutdown' => 'Shut-down', 'maintenance' => 'Maintenance', 'history' => 'History',
    ];
    /** Shut-down's record (search_index_state). */
    public const KEY = 'ops:shutdown';
    public const BY = 'the Control Board';

    public static function can(): array
    {
        if (!class_exists('Access', false)) require_once __DIR__ . '/../admin/Access.php';
        return Access::can('config.control', ['min' => 'executive', 'depts' => []]);
    }

    /** The stage the system is in now: [key, words]. */
    public static function stage(PDO $pdo): array
    {
        require_once __DIR__ . '/SystemStart.php';
        require_once __DIR__ . '/Preflight.php';
        $sd = self::shutdownState($pdo);
        if (($sd['state'] ?? '') === 'stopping') return ['shutdown', 'Shutting down: waiting for what was running to finish.'];
        $live = Preflight::live($pdo);
        if (($live['state'] ?? '') === 'running') return ['preflight', 'The pre-flight is running (' . (int) ($live['i'] ?? 0) . ' of ' . (int) ($live['total'] ?? 0) . ').'];
        $st = SystemStart::state($pdo);
        if (($st['state'] ?? '') === 'running') return ['startup', 'Starting: ' . self::startWhere($st)];
        if (Automation::master($pdo) !== null) return ['shutdown', ($sd['state'] ?? '') === 'safe' ? 'Stopped, safe: ' . (string) ($sd['left'] ?? '') : 'Stopped: the master switch is off.'];
        return ['observe', 'Running, watched.'];
    }

    private static function startWhere(array $st): string
    {
        $n = 0; $on = 0;
        foreach ((array) ($st['items'] ?? []) as $id => $it) if (str_starts_with((string) $id, 'wf:') || str_starts_with((string) $id, 't:')) { $n++; if (in_array($it['s'] ?? '', ['on', 'done'], true)) $on++; }
        return $on . ' of ' . $n . ' on.';
    }

    /** The last 24 hours of a set of endpoints' calls: calls, received, stored, updated, review, refused, errors, avg ms. */
    public static function calls(PDO $pdo, array $endpoints): array
    {
        $z = ['calls' => 0, 'received' => 0, 'stored' => 0, 'updated' => 0, 'review' => 0, 'refused' => 0, 'errors' => 0, 'ms' => 0];
        if (!$endpoints) return $z;
        try {
            $in = implode(',', array_map(fn ($e) => $pdo->quote($e), $endpoints));
            $r = $pdo->query("SELECT COUNT(*) calls, COALESCE(SUM(n_received), 0) received, COALESCE(SUM(n_stored), 0) stored, COALESCE(SUM(n_updated), 0) updated, COALESCE(SUM(n_review), 0) review, COALESCE(SUM(n_refused), 0) refused, COALESCE(SUM(code >= 500), 0) errors, COALESCE(ROUND(AVG(ms)), 0) ms FROM control_ledger WHERE endpoint IN ($in) AND at >= UTC_TIMESTAMP() - INTERVAL 1 DAY")->fetch(PDO::FETCH_ASSOC);
            foreach ($z as $k => $_) $z[$k] = (int) ($r[$k] ?? 0);
        } catch (Throwable $x) {}
        return $z;
    }

    /** The last 24 hours of crawler task outcomes: outcome => count. */
    public static function outcomes(PDO $pdo, array $tasks): array
    {
        if (!$tasks) return [];
        try {
            $in = implode(',', array_map(fn ($t) => $pdo->quote($t), $tasks));
            return array_map('intval', $pdo->query("SELECT outcome, COUNT(*) FROM crawl_run_items WHERE task IN ($in) AND at >= NOW() - INTERVAL 1 DAY GROUP BY outcome")->fetchAll(PDO::FETCH_KEY_PAIR));
        } catch (Throwable $x) { return []; }
    }

    /** The last 24 hours of site jobs' runs: [good, failed]. */
    public static function jobRuns(PDO $pdo, array $jobs): array
    {
        if (!$jobs) return [0, 0];
        try {
            $in = implode(',', array_map(fn ($j) => $pdo->quote($j), $jobs));
            $r = $pdo->query('SELECT COALESCE(SUM(ok = 1), 0) g, COALESCE(SUM(ok = 0), 0) b FROM ' . Database::t('job_runs') . " WHERE job IN ($in) AND started_at >= NOW() - INTERVAL 1 DAY")->fetch(PDO::FETCH_ASSOC);
            return [(int) $r['g'], (int) $r['b']];
        } catch (Throwable $x) { return [0, 0]; }
    }

    /** A crawler task's switch: null when on, else why it's off. */
    private static function taskOff(PDO $pdo, string $task): ?string
    {
        try {
            require_once __DIR__ . '/crawler/CrawlService.php';
            if (!CrawlService::ready($pdo)) return null;
            $t = CrawlService::tasks($pdo)[$task] ?? null;
            return $t && !(int) $t['enabled'] ? 'Off' . (!empty($t['off_why']) ? ': ' . (string) $t['off_why'] : '') : null;
        } catch (Throwable $x) { return null; }
    }

    /**
     * One process as the board shows it: [system, name, light (ok, warn, bad, off, wait), words, line (its pre-flight line's
     * stored result), route (its route line's stored result), calls, outcomes, jobs, switch ('on', 'off', ''), parts].
     */
    public static function process(PDO $pdo, string $id, array $p, array $res): array
    {
        require_once __DIR__ . '/Preflight.php';
        [$sys, $name] = $p;
        $line = $res[$id] ?? null; $route = null; $parts = []; $calls = self::calls($pdo, []); $out = []; $jobs = [0, 0]; $switch = ''; $off = null;
        if (str_starts_with($id, 'wf:')) {
            $wf = substr($id, 3); $parts = ControlRegister::of($pdo, $wf);
            $route = $res['rt:' . $id] ?? null; $calls = self::calls($pdo, array_values(array_filter($parts['endpoints'], fn ($e) => !in_array($e, ['crawl/service', 'crawl/usage'], true))));
            $out = self::outcomes($pdo, $parts['tasks']); $jobs = self::jobRuns($pdo, $parts['jobs']);
            $off = Automation::wfOff($pdo, $wf); $switch = $wf === 'W13' ? '' : ($off === null ? 'on' : 'off');
        } elseif (str_starts_with($id, 't:')) {
            require_once __DIR__ . '/SystemStart.php';
            $d = SystemStart::TASKS[substr($id, 2)] ?? null;
            if ($d) { $out = self::outcomes($pdo, $d[4]); $jobs = self::jobRuns($pdo, $d[3]); foreach ($d[4] as $tk) if (($o = self::taskOff($pdo, $tk)) !== null) $off = $o; $switch = $d[4] ? ($off === null ? 'on' : 'off') : ''; }
        } elseif (str_starts_with($id, 'wk:')) {
            $k = substr($id, 3); $w = ControlRegister::WORKERS[$k];
            $line = $w[3] !== '' ? ($res[$w[3]] ?? null) : null; $route = $res['rt:' . $id] ?? null;
            $eps = $w[2]; foreach (ControlRegister::ENDPOINTS as $e => [, $for]) if (in_array('@' . $k, $for, true) || ($k === 'crawler' && !array_filter($for, fn ($f) => $f[0] === '@' || $f === 'W0'))) $eps[] = $e;
            $calls = self::calls($pdo, array_values(array_unique($eps)));
        } elseif (str_starts_with($id, 'svc:')) {
            $off = Automation::serviceOff($pdo, substr($id, 4));
        } elseif (str_starts_with($id, 'job:')) {
            $jobs = self::jobRuns($pdo, [substr($id, 4)]);
        }
        $s = (string) ($line['s'] ?? 'new');
        $light = $off !== null ? 'off' : ($s === 'bad' || $calls['errors'] > 0 || $jobs[1] > 0 || ($out['failed'] ?? 0) > 0 ? 'bad' : ($s === 'warn' ? 'warn' : ($s === 'ok' ? 'ok' : 'wait')));
        $w = [];
        if ($off !== null) $w[] = rtrim($off, '.');
        if ($calls['calls']) $w[] = number_format($calls['calls']) . ' worker call' . ($calls['calls'] === 1 ? '' : 's') . ' in 24 hours' . ($calls['errors'] ? ', ' . $calls['errors'] . ' answered with a server error' : '');
        if ($jobs[0] + $jobs[1]) $w[] = 'site jobs: ' . $jobs[0] . ' ran' . ($jobs[1] ? ', ' . $jobs[1] . ' stopped' : '');
        if (($out['failed'] ?? 0) > 0) $w[] = (int) $out['failed'] . ' crawler task run' . ((int) $out['failed'] === 1 ? '' : 's') . ' failed';
        if (!$w) $w[] = $line ? (string) ($line['said'] ?? '') : 'Not tested yet: run its check.';
        return ['sys' => $sys, 'name' => $name, 'light' => $light, 'words' => mb_substr(rtrim(implode('; ', $w), '.') . '.', 0, 300), 'line' => $line, 'route' => $route, 'calls' => $calls, 'outcomes' => $out, 'jobs' => $jobs, 'switch' => $switch, 'parts' => $parts];
    }

    /** The records a set of endpoints touched lately: [kind, id, what, at], newest first. */
    public static function records(PDO $pdo, array $endpoints, int $n = 20): array
    {
        if (!$endpoints) return [];
        try {
            $in = implode(',', array_map(fn ($e) => $pdo->quote($e), $endpoints));
            return $pdo->query("SELECT r.kind, r.ref_id, r.what, r.at FROM control_records r JOIN control_ledger l ON l.id = r.ledger_id WHERE l.endpoint IN ($in) ORDER BY r.id DESC LIMIT " . max(1, min(100, $n)))->fetchAll(PDO::FETCH_NUM);
        } catch (Throwable $x) { return []; }
    }

    /** The crawler's last runs with what each brought in: [run row, calls, records]. */
    public static function runs(PDO $pdo, int $n = 5): array
    {
        $out = [];
        try {
            require_once __DIR__ . '/ControlLedger.php';
            foreach ($pdo->query('SELECT id, started_at, ended_at, status, why FROM crawl_runs ORDER BY id DESC LIMIT ' . max(1, min(20, $n)))->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $f = ControlLedger::forRun($pdo, (int) $r['id']);
                $out[] = [$r, $f['calls'], array_slice($f['records'], 0, 30)];
            }
        } catch (Throwable $x) {}
        return $out;
    }

    // ---- controls ----------------------------------------------------------------------------------------------------

    /** Start one process: its check first, then its switch, only when the check isn't red (the interlock). */
    public static function startOne(PDO $pdo, string $id, int $uid, string $who): string
    {
        require_once __DIR__ . '/Preflight.php';
        $pid = $id === 't:W14' ? 'wf:W14' : $id;
        Preflight::refreshFor($pdo, $pid, time() + 40, self::BY);
        $r = Preflight::run($pdo, $pid, self::BY);
        if ($r['s'] === 'bad') throw new RuntimeException('Not started: its check is red. ' . mb_substr((string) $r['said'], 0, 400));
        if (str_starts_with($id, 'wf:')) { Automation::setWorkflow($pdo, substr($id, 3), false, 'Started from ' . self::BY, $uid, $who); return substr($id, 3) . ' is on: its check passed.'; }
        if (str_starts_with($id, 't:')) {
            require_once __DIR__ . '/SystemStart.php';
            $d = SystemStart::TASKS[substr($id, 2)] ?? null;
            if (!$d || !$d[4]) throw new RuntimeException('It has no switch of its own: it comes on with its workflow.');
            foreach ($d[4] as $tk) Automation::setTask($pdo, $tk, true, 'Started from ' . self::BY, $uid, $who);
            return $d[0] . ' is on: its check passed.';
        }
        throw new RuntimeException('That can\'t be started from here.');
    }

    /** Shut one process down in order: its crawler tasks, then the workflow. What's running finishes or goes back unchanged. */
    public static function stopOne(PDO $pdo, string $id, int $uid, string $who): string
    {
        $why = 'Shut down from ' . self::BY . ' by ' . ($who !== '' ? $who : 'a director');
        if (str_starts_with($id, 'wf:')) {
            $wf = substr($id, 3);
            foreach (ControlRegister::of($pdo, $wf)['tasks'] as $tk) { try { Automation::setTask($pdo, $tk, false, $why, $uid, $who); } catch (Throwable $x) {} }
            Automation::setWorkflow($pdo, $wf, true, $why, $uid, $who);
            return $wf . ' is shut down: its tasks first, then the workflow. A crawler run going now finishes its task; nothing is lost.';
        }
        if (str_starts_with($id, 't:')) {
            require_once __DIR__ . '/SystemStart.php';
            $d = SystemStart::TASKS[substr($id, 2)] ?? null;
            if (!$d || !$d[4]) throw new RuntimeException('It has no switch of its own: shut down its workflow.');
            foreach ($d[4] as $tk) Automation::setTask($pdo, $tk, false, $why, $uid, $who);
            return $d[0] . ' is shut down.';
        }
        throw new RuntimeException('That can\'t be shut down from here.');
    }

    public static function shutdownState(PDO $pdo): array
    {
        try { require_once __DIR__ . '/SearchIndex.php'; $j = json_decode((string) SearchIndex::state($pdo, self::KEY), true); return is_array($j) ? $j : []; }
        catch (Throwable $x) { return []; }
    }

    private static function saveShutdown(PDO $pdo, array $v): void
    {
        require_once __DIR__ . '/SearchIndex.php';
        SearchIndex::setState($pdo, self::KEY, json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    /**
     * The whole system shut down in order (decisions/0171 §2.4): the new tasks, then the workflows in reverse start-up order,
     * then the master switch, then the crawler's schedule on Railway. Stays "stopping" until no crawler run that started
     * before it is still going, then "stopped, safe", saying what it left. Pause everything stays the emergency stop.
     */
    public static function shutDown(PDO $pdo, int $uid, string $who): string
    {
        require_once __DIR__ . '/SystemStart.php';
        require_once __DIR__ . '/Staging.php';
        if (Staging::here()) throw new RuntimeException('Nothing runs on staging to shut down.');
        $why = 'Shut down in order from ' . self::BY . ' by ' . ($who !== '' ? $who : 'a director');
        $done = [];
        foreach (array_reverse(array_keys(SystemStart::TASKS)) as $t) {
            if ($t === 'W14') continue;
            foreach (SystemStart::TASKS[$t][4] as $tk) { try { Automation::setTask($pdo, $tk, false, $why, $uid, $who); $done[] = $tk; } catch (Throwable $x) {} }
        }
        foreach (array_reverse(array_merge(SystemStart::ORDER, ['W14'])) as $wf) {
            if (Automation::wfOff($pdo, $wf) !== null) continue;
            try { Automation::setWorkflow($pdo, $wf, true, $why, $uid, $who); $done[] = $wf; } catch (Throwable $x) {}
        }
        Automation::set($pdo, 'master', 'all', true, $why, $uid, $who);
        [, $rw] = SystemStart::railwayKeys() ? SystemStart::railwaySchedule($pdo, null) : [false, 'Railway\'s keys aren\'t in .env, so its schedule wasn\'t touched (each run ends at once while the master is off).'];
        self::saveShutdown($pdo, ['state' => 'stopping', 'at' => time(), 'by' => $who, 'stopped' => $done, 'railway' => $rw]);
        return 'Shutting down in order: ' . count($done) . ' switched off, then the master. ' . $rw . ' It reads "stopped, safe" once no crawler run is still going.';
    }

    /** Moves "stopping" to "stopped, safe" once nothing that started before the shut-down is still running. */
    public static function settle(PDO $pdo): array
    {
        $sd = self::shutdownState($pdo);
        if (($sd['state'] ?? '') !== 'stopping') return $sd;
        $going = 0;
        try { $going = (int) $pdo->query("SELECT COUNT(*) FROM crawl_runs WHERE status = 'running' AND started_at >= NOW() - INTERVAL 40 MINUTE")->fetchColumn(); } catch (Throwable $x) {}
        if ($going > 0) return $sd;
        $left = [];
        try { $left[] = number_format((int) $pdo->query("SELECT COUNT(*) FROM crawl_requests WHERE status IN ('queued', 'leased')")->fetchColumn()) . ' crawler requests kept for the next start'; } catch (Throwable $x) {}
        try { $left[] = number_format((int) $pdo->query("SELECT COUNT(*) FROM " . Database::t('crawler_raw_index') . " WHERE status = 'staged'")->fetchColumn()) . ' finds waiting in Review'; } catch (Throwable $x) {}
        $sd['state'] = 'safe'; $sd['safe_at'] = time();
        $sd['left'] = 'nothing half-written (each write is saved as it\'s made); ' . ($left ? implode('; ', $left) . '; ' : '') . 'every switch off, with who and why';
        self::saveShutdown($pdo, $sd);
        return $sd;
    }

    /** Start the system after a shut-down clears it (Start's own steps take it from there). */
    public static function cleared(PDO $pdo): void
    {
        try { require_once __DIR__ . '/SearchIndex.php'; $pdo->prepare('DELETE FROM search_index_state WHERE k = ?')->execute([self::KEY]); } catch (Throwable $x) {}
    }
}
