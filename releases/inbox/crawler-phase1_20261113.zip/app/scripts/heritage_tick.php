<?php
// app/scripts/heritage_tick.php — the heritage catalog (decisions/0133 Phases 2-4): reads the next places whose sources
// changed (the Library of Congress's records, the crawler's dossier, the research brief) into vetted, tiered facts with
// the cheapest model, within AI use's heritage budget. Sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('heritage_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Heritage.php';
$pdo = Database::connection();
echo 'Heritage: ' . Heritage::extractTick($pdo, 2) . ".\n";
$st = Heritage::restamp($pdo);   // facts stored before they carried their sources' rules
if ($st) echo 'Sources stamped on ' . $st . " facts.\n";
$rt = Heritage::retier($pdo);   // facts tiered before the protected-place check knew the nations' peoples (review A2)
if ($rt) echo 'Re-tiered ' . $rt . " facts now known to be protected.\n";
require_once __DIR__ . '/../lib/Topics.php';   // the Topic index: summaries kept current, and the most asked-for thin topic researched
$missed = Topics::fromMissedSearches($pdo);   // once a day: what people searched for and didn't find drives the research
echo 'Topics: ' . $missed . ' from missed searches, ' . Topics::summarizeTick($pdo, 3) . ' summaries, ' . Topics::researchTick($pdo, 1) . " researched.\n";
require_once __DIR__ . '/../lib/AiAssist.php';
$fu = AiAssist::followupTick($pdo, 5);   // asks we couldn't answer, answered once their research arrived (emailed)
if ($fu) echo "AI Assist: $fu follow-up answers sent.\n";
