<?php

declare(strict_types=1);

require_once __DIR__ . '/Sources.php';

/**
 * api/lib/crawler/SourceIndex.php — our own reference index (decisions/0045, 0157).
 *
 * The worker reads one "Read regularly" source at a time (next()), sends back the places it found on it
 * (store()), and the second look checks a listing against these facts before any paid search (matches()).
 * A fact confirms a listing when the name matches and the house number or the phone matches too.
 *
 * The page log (decisions/0157 §1): every page the worker fetches is kept in crawl_pages (its address, the answer, a
 * fingerprint of its text, the entity tag and last-changed date its server gave, the links it leads to, and when to read
 * it next), never its body. next() hands the worker what the log knows, so an unchanged page answers 304 and keeps its
 * facts; how often a source is read follows how often its pages change (a week to three months).
 * Each place (decisions/0157 §2) keeps how it was read (structured data, a list page's item, text), the kind of page,
 * its own words and heading, the kind of business they say (CategoryClassifier, then Concepts), its town (from its ZIP,
 * its address, the page, or the site), its website, hours and map point when the page gave them.
 */
final class SourceIndex
{
    private const REREAD_DAYS = 30;
    private const HAND_BACK_HOURS = 6;   // a read that didn't happen is due again this soon (review B6)
    /** How often a page is read: halved when it changed, doubled when it didn't, within these (days). */
    private const EVERY_MIN = 7, EVERY_MAX = 90;
    /** The least a kind must be sure of to be kept on a place (0-99); search decides how sure it needs (decisions/0157 §3). */
    private const KIND_MIN = 40;
    private const PAGE_KINDS = ['own_site', 'list', 'events', 'notice', 'article', 'other', 'scan'];   // scan: a PDF of pictures, for the second tier
    private const HOW = ['structured', 'list', 'text', 'ai'];

    /** The columns and the page log this needs, added on first use wherever source_facts lives (decisions/0110). */
    public static function ensure(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        try {
            $f = Database::t('source_facts');
            if (!$pdo->query("SHOW COLUMNS FROM $f LIKE 'category_id'")->fetch())
                $pdo->exec("ALTER TABLE $f ADD COLUMN category_id INT UNSIGNED NULL, ADD COLUMN kind_conf TINYINT UNSIGNED NULL,
                    ADD COLUMN kind_words VARCHAR(255) NULL, ADD COLUMN section VARCHAR(120) NULL, ADD COLUMN schema_type VARCHAR(80) NULL,
                    ADD COLUMN town VARCHAR(120) NULL, ADD COLUMN state CHAR(2) NULL, ADD COLUMN website VARCHAR(500) NULL,
                    ADD COLUMN hours VARCHAR(500) NULL, ADD COLUMN lat DECIMAL(9,6) NULL, ADD COLUMN lng DECIMAL(9,6) NULL,
                    ADD COLUMN page_kind VARCHAR(12) NULL, ADD COLUMN read_how VARCHAR(12) NULL,
                    ADD KEY idx_source_facts_cat (category_id), ADD KEY idx_source_facts_town (town, state)");
            // a place the listings' guards hold (protected, on a nation's land, a person's name: review A1), kept and marked
            if (!$pdo->query("SHOW COLUMNS FROM $f LIKE 'held'")->fetch())
                $pdo->exec("ALTER TABLE $f ADD COLUMN held VARCHAR(12) NULL");
            $r = Database::t('reference_sources');
            if (!$pdo->query("SHOW COLUMNS FROM $r LIKE 'read_every'")->fetch())
                $pdo->exec("ALTER TABLE $r ADD COLUMN read_every SMALLINT UNSIGNED NULL");
            $pdo->exec('CREATE TABLE IF NOT EXISTS ' . Database::t('crawl_pages') . ' (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                url_hash CHAR(40) NOT NULL, url VARCHAR(1000) NOT NULL, host VARCHAR(190) NOT NULL,
                status SMALLINT NOT NULL DEFAULT 0, ctype VARCHAR(80) NULL, bytes INT UNSIGNED NOT NULL DEFAULT 0,
                fingerprint CHAR(40) NULL, etag VARCHAR(190) NULL, last_modified VARCHAR(60) NULL,
                title VARCHAR(200) NULL, page_kind VARCHAR(12) NULL, named SMALLINT UNSIGNED NOT NULL DEFAULT 0, links MEDIUMTEXT NULL,
                first_at DATETIME NOT NULL, fetched_at DATETIME NOT NULL, changed_at DATETIME NULL,
                every_days SMALLINT UNSIGNED NOT NULL DEFAULT 30, next_at DATETIME NOT NULL,
                PRIMARY KEY (id), UNIQUE KEY uq_crawl_pages_url (url_hash), KEY idx_crawl_pages_host (host, next_at)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci');
            // how a page was read when our fetch couldn't (tavily, textract), and a scan's text until the worker reads it
            $p = Database::t('crawl_pages');
            if (!$pdo->query("SHOW COLUMNS FROM $p LIKE 'via'")->fetch())
                $pdo->exec("ALTER TABLE $p ADD COLUMN via VARCHAR(12) NULL, ADD COLUMN scan_text MEDIUMTEXT NULL, ADD COLUMN scan_at DATETIME NULL, ADD KEY idx_crawl_pages_kind (page_kind, scan_at)");
        } catch (Throwable $e) { error_log('SourceIndex::ensure: ' . $e->getMessage()); }
    }

    private static function hostOf(string $host): string { return (string) preg_replace('/^www\./', '', strtolower(trim($host))); }

    public static function tableExists(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM ' . Database::t('source_facts') . ' LIMIT 1'); return true; } catch (PDOException) { return false; }
    }

    /** The next source due for reading, marked as read now so two runs don't take it. */
    public static function next(PDO $pdo): ?array
    {
        if (!self::tableExists($pdo) || !Sources::tableExists($pdo)) return null;
        self::ensure($pdo);
        $every = self::hasColumn($pdo, 'reference_sources', 'read_every') ? 'COALESCE(read_every, ' . self::REREAD_DAYS . ')' : (string) self::REREAD_DAYS;
        $st = $pdo->query("SELECT id, host, home_url, kind FROM " . Database::t('reference_sources') . " WHERE status = 'read'
                              AND (last_read_at IS NULL OR last_read_at < NOW() - INTERVAL $every DAY)
                            ORDER BY last_read_at IS NULL DESC, last_read_at ASC LIMIT 1");
        $s = $st->fetch(PDO::FETCH_ASSOC);
        if (!$s) return null;
        $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET last_read_at = NOW() WHERE id = ?')->execute([(int) $s['id']]);
        return ['host' => (string) $s['host'], 'home_url' => (string) $s['home_url'], 'kind' => (string) $s['kind'],
                'pages' => self::known($pdo, self::hostOf((string) $s['host']))];
    }

    /** What the page log knows of a site's pages, for asking whether each changed: url => [etag, modified, links]. */
    private static function known(PDO $pdo, string $host): array
    {
        $out = [];
        try {
            $st = $pdo->prepare('SELECT url, etag, last_modified, links, next_at <= NOW() AS due FROM ' . Database::t('crawl_pages') . ' WHERE host = ? AND status IN (200, 304) ORDER BY fetched_at DESC LIMIT 500');
            $st->execute([$host]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $out[(string) $r['url']] = ['etag' => (string) $r['etag'], 'modified' => (string) $r['last_modified'], 'due' => (bool) (int) $r['due'],   // not due: skipped this read (decisions/0157 §8)
                                            'links' => array_values(array_filter((array) json_decode((string) $r['links'], true), 'is_string'))];
            }
        } catch (Throwable $e) {}
        return $out;
    }

    private static function hasColumn(PDO $pdo, string $t, string $c): bool
    {
        try { return (bool) $pdo->query('SHOW COLUMNS FROM ' . Database::t($t) . ' LIKE ' . $pdo->quote($c))->fetch(); } catch (Throwable $e) { return false; }
    }

    /**
     * The worker's page log for one read of a site (decisions/0157 §1): each page's answer, and when to read it next.
     * Returns how often the site should now be read (days), from its pages: the most often-changing one leads.
     */
    public static function logPages(PDO $pdo, string $host, array $rows): ?int
    {
        self::ensure($pdo);
        $t = Database::t('crawl_pages');
        try {
            $get = $pdo->prepare("SELECT id, fingerprint, every_days FROM $t WHERE url_hash = ?");
            $ins = $pdo->prepare("INSERT INTO $t (url_hash, url, host, status, ctype, bytes, fingerprint, etag, last_modified, title, page_kind, named, links,
                                    first_at, fetched_at, changed_at, every_days, next_at)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), NOW(), ?, NOW() + INTERVAL ? DAY)");
            $upd = $pdo->prepare("UPDATE $t SET status = ?, ctype = COALESCE(?, ctype), bytes = IF(? > 0, ?, bytes), fingerprint = COALESCE(?, fingerprint),
                                    etag = ?, last_modified = ?, title = COALESCE(?, title), page_kind = COALESCE(?, page_kind), named = IF(? IS NULL, named, ?),
                                    links = COALESCE(?, links), fetched_at = NOW(), changed_at = IF(?, NOW(), changed_at),
                                    every_days = ?, next_at = NOW() + INTERVAL ? DAY WHERE id = ?");
        } catch (Throwable $e) { error_log('SourceIndex::logPages: ' . $e->getMessage()); return null; }
        $least = null;
        foreach (array_slice($rows, 0, 200) as $r) {
            $url = trim((string) ($r['url'] ?? ''));
            if (!preg_match('#^https?://#i', $url) || mb_strlen($url) > 1000) continue;
            $status = max(0, min(999, (int) ($r['status'] ?? 0)));
            $fp = preg_match('/^[0-9a-f]{40}$/', (string) ($r['fingerprint'] ?? '')) ? (string) $r['fingerprint'] : null;
            $kind = in_array($r['page_kind'] ?? '', self::PAGE_KINDS, true) ? (string) $r['page_kind'] : null;
            $links = isset($r['links']) && is_array($r['links'])
                ? json_encode(array_values(array_slice(array_filter($r['links'], fn ($l) => is_string($l) && preg_match('#^https?://#i', $l) && strlen($l) <= 1000), 0, 60)), JSON_UNESCAPED_SLASHES)
                : null;
            $named = isset($r['named']) ? max(0, min(65535, (int) $r['named'])) : null;
            $ctype = isset($r['type']) && $r['type'] !== '' ? mb_substr((string) $r['type'], 0, 80) : null;
            $title = isset($r['title']) && $r['title'] !== '' ? mb_substr(strip_tags((string) $r['title']), 0, 200) : null;
            $bytes = max(0, (int) ($r['bytes'] ?? 0));
            $etag = mb_substr((string) ($r['etag'] ?? ''), 0, 190) ?: null;
            $mod = mb_substr((string) ($r['modified'] ?? ''), 0, 60) ?: null;
            $h = sha1($url);
            try {
                $get->execute([$h]); $old = $get->fetch(PDO::FETCH_ASSOC);
                if (!$old) {
                    $every = self::REREAD_DAYS;
                    $ins->execute([$h, $url, $host, $status, $ctype, $bytes, $fp, $etag, $mod, $title, $kind, (int) $named, $links, $every, $every]);
                } else {
                    $was = max(self::EVERY_MIN, (int) $old['every_days']);
                    // changed: its text isn't what it was; unchanged: a 304, or the same text again
                    $changed = $status === 200 && $fp !== null && $fp !== (string) $old['fingerprint'];
                    $same = $status === 304 || ($status === 200 && $fp !== null && $fp === (string) $old['fingerprint']);
                    $every = $changed ? max(self::EVERY_MIN, intdiv($was, 2)) : ($same ? min(self::EVERY_MAX, $was * 2) : $was);
                    $upd->execute([$status, $ctype, $bytes, $bytes, $fp, $etag, $mod, $title, $kind, $named, (int) $named, $links, $changed ? 1 : 0, $every, $every, (int) $old['id']]);
                }
                if ($status === 200 || $status === 304) $least = $least === null ? $every : min($least, $every);
                if (in_array($r['via'] ?? '', ['tavily', 'commoncrawl'], true)) $pdo->prepare("UPDATE $t SET via = ? WHERE url_hash = ?")->execute([(string) $r['via'], $h]);
            } catch (Throwable $e) { error_log('SourceIndex::logPages ' . $url . ': ' . $e->getMessage()); }
        }
        if ($least !== null && self::hasColumn($pdo, 'reference_sources', 'read_every'))
            $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET read_every = ? WHERE host = ? OR host = ?')->execute([$least, $host, 'www.' . $host]);
        return $least;
    }

    /**
     * What the worker just read of a source: each page it read replaces that page's own places; pages it didn't reach
     * keep theirs (review B6, 2026-11-13: a starved read used to wipe every place from the host). A read that reached no
     * page and named nothing changes nothing: the source is handed back, due again in HAND_BACK_HOURS.
     * $log: the worker's page log for this read (logPages()). Returns how many were kept (-1: handed back).
     */
    public static function store(PDO $pdo, string $host, array $facts, array $log = [], array $unchanged = []): int
    {
        $host = self::hostOf($host);
        self::ensure($pdo);
        $f = Database::t('source_facts');
        // the pages this read really read: a 200 with its text (a fingerprint), or gone (404, 410). Not a 304, not a scan
        // waiting for Textract, not a page it never reached.
        $read = [];
        foreach ($log as $r) {
            if (!is_array($r)) continue;
            $u = mb_substr(trim((string) ($r['url'] ?? '')), 0, 500); $st = (int) ($r['status'] ?? 0);
            if (!preg_match('#^https?://#i', $u)) continue;
            if (($st === 200 && preg_match('/^[0-9a-f]{40}$/', (string) ($r['fingerprint'] ?? ''))) || in_array($st, [404, 410], true)) $read[$u] = true;
        }
        foreach ($facts as $x) if (is_array($x) && preg_match('#^https?://#i', (string) ($x['url'] ?? ''))) $read[mb_substr((string) $x['url'], 0, 500)] = true;
        if (!$read && !$facts) { self::handBack($pdo, $host); if ($log) self::logPages($pdo, $host, $log); return -1; }
        if ($log) self::logPages($pdo, $host, $log);
        if ($read) {
            foreach (array_chunk(array_keys($read), 200) as $chunk)
                $pdo->prepare("DELETE FROM $f WHERE host = ? AND page_url IN (" . implode(',', array_fill(0, count($chunk), '?')) . ')')->execute(array_merge([$host], $chunk));
        }
        // an older worker sends facts with no page log, and facts without a page: those replace nothing they don't name
        $n = self::insertFacts($pdo, $host, $facts);
        $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET last_read_at = NOW() WHERE host = ? OR host = ?')->execute([$host, 'www.' . $host]);
        // what it names that we don't list goes to the intake, to be checked like any find (decisions/0157 §3)
        if ($n && self::hasColumn($pdo, 'source_facts', 'category_id')) { try { self::stageNew($pdo, $host); } catch (Throwable $e) { error_log('SourceIndex::store stage: ' . $e->getMessage()); } }
        return $n;
    }

    /** A source taken for a read that didn't happen (the run ran out of time): due again soon, its places untouched. */
    private static function handBack(PDO $pdo, string $host): void
    {
        try {
            $every = self::hasColumn($pdo, 'reference_sources', 'read_every') ? 'COALESCE(read_every, ' . self::REREAD_DAYS . ')' : (string) self::REREAD_DAYS;
            $pdo->prepare('UPDATE ' . Database::t('reference_sources') . " SET last_read_at = NOW() - INTERVAL $every DAY + INTERVAL " . self::HAND_BACK_HOURS . ' HOUR WHERE host = ? OR host = ?')
                ->execute([$host, 'www.' . $host]);
        } catch (Throwable $e) { error_log('SourceIndex::handBack ' . $host . ': ' . $e->getMessage()); }
    }

    /**
     * Pages read from Common Crawl's archive (decisions/0157 §8.3): logged like any page (via commoncrawl), each page's places
     * replacing that page's alone, and new ones staged. Returns how many places were kept.
     */
    public static function storeMore(PDO $pdo, string $host, array $facts, array $log): int
    {
        $host = self::hostOf($host);
        self::ensure($pdo);
        $log = array_values(array_filter($log, fn ($r) => is_array($r) && self::hostOf((string) parse_url((string) ($r['url'] ?? ''), PHP_URL_HOST)) === $host));
        if ($log) self::logPages($pdo, $host, array_map(fn ($r) => ['via' => 'commoncrawl'] + $r, $log));
        $urls = array_values(array_unique(array_map(fn ($r) => (string) $r['url'], $log)));
        foreach (array_chunk($urls, 100) as $chunk)
            $pdo->prepare('DELETE FROM ' . Database::t('source_facts') . ' WHERE host = ? AND page_url IN (' . implode(',', array_fill(0, count($chunk), '?')) . ')')->execute(array_merge([$host], $chunk));
        $in = array_flip($urls);
        $n = self::insertFacts($pdo, $host, array_values(array_filter($facts, fn ($x) => is_array($x) && isset($in[(string) ($x['url'] ?? '')]))));
        if ($n && self::hasColumn($pdo, 'source_facts', 'category_id')) { try { self::stageNew($pdo, $host); } catch (Throwable $e) { error_log('SourceIndex::storeMore stage: ' . $e->getMessage()); } }
        return $n;
    }

    /** One page's places, replacing that page's alone (a scan Textract read, decisions/0157 §7.2). Returns how many were kept. */
    public static function storePage(PDO $pdo, string $host, string $url, array $facts): int
    {
        $host = self::hostOf($host);
        self::ensure($pdo);
        if (!preg_match('#^https?://#i', $url)) return 0;
        $pdo->prepare('DELETE FROM ' . Database::t('source_facts') . ' WHERE host = ? AND page_url = ?')->execute([$host, mb_substr($url, 0, 500)]);
        $facts = array_values(array_filter($facts, fn ($x) => is_array($x) && ($x['url'] ?? '') === $url));
        $n = self::insertFacts($pdo, $host, $facts);
        $pdo->prepare('UPDATE ' . Database::t('crawl_pages') . " SET via = 'textract', scan_text = NULL, named = ? WHERE url_hash = ?")->execute([$n, sha1($url)]);
        if ($n && self::hasColumn($pdo, 'source_facts', 'category_id')) { try { self::stageNew($pdo, $host); } catch (Throwable $e) { error_log('SourceIndex::storePage stage: ' . $e->getMessage()); } }
        return $n;
    }

    /** Facts as the worker sent them, checked and described, into the place store for a site. Returns how many. */
    private static function insertFacts(PDO $pdo, string $host, array $facts): int
    {
        $f = Database::t('source_facts');
        $rich = self::hasColumn($pdo, 'source_facts', 'category_id');
        $ins = $rich
            ? $pdo->prepare("INSERT INTO $f (host, page_url, name, address, house_number, phone_digits, zip, category_id, kind_conf, kind_words, section, schema_type,
                               town, state, website, hours, lat, lng, page_kind, read_how) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            : $pdo->prepare("INSERT INTO $f (host, page_url, name, address, house_number, phone_digits, zip) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $n = 0; $towns = []; $noTown = [];
        foreach (array_slice($facts, 0, 2000) as $x) {
            if (!is_array($x)) continue;
            $name = mb_substr(trim(html_entity_decode(strip_tags((string) ($x['name'] ?? '')), ENT_QUOTES)), 0, 255);
            $url = (string) ($x['url'] ?? '');
            $addr = mb_substr(trim(strip_tags((string) ($x['address'] ?? ''))), 0, 255);
            $phone = substr((string) preg_replace('/\D/', '', (string) ($x['phone'] ?? '')), -10);
            if ($name === '' || !preg_match('#^https?://#i', $url) || (strlen($phone) !== 10 && !preg_match('/^\s*\d+/', $addr))) continue;
            preg_match('/^\s*(\d+[a-z]?)\b/i', $addr, $m);
            preg_match('/\b(\d{5})(?:-\d{4})?\s*$/', $addr, $z);
            $zip = $z[1] ?? (preg_match('/^\d{5}$/', (string) ($x['zip'] ?? '')) ? (string) $x['zip'] : null);
            $row = [$host, mb_substr($url, 0, 500), $name, $addr ?: null, $m[1] ?? null, strlen($phone) === 10 ? $phone : null, $zip];
            if ($rich) {
                $d = self::describe($pdo, $x, $name, $zip);
                if ($d['town'] === null) $noTown[] = $n;
                else { $k = $d['town'] . '|' . $d['state']; $towns[$k] = ($towns[$k] ?? 0) + 1; }
                $row = array_merge($row, [$d['category_id'], $d['kind_conf'], $d['kind_words'], $d['section'], $d['schema_type'], $d['town'], $d['state'],
                                          $d['website'], $d['hours'], $d['lat'], $d['lng'], $d['page_kind'], $d['read_how']]);
            }
            try { $ins->execute($row); $n++; } catch (Throwable $e) { error_log('SourceIndex::store: ' . $e->getMessage()); }
        }
        // a place with no town of its own (no ZIP, address or page town) takes the site's: the town most of its places are in
        if ($rich && $noTown && $towns) {
            arsort($towns);
            [$tn, $ts] = explode('|', (string) array_key_first($towns)) + ['', ''];
            $pdo->prepare("UPDATE $f SET town = ?, state = ? WHERE host = ? AND town IS NULL")->execute([$tn, $ts ?: null, $host]);
        }
        return $n;
    }

    /** What a place is and where (decisions/0157 §2 steps 4-5), from what the worker read. */
    private static function describe(PDO $pdo, array $x, string $name, ?string $zip): array
    {
        $str = fn ($k, $len) => ($v = trim(mb_substr(strip_tags((string) ($x[$k] ?? '')), 0, $len))) === '' ? null : $v;
        $words = $str('words', 255); $section = $str('section', 120); $schema = $str('schema_type', 80);
        $kinds = array_values(array_filter(array_map(fn ($k) => trim(strip_tags((string) $k)), (array) ($x['kinds'] ?? [])), fn ($k) => $k !== '' && strcasecmp($k, 'LocalBusiness') && strcasecmp($k, 'Organization') && strcasecmp($k, 'Place')));
        [$cat, $conf] = self::kindOf($pdo, $name, $kinds, $section, $words, (string) ($x['title'] ?? ''));
        // where: its ZIP's town, else the town in its address, else the town the page names most (the site's comes after)
        $town = null; $state = null;
        if ($zip !== null && ($zt = self::zipTown($pdo, $zip))) [$town, $state] = $zt;
        if ($town === null && $str('town', 120)) { $town = $str('town', 120); $state = strtoupper((string) $str('state', 2)) ?: null; }
        if ($town === null && $str('page_town', 120)) { $town = $str('page_town', 120); $state = strtoupper((string) $str('page_state', 2)) ?: null; }
        $site = (string) ($x['website'] ?? '');
        $lat = is_numeric($x['lat'] ?? null) && abs((float) $x['lat']) <= 90 ? round((float) $x['lat'], 6) : null;
        $lng = is_numeric($x['lng'] ?? null) && abs((float) $x['lng']) <= 180 ? round((float) $x['lng'], 6) : null;
        return ['category_id' => $cat, 'kind_conf' => $conf, 'kind_words' => $words, 'section' => $section, 'schema_type' => $schema,
                'town' => $town, 'state' => $state !== null && preg_match('/^[A-Z]{2}$/', $state) ? $state : null,
                'website' => preg_match('#^https?://[^\s]+$#i', $site) && strlen($site) <= 500 ? $site : null,
                'hours' => $str('hours', 500), 'lat' => $lat !== null && $lng !== null ? $lat : null, 'lng' => $lat !== null && $lng !== null ? $lng : null,
                'page_kind' => in_array($x['page_kind'] ?? '', self::PAGE_KINDS, true) ? (string) $x['page_kind'] : null,
                'read_how' => in_array($x['how'] ?? '', self::HOW, true) ? (string) $x['how'] : 'text'];
    }

    /** Headings that say nothing of what's under them. */
    private const PLAIN_HEADINGS = '/^(home|about( us)?|contact( us| information)?|hours|location|locations|directions|links|resources|services|'
        . 'directory|departments?|menu|news|events|faq|more|info(rmation)?|overview|welcome|search|quick links|related|staff|our team)$/i';

    /**
     * The kind of business a place's words say (decisions/0157 §2 step 4), by what its signals agree on: the category
     * classifier listings use, and what each of these means as search reads words (Concepts): the kinds it calls itself
     * in its structured data, the heading it sits under on a list page, its own words, its name. A kind most of them
     * point to wins; one signal alone counts only when it's sure. [category id, how sure 0-99] or [null, null].
     */
    public static function kindOf(PDO $pdo, string $name, array $kinds, ?string $section, ?string $words, string $title = ''): array
    {
        static $cats = null, $byName = null;
        try {
            require_once dirname(__DIR__) . '/CategoryClassifier.php';
            if ($cats === null) {
                $cats = CategoryClassifier::categories($pdo); $byName = [];
                foreach ($cats as $c) if (!in_array((string) $c['group_name'], CategoryClassifier::FALLBACK, true)) $byName[mb_strtolower((string) $c['name'])] = (int) $c['id'];
            }
            if (!$cats) return [null, null];
            $vote = [];
            $add = function (?int $id, float $w) use (&$vote) { if ($id) $vote[$id] = ($vote[$id] ?? 0) + $w; };
            foreach (CategoryClassifier::classify(['name' => $name, 'what' => ['types' => $kinds, 'offerings' => array_filter([$section]), 'description' => (string) $words]], $cats, 3) as $r)
                if (isset($byName[mb_strtolower((string) $r['name'])])) $add((int) $r['id'], (int) $r['confidence'] / 100);
            if (is_file(dirname(__DIR__) . '/Concepts.php')) {
                require_once dirname(__DIR__) . '/Concepts.php';
                $sec = trim((string) $section);
                if ($sec !== '' && preg_match(self::PLAIN_HEADINGS, $sec)) $sec = '';
                // [the words, how much they count, how much a name's words are averaged down (one word of three names it)]
                foreach ([[implode(' ', $kinds), 1.2, false], [$sec, 1.0, false], [(string) $words, 0.7, false], [$name, 1.0, true]] as [$text, $w, $isName]) {
                    $text = trim(mb_substr($text, 0, 200));
                    if ($text === '') continue;
                    foreach (Concepts::kinds($pdo, $text, 3) as $k) {
                        $sc = (float) $k['score'];
                        if ($isName) $sc = min(1.0, $sc * 3);   // a name's other words are names ("Apache County Regional"), not kinds: its one kind word counts whole
                        $add($byName[mb_strtolower((string) $k['name'])] ?? null, $sc * $w);
                    }
                }
            }
            if (!$vote) return [null, null];
            arsort($vote);
            $id = (int) array_key_first($vote); $top = (float) reset($vote);
            $conf = (int) min(99, round($top * 50));
            return $conf >= self::KIND_MIN ? [$id, $conf] : [null, null];
        } catch (Throwable $e) { error_log('SourceIndex::kindOf: ' . $e->getMessage()); }
        return [null, null];
    }

    /** A street address, not directions ("140 W Cleveland St", never "3 mi North of St. Johns"). */
    private static function isStreet(string $s): bool
    {
        return (bool) preg_match('/^\s*\d+[a-z]?\s+(?!(mi|mile|miles|min|km|minutes?|blocks?)\b)[A-Za-z0-9]/i', $s);
    }

    /** A ZIP's town and state (the locations data), once a request each. */
    private static function zipTown(PDO $pdo, string $zip): ?array
    {
        static $memo = [];
        if (!array_key_exists($zip, $memo)) {
            $memo[$zip] = null;
            try {
                $st = $pdo->prepare('SELECT city, state FROM zip_coordinates WHERE zip = ? AND city IS NOT NULL AND city <> \'\' LIMIT 1');
                $st->execute([$zip]);
                if ($r = $st->fetch(PDO::FETCH_ASSOC)) $memo[$zip] = [mb_substr((string) $r['city'], 0, 120), strtoupper(substr((string) $r['state'], 0, 2))];
            } catch (Throwable $e) {}
        }
        return $memo[$zip];
    }

    // ---- Searching our own index (decisions/0157 §3) -------------------------------------------------------------------

    /** How far a search looks for places named on pages we read (miles), unless it says. */
    private const NEAR_MILES = 25;

    /**
     * Places named on pages we read that we don't list yet, for a search: by the kinds its words mean (and any categories
     * the caller already read), or by their own name and words, within reach of the place. Nearest first, one per place
     * (its sources together). $o: text, cats [ids], lat, lon, miles, city, state, limit, named_only (the admin's search:
     * by name, anywhere). Each: [name, address, town, state, phone, kind, miles, website, hours, how, sources [[host, url]]].
     */
    public static function search(PDO $pdo, array $o): array
    {
        if (!self::tableExists($pdo) || !self::hasColumn($pdo, 'source_facts', 'category_id')) return [];
        $text = trim(mb_strtolower(mb_substr((string) ($o['text'] ?? ''), 0, 120)));
        $limit = max(1, min(30, (int) ($o['limit'] ?? 8)));
        $cats = array_values(array_unique(array_filter(array_map('intval', (array) ($o['cats'] ?? [])))));
        if ($text !== '' && empty($o['named_only'])) {
            try {
                require_once dirname(__DIR__) . '/Concepts.php';
                $names = array_map(fn ($k) => (string) $k['name'], array_filter(Concepts::kinds($pdo, $text, 4), fn ($k) => (float) $k['score'] >= 0.5));
                if ($names) {
                    $in = implode(',', array_fill(0, count($names), '?'));
                    $st = $pdo->prepare("SELECT id FROM categories WHERE is_active = 1 AND name IN ($in)"); $st->execute($names);
                    $cats = array_values(array_unique(array_merge($cats, array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)))));
                }
            } catch (Throwable $e) {}
        }
        if ($cats) {   // a group takes in its kinds
            try {
                $in = implode(',', array_fill(0, count($cats), '?'));
                $st = $pdo->prepare("SELECT id FROM categories WHERE id IN ($in) OR parent_id IN ($in)"); $st->execute(array_merge($cats, $cats));
                $cats = array_values(array_unique(array_merge($cats, array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)))));
            } catch (Throwable $e) {}
        }
        $words = array_values(array_filter(preg_split('/[^\p{L}\p{N}]+/u', $text) ?: [], fn ($w) => mb_strlen($w) >= 3
            && !in_array($w, ['the', 'and', 'near', 'for', 'with', 'from', 'places', 'place', 'open', 'now', 'best', 'good', 'some'], true)));
        $or = []; $args = [];
        if ($cats) { $or[] = 'f.category_id IN (' . implode(',', array_fill(0, count($cats), '?')) . ')'; $args = array_merge($args, $cats); }
        if ($words) {
            $and = [];
            foreach (array_slice($words, 0, 5) as $w) {
                $and[] = empty($o['named_only']) ? "CONCAT_WS(' ', f.name, f.kind_words, f.section) LIKE ?" : 'f.name LIKE ?';
                $args[] = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $w) . '%';
            }
            $or[] = '(' . implode(' AND ', $and) . ')';
        }
        if (!$or) return [];
        $where = '(' . implode(' OR ', $or) . ')';
        $lat = is_numeric($o['lat'] ?? null) ? (float) $o['lat'] : null; $lon = is_numeric($o['lon'] ?? null) ? (float) $o['lon'] : null;
        $miles = (float) ($o['miles'] ?? self::NEAR_MILES) ?: self::NEAR_MILES;
        if (($lat === null || $lon === null) && !empty($o['city'])) {
            if ($c = self::townPoint($pdo, (string) $o['city'], (string) ($o['state'] ?? ''))) [$lat, $lon] = $c;
        }
        if (($lat === null || $lon === null) && empty($o['named_only'])) return [];   // a place is needed: nearest first, never everywhere
        $box = '';
        if ($lat !== null && $lon !== null) {   // a box first (cheap), the miles after
            $dLat = $miles / 69; $dLon = $miles / max(1.0, 69 * cos(deg2rad($lat)));
            $box = ' AND ((f.lat BETWEEN ? AND ? AND f.lng BETWEEN ? AND ?) OR (f.lat IS NULL AND (z.latitude BETWEEN ? AND ? AND z.longitude BETWEEN ? AND ?)) OR (f.lat IS NULL AND z.latitude IS NULL))';
            $args = array_merge($args, [$lat - $dLat, $lat + $dLat, $lon - $dLon, $lon + $dLon, $lat - $dLat, $lat + $dLat, $lon - $dLon, $lon + $dLon]);
        }
        $F = Database::t('source_facts'); $R = Database::t('reference_sources');
        try {
            $st = $pdo->prepare("SELECT f.*, z.latitude AS zlat, z.longitude AS zlon, c.name AS kind FROM $F f
                                   LEFT JOIN zip_coordinates z ON z.zip = f.zip
                                   LEFT JOIN categories c ON c.id = f.category_id
                                   LEFT JOIN $R s ON s.host = f.host
                                  WHERE $where AND COALESCE(s.status, 'read') <> 'ignore' $box
                                  LIMIT 400");
            $st->execute($args);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { error_log('SourceIndex::search: ' . $e->getMessage()); return []; }
        // where each one is; nearest first; one per place (the same phone, or the same name in the same town)
        $out = [];
        foreach ($rows as $r) {
            $pl = $r['lat'] !== null ? [(float) $r['lat'], (float) $r['lng']] : ($r['zlat'] !== null ? [(float) $r['zlat'], (float) $r['zlon']] : ($r['town'] ? self::townPoint($pdo, (string) $r['town'], (string) $r['state']) : null));
            $mi = $pl && $lat !== null ? self::miles($lat, $lon, $pl[0], $pl[1]) : null;
            if ($lat !== null && ($mi === null || $mi > $miles)) continue;
            // the listings' guards (review A1, decisions/0066, 0133): held places never show; a confidential address never
            // shows; on a nation's land its pin follows the nation's rules
            $g = self::guard($pdo, $r, $pl);
            if ($g['held'] !== '') continue;
            $r = $g['row']; $pl = $g['point'];
            $key = self::squash((string) $r['name']) . '|' . mb_strtolower((string) $r['town']);   // one place: its name in its town (a county's transfer stations share one phone)
            $src = [(string) $r['host'], (string) $r['page_url']];
            if (isset($out[$key])) { if (!in_array($src, $out[$key]['sources'], true)) $out[$key]['sources'][] = $src; foreach (['website', 'hours', 'kind'] as $k) if (!$out[$key][$k] && $r[$k]) $out[$key][$k] = $r[$k]; continue; }
            $out[$key] = ['name' => (string) $r['name'], 'address' => (string) ($r['address'] ?? ''), 'town' => (string) ($r['town'] ?? ''), 'state' => (string) ($r['state'] ?? ''),
                          'zip' => (string) ($r['zip'] ?? ''), 'phone' => (string) ($r['phone_digits'] ?? ''), 'kind' => (string) ($r['kind'] ?? ''), 'miles' => $mi !== null ? round($mi, 1) : null,
                          'website' => (string) ($r['website'] ?? ''), 'hours' => (string) ($r['hours'] ?? ''), 'how' => (string) ($r['read_how'] ?? ''),
                          'lat' => $pl[0] ?? null, 'lon' => $pl[1] ?? null, 'sources' => [$src], 'nation' => $g['nation'], 'confidential' => $g['confidential']];
        }
        $out = array_values($out);
        usort($out, fn ($a, $b) => ($a['miles'] ?? 0) <=> ($b['miles'] ?? 0) ?: strcmp($a['name'], $b['name']));
        // what we already list goes: it's in the results as ours
        $keep = [];
        foreach ($out as $x) { if (count($keep) >= $limit) break; if (!self::listed($pdo, $x)) $keep[] = $x; }
        return $keep;
    }

    /**
     * The listings' guards for a place named on a page we read (review A1, 2026-11-13), as decisions/0066 and 0133 ask:
     * - a protected place (sacred, burial, archaeological, a cemetery of a nation's peoples) shows only when it's plainly
     *   public (open to visitors, off a nation's land: Landmarks::publiclyKnown); otherwise it's held: never named here.
     *   A search card is all "the way in" (address, phone, directions), so "known, not open" has no card either;
     * - on a nation's land: a business (a phone or a website) shows with the nation's name, its pin moved to a public
     *   place or dropped (Nations::pin); anything else there is held until the nation's tools exist;
     * - a confidential address (a shelter) never shows: the phone only;
     * - a name that reads as a person's is held (a contact named on a page isn't a place).
     * The data is kept, never deleted; held rows are marked (held) where the column exists.
     * ['held' => why or '', 'row', 'point', 'nation' => label or '', 'confidential' => bool]
     */
    /** Words that make a name a place's, never a person's ("Second Mesa Overlook", "Smith Ranch"). */
    private const PLACE_WORDS = '/\\b(overlook|mesa|park|trail|trailhead|lake|canyon|peak|creek|springs?|butte|ranch|school|church|chapel|cent(er|re)|museum|hall|house|lodge|inn|cafe|store|shop|market|river|valley|point|rock|falls|dam|forest|camp|well|wash|tank|ridge|hills?|mountains?|road|street|plaza|square|gardens?|farm|station|office|library|clinic|motel|hotel|mill|mine|bridge|monument|memorial|cemetery|fort|pueblo)\\b/i';

    public static function guard(PDO $pdo, array $r, ?array $pl): array
    {
        require_once dirname(__DIR__) . '/Landmarks.php';
        require_once dirname(__DIR__) . '/Nations.php';
        require_once dirname(__DIR__) . '/ListingSafety.php';
        require_once __DIR__ . '/AutoImport.php';
        Landmarks::loadPeoples($pdo);
        $out = ['held' => '', 'row' => $r, 'point' => $pl, 'nation' => '', 'confidential' => false];
        $name = (string) ($r['name'] ?? '');
        $shape = $pl ? Nations::at($pdo, (float) $pl[0], (float) $pl[1]) : null;
        $text = trim($name . ' ' . (string) ($r['kind_words'] ?? '') . ' ' . (string) ($r['section'] ?? '') . ' ' . (string) ($r['kind'] ?? ''));
        if (Landmarks::isProtected($text, (string) $shape)
            && !Landmarks::publiclyKnown(['name' => $name, 'wd_desc' => trim((string) ($r['kind_words'] ?? '') . ' ' . (string) ($r['section'] ?? '')), 'nation' => (string) $shape]))
            $out['held'] = 'protected';
        elseif ($shape !== null && trim((string) ($r['phone_digits'] ?? '')) === '' && trim((string) ($r['website'] ?? '')) === '')
            $out['held'] = 'nation';
        elseif (AutoImport::looksPerson($name) && $r['category_id'] === null && !preg_match(self::PLACE_WORDS, $name) && !preg_match(Landmarks::NOTABLE, $name))
            $out['held'] = 'person';
        if ($out['held'] !== '') { self::markHeld($pdo, (int) ($r['id'] ?? 0), $out['held']); return $out; }
        if ($shape !== null) {
            $out['nation'] = Nations::label($pdo, $shape);
            [$la, $lo] = Nations::pin($pdo, (float) $pl[0], (float) $pl[1]);
            $out['point'] = $la !== null ? [(float) $la, (float) $lo] : null;
            $out['row']['lat'] = $la; $out['row']['lng'] = $lo;
        }
        if (ListingSafety::isConfidential($r['category_id'] !== null ? (int) $r['category_id'] : null, $name)) {
            $out['confidential'] = true;
            $out['row']['address'] = ''; $out['row']['lat'] = null; $out['row']['lng'] = null; $out['point'] = null;
        }
        return $out;
    }

    /** A place held by guard(): marked once (where the held column exists), kept for the nation's tools and our team. */
    private static function markHeld(PDO $pdo, int $id, string $why): void
    {
        if ($id <= 0 || !self::hasColumn($pdo, 'source_facts', 'held')) return;
        try { $pdo->prepare('UPDATE ' . Database::t('source_facts') . ' SET held = ? WHERE id = ? AND (held IS NULL OR held <> ?)')->execute([$why, $id, $why]); } catch (Throwable $e) {}
    }

    /**
     * Do we list it already? The same phone, or most of each name in the other, within about a mile (or in its ZIP).
     * The listing's id, or 0.
     */
    public static function listed(PDO $pdo, array $x): int
    {
        $want = self::words((string) $x['name']);
        $phone = (string) ($x['phone'] ?? '');
        try {
            if ($x['lat'] !== null && $x['lon'] !== null) {
                $d = 0.015;
                $st = $pdo->prepare("SELECT e.id, e.name, JSON_UNQUOTE(m.meta_value) AS phone FROM entities e LEFT JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'phone'
                                      WHERE e.entity_type = 'merchant' AND ((e.latitude BETWEEN ? AND ? AND e.longitude BETWEEN ? AND ?) OR e.primary_zip = ?) LIMIT 300");
                $st->execute([(float) $x['lat'] - $d, (float) $x['lat'] + $d, (float) $x['lon'] - $d * 1.3, (float) $x['lon'] + $d * 1.3, (string) ($x['zip'] ?: '00000')]);
            } elseif (($x['zip'] ?? '') !== '') {
                $st = $pdo->prepare("SELECT e.id, e.name, JSON_UNQUOTE(m.meta_value) AS phone FROM entities e LEFT JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'phone'
                                      WHERE e.entity_type = 'merchant' AND e.primary_zip = ? LIMIT 300");
                $st->execute([(string) $x['zip']]);
            } else return 0;
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $e) {
                if (strlen($phone) === 10 && substr((string) preg_replace('/\D/', '', (string) $e['phone']), -10) === $phone) return (int) $e['id'];
                $have = self::words((string) $e['name']);
                // most of each name in the other ("Blue Hills Environmental" isn't "Blue Hills Motel")
                $both = count(array_intersect_key($want, $have));
                if ($want && $have && $both / count($want) >= 0.7 && $both / count($have) >= 0.7) return (int) $e['id'];
            }
        } catch (Throwable $e) { error_log('SourceIndex::listed: ' . $e->getMessage()); }
        return 0;
    }

    /** A town's middle (the locations data), once a request each. */
    private static function townPoint(PDO $pdo, string $city, string $state): ?array
    {
        static $memo = [];
        $city = trim((string) preg_replace('/^st\.?\s+/i', 'Saint ', trim($city))); $state = strtoupper(trim($state));
        $k = mb_strtolower($city) . '|' . $state;
        if (!array_key_exists($k, $memo)) {
            $memo[$k] = null;
            try {
                $st = $pdo->prepare('SELECT AVG(latitude), AVG(longitude) FROM zip_coordinates WHERE city = ?' . ($state !== '' ? ' AND state = ?' : ''));
                $st->execute($state !== '' ? [$city, $state] : [$city]);
                $r = $st->fetch(PDO::FETCH_NUM);
                if ($r && $r[0] !== null) $memo[$k] = [(float) $r[0], (float) $r[1]];
            } catch (Throwable $e) {}
        }
        return $memo[$k];
    }

    private static function miles(float $a, float $b, float $c, float $d): float
    {
        $r = 3958.8; $p = M_PI / 180;
        $h = sin(($c - $a) * $p / 2) ** 2 + cos($a * $p) * cos($c * $p) * sin(($d - $b) * $p / 2) ** 2;
        return 2 * $r * asin(min(1.0, sqrt($h)));
    }

    private static function squash(string $s): string { return (string) preg_replace('/[^a-z0-9]+/', '', mb_strtolower($s)); }

    /** A row for a search's results: what it is, where, and its sources one tap away. */
    public static function card(array $x): array
    {
        $ph = $x['phone'] !== '' ? '(' . substr($x['phone'], 0, 3) . ') ' . substr($x['phone'], 3, 3) . '-' . substr($x['phone'], 6) : '';
        $hosts = array_values(array_unique(array_map(fn ($s) => $s[0], $x['sources'])));
        return ['label' => $x['name'], 'kind' => $x['kind'], 'address' => $x['address'], 'town' => trim($x['town'] . ($x['state'] ? ', ' . $x['state'] : ''), ', '),
                'phone' => $ph, 'tel' => $x['phone'], 'miles' => $x['miles'], 'website' => $x['website'], 'hours' => $x['hours'],
                'source' => $x['sources'][0][1], 'source_host' => $x['sources'][0][0], 'sources' => count($x['sources']),
                'from' => 'Named on ' . $hosts[0] . (count($hosts) > 1 ? ' and ' . (count($hosts) - 1) . ' more' : ''),
                // on a nation's land: its name, and that visitors follow its rules (decisions/0066); a confidential address isn't shown
                'nation' => (string) ($x['nation'] ?? ''), 'note' => ($x['nation'] ?? '') !== '' ? 'On ' . $x['nation'] . ' land: visitors follow the nation\'s rules.' : (!empty($x['confidential']) ? 'Its address is kept private.' : '')];
    }

    // ---- Staging what we read (decisions/0157 §3, 0044) ----------------------------------------------------------------

    /** At most this many places from one read go to the intake at a time (the rest on later reads). */
    private const STAGE_PER_READ = 40;

    /**
     * Places on a source we just read that we don't list yet go to the intake like any crawl's finds (IntakeStager,
     * decisions/0044): two independent sources publish one, the rest wait in Review, and the second look checks them.
     * Only places with a kind of business and a ZIP (the intake places nothing without one). Returns how many were sent.
     */
    public static function stageNew(PDO $pdo, string $host): int
    {
        if (!self::hasColumn($pdo, 'source_facts', 'category_id')) return 0;
        $F = Database::t('source_facts');
        try {
            $st = $pdo->prepare("SELECT f.*, c.name AS kind, z.latitude AS zlat, z.longitude AS zlon FROM $F f LEFT JOIN categories c ON c.id = f.category_id
                                   LEFT JOIN zip_coordinates z ON z.zip = f.zip
                                  WHERE f.host = ? AND f.category_id IS NOT NULL AND f.zip IS NOT NULL ORDER BY f.id LIMIT 300");
            $st->execute([self::hostOf($host)]);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { error_log('SourceIndex::stageNew: ' . $e->getMessage()); return 0; }
        if (!$rows) return 0;
        require_once __DIR__ . '/IntakeStager.php';
        require_once __DIR__ . '/CrawlQueue.php';
        $cands = []; $seen = [];
        foreach ($rows as $r) {
            if (count($cands) >= self::STAGE_PER_READ) break;
            $k = self::squash((string) $r['name']) . '|' . $r['zip'];
            if (isset($seen[$k])) continue;
            $seen[$k] = true;
            $x = ['name' => (string) $r['name'], 'phone' => (string) $r['phone_digits'], 'zip' => (string) $r['zip'],
                  'lat' => $r['lat'] !== null ? (float) $r['lat'] : ($r['zlat'] !== null ? (float) $r['zlat'] : null),
                  'lon' => $r['lng'] !== null ? (float) $r['lng'] : ($r['zlon'] !== null ? (float) $r['zlon'] : null)];
            if (self::guard($pdo, $r, $x['lat'] !== null ? [$x['lat'], $x['lon']] : null)['held'] !== '') continue;   // held places never become finds (review A1)
            if ($lid = self::listed($pdo, $x)) { self::link($pdo, $lid, $r); continue; }   // ours already: what the page says joins its record
            $street = trim((string) preg_split('/,/', (string) $r['address'])[0]);
            if (preg_match('/^(.*?\d.*?)\s+' . preg_quote((string) $r['town'], '/') . '\b/i', $street, $m)) $street = trim($m[1]);   // "12 Main St Springerville AZ" -> "12 Main St"
            $url = (string) $r['page_url'];
            $c = CrawlQueue::normalize([
                'name' => $r['name'],
                'source' => ['start_url' => $url, 'site' => (string) $r['host'], 'pages_crawled' => 1, 'crawled_at' => (string) $r['seen_at']],
                'what' => ['offerings' => array_values(array_filter([(string) $r['kind'], (string) $r['section']])), 'description' => (string) ($r['kind_words'] ?? '')],
                'where' => ['address' => self::isStreet($street) ? $street : '', 'city' => (string) $r['town'], 'state' => (string) $r['state'], 'zip' => (string) $r['zip'], 'location_page' => $url],
                'when' => ['hours' => array_filter([(string) $r['hours']])],
                'actions' => ['phone' => (string) $r['phone_digits'], 'website' => (string) ($r['website'] ?? '')],
                'sources' => ['name' => [$url], 'address' => $street !== '' ? [$url] : [], 'phone' => $r['phone_digits'] ? [$url] : []],
                // what one page we read regularly is worth: a name, and its address or phone there (as a site's own locations page)
                'confidence' => 15 + ($street !== '' ? 25 : 0) + ($r['phone_digits'] ? 15 : 0) + 5,
            ]);
            if ($c) $cands[] = $c;
        }
        if (!$cands) return 0;
        try {
            $sid = IntakeStager::createSource($pdo, 'https://' . self::hostOf($host) . '/', ['create_listings'], 'Our source: ' . self::hostOf($host) . ' (places named on it, decisions/0157)', 0);
            $r = IntakeStager::stage($pdo, $sid, $cands);
            IntakeStager::recordRun($pdo, $sid, 0, ['from the place store'], null);
            if ($r['auto_imported'] && is_file(dirname(__DIR__) . '/SearchIndex.php')) {
                require_once dirname(__DIR__) . '/SearchIndex.php';
                try { if (SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, array_map('intval', $r['auto_imported'])); } catch (Throwable $e) {}
            }
            return count($r['staged']) + count($r['auto_imported']);
        } catch (Throwable $e) { error_log('SourceIndex::stageNew stage: ' . $e->getMessage()); return 0; }
    }

    /**
     * A place on a page we read that we already list: what the page says joins the listing's record (decisions/0157 §2 step
     * 6, §6), each fact with the page as its source, so its record shows every source, and where they disagree. Only what the
     * site's licence lets us store; never a confidential place's address (decisions/0044).
     */
    private static function link(PDO $pdo, int $listing, array $r): void
    {
        static $done = [];
        $url = (string) $r['page_url'];
        if (isset($done[$listing . '|' . $url]) || !is_file(dirname(__DIR__) . '/Identity.php')) return;
        $done[$listing . '|' . $url] = true;
        try {
            require_once dirname(__DIR__) . '/Identity.php';
            if (!Identity::ready($pdo) || !Sources::mayStore($pdo, (string) $r['host'])) return;
            $e = $pdo->prepare('SELECT category_id, name FROM entities WHERE id = ?'); $e->execute([$listing]); $e = $e->fetch(PDO::FETCH_ASSOC);
            $private = $e && ListingSafety::isConfidential($e['category_id'] !== null ? (int) $e['category_id'] : null, (string) $e['name']);
            $src = ['kind' => Identity::kindFor($url), 'url' => $url, 'label' => 'Named on ' . (string) $r['host'] . ' (' . ['structured' => 'its structured data', 'list' => 'a list', 'text' => 'its text', 'ai' => 'read by AI'][(string) ($r['read_how'] ?? 'text')] . ')'];
            $street = trim((string) preg_split('/,/', (string) $r['address'])[0]);
            $add = ['phone' => (string) ($r['phone_digits'] ?? ''), 'website' => (string) ($r['website'] ?? ''), 'hours' => (string) ($r['hours'] ?? '')];
            if (!$private && self::isStreet($street)) $add['address'] = $street;
            $n = 0;
            foreach ($add as $fact => $v) if ($v !== '' && Identity::add($pdo, 'listing', $listing, $fact, $v, $src)) $n++;
            if ($n) Identity::recompute($pdo, 'listing', $listing);
        } catch (Throwable $e) { error_log('SourceIndex::link: ' . $e->getMessage()); }
    }

    /**
     * How we read a source page (for "What we know and where from", decisions/0157 §6): when, how (its structured data, a list,
     * its text, a scan, through Tavily), the kind of page, and what its site's licence lets us do. Null when it isn't one we read.
     */
    public static function about(PDO $pdo, string $url): ?array
    {
        static $memo = [];
        if ($url === '' || !preg_match('#^https?://#i', $url)) return null;
        if (array_key_exists($url, $memo)) return $memo[$url];
        $out = null;
        try {
            $st = $pdo->prepare('SELECT host, fetched_at, page_kind, via FROM ' . Database::t('crawl_pages') . ' WHERE url_hash = ?'); $st->execute([sha1($url)]);
            if ($p = $st->fetch(PDO::FETCH_ASSOC)) {
                $how = $pdo->prepare('SELECT read_how FROM ' . Database::t('source_facts') . ' WHERE page_url = ? LIMIT 1'); $how->execute([mb_substr($url, 0, 500)]);
                $h = (string) ($how->fetchColumn() ?: '');
                $rules = Sources::rules($pdo, (string) $p['host']);
                $out = ['read_at' => (string) $p['fetched_at'],
                        'how' => ($p['via'] ?? '') === 'textract' ? 'a scan, read by AWS Textract' : (($p['via'] ?? '') === 'tavily' ? 'through Tavily' : (['structured' => 'its structured data', 'list' => 'an item on a list', 'text' => 'its text', 'ai' => 'read by AI'][$h] ?? 'its text')),
                        'page' => ['own_site' => 'its own site', 'list' => 'a list', 'events' => 'events', 'notice' => 'a notice', 'article' => 'an article', 'scan' => 'a scanned PDF'][(string) $p['page_kind']] ?? '',
                        'use' => explode(' (', (string) (Sources::USES[$rules['use_rule'] ?? ''] ?? ''))[0], 'licence' => (string) (Sources::LICENCES[$rules['licence'] ?? ''] ?? '')];
            }
        } catch (Throwable $e) {}
        return $memo[$url] = $out;
    }

    // ---- "Send the crawler" (Jason only, decisions/0157 §3) ------------------------------------------------------------

    /**
     * For a town and words: its registered sources are read again first, the sources waiting for a person's call there
     * are listed, and OpenStreetMap is asked again for the town's kinds of places (TownCrawl). Free: no web search.
     * Returns ['reread' => n, 'osm' => n of kinds queued, 'waiting' => [[host, home_url]], 'place' => key].
     */
    public static function sendCrawler(PDO $pdo, string $city, string $state, string $words = ''): array
    {
        self::ensure($pdo);
        $city = trim($city); $state = strtoupper(trim($state));
        $alt = (string) preg_replace('/^st\.?\s+/i', 'Saint ', $city); $alt2 = (string) preg_replace('/^saint\s+/i', 'St. ', $city);
        $F = Database::t('source_facts'); $R = Database::t('reference_sources');
        $out = ['reread' => 0, 'osm' => 0, 'waiting' => [], 'place' => ''];
        try {
            $st = $pdo->prepare("UPDATE $R SET last_read_at = NULL WHERE status = 'read' AND host IN (SELECT host FROM (SELECT DISTINCT host FROM $F WHERE town IN (?, ?, ?) AND (state = ? OR state IS NULL)) h)");
            $st->execute([$city, $alt, $alt2, $state]);
            $out['reread'] = $st->rowCount();
            // the sites waiting for a call that name the town in their address ("stjohnsaz.gov") or that we met on its pages
            $sq = self::squash($alt2) ?: self::squash($city);
            $st = $pdo->prepare("SELECT host, home_url FROM $R WHERE status = 'suggested' AND (REPLACE(REPLACE(host, '-', ''), '.', '') LIKE ? OR REPLACE(REPLACE(host, '-', ''), '.', '') LIKE ?) ORDER BY host LIMIT 10");
            $st->execute(['%' . self::squash((string) preg_replace('/^st\.?\s+/i', 'st', $city)) . '%', '%' . self::squash($alt) . '%']);
            $out['waiting'] = $st->fetchAll(PDO::FETCH_NUM);
        } catch (Throwable $e) { error_log('SourceIndex::sendCrawler sources: ' . $e->getMessage()); }
        try {
            require_once __DIR__ . '/TownCrawl.php';
            require_once dirname(__DIR__) . '/OnDemand.php';
            $key = (string) (OnDemand::townFor($pdo, $alt, $state) ?? OnDemand::townFor($pdo, $city, $state) ?? '');
            if ($key !== '' && TownCrawl::ready($pdo)) {
                $out['place'] = $key;
                $pdo->prepare("UPDATE town_crawl_jobs SET status = 'queued', attempts = 0, lease_until = NULL, priority = GREATEST(priority, 5000), updated_at = NOW() WHERE place_key = ? AND status IN ('done', 'failed')")->execute([$key]);
                $out['osm'] = TownCrawl::queue($pdo, $key, 4000);
            }
        } catch (Throwable $e) { error_log('SourceIndex::sendCrawler osm: ' . $e->getMessage()); }
        return $out;
    }

    private static function words(string $s): array
    {
        $out = [];
        foreach (preg_split('/[^a-z0-9]+/', strtolower($s)) as $w) {
            if (strlen($w) < 3 || in_array($w, ['the', 'and', 'inc', 'llc', 'center', 'centre'], true)) continue;
            $out[strlen($w) > 4 && str_ends_with($w, 's') && !str_ends_with($w, 'ss') ? substr($w, 0, -1) : $w] = true;
        }
        return $out;
    }

    /**
     * Facts that confirm a staged listing, as Verify::complete() "found" items (one per website).
     * Skips websites the listing already cites.
     */
    public static function matches(PDO $pdo, array $c, array $knownHosts): array
    {
        if (!self::tableExists($pdo)) return [];
        $want = self::words((string) ($c['name'] ?? ''));
        if (!$want) return [];
        $zip = (string) ($c['where']['zip'] ?? '');
        $phone = substr(preg_replace('/\D/', '', (string) ($c['actions']['phone'] ?? '')), -10);
        preg_match('/^\s*(\d+[a-z]?)\b/i', (string) ($c['where']['address'] ?? ''), $m);
        $house = $m[1] ?? '';
        if ($zip === '' && strlen($phone) !== 10) return [];
        $st = $pdo->prepare('SELECT f.*, s.kind FROM ' . Database::t('source_facts') . ' f LEFT JOIN ' . Database::t('reference_sources') . ' s ON s.host = f.host
                              WHERE (f.zip = ? OR f.phone_digits = ?) AND COALESCE(s.status, \'read\') <> \'ignore\' LIMIT 300');
        $st->execute([$zip ?: '00000', strlen($phone) === 10 ? $phone : '0000000000']);
        $known = array_flip($knownHosts);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) {
            if (isset($known[$f['host']]) || isset($out[$f['host']])) continue;
            $have = self::words((string) $f['name']);
            if (count(array_intersect_key($want, $have)) / count($want) < 0.6) continue;
            $byPhone = strlen($phone) === 10 && $f['phone_digits'] === $phone;
            $byAddr = $house !== '' && strcasecmp((string) $f['house_number'], $house) === 0;
            if (!$byPhone && !$byAddr) continue;
            $kind = ['government' => 'government', 'chamber' => 'chamber', 'community_directory' => 'directory', 'tourism' => 'website', 'organization' => 'website'][$f['kind'] ?? ''] ?? 'website';
            $out[$f['host']] = ['url' => (string) $f['page_url'], 'kind' => $kind, 'evidence' => $byPhone && $byAddr ? 'both' : ($byPhone ? 'phone' : 'address'),
                                'label' => 'Our source: ' . (string) $f['name'], 'phone' => $f['phone_digits'] ?? ''];
        }
        return array_values($out);
    }
}
