<?php
// app/lib/GuideLinks.php — everything a guide names links to something we have (decisions/0131 §4). On save, scan()
// picks the names out of the written sections (Claude when it's on; always [[Name]], **Name**, roads, and the names of
// what we already have nearby), matches each one (listings, towns, neighborhoods, areas, landmarks, outdoor places,
// resource lines, roads) and queues a "Find it" job for each one we don't have. findTick() works those jobs: Claude with
// web search finds the place, confirms it's real, open and in the area, and puts it in Review as a suggestion; nothing
// is shown until a person approves it (decisions/0005). A guide goes live only when every name is linked or taken out.
declare(strict_types=1);

require_once __DIR__ . '/Guides.php';

final class GuideLinks
{
    /** A protected place a public source publishes, not open to visitors (decisions/0133, KNOWN, NOT OPEN). */
    public const KNOWN_NOTE = 'Known publicly, not open to visit: a public source publishes it, so the guide may name it and tell its story as plain text, never the way in (no directions, roads, trailheads or distances), and says it may be visited only with the authorization of the nation or the land\'s managers. Its own page stays held (decisions/0066, 0133).';

    public const KINDS = ['business' => 'Business', 'museum' => 'Museum', 'organization' => 'Organization', 'event' => 'Event', 'town' => 'Town',
                          'neighborhood' => 'Neighborhood', 'area' => 'Area', 'landmark' => 'Landmark', 'outdoors' => 'Lake, trail or park', 'road' => 'Road', 'resource' => 'Who to call'];
    /** A mention's state: linked, linked but thin (the record needs more), being found, waiting in Review, not confirmed,
     *  held (may mark a sacred or protected site: never linked or created), the listing is marked closed, taken out of
     *  the check by a person. */
    public const STATUS = ['linked' => 'Linked', 'thin' => 'Linked (needs details)', 'finding' => 'Finding it…', 'review' => 'In Review',
                           'unconfirmed' => 'Couldn\'t confirm', 'held' => 'Held (sensitive)', 'closed' => 'Closed', 'dismissed' => 'Not a place (ignored)'];
    public const BLOCKING = ['held', 'closed'];   // what keeps a guide from going live (a name we don't have yet stays plain text until Find it links it)
    public const WAITING = ['finding', 'review', 'unconfirmed'];
    private const CLOSED_NOTE = 'This business is marked closed: take it out of the guide, or reopen the listing if it is open.';
    private const ABBR = ['rstrnt' => 'restaurant', 'rstrnts' => 'restaurants', 'scty' => 'society', 'svc' => 'service', 'svcs' => 'services', 'ctr' => 'center', 'mtn' => 'mountain',
                          'mtns' => 'mountains', 'regl' => 'regional', 'assn' => 'association', 'hstrcl' => 'historical', 'mus' => 'museum', 'natl' => 'national', 'co' => 'company', 'inc' => '', 'llc' => '', 'the' => ''];

    /** Words a business adds to its name that don't change which place it is. */
    private const GENERIC = ['and', 'restaurant', 'restaurants', 'cafe', 'grill', 'bar', 'company', 'resort', 'hotel', 'motel', 'inn', 'lodge', 'museum', 'society', 'store', 'shop',
                             'center', 'llc', 'co', 'az', 'arizona', 'of', 'at', 'cabins', 'rv', 'lounge', 'eatery', 'diner', 'pub',
                             'archaeological', 'park', 'historic', 'site', 'monument'];   // "Besh-Ba-Gowah" is "Besh Ba Gowah Archaeological Park" (2026-11-12)

    public static function ready(PDO $pdo): bool { require_once __DIR__ . '/ContentTags.php'; return ContentTags::ready($pdo); }   // the guides' names live in the tag store (decisions/0132)

    /** "Molly Butler Lodge & Rstrnt" and "Molly Butler Lodge and Restaurant" read the same. */
    public static function norm(string $s): string
    {
        $s = strtolower(str_replace(['&', '’', "'"], [' and ', '', ''], $s));
        $s = (string) preg_replace('/\bst\.?\s+(?=[a-z])/', 'saint ', $s);
        $w = preg_split('/[^a-z0-9]+/', $s, -1, PREG_SPLIT_NO_EMPTY);
        $w = array_values(array_filter(array_map(fn ($x) => self::ABBR[$x] ?? $x, $w), fn ($x) => $x !== ''));
        return implode(' ', $w);
    }

    /** Does a name we have read as the name the guide wrote? */
    public static function same(string $written, string $ours): bool
    {
        $a = self::norm($written); $b = self::norm($ours);
        if ($a === '' || $b === '') return false;
        if ($a === $b) return true;
        $ta = explode(' ', $a); $tb = explode(' ', $b);
        // one name inside the other: only when what's left over is generic ("Molly Butler Lodge" is "… and Restaurant";
        // "Apache County" isn't "Apache County Road Yards"; "Mount Baldy Wilderness" isn't the peak)
        if (count($ta) >= 2 && count($tb) >= 2) {
            [$short, $long] = count($ta) <= count($tb) ? [$ta, $tb] : [$tb, $ta];
            if (!array_diff($short, $long)) return !array_diff(array_diff($long, $short), self::GENERIC);
        }
        $common = count(array_intersect($ta, $tb));
        return $common >= 2 && $common / count(array_unique(array_merge($ta, $tb))) >= 0.75 && !array_diff(array_diff(array_merge($ta, $tb), array_intersect($ta, $tb)), self::GENERIC);
    }

    // ---- picking the names out ------------------------------------------------------------------------------------------

    /** The names in the written sections: [[name, kind, section]], each once per section. */
    public static function extract(PDO $pdo, array $p, array $sections, bool $ai = true, string $feature = 'guide_names'): array
    {
        $out = [];
        $add = function (string $n, string $k, string $sec) use (&$out, $p) {
            $n = trim((string) preg_replace('/\s+/', ' ', $n), " .,;:–-");
            if (mb_strlen($n) < 3 || mb_strlen($n) > 150 || self::norm($n) === self::norm($p['name'])) return;
            $out[$sec . '|' . mb_strtolower($n)] ??= [$n, isset(self::KINDS[$k]) ? $k : 'business', $sec];
        };
        require_once __DIR__ . '/Roads511.php';
        foreach ($sections as $sec => $text) {
            if (preg_match_all('/\[\[([^\]|]{2,150})(?:\|([a-z]+))?\]\]/u', $text, $m, PREG_SET_ORDER)) foreach ($m as $x) $add($x[1], $x[2] ?? 'business', $sec);
            if (preg_match_all('/\*\*([^*]{3,150})\*\*/u', $text, $m)) foreach ($m[1] as $x) if (preg_match('/^\p{Lu}/u', $x) && !preg_match('/[:.!?]$/', $x)) $add($x, 'business', $sec);
            foreach (Roads511::roadsIn($text) as $r) $add($r, 'road', $sec);
        }
        // Claude reads the text for every named thing (the reliable way); without it, the names of what we have nearby
        if ($ai && self::aiOn($pdo, $feature)) {   // a member's words only with their AI & Learning consent (decisions/0132 §2a); each feature within its AI use settings
            try {
                $doc = ''; foreach ($sections as $sec => $text) $doc .= "\n\n[section: $sec]\n" . (string) preg_replace('/\[\[([^\]|]+)(\|[a-z]+)?\]\]/', '$1', $text);
                $r = AiClient::claudeAsk("This is the text of a travel guide for {$p['name']}" . ($p['state'] ? ', ' . $p['state'] : '') . ". List every specific named thing in it: businesses, restaurants, lodges, museums, "
                    . "towns, neighborhoods, areas, landmarks, natural features (lakes, rivers, trails, mountains, wilderness areas, forests, parks), roads, events and organizations. "
                    . "Give each name as written, its kind, and the section it is in. Leave out {$p['name']} itself, states, counties, countries, generic words (\"the lake\", \"local cafes\") and people's names.\n" . mb_substr($doc, 0, 24000),
                    ['type' => 'object', 'additionalProperties' => false, 'required' => ['names'], 'properties' => ['names' => ['type' => 'array', 'items' => ['type' => 'object', 'additionalProperties' => false, 'required' => ['name', 'kind', 'section'],
                        'properties' => ['name' => ['type' => 'string'], 'kind' => ['type' => 'string', 'enum' => array_keys(self::KINDS)], 'section' => ['type' => 'string']]]]]],
                    AiClient::feature($pdo, $feature)['model'], 0, 3000);
                AiClient::record($pdo, $feature, 0, 'done', $r);
                foreach ((array) ($r['data']['names'] ?? []) as $x) if (isset($sections[$x['section'] ?? ''])) $add((string) $x['name'], (string) $x['kind'], (string) $x['section']);
            } catch (Throwable $x) { error_log('guide names: ' . $x->getMessage()); }
        }
        $dict = [];   // what we have nearby, written in the text: the longest name wins ("Sunrise Park Resort", not "Sunrise")
        foreach (self::nearbyNames($pdo, $p) as [$name, $kind]) {
            $nn = self::norm($name); if (strlen($nn) < 6 || preg_match('/^[a-z ]{2,30} county$/', $nn)) continue;   // "Apache County" is the county, not a place to link
            $one = !str_contains($nn, ' ');   // a one-word name ("Sunrise", "Hunt") counts only written as a name, capitalized: "at sunrise" is a time of day
            foreach ($sections as $sec => $text) if (str_contains(' ' . self::norm($text) . ' ', ' ' . $nn . ' ') && (!$one || preg_match('/(?<![\p{L}])' . preg_quote($name, '/') . '(?![\p{L}])/u', $text))) $dict[$sec][$nn] = [$name, $kind];
        }
        foreach ($dict as $sec => $hits) {
            $found = array_map(fn ($x) => self::norm($x[0]), array_filter($out, fn ($x) => $x[2] === $sec));
            uksort($hits, fn ($a, $b) => strlen($b) <=> strlen($a));
            foreach ($hits as $nn => [$name, $kind]) {
                $inside = false;
                foreach ($found as $f) if ($f === $nn || str_contains(' ' . $f . ' ', ' ' . $nn . ' ')) { $inside = true; break; }
                if ($inside) continue;
                $add($name, $kind, $sec); $found[] = $nn;
            }
        }
        // one per name in a section ("Apache County Historical Scty" is "Apache County Historical Society")
        $seen = []; $keep = [];
        foreach ($out as $x) { $k = $x[2] . '|' . self::norm($x[0]); if (isset($seen[$k])) continue; $seen[$k] = 1; $keep[] = $x; }
        return $keep;
    }

    private static function aiOn(PDO $pdo, string $feature = 'guide_names'): bool
    {
        require_once __DIR__ . '/AiClient.php';
        return AiClient::allow($pdo, $feature)[0];   // on, under the month's cap, and within the feature's own settings (System Configuration → AI use)
    }

    /** Names of places and listings within reach (for finding them in text without Claude): [[name, kind]]. */
    private static function nearbyNames(PDO $pdo, array $p): array
    {
        $out = [];
        if ($p['lat'] === null) return $out;
        foreach (Guides::tree($pdo) as [$k, $n, $tier]) if ($tier >= 4) {   // towns and neighborhoods within reach
            $q = Guides::place($pdo, $k);
            if ($q && $q['lat'] !== null && Guides::miles($p['lat'], $p['lon'], $q['lat'], $q['lon']) <= 60) $out[] = [$n, $tier === 6 ? 'neighborhood' : 'town'];
        }
        [$la1, $la2, $lo1, $lo2] = self::box($p['lat'], $p['lon'], 40);
        try {
            $st = $pdo->prepare("SELECT name FROM entities WHERE is_suppressed = 0 AND status IN ('unclaimed','claimed-unverified','pending-verification','verified') AND latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ? LIMIT 3000");
            $st->execute([$la1, $la2, $lo1, $lo2]); foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $n) if (str_word_count((string) $n) >= 2) $out[] = [(string) $n, 'business'];
            require_once __DIR__ . '/Landmarks.php';
            $st = $pdo->prepare('SELECT name FROM landmarks WHERE ' . Landmarks::visibleSql() . ' AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?'); $st->execute([$la1, $la2, $lo1, $lo2]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $n) if (str_word_count((string) $n) >= 2) $out[] = [(string) $n, 'landmark'];
        } catch (Throwable) {}
        return $out;
    }

    private static function box(float $lat, float $lon, float $mi): array { $d = $mi / 69; $e = $mi / max(1, 69 * cos(deg2rad($lat))); return [$lat - $d, $lat + $d, $lon - $e, $lon + $e]; }

    // ---- matching ---------------------------------------------------------------------------------------------------------

    /**
     * What a name links to: [ref, status, note]. ref '' when we don't have it. Places and roads first for their kinds,
     * then listings, landmarks, outdoor places and resource lines near the guide.
     */
    /** Did the guide's draft find this protected-sounding name published by a public source (Guides::scrub)? */
    private static function publishedFor(PDO $pdo, string $key, string $name): bool
    {
        static $by = [];
        if (!isset($by[$key])) { $di = json_decode((string) (Guides::get($pdo, $key)['draft_info'] ?? ''), true) ?: []; $by[$key] = (array) ($di['published'] ?? []); }
        foreach ($by[$key] as $n) if (self::same($name, (string) $n) || self::same((string) $n, $name)) return true;
        return false;
    }

    public static function match(PDO $pdo, array $p, string $name, string $kind): array
    {
        require_once __DIR__ . '/Roads511.php';
        if ($kind === 'road' || Roads511::road($name) !== '') { $r = Roads511::road($name); if ($r !== '') return ['route:' . $r, 'linked', '']; }
        $order = in_array($kind, ['town', 'neighborhood', 'area'], true) ? ['place', 'landmark', 'rec', 'entity', 'resource']
            : (in_array($kind, ['landmark', 'outdoors'], true) ? ['rec', 'landmark', 'place', 'entity', 'resource'] : (in_array($kind, ['resource'], true) ? ['resource', 'entity'] : ['entity', 'landmark', 'rec', 'place', 'resource']));
        foreach ($order as $src) { $m = self::find($pdo, $p, $src, $name); if ($m) return $m; }
        return ['', 'finding', ''];
    }

    private static function find(PDO $pdo, array $p, string $src, string $name): ?array
    {
        $words = explode(' ', self::norm($name)); usort($words, fn ($a, $b) => strlen($b) <=> strlen($a));
        $first = $words[0] ?? '';   // the longest word narrows the search best ("camino", not "el"); "fair grounds" vs "fairgrounds": tried as a run too
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $first === 'saint' ? 'st' : $first) . '%';
        $near = $p['lat'] !== null ? self::box($p['lat'], $p['lon'], 60) : null;
        try {
            if ($src === 'place') {
                foreach (Guides::tree($pdo) as [$k, $n]) if (self::same($name, $n)) return [$k, 'linked', ''];
                return null;
            }
            if ($src === 'entity') {
                $st = $pdo->prepare("SELECT id, name, latitude, longitude FROM entities WHERE is_suppressed = 0 AND status IN ('unclaimed','claimed-unverified','pending-verification','verified') AND name LIKE ?" . ($near ? ' AND latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?' : '') . ' LIMIT 200');
                $st->execute(array_merge([$like], $near ?: []));
                $best = null;
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (self::same($name, (string) $r['name'])) {
                    $d = $p['lat'] !== null && $r['latitude'] !== null ? Guides::miles($p['lat'], $p['lon'], (float) $r['latitude'], (float) $r['longitude']) : 99;
                    if (!$best || $d < $best[1]) $best = [$r, $d];
                }
                if (!$best) {   // a listing that says it's held private (a shelter) is never linked from a guide: same as not having it
                    return null;
                }
                [$r] = $best;
                $meta = $pdo->query("SELECT meta_key FROM entity_metadata WHERE entity_id = " . (int) $r['id'] . " AND meta_key IN ('hours','website','closed')")->fetchAll(PDO::FETCH_COLUMN);
                if (in_array('closed', $meta, true)) return ['entity:' . (int) $r['id'], 'closed', self::CLOSED_NOTE];
                $raw = preg_match('/\b(Rstrnt|Scty|Svc|Ctr|Regl|Hstrcl|Assn)\b/', (string) $r['name']);
                $note = trim(($raw ? 'Its name needs tidying ("' . $r['name'] . '"). ' : '') . (!$meta ? 'It has no hours or website yet.' : ''));
                return ['entity:' . (int) $r['id'], $note !== '' ? 'thin' : 'linked', $note];
            }
            if ($src === 'landmark') {
                require_once __DIR__ . '/Landmarks.php';
                $st = $pdo->prepare('SELECT gnis_id, name, status, nation, wd_desc, wiki_title, why, reviewed_by FROM landmarks WHERE name LIKE ?' . ($near ? ' AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?' : '') . ' LIMIT 100');
                $st->execute(array_merge([$like], $near ?: []));
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (self::same($name, (string) $r['name'])) {
                    // held on a word, but plainly public (its own article, open to visitors) and no person decided otherwise: shown, and linked
                    if (!Landmarks::visible($r) && ($r['status'] ?? '') === 'waiting' && empty($r['reviewed_by']) && str_starts_with((string) ($r['why'] ?? ''), 'Sensitive: the name may mark') && Landmarks::publiclyKnown($r)) {
                        try { $pdo->prepare("UPDATE landmarks SET status = 'shown', why = ? WHERE gnis_id = ? AND status = 'waiting'")->execute([Landmarks::KNOWN_WHY, (int) $r['gnis_id']]); } catch (Throwable) {}
                        return ['landmark:' . $r['gnis_id'], 'linked', ''];
                    }
                    if (Landmarks::visible($r)) return ['landmark:' . $r['gnis_id'], 'linked', ''];
                    // decisions/0133's three levels (review A4, 2026-11-13): closed by the nation, hidden by our team, or held by a
                    // person's decision is HELD: never named, whatever a source publishes. Held only on a word and published by a
                    // public source we read is KNOWN, NOT OPEN: named and told as plain text, never the way in.
                    if (in_array((string) ($r['status'] ?? ''), ['closed', 'hidden'], true) || (($r['status'] ?? '') === 'waiting' && !empty($r['reviewed_by'])))
                        return ['', 'held', ($r['status'] ?? '') === 'closed' ? 'Closed by the nation, so a guide doesn\'t name it (decisions/0066, 0133). Take it out.' : 'Held by a decision (ours or the nation\'s), so a guide doesn\'t name it (decisions/0133). Take it out.'];
                    return self::publishedFor($pdo, (string) $p['key'], $name) ? ['', 'dismissed', self::KNOWN_NOTE]
                        : ['', 'held', 'This name may mark a sacred or protected site, and no public source we read publishes it: take it out of the guide (decisions/0066).'];
                }
                return null;
            }
            if ($src === 'rec') {
                $st = $pdo->prepare('SELECT ridb_id, name FROM rec_places WHERE COALESCE(hidden, 0) = 0 AND name LIKE ?' . ($near ? ' AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?' : '') . ' LIMIT 100');
                $st->execute(array_merge(['%' . trim(str_replace(['%', '_'], ['\%', '\_'], $name)) . '%'], $near ?: []));
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) return ['rec:' . $r['ridb_id'], 'linked', ''];
                $st->execute(array_merge([$like], $near ?: []));
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (self::same($name, (string) $r['name'])) return ['rec:' . $r['ridb_id'], 'linked', ''];
                return null;
            }
            if ($src === 'resource') {
                $st = $pdo->prepare("SELECT id, name FROM resource_entries WHERE status = 'live' AND name LIKE ? LIMIT 50"); $st->execute([$like]);
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (self::same($name, (string) $r['name'])) return ['resource:' . (int) $r['id'], 'linked', ''];
                return null;
            }
        } catch (Throwable $x) { error_log('guide match ' . $src . ': ' . $x->getMessage()); }
        return null;
    }

    /** Where a link goes. */
    public static function url(PDO $pdo, string $ref): string
    {
        if (preg_match('/^entity:(\d+)$/', $ref, $m)) return '/listing/view.php?id=' . (int) $m[1];
        if (preg_match('/^landmark:(\d+)$/', $ref, $m)) return '/place/landmark.php?id=' . (int) $m[1];
        if (preg_match('/^rec:(.+)$/', $ref, $m)) return '/place/recreation.php?id=' . rawurlencode($m[1]);
        if (str_starts_with($ref, 'route:')) return '#roads';
        if (str_starts_with($ref, 'resource:')) return '#who-to-call';
        $pl = Guides::place($pdo, $ref);
        return $pl ? $pl['url'] : '';
    }

    // ---- the guide's names ------------------------------------------------------------------------------------------------

    /**
     * Picks the names out of a guide's sections, matches them, keeps the list (the tag store, content_tags) and queues Find it for the
     * names we don't have. A name a person linked by hand or set aside keeps that. Returns [names, linked, queued].
     */
    public static function scan(PDO $pdo, array $p, array $sections, string $src = '', bool $ai = true, string $byKind = 'system', ?int $byId = null): array
    {
        if (!self::ready($pdo)) return ['names' => 0, 'linked' => 0, 'queued' => 0];
        $src = $src !== '' ? $src : 'guide:' . $p['key'];   // a guide, or any other piece the Chameleon Filter reads (journey:12, story:3…)
        $names = self::extract($pdo, $p, $sections, $ai, str_starts_with($src, 'guide:') ? 'guide_names' : 'content_names');
        $had = [];
        $st = $pdo->prepare('SELECT * FROM content_tags WHERE src = ?'); $st->execute([$src]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $m) $had[$m['section'] . '|' . mb_strtolower($m['name'])] = $m;
        $keep = []; $linked = 0; $queued = 0;
        foreach ($names as [$name, $kind, $sec]) {
            $k = $sec . '|' . mb_strtolower($name); $keep[$k] = true;
            $old = $had[$k] ?? null;
            // set aside or linked by a person: kept that way. One the matcher set aside (a protected place a source publishes)
            // is matched again each time, so a place since closed by the nation or held by a person stops being named (review A4)
            $byHand = $old && (str_starts_with((string) $old['note'], 'Set aside by hand') || ($old['ref'] !== '' && str_starts_with((string) $old['note'], 'Linked by hand')));
            if ($old && $old['status'] === 'dismissed' && $old['note'] !== self::KNOWN_NOTE && !str_starts_with((string) $old['note'], 'A public source publishes it')) $byHand = true;   // any other set-aside (not a place) stays
            if ($byHand) { if ($old['status'] !== 'dismissed') $linked++; continue; }
            [$ref, $status, $note] = self::match($pdo, $p, $name, $kind);
            $find = null;
            if ($ref === '' && $status === 'finding' && (string) $p['key'] === '') { $status = 'unconfirmed'; $note = 'Not found near here; no place to look around.'; }   // a piece with no place: nothing to search near
            if ($ref === '' && $status === 'finding') {
                $pdo->prepare('INSERT INTO guide_finds (place_key, name, kind, near) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE kind = VALUES(kind)')->execute([$p['key'], $name, $kind, $p['name'] . ($p['state'] ? ', ' . $p['state'] : '')]);
                $f = $pdo->prepare('SELECT id, status, suggestion_id FROM guide_finds WHERE place_key = ? AND name = ?'); $f->execute([$p['key'], $name]); $fr = $f->fetch(PDO::FETCH_ASSOC);
                $find = (int) $fr['id'];
                if ($fr['status'] === 'found') { $status = 'review'; $note = 'In Review: suggestion #' . (int) $fr['suggestion_id']; }
                elseif ($fr['status'] === 'notfound') { $status = 'unconfirmed'; $note = 'Find it couldn\'t confirm it.'; }
                else $queued++;
            }
            if (in_array($status, ['linked', 'thin'], true)) $linked++;
            $pdo->prepare("INSERT INTO content_tags (src, place_key, section, name, tag_kind, kind, ref, status, find_id, note, by_kind, by_id, updated_at) VALUES (?, ?, ?, ?, 'content', ?, ?, ?, ?, ?, ?, ?, NOW())
                           ON DUPLICATE KEY UPDATE place_key = VALUES(place_key), kind = VALUES(kind), ref = VALUES(ref), status = VALUES(status), find_id = VALUES(find_id), note = VALUES(note), updated_at = NOW()")
                ->execute([$src, (string) $p['key'], $sec, $name, $kind, $ref, $status, $find, $note, $byKind, $byId]);
        }
        foreach ($had as $k => $m) if (!isset($keep[$k]) && $m['status'] !== 'dismissed') $pdo->prepare('DELETE FROM content_tags WHERE id = ?')->execute([(int) $m['id']]);   // no longer in the text
        return ['names' => count($names), 'linked' => $linked, 'queued' => $queued];
    }

    public static function mentions(PDO $pdo, string $key): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT t.* FROM content_tags t WHERE t.src = ? ORDER BY t.section, t.id'); $st->execute([str_contains($key, ':') && preg_match('/^(guide|journey|story|experience|howto):/', $key) ? $key : 'guide:' . $key]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        // a linked listing that has since been marked closed flags the guide now, not at its next save
        $ids = [];
        foreach ($rows as $m) if (in_array($m['status'], ['linked', 'thin'], true) && preg_match('/^entity:(\d+)$/', (string) $m['ref'], $x)) $ids[] = (int) $x[1];
        if ($ids) {
            $shut = array_flip(array_map('intval', $pdo->query("SELECT entity_id FROM entity_metadata WHERE meta_key = 'closed' AND entity_id IN (" . implode(',', $ids) . ')')->fetchAll(PDO::FETCH_COLUMN)));
            foreach ($rows as &$m) if (in_array($m['status'], ['linked', 'thin'], true) && isset($shut[(int) substr((string) $m['ref'], 7)]) && str_starts_with((string) $m['ref'], 'entity:')) {
                $m['status'] = 'closed'; $m['note'] = self::CLOSED_NOTE;
                $pdo->prepare('UPDATE content_tags SET status = ?, note = ? WHERE id = ?')->execute(['closed', self::CLOSED_NOTE, (int) $m['id']]);
            }
            unset($m);
        }
        return $rows;
    }

    /** Names that keep a guide from going live. */
    public static function blocking(PDO $pdo, string $key): array
    {
        return array_values(array_map(fn ($m) => $m['name'], array_filter(self::mentions($pdo, $key), fn ($m) => in_array($m['status'], self::BLOCKING, true))));
    }

    /** A person links a name by hand (a listing, place, landmark or outdoor place), or sets it aside (not a place). */
    public static function setLink(PDO $pdo, int $id, string $ref, int $uid): void
    {
        $st = $pdo->prepare("SELECT t.* FROM content_tags t WHERE t.id = ? AND t.src LIKE 'guide:%'"); $st->execute([$id]);
        $m = $st->fetch(PDO::FETCH_ASSOC) ?: throw new RuntimeException('That name isn\'t in the guide any more.');
        if ($ref === 'dismiss') { $pdo->prepare("UPDATE content_tags SET status = 'dismissed', ref = '', note = 'Set aside by hand', by_kind = 'staff', by_id = ?, updated_at = NOW() WHERE id = ?")->execute([$uid ?: null, $id]); }
        else {
            $ref = trim($ref);
            if (preg_match('~/listing/view\.php\?id=(\d+)~', $ref, $x) || preg_match('/^#?(\d+)$/', $ref, $x)) $ref = 'entity:' . (int) $x[1];
            if (!preg_match('/^(entity:\d+|landmark:\d+|rec:[A-Za-z0-9_-]+|(hub|geo_hub|cluster|town|sub):\d+|route:.+|resource:\d+)$/', $ref)) throw new RuntimeException('Paste the listing\'s number or address (…/listing/view.php?id=…).');
            if ($m['status'] === 'held') throw new RuntimeException('This name may mark a sacred or protected site: take it out of the guide instead.');
            $pdo->prepare("UPDATE content_tags SET status = 'linked', ref = ?, note = 'Linked by hand', by_kind = 'staff', by_id = ?, updated_at = NOW() WHERE id = ?")->execute([$ref, $uid ?: null, $id]);
        }
        Guides::forget($pdo, (string) $m['place_key']);
    }

    /**
     * Written text (already escaped) with each linked name as its link: [[Name]] marks are dropped, and the first time a
     * linked name appears in the section it becomes a link.
     */
    public static function linkify(PDO $pdo, string $key, string $section, string $html): string   // $key: a guide's place key, or a piece's source (journey:12)
    {
        static $by = [];
        $html = (string) preg_replace('/\[\[([^\]|]+)(?:\|[a-z]+)?\]\]/u', '$1', $html);
        if (!isset($by[$key])) {
            $by[$key] = [];
            foreach (self::mentions($pdo, $key) as $m) if (in_array($m['status'], ['linked', 'thin'], true) && $m['ref'] !== '') $by[$key][$m['section']][$m['name']] = [self::url($pdo, (string) $m['ref']), (string) $m['ref']];
        }
        $links = $by[$key][$section] ?? [];
        uksort($links, fn ($a, $b) => mb_strlen($b) <=> mb_strlen($a));
        foreach ($links as $name => [$url, $ref]) {
            if ($url === '') continue;
            // as written, else with our abbreviations spelled out ("…Historical Scty" is written "…Historical Society")
            $long = implode(' ', array_map(fn ($w) => isset(self::ABBR[strtolower(trim($w, '.'))]) && self::ABBR[strtolower(trim($w, '.'))] !== '' ? ucfirst(self::ABBR[strtolower(trim($w, '.'))]) : $w, explode(' ', $name)));
            if ($long !== $name && mb_stripos($html, htmlspecialchars($name, ENT_QUOTES)) === false && mb_stripos($html, htmlspecialchars($long, ENT_QUOTES)) !== false) $name = $long;
            $n = preg_quote(htmlspecialchars($name, ENT_QUOTES), '/');
            $done = false;
            $html = (string) preg_replace_callback('/(<a\b[^>]*>.*?<\/a>|<[^>]+>)|(?<![\p{L}\p{N}])(' . $n . ')(?![\p{L}\p{N}])/su', function ($x) use (&$done, $url, $ref) {
                if (!empty($x[1]) || $done) return $x[0];
                $done = true;   // highlighted, with its preview card on hover or tap (js/tv-tagcard.js, decisions/0132 §2a)
                return '<a class="gl" href="' . htmlspecialchars($url, ENT_QUOTES) . '"' . (str_starts_with($url, '#') ? '' : ' data-tag="' . htmlspecialchars($ref, ENT_QUOTES) . '"') . '>' . $x[2] . '</a>';
            }, $html);
        }
        return $html;
    }

    // ---- Find it ------------------------------------------------------------------------------------------------------------

    /**
     * Works a few Find it jobs (app/scripts/guide_finds_tick.php): Claude with web search looks for the name near the
     * guide's place on official sources, says whether it's real, open and in the area, and what it found goes to Review
     * as a suggestion. Also re-matches names waiting on Review (an approved one becomes a link). Returns what it did.
     */
    public static function findTick(PDO $pdo, int $limit = 3): array
    {
        $done = ['found' => 0, 'notfound' => 0, 'relinked' => 0, 'waiting' => 0];
        if (!self::ready($pdo)) return $done;
        // names waiting: matched now (approved in Review, added by hand)?
        foreach ($pdo->query("SELECT t.* FROM content_tags t WHERE t.status IN ('finding','review','unconfirmed') AND t.place_key <> '' ORDER BY t.updated_at LIMIT 200")->fetchAll(PDO::FETCH_ASSOC) as $m) {
            $p = Guides::place($pdo, (string) $m['place_key']); if (!$p) continue;
            [$ref, $status, $note] = self::match($pdo, $p, (string) $m['name'], (string) $m['kind']);
            if ($ref !== '') { $pdo->prepare('UPDATE content_tags SET ref = ?, status = ?, note = ?, updated_at = NOW() WHERE id = ?')->execute([$ref, $status, $note, (int) $m['id']]); if (str_starts_with((string) $m['src'], 'guide:')) Guides::forget($pdo, (string) $m['place_key']); $done['relinked']++; }
        }
        // our crawler first (OpenStreetMap, then the place's own website: free); Claude only for what it couldn't find, while it's on
        $ai = self::aiOn($pdo, 'guide_find'); $aiLeft = 0;
        if ($ai) { $fc = AiClient::feature($pdo, 'guide_find'); $aiLeft = $fc['per_day'] > 0 ? max(0, $fc['per_day'] - AiClient::used($pdo, 'guide_find')['today']) : $limit; }   // never past the day's runs
        $jobs = $pdo->query("SELECT * FROM guide_finds WHERE (status = 'queued' OR (status = 'working' AND leased_until < NOW()) OR (status = 'failed' AND attempts < 3 AND done_at < NOW() - INTERVAL 6 HOUR))
                             ORDER BY COALESCE(result, '') LIKE '%\"crawler\"%', id LIMIT " . max(1, min(10, $limit)))->fetchAll(PDO::FETCH_ASSOC);
        foreach ($jobs as $j) {
            $p = Guides::place($pdo, (string) $j['place_key']);
            require_once __DIR__ . '/ListingSafety.php';
            if (ListingSafety::isConfidential(null, (string) $j['name'])) {   // a confidential service: never looked up outside (decisions/0133); a person links it
                $pdo->prepare("UPDATE guide_finds SET status = 'notfound', result = ?, done_at = NOW() WHERE id = ?")->execute([json_encode(['note' => 'confidential: not looked up outside']), (int) $j['id']]);
                $pdo->prepare("UPDATE content_tags SET status = 'unconfirmed', note = ?, updated_at = NOW() WHERE find_id = ? AND status = 'finding'")->execute(['A confidential service: not looked up outside. Link it by hand if it should be named.', (int) $j['id']]);
                continue;
            }
            $tried = (json_decode((string) ($j['result'] ?? ''), true) ?: [])['crawler'] ?? '';
            if ($tried === '' && $p && $p['lat'] !== null) {
                $hit = self::crawlFind($pdo, $p, (string) $j['name']);
                if ($hit === null) continue;   // the map service's hourly share is used up: next time
                if ($hit) { self::found($pdo, $j, $p, $hit, 'our crawler'); $done['found']++; continue; }
                $pdo->prepare("UPDATE guide_finds SET result = ? WHERE id = ?")->execute([json_encode(['crawler' => 'none']), (int) $j['id']]);
            }
            if (!$ai || $aiLeft <= 0) { $done['waiting']++; continue; }
            $aiLeft--;
            $pdo->prepare("UPDATE guide_finds SET status = 'working', attempts = attempts + 1, leased_until = NOW() + INTERVAL 10 MINUTE WHERE id = ?")->execute([(int) $j['id']]);
            try {
                $r = AiClient::claudeAsk('A travel guide for ' . $j['near'] . ' names "' . $j['name'] . '" (' . (self::KINDS[$j['kind']] ?? 'a place') . "). Find it on the web.\n"
                    . "Confirm from its own website or official sources (a government, park, tribal or chamber site; a map listing as a last resort) that it is real, currently open or operating, and in or near " . $j['near'] . '. '
                    . "Give its exact name, what it is, street address, town, state, ZIP, phone, website, hours if published, its map point (latitude and longitude, from an official map or its own site; for a river, lake, trail or mountain, its main access or center), and the pages you used. If you can't confirm it, say found=false and why in note. "
                    . "Never guess a phone number or address: leave it empty if no source shows it. If it's a sacred, burial or ceremonial site, say found=false.",
                    ['type' => 'object', 'additionalProperties' => false, 'required' => ['found', 'open', 'confidence', 'name', 'what', 'address', 'town', 'state', 'zip', 'phone', 'website', 'hours', 'lat', 'lon', 'sources', 'note'],
                     'properties' => ['found' => ['type' => 'boolean'], 'open' => ['type' => 'boolean'], 'confidence' => ['type' => 'string', 'enum' => ['low', 'medium', 'high']], 'name' => ['type' => 'string'], 'what' => ['type' => 'string'],
                                      'address' => ['type' => 'string'], 'town' => ['type' => 'string'], 'state' => ['type' => 'string'], 'zip' => ['type' => 'string'], 'phone' => ['type' => 'string'], 'website' => ['type' => 'string'],
                                      'hours' => ['type' => 'string'], 'lat' => ['type' => 'number'], 'lon' => ['type' => 'number'], 'sources' => ['type' => 'array', 'items' => ['type' => 'string']], 'note' => ['type' => 'string']]],
                    AiClient::feature($pdo, 'guide_find')['model'], AiClient::feature($pdo, 'guide_find')['searches'], 2500);
                AiClient::record($pdo, 'guide_find', (int) $j['id'], 'done', $r);
                $d = $r['data'];
                if (!empty($d['found']) && !empty($d['open']) && ($d['confidence'] ?? 'low') !== 'low') {
                    $d['score'] = self::claudeScore($d);
                    self::found($pdo, $j, $p, $d, 'Claude');
                    $done['found']++;
                } else {
                    $why = trim((string) ($d['note'] ?? '')) ?: (!empty($d['found']) && empty($d['open']) ? 'It looks closed.' : 'Not found on official sources.');
                    $pdo->prepare("UPDATE guide_finds SET status = 'notfound', result = ?, done_at = NOW() WHERE id = ?")->execute([json_encode($d, JSON_UNESCAPED_UNICODE), (int) $j['id']]);
                    $pdo->prepare("UPDATE content_tags SET status = 'unconfirmed', note = ?, updated_at = NOW() WHERE find_id = ? AND status = 'finding'")->execute([mb_substr('Couldn\'t confirm: ' . $why, 0, 300), (int) $j['id']]);
                    $done['notfound']++;
                }
            } catch (Throwable $x) {
                $again = $x->getCode() === 1;
                $pdo->prepare('UPDATE guide_finds SET status = ?, result = ?, done_at = NOW() WHERE id = ?')->execute([$again ? 'queued' : 'failed', json_encode(['error' => $x->getMessage()]), (int) $j['id']]);
                if (!$again) error_log('guide find ' . $j['id'] . ': ' . $x->getMessage());
                if ($again) break;
            }
        }
        return $done;
    }

    /** @var callable|null for tests: fn(string $url): array (pages, as SiteFetcher gives them) */
    public static $sitePages = null;

    /**
     * Our crawler looks for a name a guide uses: OpenStreetMap near the place (that it's there, its map link and its
     * website as a pointer only, ODbL), then that website, read like any business's (its name, address, phone, hours).
     * The find in Find it's shape, [] when it isn't there, null when the map service can't be asked now.
     */
    public static function crawlFind(PDO $pdo, array $p, string $name): ?array
    {
        require_once __DIR__ . '/crawler/DeepLook.php'; require_once __DIR__ . '/Landmarks.php';
        Landmarks::loadPeoples($pdo); if (Landmarks::isProtected($name)) return [];   // never looked for: it may mark a protected site (a town's public cemetery may be)
        require_once __DIR__ . '/ListingSafety.php';
        if (ListingSafety::isConfidential(null, $name)) return [];   // a confidential service is never sent to a map or search service
        $hits = DeepLook::findByName($pdo, $name, (float) $p['lat'], (float) $p['lon']);
        if ($hits === null) return null;
        if (!$hits) return [];
        [, $osmUrl, $site] = $hits[0];
        $d = ['found' => true, 'open' => true, 'confidence' => 'medium', 'name' => $name, 'what' => '', 'address' => '', 'town' => '', 'state' => '', 'zip' => '', 'phone' => '', 'website' => $site, 'hours' => '', 'lat' => 0, 'lon' => 0,
              'sources' => [$osmUrl], 'note' => 'On OpenStreetMap near ' . $p['name'] . '.', 'score' => 40];   // on the map: 40
        if ($site === '') return $d;
        try {
            $url = SiteFetcher::normalizeStartUrl(preg_match('#^https?://#i', $site) ? $site : 'https://' . $site);
            $pages = self::$sitePages ? (self::$sitePages)($url) : ((new SiteFetcher(['max_pages' => 4]))->fetch($url)['pages'] ?? []);
            $best = null;
            foreach ($pages ? ListingExtractor::extract($pages, $url) : [] as $c) { $sim = AutoImport::sameName($name, (string) ($c['name'] ?? '')); if (!$best || $sim > $best[0]) $best = [$sim, $c]; }
            if ($best) {   // the website the map gives is the place's own
                $c = $best[1]; $w = (array) ($c['where'] ?? []);
                $d = ['name' => $best[0] >= 0.5 ? (string) $c['name'] : $name, 'what' => mb_substr((string) ($c['what']['description'] ?? ''), 0, 300), 'address' => (string) ($w['address'] ?? ''), 'town' => (string) ($w['city'] ?? ''), 'state' => (string) ($w['state'] ?? ''), 'zip' => (string) ($w['zip'] ?? ''),
                      'phone' => (string) ($c['actions']['phone'] ?? ''), 'hours' => implode('; ', (array) ($c['when']['hours'] ?? [])), 'lat' => (float) ($w['point']['lat'] ?? 0), 'lon' => (float) ($w['point']['lon'] ?? 0),
                      'sources' => [$url, $osmUrl], 'confidence' => ($w['address'] ?? '') !== '' || ($c['actions']['phone'] ?? '') !== '' ? 'high' : 'medium', 'note' => 'On OpenStreetMap near ' . $p['name'] . ', and its own website.',
                      // on the map 40, its own website read 20, an address there 15, a phone 15, its name on the site 10
                      'score' => 60 + (($w['address'] ?? '') !== '' ? 15 : 0) + (($c['actions']['phone'] ?? '') !== '' ? 15 : 0) + ($best[0] >= 0.8 ? 10 : 0)] + $d;
            }
        } catch (Throwable $x) { error_log('guide find site ' . $site . ': ' . $x->getMessage()); }
        return $d;
    }

    /**
     * A find goes to Review as a missing listing, and the name waits there (In Review). With a score at or over the
     * switch's (System Configuration → AI use → Finds become listings by themselves), a business, museum or
     * organization with a phone and an address or map point is approved by that rule instead: one we already list
     * (same phone or website) is linked; else it's added as a listing and linked.
     */
    /**
     * What Claude found, scored (Jason, 2026-11-01: "Based on the listing names it is obviously what these are"): Claude's
     * own word starts it (high 75, medium 65), and 5 each for a phone, an address, a website and two or more sources. So
     * a medium find with a phone, an address and two sources reaches 80 without a website of its own (a rural place, or a
     * chain seen on its brand's locator); a medium one with less waits. The listing still has to pass the readiness rules,
     * and it starts orange (machine-confirmed): the Call list confirms it.
     */
    public static function claudeScore(array $d): int
    {
        return (($d['confidence'] ?? '') === 'high' ? 75 : 65) + (trim((string) ($d['website'] ?? '')) !== '' ? 5 : 0) + (trim((string) ($d['address'] ?? '')) !== '' ? 5 : 0)
             + (trim((string) ($d['phone'] ?? '')) !== '' ? 5 : 0) + (count((array) ($d['sources'] ?? [])) >= 2 ? 5 : 0);
    }

    /**
     * The rule's part: a find at or over the switch's score with a phone and an address or map point is linked to the
     * listing we have (same phone or website) or added through the crawler's pipeline. True when it was handled. $from:
     * the states its names are in (a new find: finding/unconfirmed; one waiting in Review: review).
     */
    private static function autoAdd(PDO $pdo, array $j, array $d, string $by, array $from): bool
    {
        require_once __DIR__ . '/Suggestions.php'; require_once __DIR__ . '/AiClient.php';
        $rule = AiClient::feature($pdo, 'guide_find_add');
        $score = (int) ($d['score'] ?? 0);
        $ok = $rule['enabled'] && $score >= $rule['per_day'] && in_array($j['kind'], ['business', 'museum', 'organization'], true)
            && Suggestions::phone10((string) $d['phone']) !== '' && (trim((string) $d['address']) !== '' || (!empty($d['lat']) && !empty($d['lon'])));
        if (!$ok) return false;
        $in = implode(',', array_map(fn ($x) => $pdo->quote($x), $from));
        $have = self::listedAs($pdo, (string) $d['phone'], (string) $d['website'], (string) $d['name']);
        if ($have < 0) return false;   // its phone or website is another listing's (a county office's line, a shared site): a person looks
        if ($have > 0) {   // we have it under a name written another way
            $pdo->prepare("UPDATE guide_finds SET status = 'found', result = ?, done_at = NOW() WHERE id = ?")->execute([json_encode($d + ['by' => $by, 'linked' => $have], JSON_UNESCAPED_UNICODE), (int) $j['id']]);
            $pdo->prepare("UPDATE content_tags SET status = 'linked', ref = ?, note = ?, updated_at = NOW() WHERE find_id = ? AND status IN ($in)")->execute(['entity:' . $have, 'Found by ' . $by . ' (score ' . $score . '): the same phone or website as a listing we have', (int) $j['id']]);
            Guides::forget($pdo, (string) $j['place_key']);
            return true;
        }
        $st = self::stageFind($pdo, $j, $d, $by);   // approved by the rule: into the crawler's one pipeline (decisions/0133)
        if ($st === null) return false;
        [$eid, $row, $why] = $st;
        $pdo->prepare("UPDATE guide_finds SET status = 'found', result = ?, done_at = NOW() WHERE id = ?")->execute([json_encode($d + ['by' => $by, 'entity' => $eid, 'row' => $row], JSON_UNESCAPED_UNICODE), (int) $j['id']]);
        if ($eid) $pdo->prepare("UPDATE content_tags SET status = 'linked', ref = ?, note = ?, updated_at = NOW() WHERE find_id = ? AND status IN ($in)")->execute(['entity:' . $eid, 'Added by Find it (' . $by . ', score ' . $score . '), ready by the listing rules', (int) $j['id']]);
        else $pdo->prepare("UPDATE content_tags SET status = 'review', note = ?, updated_at = NOW() WHERE find_id = ? AND status IN ($in)")->execute([mb_substr('Waiting with the crawler\'s listings (row #' . $row . '): ' . $why, 0, 300), (int) $j['id']]);
        Guides::forget($pdo, (string) $j['place_key']);
        return true;
    }

    /**
     * Finds already waiting in Review as a suggestion, looked at again by today's rule (Claude's score as claudeScore()
     * gives it now): the ones that pass are handled as a new find would be and their suggestion closed as used. Run by
     * the Find it job. Returns how many it handled.
     */
    public static function recheckWaiting(PDO $pdo, int $limit = 20): int
    {
        $n = 0;
        try {
            $st = $pdo->prepare("SELECT g.* FROM guide_finds g JOIN suggestions s ON s.id = g.suggestion_id WHERE g.status = 'found' AND s.status = 'new' AND g.result IS NOT NULL ORDER BY g.id LIMIT " . max(1, min(200, $limit)));
            $st->execute();
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $j) {
                $d = json_decode((string) $j['result'], true);
                if (!is_array($d) || empty($d['found'])) continue;
                $by = (string) ($d['by'] ?? 'Claude');
                if ($by === 'Claude') $d['score'] = self::claudeScore($d);
                unset($d['by']);
                if (!self::autoAdd($pdo, $j, $d, $by, ['review'])) continue;
                $eid = (int) (json_decode((string) $pdo->query('SELECT result FROM guide_finds WHERE id = ' . (int) $j['id'])->fetchColumn(), true)['entity'] ?? 0);
                $pdo->prepare("UPDATE suggestions SET status = 'used', listing_id = COALESCE(listing_id, ?), handled_at = NOW() WHERE id = ? AND status = 'new'")->execute([$eid ?: null, (int) $j['suggestion_id']]);
                $n++;
            }
        } catch (Throwable $x) { error_log('guide finds recheck: ' . $x->getMessage()); }
        return $n;
    }

    private static function found(PDO $pdo, array $j, ?array $p, array $d, string $by): void
    {
        require_once __DIR__ . '/Suggestions.php'; require_once __DIR__ . '/AiClient.php';
        $score = (int) ($d['score'] ?? 0);
        if (self::autoAdd($pdo, $j, $d, $by, ['finding', 'unconfirmed'])) return;
        $topic = in_array($j['kind'], ['outdoors', 'landmark'], true) ? 'outdoors' : (in_array($j['kind'], ['museum'], true) ? 'culture' : ($j['kind'] === 'event' ? 'event' : 'business'));
        $sid = Suggestions::create($pdo, ['kind' => 'missing', 'topic' => $topic, 'place_key' => $p ? (in_array($p['level'], ['hub', 'geo_hub', 'cluster'], true) ? $p['key'] : 'cluster:' . $p['cluster']) : '',
            'section' => 'Guide: ' . ($p['name'] ?? ''), 'target_name' => (string) $d['name'],
            'fields' => ['name' => (string) $d['name'], 'what' => (string) $d['what'], 'website' => (string) $d['website'], 'phone' => (string) $d['phone'],
                         'address' => trim(implode(', ', array_filter([(string) $d['address'], (string) $d['town'], trim($d['state'] . ' ' . $d['zip'])]))), 'hours' => (string) $d['hours'], 'source' => implode(' ', array_slice((array) $d['sources'], 0, 3)),
                         'point' => !empty($d['lat']) && !empty($d['lon']) ? $d['lat'] . ',' . $d['lon'] : ''],
            'note' => 'Found by ' . $by . ' for the ' . ($p['kind'] ?? 'guide') . ' of ' . ($p['name'] ?? '') . ' ("' . $j['name'] . '"), confidence ' . $d['confidence'] . '. ' . (string) $d['note'] . "\nSources: " . implode("\n", (array) $d['sources']),
            'context' => 'guide:' . $j['place_key']], null, 'guide-find-' . (int) $j['id']);
        $pdo->prepare("UPDATE guide_finds SET status = 'found', suggestion_id = ?, result = ?, done_at = NOW() WHERE id = ?")->execute([$sid, json_encode($d + ['by' => $by], JSON_UNESCAPED_UNICODE), (int) $j['id']]);
        $pdo->prepare("UPDATE content_tags SET status = 'review', note = ?, updated_at = NOW() WHERE find_id = ? AND status IN ('finding','unconfirmed')")->execute(['In Review: suggestion #' . $sid . ' (score ' . $score . ')', (int) $j['id']]);
    }

    /**
     * A find approved by the rule goes where every crawled listing goes (decisions/0133: one way in): staged, matched,
     * and published only if it passes the listing rules (real, complete, fits a category, unique: decisions/0076); else
     * it waits in Review with the reason. [listing id or 0, staged row id, why it waits]; null when it can't be staged
     * (no ZIP), and it goes to Review as a suggestion instead.
     */
    private static function stageFind(PDO $pdo, array $j, array $d, string $by): ?array
    {
        require_once __DIR__ . '/crawler/CrawlQueue.php'; require_once __DIR__ . '/crawler/IntakeStager.php'; require_once __DIR__ . '/crawler/AutoImport.php';
        $src = array_values(array_filter(array_map('strval', (array) ($d['sources'] ?? [])), fn ($u) => (bool) preg_match('#^https?://#i', $u)));
        $start = $by === 'our crawler' && (string) $d['website'] !== '' ? (string) $d['website'] : ($src[0] ?? '');   // our crawler read its own site; Claude's first page otherwise
        $c = CrawlQueue::normalize(['name' => $d['name'], 'what' => ['description' => $d['what']], 'when' => ['hours' => array_filter([(string) $d['hours']])],
            'where' => ['address' => $d['address'], 'city' => $d['town'], 'state' => $d['state'], 'zip' => $d['zip']],
            'actions' => ['phone' => $d['phone'], 'website' => $d['website']], 'source' => ['start_url' => $start, 'site' => (string) parse_url($start, PHP_URL_HOST), 'crawled_at' => date('c')],
            'sources' => ['name' => $src, 'address' => $src, 'phone' => $src], 'corroboration' => $src]);
        if (!$c) return null;
        if (!empty($d['lat']) && !empty($d['lon'])) $c['geo'] = ['latitude' => (float) $d['lat'], 'longitude' => (float) $d['lon']];
        $sid = IntakeStager::createSource($pdo, $start !== '' ? $start : 'https://traversence.com/guide-find/' . (int) $j['id'], ['create_listings'], 'Find it #' . (int) $j['id'] . ' for the guide of ' . $j['near'] . ' (' . $by . ')', 0);
        $r = IntakeStager::stage($pdo, $sid, [$c]);
        if ($r['auto_imported']) return [(int) $r['auto_imported'][0], 0, ''];
        $row = (int) ($r['staged'][0] ?? 0);
        if (!$row) return null;   // already known to the crawler: a person sees it as a suggestion
        $st = $pdo->prepare('SELECT raw_payload FROM ' . Database::t('crawler_raw_index') . ' WHERE id = ?'); $st->execute([$row]);
        $e = AutoImport::evaluate(json_decode((string) $st->fetchColumn(), true) ?: []);
        $why = implode('; ', array_column(array_filter($e['checks'], fn ($x) => empty($x['pass'])), 'label')) ?: 'not ready yet';
        return [0, $row, $why];
    }

    /**
     * A listing we have with this phone or website and a name like it: its id. -1 when the phone or website is another
     * listing's under another name (a county fairground on the courthouse's line), 0 when nothing shares them.
     */
    private static function listedAs(PDO $pdo, string $phone, string $site, string $name): int
    {
        require_once __DIR__ . '/crawler/AutoImport.php';
        $other = 0;
        $pick = function (PDOStatement $st) use ($name, &$other): int {
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { if (AutoImport::sameName($name, (string) $r['name']) >= 0.6) return (int) $r['entity_id']; $other = -1; }
            return 0;
        };
        $ph = substr(preg_replace('/\D/', '', $phone), -10);
        if (strlen($ph) === 10) {
            $st = $pdo->prepare("SELECT m.entity_id, e.name FROM entity_metadata m JOIN entities e ON e.id = m.entity_id AND e.is_suppressed = 0 WHERE m.meta_key = 'phone' AND m.meta_value LIKE ? LIMIT 20");
            $st->execute(['%' . substr($ph, 0, 3) . '%' . substr($ph, 3, 3) . '%' . substr($ph, 6) . '%']);
            if ($id = $pick($st)) return $id;
        }
        $host = preg_replace('/^www\./', '', strtolower((string) parse_url(preg_match('#^https?://#i', $site) ? $site : 'https://' . $site, PHP_URL_HOST)));
        if ($host !== '' && str_contains($host, '.')) {
            $st = $pdo->prepare("SELECT m.entity_id, e.name FROM entity_metadata m JOIN entities e ON e.id = m.entity_id AND e.is_suppressed = 0 WHERE m.meta_key = 'website' AND (m.meta_value LIKE ? OR m.meta_value LIKE ?) LIMIT 20");
            $st->execute(['%//' . $host . '%', '%//www.' . $host . '%']);
            if ($id = $pick($st)) return $id;
        }
        return $other;
    }
}
