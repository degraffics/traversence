<?php

declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/crawler/NpiBulk.php';

/**
 * api/lib/Landmarks.php — natural landmarks (decisions/0058 §24): badlands, arches, canyons, buttes, waterfalls, hot
 * springs, craters, peaks. Once a month the worker reads USGS Geographic Names (GNIS) for the pilot states, keeps the
 * notable natural features (a Wikipedia article or a freely licensed photo, or a landscape word in the name),
 * marks any inside a tribal nation's boundaries (Census AIANNH), adds Wikidata's description, the Wikipedia summary
 * and a freely licensed Wikimedia Commons photo, and sends them here.
 *
 * Who decides what shows (the site decides, not the worker), by the public/private standard (decisions/0066):
 *  - Public information is shown, on a sovereign nation's land too: established, publicly known features, with the
 *    nation's own name and its rules for visitors on the page.
 *  - Sensitive is held: a name that may mark a sacred, burial or protected site (shrine, burial, ruin, petroglyph,
 *    kiva …), anywhere; and on a nation's land, what is specific to the nation (its springs). Held places are kept,
 *    never shown, until the nation has its own controls (the nation tools) and says.
 *  - A nation's "closed" is final unless the nation reopens it. A person's "approved" or "hidden" is kept across
 *    monthly reloads.
 */
final class Landmarks
{
    /**
     * Whether Wikipedia's words may be kept and shown (its rule in the source register: decisions/0133; set to Cite only
     * on 2026-11-01). Otherwise a landmark shows Wikidata's description (CC0) and links to the article.
     */
    public static function wikiAllowed(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { require_once __DIR__ . '/crawler/Sources.php'; $ok = Sources::mayStore($pdo, 'wikipedia.org'); } catch (Throwable $e) { $ok = false; } }
        return $ok;
    }

    /** What a landmark says about itself: Wikipedia's extract where its rule allows, else Wikidata's description. */
    public static function about(PDO $pdo, array $r): string
    {
        $x = trim((string) ($r['extract'] ?? ''));
        if ($x !== '' && self::wikiAllowed($pdo)) return $x;
        // no article: what Claude wrote for it the first time someone opened it, kept as research (Jason, 2026-11-10: "only
        // ai when no data exist and it must be stored as research for future reuse"; PlaceFinder::aboutTick)
        $rs = trim((string) ($r['research'] ?? ''));
        if ($rs !== '') return $rs;
        // no article (2026-11-10: "Why do I want to visit this place… what is the experience?"): Wikidata's description,
        // then what it records (CC0): its listing (the National Register, a National Historic Landmark), when it dates from,
        // its style and who designed it
        $d = trim((string) preg_replace('/,\s*United States( of America)?$/i', '', trim((string) ($r['wd_desc'] ?? ''))));
        $out = $d !== '' ? ucfirst($d) . '.' : '';
        $f = json_decode((string) ($r['wd_facts'] ?? ''), true);
        if (is_array($f)) {
            foreach ((array) ($f['heritage'] ?? []) as $h) {
                $h = (string) $h;
                if (stripos($h, 'National Historic Landmark') !== false) { $out .= ' A National Historic Landmark.'; break; }
                if (stripos($h, 'National Register') !== false) { $out .= ' Listed on the National Register of Historic Places.'; break; }
            }
            if (!empty($f['style'])) $out .= ' ' . ucfirst(implode(' and ', array_slice(array_map('strval', (array) $f['style']), 0, 2))) . ' architecture' . (!empty($f['year']) ? ', from ' . $f['year'] : '') . '.';
            elseif (!empty($f['year'])) $out .= ' Dates from ' . $f['year'] . '.';
            if (!empty($f['architect'])) $out .= ' Designed by ' . implode(' and ', array_slice(array_map('strval', (array) $f['architect']), 0, 2)) . '.';
        }
        return trim($out);
    }

    /**
     * The nation tools switch (decisions/0058 §27). Off until nations have their own accounts and controls: what is held
     * as sensitive (a sacred, burial or protected site; a nation's springs) is kept, unused, never shown, and there's no
     * queue to approve it. Public places on a nation's land show like anywhere else (decisions/0066). Closed ones never show.
     */
    public const NATION_TOOLS = false;
    private const EVERY_DAYS = 30;
    private const RETRY_HOURS = 6;
    public const NEAR_MILES = 40;
    /** Words that may mark a sacred, burial or archaeological site: never listed without a person (decisions/0043, 0044). */
    public const SENSITIVE = '/\b(sacred|shrines?|burials?|graves?|graveyard|cemetery|ossuary|kivas?|ruins?|pueblito|petroglyphs?|pictographs?|rock art|cliff dwellings?|archaeolog\w*|ceremonial|medicine wheel)\b/i';
    /**
     * The three levels for a protected place (Jason, 2026-10-30, curators not controllers; decisions/0133): a town's
     * public cemetery is a public place like any other (named, told, directions given); a cemetery on a nation's land or
     * of its peoples, and every other protected kind (PROTECTED), is told only as public sources present it and never the
     * way in, or, when no public source names it, only acknowledged in general (that sacred places are there, and whose
     * permission they need).
     */
    public const CIVIC = '/\b(cemetery|cemeteries|graveyard)\b/i';
    public const PROTECTED = '/\b(sacred|shrines?|burials?|burial grounds?|graves?|ossuary|kivas?|ruins?|pueblito|petroglyphs?|pictographs?|rock art|cliff dwellings?|archaeolog\w*|ceremonial|medicine wheel)\b/i';
    /** A cemetery of a nation's peoples is protected, not civic. */
    public const NATIVE = '/\b(indian|native american|tribal|ancestral|ancestors|reservation)\b/i';

    /** Is this (a name, a sentence) about a protected place? A civic cemetery isn't; one on a nation's land or of its peoples is. */
    public static function isProtected(string $text, string $nation = ''): bool
    {
        // the nations' peoples, always (review A2, 2026-11-13): a caller that forgot loadPeoples() read a "Hopi cemetery" as a town's
        if (self::$peoples === '') { try { self::loadPeoples(Database::connection()); } catch (Throwable $e) { error_log('isProtected peoples: ' . $e->getMessage()); } }
        if (preg_match(self::PROTECTED_KINDS, $text)) return true;   // ruins, kivas, rock art …: whatever words are around them
        $civic = (bool) preg_match(self::CIVIC, $text);
        $native = $nation !== '' || preg_match(self::NATIVE, $text) || (self::$peoples !== '' && preg_match(self::$peoples, $text));
        if ($civic) return $native;   // a town's cemetery, its graves and burials included, is public; one of a nation's peoples isn't
        return (bool) preg_match(self::PROTECTED, $text);
    }

    /** The protected kinds that stay protected even beside a town's cemetery. */
    public const PROTECTED_KINDS = '/\b(sacred|shrines?|ossuary|kivas?|ruins?|pueblito|petroglyphs?|pictographs?|rock art|cliff dwellings?|archaeolog\w*|ceremonial|medicine wheel|burial grounds?)\b/i';

    /** The peoples of the nations we hold (Apache, Zuni, Hopi …), as a pattern: a cemetery of theirs is protected. Set by loadPeoples(). */
    public static string $peoples = '';

    /** Reads the peoples' names from the nations register once (for isProtected). */
    public static function loadPeoples(PDO $pdo): void
    {
        if (self::$peoples !== '') return;
        $words = [];
        try {
            foreach ($pdo->query('SELECT name FROM nations')->fetchAll(PDO::FETCH_COLUMN) as $n) {
                $n = trim((string) preg_replace('/\b(nation|tribes?|indian community|community|reservation|band|indians|of the|confederated)\b/i', ' ', (string) $n));
                if (preg_match('/^pueblo of\s+(.+)$/i', $n, $m)) $n = $m[1];
                $parts = preg_split('/\s+/', trim($n)); $w = (string) end($parts);
                if (mb_strlen($w) >= 3) $words[] = preg_quote($w, '/');
            }
        } catch (Throwable $e) {}
        self::$peoples = $words ? '/\b(' . implode('|', array_unique($words)) . ')\b/iu' : '/(?!)/';
    }

    /** Landscape words that make a feature worth listing on its own, whatever its kind. */
    public const NOTABLE = '/\b(badlands?|natural bridge|falls|waterfall|hot springs?|sand dunes|dunes|craters?|volcano|hoodoos?|gorge|box canyon|slot canyon|lava|malpais|caldera|petrified|painted desert|caves?|caverns?|sinkhole|blue hole|gardens? of the gods|valley of fires)\b/i';
    /** Shape words that count only for rock formations, arches, cliffs and named areas ("Window Rock", not "Rock Spring"). */
    public const NOTABLE_SHAPE = '/\b(arch|arches|rocks?|spires?|pinnacles?|towers?|needles?|monument|chimney|castle|cathedral|wilderness)\b/i';
    /** On a nation's land, kinds of feature specific to the nation (decisions/0066): held, like a sensitive name. */
    public const NATION_SENSITIVE_CLASSES = ['Spring'];
    public const LICENSES = '/^(cc0|cc[ -]by(-sa)?([ -][0-9.]+)?|public domain|pd\b|pd-)/i';

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM landmarks LIMIT 1'); $pdo->query('SELECT 1 FROM ' . Database::t('landmark_loads') . ' LIMIT 1'); return true; } catch (PDOException) { return false; }
    }

    public static function status(PDO $pdo): array
    {
        $last = $pdo->query('SELECT finished_at FROM ' . Database::t('landmark_loads') . ' WHERE finished_at IS NOT NULL ORDER BY finished_at DESC LIMIT 1')->fetchColumn() ?: null;
        $running = $pdo->query('SELECT started_at FROM ' . Database::t('landmark_loads') . ' WHERE finished_at IS NULL ORDER BY id DESC LIMIT 1')->fetchColumn();
        $due = (!$last || strtotime((string) $last) < time() - self::EVERY_DAYS * 86400)
            && (!$running || strtotime((string) $running) < time() - self::RETRY_HOURS * 3600);
        return ['due' => $due, 'states' => NpiBulk::STATES, 'last_finished' => $last, 'records' => (int) $pdo->query('SELECT COUNT(*) FROM landmarks')->fetchColumn()];
    }

    public static function start(PDO $pdo, string $file): int
    {
        $pdo->prepare('INSERT INTO ' . Database::t('landmark_loads') . ' (file, started_at) VALUES (?, ?)')->execute([mb_substr($file, 0, 40), date('Y-m-d H:i:s')]);
        return (int) $pdo->lastInsertId();
    }

    private static function clean(string $s, int $max): string
    {
        $s = html_entity_decode(strip_tags($s), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return mb_substr(trim(preg_replace('/\s+/u', ' ', $s)), 0, $max);
    }

    /**
     * A place plainly known to the public, though a word in its name or description ("archaeological", "ruins") would hold it
     * (Jason, 2026-11-12, Besh-Ba-Gowah: a city-run archaeological park and museum, held on one word; decisions/0066 says
     * publicly known places are public): its own Wikipedia article, or described as open to visitors (a museum, a park, a
     * monument, a historic site, a visitor center). Never on a nation's land (held until the nation says), and never a name
     * or description that speaks of the sacred or of burials (SACRED): those stay held whatever else is known.
     */
    public const SACRED = '/\b(sacred|shrines?|burials?|burial grounds?|graves?|graveyards?|ossuary|ceremonial|medicine wheel)\b/i';
    public const OPEN_TO_VISITORS = '/\b(museums?|state parks?|national (parks?|monuments?|historic(al)? (sites?|parks?))|historic(al)? (sites?|parks?|districts?)|archaeological parks?|heritage parks?|cultural parks?|visitor cent(er|re)s?|open to the public|tourist attractions?)\b/i';
    public static function publiclyKnown(array $r): bool
    {
        if (trim((string) ($r['nation'] ?? '')) !== '') return false;
        $text = ($r['name'] ?? '') . ' ' . ($r['wd_desc'] ?? '');
        if (preg_match(self::SACRED, $text)) return false;
        return trim((string) ($r['wiki_title'] ?? '')) !== '' || (bool) preg_match(self::OPEN_TO_VISITORS, $text . ' ' . ($r['extract'] ?? ''));
    }
    public const KNOWN_WHY = 'Shown: a publicly known place (its own article, or open to visitors), though a word in its name or description would hold it (decisions/0066, 2026-11-12).';

    /** What the site does with a feature before any person looks: [status, why]. */
    public static function decide(array $r): array
    {
        // the public/private standard (decisions/0066): sensitive is held, public shows, a nation's land included
        if (self::isProtected(($r['name'] ?? '') . ' ' . ($r['wd_desc'] ?? ''), (string) ($r['nation'] ?? ''))) {
            if (self::publiclyKnown($r)) return ['shown', self::KNOWN_WHY];
            return ['waiting', 'Sensitive: the name may mark a sacred, burial or protected site. Held until the nation (or the owner) says.'];
        }
        if (($r['nation'] ?? '') !== '' && in_array((string) ($r['fclass'] ?? ''), self::NATION_SENSITIVE_CLASSES, true)) return ['waiting', 'Sensitive: specific to ' . $r['nation'] . '. Held until the nation says.'];
        return ['shown', ''];
    }

    /** Worth listing: a Wikipedia article, a photo, or a landscape word in the name. */
    public static function notable(array $r): bool
    {
        // a Wikipedia article or a photo; Wikidata's description alone doesn't count (it has one for nearly every feature)
        if (($r['wiki_title'] ?? '') !== '' || ($r['image_url'] ?? '') !== '') return true;
        $n = (string) ($r['name'] ?? ''); $c = (string) ($r['fclass'] ?? '');
        return in_array($c, ['Arch', 'Falls', 'Crater', 'Pillar'], true) || (bool) preg_match(self::NOTABLE, $n)
            || (in_array($c, ['Area', 'Cliff', 'Summit'], true) && (bool) preg_match(self::NOTABLE_SHAPE, $n));
    }

    /** The nearest town (a ZIP's city) within NEAR_MILES: [zip, city, miles] or null. */
    public static function nearestZip(PDO $pdo, float $lat, float $lon): ?array
    {
        $pad = self::NEAR_MILES / 60;
        $st = $pdo->prepare('SELECT zip, city, latitude, longitude FROM zip_coordinates WHERE latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ? LIMIT 400');
        $st->execute([$lat - $pad, $lat + $pad, $lon - $pad * 1.3, $lon + $pad * 1.3]);
        $best = null;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $z) {
            $d = self::miles($lat, $lon, (float) $z['latitude'], (float) $z['longitude']);
            if ($d <= self::NEAR_MILES && ($best === null || $d < $best[2])) $best = [substr((string) $z['zip'], 0, 5), (string) $z['city'], $d];
        }
        return $best;
    }

    public static function miles(float $la1, float $lo1, float $la2, float $lo2): float
    {
        $x = deg2rad($lo2 - $lo1) * cos(deg2rad(($la1 + $la2) / 2));
        $y = deg2rad($la2 - $la1);
        return 3959 * sqrt($x * $x + $y * $y);
    }

    /** Upserts a batch (≤500). Keeps a person's approved or hidden; a feature no longer notable is skipped. */
    public static function batch(PDO $pdo, string $file, array $rows): int
    {
        $n = 0;
        $find = $pdo->prepare('SELECT status, image_url, image_page, image_credit, image_license FROM landmarks WHERE gnis_id = ?');
        $cols = ['name', 'fclass', 'state', 'county', 'lat', 'lon', 'zip5', 'near_town', 'nation', 'qid', 'wd_desc', 'wiki_title', 'extract', 'image_url', 'image_page', 'image_credit', 'image_license', 'status', 'why', 'file', 'loaded_at'];
        $ins = $pdo->prepare('INSERT INTO landmarks (gnis_id, ' . implode(', ', $cols) . ') VALUES (?' . str_repeat(', ?', count($cols)) . ')');
        $upd = $pdo->prepare('UPDATE landmarks SET ' . implode(' = ?, ', $cols) . ' = ? WHERE gnis_id = ?');
        foreach (array_slice($rows, 0, 500) as $r) {
            $id = (int) ($r['gnis_id'] ?? 0);
            $state = strtoupper(substr((string) ($r['state'] ?? ''), 0, 2));
            $name = self::clean((string) ($r['name'] ?? ''), 200);
            $lat = is_numeric($r['lat'] ?? null) ? (float) $r['lat'] : 0.0; $lon = is_numeric($r['lon'] ?? null) ? (float) $r['lon'] : 0.0;
            if ($id <= 0 || $name === '' || !in_array($state, NpiBulk::STATES, true) || $lat == 0.0 || $lon == 0.0) continue;
            if (str_contains(mb_strtolower($name), '(historical)')) continue;   // a name for something that's gone
            $img = (array) ($r['image'] ?? []);
            $okImg = !empty($img['url']) && preg_match('#^https://upload\.wikimedia\.org/#', (string) $img['url']) && preg_match(self::LICENSES, trim((string) ($img['license'] ?? '')));
            $v = ['name' => $name, 'fclass' => self::clean((string) ($r['class'] ?? ''), 40), 'state' => $state, 'county' => self::clean((string) ($r['county'] ?? ''), 80),
                  'lat' => round($lat, 6), 'lon' => round($lon, 6), 'nation' => self::clean((string) ($r['nation'] ?? ''), 120),
                  'qid' => preg_match('/^Q\d{1,12}$/', (string) ($r['qid'] ?? '')) ? (string) $r['qid'] : '',
                  'wd_desc' => self::clean((string) ($r['description'] ?? ''), 250), 'wiki_title' => self::clean((string) ($r['wiki_title'] ?? ''), 200),
                  'extract' => self::wikiAllowed($pdo) ? self::clean((string) ($r['extract'] ?? ''), 1200) : '',   // Wikipedia's words only where its rule allows (now: cite only)
                  'image_url' => $okImg ? mb_substr((string) $img['url'], 0, 500) : '',
                  'image_page' => $okImg && preg_match('#^https://commons\.wikimedia\.org/#', (string) ($img['page'] ?? '')) ? mb_substr((string) $img['page'], 0, 500) : '',
                  'image_credit' => $okImg ? self::clean((string) ($img['artist'] ?? ''), 200) : '', 'image_license' => $okImg ? self::clean((string) $img['license'], 60) : ''];
            if (!self::notable($v)) continue;
            $z = self::nearestZip($pdo, $lat, $lon);
            $v['zip5'] = $z ? $z[0] : ''; $v['near_town'] = $z ? $z[1] : '';
            [$v['status'], $v['why']] = self::decide($v);
            $v['file'] = mb_substr($file, 0, 40); $v['loaded_at'] = date('Y-m-d H:i:s');
            $find->execute([$id]);
            $old = $find->fetch(PDO::FETCH_ASSOC);
            $was = $old ? (string) $old['status'] : false;
            if ($was === false) $ins->execute(array_merge([$id], array_values(array_map(fn ($c) => $v[$c], $cols))));
            else {
                if (in_array($was, ['approved', 'hidden', 'closed'], true)) { $v['status'] = (string) $was; }   // a person's or a nation's decision stands
                if ($v['image_url'] === '' && (string) $old['image_url'] !== '')   // the month's data has none: keep the photo found or chosen since (findPhotos, a person)
                    foreach (['image_url', 'image_page', 'image_credit', 'image_license'] as $c) $v[$c] = (string) $old[$c];
                $upd->execute(array_merge(array_values(array_map(fn ($c) => $v[$c], $cols)), [$id]));
            }
            $n++;
        }
        return $n;
    }

    // ---- photos for landmarks without one (Jason, 2026-11-05: Agate Bridge had none) -----------------------------------

    /** Words of a name worth matching ("Agate Bridge" → agate, bridge). */
    public static function nameWords(string $name): array
    {
        $stop = ['the', 'and', 'of', 'at', 'on', 'in', 'for', 'to', 'mount', 'mt'];
        $w = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($name), -1, PREG_SPLIT_NO_EMPTY);
        return array_values(array_unique(array_filter($w, fn ($x) => mb_strlen($x) >= 3 && !in_array($x, $stop, true))));
    }

    /**
     * The best Commons photo of a landmark, or null: free to use (Landmarks::LICENSES, not marked non-free), at least 640 px
     * wide, every word of its name in the file's own name or title (not only in its tags: a building in the town of
     * Window Rock isn't the rock), and taken nearby: within 1.5 km (Commons' own location search), else named for it and
     * located within 5 miles. Many photos carry no location: one of those counts only with the landmark's whole name in its
     * title and its state, county or nearest town named in it ("Agate Bridge, Petrified Forest, Arizona").
     */
    public static function bestPhoto(object $wm, array $r): ?array
    {
        $words = self::nameWords((string) $r['name']);
        if (!$words) return null;
        $lat = (float) $r['lat']; $lon = (float) $r['lon'];
        $states = ['AZ' => 'arizona', 'NM' => 'new mexico', 'UT' => 'utah', 'CO' => 'colorado', 'NV' => 'nevada', 'CA' => 'california', 'TX' => 'texas'];
        $phrase = mb_strtolower(trim((string) $r['name']));
        $wheres = array_values(array_filter([$states[strtoupper((string) ($r['state'] ?? ''))] ?? '', mb_strtolower(trim((string) ($r['county'] ?? ''))),
            mb_strtolower(trim(preg_replace('/,.*$/', '', (string) ($r['near_town'] ?? ''))))], fn ($x) => mb_strlen($x) >= 4));
        $fits = function (array $it) use ($words, $lat, $lon, $phrase, $wheres): ?float {
            if (!preg_match(self::LICENSES, trim((string) $it['licence'])) || str_contains((string) $it['rights'], 'non-free')) return null;
            if ((int) $it['width'] < 640 || !preg_match('#^https://upload\.wikimedia\.org/#', (string) $it['full'])) return null;
            $hay = mb_strtolower(str_replace('_', ' ', $it['id'] . ' ' . $it['title']));
            foreach ($words as $w) if (!preg_match('/(^|[^\p{L}\p{N}])' . preg_quote($w, '/') . '/u', $hay)) return null;
            if ($it['lat'] === null || $it['lon'] === null) {   // no location on the photo: the whole name in its title, and where it is in its words
                $title = mb_strtolower(str_replace('_', ' ', $it['id'] . ' ' . $it['title']));
                $all = mb_strtolower(str_replace('_', ' ', $it['id'] . ' ' . $it['title'] . ' ' . $it['about'] . ' ' . $it['tags']));
                if (!str_contains($title, $phrase)) return null;
                foreach ($wheres as $w) if (str_contains($all, $w)) return 4.9;   // ranked after any photo located nearby
                return null;
            }
            $mi = self::miles($lat, $lon, (float) $it['lat'], (float) $it['lon']);
            return $mi <= 5.0 ? $mi : null;
        };
        foreach ([fn () => $wm->nearby($lat, $lon, 1500), fn () => $wm->named((string) $r['name'])] as $look) {
            $best = null; $bestMi = null;
            foreach ($look() as $it) { $mi = $fits($it); if ($mi !== null && ($bestMi === null || $mi < $bestMi)) { $best = $it; $bestMi = $mi; } }
            if ($best) return $best;
        }
        return null;
    }

    /**
     * Looks for photos for up to $n shown landmarks that have none (each looked at again after 30 days), one at a time,
     * and keeps the best with its credit and licence. [looked at, found].
     */
    public static function findPhotos(PDO $pdo, int $n = 20): array
    {
        require_once __DIR__ . '/stock/StockWikimedia.php';
        $wm = new StockWikimedia();
        $st = $pdo->query("SELECT gnis_id, name, lat, lon, state, county, near_town FROM landmarks WHERE " . self::visibleSql() . " AND image_url = ''
                              AND (photo_tried_at IS NULL OR photo_tried_at < NOW() - INTERVAL 30 DAY)
                            ORDER BY (wiki_title <> '') DESC, (qid <> '') DESC, gnis_id LIMIT " . max(1, min(100, $n)));
        $tried = $pdo->prepare('UPDATE landmarks SET photo_tried_at = NOW() WHERE gnis_id = ?');
        $set = $pdo->prepare("UPDATE landmarks SET image_url = ?, image_page = ?, image_credit = ?, image_license = ?, photo_source = 'commons_search' WHERE gnis_id = ? AND image_url = ''");
        $looked = 0; $found = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            try { $p = self::bestPhoto($wm, $r); } catch (Throwable $e) { error_log('landmark photos: ' . $e->getMessage()); break; }   // Commons is down or slowing us: try again next hour
            $looked++;
            $tried->execute([(int) $r['gnis_id']]);
            sleep(2);   // one landmark at a time, gently: Commons slows down callers that hurry
            if (!$p) continue;
            $set->execute([mb_substr((string) $p['full'], 0, 500), preg_match('#^https://commons\.wikimedia\.org/#', (string) $p['source_url']) ? mb_substr((string) $p['source_url'], 0, 500) : '',
                self::clean((string) $p['author'], 200), self::clean((string) $p['licence'], 60), (int) $r['gnis_id']]);
            $found++;
        }
        return [$looked, $found];
    }

    /**
     * Removes features missing from this month's data, except ones a person decided on, and never a held one (review B9,
     * 2026-11-13: "Never delete the data", decisions/0066): a row waiting for a person or a nation stays whatever the
     * month's file says. Only the states this load brought are touched, so a state whose file didn't come keeps its rows.
     */
    public static function finish(PDO $pdo, int $loadId, string $file, int $seen): int
    {
        $st = $pdo->prepare('SELECT DISTINCT state FROM landmarks WHERE file = ?'); $st->execute([$file]);
        $states = array_values(array_filter(array_map('strval', $st->fetchAll(PDO::FETCH_COLUMN)), fn ($s) => $s !== ''));
        $removed = 0;
        if ($states) {
            $del = $pdo->prepare("DELETE FROM landmarks WHERE file <> ? AND file NOT IN ('manual', 'wikidata') AND status NOT IN ('approved', 'hidden', 'closed', 'waiting')
                                    AND state IN (" . implode(',', array_fill(0, count($states), '?')) . ')');   // ones a person added, a guide found (PlaceFinder), a nation closed, or held, stay
            $del->execute(array_merge([$file], $states));
            $removed = $del->rowCount();
        }
        $pdo->prepare('UPDATE ' . Database::t('landmark_loads') . ' SET finished_at = ?, rows_seen = ?, removed = ? WHERE id = ?')->execute([date('Y-m-d H:i:s'), $seen, $removed, $loadId]);
        return $removed;
    }

    /** SQL for a landmark people can see: shown (public) or approved by a person. */
    public static function visibleSql(string $t = ''): string
    {
        $c = $t !== '' ? $t . '.' : '';
        return "{$c}status IN ('shown', 'approved')";   // waiting (sensitive, held) and closed never show
    }

    /** The same, for a row already read. */
    public static function visible(array $r): bool
    {
        return in_array($r['status'] ?? '', ['shown', 'approved'], true);
    }

    /** One feature people can see, for its page. */
    public static function get(PDO $pdo, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM landmarks WHERE gnis_id = ? AND ' . self::visibleSql());
        $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Its kind (Jason, 2026-11-10: "this should be from categories not guesses"): the category of ours it's in, else the
     * source's own class as the source gives it (GNIS's feature class in plain words, Wikidata's "instance of"). Never
     * read from its name. categorize() files each one under a category by its class.
     */
    public static function kindLabel(array $r): string
    {
        $cid = (int) ($r['category_id'] ?? 0);
        if ($cid > 0 && ($nm = self::categoryName($cid)) !== '') return $nm;
        return self::sourceClass($r);
    }

    /**
     * What's done there, by its kind (2026-11-10: Piestewa Peak wasn't a hike): words search reads, from the source's class
     * and our category, never from the name. A peak, canyon, trail, preserve or park is for hiking; a lake or river for
     * fishing; a campground for camping.
     */
    public static function activityWords(array $r): string
    {
        $k = mb_strtolower(self::sourceClass($r) . ' ' . self::kindLabel($r));
        $w = [];
        if (preg_match('/peak|summit|mount|ridge|range|canyon|gorge|trail|wilderness|preserve|reserve|park|natural area|arch|waterfall|falls|butte|mesa|cliff|hill|viewpoint|badlands|hoodoo|crater|volcano|dunes|forest/', $k)) $w[] = 'hiking hike hikes trail trails trailhead';
        if (preg_match('/lake|reservoir|river|creek|pond|stream|spring/', $k)) $w[] = 'fishing';
        if (preg_match('/camp/', $k)) $w[] = 'camping campground';
        if (preg_match('/park|lake|preserve/', $k)) $w[] = 'picnic';
        $say = ['walk' => 'walk walking stroll', 'drive' => 'drive scenic drive road trip', 'hike' => 'hike hiking', 'exhibits' => 'exhibits exhibit museum',
                'history' => 'history historic', 'views' => 'views view scenic', 'water' => 'water boating', 'camp' => 'camping', 'picnic' => 'picnic'];
        foreach (self::activities($r) as $act) $w[] = $say[$act] ?? '';
        return implode(' ', array_unique(array_filter($w)));
    }

    /**
     * What you do there (Jason, 2026-11-10: "For discovery the experience or activity is critical. A drive, a walking
     * exhibit, outdoor activities"): key => [label, how]. From what it is (the source's class and our category), never
     * its name; the research Claude wrote names them too when there was one.
     */
    public const ACTIVITIES = [
        'walk' => ['Walk', 'Best explored on foot.'],
        'drive' => ['Drive', 'Best by car: a drive with stops along the way.'],
        'hike' => ['Hike', 'Outdoors on foot: trails and views. Bring water.'],
        'exhibits' => ['Exhibits', 'Indoors, with exhibits to see. Check the hours before you go.'],
        'history' => ['Historic site', 'A historic place: see it from outside unless it opens to visitors.'],
        'views' => ['Views', 'A stop for the view.'],
        'water' => ['On the water', 'Fishing, boating, or a picnic by the shore.'],
        'camp' => ['Camp', 'Stay the night outdoors.'],
        'picnic' => ['Picnic & play', 'Room to picnic, play and stroll.'],
    ];

    /** Its activities, most telling first: [key, …]. */
    public static function activities(array $r): array
    {
        $own = json_decode((string) ($r['research_acts'] ?? ''), true);
        if (is_array($own) && $own) return array_values(array_intersect(array_map('strval', $own), array_keys(self::ACTIVITIES)));
        $k = mb_strtolower(self::sourceClass($r) . ' ' . self::kindLabel($r));
        $a = [];
        if (preg_match('/scenic byway|byway|scenic road|scenic route|highway|parkway/', $k)) $a[] = 'drive';
        if (preg_match('/museum|gallery|exhibit|art cent|arts cent|cultural cent|science cent|planetarium|aquarium|zoo/', $k)) $a[] = 'exhibits';
        if (preg_match('/historic district|neighbou?rhood|downtown|main street|plaza|square|garden|botanical|campus|street/', $k)) $a[] = 'walk';
        if (preg_match('/peak|summit|mount|ridge|range|canyon|gorge|trail|wilderness|preserve|reserve|arch|waterfall|falls|butte|mesa|cliff|hill|badlands|hoodoo|crater|volcano|dunes|forest|natural area/', $k)) $a[] = 'hike';
        if (preg_match('/viewpoint|overlook|lookout|vista|waterfall|falls|arch|canyon/', $k)) $a[] = 'views';
        if (preg_match('/lake|reservoir|river|creek|pond|stream|marina|beach/', $k)) $a[] = 'water';
        if (preg_match('/camp/', $k)) $a[] = 'camp';
        if (preg_match('/\bpark\b|parks|picnic|playground/', $k)) $a[] = 'picnic';
        if (preg_match('/historic|house|mansion|building|church|chapel|mission|fort|courthouse|station|bridge|monument|memorial|statue|landmark|cemetery|school|hotel|theat/', $k)) $a[] = 'history';
        return array_values(array_unique($a));
    }

    /** What the source calls it: GNIS's class in plain words, or Wikidata's class (or the kind a person chose). */
    public static function sourceClass(array $r): string
    {
        $fc = trim((string) ($r['fclass'] ?? ''));
        if ($fc === '') return 'Landmark';
        return self::CLASS_LABELS[$fc] ?? ucfirst(mb_strtolower($fc));
    }

    /** A category's name as the site shows it (cached for the request). */
    private static function categoryName(int $id): string
    {
        static $names = null;
        if ($names === null) {
            $names = [];
            try { foreach (Database::connection()->query('SELECT id, COALESCE(NULLIF(display_name, \'\'), name) AS n FROM categories WHERE is_active = 1')->fetchAll(PDO::FETCH_ASSOC) as $c) $names[(int) $c['id']] = (string) $c['n']; } catch (Throwable) {}
        }
        return $names[$id] ?? '';
    }

    /**
     * The category for a source class, by name: a category called that (or its plural), else one a member of staff gave
     * that word (category_terms); for a class of several words ("art museum"), the whole first, then its last word
     * ("museum"). 0 when none: shown as the source's class, and listed for staff (categoriesMissing) to give a term.
     */
    public static function categoryFor(PDO $pdo, string $class, string $plain = ''): int
    {
        static $memo = [];
        $k = mb_strtolower(trim($class)) . '|' . mb_strtolower(trim($plain));
        if (isset($memo[$k])) return $memo[$k];
        $tries = [];
        foreach (array_filter([trim($class), trim($plain)]) as $c) {
            $c = mb_strtolower($c);
            $tries[] = $c;
            if (str_contains($c, ' ')) $tries[] = (string) preg_replace('/^.* /', '', $c);   // "art museum": museum
        }
        foreach (array_values(array_unique($tries)) as $t) {
            $forms = array_values(array_unique([$t, $t . 's', $t . 'es', preg_replace('/y$/', 'ies', $t), preg_replace('/s$/', '', $t)]));
            $in = implode(',', array_fill(0, count($forms), '?'));
            try {
                $st = $pdo->prepare("SELECT id FROM categories WHERE is_active = 1 AND (LOWER(name) IN ($in) OR LOWER(COALESCE(display_name, '')) IN ($in)) ORDER BY parent_id IS NULL, id LIMIT 1");
                $st->execute(array_merge($forms, $forms));
                if ($id = (int) $st->fetchColumn()) return $memo[$k] = $id;
                $st = $pdo->prepare("SELECT t.category_id FROM category_terms t JOIN categories c ON c.id = t.category_id AND c.is_active = 1 WHERE LOWER(t.term) IN ($in) ORDER BY t.category_id LIMIT 1");
                $st->execute($forms);
                if ($id = (int) $st->fetchColumn()) return $memo[$k] = $id;
            } catch (Throwable) { return $memo[$k] = 0; }
        }
        return $memo[$k] = 0;
    }

    /**
     * Files landmarks not yet filed (category_id NULL) under a category, one source class at a time; 0 means none fits
     * yet. Those are asked again once a day, so a term staff give a category files them. Returns the ids that changed.
     */
    public static function categorize(PDO $pdo): array
    {
        try {
            require_once __DIR__ . '/PageCache.php';
            if (!PageCache::get($pdo, 'lm:cat:again')) { $pdo->exec('UPDATE landmarks SET category_id = NULL WHERE category_id = 0'); PageCache::put($pdo, 'lm:cat:again', 86400, 1); }
            $classes = $pdo->query('SELECT DISTINCT fclass FROM landmarks WHERE category_id IS NULL LIMIT 500')->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable) { return []; }
        $changed = [];
        foreach ($classes as $fc) {
            $fc = (string) $fc;
            $cid = self::categoryFor($pdo, $fc, self::CLASS_LABELS[$fc] ?? '');
            $st = $pdo->prepare('SELECT gnis_id FROM landmarks WHERE category_id IS NULL AND fclass = ?'); $st->execute([$fc]);
            $ids = $st->fetchAll(PDO::FETCH_COLUMN);
            $pdo->prepare('UPDATE landmarks SET category_id = ? WHERE category_id IS NULL AND fclass = ?')->execute([$cid, $fc]);
            if ($cid > 0) foreach ($ids as $i) $changed[] = (int) $i;
        }
        return $changed;
    }

    /** Source classes with no category yet, most landmarks first: [[class, n]] (for the health report and staff). */
    public static function categoriesMissing(PDO $pdo, int $limit = 25): array
    {
        try { return $pdo->query('SELECT fclass, COUNT(*) n FROM landmarks WHERE category_id = 0 AND ' . self::visibleSql() . ' GROUP BY fclass ORDER BY n DESC LIMIT ' . (int) $limit)->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable) { return []; }
    }

    /** GNIS classes (and the kinds a person adds) in plain words. */
    private const CLASS_LABELS = ['Monument' => 'Monument', 'Park' => 'Park', 'Viewpoint' => 'Viewpoint', 'Summit' => 'Peak', 'Valley' => 'Canyon', 'Pillar' => 'Rock formation', 'Arch' => 'Natural arch', 'Falls' => 'Waterfall', 'Crater' => 'Crater',
                'Cliff' => 'Cliff', 'Range' => 'Mountain range', 'Ridge' => 'Ridge', 'Lake' => 'Lake', 'Spring' => 'Spring', 'Basin' => 'Basin', 'Gap' => 'Pass',
                'Flat' => 'Flat', 'Plain' => 'Plain', 'Island' => 'Island', 'Rapids' => 'Rapids', 'Bench' => 'Bench', 'Area' => 'Natural area', 'Trail' => 'Trail', 'Campground' => 'Campground'];

    /** The nearest shown features to any of these points, within $miles (for place pages). */
    public static function near(PDO $pdo, array $points, float $miles = 35, int $limit = 8): array
    {
        if (!self::ready($pdo) || !$points) return [];
        $lats = array_column($points, 0); $lons = array_column($points, 1);
        $pad = $miles / 60;
        $st = $pdo->prepare("SELECT * FROM landmarks WHERE " . self::visibleSql() . " AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? LIMIT 2000");
        $st->execute([min($lats) - $pad, max($lats) + $pad, min($lons) - $pad * 1.3, max($lons) + $pad * 1.3]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $d = INF;
            foreach ($points as [$la, $lo]) $d = min($d, self::miles((float) $r['lat'], (float) $r['lon'], $la, $lo));
            if ($d <= $miles) $out[] = $r + ['miles' => $d];
        }
        // ones with a photo or an article first, then the nearest
        // the ones drawing the most interest first (Wikipedia's views, the guides naming them: interestTick), a little less the
        // further they are; then a photo or an article (2026-11-10: "rank by real interest")
        $rank = fn ($x) => (int) ($x['interest'] ?? 0) * 2 + (($x['image_url'] ?? '') !== '' ? 3 : 0) + (($x['wiki_title'] ?? '') !== '' ? 3 : 0) - $x['miles'] / 5;
        usort($out, fn ($a, $b) => $rank($b) <=> $rank($a));
        return array_slice($out, 0, $limit);
    }

    /**
     * What pairs with a place (2026-11-10, "the mission is immersion and connecting"): up to $n others within 15 mi,
     * each of a different kind from it and from each other (a canyon, then a museum, then a lake), the most interest
     * first; never a bare name (each has a photo, an article, its interest or what it's like).
     */
    public static function pairs(PDO $pdo, array $r, int $n = 3): array
    {
        $seen = [self::kindLabel($r) => 1]; $out = [];
        foreach (self::near($pdo, [[(float) $r['lat'], (float) $r['lon']]], 15, 60) as $x) {
            if ((int) $x['gnis_id'] === (int) $r['gnis_id']) continue;
            $k = self::kindLabel($x);
            if (isset($seen[$k])) continue;
            if ((int) ($x['interest'] ?? 0) <= 0 && (string) ($x['image_url'] ?? '') === '' && (string) ($x['wiki_title'] ?? '') === '' && trim((string) ($x['research'] ?? '')) === '') continue;
            $seen[$k] = 1; $out[] = $x;
            if (count($out) >= $n) break;
        }
        return $out;
    }

    /** A place to eat within 5 mi of a point, nearest first: one of our listings, else OpenStreetMap's kept (credited). Or null. */
    public static function bite(PDO $pdo, float $lat, float $lon): ?array
    {
        $box = [$lat - 0.08, $lat + 0.08, $lon - 0.1, $lon + 0.1];
        $best = null;
        try {
            $st = $pdo->prepare("SELECT label, url, sub, lat, lon FROM search_index WHERE kind = 'listing' AND why LIKE '%eat%' AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? LIMIT 300");
            $st->execute($box);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $x) {
                $mi = self::miles($lat, $lon, (float) $x['lat'], (float) $x['lon']);
                if ($mi <= 5 && (!$best || $mi < $best['miles'])) $best = ['label' => (string) $x['label'], 'sub' => trim(explode('·', (string) $x['sub'])[0]), 'url' => (string) $x['url'], 'lat' => (float) $x['lat'], 'lon' => (float) $x['lon'], 'miles' => $mi, 'osm' => false];
            }
        } catch (Throwable) {}
        if ($best) return $best;
        try {   // OpenStreetMap's layer (decisions/0065): shown from its own table, credited, never copied into ours
            $st = $pdo->prepare("SELECT name, what, lat, lon FROM open_places WHERE kind IN ('food', 'coffee', 'pizza', 'all') AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? LIMIT 300");
            $st->execute($box);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $x) {
                if (!preg_match('/restaurant|food|caf|pizza|coffee|diner|grill|bakery|ice cream/i', (string) $x['what'] . ' ' . (string) $x['name'])) continue;
                $mi = self::miles($lat, $lon, (float) $x['lat'], (float) $x['lon']);
                if ($mi <= 5 && (!$best || $mi < $best['miles'])) $best = ['label' => (string) $x['name'], 'sub' => (string) $x['what'], 'url' => '', 'lat' => (float) $x['lat'], 'lon' => (float) $x['lon'], 'miles' => $mi, 'osm' => true];
            }
        } catch (Throwable) {}
        return $best;
    }

    /**
     * A suggested outing from a place: it, then the pairs nearest-next (two at most), then a bite to eat, each leg's
     * miles; and the whole route as one directions link. [['stops' => [['label', 'sub', 'url', 'lat', 'lon', 'leg']], 'miles', 'route']] or null.
     */
    public static function outing(PDO $pdo, array $r, array $pairs): ?array
    {
        $here = ['label' => (string) $r['name'], 'sub' => self::kindLabel($r), 'url' => '', 'lat' => (float) $r['lat'], 'lon' => (float) $r['lon'], 'leg' => 0.0];
        $left = array_map(fn ($x) => ['label' => (string) $x['name'], 'sub' => self::kindLabel($x), 'url' => '/place/landmark.php?id=' . (int) $x['gnis_id'], 'lat' => (float) $x['lat'], 'lon' => (float) $x['lon']], array_slice($pairs, 0, 3));
        $stops = [$here]; $at = $here;
        while ($left && count($stops) < 3) {
            usort($left, fn ($a, $b) => self::miles($at['lat'], $at['lon'], $a['lat'], $a['lon']) <=> self::miles($at['lat'], $at['lon'], $b['lat'], $b['lon']));
            $nx = array_shift($left); $nx['leg'] = self::miles($at['lat'], $at['lon'], $nx['lat'], $nx['lon']);
            $stops[] = $nx; $at = $nx;
        }
        if (count($stops) < 2) return null;
        if ($b = self::bite($pdo, $at['lat'], $at['lon'])) { $b['leg'] = self::miles($at['lat'], $at['lon'], $b['lat'], $b['lon']); $stops[] = $b; }
        $pt = fn ($s) => round($s['lat'], 5) . ',' . round($s['lon'], 5);
        $mid = array_slice($stops, 1, -1);
        $route = 'https://www.google.com/maps/dir/?api=1&origin=' . $pt($stops[0]) . '&destination=' . $pt(end($stops)) . ($mid ? '&waypoints=' . implode('%7C', array_map($pt, $mid)) : '') . '&travelmode=driving';
        return ['stops' => $stops, 'miles' => array_sum(array_column($stops, 'leg')), 'route' => $route];
    }

    /** The best-known shown features anywhere: ones with a photo, those with an article first (Let's Explore → Parks & Landmarks). */
    public static function top(PDO $pdo, int $limit = 24): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT gnis_id, name, fclass, state, near_town, lat, lon, nation, wd_desc, image_url, image_credit, wiki_title FROM landmarks
                              WHERE " . self::visibleSql() . " AND image_url <> '' ORDER BY (wiki_title <> '') DESC, (wd_desc <> '') DESC, name LIMIT " . max(1, min(200, $limit)));
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    // ---- added by a person (Admin → Landmarks → Add a landmark) -------------------------------------------------

    /** Ids from here up are ones a person added (GNIS ids are far below). */
    public const MANUAL_FROM = 900000000;
    /** The kinds a person can choose, as GNIS classes (kindLabel() names them). */
    public const ADD_KINDS = ['Area' => 'Natural area or badlands', 'Arch' => 'Natural arch or bridge', 'Pillar' => 'Rock formation', 'Summit' => 'Peak, butte or mesa',
                              'Valley' => 'Canyon', 'Falls' => 'Waterfall', 'Spring' => 'Spring or hot spring', 'Crater' => 'Crater or volcano', 'Lake' => 'Lake',
                              'Monument' => 'Monument or marker', 'Park' => 'Park', 'Viewpoint' => 'Viewpoint', 'Trail' => 'Trail or trailhead', 'Campground' => 'Campground'];

    /**
     * A landmark the data doesn't have (Four Corners Monument, the Nambe Badlands). An Editor's shows at once, unless
     * it's on a nation's land without "the nation welcomes visitors here" ticked; a Content Creator's waits.
     */
    public static function add(PDO $pdo, int $uid, array $in, bool $canPublish): int
    {
        $name = self::clean((string) ($in['name'] ?? ''), 200);
        $lat = is_numeric($in['lat'] ?? null) ? (float) $in['lat'] : 0.0; $lon = is_numeric($in['lon'] ?? null) ? (float) $in['lon'] : 0.0;
        $state = strtoupper(substr((string) ($in['state'] ?? ''), 0, 2));
        $class = (string) ($in['kind'] ?? '');
        if (mb_strlen($name) < 3) throw new InvalidArgumentException('Give it its name.');
        if ($lat < 14 || $lat > 72 || $lon < -180 || $lon > -50) throw new InvalidArgumentException('Give its latitude and longitude (for example 36.9990, -109.0452). Right-click the spot in Google Maps to copy them.');
        if (!in_array($state, NpiBulk::STATES, true)) throw new InvalidArgumentException('Choose its state.');
        if (!isset(self::ADD_KINDS[$class])) throw new InvalidArgumentException('Choose what kind of place it is.');
        $nation = self::clean((string) ($in['nation'] ?? ''), 120);
        $img = trim((string) ($in['image_url'] ?? '')); $lic = self::clean((string) ($in['image_license'] ?? ''), 60);
        if ($img !== '' && (!preg_match('#^https://upload\.wikimedia\.org/#', $img) || !preg_match(self::LICENSES, $lic))) {
            throw new InvalidArgumentException('A photo must be a Wikimedia Commons file (upload.wikimedia.org) with a free license: CC0, public domain, CC BY or CC BY-SA.');
        }
        $id = max(self::MANUAL_FROM, (int) $pdo->query('SELECT MAX(gnis_id) FROM landmarks')->fetchColumn() + 1);
        $z = self::nearestZip($pdo, $lat, $lon);
        $v = ['name' => $name, 'fclass' => $class, 'state' => $state, 'county' => self::clean((string) ($in['county'] ?? ''), 80), 'lat' => round($lat, 6), 'lon' => round($lon, 6), 'nation' => $nation];
        [$status, $why] = self::decide($v);
        $evidence = trim((string) ($in['evidence_url'] ?? ''));
        if ($evidence !== '' && !preg_match('#^https?://\S+$#i', $evidence)) throw new InvalidArgumentException('The evidence must be a link (https://…).');
        if ($canPublish && $status !== 'waiting') { $status = 'approved'; $why = ''; }   // public: an Editor publishes it; sensitive stays held
        elseif (!$canPublish) { $status = 'waiting'; $why = 'Added by a Content Creator: an Editor approves it' . ($nation !== '' ? ' (on ' . $nation . ' land)' : ''); }
        $pdo->prepare('INSERT INTO landmarks (gnis_id, name, fclass, state, county, lat, lon, zip5, near_town, nation, qid, wd_desc, wiki_title, extract, image_url, image_page, image_credit, image_license,
                                              status, why, reviewed_by, reviewed_at, review_note, file, loaded_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, \'\', \'\', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, \'\', \'manual\', ?)')
            ->execute([$id, $v['name'], $class, $state, $v['county'], $v['lat'], $v['lon'], $z ? $z[0] : '', $z ? $z[1] : '', $nation,
                       self::clean((string) ($in['wiki_title'] ?? ''), 200), self::clean((string) ($in['description'] ?? ''), 1200),
                       $img !== '' ? mb_substr($img, 0, 500) : '', $img !== '' && preg_match('#^https://commons\.wikimedia\.org/#', (string) ($in['image_page'] ?? '')) ? mb_substr((string) $in['image_page'], 0, 500) : '',
                       $img !== '' ? self::clean((string) ($in['image_credit'] ?? ''), 200) : '', $img !== '' ? $lic : '',
                       $status, $why, $status === 'approved' ? $uid : null, $status === 'approved' ? date('Y-m-d H:i:s') : null, date('Y-m-d H:i:s')]);
        if ($nation !== '') {
            $pdo->prepare('UPDATE landmarks SET evidence_url = ?, evidence_note = ? WHERE gnis_id = ?')->execute([mb_substr($evidence, 0, 500), self::clean((string) ($in['evidence_note'] ?? ''), 300), $id]);
            self::nationLog($pdo, $id, $nation, $name, '', $status, $uid, '', $evidence, 'Added by hand');
        }
        return $id;
    }

    /** Writes the nations' log when a place on a nation's land changes (decisions/0058 §26). */
    private static function nationLog(PDO $pdo, int $id, string $nation, string $name, string $from, string $to, ?int $uid, string $contact, string $evidence, string $note): void
    {
        if (!class_exists('Nations')) require_once __DIR__ . '/Nations.php';
        Nations::log($pdo, $nation, 'landmark', (string) $id, $name, $from, $to, $uid, $contact, $evidence, $note);
    }

    // ---- review (Admin → Landmarks) -------------------------------------------------------------------------

    public const VIEWS = ['waiting' => 'Waiting', 'shown' => 'Shown', 'approved' => 'Approved', 'hidden' => 'Hidden', 'closed' => 'Closed by a nation'];

    /**
     * The tabs Admin → Landmarks shows, by who decided (decisions/0058 §27): Public (shows: from the data, or added by
     * hand), Hidden by us, Closed by a nation. With the nation tools on, Waiting comes first.
     */
    public static function views(): array
    {
        return (self::NATION_TOOLS ? ['waiting' => 'Waiting'] : []) + ['public' => 'Public', 'hidden' => 'Hidden by us', 'closed' => 'Closed by a nation'];
    }

    /** Statuses behind a tab. */
    private static function statusesFor(string $view): array
    {
        return $view === 'public' ? ['shown', 'approved'] : [$view];
    }

    /** Per tab, plus 'kept': waiting ones, kept unused while there's no review queue. */
    public static function counts(PDO $pdo): array
    {
        $by = [];
        foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM landmarks GROUP BY status')->fetchAll(PDO::FETCH_ASSOC) as $r) $by[$r['status']] = (int) $r['n'];
        $out = [];
        foreach (array_keys(self::views()) as $v) $out[$v] = array_sum(array_map(fn ($st) => $by[$st] ?? 0, self::statusesFor($v)));
        $out['kept'] = $by['waiting'] ?? 0;
        return $out;
    }

    public static function queue(PDO $pdo, string $view, string $q = '', int $limit = 100): array
    {
        $sts = self::statusesFor($view);
        $in = implode(',', array_fill(0, count($sts), '?'));
        $st = $pdo->prepare("SELECT * FROM landmarks WHERE status IN ($in)" . ($q !== '' ? ' AND name LIKE ?' : '') . ' ORDER BY (image_url <> \'\') + (wiki_title <> \'\') DESC, name LIMIT ' . max(1, min(300, $limit)));
        $st->execute($q !== '' ? array_merge($sts, ['%' . $q . '%']) : $sts);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * approve | hide | restore | nation_close | nation_reopen.
     *  - Approving one held as sensitive on a nation's land needs the nation's word: a link to its own page that opens it.
     *  - Hiding needs a reason.
     *  - "Closed by the nation" needs who asked; no reload, Undo or staff approval reopens it — only the nation, through
     *    "Reopen at the nation's request" with who asked (decisions/0058 §26).
     *  - Every change on a nation's land is written to the nations' log.
     */
    public static function review(PDO $pdo, int $uid, int $id, string $do, string $note = '', string $evidence = '', string $contact = ''): void
    {
        $st = $pdo->prepare('SELECT * FROM landmarks WHERE gnis_id = ?');
        $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That landmark is gone. It may have left this month’s data.');
        $note = mb_substr(trim($note), 0, 300); $evidence = trim($evidence); $contact = mb_substr(trim(strip_tags($contact)), 0, 200);
        $closed = $r['status'] === 'closed';
        if (!self::NATION_TOOLS && (($do === 'approve' && $r['status'] === 'waiting') || $do === 'nation_reopen')) {
            throw new InvalidArgumentException('What\'s held is sensitive: it stays unused until the nation tools, when the nation decides.');
        }
        if ($closed && $do !== 'nation_reopen') throw new InvalidArgumentException('The nation closed this one. Only the nation can reopen it: use “Reopen at the nation’s request”.');
        if ($do === 'approve') {
            if ($r['nation'] !== '' && $r['status'] === 'waiting') {   // held as sensitive: only the nation's own word opens it
                if (!preg_match('#^https?://\S+$#i', $evidence)) throw new InvalidArgumentException('This one is held as sensitive: add the link to the nation’s own page, or its word, that opens it to visitors.');
            }
            $status = 'approved';
        } elseif ($do === 'hide') {
            if ($note === '') throw new InvalidArgumentException('Say why it’s hidden, for the next person.');
            $status = 'hidden';
        } elseif ($do === 'restore') {
            $status = self::decide($r)[0];
        } elseif ($do === 'nation_close') {
            if ($r['nation'] === '') throw new InvalidArgumentException('This one isn’t on a nation’s land.');
            if ($contact === '') throw new InvalidArgumentException('Say who at the nation asked (their office, and how they asked).');
            $status = 'closed';
        } elseif ($do === 'nation_reopen') {
            if (!$closed) throw new InvalidArgumentException('It isn’t closed.');
            if ($contact === '') throw new InvalidArgumentException('Say who at the nation asked to reopen it.');
            $status = 'waiting';   // back to an Editor, with the nation's word as the evidence
        } else {
            throw new InvalidArgumentException('Unknown action.');
        }
        $pdo->prepare('UPDATE landmarks SET status = ?, reviewed_by = ?, reviewed_at = ?, review_note = ?' . ($do === 'approve' && $evidence !== '' ? ', evidence_url = ?' : '') . ' WHERE gnis_id = ?')
            ->execute(array_merge([$status, $uid, date('Y-m-d H:i:s'), $note], $do === 'approve' && $evidence !== '' ? [mb_substr($evidence, 0, 500)] : [], [$id]));
        if ($r['nation'] !== '') self::nationLog($pdo, $id, (string) $r['nation'], (string) $r['name'], (string) $r['status'], $status, $uid, $contact, $evidence, $note);
    }
}
