<?php

declare(strict_types=1);

require_once __DIR__ . '/SearchIndex.php';

/**
 * Businesses from OpenStreetMap, only where we have no listings yet (decisions/0065). For a place outside our regions
 * ("Seattle, WA"), a need or a search that names a kind of business ("Storage", "pizza") asks OpenStreetMap's Overpass
 * service once for that kind around the town, and keeps the answer for about a week (open_places). Shown as
 * OpenStreetMap's, with its credit; never a listing, never in our directory.
 *
 * Its own layer (Jason, 2026-11-10: "Use openstreetmap for everything we can get for sources and data as long as we
 * dont have to share back data"): kept in its own tables, shown as OpenStreetMap's with its credit (name, kind, address,
 * phone, hours, website), never copied into our listings or landmarks, so the licence (ODbL) never asks us to share our
 * own data back (its "collective database" and "horizontal layers" guidance). Businesses, and since 2026-11-10 the
 * outdoors too: trailheads, parks and preserves, viewpoints, campgrounds. Never anything marked historic, and never a
 * name that may mark a sacred or protected place (Landmarks::isProtected, decisions/0066).
 *
 * Only the kind and a point rounded to about 5 miles go to OpenStreetMap, from our server: never who searched.
 */
final class OpenPlaces
{
    /** Our kinds: [label, Overpass filters, words that ask for it]. Each filter is completed with (around:…). */
    public const KINDS = [
        'pizza' => ['Pizza', ['nwr["amenity"~"^(restaurant|fast_food)$"]["cuisine"~"pizza"]'], '/\bpizz/'],
        'coffee' => ['Coffee', ['nwr["amenity"="cafe"]'], '/\b(coffee|cafe|café|espresso)/'],
        'food' => ['Places to eat', ['nwr["amenity"~"^(restaurant|fast_food|cafe|food_court)$"]'], '/\b(restaurants?|food|eat|eating|dinner|lunch|breakfast|brunch|burgers?|tacos?|diner|bbq|barbecue|sushi|mexican|chinese|thai|italian)\b/'],
        'lodging' => ['Places to stay', ['nwr["tourism"~"^(hotel|motel|guest_house|hostel)$"]'], '/\b(hotels?|motels?|lodging|lodges?|inns?|hostels?|stay|bed and breakfast|b&b)\b/'],
        'fuel' => ['Gas', ['nwr["amenity"="fuel"]'], '/\b(gas|fuel|gas stations?|diesel)\b/'],
        'grocery' => ['Groceries', ['nwr["shop"~"^(supermarket|grocery|convenience|greengrocer)$"]'], '/\b(grocer(y|ies)|supermarkets?|food stores?|convenience)\b/'],
        'pharmacy' => ['Pharmacies', ['nwr["amenity"="pharmacy"]', 'nwr["shop"="chemist"]'], '/\b(pharmac(y|ies)|drug ?stores?|prescriptions?|meds|medicine)\b/'],
        'hospital' => ['Hospitals', ['nwr["amenity"="hospital"]'], '/\b(hospitals?|emergency rooms?|\ber\b)/'],
        'clinic' => ['Clinics', ['nwr["amenity"~"^(clinic|doctors)$"]'], '/\b(clinics?|urgent care|doctors?|walk-?in)\b/'],
        'storage' => ['Self storage', ['nwr["shop"="storage_rental"]', 'nwr["amenity"="storage_rental"]'], '/\b(storage|self-?storage|storage units?)\b/'],
        'auto' => ['Auto repair', ['nwr["shop"~"^(car_repair|tyres)$"]'], '/\b(tires?|tyres?|mechanics?|auto repair|car repair|oil change|auto shops?)\b/'],
        'hardware' => ['Hardware', ['nwr["shop"~"^(hardware|doityourself)$"]'], '/\b(hardware|home improvement)\b/'],
        'laundry' => ['Laundry', ['nwr["shop"~"^(laundry|dry_cleaning)$"]'], '/\b(laundr(y|omat)|laundromats?|dry clean(ing|ers)?)\b/'],
        // the outdoors (2026-11-10)
        'trail' => ['Trailheads', ['nwr["highway"="trailhead"]', 'nwr["leisure"="nature_reserve"]["name"]'], '/\b(hik(e|es|ing)|trails?|trailheads?)\b/'],
        'camping' => ['Campgrounds', ['nwr["tourism"~"^(camp_site|caravan_site)$"]'], '/\b(camping|campgrounds?|campsites?|rv parks?|camp sites?)\b/'],
        'park' => ['Parks', ['nwr["leisure"~"^(park|nature_reserve)$"]["name"]'], '/\b(parks?|preserves?|playgrounds?)\b/'],
        'viewpoint' => ['Viewpoints', ['nwr["tourism"="viewpoint"]'], '/\b(viewpoints?|scenic views?|overlooks?|lookouts?)\b/'],
        // the places people go (2026-11-10, "the mission is immersion and connecting"): museums, galleries, zoos, gardens, parks,
        // attractions, theatres; never anything historic (ruins, memorials) or a name that may mark a sacred place
        'todo' => ['Things to do', ['nwr["tourism"~"^(museum|gallery|zoo|aquarium|theme_park|attraction)$"]["name"]', 'nwr["leisure"~"^(park|garden|water_park|nature_reserve)$"]["name"]', 'nwr["amenity"~"^(theatre|arts_centre)$"]["name"]'], '/(?!)/'],
        // outings (2026-11-10, "place to take my kids"): what suits who's coming; never asked for by words, only by an outing
        'family' => ['Places for kids', ['nwr["leisure"~"^(playground|water_park|miniature_golf|trampoline_park|amusement_arcade|ice_rink|park)$"]["name"]', 'nwr["tourism"~"^(zoo|aquarium|theme_park|museum)$"]["name"]', 'nwr["amenity"~"^(library|ice_cream)$"]["name"]'], '/(?!)/'],
        'dog' => ['Places for dogs', ['nwr["leisure"="dog_park"]', 'nwr["leisure"~"^(park|nature_reserve)$"]["name"]["dog"!="no"]'], '/(?!)/'],
        // everything everyday at once: the map with no words, and "near me" alone (2026-11-10: "results are nonexistent")
        'all' => ['Places near you', ['nwr["amenity"~"^(restaurant|fast_food|cafe|fuel|pharmacy)$"]', 'nwr["shop"~"^(supermarket|grocery|convenience)$"]', 'nwr["tourism"~"^(hotel|motel)$"]'], '/(?!)/'],
    ];
    /** Words that look like a kind but aren't that business ("Gas company" is a utility, "Food banks" aren't restaurants). */
    private const NOT = [
        'fuel' => '/\b(compan(y|ies)|lines?|propane|heat|heating)\b/',
        'food' => '/\b(banks?|pantr(y|ies)|cakes?|meals)\b/',
        'lodging' => '/\bguides?\b/',
        'auto' => '/\bchains?\b/',
    ];
    /** Overpass servers, tried in turn when one doesn't answer (the crawler's own list; 2026-11-10: "why am I not seeing
     *  any listings from osm" was one server timing out) */
    private const URLS = ['https://overpass-api.de/api/interpreter', 'https://overpass.private.coffee/api/interpreter', 'https://overpass.kumi.systems/api/interpreter'];
    private const KEEP_DAYS = 7;
    private const PER_HOUR = 60;      // asks to OpenStreetMap in an hour, everything together (its fair use)
    private const BACKGROUND = 15;    // of those, the most our own jobs may use, so visitors' asks always have room
    private const RETRY_MINUTES = 10; // a spot that wasn't answered is asked again this soon, not a day later

    /** A time limit (microtime) a caller may set: no ask to OpenStreetMap starts too close to it, and none outlasts it
     *  (2026-11-10: a guide's "Finding places" ran past its own limit while OpenStreetMap was slow, and started over). */
    public static ?float $until = null;

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM open_places LIMIT 1'); $pdo->query('SELECT 1 FROM open_place_asks LIMIT 1'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    /** The kind of business some words ask for ("Storage", "Warehouses-Merchandise & Self Storage", "pizza"), or ''. */
    /**
     * The kinds of place OpenStreetMap itself names in what we ask it for ("dog_park", "playground", "water_park"), as
     * words ("dog park"), each with the kind it's asked under: [words => kind]. Its own vocabulary, not a list of ours
     * (2026-11-11: "dog park" should suggest dog parks).
     */
    public static function tagWords(): array
    {
        static $m = null;
        if ($m !== null) return $m;
        $m = [];
        foreach (self::KINDS as $k => [, $qs]) foreach ($qs as $q0) {
            if (preg_match_all('/"(?:leisure|amenity|tourism|shop)"(?:~"\^\(([a-z_|]+)\)\$"|="([a-z_]+)")/', (string) $q0, $mm, PREG_SET_ORDER)) {
                foreach ($mm as $x) foreach (explode('|', ($x[1] ?? '') !== '' ? $x[1] : ($x[2] ?? '')) as $v) if ($v !== '' && !isset($m[$w = str_replace('_', ' ', $v)])) $m[$w] = $k;
            }
        }
        return $m;
    }

    public static function kindFor(string $words): string
    {
        $w = ' ' . mb_strtolower($words) . ' ';
        if (preg_match('/ dog ?parks? | off.?leash /u', $w)) return 'dog';   // asked as dog parks, not all parks
        foreach (self::KINDS as $k => [, , $re]) if (preg_match($re, $w) && !(isset(self::NOT[$k]) && preg_match(self::NOT[$k], $w))) return $k;
        return '';
    }

    /**
     * Up to $n of a kind near a point, nearest first: from what's kept, else asked of OpenStreetMap (once a week per
     * spot). [['ref', 'label', 'what', 'phone', 'website', 'hours', 'street', 'city', 'miles', 'url', 'directions']].
     */
    public static function near(PDO $pdo, string $kind, float $lat, float $lon, int $n = 5, float $within = 25, bool $background = false): array
    {
        if (!isset(self::KINDS[$kind]) || !self::ready($pdo)) return [];
        $cell = in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? 50 : 10;   // the spot that's asked about: about 7 miles, or 1.4 for everything (asked closer in)
        $rl = round($lat * $cell) / $cell; $ro = round($lon * $cell) / $cell;
        $dp = in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? 2 : 1;
        $qkey = $kind . '@' . number_format($rl, $dp, '.', '') . ',' . number_format($ro, $dp, '.', '');   // other kinds keep their kept spots
        $st = $pdo->prepare('SELECT asked_at FROM open_place_asks WHERE qkey = ?'); $st->execute([$qkey]);
        $at = $st->fetchColumn();
        if ($at === false || strtotime((string) $at) < time() - self::KEEP_DAYS * 86400) self::ask($pdo, $kind, $qkey, $rl, $ro, $background);
        $d = 25 / 69.0;
        $st = $pdo->prepare('SELECT * FROM open_places WHERE kind = ? AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? LIMIT 400');
        $st->execute([$kind, $lat - $d, $lat + $d, $lon - $d * 1.4, $lon + $d * 1.4]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $mi = SearchIndex::miles($lat, $lon, (float) $r['lat'], (float) $r['lon']);
            if ($mi > min(25, $within)) continue;   // the Distance slider (decisions/0060), at most 25 miles
            // a nation's land (review A3, decisions/0066): a business there shows with the nation's name and its rules, its
            // directions to a place the nation opens to visitors (Nations::pin) or none; anything else there (a trailhead, a
            // reserve, a viewpoint) waits for the nation's own tools, as our landmarks do
            $n = self::nationAt($pdo, (float) $r['lat'], (float) $r['lon']);
            $to = $r['lat'] . ',' . $r['lon'];
            if ($n !== null) {
                $biz = !in_array($kind, self::OUTDOOR, true) && (trim((string) $r['phone']) !== '' || trim((string) $r['website']) !== '');
                if (!$biz) continue;
                [$pl, $po] = Nations::pin($pdo, (float) $r['lat'], (float) $r['lon']);
                $to = $pl !== null ? $pl . ',' . $po : '';
            }
            $out[] = ['ref' => (string) $r['osm_ref'], 'label' => (string) $r['name'], 'what' => (string) $r['what'], 'phone' => (string) $r['phone'],
                      'website' => (string) $r['website'], 'hours' => (string) $r['hours'], 'street' => (string) $r['street'], 'city' => (string) $r['city'],
                      'miles' => round($mi, 1), '_lat' => (float) $r['lat'], '_lon' => (float) $r['lon'], 'url' => 'https://www.openstreetmap.org/' . $r['osm_ref'],
                      'directions' => $to !== '' ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($to) : '',
                      'nation' => $n !== null ? Nations::label($pdo, $n) : '', 'note' => $n !== null ? 'On ' . Nations::label($pdo, $n) . ' land: visitors follow the nation\'s rules.' : ''];
        }
        usort($out, fn ($a, $b) => $a['miles'] <=> $b['miles']);
        // the same business mapped twice (a point and its building): once
        $kept = [];
        foreach ($out as $o) {
            foreach ($kept as $k) if (mb_strtolower($k['label']) === mb_strtolower($o['label']) && SearchIndex::miles($k['_lat'], $k['_lon'], $o['_lat'], $o['_lon']) < 0.1) continue 2;
            $kept[] = $o;
        }
        return array_map(function ($o) { unset($o['_lat'], $o['_lon']); return $o; }, array_slice($kept, 0, $n));
    }

    /** The kinds that are places outdoors, not businesses. */
    private const OUTDOOR = ['trail', 'camping', 'park', 'viewpoint', 'todo', 'family', 'dog'];

    /** The nation's land a point is on (its shape name), or null; remembered by spot for one request. */
    private static function nationAt(PDO $pdo, float $lat, float $lon): ?string
    {
        static $seen = [];
        require_once __DIR__ . '/Nations.php';
        $k = round($lat, 3) . ',' . round($lon, 3);
        if (!array_key_exists($k, $seen)) { try { $seen[$k] = Nations::at($pdo, $lat, $lon); } catch (Throwable $e) { $seen[$k] = null; } }
        return $seen[$k];
    }

    /** Asks OpenStreetMap for a kind around a spot (about 8 miles, then 25 when that finds fewer than 3) and keeps it. */
    private static function ask(PDO $pdo, string $kind, string $qkey, float $lat, float $lon, bool $background = false): void
    {
        // its fair use: all of our searches together ask at most PER_HOUR times an hour
        try { $n = (int) $pdo->query("SELECT COUNT(*) FROM open_place_asks WHERE asked_at >= '" . date('Y-m-d H:i:s', time() - 3600) . "'")->fetchColumn(); } catch (Throwable) { $n = 0; }
        if ($n >= self::PER_HOUR || ($background && $n >= self::BACKGROUND)) return;
        $found = 0; $ok = false;
        foreach ((in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? [3000, 8000] : [13000, 40000]) as $m) {   // everything, or things to do: closer in, it's dense
            $els = self::fetch($kind, $lat, $lon, $m);
            if ($els === null) break;   // didn't answer: asked again later
            $ok = true;
            $found = self::keep($pdo, $kind, $els);
            if ($found >= 3) break;
        }
        // not answered: asked again in RETRY_MINUTES (marked as asked that long before a week ran out); answered: kept a week
        $when = $ok ? date('Y-m-d H:i:s') : date('Y-m-d H:i:s', time() - self::KEEP_DAYS * 86400 + self::RETRY_MINUTES * 60);
        try {
            $pdo->prepare('DELETE FROM open_place_asks WHERE qkey = ?')->execute([$qkey]);
            $pdo->prepare('INSERT INTO open_place_asks (qkey, found, asked_at) VALUES (?, ?, ?)')->execute([$qkey, $found, $when]);
        } catch (Throwable $e) { error_log('open places ask: ' . $e->getMessage()); }
    }

    /** The elements Overpass returns, or null when it didn't answer. OSM_FIXTURE (a JSON file) stands in for it in tests. */
    private static function fetch(string $kind, float $lat, float $lon, int $meters): ?array
    {
        if (($fx = getenv('OSM_FIXTURE')) && is_file($fx)) {
            $all = json_decode((string) file_get_contents($fx), true);
            return (array) ($all[$kind] ?? []);
        }
        if (!function_exists('curl_init')) return null;
        $parts = '';
        foreach (self::KINDS[$kind][1] as $f) $parts .= $f . '(around:' . $meters . ',' . $lat . ',' . $lon . ');';
        $q = '[out:json][timeout:25];(' . $parts . ');out center tags ' . (in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? 200 : 80) . ';';
        foreach (self::URLS as $i => $url) {   // the next server when one is busy or slow: two at most, so a visitor isn't kept long
            if ($i >= 2) break;
            $left = self::$until !== null ? (int) floor(self::$until - microtime(true)) : 18;
            if ($left < 6) return null;   // no time left: not answered, asked again later
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(['data' => $q]), CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => min(18, $left), CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_USERAGENT => 'Traversence/1.0 (+https://traversence.com)']);
            $body = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            if ($body === false || $code !== 200) { error_log('open places: Overpass ' . $code . ' at ' . parse_url($url, PHP_URL_HOST)); continue; }
            $j = json_decode((string) $body, true);
            if (is_array($j['elements'] ?? null)) return $j['elements'];
        }
        return null;
    }

    /** Keeps what came back (named places with a point), replacing what was kept before. How many. */
    private static function keep(PDO $pdo, string $kind, array $els): int
    {
        $n = 0;
        $del = $pdo->prepare('DELETE FROM open_places WHERE osm_ref = ? AND kind = ?');
        $ins = $pdo->prepare('INSERT INTO open_places (osm_ref, kind, name, what, lat, lon, phone, website, hours, street, city, state, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        foreach ($els as $e) {
            $t = (array) ($e['tags'] ?? []);
            $name = trim((string) ($t['name'] ?? ''));
            $lat = $e['lat'] ?? ($e['center']['lat'] ?? null); $lon = $e['lon'] ?? ($e['center']['lon'] ?? null);
            if ($name === '' || $lat === null || $lon === null || !in_array($e['type'] ?? '', ['node', 'way', 'relation'], true)) continue;
            // never anything historic (a ruin, a memorial: where sacred or restricted sites could be), never a name that may mark
            // one; a business isn't an attraction or a natural feature (the outdoor kinds may be)
            $outdoor = in_array($kind, self::OUTDOOR, true);
            if (isset($t['historic']) || (($t['tourism'] ?? '') === 'attraction' && $kind !== 'todo') || (!$outdoor && isset($t['natural']))) continue;
            if (class_exists('Landmarks') || is_file(__DIR__ . '/Landmarks.php')) { require_once __DIR__ . '/Landmarks.php'; if (Landmarks::isProtected($name . ' ' . (string) ($t['description'] ?? ''))) continue; }
            $ref = $e['type'] . '/' . (int) $e['id'];
            $street = trim(trim((string) ($t['addr:housenumber'] ?? '')) . ' ' . trim((string) ($t['addr:street'] ?? '')));
            try {
                $del->execute([$ref, $kind]);
                $ins->execute([$ref, $kind, mb_substr($name, 0, 160), mb_substr(self::what($kind, $t), 0, 60), round((float) $lat, 6), round((float) $lon, 6),
                    mb_substr(trim((string) ($t['phone'] ?? $t['contact:phone'] ?? '')), 0, 40), mb_substr(trim((string) ($t['website'] ?? $t['contact:website'] ?? '')), 0, 255),
                    mb_substr(trim((string) ($t['opening_hours'] ?? '')), 0, 255), mb_substr($street, 0, 160), mb_substr(trim((string) ($t['addr:city'] ?? '')), 0, 80),
                    mb_substr(trim((string) ($t['addr:state'] ?? '')), 0, 20), date('Y-m-d H:i:s')]);
                $n++;
            } catch (Throwable $x) { error_log('open places keep: ' . $x->getMessage()); }
        }
        return $n;
    }

    /** Its kind in words: the cuisine for a place to eat ("Pizza", "Mexican"), else the kind's own name. */
    private static function what(string $kind, array $t): string
    {
        if (in_array($kind, ['food', 'pizza', 'coffee'], true) && !empty($t['cuisine'])) return ucfirst(str_replace('_', ' ', explode(';', (string) $t['cuisine'])[0]));
        $map = ['restaurant' => 'Restaurant', 'fast_food' => 'Fast food', 'cafe' => 'Café', 'hotel' => 'Hotel', 'motel' => 'Motel', 'guest_house' => 'Guest house',
                'hostel' => 'Hostel', 'supermarket' => 'Supermarket', 'convenience' => 'Convenience store', 'tyres' => 'Tires', 'car_repair' => 'Auto repair',
                'doctors' => 'Doctor', 'clinic' => 'Clinic', 'dry_cleaning' => 'Dry cleaning',
                'trailhead' => 'Trailhead', 'nature_reserve' => 'Nature preserve', 'park' => 'Park', 'viewpoint' => 'Viewpoint', 'camp_site' => 'Campground', 'caravan_site' => 'RV park',
                'fuel' => 'Gas', 'pharmacy' => 'Pharmacy', 'supermarket' => 'Grocery', 'grocery' => 'Grocery',
                'museum' => 'Museum', 'gallery' => 'Gallery', 'zoo' => 'Zoo', 'aquarium' => 'Aquarium', 'theme_park' => 'Theme park', 'attraction' => 'Attraction', 'garden' => 'Garden', 'water_park' => 'Water park', 'theatre' => 'Theatre', 'arts_centre' => 'Arts centre',
                'playground' => 'Playground', 'miniature_golf' => 'Mini golf', 'trampoline_park' => 'Trampoline park', 'amusement_arcade' => 'Arcade', 'ice_rink' => 'Ice rink',
                'library' => 'Library', 'ice_cream' => 'Ice cream', 'dog_park' => 'Dog park'];
        foreach (['amenity', 'tourism', 'shop', 'highway', 'leisure'] as $k) if (isset($t[$k], $map[$t[$k]])) return $map[$t[$k]];
        return self::KINDS[$kind][0];
    }
}
