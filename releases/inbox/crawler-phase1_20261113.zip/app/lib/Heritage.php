<?php
// app/lib/Heritage.php — the heritage pipeline (decisions/0133 Phases 1-5): the crawler worker searches the Library of
// Congress for each guide's place (catalog records and links only, under the source register's rules); the place's
// passages about its past (from those records, the crawler's dossier and the research brief) are cut to what matters and
// read by the cheapest model (Haiku) into facts with a fixed shape; each fact is vetted (a primary record or two
// independent sources), tiered under the jurisdiction register (an archaeological, sacred or burial place: its story,
// never the way in, and nothing at all until the law of the place is reviewed or on a nation's land until it says), and
// anchored to where it can be stood on today. The Seeker searches the catalog; guides write their "Walking in the
// footsteps" chapter from it.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Jurisdictions.php';   // extractTick needs it too (it stopped every hour without it, 2026-11-10)

final class Heritage
{
    public const KINDS = ['turning_point' => 'Turning point', 'person' => 'People and families', 'trade' => 'Trades and industries', 'material' => 'Building and native materials',
        'water' => 'Water', 'land' => 'Land and landforms', 'hardship' => 'Hardships', 'lore' => 'Local names and lore', 'site' => 'Sites to stand on today'];
    public const TIERS = ['public' => 'Public', 'story' => 'Story only (never the way in)', 'restricted' => 'Restricted (kept, never shown)'];
    /** Words that mark a passage about the past or the land (the keyword windows). */
    private const WINDOW = '/\b(founded|settl\w*|pioneer\w*|homestead\w*|ranch\w*|famil(y|ies)|mission\w*|church|parish|trade\w*|trail\w*|route\w*|railroad|mill\w*|mine\w*|mining|irrigat\w*|ditch\w*|acequia\w*|dam|river|spring\w*|well\w*|flood\w*|drought|adobe|stone|masonry|timber|brick|lumber|basalt|sandstone|built|war|raid\w*|fire|epidemic|hardship\w*|legend\w*|named after|known as|historic\w*|century|18\d\d|19\d\d|17\d\d|ancestral|pueblo\w*|nation|tribe\w*|people)\b/i';
    private const LOC_PRIMARY = '/newspaper|photo|print|drawing|map|manuscript|mixed material|film|sound recording|notated music/i';

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { foreach (['heritage_places', 'heritage_sources', 'heritage_facts'] as $t) $pdo->query("SELECT 1 FROM $t LIMIT 0"); return $ok = true; } catch (Throwable $e) { return $ok = false; }
    }

    // ---- Phase 1: the worker reads the Library of Congress -----------------------------------------------------------

    /** Places with a guide whose Library of Congress search is due (never, or a year ago): [{key, name, state, query}]. */
    public static function leaseLoc(PDO $pdo, int $limit): array
    {
        if (!self::ready($pdo)) return [];
        require_once __DIR__ . '/Guides.php';
        $rows = $pdo->query("SELECT g.place_key FROM place_guides g LEFT JOIN heritage_places h ON h.place_key = g.place_key
                              WHERE g.place_key NOT LIKE 'hub:%' AND (h.loc_at IS NULL OR h.loc_at < NOW() - INTERVAL 365 DAY) AND (h.loc_leased IS NULL OR h.loc_leased < NOW() - INTERVAL 2 HOUR)
                              ORDER BY h.loc_at IS NOT NULL, g.draft_status <> 'gathering', h.loc_at LIMIT " . max(1, min(5, $limit)))->fetchAll(PDO::FETCH_COLUMN);
        $out = [];
        foreach ($rows as $key) {
            $p = Guides::place($pdo, (string) $key); if (!$p) continue;
            require_once __DIR__ . '/Jurisdictions.php';
            if (!Jurisdictions::regionOpen($pdo, (string) ($p['state'] ?? ''))) {   // a closed region's history waits until it opens: asked again in a week
                $pdo->prepare('INSERT INTO heritage_places (place_key, loc_leased) VALUES (?, NOW() + INTERVAL 7 DAY) ON DUPLICATE KEY UPDATE loc_leased = NOW() + INTERVAL 7 DAY')->execute([$key]);
                continue;
            }
            $pdo->prepare('INSERT INTO heritage_places (place_key, loc_leased) VALUES (?, NOW()) ON DUPLICATE KEY UPDATE loc_leased = NOW()')->execute([$key]);
            $st = Jurisdictions::STATES[strtoupper((string) ($p['state'] ?? ''))] ?? '';
            $out[] = ['key' => (string) $key, 'name' => (string) $p['name'], 'state' => $st, 'query' => trim($p['name'] . ' ' . $st)];
        }
        return $out;
    }

    /** What the worker found: [{url, title, date, about, rights, format}]. Library of Congress pages only; their catalog record and link, never the item. */
    public static function completeLoc(PDO $pdo, string $key, array $items): int
    {
        if (!self::ready($pdo)) return 0;
        $n = 0;
        foreach (array_slice($items, 0, 60) as $it) {
            $url = (string) ($it['url'] ?? '');
            if (!preg_match('#^https://(www\.)?loc\.gov/(item|resource|pictures/item)/#i', $url)) continue;
            $clip = fn ($v, $max) => mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags(is_array($v) ? implode('; ', array_map('strval', $v)) : (string) $v))), 0, $max);
            $news = ($it['kind'] ?? '') === 'news';   // a page of a historic newspaper (Chronicling America): its text, not only its record
            $pdo->prepare('INSERT INTO heritage_sources (place_key, kind, url, title, date_text, about, rights, primary_record) VALUES (?, ' . ($news ? '\'news\'' : '\'loc\'') . ', ?, ?, ?, ?, ?, ?)
                           ON DUPLICATE KEY UPDATE title = VALUES(title), date_text = VALUES(date_text), about = VALUES(about), rights = VALUES(rights), fetched_at = NOW()')
                ->execute([$key, mb_substr($url, 0, 500), $clip($it['title'] ?? '', 500), $clip($it['date'] ?? '', 40), $clip($it['about'] ?? '', $news ? 3000 : 800), $clip($it['rights'] ?? '', 500),
                           preg_match(self::LOC_PRIMARY, (string) (is_array($it['format'] ?? '') ? implode(' ', $it['format']) : ($it['format'] ?? ''))) ? 1 : 0]);
            $n++;
        }
        $pdo->prepare('INSERT INTO heritage_places (place_key, loc_at, loc_items) VALUES (?, NOW(), ?) ON DUPLICATE KEY UPDATE loc_at = NOW(), loc_leased = NULL, loc_items = VALUES(loc_items)')->execute([$key, $n]);
        if ($n) { require_once __DIR__ . '/Guides.php'; Guides::due($pdo, $key, 'new historic records were found'); }   // a source we read changed
        return $n;
    }

    // ---- Phases 2-3: extraction (Haiku) and vetting --------------------------------------------------------------------

    /**
     * Draws facts for the next place whose sources changed since they were last read (the heritage_tick job). The
     * passages are cut from its sources (keyword windows), each labeled with its source group, and read by the model set
     * for heritage_extract (Haiku). Returns a line saying what it did.
     */
    public static function extractTick(PDO $pdo, int $n = 1): string
    {
        if (!self::ready($pdo)) return 'not set up';
        require_once __DIR__ . '/AiClient.php';
        require_once __DIR__ . '/Guides.php';
        $done = [];
        $keys = $pdo->query("SELECT g.place_key FROM place_guides g LEFT JOIN heritage_places h ON h.place_key = g.place_key
                              WHERE g.place_key NOT LIKE 'hub:%' ORDER BY h.extracted_at IS NOT NULL, h.extracted_at LIMIT 40")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($keys as $key) {
            if (count($done) >= $n) break;
            [$ok, $why] = AiClient::allow($pdo, 'heritage_extract');
            if (!$ok) return $done ? implode('; ', $done) : 'waiting: ' . $why;
            $p = Guides::place($pdo, (string) $key); if (!$p) continue;
            if (!Jurisdictions::regionOpen($pdo, (string) ($p['state'] ?? ''))) {   // a closed region's history waits until it opens: asked again in a week
                $pdo->prepare('INSERT INTO heritage_places (place_key, loc_leased) VALUES (?, NOW() + INTERVAL 7 DAY) ON DUPLICATE KEY UPDATE loc_leased = NOW() + INTERVAL 7 DAY')->execute([$key]);
                continue;
            }
            [$passages, $groups] = self::passages($pdo, (string) $key);
            $hash = md5(json_encode($passages));
            $st = $pdo->prepare('SELECT extract_hash FROM heritage_places WHERE place_key = ?'); $st->execute([$key]);
            if (!$passages || $st->fetchColumn() === $hash) continue;   // nothing new to read
            $done[] = $p['name'] . ': ' . self::extract($pdo, $p, $passages, $groups, $hash);
        }
        return $done ? implode('; ', $done) : 'nothing new';
    }

    /**
     * Reads one place's passages into facts now, when they changed since last read (the guide job's gathering, before its
     * first guide is written). A line saying what it did, or '' when there was nothing new or the model can't run.
     */
    public static function extractPlace(PDO $pdo, string $key): string
    {
        if (!self::ready($pdo)) return '';
        require_once __DIR__ . '/AiClient.php';
        require_once __DIR__ . '/Guides.php';
        require_once __DIR__ . '/Jurisdictions.php';
        if (!AiClient::allow($pdo, 'heritage_extract')[0]) return '';
        $p = Guides::place($pdo, $key); if (!$p || !Jurisdictions::regionOpen($pdo, (string) ($p['state'] ?? ''))) return '';
        [$passages, $groups] = self::passages($pdo, $key);
        $hash = md5(json_encode($passages));
        $st = $pdo->prepare('SELECT extract_hash FROM heritage_places WHERE place_key = ?'); $st->execute([$key]);
        if (!$passages || $st->fetchColumn() === $hash) return '';
        return self::extract($pdo, $p, $passages, $groups, $hash);
    }

    /** What the free public records hold for a place, for the research brief to start from: text ('' when none) and how many. */
    public static function held(PDO $pdo, string $key, int $max = 9000): array
    {
        if (!self::ready($pdo)) return ['', 0];
        $st = $pdo->prepare("SELECT kind, title, date_text, about FROM heritage_sources WHERE place_key = ? ORDER BY kind = 'news' DESC, primary_record DESC, id LIMIT 40"); $st->execute([$key]);
        $out = ''; $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) {
            $line = '- ' . ($s['kind'] === 'news' ? 'Newspaper, ' : 'Library of Congress, ') . trim((string) $s['title']) . ($s['date_text'] !== '' ? ' (' . $s['date_text'] . ')' : '') . (trim((string) $s['about']) !== '' ? ': ' . mb_substr(trim((string) $s['about']), 0, $s['kind'] === 'news' ? 900 : 300) : '');
            if (mb_strlen($out) + mb_strlen($line) > $max) break;
            $out .= $line . "\n"; $n++;
        }
        return [trim($out), $n];
    }

    /** The place's passages about its past: [[label => text], [label => [url, host, primary]]]. */
    public static function passages(PDO $pdo, string $key): array
    {
        $texts = []; $groups = [];
        $d = null;
        try { $st = $pdo->prepare('SELECT body, sources, research, research_sources FROM place_dossiers WHERE place_key = ?'); $st->execute([$key]); $d = $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable $e) {}
        $win = function (string $t, int $max): string {   // keep the sentences that carry the past or the land, in order
            $out = '';
            foreach (preg_split('/(?<=[.!?])\s+|\n+/u', $t) as $s) { $s = trim($s); if ($s !== '' && preg_match(self::WINDOW, $s)) { $out .= $s . ' '; if (mb_strlen($out) > $max) break; } }
            return trim($out);
        };
        if ($d && trim((string) $d['body']) !== '') {
            $src = array_values(array_filter(array_map('strval', (array) (json_decode((string) $d['sources'], true) ?: []))));
            // the dossier mixes Wikipedia, Wikidata and the official site: one independent source, never a primary record on its own
            $t = $win((string) $d['body'], 6000); if ($t !== '') { $texts['D'] = $t; $groups['D'] = [$src[0] ?? '', 'dossier', false]; }
        }
        if ($d && trim((string) ($d['research'] ?? '')) !== '') {
            $t = $win((string) $d['research'], 9000); if ($t !== '') { $texts['R'] = $t; $groups['R'] = ['', 'research brief', false]; }
        }
        $st = $pdo->prepare("SELECT url, title, date_text, about, primary_record FROM heritage_sources WHERE place_key = ? ORDER BY primary_record DESC, id LIMIT 25"); $st->execute([$key]);
        $i = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) {
            $i++; $label = 'L' . $i;
            $texts[$label] = trim($s['title'] . ($s['date_text'] !== '' ? ' (' . $s['date_text'] . ')' : '') . '. ' . $s['about']);
            $groups[$label] = [(string) $s['url'], 'loc.gov', (bool) $s['primary_record']];
        }
        return [$texts, $groups];
    }

    /** One place read into facts, vetted and tiered. */
    public static function extract(PDO $pdo, array $p, array $passages, array $groups, string $hash): string
    {
        require_once __DIR__ . '/AiClient.php';
        require_once __DIR__ . '/Jurisdictions.php';
        require_once __DIR__ . '/Landmarks.php';
        require_once __DIR__ . '/Topics.php';
        $fc = AiClient::feature($pdo, 'heritage_extract');
        $txt = ''; foreach ($passages as $label => $t) $txt .= '[' . $label . '] ' . mb_substr($t, 0, 9000) . "\n\n";
        $prompt = 'From these passages about ' . $p['name'] . ($p['state'] ? ', ' . $p['state'] : '') . ", list the facts about its past and its land. Each fact: one or two sentences in your own words (never copy), "
            . "its kind (" . implode(', ', array_keys(self::KINDS)) . "), a short title, the years it covers if stated, the place a visitor can stand on today where it happened or can be seen (a building, a church, a cemetery open to the public, a river crossing, a street; empty if none), "
            . "and the labels of the passages that say it, and the topics it is about (up to four: named people of public or historical note, rivers and landforms, trades, practices, institutions, events, routes; each with its kind: " . implode(', ', array_keys(Topics::KINDS)) . "). Only what the passages say; no outside knowledge. People: public or historical figures only, never a private person living in the last 100 years. "
            . "Never give the location of a sacred, burial, ceremonial or archaeological site; you may say such a place exists and its story.\n\n" . $txt;
        $schema = ['type' => 'object', 'additionalProperties' => false, 'required' => ['facts'], 'properties' => ['facts' => ['type' => 'array', 'items' => ['type' => 'object', 'additionalProperties' => false,
            'required' => ['kind', 'title', 'fact', 'year_from', 'year_to', 'footprint', 'sources', 'topics'],
            'properties' => ['kind' => ['type' => 'string', 'enum' => array_keys(self::KINDS)], 'title' => ['type' => 'string'], 'fact' => ['type' => 'string'],
                             'year_from' => ['type' => 'integer'], 'year_to' => ['type' => 'integer'], 'footprint' => ['type' => 'string'], 'sources' => ['type' => 'array', 'items' => ['type' => 'string']],
                             'topics' => ['type' => 'array', 'items' => ['type' => 'object', 'additionalProperties' => false, 'required' => ['name', 'kind'], 'properties' => ['name' => ['type' => 'string'], 'kind' => ['type' => 'string', 'enum' => array_keys(Topics::KINDS)]]]]]]]]];
        try {
            $r = AiClient::claudeAsk(mb_substr($prompt, 0, 40000), $schema, $fc['model'], 0, 8000, 'low');
            AiClient::record($pdo, 'heritage_extract', 0, 'done', $r);
        } catch (Throwable $x) { error_log('heritage ' . $p['key'] . ': ' . $x->getMessage()); return 'not read (' . $x->getMessage() . ')'; }
        $nation = null;
        $made = 0; $vetted = 0;
        foreach (array_slice((array) ($r['data']['facts'] ?? []), 0, 60) as $f) {
            $fact = mb_substr(trim((string) ($f['fact'] ?? '')), 0, 1200); $title = mb_substr(trim((string) ($f['title'] ?? '')), 0, 190);
            $kind = isset(self::KINDS[$f['kind'] ?? '']) ? (string) $f['kind'] : 'lore';
            if ($fact === '' || $title === '') continue;
            $labels = array_values(array_intersect(array_map('strval', (array) ($f['sources'] ?? [])), array_keys($groups)));
            if (!$labels) continue;   // a fact no passage supports is dropped
            $src = []; $hosts = []; $primary = false;
            foreach ($labels as $l) {
                [$url, $host, $pr] = $groups[$l]; $src[] = ['url' => $url, 'host' => $host, 'primary' => $pr]; $primary = $primary || $pr;
                if ($l !== 'R') $hosts[$l[0] === 'L' ? 'loc:' . $url : $host] = true;   // the research brief is our own synthesis: it never counts as a source
            }
            $src = self::stamp($pdo, $src);   // each source carries its rules (the source register)
            $foot = mb_substr(trim((string) ($f['footprint'] ?? '')), 0, 190);
            $sensitive = Landmarks::isProtected($title . ' ' . $fact . ' ' . $foot);   // a town's public cemetery is public (the three levels)
            [$lat, $lon] = self::footprintPoint($pdo, $p, $foot);
            $nid = null;
            if ($lat !== null) { try { require_once __DIR__ . '/Nations.php'; $shape = Nations::at($pdo, (float) $lat, (float) $lon); $n = $shape ? Nations::byShape($pdo, $shape) : null; $nid = $n ? (int) $n['id'] : null; } catch (Throwable $e) {} }
            $tier = Jurisdictions::tier($pdo, $sensitive, (string) ($p['state'] ?? ''), $nid);
            if ($tier !== 'public') { $lat = null; $lon = null; }   // a protected place is never pinned
            $status = ($primary || count($hosts) >= 2) && self::supplies($src) ? 'cataloged' : 'pending';   // a source that may only confirm never supplies a fact on its own
            $y = fn ($v) => ($v = (int) $v) >= 500 && $v <= (int) date('Y') ? $v : null;
            $pdo->prepare('INSERT INTO heritage_facts (place_key, kind, title, fact, year_from, year_to, footprint, lat, lon, sources, n_sources, primary_record, is_sensitive, tier, status, hash)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                           ON DUPLICATE KEY UPDATE sources = VALUES(sources), n_sources = VALUES(n_sources), primary_record = VALUES(primary_record), tier = IF(status = \'held\', tier, VALUES(tier)), status = IF(status = \'held\', \'held\', VALUES(status)), footprint = VALUES(footprint), lat = VALUES(lat), lon = VALUES(lon)')
                ->execute([$p['key'], $kind, $title, $fact, $y($f['year_from'] ?? 0), $y($f['year_to'] ?? 0), $foot, $lat, $lon, json_encode($src, JSON_UNESCAPED_SLASHES), count($hosts), $primary ? 1 : 0, $sensitive ? 1 : 0, $tier, $status, md5(mb_strtolower($title . '|' . $fact))]);
            $made++; if ($status === 'cataloged') $vetted++;
            if (Topics::ready($pdo)) {   // the Topic index (decisions/0133): the fact files under its place and the topics it names
                $fid = $pdo->prepare('SELECT id FROM heritage_facts WHERE place_key = ? AND hash = ?'); $fid->execute([$p['key'], md5(mb_strtolower($title . '|' . $fact))]);
                try { Topics::attach($pdo, (int) $fid->fetchColumn(), (array) ($f['topics'] ?? []), (string) $p['key'], (string) $p['name']); } catch (Throwable $x) { error_log('topics ' . $p['key'] . ': ' . $x->getMessage()); }
            }
        }
        $pdo->prepare('INSERT INTO heritage_places (place_key, extracted_at, extract_hash) VALUES (?, NOW(), ?) ON DUPLICATE KEY UPDATE extracted_at = NOW(), extract_hash = VALUES(extract_hash)')->execute([$p['key'], $hash]);
        return $made . ' facts, ' . $vetted . ' vetted';
    }

    /** Where a footprint is: a landmark we show near the place by that name, else a listing; [lat, lon] or [null, null]. */
    private static function footprintPoint(PDO $pdo, array $p, string $foot): array
    {
        if ($foot === '' || empty($p['lat'])) return [null, null];
        $box = [(float) $p['lat'] - .3, (float) $p['lat'] + .3, (float) $p['lon'] - .3, (float) $p['lon'] + .3];
        try {
            require_once __DIR__ . '/Landmarks.php';
            $st = $pdo->prepare('SELECT lat, lon FROM landmarks WHERE ' . Landmarks::visibleSql() . ' AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? AND (name = ? OR ? LIKE CONCAT(\'%\', name, \'%\')) LIMIT 1');
            $st->execute([$box[0], $box[1], $box[2], $box[3], $foot, $foot]);
            if ($r = $st->fetch(PDO::FETCH_ASSOC)) return [(float) $r['lat'], (float) $r['lon']];
            $st = $pdo->prepare('SELECT latitude, longitude FROM entities WHERE is_suppressed = 0 AND latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ? AND name = ? LIMIT 1');
            $st->execute([$box[0], $box[1], $box[2], $box[3], $foot]);
            if ($r = $st->fetch(PDO::FETCH_NUM)) return [(float) $r[0], (float) $r[1]];
        } catch (Throwable $e) {}
        return [null, null];
    }

    // ---- the source register on each fact (decisions/0133: the licence travels with the fact) -------------------------

    /** Each source with its rules stamped: rule (Sources::USES), licence and credit line. The research brief is our own. */
    public static function stamp(PDO $pdo, array $src): array
    {
        require_once __DIR__ . '/crawler/Sources.php';
        foreach ($src as &$s) {
            if (($s['host'] ?? '') === 'research brief' || (string) ($s['url'] ?? '') === '') { $s['rule'] = 'own'; $s['licence'] = ''; $s['credit'] = ''; continue; }
            $host = Sources::host((string) $s['url']);
            $r = Sources::rules($pdo, $host);
            $s['rule'] = (string) $r['use_rule']; $s['licence'] = (string) $r['licence']; $s['credit'] = $r['use_rule'] === 'credit' ? (string) ($r['credit_line'] ?? '') : '';
        }
        unset($s);
        return $src;
    }

    /** Does a source whose rules let us keep and show what it says back the fact (not only confirm it)? */
    public static function supplies(array $src): bool
    {
        foreach ($src as $s) if (in_array($s['rule'] ?? 'facts', ['facts', 'credit'], true)) return true;   // unstamped (older) facts: as before
        return false;
    }

    /** The credit lines a fact's sources ask for, e.g. "Library of Congress". */
    public static function credits($sources): array
    {
        $src = is_array($sources) ? $sources : (json_decode((string) $sources, true) ?: []);
        return array_values(array_unique(array_filter(array_map(fn ($s) => trim((string) ($s['credit'] ?? '')), $src))));
    }

    /** The credit lines for what a place's guide may tell (its "Walking in the footsteps" chapter). */
    public static function creditsFor(PDO $pdo, string $key): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT sources FROM heritage_facts WHERE place_key = ? AND status = 'cataloged' AND tier IN ('public', 'story')"); $st->execute([$key]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $s) $out = array_merge($out, self::credits((string) $s));
        return array_values(array_unique($out));
    }

    /**
     * Stamps the rules on facts stored before they carried them, or again after a person changed a source's rules ($host).
     * A cataloged fact none of whose sources may supply it goes back to pending (kept, not shown); a pending one that now
     * has a supplying source and was vetted (a primary record or two independent sources) is cataloged. Returns how many changed.
     */
    public static function restamp(PDO $pdo, string $host = '', int $limit = 200): int
    {
        if (!self::ready($pdo)) return 0;
        if ($host !== '') { $st = $pdo->prepare('SELECT id, sources, status, primary_record, n_sources FROM heritage_facts WHERE sources LIKE ? LIMIT 2000'); $st->execute(['%' . $host . '%']); }
        else $st = $pdo->query("SELECT id, sources, status, primary_record, n_sources FROM heritage_facts WHERE sources NOT LIKE '%\"rule\"%' LIMIT " . max(1, min(1000, $limit)));
        $n = 0;
        $up = $pdo->prepare('UPDATE heritage_facts SET sources = ?, status = ? WHERE id = ?');
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) {
            $src = self::stamp($pdo, (array) (json_decode((string) $f['sources'], true) ?: []));
            $status = (string) $f['status'];
            if ($status === 'cataloged' && !self::supplies($src)) $status = 'pending';
            elseif ($status === 'pending' && self::supplies($src) && ((int) $f['primary_record'] || (int) $f['n_sources'] >= 2)) $status = 'cataloged';   // 'held' (a takedown) is never touched
            $up->execute([json_encode($src, JSON_UNESCAPED_SLASHES), $status, (int) $f['id']]);
            $n++;
        }
        return $n;
    }

    /**
     * Facts tiered before the protected-place check knew the nations' peoples (review A2, 2026-11-13): a "Hopi cemetery"
     * read as a town's and was marked public, with its map point. Each fact marked not sensitive is read again, a batch at a
     * time from where the last stopped; one now protected is tiered again by the law of its place, and its point dropped
     * unless it stays public. 'held' (a takedown) is never touched. Returns how many were re-tiered.
     */
    public static function retier(PDO $pdo, int $limit = 500): int
    {
        if (!self::ready($pdo)) return 0;
        require_once __DIR__ . '/Landmarks.php'; require_once __DIR__ . '/Guides.php'; require_once __DIR__ . '/SearchIndex.php';
        Landmarks::loadPeoples($pdo);
        $after = (int) SearchIndex::state($pdo, 'heritage_retier_at');
        $st = $pdo->prepare("SELECT id, place_key, title, fact, footprint, lat, lon FROM heritage_facts WHERE id > ? AND is_sensitive = 0 AND status <> 'held' ORDER BY id LIMIT " . max(1, min(2000, $limit)));
        $st->execute([$after]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) return 0;   // done: every fact read once with the peoples known (new ones are tiered right as they're made)
        $up = $pdo->prepare('UPDATE heritage_facts SET is_sensitive = 1, tier = ?, lat = ?, lon = ? WHERE id = ? AND status <> \'held\'');
        $n = 0; $places = [];
        foreach ($rows as $f) {
            $after = (int) $f['id'];
            if (!Landmarks::isProtected($f['title'] . ' ' . $f['fact'] . ' ' . $f['footprint'])) continue;
            $places[$f['place_key']] ??= Guides::place($pdo, (string) $f['place_key']) ?: [];
            $nid = null;
            if ($f['lat'] !== null && $f['lon'] !== null) { try { require_once __DIR__ . '/Nations.php'; $shape = Nations::at($pdo, (float) $f['lat'], (float) $f['lon']); $nn = $shape ? Nations::byShape($pdo, $shape) : null; $nid = $nn ? (int) $nn['id'] : null; } catch (Throwable $e) {} }
            $tier = Jurisdictions::tier($pdo, true, (string) ($places[$f['place_key']]['state'] ?? ''), $nid);
            $up->execute([$tier, $tier === 'public' ? $f['lat'] : null, $tier === 'public' ? $f['lon'] : null, (int) $f['id']]);
            $n++;
        }
        SearchIndex::setState($pdo, 'heritage_retier_at', (string) $after);
        return $n;
    }

    // ---- Phases 4-5: the catalog, the Seeker and the guide's chapter ---------------------------------------------------

    /** The vetted facts a guide may write from, as text for its writer: public ones with where to stand; story-only ones flagged. */
    public static function forGuide(PDO $pdo, string $key): string
    {
        if (!self::ready($pdo)) return '';
        $st = $pdo->prepare("SELECT kind, title, fact, year_from, year_to, footprint, tier FROM heritage_facts WHERE place_key = ? AND status = 'cataloged' AND tier IN ('public', 'story') ORDER BY year_from IS NULL, year_from, id LIMIT 60");
        $st->execute([$key]);
        $out = '';
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) {
            $yr = $f['year_from'] ? ' (' . $f['year_from'] . ($f['year_to'] && $f['year_to'] !== $f['year_from'] ? '-' . $f['year_to'] : '') . ')' : '';
            $out .= '- ' . $f['title'] . $yr . ': ' . $f['fact'] . ($f['tier'] === 'story' ? ' [STORY ONLY: tell it, never say where it is or how to get there]' : ($f['footprint'] !== '' ? ' [stand here today: ' . $f['footprint'] . ']' : '')) . "\n";
        }
        return $out;
    }

    /**
     * A held landmark told as story only (decisions/0133): when a public source presents it to visitors, a person may let
     * its story be told, never its place. The landmark stays held (no page, no pin); its story enters the catalog as a
     * story-only fact for the nearest guide place. Never on a nation's land (the nation decides), and only where the law of
     * the place is reviewed (the strictest rule until then). Returns the guide place it went to.
     */
    public static function storyOnly(PDO $pdo, int $uid, int $gnisId, string $evidence, string $story): string
    {
        require_once __DIR__ . '/Jurisdictions.php';
        require_once __DIR__ . '/Guides.php';
        $st = $pdo->prepare('SELECT * FROM landmarks WHERE gnis_id = ?'); $st->execute([$gnisId]);
        $r = $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('That landmark isn\'t here.');
        if ($r['status'] !== 'waiting') throw new InvalidArgumentException('Only a held place is told as story only; this one is ' . $r['status'] . '.');
        if (trim((string) $r['nation']) !== '') throw new InvalidArgumentException('It\'s on ' . $r['nation'] . '\'s land: the nation decides what is told, and nothing is until it says.');
        if (!preg_match('#^https?://\S+$#i', trim($evidence))) throw new InvalidArgumentException('Add the link to the public source that presents it to visitors.');
        if (Jurisdictions::tier($pdo, true, (string) $r['state']) !== 'story') throw new InvalidArgumentException('The law of the place isn\'t reviewed yet (System Configuration → Jurisdictions), so the strictest rule applies: nothing about it is told.');
        $story = mb_substr(trim(strip_tags($story)), 0, 1200);
        if (mb_strlen($story) < 30) throw new InvalidArgumentException('Write its story in a sentence or two, in our own words, with no directions.');
        require_once __DIR__ . '/Guides.php';
        if (preg_match(Guides::WAY_IN, $story) && !preg_match(Guides::PUBLIC_ACCESS, $story)) throw new InvalidArgumentException('Take out the directions or distances: a story-only place is told, never the way in.');
        $best = ''; $bd = INF;   // the nearest guide's place
        foreach ($pdo->query("SELECT place_key FROM place_guides WHERE place_key NOT LIKE 'hub:%'")->fetchAll(PDO::FETCH_COLUMN) as $k) {
            $p = Guides::place($pdo, (string) $k);
            if (!$p || $p['lat'] === null) continue;
            $d = abs((float) $p['lat'] - (float) $r['lat']) + abs((float) $p['lon'] - (float) $r['lon']);
            if ($d < $bd) { $bd = $d; $best = (string) $k; }
        }
        if ($best === '' || $bd > 1.5) throw new InvalidArgumentException('There\'s no guide near it yet to tell its story in.');
        $title = mb_substr((string) $r['name'], 0, 190);
        $pdo->prepare("INSERT INTO heritage_facts (place_key, kind, title, fact, footprint, sources, n_sources, primary_record, is_sensitive, tier, status, hash)
                       VALUES (?, 'site', ?, ?, '', ?, 1, 0, 1, 'story', 'cataloged', ?) ON DUPLICATE KEY UPDATE fact = VALUES(fact), sources = VALUES(sources), tier = IF(status = 'held', tier, 'story'), status = IF(status = 'held', 'held', 'cataloged')")
            ->execute([$best, $title, $story, json_encode([['url' => trim($evidence), 'host' => (string) parse_url(trim($evidence), PHP_URL_HOST), 'primary' => false, 'by' => $uid]], JSON_UNESCAPED_SLASHES), md5('landmark:' . $gnisId)]);
        $pdo->prepare('UPDATE landmarks SET review_note = ? WHERE gnis_id = ?')->execute([mb_substr('Story only (told without its place), from ' . trim($evidence), 0, 300), $gnisId]);
        return $best;
    }

    /** When a place's catalog last gained a vetted fact (for the monthly guide check), or ''. */
    public static function lastVetted(PDO $pdo, string $key): string
    {
        if (!self::ready($pdo)) return '';
        $st = $pdo->prepare("SELECT MAX(created_at) FROM heritage_facts WHERE place_key = ? AND status = 'cataloged'"); $st->execute([$key]);
        return (string) $st->fetchColumn();
    }

    /**
     * For search's results (decisions/0133): vetted facts we may show whose title, fact or place to stand holds every word.
     * A story-only fact comes without its place. [{label, sub, url}] for a "From our guides" group.
     */
    public static function searchPublic(PDO $pdo, string $text, int $limit = 4): array
    {
        if (!self::ready($pdo)) return [];
        $ws = array_values(array_filter(preg_split('/\s+/', mb_strtolower(trim($text))), fn ($w) => mb_strlen($w) >= 3));
        if (!$ws) return [];
        $w = []; $a = [];
        foreach (array_slice($ws, 0, 5) as $t) { $w[] = '(f.title LIKE ? OR f.fact LIKE ? OR (f.tier = \'public\' AND f.footprint LIKE ?))'; array_push($a, "%$t%", "%$t%", "%$t%"); }
        $st = $pdo->prepare("SELECT f.* FROM heritage_facts f WHERE f.status = 'cataloged' AND f.tier IN ('public', 'story') AND " . implode(' AND ', $w) . ' ORDER BY f.year_from IS NULL, f.year_from LIMIT ' . max(1, min(12, $limit)));
        $st->execute($a);
        require_once __DIR__ . '/Guides.php';
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) {
            $p = Guides::place($pdo, (string) $f['place_key']);
            $cr = self::credits((string) $f['sources']);
            $out[] = ['label' => (string) $f['title'], 'sub' => trim(($p['name'] ?? '') . ($f['year_from'] ? ' · ' . $f['year_from'] : '') . ' · ' . ($f['tier'] === 'story' ? 'its story' : (self::KINDS[$f['kind']] ?? '')) . ($cr ? ' · ' . implode(', ', $cr) : ''), ' ·'),
                      'url' => !empty($p['url']) ? $p['url'] . '#g-footsteps' : '', 'id' => (int) $f['id']];
        }
        return array_values(array_filter($out, fn ($o) => $o['url'] !== ''));
    }

    /** The Seeker: facts by words, place and kind, vetted first. */
    public static function seek(PDO $pdo, string $q, string $place = '', string $kind = '', int $limit = 60): array
    {
        if (!self::ready($pdo)) return [];
        $w = []; $a = [];
        foreach (preg_split('/\s+/', trim($q)) as $t) if (mb_strlen($t) >= 3) { $w[] = '(f.title LIKE ? OR f.fact LIKE ? OR f.footprint LIKE ?)'; array_push($a, "%$t%", "%$t%", "%$t%"); }
        if ($place !== '') { $w[] = 'f.place_key = ?'; $a[] = $place; }
        if (isset(self::KINDS[$kind])) { $w[] = 'f.kind = ?'; $a[] = $kind; }
        $st = $pdo->prepare('SELECT f.* FROM heritage_facts f' . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . " ORDER BY f.status = 'cataloged' DESC, f.year_from IS NULL, f.year_from, f.id LIMIT " . max(1, min(200, $limit)));
        $st->execute($a);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Counts for the Seeker's header: [facts, vetted, places, loc items]. */
    public static function counts(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [0, 0, 0, 0];
        $r = $pdo->query("SELECT COUNT(*), SUM(status = 'cataloged'), COUNT(DISTINCT place_key) FROM heritage_facts")->fetch(PDO::FETCH_NUM);
        return [(int) $r[0], (int) $r[1], (int) $r[2], (int) $pdo->query('SELECT COUNT(*) FROM heritage_sources')->fetchColumn()];
    }
}
