<?php
// hub/build.php?city=Dana Point&state=CA&q=things to do — a guide built while you wait (decisions/0147 §1a). From a
// search for a place we have no guide for: the place is set up as one of our towns (real places only, from our
// gazetteer), then the page starts the build and checks in every few seconds, each check running the next step
// (/api/guide-build.php): places, journeys, a first look written by Claude, then on to the guide. Its guide already
// live: straight there. Never indexed; the build starts only from the page's own script, never from a link alone.
// Notify me when it's ready (Jason, 2026-11-10): a member by a notice and email, signed out by an email; and, while
// the page is open in another tab, the browser's own notice if they allow it (OnDemand::watch, notifyReady).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/OnDemand.php';

$pdo = Database::connection();
$key = null; $err = '';
try {
    if (!OnDemand::ready($pdo)) throw new RuntimeException('Guides on demand switch on within the hour of this update.');
    $key = OnDemand::townFor($pdo, (string) ($_GET['city'] ?? ''), (string) ($_GET['state'] ?? ''));
    if (!$key) throw new RuntimeException('We couldn\'t find that place. Try searching for it again with its state.');
} catch (PDOException $e) { error_log('hub/build: ' . $e->getMessage()); $err = 'Something went wrong. Try again in a moment.'; }   // never a database message to a visitor
catch (RuntimeException $e) { $err = $e->getMessage(); }
catch (Throwable $e) { error_log('hub/build: ' . $e->getMessage()); $err = 'Something went wrong. Try again in a moment.'; }
$p = $key ? Guides::place($pdo, $key) : null;
if ($p) {
    $g = Guides::get($pdo, $key);
    $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: [];
    if ($g['status'] === 'live' && empty($di['first_look'])) { header('Location: ' . $p['url'], true, 302); exit; }   // its guide is ready
}
$label = $p ? $p['name'] . ($p['state'] ? ', ' . $p['state'] : '') : '';
tv_page_start($p ? 'Building your guide to ' . $label : 'Guide', ['no_crumbs' => true, 'head' => '<meta name="robots" content="noindex,nofollow">']);
if (!$p): ?>
  <div class="text-center py-10"><h1 class="font-serif font-bold text-2xl mb-2">We can't build that guide</h1><p class="text-sm" data-tv-status="bad" data-tv-label="Why:"><?= tv_e($err) ?></p><p class="mt-3"><a class="underline" href="/discovery/">Back to Discovery</a></p></div>
<?php tv_page_end(); return; endif;
require_once __DIR__ . '/../../app/lib/Weather.php';
$wx = null; try { if ($p['lat'] !== null) $wx = Weather::stored($pdo, (float) $p['lat'], (float) $p['lon']); } catch (Throwable) {}
$wn = $wx['now'] ?? null;
?>
<style>
  .gb{max-width:40rem;margin:.8rem auto 0;display:flex;flex-direction:column;gap:.7rem}
  .gb-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem 1.1rem}
  .gb h1{font:700 1.45rem/1.25 Georgia,serif;color:#3E2B1F;margin:0 0 .3rem}
  .gb-sub{font-size:.9rem;color:#5C4632;margin:0}
  .gb-steps{list-style:none;margin:.7rem 0 0;padding:0;display:grid;gap:.35rem}
  .gb-steps li{display:flex;align-items:center;gap:.55rem;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem;padding:.45rem .65rem;font-size:.92rem;color:#8A7355}
  .gb-steps li i{flex:0 0 18px;height:18px;border-radius:999px;border:2px solid #CBB98D;display:inline-block}
  .gb-steps li.now{color:#3E2B1F;font-weight:700}.gb-steps li.now i{border-color:#B45309;border-top-color:transparent;animation:gb-spin 1s linear infinite}
  .gb-steps li.done{color:#3E2B1F}.gb-steps li.done i{border-color:#8FBCA8;background:#8FBCA8;box-shadow:0 0 0 3px rgba(143,188,168,.3)}
  .gb-steps li.waiting i{border-color:#B8863B;border-style:dashed}
  .gb-found{font-size:.85rem;color:#5C4632;margin:.5rem 0 0}
  .gb-btn{display:inline-flex;align-items:center;background:#B8863B;color:#2A1B12;font-weight:700;border-radius:.75rem;padding:.55rem 1.1rem;text-decoration:none}
  .gb-note{font-size:.8rem;color:#8A7355;margin:.4rem 0 0}
  .gb-ntf{margin:.8rem 0 0;padding-top:.7rem;border-top:1px solid #EADFC4;display:flex;flex-wrap:wrap;gap:.45rem;align-items:flex-end}
  .gb-ntf label{flex:1 1 13rem;display:grid;gap:.15rem;font-size:.86rem;font-weight:600;color:#5C4632}
  .gb-ntf input{font:inherit;font-weight:400;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem .65rem;background:#FFFBF2;width:100%;box-sizing:border-box}
  .gb-ntf button{background:#3E2B1F;color:#FFF8EA;border:0;border-radius:.75rem;padding:.55rem 1.1rem;font-weight:700;cursor:pointer}
  .gb-ntf p{flex:1 1 100%;margin:0;font-size:.8rem;color:#8A7355}
  @keyframes gb-spin{to{transform:rotate(360deg)}}
  @media (prefers-reduced-motion:reduce){.gb-steps li.now i{animation:none}}
  @media (max-width:767px){.gb{gap:3px}.gb-card{border-radius:.5rem;padding:.8rem .7rem}}
</style>
<div class="gb">
  <div class="gb-card tv-bleed">
    <h1>Building your guide to <?= tv_e($label) ?></h1>
    <p class="gb-sub">A first look in about two minutes, gathered from public sources and written by Claude, the AI we use. The full guide follows within a day or two. You can leave this page: it carries on, and it'll be here when you come back.</p>
    <?php if ($wn): ?><p class="gb-found">Right now in <?= tv_e($p['name']) ?>: <b><?= (int) $wn['temp_f'] ?>°</b>, <?= tv_e((string) $wn['text']) ?>.</p><?php endif; ?>
    <ol class="gb-steps" id="gb-steps" aria-live="polite">
      <?php foreach (OnDemand::STEPS as $k => [$doing]): ?><li data-k="<?= tv_e($k) ?>"><i aria-hidden="true"></i><span><?= tv_e($doing) ?></span></li><?php endforeach; ?>
    </ol>
    <p class="gb-found" id="gb-found" hidden></p>
    <p id="gb-say" hidden></p>
    <p style="margin:.7rem 0 0" id="gb-go" hidden><a class="gb-btn" href="<?= tv_e($p['url']) ?>">Open the guide</a></p>
    <?php $me = Auth::currentUserId(); ?>
    <form class="gb-ntf" id="gb-ntf" novalidate>
      <?php if ($me): ?><button type="submit">Notify me when it's ready</button><p>In your Pulse and by email, once.</p>
      <?php else: ?><label>Email me when it's ready<input type="email" name="email" autocomplete="email" maxlength="160" required></label><button type="submit">Notify me</button>
      <p>Once, to this address, which we don't keep after. <a class="underline" href="/login.php?next=<?= tv_e(rawurlencode((string) ($_SERVER['REQUEST_URI'] ?? '/'))) ?>">Sign in</a> to have it in your Pulse instead.</p><?php endif; ?>
    </form>
  </div>
  <p class="gb-note">Built from public sources: the town's own site, Wikipedia and Wikidata, OpenStreetMap, Recreation.gov and our own records. Every place it names is checked against them; a place that may be sacred or protected is never named. Something wrong once it's up? Tap <b>Suggest a change</b> on the guide.</p>
</div>
<script>
(function () {
  var KEY = <?= json_encode($key) ?>, Q = <?= json_encode(mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 120)) ?>, URL = <?= json_encode($p['url']) ?>;
  var API = '/api/guide-build.php', csrf = '', gone = false, tries = 0;
  var steps = document.getElementById('gb-steps'), say = document.getElementById('gb-say'), found = document.getElementById('gb-found'), go = document.getElementById('gb-go');
  function show(s) {
    (s.steps || []).forEach(function (st) {
      var li = steps.querySelector('li[data-k="' + st.key + '"]'); if (!li) return;
      li.className = st.state; li.querySelector('span').textContent = st.label;
    });
    var f = s.found || {}, bits = [];
    if (f.eat) bits.push(f.eat + ' places to eat'); if (f.stay) bits.push(f.stay + ' to stay'); if (f.outdoors) bits.push(f.outdoors + ' outdoor places'); if (f.landmarks) bits.push(f.landmarks + ' landmarks');
    if (bits.length) { found.hidden = false; found.textContent = 'Found so far: ' + bits.join(', ') + '.'; }
    if (s.note) { say.hidden = false; say.setAttribute('data-tv-status', s.status === 'failed' ? 'bad' : 'info'); say.setAttribute('data-tv-label', s.status === 'failed' ? 'Not yet:' : 'Note:'); say.textContent = s.note;
      // never a dead end: it retries by itself, the visitor can ask again now, or write to us
      if (s.status === 'failed') { say.appendChild(document.createTextNode(' Reload the page to try now, tap Notify me below to hear when it\'s ready, or write to us at ')); var m = document.createElement('a'); m.href = 'mailto:support@traversence.com?subject=' + encodeURIComponent('Guide to ' + (s.label || '')); m.className = 'underline'; m.textContent = 'support@traversence.com'; say.appendChild(m); say.appendChild(document.createTextNode('.')); } }
    if (s.ready) go.hidden = false;
  }
  // Notify me: asked once; the browser's own notice too, while this page is open in another tab, if they allow it
  var ntf = document.getElementById('gb-ntf'), local = false;
  ntf.addEventListener('submit', function (e) {
    e.preventDefault();
    var btn = ntf.querySelector('button'), em = ntf.querySelector('input[name=email]');
    if (em && !em.value.trim()) { TvAsk.say('Type your email, and we\'ll write once when it\'s ready.', { anchor: btn, bad: true }); em.focus(); return; }
    var body = { action: 'notify', place: KEY, email: em ? em.value.trim() : '' };
    TvAsk.busy(btn, true);
    fetch(API, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); }).then(function (s) {
        TvAsk.busy(btn, false);
        if (!s || !s.ok) { TvAsk.say((s && s.error && s.error.message) || 'That didn\'t go through. Try again.', { anchor: btn, bad: true }); return; }
        ntf.innerHTML = '<p data-tv-status="ok" data-tv-label="Done:"></p>'; ntf.querySelector('p').textContent = s.message;
        if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().then(function (p) { local = p === 'granted'; }, function () {});
        else local = 'Notification' in window && Notification.permission === 'granted';
      }, function () { TvAsk.busy(btn, false); TvAsk.say('That didn\'t reach us. Check your connection and try again.', { anchor: btn, bad: true }); });
  });
  function ready() {   // the browser's notice, when they asked and the page isn't in front of them
    if (!local || !document.hidden) return;
    try { var n = new Notification(<?= json_encode('Your guide to ' . $label . ' is ready') ?>, { body: 'Tap to open it.', icon: '/favicon.ico' }); n.onclick = function () { window.focus(); location.href = URL; }; } catch (e) {}
  }
  function check() {
    if (gone) return;
    fetch(API + '?run=1&place=' + encodeURIComponent(KEY), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (s) {
      tries = 0; show(s);
      if (s.live && s.status !== 'building') { gone = true; ready(); setTimeout(function () { location.href = URL; }, 1200); return; }   // the first look is up
      if (s.status === 'building') setTimeout(check, 1500);
      else if (s.status === 'queued') setTimeout(check, 60000);   // waiting for tomorrow's allowance: the page just checks now and then
    }).catch(function () { if (++tries < 40) setTimeout(check, 4000); });   // a long step can drop the connection: it runs on, so keep checking
  }
  fetch(API + '?place=' + encodeURIComponent(KEY), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (s) {
    csrf = s.csrf || '';
    var body = { action: 'start', place: KEY, q: Q };
    return fetch(API, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) });
  }).then(function (r) { return r.json(); }).then(function (s) {
    if (!s || !s.ok) { say.hidden = false; say.setAttribute('data-tv-status', 'bad'); say.setAttribute('data-tv-label', 'Error:'); say.textContent = (s && s.error && s.error.message) || 'That didn\'t start. Try again in a moment.'; return; }
    show(s); check();
  }).catch(function () { say.hidden = false; say.setAttribute('data-tv-status', 'bad'); say.setAttribute('data-tv-label', 'Error:'); say.textContent = 'That didn\'t start. Check your connection and reload.'; });
})();
</script>
<?php tv_page_end();
