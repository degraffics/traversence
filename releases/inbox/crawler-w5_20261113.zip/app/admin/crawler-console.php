<?php
// app/admin/crawler-console.php — Insights → Crawler: the crawler console (decisions/0160 §4; handoffs/crawler-revamp.md
// Phase 2; Jason, 2026-11-13: in Insights). Each workflow with its capture tasks: what each is waiting on, what the last
// runs did with it (done, nothing to do, not reached, failed and why), its share of each run, its spend this month; pause
// or resume a workflow, change its share, run a task first, switch a task off, put failed work back. Below, the last runs,
// task by task. Times show where they happened (each <time> is drawn in the viewer's zone by js/tv-time.js).
declare(strict_types=1);

function tv_admin_mod_crawler(PDO $pdo): string
{
    require_once __DIR__ . '/../lib/crawler/CrawlService.php';
    $e = 'tv_w_e';
    if (!CrawlService::ready($pdo)) return '<p data-tv-status="info" data-tv-label="Not ready:">The crawler service\'s database update hasn\'t run yet: it runs within the hour, or open System Configuration → Database updates. Until then, <a class="underline" href="/admin/crawler.php">the earlier overview</a> shows the crawler.</p>';
    [$can, $why] = Access::can('insights.crawler.edit', ['min' => 'staff', 'depts' => ['ops']]);
    $uid = (int) (Auth::currentUserId() ?? 0);
    $csrf = (string) ($_SESSION['csrf_token'] ?? ''); $msg = '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['cr_do']) && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        try {
            if (!$can) throw new RuntimeException($why);
            $wf = (string) ($_POST['wf'] ?? ''); $task = (string) ($_POST['task'] ?? '');
            switch ((string) $_POST['cr_do']) {
                case 'pause': CrawlService::pause($pdo, $wf, true, $uid, (string) ($_POST['why'] ?? '')); $say = $wf . ' is paused: the next runs leave its tasks alone.'; break;
                case 'resume': CrawlService::pause($pdo, $wf, false, $uid); $say = $wf . ' is running again from the next run.'; break;
                case 'share': CrawlService::setShare($pdo, $wf, (int) ($_POST['share'] ?? 0)); $say = $wf . '\'s share is saved: the next run plans with it.'; break;
                case 'first': CrawlService::runNext($pdo, $task); $say = 'It\'s due on the next run.'; break;
                case 'off': CrawlService::setTask($pdo, $task, false); $say = 'Switched off: no run takes it until it\'s switched on.'; break;
                case 'on': CrawlService::setTask($pdo, $task, true); $say = 'Switched on: it\'s planned from the next run.'; break;
                case 'retry': $n = CrawlService::retry($pdo, $task); $say = $n ? $n . ' put back in the queue, their tries reset.' : 'Nothing had failed.'; break;
                default: throw new RuntimeException('Unknown action.');
            }
            $msg = '<p data-tv-flash="ok">' . $e($say) . '</p>';
        } catch (Throwable $x) { $msg = '<p data-tv-flash="error">' . $e($x->getMessage()) . '</p>'; }
    }
    $at = fn (?string $t) => $t ? '<time datetime="' . $e(date('c', (int) strtotime($t))) . '" data-tv-time>' . $e(date('M j, g:i a', (int) strtotime($t))) . '</time>' : 'never';
    $usd = fn (float $v) => $v < 1 ? number_format($v * 100, 1) . '¢' : '$' . number_format($v, 2);
    $btn = function (string $do, string $label, array $hidden, string $confirm = '', bool $danger = false) use ($e, $can, $why, $csrf): string {
        $h = '<form method="post" style="display:inline">' . '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="cr_do" value="' . $e($do) . '">';
        foreach ($hidden as $k => $v) $h .= '<input type="hidden" name="' . $e($k) . '" value="' . $e((string) $v) . '">';
        $h .= '<button class="ak-b" type="submit"' . ($can ? '' : ' disabled title="' . $e($why) . '"') . ($confirm !== '' ? ' data-confirm="' . $e($confirm) . '" data-yes="' . $e($label) . '"' . ($danger ? ' data-danger' : '') : '') . '>' . $e($label) . '</button></form>';
        return $h;
    };

    $wfs = CrawlService::workflows($pdo); $tasks = CrawlService::tasks($pdo);
    $stats = CrawlService::taskStats($pdo, 24); $spend = CrawlService::spend($pdo);
    $runs = CrawlService::runs($pdo, 20);
    $h = '<p class="ak-note">The crawler is one service; each workflow asks it for what it needs through its capture tasks (decisions/0160). Every run, every 5 minutes on Railway, '
       . 'the site plans which tasks it works and gives each its share of the run: finding businesses first, then whoever waited longest. A task the run didn\'t reach is never a failure: it goes first next time. '
       . 'A run that couldn\'t work shows as failed on Railway, and in Pulse when runs keep failing.' . ($can ? '' : ' <b>' . $e($why) . '</b>') . '</p>' . $msg;

    // where it stands
    $st = CrawlService::stalled($pdo);
    $last = $runs[0] ?? null;
    if ($st) $h .= '<p data-tv-status="bad" data-tv-label="' . $e($st[1]) . ':">' . $e($st[2]) . '</p>';
    elseif (!$last) $h .= '<p data-tv-status="info" data-tv-label="No runs yet:">The worker hasn\'t run through the service yet. It does from its next deploy; until then it runs its old fixed order (<a class="underline" href="/admin/crawler.php">the earlier overview</a>).</p>';
    else $h .= '<p data-tv-status="' . (in_array($last['status'], ['ok', 'idle', 'partial'], true) ? 'ok' : ($last['status'] === 'running' ? 'info' : 'bad')) . '" data-tv-label="Last run:">'
        . $at((string) $last['started_at']) . ': ' . $e((string) $last['status']) . ($last['why'] ? ' (' . $e((string) $last['why']) . ')' : '') . '.</p>';

    // the day in numbers
    $day = ['ok' => 0, 'partial' => 0, 'idle' => 0, 'starved' => 0, 'failed' => 0, 'abandoned' => 0];
    foreach ($pdo->query("SELECT status, COUNT(*) n FROM crawl_runs WHERE started_at >= NOW() - INTERVAL 24 HOUR GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR) as $k => $v) $day[$k] = (int) $v;
    $nr = 0; foreach ($stats as $s) $nr += (int) ($s['not_reached'] ?? 0);
    $month = 0.0; foreach ($spend as $by) foreach ($by as $svc => [$u, $c]) $month += $svc === 'railway' ? 0 : $c;
    $rail = 0; foreach ($spend as $by) $rail += (int) ($by['railway'][0] ?? 0);
    $h .= '<div class="ak-metrics">';
    foreach ([['Runs, last 24 h', array_sum($day)], ['Worked', $day['ok'] + $day['partial']], ['Nothing to do', $day['idle']], ['Starved or failed', $day['starved'] + $day['failed'] + $day['abandoned']],
              ['Tasks not reached', $nr], ['Paid calls this month', $usd($month)], ['Railway time this month', round($rail / 3600, 1) . ' h']] as [$l, $v])
        $h .= '<div class="ak-metric tv-bleed"><b>' . $e((string) $v) . '</b><span>' . $e($l) . '</span></div>';
    $h .= '</div>';

    // what each task's own queue holds today
    $q = [];
    $one = function (string $sql) use ($pdo): array { try { return array_map('intval', $pdo->query($sql)->fetchAll(PDO::FETCH_KEY_PAIR)); } catch (Throwable $x) { return []; } };
    $q['coverage'] = $one("SELECT CONCAT('coverage ', status), COUNT(*) FROM " . Database::t('crawl_jobs') . " GROUP BY status") + $one("SELECT CONCAT('town ', status, IF(attempts >= 3, ' (3+ tries)', '')), COUNT(*) FROM town_crawl_jobs GROUP BY 1");
    $q['identity'] = $one("SELECT CONCAT(status, IF(attempts >= 3, ' (set aside)', '')), COUNT(*) FROM " . Database::t('identity_jobs') . " GROUP BY 1");
    $q['source'] = $one("SELECT status, COUNT(*) FROM " . Database::t('reference_sources') . " GROUP BY status");
    // W2's questions for a person (decisions/0160 W2): what its checks sent to Review and is still waiting
    $w2review = [];
    foreach ($one("SELECT CONCAT(device_hash, ' ', kind), COUNT(*) FROM suggestions WHERE status = 'new' AND device_hash IN ('crawler-refresh', 'crawler-dupes', 'system:google') GROUP BY 1") as $k => $n)
        $w2review[['crawler-refresh closed' => 'possibly closed', 'crawler-refresh fix' => 'changed details, moved or dead websites', 'crawler-dupes same' => 'live duplicates', 'system:google closed' => 'closed on Google'][$k] ?? $k] = $n;
    // W5's own queue (guides a visitor asked for, built on the site): where each stands, and the failed ones' tries
    $w5 = $one("SELECT CASE WHEN status = 'failed' AND tries > 3 THEN 'failed, waiting for our team' WHEN status = 'failed' THEN 'failed, tried again by itself' ELSE status END, COUNT(*) FROM guide_requests GROUP BY 1")
        ?: $one("SELECT status, COUNT(*) FROM guide_requests GROUP BY status");
    $req = []; foreach ($pdo->query("SELECT wf, status, COUNT(*) n FROM crawl_requests GROUP BY wf, status")->fetchAll(PDO::FETCH_ASSOC) as $r) $req[$r['wf']][$r['status']] = (int) $r['n'];
    $kv = fn (array $a) => $a ? implode(', ', array_map(fn ($k, $v) => $e((string) $k) . ' ' . (int) $v, array_keys($a), $a)) : '';
    $svcName = ['claude' => 'Claude', 'tavily' => 'Tavily search', 'brave' => 'Brave search', 'tavily_extract' => 'Tavily page reads', 'google_places' => 'Google Places', 'railway' => 'Railway'];

    foreach ($wfs as $wf => $w) {
        $mine = array_filter($tasks, fn ($t) => $t['wf'] === $wf);
        $sp = $spend[$wf] ?? [];
        if (!$mine && !$sp && !isset($req[$wf]) && !($wf === 'W5' && $w5)) continue;   // a workflow that doesn't use the crawler yet (W4, W5, W7, W13…) shows once it does
        $paused = (int) $w['paused'] === 1;
        $body = '';
        if ($paused) $body .= '<p data-tv-status="info" data-tv-label="Paused:">Since ' . $at((string) $w['paused_at']) . ($w['paused_why'] ? ': ' . $e((string) $w['paused_why']) : '') . '. Its work waits, untouched.</p>';
        $body .= '<p class="ak-note">' . ($paused ? $btn('resume', 'Resume', ['wf' => $wf]) : $btn('pause', 'Pause', ['wf' => $wf], 'Pause ' . $w['name'] . '? Its tasks are left alone until it\'s resumed.', true))
               . ' <form method="post" style="display:inline"><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="cr_do" value="share"><input type="hidden" name="wf" value="' . $e($wf) . '">'
               . '<label>Share of each run <input class="ak-in" type="number" name="share" min="0" max="100" value="' . (int) $w['share_pct'] . '" style="width:4.5rem"' . ($can ? '' : ' disabled title="' . $e($why) . '"') . '>%</label> '
               . '<button class="ak-b" type="submit"' . ($can ? '' : ' disabled title="' . $e($why) . '"') . '>Save share</button></form></p>';
        if ($sp) $body .= '<p class="ak-note">This month: ' . implode(' · ', array_map(fn ($svc, $v) => $e($svcName[$svc] ?? $svc) . ' ' . ($svc === 'claude' ? (int) $v[0] . ' call' . ($v[0] === 1 ? '' : 's') . ', ' : number_format((int) $v[0]) . ', ') . $usd((float) $v[1]), array_keys($sp), $sp)) . ' (failed calls included; prices beyond Claude\'s are estimates).</p>';
        if (isset($req[$wf])) $body .= '<p class="ak-note">Requests to the crawler: ' . $kv($req[$wf]) . '.</p>';
        if ($wf === 'W5' && $w5) $body .= '<p class="ak-note">Guides visitors asked for: ' . $kv($w5) . '. Built on the site, not by the worker; a failed build is tried again after 30 minutes, 2 hours and 8 hours, then waits in Pulse.</p>';
        if ($wf === 'W2' && $w2review) $body .= '<p class="ak-note">Waiting in Review from it: ' . $kv($w2review) . ' (<a class="underline" href="/admin/local/review">Review</a>; nothing here changes a listing by itself).</p>';
        if ($mine) {
            $body .= '<div class="ak-aa"><table><thead><tr><th>Capture task</th><th>Every</th><th>Last served</th><th>Last 24 h</th><th>Its queue</th><th></th></tr></thead><tbody>';
            foreach ($mine as $t => $r) {
                $s = $stats[$t] ?? [];
                $day24 = array_filter(['done' => $s['done'] ?? 0, 'nothing to do' => $s['idle'] ?? 0, 'not reached' => $s['not_reached'] ?? 0, 'failed' => $s['failed'] ?? 0, 'off' => $s['off'] ?? 0]);
                $every = (int) $r['every_minutes'] >= 1440 ? 'nightly, when due' : ((int) $r['every_minutes'] >= 60 ? round((int) $r['every_minutes'] / 60) . ' h' : (int) $r['every_minutes'] . ' min');
                $acts = $btn('first', 'Run first', ['task' => $t]) . ' ' . ((int) $r['enabled'] ? $btn('off', 'Switch off', ['task' => $t], 'Switch off ' . $r['name'] . '? No run takes it until it\'s on again.', true) : $btn('on', 'Switch on', ['task' => $t]))
                      . (in_array($t, ['coverage', 'identity'], true) ? ' ' . $btn('retry', 'Retry failed', ['task' => $t]) : '');
                $body .= '<tr><td><b>' . $e((string) $r['name']) . '</b>' . ((int) $r['enabled'] ? '' : ' <em>(off)</em>') . '<br><small>' . $e((string) $r['what']) . '. From ' . $e((string) $r['from_where']) . '.</small>'
                       . ($r['last_outcome'] ? '<br><small>Last: ' . $e(CrawlService::OUTCOMES[$r['last_outcome']] ?? (string) $r['last_outcome']) . ($r['last_why'] ? ' (' . $e((string) $r['last_why']) . ')' : '') . '</small>' : '') . '</td>'
                       . '<td>' . $e($every) . '</td><td>' . $at($r['last_served_at']) . '</td><td>' . ($day24 ? $kv($day24) : 'no runs') . '</td><td>' . $kv($q[$t] ?? []) . '</td><td style="white-space:nowrap">' . $acts . '</td></tr>';
            }
            $body .= '</tbody></table></div>';
        }
        $tone = $paused ? 'info' : 'ok';
        $h .= tv_admin_fold($wf . '. ' . (string) $w['name'], ($paused ? 'Paused · ' : '') . (int) $w['share_pct'] . '% share', $tone, '', $body, false);
    }

    // the last runs, task by task
    if ($runs) {
        $body = '<div class="ak-aa"><table><thead><tr><th>Started</th><th>Status</th><th>Time</th><th>Fetches</th><th>Searches</th><th>What each task did</th></tr></thead><tbody>';
        foreach ($runs as $r) {
            $items = implode('; ', array_map(fn ($i) => $e((string) $i['task']) . ' ' . $e(strtolower(CrawlService::OUTCOMES[$i['outcome']] ?? (string) $i['outcome'])) . ((int) $i['seconds'] ? ' ' . (int) $i['seconds'] . 's' : '') . ($i['why'] ? ' (' . $e(mb_strimwidth((string) $i['why'], 0, 90, '…')) . ')' : ''), $r['items']));
            $body .= '<tr><td>' . $at((string) $r['started_at']) . '</td><td>' . $e((string) $r['status']) . ($r['why'] ? '<br><small>' . $e(mb_strimwidth((string) $r['why'], 0, 160, '…')) . '</small>' : '') . '</td><td>' . (int) $r['seconds'] . 's</td><td>' . (int) $r['fetches'] . '</td><td>' . (int) $r['searches'] . '</td><td><small>' . ($items ?: '–') . '</small></td></tr>';
        }
        $h .= tv_admin_fold('The last runs', count($runs) . ' shown', 'info', '', $body . '</tbody></table></div>', false);
    }
    $h .= '<p class="ak-note">Still on <a class="underline" href="/admin/crawler.php">the earlier overview</a> until their workflows move here (handoffs/crawler-revamp.md Phase 3): queueing coverage gaps by hand, the coverage map. Railway: project gracious-sparkle, service traversence, deployed from main.</p>';
    return '<div>' . $h . '</div><style>.ak-aa{overflow-x:auto;margin:.6rem 0}.ak-aa table{width:100%;border-collapse:collapse;font-size:.85rem}.ak-aa th,.ak-aa td{padding:.35rem .5rem;border-bottom:1px solid #E8DCC6;text-align:left;vertical-align:top}</style>';
}
