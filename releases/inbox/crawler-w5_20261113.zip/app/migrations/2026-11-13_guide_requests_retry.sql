-- Guides on demand: a failed build is tried again by itself (review W5, decisions/0160 W5). Safe to run twice.
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE guide_requests ADD COLUMN tries TINYINT UNSIGNED NOT NULL DEFAULT 0', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_requests' AND COLUMN_NAME = 'tries');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE guide_requests ADD COLUMN failed_at DATETIME NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_requests' AND COLUMN_NAME = 'failed_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
-- builds that failed before this: tried again once, from now (they were promised a retry)
UPDATE guide_requests SET tries = 1, failed_at = NOW() - INTERVAL 1 DAY WHERE status = 'failed' AND tries = 0 AND failed_at IS NULL;
