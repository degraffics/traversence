<?php
/**
 * bootstrap.php
 *
 * Shared entrypoint included at the top of every api/*.php script.
 * Configures secure session handling, loads the DB connection, and
 * sets the default JSON response header.
 *
 * Session strategy: native PHP sessions (not JWT). Chosen deliberately
 * for a BlueHost shared-hosting target — no extra infrastructure
 * (Redis, token blacklist store, etc.) required, and PHP sessions are
 * well-supported out of the box. If the platform later needs a
 * stateless API for a separate mobile client, this can be swapped for
 * JWT without touching the underlying Auth::attemptLogin() logic.
 */

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0'); // never leak stack traces to the client — log instead

require_once __DIR__ . '/lib/Database.php';
require_once __DIR__ . '/lib/Response.php';
require_once __DIR__ . '/lib/TrustScore.php';
require_once __DIR__ . '/lib/Auth.php';

require_once __DIR__ . '/ui/security-headers.php';

// links typed into forms arrive wrapped, so the host's firewall doesn't block them (Response::unwrap)
if (!empty($_POST)) $_POST = Response::unwrap($_POST);

// --- Secure session cookie configuration -----------------------------
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

session_set_cookie_params([
    'lifetime' => 0,            // session cookie, expires on browser close
    'path'     => '/',
    'domain'   => '',           // current domain only
    'secure'   => $isHttps,     // HTTPS-only once live; allows local HTTP dev
    'httponly' => true,         // not accessible to JS — mitigates XSS token theft
    'samesite' => 'Lax',        // CSRF baseline; paired with explicit CSRF token below
]);
session_name('traversence_session');

// Signed in until you sign out or close the browser (Jason, 2026-10-10). PHP's default drops a session after 24
// minutes without a request, and on shared hosting every site's clean-up runs over the same shared folder, so people
// were signed out after a short break. Sessions live in our own folder (app/storage/sessions, never served) and are
// kept for 30 days without activity; the cookie itself still ends when the browser closes.
if (session_status() === PHP_SESSION_NONE) {
    $sessDir = __DIR__ . '/storage/sessions';
    if (!is_dir($sessDir)) @mkdir($sessDir, 0700, true);
    if (is_dir($sessDir) && is_writable($sessDir)) session_save_path($sessDir);
    ini_set('session.gc_maxlifetime', (string) (30 * 86400));
    ini_set('session.gc_probability', '1');
    ini_set('session.gc_divisor', '1000');
}

// Machines get no session file (2026-10-15): of 7,626 session files, 7,610 held nothing but a form token, one per
// request from something without a cookie (the crawler worker every few minutes, search engines, link previews). They
// never sign in or fill a form, so their visit keeps an in-memory session that's never saved.
$tvMachine = !empty($_SERVER['HTTP_X_CRAWLER_TOKEN'])
    || preg_match('/^Bearer\s/i', (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ''))
    || (empty($_COOKIE['traversence_session']) && preg_match('/bot|crawl|spider|slurp|preview|facebookexternalhit|embedly|monitor|uptime|curl|wget|python-requests|python-urllib|httpx|go-http-client|okhttp|headless|scrapy|axios\//i', (string) ($_SERVER['HTTP_USER_AGENT'] ?? '')));
if (session_status() === PHP_SESSION_NONE && $tvMachine) {
    $_SESSION = [];
} elseif (session_status() === PHP_SESSION_NONE) {
    session_start();
    // A visit that only ever got its form token and never came back needn't wait 30 days: such files go after a
    // day (signed-in sessions keep the 30). Checked at most once an hour, by whichever request comes first.
    $tvSessDir = (string) session_save_path();
    $tvSweep = __DIR__ . '/storage/sessions-swept';
    if ($tvSessDir !== '' && str_starts_with(realpath($tvSessDir) ?: '', realpath(__DIR__ . '/storage') ?: "\0")
        && (!is_file($tvSweep) || filemtime($tvSweep) < time() - 3600) && @touch($tvSweep)) {
        $tvOld = time() - 86400; $tvMine = 'sess_' . session_id();
        foreach (new DirectoryIterator($tvSessDir) as $tvF) {
            if (!$tvF->isFile() || !str_starts_with($tvF->getFilename(), 'sess_') || $tvF->getFilename() === $tvMine) continue;
            if ($tvF->getMTime() >= $tvOld || $tvF->getSize() > 120) continue;
            $tvBody = (string) @file_get_contents($tvF->getPathname());
            if (preg_match('/^csrf_token\|s:64:"[0-9a-f]{64}";$/', $tvBody)) @unlink($tvF->getPathname());
        }
    }
    unset($tvSessDir, $tvSweep, $tvOld, $tvMine, $tvF, $tvBody);
}
unset($tvMachine);

header('Content-Type: application/json; charset=utf-8');

// Every session gets a CSRF token issued on first contact. Endpoints that
// mutate state (register/login/logout/password reset, and everything in
// later phases) should validate X-CSRF-Token against this on non-GET
// requests. Full enforcement middleware lands in Phase 9; the token is
// issued here now so the frontend can start wiring it up immediately.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// The admin side (its pages under /admin/ and the admin APIs). Once an owner's staff login is set up (decisions/0100),
// only staff logins open it: staff ID, password and authenticator code at /admin/login.php; member accounts never do.
// Before that (the switch-over), staff signed in as members pass the emailed two-step code (decisions/0097).
if (PHP_SAPI !== 'cli') {
    $tvPath = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    if (preg_match('#^/(admin|api/admin)(/|$)#', $tvPath) && !preg_match('#^/admin/(login|setup)\.php$#', $tvPath)) {
        require_once __DIR__ . '/lib/StaffLogin.php';
        $tvPdo = Database::connection();
        $tvApi = (bool) preg_match('#^/(api/admin|admin/api)/#', $tvPath);
        if (StaffLogin::enforced($tvPdo)) {
            if (!($tvStaff = StaffLogin::inSession($tvPdo))) {
                if ($tvApi) { http_response_code(401); header('Content-Type: application/json'); echo json_encode(['ok' => false, 'error' => ['code' => 'staff_login', 'message' => 'Sign in with your staff login.']]); exit; }
                header('Location: /admin/login.php?next=' . rawurlencode((string) ($_SERVER['REQUEST_URI'] ?? '/admin/')), true, 302); exit;
            }
            // each staff level and department opens its own workspaces (Workspaces, decisions/0104)
            require_once __DIR__ . '/lib/Workspaces.php';
            $tvArea = StaffLogin::areaFor($tvPath);
            if (!$tvApi && Workspaces::levelOf($tvStaff)[0] === 'vendor' && preg_match('#^/admin(/|/index\.php|/dashboard(/today)?/?)?$#', $tvPath)) {
                // a Vendor login opens nothing but a ticket it's given (AOS §9A, decisions/0150): its landing says so, not a 403
                header('Content-Type: text/html; charset=utf-8');
                require_once __DIR__ . '/ui/page-shell.php';
                tv_page_start('Your tickets', ['no_crumbs' => true]);
                echo '<div class="hb-card tv-bleed" style="max-width:32rem;margin-top:1.5rem;margin-bottom:1.5rem;background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:1rem"><h1 style="font:700 1.3rem Georgia,serif">Your tickets</h1>'
                    . '<p style="margin:.4rem 0" data-tv-status="info" data-tv-label="Nothing yet:">Nothing is assigned to you right now. Your Service Manager will send you a ticket, and it opens here for as long as it lasts.</p>'
                    . '<p style="margin:.4rem 0"><a class="underline text-[#92400E]" href="/admin/staff.php">Your login</a></p></div>';
                tv_page_end(); exit;
            }
            if (!Workspaces::allowsArea($tvStaff, $tvArea, $tvPdo)) {
                $tvMsg = 'Your role (' . StaffLogin::levelName($tvStaff) . ') doesn\'t open ' . (StaffLogin::AREA_NAMES[$tvArea] ?? 'this area') . '. Ask an owner if you need it.';
                http_response_code(403);
                if ($tvApi) { header('Content-Type: application/json'); echo json_encode(['ok' => false, 'error' => ['code' => 'staff_role', 'message' => $tvMsg]]); exit; }
                header('Content-Type: text/html; charset=utf-8');
                require_once __DIR__ . '/ui/page-shell.php';
                tv_page_start('Not part of your role', ['no_crumbs' => true]);
                echo '<div class="hb-card tv-bleed" style="max-width:32rem;margin-top:1.5rem;margin-bottom:1.5rem;background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:1rem"><h1 style="font:700 1.3rem Georgia,serif">Not part of your role</h1><p style="margin:.4rem 0">' . htmlspecialchars($tvMsg) . '</p><p><a style="color:#92400E;text-decoration:underline" href="/admin/">Back to the Admin dashboard</a></p></div>';
                tv_page_end(); exit;
            }
        } elseif (!empty($_SESSION['user_id'])) {
            require_once __DIR__ . '/lib/TwoStep.php';
            TwoStep::gate($tvPdo, null, $tvApi);
        }
        unset($tvPdo, $tvApi);
    }
    unset($tvPath);
}

// Public photo folders made shut by an earlier build open once (Store::openPublic, decisions/0124 fix): a marker file
// makes this a single is_file() check on every later request.
if (!is_file(__DIR__ . '/storage/.uploads-open-v1')) { try { require_once __DIR__ . '/lib/Store.php'; Store::openPublic(); } catch (Throwable $e) { error_log('openPublic: ' . $e->getMessage()); } }
// The uploads hand-off to media.php is written by the site (Store::uploadsRule, 2026-11-15), again whenever Store::KINDS
// changes; after that it's one is_file() check a request.
try { require_once __DIR__ . '/lib/Store.php'; Store::uploadsRule(); } catch (Throwable $e) { error_log('uploadsRule: ' . $e->getMessage()); }
