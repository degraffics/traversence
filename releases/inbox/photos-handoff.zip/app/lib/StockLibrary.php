<?php
// app/lib/StockLibrary.php — the stock library (decisions/0143): photos no one on the site made, so cards and heroes
// look good until their owners add their own. Jason, 2026-11-04: "a way to add an image that is not user created… but
// we don't want them used to represent something when they should not, like here is a photo of my custom product, or
// my journey, because authenticity matters."
//
//   search(source, q)      a source's photos (System Configuration → Stock library), kept 24 hours; each says whether it
//                          can be added and, if not, why (its licence; a protected place; already in)
//   discover(q), adopt()   the same sources for anyone choosing stock, when the library hasn't got it: a photo they
//                          choose is added to the library then (Jason, 2026-11-04: the Stock search has to find photos)
//   add(source, id, tags)  one photo, hand-picked: read fresh from its source, its licence checked again, copied as WebP
//                          into the site's own storage (Store, decisions/0127), kept with its source, licence, author,
//                          credit and link, and tagged (subjects; a place, as "this place" or "representative")
//   pick(subject, place)   the best fit for a card or hero with no photo: this place, then the places it's in, then the
//                          subject; never the same photo twice on a page where another fits
//   forSlot(slot, …)       what an illustrative slot shows: the photo someone chose for it, else pick()
//   credit(), label()      "Photo: …, via …"; "Stock photo" and "Representative photo"
//
// Where stock may go is the slot register (SLOTS): illustrative slots only. Authentic ones (a product, a journey, a
// review, an album, an event's own photos, a business's own photos, a profile, proofs and orders) never take stock, and
// their pages never offer it. A real photo always takes over: callers show stock only where there's no photo of their own.
// The licence decides the use (decisions/0133): commercial use and changes allowed, or it's left out. Nothing that may
// show a sacred, burial or protected site (decisions/0066, Landmarks::SENSITIVE). No paid source, no per-use cost.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/stock/StockSource.php';
require_once __DIR__ . '/Store.php';

final class StockLibrary
{
    /** The sources built now: key => [adapter class, file]. A later source (below) is one more line and one adapter. */
    public const SOURCES = [
        'wikimedia' => ['StockWikimedia', 'stock/StockWikimedia.php'],
        'loc' => ['StockLoc', 'stock/StockLoc.php'],
        'pixabay' => ['StockPixabay', 'stock/StockPixabay.php'],
    ];

    /** Recorded for later (decisions/0143 §4), not built: what each needs. */
    public const LATER = [
        'nps' => ['National Park Service', 'A key from api.data.gov as NPS_API_KEY (sent as X-Api-Key to developer.nps.gov/api/v1); each photo\'s credit line checked.'],
        'unsplash' => ['Unsplash', 'UNSPLASH_ACCESS_KEY; held as a link with its download ping, not a copy.'],
        'pexels' => ['Pexels', 'PEXELS_API_KEY, once new keys reopen; a copy with a link back.'],
    ];

    /** The slot register: [kind, what it is]. Illustrative slots may show stock (labelled); authentic ones never. */
    public const SLOTS = [
        'hero' => ['illustrative', 'A hero with no photos yet (a place guide, a listing)'],
        'card' => ['illustrative', 'A card with no photo yet'],
        'storefront_cover' => ['illustrative', 'A storefront banner'],
        'page_banner' => ['illustrative', 'A page banner'],
        'guide_illustration' => ['illustrative', 'A place guide\'s or article\'s illustration'],
        'home_door' => ['illustrative', 'A home-page door'],
        'event_backdrop' => ['illustrative', 'An event\'s backdrop, before its own photos'],
        'category_tile' => ['illustrative', 'A category tile'],
        'product_photo' => ['authentic', 'A product\'s or item\'s photos'],
        'journey_photo' => ['authentic', 'A journey\'s or story\'s photos'],
        'review_photo' => ['authentic', 'A review\'s photos'],
        'gallery_album' => ['authentic', 'A gallery album'],
        'event_photo' => ['authentic', 'An event\'s own photos'],
        'business_photo' => ['authentic', 'A business\'s own photos (its premises, people or work; its logo; its hero photos)'],
        'profile_photo' => ['authentic', 'A profile or cover photo'],
        'proof' => ['authentic', 'Proofs, orders and their files'],
    ];

    /** The home page's doors and the subjects their photos are picked by when nobody has chosen one. */
    public const DOORS = ['explore' => ['Explore', 'landscape'], 'local' => ['Local', 'main street'], 'social' => ['Connect', 'community'], 'market' => ['Market', 'market']];

    public const SCOPES = ['this_place' => 'This place', 'representative' => 'Representative'];
    private const ADD_PER_10_MIN = 30;   // hand-picked, never bulk

    private static array $used = [];     // photos already on this page
    private static ?array $all = null;

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM stock_images LIMIT 1'); $pdo->query('SELECT 1 FROM stock_uses LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    /** Whether a slot may show stock. An unknown slot may not. */
    public static function allowed(string $slot): bool { return (self::SLOTS[$slot][0] ?? '') === 'illustrative'; }

    /** Keeps the register in the database the same as the code's (the code wins). */
    public static function syncSlots(PDO $pdo): void
    {
        try {
            $st = $pdo->prepare('INSERT INTO stock_slots (slot, kind, label, updated_at) VALUES (?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE kind = VALUES(kind), label = VALUES(label)');
            foreach (self::SLOTS as $k => [$kind, $label]) $st->execute([$k, $kind, $label]);
            $keep = implode(',', array_map([$pdo, 'quote'], array_keys(self::SLOTS)));
            $pdo->exec("DELETE FROM stock_slots WHERE slot NOT IN ($keep)");
        } catch (PDOException $x) { error_log('stock slots: ' . $x->getMessage()); }
    }

    // ---- sources --------------------------------------------------------------------------------------------------------

    public static function source(string $key): StockSource
    {
        if (!isset(self::SOURCES[$key])) throw new InvalidArgumentException('Not one of the stock sources.');
        [$class, $file] = self::SOURCES[$key];
        require_once __DIR__ . '/' . $file;
        return new $class();
    }

    /** Each source: [key, name, why it can't be used ('' = it can)]. */
    public static function sources(): array
    {
        $out = [];
        foreach (array_keys(self::SOURCES) as $k) { $s = self::source($k); $out[] = [$k, $s->name(), $s->missing()]; }
        return $out;
    }

    public static function sourceName(string $key): string
    {
        return isset(self::SOURCES[$key]) ? self::source($key)->name() : (self::LATER[$key][0] ?? $key);
    }

    /**
     * Whether a photo's licence lets us use it on cards and heroes, cropped: [ok, the licence's name, why not].
     * Commercial use and changes must both be allowed; non-commercial, no-derivatives and unknown are left out.
     */
    public static function licence(string $source, array $it): array
    {
        if ($source === 'pixabay') return [true, 'Pixabay Content License', ''];
        if ($source === 'loc') {   // its own rights line, read for each photo
            $r = (string) ($it['rights'] ?? '');
            if ($r === '') return [false, '', 'Its rights line isn\'t given, so it\'s left out.'];
            if (preg_match('/not evaluated|may be restricted|is restricted|permission|copyright (is )?held|undetermined/i', $r)) return [false, '', 'Its rights line doesn\'t clear it: "' . mb_strimwidth($r, 0, 90, '…') . '"'];
            if (preg_match('/no known restrictions/i', $r)) return [true, 'No known restrictions on publication', ''];
            if (preg_match('/public domain|no known copyright/i', $r)) return [true, 'Public domain', ''];
            return [false, '', 'Its rights line isn\'t one we can read as clear: "' . mb_strimwidth($r, 0, 90, '…') . '"'];
        }
        $l = trim((string) ($it['licence'] ?? ''));
        if (stripos((string) ($it['rights'] ?? ''), 'non-free') !== false) return [false, $l, 'It isn\'t freely licensed.'];
        if ($l === '') return [false, '', 'Its licence isn\'t stated, so it\'s left out.'];
        if (preg_match('/\bnc\b|non-?commercial/i', $l)) return [false, $l, $l . ' doesn\'t allow commercial use.'];
        if (preg_match('/\bnd\b|no-?deriv/i', $l)) return [false, $l, $l . ' doesn\'t allow changes, and cards and heroes crop.'];
        if (preg_match('/^(cc0|cc[ -]?by(-sa)?([ -][0-9.]+)?( [a-z]{2,3})?|public domain|pd\b|pd-)/i', $l)) return [true, $l, ''];
        return [false, $l, $l . ' isn\'t a licence we can use (commercial use and changes must both be allowed).'];
    }

    /** Words that may mark a sacred, burial or protected site (decisions/0066). '' when clear. */
    public static function sensitive(array $it): string
    {
        require_once __DIR__ . '/Landmarks.php';
        $text = implode(' ', [(string) ($it['title'] ?? ''), (string) ($it['about'] ?? ''), (string) ($it['tags'] ?? '')]);
        return preg_match(Landmarks::SENSITIVE, $text, $m) ? 'It may show a sacred, burial or protected site ("' . $m[0] . '"), so it stays out (decisions/0066).' : '';
    }

    /**
     * A source's photos for a search: [items, more]. Each item adds state ('ok', 'in' with the library's id, or 'no') and
     * why. Answers are kept 24 hours (Pixabay asks for it; kind to the others).
     */
    public static function search(PDO $pdo, string $source, string $q, int $page = 1): array
    {
        $q = trim((string) preg_replace('/\s+/', ' ', $q));
        if (mb_strlen($q) < 2) throw new InvalidArgumentException('Type what you\'re looking for.');
        $src = self::source($source);
        if ($src->missing() !== '') throw new RuntimeException($src->name() . ' can\'t be searched yet: ' . $src->missing());
        $page = max(1, min(20, $page));
        $hash = sha1(mb_strtolower($q) . '|' . $page);
        $res = null;
        try {
            $st = $pdo->prepare('SELECT results FROM stock_search_cache WHERE source = ? AND qhash = ? AND cached_at > ?');
            $st->execute([$source, $hash, date('Y-m-d H:i:s', time() - $src->cacheFor())]);
            $res = json_decode((string) $st->fetchColumn(), true);
        } catch (PDOException) {}
        if (!is_array($res)) {
            [$items, $more] = $src->search($q, $page);
            $res = ['items' => $items, 'more' => $more];
            try {
                $pdo->prepare('REPLACE INTO stock_search_cache (source, qhash, results, cached_at) VALUES (?, ?, ?, NOW())')->execute([$source, $hash, json_encode($res, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
                if (random_int(1, 20) === 1) $pdo->prepare('DELETE FROM stock_search_cache WHERE cached_at < ?')->execute([date('Y-m-d H:i:s', time() - 86400)]);
            } catch (PDOException $x) { error_log('stock cache: ' . $x->getMessage()); }
        }
        $have = [];
        $ids = array_column($res['items'], 'id');
        if ($ids) {
            $st = $pdo->prepare('SELECT source_id, id, status FROM stock_images WHERE source = ? AND source_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')');
            $st->execute(array_merge([$source], $ids));
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $have[(string) $r['source_id']] = $r;
        }
        $out = [];
        foreach ($res['items'] as $it) {
            [$ok, $lic, $why] = self::licence($source, $it);
            if (!$ok && $source !== 'loc') continue;   // left out automatically; the Library's are shown greyed, so its rights lines can be seen
            $sens = self::sensitive($it);
            $in = $have[(string) $it['id']] ?? null;
            $out[] = ['id' => (string) $it['id'], 'title' => $it['title'], 'thumb' => $it['thumb'], 'licence' => $lic ?: (string) $it['licence'], 'author' => $it['author'],
                'credit' => self::creditText($it['credit'], $it['author'], $lic, $source), 'source_url' => $it['source_url'], 'tags' => mb_substr((string) $it['tags'], 0, 160),
                'state' => $in ? 'in' : ($ok && $sens === '' ? 'ok' : 'no'), 'in' => $in ? (int) $in['id'] : 0,
                'why' => $in ? ($in['status'] === 'live' ? 'Already in the library.' : 'In the library, retired.') : ($ok ? $sens : $why)];
        }
        return [$out, (bool) $res['more']];
    }

    /**
     * The sources' photos for anyone choosing stock (the Gallery's Stock tab, the picker), when the library hasn't got
     * what they need: every source that's set up, searched (kept 24 hours), only photos that can be used (licence clear,
     * no protected place, not already in the library), interleaved so each source shows. [items, notes about sources that
     * didn't answer]. Pixabay asks that its search results say where they're from: each item names its source.
     */
    public static function discover(PDO $pdo, string $q, int $max = 36): array
    {
        $q = trim((string) preg_replace('/\s+/', ' ', $q));
        if (mb_strlen($q) < 2 || !self::ready($pdo)) return [[], []];
        $lists = []; $notes = [];
        foreach (self::sources() as [$k, $name, $miss]) {
            if ($miss !== '') continue;
            try { [$items] = self::search($pdo, $k, $q, 1); $lists[$k] = array_values(array_filter($items, fn ($i) => $i['state'] === 'ok')); }
            catch (Throwable $x) { error_log('stock discover ' . $k . ': ' . $x->getMessage()); $notes[] = $name . ' didn\'t answer just now.'; }
        }
        $out = [];
        for ($i = 0; count($out) < $max; $i++) {
            $any = false;
            foreach ($lists as $k => $l) if (isset($l[$i])) { $any = true; $out[] = ['source' => $k, 'source_id' => $l[$i]['id'], 'source_name' => self::sourceName($k), 'card' => $l[$i]['thumb'], 'title' => $l[$i]['title'],
                'credit' => $l[$i]['credit'], 'licence' => $l[$i]['licence'], 'source_url' => $l[$i]['source_url'], 'found' => true]; }
            if (!$any) break;
        }
        return [array_slice($out, 0, $max), $notes];
    }

    /**
     * A photo someone found at a source and chose for an illustrative spot: added to the library then and there (one at
     * a time, by the person who chose it; its licence and place checked again, copied as WebP, tagged with what they
     * searched for, "representative"), or the library's copy when it's already in. Returns it as shown.
     */
    public static function adopt(PDO $pdo, int $uid, string $source, string $id, string $q): array
    {
        $st = $pdo->prepare('SELECT id, status FROM stock_images WHERE source = ? AND source_id = ?'); $st->execute([$source, $id]);
        if ($had = $st->fetch(PDO::FETCH_ASSOC)) {
            if ($had['status'] !== 'live') throw new InvalidArgumentException('Our team took that photo out of the library. Choose another.');
            return self::shown(self::get($pdo, (int) $had['id']), '', true);
        }
        $subjects = self::words($q);
        $img = self::add($pdo, $source, $id, ['subjects' => implode(',', array_merge([mb_strtolower(trim($q))], $subjects)) ?: 'photo', 'place' => '', 'scope' => 'representative'], $uid);
        return self::shown($img, '', true);
    }

    // ---- adding, tagging, retiring ----------------------------------------------------------------------------------------

    /** Subjects as stored: ",canyon,desert sunset," (lower case, one or two words each, up to 12). */
    public static function subjects(string $s): string
    {
        $out = [];
        foreach (preg_split('/[,;\n]+/', mb_strtolower(strip_tags($s))) as $w) {
            $w = trim((string) preg_replace('/[^\p{L}\p{N} &\'-]+/u', '', $w));
            if ($w !== '' && mb_strlen($w) <= 40) $out[$w] = true;
        }
        return $out ? ',' . implode(',', array_slice(array_keys($out), 0, 12)) . ',' : '';
    }

    /** The tags someone set: [subjects, place key, scope]. */
    private static function tags(PDO $pdo, array $t): array
    {
        $subjects = self::subjects((string) ($t['subjects'] ?? ''));
        if ($subjects === '') throw new InvalidArgumentException('Give it at least one subject (what it shows: canyon, main street, farmers market…).');
        $place = trim((string) ($t['place'] ?? ''));
        if ($place !== '') {
            require_once __DIR__ . '/Guides.php';
            if (!Guides::place($pdo, $place)) throw new InvalidArgumentException('That place isn\'t in the places tree.');
        }
        $scope = (string) ($t['scope'] ?? 'representative');
        if (!isset(self::SCOPES[$scope])) $scope = 'representative';
        if ($place === '') $scope = 'representative';   // "this place" needs a place
        return [$subjects, $place, $scope];
    }

    public static function add(PDO $pdo, string $source, string $id, array $tags, int $uid): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('The stock library\'s database update hasn\'t run yet.');
        [$subjects, $place, $scope] = self::tags($pdo, $tags);
        $st = $pdo->prepare('SELECT COUNT(*) FROM stock_images WHERE added_by = ? AND added_at > ?');
        $st->execute([$uid, date('Y-m-d H:i:s', time() - 600)]);
        if ((int) $st->fetchColumn() >= self::ADD_PER_10_MIN) throw new InvalidArgumentException('That\'s ' . self::ADD_PER_10_MIN . ' in ten minutes. The library is hand-picked, never bulk: take a break and come back.');
        $st = $pdo->prepare('SELECT id, status FROM stock_images WHERE source = ? AND source_id = ?'); $st->execute([$source, $id]);
        if ($had = $st->fetch(PDO::FETCH_ASSOC)) throw new InvalidArgumentException($had['status'] === 'live' ? 'It\'s already in the library.' : 'It\'s in the library, retired. Restore it from the list.');
        $src = self::source($source);
        $it = $src->item($id);   // fresh from the source: nothing a page sent is trusted
        if (!$it) throw new InvalidArgumentException('That photo isn\'t at ' . $src->name() . ' any more.');
        [$ok, $lic, $why] = self::licence($source, $it);
        if (!$ok) throw new InvalidArgumentException('Left out: ' . $why);
        if (($sens = self::sensitive($it)) !== '') throw new InvalidArgumentException('Left out: ' . $sens);
        $paths = ['', '']; $w = (int) $it['width']; $h = (int) $it['height'];
        if ($src->held() === 'copy') [$paths, $w, $h] = self::copy($src, (string) $it['full']);
        $pdo->prepare('INSERT INTO stock_images (source, source_id, title, licence, licence_url, author, credit, source_url, path, card_path, remote_url, width, height, subjects, place_key, place_scope, status, added_by, added_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, \'live\', ?, NOW())')
            ->execute([$source, mb_substr($id, 0, 190), mb_substr((string) $it['title'], 0, 300), mb_substr($lic, 0, 80), mb_substr((string) $it['licence_url'], 0, 300), mb_substr((string) $it['author'], 0, 200),
                mb_substr(self::creditText((string) $it['credit'], (string) $it['author'], $lic, $source), 0, 400), mb_substr((string) $it['source_url'], 0, 500),
                $paths[0], $paths[1], $src->held() === 'link' ? mb_substr((string) $it['full'], 0, 500) : '', min(65535, $w), min(65535, $h), $subjects, $place, $scope, $uid]);
        self::$all = null;
        return self::get($pdo, (int) $pdo->lastInsertId()) ?? [];
    }

    /** Fetches the photo (only from its source's own hosts) and keeps it as WebP: a large copy and a card. */
    private static function copy(StockSource $src, string $url): array
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (!str_starts_with($url, 'https://') || !in_array($host, $src->hosts(), true)) throw new RuntimeException('That photo\'s address isn\'t one of ' . $src->name() . '\'s.');
        $ch = curl_init($url);
        $bytes = '';
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => false, CURLOPT_TIMEOUT => 40, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_HTTPHEADER => ['User-Agent: ' . StockSource::UA],
            CURLOPT_WRITEFUNCTION => function ($c, $chunk) use (&$bytes) { $bytes .= $chunk; return strlen($bytes) > 30 * 1048576 ? 0 : strlen($chunk); }]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final = strtolower((string) parse_url((string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL), PHP_URL_HOST));
        curl_close($ch);
        if ($code !== 200 || $bytes === '') throw new RuntimeException($src->name() . ' didn\'t send the photo. Try again.');
        if (!in_array($final, $src->hosts(), true)) throw new RuntimeException('The photo came from somewhere other than ' . $src->name() . '.');
        $info = @getimagesizefromstring($bytes);
        if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) throw new RuntimeException('That isn\'t a photo we can keep (JPEG, PNG or WebP).');
        if ($info[0] < 640 || $info[1] < 360) throw new InvalidArgumentException('It\'s too small for a card or a hero (at least 640 × 360).');
        $im = @imagecreatefromstring($bytes);
        unset($bytes);
        if (!$im) throw new RuntimeException('That photo couldn\'t be read.');
        require_once __DIR__ . '/Store.php';
        $name = bin2hex(random_bytes(12));
        $ext = function_exists('imagewebp') ? 'webp' : 'jpg';
        $full = Store::path('system', 'stock', 'stock', "$name.$ext", true);
        $dir = dirname($full);
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) throw new RuntimeException('The library can\'t store photos right now.');
        [$w, $h] = self::save($im, $full, 2000);
        self::save($im, "$dir/$name-card.$ext", 640);
        imagedestroy($im);
        Store::keep($full, "$dir/$name-card.$ext");
        $rel = Store::address($full);
        return [[$rel, substr($rel, 0, -strlen(".$ext")) . "-card.$ext"], $w, $h];
    }

    private static function save($src, string $path, int $max): array
    {
        $w = imagesx($src); $h = imagesy($src); $k = min(1, $max / max($w, $h));
        $dst = imagecreatetruecolor(max(1, (int) round($w * $k)), max(1, (int) round($h * $k)));
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
        imagecopyresampled($dst, $src, 0, 0, 0, 0, imagesx($dst), imagesy($dst), $w, $h);
        $ok = str_ends_with($path, '.webp') ? imagewebp($dst, $path, 80) : imagejpeg($dst, $path, 82);   // a new file: nothing from the original (no metadata) is kept
        $size = [imagesx($dst), imagesy($dst)];
        imagedestroy($dst);
        if (!$ok) throw new RuntimeException('The library can\'t store photos right now.');
        @chmod($path, 0644);
        return $size;
    }

    public static function get(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM stock_images WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function retag(PDO $pdo, int $id, array $t, int $uid): void
    {
        [$subjects, $place, $scope] = self::tags($pdo, $t);
        $pdo->prepare('UPDATE stock_images SET subjects = ?, place_key = ?, place_scope = ? WHERE id = ?')->execute([$subjects, $place, $scope, $id]);
        self::$all = null;
    }

    /** Retired: off every card, hero and pick at once (the choices that used it fall back to pick()); the copy is kept. */
    public static function retire(PDO $pdo, int $id, string $why, int $uid): void
    {
        $pdo->prepare("UPDATE stock_images SET status = 'retired', retired_by = ?, retired_at = NOW(), retired_why = ? WHERE id = ?")->execute([$uid, mb_substr(trim($why), 0, 300), $id]);
        self::$all = null;
    }

    public static function restore(PDO $pdo, int $id): void
    {
        $pdo->prepare("UPDATE stock_images SET status = 'live', retired_by = NULL, retired_at = NULL, retired_why = '' WHERE id = ?")->execute([$id]);
        self::$all = null;
    }

    /** How many places use it by choice. */
    public static function uses(PDO $pdo, int $id): int
    {
        $st = $pdo->prepare('SELECT COUNT(*) FROM stock_uses WHERE stock_id = ?'); $st->execute([$id]);
        return (int) $st->fetchColumn();
    }

    // ---- credit and labels -------------------------------------------------------------------------------------------------

    public static function creditText(string $credit, string $author, string $licence, string $source): string
    {
        $c = trim($credit);
        if ($c !== '') return $c;
        return 'Photo: ' . ($author !== '' ? $author . ', ' : '') . ($licence !== '' ? $licence . ', ' : '') . 'via ' . self::sourceName($source);
    }

    public static function credit(array $img): string
    {
        return self::creditText((string) ($img['credit'] ?? ''), (string) ($img['author'] ?? ''), (string) ($img['licence'] ?? ''), (string) ($img['source'] ?? ''));
    }

    /** "Stock photo", with "Representative photo" when it isn't the actual place. */
    public static function label(array $shown): string
    {
        return 'Stock photo' . (!empty($shown['representative']) ? ' · Representative photo' : '');
    }

    // ---- choosing ------------------------------------------------------------------------------------------------------------

    /** The words a subject is matched on. */
    private static function words(string $s): array
    {
        $out = [];
        foreach (preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($s)) ?: [] as $w) {
            if (mb_strlen($w) < 3 || in_array($w, ['the', 'and', 'for', 'with', 'shop', 'store', 'services', 'service', 'other', 'general', 'local', 'company', 'inc', 'llc'], true)) continue;
            $out[] = $w; if (strlen($w) > 4 && str_ends_with($w, 's')) $out[] = substr($w, 0, -1);
        }
        return array_values(array_unique($out));
    }

    /** The place and every place above it, nearest first: [key => depth]. */
    private static function chain(PDO $pdo, string $place): array
    {
        if ($place === '') return [];
        require_once __DIR__ . '/Guides.php';
        $out = []; $k = $place;
        for ($i = 0; $k && $i < 6; $i++) { $p = Guides::place($pdo, $k); if (!$p) break; $out[$k] = $i; $k = $p['parent']; }
        return $out;
    }

    private static function live(PDO $pdo): array
    {
        if (self::$all !== null) return self::$all;
        try { return self::$all = $pdo->query("SELECT * FROM stock_images WHERE status = 'live' ORDER BY id LIMIT 3000")->fetchAll(PDO::FETCH_ASSOC); }
        catch (PDOException) { return self::$all = []; }
    }

    /**
     * The best photo for a card or hero with no photo of its own, or null. $o: seed (so neighbouring cards differ),
     * representative (true: never says it's the actual place, as for a business), fallback (a subject when none fits).
     */
    public static function pick(PDO $pdo, string $subject = '', string $place = '', array $o = []): ?array
    {
        if (!self::ready($pdo)) return null;
        $rows = self::live($pdo);
        if (!$rows) return null;
        $chain = self::chain($pdo, $place);
        $best = self::rank($rows, self::words($subject), $chain, $place, (string) ($o['seed'] ?? $subject . '|' . $place));
        if (!$best && !empty($o['fallback'])) $best = self::rank($rows, self::words((string) $o['fallback']), $chain, $place, (string) ($o['seed'] ?? ''));
        if (!$best) return null;
        $pickRow = null;
        foreach ($best as $r) if (!isset(self::$used[(int) $r['id']])) { $pickRow = $r; break; }
        $pickRow = $pickRow ?? $best[0];   // every fitting photo is on the page already: repeating is better than none
        self::$used[(int) $pickRow['id']] = true;
        return self::shown($pickRow, $place, !empty($o['representative']));
    }

    private static function rank(array $rows, array $words, array $chain, string $place, string $seed): array
    {
        $scored = [];
        foreach ($rows as $r) {
            $pk = (string) $r['place_key'];
            $s = 0;
            if ($pk !== '' && isset($chain[$pk])) $s += ($chain[$pk] === 0 ? ($r['place_scope'] === 'this_place' ? 100 : 80) : max(20, 60 - 10 * $chain[$pk]));
            elseif ($pk !== '' && $r['place_scope'] === 'this_place') continue;   // a photo of somewhere else never stands for this place
            $subs = array_filter(explode(',', (string) $r['subjects']));
            $hit = 0;
            foreach ($subs as $sub) foreach (self::words($sub) as $sw) if (in_array($sw, $words, true)) { $hit++; break; }
            $s += 15 * min(3, $hit);
            if ($s <= 0) continue;
            $scored[] = [$s, crc32($seed . '#' . $r['id']), $r];
        }
        usort($scored, fn ($a, $b) => [$b[0], $a[1]] <=> [$a[0], $b[1]]);
        return array_map(fn ($x) => $x[2], $scored);
    }

    /** A library row as shown: url, card, credit, label… */
    public static function shown(array $r, string $place = '', bool $representative = false): array
    {
        $isPlace = !$representative && $place !== '' && (string) $r['place_key'] === $place && $r['place_scope'] === 'this_place';
        $url = (string) ($r['path'] ?: $r['remote_url']);
        $shown = ['id' => (int) $r['id'], 'url' => Store::src($url), 'card' => Store::src((string) ($r['card_path'] ?: $url)), 'title' => (string) $r['title'],
            'credit' => self::credit($r), 'licence' => (string) $r['licence'], 'licence_url' => (string) $r['licence_url'], 'author' => (string) $r['author'],
            'source' => (string) $r['source'], 'source_name' => self::sourceName((string) $r['source']), 'source_url' => (string) $r['source_url'],
            'place' => (string) $r['place_key'], 'representative' => !$isPlace];
        $shown['label'] = self::label($shown);
        return $shown;
    }

    /** What an illustrative slot shows when it has no photo of its own: the photo chosen for it, else pick(). Null for authentic slots. */
    public static function forSlot(PDO $pdo, string $slot, string $owner, string $subject = '', string $place = '', array $o = []): ?array
    {
        if (!self::allowed($slot) || !self::ready($pdo)) return null;
        if ($owner !== '') {
            try {
                $st = $pdo->prepare("SELECT i.* FROM stock_uses u JOIN stock_images i ON i.id = u.stock_id AND i.status = 'live' WHERE u.slot = ? AND u.owner_ref = ?");
                $st->execute([$slot, $owner]);
                if ($r = $st->fetch(PDO::FETCH_ASSOC)) { self::$used[(int) $r['id']] = true; return self::shown($r, $place, !empty($o['representative'])) + ['chosen' => true]; }
            } catch (PDOException $x) { error_log('stock forSlot: ' . $x->getMessage()); }
        }
        return self::pick($pdo, $subject, $place, $o + ['seed' => $slot . ':' . $owner]);
    }

    /** The photo chosen for a slot (0 = none: picked automatically), or null. */
    public static function chosen(PDO $pdo, string $slot, string $owner): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare("SELECT i.* FROM stock_uses u JOIN stock_images i ON i.id = u.stock_id AND i.status = 'live' WHERE u.slot = ? AND u.owner_ref = ?");
        $st->execute([$slot, $owner]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ? self::shown($r) : null;
    }

    /** Chooses a library photo for an illustrative slot (0 goes back to automatic). The caller has checked who may. */
    public static function setUse(PDO $pdo, string $slot, string $owner, int $stockId, int $uid): void
    {
        if (!self::allowed($slot)) throw new InvalidArgumentException('Stock photos can\'t go here: this spot is for real photos.');
        if (!self::ready($pdo)) throw new RuntimeException('The stock library isn\'t switched on yet.');
        if ($owner === '' || strlen($owner) > 64) throw new InvalidArgumentException('Which one?');
        if ($stockId <= 0) { $pdo->prepare('DELETE FROM stock_uses WHERE slot = ? AND owner_ref = ?')->execute([$slot, $owner]); return; }
        $img = self::get($pdo, $stockId);
        if (!$img || $img['status'] !== 'live') throw new InvalidArgumentException('That photo isn\'t in the library.');
        $pdo->prepare('REPLACE INTO stock_uses (slot, owner_ref, stock_id, set_by, set_at) VALUES (?, ?, ?, ?, NOW())')->execute([$slot, $owner, $stockId, $uid ?: null]);
    }

    /** The library for the image picker's Stock tab: live photos matching the words, this place's first. */
    public static function find(PDO $pdo, string $q, string $place = '', int $max = 36): array
    {
        if (!self::ready($pdo)) return [];
        $rows = self::live($pdo);
        $words = self::words($q); $chain = self::chain($pdo, $place);
        $out = [];
        foreach ($rows as $r) {
            $hay = mb_strtolower($r['subjects'] . ' ' . $r['title']);
            $hit = 0; foreach ($words as $w) if (str_contains($hay, $w)) $hit++;
            if ($words && !$hit) continue;
            $pk = (string) $r['place_key'];
            if ($pk !== '' && $r['place_scope'] === 'this_place' && !isset($chain[$pk]) && $place !== '') continue;   // somewhere else's own photo
            $out[] = [$hit * 10 + ($pk !== '' && isset($chain[$pk]) ? 50 - 10 * $chain[$pk] : 0), -(int) $r['id'], $r];
        }
        usort($out, fn ($a, $b) => [$b[0], $a[1]] <=> [$a[0], $b[1]]);
        return array_map(fn ($x) => self::shown($x[2], $place), array_slice($out, 0, $max));
    }

    // ---- places -------------------------------------------------------------------------------------------------------------

    public static function placeName(PDO $pdo, string $key): string
    {
        if ($key === '') return '';
        require_once __DIR__ . '/Guides.php';
        $p = Guides::place($pdo, $key);
        return $p ? $p['name'] . ' (' . $p['kind'] . ')' : $key;
    }

    /** A listing's place for picking (its community), or ''. */
    public static function listingPlace(array $biz): string
    {
        return !empty($biz['micro_cluster_id']) ? 'cluster:' . (int) $biz['micro_cluster_id'] : '';
    }
}
