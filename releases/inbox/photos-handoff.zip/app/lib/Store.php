<?php
// app/lib/Store.php — where the site's files live (decisions/0123, 0124). Jason, 2026-10-24: "All files should…
// isn't that why we set up S3, so the gallery and order processing wouldn't kill Bluehost?" and "Shouldn't we have a
// folder dedicated to user id for uploads that way it can be easier to manage and export/delete if needed. Plus we
// will at some point have a DAM feature."
//
// Every file belongs to an owner, and an owner's files sit together under one folder, so they can be listed, counted,
// exported or deleted as one (files(), usage(), wipe()), and the DAM can build on it:
//   members/<folder>/public/…     profile and cover photos, journey photos, their photos of places
//   members/<folder>/private/…    GO Code logos, claim documents
//   businesses/<folder>/public/…  a business's photos (the top of its page)
//   businesses/<folder>/private/… its quotes' proofs and files
//   guests/<folder>/…             GO Code logos from someone without an account
//   orders/<folder>/…             a client order's proofs, artwork and labels: kept with the order, our production and
//                                 sales record, even when the customer's account is deleted (decisions/0095, 0099)
//   system/<folder>/public/…      the site's own: the stock library's copies (decisions/0143), photos no one on the site made
//   internal/…                    our own working files (scanned business cards)
// <folder> is a random name kept in storage_folders, not the account or listing number, so a photo's address doesn't
// say whose it is.
//
// Each library makes a file at its owner's place on the server (path(): public photos under website/uploads, the rest
// under app/storage, claim documents in the claims folder outside the site), then keep() moves it to S3 under the
// same place and removes the server copy. Reading, sending and removing go through here: the server copy first (S3
// not set up, or a file not moved yet), then S3. Public photos keep their /uploads/… address: website/uploads/.htaccess
// sends one that isn't on the server to media.php, which points the browser at S3. The site writes that rule itself
// (uploadsRule(), from KINDS), and src() gives pages an address that works without it.
//
// Files from before (website/uploads/hero|journeys|profile, app/storage/order-proofs…) still work where they are
// (either()), until moveOld() puts each one in its owner's folder (records updated) and in S3: the Settings button,
// or the files_tick scheduled task.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/S3.php';

final class Store
{
    public const KINDS = ['members', 'businesses', 'guests', 'orders', 'system'];
    private static array $folders = [];

    public static function on(): bool { Database::readEnv(); return S3::on(); }

    // ---- owners --------------------------------------------------------------------------------------------------------

    private static function ensure(PDO $pdo): void
    {
        require_once __DIR__ . '/AdminTables.php';
        AdminTables::make($pdo, ['storage_folders' => "(kind VARCHAR(12) NOT NULL, ref VARCHAR(64) NOT NULL, folder CHAR(16) NOT NULL,
            created_at DATETIME NOT NULL, PRIMARY KEY (kind, ref), UNIQUE KEY uq_storage_folder (folder))"]);
    }

    /** An owner's folder name: made the first time it keeps a file, the same ever after. $make false: '' when it has none. */
    public static function folder(string $kind, string|int $ref, bool $make = true): string
    {
        if (!in_array($kind, self::KINDS, true)) throw new InvalidArgumentException('Unknown owner kind.');
        $ref = (string) $ref;
        if ($ref === '' || $ref === '0') throw new InvalidArgumentException('A file needs an owner.');
        if (isset(self::$folders["$kind:$ref"])) return self::$folders["$kind:$ref"];
        $pdo = Database::connection(); self::ensure($pdo);
        $t = Database::t('storage_folders');
        $st = $pdo->prepare("SELECT folder FROM $t WHERE kind = ? AND ref = ?"); $st->execute([$kind, $ref]);
        $f = (string) ($st->fetchColumn() ?: '');
        if ($f === '' && $make) {
            $pdo->prepare("INSERT IGNORE INTO $t (kind, ref, folder, created_at) VALUES (?, ?, ?, NOW())")->execute([$kind, $ref, bin2hex(random_bytes(8))]);
            $st->execute([$kind, $ref]); $f = (string) $st->fetchColumn();
        }
        return $f === '' ? '' : (self::$folders["$kind:$ref"] = $f);
    }

    /** Where an owner's file goes on the server (keep() then moves it to S3). $area: "journeys", "orders/12/proofs"… */
    public static function path(string $kind, string|int $ref, string $area, string $name, bool $public): string
    {
        $rel = $kind . '/' . self::folder($kind, $ref) . '/' . trim($area, '/') . '/' . basename($name);
        return $public ? dirname(__DIR__, 2) . '/website/uploads/' . $rel : dirname(__DIR__) . '/storage/' . $rel;
    }

    /** A new folder's permissions: public photo folders (website/uploads/…) must let the web server in (0755), or
     *  Apache refuses every photo under them ("Server unable to read htaccess file"); private storage stays 0750. */
    public static function mode(string $path): int
    {
        return str_starts_with($path, dirname(__DIR__, 2) . '/website/uploads/') ? 0755 : 0750;
    }

    /** Opens public photo folders made shut (0750) before mode() existed: once, then a marker says it's done. */
    public static function openPublic(bool $force = false): int
    {
        $mark = dirname(__DIR__) . '/storage/.uploads-open-v1';
        if (!$force && is_file($mark)) return 0;
        $root = dirname(__DIR__, 2) . '/website/uploads';
        $n = 0;
        if (is_dir($root)) {
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
            foreach ($it as $f) {
                $p = (string) $f->getPathname(); $perm = @fileperms($p) & 0777;
                if ($f->isDir() && ($perm & 0005) !== 0005) { if (@chmod($p, 0755)) $n++; }
                elseif ($f->isFile() && ($perm & 0004) !== 0004) { if (@chmod($p, 0644)) $n++; }
            }
        }
        if (!is_dir(dirname($mark))) @mkdir(dirname($mark), 0750, true);
        if (is_dir(dirname($mark))) @file_put_contents($mark, date('c') . ' opened ' . $n . "\n");
        return $n;
    }

    /** A public photo's address (what the records keep), for a path made by path(..., true). */
    public static function address(string $path): string
    {
        $root = dirname(__DIR__, 2) . '/website';
        return str_starts_with($path, $root . '/uploads/') ? substr($path, strlen($root)) : '';
    }

    /** Our own working files (not anyone's): app/storage/internal/<area>/<name>. */
    public static function internal(string $area, string $name): string { return dirname(__DIR__) . '/storage/internal/' . trim($area, '/') . '/' . basename($name); }

    /** The claims folder, outside the site (decisions/0070). */
    public static function claimsRoot(): string { return rtrim((string) (getenv('CLAIM_STORAGE') ?: dirname(__DIR__, 4) . '/traversence-private/claims'), '/'); }

    /** A file from before owner folders when it's still on the server, else the owner's one. */
    public static function either(string $new, string $old): string { return is_file($old) ? $old : $new; }

    // ---- where a file is in S3 ----------------------------------------------------------------------------------------

    /** A path with its "." and ".." taken out (the file may not be on the server, so not realpath). */
    private static function clean(string $p): string
    {
        $out = [];
        foreach (explode('/', str_replace('\\', '/', $p)) as $i => $seg) {
            if ($seg === '..') { array_pop($out); continue; }
            if ($seg === '.' || ($seg === '' && $i > 0)) continue;
            $out[] = $seg;
        }
        return implode('/', $out);
    }

    /** The S3 key for a file the site keeps, or null for anything else. */
    public static function key(string $path): ?string
    {
        $p = self::clean($path);
        $own = '#^(' . implode('|', self::KINDS) . ')/([a-f0-9]{16})/(.+)$#';
        $roots = [[dirname(__DIR__, 2) . '/website/uploads/', 'public/', 'uploads/'], [dirname(__DIR__) . '/storage/', 'private/', 'private/'], [self::clean(self::claimsRoot()) . '/', 'private/claims/', 'private/claims/']];
        foreach ($roots as [$root, $in, $before]) {
            if (!str_starts_with($p, $root)) continue;
            $rest = substr($p, strlen($root));
            if (preg_match($own, $rest, $m)) return "$m[1]/$m[2]/$in$m[3]";
            if (str_starts_with($rest, 'internal/') && $in === 'private/') return $rest;
            return $before . $rest;   // a file from before owner folders, moved as it was (decisions/0123)
        }
        return null;
    }

    /** The S3 key of a public photo's address (/uploads/…), for media.php; null for anything else. */
    public static function publicKey(string $rel): ?string
    {
        if (preg_match('#^(' . implode('|', self::KINDS) . ')/([a-f0-9]{16})/([a-z-]{2,20})/([A-Za-z0-9_-]{1,80}\.(jpe?g|png|webp))$#', $rel, $m)) return "$m[1]/$m[2]/public/$m[3]/$m[4]";
        if (preg_match('#^(hero|journeys|profile)/\d{4}/\d{2}/[A-Za-z0-9_-]{1,80}\.(jpe?g|png|webp)$#', $rel)) return 'uploads/' . $rel;
        return null;
    }

    /** A public photo's address as a page should write it (2026-11-15): the /uploads/… address while its server copy is
     *  there; once it's only in the file store, S3_PUBLIC_BASE's address when that's set, else media.php's, so the photo
     *  loads even if website/uploads/.htaccess's hand-off is missing or misses its kind. Anything else comes back as given. */
    public static function src(string $addr): string
    {
        if (!str_starts_with($addr, '/uploads/') || str_contains($addr, '?') || is_file(self::web($addr))) return $addr;
        $rel = substr($addr, strlen('/uploads/'));
        $key = self::publicKey($rel);
        if ($key === null || !self::on()) return $addr;
        $base = rtrim(trim((string) (getenv('S3_PUBLIC_BASE') ?: '')), '/');
        return $base !== '' ? $base . '/' . $key : '/media.php?p=' . $rel;
    }

    /** website/uploads/.htaccess's hand-off to media.php (decisions/0123), for every kind in KINDS and the old
     *  hero|journeys|profile names, matching publicKey(). */
    public static function uploadsBlock(): string
    {
        $ext = '\.(jpe?g|png|webp))$ /media.php?p=$1 [L]';
        return "# BEGIN media hand-off (Store::uploadsRule, decisions/0123): a public photo that isn't on the server is in the\n"
            . "# file store, and media.php points the browser at it. Written by the site from Store::KINDS; edits here are replaced.\n"
            . "RewriteEngine On\n"
            . "RewriteCond %{REQUEST_FILENAME} !-f\n"
            . 'RewriteRule ^((' . implode('|', self::KINDS) . ')/[a-f0-9]{16}/[a-z-]{2,20}/[A-Za-z0-9_-]{1,80}' . $ext . "\n"
            . "RewriteCond %{REQUEST_FILENAME} !-f\n"
            . 'RewriteRule ^((hero|journeys|profile)/[0-9]{4}/[0-9]{2}/[A-Za-z0-9_-]{1,80}' . $ext . "\n"
            . "# END media hand-off\n";
    }

    /** Keeps the hand-off in website/uploads/.htaccess (2026-11-15). It was written by hand and missed system/ (the stock
     *  library, decisions/0143), so stock photos gave a 404 once their server copy moved to the store. Now the site
     *  writes it: the block goes first, the rest of the file is kept, the file as it was is kept once as
     *  .htaccess-before-rule. A marker named from the block's hash makes it one is_file() a request until KINDS changes. */
    public static function uploadsRule(bool $force = false): bool
    {
        $block = self::uploadsBlock();
        $mark = dirname(__DIR__) . '/storage/.uploads-rule-' . substr(sha1($block), 0, 12);
        if (!$force && is_file($mark)) return false;
        $root = dirname(__DIR__, 2) . '/website/uploads';
        if (!is_dir($root)) return false;
        $f = $root . '/.htaccess';
        $old = is_file($f) ? (string) @file_get_contents($f) : '';
        $rest = (string) preg_replace('/^# BEGIN media hand-off.*?^# END media hand-off[^\n]*\n?/ms', '', $old);
        $new = $block . ($rest !== '' ? "\n" . ltrim($rest) : '');
        if ($new !== $old) {
            if ($old !== '' && !is_file($root . '/.htaccess-before-rule')) @file_put_contents($root . '/.htaccess-before-rule', $old);
            $tmp = $f . '.tmp-' . getmypid();
            if (@file_put_contents($tmp, $new) === false || !@rename($tmp, $f)) { @unlink($tmp); error_log('uploadsRule: could not write ' . $f); return false; }
            @chmod($f, 0644);
        }
        if (!is_dir(dirname($mark))) @mkdir(dirname($mark), 0750, true);
        @file_put_contents($mark, date('c') . "\n");
        return true;
    }

    /** The server path of a public photo's address (/uploads/…). */
    public static function web(string $rel): string { return dirname(__DIR__, 2) . '/website' . $rel; }

    // ---- a file ------------------------------------------------------------------------------------------------------

    /** Moves files just made on the server to S3 and removes the server copies. If S3 isn't set up, or doesn't take a
     *  file, the file stays where it is and still works from there. */
    public static function keep(string ...$paths): void
    {
        if (!self::on()) return;
        foreach ($paths as $p) {
            $k = self::key($p);
            if ($k === null || !is_file($p)) continue;
            $public = str_contains($k, '/public/') || str_starts_with($k, 'uploads/');
            try { S3::put($k, $p, self::type($p), $public ? 'public, max-age=31536000, immutable' : 'private, max-age=600'); @unlink($p); }
            catch (Throwable $x) { error_log('Store keep ' . $k . ': ' . $x->getMessage()); }
        }
    }

    public static function has(string $path): bool
    {
        if (is_file($path)) return true;
        $k = self::key($path);
        return $k !== null && self::on() && S3::size($k) >= 0;
    }

    /** A kept file's bytes ('' when it isn't anywhere). */
    public static function read(string $path): string
    {
        if (is_file($path)) return (string) file_get_contents($path);
        $k = self::key($path);
        return $k !== null && self::on() ? (string) S3::get($k) : '';
    }

    /** A file on the server to work from (the file itself, or a copy fetched from S3 for this request), or '' when it
     *  isn't anywhere. For code that needs a real file (resizing a photo). */
    public static function local(string $path): string
    {
        if (is_file($path)) return $path;
        $k = self::key($path);
        if ($k === null || !self::on() || ($bytes = S3::get($k)) === null) return '';
        $tmp = tempnam(sys_get_temp_dir(), 'tvs'); file_put_contents($tmp, $bytes);
        register_shutdown_function(static fn () => @unlink($tmp));
        return $tmp;
    }

    /** Removes a kept file wherever it is. */
    public static function remove(string $path): void
    {
        if (is_file($path)) @unlink($path);
        $k = self::key($path);
        if ($k !== null && self::on()) S3::delete($k);
    }

    /** A file that isn't on the server: sends the browser to it in S3 (a 15-minute link with its own name) and stops.
     *  Returns when the file is on the server, so the caller serves it as it always has. */
    public static function redirect(string $path, string $name, string $mime, bool $inline): void
    {
        if (is_file($path)) return;
        $k = self::key($path);
        if ($k === null || !self::on()) return;
        header('Cache-Control: private, no-store');
        header('Location: ' . S3::link($k, $name, $mime, $inline), true, 302);
        exit;
    }

    /** Moves a file to a new place (on the server, or within S3). True when it's there. */
    private static function relocate(string $from, string $to): bool
    {
        if ($from === $to) return true;
        if (is_file($from)) {
            if (!is_dir(dirname($to)) && !@mkdir(dirname($to), self::mode($to), true) && !is_dir(dirname($to))) return false;
            if (!@rename($from, $to)) return false;
            self::keep($to);
            return true;
        }
        $a = self::key($from); $b = self::key($to);
        if ($a === null || $b === null || !self::on() || S3::size($a) < 0) return false;
        if (!S3::copy($a, $b)) return false;
        S3::delete($a);
        return true;
    }

    // ---- an owner's files: list, count, export, delete ----------------------------------------------------------------

    /** Everything an owner keeps: [key or server path => bytes]. */
    public static function files(string $kind, string|int $ref): array
    {
        $f = self::folder($kind, $ref, false);
        if ($f === '') return [];
        $out = [];
        foreach ([dirname(__DIR__, 2) . "/website/uploads/$kind/$f", dirname(__DIR__) . "/storage/$kind/$f", self::claimsRoot() . "/$kind/$f"] as $d) {
            if (!is_dir($d)) continue;
            foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS)) as $x) if ($x->isFile()) $out[$x->getPathname()] = (int) $x->getSize();
        }
        if (self::on()) $out += S3::list("$kind/$f/");
        return $out;
    }

    /** How much an owner keeps: [files, bytes]. */
    public static function usage(string $kind, string|int $ref): array
    {
        $all = self::files($kind, $ref);
        return [count($all), array_sum($all)];
    }

    /** Deletes everything an owner keeps (an account deleted for good, a business removed). Returns how many. */
    public static function wipe(string $kind, string|int $ref): int
    {
        $n = 0;
        foreach (array_keys(self::files($kind, $ref)) as $k) {
            if (str_starts_with($k, '/')) @unlink($k); else S3::delete($k);
            $n++;
        }
        return $n;
    }

    // ---- files from before owner folders ------------------------------------------------------------------------------

    /** Files still to move: from before owner folders (anywhere), or not in S3 yet: [path, bytes] each. */
    public static function oldFiles(): \Generator
    {
        $app = dirname(__DIR__);
        $dirs = [dirname($app) . '/website/uploads', "$app/storage/order-proofs", "$app/storage/order-files", "$app/storage/qr-logos", "$app/storage/cards", "$app/storage/biz-files", "$app/storage/internal", self::claimsRoot()];
        foreach (self::KINDS as $k) $dirs[] = "$app/storage/$k";
        foreach ($dirs as $d) {
            if (!is_dir($d)) continue;
            foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS)) as $f) {
                $p = $f->getPathname();
                if (!$f->isFile() || str_starts_with($f->getFilename(), '.') || str_contains(substr($p, strlen($d)), '/tmp/') || self::key($p) === null) continue;   // .htaccess, unfinished pieces
                yield [$p, (int) $f->getSize()];
            }
        }
    }

    /** What's left to move: [files on the server, their bytes, records naming a photo from before that isn't on the server]. */
    public static function oldCount(?PDO $pdo = null): array
    {
        $n = 0; $b = 0;
        if (self::on()) foreach (self::oldFiles() as [, $size]) { $n++; $b += $size; }
        $recs = 0;
        if ($pdo) foreach (self::legacyRecords($pdo, 100000) as $r) if (!is_file(self::web($r[4]))) $recs++;   // a photo on the server is counted with the files already
        return [$n, $b, $recs];
    }

    /** Records whose photo is still at a place from before: [table, key column, key, column, path, owner kind, owner, area]. */
    private static function legacyRecords(PDO $pdo, int $max): \Generator
    {
        $q = fn (string $c) => "($c LIKE '/uploads/hero/%' OR $c LIKE '/uploads/journeys/%' OR $c LIKE '/uploads/profile/%')";
        $n = 0;
        try {
            foreach ($pdo->query('SELECT id, owner_kind, owner_ref, path, card_path FROM hero_media WHERE ' . $q('path') . ' OR ' . $q('card_path'))->fetchAll(PDO::FETCH_ASSOC) as $r)
                foreach (['path', 'card_path'] as $c) if (preg_match('#^/uploads/(hero|journeys|profile)/#', (string) $r[$c]) && $n++ < $max)
                    yield ['hero_media', 'id', (int) $r['id'], $c, (string) $r[$c], $r['owner_kind'] === 'listing' ? 'businesses' : 'members', (int) $r['owner_ref'], 'photos'];
        } catch (PDOException) {}
        try {
            foreach ($pdo->query('SELECT m.id, j.author_id, m.path, m.card_path FROM journey_media m JOIN journeys j ON j.id = m.journey_id WHERE ' . $q('m.path') . ' OR ' . $q('m.card_path'))->fetchAll(PDO::FETCH_ASSOC) as $r)
                foreach (['path', 'card_path'] as $c) if (preg_match('#^/uploads/(hero|journeys|profile)/#', (string) $r[$c]) && $n++ < $max)
                    yield ['journey_media', 'id', (int) $r['id'], $c, (string) $r[$c], 'members', (int) $r['author_id'], 'journeys'];
        } catch (PDOException) {}
        try {
            foreach ($pdo->query("SELECT user_id, avatar_path, cover_path, details FROM member_profiles WHERE " . $q('avatar_path') . ' OR ' . $q('cover_path') . " OR details LIKE '%/uploads/profile/%'")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                foreach (['avatar_path', 'cover_path'] as $c) if (preg_match('#^/uploads/(hero|journeys|profile)/#', (string) $r[$c]) && $n++ < $max)
                    yield ['member_profiles', 'user_id', (int) $r['user_id'], $c, (string) $r[$c], 'members', (int) $r['user_id'], 'profile'];
                $src = (string) ((json_decode((string) $r['details'], true) ?: [])['_avatar_src'] ?? '');
                if (preg_match('#^/uploads/(hero|journeys|profile)/#', $src) && $n++ < $max) yield ['member_profiles', 'user_id', (int) $r['user_id'], 'details._avatar_src', $src, 'members', (int) $r['user_id'], 'profile'];
            }
        } catch (PDOException) {}
    }

    /**
     * Puts files from before in their owner's folder and in S3, a batch at a time (a web request has a time limit): up
     * to $max files or $seconds. Photos named in records move with their record (updated to the new address); files
     * named by number (order proofs, logos, cards, business files, claim documents) move to where their library now
     * looks. A file nobody's record names is moved to S3 as it was. Returns what moved, what wouldn't go (it stays
     * where it is and still works), and what's left.
     */
    public static function moveOld(PDO $pdo, int $max = 40, int $seconds = 20): array
    {
        if (!self::on()) throw new RuntimeException('S3 isn\'t set up.');
        $t0 = time(); $moved = 0; $stuck = 0; $bytes = 0; $missing = 0;
        $more = function () use (&$moved, &$stuck, &$missing, $max, $t0, $seconds) { return $moved + $stuck + $missing < $max && time() - $t0 < $seconds; };
        // 1. photos named in records
        foreach (self::legacyRecords($pdo, $max) as [$table, $idCol, $id, $col, $old, $kind, $ref, $area]) {
            if (!$more()) break;
            if (!$ref) { $stuck++; continue; }
            $new = self::path($kind, $ref, $area, basename($old), true);
            $size = is_file(self::web($old)) ? (int) filesize(self::web($old)) : 0;
            $gone = !is_file(self::web($old)) && (($k = self::key(self::web($old))) === null || S3::size($k) < 0);   // a record naming a photo that's nowhere
            if ($gone) $missing++;
            elseif (!self::relocate(self::web($old), $new)) { error_log('Store moveOld: ' . $old . ' did not move'); $stuck++; continue; }
            $rel = self::address($new);
            if ($col === 'details._avatar_src') {
                $st = $pdo->prepare('SELECT details FROM member_profiles WHERE user_id = ?'); $st->execute([$id]);
                $d = json_decode((string) $st->fetchColumn(), true) ?: []; $d['_avatar_src'] = $rel;
                $pdo->prepare('UPDATE member_profiles SET details = ? WHERE user_id = ?')->execute([json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $id]);
            } else $pdo->prepare("UPDATE $table SET $col = ? WHERE $idCol = ? AND $col = ?")->execute([$rel, $id, $old]);
            if (!$gone) { $moved++; $bytes += $size; }
        }
        // 2. files on the server: named by number, or already in their owner's folder but not in S3 yet (once every record's
        //    photo has moved, so a photo from before still named by a record isn't moved twice)
        $app = dirname(__DIR__); $logos = [];
        if ($more()) foreach (self::oldFiles() as [$p, $size]) {
            if (!$more()) break;
            [$to, $after] = self::newPlace($pdo, $p, $app);
            if ($to === null) { self::keep($p); if (is_file($p)) { $stuck++; continue; } $moved++; $bytes += $size; continue; }   // nobody's record: to S3 as it was
            if (!self::relocate($p, $to)) { $stuck++; continue; }
            if ($after) $after();   // its record now names the new place
            if (is_file($to)) { $stuck++; continue; }   // in its owner's folder, but S3 didn't take it yet
            $moved++; $bytes += $size;
            if (preg_match('#/qr-logos/(\d+)\.png$#', $to, $m)) $logos[] = (int) $m[1];
        }
        if ($logos) {   // so the GO Codes pages know these have a logo without looking
            $st = $pdo->prepare('SELECT style FROM qr_issued WHERE id = ?'); $up = $pdo->prepare('UPDATE qr_issued SET style = ? WHERE id = ?');
            foreach ($logos as $id) { $st->execute([$id]); $sty = $st->fetchColumn(); if ($sty !== false) $up->execute([json_encode(['has_logo' => 1] + (json_decode((string) $sty, true) ?: [])), $id]); }
        }
        [$left, $leftBytes, $recs] = self::oldCount($pdo);
        return ['moved' => $moved, 'bytes' => $bytes, 'stuck' => $stuck, 'missing' => $missing, 'left' => $left + $recs, 'left_bytes' => $leftBytes];
    }

    /** Where a file goes now: [its library's place for it, or null when no record names it; what to update once it's there]. */
    private static function newPlace(PDO $pdo, string $p, string $app): array
    {
        $cp = self::clean($p);
        $web = self::clean(dirname($app) . '/website/uploads') . '/';
        if (str_starts_with($cp, $web)) return [preg_match('#^(' . implode('|', self::KINDS) . ')/[a-f0-9]{16}/#', substr($cp, strlen($web))) ? $p : null, null];   // photos from before that no record names: as they were
        $rel = substr($cp, strlen(self::clean($app) . '/storage/'));
        try {
            if (preg_match('#^order-(proofs|files)/(\d+)/(\d+)\.\w+$#', $rel, $m)) {
                require_once __DIR__ . '/ClientOrders.php';
                $st = $pdo->prepare('SELECT * FROM ' . ($m[1] === 'proofs' ? 'order_proofs' : 'order_files') . ' WHERE id = ? AND order_id = ?'); $st->execute([(int) $m[3], (int) $m[2]]);
                $r = $st->fetch(PDO::FETCH_ASSOC);
                return [$r ? ($m[1] === 'proofs' ? ClientOrders::proofPlace($pdo, $r) : ClientOrders::filePlace($pdo, $r)) : null, null];
            }
            if (preg_match('#^qr-logos/(\d+)\.png$#', $rel, $m)) { require_once __DIR__ . '/QrIssue.php'; return [QrIssue::logoPlace($pdo, (int) $m[1]), null]; }
            if (preg_match('#^cards/(\d+)-([12])\.jpg$#', $rel, $m)) return [self::internal('cards', "$m[1]-$m[2].jpg"), null];
            if (preg_match('#^biz-files/(\d+)/(\d+)\.(\w+)$#', $rel, $m)) return [self::path('businesses', (int) $m[1], 'quote-files', "$m[2].$m[3]", false), null];
            $claims = self::clean(self::claimsRoot()) . '/';
            if (str_starts_with(self::clean($p), $claims) && preg_match('#^\d{4}/\d{2}/([a-f0-9]{24}\.\w{3,4})$#', substr(self::clean($p), strlen($claims)), $m)) {
                $st = $pdo->prepare('SELECT id, user_id FROM listing_claims WHERE doc_path = ?'); $st->execute([substr(self::clean($p), strlen($claims))]);
                $c = $st->fetch(PDO::FETCH_ASSOC);
                if (!$c || !$c['user_id']) return [null, null];
                $to = self::claimsRoot() . '/members/' . self::folder('members', (int) $c['user_id']) . '/' . $m[1];
                return [$to, fn () => $pdo->prepare('UPDATE listing_claims SET doc_path = ? WHERE id = ?')->execute([substr($to, strlen(self::claimsRoot()) + 1), (int) $c['id']])];
            }
        } catch (Throwable $x) { error_log('Store newPlace ' . $rel . ': ' . $x->getMessage()); return [null, null]; }
        return [$p, null];   // already in its owner's folder (or ours): just to S3
    }

    private static function type(string $p): string
    {
        $t = function_exists('mime_content_type') ? (string) @mime_content_type($p) : '';
        return $t !== '' ? $t : 'application/octet-stream';
    }
}
