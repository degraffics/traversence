/* js/tv-conf.js — the confidence ring on listing cards in search and lists (decisions/0133). Every card that carries
   data-link="business:<id>" gets a ring: at the top of its actions column when it has one (.dr-acts, .gd-acts), else
   beside its Link button. One request for all the cards on screen; cards drawn later (search, the map) are picked up
   too. Tapping it opens the listing at How we know. The number is spoken, so it never rests on colour alone. */
(function () {
  if (window.TvConf) return;
  var seen = {}, cache = {}, wait = null;
  function ring(id, c) {
    var r = 12.5, len = 2 * Math.PI * r, fill = len * c.score / 100;
    var a = document.createElement('a');
    a.className = 'tv-conf'; a.href = '/listing/view.php?id=' + id + '#lv-know';
    var say = 'How sure we are: ' + c.score + ' out of 100, ' + c.label + '. Show how we know.';
    a.title = say; a.setAttribute('aria-label', say);
    a.innerHTML = '<svg viewBox="0 0 30 30" width="30" height="30" aria-hidden="true"><circle cx="15" cy="15" r="12.5" fill="#FFFBF2" stroke="#E8DCC2" stroke-width="3"/>'
      + '<circle cx="15" cy="15" r="12.5" fill="none" stroke="' + c.colour + '" stroke-width="3" stroke-linecap="round" stroke-dasharray="' + fill.toFixed(2) + ' ' + len.toFixed(2) + '" transform="rotate(-90 15 15)"/>'
      + '<text x="15" y="15" text-anchor="middle" dominant-baseline="central" font-size="10.5" font-weight="700" fill="#3E2B1F" font-family="system-ui,sans-serif">' + c.score + '</text></svg>';
    return a;
  }
  function chip(id, c) {   // the score as a small chip: the number, its colour, and ⓘ to how we know
    var a = document.createElement('a');
    a.className = 'tv-conf tv-conf-chip'; a.href = '/listing/view.php?id=' + id + '#lv-know';
    var say = 'How sure we are: ' + c.score + ' out of 100, ' + c.label + '. Show how we know.';
    a.title = say; a.setAttribute('aria-label', say);
    a.style.cssText = 'display:inline-flex;align-items:center;gap:.2rem;border:1px solid ' + c.colour + ';border-radius:999px;padding:0 .45rem;font:700 .76rem system-ui,sans-serif;color:#3E2B1F;text-decoration:none;background:#FFFBF2;line-height:1.5';
    a.innerHTML = '<span aria-hidden="true" style="width:.5rem;height:.5rem;border-radius:50%;background:' + c.colour + '"></span>' + c.score + ' <span aria-hidden="true" style="font-weight:400;opacity:.7">\u24d8</span>';
    return a;
  }
  function place(host, id) {
    if (host.querySelector('.tv-conf')) return;
    var c = cache[id]; if (!c) return;
    var hd = host.querySelector('.dr-hd');
    if (hd) { hd.appendChild(chip(id, c)); return; }   // Get Local's cards: a chip beside the name (Jason, 2026-11-19, Change 2)
    var a = ring(id, c), acts = host.querySelector('.dr-acts, .gd-acts, .tvm-acts');
    if (acts) { acts.insertBefore(a, acts.firstChild); return; }
    a.setAttribute('data-link-extra', ''); a.classList.add('tv-extra');
    var corner = null; for (var k = 0; k < host.children.length; k++) if (host.children[k].classList.contains('tv-corner')) corner = host.children[k];
    (corner || host).insertBefore(a, corner ? corner.firstChild : null);
  }
  function scan() {
    var hosts = document.querySelectorAll('[data-link-host]'), want = [];
    Array.prototype.forEach.call(hosts, function (h) {
      if (h.closest('.lv-card') || h.querySelector('.tv-conf')) return;   // the listing's own page has its own ring
      var s = h.querySelector('[data-link^="business:"]'); if (!s) return;
      var id = +s.getAttribute('data-link').split(':')[1]; if (!id) return;
      if (cache[id]) place(h, id); else if (!seen[id]) { seen[id] = 1; want.push(id); }
    });
    for (var i = 0; i < want.length; i += 100) (function (ids) {
      fetch('/api/listing-confidence.php?ids=' + ids.join(','), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
        if (!d || !d.ok) return;
        Object.keys(d.scores || {}).forEach(function (k) { cache[k] = d.scores[k]; });
        Array.prototype.forEach.call(document.querySelectorAll('[data-link-host]'), function (h) {
          var s = h.querySelector('[data-link^="business:"]'); if (s) place(h, +s.getAttribute('data-link').split(':')[1]);
        });
      }).catch(function () {});
    })(want.slice(i, i + 100));
  }
  var st = document.createElement('style');
  // its own size and look, whatever the card does to the icons beside it (a guide card shrinks them to 15px)
  st.textContent = 'a.tv-conf{display:inline-flex!important;align-items:center;justify-content:center;width:30px!important;height:30px!important;border:0!important;background:none!important;padding:0!important;border-radius:999px;flex:none;text-decoration:none}'
    + '.tv-conf:focus-visible{outline:2px solid #F59E0B;outline-offset:2px}a.tv-conf svg{display:block;width:30px!important;height:30px!important}';
  document.head.appendChild(st);
  function soon() { clearTimeout(wait); wait = setTimeout(scan, 120); }
  window.TvConf = { scan: scan };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scan); else scan();
  new MutationObserver(soon).observe(document.documentElement, { childList: true, subtree: true });
})();
