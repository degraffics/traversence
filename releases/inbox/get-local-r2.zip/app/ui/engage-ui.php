<?php
// includes/engage-ui.php — the standard engagement on content pages (decisions/0058 §20): the Engage bar under the
// page's header (views, likes, comments, Share, Report) and the Comments section at the end, with one level of replies
// (decisions/0172 §2.3). js/engage.js runs both.
//   echo tv_engage_bar($pdo, 'exp', '12', ['title' => 'Paddle Lyman Lake', 'report' => 'experience:12']);
//   echo tv_engage_comments($pdo, 'exp', '12');
declare(strict_types=1);

require_once __DIR__ . '/../lib/Engage.php';

function tv_engage_assets(): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    return <<<'H'
<style>
  .eg-bar{display:flex;flex-wrap:wrap;align-items:center;gap:.35rem;margin:.6rem 0 .2rem}
  .eg-bar .eg-n{display:inline-flex;align-items:center;gap:.3rem;font-size:.8rem;font-weight:700;color:var(--tv-meta);margin-right:.2rem;font-variant-numeric:tabular-nums}.eg-n svg{width:16px;height:16px}
  .eg-b{display:inline-flex;align-items:center;gap:.3rem;border:1px solid var(--tv-line-strong);background:var(--tv-card-a);color:var(--tv-ink);border-radius:999px;padding:.28rem .7rem;font:inherit;font-size:.8rem;font-weight:600;cursor:pointer;text-decoration:none;line-height:1.2}
  .eg-b:hover{border-color:var(--tv-icon,#B45309)}.eg-b svg{width:15px;height:15px;color:var(--tv-icon,#B45309)}
  .eg-b[aria-pressed="true"]{background:var(--tv-sage);border-color:var(--tv-sage);color:var(--tv-umber);box-shadow:0 0 0 2px rgba(143,188,168,.3)}.eg-b[aria-pressed="true"] svg{color:var(--tv-umber)}
  .eg-b.r{margin-left:auto;color:var(--tv-meta);font-weight:500}
  .eg-sec{margin:1.4rem 0 .5rem}.eg-sec h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.2rem;color:var(--tv-ink);margin:0 0 .5rem}
  .eg-cm{background:var(--tv-card-a);border:1px solid var(--tv-line);border-radius:.7rem;padding:.55rem .75rem;margin-bottom:.4rem}
  .eg-cm b{font-size:.86rem;color:var(--tv-ink)}.eg-cm small{color:var(--tv-meta);font-size:.75rem;margin-left:.4rem}.eg-cm p{margin:.25rem 0 0;font-size:.9rem;color:var(--tv-ink);white-space:pre-line}
  .eg-re{margin-left:1.1rem;border-left:3px solid var(--tv-line-strong)}.eg-team{display:inline-block;margin-left:.35rem;font-size:.72rem;font-weight:700;color:var(--tv-link);background:var(--tv-card-a);border-radius:999px;padding:.05rem .45rem}
  .eg-rf{margin:.2rem 0 .5rem 1.1rem}.eg-rf .eg-in{min-height:3rem}
  .eg-cm button{float:right;border:0;background:none;color:var(--tv-meta);font-size:.75rem;cursor:pointer;text-decoration:underline;margin-left:.4rem}
  .eg-in{width:100%;box-sizing:border-box;border:1px solid var(--tv-line-strong);border-radius:.6rem;padding:.5rem .6rem;font:inherit;font-size:.9rem;background:var(--tv-field);min-height:4.5rem}
  .eg-box{margin-top:.4rem}.eg-fake{display:block;text-align:left;color:var(--tv-meta);cursor:text;min-height:2.8rem!important}
  .eg-grow{min-height:2.8rem;transition:min-height .15s}.eg-grow:focus,.eg-grow:not(:placeholder-shown){min-height:6rem}
  .eg-starters{display:flex;flex-wrap:wrap;gap:.35rem;margin:.45rem 0 .1rem}.eg-st{border:1px solid var(--tv-line-strong);background:var(--tv-card-a);color:var(--tv-ink);border-radius:999px;padding:.25rem .7rem;font:500 .82rem var(--tv-font-ui);cursor:pointer}
  .eg-st:hover{border-color:var(--tv-link);color:var(--tv-link)}.eg-row{margin:.4rem 0 0}
  .eg-note{font-size:.8rem;color:var(--tv-meta);margin:.3rem 0}.eg-note a{color:var(--tv-link)}
  .eg-rep{background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:.7rem;padding:.6rem .75rem;margin:.5rem 0}.eg-rep select,.eg-rep input{font:inherit;font-size:.85rem;border:1px solid var(--tv-line-strong);border-radius:.45rem;padding:.3rem .4rem;margin:.2rem 0;max-width:100%}
</style>
<script src="/js/engage.js" defer></script>
H;
}

/** The bar under a page's header. $o: title (for Share), likes (default true), comments (default true), report ("experience:12"). */
function tv_engage_bar(PDO $pdo, string $kind, string $ref, array $o = []): string
{
    $uid = Auth::currentUserId();
    $views = Engage::views($pdo, $kind, $ref);
    $ic = fn (string $p) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
    $h = tv_engage_assets() . '<div class="eg-bar" data-eg-kind="' . tv_e($kind) . '" data-eg-ref="' . tv_e($ref) . '" data-eg-title="' . tv_e((string) ($o['title'] ?? '')) . '">';
    if ($views > 0) $h .= '<span class="eg-n" title="' . number_format($views) . ' ' . ($views === 1 ? 'visit' : 'visits') . ' saw this page" aria-label="' . number_format($views) . ' views">'
        . $ic('<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>') . '<span>' . number_format($views) . '</span></span>';
    if ($o['likes'] ?? true) {
        if ($uid) $on = Engage::liked($pdo, $kind, $ref, $uid);
        else { require_once __DIR__ . '/../lib/Guest.php'; $on = !empty(Guest::liked()[$kind . ':' . $ref]); }   // this visit's own like (decisions/0009)
        $n = Engage::likes($pdo, $kind, $ref);
        $h .= '<button type="button" class="eg-b" data-eg-like aria-pressed="' . ($on ? 'true' : 'false') . '" title="Like">' . $ic('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>') . '<span>' . $n . '</span></button>';
    }
    if ($o['comments'] ?? true) $h .= '<a class="eg-b" href="#comments" title="Comments">' . $ic('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>') . '<span>' . Engage::commentCount($pdo, $kind, $ref) . '</span></a>';
    $h .= '<button type="button" class="eg-b" data-eg-share title="Share">' . $ic('<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/>') . '<span>Share</span></button>';
    // the page's QR code, on its trvgo.us address (decisions/0094; js/short-link.js)
    $h .= '<button type="button" class="eg-b" data-qr title="QR code" aria-label="QR code for this page">' . $ic('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4v-3"/>') . '</button>';
    if (!empty($o['report'])) $h .= '<button type="button" class="eg-b r" data-eg-report="' . tv_e((string) $o['report']) . '">Report</button>';
    return $h . '</div>';
}

/** One comment's card: Remove (the writer, staff), Report, Reply (a comment, not a reply); a team member named with the business. */
function tv_engage_comment_card(array $c, ?int $uid, bool $tidy, bool $canReply): string
{
    $mine = $uid && (int) $c['user_id'] === $uid;
    return '<div class="eg-cm' . (!empty($c['parent_id']) ? ' eg-re' : '') . '" data-c="' . (int) $c['id'] . '">' . ($mine || $tidy ? '<button type="button" data-eg-del="' . (int) $c['id'] . '">Remove</button>' : '')
        . ($uid && !$mine ? '<button type="button" data-eg-rep="' . (int) $c['id'] . '">Report</button>' : '')
        . ($canReply && empty($c['parent_id']) ? '<button type="button" data-eg-reply="' . (int) $c['id'] . '">Reply</button>' : '')
        . '<b>' . tv_e((string) $c['name']) . '</b>' . (!empty($c['team']) ? '<span class="eg-team">' . tv_e((string) $c['team']) . '</span>' : '')
        . '<small>' . tv_e(date('M j, Y', strtotime((string) $c['created_at']))) . '</small><p>' . tv_e((string) $c['body']) . '</p></div>';
}

/** The Comments section: public comments with one level of replies, the form (signed in, 18 or older), Remove for the writer and staff, Report, Reply. */
function tv_engage_comments(PDO $pdo, string $kind, string $ref, array $o = []): string
{
    $title = trim((string) ($o['title'] ?? '')); $starters = array_values(array_filter(array_map('strval', (array) ($o['starters'] ?? []))));
    $uid = Auth::currentUserId();
    $tidy = Engage::canTidy($pdo, $uid);
    $list = Engage::comments($pdo, $kind, $ref);
    $canReply = $uid !== null && Engage::repliesReady($pdo);
    $kids = [];
    foreach ($list as $c) if (!empty($c['parent_id'])) $kids[(int) $c['parent_id']][] = $c;
    $h = tv_engage_assets() . '<section class="eg-sec" id="comments" data-eg-kind="' . tv_e($kind) . '" data-eg-ref="' . tv_e($ref) . '"><h2>Comments</h2><div data-eg-list>';
    if (!$list) $h .= '<p class="eg-note" data-eg-none>No comments yet: be the first.</p>';
    foreach ($list as $c) {
        if (!empty($c['parent_id'])) continue;   // drawn under its comment
        $h .= '<div class="eg-th" data-th="' . (int) $c['id'] . '">' . tv_engage_comment_card($c, $uid, $tidy, $canReply);
        foreach ($kids[(int) $c['id']] ?? [] as $r) $h .= tv_engage_comment_card($r, $uid, $tidy, $canReply);
        $h .= '</div>';
    }
    $h .= '</div>';
    // the box that invites a comment, open right here (Jason approved, 2026-11-19): it grows when tapped; a guest's tap
    // asks them to sign in (js/tv-join.js), then back to the comments; starters under it; "Comments are public" as a note
    $ask = $title !== '' ? 'Been to ' . $title . '? Share a tip…' : 'Been here? Share a tip…';
    $st = '';
    if ($starters) { $st = '<p class="eg-starters" aria-label="Start with">'; foreach ($starters as $w) $st .= '<button type="button" class="eg-st" data-eg-start="' . tv_e($w) . '">' . tv_e($w) . '</button>'; $st .= '</p>'; }
    if (!$uid) {
        $need = ' data-needs-account="Comments come back to you: replies, edits and removing them. Create a free account (it takes a minute) to comment." data-next="' . tv_e((string) ($_SERVER['REQUEST_URI'] ?? '/') . '#comments') . '"';
        $h .= '<div class="eg-box"><button type="button" class="eg-in eg-fake"' . $need . '>' . tv_e($ask) . '</button>'
            . ($starters ? str_replace('class="eg-st"', 'class="eg-st"' . $need, $st) : '')
            . '<p class="eg-note">Comments are public. You need to be 18 or older.</p></div>';
    } else {
        require_once __DIR__ . '/../lib/AgeGate.php';
        $h .= '<form data-eg-form class="eg-box"><textarea class="eg-in eg-grow" maxlength="2000" rows="1" placeholder="' . tv_e($ask) . '" aria-label="' . tv_e($ask) . '" required></textarea>' . $st
            . (!AgeGate::confirmed($pdo, $uid) ? '<label class="eg-note"><input type="checkbox" data-eg-age required> I am 18 or older</label>' : '')
            . '<p class="eg-row"><button class="eg-b" type="submit">Post comment</button> <span class="eg-note" data-eg-msg></span></p><p class="eg-note">Comments are public.</p></form>';
    }
    return $h . '</section>';
}
