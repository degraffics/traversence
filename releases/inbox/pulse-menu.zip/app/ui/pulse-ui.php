<?php
// app/ui/pulse-ui.php — the admin Pulse (decisions/0105, Jason's mockup of 2026-10-21): workspaces 1 and 2 on one screen.
//   header     the Pulse mark, "who you're working as" (Platform Admin, or a department), count chips (Operational
//              Queues, Alerts, Order Mgmt, System Health, Mine, Resolved), the bell, Stream settings, + and search
//   top row    Quick Actions & Navigation and a box to post to the team, and Your day, both opening collapsed. The
//              Operational Task Queue went (decisions/0172): the bell beside the chips (critical, escalated to you) and the
//              site's bell list replace it.
//   stream     the Unified Communications Hub: source, severity, subject with its action, received. One row is one thing
//              (decisions/0172): a bundling case (the engine's "needs a person", Site health) shows a row per thing, each from
//              its sender, acting through its case. Each row has the seven icons (read or unread, pass it on, pin, escalate,
//              file, add to: Follow up, importance, tags; open) and the person's own views (Inbox, Pinned, Follow up,
//              Archived, folders; /user/api/marks.php), and opens in place under itself: the case's panel, its steps'
//              buttons acting there. Work on it carries it to the drawer.
//   drawer     the case: details, SLA, Quick comment with Post (reply to the sender, or a note to the team), Escalate,
//              Assign, Mark resolved, History, and the tool itself
declare(strict_types=1);

require_once __DIR__ . '/../lib/Pulse.php';
require_once __DIR__ . '/../lib/Workspaces.php';
require_once __DIR__ . '/app-shell.php';   // tv_icon()

function tv_pulse_ago(string $t): string
{
    if ($t === '') return '';
    $s = time() - strtotime($t);
    if ($s < 0) return 'today';
    return $s < 3600 ? max(1, (int) round($s / 60)) . ' min ago' : ($s < 86400 ? (int) round($s / 3600) . ' h ago' : (int) round($s / 86400) . ' d ago');
}

/** "1 h 20 min left" or "Over by 3 h"; '' without a clock. */
function tv_pulse_sla(array $it): string
{
    if (!$it['sla_due'] || $it['state'] === 'done') return '';
    $s = strtotime($it['sla_due']) - time();
    $fmt = function (int $s): string { $s = abs($s); $h = intdiv($s, 3600); $m = intdiv($s % 3600, 60); return $h >= 48 ? round($h / 24) . ' d' : ($h ? $h . ' h' . ($m ? ' ' . $m . ' min' : '') : max(1, $m) . ' min'); };
    return $s >= 0 ? $fmt($s) . ' left' : 'Over by ' . $fmt($s);
}

/**
 * Quick Actions (Jason, 2026-10-21): each opens its tool in a side panel over the dashboard (full screen on a phone),
 * so a quick task is done without leaving; "Open the full page" is there when it isn't quick. Closing after the tool
 * saved something refreshes the board.
 */
function tv_pulse_quick(PDO $pdo, ?array $staff): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $acts = [   // [area it needs, icon, label, the tool's own page]
        ['ecommerce', 'orders', 'Order management', '/admin/backoffice/production', true],   // its own page (orders aren't always in the stream: Jason, 2026-10-30)
        ['sales', 'camera', 'Scan a card', '/admin/sales.php?sec=cards'],
        ['ecommerce', 'plus', 'New client order', '/admin/client-order.php?new=1'],
        ['sales', 'contact', 'Calls today', '/admin/sales.php?sec=calls'],
        ['listings', 'search', 'Find a listing', '/admin/listings.php'],
        ['listings', 'store', 'Add a listing', '/admin/listing-add.php'],
        ['safety', 'shield', 'Review reports', '/admin/reports.php'],
        ['ecommerce', 'qr', 'GO Codes', '/admin/short-codes.php'],
        ['settings', 'settings', 'System settings', '/admin/config/settings'],
    ];
    $h = '<ul class="pq-links">';
    foreach ($acts as $act) { [$area, $icon, $label, $url] = $act; $page = !empty($act[4]);
        if (Workspaces::allowsArea($staff, $area, $pdo)) $h .= '<li><a href="' . $e($url) . '"' . ($page ? ' target="_top"' : ' data-qa="' . $e(tv_admin_embed_url($url)) . '" data-qa-title="' . $e($label) . '"') . '><span class="pq-li" aria-hidden="true">' . tv_icon($icon, 'pu-svg') . '</span>' . $e($label) . '</a></li>'; }
    $h .= '</ul>';
    ob_start(); ?>
<style>
  .qa-p{position:fixed;top:0;right:0;bottom:0;width:min(44rem,100%);z-index:1850;background:#FFFBF2;border-left:1px solid #CBB98D;box-shadow:-18px 0 40px -20px rgba(0,0,0,.45);display:flex;flex-direction:column}
  .qa-p[hidden]{display:none}
  .qa-bar{display:flex;align-items:center;gap:.6rem;padding:.55rem .8rem;background:#3E2B1F;color:#FFF8EA}
  .qa-bar b{flex:1;font:700 1.05rem var(--tv-font-head,Georgia,serif);min-width:0}.qa-bar a{color:#F3DDB0;font-size:.88rem;text-decoration:underline;white-space:nowrap}
  .qa-x{width:34px;height:34px;border-radius:999px;border:1px solid rgba(255,248,234,.45);background:transparent;color:#FFF8EA;font-size:1.3rem;cursor:pointer;flex:none}
  .qa-p iframe{flex:1;width:100%;border:0;background:#F6EEDC}
</style>
<aside class="qa-p" id="qa-p" hidden role="dialog" aria-label="Quick action">
  <div class="qa-bar"><b id="qa-t"></b><a id="qa-full" href="#" target="_top">Open the full page ↗</a><button type="button" class="qa-x" id="qa-x" aria-label="Close" title="Close">×</button></div>
  <iframe id="qa-f" title="Quick action"></iframe>
</aside>
<script>
(function () {
  var P = document.getElementById('qa-p'), F = document.getElementById('qa-f'), loads = 0;
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-qa]'); if (!a || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault(); loads = 0;
    document.getElementById('qa-t').textContent = a.getAttribute('data-qa-title');
    document.getElementById('qa-full').href = a.getAttribute('href');
    F.src = a.getAttribute('data-qa'); P.hidden = false;
  });
  F.addEventListener('load', function () { loads++; });   // a second load means the tool saved or moved on
  function close() { P.hidden = true; F.src = 'about:blank'; if (loads > 1) location.reload(); }
  document.getElementById('qa-x').addEventListener('click', close);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !P.hidden) close(); });
})();
</script>
<?php
    return $h . (string) ob_get_clean();
}

/**
 * What else comes in to this staff member, as rows beside the cases (decisions/0172 "Everything incoming is there"):
 *   - their own messages from the one dispatcher (Notify::forUser, not a business's): a mailbox that refused, the site's
 *     email failing, a task a teammate gave them, a follow-up come back (G6). Item 'comms:<id>'; it opens in place with its
 *     own body (/user/api/pulse-msg.php), and opening it reads it.
 *   - the mail of the mailboxes they read (Mailboxes::inbox: their own, or ours they oversee; one row per conversation,
 *     §4.7) (G7). Item 'mail:<id>'; it opens in place as Dashboard → My inbox shows it, which stays as a view of these rows.
 * Each is shaped like a Pulse item (key, source, severity, title, why, when…) plus 'kind' (comms|mail), so the stream's
 * sort, filters, views and the seven icons treat it as any other row.
 */
function tv_pulse_extra(PDO $pdo, int $uid): array
{
    $out = [];
    $base = ['state' => 'open', 'dept' => '', 'mine' => true, 'esc_to_me' => false, 'esc' => 0, 'who' => '', 'over' => false, 'sla_due' => null, 'action' => 'Open'];
    if (is_file(__DIR__ . '/../lib/Notify.php')) {
        require_once __DIR__ . '/../lib/Notify.php';
        try {
            foreach (Notify::forUser($pdo, $uid, null, 40) as $m) {
                $out[] = ['key' => 'comms:' . $m['id'], 'kind' => 'comms', 'id' => (int) $m['id'], 'source' => 'team', 'icon' => 'bell',
                    'severity' => Pulse::FROM_LEVEL[$m['level']] ?? 'update', 'title' => (string) $m['title'], 'why' => (string) $m['body'], 'from' => (string) $m['from'],
                    'when' => (string) $m['when'], 'unread' => (bool) $m['unread'], 'url' => (string) $m['url'], 'msg_kind' => (string) $m['kind']] + $base;
            }
        } catch (Throwable $x) { error_log('pulse extra comms: ' . $x->getMessage()); }
    }
    if (is_file(__DIR__ . '/../lib/Mailboxes.php')) {
        require_once __DIR__ . '/../lib/Mailboxes.php';
        try {
            if (Mailboxes::ready($pdo)) foreach (Mailboxes::inbox($pdo, $uid, 0, '', 50, 'inbox')['rows'] as $r) {
                $out[] = ['key' => 'mail:' . $r['id'], 'kind' => 'mail', 'id' => (int) $r['id'], 'source' => 'support', 'icon' => 'inbox',
                    'severity' => 'update', 'title' => ($r['subject'] !== '' ? $r['subject'] : '(no subject)') . ($r['count'] > 1 ? ' (' . $r['count'] . ')' : ''),
                    'why' => (string) $r['snippet'], 'from' => (string) $r['from'], 'from_addr' => (string) $r['from_addr'], 'mailbox' => (string) $r['mailbox'],
                    'when' => (string) $r['when'], 'unread' => (bool) $r['unread'], 'attach' => (bool) $r['attach'], 'url' => '/admin/dashboard/inbox#mail-' . $r['id']] + $base;
            }
        } catch (Throwable $x) { error_log('pulse extra mail: ' . $x->getMessage()); }
    }
    return $out;
}

/** The whole board. $focus 'stream' scrolls to the stream (workspace 2). */
function tv_pulse_board(PDO $pdo, ?array $staff, int $uid, string $focus = '', string $today = ''): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $t0 = microtime(true);
    $items = Pulse::items($pdo, $staff, $uid);
    // how long Pulse took to gather its rows, for the Control Board's "Pulse" part (Jason, 2026-11-19: "add Pulse's load-time
    // warning"): the time only, nothing about who opened it
    try { require_once __DIR__ . '/../lib/ControlSensor.php'; ControlSensor::pulseTimed($pdo, (int) round((microtime(true) - $t0) * 1000)); } catch (Throwable $x) {}
    $open = array_filter($items, fn ($i) => $i['state'] !== 'done');
    $cnt = fn (callable $f) => count(array_filter($open, $f));
    $chips = [   // Show: what no other control does (Jason, 2026-11-19: "Drop four, keep Mine+Resolved"; the funnels and Group cover the rest)
        'mine' => ['Mine', $cnt(fn ($i) => $i['mine'])],
        'done' => ['Resolved', count($items) - count($open)],
    ];
    $bell = $cnt(fn ($i) => $i['esc_to_me'] || $i['severity'] === 'critical' || !empty($i['over']));   // and overdue work (Jason, 2026-11-19: "bell alerts")
    // the stream shows every department's work; who sees what is Stream settings' routing (Jason, 2026-11-19: "Working as" removed)
    [$lv, $dep] = $staff ? Workspaces::levelOf($staff) : ['founder', ''];
    $data = [];
    foreach ($items as $it) $data[$it['key']] = $it + ['play' => Pulse::playbook($it), 'explain' => Pulse::explain($pdo, $it), 'ago' => tv_pulse_ago($it['when']), 'sla' => tv_pulse_sla($it),
        'received' => $it['when'] !== '' ? date('M j, g:i a', strtotime($it['when'])) : '', 'src_label' => Pulse::SOURCES[$it['source']][0]];
    // one row is one thing (decisions/0172 "Pulse: collect, organize, read"): a case that bundles many things (the engine's
    // "needs a person", Site health's findings) shows one row per thing, each from its sender, acting through the same
    // case (Pulse::manage on the bundle's key) so nothing about how each is answered changes
    // the row's seven icons, the same as the member's Pulse (js/tv-pulse.js), each managing the message (decisions/0172 "The row's icons")
    $ICONS = [['read', '<path d="M3 9l9 6 9-6"/><path d="M3 9l9-6 9 6v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>', 'Read or unread'],
        ['pass', '<path d="M14 5l7 6-7 6V13c-6 0-9 2-11 6 0-6 3-11 11-11z"/>', 'Pass it on: assign it to a teammate'],
        ['pin', '<path d="M9 3h6l-1 6 3 3v2H7v-2l3-3z"/><path d="M12 14v7"/>', 'Pin in your own list'],
        ['protect', '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>', 'Escalate'],
        ['file', '<path d="M3 6a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M12 10v6M9.5 13.5 12 16l2.5-2.5"/>', 'File it in a folder, or Archive'],
        ['add', '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>', 'Add to: Follow up, importance, tags'],
        ['open', '<path d="M5 8l7 8 7-8z" fill="currentColor"/>', 'Open it here']];
    // the same icons on a message or an email (decisions/0172's table): what each does there; '!' marks one that doesn't
    // apply, greyed with its reason (never hidden)
    $ICONK = ['comms' => ['pass' => 'Pass it on: forward it to a teammate or by email', 'protect' => '!Can\'t be reported: a message from the site. Its own buttons act on what it\'s about.',
                          'add' => 'Add to: Follow up, importance, tags, a task'],
              'mail' => ['pass' => 'Pass it on: forward it by email, from the mailbox it came to', 'protect' => 'Protect: junk, block the sender, report phishing',
                         'add' => 'Add to: Follow up, importance, tags, make it a case or a task, the sender to the Address Book', 'read' => 'Read or unread (kept in step with the mailbox)'],
              '' => ['add' => 'Add to: Follow up, importance, tags, a task, a note']];
    // the level as an icon (Jason, 2026-11-18: "severity could be handled with icons"): its shape and colour, its name on
    // hover and to screen readers; the order the Level column sorts by
    $SEVI = ['critical' => ['#B91C1C', '<circle cx="12" cy="12" r="9" fill="currentColor"/><path d="M12 7v6M12 16.5v.5" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/>'],
        'urgent' => ['#B45309', '<path d="M12 3l9.5 17h-19z" fill="currentColor"/><path d="M12 9.5v5M12 17.5v.3" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/>'],
        'alert' => ['#EA8A2E', '<path d="M12 2.5l9.5 9.5-9.5 9.5-9.5-9.5z" fill="currentColor"/><path d="M12 8v5M12 16v.3" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/>'],
        'update' => ['#8A7355', '<circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 11v5.5M12 7.8v.3" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>'],
        'event' => ['#2F6B55', '<circle cx="12" cy="12" r="5" fill="currentColor"/>'],
        'special' => ['#6D28D9', '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z" fill="currentColor"/>']];
    $SEVRANK = array_flip(array_keys(Pulse::SEVERITY));
    $sevIcon = fn (string $sv) => '<svg class="ps-svi" viewBox="0 0 24 24" style="color:' . ($SEVI[$sv][0] ?? '#8A7355') . '" aria-hidden="true">' . ($SEVI[$sv][1] ?? '') . '</svg>';
    $BUNDLES = ['engine:person' => 'The engine', 'sitehealth:open' => 'Site health'];
    $rowsOut = [];
    foreach ($items as $it) {
        if (!empty($it['children']) && is_array($it['children'])) {   // related alarms grouped by the Control Board (Jason, 2026-11-18; 0171 §8, 0172 note): one row with its count, opening in place to each alarm
            $kids = array_values(array_filter($it['children'], fn ($c) => is_array($c) && isset($c['key'])));
            $rowsOut[] = ['group' => count($kids)] + $it;
            foreach ($kids as $c) {
                $c += ['source' => $it['source'], 'severity' => $it['severity'], 'why' => '', 'when' => $it['when'], 'state' => 'open', 'dept' => $it['dept'] ?? '', 'mine' => false, 'esc_to_me' => false,
                    'esc' => 0, 'who' => '', 'over' => false, 'sla_due' => null, 'action' => 'Open', 'title' => ''];
                $data[$c['key']] = $c + ['play' => Pulse::playbook($c), 'explain' => Pulse::explain($pdo, $c), 'ago' => tv_pulse_ago((string) $c['when']), 'sla' => tv_pulse_sla($c),
                    'received' => $c['when'] !== '' ? date('M j, g:i a', strtotime((string) $c['when'])) : '', 'src_label' => Pulse::SOURCES[$c['source']][0] ?? 'System', 'group_of' => $it['key']];
                $rowsOut[] = ['child_of' => $it['key']] + $c;
            }
            continue;
        }
        if (!isset($BUNDLES[$it['key']]) || $it['state'] === 'done') { $rowsOut[] = $it; continue; }
        $subs = [];
        foreach ((array) $data[$it['key']]['play'] as $n => $st) {
            $a = $st['act'] ?? null;
            if (!$a || ($a[0] ?? '') === 'resolve') continue;
            $tag = is_string($a[1] ?? null) && preg_match('/^[A-Za-z0-9:_.@-]{1,80}$/', (string) $a[1]) ? (string) $a[1] : 'n' . $n;
            $sk = $it['key'] . ':' . $tag;
            $sub = ['key' => $sk, 'title' => (string) $st['t'], 'why' => (string) ($st['h'] ?? ''), 'from' => $BUNDLES[$it['key']]] + $it;
            $data[$sk] = ['key' => $sk, 'title' => $sub['title'], 'why' => $sub['why'], 'body' => $sub['why'], 'parent' => $it['key'], 'offset' => $n, 'play' => [$st]] + $data[$it['key']];
            $subs[] = $sub;
        }
        if ($subs) array_push($rowsOut, ...$subs); else $rowsOut[] = $it;
    }
    // the staff member's own messages and the mail they read, as rows beside the cases (G6, G7; tv_pulse_extra)
    $extra = tv_pulse_extra($pdo, $uid);
    foreach ($extra as $x) {
        $data[$x['key']] = ['key' => $x['key'], 'kind' => $x['kind'], 'id' => $x['id'], 'title' => $x['title'], 'why' => $x['why'], 'state' => '', 'esc' => 0, 'url' => $x['url'],
            'from' => $x['from'], 'from_addr' => $x['from_addr'] ?? '', 'mailbox' => $x['mailbox'] ?? '', 'severity' => $x['severity'], 'src_label' => $x['kind'] === 'mail' ? 'Mail' : 'Messages',
            'received' => $x['when'] !== '' ? date('M j, g:i a', strtotime($x['when'])) : '', 'play' => [], 'explain' => []];
        $rowsOut[] = $x;
    }
    // in the stream's own order (Pulse::items: open first, escalated to you, level, newest), the new rows placed by the same
    // rule; a group's alarms stay right under it
    $units = [];
    foreach ($rowsOut as $r) { if (isset($r['child_of']) && $units) $units[count($units) - 1][] = $r; else $units[] = [$r]; }
    $rank = array_flip(array_keys(Pulse::SEVERITY));
    $ord = fn (array $u) => [($u[0]['state'] ?? '') === 'done',   // the stream's own order: newest received first (Jason, 2026-11-19: "default is by when received"); the ! column sorts by importance
        -strtotime(($u[0]['when'] ?? '') ?: '2000-01-01')];
    usort($units, fn ($a, $b) => $ord($a) <=> $ord($b));
    $rowsOut = array_merge(...array_values($units ?: [[]]));
    $mailN = count(array_filter($extra, fn ($x) => $x['kind'] === 'mail' && $x['unread']));
    $deptOpts = '<option value="">Everyone</option>';
    foreach (Workspaces::DEPARTMENTS as $k => [$name]) $deptOpts .= '<option value="' . $k . '"' . ($k === $dep ? ' selected' : '') . '>' . $e($name) . '</option>';

    ob_start(); ?>
<style>
  .pb .sr-only,.pb-dr .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
  .pb,.pb-dr{--b:#3E2B1F;--br:#92400E;--am:#B45309;--sg:#8FBCA8;--cr:#FFFBF2;--pa:#F7EFDC;--ln:#EADFC4}
  .pb-head{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .7rem;margin-top:.4rem}
  .pb-title{margin:0;font:700 1.2rem var(--tv-font-head,Georgia,serif);color:var(--b)}.pb-q{flex:1 1 14rem;min-width:0;border:1px solid var(--tv-field-edge,#8D7E68);background:var(--tv-field,#F6F1E4);border-radius:999px;padding:.5rem .9rem;font-size:.95rem}
  .pb-pop{position:relative}.pb-pop>summary{list-style:none}.pb-pop>summary::-webkit-details-marker{display:none}.pb-pop[open]>summary{border-color:var(--tv-link)}
  .pb-popc{position:absolute;right:0;top:calc(100% + .35rem);z-index:45;width:min(26rem,calc(100vw - 2rem));max-height:75vh;overflow:auto;background:var(--tv-card-a,#F6F1E4);border:1px solid var(--tv-line-strong);border-radius:.8rem;box-shadow:var(--tv-shadow-lg);padding:.7rem .8rem}
  .pb-pop .pb-dim{display:none}.pb-pop[open] .pb-dim{display:block;position:fixed;inset:0;z-index:1500;background:rgba(42,27,18,.45)}
  .pb-pop[open] .pb-today{position:fixed;z-index:1501;left:50%;top:max(4vh,1rem);right:auto;transform:translateX(-50%);width:min(60rem,calc(100vw - 2rem));max-height:88vh;padding:1rem 1.1rem}   /* Your day, wide */
  .pb-x{position:absolute;top:.4rem;right:.5rem;width:34px;height:34px;border-radius:999px;border:1px solid var(--tv-line-strong);background:var(--tv-card-a,#F6F1E4);color:var(--tv-ink);font-size:1.3rem;line-height:1;cursor:pointer;z-index:2}
  .pb-newp .pb-popc{left:0;right:auto;width:min(24rem,calc(100vw - 2rem))}
  .pb-fddc,.pb-popc{position:absolute}.pb-fddc .pb-x,.pb-popc .pb-x{position:absolute;top:.35rem;right:.4rem;width:30px;height:30px;padding:0;border:1px solid var(--tv-line-strong);border-radius:999px;background:var(--tv-card-a,#F6F1E4);color:var(--tv-ink);font:400 1.15rem/1 var(--tv-font-ui);text-align:center}   /* every pop-up closes: × (Jason, 2026-11-19) */
  @media (max-width:767px){.pb-row2{position:relative;flex-wrap:wrap}.pb-row2 .pb-fdd,.pb-row2 .pb-pop{position:static}.pb-row2 .pb-fddc,.pb-row2 .pb-popc{position:absolute;left:0;right:0;top:calc(100% + .35rem);width:auto;min-width:0;max-width:none;z-index:60}}   /* on a phone the row's panels span the screen, never off its edge */
  .pb-fddc .pb-x:hover,.pb-popc .pb-x:hover{border-color:var(--tv-link);color:var(--tv-link)}.pb-fddc>.pb-fddh:first-of-type,.pb-popc>h3{padding-right:2.2rem}
  .pb-newl{display:flex;flex-direction:column;gap:.15rem;margin-top:.3rem}.pb-newl button,.pb-newl a{display:flex;flex-direction:column;align-items:flex-start;text-align:left;border:0;background:none;border-radius:.5rem;padding:.45rem .55rem;font:600 .95rem var(--tv-font-ui);color:var(--tv-ink);text-decoration:none;cursor:pointer}
  .pb-newl button:hover:not(:disabled),.pb-newl a:hover{background:var(--tv-sec,#EDE6D5)}.pb-newl small{font-weight:400;font-size:.8rem;color:var(--tv-meta)}.pb-newl button:disabled{cursor:default;color:var(--tv-meta)}.pb-newl button:disabled b{opacity:.6}
  .pb-back{border:0;background:none;padding:0 0 .35rem;font:600 .85rem var(--tv-font-ui);color:var(--tv-link);cursor:pointer}.pb-task label{display:block;font:600 .8rem var(--tv-font-ui);color:var(--tv-meta);margin:.45rem 0 .15rem}.pb-task select,.pb-task input{width:100%;padding:.4rem .5rem;border:1px solid var(--tv-field-edge,#CBB98D);border-radius:.45rem;background:var(--tv-field,#FFFBF2);font:inherit}.pb-task .pb-btn{margin-top:.6rem}
  .pb-popc h3{margin:0 0 .4rem;font:700 1rem var(--tv-font-head,Georgia,serif);color:var(--b)}
  .pb-row2{display:flex;align-items:center;gap:.5rem;margin:.55rem 0 .6rem}.pb-fdd{position:relative}.pb-fdd>summary{list-style:none}.pb-fdd>summary::-webkit-details-marker{display:none}
  .pb-fb{display:inline-flex;align-items:center;gap:.4rem;border:1px solid var(--tv-line-strong);background:var(--tv-card-a,#F6F1E4);color:var(--tv-ink);border-radius:999px;padding:.38rem .85rem;font:600 .92rem var(--tv-font-ui);cursor:pointer}.pb-fb .pu-svg{width:15px;height:15px;color:var(--tv-icon,#B45309)}
  .pb-fdd[open]>.pb-fb{border-color:var(--tv-link)}.pb-fddc{position:absolute;left:0;top:calc(100% + .35rem);z-index:45;width:min(30rem,calc(100vw - 2rem));background:var(--tv-card-a,#F6F1E4);border:1px solid var(--tv-line-strong);border-radius:.8rem;box-shadow:var(--tv-shadow-lg);padding:.6rem .7rem}
  .pb-fddh{margin:.2rem 0 .3rem;font:600 .78rem var(--tv-font-ui);color:var(--tv-meta)}.pb-fddc .ps-views{margin:0 0 .5rem}
  .pb-gddc{display:flex;flex-direction:column;width:auto;min-width:11rem}.pb-gddc button{border:0;background:none;text-align:left;padding:.42rem .55rem;border-radius:.4rem;font:500 .92rem var(--tv-font-ui);color:var(--tv-ink);cursor:pointer}
  .pb-gddc button:hover{background:var(--tv-sec,#EDE6D5)}.pb-gddc button[aria-checked=true]{font-weight:700;color:var(--tv-link)}.pb-gddc button[aria-checked=true]::before{content:'✓ '}
  .ps-ghead{grid-template-columns:1fr!important;grid-template-areas:none!important;background:var(--tv-sec,#EDE6D5);cursor:pointer}.ps-ghead .ps-gb{display:flex;align-items:center;gap:.5rem;border:0;background:none;padding:.15rem 0;font:700 .92rem var(--tv-font-ui);color:var(--tv-ink);cursor:pointer;text-align:left}
  .ps-ghead .ps-gcar{display:inline-block;transition:transform var(--tv-ease);color:var(--tv-meta)}.ps-ghead[aria-expanded=true] .ps-gcar{transform:rotate(90deg)}.ps-ghead .ps-gcount{font:700 .78rem var(--tv-font-ui);border-radius:999px;padding:.05rem .5rem;background:var(--tv-card-a,#F6F1E4);border:1px solid var(--tv-line)}
  .ps-row[data-gm]>.ps-src{padding-left:.8rem}
  .pb-b2{display:inline-flex;align-items:center;gap:.3rem;border:1px solid var(--tv-line-strong);background:var(--tv-card-a,#F6F1E4);color:var(--tv-link);border-radius:999px;padding:.38rem .8rem;font:600 .92rem var(--tv-font-ui);cursor:pointer}.pb-b2 .pu-svg{width:15px;height:15px}
  .pb-mark{width:56px;height:56px;border-radius:999px;border:2px solid #CBB98D;background:var(--cr);color:var(--am);display:flex;align-items:center;justify-content:center;flex:none}
  .pb-mark svg{width:30px;height:30px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
  .pb-chips{display:flex;flex-wrap:wrap;gap:.35rem;flex:1 1 20rem}
  .pb-chip{border:1px solid #CBB98D;background:var(--cr);color:var(--b);border-radius:999px;padding:.3rem .7rem;font-size:.92rem;font-weight:600;cursor:pointer;white-space:nowrap}
  .pb-chip[aria-pressed=true]{background:#F0B57A;border-color:#E39A52;color:#3E2B1F}
  .pb-chip.hot b{color:#B91C1C}
  .pb-tools{display:flex;gap:.4rem;margin-left:auto}
  .pb-ic{width:36px;height:36px;border-radius:999px;border:1px solid #CBB98D;background:var(--cr);color:var(--am);display:inline-flex;align-items:center;justify-content:center;position:relative;cursor:pointer;padding:0;text-decoration:none}
  .pb-ic[aria-pressed=true]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .pb-ic i{position:absolute;top:-6px;right:-6px;background:#DC2626;color:#fff;font:700 .72rem system-ui;border-radius:999px;padding:.05rem .35rem;font-style:normal}
  .pu-svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
  .pb-search{display:flex;align-items:center;gap:.5rem;margin:.6rem 0}
  .pb-search input{flex:1;min-width:0;background:var(--cr);border:1px solid #CBB98D;border-radius:999px;padding:.5rem .9rem;font-size:1rem;color:var(--b)}
  .pb-top{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:.6rem;margin-top:.4rem}
  .pb-panel{background:var(--pa);border:1px solid var(--ln);border-radius:.8rem;padding:.7rem .8rem;min-width:0}
  .pb-panel>summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between}
  .pb-panel>summary::-webkit-details-marker{display:none}
  .pb-panel>summary::after{content:"▾";color:#8A7355;font-size:1rem;transition:transform .15s}
  .pb-panel:not([open])>summary::after{transform:rotate(-90deg)}
  .pb-panel:not([open]) h2{margin:0}
  .pb-cnt{font:700 .8rem system-ui;background:#DC2626;color:#fff;border-radius:999px;padding:.05rem .45rem;vertical-align:middle;margin-left:.3rem}
  .pb-top{align-items:start;margin:0 0 .6rem;grid-template-columns:minmax(0,1fr)}
  .pb-today{margin:0 0 .6rem}
  .pb-panel h2{font:700 1.15rem var(--tv-font-head,Georgia,serif);color:var(--b);margin:0 0 .5rem}
  .pq-dd{position:relative;display:inline-block;margin-bottom:.4rem;z-index:30}
  .pq-dd>summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;gap:.35rem;border:1px solid #CBB98D;background:#FFF8EA;color:#3E2B1F;border-radius:999px;padding:.35rem .75rem;font:700 .92rem system-ui,sans-serif}
  .pq-dd>summary::-webkit-details-marker{display:none}.pq-dd>summary::after{content:"▾";color:#8A7355;font-size:.8em}
  .pq-dd[open]>summary,.pq-dd.on>summary{background:var(--sg);border-color:var(--sg);color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .pq-n{font-weight:600;color:#8A7355;font-size:.85em}.pq-dd[open] .pq-n,.pq-dd.on>summary .pq-n{color:#1F3B30}
  .pq-list{position:absolute;left:0;top:calc(100% + .35rem);width:min(16rem,calc(100vw - 6px));background:#FFFBF2;border:1px solid #CBB98D;border-radius:.7rem;box-shadow:0 16px 32px -14px rgba(0,0,0,.4);padding:.3rem}
  .pq-list button{display:flex;align-items:center;gap:.45rem;width:100%;border:0;background:none;padding:.4rem .5rem;border-radius:.45rem;color:#92400E;font:600 .95rem system-ui,sans-serif;text-align:left;cursor:pointer}
  .pq-list button:hover{background:#F5EBD3}.pq-list button[aria-checked=true]{background:#E4F0EA;color:#1F3B30}.pq-list .pq-n{margin-left:auto}
  @media (max-width:767px){.pq-list{position:fixed;left:3px;right:3px;width:auto;top:auto}}
  .pq-row{display:flex;gap:.55rem;align-items:flex-start;padding:.5rem .2rem;border-top:1px solid var(--ln)}
  .pq-row:first-of-type{border-top:0}
  .pq-sev{width:30px;height:30px;border-radius:.45rem;flex:none;display:flex;align-items:center;justify-content:center;color:#fff;font:800 1rem system-ui}
  .pq-sev.critical{background:#DC2626}.pq-sev.alert{background:#EA8A2E}.pq-sev.update{background:#8A7355}.pq-sev.event{background:#8FBCA8}
  .pq-t{min-width:0;flex:1}
  .pq-t a{color:var(--br);text-decoration:underline;font-weight:700;cursor:pointer}
  .pq-t small{display:block;color:#8A7355;font-size:.85rem}
  .pq-t small.over{color:#B91C1C;font-weight:700}
  .pq-links{list-style:none;margin:0 0 .6rem;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(min(12rem,100%),1fr));gap:.3rem .8rem}
  .pq-links a{display:flex;align-items:center;gap:.45rem;color:var(--br);text-decoration:underline;font-weight:600;padding:.25rem 0}
  .pq-li{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:var(--cr);color:var(--am);display:inline-flex;align-items:center;justify-content:center;flex:none}
  .pb-post{border:1px solid #CBB98D;border-radius:.7rem;background:var(--cr);padding:.5rem}
  .pb-post textarea{width:100%;min-height:4.5rem;border:0;background:transparent;resize:vertical;font-size:1rem;color:var(--b)}
  .pb-post .row{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;justify-content:flex-end}
  .pb-post select{background:var(--cr);border:1px solid #CBB98D;border-radius:.5rem;padding:.3rem .4rem;font-size:.9rem;color:var(--b)}
  .pb-btn{border:1px solid #E39A52;background:#F0B57A;color:#3E2B1F;border-radius:999px;padding:.35rem .9rem;font-weight:800;font-size:.85rem;letter-spacing:.04em;text-transform:uppercase;cursor:pointer}
  .pb-btn.sm{text-transform:none;letter-spacing:0;font-weight:700;background:var(--cr);border-color:#CBB98D}
  .pb-btn.go{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;text-transform:none;letter-spacing:0}
  .pb-stream{margin-top:.8rem;container-type:inline-size}   /* the list fits the room it has (split screen, a rail open), not the screen */
  .pb-sh{display:flex;align-items:center;gap:.5rem;font:700 1.15rem var(--tv-font-head,Georgia,serif);color:var(--b);background:var(--pa);border:1px solid var(--ln);border-radius:.8rem .8rem 0 0;padding:.55rem .8rem}
  .pb-sh .pb-mark{width:32px;height:32px}.pb-sh .pb-mark svg{width:18px;height:18px}
  /* one line per message, like a mail inbox (Jason, 2026-11-18, Outlook's inbox as the example): the level first and very
     narrow, the sender's mark, From, the subject with its words after it, Received; each column sorts and sizes from its
     header; the row's icons appear on its line when it's pointed at, opened or focused */
  .ps-hd,.ps-row{display:grid;grid-template-columns:var(--c-sev,2.7rem) 1.3rem var(--c-from,10rem) minmax(0,1fr) max(6.5rem,var(--c-when,8rem)) auto;grid-template-areas:"sev ic src sub when acts";gap:.45rem;align-items:center;padding:.28rem .6rem;position:relative}
  .ps-row.ps-late{background:color-mix(in srgb,var(--tv-hold) 6%,var(--tv-card-a))}.ps-row.ps-late.ps-crit{background:color-mix(in srgb,var(--tv-fail) 6%,var(--tv-card-a))}   /* overdue: amber; overdue and Critical: red (Jason, 2026-11-19) */
  .ps-sort-i .ps-hi{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2}.ps-sort-i{display:inline-flex;align-items:center}.ps-due{display:inline-flex;align-items:center;color:var(--tv-hold);cursor:help}.ps-row.ps-crit .ps-due{color:var(--tv-fail)}.ps-due svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2.2}   /* the due time on hover (Jason, 2026-11-19) */
  .ps-row{font-size:.9rem}.ps-row>.ps-sev{grid-area:sev;display:flex;justify-content:center}.ps-row>.ps-ic{grid-area:ic}.ps-row>.ps-src{grid-area:src}.ps-row>.ps-sub{grid-area:sub;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ps-row>.ps-when{grid-area:when;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .ps-row .ps-sub small{display:inline;margin-left:.45rem}.ps-row .ps-when small{display:inline;margin-left:.35rem}.ps-row .ps-sub .ps-pills,.ps-row .ps-marks{display:inline}
  .ps-row>.ps-ic .pu-svg{width:15px;height:15px}.ps-row>.ps-ic{display:flex}
  /* the row's actions in their own column, never over the text (design/table-standard.md, T2): ▾ and ⋯, ⋯ a menu with words */
  .ps-row>.ps-icons{grid-area:acts;position:relative;display:flex;gap:.25rem;align-items:center;justify-self:end;align-self:stretch;border-left:1px solid var(--ln);padding-left:.45rem;min-width:4.4rem;justify-content:flex-end}
  .ps-hd>.ps-hacts{grid-area:acts;align-self:stretch;border-left:1px solid var(--ln);min-width:4.9rem}   /* ▾ and ⋯ set apart by a line (Jason, 2026-11-19) */
  .ps-menu{display:none;position:absolute;right:0;top:calc(100% + .25rem);z-index:40;min-width:15rem;flex-direction:column;background:var(--tv-card-a,#F6F1E4);border:1px solid var(--tv-line-strong);border-radius:.6rem;box-shadow:var(--tv-shadow-lg);padding:.3rem}
  .ps-icons.more>.ps-menu{display:flex}.ps-icons.up>.ps-menu{top:auto;bottom:calc(100% + .25rem)}
  .ps-row .ps-menu .ps-i{width:auto;height:auto;border:0;border-radius:.4rem;background:none;color:var(--tv-ink);justify-content:flex-start;align-items:flex-start;gap:.55rem;padding:.42rem .55rem;font:500 .9rem var(--tv-font-ui);text-align:left;box-shadow:none}
  .ps-menu .ps-i .pu-svg{color:var(--tv-icon,#B45309);flex:none;margin-top:.1rem}.ps-menu .ps-i:hover{background:var(--tv-sec,#EDE6D5)}.ps-menu .ps-i small{display:block;font-size:.76rem;color:var(--tv-meta)}
  .ps-menu .ps-i[aria-pressed=true]{background:color-mix(in srgb,var(--tv-sage) 30%,transparent);box-shadow:none;color:var(--tv-ink)}.ps-menu .ps-i[aria-disabled=true]{color:var(--tv-meta);cursor:not-allowed}
  .ps-row .ps-i{width:26px;height:26px}
  @container (min-width:48.01rem){.ps-row>.ps-ic{width:1.3rem;height:1.3rem;border:0;background:none;box-shadow:none;align-items:center;justify-content:center}.ps-row .ps-next{padding:0 .45rem;font-size:.75rem}}
  .ps-h{position:relative;display:flex;align-items:center;gap:.15rem;min-width:0}
  .ps-sort,.ps-flt{border:0;background:none;padding:.1rem .15rem;font:inherit;color:inherit;letter-spacing:inherit;text-transform:inherit;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .ps-sort::after{content:" ▼";font-size:.7em;opacity:.3}.ps-sort:hover::after{opacity:.65}.ps-sort[aria-sort=ascending]::after{content:" ▲";opacity:1}.ps-sort[aria-sort=descending]::after{content:" ▼";opacity:1}   /* every heading shows its arrow (Jason, 2026-11-19) */
  .ps-flt svg{width:12px;height:12px;fill:none;stroke:currentColor;stroke-width:2.2;vertical-align:-1px}
  .ps-flt[aria-pressed=true]{background:#8FBCA8;color:#1F3B30;border-radius:999px}
  .ps-grip{position:absolute;right:-.4rem;top:-.3rem;bottom:-.3rem;width:.6rem;cursor:col-resize;touch-action:none}
  .ps-grip:hover,.ps-grip.on{background:linear-gradient(90deg,transparent 40%,#CBB98D 40%,#CBB98D 60%,transparent 60%)}
  .ps-icons .ps-more{display:inline-flex}
  .ps-svi{width:16px;height:16px;vertical-align:middle;flex:none}
  .ps-row>.ps-src{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .ps-hd{font-size:.8rem;text-transform:none;letter-spacing:0;color:#8A7355;background:var(--pa);border-left:1px solid var(--ln);border-right:1px solid var(--ln)}
  .ps-list{border:1px solid var(--ln);border-top:0;border-radius:0 0 .8rem .8rem;overflow:visible;background:var(--cr)}.ps-list>.ps-row:last-of-type{border-radius:0 0 .8rem .8rem}
  .ps-row{border-top:1px solid var(--ln);cursor:pointer}
  .ps-row:hover,.ps-row.on{background:#F7D9B5}
  .ps-row.done{opacity:.6}
  .ps-row[hidden],.pq-row[hidden],.pb-dr[hidden],.pb-form[hidden],.ps-empty[hidden]{display:none!important}
  .ps-src{display:flex;align-items:center;gap:.4rem;min-width:0;color:var(--b);font-weight:600}
  .ps-ic{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:var(--cr);color:var(--am);display:inline-flex;align-items:center;justify-content:center}
  .ps-sev{font-weight:700;font-size:.92rem}
  .ps-sev.critical{color:#B91C1C}.ps-sev.urgent{color:#B45309}.ps-sev.alert{color:#C2410C}.ps-sev.update{color:#5C4632}.ps-sev.event{color:#2F6B55}.ps-sev.special{color:#6D28D9}
  .ps-sub{min-width:0}
  .ps-sub b{font-weight:600;color:var(--b)}
  .ps-sub a{color:var(--br);text-decoration:underline;font-weight:600;margin-left:.3rem}
  .ps-sub small{display:block;color:#8A7355;font-size:.85rem;overflow-wrap:anywhere}
  .ps-next{border:1px solid #CBB98D;background:var(--cr);color:var(--br);border-radius:999px;padding:.05rem .55rem;margin-left:.35rem;font:600 .8rem system-ui;cursor:pointer;vertical-align:1px}
  .ps-icons{display:flex;flex-wrap:nowrap;gap:.2rem;justify-self:end}
  .ps-i{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:var(--cr);color:var(--am);display:inline-flex;align-items:center;justify-content:center;padding:0;cursor:pointer}
  .ps-i[aria-pressed=true]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .ps-i .pu-svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
  .ps-row.unread .ps-sub b{font-weight:800}.ps-row.unread{box-shadow:inset 3px 0 0 #B45309}
  .ps-marks{display:inline-flex;flex-wrap:wrap;gap:.25rem;margin-top:.2rem}.ps-marks:empty{display:none}
  .ps-marks span{font-size:.72rem;border:1px solid;border-radius:999px;padding:0 .4rem}.ps-marks .fl{color:#B91C1C}.ps-marks .im{color:#92400E}
  .ps-views{display:flex;flex-wrap:wrap;gap:.35rem;margin:.6rem 0 0}
  /* paging (the admin's list standard, .ak-pgb): the count, Show N a page, the page bar; on a phone previous, Page n of N, next */
  .ps-pg{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .8rem;margin:.55rem .2rem 0;font-size:.88rem;color:var(--tv-meta)}.ps-pg:empty{display:none}
  .ps-pg nav{display:flex;flex-wrap:wrap;gap:.25rem;align-items:center}.ps-pg .ak-pgb{min-width:34px;height:34px;padding:0 .5rem;border:1px solid var(--tv-line);border-radius:.4rem;background:var(--tv-card-a,#F6F1E4);color:var(--tv-ink);font:inherit;cursor:pointer}
  .ps-pg .ak-pgb[aria-current]{background:var(--tv-btn,#92400E);border-color:var(--tv-btn,#92400E);color:var(--tv-btn-text,#E4DCC5);font-weight:700}.ps-pg .ak-pgb:disabled{opacity:.45;cursor:default}
  .ps-pg .ps-pn{display:none}.ps-pg label{margin-left:auto;display:flex;align-items:center;gap:.35rem}.ps-pg select{padding:.3rem .45rem;border:1px solid var(--tv-field-edge,#8D7E68);border-radius:.4rem;background:var(--tv-field,#F6F1E4);font:inherit}
  @media (max-width:767px){.ps-pg .ak-pgb[data-n]{display:none}.ps-pg .ps-pn{display:inline}.ps-pg label{margin-left:0}}
  .ps-open{border-top:1px solid var(--ln);background:#FFF8EA;padding:.3rem}
  .ps-open .pb-case{display:block;height:auto;box-shadow:none;border:1px solid #CBB98D;border-radius:.5rem}
  .ps-open .pb-case-in{overflow:visible}
  .ps-open #pb-dr-mgw,.ps-open #pb-dr-vend,.ps-open #pb-dr-tool{display:none!important}
  .ps-open #pb-dr-play>li:nth-child(n+6),.ps-open #pb-dr-hist>li:nth-child(n+4){display:none}
  .ps-when{font-size:.88rem;color:#5C4632}
  .ps-when small{display:block;color:#B91C1C;font-weight:700}
  .ps-pills{display:inline-flex;gap:.25rem;flex-wrap:wrap;margin-left:.3rem}
  .ps-pill{font-size:.75rem;border-radius:999px;padding:.03rem .4rem;background:#EADFC4;color:#5C4632;font-weight:700}
  .ps-pill.red{background:#FEE2E2;color:#991B1B}.ps-pill.ok{background:#DCEFE5;color:#1F5C43}
  .ps-empty{padding:1rem;color:#5C4632}
  .pb-dr{position:fixed;inset:0;z-index:1900;display:grid;grid-template-rows:minmax(0,1fr);grid-template-columns:minmax(0,1fr) min(28rem,100%);background:rgba(30,20,12,.35)}
  .pb-tool{display:flex;flex-direction:column;min-width:0;min-height:0;height:100%;background:var(--cr);border-right:1px solid #CBB98D;box-shadow:0 0 40px -10px rgba(0,0,0,.45)}
  .pb-tool[hidden]{display:none}
  .pb-tool-bar{display:flex;align-items:center;gap:.5rem;padding:.55rem .8rem;background:#3E2B1F;color:#FFF8EA}
  .pb-tool-bar b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pb-tool-bar a,.pb-tool-bar button{color:#FFF8EA;border:1px solid rgba(255,248,234,.45);background:transparent;border-radius:.5rem;padding:.25rem .6rem;font-weight:700;font-size:.88rem;text-decoration:none;cursor:pointer;white-space:nowrap}
  .pb-tool-sc{flex:1;min-height:0;overflow:hidden;display:flex}
  #pb-tool-f{display:block;flex:1;width:100%;height:100%;min-height:0;border:0;background:transparent}
  .pb-tool iframe{display:block;width:100%;height:100%;min-height:100%;border:0;background:var(--cr)}
  .pb-shade{cursor:pointer}
  .pb-case{grid-column:2;display:flex;flex-direction:column;min-width:0;min-height:0;height:100%;background:var(--cr);box-shadow:-18px 0 40px -20px rgba(0,0,0,.5)}
  .pb-case-hd{padding:.75rem .9rem .6rem;background:#F7E7CC;border-bottom:1px solid #CBB98D}
  .pb-case-hd .top{display:flex;align-items:flex-start;gap:.5rem}
  .pb-case-hd small{display:block;color:#8A7355;font-weight:700;letter-spacing:.05em;text-transform:uppercase;font-size:.75rem}
  .pb-case-hd h3{flex:1;min-width:0;margin:.1rem 0 0;font:700 1.12rem/1.25 var(--tv-font-head,Georgia,serif);color:var(--b)}
  .pb-case-hd .x{border:0;background:transparent;font-size:1.6rem;line-height:1;color:var(--b);cursor:pointer;padding:0 .1rem}
  .pb-chips2{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.5rem}
  .pb-c{font-size:.78rem;font-weight:700;border-radius:999px;padding:.12rem .55rem;background:#EADFC4;color:#5C4632;white-space:nowrap}
  .pb-c.critical,.pb-c.over{background:#FEE2E2;color:#991B1B}.pb-c.alert{background:#FFEDD5;color:#9A3412}.pb-c.event,.pb-c.ok{background:#DCEFE5;color:#1F5C43}
  .pb-case-in{flex:1;overflow-y:auto;padding:.75rem .9rem}
  .pb-why{margin:0 0 .6rem;color:var(--b);font-size:.97rem;overflow-wrap:anywhere}
  .pb-opentool{display:flex;align-items:center;justify-content:center;gap:.4rem;width:100%;border:1px solid #3E2B1F;background:#3E2B1F;color:#FFF8EA;border-radius:.6rem;padding:.55rem;font-weight:700;cursor:pointer;margin-bottom:.7rem}
  .pb-acts{display:flex;flex-wrap:wrap;gap:.35rem;margin-bottom:.7rem}
  .pb-acts select{border:1px solid #CBB98D;background:var(--cr);border-radius:999px;padding:.3rem .6rem;font-weight:700;font-size:.85rem;color:var(--b);max-width:11rem}
  .pb-seg{display:inline-flex;border:1px solid #CBB98D;border-radius:999px;overflow:hidden}
  .pb-seg button{border:0;background:var(--cr);padding:.3rem .65rem;font-size:.82rem;font-weight:700;color:var(--b);cursor:pointer}
  .pb-seg button[aria-pressed=true]{background:#8FBCA8;color:#1F3B30}
  .pb-tl{list-style:none;margin:.3rem 0 0;padding:0 0 0 .9rem;border-left:2px solid var(--ln);font-size:.9rem}
  .pb-tl li{position:relative;padding:.1rem 0 .6rem}
  .pb-tl li::before{content:"";position:absolute;left:-1.25rem;top:.4rem;width:.6rem;height:.6rem;border-radius:999px;background:#CBB98D}
  .pb-tl li.order::before{background:#fff;border:2px solid #CBB98D}.pb-tl li.order b{color:#8A7355;font-weight:600}.pb-tl li.reply::before{background:#B45309}.pb-tl li.resolve::before{background:#8FBCA8}.pb-tl li.escalate::before{background:#DC2626}
  .pb-tl small{display:block;color:#8A7355}
  .pb-steps{list-style:none;display:flex;margin:.2rem 0 .6rem;padding:0;counter-reset:st}
  .pb-steps li{flex:1;min-width:0;text-align:center;font-size:.72rem;font-weight:700;color:#8A7355;position:relative;padding-top:1.5rem}
  .pb-steps li::before{content:"";position:absolute;top:.35rem;left:50%;transform:translateX(-50%);width:.9rem;height:.9rem;border-radius:999px;border:2px solid #CBB98D;background:var(--cr);z-index:1}
  .pb-steps li::after{content:"";position:absolute;top:.75rem;left:-50%;width:100%;height:2px;background:#CBB98D}
  .pb-steps li:first-child::after{display:none}
  .pb-steps li.done{color:#2F6B55}.pb-steps li.done::before{background:#8FBCA8;border-color:#8FBCA8}.pb-steps li.done::after{background:#8FBCA8}
  .pb-steps li.current{color:var(--b)}.pb-steps li.current::before{box-shadow:0 0 0 4px rgba(143,188,168,.4)}
  .pb-next{display:flex;flex-wrap:wrap;gap:.4rem;margin-bottom:.7rem}
  .pb-track,.pb-play li input.pb-track{display:block;width:100%;height:auto;appearance:auto;box-sizing:border-box;margin-top:.45rem;padding:.45rem .65rem;border:1px solid #CBB98D;border-radius:.5rem;background:#FFFBF2;color:#3E2B1F;font:inherit;font-size:.95rem}
  .pb-next .lead{flex:1 1 100%;font-size:.82rem;font-weight:700;color:#8A7355;text-transform:uppercase;letter-spacing:.05em}
  .pb-c{border:0;cursor:pointer;font-family:inherit}
  .pb-c[aria-pressed=true]{outline:2px solid #3E2B1F;outline-offset:1px}
  .pb-ex{margin:.5rem 0 0;padding:.5rem .6rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;font-size:.9rem;color:#3E2B1F}
  .pb-ex a{color:#92400E;text-decoration:underline;font-weight:700}
  .pb-play{list-style:none;margin:.2rem 0 .8rem;padding:0;counter-reset:pp}
  .pb-play li{display:grid;grid-template-columns:1.6rem minmax(0,1fr) auto;gap:.15rem .5rem;align-items:start;padding:.5rem 0;border-top:1px solid var(--ln);counter-increment:pp}
  .pb-play li:first-child{border-top:0}
  .pb-play .pb-ext{display:inline-flex;align-items:center;margin-top:.35rem;padding:.25rem .65rem;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#92400E;font-weight:700;font-size:.82rem;text-decoration:none}
  .pb-play .pb-ext + .pb-ext{margin-left:.35rem}
  .pb-play li.pb-go{background:rgba(143,188,168,.18);box-shadow:0 0 0 3px rgba(143,188,168,.45);border-radius:.5rem;padding-left:.35rem;padding-right:.35rem}
  .pb-play input{width:1.15rem;height:1.15rem;margin-top:.15rem;accent-color:#2F6B55}
  .pb-play b{font-weight:700;color:var(--b)}
  .pb-play b::before{content:counter(pp) ". ";color:#8A7355}
  .pb-play small{display:block;color:#5C4632;font-size:.86rem;line-height:1.35}
  .pb-play li.done b{color:#2F6B55;text-decoration:line-through;text-decoration-color:rgba(47,107,85,.5)}
  .pb-play .auto{font-size:.72rem;font-weight:700;color:#2F6B55;background:#DCEFE5;border-radius:999px;padding:0 .4rem;margin-left:.3rem}
  .pb-play button{white-space:nowrap}
  .pb-mg{display:flex;flex-wrap:wrap;gap:.35rem}
  .pb-mg .no{color:#991B1B;border-color:#E5B4B4}
  .pb-form{margin:.6rem 0;padding:.6rem;border:1px solid #CBB98D;border-radius:.7rem;background:#FFF8EA;display:grid;grid-template-columns:minmax(0,1fr);gap:.4rem}
  .pb-form b{font:700 1rem var(--tv-font-head,Georgia,serif);color:var(--b)}
  .pb-form label{font-size:.85rem;font-weight:700;color:#5C4632;display:grid;gap:.15rem;min-width:0}
  .pb-form input,.pb-form select,.pb-form textarea{border:1px solid #CBB98D;background:var(--cr);border-radius:.5rem;padding:.4rem .55rem;font-size:.95rem;color:var(--b);font-weight:400;width:100%;min-width:0;box-sizing:border-box}
  .pb-form .row{display:flex;gap:.4rem;justify-content:flex-end}
  .pb-vend{font-size:.88rem;margin:.1rem 0 .6rem;padding:.45rem .6rem;border:1px dashed #CBB98D;border-radius:.6rem}
  .pb-vend b{display:block;font-size:.78rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355}
  .pb-vj{display:flex;justify-content:space-between;gap:.5rem;padding:.3rem 0;border-top:1px solid #EADFC4}
  .pb-vj strong{display:block;font-size:.9rem}.pb-vj span{display:block;color:#5C4632}
  .pb-margin{margin-top:.35rem;padding:.3rem .5rem;border-radius:.5rem;background:#DCEFE5;color:#1F5C43;font-weight:700}
  .pb-margin.neg{background:#FEE2E2;color:#991B1B}
  .pb-form details{border-top:1px dashed #CBB98D;padding-top:.3rem}.pb-form details>summary{cursor:pointer;font-weight:700;color:#92400E}.pb-form details label{margin-top:.35rem}
  .pb-tl .ed{margin-left:.4rem;font-size:.8rem;color:#92400E;text-decoration:underline;background:none;border:0;cursor:pointer;padding:0}
  .pb-case h4{font:700 1rem var(--tv-font-head,Georgia,serif);margin:.8rem 0 .2rem;color:var(--b)}
  @media (max-width:767px){.pb-dr{grid-template-columns:1fr;background:none}.pb-case{grid-column:1;grid-row:1}.pb-tool{grid-column:1;grid-row:1;z-index:2}.pb-shade{display:none}}
  .pb-msg{font-size:.9rem;margin:.3rem 0 0;color:#1F5C43;font-weight:600}
  .pb-msg.no{color:#991B1B}
  @media (max-width:900px){.pb-top{grid-template-columns:1fr}}
  @media (max-width:767px){
    .ps-hd{display:flex;flex-wrap:wrap;gap:.25rem .6rem}.ps-hd>span:nth-child(2){display:none}.ps-grip{display:none}
    .ps-row{grid-template-columns:1.3rem 2.2rem minmax(0,1fr) auto;grid-template-areas:"sev ic src acts" ". ic sub sub" ". ic when when";row-gap:.15rem;padding:.5rem .7rem;font-size:1rem}
    .ps-row>.ps-sub{white-space:normal}.ps-row .ps-sub small{display:block;margin-left:0}.ps-row>.ps-when{white-space:normal}
    .ps-row>.ps-icons{position:static;transform:none;background:none;box-shadow:none;padding:0;display:flex;border-left:0;min-width:0;align-self:start}.ps-hd>.ps-hacts{display:none}
    .ps-row>.ps-ic{grid-area:ic;align-self:start}.ps-row>.ps-src{grid-area:src}.ps-row>.ps-sev{display:flex;grid-area:sev;align-self:start;padding-top:.5rem}.ps-row>.ps-sub{grid-area:sub}.ps-row>.ps-when{grid-area:when}
    .ps-row>.ps-icons{grid-area:acts;align-self:start}
    .pb-tools{margin-left:0}
  }
  .ps-sevm{display:none;font-weight:700;font-size:.85rem}
  /* narrow room on a wide screen (split screen, the admin rail beside it): the same stacked rows as a phone */
  @container (max-width:48rem){
    .ps-hd{display:flex;flex-wrap:wrap;gap:.25rem .6rem}.ps-hd>span:nth-child(2){display:none}.ps-grip{display:none}
    .ps-row{grid-template-columns:1.3rem 2.2rem minmax(0,1fr) auto;grid-template-areas:"sev ic src acts" ". ic sub sub" ". ic when when";row-gap:.15rem;padding:.5rem .7rem;font-size:1rem}
    .ps-row>.ps-sub{white-space:normal}.ps-row .ps-sub small{display:block;margin-left:0}.ps-row>.ps-when{white-space:normal}
    .ps-row>.ps-icons{position:static;transform:none;background:none;box-shadow:none;padding:0;display:flex;border-left:0;min-width:0;align-self:start}.ps-hd>.ps-hacts{display:none}
    .ps-row>.ps-ic{grid-area:ic;align-self:start}.ps-row>.ps-src{grid-area:src}.ps-row>.ps-sev{display:flex;grid-area:sev;align-self:start;padding-top:.5rem}.ps-row>.ps-sub{grid-area:sub}.ps-row>.ps-when{grid-area:when}
    .ps-row>.ps-icons{grid-area:acts;align-self:start}
  }
  /* grouped alarms (Control Board, 0171 §8 note): one row with its count; its alarms indented under it, shown when opened */
  .ps-gn{border:1px solid #CBB98D;background:var(--cr);color:var(--am);border-radius:999px;font:700 .72rem system-ui;width:1.4rem;height:1.2rem;padding:0;margin-right:.4rem;cursor:pointer;vertical-align:middle}
  .ps-gn::before{content:"▸"}.ps-group[aria-expanded=true] .ps-gn::before{content:"▾"}
  .ps-child>.ps-sub{padding-left:1.1rem}
  /* a message or an email in the stream (G6, G7): the mailbox it came to, a paperclip, its body opened in place */
  .ps-box{font-size:.72rem;border:1px solid var(--ln);border-radius:999px;padding:0 .4rem;margin-right:.35rem;color:#5C4632;background:var(--cr)}
  .ps-clip{display:inline-flex;vertical-align:middle;margin-left:.3rem;color:#8A7355}.ps-clip .pu-svg{width:14px;height:14px}
  .ps-i[aria-disabled=true]{opacity:.4;cursor:not-allowed}
  .ps-msgbox{border:1px solid var(--ln);border-radius:.5rem;background:var(--cr);padding:.6rem .7rem;font-size:.93rem;color:var(--b);overflow-wrap:anywhere}
  .ps-msgbox .ps-mh{display:flex;flex-wrap:wrap;gap:.2rem .6rem;align-items:baseline;font-size:.85rem;color:#5C4632;margin:0 0 .35rem}
  .ps-msgbox .ps-mh b{color:var(--b);font-size:.93rem}
  .ps-mail{border-top:1px solid var(--ln);padding:.5rem 0}.ps-mail:first-child{border-top:0;padding-top:0}
  .ps-mail iframe,.ps-mail .ps-mb{width:100%;border:0;background:#fff;max-height:60vh;overflow:auto}
  .ps-msgbox form{display:grid;gap:.35rem;margin-top:.5rem}.ps-msgbox textarea,.ps-msgbox input,.ps-msgbox select{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.5rem;padding:.4rem .55rem;font:inherit;background:#fff}
  .ps-msgbox .row{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;justify-content:space-between}
  /* the drawer's Previous / Next through the list as it's shown (decisions/0172's three views: the drawer gains them) */
  .pb-pn{display:inline-flex;gap:.25rem}.pb-pn button{border:1px solid #CBB98D;background:var(--cr);color:var(--b);border-radius:999px;width:30px;height:30px;font-size:1rem;cursor:pointer}
  .pb-pn button[disabled]{opacity:.4;cursor:default}
</style>
<div class="pb" id="pb" data-focus="<?= $e($focus) ?>">
  <?php /* the Operational Task Queue went (decisions/0172, Jason 2026-11-18): the bell's list replaces it. The top half is two
     rows (design/table-standard.md, T2): one header, then one filter button; Quick Actions a ⋯ and Your day a pop-up (0172) */ ?>
  <div class="pb-head">
    <span class="pb-mark" aria-hidden="true"><?= tv_icon('pulse', '') ?></span><h2 class="pb-title" id="ps-h">Pulse</h2>
    <label class="sr-only" for="pb-q">Filter this list</label>
    <input id="pb-q" class="pb-q" type="search" placeholder="Filter this list" autocomplete="off">
    <div class="pb-tools">
      <button type="button" class="pb-ic" data-chip-bell aria-pressed="false" title="Critical, overdue, and escalated to you" aria-label="Critical, overdue, and escalated to you"><?= tv_icon('bell', 'pu-svg') ?><?= $bell ? '<i>' . $bell . '</i>' : '' ?></button>
      <?php if ($today !== ''): ?><details class="pb-pop"><summary class="pb-ic" title="Your day" aria-label="Your day"><?= tv_icon('calendar', 'pu-svg') ?></summary><span class="pb-dim" data-pop-close aria-hidden="true"></span><div class="pb-popc pb-today" role="dialog" aria-label="Your day"><button type="button" class="pb-x" data-pop-close aria-label="Close">&times;</button><?= $today ?></div></details><?php endif; ?>
      <details class="pb-pop"><summary class="pb-ic" title="Quick actions" aria-label="Quick actions"><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/></svg></summary>
        <div class="pb-popc pb-qa"><button type="button" class="pb-x" data-pop-close aria-label="Close" title="Close">&times;</button><h3 id="qa-h">Quick actions</h3>
      <?= tv_pulse_quick($pdo, $staff) ?>
        </div></details>
      <a class="pb-ic" href="/admin/dashboard/streamset" data-ak-hand="/admin/dashboard/streamset" data-ak-title="Stream settings" title="Stream settings: routing, clocks" aria-label="Stream settings"><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/></svg></a>
    </div>
  </div>
  <div class="pb-row2">
    <details class="pb-fdd" id="pb-fdd"><summary class="pb-fb"><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4 2v-8z"/></svg><span data-fdd-lab>Inbox · All</span> <b data-fdd-n></b> <span aria-hidden="true">▾</span></summary>
      <div class="pb-fddc"><button type="button" class="pb-x" data-pop-close aria-label="Close" title="Close">&times;</button><p class="pb-fddh">Your lists</p><div class="ps-views" id="ps-views" role="group" aria-label="Your views"></div>
        <p class="pb-fddh">Show</p><div class="pb-chips" role="group" aria-label="Show">
      <?php foreach ($chips as $k => [$label, $n]): ?><button type="button" class="pb-chip" data-chip="<?= $k ?>" aria-pressed="false"><?= $e($label) ?> (<b><?= (int) $n ?></b>)</button><?php endforeach; ?>
      <?php if (array_filter($extra, fn ($x) => $x['kind'] === 'mail')): ?><button type="button" class="pb-chip" data-chip="mail" aria-pressed="false" title="The mail of the mailboxes you read (Dashboard → My inbox shows the same)">Mail (<b><?= (int) $mailN ?></b>)</button><?php endif; ?>
        </div></div></details>
    <details class="pb-fdd pb-gdd" id="pb-gdd"><summary class="pb-fb" title="Group the rows"><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2 8l10 5 10-5z"/><path d="m2 13 10 5 10-5"/></svg><span data-gb-lab>Group: None</span> <span aria-hidden="true">▾</span></summary>
      <div class="pb-fddc pb-gddc" role="menu"><button type="button" class="pb-x" data-pop-close aria-label="Close" title="Close">&times;</button><p class="pb-fddh">Group by</p><button type="button" role="menuitemradio" data-gb="">None</button><button type="button" role="menuitemradio" data-gb="from">Sender</button><button type="button" role="menuitemradio" data-gb="src">Kind</button><button type="button" role="menuitemradio" data-gb="sev">Level</button></div></details>
    <?php $canA = fn ($a) => Workspaces::allowsArea($staff, $a, $pdo); $qa = fn ($u, $l) => ' href="' . $e($u) . '" data-qa="' . $e(tv_admin_embed_url($u)) . '" data-qa-title="' . $e($l) . '"'; ?>
    <details class="pb-pop pb-newp"><summary class="pb-b2" data-compose title="Start something new: a post, a task, an order, a listing"><?= tv_icon('plus', 'pu-svg') ?> New</summary>
      <div class="pb-popc pb-new"><button type="button" class="pb-x" data-pop-close aria-label="Close" title="Close">&times;</button>
      <div data-new-pane="menu"><h3>New</h3><div class="pb-newl">
        <button type="button" data-new="post"><b>Post to the team</b><small>Everyone, or one department</small></button>
        <button type="button" data-new="task"><b>A task</b><small>For you or a teammate, with a day: it comes back then</small></button>
        <?php if ($canA('ecommerce')): ?><a<?= $qa('/admin/client-order.php?new=1', 'New client order') ?>><b>A client order</b><small>Opens beside Pulse</small></a><?php else: ?><button type="button" disabled><b>A client order</b><small>Your role doesn't take orders.</small></button><?php endif; ?>
        <?php if ($canA('listings')): ?><a<?= $qa('/admin/listing-add.php', 'Add a listing') ?>><b>A listing</b><small>Opens beside Pulse</small></a><?php else: ?><button type="button" disabled><b>A listing</b><small>Your role doesn't add listings.</small></button><?php endif; ?>
        <button type="button" disabled><b>An email</b><small>Coming: from a mailbox you read. Today, reply to or forward an email's row.</small></button>
        <button type="button" disabled><b>A message to one teammate</b><small>Coming. Today, Pass it on from a row, or a task.</small></button>
      </div></div>
      <div data-new-pane="post" hidden><button type="button" class="pb-back" data-new-back>&larr; Back</button><h3>Post to the team</h3>
      <div class="pb-post">
        <label class="sr-only" for="pb-body">Post to the team</label>
        <textarea id="pb-body" placeholder="Post to your team…"></textarea>
        <div class="row"><label class="sr-only" for="pb-dept">Post to</label><select id="pb-dept"><?= $deptOpts ?></select><button type="button" class="pb-btn" data-post-team>Post</button></div>
        <p class="pb-msg" id="pb-msg" role="status"></p>
      </div></div>
      <form data-new-pane="task" class="pb-task" hidden><button type="button" class="pb-back" data-new-back>&larr; Back</button><h3>A task</h3>
        <label for="pb-tfor">For</label><select id="pb-tfor" name="to"><option value="0">Me</option></select>
        <label for="pb-twhen">When</label><select id="pb-twhen" name="due"><option value="today">Today</option><option value="tomorrow">Tomorrow</option><option value="week">This week</option><option value="nextweek">Next week</option></select>
        <label for="pb-twhat">What to do</label><input id="pb-twhat" name="what" maxlength="200" required data-spell autocomplete="off">
        <button type="submit" class="pb-btn">Give it</button></form>
      </div></details>
  </div>

  <section class="pb-stream" id="pu-stream" aria-labelledby="ps-h">
    <div class="ps-hd" id="ps-hd" role="group" aria-label="Sort and filter the stream">
      <span class="ps-h" style="grid-area:sev"><button type="button" class="ps-sort" data-sort="sev" title="Sort by level" aria-label="Level">!</button><button type="button" class="ps-flt" data-filter="sev" title="Show only some levels" aria-label="Filter by level" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4-2v-4z"/></svg></button><i class="ps-grip" data-grip="sev" title="Drag to resize" aria-hidden="true"></i></span>
      <span style="grid-area:ic"></span>
      <span class="ps-h" style="grid-area:src"><button type="button" class="ps-sort" data-sort="from" title="Sort by sender">From</button><button type="button" class="ps-flt" data-filter="from" title="Show only some senders" aria-label="Filter by sender" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4-2v-4z"/></svg></button><i class="ps-grip" data-grip="from" title="Drag to resize" aria-hidden="true"></i></span>
      <span class="ps-h" style="grid-area:sub"><button type="button" class="ps-sort" data-sort="sub" title="Sort by subject">Subject</button><i class="ps-grip" data-grip="sub" title="Drag to resize" aria-hidden="true"></i></span>
      <span class="ps-h" style="grid-area:when"><button type="button" class="ps-sort ps-sort-i" data-sort="when" title="Received: sort by when it came in" aria-label="Received"><?= function_exists('tv_icon') ? tv_icon('inbox', 'ps-hi') : 'Received' ?></button></span>
      <span class="ps-hacts" aria-hidden="true"></span>
    </div>
    <div class="ps-list" id="ps-list">
      <?php foreach ($rowsOut as $it): $sla = tv_pulse_sla($it); $kind = (string) ($it['kind'] ?? ''); $pitem = $kind !== '' ? $it['key'] : 'pulse:' . mb_substr(preg_replace('/[^A-Za-z0-9:_.@-]/', '_', $it['key']), 0, 100);
        $grp = (int) ($it['group'] ?? 0); $par = (string) ($it['child_of'] ?? ''); ?>
      <div class="ps-row<?= $it['state'] === 'done' ? ' done' : '' ?><?= !empty($it['unread']) ? ' unread' : '' ?><?= $grp ? ' ps-group' : '' ?><?= $par !== '' ? ' ps-child' : '' ?><?= $it['over'] && $sla !== '' ? ' ps-late' . ($it['severity'] === 'critical' ? ' ps-crit' : '') : '' ?>" tabindex="0" role="button" data-key="<?= $e($it['key']) ?>" data-src="<?= $e($it['source']) ?>" data-sev="<?= $e($it['severity']) ?>"<?= $kind !== '' ? ' data-kind="' . $e($kind) . '"' : '' ?><?= $par !== '' ? ' data-parent="' . $e($par) . '"' : '' ?><?= $grp ? ' data-group="' . $grp . '" aria-expanded="false"' : '' ?>
        data-dept="<?= $e($it['dept']) ?>" data-state="<?= $it['state'] === 'done' ? 'done' : 'open' ?>" data-mine="<?= $it['mine'] ? 1 : 0 ?>" data-esc="<?= $it['esc_to_me'] ? 1 : 0 ?>" data-over="<?= !empty($it['over']) ? 1 : 0 ?>" data-item="<?= $e($pitem) ?>" data-from="<?= $e($it['from'] ?? Pulse::SOURCES[$it['source']][0]) ?>" data-sevrank="<?= (int) ($SEVRANK[$it['severity']] ?? 9) + (!empty($it['over']) ? 0 : 20) ?>" data-at="<?= $it['when'] !== '' ? (int) strtotime($it['when']) : 0 ?>"
        data-text="<?= $e(mb_strtolower($it['title'] . ' ' . $it['why'] . ' ' . ($it['from'] ?? '') . ' ' . ($it['mailbox'] ?? '') . ' ' . Pulse::SOURCES[$it['source']][0])) ?>">
        <span class="ps-ic" aria-hidden="true"><?= tv_icon((string) ($it['icon'] ?? Pulse::SOURCES[$it['source']][1]), 'pu-svg') ?></span>
        <span class="ps-src"><?= $e($it['from'] ?? Pulse::SOURCES[$it['source']][0]) ?> <span class="ps-sevm ps-sev <?= $it['severity'] ?>"><?= $it['over'] && $sla !== '' ? '<i class="ps-due" role="img" title="' . $e(Pulse::SEVERITY[$it['severity']] . ' · ' . $sla) . '" aria-label="' . $e(Pulse::SEVERITY[$it['severity']] . ', ' . $sla) . '">' . (function_exists('tv_icon') ? tv_icon('clock', 'ps-due-i') : '') . '</i>' : $sevIcon($it['severity']) ?> <?= $e(Pulse::SEVERITY[$it['severity']]) ?></span></span>
        <span class="ps-sev <?= $it['severity'] ?>" title="<?= $e(Pulse::SEVERITY[$it['severity']]) ?>"><?= $it['over'] && $sla !== '' ? '<i class="ps-due" role="img" title="' . $e(Pulse::SEVERITY[$it['severity']] . ' · ' . $sla) . '" aria-label="' . $e(Pulse::SEVERITY[$it['severity']] . ', ' . $sla) . '">' . (function_exists('tv_icon') ? tv_icon('clock', 'ps-due-i') : '') . '</i>' : $sevIcon($it['severity']) ?><span class="sr-only"><?= $e(Pulse::SEVERITY[$it['severity']]) ?></span></span>
        <span class="ps-sub"><?php if ($grp): ?><button type="button" class="ps-gn" data-group-toggle title="Show the <?= $grp ?> alarms in this group" aria-label="Show the <?= $grp ?> alarms in this group"></button><?php endif; ?><?php if ($kind === 'mail'): ?><span class="ps-box" title="Came to <?= $e($it['mailbox']) ?>"><?= $e($it['mailbox']) ?></span><?php endif; ?><b><?= $e($it['title']) ?></b><?php if (!empty($it['attach'])): ?><span class="ps-clip" title="Has attachments" aria-label="Has attachments"><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11.5l-8.2 8.2a5 5 0 0 1-7.1-7.1L13 4.3a3.4 3.4 0 0 1 4.8 4.8l-8.3 8.3a1.7 1.7 0 0 1-2.4-2.4L15 7.1"/></svg></span><?php endif; ?><?php if ($kind === ''): ?><button type="button" class="ps-next" data-open title="Open it here: its next step is inside"><?= $e($it['action']) ?></button><?php endif; ?>
          <span class="ps-pills"><?= $it['esc'] ? '<span class="ps-pill red">Escalated to ' . ($it['esc'] === 1 ? 'Manager' : 'Director') . '</span>' : '' ?><?= $it['who'] !== '' ? '<span class="ps-pill ok">' . ($it['mine'] ? 'Yours' : $e($it['who'])) . '</span>' : '' ?><?= $it['state'] === 'done' ? '<span class="ps-pill ok">Resolved</span>' : '' ?></span>
          <?= $it['why'] !== '' ? '<small>' . $e($it['why']) . '</small>' : '' ?><span class="ps-marks"></span>
</span>
        <span class="ps-when"><?php $wt = $it['when'] !== '' ? (int) strtotime($it['when']) : 0;   // the date; today, the time (Jason, 2026-11-19); the moment on hover, labeled
          echo $wt ? '<time class="ps-at" datetime="' . $e(date('c', $wt)) . '" title="' . $e(date('M j, Y, g:i A T', $wt)) . '">' . $e(date('Y-m-d', $wt) === date('Y-m-d') ? date('g:i A', $wt) : (date('Y', $wt) === date('Y') ? date('M j', $wt) : date('M j, Y', $wt))) . '</time>' : ''; ?></span>
        <span class="ps-icons" role="group" aria-label="Manage it"><?php $openI = null; ob_start(); foreach ($ICONS as [$ia, $ip, $il]): $il = $ICONK[$kind][$ia] ?? $il; $off = str_starts_with($il, '!'); $il = ltrim($il, '!'); if ($ia === 'open') { $openI = [$ip, $il]; continue; } $why = $off && strpos($il, ': ') !== false ? substr($il, strpos($il, ': ') + 2) : ''; $lab = $why !== '' ? substr($il, 0, strpos($il, ': ')) : $il; ?><button type="button" class="ps-i" role="menuitem" data-ia="<?= $ia ?>" title="<?= $e($il) ?>"<?= $ia === 'pin' ? ' aria-pressed="false"' : '' ?><?= $off ? ' aria-disabled="true"' : '' ?>><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><?= $ip ?></svg><span><?= $e($lab) ?><?= $why !== '' ? '<small>' . $e($why) . '</small>' : '' ?></span></button><?php endforeach; $menuI = ob_get_clean(); ?><?php if ($openI): ?><button type="button" class="ps-i ps-open-b" data-ia="open" title="<?= $e($openI[1]) ?>" aria-label="<?= $e($openI[1]) ?>"><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><?= $openI[0] ?></svg></button><?php endif; ?><button type="button" class="ps-i ps-more" data-ia="more" title="More actions" aria-label="More actions" aria-haspopup="menu" aria-expanded="false"><svg class="pu-svg" viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/></svg></button><span class="ps-menu" role="menu" aria-label="Actions"><?= $menuI ?></span></span>

      </div>
      <?php endforeach; ?>
      <p class="ps-empty" hidden>Nothing here. All caught up.</p>
    </div>
    <div class="ps-pg ak-pg" id="ps-pg" aria-label="Pages"></div>
  </section>
</div>

<div class="pb-dr" id="pb-dr" hidden>
  <div class="pb-shade" data-dr-close aria-hidden="true"></div>
  <section class="pb-tool" id="pb-tool" aria-label="The tool" hidden>
    <div class="pb-tool-bar"><button type="button" data-tool-close>&larr; Case</button><b id="pb-tool-t"></b><a id="pb-tool-full" href="#" target="_blank" rel="noopener">Full page &#8599;</a></div>
    <div class="pb-tool-sc"><iframe id="pb-tool-f" title="The tool"></iframe></div>
  </section>
  <aside class="pb-case" role="dialog" aria-modal="true" aria-labelledby="pb-dr-h">
    <div class="pb-case-hd"><div class="top"><div style="flex:1;min-width:0"><small id="pb-dr-no">Case</small><h3 id="pb-dr-h"></h3></div><span class="pb-pn" role="group" aria-label="Move through the list"><button type="button" data-pn="-1" title="Previous in the list" aria-label="Previous in the list">&lsaquo;</button><button type="button" data-pn="1" title="Next in the list" aria-label="Next in the list">&rsaquo;</button></span><button type="button" class="pb-btn sm" data-work hidden>Work on it</button><button type="button" class="x" data-dr-close aria-label="Close">&times;</button></div>
      <div class="pb-chips2" id="pb-dr-chips" role="group" aria-label="About this case (tap for what each means)"></div>
      <p class="pb-ex" id="pb-dr-ex" hidden></p></div>
    <div class="pb-case-in">
      <p class="pb-why" id="pb-dr-why"></p>
      <div id="pb-dr-order" hidden><ol class="pb-steps" id="pb-dr-steps" aria-label="Where the order is"></ol></div>
      <div id="pb-dr-vend" hidden></div>
      <h4 style="margin-top:.2rem">How to clear this</h4>
      <ol class="pb-play" id="pb-dr-play"></ol>
      <button type="button" class="pb-opentool" id="pb-dr-tool" data-tool-open><?= tv_icon('link', 'pu-svg') ?><span>Open the order</span></button>
      <div class="pb-acts">
        <button type="button" class="pb-btn sm" data-dr="mine" id="pb-dr-take">Take it</button>
        <label class="sr-only" for="pb-dr-to">Assign to</label><select id="pb-dr-to"></select>
        <button type="button" class="pb-btn sm" data-dr="escalate" id="pb-dr-esc">Escalate</button>
        <button type="button" class="pb-btn go" data-dr="done" id="pb-dr-done">Resolve</button>
      </div>
      <div class="pb-post">
        <label class="sr-only" for="pb-dr-body">Comment</label>
        <textarea id="pb-dr-body" placeholder="Write a comment…"></textarea>
        <div class="row" style="justify-content:space-between"><span class="pb-seg" role="group" aria-label="Post as" id="pb-dr-mode"></span><button type="button" class="pb-btn" data-dr-post>Post</button></div>
        <p class="pb-msg" id="pb-dr-msg" role="status"></p>
      </div>
      <div id="pb-dr-mgw"><h4>Manage</h4><div class="pb-mg" id="pb-dr-mg"></div></div>
      <div class="pb-form" id="pb-dr-form" hidden></div>
      <h4>History</h4>
      <ul class="pb-tl" id="pb-dr-hist"></ul>
    </div>
  </aside>
</div>
<script type="application/json" id="pb-data"><?= json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?></script>
<script>
(function () {
  var CSRF = <?= json_encode((string) ($_SESSION['csrf_token'] ?? '')) ?>, D = JSON.parse(document.getElementById('pb-data').textContent);
  var root = document.getElementById('pb'), rows = [].slice.call(document.querySelectorAll('.ps-row')), qrows = [].slice.call(document.querySelectorAll('.pq-row'));
  var chip = '', q = '', qsrc = '', cur = null, dr = document.getElementById('pb-dr'), G = {};
  if (/^#mail\b/.test(location.hash)) chip = 'mail';   // from Dashboard → My inbox: "See them in Pulse"
  function api(body) {
    var dd = body.key && D[body.key];   // a row split out of a bundle acts through its bundle's case, its step numbered as there
    if (dd && dd.parent) { body = Object.assign({}, body, { key: dd.parent }); if (typeof body.n === 'number') body.n += dd.offset || 0; }
    return fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); });
  }
  function el(t, txt) { var n = document.createElement(t); if (txt != null) n.textContent = txt; return n; }
  function apply() {
    var n = 0;
    rows.forEach(function (r) {
      var s = r.dataset, open = s.state !== 'done', show;
      show = chip === 'done' ? !open : open;
      if (chip === 'mine') show = open && s.mine === '1';
      if (chip === 'bell') show = open && (s.sev === 'critical' || s.esc === '1' || s.over === '1');
      if (chip === 'mail') show = s.kind === 'mail';   // Mail: what Dashboard → My inbox shows, here as rows
      else if (s.kind && chip && chip !== 'bell' && chip !== 'mine') show = false;   // a message or an email isn't a queue, an order or a health item
      if (s.parent && !G[s.parent]) show = false;   // a group's alarms show when the group is opened
      if (q && s.text.indexOf(q) < 0) show = false;
      if (typeof T !== 'undefined' && T) { if (T.from.length && T.from.indexOf(s.from) < 0) show = false; if (T.sev.length && T.sev.indexOf(s.sev) < 0) show = false; }   // the header's filters
      var MM = typeof M !== 'undefined' && M ? M : { marks: {}, view: '' }, mk = MM.marks[s.item] || {}, filed = mk.archived || mk.folder;   // the person's own views (decisions/0172): filed and archived rows leave the Inbox
      if (MM.view === '' && filed) show = false;
      if (MM.view === 'pinned') show = !!mk.pinned; else if (MM.view === 'flagged') show = mk.flag === 'open'; else if (MM.view === 'archived') show = !!mk.archived;
      else if (MM.view.indexOf('folder:') === 0) show = mk.folder === MM.view.slice(7);
      r.hidden = !show; if (show) n++;
      var op = r.nextElementSibling; if (op && op.classList.contains('ps-open')) op.hidden = !show;
    });
    document.querySelector('#ps-list .ps-empty').hidden = n > 0;
    qrows.forEach(function (r) { r.hidden = (qsrc && r.dataset.src !== qsrc); });
  }
  document.querySelectorAll('[data-chip]').forEach(function (c) { c.addEventListener('click', function () {
    var on = c.getAttribute('aria-pressed') !== 'true';
    document.querySelectorAll('[data-chip]').forEach(function (o) { o.setAttribute('aria-pressed', 'false'); });
    c.setAttribute('aria-pressed', on ? 'true' : 'false'); chip = on ? c.dataset.chip : ''; document.querySelector('[data-chip-bell]').setAttribute('aria-pressed', 'false'); apply();
  }); });
  if (chip) { var c0 = document.querySelector('[data-chip="' + chip + '"]'); if (c0) c0.setAttribute('aria-pressed', 'true'); }
  document.querySelector('[data-chip-bell]').addEventListener('click', function () {
    document.querySelectorAll('[data-chip]').forEach(function (o) { o.setAttribute('aria-pressed', 'false'); });
    chip = chip === 'bell' ? '' : 'bell'; this.setAttribute('aria-pressed', chip === 'bell' ? 'true' : 'false'); apply(); document.getElementById('pu-stream').scrollIntoView({ behavior: 'smooth' });
  });
  var qdd = document.getElementById('pq-dd');
  if (qdd) {
    qdd.querySelectorAll('[data-qsrc]').forEach(function (b) { b.addEventListener('click', function () {
      qdd.querySelectorAll('[data-qsrc]').forEach(function (o) { o.setAttribute('aria-checked', o === b ? 'true' : 'false'); });
      qsrc = b.dataset.qsrc; qdd.querySelector('[data-qlab]').textContent = b.dataset.lab; qdd.querySelector('[data-qn]').textContent = b.dataset.n;
      qdd.classList.toggle('on', qsrc !== ''); qdd.removeAttribute('open'); apply();
    }); });
    document.addEventListener('click', function (e) { if (qdd.open && !qdd.contains(e.target)) qdd.removeAttribute('open'); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') qdd.removeAttribute('open'); });
  }
  document.getElementById('pb-q').addEventListener('input', function () { q = this.value.trim().toLowerCase(); apply(); });
  (function () {   // + New: a menu of what you can start; each opens here with Back and × (Jason, 2026-11-19)
    var d = document.querySelector('.pb-newp'), panes = d.querySelectorAll('[data-new-pane]');
    function show(k) { panes.forEach(function (x) { x.hidden = x.dataset.newPane !== k; });
      if (k === 'post') document.getElementById('pb-body').focus();
      if (k === 'task') { var sel = document.getElementById('pb-tfor'); document.getElementById('pb-twhat').focus();
        if (!sel.dataset.done) team().then(function (t) { sel.dataset.done = '1'; t.forEach(function (p) { var o = document.createElement('option'); o.value = String(p.id); o.textContent = p.name; sel.appendChild(o); }); }).catch(function () {}); } }
    d.addEventListener('toggle', function () { if (d.open) show('menu'); });
    d.addEventListener('click', function (e) { var b = e.target.closest('[data-new]'); if (b) { e.preventDefault(); show(b.dataset.new); } if (e.target.closest('[data-new-back]')) show('menu');
      if (e.target.closest('[data-qa]')) d.removeAttribute('open'); });   // an order or a listing opens in the side panel
    d.querySelector('form[data-new-pane=task]').addEventListener('submit', function (e) { e.preventDefault(); var f = this, btn = f.querySelector('[type=submit]'), what = f.what.value.trim(); if (!what) return;
      var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (x) {}
      if (window.TvAsk) TvAsk.busy(btn, true);
      api({ do: 'task', key: '', item: '', to: +f.to.value, due: f.due.value, tz: tz, what: what }).then(function (j) { if (window.TvAsk) TvAsk.busy(btn, false); if (!j.ok) throw new Error(j.error.message);
        f.what.value = ''; say(j.message || 'Task given.', btn); show('menu'); }).catch(function (x) { if (window.TvAsk) TvAsk.busy(btn, false); say(x.message, btn, true); }); });
  })();
  // the pop-ups (Your day, Quick actions, the filter button) close on a click outside them and on Esc
  document.addEventListener('click', function (e) { document.querySelectorAll('.pb-pop[open], .pb-fdd[open]').forEach(function (d) { if (!d.contains(e.target)) d.removeAttribute('open'); }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.querySelectorAll('.pb-pop[open], .pb-fdd[open]').forEach(function (d) { d.removeAttribute('open'); }); });
  document.addEventListener('click', function (e) { var c = e.target.closest('[data-pop-close]'); if (c) { var d = c.closest('details'); if (d) d.removeAttribute('open'); } });   // the dim and × close Your day
  function paintFdd() {   // "Inbox · Alerts (8)": the list, the view, how many show
    var lab = document.querySelector('[data-fdd-lab]'), n = document.querySelector('[data-fdd-n]'); if (!lab) return;
    var v = document.querySelector('#ps-views [aria-pressed=true]'), c = document.querySelector('.pb-chips [aria-pressed=true]');
    lab.textContent = (v ? v.textContent : 'Inbox') + ' · ' + (c ? c.textContent.replace(/\s*\(\d+\)\s*$/, '') : (chip === 'bell' ? 'The bell' : 'All'));
    n.textContent = '(' + shownN + ')';
    document.getElementById('pb-fdd').classList.toggle('on', !!c || (v && v.dataset.view !== ''));
  }
  // paging (design/table-standard.md item 9): newest first stays the order; a page of N; the count says what matches
  var PG = { p: 0, per: 50, sig: '' }; try { var pp = +localStorage.getItem('pb_per'); if ([10, 25, 50, 100].indexOf(pp) >= 0) PG.per = pp; } catch (x) {}
  var pgEl = document.getElementById('ps-pg'), shownN = 0;
  function page() {
    var MM = typeof M !== 'undefined' && M ? M : { view: '' }, TT = typeof T !== 'undefined' && T ? T : { from: [], sev: [], sort: '' };
    var sig = [GB, q, chip, MM.view, TT.from.join(','), TT.sev.join(','), TT.sort, TT.dir].join('|'), filtered = !!(q || chip || MM.view || TT.from.length || TT.sev.length);
    if (sig !== PG.sig) { PG.sig = sig; PG.p = 0; }   // a new filter or sort starts at page 1
    var list = document.getElementById('ps-list'), units = [].slice.call(list.querySelectorAll('.ps-row')).filter(function (r) { return !r.hidden && !r.dataset.parent && !r.hasAttribute('data-gm'); });   // a group is one row
    var n = units.length, pages = Math.max(1, Math.ceil(n / PG.per)); if (PG.p >= pages) PG.p = pages - 1;
    var a = PG.p * PG.per, z = Math.min(n, a + PG.per), keep = {};
    units.forEach(function (r, i) { var on = i >= a && i < z; if (r.classList.contains('ps-ghead')) { r.hidden = !on; return; } if (!on) { r.hidden = true; var op = r.nextElementSibling; if (op && op.classList.contains('ps-open')) op.hidden = true; } keep[r.dataset.key] = on; });
    rows.forEach(function (r) { if (r.dataset.parent && keep[r.dataset.parent] === false) r.hidden = true; });
    list.querySelectorAll('.ps-ghead').forEach(function (h) { keep['g:' + h.dataset.gkey] = !h.hidden; });
    rows.forEach(function (r) { if (r.hasAttribute('data-gm') && keep['g:' + r.getAttribute('data-gm')] === false) r.hidden = true; });
    if (cur && keep[cur] === false) close();   // an open row closes when its page goes
    shownN = n;
    var pb = function (p, label, cur2, aria, off, num) { return '<button type="button" class="ak-pgb" data-pg="' + p + '"' + (num ? ' data-n' : '') + (cur2 ? ' aria-current="page"' : '') + (off ? ' disabled' : '') + ' aria-label="' + aria + '">' + label + '</button>'; };
    var nav = '';
    if (pages > 1) { var want = {}; [0, pages - 1, PG.p - 1, PG.p, PG.p + 1].forEach(function (x) { if (x >= 0 && x < pages) want[x] = 1; }); var last = -1;
      nav = pb(PG.p - 1, '‹', false, 'Previous page', PG.p <= 0);
      Object.keys(want).map(Number).sort(function (m, k) { return m - k; }).forEach(function (x) { if (last >= 0 && x > last + 1) nav += '<span class="ak-gap" data-n>…</span>'; nav += pb(x, x + 1, x === PG.p, 'Page ' + (x + 1), false, true); last = x; });
      nav += '<span class="ps-pn">Page ' + (PG.p + 1) + ' of ' + pages + '</span>' + pb(PG.p + 1, '›', false, 'Next page', PG.p >= pages - 1); }
    pgEl.innerHTML = n ? (nav ? '<nav aria-label="Pages">' + nav + '</nav>' : '') + '<span class="ak-range">' + (a + 1).toLocaleString() + '–' + z.toLocaleString() + ' of ' + n.toLocaleString() + (filtered ? ' match' : '') + '</span>'
      + '<label>Show <select data-per aria-label="How many a page">' + [10, 25, 50, 100].map(function (k) { return '<option' + (k === PG.per ? ' selected' : '') + '>' + k + '</option>'; }).join('') + '</select> a page</label>' : '';
  }
  pgEl.addEventListener('click', function (e) { var b = e.target.closest('[data-pg]'); if (!b || b.disabled) return; PG.p = +b.dataset.pg; applyBase(); page(); paintFdd(); document.getElementById('pu-stream').scrollIntoView({ block: 'start', behavior: 'smooth' }); });
  pgEl.addEventListener('change', function (e) { if (!e.target.matches('[data-per]')) return; var first = PG.p * PG.per; PG.per = +e.target.value; PG.p = Math.floor(first / PG.per); try { localStorage.setItem('pb_per', PG.per); } catch (x) {} applyBase(); page(); paintFdd(); });
  // Group by (the person's own view): one header per sender, kind or level, in the order the stream has them; it opens in place
  var GB = ''; try { GB = localStorage.getItem('pb_group') || ''; } catch (x) {} if (['', 'from', 'src', 'sev'].indexOf(GB) < 0) GB = '';
  var GO = {};
  function gname(v) { return GB === 'sev' ? (SEVN[v] || v) : GB === 'src' ? (SRCN[v] || v) : v; }
  function regroup() {
    var list = document.getElementById('ps-list'), empty = list.querySelector('.ps-empty');
    list.querySelectorAll('.ps-ghead').forEach(function (h) { h.remove(); }); rows.forEach(function (r) { r.removeAttribute('data-gm'); });
    var lab = document.querySelector('[data-gb-lab]'); if (lab) lab.textContent = 'Group: ' + ({ '': 'None', from: 'Sender', src: 'Kind', sev: 'Level' })[GB];
    document.querySelectorAll('[data-gb]').forEach(function (b) { b.setAttribute('aria-checked', b.dataset.gb === GB ? 'true' : 'false'); });
    document.getElementById('pb-gdd').classList.toggle('on', !!GB);
    if (!GB) return;
    var tops = [].slice.call(list.querySelectorAll('.ps-row')).filter(function (r) { return !r.dataset.parent; }), groups = [], by = {};
    tops.forEach(function (r) { var k = r.dataset[GB] || ''; if (!by[k]) { by[k] = []; groups.push(k); } by[k].push(r); });
    groups.forEach(function (k) {
      var members = by[k], shown = members.filter(function (r) { return !r.hidden; }); if (!shown.length) return;
      var h = document.createElement('div'); h.className = 'ps-row ps-ghead'; h.dataset.gkey = k; h.setAttribute('aria-expanded', GO[GB + ':' + k] ? 'true' : 'false');
      h.innerHTML = '<button type="button" class="ps-gb" aria-expanded="' + (GO[GB + ':' + k] ? 'true' : 'false') + '"><span class="ps-gcar" aria-hidden="true">▸</span><span></span><span class="ps-gcount"></span></button>';
      h.querySelector('span:nth-child(2)').textContent = gname(k) || '(none)'; h.querySelector('.ps-gcount').textContent = shown.length;
      list.insertBefore(h, empty);
      members.forEach(function (r) {   // the row, its opened part and its own members move together
        var tail = [r], n = r.nextElementSibling; while (n && (n.classList.contains('ps-open') || (n.dataset.parent && n.dataset.parent === r.dataset.key))) { tail.push(n); n = n.nextElementSibling; }
        tail.forEach(function (x) { list.insertBefore(x, empty); });
        r.setAttribute('data-gm', k); if (!GO[GB + ':' + k]) { r.hidden = true; tail.slice(1).forEach(function (x) { x.hidden = true; }); }
      });
    });
  }
  document.getElementById('ps-list').addEventListener('click', function (e) {
    var h = e.target.closest('.ps-ghead'); if (!h) return; var k = GB + ':' + h.dataset.gkey; GO[k] = !GO[k]; apply();
  });
  document.getElementById('pb-gdd').addEventListener('click', function (e) {
    var b = e.target.closest('[data-gb]'); if (!b) return; GB = b.dataset.gb; GO = {}; try { localStorage.setItem('pb_group', GB); } catch (x) {} this.removeAttribute('open'); apply();
  });
  var applyBase = apply; apply = function () { applyBase(); regroup(); page(); paintFdd(); };
  var sortBase = sortRows; sortRows = function () { sortBase(); apply(); };
  document.querySelectorAll('[data-chip]').forEach(function (c) { c.addEventListener('click', function () { var d = document.getElementById('pb-fdd'); if (d) d.removeAttribute('open'); }); });
  document.querySelector('[data-post-team]').addEventListener('click', function () {
    var t = document.getElementById('pb-body'), m = document.getElementById('pb-msg');
    api({ do: 'post', key: '', dept: document.getElementById('pb-dept').value, body: t.value }).then(function (j) {
      m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? j.message + ' It shows in the stream next time it loads.' : j.error.message; if (j.ok) t.value = '';
    });
  });

  // the person's own marks on each row (decisions/0172 "Flags and tags in Pulse"; /user/api/marks.php): never shown to anyone else
  var M = { marks: {}, tags: [], folders: {}, csrf: '', view: '' };
  try { M.view = localStorage.getItem('pb_view') || ''; } catch (x) {}
  // beside what was clicked, except in the table's header and a row's icon pill: there a notice would squeeze into a column, so the centered notice
  function say(m, el, bad) { if (!window.TvAsk) return; var o = { bad: !!bad }; if (el && !el.closest('.ps-hd, .ps-icons')) o.anchor = el; TvAsk.say(m, o); }
  function mpost(body) {
    return fetch('/user/api/marks.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': M.csrf || CSRF }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t save.'); return j; });
  }
  function loadMarks() {
    var items = rows.map(function (r) { return r.dataset.item; });
    fetch('/user/api/marks.php?items=' + encodeURIComponent(items.join(',')), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok) return; M.marks = j.marks || {}; M.tags = j.tags || []; M.folders = j.folders || {}; M.csrf = j.csrf || M.csrf; paintMarks(); apply();
    }).catch(function () {});
  }
  function paintMarks() {
    var tagBy = {}; M.tags.forEach(function (t) { tagBy[t.id] = t; });
    var list = document.getElementById('ps-list'), pinned = [];
    rows.forEach(function (r) {
      var m = M.marks[r.dataset.item] || {}, b = r.querySelector('.ps-marks');
      r.classList.toggle('unread', !!m.back);
      var pi = r.querySelector('[data-ia="pin"]'); if (pi) pi.setAttribute('aria-pressed', m.pinned ? 'true' : 'false');
      if (b) { b.textContent = '';
        if (m.flag === 'open') b.appendChild(el('span', 'Follow up' + (m.due ? ' · ' + new Date(m.due.replace(' ', 'T')).toLocaleDateString([], { month: 'short', day: 'numeric' }) : ''))).className = 'fl';
        if (m.flag === 'done') b.appendChild(el('span', 'Followed up')).className = 'fl';
        if (m.importance) b.appendChild(el('span', m.importance === 'high' ? 'High' : 'Low')).className = 'im';
        (m.tags || []).forEach(function (t) { var x = tagBy[t]; if (x) { var sp = el('span', x.name); sp.style.borderColor = x.colour; sp.style.color = x.colour; b.appendChild(sp); } });
        if (m.folder) b.appendChild(el('span', 'In ' + m.folder));
      }
      if (m.pinned) pinned.push(r);
    });
    pinned.reverse().forEach(function (r) { var o = r.nextElementSibling; list.insertBefore(r, list.firstChild); if (o && o.classList.contains('ps-open')) r.insertAdjacentElement('afterend', o); });   // the person's pins, at the top of their own list
    var v = document.getElementById('ps-views');
    var opts = [['', 'Inbox'], ['pinned', 'Pinned'], ['flagged', 'Follow up'], ['archived', 'Archived']].concat(Object.keys(M.folders).map(function (f) { return ['folder:' + f, f]; }));
    v.textContent = '';
    opts.forEach(function (o) { var b2 = el('button', o[1]); b2.type = 'button'; b2.className = 'pb-chip'; b2.dataset.view = o[0]; b2.setAttribute('aria-pressed', M.view === o[0] ? 'true' : 'false'); v.appendChild(b2); });
  }
  document.getElementById('ps-views').addEventListener('click', function (e) {
    var b = e.target.closest('[data-view]'); if (!b) return;
    M.view = b.dataset.view; try { localStorage.setItem('pb_view', M.view); } catch (x) {} paintMarks(); apply(); var fd = document.getElementById('pb-fdd'); if (fd) fd.removeAttribute('open');
  });
  function mark(r, a, set, said) {
    var key = r.dataset.item;
    if (window.TvAsk) TvAsk.busy(a, true);
    return mpost({ item: key, set: set }).then(function (j) { if (window.TvAsk) TvAsk.busy(a, false); say(said || j.message, a); M.marks[key] = j.marks; paintMarks(); apply(); })
      .catch(function (x) { if (window.TvAsk) TvAsk.busy(a, false); say(x.message, a, true); });
  }
  function markRead(r) {   // opening it reads it (quietly)
    var m = M.marks[r.dataset.item]; if (!m || !m.back) return;
    mpost({ item: r.dataset.item, set: { read: true } }).then(function (j) { M.marks[r.dataset.item] = j.marks; paintMarks(); }).catch(function () {});
  }
  document.addEventListener('click', function (e) { setTimeout(function () { document.querySelectorAll('.ps-icons.more').forEach(function (b) {
    if (!b.contains(e.target) || e.target.closest('.ps-menu .ps-i')) { b.classList.remove('more'); var mb = b.querySelector('.ps-more'); if (mb) mb.setAttribute('aria-expanded', 'false'); }
    else { var mr = b.getBoundingClientRect(); b.classList.toggle('up', mr.bottom + 280 > window.innerHeight && mr.top > 300); } }); }, 0); });   // opens upward near the bottom of the screen
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.querySelectorAll('.ps-icons.more').forEach(function (b) { b.classList.remove('more'); }); });
  function icon(r, a) {
    var k = r.dataset.key, w = a.dataset.ia, m = M.marks[r.dataset.item] || {};
    if (a.getAttribute('aria-disabled') === 'true') { say(a.title, a, true); return; }   // greyed: its reason, never a dead click
    if (w === 'open') { if (r.dataset.group) { toggleGroup(r); return; } open(k); return; }
    if (r.dataset.kind && (w === 'read' || w === 'pass' || w === 'protect')) { kindIcon(r, a, w, m); return; }
    if (w === 'more') { var bx = a.parentNode, on2 = !bx.classList.contains('more'); bx.classList.toggle('more', on2); a.setAttribute('aria-expanded', String(on2)); return; }   // on a phone: the six fold into ⋯
    if (w === 'read') { mark(r, a, { unread: !m.back }, m.back ? 'Marked read.' : 'Marked unread.'); return; }
    if (w === 'pin') { mark(r, a, { pinned: !m.pinned }); return; }
    if (w === 'pass') { if (cur !== k || !inPlace) open(k); setTimeout(function () { var s = document.getElementById('pb-dr-to'); s.scrollIntoView({ block: 'center' }); s.focus(); say('Choose who takes it: they\'re told by Pulse and email.', s); }, 250); return; }
    if (w === 'protect') {
      if (D[k].state === 'done' || (D[k].esc || 0) >= 2) { say(D[k].state === 'done' ? 'It\'s resolved: reopen it first.' : 'It\'s already with the Director.', a, true); return; }
      if (!TvAsk.gate(a, 'Escalate it to the ' + ((D[k].esc || 0) ? 'Director' : 'Manager') + ' of its department?', { yes: 'Escalate' })) return;
      if (window.TvAsk) TvAsk.busy(a, true);
      api({ do: 'escalate', key: k }).then(function (j) { if (window.TvAsk) TvAsk.busy(a, false); if (!j.ok) { say(j.error.message, a, true); return; } D[k].esc = Math.min(2, (D[k].esc || 0) + 1); say(j.message || 'Escalated.', a); if (cur === k) fill(j); });
      return;
    }
    if (w === 'file') {
      var fch = [['__archive', 'Archive', 'Out of the list; Archived shows it.']].concat(Object.keys(M.folders).map(function (f) { return [f, f, '']; })).concat([['__new', 'A new folder…', ''], ['__back', 'Back in the list', '']]);
      TvAsk.choose('File it', fch, m.archived ? '__archive' : (m.folder || ''), { yes: 'File it' }).then(function (v) {
        if (!v) return;
        if (v === '__archive') return mark(r, a, { archived: true });
        if (v === '__back') return mark(r, a, { folder: '' });
        if (v === '__new') return TvAsk.ask('New folder', '').then(function (n) { if (n) { M.folders[n] = 0; mark(r, a, { folder: n }); } });
        mark(r, a, { folder: v });
      });
      return;
    }
    if (w === 'add') {
      var ch = [['today', 'Follow up today', ''], ['tomorrow', 'Follow up tomorrow', ''], ['week', 'Follow up this week', ''], ['nextweek', 'Follow up next week', ''], ['date', 'Follow up on a date', '']];
      if (m.flag === 'open') ch.push(['done', 'Mark the follow-up complete', ''], ['clear', 'Clear the flag', '']);
      ch.push(['high', 'High importance', 'Only for you.'], ['low', 'Low importance', ''], ['noimp', 'No importance', ''], ['tags', 'Tags…', 'Your own, or the team\'s shared tags.']);
      ch.push(['task', 'A task…', 'For you or a teammate, with a day: it arrives in their Pulse and comes back then.']);
      if (r.dataset.kind === 'mail') ch.push(['case', 'Make it a case', 'An outside email becomes one of ours, the email inside it; replies stay in the same thread.'], ['contact', 'The sender to the Address Book', 'When the sender is on Traversence: a connection request.']);
      if (!r.dataset.kind) ch.push(['note', 'A note for the team', 'Written in the case.']);
      TvAsk.choose('Add to', ch, '', { yes: 'Choose' }).then(function (v) {
        if (!v) return;
        var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (x) {}
        if (['today', 'tomorrow', 'week', 'nextweek'].indexOf(v) >= 0) return mark(r, a, { follow: v, tz: tz });
        if (v === 'date') return TvAsk.ask('Follow up on (YYYY-MM-DD)', '').then(function (d) { if (d) mark(r, a, { follow: 'date', date: String(d).trim(), tz: tz }); });
        if (v === 'done' || v === 'clear') return mark(r, a, { flag: v });
        if (v === 'high' || v === 'low' || v === 'noimp') return mark(r, a, { importance: v === 'noimp' ? '' : v });
        if (v === 'note') { if (cur !== k || !inPlace) open(k); setTimeout(function () { var t = document.getElementById('pb-dr-body'); t.scrollIntoView({ block: 'center' }); t.focus(); }, 250); return; }
        if (v === 'task') return task(r, a);
        if (v === 'case' || v === 'contact') { TvAsk.busy(a, true); return api({ do: v === 'case' ? 'mail_case' : 'mail_contact', item: r.dataset.item }).then(function (j) { TvAsk.busy(a, false); say(j.ok ? j.message : j.error.message, a, !j.ok); }); }
        if (v === 'tags') {
          var tc = M.tags.map(function (t) { return [String(t.id), t.name, t.shared ? 'Shared with the team' : '']; }).concat([['new', 'A new tag…', ''], ['newteam', 'A new tag for the whole team…', '']]);
          return TvAsk.choose('Tags', tc, (m.tags || []).join(','), { multi: true }).then(function (picked) {
            if (picked === null) return;
            var all = picked.split(','), ids = all.filter(function (x) { return x && x !== 'new' && x !== 'newteam'; });
            var nw = all.indexOf('newteam') >= 0 ? 'staff:0' : all.indexOf('new') >= 0 ? 'mine' : '';
            if (!nw) return mark(r, a, { tags: ids });
            return TvAsk.ask('New tag', '').then(function (name) {
              if (!name) return;
              return mpost({ tag: { name: name, scope: nw === 'mine' ? '' : nw } }).then(function (j) { M.tags.push(j.tag); ids.push(String(j.tag.id)); return mark(r, a, { tags: ids }); });
            });
          });
        }
      });
    }
  }
  // ---- a message or an email in the stream (G6, G7) -------------------------------------------------------------------
  function team() {   // who a task or a forward can go to: the staff list the case drawer uses
    if (team.p) return team.p;
    return (team.p = api({ do: 'team' }).then(function (j) { if (!j.ok) throw new Error(j.error.message); return j.team || []; }));
  }
  function actPost(body) {   // /user/api/pulse-act.php: forward and report, shared with the member's Pulse
    return fetch('/user/api/pulse-act.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': M.csrf || CSRF }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (x) { return x.json().catch(function () { return { ok: false, error: { message: 'The server didn’t answer clearly. Try again.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn’t work.'); return j; });
  }
  function mailPost(body) {   // /user/api/mailboxes.php: read state and replies, kept in step with the mailbox
    return fetch('/user/api/mailboxes.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': M.csrf || CSRF }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (x) { return x.json(); }).then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn’t work.'); return j; });
  }
  function said(a, p) { TvAsk.busy(a, true); return p.then(function (j) { TvAsk.busy(a, false); say(j.message || 'Done.', a); return j; }).catch(function (x) { TvAsk.busy(a, false); say(x.message, a, true); }); }
  function kindIcon(r, a, w, m) {
    var k = r.dataset.key, it = D[k], mail = r.dataset.kind === 'mail';
    if (w === 'read') {
      var un = !r.classList.contains('unread');
      if (mail) { said(a, mailPost({ act: un ? 'unread' : 'read', mail: it.id })).then(function (j) { if (j) r.classList.toggle('unread', un); }); return; }
      mark(r, a, { unread: un }, un ? 'Marked unread.' : 'Marked read.'); r.classList.toggle('unread', un); return;
    }
    if (w === 'pass') {
      var ch = mail ? [['email', 'By email', 'From ' + (it.mailbox || 'its mailbox') + ', with your note above it.']]
        : [['team', 'To a teammate', 'It arrives in their Pulse, saying you passed it on.'], ['email', 'By email', 'To any address, with a line saying you forwarded it.']];
      TvAsk.choose('Pass it on', ch, ch[0][0], { yes: 'Next' }).then(function (how) {
        if (!how) return;
        if (how === 'team') return team().then(function (t) {
          return TvAsk.choose('To whom?', t.map(function (p) { return [String(p.id), p.name, '']; }), '', { yes: 'Choose' }).then(function (to) {
            if (!to) return; return TvAsk.ask('A note with it (optional)', '').then(function (note) { if (note === null) return; return said(a, actPost({ do: 'forward', item: r.dataset.item, to_user: +to, note: note || '' })); });
          });
        }).catch(function (x) { say(x.message, a, true); });
        return TvAsk.ask('Their email address', '').then(function (to) {
          if (!to) return; return TvAsk.ask('A note with it (optional)', '').then(function (note) {
            if (note === null) return;
            said(a, mail ? api({ do: 'mail_forward', item: r.dataset.item, to: String(to).trim(), note: note || '' }).then(function (j) { if (!j.ok) throw new Error(j.error.message); return j; })
                         : actPost({ do: 'forward', item: r.dataset.item, to_email: String(to).trim(), note: note || '' }));
          });
        });
      });
      return;
    }
    if (w === 'protect' && mail) {
      TvAsk.choose('Protect', [['junk', 'Junk', 'Moves it to the mailbox’s Junk folder.'], ['block', 'Block the sender', 'Their mail stops showing to you; the mailbox keeps it and they aren’t told.'],
        ['phish', 'Report phishing', 'Moves it to Junk and tells our team, with the email.']], '', { yes: 'Do it' }).then(function (v) {
        if (!v) return;
        var p2 = v === 'junk' ? mailPost({ act: 'junk', mail: it.id }) : api({ do: v === 'block' ? 'mail_block' : 'mail_phish', item: r.dataset.item }).then(function (j) { if (!j.ok) throw new Error(j.error.message); return j; });
        said(a, p2).then(function (j) { if (j) { r.hidden = true; var o = r.nextElementSibling; if (o && o.classList.contains('ps-open')) home(); } });
      });
    }
  }
  function task(r, a) {   // ⊕ A task: for you or a teammate, with a day (decisions/0172's table, a case's ⊕)
    team().then(function (t) {
      return TvAsk.choose('A task for', [['0', 'Me', '']].concat(t.map(function (p) { return [String(p.id), p.name, '']; })), '0', { yes: 'Next' }).then(function (to) {
        if (to === null || to === undefined || to === '') return;
        return TvAsk.choose('When', [['today', 'Today', ''], ['tomorrow', 'Tomorrow', ''], ['week', 'This week', ''], ['nextweek', 'Next week', '']], 'today', { yes: 'Next' }).then(function (due) {
          if (!due) return;
          return TvAsk.ask('What to do', 'Follow up: ' + (D[r.dataset.key] ? D[r.dataset.key].title : '')).then(function (what) {
            if (!what) return;
            var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (x) {}
            said(a, api({ do: 'task', key: r.dataset.key, item: r.dataset.item, to: +to, due: due, tz: tz, what: what }).then(function (j) { if (!j.ok) throw new Error(j.error.message); return j; }));
          });
        });
      });
    }).catch(function (x) { say(x.message, a, true); });
  }
  function toggleGroup(r) {   // a group of alarms: its alarms under it, one level in
    var on = !G[r.dataset.key]; G[r.dataset.key] = on; r.setAttribute('aria-expanded', String(on));
    var oi = r.querySelector('[data-ia="open"]'); if (oi) oi.setAttribute('aria-expanded', String(on));
    apply();
  }
  function openMsg(r, k) {   // a message or an email opens in place under its row, as in the member's Pulse
    var it = D[k], o = document.createElement('div'); o.className = 'ps-open'; r.insertAdjacentElement('afterend', o);
    var box = document.createElement('div'); box.className = 'ps-msgbox'; box.textContent = 'Opening…'; o.appendChild(box);
    cur = k; inPlace = true; rows.forEach(function (x) { x.classList.toggle('on', x === r); });
    var oi = r.querySelector('[data-ia="open"]'); if (oi) oi.setAttribute('aria-expanded', 'true');
    if (r.dataset.kind === 'comms') {
      var go = function () { window.TvPulseMsg.open(it.id, box).then(function () { r.classList.remove('unread'); }); };
      if (window.TvPulseMsg) go(); else { var sc = document.createElement('script'); sc.src = '/js/pulse-msg.js'; sc.onload = go; document.head.appendChild(sc); }
      return;
    }
    fetch('/user/api/mailboxes.php?thread=' + it.id + (it.pics ? '&pictures=1' : ''), { credentials: 'same-origin' }).then(function (x) { return x.json(); }).then(function (j) {
      if (!j.ok) throw new Error((j.error && j.error.message) || 'That email didn’t open.');
      r.classList.remove('unread'); box.textContent = '';
      var esc = function (v) { var d = document.createElement('div'); d.textContent = v == null ? '' : String(v); return d.innerHTML; };
      var addr = function (l) { return (l || []).map(function (x) { return esc(x.addr || x[0] || ''); }).join(', '); };
      box.innerHTML = j.messages.map(function (mm) {
        return '<div class="ps-mail"><p class="ps-mh"><b>' + esc(mm.from_name || mm.from_addr) + '</b> <span>&lt;' + esc(mm.from_addr) + '&gt;</span>'
          + '<span>To ' + addr(mm.to) + (mm.cc && mm.cc.length ? ' · Cc ' + addr(mm.cc) : '') + '</span><time datetime="' + esc(mm.sent_at) + '" data-tv-time>' + esc(mm.sent_at) + '</time></p>'
          + '<div class="ps-mb">' + (mm.html || ('<p style="white-space:pre-wrap">' + esc(mm.text || mm.body_text || '') + '</p>')) + '</div>'
          + (mm.attach && mm.attach.length ? '<p><small>Attached: ' + mm.attach.map(function (x) { return esc(x.name || 'attachment'); }).join(', ') + ' (open them in the mailbox itself for now)</small></p>' : '') + '</div>';
      }).join('') + (j.messages.some(function (mm) { return mm.held_pictures; }) ? '<p><button type="button" class="pb-btn sm" data-mail-pics>Show pictures</button></p>' : '')
        + '<form data-mail-reply><label class="sr-only" for="ps-rt-' + it.id + '">Reply</label><textarea id="ps-rt-' + it.id + '" name="text" rows="3" data-spell placeholder="Reply from ' + esc(j.mailbox ? j.mailbox.address : '') + '…"></textarea>'
        + '<div class="row"><label style="display:flex;gap:.3rem;align-items:center;font-size:.85rem">From <select name="from">' + (j.from_choices || []).map(function (f) { return '<option value="' + f.id + '"' + (j.mailbox && f.id === j.mailbox.id ? ' selected' : '') + '>' + esc(f.address) + '</option>'; }).join('') + '</select></label>'
        + '<button type="submit" class="pb-btn sm">Send reply</button></div></form>';
      var last = j.messages[j.messages.length - 1]; box.dataset.last = last.id; box.dataset.to = last.from_addr;
      if (window.TvTime) TvTime.paint(box);
    }).catch(function (x) { box.innerHTML = ''; var p = el('p', x.message + ' Try again; still stuck? Write to support@traversence.com.'); p.setAttribute('data-tv-status', 'bad'); p.setAttribute('data-tv-label', 'Error:'); box.appendChild(p); });
  }
  document.addEventListener('submit', function (ev) {
    var f = ev.target.closest && ev.target.closest('form[data-mail-reply]'); if (!f) return;
    ev.preventDefault();
    var box = f.closest('.ps-msgbox'), btn = f.querySelector('button[type=submit]'), text = f.elements.text.value.trim();
    if (!text) { say('Write something first.', btn, true); return; }
    said(btn, mailPost({ send: { from: +f.elements.from.value, to: box.dataset.to, text: text, reply_to: +box.dataset.last } })).then(function (j) { if (j) f.elements.text.value = ''; });
  });
  // Previous / Next in the drawer and in place: through the list as it's shown now (filters, sort, views)
  function stepTo(dir) {
    var wide = !dr.hidden && !inPlace;   // in the drawer: the next case (a message or an email has no drawer; it opens in place)
    var vis = rows.filter(function (r) { return !r.hidden && !r.dataset.group && (!wide || !r.dataset.kind); }), i = vis.findIndex(function (r) { return r.dataset.key === cur; });
    var nx = vis[i + dir]; if (!nx) { say(dir > 0 ? 'That’s the last one in the list.' : 'That’s the first one in the list.', document.querySelector('[data-pn="' + dir + '"]')); return; }
    if (nx.dataset.kind) { close(); open(nx.dataset.key); nx.scrollIntoView({ block: 'nearest' }); return; }
    open(nx.dataset.key, wide); nx.scrollIntoView({ block: 'nearest' });
  }

  loadMarks();

  // the stream as a table (Jason, 2026-11-18): tap a header to sort, its ▾ to filter, drag a header's edge to resize;
  // remembered in this browser. The person's pins stay on top of whatever order they choose.
  var T = { sort: '', dir: 1, from: [], sev: [] }, SEVN = <?= json_encode(Pulse::SEVERITY) ?>, SRCN = <?= json_encode(array_map(fn ($x) => $x[0], Pulse::SOURCES)) ?>;
  try { var tj = JSON.parse(localStorage.getItem('pb_table') || '{}'); T.sort = tj.sort || ''; T.dir = tj.dir || 1; T.from = tj.from || []; T.sev = tj.sev || [];
    ['from', 'sev', 'when'].forEach(function (c) { if (tj['w_' + c]) document.getElementById('pu-stream').style.setProperty('--c-' + c, tj['w_' + c]); }); } catch (x) {}
  function saveT() { try { var st = document.getElementById('pu-stream').style, o = { sort: T.sort, dir: T.dir, from: T.from, sev: T.sev }; ['from', 'sev', 'when'].forEach(function (c) { var v = st.getPropertyValue('--c-' + c); if (v) o['w_' + c] = v.trim(); }); localStorage.setItem('pb_table', JSON.stringify(o)); } catch (x) {} }
  // Received in the viewer's own zone: today the time, this year the date, older with the year; the whole moment, labeled, on hover
  (function () { var now = new Date(); document.querySelectorAll('#ps-list time.ps-at').forEach(function (t) { var d = new Date(t.getAttribute('datetime')); if (isNaN(d)) return;
    var same = d.toDateString() === now.toDateString(), yr = d.getFullYear() === now.getFullYear();
    t.textContent = same ? d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) : d.toLocaleDateString('en-US', yr ? { month: 'short', day: 'numeric' } : { month: 'short', day: 'numeric', year: 'numeric' });
    t.title = d.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short' }); }); })();
  function sortRows() {
    var list = document.getElementById('ps-list'), empty = list.querySelector('.ps-empty');
    document.querySelectorAll('#ps-hd [data-sort]').forEach(function (b) { if (b.dataset.sort === T.sort) b.setAttribute('aria-sort', T.dir > 0 ? 'ascending' : 'descending'); else b.removeAttribute('aria-sort'); });
    var key = function (r) { var d = r.dataset; return T.sort === 'from' ? d.from.toLowerCase() : T.sort === 'sev' ? +d.sevrank : T.sort === 'when' ? +d.at : (r.querySelector('.ps-sub b') || r).textContent.toLowerCase(); };
    (T.sort ? rows.slice().sort(function (a, b) { var x = key(a), y = key(b); return (x < y ? -1 : x > y ? 1 : 0) * T.dir; }) : rows.slice()).forEach(function (r) {   // no sort: the stream's own order
      var o = r.nextElementSibling; list.insertBefore(r, empty); if (o && o.classList.contains('ps-open')) r.insertAdjacentElement('afterend', o); });
    paintMarks();   // the person's pins back on top
  }
  function paintFilters() { document.querySelectorAll('#ps-hd [data-filter]').forEach(function (b) { var n = T[b.dataset.filter].length; b.setAttribute('aria-pressed', n ? 'true' : 'false'); b.title = n ? n + ' chosen: tap to change' : (b.dataset.filter === 'from' ? 'Show only some senders' : 'Show only some levels'); }); }
  document.getElementById('ps-hd').addEventListener('click', function (e) {
    var sb = e.target.closest('[data-sort]');
    if (sb) { var c = sb.dataset.sort, first = c === 'when' ? -1 : 1;   // a tap: its first order, the other way, then the stream's own order (Received used to skip oldest first)
      if (T.sort === c) { if (T.dir === first) T.dir = -first; else { T.sort = ''; T.dir = 1; } } else { T.sort = c; T.dir = first; }
      sortRows(); saveT(); return; }
    var fb = e.target.closest('[data-filter]'); if (!fb) return;
    var f = fb.dataset.filter, seen = {}, ch = [];
    rows.forEach(function (r) { var v = f === 'from' ? r.dataset.from : r.dataset.sev; if (!seen[v]) { seen[v] = 0; ch.push(v); } seen[v]++; });
    var choices = ch.sort(function (a, b) { return f === 'sev' ? Object.keys(SEVN).indexOf(a) - Object.keys(SEVN).indexOf(b) : a.localeCompare(b); }).map(function (v) { return [v, (f === 'sev' ? SEVN[v] : v) + ' (' + seen[v] + ')', '']; });
    TvAsk.choose(f === 'from' ? 'Show these senders' : 'Show these levels', choices, (T[f].length ? T[f] : ch).join(','), { multi: true, yes: 'Show', note: 'Untick any you don\'t want to see.' }).then(function (v) {   // all ticked to start (Jason, 2026-11-19)
      if (v === null) return; var picked = v ? v.split(',').filter(Boolean) : []; T[f] = picked.length >= ch.length ? [] : picked; paintFilters(); apply(); saveT();   // all ticked, or none, is everything
    });
  });
  // resizing: drag a header's edge (From, Level; Subject's edge sizes Received)
  document.getElementById('ps-hd').addEventListener('pointerdown', function (e) {
    var g = e.target.closest('[data-grip]'); if (!g) return;
    e.preventDefault(); g.setPointerCapture(e.pointerId); g.classList.add('on');
    var st = document.getElementById('pu-stream'), c = g.dataset.grip === 'sub' ? 'when' : g.dataset.grip, x0 = e.clientX;
    var w0 = c === 'when' ? st.querySelector('.ps-hd > span:nth-child(5)').getBoundingClientRect().width : g.parentNode.getBoundingClientRect().width;
    var min = { from: 64, sev: 18, when: 72 }[c], max = { from: 360, sev: 120, when: 260 }[c];
    var move = function (ev) { var d = ev.clientX - x0; var w = Math.max(min, Math.min(max, c === 'when' ? w0 - d : w0 + d)); st.style.setProperty('--c-' + c, w + 'px'); };
    var up = function () { g.classList.remove('on'); g.removeEventListener('pointermove', move); g.removeEventListener('pointerup', up); saveT(); };
    g.addEventListener('pointermove', move); g.addEventListener('pointerup', up);
  });
  paintFilters(); sortRows(); apply();

  // the case drawer
  function row(k) { return rows.filter(function (r) { return r.dataset.key === k; })[0]; }
  // the site's bell (js/pulse-msg.js): a message tapped there opens its own row here, in place (decisions/0172); and a
  // link from another page (?pulse_msg=ID) does the same once the stream is drawn
  window.TvPulse = window.TvPulse || {};
  TvPulse.openComms = function (id) { var r = row('comms:' + id); if (!r) return false; r.hidden = false; r.scrollIntoView({ block: 'center' }); open(r.dataset.key); return true; };
  setTimeout(function () { var m = /[?&]pulse_msg=(\d+)/.exec(location.search); if (m) TvPulse.openComms(m[1]); }, 0);
  var SEV = { critical: 'Critical', alert: 'Alert', update: 'Update', event: 'Event' }, mode = 'team';
  var TOOL = { order: 'Open the order', report: 'Open the report', claim: 'Open the claim', listing: 'Open the listing' };
  function toolName(u) { return /order|client-order/.test(u) ? TOOL.order : /reports/.test(u) ? TOOL.report : /claims/.test(u) ? TOOL.claim : 'Open the tool'; }
  function pill(t, c, ex) { var s = el('button', t); s.type = 'button'; s.className = 'pb-c' + (c ? ' ' + c : ''); if (ex) s.dataset.ex = ex; s.setAttribute('aria-pressed', 'false'); return s; }
  var ME = 0;
  var goTo = null;   // the step the daily report opened this case at
  function fill(c) {
    var it = D[cur]; if (c.me) ME = c.me;
    document.getElementById('pb-dr-no').textContent = (c.case_no ? 'Case #' + c.case_no + ' · ' : '') + it.src_label + ' · ' + it.received;
    document.getElementById('pb-dr-h').textContent = it.title;
    var ch = document.getElementById('pb-dr-chips'); ch.textContent = '';
    ch.appendChild(pill(it.src_label, '', 'source'));
    ch.appendChild(pill(SEV[it.severity], it.severity, 'severity'));
    ch.appendChild(pill(it.sla ? 'SLA ' + it.sla : 'No clock', it.over ? 'over' : '', 'sla'));
    ch.appendChild(pill(it.state === 'done' ? 'Resolved' : 'Open', it.state === 'done' ? 'ok' : '', 'status'));
    ch.appendChild(pill(it.who ? 'With ' + it.who : 'Unassigned', '', 'assigned'));
    ch.appendChild(pill(it.esc ? 'Escalated to the ' + (it.esc === 1 ? 'Manager' : 'Director') : 'Not escalated', it.esc ? 'over' : '', 'escalation'));
    document.getElementById('pb-dr-ex').hidden = true;
    // the procedure: auto-done steps from the data, the rest ticked by hand
    var ticked = c.ticked || [], pl = document.getElementById('pb-dr-play'); pl.textContent = '';
    (it.play || []).forEach(function (st, n) {
      var done = st.auto || ticked.indexOf(n) >= 0, li = el('li'); li.className = done ? 'done' : '';
      var cb = el('input'); cb.type = 'checkbox'; cb.checked = done; cb.disabled = !!st.auto; cb.dataset.step = n; cb.setAttribute('aria-label', 'Done: ' + st.t); li.appendChild(cb);
      var tx = el('div'); var b = el('b', st.t); tx.appendChild(b); if (st.auto) tx.appendChild(el('span', 'done')).className = 'auto'; if (st.h) tx.appendChild(el('small', st.h));
      (st.exts || (st.ext ? [st.ext] : [])).forEach(function (x) { var xa = el('a', 'Open ' + x[0] + ' ↗'); xa.href = x[1]; xa.target = '_blank'; xa.rel = 'noopener'; xa.className = 'pb-ext'; tx.appendChild(xa); });   // the outside service this step needs, right here (exts: more than one, e.g. a site health finding's page, screenshot and proposal)
      li.appendChild(tx);
      var a = st.act, btn = null;
      if (a && a[0] === 'tool') { btn = el('button', 'Open'); btn.dataset.toolUrl = a[1]; }
      if (a && a[0] === 'reply' && it.reply_to) { btn = el('button', 'Write it'); btn.dataset.write = n; }
      if (a && a[0] === 'reply' && !it.reply_to && it.key.indexOf('post:') === 0) { btn = el('button', 'Write it'); btn.dataset.write = n; }
      if (a && a[0] === 'stage') { btn = el('button', a[2]); btn.dataset.stage = a[1]; }
      if (a && a[0] === 'do' && it.state !== 'done') { btn = el('button', a[2]); btn.dataset.doWhat = a[1]; }
      if (a && a[0] === 'form' && it.state !== 'done') { btn = el('button', a[2]); btn.dataset.formStep = n; }
      if (a && a[0] === 'resolve' && it.state !== 'done') { btn = el('button', 'Resolve'); btn.dataset.dr = 'done'; }
      if (btn) { btn.type = 'button'; btn.className = 'pb-btn sm'; li.appendChild(btn); } else li.appendChild(el('span'));
      pl.appendChild(li);
    });
    // opened from the daily report at a step (#case=KEY&step=N): that step lit, its button ready for one tap
    if (goTo && goTo.k === cur && pl.children[goTo.n]) {
      var gl = pl.children[goTo.n]; gl.classList.add('pb-go');
      if (!goTo.shown && (c.case_no !== undefined || c.history)) { goTo.shown = true; setTimeout(function () { gl.scrollIntoView({ block: 'center', behavior: 'smooth' }); var gb = gl.querySelector('button'); if (gb) gb.focus({ preventScroll: true }); }, 120); }
    }
    document.getElementById('pb-dr-why').textContent = it.body || it.why || '';
    var ob = document.getElementById('pb-dr-order'); ob.hidden = !it.order;
    if (it.order) {
      var ol = document.getElementById('pb-dr-steps'); ol.textContent = '';
      it.order.steps.forEach(function (st) { var li = el('li', st.label); li.className = (st.done ? 'done' : '') + (st.current ? ' current' : ''); ol.appendChild(li); });
    }
    var tb = document.getElementById('pb-dr-tool'); tb.hidden = !it.url; tb.querySelector('span').textContent = toolName(it.url || '');
    document.getElementById('pb-dr-take').hidden = !!it.mine || it.state === 'done';
    document.getElementById('pb-dr-esc').hidden = it.state === 'done' || it.esc >= 2;
    var to = document.getElementById('pb-dr-to'); to.textContent = ''; var o0 = el('option', 'Assign to…'); o0.value = ''; to.appendChild(o0);
    (c.team || []).forEach(function (p) { var o = el('option', p.name); o.value = p.id; to.appendChild(o); });
    var done = document.getElementById('pb-dr-done'); done.textContent = it.state === 'done' ? 'Reopen' : 'Resolve'; done.dataset.dr = it.state === 'done' ? 'undo' : 'done';
    var seg = document.getElementById('pb-dr-mode'); seg.textContent = '';
    var opts = (it.reply_to ? [['reply', 'Reply to ' + (it.reply_to[1] || it.reply_to[0])]] : []).concat([['team', 'Note to the team']]);
    if (!opts.some(function (x) { return x[0] === mode; })) mode = opts[0][0];
    opts.forEach(function (x) { var b = el('button', x[1]); b.type = 'button'; b.dataset.mode = x[0]; b.setAttribute('aria-pressed', x[0] === mode ? 'true' : 'false'); seg.appendChild(b); });
    document.getElementById('pb-dr-body').placeholder = mode === 'reply' ? 'Write to ' + (it.reply_to[1] || it.reply_to[0]) + '… (sent by email)' : 'A note for the team…';
    var h = document.getElementById('pb-dr-hist'); h.textContent = '';
    (c.history || []).forEach(function (n) { var li = el('li'); li.className = n.kind; li.appendChild(el('b', n.by + ' ')); li.appendChild(document.createTextNode(n.body + (n.to ? ' (emailed to ' + n.to + ')' : '')));
      if (ME && n.uid === ME && (n.kind === 'note' || n.kind === 'reply')) {
        if (n.kind === 'note') { var ee = el('button', 'Edit'); ee.type = 'button'; ee.className = 'ed'; ee.dataset.noteEdit = n.id; ee.dataset.text = n.body.replace(/ \(edited\)$/, ''); li.appendChild(ee); }
        var dd = el('button', 'Delete'); dd.type = 'button'; dd.className = 'ed'; dd.dataset.noteDel = n.id; li.appendChild(dd); }
      var at = /^\d{4}-\d\d-\d\d /.test(n.at || '') ? new Date(n.at.replace(' ', 'T')) : null;
      li.appendChild(el('small', at && !isNaN(at) ? at.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : n.at)); h.appendChild(li); });
    // vendor jobs on an order (4OVER's layout) and the margin: staff only, never the client
    var vb = document.getElementById('pb-dr-vend'); vb.textContent = ''; vb.hidden = !it.order || it.order.shop || (!c.vendor && !(it.order.work || []).length);
    if (it.order && (it.order.work || []).length) {   // the order's work orders, as they stand
      var wb = el('div'); wb.className = 'pb-vend'; wb.appendChild(el('b', 'Work orders'));
      it.order.work.forEach(function (w) { var r = el('div'); r.className = 'pb-vj'; var t = el('div'); t.appendChild(el('strong', w.no + ' · ' + w.vendor));
        t.appendChild(el('span', [w.label, w.status === 'sent' ? (w.opened ? 'opened by the vendor' : 'not opened yet') : '', w.due ? 'must have ' + w.due : '', w.tracking ? 'tracking ' + w.tracking : ''].filter(Boolean).join(' · ')));
        r.appendChild(t); wb.appendChild(r); });
      vb.appendChild(wb);
    }
    if (c.vendor && it.order && !it.order.shop && (c.vendor.jobs.length || !(it.order.work || []).length)) {
      var dl = document.getElementById('pb-vlist') || document.body.appendChild(el('datalist')); dl.id = 'pb-vlist'; dl.textContent = '';
      c.vendor.vendors.forEach(function (v) { var o = el('option'); o.value = v; dl.appendChild(o); });
      VORD = c.vendor.orders || []; VITEMS = c.vendor.items || [];
      var bx = el('div'); bx.className = 'pb-vend'; bx.appendChild(el('b', 'Vendor jobs (our team only)'));
      if (!c.vendor.jobs.length) bx.appendChild(el('div', 'None yet.'));
      var usd = function (x) { return x === null || x === undefined ? '' : '$' + (x / 100).toFixed(2); };
      c.vendor.jobs.forEach(function (j) {
        var row = el('div'); row.className = 'pb-vj';
        var t = el('div'); t.appendChild(el('strong', j.vendor + (j.vendor_order_no && j.vendor_order_no.indexOf('old-') !== 0 ? ' #' + j.vendor_order_no : '')));
        t.appendChild(el('span', 'For ' + (j.line_id ? itemName(j.line_id) || 'an item' : 'the whole order')));
        t.appendChild(el('span', [j.po_name, j.job_no ? 'Job ' + j.job_no : '', j.job_status, j.tracking ? 'Tracking ' + j.tracking : '', j.completion_on ? 'Done by ' + j.completion_on : '', usd(j.total_cents)].filter(Boolean).join(' · ')));
        row.appendChild(t); var ub = el('button', 'Update'); ub.type = 'button'; ub.className = 'ed'; ub.dataset.vjob = j.id; row.appendChild(ub); bx.appendChild(row);
      });
      var mg2 = c.vendor.margin;
      if (mg2) { var mm = el('div'); mm.className = 'pb-margin' + (mg2.margin < 0 ? ' neg' : ''); mm.textContent = 'Client price ' + usd(mg2.price) + ' · vendor cost ' + usd(mg2.cost) + ' · margin ' + usd(mg2.margin) + ' (' + mg2.pct + '%)'; bx.appendChild(mm); }
      var vrow = el('div'); vrow.style.cssText = 'display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.45rem';   // two buttons, apart
      var ab = el('button', '+ Add a vendor job'); ab.type = 'button'; ab.className = 'pb-btn sm'; ab.dataset.mgo = 'vendor'; vrow.appendChild(ab);
      var pb = el('button', 'Paste from 4OVER'); pb.type = 'button'; pb.className = 'pb-btn sm'; pb.dataset.mgo = 'paste4'; vrow.appendChild(pb); bx.appendChild(vrow); vb.appendChild(bx);
      VJOBS = {}; c.vendor.jobs.forEach(function (j) { VJOBS[j.id] = j; });
    }
    // Manage: what this case is about
    var mg = document.getElementById('pb-dr-mg'); mg.textContent = ''; document.getElementById('pb-dr-form').hidden = true;
    var mb = function (label, attr, val, cls) { var b = el('button', label); b.type = 'button'; b.className = 'pb-btn sm' + (cls ? ' ' + cls : ''); b.dataset[attr] = val; mg.appendChild(b); };
    if (it.order) {
      var od = it.order, money = '/admin/order.php?id=' + od.id;
      if (od.client) mb('Edit the order', 'toolUrl', '/admin/backoffice/orders/' + od.id); else mb('Open the order', 'toolUrl', money);
      if (od.client && (od.status === 'draft' || od.status === 'sent')) mb('Send to the client again', 'mgo', 'resend');
      if (od.client && od.status === 'pending' && !od.paid) mb('Record a payment', 'mgo', 'pay');
      if (od.client && !od.closed) mb('Change the due date', 'mgo', 'due');
      if (od.paid) mb('Refund or credit', 'toolUrl', money);
      mb('Add an order note', 'mgo', 'note');
      if (!od.paid && od.status !== 'void') mb('Void the order', 'mgo', 'void', 'no');
    } else if (it.key.indexOf('post:') === 0 && ME && it.author === ME) { mb('Edit the post', 'mgo', 'post_edit'); mb('Delete the post', 'mgo', 'post_delete', 'no'); }
    else if (it.url) mb('Open the tool', 'toolUrl', it.url);
    document.getElementById('pb-dr-mgw').hidden = !mg.children.length;
    if (!(c.history || []).length) h.appendChild(el('li', 'Nothing yet.'));
  }
  function showTool(on, url, auto) {
    var t = document.getElementById('pb-tool'), f = document.getElementById('pb-tool-f'), it = cur && D[cur];
    url = url || (it && it.url);
    if (on && url && /^https?:\/\//i.test(url)) { if (!auto) window.open(url, '_blank', 'noopener'); return; }   // another site (a source's terms): its own tab, never framed
    if (on && url && /^\/admin\/(backoffice\/orders\/|client-order\.php)/.test(url)) { if (auto) on = false; else { location.href = url; return; } }   // an order: its own whole page when asked for, never on its own as the case opens (it left the case: Jason, 2026-10-30)
    if (on && it && url) { document.getElementById('pb-tool-t').textContent = it.title; document.getElementById('pb-tool-full').href = url;
      var u = url, hsh = '', i = u.indexOf('#'); if (i >= 0) { hsh = u.slice(i); u = u.slice(0, i); } f.src = u + (u.indexOf('?') >= 0 ? '&' : '?') + 'embed=1' + hsh; t.hidden = false; document.querySelector('.pb-tool-sc').scrollTop = 0; /* the tool fills the panel and scrolls itself, so its pop-ups open where you're looking */ }
    else { t.hidden = true; f.src = 'about:blank'; }
    document.querySelector('.pb-shade').hidden = !t.hidden;
    var ob2 = document.getElementById('pb-dr-tool'); if (it) ob2.hidden = !it.url || !t.hidden;
  }
  // a step's answer from before the refresh (the steps above it are now up to date): the site's notice, in the middle
  try { var pbSaid = sessionStorage.getItem('pb_said'); if (pbSaid) { sessionStorage.removeItem('pb_said'); setTimeout(function () { TvAsk.say(pbSaid, { bad: false }); }, 400); } } catch (x) {}
  // a row opens in place, under itself (decisions/0172: the expanded toggle is for looking): the case's panel moves under
  // the row, one open at a time; Work on it carries it to the drawer for the longer work, with the tools beside it
  var CASE = document.querySelector('.pb-case'), PLACE = CASE.parentNode, inPlace = false;
  function home() { var o = document.querySelector('.ps-open'); if (CASE.parentNode !== PLACE) PLACE.appendChild(CASE); if (o) o.remove(); inPlace = false; }
  function open(k, wide) {
    var r = row(k);
    if (!wide && cur === k && inPlace) { close(); return; }
    home();
    if (D[k] && D[k].kind && r) { dr.hidden = true; document.documentElement.style.overflow = ''; openMsg(r, k); return; }   // a message or an email: its own body, in place
    cur = k; mode = D[k].reply_to ? 'reply' : 'team'; rows.forEach(function (x) { x.classList.toggle('on', x.dataset.key === k); });
    document.getElementById('pb-dr-msg').textContent = ''; document.getElementById('pb-dr-body').value = '';
    if (!wide && r) {
      var o = document.createElement('div'); o.className = 'ps-open'; r.insertAdjacentElement('afterend', o); o.appendChild(CASE); inPlace = true;
      document.querySelector('[data-work]').hidden = false;
      var oi = r.querySelector('[data-ia="open"]'); if (oi) oi.setAttribute('aria-expanded', 'true');
      fill({}); markRead(r); setTimeout(function () { r.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 50);
      api({ do: 'case', key: k }).then(function (j) { if (j.ok && cur === k) fill(j); });
      return;
    }
    document.querySelector('[data-work]').hidden = true;
    fill({}); dr.hidden = false; document.documentElement.style.overflow = 'hidden';
    showTool(window.innerWidth >= 1100 && !!D[k].url, null, true);   // a wide screen opens the tool beside the case (not an order: that's its own page)
    api({ do: 'case', key: k }).then(function (j) { if (j.ok) fill(j); });
  }
  function close() { home(); showTool(false); dr.hidden = true; cur = null; rows.forEach(function (x) { var oi = x.querySelector('[data-ia="open"]'); if (oi) oi.setAttribute('aria-expanded', 'false'); }); document.documentElement.style.overflow = ''; rows.forEach(function (r) { r.classList.remove('on'); }); }
  function act(d, extra) {
    var m = document.getElementById('pb-dr-msg'), it = D[cur], body = Object.assign({ do: d, key: cur }, extra || {});
    return api(body).then(function (j) {
      m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? '' : j.error.message; if (!j.ok) return;
      if (d === 'done' || d === 'undo') { it.state = d === 'done' ? 'done' : ''; var rr = row(cur); if (rr) { rr.dataset.state = d === 'done' ? 'done' : 'open'; rr.classList.toggle('done', d === 'done'); } }
      if (d === 'mine') { it.mine = true; it.who = 'you'; var r2 = row(cur); if (r2) r2.dataset.mine = '1'; }
      if (d === 'assign') { var s = document.getElementById('pb-dr-to'); it.who = s.options[s.selectedIndex].text; }
      if (d === 'escalate') it.esc = Math.min(2, (it.esc || 0) + 1);
      fill(j); apply();
    });
  }
  document.addEventListener('click', function (e) {
    var wk = e.target.closest('[data-work]'); if (wk && cur) { open(cur, true); showTool(window.innerWidth >= 1100 && !!D[cur].url, null, true); return; }
    if (e.target.closest('.ps-ghead')) return;   // a group's heading opens its group, not a case
    var ic = e.target.closest('.ps-i'); if (ic) { e.preventDefault(); e.stopPropagation(); icon(ic.closest('.ps-row'), ic); return; }
    var pn = e.target.closest('[data-pn]'); if (pn && cur) { stepTo(+pn.dataset.pn); return; }
    var gr = e.target.closest('.ps-group'); if (gr && !e.target.closest('.ps-open')) { e.preventDefault(); toggleGroup(gr); return; }
    var pics = e.target.closest('[data-mail-pics]'); if (pics && cur) {
      var k2 = cur; D[k2].pics = true; home(); cur = null; open(k2); return; }
    if (e.target.closest('.ps-open') && !e.target.closest('.pb-case')) return;   // inside an opened message: its own buttons
    var r = e.target.closest('.ps-row, .pq-row');
    if (r && (e.target.closest('[data-open]') || r.classList.contains('ps-row'))) { e.preventDefault(); open(r.dataset.key); return; }
    if (e.target.closest('[data-dr-close]')) { close(); return; }
    if (e.target.closest('[data-tool-open]')) { showTool(true); return; }
    var tu = e.target.closest('[data-tool-url]'); if (tu) { showTool(true, tu.dataset.toolUrl); return; }
    var dw = e.target.closest('[data-do-what]'); if (dw && cur) {   // a step's button: a spinner while it works, its answer beside it, then the case refreshed
      TvAsk.busy(dw, true);
      api({ do: 'manage', key: cur, what: dw.dataset.doWhat, args: {} }).then(function (j) {
        TvAsk.busy(dw, false);
        if (!j.ok) { TvAsk.say(j.error && j.error.message || 'That didn\u2019t work.', { bad: true }); return; }   // the site's notice, in the middle; it stays until closed
        try { sessionStorage.setItem('pb_said', j.message || 'Done.'); } catch (x) {}   // shown once the case is back with its steps up to date
        location.hash = 'case=' + encodeURIComponent(cur); location.reload();
      }).catch(function () { TvAsk.busy(dw, false); TvAsk.say('That didn\u2019t reach the site. Try again.', { bad: true }); });
      return;
    }
    var fs = e.target.closest('[data-form-step]'); if (fs && cur) { var st2 = D[cur].play[+fs.dataset.formStep], a2 = st2.act; form(st2.t, a2[3], a2[2], function (v) { manage(a2[1], v, true); }); return; }   // a step that does the work: its form, here
    var ex = e.target.closest('[data-ex]');
    if (ex && cur) {
      var box = document.getElementById('pb-dr-ex'), on = ex.getAttribute('aria-pressed') !== 'true', E = D[cur].explain || {};
      document.querySelectorAll('#pb-dr-chips [data-ex]').forEach(function (x) { x.setAttribute('aria-pressed', 'false'); });
      box.textContent = ''; box.hidden = !on;
      if (on) { ex.setAttribute('aria-pressed', 'true'); box.appendChild(document.createTextNode(E[ex.dataset.ex] || ''));
        if (ex.dataset.ex === 'source' && E.source_url) { box.appendChild(document.createTextNode(' ')); var a = el('a', 'See the whole queue →'); a.href = E.source_url; box.appendChild(a); }
        if (ex.dataset.ex === 'escalation' && D[cur].state !== 'done') { box.appendChild(document.createTextNode(' ')); var eb = el('button', 'Escalate now'); eb.type = 'button'; eb.className = 'pb-btn sm'; eb.dataset.dr = 'escalate'; box.appendChild(eb); } }
      return;
    }
    var wr = e.target.closest('[data-write]');
    if (wr && cur) { var st = D[cur].play[+wr.dataset.write]; mode = D[cur].reply_to && D[cur].key.indexOf('post:') !== 0 ? 'reply' : 'team';
      var ta = document.getElementById('pb-dr-body'); ta.value = (st.act && st.act[1]) || ''; refreshMode(); ta.focus(); ta.scrollIntoView({ block: 'center' }); return; }
    if (e.target.closest('[data-tool-close]')) { showTool(false); return; }
    var sg = e.target.closest('[data-stage]');
    if (sg && cur) {
      var go = function (tracking) {
        api({ do: 'stage', key: cur, stage: sg.dataset.stage, tracking: tracking || '' }).then(function (j) {
          var m = document.getElementById('pb-dr-msg'); m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? '' : j.error.message;
          if (j.ok) { location.hash = 'case=' + encodeURIComponent(cur); location.reload(); }
        });
      };
      if (sg.dataset.stage === 'ordered') { form('Sent to the printer', jobFields(), 'Send to the printer', function (v) {
        api({ do: 'stage', key: cur, stage: 'ordered', tracking: '', job: v }).then(function (j) { done(j, true); }); }); return; }
      // shipping asks for the tracking number right here, in the case (no pop-up over the drawer)
      if (sg.dataset.stage === 'shipped' && !sg.dataset.ready) {
        // the box goes under the step's words (its own row, full width), so the button keeps its place
        var li = sg.closest('li'), txt = (li && li.children[1]) || sg.parentNode, inp = el('input'); inp.className = 'pb-track'; inp.placeholder = 'Tracking number (optional)'; inp.value = D[cur].order.tracking || '';
        inp.setAttribute('aria-label', 'Tracking number'); txt.appendChild(inp); sg.dataset.ready = '1'; sg.textContent = 'Mark shipped'; inp.focus(); return;
      }
      if (sg.dataset.stage === 'complete' && window.TvAsk && !TvAsk.gate(sg, 'Mark this order complete? The client is emailed.', { yes: 'Mark complete' })) return;
      go(sg.dataset.ready ? (document.querySelector('.pb-track') || {}).value : '');
      return;
    }
    var sb = e.target.closest('#pb-dr-mode button'); if (sb) { mode = sb.dataset.mode; fill({ case_no: 0, team: [], history: [] }); api({ do: 'case', key: cur }).then(function (j) { if (j.ok) fill(j); }); return; }
    var b = e.target.closest('[data-dr]'); if (b && cur) act(b.dataset.dr);
  });
  // a small form inside the case (no pop-ups over the drawer): fields [name, label, type, value, list]
  function form(title, fields, yes, send, danger) {
    var f = document.getElementById('pb-dr-form'); f.textContent = ''; f.hidden = false;
    f.appendChild(el('b', title));
    var host = f;
    fields.forEach(function (x) {
      if (x[0] === '-') { var d = el('details'); d.appendChild(el('summary', x[1])); f.appendChild(d); host = d; return; }
      var l = el('label', x[1]), i;
      if (x[2] === 'select') { i = el('select'); (Array.isArray(x[4]) ? x[4] : Object.keys(x[4]).map(function (k) { return [k, x[4][k]]; })).forEach(function (kv) { var o = el('option', kv[1]); o.value = kv[0]; i.appendChild(o); }); }
      else if (x[2] === 'textarea') { i = el('textarea'); i.rows = 3; }
      else { i = el('input'); i.type = x[2] || 'text'; if (x[4]) i.setAttribute('list', x[4]); }
      i.name = x[0]; if (x[3] != null) i.value = x[3]; l.appendChild(i); host.appendChild(l);
    });
    var r = el('div'); r.className = 'row'; var no = el('button', 'Close'); no.type = 'button'; no.className = 'pb-btn sm';
    var ok = el('button', yes); ok.type = 'button'; ok.className = 'pb-btn ' + (danger ? 'sm no' : 'go'); r.appendChild(no); r.appendChild(ok); f.appendChild(r);
    no.onclick = function () { f.hidden = true; };
    ok.onclick = function () { var v = {}; f.querySelectorAll('[name]').forEach(function (i) { v[i.name] = i.value; }); send(v); };
    var vs = f.querySelector('[name=vendor_order_id]');
    if (vs) { var sync = function () { ['vendor', 'vendor_order_no'].forEach(function (n) { var x = f.querySelector('[name=' + n + ']'); if (x) x.closest('label').hidden = vs.value !== ''; }); }; vs.addEventListener('change', sync); sync(); }
    var first = f.querySelector('input,textarea,select'); if (first) first.focus(); f.scrollIntoView({ block: 'nearest' });
  }
  function done(j, reload) {
    var m = document.getElementById('pb-dr-msg'); m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? (j.message || '') : j.error.message;
    if (!j.ok) return;
    if (reload) { try { sessionStorage.setItem('pb_said', j.message || 'Done.'); } catch (x) {} location.hash = 'case=' + encodeURIComponent(cur); location.reload(); return; }   // its answer as the site's notice once the case is back (site audit P11)
    document.getElementById('pb-dr-form').hidden = true; if (j.history) fill(j);
  }
  function manage(what, args, reload) { return api({ do: 'manage', key: cur, what: what, args: args || {} }).then(function (j) { done(j, reload); }); }
  var VORD = [], VJOBS = {}, VITEMS = [];
  // which item a job is for: the whole order (it moves every item without its own job), or one item (decisions/0107)
  function forField(v) { return ['line_id', 'For', 'select', v ? String(v) : '', [['', 'The whole order (every item without its own job)']].concat(VITEMS.map(function (i) { return [String(i.id), i.title]; }))]; }
  function itemName(id) { var i = VITEMS.filter(function (x) { return x.id === +id; })[0]; return i ? i.title : ''; }
  function jobFields() {
    var it = D[cur], po = it && it.order ? (it.title.split(' · ')[1] || '') : '';
    var pick = VORD.map(function (o) { return [String(o.id), 'Add to ' + o.label]; }).concat([['', 'A new vendor order']]);   // the latest order first: one 4OVER order holds several jobs
    return [['vendor_order_id', 'Vendor order', 'select', VORD.length ? String(VORD[0].id) : '', pick], forField(VITEMS.length === 1 ? VITEMS[0].id : ''), ['vendor', 'Vendor', 'text', '4OVER', 'pb-vlist'], ['vendor_order_no', 'Their order #', 'text', ''],
      ['po_name', 'Project / P.O. name', 'text', po], ['set_name', 'Set name', 'text', ''], ['job_no', 'Job ID', 'text', ''], ['job_status', 'Job status (theirs)', 'text', ''],
      ['subtotal', 'Our cost: subtotal ($)', 'text', ''], ['shipping', 'Shipping & processing ($)', 'text', ''], ['tax', 'Tax ($)', 'text', ''],
      ['-', 'More details: specs, shipment, artwork'], ['sku', 'SKU', 'text', ''], ['specs', 'Specs (size, stock, coating, colors)', 'textarea', ''], ['run_size', 'Run size', 'text', ''], ['turnaround', 'Turnaround', 'text', ''],
      ['facility', 'Production facility', 'text', ''], ['completion_on', 'Completion date', 'date', ''], ['ship_to', 'Ships to', 'text', ''], ['ship_method', 'Shipping method', 'text', ''], ['artwork_url', 'Artwork link', 'text', ''], ['note', 'Note (our team only)', 'textarea', '']];
  }
  document.addEventListener('click', function (e) {
    if (!e.target.closest('#pb-dr, .pb-case')) return;   // the case's own panel, in place or in the drawer
    var g = e.target.closest('[data-mgo]'); if (g && cur) {
      var it = D[cur], od = it.order || {}, w = g.dataset.mgo;
      if (w === 'resend') { if (!TvAsk.gate(g, 'Email the order to the client again?', { yes: 'Send it' })) return; manage('resend', {}, true); }
      if (w === 'pay') form('Record a payment', [['amount', 'Amount received ($)', 'text', ''], ['method', 'How', 'select', null, { cash: 'Cash', check: 'Check', zelle: 'Zelle', venmo: 'Venmo', bank: 'Bank transfer', card: 'Card (another terminal)', other: 'Other' }], ['ref', 'Reference (check #, etc.)', 'text', '']], 'Record it', function (v) { manage('pay', v, true); });
      if (w === 'due') form('Change the due date', [['date', 'New due date', 'date', od.due || '']], 'Save', function (v) { manage('due', v, true); });
      if (w === 'note') form('Add an order note', [['text', 'Note (on the order\'s history; our team only)', 'textarea', '']], 'Add it', function (v) { manage('note', v); });
      if (w === 'void') form('Void the order', [['why', 'Why (the client is told if it was sent)', 'text', '']], 'Void it', function (v) { manage('void', v, true); }, true);
      if (w === 'post_edit') form('Edit the post', [['text', 'Post', 'textarea', it.body || '']], 'Save', function (v) { manage('post_edit', v, true); });
      if (w === 'post_delete') { if (!TvAsk.gate(g, 'Delete this post?', { yes: 'Delete', danger: true })) return; api({ do: 'manage', key: cur, what: 'post_delete' }).then(function (j) { if (j.ok) { location.hash = ''; location.reload(); } else done(j); }); }
      if (w === 'paste4') form('Paste from 4OVER', [['text', 'On the 4OVER order page press Ctrl+A, then Ctrl+C, and paste here (Ctrl+V)', 'textarea', '']], 'Read it', function (v) {
        api({ do: 'parse4', text: v.text }).then(function (j) {
          if (!j.ok) { done(j); return; }
          var P = j.parsed, oid = D[cur].order ? D[cur].order.id : 0, f = document.getElementById('pb-dr-form'); f.textContent = '';
          f.appendChild(el('b', '4OVER #' + P.vendor_order_no + ' · ' + (P.purchased || '') + ' · ' + (P.payment || '') + (P.total != null ? ' · $' + P.total.toFixed(2) : '')));
          P.projects.forEach(function (pr, n) {
            var m = j.matches[n], l = el('label', pr.po_name + ' → ' + pr.sets.map(function (x) { return [x.job_no, x.job_status, x.tracking].filter(Boolean).join(' · '); }).join('; ') + (pr.total != null ? ' · $' + pr.total.toFixed(2) : '') + ' · ships to ' + pr.ship_name);
            var sel = el('select'); sel.name = 'p' + n;
            var o0 = el('option', m.known ? 'Already saved: update it' : 'Not this order (skip)'); o0.value = m.known ? m.order_id : 0; sel.appendChild(o0);
            if (!m.known) j.orders.forEach(function (o) { var op = el('option', 'For ' + o.label); op.value = o.id; if (o.id === (m.order_id || 0)) op.selected = true; sel.appendChild(op); });
            l.appendChild(sel); f.appendChild(l);
          });
          var r = el('div'); r.className = 'row'; var no = el('button', 'Close'); no.type = 'button'; no.className = 'pb-btn sm'; no.onclick = function () { f.hidden = true; };
          var ok = el('button', 'Save from 4OVER'); ok.type = 'button'; ok.className = 'pb-btn go'; r.appendChild(no); r.appendChild(ok); f.appendChild(r);
          ok.onclick = function () { var of = {}; P.projects.forEach(function (_, n) { of[n] = +f.querySelector('[name=p' + n + ']').value; });
            api({ do: 'import4', key: cur, text: v.text, order_for: of }).then(function (k) { done(k, true); }); };
        });
      });
      if (w === 'vendor') form('Add a vendor job', jobFields(), 'Save', function (v) { api({ do: 'vendor', key: cur, job: v }).then(function (j) { done(j); }); });
      return;
    }
    var vj = e.target.closest('[data-vjob]');
    if (vj && VJOBS[vj.dataset.vjob]) { var J = VJOBS[vj.dataset.vjob], c2 = function (x) { return x === null || x === undefined ? '' : (x / 100).toFixed(2); };
      form('Update ' + (J.job_no ? 'job ' + J.job_no : 'the job'), [forField(J.line_id), ['job_status', 'Job status (theirs)', 'text', J.job_status], ['tracking', 'Tracking', 'text', J.tracking], ['completion_on', 'Completion date', 'date', J.completion_on || ''],
        ['job_no', 'Job ID', 'text', J.job_no], ['subtotal', 'Subtotal ($)', 'text', c2(J.subtotal_cents)], ['shipping', 'Shipping & processing ($)', 'text', c2(J.shipping_cents)], ['tax', 'Tax ($)', 'text', c2(J.tax_cents)]],
        'Save', function (v) { api({ do: 'vjob', key: cur, id: +vj.dataset.vjob, job: v }).then(function (j) { done(j, true); }); }); return; }
    var ne = e.target.closest('[data-note-edit]'); if (ne) { form('Edit your note', [['text', 'Note', 'textarea', ne.dataset.text]], 'Save', function (v) { manage('note_edit', { id: +ne.dataset.noteEdit, text: v.text }); }); return; }
    var nd = e.target.closest('[data-note-del]'); if (nd) { if (!TvAsk.gate(nd, 'Delete your note?', { yes: 'Delete', danger: true })) return; manage('note_delete', { id: +nd.dataset.noteDel }); }
  });
  function refreshMode() { document.querySelectorAll('#pb-dr-mode button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.mode === mode ? 'true' : 'false'); }); }
  document.getElementById('pb-dr-play').addEventListener('change', function (e) {
    var cb = e.target.closest('[data-step]'); if (!cb || !cur) return;
    var n = +cb.dataset.step; api({ do: 'step', key: cur, n: n, on: cb.checked, label: D[cur].play[n].t }).then(function (j) { if (j.ok) fill(j); });
  });
  document.getElementById('pb-dr-to').addEventListener('change', function () { if (this.value) act('assign', { to: +this.value }); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && inPlace) { close(); return; }
    if (e.key === 'Escape' && !dr.hidden) { if (!document.getElementById('pb-tool').hidden && window.innerWidth < 768) showTool(false); else close(); }
    if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('ps-row')) { e.preventDefault(); if (e.target.dataset.group) toggleGroup(e.target); else open(e.target.dataset.key); }
  });
  document.querySelector('[data-dr-post]').addEventListener('click', function () {
    var t = document.getElementById('pb-dr-body'), m = document.getElementById('pb-dr-msg');
    api({ do: 'post', key: cur, mode: mode, body: t.value }).then(function (j) {
      m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? j.message : j.error.message; if (j.ok) { t.value = ''; fill(j); }
    });
  });
  // the SLA clocks tick
  setInterval(function () {
    document.querySelectorAll('[data-due]').forEach(function (s) { var d = s.dataset.due; if (!d) return; var left = (new Date(d.replace(' ', 'T')) - new Date()) / 1000;
      var a = Math.abs(left), h = Math.floor(a / 3600), mi = Math.floor(a % 3600 / 60), f = h >= 48 ? Math.round(h / 24) + ' d' : (h ? h + ' h' + (mi ? ' ' + mi + ' min' : '') : Math.max(1, mi) + ' min');
      s.textContent = s.textContent.replace(/SLA .*?(?= ·|$)/, 'SLA ' + (left >= 0 ? f + ' left' : 'Over by ' + f)); s.classList.toggle('over', left < 0); });
  }, 60000);
  document.querySelectorAll('.pb-panel[data-keep]').forEach(function (d) {
    var k = 'tv-pulse-' + d.dataset.keep; try { var st = localStorage.getItem(k); if (st === 'closed') d.open = false; if (st === 'open') d.open = true; } catch (x) {}
    d.addEventListener('toggle', function () { try { localStorage.setItem(k, d.open ? 'open' : 'closed'); } catch (x) {} });
  });
  apply();
  // reopen a case after moving its order on; or open one from the daily report, at its step
  var hc = /case=([^&]+)/.exec(location.hash), hs = /[#&]step=(\d+)/.exec(location.hash);
  if (hc && D[decodeURIComponent(hc[1])]) { if (hs) goTo = { k: decodeURIComponent(hc[1]), n: +hs[1], shown: false }; open(decodeURIComponent(hc[1])); }
  else if (hc && hs && window.TvAsk) TvAsk.say('That case is already resolved, or nothing on it needs you now.', { bad: false });
  if (root.dataset.focus === 'stream') setTimeout(function () { document.getElementById('pu-stream').scrollIntoView(); }, 50);
})();
</script>
<?php
    return (string) ob_get_clean();
}

/** Stream settings (decisions/0105): which department each kind of item goes to, and each severity's clock. */
function tv_pulse_settings(PDO $pdo, ?array $staff): string
{
    $e = 'tv_e';
    $ready = Pulse::settingsReady($pdo); $can = $ready && Pulse::canSet($staff);
    $dis = $can ? '' : ' disabled';
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    ob_start(); ?>
<style>
  .pst{max-width:44rem;margin-top:.6rem}.pst h2{margin:0}.pst table{width:100%;border-collapse:collapse;margin:.4rem 0 .2rem}
  .pst td{padding:.4rem .3rem;border-top:1px solid #EADFC4;vertical-align:middle}.pst td:first-child{display:flex;align-items:center;gap:.45rem;font-weight:600;color:#3E2B1F}
  .pst .pu-svg{width:18px;height:18px;fill:none;stroke:#B45309;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}
  .pst select,.pst input{font:inherit;border:1px solid #CBB98D;border-radius:.45rem;background:#FFFBF2;color:#3E2B1F;padding:.3rem .45rem;max-width:100%}
  .pst input{width:5.5rem}.pst small{color:#8A7355}.pst .row{display:flex;gap:.6rem;align-items:center;flex-wrap:wrap;margin-top:.6rem}
  .pst-msg{font-weight:600;color:#1F3B30}.pst-msg.no{color:#991B1B}
  .pst.hb-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .85rem}
  .pst .hb-h{font:700 1.1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F;margin:1.1rem 0 0}.pst .hb-intro{font-size:.95rem;color:#5C4632;margin:.3rem 0 .2rem}
  .pst .hb-b{display:inline-flex;align-items:center;justify-content:center;font:700 .9rem/1.2 inherit;border-radius:.6rem;padding:.42rem .8rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;cursor:pointer;white-space:nowrap}
  .pst .hb-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}.pst .hb-b:disabled{opacity:.55;cursor:default}
  .pst table.pst-rep{table-layout:fixed}.pst table.pst-rep td:first-child{width:7.2rem}.pst table.pst-rep select{width:100%;min-width:0}
</style>
<div class="hb-card tv-bleed pst" id="pst">
  <h2 class="hb-h">Routing</h2>
  <p class="hb-intro">Which department's queue each kind of item goes to. Everyone: it shows in the whole team's stream. A department's Manager and Director are the ones an item escalates to.</p>
  <?php if (!$ready): ?><p class="hb-intro"><b>Run <code>app/migrations/2026-12-19_pulse_settings.sql</code></b> to change these. Until then the defaults below apply.</p><?php elseif (!$can): ?><p class="hb-intro">A Director, an Executive or the Founder changes these.</p><?php endif; ?>
  <table><?php foreach (Pulse::SOURCES as $src => [$label, $icon]): $d = Pulse::deptFor($pdo, $src); ?>
    <tr><td><?= tv_icon($icon, 'pu-svg') ?><?= $e($label) ?></td><td><select data-route="<?= $e($src) ?>" aria-label="<?= $e($label) ?> goes to"<?= $dis ?>><option value=""<?= $d === '' ? ' selected' : '' ?>>Everyone</option><?php foreach (Workspaces::DEPARTMENTS as $k => [$dl]): ?><option value="<?= $k ?>"<?= $d === $k ? ' selected' : '' ?>><?= $e($dl) ?></option><?php endforeach; ?></select>
      <?php if ($d !== (string) Pulse::SOURCES[$src][3]): ?><small>default: <?= $e(Pulse::SOURCES[$src][3] === '' ? 'Everyone' : Workspaces::DEPARTMENTS[Pulse::SOURCES[$src][3]][0]) ?></small><?php endif; ?></td></tr>
  <?php endforeach; ?></table>
  <h2 class="hb-h" style="margin-top:1rem">Clocks (SLA)</h2>
  <p class="hb-intro">How long an open item may wait before it shows as over, in hours. 0 = no clock. An item still open after its clock can be escalated to the department's Manager, then its Director.</p>
  <table><?php foreach (Pulse::SLA_HOURS as $sev => $def): if (in_array($sev, ['urgent', 'special'], true)) continue; /* no clock on the new levels (decisions/0172) */ $hrs = Pulse::slaHours($pdo, $sev); ?>
    <tr><td><?= $e(Pulse::SEVERITY[$sev]) ?></td><td><input type="number" min="0" max="720" step="1" inputmode="numeric" data-sla="<?= $sev ?>" value="<?= $hrs ?>" aria-label="<?= $e(Pulse::SEVERITY[$sev]) ?> clock, hours"<?= $dis ?>> hours <small>(<?= $e(Pulse::clockLabel($hrs)) ?><?= $hrs !== $def ? '; default ' . $e(Pulse::clockLabel($def)) : '' ?>)</small></td></tr>
  <?php endforeach; ?></table>
  <?php require_once __DIR__ . '/../lib/DailyReport.php'; $rto = DailyReport::recipient($pdo); $rhr = DailyReport::hour($pdo); $rday = DailyReport::today($pdo); ?>
  <h2 class="hb-h" style="margin-top:1rem">Daily report</h2>
  <p class="hb-intro">One email a day with every open case, a button to each one's step, and the system status. It goes to one Owner. A day with nothing open still sends one line, so no email means it stopped (and Pulse raises a case).</p>
  <table class="pst-rep">
    <tr><td><?= tv_icon('inbox', 'pu-svg') ?>Goes to</td><td><select data-report="to" aria-label="The daily report goes to"<?= $dis ?>><?php foreach (DailyReport::owners($pdo) as $oid => [$oem, $onm]): ?><option value="<?= (int) $oid ?>"<?= $rto && $rto[0] === $oid ? ' selected' : '' ?>><?= $e(($onm !== '' ? $onm . ' · ' : '') . $oem) ?></option><?php endforeach; ?></select></td></tr>
    <tr><td><?= tv_icon('calendar', 'pu-svg') ?>Sent at</td><td><select data-report="hour" aria-label="The hour it goes, Arizona time"<?= $dis ?>><?php for ($h = 3; $h <= 11; $h++): ?><option value="<?= $h ?>"<?= $h === $rhr ? ' selected' : '' ?>><?= $e(DailyReport::hourLabel($h)) ?></option><?php endfor; ?></select> <small>Arizona time<?= $rhr !== DailyReport::HOUR ? '; default ' . DailyReport::hourLabel(DailyReport::HOUR) : '' ?></small></td></tr>
    <tr><td>Today's</td><td style="overflow-wrap:anywhere"><small><?= $rday ? ((int) $rday['ok'] ? 'Sent at ' . $e(date('g:i a', strtotime((string) $rday['sent_at']))) . ' Arizona time to ' . $e($rday['to_email']) : 'Didn\'t send: ' . $e($rday['error'])) : 'Not sent yet today' ?></small></td></tr>
  </table>
  <div class="row"><button type="button" class="hb-b" id="pst-rprev">Preview today's report</button><?php if ($can): ?><button type="button" class="hb-b" id="pst-rsend">Send me a copy now</button><?php endif; ?><span class="pst-msg" id="pst-rmsg" role="status"></span></div>
  <iframe id="pst-rframe" title="Today's report" hidden style="width:100%;height:34rem;border:1px solid #E8DCC2;border-radius:.5rem;margin-top:.5rem;background:#F6EFDF"></iframe>
  <?php if ($can): ?><div class="row"><button type="button" class="hb-b go" id="pst-save">Save</button><button type="button" class="hb-b" id="pst-def">Use the defaults</button><span class="pst-msg" id="pst-msg" role="status"></span></div><?php endif; ?>
</div>
<?php if ($can): ?>
<script>
(function () {
  var box = document.getElementById('pst'), msg = document.getElementById('pst-msg');
  var DEF = <?= json_encode(['route' => array_map(fn ($x) => (string) $x[3], Pulse::SOURCES), 'sla' => Pulse::SLA_HOURS]) ?>;
  function send(body) {
    msg.className = 'pst-msg'; msg.textContent = 'Saving…';
    fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode($csrf) ?> }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); }).then(function (j) {
        if (!j.ok) { msg.className = 'pst-msg no'; msg.textContent = j.error.message; return; }
        msg.textContent = j.message; if (j.message !== 'Nothing changed.') setTimeout(function () { location.reload(); }, 900);
      }).catch(function () { msg.className = 'pst-msg no'; msg.textContent = 'That didn\'t save. Try again.'; });
  }
  function collect() { var v = { do: 'settings', route: {}, sla: {} };
    box.querySelectorAll('[data-route]').forEach(function (s) { v.route[s.dataset.route] = s.value; });
    box.querySelectorAll('[data-sla]').forEach(function (i) { v.sla[i.dataset.sla] = i.value; });
    var rt = box.querySelector('[data-report=to]'), rh = box.querySelector('[data-report=hour]'); if (rt && rt.value) v.report_to = rt.value; if (rh) v.report_hour = rh.value; return v; }
  var rs = document.getElementById('pst-rsend');
  if (rs) rs.addEventListener('click', function () {
    var b = this; if (!TvAsk.gate(b, 'Email a copy of today\'s report now? The 5 am one still goes.', { yes: 'Send it' })) return;
    b.disabled = true;
    fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode($csrf) ?> }, body: JSON.stringify({ do: 'report_copy' }) })
      .then(function (r) { return r.json(); }).then(function (j) { b.disabled = false; TvAsk.say(j.ok ? j.message : j.error.message, { anchor: b, bad: !j.ok }); })
      .catch(function () { b.disabled = false; TvAsk.say('That didn\'t reach the site. Try again.', { anchor: b, bad: true }); });
  });
  document.getElementById('pst-save').addEventListener('click', function () { send(collect()); });
  document.getElementById('pst-def').addEventListener('click', function () {
    if (!TvAsk.gate(this, 'Put routing and clocks back to the defaults?', { yes: 'Use the defaults' })) return;
    send({ do: 'settings', route: DEF.route, sla: DEF.sla }); });
})();
</script>
<?php endif; ?>
<script>
(function () {
  var pb = document.getElementById('pst-rprev'), fr = document.getElementById('pst-rframe'); if (!pb) return;
  pb.addEventListener('click', function () {
    if (!fr.hidden) { fr.hidden = true; pb.textContent = 'Preview today\'s report'; return; }
    pb.disabled = true;
    fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode($csrf) ?> }, body: JSON.stringify({ do: 'report_preview' }) })
      .then(function (r) { return r.json(); }).then(function (j) {
        pb.disabled = false;
        if (!j.ok) { TvAsk.say(j.error.message, { anchor: pb, bad: true }); return; }
        fr.srcdoc = j.html; fr.hidden = false; pb.textContent = 'Close the preview';
      }).catch(function () { pb.disabled = false; TvAsk.say('That didn\'t reach the site. Try again.', { anchor: pb, bad: true }); });
  });
})();
</script>
<?php
    return (string) ob_get_clean();
}
