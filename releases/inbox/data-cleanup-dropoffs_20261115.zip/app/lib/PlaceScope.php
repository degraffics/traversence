<?php
// api/lib/PlaceScope.php
//
// One place to turn "hub / geo-hub / cluster" (the Geographic Hierarchy) into a
// filter on `entities`. Used by search_listings.php, suggest.php, place.php and
// places.php so every part of the site means the same thing by "in this region".
//
//   PlaceScope::resolve($pdo, $_GET)  -> null when no scope was requested,
//   otherwise ['level','slug','found','id','name','hub_number','sql'].
//
// 'sql' is a boolean SQL fragment over the alias `e` (entities). It contains
// only integers that were read back from the database, never request text, so
// it can be concatenated into any query (named OR positional placeholders).
// An unknown/invalid slug yields '1 = 0' (matches nothing rather than
// silently ignoring the request).
//
// Requires migrations/2026-09-19_geo_hierarchy*.sql (hub_counties, hubs.status).
// Matching rules (first hit counts):
//   cluster  : entity.micro_cluster_id, or entity ZIP = the cluster's primary ZIP
//   geo-hub  : entities in its clusters, or in counties assigned to it
//   hub      : entities in any cluster of the hub, or whose ZIP falls in a county
//              assigned to the hub (hub_counties via zip_coordinates)

final class PlaceScope
{
    // Explicit on both sides of every comparison: the tables were created with
    // different default collations, and MySQL rejects mixing them implicitly.
    private const C = 'COLLATE utf8mb4_general_ci';

    /** Entity statuses the public directory may show (kept in step with api/search_listings.php). */
    public const PUBLIC_STATUSES = ['unclaimed', 'claimed-unverified', 'pending-verification', 'verified'];

    /**
     * Kinds of place we list that aren't businesses (Jason, 2026-11-15: drop boxes are "their own listing and map pin"):
     * slug => what to say. They're found by search and on maps, with their pins, but kept out of business browse lists
     * (the directory's browsing, a town's sections) and can't be claimed: there's no owner to claim a USPS box.
     */
    public const NOT_A_BUSINESS = ['mail-package-drop-off' => 'A mail and package drop-off, not a business: there\'s nothing to claim.'];

    /** SQL: the listing (alias $a) isn't one of NOT_A_BUSINESS's kinds (for business browse lists). */
    public static function businessOnly(string $a = 'e'): string
    {
        $slugs = implode(', ', array_map(fn ($s) => "'" . $s . "'", array_keys(self::NOT_A_BUSINESS)));
        return "($a.category_id IS NULL OR $a.category_id NOT IN (SELECT nb.id FROM categories nb WHERE nb.slug IN ($slugs)))";
    }

    /** Why a listing can't be claimed, from its kind ('' when it can). */
    public static function notABusiness(PDO $pdo, int $id): string
    {
        try {
            $st = $pdo->prepare('SELECT c.slug FROM entities e JOIN categories c ON c.id = e.category_id WHERE e.id = ?');
            $st->execute([$id]);
            return self::NOT_A_BUSINESS[(string) $st->fetchColumn()] ?? '';
        } catch (Throwable $x) { return ''; }
    }

    /** Cluster name without the admin-only "(auto-seeded, needs review)" note. */
    public static function publicName(?string $name): string
    {
        return trim((string)preg_replace('/\s*\(auto-seeded[^)]*\)/i', '', (string)$name));
    }

    /** @return array{0:string,1:string}|null [level, slug] — most specific wins */
    public static function requested(array $src): ?array
    {
        foreach (['cluster' => 'cluster', 'geo' => 'geo_hub', 'hub' => 'hub'] as $key => $level) {
            $v = trim((string)($src[$key] ?? ''));
            if ($v !== '') {
                return [$level, $v];
            }
        }
        return null;
    }

    public static function resolve(PDO $pdo, array $src): ?array
    {
        $req = self::requested($src);
        if ($req === null) {
            return null;
        }
        [$level, $slug] = $req;

        $out = [
            'level' => $level, 'slug' => $slug, 'found' => false, 'id' => 0,
            'name' => null, 'hub_number' => null, 'sql' => '1 = 0',
        ];

        $slugOk = (bool)preg_match('/^[a-z0-9][a-z0-9-]{0,99}$/', $slug);
        $numericCluster = ($level === 'cluster' && ctype_digit($slug) && strlen($slug) <= 10);
        if (!$slugOk && !$numericCluster) {
            return $out;
        }

        $c = self::C;

        if ($level === 'hub') {
            $st = $pdo->prepare('SELECT id, name, hub_number FROM hubs WHERE slug = ? LIMIT 1');
            $st->execute([$slug]);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return $out;
            }
            $id = (int)$row['id'];
            $n  = (int)$row['hub_number'];
            $out = array_merge($out, ['found' => true, 'id' => $id, 'name' => $row['name'], 'hub_number' => $n]);
            $out['sql'] = "(e.micro_cluster_id IN (SELECT mc.id FROM micro_clusters mc JOIN geo_hubs g ON g.id = mc.geo_hub_id WHERE g.hub_id = $id)
                OR e.primary_zip $c IN (SELECT z.zip $c FROM zip_coordinates z
                    JOIN hub_counties hc ON hc.state $c = z.state $c AND hc.county $c = z.county $c
                    WHERE hc.hub_number = $n))";
            return $out;
        }

        if ($level === 'geo_hub') {
            $st = $pdo->prepare('SELECT g.id, g.name, h.hub_number FROM geo_hubs g JOIN hubs h ON h.id = g.hub_id WHERE g.slug = ? LIMIT 1');
            $st->execute([$slug]);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return $out;
            }
            $id = (int)$row['id'];
            $out = array_merge($out, ['found' => true, 'id' => $id, 'name' => $row['name'], 'hub_number' => (int)$row['hub_number']]);
            $out['sql'] = "(e.micro_cluster_id IN (SELECT mc.id FROM micro_clusters mc WHERE mc.geo_hub_id = $id)
                OR e.primary_zip $c IN (SELECT mc.primary_zip $c FROM micro_clusters mc WHERE mc.geo_hub_id = $id)
                OR e.primary_zip $c IN (SELECT z.zip $c FROM zip_coordinates z
                    JOIN hub_counties hc ON hc.state $c = z.state $c AND hc.county $c = z.county $c
                    WHERE hc.geo_hub_id = $id))";
            return $out;
        }

        // cluster: numeric id or slug
        if ($numericCluster) {
            $st = $pdo->prepare('SELECT mc.id, mc.name, h.hub_number FROM micro_clusters mc JOIN geo_hubs g ON g.id = mc.geo_hub_id JOIN hubs h ON h.id = g.hub_id WHERE mc.id = ? LIMIT 1');
        } else {
            $st = $pdo->prepare('SELECT mc.id, mc.name, h.hub_number FROM micro_clusters mc JOIN geo_hubs g ON g.id = mc.geo_hub_id JOIN hubs h ON h.id = g.hub_id WHERE mc.slug = ? ORDER BY mc.id LIMIT 1');
        }
        $st->execute([$numericCluster ? (int)$slug : $slug]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return $out;
        }
        $id = (int)$row['id'];
        // Auto-seeded clusters are named after a ZIP ("ZIP 85901 (auto-seeded...)"). The
        // public sees the town instead ("Show Low, AZ"); a real name is left alone.
        $label = self::publicName($row['name']);
        if (preg_match('/^ZIP \\d{5}\\b/', $label)) {
            try {
                $zt = $pdo->prepare("SELECT z.city, z.state FROM micro_clusters mc JOIN zip_coordinates z
                        ON TRIM(z.zip) $c = TRIM(mc.primary_zip) $c WHERE mc.id = ? LIMIT 1");
                $zt->execute([$id]);
                if ($zr = $zt->fetch(PDO::FETCH_ASSOC)) {
                    $label = trim($zr['city']) . ', ' . trim($zr['state']);
                }
            } catch (\Throwable $e) { /* keep the ZIP label */ }
        }
        $out = array_merge($out, ['found' => true, 'id' => $id, 'name' => $label, 'hub_number' => (int)$row['hub_number']]);
        $out['sql'] = "(e.micro_cluster_id = $id
            OR e.primary_zip $c IN (SELECT mc.primary_zip $c FROM micro_clusters mc WHERE mc.id = $id))";
        return $out;
    }
}
