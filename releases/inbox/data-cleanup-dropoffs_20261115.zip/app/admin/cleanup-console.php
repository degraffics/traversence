<?php
// app/admin/cleanup-console.php — Insights → Data cleanup (decisions/0163 §8 stage 1b, 0164 §6.1b; Jason, 2026-11-14).
// Finds what the old crawler made that fails today's rules (app/lib/DataCleanup.php), previews it by reason, and acts on
// it by rule, reversibly: every change is in the ledger with Undo per record and per pass; nothing is deleted; what a
// person entered or decided is never changed ("Check these", one Pulse case). A card per rule, so it reads on a phone.
// Never a dead end (Jason, 2026-11-15): what a pass takes off goes back to work (sightings, "Help us find") or is listed
// under Restricted with its reason, Put back and Make it a request.
declare(strict_types=1);

function tv_admin_mod_cleanup(PDO $pdo): string
{
    require_once __DIR__ . '/../lib/DataCleanup.php';
    $e = 'tv_w_e';
    [$can, $why] = Access::can('insights.cleanup', DataCleanup::RULE_RUN);
    [$canUndo, $whyUndo] = Access::can('insights.cleanup_undo', DataCleanup::RULE_UNDO);
    $me = Access::staff(); $uid = (int) (Auth::currentUserId() ?? 0);
    $who = trim((string) ($me['name'] ?? ''));
    if ($who === '' && $uid) { try { $st = $pdo->prepare('SELECT display_name FROM users WHERE id = ?'); $st->execute([$uid]); $who = (string) ($st->fetchColumn() ?: ''); } catch (Throwable $x) {} }
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    $ready = DataCleanup::ready($pdo);
    $only = ''; $res = null; $msg = '';
    $say = fn (string $t, bool $ok = true) => '<p data-tv-flash="' . ($ok ? 'ok' : 'error') . '">' . $e($t) . '</p>';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['dc_do']) && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        try {
            $do = (string) $_POST['dc_do'];
            $only = (string) ($_POST['rule'] ?? '');
            if ($only !== '' && !isset(DataCleanup::RULES[$only])) $only = '';
            $tz = mb_substr((string) ($_POST['tz'] ?? ''), 0, 64);
            if (in_array($do, ['undo_item', 'undo_run', 'undo_group', 'put_back'], true)) { if (!$canUndo) throw new RuntimeException($whyUndo); }
            elseif (!$can) throw new RuntimeException($why);
            switch ($do) {
                case 'preview':
                    $res = DataCleanup::preview($pdo, $only);
                    $n = array_sum(array_map(fn ($r) => $r['act'] + $r['check'], $res['rules']));
                    $msg = $say($n ? 'Preview ready: ' . number_format($n) . ' record' . ($n === 1 ? '' : 's') . ' fail today\'s rules. Nothing was changed.' : 'Preview ready: nothing fails today\'s rules. Nothing was changed.');
                    break;
                case 'run':
                    $r = DataCleanup::run($pdo, $only, $uid, $who, $tz);
                    $c = json_decode((string) ($r['counts_json'] ?? ''), true) ?: [];
                    $d = array_filter((array) ($c['done'] ?? []));
                    $words = ['quarantined' => 'restricted', 'restricted' => 'restricted', 'sighting' => 'back to sightings', 'name_unknown' => 'back as sightings "name unknown"', 'help_find' => 'set for "Help us find"', 'drop_off' => 'listed as drop-offs', 'found' => 'found as other listings', 'unconfirmed' => 'marked unconfirmed', 'caution' => 'Closed to caution', 'offered' => 'merges offered', 'held' => 'held', 'story_only' => 'held for story only', 'cleared' => 'Wikipedia texts cleared', 'queued' => 'descriptions queued', 'failed' => 'failed (in the log)'];
                    $msg = $say(($d ? implode(', ', array_map(fn ($k, $v) => number_format($v) . ' ' . $words[$k], array_keys($d), $d)) : 'Nothing to change') . '. ' . number_format((int) ($c['check'] ?? 0)) . ' to check.'
                        . (!empty($c['more']) ? ' More to do: press Continue.' : ' Pass finished.') . ' Every change can be undone below.');
                    break;
                case 'undo_group':
                    [$u, $l] = DataCleanup::undoGroup($pdo, (int) ($_POST['run'] ?? 0), (string) ($_POST['g_rule'] ?? ''), (string) ($_POST['g_why'] ?? ''), $uid);
                    $msg = $say('Undone: ' . $u . ' change' . ($u === 1 ? '' : 's') . ($l ? '. ' . $l . ' changed since: left as they are now.' : '.'));
                    break;
                case 'undo_item': case 'undo_run':
                    [$u, $l] = DataCleanup::undo($pdo, (int) ($_POST['run'] ?? 0), $do === 'undo_item' ? (string) ($_POST['ref'] ?? '') : '', $uid);
                    $msg = $say('Undone: ' . $u . ' change' . ($u === 1 ? '' : 's') . ($l ? '. ' . $l . ' changed since (by someone, or a later pass): left as they are now.' : '.'));
                    break;
                case 'put_back':
                    [$u, $l] = DataCleanup::putBack($pdo, (string) ($_POST['ref'] ?? ''), $uid);
                    $msg = $say('Put back: ' . $u . ' change' . ($u === 1 ? '' : 's') . ' undone' . ($l ? '. ' . $l . ' changed since: left as they are now.' : '.'));
                    break;
                case 'request':
                    $msg = $say(DataCleanup::request($pdo, (string) ($_POST['ref'] ?? ''), $uid, $who, $tz));
                    break;
                case 'place_drops':
                    [$placed, $tried] = DataCleanup::placeDrops($pdo, 25);
                    $msg = $say($tried ? 'Placed ' . $placed . ' of ' . $tried . ' drop-off' . ($tried === 1 ? '' : 's') . ' on the map from their street address (U.S. Census).' . ($placed < $tried ? ' The rest didn\'t match an address: drop their pins in Edit listing ("Pick on the map").' : '') : 'None waiting: every drop-off with a street address has its pin, or was tried in the last 90 days.');
                    break;
                case 'retry_now':
                    $settled = DataCleanup::settle($pdo, 300);
                    [$looked, $answered] = DataCleanup::retryTick($pdo, 300);
                    $msg = $say('Looked again at ' . number_format($looked) . ' sighting' . ($looked === 1 ? '' : 's') . ': ' . number_format($answered) . ' answered (in Review)' . ($settled ? ', ' . $settled . ' settled from Review' : '') . '. The rest are tried again on the retry ladder.');
                    break;
                case 'write':
                    $n = DataCleanup::writeNow($pdo, 10);
                    $msg = $say($n ? 'Wrote ' . $n . ' description' . ($n === 1 ? '' : 's') . '. A pass for "Wikipedia text" now clears the text they replace.' : 'Nothing written: none waiting, or AI use stopped it (see AI use).');
                    break;
                case 'auto_on': case 'auto_off':
                    DataCleanup::setSetting($pdo, 'auto', $do === 'auto_on' ? 'on' : 'off', $uid);
                    $msg = $say($do === 'auto_on' ? 'The daily pass is on. It runs only while automation is on (System Configuration → Automation).' : 'The daily pass is off. Passes run only by a button.');
                    break;
                case 'seen':
                    $msg = $say(DataCleanup::pulseDo($pdo, 'cleanup_seen:' . $only, $uid));
                    break;
                default: throw new RuntimeException('Unknown action.');
            }
        } catch (Throwable $x) {
            $known = $x instanceof RuntimeException || $x instanceof InvalidArgumentException;
            $msg = $say($known ? $x->getMessage() : 'That didn\'t finish: try one rule at a time.', false);
            if (!$known) error_log('cleanup: ' . $x->getMessage());
        }
    }
    $dis = $can ? '' : ' disabled title="' . $e($why) . '"';
    $info = fn (string $title, string $html) => '<details class="dc-i"><summary aria-label="' . $e($title) . '" title="' . $e($title) . '">ⓘ</summary><div>' . $html . '</div></details>';
    $time = fn (string $at, string $tz = '') => '<time datetime="' . $e(date('c', (int) strtotime($at))) . '" data-tv-time' . ($tz !== '' ? ' data-tz="' . $e($tz) . '"' : '') . '>' . $e(date('M j, g:i A', (int) strtotime($at))) . '</time>';
    $form = function (string $do, string $label, array $hidden = [], string $confirm = '', bool $danger = false, string $off = '', string $cls = 'ak-b') use ($e, $csrf): string {
        $h = '<form method="post" class="dc-inl" data-dc-form><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="dc_do" value="' . $e($do) . '"><input type="hidden" name="tz" value="">';
        foreach ($hidden as $k => $v) $h .= '<input type="hidden" name="' . $e($k) . '" value="' . $e((string) $v) . '">';
        return $h . '<button class="' . $cls . '" type="submit"' . ($confirm !== '' ? ' data-confirm="' . $e($confirm) . '" data-yes="' . $e($label) . '"' . ($danger ? ' data-danger' : '') : '') . ($off !== '' ? ' disabled title="' . $e($off) . '"' : '') . '>' . $e($label) . '</button></form>';
    };

    $h = '<style>.dc-i{display:inline-block;margin-left:.3rem}.dc-i>summary{cursor:pointer;list-style:none;color:#B45309;font-weight:700}.dc-i>div{background:#FFFBF2;border:1px solid #E7D9C2;border-radius:.5rem;padding:.6rem .8rem;margin:.4rem 0;max-width:46rem}'
        . '.dc-f{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;margin:.4rem 0}.dc-inl{display:inline-block;margin:.15rem .3rem .15rem 0}.dc-x>summary{cursor:pointer;color:#92400E}.dc-x ul{margin:.3rem 0 .5rem 1.1rem;padding:0}.dc-x li{margin:.2rem 0;overflow-wrap:anywhere}'
        . '.dc-g{font-size:.8rem;color:#6B5B45}.dc-r{border-top:1px solid #E8DCC6;padding:.6rem 0}.dc-r:first-of-type{border-top:0}.dc-r h4{margin:0 0 .15rem;font-size:1rem}.dc-c{display:flex;flex-wrap:wrap;gap:.35rem;margin:.35rem 0}'
        . '.dc-c span{background:#F5EBDD;border-radius:999px;padding:.1rem .55rem;font-size:.8rem;font-variant-numeric:tabular-nums}.dc-c span.dc-a{background:#FDE7D3;color:#7C2D12}.dc-c span.dc-k{background:#E3EFE8;color:#24543B}</style>';
    $h .= $msg . '<p class="ak-note">Brings what the crawler made before today\'s rules (decisions/0164) into line: listings, staged finds, the place store and landmarks. '
        . 'Preview shows, by reason, how many and which; a pass acts by rule, and every change can be undone. ' . ($can ? '' : '<b>' . $e($why) . '</b>')
        . $info('How Data cleanup works', '<p><b>Preview, then a pass.</b> Preview changes nothing. A pass acts on what fails each rule, ' . DataCleanup::BATCH . ' records a press (Continue carries on), and logs every change with what was there before, so Undo puts back one record or a whole pass.</p>'
            . '<p><b>What a pass does, by rule:</b></p><ul>' . implode('', array_map(fn ($v) => '<li>' . $e($v) . '</li>', array_unique(DataCleanup::ACTIONS))) . '</ul>'
            . '<p><b>Never deleted, never a person\'s work:</b> what an owner, our team or a member entered, a claimed listing\'s owner\'s fields, and anything a person decided (approved in the intake, a field they set, a landmark they approved) is never changed. Those are <b>Check these</b>: one Pulse case, "Data cleanup needs a person", a step per kind.</p>'
            . '<p><b>Wikipedia\'s words</b> are replaced before they go: a landmark\'s own description is written first (Place descriptions, kept as research, inside the AI cap), and a later pass clears the text only where that exists. The title and the link to the article stay.</p>'
            . '<p><b>Undo</b> leaves anything changed since as it is now: a person\'s later change wins.</p>') . '</p>';
    if (!$ready) $h .= '<p data-tv-status="info" data-tv-label="Preview only for now:">Passes and Undo start once Data cleanup\'s database update runs (within the hour, or open System Configuration → Database updates).</p>';

    // preview and pass
    $open = $ready ? DataCleanup::openRun($pdo) : null;
    $opts = '<option value="">Every rule</option>';
    foreach (DataCleanup::STORES as $sk => $sl) {
        $opts .= '<optgroup label="' . $e($sl) . '">';
        foreach (DataCleanup::RULES as $k => $r) if ($r[0] === $sk) $opts .= '<option value="' . $e($k) . '"' . ($only === $k ? ' selected' : '') . '>' . $e($r[1]) . '</option>';
        $opts .= '</optgroup>';
    }
    $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Preview or run a pass</h3>'
        . '<form method="post" class="dc-f" data-dc-form><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="tz" value="">'
        . '<label class="ak-note" for="dc-rule">Rule</label><select id="dc-rule" class="ak-in" name="rule"' . $dis . '>' . $opts . '</select>'
        . '<button class="ak-b" type="submit" name="dc_do" value="preview"' . $dis . '>Preview</button>'
        . ($ready ? '<button class="ak-b go" type="submit" name="dc_do" value="run" data-confirm="Run this pass? It acts on what fails the rule (never a person\'s work), and every change can be undone." data-yes="Run the pass"' . ($open ? ' disabled title="A pass is under way: Continue it below first."' : $dis) . '>Run a pass</button>' : '')
        . '</form>'
        . ($open ? '<p data-tv-status="info" data-tv-label="Under way:">A pass for ' . $e($open['rule'] === '' ? 'every rule' : DataCleanup::RULES[$open['rule']][1]) . ' stopped at ' . DataCleanup::BATCH . ' records. ' . '</p>' . $form('run', 'Continue the pass', ['rule' => (string) $open['rule']], '', false, $can ? '' : $why, 'ak-b go') : '')
        . '<p class="ak-note">Reads up to ' . number_format(DataCleanup::READ) . ' of each store, newest first. Every rule at once can take a minute.</p></div>';

    // what the preview found: a card per rule
    if ($res !== null) {
        $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">What the preview found</h3><p class="ak-note">As of ' . $time($res['at']) . '. ';
        $parts = [];
        foreach ($res['stores'] as $sk => $s) $parts[] = DataCleanup::STORES[$sk] . ': ' . ($s['error'] !== '' && !$s['read'] ? $s['error'] : 'read ' . number_format($s['read']) . ' of ' . number_format($s['of']) . ($s['error'] !== '' ? ' (' . $s['error'] . ')' : ''));
        $h .= $e(implode(' · ', $parts)) . '</p>';
        foreach ($res['rules'] as $k => $r) {
            [$store, $title, $what, $act] = DataCleanup::RULES[$k];
            $ex = '';
            foreach (['act' => 'Would change', 'check' => 'Check these (a person entered or decided something: never changed)', 'left' => 'Left as they are'] as $g => $gl) {
                if (!$r['examples'][$g]) continue;
                $ex .= '<p class="dc-g"><b>' . $e($gl) . '</b>' . ($r[$g] > count($r['examples'][$g]) ? ', the newest ' . count($r['examples'][$g]) . ' of ' . number_format($r[$g]) : '') . ':</p><ul>';
                foreach ($r['examples'][$g] as $it) $ex .= '<li><a href="' . $e($it['link']) . '" data-peek-frame>' . $e($it['name'] !== '' ? $it['name'] : '(no name)') . '</a>: ' . $e($it['why'])
                    . ($g === 'act' && $it['target'] !== $act ? ' <span class="dc-g">(' . $e(DataCleanup::ACTIONS[strtok($it['target'], ':')] ?? $it['target']) . ')</span>' : '') . '</li>';
                $ex .= '</ul>';
            }
            $h .= '<div class="dc-r"><h4>' . $e($title) . '</h4><div class="dc-g">' . $e(DataCleanup::STORES[$store]) . ' · ' . $e(DataCleanup::ACTIONS[$act]) . '</div>'
                . '<div class="dc-c"><span class="dc-a">Would change ' . number_format($r['act']) . '</span><span class="dc-k">Check these ' . number_format($r['check']) . '</span><span>Left ' . number_format($r['left']) . '</span></div>'
                . ($ex !== '' ? '<details class="dc-x"><summary>Examples</summary>' . $ex . '</details>' : '')
                . ($ready && $r['act'] ? $form('run', 'Run this rule', ['rule' => $k], 'Run "' . $title . '"? ' . number_format($r['act']) . ' would change; every change can be undone.', false, $open ? 'A pass is under way: Continue it first.' : ($can ? '' : $why)) : '')
                . '</div>';
        }
        $h .= '<p class="ak-note">A listing is counted under one reason, the first it fails: its name, the floor, its sources; then OpenStreetMap values, a one-site Closed and duplicates.</p></div>';
    }

    if ($ready) {
        DataCleanup::settle($pdo);   // what Review decided about cleanup's sightings (bounded; a person's decision)
        // Check these, from the last pass, for one rule (the Pulse case's "Open the list")
        $by = DataCleanup::openChecks($pdo);
        $show = (string) ($_GET['checks'] ?? '');
        if ($by) {
            $h .= '<div class="ak-card tv-bleed" id="checks"><h3 class="ak-h" style="margin-top:0">Check these</h3><p class="ak-note">A person entered or decided something on each, so passes leave them. Open each and fix it by hand, or leave it; "Looked at them" takes them off the Pulse case.</p>';
            foreach ($by as $rule => $list) {
                $h .= '<details class="dc-x dc-r"' . ($show === $rule ? ' open' : '') . '><summary><b>' . $e(DataCleanup::RULES[$rule][1]) . '</b> (' . count($list) . ')</summary><ul>';
                foreach (array_slice($list, 0, 100) as $c) $h .= '<li><a href="' . $e($c['link']) . '" data-peek-frame>' . $e($c['name']) . '</a>: ' . $e($c['why']) . '</li>';
                $h .= '</ul>' . (count($list) > 100 ? '<p class="dc-g">And ' . (count($list) - 100) . ' more.</p>' : '') . $form('seen', 'Looked at them', ['rule' => $rule], '', false, $can ? '' : $why) . '</details>';
            }
            $h .= '</div>';
        }

        // Wikipedia's words: replaced first
        [$waiting, $written, $holding] = DataCleanup::wikiCounts($pdo);
        if ($holding) {
            [$cw, $cwWhy] = DataCleanup::canWrite($pdo);
            $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Wikipedia text: replaced before it\'s cleared</h3>'
                . '<div class="dc-c"><span>Holding Wikipedia\'s words ' . number_format($holding) . '</span><span class="dc-k">Own description written ' . number_format($written) . '</span><span class="dc-a">Waiting to be written ' . number_format($waiting) . '</span></div>'
                . '<p class="ak-note">A pass for "Wikipedia text" queues each one\'s description, and clears the text only where it\'s written. Place descriptions writes them in our own words (2 or 3 sentences, its sources kept), inside the AI cap; the scheduled writer runs while automation is on.</p>'
                . ($waiting ? $form('write', 'Write 10 now', [], '', false, !$can ? $why : (!$cw ? $cwWhy : ''), 'ak-b go') : '') . '</div>';
        }

        // "Help us find this business" (decisions/0164 §3.5): the no-address-or-phone listings, asked about in public
        if (is_file(__DIR__ . '/../lib/HelpFind.php')) {
            require_once __DIR__ . '/../lib/HelpFind.php';
            [$hShown, $hRetired, $hFound] = HelpFind::counts($pdo);
            if ($hShown + $hRetired + $hFound)
                $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Help us find this business</h3>'
                    . '<div class="dc-c"><span class="dc-a">Asking the public ' . number_format($hShown) . '</span><span class="dc-k">Found and listed again ' . number_format($hFound) . '</span><span>Not shown ' . number_format($hRetired) . '</span></div>'
                    . '<p class="ak-note">Listings with a name and a town but no address or phone are asked about on their town\'s page and in search. A visitor\'s answer comes to Review as a suggestion with how they know; once a phone or street address is accepted (or the owner claims it and adds one), it\'s a listing again. Not shown: a person\'s or a protected name, or no answer in ' . HelpFind::RETIRE_DAYS . ' days (kept; an answer brings it back).</p></div>';
        }
        // sightings back in the intake, on the retry ladder (decisions/0163 §12)
        [$sWait, $sAns, $sName] = DataCleanup::sightingCounts($pdo);
        if ($sWait)
            $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Back to sightings</h3>'
                . '<div class="dc-c"><span class="dc-a">Waiting in Review ' . number_format($sWait) . '</span><span class="dc-k">A source answered ' . number_format($sAns) . '</span><span>Name unknown ' . number_format($sName) . '</span></div>'
                . '<p class="ak-note">Listings a pass took off with a name only, facts only from pages we may cite, or page text for a name but a phone or address. Each waits in Review, merged into its hidden listing once it has what it lacks, and is looked up again on the retry ladder (a day, then 7, 30 and 180 days, for good; an answer resets it). The daily pass does it while automation is on; this button does it now from what our sources already hold (no fetch, nothing spent).</p>'
                . $form('retry_now', 'Look for answers now', [], '', false, $can ? '' : $why) . ' <a class="ak-b" href="/admin/listing-intake.php">Open Review</a></div>';

        // drop-offs' pins: their own point from their street address (the Census, free); OpenStreetMap's boxes stay its own layer
        [$dpAddr, $dpNone] = DataCleanup::dropPins($pdo);
        if ($dpAddr + $dpNone)
            $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Drop-offs without a map pin</h3>'
                . '<div class="dc-c"><span class="dc-a">With a street address ' . number_format($dpAddr) . '</span><span>No street address ' . number_format($dpNone) . '</span></div>'
                . '<p class="ak-note">A drop-off\'s pin is its own point: from its street address by the U.S. Census geocoder (free, 25 a press), or dropped by a person in Edit listing ("Pick on the map"). OpenStreetMap\'s boxes show in search as its own layer, credited, and are never copied onto our listings (decisions/0065).</p>'
                . ($dpAddr ? $form('place_drops', 'Place 25 on the map', [], '', false, $can ? '' : $why, 'ak-b go') : '') . '</div>';

        // Restricted: every record held, its reason, Put back and Make it a request (no hidden limbo)
        $rBy = DataCleanup::restrictedCounts($pdo);
        if ($rBy) {
            $rShow = (string) ($_GET['restricted'] ?? '');
            $label = fn (string $k) => $k === 'review' ? 'Turned down in Review' : (DataCleanup::RULES[$k][1] ?? $k);
            $link = function (array $it): string {
                [$k, $id] = explode(':', (string) $it['ref'], 2) + ['', ''];
                if ($k === 'fact') return '/admin/insights/sources?q=' . rawurlencode((string) $it['name']);
                return (['entity' => '/admin/listing-edit.php?id=', 'staged' => '/admin/listing-intake.php?row=', 'landmark' => '/admin/local/places/'][$k] ?? '/admin/insights/cleanup?') . rawurlencode($id);
            };
            $h .= '<div class="ak-card tv-bleed" id="restricted"><h3 class="ak-h" style="margin-top:0">Restricted (' . number_format(array_sum($rBy)) . ')</h3>'
                . '<p class="ak-note">Kept for our records only, never shown (0164 R7\'s tier): page text with nothing else, staged finds and place-store names that are page text, facts from cite-only pages (their links kept as citations), and landmarks held for their names. '
                . 'Put back undoes the cleanup\'s change; Make it a request sends it back to work (a sighting in Review, or a "Help us find" card).</p>';
            foreach ($rBy as $rule => $n) {
                $h .= '<details class="dc-x dc-r"' . ($rShow === $rule ? ' open' : '') . '><summary><b>' . $e($label((string) $rule)) . '</b> (' . number_format($n) . ')</summary>';
                if ($rShow === $rule || count($rBy) === 1 || $n <= 20) {
                    $h .= '<ul>';
                    foreach (DataCleanup::restricted($pdo, (string) $rule, 60) as $it) {
                        $h .= '<li><a href="' . $e($link($it)) . '" data-peek-frame>' . $e((string) $it['name'] !== '' ? (string) $it['name'] : '(no name)') . '</a>: ' . $e(preg_replace('/^Data cleanup: [^.]*\. /', '', (string) $it['why']))
                            . ($it['at'] !== '' ? ' <span class="dc-g">' . $time((string) $it['at'], (string) $it['tz']) . '</span>' : '') . '<br>'
                            . $form('put_back', 'Put back', ['ref' => (string) $it['ref']], 'Put it back as it was before the cleanup? (Anything changed since stays as it is now.)', false, $canUndo ? '' : $whyUndo)
                            . $form('request', 'Make it a request', ['ref' => (string) $it['ref']], '', false, $it['request'] !== '' ? (string) $it['request'] : ($can ? '' : $why)) . '</li>';
                    }
                    $h .= '</ul>' . ($n > 60 ? '<p class="dc-g">The newest 60 of ' . number_format($n) . '.</p>' : '');
                } else $h .= '<p class="dc-g"><a href="?restricted=' . $e(rawurlencode((string) $rule)) . '#restricted">Show them</a></p>';
                $h .= '</details>';
            }
            $h .= '</div>';
        }

        // passes: who, when, what, and Undo
        $runs = DataCleanup::runs($pdo, 10);
        if ($runs) {
            $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Passes</h3><p class="ak-note">Undo puts a record, or a whole pass, back as it was. ' . ($canUndo ? '' : '<b>' . $e($whyUndo) . '</b>') . '</p>';
            foreach ($runs as $r) {
                $c = json_decode((string) $r['counts_json'], true) ?: [];
                $d = array_filter((array) ($c['done'] ?? []));
                $items = DataCleanup::items($pdo, (int) $r['id'], 60);
                $h .= '<div class="dc-r"><h4>' . $e($r['rule'] === '' ? 'Every rule' : DataCleanup::RULES[$r['rule']][1]) . '</h4><div class="dc-g">' . $time((string) $r['started_at'], (string) $r['by_tz']) . ' · ' . $e($r['how'] === 'schedule' ? 'the daily pass' : ($r['by_name'] !== '' ? $r['by_name'] : 'staff'))
                    . ($r['undone_at'] ? ' · <b>undone</b> ' . $time((string) $r['undone_at']) : ($r['finished_at'] ? '' : ' · under way')) . '</div>'
                    . '<div class="dc-c">' . ($d ? implode('', array_map(fn ($k, $v) => '<span>' . $e(str_replace('_', ' ', $k)) . ' ' . number_format($v) . '</span>', array_keys($d), $d)) : '<span>nothing changed</span>') . '<span class="dc-k">to check ' . number_format((int) ($c['check'] ?? 0)) . '</span><span>left ' . number_format((int) ($c['left'] ?? 0)) . '</span></div>'
                    . (!empty($c['left_by']) ? '<details class="dc-x"><summary>Why ' . number_format((int) $c['left']) . ((int) $c['left'] === 1 ? ' was' : ' were') . ' left as they are</summary><ul>' . implode('', array_map(fn ($w, $n) => '<li>' . $e((string) $w) . ': ' . number_format((int) $n) . '</li>', array_keys((array) $c['left_by']), (array) $c['left_by'])) . '</ul></details>' : '');
                if ($items) {
                    $h .= '<details class="dc-x"><summary>What changed' . (count($items) >= 60 ? ' (the newest 60)' : '') . '</summary><ul>';
                    foreach ($items as $it) {
                        $done = (int) $it['undone'] >= (int) $it['n'];
                        $h .= '<li><b>' . $e($it['name']) . '</b>: ' . $e(DataCleanup::ACTIONS[$it['target']] ?? DataCleanup::ACTIONS[$it['action']] ?? $it['action']) . ' <span class="dc-g">(' . $e(DataCleanup::RULES[$it['rule']][1] ?? $it['rule']) . ')</span> '
                            . ($done ? '<span class="dc-g">' . $e((string) $it['undo_note']) . '</span>' : $form('undo_item', 'Undo', ['run' => (int) $r['id'], 'ref' => (string) $it['ref']], '', false, $canUndo ? '' : $whyUndo)) . '</li>';
                    }
                    $h .= '</ul></details>';
                }
                if (!$r['undone_at']) foreach (DataCleanup::groups($pdo, (int) $r['id']) as $gr)   // one reason at a time (the drop boxes)
                    $h .= '<div class="dc-g">' . $form('undo_group', 'Undo all ' . (int) $gr['n'], ['run' => (int) $r['id'], 'g_rule' => (string) $gr['rule'], 'g_why' => (string) $gr['why']], 'Undo all ' . (int) $gr['n'] . ': "' . preg_replace('/^Data cleanup: /', '', (string) $gr['why']) . '"? Each goes back as it was, except anything changed since.', false, $canUndo ? '' : $whyUndo) . ' ' . $e(preg_replace('/^Data cleanup: /', '', (string) $gr['why'])) . '</div>';
                if (!$r['undone_at'] && $items) $h .= $form('undo_run', 'Undo this pass', ['run' => (int) $r['id']], 'Undo the whole pass? Every record it changed goes back as it was, except anything changed since.', true, $canUndo ? '' : $whyUndo);
                $h .= '</div>';
            }
            $h .= '</div>';
        }

        // the daily pass: shipped off, and under the automation master switch
        $auto = DataCleanup::autoOn($pdo);
        $master = null;
        try { require_once __DIR__ . '/../lib/Automation.php'; $master = Automation::master($pdo); } catch (Throwable $x) {}
        $h .= '<div class="ak-card tv-bleed"><h3 class="ak-h" style="margin-top:0">Daily pass: ' . ($auto ? 'on' : 'off') . '</h3>'
            . '<p class="ak-note">Once a day, a pass for every rule, so the record stays clean. ' . ($master ? 'Automation is paused (System Configuration → Automation), so it wouldn\'t run even when on.' : 'It runs only while automation is on.') . '</p>'
            . ($auto ? $form('auto_off', 'Switch the daily pass off', [], '', false, $can ? '' : $why) : $form('auto_on', 'Switch the daily pass on', [], 'Switch the daily pass on? It acts by rule every day while automation is on; every change can be undone.', false, $can ? '' : $why, 'ak-b go')) . '</div>';
    }
    // the device's time zone with each press (times shown where they happened), and the spinner while it works
    $h .= '<script>(function(){var z="";try{z=Intl.DateTimeFormat().resolvedOptions().timeZone||"";}catch(x){}document.querySelectorAll("form[data-dc-form] input[name=tz]").forEach(function(i){i.value=z;});'
        . 'document.addEventListener("submit",function(e){var f=e.target;if(!f||!f.hasAttribute||!f.hasAttribute("data-dc-form")||e.defaultPrevented)return;var b=e.submitter||f.querySelector("button[type=submit]");if(b&&window.TvAsk)setTimeout(function(){TvAsk.busy(b,true)},0);});})();</script>';
    return $h;
}
