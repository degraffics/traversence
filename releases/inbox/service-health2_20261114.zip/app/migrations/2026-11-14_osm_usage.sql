-- OpenStreetMap's daily budget (ServiceHealth::osmBudget; Jason, 2026-11-14: a quarter of the public guidance, crawler
-- and site counted apart). One row a UTC day and caller. Safe to run twice.
CREATE TABLE IF NOT EXISTS osm_usage (
  day DATE NOT NULL,
  caller VARCHAR(10) NOT NULL,
  queries INT UNSIGNED NOT NULL DEFAULT 0,
  bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (day, caller)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
