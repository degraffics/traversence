<?php
// app/scripts/frontier_tick.php — W0 Indexer's upkeep (decisions/0164 §1.4's note of 2026-11-17), hourly: sites not
// decided yet classified by the machine (the first pass took today's "Waiting for you"; a tribal nation's set aside for a
// person; nothing already decided changes), places' own websites ranked first, junk seen often made a skip rule, the size
// guard, and the frontier's size recorded. Database only (no outside call), so it runs whatever the switches say; never on
// staging, where the crawl tables follow live. Sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Staging.php';
if (Staging::here()) exit;
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('frontier_tick');
require_once __DIR__ . '/../lib/crawler/Frontier.php';
$pdo = Database::connection();
$r = Frontier::tick($pdo);
echo 'The index: ' . $r['classified'] . ' site(s) classified, ' . $r['places'] . ' places\' site(s) ranked first, ' . $r['rules'] . ' new skip rule(s), ' . $r['compressed'] . ' URL(s) kept as their hash' . (isset($r['why']) ? ' (' . $r['why'] . ')' : '') . "\n";
