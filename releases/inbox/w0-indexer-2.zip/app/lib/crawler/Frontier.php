<?php
/**
 * app/lib/crawler/Frontier.php — W0 Indexer's frontier (decisions/0164 §1.1–1.4 and the note of 2026-11-17: "every URL
 * found is logged; no 'suggested' gate").
 *
 * Every link on every page read is logged here, normalized and de-duplicated, with the page it came from and its link
 * text, on the same site or another. Logging isn't reading: a URL is handed to the indexer only when its site may be read
 * (Read regularly, not held, not junk) and §1.2's rules allow; robots.txt and the per-site pace are the worker's (R18).
 * Later steps write their verdict back onto the URL and its site (promoted, normal, demoted, junk); junk is kept as a
 * compact record (hash, site, reason) so it's recognised the moment it's found again, and frequent junk patterns become
 * skip rules. Every verdict is in crawl_audit_log with its reason and can be undone. Each batch from the worker gets a
 * receipt (how many stored and a checksum), so a batch a firewall swallows is resent.
 *
 * The key is sha1 of the normalized address, the page log's key (crawl_pages.url_hash), so the two join (Jason,
 * 2026-11-17, amending §1.1's SHA-256). Database only: no outside call is made from here.
 */
declare(strict_types=1);

require_once __DIR__ . '/../Database.php';
require_once __DIR__ . '/Sources.php';

final class Frontier
{
    public const WF = 'W0';
    /** The states a URL can be in (§1.1). Due ones are handed out; the rest wait or are done. */
    public const STATES = ['pending' => 'Found, not read yet', 'fetched' => 'Read', 'failed' => 'Didn\'t answer (tried again later)', 'gone' => 'Gone (checked again once)',
                           'paywall' => 'Behind a paywall (checked once a year)', 'held' => 'Its site blocked us (a person reactivates it)'];
    /** States the indexer may be handed (when due and the site may be read). */
    private const DUE = ['pending', 'fetched', 'failed', 'gone', 'paywall'];
    public const VERDICTS = ['promoted' => 'Promoted', 'normal' => 'Normal', 'demoted' => 'Demoted', 'junk' => 'Junk'];
    /** Why a URL is junk, in words. */
    public const REASONS = ['TIER5' => 'Parked, a link farm or spam (Tier 5)', 'TRAP' => 'A trap: endless calendar, session or search-result pages', 'MEDIA' => 'Not a page (an image, a file to download)',
                            'ADMIN_PATH' => 'A sign-in or account page (never public)', 'ROBOTS' => 'robots.txt asks us not to', 'GONE' => 'Gone twice, 30 days apart', 'RESTRICTED' => 'Restricted: never gathered (R18)',
                            'SKIP_RULE' => 'Matched a skip rule', 'PERSON' => 'Marked junk by a person', 'SOCIAL' => 'Facebook or Instagram: never read (R14)', 'BAD_URL' => 'Not a web address', 'PRIVATE' => 'A private address'];

    /** Tracking parameters stripped (§1.1). */
    private const TRACKING = '/^(utm_[a-z_]*|fbclid|gclid|dclid|msclkid|yclid|mc_cid|mc_eid|_ga|_gl|ref|ref_src|igshid|si)$/i';
    /** Non-public paths (§1.2, 4): logged, never read. */
    private const ADMIN_PATH = '#^/(wp-admin|wp-login\.php|login|log-in|signin|sign-in|signup|sign-up|register|account|my-account|cart|checkout|auth|oauth|dashboard|user/login)(/|$|\?)#i';
    /** Traps: session and search-result URLs, and calendar pages far from now. */
    private const TRAP_KEYS = '/^(phpsessid|jsessionid|sessionid|session_id|sid|replytocom|share|ical|outlook-ical|tribe-bar-date|eventdisplay|s|q|query|search|keyword|keywords)$/i';
    private const MEDIA = '/\.(jpe?g|png|gif|webp|svg|ico|bmp|tiff?|css|js|json|xml|rss|woff2?|ttf|eot|zip|gz|rar|7z|tar|exe|dmg|msi|apk|mp4|m4v|mov|avi|wmv|mp3|m4a|wav|ogg|webm|docx?|xlsx?|pptx?)$/i';
    /** Facebook and Instagram are never read (R14): their links are logged, their pages never handed out. */
    private const NEVER_READ = ['facebook.com', 'instagram.com', 'fb.com', 'fb.me', 'm.facebook.com'];

    private const NOT_READABLE = -20000;   // the site may not be read (not Read regularly, held, junk): logged, waiting
    private const TOO_DEEP = -10000;       // too far from a trusted source: waits, never dropped
    private const LEASE_MIN = 15;          // a URL handed out comes back this long after if no answer arrives

    // ---- set-up --------------------------------------------------------------------------------------------------------

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM ' . Database::t('crawl_frontier') . ' LIMIT 0'); $pdo->query('SELECT 1 FROM ' . Database::t('crawl_junk') . ' LIMIT 0'); return $r = true; }
        catch (Throwable $e) { return $r = false; }
    }

    /** W0's row in crawl_workflows, added paused (it ships switched off; Start the system switches it on first). */
    public static function ensureWorkflow(PDO $pdo): void
    {
        try {
            if ((int) $pdo->query("SELECT COUNT(*) FROM crawl_workflows WHERE wf = 'W0'")->fetchColumn()) return;
            $cols = []; foreach ($pdo->query('SHOW COLUMNS FROM crawl_workflows')->fetchAll(PDO::FETCH_ASSOC) as $c) $cols[$c['Field']] = $c;
            $want = ['wf' => 'W0', 'name' => 'Indexer', 'label' => 'Indexer', 'paused' => 1, 'paused_at' => date('Y-m-d H:i:s'), 'share_pct' => 0,
                     'paused_why' => 'Shipped switched off (W0, 2026-11-17): Start the system switches it on first', 'why' => 'Shipped switched off'];
            $row = [];
            foreach ($cols as $f => $c) {
                if (array_key_exists($f, $want)) { $row[$f] = $want[$f]; continue; }
                if ($c['Null'] === 'NO' && $c['Default'] === null && !str_contains((string) $c['Extra'], 'auto_increment')) $row[$f] = preg_match('/int|dec/i', (string) $c['Type']) ? 0 : (preg_match('/date|time/i', (string) $c['Type']) ? date('Y-m-d H:i:s') : '');
            }
            $pdo->prepare('INSERT IGNORE INTO crawl_workflows (`' . implode('`, `', array_keys($row)) . '`) VALUES (' . implode(', ', array_fill(0, count($row), '?')) . ')')->execute(array_values($row));
        } catch (Throwable $x) { error_log('W0 row: ' . $x->getMessage()); }
    }

    /** The indexer's settings, from the Thresholds register (§1.4: "settings, not code"). */
    public static function settings(PDO $pdo): array
    {
        require_once __DIR__ . '/../Thresholds.php';
        $g = fn (string $k) => Thresholds::get($pdo, $k);
        return ['found_batch' => (int) $g('indexer_found_batch'), 'page_batch' => (int) $g('indexer_page_batch'), 'batch_kb' => (int) $g('indexer_batch_kb'),
                'gap_s' => (int) $g('indexer_gap_s'), 'batch_max' => (int) $g('indexer_batch_max'), 'per_host' => (int) $g('indexer_per_host'),
                'link_net' => (int) $g('indexer_link_net'), 'max_depth' => (int) $g('indexer_max_depth')];
    }

    /** Why the indexer may not work now, or null: staging, the master, W0's own switch, its budget. */
    public static function off(PDO $pdo): ?string
    {
        require_once __DIR__ . '/../Staging.php';
        if (Staging::here()) return 'Staging is a safe copy: the indexer works for the live site only.';
        if (!self::ready($pdo)) return 'The frontier\'s database update hasn\'t run yet.';
        require_once __DIR__ . '/../Automation.php';
        if (($w = Automation::gathering($pdo, '', self::WF)) !== null) return $w;
        $b = self::budget($pdo);
        if ($b['cap'] > 0 && $b['used'] >= $b['cap']) return 'W0\'s Railway budget for the month is used ($' . number_format($b['used'], 2) . ' of $' . number_format($b['cap'], 2) . '): it sleeps until the 1st, or raise the cap in the Service register.';
        return null;
    }

    /** This month's Railway time for W0 by our count: [used usd, cap usd, hours]. */
    public static function budget(PDO $pdo): array
    {
        require_once __DIR__ . '/../Thresholds.php';
        $cap = (float) Thresholds::get($pdo, 'indexer_month_usd'); $used = 0.0; $secs = 0;
        try {
            $r = $pdo->query("SELECT COALESCE(SUM(units), 0) u, COALESCE(SUM(usd_micros), 0) c FROM crawl_costs WHERE service = 'railway' AND wf = 'W0' AND at >= '" . date('Y-m-01') . "'")->fetch(PDO::FETCH_ASSOC);
            $secs = (int) $r['u']; $used = (int) $r['c'] / 1e6;
        } catch (Throwable $x) {}
        return ['used' => $used, 'cap' => $cap, 'hours' => round($secs / 3600, 1)];
    }

    /** Its estimated Railway price an hour (always on, small): INDEXER_USD_HOUR in .env, else $0.005 (about $3.60 a month). */
    public static function pricePerHour(): float
    {
        $v = getenv('INDEXER_USD_HOUR');
        return is_string($v) && is_numeric($v) && (float) $v >= 0 ? (float) $v : 0.005;
    }

    /** The worker checked in: its time since the last check-in goes on the ledger as W0's Railway time. */
    public static function beat(PDO $pdo, array $b): void
    {
        $secs = max(0, min(3600, (int) ($b['secs'] ?? 0)));
        require_once __DIR__ . '/../SearchIndex.php';
        SearchIndex::setState($pdo, 'w0:beat', json_encode(['at' => time(), 'v' => mb_substr((string) ($b['v'] ?? ''), 0, 20), 'queue' => (int) ($b['queue'] ?? 0),
            'mismatches' => (int) ($b['mismatches'] ?? 0), 'batch' => (int) ($b['batch'] ?? 0), 'gap' => (float) ($b['gap'] ?? 0), 'note' => mb_substr((string) ($b['note'] ?? ''), 0, 200)]));
        if ($secs > 0) {
            require_once __DIR__ . '/CrawlService.php';
            CrawlService::cost($pdo, 'railway', self::WF, 'indexer', $secs, null, 'W0 Indexer, always on', $secs / 3600 * self::pricePerHour());
        }
    }

    /** The worker's last check-in: [at, v, queue, mismatches, batch, gap, note] or []. */
    public static function lastBeat(PDO $pdo): array
    {
        require_once __DIR__ . '/../SearchIndex.php';
        $b = json_decode(SearchIndex::state($pdo, 'w0:beat'), true);
        return is_array($b) ? $b : [];
    }

    // ---- normalizing (§1.1) --------------------------------------------------------------------------------------------

    /** The normalized address, or null when it isn't a public web address. Relative links resolve against $base. */
    public static function normalize(string $url, string $base = ''): ?string
    {
        $url = trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($url === '' || strlen($url) > 2000) return null;
        if ($base !== '' && !preg_match('#^[a-z][a-z0-9+.-]*:#i', $url)) $url = self::resolve($base, $url);
        $p = parse_url($url);
        if (!is_array($p) || empty($p['host']) || !in_array(strtolower((string) ($p['scheme'] ?? '')), ['http', 'https'], true)) return null;
        $host = strtolower(rtrim((string) $p['host'], '.'));
        if (!preg_match('/^[a-z0-9.-]+\.[a-z]{2,}$/', $host) || self::privateHost($host)) return null;
        $path = (string) ($p['path'] ?? '/');
        if ($path === '') $path = '/';
        $path = self::dots($path);
        $path = (string) preg_replace_callback('/%[0-9a-f]{2}/i', fn ($m) => strtoupper($m[0]), $path);
        if ($path !== '/' ) $path = rtrim($path, '/');   // trailing slashes off, except the root
        if ($path === '') $path = '/';
        $q = '';
        if (isset($p['query']) && $p['query'] !== '') {
            $keep = [];
            foreach (explode('&', (string) $p['query']) as $pair) {
                if ($pair === '') continue;
                $k = urldecode(explode('=', $pair, 2)[0]);
                if (preg_match(self::TRACKING, $k)) continue;
                $keep[] = [$k, $pair];
            }
            usort($keep, fn ($a, $b) => strcmp($a[0], $b[0]) ?: strcmp($a[1], $b[1]));
            $q = implode('&', array_column($keep, 1));
        }
        $port = isset($p['port']) && !in_array((int) $p['port'], [80, 443], true) ? ':' . (int) $p['port'] : '';
        $out = strtolower((string) $p['scheme']) . '://' . $host . $port . $path . ($q !== '' ? '?' . $q : '');
        return strlen($out) <= 1000 ? $out : null;
    }

    public static function hash(string $normalized): string { return sha1($normalized); }

    /** The host as the register keeps it (no www.). */
    public static function hostOf(string $url): string { return Sources::host($url); }

    private static function resolve(string $base, string $rel): string
    {
        $b = parse_url($base);
        if (!is_array($b) || empty($b['host'])) return $rel;
        $scheme = ($b['scheme'] ?? 'https');
        if (str_starts_with($rel, '//')) return $scheme . ':' . $rel;
        $root = $scheme . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
        if (str_starts_with($rel, '/')) return $root . $rel;
        if (str_starts_with($rel, '?')) return $root . ($b['path'] ?? '/') . $rel;
        if (str_starts_with($rel, '#')) return $base;
        $dir = preg_replace('#/[^/]*$#', '/', (string) ($b['path'] ?? '/'));
        return $root . ($dir === '' ? '/' : $dir) . $rel;
    }

    private static function dots(string $path): string
    {
        $out = [];
        foreach (explode('/', $path) as $seg) {
            if ($seg === '.') continue;
            if ($seg === '..') { if (count($out) > 1) array_pop($out); continue; }
            $out[] = $seg;
        }
        $p = implode('/', $out);
        return str_starts_with($p, '/') ? $p : '/' . $p;
    }

    private static function privateHost(string $host): bool
    {
        if ($host === 'localhost' || str_ends_with($host, '.local') || str_ends_with($host, '.internal') || str_ends_with($host, '.localhost')) return true;
        if (filter_var($host, FILTER_VALIDATE_IP)) return true;   // an address by number: never a public site we index
        return false;
    }

    /** Junk by its address alone (logged compactly, never read): [reason, pattern] or null. */
    public static function junkByAddress(string $url): ?array
    {
        $p = parse_url($url); $path = (string) ($p['path'] ?? '/');
        $seg = '/' . (explode('/', ltrim($path, '/'))[0] ?? '');
        if (preg_match(self::MEDIA, $path)) return ['MEDIA', mb_substr($seg . '/*.' . strtolower((string) pathinfo($path, PATHINFO_EXTENSION)), 0, 80)];
        if (preg_match(self::ADMIN_PATH, $path . (isset($p['query']) ? '?' : ''))) return ['ADMIN_PATH', mb_substr($seg, 0, 80)];
        if (isset($p['query'])) {
            foreach (explode('&', (string) $p['query']) as $pair) {
                $k = strtolower(urldecode(explode('=', $pair, 2)[0]));
                if (preg_match(self::TRAP_KEYS, $k)) return ['TRAP', mb_substr('?' . $k, 0, 80)];
            }
        }
        // calendar pages two years or more away from now: an endless calendar
        if (preg_match('#(?:^|/|[?&=])((?:19|20)\d{2})[-/](\d{1,2})(?:[-/]\d{1,2})?(?:/|$|&)#', $path . '?' . ($p['query'] ?? ''), $m) && abs((int) $m[1] - (int) date('Y')) >= 2) return ['TRAP', mb_substr($seg . '/<date>', 0, 80)];
        return null;
    }

    // ---- logging found URLs ------------------------------------------------------------------------------------------

    /**
     * Found URLs into the frontier, keyed so a resend changes nothing. $rows: [{u, f (the page it came from), t (link
     * text)}]. Returns the receipt: ['received', 'stored', 'rejected' => [[key, why]], 'skipped', 'junk', 'new', 'new_sites',
     * 'checksum']. The checksum is sha1 over the sorted sha1 of each address as the worker sent it, of those stored.
     */
    public static function found(PDO $pdo, array $rows): array
    {
        $rcpt = ['received' => 0, 'stored' => 0, 'rejected' => [], 'skipped' => 0, 'junk' => 0, 'new' => 0, 'new_sites' => 0, 'checksum' => ''];
        if (!self::ready($pdo)) return $rcpt;
        $keys = []; $items = [];
        foreach ($rows as $r) {
            if (!is_array($r)) continue;
            $rcpt['received']++;
            $sent = (string) ($r['u'] ?? '');
            $key = sha1($sent);
            $norm = self::normalize($sent, (string) ($r['f'] ?? ''));
            if ($norm === null) { $rcpt['rejected'][] = [$key, 'BAD_URL']; continue; }
            $from = (string) ($r['f'] ?? '');
            $fromNorm = $from !== '' ? self::normalize($from) : null;
            $items[] = ['key' => $key, 'url' => $norm, 'h' => self::hash($norm), 'host' => self::hostOf($norm), 'from' => $fromNorm !== null ? self::hash($fromNorm) : null,
                        'from_host' => $fromNorm !== null ? self::hostOf($fromNorm) : '', 'text' => mb_substr(trim((string) preg_replace('/\s+/', ' ', strip_tags((string) ($r['t'] ?? '')))), 0, 160)];
        }
        if ($items) {
            $hashes = array_values(array_unique(array_column($items, 'h')));
            $junk = self::known($pdo, 'crawl_junk', $hashes);
            $rules = self::rulesFor($pdo, array_map(fn ($i) => Sources::site($i['host']), $items));
            $toJunk = []; $fresh = []; $hits = [];
            foreach ($items as $it) {
                $keys[] = $it['key'];
                if (isset($junk[$it['h']])) { $rcpt['junk']++; continue; }                 // recognised: never logged or read twice
                $site = mb_substr(Sources::site($it['host']), 0, 150);
                if (($rule = self::matchRule($rules[$site] ?? [], $it['url'])) !== null) { $rcpt['skipped']++; $hits[$rule] = ($hits[$rule] ?? 0) + 1; continue; }
                if (($j = self::junkByAddress($it['url'])) !== null) { $toJunk[$it['h']] = [$site, $j[0], $j[1]]; $rcpt['junk']++; continue; }
                $fresh[$it['h']] = $it + ['site' => $site];
            }
            if ($hits) self::ruleHits($pdo, $hits);
            if ($toJunk) self::putJunk($pdo, $toJunk);
            if ($fresh) [$rcpt['new'], $rcpt['new_sites']] = self::log($pdo, array_values($fresh));
        }
        $rejected = array_flip(array_column($rcpt['rejected'], 0));
        $stored = array_values(array_filter($keys, fn ($k) => !isset($rejected[$k])));
        sort($stored);
        $rcpt['stored'] = count($stored);
        $rcpt['checksum'] = sha1(implode(',', $stored));
        return $rcpt;
    }

    /** The links a page log row carries (an older worker's read of a source): logged like any found URL. */
    public static function fromLog(PDO $pdo, array $log): void
    {
        if (!self::ready($pdo)) return;
        $rows = []; $pages = [];
        foreach ($log as $r) {
            if (!is_array($r) || empty($r['url']) || !isset($r['links']) || !is_array($r['links'])) continue;
            $pages[] = ['u' => (string) $r['url'], 'f' => ''];   // the page itself is in the frontier too, first (its links' depth counts from it)
            foreach ($r['links'] as $l) if (is_string($l)) $rows[] = ['u' => $l, 'f' => (string) $r['url']];
        }
        if (!empty($pages)) try { self::found($pdo, $pages); } catch (Throwable $x) { error_log('Frontier::fromLog: ' . $x->getMessage()); }
        foreach (array_chunk($rows, 500) as $chunk) {
            try { self::found($pdo, $chunk); } catch (Throwable $x) { error_log('Frontier::fromLog: ' . $x->getMessage()); }
        }
    }

    /** Fresh, valid, not-junk items into the frontier: one statement per batch. Returns [new URLs, new sites]. */
    private static function log(PDO $pdo, array $items): array
    {
        $T = Database::t('crawl_frontier');
        // the register: every new host classified by the machine (no "Waiting for you" gate)
        $hosts = [];
        foreach ($items as $it) $hosts[$it['host']] ??= ['url' => $it['url'], 'text' => $it['text'], 'from' => $it['from_host']];
        $newSites = Sources::addFound($pdo, $hosts);
        $siteRows = self::siteRows($pdo, array_keys($hosts));
        // depth from a trusted source: the page it came from (in this batch's from hashes)
        $fromHashes = array_values(array_unique(array_filter(array_column($items, 'from'))));
        $from = [];
        if ($fromHashes) {
            $st = $pdo->prepare('SELECT url_hash, depth, host, verdict FROM ' . $T . ' WHERE url_hash IN (' . implode(',', array_fill(0, count($fromHashes), '?')) . ')');
            $st->execute($fromHashes);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $from[(string) $r['url_hash']] = $r;
            $siteRows += self::siteRows($pdo, array_values(array_diff(array_unique(array_column($from, 'host')), array_keys($siteRows))));
        }
        $maxDepth = (int) self::settings($pdo)['max_depth'];
        $before = (int) $pdo->query('SELECT COUNT(*) FROM ' . $T . ' WHERE url_hash IN (' . implode(',', array_map(fn ($i) => $pdo->quote($i['h']), $items)) . ')')->fetchColumn();
        $vals = []; $args = [];
        foreach ($items as $it) {
            $f = $it['from'] !== null ? ($from[$it['from']] ?? null) : null;
            $depth = $f === null ? 0 : (self::trusted($siteRows[(string) $f['host']] ?? null, (string) $f['verdict']) ? 1 : min(255, (int) $f['depth'] + 1));
            $sr = $siteRows[$it['host']] ?? null;
            $ss = self::siteScore($sr);
            $us = self::urlScore('normal', 1, $depth, $maxDepth, self::trusted($sr, 'normal'));
            $vals[] = '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())';
            array_push($args, $it['h'], $it['url'], mb_substr($it['host'], 0, 190), $it['site'], $it['from'], $it['text'] !== '' ? $it['text'] : null, $depth, $ss, $us, self::clamp($ss + $us),
                       self::neverRead($it['host']) ? 'SOCIAL' : null);
        }
        // a resend, or the same page read again, changes nothing: links_in counts only a new page linking to it
        $pdo->prepare('INSERT INTO ' . $T . ' (url_hash, url, host, site, from_hash, link_text, depth, site_score, url_score, priority, reason, first_at, seen_at) VALUES ' . implode(', ', $vals) . '
                       ON DUPLICATE KEY UPDATE seen_at = NOW(), url = COALESCE(url, VALUES(url)),
                         links_in = IF(VALUES(from_hash) IS NOT NULL AND (from_hash IS NULL OR from_hash <> VALUES(from_hash)), LEAST(links_in + 1, 4000000000), links_in),
                         from_hash = COALESCE(VALUES(from_hash), from_hash), link_text = COALESCE(link_text, VALUES(link_text)), depth = LEAST(depth, VALUES(depth))')
            ->execute($args);
        return [max(0, count($items) - $before), $newSites];
    }

    private static function neverRead(string $host): bool
    {
        $site = Sources::site($host);
        return in_array($site, self::NEVER_READ, true) || in_array($host, self::NEVER_READ, true);
    }

    /** Which of these hashes a table holds: hash => true. */
    private static function known(PDO $pdo, string $table, array $hashes): array
    {
        $out = [];
        foreach (array_chunk($hashes, 500) as $c) {
            $st = $pdo->prepare('SELECT url_hash FROM ' . Database::t($table) . ' WHERE url_hash IN (' . implode(',', array_fill(0, count($c), '?')) . ')');
            $st->execute($c);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $h) $out[(string) $h] = true;
        }
        return $out;
    }

    /** Junk records (hash => [site, reason, pattern]); a URL in the frontier with the same hash leaves it. */
    private static function putJunk(PDO $pdo, array $junk): void
    {
        $vals = []; $args = [];
        foreach ($junk as $h => [$site, $reason, $pattern]) { $vals[] = '(?, ?, ?, ?, NOW())'; array_push($args, $h, mb_substr((string) $site, 0, 150), $reason, $pattern !== null && $pattern !== '' ? mb_substr((string) $pattern, 0, 80) : null); }
        foreach (array_chunk(array_keys($vals), 400) as $idx) {
            $v = []; $a = [];
            foreach ($idx as $i) { $v[] = $vals[$i]; array_push($a, ...array_slice($args, $i * 4, 4)); }
            $pdo->prepare('INSERT IGNORE INTO ' . Database::t('crawl_junk') . ' (url_hash, site, reason, pattern, at) VALUES ' . implode(', ', $v))->execute($a);
        }
        foreach (array_chunk(array_keys($junk), 400) as $c)
            $pdo->prepare('DELETE FROM ' . Database::t('crawl_frontier') . ' WHERE url_hash IN (' . implode(',', array_fill(0, count($c), '?')) . ')')->execute($c);
    }

    // ---- scores and reading priority (§1.4) ----------------------------------------------------------------------------

    /** The register's rows for these hosts: host => [status, kind, tier, verdict, held, place]. */
    private static function siteRows(PDO $pdo, array $hosts): array
    {
        $out = [];
        $hosts = array_values(array_filter(array_unique($hosts)));
        if (!$hosts || !Sources::tableExists($pdo)) return $out;
        Sources::ensureJudge($pdo);
        foreach (array_chunk($hosts, 300) as $c) {
            try {
                $st = $pdo->prepare('SELECT host, status, kind, tier, verdict, held_at, place FROM ' . Database::t('reference_sources') . ' WHERE host IN (' . implode(',', array_fill(0, count($c), '?')) . ')');
                $st->execute($c);
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    // a site decided before W0 (by a person, or the old register) has no tier yet: from its address and kind
                    if ($r['tier'] === null) $r['tier'] = Sources::tierOf((string) $r['host'], (string) $r['kind']);
                    $out[(string) $r['host']] = $r;
                }
            } catch (Throwable $x) { error_log('Frontier::siteRows: ' . $x->getMessage()); }
        }
        return $out;
    }

    /** A site official or first-party (Tier 1 or 2), or promoted: depth counts from it. */
    private static function trusted(?array $site, string $urlVerdict): bool
    {
        if ($urlVerdict === 'promoted') return true;
        if (!$site) return false;
        return ((int) ($site['tier'] ?? 0) >= 1 && (int) ($site['tier'] ?? 0) <= 2) || ($site['verdict'] ?? '') === 'promoted';
    }

    /**
     * A site's share of a URL's priority: places in our hubs first (until W15 Funnel: the websites of places we already
     * have), then its tier and its verdict. A site that may not be read (anything but Read regularly, held, junk) stops
     * its URLs being handed out; they stay logged.
     */
    private static function siteScore(?array $s): int
    {
        if (!$s || ($s['status'] ?? '') !== 'read' || !empty($s['held_at']) || ($s['verdict'] ?? '') === 'junk' || (int) ($s['tier'] ?? 0) === 5) return self::NOT_READABLE;
        if (self::neverRead((string) $s['host'])) return self::NOT_READABLE;
        $tier = [1 => 200, 2 => 150, 3 => 100, 4 => 50][(int) ($s['tier'] ?? 0)] ?? 60;
        return $tier + ((int) ($s['place'] ?? 0) ? 400 : 0) + (['promoted' => 300, 'demoted' => -300][(string) ($s['verdict'] ?? '')] ?? 0);
    }

    /** A URL's own share: its verdict, how many pages link to it, how far it is from a trusted source. */
    private static function urlScore(string $verdict, int $linksIn, int $depth, int $maxDepth, bool $siteTrusted): int
    {
        if (!$siteTrusted && $depth > $maxDepth) return self::TOO_DEEP;
        return (['promoted' => 300, 'demoted' => -300][$verdict] ?? 0) + min(50, max(0, $linksIn)) * 4 - min(10, $depth) * 40;
    }

    private static function clamp(int $v): int { return max(-32768, min(32767, $v)); }

    /** A site's score again on all its URLs (its tier, status, hold, place or verdict changed). */
    public static function rescoreSite(PDO $pdo, string $host): void
    {
        if (!self::ready($pdo)) return;
        $s = self::siteRows($pdo, [$host])[$host] ?? null;
        $ss = self::siteScore($s);
        try { $pdo->prepare('UPDATE ' . Database::t('crawl_frontier') . ' SET site_score = ?, priority = GREATEST(-32768, LEAST(32767, ? + url_score)) WHERE host = ? AND site_score <> ?')->execute([$ss, $ss, $host, $ss]); }
        catch (Throwable $x) { error_log('Frontier::rescoreSite: ' . $x->getMessage()); }
    }

    // ---- handing out work ----------------------------------------------------------------------------------------------

    /**
     * Up to $n URLs due to read, best first, at most per_host from one site, each leased for 15 minutes. With what the
     * page log knows (entity tag, last-changed date) so an unchanged page answers 304 and costs nothing.
     */
    public static function work(PDO $pdo, int $n): array
    {
        if (!self::ready($pdo) || $n <= 0) return [];
        $T = Database::t('crawl_frontier'); $set = self::settings($pdo); $per = max(1, $set['per_host']);
        $lease = "(lease_until IS NULL OR lease_until < NOW())";
        $cand = [];
        try {
            // new URLs, best first
            $cand = $pdo->query("SELECT id, url_hash, url, host, depth, state FROM $T WHERE state = 'pending' AND priority > " . self::TOO_DEEP . " AND url IS NOT NULL AND $lease
                                  ORDER BY priority DESC, id LIMIT " . ($n * 4))->fetchAll(PDO::FETCH_ASSOC);
            // then what's due again (re-reads, retries, gone and paywall checks), oldest due first
            foreach (array_diff(self::DUE, ['pending']) as $s)
                $cand = array_merge($cand, $pdo->query("SELECT id, url_hash, url, host, depth, state FROM $T WHERE state = " . $pdo->quote($s) . " AND next_at <= NOW() AND priority > " . self::TOO_DEEP . " AND url IS NOT NULL AND $lease
                                                         ORDER BY next_at LIMIT " . $n)->fetchAll(PDO::FETCH_ASSOC));
        } catch (Throwable $x) { error_log('Frontier::work: ' . $x->getMessage()); return []; }
        $out = []; $byHost = [];
        foreach ($cand as $r) {
            if (count($out) >= $n) break;
            $h = (string) $r['host'];
            if (($byHost[$h] ?? 0) >= $per) continue;
            $byHost[$h] = ($byHost[$h] ?? 0) + 1;
            $out[(string) $r['url_hash']] = $r;
        }
        if (!$out) return [];
        $ids = array_map(fn ($r) => (int) $r['id'], $out);
        $pdo->exec("UPDATE $T SET lease_until = NOW() + INTERVAL " . self::LEASE_MIN . ' MINUTE WHERE id IN (' . implode(',', $ids) . ')');
        // the page log's tags for a page read before
        $tags = [];
        try {
            $hs = array_keys($out);
            $st = $pdo->prepare('SELECT url_hash, etag, last_modified, pending_at FROM ' . Database::t('crawl_pages') . ' WHERE url_hash IN (' . implode(',', array_fill(0, count($hs), '?')) . ')');
            $st->execute($hs);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $p) $tags[(string) $p['url_hash']] = empty($p['pending_at']) ? [(string) $p['etag'], (string) $p['last_modified']] : ['', ''];
        } catch (Throwable $x) {}
        $res = [];
        foreach ($out as $h => $r) $res[] = ['u' => (string) $r['url'], 'h' => $h, 'host' => (string) $r['host'], 'etag' => $tags[$h][0] ?? '', 'modified' => $tags[$h][1] ?? '', 'again' => $r['state'] !== 'pending'];
        return $res;
    }

    // ---- what the indexer read ---------------------------------------------------------------------------------------

    /**
     * Read pages' answers (the worker sends their links separately, as found URLs from the page). $rows: [{u, s (status),
     * ty, b, e (etag), m (modified), fp, ti, k (page kind), n (links on the page), fl (flagged: an absurd number of
     * links), why (robots|admin|auth|ban|challenge|parked|thin|paywall|redirect_auth)}]. Returns the receipt as found().
     */
    public static function pages(PDO $pdo, array $rows): array
    {
        $rcpt = ['received' => 0, 'stored' => 0, 'rejected' => [], 'skipped' => 0, 'junk' => 0, 'new' => 0, 'new_sites' => 0, 'checksum' => ''];
        if (!self::ready($pdo)) return $rcpt;
        require_once __DIR__ . '/SourceIndex.php';
        $T = Database::t('crawl_frontier'); $keys = []; $byHost = []; $junk = []; $held = []; $flagged = [];
        foreach ($rows as $r) {
            if (!is_array($r)) continue;
            $rcpt['received']++;
            $sent = (string) ($r['u'] ?? ''); $key = sha1($sent);
            $url = self::normalize($sent);
            if ($url === null) { $rcpt['rejected'][] = [$key, 'BAD_URL']; continue; }
            $keys[] = $key;
            $h = self::hash($url); $host = self::hostOf($url); $site = mb_substr(Sources::site($host), 0, 150);
            $status = max(0, min(999, (int) ($r['s'] ?? 0))); $why = (string) ($r['why'] ?? '');
            $seg = '/' . (explode('/', ltrim((string) parse_url($url, PHP_URL_PATH), '/'))[0] ?? '');
            // make sure it's in the frontier (a redirect's target, a describe's home page), then route its answer
            $pdo->prepare("INSERT IGNORE INTO $T (url_hash, url, host, site, first_at, seen_at) VALUES (?, ?, ?, ?, NOW(), NOW())")->execute([$h, $url, mb_substr($host, 0, 190), $site]);
            if ($why === 'robots') { $junk[$h] = [$site, 'ROBOTS', $seg]; continue; }
            if ($why === 'admin' || ($why === 'redirect_auth' && $status < 400)) { $junk[$h] = [$site, 'ADMIN_PATH', $seg]; continue; }
            if ($why === 'parked') { $junk[$h] = [$site, 'TIER5', null]; self::verdict($pdo, 'site', $host, 'junk', 'Its page is parked, for sale or suspended (Tier 5).', 'tier5_parked'); continue; }
            if (in_array($status, [401, 403, 451], true) || in_array($why, ['auth', 'ban', 'challenge'], true) || ($status === 406 || $status === 418)) {
                $held[$host] = ($why !== '' ? $why : 'HTTP ' . $status) . ' on ' . mb_substr($url, 0, 160);
                $pdo->prepare("UPDATE $T SET state = 'held', reason = ?, lease_until = NULL WHERE url_hash = ?")->execute([$status === 451 ? 'REFUSED' : 'AUTH_WALL', $h]);
                continue;
            }
            if ($status === 402 || $why === 'paywall') { $pdo->prepare("UPDATE $T SET state = 'paywall', reason = 'PAYWALL', next_at = NOW() + INTERVAL 365 DAY, lease_until = NULL WHERE url_hash = ?")->execute([$h]); continue; }
            if ($status === 404 || $status === 410) {
                $was = $pdo->prepare("SELECT state FROM $T WHERE url_hash = ?"); $was->execute([$h]);
                if ($was->fetchColumn() === 'gone') { $junk[$h] = [$site, 'GONE', $seg]; continue; }   // twice, 30 days apart: archived
                $pdo->prepare("UPDATE $T SET state = 'gone', reason = 'GONE', next_at = NOW() + INTERVAL 30 DAY, lease_until = NULL WHERE url_hash = ?")->execute([$h]);
                $byHost[$host][] = self::logRow($url, $r, $status);
                continue;
            }
            if ($status === 0 || $status === 429 || $status >= 500) {
                // back off 2^tries minutes, at most 5 tries (the worker follows Retry-After itself); then demoted, a month later
                $pdo->prepare("UPDATE $T SET tries = LEAST(tries + 1, 250), state = IF(tries >= 5, 'failed', state), reason = 'FAILED_TRANSIENT',
                                 next_at = IF(tries >= 5, NOW() + INTERVAL 30 DAY, NOW() + INTERVAL POW(2, tries) MINUTE), lease_until = NULL WHERE url_hash = ?")->execute([$h]);
                continue;
            }
            // 200 or 304: read; the page log decides when it's due again (how often it changes)
            $byHost[$host][] = self::logRow($url, $r, $status);
            $pdo->prepare("UPDATE $T SET state = 'fetched', reason = ?, tries = 0, read_at = NOW(), lease_until = NULL WHERE url_hash = ?")->execute([!empty($r['fl']) ? 'MANY_LINKS' : null, $h]);
            if (!empty($r['fl'])) $flagged[] = $url;
            if ($why === 'thin') self::verdict($pdo, 'url', $h, 'demoted', 'A thin page: few words, mostly links.', 'thin_page');
        }
        foreach ($byHost as $host => $log) {
            try { SourceIndex::logPages($pdo, $host, $log); } catch (Throwable $x) { error_log('Frontier::pages log: ' . $x->getMessage()); }
            try {   // its next visit, from the page log
                $hs = array_map(fn ($l) => sha1($l['url']), $log);
                $pdo->prepare("UPDATE $T f JOIN " . Database::t('crawl_pages') . ' p ON p.url_hash = f.url_hash SET f.next_at = p.next_at WHERE f.state = \'fetched\' AND f.url_hash IN (' . implode(',', array_fill(0, count($hs), '?')) . ')')->execute($hs);
            } catch (Throwable $x) {}
        }
        if ($junk) { self::putJunk($pdo, $junk); $rcpt['junk'] = count($junk); }
        foreach ($held as $host => $why) self::hold($pdo, $host, $why);
        if ($flagged) self::flag($pdo, $flagged);
        sort($keys);
        $rcpt['stored'] = count($keys);
        $rcpt['checksum'] = sha1(implode(',', $keys));
        return $rcpt;
    }

    private static function logRow(string $url, array $r, int $status): array
    {
        return ['url' => $url, 'status' => $status, 'type' => (string) ($r['ty'] ?? ''), 'bytes' => (int) ($r['b'] ?? 0), 'etag' => (string) ($r['e'] ?? ''),
                'modified' => (string) ($r['m'] ?? ''), 'fingerprint' => (string) ($r['fp'] ?? ''), 'title' => (string) ($r['ti'] ?? ''), 'page_kind' => (string) ($r['k'] ?? '')];
    }

    /** Pages flagged for an absurd number of links (logged over several passes, nothing dropped): kept for Pulse. */
    private static function flag(PDO $pdo, array $urls): void
    {
        require_once __DIR__ . '/../SearchIndex.php';
        $was = json_decode(SearchIndex::state($pdo, 'w0:flagged'), true) ?: [];
        foreach ($urls as $u) $was[sha1($u)] = ['u' => mb_substr($u, 0, 300), 'at' => date('Y-m-d H:i:s')];
        SearchIndex::setState($pdo, 'w0:flagged', json_encode(array_slice($was, -50, null, true)));
    }

    public static function flagged(PDO $pdo): array
    {
        require_once __DIR__ . '/../SearchIndex.php';
        return json_decode(SearchIndex::state($pdo, 'w0:flagged'), true) ?: [];
    }

    public static function unflag(PDO $pdo, string $h): void
    {
        $f = self::flagged($pdo); unset($f[$h]);
        SearchIndex::setState($pdo, 'w0:flagged', json_encode($f));
    }

    // ---- blocks (§1.2, 5): never retried by itself -----------------------------------------------------------------------

    /** A site that blocked us is held, with the evidence, until a person reactivates it. */
    public static function hold(PDO $pdo, string $host, string $why): void
    {
        Sources::ensureJudge($pdo);
        try {
            $st = $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET held_at = COALESCE(held_at, NOW()), held_why = ? WHERE host = ? AND held_at IS NULL');
            $st->execute([mb_substr($why, 0, 255), $host]);
            if ($st->rowCount()) { self::audit($pdo, 'site', $host, 'hold', null, 'held', $why, 'blocked_us'); self::rescoreSite($pdo, $host); }
        } catch (Throwable $x) { error_log('Frontier::hold: ' . $x->getMessage()); }
    }

    /** A person's Reactivate: one polite try (its home page first); still blocked, it's held again. */
    public static function reactivate(PDO $pdo, string $host, int $uid, string $who): void
    {
        Sources::ensureJudge($pdo);
        $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET held_at = NULL, held_why = NULL WHERE host = ?')->execute([$host]);
        $pdo->prepare('UPDATE ' . Database::t('crawl_frontier') . " SET state = 'pending', reason = NULL, next_at = NULL, lease_until = NULL WHERE host = ? AND state = 'held'")->execute([$host]);
        self::audit($pdo, 'site', $host, 'reactivate', 'held', null, 'Reactivated by ' . ($who !== '' ? $who : 'a person') . ': one polite try.', 'person', $uid, $who);
        self::rescoreSite($pdo, $host);
    }

    /** Sites held because they blocked us: [host, why, at]. */
    public static function heldSites(PDO $pdo, int $n = 50): array
    {
        if (!Sources::tableExists($pdo)) return [];
        Sources::ensureJudge($pdo);
        try { return $pdo->query('SELECT host, held_why, held_at FROM ' . Database::t('reference_sources') . ' WHERE held_at IS NOT NULL ORDER BY held_at DESC LIMIT ' . max(1, min(500, $n)))->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $x) { return []; }
    }

    // ---- verdicts (the loop back from the reader) and the audit log ----------------------------------------------------

    /**
     * A verdict on a URL ($ref its hash) or a site ($ref its host): promoted, normal, demoted or junk, with its reason and
     * the rule that gave it. Logged; returns the audit row's id (0: nothing changed). A person's verdict outranks the
     * machine's: the machine never changes a URL or site a person judged until that's undone.
     */
    public static function verdict(PDO $pdo, string $subject, string $ref, string $verdict, string $reason, string $rule, int $uid = 0, string $who = ''): int
    {
        if (!self::ready($pdo) || !isset(self::VERDICTS[$verdict]) || !in_array($subject, ['url', 'site'], true) || $ref === '') return 0;
        $byPerson = $uid > 0 || $rule === 'person';
        if (!$byPerson && self::personJudged($pdo, $subject, $ref)) return 0;
        if ($subject === 'site') {
            Sources::ensureJudge($pdo);
            $st = $pdo->prepare('SELECT verdict FROM ' . Database::t('reference_sources') . ' WHERE host = ?'); $st->execute([$ref]);
            $was = $st->fetchColumn();
            if ($was === false) return 0;
            $was = (string) ($was ?: 'normal');
            if ($was === $verdict) return 0;
            $pdo->prepare('UPDATE ' . Database::t('reference_sources') . ' SET verdict = ? WHERE host = ?')->execute([$verdict === 'normal' ? null : $verdict, $ref]);
            $id = self::audit($pdo, 'site', $ref, 'verdict', $was, $verdict, $reason, $rule, $uid, $who);
            self::rescoreSite($pdo, $ref);
            return $id;
        }
        $T = Database::t('crawl_frontier');
        $st = $pdo->prepare("SELECT url_hash, site, verdict, links_in, depth, host, site_score FROM $T WHERE url_hash = ?"); $st->execute([$ref]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            $j = $pdo->prepare('SELECT site FROM ' . Database::t('crawl_junk') . ' WHERE url_hash = ?'); $j->execute([$ref]);
            $site = $j->fetchColumn();
            if ($site === false || $verdict === 'junk') return 0;
            // undoing junk: the compact record goes, so the URL is logged again the next time it's found
            $pdo->prepare('DELETE FROM ' . Database::t('crawl_junk') . ' WHERE url_hash = ?')->execute([$ref]);
            return self::audit($pdo, 'url', $ref, 'verdict', 'junk', $verdict, $reason, $rule, $uid, $who);
        }
        $was = (string) $row['verdict'];
        if ($was === $verdict) return 0;
        if ($verdict === 'junk') {
            self::putJunk($pdo, [$ref => [(string) $row['site'], $byPerson ? 'PERSON' : mb_substr(strtoupper($rule), 0, 24), null]]);
        } else {
            $sr = self::siteRows($pdo, [(string) $row['host']])[(string) $row['host']] ?? null;
            $us = self::urlScore($verdict, (int) $row['links_in'], (int) $row['depth'], (int) self::settings($pdo)['max_depth'], self::trusted($sr, $verdict));
            $pdo->prepare("UPDATE $T SET verdict = ?, url_score = ?, priority = GREATEST(-32768, LEAST(32767, site_score + ?)) WHERE url_hash = ?")->execute([$verdict, $us, $us, $ref]);
        }
        return self::audit($pdo, 'url', $ref, 'verdict', $was, $verdict, $reason, $rule, $uid, $who);
    }

    /** Puts a verdict back as it was (a person's Undo, or new evidence). */
    public static function undo(PDO $pdo, int $auditId, int $uid, string $who): string
    {
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('crawl_audit_log') . ' WHERE id = ?'); $st->execute([$auditId]);
        $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) throw new RuntimeException('That verdict isn\'t in the log.');
        if (!empty($a['undone_at'])) throw new RuntimeException('It was undone already.');
        if ($a['action'] === 'hold') { self::reactivate($pdo, (string) $a['ref'], $uid, $who); $words = 'Reactivated: one polite try.'; }
        elseif ($a['action'] === 'verdict') {
            self::verdict($pdo, (string) $a['subject'], (string) $a['ref'], (string) ($a['was'] ?: 'normal'), 'Undone by ' . ($who !== '' ? $who : 'a person') . ' (verdict #' . $auditId . ').', 'undo', $uid, $who);
            $words = 'Put back as ' . strtolower(self::VERDICTS[(string) ($a['was'] ?: 'normal')] ?? 'it was') . '.';
        } elseif ($a['action'] === 'skip_rule') {
            $pdo->prepare('UPDATE ' . Database::t('crawl_skip_rules') . ' SET active = 0 WHERE id = ?')->execute([(int) $a['ref']]);
            $words = 'The skip rule is off: what it matched is logged again when it\'s found.';
        } else throw new RuntimeException('That entry can\'t be undone.');
        $pdo->prepare('UPDATE ' . Database::t('crawl_audit_log') . ' SET undone_at = NOW() WHERE id = ?')->execute([$auditId]);
        return $words;
    }

    private static function personJudged(PDO $pdo, string $subject, string $ref): bool
    {
        try {
            $st = $pdo->prepare('SELECT by_uid, rule, undone_at FROM ' . Database::t('crawl_audit_log') . " WHERE subject = ? AND ref = ? AND action = 'verdict' ORDER BY id DESC LIMIT 1");
            $st->execute([$subject, mb_substr($ref, 0, 150)]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return $r && empty($r['undone_at']) && ((int) $r['by_uid'] > 0 || $r['rule'] === 'person');
        } catch (Throwable $x) { return false; }
    }

    /** One line in the append-only audit log (§1.4): every decision with its reason and the rule it applied. */
    public static function audit(PDO $pdo, string $subject, string $ref, string $action, ?string $was, ?string $now, string $reason, string $rule, int $uid = 0, string $who = ''): int
    {
        try {
            $pdo->prepare('INSERT INTO ' . Database::t('crawl_audit_log') . ' (at, subject, ref, action, was, now_is, reason, rule, by_uid, by_name) VALUES (NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$subject, mb_substr($ref, 0, 150), $action, $was, $now, mb_substr($reason, 0, 255), mb_substr($rule, 0, 40), $uid ?: null, $who !== '' ? mb_substr($who, 0, 80) : null]);
            return (int) $pdo->lastInsertId();
        } catch (Throwable $x) { error_log('Frontier::audit: ' . $x->getMessage()); return 0; }
    }

    /** The last entries, newest first. */
    public static function history(PDO $pdo, int $n = 30): array
    {
        try { return $pdo->query('SELECT a.*, f.url FROM ' . Database::t('crawl_audit_log') . ' a LEFT JOIN ' . Database::t('crawl_frontier') . " f ON a.subject = 'url' AND f.url_hash = a.ref ORDER BY a.id DESC LIMIT " . max(1, min(200, $n)))->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $x) { return []; }
    }

    // ---- skip rules: junk seen often, skipped at the door ----------------------------------------------------------------

    private static function rulesFor(PDO $pdo, array $sites): array
    {
        $out = [];
        $sites = array_values(array_unique(array_merge($sites, ['*'])));
        try {
            $st = $pdo->prepare('SELECT id, site, kind, pattern FROM ' . Database::t('crawl_skip_rules') . ' WHERE active = 1 AND site IN (' . implode(',', array_fill(0, count($sites), '?')) . ')');
            $st->execute($sites);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['site']][] = $r;
        } catch (Throwable $x) {}
        if (isset($out['*'])) foreach ($sites as $s) if ($s !== '*') $out[$s] = array_merge($out[$s] ?? [], $out['*']);
        return $out;
    }

    /** The rule a URL matches (its id), or null. path: the first path segment; query: a query key. */
    private static function matchRule(array $rules, string $url): ?int
    {
        if (!$rules) return null;
        $p = parse_url($url); $path = (string) ($p['path'] ?? '/');
        $keys = [];
        foreach (explode('&', (string) ($p['query'] ?? '')) as $pair) if ($pair !== '') $keys['?' . strtolower(urldecode(explode('=', $pair, 2)[0]))] = true;
        foreach ($rules as $r) {
            $pat = (string) $r['pattern'];
            if ($r['kind'] === 'query' && isset($keys[strtolower($pat)])) return (int) $r['id'];
            if ($r['kind'] === 'path' && $pat !== '/' && (str_starts_with($path . '/', rtrim($pat, '/*') . '/'))) return (int) $r['id'];
        }
        return null;
    }

    private static function ruleHits(PDO $pdo, array $hits): void
    {
        $st = $pdo->prepare('UPDATE ' . Database::t('crawl_skip_rules') . ' SET hits = hits + ? WHERE id = ?');
        foreach ($hits as $id => $n) { try { $st->execute([$n, $id]); } catch (Throwable $x) {} }
    }

    /**
     * Junk seen often becomes a rule (§1.4): 25 or more junk records of one site with the same reason and pattern in a
     * week (a site's calendar pages, a session key). Robots and gone pages too, by their first path segment.
     */
    public static function mineRules(PDO $pdo): int
    {
        $n = 0;
        try {
            $rows = $pdo->query('SELECT site, reason, pattern, COUNT(*) c FROM ' . Database::t('crawl_junk') . " WHERE pattern IS NOT NULL AND at >= NOW() - INTERVAL 7 DAY
                                  AND reason IN ('TRAP', 'ROBOTS', 'GONE', 'ADMIN_PATH', 'MEDIA') GROUP BY site, reason, pattern HAVING c >= 25 ORDER BY c DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
            $ins = $pdo->prepare('INSERT IGNORE INTO ' . Database::t('crawl_skip_rules') . " (rule_key, site, kind, pattern, reason, made_by, active, at) VALUES (?, ?, ?, ?, ?, 'machine', 1, NOW())");
            foreach ($rows as $r) {
                $pat = (string) $r['pattern'];
                if (str_contains($pat, '<date>') || $pat === '/' || $pat === '') continue;   // dates are caught by address already
                $kind = str_starts_with($pat, '?') ? 'query' : 'path';
                if ($kind === 'path') $pat = (string) preg_replace('#/\*\..*$#', '', $pat);
                $ins->execute([sha1($r['site'] . '|' . $kind . '|' . $pat), (string) $r['site'], $kind, $pat, (string) $r['reason']]);
                if ($ins->rowCount()) {
                    $id = (int) $pdo->lastInsertId();
                    self::audit($pdo, 'rule', (string) $id, 'skip_rule', null, 'active', $r['c'] . ' junk records of ' . $r['site'] . ' matched ' . $pat . ' in a week (' . (self::REASONS[$r['reason']] ?? $r['reason']) . ').', 'junk_pattern');
                    $n++;
                }
            }
        } catch (Throwable $x) { error_log('Frontier::mineRules: ' . $x->getMessage()); }
        return $n;
    }

    public static function rules(PDO $pdo, int $n = 50): array
    {
        try { return $pdo->query('SELECT * FROM ' . Database::t('crawl_skip_rules') . ' ORDER BY active DESC, hits DESC, id DESC LIMIT ' . max(1, min(500, $n)))->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $x) { return []; }
    }

    // ---- receipts ------------------------------------------------------------------------------------------------------

    /**
     * A batch's receipt, kept: the worker said how many it sent ($declared); received fewer means something on the way
     * (a firewall) cut it. Keyed, so the same batch sent again keeps one row.
     */
    public static function receipt(PDO $pdo, string $key, string $kind, int $declared, array $rcpt, int $bytes, int $ms): array
    {
        $ok = $declared === 0 || $declared === (int) $rcpt['received'];
        try {
            $pdo->prepare('INSERT INTO ' . Database::t('crawl_batches') . ' (batch_key, kind, declared, received, stored_n, rejected, checksum, bytes, ok, ms, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                           ON DUPLICATE KEY UPDATE received = VALUES(received), stored_n = VALUES(stored_n), rejected = VALUES(rejected), checksum = VALUES(checksum), bytes = VALUES(bytes), ok = VALUES(ok), ms = VALUES(ms), at = NOW()')
                ->execute([sha1($key), mb_substr($kind, 0, 8), $declared, (int) $rcpt['received'], (int) $rcpt['stored'], count($rcpt['rejected']), $rcpt['checksum'], $bytes, $ok ? 1 : 0, $ms]);
        } catch (Throwable $x) { error_log('Frontier::receipt: ' . $x->getMessage()); }
        return ['key' => $key, 'declared' => $declared, 'received' => (int) $rcpt['received'], 'stored' => (int) $rcpt['stored'], 'rejected' => $rcpt['rejected'], 'checksum' => $rcpt['checksum'], 'ok' => $ok];
    }

    /** Mismatches in a row: the site's own (received fewer than declared) and the worker's (its last check-in). */
    public static function mismatches(PDO $pdo): int
    {
        $site = 0;
        try { foreach ($pdo->query('SELECT ok FROM ' . Database::t('crawl_batches') . ' ORDER BY id DESC LIMIT 10')->fetchAll(PDO::FETCH_COLUMN) as $ok) { if ((int) $ok) break; $site++; } } catch (Throwable $x) {}
        return max($site, (int) (self::lastBeat($pdo)['mismatches'] ?? 0));
    }

    // ---- upkeep: the size guard, the rules, the first pass (hourly, app/scripts/frontier_tick.php) ---------------------------

    /**
     * The hourly upkeep. Database only, so it runs whatever the switches say: today's "Waiting for you" sources are
     * classified (the first pass; nothing already decided changes), places' websites ranked first, junk patterns become
     * rules, and the size guard keeps the frontier compact.
     */
    public static function tick(PDO $pdo): array
    {
        $out = ['classified' => 0, 'places' => 0, 'rules' => 0, 'compressed' => 0];
        if (!self::ready($pdo)) return $out + ['why' => 'its database update hasn\'t run'];
        self::ensureWorkflow($pdo);
        for ($i = 0; $i < 10; $i++) { $n = Sources::sweep($pdo, 200); $out['classified'] += $n; if ($n < 1) break; }
        $out['places'] = self::markPlaces($pdo);
        $out['rules'] = self::mineRules($pdo);
        $out['compressed'] = self::compress($pdo);
        self::snapshot($pdo);
        try { $pdo->exec('UPDATE ' . Database::t('crawl_frontier') . ' SET lease_until = NULL WHERE lease_until < NOW() - INTERVAL 1 HOUR'); } catch (Throwable $x) {}
        try { $pdo->exec('DELETE FROM ' . Database::t('crawl_batches') . ' WHERE at < NOW() - INTERVAL 30 DAY'); } catch (Throwable $x) {}
        return $out;
    }

    /**
     * Places in our hubs first (until W15 Funnel: the websites of places we already have): their sites marked, and their
     * URLs ranked up. Returns how many sites changed.
     */
    public static function markPlaces(PDO $pdo): int
    {
        if (!Sources::tableExists($pdo)) return 0;
        Sources::ensureJudge($pdo);
        $hosts = [];
        try {
            foreach ($pdo->query("SELECT DISTINCT meta_value FROM entity_metadata WHERE meta_key = 'website' AND meta_value LIKE 'http%' LIMIT 50000")->fetchAll(PDO::FETCH_COLUMN) as $w) {
                $h = Sources::host((string) $w);
                if ($h !== '') $hosts[$h] = true;
            }
        } catch (Throwable $x) { return 0; }
        $n = 0;
        $R = Database::t('reference_sources');
        foreach (array_chunk(array_keys($hosts), 300) as $c) {
            try {
                $st = $pdo->prepare("SELECT host FROM $R WHERE place = 0 AND host IN (" . implode(',', array_fill(0, count($c), '?')) . ')'); $st->execute($c);
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $h) {
                    $pdo->prepare("UPDATE $R SET place = 1 WHERE host = ?")->execute([$h]);
                    self::rescoreSite($pdo, (string) $h); $n++;
                }
            } catch (Throwable $x) { error_log('Frontier::markPlaces: ' . $x->getMessage()); }
        }
        return $n;
    }

    /**
     * The size guard (§1.4): a URL never read after the set days (180), not promoted and not linked from anything
     * promoted, keeps only its hash (and site and scores), so it's still recognised when it's found again.
     */
    public static function compress(PDO $pdo): int
    {
        require_once __DIR__ . '/../Thresholds.php';
        $days = max(30, (int) Thresholds::get($pdo, 'indexer_compress_days'));
        $T = Database::t('crawl_frontier'); $n = 0;
        try {
            $top = (int) $pdo->query("SELECT COALESCE(MAX(id), 0) FROM $T WHERE first_at < NOW() - INTERVAL $days DAY")->fetchColumn();
            require_once __DIR__ . '/../SearchIndex.php';
            $from = (int) SearchIndex::state($pdo, 'w0:compress_from');
            for ($a = $from; $a < $top && $n < 50000; $a += 5000) {
                $st = $pdo->prepare("UPDATE $T f LEFT JOIN $T p ON p.url_hash = f.from_hash AND p.verdict = 'promoted'
                                      SET f.url = NULL, f.link_text = NULL WHERE f.id > ? AND f.id <= ? AND f.url IS NOT NULL AND f.read_at IS NULL
                                        AND f.verdict <> 'promoted' AND f.first_at < NOW() - INTERVAL $days DAY AND p.id IS NULL");
                $st->execute([$a, $a + 5000]); $n += $st->rowCount();
                SearchIndex::setState($pdo, 'w0:compress_from', (string) min($top, $a + 5000));
            }
            if ($from >= $top) SearchIndex::setState($pdo, 'w0:compress_from', '0');   // round again from the start next time
        } catch (Throwable $x) { error_log('Frontier::compress: ' . $x->getMessage()); }
        return $n;
    }

    /** Its size now: rows, compressed, junk, MB on disk, and growth (a day's snapshot kept 30 days). */
    public static function size(PDO $pdo): array
    {
        $T = Database::t('crawl_frontier'); $out = ['rows' => 0, 'compressed' => 0, 'junk' => 0, 'mb' => 0.0, 'day' => 0, 'week' => 0, 'by_state' => [], 'by_verdict' => [], 'sites' => 0];
        if (!self::ready($pdo)) return $out;
        try {
            $out['rows'] = (int) $pdo->query("SELECT COUNT(*) FROM $T")->fetchColumn();
            $out['compressed'] = (int) $pdo->query("SELECT COUNT(*) FROM $T WHERE url IS NULL")->fetchColumn();
            $out['junk'] = (int) $pdo->query('SELECT COUNT(*) FROM ' . Database::t('crawl_junk'))->fetchColumn();
            $out['day'] = (int) $pdo->query("SELECT COUNT(*) FROM $T WHERE first_at >= NOW() - INTERVAL 1 DAY")->fetchColumn();
            $out['week'] = (int) $pdo->query("SELECT COUNT(*) FROM $T WHERE first_at >= NOW() - INTERVAL 7 DAY")->fetchColumn();
            $out['by_state'] = array_map('intval', $pdo->query("SELECT state, COUNT(*) FROM $T GROUP BY state")->fetchAll(PDO::FETCH_KEY_PAIR));
            $out['by_verdict'] = array_map('intval', $pdo->query("SELECT verdict, COUNT(*) FROM $T GROUP BY verdict")->fetchAll(PDO::FETCH_KEY_PAIR));
            $out['sites'] = (int) $pdo->query("SELECT COUNT(DISTINCT host) FROM $T")->fetchColumn();
            $out['mb'] = round((float) $pdo->query("SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.TABLES WHERE table_schema = DATABASE()
                                                     AND table_name IN ('crawl_frontier', 'crawl_junk', 'crawl_audit_log', 'crawl_skip_rules', 'crawl_batches')")->fetchColumn() / 1048576, 1);
        } catch (Throwable $x) { error_log('Frontier::size: ' . $x->getMessage()); }
        return $out;
    }

    private static function snapshot(PDO $pdo): void
    {
        require_once __DIR__ . '/../SearchIndex.php';
        $h = json_decode(SearchIndex::state($pdo, 'w0:size'), true) ?: [];
        $d = date('Y-m-d');
        if (isset($h[$d])) return;
        $s = self::size($pdo);
        $h[$d] = ['rows' => $s['rows'], 'junk' => $s['junk'], 'mb' => $s['mb']];
        SearchIndex::setState($pdo, 'w0:size', json_encode(array_slice($h, -30, null, true)));
    }

    /** The daily snapshots: date => [rows, junk, mb]. */
    public static function growth(PDO $pdo): array
    {
        require_once __DIR__ . '/../SearchIndex.php';
        return json_decode(SearchIndex::state($pdo, 'w0:size'), true) ?: [];
    }

    // ---- Pulse: one case, "W0 Indexer needs a look" (Operations::pulseItems) ----------------------------------------------

    /** What needs a person: receipts mismatching three times in a row, sites that blocked us, flagged pages, its size. */
    public static function needs(PDO $pdo): array
    {
        $out = [];
        if (!self::ready($pdo)) return $out;
        if (($m = self::mismatches($pdo)) >= 3) $out[] = ['receipts', 'Batches went missing: ' . $m . ' receipts in a row didn\'t match', 'The site stored fewer records than the indexer sent, ' . $m . ' times in a row: something on the way (most likely Bluehost\'s firewall) is cutting batches without an error. The indexer has slowed down and resends what\'s missing.'];
        foreach (self::heldSites($pdo, 20) as $s) $out[] = ['held:' . $s['host'], $s['host'] . ' blocked us', (string) $s['held_why'] . '. It\'s never retried by itself; its records refresh from their other sources meanwhile.'];
        foreach (self::flagged($pdo) as $h => $f) $out[] = ['flag:' . $h, 'A page with an absurd number of links', $f['u'] . ': its links are being logged over several passes; nothing is dropped. Is it a real directory, or a broken page?'];
        require_once __DIR__ . '/../Thresholds.php';
        $s = self::size($pdo); $cap = (int) Thresholds::get($pdo, 'indexer_frontier_mb');
        if ($cap > 0 && $s['mb'] >= $cap) $out[] = ['size', 'The frontier is ' . number_format($s['mb']) . ' MB', 'Past the ' . number_format($cap) . ' MB set in Thresholds. If it outgrows Bluehost\'s database, the frontier moves to the worker\'s side (Railway or Supabase, decisions/0164 §1.4).'];
        return $out;
    }
}
