<?php
// /user/api/pulse-act.php — what a Pulse row holds and what its icons do, for the member's and a business's Pulse
// (decisions/0172 "The row's icons" and "The message"). Signed in; POSTs need X-CSRF-Token. Every action goes through the
// library that owns the thing (People, BizMessages, GuestInquiries, Reports, Links, GroupNotices, MemberPosts, Notify,
// Mailer); this file only checks who may do it and says what happened.
//   GET  ?ref={json}                      -> {thread} a conversation opened in place (people | biz | team | guest)
//   GET  ?forward_to=1                    -> {people: [[id, name, what]], team: [[id, name, role]], left: n} who you can pass it on to
//   POST {do: 'reply', ref, body, type?}  -> sends it (People::send, BizMessages::personSend|bizReply, GuestInquiries::bizReply)
//   POST {do: 'forward', item, to: 'person'|'team'|'email', to_user?, to_email?, note?}
//          a person's message forwards within the site or by email with a line saying who forwarded it (Jason,
//          2026-11-18, decision pop-up); email forwards are capped per person per day (FORWARD_DAY)
//   POST {do: 'report', item, reason, note?}   -> the existing report path (Reports::file; a customer's message to a business
//          reaches our team's support inbox); never tells the person reported
//   POST {do: 'block', item}  -> a person (People::block) or, from a business, all its messages to you (BizMessages mutes);
//          the blocked side is never told
//   POST {do: 'mute', item, on?} -> the viewer's own: the poster's posts (Links::mute), a group (GroupNotices::setMuted),
//          a conversation (People::setThread)
//   POST {do: 'addressbook', item} -> the person to your Address Book (People::connect) or the business (Links::set)
//   POST {do: 'keep', item}   -> MemberPosts::keep (the poster, or someone a Snap was sent to)
//   `item` is the row as /user/api/pulse.php gave it: {ref, comms?, post?, title, body, url}; the server reads the thing
//   again from its own tables and never trusts the row's words.

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/Roles.php';
require_once __DIR__ . '/../../../app/lib/People.php';
require_once __DIR__ . '/../../../app/lib/BizMessages.php';
require_once __DIR__ . '/../../../app/lib/PulseAct.php';

header('Cache-Control: no-store');
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$uid = (int) $me['id'];
$pdo = Database::connection();

try {
    $ctx = Roles::current($pdo, $uid);
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $csrf = ['csrf' => $_SESSION['csrf_token'] ?? null];
        if (isset($_GET['ref'])) Response::json(['ok' => true, 'thread' => PulseAct::thread($pdo, $uid, $ctx, (array) json_decode((string) $_GET['ref'], true))] + $csrf);
        if (isset($_GET['forward_to'])) Response::json(['ok' => true] + PulseAct::forwardTargets($pdo, $uid, $ctx) + $csrf);
        Response::error('What would you like?', 400, 'bad_request');
    }
    Response::requireMethod('POST');
    Response::requireCsrf();
    $b = Response::jsonBody();
    $item = (array) ($b['item'] ?? []);
    $out = match ((string) ($b['do'] ?? '')) {
        'reply' => PulseAct::reply($pdo, $uid, $ctx, (array) ($b['ref'] ?? []), (string) ($b['body'] ?? ''), (string) ($b['type'] ?? '')),
        'forward' => PulseAct::forward($pdo, $me, $ctx, $item, (string) ($b['to'] ?? ''), (int) ($b['to_user'] ?? 0), (string) ($b['to_email'] ?? ''), (string) ($b['note'] ?? '')),
        'report' => PulseAct::report($pdo, $uid, $ctx, $item, (string) ($b['reason'] ?? ''), (string) ($b['note'] ?? '')),
        'block' => PulseAct::block($pdo, $uid, $ctx, $item),
        'mute' => PulseAct::mute($pdo, $uid, $ctx, $item, !isset($b['on']) || !empty($b['on'])),
        'addressbook' => PulseAct::addressBook($pdo, $uid, $ctx, $item),
        'keep' => PulseAct::keep($pdo, $uid, $item),
        default => throw new InvalidArgumentException('What would you like to do?'),
    };
    Response::json(['ok' => true] + $out);
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'invalid');
} catch (RuntimeException $e) {
    Response::error($e->getMessage(), 429, 'limited');
} catch (Throwable $e) {
    error_log('user/api/pulse-act.php: ' . $e->getMessage());
    Response::error('That didn\'t work. Try again; still stuck? Write to support@traversence.com.', 500, 'server_error');
}
