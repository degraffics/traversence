<?php
// /user/api/pulse.php — the Pulse (decisions/0055 §5), for the context the person is acting in.
//   GET -> {context, needs: [[count, text, link]], sources: {key: label}, items: [{source, title, body, url, when, unread, ref?, group?,
//          fwd (why ↗ can't, '' when it can), protect: [[key, label, what, why not]]}]}

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/MemberPulse.php';   // the member's own Pulse (the staff Pulse is app/lib/Pulse.php)
require_once __DIR__ . '/../../../app/lib/Roles.php';
require_once __DIR__ . '/../../../app/lib/PulseAct.php';   // what each row's Pass it on and Protect can do (decisions/0172)

header('Cache-Control: no-store');
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$pdo = Database::connection();
try {
    $ctx = Roles::current($pdo, (int) $me['id']);
    $src = MemberPulse::sources($ctx);
    Response::json(['ok' => true, 'context' => ['key' => $ctx['key'], 'kind' => $ctx['kind'], 'label' => $ctx['label']],
                    'needs' => MemberPulse::needs($pdo, (int) $me['id'], $ctx),
                    'sources' => (object) array_combine($src, array_map(fn ($k) => MemberPulse::SOURCES[$k], $src)),
                    'items' => array_map(fn ($i) => PulseAct::decorate($i, $ctx), MemberPulse::stream($pdo, (int) $me['id'], $ctx)),
                    'csrf' => $_SESSION['csrf_token'] ?? null]);
} catch (Throwable $e) {
    error_log('user/api/pulse.php: ' . $e->getMessage());
    Response::error('The Pulse isn\'t available right now.', 500, 'server_error');
}
