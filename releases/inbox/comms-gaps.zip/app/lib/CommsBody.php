<?php
// app/lib/CommsBody.php — the small pieces every message body is drawn from (decisions/0172 "The message: what it's
// for, and acting on it inside it"). A kind's body is made by the library that owns it (CommentNotices, Bookings,
// GroupNotices: Notify::BODIES); these helpers only keep the look and the button contract one:
//   a button   <button type="button" class="tv-btn" data-msg-act="/api/…" data-msg-body='{"…"}'>Hide</button>
//   a reply    <form data-msg-reply="/api/…" data-msg-body='{"…"}'><textarea name="body" data-spell …></textarea><button>Reply</button></form>
// Pulse's own script posts the JSON (with every named field of a reply form), answers beside the button, and swaps in
// the new body when the answer carries `html`. Nothing here decides who may act: each endpoint checks that itself.
declare(strict_types=1);

final class CommsBody
{
    public static function e(?string $s): string { return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

    /** A moment, shown in the viewer's zone by js/tv-time.js, with the server's words until it's painted. */
    public static function time(?string $at): string
    {
        $t = strtotime((string) $at);
        if (!$t) return '';
        return '<time datetime="' . self::e(date('c', $t)) . '" data-tv-time>' . self::e(date('M j, g:i A', $t)) . '</time>';
    }

    /** An action button. $body: the JSON sent. $o: confirm (question), yes (its button), danger, off (why it can't be pressed). */
    public static function button(string $label, string $endpoint, array $body, array $o = []): string
    {
        if (!empty($o['off'])) return '<button type="button" class="tv-btn" disabled title="' . self::e((string) $o['off']) . '" aria-disabled="true">' . self::e($label) . '</button>'
            . '<small class="tv-mb-why">' . self::e((string) $o['off']) . '</small>';
        $h = '<button type="button" class="tv-btn' . (!empty($o['danger']) ? ' tv-btn-danger' : '') . '" data-msg-act="' . self::e($endpoint) . '" data-msg-body=\'' . self::json($body) . '\'';
        if (!empty($o['confirm'])) $h .= ' data-confirm="' . self::e((string) $o['confirm']) . '" data-yes="' . self::e((string) ($o['yes'] ?? $label)) . '"' . (!empty($o['danger']) ? ' data-danger' : '');
        return $h . '>' . self::e($label) . '</button>';
    }

    /** A short reply box. $extra: more fields inside the form (already escaped HTML). */
    public static function reply(string $endpoint, array $body, string $placeholder, string $button = 'Reply', int $max = 2000, string $extra = ''): string
    {
        return '<form class="tv-mb-reply" data-msg-reply="' . self::e($endpoint) . '" data-msg-body=\'' . self::json($body) . '\'>'
            . '<textarea name="body" data-spell maxlength="' . $max . '" rows="2" required placeholder="' . self::e($placeholder) . '"></textarea>'
            . $extra . '<button type="submit" class="tv-btn">' . self::e($button) . '</button></form>';
    }

    /** Someone's words, quoted: who, when, what. */
    public static function quote(string $who, ?string $at, string $words, string $note = ''): string
    {
        return '<blockquote class="tv-mb-q"><b>' . self::e($who) . '</b> <small>' . self::time($at) . '</small>'
            . ($note !== '' ? ' <small class="tv-mb-note">' . self::e($note) . '</small>' : '') . '<p>' . nl2br(self::e($words)) . '</p></blockquote>';
    }

    /** One line of where it stands now, as the site's status line (tv-ask.js draws it). */
    public static function status(string $text, string $tone = 'info', string $label = ''): string
    {
        return '<p data-tv-status="' . self::e($tone) . '"' . ($label !== '' ? ' data-tv-label="' . self::e($label) . '"' : '') . '>' . self::e($text) . '</p>';
    }

    /** A row of buttons. */
    public static function acts(array $buttons): string
    {
        $b = array_filter($buttons, fn ($x) => $x !== '');
        return $b ? '<div class="tv-mb-acts">' . implode('', $b) . '</div>' : '';
    }

    /** The body's frame, with its few rules once per page (phone first: nothing wider than the message). */
    public static function wrap(string $inner): string
    {
        static $css = false;
        $style = '';
        if (!$css) {
            $css = true;
            $style = '<style>.tv-mb{max-width:100%;box-sizing:border-box;overflow-wrap:anywhere;font-size:.92rem;color:#3E2B1F}.tv-mb p{margin:.3rem 0}'
                . '.tv-mb-q{margin:.4rem 0;padding:.45rem .65rem;border-left:3px solid #CBB98D;background:#FFFBF2;border-radius:.4rem}.tv-mb-q p{margin:.2rem 0 0;white-space:normal}'
                . '.tv-mb-q small{color:#8A7355;font-size:.75rem}.tv-mb-q .tv-mb-note{color:#92400E;font-weight:600}.tv-mb-sub{margin-left:.9rem}'
                . '.tv-mb-acts{display:flex;flex-wrap:wrap;gap:.4rem;margin:.5rem 0;align-items:center}.tv-mb-why{flex-basis:100%;color:#8A7355;font-size:.75rem}'
                . '.tv-mb-reply{display:flex;flex-direction:column;gap:.35rem;margin:.5rem 0}.tv-mb-reply textarea,.tv-mb-reply select,.tv-mb-reply input[type=text]{width:100%;box-sizing:border-box;font:inherit;font-size:.9rem;border:1px solid #CBB98D;border-radius:.5rem;padding:.45rem .55rem;background:#fff}'
                . '.tv-mb-reply button{align-self:flex-start}.tv-mb-reply label{font-size:.82rem;color:#6B5640}.tv-mb dl{display:grid;grid-template-columns:auto 1fr;gap:.15rem .7rem;margin:.4rem 0}.tv-mb dt{color:#8A7355;font-size:.8rem}.tv-mb dd{margin:0}'
                . '.tv-mb details{margin:.4rem 0}.tv-mb summary{cursor:pointer;color:#92400E;font-size:.85rem}.tv-mb a{color:#92400E}'
                // its buttons, in the site's look wherever the body opens (Pulse, the bell, a business's or the admin's stream)
                . '.tv-mb .tv-btn{font:inherit;font-size:.82rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:.55rem;padding:.35rem .8rem;cursor:pointer;white-space:nowrap;text-decoration:none;display:inline-flex;align-items:center;gap:.3rem;min-height:2rem}'
                . '.tv-mb .tv-btn:hover{background:#F7D9B5}.tv-mb .tv-btn:focus-visible{outline:2px solid #92400E;outline-offset:2px}.tv-mb .tv-btn[disabled]{opacity:.55;cursor:default}'
                . '.tv-mb .tv-btn.tv-btn-danger{color:#991B1B;border-color:#FCA5A5}.tv-mb .tv-btn.tv-btn-danger:hover{background:#FEE2E2}.tv-mb .tv-btn.ghost{background:none;border-color:transparent;color:#92400E;text-decoration:underline}</style>';
        }
        return $style . '<div class="tv-mb">' . $inner . '</div>';
    }

    /** Details as a short list: [label => value (plain text)]. */
    public static function facts(array $rows): string
    {
        $h = '<dl>';
        foreach ($rows as $k => $v) if ((string) $v !== '') $h .= '<dt>' . self::e((string) $k) . '</dt><dd>' . self::e((string) $v) . '</dd>';
        return $h . '</dl>';
    }

    /**
     * The message a button was pressed in, for its new body: the comms_messages row, only when it's this viewer's own.
     * Null when there's no message id, or it isn't theirs (then the endpoint answers without a new body).
     */
    public static function message(PDO $pdo, int $msgId, int $viewer): ?array
    {
        if ($msgId <= 0) return null;
        try {
            $st = $pdo->prepare('SELECT * FROM comms_messages WHERE id = ? AND to_user = ?'); $st->execute([$msgId, $viewer]);
            return $st->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Throwable) { return null; }
    }

    private static function json(array $a): string
    {
        return (string) json_encode($a, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS);
    }
}
