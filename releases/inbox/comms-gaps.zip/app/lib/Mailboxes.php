<?php
// app/lib/Mailboxes.php — mailboxes read and answered in Pulse (decisions/0172 §4.7; 0167 §2, §2a). Pulse is a window onto
// the mailbox, not a copy that takes over: a reply goes out from that mailbox (its own SMTP, or Microsoft's Graph), lands in
// its own Sent folder, and read state is kept in step both ways.
//   providers  cpanel (our own mailboxes: support@, orders@, a staff member's), imap (any IMAP host, app password), pop (inbox
//              only, no read state back, a copy left on the server), gmail (IMAP with an app password; "Sign in with
//              Google" only once revenue covers Google's yearly assessment: gmailGate()), microsoft ("Sign in with
//              Microsoft", Graph: Microsoft no longer takes passwords), ses (an address on one of our domains received by
//              Amazon SES, which calls /api/ses-inbound.php).
//   who        staff: our cPanel mailboxes they oversee (CommsSetup overseers, 0167 §2a), and an outside one once their
//              manager approves it (Jason, 2026-11-18). A business's and a member's mailboxes are offered through the App
//              store (0169, Jason 2026-11-18): the table already takes owner 'entity' and 'user', nothing offers them yet.
//   freshness  every 5 minutes (the mail_sync job; Bluehost can't hold a connection open), and at once when the person
//              opens their inbox (syncFor, bounded). We keep a working copy of the last 90 days for search and threading
//              (mail_keep purges older); Disconnect deletes our copy and the sealed password.
//   private    a person's mailbox is theirs; staff mailboxes only their overseers'. Nothing from a mailbox goes to AI.
//   failures   a refused password, an expired sign-in or a full mailbox becomes an Alert in that person's Pulse with
//              Reconnect in it (kind mailbox.reconnect), never a dead end.
//   staging    never connects (each transport asks StagingGate::hold first; connect() refuses on staging).
// The mail transports (MailImap, MailPop, MailSmtp, MailMime, MsGraphMail) know nothing of who may read what; this does.
declare(strict_types=1);

final class Mailboxes
{
    public const PROVIDERS = [
        'cpanel'    => ['One of our mailboxes', 'support@, orders@ or a staff mailbox on our cPanel account.'],
        'imap'      => ['IMAP', 'Any mailbox that offers IMAP (Yahoo, iCloud, Zoho, Bluehost, your own host): server, port 993 and an app password.'],
        'gmail'     => ['Gmail (app password)', 'Gmail or Google Workspace by IMAP with an app password: Google\'s 2-Step Verification must be on. A Workspace admin can block app passwords.'],
        'pop'       => ['POP', 'Only where IMAP isn\'t offered: the inbox only, no folders, and read state isn\'t sent back. A copy stays on the server.'],
        'microsoft' => ['Microsoft 365 or Outlook.com', 'Sign in with Microsoft. Microsoft no longer takes passwords for IMAP.'],
        'ses'       => ['An address received by Amazon SES', 'An address on one of our domains whose mail Amazon SES receives (no mail host needed).'],
    ];
    public const KEEP_DAYS = 90;
    public const HOSTS = ['gmail' => ['imap.gmail.com', 993, 'smtp.gmail.com', 587], 'outlook' => ['outlook.office365.com', 993, 'smtp.office365.com', 587],
                          'yahoo' => ['imap.mail.yahoo.com', 993, 'smtp.mail.yahoo.com', 587], 'icloud' => ['imap.mail.me.com', 993, 'smtp.mail.me.com', 587], 'zoho' => ['imap.zoho.com', 993, 'smtp.zoho.com', 587]];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM comms_mailboxes LIMIT 0'); $pdo->query('SELECT 1 FROM comms_mail LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }
    private static function lib(string $f): void { require_once __DIR__ . '/' . $f; }

    private static function staging(): bool { try { self::lib('StagingGate.php'); return StagingGate::here(); } catch (Throwable) { return false; } }

    /** Gmail by "Sign in with Google" waits until revenue covers Google's yearly security assessment (No income, no expense). */
    public static function gmailGate(PDO $pdo): array
    {
        self::lib('EnvSettings.php');
        $cost = (float) (EnvSettings::value('GMAIL_ASSESSMENT_USD') ?: 15000);
        $rev = 0.0;
        try { self::lib('Operations.php'); $rev = (float) (Operations::costs($pdo)['revenue'] ?? 0); } catch (Throwable) {}
        $yearly = $rev * 12;
        $ok = $yearly >= $cost;
        return [$ok, $ok ? '' : 'Sign in with Google waits until a year\'s revenue (now about $' . number_format($yearly) . ') covers Google\'s yearly security assessment (about $' . number_format($cost) . '). Until then, connect Gmail with an app password.'];
    }

    // ---- who may see what --------------------------------------------------------------------------------------------------

    private static function isStaff(PDO $pdo, int $uid): ?array
    {
        try { $st = $pdo->prepare("SELECT * FROM " . Database::t('staff_accounts') . " WHERE user_id = ? AND status = 'active'"); $st->execute([$uid]); return $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable) { return null; }
    }

    /** The mailboxes this person reads in Pulse (active and pending, theirs or overseen). */
    public static function forUser(PDO $pdo, int $uid): array
    {
        if (!self::ready($pdo)) return [];
        self::lib('CommsSetup.php');
        $over = CommsSetup::oversees($pdo, $uid);
        $w = "(owner_type IN ('staff','user') AND owner_id = ?)"; $a = [$uid];
        if ($over) { $w .= " OR (owner_type = 'system' AND address IN (" . implode(',', array_fill(0, count($over), '?')) . '))'; $a = array_merge($a, $over); }
        $st = $pdo->prepare("SELECT id, owner_type, owner_id, label, address, provider, status, last_sync_at, last_error, approved_at FROM comms_mailboxes WHERE $w ORDER BY owner_type = 'system' DESC, address");
        $st->execute($a);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    private static function box(PDO $pdo, int $id): array
    {
        $st = $pdo->prepare('SELECT * FROM comms_mailboxes WHERE id = ?'); $st->execute([$id]);
        $b = $st->fetch(PDO::FETCH_ASSOC);
        if (!$b) throw new InvalidArgumentException('That mailbox isn\'t connected.');
        return $b;
    }

    /** The mailbox, if this person may read it. */
    public static function mine(PDO $pdo, int $uid, int $id): array
    {
        foreach (self::forUser($pdo, $uid) as $b) if ((int) $b['id'] === $id) return self::box($pdo, $id);
        throw new InvalidArgumentException('That mailbox isn\'t one you read.');
    }

    // ---- connecting ---------------------------------------------------------------------------------------------------------

    /**
     * Connects a mailbox. $in: provider, address, label, host, port, login, password, smtp_host, smtp_port. $ownerType 'staff'
     * (their own; an outside one waits for their manager's approval), or 'system' (one of ours, owner-level, read by its
     * overseers). Signs in first (Check) so a wrong password shows at once. Returns [id, what to say].
     */
    public static function connect(PDO $pdo, int $by, string $ownerType, array $in): array
    {
        if (!self::ready($pdo)) throw new InvalidArgumentException('Mailboxes in Pulse switch on once the site\'s update has run.');
        if (self::staging()) throw new RuntimeException('Staging never connects to a mailbox: do it on the live site.');
        $prov = (string) ($in['provider'] ?? '');
        if (!isset(self::PROVIDERS[$prov])) throw new InvalidArgumentException('Choose what kind of mailbox it is.');
        if (in_array($prov, ['microsoft'], true)) throw new InvalidArgumentException('Use Sign in with Microsoft for that one.');
        $addr = strtolower(trim((string) ($in['address'] ?? '')));
        if (!filter_var($addr, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Write the mailbox\'s whole address.');
        if (!in_array($ownerType, ['staff', 'system'], true)) throw new InvalidArgumentException('Mailboxes for businesses and members come with the App store (coming).');
        $staff = self::isStaff($pdo, $by);
        if (!$staff) throw new InvalidArgumentException('Only staff connect mailboxes for now.');
        $c = self::settingsFor($prov, $addr, $in);
        $pw = (string) ($in['password'] ?? '');
        if ($prov === 'ses') {
            $dom = explode('@', $addr)[1];
            self::lib('CommsSetup.php');
            if (!in_array($dom, array_keys(CommsSetup::DOMAINS), true) && !in_array($dom, ['traversence.com', 'trvgo.us'], true)) throw new InvalidArgumentException('Amazon SES receives only for our own domains here.');
        } else {
            if ($pw === '') throw new InvalidArgumentException('Type the mailbox\'s password (for Gmail, Yahoo and iCloud: an app password).');
            $why = self::check($prov, $c + ['password' => $pw]);
            if ($why !== '') throw new InvalidArgumentException($why);
        }
        $ownerId = $ownerType === 'staff' ? $by : 0;
        $outside = $ownerType === 'staff' && $prov !== 'cpanel';
        $status = $outside ? 'pending' : 'active';
        self::lib('CommsCrypt.php');
        $pdo->prepare('INSERT INTO comms_mailboxes (owner_type, owner_id, label, address, provider, host, port, login, secret, smtp_host, smtp_port, status, made_by, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE provider = VALUES(provider), host = VALUES(host), port = VALUES(port), login = VALUES(login), secret = VALUES(secret), smtp_host = VALUES(smtp_host),
                       smtp_port = VALUES(smtp_port), status = IF(status = \'active\' AND VALUES(status) = \'pending\', status, VALUES(status)), last_error = \'\', updated_at = VALUES(updated_at)')
            ->execute([$ownerType, $ownerId, mb_substr(trim((string) ($in['label'] ?? '')) ?: $addr, 0, 80), $addr, $prov, $c['host'], $c['port'], $c['login'], $pw !== '' ? CommsCrypt::seal($pw) : null,
                $c['smtp_host'], $c['smtp_port'], $status, $by, self::now(), self::now()]);
        $st = $pdo->prepare('SELECT id, status FROM comms_mailboxes WHERE owner_type = ? AND owner_id = ? AND address = ?'); $st->execute([$ownerType, $ownerId, $addr]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        self::lib('CommsSetup.php');
        CommsSetup::log($pdo, $by, 'mailbox_connected', $addr, $prov . ($row['status'] === 'pending' ? ', waiting for a manager' : ''));
        if ($row['status'] === 'pending') { self::askManager($pdo, (int) $row['id'], $staff, $addr); return [(int) $row['id'], 'Signed in. ' . $addr . ' waits for your manager\'s OK; they\'ve been told, and it shows in your inbox once they approve.']; }
        return [(int) $row['id'], 'Connected: ' . $addr . '. Its mail comes into your Pulse within a few minutes.'];
    }

    /** A provider's server settings: known hosts filled in, else what was typed. */
    private static function settingsFor(string $prov, string $addr, array $in): array
    {
        $dom = explode('@', $addr)[1];
        $c = ['host' => trim((string) ($in['host'] ?? '')), 'port' => (int) ($in['port'] ?? 0), 'login' => trim((string) ($in['login'] ?? '')) ?: $addr,
              'smtp_host' => trim((string) ($in['smtp_host'] ?? '')), 'smtp_port' => (int) ($in['smtp_port'] ?? 0), 'address' => $addr];
        if ($prov === 'gmail') [$c['host'], $c['port'], $c['smtp_host'], $c['smtp_port']] = self::HOSTS['gmail'];
        if ($prov === 'cpanel') {   // our own: Bluehost's mail server is the one the site sends through
            $h = getenv('SMTP_HOST') ?: ('mail.' . $dom);
            $c['host'] = $c['host'] ?: $h; $c['port'] = $c['port'] ?: 993; $c['smtp_host'] = $c['smtp_host'] ?: $h; $c['smtp_port'] = $c['smtp_port'] ?: 587;
        }
        if (in_array($prov, ['imap', 'pop'], true)) {
            foreach (self::HOSTS as $k => $h) if (str_contains($dom, $k === 'outlook' ? 'outlook.' : $k . '.')) { if ($c['host'] === '') [$c['host'], , $c['smtp_host'], $c['smtp_port']] = $h; }
            if ($c['host'] === '') throw new InvalidArgumentException('Write the mail server (for example imap.example.com).');
            $c['port'] = $c['port'] ?: ($prov === 'pop' ? 995 : 993);
            $c['smtp_host'] = $c['smtp_host'] ?: preg_replace('/^(imap|pop3?|mail)\./', 'smtp.', $c['host']);
            $c['smtp_port'] = $c['smtp_port'] ?: 587;
        }
        if ($c['port'] < 0 || $c['port'] > 65535 || $c['smtp_port'] < 0 || $c['smtp_port'] > 65535) throw new InvalidArgumentException('A port is a number up to 65535.');
        return $c;
    }

    /** Signs in without changing anything: '' or the exact refusal. */
    public static function check(string $prov, array $c): string
    {
        try {
            if ($prov === 'pop') { self::lib('MailPop.php'); return MailPop::check($c); }
            self::lib('MailImap.php'); return MailImap::check($c);
        } catch (Throwable $e) { return $e->getMessage(); }
    }

    /** An outside mailbox for a staff member waits for their manager (Jason, 2026-11-18). */
    private static function askManager(PDO $pdo, int $id, array $staff, string $addr): void
    {
        self::lib('Workspaces.php');
        [$lv, $dept] = Workspaces::levelOf($staff);
        $rank = ['staff' => 0, 'manager' => 1, 'director' => 2, 'executive' => 3, 'founder' => 4];
        $to = [];
        foreach ($pdo->query("SELECT * FROM " . Database::t('staff_accounts') . " WHERE status = 'active' AND user_id IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC) as $s) {
            [$l, $d] = Workspaces::levelOf($s);
            if ((int) $s['user_id'] !== (int) $staff['user_id'] && ($rank[$l] ?? 0) > ($rank[$lv] ?? 0) && ($d === $dept || $dept === '' || in_array($l, ['executive', 'founder'], true))) $to[$l][] = (int) $s['user_id'];
        }
        $first = [];
        foreach (['manager', 'director', 'executive', 'founder'] as $l) if (!empty($to[$l])) { $first = $to[$l]; break; }
        if (!$first) return;
        self::lib('Notify.php');
        Notify::send($pdo, 'mailbox.reconnect', ['staff' => $first], ['thing' => 'mbapprove:' . $id, 'url' => '/admin/dashboard/inbox', 'from' => ['user', (int) $staff['user_id'], (string) $staff['name']]],
            ['title' => $staff['name'] . ' asks to read ' . $addr . ' in Pulse', 'body' => 'An outside mailbox for staff needs their manager\'s OK. Approve or decline it inside this message.']);
    }

    public static function approve(PDO $pdo, int $by, int $id, bool $yes): string
    {
        $b = self::box($pdo, $id);
        if ($b['status'] !== 'pending') return 'Already ' . ($b['status'] === 'active' ? 'approved.' : $b['status'] . '.');
        $me = self::isStaff($pdo, $by);
        if (!$me || (int) $b['owner_id'] === $by) throw new InvalidArgumentException('Their manager approves it, not the person asking.');
        self::lib('Workspaces.php');
        if (Workspaces::levelOf($me)[0] === 'staff') throw new InvalidArgumentException('Only a Manager or above approves an outside mailbox.');
        if ($yes) $pdo->prepare("UPDATE comms_mailboxes SET status = 'active', approved_by = ?, approved_at = ?, updated_at = ? WHERE id = ?")->execute([$by, self::now(), self::now(), $id]);
        else self::disconnect($pdo, (int) $b['owner_id'], $id, true);
        self::lib('CommsSetup.php');
        CommsSetup::log($pdo, $by, $yes ? 'mailbox_approved' : 'mailbox_declined', (string) $b['address']);
        self::lib('Notify.php');
        Notify::send($pdo, 'mailbox.reconnect', ['staff' => [(int) $b['owner_id']]], ['thing' => 'mbapproved:' . $id . ':' . ($yes ? 1 : 0), 'url' => '/admin/dashboard/inbox', 'from' => ['system', null, 'Mailboxes']],
            ['title' => $b['address'] . ($yes ? ' is approved' : ' was declined'), 'body' => $yes ? 'Its mail comes into your Pulse inbox within a few minutes.' : 'Your manager declined reading it in Pulse; its password was removed.']);
        return $yes ? 'Approved: ' . $b['address'] . ' comes into their inbox.' : 'Declined; the password was removed.';
    }

    /** Sign in with Microsoft finished (/api/ms-mail.php): the mailbox, with its sealed tokens. */
    public static function connectMicrosoft(PDO $pdo, int $by, array $tok): array
    {
        if (!self::isStaff($pdo, $by)) throw new InvalidArgumentException('Only staff connect mailboxes for now.');
        $addr = strtolower((string) ($tok['address'] ?? ''));
        if (!filter_var($addr, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Microsoft didn\'t say which mailbox signed in.');
        self::lib('CommsCrypt.php');
        $pdo->prepare("INSERT INTO comms_mailboxes (owner_type, owner_id, label, address, provider, secret, status, made_by, created_at, updated_at) VALUES ('staff', ?, ?, ?, 'microsoft', ?, 'pending', ?, ?, ?)
                       ON DUPLICATE KEY UPDATE secret = VALUES(secret), last_error = '', status = IF(status = 'failed', IF(approved_at IS NULL, 'pending', 'active'), status), updated_at = VALUES(updated_at)")
            ->execute([$by, $addr, $addr, CommsCrypt::seal(json_encode($tok)), $by, self::now(), self::now()]);
        $st = $pdo->prepare("SELECT id, status FROM comms_mailboxes WHERE owner_type = 'staff' AND owner_id = ? AND address = ?"); $st->execute([$by, $addr]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if ($row['status'] === 'pending') self::askManager($pdo, (int) $row['id'], (array) self::isStaff($pdo, $by), $addr);
        return [(int) $row['id'], $row['status'] === 'pending' ? 'Signed in with Microsoft. ' . $addr . ' waits for your manager\'s OK.' : 'Reconnected: ' . $addr . '.'];
    }

    /** Reconnect: a new password (or app password) for a mailbox that refused its old one. */
    public static function reconnect(PDO $pdo, int $uid, int $id, string $pw): string
    {
        $b = self::mine($pdo, $uid, $id);
        if ($b['provider'] === 'microsoft') throw new InvalidArgumentException('Sign in with Microsoft again to reconnect it.');
        if ($b['owner_type'] === 'system') throw new InvalidArgumentException('One of our mailboxes: an owner resets it in System Configuration → Communications.');
        $why = self::check((string) $b['provider'], self::conf($b) + ['password' => $pw]);
        if ($why !== '') throw new InvalidArgumentException($why);
        self::lib('CommsCrypt.php');
        $pdo->prepare("UPDATE comms_mailboxes SET secret = ?, status = IF(approved_at IS NULL AND owner_type = 'staff' AND provider <> 'cpanel', 'pending', 'active'), last_error = '', updated_at = ? WHERE id = ?")->execute([CommsCrypt::seal($pw), self::now(), $id]);
        return 'Reconnected: ' . $b['address'] . '.';
    }

    /** Disconnect: our copy of its mail and its sealed password are deleted; the mailbox itself is untouched. */
    public static function disconnect(PDO $pdo, int $uid, int $id, bool $force = false): string
    {
        $b = $force ? self::box($pdo, $id) : self::mine($pdo, $uid, $id);
        if (!$force && $b['owner_type'] === 'system') throw new InvalidArgumentException('One of our mailboxes: an owner disconnects it in System Configuration → Communications.');
        $pdo->prepare('DELETE FROM comms_mail WHERE mailbox_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM comms_mailboxes WHERE id = ?')->execute([$id]);
        self::lib('CommsSetup.php');
        CommsSetup::log($pdo, $uid, 'mailbox_disconnected', (string) $b['address']);
        return 'Disconnected: our copy of ' . $b['address'] . '\'s mail and its password are deleted. The mailbox itself is as it was.';
    }

    private static function conf(array $b): array
    {
        return ['host' => (string) $b['host'], 'port' => (int) $b['port'], 'login' => (string) $b['login'], 'address' => (string) $b['address'], 'smtp_host' => (string) $b['smtp_host'], 'smtp_port' => (int) $b['smtp_port']];
    }

    private static function secret(array $b): string
    {
        self::lib('CommsCrypt.php');
        return $b['secret'] ? CommsCrypt::open((string) $b['secret']) : '';
    }

    // ---- reading the mailbox (sync) -------------------------------------------------------------------------------------------

    /** The mail_sync job: every active mailbox not synced for 4 minutes. Returns new messages stored. */
    public static function syncAll(PDO $pdo, int $budgetSeconds = 50): int
    {
        if (!self::ready($pdo) || self::staging()) return 0;
        $end = time() + $budgetSeconds; $n = 0;
        $st = $pdo->prepare("SELECT id FROM comms_mailboxes WHERE status = 'active' AND provider <> 'ses' AND (last_sync_at IS NULL OR last_sync_at < ?) ORDER BY last_sync_at LIMIT 30");
        $st->execute([date('Y-m-d H:i:s', time() - 240)]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) { if (time() > $end) break; $n += self::sync($pdo, (int) $id); }
        return $n;
    }

    /** When the person opens their inbox: their mailboxes not synced for a minute, within a few seconds. */
    public static function syncFor(PDO $pdo, int $uid, int $budgetSeconds = 8): void
    {
        if (self::staging()) return;
        $end = time() + $budgetSeconds;
        foreach (self::forUser($pdo, $uid) as $b) {
            if (time() > $end) break;
            if ($b['status'] !== 'active' || $b['provider'] === 'ses' || ($b['last_sync_at'] && strtotime((string) $b['last_sync_at']) > time() - 60)) continue;
            self::sync($pdo, (int) $b['id'], 25);
        }
    }

    /** One mailbox: new mail stored, read state brought in. On a refusal, the mailbox is marked and its people told. */
    public static function sync(PDO $pdo, int $id, int $max = 50): int
    {
        $b = self::box($pdo, $id);
        $pdo->prepare('UPDATE comms_mailboxes SET last_sync_at = ? WHERE id = ?')->execute([self::now(), $id]);
        try {
            $n = match ((string) $b['provider']) {
                'microsoft' => self::syncGraph($pdo, $b, $max),
                'pop' => self::syncPop($pdo, $b, $max),
                'ses' => 0,
                default => self::syncImap($pdo, $b, $max),
            };
            if ($b['last_error'] !== '') $pdo->prepare("UPDATE comms_mailboxes SET last_error = '', status = 'active' WHERE id = ?")->execute([$id]);
            return $n;
        } catch (Throwable $e) {
            self::failed($pdo, $b, $e->getMessage());
            return 0;
        }
    }

    private static function syncImap(PDO $pdo, array $b, int $max): int
    {
        $pw = self::secret($b);
        if ($pw === '') throw new RuntimeException('Its password can\'t be read any more: reconnect it.');
        self::lib('MailImap.php'); self::lib('MailMime.php');
        $im = new MailImap(self::conf($b) + ['password' => $pw]);
        $im->login();
        $sel = $im->select('INBOX');
        [$validity, $last] = array_pad(explode(':', (string) $b['sync_mark']), 2, '0');
        $first = $validity === '' || $validity === '0' || (string) $sel['uidvalidity'] !== $validity;
        $uids = $first ? array_slice($im->uidsSince(14), -$max) : $im->uidsAfter((int) $last, $max);
        $n = 0; $top = $first ? 0 : (int) $last;
        foreach (array_chunk($uids, 10) as $chunk) {
            foreach ($im->fetch($chunk) as $f) {
                $p = MailMime::parse((string) $f['raw']);
                if (self::store($pdo, (int) $b['id'], 'INBOX', (string) $f['uid'], $p, in_array('\\Seen', (array) $f['flags'], true), 'in', in_array('\\Flagged', (array) $f['flags'], true))) $n++;
                $top = max($top, (int) $f['uid']);
            }
        }
        // read state from the mailbox for what we hold of the last days (both ways: Pulse writes it back as it's read)
        if (!$first) {
            $st = $pdo->prepare("SELECT uid FROM comms_mail WHERE mailbox_id = ? AND folder = 'INBOX' AND seen = 0 ORDER BY id DESC LIMIT 100"); $st->execute([$b['id']]);
            $unseen = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
            if ($unseen) foreach ($im->flagsOf($unseen) as $uid => $flags) if (in_array('\\Seen', $flags, true)) $pdo->prepare("UPDATE comms_mail SET seen = 1 WHERE mailbox_id = ? AND folder = 'INBOX' AND uid = ?")->execute([$b['id'], (string) $uid]);
        }
        $im->logout();
        $pdo->prepare('UPDATE comms_mailboxes SET sync_mark = ? WHERE id = ?')->execute([$sel['uidvalidity'] . ':' . $top, $b['id']]);
        return $n;
    }

    private static function syncPop(PDO $pdo, array $b, int $max): int
    {
        $pw = self::secret($b);
        if ($pw === '') throw new RuntimeException('Its password can\'t be read any more: reconnect it.');
        self::lib('MailPop.php'); self::lib('MailMime.php');
        $pop = new MailPop(self::conf($b) + ['password' => $pw]);
        $pop->login();
        $have = [];
        $st = $pdo->prepare('SELECT uid FROM comms_mail WHERE mailbox_id = ?'); $st->execute([$b['id']]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $u) $have[(string) $u] = true;
        $n = 0;
        foreach (array_reverse($pop->uidl(), true) as $num => $uid) {
            if (isset($have[(string) $uid])) continue;
            if ($n >= $max) break;
            if (self::store($pdo, (int) $b['id'], 'INBOX', (string) $uid, MailMime::parse($pop->retr((int) $num)), false)) $n++;
        }
        $pop->quit();
        return $n;
    }

    private static function syncGraph(PDO $pdo, array $b, int $max): int
    {
        self::lib('MsGraphMail.php');
        $tok = json_decode(self::secret($b), true);
        if (!is_array($tok)) throw new RuntimeException('Microsoft\'s sign-in for ' . $b['address'] . ' can\'t be read: reconnect it.');
        $before = json_encode($tok);
        $since = $b['sync_mark'] !== '' ? (string) $b['sync_mark'] : gmdate('Y-m-d\TH:i:s\Z', time() - 14 * 86400);
        $list = MsGraphMail::list($tok, $since);
        if (json_encode($tok) !== $before) { self::lib('CommsCrypt.php'); $pdo->prepare('UPDATE comms_mailboxes SET secret = ? WHERE id = ?')->execute([CommsCrypt::seal(json_encode($tok)), $b['id']]); }
        $n = 0; $mark = $since;
        foreach (array_slice($list, 0, $max) as $p) {
            if (self::store($pdo, (int) $b['id'], 'INBOX', (string) $p['uid'], $p, !empty($p['seen']))) $n++;
            if ($p['date']) $mark = max($mark, gmdate('Y-m-d\TH:i:s\Z', (int) $p['date']));
        }
        $pdo->prepare('UPDATE comms_mailboxes SET sync_mark = ? WHERE id = ?')->execute([$mark, $b['id']]);
        return $n;
    }

    /** A mailbox refused: marked failed, its people told once a day with Reconnect in the message. */
    private static function failed(PDO $pdo, array $b, string $why): void
    {
        $why = mb_substr(trim($why), 0, 250);
        $pdo->prepare("UPDATE comms_mailboxes SET status = 'failed', last_error = ?, updated_at = ? WHERE id = ?")->execute([$why, self::now(), $b['id']]);
        self::lib('CommsSetup.php'); self::lib('Notify.php');
        $to = $b['owner_type'] === 'system' ? (CommsSetup::overseersOf($pdo, (string) $b['address']) ?: CommsSetup::founders($pdo)) : [(int) $b['owner_id']];
        Notify::send($pdo, 'mailbox.reconnect', [$b['owner_type'] === 'user' ? 'users' : 'staff' => $to], ['thing' => 'mbfail:' . $b['id'] . ':' . date('Ymd'), 'url' => '/admin/dashboard/inbox', 'from' => ['system', null, 'Mailboxes']],
            ['title' => $b['address'] . ' needs reconnecting', 'body' => $why]);
    }

    /**
     * Stores one message in our working copy. Returns true when it's new. Mail to requests@ (plus-addressed replies, and
     * bounces) is handed to the listing messages it answers (decisions/0172 §3.3).
     */
    public static function store(PDO $pdo, int $mailboxId, string $folder, string $uid, array $p, bool $seen, string $dir = 'in', bool $flagged = false, string $thread = ''): bool
    {
        self::lib('MailMime.php');
        $text = (string) ($p['text'] ?? '');
        $ins = $pdo->prepare('INSERT IGNORE INTO comms_mail (mailbox_id, folder, uid, msg_id, thread_key, direction, from_addr, from_name, to_list, cc_list, subject, sent_at, snippet, body_text, body_html, attach, seen, flagged, created_at)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $ins->execute([$mailboxId, mb_substr($folder, 0, 60), mb_substr($uid, 0, 190), mb_substr((string) ($p['message_id'] ?? ''), 0, 255), $thread !== '' ? $thread : (!empty($p['thread']) ? sha1('graph|' . $p['thread']) : MailMime::threadKey($p)), $dir,
            mb_substr(strtolower((string) ($p['from']['addr'] ?? ($p['from'][0] ?? ''))), 0, 190), mb_substr((string) ($p['from']['name'] ?? ($p['from'][1] ?? '')), 0, 120),
            json_encode($p['to'] ?? []), json_encode($p['cc'] ?? []), mb_substr((string) ($p['subject'] ?? ''), 0, 255),
            !empty($p['date']) ? date('Y-m-d H:i:s', (int) $p['date']) : self::now(), mb_substr(MailMime::snippet($text, 200), 0, 300), mb_substr($text, 0, 200000),
            mb_substr((string) ($p['html'] ?? ''), 0, 400000), json_encode($p['attachments'] ?? []), $seen ? 1 : 0, $flagged ? 1 : 0, self::now()]);
        $new = $ins->rowCount() > 0;
        if ($new && $dir === 'in') self::route($pdo, $mailboxId, $p);
        return $new;
    }

    /** Mail that answers something of ours: a listing request's reply (requests+r…@), or a bounce of one. */
    private static function route(PDO $pdo, int $mailboxId, array $p): void
    {
        $tos = array_map(fn ($t) => strtolower((string) ($t['addr'] ?? ($t[0] ?? ''))), (array) ($p['to'] ?? []));
        $from = strtolower((string) ($p['from']['addr'] ?? ''));
        try {
            if (!is_file(__DIR__ . '/ListingMessages.php')) return;
            self::lib('ListingMessages.php');
            foreach ($tos as $to) if (preg_match('/^requests\+r\d+-[a-f0-9]{16}@/', $to)) { ListingMessages::emailReply($pdo, $to, $p); return; }
            if (preg_match('/^(mailer-daemon|postmaster)@/', $from) && preg_match('/requests@/i', (string) ($p['text'] ?? '')) && preg_match_all('/[\w.+-]+@[\w-]+\.[\w.-]+/', (string) ($p['text'] ?? ''), $mm)) {
                foreach (array_unique($mm[0]) as $a) if (!preg_match('/^(requests|mailer-daemon|postmaster)/i', $a)) ListingMessages::bounced($pdo, strtolower($a));
            }
        } catch (Throwable $e) { error_log('mailboxes route: ' . $e->getMessage()); }
    }

    /** The mail_keep job: our working copy keeps 90 days. */
    public static function purge(PDO $pdo): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->prepare('DELETE FROM comms_mail WHERE COALESCE(sent_at, created_at) < ? LIMIT 5000'); $st->execute([date('Y-m-d H:i:s', time() - self::KEEP_DAYS * 86400)]);
        return $st->rowCount();
    }

    // ---- the inbox in Pulse ------------------------------------------------------------------------------------------------------

    /** This person's mail, one row per conversation, newest first. $box: one mailbox only; $q: search; $view: inbox|sent|all. */
    public static function inbox(PDO $pdo, int $uid, int $box = 0, string $q = '', int $limit = 50, string $view = 'inbox'): array
    {
        $boxes = self::forUser($pdo, $uid);
        $ids = array_map(fn ($b) => (int) $b['id'], array_filter($boxes, fn ($b) => $b['status'] !== 'pending'));
        if ($box) $ids = array_values(array_intersect($ids, [$box]));
        if (!$ids) return ['boxes' => $boxes, 'rows' => []];
        $w = 'mailbox_id IN (' . implode(',', $ids) . ')'; $a = [];
        if ($view === 'inbox') $w .= " AND direction = 'in' AND folder = 'INBOX'";
        elseif ($view === 'sent') $w .= " AND direction = 'out'";
        if ($q !== '') { $w .= ' AND (subject LIKE ? OR from_addr LIKE ? OR from_name LIKE ? OR body_text LIKE ?)'; $a = array_fill(0, 4, '%' . $q . '%'); }
        if ($bl = self::blockedFor($pdo, $uid)) { $w .= " AND (direction = 'out' OR LOWER(from_addr) NOT IN (" . implode(',', array_fill(0, count($bl), '?')) . '))'; $a = array_merge($a, $bl); }   // senders this person blocked: theirs only
        $st = $pdo->prepare("SELECT m.id, m.mailbox_id, m.thread_key, m.from_addr, m.from_name, m.subject, m.sent_at, m.snippet, m.seen, m.flagged, m.attach, m.direction, x.n, x.unread
                              FROM comms_mail m JOIN (SELECT thread_key, MAX(id) AS last, COUNT(*) AS n, SUM(seen = 0 AND direction = 'in') AS unread FROM comms_mail WHERE $w GROUP BY thread_key) x ON x.last = m.id
                              ORDER BY m.sent_at DESC LIMIT " . max(1, min(200, $limit)));
        $st->execute($a);
        $label = array_column($boxes, 'address', 'id');
        $rows = array_map(fn ($r) => ['id' => (int) $r['id'], 'box' => (int) $r['mailbox_id'], 'mailbox' => (string) ($label[$r['mailbox_id']] ?? ''), 'from' => (string) ($r['from_name'] ?: $r['from_addr']),
            'from_addr' => (string) $r['from_addr'], 'subject' => (string) $r['subject'], 'when' => (string) $r['sent_at'], 'snippet' => (string) $r['snippet'], 'unread' => (int) $r['unread'] > 0,
            'flagged' => (bool) $r['flagged'], 'count' => (int) $r['n'], 'attach' => count((array) json_decode((string) $r['attach'], true)) > 0, 'item' => 'mail:' . (int) $r['id']], $st->fetchAll(PDO::FETCH_ASSOC));
        return ['boxes' => $boxes, 'rows' => $rows];
    }

    /** One conversation, opened in place: each message shown safely; read state written back to the mailbox. */
    public static function thread(PDO $pdo, int $uid, int $mailId, bool $pictures = false): array
    {
        $st = $pdo->prepare('SELECT * FROM comms_mail WHERE id = ?'); $st->execute([$mailId]);
        $m = $st->fetch(PDO::FETCH_ASSOC);
        if (!$m) throw new InvalidArgumentException('That email isn\'t here any more.');
        $b = self::mine($pdo, $uid, (int) $m['mailbox_id']);
        $st = $pdo->prepare('SELECT * FROM comms_mail WHERE mailbox_id = ? AND thread_key = ? ORDER BY sent_at, id LIMIT 50'); $st->execute([$m['mailbox_id'], $m['thread_key']]);
        $all = $st->fetchAll(PDO::FETCH_ASSOC);
        self::lib('MailMime.php');
        $out = [];
        foreach ($all as $r) {
            $out[] = ['id' => (int) $r['id'], 'from' => (string) $r['from_name'], 'from_addr' => (string) $r['from_addr'], 'to' => (array) json_decode((string) $r['to_list'], true),
                'cc' => (array) json_decode((string) $r['cc_list'], true), 'when' => (string) $r['sent_at'], 'subject' => (string) $r['subject'], 'direction' => (string) $r['direction'],
                'html' => (string) $r['body_html'] !== '' ? MailMime::safeHtml((string) $r['body_html'], $pictures) : '', 'text' => (string) $r['body_text'],
                'held_pictures' => !$pictures && preg_match('/<img[^>]+src=["\']?https?:/i', (string) $r['body_html']), 'attach' => (array) json_decode((string) $r['attach'], true)];
            if (!(int) $r['seen'] && $r['direction'] === 'in') self::setSeen($pdo, $b, $r, true);
        }
        return ['mailbox' => ['id' => (int) $b['id'], 'address' => (string) $b['address'], 'provider' => (string) $b['provider']], 'messages' => $out,
            'from_choices' => array_values(array_map(fn ($x) => ['id' => (int) $x['id'], 'address' => (string) $x['address']], array_filter(self::forUser($pdo, $uid), fn ($x) => $x['status'] === 'active')))];
    }

    /** Read or unread, here and in the mailbox (POP can't take it back; SES has no mailbox). */
    public static function setSeen(PDO $pdo, array $b, array $r, bool $on): void
    {
        $pdo->prepare('UPDATE comms_mail SET seen = ? WHERE id = ?')->execute([$on ? 1 : 0, $r['id']]);
        if (self::staging()) return;
        try {
            if ($b['provider'] === 'microsoft') { self::lib('MsGraphMail.php'); $tok = json_decode(self::secret($b), true); if (is_array($tok)) MsGraphMail::markRead($tok, (string) $r['uid'], $on); return; }
            if (in_array($b['provider'], ['pop', 'ses'], true)) return;
            self::lib('MailImap.php');
            $im = new MailImap(self::conf($b) + ['password' => self::secret($b)]);
            $im->login(); $im->select((string) $r['folder']); $im->setSeen((int) $r['uid'], $on); $im->logout();
        } catch (Throwable $e) { error_log('mailboxes seen: ' . $e->getMessage()); }
    }

    /** The row's Read/unread, Flag and File (to the mailbox's own Archive or Junk folder). */
    public static function act(PDO $pdo, int $uid, int $mailId, string $what): string
    {
        $st = $pdo->prepare('SELECT * FROM comms_mail WHERE id = ?'); $st->execute([$mailId]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That email isn\'t here any more.');
        $b = self::mine($pdo, $uid, (int) $r['mailbox_id']);
        switch ($what) {
            case 'read': self::setSeen($pdo, $b, $r, true); return 'Marked read.';
            case 'unread': self::setSeen($pdo, $b, $r, false); return 'Marked unread.';
            case 'archive': case 'junk':
                $pdo->prepare('UPDATE comms_mail SET folder = ? WHERE id = ?')->execute([$what === 'junk' ? 'Junk' : 'Archive', $mailId]);
                if (!self::staging() && in_array($b['provider'], ['imap', 'gmail', 'cpanel'], true)) {
                    try { self::lib('MailImap.php'); $im = new MailImap(self::conf($b) + ['password' => self::secret($b)]); $im->login(); $im->select('INBOX');
                        $target = $im->special($what === 'junk' ? 'Junk' : 'Archive'); if ($target !== '') $im->move((int) $r['uid'], $target); $im->logout(); }
                    catch (Throwable $e) { return 'Moved here; the mailbox didn\'t take the move (' . mb_substr($e->getMessage(), 0, 120) . ').'; }
                }
                if (!self::staging() && $b['provider'] === 'microsoft') { try { self::lib('MsGraphMail.php'); $tok = json_decode(self::secret($b), true); MsGraphMail::move($tok, (string) $r['uid'], $what === 'junk' ? 'junkemail' : 'archive'); } catch (Throwable $e) { error_log('graph move: ' . $e->getMessage()); } }
                return $what === 'junk' ? 'Moved to Junk.' : 'Archived.';
            default: throw new InvalidArgumentException('Unknown action.');
        }
    }

    /**
     * Sends from one of this person's mailboxes (a reply goes from the mailbox the message came to unless they pick another,
     * 0167 §2a). $in: from (mailbox id), to, cc, subject, text, reply_to (a comms_mail id), all (Reply all). Kept in that
     * mailbox's Sent folder, and in our copy as sent.
     */
    public static function send(PDO $pdo, int $uid, array $in): string
    {
        if (self::staging()) throw new RuntimeException('Staging never sends from a mailbox.');
        $b = self::mine($pdo, $uid, (int) ($in['from'] ?? 0));
        if ($b['status'] !== 'active') throw new InvalidArgumentException($b['address'] . ' isn\'t connected right now: reconnect it first.');
        $addrs = function ($s): array { $out = []; foreach (preg_split('/[,;]+/', (string) $s) as $a) { $a = trim($a); if ($a === '') continue; if (!filter_var($a, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException($a . ' isn\'t an email address.'); $out[] = [$a, '']; } return $out; };
        $to = $addrs($in['to'] ?? ''); $cc = $addrs($in['cc'] ?? '');
        if (!$to) throw new InvalidArgumentException('Who is it to?');
        if (count($to) + count($cc) > 20) throw new InvalidArgumentException('Up to 20 people at a time.');
        $text = trim((string) ($in['text'] ?? ''));
        if ($text === '') throw new InvalidArgumentException('Write something first.');
        $subject = trim((string) ($in['subject'] ?? ''));
        $refs = []; $irt = ''; $o = null;
        if (!empty($in['reply_to'])) {
            $st = $pdo->prepare('SELECT * FROM comms_mail WHERE id = ?'); $st->execute([(int) $in['reply_to']]);
            if ($o = $st->fetch(PDO::FETCH_ASSOC)) {
                self::mine($pdo, $uid, (int) $o['mailbox_id']);
                $irt = (string) $o['msg_id']; $refs = $irt !== '' ? [$irt] : [];
                if ($subject === '') $subject = preg_match('/^re:/i', (string) $o['subject']) ? (string) $o['subject'] : 'Re: ' . $o['subject'];
            }
        }
        self::lib('MailMime.php');
        $msg = ['from' => [(string) $b['address'], self::senderName($pdo, $uid)], 'to' => $to, 'cc' => $cc, 'subject' => $subject ?: '(no subject)', 'text' => $text, 'in_reply_to' => $irt, 'references' => $refs];
        $raw = MailMime::build($msg);
        switch ($b['provider']) {
            case 'microsoft':
                self::lib('MsGraphMail.php'); $tok = json_decode(self::secret($b), true);
                MsGraphMail::send($tok, $msg + ($o && (int) $o['mailbox_id'] === (int) $b['id'] ? ['reply_to_graph_id' => (string) $o['uid']] : []));
                self::lib('CommsCrypt.php'); $pdo->prepare('UPDATE comms_mailboxes SET secret = ? WHERE id = ?')->execute([CommsCrypt::seal(json_encode($tok)), $b['id']]);
                break;
            case 'ses':
                self::lib('SesMail.php');
                [$local, $dom] = explode('@', (string) $b['address'], 2);
                $r = SesMail::send($pdo, ['account' => 'personal', 'from_local' => $local, 'from_domain' => $dom, 'from_name' => $msg['from'][1], 'to' => $to[0][0], 'to_name' => '', 'subject' => $msg['subject'],
                    'text' => $text, 'html' => '', 'reply_to' => (string) $b['address'], 'sender' => 'traversence', 'purpose' => 'site_email', 'scope' => 'site_email', 'why' => 'A reply from ' . $b['address'] . '.']);
                if (($r['status'] ?? '') !== 'sent') throw new RuntimeException('Amazon SES didn\'t send it (' . (string) ($r['status'] ?? 'no answer') . ').');
                break;
            default:
                self::lib('MailSmtp.php');
                MailSmtp::send(['host' => (string) $b['smtp_host'], 'port' => (int) $b['smtp_port'], 'login' => (string) $b['login'], 'password' => self::secret($b)], (string) $b['address'], array_merge(array_column($to, 0), array_column($cc, 0)), $raw);
                if ($b['provider'] !== 'pop') { try { self::lib('MailImap.php'); $im = new MailImap(self::conf($b) + ['password' => self::secret($b)]); $im->login(); $sent = $im->special('Sent'); if ($sent !== '') $im->append($sent, $raw); $im->logout(); } catch (Throwable $e) { error_log('mailboxes sent copy: ' . $e->getMessage()); } }
        }
        $p = MailMime::parse($raw); $p['date'] = time();
        self::store($pdo, (int) $b['id'], 'Sent', 'out-' . bin2hex(random_bytes(8)), $p, true, 'out', false, $o ? (string) $o['thread_key'] : '');   // a reply stays in its conversation
        self::lib('Notify.php');
        try { $pdo->prepare('INSERT INTO comms_route (message_id, via, stage, detail, provider_id, happened_at, sender_key, addr_hash, subject, mail_kind) VALUES (0, \'mailbox\', \'sent\', ?, \'\', ?, ?, ?, ?, ?)')
            ->execute([mb_substr('From ' . $b['address'] . ' (' . $b['provider'] . ')', 0, 255), self::now(), 'mailbox', hash('sha256', strtolower($to[0][0])), mb_substr($msg['subject'], 0, 200), 'mailbox']); } catch (Throwable) {}
        return 'Sent from ' . $b['address'] . '.';
    }

    private static function senderName(PDO $pdo, int $uid): string
    {
        $st = $pdo->prepare('SELECT display_name FROM users WHERE id = ?'); $st->execute([$uid]);
        return (string) ($st->fetchColumn() ?: '');
    }

    // ---- the email row's own actions in Pulse (decisions/0172 §4.7; the row's icons) ---------------------------------------------

    public static function blocksReady(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM comms_mail_blocks LIMIT 0'); return true; } catch (Throwable) { return false; }
    }

    /** The senders this person blocked (lower case): their mail stops showing to them, nobody else; the sender isn't told. */
    public static function blockedFor(PDO $pdo, int $uid): array
    {
        if (!self::blocksReady($pdo)) return [];
        $st = $pdo->prepare('SELECT addr FROM comms_mail_blocks WHERE user_id = ?'); $st->execute([$uid]);
        return array_map('strval', $st->fetchAll(PDO::FETCH_COLUMN));
    }

    /** 🛡 Block the sender of this email (or unblock with $on false). The mail stays in the mailbox itself. */
    public static function blockSender(PDO $pdo, int $uid, int $mailId, bool $on = true): string
    {
        if (!self::blocksReady($pdo)) throw new RuntimeException('Blocking senders switches on once the site\'s update has run (within the hour).');
        $r = self::mailFor($pdo, $uid, $mailId);
        $addr = mb_strtolower(trim((string) $r['from_addr']));
        if ($addr === '' || !filter_var($addr, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email has no sender address to block.');
        if ($on) $pdo->prepare('INSERT IGNORE INTO comms_mail_blocks (user_id, addr, created_at) VALUES (?, ?, ?)')->execute([$uid, $addr, self::now()]);
        else $pdo->prepare('DELETE FROM comms_mail_blocks WHERE user_id = ? AND addr = ?')->execute([$uid, $addr]);
        return $on ? 'Blocked ' . $addr . ': their mail no longer shows in your Pulse (only yours; they aren\'t told).' : 'Unblocked ' . $addr . '.';
    }

    /** ↗ Forward this email from the mailbox it came to, with a note above it. */
    public static function forward(PDO $pdo, int $uid, int $mailId, string $to, string $note): string
    {
        $r = self::mailFor($pdo, $uid, $mailId);
        $text = trim($note) . "\n\n---------- Forwarded message ----------\nFrom: " . trim(($r['from_name'] ? $r['from_name'] . ' ' : '') . '<' . $r['from_addr'] . '>')
            . "\nDate: " . (string) $r['sent_at'] . "\nSubject: " . (string) $r['subject'] . "\n\n" . (string) $r['body_text'];
        $subject = preg_match('/^fwd?:/i', (string) $r['subject']) ? (string) $r['subject'] : 'Fwd: ' . $r['subject'];
        return self::send($pdo, $uid, ['from' => (int) $r['mailbox_id'], 'to' => $to, 'subject' => $subject, 'text' => ltrim($text)]);
    }

    /** One email, if this person reads its mailbox. */
    public static function mailFor(PDO $pdo, int $uid, int $mailId): array
    {
        $st = $pdo->prepare('SELECT * FROM comms_mail WHERE id = ?'); $st->execute([$mailId]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That email isn\'t here any more.');
        self::mine($pdo, $uid, (int) $r['mailbox_id']);
        return $r;
    }

    /**
     * 🛡 Report phishing: moves it to Junk (in the mailbox too) and tells our team: the people who read our own mailboxes
     * (System Configuration → Communications), with the email's sender, subject and words. Never the sender.
     */
    public static function reportPhishing(PDO $pdo, int $uid, int $mailId): string
    {
        $r = self::mailFor($pdo, $uid, $mailId);
        $moved = self::act($pdo, $uid, $mailId, 'junk');
        $team = [];
        try {
            self::lib('CommsSetup.php');
            foreach ($pdo->query("SELECT LOWER(address) FROM comms_mailboxes WHERE owner_type = 'system'")->fetchAll(PDO::FETCH_COLUMN) as $a) $team = array_merge($team, CommsSetup::overseersOf($pdo, (string) $a));
        } catch (Throwable) {}
        $team = array_values(array_unique(array_filter(array_map('intval', $team), fn ($x) => $x !== $uid)));
        if (!$team) return $moved . ' No one is set to read our mailboxes yet, so our team wasn\'t told: choose who in System Configuration → Communications.';
        self::lib('Notify.php');
        Notify::send($pdo, 'case.assigned', ['staff' => $team], ['thing' => 'phish:' . $mailId, 'url' => '/admin/dashboard/stream#mail', 'from' => ['staff', $uid, self::senderName($pdo, $uid) ?: 'A teammate']],
            ['title' => 'Phishing reported: ' . mb_substr((string) $r['subject'], 0, 150), 'body' => 'From ' . trim(($r['from_name'] ? $r['from_name'] . ' ' : '') . '<' . $r['from_addr'] . '>') . ': ' . mb_substr((string) $r['snippet'], 0, 400)]);
        return $moved . ' Our team was told.';
    }

    /** ⊕ The sender to the Address Book: when they're on Traversence, a connection request (People::connect); else why not. */
    public static function contactSender(PDO $pdo, int $uid, int $mailId): string
    {
        $r = self::mailFor($pdo, $uid, $mailId);
        $addr = mb_strtolower(trim((string) $r['from_addr']));
        $st = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1'); $st->execute([$addr]);
        $other = (int) $st->fetchColumn();
        if (!$other) throw new InvalidArgumentException($addr . ' isn\'t on Traversence, so there\'s no one to add: their address stays in the mailbox\'s own contacts.');
        self::lib('People.php');
        $how = People::connect($pdo, $uid, $other);
        return $how === 'connected' ? 'In your Address Book.' : 'Asked to connect: they\'re in your Address Book once they accept.';
    }

    /** Make it a case (⊕): an outside email becomes one of ours, with the email inside it. Returns the Pulse item key. */
    public static function makeCase(PDO $pdo, int $uid, int $mailId): string
    {
        $st = $pdo->prepare('SELECT * FROM comms_mail WHERE id = ?'); $st->execute([$mailId]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new InvalidArgumentException('That email isn\'t here any more.');
        self::mine($pdo, $uid, (int) $r['mailbox_id']);
        self::lib('Notify.php');
        Notify::send($pdo, 'case.assigned', ['staff' => [$uid]], ['thing' => 'mailcase:' . $mailId, 'url' => '/admin/dashboard/inbox#mail-' . $mailId, 'from' => ['system', null, 'Mailboxes']],
            ['title' => 'Case from email: ' . mb_substr((string) $r['subject'], 0, 150), 'body' => 'From ' . ($r['from_name'] ?: $r['from_addr']) . ': ' . (string) $r['snippet']]);
        return 'It\'s a case in your Pulse now, with the email linked; replies stay in the same thread.';
    }

    /** The message body for mailbox notices: Reconnect, or a manager's Approve / Decline (0172 "The message"). */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
        $thing = (string) $m['thing'];
        $btn = fn (string $label, array $body, string $cls = '', string $confirm = '') => '<button type="button" class="tv-btn' . $cls . '" data-msg-act="/user/api/mailboxes.php" data-msg-body=\'' . $e(json_encode($body + ['from_msg' => (int) $m['id']])) . '\'' . ($confirm !== '' ? ' data-confirm="' . $e($confirm) . '" data-yes="Decline" data-danger' : '') . '>' . $e($label) . '</button>';
        if (preg_match('/^mbapprove:(\d+)$/', $thing, $x)) {
            try { $b = self::box($pdo, (int) $x[1]); } catch (Throwable) { return ['html' => '<p>That request was withdrawn.</p>', 'state' => 'Withdrawn']; }
            if ($b['status'] !== 'pending') return ['html' => '<p>' . $e($b['address']) . ' was ' . ($b['status'] === 'active' ? 'approved' : $e($b['status'])) . '.</p>', 'state' => 'Decided'];
            return ['html' => '<p>' . $e($m['body']) . '</p><p class="tv-msg-acts">' . $btn('Approve', ['approve' => (int) $b['id']]) . ' ' . $btn('Decline', ['decline' => (int) $b['id']], ' ghost', 'Decline reading ' . $b['address'] . ' in Pulse? Its password is removed.') . '</p>', 'state' => 'Waiting for your OK'];
        }
        if (preg_match('/^mbfail:(\d+):/', $thing, $x)) {
            try { $b = self::box($pdo, (int) $x[1]); } catch (Throwable) { return ['html' => '<p>That mailbox was disconnected.</p>', 'state' => 'Disconnected']; }
            if ($b['status'] === 'active') return ['html' => '<p data-tv-status="ok" data-tv-label="Working:">' . $e($b['address']) . ' is reading again.</p>', 'state' => 'Working again'];
            $html = '<p data-tv-status="bad" data-tv-label="Refused:">' . $e($b['last_error'] ?: $m['body']) . '</p>';
            if ($b['provider'] === 'microsoft') $html .= '<p class="tv-msg-acts"><a class="tv-btn" href="/api/ms-mail.php?start=1">Sign in with Microsoft again</a></p>';
            elseif ($b['owner_type'] === 'system') $html .= '<p class="tv-msg-acts"><a class="tv-btn" href="/admin/config/communications#cs-mailboxes" data-peek-frame>Reset it in Communications</a></p>';
            else $html .= '<form class="tv-msg-acts" data-msg-reply="/user/api/mailboxes.php" data-msg-body=\'' . $e(json_encode(['reconnect' => (int) $b['id'], 'from_msg' => (int) $m['id']])) . '\'><input type="password" name="password" autocomplete="current-password" aria-label="Its password or app password" placeholder="Its password or app password"> <button class="tv-btn">Reconnect</button></form>';
            return ['html' => $html, 'state' => 'Needs reconnecting'];
        }
        return ['html' => '<p>' . $e($m['body']) . '</p>', 'state' => ''];
    }
}
