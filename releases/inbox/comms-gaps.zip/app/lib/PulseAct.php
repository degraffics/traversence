<?php

declare(strict_types=1);

require_once __DIR__ . '/People.php';
require_once __DIR__ . '/BizMessages.php';

/**
 * app/lib/PulseAct.php — a Pulse row opened, and its icons, for the member's and a business's Pulse (decisions/0172 "The
 * row's icons" and "The message"; /user/api/pulse-act.php). Pulse collects and lets you read; each action here goes
 * through the library that owns the thing, after checking the person may see it. Nothing is read from the row's own
 * words except a public link's title: the thing is read again from its tables.
 *
 * - A conversation (People, BizMessages, GuestInquiries) opens with its messages and a Reply that sends.
 * - ↗ Pass it on: to a connection (a People message), a teammate (Notify 'pulse.forward') or any email address, with a
 *   line saying who forwarded it (Jason, 2026-11-18, decision pop-up: "Also by email"). Email forwards are system
 *   emails, capped at FORWARD_DAY a person a day (pulse_forwards), so they can't be used to spam.
 * - 🛡 Protect: report through the existing path (Reports; a customer's message to a business opens a Safety case for our
 *   team), block (People::block, or every message type from a business), mute (the viewer's own). The person reported or
 *   blocked is never told.
 * - ⊕: the sender to the Address Book; Keep a post.
 */
final class PulseAct
{
    public const FORWARD_DAY = 20;

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /** The business this person is acting for, when it's that business's Pulse and they may read its messages. */
    private static function team(PDO $pdo, int $uid, array $ctx, int $e): int
    {
        if (($ctx['kind'] ?? '') !== 'org' || (int) ($ctx['scope']['entity'] ?? 0) !== $e || $e <= 0 || !BizMessages::isStaff($pdo, $uid, $e))
            throw new InvalidArgumentException('That conversation belongs to a business you aren\'t working as. Switch with Pulse ▾.');
        return $e;
    }

    // ---- a conversation, opened in place ------------------------------------------------------------------------------------

    /** {kind, with, messages: [{mine, from, body, at}], can_reply, why, types?, note?} */
    public static function thread(PDO $pdo, int $uid, array $ctx, array $ref): array
    {
        $k = (string) ($ref['kind'] ?? '');
        if ($k === 'people') {
            $t = People::thread($pdo, $uid, (int) ($ref['thread'] ?? 0));
            return ['kind' => 'people', 'with' => $t['with'], 'messages' => array_map(fn ($m) => ['mine' => (bool) $m['mine'], 'from' => (string) ($m['from'] ?? ''), 'body' => $m['body'], 'at' => $m['at']], $t['messages']),
                    'can_reply' => (bool) $t['can_reply'], 'why' => $t['can_reply'] ? '' : (!empty($t['waiting']) ? 'They haven\'t accepted your message request yet.' : (!empty($t['declined']) ? 'They declined this conversation.' : 'You can\'t write here any more.'))];
        }
        if ($k === 'biz') {
            $t = BizMessages::personThread($pdo, $uid, (int) ($ref['e'] ?? 0));
            return ['kind' => 'biz', 'with' => $t['name'], 'messages' => array_map(fn ($m) => ['mine' => $m['mine'], 'from' => $m['mine'] ? '' : $t['name'] . ($m['type_label'] ? ' · ' . $m['type_label'] : ''), 'body' => $m['body'], 'at' => $m['at']], $t['messages']),
                    'can_reply' => (bool) $t['can_reply'], 'why' => $t['can_reply'] ? '' : 'No one manages this listing yet, so there\'s no one to read it.'];
        }
        if ($k === 'team') {
            $e = self::team($pdo, $uid, $ctx, (int) ($ref['e'] ?? 0));
            $t = BizMessages::bizThread($pdo, $e, (int) ($ref['u'] ?? 0));
            return ['kind' => 'team', 'with' => $t['name'], 'messages' => array_map(fn ($m) => ['mine' => $m['mine'], 'from' => $m['mine'] ? ($m['type_label'] ?: '') : $t['name'], 'body' => $m['body'], 'at' => $m['at']], $t['messages']),
                    'can_reply' => (bool) $t['can_reply'], 'why' => $t['can_reply'] ? '' : 'You can write while they\'re linked to you, or within 30 days of their last message.',
                    'types' => $t['types_ready'] ? array_map(fn ($k2, $v) => [$k2, is_array($v) ? (string) ($v[0] ?? $k2) : (string) $v], array_keys($t['types']), array_values($t['types'])) : []];
        }
        if ($k === 'guest') {
            require_once __DIR__ . '/GuestInquiries.php';
            $e = self::team($pdo, $uid, $ctx, (int) ($ref['e'] ?? 0));
            $q = GuestInquiries::bizThread($pdo, $e, (int) ($ref['id'] ?? 0));
            return ['kind' => 'guest', 'with' => $q['name'] . ' (guest)', 'messages' => array_map(fn ($m) => ['mine' => $m['from_business'], 'from' => $m['from_business'] ? '' : $q['name'], 'body' => $m['body'], 'at' => $m['at']], $q['messages']),
                    'can_reply' => $q['status'] !== 'spam', 'why' => $q['status'] === 'spam' ? 'You marked this as spam.' : '', 'note' => (string) $q['left_note'],
                    'contact' => $q['contact'] !== '' ? $q['contact_type'] . ': ' . $q['contact'] : ''];
        }
        throw new InvalidArgumentException('That doesn\'t open here.');
    }

    public static function reply(PDO $pdo, int $uid, array $ctx, array $ref, string $body, string $type): array
    {
        $body = trim($body);
        if ($body === '') throw new InvalidArgumentException('Write something first.');
        $k = (string) ($ref['kind'] ?? '');
        if ($k === 'people') People::send($pdo, $uid, null, (int) ($ref['thread'] ?? 0), $body);
        elseif ($k === 'biz') BizMessages::personSend($pdo, $uid, (int) ($ref['e'] ?? 0), $body);
        elseif ($k === 'team') { $e = self::team($pdo, $uid, $ctx, (int) ($ref['e'] ?? 0)); BizMessages::bizReply($pdo, $uid, $e, (int) ($ref['u'] ?? 0), $body, $type !== '' ? $type : 'inquiry'); }
        elseif ($k === 'guest') {
            require_once __DIR__ . '/GuestInquiries.php';
            $e = self::team($pdo, $uid, $ctx, (int) ($ref['e'] ?? 0));
            $emailed = GuestInquiries::bizReply($pdo, $uid, $e, (int) ($ref['id'] ?? 0), $body, BizMessages::entityName($pdo, $e));
            return ['message' => $emailed ? 'Sent: they were emailed your answer.' : 'Sent: they\'ll see it with their reply code.', 'thread' => self::thread($pdo, $uid, $ctx, $ref)];
        } else throw new InvalidArgumentException('That can\'t be answered here.');
        return ['message' => 'Sent.', 'thread' => self::thread($pdo, $uid, $ctx, $ref)];
    }

    // ---- what a row is, read again from its own tables -----------------------------------------------------------------------

    /** [what it is in words, its text, its link, who it's from, kind] for forwarding; throws when this person can't see it. */
    private static function source(PDO $pdo, int $uid, array $ctx, array $item): array
    {
        $ref = (array) ($item['ref'] ?? []);
        if (!empty($item['comms'])) {
            $st = $pdo->prepare('SELECT title, body, url, sender_name FROM comms_messages WHERE id = ? AND to_user = ?');
            $st->execute([(int) $item['comms'], $uid]);
            $m = $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('That message isn\'t yours.');
            return ['A notice', $m['title'] . ($m['body'] !== '' ? "\n" . $m['body'] : ''), (string) $m['url'], (string) ($m['sender_name'] ?: 'Traversence'), 'notice'];
        }
        if (!empty($item['post']['id'])) {
            require_once __DIR__ . '/MemberPosts.php';
            $p = MemberPosts::get($pdo, (int) $item['post']['id']);
            if (!$p || !MemberPosts::canSee($pdo, $p, $uid)) throw new InvalidArgumentException('That post isn\'t available.');
            $pu = (string) ($item['post']['url'] ?? ''); return ['A post', (string) $p['body'], preg_match('#^/[^/]#', $pu) ? $pu : '', 'a post', 'post'];
        }
        $k = (string) ($ref['kind'] ?? '');
        if (in_array($k, ['people', 'biz', 'team', 'guest'], true)) {
            $t = self::thread($pdo, $uid, $ctx, $ref);
            $last = array_slice($t['messages'], -3);
            if (!$last) throw new InvalidArgumentException('That conversation is empty.');
            $text = implode("\n\n", array_map(fn ($m) => ($m['mine'] ? 'You' : ($m['from'] !== '' ? $m['from'] : $t['with'])) . ' (' . $m['at'] . "):\n" . $m['body'], $last));
            return ['A conversation with ' . $t['with'], $text, '', $t['with'], 'message'];
        }
        // a feed item or what needs you: public pages and the site's own counts; only the title and the link go
        $url = (string) ($item['url'] ?? '');
        if ($url !== '' && !preg_match('#^(/[^/]|\#)#', $url)) $url = '';
        return [(string) ($item['title'] ?? 'Something in your Pulse'), mb_substr((string) ($item['title'] ?? ''), 0, 200), $url, 'Traversence', 'feed'];
    }

    // ---- ↗ Pass it on -------------------------------------------------------------------------------------------------------

    /** Who this person can pass a message on to, here. */
    public static function forwardTargets(PDO $pdo, int $uid, array $ctx): array
    {
        $people = $team = [];
        if (($ctx['kind'] ?? '') === 'org') {
            require_once __DIR__ . '/Marketing.php';
            foreach (Marketing::staff($pdo, (int) $ctx['scope']['entity']) as $id) if ($id !== $uid && ($u = People::user($pdo, $id))) $team[] = [$id, People::name($u), 'On your team'];
        } else {
            try {
                $st = $pdo->prepare("SELECT CASE WHEN requester_id = ? THEN addressee_id ELSE requester_id END FROM people_connections
                                      WHERE (requester_id = ? OR addressee_id = ?) AND status = 'accepted' ORDER BY responded_at DESC LIMIT 100");
                $st->execute([$uid, $uid, $uid]);
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) if (($u = People::user($pdo, (int) $id)) && !People::blocked($pdo, $uid, (int) $id)) $people[] = [(int) $id, People::name($u), 'A connection'];
            } catch (Throwable) {}
        }
        return ['people' => $people, 'team' => $team, 'left' => self::forwardsLeft($pdo, $uid)];
    }

    private static function forwardsReady(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM pulse_forwards LIMIT 0'); return true; } catch (Throwable) { return false; }
    }

    public static function forwardsLeft(PDO $pdo, int $uid): int
    {
        if (!self::forwardsReady($pdo)) return 0;
        $st = $pdo->prepare("SELECT COUNT(*) FROM pulse_forwards WHERE user_id = ? AND via = 'email' AND created_at > ?");
        $st->execute([$uid, date('Y-m-d H:i:s', time() - 86400)]);
        return max(0, self::FORWARD_DAY - (int) $st->fetchColumn());
    }

    public static function forward(PDO $pdo, array $me, array $ctx, array $item, string $to, int $toUser, string $toEmail, string $note): array
    {
        $uid = (int) $me['id'];
        [$what, $text, $url, $from] = self::source($pdo, $uid, $ctx, $item);
        $name = People::name(People::user($pdo, $uid) ?? $me);
        $note = trim(mb_substr(strip_tags($note), 0, 1000));
        $site = rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/');
        $link = $url !== '' && $url[0] === '/' ? $site . $url : '';
        $head = 'Forwarded by ' . $name . ' from their Pulse on Traversence.';
        $text = mb_substr($text, 0, 3000);
        if ($to === 'email') {
            $toEmail = mb_strtolower(trim($toEmail));
            if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email address doesn\'t look right.');
            if (!self::forwardsReady($pdo)) throw new InvalidArgumentException('Forwarding by email switches on once the site\'s update has run (within the hour).');
            if (self::forwardsLeft($pdo, $uid) <= 0) throw new RuntimeException('That\'s ' . self::FORWARD_DAY . ' forwards by email today, the most for a day. Pass it on in Traversence, or try again tomorrow.');
            require_once __DIR__ . '/Mailer.php';
            $body = $head . ($note !== '' ? "\n\n" . $note : '') . "\n\n---------- " . $what . " ----------\nFrom: " . $from . "\n\n" . $text . ($link !== '' ? "\n\n" . $link : '')
                . "\n\nYou're getting this because " . $name . ' chose to send it to you. Traversence sends nothing else from it.';
            Mailer::send($toEmail, 'Fwd: ' . mb_strimwidth($what, 0, 120, '…'), $body);
            $pdo->prepare('INSERT INTO pulse_forwards (user_id, via, to_user, to_hash, what, created_at) VALUES (?, ?, NULL, ?, ?, ?)')
                ->execute([$uid, 'email', hash('sha256', $toEmail), mb_substr($what, 0, 120), self::now()]);
            return ['message' => 'Forwarded to ' . $toEmail . '.', 'left' => self::forwardsLeft($pdo, $uid)];
        }
        if ($to === 'person') {
            if (($ctx['kind'] ?? '') === 'org') throw new InvalidArgumentException('From a business, pass it on to your team or by email.');
            $ok = array_column(self::forwardTargets($pdo, $uid, $ctx)['people'], 0);
            if (!in_array($toUser, $ok, true)) throw new InvalidArgumentException('Choose one of your connections.');
            People::send($pdo, $uid, $toUser, null, $head . ($note !== '' ? "\n\n" . $note : '') . "\n\n" . $what . ', from ' . $from . ":\n" . $text . ($link !== '' ? "\n" . $link : ''));
            self::logForward($pdo, $uid, 'person', $toUser, $what);
            return ['message' => 'Passed on in a message to ' . People::name(People::user($pdo, $toUser) ?? []) . '.'];
        }
        if ($to === 'team') {
            $ok = array_column(self::forwardTargets($pdo, $uid, $ctx)['team'], 0);
            if (!in_array($toUser, $ok, true)) throw new InvalidArgumentException('Choose someone on your team.');
            require_once __DIR__ . '/Notify.php';
            if (!isset(Notify::kinds()['pulse.forward'])) throw new InvalidArgumentException('Passing on to your team switches on with the site\'s next update.');
            $n = Notify::send($pdo, 'pulse.forward', ['users' => [$toUser]], ['thing' => 'fwd:' . bin2hex(random_bytes(6)), 'url' => $url, 'from' => ['user', $uid, $name]],
                ['title' => $name . ' passed on: ' . mb_strimwidth($what, 0, 140, '…'), 'body' => ($note !== '' ? $note . "\n\n" : '') . 'From ' . $from . ': ' . $text]);
            if (!$n) throw new InvalidArgumentException('That didn\'t reach them. Try again; still stuck? Write to support@traversence.com.');
            self::logForward($pdo, $uid, 'team', $toUser, $what);
            return ['message' => 'Passed on: it\'s in their Pulse.'];
        }
        throw new InvalidArgumentException('Choose who to pass it on to.');
    }

    private static function logForward(PDO $pdo, int $uid, string $via, int $toUser, string $what): void
    {
        if (!self::forwardsReady($pdo)) return;
        try { $pdo->prepare('INSERT INTO pulse_forwards (user_id, via, to_user, to_hash, what, created_at) VALUES (?, ?, ?, NULL, ?, ?)')->execute([$uid, $via, $toUser, mb_substr($what, 0, 120), self::now()]); } catch (Throwable) {}
    }

    /** Why ↗ can't pass this row on ('' when it can): a count of what needs you is the site's own, not a message. */
    public static function forwardWhy(array $item): string
    {
        $k = (string) ($item['ref']['kind'] ?? '');
        if ($k === 'needs') return 'This is the site\'s own count of what needs you: open it to act.';
        if ($k === 'left') return 'This is your own message, waiting on a listing.';
        return '';
    }

    /** A row as the Pulse page gets it: what ↗ and 🛡 can do with it. */
    public static function decorate(array $item, array $ctx): array
    {
        return $item + ['fwd' => self::forwardWhy($item), 'protect' => self::protects($item, $ctx)];
    }

    // ---- 🛡 Protect -----------------------------------------------------------------------------------------------------------

    /** What 🛡 can do with this row: [[key, label, what it does, reason it can't (empty when it can)]]. */
    public static function protects(array $item, array $ctx): array
    {
        $ref = (array) ($item['ref'] ?? []); $k = (string) ($ref['kind'] ?? '');
        if (!empty($item['comms'])) return [['report', 'Report it', '', 'It\'s from Traversence: what it\'s about has its own Report inside it, where it applies.']];
        if (!empty($item['post'])) {   // a post: its own Report (TvMoments), and muting its poster
            return [['report', 'Report the post', 'Its own Report, opened in place.', ''],
                    !empty($item['post']['owner']['id']) ? ['mute', 'Mute ' . (string) ($item['post']['owner']['name'] ?? 'them'), 'Their posts stop showing in your Pulse; only for you.', ''] : ['mute', 'Mute them', '', 'This post has no one to mute.']];
        }
        if ($k === 'needs') return [['report', 'Report it', '', 'It\'s from Traversence itself.']];
        if ($k === 'people') return [['report', 'Report the conversation', 'Our team looks; they aren\'t told who reported.', ''], ['block', 'Block them', 'They can\'t message you; they aren\'t told.', ''], ['mute', 'Mute it', 'No more alerts from it; only for you.', '']];
        if ($k === 'biz') return [['report', 'Report their message', 'Spam, harassment, or Sales sent as another type.', ''], ['block', 'Block this business', 'No more messages of any kind from it; it isn\'t told.', '']];
        if ($k === 'team') return [['report', 'Report this customer', 'Goes to our team\'s support inbox with what they wrote; they aren\'t told.', ''], ['block', 'Block them', '', 'A business can\'t block a customer here: report it and our team steps in.']];
        if ($k === 'guest') return [['report', 'Report this message', 'Our team looks; the guest isn\'t told.', '']];
        if ($k === 'left') return [['report', 'Report it', '', 'This is your own message.']];
        if ($k === 'feed') {
            $o = [];
            $o[] = !empty($ref['post']) ? ['report', 'Report the post', 'Goes to the group\'s moderators (to us for law or danger).', ''] : ['report', 'Report the post', '', 'Report it on its own page: open it with the link mark.'];
            if (!empty($ref['group'])) $o[] = ['mute', 'Mute the group', 'Its posts stop showing in your Pulse; only for you.', ''];
            elseif (!empty($ref['mute'])) $o[] = ['mute', 'Mute them', 'Their posts stop showing in your Pulse; only for you.', ''];
            return $o;
        }
        return [['report', 'Report it', '', 'There\'s nothing here to report.']];
    }

    public static function report(PDO $pdo, int $uid, array $ctx, array $item, string $reason, string $note): array
    {
        require_once __DIR__ . '/Reports.php';
        $ref = (array) ($item['ref'] ?? []); $k = (string) ($ref['kind'] ?? '');
        $can = array_values(array_filter(self::protects($item, $ctx), fn ($p) => $p[0] === 'report' && $p[3] === ''));
        if (!$can) throw new InvalidArgumentException(self::protects($item, $ctx)[0][3] ?? 'That can\'t be reported here.');
        if ($k === 'people') { Reports::file($pdo, $uid, 'thread', (int) ($ref['thread'] ?? 0), $reason, $note); }
        elseif ($k === 'biz') {
            $st = $pdo->prepare('SELECT id FROM business_messages WHERE user_id = ? AND entity_id = ? AND from_business = 1 ORDER BY id DESC LIMIT 1');
            $st->execute([$uid, (int) ($ref['e'] ?? 0)]);
            $mid = (int) $st->fetchColumn();
            if (!$mid) throw new InvalidArgumentException('They haven\'t sent you anything to report.');
            Reports::file($pdo, $uid, 'biz_message', $mid, $reason, $note);
        } elseif ($k === 'team' || ($k === 'guest' && empty($ref['left']))) {
            $e = self::team($pdo, $uid, $ctx, (int) ($ref['e'] ?? 0));
            if (!isset(Reports::REASONS[$reason])) throw new InvalidArgumentException('Pick a reason.');
            // no report kind exists for a business reporting a customer: it reaches our team's support inbox (read in Pulse,
            // decisions/0167), with what was written; the customer isn't told
            require_once __DIR__ . '/Mailer.php'; require_once __DIR__ . '/ListingMessages.php';
            $t = self::thread($pdo, $uid, $ctx, $ref);
            $last = array_slice(array_filter($t['messages'], fn ($m) => !$m['mine']), -3);
            Mailer::send(ListingMessages::helpTo(), 'Report from a business: ' . Reports::label($reason),
                BizMessages::entityName($pdo, $e) . ' (listing ' . $e . ') reported a ' . ($k === 'team' ? 'customer\'s message (user ' . (int) ($ref['u'] ?? 0) . ')' : 'guest\'s question (#' . (int) ($ref['id'] ?? 0) . ')')
                . ' from its Pulse, reported by user ' . $uid . '.' . "\n\nReason: " . Reports::label($reason) . (trim($note) !== '' ? "\nTheir note: " . mb_substr(trim(strip_tags($note)), 0, 500) : '')
                . "\n\nWhat was written:\n" . implode("\n\n", array_map(fn ($m) => $m['at'] . ': ' . mb_substr($m['body'], 0, 1000), $last)));
        } elseif ($k === 'guest') {
            self::team($pdo, $uid, $ctx, (int) ($ref['e'] ?? 0));
            Reports::file($pdo, $uid, 'listing_message', (int) ($ref['id'] ?? 0), $reason, $note);
        } elseif ($k === 'feed' && !empty($ref['post'])) {
            Reports::file($pdo, $uid, 'group_post', (int) $ref['post'], $reason, $note);
        } else throw new InvalidArgumentException('That can\'t be reported here.');
        return ['message' => 'Reported. Thank you: we look at every report, and they aren\'t told who sent it.'];
    }

    public static function block(PDO $pdo, int $uid, array $ctx, array $item): array
    {
        $ref = (array) ($item['ref'] ?? []); $k = (string) ($ref['kind'] ?? '');
        if ($k === 'people') {
            $with = (int) ($ref['with'] ?? 0);
            if ($with <= 0) throw new InvalidArgumentException('This is a group conversation: mute it, or leave it.');
            People::block($pdo, $uid, $with);
            return ['message' => 'Blocked. They can\'t message you, and they aren\'t told. Undo it in your Address Book.'];
        }
        if ($k === 'biz') {
            $e = (int) ($ref['e'] ?? 0);
            if (!BizMessages::typesReady($pdo)) throw new InvalidArgumentException('Blocking a business switches on once the site\'s update has run.');
            foreach (array_keys(BizMessages::TYPES) as $t) BizMessages::setMute($pdo, $uid, $e, (string) $t, true);
            return ['message' => 'Blocked: no more messages of any kind from ' . BizMessages::entityName($pdo, $e) . '. It isn\'t told.'];
        }
        $p = array_values(array_filter(self::protects($item, $ctx), fn ($x) => $x[0] === 'block'));
        throw new InvalidArgumentException($p ? $p[0][3] : 'There\'s no one to block here.');
    }

    public static function mute(PDO $pdo, int $uid, array $ctx, array $item, bool $on): array
    {
        $ref = (array) ($item['ref'] ?? []); $k = (string) ($ref['kind'] ?? '');
        if ($k === 'people') { People::setThread($pdo, $uid, (int) ($ref['thread'] ?? 0), 'muted', $on); return ['message' => $on ? 'Muted: no more alerts from this conversation.' : 'Unmuted.']; }
        if ($k === 'feed' && !empty($ref['group'])) {
            require_once __DIR__ . '/GroupNotices.php'; require_once __DIR__ . '/Community.php';
            $g = Community::group($pdo, (int) $ref['group']) ?: throw new InvalidArgumentException('That group isn\'t available.');
            GroupNotices::setMuted($pdo, $uid, $g, $on);
            return ['message' => $on ? 'Muted ' . $g['name'] . ': its posts stop showing in your Pulse. Only for you.' : 'Unmuted ' . $g['name'] . '.'];
        }
        if ($k === 'feed' && !empty($ref['mute'])) {
            [$type, $id] = $ref['mute'];
            if (!in_array($type, ['person', 'business'], true)) throw new InvalidArgumentException('That can\'t be muted.');
            require_once __DIR__ . '/Links.php';
            Links::mute($pdo, $uid, (string) $type, (string) $id, $on);
            return ['message' => $on ? 'Muted: their posts stop showing in your Pulse. Only for you.' : 'Unmuted.'];
        }
        if (!empty($item['post']['owner']['id'])) {
            require_once __DIR__ . '/Links.php';
            Links::mute($pdo, $uid, !empty($item['post']['owner']['business']) ? 'business' : 'person', (string) (int) $item['post']['owner']['id'], $on);
            return ['message' => $on ? 'Muted ' . $item['post']['owner']['name'] . ': their posts stop showing in your Pulse. Only for you.' : 'Unmuted.'];
        }
        throw new InvalidArgumentException('There\'s nothing to mute here.');
    }

    // ---- ⊕ ------------------------------------------------------------------------------------------------------------------

    public static function addressBook(PDO $pdo, int $uid, array $ctx, array $item): array
    {
        $ref = (array) ($item['ref'] ?? []); $k = (string) ($ref['kind'] ?? '');
        if ($k === 'people') {
            $with = (int) ($ref['with'] ?? 0);
            if ($with <= 0) throw new InvalidArgumentException('A group conversation has no one person to add.');
            $r = People::connect($pdo, $uid, $with);
            return ['message' => $r === 'connected' ? 'In your Address Book.' : 'Asked to connect: they\'ll be in your Address Book when they accept.'];
        }
        if ($k === 'biz') {
            require_once __DIR__ . '/Links.php';
            Links::set($pdo, $uid, 'business', (string) (int) ($ref['e'] ?? 0), true);
            return ['message' => 'Linked: the business is in your Address Book, and its news comes to your Pulse.'];
        }
        if (!empty($item['post']['owner']['id']) && empty($item['post']['owner']['business'])) {
            $r = People::connect($pdo, $uid, (int) $item['post']['owner']['id']);
            return ['message' => $r === 'connected' ? 'In your Address Book.' : 'Asked to connect.'];
        }
        throw new InvalidArgumentException('There\'s no one here to add to your Address Book.');
    }

    public static function keep(PDO $pdo, int $uid, array $item): array
    {
        if (empty($item['post']['id'])) throw new InvalidArgumentException('Only a post can be kept.');
        require_once __DIR__ . '/MemberPosts.php';
        MemberPosts::keep($pdo, $uid, (int) $item['post']['id']);
        return ['message' => 'Kept: it stays, and its photos are in your Gallery (Kept Moments).'];
    }
}
