<?php
// app/admin/inbox-console.php — Dashboard → My inbox and Dashboard → Your communications (decisions/0172 §4.7, §4.4; 0167
// §2a). My inbox: the mail of every mailbox the signed-in staff member reads (ours they oversee, and their own, outside
// ones once their manager approves), together, each row labelled with its mailbox, with a filter by mailbox; a row opens
// in place (the email shown safely, outside pictures held until asked, its attachments listed) with its answer box
// (Reply, Reply all, Forward; From: only the mailboxes they read; Send). Connect another mailbox from here (IMAP, POP,
// Gmail by app password, Sign in with Microsoft). Your communications: the same one setting members have, for staff
// (their choices, quiet hours, push on this device). The script is js/admin-inbox.js. The same mail shows as rows in the
// Pulse stream (app/ui/pulse-ui.php tv_pulse_extra; its Mail chip): this page stays as their view, for connecting and state.
declare(strict_types=1);

function tv_admin_mod_inbox(PDO $pdo): string
{
    require_once __DIR__ . '/../lib/Mailboxes.php';
    require_once __DIR__ . '/../lib/MsGraphMail.php';
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    if (!Mailboxes::ready($pdo)) return '<p data-tv-status="info" data-tv-label="Waiting:">Your inbox switches on once the site\'s database update runs (within the hour, or open <a href="/admin/config/dbupdates">Database updates</a>).</p>';
    [$gok, $gwhy] = Mailboxes::gmailGate($pdo);
    $prov = '';
    foreach (Mailboxes::PROVIDERS as $k => [$n, $w]) if (!in_array($k, ['microsoft', 'ses', 'cpanel'], true)) $prov .= '<option value="' . $e($k) . '" title="' . $e($w) . '">' . $e($n) . '</option>';
    $h = '<div id="ib" data-csrf="' . $e((string) ($_SESSION['csrf_token'] ?? '')) . '">'
       // the same mail is in the Pulse stream, a row per conversation beside everything else (decisions/0172 §4.7; this page
       // stays as its view, with connecting and the mailboxes' state)
       . '<p data-tv-status="info" data-tv-label="Also in Pulse:">This mail is in your Pulse stream too, beside everything else. <a href="/admin/dashboard/stream#mail">See it in Pulse</a> (the Mail chip).</p>'
       . '<div class="ib-bar"><select id="ib-box" aria-label="Which mailbox"><option value="0">All my mailboxes</option></select>'
       . '<select id="ib-view" aria-label="Which mail"><option value="inbox">Inbox</option><option value="sent">Sent</option><option value="all">All</option></select>'
       . '<input type="search" id="ib-q" placeholder="Search your mail" aria-label="Search your mail" data-spell> <button type="button" class="ak-btn ghost" id="ib-new">Write</button> <button type="button" class="ak-btn ghost" id="ib-refresh">Check now</button></div>'
       . '<div id="ib-boxes" class="ib-boxes"></div><div id="ib-list" class="ib-list"><p class="ak-note">Loading your mail…</p></div>'
       . '<details class="ib-connect"><summary>Connect another mailbox</summary>'
       . '<p class="ak-note">Our mailboxes (support@, orders@) are added to your inbox by an owner in <a href="/admin/config/communications#cs-mailboxes" data-peek-frame>Communications</a>. An outside mailbox of yours waits for your manager\'s OK. Passwords are sealed and never shown again; Disconnect deletes our copy.</p>'
       . '<form id="ib-cform"><label>Kind <select name="provider">' . $prov . '</select></label>'
       . '<label>Address <input name="address" type="email" required spellcheck="false" autocomplete="email"></label>'
       . '<label>Password or app password <input name="password" type="password" autocomplete="current-password" required spellcheck="false"></label>'
       . '<details><summary>Server (filled in for Gmail, Yahoo, iCloud, Zoho, Outlook)</summary><label>Server <input name="host" spellcheck="false" placeholder="imap.example.com"></label><label>Port <input name="port" inputmode="numeric" placeholder="993"></label>'
       . '<label>Sending server <input name="smtp_host" spellcheck="false" placeholder="smtp.example.com"></label><label>Sending port <input name="smtp_port" inputmode="numeric" placeholder="587"></label><label>Sign-in name, if not the address <input name="login" spellcheck="false"></label></details>'
       . '<p class="ak-note">Gmail: turn on 2-Step Verification, then make an app password at https://myaccount.google.com/apppasswords. Yahoo: https://login.yahoo.com/account/security. iCloud: https://account.apple.com → Sign-In and Security → App-Specific Passwords.</p>'
       . '<button class="ak-btn">Sign in and connect</button></form>'
       . '<p>' . (MsGraphMail::ready() ? '<a class="ak-btn" href="/api/ms-mail.php?start=1">Sign in with Microsoft</a>' : '<button type="button" class="ak-btn" disabled title="Not set up yet">Sign in with Microsoft</button> <span class="ak-note">An owner adds the app\'s keys in Communications first.</span>') . '</p>'
       . '<p><button type="button" class="ak-btn" disabled title="' . $e($gok ? 'Coming' : $gwhy) . '">Sign in with Google</button> <span class="ak-note">' . $e($gok ? 'Revenue covers Google\'s assessment: it can be built.' : $gwhy) . '</span></p></details>'
       . '</div>'
       . '<style>#ib .ib-bar{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;margin-bottom:.5rem}#ib .ib-bar input[type=search]{flex:1;min-width:10rem}'
       . '#ib .ib-boxes{display:flex;flex-wrap:wrap;gap:.3rem;margin:.3rem 0}#ib .ib-chip{font-size:.8rem;border:1px solid #CBB98D;border-radius:999px;padding:.1rem .5rem}#ib .ib-chip.bad{border-color:#B91C1C;color:#B91C1C}'
       . '#ib .ib-r{border-bottom:1px solid #EADFC4;padding:.45rem .3rem;cursor:pointer;display:grid;grid-template-columns:1fr auto;gap:.1rem .5rem}#ib .ib-r.new .ib-s{font-weight:700}#ib .ib-r small{color:#8A7355}'
       . '#ib .ib-open{grid-column:1/-1;cursor:auto;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.5rem;padding:.6rem;margin:.3rem 0}#ib .ib-mail{border-bottom:1px dashed #EADFC4;padding:.4rem 0;overflow-wrap:anywhere}#ib .ib-mail .ib-html{max-width:100%;overflow-x:auto}'
       . '#ib .ib-mail img{max-width:100%;height:auto}#ib form label{display:block;margin:.3rem 0}#ib form input,#ib form select,#ib form textarea{width:100%;max-width:32rem;box-sizing:border-box}#ib .ib-acts{display:flex;flex-wrap:wrap;gap:.35rem;margin:.4rem 0}'
       . '@media (max-width:767px){#ib .ib-r{grid-template-columns:1fr}}</style><script src="/js/admin-inbox.js" defer></script>';
    return $h;
}

/** Dashboard → Your communications: the one Communications setting, for staff (handoffs/communications.md: left for later). */
function tv_admin_mod_mycomms(PDO $pdo): string
{
    require_once __DIR__ . '/../ui/comms-setting.php';
    return '<div class="ah-card tv-bleed">' . tv_comms_setting('staff') . '</div>';
}
