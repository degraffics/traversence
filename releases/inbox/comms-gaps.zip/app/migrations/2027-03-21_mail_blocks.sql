-- decisions/0172 §4.7, the email row's 🛡 in Pulse: senders a person blocked. Their mail stops showing to that person only;
-- the mailbox keeps it and the sender isn't told. Add-only, safe to run twice.
CREATE TABLE IF NOT EXISTS comms_mail_blocks (
  user_id INT UNSIGNED NOT NULL,
  addr VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, addr)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
