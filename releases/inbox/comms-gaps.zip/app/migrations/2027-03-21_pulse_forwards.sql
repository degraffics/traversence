-- decisions/0172, the row's ↗ in Pulse: each message a person passed on (to a connection, a teammate, or by email; Jason,
-- 2026-11-18). Email forwards are counted from here, capped a day per person (PulseAct::FORWARD_DAY); an address is kept
-- only as its hash. Add-only, safe to run twice.
CREATE TABLE IF NOT EXISTS pulse_forwards (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  via VARCHAR(10) NOT NULL,
  to_user INT UNSIGNED NULL,
  to_hash CHAR(64) NULL,
  what VARCHAR(120) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL,
  KEY pf_user_day (user_id, via, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
