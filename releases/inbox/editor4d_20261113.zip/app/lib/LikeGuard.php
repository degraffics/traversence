<?php
// app/lib/LikeGuard.php — checks on likes, so a count means real people (Jason, 2026-11-05; decisions/0009, 0058 §20).
//
// Same limits for everyone; guests and accounts in their first 7 days ("watched") get the closer checks until proven:
//   speed      likes from one connection in a minute: 20 (watched: 10). Past it, the "verify you're human" check
//              (Turnstile, free: Captcha.php), never a refusal. Passing it covers the visit for 10 minutes.
//   timing     likes at near-identical gaps (a script's rhythm), from a source's 10th like (watched: 5th): the same check.
//   daily      100 likes a day per account; past it, "You've reached today's 100 likes", and Keep liking (after the check)
//              allows another 100. Guests: after Guest::LIKES_PER_VISIT the account panel, with Keep going as a guest,
//              up to Guest::MAX_PER_VISIT in the visit.
//   hourly     tick(): perfectly timed likes, or an item with more likes than views, come off the count at once and are
//              reported; groups of watched sources on one item, and a new account with guests on one connection, are
//              reported only. Reports are a Safety case in Pulse (likes:checks), a step each: Looks fine, or Remove them.
// Proven: an account 7+ days old with nothing reported in its first 7 days (like_watch keeps a reported one watched
// until cleared). Guests are always watched: a guest is one visit. Nobody is told they're watched; nothing about a
// person is shown in a report beyond the counts and a hashed connection. Events are deleted after 30 days.
declare(strict_types=1);

final class LikeGuard
{
    public const PER_MIN = 20;
    public const PER_MIN_WATCHED = 10;
    public const TIMING_FROM = 10;
    public const TIMING_FROM_WATCHED = 5;
    public const PER_DAY = 100;
    public const NEW_DAYS = 7;
    public const PASS_MINUTES = 10;
    public const GROUP = 3;   // watched sources on one item within an hour
    public const REASONS = [
        'timing' => 'Liked at a machine\'s pace',
        'views' => 'More likes than views',
        'group' => 'New accounts and guests together',
        'connection' => 'A new account and guests on one connection',
    ];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM like_events LIMIT 0'); $pdo->query('SELECT 1 FROM like_flags LIMIT 0'); return $ok = true; } catch (Throwable) { return $ok = false; }
    }

    /** Who gave it: a member, or a guest visit (its session, hashed; gone when the visit ends). */
    public static function src(?int $uid): string
    {
        if ($uid) return 'u:' . $uid;
        return 'g:' . substr(hash('sha256', 'visit|' . session_id()), 0, 32);
    }

    public static function ipKey(): string { return hash('sha256', 'ip|' . (string) ($_SERVER['REMOTE_ADDR'] ?? '')); }

    /** The closer checks: guests always; an account in its first 7 days, or one kept on them after a report. */
    public static function watched(PDO $pdo, ?int $uid): bool
    {
        if (!$uid) return true;
        try {
            $st = $pdo->prepare('SELECT created_at FROM users WHERE id = ?'); $st->execute([$uid]);
            $c = $st->fetchColumn();
            if ($c && strtotime((string) $c) > time() - self::NEW_DAYS * 86400) return true;
            $st = $pdo->prepare('SELECT 1 FROM like_watch WHERE user_id = ? AND cleared_at IS NULL'); $st->execute([$uid]);
            return (bool) $st->fetchColumn();
        } catch (Throwable) { return false; }
    }

    private static function passed(): bool { return (int) ($_SESSION['tv_like_ok_until'] ?? 0) > time(); }

    /**
     * Before a like is added. Throws RuntimeException 428 ("check": the human check first) or 429 ("daily": today's
     * likes are used; Keep liking asks for more). Nothing is checked before the migration runs.
     */
    public static function check(PDO $pdo, ?int $uid): void
    {
        if (!self::ready($pdo)) return;
        $w = self::watched($pdo, $uid);
        if (!self::passed()) {
            $st = $pdo->prepare('SELECT COUNT(*) FROM like_events WHERE ip_key = ? AND created_at >= ?');
            $st->execute([self::ipKey(), date('Y-m-d H:i:s', time() - 60)]);
            if ((int) $st->fetchColumn() >= ($w ? self::PER_MIN_WATCHED : self::PER_MIN))
                throw new RuntimeException('That\'s a lot of likes in a minute. Please confirm you\'re a person to keep going.', 428);
            if (self::machinePace($pdo, self::src($uid), $w ? self::TIMING_FROM_WATCHED : self::TIMING_FROM))
                throw new RuntimeException('Please confirm you\'re a person to keep liking.', 428);
        }
        if ($uid) {
            $st = $pdo->prepare('SELECT COUNT(*) FROM like_events WHERE user_id = ? AND created_at >= ? AND voided_at IS NULL');
            $st->execute([$uid, date('Y-m-d 00:00:00')]);
            $more = (int) (($_SESSION['tv_like_more'] ?? [])[date('Y-m-d')] ?? 0);
            if ((int) $st->fetchColumn() >= self::PER_DAY * (1 + $more))
                throw new RuntimeException('You\'ve reached today\'s ' . self::PER_DAY . ' likes.', 429);
        }
    }

    /** A source's last $n likes came at near-identical gaps, faster than a person reads: a script's rhythm. */
    private static function machinePace(PDO $pdo, string $src, int $n): bool
    {
        $st = $pdo->prepare('SELECT created_at FROM like_events WHERE src = ? ORDER BY id DESC LIMIT ' . (int) $n);
        $st->execute([$src]);
        $t = array_map(fn ($x) => (float) strtotime(substr((string) $x, 0, 19)) + (float) ('0.' . (explode('.', (string) $x)[1] ?? '0')), $st->fetchAll(PDO::FETCH_COLUMN));
        return count($t) >= $n && self::even($t);
    }

    /** Gaps between the times (newest first) average under 4 s and vary less than 8%. */
    public static function even(array $t): bool
    {
        if (count($t) < 4) return false;
        $g = [];
        for ($i = 0; $i < count($t) - 1; $i++) $g[] = abs($t[$i] - $t[$i + 1]);
        $mean = array_sum($g) / count($g);
        if ($mean <= 0 || $mean >= 4.0) return false;
        $var = 0.0; foreach ($g as $x) $var += ($x - $mean) ** 2;
        return sqrt($var / count($g)) < 0.08 * $mean;
    }

    /** A like was added: kept for the checks. */
    public static function record(PDO $pdo, ?int $uid, string $kind, string $ref): void
    {
        if (!self::ready($pdo)) return;
        $now = microtime(true);
        $pdo->prepare('INSERT INTO like_events (kind, ref, src, user_id, ip_key, watched, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$kind, $ref, self::src($uid), $uid ?: null, self::ipKey(), self::watched($pdo, $uid) ? 1 : 0, date('Y-m-d H:i:s', (int) $now) . sprintf('.%03d', (int) (($now - floor($now)) * 1000))]);
    }

    /** An unlike: the like it undoes no longer counts toward the day or the checks. */
    public static function unrecord(PDO $pdo, ?int $uid, string $kind, string $ref): void
    {
        if (!self::ready($pdo)) return;
        $pdo->prepare('DELETE FROM like_events WHERE src = ? AND kind = ? AND ref = ? ORDER BY id DESC LIMIT 1')->execute([self::src($uid), $kind, $ref]);
    }

    /** The human check passed (Turnstile): the speed and timing checks wait 10 minutes for this visit. */
    public static function pass(string $token): void
    {
        require_once __DIR__ . '/Captcha.php';
        Captcha::verify($token);
        $_SESSION['tv_like_ok_until'] = time() + self::PASS_MINUTES * 60;
    }

    /** Keep liking past today's 100 (after the human check): another 100 today. */
    public static function more(string $token): void
    {
        self::pass($token);
        $m = (array) ($_SESSION['tv_like_more'] ?? []); $d = date('Y-m-d');
        $_SESSION['tv_like_more'] = [$d => (int) ($m[$d] ?? 0) + 1];
    }

    // ---- the hourly look -------------------------------------------------------------------------------------------

    /** Takes clear machine likes off the count, reports the rest to Safety, deletes events past 30 days. A summary. */
    public static function tick(PDO $pdo): string
    {
        if (!self::ready($pdo)) return 'Not ready yet: the like checks migration hasn\'t run.';
        $since = date('Y-m-d H:i:s', time() - 65 * 60);
        $ev = $pdo->prepare('SELECT * FROM like_events WHERE created_at >= ? AND voided_at IS NULL ORDER BY id DESC');
        $ev->execute([$since]);
        $rows = $ev->fetchAll(PDO::FETCH_ASSOC);
        $bySrc = []; $byItem = [];
        foreach ($rows as $r) { $bySrc[$r['src']][] = $r; $byItem[$r['kind'] . "\t" . $r['ref']][] = $r; }
        $removed = 0; $flags = 0;

        // 1. a machine's pace: every like in the hour from that source comes off, and it's reported
        foreach ($bySrc as $src => $list) {
            $n = $list[0]['watched'] ? self::TIMING_FROM_WATCHED : self::TIMING_FROM;
            if (count($list) < $n) continue;
            $t = array_map(fn ($x) => (float) strtotime(substr((string) $x['created_at'], 0, 19)) + (float) ('0.' . (explode('.', (string) $x['created_at'])[1] ?? '0')), $list);
            if (!self::even($t)) continue;
            $removed += self::void($pdo, $list);
            foreach (self::group($list) as $item => $l)
                $flags += self::flag($pdo, $l[0]['kind'], $l[0]['ref'], 'timing', count($list) . ' likes in the hour at a steady ' . round((max($t) - min($t)) / max(1, count($t) - 1), 2) . ' s apart; all taken off.', [$src], count($l), count($l));
        }

        // 2. more likes than views: the newest watched likes come off until the count is no more than its views
        require_once __DIR__ . '/Engage.php';
        foreach ($byItem as $key => $list) {
            [$kind, $ref] = explode("\t", $key);
            if (!isset(Engage::COUNT_KEY[$kind])) continue;
            $likes = Engage::likes($pdo, $kind, $ref); $views = Engage::views($pdo, $kind, $ref);
            if ($views <= 0 || $likes <= $views) continue;
            $over = $likes - $views;
            $take = array_slice(array_values(array_filter($list, fn ($r) => (int) $r['watched'] === 1 && $r['voided_at'] === null)), 0, $over);
            $n = self::void($pdo, $take); $removed += $n;
            $flags += self::flag($pdo, $kind, $ref, 'views', $likes . ' likes and ' . $views . ' views; ' . $n . ' new or guest like' . ($n === 1 ? '' : 's') . ' taken off.', array_unique(array_column($take, 'src')), count($list), $n);
        }

        // 3. watched sources together on one item (report only), and 4. a new account with guests on one connection
        foreach ($byItem as $key => $list) {
            [$kind, $ref] = explode("\t", $key);
            $w = array_values(array_filter($list, fn ($r) => (int) $r['watched'] === 1));
            $srcs = array_unique(array_column($w, 'src'));
            if (count($srcs) >= self::GROUP)
                $flags += self::flag($pdo, $kind, $ref, 'group', count($srcs) . ' new accounts and guest visits liked it within the hour.', $srcs, count($list), 0);
            $byIp = [];
            foreach ($w as $r) $byIp[$r['ip_key']][] = $r;
            foreach ($byIp as $ip => $l) {
                $s = array_unique(array_column($l, 'src'));
                $guests = count(array_filter($s, fn ($x) => str_starts_with($x, 'g:'))); $members = count($s) - $guests;
                if ($guests >= 1 && $members >= 1)
                    $flags += self::flag($pdo, $kind, $ref, 'connection', $members . ' new account' . ($members === 1 ? '' : 's') . ' and ' . $guests . ' guest visit' . ($guests === 1 ? '' : 's') . ' on one connection (' . substr($ip, 0, 8) . '…).', $s, count($l), 0);
            }
        }

        // reported accounts stay on the closer checks until someone clears them
        $d = $pdo->prepare('DELETE FROM like_events WHERE created_at < ?'); $d->execute([date('Y-m-d H:i:s', time() - 30 * 86400)]);
        return 'Looked at ' . count($rows) . ' likes from the last hour: ' . $removed . ' taken off, ' . $flags . ' report' . ($flags === 1 ? '' : 's') . ' for Safety. Deleted ' . $d->rowCount() . ' older than 30 days.';
    }

    private static function group(array $list): array { $g = []; foreach ($list as $r) $g[$r['kind'] . "\t" . $r['ref']][] = $r; return $g; }

    /** Takes these likes off the count: a member's like is removed; a guest's comes off the item's guest count. */
    private static function void(PDO $pdo, array $list): int
    {
        $n = 0;
        foreach ($list as $r) {
            if ($r['voided_at'] !== null) continue;
            $u = $pdo->prepare('UPDATE like_events SET voided_at = NOW() WHERE id = ? AND voided_at IS NULL'); $u->execute([(int) $r['id']]);
            if (!$u->rowCount()) continue;
            if ($r['user_id']) $pdo->prepare('DELETE FROM content_likes WHERE kind = ? AND ref = ? AND user_id = ?')->execute([$r['kind'], $r['ref'], (int) $r['user_id']]);
            else $pdo->prepare('UPDATE content_like_tally SET guest_likes = GREATEST(guest_likes, 1) - 1 WHERE kind = ? AND ref = ?')->execute([$r['kind'], $r['ref']]);
            $n++;
        }
        return $n;
    }

    /** A report for Safety; one open report per item and reason (a repeat adds to it). Accounts in it stay watched. 1 when new. */
    private static function flag(PDO $pdo, string $kind, string $ref, string $reason, string $detail, array $srcs, int $likes, int $removed): int
    {
        foreach ($srcs as $s) if (str_starts_with((string) $s, 'u:'))
            $pdo->prepare("INSERT INTO like_watch (user_id, reason, since) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE reason = VALUES(reason), cleared_at = NULL, cleared_by = NULL")
                ->execute([(int) substr((string) $s, 2), self::REASONS[$reason]]);
        $st = $pdo->prepare("SELECT id, srcs FROM like_flags WHERE kind = ? AND ref = ? AND reason = ? AND status = 'open' LIMIT 1");
        $st->execute([$kind, $ref, $reason]);
        if ($f = $st->fetch(PDO::FETCH_ASSOC)) {
            $all = array_values(array_unique(array_merge((array) json_decode((string) $f['srcs'], true), array_values($srcs))));
            $pdo->prepare('UPDATE like_flags SET detail = ?, srcs = ?, likes = likes + ?, auto_removed = auto_removed + ? WHERE id = ?')
                ->execute([mb_substr($detail, 0, 500), json_encode($all), $likes, $removed, (int) $f['id']]);
            return 0;
        }
        $pdo->prepare('INSERT INTO like_flags (kind, ref, reason, detail, srcs, likes, auto_removed, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())')
            ->execute([$kind, $ref, $reason, mb_substr($detail, 0, 500), json_encode(array_values($srcs)), $likes, $removed]);
        return 1;
    }

    // ---- Safety (Pulse: likes:checks) -------------------------------------------------------------------------------

    /** Open reports, newest first, each with the item's name and page. */
    public static function flags(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [];
        $rows = $pdo->query("SELECT * FROM like_flags WHERE status = 'open' ORDER BY created_at DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) { [$r['label'], $r['url']] = self::item($pdo, (string) $r['kind'], (string) $r['ref']); $r['why'] = self::REASONS[$r['reason']] ?? $r['reason']; }
        unset($r);
        return $rows;
    }

    /** An item's name and page, as best we can: a listing's name, else what it is. */
    private static function item(PDO $pdo, string $kind, string $ref): array
    {
        if ($kind === 'listing' && ctype_digit($ref)) {
            try { $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([(int) $ref]); $n = (string) $st->fetchColumn(); if ($n !== '') return [$n, '/listing/view.php?id=' . (int) $ref]; } catch (Throwable) {}
            return ['Listing #' . $ref, '/listing/view.php?id=' . (int) $ref];
        }
        if ($kind === 'page' && ctype_digit($ref)) {   // one of our own pages (0159 step 4d)
            try { require_once __DIR__ . '/SitePages.php'; $p = SitePages::get($pdo, (int) $ref); if ($p) return [(string) $p['title'], SitePages::url($p)]; } catch (Throwable) {}
        }
        $names = ['rec' => 'Outdoor place', 'exp' => 'Experience', 'place' => 'Place', 'lm' => 'Landmark', 'guide' => 'Guide', 'how' => 'How-to', 'sj' => 'Suggested journey', 'page' => 'Page'];
        return [($names[$kind] ?? ucfirst($kind)) . ' ' . $ref, ''];
    }

    /**
     * A person decides a report: "clear" (looks fine: the accounts in it come off the closer checks) or "remove" (not
     * genuine: the likes in it that still count come off, and the accounts stay watched). Returns the message.
     */
    public static function decide(PDO $pdo, int $id, string $what, int $by): string
    {
        $st = $pdo->prepare("SELECT * FROM like_flags WHERE id = ? AND status = 'open'"); $st->execute([$id]);
        $f = $st->fetch(PDO::FETCH_ASSOC);
        if (!$f) throw new RuntimeException('That report has already been decided.');
        $srcs = array_map('strval', (array) json_decode((string) $f['srcs'], true));
        if ($what === 'clear') {
            $u = array_map(fn ($s) => (int) substr($s, 2), array_filter($srcs, fn ($s) => str_starts_with($s, 'u:')));
            foreach ($u as $uid) $pdo->prepare('UPDATE like_watch SET cleared_at = NOW(), cleared_by = ? WHERE user_id = ? AND cleared_at IS NULL')->execute([$by, $uid]);
            $pdo->prepare("UPDATE like_flags SET status = 'cleared', decided_at = NOW(), decided_by = ? WHERE id = ?")->execute([$by, $id]);
            return 'Cleared: the likes stay' . ($u ? ', and ' . count($u) . ' account' . (count($u) === 1 ? '' : 's') . ' came off the closer checks' : '') . '.';
        }
        if ($what !== 'remove') throw new RuntimeException('Choose Looks fine or Remove them.');
        $n = 0;
        if ($srcs) {
            $in = implode(',', array_fill(0, count($srcs), '?'));
            $ev = $pdo->prepare("SELECT * FROM like_events WHERE kind = ? AND ref = ? AND voided_at IS NULL AND src IN ($in)");
            $ev->execute(array_merge([$f['kind'], $f['ref']], $srcs));
            $n = self::void($pdo, $ev->fetchAll(PDO::FETCH_ASSOC));
        }
        $pdo->prepare("UPDATE like_flags SET status = 'removed', auto_removed = auto_removed + ?, decided_at = NOW(), decided_by = ? WHERE id = ?")->execute([$n, $by, $id]);
        return $n ? 'Removed ' . $n . ' like' . ($n === 1 ? '' : 's') . ' from the count.' : 'Marked not genuine; none of its likes were still counting.';
    }
}
