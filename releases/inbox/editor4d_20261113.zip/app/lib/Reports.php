<?php

declare(strict_types=1);

require_once __DIR__ . '/Community.php';

/**
 * api/lib/Reports.php — people report community posts and groups; admins decide (decisions/0047).
 *
 * One report per person per item. A post reported by 3 different people is hidden at once, pending an
 * admin's look (they can restore it). Admins remove (post removed, group hidden) or dismiss; either closes
 * every open report on that item. Reporters are never shown to the person reported.
 *
 * In groups (decisions/0137 §5): a report on a group's post goes to that group's own moderators (route 'group'), who
 * decide under their charter (Community::reportFiled, decideReport); Traversence's team never sees those. Two kinds come
 * to us instead, each opening a numbered Safety case in the Pulse at once (route 'staff'): "Breaks the law or puts
 * someone in danger" (reason 'unsafe'), where our Terms apply, and any report on a group as a whole.
 */
final class Reports
{
    public const REASONS = ['spam' => 'Spam or scam', 'harassment' => 'Harassment or hate', 'sacred_site' => 'Shows a sacred or restricted site',
                            'private_info' => 'Someone\'s private information', 'people' => 'Shows people without their consent',
                            'private_property' => 'Private property without permission', 'unsafe' => 'Breaks the law or puts someone in danger', 'other' => 'Something else'];
    /** Reasons that hide a group's post at its first report, as takedowns do (0137 §5). */
    public const HOLD_AT_ONCE = ['private_info', 'sacred_site', 'unsafe'];
    /** A listing's message (decisions/0052 §4): mislabelled is a Sales message sent under another type. */
    public const MESSAGE_REASONS = ['mislabelled' => 'Sales sent as another type', 'spam' => 'Spam or scam', 'harassment' => 'Harassment or hate', 'other' => 'Something else'];

    public static function label(string $reason): string
    {
        return self::REASONS[$reason] ?? self::MESSAGE_REASONS[$reason] ?? $reason;
    }
    private const AUTO_HIDE = 3;

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM content_reports LIMIT 1'); return true; } catch (PDOException) { return false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /** Whether 2027-01-17_group_reports.sql has run (reports routed to a group's moderators). */
    public static function routeReady(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT route FROM content_reports LIMIT 0'); $pdo->query('SELECT held_at FROM community_posts LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    /** The condition that keeps a group's own reports out of our team's lists: '' before the migration. */
    public static function staffOnly(PDO $pdo, string $alias = ''): string
    {
        return self::routeReady($pdo) ? ' AND ' . ($alias !== '' ? $alias . '.' : '') . "route <> 'group'" : '';
    }

    public static function file(PDO $pdo, int $uid, string $kind, int $target, string $reason, string $note): void
    {
        if (!isset(($kind === 'biz_message' ? self::MESSAGE_REASONS : self::REASONS)[$reason])) throw new InvalidArgumentException('Pick a reason.');
        if ($kind === 'biz_message') {
            // Only the person it was sent to can report a listing's message.
            $st = $pdo->prepare('SELECT 1 FROM business_messages WHERE id = ? AND user_id = ? AND from_business = 1');
            $st->execute([$target, $uid]);
            if ($st->fetchColumn() === false) throw new InvalidArgumentException('That message isn\'t yours to report.');
        } elseif ($kind === 'group_post') {
            $st = $pdo->prepare('SELECT group_id, user_id FROM community_posts WHERE id = ? AND removed_at IS NULL');
            $st->execute([$target]);
            $p = $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('That post is gone.');
            if ((int) $p['user_id'] === $uid) throw new InvalidArgumentException('That\'s your own post: remove it instead.');
            $m = Community::membership($pdo, (int) $p['group_id'], $uid);
            if (!$m || $m['status'] !== 'active') throw new InvalidArgumentException('Only members can report posts.');
        } elseif ($kind === 'group') {
            if (!Community::group($pdo, $target)) throw new InvalidArgumentException('That group isn\'t available.');
        } elseif ($kind === 'journey' || $kind === 'journey_comment') {   // decisions/0056: anyone signed in can report a journey or a comment
            $st = $pdo->prepare($kind === 'journey' ? "SELECT author_id FROM journeys WHERE id = ? AND status = 'published'" : "SELECT user_id FROM journey_comments WHERE id = ? AND status = 'visible'");
            $st->execute([$target]);
            $who = $st->fetchColumn();
            if ($who === false) throw new InvalidArgumentException('That isn\'t available.');
            if ((int) $who === $uid) throw new InvalidArgumentException('That\'s your own: edit or remove it instead.');
        } elseif ($kind === 'content_comment' || $kind === 'experience') {   // decisions/0058 §20, 0059: a comment on a page, or an experience
            $st = $pdo->prepare($kind === 'content_comment' ? "SELECT user_id FROM content_comments WHERE id = ? AND status = 'visible'" : "SELECT author_id FROM experiences WHERE id = ? AND status = 'published'");
            $st->execute([$target]);
            $who = $st->fetchColumn();
            if ($who === false) throw new InvalidArgumentException('That isn\'t available.');
            if ($who !== null && (int) $who === $uid) throw new InvalidArgumentException('That\'s your own: edit or remove it instead.');
        } elseif ($kind === 'market_post') {   // decisions/0135: anyone signed in can report a Marketplace post
            $st = $pdo->prepare("SELECT user_id FROM market_posts WHERE id = ? AND status IN ('active','pending')");
            $st->execute([$target]);
            $who = $st->fetchColumn();
            if ($who === false) throw new InvalidArgumentException('That isn\'t available.');
            if ((int) $who === $uid) throw new InvalidArgumentException('That\'s your own: change it or take it down instead.');
        } elseif ($kind === 'market_item') {   // a business's item on the Marketplace (decisions/0135 step 3)
            $st = $pdo->prepare("SELECT entity_id FROM market_items WHERE id = ? AND status = 'published'");
            $st->execute([$target]);
            if ($st->fetchColumn() === false) throw new InvalidArgumentException('That isn\'t available.');
        } elseif ($kind === 'market_note') {   // a note left after a Marketplace trade (decisions/0135 §5)
            $st = $pdo->prepare("SELECT from_id FROM market_notes WHERE id = ? AND status = 'visible'");
            $st->execute([$target]);
            $who = $st->fetchColumn();
            if ($who === false) throw new InvalidArgumentException('That isn\'t available.');
            if ((int) $who === $uid) throw new InvalidArgumentException('That\'s your own note.');
        } elseif ($kind === 'member_post') {   // a post on someone's profile (decisions/0153): anyone who can see it
            require_once __DIR__ . '/MemberPosts.php';
            $mp = MemberPosts::get($pdo, $target);
            if (!$mp || !MemberPosts::canSee($pdo, $mp, $uid)) throw new InvalidArgumentException('That isn\'t available.');
            if ((int) $mp['user_id'] === $uid) throw new InvalidArgumentException('That\'s your own post: change it or delete it instead.');
        } elseif ($kind === 'thread') {
            $st = $pdo->prepare('SELECT 1 FROM message_members WHERE thread_id = ? AND user_id = ?');   // only a member can report a conversation
            $st->execute([$target, $uid]);
            if ($st->fetchColumn() === false) throw new InvalidArgumentException('That conversation isn\'t yours.');
        } else {
            throw new InvalidArgumentException('That can\'t be reported.');
        }
        $st = $pdo->prepare('SELECT 1 FROM content_reports WHERE reporter_id = ? AND kind = ? AND target_id = ?');
        $st->execute([$uid, $kind, $target]);
        if ($st->fetchColumn() !== false) return;   // already reported: once is enough
        $note = mb_substr(trim(strip_tags($note)), 0, 500);
        if (self::routeReady($pdo)) {   // decisions/0137 §5: a group's post goes to its moderators, unless it's a matter of law or danger
            $route = $kind === 'group_post' && $reason !== 'unsafe' ? 'group' : 'staff';
            $pdo->prepare('INSERT INTO content_reports (reporter_id, kind, target_id, reason, note, created_at, route) VALUES (?, ?, ?, ?, ?, ?, ?)')
                ->execute([$uid, $kind, $target, $reason, $note, self::now(), $route]);
            $rid = (int) $pdo->lastInsertId();
            if ($kind === 'group_post') { require_once __DIR__ . '/Community.php'; Community::reportFiled($pdo, $target, $reason); }
            if ($kind === 'member_post') self::memberPostFiled($pdo, $target, $reason);
            if ($kind === 'group' || ($kind === 'group_post' && $reason === 'unsafe')) self::safetyTicket($pdo, $rid, $kind, $reason, $note);
            return;
        }
        $pdo->prepare('INSERT INTO content_reports (reporter_id, kind, target_id, reason, note, created_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$uid, $kind, $target, $reason, $note, self::now()]);
        if ($kind === 'member_post') self::memberPostFiled($pdo, $target, $reason);
        if ($kind === 'group_post') {
            $st = $pdo->prepare("SELECT COUNT(*) FROM content_reports WHERE kind = 'group_post' AND target_id = ? AND status = 'open'");
            $st->execute([$target]);
            if ((int) $st->fetchColumn() >= self::AUTO_HIDE) $pdo->prepare('UPDATE community_posts SET removed_at = ? WHERE id = ? AND removed_at IS NULL')->execute([self::now(), $target]);
        }
    }

    /** A post on a profile reported (decisions/0153 §5): a compressed copy is held, and it's hidden at the third report, or
     *  at once for the reasons that hide at once. */
    private static function memberPostFiled(PDO $pdo, int $id, string $reason): void
    {
        require_once __DIR__ . '/MemberPosts.php';
        $st = $pdo->prepare("SELECT COUNT(*) FROM content_reports WHERE kind = 'member_post' AND target_id = ? AND status = 'open'");
        $st->execute([$id]);
        try { MemberPosts::reported($pdo, $id, $reason, in_array($reason, self::HOLD_AT_ONCE, true) || (int) $st->fetchColumn() >= self::AUTO_HIDE); }
        catch (Throwable $e) { error_log('member post report ' . $id . ': ' . $e->getMessage()); }
    }

    /** Opens the Safety case for a report that comes to Traversence (0137 §5): numbered at once, the report as its first entry. */
    private static function safetyTicket(PDO $pdo, int $rid, string $kind, string $reason, string $note): void
    {
        if (!is_file(__DIR__ . '/Pulse.php')) return;
        try {
            require_once __DIR__ . '/Pulse.php';
            Pulse::openTicket($pdo, 'report:' . $rid, (self::KIND_LABEL[$kind] ?? 'Report') . ': ' . self::label($reason) . ($note !== '' ? '. ' . $note : '.'));
        } catch (Throwable $e) { error_log('safety ticket: ' . $e->getMessage()); }
    }

    public static function openCount(PDO $pdo): int
    {
        if (!self::ready($pdo)) return 0;
        // the reports that lost what they were about are one item (dismissed together), as on the Reports page
        return (int) $pdo->query("SELECT COUNT(*) FROM (SELECT 1 FROM content_reports WHERE status = 'open'" . self::staffOnly($pdo) . " GROUP BY kind, CASE WHEN kind = '' THEN 0 ELSE target_id END) x")->fetchColumn();
    }

    /**
     * Reports filed with a blank kind (before 2026-10-25_reports_kinds.sql: the table's list lacked page comments and
     * experiences) get their kind back when the target can only be one thing: a page comment or an experience.
     * Returns how many were repaired. Needs the migration (the kind as text); without it, nothing changes.
     */
    public static function repairBlank(PDO $pdo): int
    {
        $fixed = 0;
        try {
            $ids = $pdo->query("SELECT DISTINCT target_id FROM content_reports WHERE kind = '' AND status = 'open'")->fetchAll(PDO::FETCH_COLUMN);
            $has = function (string $sql, int $id) use ($pdo): bool { try { $st = $pdo->prepare($sql); $st->execute([$id]); return (bool) $st->fetchColumn(); } catch (Throwable) { return false; } };
            foreach ($ids as $id) {
                $id = (int) $id;
                $cc = $has('SELECT 1 FROM content_comments WHERE id = ?', $id);
                $ex = $has('SELECT 1 FROM experiences WHERE id = ?', $id);
                if ($cc === $ex) continue;   // both or neither: can't tell, so it stays lost
                $st = $pdo->prepare("UPDATE content_reports SET kind = ? WHERE kind = '' AND target_id = ?");
                $st->execute([$cc ? 'content_comment' : 'experience', $id]);
                $fixed += $st->rowCount();
            }
        } catch (Throwable $e) { error_log('reports repair: ' . $e->getMessage()); }
        return $fixed;
    }

    /** Open items, most-reported first, with what was reported. */
    public static function open(PDO $pdo): array
    {
        self::repairBlank($pdo);
        $lost = ['n' => 0, 'reports' => [], 'first_at' => ''];
        $rows = $pdo->query("SELECT kind, target_id, COUNT(*) AS n, MIN(created_at) AS first_at FROM content_reports WHERE status = 'open'" . self::staffOnly($pdo) . "
                              GROUP BY kind, target_id ORDER BY n DESC, first_at LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        $out = [];
        foreach ($rows as $r) {
            $kind = (string) $r['kind'];
            $id = (int) $r['target_id'];
            $rs = $pdo->prepare("SELECT reason, note FROM content_reports WHERE kind = ? AND target_id = ? AND status = 'open' ORDER BY id");
            $rs->execute([$kind, $id]);
            $item = ['kind' => $kind, 'id' => $id, 'count' => (int) $r['n'], 'first_at' => (string) $r['first_at'], 'reports' => $rs->fetchAll(PDO::FETCH_ASSOC)];
            // filed with a blank kind and not repairable: one item for all of them, dismissed together
            if ($kind === '') {
                $lost['n'] += (int) $r['n']; $lost['reports'] = array_merge($lost['reports'], $item['reports']);
                if ($lost['first_at'] === '' || $r['first_at'] < $lost['first_at']) $lost['first_at'] = (string) $r['first_at'];
                continue;
            }
            // what was reported has since been deleted: say so, rather than leave it out while it's still counted
            $gone = $item + ['text' => 'What was reported is gone: it was deleted after the report.', 'author' => '', 'author_id' => 0, 'where' => self::KIND_LABEL[$kind] ?? 'Something', 'group_id' => 0, 'hidden' => false, 'gone' => true];
            if ($kind === 'group_post') {
                $st = $pdo->prepare('SELECT p.body, p.user_id, p.removed_at, p.group_id, g.name AS group_name FROM community_posts p JOIN community_groups g ON g.id = p.group_id WHERE p.id = ?');
                $st->execute([$id]);
                $p = $st->fetch(PDO::FETCH_ASSOC);
                if (!$p) { $out[] = $gone; continue; }
                $u = People::user($pdo, (int) $p['user_id']);
                $item += ['text' => (string) $p['body'], 'author' => $u ? People::name($u) : 'Someone who left', 'author_id' => (int) $p['user_id'],
                          'where' => (string) $p['group_name'], 'group_id' => (int) $p['group_id'], 'hidden' => $p['removed_at'] !== null];
            } elseif ($kind === 'thread') {
                // What an admin needs to judge it: the recent messages in that conversation (the reporter chose to share them).
                $st = $pdo->prepare('SELECT m.sender_id, m.body, m.created_at FROM messages m WHERE m.thread_id = ? ORDER BY m.id DESC LIMIT 10');
                $st->execute([$id]);
                $lines = [];
                foreach (array_reverse($st->fetchAll(PDO::FETCH_ASSOC)) as $m) {
                    $u = People::user($pdo, (int) $m['sender_id']);
                    $lines[] = ($u ? People::name($u) : 'Someone') . ': ' . $m['body'];
                }
                $item += ['text' => implode("\n", $lines), 'author' => '', 'author_id' => 0, 'where' => 'Conversation', 'group_id' => 0, 'hidden' => false];
            } elseif ($kind === 'journey' || $kind === 'journey_comment') {
                $st = $pdo->prepare($kind === 'journey' ? 'SELECT id, author_id AS uid, title AS t, body, status FROM journeys WHERE id = ?'
                    : 'SELECT c.journey_id AS id, c.user_id AS uid, j.title AS t, c.body, c.status FROM journey_comments c JOIN journeys j ON j.id = c.journey_id WHERE c.id = ?');
                $st->execute([$id]);
                $j = $st->fetch(PDO::FETCH_ASSOC);
                if (!$j) { $out[] = $gone; continue; }
                $u = People::user($pdo, (int) $j['uid']);
                $item += ['text' => ($kind === 'journey' ? $j['t'] . ': ' : '') . mb_strimwidth(strip_tags((string) $j['body']), 0, 600, '…'), 'author' => $u ? People::name($u) : 'Someone who left',
                          'author_id' => (int) $j['uid'], 'where' => $kind === 'journey' ? 'Journey' : 'Comment on “' . $j['t'] . '”', 'group_id' => 0,
                          'hidden' => in_array($j['status'], ['hidden'], true), 'url' => '/journeys/view.php?id=' . (int) $j['id']];
            } elseif ($kind === 'content_comment' || $kind === 'experience') {
                $st = $pdo->prepare($kind === 'experience' ? 'SELECT id, author_id AS uid, title AS t, summary AS body, status FROM experiences WHERE id = ?'
                    : 'SELECT kind, ref, user_id AS uid, body, status FROM content_comments WHERE id = ?');
                $st->execute([$id]);
                $c = $st->fetch(PDO::FETCH_ASSOC);
                if (!$c) { $out[] = $gone; continue; }
                $u = $c['uid'] ? People::user($pdo, (int) $c['uid']) : null;
                $url = $kind === 'experience' ? '/experiences/view.php?id=' . (int) $c['id']
                    : ($c['kind'] === 'place' ? (function () use ($pdo, $c) { try { require_once __DIR__ . '/Links.php'; return Links::resolve($pdo, 'place', (string) $c['ref'])[1]; } catch (Throwable) { return ''; } })()
                    : ($c['kind'] === 'page' ? (function () use ($pdo, $c) { try { require_once __DIR__ . '/SitePages.php'; $p = SitePages::get($pdo, (int) $c['ref']); return $p ? SitePages::url($p) : ''; } catch (Throwable) { return ''; } })()
                       : (['listing' => '/listing/view.php?id=', 'rec' => '/place/recreation.php?id=', 'exp' => '/experiences/view.php?id=', 'lm' => '/place/landmark.php?id=',
                           'guide' => '/guide/resources.php?id=', 'how' => '/guide/how.php?id=', 'sj' => '/journeys/suggested.php?id='][$c['kind']] ?? '/?') . rawurlencode((string) $c['ref'])));
                $item += ['text' => ($kind === 'experience' ? $c['t'] . ': ' : '') . mb_strimwidth(strip_tags((string) $c['body']), 0, 600, '…'), 'author' => $u ? People::name($u) : 'Traversence',
                          'author_id' => (int) $c['uid'], 'where' => $kind === 'experience' ? 'Experience' : 'Comment on a page', 'group_id' => 0,
                          'hidden' => $c['status'] === 'hidden', 'url' => $url];
            } elseif ($kind === 'market_post') {
                $st = $pdo->prepare('SELECT id, user_id, title, about, price_mode, price_cents, place_label, status FROM market_posts WHERE id = ?');
                $st->execute([$id]);
                $p = $st->fetch(PDO::FETCH_ASSOC);
                if (!$p) { $out[] = $gone; continue; }
                require_once __DIR__ . '/Market.php';
                $u = People::user($pdo, (int) $p['user_id']);
                $item += ['text' => $p['title'] . ' (' . Market::price($p) . ', ' . $p['place_label'] . '): ' . mb_strimwidth(strip_tags((string) $p['about']), 0, 500, '…'), 'author' => $u ? People::name($u) : 'Someone who left',
                          'author_id' => (int) $p['user_id'], 'where' => 'Marketplace post', 'group_id' => 0, 'hidden' => $p['status'] === 'removed', 'url' => '/market/view.php?id=' . (int) $p['id']];
            } elseif ($kind === 'market_item') {
                $st = $pdo->prepare('SELECT i.*, e.name AS biz FROM market_items i LEFT JOIN entities e ON e.id = i.entity_id WHERE i.id = ?');
                $st->execute([$id]);
                $mi = $st->fetch(PDO::FETCH_ASSOC);
                if (!$mi) { $out[] = $gone; continue; }
                $item += ['text' => $mi['title'] . ': ' . mb_strimwidth((string) $mi['about'], 0, 500, '…'), 'author' => (string) ($mi['biz'] ?? 'A business'), 'author_id' => 0,
                          'where' => 'A business\'s item on the Marketplace', 'group_id' => 0, 'hidden' => $mi['status'] === 'removed', 'url' => '/market/item.php?id=' . (int) $mi['id']];
            } elseif ($kind === 'market_note') {
                $st = $pdo->prepare('SELECT n.*, p.id AS post_id, p.title FROM market_notes n LEFT JOIN market_offers o ON o.id = n.offer_id LEFT JOIN market_posts p ON p.id = o.post_id WHERE n.id = ?');
                $st->execute([$id]);
                $n = $st->fetch(PDO::FETCH_ASSOC);
                if (!$n) { $out[] = $gone; continue; }
                $u = People::user($pdo, (int) $n['from_id']); $about = People::user($pdo, (int) $n['about_id']);
                $item += ['text' => (string) $n['body'], 'author' => $u ? People::name($u) : 'Someone who left', 'author_id' => (int) $n['from_id'],
                          'where' => 'Note about ' . ($about ? People::name($about) : 'a member') . ' after a Marketplace trade' . ($n['title'] ? ' (' . $n['title'] . ')' : ''), 'group_id' => 0,
                          'hidden' => $n['status'] === 'hidden', 'url' => $n['post_id'] ? '/market/view.php?id=' . (int) $n['post_id'] : ''];
            } elseif ($kind === 'biz_message') {
                $type = '';
                try {
                    $st = $pdo->prepare('SELECT m.body, m.msg_type, e.name FROM business_messages m LEFT JOIN entities e ON e.id = m.entity_id WHERE m.id = ?');
                    $st->execute([$id]);
                    $m = $st->fetch(PDO::FETCH_ASSOC);
                } catch (PDOException) { $m = false; }
                if (!$m) { $out[] = $gone; continue; }
                require_once __DIR__ . '/BizMessages.php';
                $type = BizMessages::TYPES[(string) $m['msg_type']] ?? 'Untyped';
                $item += ['text' => (string) $m['body'], 'author' => (string) ($m['name'] ?? 'A listing'), 'author_id' => 0,
                          'where' => 'Listing message, sent as ' . $type, 'group_id' => 0, 'hidden' => false];
            } elseif ($kind === 'member_post') {
                require_once __DIR__ . '/MemberPosts.php';
                $mp = MemberPosts::forReport($pdo, $id);
                if (!$mp) { $out[] = $gone; continue; }
                $item += $mp + ['where' => 'Post on a profile', 'group_id' => 0];
            } elseif ($kind === 'group') {
                $g = Community::group($pdo, $id, true);
                if (!$g) { $out[] = $gone; continue; }
                $item += ['text' => (string) $g['name'] . ($g['about'] ? ': ' . $g['about'] : ''), 'author' => '', 'author_id' => (int) $g['owner_id'],
                          'where' => 'Group', 'group_id' => $id, 'hidden' => $g['status'] === 'hidden'];
            } else {   // a kind this page doesn't know yet: shown, never silently left out
                $item += ['text' => 'A report on something this page can\'t show yet (' . $kind . ' #' . $id . ').', 'author' => '', 'author_id' => 0, 'where' => $kind, 'group_id' => 0, 'hidden' => false, 'gone' => true];
            }
            $out[] = $item;
        }
        if ($lost['n']) $out[] = ['kind' => 'lost', 'id' => 0, 'count' => $lost['n'], 'first_at' => $lost['first_at'], 'reports' => $lost['reports'], 'hidden' => false, 'author' => '', 'author_id' => 0, 'group_id' => 0,
                                  'where' => 'Reports that lost what they were about',
                                  'text' => 'Filed before a database fix, these reports lost what they were about, so there\'s nothing to look at. Their reasons and notes are below. Dismiss them together; the people who filed them can report again if it still matters.', 'gone' => true];
        return $out;
    }

    /** remove: take the post down or hide the group; dismiss: leave it as it is; restore: bring back a post hidden by reports. */
    /** What each kind of report is, for headings. */
    public const KIND_LABEL = ['group_post' => 'Post in a group', 'group' => 'Group', 'thread' => 'Conversation', 'biz_message' => 'Listing message', 'journey' => 'Journey',
                               'journey_comment' => 'Comment on a journey', 'content_comment' => 'Comment on a page', 'experience' => 'Experience', 'market_post' => 'Marketplace post', 'market_note' => 'Note after a Marketplace trade', 'market_item' => 'A business\'s Marketplace item', 'member_post' => 'Post on a profile'];

    public static function decide(PDO $pdo, int $admin, string $kind, int $id, string $what): void
    {
        if ($kind === 'lost' && $what === 'dismiss') {   // the blank ones, together
            $pdo->prepare("UPDATE content_reports SET status = 'dismissed', handled_by = ?, handled_at = ? WHERE kind = '' AND status = 'open'")->execute([$admin, self::now()]);
            return;
        }
        if (!in_array($what, ['remove', 'dismiss', 'restore'], true)) throw new InvalidArgumentException('Unknown action.');
        // any report can be dismissed (even of a kind this page can't show); removing and restoring need a known kind
        if ($what !== 'dismiss' && !in_array($kind, ['group_post', 'group', 'thread', 'biz_message', 'journey', 'journey_comment', 'content_comment', 'experience', 'market_post', 'market_note', 'market_item', 'member_post'], true)) throw new InvalidArgumentException('Unknown action.');
        if ($kind === '' || mb_strlen($kind) > 20) throw new InvalidArgumentException('Unknown action.');
        if ($kind === 'content_comment' && $what !== 'dismiss') { require_once __DIR__ . '/Engage.php'; Engage::setCommentHidden($pdo, $id, $what === 'remove'); }
        if ($kind === 'experience' && $what !== 'dismiss') {
            $pdo->prepare('UPDATE experiences SET status = ?, review_note = ? WHERE id = ?')->execute([$what === 'remove' ? 'hidden' : 'published', $what === 'remove' ? 'Hidden after reports' : '', $id]);
        }
        if ($kind === 'market_post' && $what !== 'dismiss') {   // the seller sees it was taken down after reports (decisions/0135)
            require_once __DIR__ . '/Market.php';
            try { Market::staffAct($pdo, $admin, $id, $what === 'remove' ? 'remove' : 'restore', 'reported by people who saw it, and our team agreed'); } catch (InvalidArgumentException) {}
        }
        if ($kind === 'market_item' && $what !== 'dismiss') { require_once __DIR__ . '/MarketBiz.php'; try { MarketBiz::staffAct($pdo, $id, $what === 'remove' ? 'remove' : 'restore', 'reported by people who saw it, and our team agreed'); } catch (InvalidArgumentException) {} }
        if ($kind === 'market_note' && $what !== 'dismiss') { require_once __DIR__ . '/MarketOffers.php'; MarketOffers::setNoteHidden($pdo, $id, $what === 'remove'); }
        if ($kind === 'journey' && $what !== 'dismiss') {   // hidden stays visible to its author (decisions/0056 §6)
            require_once __DIR__ . '/Journeys.php';
            Journeys::setHidden($pdo, $id, $what === 'remove', 'Hidden after reports');
        }
        if ($kind === 'journey_comment' && $what !== 'dismiss') {
            require_once __DIR__ . '/Journeys.php';
            Journeys::setCommentHidden($pdo, $id, $what === 'remove');
        }
        if ($kind === 'member_post') { require_once __DIR__ . '/MemberPosts.php'; MemberPosts::decided($pdo, $id, $what); }   // its held copy stays 90 more days (0153 §9)
        if ($kind === 'group_post' && $what === 'remove') $pdo->prepare('UPDATE community_posts SET removed_at = COALESCE(removed_at, ?) WHERE id = ?')->execute([self::now(), $id]);
        if ($kind === 'group_post' && $what === 'restore') $pdo->prepare('UPDATE community_posts SET removed_at = NULL WHERE id = ?')->execute([$id]);
        if ($kind === 'group' && $what === 'remove') $pdo->prepare("UPDATE community_groups SET status = 'hidden' WHERE id = ?")->execute([$id]);
        if ($kind === 'group' && $what === 'restore') $pdo->prepare("UPDATE community_groups SET status = 'active' WHERE id = ?")->execute([$id]);
        // the author's standing (decisions/0079): a take-down lowers their trust, and may open a warning; a restore gives it back
        $author = in_array($what, ['remove', 'restore'], true) ? self::authorOf($pdo, $kind, $id) : 0;
        $reasons = [];
        if ($author && $what === 'remove') {
            $rs = $pdo->prepare("SELECT DISTINCT reason FROM content_reports WHERE kind = ? AND target_id = ? AND status = 'open'");
            $rs->execute([$kind, $id]);
            $reasons = array_map(fn ($r) => mb_strtolower(self::label((string) $r)), $rs->fetchAll(PDO::FETCH_COLUMN));
        }
        $pdo->prepare("UPDATE content_reports SET status = ?, handled_by = ?, handled_at = ? WHERE kind = ? AND target_id = ? AND status = 'open'")
            ->execute([$what === 'remove' ? 'removed' : 'dismissed', $admin, self::now(), $kind, $id]);
        if ($kind === 'group_post' && $what !== 'remove') { require_once __DIR__ . '/Community.php'; Community::unholdIfClear($pdo, $id); }   // let it show again unless the group still has it in hand
        if ($author) {
            require_once __DIR__ . '/Standing.php';
            try {
                if ($what === 'remove') Standing::contentRemoved($pdo, $author, mb_strtolower(self::KIND_LABEL[$kind] ?? 'a post'), $reasons, $admin);
                else Standing::contentRestored($pdo, $author);
            } catch (Throwable $e) { error_log('standing: ' . $e->getMessage()); }
        }
    }

    /** Who wrote what was reported (0 for a conversation, a listing's message, or something gone). */
    private static function authorOf(PDO $pdo, string $kind, int $id): int
    {
        $sql = ['group_post' => 'SELECT user_id FROM community_posts WHERE id = ?', 'group' => 'SELECT owner_id FROM community_groups WHERE id = ?',
                'journey' => 'SELECT author_id FROM journeys WHERE id = ?', 'journey_comment' => 'SELECT user_id FROM journey_comments WHERE id = ?',
                'content_comment' => 'SELECT user_id FROM content_comments WHERE id = ?', 'experience' => 'SELECT author_id FROM experiences WHERE id = ?',
                'market_post' => 'SELECT user_id FROM market_posts WHERE id = ?', 'market_note' => 'SELECT from_id FROM market_notes WHERE id = ?',
                'member_post' => 'SELECT user_id FROM member_post_holds WHERE post_id = ?'][$kind] ?? null;
        if (!$sql) return 0;
        try { $st = $pdo->prepare($sql); $st->execute([$id]); return (int) $st->fetchColumn(); } catch (Throwable) { return 0; }
    }
}
