<?php
// app/lib/SitePages.php — Storefront & pages (business-portal-architecture.md, "Admin first"): an owner's own pages
// (About, Services, FAQ, Contact...) with their SEO title, description and share image, and the forms on them, whose
// entries become leads in Customers. owner_id 0 is Traversence; a business's pages carry its listing id once the
// business portal scopes the tools. Pages and entries are public-side data (like orders), so they live in main.
// Pages are written in a little Markdown: ## and ### headings, paragraphs, "- " lists, **bold**, *italic*,
// [links](/path or https://...) and ![pictures](https://... or /uploads/...).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class SitePages
{
    public const STATUSES = ['draft' => 'Draft', 'live' => 'Live', 'hidden' => 'Hidden'];
    public const FORMS = ['none' => 'No form', 'contact' => 'Contact form', 'quote' => 'Ask for a quote'];
    public const ENTRY_STATUSES = ['new' => 'New', 'handled' => 'Handled', 'spam' => 'Spam'];
    private const PER_HOUR = 5;   // form entries from one internet address in an hour

    private static bool $ready = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci';
        $pdo->exec('CREATE TABLE IF NOT EXISTS site_pages (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, owner_id INT UNSIGNED NOT NULL DEFAULT 0,
            slug VARCHAR(80) NOT NULL, title VARCHAR(120) NOT NULL, summary VARCHAR(300) NOT NULL DEFAULT \'\', body MEDIUMTEXT NOT NULL, form VARCHAR(10) NOT NULL DEFAULT \'none\',
            status VARCHAR(8) NOT NULL DEFAULT \'draft\', share_image VARCHAR(255) NOT NULL DEFAULT \'\', updated_by INT UNSIGNED DEFAULT NULL,
            created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, UNIQUE KEY uq_site_page (owner_id, slug))' . $tail);
        $pdo->exec('CREATE TABLE IF NOT EXISTS site_form_entries (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, owner_id INT UNSIGNED NOT NULL DEFAULT 0,
            page_id INT UNSIGNED NOT NULL, kind VARCHAR(10) NOT NULL, name VARCHAR(120) NOT NULL DEFAULT \'\', email VARCHAR(190) NOT NULL DEFAULT \'\',
            phone VARCHAR(40) NOT NULL DEFAULT \'\', message TEXT NOT NULL, ip_hash CHAR(64) NOT NULL DEFAULT \'\', status VARCHAR(8) NOT NULL DEFAULT \'new\',
            created_at DATETIME NOT NULL, KEY idx_sfe_owner (owner_id, status, created_at), KEY idx_sfe_ip (ip_hash, created_at), KEY idx_sfe_email (email))' . $tail);
        self::$ready = true;
    }

    public static function all(PDO $pdo, int $owner = 0): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT p.*, (SELECT COUNT(*) FROM site_form_entries e WHERE e.page_id = p.id AND e.status = \'new\') AS new_entries FROM site_pages p WHERE p.owner_id = ? ORDER BY p.status = \'live\' DESC, p.title');
        $st->execute([$owner]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function get(PDO $pdo, int $id, int $owner = 0): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM site_pages WHERE id = ? AND owner_id = ?'); $st->execute([$id, $owner]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function bySlug(PDO $pdo, string $slug, int $owner = 0): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM site_pages WHERE owner_id = ? AND slug = ?'); $st->execute([$owner, $slug]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function url(array $p): string { return '/pages/view.php?s=' . rawurlencode((string) $p['slug']); }

    public static function slugify(string $s): string { return trim(substr(preg_replace('/[^a-z0-9]+/', '-', strtolower($s)), 0, 80), '-'); }

    /** A new draft page, with an address made from its title. */
    public static function create(PDO $pdo, string $title, int $uid, int $owner = 0): int
    {
        self::ensure($pdo);
        $title = trim($title);
        if ($title === '') throw new InvalidArgumentException('Give the page a title.');
        $slug = self::slugify($title) ?: 'page'; $base = $slug; $n = 2;
        while (self::bySlug($pdo, $slug, $owner)) $slug = substr($base, 0, 76) . '-' . $n++;
        $now = date('Y-m-d H:i:s');
        $pdo->prepare('INSERT INTO site_pages (owner_id, slug, title, body, updated_by, created_at, updated_at) VALUES (?, ?, ?, \'\', ?, ?, ?)')->execute([$owner, $slug, mb_substr($title, 0, 120), $uid ?: null, $now, $now]);
        return (int) $pdo->lastInsertId();
    }

    /** Changes any of: title, slug, summary, body, form, status, share_image. */
    public static function save(PDO $pdo, int $id, array $in, int $uid, int $owner = 0): void
    {
        $p = self::get($pdo, $id, $owner);
        if (!$p) throw new InvalidArgumentException('That page isn\'t here.');
        $v = [];
        if (array_key_exists('title', $in)) { $t = trim((string) $in['title']); if ($t === '') throw new InvalidArgumentException('A page needs a title.'); $v['title'] = mb_substr($t, 0, 120); }
        if (array_key_exists('slug', $in)) {
            $s = self::slugify((string) $in['slug']);
            if ($s === '') throw new InvalidArgumentException('The address needs letters or numbers.');
            $o = self::bySlug($pdo, $s, $owner);
            if ($o && (int) $o['id'] !== $id) throw new InvalidArgumentException('Another page already uses /' . $s . '.');
            $v['slug'] = $s;
        }
        if (array_key_exists('summary', $in)) $v['summary'] = mb_substr(trim(preg_replace('/\s+/', ' ', (string) $in['summary'])), 0, 300);
        if (array_key_exists('body', $in)) $v['body'] = mb_substr(str_replace("\r", '', (string) $in['body']), 0, 60000);
        if (array_key_exists('form', $in) && isset(self::FORMS[$in['form']])) $v['form'] = (string) $in['form'];
        if (array_key_exists('status', $in) && isset(self::STATUSES[$in['status']])) $v['status'] = (string) $in['status'];
        if (array_key_exists('share_image', $in)) {
            $img = trim((string) $in['share_image']);
            if ($img !== '' && !preg_match('#^(https://|/uploads/|/image/)#', $img)) throw new InvalidArgumentException('The share picture is a link starting with https:// or /uploads/.');
            $v['share_image'] = mb_substr($img, 0, 255);
        }
        if (($v['status'] ?? $p['status']) === 'live' && trim((string) ($v['body'] ?? $p['body'])) === '' && ($v['form'] ?? $p['form']) === 'none') throw new InvalidArgumentException('Write the page (or add a form) before it goes live.');
        if (!$v) return;
        $set = implode(', ', array_map(fn ($k) => "$k = ?", array_keys($v)));
        $pdo->prepare("UPDATE site_pages SET $set, updated_by = ?, updated_at = NOW() WHERE id = ? AND owner_id = ?")->execute([...array_values($v), $uid ?: null, $id, $owner]);
    }

    // ---- what visitors see ---------------------------------------------------------------------------------------------

    /** The page's Markdown as HTML. Everything is escaped; links and pictures only to our own paths or https. */
    public static function html(string $md): string
    {
        $out = []; $para = []; $list = [];
        $flushP = function () use (&$para, &$out) { if ($para) { $out[] = '<p>' . self::inline(implode(' ', $para)) . '</p>'; $para = []; } };
        $flushL = function () use (&$list, &$out) { if ($list) { $out[] = '<ul>' . implode('', array_map(fn ($i) => '<li>' . self::inline($i) . '</li>', $list)) . '</ul>'; $list = []; } };
        foreach (explode("\n", $md) as $line) {
            $t = rtrim($line);
            if (trim($t) === '') { $flushP(); $flushL(); continue; }
            if (preg_match('/^(#{2,3})\s+(.+)$/', $t, $m)) { $flushP(); $flushL(); $lv = strlen($m[1]); $out[] = '<h' . $lv . '>' . self::inline($m[2]) . '</h' . $lv . '>'; continue; }
            if (preg_match('/^\s*[-*]\s+(.+)$/', $t, $m)) { $flushP(); $list[] = $m[1]; continue; }
            if (preg_match('/^!\[([^\]]*)\]\(([^)\s]+)\)\s*$/', trim($t), $m) && self::okUrl($m[2], true)) { $flushP(); $flushL(); $out[] = '<figure><img src="' . htmlspecialchars($m[2], ENT_QUOTES) . '" alt="' . htmlspecialchars($m[1], ENT_QUOTES) . '" loading="lazy">' . ($m[1] !== '' ? '<figcaption>' . htmlspecialchars($m[1]) . '</figcaption>' : '') . '</figure>'; continue; }
            $flushL(); $para[] = trim($t);
        }
        $flushP(); $flushL();
        return implode("\n", $out);
    }

    private static function inline(string $s): string
    {
        $s = htmlspecialchars($s, ENT_QUOTES);
        $s = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $s);
        $s = preg_replace('/(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?!\w)/', '<em>$1</em>', $s);
        return preg_replace_callback('/\[([^\]]+)\]\(([^)\s]+)\)/', function ($m) {
            $u = html_entity_decode($m[2], ENT_QUOTES);
            if (!self::okUrl($u, false)) return $m[1];
            return '<a href="' . htmlspecialchars($u, ENT_QUOTES) . '"' . (str_starts_with($u, 'http') ? ' rel="noopener" target="_blank"' : '') . '>' . $m[1] . '</a>';
        }, $s);
    }

    private static function okUrl(string $u, bool $img): bool
    {
        return $img ? (bool) preg_match('#^(https://|/uploads/|/image/)#', $u) : (bool) preg_match('#^(/(?!/)|https://|mailto:|tel:|\#)#', $u);
    }

    /** Words in a page (for the list). */
    public static function words(string $md): int { return str_word_count(strip_tags(self::html($md))); }

    // ---- forms -------------------------------------------------------------------------------------------------------

    /** A visitor's form entry. Throws with a message for them on a problem. */
    public static function submit(PDO $pdo, array $page, array $in, string $ip): int
    {
        self::ensure($pdo);
        $kind = (string) $page['form'];
        $want = (string) ($in['kind'] ?? '');   // a form block on the page (decisions/0159 step 4d): taken while the page's live blocks hold one of that kind
        if ($want !== '' && $want !== $kind && $want !== 'none' && isset(self::FORMS[$want])) {
            require_once __DIR__ . '/Blocks.php';
            if (Blocks::hasForm($pdo, (int) $page['id'], $want)) $kind = $want;
        }
        if ($page['status'] !== 'live' || $kind === 'none') throw new InvalidArgumentException('This form isn\'t taking messages.');
        if (trim((string) ($in['website'] ?? '')) !== '') return 0;   // the hidden box only robots fill in
        $name = trim((string) ($in['name'] ?? '')); $email = strtolower(trim((string) ($in['email'] ?? ''))); $msg = trim((string) ($in['message'] ?? ''));
        if ($name === '') throw new InvalidArgumentException('Please give your name.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Please check your email address.');
        if (mb_strlen($msg) < 5) throw new InvalidArgumentException('Please write your message.');
        $iph = hash('sha256', 'tvform|' . $ip);
        $st = $pdo->prepare('SELECT COUNT(*) FROM site_form_entries WHERE ip_hash = ? AND created_at > NOW() - INTERVAL 1 HOUR'); $st->execute([$iph]);
        if ((int) $st->fetchColumn() >= self::PER_HOUR) throw new RuntimeException('That\'s a lot of messages in an hour. Please try again later.');
        $pdo->prepare('INSERT INTO site_form_entries (owner_id, page_id, kind, name, email, phone, message, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())')
            ->execute([(int) $page['owner_id'], (int) $page['id'], $kind, mb_substr($name, 0, 120), mb_substr($email, 0, 190), mb_substr(trim((string) ($in['phone'] ?? '')), 0, 40), mb_substr($msg, 0, 5000), $iph]);
        return (int) $pdo->lastInsertId();
    }

    public static function entries(PDO $pdo, int $owner = 0, string $status = '', string $q = ''): array
    {
        self::ensure($pdo);
        $w = ['e.owner_id = ?']; $a = [$owner];
        if ($status !== '') { $w[] = 'e.status = ?'; $a[] = $status; }
        if ($q !== '') { $w[] = '(e.name LIKE ? OR e.email LIKE ? OR e.message LIKE ?)'; array_push($a, "%$q%", "%$q%", "%$q%"); }
        $st = $pdo->prepare('SELECT e.*, p.title AS page_title, p.slug FROM site_form_entries e LEFT JOIN site_pages p ON p.id = e.page_id WHERE ' . implode(' AND ', $w) . ' ORDER BY e.id DESC LIMIT 500');
        $st->execute($a);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function entry(PDO $pdo, int $id, int $owner = 0): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT e.*, p.title AS page_title, p.slug FROM site_form_entries e LEFT JOIN site_pages p ON p.id = e.page_id WHERE e.id = ? AND e.owner_id = ?'); $st->execute([$id, $owner]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function markEntry(PDO $pdo, int $id, string $status, int $owner = 0): void
    {
        if (!isset(self::ENTRY_STATUSES[$status])) throw new InvalidArgumentException('Choose New, Handled or Spam.');
        if (!self::entry($pdo, $id, $owner)) throw new InvalidArgumentException('That entry isn\'t here.');
        $pdo->prepare('UPDATE site_form_entries SET status = ? WHERE id = ? AND owner_id = ?')->execute([$status, $id, $owner]);
    }
}
