<?php
// /api/blocks.php — the editor's core (decisions/0159 §3, step 3; app/lib/Blocks.php, js/tv-editor.js). Staff with
// pages.edit and pages.publish (Founder only until given to a role), signed in with their staff login.
//   GET  ?zone=<key>                                   -> {ok, state, versions, can: {edit, publish}, types, bgs}
//        (types and live: only what may go in that zone; the engage bar and a form only in our pages' zones, 4d)
//   POST {action: save|publish|rollback|discard, zone, tree?, version?, tz}, X-CSRF-Token -> {ok, message, state, versions}
//   POST {action: preview, zone, tree, here}  -> {ok, html}: the tree drawn as the page will draw it (nothing kept; step 4a;
//        here: the page's own address, for a GO Code of "this page")
//   POST {action: schedule, zone, tree, at (ISO), tz} | {action: unschedule, zone} -> Publish later, or call it off (4c)
//   POST {action: page, zone, title, summary, share_image} -> a page of ours' settings, saved at once (pages.publish; 4b)
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Blocks.php';
header('Cache-Control: no-store');

[$canEdit, $why] = Blocks::can('pages.edit');
if (!$canEdit) Response::error($why, 403, 'not_allowed');
$pdo = Database::connection();
$post = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
$in = $post ? Response::jsonBody() : $_GET;
$zone = (string) ($in['zone'] ?? '');
if (!Blocks::zoneOk($zone)) Response::error('That isn\'t a place for blocks.', 422);
$out = function (string $msg = '') use ($pdo, $zone): void {
    [$pub] = Blocks::can('pages.publish');
    Response::json(['ok' => true, 'message' => $msg, 'state' => Blocks::state($pdo, $zone), 'versions' => Blocks::versions($pdo, $zone),
        'can' => ['edit' => true, 'publish' => $pub], 'types' => Blocks::typesFor($zone), 'bgs' => Blocks::BGS,
        'bps' => Blocks::BPS, 'design' => ['section' => Blocks::SEC_DESIGN, 'block' => Blocks::BLOCK_DESIGN],
        'live' => Blocks::liveFor($zone), 'page' => Blocks::pageOf($pdo, $zone)]);
};
if (!$post) $out();
if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) Response::error('This page had been open a long time: reload it and try again.', 403, 'csrf');

$me = Auth::currentUser();
$uid = (int) ($me['id'] ?? 0);
require_once __DIR__ . '/../../app/admin/Access.php';
$name = (string) (Access::staff()['name'] ?? $me['display_name'] ?? '');
$tz = preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($in['tz'] ?? '')) ? (string) $in['tz'] : '';
$here = (string) ($in['here'] ?? '');
Blocks::useDb($pdo, preg_match('#^/(?!/)[^\s<>"]{0,300}$#', $here) ? $here : '');
Blocks::inZone($zone);   // the parts that belong to a page of ours draw only in its zone (4d)
if (($in['action'] ?? '') === 'preview') Response::json(['ok' => true, 'html' => Blocks::render(Blocks::clean($in['tree'] ?? null), true)]);
try {
    switch ((string) ($in['action'] ?? '')) {
        case 'save': $out(Blocks::saveDraft($pdo, $zone, $in['tree'] ?? null, $uid, $name, $tz));
        case 'publish': $out(Blocks::publish($pdo, $zone, $in['tree'] ?? null, $uid, $name, $tz));
        case 'rollback': $out(Blocks::rollBack($pdo, $zone, (int) ($in['version'] ?? 0), $uid, $name, $tz));
        case 'discard': $out(Blocks::discard($pdo, $zone));
        case 'schedule': $out(Blocks::schedule($pdo, $zone, $in['tree'] ?? null, (string) ($in['at'] ?? ''), $uid, $name, $tz));
        case 'unschedule': $out(Blocks::unschedule($pdo, $zone));
        case 'page':   // a page of ours: its title, search description and share picture, live when saved
            [$pub, $whyNot] = Blocks::can('pages.publish');
            if (!$pub) throw new RuntimeException($whyNot);
            $pg = Blocks::pageOf($pdo, $zone);
            if (!$pg) throw new RuntimeException('Only our own pages have these settings.');
            try { SitePages::save($pdo, $pg['id'], ['title' => (string) ($in['title'] ?? ''), 'summary' => (string) ($in['summary'] ?? ''), 'share_image' => (string) ($in['share_image'] ?? '')], $uid); }
            catch (InvalidArgumentException $x) { throw new RuntimeException($x->getMessage()); }
            $out('Saved: the page\'s title, search description and share picture are live.');
    }
    Response::error('Unknown action.', 422);
} catch (RuntimeException $e) { Response::error($e->getMessage(), 422); }
