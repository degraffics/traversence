/* js/tv-blocks.js — the browser half of the editor's live components (decisions/0159 §3.3, step 4b; app/lib/Blocks.php
 * Blocks::LIVE). Loaded by the page once it has one, for everyone:
 *  - a search box ([data-tvb-search]): opens the site's search with its words (TvSearch), or the directory without it;
 *  - businesses ([data-tvb-listings]): cards from the directory's own API (/api/search_listings.php, so its public
 *    rules apply), drawn to the card standard (0058 §11: the name the link, Link top right, Call, Directions and Website as
 *    round icon buttons, counted with data-out); the plain "See … in …" link stays as the way to all of them;
 *  - a map button ([data-tvb-map]): the site's map (TvMap, js/map-view.js, loaded when first needed) of those businesses;
 *  - a form ([data-tvb-form], step 4d, our own pages only): a contact or quote form sent to /pages/form.php.
 * TvBlocks.scan(root) wires what's new (the editor calls it after each preview). Every part works as a plain link
 * when this file can't run. */
(function () {
  var I = {
    call: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>',
    dir: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11l19-9-9 19-2-8-8-2z"/></svg>',
    web: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>'
  };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function params(el, extra) {
    var u = new URLSearchParams();
    if (el.dataset.town) u.set('city', el.dataset.town);
    if (el.dataset.state) u.set('state', el.dataset.state);
    if (el.dataset.cat) u.set('q', el.dataset.cat);
    Object.keys(extra || {}).forEach(function (k) { u.set(k, extra[k]); });
    return u;
  }
  function get(u) {
    return fetch('/api/search_listings.php?' + u.toString(), { credentials: 'include' })
      .then(function (r) { return r.json().then(function (j) { if (!(r.ok && j.success)) throw new Error(j.error || ('HTTP ' + r.status)); return j; }); });
  }
  function ib(href, icon, label, out, id, ext) {
    return '<a class="tvb-ib" href="' + esc(href) + '" title="' + label + '" aria-label="' + label + '" data-out="' + out + '" data-e="' + id + '"' + (ext ? ' rel="noopener" target="_blank"' : '') + '>' + I[icon] + '</a>';
  }
  function card(l) {
    var url = '/listing/view.php?id=' + l.id, where = [l.address, l.city, l.state].filter(Boolean).join(', ');
    var acts = '';
    if (l.phone) acts += ib('tel:' + String(l.phone).replace(/[^0-9+]/g, ''), 'call', 'Call', 'call', l.id);
    if (l.lat != null && l.lon != null && !l.approx) acts += ib('https://www.google.com/maps/dir/?api=1&destination=' + l.lat + ',' + l.lon, 'dir', 'Directions', 'directions', l.id, true);
    if (l.website) acts += ib(/^https?:/.test(l.website) ? l.website : 'https://' + l.website, 'web', 'Website', 'website', l.id, true);
    return '<article class="tvb-card tv-bleed"><div class="tvb-card-h"><a class="n" href="' + url + '">' + esc(l.business_name) + '</a>' + (acts ? '<span class="tvb-acts">' + acts + '</span>' : '')
      + '<span class="tvb-ib tvb-lk" role="button" tabindex="0" data-link="business:' + l.id + '" title="Link" aria-label="Link to ' + esc(l.business_name) + '">' + I.link + '</span></div>'
      + (l.category ? '<p class="k">' + esc(l.category) + '</p>' : '')
      + (l.description ? '<p>' + esc(String(l.description).slice(0, 160)) + (String(l.description).length > 160 ? '…' : '') + '</p>' : '')
      + (where ? '<p class="k">' + esc(where) + (l.hours_text ? ' · ' + esc(l.hours_text) : '') + '</p>' : '') + '</article>';
  }
  function listings(el) {
    var n = Math.max(1, Math.min(12, +el.dataset.n || 6)), more = el.querySelector('.tvb-more');
    var moreHtml = more ? more.outerHTML : '';
    get(params(el, { per_page: n, sort: el.dataset.sort || 'best' })).then(function (j) {
      var ls = (j.listings || []).slice(0, n);
      if (!ls.length) { el.innerHTML = '<p class="tvb-more">No businesses listed there yet. ' + (more ? more.innerHTML : '') + '</p>'; return; }
      el.innerHTML = ls.map(card).join('') + (j.total > ls.length ? moreHtml.replace(/>See /, '>See all ' + (+j.total).toLocaleString() + ' ') : '');
      el.setAttribute('data-tv-pager', 'off');   // a set number, chosen in the editor: never paged
    }, function () { /* the plain link stays: the directory itself */ });
  }
  function needMap(then) {
    if (window.TvMap) return then();
    var s = document.querySelector('script[data-tvb-mapjs]');
    if (!s) { s = document.createElement('script'); s.src = '/js/map-view.js'; s.setAttribute('data-tvb-mapjs', ''); document.head.appendChild(s); }
    s.addEventListener('load', function () { then(); });
  }
  function openMap(a) {
    var where = a.dataset.town + (a.dataset.state ? ', ' + a.dataset.state : '');
    var title = (a.dataset.cat ? a.dataset.cat.charAt(0).toUpperCase() + a.dataset.cat.slice(1) : 'Businesses') + ' in ' + where;
    TvMap.open({ panel: true, title: title,
      titleFor: function (j) { var n = j.total != null ? j.total : (j.pins || []).length; return n.toLocaleString() + (n === 1 ? ' business' : ' businesses') + ' · ' + where; },
      load: function (area, words) {
        var u = params(a, { view: 'map' });
        if (words) u.set('q', words);
        if (area) { u.delete('city'); u.delete('state'); u.set('lat', area.lat); u.set('lon', area.lon); if (area.radius) u.set('radius', area.radius); }
        return get(u);
      } });
  }
  function scan(root) {
    root = root || document;
    root.querySelectorAll('[data-tvb-listings]:not([data-tvb-on])').forEach(function (el) { el.setAttribute('data-tvb-on', ''); listings(el); });
    root.querySelectorAll('[data-tvb-map]:not([data-tvb-on])').forEach(function (a) {
      a.setAttribute('data-tvb-on', '');
      a.addEventListener('click', function (e) {
        if (e.defaultPrevented || a.closest('.tvb-edit')) return;   // in the editor a tap picks the block
        e.preventDefault(); needMap(function () { openMap(a); });
      });
    });
    root.querySelectorAll('[data-tvb-search]:not([data-tvb-on])').forEach(function (f) {
      f.setAttribute('data-tvb-on', '');
      f.addEventListener('submit', function (e) {
        var q = (f.querySelector('input').value || '').trim();
        if (window.TvSearch && TvSearch.open) { e.preventDefault(); TvSearch.open(q); }   // the site's own search, where the page has it
      });
    });
  }
  // a form on one of our pages ([data-tvb-form], step 4d): sent to /pages/form.php like the page's own form, so its entries
  // reach Form entries; the human check (Captcha::widget) is waited for, and the answer shown as the site's notice
  function forms(root) {
    root.querySelectorAll('[data-tvb-form]:not([data-tvb-on])').forEach(function (f) {
      f.setAttribute('data-tvb-on', '');
      var out = f.querySelector('[data-tvb-out]');
      function say(m, ok, b) {
        if (out) { out.hidden = false; out.setAttribute('data-tv-status', ok ? 'ok' : 'bad'); out.setAttribute('data-tv-label', ok ? 'Sent:' : 'Not sent:'); out.textContent = m; }
        if (window.TvAsk && TvAsk.say) TvAsk.say(m, { anchor: b, bad: !ok });
      }
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = f.querySelector('button[type=submit]');
        var d = { page: +f.dataset.page, kind: f.dataset.kind };
        ['name', 'email', 'phone', 'message', 'website'].forEach(function (k) { d[k] = (f.elements[k].value || '').trim(); });
        if (!d.name) return say('Please give your name.', false, b);
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)) return say('Please check your email address.', false, b);
        if (d.message.length < 5) return say('Please write your message.', false, b);
        if (window.TvAsk && TvAsk.busy) TvAsk.busy(b, true);
        (window.tvCaptchaWait ? tvCaptchaWait() : Promise.resolve(window.tvCaptcha ? tvCaptcha() : '')).then(function (c) {
          d.captcha = c || '';
          return fetch('/pages/form.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(window.tvSafe ? tvSafe(d) : d) })
            .then(function (r) { return r.json(); });
        }).then(function (j) {
          if (window.TvAsk && TvAsk.busy) TvAsk.busy(b, false);
          if (j.ok || j.success) { f.reset(); say('Thank you. We\'ve got your message and will answer by email.', true, b); }
          else say(((j.error && j.error.message) || j.error || 'That didn\'t send. Try again.') + ' Still stuck? Write to support@traversence.com.', false, b);
          if (window.tvCaptchaReset) tvCaptchaReset();
        }).catch(function () { if (window.TvAsk && TvAsk.busy) TvAsk.busy(b, false); say('That didn\'t send. Check your connection and try again, or write to support@traversence.com.', false, b); });
      });
    });
  }
  window.TvBlocks = { scan: function (root) { scan(root); forms(root || document); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { TvBlocks.scan(); }); else TvBlocks.scan();
})();
