<?php
// /api/release-bar.php — on the live site (decisions/0145 Phase 5): answers the staging bar, which staging passes on
// (website/api/stg-bar.php), signed with the key the live site keeps in staging's .env (RELEASE_BAR_KEY). Acts as the
// staff member who opened staging from Releases, with the release permissions they had then (Releases::actFromBar).
//   POST {b64: base64(json {bar, action, rel, args})}, X-Bar-Sig: hmac  -> the bar's state, or {ok, message}
//   action upload, args {inbox, name, tz}: the site manager's Upload (decisions/0159 §5) -> {ok, id, message}
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Staging.php';
header('Cache-Control: no-store');
if (Staging::here()) { http_response_code(404); exit; }
Response::requireMethod('POST');
require_once __DIR__ . '/../../app/lib/StagingSite.php';
require_once __DIR__ . '/../../app/lib/Releases.php';
$pdo = Database::connection();
$s = StagingSite::get($pdo, 'setup');
$env = $s && !empty($s['base']) ? StagingSite::readEnvFile(StagingSite::layout((string) $s['base'])['env']) : [];
$key = (string) ($env['RELEASE_BAR_KEY'] ?? '');
$raw = json_decode((string) file_get_contents('php://input'), true);
$b64 = is_array($raw) ? (string) ($raw['b64'] ?? '') : '';
if ($key === '' || $b64 === '' || !hash_equals(hash_hmac('sha256', $b64, $key), (string) ($_SERVER['HTTP_X_BAR_SIG'] ?? ''))) Response::error('Not allowed.', 401, 'not_allowed');
$in = json_decode((string) base64_decode($b64, true), true);
$bar = is_array($in) ? Releases::verify((string) ($in['bar'] ?? ''), $key) : null;
if (!$bar) Response::error('The staging bar has run out (it lasts 12 hours): open staging again from Releases on the live site.', 401, 'bar_expired');
$perms = array_values(array_filter((array) ($bar['perms'] ?? []), 'is_string'));
$rel = (int) ($in['rel'] ?? 0) ?: (int) ($bar['rel'] ?? 0);
$act = (string) ($in['action'] ?? 'state');
try {
    if ($act === 'state' && $rel) Releases::sawOnStaging($pdo, $rel, (int) ($bar['uid'] ?? 0), (string) ($bar['name'] ?? ''));
    if ($act === 'state') {
        $stg = null;   // staging as a whole, for the site manager's line and its Staging ▾ (decisions/0165 §5)
        try { require_once __DIR__ . '/../../app/lib/StagingApi.php'; $sum = StagingApi::summary($pdo); $stg = $sum + ['line' => StagingApi::line($sum)]; } catch (Throwable $x) { error_log('staging summary: ' . $x->getMessage()); }
        $bs = Releases::barState($pdo, $rel, $perms);
        // the release the bar shows is the one being looked at, whichever way it was chosen (Jason, 2026-11-15: opened from
        // the Releases page with none named, the bar showed #60 by itself and Publish said it hadn't been looked at)
        $shown = (int) ($bs['release']['id'] ?? 0);
        if ($shown && $shown !== $rel) Releases::sawOnStaging($pdo, $shown, (int) ($bar['uid'] ?? 0), (string) ($bar['name'] ?? ''));
        Response::json(['ok' => true, 'who' => (string) ($bar['name'] ?? ''), 'staging' => $stg] + $bs);
    }
    if (str_starts_with($act, 'stg:')) {   // staging as a whole, from the site manager: as the bar's person, with the permissions it carries
        require_once __DIR__ . '/../../app/lib/StagingApi.php';
        $sa = substr($act, 4);
        if (!in_array($sa, StagingApi::ACTS, true) || in_array($sa, ['mirror', 'jobs'], true)) Response::error('That\'s done on the live admin: System Configuration → Staging.', 422);
        $a = (array) ($in['args'] ?? []);
        $tz = preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($a['tz'] ?? '')) ? (string) $a['tz'] : '';
        $uid = (int) ($bar['uid'] ?? 0); $email = '';
        try { $st = $pdo->prepare('SELECT email FROM users WHERE id = ?'); $st->execute([$uid]); $email = (string) $st->fetchColumn(); } catch (Throwable) {}
        Response::json(['ok' => true] + Releases::asBar($bar, fn () => StagingApi::act($pdo, $sa, $a, [$uid, (string) ($bar['name'] ?? ''), $email, $tz])));
    }
    if ($act === 'pull') {   // Check for builds: Claude's, from git (Phase 6); the bar then shows the build that came in, on staging or
        // already live (2026-11-13: one that published itself left the bar on the release it was opened on); nothing new: it stays
        Releases::ensure($pdo);
        $before = (int) $pdo->query('SELECT COALESCE(MAX(id), 0) FROM site_releases')->fetchColumn();
        $msg = Releases::pullFromBar($pdo, $bar);
        $nid = (int) $pdo->query('SELECT COALESCE(MAX(id), 0) FROM site_releases')->fetchColumn();
        Response::json(['ok' => true, 'message' => $msg] + ($nid > $before ? ['id' => $nid] : []));
    }
    if ($act === 'upload') {   // the site manager's Upload (decisions/0159 §5): the zip it kept on staging, straight onto staging as a release
        $a = (array) ($in['args'] ?? []);
        $tz = preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($a['tz'] ?? '')) ? (string) $a['tz'] : '';
        Response::json(['ok' => true] + Releases::fromStagingInbox($pdo, $bar, (string) ($a['inbox'] ?? ''), (string) ($a['name'] ?? ''), $tz));
    }
    Response::json(['ok' => true, 'message' => Releases::actFromBar($pdo, $bar, $rel, $act, (array) ($in['args'] ?? []))]);
} catch (RuntimeException $e) { Response::error($e->getMessage(), 422); }
