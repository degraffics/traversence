-- Data cleanup, step 2 (decisions/0163 §8 stage 1b, 0164 §6.1b): its passes, the ledger of every change (old and new
-- value, for Undo), the "Check these" a person marked looked at, and its settings (the scheduled pass, shipped off).
-- Only creates tables: safe to run twice. In the main database, beside entities and landmarks.

CREATE TABLE IF NOT EXISTS cleanup_runs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  rule VARCHAR(30) NOT NULL DEFAULT '',
  by_id INT UNSIGNED NULL,
  by_name VARCHAR(120) NOT NULL DEFAULT '',
  by_tz VARCHAR(64) NOT NULL DEFAULT '',
  how VARCHAR(10) NOT NULL DEFAULT 'button',
  started_at DATETIME NOT NULL,
  finished_at DATETIME NULL,
  counts_json MEDIUMTEXT NULL,
  undone_at DATETIME NULL,
  undone_by INT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_cleanup_runs_open (finished_at, undone_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cleanup_ledger (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  run_id INT UNSIGNED NOT NULL,
  store VARCHAR(12) NOT NULL,
  ref VARCHAR(60) NOT NULL,
  name VARCHAR(160) NOT NULL DEFAULT '',
  rule VARCHAR(30) NOT NULL,
  action VARCHAR(20) NOT NULL,
  target VARCHAR(20) NOT NULL DEFAULT '',
  field VARCHAR(40) NOT NULL,
  old_value MEDIUMTEXT NULL,
  new_value MEDIUMTEXT NULL,
  why VARCHAR(300) NOT NULL DEFAULT '',
  by_id INT UNSIGNED NULL,
  at DATETIME NOT NULL,
  tz VARCHAR(64) NOT NULL DEFAULT '',
  undone_at DATETIME NULL,
  undone_by INT UNSIGNED NULL,
  undo_note VARCHAR(255) NULL,
  PRIMARY KEY (id),
  KEY idx_cleanup_ledger_run (run_id, ref),
  KEY idx_cleanup_ledger_ref (ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cleanup_checks (
  ref VARCHAR(60) NOT NULL,
  rule VARCHAR(30) NOT NULL,
  looked_by INT UNSIGNED NULL,
  looked_at DATETIME NOT NULL,
  PRIMARY KEY (rule, ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cleanup_settings (
  k VARCHAR(40) NOT NULL,
  v VARCHAR(255) NOT NULL DEFAULT '',
  by_id INT UNSIGNED NULL,
  at DATETIME NULL,
  PRIMARY KEY (k)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
