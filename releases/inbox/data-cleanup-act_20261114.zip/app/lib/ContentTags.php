<?php
// app/lib/ContentTags.php — the tag store (decisions/0132): what each piece of content is about. The Chameleon Filter
// keeps the content tags (the names a piece mentions, matched to what we have); an author's @tags live here too. A tag
// grants nothing: it puts the piece on the page of what it names ("Featured in"), and it's how a reader goes deeper (the
// highlighted name and its preview card). Sources are 'guide:<place key>' now; journeys, stories, experiences and the
// rest move here as they're next worked on.
declare(strict_types=1);

final class ContentTags
{
    /** Where a tag stands. Only linked and thin ones show anywhere. */
    public const SHOWN = ['linked', 'thin'];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM content_tags LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    /** The kinds of source and how each is shown: label, and whether a member can write it (their words are read only with consent). */
    public const SOURCES = ['guide' => 'Guide', 'journey' => 'Journey', 'story' => 'Story', 'experience' => 'Experience', 'howto' => 'How-to', 'group' => 'Group'];

    /**
     * What a source is: [title, url, kind label, live (published and shown), by (member|staff), author id, when]. Null when
     * it's gone. 'guide:town:2', 'journey:14', 'story:cluster:12', 'experience:5', 'howto:3'.
     */
    public static function source(PDO $pdo, string $src): ?array
    {
        static $memo = [];
        if (array_key_exists($src, $memo)) return $memo[$src];
        [$type, $id] = array_pad(explode(':', $src, 2), 2, '');
        $out = null;
        try {
            if ($type === 'guide') {
                require_once __DIR__ . '/Guides.php';
                $p = Guides::place($pdo, $id); $g = $p ? Guides::get($pdo, $id) : null;
                if ($p) $out = [$p['name'], $p['url'], $p['kind'], $g['status'] === 'live', 'staff', null, (string) ($g['published_at'] ?? '')];
            } elseif ($type === 'journey') {
                $st = $pdo->prepare('SELECT id, title, status, voice, author_id, published_at FROM journeys WHERE id = ?'); $st->execute([(int) $id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if ($r) $out = [(string) $r['title'], '/journeys/view.php?id=' . (int) $r['id'], 'Journey', $r['status'] === 'published', $r['voice'] === 'traversence' ? 'staff' : 'member', (int) $r['author_id'], (string) $r['published_at']];
            } elseif ($type === 'story') {
                require_once __DIR__ . '/Guides.php';
                $st = $pdo->prepare('SELECT title, status, updated_at FROM place_stories WHERE place_key = ?'); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                $p = Guides::place($pdo, $id);
                if ($r && $p) $out = [(string) ($r['title'] ?: 'The story of ' . $p['name']), $p['url'] . '#g-glance', 'Story', $r['status'] === 'published', 'staff', null, (string) $r['updated_at']];
            } elseif ($type === 'experience') {
                $st = $pdo->prepare('SELECT id, title, status, author_id, source, published_at FROM experiences WHERE id = ?'); $st->execute([(int) $id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if ($r) $out = [(string) $r['title'], '/experiences/view.php?id=' . (int) $r['id'], 'Experience', $r['status'] === 'published', $r['source'] === 'member' ? 'member' : 'staff', $r['author_id'] ? (int) $r['author_id'] : null, (string) $r['published_at']];
            } elseif ($type === 'group') {   // a community group naming the places it's about (decisions/0136 §3): "Featured in" shows it as a group
                $st = $pdo->prepare('SELECT id, name, status, owner_id, created_at FROM community_groups WHERE id = ?'); $st->execute([(int) $id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if ($r) $out = [(string) $r['name'], '/community/group.php?id=' . (int) $r['id'] . '&src=place', 'Group', $r['status'] === 'active', 'member', (int) $r['owner_id'], (string) $r['created_at']];
            } elseif ($type === 'howto') {
                $st = $pdo->prepare('SELECT id, title, status, published_at FROM how_guides WHERE id = ?'); $st->execute([(int) $id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if ($r) $out = [(string) $r['title'], '/guide/how.php?id=' . (int) $r['id'], 'How-to', $r['status'] === 'published', 'staff', null, (string) $r['published_at']];
            }
        } catch (Throwable $e) { error_log('content tags source ' . $src . ': ' . $e->getMessage()); }
        return $memo[$src] = $out;
    }

    /**
     * The Chameleon Filter reads a piece (decisions/0132 §2a): picks out what it names, matches each to what we have
     * near its place, keeps the tags, and sends names we don't have to Find it. $ai: may Claude read the words (staff
     * and listing content always; a member's only with AI & Learning consent and a paid plan, AiCredits). A name its author removed stays removed.
     */
    public static function tagPiece(PDO $pdo, string $src, string $placeKey, array $sections, string $byKind, ?int $byId, bool $ai, ?float $lat = null, ?float $lon = null): array
    {
        if (!self::ready($pdo)) return ['names' => 0, 'linked' => 0, 'queued' => 0];
        if ($ai && $byKind === 'member') { require_once __DIR__ . '/AiCredits.php'; $ai = AiCredits::funded($pdo, $byId); }   // a member's words cost an AI read only when a plan of theirs pays for it
        require_once __DIR__ . '/Guides.php';
        require_once __DIR__ . '/GuideLinks.php';
        $p = $placeKey !== '' ? Guides::place($pdo, $placeKey) : null;
        $p = $p ?: ['key' => '', 'name' => '', 'state' => '', 'level' => '', 'cluster' => null, 'lat' => $lat, 'lon' => $lon];
        $sections = array_filter(array_map(fn ($t) => trim((string) $t), $sections), fn ($t) => $t !== '');
        if (!$sections) { $pdo->prepare("DELETE FROM content_tags WHERE src = ? AND status <> 'dismissed'")->execute([$src]); return ['names' => 0, 'linked' => 0, 'queued' => 0]; }
        try { return GuideLinks::scan($pdo, $p, $sections, $src, $ai, $byKind, $byId); }
        catch (Throwable $e) { error_log('content tags ' . $src . ': ' . $e->getMessage()); return ['names' => 0, 'linked' => 0, 'queued' => 0]; }
    }

    /**
     * After a piece is saved: if it's published, the Chameleon Filter reads it again (its words, its place, its author;
     * a member's words go to Claude only with their AI & Learning consent). Drafts keep what they had. Never throws.
     */
    public static function retag(PDO $pdo, string $src): void
    {
        try {
            if (!self::ready($pdo)) return;
            [$type, $id] = array_pad(explode(':', $src, 2), 2, '');
            $consent = function (?int $uid) use ($pdo): bool { if (!$uid) return false; require_once __DIR__ . '/Consent.php'; return Consent::allows($pdo, $uid, 'ai_learning'); };
            if ($type === 'journey') {
                $st = $pdo->prepare('SELECT * FROM journeys WHERE id = ?'); $st->execute([(int) $id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if (!$r || $r['status'] !== 'published') return;
                $staff = $r['voice'] === 'traversence';
                self::tagPiece($pdo, $src, (string) $r['place_key'], ['body' => $r['title'] . "\n\n" . $r['body']], $staff ? 'staff' : 'member', (int) $r['author_id'], $staff || $consent((int) $r['author_id']),
                               $r['pin_lat'] !== null ? (float) $r['pin_lat'] : null, $r['pin_lon'] !== null ? (float) $r['pin_lon'] : null);
            } elseif ($type === 'story') {
                $st = $pdo->prepare('SELECT * FROM place_stories WHERE place_key = ?'); $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if ($r && $r['status'] === 'published') self::tagPiece($pdo, $src, $id, ['story' => (string) $r['body']], 'staff', $r['author_id'] ? (int) $r['author_id'] : null, true);
            } elseif ($type === 'experience') {
                $st = $pdo->prepare('SELECT * FROM experiences WHERE id = ?'); $st->execute([(int) $id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if (!$r || $r['status'] !== 'published') return;
                $member = $r['source'] === 'member';
                self::tagPiece($pdo, $src, (string) $r['place_key'], ['summary' => (string) $r['summary'], 'body' => (string) $r['body']], $member ? 'member' : 'staff', $r['author_id'] ? (int) $r['author_id'] : null, !$member || $consent($r['author_id'] ? (int) $r['author_id'] : null));
            } elseif ($type === 'howto') {
                $st = $pdo->prepare('SELECT * FROM how_guides WHERE id = ?'); $st->execute([(int) $id]); $r = $st->fetch(PDO::FETCH_ASSOC);
                if (!$r || $r['status'] !== 'published') return;
                $steps = json_decode((string) $r['steps'], true);
                $text = is_array($steps) ? implode("\n\n", array_map(fn ($x) => is_array($x) ? (string) ($x['text'] ?? $x['step'] ?? '') : (string) $x, $steps)) : (string) $r['steps'];
                self::tagPiece($pdo, $src, '', ['intro' => (string) $r['intro'], 'steps' => $text], 'staff', null, true);
            }
        } catch (Throwable $e) { error_log('content tags retag ' . $src . ': ' . $e->getMessage()); }
    }

    /**
     * Tags reaching people (decisions/0132 §4): for one person's follows (Links::all), the published pieces that name
     * what they follow, as feed items (they're also what the Pulse shows). listings: a business you follow was named;
     * discovery: a place you follow has a new guide, story, journey or experience, or was named in one; community: what
     * the people you follow published. A member's piece reaches a business's followers only if they also follow its
     * author or its place, so naming a business never puts a post in front of its whole audience.
     */
    public static function feedFor(PDO $pdo, array $links, string $tab, int $limit = 25, int $uid = 0): array
    {
        if (!self::ready($pdo)) return [];
        $active = fn (string $t) => array_values(array_filter($links[$t] ?? [], fn ($l) => !(int) $l['muted']));
        $people = array_map(fn ($l) => (int) $l['target_id'], $active('person'));
        $places = array_map(fn ($l) => (string) $l['target_id'], $active('place'));
        $labels = []; foreach (['business', 'place', 'person'] as $t) foreach ($active($t) as $l) $labels[$t === 'business' ? 'entity:' . $l['target_id'] : (string) $l['target_id']] = (string) $l['label'];
        $since = date('Y-m-d H:i:s', time() - 60 * 86400);
        $refs = $tab === 'listings' ? array_map(fn ($l) => 'entity:' . (int) $l['target_id'], $active('business')) : ($tab === 'discovery' ? $places : []);
        $rows = [];
        if ($refs) {
            $in = implode(',', array_map(fn ($r) => $pdo->quote($r), $refs));
            $rows = $pdo->query("SELECT src, ref, place_key, MAX(updated_at) AS at FROM content_tags WHERE status IN ('linked','thin') AND (ref IN ($in)" . ($tab === 'discovery' ? " OR place_key IN ($in)" : '') . ")
                                 AND updated_at >= " . $pdo->quote($since) . " GROUP BY src, ref, place_key ORDER BY at DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
        }
        $out = []; $seen = [];
        foreach ($rows as $r) {
            $s = self::source($pdo, (string) $r['src']);
            if (!$s || !$s[3]) continue;   // only what's published
            if ($s[4] === 'member' && $tab === 'listings' && !in_array((int) $s[5], $people, true) && !in_array((string) $r['place_key'], $places, true)) continue;
            $about = $tab === 'discovery' ? (in_array((string) $r['ref'], $places, true) ? (string) $r['ref'] : (string) $r['place_key']) : (string) $r['ref'];   // each tab speaks of what it follows
            $k = $r['src'] . '|' . $about; if (isset($seen[$k]) || !isset($labels[$about])) continue; $seen[$k] = 1;
            $own = $about === substr((string) $r['src'], 6) && str_starts_with((string) $r['src'], 'guide:');
            $out[] = ['kind' => 'featured', 'title' => $own ? 'The ' . $labels[$about] . ' guide' : $labels[$about] . ' is in ' . $s[0],
                      'body' => $own ? 'A ' . strtolower($s[2]) . ' for a place you follow.' : $s[2] . ': ' . $s[0], 'url' => $s[1], 'when' => $s[6] ?: (string) $r['at'], 'from' => $labels[$about]];
            if (count($out) >= $limit) break;
        }
        if ($tab === 'community' && $uid) {   // you were @mentioned in a group post you can read: once, as it happened
            try {
                $st = $pdo->prepare("SELECT t.src, t.by_id, t.created_at, p.group_id, p.body FROM content_tags t JOIN community_posts p ON p.id = CAST(SUBSTRING(t.src, 6) AS UNSIGNED)
                                     WHERE t.tag_kind = 'mention' AND t.ref = ? AND t.src LIKE 'post:%' AND p.removed_at IS NULL AND t.created_at >= ? ORDER BY t.created_at DESC LIMIT 20");
                $st->execute(['person:' . $uid, $since]);
                require_once __DIR__ . '/Community.php'; require_once __DIR__ . '/People.php';
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    if (!Community::isMember($pdo, (int) $r['group_id'], $uid) || People::blocked($pdo, $uid, (int) $r['by_id'])) continue;
                    $g = Community::group($pdo, (int) $r['group_id']); $u = People::user($pdo, (int) $r['by_id']);
                    $out[] = ['kind' => 'mention', 'title' => ($u ? People::name($u) : 'Someone') . ' mentioned you' . ($g ? ' in ' . $g['name'] : ''), 'body' => mb_strimwidth((string) preg_replace('/@\[([^\]]+)\]\([^)]+\)/', '@$1', (string) $r['body']), 0, 200, '…'),
                              'url' => '/community/group.php?id=' . (int) $r['group_id'], 'when' => (string) $r['created_at'], 'from' => $g['name'] ?? '', 'unread' => true];
                }
            } catch (Throwable $e) { error_log('feed mentions: ' . $e->getMessage()); }
        }
        if ($tab === 'community' && $people) {   // what the people you follow published, newest first
            $in = implode(',', array_map('intval', $people));
            try {
                foreach ($pdo->query("SELECT id FROM journeys WHERE author_id IN ($in) AND status = 'published' AND voice <> 'traversence' AND published_at >= " . $pdo->quote($since) . ' ORDER BY published_at DESC LIMIT ' . (int) $limit)->fetchAll(PDO::FETCH_COLUMN) as $jid) {
                    $s = self::source($pdo, 'journey:' . (int) $jid); if (!$s) continue;
                    $out[] = ['kind' => 'journey', 'title' => $s[0], 'body' => 'A new journey from someone you follow.', 'url' => $s[1], 'when' => $s[6], 'from' => ''];
                }
            } catch (Throwable) {}
        }
        return $out;
    }

    /**
     * The author's @tags in content attached to something (decisions/0132 §2a: a group post): kept as mention tags, the
     * Chameleon Filter adds nothing. A group post is for its members, so these never show in "Featured in" or anyone's
     * follows; a person @mentioned hears of it once, if they can read it (feedFor, community).
     */
    public static function mentions(PDO $pdo, string $src, string $body, int $byId, string $placeKey = ''): void
    {
        if (!self::ready($pdo)) return;
        try {
            preg_match_all('/@\[([^\]\n]{1,80})\]\((p:((?:hub|geo_hub|cluster):\d+)|t:([a-z0-9-]{1,60})|u:(\d+))\)/u', $body, $m, PREG_SET_ORDER);
            $keep = [];
            foreach ($m as $x) {
                [$kind, $ref] = ($x[3] ?? '') !== '' ? ['place', $x[3]] : ((($x[4] ?? '') !== '') ? ['topic', 'topic:' . $x[4]] : ['person', 'person:' . (int) ($x[5] ?? 0)]);
                if ($ref === 'person:' . $byId) continue;   // tagging yourself tells no one anything
                $keep[$ref] = 1;
                $pdo->prepare("INSERT INTO content_tags (src, place_key, section, name, tag_kind, kind, ref, status, by_kind, by_id, updated_at) VALUES (?, ?, 'body', ?, 'mention', ?, ?, 'linked', 'member', ?, NOW())
                               ON DUPLICATE KEY UPDATE ref = VALUES(ref), kind = VALUES(kind), updated_at = updated_at")->execute([$src, $placeKey, mb_substr($x[1], 0, 160), $kind, $ref, $byId]);
            }
            $old = $pdo->prepare("SELECT id, ref FROM content_tags WHERE src = ? AND tag_kind = 'mention'"); $old->execute([$src]);
            foreach ($old->fetchAll(PDO::FETCH_ASSOC) as $o) if (!isset($keep[$o['ref']])) $pdo->prepare('DELETE FROM content_tags WHERE id = ?')->execute([(int) $o['id']]);
        } catch (Throwable $e) { error_log('content tags mentions ' . $src . ': ' . $e->getMessage()); }
    }

    /** A piece's tags as its author sees them: [id, name, what it points to, its page, status]. */
    public static function forSource(PDO $pdo, string $src): array
    {
        if (!self::ready($pdo)) return [];
        require_once __DIR__ . '/GuideLinks.php';
        $st = $pdo->prepare("SELECT id, name, ref, status FROM content_tags WHERE src = ? AND status IN ('linked','thin') ORDER BY section, id"); $st->execute([$src]);
        $out = []; $seen = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { if (isset($seen[$r['ref']])) continue; $seen[$r['ref']] = 1; $out[] = $r + ['url' => GuideLinks::url($pdo, (string) $r['ref'])]; }
        return $out;
    }

    /** The author (or staff) takes a tag off a piece: the name stays plain text, and the piece leaves that thing's page. */
    public static function remove(PDO $pdo, int $tagId, int $uid, bool $staff): string
    {
        $st = $pdo->prepare('SELECT * FROM content_tags WHERE id = ?'); $st->execute([$tagId]); $t = $st->fetch(PDO::FETCH_ASSOC);
        if (!$t) throw new RuntimeException('That tag is already gone.');
        $s = self::source($pdo, (string) $t['src']);
        if (!$staff && (!$s || $s[5] !== $uid)) throw new RuntimeException('Only the author can take a tag off.');
        // every row naming the same thing in this piece goes, so it leaves the page at once
        $pdo->prepare("UPDATE content_tags SET status = 'dismissed', note = ?, by_kind = ?, by_id = ?, updated_at = NOW() WHERE src = ? AND (id = ? OR (ref <> '' AND ref = ?))")
            ->execute([$staff && (!$s || $s[5] !== $uid) ? 'Taken off by our team' : 'Taken off by the author', $staff ? 'staff' : 'member', $uid, $t['src'], $tagId, $t['ref']]);
        return (string) $t['name'];
    }

    /**
     * The published pieces that name a thing ('entity:12', 'landmark:3456', 'rec:abc', 'town:2'…), for its "Featured in":
     * [title, url, kind label], newest first. A piece counts only once it's published (a guide once it's live).
     */
    public static function featuredIn(PDO $pdo, string $ref, int $n = 6): array
    {
        if ($ref === '' || !self::ready($pdo)) return [];
        require_once __DIR__ . '/Guides.php';
        $st = $pdo->prepare("SELECT t.src, MAX(t.updated_at) AS at FROM content_tags t WHERE t.ref = ? AND t.status IN ('linked','thin') GROUP BY t.src ORDER BY at DESC LIMIT 40");
        $st->execute([$ref]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if ((string) $r['src'] === 'guide:' . $ref) continue;   // a guide naming its own place isn't news
            $sx = self::source($pdo, (string) $r['src']);
            if ($sx && $sx[3]) $out[] = [$sx[0], $sx[1], $sx[2]];   // only what's published shows
            if (count($out) >= $n) break;
        }
        return $out;
    }

    /**
     * What a tagged name opens as a preview card: name, what it is, where, a line about it, its page. Public facts only;
     * null when it isn't something we show (hidden, held, gone).
     */
    public static function card(PDO $pdo, string $ref): ?array
    {
        require_once __DIR__ . '/Guides.php';
        require_once __DIR__ . '/GuideLinks.php';
        $url = GuideLinks::url($pdo, $ref);
        if (preg_match('/^entity:(\d+)$/', $ref, $m)) {
            $st = $pdo->prepare("SELECT e.id, e.name, e.status, e.latitude, e.longitude, c.name AS category FROM entities e LEFT JOIN categories c ON c.id = e.category_id WHERE e.id = ? AND e.is_suppressed = 0");
            $st->execute([(int) $m[1]]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if (!$r) return null;
            $rows = [$r]; Guides::withMeta($pdo, $rows); $r = $rows[0];
            $closed = (bool) $pdo->query("SELECT 1 FROM entity_metadata WHERE entity_id = " . (int) $r['id'] . " AND meta_key = 'closed'")->fetchColumn();
            return ['name' => (string) $r['name'], 'what' => (string) preg_replace('/\s*\([^)]*$/', '', (string) $r['category']), 'where' => trim((string) $r['city'] . ($r['state'] !== '' ? ', ' . $r['state'] : ''), ', '),
                    'line' => $closed ? 'Marked closed' : ($r['hours'] !== '' ? 'Hours listed' : ''), 'phone' => (string) $r['phone'], 'url' => $url,
                    'lat' => $r['latitude'] !== null ? (float) $r['latitude'] : null, 'lon' => $r['longitude'] !== null ? (float) $r['longitude'] : null, 'address' => trim((string) $r['address'] . ', ' . (string) $r['city'] . ' ' . (string) $r['state'], ', '), 'e' => (int) $r['id']];
        }
        if (preg_match('/^landmark:(\d+)$/', $ref, $m)) {
            require_once __DIR__ . '/Landmarks.php';
            $st = $pdo->prepare('SELECT * FROM landmarks WHERE gnis_id = ?'); $st->execute([(int) $m[1]]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if (!$r || !Landmarks::visible($r)) return null;
            // its line: Wikidata's description, else ours (Landmarks::about): never Wikipedia's words while its rule is cite only (0164 R9)
            return ['name' => (string) $r['name'], 'what' => (string) ($r['fclass'] ?: 'Landmark'), 'where' => trim(($r['near_town'] ?: $r['county']) . ($r['state'] ? ', ' . $r['state'] : ''), ', '),
                    'line' => mb_substr(trim((string) ($r['wd_desc'] ?: Landmarks::about($pdo, $r))), 0, 140), 'phone' => '', 'url' => $url, 'image' => (string) ($r['image_url'] ?? ''), 'lat' => (float) $r['lat'], 'lon' => (float) $r['lon']];
        }
        if (preg_match('/^rec:(.+)$/', $ref, $m)) {
            $st = $pdo->prepare('SELECT * FROM rec_places WHERE ridb_id = ? AND COALESCE(hidden, 0) = 0'); $st->execute([$m[1]]); $r = $st->fetch(PDO::FETCH_ASSOC);
            if (!$r) return null;
            return ['name' => (string) $r['name'], 'what' => (string) ($r['type'] ?: 'Outdoor place'), 'where' => trim(($r['city'] ?: $r['org']) . ($r['state'] ? ', ' . $r['state'] : ''), ', '),
                    'line' => mb_substr(trim(strip_tags((string) $r['summary'])), 0, 140), 'phone' => (string) $r['phone'], 'url' => $url, 'lat' => $r['lat'] !== null ? (float) $r['lat'] : null, 'lon' => $r['lon'] !== null ? (float) $r['lon'] : null];
        }
        $p = Guides::place($pdo, $ref);
        if ($p) return ['name' => $p['name'], 'what' => $p['kind'], 'where' => '', 'line' => '', 'phone' => '', 'url' => $p['url']];
        return null;
    }
}
