<?php
// app/lib/DataCleanup.php — Insights → Data cleanup (decisions/0163 §8 stage 1b, 0164 §6.1b; Jason, 2026-11-14: "a tool
// clean up all the bad data recently added").
//
// It brings what the old crawler made into line with today's rules (0164), from handoffs/crawler-revamp.md Phase 4's
// assimilation passes. Each rule finds the records that fail it, in four stores (listings, staged finds, the place store,
// landmarks), newest first, and says what would happen to each:
//   act    the rule's action applies (quarantine, sighting, "Help us find", re-source, caution, merge offer, hold);
//   check  a person entered or decided something here (0164 R4): never changed, a "Check these" step instead;
//   left   it fails nothing today's rules act on (shown in the preview so the count is honest).
// Step 2 (2026-11-14) acts on them by rule, reversibly: every change is a row in the ledger (cleanup_ledger) with its old
// and new value, undone one record or one whole pass at a time; nothing is ever deleted. What needs a person is one Pulse
// case. A pass runs by a person's button; the scheduled pass (data_cleanup_tick) is shipped off, under the master switch.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class DataCleanup
{
    /** Who may run passes, and who may undo them (System Configuration → Permissions). */
    public const PERMS = [
        'insights.cleanup' => 'Data cleanup: see the preview and run passes',
        'insights.cleanup_undo' => 'Data cleanup: undo a change or a whole pass',
    ];
    public const RULE_RUN = ['min' => 'executive', 'depts' => []];
    public const RULE_UNDO = ['min' => 'executive', 'depts' => []];

    /** How many of each store a preview reads (newest first): enough for the crawler's stores today, bounded for the server. */
    public const READ = 6000;
    public const EXAMPLES = 6;

    /**
     * The rules: key => [store, title, what it finds, what happens (the action), its decision].
     * Actions: quarantine (off the public site, kept, reason stored), sighting (back to a sighting), help_find (a "Help us find
     * this business" card: not built yet, so quarantined with that as its planned target), unconfirm (the value marked
     * unconfirmed until re-sourced), caution (Closed becomes a caution with "Still open?"), merge (offered for a merge in
     * Review), hold (held, as the landmark rules hold a place), story_only (held until landmarks have the story-only level),
     * clear_text (a source's words we may only cite: cleared, its title and link kept).
     */
    public const RULES = [
        'junk_name' => ['listings', 'Not a business name', 'A listing whose name is page text ("Contact Us:", "PO Box 190", a webinar or form title, a heading).', 'quarantine', '0164 §3.5 (the "real business" floor)'],
        'no_floor' => ['listings', 'No address or phone', 'A listing with no street address and no phone, so nothing lets a visitor find it.', 'help_find', '0164 §3.5 (the floor; "Help us find this business")'],
        'page_only' => ['listings', 'Made from a page we may only cite', 'A listing whose address and phone rest only on pages whose terms let us cite them, not keep their facts.', 'sighting', '0164 R9, §3.5'],
        'osm_only' => ['listings', 'Values from OpenStreetMap only', 'A phone, address, website, hours or map point whose only source is OpenStreetMap (a lead, never a source).', 'unconfirm', '0065, 0164 R9'],
        'closed_one_site' => ['listings', '"Closed" from one site', 'A listing the crawler marked Closed on one site\'s word.', 'caution', '0164 R12 ("Still open?")'],
        'duplicate' => ['listings', 'Likely duplicates', 'Two live listings the intake\'s own test calls one business (the same phone, and the same Google place, name or address); providers at one clinic and businesses sharing a building aren\'t duplicates (0074).', 'merge', '0164 R12, decisions/0074, 0133'],
        'staged_junk' => ['staged', 'Staged finds with a page-text name', 'A find waiting in the intake whose name is page text.', 'quarantine', '0164 §3.5'],
        'store_junk' => ['store', 'Place-store names that are page text', 'A place in the place store whose name is page text.', 'hold', '0164 §3.5'],
        'store_guard' => ['store', 'Place-store places the guards would hold', 'A protected place, one on a nation\'s land with no phone or website, or a person\'s name, not yet marked held.', 'hold', '0164 R6, R7; 0066'],
        'store_cite' => ['store', 'Place-store facts from cite-only sources', 'Facts kept from a source whose rule is cite only (or ignore).', 'hold', '0164 R9'],
        'protected_open' => ['landmarks', 'Protected names shown too openly', 'A landmark whose name marks a sacred, burial or archaeological place, shown with its pin on a machine\'s word (a Wikipedia article alone).', 'story_only', '0164 R7 (story only), P5-3; 0066'],
        'nation_sensitive' => ['landmarks', 'Nation-sensitive names shown', 'A landmark on a nation\'s land of a kind specific to the nation (its springs), shown.', 'hold', '0066, 0164 R7'],
        'wiki_text' => ['landmarks', 'Wikipedia text kept while its rule is cite only', 'A landmark holding Wikipedia\'s words, though Wikipedia\'s rule in the source register is cite only. Its replacement is written first (our own words, kept as research); the text is cleared only once that exists.', 'clear_text', '0164 R9, W9 (Jason, 2026-11-14: a replacement before it\'s stripped)'],
    ];

    public const ACTIONS = [
        'quarantine' => 'Quarantine: off the public site, kept, with its reason',
        'sighting' => 'Back to a sighting until a source we may keep gives its address or phone',
        'help_find' => 'A "Help us find this business" card (not built yet: quarantined, with that as its planned target)',
        'unconfirm' => 'Re-source, or mark the value unconfirmed',
        'caution' => 'Caution with "Still open?" instead of Closed',
        'merge' => 'Offered for a merge in Review',
        'hold' => 'Held: kept, never shown',
        'story_only' => 'Held until landmarks have the story-only level (named and told, no pin), then story only',
        'clear_text' => 'Its words cleared once our own description replaces them; its title and link kept',
        'write_first' => 'Its replacement written first (Place descriptions); cleared on a later pass, once written',
    ];

    public const STORES = ['listings' => 'Listings', 'staged' => 'Staged finds', 'store' => 'The place store', 'landmarks' => 'Landmarks'];

    // ---- the "real business" name check (0164 §3.5; handoffs/crawler-revamp.md §7.3) ------------------------------------

    /** A page's labels read as a name. */
    private const LABELS = '/^\s*((physical|mailing|street|business|our|postal)\s+address(es)?|address(es)?|contact(\s+(us|info|information|me|page))?|about(\s+us)?|home(\s+page)?|locations?|directions|hours(\s+of\s+operation)?|office\s+hours|phone(\s+numbers?)?|email|e-mail|fax|menu|welcome|news|events?|calendar|resources|services|faqs?|search|login|log\s+in|sign\s+(in|up)|privacy(\s+policy)?|terms(\s+of\s+(use|service))?|site\s*map|map|gallery|photos|links|staff|team|board|careers|jobs|donate|subscribe|register|more|read\s+more|learn\s+more|click\s+here|untitled|n\/?a|none|null|test)\s*[:.\-–—]*\s*$/iu';
    /** Words that make a name a document, an event or a form, not a business. */
    private const DOC_WORDS = '/\b(webinars?|slide\s?shows?|slides|newsletters?|brochures?|flyers?|fliers?|agendas?|meeting\s+minutes|press\s+releases?|pdf|docx?|(application|registration|enrollment|intake|request|order|complaint|permit)\s+(forms?|packets?)|forms?\s+(and|&)\s+(documents|applications)|fillable|click\s+here|read\s+more|learn\s+more|sign\s+up|download|informational|annual\s+report|fact\s+sheet|faq)\b/iu';
    /** Openings that make a name a sentence about something ("An agency within…", "Part of…"). */
    private const SENTENCE = '/^\s*(an?\s+(agency|program|programme|service|division|department|unit|office|bureau|branch|partnership|initiative|project|resource|list|guide|directory|collection)\b|part\s+of\b|home\s+of\b|welcome\s+to\b|learn\s+(about|more)\b|find\s+(a|an|the|your)\b|how\s+to\b|what\s+(is|are)\b|this\s+(is|page)\b|we\s+(are|offer)\b|please\b|for\s+more\b)/iu';
    /** Mail and drop boxes: a place to post, not a business. */
    private const BOXES = '/^\s*(p\.?\s*o\.?\s*box|post\s+office\s+box|box|rr|hc|star\s+route)\s*#?\s*\d|\b(collection|drop(-?\s?off)?|deposit|night\s+drop|book\s+return)\s+box(es)?\b|\busps\s+(collection|blue)\b/iu';

    /**
     * Whether a name is page text rather than a business's name, and why: [true, why] or [false, ''].
     * Conservative on purpose: a real name that trips it is a "Check these" for a person only when a person touched it, so
     * the patterns are the junk names of 2026-11-13 and their kin, never a guess about an unusual name.
     */
    public static function junkName(string $name): array
    {
        $n = trim(html_entity_decode(strip_tags($name), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if (mb_strlen($n) < 2) return [true, 'No name'];
        if (preg_match(self::LABELS, $n)) return [true, 'A page\'s label, not a name'];
        if (preg_match('/[:]\s*$/u', $n)) return [true, 'Ends with a colon: a page\'s label'];
        if (preg_match('/^\s*contact\s*[:\-–—]/iu', $n)) return [true, 'A contact line, not a name'];
        if (preg_match('/^\s*(contact|call|email|e-mail|phone|fax|write\s+to|mail\s+to)\s+(.+)$/iu', $n, $m)) {
            require_once __DIR__ . '/crawler/AutoImport.php';
            $contact = mb_strtolower($m[1]) === 'contact';   // "Contact Greg Trapp"; "Call Ahead Pizza" is a business
            if (preg_match('/^(us|info|information|me|our|today|now)\b/iu', $m[2]) || preg_match('/^\(?\d/', $m[2]) || ($contact && (AutoImport::looksPerson($m[2]) || preg_match('/^(the|for|at)\b/iu', $m[2])))) return [true, 'A contact line, not a name'];
        }
        if (preg_match(self::BOXES, $n)) return [true, 'A mail or drop box, not a business'];
        if (preg_match(self::SENTENCE, $n)) return [true, 'A sentence about something, not a name'];
        if (preg_match(self::DOC_WORDS, $n)) return [true, 'A document, event or form title'];
        if (preg_match('#^\s*(https?://|www\.)#i', $n) || preg_match('/@[a-z0-9-]+\.[a-z]{2,}/i', $n)) return [true, 'A web or email address'];
        if (preg_match('/^[\d\s().+\-]{7,}$/', $n)) return [true, 'A phone number'];
        $words = preg_split('/\s+/u', $n, -1, PREG_SPLIT_NO_EMPTY);
        if (count($words) > 12 || mb_strlen($n) > 100) return [true, 'Too long for a name: a sentence from a page'];
        if (!preg_match('/\p{Lu}|\d/u', $n) && count($words) >= 4) return [true, 'A phrase from a page (no capital letters)'];
        return [false, ''];
    }

    // ---- the preview -----------------------------------------------------------------------------------------------

    /**
     * Every rule's finds, without changing anything: ['rules' => key => ['act', 'check', 'left', 'examples' => [guard =>
     * [item…]]], 'stores' => store => ['read', 'of', 'error'], 'at' => when]. $only: one rule's key, or '' for all.
     * An item: ['store', 'ref', 'name', 'rule', 'guard', 'why', 'link', 'target'].
     */
    public static function preview(PDO $pdo, string $only = ''): array
    {
        @set_time_limit(120);
        $out = ['rules' => [], 'stores' => [], 'at' => date('c')];
        foreach (self::RULES as $k => $r) $out['rules'][$k] = ['act' => 0, 'check' => 0, 'left' => 0, 'examples' => ['act' => [], 'check' => [], 'left' => []]];
        $add = function (array $it) use (&$out): void {
            $r = &$out['rules'][$it['rule']];
            $r[$it['guard']]++;
            if (count($r['examples'][$it['guard']]) < self::EXAMPLES) $r['examples'][$it['guard']][] = $it;
        };
        $want = fn (string $store) => $only === '' || (self::RULES[$only][0] ?? '') === $store;
        foreach (['listings' => 'findListings', 'staged' => 'findStaged', 'store' => 'findStore', 'landmarks' => 'findLandmarks'] as $store => $fn) {
            if (!$want($store)) continue;
            try { $out['stores'][$store] = self::$fn($pdo, $add, $only); }
            catch (Throwable $x) { $out['stores'][$store] = ['read' => 0, 'of' => 0, 'error' => 'Couldn\'t read it: ' . self::plainError($x)]; error_log('DataCleanup ' . $store . ': ' . $x->getMessage()); }
        }
        if ($only !== '') $out['rules'] = array_intersect_key($out['rules'], [$only => 1]);
        return $out;
    }

    private static function plainError(Throwable $x): string
    {
        $m = $x->getMessage();
        if (preg_match("/Table '[^']*?\.?([a-z_]+)' doesn't exist|no such table: ([a-z_]+)/i", $m, $t)) return 'the table ' . ($t[1] ?: $t[2]) . ' isn\'t there yet';
        return 'a database error (in the log)';
    }

    private static function item(string $store, string $ref, string $name, string $rule, string $guard, string $why, string $link, string $target = '', array $data = []): array
    {
        return ['store' => $store, 'ref' => $ref, 'name' => mb_substr($name, 0, 160), 'rule' => $rule, 'guard' => $guard, 'why' => $why, 'link' => $link, 'target' => $target ?: self::RULES[$rule][3], 'data' => $data];
    }

    /** Every item a pass would act on or show, in full (preview() keeps only counts and examples). */
    public static function collect(PDO $pdo, string $only = ''): array
    {
        @set_time_limit(300);
        $all = []; $errors = [];
        $add = function (array $it) use (&$all): void { $all[] = $it; };
        foreach (['listings' => 'findListings', 'staged' => 'findStaged', 'store' => 'findStore', 'landmarks' => 'findLandmarks'] as $store => $fn) {
            if ($only !== '' && (self::RULES[$only][0] ?? '') !== $store) continue;
            try { self::$fn($pdo, $add, $only); } catch (Throwable $x) { $errors[$store] = self::plainError($x); error_log('DataCleanup ' . $store . ': ' . $x->getMessage()); }
        }
        return ['items' => $all, 'errors' => $errors];
    }

    private static function jsonText($v): string
    {
        $d = json_decode((string) $v, true);
        if (is_string($d)) return $d;
        if (is_array($d)) return (string) ($d['value'] ?? $d['line'] ?? implode(' ', array_filter($d, 'is_scalar')));
        return (string) $v;
    }

    private static function host(string $u): string
    {
        $u = trim($u);
        if ($u === '') return '';
        return (string) preg_replace('/^www\./', '', strtolower((string) parse_url(preg_match('#^[a-z]+://#i', $u) ? $u : 'https://' . $u, PHP_URL_HOST)));
    }

    private static function isOsm(string $site): bool
    {
        return (bool) preg_match('/(^|\.)(openstreetmap\.org|osm\.org)$/', self::host($site) ?: strtolower($site));
    }

    /** A source's use rule for its host: 'cite' when we may only cite it (or ignore it), else what the register says. */
    private static function useRule(PDO $pdo, string $host): string
    {
        static $seen = [];
        if ($host === '') return 'facts';
        if (!isset($seen[$host])) {
            try { require_once __DIR__ . '/crawler/SourceIndex.php'; $seen[$host] = SourceIndex::useRule($pdo, $host); }
            catch (Throwable $x) { $seen[$host] = 'facts'; }
        }
        return $seen[$host];
    }

    // ---- listings --------------------------------------------------------------------------------------------------

    /** Source kinds that are where a value came into our records, not evidence of it. */
    private const PROVENANCE = ['crawler', 'import', 'evidence', 'rejected', 'replaced', 'dismissed'];
    /** Source kinds that are a person's word: keepable, and a person decided. */
    private const PERSON_KINDS = ['owner', 'admin', 'staff', 'member'];

    private static function findListings(PDO $pdo, callable $add, string $only): array
    {
        require_once __DIR__ . '/PlaceScope.php';
        $pub = implode(',', array_map(fn ($s) => $pdo->quote($s), PlaceScope::PUBLIC_STATUSES));
        $of = (int) $pdo->query("SELECT COUNT(*) FROM entities WHERE entity_type = 'merchant' AND created_by_type = 'ai_crawler' AND is_suppressed = 0 AND status IN ($pub)")->fetchColumn();
        $rows = $pdo->query("SELECT id, name, status, owner_user_id, updated_by_type, primary_zip FROM entities
                              WHERE entity_type = 'merchant' AND created_by_type = 'ai_crawler' AND is_suppressed = 0 AND status IN ($pub)
                              ORDER BY id DESC LIMIT " . self::READ)->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) return ['read' => 0, 'of' => $of, 'error' => ''];
        $ids = array_map(fn ($r) => (int) $r['id'], $rows);
        $meta = []; $raw = []; $facts = [];
        foreach (array_chunk($ids, 800) as $chunk) {
            $in = implode(',', $chunk);
            foreach ($pdo->query("SELECT entity_id, meta_key, meta_value, source_type, is_locked FROM entity_metadata WHERE entity_id IN ($in)
                                   AND meta_key IN ('phone', 'address', 'city', 'website', 'hours', 'closed', 'google', 'removed', 'unconfirmed')")->fetchAll(PDO::FETCH_ASSOC) as $m)
                $meta[(int) $m['entity_id']][$m['meta_key']] = $m;
            // who decided it: a person approving the find in the intake is a person's decision (R4)
            try {
                foreach ($pdo->query('SELECT entity_id, reviewed_by_user_id, source_url, JSON_EXTRACT(raw_payload, \'$.source\') AS src, JSON_EXTRACT(raw_payload, \'$.sources\') AS srcs,
                                             JSON_EXTRACT(raw_payload, \'$.registries\') AS regs, JSON_EXTRACT(raw_payload, \'$.corroboration\') AS corr, JSON_EXTRACT(raw_payload, \'$.actions.website\') AS site
                                        FROM ' . Database::t('crawler_raw_index') . " WHERE status = 'published' AND entity_id IN ($in)")->fetchAll(PDO::FETCH_ASSOC) as $r)
                    $raw[(int) $r['entity_id']] = $r;
            } catch (Throwable $x) { error_log('DataCleanup raw: ' . $x->getMessage()); }
            try {
                foreach ($pdo->query('SELECT f.record_id, f.fact, f.value, s.kind, s.site FROM ' . Database::t('identity_facts') . ' f JOIN ' . Database::t('identity_fact_sources') . " s ON s.fact_id = f.id
                                       WHERE f.record_kind = 'listing' AND f.record_id IN ($in) AND f.is_current = 1 AND f.fact IN ('phone', 'address', 'website', 'hours', 'point')
                                         AND f.status NOT IN ('rejected', 'replaced')")->fetchAll(PDO::FETCH_ASSOC) as $f)
                    $facts[(int) $f['record_id']][$f['fact']][] = $f;
            } catch (Throwable $x) { error_log('DataCleanup identity: ' . $x->getMessage()); }
        }
        $link = fn (int $id) => '/admin/listing-edit.php?id=' . $id;
        $want = fn (string $k) => $only === '' || $only === $k;
        $byPhone = [];
        foreach ($rows as $e) {
            $id = (int) $e['id']; $m = $meta[$id] ?? []; $r = $raw[$id] ?? null; $name = (string) $e['name'];
            $claimed = (int) $e['owner_user_id'] > 0 || $e['status'] !== 'unclaimed';
            $personField = fn (string $k) => isset($m[$k]) && ((int) $m[$k]['is_locked'] === 1 || in_array((string) $m[$k]['source_type'], ['admin', 'owner', 'user'], true));
            $touched = $claimed || ($r && (int) $r['reviewed_by_user_id'] > 0) || in_array((string) $e['updated_by_type'], ['admin', 'owner', 'user'], true)
                       || (bool) array_filter($m, fn ($x) => (int) $x['is_locked'] === 1 || in_array((string) $x['source_type'], ['admin', 'owner', 'user'], true));
            $whole = $touched ? 'check' : 'act';
            $phone = isset($m['phone']) ? preg_replace('/\D/', '', self::jsonText($m['phone']['meta_value'])) : '';
            $phone = strlen((string) $phone) >= 10 ? substr((string) $phone, -10) : '';
            $street = isset($m['address']) && preg_match('/^\s*#?\s*\d/', self::jsonText($m['address']['meta_value']));
            $f = $facts[$id] ?? [];
            // a fact's sources: OpenStreetMap only, cite-only pages only, or something we may keep
            $kind = function (string $fact) use ($f, $pdo): string {
                if (empty($f[$fact])) return 'unknown';
                $osm = false; $cite = false;
                foreach ($f[$fact] as $s) {
                    $k = (string) $s['kind']; $site = (string) $s['site'];
                    if (in_array($k, self::PERSON_KINDS, true) || $k === 'registry') return 'keep';
                    if ($site !== '' && self::isOsm($site)) { $osm = true; continue; }
                    if (in_array($k, self::PROVENANCE, true)) continue;
                    if ($site !== '' && self::useRule($pdo, $site) === 'cite') { $cite = true; continue; }
                    return 'keep';
                }
                return $osm ? 'osm' : ($cite ? 'cite' : 'unknown');
            };
            $junk = self::junkName($name);
            if ($junk[0]) {
                if ($want('junk_name')) $add(self::item('listings', 'entity:' . $id, $name, 'junk_name', $whole, $junk[1], $link($id)));
                continue;   // one reason a listing: the strongest first
            }
            $pk = $phone !== '' ? $kind('phone') : ''; $ak = $street ? $kind('address') : '';
            if ($phone === '' && !$street) {
                $town = isset($m['city']) || trim((string) $e['primary_zip']) !== '';
                if ($want('no_floor')) $add(self::item('listings', 'entity:' . $id, $name, 'no_floor', $whole, $town ? 'A name and a town, no address or phone' : 'A name only: no town, address or phone', $link($id), $town ? 'help_find' : 'sighting'));
                continue;
            }
            $keepable = ($phone !== '' && !in_array($pk, ['osm', 'cite'], true)) || ($street && !in_array($ak, ['osm', 'cite'], true));
            if (!$keepable && ($pk === 'cite' || $ak === 'cite')) {
                if ($want('page_only')) $add(self::item('listings', 'entity:' . $id, $name, 'page_only', $whole, 'Its address and phone come only from pages we may cite, not keep', $link($id)));
                continue;
            }
            if ($want('osm_only')) {
                $osm = [];
                foreach (['phone' => 'phone', 'address' => 'address', 'website' => 'website', 'hours' => 'hours', 'point' => 'map point'] as $fact => $label)
                    if ((($fact === 'point') || isset($m[$fact])) && $kind($fact) === 'osm') $osm[$fact] = $label;
                $done = isset($m['unconfirmed']) ? (array) (json_decode((string) $m['unconfirmed']['meta_value'], true)['fields'] ?? []) : [];
                $osm = array_diff_key($osm, $done);   // marked on an earlier pass
                if ($osm) {
                    $g = $claimed || array_filter(array_keys($osm), fn ($k) => $personField($k)) ? 'check' : 'act';
                    $add(self::item('listings', 'entity:' . $id, $name, 'osm_only', $g, 'From OpenStreetMap only: ' . implode(', ', $osm) . (!$keepable ? ' (nothing else gives its address or phone)' : ''), $link($id), '', ['fields' => $osm]));
                }
            }
            if ($want('closed_one_site') && isset($m['closed'])) {
                $c = json_decode((string) $m['closed']['meta_value'], true);
                $c = is_array($c) ? $c : [];
                if ((int) ($c['by'] ?? 0) === 0) {
                    $note = (string) ($c['note'] ?? '');
                    if (preg_match('/^its own website says/i', $note)) $add(self::item('listings', 'entity:' . $id, $name, 'closed_one_site', 'left', 'Its own website says it closed: R12 lets that show as Closed', $link($id)));
                    else $add(self::item('listings', 'entity:' . $id, $name, 'closed_one_site', $claimed ? 'check' : 'act', 'Marked Closed by the crawler' . ($note !== '' ? ': ' . mb_substr($note, 0, 120) : ''), $link($id), '', ['note' => $note, 'at' => (string) ($c['at'] ?? '')]));
                }
            }
            if ($phone !== '') $byPhone[$phone][] = ['id' => $id, 'name' => $name, 'primary_zip' => (string) $e['primary_zip'], 'address' => $m['address']['meta_value'] ?? '', 'google' => $m['google']['meta_value'] ?? '',
                                                    'website' => isset($m['website']) ? self::jsonText($m['website']['meta_value']) : '', 'phone' => $phone, 'claimed' => $claimed];
        }
        if ($only === '' || $only === 'duplicate') self::findDupes($pdo, $add, $byPhone, $link);
        return ['read' => count($rows), 'of' => $of, 'error' => ''];
    }

    /** Pairs among the crawler's listings that look like one business (LiveDupes' test), not asked about before. */
    private static function findDupes(PDO $pdo, callable $add, array $byPhone, callable $link): void
    {
        require_once __DIR__ . '/crawler/LiveDupes.php';
        require_once __DIR__ . '/crawler/AutoImport.php';
        $asked = [];
        try {
            foreach ($pdo->query("SELECT entity_id, same_as_id FROM suggestions WHERE kind = 'same' AND same_as_id IS NOT NULL")->fetchAll(PDO::FETCH_NUM) as [$a, $b])
                $asked[min((int) $a, (int) $b) . '-' . max((int) $a, (int) $b)] = true;
        } catch (Throwable $x) {}
        foreach ($byPhone as $g) {
            if (count($g) < 2 || count($g) > 4) continue;   // more share a switchboard's line: proves nothing
            for ($i = 0; $i < count($g); $i++) for ($j = $i + 1; $j < count($g); $j++) {
                $why = LiveDupes::same($g[$i], $g[$j]);
                if ($why === '') continue;
                // the intake's own test (AutoImport::relationTo, decisions/0074): providers at one clinic, another location,
                // another business in the same building or a name covered by the other aren't duplicates
                $a = $g[$i]; $b = $g[$j];
                $rel = AutoImport::relationTo(['name' => $a['name'], 'actions' => ['phone' => $a['phone'], 'website' => $a['website']],
                    'where' => ['address' => self::jsonText($a['address']), 'zip' => substr($a['primary_zip'], 0, 5)]], $b['name'], $b['phone'], self::jsonText($b['address']), substr($b['primary_zip'], 0, 5), $b['website']);
                if (!in_array($rel['kind'], ['same', 'covered', 'maybe'], true)) continue;   // 'covered': one is the other's legal or parent name
                $why .= $rel['kind'] === 'maybe' ? ' (names only partly alike: a person decides)' : ($rel['kind'] === 'covered' ? ' (one name looks like the other\'s legal or parent name)' : '');
                $k = min($g[$i]['id'], $g[$j]['id']) . '-' . max($g[$i]['id'], $g[$j]['id']);
                $add(self::item('listings', 'pair:' . $k, $g[$i]['name'] . ' and ' . $g[$j]['name'], 'duplicate', isset($asked[$k]) ? 'left' : ($g[$i]['claimed'] || $g[$j]['claimed'] ? 'check' : 'act'),
                    isset($asked[$k]) ? 'Already asked about in Review' : 'The same phone, ' . $why . ' (#' . $g[$i]['id'] . ', #' . $g[$j]['id'] . ')', $link($g[$i]['id']), '', ['a' => $g[$i]['id'], 'b' => $g[$j]['id'], 'why' => $why]));
            }
        }
    }

    // ---- staged finds ------------------------------------------------------------------------------------------------

    private static function findStaged(PDO $pdo, callable $add, string $only): array
    {
        if ($only !== '' && $only !== 'staged_junk') return ['read' => 0, 'of' => 0, 'error' => ''];
        $T = Database::t('crawler_raw_index');
        $of = (int) $pdo->query("SELECT COUNT(*) FROM $T WHERE status = 'staged' AND payload_type = 'listing'")->fetchColumn();
        $rows = $pdo->query("SELECT id, reviewed_by_user_id, JSON_UNQUOTE(JSON_EXTRACT(raw_payload, '$.name')) AS name FROM $T WHERE status = 'staged' AND payload_type = 'listing' ORDER BY id DESC LIMIT " . self::READ)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $j = self::junkName((string) $r['name']);
            if ($j[0]) $add(self::item('staged', 'staged:' . (int) $r['id'], (string) $r['name'], 'staged_junk', (int) $r['reviewed_by_user_id'] > 0 ? 'check' : 'act', $j[1], '/admin/listing-intake.php?row=' . (int) $r['id']));
        }
        return ['read' => count($rows), 'of' => $of, 'error' => ''];
    }

    // ---- the place store ---------------------------------------------------------------------------------------------

    private static function findStore(PDO $pdo, callable $add, string $only): array
    {
        if ($only !== '' && !in_array($only, ['store_junk', 'store_guard', 'store_cite'], true)) return ['read' => 0, 'of' => 0, 'error' => ''];
        require_once __DIR__ . '/crawler/SourceIndex.php';
        $F = Database::t('source_facts');
        $hasHeld = (bool) $pdo->query("SHOW COLUMNS FROM $F LIKE 'held'")->fetch();
        $of = (int) $pdo->query("SELECT COUNT(*) FROM $F" . ($hasHeld ? ' WHERE held IS NULL' : ''))->fetchColumn();
        $rich = (bool) $pdo->query("SHOW COLUMNS FROM $F LIKE 'category_id'")->fetch();
        $rows = $pdo->query("SELECT id, host, page_url, name, phone_digits, " . ($rich ? 'category_id, kind_words, section, website, lat, lng' : 'NULL AS category_id, NULL AS kind_words, NULL AS section, NULL AS website, NULL AS lat, NULL AS lng')
                            . " FROM $F" . ($hasHeld ? ' WHERE held IS NULL' : '') . ' ORDER BY id DESC LIMIT ' . self::READ)->fetchAll(PDO::FETCH_ASSOC);
        $want = fn (string $k) => $only === '' || $only === $k;
        $link = fn (array $r) => '/admin/insights/sources?q=' . rawurlencode((string) $r['host']);
        foreach ($rows as $r) {
            $name = (string) $r['name'];
            $j = self::junkName($name);
            if ($j[0]) { if ($want('store_junk')) $add(self::item('store', 'fact:' . (int) $r['id'], $name, 'store_junk', 'act', $j[1] . ' (' . $r['host'] . ')', $link($r), '', ['held' => 'junk'])); continue; }
            if ($want('store_guard')) {
                $pl = $r['lat'] !== null && $r['lng'] !== null ? [(float) $r['lat'], (float) $r['lng']] : null;
                $g = self::guardOnly($pdo, $r, $pl);
                if ($g !== '') { $add(self::item('store', 'fact:' . (int) $r['id'], $name, 'store_guard', 'act', ['protected' => 'May mark a sacred, burial or archaeological place', 'nation' => 'On a nation\'s land, with no phone or website', 'person' => 'Reads as a person\'s name'][$g] ?? $g, $link($r), 'hold:' . $g, ['held' => $g])); continue; }
            }
            if ($want('store_cite') && self::useRule($pdo, self::host((string) $r['host'])) === 'cite')
                $add(self::item('store', 'fact:' . (int) $r['id'], $name, 'store_cite', 'act', $r['host'] . '\'s rule is cite only', $link($r), '', ['held' => 'cite']));
        }
        return ['read' => count($rows), 'of' => $of, 'error' => $hasHeld ? '' : 'The place store has no held column yet: what would be held is shown, and holding waits for it.'];
    }

    /** SourceIndex::guard()'s verdict, without its marking the row (the preview writes nothing). */
    private static function guardOnly(PDO $pdo, array $r, ?array $pl): string
    {
        require_once __DIR__ . '/Landmarks.php';
        require_once __DIR__ . '/Nations.php';
        require_once __DIR__ . '/crawler/AutoImport.php';
        Landmarks::loadPeoples($pdo);
        $name = (string) ($r['name'] ?? '');
        $shape = $pl ? Nations::at($pdo, (float) $pl[0], (float) $pl[1]) : null;
        $text = trim($name . ' ' . (string) ($r['kind_words'] ?? '') . ' ' . (string) ($r['section'] ?? ''));
        if (Landmarks::isProtected($text, (string) $shape)
            && !Landmarks::publiclyKnown(['name' => $name, 'wd_desc' => trim((string) ($r['kind_words'] ?? '') . ' ' . (string) ($r['section'] ?? '')), 'nation' => (string) $shape])) return 'protected';   // as SourceIndex::guard() decides today
        if ($shape !== null && trim((string) ($r['phone_digits'] ?? '')) === '' && trim((string) ($r['website'] ?? '')) === '') return 'nation';
        if (AutoImport::looksPerson($name) && $r['category_id'] === null && !preg_match('/\b(overlook|mesa|park|trail|lake|canyon|peak|creek|springs?|butte|ranch|school|church|cent(er|re)|museum|hall|house|lodge|inn|cafe|store|shop|market|river|valley|point|rock|falls|farm|station|office|library|clinic|motel|hotel|bridge|monument|memorial|cemetery|fort)\b/i', $name)) return 'person';
        return '';
    }

    // ---- landmarks ------------------------------------------------------------------------------------------------------

    private static function findLandmarks(PDO $pdo, callable $add, string $only): array
    {
        if ($only !== '' && !in_array($only, ['protected_open', 'nation_sensitive', 'wiki_text'], true)) return ['read' => 0, 'of' => 0, 'error' => ''];
        require_once __DIR__ . '/Landmarks.php';
        Landmarks::loadPeoples($pdo);
        $of = (int) $pdo->query("SELECT COUNT(*) FROM landmarks WHERE status IN ('shown', 'approved')")->fetchColumn();
        $research = (bool) $pdo->query("SHOW COLUMNS FROM landmarks LIKE 'research'")->fetch();
        $rows = $pdo->query("SELECT gnis_id, name, fclass, nation, wd_desc, wiki_title, extract, status, why, reviewed_by, " . ($research ? 'research, about_queued_at' : "'' AS research, NULL AS about_queued_at") . " FROM landmarks
                              WHERE status IN ('shown', 'approved') ORDER BY gnis_id DESC LIMIT " . (self::READ * 3))->fetchAll(PDO::FETCH_ASSOC);
        $wiki = Landmarks::wikiAllowed($pdo);
        $want = fn (string $k) => $only === '' || $only === $k;
        $link = fn (array $r) => '/admin/local/places/' . (int) $r['gnis_id'];
        foreach ($rows as $r) {
            $person = $r['status'] === 'approved' || (int) $r['reviewed_by'] > 0;   // a person's decision stands (R4); never a machine's call on a sensitive place (R7)
            $name = (string) $r['name'];
            $text = $name . ' ' . (string) $r['wd_desc'];
            if ($want('protected_open') && Landmarks::isProtected($text, (string) $r['nation'])) {
                $add(self::item('landmarks', 'landmark:' . (int) $r['gnis_id'], $name, 'protected_open', $person ? 'check' : 'act',
                    ($person ? 'Approved by a person' : ((string) $r['why'] === Landmarks::KNOWN_WHY ? 'Shown on a machine\'s word (its own article, or a guide named it)' : 'Shown with its pin')) . ($r['nation'] !== '' ? ', on ' . $r['nation'] . '\'s land' : ''), $link($r)));
                continue;
            }
            if ($want('nation_sensitive') && trim((string) $r['nation']) !== '' && in_array((string) $r['fclass'], Landmarks::NATION_SENSITIVE_CLASSES, true)) {
                $add(self::item('landmarks', 'landmark:' . (int) $r['gnis_id'], $name, 'nation_sensitive', $person ? 'check' : 'act', 'A ' . strtolower((string) $r['fclass']) . ' on ' . $r['nation'] . '\'s land' . ($person ? ', approved by a person' : ''), $link($r)));
                continue;
            }
            if ($want('wiki_text') && !$wiki && trim((string) $r['extract']) !== '') {
                $has = trim((string) $r['research']) !== '';   // our own description is written: the text can go
                $add(self::item('landmarks', 'landmark:' . (int) $r['gnis_id'], $name, 'wiki_text', !$has && $r['about_queued_at'] !== null ? 'left' : 'act',
                    ($has ? 'Our own description is written: Wikipedia\'s words can go' : ($r['about_queued_at'] !== null ? 'Waiting for its description to be written, then cleared' : 'Its description is written first, then the text cleared'))
                    . ($r['wiki_title'] !== '' ? ' ("' . $r['wiki_title'] . '": the link stays)' : ''), $link($r), $has ? 'clear_text' : 'write_first', ['ready' => $has, 'queued' => $r['about_queued_at'] !== null]));
            }
        }
        return ['read' => count($rows), 'of' => $of, 'error' => ''];
    }

    // ---- acting: runs, the ledger and Undo (step 2) ---------------------------------------------------------------------

    /** Records acted on in one press; a bigger pass carries on with Continue (what's done no longer fails its rule). */
    public const BATCH = 600;
    /** Merge offers from one pass waiting in Review at once: Review isn't flooded (LiveDupes keeps 40). */
    public const MAX_OFFERS = 60;
    /** "Check these" kept on a run for the Pulse case. */
    private const CHECKS_KEPT = 400;
    public const DEVICE = 'crawler-cleanup';   // the crawler's own checks (Suggestions::OWN_SQL): Review's checkers, not Support

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM ' . Database::t('cleanup_ledger') . ' LIMIT 0'); $pdo->query('SELECT 1 FROM ' . Database::t('cleanup_runs') . ' LIMIT 0'); $ok = true; } catch (Throwable $x) { $ok = false; } }
        return $ok;
    }

    public static function setting(PDO $pdo, string $k): string
    {
        try { $st = $pdo->prepare('SELECT v FROM ' . Database::t('cleanup_settings') . ' WHERE k = ?'); $st->execute([$k]); return (string) ($st->fetchColumn() ?: ''); } catch (Throwable $x) { return ''; }
    }

    public static function setSetting(PDO $pdo, string $k, string $v, int $uid): void
    {
        $pdo->prepare('INSERT INTO ' . Database::t('cleanup_settings') . ' (k, v, by_id, at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v), by_id = VALUES(by_id), at = VALUES(at)')->execute([$k, $v, $uid, date('Y-m-d H:i:s')]);
    }

    /** The scheduled pass: off unless a person switches it on (and always under the automation master switch). */
    public static function autoOn(PDO $pdo): bool { return self::setting($pdo, 'auto') === 'on'; }

    /** A run that isn't finished (a pass bigger than one press), or null. */
    public static function openRun(PDO $pdo): ?array
    {
        if (!self::ready($pdo)) return null;
        $r = $pdo->query('SELECT * FROM ' . Database::t('cleanup_runs') . ' WHERE finished_at IS NULL AND undone_at IS NULL ORDER BY id DESC LIMIT 1')->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    public static function runs(PDO $pdo, int $n = 10): array
    {
        if (!self::ready($pdo)) return [];
        return $pdo->query('SELECT * FROM ' . Database::t('cleanup_runs') . ' ORDER BY id DESC LIMIT ' . max(1, min(50, $n)))->fetchAll(PDO::FETCH_ASSOC);
    }

    /** The changes of a run, one row per record (its fields together), newest first. */
    public static function items(PDO $pdo, int $runId, int $limit = 60): array
    {
        $st = $pdo->prepare('SELECT ref, MIN(name) AS name, MIN(rule) AS rule, MIN(action) AS action, MIN(target) AS target, MIN(why) AS why, MIN(at) AS at, MIN(tz) AS tz,
                                    COUNT(*) AS n, SUM(undone_at IS NOT NULL) AS undone, MAX(undo_note) AS undo_note
                               FROM ' . Database::t('cleanup_ledger') . ' WHERE run_id = ? GROUP BY ref ORDER BY MAX(id) DESC LIMIT ' . max(1, min(500, $limit)));
        $st->execute([$runId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * One press of a pass: finds again, acts on up to BATCH records by rule ('act' only: never a person's), logs each
     * change, and keeps the "Check these" for the Pulse case. $only: one rule or '' for all. Returns the run.
     */
    public static function run(PDO $pdo, string $only, int $uid, string $who, string $tz = '', string $how = 'button'): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('Data cleanup\'s database update hasn\'t run yet: it runs within the hour, or open System Configuration → Database updates.');
        if ($only !== '' && !isset(self::RULES[$only])) throw new InvalidArgumentException('Unknown rule.');
        $R = Database::t('cleanup_runs');
        $open = self::openRun($pdo);
        if ($open && (string) $open['rule'] !== $only) throw new RuntimeException('A pass for ' . ($open['rule'] === '' ? 'every rule' : self::RULES[$open['rule']][1]) . ' is still under way: Continue it first.');
        if ($open) $runId = (int) $open['id'];
        else {
            $pdo->prepare("INSERT INTO $R (rule, by_id, by_name, by_tz, how, started_at) VALUES (?, ?, ?, ?, ?, ?)")->execute([$only, $uid ?: null, mb_substr($who, 0, 120), mb_substr($tz, 0, 64), $how, date('Y-m-d H:i:s')]);
            $runId = (int) $pdo->lastInsertId();
        }
        $found = self::collect($pdo, $only);
        $done = ['quarantined' => 0, 'sighting' => 0, 'help_find' => 0, 'unconfirmed' => 0, 'caution' => 0, 'offered' => 0, 'held' => 0, 'story_only' => 0, 'cleared' => 0, 'queued' => 0, 'failed' => 0];
        $checks = []; $left = 0; $acted = 0; $more = false; $listings = []; $landmarks = [];
        $offers = self::openOffers($pdo);
        foreach ($found['items'] as $it) {
            if ($it['guard'] === 'check') { if (count($checks) < self::CHECKS_KEPT) $checks[] = array_intersect_key($it, array_flip(['ref', 'name', 'rule', 'why', 'link'])); continue; }
            if ($it['guard'] !== 'act') { $left++; continue; }
            if ($it['rule'] === 'duplicate' && $offers >= self::MAX_OFFERS) { $left++; continue; }   // Review isn't flooded: the next pass offers more
            if ($acted >= self::BATCH) { $more = true; break; }
            try {
                $k = self::act($pdo, $runId, $it, $uid, $tz);
                if ($k === '') continue;
                $done[$k]++; $acted++;
                if ($k === 'offered') $offers++;
                if (str_starts_with($it['ref'], 'entity:')) $listings[] = (int) substr($it['ref'], 7);
                if (str_starts_with($it['ref'], 'landmark:')) $landmarks[] = (int) substr($it['ref'], 9);
            } catch (Throwable $x) { $done['failed']++; error_log('DataCleanup act ' . $it['ref'] . ': ' . $x->getMessage()); }
        }
        self::reindex($pdo, $listings, $landmarks);
        $prev = $open ? (json_decode((string) $open['counts_json'], true) ?: []) : [];
        foreach ($done as $k => $v) $done[$k] = $v + (int) ($prev['done'][$k] ?? 0);
        $counts = ['done' => $done, 'left' => $left, 'check' => count($checks), 'checks' => $checks, 'errors' => $found['errors'], 'more' => $more];
        $pdo->prepare("UPDATE $R SET counts_json = ?, finished_at = ? WHERE id = ?")->execute([json_encode($counts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $more ? null : date('Y-m-d H:i:s'), $runId]);
        $st = $pdo->prepare("SELECT * FROM $R WHERE id = ?"); $st->execute([$runId]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    private static function openOffers(PDO $pdo): int
    {
        try { $st = $pdo->prepare("SELECT COUNT(*) FROM suggestions WHERE device_hash = ? AND status = 'new'"); $st->execute([self::DEVICE]); return (int) $st->fetchColumn(); } catch (Throwable $x) { return 0; }
    }

    /** One record, by its rule's action. Returns what was done (a key of run()'s counts) or '' when nothing changed. */
    private static function act(PDO $pdo, int $runId, array $it, int $uid, string $tz): string
    {
        $ref = (string) $it['ref']; $rule = (string) $it['rule']; $target = (string) $it['target']; $d = (array) ($it['data'] ?? []);
        $why = 'Data cleanup: ' . self::RULES[$rule][1] . '. ' . $it['why'];
        $log = function (string $field, $new) use ($pdo, $runId, $it, $ref, $rule, $target, $why, $uid, $tz): void {
            $old = self::get($pdo, $ref, $field);
            if ($old === $new) return;
            self::put($pdo, $ref, $field, $new);
            $pdo->prepare('INSERT INTO ' . Database::t('cleanup_ledger') . ' (run_id, store, ref, name, rule, action, target, field, old_value, new_value, why, by_id, at, tz) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$runId, $it['store'], $ref, mb_substr((string) $it['name'], 0, 160), $rule, self::RULES[$rule][3], strtok($target, ':'), $field, $old, $new, mb_substr($why, 0, 300), $uid ?: null, date('Y-m-d H:i:s'), mb_substr($tz, 0, 64)]);
        };
        $meta = fn (array $v, string $src = 'admin', int $locked = 1) => json_encode(['v' => json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 's' => $src, 'l' => $locked], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        switch ($rule) {
            case 'junk_name': case 'no_floor': case 'page_only':   // off the public site, kept, with its reason and planned target
                $log('meta:removed', $meta(['at' => date('Y-m-d'), 'by' => $uid, 'reason' => mb_substr($why, 0, 300), 'cleanup' => $runId, 'target' => $target]));
                $log('is_suppressed', '1');
                return $target === 'help_find' ? 'help_find' : ($target === 'sighting' ? 'sighting' : 'quarantined');
            case 'osm_only':
                $cur = self::get($pdo, $ref, 'meta:unconfirmed');
                $have = $cur !== null ? (array) (json_decode((string) (json_decode($cur, true)['v'] ?? ''), true)['fields'] ?? []) : [];
                $f = $have + array_map(fn ($l) => 'From OpenStreetMap only: not yet confirmed', (array) ($d['fields'] ?? []));
                $log('meta:unconfirmed', $meta(['fields' => $f, 'at' => date('Y-m-d'), 'cleanup' => $runId], 'ai_crawler', 0));
                return 'unconfirmed';
            case 'closed_one_site':
                $log('meta:closed_signal', $meta(['line' => (string) ($d['note'] ?? '') !== '' ? (string) $d['note'] : 'One site said it closed', 'url' => '', 'at' => (string) ($d['at'] ?? '') ?: date('Y-m-d'), 'from' => 'cleanup'], 'ai_crawler', 0));
                $log('meta:closed', null);
                return 'caution';
            case 'duplicate':
                require_once __DIR__ . '/Suggestions.php';
                $id = Suggestions::create($pdo, ['kind' => 'same', 'topic' => 'business', 'entity_id' => (int) $d['a'], 'same_as_id' => (int) $d['b'],
                    'note' => 'Found by Data cleanup: ' . $it['name'] . ' have ' . lcfirst((string) $it['why']) . '. Merge them if they\'re one business; turn it down if not (it isn\'t asked again).', 'context' => 'Data cleanup: duplicates'], null, self::DEVICE);
                $pdo->prepare('INSERT INTO ' . Database::t('cleanup_ledger') . ' (run_id, store, ref, name, rule, action, target, field, old_value, new_value, why, by_id, at, tz) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?)')
                    ->execute([$runId, 'listings', $ref, mb_substr((string) $it['name'], 0, 160), $rule, 'merge', 'merge', 'suggestion', (string) $id, mb_substr($why, 0, 300), $uid ?: null, date('Y-m-d H:i:s'), mb_substr($tz, 0, 64)]);
                return 'offered';
            case 'staged_junk':
                $note = self::get($pdo, $ref, 'review_note');
                $log('review_note', mb_substr($why . ($note ? ' · ' . $note : ''), 0, 1000));
                $log('status', 'quarantined');
                return 'quarantined';
            case 'store_junk': case 'store_guard': case 'store_cite':
                $log('held', mb_substr((string) ($d['held'] ?? 'junk'), 0, 12));
                return 'held';
            case 'protected_open': case 'nation_sensitive':   // held ("Hidden by us" survives the monthly reload), a person's press
                $r = self::landmark($pdo, (int) substr($ref, 9));
                if (!$r || !in_array($r['status'], ['shown'], true)) return '';   // a person's approval is never undone by a machine
                $log('review_note', mb_substr($why . ($rule === 'protected_open' ? ' Planned: story only (named and told, no pin), once landmarks have that level (R7).' : ''), 0, 300));
                $log('reviewed_by', (string) $uid);
                $log('status', 'hidden');
                if (trim((string) $r['nation']) !== '') { try { require_once __DIR__ . '/Nations.php'; Nations::log($pdo, (string) $r['nation'], 'landmark', (string) $r['gnis_id'], (string) $r['name'], 'shown', 'hidden', $uid, '', '', mb_substr($why, 0, 250)); } catch (Throwable $x) {} }
                return $rule === 'protected_open' ? 'story_only' : 'held';
            case 'wiki_text':
                if (!empty($d['ready'])) { $log('extract', ''); return 'cleared'; }
                if (!empty($d['queued'])) return '';
                $log('about_queued_at', date('Y-m-d H:i:s'));   // Place descriptions writes it (PlaceFinder::aboutTick), then a later pass clears
                return 'queued';
        }
        return '';
    }

    // ---- field access: one place that knows how each stored value is read and written ----------------------------------

    /** [table, key column, id] for a ref. */
    private static function where(string $ref): array
    {
        if (!preg_match('/^(entity|staged|fact|landmark|pair):([\d-]+)$/', $ref, $m)) throw new InvalidArgumentException('Unknown record.');
        return [$m[1], $m[2]];
    }

    private const COLUMNS = ['entity' => ['is_suppressed'], 'staged' => ['status', 'review_note'], 'fact' => ['held'], 'landmark' => ['status', 'review_note', 'reviewed_by', 'extract', 'about_queued_at']];

    /** The stored value now (a metadata row as JSON {v, s, l}), or null. */
    private static function get(PDO $pdo, string $ref, string $field): ?string
    {
        [$kind, $id] = self::where($ref);
        if ($kind === 'entity' && str_starts_with($field, 'meta:')) {
            $st = $pdo->prepare('SELECT meta_value, source_type, is_locked FROM entity_metadata WHERE entity_id = ? AND meta_key = ?'); $st->execute([(int) $id, substr($field, 5)]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return $r ? json_encode(['v' => (string) $r['meta_value'], 's' => (string) $r['source_type'], 'l' => (int) $r['is_locked']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        }
        if ($kind === 'pair' && $field === 'suggestion') return null;
        if (!in_array($field, self::COLUMNS[$kind] ?? [], true)) throw new InvalidArgumentException('Unknown field.');
        [$t, $k] = self::table($kind);
        $st = $pdo->prepare("SELECT $field FROM $t WHERE $k = ?"); $st->execute([(int) $id]);
        $v = $st->fetchColumn();
        return $v === false || $v === null ? null : (string) $v;
    }

    private static function put(PDO $pdo, string $ref, string $field, ?string $v): void
    {
        [$kind, $id] = self::where($ref);
        if ($kind === 'entity' && str_starts_with($field, 'meta:')) {
            $key = substr($field, 5);
            if ($v === null) { $pdo->prepare('DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = ?')->execute([(int) $id, $key]); return; }
            $x = json_decode($v, true);
            $pdo->prepare('INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())
                           ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = VALUES(source_type), is_locked = VALUES(is_locked), updated_at = NOW()')
                ->execute([(int) $id, $key, (string) $x['v'], (string) $x['s'], (int) $x['l']]);
            return;
        }
        if (!in_array($field, self::COLUMNS[$kind] ?? [], true)) throw new InvalidArgumentException('Unknown field.');
        [$t, $k] = self::table($kind);
        if ($kind === 'entity') { $pdo->prepare("UPDATE $t SET is_suppressed = ?, updated_by_type = 'admin', updated_at = NOW() WHERE id = ?")->execute([(int) $v, (int) $id]); return; }
        $pdo->prepare("UPDATE $t SET $field = ? WHERE $k = ?")->execute([$field === 'reviewed_by' && $v !== null ? (int) $v : $v, (int) $id]);
    }

    private static function table(string $kind): array
    {
        return ['entity' => ['entities', 'id'], 'staged' => [Database::t('crawler_raw_index'), 'id'], 'fact' => [Database::t('source_facts'), 'id'], 'landmark' => ['landmarks', 'gnis_id']][$kind];
    }

    private static function landmark(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT gnis_id, name, nation, status FROM landmarks WHERE gnis_id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private static function reindex(PDO $pdo, array $listings, array $landmarks): void
    {
        try {
            require_once __DIR__ . '/SearchIndex.php';
            foreach (array_chunk(array_values(array_unique($listings)), 200) as $c) SearchIndex::indexListings($pdo, $c);
            foreach (array_unique($landmarks) as $id) SearchIndex::refreshLandmark($pdo, $id);
        } catch (Throwable $x) { error_log('DataCleanup reindex: ' . $x->getMessage()); }
        if ($listings && is_file(__DIR__ . '/ListingConfidence.php')) { require_once __DIR__ . '/ListingConfidence.php'; foreach (array_slice(array_unique($listings), 0, 1500) as $id) ListingConfidence::refresh($pdo, $id); }
    }

    /**
     * Undo: one record's changes in a run ($ref), or the whole run ($ref ''). A field changed since (someone edited it,
     * a later pass) is left as it is now, and said: a person's later change wins. Returns [undone, left].
     */
    public static function undo(PDO $pdo, int $runId, string $ref, int $uid): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('Data cleanup isn\'t set up yet.');
        $L = Database::t('cleanup_ledger');
        $st = $pdo->prepare("SELECT * FROM $L WHERE run_id = ? AND undone_at IS NULL" . ($ref !== '' ? ' AND ref = ?' : '') . ' ORDER BY id DESC');
        $st->execute($ref !== '' ? [$runId, $ref] : [$runId]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) throw new RuntimeException($ref !== '' ? 'Nothing left to undo for it.' : 'Nothing left to undo in this pass.');
        $undone = 0; $left = 0; $listings = []; $landmarks = [];
        $mark = $pdo->prepare("UPDATE $L SET undone_at = ?, undone_by = ?, undo_note = ? WHERE id = ?");
        foreach ($rows as $r) {
            try {
                if ($r['field'] === 'suggestion') {   // a merge offer: withdrawn while nobody has answered it
                    $s = $pdo->prepare('SELECT status FROM suggestions WHERE id = ?'); $s->execute([(int) $r['new_value']]);
                    if ((string) $s->fetchColumn() !== 'new') { $mark->execute([date('Y-m-d H:i:s'), $uid, 'Already answered in Review: left as decided', (int) $r['id']]); $left++; continue; }
                    require_once __DIR__ . '/Suggestions.php';
                    Suggestions::decide($pdo, (int) $r['new_value'], 'dismissed', $uid);
                } else {
                    $now = self::get($pdo, (string) $r['ref'], (string) $r['field']);
                    if ($now !== ($r['new_value'] === null ? null : (string) $r['new_value'])) { $mark->execute([date('Y-m-d H:i:s'), $uid, 'Changed since: left as it is now', (int) $r['id']]); $left++; continue; }
                    self::put($pdo, (string) $r['ref'], (string) $r['field'], $r['old_value'] === null ? null : (string) $r['old_value']);
                }
                $mark->execute([date('Y-m-d H:i:s'), $uid, 'Undone', (int) $r['id']]); $undone++;
                if (str_starts_with((string) $r['ref'], 'entity:')) $listings[] = (int) substr((string) $r['ref'], 7);
                if (str_starts_with((string) $r['ref'], 'landmark:')) $landmarks[] = (int) substr((string) $r['ref'], 9);
            } catch (Throwable $x) { $left++; error_log('DataCleanup undo #' . $r['id'] . ': ' . $x->getMessage()); }
        }
        self::reindex($pdo, $listings, $landmarks);
        if ($ref === '') $pdo->prepare('UPDATE ' . Database::t('cleanup_runs') . ' SET undone_at = ?, undone_by = ?, finished_at = COALESCE(finished_at, ?) WHERE id = ?')->execute([date('Y-m-d H:i:s'), $uid, date('Y-m-d H:i:s'), $runId]);
        return [$undone, $left];
    }

    // ---- Wikipedia's words: replaced before they're cleared (Jason, 2026-11-14) ---------------------------------------

    /** [queued and waiting, written and ready to clear, still holding the text]. */
    public static function wikiCounts(PDO $pdo): array
    {
        try {
            $r = $pdo->query("SELECT SUM(about_queued_at IS NOT NULL AND research_at IS NULL), SUM(research IS NOT NULL AND research <> ''), COUNT(*) FROM landmarks WHERE extract <> '' AND status IN ('shown', 'approved')")->fetch(PDO::FETCH_NUM);
            return [(int) $r[0], (int) $r[1], (int) $r[2]];
        } catch (Throwable $x) { return [0, 0, 0]; }
    }

    /** Whether Place descriptions may write now: [true, ''] or [false, why] (AI use, the automation switches). */
    public static function canWrite(PDO $pdo): array
    {
        try { require_once __DIR__ . '/AiClient.php'; $a = AiClient::allow($pdo, 'place_about'); return [(bool) $a[0], (string) ($a[1] ?? '')]; } catch (Throwable $x) { return [false, 'AI use isn\'t set up here.']; }
    }

    /** A staff press: writes up to $n queued descriptions now (inside AI use's cap and switches). */
    public static function writeNow(PDO $pdo, int $n = 10): int
    {
        [$ok, $why] = self::canWrite($pdo);
        if (!$ok) throw new RuntimeException($why !== '' ? $why : 'Place descriptions can\'t write now.');
        require_once __DIR__ . '/PlaceFinder.php';
        return PlaceFinder::aboutTick($pdo, max(1, min(25, $n)));
    }

    // ---- Pulse: one case for what needs a person (CLAUDE.md: one case per kind of chore, a step per item) --------------

    /** The last pass that finished and wasn't undone, with its counts. */
    public static function lastRun(PDO $pdo): ?array
    {
        if (!self::ready($pdo)) return null;
        $r = $pdo->query('SELECT * FROM ' . Database::t('cleanup_runs') . ' WHERE finished_at IS NOT NULL AND undone_at IS NULL ORDER BY id DESC LIMIT 1')->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $r['counts'] = json_decode((string) $r['counts_json'], true) ?: [];
        return $r;
    }

    /** Check these from the last pass that nobody has marked looked at, by rule. */
    public static function openChecks(PDO $pdo, ?array $run = null): array
    {
        $run = $run ?? self::lastRun($pdo);
        if (!$run) return [];
        $seen = [];
        try { foreach ($pdo->query('SELECT CONCAT(rule, \'|\', ref) FROM ' . Database::t('cleanup_checks'))->fetchAll(PDO::FETCH_COLUMN) as $k) $seen[$k] = true; } catch (Throwable $x) {}
        $by = [];
        foreach ((array) ($run['counts']['checks'] ?? []) as $c) if (!isset($seen[$c['rule'] . '|' . $c['ref']])) $by[$c['rule']][] = $c;
        return $by;
    }

    /** [key, severity, title, why, when, action word] for Pulse::items. */
    public static function pulseItems(PDO $pdo): array
    {
        $run = self::lastRun($pdo);
        if (!$run) return [];
        $by = self::openChecks($pdo, $run);
        $offers = self::openOffers($pdo);
        $n = array_sum(array_map('count', $by));
        if (!$n && !$offers && empty($run['counts']['more'])) return [];
        $d = (array) ($run['counts']['done'] ?? []);
        $report = 'Last pass ' . date('M j', strtotime((string) $run['finished_at'])) . ': ' . implode(', ', array_filter([
            ($d['quarantined'] ?? 0) + ($d['sighting'] ?? 0) + ($d['help_find'] ?? 0) ? (($d['quarantined'] ?? 0) + ($d['sighting'] ?? 0) + ($d['help_find'] ?? 0)) . ' taken off the site' : '',
            ($d['unconfirmed'] ?? 0) ? $d['unconfirmed'] . ' marked unconfirmed' : '', ($d['caution'] ?? 0) ? $d['caution'] . ' Closed to caution' : '',
            ($d['held'] ?? 0) + ($d['story_only'] ?? 0) ? (($d['held'] ?? 0) + ($d['story_only'] ?? 0)) . ' held' : '', ($d['offered'] ?? 0) ? $d['offered'] . ' merges offered' : '',
            ($d['cleared'] ?? 0) ? $d['cleared'] . ' Wikipedia texts replaced' : '', (int) ($run['counts']['left'] ?? 0) ? (int) $run['counts']['left'] . ' left' : '']) ?: ['nothing changed']) . '.';
        return [['cleanup:checks', 'update', 'Data cleanup needs a person: ' . ($n ? $n . ' to check' : '') . ($n && $offers ? ', ' : '') . ($offers ? $offers . ' merge offer' . ($offers === 1 ? '' : 's') . ' in Review' : ''),
                 'Records a person entered or decided, which the cleanup never changes, and what it offered for a person to decide. ' . $report, (string) $run['finished_at'], 'Look']];
    }

    /** The case's steps: a step per kind, each a button that does it (Pulse::manage → pulseDo). */
    public static function pulseSteps(PDO $pdo, callable $s): array
    {
        $st = []; $by = self::openChecks($pdo);
        foreach ($by as $rule => $list) {
            $names = implode('; ', array_map(fn ($c) => $c['name'] . ' (' . $c['why'] . ')', array_slice($list, 0, 5)));
            $st[] = $s('Check these: ' . self::RULES[$rule][1] . ' (' . count($list) . ')', 'A person entered or decided something on each, so the cleanup leaves them: open each and fix it by hand, or leave it. ' . $names . (count($list) > 5 ? '; and ' . (count($list) - 5) . ' more on the page.' : '.'),
                ['do', 'cleanup_seen:' . $rule, 'Looked at them']);
            $st[] = $s('Open the list', 'Insights → Data cleanup lists them with a link to each.', ['tool', '/admin/insights/cleanup?checks=' . $rule]);
        }
        if (($o = self::openOffers($pdo)) > 0) $st[] = $s('Answer the merge offers (' . $o . ')', 'In Review: merge the ones that are one business, turn down the rest (never asked again).', ['tool', '/admin/crawler-review.php?type=suggest']);
        $run = self::lastRun($pdo);
        if ($run && !empty($run['counts']['more'])) $st[] = $s('Finish the pass', 'It stopped at ' . self::BATCH . ' records a press; Continue carries on.', ['tool', '/admin/insights/cleanup']);
        $st[] = $s('Resolve the case', 'Once these are looked at. A new pass opens it again only for new ones.', ['resolve']);
        return $st;
    }

    /** Pulse::manage: "Looked at them" for one rule's Check these. */
    public static function pulseDo(PDO $pdo, string $what, int $uid): string
    {
        if (!preg_match('/^cleanup_seen:([a-z_]+)$/', $what, $m) || !isset(self::RULES[$m[1]])) throw new RuntimeException('Unknown step.');
        $list = self::openChecks($pdo)[$m[1]] ?? [];
        $ins = $pdo->prepare('INSERT IGNORE INTO ' . Database::t('cleanup_checks') . ' (ref, rule, looked_by, looked_at) VALUES (?, ?, ?, ?)');
        foreach ($list as $c) $ins->execute([$c['ref'], $m[1], $uid, date('Y-m-d H:i:s')]);
        return count($list) . ' marked looked at: they aren\'t asked about again unless they change.';
    }
}
