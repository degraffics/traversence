<?php
// app/scripts/data_cleanup_tick.php — Data cleanup's daily pass (decisions/0163 §8 stage 1b): a pass for every rule of
// Insights → Data cleanup, reversibly, so the record stays in line with today's rules. Shipped off: it runs only when its
// daily pass is switched on there, and only while automation is on (Automation::JOBS, under the master switch). Not in
// Scheduler::AUTO, so cPanel has no job for it until someone adds it in System Configuration → Scheduled tasks.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('data_cleanup_tick');   // its runs show in System Configuration → Scheduled tasks; paused while automation is
require_once __DIR__ . '/../lib/DataCleanup.php';
$pdo = Database::connection();
if (!DataCleanup::ready($pdo)) { echo "Not ready yet: Data cleanup's database update hasn't run.\n"; exit(0); }
if (!DataCleanup::autoOn($pdo)) { echo "Off: the daily pass is switched off (Insights → Data cleanup).\n"; exit(0); }
$open = DataCleanup::openRun($pdo);
if ($open && (string) $open['rule'] !== '') { echo "Waiting: a pass for one rule is under way; it's finished by a person first.\n"; exit(0); }
$r = DataCleanup::run($pdo, '', 0, 'the daily pass', 'UTC', 'schedule');
$c = json_decode((string) ($r['counts_json'] ?? ''), true) ?: [];
echo 'Pass #' . (int) ($r['id'] ?? 0) . ': ' . array_sum(array_map('intval', (array) ($c['done'] ?? []))) . ' changed, ' . (int) ($c['check'] ?? 0) . ' to check' . (!empty($c['more']) ? ', more next time' : '') . ".\n";
