/* js/admin-outside.js — System Configuration → Outside services as a table (Jason, 2026-11-17: "treat it like the table view
 * with search and filters sorting"). Search across names, uses and key names; one filter (needs a look, in use, not in use,
 * or a kind); sort by status (the default), name or this month's cost; a row opens its full card in place. The search,
 * filter and sort are remembered in this browser. Each card's Test runs its pre-flight line (one status with the
 * pre-flight) through /admin/api/config/preflight; its row's mark follows. #svc-<key> opens that row. */
(function () {
  var box = document.getElementById('os-table');
  if (!box) return;
  var root = box.closest('.os'), csrf = root ? root.getAttribute('data-csrf') || '' : '', rowsEl = box.querySelector('.os-rows');
  var rows = Array.prototype.slice.call(box.querySelectorAll('.os-r')), KEY = 'os:table';
  var S = (function () { try { return JSON.parse(localStorage.getItem(KEY) || 'null') || {}; } catch (e) { return {}; } })();
  S.q = S.q || ''; S.f = S.f || ''; S.sort = S.sort || 'status';
  var order = rows.slice();   // the server's order is the status order
  var q = box.querySelector('[data-os-q]'), fb = box.querySelector('[data-os-fb]'), fl = fb.nextElementSibling;
  function keep() { try { localStorage.setItem(KEY, JSON.stringify({ q: S.q, f: S.f, sort: S.sort })); } catch (e) {} }
  function match(r, f) {
    if (!f) return true;
    if (f === 'need') return r.getAttribute('data-need') === '1';
    if (f === 'on') return r.getAttribute('data-on') === '1';
    if (f === 'off') return r.getAttribute('data-on') !== '1';
    if (f.indexOf('kind:') === 0) return (' ' + r.getAttribute('data-kinds') + ' ').indexOf(' ' + f.slice(5) + ' ') >= 0;
    return true;
  }
  function draw() {
    var words = S.q.toLowerCase().split(/\s+/).filter(Boolean), shown = 0;
    var list = order.slice();
    if (S.sort === 'name') list.sort(function (a, b) { return a.getAttribute('data-name').localeCompare(b.getAttribute('data-name')); });
    if (S.sort === 'cost') list.sort(function (a, b) { return (+b.getAttribute('data-cost')) - (+a.getAttribute('data-cost')); });
    list.forEach(function (r) {
      var t = r.getAttribute('data-q'), ok = match(r, S.f) && words.every(function (w) { return t.indexOf(w) >= 0; });
      r.hidden = !ok; if (ok) shown++; rowsEl.appendChild(r);
    });
    box.querySelector('[data-os-none]').hidden = shown > 0;
    // the filter's counts, as the kit's dropdowns show them
    fl.querySelectorAll('[data-fv]').forEach(function (o) {
      var v = o.getAttribute('data-fv'), n = rows.filter(function (r) { return match(r, v); }).length;
      o.querySelector('i').textContent = n; o.classList.toggle('on', v === S.f);
      if (v === S.f) { box.querySelector('[data-os-fl]').textContent = o.firstChild.textContent; box.querySelector('[data-os-fn]').textContent = shown; }
    });
    box.querySelectorAll('[data-os-sort]').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-os-sort') === S.sort); });
    if (q.value !== S.q) q.value = S.q;
  }
  q.addEventListener('input', function () { S.q = q.value; keep(); draw(); });
  fb.addEventListener('click', function (e) { e.stopPropagation(); var open = fl.hidden; fl.hidden = !open; fb.setAttribute('aria-expanded', open ? 'true' : 'false'); });
  fl.addEventListener('click', function (e) { var o = e.target.closest('[data-fv]'); if (!o) return; S.f = o.getAttribute('data-fv'); fl.hidden = true; fb.setAttribute('aria-expanded', 'false'); keep(); draw(); });
  document.addEventListener('click', function (e) { if (!fb.parentNode.contains(e.target)) { fl.hidden = true; fb.setAttribute('aria-expanded', 'false'); } });
  box.querySelectorAll('[data-os-sort]').forEach(function (b) { b.addEventListener('click', function () { S.sort = b.getAttribute('data-os-sort'); keep(); draw(); }); });

  function openRow(r, on) { var h = r.querySelector('.os-rh'), b = r.querySelector('.os-rb'); b.hidden = !on; h.setAttribute('aria-expanded', on ? 'true' : 'false'); if (on) r.setAttribute('open-row', ''); else r.removeAttribute('open-row'); }
  box.addEventListener('click', function (e) {
    var h = e.target.closest('.os-rh');
    if (h) { var r = h.closest('.os-r'); openRow(r, h.getAttribute('aria-expanded') !== 'true'); return; }
    var t = e.target.closest('[data-os-test]');
    if (!t) return;
    var r2 = t.closest('.os-r'), said = r2.querySelector('[data-os-said]');
    if (window.TvAsk && TvAsk.busy) TvAsk.busy(t, true);
    var body = { action: 'run', id: 'svc:' + t.getAttribute('data-os-test') };
    fetch('/admin/api/config/preflight', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (x) { return x.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again.' } }; }); })
      .then(function (j) {
        if (window.TvAsk && TvAsk.busy) TvAsk.busy(t, false);
        if (!j.ok) throw new Error((j.error && j.error.message) || 'That didn\'t work. Try again.');
        var m = r2.querySelector('.os-m'), s = j.s === 'ok' ? 'ok' : (j.s === 'bad' ? 'bad' : 'na');   // the mark is the answer (Jason, 2026-11-17)
        var icons = { ok: '<path d="M20 6 9 17l-5-5"/>', bad: '<path d="M18 6 6 18M6 6l12 12"/>', na: '<path d="M5 12h14"/>' };
        m.className = 'os-m os-m-' + s; var svg = m.querySelector('svg'); if (svg) svg.innerHTML = icons[s];
        said.textContent = ({ ok: 'Ready', bad: 'Not ready', na: 'Not needed yet', wait: 'Waiting' }[j.s] || j.s) + ': ' + j.said;
        if (j.s === 'bad') r2.setAttribute('data-need', '1');
        var at = r2.querySelector('[data-os-at]');
        if (at && j.at) { at.innerHTML = '<time datetime="' + new Date(j.at * 1000).toISOString() + '" data-tv-time></time>'; if (window.TvTime) TvTime.paint(at); }
        draw();
      })
      .catch(function (err) { if (window.TvAsk && TvAsk.busy) TvAsk.busy(t, false); if (window.TvAsk) TvAsk.say(err.message, { anchor: said, bad: true }); });
  });
  function fromHash() {
    var r = location.hash && document.getElementById(location.hash.slice(1));
    if (!r || !r.classList.contains('os-r')) return;
    if (r.hidden) { S.q = ''; S.f = ''; draw(); }   // a link to a row always shows it
    openRow(r, true); r.style.boxShadow = '0 0 0 3px #8FBCA8';
    setTimeout(function () { r.scrollIntoView({ block: 'start' }); }, 50);
  }
  rows.forEach(function (r) { if (r.querySelector('.os-rh').getAttribute('aria-expanded') === 'true') r.setAttribute('open-row', ''); });
  draw(); fromHash();
  window.addEventListener('hashchange', fromHash);
})();
