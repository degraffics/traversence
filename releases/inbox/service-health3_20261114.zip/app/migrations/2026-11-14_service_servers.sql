-- An outside service's servers as settings (Jason, 2026-11-14: "server lists become settings, not code"), on its card in
-- Outside services: added, paused and resumed there; the pre-use check (ServiceHealth) holds one with an issue. Seeds
-- OpenStreetMap's Overpass servers, overpass-api.de back on the list (held by its open ban until its probe answers 200).
-- Also osm_usage.last_at, for the pace. Safe to run twice.
CREATE TABLE IF NOT EXISTS service_servers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  service VARCHAR(40) NOT NULL,
  role VARCHAR(20) NOT NULL,
  url VARCHAR(255) NOT NULL,
  sort SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  paused TINYINT(1) NOT NULL DEFAULT 0,
  paused_why VARCHAR(255) NULL,
  paused_by INT UNSIGNED NULL,
  paused_at DATETIME NULL,
  added_by INT UNSIGNED NULL,
  added_at DATETIME NOT NULL,
  UNIQUE KEY uq_ss_url (service, role, url),
  KEY idx_ss_role (service, role, sort)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO service_servers (service, role, url, sort, added_at) VALUES
  ('osm', 'overpass', 'https://overpass-api.de/api/interpreter', 1, UTC_TIMESTAMP()),
  ('osm', 'overpass', 'https://overpass.private.coffee/api/interpreter', 2, UTC_TIMESTAMP()),
  ('osm', 'overpass', 'https://overpass.kumi.systems/api/interpreter', 3, UTC_TIMESTAMP()),
  ('osm', 'overpass', 'https://maps.mail.ru/osm/tools/overpass/api/interpreter', 4, UTC_TIMESTAMP());

CREATE TABLE IF NOT EXISTS osm_usage (
  day DATE NOT NULL,
  caller VARCHAR(10) NOT NULL,
  queries INT UNSIGNED NOT NULL DEFAULT 0,
  bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (day, caller)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE osm_usage ADD COLUMN last_at DATETIME DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'osm_usage' AND COLUMN_NAME = 'last_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
