<?php
/**
 * Claims.php: claiming a listing (decisions/0070).
 *
 *   1. An email code to the claimant's own account → the listing is "Managed by owner" (claimed-unverified): the
 *      owner record is written to listing_access (and kept in step in entities.owner_user_id), and they can edit the
 *      description, photos, hours and services. Name, phone, address and website wait for an admin (claim_changes),
 *      and the evidence from our sources can still update them.
 *   2. Text the claim's code to the Verify number. From the listed number, an admin marks it ✓ Verified; from another
 *      number, an admin contacts the claimant within 48 hours and decides, case by case.
 *   Other routes: an email at the business's own domain (verified at once), a document, or an appointment.
 *
 * One claim goes ahead per listing; a second request is held ("Claim Request On Hold") and admins get a Notice.
 * Admins decide flexibly: verify, keep as managed, ask for more, decline, or start a held request.
 */
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/StepUpAuth.php';
require_once __DIR__ . '/Mailer.php';
require_once __DIR__ . '/TrustScore.php';

final class Claims
{
    /** The Verify number claimants text (decisions/0070 §3; Jason's number in the pilot). CLAIM_VERIFY_NUMBER overrides. */
    public const VERIFY_NUMBER = '602-708-3795';
    public const DUE_HOURS = 48;
    public const DOC_MAX = 25 * 1024 * 1024;
    public const DOC_TYPES = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png'];
    public const PROTECTED = ['name', 'phone', 'address', 'city', 'state', 'website'];
    public const PLANS = ['free' => 'Free', 'basic' => 'Basic Partner ($29.95/mo)', 'core' => 'Core Partner ($79.95/mo)', 'strategic' => 'Strategic Partner ($229.95/mo)', 'cornerstone' => 'Cornerstone ($399.95/mo)'];
    /** Claims that hold the listing: nobody else's claim goes ahead while one of these is open. */
    private const HOLDING = ['managed', 'verified'];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM listing_claims LIMIT 1'); return $ok = true; } catch (Throwable) { return $ok = false; }
    }

    public static function verifyNumber(): string
    {
        return (string) (getenv('CLAIM_VERIFY_NUMBER') ?: self::VERIFY_NUMBER);
    }

    public static function phone10(?string $s): string
    {
        $d = preg_replace('/\D/', '', (string) $s);
        if (strlen($d) === 11 && $d[0] === '1') $d = substr($d, 1);
        return strlen($d) === 10 ? $d : '';
    }

    public static function fmtPhone(string $p10): string
    {
        return strlen($p10) === 10 ? sprintf('(%s) %s-%s', substr($p10, 0, 3), substr($p10, 3, 3), substr($p10, 6)) : $p10;
    }

    // ------------------------------------------------------------------ reading

    /** The listing as the claim page needs it: name, place, status, owner, phone and website on file. */
    public static function listing(PDO $pdo, int $e): ?array
    {
        $st = $pdo->prepare(
            "SELECT e.id, e.name, e.status, e.owner_user_id, e.plan_tier,
                    JSON_UNQUOTE(mc.meta_value) AS city, JSON_UNQUOTE(ms.meta_value) AS state,
                    JSON_UNQUOTE(mp.meta_value) AS phone, JSON_UNQUOTE(mw.meta_value) AS website, JSON_UNQUOTE(ma.meta_value) AS address
               FROM entities e
               LEFT JOIN entity_metadata mc ON mc.entity_id = e.id AND mc.meta_key = 'city'
               LEFT JOIN entity_metadata ms ON ms.entity_id = e.id AND ms.meta_key = 'state'
               LEFT JOIN entity_metadata mp ON mp.entity_id = e.id AND mp.meta_key = 'phone'
               LEFT JOIN entity_metadata mw ON mw.entity_id = e.id AND mw.meta_key = 'website'
               LEFT JOIN entity_metadata ma ON ma.entity_id = e.id AND ma.meta_key = 'address'
              WHERE e.id = ? AND e.entity_type = 'merchant' AND (e.is_suppressed = 0
                    OR EXISTS (SELECT 1 FROM entity_metadata hf WHERE hf.entity_id = e.id AND hf.meta_key = 'removed' AND hf.meta_value LIKE '%\"target\":\"help_find\"%')) LIMIT 1"
        );
        $st->execute([$e]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    /**
     * The listing as its own team's portal needs it, hidden or not (site-audit case #22): an owner or manager always
     * opens their own listing's editor; the public site and search keep hiding it (listing() above is unchanged).
     * Only listings Team::listingsOf gives this person ($mine: that list, when the caller has it already).
     * Adds is_suppressed, so the page can say it's hidden (hiddenReason()).
     */
    public static function ownListing(PDO $pdo, int $uid, int $e, ?array $mine = null): ?array
    {
        if ($uid <= 0 || $e <= 0) return null;
        if ($mine === null) { require_once __DIR__ . '/Team.php'; $mine = Team::listingsOf($pdo, $uid); }
        if (!isset($mine[$e])) return null;
        $st = $pdo->prepare(
            "SELECT e.id, e.name, e.status, e.owner_user_id, e.plan_tier, e.is_suppressed,
                    JSON_UNQUOTE(mc.meta_value) AS city, JSON_UNQUOTE(ms.meta_value) AS state,
                    JSON_UNQUOTE(mp.meta_value) AS phone, JSON_UNQUOTE(mw.meta_value) AS website, JSON_UNQUOTE(ma.meta_value) AS address
               FROM entities e
               LEFT JOIN entity_metadata mc ON mc.entity_id = e.id AND mc.meta_key = 'city'
               LEFT JOIN entity_metadata ms ON ms.entity_id = e.id AND ms.meta_key = 'state'
               LEFT JOIN entity_metadata mp ON mp.entity_id = e.id AND mp.meta_key = 'phone'
               LEFT JOIN entity_metadata mw ON mw.entity_id = e.id AND mw.meta_key = 'website'
               LEFT JOIN entity_metadata ma ON ma.entity_id = e.id AND ma.meta_key = 'address'
              WHERE e.id = ? AND e.entity_type = 'merchant' LIMIT 1"
        );
        $st->execute([$e]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    /**
     * Why the team's own listing isn't on the public site, in words for them; null when it's public.
     * Said plainly only where the reason is theirs to know (the test listing, a private client record, merged into
     * another listing, not public yet). Anything held by staff (a data check, low trust, Restricted, a nation's or a
     * sensitive place's hold: decisions/0066, 0164 R7) is only "under review", with Ask our team: never the staff reason.
     * A merged listing also carries 'merged' => [kept id, kept name]: changes belong on the kept one, so the editor locks.
     * @return array{text: string, link: ?array{0: string, 1: string}, ask: bool, merged?: array{0: int, 1: string}}|null
     */
    public static function hiddenReason(PDO $pdo, array $row): ?array
    {
        $e = (int) ($row['id'] ?? 0);
        $public = ['unclaimed', 'claimed-unverified', 'pending-verification', 'verified'];
        if ((int) ($row['is_suppressed'] ?? 0) === 0 && in_array((string) ($row['status'] ?? ''), $public, true)) return null;
        $review = ['text' => 'It\'s under review by our team, so it isn\'t on the public site or in search for now. You can keep editing it; your changes show once it\'s back.', 'link' => null, 'ask' => true];
        if ((int) ($row['is_suppressed'] ?? 0) === 0)
            return ['text' => 'It isn\'t public yet: our team checks a new or changed listing before it shows on the site and in search. You can keep editing it meanwhile.', 'link' => null, 'ask' => true];
        try {   // the hidden test listing for the site's checks (TestAccounts)
            $st = $pdo->prepare("SELECT 1 FROM test_records WHERE kind = 'listing' AND ref_id = ? LIMIT 1"); $st->execute([$e]);
            if ($st->fetchColumn()) return ['text' => 'This is the test listing for the site\'s checks. It\'s never shown on the public site or in search.', 'link' => null, 'ask' => false];
        } catch (Throwable) {}
        try {   // a private client record (Clients::makePrivate): kept for orders, never public
            $st = $pdo->prepare('SELECT 1 FROM client_listings WHERE entity_id = ? AND private = 1 LIMIT 1'); $st->execute([$e]);
            if ($st->fetchColumn()) return ['text' => 'It\'s kept private: our team holds it for your orders with us, and it isn\'t shown on the public site or in search. To list your business publicly, ask our team.', 'link' => null, 'ask' => true];
        } catch (Throwable) {}
        try {   // merged into another listing of the same business (decisions/0072): its link takes visitors there
            $st = $pdo->prepare("SELECT meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key = 'same_as'"); $st->execute([$e]);
            $same = json_decode((string) $st->fetchColumn(), true);
            $keep = is_array($same) ? (int) ($same['id'] ?? 0) : 0;
            if ($keep > 0) {
                $st = $pdo->prepare("SELECT name FROM entities WHERE id = ? AND is_suppressed = 0 AND entity_type = 'merchant'"); $st->execute([$keep]);
                $kept = $st->fetchColumn();
                if ($kept !== false) return ['text' => 'It was joined with ' . (string) $kept . ', another listing for the same business, which visitors see instead; its old link takes them there. Changes here wouldn\'t show anywhere, so make them on ' . (string) $kept . '.',
                                             'link' => ['/listing/view.php?id=' . $keep, 'See ' . (string) $kept], 'ask' => true, 'merged' => [$keep, (string) $kept]];
            }
        } catch (Throwable) {}
        return $review;
    }

    /**
     * Ask our team about a hidden listing, from its editor (Never a dead end): to our inbox, with the listing and the
     * person's account email to answer at. 3 a session a day, as ListingMessages::askTeam; our inbox, so it costs nothing.
     */
    public static function askAboutHidden(PDO $pdo, array $user, int $e, string $note): string
    {
        require_once __DIR__ . '/ListingMessages.php';
        $to = ListingMessages::helpTo();
        $row = self::ownListing($pdo, (int) ($user['id'] ?? 0), $e);
        if (!$row) throw new InvalidArgumentException('That listing isn\'t one you manage.');
        $email = trim((string) ($user['email'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Your account has no email for us to answer at. Write to ' . $to . '.');
        $tries = array_filter((array) ($_SESSION['bp_hidden_ask'] ?? []), fn ($t) => $t > time() - 86400);
        if (count($tries) >= 3) throw new InvalidArgumentException('We\'ve had your notes today. Write to ' . $to . ' and we\'ll answer you there.');
        $tries[] = time(); $_SESSION['bp_hidden_ask'] = array_values($tries);
        $why = self::hiddenReason($pdo, $row);
        $body = 'Listing: ' . $row['name'] . ' (#' . $e . ')' . "\nAdmin: " . (getenv('APP_URL') ?: 'https://traversence.com') . '/admin/listing-edit.php?id=' . $e
              . "\nWhat the owner sees: " . ($why['text'] ?? 'public') . "\n\nTheir note:\n" . (trim($note) !== '' ? mb_substr(trim($note), 0, 1500) : '(none)') . "\n\nReply to: " . $email;
        try { Mailer::send($to, 'Why is my listing hidden? ' . mb_substr((string) $row['name'], 0, 80), $body, null, '', '', $email); }
        catch (Throwable $x) { error_log('hidden listing ask: ' . $x->getMessage()); throw new InvalidArgumentException('That didn\'t send. Write to ' . $to . ' instead.'); }
        return 'Sent to our team. We\'ll answer you at ' . $email . ', usually within a business day.';
    }

    public static function get(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM listing_claims WHERE id = ?');
        $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    /** The claim that holds a listing now (managed or verified), if any. */
    public static function holding(PDO $pdo, int $e): ?array
    {
        $st = $pdo->prepare("SELECT * FROM listing_claims WHERE entity_id = ? AND status IN ('managed','verified') ORDER BY id DESC LIMIT 1");
        $st->execute([$e]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    /** This person's latest claim on a listing, any status. */
    public static function mine(PDO $pdo, int $uid, int $e): ?array
    {
        $st = $pdo->prepare('SELECT * FROM listing_claims WHERE user_id = ? AND entity_id = ? ORDER BY id DESC LIMIT 1');
        $st->execute([$uid, $e]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    /** Everything this person has claimed or asked to claim, newest first (for the business dashboard). */
    public static function forUser(PDO $pdo, int $uid): array
    {
        $st = $pdo->prepare("SELECT c.*, e.name, e.status AS entity_status, e.plan_tier FROM listing_claims c JOIN entities e ON e.id = c.entity_id
                              WHERE c.user_id = ? AND c.status IN ('managed','verified','on_hold') ORDER BY c.id DESC");
        $st->execute([$uid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Whether the person may claim: signed in, 18+, Verification on. Returns what's missing (empty = ready). */
    public static function missing(PDO $pdo, int $uid): array
    {
        require_once __DIR__ . '/MemberVerification.php';
        require_once __DIR__ . '/AgeGate.php';
        $m = [];
        // decisions/0071 §1: a confirmed email and a phone on the account
        $st = $pdo->prepare('SELECT email_verified_at, phone FROM users WHERE id = ?');
        try { $st->execute([$uid]); $u = $st->fetch(PDO::FETCH_ASSOC) ?: []; } catch (PDOException) { $u = ['email_verified_at' => 1, 'phone' => '0000000000']; }   // before the migration
        if (empty($u['email_verified_at'])) $m[] = 'email';
        if (self::phone10((string) ($u['phone'] ?? '')) === '') $m[] = 'phone';
        if (!AgeGate::confirmed($pdo, $uid)) $m[] = 'age';
        if (!MemberVerification::consented($pdo, $uid)) $m[] = 'verification';
        return $m;
    }

    // ------------------------------------------------------------------ step 1: the email code

    /**
     * Starts a claim: emails a code to the claimant's own account. If another claim holds the listing, nothing is
     * sent: the caller puts the request on hold instead (see hold()).
     * @return array{held: bool}
     */
    public static function start(PDO $pdo, array $user, int $e): array
    {
        $uid = (int) $user['id'];
        $l = self::listing($pdo, $e);
        if (!$l) throw new InvalidArgumentException('Listing not found.');
        require_once __DIR__ . '/PlaceScope.php';
        if (($no = PlaceScope::notABusiness($pdo, $e)) !== '') throw new InvalidArgumentException($no . ' To fix something on it, use Suggest an edit.');   // a drop box has no owner
        if ($m = self::missing($pdo, $uid)) throw new DomainException(implode(',', $m));
        $h = self::holding($pdo, $e);
        if ($h && (int) $h['user_id'] === $uid) throw new InvalidArgumentException('You already manage this listing. It\'s in your business dashboard.');
        if ($h || !in_array($l['status'], ['unclaimed'], true)) return ['held' => true];
        $code = StepUpAuth::issue($pdo, $uid, 'claim', (string) $e);
        Mailer::sendCode((string) $user['email'], (string) $code, 'code to claim ' . $l['name'],
            "Your code to claim {$l['name']} is: {$code}\n\nIt expires in 10 minutes. If you didn't ask for this, you can ignore this email.");
        return ['held' => false];
    }

    /**
     * Confirms the email code: the listing becomes Managed by owner, the claim gets its text code and a 48-hour due
     * time, and admins are told.
     */
    public static function confirm(PDO $pdo, array $user, int $e, string $code, string $role = '', string $phone = ''): array
    {
        $uid = (int) $user['id'];
        if ($m = self::missing($pdo, $uid)) throw new DomainException(implode(',', $m));
        try { StepUpAuth::verify($pdo, $uid, 'claim', $code, (string) $e); }
        catch (RuntimeException $x) { throw new InvalidArgumentException($x->getMessage()); }
        $l = self::listing($pdo, $e);
        if (!$l) throw new InvalidArgumentException('Listing not found.');
        $id = 0;
        Database::transaction(function (PDO $pdo) use ($e, $uid, $l, $role, $phone, &$id) {
            $st = $pdo->prepare('SELECT status FROM entities WHERE id = ? FOR UPDATE');
            $st->execute([$e]);
            if ($st->fetchColumn() !== 'unclaimed' || self::holding($pdo, $e)) throw new RuntimeException('held');
            $id = self::open($pdo, $e, $uid, null, $role, $phone, (string) $l['phone']);
        });
        $c = self::get($pdo, $id);
        self::tellAdmins($pdo, 'New claim: ' . $l['name'], self::who($pdo, $uid) . " claimed {$l['name']} (Managed by owner). Text code {$c['text_code']}; listed phone "
            . (self::fmtPhone((string) $c['listed_phone']) ?: 'none') . '. Contact due by ' . $c['due_at'] . '.');
        return $c;
    }

    /**
     * A business its owner just added (decisions/0071): the new listing opens straight away as their claim, Managed by
     * owner, and admins get a Notice. The email code was already confirmed by AddBusiness.
     */
    public static function adopt(PDO $pdo, int $uid, int $e, string $phone, string $role): array
    {
        $id = 0;
        Database::transaction(function (PDO $pdo) use ($e, $uid, $phone, $role, &$id) {
            $st = $pdo->prepare('SELECT status FROM entities WHERE id = ? FOR UPDATE');
            $st->execute([$e]);
            if ($st->fetchColumn() !== 'unclaimed') throw new RuntimeException('held');
            $id = self::open($pdo, $e, $uid, null, $role, $phone, $phone);
        });
        $c = self::get($pdo, $id);
        $l = self::listing($pdo, $e);
        self::note($pdo, $id, 'Added by its owner (decisions/0071).');
        self::tellAdmins($pdo, 'Notice: new business added by its owner: ' . ($l['name'] ?? ''), self::who($pdo, $uid) . ' added ' . ($l['name'] ?? '') . ' (' . ($l['city'] ?? '') . ').'
            . " It's live as Managed by owner. They can send you a verification request, or text {$c['text_code']}.");
        return $c;
    }

    /** Admins are told (used by the verification request). */
    /** An owner claimed it: the lead goes to its territory's rep (decisions/0108). Never stops the claim. */
    private static function toSales(PDO $pdo, int $e): void
    {
        try { require_once __DIR__ . '/Leads.php'; if (Leads::ready($pdo)) Leads::route($pdo, $e, 'inbound'); } catch (Throwable $x) { error_log('claim to sales: ' . $x->getMessage()); }
    }

    public static function notifyAdmins(PDO $pdo, string $subject, string $body): void { self::tellAdmins($pdo, $subject, $body); }

    /** The claimant is told (used by the verification request). */
    public static function notifyClaimant(PDO $pdo, array $c, string $subject, string $body): void { self::tellClaimant($pdo, $c, $subject, $body); }

    /** Writes a managed claim and its owner record. Inside a transaction. */
    private static function open(PDO $pdo, int $e, int $uid, ?int $group, string $role, string $phone, string $listedPhone): int
    {
        $pdo->prepare("UPDATE entities SET owner_user_id = ?, status = 'claimed-unverified', updated_by_type = 'user', updated_at = NOW() WHERE id = ?")->execute([$uid, $e]);
        $pdo->prepare("INSERT INTO listing_access (entity_id, user_id, access_level, granted_by_user_id) VALUES (?, ?, 'owner', ?)
                        ON DUPLICATE KEY UPDATE access_level = 'owner'")->execute([$e, $uid, $uid]);
        $pdo->prepare("INSERT INTO listing_claims (entity_id, user_id, group_id, status, role_note, text_code, listed_phone, claimant_phone, due_at)
                        VALUES (?, ?, ?, 'managed', ?, ?, ?, ?, ?)")
            ->execute([$e, $uid, $group, mb_substr(trim($role), 0, 80), self::newCode($pdo), self::phone10($listedPhone), self::phone10($phone),
                       date('Y-m-d H:i:s', time() + self::DUE_HOURS * 3600)]);
        $cid = (int) $pdo->lastInsertId();
        self::toSales($pdo, $e);
        return $cid;
    }

    private static function newCode(PDO $pdo): string
    {
        for ($i = 0; $i < 20; $i++) {
            $c = 'TV-' . str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
            $st = $pdo->prepare("SELECT 1 FROM listing_claims WHERE text_code = ? AND status IN ('managed','on_hold')");
            $st->execute([$c]);
            if (!$st->fetchColumn()) return $c;
        }
        return 'TV-' . random_int(10000, 99999);
    }

    /** Adds the phone the claimant will text from, and what they are (owner, manager…), after the email step. */
    public static function details(PDO $pdo, int $uid, int $claimId, string $phone, string $role): void
    {
        $c = self::ownClaim($pdo, $uid, $claimId);
        $pdo->prepare('UPDATE listing_claims SET claimant_phone = ?, role_note = ? WHERE id = ?')
            ->execute([self::phone10($phone), mb_substr(trim($role), 0, 80), $c['id']]);
    }

    // ------------------------------------------------------------------ a second request: on hold

    /** "Claim Request On Hold": saved with whatever contact details and note they leave, and admins get a Notice. */
    public static function hold(PDO $pdo, array $user, int $e, array $contact): array
    {
        $uid = (int) $user['id'];
        $l = self::listing($pdo, $e);
        if (!$l) throw new InvalidArgumentException('Listing not found.');
        $mine = self::mine($pdo, $uid, $e);
        $det = json_encode(array_filter([
            'phone' => self::phone10($contact['phone'] ?? ''), 'role' => mb_substr(trim((string) ($contact['role'] ?? '')), 0, 80),
            'note' => mb_substr(trim((string) ($contact['note'] ?? '')), 0, 1000),
        ]), JSON_UNESCAPED_UNICODE);
        if ($mine && $mine['status'] === 'on_hold') {
            $pdo->prepare('UPDATE listing_claims SET details = ? WHERE id = ?')->execute([$det, $mine['id']]);
            return self::get($pdo, (int) $mine['id']);
        }
        $pdo->prepare("INSERT INTO listing_claims (entity_id, user_id, status, role_note, claimant_phone, listed_phone, details) VALUES (?, ?, 'on_hold', ?, ?, ?, ?)")
            ->execute([$e, $uid, mb_substr(trim((string) ($contact['role'] ?? '')), 0, 80), self::phone10($contact['phone'] ?? ''), self::phone10($l['phone']), $det]);
        $id = (int) $pdo->lastInsertId();
        self::toSales($pdo, $e);
        $h = self::holding($pdo, $e);
        self::tellAdmins($pdo, 'Notice: a second claim request for ' . $l['name'],
            self::who($pdo, $uid) . " asked to claim {$l['name']}, which " . ($h ? self::who($pdo, (int) $h['user_id']) . ' already ' . ($h['status'] === 'verified' ? 'owns (verified)' : 'manages') : 'is already claimed')
            . '. Their request is on hold in Admin → Claims.');
        return self::get($pdo, $id);
    }

    // ------------------------------------------------------------------ other routes

    /** The domain of the listing's website, if it has one: "example.com". */
    public static function siteDomain(?string $website): string
    {
        $w = trim((string) $website);
        if ($w === '') return '';
        $h = parse_url(str_contains($w, '://') ? $w : 'http://' . $w, PHP_URL_HOST) ?: '';
        return strtolower(preg_replace('/^www\./i', '', $h));
    }

    /** Sends a code to an address at the business's own domain. */
    public static function domainStart(PDO $pdo, int $uid, int $claimId, string $email): void
    {
        $c = self::ownClaim($pdo, $uid, $claimId);
        $l = self::listing($pdo, (int) $c['entity_id']);
        $dom = self::siteDomain($l['website'] ?? '');
        $email = strtolower(trim($email));
        if ($dom === '') throw new InvalidArgumentException('This listing has no website on file, so this way isn\'t available.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@' . $dom)) throw new InvalidArgumentException("Use an address ending in @{$dom}.");
        $code = StepUpAuth::issue($pdo, $uid, 'claim', 'domain:' . $c['id'] . ':' . $email);
        Mailer::sendCode($email, (string) $code, 'code to confirm ' . $l['name'], "Your code to confirm {$l['name']} is: {$code}\n\nIt expires in 10 minutes.");
        self::setDetail($pdo, (int) $c['id'], 'domain_email', $email);
        $pdo->prepare("UPDATE listing_claims SET route = 'domain' WHERE id = ?")->execute([$c['id']]);
    }

    /** The code from the business's own domain: ✓ Verified at once. */
    public static function domainConfirm(PDO $pdo, int $uid, int $claimId, string $code): void
    {
        $c = self::ownClaim($pdo, $uid, $claimId);
        $email = (string) (self::detailsOf($c)['domain_email'] ?? '');
        try { StepUpAuth::verify($pdo, $uid, 'claim', $code, 'domain:' . $c['id'] . ':' . $email); }
        catch (RuntimeException $x) { throw new InvalidArgumentException($x->getMessage()); }
        self::verify($pdo, (int) $c['id'], null, 'domain', 'Confirmed by a code sent to ' . $email . '.');
    }

    /** A document (bill, license, lease, photos, brochure): kept outside the site folders, never served, purged after the decision. */
    /** May this person send a document for this claim? (the uploader checks before anything is sent: decisions/0127) */
    public static function canDocument(PDO $pdo, int $uid, int $claimId): void { self::ownClaim($pdo, $uid, $claimId, true); }

    public static function document(PDO $pdo, int $uid, int $claimId, array $file): void
    {
        $c = self::ownClaim($pdo, $uid, $claimId, true);
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_file((string) $file['tmp_name'])) throw new InvalidArgumentException('The file didn\'t arrive. Try again.');
        if ((int) $file['size'] > self::DOC_MAX) throw new InvalidArgumentException('That file is over 25 MB.');
        $type = (new finfo(FILEINFO_MIME_TYPE))->file((string) $file['tmp_name']) ?: '';
        if (!isset(self::DOC_TYPES[$type])) throw new InvalidArgumentException('Send a PDF, JPG or PNG.');
        require_once __DIR__ . '/Store.php';   // in the claimant's folder (decisions/0124)
        $sub = 'members/' . Store::folder('members', $uid);
        $dir = self::lockedDir($sub);
        $name = bin2hex(random_bytes(12)) . '.' . self::DOC_TYPES[$type];
        if (!@rename((string) $file['tmp_name'], "$dir/$name") && !@copy((string) $file['tmp_name'], "$dir/$name"))   // as it arrived (api/upload.php, target claim_doc)
            throw new RuntimeException('Could not store the file.');
        @chmod("$dir/$name", 0600);   // the site's own account only
        Store::keep("$dir/$name");   // to S3 (private, decisions/0123)
        if ($c['doc_path'] !== '' && !str_contains((string) $c['doc_path'], '..')) Store::remove(self::storage() . '/' . $c['doc_path']);
        $pdo->prepare('UPDATE listing_claims SET doc_path = ?, doc_name = ?, route = IF(route = "text", "document", route) WHERE id = ?')
            ->execute([$sub . "/$name", mb_substr(basename((string) $file['name']), 0, 160), $c['id']]);
        $l = self::listing($pdo, (int) $c['entity_id']);
        self::tellAdmins($pdo, 'Document for a claim: ' . ($l['name'] ?? ''), self::who($pdo, $uid) . ' sent a document for their claim. Admin → Claims.');
    }

    /** An appointment with an agent: email, phone, address, preferred date and time, call or visit. */
    public static function appointment(PDO $pdo, int $uid, int $claimId, array $in): void
    {
        $c = self::ownClaim($pdo, $uid, $claimId, true);
        $a = [
            'email' => strtolower(trim((string) ($in['email'] ?? ''))), 'phone' => self::phone10($in['phone'] ?? ''),
            'address' => mb_substr(trim((string) ($in['address'] ?? '')), 0, 200), 'when' => mb_substr(trim((string) ($in['when'] ?? '')), 0, 40),
            'how' => ($in['how'] ?? '') === 'visit' ? 'visit' : 'call',
        ];
        if (!filter_var($a['email'], FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Add an email we can reach you at.');
        if ($a['phone'] === '') throw new InvalidArgumentException('Add a 10-digit phone number.');
        if ($a['how'] === 'visit' && $a['address'] === '') throw new InvalidArgumentException('Add the address to meet at.');
        if ($a['when'] === '' || strtotime($a['when']) === false) throw new InvalidArgumentException('Pick a date and time.');
        self::setDetail($pdo, (int) $c['id'], 'appointment', $a);
        $pdo->prepare("UPDATE listing_claims SET route = 'appointment' WHERE id = ?")->execute([$c['id']]);
        $l = self::listing($pdo, (int) $c['entity_id']);
        self::tellAdmins($pdo, 'Appointment requested: ' . ($l['name'] ?? ''), self::who($pdo, $uid) . ' asked for a ' . $a['how'] . ' on ' . $a['when'] . '. Admin → Claims.');
    }

    /** The claimant takes their claim back: the listing returns to unclaimed. */
    public static function withdraw(PDO $pdo, int $uid, int $claimId): void
    {
        $c = self::ownClaim($pdo, $uid, $claimId, true);
        if ($c['status'] === 'on_hold') { $pdo->prepare("UPDATE listing_claims SET status = 'withdrawn' WHERE id = ?")->execute([$c['id']]); self::purgeDocuments($pdo); return; }
        Database::transaction(fn (PDO $pdo) => self::release($pdo, $c, 'withdrawn', null));
        self::purgeDocuments($pdo);
    }

    // ------------------------------------------------------------------ several locations

    /** The claimant's other locations we can see: unclaimed listings with the same phone or website, or the same name. */
    public static function siblings(PDO $pdo, int $e): array
    {
        $l = self::listing($pdo, $e);
        if (!$l) return [];
        $p = self::phone10($l['phone']); $d = self::siteDomain($l['website']);
        $st = $pdo->prepare(
            "SELECT e.id, e.name, JSON_UNQUOTE(mc.meta_value) AS city, JSON_UNQUOTE(ma.meta_value) AS address, JSON_UNQUOTE(mp.meta_value) AS phone, JSON_UNQUOTE(mw.meta_value) AS website
               FROM entities e
               LEFT JOIN entity_metadata mc ON mc.entity_id = e.id AND mc.meta_key = 'city'
               LEFT JOIN entity_metadata ma ON ma.entity_id = e.id AND ma.meta_key = 'address'
               LEFT JOIN entity_metadata mp ON mp.entity_id = e.id AND mp.meta_key = 'phone'
               LEFT JOIN entity_metadata mw ON mw.entity_id = e.id AND mw.meta_key = 'website'
              WHERE e.id <> ? AND e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status = 'unclaimed'
                AND (e.name = ? OR (? <> '' AND REGEXP_REPLACE(JSON_UNQUOTE(mp.meta_value), '[^0-9]', '') LIKE CONCAT('%', ?))
                     OR (? <> '' AND JSON_UNQUOTE(mw.meta_value) LIKE CONCAT('%', ?, '%')))
              ORDER BY e.name LIMIT 25"
        );
        try { $st->execute([$e, $l['name'], $p, $p, $d, $d]); }
        catch (PDOException) {   // MySQL 5.7 has no REGEXP_REPLACE: same name or website only, phone compared in PHP
            $st = $pdo->prepare(
                "SELECT e.id, e.name, JSON_UNQUOTE(mc.meta_value) AS city, JSON_UNQUOTE(ma.meta_value) AS address, JSON_UNQUOTE(mp.meta_value) AS phone, JSON_UNQUOTE(mw.meta_value) AS website
                   FROM entities e
                   LEFT JOIN entity_metadata mc ON mc.entity_id = e.id AND mc.meta_key = 'city'
                   LEFT JOIN entity_metadata ma ON ma.entity_id = e.id AND ma.meta_key = 'address'
                   LEFT JOIN entity_metadata mp ON mp.entity_id = e.id AND mp.meta_key = 'phone'
                   LEFT JOIN entity_metadata mw ON mw.entity_id = e.id AND mw.meta_key = 'website'
                  WHERE e.id <> ? AND e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status = 'unclaimed'
                    AND (e.name = ? OR (? <> '' AND mp.meta_value LIKE CONCAT('%', ?, '%')) OR (? <> '' AND mw.meta_value LIKE CONCAT('%', ?, '%')))
                  ORDER BY e.name LIMIT 25");
            $st->execute([$e, $l['name'], $p, substr($p, -4), $d, $d]);
        }
        // the same name counts only when it's fairly rare: "ATM" or "U.S. Post Office" listings aren't one owner's
        $c = $pdo->prepare("SELECT COUNT(*) FROM entities WHERE name = ? AND entity_type = 'merchant'");
        $c->execute([$l['name']]);
        $byName = (int) $c->fetchColumn() < 10;
        return array_values(array_filter($st->fetchAll(PDO::FETCH_ASSOC), function ($r) use ($l, $p, $d, $byName) {
            return ($byName && $r['name'] === $l['name']) || ($p !== '' && self::phone10($r['phone']) === $p) || ($d !== '' && self::siteDomain($r['website']) === $d);
        }));
    }

    /** Claims the other locations the claimant picked, together with this one: each its own listing and claim, one group. */
    public static function addLocations(PDO $pdo, int $uid, int $claimId, array $ids): array
    {
        $c = self::ownClaim($pdo, $uid, $claimId);
        $ok = array_column(self::siblings($pdo, (int) $c['entity_id']), 'id');
        $added = [];
        foreach (array_unique(array_map('intval', $ids)) as $e) {
            if (!in_array($e, array_map('intval', $ok), true)) continue;
            Database::transaction(function (PDO $pdo) use ($e, $uid, $c, &$added) {
                $st = $pdo->prepare('SELECT status FROM entities WHERE id = ? FOR UPDATE');
                $st->execute([$e]);
                if ($st->fetchColumn() !== 'unclaimed' || self::holding($pdo, $e)) return;
                $l = self::listing($pdo, $e);
                $added[] = self::open($pdo, $e, $uid, (int) ($c['group_id'] ?: $c['id']), (string) $c['role_note'], (string) $c['claimant_phone'], (string) ($l['phone'] ?? ''));
            });
        }
        if ($added) {
            $pdo->prepare('UPDATE listing_claims SET group_id = id WHERE id = ? AND group_id IS NULL')->execute([$c['id']]);
            self::tellAdmins($pdo, 'Several locations claimed together', self::who($pdo, $uid) . ' added ' . count($added) . ' more location(s) to their claim. Admin → Claims.');
        }
        return $added;
    }

    // ------------------------------------------------------------------ admin decisions (flexible)

    /** ✓ Verified. $groupToo verifies every managed claim in the same group. */
    public static function verify(PDO $pdo, int $claimId, ?int $adminId, string $how, string $note = '', bool $groupToo = false): void
    {
        $c = self::get($pdo, $claimId);
        if (!$c || $c['status'] !== 'managed') throw new InvalidArgumentException('This claim isn\'t waiting to be verified.');
        $ids = [(int) $c['id']];
        if ($groupToo && $c['group_id']) {
            $st = $pdo->prepare("SELECT id FROM listing_claims WHERE group_id = ? AND status = 'managed'");
            $st->execute([$c['group_id']]);
            $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        }
        foreach ($ids as $id) {
            $x = self::get($pdo, $id);
            $tier = $how === 'domain' ? 1 : 4;
            Database::transaction(function (PDO $pdo) use ($x, $adminId, $tier, $how, $note) {
                $pdo->prepare("UPDATE entities SET status = 'verified', verified_tier = ?, updated_by_type = ?, updated_at = NOW() WHERE id = ?")
                    ->execute([$tier, $adminId ? 'admin' : 'user', $x['entity_id']]);
                $pdo->prepare("UPDATE listing_claims SET status = 'verified', decided_by = ?, decided_at = NOW(), admin_note = CONCAT_WS('\n', admin_note, ?) WHERE id = ?")
                    ->execute([$adminId, $note !== '' ? $note : null, $x['id']]);
                $pdo->prepare("INSERT INTO verification_attempts (entity_id, method, status, reviewed_by_user_id, notes, created_at, resolved_at) VALUES (?, ?, 'approved', ?, ?, NOW(), NOW())")
                    ->execute([$x['entity_id'], $how === 'domain' ? 'domain_match' : ($x['doc_path'] !== '' ? 'document_upload' : 'admin_override'), $adminId, 'Claim ' . $x['id'] . ': ' . ($note ?: $how)]);
                try { TrustScore::awardVerificationTier($pdo, (int) $x['entity_id'], (int) $x['user_id'], $tier, $adminId ? 'admin' : 'user', $x['doc_path'] !== ''); } catch (Throwable $t) { error_log('claims trust: ' . $t->getMessage()); }
            });
            // changes the owner made while Managed now apply: the fields are theirs (decisions/0070 §3)
            foreach (self::changes($pdo, (int) $x['entity_id']) as $ch) if ((int) $ch['user_id'] === (int) $x['user_id']) {
                try { self::decideChange($pdo, (int) $ch['id'], (int) ($adminId ?? $x['user_id']), true); } catch (Throwable) {}
            }
            self::purgeDocuments($pdo);
            // messages left on the listing before its claim are delivered now, into the business's Pulse (decisions/0172 §3.3)
            if (is_file(__DIR__ . '/ListingMessages.php')) { try { require_once __DIR__ . '/ListingMessages.php'; ListingMessages::claimed($pdo, (int) $x['entity_id']); } catch (Throwable $t) { error_log('claims: left messages: ' . $t->getMessage()); } }
            self::tellClaimant($pdo, $x, 'Your listing is verified', 'Your claim is confirmed: your listing now shows ✓ Verified, and its name, phone, address and website are yours to edit from your business dashboard.');
        }
    }

    /** Decline: the listing returns to unclaimed, and any changes waiting from this claimant are dismissed. */
    public static function decline(PDO $pdo, int $claimId, int $adminId, string $note = ''): void
    {
        $c = self::get($pdo, $claimId);
        if (!$c || !in_array($c['status'], ['managed', 'on_hold'], true)) throw new InvalidArgumentException('This claim is already closed.');
        if ($c['status'] === 'on_hold') {
            $pdo->prepare("UPDATE listing_claims SET status = 'declined', decided_by = ?, decided_at = NOW(), admin_note = CONCAT_WS('\n', admin_note, ?) WHERE id = ?")
                ->execute([$adminId, $note ?: null, $c['id']]);
        } else {
            Database::transaction(fn (PDO $pdo) => self::release($pdo, $c, 'declined', $adminId, $note));
        }
        self::purgeDocuments($pdo);
        self::tellClaimant($pdo, $c, 'About your claim', 'We couldn\'t confirm your claim this time.' . ($note !== '' ? "\n\n" . $note : '') . "\n\nIf you think this is a mistake, reply to this email or start a new claim.");
    }

    /** Starts a held request as the claim (the listing must be free): it becomes Managed by owner. */
    public static function startHeld(PDO $pdo, int $claimId, int $adminId): void
    {
        $c = self::get($pdo, $claimId);
        if (!$c || $c['status'] !== 'on_hold') throw new InvalidArgumentException('This request isn\'t on hold.');
        Database::transaction(function (PDO $pdo) use ($c, $adminId) {
            $st = $pdo->prepare('SELECT status FROM entities WHERE id = ? FOR UPDATE');
            $st->execute([$c['entity_id']]);
            if ($st->fetchColumn() !== 'unclaimed' || self::holding($pdo, (int) $c['entity_id'])) throw new InvalidArgumentException('Another claim still holds this listing. Decline or withdraw it first.');
            $l = self::listing($pdo, (int) $c['entity_id']);
            $pdo->prepare("UPDATE listing_claims SET status = 'withdrawn', decided_by = ?, decided_at = NOW(), admin_note = CONCAT_WS('\n', admin_note, 'Started as a claim.') WHERE id = ?")->execute([$adminId, $c['id']]);
            self::open($pdo, (int) $c['entity_id'], (int) $c['user_id'], null, (string) $c['role_note'], (string) $c['claimant_phone'], (string) ($l['phone'] ?? ''));
        });
        self::tellClaimant($pdo, $c, 'Your claim is going ahead', 'Your claim request is no longer on hold: you now manage the listing. Open your business dashboard to finish the last step.');
    }

    /** Ask the claimant for more: emailed, and noted on the claim. */
    public static function askMore(PDO $pdo, int $claimId, int $adminId, string $message): void
    {
        $c = self::get($pdo, $claimId);
        if (!$c) throw new InvalidArgumentException('Claim not found.');
        if (trim($message) === '') throw new InvalidArgumentException('Write what you need from them.');
        self::logContact($pdo, $claimId, $adminId, 'email', 'Asked for more: ' . $message);
        self::tellClaimant($pdo, $c, 'About your claim: one more thing', $message . "\n\nYou can add a document or ask for a call from your business dashboard.");
    }

    /** A note of what was done: who was contacted, how, and what was found. Pushes the due time off once contacted. */
    public static function logContact(PDO $pdo, int $claimId, int $adminId, string $channel, string $note): void
    {
        $c = self::get($pdo, $claimId);
        if (!$c) throw new InvalidArgumentException('Claim not found.');
        $log = json_decode((string) $c['contact_log'], true) ?: [];
        $log[] = ['at' => date('Y-m-d H:i'), 'by' => $adminId, 'channel' => mb_substr($channel, 0, 20), 'note' => mb_substr(trim($note), 0, 1000)];
        $pdo->prepare('UPDATE listing_claims SET contact_log = ?, due_at = NULL WHERE id = ?')->execute([json_encode($log, JSON_UNESCAPED_UNICODE), $claimId]);
    }

    /** Private notes on the claim, for the next admin. */
    public static function note(PDO $pdo, int $claimId, string $note): void
    {
        $pdo->prepare("UPDATE listing_claims SET admin_note = CONCAT_WS('\n', admin_note, ?) WHERE id = ?")->execute([mb_substr(trim($note), 0, 1000), $claimId]);
    }

    /** Ends a claim and returns the listing: owner record removed, status unclaimed, waiting changes dismissed. */
    private static function release(PDO $pdo, array $c, string $status, ?int $adminId, string $note = ''): void
    {
        $e = (int) $c['entity_id']; $u = (int) $c['user_id'];
        $pdo->prepare("UPDATE entities SET owner_user_id = NULL, status = 'unclaimed', verified_tier = NULL, updated_at = NOW() WHERE id = ? AND owner_user_id = ?")->execute([$e, $u]);
        $pdo->prepare("DELETE FROM listing_access WHERE entity_id = ? AND user_id = ? AND access_level = 'owner'")->execute([$e, $u]);
        $pdo->prepare("UPDATE claim_changes SET status = 'dismissed', decided_by = ?, decided_at = NOW() WHERE entity_id = ? AND user_id = ? AND status = 'waiting'")->execute([$adminId, $e, $u]);
        $pdo->prepare("UPDATE listing_claims SET status = ?, decided_by = ?, decided_at = NOW(), admin_note = CONCAT_WS('\n', admin_note, ?) WHERE id = ?")->execute([$status, $adminId, $note ?: null, $c['id']]);
    }

    // ------------------------------------------------------------------ protected fields while Managed by owner

    /** An owner's change to name, phone, address or website on a Managed listing: waits for an admin. */
    public static function queueChange(PDO $pdo, int $uid, int $e, string $field, string $old, string $new): void
    {
        $pdo->prepare("UPDATE claim_changes SET status = 'dismissed', decided_at = NOW() WHERE entity_id = ? AND field = ? AND status = 'waiting'")->execute([$e, $field]);
        $pdo->prepare('INSERT INTO claim_changes (entity_id, user_id, field, old_value, new_value) VALUES (?, ?, ?, ?, ?)')
            ->execute([$e, $uid, $field, mb_substr($old, 0, 600), mb_substr($new, 0, 600)]);
    }

    public static function changes(PDO $pdo, int $e, string $status = 'waiting'): array
    {
        $st = $pdo->prepare('SELECT * FROM claim_changes WHERE entity_id = ? AND status = ? ORDER BY id');
        $st->execute([$e, $status]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** An admin applies or dismisses a waiting change. Applied values are written as the owner's, locked. */
    public static function decideChange(PDO $pdo, int $changeId, int $adminId, bool $apply): void
    {
        $st = $pdo->prepare("SELECT * FROM claim_changes WHERE id = ? AND status = 'waiting'");
        $st->execute([$changeId]);
        $ch = $st->fetch(PDO::FETCH_ASSOC);
        if (!$ch) throw new InvalidArgumentException('That change was already decided.');
        if ($apply) self::writeField($pdo, (int) $ch['entity_id'], (string) $ch['field'], (string) $ch['new_value']);
        $pdo->prepare('UPDATE claim_changes SET status = ?, decided_by = ?, decided_at = NOW() WHERE id = ?')->execute([$apply ? 'applied' : 'dismissed', $adminId, $changeId]);
    }

    /** Writes a field as the owner's: the name on the entity, everything else as locked metadata. */
    public static function writeField(PDO $pdo, int $e, string $field, string $value): void
    {
        if ($field === 'name') {
            $pdo->prepare("UPDATE entities SET name = ?, updated_by_type = 'owner', updated_at = NOW() WHERE id = ?")->execute([mb_substr($value, 0, 255), $e]);
            require_once __DIR__ . '/Identity.php';
            Identity::listingWrote($pdo, $e, 'name', mb_substr($value, 0, 255), 'owner');
            return;
        }
        $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, trust_score, created_at, updated_at)
                        VALUES (?, ?, ?, 'owner', 1, 100.00, NOW(), NOW())
                        ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = 'owner', is_locked = 1, updated_at = NOW()")
            ->execute([$e, $field, json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
        require_once __DIR__ . '/Identity.php';
        Identity::listingWrote($pdo, $e, $field, $value, 'owner');   // the owner's word, in the listing's identity (decisions/0133)
    }

    // ------------------------------------------------------------------ activation: choosing a plan

    /**
     * Free starts at once. A paid plan starts a 30-day trial (decisions/0108): it ends on Free unless the owner adds a
     * card and keeps it (Billing). Trial content stays noindex (0034). Choosing again replaces a trial, never a paid plan.
     */
    public static function activate(PDO $pdo, int $uid, int $claimId, string $plan, bool $agreed = false): void
    {
        require_once __DIR__ . '/Billing.php';
        $c = self::ownClaim($pdo, $uid, $claimId);
        if (!isset(self::PLANS[$plan])) throw new InvalidArgumentException('Pick a plan.');
        // a paid plan's trial starts only after its checkout: the plan, the dates, what happens at the end, and the
        // Terms agreed (Jason, 2026-10-24: "no terms or confirmation upon clicking activate")
        if ($plan !== 'free' && !$agreed) throw new InvalidArgumentException('Review the trial and agree to the Terms first.');
        $e = (int) $c['entity_id'];
        $cur = Billing::current($pdo, 'listing', $e);
        if ($cur && $cur['status'] !== 'trial') throw new InvalidArgumentException('This listing has a paid plan: change it on its Plans page.');
        Database::transaction(function (PDO $pdo) use ($c, $plan, $e, $cur) {
            if ($cur) Billing::endNow($pdo, (int) $cur['id'], 'another plan chosen');
            if ($plan !== 'free') Billing::trial($pdo, 0, 'listing', $e, $plan, 30);
            else Billing::syncTier($pdo, 'listing', $e);
            $pdo->prepare('UPDATE listing_claims SET plan = ?, activated_at = NOW() WHERE id = ?')->execute([$plan, $c['id']]);
        });
        if ($plan !== 'free') { try { require_once __DIR__ . '/Roles.php'; Roles::log($pdo, $uid, null, 'billing', 'trial terms agreed', 'listing ' . $e . ': ' . $plan . ', 30 days, ' . ($_SERVER['REMOTE_ADDR'] ?? '')); } catch (Throwable) {} }
    }

    /** Whether the listing is on a trial: its page carries noindex (0034) until it's kept. */
    public static function onTrial(PDO $pdo, int $e): bool
    {
        try {
            $st = $pdo->prepare("SELECT 1 FROM subscriptions WHERE owner_type = 'listing' AND owner_id = ? AND status = 'trial' LIMIT 1");
            $st->execute([$e]);
            return (bool) $st->fetchColumn();
        } catch (Throwable) { return false; }
    }

    // ------------------------------------------------------------------ disputes (decisions/0070 §8)

    /** Files a dispute against the listing's owner. The challenger's proof is a document or a note; admins decide. */
    public static function fileDispute(PDO $pdo, array $user, int $e, string $reason): int
    {
        $uid = (int) $user['id'];
        if ($m = self::missing($pdo, $uid)) throw new DomainException(implode(',', $m));
        $h = self::holding($pdo, $e);
        if (!$h) throw new InvalidArgumentException('This listing has no owner to dispute. You can claim it instead.');
        if ((int) $h['user_id'] === $uid) throw new InvalidArgumentException('This is your own listing.');
        if (mb_strlen(trim($reason)) < 10) throw new InvalidArgumentException('Tell us why, in a sentence or two.');
        $st = $pdo->prepare("SELECT id FROM disputes WHERE entity_id = ? AND status = 'open' LIMIT 1");
        $st->execute([$e]);
        if ($st->fetchColumn()) throw new InvalidArgumentException('A dispute about this listing is already open. An admin is looking at it.');
        // the challenger's own claim, held, carries their proof
        $mine = self::mine($pdo, $uid, $e);
        $claim = ($mine && $mine['status'] === 'on_hold') ? $mine : self::hold($pdo, $user, $e, ['note' => 'Dispute: ' . $reason]);
        $pdo->prepare("INSERT INTO disputes (entity_id, filed_by_user_id, claim_id, reason, status, challenge_deadline) VALUES (?, ?, ?, ?, 'open', ?)")
            ->execute([$e, $uid, $claim['id'], mb_substr(trim($reason), 0, 4000), date('Y-m-d H:i:s', time() + 7 * 86400)]);
        $id = (int) $pdo->lastInsertId();
        $l = self::listing($pdo, $e);
        self::tellClaimant($pdo, $h, 'Someone has questioned your listing',
            "Someone believes they own or run {$l['name']}. Nothing changes on your listing for now. If you're the owner, answer within 7 days from your business dashboard"
            . ($h['status'] === 'verified' ? '' : ', and finish the last step of your claim if you haven\'t') . '. An admin decides.');
        self::tellAdmins($pdo, 'Dispute filed: ' . $l['name'], self::who($pdo, $uid) . " disputes the owner of {$l['name']}. Admin → Claims.");
        return $id;
    }

    public static function openDispute(PDO $pdo, int $e): ?array
    {
        try {
            $st = $pdo->prepare("SELECT * FROM disputes WHERE entity_id = ? AND status = 'open' ORDER BY id DESC LIMIT 1");
            $st->execute([$e]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return $r ?: null;
        } catch (Throwable) { return null; }
    }

    /** Owner edits are frozen only once an admin accepts the case as worth a look (not on filing). */
    public static function frozen(PDO $pdo, int $e): bool
    {
        $d = self::openDispute($pdo, $e);
        return $d !== null && !empty($d['accepted_at']);
    }

    public static function answerDispute(PDO $pdo, int $uid, int $disputeId, string $answer): void
    {
        $st = $pdo->prepare("SELECT d.*, e.owner_user_id FROM disputes d JOIN entities e ON e.id = d.entity_id WHERE d.id = ? AND d.status = 'open'");
        $st->execute([$disputeId]);
        $d = $st->fetch(PDO::FETCH_ASSOC);
        if (!$d || (int) $d['owner_user_id'] !== $uid) throw new InvalidArgumentException('Dispute not found.');
        $pdo->prepare('UPDATE disputes SET owner_answer = ?, answered_at = NOW() WHERE id = ?')->execute([mb_substr(trim($answer), 0, 4000), $disputeId]);
        self::tellAdmins($pdo, 'Owner answered a dispute', 'The owner answered dispute #' . $disputeId . '. Admin → Claims.');
    }

    /** Admin: accept (freeze edits while looking), keep the owner, transfer to the challenger, or return to unclaimed. */
    public static function decideDispute(PDO $pdo, int $disputeId, int $adminId, string $what, string $note = ''): void
    {
        $st = $pdo->prepare("SELECT * FROM disputes WHERE id = ? AND status = 'open'");
        $st->execute([$disputeId]);
        $d = $st->fetch(PDO::FETCH_ASSOC);
        if (!$d) throw new InvalidArgumentException('This dispute is already closed.');
        $e = (int) $d['entity_id'];
        if ($what === 'accept') {
            $pdo->prepare('UPDATE disputes SET accepted_at = NOW(), admin_note = CONCAT_WS(\'\n\', admin_note, ?) WHERE id = ?')->execute([$note ?: null, $disputeId]);
            return;
        }
        if (!in_array($what, ['kept', 'transferred', 'returned'], true)) throw new InvalidArgumentException('Pick a decision.');
        $h = self::holding($pdo, $e);
        $ch = $d['claim_id'] ? self::get($pdo, (int) $d['claim_id']) : null;
        Database::transaction(function (PDO $pdo) use ($what, $h, $ch, $e, $adminId, $note, $disputeId) {
            if ($what !== 'kept' && $h) self::release($pdo, $h, 'declined', $adminId, 'Dispute #' . $disputeId . ': ' . $what);
            if ($what === 'transferred' && $ch) {
                $l = self::listing($pdo, $e);
                $pdo->prepare("UPDATE listing_claims SET status = 'withdrawn', decided_by = ?, decided_at = NOW() WHERE id = ?")->execute([$adminId, $ch['id']]);
                $id = self::open($pdo, $e, (int) $ch['user_id'], null, (string) $ch['role_note'], (string) $ch['claimant_phone'], (string) ($l['phone'] ?? ''));
                $pdo->prepare("UPDATE listing_claims SET doc_path = ?, doc_name = ? WHERE id = ?")->execute([$ch['doc_path'], $ch['doc_name'], $id]);
            } elseif ($ch && $ch['status'] === 'on_hold') {
                $pdo->prepare("UPDATE listing_claims SET status = 'declined', decided_by = ?, decided_at = NOW() WHERE id = ?")->execute([$adminId, $ch['id']]);
            }
            $pdo->prepare('UPDATE disputes SET status = ?, decided_by = ?, resolved_at = NOW(), admin_note = CONCAT_WS(\'\n\', admin_note, ?) WHERE id = ?')
                ->execute([$what, $adminId, $note ?: null, $disputeId]);
        });
        if ($what === 'transferred' && $ch) {
            $new = self::holding($pdo, $e);
            if ($new) self::verify($pdo, (int) $new['id'], $adminId, 'admin', 'Transferred after dispute #' . $disputeId . '.');
        }
        self::purgeDocuments($pdo);
        $msg = ['kept' => 'The listing stays with its current owner.', 'transferred' => 'The listing was transferred to the person who filed the dispute.', 'returned' => 'The listing returned to unclaimed; anyone can claim it again.'][$what];
        if ($h) self::tellClaimant($pdo, $h, 'Dispute decided', $msg . ($note !== '' ? "\n\n" . $note : ''));
        if ($ch) self::tellClaimant($pdo, $ch, 'Dispute decided', $msg . ($note !== '' ? "\n\n" . $note : ''));
    }

    // ------------------------------------------------------------------ the admin queue

    /** Everything waiting, overdue first. */
    public static function queue(PDO $pdo): array
    {
        $rows = $pdo->query(
            "SELECT c.*, e.name AS listing, e.status AS entity_status, u.email, u.display_name,
                    (SELECT COUNT(*) FROM listing_claims c2 WHERE c2.group_id = c.group_id AND c.group_id IS NOT NULL) AS group_n
               FROM listing_claims c JOIN entities e ON e.id = c.entity_id JOIN users u ON u.id = c.user_id
              WHERE c.status IN ('managed','on_hold')
              ORDER BY (c.due_at IS NOT NULL AND c.due_at < NOW()) DESC, c.status = 'on_hold' DESC, c.due_at IS NULL, c.due_at, c.id"
        )->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) {
            $r['details'] = self::detailsOf($r);
            $r['contact_log'] = json_decode((string) $r['contact_log'], true) ?: [];
            $r['overdue'] = $r['due_at'] !== null && strtotime((string) $r['due_at']) < time() && $r['status'] === 'managed';
        }
        return $rows;
    }

    public static function disputesOpen(PDO $pdo): array
    {
        try {
            return $pdo->query("SELECT d.*, e.name AS listing, u.email, u.display_name FROM disputes d JOIN entities e ON e.id = d.entity_id LEFT JOIN users u ON u.id = d.filed_by_user_id
                                 WHERE d.status = 'open' ORDER BY d.id")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return []; }
    }

    public static function changesWaiting(PDO $pdo): array
    {
        return $pdo->query("SELECT ch.*, e.name AS listing FROM claim_changes ch JOIN entities e ON e.id = ch.entity_id WHERE ch.status = 'waiting' ORDER BY ch.id")->fetchAll(PDO::FETCH_ASSOC);
    }

    /** For the dashboard and menu: ['claims' => waiting, 'overdue' => past 48 h, 'held' => on hold, 'changes' => fields, 'disputes' => open]. */
    public static function counts(PDO $pdo): array
    {
        if (!self::ready($pdo)) return ['claims' => 0, 'overdue' => 0, 'held' => 0, 'changes' => 0, 'disputes' => 0];
        $one = fn (string $sql) => (int) $pdo->query($sql)->fetchColumn();
        return [
            'claims' => $one("SELECT COUNT(*) FROM listing_claims WHERE status = 'managed'"),
            'overdue' => $one("SELECT COUNT(*) FROM listing_claims WHERE status = 'managed' AND due_at IS NOT NULL AND due_at < NOW()"),
            'held' => $one("SELECT COUNT(*) FROM listing_claims WHERE status = 'on_hold'"),
            'changes' => $one("SELECT COUNT(*) FROM claim_changes WHERE status = 'waiting'"),
            'disputes' => (function () use ($one) { try { return $one("SELECT COUNT(*) FROM disputes WHERE status = 'open'"); } catch (Throwable) { return 0; } })(),
        ];
    }

    private static function docType(string $path): string
    {
        $e = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        return (string) (array_search($e, self::DOC_TYPES, true) ?: 'application/octet-stream');
    }

    /** Streams a claim's document to an admin (the only way it's ever read). */
    public static function streamDocument(PDO $pdo, int $claimId): void
    {
        $c = self::get($pdo, $claimId);
        $path = $c && preg_match('#^(\d{4}/\d{2}|members/[a-f0-9]{16})/[a-f0-9]{24}\.[a-z]{3,4}$#', (string) $c['doc_path']) ? self::storage() . '/' . $c['doc_path'] : '';
        if ($path !== '') { require_once __DIR__ . '/Store.php'; Store::redirect($path, 'claim-' . $claimId . '.' . pathinfo($path, PATHINFO_EXTENSION), self::docType($path), true); }   // in S3 (decisions/0123)
        if ($path === '' || !is_file($path) || !str_starts_with(realpath($path) ?: '', realpath(self::storage()) ?: '//')) { http_response_code(404); exit('Not found.'); }
        $type = (new finfo(FILEINFO_MIME_TYPE))->file($path) ?: 'application/octet-stream';
        header('Content-Type: ' . $type);
        header('Content-Disposition: inline; filename="claim-' . $claimId . '.' . pathinfo($path, PATHINFO_EXTENSION) . '"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        readfile($path);
        exit;
    }

    /**
     * Documents are for verification only (Jason, 2026-10-09): deleted the moment their claim is decided (verified,
     * declined, withdrawn, or the dispute they support is settled). Nothing is kept. Called after every decision, and
     * whenever the queue opens as a backstop.
     */
    public static function purgeDocuments(PDO $pdo): int
    {
        $st = $pdo->query("SELECT id, doc_path FROM listing_claims WHERE doc_path <> '' AND status NOT IN ('managed','on_hold')");
        $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            require_once __DIR__ . '/Store.php';
            if (!str_contains((string) $r['doc_path'], '..')) Store::remove(self::storage() . '/' . $r['doc_path']);
            $pdo->prepare("UPDATE listing_claims SET doc_path = '', doc_name = CONCAT(doc_name, ' (deleted)') WHERE id = ?")->execute([$r['id']]);
            $n++;
        }
        return $n;
    }

    // ------------------------------------------------------------------ helpers

    /**
     * Where claim documents live: outside the web root and outside the synced site folders, next to the .env
     * (/home4/degraff1/traversence-private/claims on the server), so they never reach OneDrive or GitHub.
     * CLAIM_STORAGE overrides it.
     */
    /**
     * The document folder, locked down (Jason, 2026-10-09: "keep them local, but lock down the doc folder"):
     *  - on the server only, outside the web root and outside the synced website/ and app/ folders;
     *  - folders 0700 and files 0600, so only the site's own account can open them;
     *  - a deny-all .htaccess and no index, in case the folder is ever moved under a web root.
     * The only way to read a document is Admin → Claims (streamDocument), for admins.
     */
    private static function lockedDir(string $sub = ''): string
    {
        $root = self::storage();
        $old = umask(0077);
        try {
            if (!is_dir($root) && !@mkdir($root, 0700, true)) throw new RuntimeException('Could not store the file.');
            @chmod($root, 0700);
            if (!is_file("$root/.htaccess")) @file_put_contents("$root/.htaccess", "# Claim documents: never served (decisions/0070).\nRequire all denied\nOptions -Indexes\n");
            $dir = $sub === '' ? $root : "$root/$sub";
            if (!is_dir($dir) && !@mkdir($dir, 0700, true)) throw new RuntimeException('Could not store the file.');
            @chmod($dir, 0700);
            return $dir;
        } finally {
            umask($old);
        }
    }

    private static function storage(): string
    {
        return rtrim((string) (getenv('CLAIM_STORAGE') ?: dirname(__DIR__, 4) . '/traversence-private/claims'), '/');
    }

    private static function ownClaim(PDO $pdo, int $uid, int $claimId, bool $heldToo = false): array
    {
        $c = self::get($pdo, $claimId);
        $ok = $heldToo ? ['managed', 'on_hold'] : ['managed', 'verified'];
        if (!$c || (int) $c['user_id'] !== $uid || !in_array($c['status'], $ok, true)) throw new InvalidArgumentException('Claim not found.');
        return $c;
    }

    public static function detailsOf(array $c): array
    {
        return is_array($c['details'] ?? null) ? $c['details'] : (json_decode((string) ($c['details'] ?? ''), true) ?: []);
    }

    private static function setDetail(PDO $pdo, int $id, string $k, mixed $v): void
    {
        $c = self::get($pdo, $id);
        $d = self::detailsOf($c ?: []);
        $d[$k] = $v;
        $pdo->prepare('UPDATE listing_claims SET details = ? WHERE id = ?')->execute([json_encode($d, JSON_UNESCAPED_UNICODE), $id]);
    }

    private static function who(PDO $pdo, int $uid): string
    {
        $st = $pdo->prepare('SELECT display_name, email FROM users WHERE id = ?');
        $st->execute([$uid]);
        $u = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        return trim((string) ($u['display_name'] ?? '')) ?: (string) ($u['email'] ?? ('member ' . $uid));
    }

    private static function tellClaimant(PDO $pdo, array $c, string $subject, string $body): void
    {
        $st = $pdo->prepare('SELECT email FROM users WHERE id = ?');
        $st->execute([$c['user_id']]);
        $to = (string) $st->fetchColumn();
        if ($to === '') return;
        try { Mailer::send($to, $subject, $body . "\n\n" . rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/listing/businessportal.php'); }
        catch (Throwable $t) { error_log('claims mail: ' . $t->getMessage()); }
    }

    /** Admins are told by email, best effort; the dashboard and Admin → Claims show the same things. */
    private static function tellAdmins(PDO $pdo, string $subject, string $body): void
    {
        try {
            $to = $pdo->query("SELECT u.email FROM users u WHERE u.is_admin = 1 AND u.is_suspended = 0
                                UNION SELECT u.email FROM " . Database::t('admin_access') . " a JOIN users u ON u.id = a.user_id WHERE a.tier = 'super_admin'")->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable) { $to = []; }
        foreach (array_unique($to) as $email) {
            try { Mailer::send((string) $email, '[Traversence] ' . $subject, $body . "\n\n" . rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/admin/claims.php'); }
            catch (Throwable $t) { error_log('claims admin mail: ' . $t->getMessage()); }
        }
    }
}
