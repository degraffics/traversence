<?php
// app/ui/theme-tokens.php — the design tokens, one copy for every page (design/css-theme-brand.md §3–4, Release 1;
// brand.md §4's note of 2026-11-18, §7, §8). Drawn once in the page's <head> by tv_page_start (page-shell.php); every
// stylesheet and shared part reads these, never its own copies of the colours.
//
// Values are brand.md's own hex values. Where brand.md has no value, the token is mixed from brand values, never a new
// colour: the lines (Deep Umber into the vellum) and metadata text. Muted Taupe #7A6A52 is 4.11:1 on the vellum, under
// §8's 4.5:1 for text, so metadata TEXT is taupe with 35% Warm Near-Black mixed in (6.2:1 on the vellum, 4.73:1 on the
// card's darker end #D8C79D); taupe itself stays for icons, rules and large text.
// The fonts are served from our own server (website/fonts/, SIL Open Font License), so the card pages' content policy
// (font-src 'self') allows them and no visitor is sent to a font company.
declare(strict_types=1);

function tv_theme_tokens(): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    $v = (int) @filemtime(__DIR__ . '/../../website/fonts/inter-400.woff2');
    return '<link rel="preload" href="/fonts/inter-400.woff2?v=' . $v . '" as="font" type="font/woff2" crossorigin>' . "\n" . <<<'CSS'
<style>
  /* the families and weights Jason named (2026-11-18): Inter 400–700 (four hinted files), Merriweather 300/400/700 and 300
     italic, Playfair Display 400/600/700 and 400 italic. A browser fetches only the ones a page uses. */
  @font-face{font-family:"Merriweather";font-style:normal;font-weight:300;font-display:swap;src:url(/fonts/merriweather-300.woff2) format("woff2")}
  @font-face{font-family:"Merriweather";font-style:italic;font-weight:300;font-display:swap;src:url(/fonts/merriweather-300-italic.woff2) format("woff2")}
  @font-face{font-family:"Playfair Display";font-style:normal;font-weight:400;font-display:swap;src:url(/fonts/playfair-400.woff2) format("woff2")}
  @font-face{font-family:"Playfair Display";font-style:italic;font-weight:400;font-display:swap;src:url(/fonts/playfair-400-italic.woff2) format("woff2")}
  @font-face{font-family:"Playfair Display";font-style:normal;font-weight:600;font-display:swap;src:url(/fonts/playfair-600.woff2) format("woff2")}
  @font-face{font-family:"Playfair Display";font-style:normal;font-weight:700;font-display:swap;src:url(/fonts/playfair-700.woff2) format("woff2")}
  @font-face{font-family:"Merriweather";font-style:normal;font-weight:400;font-display:swap;src:url(/fonts/merriweather-400.woff2) format("woff2")}
  @font-face{font-family:"Merriweather";font-style:normal;font-weight:700;font-display:swap;src:url(/fonts/merriweather-700.woff2) format("woff2")}
  /* Inter as four fixed weights with hinting added (ttfautohint, 2026-11-19): the variable file has none, and Windows draws
     unhinted text jagged at small sizes (Jason: "it feels pixelated"). Same family, same weights; inter-var.woff2 stays
     on the server, unused. */
  @font-face{font-family:"Inter";font-style:normal;font-weight:400;font-display:swap;src:url(/fonts/inter-400.woff2) format("woff2")}
  @font-face{font-family:"Inter";font-style:normal;font-weight:500;font-display:swap;src:url(/fonts/inter-500.woff2) format("woff2")}
  @font-face{font-family:"Inter";font-style:normal;font-weight:600;font-display:swap;src:url(/fonts/inter-600.woff2) format("woff2")}
  @font-face{font-family:"Inter";font-style:normal;font-weight:700;font-display:swap;src:url(/fonts/inter-700.woff2) format("woff2")}
  @font-face{font-family:"Inter";font-style:normal;font-weight:800;font-display:swap;src:url(/fonts/inter-800.woff2) format("woff2")}
  :root{
    /* canvas and surfaces (brand.md §4) */
    /* three levels (Jason, 2026-11-19, set A; brand.md §4's note): one warm hue, stepping only in lightness, page → section →
       card; replaces the vellum canvas and the micro-gradient card of design/css-theme-brand.md §3 */
    --tv-canvas:#E4DCC5;          /* the page */
    --tv-sec:#EDE6D5;--tv-sec-edge:#DBD2BA;   /* a section: a group of cards, a panel */
    --tv-card-edge:#E3DBC6;--tv-tag:#EDE6D5;  /* a card's edge; a tag or badge on a card */
    --tv-umber:#3E2B1F;           /* Deep Umber: top bars, the rail, structure */
    --tv-void:#231D17;            /* Slate-Umbra: deep backgrounds, map oceans */
    --tv-card-a:#F6F1E4;--tv-card-b:#F6F1E4;   /* the card (Jason: "i like this card color"), flat */
    --tv-card:linear-gradient(180deg,var(--tv-card-a),var(--tv-card-b));   /* elevated surfaces: the micro-gradient */
    --tv-field:#F6F1E4;--tv-field-edge:#8D7E68;   /* fields share the card colour (Jason, 2026-11-19); their edge is 3.5:1 on it, so a box is found */   /* text boxes and dropdowns: a lighter vellum, so a field reads apart from the page (Jason, 2026-11-19) */
    /* type colours */
    --tv-ink:#2A1D14;             /* Warm Near-Black: headings and body text */
    --tv-taupe:#7A6A52;           /* Muted Taupe: icons, rules, large metadata */
    --tv-meta:color-mix(in srgb,#2A1D14 35%,#7A6A52);   /* metadata text, 4.5:1 on every surface (see the note above) */
    /* lines, mixed from Deep Umber into the vellum (brand.md names none) */
    --tv-line:color-mix(in srgb,#3E2B1F 20%,#E4DCC5);          /* hairlines and dividers */
    --tv-line-strong:color-mix(in srgb,#3E2B1F 58%,#E4DCC5);   /* input and control edges, 3.35:1 on the vellum */
    /* on the umber rail and bars */
    --tv-on-umber:#EFE3C8;
    --tv-on-umber-meta:color-mix(in srgb,#EFE3C8 70%,#7A6A52); /* 7.4:1 on Deep Umber */
    --tv-umber-line:color-mix(in srgb,#EFE3C8 16%,#3E2B1F);   /* dividers and hovers on the umber */
    --tv-link:#92400E;            /* names and links: brand brown, CLAUDE.md's card anatomy (decisions/0058 §11), 5.6:1 */
    /* accents and tracks (brand.md §4) */
    --tv-copper:#C85A17;          /* primary actions, Traveler ("Let's Explore") */
    --tv-sage:#92BEA5;            /* active states, Resident ("Get Local") */
    --tv-amethyst:#7D6B8D;        /* Community ("Connect") */
    --tv-river:#3B5A6B;--tv-moss:#6B7F62;--tv-crimson:#8C3A23;   /* cartographic: water, reserves, sites */
    --tv-route:#B6F22E;--tv-route-casing:#3E2B1F;   /* routes and trails only (activity): Electric Lime over a Deep Umber casing
                                                       (Jason, 2026-11-19); lime alone is 1.05:1 on the vellum (10:1 against its casing), so never text */
    /* status (brand.md §4's note, 2026-11-18) */
    --tv-fail:#a62b2b;            /* System Red: a halting or core failure, or an open trip only */
    --tv-hold:#8f5600;            /* Grounded Amber: routine timeouts, waits, holds ("Held") */
    --tv-fail-bg:color-mix(in srgb,#a62b2b 10%,#EFE3C8);
    --tv-hold-bg:color-mix(in srgb,#8f5600 12%,#EFE3C8);
    /* type (brand.md §7) */
    --tv-font-head:"Merriweather","Playfair Display",ui-serif,Georgia,serif;    /* editorial and brand headings */
    --tv-font-display:"Playfair Display","Merriweather",ui-serif,Georgia,serif;   /* display titles (heroes, landings) */
    --tv-font-ui:"Inter",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
    /* motion (brand.md §8) */
    --tv-ease:150ms ease-out;
    /* geometry: soft corners, warm shadows, and the space between groups (never inside list rows) */
    --tv-r-sm:.5rem;--tv-r:.75rem;--tv-r-lg:1rem;
    --tv-shadow:0 1px 2px rgba(62,43,31,.08),0 6px 16px -10px rgba(62,43,31,.3);
    --tv-shadow-lg:0 22px 44px -22px rgba(35,29,23,.5);
    --tv-gap:1.5rem;
    /* focus rings in the active tokens (brand.md §8): copper on light surfaces (3.3:1), sage on the umber */
    --tv-focus:#C85A17;--tv-focus-dark:#92BEA5;
  }
  html,body{background-color:var(--tv-canvas)}
  body,body.font-sans{font-family:var(--tv-font-ui)}   /* the UI face; headings move to the serif token page by page (Release 3) */
  :focus-visible{outline:2px solid var(--tv-focus);outline-offset:2px}
  :where(input:not([type=checkbox],[type=radio],[type=range],[type=color],[type=submit],[type=button],[type=reset],[type=file],[type=image]),select,textarea){background-color:var(--tv-field);border-color:var(--tv-field-edge)}
  @media (prefers-reduced-motion:reduce){:root{--tv-ease:0s linear}}
</style>
CSS;
}
