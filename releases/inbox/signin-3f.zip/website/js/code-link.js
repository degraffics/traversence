// js/code-link.js — the 6-digit code box on the sign-in code steps (/admin/login.php, /two-step.php).
// "Sign in with this code" from a code email (Jason, 2026-11-11): the page opens at #code=123456 and the code box fills
// in. The code travels after # (never sent to the server or kept in its logs) and the address is cleaned at once, so it
// isn't left in history. Where the box isn't on the page (another browser, or a sign-in that ended), it says so and how
// to go on: a code works only where the sign-in started.
// A box marked data-tv-code (3f A11, Jason 2026-11-22: the system does it, principle 1): anything but digits is dropped
// as it's typed or pasted ("123 456", "123-456"), and the 6th digit sends the form, as its own button would, with that
// button's spinner. A code filled in from the email's link sends itself the same way.
(function () {
  function box() { return document.querySelector('input[autocomplete="one-time-code"]'); }
  function btnOf(i) { return i.form && i.form.querySelector('button.b, button[type="submit"], button:not([type])'); }
  function send(i) {
    if (!i.form || i.form.dataset.tvSent) return;
    if (!/^\d{6}$/.test(i.value)) return;
    i.form.dataset.tvSent = '1';
    var b = btnOf(i);
    if (b && window.TvAsk) TvAsk.busy(b, true);
    if (i.form.requestSubmit) i.form.requestSubmit(b || undefined); else if (b) b.click(); else i.form.submit();
  }
  function arm(i) {
    if (!i || !i.hasAttribute('data-tv-code') || i.dataset.tvArmed) return;
    i.dataset.tvArmed = '1';
    i.addEventListener('input', function () {
      var d = i.value.replace(/\D+/g, '').slice(0, 6);
      if (d !== i.value) i.value = d;
      if (d.length === 6) send(i);
    });
    if (i.form) i.form.addEventListener('submit', function () { i.value = i.value.replace(/\D+/g, ''); });   // the server strips spaces too
  }
  function go() {
    var i = box(); arm(i);
    var m = /[#&]code=(\d{6})\b/.exec(location.hash || ''); if (!m) return;
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
    if (i) {
      i.value = m[1]; i.focus();
      if (i.hasAttribute('data-tv-code')) { send(i); return; }
      var b = btnOf(i); if (b && window.TvAsk) TvAsk.say('Your code is filled in: tap ' + (b.textContent || 'Sign in').trim() + '.', { anchor: b });
      return;
    }
    var msg = 'That code works only in the browser where you signed in. Sign in here, and we’ll email a new code.';
    if (window.TvAsk) TvAsk.say(msg); else { var p = document.createElement('p'); p.setAttribute('data-tv-status', 'info'); p.textContent = msg; (document.querySelector('form') || document.body).before(p); }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
})();
