<?php
// admin/staff.php — Staff logins (People & roles, decisions/0100). Owners add staff (name, work email first.last@trvgo.com,
// role; the setup link is emailed to them and stays on their row until it's used), change their work email or role,
// reset them (forgotten password, lost mailbox: a new setup link), or end their access. An admin can reset another
// admin's login. Everyone signed in with a staff login sees their own here: change password, the optional
// authenticator app (a fallback for slow email), and its history. Before the first owner login exists (the
// switch-over), an admin signed in as a member can create it.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../app/lib/Qr.php';
require_once __DIR__ . '/../../app/lib/CPanelMail.php';
require_once __DIR__ . '/../../app/lib/EnvSettings.php';

$pdo = Database::connection();
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$ready = StaffLogin::ready($pdo);
$enforced = $ready && StaffLogin::enforced($pdo);
$mine = $ready ? StaffLogin::inSession($pdo) : null;
$owner = $mine && $mine['role'] === 'owner';
$canManage = $owner || ($ready && !$enforced && !empty($me['is_admin']));   // the switch-over: an admin member makes the first owner
$actor = $mine ? (int) $mine['id'] : null;
$self = '/admin/staff.php' . (!empty($_GET['embed']) ? '?embed=1' : '');
$link = null;   // a setup link to show once

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $id = (int) ($_POST['id'] ?? 0);
        $do = (string) ($_POST['do'] ?? '');
        $t = $id ? StaffLogin::get($pdo, $id) : null;
        if ($do === 'reset') {   // owners: anyone; admins: another admin; the switch-over: a login still waiting
            if (!$t || !(StaffLogin::canReset($mine, $t) || (!$enforced && $canManage && $t['status'] === 'setup'))) throw new RuntimeException('Only an owner can reset that login.');
        } elseif (in_array($do, ['add', 'mailbox', 'end', 'role', 'set_email', 'tidy', 'app_off', 'link_member', 'unlink_member'], true) && !$canManage) throw new RuntimeException('Only an owner can do that.');
        elseif (!$enforced && in_array($do, ['end', 'role', 'tidy', 'app_off'], true) && !$owner) throw new RuntimeException('Set up the owner login first, then sign in with it.');
        if (in_array($do, ['password', 'app_key', 'app_add', 'app_remove', 'app_nudge_off'], true) && !$mine) throw new RuntimeException('Sign in with your staff login first.');
        switch ($do) {
            case 'add':
                $role = $enforced ? (string) ($_POST['role'] ?? 'manager') : 'owner';
                $box = null;
                if (!empty($_POST['mailbox']) && CPanelMail::ready()) {   // make first.last@… in cPanel first, so the setup email lands there
                    if (trim((string) ($_POST['name'] ?? '')) === '') throw new RuntimeException('Give the person\'s name.');
                    $addr = StaffLogin::workEmail($pdo, (string) ($_POST['email'] ?? ''));
                    $box = ['email' => $addr, 'pw' => CPanelMail::create($addr), 'webmail' => CPanelMail::webmail($addr)];
                }
                $r = StaffLogin::create($pdo, (string) ($_POST['name'] ?? ''), (string) ($_POST['email'] ?? ''), $role, $actor, (int) $me['id']);
                if ($box) StaffLogin::log($pdo, (int) $r['staff']['id'], 'mailbox', $box['pw'] !== '' ? 'Mailbox made in cPanel' : 'Mailbox already existed', $actor);
                $_SESSION['tv_staff_link_once'] = ['who' => $r['staff']['staff_id'] . ' · ' . $r['staff']['name'], 'url' => $r['setup_url'], 'mailed' => $r['mailed'], 'box' => $box];
                break;
            case 'mailbox':   // a shared mailbox with no staff login (orders@…): made in cPanel; its password is shown once
                if (!$owner) throw new RuntimeException('Only an owner can do that.');
                $local = strtolower(trim((string) ($_POST['local'] ?? '')));
                if (!preg_match('/^[a-z0-9][a-z0-9._-]{0,39}$/', $local)) throw new RuntimeException('Write the part before the @, like orders.');
                $addr = $local . '@' . StaffLogin::workDomain();
                $pw = CPanelMail::create($addr);
                $set = '';
                if (!empty($_POST['as_orders'])) {   // the site's orders email (work orders go from it; vendors' updates come to it)
                    try { EnvSettings::set('ORDERS_FROM_EMAIL', $addr); if (EnvSettings::value('ORDERS_FROM_NAME') === '') EnvSettings::set('ORDERS_FROM_NAME', 'Traversence Orders'); if (EnvSettings::value('ORDERS_REPLY_TO') === '') EnvSettings::set('ORDERS_REPLY_TO', 'support@traversence.com'); $set = 'orders'; }
                    catch (Throwable $x) { $set = 'Set it as the Orders email in Settings yourself (' . $x->getMessage() . ')'; }
                }
                $_SESSION['tv_box_once'] = ['email' => $addr, 'pw' => $pw, 'webmail' => CPanelMail::webmail($addr), 'set' => $set];
                break;
            case 'reset':
                $r = StaffLogin::reset($pdo, $id, $actor);
                $_SESSION['tv_staff_link_once'] = ['who' => $t['staff_id'] . ' · ' . $t['name'], 'url' => $r['url'], 'mailed' => $r['mailed']];
                break;
            case 'set_email':
                if (!$t || $t['status'] === 'ended') throw new RuntimeException('That staff login has ended.');
                if (!$owner && $t['status'] !== 'setup') throw new RuntimeException('Set up the owner login first, then sign in with it.');
                StaffLogin::setEmail($pdo, $id, (string) ($_POST['email'] ?? ''), $actor);
                tv_crawler_flash(['type' => 'ok', 'text' => 'Work email saved. Sign-in codes go there from now on.']);
                break;
            case 'end':
                if ($mine && $id === (int) $mine['id']) throw new RuntimeException('You can\'t end your own staff login here. Ask another owner.');
                StaffLogin::end($pdo, $id, $actor, trim((string) ($_POST['why'] ?? '')));
                $boxNote = '';
                if ($t && $t['email'] && CPanelMail::ready()) {   // their work mailbox stops signing in too (its mail is kept)
                    try { CPanelMail::suspend((string) $t['email']); StaffLogin::log($pdo, $id, 'mailbox', 'Mailbox sign-in suspended in cPanel', $actor); $boxNote = ' Their mailbox can\'t sign in any more; its mail is kept.'; }
                    catch (RuntimeException $x) { $boxNote = ' Their mailbox is still open (' . $x->getMessage() . '): suspend it in cPanel.'; }
                }
                tv_crawler_flash(['type' => 'ok', 'text' => 'Staff access ended. That login is switched off and signed out everywhere; its history stays.' . $boxNote]);
                break;
            case 'link_member':   // an owner links the login to the person's member account; they confirm by email
                if (!$t) throw new RuntimeException('That staff login isn\'t here.');
                $to = StaffLogin::requestMemberLink($pdo, $id, (string) ($_POST['member_email'] ?? ''), $actor);
                tv_crawler_flash(['type' => 'ok', 'text' => 'We\'ve emailed ' . $to . ' to confirm. ' . $t['staff_id'] . ' is linked once they say yes, signed in as that account.']);
                break;
            case 'unlink_member':
                if (!$t || !$t['member_user_id']) throw new RuntimeException('That staff login has no member account linked.');
                StaffLogin::unlinkMember($pdo, (int) $t['member_user_id'], $id);
                tv_crawler_flash(['type' => 'ok', 'text' => 'Member account unlinked from ' . $t['staff_id'] . '.']);
                break;
            case 'role':
                StaffLogin::setRole($pdo, $id, (string) ($_POST['role'] ?? ''), (int) $actor);
                tv_crawler_flash(['type' => 'ok', 'text' => 'Role changed.']);
                break;
            case 'app_off':   // an owner takes the authenticator off someone's login (a lost phone)
                if (!$t) throw new RuntimeException('That staff login isn\'t here.');
                StaffLogin::removeApp($pdo, $id, $actor);
                tv_crawler_flash(['type' => 'ok', 'text' => 'Authenticator app removed from ' . $t['staff_id'] . '. Emailed codes still work.']);
                break;
            case 'password':
                StaffLogin::changePassword($pdo, (int) $mine['id'], (string) ($_POST['current'] ?? ''), (string) ($_POST['password'] ?? ''), (string) ($_POST['password2'] ?? ''));
                tv_crawler_flash(['type' => 'ok', 'text' => 'Password changed.']);
                break;
            case 'app_key':   // show the key to scan (a fresh one if asked)
                $_SESSION['tv_staff_app_open'] = 1;
                if (!empty($_POST['fresh'])) StaffLogin::newPendingSecret((int) $mine['id']);
                header('Location: ' . $self . '#my-app', true, 303); exit;
            case 'app_add':
                StaffLogin::addApp($pdo, (int) $mine['id'], (string) ($_POST['code'] ?? ''));
                tv_crawler_flash(['type' => 'ok', 'text' => 'Authenticator app added. When email is slow, its code works at sign-in.']);
                break;
            case 'app_remove':
                StaffLogin::removeApp($pdo, (int) $mine['id'], (int) $mine['id']);
                tv_crawler_flash(['type' => 'ok', 'text' => 'Authenticator app removed. Sign-in codes come by email.']);
                break;
            case 'app_nudge_off':   // "Not now" on the add-an-authenticator notice (3f B8): remembered for this staff login; back to the page
                $pdo->prepare('INSERT INTO ' . Database::t('staff_settings') . ' (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)')->execute(['appnudge:' . (int) $mine['id'], date('c')]);
                StaffLogin::log($pdo, (int) $mine['id'], 'app_nudge', 'Chose Not now on the authenticator app notice', (int) $mine['id']);
                $back = (string) ($_POST['back'] ?? '');
                header('Location: ' . (preg_match('#^/admin(?:/[^\s\\]*)?$#', $back) && !str_starts_with($back, '//') ? $back : $self), true, 303); exit;
            case 'tidy':   // after the switch-over: member accounts lose their old admin roles (they no longer open admin anyway)
                $n = $pdo->exec("UPDATE users SET is_admin = 0 WHERE is_admin = 1 AND email NOT LIKE '%@staff.traversence.invalid'");
                $pdo->exec("DELETE a FROM " . Database::t('admin_access') . " a JOIN users u ON u.id = a.user_id WHERE u.email NOT LIKE '%@staff.traversence.invalid'");
                tv_crawler_flash(['type' => 'ok', 'text' => 'Done: admin roles removed from ' . (int) $n . ' member account' . ((int) $n === 1 ? '' : 's') . '.']);
                break;
        }
        if ($do === 'app_add' || $do === 'app_remove') unset($_SESSION['tv_staff_app_open']);
    } catch (RuntimeException $ex) { tv_crawler_flash(['type' => 'error', 'text' => $ex->getMessage()]); }
    header('Location: ' . $self, true, 303); exit;
}

tv_admin_start('people', 'Staff logins', 'The Traversence team signs in to the admin side with a staff login: a staff ID, a password and a code we email to their work email. Separate from anyone\'s member account, so ending someone\'s staff access never touches the account they use as a member.');
if (!$ready) { echo '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2026-12-05_staff_logins.sql</code> in phpMyAdmin first.</p></div>'; tv_admin_end(); return; }
$flash = tv_crawler_flash();
$once = $_SESSION['tv_staff_link_once'] ?? null; unset($_SESSION['tv_staff_link_once']);
$boxOnce = $_SESSION['tv_box_once'] ?? null; unset($_SESSION['tv_box_once']);
$appOpen = !empty($_SESSION['tv_staff_app_open']);
$dom = StaffLogin::workDomain();
$staff = StaffLogin::all($pdo);
$when = fn ($t) => $t ? date('M j, Y g:i a', strtotime((string) $t)) : '';
$hidden = fn (string $do, int $id = 0) => '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="do" value="' . $do . '"><input type="hidden" name="id" value="' . $id . '">';
$memberAdmins = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = 1 AND email NOT LIKE '%@staff.traversence.invalid'")->fetchColumn();
?>
<style>
  .st-row{display:flex;justify-content:space-between;gap:.6rem;align-items:flex-start;flex-wrap:wrap;padding:.6rem 0;border-top:1px solid #EADFC4}.st-row:first-child{border-top:0}
  .st-row .who{min-width:0;flex:1 1 16rem}.st-row small{display:block;color:#8A7355;font-size:.8rem}
  .st-acts{display:flex;gap:.3rem;flex-wrap:wrap;align-items:center}
  .st-link{background:#FFFBF2;border:1px dashed #B8863B;border-radius:.6rem;padding:.7rem;margin:.5rem 0;overflow-wrap:anywhere}
  .st-link code{font-size:.85rem}
  .st-wait{display:flex;flex-wrap:wrap;align-items:center;gap:.35rem;margin-top:.35rem}.st-wait small{width:100%}.st-wait a.hb-b{text-decoration:none}
  .st-exp{color:#991B1B}
  .st-em{flex:1 1 100%;font-size:.82rem}.st-em summary{cursor:pointer;color:#92400E;font-weight:600}
  .st-app{display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-start;margin-top:.4rem}.st-app .qr{width:10rem;height:10rem;background:#fff;padding:.35rem;border-radius:.5rem}.st-app .qr svg{width:100%;height:100%}
  .st-app code{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.3rem;padding:.1rem .3rem;font-size:.82rem;word-break:break-all}
  .st-f{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.4rem}.st-f .hb-in{flex:1 1 12rem;width:auto}
</style>
<?php if ($flash): ?><p class="hb-card tv-bleed" role="status" data-tv-flash="<?= $e($flash['type'] ?? '') ?>" style="background:<?= ($flash['type'] ?? '') === 'error' ? '#FEE2E2' : '#DCFCE7' ?>"><?= $e($flash['text'] ?? '') ?></p><?php endif; ?>

<?php if ($once): ?>
<div class="hb-card hot tv-bleed">
  <b>Setup link for <?= $e($once['who']) ?></b>
  <p class="hb-intro"><?= !empty($once['mailed']) ? 'Emailed to <b>' . $e($once['mailed']) . '</b>.' : '<b>It couldn\'t be emailed</b>: copy it and give it to them yourself (in person, or a message only they read).' ?> It works once, for <?= StaffLogin::SETUP_HOURS ?> hours: they choose a password and confirm their work email. Until it's used it stays on their row below.</p>
  <?php if (!empty($once['box'])): $bx = $once['box']; ?>
  <p class="hb-intro"><b>Mailbox <?= $e($bx['email']) ?></b> <?= $bx['pw'] !== '' ? 'made in cPanel.' : 'already existed: its password wasn\'t changed.' ?> They read the setup email in webmail (<a class="hb-go" href="<?= $e($bx['webmail']) ?>" target="_blank" rel="noopener">webmail</a>) and should change the mailbox password there.</p>
  <?php if ($bx['pw'] !== ''): ?><details style="font-size:.85rem;margin:.2rem 0 .4rem"><summary style="cursor:pointer;color:#92400E;font-weight:600">Show the mailbox password (shown once)</summary><div class="st-link"><code id="st-pw"><?= $e($bx['pw']) ?></code></div>
    <button type="button" class="hb-b" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('st-pw').textContent).then(function(){TvAsk.say('Copied')})">Copy the password</button></details><?php endif; ?>
  <?php endif; ?>
  <div class="st-link"><code id="st-url"><?= $e($once['url']) ?></code></div>
  <button type="button" class="hb-b" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('st-url').textContent).then(function(){TvAsk.say('Copied')})">Copy the link</button>
</div>
<?php endif; ?>

<?php if (!$enforced): ?>
<div class="hb-card hot tv-bleed">
  <b>Staff logins aren't switched on yet.</b>
  <p class="hb-intro">Right now admins open the admin side with their member account and an emailed code. Create the first <b>owner</b> staff login (yours), set it up from its link (emailed to your work email), and sign in with it at <b>/admin/login.php</b>. From then on only staff logins open the admin side; member accounts don't.</p>
  <?php if ($canManage && !array_filter($staff, fn ($s) => $s['role'] === 'owner' && $s['status'] !== 'ended')): ?>
  <form method="post" class="st-f"><?= $hidden('add') ?><input class="hb-in" name="name" placeholder="Your name" required maxlength="100"><input class="hb-in" type="email" name="email" placeholder="first.last@<?= $e($dom) ?>" required maxlength="190"><button class="hb-b go" data-confirm="Create the owner staff login? You'll get its setup link." data-yes="Create it">Create the owner login</button></form>
  <?php elseif ($staff): ?><p class="hb-intro">The owner login is made: open its setup link, then sign in at <a class="hb-go" href="/admin/login.php">/admin/login.php</a>. Its link stays here until it's used: <b>Open setup link</b> or <b>Copy link</b> beside it, below. Expired? <b>New setup link</b>.</p><?php endif; ?>
</div>
<?php endif; ?>

<h2 class="hb-h">The team</h2>
<div class="hb-card tv-bleed">
  <?php if (!$staff): ?><p class="text-sm">No staff logins yet.</p><?php endif; ?>
  <?php foreach ($staff as $s): $isMe = $mine && (int) $mine['id'] === (int) $s['id']; ?>
  <div class="st-row">
    <div class="who"><b><?= $e($s['staff_id']) ?></b> · <?= $e($s['name']) ?> <span class="hb-pill<?= $s['status'] === 'active' ? ' ok' : ($s['status'] === 'ended' ? ' red' : '') ?>"><?= $e(['setup' => 'Waiting for setup', 'active' => 'Active', 'ended' => 'Ended'][$s['status']] ?? $s['status']) ?></span><?= $isMe ? ' <span class="hb-pill">You</span>' : '' ?>
      <small><?= $e(StaffLogin::ROLES[$s['role']] ?? $s['role']) ?><?= $s['last_sign_in_at'] ? ' · last signed in ' . $e($when($s['last_sign_in_at'])) : '' ?><?= $s['ended_at'] ? ' · ended ' . $e($when($s['ended_at'])) : '' ?></small>
      <small><?= $s['member_user_id'] ? 'Linked member account: ' . $e($s['member_name'] ?: $s['member_email']) : 'No member account linked' ?></small>
      <small><?= $s['email'] ? 'Work email: ' . $e($s['email']) : '<span class="st-exp">No work email yet</span>' ?><?= StaffLogin::hasApp($s) ? ' · authenticator app added' : '' ?></small>
      <?php if ($canManage && $s['status'] === 'setup'): $wl = StaffLogin::setupUrl($pdo, (int) $s['id']); ?>
      <?php if ($wl): ?>
      <div class="st-wait"><small>Setup link, works until <?= $e($when($wl['until'])) ?>:</small>
        <a class="hb-b go" href="<?= $e($wl['url']) ?>" target="_blank" rel="noopener noreferrer">Open setup link</a>
        <button type="button" class="hb-b" data-copy="<?= $e($wl['url']) ?>" onclick="var u=this.getAttribute('data-copy'),b=this;navigator.clipboard&&navigator.clipboard.writeText(u).then(function(){TvAsk.say('Copied',{anchor:b})})">Copy link</button></div>
      <?php else: ?>
      <small class="st-exp"><?= $s['setup_until'] && strtotime((string) $s['setup_until']) > time() ? 'Its setup link was made before links were kept here.' : 'Its setup link has expired (links last 72 hours).' ?> Make a new one with <b>New setup link</b>.</small>
      <?php endif; endif; ?>
    </div>
    <?php $canReset = StaffLogin::canReset($mine, $s) || (!$enforced && $canManage && $s['status'] === 'setup'); $editEmail = $s['status'] !== 'ended' && ($owner || (!$enforced && $canManage && $s['status'] === 'setup')); ?>
    <?php if ($s['status'] !== 'ended' && ($canReset || $editEmail || $owner)): ?>
    <div class="st-acts">
      <?php if ($owner): ?><form method="post"><?= $hidden('role', (int) $s['id']) ?><select class="hb-in" name="role" onchange="this.form.submit()" aria-label="Role" style="width:auto;padding:.3rem .5rem;font-size:.82rem"><?php foreach (StaffLogin::ROLES as $k => $lab): if ($k === 'admin' && $s['role'] !== 'admin') continue; ?><option value="<?= $k ?>"<?= $k === $s['role'] ? ' selected' : '' ?> title="<?= $e($lab) ?>"><?= $e(StaffLogin::roleName($k)) ?></option><?php endforeach; ?></select></form><?php endif; ?>
      <?php if ($canReset): ?><form method="post"><?= $hidden('reset', (int) $s['id']) ?><button class="hb-b<?= $s['status'] === 'setup' ? ' go' : '' ?>" data-confirm="<?= $s['status'] === 'setup' ? 'Make a new setup link for ' . $e($s['staff_id']) . '? Any earlier link stops working.' : 'Reset ' . $e($s['staff_id']) . '? Their password and authenticator stop working and they\'re signed out; a new setup link is emailed to their work email.' ?>" data-yes="<?= $s['status'] === 'setup' ? 'New link' : 'Reset' ?>"><?= $s['status'] === 'setup' ? 'New setup link' : 'Reset' ?></button></form><?php endif; ?>
      <?php if ($owner && StaffLogin::hasApp($s) && !$isMe): ?><form method="post"><?= $hidden('app_off', (int) $s['id']) ?><button class="hb-b" data-confirm="Take the authenticator app off <?= $e($s['staff_id']) ?>? Emailed codes still work." data-yes="Remove it">Remove app</button></form><?php endif; ?>
      <?php if ($owner && !$isMe): ?><form method="post"><?= $hidden('end', (int) $s['id']) ?><input type="hidden" name="why" value=""><button class="hb-b no" data-confirm="End <?= $e($s['staff_id']) ?>'s staff access? The login is switched off and signed out everywhere. Their member account isn't touched." data-yes="End access" data-danger>End access</button></form><?php endif; ?>
    </div>
    <?php if ($canManage && $s['status'] !== 'ended'): ?>
    <details class="st-em"><summary><?= $s['member_user_id'] ? 'Member account' : 'Link a member account' ?></summary>
      <?php if ($s['member_user_id']): ?>
      <form method="post"><?= $hidden('unlink_member', (int) $s['id']) ?><button class="hb-b no" data-confirm="Unlink <?= $e($s['member_name'] ?: $s['member_email']) ?> from <?= $e($s['staff_id']) ?>? Neither account is touched; they just stop switching between them." data-yes="Unlink" data-danger>Unlink</button></form>
      <?php else: ?>
      <form method="post" style="display:flex;gap:.4rem;flex-wrap:wrap"><?= $hidden('link_member', (int) $s['id']) ?><input class="hb-in" type="email" name="member_email" required placeholder="Their member account's email" aria-label="Their member account's email" style="flex:1;min-width:12rem"><button class="hb-b go">Send to confirm</button></form>
      <small>They get an email and confirm signed in as that member. Linked, the staff login switches into that account from its menu.</small>
      <?php endif; ?>
    </details>
    <?php endif; ?>
    <?php if ($editEmail): ?>
    <details class="st-em"><summary><?= $s['email'] ? 'Change work email' : 'Add work email' ?></summary>
      <form method="post" class="st-f"><?= $hidden('set_email', (int) $s['id']) ?><input class="hb-in" type="email" name="email" value="<?= $e($s['email'] ?? '') ?>" placeholder="first.last@<?= $e($dom) ?>" required maxlength="190"><button class="hb-b">Save</button></form>
    </details>
    <?php endif; ?>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<?php if ($owner): ?>
<h2 class="hb-h">Add someone</h2>
<div class="hb-card tv-bleed">
  <form method="post" class="st-f"><?= $hidden('add') ?>
    <input class="hb-in" name="name" placeholder="Their name" required maxlength="100">
    <input class="hb-in" type="email" name="email" placeholder="first.last@<?= $e($dom) ?>" required maxlength="190">
    <select class="hb-in" name="role" style="flex:0 1 auto;max-width:100%;min-width:0"><?php foreach (StaffLogin::ROLES as $k => $lab): if ($k === 'admin') continue; ?><option value="<?= $k ?>"<?= $k === 'manager' ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></select>
    <?php if (CPanelMail::ready()): ?><label style="display:flex;gap:.35rem;align-items:center;font-size:.85rem;flex:1 1 100%"><input type="checkbox" name="mailbox" value="1" checked> Make the mailbox in cPanel too</label><?php endif; ?>
    <button class="hb-b go">Add and get a setup link</button>
  </form>
  <p class="hb-intro">They get the next staff ID, and the setup link is emailed to their work email (first.last@<?= $e($dom) ?>). <?= CPanelMail::ready() ? 'Ending someone\'s access also stops their mailbox signing in (its mail is kept).' : 'Make the mailbox in cPanel first (or add the cPanel API token to .env, and it\'s made from here).' ?></p>
</div>

<h2 class="hb-h">System mailboxes</h2>
<div class="hb-card tv-bleed" id="mailboxes">
  <?php if ($boxOnce): $bx = $boxOnce; $smtpHost = trim((string) (getenv('SMTP_HOST') ?: '')) ?: 'mail.' . $dom; ?>
  <div class="hb-card hot" style="margin:0 0 .6rem">
    <b>Mailbox <?= $e($bx['email']) ?></b> <?= $bx['pw'] !== '' ? 'made in cPanel.' : 'already existed: its password wasn\'t changed.' ?>
    <?= $bx['set'] === 'orders' ? ' It\'s the site\'s <b>Orders email</b> now; replies go to support@traversence.com.' : ($bx['set'] !== '' ? ' ' . $e($bx['set']) . '.' : '') ?>
    It only sends: nobody needs to read it.
    <?php if ($bx['pw'] !== ''): ?>
    <details style="font-size:.85rem;margin:.3rem 0"><summary style="cursor:pointer;color:#92400E;font-weight:600">Show its password (shown once)</summary><div class="st-link"><code id="bx-pw"><?= $e($bx['pw']) ?></code></div>
      <button type="button" class="hb-b" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('bx-pw').textContent).then(function(){TvAsk.say('Copied', {bad: false})})">Copy the password</button></details>
    <?php endif; ?>
    <?php if ($bx['set'] === 'orders'): ?>
    <p class="hb-intro" style="margin:.3rem 0 .2rem">So work orders go <b>from</b> it, add these lines to <code>.env</code> in cPanel → File Manager (its password goes in by hand, never through a web page):</p>
    <div class="st-link"><code style="white-space:pre">ORDERS_SMTP_HOST=<?= $e($smtpHost) ?>

ORDERS_SMTP_PORT=<?= (int) (getenv('SMTP_PORT') ?: 587) ?>

ORDERS_SMTP_USERNAME=<?= $e($bx['email']) ?>

ORDERS_SMTP_PASSWORD=(its password)</code></div>
    <?php endif; ?>
  </div>
  <?php endif; ?>
  <?php if (CPanelMail::ready()): ?>
  <form method="post" class="st-f"><?= $hidden('mailbox') ?>
    <span style="display:flex;align-items:center;gap:.3rem;flex:1 1 16rem"><input class="hb-in" name="local" placeholder="orders" required maxlength="40" pattern="[A-Za-z0-9._-]+" style="flex:1"><b>@<?= $e($dom) ?></b></span>
    <label style="display:flex;gap:.35rem;align-items:center;font-size:.85rem;flex:1 1 100%"><input type="checkbox" name="as_orders" value="1" checked> Use it as the site's Orders email (work orders go from it; replies and vendors' updates go to support@traversence.com)</label>
    <button class="hb-b go">Make the mailbox</button>
  </form>
  <p class="hb-intro">A send-only system address, like orders@<?= $e($dom) ?> or donotreply@<?= $e($dom) ?>: made in cPanel, with no staff login and no admin access. Nobody reads it: replies go to support@traversence.com. Its password is shown once.</p>
  <?php else: ?>
  <p class="hb-intro">Make it in cPanel → Email Accounts (or add the cPanel API token to .env to make it here).</p>
  <?php endif; ?>
</div>

<?php if ($memberAdmins > 0): ?>
<h2 class="hb-h">Old admin roles on member accounts</h2>
<div class="hb-card tv-bleed">
  <p class="text-sm"><?= $memberAdmins ?> member account<?= $memberAdmins === 1 ? ' still has' : 's still have' ?> an admin role from before staff logins. They can't open the admin side any more; removing the role tidies it up.</p>
  <form method="post" style="margin-top:.4rem"><?= $hidden('tidy') ?><button class="hb-b" data-confirm="Remove admin roles from member accounts? Staff logins aren't affected." data-yes="Remove them">Remove them</button></form>
</div>
<?php endif; ?>
<?php endif; ?>

<?php if ($mine): ?>
<h2 class="hb-h">Your staff login (<?= $e($mine['staff_id']) ?>)</h2>
<div class="hb-card tv-bleed">
  <p class="text-sm">Sign-in codes go to <b><?= $e($mine['email'] ?: 'no work email yet: ask an owner to add it') ?></b>. Forgot your password or lost that mailbox? An owner<?= $mine['role'] !== 'owner' ? ' or a manager' : '' ?> resets you and a new setup link is emailed. To link your member account, an owner sends it a confirmation from this page (Link a member account).</p>

  <h3 class="hb-h" style="font-size:.95rem">Change your password</h3>
  <form method="post" class="st-f" autocomplete="off"><?= $hidden('password') ?>
    <input type="text" name="username" value="<?= $e($mine['staff_id']) ?>" autocomplete="username" hidden>
    <input class="hb-in" type="password" name="current" placeholder="Current password" autocomplete="current-password" required>
    <input class="hb-in" id="np1" type="password" name="password" placeholder="New password (12+)" minlength="12" autocomplete="new-password" data-pw-not="<?= $e($mine['staff_id']) ?>" required>
    <input class="hb-in" id="np2" type="password" name="password2" placeholder="The same again" minlength="12" autocomplete="new-password" data-pw-match="#np1" required>
    <button class="hb-b">Change it</button>
  </form>

  <h3 class="hb-h" style="font-size:.95rem" id="my-app">Authenticator app (optional)</h3>
  <?php if (StaffLogin::hasApp($mine)): ?>
  <p class="text-sm"><b>Added.</b> When email is slow or down, the code your app shows works at sign-in instead of the emailed one.</p>
  <form method="post" style="margin-top:.4rem"><?= $hidden('app_remove') ?><button class="hb-b" data-confirm="Remove the authenticator app? Sign-in codes will only come by email." data-yes="Remove it">Remove it</button></form>
  <?php elseif (!$appOpen): ?>
  <p class="text-sm">A fallback for when email is slow or down: Microsoft Authenticator, Google Authenticator or 1Password on your phone shows a code that works at sign-in too.</p>
  <form method="post" style="margin-top:.4rem"><?= $hidden('app_key') ?><button class="hb-b">Add an authenticator app</button></form>
  <?php else: $sec = StaffLogin::pendingSecret((int) $mine['id']); ?>
  <div class="st-app">
    <div class="qr" aria-label="Authenticator setup code"><?= Qr::svg(StaffLogin::otpauthUri((string) $mine['staff_id'], $sec), ['ecc' => 'M', 'dark' => '#000000', 'light' => '#FFFFFF']) ?></div>
    <div style="flex:1 1 14rem">
      <p class="text-sm">In the app, add an account and scan this code. Then type the code it shows.</p>
      <details style="font-size:.85rem"><summary style="cursor:pointer;color:#92400E;font-weight:600">Can't scan? Show the key</summary><p>Type this key into the app: <code><?= $e(trim(chunk_split($sec, 4, ' '))) ?></code><br>It's a secret, like a password: don't share it or put it in a screenshot.</p></details>
      <form method="post" class="st-f"><?= $hidden('app_add') ?><input class="hb-in" name="code" inputmode="numeric" maxlength="7" placeholder="000000" autocomplete="one-time-code" required style="max-width:9rem"><button class="hb-b go">Add it</button></form>
      <form method="post" style="margin-top:.3rem"><?= $hidden('app_key') ?><input type="hidden" name="fresh" value="1"><button class="underline text-[#92400E]" style="background:none;border:0;padding:0;font-size:.82rem;cursor:pointer" data-confirm="Make a new key? The code shown now stops working." data-yes="New key">Someone else saw this? Get a new key</button></form>
    </div>
  </div>
  <?php endif; ?>
  <h3 class="hb-h" style="font-size:.95rem">Recent activity</h3>
  <ul style="font-size:.85rem;margin:.3rem 0 0 1rem;list-style:disc"><?php foreach (StaffLogin::history($pdo, (int) $mine['id'], 12) as $h): ?><li><?= $e($when($h['created_at'])) ?>: <?= $e(str_replace('_', ' ', (string) $h['event'])) ?><?= $h['note'] !== '' ? ', ' . $e($h['note']) : '' ?><?= $h['actor'] ? ' (by ' . $e($h['actor']) . ')' : '' ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>
<?php tv_admin_end();
