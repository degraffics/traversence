<?php
// /admin/login.php — the staff sign-in (decisions/0100): staff ID and password, then the 6-digit code we email to the
// work email (or, if they've added one, the authenticator app's code). Member accounts sign in at /login.php and don't
// open the admin side. ?next= a path on this site.
// The code box (3f A11): "6 digits", when the code stops working as a clock time in the viewer's zone, signs in at the
// 6th digit, takes a pasted code with spaces (js/code-link.js). Can't get the email? (3f B8, decisions/0100's note of
// 2026-11-22): a short form that becomes an owners' Pulse case (app/lib/StaffMailHelp.php).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';

$pdo = Database::connection();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$next = (string) ($_GET['next'] ?? $_POST['next'] ?? '/admin/');
if (!preg_match('#^/(?!/)[^\s\\\\]*$#', $next)) $next = '/admin/';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$err = ''; $msg = ''; $helped = false;

if (!StaffLogin::ready($pdo)) { tv_page_start('Staff sign-in', ['no_crumbs' => true, 'app' => true]); echo '<p class="p-4">Run <code>app/migrations/2026-12-05_staff_logins.sql</code> first.</p>'; tv_page_end(); exit; }
if (StaffLogin::inSession($pdo) && $_SERVER['REQUEST_METHOD'] === 'GET' && empty($_GET['again'])) { header('Location: ' . $next, true, 302); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        switch ((string) ($_POST['do'] ?? '')) {
            case 'password':
                $r = StaffLogin::checkPassword($pdo, (string) ($_POST['staff_id'] ?? ''), (string) ($_POST['password'] ?? ''));
                if ($r['mail_error'] !== '') $err = $r['mail_error'];
                break;
            case 'code':
                StaffLogin::checkCode($pdo, (string) ($_POST['code'] ?? ''));
                header('Location: ' . $next, true, 303); exit;
            case 'resend':
                $msg = 'New code sent to ' . StaffLogin::resendCode($pdo) . '. Use the newest one.';
                break;
            case 'restart':
                unset($_SESSION['tv_staff_step']);
                break;
            case 'help':   // Can't get the email? (tied to this browser's sign-in step; StaffMailHelp checks it and its limits)
                require_once __DIR__ . '/../../app/lib/StaffMailHelp.php';
                $msg = StaffMailHelp::request($pdo, (string) ($_POST['help_name'] ?? ''), (string) ($_POST['help_contact'] ?? ''), (string) ($_POST['tz'] ?? ''));
                $helped = true;
                break;
        }
    } catch (Throwable $ex) { $err = $ex instanceof RuntimeException ? $ex->getMessage() : 'Something went wrong. Try again.'; if (!($ex instanceof RuntimeException)) error_log('staff login: ' . $ex->getMessage()); }
}

$step = $_SESSION['tv_staff_step'] ?? null;
$who = $step ? StaffLogin::get($pdo, (int) $step['id']) : null;
if ($step && (!$who || time() - (int) $step['at'] > 600)) { unset($_SESSION['tv_staff_step']); $who = null; }
$sentTo = $who ? StaffLogin::codeSentTo('signin', (int) $who['id']) : '';
$mailable = $who && filter_var((string) $who['email'], FILTER_VALIDATE_EMAIL);
$app = $who && StaffLogin::hasApp($who);
$until = $who ? StaffLogin::codeUntil('signin', (int) $who['id']) : 0;   // when the emailed code stops working

// the sign-in card alone: no admin menu and none of its counts until you're signed in as staff (Jason, 2026-11-05); signed in
// as yourself, the account bar says why you're here
if (class_exists('Auth') && Auth::currentUser() !== null) $GLOBALS['tv_bar_note'] = 'Staff sign-in needed below';
tv_page_start('Staff sign-in', ['no_crumbs' => true, 'app' => true, 'description' => 'Sign in to the Traversence admin side with your staff login.']);
?>
<style>
  .sl{max-width:24rem;margin:1.5rem auto;background:#F7EFDC;border:1px solid #CBB98D;border-radius:1rem;padding:1.2rem;color:#3E2B1F}
  .sl h1{font:700 1.5rem var(--tv-font-head,Georgia,serif);margin:0 0 .3rem}
  .sl p{font-size:.9rem;line-height:1.5;margin:.35rem 0}
  .sl label{display:block;font-size:.82rem;font-weight:700;margin:.6rem 0 .2rem}
  .sl input{width:100%;font-size:1rem;padding:.55rem .65rem;border:1px solid #CBB98D;border-radius:.6rem;background:#FFFBF2;color:#3E2B1F}
  .sl input.code{font-size:1.5rem;letter-spacing:.3em;text-align:center}
  .sl input.code::placeholder{letter-spacing:normal;font-size:1.05rem}
  .sl-help{margin-top:.8rem;border-top:1px solid #E2D3B0;padding-top:.6rem}
  .sl-help .hd{display:flex;align-items:center;justify-content:space-between;gap:.5rem}
  .sl-help .x{border:0;background:none;font-size:1.4rem;line-height:1;color:#5C4632;cursor:pointer;padding:0 .2rem}
  .sl .b{width:100%;margin-top:.9rem;border:1px solid #92400E;background:var(--tv-btn);color:var(--tv-btn-text);border-radius:.6rem;padding:.6rem;font-weight:700;font-size:.95rem;cursor:pointer}
  .sl .l{background:none;border:0;color:#92400E;text-decoration:underline;cursor:pointer;font-size:.85rem;padding:0}
  .sl .ok{background:#DCFCE7;border-radius:.5rem;padding:.45rem .6rem}.sl .no{background:#FEE2E2;border-radius:.5rem;padding:.45rem .6rem}
  .sl small{display:block;color:#8A7355;font-size:.78rem;margin-top:.6rem}
  @media (max-width:767px){.sl{margin:.6rem 0}}
</style>
<div class="sl tv-bleed">
  <h1>Staff sign-in</h1>
  <?php if ($err): ?><p class="no" role="alert"><?= $e($err) ?></p><?php endif; ?>
  <?php if ($msg): ?><p class="ok" role="status"><?= $e($msg) ?></p><?php endif; ?>
  <?php if (!$who): ?>
    <p>For the Traversence team. Members sign in <a class="underline" href="/login.php">here</a>.</p>
    <form method="post" autocomplete="on">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><input type="hidden" name="do" value="password">
      <label for="sid">Staff ID or work email</label><input id="sid" name="staff_id" placeholder="TRV-0001" autocomplete="username" autocapitalize="off" spellcheck="false" value="<?= $e((string) ($_POST['staff_id'] ?? '') !== '' ? mb_substr((string) $_POST['staff_id'], 0, 120) : (preg_match('/^TRV-\d{4}$/', (string) ($_GET['sid'] ?? '')) ? $_GET['sid'] : '')) ?>" required<?= empty($_GET['sid']) && empty($_POST['staff_id']) ? ' autofocus' : '' ?>>
      <label for="pw">Password</label><input id="pw" name="password" type="password" autocomplete="current-password" required<?= !empty($_GET['sid']) || !empty($_POST['staff_id']) ? ' autofocus' : '' ?>>
      <button class="b">Next</button>
    </form>
    <small>Forgot your password? Ask an owner to reset your staff login: they'll hand you a new setup link. Can't get your work email? Sign in with your staff ID and password, then choose <b>Can't get the email?</b> Stuck? Write to <a class="underline" href="mailto:support@traversence.com">support@traversence.com</a>.</small>
  <?php else: ?>
    <p><b><?= $e($who['staff_id']) ?></b> · <?= $e($who['name']) ?></p>
    <?php if ($sentTo !== ''): ?><p>We emailed a 6-digit code to <b><?= $e($sentTo) ?></b>. It works until <?= $until ? '<time datetime="' . $e(date('c', $until)) . '" data-tv-time data-tv-clock>' . $e(date('g:i A T', $until)) . '</time>' : StaffLogin::CODE_MINUTES . ' minutes after it was sent' ?>.</p><?php endif; ?>
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><input type="hidden" name="do" value="code">
      <label for="code"><?= $sentTo !== '' ? 'The code from the email' : 'The code from your authenticator app' ?></label>
      <input id="code" class="code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="12" placeholder="6 digits" required autofocus data-tv-code>
      <button class="b">Sign in</button>
    </form>
    <?php if ($app && $sentTo !== ''): ?><small>Email slow? The code your authenticator app shows works here too.</small><?php endif; ?>
    <?php if ($mailable): ?><form method="post" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><button class="l" name="do" value="resend">Send a new code</button></form><?php endif; ?>
    <form method="post" style="margin-top:.5rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><button class="l" name="do" value="restart">Not you? Start again</button></form>
    <?php // a lost work email is never a dead end (decisions/0100's note, 2026-11-22): the owners are asked, and call back ?>
    <?php if (!$helped): ?>
    <div class="sl-help">
      <button type="button" class="l" id="sl-help-open" aria-expanded="<?= $err !== '' && ($_POST['do'] ?? '') === 'help' ? 'true' : 'false' ?>" aria-controls="sl-help">Can't get the email?</button>
      <form method="post" id="sl-help"<?= $err !== '' && ($_POST['do'] ?? '') === 'help' ? '' : ' hidden' ?>>
        <div class="hd"><p style="margin:.4rem 0 0"><b>Ask an owner for a new way in</b></p><button type="button" class="x" data-help-x aria-label="Close" title="Close">&times;</button></div>
        <p>If you can't reach <?= $sentTo !== '' ? '<b>' . $e($sentTo) . '</b>' : 'your work email' ?> any more, tell the owners how to reach you. One of them will contact you to check it's you, then change your work email or give you a new setup link.</p>
        <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><input type="hidden" name="do" value="help"><input type="hidden" name="tz" value="">
        <label for="help-name">Your name</label><input id="help-name" name="help_name" autocomplete="name" maxlength="120" required data-spell value="<?= $e(mb_substr((string) ($_POST['help_name'] ?? ''), 0, 120)) ?>">
        <label for="help-contact">A phone, or another email, to reach you</label><input id="help-contact" name="help_contact" autocomplete="tel" maxlength="190" spellcheck="false" required value="<?= $e(mb_substr((string) ($_POST['help_contact'] ?? ''), 0, 190)) ?>">
        <button class="b">Send to the owners</button>
      </form>
    </div>
    <?php endif; ?>
  <?php endif; ?>
</div>
<script src="/js/tv-time.js" defer></script>
<script src="/js/code-link.js" defer></script>
<script<?= function_exists('tv_nonce') ? tv_nonce() : '' ?>>
// Can't get the email?: opens in place; ×, Esc and a click outside close it (a click outside only while it's empty, so
// nothing typed is lost); the device's time zone goes with it (times where they happened)
(function () {
  var o = document.getElementById('sl-help-open'), f = document.getElementById('sl-help'); if (!o || !f) return;
  var tz = f.querySelector('[name=tz]'); try { tz.value = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
  function show(on) { f.hidden = !on; o.setAttribute('aria-expanded', String(on)); if (on) { var n = f.querySelector('#help-name'); if (n) n.focus(); } else o.focus(); }
  o.addEventListener('click', function () { show(f.hidden); });
  f.querySelector('[data-help-x]').addEventListener('click', function () { show(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !f.hidden) show(false); });
  document.addEventListener('click', function (e) {
    if (f.hidden || f.contains(e.target) || o.contains(e.target)) return;
    var typed = Array.prototype.some.call(f.querySelectorAll('input:not([type=hidden])'), function (i) { return i.value.trim() !== ''; });
    if (!typed) show(false);
  });
  f.addEventListener('submit', function () { var b = f.querySelector('button.b'); if (b && window.TvAsk) TvAsk.busy(b, true); });
})();
</script>
<?php tv_page_end();
