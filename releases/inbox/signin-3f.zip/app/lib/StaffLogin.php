<?php
// app/lib/StaffLogin.php — staff logins, separate from member accounts (decisions/0100, rewritten 2026-10-16).
//
// A staff login is a staff ID (TRV-0001), a work email (first.last@trvgo.com, required: STAFF_EMAIL_DOMAIN in .env
// sets the domain), and a password. Signing in takes the password, then a 6-digit code emailed to the work email. An
// authenticator app (TOTP, RFC 6238) is an optional fallback the person adds themselves, for when email is slow or down.
// Forgotten password, lost mailbox: an owner (or, for an admin login, another admin) resets it, which emails a new
// setup link; if no owner can sign in, the server's terminal can (app/scripts/staff-reset.php). No recovery codes.
//
// Each staff login has its own hidden user record (users row, email <staff id>@staff.traversence.invalid, never mailed,
// no usable password) that holds its admin roles, so every admin page's check works as it did. Signing in as staff
// signs this browser in as that record; members' own accounts never open the admin side once an owner exists.
//
// A staff member may link their own member account (from the member side, with a code emailed to their work email)
// so staff notices can reach them there.
declare(strict_types=1);

final class StaffLogin
{
    // The staff roles (the admin side's roles, decisions/0055 §8) and the admin areas each opens (decisions/0078's menu).
    // 'admin' is the role from before the finer roles: everything except managing staff.
    public const ROLES = [
        'owner' => 'Owner (everything, and managing staff)',
        'manager' => 'Manager (listings, search, safety, data, sales, people)',
        'editor' => 'Editor (listings and places, search and guides)',
        'accountant' => 'Accountant (E-Commerce: orders, refunds, payments)',
        'assistant' => 'Executive Assistant (sales and insights)',
        'creator' => 'Content Creator (listings and places, guides)',
        'general' => 'General (sales and support: leads, listings, safety)',
        'admin' => 'Admin (everything but managing staff)',
    ];
    public const AREAS = [
        'owner' => ['*'],
        'admin' => ['*'],
        'manager' => ['admin', 'sales', 'listings', 'search', 'safety', 'data', 'insights', 'people'],
        'editor' => ['admin', 'listings', 'search', 'insights'],
        'accountant' => ['admin', 'ecommerce', 'sales', 'insights'],
        'assistant' => ['admin', 'sales', 'insights'],
        'creator' => ['admin', 'listings', 'search'],
        'general' => ['admin', 'sales', 'listings', 'safety'],
    ];
    public const AREA_NAMES = ['admin' => 'the Admin dashboard', 'sales' => 'Sales', 'ecommerce' => 'E-Commerce', 'listings' => 'Listings & places',
        'search' => 'Search', 'safety' => 'Safety', 'data' => 'Data & crawler', 'insights' => 'Insights', 'people' => 'People & roles', 'settings' => 'Settings'];

    /** The admin area an /admin (or admin API) address belongs to; staff.php is 'self' (everyone's own login). */
    public static function areaFor(string $path): string
    {
        $p = strtolower($path);
        if (in_array($p, ['/admin/staff.php', '/admin/w.php', '/admin/staff-profile.php'], true)) return 'self';   // w.php checks its own workspace
        // the admin's clean addresses (decisions/0109): admin/router.php and admin/api.php check each module and tool themselves
        if (!str_contains($p, '.') && preg_match('#^/admin/(api/[a-z]+/[a-z0-9_-]+|[a-z]+(/[a-z0-9_-]+){0,2})/?$#', $p)) return 'self';
        foreach ([
            'ecommerce' => ['/admin/ecommerce', '/admin/order.php', '/admin/quickbooks', '/admin/short-codes', '/admin/client-order', '/admin/products', '/api/admin/client-order', '/admin/manifest', '/admin/vendors'],
            'settings' => ['/admin/settings', '/admin/logs', '/admin/sitemap'],
            'people' => ['/admin/people', '/admin/api/people.php', '/admin/staff-levels'],
            'sales' => ['/admin/sales', '/admin/api/sales.php', '/admin/api/cards.php'],
            'safety' => ['/admin/safety', '/admin/reports'],
            'insights' => ['/admin/insights'],
            'search' => ['/admin/search', '/admin/how-guides', '/admin/resource-guides'],
            'data' => ['/admin/data', '/admin/crawler.php', '/admin/sources', '/admin/cluster-tools', '/admin/geocode', '/admin/stories', '/admin/recreation', '/admin/categories', '/admin/api/data.php'],
            'admin' => ['/admin/index.php', '/admin/helper', '/admin/adminportal', '/admin/api/pulse.php'],
        ] as $area => $pres) foreach ($pres as $pre) if (str_starts_with($p, $pre)) return $area;
        if ($p === '/admin' || $p === '/admin/') return 'admin';
        return 'listings';   // listings, review, claims, Nexus, places, journeys, their APIs and the intake
    }

    public static function allowsArea(string $role, string $area): bool
    {
        if ($area === 'self') return true;
        $a = self::AREAS[$role] ?? self::AREAS['manager'];
        return $a === ['*'] || in_array($area, $a, true);
    }

    public static function roleName(string $role): string { return (string) strtok(self::ROLES[$role] ?? ucfirst($role), ' ('); }

    /** "Manager · Operations": the staff login's level and department (Master AOS §9A), or its old role's. */
    public static function levelName(array $s): string
    {
        require_once __DIR__ . '/Workspaces.php';
        [$lv, $dep] = Workspaces::levelOf($s);
        return (Workspaces::LEVELS[$lv] ?? ucfirst($lv)) . ($dep !== '' && isset(Workspaces::DEPARTMENTS[$dep]) ? ' · ' . Workspaces::DEPARTMENTS[$dep][0] : '');
    }

    /** Sets a staff login's level, department and (for an Assistant) the staff login it assists. Owners only. */
    public static function setLevel(PDO $pdo, int $sid, string $level, string $dep, int $assists, int $actorStaff): void
    {
        require_once __DIR__ . '/Workspaces.php';
        if (!isset(Workspaces::LEVELS[$level])) throw new RuntimeException('Choose a level.');
        $s = self::get($pdo, $sid);
        if (!$s || $s['status'] === 'ended') throw new RuntimeException('That staff login has ended.');
        $needsDep = !in_array($level, ['founder', 'executive', 'assistant', 'vendor'], true);
        if ($needsDep && !isset(Workspaces::DEPARTMENTS[$dep])) throw new RuntimeException('Choose a department.');
        if (!$needsDep) $dep = '';
        if ($level === 'assistant') {
            $b = $assists ? self::get($pdo, $assists) : null;
            if (!$b || $b['status'] === 'ended' || $assists === $sid) throw new RuntimeException('Choose who they assist.');
            if (!in_array(Workspaces::levelOf($b)[0], ['executive', 'director', 'manager', 'founder'], true)) throw new RuntimeException('An Assistant supports an Executive, a Director or a Manager.');
        } else $assists = 0;
        if ($s['role'] === 'owner' && $level !== 'founder') throw new RuntimeException('Owners are Founders. Change their role in Staff logins first.');
        if ($s['role'] !== 'owner' && $level === 'founder') throw new RuntimeException('Founders are the owners. Make them an owner in Staff logins.');
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET level = ?, department = ?, assists = ? WHERE id = ?')->execute([$level, $dep, $assists ?: null, $sid]);
        self::log($pdo, $sid, 'role', self::levelName(['level' => $level, 'department' => $dep]), $actorStaff);
    }

    public const SETUP_HOURS = 72;
    public const MAX_FAILS = 5;
    public const LOCK_MINUTES = 15;
    public const CODE_MINUTES = 10;
    private const DOMAIN = 'staff.traversence.invalid';
    private const ISSUER = 'Traversence';

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM ' . Database::t('staff_accounts') . ' LIMIT 1'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    /** Is an owner's staff login set up? From then on only staff logins open the admin side. */
    public static function enforced(PDO $pdo): bool
    {
        static $e = null;
        if ($e !== null) return $e;
        if (!self::ready($pdo)) return $e = false;
        return $e = (bool) $pdo->query("SELECT 1 FROM " . Database::t('staff_accounts') . " WHERE role = 'owner' AND status = 'active' LIMIT 1")->fetchColumn();
    }

    /** Is this browser signed in with a staff login (and is it still on)? */
    public static function inSession(PDO $pdo): ?array
    {
        $sid = (int) ($_SESSION['tv_staff'] ?? 0);
        if ($sid <= 0) return null;
        $s = self::get($pdo, $sid);
        if (!$s || $s['status'] !== 'active' || (int) $s['user_id'] !== (int) ($_SESSION['user_id'] ?? 0)) return null;
        // the switch back to this login counts from its last use here, not from its sign-in (Jason, 2026-11-02)
        if (isset($_SESSION['tv_staff_auth']['id']) && (int) $_SESSION['tv_staff_auth']['id'] === (int) $s['id']) $_SESSION['tv_staff_auth']['at'] = time();
        return $s;
    }

    public static function isStaffUser(string $email): bool { return str_ends_with(strtolower($email), '@' . self::DOMAIN); }

    public static function get(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('staff_accounts') . ' WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function byStaffId(PDO $pdo, string $staffId): ?array
    {
        if (str_contains($staffId, '@')) {   // the work email works as the staff ID too (not a member's own address)
            $st = $pdo->prepare("SELECT * FROM " . Database::t('staff_accounts') . " WHERE email = ? AND status <> 'ended' ORDER BY id LIMIT 1"); $st->execute([strtolower(trim($staffId))]);
            return $st->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        $staffId = strtoupper(trim($staffId));
        if (preg_match('/^\d{1,4}$/', $staffId)) $staffId = sprintf('TRV-%04d', (int) $staffId);   // "7" or "0007" works too
        if (!preg_match('/^TRV-\d{4}$/', $staffId)) return null;
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('staff_accounts') . ' WHERE staff_id = ?'); $st->execute([$staffId]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function all(PDO $pdo): array
    {
        return $pdo->query('SELECT s.*, m.display_name AS member_name, m.email AS member_email FROM ' . Database::t('staff_accounts') . ' s LEFT JOIN users m ON m.id = s.member_user_id ORDER BY s.id')->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function log(PDO $pdo, int $sid, string $event, string $note = '', ?int $actor = null): void
    {
        $pdo->prepare('INSERT INTO ' . Database::t('staff_log') . ' (staff_account_id, event, note, actor_staff_id) VALUES (?, ?, ?, ?)')->execute([$sid, $event, mb_substr($note, 0, 300), $actor]);
    }

    public static function history(PDO $pdo, int $sid, int $limit = 30): array
    {
        $st = $pdo->prepare('SELECT l.*, a.staff_id AS actor FROM ' . Database::t('staff_log') . ' l LEFT JOIN ' . Database::t('staff_accounts') . ' a ON a.id = l.actor_staff_id WHERE l.staff_account_id = ? ORDER BY l.id DESC LIMIT ' . (int) $limit);
        $st->execute([$sid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    // ---- the work email ---------------------------------------------------------------------------------------------

    public static function workDomain(): string
    {
        return strtolower(trim((string) (getenv('STAFF_EMAIL_DOMAIN') ?: 'trvgo.com'), " @\t"));
    }

    /** first.last@<work domain>, lower case; not used by another staff login that hasn't ended. */
    public static function workEmail(PDO $pdo, string $email, int $exceptSid = 0): string
    {
        $email = strtolower(trim($email));
        $d = self::workDomain();
        if (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*\.[a-z0-9]+(?:-[a-z0-9]+)*@' . preg_quote($d, '/') . '$/', $email))
            throw new RuntimeException('Use the work email, first.last@' . $d . '.');
        $q = $pdo->prepare("SELECT staff_id FROM " . Database::t('staff_accounts') . " WHERE email = ? AND status <> 'ended' AND id <> ?"); $q->execute([$email, $exceptSid]);
        if ($other = $q->fetchColumn()) throw new RuntimeException('That email is already ' . $other . '\'s.');
        return $email;
    }

    public static function setEmail(PDO $pdo, int $sid, string $email, ?int $actorStaff): void
    {
        $email = self::workEmail($pdo, $email, $sid);
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET email = ? WHERE id = ?')->execute([$email, $sid]);
        self::log($pdo, $sid, 'email', 'Work email set to ' . self::mask($email), $actorStaff);
    }

    public static function mask(string $email): string { return (string) preg_replace('/(?<=.).(?=[^@]*@)/', '•', $email); }

    /** Emails a 6-digit code for $slot ('signin', 'setup', 'link'); kept (hashed) in this browser's session. Returns the masked address. */
    private static function mailCode(PDO $pdo, array $s, string $slot, string $subject, string $why): string
    {
        $to = (string) ($s['email'] ?? '');
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('This staff login has no work email yet. Ask an owner to add it.');
        $k = 'tv_staff_code_' . $slot; $m = $_SESSION[$k] ?? null;
        if ($m && (int) $m['id'] === (int) $s['id'] && time() - (int) $m['at'] < 30) throw new RuntimeException('A code was sent a moment ago. Give it a minute to arrive.');
        $c = (string) random_int(100000, 999999);
        require_once __DIR__ . '/Mailer.php';
        // the sign-in step: a button to the sign-in page with the code filled in (decisions: Jason, 2026-11-11)
        $link = $slot === 'signin' ? rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/login.php#code=' . $c : '';
        try { Mailer::sendCode($to, $c, $subject, "Your code is $c\n\nIt works for " . self::CODE_MINUTES . " minutes. $why\n\nTraversence", null, $link); }   // $subject names the code: 'staff sign-in code'
        catch (Throwable $e) { error_log('staff code email: ' . $e->getMessage()); throw new RuntimeException('We couldn\'t send the email just now. Try again in a minute' . (self::hasApp($s) ? ', or use your authenticator app.' : '.')); }
        $_SESSION[$k] = ['id' => (int) $s['id'], 'hash' => hash('sha256', $c), 'at' => time(), 'tries' => 0, 'to' => self::mask($to)];
        self::log($pdo, (int) $s['id'], 'code_emailed', (['signin' => 'Sign-in', 'setup' => 'Setup', 'link' => 'Member link'][$slot] ?? ucfirst($slot)) . ' code to ' . self::mask($to));
        return self::mask($to);
    }

    /** Is $code the emailed code for $slot (unused, under 10 minutes, under 5 tries)? Used up when it matches. */
    private static function mailCodeOk(array $s, string $slot, string $code): bool
    {
        $k = 'tv_staff_code_' . $slot; $m = $_SESSION[$k] ?? null;
        if (!$m || (int) $m['id'] !== (int) $s['id'] || time() - (int) $m['at'] > self::CODE_MINUTES * 60) return false;
        if (!hash_equals((string) $m['hash'], hash('sha256', $code))) { if (++$_SESSION[$k]['tries'] >= 5) unset($_SESSION[$k]); return false; }
        unset($_SESSION[$k]);
        return true;
    }

    /** When the code waiting for $slot stops working (a Unix time), or 0 when none is waiting (3f A11: "until 4:42 AM MST"). */
    public static function codeUntil(string $slot, int $sid): int
    {
        $m = $_SESSION['tv_staff_code_' . $slot] ?? null;
        $end = $m && (int) $m['id'] === $sid ? (int) $m['at'] + self::CODE_MINUTES * 60 : 0;
        return $end > time() ? $end : 0;
    }

    /** Where the last code for $slot went (masked), if one is waiting. */
    public static function codeSentTo(string $slot, int $sid): string
    {
        $m = $_SESSION['tv_staff_code_' . $slot] ?? null;
        return $m && (int) $m['id'] === $sid && time() - (int) $m['at'] <= self::CODE_MINUTES * 60 ? (string) $m['to'] : '';
    }

    // ---- an owner manages staff ----------------------------------------------------------------------------------------

    /** Adds a staff login. Returns ['staff' => row, 'setup_url' => the link, 'mailed' => masked address or '']. */
    public static function create(PDO $pdo, string $name, string $email, string $role, ?int $actorStaff, ?int $actorUser = null): array
    {
        $name = mb_substr(trim($name), 0, 100);
        if ($name === '') throw new RuntimeException('Give the person\'s name.');
        if (!isset(self::ROLES[$role])) throw new RuntimeException('Choose a role.');
        $email = self::workEmail($pdo, $email);
        $pdo->beginTransaction();
        try {
            $n = (int) $pdo->query("SELECT COALESCE(MAX(CAST(SUBSTRING(staff_id, 5) AS UNSIGNED)), 0) FROM " . Database::t('staff_accounts') . " FOR UPDATE")->fetchColumn() + 1;
            $staffId = sprintf('TRV-%04d', $n);
            $pdo->prepare('INSERT INTO users (email, display_name, password_hash, email_verified_at, is_admin) VALUES (?, ?, ?, NOW(), ?)')
                ->execute([strtolower($staffId) . '@' . self::DOMAIN, mb_substr($name . ' (' . $staffId . ')', 0, 100), password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), 1]);
            $uid = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO ' . Database::t('staff_accounts') . ' (staff_id, name, role, user_id, email, created_by) VALUES (?, ?, ?, ?, ?, ?)')->execute([$staffId, $name, $role, $uid, $email, $actorStaff]);
            $sid = (int) $pdo->lastInsertId();
            $url = self::newSetup($pdo, $sid);
            self::log($pdo, $sid, 'created', self::ROLES[$role] . ' · ' . self::mask($email) . ($actorStaff === null && $actorUser ? ' · by member #' . $actorUser : ''), $actorStaff);
            $pdo->commit();
        } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
        $s = self::get($pdo, $sid);
        return ['staff' => $s, 'setup_url' => $url, 'mailed' => self::mailSetup($s, $url)];
    }

    /**
     * A test staff login for the site's checks (decisions/0145 §3, TestAccounts): active at once, at the level and
     * department given, with a password and a two-step key. Its email is the test mailbox (nothing is sent to it on the
     * live site), so it signs in with its two-step key. Returns ['sid', 'staff_id', 'password', 'totp'], shown once.
     */
    public static function makeTest(PDO $pdo, string $name, string $level, string $dep, string $email, int $assists = 0): array
    {
        require_once __DIR__ . '/Workspaces.php';
        if (!isset(Workspaces::LEVELS[$level]) || $level === 'founder') throw new RuntimeException('A test login can be any level but Founder.');
        $pdo->beginTransaction();
        try {
            $n = (int) $pdo->query("SELECT COALESCE(MAX(CAST(SUBSTRING(staff_id, 5) AS UNSIGNED)), 0) FROM " . Database::t('staff_accounts') . " FOR UPDATE")->fetchColumn() + 1;
            $staffId = sprintf('TRV-%04d', $n);
            $pdo->prepare('INSERT INTO users (email, display_name, password_hash, email_verified_at, is_admin, is_test) VALUES (?, ?, ?, NOW(), 1, 1)')
                ->execute([strtolower($staffId) . '@' . self::DOMAIN, mb_substr($name . ' (' . $staffId . ')', 0, 100), password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT)]);
            $uid = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO ' . Database::t('staff_accounts') . ' (staff_id, name, role, user_id, email, created_by) VALUES (?, ?, ?, ?, ?, NULL)')->execute([$staffId, $name, 'general', $uid, $email]);
            $sid = (int) $pdo->lastInsertId();
            $pdo->commit();
        } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
        $needsDep = !in_array($level, ['executive', 'assistant', 'vendor'], true);
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET level = ?, department = ?, assists = ? WHERE id = ?')->execute([$level, $needsDep ? $dep : '', $level === 'assistant' && $assists ? $assists : null, $sid]);
        $s = self::resetTest($pdo, $sid);
        self::log($pdo, $sid, 'created', 'Test login for the site checks', null);
        return ['sid' => $sid, 'staff_id' => $staffId] + $s;
    }

    /** A test login's new password and two-step key (Replace sign-ins). Only a test login: its users row is a test. */
    public static function resetTest(PDO $pdo, int $sid): array
    {
        $s = self::get($pdo, $sid);
        if (!$s) throw new RuntimeException('That staff login isn\'t here.');
        $t = $pdo->prepare('SELECT is_test FROM users WHERE id = ?'); $t->execute([(int) $s['user_id']]);
        if (!(int) $t->fetchColumn()) throw new RuntimeException('Only a test login\'s sign-in can be replaced here.');
        $pw = rtrim(strtr(base64_encode(random_bytes(18)), '+/', 'Ab'), '=') . '-T9';
        $secret = self::base32(random_bytes(20));
        $pdo->prepare("UPDATE " . Database::t('staff_accounts') . " SET status = 'active', password_hash = ?, totp_secret = ?, totp_last_step = 0, setup_hash = '', setup_until = NULL, failed = 0, locked_until = NULL WHERE id = ?")
            ->execute([password_hash($pw, PASSWORD_DEFAULT), self::seal($secret), $sid]);
        return ['password' => $pw, 'totp' => $secret];
    }

    /** May $actor (a staff row) reset $target? Owners: anyone. Managers (and the older Admin role): another login that isn't an owner. */
    public static function canReset(?array $actor, array $target): bool
    {
        if (!$actor || $actor['status'] !== 'active' || $target['status'] === 'ended') return false;
        if ($actor['role'] === 'owner') return true;
        return in_array($actor['role'], ['admin', 'manager'], true) && $target['role'] !== 'owner' && (int) $actor['id'] !== (int) $target['id'];
    }

    /** A new one-time setup link (the old password and authenticator stop working). */
    private static function newSetup(PDO $pdo, int $sid): string
    {
        $tok = bin2hex(random_bytes(24));
        $pdo->prepare("UPDATE " . Database::t('staff_accounts') . " SET status = IF(status = 'ended', 'ended', 'setup'), password_hash = '', totp_secret = '', totp_last_step = 0, setup_hash = ?, setup_until = ?, failed = 0, locked_until = NULL WHERE id = ?")
            ->execute([hash('sha256', $tok), date('Y-m-d H:i:s', time() + self::SETUP_HOURS * 3600), $sid]);
        // kept sealed, so it can be opened or copied again from Staff logins until it's used or expires
        $pdo->prepare('INSERT INTO ' . Database::t('staff_settings') . ' (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)')->execute(['setup:' . $sid, self::seal($tok)]);
        return self::setupLink($tok);
    }

    /** Emails the setup link to the work email; the masked address, or '' if it couldn't go (the link is on Staff logins either way). */
    private static function mailSetup(?array $s, string $url): string
    {
        if (!$s || !filter_var((string) $s['email'], FILTER_VALIDATE_EMAIL)) return '';
        require_once __DIR__ . '/Mailer.php';
        try {
            Mailer::send((string) $s['email'], 'Set up your Traversence staff login (' . $s['staff_id'] . ')', "Hi " . $s['name'] . ",\n\nYour staff ID is " . $s['staff_id'] . ". Open this link to choose your password:\n\n$url\n\nIt works once, for " . self::SETUP_HOURS . " hours. After that you'll sign in at traversence.com/admin/login.php with your staff ID, your password and a code we email here (or type your staff ID in the site's own Sign in).\n\nGoogle, Microsoft and Facebook never sign in to your staff login: they're for member accounts only. If your own member account is linked to this staff login, Switch takes you between them.\n\nTraversence");
            return self::mask((string) $s['email']);
        } catch (Throwable $e) { error_log('staff setup email: ' . $e->getMessage()); return ''; }
    }

    private static function setupLink(string $tok): string
    {
        return rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/setup.php?t=' . $tok;
    }

    /** The waiting setup link for a staff login, while it still works: ['url', 'until'], or null (used, expired, ended). */
    public static function setupUrl(PDO $pdo, int $sid): ?array
    {
        $s = self::get($pdo, $sid);
        if (!$s || $s['status'] !== 'setup' || !$s['setup_hash'] || strtotime((string) $s['setup_until']) <= time()) return null;
        $st = $pdo->prepare('SELECT value FROM ' . Database::t('staff_settings') . ' WHERE name = ?'); $st->execute(['setup:' . $sid]);
        $tok = self::unseal((string) ($st->fetchColumn() ?: ''));
        if ($tok === '' || !hash_equals((string) $s['setup_hash'], hash('sha256', $tok))) return null;
        return ['url' => self::setupLink($tok), 'until' => (string) $s['setup_until']];
    }

    private static function forgetSetup(PDO $pdo, int $sid): void
    {
        $pdo->prepare('DELETE FROM ' . Database::t('staff_settings') . ' WHERE name = ?')->execute(['setup:' . $sid]);
    }

    /** Forgotten password, lost mailbox or phone: a new setup link (emailed, and on Staff logins); their sessions end now. */
    public static function reset(PDO $pdo, int $sid, ?int $actorStaff): array
    {
        $s = self::get($pdo, $sid);
        if (!$s || $s['status'] === 'ended') throw new RuntimeException('That staff login has ended. Add the person again.');
        self::endSessions($pdo, $s);
        $url = self::newSetup($pdo, $sid);
        self::log($pdo, $sid, 'reset', 'A new setup link was made', $actorStaff);
        return ['url' => $url, 'mailed' => self::mailSetup($s, $url)];
    }

    /** Ends a staff login for good: switched off at once, sessions ended, admin roles removed; its history stays. */
    public static function end(PDO $pdo, int $sid, ?int $actorStaff, string $why = ''): void
    {
        $s = self::get($pdo, $sid);
        if (!$s) throw new RuntimeException('That staff login isn\'t here.');
        if ($s['role'] === 'owner' && (int) $pdo->query("SELECT COUNT(*) FROM " . Database::t('staff_accounts') . " WHERE role = 'owner' AND status = 'active' AND id <> " . (int) $sid)->fetchColumn() === 0 && $s['status'] === 'active')
            throw new RuntimeException('That\'s the only owner. Add another owner first, so someone can still manage staff.');
        self::endSessions($pdo, $s);
        $uid = (int) $s['user_id'];
        $pdo->prepare('UPDATE users SET is_admin = 0, is_suspended = 1 WHERE id = ?')->execute([$uid]);
        $pdo->prepare('DELETE FROM ' . Database::t('admin_access') . ' WHERE user_id = ?')->execute([$uid]);
        try { $pdo->prepare('UPDATE ' . Database::t('role_grants') . ' SET revoked_at = NOW(), revoked_by = ? WHERE user_id = ? AND revoked_at IS NULL')->execute([$actorStaff, $uid]); } catch (Throwable) {}
        require_once __DIR__ . '/SupportAccess.php'; SupportAccess::endForUser($pdo, $uid, $actorStaff);   // their White Glove access ends (0117)
        $pdo->prepare("UPDATE " . Database::t('staff_accounts') . " SET status = 'ended', password_hash = '', totp_secret = '', setup_hash = NULL, ended_at = NOW(), ended_by = ? WHERE id = ?")->execute([$actorStaff, $sid]);
        self::forgetSetup($pdo, $sid);
        self::log($pdo, $sid, 'ended', $why !== '' ? $why : 'Staff access ended', $actorStaff);
    }

    public static function setRole(PDO $pdo, int $sid, string $role, int $actorStaff): void
    {
        if (!isset(self::ROLES[$role])) throw new RuntimeException('Choose a role.');
        $s = self::get($pdo, $sid);
        if (!$s || $s['status'] === 'ended') throw new RuntimeException('That staff login has ended.');
        if ($s['role'] === 'owner' && $role !== 'owner' && (int) $pdo->query("SELECT COUNT(*) FROM " . Database::t('staff_accounts') . " WHERE role = 'owner' AND status <> 'ended' AND id <> " . (int) $sid)->fetchColumn() === 0)
            throw new RuntimeException('That\'s the only owner. Make someone else an owner first.');
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET role = ? WHERE id = ?')->execute([$role, $sid]);
        self::log($pdo, $sid, 'role', self::ROLES[$role], $actorStaff);
    }

    private static function endSessions(PDO $pdo, array $s): void
    {
        $pdo->prepare('UPDATE users SET session_version = session_version + 1 WHERE id = ?')->execute([(int) $s['user_id']]);
    }

    // ---- setting up (the one-time link): a password, and a code emailed to the work email ----------------------------

    public static function bySetup(PDO $pdo, string $tok): ?array
    {
        if (!preg_match('/^[0-9a-f]{48}$/', $tok)) return null;
        $st = $pdo->prepare("SELECT * FROM " . Database::t('staff_accounts') . " WHERE setup_hash = ? AND setup_until > NOW() AND status = 'setup'"); $st->execute([hash('sha256', $tok)]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function sendSetupCode(PDO $pdo, array $s): string
    {
        return self::mailCode($pdo, $s, 'setup', 'staff setup code', 'It confirms this is your work email. If you aren\'t setting up ' . $s['staff_id'] . ', ignore this email.');
    }

    /** Finishes setup: the password, and the code emailed to the work email (proving it reaches them). */
    public static function completeSetup(PDO $pdo, string $tok, string $password, string $password2, string $code): array
    {
        $s = self::bySetup($pdo, $tok);
        if (!$s) throw new RuntimeException('This setup link has expired or was already used. Ask an owner for a new one.');
        self::checkNewPassword($s, $password, $password2);
        if (!self::mailCodeOk($s, 'setup', str_replace(' ', '', trim($code)))) throw new RuntimeException('That code doesn\'t match the one we emailed to ' . self::mask((string) $s['email']) . '. Check the newest email, or send a new code.');
        $pdo->prepare("UPDATE " . Database::t('staff_accounts') . " SET status = 'active', password_hash = ?, setup_hash = NULL, setup_until = NULL, failed = 0, locked_until = NULL WHERE id = ?")
            ->execute([password_hash($password, PASSWORD_DEFAULT), (int) $s['id']]);
        self::forgetSetup($pdo, (int) $s['id']);
        self::log($pdo, (int) $s['id'], 'set_up', 'Password set, work email confirmed');
        return $s;
    }

    private static function checkNewPassword(array $s, string $p1, string $p2): void
    {
        if (strlen($p1) < 12) throw new RuntimeException('Use a password of at least 12 characters.');
        if ($p1 !== $p2) throw new RuntimeException('The two passwords don\'t match.');
        if (stripos($p1, (string) $s['staff_id']) !== false) throw new RuntimeException('Don\'t use your staff ID in your password.');
    }

    // ---- signing in -------------------------------------------------------------------------------------------------

    /** Step 1: staff ID and password; then a code is emailed. Returns ['staff' => row, 'mailed' => masked address or '', 'mail_error' => '']. */
    public static function checkPassword(PDO $pdo, string $staffId, string $password): array
    {
        $bad = 'That staff ID and password don\'t match.';
        $s = self::byStaffId($pdo, $staffId);
        if (!$s) { password_verify($password, '$2y$10$abcdefghijklmnopqrstuuJ8m7c2a5mJx8N5bS4m3m3m3m3m3m3m'); throw new RuntimeException($bad); }
        if ($s['status'] !== 'active') throw new RuntimeException($s['status'] === 'ended' ? 'This staff login has ended.' : 'This staff login isn\'t set up yet: use the setup link in your email.');
        if ($s['locked_until'] && strtotime((string) $s['locked_until']) > time()) throw new RuntimeException('Too many tries. Try again after ' . date('g:i a', strtotime((string) $s['locked_until'])) . ', or ask an owner.');
        if (!password_verify($password, (string) $s['password_hash'])) { self::fail($pdo, $s, 'Wrong password'); throw new RuntimeException($bad); }
        if (!filter_var((string) $s['email'], FILTER_VALIDATE_EMAIL) && !self::hasApp($s)) throw new RuntimeException('This staff login has no work email yet. Ask an owner to add it on Staff logins.');
        $_SESSION['tv_staff_step'] = ['id' => (int) $s['id'], 'at' => time()];
        $mailed = self::codeSentTo('signin', (int) $s['id']); $err = '';
        if ($mailed === '' && filter_var((string) $s['email'], FILTER_VALIDATE_EMAIL)) {
            try { $mailed = self::sendSignInCode($pdo, $s); } catch (RuntimeException $e) { $err = $e->getMessage(); }
        }
        return ['staff' => $s, 'mailed' => $mailed, 'mail_error' => $err];
    }

    public static function sendSignInCode(PDO $pdo, array $s): string
    {
        return self::mailCode($pdo, $s, 'signin', 'staff sign-in code', 'If you didn\'t just sign in as ' . $s['staff_id'] . ', someone has your password: change it, and tell an owner.');
    }

    /** "Send a new code" on step 2. */
    public static function resendCode(PDO $pdo): string
    {
        $st = $_SESSION['tv_staff_step'] ?? null;
        $s = $st ? self::get($pdo, (int) $st['id']) : null;
        if (!$s) throw new RuntimeException('Start again with your staff ID.');
        return self::sendSignInCode($pdo, $s);
    }

    /** Step 2: the emailed code, or the authenticator app's code if they've added one. Signs this browser in. */
    public static function checkCode(PDO $pdo, string $code): array
    {
        $st = $_SESSION['tv_staff_step'] ?? null;
        if (!$st || time() - (int) $st['at'] > self::CODE_MINUTES * 60) { unset($_SESSION['tv_staff_step']); throw new RuntimeException('That took too long. Start again with your staff ID.'); }
        $s = self::get($pdo, (int) $st['id']);
        if (!$s || $s['status'] !== 'active') throw new RuntimeException('This staff login isn\'t active.');
        if ($s['locked_until'] && strtotime((string) $s['locked_until']) > time()) throw new RuntimeException('Too many tries. Try again later, or ask an owner.');
        $code = str_replace(' ', '', trim($code));
        $how = '';
        if (preg_match('/^\d{6}$/', $code)) {
            if (self::mailCodeOk($s, 'signin', $code)) $how = 'emailed code';
            elseif (($step = self::totpMatch(self::unseal((string) $s['totp_secret']), $code, (int) $s['totp_last_step'])) > 0) {
                $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET totp_last_step = ? WHERE id = ?')->execute([$step, (int) $s['id']]); $how = 'authenticator app';
            }
        }
        if ($how === '') { self::fail($pdo, $s, 'Wrong code'); throw new RuntimeException('That code doesn\'t match. Use the newest code we emailed' . (self::hasApp($s) ? ', or the one your authenticator app shows now.' : '.')); }
        unset($_SESSION['tv_staff_step']);
        // signed in as the staff login's own user record (its admin roles); the admin side's second step is done
        $u = $pdo->prepare('SELECT id, session_version FROM users WHERE id = ?'); $u->execute([(int) $s['user_id']]); $u = $u->fetch(PDO::FETCH_ASSOC);
        if (!$u) throw new RuntimeException('This staff login is missing its record. Ask an owner to reset it.');
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $u['id'];
        $_SESSION['session_version'] = (int) $u['session_version'];
        $_SESSION['tv_staff'] = (int) $s['id'];
        $_SESSION['tv_2s_ok'] = (int) $u['id'];
        $_SESSION['tv_staff_auth'] = ['id' => (int) $s['id'], 'at' => time(), 'sv' => (int) $u['session_version']];   // switching to the member account and back
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET failed = 0, locked_until = NULL, last_sign_in_at = NOW() WHERE id = ?')->execute([(int) $s['id']]);
        self::log($pdo, (int) $s['id'], 'signed_in', 'with ' . $how . ' · ' . self::device());
        return ['staff' => $s, 'how' => $how];
    }

    private static function fail(PDO $pdo, array $s, string $what): void
    {
        $n = (int) $s['failed'] + 1;
        $lock = $n >= self::MAX_FAILS ? date('Y-m-d H:i:s', time() + self::LOCK_MINUTES * 60) : null;
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET failed = ?, locked_until = ? WHERE id = ?')->execute([$lock ? 0 : $n, $lock, (int) $s['id']]);
        self::log($pdo, (int) $s['id'], $lock ? 'locked' : 'failed', $what . ($lock ? ': locked for ' . self::LOCK_MINUTES . ' minutes' : '') . ' · ' . self::device());
    }

    private static function device(): string
    {
        $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $os = preg_match('/iPhone|iPad/i', $ua) ? 'iPhone/iPad' : (preg_match('/Android/i', $ua) ? 'Android' : (preg_match('/Windows/i', $ua) ? 'Windows' : (preg_match('/Mac OS/i', $ua) ? 'Mac' : 'another device')));
        $br = preg_match('/Edg\//', $ua) ? 'Edge' : (preg_match('/Chrome\//', $ua) ? 'Chrome' : (preg_match('/Firefox\//', $ua) ? 'Firefox' : (preg_match('/Safari\//', $ua) ? 'Safari' : 'a browser')));
        return "$br on $os";
    }

    // ---- signed in: your own login (password, the optional authenticator app) -----------------------------------------

    public static function changePassword(PDO $pdo, int $sid, string $current, string $p1, string $p2): void
    {
        $s = self::get($pdo, $sid);
        if (!$s || !password_verify($current, (string) $s['password_hash'])) { if ($s) self::fail($pdo, $s, 'Wrong current password'); throw new RuntimeException('Your current password isn\'t right.'); }
        self::checkNewPassword($s, $p1, $p2);
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET password_hash = ? WHERE id = ?')->execute([password_hash($p1, PASSWORD_DEFAULT), $sid]);
        self::log($pdo, $sid, 'password_changed', self::device(), $sid);
    }

    public static function hasApp(array $s): bool { return (string) ($s['totp_secret'] ?? '') !== ''; }

    /** The authenticator fallback: proven with the code the app shows for the key on the page. */
    public static function addApp(PDO $pdo, int $sid, string $code): void
    {
        $secret = self::pendingSecret($sid);
        $step = self::totpMatch($secret, str_replace(' ', '', trim($code)), 0);
        if ($step === 0) throw new RuntimeException('That code doesn\'t match. Check the app shows Traversence, and type the code it shows now.');
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET totp_secret = ?, totp_last_step = ? WHERE id = ?')->execute([self::seal($secret), $step, $sid]);
        unset($_SESSION['tv_staff_setup_' . $sid]);
        self::log($pdo, $sid, 'app_added', 'Authenticator app added (fallback)', $sid);
    }

    public static function removeApp(PDO $pdo, int $sid, ?int $actorStaff): void
    {
        $pdo->prepare("UPDATE " . Database::t('staff_accounts') . " SET totp_secret = '', totp_last_step = 0 WHERE id = ?")->execute([$sid]);
        self::log($pdo, $sid, 'app_removed', 'Authenticator app removed', $actorStaff);
    }

    /** The key on the page while adding the app (kept in the session until the code proves it was added). */
    public static function pendingSecret(int $sid): string
    {
        $k = 'tv_staff_setup_' . $sid;
        if (empty($_SESSION[$k])) $_SESSION[$k] = self::base32(random_bytes(20));
        return (string) $_SESSION[$k];
    }

    public static function newPendingSecret(int $sid): string
    {
        unset($_SESSION['tv_staff_setup_' . $sid]);
        return self::pendingSecret($sid);
    }

    public static function otpauthUri(string $staffId, string $secret): string
    {
        return 'otpauth://totp/' . rawurlencode(self::ISSUER . ':' . $staffId) . '?' . http_build_query(['secret' => $secret, 'issuer' => self::ISSUER, 'digits' => 6, 'period' => 30], '', '&', PHP_QUERY_RFC3986);
    }

    // ---- switching between the staff login and the person's own member account (the account menu) ------------------
    //
    // One browser, both accounts: signed in with the staff login, the person can switch to the member account they
    // linked (proven when linking) without signing in again, and back to the staff login for SWITCH_HOURS after the
    // staff login was last used in this browser (each admin page renews it; Jason, 2026-11-02). Ending or resetting the staff login (its sessions end) stops the switch back.

    public const SWITCH_HOURS = 12;

    /** The other account this browser can move to: ['to' => member|staff|staff_signin|link, 'name', 'sub'], or null. */
    public static function otherAccount(PDO $pdo, array $me): ?array
    {
        if (!self::ready($pdo)) return null;
        $uid = (int) $me['id'];
        if (self::isStaffUser((string) ($me['email'] ?? ''))) {
            $s = self::inSession($pdo);
            if (!$s) return null;
            $m = $s['member_user_id'] ? self::memberRow($pdo, (int) $s['member_user_id']) : null;
            if (!$m) return ['to' => 'link', 'name' => 'Your member account', 'sub' => 'Not linked yet'];
            return ['to' => 'member', 'uid' => (int) $m['id'], 'name' => trim((string) $m['display_name']) ?: (string) strstr((string) $m['email'], '@', true), 'sub' => 'Personal Account'];
        }
        $st = $pdo->prepare("SELECT * FROM " . Database::t('staff_accounts') . " WHERE member_user_id = ? AND status = 'active' ORDER BY id LIMIT 1"); $st->execute([$uid]);
        $s = $st->fetch(PDO::FETCH_ASSOC);
        if (!$s) return null;
        return ['to' => self::canSwitchBack($pdo, $s, $uid) ? 'staff' : 'staff_signin', 'name' => 'Traversence staff', 'sub' => $s['staff_id'] . ' · ' . ($s['role'] === 'owner' ? 'Owner' : 'Admin')];
    }

    private static function memberRow(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM users WHERE id = ?'); $st->execute([$id]);
        $m = $st->fetch(PDO::FETCH_ASSOC);
        if (!$m || !empty($m['is_suspended']) || !empty($m['deleted_at']) || self::isStaffUser((string) $m['email'])) return null;
        return $m;
    }

    private static function canSwitchBack(PDO $pdo, array $s, int $uid): bool
    {
        $a = $_SESSION['tv_staff_auth'] ?? null;
        if (!$a || (int) $a['id'] !== (int) $s['id'] || time() - (int) $a['at'] > self::SWITCH_HOURS * 3600 || (int) $s['member_user_id'] !== $uid) return false;
        $v = $pdo->prepare('SELECT session_version FROM users WHERE id = ?'); $v->execute([(int) $s['user_id']]);
        return (int) $v->fetchColumn() === (int) $a['sv'];
    }

    /** Moves this browser to the member account ('member') or back to the staff login ('staff'). Returns where to go next. */
    public static function switchTo(PDO $pdo, array $me, string $to): string
    {
        if ($to === 'member') {
            $s = self::inSession($pdo);
            $m = $s && $s['member_user_id'] ? self::memberRow($pdo, (int) $s['member_user_id']) : null;
            if (!$m) throw new RuntimeException('Link your member account first: sign in as that member and link this staff login from Dashboard → Privacy.');
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $m['id'];
            $_SESSION['session_version'] = (int) $m['session_version'];
            $_SESSION['tv_ctx'] = 'member';
            unset($_SESSION['tv_staff'], $_SESSION['tv_2s_ok']);
            self::log($pdo, (int) $s['id'], 'switched', 'To the linked member account · ' . self::device(), (int) $s['id']);
            return '/user/dashboard.php#pulse';
        }
        $st = $pdo->prepare("SELECT * FROM " . Database::t('staff_accounts') . " WHERE member_user_id = ? AND status = 'active' ORDER BY id LIMIT 1"); $st->execute([(int) $me['id']]);
        $s = $st->fetch(PDO::FETCH_ASSOC);
        if (!$s || !self::canSwitchBack($pdo, $s, (int) $me['id'])) return '/admin/login.php';
        $v = $pdo->prepare('SELECT session_version FROM users WHERE id = ?'); $v->execute([(int) $s['user_id']]);
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $s['user_id'];
        $_SESSION['session_version'] = (int) $v->fetchColumn();
        $_SESSION['tv_staff'] = (int) $s['id'];
        $_SESSION['tv_2s_ok'] = (int) $s['user_id'];
        $_SESSION['tv_ctx'] = 'admin';
        self::log($pdo, (int) $s['id'], 'switched', 'Back from the member account · ' . self::device(), (int) $s['id']);
        return '/admin/';
    }

    // ---- the member link --------------------------------------------------------------------------------------------

    /** From the member side: a code to the staff login's work email, to prove it's theirs. */
    public static function sendLinkCode(PDO $pdo, string $staffId): string
    {
        $s = self::byStaffId($pdo, $staffId);
        if (!$s || $s['status'] !== 'active') throw new RuntimeException('That staff ID isn\'t an active staff login.');
        return self::mailCode($pdo, $s, 'link', 'code to link your member account', 'It links staff login ' . $s['staff_id'] . ' to a member account, for staff notices. If that isn\'t you, ignore this email.');
    }

    /** A member links their own staff login with the code emailed to its work email (or its authenticator app's code). */
    public static function linkMember(PDO $pdo, int $memberUserId, string $staffId, string $code): array
    {
        $s = self::byStaffId($pdo, $staffId);
        if (!$s || $s['status'] !== 'active') throw new RuntimeException('That staff ID isn\'t an active staff login.');
        if ($s['locked_until'] && strtotime((string) $s['locked_until']) > time()) throw new RuntimeException('Too many tries. Try again later.');
        $code = str_replace(' ', '', trim($code));
        $step = 0;
        if (!self::mailCodeOk($s, 'link', $code)) {
            $step = self::totpMatch(self::unseal((string) $s['totp_secret']), $code, (int) $s['totp_last_step']);
            if ($step === 0) { self::fail($pdo, $s, 'Wrong code while linking a member account'); throw new RuntimeException('That code doesn\'t match the one we emailed to the staff login\'s work email.'); }
        }
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET member_user_id = ?, totp_last_step = GREATEST(totp_last_step, ?) WHERE id = ?')->execute([$memberUserId, $step, (int) $s['id']]);
        self::log($pdo, (int) $s['id'], 'linked', 'Member account #' . $memberUserId . ' linked, for notices');
        return $s;
    }

    /**
     * An owner links a staff login to a member account (Jason, 2026-10-23: the admin links, not every member). A linked
     * staff login can switch into that member account without its password, so the member says yes first: we email
     * them a link (good for 3 days, signed, no table) that they open signed in as that member and confirm.
     */
    public static function requestMemberLink(PDO $pdo, int $sid, string $memberEmail, ?int $actorStaff): string
    {
        $s = self::get($pdo, $sid);
        if (!$s || $s['status'] === 'ended') throw new RuntimeException('That staff login isn\'t active.');
        $st = $pdo->prepare('SELECT id, email, display_name FROM users WHERE email = ? AND deleted_at IS NULL'); $st->execute([trim($memberEmail)]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if (!$u || self::isStaffUser((string) $u['email'])) throw new RuntimeException('No member account has that email.');
        $body = $sid . '.' . (int) $u['id'] . '.' . (time() + 3 * 86400);
        $tok = rtrim(strtr(base64_encode($body), '+/', '-_'), '=') . '.' . substr(hash_hmac('sha256', 'link|' . $body, self::key()), 0, 32);
        $url = rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/user/staff-link.php?t=' . $tok;
        require_once __DIR__ . '/Mailer.php';
        Mailer::send((string) $u['email'], 'Link your Traversence account to staff login ' . $s['staff_id'],
            'Our team asked to link your member account to staff login ' . $s['staff_id'] . ' (' . $s['name'] . ").\n\nOnce linked, that staff login can switch into this account from its menu without your password, and staff notices reach you here. Only say yes if the staff login is yours.\n\nSign in as this account and confirm (the link works for 3 days):\n" . $url . "\n\nIf this isn't you, ignore this email: nothing is linked.");
        self::log($pdo, $sid, 'link_asked', 'Link to member account #' . (int) $u['id'] . ' asked; waiting for them to confirm', $actorStaff);
        return (string) $u['email'];
    }

    /** The link an owner asked for, if the token is good and meant for this member: [staff login, member id] or null. */
    public static function memberLinkFor(PDO $pdo, string $tok, int $memberUserId): ?array
    {
        [$b, $mac] = array_pad(explode('.', $tok, 2), 2, '');
        $body = (string) base64_decode(strtr($b, '-_', '+/'), true);
        if ($body === '' || !hash_equals(substr(hash_hmac('sha256', 'link|' . $body, self::key()), 0, 32), $mac)) return null;
        [$sid, $uid, $exp] = array_map('intval', array_pad(explode('.', $body), 3, 0));
        if ($exp < time() || $uid !== $memberUserId) return null;
        $s = self::get($pdo, $sid);
        return $s && $s['status'] !== 'ended' ? $s : null;
    }

    /** The member says yes to the link an owner asked for. */
    public static function confirmMemberLink(PDO $pdo, string $tok, int $memberUserId): array
    {
        $s = self::memberLinkFor($pdo, $tok, $memberUserId);
        if (!$s) throw new RuntimeException('That link has expired or isn\'t for this account. Ask an owner to send a new one.');
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET member_user_id = ? WHERE id = ?')->execute([$memberUserId, (int) $s['id']]);
        self::log($pdo, (int) $s['id'], 'linked', 'Member account #' . $memberUserId . ' linked (asked by an owner, confirmed by the member)');
        return $s;
    }

    public static function unlinkMember(PDO $pdo, int $memberUserId, int $sid): void
    {
        $pdo->prepare('UPDATE ' . Database::t('staff_accounts') . ' SET member_user_id = NULL WHERE id = ? AND member_user_id = ?')->execute([$sid, $memberUserId]);
        self::log($pdo, $sid, 'unlinked', 'Member account #' . $memberUserId . ' unlinked');
    }

    public static function forMember(PDO $pdo, int $memberUserId): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT id, staff_id, name, role, status FROM " . Database::t('staff_accounts') . " WHERE member_user_id = ? AND status <> 'ended'"); $st->execute([$memberUserId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    // ---- TOTP (RFC 6238), base32, sealing ---------------------------------------------------------------------------

    /** The 30-second step whose code matches (within one step either side, never one already used), or 0. */
    public static function totpMatch(string $secret, string $code, int $lastStep): int
    {
        if ($secret === '' || !preg_match('/^\d{6}$/', $code)) return 0;
        $now = intdiv(time(), 30);
        foreach ([0, -1, 1] as $d) {
            $step = $now + $d;
            if ($step > $lastStep && hash_equals(self::totp($secret, $step), $code)) return $step;
        }
        return 0;
    }

    public static function totp(string $secret, int $step): string
    {
        $key = self::base32Decode($secret);
        $h = hash_hmac('sha1', pack('N2', ($step >> 32) & 0xFFFFFFFF, $step & 0xFFFFFFFF), $key, true);
        $o = ord($h[19]) & 0x0F;
        $n = ((ord($h[$o]) & 0x7F) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
        return str_pad((string) ($n % 1000000), 6, '0', STR_PAD_LEFT);
    }

    private static function base32(string $bin): string
    {
        $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
        foreach (str_split($bin) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
        foreach (str_split($bits, 5) as $b) $out .= $a[bindec(str_pad($b, 5, '0'))];
        return $out;
    }

    private static function base32Decode(string $s): string
    {
        $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
        foreach (str_split(strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $s))) as $c) $bits .= str_pad(decbin(strpos($a, $c)), 5, '0', STR_PAD_LEFT);
        foreach (str_split($bits, 8) as $b) if (strlen($b) === 8) $out .= chr(bindec($b));
        return $out;
    }

    private static function key(): string
    {
        return sodium_crypto_generichash('tv-staff|' . (string) (getenv('APP_SECRET') ?: getenv('DB_PASSWORD') ?: ''), '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES);
    }

    private static function seal(string $s): string
    {
        $n = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return base64_encode($n . sodium_crypto_secretbox($s, $n, self::key()));
    }

    private static function unseal(string $b): string
    {
        if ($b === '') return '';
        $raw = base64_decode($b, true) ?: '';
        $out = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), self::key());
        return $out === false ? '' : $out;
    }

    /**
     * A key sealed here, sealed again for another copy of the site whose APP_SECRET is $secret: the staging copy, so the
     * test staff logins sign in there with the same two-step keys (StagingSite, decisions/0145 Phase 3). '' when empty.
     */
    public static function resealFor(string $sealed, string $secret): string
    {
        $plain = self::unseal($sealed);
        if ($plain === '' || $secret === '') return '';
        $n = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return base64_encode($n . sodium_crypto_secretbox($plain, $n, sodium_crypto_generichash('tv-staff|' . $secret, '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES)));
    }
}
