<?php
// app/lib/StaffMailHelp.php — "Can't get the email?": a lost work email is never a dead end (decisions/0100's note of
// 2026-11-22; screens proposal B8 with the session manager's guard rails; built in Release 3f).
//
// On the staff code step (/admin/login.php, after the right staff ID and password), the person can ask for help: their
// name and a phone or another email to reach them. It becomes an owners' Pulse case (Security, key staffmail:<id>, one
// case per request). The form isn't signed in, so the case shows first who the login is, its work email now, its last
// sign-in and the contact given, marked not verified; each button asks "Have you confirmed this is them?" first:
//   Change work email          StaffLogin::setEmail; the old address is told
//   Reset the mailbox password CPanelMail::setPassword (our own work domain only); shown once to the owner
//   New setup link             StaffLogin::reset (their sessions end, password and authenticator cleared); the link is
//                              shown to the owner to hand over, never only emailed to the mailbox they can't reach
// Every action goes in the staff log (StaffLogin::log) and on the case (Pulse notes). Owners only.
// Requests are held in staff_mail_requests (class "never" in staging-tables.php: sign-in recovery, empty on staging).
declare(strict_types=1);

require_once __DIR__ . '/StaffLogin.php';

final class StaffMailHelp
{
    public const PER_LOGIN_DAY = 3;      // requests (and updates) for one staff login in 24 hours
    public const PER_ADDRESS_DAY = 6;    // from one network address in 24 hours
    public const SESSION_WAIT = 120;     // seconds between two sends from one browser

    private static bool $ready = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $pdo->exec('CREATE TABLE IF NOT EXISTS ' . Database::t('staff_mail_requests') . ' (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            staff_account_id INT UNSIGNED NOT NULL,
            name VARCHAR(120) NOT NULL DEFAULT \'\',
            contact VARCHAR(190) NOT NULL DEFAULT \'\',
            ip_hash CHAR(64) NOT NULL DEFAULT \'\',
            device VARCHAR(120) NOT NULL DEFAULT \'\',
            tz VARCHAR(64) NOT NULL DEFAULT \'\',
            sends INT UNSIGNED NOT NULL DEFAULT 1,
            status VARCHAR(12) NOT NULL DEFAULT \'open\',
            outcome VARCHAR(300) NOT NULL DEFAULT \'\',
            done_by INT UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            done_at DATETIME NULL,
            KEY by_login (staff_account_id, status),
            KEY by_ip (ip_hash, updated_at)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
        self::$ready = true;
    }

    /** A phone (7+ digits) or an email address; '' when it's neither. */
    public static function cleanContact(string $c): string
    {
        $c = trim(preg_replace('/\s+/', ' ', $c));
        if ($c === '' || mb_strlen($c) > 190) return '';
        if (filter_var($c, FILTER_VALIDATE_EMAIL)) return strtolower($c);
        return preg_match('/^[+()\d .\-x]+$/i', $c) && strlen(preg_replace('/\D/', '', $c)) >= 7 ? $c : '';
    }

    /**
     * From the code step: tied to this browser's sign-in step (the right staff ID and password, in the last 10 minutes).
     * Returns the words to show. An open request for the same login is updated in place (one case per request).
     */
    public static function request(PDO $pdo, string $name, string $contact, string $tz = ''): string
    {
        $step = $_SESSION['tv_staff_step'] ?? null;
        if (!$step || time() - (int) $step['at'] > StaffLogin::CODE_MINUTES * 60) throw new RuntimeException('That took too long. Start again with your staff ID and password, then choose Can\'t get the email?');
        $s = StaffLogin::get($pdo, (int) $step['id']);
        if (!$s || $s['status'] !== 'active') throw new RuntimeException('This staff login isn\'t active. Write to support@traversence.com.');
        $name = trim(preg_replace('/\s+/', ' ', $name));
        if (mb_strlen($name) < 2 || mb_strlen($name) > 120) throw new RuntimeException('Write your name.');
        $c = self::cleanContact($contact);
        if ($c === '') throw new RuntimeException('Write a phone number or another email where an owner can reach you.');
        $last = (int) ($_SESSION['tv_staffmail_at'] ?? 0);
        if ($last && time() - $last < self::SESSION_WAIT) throw new RuntimeException('Your request was sent a moment ago. An owner will contact you; there\'s no need to send it again.');
        self::ensure($pdo);
        $ip = hash('sha256', (string) ($_SERVER['REMOTE_ADDR'] ?? '') . '|staffmail');
        $day = date('Y-m-d H:i:s', time() - 86400);
        $q = $pdo->prepare('SELECT COALESCE(SUM(sends), 0) FROM ' . Database::t('staff_mail_requests') . ' WHERE staff_account_id = ? AND updated_at >= ?'); $q->execute([(int) $s['id'], $day]);
        if ((int) $q->fetchColumn() >= self::PER_LOGIN_DAY) throw new RuntimeException('The owners already have your request. They\'ll contact you; if it\'s urgent, write to support@traversence.com.');
        $q = $pdo->prepare('SELECT COALESCE(SUM(sends), 0) FROM ' . Database::t('staff_mail_requests') . ' WHERE ip_hash = ? AND updated_at >= ?'); $q->execute([$ip, $day]);
        if ((int) $q->fetchColumn() >= self::PER_ADDRESS_DAY) throw new RuntimeException('Too many requests from here today. Write to support@traversence.com.');
        $dev = self::device();
        $tz = preg_match('#^[A-Za-z_]+(?:/[A-Za-z0-9_+\-]+){0,2}$#', $tz) ? $tz : '';
        $o = $pdo->prepare("SELECT id FROM " . Database::t('staff_mail_requests') . " WHERE staff_account_id = ? AND status = 'open' ORDER BY id DESC LIMIT 1"); $o->execute([(int) $s['id']]);
        if ($id = (int) $o->fetchColumn()) {
            $pdo->prepare('UPDATE ' . Database::t('staff_mail_requests') . ' SET name = ?, contact = ?, ip_hash = ?, device = ?, tz = ?, sends = sends + 1, updated_at = NOW() WHERE id = ?')->execute([$name, $c, $ip, $dev, $tz, $id]);
            StaffLogin::log($pdo, (int) $s['id'], 'mail_help', 'Asked again for help with the work email, from the sign-in page · ' . $dev);
        } else {
            $pdo->prepare('INSERT INTO ' . Database::t('staff_mail_requests') . ' (staff_account_id, name, contact, ip_hash, device, tz) VALUES (?, ?, ?, ?, ?, ?)')->execute([(int) $s['id'], $name, $c, $ip, $dev, $tz]);
            StaffLogin::log($pdo, (int) $s['id'], 'mail_help', 'Asked for help with the work email, from the sign-in page · ' . $dev);
        }
        $_SESSION['tv_staffmail_at'] = time();
        return 'Sent to the owners. One of them will contact you at ' . $c . ' to check it\'s you, then give you a new way in. Nothing changes on your login until then.';
    }

    public static function get(PDO $pdo, int $id): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('staff_mail_requests') . ' WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Open requests, newest first, each with its staff login (for Pulse::items). */
    public static function open(PDO $pdo): array
    {
        self::ensure($pdo);
        $out = [];
        foreach ($pdo->query("SELECT * FROM " . Database::t('staff_mail_requests') . " WHERE status = 'open' ORDER BY updated_at DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $s = StaffLogin::get($pdo, (int) $r['staff_account_id']);
            if (!$s) continue;
            $out[] = $r + ['staff' => $s];
        }
        return $out;
    }

    /** Pulse's row for one open request: [title, why]. */
    public static function row(array $r): array
    {
        $s = $r['staff'];
        return ['Can\'t get their work email: ' . $s['staff_id'] . ' · ' . $s['name'],
            'Asked from the sign-in page after the right staff ID and password. Reach them at ' . $r['contact'] . ' (not verified). Check it\'s them before changing anything.'];
    }

    /** Is the person looking an owner? [ok, why not] */
    public static function ownerCheck(PDO $pdo): array
    {
        $me = StaffLogin::inSession($pdo);
        if (!$me || $me['role'] !== 'owner') return [false, 'Only an owner can do this: it changes how someone signs in'];
        return [true, ''];
    }

    /**
     * The case's steps (Pulse::playbook): what's known first, then the three buttons, each confirmed first; greyed with the
     * reason where it can't work. $s is Pulse's step maker.
     */
    public static function steps(array $it, callable $s): array
    {
        $pdo = Database::connection();
        $r = $it['staffmail'] ?? null;
        if (!$r) return [$s('This request is closed', '', null)];
        $t = $r['staff'];
        [$own, $why] = self::ownerCheck($pdo);
        $email = (string) $t['email'];
        $last = self::when($t['last_sign_in_at'] ? (string) $t['last_sign_in_at'] : null);
        $ask = ['confirm' => 'Have you confirmed this is them?', 'danger' => true];
        $off = fn (string $w) => $ask + ['off' => $w];
        $mine = $own ? $ask : $off($why);
        require_once __DIR__ . '/CPanelMail.php';
        $boxWhy = '';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $boxWhy = 'This login has no work email yet: use Change work email';
        elseif (strtolower(substr(strrchr($email, '@'), 1)) !== StaffLogin::workDomain()) $boxWhy = 'Not one of our mailboxes (' . StaffLogin::workDomain() . ')';
        elseif (!CPanelMail::ready()) $boxWhy = 'cPanel isn\'t connected (CPANEL_HOST, CPANEL_USER, CPANEL_TOKEN in .env)';
        return [
            $s('Check it\'s them', 'Staff login: ' . $t['staff_id'] . ' · ' . $t['name'] . ' (' . explode(' (', (string) (StaffLogin::ROLES[$t['role']] ?? $t['role']))[0] . '). Work email now: ' . ($email !== '' ? $email : 'none')
                . '. Last sign-in: ' . $last . '. Name given: ' . $r['name'] . '. Contact given: ' . $r['contact'] . ' — not verified: anyone who knows their password could have sent this.'
                . ' Asked ' . self::when((string) $r['updated_at'], (string) $r['tz']) . ($r['device'] !== '' ? ' from ' . $r['device'] : '') . ((int) $r['sends'] > 1 ? ' (sent ' . (int) $r['sends'] . ' times)' : '')
                . '. Call or write to them there, or on a number you already have for them, before you press anything below.', null),
            $s('Change work email', 'For a new address (first.last@' . StaffLogin::workDomain() . '). Sign-in codes go there from now on; the old address is told.',
                ['form', 'sm_email', 'Change work email', [['email', 'New work email', 'email', '']], $mine]),
            $s('Reset the mailbox password', 'When the mailbox is ours but they can\'t sign in to it. A new password for ' . ($email ?: 'it') . ', shown to you once to pass on.',
                ['do', 'sm_mailbox', 'Reset the mailbox password', $boxWhy !== '' && $own ? $off($boxWhy) : $mine]),
            $s('New setup link', 'Ends their sessions and clears their password and authenticator app; they choose new ones with the link. Shown to you to hand over in person or by phone (it\'s also emailed to the work email, which they can\'t reach now).',
                ['do', 'sm_setup', 'New setup link', $mine]),
            $s('Close the request', 'When they\'re back in, or it wasn\'t them. What you write goes in their staff log.',
                ['form', 'sm_close', 'Close it', [['why', 'What happened', 'text', '']], $own ? [] : ['off' => $why]]),
        ];
    }

    /**
     * A button on the case. Returns ['message', 'once' => [label, value]|null shown to the owner one time, 'note' => for the
     * case's notes, 'close' => bool]. Pulse::manage writes the note and closes the case.
     */
    public static function act(PDO $pdo, int $id, string $what, array $a, int $uid): array
    {
        [$own, $why] = self::ownerCheck($pdo);
        if (!$own) throw new RuntimeException($why . '.');
        $me = StaffLogin::inSession($pdo);
        $r = self::get($pdo, $id);
        if (!$r || $r['status'] !== 'open') throw new RuntimeException('This request is closed already.');
        $t = StaffLogin::get($pdo, (int) $r['staff_account_id']);
        if (!$t || $t['status'] === 'ended') throw new RuntimeException('That staff login has ended.');
        $actor = (int) $me['id'];
        require_once __DIR__ . '/Mailer.php';
        switch ($what) {
            case 'sm_email':
                $old = (string) $t['email'];
                StaffLogin::setEmail($pdo, (int) $t['id'], (string) ($a['email'] ?? ''), $actor);
                $new = (string) StaffLogin::get($pdo, (int) $t['id'])['email'];
                if ($new === strtolower($old)) throw new RuntimeException('That\'s the work email it has now.');
                $told = self::tell($old, 'Your Traversence work email was changed',
                    "An owner ({$me['staff_id']}) changed the work email on staff login {$t['staff_id']} from $old to " . StaffLogin::mask($new) . ' on ' . date('M j, Y, g:i A T') . ", after a request from the sign-in page.\n\nSign-in codes go to the new address from now on. If you didn't ask for this, write to support@traversence.com at once.\n\nTraversence");
                StaffLogin::log($pdo, (int) $t['id'], 'mail_help', 'Work email changed from the help request (' . ($told ? 'the old address was told' : 'the old address couldn\'t be told') . ')', $actor);
                return ['message' => 'Work email changed to ' . $new . '. Sign-in codes go there now' . ($told ? ', and the old address was told.' : '.'), 'once' => null,
                    'note' => 'Changed the work email from ' . ($old ?: 'none') . ' to ' . $new . '. ' . ($told ? 'The old address was told.' : 'The old address couldn\'t be told.'), 'close' => false];
            case 'sm_mailbox':
                $email = strtolower((string) $t['email']);
                if (!filter_var($email, FILTER_VALIDATE_EMAIL) || substr(strrchr($email, '@'), 1) !== StaffLogin::workDomain()) throw new RuntimeException('Not one of our mailboxes.');
                require_once __DIR__ . '/CPanelMail.php';
                if (!CPanelMail::ready()) throw new RuntimeException('cPanel isn\'t connected, so the mailbox can\'t be reset from here.');
                $pw = self::password();
                CPanelMail::setPassword($email, $pw);
                self::tell($email, 'Your mailbox password was reset', "An owner ({$me['staff_id']}) reset the password of this mailbox on " . date('M j, Y, g:i A T') . ", after a request from the Traversence sign-in page. They'll give you the new one.\n\nIf you didn't ask for this, write to support@traversence.com at once.\n\nTraversence");
                StaffLogin::log($pdo, (int) $t['id'], 'mailbox', 'Mailbox password reset from the help request', $actor);
                return ['message' => 'Mailbox password reset. Pass it on to them; it isn\'t shown again. Webmail: ' . CPanelMail::webmail($email), 'once' => ['New password for ' . $email, $pw],
                    'note' => 'Reset the mailbox password of ' . $email . ' (shown once to the owner).', 'close' => false];
            case 'sm_setup':
                $res = StaffLogin::reset($pdo, (int) $t['id'], $actor);
                StaffLogin::log($pdo, (int) $t['id'], 'mail_help', 'New setup link made from the help request, shown to the owner to hand over', $actor);
                return ['message' => 'New setup link made: hand it to them yourself. It works for ' . StaffLogin::SETUP_HOURS . ' hours and once; their sessions have ended.', 'once' => ['Setup link for ' . $t['staff_id'], (string) $res['url']],
                    'note' => 'Made a new setup link and saw it to hand over. Their sessions ended; password and authenticator cleared.', 'close' => false];
            case 'sm_close':
                $w = mb_substr(trim((string) ($a['why'] ?? '')), 0, 280);
                if ($w === '') throw new RuntimeException('Write what happened, for their staff log.');
                $pdo->prepare("UPDATE " . Database::t('staff_mail_requests') . " SET status = 'done', outcome = ?, done_by = ?, done_at = NOW() WHERE id = ?")->execute([$w, $uid, $id]);
                StaffLogin::log($pdo, (int) $t['id'], 'mail_help', 'Help request closed: ' . $w, $actor);
                return ['message' => 'Closed. It\'s in their staff log.', 'once' => null, 'note' => 'Closed: ' . $w, 'close' => true];
        }
        throw new RuntimeException('That isn\'t something this case can do.');
    }

    /** A system email to $to (it costs nothing; CLAUDE.md "No income, no expense"). False when it couldn't go. */
    private static function tell(string $to, string $subject, string $text): bool
    {
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
        try { Mailer::send($to, $subject, $text); return true; } catch (Throwable $e) { error_log('staff mail help: ' . $e->getMessage()); return false; }
    }

    /** A moment in the zone it's labelled in: $tz (the device's, stored with it) or the site's own. "Nov 22, 4:42 AM MST" */
    public static function when(?string $at, string $tz = ''): string
    {
        if (!$at || !strtotime($at)) return 'never';
        try {
            $d = new DateTime($at);
            if ($tz !== '') $d->setTimezone(new DateTimeZone($tz));
            return $d->format('M j, Y, g:i A T');
        } catch (Throwable) { return date('M j, Y, g:i A T', strtotime($at)); }
    }

    private static function password(): string
    {
        $a = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $p = '';
        for ($i = 0; $i < 16; $i++) $p .= $a[random_int(0, strlen($a) - 1)];
        return substr($p, 0, 4) . '-' . substr($p, 4, 4) . '-' . substr($p, 8, 4) . '-' . substr($p, 12, 4) . '!7';
    }

    private static function device(): string
    {
        $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $os = preg_match('/iPhone|iPad/i', $ua) ? 'iPhone/iPad' : (preg_match('/Android/i', $ua) ? 'Android' : (preg_match('/Windows/i', $ua) ? 'Windows' : (preg_match('/Mac OS/i', $ua) ? 'Mac' : 'another device')));
        $br = preg_match('/Edg\//', $ua) ? 'Edge' : (preg_match('/Chrome\//', $ua) ? 'Chrome' : (preg_match('/Firefox\//', $ua) ? 'Firefox' : (preg_match('/Safari\//', $ua) ? 'Safari' : 'a browser')));
        return "$br on $os";
    }
}
