<?php
// app/ui/social-buttons.php — the row of sign-in buttons under the email form (decisions/0090): Google, Apple, Microsoft
// and Facebook, each shown only when it's set up. One white button each, its company's own logo and its words beside it
// ("Continue with Google"; screens proposal A9, Jason 2026-11-22: logos alone left people guessing), stacked full width.
declare(strict_types=1);

require_once __DIR__ . '/google-button.php';
require_once __DIR__ . '/../lib/SocialAuth.php';

/** The providers that are on, in order: [key => [label, href]]. */
function tv_social_list(string $next = ''): array
{
    $q = GoogleAuth::safeNext($next) !== '' ? '&next=' . rawurlencode($next) : '';
    $out = [];
    if (GoogleAuth::enabled()) $out['google'] = ['Google', '/api/auth/google.php?start=1' . $q];
    foreach (array_keys(SocialAuth::PROVIDERS) as $p) if (SocialAuth::enabled($p)) $out[$p] = [SocialAuth::label($p), '/api/auth/' . $p . '.php?start=1' . $q];
    return $out;
}

/** "or" and the row of tiles; '' when none is on. $verb: "Continue with" (sign in) or "Sign up with". */
function tv_social_buttons(string $verb = 'Continue with', string $next = ''): string
{
    $list = tv_social_list($next);
    if (!$list) return '';
    $logo = [
        'google' => '<svg width="26" height="26" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>',
        'apple' => '<svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true"><path fill="#000" d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.744.9-1.99 1.57-2.987 1.57-.12 0-.23-.02-.3-.03-.01-.06-.04-.22-.04-.39 0-1.15.572-2.27 1.206-2.98.804-.94 2.142-1.64 3.248-1.68.03.13.05.28.05.43zm4.565 15.71c-.03.07-.463 1.58-1.518 3.12-.945 1.34-1.94 2.71-3.43 2.71-1.517 0-1.9-.88-3.63-.88-1.698 0-2.302.91-3.67.91-1.377 0-2.332-1.26-3.428-2.8-1.287-1.82-2.323-4.63-2.323-7.28 0-4.28 2.797-6.55 5.552-6.55 1.448 0 2.675.95 3.6.95.865 0 2.222-1.01 3.902-1.01.613 0 2.886.06 4.374 2.19-.13.09-2.383 1.37-2.383 4.19 0 3.26 2.854 4.42 2.955 4.45z"/></svg>',
        'microsoft' => '<svg width="24" height="24" viewBox="0 0 21 21" aria-hidden="true"><rect x="1" y="1" width="9" height="9" fill="#F25022"/><rect x="11" y="1" width="9" height="9" fill="#7FBA00"/><rect x="1" y="11" width="9" height="9" fill="#00A4EF"/><rect x="11" y="11" width="9" height="9" fill="#FFB900"/></svg>',
        'facebook' => '<svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true"><path fill="#1877F2" d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/><path fill="#fff" d="M16.671 15.563l.532-3.49h-3.328v-2.25c0-.949.465-1.874 1.956-1.874h1.513V4.996s-1.374-.235-2.686-.235c-2.741 0-4.533 1.662-4.533 4.669v2.643H7.078v3.49h3.047V24a12.2 12.2 0 003.75 0v-8.437z"/></svg>',
    ];
    $h = '<div class="tv-or" style="display:flex;align-items:center;gap:.6rem;margin:1.1rem 0 .9rem;color:#5C4632;font:600 .8rem/1 var(--tv-font-head,Georgia,serif)"><span style="flex:1;height:1px;background:#B9A57A"></span>or<span style="flex:1;height:1px;background:#B9A57A"></span></div>'
       . '<div class="tv-social" style="display:flex;flex-direction:column;gap:.5rem">';
    foreach ($list as $k => [$label, $href]) {
        $name = $verb . ' ' . $label;
        $h .= '<a href="' . htmlspecialchars($href, ENT_QUOTES) . '" class="tv-sbtn"'
            . ' style="display:flex;align-items:center;justify-content:center;gap:.65rem;min-height:2.9rem;padding:.4rem .9rem;background:#fff;border:1px solid #CBB98D;border-radius:.6rem;box-shadow:0 1px 2px rgba(62,43,31,.08);color:#3E2B1F;font:600 .92rem/1.2 system-ui,sans-serif;text-decoration:none">'
            . '<span style="display:flex;flex:none;width:26px;justify-content:center">' . $logo[$k] . '</span><span>' . htmlspecialchars($name) . '</span></a>';
    }
    return $h . '</div><style>.tv-sbtn:hover,.tv-sbtn:focus-visible{border-color:#92400E;box-shadow:0 0 0 3px rgba(143,188,168,.45)!important;outline:none}</style>';
}
