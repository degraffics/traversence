<?php
// admin/sources.php — the websites that confirm places for the directory (decisions/0045)
//
// Filled by the crawler's second look: every website that showed a place's name with its address or phone.
// A person decides what each is for: "Read regularly" (the worker reads it and follows its links),
// "Cite only" (counts as a reference, never read in bulk), or "Ignore" (doesn't count at all). Sources can
// also be added by hand. Admin-only, checked server-side; POSTs carry the session CSRF token.

declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';   // Admin → Crawler → Sources (decisions/0046)

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
if (!is_file(__DIR__ . '/../../app/lib/crawler/Sources.php')) {
    tv_page_start('Sources');
    echo '<p class="text-sm">Missing on the server: <code>app/lib/crawler/Sources.php</code>. Upload it from the package, then reload.</p>';
    tv_page_end();
    exit;
}
require_once __DIR__ . '/../../app/lib/crawler/Sources.php';
require_once __DIR__ . '/../../app/lib/OutsideServices.php';   // each standing source links to its service's card, and the card to its row here (#src-…)
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$hasTable = Sources::tableExists($pdo);
$filter = (string) ($_GET['show'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $hasTable) {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'set') {
            Sources::update($pdo, (int) ($_POST['id'] ?? 0), ($_POST['status'] ?? '') !== '' ? (string) $_POST['status'] : null,
                ($_POST['kind'] ?? '') !== '' ? (string) $_POST['kind'] : null);
            $_SESSION['src_flash'] = [true, 'Saved.'];
        } elseif ($action === 'add') {
            $host = Sources::add($pdo, (string) ($_POST['url'] ?? ''), (string) ($_POST['kind'] ?? ''), (string) ($_POST['label'] ?? ''));
            $_SESSION['src_flash'] = [true, "Added $host to the sources read regularly."];
        } elseif ($action === 'rules') {   // the source register (decisions/0133): its licence decides what we may do with it
            if (!Sources::rulesReady($pdo)) throw new InvalidArgumentException('The database update for source rules hasn\'t run yet (System Configuration → Database updates).');
            Sources::setRules($pdo, (string) ($_POST['host'] ?? ''), $_POST, (int) (Auth::currentUserId() ?? 0));
            $_SESSION['src_flash'] = [true, 'Saved the rules for ' . Sources::host('https://' . preg_replace('#^https?://#i', '', (string) ($_POST['host'] ?? ''))) . '.'];
        } elseif ($action === 'harvest') {
            $r = Sources::harvest($pdo);
            $_SESSION['src_flash'] = [true, "Checked every crawled listing: {$r['sources']} website" . ($r['sources'] === 1 ? '' : 's') . " confirmed places, {$r['added']} new to the list."];
        }
    } catch (InvalidArgumentException $e) {
        $_SESSION['src_flash'] = [false, $e->getMessage()];
    }
    header('Location: ' . strtok((string) $_SERVER['REQUEST_URI'], '#'), true, 303);
    exit;
}
$flash = $_SESSION['src_flash'] ?? null;
unset($_SESSION['src_flash']);

tv_crawler_start('sources', 'Sources', $pdo);
?>
<style>
  .sr-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;box-shadow:0 4px 6px -1px rgba(0,0,0,.08);padding:1rem;margin-top:1.25rem;max-width:64rem}
  .sr-t{width:100%;font-size:.85rem;border-collapse:collapse;margin-top:.5rem}
  .sr-t td,.sr-t th{padding:.4rem .6rem .4rem 0;border-top:1px solid rgba(203,185,141,.45);vertical-align:top;text-align:left}
  .sr-t th{font-weight:400;font-size:.7rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355;border-top:0}
  .sr-btn{background:#D97706;color:#fff;font-weight:600;border-radius:.75rem;padding:.45rem 1rem}
  .sr-btn2{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;font-weight:600;border-radius:.75rem;padding:.4rem .9rem}
  .sr-lnk{color:#B45309;text-decoration:underline;font-size:.8rem;background:none;cursor:pointer}
  .sr-in{background:#FFFBF2;border:1px solid rgba(203,185,141,.8);border-radius:.5rem;padding:.3rem .5rem;font-size:.85rem}
  .sr-tab{font-size:.85rem;padding:.25rem .7rem;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;margin-right:.3rem;display:inline-block}
  .sr-tab.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .sr-st{display:inline-block;margin:0 .15rem .2rem 0}
  .sr-st button{font-size:.75rem;border:1px solid #CBB98D;border-radius:999px;padding:.1rem .55rem;background:#FFFBF2}
  .sr-st button.on{background:#166534;color:#fff;border-color:#166534}
  .sr-st button.on.ig{background:#991B1B;border-color:#991B1B}
  .sr-st button.on.co{background:#5C4632;border-color:#5C4632}
  .sr-bar{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem}
  /* Phones: each website becomes a small stacked block instead of a wide table row. */
  @media (max-width: 700px) {
    .sr-t,.sr-t tbody,.sr-t tr,.sr-t td{display:block;width:100%}
    .sr-t tr:first-child{display:none}
    .sr-t tr{border-top:1px solid rgba(203,185,141,.45);padding:.5rem 0}
    .sr-t td{border:0;padding:.15rem 0}
    .sr-in{max-width:100%}
  }
</style>

<div>
  <p class="text-sm text-[#5C4632] mt-1 max-w-2xl">
    Websites that have confirmed places for the directory: each showed a place's name with its street address or phone.
    Mark the good ones <strong>Read regularly</strong> (community and government directories, chambers, tourism sites) and the
    crawler will read them and follow their links, so it needs fewer paid searches. Commercial directories and social media start as
    <strong>Cite only</strong>: they still count as references, but their terms forbid copying them in bulk. <strong>Ignore</strong> stops a
    website counting at all. (ADR 0045)
  </p>
</div>

<?php if ($flash): ?>
  <div class="sr-card tv-bleed" style="background:<?= $flash[0] ? '#ECFDF5' : '#FEF2F2' ?>;border-color:<?= $flash[0] ? '#6EE7B7' : '#FCA5A5' ?>" role="status"><?= tv_e($flash[1]) ?></div>
<?php endif; ?>

<?php if (!$hasTable): ?>
  <div class="sr-card tv-bleed"><p class="text-sm" data-tv-status="info" data-tv-label="Not ready:">The database update for sources hasn't run yet: it runs within the hour, or open System Configuration → Database updates.</p></div>
<?php tv_crawler_end(); exit; endif;
$counts = Sources::counts($pdo);
$rows = Sources::all($pdo, $filter);
$rulesOn = Sources::rulesReady($pdo);
// one source's rules, shown in words with a form to change them (decisions/0133: the licence decides the use)
$rulesCell = function (string $host, string $kind = '') use ($pdo, $csrf, $rulesOn): string {
    $r = Sources::rules($pdo, $host, $kind);
    $h = '<span class="text-xs">' . tv_e(Sources::LICENCES[$r['licence']] ?? $r['licence']) . ' · <b>' . tv_e(explode(' (', Sources::USES[$r['use_rule']] ?? $r['use_rule'])[0]) . '</b>'
       . ($r['terms_checked_at'] ? ' · terms read ' . tv_e(date('M j, Y', strtotime((string) $r['terms_checked_at']))) : ' · terms not checked yet') . ($r['from'] === 'kind' ? ' · from its kind' : '') . '</span>';
    if (!$rulesOn) return $h;
    $o = fn (array $list, string $cur) => implode('', array_map(fn ($k, $v) => '<option value="' . $k . '"' . ($k === $cur ? ' selected' : '') . '>' . tv_e($v) . '</option>', array_keys($list), $list));
    return $h . '<details class="sr-rules"><summary class="sr-lnk">Licence and use</summary><form method="post" class="sr-rf">'
        . '<input type="hidden" name="csrf" value="' . tv_e($csrf) . '"><input type="hidden" name="action" value="rules"><input type="hidden" name="host" value="' . tv_e($host) . '">'
        . '<label>Licence<select class="sr-in" name="licence">' . $o(Sources::LICENCES, $r['licence']) . '</select></label>'
        . '<label>What we may do<select class="sr-in" name="use_rule">' . $o(Sources::USES, $r['use_rule']) . '</select></label>'
        . '<label>Credit line<input class="sr-in" name="credit_line" value="' . tv_e((string) $r['credit_line']) . '" placeholder="When the licence asks for one"></label>'
        . '<label>Limits<input class="sr-in" name="limits" value="' . tv_e((string) $r['limits']) . '" placeholder="e.g. 50 requests a minute"></label>'
        . '<label>Read again every<input class="sr-in" type="number" min="0" max="3650" name="refresh_days" value="' . tv_e((string) ($r['refresh_days'] ?? '')) . '" placeholder="days"></label>'
        . '<label>Terms page<input class="sr-in" name="terms_url" value="' . tv_e((string) $r['terms_url']) . '" placeholder="https://…/terms"></label>'
        . '<label class="sr-chk"><input type="checkbox" name="checked" value="1"> I read its terms today</label>'
        . '<button class="sr-btn" type="submit">Save</button></form></details>';
};
?>
<style>
  .sr-rules{margin-top:.25rem}.sr-rules summary{cursor:pointer}
  .sr-rf{display:grid;grid-template-columns:repeat(auto-fit,minmax(12rem,1fr));gap:.5rem .8rem;margin-top:.4rem;align-items:end}
  .sr-rf label{display:grid;gap:.15rem;font-size:.75rem;color:#5C4632}.sr-rf .sr-in{width:100%}.sr-chk{display:flex!important;gap:.35rem;align-items:center}
</style>

<section class="sr-card tv-bleed">
  <h2 class="font-serif font-bold text-lg">The sources the engine runs on</h2>
  <p class="text-sm mt-1">Each source's licence decides what we may do with what it says: store its facts, show it with credit, keep only a pointer,
    cite it, or use it only as evidence that confirms (decisions/0133). These are the standing rules; change one here when its terms change, and tick
    that you read them.</p>
  <table class="sr-t">
    <tr><th>Source</th><th>What we take</th><th>Limits</th><th>Licence and use</th></tr>
    <?php foreach (Sources::STANDING as $host => [$name, $type, , , $take, $credit, $limits, $days, $terms]): $svc = OutsideServices::serviceOfHost($host); ?>
    <tr id="<?= tv_e(OutsideServices::sourceAnchor($host)) ?>">
      <td><a class="sr-lnk" style="font-size:.9rem" href="<?= tv_e($terms) ?>" target="_blank" rel="noopener nofollow" title="Its terms"><?= tv_e($name) ?></a><br><span class="text-xs text-[#8A7355]"><?= tv_e($type) ?> · <?= tv_e($host) ?></span>
        <?php if ($svc !== ''): ?><br><a class="sr-lnk" href="/admin/config/services#svc-<?= tv_e($svc) ?>" title="Everything about it: whether it's working, its cost, its settings and who to ask">Its service card</a><?php endif; ?></td>
      <td class="text-xs"><?= tv_e($take) ?><?= $credit !== '' ? '<br><span class="text-[#8A7355]">Credit: ' . tv_e($credit) . '</span>' : '' ?></td>
      <td class="text-xs"><?= tv_e($limits) ?><?= $days ? '<br><span class="text-[#8A7355]">read again every ' . (int) $days . ' days</span>' : '' ?></td>
      <td><?= $rulesCell($host) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</section>

<section class="sr-card tv-bleed">
  <div class="sr-bar">
    <a class="sr-tab <?= $filter === '' ? 'on' : '' ?>" href="?">All <?= array_sum($counts) ?></a>
    <?php foreach (Sources::STATUSES as $k => $label): ?>
      <a class="sr-tab <?= $filter === $k ? 'on' : '' ?>" href="?show=<?= $k ?>"><?= tv_e($label) ?> <?= $counts[$k] ?></a>
    <?php endforeach; ?>
    <form method="post" class="ml-auto"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="action" value="harvest">
      <button class="sr-btn2" type="submit" title="Recount from every crawled listing, and add websites found before this list existed">Recount from listings</button></form>
  </div>

  <?php if (!$rows): ?>
    <p class="text-sm mt-3">None yet. Press <strong>Recount from listings</strong> to collect the websites the crawler has already found; new ones are added as it works.</p>
  <?php else: ?>
  <table class="sr-t">
    <tr><th>Website</th><th>Kind</th><th>Confirmed</th><th>What the crawler does with it</th><th>Licence and use</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><a class="sr-lnk" style="font-size:.9rem" href="<?= tv_e((string) ($r['sample_url'] ?: $r['home_url'])) ?>" target="_blank" rel="noopener nofollow"><?= tv_e($r['host']) ?></a>
        <?php if ($r['label']): ?><br><span class="text-xs text-[#8A7355]"><?= tv_e(mb_strimwidth((string) $r['label'], 0, 70, '…')) ?></span><?php endif; ?>
        <?php if ($r['added_by'] === 'admin'): ?><br><span class="text-xs text-[#8A7355]">added by hand</span><?php endif; ?>
        <?php if ((int) ($r['borne_out'] ?? 0) + (int) ($r['shown_wrong'] ?? 0) > 0): $w = Sources::trustWeight($pdo, (string) $r['host']); ?><br><span class="text-xs text-[#8A7355]" title="decisions/0157 §5: how much its word counts toward the two sources">Its record: <?= (int) $r['borne_out'] ?> borne out, <?= (int) $r['shown_wrong'] ?> shown wrong · counts <?= $w >= 1.5 ? 'more' : ($w <= 0 ? 'not at all' : ($w < 1 ? 'less' : 'as usual')) ?></span><?php endif; ?>
        <?php if (in_array(($r['judged_by'] ?? ''), ['crawler', 'claude'], true)): ?><br><span class="text-xs text-[#8A7355]" title="<?= tv_e((string) ($r['judged_why'] ?? '')) ?>"><b>Set by <?= ($r['judged_by'] ?? '') === 'claude' ? 'Claude, from its terms' : 'the crawler' ?>:</b> <?= tv_e(mb_strimwidth((string) ($r['judged_why'] ?? ''), 0, 120, '…')) ?> Change it and your call stands.</span>
        <?php elseif ($r['status'] === 'suggested' && !empty($r['about'])): ?><br><span class="text-xs text-[#8A7355]">It says: <?= tv_e(mb_strimwidth((string) $r['about'], 0, 110, '…')) ?></span><?php endif; ?></td>
      <td>
        <form method="post"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="action" value="set"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
          <select name="kind" class="sr-in" style="font-size:.8rem" onchange="this.form.submit()">
            <?php foreach (Sources::KINDS as $k => $label): ?><option value="<?= $k ?>" <?= $r['kind'] === $k ? 'selected' : '' ?>><?= tv_e($label) ?></option><?php endforeach; ?>
          </select><noscript><button class="sr-lnk" type="submit">Save</button></noscript>
        </form></td>
      <td><?= (int) $r['confirmations'] ?> listing<?= (int) $r['confirmations'] === 1 ? '' : 's' ?>
        <?php if ($r['last_listing']): ?><br><span class="text-xs text-[#8A7355]">latest: <?= tv_e(mb_strimwidth((string) $r['last_listing'], 0, 40, '…')) ?></span><?php endif; ?></td>
      <td>
        <?php foreach (['read' => ['Read regularly', ''], 'cite_only' => ['Cite only', 'co'], 'ignore' => ['Ignore', 'ig']] as $st => [$label, $cls]): ?>
          <form method="post" class="sr-st"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="action" value="set">
            <input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="status" value="<?= $st ?>">
            <button type="submit" class="<?= $r['status'] === $st ? 'on ' . $cls : '' ?>"><?= $label ?></button></form>
        <?php endforeach; ?>
        <?php if ($r['status'] === 'suggested'): ?><br><span class="text-xs text-amber-800">waiting for you</span><?php endif; ?>
        <?php if ($r['status'] === 'read'): ?><br><span class="text-xs text-[#8A7355]"><?= $r['last_read_at'] ? 'last read ' . tv_e(substr((string) $r['last_read_at'], 0, 10)) : 'not read yet' ?></span><?php endif; ?>
      </td>
      <td><?= $rulesCell((string) $r['host'], (string) $r['kind']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</section>

<section class="sr-card tv-bleed">
  <h2 class="font-serif font-bold text-lg">Add a source</h2>
  <p class="text-sm mt-1">A page that lists local places with their addresses or phones: a county or city services page, a chamber member
    directory, a tribal government's public services page, a regional resource guide. It is read regularly.</p>
  <form method="post" class="flex flex-wrap gap-2 mt-2 items-end">
    <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="action" value="add">
    <label class="text-sm">Web address<br><input class="sr-in" name="url" required placeholder="https://business.thegallupchamber.com/list" style="width:22rem;max-width:100%"></label>
    <label class="text-sm">Kind<br><select class="sr-in" name="kind"><option value="">Guess from the address</option>
      <?php foreach (Sources::KINDS as $k => $label): ?><option value="<?= $k ?>"><?= tv_e($label) ?></option><?php endforeach; ?></select></label>
    <label class="text-sm">Note (optional)<br><input class="sr-in" name="label" placeholder="Gallup-McKinley County Chamber directory" style="width:16rem;max-width:100%"></label>
    <button class="sr-btn" type="submit">Add</button>
  </form>
</section>
<script>(function(){var t=location.hash&&document.getElementById(location.hash.slice(1));if(!t||t.tagName!=='TR')return;t.style.boxShadow='inset 0 0 0 3px #8FBCA8';setTimeout(function(){t.scrollIntoView({block:'center'});},50);})();</script>
<?php tv_crawler_end();
