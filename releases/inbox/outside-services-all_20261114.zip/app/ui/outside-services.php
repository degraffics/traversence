<?php
// app/ui/outside-services.php — System Configuration → Outside services and → Settings, in the new admin (decisions/0152).
// Outside services: one card per company (app/lib/OutsideServices.php), with what we use it for, each part checked, this
// month's use and cost, its pricing and fees, its .env names (never values) and its links; the month's total on top.
// Settings: what's about the site itself (the settings changed here, publishing, privacy, the site, the server).
// Both replace admin/settings.php (archived) and the Services & usage page of decisions/0133, keeping all they showed.
declare(strict_types=1);

require_once __DIR__ . '/../lib/OutsideServices.php';
require_once __DIR__ . '/../lib/Services.php';
require_once __DIR__ . '/../admin/sections.php';

function tv_os_money(float $d): string { return '$' . number_format($d, $d > 0 && $d < 1 ? 3 : 2); }
function tv_os_size(int $b): string { return $b >= 1073741824 ? number_format($b / 1073741824, 2) . ' GB' : number_format($b / 1048576, 1) . ' MB'; }

/** A company's flat plan this month: [name, plan, usd or null when not set, note]. */
function tv_os_plan(string $key): ?array
{
    if ($key === '') return null;
    if (isset(Services::PLANS[$key])) {
        [$name, $plan, $usd, $env, $note] = Services::PLANS[$key];
        $v = getenv($env); $usd = $v !== false && $v !== '' && is_numeric($v) ? (float) $v : (float) $usd;
        return [$name, $plan, $usd > 0 ? $usd : null, $note, $env];
    }
    if ($key === 'bluehost') { $v = getenv('BLUEHOST_USD_MONTH'); return ['Bluehost', 'Hosting', $v !== false && $v !== '' && is_numeric($v) && (float) $v > 0 ? (float) $v : null, 'The web hosting plan.', 'BLUEHOST_USD_MONTH']; }
    return null;
}

function tv_outside_services(PDO $pdo): string
{
    $e = 'tv_w_e';
    require_once __DIR__ . '/../admin/Access.php';
    [$canNotes, $whyNotes] = Access::can('config.services.notes', ['min' => 'executive', 'depts' => []]);   // owners and executives
    $csrf = (string) ($_SESSION['csrf_token'] ?? ''); $msg = ''; $saved = '';
    if ($canNotes && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !empty($_POST['svc_notes']) && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        try { OutsideServices::saveNotes($pdo, (string) $_POST['svc_notes'], (array) ($_POST['note'] ?? [])); $saved = (string) $_POST['svc_notes'];
              $msg = '<p data-tv-flash="ok">' . $e(OutsideServices::COMPANIES[$saved][0] ?? 'The service') . ': how to sign in is saved.</p>'; }
        catch (Throwable $x) { $msg = '<p data-tv-flash="error">' . $e($x instanceof InvalidArgumentException ? $x->getMessage() : 'That didn\'t save. Try again.') . '</p>'; $saved = (string) $_POST['svc_notes']; }
    }
    $use = []; try { foreach (Services::all($pdo) as $s) $use[$s['key']] = $s; } catch (Throwable) {}
    $cards = []; $plansUsd = 0.0; $usageUsd = 0.0; $unpriced = [];
    foreach (OutsideServices::COMPANIES as $k => [$name, $what, $pricing, $links, $usageKeys, $planKey]) {
        $parts = []; try { $parts = OutsideServices::parts($pdo, $k); } catch (Throwable $x) { $parts = [['Check', 'Couldn\'t check: ' . $x->getMessage(), 'bad', '', '']]; }
        $bad = array_filter($parts, fn ($p) => $p[2] === 'bad');
        $b = '<p class="os-what">' . $e($what) . '</p>';
        // sign in, first and on one line (Jason, 2026-11-11: "I really need login and passwords with where to sign in links"; "I dont
        // like how much space the how to sign in is taking up"): the company's sign-in page, the login in 1Password (its private
        // link: the password stays in 1Password, decisions/0155), who to sign in as and the second step; ✎ opens the fields.
        $login = $k === 'aws' && trim((string) (getenv('AWS_CONSOLE_URL') ?: '')) !== '' ? trim((string) getenv('AWS_CONSOLE_URL')) : (OutsideServices::LOGIN[$k] ?? '');   // Amazon: the account's own sign-in link when set
        $nt = $canNotes ? OutsideServices::notes($pdo, $k) : []; $vault = OutsideServices::vaultLink((string) ($nt['vault'] ?? ''));
        $bits = array_values(array_filter([(string) ($nt['account'] ?? ''), (string) ($nt['how'] ?? ''), (string) ($nt['step'] ?? ''), ($nt['who'] ?? '') !== '' ? 'held by ' . $nt['who'] : '']));
        $b .= '<div class="os-sign">' . ($login !== '' ? '<a class="ak-b go" href="' . $e($login) . '" target="_blank" rel="noopener">Sign in ↗</a>' : '')
            . ($canNotes ? ($vault !== '' ? '<a class="ak-b" href="' . $e($vault) . '" target="_blank" rel="noopener" title="Opens this login in your 1Password: the password stays there">1Password ↗</a>' : '')
                . '<details class="os-ed"' . ($saved === $k ? ' open' : '') . '><summary title="Edit how to sign in" aria-label="Edit how to sign in">✎</summary><form method="post" class="os-notes"><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="svc_notes" value="' . $e($k) . '">'
                . implode('', array_map(fn ($f, $fd) => '<label><span>' . $e($fd[0]) . '</span><input class="ak-in" name="note[' . $f . ']" value="' . $e((string) ($nt[$f] ?? '')) . '" maxlength="200" placeholder="' . $e($fd[1]) . '" spellcheck="false" autocomplete="off"></label>', array_keys(OutsideServices::NOTE_FIELDS), OutsideServices::NOTE_FIELDS))
                . '<p class="os-note">The password stays in 1Password: paste the login\'s private link, never the password. A password, key or code typed here is refused.</p><button class="ak-b go">Save</button></form></details>'
                . '<span class="os-signt">' . ($bits ? $e(implode(' · ', $bits)) : '<span class="os-not">' . (!empty($nt['known']) ? '' : 'No sign-in note yet') . '</span>') . (!empty($nt['known']) ? ' <span class="os-not">(from the decisions: ✎ to confirm)</span>' : '') . '</span>'
              : '<span class="os-signt os-not">Sign-in notes: ' . $e($whyNotes) . '</span>')
            . '</div>';
        // each part, checked
        foreach ($parts as $p) {
            $tone = $p[2] === 'ok' ? 'ok' : ($p[2] === 'bad' ? 'bad' : 'info');
            $b .= '<div class="os-part"><p data-tv-status="' . $tone . '" data-tv-label="' . $e($p[0]) . ':">' . $e($p[1]) . '</p>'
                . (($p[4] ?? '') !== '' || ($p[3] ?? '') !== '' ? '<small>' . $e((string) ($p[4] ?? '')) . (($p[3] ?? '') !== '' ? ' <code>' . $e($p[3]) . '</code>' : '') . '</small>' : '') . '</div>';
            if (($p[5] ?? '') === 'storage') {
                [$n, $bytes, $vn, $vb] = OutsideServices::stored($pdo);
                $b .= '<p class="os-line">Stored: <b>' . number_format($n) . ' photos and videos, ' . tv_os_size($bytes) . '</b>' . ($vn ? ' (' . number_format($vn) . ' videos, ' . tv_os_size($vb) . ')' : '') . '. Business files, proofs and order files are counted in Cloudflare\'s own numbers (Metrics on the bucket). Views and plays aren\'t counted by the site.</p>';
                // the files from before object storage: moved off the server a batch at a time (decisions/0123)
                $b .= '<div class="os-line" id="tv-s3move"><p data-t>Checking for files still on the server…</p><button type="button" class="ak-b go" style="display:none">Move files</button></div>';
            }
        }
        // is it working, from the site's and the crawler's own logs (Jason, 2026-11-13: "everything pertaining to that service")
        $work = []; try { $work = OutsideServices::working($pdo, $k); } catch (Throwable $x) {}
        if ($work) {
            $b .= '<h3 class="os-h">Is it working</h3>';
            foreach ($work as [$wl, $ws, $wt, $wu]) {
                if ($wt === 'bad') $bad[] = $wl;
                $b .= '<div class="os-part"><p data-tv-status="' . ($wt === 'ok' ? 'ok' : ($wt === 'bad' ? 'bad' : 'info')) . '" data-tv-label="' . $e($wl) . ':">' . $e($ws)
                    . ($wu !== '' ? ' <a class="os-go" href="' . $e($wu) . '"' . (str_starts_with($wu, '/') ? '' : ' target="_blank" rel="noopener"') . '>' . (str_starts_with($wu, '/') ? 'Open' : 'Read it ↗') . '</a>' : '') . '</p></div>';
            }
        }
        // what's set in another section: shown here as it stands, changed there ("linked [where it] is controlled by another section")
        $ctl = []; try { $ctl = OutsideServices::controlled($pdo, $k); } catch (Throwable $x) {}
        if ($ctl) {
            $b .= '<h3 class="os-h">Set in other sections</h3>';
            foreach ($ctl as [$cl, $cs, $cu]) $b .= '<p class="os-line"><a class="os-go" href="' . $e($cu) . '">' . $e($cl) . '</a>: ' . $e($cs) . '</p>';
        }
        // what we call: its addresses (the admin search finds the card by them; the site audit's R12 checks the code against them)
        if ($hs = OutsideServices::HOSTS[$k] ?? []) $b .= '<p class="os-note">Called at: ' . implode(', ', array_map(fn ($x) => '<code>' . $e($x) . '</code>', $hs)) . '</p>';
        // what it costs
        $cost = '';
        if ($pl = tv_os_plan($planKey)) {
            if ($pl[2] !== null) { $plansUsd += $pl[2]; $cost .= '<p class="os-line">Plan: <b>' . $e($pl[1]) . ', ' . tv_os_money($pl[2]) . ' a month</b>. ' . $e($pl[3]) . '</p>'; }
            else { $unpriced[] = $name; $cost .= '<p data-tv-status="info" data-tv-label="Plan price not set:">Set it in Settings (' . $e($pl[0]) . ' plan, a month) so it counts in the monthly total. <code>' . $e($pl[4]) . '</code></p>'; }
        }
        foreach ($usageKeys as $uk) if (isset($use[$uk])) {
            $s = $use[$uk]; $usageUsd += (float) $s['cost'];
            $line = $s['money'] ? tv_os_money((float) $s['used']) . ' of ' . tv_os_money((float) $s['cap']) : number_format((float) $s['used']) . ($s['cap'] ? ' of ' . number_format((float) $s['cap']) : '') . ' ' . $s['unit'];
            $cost .= '<p data-tv-status="' . $s['tone'] . '" data-tv-label="' . ($s['pct'] >= 100 ? 'Stopped for the month:' : ($s['pct'] >= 80 ? 'Getting close:' : $e($s['name']) . ' this month:')) . '">' . $e($line)
                . ($s['cap'] ? ' (' . $s['pct'] . '%)' : '') . ' · ' . number_format((float) $s['today'], $s['money'] ? 2 : 0) . ' today · at this pace ' . $e(Services::fmt($s, $s['projected_units'])) . ' by the month\'s end'
                . (!$s['money'] && $s['rate'] > 0 ? ', about ' . tv_os_money((float) $s['projected']) . ' (' . tv_os_money((float) $s['cost']) . ' so far)' : '') . '.</p><p class="os-note">' . $e($s['note']) . '</p>';
        }
        $free = str_starts_with($pricing, 'Free ($0)');
        $b .= '<h3 class="os-h">What it costs</h3>' . ($cost !== '' ? $cost : ($free ? '<p class="os-line"><b>$0</b>: free, within its usage rules below.</p>' : '<p class="os-line">No use counted by the site; see its own billing.</p>')) . '<p class="os-note">' . $e($pricing) . '</p>';
        // its settings changed here (the rest stay in .env: the names under each part above)
        if ($mine = OutsideServices::settingsOf($k)) $b .= '<h3 class="os-h">Its settings</h3>' . tv_os_env_rows($mine);
        // where it's set up in our admin, then the company's own pages
        if ($in = OutsideServices::linked($k)) {
            $b .= '<h3 class="os-h">In our admin</h3><div class="os-links">';
            foreach ($in as [$lt, $lu]) $b .= '<a class="ak-b" href="' . $e($lu) . '">' . $e($lt) . '</a>';
            $b .= '</div><h3 class="os-h">On ' . $e($name) . '</h3>';
        }
        $b .= '<div class="os-links">';
        foreach ($links as [$lt, $lu]) { $u = OutsideServices::link($lu); $ext = !str_starts_with($u, '/');
            $b .= '<a class="ak-b" href="' . $e($u) . '"' . ($ext ? ' target="_blank" rel="noopener"' : '') . '>' . $e($lt) . ($ext ? ' ↗' : '') . '</a>'; }
        $b .= '</div>';
        // its terms and where to reach it or its community when something's wrong
        if ($ct = OutsideServices::CONTACT[$k] ?? []) {
            $b .= '<h3 class="os-h">Terms and who to ask</h3><div class="os-links">';
            foreach ($ct as [$lt, $lu]) $b .= '<a class="ak-b" href="' . $e($lu) . '" target="_blank" rel="noopener">' . $e($lt) . ' ↗</a>';
            $b .= '</div>';
        }
        $on = OutsideServices::inUse($parts);
        $status = $bad ? count($bad) . ' to look at' : ($on ? 'In use' : 'Not set up');
        $cards[] = [$on ? ($bad ? 0 : 1) : 2, $name, '<div class="os-card" id="svc-' . $e($k) . '">' . tv_admin_fold($name, $status . ' · ' . $what, $bad ? 'bad' : ($on ? 'ok' : ''), '', $b, (bool) $bad || $saved === $k) . '</div>'];   // open again after saving it; #svc-<key>: the admin search opens it here
    }
    usort($cards, fn ($a, $b) => [$a[0], $a[1]] <=> [$b[0], $b[1]]);   // what needs a look, then what's in use, then the rest; by name
    $total = $plansUsd + $usageUsd;
    $h = $msg . '<p data-tv-status="info" data-tv-label="This month so far:">Plans ' . tv_os_money($plansUsd) . ' + use ' . tv_os_money($usageUsd) . ' = <b>' . tv_os_money($total) . '</b>'
       . ($unpriced ? ' (not counted yet: ' . $e(implode(', ', $unpriced)) . '\'s plan price, set in Settings)' : '') . '. Card fees on our own orders show in QuickBooks; businesses\' fees on the Marketplace are theirs.</p>'
       . '<p class="ak-note">Every outside service the site and the crawler depend on, keyed or free, one card each: what it\'s for, whether it\'s working (from the site\'s and the crawler\'s own logs), what it costs, what\'s set in other sections (each linked), its terms and who to ask. Ctrl K finds a card by its name, company or address. The counts are the site\'s own; each company\'s bill is exact (its Billing link). An email goes to the admins at 80% and 100% of a cap, and a report on the 1st.</p>';
    foreach ($cards as $c) $h .= $c[2];
    // across companies: how independent we are, and last month's report (kept from Services & usage, decisions/0133)
    try {
        $i = Services::independence($pdo);
        $h .= '<p data-tv-status="info" data-tv-label="Independence this month:">' . ($i['share'] !== null ? 'Our own crawler answered ' . $i['share'] . '% of Find it (' . $i['find_free'] . ' of ' . ($i['find_free'] + $i['find_paid']) . ').' : 'No Find it answers yet this month.')
            . ' ' . $i['listings'] . ' listing' . ($i['listings'] === 1 ? '' : 's') . ' published from the crawler with ' . $i['paid'] . ' paid lookup' . ($i['paid'] === 1 ? '' : 's') . ($i['per_listing'] !== null ? ' (' . $i['per_listing'] . ' each; lower is more independent)' : '') . '.</p>';
        $last = date('Y-m', strtotime('first day of last month'));
        $h .= tv_admin_fold('Report for ' . date('F Y', strtotime($last . '-01')), 'What the email on the 1st says', '', '', '<pre style="white-space:pre-wrap;font:inherit;font-size:.85rem;margin:0">' . $e(Services::report($pdo, $last)) . '</pre>', false);
    } catch (Throwable) {}
    // #svc-<key> (the admin search, or a link from another section): open that card, ring it and bring it into view
    $h .= '<script>(function(){var t=location.hash&&document.getElementById(location.hash.slice(1));if(!t||!t.classList.contains("os-card"))return;var b=t.querySelector(\'.ak-foldt[aria-expanded="false"]\');if(b)b.click();t.style.boxShadow="0 0 0 3px #8FBCA8";t.style.borderRadius=".5rem";setTimeout(function(){t.scrollIntoView({block:"start"});},50);})();</script>';
    return '<div class="os">' . $h . '</div>' . tv_os_css() . tv_os_move_js() . tv_os_env_js();
}

/** System Configuration → Settings: what's about the site itself. Outside companies are in Outside services. */
function tv_site_settings(PDO $pdo): string
{
    $e = 'tv_w_e';
    $env = fn (string $k): string => trim((string) (getenv($k) ?: ''));
    $on = fn (string $k, string $d = 'on'): bool => strtolower($env($k) ?: $d) !== 'off';
    require_once __DIR__ . '/../lib/EnvSettings.php';
    require_once __DIR__ . '/../admin/Access.php';
    // changed here, written into .env (decisions/0125); keys, passwords and tokens stay in .env by hand
    $h = '<p class="ak-note">How the site itself is set up. Each outside company (storage, email, payments, AI, sign-in) and its keys are in <a href="/admin/config/services">Outside services</a>. '
       . 'Settings below are written into .env for you, and the file before each change is kept; keys, passwords and tokens stay in .env (cPanel → File Manager), never shown here.</p>';
    $rest = array_values(array_diff(array_keys(EnvSettings::EDITABLE), OutsideServices::onCards()));   // a company's are on its card
    // in groups, the way they're used (Jason, 2026-11-11: "easy to find"); anything new lands in Other until it's grouped
    $groups = ['The site\'s email' => ['SMTP_FROM_NAME', 'SMTP_FROM_EMAIL', 'SMTP_REPLY_TO', 'BUSINESS_POSTAL_ADDRESS'],
               'Orders and payments' => ['ORDERS_FROM_EMAIL', 'ORDERS_FROM_NAME', 'ORDERS_REPLY_TO', 'CLIENT_PAY_WAYS', 'WIRE_VERIFY_PHONE'],
               'Legal identity (Terms and policies)' => ['LEGAL_NAME', 'LEGAL_ADDRESS', 'LEGAL_EMAIL', 'LEGAL_PHONE', 'LEGAL_STATE', 'LEGAL_COUNTY'],
               'Claims' => ['CLAIM_VERIFY_NUMBER']];
    $grouped = array_merge(...array_values($groups));
    if ($other = array_values(array_diff($rest, $grouped))) $groups['Other'] = $other;
    foreach ($groups as $g => $ks) { $ks = array_values(array_intersect($ks, $rest)); if ($ks) $h .= tv_admin_fold($g, count($ks) . ' setting' . (count($ks) === 1 ? '' : 's') . ', changed here', '', '', tv_os_env_rows($ks), false); }
    require_once __DIR__ . '/../lib/crawler/AutoImport.php';
    $sess = dirname(__DIR__) . '/storage/sessions';
    $G = [
        'Publishing' => [
            ['Auto-publish', AutoImport::enabled() ? 'On' : 'Off', AutoImport::enabled() ? 'ok' : 'bad', 'AUTO_IMPORT', 'Listings that pass every check publish on their own (decisions/0076). Off: everything waits in Review.'],
            ['Crawler', $on('CRAWL_QUEUE') ? 'Running' : 'Paused', $on('CRAWL_QUEUE') ? 'ok' : 'bad', 'CRAWL_QUEUE', 'Off pauses every crawl job.'],
        ],
        'Privacy' => [
            ['Usage analytics', $env('ANALYTICS_SRC') !== '' ? ($env('ANALYTICS_NAME') ?: 'Set up') . ' (' . (parse_url($env('ANALYTICS_SRC'), PHP_URL_HOST) ?: $env('ANALYTICS_SRC')) . ')' : 'None set up', $env('ANALYTICS_SRC') !== '' ? 'ok' : 'info', 'ANALYTICS_SRC, ANALYTICS_NAME', 'Loads only for people who say yes (decisions/0077). With none set up, nobody is asked.'],
            ['Videos from elsewhere', 'Wait for a yes', 'ok', 'built in', 'YouTube and Vimeo load only after Play, or with Videos allowed.'],
            ['Staying signed in', 'Until sign-out or the browser closes; 30 days unused', 'info', 'built in', 'Sessions are kept in app/storage/sessions' . (is_dir($sess) && is_writable($sess) ? '.' : ', which isn\'t writable yet: people may be signed out sooner.')],
            ['Privacy keys', $env('TAG_HASH_KEY') !== '' && $env('GUEST_HASH_KEY') !== '' ? 'Set' : 'Not all set', $env('TAG_HASH_KEY') !== '' && $env('GUEST_HASH_KEY') !== '' ? 'ok' : 'bad', 'TAG_HASH_KEY, GUEST_HASH_KEY', 'Turn counts into codes no one can trace back.'],
        ],
        'The site' => [
            ['Site address', $env('APP_URL') ?: 'Not set', 'info', 'APP_URL', 'Used in emails and shared links.'],
            ['Default place', $env('DEFAULT_GEO_HUB_SLUG') ?: 'Not set', 'info', 'DEFAULT_GEO_HUB_SLUG', 'Where the site opens with no place chosen.'],
            ['Two-step sign-in for staff', strtolower($env('TV_TWO_STEP')) === 'off' ? 'Off (TV_TWO_STEP=off)' : 'On', strtolower($env('TV_TWO_STEP')) === 'off' ? 'bad' : 'ok', 'TV_TWO_STEP', 'Staff enter a code from their authenticator app.'],
            ['Crawler key', $env('CRAWLER_API_TOKEN') !== '' ? 'Set' : 'Not set', $env('CRAWLER_API_TOKEN') !== '' ? 'ok' : 'bad', 'CRAWLER_API_TOKEN', 'Lets the crawler worker report in.'],
            ['Staff mailboxes', $env('STAFF_EMAIL_DOMAIN') ?: 'trvgo.com', 'info', 'STAFF_EMAIL_DOMAIN', 'Made from Staff logins through cPanel (Bluehost in Outside services).'],
        ],
        'Server' => [
            ['PHP', PHP_VERSION, 'info', 'the host', ''],
            ['Database', (function () use ($pdo) { try { return 'MySQL ' . $pdo->query('SELECT VERSION()')->fetchColumn(); } catch (Throwable) { return 'Not reachable'; } })(), 'info', 'DB_HOST, DB_DATABASE', 'Updates run themselves: Database updates.'],
            ['Maintenance notice', 'Coming', 'info', '', 'A notice across the top of every page while work is being done.'],
        ],
    ];
    foreach ($G as $g => $rs) {
        $b = '';
        foreach ($rs as [$lab, $val, $tone, $from, $what]) $b .= '<div class="os-part"><p data-tv-status="' . $tone . '" data-tv-label="' . $e($lab) . ':">' . $e($val) . '</p><small>' . $e($what) . ($from !== '' ? ' <code>' . $e($from) . '</code>' : '') . '</small></div>';
        $bad = count(array_filter($rs, fn ($r) => $r[2] === 'bad'));
        $h .= tv_admin_fold($g, $bad ? $bad . ' to look at' : count($rs) . ' settings', $bad ? 'bad' : '', '', $b, (bool) $bad);
    }
    $h .= '<div class="os-links"><a class="ak-b" href="/admin/config/services">Outside services</a><a class="ak-b" href="/admin/config/dbupdates">Database updates</a><a class="ak-b" href="/admin/config/scheduler">Scheduled tasks</a><a class="ak-b" href="/admin/config/ai">AI use</a></div>';
    return '<div class="os">' . $h . '</div>' . tv_os_css() . tv_os_env_js();
}

/** Settings changed here (EnvSettings, decisions/0125), each with Edit: written into .env, the file before kept. */
function tv_os_env_rows(array $keys): string
{
    if (!$keys) return '';
    require_once __DIR__ . '/../lib/EnvSettings.php';
    require_once __DIR__ . '/../admin/Access.php';
    [$ok, $why] = Access::can('config.env', ['min' => 'executive', 'depts' => []]);
    $e = 'tv_w_e'; $h = '';
    foreach ($keys as $k) {
        if (!isset(EnvSettings::EDITABLE[$k])) continue;
        [$lab, $what] = EnvSettings::EDITABLE[$k]; $v = EnvSettings::value($k);
        $h .= '<div class="os-env"><div class="os-envh"><b>' . $e($lab) . '</b><span data-v>' . ($v !== '' ? $e($v) : '<span class="os-not">Not set</span>') . '</span>'
            . '<button type="button" class="ak-b" data-env="' . $e($k) . '" data-label="' . $e($lab) . '" data-value="' . $e($v) . '"' . ($ok ? '' : ' disabled title="' . $e($why) . '" aria-disabled="true"') . '>Edit</button></div>'
            . '<small>' . $e($what) . ' <code>' . $e($k) . '</code>' . ($ok ? '' : ' · ' . $e($why)) . '</small></div>';
    }
    return '<div class="os-envs">' . $h . '</div>';
}

function tv_os_css(): string
{
    static $done = false; if ($done) return ''; $done = true;
    return '<style>.os .os-what{margin:.1rem 0 .6rem;font-weight:600;color:#3E2B1F}.os .os-part{margin:.35rem 0 .55rem}.os .os-part p{margin:0}.os .os-part small,.os .os-note{display:block;font-size:.78rem;color:#8A7355;margin-top:.15rem}'
         . '.os .os-h{font-size:.72rem;letter-spacing:.08em;text-transform:uppercase;color:#8A7355;margin:.9rem 0 .35rem}.os .os-line{margin:.35rem 0;font-size:.9rem}.os .os-links{display:flex;flex-wrap:wrap;gap:.4rem;margin:.8rem 0 .2rem}.os .os-links .ak-b{text-decoration:none}'
         . '.os .os-sign{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .5rem;margin:.1rem 0 .6rem}.os .os-sign .ak-b{text-decoration:none}.os .os-signt{font-size:.85rem;color:#5C4632;min-width:0}'
         . '.os .os-ed{display:inline-block}.os .os-ed>summary{list-style:none;cursor:pointer;width:28px;height:28px;border-radius:999px;border:1px solid #CBB98D;display:inline-flex;align-items:center;justify-content:center;color:#92400E;font-size:.85rem}.os .os-ed>summary::-webkit-details-marker{display:none}.os .os-ed[open]{flex-basis:100%;order:9}.os .os-ed .os-notes{margin-top:.5rem}'
         . '.os .os-notes{display:grid;gap:.45rem;max-width:40rem}.os .os-notes label{display:grid;grid-template-columns:8rem 1fr;gap:.5rem;align-items:center;font-size:.85rem}.os .os-notes label span{font-weight:700}.os .os-notes .ak-b{justify-self:start}@media (max-width:560px){.os .os-notes label{grid-template-columns:1fr}}'
         . '.os .os-env{padding:.5rem 0;border-top:1px solid #EEE3CA}.os .os-env:first-child{border-top:0}.os .os-envh{display:flex;flex-wrap:wrap;align-items:center;gap:.3rem .6rem}.os .os-envh b{min-width:12rem}.os .os-envh [data-v]{flex:1;min-width:8rem;word-break:break-all}'
         . '.os .os-env small{display:block;font-size:.78rem;color:#8A7355;margin-top:.2rem}.os .os-not{color:#8A7355;font-weight:400}.os .os-go{color:#92400E;text-decoration:underline;font-weight:600}.os code{font-size:.75rem;word-break:break-all}</style>';
}

/** Settings → Change here: one setting at a time, written into .env (decisions/0125). */
function tv_os_env_js(): string
{
    return <<<'JS'
<script>
(function () {
  document.querySelectorAll('.os [data-env]').forEach(function (b) {
    b.addEventListener('click', async function () {
      if (b.disabled) return;
      var v = await TvAsk.ask(b.dataset.label, b.dataset.value);
      if (v === null || v === undefined || v === b.dataset.value) return;
      TvAsk.busy(b, true);
      try {
        var csrf = (await (await fetch('/api/auth/session.php', { credentials: 'include' })).json()).csrf_token;
        var body = { key: b.dataset.env, value: v };
        var r = await (await fetch('/admin/api/env-setting.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })).json();
        if (!r.ok) { TvAsk.say((r.error && r.error.message) || 'That didn\'t save.', { anchor: b, bad: true }); return; }
        b.dataset.value = r.value;
        var shown = b.closest('.os-env').querySelector('[data-v]'); shown.textContent = r.value || 'Not set';
        TvAsk.say(r.message + ' It\'s in use from the next page you open.', { anchor: b });
      } catch (e) { TvAsk.say('That didn\'t save. Try again.', { anchor: b, bad: true }); }
      finally { TvAsk.busy(b, false); }
    });
  });
})();
</script>
JS;
}

/** Storage: the files from before object storage, moved off the server a batch per request (decisions/0123). */
function tv_os_move_js(): string
{
    return <<<'JS'
<script>
(function () {
  var box = document.getElementById('tv-s3move'); if (!box) return;
  var t = box.querySelector('[data-t]'), btn = box.querySelector('button');
  function mb(b) { return b >= 1073741824 ? (b / 1073741824).toFixed(2) + ' GB' : (b / 1048576).toFixed(1) + ' MB'; }
  function left(r) { if (!r.left) { t.textContent = 'Every file is in storage: none left on the server.'; btn.style.display = 'none'; return; }
    t.textContent = r.left + ' file' + (r.left === 1 ? '' : 's') + ' (' + mb(r.left_bytes) + ') from before still to move into their owners\' folders in storage. Nothing changes for visitors while they move. The scheduled task Files to S3 does this too.';
    btn.textContent = 'Move ' + r.left + ' file' + (r.left === 1 ? '' : 's'); btn.style.display = ''; }
  fetch('/admin/api/move-files.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (r) { if (r.ok) left(r); else t.textContent = (r.error && r.error.message) || 'Couldn\'t check.'; }).catch(function () { t.textContent = 'Couldn\'t check.'; });
  btn.addEventListener('click', async function () {
    if (!(await TvAsk.confirm('Move them now? Keep this page open until it says done; it goes a batch at a time.', { anchor: btn, yes: 'Move them' }))) return;
    TvAsk.busy(btn, true);
    var csrf = (await (await fetch('/api/auth/session.php', { credentials: 'include' })).json()).csrf_token, total = 0, bytes = 0, r;
    try {
      do {
        r = await (await fetch('/admin/api/move-files.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: '{}' })).json();
        if (!r.ok) throw r.error || {};
        total += r.moved; bytes += r.bytes;
        t.textContent = 'Moved ' + total + ' (' + mb(bytes) + ')… ' + r.left + ' to go.';
      } while (r.moved + (r.missing || 0) > 0 && r.left > r.stuck);
      if (r.left) { left(r); TvAsk.say('Moved ' + total + '. ' + r.left + ' wouldn\'t go yet (they still work from the server); try again later.', { anchor: btn }); }
      else { t.textContent = 'Done: moved ' + total + ' file' + (total === 1 ? '' : 's') + ' (' + mb(bytes) + '). Every file is in storage.'; btn.style.display = 'none'; }
    } catch (e) { t.textContent = (e && e.message) || 'The move stopped. Try again: what moved stays moved.'; }
    TvAsk.busy(btn, false);
  });
})();
</script>
JS;
}
