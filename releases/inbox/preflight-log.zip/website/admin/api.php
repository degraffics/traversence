<?php
// admin/api.php — the admin's one endpoint (decisions/0109 A5): /admin/api/<module>/<tool>. Every tool answers the same
// actions: list (rows, stage counts), get (the detail: fields, links, where it is in its workflow, the moves with who
// may make them, history), move (a workflow move), create (a quick task). System Configuration adds workflows (the
// builder: get, save a draft, check, publish, new, discard) and permissions (save a rule). The same access rule applies
// wherever the tool is opened (app/admin/Access.php).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
require_once __DIR__ . '/../../app/admin/AdminModules.php';
require_once __DIR__ . '/../../app/admin/Workflow.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
$ok = $me && IntakeStager::canUseIntake($pdo, $me);
if ($me && !$ok) { try { $st = $pdo->prepare("SELECT 1 FROM " . Database::t('admin_access') . " WHERE user_id = ? AND tier = 'regional_admin' LIMIT 1"); $st->execute([(int) $me['id']]); $ok = (bool) $st->fetchColumn(); } catch (Throwable) {} }
if (!$ok) Response::error('Staff only.', 403, 'forbidden');
$uid = (int) $me['id'];
$path = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
if (!preg_match('#/admin/api/([a-z]+)/([a-z0-9_-]+)$#', $path, $x)) Response::error('Not an admin tool.', 404);
[, $mod, $t] = $x;
$post = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$in = $post ? Response::jsonBody() : $_GET;
if ($post) Response::requireCsrf();
$act = (string) ($in['action'] ?? 'list');

/** An action's link with {id} and the item's own fields ({user_id}) filled in. */
function ak_link(string $u, int $id, array $row): string
{
    return $u === '' ? '' : preg_replace_callback('/\{([a-z_]+)\}/', fn ($x) => rawurlencode($x[1] === 'id' ? (string) $id : (string) ($row[$x[1]] ?? '')), $u);
}

/** The detail drawer's content for an item. */
function ak_detail(PDO $pdo, string $key, array $tool, int $id): array
{
    $d = isset($tool['get']) ? ($tool['get'])($pdo, $id) : null;
    if (!$d && empty($tool['workflow'])) throw new InvalidArgumentException('That item isn\'t here.');
    $d = (array) $d + ['title' => '#' . $id, 'subtitle' => '', 'fields' => [], 'links' => []];
    $d['fields'] = array_values(array_filter($d['fields'], fn ($f) => trim((string) $f[1]) !== ''));
    $d['id'] = $id;
    if (!empty($tool['workflow']) && Workflow::ready($pdo)) {
        $wk = $tool['workflow'];
        $it = Workflow::item($pdo, $wk, $id);
        $def = Workflow::def($pdo, $wk, (int) $it['version']);
        [$h, $sla, $late] = Workflow::clock($def, $it);
        $cur = $it['stage'];
        $order = array_column($def['stages'], 'key');
        $pos = array_search($cur, $order, true);
        $d['workflow'] = ['key' => $wk, 'stage' => $cur, 'version' => (int) $it['version'],
            'stages' => array_values(array_map(fn ($s, $i) => ['key' => $s['key'], 'label' => $s['label'], 'end' => ($s['kind'] ?? '') === 'end', 'state' => $s['key'] === $cur ? 'now' : ($pos !== false && $i < $pos && ($s['kind'] ?? '') !== 'end' ? 'done' : '')],
                $def['stages'], array_keys($def['stages']))),
            'hours' => $h, 'sla' => $sla, 'late' => $late,
            'moves' => array_map(fn ($m) => ['link' => ak_link((string) ($m['link'] ?? ''), $id, (array) ($it['row'] ?? []))] + $m, Workflow::moves($pdo, $wk, $id, $it)),
            'history' => array_map(fn ($r) => ['at' => date('M j, Y g:ia', strtotime((string) $r['created_at'])), 'move' => $r['move'], 'from' => $r['from_stage'], 'to' => $r['to_stage'],
                'by' => (string) ($r['display_name'] ?: $r['email'] ?: ''), 'note' => (string) $r['note'], 'effects' => (string) ($r['effects'] ?? '')], Workflow::history($pdo, $wk, $id)),
            'labels' => array_column($def['stages'], 'label', 'key')];
        if ($d['title'] === '#' . $id && !empty($it['title'])) $d['title'] = $it['title'];
    }
    return $d;
}

try {
    // ---- System Configuration: the workflow builder ----------------------------------------------------------------
    if ($mod === 'config' && $t === 'workflows') {
        [$can, $why] = Access::can('config.workflows.edit', ['min' => 'manager', 'depts' => []]);
        $key = (string) ($in['key'] ?? '');
        if ($act === 'get') {
            $w = Workflow::meta($pdo, $key);
            $pub = $w['version'] ? Workflow::def($pdo, $key) : ['stages' => [], 'moves' => [], 'any' => []];
            $draft = $w['draft'] !== null ? json_decode((string) $w['draft'], true) : null;
            $counts = [];
            $st = $pdo->prepare('SELECT stage, COUNT(*) n FROM ' . Database::t('wf_items') . ' WHERE wf_key = ? GROUP BY stage'); $st->execute([$key]);
            foreach ($st as $r) $counts[$r['stage']] = (int) $r['n'];
            $b = Workflow::builtins()[$key]['def'] ?? null;
            $lock = ['stages' => [], 'moves' => []];
            if ($b) { foreach ($b['stages'] as $s) if (!empty($s['op']) || !empty($s['locked'])) $lock['stages'][] = $s['key']; foreach ($b['moves'] as $m) if (!empty($m['op'])) $lock['moves'][] = $m['key']; }
            $by = '';
            if ($w['draft_by']) { $u = $pdo->prepare('SELECT COALESCE(display_name, email) FROM users WHERE id = ?'); $u->execute([(int) $w['draft_by']]); $by = (string) $u->fetchColumn(); }
            $vs = $pdo->prepare('SELECT version, note, published_at FROM ' . Database::t('wf_versions') . ' WHERE wf_key = ? ORDER BY version DESC LIMIT 10'); $vs->execute([$key]);
            Response::success(['workflow' => ['key' => $key, 'name' => $w['name'], 'module' => $w['module'], 'builtin' => (bool) $w['builtin'], 'version' => (int) $w['version'],
                'draft_by' => $by, 'draft_at' => $w['draft_at']], 'def' => $draft ?? $pub, 'published' => $pub, 'has_draft' => $draft !== null, 'counts' => $counts, 'lock' => $lock,
                'problems' => Workflow::validate($key, $draft ?? $pub), 'versions' => $vs->fetchAll(PDO::FETCH_ASSOC), 'can' => $can, 'why' => $why]);
        }
        if (!$post) Response::error('Send it as a POST.', 405);
        if (!$can) Response::error($why . '.', 403);
        if ($act === 'save') {
            $def = (array) ($in['def'] ?? []);
            $def = ['stages' => array_values((array) ($def['stages'] ?? [])), 'moves' => array_values((array) ($def['moves'] ?? [])), 'any' => array_values((array) ($def['any'] ?? []))];
            if (strlen(json_encode($def)) > 60000) Response::error('That workflow is too big.');
            Workflow::saveDraft($pdo, $key, $def, $uid);
            Response::success(['problems' => Workflow::validate($key, $def)]);
        }
        if ($act === 'publish') {
            $v = Workflow::publish($pdo, $key, (string) ($in['note'] ?? ''), ($in['carry'] ?? '') === 'move' ? 'move' : 'keep', (array) ($in['map'] ?? []), $uid);
            Response::success(['version' => $v, 'message' => 'Published as version ' . $v . '.']);
        }
        if ($act === 'discard') { $pdo->prepare('UPDATE ' . Database::t('wf_workflows') . ' SET draft = NULL, draft_by = NULL, draft_at = NULL WHERE wf_key = ?')->execute([$key]); Response::success(['message' => 'Draft thrown away.']); }
        if ($act === 'create') {
            $m = (string) ($in['module'] ?? '');
            if (!isset(Workspaces::ALL[$m])) Response::error('Choose the module it belongs to.');
            Response::success(['key' => Workflow::create($pdo, (string) ($in['name'] ?? ''), $m, $uid)]);
        }
        Response::error('Unknown action.');
    }

    // ---- System Configuration: permissions -------------------------------------------------------------------------
    if ($mod === 'config' && $t === 'permissions') {
        if (!$post) Response::error('Send it as a POST.', 405);
        [$can, $why] = Access::can('config.permissions.edit', ['min' => 'director', 'depts' => []]);
        if (!$can) Response::error($why . '.', 403);
        $action = (string) ($in['rule'] ?? '');
        $min = (string) ($in['min'] ?? '');
        if (!preg_match('/^[a-z0-9_\/.-]{3,120}$/', $action) || !isset(Access::LEVEL_NAMES[$min])) Response::error('That rule isn\'t right.');
        $depts = array_values(array_intersect((array) ($in['depts'] ?? []), array_keys(Access::DEPT_NAMES)));
        Access::save($pdo, $action, $min, $depts, $uid);
        Response::success(['message' => 'Saved.']);
    }

    // ---- System Configuration: the stock library (decisions/0143): search a source, add a photo, choose a door's photo.
    // Its list, retagging and retiring are the config/stock tool, below.
    if ($mod === 'config' && $t === 'stock' && in_array($act, ['search', 'add', 'use'], true)) {
        require_once __DIR__ . '/../../app/lib/StockLibrary.php';
        [$sok, $swhy] = Modules::canTool('config/stock');
        if (!$sok) Response::error($swhy . '.', 403);
        if ($act === 'search') {
            [$items, $more] = StockLibrary::search($pdo, (string) ($in['source'] ?? ''), (string) ($in['q'] ?? ''), (int) ($in['page'] ?? 1));
            Response::success(['items' => $items, 'more' => $more]);
        }
        if (!$post) Response::error('Send it as a POST.', 405);
        [$eok, $ewhy] = Access::can('config/stock.edit', ['min' => 'staff', 'depts' => ['con', 'ops', 'eng']]);
        if (!$eok) Response::error($ewhy . '.', 403);
        if ($act === 'add') {
            $img = StockLibrary::add($pdo, (string) ($in['source'] ?? ''), (string) ($in['id'] ?? ''), ['subjects' => (string) ($in['subjects'] ?? ''), 'place' => (string) ($in['place'] ?? ''), 'scope' => (string) ($in['scope'] ?? '')], $uid);
            Response::success(['id' => (int) ($img['id'] ?? 0), 'message' => 'Added to the library, with its credit.']);
        }
        $slot = (string) ($in['slot'] ?? '');   // the admin chooses only for the site's own slots (the home page's doors)
        if ($slot !== 'home_door' || !isset(StockLibrary::DOORS[(string) ($in['owner'] ?? '')])) Response::error('Choose that where it\'s edited.');
        StockLibrary::setUse($pdo, $slot, (string) $in['owner'], (int) ($in['stock'] ?? 0), $uid);
        Response::success(['message' => (int) ($in['stock'] ?? 0) ? 'Chosen: the door shows it until you choose another.' : 'Back to automatic.']);
    }

    // ---- System Configuration: Pre-flight (decisions/0163 §10's note of 2026-11-16). run: one line's real, free, read-only
    // test, answered with the line drawn again and the counts; fix: a fix the site can make (the scheduler's jobs, database
    // updates); done: a Run all finished (kept for Start the system). Executives (config.preflight); it changes nothing else.
    if ($mod === 'config' && $t === 'preflight') {
        require_once __DIR__ . '/../../app/lib/Preflight.php';
        require_once __DIR__ . '/../../app/admin/preflight-console.php';
        [$can, $why] = Preflight::can();
        if (!$can) Response::error($why . '.', 403);
        if (!$post && $act === 'report') {   // the plain-text report, to read or send to Claude (Jason, 2026-11-17); run=<id>: a logged run's, as it stood then
            $rid = (int) ($in['run'] ?? 0); $one = $rid ? Preflight::runReport($pdo, $rid) : null;
            if ($rid && !$one) Response::error('That run isn\'t in the log any more (the last 50 are kept).', 404);
            header('Content-Type: text/plain; charset=utf-8');
            header('Content-Disposition: attachment; filename="preflight-' . gmdate('Y-m-d-Hi', $one ? $one[1] : time()) . '.txt"');
            echo $one ? $one[0] : Preflight::report($pdo);
            exit;
        }
        if (!$post) Response::error('Send it as a POST.', 405);
        $who = (string) (Access::staff()['name'] ?? $me['display_name'] ?? '');
        try {
            if ($act === 'run') { $id = (string) ($in['id'] ?? ''); $r = Preflight::run($pdo, $id, $who); Response::success(['s' => $r['s'], 'said' => $r['said'], 'at' => $r['at'], 'html' => tv_preflight_line($pdo, $id, $r), 'counts' => tv_preflight_counts($pdo)]); }   // said, at: Outside services' card Test
            if ($act === 'fix') Response::success(['message' => Preflight::fix($pdo, (string) ($in['fix'] ?? ''), $uid), 'counts' => tv_preflight_counts($pdo)]);
            if ($act === 'done') { Preflight::finished($pdo, $who, (int) ($in['start'] ?? 0)); Response::success(['counts' => tv_preflight_counts($pdo), 'log' => tv_preflight_log($pdo), 'message' => 'The pre-flight ran from start to finish.']); }
        } catch (RuntimeException | InvalidArgumentException $x) { Response::error($x->getMessage(), 422); }
        Response::error('Unknown action.');
    }

    // ---- System Configuration: staging (decisions/0145 Phase 3). Founder only. setup: makes or completes staging.trvgo.us
    // and gives the test accounts new sign-ins (the shown-once block, with staging's viewing password), then starts the
    // first refresh; refresh: starts or carries on a refresh, a step at a time (the page asks again until it's done);
    // wayin: Check the way in, which asks staging several ways and says which layer answered (decisions/0159 step 1).
    if ($mod === 'config' && $t === 'staging') {
        require_once __DIR__ . '/../../app/lib/StagingSite.php';
        if ($act === 'status') Response::success(['progress' => StagingSite::progressNow($pdo)]);
        // staging as a whole (decisions/0165 §5): keep caught up, its jobs, preview, publish, conflicts, held, roll back.
        // Each checks its own permission (StagingApi); reading (summary, held, conflicts, plan, tosend, carry) may be a GET.
        require_once __DIR__ . '/../../app/lib/StagingApi.php';
        if (in_array($act, StagingApi::ACTS, true)) {
            if (!$post && !in_array($act, ['summary', 'held', 'conflicts', 'plan', 'tosend', 'carry', 'startover_losses'], true)) Response::error('Send it as a POST.', 405);
            $tz0 = preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($in['tz'] ?? '')) ? (string) $in['tz'] : '';
            try { Response::success(StagingApi::act($pdo, $act, $in, [$uid, (string) ($me['display_name'] ?? ''), (string) ($me['email'] ?? ''), $tz0])); }
            catch (RuntimeException | InvalidArgumentException $x) { Response::error($x->getMessage(), 422); }
        }
        if (!$post) Response::error('Send it as a POST.', 405);
        [$can, $why] = StagingSite::canManage();
        if (!$can) Response::error($why, 403);
        $tz = preg_match('#^[A-Za-z_]+(/[A-Za-z0-9_+-]+)*$#', (string) ($in['tz'] ?? '')) ? (string) $in['tz'] : '';
        if ($act === 'setup') {
            $done = StagingSite::setup($pdo, $uid, $tz);
            require_once __DIR__ . '/../../app/lib/TestAccounts.php';
            $block = ''; $made = [];
            if (TestAccounts::ready($pdo)) { $me2 = Access::staff(); $r = TestAccounts::makeAll($pdo, (int) ($me2['id'] ?? 0), $uid); $block = $r['block']; $made = $r['made']; }
            else { $v = StagingSite::newViewing($pdo); $block = json_encode(['made_at' => date('c'), 'staging' => $v], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); $made = ['a staging viewing password (the test accounts aren\'t made yet: their database update runs first)']; }
            $p = StagingSite::start($pdo, $uid, $tz);
            StagingSite::kick($pdo);   // the server carries it on, page open or not
            Response::success(['log' => $done['log'], 'block' => $block, 'made' => $made, 'progress' => $p,
                'message' => 'Staging is set up. Copy the sign-ins below into CHECK_ACCOUNTS now (they\'re shown once); the copy of the live site is going in.']);
        }
        if ($act === 'wayin') {   // Check the way in (decisions/0159 step 1): which layer asks for the password on Open staging
            $me4 = Access::staff();
            try { [$rows, $text] = StagingSite::checkWayIn($pdo, $uid, (string) ($me4['name'] ?? $me['display_name'] ?? ''), (int) ($me4['id'] ?? 0)); }
            catch (RuntimeException $x) { Response::error($x->getMessage(), 422); }
            Response::success(['rows' => $rows, 'text' => $text, 'message' => 'Checked: the answers are below. Copy them and send them to Claude.']);
        }
        if ($act === 'refresh') {
            $r = StagingSite::running($pdo);
            if (!$r) StagingSite::start($pdo, $uid, $tz);
            if (!$r || time() - (int) ($r['updated'] ?? 0) > 120) StagingSite::kick($pdo);   // started, or nothing moved for two minutes
            Response::success(['progress' => StagingSite::step($pdo, 20)]);
        }
        Response::error('Unknown action.');
    }

    // ---- System Configuration: releases (decisions/0145 Phase 5). Each action checks its own permission (Releases::can):
    // releases.publish, .schedule, .turn_off, .rollback, Founder only until a role is given one. GET download: the release's
    // zip or its rollback zip, for an upload by FTP.
    if ($mod === 'config' && $t === 'releases') {
        require_once __DIR__ . '/../../app/lib/Releases.php';
        require_once __DIR__ . '/../../app/lib/Switches.php';
        if (!Switches::on($pdo, 'releases')) Response::error('The Releases page isn\'t on for you yet (Switches → Releases page).', 403);
        try {
            if ($act === 'enter') {   // Open on staging: past its viewing password, as a test account, with the staging bar
                $me3 = Access::staff();
                $url = Releases::enterUrl($pdo, (int) ($in['id'] ?? 0), (string) ($in['as'] ?? ''), (string) ($in['to'] ?? '/'), $uid, (string) ($me3['name'] ?? $me['display_name'] ?? ''), (int) ($me3['id'] ?? 0));
                header('Location: ' . $url, true, 302);
                exit;
            }
            if ($act === 'download') {
                [$file, $name] = Releases::zip($pdo, (int) ($in['id'] ?? 0), ($in['which'] ?? '') === 'rollback' ? 'rollback' : 'release');
                header('Content-Type: application/zip');
                header('Content-Disposition: attachment; filename="' . $name . '"');
                header('Content-Length: ' . (string) filesize($file));
                header('Cache-Control: no-store');
                readfile($file);
                exit;
            }
            if (!$post) Response::error('Send it as a POST.', 405);
            if ($act === 'pull') Response::success(['message' => Releases::pullNow($pdo, $uid)]);   // Check for builds (git's inbox, now)
            if ($act === 'settings') Response::success(['message' => Releases::saveSettings($pdo, (array) ($in['settings'] ?? []))]);
            Response::success(['message' => Releases::act($pdo, (int) ($in['id'] ?? 0), $act, (array) ($in['args'] ?? []), $uid)]);
        } catch (RuntimeException $x) { Response::error($x->getMessage(), 422); }
    }

    // ---- a tool --------------------------------------------------------------------------------------------------------
    $key = $mod . '/' . $t;
    $tool = Modules::tool($key);
    if (!$tool) Response::error('Not an admin tool.', 404);
    [$ok, $why] = Modules::canTool($key);
    if (!$ok) Response::error($why . '.', 403);

    if ($act === 'list') {
        $per = in_array((int) ($in['per'] ?? 50), [10, 25, 50, 100], true) ? (int) $in['per'] : 50;   // so many a page (the lists' standard)
        $in['per'] = $per;
        [$rows, $total, $counts] = ($tool['list'])($pdo, $in, $uid);
        $stage = (string) ($in['stage'] ?? '');
        $paged = $total > count($rows) && empty($tool['pages_all']);   // the tool pages itself
        if (!$counts && !empty($tool['workflow'])) foreach ($rows as $r) if (isset($r['stage'])) $counts[$r['stage']] = ($counts[$r['stage']] ?? 0) + 1;
        if (!$paged) {
            if ($stage !== '') { $set = explode(',', $stage); $rows = array_values(array_filter($rows, fn ($r) => in_array((string) ($r['stage'] ?? ''), $set, true))); }   // a metric can stand for several stages ("To make")
            $sort = (string) ($in['sort'] ?? '');
            if ($sort !== '' && $rows && array_key_exists($sort, $rows[0])) {   // all the rows are here: any column sorts
                $d = ($in['dir'] ?? '') === 'desc' ? -1 : 1;
                usort($rows, fn ($x, $y) => $d * strnatcasecmp((string) ($x[$sort] ?? ''), (string) ($y[$sort] ?? '')));
            }
            $total = count($rows);
            $page = max(0, (int) ($in['page'] ?? 0));
            $rows = array_slice($rows, $page * $per, $per);
        }
        $sortable = $paged ? (array) ($tool['sortable'] ?? []) : array_map(fn ($c) => (string) $c[0], (array) ($tool['columns'] ?? []));
        Response::success(['rows' => $rows, 'total' => $total, 'counts' => (object) $counts, 'per' => $per, 'sortable' => $sortable]);
    }
    if ($act === 'get') Response::success(['item' => ak_detail($pdo, $key, $tool, (int) ($in['id'] ?? 0))]);
    if (!$post) Response::error('Send it as a POST.', 405);
    if ($act === 'move') {
        if (empty($tool['workflow'])) Response::error('This tool has no workflow.');
        $id = (int) ($in['id'] ?? 0);
        Workflow::move($pdo, $tool['workflow'], $id, (string) ($in['move'] ?? ''), (array) ($in['input'] ?? []), $uid);
        Response::success(['item' => ak_detail($pdo, $key, $tool, $id), 'message' => 'Done.']);
    }
    if ($act === 'act') {   // an action from the detail drawer (a note, tags, an edit): the tool says what it does
        if (empty($tool['act'])) Response::error('Nothing to do here.');
        [$aok, $awhy] = Access::can($key . '.edit', $tool['edit'] ?? ['min' => 'staff', 'depts' => []]);
        if (!$aok) Response::error($awhy . '.', 403);
        $id = (int) ($in['id'] ?? 0);
        $msg = ($tool['act'])($pdo, $id, (string) ($in['act'] ?? ''), (array) ($in['input'] ?? []), $uid);
        if (is_array($msg) && isset($msg['draft'])) Response::success(['draft' => (string) $msg['draft'], 'message' => (string) ($msg['message'] ?? '')]);   // written words for a box, not saved
        if (is_array($msg) && !empty($msg['ask'])) Response::success(['ask' => $msg['ask']]);   // a question first (a licensed item: is it, and its conditions); the page sends the answer
        if (is_array($msg) && !empty($msg['gone'])) Response::success(['gone' => true, 'message' => (string) ($msg['message'] ?? 'Deleted.')]);   // the record is gone: the drawer closes
        Response::success(['item' => ak_detail($pdo, $key, $tool, $id), 'message' => is_string($msg) ? $msg : 'Done.']);
    }
    if ($act === 'create') {
        $c = $tool['create'] ?? null;
        if (!$c || empty($c['do'])) Response::error('Nothing to make here.');
        [$cok, $cwhy] = Access::can($key . '.create', $c['rule'] ?? ['min' => 'staff', 'depts' => []]);
        if (!$cok) Response::error($cwhy . '.', 403);
        $vals = (array) ($in['input'] ?? []);
        foreach ((is_callable($c['fields'] ?? null) ? ($c['fields'])($pdo) : (array) ($c['fields'] ?? [])) as $f) if (($f[4] ?? '') !== 'optional' && trim((string) ($vals[$f[0]] ?? '')) === '') Response::error('Fill in ' . strtolower($f[1]) . '.');
        Response::success(($c['do'])($pdo, $vals, $uid));
    }
    Response::error('Unknown action.');
} catch (InvalidArgumentException | RuntimeException $e) {
    Response::error($e->getMessage());
} catch (Throwable $e) {
    error_log('admin api ' . $path . ': ' . $e->getMessage());
    Response::error('Something went wrong. Try again.', 500);
}
