<?php

declare(strict_types=1);

require_once __DIR__ . '/../PlaceScope.php';
require_once __DIR__ . '/../Identity.php';
require_once __DIR__ . '/../Suggestions.php';
require_once __DIR__ . '/../SearchIndex.php';

/**
 * app/lib/crawler/LiveDupes.php — live listings that are one business (review E24, decisions/0160 W2; decisions/0133's
 * "same place ID + same phone").
 *
 * New finds are merged into live listings at intake; two listings already live were found only when a visitor said so.
 * This pass finds them: the same phone (a number shared by more than MAX_GROUP listings is a head office's or a
 * switchboard's, and proves nothing) and then the same Google place, or the same ZIP with the same name or the same
 * street number. Each pair is offered in Review as "Same business" (Review's merge does the rest: which to keep, what
 * to fill in), never merged by itself. A pair asked about once is never asked again, whatever the answer.
 */
final class LiveDupes
{
    private const DEVICE = 'crawler-dupes';
    private const MAX_GROUP = 4;       // listings sharing one phone; more is a shared line
    private const MAX_OPEN = 40;       // waiting in Review at once from this pass: Review isn't flooded
    private const STATE = 'crawler_dupes_from';   // the phone the next pass starts after (it walks them all, a slice a time)

    /**
     * One pass: up to $limit new pairs offered. Returns ['checked' => phones looked at, 'offered' => pairs sent to Review].
     */
    public static function tick(PDO $pdo, int $limit = 5, int $slice = 1500): array
    {
        if (!Suggestions::ready($pdo)) return ['checked' => 0, 'offered' => 0];
        $open = $pdo->prepare("SELECT COUNT(*) FROM suggestions WHERE device_hash = ? AND status = 'new'"); $open->execute([self::DEVICE]);
        $room = min($limit, self::MAX_OPEN - (int) $open->fetchColumn());
        if ($room <= 0) return ['checked' => 0, 'offered' => 0];
        $pub = implode(',', array_map(fn ($s) => $pdo->quote($s), PlaceScope::PUBLIC_STATUSES));
        $rows = $pdo->query("SELECT e.id, e.name, e.primary_zip, p.meta_value AS phone, a.meta_value AS address, g.meta_value AS google
                               FROM entities e
                               JOIN entity_metadata p ON p.entity_id = e.id AND p.meta_key = 'phone'
                          LEFT JOIN entity_metadata a ON a.entity_id = e.id AND a.meta_key = 'address'
                          LEFT JOIN entity_metadata g ON g.entity_id = e.id AND g.meta_key = 'google'
                              WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ($pub)")->fetchAll(PDO::FETCH_ASSOC);
        $byPhone = [];
        foreach ($rows as $r) {
            $v = json_decode((string) $r['phone'], true);
            $p = Suggestions::phone10(is_string($v) ? $v : (string) $r['phone']);
            if ($p !== '') $byPhone[$p][] = $r;
        }
        $byPhone = array_filter($byPhone, fn ($g) => count($g) >= 2 && count($g) <= self::MAX_GROUP);
        ksort($byPhone, SORT_STRING);
        // walk the phones in order, a slice a pass, from where the last pass stopped (then round again)
        try { $from = SearchIndex::state($pdo, self::STATE); } catch (Throwable $e) { $from = ''; }
        $keys = array_keys($byPhone);
        $start = 0;
        foreach ($keys as $i => $k) if (strcmp((string) $k, $from) > 0) { $start = $i; break; }
        if ($from !== '' && $keys && strcmp((string) end($keys), $from) <= 0) $start = 0;
        $offered = 0; $checked = 0; $last = $from;
        foreach (array_slice($keys, $start, $slice) as $phone) {
            $checked++; $last = (string) $phone;
            $g = $byPhone[$phone];
            for ($i = 0; $i < count($g) && $offered < $room; $i++) {
                for ($j = $i + 1; $j < count($g) && $offered < $room; $j++) {
                    $why = self::same($g[$i], $g[$j]);
                    if ($why === '' || self::asked($pdo, (int) $g[$i]['id'], (int) $g[$j]['id'])) continue;
                    try {
                        Suggestions::create($pdo, ['kind' => 'same', 'topic' => 'business', 'entity_id' => (int) $g[$i]['id'], 'same_as_id' => (int) $g[$j]['id'],
                            'note' => 'Found by the crawler\'s check of live listings: ' . $g[$i]['name'] . ' (#' . $g[$i]['id'] . ') and ' . $g[$j]['name'] . ' (#' . $g[$j]['id'] . ') have the same phone, ' . $why . '. Merge them if they\'re one business; turn it down if they\'re two at one number.',
                            'context' => 'Crawler: live duplicates'], null, self::DEVICE);
                        $offered++;
                    } catch (Throwable $e) { error_log('LiveDupes ' . $g[$i]['id'] . '/' . $g[$j]['id'] . ': ' . $e->getMessage()); }
                }
            }
            if ($offered >= $room) break;
        }
        if ($checked && $last === (string) end($keys)) $last = '';   // the end: round again next time
        try { SearchIndex::setState($pdo, self::STATE, $last); } catch (Throwable $e) {}
        return ['checked' => $checked, 'offered' => $offered];
    }

    /** Why two listings with one phone look like one business, or '' when they don't. */
    public static function same(array $a, array $b): string
    {
        $ga = json_decode((string) ($a['google'] ?? ''), true); $gb = json_decode((string) ($b['google'] ?? ''), true);
        $pa = is_array($ga) && !empty($ga['matched']) ? (string) ($ga['place_id'] ?? '') : '';
        $pb = is_array($gb) && !empty($gb['matched']) ? (string) ($gb['place_id'] ?? '') : '';
        if ($pa !== '' && $pa === $pb) return 'and Google lists them as one place';
        if ($pa !== '' && $pb !== '' && $pa !== $pb) return '';   // Google says two places
        $za = substr((string) $a['primary_zip'], 0, 5); $zb = substr((string) $b['primary_zip'], 0, 5);
        if ($za === '' || $za !== $zb) return '';
        if (Identity::nameMatch((string) $a['name'], (string) $b['name']) >= 0.8) return 'the same ZIP and the same name';
        $num = function ($x) { $v = json_decode((string) $x, true); $s = is_string($v) ? $v : (string) $x; return preg_match('/^\s*(\d+)\s+(\S+)/', $s, $m) ? $m[1] . ' ' . strtolower($m[2]) : ''; };
        $na = $num($a['address'] ?? ''); $nb = $num($b['address'] ?? '');
        if ($na !== '' && $na === $nb) return 'the same ZIP and the same street address';
        return '';
    }

    /** Asked before about this pair, by anyone, whatever came of it. */
    private static function asked(PDO $pdo, int $a, int $b): bool
    {
        $st = $pdo->prepare("SELECT 1 FROM suggestions WHERE kind = 'same' AND ((entity_id = ? AND same_as_id = ?) OR (entity_id = ? AND same_as_id = ?)) LIMIT 1");
        $st->execute([$a, $b, $b, $a]);
        return (bool) $st->fetchColumn();
    }
}
