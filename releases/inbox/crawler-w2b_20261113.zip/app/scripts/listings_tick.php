<?php
// app/scripts/listings_tick.php — The listings pipeline's pass (decisions/0076, 0133 Phase 5): the crawler's waiting
// listings are matched again, the same business merged, and the ready ones published by rule, without anyone opening
// Review (which runs the same pass). Sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('listings_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/crawler/AutoImport.php';
$pdo = Database::connection();
$r = AutoImport::advance($pdo, 150);
require_once __DIR__ . '/../lib/CategoryClassifier.php';
[$cc, $ca, $cs] = CategoryClassifier::reclassifyTick($pdo, 200);   // listings already live (decisions/0024 §4)
if ($cc) echo "Categories: $cc checked, $ca corrected, $cs for a person.\n";
// the trust record (decisions/0157 §5): what became of the finds each site showed
require_once __DIR__ . '/../lib/crawler/Sources.php';
[$tOk, $tBad] = Sources::tallyTrust($pdo);
if ($tOk || $tBad) echo "Sources: $tOk borne out, $tBad shown wrong.\n";
// the second tier (decisions/0157): a few finds the free steps couldn't settle, looked up by Claude while its feature is on
require_once __DIR__ . '/../lib/crawler/SecondTier.php';
$st2 = SecondTier::settleTick($pdo, 3);
$scans = SecondTier::scanTick($pdo, 2);   // scanned PDFs, read by AWS Textract while its feature is on; the worker reads their text
if ($scans) echo "Scans read by Textract: $scans.\n";
if ($st2['published'] || $st2['closed'] || $st2['unsure']) echo 'Second tier: ' . $st2['published'] . ' published, ' . $st2['closed'] . ' turned down as closed, ' . $st2['unsure'] . " left for a person.\n";
// live listings that are one business (review E24, decisions/0160 W2): offered in Review as "Same business", never merged by itself
require_once __DIR__ . '/../lib/crawler/LiveDupes.php';
try { $dd = LiveDupes::tick($pdo, 5); if ($dd['offered']) echo 'Live duplicates: ' . $dd['offered'] . " pair(s) sent to Review.\n"; } catch (Throwable $e) { error_log('LiveDupes: ' . $e->getMessage()); }
echo 'Checked ' . $r['checked'] . ' waiting listings: ' . $r['published'] . ' published, ' . $r['merged'] . ' merged with ones we have, '
    . ($r['covered'] ?? 0) . " already covered.\n";
