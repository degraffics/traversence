<?php
// /admin/reports.php — reports of community posts and groups (decisions/0047). Remove, dismiss, or restore.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/Reports.php';

$pdo = Database::connection();
$me = tv_crawler_require_admin($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$ready = Reports::ready($pdo) && Community::ready($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $ready) {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        Reports::decide($pdo, (int) $me['id'], (string) ($_POST['kind'] ?? ''), (int) ($_POST['id'] ?? 0), (string) ($_POST['what'] ?? ''));
        $_SESSION['rep_flash'] = [true, 'Done.'];
    } catch (InvalidArgumentException $e) {
        $_SESSION['rep_flash'] = [false, $e->getMessage()];
    }
    header('Location: /admin/reports.php' . (!empty($_GET['embed']) ? '?embed=1' : ''));   // inside Pulse's tool panel, it stays there
    exit;
}
$flash = $_SESSION['rep_flash'] ?? null;
unset($_SESSION['rep_flash']);
$items = $ready ? Reports::open($pdo) : [];

tv_page_start('Reports', ['crumbs' => [['Home', '/'], ['Admin', '/admin/'], ['Reports']]]);
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
?>
<style>
  .rp{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem 1.1rem;margin-top:.8rem}
  .rp-b{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;background:#FFFBF2;border-radius:.6rem;padding:.35rem .8rem;cursor:pointer}
  .rp-b.bad{background:#991B1B;border-color:#991B1B;color:#fff}.rp-s{font-size:.75rem;color:#8A7355}
</style>
<div class="max-w-3xl">
  <h1 class="font-serif font-bold text-2xl text-[#3E2B1F]">Reports</h1>
  <p class="text-sm text-[#5C4632] mt-1">What people reported: posts, groups, conversations, comments, journeys, experiences and listing messages. A post reported by 3 people is hidden until you decide. Reporters' names are never shown to the person reported.</p>
  <?php if ($flash): ?><p class="text-sm mt-2" data-tv-flash="<?= $flash[0] ? 'ok' : 'error' ?>"><?= $e($flash[1]) ?></p><?php endif; ?>
  <?php if (!$ready): ?>
    <p class="rp text-sm">Run <code>app/migrations/2026-10-01_reports.sql</code> (and the community groups one) first.</p>
  <?php elseif (!$items): ?>
    <p class="rp text-sm">Nothing reported. All clear.</p>
  <?php endif; foreach ($items as $it): ?>
  <div class="rp">
    <div class="flex justify-between gap-2 flex-wrap">
      <b class="text-[#3E2B1F]"><?= $it['kind'] === 'lost' ? $e($it['where']) : (!empty($it['gone']) ? $e(Reports::KIND_LABEL[$it['kind']] ?? $it['where']) . ' · gone'
          : ($it['kind'] === 'group' ? 'Group' : ($it['kind'] === 'thread' ? 'Conversation (last messages)' : ($it['kind'] === 'biz_message' ? $e($it['where']) . ' · from ' . $e($it['author'])
          : ($it['kind'] === 'group_post' ? 'Post in ' . $e($it['where']) : $e($it['where']) . ($it['author'] ? ' · by ' . $e($it['author']) : '')))))) ?></b>
      <span class="rp-s"><?= (int) $it['count'] ?> report<?= $it['count'] === 1 ? '' : 's' ?> · since <?= $e(substr($it['first_at'], 0, 16)) ?><?= $it['hidden'] ? ' · <b style="color:#991B1B">hidden now</b>' : '' ?></span>
    </div>
    <?php if ($it['author'] && $it['kind'] !== 'biz_message'): ?><p class="rp-s mt-1">By <a class="underline" href="/user/profile.php?id=<?= (int) $it['author_id'] ?>"><?= $e($it['author']) ?></a></p><?php endif; ?>
    <p class="text-sm mt-2" style="white-space:pre-line"><?= $e(mb_strimwidth($it['text'], 0, 600, '…')) ?></p>
    <ul class="rp-s mt-2">
      <?php foreach ($it['reports'] as $r): ?><li>• <?= $e(Reports::label((string) $r['reason'])) ?><?= $r['note'] ? ': ' . $e($r['note']) : '' ?></li><?php endforeach; ?>
    </ul>
    <form method="post" class="flex flex-wrap gap-2 mt-3">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="kind" value="<?= $e($it['kind']) ?>"><input type="hidden" name="id" value="<?= (int) $it['id'] ?>">
      <?php if (empty($it['gone']) && !in_array($it['kind'], ['thread', 'biz_message'], true)): ?><button class="rp-b bad" name="what" value="remove"><?= ['group' => 'Hide group', 'journey' => 'Hide journey', 'experience' => 'Hide experience', 'journey_comment' => 'Hide comment', 'content_comment' => 'Hide comment'][$it['kind']] ?? 'Remove post' ?></button><?php endif; ?>
      <?php if ($it['hidden'] && empty($it['gone'])): ?><button class="rp-b" name="what" value="restore">Restore and close</button><?php endif; ?>
      <button class="rp-b" name="what" value="dismiss"><?= $it['kind'] === 'lost' ? 'Dismiss all ' . (int) $it['count'] : 'Dismiss' . ($it['hidden'] ? ' (leave hidden)' : '') ?></button>
      <?php if ($it['kind'] === 'biz_message'): ?><span class="rp-s">Repeated mislabelling: talk to the listing's managers, or remove their access.</span><?php elseif ($it['kind'] === 'thread'): ?><span class="rp-s">Block or suspend the sender from their profile if needed.</span><?php elseif (!empty($it['gone'])): ?><?php elseif (!empty($it['url'])): ?><a class="rp-b" href="<?= $e($it['url']) ?>" target="_blank">Open it</a><?php elseif ($it['group_id']): ?><a class="rp-b" href="/community/group.php?id=<?= (int) $it['group_id'] ?>">Open group</a><?php endif; ?>
    </form>
  </div>
  <?php endforeach; ?>
</div>
<?php tv_page_end();
