<?php
// admin/api/pulse.php — the admin Pulse's actions (decisions/0105). POST JSON:
//   {do: case, key}                        the case for the drawer: number, history, who it can go to
//   {do: done|undo|mine|letgo|escalate, key}
//   {do: assign, key, to}                  to = a staff member's user id
//   {do: post, key, mode: reply|team, body} Post on a case: reply to the sender (email), or a note to the team
//   {do: post, dept, body}                 a post to a department's stream ('' = everyone)
//   {do: step, key, n, on, label}         ticks a step of the case's procedure by hand
//   {do: manage, key, what, args}         orders: resend, pay, due, note, void; notes and posts: *_edit, *_delete (your own)
//   {do: vendor, key: order:ID, job}       adds a vendor job without changing the stage
//   {do: parse4, text} / {do: import4, key, text, order_for}  Paste from 4OVER: read the page, then save it
//   {do: vjob, key: order:ID, id, job}     updates a vendor job (status, tracking, completion date, costs, the item it's for)
//   {do: settings, route: {source: dept}, sla: {severity: hours}, report_to, report_hour}  Stream settings
//   {do: report_preview} / {do: report_copy}  the daily report: see today's, or email a copy now
//   {do: stage, key: order:ID, stage, tracking}  moves an order on (ClientOrders::setStage; the client is told)
// Staff only; the items themselves are only shown to those whose role reaches their source.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/Pulse.php';
require_once __DIR__ . '/../../../app/lib/StaffLogin.php';
require_once __DIR__ . '/../../../app/lib/crawler/IntakeStager.php';

$pdo = Database::connection();
$me = Auth::requireAuth();
if (!IntakeStager::canUseIntake($pdo, $me)) Response::error('Our team only.', 403, 'forbidden');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') Response::error('POST required.', 405, 'method');
if (!hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) Response::error('This page had expired. Reload it.', 403, 'csrf');
if (!Pulse::ready($pdo)) Response::error('Run the Pulse update (2026-12-14_pulse.sql) first.', 409, 'not_ready');
$in = Response::jsonBody();
$uid = (int) $me['id'];
$staff = StaffLogin::inSession($pdo) ?: null;
$key = (string) ($in['key'] ?? '');
try {
    switch ($do = (string) ($in['do'] ?? '')) {
        case 'case': Response::json(['ok' => true, 'me' => $uid] + Pulse::caseOf($pdo, $key));
        case 'post':
            if (!Pulse::casesReady($pdo)) throw new RuntimeException('Run the Pulse update (2026-12-15_pulse_cases.sql) first.');
            $msg = Pulse::post($pdo, $staff, $uid, $key, (string) ($in['mode'] ?? 'team'), (string) ($in['body'] ?? ''), (string) ($in['dept'] ?? ''));
            Response::json(['ok' => true, 'message' => $msg] + ($key !== '' ? Pulse::caseOf($pdo, $key) : []));
        case 'step':
            Pulse::step($pdo, $key, (int) ($in['n'] ?? -1), !empty($in['on']), (string) ($in['label'] ?? ''), $uid);
            Response::json(['ok' => true] + Pulse::caseOf($pdo, $key));
        case 'manage':
            $msg = Pulse::manage($pdo, $key, (string) ($in['what'] ?? ''), (array) ($in['args'] ?? []), $uid);
            Response::json(['ok' => true, 'message' => $msg, 'me' => $uid] + (str_starts_with($key, 'post:') && str_ends_with((string) $in['what'], 'delete') ? [] : Pulse::caseOf($pdo, $key)));
        case 'vendor':
            if (!preg_match('/^order:(\d+)$/', $key, $vm)) throw new RuntimeException('That isn\'t an order.');
            $vj = (array) ($in['job'] ?? []);
            if (trim((string) ($vj['vendor'] ?? '')) === '' && empty($vj['vendor_order_id'])) throw new RuntimeException('Which printer or vendor has it?');
            Pulse::vendorJob($pdo, (int) $vm[1], $vj, $uid, $key);
            Response::json(['ok' => true, 'message' => 'Vendor job saved.'] + Pulse::caseOf($pdo, $key));
        case 'parse4':   // a pasted 4OVER order page: what's in it, and the client order each project matches
            require_once __DIR__ . '/../../../app/lib/VendorOrders.php';
            $pp = VendorOrders::parse4over((string) ($in['text'] ?? ''));
            Response::json(['ok' => true, 'parsed' => $pp] + VendorOrders::match4over($pdo, $pp));
        case 'import4':  // saves it (the page is read again here, never trusted from the browser)
            require_once __DIR__ . '/../../../app/lib/VendorOrders.php';
            if (!VendorOrders::ready($pdo)) throw new RuntimeException('Run the vendor orders update (2026-12-17_vendor_orders.sql) first.');
            $nn = VendorOrders::import4over($pdo, VendorOrders::parse4over((string) ($in['text'] ?? '')), array_map('intval', (array) ($in['order_for'] ?? [])), $uid);
            if ($key !== '') { Pulse::caseOf($pdo, $key); }
            Response::json(['ok' => true, 'message' => 'From 4OVER: ' . $nn['added'] . ' added, ' . $nn['updated'] . ' updated' . ($nn['skipped'] ? ', ' . $nn['skipped'] . ' not matched to an order' : '') . '.'] + ($key !== '' ? Pulse::caseOf($pdo, $key) : []));
        case 'vjob':   // updates a vendor job on this order: status, tracking, completion date, costs
            require_once __DIR__ . '/../../../app/lib/VendorOrders.php';
            if (!preg_match('/^order:(\d+)$/', $key, $vm)) throw new RuntimeException('That isn\'t an order.');
            $jb = VendorOrders::job($pdo, (int) ($in['id'] ?? 0));
            if (!$jb || (int) $jb['order_id'] !== (int) $vm[1]) throw new RuntimeException('That job isn\'t on this order.');
            VendorOrders::updateJob($pdo, (int) $jb['id'], (array) ($in['job'] ?? []), $uid);
            if (array_key_exists('line_id', (array) ($in['job'] ?? [])) && (int) $in['job']['line_id'] !== (int) $jb['line_id']) VendorOrders::setLine($pdo, (int) $jb['id'], (int) $in['job']['line_id'], $uid);
            Response::json(['ok' => true, 'message' => 'Vendor job updated.'] + Pulse::caseOf($pdo, $key));
        case 'settings':   // Stream settings: routing and clocks (a Director, an Executive or the Founder)
            Response::json(['ok' => true, 'message' => Pulse::saveSettings($pdo, $staff, $uid, $in)]);
        case 'report_preview':   // today's daily report as it would go now (links open Pulse; the preview sends nothing)
            require_once __DIR__ . '/../../../app/lib/DailyReport.php';
            Response::json(['ok' => true, 'html' => DailyReport::html(DailyReport::build($pdo, (int) (DailyReport::recipient($pdo)[0] ?? $uid)))]);
        case 'report_copy':      // an extra copy now, to the person it goes to (the 5 am one still goes)
            require_once __DIR__ . '/../../../app/lib/DailyReport.php';
            if (!Pulse::canSet($staff)) throw new RuntimeException('Only a Director, an Executive or the Founder sends the report.');
            Response::json(['ok' => true, 'message' => DailyReport::send($pdo, false)]);
        case 'stage':
            Pulse::stage($pdo, $key, (string) ($in['stage'] ?? ''), (string) ($in['tracking'] ?? ''), $uid, (array) ($in['job'] ?? []));
            Response::json(['ok' => true] + Pulse::caseOf($pdo, $key));
        default:
            Pulse::mark($pdo, $key, $do, $uid, (int) ($in['to'] ?? 0));
            Response::json(['ok' => true] + Pulse::caseOf($pdo, $key));
    }
} catch (RuntimeException | InvalidArgumentException $x) {   // the libraries refuse with either (Market::staffAct throws the second; site audit P11)
    Response::error($x->getMessage(), 422, 'invalid');
}
