<?php require_once __DIR__ . '/../app/ui/auth-nav.php'; require_once __DIR__ . '/../app/ui/social-buttons.php'; require_once __DIR__ . '/../app/lib/SignInLinks.php';
// back from Google (decisions/0085), Apple, Microsoft or Facebook (decisions/0090) with something to say
tv_google_session();   // first, before any output: the settings (.env), the database and the session
// signed in already (site audit P2, Jason 2026-11-08): on to where they were going, else their dashboard. Not while a
// social sign-in is coming back or one is waiting to be linked.
if (empty($_GET['google']) && empty($_GET['social']) && empty($_GET['link']) && Auth::currentUserId()) {
    $nx = GoogleAuth::safeNext((string) ($_GET['next'] ?? ''));
    header('Location: ' . ($nx !== '' ? $nx : '/user/dashboard.php'), true, 302); exit;
}
$gMsg = '';
$sWhy = (string) ($_GET['google'] ?? ($_GET['social'] ?? ''));
$sWho = isset($_GET['google']) ? 'Google' : SocialAuth::label(preg_replace('/[^a-z]/', '', (string) ($_GET['p'] ?? '')));
if ($sWhy === 'cancelled') $gMsg = "$sWho sign-in was cancelled. Try again, or sign in with your email and password.";
elseif ($sWhy === 'off') $gMsg = "Signing in with $sWho isn't available right now. Sign in with your email and password.";
elseif ($sWhy === 'error') {
    $k = isset($_GET['google']) ? 'tv_google_error' : 'tv_social_error';
    $gMsg = (string) ($_SESSION[$k] ?? "Signing in with $sWho didn't work. Try again."); unset($_SESSION[$k]);
}
// "I already have an account" (decisions/0090): the next sign-in links the one that was waiting
$lw = !empty($_GET['link']) ? SignInLinks::waiting() : null;
if ($lw) SignInLinks::want();
$tab = ($_GET['tab'] ?? '') === 'create' && !$lw ? 'create' : 'in'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign in or create an account — Traversence</title>
  <?php tv_nav_head(); ?>
</head>
<body class="bg-[#EFE3C8] text-[#3E2B1F] min-h-screen flex flex-col font-sans">
  <?php tv_nav_bar(); ?>
  <main class="flex-1 flex items-center justify-center py-8">
  <div class="au-card tv-bleed bg-[#E3D3AC] border border-[#3E2B1F]/40 rounded-lg sm:rounded-2xl px-6 py-7 sm:px-10 max-w-md w-full mx-[3px] sm:mx-4 shadow-xl">
    <h1 class="sr-only">Sign in or create an account</h1>
    <?php // one page, two tabs (Jason, 2026-11-05): Sign in | Create account; ?tab=create opens the second ?>
    <div class="au-tabs" role="tablist" aria-label="Sign in or create an account">
      <button type="button" role="tab" class="au-t" id="t-in" data-tab="in" aria-controls="p-in" aria-selected="<?= $tab === 'in' ? 'true' : 'false' ?>">Sign in</button>
      <button type="button" role="tab" class="au-t" id="t-up" data-tab="create" aria-controls="p-up" aria-selected="<?= $tab === 'create' ? 'true' : 'false' ?>">Create account</button>
    </div>
    <?php if ($gMsg !== ''): ?><p class="text-sm text-red-700 text-center mb-3" role="status"><?= htmlspecialchars($gMsg) ?></p><?php endif; ?>
    <?php if ($lw): ?><p class="text-sm text-center mb-4 rounded-lg p-2" style="background:#F7F1E3;border:1px solid #CBB98D" role="status">Sign in to the Traversence account you already have, any way you usually do. Your <?= htmlspecialchars($lw['label']) ?> account (<?= htmlspecialchars($lw['email']) ?>) will be linked to it.</p><?php endif; ?>
    <div id="p-in" role="tabpanel" aria-labelledby="t-in"<?= $tab === 'in' ? '' : ' hidden' ?>>
    <form id="login-form" class="space-y-3" novalidate>
      <label class="block text-xs font-semibold text-[#5C4632]" for="email">Email <span class="font-normal text-[#8A7355]">(or your staff ID)</span></label>
      <input type="email" id="email" autocomplete="username" placeholder="you@example.com" required style="margin-top:.25rem" value="<?= htmlspecialchars(mb_substr((string) ($_GET['email'] ?? ''), 0, 190)) ?>"
             class="w-full border border-[#CBB98D] rounded-lg px-3 py-2.5 text-sm bg-[#F7F1E3]">
      <label class="block text-xs font-semibold text-[#5C4632] pt-1" for="password">Password</label>
      <div class="relative" style="margin-top:.25rem">
        <input type="password" id="password" autocomplete="current-password" required
               class="w-full border border-[#CBB98D] rounded-lg px-3 py-2.5 text-sm bg-[#F7F1E3]">
      </div>
    </form>
    </div>
    <div id="p-up" role="tabpanel" aria-labelledby="t-up"<?= $tab === 'create' ? '' : ' hidden' ?>>
    <form id="register-form" class="space-y-4" novalidate>
      <?php // step 1 of creating an account (Jason, 2026-11-05): just these; the rest comes after the email link ?>
      <label class="block text-xs font-semibold text-[#5C4632]" for="r_email">Email</label>
      <input type="email" id="r_email" autocomplete="email" placeholder="you@example.com" required style="margin-top:.25rem" value="<?= htmlspecialchars(mb_substr((string) ($_GET['email'] ?? ''), 0, 190)) ?>"
             class="w-full border border-[#CBB98D] rounded-lg px-3 py-2.5 text-sm bg-[#F7F1E3]">
      <label class="block text-xs font-semibold text-[#5C4632]" for="r_password">Password</label>
      <input type="password" id="r_password" required minlength="8" data-pw-strong autocomplete="new-password" style="margin-top:.25rem"
             class="w-full border border-[#CBB98D] rounded-lg px-3 py-2.5 text-sm bg-[#F7F1E3]">
      <label class="block text-xs font-semibold text-[#5C4632]" for="r_password2">Password again</label>
      <input type="password" id="r_password2" required data-pw-match="#r_password" autocomplete="new-password" style="margin-top:.25rem"
             class="w-full border border-[#CBB98D] rounded-lg px-3 py-2.5 text-sm bg-[#F7F1E3]">
      <label class="flex items-start gap-2 text-sm text-[#3E2B1F]">
        <input type="checkbox" id="over_18" required class="mt-0.5 accent-amber-700 w-4 h-4">
        <span>I am 18 years old or older. <span class="text-xs text-[#8A7355]">Traversence accounts are for adults, 18 and up.</span></span>
      </label>
      <div id="r_homew" hidden>
        <label class="block text-xs font-semibold text-[#5C4632]" for="r_home">Where do you live?</label>
        <select id="r_home" style="margin-top:.25rem" class="w-full border border-[#CBB98D] rounded-lg px-3 py-2.5 text-sm bg-[#F7F1E3]">
          <option value="">Choose…</option><option value="US">United States</option><option value="CA">Canada</option><option value="MX">Mexico</option>
          <option value="EUUK">A country in the EU or the UK</option><option value="other">Another country</option>
        </select>
      </div>
      <p class="text-xs text-[#5C4632]">By creating an account you accept our <a class="underline" href="/terms.php" target="_blank">Terms of Use</a> and <a class="underline" href="/privacy.php" target="_blank">Privacy Policy</a>.</p>
    </form>
    </div>
    <?php require_once __DIR__ . '/../app/lib/Captcha.php'; echo Captcha::widget(); ?>
    <button type="submit" form="login-form" id="go-in" class="au-go w-full bg-[#92400E] text-white rounded-lg py-2.5 text-sm font-semibold tracking-wide uppercase hover:bg-[#7C2D12] transition" style="margin-top:1rem"<?= $tab === 'in' ? '' : ' hidden' ?>>Sign in</button>
    <button type="submit" form="register-form" id="go-up" class="au-go w-full bg-[#C75A28] text-white rounded-lg py-2.5 text-sm font-semibold tracking-wide uppercase hover:bg-[#A8481F] transition" style="margin-top:1rem"<?= $tab === 'create' ? '' : ' hidden' ?>>Create account</button>
    <div id="status" class="text-sm text-center mt-3"></div>
    <div id="au-sent" class="text-center" hidden>
      <p class="text-lg font-serif font-bold mt-2">Check your email</p>
      <p class="text-sm mt-2">We sent a link to <b id="au-sent-to"></b>. Open it to confirm your address, answer a few quick questions, and you're signed in.</p>
      <p class="text-xs text-[#8A7355] mt-2">No email after a few minutes? Check your spam folder, or</p>
      <button type="button" id="au-resend" class="mt-2 border border-[#92400E] text-[#92400E] rounded-lg px-4 py-2 text-sm font-semibold">Send the link again</button>
    </div>
    <p class="text-sm mt-4 font-serif text-center" data-for="in"<?= $tab === 'in' ? '' : ' hidden' ?>><a href="forgot-password.php" class="text-[#B45309] hover:text-[#92400E] font-semibold">Forgot password?</a></p>
    <?= tv_social_buttons('Continue with', (string) ($_GET['next'] ?? '')) ?>
  </div>
  <style>
    /* the tabs fill the card's top edge to edge, no margin (Jason, 2026-11-05): the card's padding is pulled back and its
       rounded corners clip them */
    .au-card{overflow:hidden;padding:1.75rem 1.5rem;position:relative}
    .au-card .sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;margin:0;padding:0}
    @media (min-width:640px){.au-card{padding-left:2.5rem;padding-right:2.5rem}}
    .au-tabs{display:flex;gap:0;margin:-1.75rem -1.5rem 1.4rem;border-bottom:2px solid #C75A28}
    @media (min-width:640px){.au-tabs{margin-left:-2.5rem;margin-right:-2.5rem}}
    .au-t{flex:1;border:0;border-radius:0;background:#C75A28;color:#FCE9C4;padding:.85rem .4rem;font:800 .9rem/1.1 system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;margin-bottom:-2px}
    .au-t[aria-selected=true]{background:#E3D3AC;color:#2A1B12;box-shadow:inset 0 3px 0 #C75A28}
    .au-t:focus-visible{outline:2px solid #3E2B1F;outline-offset:2px}
  </style>
  </main>
  <?php tv_nav_foot(); ?>
  <script>
    const statusEl = document.getElementById('status');
    let csrfToken = null;

    async function getCsrfToken() {
      const res = await fetch('/api/auth/session.php', { credentials: 'include' });
      const data = await res.json();
      return data.csrf_token;
    }

    function togglePasswordVisibility(inputId, btn) {
      const input = document.getElementById(inputId);
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.textContent = showing ? 'Show' : 'Hide';
    }

    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      // a staff ID (TRV-0001) belongs on the staff sign-in (decisions/0100): take it there, filled in
      const sid = email.match(/^(?:trv)?[\s-]*(\d{1,4})$/i);
      if (sid) {   // the staff ID and password go straight to the staff sign-in; it asks for the emailed code next
        const id = 'TRV-' + ('000' + sid[1]).slice(-4);
        if (password === '') { location.href = '/admin/login.php?sid=' + encodeURIComponent(id); return; }
        const t = csrfToken || await getCsrfToken();
        const f = document.createElement('form'); f.method = 'post'; const nx = new URLSearchParams(location.search).get('next') || ''; f.action = '/admin/login.php' + (nx.indexOf('/admin') === 0 ? '?next=' + encodeURIComponent(nx) : '');
        [['csrf', t], ['do', 'password'], ['staff_id', id], ['password', password]].forEach(([k, v]) => { const i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; f.appendChild(i); });
        document.body.appendChild(f); f.submit(); return;
      }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { statusEl.textContent = 'Enter your email address.'; statusEl.className = 'text-sm text-center mt-4 text-red-700'; return; }
      if (password === '') { statusEl.textContent = 'Enter your password.'; statusEl.className = 'text-sm text-center mt-4 text-red-700'; return; }
      const submitBtn = document.getElementById('go-in');
      if (window.TvAsk) TvAsk.busy(submitBtn, true); else submitBtn.disabled = true;
      statusEl.textContent = '';

      try {
        if (!csrfToken) {
          csrfToken = await getCsrfToken();
        }
        const res = await fetch('/api/auth/login.php', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify({ email, password, captcha: window.tvCaptchaWait ? await tvCaptchaWait() : (window.tvCaptcha ? tvCaptcha() : '') }),
        });
        const data = await res.json();

        if (data?.error?.code === 'closing') { window.location.href = '/user/restore-account.php'; return; }
        if (data?.error?.code === 'unconfirmed') {   // decisions/0014: confirm first; the link again, right here
          window.tvCaptchaReset && tvCaptchaReset();
          statusEl.textContent = data.error.message; statusEl.className = 'text-sm text-center mt-4 text-red-700';
          const rb = document.createElement('button'); rb.type = 'button'; rb.className = 'block mx-auto mt-2 border border-[#92400E] text-[#92400E] rounded-lg px-4 py-2 text-sm font-semibold'; rb.textContent = 'Send the link again';
          rb.addEventListener('click', () => auResend(email, rb)); statusEl.appendChild(rb);
          if (window.TvAsk) TvAsk.busy(submitBtn, false); submitBtn.disabled = false; return;
        }   // a closing account: Restore or keep closed
        if (res.ok && data.ok) {
          // ?next= brings people back to where they were (e.g. the claim page); only a path on this site
          const next = new URLSearchParams(location.search).get('next') || '';
          window.location.href = /^\/(?!\/)[^\s\\]*$/.test(next) ? next : '/user/dashboard.php';
          // Personal dashboard is now the real post-login destination —
          // the business listing portal (/listing/businessportal.php) is
          // reached from there via a nav tile, not landed on directly.
        } else {
          window.tvCaptchaReset && tvCaptchaReset();   // a captcha token works once
          statusEl.textContent = data?.error?.message || 'Sign in failed.';
          statusEl.className = 'text-sm text-center mt-4 text-red-700';
          if (window.TvAsk) TvAsk.busy(submitBtn, false); submitBtn.disabled = false;
        }
      } catch (err) {
        statusEl.textContent = 'Something went wrong. Please try again.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        if (window.TvAsk) TvAsk.busy(submitBtn, false); submitBtn.disabled = false;
      }
    });

    // the two tabs: one page, the form shown is the one you're using; the email you typed comes along
    function auTab(t) {
      const up = t === 'create';
      document.getElementById('p-in').hidden = up; document.getElementById('p-up').hidden = !up;
      document.getElementById('go-in').hidden = up; document.getElementById('go-up').hidden = !up;
      document.querySelectorAll('[data-for="in"]').forEach(el => { el.hidden = up; });
      document.getElementById('t-in').setAttribute('aria-selected', String(!up));
      document.getElementById('t-up').setAttribute('aria-selected', String(up));
      const from = document.getElementById(up ? 'email' : 'r_email'), to = document.getElementById(up ? 'r_email' : 'email');
      if (from && to && !to.value && from.value.indexOf('@') > 0) to.value = from.value;
      statusEl.textContent = '';
      try { const u = new URL(location.href); if (up) u.searchParams.set('tab', 'create'); else u.searchParams.delete('tab'); history.replaceState(null, '', u); } catch (x) {}
    }
    document.querySelectorAll('.au-t').forEach(b => b.addEventListener('click', () => auTab(b.getAttribute('data-tab'))));

    // Create account: step 1 only (Jason, 2026-11-05); the questions come after the email link (verify-email.php)
    function auHome() {   // the extra question, only when it was asked (the EU/UK check, decisions/0027)
      const w = document.getElementById('r_homew'), v = document.getElementById('r_home').value;
      return (w && !w.hidden && v) ? { home_country: v === 'other' ? 'other' : v } : {};
    }
    async function auResend(email, btn) {
      if (window.TvAsk) TvAsk.busy(btn, true);
      try {
        if (!csrfToken) csrfToken = await getCsrfToken();
        const r = await fetch('/api/auth/resend-confirmation.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken }, body: JSON.stringify({ email }) });
        const d = await r.json();
        if (window.TvAsk) { TvAsk.busy(btn, false); TvAsk.say(d.ok ? d.message : ((d.error && d.error.message) || 'That didn\'t work.'), { anchor: btn, bad: !d.ok }); }
      } catch (e) { if (window.TvAsk) { TvAsk.busy(btn, false); TvAsk.say('Something went wrong. Try again.', { anchor: btn, bad: true }); } }
    }
    document.getElementById('au-resend').addEventListener('click', e => auResend(document.getElementById('au-sent-to').textContent, e.currentTarget));
    document.getElementById('register-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target, btn = document.getElementById('go-up');
      if (!f.checkValidity()) { f.reportValidity(); return; }   // the site's own notice says which field (js/tv-ask.js)
      if (window.TvAsk) TvAsk.busy(btn, true); else btn.disabled = true;
      statusEl.textContent = '';
      const done = () => { if (window.TvAsk) TvAsk.busy(btn, false); btn.disabled = false; };
      try {
        if (!csrfToken) csrfToken = await getCsrfToken();
        const email = document.getElementById('r_email').value.trim();
        const res = await fetch('/api/auth/register.php', {
          method: 'POST', credentials: 'include',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
          body: JSON.stringify(Object.assign({ email, password: document.getElementById('r_password').value, over_18: document.getElementById('over_18').checked, captcha: window.tvCaptchaWait ? await tvCaptchaWait() : (window.tvCaptcha ? tvCaptcha() : '') }, auHome())),
        });
        const data = await res.json();
        if (res.ok && data.ok) {
          // step 2: check your email (the tabs, the form and the other sign-ins step aside)
          document.querySelectorAll('.au-tabs, #p-up, #go-up, .cf-turnstile, .tv-social, .tv-gbtn').forEach(el => { el.hidden = true; el.style.display = 'none'; });
          document.getElementById('au-sent-to').textContent = data.email || email;
          document.getElementById('au-sent').hidden = false;
        } else if (data?.error?.code === 'ask_home') {   // decisions/0027: connecting from the EU/UK, so one more question
          window.tvCaptchaReset && tvCaptchaReset();
          document.getElementById('r_homew').hidden = false; document.getElementById('r_home').required = true;
          if (window.TvAsk) TvAsk.say('One more question: where do you live?', { anchor: document.getElementById('r_home') });
          done();
        } else {
          window.tvCaptchaReset && tvCaptchaReset();
          statusEl.textContent = data?.error?.message || 'Creating your account didn\'t work.';
          statusEl.className = 'text-sm text-center mt-4 text-red-700';
          done();
        }
      } catch (err) {
        statusEl.textContent = 'Something went wrong. Please try again.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        done();
      }
    });
  </script>
</body>
</html>
