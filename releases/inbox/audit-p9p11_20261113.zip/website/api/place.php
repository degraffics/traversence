<?php
// api/place.php
//
// The shared "where is this?" resolver (spec: Geographic Hierarchy, Shared Place
// Context). Public, read-only, no session.
//
//   GET /api/place.php?action=hubs
//       -> {success, hubs:[{slug,name,hub_number,status}]}       (region picker)
//   GET /api/place.php?hub=<slug> | ?geo=<slug> | ?cluster=<slug|id>
//       -> {success, place:{level,slug,label,lat,lon,hub}}
//   GET /api/place.php?zip=85936
//       -> {success, place:{level:'zip',label,city,state,zip,lat,lon,hub}}
//   GET /api/place.php?lat=..&lon=..[&accuracy=meters]           (device guess)
//       -> {success, place:{level:'zip',...,approximate:bool}}
//
// A device guess is ONLY a suggestion: this endpoint never applies anything.
// The nearest ZIP centroid names the spot ("Looks like St. Johns, AZ").

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');

require_once __DIR__ . '/../../app/lib/Database.php';
require_once __DIR__ . '/../../app/lib/PlaceScope.php';

function place_out(array $payload): void
{
    echo json_encode(['success' => true] + $payload);
    exit;
}

function place_fail(int $code, string $msg): void
{
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $msg]);
    exit;
}

/** Hub that owns a county (via hub_counties). Null if unknown or table missing. */
function place_hub_for_county(PDO $pdo, ?string $state, ?string $county): ?array
{
    if ($state === null || $county === null || $state === '' || $county === '') {
        return null;
    }
    try {
        $st = $pdo->prepare(
            'SELECT h.slug, h.name FROM hub_counties hc JOIN hubs h ON h.hub_number = hc.hub_number
              WHERE hc.state = ? AND hc.county = ? LIMIT 1'
        );
        $st->execute([$state, $county]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ? ['slug' => $row['slug'], 'name' => $row['name']] : null;
    } catch (Throwable $e) {
        return null;
    }
}

function place_zip_place(PDO $pdo, array $z): array
{
    $city  = trim((string)$z['city']);
    $state = trim((string)$z['state']);
    return [
        'level' => 'zip',
        'slug'  => null,
        'label' => trim($city . ($state !== '' ? ', ' . $state : '')),
        'city'  => $city,
        'state' => $state,
        'zip'   => trim((string)$z['zip']),
        'lat'   => $z['latitude'] !== null ? (float)$z['latitude'] : null,
        'lon'   => $z['longitude'] !== null ? (float)$z['longitude'] : null,
        'hub'   => place_hub_for_county($pdo, $state, $z['county'] ?? null),
        'cluster' => place_cluster_for_zip($pdo, trim((string)$z['zip']), $z['latitude'] ?? null, $z['longitude'] ?? null),
        'town'  => place_town_for_zip($pdo, trim((string)$z['zip'])),
    ];
}

/**
 * The town a ZIP is (the anchors table, the towns guides are written for): {slug, name} or null. Auto-detect names the town
 * it found, never its greater area (Jason, 2026-11-12: "in st. johns, but i expected the ST. johns town not the greater area").
 */
function place_town_for_zip(PDO $pdo, string $zip): ?array
{
    if ($zip === '') return null;
    try {
        $st = $pdo->prepare("SELECT slug, name FROM anchors WHERE CONCAT(',', REPLACE(zips, ' ', ''), ',') LIKE ? LIMIT 1");
        $st->execute(['%,' . $zip . ',%']);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ? ['slug' => (string)$r['slug'], 'name' => (string)$r['name']] : null;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * The town area (micro cluster) a ZIP belongs to, so a ZIP or a device location can open Let's Explore for it:
 * the cluster whose ZIPs include it, else the nearest cluster within 40 miles. {slug, label} or null.
 */
function place_cluster_for_zip(PDO $pdo, string $zip, $lat, $lon): ?array
{
    try {
        $st = $pdo->prepare("SELECT slug, name FROM micro_clusters WHERE slug IS NOT NULL AND slug <> '' AND (TRIM(primary_zip) = ? OR associated_zips LIKE ?) LIMIT 1");
        $st->execute([$zip, '%"' . $zip . '"%']);
        if ($r = $st->fetch(PDO::FETCH_ASSOC)) return ['slug' => (string)$r['slug'], 'label' => PlaceScope::publicName((string)$r['name'])];
        if ($lat === null || $lon === null) return null;
        $st = $pdo->prepare("SELECT mc.slug, mc.name, z.latitude AS la, z.longitude AS lo FROM micro_clusters mc
                               JOIN zip_coordinates z ON TRIM(z.zip) = TRIM(mc.primary_zip)
                              WHERE mc.slug IS NOT NULL AND mc.slug <> '' AND z.latitude BETWEEN ? AND ? AND z.longitude BETWEEN ? AND ?");
        $st->execute([(float)$lat - 0.6, (float)$lat + 0.6, (float)$lon - 0.75, (float)$lon + 0.75]);
        $best = null; $bd = 40.0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $dy = ((float)$r['la'] - (float)$lat) * 69.0; $dx = ((float)$r['lo'] - (float)$lon) * 69.0 * cos(deg2rad((float)$lat));
            $d = sqrt($dx * $dx + $dy * $dy);
            if ($d < $bd) { $bd = $d; $best = $r; }
        }
        return $best ? ['slug' => (string)$best['slug'], 'label' => PlaceScope::publicName((string)$best['name'])] : null;
    } catch (Throwable $e) {
        return null;
    }
}

try {
    $pdo = Database::connection();
    $action = (string)($_GET['action'] ?? '');

    // ---- Narrowing choices for the directory funnel ----
    //   ?action=narrow                     -> live hubs (root)
    //   ?action=narrow&hub=|geo=|cluster=  -> that region's children + its ancestors
    // {success, place:{level,slug,label}|null, trail:[{level,slug,name}] (top-down,
    //  ancestors only), children:[{level,slug,name,count}] (count > 0 only)}
    if ($action === 'narrow') {
        $statuses = "'" . implode("','", PlaceScope::PUBLIC_STATUSES) . "'";
        $base = "e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ($statuses)";
        $scope = PlaceScope::resolve($pdo, $_GET);
        $trail = [];
        $children = [];
        $place = null;

        if ($scope === null) {
            try {
                $hubs = $pdo->query("SELECT slug, name FROM hubs WHERE status <> 'planned' ORDER BY hub_number")->fetchAll(PDO::FETCH_ASSOC);
            } catch (Throwable $e) {
                $hubs = $pdo->query('SELECT slug, name FROM hubs ORDER BY hub_number')->fetchAll(PDO::FETCH_ASSOC);
            }
            foreach ($hubs as $h) {
                $hs = PlaceScope::resolve($pdo, ['hub' => $h['slug']]);
                if (!$hs || !$hs['found']) { continue; }
                $n = (int)$pdo->query("SELECT COUNT(*) FROM entities e WHERE $base AND " . $hs['sql'])->fetchColumn();
                if ($n > 0) { $children[] = ['level' => 'hub', 'slug' => $h['slug'], 'name' => $h['name'], 'count' => $n]; }
            }
        } else {
            if (!$scope['found']) { place_fail(404, 'Unknown region.'); }
            $place = ['level' => $scope['level'], 'slug' => $scope['slug'], 'label' => $scope['name']];
            $hubRow = null;
            if ($scope['hub_number'] !== null) {
                $st = $pdo->prepare('SELECT slug, name FROM hubs WHERE hub_number = ? LIMIT 1');
                $st->execute([$scope['hub_number']]);
                $hubRow = $st->fetch(PDO::FETCH_ASSOC) ?: null;
            }
            if ($scope['level'] === 'hub') {
                $st = $pdo->prepare(
                    "SELECT g.slug, g.name, COUNT(e.id) AS n
                       FROM geo_hubs g
                       LEFT JOIN micro_clusters mc ON mc.geo_hub_id = g.id
                       LEFT JOIN entities e ON e.micro_cluster_id = mc.id AND $base
                      WHERE g.hub_id = ? GROUP BY g.id, g.slug, g.name");
                $st->execute([$scope['id']]);
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    if ((int)$r['n'] > 0) { $children[] = ['level' => 'geo_hub', 'slug' => $r['slug'], 'name' => $r['name'], 'count' => (int)$r['n']]; }
                }
            } elseif ($scope['level'] === 'geo_hub') {
                if ($hubRow) { $trail[] = ['level' => 'hub', 'slug' => $hubRow['slug'], 'name' => $hubRow['name']]; }
                $st = $pdo->prepare(
                    "SELECT mc.id, mc.name, mc.primary_zip, z.city AS zc, z.state AS zs, COUNT(e.id) AS n
                       FROM micro_clusters mc
                       LEFT JOIN zip_coordinates z ON TRIM(z.zip) COLLATE utf8mb4_general_ci = TRIM(mc.primary_zip) COLLATE utf8mb4_general_ci
                       LEFT JOIN entities e ON e.micro_cluster_id = mc.id AND $base
                      WHERE mc.geo_hub_id = ? GROUP BY mc.id, mc.name, mc.primary_zip, z.city, z.state");
                $st->execute([$scope['id']]);
                $rows = $st->fetchAll(PDO::FETCH_ASSOC);
                // Auto-seeded clusters are named after a ZIP; show the town instead (with the
                // ZIP only where two clusters share a town).
                $labels = [];
                foreach ($rows as $r) {
                    $nm = PlaceScope::publicName($r['name']);
                    if (preg_match('/^ZIP \\d{5}\\b/', $nm) && trim((string)$r['zc']) !== '') { $nm = trim($r['zc']); }
                    $labels[(int)$r['id']] = $nm;
                }
                $dupe = array_count_values($labels);
                foreach ($rows as $r) {
                    if ((int)$r['n'] <= 0) { continue; }
                    $nm = $labels[(int)$r['id']];
                    if ($dupe[$nm] > 1 && trim((string)$r['primary_zip']) !== '') { $nm .= ' (' . trim($r['primary_zip']) . ')'; }
                    $children[] = ['level' => 'cluster', 'slug' => (string)(int)$r['id'], 'name' => $nm, 'count' => (int)$r['n']];
                }
            } else { // cluster (a leaf)
                if ($hubRow) { $trail[] = ['level' => 'hub', 'slug' => $hubRow['slug'], 'name' => $hubRow['name']]; }
                $st = $pdo->prepare('SELECT g.slug, g.name FROM micro_clusters mc JOIN geo_hubs g ON g.id = mc.geo_hub_id WHERE mc.id = ? LIMIT 1');
                $st->execute([$scope['id']]);
                if ($g = $st->fetch(PDO::FETCH_ASSOC)) { $trail[] = ['level' => 'geo_hub', 'slug' => $g['slug'], 'name' => $g['name']]; }
            }
        }
        usort($children, function ($a, $b) { return ($b['count'] <=> $a['count']) ?: strcmp($a['name'], $b['name']); });
        place_out(['place' => $place, 'trail' => $trail, 'children' => array_slice($children, 0, 200)]);
    }

    // ---- States and towns that have listings (first-visit prompts) ----
    //   ?action=states            -> {states:[{code,count}]}, alphabetical
    //   ?action=towns&state=AZ    -> {towns:[{city,count}]}, alphabetical
    if ($action === 'states' || $action === 'towns') {
        $statuses = "'" . implode("','", PlaceScope::PUBLIC_STATUSES) . "'";
        $baseE = "e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ($statuses)";
        if ($action === 'states') {
            $rows = $pdo->query(
                "SELECT JSON_UNQUOTE(ms.meta_value) AS state, COUNT(*) AS n
                   FROM entities e JOIN entity_metadata ms ON ms.entity_id = e.id AND ms.meta_key = 'state'
                  WHERE $baseE GROUP BY JSON_UNQUOTE(ms.meta_value)"
            )->fetchAll(PDO::FETCH_ASSOC);
            $out = [];
            foreach ($rows as $r) {
                $code = strtoupper(trim((string)$r['state']));
                if (preg_match('/^[A-Z]{2}$/', $code)) { $out[$code] = ($out[$code] ?? 0) + (int)$r['n']; }
            }
            ksort($out);
            $list = [];
            foreach ($out as $code => $n) { $list[] = ['code' => $code, 'count' => $n]; }
            place_out(['states' => $list]);
        }
        $stateIn = strtoupper(trim((string)($_GET['state'] ?? '')));
        if (!preg_match('/^[A-Z]{2}$/', $stateIn)) { place_fail(400, 'Invalid state.'); }
        $st = $pdo->prepare(
            "SELECT JSON_UNQUOTE(mc.meta_value) AS city, COUNT(*) AS n
               FROM entities e
               JOIN entity_metadata mc ON mc.entity_id = e.id AND mc.meta_key = 'city'
               JOIN entity_metadata ms ON ms.entity_id = e.id AND ms.meta_key = 'state'
              WHERE $baseE AND UPPER(TRIM(JSON_UNQUOTE(ms.meta_value))) = ?
              GROUP BY JSON_UNQUOTE(mc.meta_value)
              ORDER BY JSON_UNQUOTE(mc.meta_value) LIMIT 400"
        );
        $st->execute([$stateIn]);
        $towns = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $c = trim((string)$r['city']);
            if ($c !== '') { $towns[] = ['city' => $c, 'count' => (int)$r['n']]; }
        }
        place_out(['state' => $stateIn, 'towns' => $towns]);
    }

    // ---- Regional hubs for the picker ----
    // ---- Find a place by name, for the place picker's Destination (decisions/0058 §8) ----
    //   ?action=find&q=st. johns  -> {success, places:[{label, sub, level, slug}]}
    // Regions, areas, town areas and accepted local names, matched forgivingly: "St. Johns", "st johns", "Saint
    // Johns" and "The Greater St. Johns Area" all find each other. Names that start with what was typed come first.
    if ($action === 'find') {
        $q = trim((string)($_GET['q'] ?? ''));
        if (mb_strlen($q) < 2) place_out(['places' => []]);
        $norm = function (string $x): string {
            $x = mb_strtolower($x);
            $x = preg_replace('/[.,\'’]/u', '', $x);
            $x = preg_replace('/\bsaint\b/u', 'st', $x);
            $x = preg_replace('/^(the|greater)\s+/u', '', $x);
            $x = preg_replace('/^(the|greater)\s+/u', '', $x);
            return trim(preg_replace('/\s+/u', ' ', $x));
        };
        $nq = $norm($q);
        $like = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $nq) . '%';
        // the same forgiveness in SQL: no periods, commas or apostrophes; "saint " read as "st "
        $col = fn (string $c) => "REPLACE(REPLACE(REPLACE(REPLACE(LOWER($c), '.', ''), ',', ''), '''', ''), 'saint ', 'st ')";
        // In this order (decisions/0058 §17): 0 the anchor town of a town area, as the town itself: a point, within 10 mi by
        // default (decisions/0053, "Town names … open Get Local"; P9, Jason 2026-11-13; its town area is still row 1),
        // 1 town areas, 2 local names, 3 other towns in our areas, 4 areas and regions, 5 landmarks (outdoor places and
        // attractions: "Grand Canyon", "Disneyland"). Within each, names that start with what was typed come first.
        $out = [];
        $put = function (array $o, int $g) use (&$out) { $o['g'] = $g; $out[] = $o; };
        $add = function (string $sql, string $level, string $sub, int $g) use ($pdo, $like, $put) {
            try {
                $st = $pdo->prepare($sql); $st->execute([$like]);
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    if ((string)($r['slug'] ?? '') === '') continue;
                    $put(['label' => PlaceScope::publicName((string)$r['name']), 'sub' => $sub . (!empty($r['within']) ? ' · ' . PlaceScope::publicName((string)$r['within']) : ''),
                          'level' => $level, 'slug' => (string)$r['slug'], 'name' => (string)$r['name']], $g);
                }
            } catch (Throwable $e) { error_log('place find: ' . $e->getMessage()); }
        };
        $anchorSlugs = [];
        try {   // 0: anchor towns, each with its town area
            $st = $pdo->prepare('SELECT mc.slug, mc.name AS within, z.city, z.state FROM micro_clusters mc JOIN zip_coordinates z ON TRIM(z.zip) = TRIM(mc.primary_zip)
                                  WHERE mc.slug IS NOT NULL AND mc.slug <> \'\' AND ' . $col('z.city') . " LIKE ? ESCAPE '!' ORDER BY mc.source = 'manual' DESC, mc.id LIMIT 12");
            $st->execute([$like]);
            $seenA = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $anchorSlugs[(string)$r['slug']] = true;
                $ak = mb_strtolower((string)$r['city'] . '|' . $r['state']);   // one row per town: the hand-made area first
                if (isset($seenA[$ak])) continue;
                $seenA[$ak] = true;
                $put(['label' => ucwords(mb_strtolower((string)$r['city'])) . ', ' . (string)$r['state'], 'sub' => 'Town · in ' . PlaceScope::publicName((string)$r['within']),
                      'city' => ucwords(mb_strtolower((string)$r['city'])), 'state' => (string)$r['state'], 'name' => (string)$r['city']], 0);
            }
        } catch (Throwable $e) { error_log('place find anchors: ' . $e->getMessage()); }
        $add('SELECT mc.slug, mc.name, g.name AS within FROM micro_clusters mc LEFT JOIN geo_hubs g ON g.id = mc.geo_hub_id WHERE ' . $col('mc.name') . " LIKE ? ESCAPE '!' LIMIT 10", 'cluster', 'Town area', 1);
        try {   // 2: local names ("Wide Ruins") open the town area they belong to
            $st = $pdo->prepare("SELECT s.name, mc.slug, mc.name AS within FROM cluster_subgroups s JOIN micro_clusters mc ON mc.id = s.cluster_id WHERE s.status = 'accepted' AND " . $col('s.name') . " LIKE ? ESCAPE '!' LIMIT 6");
            $st->execute([$like]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if ((string)$r['slug'] !== '') $put(['label' => (string)$r['name'], 'sub' => 'Local name · ' . PlaceScope::publicName((string)$r['within']), 'level' => 'cluster', 'slug' => (string)$r['slug'], 'name' => (string)$r['name']], 2);
        } catch (Throwable $e) {}
        try {   // 3: other towns inside one of our town areas, each as the town (a point), like row 0
            $st = $pdo->prepare('SELECT DISTINCT z.zip, z.city, z.state FROM zip_coordinates z WHERE ' . $col('z.city') . " LIKE ? ESCAPE '!' LIMIT 25");
            $st->execute([$like]);
            $seenTown = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $tk = mb_strtolower((string)$r['city'] . '|' . $r['state']);
                if (isset($seenTown[$tk])) continue;
                $c = place_cluster_for_zip($pdo, trim((string)$r['zip']), null, null);
                if (!$c || isset($anchorSlugs[$c['slug']])) continue;
                $seenTown[$tk] = true;
                $put(['label' => ucwords(mb_strtolower((string)$r['city'])) . ', ' . (string)$r['state'], 'sub' => 'Town · in ' . $c['label'], 'city' => ucwords(mb_strtolower((string)$r['city'])), 'state' => (string)$r['state'], 'name' => (string)$r['city']], 3);
                if (count($seenTown) >= 5) break;
            }
        } catch (Throwable $e) {}
        $add('SELECT g.slug, g.name, h.name AS within FROM geo_hubs g JOIN hubs h ON h.id = g.hub_id WHERE ' . $col('g.name') . " LIKE ? ESCAPE '!' LIMIT 8", 'geo_hub', 'Area', 4);
        $add('SELECT slug, name, \'\' AS within FROM hubs WHERE ' . $col('name') . " LIKE ? ESCAPE '!' LIMIT 6", 'hub', 'Region', 4);
        // 5: landmarks. Choosing one sets the town area around it (else its own town). Public places only; never a
        // confidential listing, never anything hidden.
        $landmark = function (string $name, string $what, $lat, $lon, string $zip, string $city, string $state) use ($pdo, $put) {
            $c = place_cluster_for_zip($pdo, $zip, $lat, $lon);
            $town = trim(implode(', ', array_filter([ucwords(mb_strtolower($city)), $state])));
            if ($c) $put(['label' => $name, 'sub' => $what . ' · ' . $c['label'], 'level' => 'cluster', 'slug' => $c['slug'], 'area' => $c['label'], 'name' => $name], 5);   // the place is the area, by its own name
            elseif ($city !== '' && $state !== '') $put(['label' => $name, 'sub' => $what . ' · ' . $town, 'city' => ucwords(mb_strtolower($city)), 'state' => $state, 'name' => $name], 5);
        };
        if (mb_strlen($nq) >= 3) {
            try {
                require_once __DIR__ . '/../../app/lib/crawler/RecBulk.php';
                if (RecBulk::ready($pdo)) {
                    $st = $pdo->prepare('SELECT name, kind, type, lat, lon, zip5, city, state FROM rec_places WHERE hidden = 0 AND ' . $col('name') . " LIKE ? ESCAPE '!' ORDER BY kind = 'recarea' DESC, LENGTH(name) LIMIT 4");
                    $st->execute([$like]);
                    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $landmark(RecBulk::displayName((string)$r['name']), 'Outdoors', $r['lat'], $r['lon'], (string)$r['zip5'], (string)$r['city'], (string)$r['state']);
                }
            } catch (Throwable $e) { error_log('place find rec: ' . $e->getMessage()); }
            try {   // natural landmarks people can see (decisions/0058 §24, §25): "Four Corners Monument", "Bisti Badlands"
                require_once __DIR__ . '/../../app/lib/Landmarks.php';
                if (Landmarks::ready($pdo)) {
                    $st = $pdo->prepare("SELECT name, fclass, lat, lon, zip5, near_town, state FROM landmarks WHERE " . Landmarks::visibleSql() . " AND " . $col('name') . " LIKE ? ESCAPE '!' ORDER BY (image_url <> '') + (wiki_title <> '') + (file = 'manual') DESC, LENGTH(name) LIMIT 4");
                    $st->execute([$like]);
                    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $landmark((string)$r['name'], Landmarks::kindLabel($r), $r['lat'], $r['lon'], (string)$r['zip5'], (string)$r['near_town'], (string)$r['state']);
                }
            } catch (Throwable $e) { error_log('place find natural landmarks: ' . $e->getMessage()); }
            try {
                require_once __DIR__ . '/../../app/lib/ListingSafety.php';
                $cats = ['amusement', 'museum', 'tourist', 'attraction', 'monument', 'landmark', 'national park', 'state park', 'zoo', 'aquarium', 'resort', 'casino', 'stadium', 'arena', 'theme park', 'cavern', 'observator', 'ruins', 'historic'];
                $cw = implode(' OR ', array_fill(0, count($cats), 'LOWER(c.name) LIKE ?'));
                $st = $pdo->prepare("SELECT e.id, e.name, e.category_id, e.latitude, e.longitude, e.primary_zip, c.name AS cat,
                                            (SELECT meta_value FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'city' LIMIT 1) AS city,
                                            (SELECT meta_value FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'state' LIMIT 1) AS state
                                       FROM entities e JOIN categories c ON c.id = e.category_id
                                      WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ('unclaimed','claimed-unverified','pending-verification','verified')
                                        AND " . $col('e.name') . " LIKE ? ESCAPE '!' AND ($cw) LIMIT 4");
                $st->execute(array_merge([$like], array_map(fn ($c) => '%' . $c . '%', $cats)));
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    if (ListingSafety::isConfidential($r['category_id'] !== null ? (int)$r['category_id'] : null, (string)$r['name'])) continue;
                    $v = fn ($x) => is_string($d = json_decode((string)$x, true)) ? $d : (string)$x;
                    require_once __DIR__ . '/../../app/lib/NameText.php';
                    $landmark(NameText::full((string)$r['name']), (string)$r['cat'], $r['latitude'], $r['longitude'], trim((string)$r['primary_zip']), $v($r['city']), $v($r['state']));
                }
            } catch (Throwable $e) { error_log('place find landmarks: ' . $e->getMessage()); }
        }
        $rank = fn ($o) => str_starts_with($norm($o['name']), $nq) ? 0 : (preg_match('/\b' . preg_quote($nq, '/') . '/u', $norm($o['name'])) ? 1 : 2);
        $out = array_values(array_filter($out, fn ($o) => $rank($o) < 2));   // a word starts with it: "sport" isn't Breesport
        usort($out, fn ($a, $b) => [$a['g'], $rank($a)] <=> [$b['g'], $rank($b)]);
        $seen = []; $out = array_values(array_filter($out, function ($o) use (&$seen) { $k = ($o['slug'] ?? '') . '|' . mb_strtolower($o['label']); if (isset($seen[$k])) return false; $seen[$k] = 1; return true; }));
        foreach ($out as &$o) unset($o['g']);
        unset($o);
        place_out(['places' => array_map(fn ($o) => array_diff_key($o, ['name' => 1]), array_slice($out, 0, 10))]);
    }

    if ($action === 'hubs') {
        try {
            $rows = $pdo->query('SELECT slug, name, hub_number, status FROM hubs ORDER BY hub_number')->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            // geo-hierarchy migration not run yet: no status column
            $rows = $pdo->query('SELECT slug, name, hub_number FROM hubs ORDER BY hub_number')->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as &$r) { $r['status'] = 'active'; }
            unset($r);
        }
        foreach ($rows as &$r) { $r['hub_number'] = (int)$r['hub_number']; }
        unset($r);
        place_out(['hubs' => $rows]);
    }

    // ---- Hub / geo-hub / cluster ----
    $scope = PlaceScope::resolve($pdo, $_GET);
    if ($scope !== null) {
        if (!$scope['found']) {
            place_fail(404, 'Unknown region.');
        }
        $lat = $lon = null;
        try {
            if ($scope['level'] === 'hub') {
                $st = $pdo->prepare('SELECT center_lat, center_lon FROM hubs WHERE id = ?');
            } elseif ($scope['level'] === 'geo_hub') {
                $st = $pdo->prepare('SELECT center_lat, center_lon FROM geo_hubs WHERE id = ?');
            } else {
                $st = $pdo->prepare('SELECT center_lat, center_lon FROM micro_clusters WHERE id = ?');
            }
            $st->execute([$scope['id']]);
            if ($c = $st->fetch(PDO::FETCH_ASSOC)) {
                $lat = $c['center_lat'] !== null ? (float)$c['center_lat'] : null;
                $lon = $c['center_lon'] !== null ? (float)$c['center_lon'] : null;
            }
        } catch (Throwable $e) {
            // centre columns come from the migration; a region works without them
        }
        $hub = null;
        if ($scope['hub_number'] !== null) {
            $st = $pdo->prepare('SELECT slug, name FROM hubs WHERE hub_number = ? LIMIT 1');
            $st->execute([$scope['hub_number']]);
            if ($h = $st->fetch(PDO::FETCH_ASSOC)) {
                $hub = ['slug' => $h['slug'], 'name' => $h['name']];
            }
        }
        place_out(['place' => [
            'level' => $scope['level'], 'slug' => $scope['slug'], 'label' => $scope['name'],
            'lat' => $lat, 'lon' => $lon, 'hub' => $hub,
        ]]);
    }

    // ---- ZIP ----
    $zip = trim((string)($_GET['zip'] ?? ''));
    if ($zip !== '') {
        if (!preg_match('/^\d{5}$/', $zip)) {
            place_fail(400, 'Invalid ZIP.');
        }
        $st = $pdo->prepare('SELECT zip, city, state, county, latitude, longitude FROM zip_coordinates WHERE zip = ? LIMIT 1');
        $st->execute([$zip]);
        $z = $st->fetch(PDO::FETCH_ASSOC);
        if (!$z) {
            place_fail(404, 'Unknown ZIP.');
        }
        place_out(['place' => place_zip_place($pdo, $z)]);
    }

    // ---- Device coordinates -> nearest ZIP (a suggestion, never applied) ----
    $latIn = $_GET['lat'] ?? '';
    $lonIn = $_GET['lon'] ?? '';
    if ($latIn !== '' && $lonIn !== '' && is_numeric($latIn) && is_numeric($lonIn)) {
        $lat = (float)$latIn;
        $lon = (float)$lonIn;
        if ($lat < -90 || $lat > 90 || $lon < -180 || $lon > 180) {
            place_fail(400, 'Invalid coordinates.');
        }
        $acc = (isset($_GET['accuracy']) && is_numeric($_GET['accuracy'])) ? (float)$_GET['accuracy'] : null;

        $found = null;
        foreach ([0.25, 1.0, 3.0] as $d) { // widen the box only if nothing is near
            $st = $pdo->prepare(
                'SELECT zip, city, state, county, latitude, longitude FROM zip_coordinates
                  WHERE latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?
                  ORDER BY ((latitude - ?) * (latitude - ?) + (longitude - ?) * (longitude - ?) * ?) ASC
                  LIMIT 1'
            );
            $k = cos(deg2rad($lat)) ** 2;
            $st->execute([$lat - $d, $lat + $d, $lon - $d, $lon + $d, $lat, $lat, $lon, $lon, $k]);
            $found = $st->fetch(PDO::FETCH_ASSOC);
            if ($found) {
                break;
            }
        }
        if (!$found) {
            place_fail(404, 'No place found near these coordinates.');
        }
        $place = place_zip_place($pdo, $found);
        $place['approximate'] = ($acc === null) || $acc > 5000; // >5 km, or unknown: IP/Wi-Fi style guess
        $place['accuracy_m'] = $acc;
        place_out(['place' => $place]);
    }

    place_fail(400, 'Nothing to look up.');
} catch (Throwable $e) {
    error_log('place.php: ' . $e->getMessage());
    place_fail(500, 'Place lookup is unavailable right now.');
}
