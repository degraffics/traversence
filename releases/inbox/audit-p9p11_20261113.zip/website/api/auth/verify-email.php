<?php

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';

Response::requireMethod('POST');
Response::requireCsrf();

$body = Response::jsonBody();
$token = trim((string) ($body['token'] ?? ''));

if ($token === '') {
    Response::error('A confirmation token is required.', 422, 'validation_error');
}

try {
    $userId = Auth::confirmEmailToken($token, 'registration');
} catch (RuntimeException $e) {
    Response::error($e->getMessage(), 410, 'invalid_token');
}

// the questions after the link (Jason, 2026-11-05): this browser may answer them for this account for the next hour,
// without being signed in (/api/auth/setup.php)
$_SESSION['tv_setup'] = ['uid' => $userId, 'at' => time()];
$em = ''; $in = false;
try {
    $pdo = Database::connection();
    $st = $pdo->prepare('SELECT email, is_suspended, session_version FROM users WHERE id = ?'); $st->execute([$userId]); $u = $st->fetch(PDO::FETCH_ASSOC) ?: [];
    $em = (string) ($u['email'] ?? '');
    // the link from their own inbox signs them in, as a sign-in link does (Jason, 2026-11-13, site audit P11): not a
    // suspended or closing account, and not over someone already signed in here
    $closing = false;
    if (is_file(__DIR__ . '/../../../app/lib/AccountDeletion.php')) { require_once __DIR__ . '/../../../app/lib/AccountDeletion.php'; $closing = AccountDeletion::ready($pdo) && AccountDeletion::closing($pdo, $userId); }
    if ($u && (int) $u['is_suspended'] === 0 && !$closing && empty($_SESSION['user_id'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $userId;
        $_SESSION['logged_in_at'] = time();
        $_SESSION['session_version'] = (int) $u['session_version'];
        $in = true;
    }
} catch (Throwable $e) { error_log('verify-email sign-in: ' . $e->getMessage()); }
Response::success(['message' => 'Your email is confirmed.', 'user_id' => $userId, 'email' => $em, 'signed_in' => $in, 'csrf_token' => $_SESSION['csrf_token'] ?? '']);
