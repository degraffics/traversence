<?php

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/Mailer.php';

Response::requireMethod('POST');
Response::requireCsrf();

$body = Response::jsonBody();
// a captcha (decisions/0097): off until its keys are in .env
require_once __DIR__ . '/../../../app/lib/Captcha.php';
try { Captcha::verify((string) ($body['captcha'] ?? '')); } catch (RuntimeException $e) { Response::error($e->getMessage(), 400, 'captcha'); }
$email = trim((string) ($body['email'] ?? ''));
$password = (string) ($body['password'] ?? '');
$displayName = isset($body['display_name']) ? trim((string) $body['display_name']) : null;

if ($email === '' || $password === '') {
    Response::error('Email and password are required.', 422, 'validation_error');
}
// Accounts are for adults, 18 or older (decisions/0058 §7). Checked here, not only in the form.
if (($body['over_18'] ?? false) !== true) {
    Response::error('You must be 18 years old or older to create an account.', 422, 'age_required');
}

// where they live and where they're connecting from (decisions/0027): only both in the EU/UK stops sign-up here
require_once __DIR__ . '/../../../app/lib/RegionGate.php';
$tvHome = isset($body['home_country']) ? (string) $body['home_country'] : null;
$tvGate = RegionGate::check(Database::connection(), $tvHome);
if ($tvGate === 'ask') Response::error('Where do you live?', 422, 'ask_home');
if ($tvGate === 'refuse') Response::error(RegionGate::MESSAGE, 451, 'region');

try {
    $user = Auth::register($email, $password, $displayName ?: null);
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'validation_error');
} catch (RuntimeException $e) {
    // Deliberately generic message from Auth::register() to avoid email enumeration.
    Response::error($e->getMessage(), 409, 'registration_failed');
}

// Joined through an invite (join.php): connect them to whoever invited them (decisions/0047).
if (!empty($_SESSION['tv_invite']) && !empty($user['id'])) {
    try {
        require_once __DIR__ . '/../../../app/lib/People.php';
        People::acceptInvite(Database::connection(), (string) $_SESSION['tv_invite'], (int) $user['id']);
    } catch (Throwable $e) {
        error_log('Invite accept failed: ' . $e->getMessage());
    }
    unset($_SESSION['tv_invite']);
}

try {
    require_once __DIR__ . '/../../../app/lib/AgeGate.php';
    if (!empty($user['id'])) AgeGate::confirm(Database::connection(), (int) $user['id']);
} catch (Throwable $e) {
    error_log('Age confirmation not saved: ' . $e->getMessage());
}

// privacy choices from sign-up (decisions/0077): both recorded, yes or no, with the wording shown
if (is_array($body['choices'] ?? null) && !empty($user['id'])) {
    try {
        require_once __DIR__ . '/../../../app/lib/Consent.php';
        $cp2 = Database::connection();
        if (Consent::ready($cp2)) foreach (['analytics', 'video'] as $t) Consent::set($cp2, (int) $user['id'], $t, !empty($body['choices'][$t]), 'register.php');
    } catch (Throwable $e) { error_log('register choices: ' . $e->getMessage()); }
}
// no Verification question any more (Jason, 2026-11-05, amending decisions/0062): confirming the email is the check.
// The choices (AI & Learning, analytics, videos) and where you're from are asked after the email link (verify-email.php).

// what they answered, kept (a home outside the EU/UK; the US gets its ZIP after the email link)
if ($tvHome !== null && trim($tvHome) !== '' && !empty($user['id'])) {
    try { Database::connection()->prepare('UPDATE users SET home_country = ? WHERE id = ?')->execute([mb_substr(trim($tvHome), 0, 60), (int) $user['id']]); } catch (Throwable $e) { error_log('register home: ' . $e->getMessage()); }
}

$verificationToken = $user['verification_token'];
unset($user['verification_token']);

$verifyUrl = rtrim(getenv('APP_URL') ?: '', '/') . '/verify-email.php?token=' . urlencode($verificationToken);
try {
    Mailer::send(
        $user['email'],
        'Verify your Traversence account',
        "Welcome to Traversence.\n\nConfirm your email address to finish creating your account:\n{$verifyUrl}\n\n"
        . "The link works for 24 hours. After it, a few quick questions and you're in.\n\n"
        . "If you didn't create this account, you can ignore this email."
    );
} catch (Throwable $e) {
    // Registration itself already succeeded — a failed send here shouldn't
    // fail the whole request, but it does mean the user can't verify yet.
    // Logged for follow-up rather than silently swallowed.
    error_log('Failed to send verification email to ' . $user['email'] . ': ' . $e->getMessage());
}

Response::success([
    'user' => $user,
    'message' => 'Check your email: we sent a link to ' . $user['email'] . '. Open it to confirm your address, then answer a few quick questions and you\'re signed in.',
    'email' => $user['email'],
], 201);
