<?php require_once __DIR__ . '/../app/ui/auth-nav.php'; require_once __DIR__ . '/../app/lib/Consent.php';
// The email link, then four quick questions, then on to the dashboard (Jason, 2026-11-05; signed in by the link since
// 2026-11-13, site audit P11):
//   the link confirms the address (that is the Verified check; decisions/0014, 0062 as amended) ->
//   1. Where you're from (decisions/0027)  2. AI Assist & Learning (0051)  3. Usage analytics (0077)  4. Videos (0077)
//   each with Continue or Skip (skipped stays off) -> Sign in (or on to the dashboard, if already signed in).
// ?setup=1 opens the questions straight away for someone signed in (finishing a Google, Apple, Microsoft or Facebook
// sign-up, whose email the provider has already confirmed).
$tv_q = [];
foreach (['ai_learning', 'analytics', 'video'] as $tv_k) $tv_q[$tv_k] = Consent::TOOLS[$tv_k];
$tv_e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Confirm your email — Traversence</title>
  <?php tv_nav_head(); ?>
  <style>
    .vs,.vs *{box-sizing:border-box}
    .vs{max-width:28rem;width:100%;background:#E3D3AC;border:1px solid #CBB98D;border-radius:1rem;padding:1.6rem 1.5rem;box-shadow:0 18px 40px -20px rgba(0,0,0,.45);color:#3E2B1F}
    .vs h1{font:700 1.35rem/1.25 Georgia,serif;margin:0 0 .4rem}
    .vs p{font-size:.93rem;line-height:1.5;margin:.35rem 0}
    .vs-step[hidden]{display:none}
    .vs-n{font:700 .72rem system-ui,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#8A7355;margin-bottom:.35rem}
    .vs-bar{height:4px;border-radius:999px;background:#CBB98D;margin:0 0 1rem;overflow:hidden}.vs-bar i{display:block;height:100%;background:#C85A17;width:0;transition:width .2s}
    .vs label.f{display:block;font-size:.82rem;font-weight:700;margin:.8rem 0 .25rem}
    .vs select,.vs input[type=text]{width:100%;font-size:1rem;padding:.55rem .65rem;border:1px solid #CBB98D;border-radius:.6rem;background:#F7F1E3;color:#3E2B1F}
    .vs .tick{display:flex;gap:.6rem;align-items:flex-start;margin:.9rem 0 .2rem;font-size:.95rem;font-weight:600;cursor:pointer}
    .vs .tick input{width:1.15rem;height:1.15rem;margin-top:.15rem;accent-color:#C85A17;flex:none}
    .vs details{margin:.5rem 0 0;font-size:.85rem}.vs summary{cursor:pointer;color:#92400E;font-weight:700}
    .vs details p{font-size:.85rem;color:#5C4632}
    .vs-go{display:flex;gap:.6rem;margin-top:1.3rem}
    .vs-go button,.vs-go a{flex:1;text-align:center;border-radius:.6rem;padding:.65rem;font:700 .95rem system-ui,sans-serif;cursor:pointer;text-decoration:none}
    .vs-c{background:#92400E;border:1px solid #92400E;color:#fff}.vs-s{background:none;border:1px solid #92400E;color:#92400E}
    @media (max-width:767px){.vs{border-radius:.5rem;margin:0 3px;width:calc(100% - 6px);padding:1.3rem 1rem}}
  </style>
</head>
<body class="bg-[#EFE3C8] text-[#3E2B1F] min-h-screen flex flex-col font-sans">
  <?php tv_nav_bar(); ?>
  <main class="flex-1 flex items-center justify-center py-8">
  <div class="vs tv-bleed">
    <div class="vs-step" id="s0">
      <h1>Confirming your email…</h1>
      <p id="s0-msg" data-tv-status="info" data-tv-label="One moment:">Checking your link.</p>
    </div>

    <div class="vs-step" id="s1" hidden>
      <div class="vs-n">✓ Email confirmed · Question 1 of 4</div><div class="vs-bar"><i style="width:25%"></i></div>
      <h1>Where are you from?</h1>
      <p>So the places, guides and events you see start near home. Only you see it.</p>
      <label class="f" for="q-country">Country</label>
      <select id="q-country"><option value="">Choose…</option><option value="US">United States</option><option value="CA">Canada</option><option value="MX">Mexico</option><option value="other">Another country</option></select>
      <div id="q-zipw"><label class="f" for="q-zip">ZIP code</label><input type="text" id="q-zip" inputmode="numeric" maxlength="5" autocomplete="postal-code" placeholder="85936"></div>
      <div id="q-otherw" hidden><label class="f" for="q-other">Which country?</label><input type="text" id="q-other" maxlength="60" autocomplete="country-name" data-spell></div>
      <div class="vs-go"><button type="button" class="vs-s" data-skip>Skip</button><button type="button" class="vs-c" data-next="where">Continue</button></div>
    </div>

    <?php $tv_i = 2; foreach ($tv_q as $tv_k => $tv_t): ?>
    <div class="vs-step" id="s<?= $tv_i ?>" hidden>
      <div class="vs-n">Question <?= $tv_i ?> of 4</div><div class="vs-bar"><i style="width:<?= $tv_i * 25 ?>%"></i></div>
      <h1><?= $tv_e($tv_t['name']) ?></h1>
      <p><?= $tv_e($tv_t['summary']) ?></p>
      <label class="tick"><input type="checkbox" id="q-<?= $tv_k ?>"> <span>Yes, turn on <?= $tv_e($tv_t['name']) ?></span></label>
      <details data-read="<?= $tv_k ?>"><summary>ⓘ What this means</summary><?php foreach (preg_split('/\n\s*\n/', (string) $tv_t['explanation']) as $tv_para): ?><p><?= $tv_e($tv_para) ?></p><?php endforeach; ?></details>
      <p style="font-size:.8rem;color:#8A7355">Off unless you tick it. Change it any time in Privacy Settings.</p>
      <div class="vs-go"><button type="button" class="vs-s" data-skip>Skip</button><button type="button" class="vs-c" data-next="<?= $tv_k ?>">Continue</button></div>
    </div>
    <?php $tv_i++; endforeach; ?>

    <div class="vs-step" id="s5" hidden>
      <div class="vs-n">All done</div><div class="vs-bar"><i style="width:100%"></i></div>
      <h1>You're all set.</h1>
      <p id="s5-msg">Your email is confirmed and your account is ready.</p>
      <div class="vs-go"><a class="vs-c" id="s5-go" href="/login.php">Sign in</a></div>
    </div>
  </div>
  </main>
  <?php tv_nav_foot(); ?>
  <script>
  (function () {
    const P = new URLSearchParams(location.search), token = P.get('token'), setup = P.get('setup') === '1';
    let csrf = '', email = '', signedIn = false, at = 0;
    const show = n => { document.querySelectorAll('.vs-step').forEach(s => { s.hidden = s.id !== 's' + n; }); at = n; window.scrollTo(0, 0); };
    const say = (msg, el, bad) => { if (window.TvAsk) TvAsk.say(msg, { anchor: el, bad: !!bad }); };
    const s0 = document.getElementById('s0-msg');
    const fail = m => { s0.textContent = m; s0.setAttribute('data-tv-status', 'bad'); s0.setAttribute('data-tv-label', 'Error:'); document.querySelector('#s0 h1').textContent = 'That link didn’t work';
      const a = document.createElement('a'); a.href = '/login.php'; a.className = 'inline-block mt-3 underline font-semibold text-[#92400E]'; a.textContent = 'Go to Sign in (it can send you a new link)'; s0.after(a); };
    function finish() {
      let draft = null; try { draft = localStorage.getItem('tv_add_business'); } catch (e) {}
      const go = document.getElementById('s5-go'), next = P.get('next') || '';
      const safe = /^\/(?!\/)[^\s\\]*$/.test(next) ? next : '';
      if (signedIn) { go.textContent = draft ? 'Continue adding your business' : 'Go to your dashboard'; go.href = draft ? '/claim.php?new=1' : (safe || '/user/dashboard.php'); }
      else {
        go.textContent = 'Sign in';
        const q = new URLSearchParams(); if (email) q.set('email', email); const after = draft ? '/claim.php?new=1' : safe; if (after) q.set('next', after);
        go.href = '/login.php' + (q.toString() ? '?' + q.toString() : '');
        document.getElementById('s5-msg').textContent = 'Your email is confirmed and your account is ready. Sign in to start.';
      }
      show(5);
    }
    const step = () => (at < 4 ? show(at + 1) : finish());
    document.getElementById('q-country').addEventListener('change', e => {
      const v = e.target.value; document.getElementById('q-zipw').hidden = v !== 'US' && v !== ''; document.getElementById('q-otherw').hidden = v !== 'other';
    });
    document.querySelectorAll('[data-skip]').forEach(b => b.addEventListener('click', step));
    document.querySelectorAll('[data-next]').forEach(b => b.addEventListener('click', async () => {
      const k = b.getAttribute('data-next'); let body;
      if (k === 'where') {
        let c = document.getElementById('q-country').value;
        if (c === 'other') c = document.getElementById('q-other').value.trim();
        if (!c) { say('Choose your country, or tap Skip.', b, true); return; }
        body = { country: c, zip: document.getElementById('q-zip').value.trim() };
      } else {
        body = { choices: { [k]: document.getElementById('q-' + k).checked }, read: { [k]: !!document.querySelector('details[data-read="' + k + '"][open]') } };
      }
      if (window.TvAsk) TvAsk.busy(b, true);
      try {
        const r = await fetch('/api/auth/setup.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) });
        const d = await r.json();
        if (window.TvAsk) TvAsk.busy(b, false);
        if (!r.ok || !d.ok) { say((d.error && d.error.message) || 'That didn’t save. Try again.', b, true); return; }
        step();
      } catch (e) { if (window.TvAsk) TvAsk.busy(b, false); say('Something went wrong. Try again.', b, true); }
    }));
    (async function start() {
      try {
        const ses = await fetch('/api/auth/session.php', { credentials: 'include' }).then(r => r.json());
        csrf = (ses && ses.csrf_token) || ''; signedIn = !!(ses && ses.authenticated);
        if (setup) { if (signedIn) { show(1); return; } fail('Sign in first, then finish these in Privacy Settings.'); return; }
        if (!token) { fail('This page needs the link from your email.'); return; }
        const res = await fetch('/api/auth/verify-email.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ token }) });
        const d = await res.json();
        if (res.ok && d.ok) { email = d.email || ''; if (d.signed_in) { signedIn = true; csrf = d.csrf_token || csrf; } show(1); }
        else fail((d.error && d.error.message) || 'That link didn’t work.');
      } catch (e) { fail('Something went wrong. Try the link again.'); }
    })();
  })();
  </script>
</body>
</html>
