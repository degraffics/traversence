<?php
// api/lib/Engage.php — the standard engagement on every content page (decisions/0058 §20): views (the platform's
// counts, never who), likes (how many; never who), public comments, Share and Report. For listings, outdoor places,
// experiences and place pages; journeys keep their own (Journeys::comments). A comment needs a signed-in member who
// is 18 or older; it can be removed by its writer or by staff, and reported (Admin → Reports).
declare(strict_types=1);

require_once __DIR__ . '/ListingSafety.php';

final class Engage
{
    public const KINDS = ['listing', 'rec', 'exp', 'place', 'lm', 'guide', 'how', 'sj'];   // sj: a suggested journey (decisions/0146); 'mkt' (a Marketplace post) has views, Share and Report only; 'group' (a community group, decisions/0137 §4) views, Share and QR
    /** the platform's view-count key for each (decisions/0058 §13) */
    public const COUNT_KEY = ['listing' => 'listing:', 'rec' => 'rec:', 'exp' => 'experience:', 'place' => 'place:', 'lm' => 'landmark:', 'guide' => 'guide:', 'how' => 'how:', 'sj' => 'suggested:', 'mkt' => 'market:', 'group' => 'group:'];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM content_comments LIMIT 1'); $pdo->query('SELECT 1 FROM content_likes LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /** A valid target: [kind, ref], or an exception. */
    public static function target(string $kind, string $ref): array
    {
        $ok = match ($kind) {
            'listing', 'exp', 'lm', 'guide', 'how', 'sj', 'photo' => ctype_digit($ref),   // photo: a gallery item, only through Gallery (decisions/0126), which checks who may see it
            'mp' => ctype_digit($ref),   // a member's post, only through MemberPosts (decisions/0153), which checks who may see it
            'rec' => (bool) preg_match('/^[A-Za-z0-9_-]{1,40}$/', $ref),
            'place' => (bool) preg_match('/^(hub|geo_hub|cluster|town|sub):\d{1,9}$/', $ref),   // town, sub: city and neighborhood guides (decisions/0131)
            default => false,
        };
        if (!$ok) throw new InvalidArgumentException('That can\'t be liked or commented on.');
        return [$kind, $ref];
    }

    /** How many visits saw it (all time), from the platform's counts. */
    public static function views(PDO $pdo, string $kind, string $ref): int
    {
        try {
            require_once __DIR__ . '/PlatformCounts.php';
            return (int) PlatformCounts::total($pdo, 'view', 3650, self::COUNT_KEY[$kind] . $ref)['visits'];
        } catch (Throwable) { return 0; }
    }

    public static function likes(PDO $pdo, string $kind, string $ref): int
    {
        if (!self::ready($pdo)) return 0;
        require_once __DIR__ . '/TestAccounts.php';   // a test account's like isn't counted (decisions/0145 §3)
        $st = $pdo->prepare('SELECT COUNT(*) FROM content_likes l' . (TestAccounts::ready($pdo) ? ' WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = l.user_id AND u.is_test = 1) AND' : ' WHERE') . ' l.kind = ? AND l.ref = ?');
        $st->execute([$kind, $ref]);
        return (int) $st->fetchColumn() + self::guestLikes($pdo, $kind, $ref);
    }

    public static function liked(PDO $pdo, string $kind, string $ref, ?int $uid): bool
    {
        if (!$uid || !self::ready($pdo)) return false;
        $st = $pdo->prepare('SELECT 1 FROM content_likes WHERE kind = ? AND ref = ? AND user_id = ?');
        $st->execute([$kind, $ref, $uid]);
        return (bool) $st->fetchColumn();
    }

    /**
     * Like or unlike, signed in. Returns [liked, likes]. A like passes the checks first (LikeGuard: speed, timing, 100 a
     * day), which can throw RuntimeException 428 (the human check) or 429 (today's likes used). Gallery photos are liked
     * inside a gallery its owner shares, so they skip them.
     */
    /**
     * Is there something to like (site audit P11, 2026-11-13: likes were taken for ids nothing has)? Each kind through its
     * own library, so a landmark that isn't shown can't be liked either. True when it can't be told (a library or table
     * missing): a like is never refused for our own gap. Kinds checked elsewhere (photo, mp) or by shape only (rec,
     * place) pass.
     */
    public static function exists(PDO $pdo, string $kind, string $ref): bool
    {
        try {
            switch ($kind) {
                case 'lm': require_once __DIR__ . '/Landmarks.php'; return !Landmarks::ready($pdo) || Landmarks::get($pdo, (int) $ref) !== null;
                case 'sj': require_once __DIR__ . '/JourneyPlan.php'; return !JourneyPlan::ready($pdo) || JourneyPlan::get($pdo, (int) $ref) !== null;
                case 'guide': require_once __DIR__ . '/ResourceGuides.php'; return !ResourceGuides::ready($pdo) || ResourceGuides::guide($pdo, (int) $ref) !== null;
                case 'exp': $sql = "SELECT 1 FROM experiences WHERE id = ? AND status = 'published'"; break;
                case 'how': $sql = 'SELECT 1 FROM how_guides WHERE id = ?'; break;
                case 'listing': $sql = 'SELECT 1 FROM entities WHERE id = ? AND is_suppressed = 0'; break;
                default: return true;
            }
            $st = $pdo->prepare($sql); $st->execute([(int) $ref]);
            return (bool) $st->fetchColumn();
        } catch (Throwable) { return true; }
    }

    public static function toggleLike(PDO $pdo, int $uid, string $kind, string $ref): array
    {
        self::target($kind, $ref);
        $guard = $kind !== 'photo';
        if ($guard) require_once __DIR__ . '/LikeGuard.php';
        if (self::liked($pdo, $kind, $ref, $uid)) {
            $pdo->prepare('DELETE FROM content_likes WHERE kind = ? AND ref = ? AND user_id = ?')->execute([$kind, $ref, $uid]);
            if ($guard) LikeGuard::unrecord($pdo, $uid, $kind, $ref);
        } else {
            if (!self::exists($pdo, $kind, $ref)) throw new InvalidArgumentException('That isn\'t here any more, so it can\'t be liked.');
            if ($guard) LikeGuard::check($pdo, $uid);
            $pdo->prepare('INSERT INTO content_likes (kind, ref, user_id, created_at) VALUES (?, ?, ?, ?)')->execute([$kind, $ref, $uid, self::now()]);
            if ($guard) LikeGuard::record($pdo, $uid, $kind, $ref);
        }
        return [self::liked($pdo, $kind, $ref, $uid), self::likes($pdo, $kind, $ref)];
    }

    /** Guests' likes (decisions/0009; 0058 §20 as changed 2026-11-05): added straight to the item's count. */
    public static function guestLikes(PDO $pdo, string $kind, string $ref): int
    {
        try { $st = $pdo->prepare('SELECT guest_likes FROM content_like_tally WHERE kind = ? AND ref = ?'); $st->execute([$kind, $ref]); return (int) $st->fetchColumn(); }
        catch (PDOException) { return 0; }   // before the migration runs
    }

    /**
     * A guest likes or unlikes (Jason, 2026-11-05). Once per item per visit; up to Guest::PER_ITEM_CONNECTION guest likes
     * on one item from one connection a day (a family or an office on one connection can each like it). After
     * Guest::LIKES_PER_VISIT likes the account panel asks them to join, with Keep going as a guest (a RuntimeException 401;
     * its message ends "|more" when they may keep going), up to Guest::MAX_PER_VISIT. The checks (LikeGuard) watch every
     * guest closely: they can throw 428, the human check. Returns [liked, likes].
     */
    public static function toggleGuestLike(PDO $pdo, string $kind, string $ref): array
    {
        require_once __DIR__ . '/Guest.php';
        require_once __DIR__ . '/LikeGuard.php';
        self::target($kind, $ref);
        if (Guest::isBot()) throw new InvalidArgumentException('That can\'t be liked from here.');
        $k = $kind . ':' . $ref;
        if (!empty(Guest::liked()[$k])) {   // unliking this visit's own like
            $pdo->prepare('UPDATE content_like_tally SET guest_likes = GREATEST(guest_likes, 1) - 1 WHERE kind = ? AND ref = ?')->execute([$kind, $ref]);
            LikeGuard::unrecord($pdo, null, $kind, $ref);
            Guest::setLiked($k, false);
            return [false, self::likes($pdo, $kind, $ref)];
        }
        $n = count(Guest::liked());
        if ($n >= Guest::MAX_PER_VISIT) throw new RuntimeException('That\'s ' . Guest::MAX_PER_VISIT . ' likes this visit. Create a free account to keep liking: it takes a minute.', 401);
        if ($n >= Guest::LIKES_PER_VISIT && !Guest::more()) throw new RuntimeException('You\'re liking a lot of places. Create a free account to keep liking (it takes a minute): likes from an account count wherever you are.|more', 401);
        if (LikeGuard::ready($pdo)) {
            $st = $pdo->prepare("SELECT COUNT(*) FROM like_events WHERE kind = ? AND ref = ? AND ip_key = ? AND src LIKE 'g:%' AND voided_at IS NULL AND created_at >= ?");
            $st->execute([$kind, $ref, LikeGuard::ipKey(), date('Y-m-d 00:00:00')]);
            if ((int) $st->fetchColumn() >= Guest::PER_ITEM_CONNECTION) throw new InvalidArgumentException('Guests on this connection have liked it today already. Create a free account to add yours.');
        }
        if (!self::exists($pdo, $kind, $ref)) throw new InvalidArgumentException('That isn\'t here any more, so it can\'t be liked.');
        LikeGuard::check($pdo, null);
        $pdo->prepare('INSERT INTO content_like_tally (kind, ref, guest_likes) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE guest_likes = guest_likes + 1')->execute([$kind, $ref]);
        LikeGuard::record($pdo, null, $kind, $ref);
        Guest::setLiked($k, true);
        return [true, self::likes($pdo, $kind, $ref)];
    }

    /** The connection check's records go after 30 days (decisions/0009); the likes stay in the counts. */
    public static function purgeGuestConnections(PDO $pdo): int
    {
        $d = $pdo->prepare('DELETE FROM guest_ip_likes WHERE created_at < ?'); $d->execute([date('Y-m-d H:i:s', time() - 30 * 86400)]);
        return $d->rowCount();
    }

    public static function comments(PDO $pdo, string $kind, string $ref, int $limit = 200): array
    {
        if (!self::ready($pdo)) return [];
        require_once __DIR__ . '/People.php';
        $st = $pdo->prepare("SELECT id, user_id, body, created_at FROM content_comments WHERE kind = ? AND ref = ? AND status = 'visible' ORDER BY created_at LIMIT " . max(1, $limit));
        $st->execute([$kind, $ref]);
        return array_map(function ($c) use ($pdo) { $u = People::user($pdo, (int) $c['user_id']); return $c + ['name' => $u ? People::name($u) : 'Someone who left']; }, $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function commentCount(PDO $pdo, string $kind, string $ref): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->prepare("SELECT COUNT(*) FROM content_comments WHERE kind = ? AND ref = ? AND status = 'visible'");
        $st->execute([$kind, $ref]);
        return (int) $st->fetchColumn();
    }

    public static function comment(PDO $pdo, int $uid, string $kind, string $ref, string $body): array
    {
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);   // limited accounts can't post or send (decisions/0079)
        self::target($kind, $ref);
        require_once __DIR__ . '/AgeGate.php';
        AgeGate::require($pdo, $uid);
        $body = mb_substr(trim(strip_tags($body)), 0, 2000);
        if ($body === '') throw new InvalidArgumentException('Write a comment first.');
        if ($p = ListingSafety::contentProblem($body)) throw new InvalidArgumentException('That comment can\'t be posted: ' . $p . '.');
        $st = $pdo->prepare('SELECT COUNT(*) FROM content_comments WHERE user_id = ? AND created_at >= ?');
        $st->execute([$uid, date('Y-m-d H:i:s', time() - 3600)]);
        if ((int) $st->fetchColumn() >= 30) throw new InvalidArgumentException('That\'s a lot of comments for one hour. Try again later.');
        $pdo->prepare('INSERT INTO content_comments (kind, ref, user_id, body, created_at) VALUES (?, ?, ?, ?, ?)')->execute([$kind, $ref, $uid, $body, self::now()]);
        $id = (int) $pdo->lastInsertId();   // read before any other query: MySQL's insert id is reset by the next statement
        require_once __DIR__ . '/People.php';
        $u = People::user($pdo, $uid);
        return ['id' => $id, 'name' => $u ? People::name($u) : 'You', 'body' => $body];
    }

    /** The writer, or staff who look after content, can remove a comment. */
    public static function removeComment(PDO $pdo, int $uid, int $id): void
    {
        $st = $pdo->prepare('SELECT user_id FROM content_comments WHERE id = ?');
        $st->execute([$id]);
        $who = $st->fetchColumn();
        require_once __DIR__ . '/Journeys.php';
        if ($who === false || ((int) $who !== $uid && !Journeys::staffCan($pdo, $uid, 'journeys'))) throw new InvalidArgumentException('That comment isn\'t yours to remove.');
        $pdo->prepare('DELETE FROM content_comments WHERE id = ?')->execute([$id]);
    }

    public static function setCommentHidden(PDO $pdo, int $id, bool $hide): void
    {
        $pdo->prepare('UPDATE content_comments SET status = ? WHERE id = ?')->execute([$hide ? 'hidden' : 'visible', $id]);
    }

    /** Whether this person may remove comments here (staff who look after content). */
    public static function canTidy(PDO $pdo, ?int $uid): bool
    {
        if (!$uid) return false;
        require_once __DIR__ . '/Journeys.php';
        return Journeys::staffCan($pdo, $uid, 'journeys');
    }
}
