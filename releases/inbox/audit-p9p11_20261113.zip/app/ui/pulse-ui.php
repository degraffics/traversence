<?php
// app/ui/pulse-ui.php — the admin Pulse (decisions/0105, Jason's mockup of 2026-10-21): workspaces 1 and 2 on one screen.
//   header     the Pulse mark, "who you're working as" (Platform Admin, or a department), count chips (Operational
//              Queues, Alerts, Order Mgmt, System Health, Mine, Resolved), the bell, Stream settings, + and search
//   top row    Operational Task Queue (critical and alert cases with their SLA clocks) beside Quick Actions & Navigation
//              and a box to post to the team
//   stream     the Unified Communications Hub: source, severity, subject with its action, received
//   drawer     the case: details, SLA, Quick comment with Post (reply to the sender, or a note to the team), Escalate,
//              Assign, Mark resolved, History, and the tool itself
declare(strict_types=1);

require_once __DIR__ . '/../lib/Pulse.php';
require_once __DIR__ . '/../lib/Workspaces.php';
require_once __DIR__ . '/app-shell.php';   // tv_icon()

function tv_pulse_ago(string $t): string
{
    if ($t === '') return '';
    $s = time() - strtotime($t);
    if ($s < 0) return 'today';
    return $s < 3600 ? max(1, (int) round($s / 60)) . ' min ago' : ($s < 86400 ? (int) round($s / 3600) . ' h ago' : (int) round($s / 86400) . ' d ago');
}

/** "1 h 20 min left" or "Over by 3 h"; '' without a clock. */
function tv_pulse_sla(array $it): string
{
    if (!$it['sla_due'] || $it['state'] === 'done') return '';
    $s = strtotime($it['sla_due']) - time();
    $fmt = function (int $s): string { $s = abs($s); $h = intdiv($s, 3600); $m = intdiv($s % 3600, 60); return $h >= 48 ? round($h / 24) . ' d' : ($h ? $h . ' h' . ($m ? ' ' . $m . ' min' : '') : max(1, $m) . ' min'); };
    return $s >= 0 ? $fmt($s) . ' left' : 'Over by ' . $fmt($s);
}

/**
 * Quick Actions (Jason, 2026-10-21): each opens its tool in a side panel over the dashboard (full screen on a phone),
 * so a quick task is done without leaving; "Open the full page" is there when it isn't quick. Closing after the tool
 * saved something refreshes the board.
 */
function tv_pulse_quick(PDO $pdo, ?array $staff): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $acts = [   // [area it needs, icon, label, the tool's own page]
        ['ecommerce', 'orders', 'Order management', '/admin/backoffice/production', true],   // its own page (orders aren't always in the stream: Jason, 2026-10-30)
        ['sales', 'camera', 'Scan a card', '/admin/sales.php?sec=cards'],
        ['ecommerce', 'plus', 'New client order', '/admin/client-order.php?new=1'],
        ['sales', 'contact', 'Calls today', '/admin/sales.php?sec=calls'],
        ['listings', 'search', 'Find a listing', '/admin/listings.php'],
        ['listings', 'store', 'Add a listing', '/admin/listing-add.php'],
        ['safety', 'shield', 'Review reports', '/admin/reports.php'],
        ['ecommerce', 'qr', 'GO Codes', '/admin/short-codes.php'],
        ['settings', 'settings', 'System settings', '/admin/config/settings'],
    ];
    $h = '<ul class="pq-links">';
    foreach ($acts as $act) { [$area, $icon, $label, $url] = $act; $page = !empty($act[4]);
        if (Workspaces::allowsArea($staff, $area, $pdo)) $h .= '<li><a href="' . $e($url) . '"' . ($page ? ' target="_top"' : ' data-qa="' . $e(tv_admin_embed_url($url)) . '" data-qa-title="' . $e($label) . '"') . '><span class="pq-li" aria-hidden="true">' . tv_icon($icon, 'pu-svg') . '</span>' . $e($label) . '</a></li>'; }
    $h .= '</ul>';
    ob_start(); ?>
<style>
  .qa-p{position:fixed;top:0;right:0;bottom:0;width:min(44rem,100%);z-index:1850;background:#FFFBF2;border-left:1px solid #CBB98D;box-shadow:-18px 0 40px -20px rgba(0,0,0,.45);display:flex;flex-direction:column}
  .qa-p[hidden]{display:none}
  .qa-bar{display:flex;align-items:center;gap:.6rem;padding:.55rem .8rem;background:#3E2B1F;color:#FFF8EA}
  .qa-bar b{flex:1;font:700 1.05rem Georgia,serif;min-width:0}.qa-bar a{color:#F3DDB0;font-size:.88rem;text-decoration:underline;white-space:nowrap}
  .qa-x{width:34px;height:34px;border-radius:999px;border:1px solid rgba(255,248,234,.45);background:transparent;color:#FFF8EA;font-size:1.3rem;cursor:pointer;flex:none}
  .qa-p iframe{flex:1;width:100%;border:0;background:#F6EEDC}
</style>
<aside class="qa-p" id="qa-p" hidden role="dialog" aria-label="Quick action">
  <div class="qa-bar"><b id="qa-t"></b><a id="qa-full" href="#" target="_top">Open the full page ↗</a><button type="button" class="qa-x" id="qa-x" aria-label="Close" title="Close">×</button></div>
  <iframe id="qa-f" title="Quick action"></iframe>
</aside>
<script>
(function () {
  var P = document.getElementById('qa-p'), F = document.getElementById('qa-f'), loads = 0;
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-qa]'); if (!a || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault(); loads = 0;
    document.getElementById('qa-t').textContent = a.getAttribute('data-qa-title');
    document.getElementById('qa-full').href = a.getAttribute('href');
    F.src = a.getAttribute('data-qa'); P.hidden = false;
  });
  F.addEventListener('load', function () { loads++; });   // a second load means the tool saved or moved on
  function close() { P.hidden = true; F.src = 'about:blank'; if (loads > 1) location.reload(); }
  document.getElementById('qa-x').addEventListener('click', close);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !P.hidden) close(); });
})();
</script>
<?php
    return $h . (string) ob_get_clean();
}

/** The whole board. $focus 'stream' scrolls to the stream (workspace 2). */
function tv_pulse_board(PDO $pdo, ?array $staff, int $uid, string $focus = '', string $today = ''): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $items = Pulse::items($pdo, $staff, $uid);
    $open = array_filter($items, fn ($i) => $i['state'] !== 'done');
    $cnt = fn (callable $f) => count(array_filter($open, $f));
    $chips = [
        'queues' => ['Operational Queues', $cnt(fn ($i) => $i['severity'] !== 'event' && $i['source'] !== 'team')],
        'alerts' => ['Alerts', $cnt(fn ($i) => in_array($i['severity'], ['critical', 'alert'], true))],
        'orders' => ['Order Mgmt', $cnt(fn ($i) => in_array($i['source'], ['fulfillment', 'payments'], true))],
        'health' => ['System Health', $cnt(fn ($i) => in_array($i['source'], ['system', 'security'], true))],
        'mine' => ['Mine', $cnt(fn ($i) => $i['mine'])],
        'done' => ['Resolved', count($items) - count($open)],
    ];
    $bell = $cnt(fn ($i) => $i['esc_to_me'] || $i['severity'] === 'critical');
    // who you're working as: Founders and Executives see every department; others their own
    [$lv, $dep] = $staff ? Workspaces::levelOf($staff) : ['founder', ''];
    $views = in_array($lv, ['founder', 'executive'], true) ? ['' => 'Platform Admin'] + array_map(fn ($d) => $d[0], Workspaces::DEPARTMENTS)
        : ($dep !== '' ? [$dep => Workspaces::DEPARTMENTS[$dep][0]] : ['' => 'My work']);
    $queue = array_values(array_filter($open, fn ($i) => in_array($i['severity'], ['critical', 'alert'], true) || $i['esc_to_me']));
    $data = [];
    foreach ($items as $it) $data[$it['key']] = $it + ['play' => Pulse::playbook($it), 'explain' => Pulse::explain($pdo, $it), 'ago' => tv_pulse_ago($it['when']), 'sla' => tv_pulse_sla($it),
        'received' => $it['when'] !== '' ? date('M j, g:i a', strtotime($it['when'])) : '', 'src_label' => Pulse::SOURCES[$it['source']][0]];
    $deptOpts = '<option value="">Everyone</option>';
    foreach (Workspaces::DEPARTMENTS as $k => [$name]) $deptOpts .= '<option value="' . $k . '"' . ($k === $dep ? ' selected' : '') . '>' . $e($name) . '</option>';

    ob_start(); ?>
<style>
  .pb .sr-only,.pb-dr .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
  .pb,.pb-dr{--b:#3E2B1F;--br:#92400E;--am:#B45309;--sg:#8FBCA8;--cr:#FFFBF2;--pa:#F7EFDC;--ln:#EADFC4}
  .pb-head{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .7rem;margin-top:.4rem}
  .pb-mark{width:56px;height:56px;border-radius:999px;border:2px solid #CBB98D;background:var(--cr);color:var(--am);display:flex;align-items:center;justify-content:center;flex:none}
  .pb-mark svg{width:30px;height:30px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
  .pb-as{font:700 1.15rem Georgia,serif;color:var(--b);background:var(--cr);border:1px solid #CBB98D;border-radius:.6rem;padding:.4rem .6rem;max-width:100%}
  .pb-chips{display:flex;flex-wrap:wrap;gap:.35rem;flex:1 1 20rem}
  .pb-chip{border:1px solid #CBB98D;background:var(--cr);color:var(--b);border-radius:999px;padding:.3rem .7rem;font-size:.92rem;font-weight:600;cursor:pointer;white-space:nowrap}
  .pb-chip[aria-pressed=true]{background:#F0B57A;border-color:#E39A52;color:#3E2B1F}
  .pb-chip.hot b{color:#B91C1C}
  .pb-tools{display:flex;gap:.4rem;margin-left:auto}
  .pb-ic{width:36px;height:36px;border-radius:999px;border:1px solid #CBB98D;background:var(--cr);color:var(--am);display:inline-flex;align-items:center;justify-content:center;position:relative;cursor:pointer;padding:0;text-decoration:none}
  .pb-ic[aria-pressed=true]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .pb-ic i{position:absolute;top:-6px;right:-6px;background:#DC2626;color:#fff;font:700 .72rem system-ui;border-radius:999px;padding:.05rem .35rem;font-style:normal}
  .pu-svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
  .pb-search{display:flex;align-items:center;gap:.5rem;margin:.6rem 0}
  .pb-search input{flex:1;min-width:0;background:var(--cr);border:1px solid #CBB98D;border-radius:999px;padding:.5rem .9rem;font-size:1rem;color:var(--b)}
  .pb-top{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:.6rem;margin-top:.4rem}
  .pb-panel{background:var(--pa);border:1px solid var(--ln);border-radius:.8rem;padding:.7rem .8rem;min-width:0}
  .pb-panel>summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between}
  .pb-panel>summary::-webkit-details-marker{display:none}
  .pb-panel>summary::after{content:"▾";color:#8A7355;font-size:1rem;transition:transform .15s}
  .pb-panel:not([open])>summary::after{transform:rotate(-90deg)}
  .pb-panel:not([open]) h2{margin:0}
  .pb-cnt{font:700 .8rem system-ui;background:#DC2626;color:#fff;border-radius:999px;padding:.05rem .45rem;vertical-align:middle;margin-left:.3rem}
  .pb-top{align-items:start;margin:0 0 .6rem}
  .pb-today{margin:0 0 .6rem}
  .pb-panel h2{font:700 1.15rem Georgia,serif;color:var(--b);margin:0 0 .5rem}
  .pq-dd{position:relative;display:inline-block;margin-bottom:.4rem;z-index:30}
  .pq-dd>summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;gap:.35rem;border:1px solid #CBB98D;background:#FFF8EA;color:#3E2B1F;border-radius:999px;padding:.35rem .75rem;font:700 .92rem system-ui,sans-serif}
  .pq-dd>summary::-webkit-details-marker{display:none}.pq-dd>summary::after{content:"▾";color:#8A7355;font-size:.8em}
  .pq-dd[open]>summary,.pq-dd.on>summary{background:var(--sg);border-color:var(--sg);color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .pq-n{font-weight:600;color:#8A7355;font-size:.85em}.pq-dd[open] .pq-n,.pq-dd.on>summary .pq-n{color:#1F3B30}
  .pq-list{position:absolute;left:0;top:calc(100% + .35rem);width:min(16rem,calc(100vw - 6px));background:#FFFBF2;border:1px solid #CBB98D;border-radius:.7rem;box-shadow:0 16px 32px -14px rgba(0,0,0,.4);padding:.3rem}
  .pq-list button{display:flex;align-items:center;gap:.45rem;width:100%;border:0;background:none;padding:.4rem .5rem;border-radius:.45rem;color:#92400E;font:600 .95rem system-ui,sans-serif;text-align:left;cursor:pointer}
  .pq-list button:hover{background:#F5EBD3}.pq-list button[aria-checked=true]{background:#E4F0EA;color:#1F3B30}.pq-list .pq-n{margin-left:auto}
  @media (max-width:767px){.pq-list{position:fixed;left:3px;right:3px;width:auto;top:auto}}
  .pq-row{display:flex;gap:.55rem;align-items:flex-start;padding:.5rem .2rem;border-top:1px solid var(--ln)}
  .pq-row:first-of-type{border-top:0}
  .pq-sev{width:30px;height:30px;border-radius:.45rem;flex:none;display:flex;align-items:center;justify-content:center;color:#fff;font:800 1rem system-ui}
  .pq-sev.critical{background:#DC2626}.pq-sev.alert{background:#EA8A2E}.pq-sev.update{background:#8A7355}.pq-sev.event{background:#8FBCA8}
  .pq-t{min-width:0;flex:1}
  .pq-t a{color:var(--br);text-decoration:underline;font-weight:700;cursor:pointer}
  .pq-t small{display:block;color:#8A7355;font-size:.85rem}
  .pq-t small.over{color:#B91C1C;font-weight:700}
  .pq-links{list-style:none;margin:0 0 .6rem;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(min(12rem,100%),1fr));gap:.3rem .8rem}
  .pq-links a{display:flex;align-items:center;gap:.45rem;color:var(--br);text-decoration:underline;font-weight:600;padding:.25rem 0}
  .pq-li{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:var(--cr);color:var(--am);display:inline-flex;align-items:center;justify-content:center;flex:none}
  .pb-post{border:1px solid #CBB98D;border-radius:.7rem;background:var(--cr);padding:.5rem}
  .pb-post textarea{width:100%;min-height:4.5rem;border:0;background:transparent;resize:vertical;font-size:1rem;color:var(--b)}
  .pb-post .row{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;justify-content:flex-end}
  .pb-post select{background:var(--cr);border:1px solid #CBB98D;border-radius:.5rem;padding:.3rem .4rem;font-size:.9rem;color:var(--b)}
  .pb-btn{border:1px solid #E39A52;background:#F0B57A;color:#3E2B1F;border-radius:999px;padding:.35rem .9rem;font-weight:800;font-size:.85rem;letter-spacing:.04em;text-transform:uppercase;cursor:pointer}
  .pb-btn.sm{text-transform:none;letter-spacing:0;font-weight:700;background:var(--cr);border-color:#CBB98D}
  .pb-btn.go{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30;text-transform:none;letter-spacing:0}
  .pb-stream{margin-top:.8rem;container-type:inline-size}   /* the list fits the room it has (split screen, a rail open), not the screen */
  .pb-sh{display:flex;align-items:center;gap:.5rem;font:700 1.15rem Georgia,serif;color:var(--b);background:var(--pa);border:1px solid var(--ln);border-radius:.8rem .8rem 0 0;padding:.55rem .8rem}
  .pb-sh .pb-mark{width:32px;height:32px}.pb-sh .pb-mark svg{width:18px;height:18px}
  .ps-hd,.ps-row{display:grid;grid-template-columns:2.2rem minmax(7rem,.9fr) 6rem minmax(0,2.4fr) 9rem;gap:.5rem;align-items:center;padding:.5rem .7rem}
  .ps-hd{font-size:.8rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355;background:var(--pa);border-left:1px solid var(--ln);border-right:1px solid var(--ln)}
  .ps-list{border:1px solid var(--ln);border-top:0;border-radius:0 0 .8rem .8rem;overflow:hidden;background:var(--cr)}
  .ps-row{border-top:1px solid var(--ln);cursor:pointer}
  .ps-row:hover,.ps-row.on{background:#F7D9B5}
  .ps-row.done{opacity:.6}
  .ps-row[hidden],.pq-row[hidden],.pb-dr[hidden],.pb-form[hidden],.ps-empty[hidden]{display:none!important}
  .ps-src{display:flex;align-items:center;gap:.4rem;min-width:0;color:var(--b);font-weight:600}
  .ps-ic{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:var(--cr);color:var(--am);display:inline-flex;align-items:center;justify-content:center}
  .ps-sev{font-weight:700;font-size:.92rem}
  .ps-sev.critical{color:#B91C1C}.ps-sev.alert{color:#C2410C}.ps-sev.update{color:#5C4632}.ps-sev.event{color:#2F6B55}
  .ps-sub{min-width:0}
  .ps-sub b{font-weight:600;color:var(--b)}
  .ps-sub a{color:var(--br);text-decoration:underline;font-weight:600;margin-left:.3rem}
  .ps-sub small{display:block;color:#8A7355;font-size:.85rem;overflow-wrap:anywhere}
  .ps-when{font-size:.88rem;color:#5C4632}
  .ps-when small{display:block;color:#B91C1C;font-weight:700}
  .ps-pills{display:inline-flex;gap:.25rem;flex-wrap:wrap;margin-left:.3rem}
  .ps-pill{font-size:.75rem;border-radius:999px;padding:.03rem .4rem;background:#EADFC4;color:#5C4632;font-weight:700}
  .ps-pill.red{background:#FEE2E2;color:#991B1B}.ps-pill.ok{background:#DCEFE5;color:#1F5C43}
  .ps-empty{padding:1rem;color:#5C4632}
  .pb-dr{position:fixed;inset:0;z-index:1900;display:grid;grid-template-rows:minmax(0,1fr);grid-template-columns:minmax(0,1fr) min(28rem,100%);background:rgba(30,20,12,.35)}
  .pb-tool{display:flex;flex-direction:column;min-width:0;min-height:0;height:100%;background:var(--cr);border-right:1px solid #CBB98D;box-shadow:0 0 40px -10px rgba(0,0,0,.45)}
  .pb-tool[hidden]{display:none}
  .pb-tool-bar{display:flex;align-items:center;gap:.5rem;padding:.55rem .8rem;background:#3E2B1F;color:#FFF8EA}
  .pb-tool-bar b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pb-tool-bar a,.pb-tool-bar button{color:#FFF8EA;border:1px solid rgba(255,248,234,.45);background:transparent;border-radius:.5rem;padding:.25rem .6rem;font-weight:700;font-size:.88rem;text-decoration:none;cursor:pointer;white-space:nowrap}
  .pb-tool-sc{flex:1;min-height:0;overflow:hidden;display:flex}
  #pb-tool-f{display:block;flex:1;width:100%;height:100%;min-height:0;border:0;background:transparent}
  .pb-tool iframe{display:block;width:100%;height:100%;min-height:100%;border:0;background:var(--cr)}
  .pb-shade{cursor:pointer}
  .pb-case{grid-column:2;display:flex;flex-direction:column;min-width:0;min-height:0;height:100%;background:var(--cr);box-shadow:-18px 0 40px -20px rgba(0,0,0,.5)}
  .pb-case-hd{padding:.75rem .9rem .6rem;background:#F7E7CC;border-bottom:1px solid #CBB98D}
  .pb-case-hd .top{display:flex;align-items:flex-start;gap:.5rem}
  .pb-case-hd small{display:block;color:#8A7355;font-weight:700;letter-spacing:.05em;text-transform:uppercase;font-size:.75rem}
  .pb-case-hd h3{flex:1;min-width:0;margin:.1rem 0 0;font:700 1.12rem/1.25 Georgia,serif;color:var(--b)}
  .pb-case-hd .x{border:0;background:transparent;font-size:1.6rem;line-height:1;color:var(--b);cursor:pointer;padding:0 .1rem}
  .pb-chips2{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.5rem}
  .pb-c{font-size:.78rem;font-weight:700;border-radius:999px;padding:.12rem .55rem;background:#EADFC4;color:#5C4632;white-space:nowrap}
  .pb-c.critical,.pb-c.over{background:#FEE2E2;color:#991B1B}.pb-c.alert{background:#FFEDD5;color:#9A3412}.pb-c.event,.pb-c.ok{background:#DCEFE5;color:#1F5C43}
  .pb-case-in{flex:1;overflow-y:auto;padding:.75rem .9rem}
  .pb-why{margin:0 0 .6rem;color:var(--b);font-size:.97rem;overflow-wrap:anywhere}
  .pb-opentool{display:flex;align-items:center;justify-content:center;gap:.4rem;width:100%;border:1px solid #3E2B1F;background:#3E2B1F;color:#FFF8EA;border-radius:.6rem;padding:.55rem;font-weight:700;cursor:pointer;margin-bottom:.7rem}
  .pb-acts{display:flex;flex-wrap:wrap;gap:.35rem;margin-bottom:.7rem}
  .pb-acts select{border:1px solid #CBB98D;background:var(--cr);border-radius:999px;padding:.3rem .6rem;font-weight:700;font-size:.85rem;color:var(--b);max-width:11rem}
  .pb-seg{display:inline-flex;border:1px solid #CBB98D;border-radius:999px;overflow:hidden}
  .pb-seg button{border:0;background:var(--cr);padding:.3rem .65rem;font-size:.82rem;font-weight:700;color:var(--b);cursor:pointer}
  .pb-seg button[aria-pressed=true]{background:#8FBCA8;color:#1F3B30}
  .pb-tl{list-style:none;margin:.3rem 0 0;padding:0 0 0 .9rem;border-left:2px solid var(--ln);font-size:.9rem}
  .pb-tl li{position:relative;padding:.1rem 0 .6rem}
  .pb-tl li::before{content:"";position:absolute;left:-1.25rem;top:.4rem;width:.6rem;height:.6rem;border-radius:999px;background:#CBB98D}
  .pb-tl li.order::before{background:#fff;border:2px solid #CBB98D}.pb-tl li.order b{color:#8A7355;font-weight:600}.pb-tl li.reply::before{background:#B45309}.pb-tl li.resolve::before{background:#8FBCA8}.pb-tl li.escalate::before{background:#DC2626}
  .pb-tl small{display:block;color:#8A7355}
  .pb-steps{list-style:none;display:flex;margin:.2rem 0 .6rem;padding:0;counter-reset:st}
  .pb-steps li{flex:1;min-width:0;text-align:center;font-size:.72rem;font-weight:700;color:#8A7355;position:relative;padding-top:1.5rem}
  .pb-steps li::before{content:"";position:absolute;top:.35rem;left:50%;transform:translateX(-50%);width:.9rem;height:.9rem;border-radius:999px;border:2px solid #CBB98D;background:var(--cr);z-index:1}
  .pb-steps li::after{content:"";position:absolute;top:.75rem;left:-50%;width:100%;height:2px;background:#CBB98D}
  .pb-steps li:first-child::after{display:none}
  .pb-steps li.done{color:#2F6B55}.pb-steps li.done::before{background:#8FBCA8;border-color:#8FBCA8}.pb-steps li.done::after{background:#8FBCA8}
  .pb-steps li.current{color:var(--b)}.pb-steps li.current::before{box-shadow:0 0 0 4px rgba(143,188,168,.4)}
  .pb-next{display:flex;flex-wrap:wrap;gap:.4rem;margin-bottom:.7rem}
  .pb-track,.pb-play li input.pb-track{display:block;width:100%;height:auto;appearance:auto;box-sizing:border-box;margin-top:.45rem;padding:.45rem .65rem;border:1px solid #CBB98D;border-radius:.5rem;background:#FFFBF2;color:#3E2B1F;font:inherit;font-size:.95rem}
  .pb-next .lead{flex:1 1 100%;font-size:.82rem;font-weight:700;color:#8A7355;text-transform:uppercase;letter-spacing:.05em}
  .pb-c{border:0;cursor:pointer;font-family:inherit}
  .pb-c[aria-pressed=true]{outline:2px solid #3E2B1F;outline-offset:1px}
  .pb-ex{margin:.5rem 0 0;padding:.5rem .6rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;font-size:.9rem;color:#3E2B1F}
  .pb-ex a{color:#92400E;text-decoration:underline;font-weight:700}
  .pb-play{list-style:none;margin:.2rem 0 .8rem;padding:0;counter-reset:pp}
  .pb-play li{display:grid;grid-template-columns:1.6rem minmax(0,1fr) auto;gap:.15rem .5rem;align-items:start;padding:.5rem 0;border-top:1px solid var(--ln);counter-increment:pp}
  .pb-play li:first-child{border-top:0}
  .pb-play .pb-ext{display:inline-flex;align-items:center;margin-top:.35rem;padding:.25rem .65rem;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#92400E;font-weight:700;font-size:.82rem;text-decoration:none}
  .pb-play .pb-ext + .pb-ext{margin-left:.35rem}
  .pb-play li.pb-go{background:rgba(143,188,168,.18);box-shadow:0 0 0 3px rgba(143,188,168,.45);border-radius:.5rem;padding-left:.35rem;padding-right:.35rem}
  .pb-play input{width:1.15rem;height:1.15rem;margin-top:.15rem;accent-color:#2F6B55}
  .pb-play b{font-weight:700;color:var(--b)}
  .pb-play b::before{content:counter(pp) ". ";color:#8A7355}
  .pb-play small{display:block;color:#5C4632;font-size:.86rem;line-height:1.35}
  .pb-play li.done b{color:#2F6B55;text-decoration:line-through;text-decoration-color:rgba(47,107,85,.5)}
  .pb-play .auto{font-size:.72rem;font-weight:700;color:#2F6B55;background:#DCEFE5;border-radius:999px;padding:0 .4rem;margin-left:.3rem}
  .pb-play button{white-space:nowrap}
  .pb-mg{display:flex;flex-wrap:wrap;gap:.35rem}
  .pb-mg .no{color:#991B1B;border-color:#E5B4B4}
  .pb-form{margin:.6rem 0;padding:.6rem;border:1px solid #CBB98D;border-radius:.7rem;background:#FFF8EA;display:grid;grid-template-columns:minmax(0,1fr);gap:.4rem}
  .pb-form b{font:700 1rem Georgia,serif;color:var(--b)}
  .pb-form label{font-size:.85rem;font-weight:700;color:#5C4632;display:grid;gap:.15rem;min-width:0}
  .pb-form input,.pb-form select,.pb-form textarea{border:1px solid #CBB98D;background:var(--cr);border-radius:.5rem;padding:.4rem .55rem;font-size:.95rem;color:var(--b);font-weight:400;width:100%;min-width:0;box-sizing:border-box}
  .pb-form .row{display:flex;gap:.4rem;justify-content:flex-end}
  .pb-vend{font-size:.88rem;margin:.1rem 0 .6rem;padding:.45rem .6rem;border:1px dashed #CBB98D;border-radius:.6rem}
  .pb-vend b{display:block;font-size:.78rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355}
  .pb-vj{display:flex;justify-content:space-between;gap:.5rem;padding:.3rem 0;border-top:1px solid #EADFC4}
  .pb-vj strong{display:block;font-size:.9rem}.pb-vj span{display:block;color:#5C4632}
  .pb-margin{margin-top:.35rem;padding:.3rem .5rem;border-radius:.5rem;background:#DCEFE5;color:#1F5C43;font-weight:700}
  .pb-margin.neg{background:#FEE2E2;color:#991B1B}
  .pb-form details{border-top:1px dashed #CBB98D;padding-top:.3rem}.pb-form details>summary{cursor:pointer;font-weight:700;color:#92400E}.pb-form details label{margin-top:.35rem}
  .pb-tl .ed{margin-left:.4rem;font-size:.8rem;color:#92400E;text-decoration:underline;background:none;border:0;cursor:pointer;padding:0}
  .pb-case h4{font:700 1rem Georgia,serif;margin:.8rem 0 .2rem;color:var(--b)}
  @media (max-width:767px){.pb-dr{grid-template-columns:1fr;background:none}.pb-case{grid-column:1;grid-row:1}.pb-tool{grid-column:1;grid-row:1;z-index:2}.pb-shade{display:none}}
  .pb-msg{font-size:.9rem;margin:.3rem 0 0;color:#1F5C43;font-weight:600}
  .pb-msg.no{color:#991B1B}
  @media (max-width:900px){.pb-top{grid-template-columns:1fr}}
  @media (max-width:767px){
    .ps-hd{display:none}
    .ps-row{grid-template-columns:2.2rem minmax(0,1fr);grid-template-areas:"ic src" "ic sub" "ic when";row-gap:.15rem}
    .ps-row>.ps-ic{grid-area:ic;align-self:start}.ps-row>.ps-src{grid-area:src}.ps-row>.ps-sev{display:none}.ps-row>.ps-sub{grid-area:sub}.ps-row>.ps-when{grid-area:when}
    .ps-src .ps-sevm{display:inline}
    .pb-tools{margin-left:0}
  }
  .ps-sevm{display:none;font-weight:700;font-size:.85rem}
  /* narrow room on a wide screen (split screen, the admin rail beside it): the same stacked rows as a phone */
  @container (max-width:48rem){
    .ps-hd{display:none}
    .ps-row{grid-template-columns:2.2rem minmax(0,1fr);grid-template-areas:"ic src" "ic sub" "ic when";row-gap:.15rem}
    .ps-row>.ps-ic{grid-area:ic;align-self:start}.ps-row>.ps-src{grid-area:src}.ps-row>.ps-sev{display:none}.ps-row>.ps-sub{grid-area:sub}.ps-row>.ps-when{grid-area:when}
    .ps-src .ps-sevm{display:inline}
  }
</style>
<div class="pb" id="pb" data-focus="<?= $e($focus) ?>">
  <div class="pb-top">
    <details class="pb-panel" data-keep="pq" open>
      <summary><h2 id="pq-h">Operational Task Queue <span class="pb-cnt"><?= count($queue) ?></span></h2></summary>
      <?php $qcount = array_count_values(array_column($queue, 'source')); ?>
      <details class="pq-dd" id="pq-dd"><summary aria-label="Filter the queue"><?= tv_icon('filter', 'pu-svg') ?><span data-qlab>All</span> <span class="pq-n" data-qn><?= count($queue) ?></span></summary>
        <div class="pq-list" role="menu" aria-label="Show">
          <button type="button" role="menuitemradio" data-qsrc="" data-lab="All" data-n="<?= count($queue) ?>" aria-checked="true">All <span class="pq-n"><?= count($queue) ?></span></button>
          <?php foreach ($qcount as $src => $nq): ?><button type="button" role="menuitemradio" data-qsrc="<?= $e($src) ?>" data-lab="<?= $e(Pulse::SOURCES[$src][0]) ?>" data-n="<?= $nq ?>" aria-checked="false"><?= tv_icon(Pulse::SOURCES[$src][1], 'pu-svg') ?><?= $e(Pulse::SOURCES[$src][0]) ?> <span class="pq-n"><?= $nq ?></span></button><?php endforeach; ?>
        </div>
      </details>
      <?php foreach ($queue as $it): $sla = tv_pulse_sla($it); ?>
      <div class="pq-row" data-key="<?= $e($it['key']) ?>" data-src="<?= $e($it['source']) ?>" data-dept="<?= $e($it['dept']) ?>">
        <span class="pq-sev <?= $it['severity'] ?>" aria-hidden="true">!</span>
        <div class="pq-t"><a data-open><?= $e($it['title']) ?></a> <a data-open>[<?= $e($it['action']) ?>]</a>
          <small class="<?= $it['over'] ? 'over' : '' ?>" data-due="<?= $e((string) $it['sla_due']) ?>"><?= $e(Pulse::SEVERITY[$it['severity']]) ?><?= $sla !== '' ? ' · SLA ' . $e($sla) : '' ?><?= $it['esc_to_me'] ? ' · Escalated to you' : '' ?></small></div>
      </div>
      <?php endforeach; ?>
      <?php if (!$queue): ?><p class="ps-empty">Nothing urgent. No critical or alert cases are open.</p><?php endif; ?>
    </details>
    <details class="pb-panel" data-keep="qa" open>
      <summary><h2 id="qa-h">Quick Actions &amp; Navigation</h2></summary>
      <?= tv_pulse_quick($pdo, $staff) ?>
      <div class="pb-post">
        <label class="sr-only" for="pb-body">Post to the team</label>
        <textarea id="pb-body" placeholder="Post to your team…"></textarea>
        <div class="row"><label class="sr-only" for="pb-dept">Post to</label><select id="pb-dept"><?= $deptOpts ?></select><button type="button" class="pb-btn" data-post-team>Post</button></div>
        <p class="pb-msg" id="pb-msg" role="status"></p>
      </div>
    </details>
  </div>

  <?php if ($today !== ''): ?><details class="pb-panel pb-today" data-keep="day"><summary><h2>Your day</h2></summary><?= $today ?></details><?php endif; ?>
  <div class="pb-head">
    <span class="pb-mark" aria-hidden="true"><?= tv_icon('pulse', '') ?></span>
    <label class="sr-only" for="pb-as">Working as</label>
    <select class="pb-as" id="pb-as"><?php foreach ($views as $k => $v): ?><option value="<?= $e($k) ?>"><?= $e($v) ?></option><?php endforeach; ?></select>
    <div class="pb-chips" role="group" aria-label="Show">
      <?php foreach ($chips as $k => [$label, $n]): ?><button type="button" class="pb-chip<?= $k === 'alerts' && $n ? ' hot' : '' ?>" data-chip="<?= $k ?>" aria-pressed="false"><?= $e($label) ?> (<b><?= (int) $n ?></b>)</button><?php endforeach; ?>
    </div>
    <div class="pb-tools">
      <button type="button" class="pb-ic" data-chip-bell aria-pressed="false" title="Critical, and escalated to you" aria-label="Critical, and escalated to you"><?= tv_icon('bell', 'pu-svg') ?><?= $bell ? '<i>' . $bell . '</i>' : '' ?></button>
      <a class="pb-ic" href="/admin/pulse/settings" target="_top" title="Stream settings" aria-label="Stream settings"><?= tv_icon('settings', 'pu-svg') ?></a>
    </div>
  </div>
  <div class="pb-search">
    <button type="button" class="pb-ic" data-compose title="Post to the team" aria-label="Post to the team"><?= tv_icon('plus', 'pu-svg') ?></button>
    <label class="sr-only" for="pb-q">Search all platform events</label>
    <input id="pb-q" type="search" placeholder="Search all platform events…" autocomplete="off">
  </div>

  <section class="pb-stream" id="pu-stream" aria-labelledby="ps-h">
    <div class="pb-sh"><span class="pb-mark" aria-hidden="true"><?= tv_icon('pulse', '') ?></span><span id="ps-h">Unified Communications Hub (Pulse Stream)</span></div>
    <div class="ps-hd" aria-hidden="true"><span></span><span>From</span><span>Severity</span><span>Subject</span><span>Received</span></div>
    <div class="ps-list" id="ps-list">
      <?php foreach ($items as $it): $sla = tv_pulse_sla($it); ?>
      <div class="ps-row<?= $it['state'] === 'done' ? ' done' : '' ?>" tabindex="0" role="button" data-key="<?= $e($it['key']) ?>" data-src="<?= $e($it['source']) ?>" data-sev="<?= $e($it['severity']) ?>"
        data-dept="<?= $e($it['dept']) ?>" data-state="<?= $it['state'] === 'done' ? 'done' : 'open' ?>" data-mine="<?= $it['mine'] ? 1 : 0 ?>" data-esc="<?= $it['esc_to_me'] ? 1 : 0 ?>"
        data-text="<?= $e(mb_strtolower($it['title'] . ' ' . $it['why'] . ' ' . Pulse::SOURCES[$it['source']][0])) ?>">
        <span class="ps-ic" aria-hidden="true"><?= tv_icon(Pulse::SOURCES[$it['source']][1], 'pu-svg') ?></span>
        <span class="ps-src"><?= $e(Pulse::SOURCES[$it['source']][0]) ?> <span class="ps-sevm ps-sev <?= $it['severity'] ?>">· <?= $e(Pulse::SEVERITY[$it['severity']]) ?></span></span>
        <span class="ps-sev <?= $it['severity'] ?>"><?= $e(Pulse::SEVERITY[$it['severity']]) ?></span>
        <span class="ps-sub"><b><?= $e($it['title']) ?></b><a data-open>[<?= $e($it['action']) ?>]</a>
          <span class="ps-pills"><?= $it['esc'] ? '<span class="ps-pill red">Escalated to ' . ($it['esc'] === 1 ? 'Manager' : 'Director') . '</span>' : '' ?><?= $it['who'] !== '' ? '<span class="ps-pill ok">' . ($it['mine'] ? 'Yours' : $e($it['who'])) . '</span>' : '' ?><?= $it['state'] === 'done' ? '<span class="ps-pill ok">Resolved</span>' : '' ?></span>
          <?= $it['why'] !== '' ? '<small>' . $e($it['why']) . '</small>' : '' ?></span>
        <span class="ps-when"><?= $e($it['when'] !== '' ? date('M j, g:i a', strtotime($it['when'])) : '') ?><?= $sla !== '' ? '<small' . ($it['over'] ? '' : ' style="color:#8A7355;font-weight:400"') . '>' . $e($sla) . '</small>' : '' ?></span>
      </div>
      <?php endforeach; ?>
      <p class="ps-empty" hidden>Nothing here. All caught up.</p>
    </div>
  </section>
</div>

<div class="pb-dr" id="pb-dr" hidden>
  <div class="pb-shade" data-dr-close aria-hidden="true"></div>
  <section class="pb-tool" id="pb-tool" aria-label="The tool" hidden>
    <div class="pb-tool-bar"><button type="button" data-tool-close>&larr; Case</button><b id="pb-tool-t"></b><a id="pb-tool-full" href="#" target="_blank" rel="noopener">Full page &#8599;</a></div>
    <div class="pb-tool-sc"><iframe id="pb-tool-f" title="The tool"></iframe></div>
  </section>
  <aside class="pb-case" role="dialog" aria-modal="true" aria-labelledby="pb-dr-h">
    <div class="pb-case-hd"><div class="top"><div style="flex:1;min-width:0"><small id="pb-dr-no">Case</small><h3 id="pb-dr-h"></h3></div><button type="button" class="x" data-dr-close aria-label="Close">&times;</button></div>
      <div class="pb-chips2" id="pb-dr-chips" role="group" aria-label="About this case (tap for what each means)"></div>
      <p class="pb-ex" id="pb-dr-ex" hidden></p></div>
    <div class="pb-case-in">
      <p class="pb-why" id="pb-dr-why"></p>
      <div id="pb-dr-order" hidden><ol class="pb-steps" id="pb-dr-steps" aria-label="Where the order is"></ol></div>
      <div id="pb-dr-vend" hidden></div>
      <h4 style="margin-top:.2rem">How to clear this</h4>
      <ol class="pb-play" id="pb-dr-play"></ol>
      <button type="button" class="pb-opentool" id="pb-dr-tool" data-tool-open><?= tv_icon('link', 'pu-svg') ?><span>Open the order</span></button>
      <div class="pb-acts">
        <button type="button" class="pb-btn sm" data-dr="mine" id="pb-dr-take">Take it</button>
        <label class="sr-only" for="pb-dr-to">Assign to</label><select id="pb-dr-to"></select>
        <button type="button" class="pb-btn sm" data-dr="escalate" id="pb-dr-esc">Escalate</button>
        <button type="button" class="pb-btn go" data-dr="done" id="pb-dr-done">Resolve</button>
      </div>
      <div class="pb-post">
        <label class="sr-only" for="pb-dr-body">Comment</label>
        <textarea id="pb-dr-body" placeholder="Write a comment…"></textarea>
        <div class="row" style="justify-content:space-between"><span class="pb-seg" role="group" aria-label="Post as" id="pb-dr-mode"></span><button type="button" class="pb-btn" data-dr-post>Post</button></div>
        <p class="pb-msg" id="pb-dr-msg" role="status"></p>
      </div>
      <div id="pb-dr-mgw"><h4>Manage</h4><div class="pb-mg" id="pb-dr-mg"></div></div>
      <div class="pb-form" id="pb-dr-form" hidden></div>
      <h4>History</h4>
      <ul class="pb-tl" id="pb-dr-hist"></ul>
    </div>
  </aside>
</div>
<script type="application/json" id="pb-data"><?= json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?></script>
<script>
(function () {
  var CSRF = <?= json_encode((string) ($_SESSION['csrf_token'] ?? '')) ?>, D = JSON.parse(document.getElementById('pb-data').textContent);
  var root = document.getElementById('pb'), rows = [].slice.call(document.querySelectorAll('.ps-row')), qrows = [].slice.call(document.querySelectorAll('.pq-row'));
  var chip = '', q = '', view = '', qsrc = '', cur = null, dr = document.getElementById('pb-dr');
  function api(body) {
    return fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); });
  }
  function el(t, txt) { var n = document.createElement(t); if (txt != null) n.textContent = txt; return n; }
  function apply() {
    var n = 0;
    rows.forEach(function (r) {
      var s = r.dataset, open = s.state !== 'done', show;
      show = chip === 'done' ? !open : open;
      if (chip === 'queues') show = open && s.sev !== 'event' && s.src !== 'team';
      if (chip === 'alerts') show = open && (s.sev === 'critical' || s.sev === 'alert');
      if (chip === 'orders') show = open && (s.src === 'fulfillment' || s.src === 'payments');
      if (chip === 'health') show = open && (s.src === 'system' || s.src === 'security');
      if (chip === 'mine') show = open && s.mine === '1';
      if (chip === 'bell') show = open && (s.sev === 'critical' || s.esc === '1');
      if (view && s.dept && s.dept !== view) show = false;
      if (q && s.text.indexOf(q) < 0) show = false;
      r.hidden = !show; if (show) n++;
    });
    document.querySelector('#ps-list .ps-empty').hidden = n > 0;
    qrows.forEach(function (r) { r.hidden = (qsrc && r.dataset.src !== qsrc) || (view && r.dataset.dept && r.dataset.dept !== view); });
  }
  document.querySelectorAll('[data-chip]').forEach(function (c) { c.addEventListener('click', function () {
    var on = c.getAttribute('aria-pressed') !== 'true';
    document.querySelectorAll('[data-chip]').forEach(function (o) { o.setAttribute('aria-pressed', 'false'); });
    c.setAttribute('aria-pressed', on ? 'true' : 'false'); chip = on ? c.dataset.chip : ''; document.querySelector('[data-chip-bell]').setAttribute('aria-pressed', 'false'); apply();
  }); });
  document.querySelector('[data-chip-bell]').addEventListener('click', function () {
    document.querySelectorAll('[data-chip]').forEach(function (o) { o.setAttribute('aria-pressed', 'false'); });
    chip = chip === 'bell' ? '' : 'bell'; this.setAttribute('aria-pressed', chip === 'bell' ? 'true' : 'false'); apply(); document.getElementById('pu-stream').scrollIntoView({ behavior: 'smooth' });
  });
  var qdd = document.getElementById('pq-dd');
  if (qdd) {
    qdd.querySelectorAll('[data-qsrc]').forEach(function (b) { b.addEventListener('click', function () {
      qdd.querySelectorAll('[data-qsrc]').forEach(function (o) { o.setAttribute('aria-checked', o === b ? 'true' : 'false'); });
      qsrc = b.dataset.qsrc; qdd.querySelector('[data-qlab]').textContent = b.dataset.lab; qdd.querySelector('[data-qn]').textContent = b.dataset.n;
      qdd.classList.toggle('on', qsrc !== ''); qdd.removeAttribute('open'); apply();
    }); });
    document.addEventListener('click', function (e) { if (qdd.open && !qdd.contains(e.target)) qdd.removeAttribute('open'); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') qdd.removeAttribute('open'); });
  }
  document.getElementById('pb-q').addEventListener('input', function () { q = this.value.trim().toLowerCase(); apply(); });
  document.getElementById('pb-as').addEventListener('change', function () { view = this.value; apply(); });
  document.querySelector('[data-compose]').addEventListener('click', function () { var t = document.getElementById('pb-body'); t.scrollIntoView({ block: 'center' }); t.focus(); });
  document.querySelector('[data-post-team]').addEventListener('click', function () {
    var t = document.getElementById('pb-body'), m = document.getElementById('pb-msg');
    api({ do: 'post', key: '', dept: document.getElementById('pb-dept').value, body: t.value }).then(function (j) {
      m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? j.message + ' It shows in the stream next time it loads.' : j.error.message; if (j.ok) t.value = '';
    });
  });

  // the case drawer
  function row(k) { return rows.filter(function (r) { return r.dataset.key === k; })[0]; }
  var SEV = { critical: 'Critical', alert: 'Alert', update: 'Update', event: 'Event' }, mode = 'team';
  var TOOL = { order: 'Open the order', report: 'Open the report', claim: 'Open the claim', listing: 'Open the listing' };
  function toolName(u) { return /order|client-order/.test(u) ? TOOL.order : /reports/.test(u) ? TOOL.report : /claims/.test(u) ? TOOL.claim : 'Open the tool'; }
  function pill(t, c, ex) { var s = el('button', t); s.type = 'button'; s.className = 'pb-c' + (c ? ' ' + c : ''); if (ex) s.dataset.ex = ex; s.setAttribute('aria-pressed', 'false'); return s; }
  var ME = 0;
  var goTo = null;   // the step the daily report opened this case at
  function fill(c) {
    var it = D[cur]; if (c.me) ME = c.me;
    document.getElementById('pb-dr-no').textContent = (c.case_no ? 'Case #' + c.case_no + ' · ' : '') + it.src_label + ' · ' + it.received;
    document.getElementById('pb-dr-h').textContent = it.title;
    var ch = document.getElementById('pb-dr-chips'); ch.textContent = '';
    ch.appendChild(pill(it.src_label, '', 'source'));
    ch.appendChild(pill(SEV[it.severity], it.severity, 'severity'));
    ch.appendChild(pill(it.sla ? 'SLA ' + it.sla : 'No clock', it.over ? 'over' : '', 'sla'));
    ch.appendChild(pill(it.state === 'done' ? 'Resolved' : 'Open', it.state === 'done' ? 'ok' : '', 'status'));
    ch.appendChild(pill(it.who ? 'With ' + it.who : 'Unassigned', '', 'assigned'));
    ch.appendChild(pill(it.esc ? 'Escalated to the ' + (it.esc === 1 ? 'Manager' : 'Director') : 'Not escalated', it.esc ? 'over' : '', 'escalation'));
    document.getElementById('pb-dr-ex').hidden = true;
    // the procedure: auto-done steps from the data, the rest ticked by hand
    var ticked = c.ticked || [], pl = document.getElementById('pb-dr-play'); pl.textContent = '';
    (it.play || []).forEach(function (st, n) {
      var done = st.auto || ticked.indexOf(n) >= 0, li = el('li'); li.className = done ? 'done' : '';
      var cb = el('input'); cb.type = 'checkbox'; cb.checked = done; cb.disabled = !!st.auto; cb.dataset.step = n; cb.setAttribute('aria-label', 'Done: ' + st.t); li.appendChild(cb);
      var tx = el('div'); var b = el('b', st.t); tx.appendChild(b); if (st.auto) tx.appendChild(el('span', 'done')).className = 'auto'; if (st.h) tx.appendChild(el('small', st.h));
      (st.exts || (st.ext ? [st.ext] : [])).forEach(function (x) { var xa = el('a', 'Open ' + x[0] + ' ↗'); xa.href = x[1]; xa.target = '_blank'; xa.rel = 'noopener'; xa.className = 'pb-ext'; tx.appendChild(xa); });   // the outside service this step needs, right here (exts: more than one, e.g. a site health finding's page, screenshot and proposal)
      li.appendChild(tx);
      var a = st.act, btn = null;
      if (a && a[0] === 'tool') { btn = el('button', 'Open'); btn.dataset.toolUrl = a[1]; }
      if (a && a[0] === 'reply' && it.reply_to) { btn = el('button', 'Write it'); btn.dataset.write = n; }
      if (a && a[0] === 'reply' && !it.reply_to && it.key.indexOf('post:') === 0) { btn = el('button', 'Write it'); btn.dataset.write = n; }
      if (a && a[0] === 'stage') { btn = el('button', a[2]); btn.dataset.stage = a[1]; }
      if (a && a[0] === 'do' && it.state !== 'done') { btn = el('button', a[2]); btn.dataset.doWhat = a[1]; }
      if (a && a[0] === 'form' && it.state !== 'done') { btn = el('button', a[2]); btn.dataset.formStep = n; }
      if (a && a[0] === 'resolve' && it.state !== 'done') { btn = el('button', 'Resolve'); btn.dataset.dr = 'done'; }
      if (btn) { btn.type = 'button'; btn.className = 'pb-btn sm'; li.appendChild(btn); } else li.appendChild(el('span'));
      pl.appendChild(li);
    });
    // opened from the daily report at a step (#case=KEY&step=N): that step lit, its button ready for one tap
    if (goTo && goTo.k === cur && pl.children[goTo.n]) {
      var gl = pl.children[goTo.n]; gl.classList.add('pb-go');
      if (!goTo.shown && (c.case_no !== undefined || c.history)) { goTo.shown = true; setTimeout(function () { gl.scrollIntoView({ block: 'center', behavior: 'smooth' }); var gb = gl.querySelector('button'); if (gb) gb.focus({ preventScroll: true }); }, 120); }
    }
    document.getElementById('pb-dr-why').textContent = it.body || it.why || '';
    var ob = document.getElementById('pb-dr-order'); ob.hidden = !it.order;
    if (it.order) {
      var ol = document.getElementById('pb-dr-steps'); ol.textContent = '';
      it.order.steps.forEach(function (st) { var li = el('li', st.label); li.className = (st.done ? 'done' : '') + (st.current ? ' current' : ''); ol.appendChild(li); });
    }
    var tb = document.getElementById('pb-dr-tool'); tb.hidden = !it.url; tb.querySelector('span').textContent = toolName(it.url || '');
    document.getElementById('pb-dr-take').hidden = !!it.mine || it.state === 'done';
    document.getElementById('pb-dr-esc').hidden = it.state === 'done' || it.esc >= 2;
    var to = document.getElementById('pb-dr-to'); to.textContent = ''; var o0 = el('option', 'Assign to…'); o0.value = ''; to.appendChild(o0);
    (c.team || []).forEach(function (p) { var o = el('option', p.name); o.value = p.id; to.appendChild(o); });
    var done = document.getElementById('pb-dr-done'); done.textContent = it.state === 'done' ? 'Reopen' : 'Resolve'; done.dataset.dr = it.state === 'done' ? 'undo' : 'done';
    var seg = document.getElementById('pb-dr-mode'); seg.textContent = '';
    var opts = (it.reply_to ? [['reply', 'Reply to ' + (it.reply_to[1] || it.reply_to[0])]] : []).concat([['team', 'Note to the team']]);
    if (!opts.some(function (x) { return x[0] === mode; })) mode = opts[0][0];
    opts.forEach(function (x) { var b = el('button', x[1]); b.type = 'button'; b.dataset.mode = x[0]; b.setAttribute('aria-pressed', x[0] === mode ? 'true' : 'false'); seg.appendChild(b); });
    document.getElementById('pb-dr-body').placeholder = mode === 'reply' ? 'Write to ' + (it.reply_to[1] || it.reply_to[0]) + '… (sent by email)' : 'A note for the team…';
    var h = document.getElementById('pb-dr-hist'); h.textContent = '';
    (c.history || []).forEach(function (n) { var li = el('li'); li.className = n.kind; li.appendChild(el('b', n.by + ' ')); li.appendChild(document.createTextNode(n.body + (n.to ? ' (emailed to ' + n.to + ')' : '')));
      if (ME && n.uid === ME && (n.kind === 'note' || n.kind === 'reply')) {
        if (n.kind === 'note') { var ee = el('button', 'Edit'); ee.type = 'button'; ee.className = 'ed'; ee.dataset.noteEdit = n.id; ee.dataset.text = n.body.replace(/ \(edited\)$/, ''); li.appendChild(ee); }
        var dd = el('button', 'Delete'); dd.type = 'button'; dd.className = 'ed'; dd.dataset.noteDel = n.id; li.appendChild(dd); }
      var at = /^\d{4}-\d\d-\d\d /.test(n.at || '') ? new Date(n.at.replace(' ', 'T')) : null;
      li.appendChild(el('small', at && !isNaN(at) ? at.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : n.at)); h.appendChild(li); });
    // vendor jobs on an order (4OVER's layout) and the margin: staff only, never the client
    var vb = document.getElementById('pb-dr-vend'); vb.textContent = ''; vb.hidden = !it.order || it.order.shop || (!c.vendor && !(it.order.work || []).length);
    if (it.order && (it.order.work || []).length) {   // the order's work orders, as they stand
      var wb = el('div'); wb.className = 'pb-vend'; wb.appendChild(el('b', 'Work orders'));
      it.order.work.forEach(function (w) { var r = el('div'); r.className = 'pb-vj'; var t = el('div'); t.appendChild(el('strong', w.no + ' · ' + w.vendor));
        t.appendChild(el('span', [w.label, w.status === 'sent' ? (w.opened ? 'opened by the vendor' : 'not opened yet') : '', w.due ? 'must have ' + w.due : '', w.tracking ? 'tracking ' + w.tracking : ''].filter(Boolean).join(' · ')));
        r.appendChild(t); wb.appendChild(r); });
      vb.appendChild(wb);
    }
    if (c.vendor && it.order && !it.order.shop && (c.vendor.jobs.length || !(it.order.work || []).length)) {
      var dl = document.getElementById('pb-vlist') || document.body.appendChild(el('datalist')); dl.id = 'pb-vlist'; dl.textContent = '';
      c.vendor.vendors.forEach(function (v) { var o = el('option'); o.value = v; dl.appendChild(o); });
      VORD = c.vendor.orders || []; VITEMS = c.vendor.items || [];
      var bx = el('div'); bx.className = 'pb-vend'; bx.appendChild(el('b', 'Vendor jobs (our team only)'));
      if (!c.vendor.jobs.length) bx.appendChild(el('div', 'None yet.'));
      var usd = function (x) { return x === null || x === undefined ? '' : '$' + (x / 100).toFixed(2); };
      c.vendor.jobs.forEach(function (j) {
        var row = el('div'); row.className = 'pb-vj';
        var t = el('div'); t.appendChild(el('strong', j.vendor + (j.vendor_order_no && j.vendor_order_no.indexOf('old-') !== 0 ? ' #' + j.vendor_order_no : '')));
        t.appendChild(el('span', 'For ' + (j.line_id ? itemName(j.line_id) || 'an item' : 'the whole order')));
        t.appendChild(el('span', [j.po_name, j.job_no ? 'Job ' + j.job_no : '', j.job_status, j.tracking ? 'Tracking ' + j.tracking : '', j.completion_on ? 'Done by ' + j.completion_on : '', usd(j.total_cents)].filter(Boolean).join(' · ')));
        row.appendChild(t); var ub = el('button', 'Update'); ub.type = 'button'; ub.className = 'ed'; ub.dataset.vjob = j.id; row.appendChild(ub); bx.appendChild(row);
      });
      var mg2 = c.vendor.margin;
      if (mg2) { var mm = el('div'); mm.className = 'pb-margin' + (mg2.margin < 0 ? ' neg' : ''); mm.textContent = 'Client price ' + usd(mg2.price) + ' · vendor cost ' + usd(mg2.cost) + ' · margin ' + usd(mg2.margin) + ' (' + mg2.pct + '%)'; bx.appendChild(mm); }
      var vrow = el('div'); vrow.style.cssText = 'display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.45rem';   // two buttons, apart
      var ab = el('button', '+ Add a vendor job'); ab.type = 'button'; ab.className = 'pb-btn sm'; ab.dataset.mgo = 'vendor'; vrow.appendChild(ab);
      var pb = el('button', 'Paste from 4OVER'); pb.type = 'button'; pb.className = 'pb-btn sm'; pb.dataset.mgo = 'paste4'; vrow.appendChild(pb); bx.appendChild(vrow); vb.appendChild(bx);
      VJOBS = {}; c.vendor.jobs.forEach(function (j) { VJOBS[j.id] = j; });
    }
    // Manage: what this case is about
    var mg = document.getElementById('pb-dr-mg'); mg.textContent = ''; document.getElementById('pb-dr-form').hidden = true;
    var mb = function (label, attr, val, cls) { var b = el('button', label); b.type = 'button'; b.className = 'pb-btn sm' + (cls ? ' ' + cls : ''); b.dataset[attr] = val; mg.appendChild(b); };
    if (it.order) {
      var od = it.order, money = '/admin/order.php?id=' + od.id;
      if (od.client) mb('Edit the order', 'toolUrl', '/admin/backoffice/orders/' + od.id); else mb('Open the order', 'toolUrl', money);
      if (od.client && (od.status === 'draft' || od.status === 'sent')) mb('Send to the client again', 'mgo', 'resend');
      if (od.client && od.status === 'pending' && !od.paid) mb('Record a payment', 'mgo', 'pay');
      if (od.client && !od.closed) mb('Change the due date', 'mgo', 'due');
      if (od.paid) mb('Refund or credit', 'toolUrl', money);
      mb('Add an order note', 'mgo', 'note');
      if (!od.paid && od.status !== 'void') mb('Void the order', 'mgo', 'void', 'no');
    } else if (it.key.indexOf('post:') === 0 && ME && it.author === ME) { mb('Edit the post', 'mgo', 'post_edit'); mb('Delete the post', 'mgo', 'post_delete', 'no'); }
    else if (it.url) mb('Open the tool', 'toolUrl', it.url);
    document.getElementById('pb-dr-mgw').hidden = !mg.children.length;
    if (!(c.history || []).length) h.appendChild(el('li', 'Nothing yet.'));
  }
  function showTool(on, url, auto) {
    var t = document.getElementById('pb-tool'), f = document.getElementById('pb-tool-f'), it = cur && D[cur];
    url = url || (it && it.url);
    if (on && url && /^https?:\/\//i.test(url)) { if (!auto) window.open(url, '_blank', 'noopener'); return; }   // another site (a source's terms): its own tab, never framed
    if (on && url && /^\/admin\/(backoffice\/orders\/|client-order\.php)/.test(url)) { if (auto) on = false; else { location.href = url; return; } }   // an order: its own whole page when asked for, never on its own as the case opens (it left the case: Jason, 2026-10-30)
    if (on && it && url) { document.getElementById('pb-tool-t').textContent = it.title; document.getElementById('pb-tool-full').href = url;
      var u = url, hsh = '', i = u.indexOf('#'); if (i >= 0) { hsh = u.slice(i); u = u.slice(0, i); } f.src = u + (u.indexOf('?') >= 0 ? '&' : '?') + 'embed=1' + hsh; t.hidden = false; document.querySelector('.pb-tool-sc').scrollTop = 0; /* the tool fills the panel and scrolls itself, so its pop-ups open where you're looking */ }
    else { t.hidden = true; f.src = 'about:blank'; }
    document.querySelector('.pb-shade').hidden = !t.hidden;
    var ob2 = document.getElementById('pb-dr-tool'); if (it) ob2.hidden = !it.url || !t.hidden;
  }
  // a step's answer from before the refresh (the steps above it are now up to date): the site's notice, in the middle
  try { var pbSaid = sessionStorage.getItem('pb_said'); if (pbSaid) { sessionStorage.removeItem('pb_said'); setTimeout(function () { TvAsk.say(pbSaid, { bad: false }); }, 400); } } catch (x) {}
  function open(k) {
    cur = k; mode = D[k].reply_to ? 'reply' : 'team'; rows.forEach(function (r) { r.classList.toggle('on', r.dataset.key === k); });
    document.getElementById('pb-dr-msg').textContent = ''; document.getElementById('pb-dr-body').value = '';
    fill({}); dr.hidden = false; document.documentElement.style.overflow = 'hidden';
    showTool(window.innerWidth >= 1100 && !!D[k].url, null, true);   // a wide screen opens the tool beside the case (not an order: that's its own page)
    api({ do: 'case', key: k }).then(function (j) { if (j.ok) fill(j); });
  }
  function close() { showTool(false); dr.hidden = true; cur = null; document.documentElement.style.overflow = ''; rows.forEach(function (r) { r.classList.remove('on'); }); }
  function act(d, extra) {
    var m = document.getElementById('pb-dr-msg'), it = D[cur], body = Object.assign({ do: d, key: cur }, extra || {});
    return api(body).then(function (j) {
      m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? '' : j.error.message; if (!j.ok) return;
      if (d === 'done' || d === 'undo') { it.state = d === 'done' ? 'done' : ''; var rr = row(cur); if (rr) { rr.dataset.state = d === 'done' ? 'done' : 'open'; rr.classList.toggle('done', d === 'done'); } }
      if (d === 'mine') { it.mine = true; it.who = 'you'; var r2 = row(cur); if (r2) r2.dataset.mine = '1'; }
      if (d === 'assign') { var s = document.getElementById('pb-dr-to'); it.who = s.options[s.selectedIndex].text; }
      if (d === 'escalate') it.esc = Math.min(2, (it.esc || 0) + 1);
      fill(j); apply();
    });
  }
  document.addEventListener('click', function (e) {
    var r = e.target.closest('.ps-row, .pq-row');
    if (r && (e.target.closest('[data-open]') || r.classList.contains('ps-row'))) { e.preventDefault(); open(r.dataset.key); return; }
    if (e.target.closest('[data-dr-close]')) { close(); return; }
    if (e.target.closest('[data-tool-open]')) { showTool(true); return; }
    var tu = e.target.closest('[data-tool-url]'); if (tu) { showTool(true, tu.dataset.toolUrl); return; }
    var dw = e.target.closest('[data-do-what]'); if (dw && cur) {   // a step's button: a spinner while it works, its answer beside it, then the case refreshed
      TvAsk.busy(dw, true);
      api({ do: 'manage', key: cur, what: dw.dataset.doWhat, args: {} }).then(function (j) {
        TvAsk.busy(dw, false);
        if (!j.ok) { TvAsk.say(j.error && j.error.message || 'That didn\u2019t work.', { bad: true }); return; }   // the site's notice, in the middle; it stays until closed
        try { sessionStorage.setItem('pb_said', j.message || 'Done.'); } catch (x) {}   // shown once the case is back with its steps up to date
        location.hash = 'case=' + encodeURIComponent(cur); location.reload();
      }).catch(function () { TvAsk.busy(dw, false); TvAsk.say('That didn\u2019t reach the site. Try again.', { bad: true }); });
      return;
    }
    var fs = e.target.closest('[data-form-step]'); if (fs && cur) { var st2 = D[cur].play[+fs.dataset.formStep], a2 = st2.act; form(st2.t, a2[3], a2[2], function (v) { manage(a2[1], v, true); }); return; }   // a step that does the work: its form, here
    var ex = e.target.closest('[data-ex]');
    if (ex && cur) {
      var box = document.getElementById('pb-dr-ex'), on = ex.getAttribute('aria-pressed') !== 'true', E = D[cur].explain || {};
      document.querySelectorAll('#pb-dr-chips [data-ex]').forEach(function (x) { x.setAttribute('aria-pressed', 'false'); });
      box.textContent = ''; box.hidden = !on;
      if (on) { ex.setAttribute('aria-pressed', 'true'); box.appendChild(document.createTextNode(E[ex.dataset.ex] || ''));
        if (ex.dataset.ex === 'source' && E.source_url) { box.appendChild(document.createTextNode(' ')); var a = el('a', 'See the whole queue →'); a.href = E.source_url; box.appendChild(a); }
        if (ex.dataset.ex === 'escalation' && D[cur].state !== 'done') { box.appendChild(document.createTextNode(' ')); var eb = el('button', 'Escalate now'); eb.type = 'button'; eb.className = 'pb-btn sm'; eb.dataset.dr = 'escalate'; box.appendChild(eb); } }
      return;
    }
    var wr = e.target.closest('[data-write]');
    if (wr && cur) { var st = D[cur].play[+wr.dataset.write]; mode = D[cur].reply_to && D[cur].key.indexOf('post:') !== 0 ? 'reply' : 'team';
      var ta = document.getElementById('pb-dr-body'); ta.value = (st.act && st.act[1]) || ''; refreshMode(); ta.focus(); ta.scrollIntoView({ block: 'center' }); return; }
    if (e.target.closest('[data-tool-close]')) { showTool(false); return; }
    var sg = e.target.closest('[data-stage]');
    if (sg && cur) {
      var go = function (tracking) {
        api({ do: 'stage', key: cur, stage: sg.dataset.stage, tracking: tracking || '' }).then(function (j) {
          var m = document.getElementById('pb-dr-msg'); m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? '' : j.error.message;
          if (j.ok) { location.hash = 'case=' + encodeURIComponent(cur); location.reload(); }
        });
      };
      if (sg.dataset.stage === 'ordered') { form('Sent to the printer', jobFields(), 'Send to the printer', function (v) {
        api({ do: 'stage', key: cur, stage: 'ordered', tracking: '', job: v }).then(function (j) { done(j, true); }); }); return; }
      // shipping asks for the tracking number right here, in the case (no pop-up over the drawer)
      if (sg.dataset.stage === 'shipped' && !sg.dataset.ready) {
        // the box goes under the step's words (its own row, full width), so the button keeps its place
        var li = sg.closest('li'), txt = (li && li.children[1]) || sg.parentNode, inp = el('input'); inp.className = 'pb-track'; inp.placeholder = 'Tracking number (optional)'; inp.value = D[cur].order.tracking || '';
        inp.setAttribute('aria-label', 'Tracking number'); txt.appendChild(inp); sg.dataset.ready = '1'; sg.textContent = 'Mark shipped'; inp.focus(); return;
      }
      if (sg.dataset.stage === 'complete' && window.TvAsk && !TvAsk.gate(sg, 'Mark this order complete? The client is emailed.', { yes: 'Mark complete' })) return;
      go(sg.dataset.ready ? (document.querySelector('.pb-track') || {}).value : '');
      return;
    }
    var sb = e.target.closest('#pb-dr-mode button'); if (sb) { mode = sb.dataset.mode; fill({ case_no: 0, team: [], history: [] }); api({ do: 'case', key: cur }).then(function (j) { if (j.ok) fill(j); }); return; }
    var b = e.target.closest('[data-dr]'); if (b && cur) act(b.dataset.dr);
  });
  // a small form inside the case (no pop-ups over the drawer): fields [name, label, type, value, list]
  function form(title, fields, yes, send, danger) {
    var f = document.getElementById('pb-dr-form'); f.textContent = ''; f.hidden = false;
    f.appendChild(el('b', title));
    var host = f;
    fields.forEach(function (x) {
      if (x[0] === '-') { var d = el('details'); d.appendChild(el('summary', x[1])); f.appendChild(d); host = d; return; }
      var l = el('label', x[1]), i;
      if (x[2] === 'select') { i = el('select'); (Array.isArray(x[4]) ? x[4] : Object.keys(x[4]).map(function (k) { return [k, x[4][k]]; })).forEach(function (kv) { var o = el('option', kv[1]); o.value = kv[0]; i.appendChild(o); }); }
      else if (x[2] === 'textarea') { i = el('textarea'); i.rows = 3; }
      else { i = el('input'); i.type = x[2] || 'text'; if (x[4]) i.setAttribute('list', x[4]); }
      i.name = x[0]; if (x[3] != null) i.value = x[3]; l.appendChild(i); host.appendChild(l);
    });
    var r = el('div'); r.className = 'row'; var no = el('button', 'Close'); no.type = 'button'; no.className = 'pb-btn sm';
    var ok = el('button', yes); ok.type = 'button'; ok.className = 'pb-btn ' + (danger ? 'sm no' : 'go'); r.appendChild(no); r.appendChild(ok); f.appendChild(r);
    no.onclick = function () { f.hidden = true; };
    ok.onclick = function () { var v = {}; f.querySelectorAll('[name]').forEach(function (i) { v[i.name] = i.value; }); send(v); };
    var vs = f.querySelector('[name=vendor_order_id]');
    if (vs) { var sync = function () { ['vendor', 'vendor_order_no'].forEach(function (n) { var x = f.querySelector('[name=' + n + ']'); if (x) x.closest('label').hidden = vs.value !== ''; }); }; vs.addEventListener('change', sync); sync(); }
    var first = f.querySelector('input,textarea,select'); if (first) first.focus(); f.scrollIntoView({ block: 'nearest' });
  }
  function done(j, reload) {
    var m = document.getElementById('pb-dr-msg'); m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? (j.message || '') : j.error.message;
    if (!j.ok) return;
    if (reload) { try { sessionStorage.setItem('pb_said', j.message || 'Done.'); } catch (x) {} location.hash = 'case=' + encodeURIComponent(cur); location.reload(); return; }   // its answer as the site's notice once the case is back (site audit P11)
    document.getElementById('pb-dr-form').hidden = true; if (j.history) fill(j);
  }
  function manage(what, args, reload) { return api({ do: 'manage', key: cur, what: what, args: args || {} }).then(function (j) { done(j, reload); }); }
  var VORD = [], VJOBS = {}, VITEMS = [];
  // which item a job is for: the whole order (it moves every item without its own job), or one item (decisions/0107)
  function forField(v) { return ['line_id', 'For', 'select', v ? String(v) : '', [['', 'The whole order (every item without its own job)']].concat(VITEMS.map(function (i) { return [String(i.id), i.title]; }))]; }
  function itemName(id) { var i = VITEMS.filter(function (x) { return x.id === +id; })[0]; return i ? i.title : ''; }
  function jobFields() {
    var it = D[cur], po = it && it.order ? (it.title.split(' · ')[1] || '') : '';
    var pick = VORD.map(function (o) { return [String(o.id), 'Add to ' + o.label]; }).concat([['', 'A new vendor order']]);   // the latest order first: one 4OVER order holds several jobs
    return [['vendor_order_id', 'Vendor order', 'select', VORD.length ? String(VORD[0].id) : '', pick], forField(VITEMS.length === 1 ? VITEMS[0].id : ''), ['vendor', 'Vendor', 'text', '4OVER', 'pb-vlist'], ['vendor_order_no', 'Their order #', 'text', ''],
      ['po_name', 'Project / P.O. name', 'text', po], ['set_name', 'Set name', 'text', ''], ['job_no', 'Job ID', 'text', ''], ['job_status', 'Job status (theirs)', 'text', ''],
      ['subtotal', 'Our cost: subtotal ($)', 'text', ''], ['shipping', 'Shipping & processing ($)', 'text', ''], ['tax', 'Tax ($)', 'text', ''],
      ['-', 'More details: specs, shipment, artwork'], ['sku', 'SKU', 'text', ''], ['specs', 'Specs (size, stock, coating, colors)', 'textarea', ''], ['run_size', 'Run size', 'text', ''], ['turnaround', 'Turnaround', 'text', ''],
      ['facility', 'Production facility', 'text', ''], ['completion_on', 'Completion date', 'date', ''], ['ship_to', 'Ships to', 'text', ''], ['ship_method', 'Shipping method', 'text', ''], ['artwork_url', 'Artwork link', 'text', ''], ['note', 'Note (our team only)', 'textarea', '']];
  }
  document.getElementById('pb-dr').addEventListener('click', function (e) {
    var g = e.target.closest('[data-mgo]'); if (g && cur) {
      var it = D[cur], od = it.order || {}, w = g.dataset.mgo;
      if (w === 'resend') { if (!TvAsk.gate(g, 'Email the order to the client again?', { yes: 'Send it' })) return; manage('resend', {}, true); }
      if (w === 'pay') form('Record a payment', [['amount', 'Amount received ($)', 'text', ''], ['method', 'How', 'select', null, { cash: 'Cash', check: 'Check', zelle: 'Zelle', venmo: 'Venmo', bank: 'Bank transfer', card: 'Card (another terminal)', other: 'Other' }], ['ref', 'Reference (check #, etc.)', 'text', '']], 'Record it', function (v) { manage('pay', v, true); });
      if (w === 'due') form('Change the due date', [['date', 'New due date', 'date', od.due || '']], 'Save', function (v) { manage('due', v, true); });
      if (w === 'note') form('Add an order note', [['text', 'Note (on the order\'s history; our team only)', 'textarea', '']], 'Add it', function (v) { manage('note', v); });
      if (w === 'void') form('Void the order', [['why', 'Why (the client is told if it was sent)', 'text', '']], 'Void it', function (v) { manage('void', v, true); }, true);
      if (w === 'post_edit') form('Edit the post', [['text', 'Post', 'textarea', it.body || '']], 'Save', function (v) { manage('post_edit', v, true); });
      if (w === 'post_delete') { if (!TvAsk.gate(g, 'Delete this post?', { yes: 'Delete', danger: true })) return; api({ do: 'manage', key: cur, what: 'post_delete' }).then(function (j) { if (j.ok) { location.hash = ''; location.reload(); } else done(j); }); }
      if (w === 'paste4') form('Paste from 4OVER', [['text', 'On the 4OVER order page press Ctrl+A, then Ctrl+C, and paste here (Ctrl+V)', 'textarea', '']], 'Read it', function (v) {
        api({ do: 'parse4', text: v.text }).then(function (j) {
          if (!j.ok) { done(j); return; }
          var P = j.parsed, oid = D[cur].order ? D[cur].order.id : 0, f = document.getElementById('pb-dr-form'); f.textContent = '';
          f.appendChild(el('b', '4OVER #' + P.vendor_order_no + ' · ' + (P.purchased || '') + ' · ' + (P.payment || '') + (P.total != null ? ' · $' + P.total.toFixed(2) : '')));
          P.projects.forEach(function (pr, n) {
            var m = j.matches[n], l = el('label', pr.po_name + ' → ' + pr.sets.map(function (x) { return [x.job_no, x.job_status, x.tracking].filter(Boolean).join(' · '); }).join('; ') + (pr.total != null ? ' · $' + pr.total.toFixed(2) : '') + ' · ships to ' + pr.ship_name);
            var sel = el('select'); sel.name = 'p' + n;
            var o0 = el('option', m.known ? 'Already saved: update it' : 'Not this order (skip)'); o0.value = m.known ? m.order_id : 0; sel.appendChild(o0);
            if (!m.known) j.orders.forEach(function (o) { var op = el('option', 'For ' + o.label); op.value = o.id; if (o.id === (m.order_id || 0)) op.selected = true; sel.appendChild(op); });
            l.appendChild(sel); f.appendChild(l);
          });
          var r = el('div'); r.className = 'row'; var no = el('button', 'Close'); no.type = 'button'; no.className = 'pb-btn sm'; no.onclick = function () { f.hidden = true; };
          var ok = el('button', 'Save from 4OVER'); ok.type = 'button'; ok.className = 'pb-btn go'; r.appendChild(no); r.appendChild(ok); f.appendChild(r);
          ok.onclick = function () { var of = {}; P.projects.forEach(function (_, n) { of[n] = +f.querySelector('[name=p' + n + ']').value; });
            api({ do: 'import4', key: cur, text: v.text, order_for: of }).then(function (k) { done(k, true); }); };
        });
      });
      if (w === 'vendor') form('Add a vendor job', jobFields(), 'Save', function (v) { api({ do: 'vendor', key: cur, job: v }).then(function (j) { done(j); }); });
      return;
    }
    var vj = e.target.closest('[data-vjob]');
    if (vj && VJOBS[vj.dataset.vjob]) { var J = VJOBS[vj.dataset.vjob], c2 = function (x) { return x === null || x === undefined ? '' : (x / 100).toFixed(2); };
      form('Update ' + (J.job_no ? 'job ' + J.job_no : 'the job'), [forField(J.line_id), ['job_status', 'Job status (theirs)', 'text', J.job_status], ['tracking', 'Tracking', 'text', J.tracking], ['completion_on', 'Completion date', 'date', J.completion_on || ''],
        ['job_no', 'Job ID', 'text', J.job_no], ['subtotal', 'Subtotal ($)', 'text', c2(J.subtotal_cents)], ['shipping', 'Shipping & processing ($)', 'text', c2(J.shipping_cents)], ['tax', 'Tax ($)', 'text', c2(J.tax_cents)]],
        'Save', function (v) { api({ do: 'vjob', key: cur, id: +vj.dataset.vjob, job: v }).then(function (j) { done(j, true); }); }); return; }
    var ne = e.target.closest('[data-note-edit]'); if (ne) { form('Edit your note', [['text', 'Note', 'textarea', ne.dataset.text]], 'Save', function (v) { manage('note_edit', { id: +ne.dataset.noteEdit, text: v.text }); }); return; }
    var nd = e.target.closest('[data-note-del]'); if (nd) { if (!TvAsk.gate(nd, 'Delete your note?', { yes: 'Delete', danger: true })) return; manage('note_delete', { id: +nd.dataset.noteDel }); }
  });
  function refreshMode() { document.querySelectorAll('#pb-dr-mode button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.mode === mode ? 'true' : 'false'); }); }
  document.getElementById('pb-dr-play').addEventListener('change', function (e) {
    var cb = e.target.closest('[data-step]'); if (!cb || !cur) return;
    var n = +cb.dataset.step; api({ do: 'step', key: cur, n: n, on: cb.checked, label: D[cur].play[n].t }).then(function (j) { if (j.ok) fill(j); });
  });
  document.getElementById('pb-dr-to').addEventListener('change', function () { if (this.value) act('assign', { to: +this.value }); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !dr.hidden) { if (!document.getElementById('pb-tool').hidden && window.innerWidth < 768) showTool(false); else close(); }
    if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('ps-row')) { e.preventDefault(); open(e.target.dataset.key); }
  });
  document.querySelector('[data-dr-post]').addEventListener('click', function () {
    var t = document.getElementById('pb-dr-body'), m = document.getElementById('pb-dr-msg');
    api({ do: 'post', key: cur, mode: mode, body: t.value }).then(function (j) {
      m.className = 'pb-msg' + (j.ok ? '' : ' no'); m.textContent = j.ok ? j.message : j.error.message; if (j.ok) { t.value = ''; fill(j); }
    });
  });
  // the SLA clocks tick
  setInterval(function () {
    document.querySelectorAll('[data-due]').forEach(function (s) { var d = s.dataset.due; if (!d) return; var left = (new Date(d.replace(' ', 'T')) - new Date()) / 1000;
      var a = Math.abs(left), h = Math.floor(a / 3600), mi = Math.floor(a % 3600 / 60), f = h >= 48 ? Math.round(h / 24) + ' d' : (h ? h + ' h' + (mi ? ' ' + mi + ' min' : '') : Math.max(1, mi) + ' min');
      s.textContent = s.textContent.replace(/SLA .*?(?= ·|$)/, 'SLA ' + (left >= 0 ? f + ' left' : 'Over by ' + f)); s.classList.toggle('over', left < 0); });
  }, 60000);
  document.querySelectorAll('.pb-panel[data-keep]').forEach(function (d) {
    var k = 'tv-pulse-' + d.dataset.keep; try { var st = localStorage.getItem(k); if (st === 'closed') d.open = false; if (st === 'open') d.open = true; } catch (x) {}
    d.addEventListener('toggle', function () { try { localStorage.setItem(k, d.open ? 'open' : 'closed'); } catch (x) {} });
  });
  apply();
  // reopen a case after moving its order on; or open one from the daily report, at its step
  var hc = /case=([^&]+)/.exec(location.hash), hs = /[#&]step=(\d+)/.exec(location.hash);
  if (hc && D[decodeURIComponent(hc[1])]) { if (hs) goTo = { k: decodeURIComponent(hc[1]), n: +hs[1], shown: false }; open(decodeURIComponent(hc[1])); }
  else if (hc && hs && window.TvAsk) TvAsk.say('That case is already resolved, or nothing on it needs you now.', { bad: false });
  if (root.dataset.focus === 'stream') setTimeout(function () { document.getElementById('pu-stream').scrollIntoView(); }, 50);
})();
</script>
<?php
    return (string) ob_get_clean();
}

/** Stream settings (decisions/0105): which department each kind of item goes to, and each severity's clock. */
function tv_pulse_settings(PDO $pdo, ?array $staff): string
{
    $e = 'tv_e';
    $ready = Pulse::settingsReady($pdo); $can = $ready && Pulse::canSet($staff);
    $dis = $can ? '' : ' disabled';
    $csrf = (string) ($_SESSION['csrf_token'] ?? '');
    ob_start(); ?>
<style>
  .pst{max-width:44rem;margin-top:.6rem}.pst h2{margin:0}.pst table{width:100%;border-collapse:collapse;margin:.4rem 0 .2rem}
  .pst td{padding:.4rem .3rem;border-top:1px solid #EADFC4;vertical-align:middle}.pst td:first-child{display:flex;align-items:center;gap:.45rem;font-weight:600;color:#3E2B1F}
  .pst .pu-svg{width:18px;height:18px;fill:none;stroke:#B45309;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}
  .pst select,.pst input{font:inherit;border:1px solid #CBB98D;border-radius:.45rem;background:#FFFBF2;color:#3E2B1F;padding:.3rem .45rem;max-width:100%}
  .pst input{width:5.5rem}.pst small{color:#8A7355}.pst .row{display:flex;gap:.6rem;align-items:center;flex-wrap:wrap;margin-top:.6rem}
  .pst-msg{font-weight:600;color:#1F3B30}.pst-msg.no{color:#991B1B}
  .pst.hb-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .85rem}
  .pst .hb-h{font:700 1.1rem Georgia,serif;color:#3E2B1F;margin:1.1rem 0 0}.pst .hb-intro{font-size:.95rem;color:#5C4632;margin:.3rem 0 .2rem}
  .pst .hb-b{display:inline-flex;align-items:center;justify-content:center;font:700 .9rem/1.2 inherit;border-radius:.6rem;padding:.42rem .8rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;cursor:pointer;white-space:nowrap}
  .pst .hb-b.go{background:#3E2B1F;border-color:#3E2B1F;color:#FFF8EA}.pst .hb-b:disabled{opacity:.55;cursor:default}
  .pst table.pst-rep{table-layout:fixed}.pst table.pst-rep td:first-child{width:7.2rem}.pst table.pst-rep select{width:100%;min-width:0}
</style>
<div class="hb-card tv-bleed pst" id="pst">
  <h2 class="hb-h">Routing</h2>
  <p class="hb-intro">Which department's queue each kind of item goes to. Everyone: it shows in the whole team's stream. A department's Manager and Director are the ones an item escalates to.</p>
  <?php if (!$ready): ?><p class="hb-intro"><b>Run <code>app/migrations/2026-12-19_pulse_settings.sql</code></b> to change these. Until then the defaults below apply.</p><?php elseif (!$can): ?><p class="hb-intro">A Director, an Executive or the Founder changes these.</p><?php endif; ?>
  <table><?php foreach (Pulse::SOURCES as $src => [$label, $icon]): $d = Pulse::deptFor($pdo, $src); ?>
    <tr><td><?= tv_icon($icon, 'pu-svg') ?><?= $e($label) ?></td><td><select data-route="<?= $e($src) ?>" aria-label="<?= $e($label) ?> goes to"<?= $dis ?>><option value=""<?= $d === '' ? ' selected' : '' ?>>Everyone</option><?php foreach (Workspaces::DEPARTMENTS as $k => [$dl]): ?><option value="<?= $k ?>"<?= $d === $k ? ' selected' : '' ?>><?= $e($dl) ?></option><?php endforeach; ?></select>
      <?php if ($d !== (string) Pulse::SOURCES[$src][3]): ?><small>default: <?= $e(Pulse::SOURCES[$src][3] === '' ? 'Everyone' : Workspaces::DEPARTMENTS[Pulse::SOURCES[$src][3]][0]) ?></small><?php endif; ?></td></tr>
  <?php endforeach; ?></table>
  <h2 class="hb-h" style="margin-top:1rem">Clocks (SLA)</h2>
  <p class="hb-intro">How long an open item may wait before it shows as over, in hours. 0 = no clock. An item still open after its clock can be escalated to the department's Manager, then its Director.</p>
  <table><?php foreach (Pulse::SLA_HOURS as $sev => $def): $hrs = Pulse::slaHours($pdo, $sev); ?>
    <tr><td><?= $e(Pulse::SEVERITY[$sev]) ?></td><td><input type="number" min="0" max="720" step="1" inputmode="numeric" data-sla="<?= $sev ?>" value="<?= $hrs ?>" aria-label="<?= $e(Pulse::SEVERITY[$sev]) ?> clock, hours"<?= $dis ?>> hours <small>(<?= $e(Pulse::clockLabel($hrs)) ?><?= $hrs !== $def ? '; default ' . $e(Pulse::clockLabel($def)) : '' ?>)</small></td></tr>
  <?php endforeach; ?></table>
  <?php require_once __DIR__ . '/../lib/DailyReport.php'; $rto = DailyReport::recipient($pdo); $rhr = DailyReport::hour($pdo); $rday = DailyReport::today($pdo); ?>
  <h2 class="hb-h" style="margin-top:1rem">Daily report</h2>
  <p class="hb-intro">One email a day with every open case, a button to each one's step, and the system status. It goes to one Owner. A day with nothing open still sends one line, so no email means it stopped (and Pulse raises a case).</p>
  <table class="pst-rep">
    <tr><td><?= tv_icon('inbox', 'pu-svg') ?>Goes to</td><td><select data-report="to" aria-label="The daily report goes to"<?= $dis ?>><?php foreach (DailyReport::owners($pdo) as $oid => [$oem, $onm]): ?><option value="<?= (int) $oid ?>"<?= $rto && $rto[0] === $oid ? ' selected' : '' ?>><?= $e(($onm !== '' ? $onm . ' · ' : '') . $oem) ?></option><?php endforeach; ?></select></td></tr>
    <tr><td><?= tv_icon('calendar', 'pu-svg') ?>Sent at</td><td><select data-report="hour" aria-label="The hour it goes, Arizona time"<?= $dis ?>><?php for ($h = 3; $h <= 11; $h++): ?><option value="<?= $h ?>"<?= $h === $rhr ? ' selected' : '' ?>><?= $e(DailyReport::hourLabel($h)) ?></option><?php endfor; ?></select> <small>Arizona time<?= $rhr !== DailyReport::HOUR ? '; default ' . DailyReport::hourLabel(DailyReport::HOUR) : '' ?></small></td></tr>
    <tr><td>Today's</td><td style="overflow-wrap:anywhere"><small><?= $rday ? ((int) $rday['ok'] ? 'Sent at ' . $e(date('g:i a', strtotime((string) $rday['sent_at']))) . ' Arizona time to ' . $e($rday['to_email']) : 'Didn\'t send: ' . $e($rday['error'])) : 'Not sent yet today' ?></small></td></tr>
  </table>
  <div class="row"><button type="button" class="hb-b" id="pst-rprev">Preview today's report</button><?php if ($can): ?><button type="button" class="hb-b" id="pst-rsend">Send me a copy now</button><?php endif; ?><span class="pst-msg" id="pst-rmsg" role="status"></span></div>
  <iframe id="pst-rframe" title="Today's report" hidden style="width:100%;height:34rem;border:1px solid #E8DCC2;border-radius:.5rem;margin-top:.5rem;background:#F6EFDF"></iframe>
  <?php if ($can): ?><div class="row"><button type="button" class="hb-b go" id="pst-save">Save</button><button type="button" class="hb-b" id="pst-def">Use the defaults</button><span class="pst-msg" id="pst-msg" role="status"></span></div><?php endif; ?>
</div>
<?php if ($can): ?>
<script>
(function () {
  var box = document.getElementById('pst'), msg = document.getElementById('pst-msg');
  var DEF = <?= json_encode(['route' => array_map(fn ($x) => (string) $x[3], Pulse::SOURCES), 'sla' => Pulse::SLA_HOURS]) ?>;
  function send(body) {
    msg.className = 'pst-msg'; msg.textContent = 'Saving…';
    fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode($csrf) ?> }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); }).then(function (j) {
        if (!j.ok) { msg.className = 'pst-msg no'; msg.textContent = j.error.message; return; }
        msg.textContent = j.message; if (j.message !== 'Nothing changed.') setTimeout(function () { location.reload(); }, 900);
      }).catch(function () { msg.className = 'pst-msg no'; msg.textContent = 'That didn\'t save. Try again.'; });
  }
  function collect() { var v = { do: 'settings', route: {}, sla: {} };
    box.querySelectorAll('[data-route]').forEach(function (s) { v.route[s.dataset.route] = s.value; });
    box.querySelectorAll('[data-sla]').forEach(function (i) { v.sla[i.dataset.sla] = i.value; });
    var rt = box.querySelector('[data-report=to]'), rh = box.querySelector('[data-report=hour]'); if (rt && rt.value) v.report_to = rt.value; if (rh) v.report_hour = rh.value; return v; }
  var rs = document.getElementById('pst-rsend');
  if (rs) rs.addEventListener('click', function () {
    var b = this; if (!TvAsk.gate(b, 'Email a copy of today\'s report now? The 5 am one still goes.', { yes: 'Send it' })) return;
    b.disabled = true;
    fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode($csrf) ?> }, body: JSON.stringify({ do: 'report_copy' }) })
      .then(function (r) { return r.json(); }).then(function (j) { b.disabled = false; TvAsk.say(j.ok ? j.message : j.error.message, { anchor: b, bad: !j.ok }); })
      .catch(function () { b.disabled = false; TvAsk.say('That didn\'t reach the site. Try again.', { anchor: b, bad: true }); });
  });
  document.getElementById('pst-save').addEventListener('click', function () { send(collect()); });
  document.getElementById('pst-def').addEventListener('click', function () {
    if (!TvAsk.gate(this, 'Put routing and clocks back to the defaults?', { yes: 'Use the defaults' })) return;
    send({ do: 'settings', route: DEF.route, sla: DEF.sla }); });
})();
</script>
<?php endif; ?>
<script>
(function () {
  var pb = document.getElementById('pst-rprev'), fr = document.getElementById('pst-rframe'); if (!pb) return;
  pb.addEventListener('click', function () {
    if (!fr.hidden) { fr.hidden = true; pb.textContent = 'Preview today\'s report'; return; }
    pb.disabled = true;
    fetch('/admin/api/pulse.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode($csrf) ?> }, body: JSON.stringify({ do: 'report_preview' }) })
      .then(function (r) { return r.json(); }).then(function (j) {
        pb.disabled = false;
        if (!j.ok) { TvAsk.say(j.error.message, { anchor: pb, bad: true }); return; }
        fr.srcdoc = j.html; fr.hidden = false; pb.textContent = 'Close the preview';
      }).catch(function () { pb.disabled = false; TvAsk.say('That didn\'t reach the site. Try again.', { anchor: pb, bad: true }); });
  });
})();
</script>
<?php
    return (string) ob_get_clean();
}
