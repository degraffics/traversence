<?php
// /api/domains.php — Shop → Domains and the account's Domains tab (decisions/0169 §1a), and the account's wallet
// (decisions/0166 §6a). POST JSON with the page's form token (X-CSRF-Token); signed in. {type: 'user'|'listing', id}
// names the account (a member's own, or a business they're on the team of).
//   {action: 'status', type, id}            -> {open, why, test, accounts, domains, storefront, cards, pay, can}
//   {action: 'search', q, type, id}         -> {results: [{domain, ok, premium, price, label}]}
//   {action: 'cart_add', type, id, domain, price, who: {first,last,email,phone,address1,city,state,zip}, adult}
//   {action: 'cart_card', type, id, pick}   which wallet card pays the account's domains in the cart ('wallet:<id>' | 'new')
//   {action: 'renew_now', domain, pick} · {action: 'renew_cart', domain} · {action: 'auto_renew', domain, on, pick}
//   {action: 'forward', domain, to} · {action: 'records', domain} · {action: 'record_save', domain, rec} ·
//   {action: 'record_delete', domain, rid} · {action: 'nameservers', domain, list} · {action: 'email_add', domain}
//   {action: 'transfer', domain} -> {code} (shown once) · {action: 'history', domain} · {action: 'ticket', domain, words}
//   {action: 'own_add', type, id, domain} · {action: 'own_remove', domain}
//   {action: 'wallet_add', type, id, token, default} · {action: 'wallet_default', type, id, card} ·
//   {action: 'wallet_remove', type, id, card} · {action: 'wallet_replace', type, id, card, pick, only: 'domain:<id>'|'plan:<id>'|''}
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/AccountDomains.php';
require_once __DIR__ . '/../../app/lib/QuickBooksPay.php';

Response::requireMethod('POST');
Response::requireCsrf();
$me = Auth::currentUser();
if (!$me) Response::error('Sign in first: domains belong to an account.', 401, 'unauthenticated');
$uid = (int) $me['id'];
$pdo = Database::connection();
if (!AccountDomains::ready($pdo)) Response::error('Domains open once their database update has run (within the hour).', 503, 'not_ready');
$b = Response::jsonBody();
$act = (string) ($b['action'] ?? '');
$type = ($b['type'] ?? 'user') === 'listing' ? 'listing' : 'user';
$id = $type === 'user' ? $uid : (int) ($b['id'] ?? 0);
$dom = (int) ($b['domain'] ?? 0);
$day = fn ($t) => $t ? date('M j, Y', strtotime((string) $t)) : '';

/** The accounts this person can buy domains for: themself, and each business where they have Domain and Plan & billing. */
$accounts = function () use ($pdo, $uid, $me): array {
    $out = [['type' => 'user', 'id' => $uid, 'name' => 'You (' . (trim((string) ($me['display_name'] ?? '')) ?: (string) $me['email']) . ')']];
    try {
        require_once __DIR__ . '/../../app/lib/Team.php';
        foreach (Team::listingsOf($pdo, $uid) as $lid => $l) if (AccountDomains::canPay($pdo, $uid, 'listing', (int) $lid)) $out[] = ['type' => 'listing', 'id' => (int) $lid, 'name' => (string) $l['name']];
    } catch (Throwable $x) { error_log('domains accounts: ' . $x->getMessage()); }
    return $out;
};

$status = function () use ($pdo, $uid, $type, $id, $accounts, $day): array {
    if (!AccountDomains::canManage($pdo, $uid, $type, $id)) throw new InvalidArgumentException('You can\'t see this account\'s domains. The owner can give you Domain (view) on the team.');
    [$open, $why] = AccountDomains::open($pdo, $uid);
    $sf = null;
    if ($type === 'listing' && Domains::ready($pdo) && ($x = Domains::forEntity($pdo, $id))) $sf = ['domain' => $x['domain'], 'status' => Domains::STATUSES[$x['status']] ?? $x['status'], 'source' => Domains::SOURCES[$x['source']] ?? '', 'expires' => $day($x['expires_at']), 'url' => '/business/' . $id . '/storefront#domain'];
    $cards = array_map(fn ($c) => Wallet::shape($c) + ['usable' => Wallet::usable($pdo, $c)], Wallet::cards($pdo, $type, $id));
    return ['open' => $open, 'why' => $why, 'test' => Domains::testing() || AccountDomains::sandboxed($pdo, $type, $id), 'accounts' => $accounts(), 'name' => AccountDomains::ownerName($pdo, $type, $id),
        'domains' => array_map(fn ($d) => AccountDomains::shape($pdo, $d), AccountDomains::forOwner($pdo, $type, $id)), 'storefront' => $sf, 'cards' => $cards,
        'pay' => ['token_url' => QuickBooksPay::tokenUrl(), 'test' => QuickBooksPay::env() !== 'production', 'mock' => QuickBooksPay::env() === 'mock'],
        'can' => ['pay' => AccountDomains::canPay($pdo, $uid, $type, $id), 'wallet' => Wallet::canManage($pdo, $uid, $type, $id)], 'types' => AccountDomains::RECORD_TYPES, 'me' => ['email' => (string) ($GLOBALS['me']['email'] ?? '')]];
};

try {
    switch ($act) {
        case 'status':
            Response::success($status());
        case 'search':
            [$ok, $why] = AccountDomains::open($pdo, $uid); if (!$ok) throw new InvalidArgumentException($why);
            Response::success(['results' => array_map(fn ($r) => $r + ['label' => AccountDomains::usd((int) $r['price']) . ' a year', 'renew_label' => AccountDomains::usd((int) $r['renew']) . ' a year after'],
                AccountDomains::search($pdo, (string) ($b['q'] ?? ''), $type, $id))]);
        case 'cart_add':
            AccountDomains::addToCart($pdo, $uid, $type, $id, (string) ($b['domain'] ?? ''), (int) ($b['price'] ?? 0), (array) ($b['who'] ?? []), !empty($b['adult']));
            Response::success(['message' => 'In your cart.']);
        case 'cart_card':
            AccountDomains::setCartCard($pdo, $uid, $type, $id, (string) ($b['pick'] ?? 'new'));
            Response::success(['message' => 'Saved.']);
        case 'renew_now':
            $oid = AccountDomains::renewNow($pdo, $uid, $dom, (string) ($b['pick'] ?? ''));
            $d = AccountDomains::get($pdo, $dom);
            Response::success(['message' => $d && $d['attention'] === '' ? 'Renewed: ' . $d['domain'] . ' is paid up to ' . $day($d['expires_at']) . '.' : 'Paid. Name.com didn\'t renew it yet: our team is on it and will write to you.', 'order' => $oid]);
        case 'renew_cart':
            AccountDomains::renewToCart($pdo, $uid, $dom);
            Response::success(['message' => 'Its renewal is in your cart.']);
        case 'auto_renew':
            Response::success(['message' => AccountDomains::setAutoRenew($pdo, $uid, $dom, !empty($b['on']), (string) ($b['pick'] ?? ''))]);
        case 'forward':
            Response::success(['message' => AccountDomains::forward($pdo, $uid, $dom, (string) ($b['to'] ?? ''))]);
        case 'records':
            Response::success(['records' => AccountDomains::records($pdo, $uid, $dom)]);
        case 'record_save':
            Response::success(['message' => AccountDomains::saveRecord($pdo, $uid, $dom, (array) ($b['rec'] ?? []))]);
        case 'record_delete':
            Response::success(['message' => AccountDomains::deleteRecord($pdo, $uid, $dom, (int) ($b['rid'] ?? 0))]);
        case 'nameservers':
            Response::success(['message' => AccountDomains::setNameservers($pdo, $uid, $dom, (array) ($b['list'] ?? []))]);
        case 'email_add':
            Response::success(['message' => AccountDomains::addEmailRecords($pdo, $uid, $dom)]);
        case 'transfer':
            Response::success(['message' => 'Unlocked. Give this code to the new registrar. It isn\'t kept here: copy it now.', 'code' => AccountDomains::transferCode($pdo, $uid, $dom)]);
        case 'history':
            AccountDomains::mine($pdo, $uid, $dom);
            Response::success(['history' => array_map(fn ($h) => ['kind' => $h['kind'], 'note' => $h['note'], 'at' => date('c', strtotime((string) $h['created_at'])), 'order' => $h['order_id'] ? (int) $h['order_id'] : null], AccountDomains::history($pdo, $dom))]);
        case 'ticket':
            $no = AccountDomains::ticket($pdo, $uid, $dom, (string) ($b['words'] ?? ''));
            Response::success(['message' => 'Sent to our team' . ($no ? ': ticket #' . $no : '') . '. We\'ll write to you by email.']);
        case 'own_add':
            $d = AccountDomains::addOwn($pdo, $uid, $type, $id, (string) ($b['domain'] ?? ''));
            Response::success(['message' => 'Listed: ' . $d['domain'] . '. Its records stay where it\'s registered.']);
        case 'own_remove':
            AccountDomains::removeOwn($pdo, $uid, $dom);
            Response::success(['message' => 'Taken off your list.']);
        case 'wallet_add':
            if (!Wallet::canManage($pdo, $uid, $type, $id)) throw new InvalidArgumentException('Only the owner, or someone they let handle billing, can add cards here.');
            $c = AccountDomains::sandboxed($pdo, $type, $id) ? Wallet::asSandbox(true, fn () => Wallet::add($pdo, $uid, $type, $id, (string) ($b['token'] ?? ''), !empty($b['default']))) : Wallet::add($pdo, $uid, $type, $id, (string) ($b['token'] ?? ''), !empty($b['default']));
            Response::success(['message' => $c['label'] . ' is in the wallet.']);
        case 'wallet_default':
            if (!Wallet::canManage($pdo, $uid, $type, $id)) throw new InvalidArgumentException('Only the owner, or someone they let handle billing, can change these cards.');
            Wallet::setDefault($pdo, $type, $id, (int) ($b['card'] ?? 0));
            Response::success(['message' => 'It\'s offered first now.']);
        case 'wallet_remove':
            if (!Wallet::canManage($pdo, $uid, $type, $id)) throw new InvalidArgumentException('Only the owner, or someone they let handle billing, can remove cards.');
            Wallet::remove($pdo, $type, $id, (int) ($b['card'] ?? 0));
            Response::success(['message' => 'Removed from the wallet.']);
        case 'wallet_replace':
            $only = preg_match('/^(domain|plan):(\d+)$/', (string) ($b['only'] ?? ''), $m) ? [$m[1], (int) $m[2]] : null;
            $run = fn () => Wallet::replace($pdo, $uid, $type, $id, (int) ($b['card'] ?? 0), (string) ($b['pick'] ?? ''), $only);
            [$new, $moved] = AccountDomains::sandboxed($pdo, $type, $id) ? Wallet::asSandbox(true, $run) : $run();
            Response::success(['message' => $moved ? implode(', ', $moved) . ' now ' . (count($moved) === 1 ? 'renews' : 'renew') . ' on ' . $new['label'] . '.' : 'Nothing needed moving.']);
    }
    Response::error('Unknown action.', 400, 'bad_action');
} catch (InvalidArgumentException $x) {
    Response::error($x->getMessage(), 422, 'not_allowed');
} catch (RuntimeException $x) {
    Response::error($x->getMessage(), $x->getCode() === 402 ? 402 : 422, 'not_done');
}
