<?php
// /user/domains/ — your Domains (decisions/0169 §1a): every domain you hold, its expiry, Renew now, auto-renew, where
// it points, DNS records, email records, transfer away, history and Something isn't right; domains you own elsewhere
// listed for pointing only; and your wallet (decisions/0166 §6a). Also in the Dashboard (#domains, embedded). Buying is
// in Shop → Domains (/shop/domains.php).
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');   // bootstrap defaults to JSON
require_once __DIR__ . '/../../../app/ui/page-shell.php';
require_once __DIR__ . '/../../../app/ui/go-codes.php';
require_once __DIR__ . '/../../../app/ui/domains-view.php';

$uid = Auth::currentUserId();
if ($uid === null) { header('Location: /login.php?next=' . rawurlencode('/user/domains/'), true, 302); exit; }
tv_page_start('Your domains', ['no_crumbs' => true, 'description' => 'Your domains: renew, auto-renew, where each points, DNS and email records, and your wallet.']);
tv_go_head('', false);
?>
<div class="go">
  <?php if (!tv_embedded()): ?><h1>Your domains</h1><?php endif; ?>
  <p class="go-lead">Domains you bought through Traversence, and ones you own elsewhere. Each is yours: renew it, point it where you like, or move it to another registrar.</p>
  <?= tv_domains_view('user', (int) $uid, 'tab') ?>
</div>
<?php tv_page_end();
