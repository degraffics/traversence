<?php
// /shop/domains.php — Shop → Domains (decisions/0169 §1a): search a name (the typed name and .com, .net, .shop,
// .store, .co, .us, .biz) with our price a year (Name.com's cost plus our markup; premium names referred to us), add it
// to the one cart with its registrant (18 or older, real contact details), pay first, then it's registered through
// Name.com in the buyer's name with WHOIS privacy. Any account: a member, or a business they buy for (Domain and Plan &
// billing on its team). ?for=listing:<id> chooses the account. A standalone product: no storefront or plan needed.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');   // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/lib/Roles.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/go-codes.php';
require_once __DIR__ . '/../../app/ui/domains-view.php';

$me = Auth::currentUser();
$pdo = Database::connection();
$uid = $me ? (int) $me['id'] : 0;
$type = 'user'; $id = $uid;
if ($uid) {
    if (preg_match('/^listing:(\d+)$/', (string) ($_GET['for'] ?? ''), $m)) { $type = 'listing'; $id = (int) $m[1]; }
    else { try { $cx = Roles::current($pdo, $uid); if (str_starts_with((string) $cx['key'], 'entity:')) { $type = 'listing'; $id = (int) substr((string) $cx['key'], 7); } } catch (Throwable) {} }   // acting as a business: for it
}
tv_page_start('Domains', ['no_crumbs' => true, 'description' => 'Search and register a domain name through Traversence: our price a year, in your name with privacy on.']);
tv_go_head('', false);
?>
<div class="go">
  <h1>Domains</h1>
  <p class="go-lead">A web address of your own, like <b>yourname.com</b>. Part of the <a href="/shop/">Shop</a>: paid in the one cart, then registered for you through Name.com.</p>
<?php if (!$uid): ?>
  <section class="go-card tv-bleed"><p class="go-note">A domain belongs to an account, so sign in or join first (it's free).</p>
    <p style="display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.5rem"><a class="go-btn main" href="/login.php?next=<?= rawurlencode('/shop/domains.php') ?>">Sign in</a><a class="go-btn" href="/register.php?next=<?= rawurlencode('/shop/domains.php') ?>">Join</a></p></section>
<?php else: ?>
  <?= tv_domains_view($type, $id, 'shop') ?>
<?php endif; ?>
  <p class="go-note">Prices are a year, before tax. Renewals are at Name.com's price then, plus ours. Questions: <a href="mailto:support@traversence.com">support@traversence.com</a></p>
</div>
<?php tv_page_end();
