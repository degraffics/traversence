<?php
// app/scripts/domains_tick.php — businesses' own domains (decisions/0139 §3, step 5b): every 15 minutes, checks the
// domains waiting for DNS or their certificate, re-checks live ones once a day, and renews domains bought through us two
// weeks before they run out (the card first, then Name.com). Sets itself up in cPanel through the API (Scheduler::AUTO).
// Also the accounts' own domains bought in the Shop (decisions/0169 §1a, AccountDomains::tick): auto-renewals on their
// wallet card, expiry, moves away, and the wallet's reminders before a card that pays for something expires.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('domains_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Domains.php';
$pdo = Database::connection();
[$checked, $live, $renewed, $failed] = Domains::tick($pdo);
echo 'Domains checked: ' . $checked . ', gone live: ' . $live . ', renewed: ' . $renewed . ', stopped: ' . $failed . ".\n";
require_once __DIR__ . '/../lib/AccountDomains.php';
[$aRenewed, $aFailed, $aExpired] = AccountDomains::tick($pdo);
echo 'Accounts\' domains renewed: ' . $aRenewed . ', declined: ' . $aFailed . ', expired: ' . $aExpired . ".\n";
