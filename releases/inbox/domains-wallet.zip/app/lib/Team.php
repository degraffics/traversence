<?php
// app/lib/Team.php — a business's team and what each role may do there (decisions/0102 §3–4, Master AOS §9B). The role
// decides: if a person's role allows an action they do it, with no confirmation step; if not, they can't. One check
// for every business page and API: Team::can($pdo, $userId, $listingId, 'catalog', 'edit').
//
// Levels, lowest to highest: none, view, draft, edit, full. The Owner has full everywhere. A one-person business sees
// no roles: its owner just has everything. Support agents acting on a business (standing grants and tickets, 0102 §5)
// come later and will pass through the same check.
declare(strict_types=1);

final class Team
{
    public const ROLES = ['owner' => 'Owner', 'manager' => 'Manager', 'accountant' => 'Accountant', 'sales' => 'Sales',
        'support' => 'Support', 'creator' => 'Creator', 'developer' => 'Developer', 'viewer' => 'Viewer'];
    /** Viewer (business-portal-architecture.md §7.3): sees the business's work, changes nothing; not money settings, the team or keys. */
    private const VIEWER = ['ledger' => 'view', 'listing' => 'view', 'catalog' => 'view', 'publish' => 'view', 'orders' => 'view', 'customers' => 'view',
        'inbox' => 'view', 'theme' => 'view', 'codes' => 'view', 'groups' => 'view'];
    public const PERMS = ['billing' => 'Plan & billing', 'ledger' => 'Ledger, invoices, payments', 'team' => 'Team & roles',
        'listing' => 'Listing details', 'catalog' => 'Catalog & content', 'publish' => 'Publish', 'orders' => 'Orders & fulfillment',
        'customers' => 'Customers & pipeline', 'inbox' => 'Inbox', 'domain' => 'Domain, API keys, webhooks', 'theme' => 'Theme & styling',
        'codes' => 'QR & short codes', 'groups' => 'Community groups', 'exports' => 'Exports', 'delete' => 'Delete the business'];
    private const RANK = ['none' => 0, 'view' => 1, 'draft' => 2, 'edit' => 3, 'full' => 4];
    /**
     * Our team's roles on a business, held through a grant (SupportAccess, decisions/0117), never given by an owner.
     * White Glove is the services in the Terms (#white-glove): the profile, catalog, content, storefront and codes;
     * seeing customers, orders and messages; never money, the team, keys, exports or deleting the business.
     */
    public const SUPPORT_ROLES = ['white_glove' => 'White Glove (Traversence)'];
    private const WHITE_GLOVE = ['listing' => 'edit', 'catalog' => 'edit', 'publish' => 'edit', 'theme' => 'edit', 'codes' => 'edit', 'groups' => 'view',
        'customers' => 'view', 'orders' => 'view', 'inbox' => 'view'];

    public static function roleName(string $role): string { return self::ROLES[$role] ?? self::SUPPORT_ROLES[$role] ?? ucfirst($role); }

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM listing_memberships LIMIT 1'); $pdo->query('SELECT 1 FROM ' . Database::t('role_perms') . ' LIMIT 1'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    /**
     * Every business this person is on, from all three records (the team, listing_access, the claimed owner), so the
     * menu, /business/ and the business dashboard agree: [listing id => [id, name, status, plan_tier, role]], by name.
     */
    public static function listingsOf(PDO $pdo, int $userId): array
    {
        self::claimInvites($pdo, $userId);   // an invitation to their confirmed email joins them first
        $role = [];
        $add = function (int $id, string $r) use (&$role) { if ($id > 0 && !isset($role[$id])) $role[$id] = $r; };
        if (self::ready($pdo)) { try { $st = $pdo->prepare("SELECT listing_id, role FROM listing_memberships WHERE user_id = ? AND status = 'active'"); $st->execute([$userId]); foreach ($st->fetchAll(PDO::FETCH_NUM) as [$i, $r]) $add((int) $i, (string) $r); } catch (Throwable) {} }
        try { $st = $pdo->prepare('SELECT entity_id, access_level FROM listing_access WHERE user_id = ?'); $st->execute([$userId]); foreach ($st->fetchAll(PDO::FETCH_NUM) as [$i, $r]) $add((int) $i, $r === 'owner' ? 'owner' : 'manager'); } catch (Throwable) {}
        try { $st = $pdo->prepare('SELECT id FROM entities WHERE owner_user_id = ?'); $st->execute([$userId]); foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $i) $role[(int) $i] = 'owner'; } catch (Throwable) {}
        require_once __DIR__ . '/SupportAccess.php';
        foreach (SupportAccess::listingsOf($pdo, $userId) as $i => $r) $add((int) $i, $r);
        if (!$role) return [];
        $out = [];
        $in = implode(',', array_map('intval', array_keys($role)));
        foreach ($pdo->query("SELECT id, name, status, plan_tier FROM entities WHERE id IN ($in) ORDER BY name")->fetchAll(PDO::FETCH_ASSOC) as $e)
            $out[(int) $e['id']] = $e + ['role' => $role[(int) $e['id']]];
        return $out;
    }

    /** The person's role on this business, or null. A listing (an `entities` row)'s claimed owner counts as its Owner. */
    public static function roleOf(PDO $pdo, int $userId, int $listingId): ?string
    {
        if (self::ready($pdo)) {
            $st = $pdo->prepare("SELECT role FROM listing_memberships WHERE listing_id = ? AND user_id = ? AND status = 'active'");
            $st->execute([$listingId, $userId]);
            $r = $st->fetchColumn();
            if ($r !== false) return (string) $r;
        }
        try {   // before the migration: the owner and managers from listing_access and entities.owner_user_id
            $st = $pdo->prepare('SELECT access_level FROM listing_access WHERE entity_id = ? AND user_id = ?');
            $st->execute([$listingId, $userId]);
            if (($r = $st->fetchColumn()) !== false) return (string) $r;
            $st = $pdo->prepare('SELECT owner_user_id FROM entities WHERE id = ?');
            $st->execute([$listingId]);
            if ($userId > 0 && (int) $st->fetchColumn() === $userId) return 'owner';
        } catch (Throwable) {}
        require_once __DIR__ . '/SupportAccess.php';   // our team, through a standing grant (White Glove)
        return SupportAccess::roleOf($pdo, $userId, $listingId);
    }

    /** The level a role has for a permission. */
    public static function level(PDO $pdo, string $role, string $perm): string
    {
        if ($role === 'owner') return 'full';
        static $cache = [];
        if (!isset($cache[$role])) {
            $cache[$role] = [];
            if (self::ready($pdo)) { $st = $pdo->prepare('SELECT perm, level FROM ' . Database::t('role_perms') . ' WHERE role = ?'); $st->execute([$role]); $cache[$role] = $st->fetchAll(PDO::FETCH_KEY_PAIR); }
            if ($role === 'viewer' && !$cache[$role]) $cache[$role] = self::VIEWER;   // until Permissions sets its own
            if ($role === 'white_glove') $cache[$role] = self::WHITE_GLOVE;   // fixed by the Terms, not by Permissions
        }
        return (string) ($cache[$role][$perm] ?? 'none');
    }

    /** Whether the person may do $need (view, draft, edit, full) with $perm on this business. */
    public static function can(PDO $pdo, int $userId, int $listingId, string $perm, string $need = 'view'): bool
    {
        $role = self::roleOf($pdo, $userId, $listingId);
        if ($role === null) return false;
        $lv = self::RANK[self::level($pdo, $role, $perm)];
        // a client's contacts on a public listing nobody has claimed (decisions/0101, addendum 2026-10-28): they see it, but
        // editing, publishing or deleting the listing (its public content and look too) waits for the claim; a private client listing is theirs to edit
        if (in_array($perm, ['listing', 'catalog', 'theme', 'publish', 'delete', 'domain'], true) && $lv > 1 && self::unclaimedPublic($pdo, $listingId)) $lv = 1;
        return $lv >= (self::RANK[$need] ?? 4);
    }

    private static function unclaimedPublic(PDO $pdo, int $listingId): bool
    {
        static $c = [];
        if (!isset($c[$listingId])) { try { $st = $pdo->prepare("SELECT status = 'unclaimed' AND is_suppressed = 0 FROM entities WHERE id = ?"); $st->execute([$listingId]); $c[$listingId] = (bool) $st->fetchColumn(); } catch (Throwable) { $c[$listingId] = false; } }
        return $c[$listingId];
    }

    /** The active team, owner first. */
    public static function members(PDO $pdo, int $listingId): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT m.*, u.email, u.display_name FROM listing_memberships m JOIN users u ON u.id = m.user_id
            WHERE m.listing_id = ? AND m.status = 'active' ORDER BY m.role = 'owner' DESC, m.created_at");
        $st->execute([$listingId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Adds someone to the team or changes their role; only someone with 'team' edit may, and never above Manager unless the Owner. */
    public static function setRole(PDO $pdo, int $actorId, int $listingId, int $userId, string $role): void
    {
        if (!isset(self::ROLES[$role])) throw new RuntimeException('Choose a role.');
        $actorRole = self::roleOf($pdo, $actorId, $listingId);
        if (!self::can($pdo, $actorId, $listingId, 'team', 'edit')) throw new RuntimeException('Your role doesn\'t manage the team.');
        if ($actorRole !== 'owner' && in_array($role, ['owner', 'manager'], true)) throw new RuntimeException('Only the Owner gives the Owner or Manager role.');
        if ($actorRole !== 'owner' && self::roleOf($pdo, $userId, $listingId) === 'manager') throw new RuntimeException('Only the Owner changes a Manager\'s role.');
        if (self::roleOf($pdo, $userId, $listingId) === 'owner' && $role !== 'owner') throw new RuntimeException('That\'s the owner. Ownership moves only through Traversence for now.');
        $pdo->prepare("INSERT INTO listing_memberships (listing_id, user_id, role, status, invited_by) VALUES (?, ?, ?, 'active', ?)
            ON DUPLICATE KEY UPDATE role = VALUES(role), status = 'active', ended_at = NULL")->execute([$listingId, $userId, $role, $actorId]);
        self::syncAccess($pdo, $listingId, $userId, $role);
        Audit::log($pdo, ['user' => $actorId, 'listing' => $listingId, 'route' => 'member', 'action' => 'team.role', 'detail' => "user $userId → $role"]);
    }

    /** Owner and Manager are kept in listing_access too (the listing editor reads it); other roles aren't there. */
    public static function syncAccess(PDO $pdo, int $listingId, int $userId, ?string $role): void   // also for Clients::claim
    {
        try {
            $pdo->prepare('DELETE FROM listing_access WHERE entity_id = ? AND user_id = ?')->execute([$listingId, $userId]);
            if (in_array($role, ['owner', 'manager'], true)) $pdo->prepare('INSERT INTO listing_access (entity_id, user_id, access_level, granted_by_user_id) VALUES (?, ?, ?, ?)')->execute([$listingId, $userId, $role, $userId]);
        } catch (Throwable $x) { error_log('team access sync: ' . $x->getMessage()); }
    }

    /** Someone on the team takes a person off it (Plan & settings): never the owner; a Manager only by the Owner; anyone may leave. */
    public static function remove(PDO $pdo, int $actorId, int $listingId, int $userId): void
    {
        $role = self::roleOf($pdo, $userId, $listingId);
        if ($role === null) throw new RuntimeException('They\'re not on the team.');
        if ($role === 'owner') throw new RuntimeException('That\'s the owner: they can\'t be taken off.');
        if ($actorId !== $userId) {
            if (!self::can($pdo, $actorId, $listingId, 'team', 'edit')) throw new RuntimeException('Your role doesn\'t manage the team.');
            if ($role === 'manager' && self::roleOf($pdo, $actorId, $listingId) !== 'owner') throw new RuntimeException('Only the Owner takes a Manager off the team.');
        }
        $pdo->prepare("UPDATE listing_memberships SET status = 'ended', ended_at = NOW() WHERE listing_id = ? AND user_id = ?")->execute([$listingId, $userId]);
        self::syncAccess($pdo, $listingId, $userId, null);
        Audit::log($pdo, ['user' => $actorId, 'listing' => $listingId, 'route' => 'member', 'action' => 'team.remove', 'detail' => "user $userId" . ($actorId === $userId ? ' (left)' : '')]);
    }

    // ---- handing over ownership (decisions/0103 §2 "By hand"; 0120): the owner names a successor, the successor accepts

    public const TRANSFER_DAYS = 30;   // an unanswered request lapses (0103's ⏱30 days)

    public static function ensureTransfers(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS transfers (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(16) NOT NULL, ref BIGINT UNSIGNED NOT NULL,
                from_user INT UNSIGNED NOT NULL, to_user INT UNSIGNED NOT NULL, requested_at DATETIME NOT NULL, expires_at DATETIME NOT NULL, accepted_at DATETIME DEFAULT NULL,
                declined_at DATETIME DEFAULT NULL, cancelled_at DATETIME DEFAULT NULL, note VARCHAR(300) NOT NULL DEFAULT '', KEY idx_tr_ref (kind, ref), KEY idx_tr_to (to_user))
                ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            return $ok = true;
        } catch (Throwable $x) { error_log('transfers: ' . $x->getMessage()); return $ok = false; }
    }

    /** The open request on a business, if any (not answered, not lapsed). */
    public static function pendingTransfer(PDO $pdo, int $listingId): ?array
    {
        if (!self::ensureTransfers($pdo)) return null;
        $st = $pdo->prepare("SELECT t.*, u.email AS to_email, u.display_name AS to_name FROM transfers t JOIN users u ON u.id = t.to_user
            WHERE t.kind = 'business' AND t.ref = ? AND t.accepted_at IS NULL AND t.declined_at IS NULL AND t.cancelled_at IS NULL AND t.expires_at > NOW() ORDER BY t.id DESC LIMIT 1");
        try { $st->execute([$listingId]); return $st->fetch(PDO::FETCH_ASSOC) ?: null; }
        catch (PDOException $x) { error_log('pendingTransfer: ' . $x->getMessage()); return null; }   // an older transfers table: no handover shown, the page goes on
    }

    public static function transfer(PDO $pdo, int $id): ?array
    {
        if (!self::ensureTransfers($pdo)) return null;
        $st = $pdo->prepare("SELECT t.*, e.name AS biz, f.display_name AS from_name, f.email AS from_email FROM transfers t JOIN entities e ON e.id = t.ref JOIN users f ON f.id = t.from_user WHERE t.id = ? AND t.kind = 'business'");
        $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** The Owner asks someone (on the team, or any member by email) to take the business over. Nothing changes until they accept. */
    public static function requestTransfer(PDO $pdo, int $ownerId, int $listingId, string $who, string $bizName): string
    {
        if (self::roleOf($pdo, $ownerId, $listingId) !== 'owner') throw new RuntimeException('Only the Owner hands over the business.');
        if (!self::ensureTransfers($pdo)) throw new RuntimeException('Handing over isn\'t set up yet: run app/migrations/2026-12-26_transfers.sql.');
        $who = trim($who);
        $st = ctype_digit($who) ? $pdo->prepare('SELECT id, email, display_name FROM users WHERE id = ? AND deleted_at IS NULL') : $pdo->prepare('SELECT id, email, display_name FROM users WHERE email = ? AND deleted_at IS NULL');
        $st->execute([ctype_digit($who) ? (int) $who : strtolower($who)]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if (!$u) throw new RuntimeException('No Traversence account has that email. They sign up first (free), then you ask them.');
        $to = (int) $u['id'];
        if ($to === $ownerId) throw new RuntimeException('That\'s you.');
        require_once __DIR__ . '/Roles.php';
        if (Roles::staffLogin($pdo, $to)) throw new RuntimeException('That\'s a Traversence staff login. Use the person\'s own account.');
        $pdo->prepare("UPDATE transfers SET cancelled_at = NOW() WHERE kind = 'business' AND ref = ? AND accepted_at IS NULL AND declined_at IS NULL AND cancelled_at IS NULL")->execute([$listingId]);
        $pdo->prepare("INSERT INTO transfers (kind, ref, from_user, to_user, requested_at, expires_at) VALUES ('business', ?, ?, ?, NOW(), NOW() + INTERVAL " . self::TRANSFER_DAYS . " DAY)")->execute([$listingId, $ownerId, $to]);
        $tid = (int) $pdo->lastInsertId();
        Audit::log($pdo, ['user' => $ownerId, 'listing' => $listingId, 'route' => 'member', 'action' => 'owner.transfer_ask', 'detail' => "to user $to (request $tid)"]);
        require_once __DIR__ . '/Mailer.php';
        $base = rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/');
        try { Mailer::send((string) $u['email'], 'Take over ' . $bizName . ' on Traversence?', 'You\'ve been asked to take over ' . $bizName . ' on Traversence as its Owner.' . "\n\nNothing changes until you accept. See what it means and accept or decline here (the request lapses in " . self::TRANSFER_DAYS . " days):\n$base/user/transfer.php?id=$tid\n\nTraversence\n"); }
        catch (Throwable $x) { error_log('transfer mail: ' . $x->getMessage()); }
        return 'We\'ve asked ' . (trim((string) $u['display_name']) ?: (string) $u['email']) . '. Nothing changes until they accept.';
    }

    public static function cancelTransfer(PDO $pdo, int $ownerId, int $listingId): void
    {
        if (self::roleOf($pdo, $ownerId, $listingId) !== 'owner') throw new RuntimeException('Only the Owner can cancel it.');
        if (!self::ensureTransfers($pdo)) return;
        $pdo->prepare("UPDATE transfers SET cancelled_at = NOW() WHERE kind = 'business' AND ref = ? AND accepted_at IS NULL AND declined_at IS NULL AND cancelled_at IS NULL")->execute([$listingId]);
        Audit::log($pdo, ['user' => $ownerId, 'listing' => $listingId, 'route' => 'member', 'action' => 'owner.transfer_cancel', 'detail' => '']);
    }

    /** The successor answers. Accepting makes them the Owner; the one before stays on as Manager; the team is told. */
    public static function answerTransfer(PDO $pdo, int $tid, int $uid, bool $accept): array
    {
        $t = self::transfer($pdo, $tid);
        if (!$t || (int) $t['to_user'] !== $uid) throw new RuntimeException('This request isn\'t for the account you\'re signed in as.');
        if ($t['accepted_at'] || $t['declined_at'] || $t['cancelled_at'] || strtotime((string) $t['expires_at']) < time()) throw new RuntimeException('This request isn\'t open any more.');
        $lid = (int) $t['ref'];
        if (self::roleOf($pdo, (int) $t['from_user'], $lid) !== 'owner') throw new RuntimeException('Whoever asked isn\'t the owner any more, so this request has lapsed.');
        if (!$accept) {
            $pdo->prepare('UPDATE transfers SET declined_at = NOW() WHERE id = ?')->execute([$tid]);
            Audit::log($pdo, ['user' => $uid, 'listing' => $lid, 'route' => 'member', 'action' => 'owner.transfer_decline', 'detail' => "request $tid"]);
            self::tell($pdo, [(int) $t['from_user']], $t['biz'] . ': handing over was declined', 'The person you asked declined to take over ' . $t['biz'] . '. You\'re still its Owner.');
            return $t;
        }
        $from = (int) $t['from_user'];
        $pdo->beginTransaction();
        try {
            $set = $pdo->prepare("INSERT INTO listing_memberships (listing_id, user_id, role, status, invited_by) VALUES (?, ?, ?, 'active', ?) ON DUPLICATE KEY UPDATE role = VALUES(role), status = 'active', ended_at = NULL");
            $set->execute([$lid, $uid, 'owner', $from]); self::syncAccess($pdo, $lid, $uid, 'owner');
            $set->execute([$lid, $from, 'manager', $uid]); self::syncAccess($pdo, $lid, $from, 'manager');
            $pdo->prepare('UPDATE entities SET owner_user_id = ?, updated_at = NOW() WHERE id = ?')->execute([$uid, $lid]);
            $pdo->prepare('UPDATE transfers SET accepted_at = NOW() WHERE id = ?')->execute([$tid]);
            $pdo->commit();
        } catch (Throwable $x) { $pdo->rollBack(); throw $x; }
        $billing = self::handOverBilling($pdo, $lid);
        Audit::log($pdo, ['user' => $uid, 'listing' => $lid, 'route' => 'member', 'action' => 'owner.transfer_accept', 'detail' => "request $tid: user $from → user $uid"]);
        $st = $pdo->prepare('SELECT display_name, email FROM users WHERE id = ?'); $st->execute([$uid]); $n = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        $who = trim((string) ($n['display_name'] ?? '')) ?: (string) ($n['email'] ?? 'The new owner');
        $team = array_values(array_filter(array_map(fn ($m) => (int) $m['user_id'], self::members($pdo, $lid)), fn ($x) => $x !== $uid));
        self::tell($pdo, $team, $t['biz'] . ' has a new Owner', $who . ' is now the Owner of ' . $t['biz'] . ' on Traversence, taking over from ' . (trim((string) $t['from_name']) ?: $t['from_email']) . ', who stays on the team as Manager.');
        if ($billing) self::tell($pdo, [$uid], 'Keep ' . $t['biz'] . '\'s plan: add your card', 'You\'re now the Owner of ' . $t['biz'] . '. Its ' . $billing . ' plan was paid with the previous owner\'s card, which has been taken off it. The plan runs to the end of the period it\'s paid for; to keep it after that, add your card and choose Keep my plan: '
            . rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/') . '/plans.php?listing=' . $lid);
        return $t;
    }

    /**
     * After a change of owner: the plan stays, but the previous owner's card comes off it so they're never charged for a
     * business that isn't theirs; it runs to the end of its paid period unless the new owner adds a card and keeps it.
     * Returns the plan's name when there was one to hand over.
     */
    private static function handOverBilling(PDO $pdo, int $listingId): string
    {
        try {
            require_once __DIR__ . '/Billing.php';
            $s = Billing::current($pdo, 'listing', $listingId);
            if (!$s || !in_array($s['status'], ['trial', 'active', 'past_due'], true)) return '';
            $pdo->prepare("UPDATE subscriptions SET card_id = '', card_label = '', cancel_at_end = 1 WHERE id = ?")->execute([(int) $s['id']]);
            require_once __DIR__ . '/Wallet.php';   // and from the wallet: the plan's card comes off, the previous owner's cards leave it (decisions/0166 §6a)
            try { Wallet::handOver($pdo, $listingId, (int) $s['id'], (int) ($s['payer_id'] ?? 0)); } catch (Throwable $x) { error_log('transfer wallet: ' . $x->getMessage()); }
            return (string) (Billing::PLANS[$s['plan']][0] ?? $s['plan']);
        } catch (Throwable $x) { error_log('transfer billing: ' . $x->getMessage()); return ''; }
    }

    private static function tell(PDO $pdo, array $uids, string $subject, string $body): void
    {
        if (!$uids) return;
        require_once __DIR__ . '/Mailer.php';
        $st = $pdo->prepare('SELECT email FROM users WHERE id = ?');
        foreach (array_unique($uids) as $u) { try { $st->execute([$u]); if ($to = (string) $st->fetchColumn()) Mailer::send($to, $subject, $body . "\n\nTraversence\n"); } catch (Throwable $x) { error_log('team tell: ' . $x->getMessage()); } }
    }

    // ---- invitations: someone without an account yet (decisions/0118) ---------------------------------------------

    public static function ensureInvites(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS listing_invites (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, listing_id BIGINT UNSIGNED NOT NULL, email VARCHAR(190) NOT NULL,
                role VARCHAR(16) NOT NULL, invited_by INT UNSIGNED DEFAULT NULL, created_at DATETIME NOT NULL, accepted_at DATETIME DEFAULT NULL, accepted_user INT UNSIGNED DEFAULT NULL,
                cancelled_at DATETIME DEFAULT NULL, KEY idx_li_email (email, accepted_at, cancelled_at), KEY idx_li_listing (listing_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            return $ok = true;
        } catch (Throwable $x) { error_log('listing invites: ' . $x->getMessage()); return $ok = false; }
    }

    /**
     * Adds a person by email: on the team at once when they have an account (and they're emailed), else an invitation
     * by email that joins them when they sign up (or sign in) with that email, confirmed. Returns what happened.
     */
    public static function invite(PDO $pdo, int $actorId, int $listingId, string $email, string $role, string $bizName, string $name = ''): string
    {
        $email = strtolower(trim($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('That email doesn\'t look right.');
        if (!isset(self::ROLES[$role]) || $role === 'owner') throw new RuntimeException('Choose a role.');
        if (!self::can($pdo, $actorId, $listingId, 'team', 'edit')) throw new RuntimeException('Your role doesn\'t manage the team.');
        if (self::roleOf($pdo, $actorId, $listingId) !== 'owner' && $role === 'manager') throw new RuntimeException('Only the Owner gives the Manager role.');
        $base = rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/');
        require_once __DIR__ . '/Mailer.php';
        $st = $pdo->prepare('SELECT id, display_name FROM users WHERE email = ? AND deleted_at IS NULL'); $st->execute([$email]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if ($u) {
            require_once __DIR__ . '/Roles.php';
            if (Roles::staffLogin($pdo, (int) $u['id'])) throw new RuntimeException('That\'s a Traversence staff login. Use the person\'s own account email.');
            if (self::roleOf($pdo, (int) $u['id'], $listingId) !== null) throw new RuntimeException('They\'re already on the team. Change their role in the list.');
            self::setRole($pdo, $actorId, $listingId, (int) $u['id'], $role);
            try { Mailer::send($email, 'You\'re on ' . $bizName . '\'s team on Traversence', 'You\'ve been added to ' . $bizName . ' as ' . self::ROLES[$role] . ".\n\nOpen it from your account menu (Your listings), or here:\n$base/business/$listingId\n\nTraversence\n"); } catch (Throwable $x) { error_log('team mail: ' . $x->getMessage()); }
            return (trim((string) $u['display_name']) ?: $email) . ' is on the team now; we\'ve emailed them.';
        }
        if (!self::ensureInvites($pdo)) throw new RuntimeException('Invitations aren\'t set up yet: run app/migrations/2026-12-25_listing_invites.sql.');
        require_once __DIR__ . '/Clients.php';
        if (Clients::ready($pdo)) {   // a contact with the claim link (/join.php): activate and create the account in one step (decisions/0101, addendum 2026-10-28)
            Clients::sendInvite($pdo, $actorId, Clients::addContact($pdo, $actorId, $listingId, ['email' => $email, 'role' => $role, 'name' => $name], false), false);
            return 'Invitation emailed to ' . $email . ': the link lets them claim their place and create their account.';
        }
        $pdo->prepare('UPDATE listing_invites SET cancelled_at = NOW() WHERE listing_id = ? AND email = ? AND accepted_at IS NULL AND cancelled_at IS NULL')->execute([$listingId, $email]);
        $pdo->prepare('INSERT INTO listing_invites (listing_id, email, role, invited_by, created_at) VALUES (?, ?, ?, ?, NOW())')->execute([$listingId, $email, $role, $actorId]);
        Audit::log($pdo, ['user' => $actorId, 'listing' => $listingId, 'route' => 'member', 'action' => 'team.invite', 'detail' => "$email → $role"]);
        Mailer::send($email, 'Join ' . $bizName . '\'s team on Traversence', 'You\'ve been invited to help run ' . $bizName . ' on Traversence, as ' . self::ROLES[$role] . ".\n\n"
            . "Create your free account with this email address ($email), and you'll be on the team as soon as it's confirmed:\n$base/register.php?next=" . rawurlencode("/business/$listingId") . "\n\nAlready have an account under another email? Ask them to invite that one instead.\n\nTraversence\n");
        return 'Invitation emailed to ' . $email . '. They join when they sign up with that email.';
    }

    /** Invitations still open for a business. */
    public static function invites(PDO $pdo, int $listingId): array
    {
        if (!self::ensureInvites($pdo)) return [];
        $st = $pdo->prepare('SELECT id, email, role, created_at FROM listing_invites WHERE listing_id = ? AND accepted_at IS NULL AND cancelled_at IS NULL ORDER BY created_at'); $st->execute([$listingId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function cancelInvite(PDO $pdo, int $actorId, int $listingId, int $inviteId): void
    {
        if (!self::can($pdo, $actorId, $listingId, 'team', 'edit')) throw new RuntimeException('Your role doesn\'t manage the team.');
        if (!self::ensureInvites($pdo)) return;
        $pdo->prepare('UPDATE listing_invites SET cancelled_at = NOW() WHERE id = ? AND listing_id = ? AND accepted_at IS NULL')->execute([$inviteId, $listingId]);
        Audit::log($pdo, ['user' => $actorId, 'listing' => $listingId, 'route' => 'member', 'action' => 'team.invite_cancel', 'detail' => "invite $inviteId"]);
    }

    /** Joins this person to every business that invited their (confirmed) email. Called as their businesses are read. */
    public static function claimInvites(PDO $pdo, int $userId): void
    {
        static $done = [];
        if (isset($done[$userId])) return;
        $done[$userId] = true;
        try {
            $st = $pdo->prepare('SELECT i.id, i.listing_id, i.role, i.invited_by FROM listing_invites i JOIN users u ON u.email = i.email
                WHERE u.id = ? AND u.email_verified_at IS NOT NULL AND i.accepted_at IS NULL AND i.cancelled_at IS NULL');
            $st->execute([$userId]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $i) {
                if (self::roleOf($pdo, $userId, (int) $i['listing_id']) === null) {
                    $pdo->prepare("INSERT INTO listing_memberships (listing_id, user_id, role, status, invited_by) VALUES (?, ?, ?, 'active', ?)
                        ON DUPLICATE KEY UPDATE role = VALUES(role), status = 'active', ended_at = NULL")->execute([(int) $i['listing_id'], $userId, $i['role'], $i['invited_by']]);
                    self::syncAccess($pdo, (int) $i['listing_id'], $userId, (string) $i['role']);
                    Audit::log($pdo, ['user' => $userId, 'listing' => (int) $i['listing_id'], 'route' => 'member', 'action' => 'team.join', 'detail' => 'invitation ' . $i['id'] . ' → ' . $i['role']]);
                }
                $pdo->prepare('UPDATE listing_invites SET accepted_at = NOW(), accepted_user = ? WHERE id = ?')->execute([$userId, (int) $i['id']]);
            }
        } catch (Throwable) {}   // no invitations table yet: nothing to claim
    }

    /**
     * Our team puts a member on a business (admin → Local → Listings → Owner & team): by their account's email, with a
     * role. Owner also becomes the listing's claimed owner (the one before stays on as Manager); Owner and Manager are
     * kept in listing_access too, which the listing editor reads. The member is told by email. Logged as route admin.
     */
    public static function adminSet(PDO $pdo, int $listingId, string $email, string $role, int $actorId): string
    {
        if (!isset(self::ROLES[$role])) throw new InvalidArgumentException('Choose a role.');
        $st = $pdo->prepare('SELECT id, email, display_name FROM users WHERE email = ? AND deleted_at IS NULL'); $st->execute([trim($email)]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if (!$u) throw new InvalidArgumentException('No member account has that email. They sign up first, then you add them.');
        require_once __DIR__ . '/Roles.php';
        if (Roles::staffLogin($pdo, (int) $u['id'])) throw new InvalidArgumentException('That\'s a staff login. Add the person\'s own member account.');
        $st = $pdo->prepare('SELECT name, owner_user_id FROM entities WHERE id = ?'); $st->execute([$listingId]);
        $e = $st->fetch(PDO::FETCH_ASSOC);
        if (!$e) throw new InvalidArgumentException('That listing isn\'t here.');
        $uid = (int) $u['id'];
        $team = function (int $who, string $r) use ($pdo, $listingId, $actorId) {
            if (self::ready($pdo)) $pdo->prepare("INSERT INTO listing_memberships (listing_id, user_id, role, status, invited_by) VALUES (?, ?, ?, 'active', ?)
                ON DUPLICATE KEY UPDATE role = VALUES(role), status = 'active', ended_at = NULL")->execute([$listingId, $who, $r, $actorId]);
            $pdo->prepare('DELETE FROM listing_access WHERE entity_id = ? AND user_id = ?')->execute([$listingId, $who]);
            if (in_array($r, ['owner', 'manager'], true)) $pdo->prepare('INSERT INTO listing_access (entity_id, user_id, access_level, granted_by_user_id) VALUES (?, ?, ?, ?)')->execute([$listingId, $who, $r, $actorId]);
        };
        $pdo->beginTransaction();
        try {
            if ($role === 'owner') {
                $was = (int) $e['owner_user_id'];
                if ($was && $was !== $uid) $team($was, 'manager');
                $pdo->prepare("UPDATE entities SET owner_user_id = ?, status = IF(status = 'unclaimed', 'claimed-unverified', status), updated_at = NOW() WHERE id = ?")->execute([$uid, $listingId]);
                if ($was && $was !== $uid) self::handOverBilling($pdo, $listingId);   // the old owner's card comes off the plan
            } elseif ((int) $e['owner_user_id'] === $uid) {
                throw new InvalidArgumentException('They\'re its owner. Make someone else the owner first.');
            }
            $team($uid, $role);
            $pdo->commit();
        } catch (Throwable $t) { $pdo->rollBack(); throw $t; }
        Audit::log($pdo, ['user' => $actorId, 'listing' => $listingId, 'route' => 'admin', 'action' => 'team.set', 'detail' => "user $uid → $role"]);
        try { require_once __DIR__ . '/Mailer.php'; Mailer::send((string) $u['email'], 'You\'re on ' . $e['name'] . '\'s team on Traversence', 'Our team has added you to ' . $e['name'] . ' as ' . self::ROLES[$role] . ".\n\nOpen it from your account menu (Your listings, Business portal), or here:\n"
            . rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/business/' . $listingId . "\n\nIf you didn't expect this, reply and we'll take you off."); } catch (Throwable $t) { error_log('team mail: ' . $t->getMessage()); }
        return trim((string) $u['display_name']) ?: (string) $u['email'];
    }

    /** Our team takes someone off a business. The owner can't be taken off this way: make someone else the owner first. */
    public static function adminRemove(PDO $pdo, int $listingId, int $userId, int $actorId): void
    {
        $st = $pdo->prepare('SELECT owner_user_id FROM entities WHERE id = ?'); $st->execute([$listingId]);
        if ((int) $st->fetchColumn() === $userId) throw new InvalidArgumentException('That\'s its owner. Make someone else the owner first.');
        if (self::ready($pdo)) $pdo->prepare("UPDATE listing_memberships SET status = 'ended', ended_at = NOW() WHERE listing_id = ? AND user_id = ?")->execute([$listingId, $userId]);
        $pdo->prepare('DELETE FROM listing_access WHERE entity_id = ? AND user_id = ?')->execute([$listingId, $userId]);
        Audit::log($pdo, ['user' => $actorId, 'listing' => $listingId, 'route' => 'admin', 'action' => 'team.remove', 'detail' => "user $userId"]);
    }
}

/** The action log (decisions/0102 §5): who did what, where, by which route. Rows are only ever added. */
final class Audit
{
    public static function log(PDO $pdo, array $a): void
    {
        try {
            $pdo->prepare('INSERT INTO ' . Database::t('audit_log') . ' (actor_user, actor_staff, listing_id, route, action, detail) VALUES (?, ?, ?, ?, ?, ?)')->execute([
                $a['user'] ?? null, $a['staff'] ?? null, $a['listing'] ?? null, (string) ($a['route'] ?? ''),
                substr((string) ($a['action'] ?? ''), 0, 64), substr((string) ($a['detail'] ?? ''), 0, 500)]);
        } catch (Throwable) {}   // the log never stops the action it records
    }
}
