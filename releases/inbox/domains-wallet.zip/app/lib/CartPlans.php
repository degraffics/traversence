<?php
// app/lib/CartPlans.php — plans and storage packs in the cart (decisions/0154 §6: one cart for everything Traversence
// sells). Beside the GO Codes in /qr/cart.php, for a signed-in member, for themselves or a business they handle billing
// for. Paid with the same card form: a plan that starts takes one card token (Billing::start keeps the card on file
// for renewals); a change of plan or packs added to a plan already paid go on the card on file (Billing::changePlan,
// addAddon). GO Codes in the same checkout take a second token from the same card entry (js/go-codes.js `tokens`).
declare(strict_types=1);

require_once __DIR__ . '/Billing.php';

final class CartPlans
{
    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM cart_plans LIMIT 0'); return $r = Billing::ready($pdo); } catch (PDOException) { return $r = false; }
    }

    /** Puts a plan or a pack in the cart for an account. A plan replaces the account's other plan in the cart; a pack adds one. */
    public static function add(PDO $pdo, int $uid, string $type, int $id, string $item, string $cycle = 'month'): void
    {
        $type = $type === 'listing' ? 'listing' : 'user'; if ($type === 'user') $id = $uid;
        if (!Billing::canManage($pdo, $uid, $type, $id)) throw new InvalidArgumentException('Only the owner, or someone they let handle billing, can choose its plan.');
        $cycle = $cycle === 'year' ? 'year' : 'month';
        $s = Billing::current($pdo, $type, $id);
        if (isset(Billing::PLANS[$item])) {
            if (Billing::PLANS[$item][1] !== $type) throw new InvalidArgumentException('That plan is for a ' . ($type === 'user' ? 'business' : 'personal account') . '.');
            if (Billing::planPrice($item, 'month') === 0) throw new InvalidArgumentException('The free plan needs no checkout: stop your plan on the Plans page instead.');
            if ($s && $s['status'] !== 'trial' && $s['plan'] === $item) throw new InvalidArgumentException('That\'s your plan now.');
            $pdo->prepare("DELETE FROM cart_plans WHERE user_id = ? AND owner_type = ? AND owner_id = ? AND item IN ('" . implode("','", array_keys(Billing::PLANS)) . "')")->execute([$uid, $type, $id]);
            $pdo->prepare('INSERT INTO cart_plans (user_id, owner_type, owner_id, item, qty, cycle, created_at) VALUES (?, ?, ?, ?, 1, ?, ?)')->execute([$uid, $type, $id, $item, $cycle, date('Y-m-d H:i:s')]);
            return;
        }
        if (!isset(Billing::ADDONS[$item])) throw new InvalidArgumentException('That isn\'t something we sell.');
        $pdo->prepare('INSERT INTO cart_plans (user_id, owner_type, owner_id, item, qty, cycle, created_at) VALUES (?, ?, ?, ?, 1, ?, ?) ON DUPLICATE KEY UPDATE qty = LEAST(qty + 1, 20)')
            ->execute([$uid, $type, $id, $item, $cycle, date('Y-m-d H:i:s')]);
    }

    public static function remove(PDO $pdo, int $uid, int $line): void
    {
        $pdo->prepare('DELETE FROM cart_plans WHERE id = ? AND user_id = ?')->execute([$line, $uid]);
    }

    /** The member's plan lines, grouped by account: [{type, id, name, lines: [{id, item, name, qty, cents, kind}], plan, card:
     *  'new' (a card is entered: a plan starts) | 'file' (the card on file pays) | 'none' (can't yet: why), why, due_now}]. */
    public static function groups(PDO $pdo, int $uid): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM cart_plans WHERE user_id = ? ORDER BY owner_type DESC, owner_id, id'); $st->execute([$uid]);
        $g = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if ($r['owner_type'] === 'domain') continue;   // domains (app/lib/AccountDomains.php): their own groups, added below
            if ($r['owner_type'] === 'media' || $r['owner_type'] === 'oneoff') {   // one-off purchases (app/lib/OneOffs.php): one group, paid once
                require_once __DIR__ . '/OneOffs.php';
                if (!isset(OneOffs::KINDS[$r['item']])) continue;
                $g['oneoff'] = $g['oneoff'] ?? ['type' => 'oneoff', 'id' => 0, 'name' => 'One-off purchases', 'lines' => [], 'plan' => '', 'cycle' => 'once'];
                $g['oneoff']['lines'][] = ['id' => (int) $r['id'], 'item' => (string) $r['item'], 'kind' => 'oneoff', 'qty' => 1, 'ref' => (int) $r['owner_id'],
                    'name' => OneOffs::KINDS[$r['item']][0], 'cents' => OneOffs::KINDS[$r['item']][1], 'per' => 'once'];
                continue;
            }
            $k = $r['owner_type'] . ':' . $r['owner_id'];
            if (!isset($g[$k])) {
                $o = Billing::owner($pdo, (string) $r['owner_type'], (int) $r['owner_id']);
                $g[$k] = ['type' => (string) $r['owner_type'], 'id' => (int) $r['owner_id'], 'name' => $r['owner_type'] === 'user' ? 'Your personal plan' : (string) $o['name'], 'lines' => [], 'plan' => '', 'cycle' => 'month'];
            }
            $plan = isset(Billing::PLANS[$r['item']]);
            if ($plan) { $g[$k]['plan'] = (string) $r['item']; $g[$k]['cycle'] = (string) $r['cycle']; }
            $g[$k]['lines'][] = ['id' => (int) $r['id'], 'item' => (string) $r['item'], 'kind' => $plan ? 'plan' : 'pack', 'qty' => (int) $r['qty'],
                'name' => $plan ? Billing::PLANS[$r['item']][0] . ' plan' : Billing::ADDONS[$r['item']][0] . ((int) $r['qty'] > 1 ? ' × ' . (int) $r['qty'] : ''),
                'cents' => $plan ? Billing::planPrice((string) $r['item'], (string) $r['cycle']) : (int) Billing::ADDONS[$r['item']][1] * (int) $r['qty'], 'per' => $r['cycle'] === 'year' ? 'a year' : 'a month'];
        }
        foreach ($g as &$x) {
            if ($x['type'] === 'oneoff') { $x['card'] = 'new'; $x['why'] = ''; $x['due_now'] = array_sum(array_column($x['lines'], 'cents')); continue; }
            $s = Billing::current($pdo, $x['type'], $x['id']);
            $paid = $s && $s['status'] !== 'trial';
            $packs = []; foreach ($x['lines'] as $l) if ($l['kind'] === 'pack') $packs[$l['item']] = $l['qty'];
            $x['why'] = '';
            if ($x['plan'] !== '' && !$paid) { $x['card'] = 'new'; $x['due_now'] = Billing::quote($x['plan'], $x['cycle'], $packs)['total']; }
            elseif ($paid && ($s['card_id'] ?? '') !== '') {
                $x['card'] = 'file'; $x['card_label'] = (string) ($s['card_label'] ?? '');
                $due = $x['plan'] !== '' ? (int) Billing::previewChange($s, $x['plan'])['charge'] : 0;
                foreach ($packs as $a => $q) $due += Billing::previewAddon($s, $a, $q);
                $x['due_now'] = $due;
            } else { $x['card'] = 'none'; $x['due_now'] = 0; $x['why'] = $s && $s['status'] === 'trial' ? 'Packs are added once the plan is kept: add a plan here, or keep yours on the Plans page.' : 'Packs go on a paid plan: add a plan here with them.'; }
        }
        unset($x);
        $out = array_values($g);
        if (is_file(__DIR__ . '/AccountDomains.php')) {   // domains (decisions/0169 §1a): a group per account, paid from its wallet or a new card
            require_once __DIR__ . '/AccountDomains.php';
            try { $out = array_merge($out, AccountDomains::cartGroups($pdo, $uid)); } catch (Throwable $e) { error_log('cart domains: ' . $e->getMessage()); }
        }
        return $out;
    }

    /** How many card tokens the plans need (one for each account whose plan starts now). */
    public static function tokensNeeded(PDO $pdo, int $uid): int
    {
        return count(array_filter(self::groups($pdo, $uid), fn ($x) => $x['card'] === 'new'));
    }

    /** Pays the plan lines, account by account, in order; each one done comes out of the cart. Stops at the first that
     *  fails, saying what was done before it. $tokens: one for each account whose plan starts (tokensNeeded()). */
    public static function pay(PDO $pdo, int $uid, array $tokens): array
    {
        $done = [];
        foreach (self::groups($pdo, $uid) as $x) {
            if ($x['card'] === 'none') throw new InvalidArgumentException($x['name'] . ': ' . $x['why']);
            $packs = []; foreach ($x['lines'] as $l) if ($l['kind'] === 'pack') $packs[$l['item']] = $l['qty'];
            try {
                if ($x['type'] === 'oneoff') { require_once __DIR__ . '/OneOffs.php'; OneOffs::pay($pdo, $uid, $x['lines'], (string) array_shift($tokens)); }
                elseif ($x['type'] === 'domain') { require_once __DIR__ . '/AccountDomains.php'; AccountDomains::payGroup($pdo, $uid, $x, $x['card'] === 'new' ? (string) array_shift($tokens) : ''); }
                elseif ($x['card'] === 'new') {
                    $tok = (string) array_shift($tokens);
                    if (!preg_match('/^[A-Za-z0-9_.:-]{6,300}$/', $tok)) throw new RuntimeException('The card details didn\'t come through. Nothing was charged for it. Try again.');
                    Billing::start($pdo, $uid, $x['type'], $x['id'], $x['plan'], $x['cycle'], $packs, $tok);
                } else {
                    $s = Billing::current($pdo, $x['type'], $x['id']);
                    if ($x['plan'] !== '') Billing::changePlan($pdo, (int) $s['id'], $x['plan']);
                    foreach ($packs as $a => $q) Billing::addAddon($pdo, (int) $s['id'], $a, $q);
                }
            } catch (Throwable $e) {
                throw new RuntimeException(($done ? 'Done: ' . implode(', ', $done) . '. ' : '') . $x['name'] . ': ' . $e->getMessage());
            }
            $ids = implode(',', array_map(fn ($l) => (int) $l['id'], $x['lines']));
            $pdo->prepare("DELETE FROM cart_plans WHERE user_id = ? AND id IN ($ids)")->execute([$uid]);
            $done[] = $x['name'];
        }
        return $done;
    }
}
