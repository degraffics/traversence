<?php
// app/lib/Wallet.php — each account's wallet (decisions/0166 §6a, built first by the Domains build, 0169 §1a). A member's
// wallet and a business's never mix. It holds saved cards: only the processor's card reference and a label
// ("Visa ··4242") with the expiry month, never the number (the card goes from the browser to Intuit for a one-time
// token; QuickBooksPay::saveCard turns it into a card on file, chargeSaved charges it). One card is the default, offered
// first at checkout. Every purchase that renews is *assigned* a card (a plan, a domain's renewals; paid apps later); an
// assigned card is *locked*: it can't be removed, only replaced (for that one thing, or for everything on it), and it
// unlocks when nothing renews on it any more. 30 days before a locked card expires the account is reminded, with
// Replace card. Each card stays with the processor that saved it (0166 §6, rule 2): QuickBooks Payments today.
// Who manages it: a member their own; a business's, whoever has Plan & billing (edit) on its team: the owner, and the
// accountant role when the owner allows it (Team's role permissions). A test account's cards live in the sandbox.
// Plans pay from the wallet (Jason, 2026-11-17: "it is a payment method from wallet"): subscriptions.card_id and
// card_label stay, kept equal to the plan's assigned card, so every reader of them keeps working.
// Two wallets per account, never mixed (Jason, 2026-11-17: "a test/sandbox version that is used by the system for
// testing to ensure no actual live payment is ever available"): the *live* wallet (real cards, QuickBooks Payments'
// production) and the *test* wallet (cards saved in QuickBooks' sandbox, env 'sandbox'). Whenever the system is
// testing (a test account, domains' test mode, the staging copy, a test account signed in, or payments switched to
// Sandbox) only the test wallet is seen, saved to and charged; a live card is refused there, and a test card is only
// ever charged with QuickBooks forced to its sandbox (refused outright if that can't be). A test account has only a
// test wallet.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Wallet
{
    public const ITEMS = ['plan' => 'Plan', 'domain' => 'Domain renewals'];
    public const REMIND_DAYS = 30;

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM wallet_cards LIMIT 0'); $pdo->query('SELECT 1 FROM wallet_assignments LIMIT 0'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /** The processor's wallet id for an account (the same one plans have always used). */
    public static function walletId(string $type, int $id): string { return 'TRV-' . ($type === 'listing' ? 'L' : 'U') . $id; }

    /** May this person use and change the account's wallet? */
    public static function canManage(PDO $pdo, int $uid, string $type, int $id): bool
    {
        if ($uid <= 0) return false;
        if ($type === 'user') return $uid === $id;
        require_once __DIR__ . '/Billing.php';
        return Billing::canManage($pdo, $uid, 'listing', $id);
    }

    /**
     * The account's cards in one of its two wallets ($side 'live' | 'test'; null: the one in use now), default first:
     * each with `locked` (what renews on it) and `expiring`.
     */
    public static function cards(PDO $pdo, string $type, int $id, ?string $side = null): array
    {
        if (!self::ready($pdo)) return [];
        $side = $side ?? self::side($pdo, $type, $id);
        $st = $pdo->prepare('SELECT * FROM wallet_cards WHERE owner_type = ? AND owner_id = ? AND removed_at IS NULL ORDER BY is_default DESC, id DESC'); $st->execute([$type, $id]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $c) {
            if (self::isTest($c) !== ($side === 'test')) continue;   // the other wallet's
            $c['uses'] = self::uses($pdo, (int) $c['id']);
            $c['locked'] = (bool) $c['uses'];
            $c['expiring'] = self::expiresSoon((string) $c['exp']);
            $out[] = $c;
        }
        return $out;
    }

    /** One of the account's cards in the wallet in use now, or null (a card of the other wallet isn't found here). */
    public static function card(PDO $pdo, string $type, int $id, int $cardId): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM wallet_cards WHERE id = ? AND owner_type = ? AND owner_id = ? AND removed_at IS NULL'); $st->execute([$cardId, $type, $id]);
        $c = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        return $c && self::isTest($c) === (self::side($pdo, $type, $id) === 'test') ? $c : null;
    }

    /** Is it a test-wallet card (saved in QuickBooks' sandbox)? */
    public static function isTest(array $c): bool { return ($c['env'] ?? '') === 'sandbox'; }

    public static function defaultCard(PDO $pdo, string $type, int $id): ?array
    {
        return self::cards($pdo, $type, $id)[0] ?? null;
    }

    /**
     * What renews on a card: [[item_type, item_id, what it is], …]. Read as things stand, so a card unlocks by itself
     * once nothing renews on it: a plan ended or set to stop at its end, a domain with auto-renew off or gone.
     */
    public static function uses(PDO $pdo, int $cardId): array
    {
        $st = $pdo->prepare('SELECT item_type, item_id FROM wallet_assignments WHERE card_id = ? AND ended_at IS NULL ORDER BY id'); $st->execute([$cardId]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $a) {
            if (!self::renews($pdo, (string) $a['item_type'], (int) $a['item_id'])) continue;
            $out[] = [(string) $a['item_type'], (int) $a['item_id'], self::itemName($pdo, (string) $a['item_type'], (int) $a['item_id'])];
        }
        return $out;
    }

    /** Does this still renew? */
    private static function renews(PDO $pdo, string $type, int $id): bool
    {
        try {
            if ($type === 'plan') { $st = $pdo->prepare("SELECT 1 FROM subscriptions WHERE id = ? AND status <> 'ended' AND cancel_at_end = 0"); $st->execute([$id]); return (bool) $st->fetchColumn(); }
            if ($type === 'domain') { $st = $pdo->prepare("SELECT 1 FROM account_domains WHERE id = ? AND status = 'active' AND auto_renew = 1 AND source = 'bought'"); $st->execute([$id]); return (bool) $st->fetchColumn(); }
        } catch (Throwable) { return true; }   // unsure: kept locked, never removed by mistake
        return true;
    }

    private static function itemName(PDO $pdo, string $type, int $id): string
    {
        try {
            if ($type === 'plan') { require_once __DIR__ . '/Billing.php'; $s = Billing::get($pdo, $id); return (Billing::PLANS[$s['plan']][0] ?? 'Plan') . ' plan'; }
            if ($type === 'domain') { $st = $pdo->prepare('SELECT domain FROM account_domains WHERE id = ?'); $st->execute([$id]); return (string) ($st->fetchColumn() ?: 'A domain') . ' renewals'; }
        } catch (Throwable) {}
        return self::ITEMS[$type] ?? $type;
    }

    /** "YYYY-MM" within 30 days of its end (or past it). */
    public static function expiresSoon(string $exp): bool
    {
        if (!preg_match('/^(\d{4})-(\d{2})$/', $exp, $m)) return false;
        $end = strtotime(date('Y-m-t 23:59:59', mktime(0, 0, 0, (int) $m[2], 1, (int) $m[1])));
        return $end < strtotime('+' . self::REMIND_DAYS . ' days');
    }

    /**
     * Saves the card behind a one-time token into the account's wallet. Returns the card row. The first card is the
     * default; $default makes this one the default.
     */
    public static function add(PDO $pdo, int $uid, string $type, int $id, string $token, bool $default = false): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('The wallet is being set up. Try again in a few minutes.');
        if (!preg_match('/^[A-Za-z0-9_.:-]{6,300}$/', $token)) throw new RuntimeException('The card details didn\'t come through. Nothing was saved or charged. Try again.');
        require_once __DIR__ . '/QuickBooksPay.php';
        $wallet = self::walletId($type, $id);
        $saved = self::sandboxFor($pdo, $type, $id, fn () => QuickBooksPay::saveCard($pdo, $wallet, $token, 'card-' . $wallet . '-' . substr(hash('sha256', $token), 0, 10)));
        return self::adopt($pdo, $uid, $type, $id, (string) $saved[0], (string) $saved[1], (string) ($saved[2] ?? ''), $default);
    }

    /** A card the processor already holds for the account, put in its wallet (or the row it already has). */
    public static function adopt(PDO $pdo, int $uid, string $type, int $id, string $ref, string $label, string $exp = '', bool $default = false): array
    {
        if ($ref === '') throw new InvalidArgumentException('That card has no reference.');
        $st = $pdo->prepare("SELECT * FROM wallet_cards WHERE processor = 'quickbooks' AND card_ref = ?"); $st->execute([$ref]);
        $c = $st->fetch(PDO::FETCH_ASSOC);
        if ($c && ($c['owner_type'] !== $type || (int) $c['owner_id'] !== $id)) throw new RuntimeException('That card belongs to another account\'s wallet.');   // never mixed
        $first = !self::cards($pdo, $type, $id);
        if ($c) {
            if (self::isTest($c) !== (self::side($pdo, $type, $id) === 'test')) throw new RuntimeException('That card belongs to the account\'s other wallet (test and live never mix).');
            $pdo->prepare('UPDATE wallet_cards SET removed_at = NULL, label = IF(? <> \'\', ?, label), exp = IF(? <> \'\', ?, exp) WHERE id = ?')->execute([$label, $label, $exp, $exp, (int) $c['id']]);
            $cid = (int) $c['id'];
        } else {
            require_once __DIR__ . '/QuickBooksPay.php';
            $pdo->prepare("INSERT INTO wallet_cards (owner_type, owner_id, processor, env, wallet, card_ref, label, exp, is_default, added_by, created_at) VALUES (?, ?, 'quickbooks', ?, ?, ?, ?, ?, 0, ?, ?)")
                ->execute([$type, $id, self::side($pdo, $type, $id) === 'test' ? 'sandbox' : QuickBooksPay::env(), self::walletId($type, $id), $ref, mb_substr($label, 0, 60), $exp, $uid ?: null, self::now()]);
            $cid = (int) $pdo->lastInsertId();
        }
        if ($first || $default) self::setDefault($pdo, $type, $id, $cid);
        return self::card($pdo, $type, $id, $cid) ?: [];
    }

    /**
     * The card to pay with: 'wallet:<id>' picks a saved card; anything else is a one-time token, saved first. Returns
     * the card row.
     */
    public static function resolve(PDO $pdo, int $uid, string $type, int $id, string $pick): array
    {
        if (preg_match('/^wallet:(\d+)$/', $pick, $m)) {
            if (!self::canManage($pdo, $uid, $type, $id)) throw new RuntimeException('Only the owner, or someone they let handle billing, can use this wallet.');
            $c = self::card($pdo, $type, $id, (int) $m[1]);
            if (!$c) throw new RuntimeException('That card isn\'t in this account\'s wallet any more. Choose another, or add a card.');
            if (!self::usable($pdo, $c)) throw new RuntimeException(($c['env'] === 'sandbox' ? 'That\'s a test card: it pays only for tests.' : 'A test can\'t use a real card.') . ' Choose another, or add a card.');
            return $c;
        }
        return self::add($pdo, $uid, $type, $id, $pick);
    }

    public static function setDefault(PDO $pdo, string $type, int $id, int $cardId): void
    {
        if (!self::card($pdo, $type, $id, $cardId)) throw new InvalidArgumentException('That card isn\'t in this wallet.');
        $pdo->prepare("UPDATE wallet_cards SET is_default = IF(id = ?, 1, 0) WHERE owner_type = ? AND owner_id = ? AND removed_at IS NULL AND (env = 'sandbox') = ?")   // within this wallet only: each has its own default
            ->execute([$cardId, $type, $id, self::side($pdo, $type, $id) === 'test' ? 1 : 0]);
    }

    /** Removes a card, unless something renews on it (then it can only be replaced). */
    public static function remove(PDO $pdo, string $type, int $id, int $cardId): void
    {
        $c = self::card($pdo, $type, $id, $cardId);
        if (!$c) throw new InvalidArgumentException('That card isn\'t in this wallet.');
        if ($u = self::uses($pdo, $cardId)) throw new RuntimeException($c['label'] . ' pays for ' . implode(', ', array_column($u, 2)) . '. Replace it with another card instead: it can\'t be removed while something renews on it.');
        $pdo->prepare('UPDATE wallet_cards SET removed_at = ?, is_default = 0 WHERE id = ?')->execute([self::now(), $cardId]);
        if ((int) $c['is_default'] && ($next = self::defaultCard($pdo, $type, $id))) self::setDefault($pdo, $type, $id, (int) $next['id']);
    }

    // ---- assignments ------------------------------------------------------------------------------------------------

    /** The card assigned to something that renews, or null. */
    public static function assigned(PDO $pdo, string $itemType, int $itemId): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT c.* FROM wallet_assignments a JOIN wallet_cards c ON c.id = a.card_id WHERE a.item_type = ? AND a.item_id = ? AND a.ended_at IS NULL ORDER BY a.id DESC LIMIT 1');
        $st->execute([$itemType, $itemId]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Assigns a card to something that renews (its earlier card, if any, is released from it). */
    public static function assign(PDO $pdo, int $cardId, string $itemType, int $itemId): void
    {
        if (!self::ready($pdo)) return;
        $cur = self::assigned($pdo, $itemType, $itemId);
        if ($cur && (int) $cur['id'] === $cardId) return;
        self::release($pdo, $itemType, $itemId);
        $pdo->prepare('INSERT INTO wallet_assignments (card_id, item_type, item_id, created_at) VALUES (?, ?, ?, ?)')->execute([$cardId, $itemType, $itemId, self::now()]);
        if ($itemType === 'plan') self::toPlan($pdo, $itemId, $cardId);
    }

    /** Nothing renews on a card for this any more (cancelled, auto-renew off, transferred away). */
    public static function release(PDO $pdo, string $itemType, int $itemId): void
    {
        if (!self::ready($pdo)) return;
        $pdo->prepare('UPDATE wallet_assignments SET ended_at = ? WHERE item_type = ? AND item_id = ? AND ended_at IS NULL')->execute([self::now(), $itemType, $itemId]);
    }

    /**
     * Replaces a locked card: for one thing ($only = [item_type, item_id]) or for everything on it. $pick: a saved card
     * ('wallet:<id>') or a new card's token. A declined renewal waiting on the old card is tried on the new one at once.
     * Returns [the new card, the things moved].
     */
    public static function replace(PDO $pdo, int $uid, string $type, int $id, int $oldId, string $pick, ?array $only = null): array
    {
        if (!self::canManage($pdo, $uid, $type, $id)) throw new RuntimeException('Only the owner, or someone they let handle billing, can change these cards.');
        $old = self::card($pdo, $type, $id, $oldId);
        if (!$old) throw new InvalidArgumentException('That card isn\'t in this wallet.');
        $new = self::resolve($pdo, $uid, $type, $id, $pick);
        if ((int) $new['id'] === $oldId) throw new InvalidArgumentException('That\'s the same card. Choose another, or add a new one.');
        $moved = [];
        foreach (self::uses($pdo, $oldId) as [$it, $iid, $name]) {
            if ($only && ($only[0] !== $it || (int) $only[1] !== $iid)) continue;
            self::assign($pdo, (int) $new['id'], $it, $iid);
            $moved[] = $name;
            self::retryNow($pdo, $it, $iid);
        }
        return [$new, $moved];
    }

    /** A renewal declined on the old card is tried again at once on the new one. */
    private static function retryNow(PDO $pdo, string $itemType, int $itemId): void
    {
        try {
            if ($itemType === 'plan') {
                require_once __DIR__ . '/Billing.php';
                $s = Billing::get($pdo, $itemId);
                if ($s['status'] === 'past_due') Billing::renew($pdo, $s, true);
            } elseif ($itemType === 'domain') {
                require_once __DIR__ . '/AccountDomains.php';
                AccountDomains::retryRenewal($pdo, $itemId);
            }
        } catch (Throwable $x) { error_log('wallet retry ' . $itemType . ' ' . $itemId . ': ' . $x->getMessage()); }
    }

    /** A plan's card fields follow its assigned card (every reader of subscriptions.card_id keeps working). */
    private static function toPlan(PDO $pdo, int $sid, int $cardId): void
    {
        $st = $pdo->prepare('SELECT wallet, card_ref, label FROM wallet_cards WHERE id = ?'); $st->execute([$cardId]);
        if ($c = $st->fetch(PDO::FETCH_ASSOC)) $pdo->prepare('UPDATE subscriptions SET wallet = ?, card_id = ?, card_label = ? WHERE id = ?')->execute([$c['wallet'], $c['card_ref'], $c['label'], $sid]);
    }

    /** A business's owner changed: the plan's card comes off it, and the cards the previous owner added leave the wallet. */
    public static function handOver(PDO $pdo, int $listingId, int $sid, int $oldOwner): void
    {
        if (!self::ready($pdo)) return;
        self::release($pdo, 'plan', $sid);
        if ($oldOwner <= 0) return;
        $st = $pdo->prepare("SELECT id FROM wallet_cards WHERE owner_type = 'listing' AND owner_id = ? AND added_by = ? AND removed_at IS NULL"); $st->execute([$listingId, $oldOwner]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $cid) {
            $pdo->prepare('UPDATE wallet_assignments SET ended_at = ? WHERE card_id = ? AND ended_at IS NULL')->execute([self::now(), (int) $cid]);   // the old owner is never charged again for it
            $pdo->prepare('UPDATE wallet_cards SET removed_at = ?, is_default = 0 WHERE id = ?')->execute([self::now(), (int) $cid]);
        }
    }

    // ---- charging ---------------------------------------------------------------------------------------------------

    /**
     * Charges a wallet card (once per $key). Returns the charge id; throws on a decline (code 402) or no answer (503).
     * A test-wallet card is charged only in QuickBooks' sandbox (forced, and refused if it still reads production); a
     * live card is never charged while the system is testing.
     */
    public static function charge(PDO $pdo, array $card, int $cents, string $what, string $key): string
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $type = (string) $card['owner_type']; $id = (int) $card['owner_id'];
        if (self::isTest($card)) {
            $was = QuickBooksPay::forcedEnv();
            QuickBooksPay::useEnv('sandbox');
            try {
                if (QuickBooksPay::env() === 'production') throw new RuntimeException('A test card is charged only in QuickBooks\' sandbox, and it couldn\'t be reached that way. Nothing was charged.', 400);
                return QuickBooksPay::chargeSaved($pdo, (string) $card['card_ref'], $cents, $what, $key);
            } finally { QuickBooksPay::useEnv($was); }
        }
        if (self::side($pdo, $type, $id) === 'test') throw new RuntimeException('This is a test: it never charges a real card. Nothing was charged; use a card from the test wallet.', 400);
        return QuickBooksPay::chargeSaved($pdo, (string) $card['card_ref'], $cents, $what, $key);
    }

    /** Is the account a test account (its cards and charges live in the sandbox only, decisions/0145)? */
    public static function testOwner(PDO $pdo, string $type, int $id): bool
    {
        try {
            require_once __DIR__ . '/TestAccounts.php';
            if ($type === 'user') return TestAccounts::isTestUser($pdo, $id);
            require_once __DIR__ . '/Billing.php';
            $o = Billing::owner($pdo, 'listing', $id);
            return !empty($o['payer']) && TestAccounts::isTestUser($pdo, (int) $o['payer']);
        } catch (Throwable) { return false; }
    }

    private static bool $force = false;

    /** Runs $f with every card saved and charged in the sandbox (domains' test mode: no real money, decisions/0145). */
    public static function asSandbox(bool $on, callable $f)
    {
        $was = self::$force; self::$force = $on || $was;
        try { return $f(); } finally { self::$force = $was; }
    }

    /**
     * Which wallet is in use for the account now: 'test' whenever the system is testing (asSandbox, a test account, a
     * test account signed in or the staging copy, payments switched to Sandbox), else 'live'.
     */
    public static function side(PDO $pdo, string $type, int $id): string
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        if (self::$force || QuickBooksPay::testHere() || ($type !== '' && self::testOwner($pdo, $type, $id))) return 'test';
        return QuickBooksPay::env() === 'sandbox' ? 'test' : 'live';
    }

    /** Are this account's cards and charges in the sandbox right now? */
    public static function inSandbox(PDO $pdo, string $type, int $id): bool { return self::side($pdo, $type, $id) === 'test'; }

    /** Has the account a live wallet at all? Never a test account's, never on the staging copy. */
    public static function liveAllowed(PDO $pdo, string $type, int $id): bool
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        return !self::testOwner($pdo, $type, $id) && !QuickBooksPay::testHere();
    }

    /** May this card pay here? Only a card of the wallet in use now. */
    public static function usable(PDO $pdo, array $c): bool
    {
        return self::isTest($c) === (self::side($pdo, (string) $c['owner_type'], (int) $c['owner_id']) === 'test');
    }

    /** Runs a processor call in the sandbox for a test account (or while asSandbox is on). */
    public static function sandboxFor(PDO $pdo, string $type, int $id, callable $f)
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $test = self::$force || ($type !== '' && self::testOwner($pdo, $type, $id));   // (QuickBooksPay::env() reads sandbox by itself for a signed-in test account and on staging)
        $was = QuickBooksPay::forcedEnv();
        if ($test) QuickBooksPay::useEnv('sandbox');
        try { return $f(); } finally { if ($test) QuickBooksPay::useEnv($was); }
    }

    // ---- the reminder -----------------------------------------------------------------------------------------------

    /** Daily (from domains_tick): a locked card ending within 30 days is reminded once, with Replace card. Returns how many. */
    public static function tick(PDO $pdo): int
    {
        if (!self::ready($pdo)) return 0;
        $n = 0;
        $rows = $pdo->query("SELECT c.* FROM wallet_cards c WHERE c.removed_at IS NULL AND c.reminded_at IS NULL AND c.exp <> '' AND EXISTS (SELECT 1 FROM wallet_assignments a WHERE a.card_id = c.id AND a.ended_at IS NULL) LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $c) {
            if (!self::expiresSoon((string) $c['exp']) || !self::uses($pdo, (int) $c['id'])) continue;
            try {
                require_once __DIR__ . '/Billing.php'; require_once __DIR__ . '/Mailer.php';
                $o = Billing::owner($pdo, (string) $c['owner_type'], (int) $c['owner_id']);
                $uses = array_column(self::uses($pdo, (int) $c['id']), 2);
                if ($o['email'] !== '') Mailer::send($o['email'], 'Your card ' . $c['label'] . ' is about to expire',
                    "Hello,\n\n" . $c['label'] . ' in ' . ($c['owner_type'] === 'listing' ? $o['name'] . '\'s' : 'your') . ' Traversence wallet expires at the end of ' . date('F Y', strtotime($c['exp'] . '-01'))
                    . ". It pays for: " . implode(', ', $uses) . ".\n\nReplace it before then so nothing stops renewing:\n" . self::link((string) $c['owner_type'], (int) $c['owner_id'])
                    . "\n\nQuestions, or a link that doesn't work: write to support@traversence.com.\n");
                $pdo->prepare('UPDATE wallet_cards SET reminded_at = ? WHERE id = ?')->execute([self::now(), (int) $c['id']]);
                $n++;
            } catch (Throwable $x) { error_log('wallet remind ' . $c['id'] . ': ' . $x->getMessage()); }
        }
        return $n;
    }

    /** Where the account's wallet is managed (its Domains tab shows it; so does the Plans page's card). */
    public static function link(string $type, int $id): string
    {
        $base = rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/');
        return $type === 'listing' ? $base . '/business/' . $id . '/domains#wallet' : $base . '/user/domains/#wallet';
    }

    /** For the page: a card as the account sees it. */
    public static function shape(array $c): array
    {
        return ['id' => (int) $c['id'], 'label' => (string) $c['label'], 'exp' => (string) $c['exp'], 'default' => (bool) (int) $c['is_default'], 'locked' => !empty($c['locked']),
            'uses' => array_column((array) ($c['uses'] ?? []), 2), 'expiring' => !empty($c['expiring']), 'test' => self::isTest($c)];
    }
}
