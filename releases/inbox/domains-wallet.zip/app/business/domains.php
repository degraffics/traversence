<?php
// app/business/domains.php — the business portal's Domains (decisions/0169 §1a): the business's own domains (bought in
// Shop → Domains, or owned elsewhere and listed for pointing only), its storefront's domain read only, and its wallet
// (decisions/0166 §6a). Drawn by the shared view (app/ui/domains-view.php). Seeing it: Domain (view); changing: Domain
// (edit); paying and the wallet: Plan & billing (edit) too.
declare(strict_types=1);

require_once __DIR__ . '/../ui/go-codes.php';
require_once __DIR__ . '/../ui/domains-view.php';

function tv_biz_domains(PDO $main, array $ctx, int $uid): string
{
    ob_start(); tv_go_head('', false); $head = (string) ob_get_clean();
    return $head . '<div class="go"><p class="go-lead">' . htmlspecialchars((string) $ctx['name'], ENT_QUOTES) . '\'s domains: renew them, point them where you like, or move them away. Find a new one in the Shop.</p>'
        . tv_domains_view('listing', (int) $ctx['id'], 'tab') . '</div>';
}
