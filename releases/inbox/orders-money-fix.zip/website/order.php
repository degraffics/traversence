<?php
// /order.php?t=… — a client's order, built for them by our team (decisions/0101), on its private link (emailed; no
// account needed). They review what's in it, approve each proof or ask for changes, approve the order with their name
// and billing address (the invoice and sales tax are made then), and pay by card here: all of it, or the deposit and
// later the rest (an older order on invoice-later terms pays its invoice the same way). Afterwards: the receipt, GO Codes to download, and
// where the printed items are (in production, sent to print, shipped or ready for pickup).
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/ClientOrders.php';
require_once __DIR__ . '/../app/lib/QrIssue.php';
require_once __DIR__ . '/../app/lib/QuickBooksPay.php';
require_once __DIR__ . '/../app/lib/Promotions.php';
require_once __DIR__ . '/../app/ui/page-shell.php';
require_once __DIR__ . '/../app/ui/go-codes.php';
tv_card_page_csp('order', ['quickbooks', 'pdfjs']);   // a card page: only our scripts and Intuit's (0098; its script list there)
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');

$pdo = Database::connection();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$usd = fn ($c) => Orders::usd((int) $c);
$tok = (string) ($_GET['t'] ?? $_POST['t'] ?? '');
$o = Products::ready($pdo) ? ClientOrders::byToken($pdo, $tok) : null;
if ($o && $o['status'] === 'draft') $o = null;   // not sent yet
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$err = ''; $ok = '';
$staffView = $o && ClientOrders::staffView($pdo, $o);   // our team on a real order: look, don't act (Jason, 2026-10-28)

// the page, once it's showing, tells us the client opened it (a mail scanner fetching the link doesn't run it; our team doesn't count)
if ($o && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'seen') {
    if (hash_equals($csrf, (string) ($_POST['csrf'] ?? '')) && !QuickBooksPay::staffHere($pdo)) { try { ClientOrders::seen($pdo, $o); } catch (Throwable $ex) { error_log('order seen: ' . $ex->getMessage()); } }
    http_response_code(204); exit;
}
if ($o && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        if ($staffView) throw new RuntimeException(ClientOrders::STAFF_VIEW_MSG);
        switch ((string) ($_POST['do'] ?? '')) {
            case 'proof_ok': ClientOrders::decideProof($pdo, $o, (int) ($_POST['proof'] ?? 0), true, '', ['checks' => (array) ($_POST['check'] ?? []), 'initials' => (string) ($_POST['initials'] ?? '')]); $ok = 'Proof approved.'; break;
            case 'proof_change': ClientOrders::decideProof($pdo, $o, (int) ($_POST['proof'] ?? 0), false, (string) ($_POST['note'] ?? '')); $ok = 'Sent to us. We\'ll make the changes and send you a new proof.'; break;
            case 'promo': ClientOrders::setPromo($pdo, (int) $o['id'], (string) ($_POST['code'] ?? '')); $ok = trim((string) ($_POST['code'] ?? '')) === '' ? 'Code taken off.' : 'Code applied.'; break;
            case 'approve':
                if (empty($_POST['agree'])) throw new RuntimeException('Tick the box to approve the order as shown.');
                ClientOrders::approve($pdo, $o, (string) ($_POST['name'] ?? ''), $_POST);
                ClientOrders::setNotify($pdo, $o, !empty($_POST['notify']));
                $ok = 'Approved. Thank you!'; break;
            case 'pay_method': ClientOrders::choosePay($pdo, $o, (string) ($_POST['method'] ?? ''), (string) ($_POST['ref'] ?? '')); $ok = ($_POST['method'] ?? '') === 'card' ? '' : 'The details are below, and in your email.'; break;
            case 'pay_report': ClientOrders::reportPay($pdo, $o, (string) ($_POST['ref'] ?? '')); $ok = ''; $toThanks = true; break;
            case 'wire_code': ClientOrders::wireSendCode($pdo, $o); $ok = 'We emailed you a code: enter it below to see our wire details.'; break;
            case 'wire_hide': unset($_SESSION['tv_wire_ok'][(int) $o['id']]); $ok = ''; break;
            case 'wire_show': ClientOrders::wireCheckCode($pdo, $o, (string) ($_POST['code'] ?? '')); $ok = ''; break;
            case 'notify': ClientOrders::setNotify($pdo, $o, !empty($_POST['notify'])); $ok = !empty($_POST['notify']) ? 'We\'ll email you as your order moves along.' : 'No more progress emails. Your receipts still come.'; break;
            // done (Jason, 2026-10-30): they have it (that completes the order), how it went, a problem, a reorder
            case 'received': ClientOrders::confirmReceived($pdo, $o, (int) ($_POST['rating'] ?? 0), (string) ($_POST['words'] ?? ''), !empty($_POST['quote'])); $ok = 'Thank you! Your order is complete.'; $to = '#reorder'; break;
            case 'review': ClientOrders::review($pdo, $o, (int) ($_POST['rating'] ?? 0), (string) ($_POST['words'] ?? ''), !empty($_POST['quote'])); $ok = 'Thank you for telling us.'; $to = '#feedback'; break;
            case 'problem': $tk = ClientOrders::problem($pdo, $o, (string) ($_POST['words'] ?? '')); $ok = 'We have it' . ($tk ? ' (ticket #' . $tk . ')' : '') . ', and we\'ll be in touch to put it right.'; $to = '#got-it'; break;
            case 'reorder':
                require_once __DIR__ . '/../app/lib/Collateral.php';
                if (($o['stage'] ?? '') !== 'complete') throw new RuntimeException('You can reorder once this order is complete.');
                $mine = Collateral::onOrder($pdo, (int) $o['id']); $want = [];
                foreach ((array) ($_POST['pick'] ?? []) as $cid) { $cid = (int) $cid; if (!isset($mine[$cid])) continue; $n = (int) preg_replace('/\D/', '', (string) ($_POST['qty'][$cid] ?? '')); $want[$cid] = $n ?: (int) $mine[$cid][0]['qty']; }
                $meR = Auth::currentUser();
                Collateral::askReorder($pdo, $want, !empty($_POST['changes']), (string) ($_POST['note'] ?? ''), (string) $o['bill_name'] . ' (' . $o['bill_email'] . ')', $meR ? (int) $meR['id'] : ((int) ($o['user_id'] ?? 0) ?: null));
                $ok = 'We have your reorder. We\'ll send you the order, at today\'s prices, to look over and approve' . (empty($_POST['changes']) ? '' : ', with a new proof for your changes') . '.'; $to = '#reorder'; break;
        }
        $_SESSION['tv_co_flash'] = ['ok', $ok];
    } catch (Throwable $ex) {
        if (!($ex instanceof RuntimeException) || $ex instanceof PDOException) error_log('order page: ' . $ex->getMessage());
        $_SESSION['tv_co_flash'] = ['err', $ex instanceof RuntimeException && !($ex instanceof PDOException) ? $ex->getMessage() : 'Something went wrong. Try again.'];
    }
    if (!empty($toThanks)) { header('Location: /order.php?t=' . rawurlencode($tok) . '#thanks', true, 303); exit; }
    if (in_array($_POST['do'] ?? '', ['received', 'review', 'problem', 'reorder'], true)) { header('Location: /order.php?t=' . rawurlencode($tok) . ($to ?? '#' . ($_POST['do'] === 'reorder' ? 'reorder' : 'got-it')), true, 303); exit; }
    header('Location: /order.php?t=' . rawurlencode($tok) . (in_array($_POST['do'] ?? '', ['approve', 'pay_method', 'pay_report', 'notify', 'wire_code', 'wire_show', 'wire_hide'], true) ? '#pay' : ''), true, 303); exit;
}
if (isset($_SESSION['tv_co_flash'])) { [$k, $m] = $_SESSION['tv_co_flash']; unset($_SESSION['tv_co_flash']); if ($k === 'ok') $ok = $m; else $err = $m; }

tv_page_start($o ? 'Your order #' . Orders::no($o) : 'Your order', ['no_crumbs' => true, 'footer' => 'checkout', 'description' => 'Review, approve and pay your Traversence order.']);
tv_go_head('', false);
if (!$o): ?>
<div class="go"><section class="go-card tv-bleed"><h1>This link doesn't work</h1><p class="go-note">Check you opened the whole link from our email, or write to support@traversence.com.</p></section></div>
<?php tv_page_end(); return; endif;

QrIssue::allowOrder((int) $o['id']);   // its GO Codes download from this page
$oid = (int) $o['id'];
$lines = ClientOrders::lines($pdo, $oid);
foreach ($lines as &$rl) {   // retired files (a concept or version our team took back) aren't the client's to see or open
    $keep = fn (array $fs) => array_values(array_filter($fs, fn ($f) => empty($f['retired_at'])));
    $rl['proof_files'] = $keep((array) $rl['proof_files']); $rl['finals'] = $keep((array) $rl['finals']);
    foreach ($rl['versions'] as $vv => $vf) { $vf = $keep($vf); if ($vf) $rl['versions'][$vv] = $vf; else unset($rl['versions'][$vv]); }
    if ($rl['proof'] && !empty($rl['proof']['retired_at']) && !$rl['proof_files']) $rl['proof'] = null;   // its whole version retired: no proof to show
}
unset($rl);
$groups = ClientOrders::groups($lines, ClientOrders::projects($pdo, $oid));   // projects: each item's price, the project's subtotal (never a bundle's lines)
$released = ClientOrders::released($pdo, $o, $lines);   // approved files, once paid in full
$m = Orders::money($pdo, $oid);
$due = ClientOrders::dueNow($pdo, $o);
$expired = ClientOrders::expired($o);
$review = $o['status'] === 'sent' && !$expired;
$hasShip = ClientOrders::hasShip($pdo); $addrs = ClientOrders::addresses($pdo, $oid); $ship = ClientOrders::shipping($pdo, $o);
$outside = $o['pay_mode'] === 'outside';   // paid to us directly, recorded by our team (no card form here)
$delivery = ClientOrders::delivery($o, $lines);
if ($delivery === 'ship' && !ClientOrders::needsClientAddress($lines)) $delivery = 'items';   // every item goes to a set address or is picked up: nothing to ask
$waiting = $review ? (int) $pdo->query("SELECT COUNT(*) FROM order_proofs WHERE order_id = $oid AND status IN ('waiting', 'changes')")->fetchColumn() : 0;
$codes = array_values(array_filter($lines, fn ($l) => $l['code'] && QrIssue::owned($l['code'])));
$print = array_filter($lines, fn ($l) => $l['product'] !== 'go_code');
$hid = '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="t" value="' . $e($tok) . '">';
$steps = ['production' => 'In production', 'ordered' => 'Sent to print', 'shipped' => 'Shipped', 'complete' => 'Complete'];
if ($o['stage'] === 'ready') $steps = ['production' => 'In production', 'ordered' => 'Sent to print', 'ready' => 'Ready for pickup', 'complete' => 'Complete'];
?>
<style>
  .co-ihead{display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;border-bottom:2px solid #3E2B1F;padding-bottom:.5rem;margin-bottom:.8rem}
  .co-ihead h1{margin:0;font:700 clamp(1.6rem,4vw,2.2rem) system-ui,sans-serif;letter-spacing:.04em;color:#6B5640;text-transform:uppercase}
  .co-brand{display:block;font:700 clamp(1.6rem,4vw,2.2rem) var(--tv-font-head,Georgia,serif);color:#3E2B1F}.co-ihead small{color:#6B5640;display:block;font-size:.85rem}
  .co-inv{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:.6rem;margin-bottom:.8rem}
  .co-box{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.5rem;padding:.7rem .85rem;line-height:1.45;overflow-wrap:anywhere;font-size:.95rem}
  .co-box h3{margin:0 0 .3rem;font:700 .76rem system-ui,sans-serif;letter-spacing:.07em;text-transform:uppercase;color:#8A7355}
  .co-box dl{display:grid;grid-template-columns:auto 1fr;gap:.15rem .7rem;margin:0}.co-box dt{color:#8A7355}.co-box dd{margin:0;text-align:right;font-weight:700}
  .co-ist{display:inline-block;margin-top:.3rem;font:600 .78rem system-ui,sans-serif;background:#E7F1EC;color:#1F5C43;border-radius:999px;padding:.12rem .55rem}
  .co-shr{display:block;font-size:.8rem;color:#8A7355;font-weight:400}
  @media (max-width:767px){.co-inv{grid-template-columns:1fr}}
  .co-ship{border:1px solid #EADFC4;border-radius:.6rem;padding:.6rem .7rem;margin:.7rem 0 0}.co-ship legend{font-weight:700;padding:0 .3rem}.co-ship [hidden]{display:none!important}
  .co-pv{margin-top:.5rem;width:100%;display:flex;flex-direction:column;align-items:center;gap:.6rem;padding:.7rem;background:#fff;border:1px solid #EADFC4;border-radius:.5rem;cursor:pointer;font:inherit}
  .co-pvs{display:grid;grid-template-columns:repeat(auto-fill,minmax(9rem,1fr));gap:.4rem}.co-pvs .co-pv{margin-top:.3rem}.co-pvs .co-pv img{max-height:9rem;object-fit:contain}
  .co-reuse{display:flex;flex-wrap:wrap;gap:.4rem .7rem;align-items:center;margin-top:.5rem}
  .co-pv img{display:block;max-width:100%;max-height:11rem;width:auto;height:auto}
  .co-pv .pdf{display:flex;align-items:center;justify-content:center;width:5rem;height:6.4rem;border:2px solid #CBB98D;border-radius:.3rem;font:700 .9rem system-ui,sans-serif;color:#92400E;background:#FFFBF2}
  .co-acts{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.5rem}
  .co-st{display:inline-block;border-radius:999px;padding:.1rem .55rem;font-size:.75rem;font-weight:700;background:#FEF3C7;color:#7C2D12}.co-st.ok{background:#DCFCE7;color:#14532D}.co-st.no{background:#FEE2E2;color:#991B1B}
  .co-ln{border-top:1px solid #EADFC4;padding:.75rem 0}.co-ln:first-child{border-top:0;padding-top:0}
  .co-prj{border:1px solid #E3D3AC;border-radius:.6rem;padding:.6rem .75rem;margin:.6rem 0;background:#FFFDF7}.co-prj>h3{font:700 1.05rem var(--tv-font-head,Georgia,serif);margin:0 0 .4rem;color:#3E2B1F}
  .co-prj .co-ln:first-of-type{border-top:0;padding-top:0}.co-psub{display:flex;justify-content:space-between;border-top:1px solid #E3D3AC;padding-top:.45rem;margin-top:.2rem;font-weight:700}
  .co-rel{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.4rem}@media (max-width:767px){.co-prj{padding:.5rem}}
  .co-ln .hd{display:flex;justify-content:space-between;gap:.6rem}.co-ln .hd b{font-size:1rem}
  .co-amt{white-space:nowrap;font-weight:700;text-align:right}.co-amt s{display:block;color:#8A7355;font-weight:400;font-size:.78rem}
  .co-sign{position:fixed;inset:0;z-index:2100;background:rgba(18,11,6,.78);display:flex;align-items:center;justify-content:center;padding:12px 0}.co-sign[hidden]{display:none}
  .co-sign-box{position:relative;width:min(40rem,calc(100% - 24px));max-height:100%;overflow-y:auto;box-sizing:border-box;background:#FFFBF2;color:#3E2B1F;border-radius:.8rem;padding:1rem 1.1rem;box-shadow:0 24px 60px -18px rgba(0,0,0,.8);margin:0}
  .co-sign-x{position:absolute;top:.55rem;right:.55rem;width:36px;height:36px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;font-size:1.35rem;line-height:1;cursor:pointer}.co-sign-x:hover{background:#8FBCA8;color:#1F3A2E}
  .co-sign-box h2{padding-right:2.6rem;margin:0 0 .5rem;font:700 1.15rem var(--tv-font-head,Georgia,serif)}.co-sign-box h2 span{font-weight:400}
  .co-sign-terms{margin:0 0 .6rem;padding-left:1.1rem;display:grid;gap:.4rem;font-size:.92rem;line-height:1.45}
  .co-sign-dl{margin:.2rem 0 .6rem;font-size:.92rem}.co-sign-dl a{color:#92400E;font-weight:600}
  .co-sign-chk{display:flex!important;gap:.5rem;align-items:flex-start;font-weight:400!important;margin:.35rem 0;font-size:.95rem}.co-sign-chk input{width:1.1rem;height:1.1rem;flex:none;margin-top:.15rem;accent-color:#92400E}
  .co-sign-ini{display:block;font-weight:700;margin:.6rem 0 .2rem}.co-sign-box #sg-ini{border:1px solid #CBB98D;border-radius:.5rem;padding:.4rem .6rem;background:#fff;width:9rem;text-transform:uppercase;letter-spacing:.08em;font-size:1.05rem}
  .co-sign-acts{display:flex;flex-wrap:wrap;gap:.5rem;justify-content:flex-end;margin-top:.8rem}
  .co-thanks{border:2px solid #8FBCA8;background:#F1F7F3}.co-thanks h2{font:700 1.35rem var(--tv-font-head,Georgia,serif);margin:0 0 .3rem}
  .co-rate,.co-prob form,.co-reo{display:grid;gap:.55rem;margin-top:.5rem}.co-rate label,.co-prob label,.co-reo label{display:grid;gap:.2rem;font-weight:600;font-size:.92rem}
  .co-in{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.5rem;padding:.5rem .6rem;font:inherit;background:#fff}
  .co-rate label.co-chk,.co-reo label.co-chk{display:flex;gap:.45rem;align-items:flex-start;font-weight:400}.co-chk input{width:auto;margin-top:.2rem}
  .co-stars{border:0;padding:0;margin:0}.co-stars legend{font-weight:600;font-size:.92rem;padding:0;margin-bottom:.2rem}
  .co-stars div{display:inline-flex;flex-direction:row-reverse;gap:.15rem}.co-stars input{position:absolute;opacity:0;width:1px;height:1px}
  .co-stars label{color:#FFFBF2;cursor:pointer;display:block;line-height:0}.co-stars label:hover,.co-stars label:hover~label,.co-stars input:checked~label{color:#F59E0B}
  .co-stars input:focus-visible+label{outline:2px solid #92400E;outline-offset:2px;border-radius:4px}
  .co-prob{margin-top:.7rem}.co-prob summary{cursor:pointer;color:#92400E;font-weight:600}
  .co-reo-i{display:flex;justify-content:space-between;align-items:flex-end;gap:.6rem;border-bottom:1px solid #EADFC4;padding-bottom:.45rem}.co-reo-q{max-width:7.5rem}
  .co-flow{display:flex;flex-wrap:wrap;gap:.3rem;list-style:none;padding:0;margin:.6rem 0}.co-flow li{font-size:.82rem;font-weight:700;border-radius:999px;padding:.2rem .65rem;background:#FFFBF2;border:1px solid #CBB98D;color:#8A7355}
  .co-flow li.done{background:#DCFCE7;border-color:#8FBCA8;color:#14532D}.co-flow li.done::before{content:"✓ "}.co-flow li.on{background:#FEF3C7;border-color:#F59E0B;color:#7C2D12}
  .co-ty-acts{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.4rem}
  .co-paymore>summary{cursor:pointer;color:#92400E;font-weight:600;margin:.2rem 0 .4rem}
  .co-wire-safe{background:#F1F7F3;border:1px solid #8FBCA8;border-radius:.6rem;padding:.5rem .7rem;margin:.4rem 0 .6rem;font-size:.92rem}
  .co-wire{position:relative;margin:.4rem 0 0;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;border:1px solid #CBB98D;border-radius:.6rem;overflow:hidden;background:#FFFBF2}
  .co-wire img{display:block;width:100%;height:auto;pointer-events:none;-webkit-user-drag:none}
  .co-wire-cover{display:none;position:absolute;inset:0;align-items:center;justify-content:center;text-align:center;padding:1rem;background:#3E2B1F;color:#FFF8EA;font-weight:600;cursor:pointer}
  .co-wire.off img{filter:blur(18px)}.co-wire.off .co-wire-cover{display:flex}
  .co-wire-ask{display:grid;gap:.5rem;margin:.3rem 0}.co-wire-ask form{margin:0}.co-wire-code input{max-width:11rem;letter-spacing:.2em;font-size:1.1rem}
  .co-wire-warn{background:#FEF3C7;border:1px solid #F59E0B;border-radius:.6rem;padding:.5rem .7rem}
  @media print{.co-wire,.co-wire-safe,.co-howbox{display:none!important}body::after{content:"Our wire details aren't printed. See them on your order page.";display:block;padding:1rem;font:600 14px system-ui,sans-serif}}
  .co-ways{display:flex;gap:.4rem;flex-wrap:wrap;margin:.2rem 0 .7rem}.co-ways form{margin:0}
  .co-howbox{background:#FFFBF2;border:1px dashed #CBB98D;border-radius:.6rem;padding:.6rem .8rem;margin:.4rem 0 .6rem;font-size:.95rem;line-height:1.5;overflow-wrap:anywhere}
  .co-steps{display:flex;gap:.3rem;flex-wrap:wrap;list-style:none;padding:0;margin:.4rem 0}
  .co-steps li{flex:1 1 6rem;text-align:center;font-size:.76rem;padding:.4rem .3rem;border-radius:.5rem;background:#FFFBF2;border:1px solid #EADFC4;color:#8A7355}
  .co-steps li.on{background:#8FBCA8;border-color:#6E9F8A;color:#1F3A2E;font-weight:700;box-shadow:0 0 0 3px rgba(143,188,168,.3)}.co-steps li.done{color:#1F3A2E;background:#E7F3EC}
  .co-msg{border-radius:.6rem;padding:.55rem .7rem;margin:0 0 .7rem;font-size:.9rem}.co-msg.ok{background:#DCFCE7}.co-msg.err{background:#FEE2E2}
</style>
<div class="go">
  <div class="co-ihead"><div><b class="co-brand">Traversence</b><small><?= $e(implode(' · ', ClientOrders::FROM)) ?></small></div><h1><?= $o['approved_at'] ? 'Invoice' : 'Order' ?></h1></div>
  <?php $shipTxt = ClientOrders::shipToText($o); ?>
  <div class="co-inv">
    <div class="co-box"><h3>Bill to</h3><b><?= $e($o['client_company'] !== '' ? $o['client_company'] : $o['bill_name']) ?></b><?= $o['client_company'] !== '' ? '<br>' . $e($o['bill_name']) : '' ?><?= ($o['bill_street'] ?? '') !== '' ? '<br>' . $e($o['bill_street']) . '<br>' . $e(trim($o['bill_city'] . ', ' . $o['bill_state'] . ' ' . $o['bill_zip'], ', ')) : '' ?><?= $o['client_phone'] !== '' ? '<br>' . $e($o['client_phone']) : '' ?><br><?= $e($o['bill_email']) ?></div>
    <?php require_once __DIR__ . '/../app/lib/Shipments.php'; $smode = Shipments::ready($pdo) ? Shipments::mode($o) : ''; ?>
    <?php if ($smode === 'none'): ?><div class="co-box"><h3>Delivery</h3><?= $e(Shipments::REASONS[$o['no_ship_reason'] ?? 'none'] ?? 'None') ?><?= ($o['no_ship_reason'] ?? '') === 'will_call' ? '<br><span class="go-note">We\'ll let you know when it\'s ready to pick up.</span>' : '' ?></div>
    <?php elseif ($smode === 'multi'): $dd = Shipments::destinations($pdo, $o); $lb = Shipments::lots($pdo, $oid); $ttl = array_column($lines, 'title', 'id'); ?>
    <div class="co-box"><h3>Ships to <?= count($dd) ?> places</h3><?php foreach ($dd as $did => $d): $its = []; foreach ($lb as $lid => $ls) foreach ($ls as $lt) if ((int) $lt['dest_id'] === $did) $its[] = ($ttl[$lid] ?? '') . ($lt['label'] !== '' ? ' (' . $lt['label'] . ')' : '') . ' × ' . (int) $lt['qty']; ?>
      <p style="margin:.3rem 0"><b><?= $e($d['label']) ?></b><?= $d['text'] !== '' ? ': ' . $e($d['text']) : '' ?><?= $its ? '<br><span class="go-note">' . $e(implode('; ', $its)) . '</span>' : '' ?></p><?php endforeach; ?></div>
    <?php else: ?>
    <div class="co-box"><h3>Ship to</h3><?php if (($o['ship_street'] ?? '') !== ''): ?><b><?= $e($o['ship_name'] ?: $o['bill_name']) ?></b><br><?= $e($o['ship_street']) ?><br><?= $e(trim($o['ship_city'] . ', ' . $o['ship_state'] . ' ' . $o['ship_zip'], ', ')) ?><?php else: ?><span class="go-note"><?= $smode === 'single' ? 'Your address, from the approval' : 'Each item below says where it ships' ?><?= $review ? ', or give your address when you approve' : '' ?>.</span><?php endif; ?></div>
    <?php endif; ?>
    <div class="co-box"><h3><?= $o['approved_at'] ? 'Invoice' : 'Order' ?> details</h3><dl><dt>Number</dt><dd><?= $e(ClientOrders::ref($o)) ?></dd><dt>Date</dt><dd><?= $e(date('M j, Y', strtotime((string) ($o['sent_at'] ?: $o['created_at'])))) ?></dd><?php if ($o['approved_at']): ?><dt>Due</dt><dd><?= $e(ClientOrders::dueDate($o)) ?></dd><?php endif; ?><?php if (($o['po_number'] ?? '') !== ''): ?><dt>P.O. #</dt><dd><?= $e($o['po_number']) ?></dd><?php endif; ?></dl></div>
  </div>
  <?php if ($ok !== ''): ?><p class="co-msg ok" role="status" data-tv-flash="ok"><?= $e($ok) ?></p><?php endif; ?>
  <?php if ($err !== ''): ?><p class="co-msg err" role="alert" data-tv-flash="error"><?= $e($err) ?></p><?php endif; ?>
  <?php if (($o['qb_env'] ?? '') === 'sandbox'): ?><div class="go-banner warm"><b>Test order</b> (QuickBooks sandbox): no real money moves.</div><?php endif; ?>
  <?php if ($staffView): ?><div class="go-banner warm co-ro" role="note"><b>Viewing as the client (read only).</b> This is a real order, so approving, paying and changes are turned off for you here; the client's link works as normal. To act for them, <a href="/admin/backoffice/orders/<?= (int) $o['id'] ?>">open the order in Back-Office</a> (Approve for the client, Confirm received). Sandbox test orders work all the way through.</div><?php endif; ?>
  <?php $placed = ClientOrders::placed($o); if ($placed):   // the client has done their part: thank them, and point to their account (Jason, 2026-10-28)
    $meU = Auth::currentUser(); $mineU = $meU && ((int) ($o['user_id'] ?? 0) === (int) $meU['id'] || strcasecmp((string) $meU['email'], (string) $o['bill_email']) === 0);
    $paidUp = in_array($o['status'], ['paid', 'part_refunded'], true); $pmT = (string) ($o['pay_method'] ?? ''); $first = trim((string) strtok(preg_replace('/^TEST · /u', '', (string) $o['bill_name']), ' '));
    $next = '/user/orders.php'; $coName = trim((string) $o['client_company']); $bizNext = '/claim.php?new=1&order=' . $tok; ?>
  <section class="go-card tv-bleed co-thanks" id="thanks" aria-labelledby="ty-h">
    <h2 id="ty-h">Thank you<?= $first !== '' ? ', ' . $e($first) : '' ?>: order #<?= $e(Orders::no($o)) ?> is <?= $paidUp ? 'paid' : 'placed' ?>.</h2>
    <p class="go-note" style="font-size:1rem"><?php if ($paidUp): ?>We received <?= $usd($m['paid']) ?><?= $o['paid_at'] ? ' on ' . $e(date('F j', strtotime((string) $o['paid_at']))) : '' ?>.<?= $print ? ' Your order is in production.' : '' ?>
      <?php elseif ($pmT === 'cash'): ?>Your order is held until we receive your payment of <?= $usd($due) ?>; then it goes to production.
      <?php else: ?>We'll email you as soon as your <?= $e(strtolower(ClientOrders::CLIENT_METHODS[$pmT] ?? 'payment')) ?> of <?= $usd($due) ?> arrives (your reference: <?= $e($o['pay_report']) ?>). Your order goes to production then.<?php endif; ?></p>
    <ol class="co-flow"><li class="done">Proofs approved</li><li class="done">Order approved</li><li class="<?= $paidUp ? 'done' : 'on' ?>"><?= $paidUp ? 'Paid' : 'Payment on its way' ?></li><li class="<?= $paidUp && $print ? 'on' : '' ?>"><?= $print ? 'In production' : 'Ready' ?></li><?php if ($print): ?><li><?= $delivery === 'pickup' ? 'Ready for pickup' : 'Shipped' ?></li><?php endif; ?></ol>
    <div class="co-ty-acts">
      <?php if ($mineU): ?><a class="go-btn main" href="<?= $e($next) ?>">See all your orders</a>
      <?php elseif (!$meU && (int) ($o['user_id'] ?? 0) > 0): ?><a class="go-btn main" href="/login.php?next=<?= $e(rawurlencode($next)) ?>">Sign in to see all your orders</a>
      <?php elseif (!$meU): ?><a class="go-btn main" href="/register.php?email=<?= $e(rawurlencode((string) $o['bill_email'])) ?>&amp;next=<?= $e(rawurlencode($next)) ?>">Create your free account</a>
        <a class="go-btn" href="/login.php?next=<?= $e(rawurlencode($next)) ?>">I have an account: sign in</a><?php endif; ?>
      <?php if ($coName !== '' && (!$meU || $mineU)): ?><a class="go-btn" href="<?= $e($meU ? $bizNext : '/register.php?email=' . rawurlencode((string) $o['bill_email']) . '&next=' . rawurlencode($bizNext)) ?>">Put <?= $e($coName) ?> on Traversence</a><?php endif; ?>
    </div>
    <?php if (!$meU): ?><p class="go-note" style="margin-top:.5rem">With a free account (use <?= $e($o['bill_email']) ?>), every order, proof and released file is in one place<?= $coName !== '' ? ', and you can put ' . $e($coName) . ' on Traversence in the same step: one account for you, your business on it' : '' ?>.</p><?php endif; ?>
  </section>
  <?php endif; ?>
  <?php
  // done (Jason, 2026-10-30): once all of it is on its way, the client tells us they have it (that completes the order) and
  // how it went; after, a thank-you, their stars and words if not given yet, and a reorder at today's prices
  $fb = ClientOrders::feedback($pdo, $oid); $done = ($o['stage'] ?? '') === 'complete';
  $reviewed = (bool) array_filter($fb, fn ($f) => $f['kind'] === 'review' && ($f['rating'] || trim((string) $f['words']) !== ''));
  $openProblem = (bool) array_filter($fb, fn ($f) => $f['kind'] === 'problem' && $f['resolved_at'] === null);
  $star = '<svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true"><path d="M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2l-5.7 3.1 1.2-6.4L2.8 9.5l6.4-.8z" fill="currentColor" stroke="#92400E" stroke-width="1.2" stroke-linejoin="round"/></svg>';
  $rate = function (string $do, string $yes) use ($hid, $star, $e): string {
      $h = '<form method="post" class="co-rate">' . $hid . '<input type="hidden" name="do" value="' . $do . '"><fieldset class="co-stars"><legend>How did we do?' . ($do === 'received' ? ' (optional)' : '') . '</legend><div>';
      for ($i = 5; $i >= 1; $i--) $h .= '<input type="radio" name="rating" value="' . $i . '" id="st-' . $do . $i . '"><label for="st-' . $do . $i . '" title="' . $i . ' of 5" aria-label="' . $i . ' of 5">' . $star . '</label>';
      return $h . '</div></fieldset><label>Anything to tell us?<textarea class="co-in" name="words" rows="3" maxlength="2000" placeholder="What you liked, what we could do better"></textarea></label>'
          . '<label class="co-chk"><input type="checkbox" name="quote" value="1"> You may quote my words (with my first name) on Traversence</label><button class="go-btn main">' . $e($yes) . '</button></form>';
  };
  if (ClientOrders::hasReceived($pdo) && !$done && ClientOrders::outTheDoor($pdo, $o, $lines)): ?>
  <section class="go-card tv-bleed co-done" id="got-it" aria-labelledby="gi-h">
    <h2 id="gi-h">Do you have it?</h2>
    <p class="go-note">Everything on this order is on its way<?= in_array('ready', array_map(fn ($l) => ClientOrders::itemStatus($o, $l), $lines), true) ? ' or ready for pickup' : '' ?>. When you have it, tell us here: that completes your order.</p>
    <?php if ($openProblem): ?><p data-tv-status="info" data-tv-label="We have your note:">about something that isn't right<?php require_once __DIR__ . '/../app/lib/Pulse.php'; foreach ($fb as $f) if ($f['kind'] === 'problem' && $f['resolved_at'] === null && ($tk = Pulse::caseNo($pdo, 'fb:' . $f['id']))) { echo ' (ticket #' . (int) $tk . ')'; break; } ?>. We'll be in touch to put it right.</p><?php endif; ?>
    <?= $rate('received', 'Yes, I have it') ?>
    <details class="co-prob"><summary>Something isn't right?</summary>
      <form method="post"><?= $hid ?><input type="hidden" name="do" value="problem"><label>Tell us what happened<textarea class="co-in" name="words" rows="3" maxlength="2000" required placeholder="Missing, damaged, not what you expected…"></textarea></label><button class="go-btn">Tell us</button></form>
    </details>
  </section>
  <?php elseif ($done): ?>
  <section class="go-card tv-bleed co-done" id="feedback" aria-labelledby="fb-h">
    <h2 id="fb-h">Complete. Thank you!</h2>
    <p class="go-note">Order #<?= $e(Orders::no($o)) ?> is complete<?= !empty($o['received_at']) ? ': you told us you have it on ' . $e(date('F j', strtotime((string) $o['received_at']))) : '' ?>. Thank you for working with us.</p>
    <?php if ($reviewed): ?><p data-tv-status="ok" data-tv-label="Thank you:">for telling us how it went.</p>
    <?php elseif (ClientOrders::hasReceived($pdo)): ?><?= $rate('review', 'Send') ?><?php endif; ?>
  </section>
  <?php require_once __DIR__ . '/../app/lib/Collateral.php'; $again = Collateral::onOrder($pdo, $oid); if ($again): ?>
  <section class="go-card tv-bleed co-done" id="reorder" aria-labelledby="ro-h">
    <h2 id="ro-h">Reorder</h2>
    <p class="go-note">Tick what you need again and how many. It's priced at today's rates, and we send you the order to look over and approve before anything is made.</p>
    <form method="post" class="co-reo"><?= $hid ?><input type="hidden" name="do" value="reorder">
      <?php foreach ($again as $cid => [$c, $l]): ?>
      <div class="co-reo-i"><label class="co-chk"><input type="checkbox" name="pick[]" value="<?= (int) $cid ?>"<?= count($again) === 1 ? ' checked' : '' ?>> <b><?= $e($c['name']) ?></b></label>
        <label class="co-reo-q">How many<input class="co-in" name="qty[<?= (int) $cid ?>]" inputmode="numeric" value="<?= (int) $c['qty'] ?>"></label></div>
      <?php endforeach; ?>
      <label class="co-chk"><input type="checkbox" name="changes" value="1"> I want changes to the art (we'll send a new proof)</label>
      <label>Anything we should know?<textarea class="co-in" name="note" rows="2" maxlength="600"></textarea></label>
      <button class="go-btn main">Ask for this reorder</button>
    </form>
  </section>
  <?php endif; endif; ?>
  <?php if ($o['status'] === 'void'): ?><div class="go-banner warm">This order was cancelled. Nothing was charged.</div><?php endif; ?>
  <?php if ($expired): ?><div class="go-banner warm">This order's link expired on <?= $e(date('F j', strtotime((string) $o['expires_at']))) ?>. Reply to our email and we'll send it again.</div><?php endif; ?>
  <?php if ($o['note'] !== ''): ?><div class="go-banner"><?= nl2br($e($o['note'])) ?></div><?php endif; ?>

  <?php if ($o['stage'] !== '' && $print && !ClientOrders::hasItems($pdo)): ?>
  <section class="go-card tv-bleed" aria-label="Where it is">
    <h2>Where it is</h2>
    <?php $keys = array_keys($steps); $at = array_search($o['stage'], $keys, true); ?>
    <ol class="co-steps"><?php foreach ($keys as $i => $k): ?><li class="<?= $i === $at ? 'on' : ($at !== false && $i < $at ? 'done' : '') ?>"><?= $e($steps[$k]) ?></li><?php endforeach; ?></ol>
    <?php if ($o['tracking'] !== ''): ?><p class="go-note"><?= $o['stage'] === 'shipped' ? 'Tracking: ' : '' ?><b><?= $e($o['tracking']) ?></b></p><?php endif; ?>
  </section>
  <?php endif; ?>

  <section class="go-card tv-bleed" aria-label="What's in it">
    <h2>What's in it</h2>
    <?php if ($review && $waiting): ?><p class="go-note" style="margin-bottom:.5rem">Look over each proof: <b>Approve</b> it, or tell us what to change. Then approve the order below.</p><?php endif; ?>
    <?php foreach ($groups as $g): if (!$g['lines']) continue; $gPrint = ClientOrders::hasProjects($pdo) && array_filter($g['lines'], fn ($x) => ClientOrders::role($pdo, $x) === 'print'); if ($g['project']): ?><div class="co-prj"><h3><?= $e($g['project']['title']) ?></h3><?php endif; ?>
    <?php foreach ($g['lines'] as $l): $pf = $l['proof']; $ist = ClientOrders::hasItems($pdo) ? ClientOrders::itemStatus($o, $l) : ''; if ($ist === 'deleted') continue; ?>
    <div class="co-ln">
      <div class="hd">
        <div style="min-width:0"><b><?= $e(preg_replace('/^GO Code: /', 'GO Code: ', (string) $l['title'])) ?></b>
          <?php if ($l['options'] !== ''): ?><div class="go-note"><?= $e($l['options']) ?></div><?php endif; ?>
          <?php if ($l['note'] !== ''): ?><div class="go-note"><?= $e($l['note']) ?></div><?php endif; ?>
          <?php if ($l['code']): ?><div class="go-note"><?= $e(Qr::TYPES[$l['code']['type']] ?? '') ?>: <?= $e(QrIssue::holds((string) $l['code']['type'], json_decode((string) $l['code']['fields'], true) ?: [])) ?></div><?php endif; ?>
          <?php if ($l['product'] === 'product' && ClientOrders::runQty($l) > 1): ?><div class="go-note"><?= number_format(ClientOrders::runQty($l)) ?> × $<?= $e(ClientOrders::rate($l)) ?></div><?php elseif ((int) $l['qty'] > 1): ?><div class="go-note"><?= (int) $l['qty'] ?> × <?= $usd($l['unit_cents']) ?></div><?php endif; ?>
          <?php if ($hasShip && $l['product'] !== 'shipping' && (($l['ship_to'] ?? '') !== '' || (int) $l['ship_cents'])): ?><div class="go-note"><?= ($l['ship_to'] ?? '') === 'pickup' ? 'Picked up by you' : 'Ships to ' . $e(ClientOrders::shipLabel($o, $l, $addrs)) ?><?= (int) $l['ship_cents'] ? ' · shipping ' . $usd($l['ship_cents']) : '' ?></div><?php endif; ?>
          <?php if ($ist !== '' && $o['approved_at'] && $l['product'] !== 'shipping'): ?><span class="co-ist"><?= $e(ClientOrders::statusLabel($ist)) ?></span><?php if (($l['tracking'] ?? '') !== ''): ?> <span class="go-note"><?= $e($l['tracking']) ?></span><?php endif; ?><?php endif; ?>
        </div>
        <div class="co-amt"><?php if ((int) $l['list_cents'] > (int) $l['unit_cents']): ?><s><?= $usd((int) $l['list_cents'] * (int) $l['qty']) ?></s><?php endif; ?><?= $usd((int) $l['unit_cents'] * (int) $l['qty']) ?></div>
      </div>
      <?php if ($pf):
        $isGo = $pf['mime'] === 'go-code';
        $src = $isGo ? ($l['code'] ? '/api/qr.php?issued=' . (int) $l['code']['id'] . '&proof=1&format=svg' : '') : '/api/order-proof.php?o=' . $oid . '&p=' . (int) $pf['id'] . '&t=' . rawurlencode($tok);
        $kind = $isGo ? 'go' : ($pf['mime'] === 'application/pdf' ? 'pdf' : 'image');
        $acts = $review && in_array($pf['status'], ['waiting', 'approved'], true);
        // a reorder with the same art (decisions/0101, addendum 2026-10-28): the client confirms the reuse, signed off with initials as for any proof
        $reuse = !empty($pf['reuse_of']); $reuseNo = '';
        if ($reuse) { $rs = $pdo->prepare('SELECT o.* FROM order_proofs p JOIN orders o ON o.id = p.order_id WHERE p.id = ?'); $rs->execute([(int) $pf['reuse_of']]); $ro = $rs->fetch(PDO::FETCH_ASSOC); $reuseNo = $ro ? Orders::no($ro) : ''; }
        $signForm = function (string $label) use ($pf, $l, $isGo, $oid, $tok, $hid, $e): string {
            $dl = $isGo ? [] : array_map(fn ($f) => ['name' => (string) ($f['file_name'] ?: 'proof'), 'url' => '/api/order-proof.php?o=' . $oid . '&p=' . (int) $f['id'] . '&t=' . rawurlencode($tok) . '&download=1'], $l['proof_files'] ?: [$pf]);
            return '<form method="post" data-signoff data-pid="' . (int) $pf['id'] . '" data-title="' . $e($l['title'] . ((int) $pf['version'] > 1 ? ' (version ' . (int) $pf['version'] . ')' : '')) . '" data-dl="' . $e(json_encode($dl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) . '">'
                . $hid . '<input type="hidden" name="do" value="proof_ok"><input type="hidden" name="proof" value="' . (int) $pf['id'] . '"><button class="go-btn main">' . $e($label) . '</button></form>';
        }; ?>
      <p class="go-note" style="margin-top:.4rem">Proof<?= (int) $pf['version'] > 1 ? ' (version ' . (int) $pf['version'] . ')' : '' ?>:
        <span class="co-st <?= $pf['status'] === 'approved' ? 'ok' : ($pf['status'] === 'changes' ? 'no' : '') ?>"><?= $e(['waiting' => $reuse ? 'The same art as before: confirm the reuse' : 'Waiting for your OK', 'approved' => $reuse ? 'Reuse confirmed' : 'Approved', 'changes' => 'Changes asked for', 'replaced' => 'Replaced'][$pf['status']] ?? '') ?></span>
        <?php if ($reuse): ?><br>A reorder: this is the artwork you approved<?= $reuseNo !== '' ? ' on order #' . $e($reuseNo) : '' ?>. Look it over, then confirm it's still right, or ask for changes.<?php endif; ?></p>
      <?php if ($isGo && $l['code']): ?><template id="gi<?= (int) $l['id'] ?>"><h3><?= $e(QrIssue::KIND[$l['code']['type']] ?? 'GO Code') ?></h3><?= QrIssue::detailsHtml((string) $l['code']['type'], json_decode((string) $l['code']['fields'], true) ?: []) ?></template><?php endif; ?>
      <?php if ($acts): ?><template id="pa<?= (int) $pf['id'] ?>">
        <?php if ($pf['status'] === 'waiting'): $dl = $isGo ? [] : array_map(fn ($f) => ['name' => (string) ($f['file_name'] ?: 'proof'), 'url' => '/api/order-proof.php?o=' . $oid . '&p=' . (int) $f['id'] . '&t=' . rawurlencode($tok) . '&download=1'], $l['proof_files'] ?: [$pf]); ?>
        <?= $signForm($reuse ? 'Confirm reuse' : 'Approve') ?><?php endif; ?>
        <details><summary class="go-btn" style="display:inline-flex;list-style:none"><?= $pf['status'] === 'approved' ? 'Change my mind: make changes' : 'Make changes' ?></summary>
          <form method="post" class="go-f"><?= $hid ?><input type="hidden" name="do" value="proof_change"><input type="hidden" name="proof" value="<?= (int) $pf['id'] ?>">
            <label>What should we change?<textarea name="note" maxlength="1000" required></textarea></label>
            <button class="go-btn" style="margin-top:.4rem">Send it to us</button></form></details>
      </template><?php endif; ?>
      <?php if ($src !== ''): $pfs = $isGo ? [$pf] : ($l['proof_files'] ?: [$pf]); $nf = count($pfs); ?>
      <?php if ($nf > 1): ?><p class="go-note" style="margin:.3rem 0 0"><?= $nf ?> files in this proof: approving it approves them all.</p><div class="co-pvs"><?php endif; ?>
      <?php foreach ($pfs as $fi => $p1):
        $src1 = $isGo ? $src : '/api/order-proof.php?o=' . $oid . '&p=' . (int) $p1['id'] . '&t=' . rawurlencode($tok);
        $kind1 = $isGo ? 'go' : ($p1['mime'] === 'application/pdf' ? 'pdf' : 'image'); ?>
      <button type="button" class="co-pv" data-proof="<?= $kind1 ?>" data-proof-src="<?= $e($src1) ?>" data-proof-title="<?= $e(preg_replace('/^GO Code: /', '', (string) $l['title']) . ((int) $pf['version'] > 1 ? ' (version ' . (int) $pf['version'] . ')' : '') . ($nf > 1 ? ' · file ' . ($fi + 1) . ' of ' . $nf : '')) ?>"<?= $isGo ? ' data-proof-info="#gi' . (int) $l['id'] . '"' : '' ?><?= $acts ? ' data-proof-acts="#pa' . (int) $pf['id'] . '"' : '' ?>>
        <?php if ($kind1 === 'image'): ?><img src="<?= $e($src1) ?>" alt="" loading="lazy"><?php elseif ($isGo): ?><img src="/api/qr.php?issued=<?= (int) $l['code']['id'] ?>&amp;format=png&amp;px=300" alt="" loading="lazy" style="max-width:7rem"><?php else: ?><span class="pdf">PDF</span><?php endif; ?>
        <span class="go-btn<?= $pf['status'] === 'waiting' && $review && !$fi ? ' main' : '' ?>"><?= $fi ? 'File ' . ($fi + 1) : ($pf['status'] === 'waiting' && $review ? 'Review the proof' : 'See the proof') ?></span>
      </button>
      <?php endforeach; ?>
      <?php if ($nf > 1): ?></div><?php endif; ?>
      <?php if ($reuse && $pf['status'] === 'waiting' && $review): ?><div class="co-reuse"><?= $signForm('Confirm reuse') ?><span class="go-note">Opens the sign-off with your initials, as for any proof.</span></div><?php endif; ?>
      <?php endif; ?>
      <?php if ($pf['status'] === 'changes'): ?><p class="go-note" style="margin-top:.4rem"><b>You asked:</b> <?= $e($pf['client_note']) ?> We'll send you a new proof.</p><?php endif; ?>
      <?php endif; ?>
      <?php if ($l['code'] && QrIssue::owned($l['code'])): $q = '/api/qr.php?issued=' . (int) $l['code']['id']; ?>
      <div class="co-acts"><img src="<?= $e($q) ?>&format=png&px=200" alt="" style="width:4.5rem;height:4.5rem;background:#fff;border-radius:.25rem">
        <a class="go-btn" href="<?= $e($q) ?>&format=svg&download=1">Download for print (SVG)</a><a class="go-btn" href="<?= $e($q) ?>&format=png&px=1200&download=1">Download (PNG)</a></div>
      <?php endif; ?>
      <?php if (!empty($released[(int) $l['id']])): ?>
      <div class="co-rel"><?php foreach ($released[(int) $l['id']] as $rf): ?><a class="go-btn main" href="/api/order-proof.php?o=<?= $oid ?>&amp;p=<?= (int) $rf['id'] ?>&amp;t=<?= $e(rawurlencode($tok)) ?>&amp;download=1">Download <?= $e($rf['file_name'] ?: 'the file') ?></a><?php endforeach; ?></div>
      <?php elseif ($pf && $pf['status'] === 'approved' && $o['approved_at'] && !ClientOrders::paidInFull($pdo, $o) && (($rl = ClientOrders::role($pdo, $l)) === 'print' || ($rl === 'creative' && !$gPrint && $l['finals']))): ?>
      <p class="go-note" style="margin-top:.3rem">The approved files are yours to download once the order is paid in full.</p>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php if ($g['project']): ?><div class="co-psub"><span><?= $e($g['project']['title']) ?></span><span><?= $usd($g['subtotal']) ?></span></div></div><?php endif; ?>
    <?php endforeach; ?>
    <?php if ($ship['cents']): ?><div class="go-sum" style="font-weight:400"><span>Items</span><span><?= $usd((int) $o['subtotal_cents'] - $ship['cents']) ?></span></div>
    <div class="go-sum" style="font-weight:400"><span>Shipping<?php foreach ($ship['rows'] as $r): ?><small class="co-shr"><?= $e($r['title']) ?> → <?= $e($r['to']) ?>: <?= $usd($r['cents']) ?></small><?php endforeach; ?></span><span><?= $usd($ship['cents']) ?></span></div><?php endif; ?>
    <?php $pv = ClientOrders::promoPreview($pdo, $o); if ($pv && $pv['off'] > 0): ?>
    <div class="go-sum" style="font-weight:400;color:#166534"><span>Code <?= $e($pv['promo']['code']) ?>: <?= $e(Promotions::offer($pv['promo'])) ?><?= $pv['applied'] ? '' : ' <small style="display:block;color:#5C4632">taken off the prices when you approve</small>' ?></span><span>−<?= $usd($pv['off']) ?></span></div>
    <?php endif; ?>
    <div class="go-sum" style="font-weight:400"><span>Subtotal<?= $pv && $pv['off'] > 0 && !$pv['applied'] ? ' before the code' : '' ?></span><span><?= $usd($o['subtotal_cents']) ?></span></div>
    <?php if ($review): ?>
    <form method="post" style="display:flex;gap:.4rem;margin-top:.5rem"><?= $hid ?><input type="hidden" name="do" value="promo">
      <input name="code" value="<?= $e($pv['promo']['code'] ?? '') ?>" placeholder="Promo code" aria-label="Promo code" autocapitalize="characters" style="flex:1;min-width:0;border:1px solid #CBB98D;border-radius:.6rem;padding:.45rem .6rem;background:#FFFBF2">
      <button class="go-btn"><?= $pv ? 'Change' : 'Apply' ?></button></form>
    <?php endif; ?>
    <?php if ($o['approved_at']): ?>
      <?php if (!$outside): ?><div class="go-sum" style="font-weight:400"><span>Sales tax</span><span><?= $usd($o['tax_cents']) ?></span></div><?php endif; ?>
      <div class="go-sum"><span>Total</span><span><?= $usd($o['total_cents']) ?></span></div>
      <?php if ($m['paid'] > 0): ?><div class="go-sum" style="font-weight:400"><span>Paid</span><span><?= $usd($m['paid']) ?></span></div><?php endif; ?>
      <?php if ($m['refunded'] > 0): ?><div class="go-sum" style="font-weight:400"><span>Refunded</span><span><?= $usd($m['refunded']) ?></span></div><?php endif; ?>
    <?php elseif (!$outside): ?><p class="go-note">Plus sales tax, worked out from your billing address when you approve.</p><?php endif; ?>
    <?php if ($o['approved_at'] && ($o['ship_street'] ?? '') !== ''): ?><p class="go-note" style="margin-top:.4rem">Shipping to <?= $e($o['ship_name']) ?>, <?= $e($o['ship_street']) ?>, <?= $e($o['ship_city']) ?>, <?= $e($o['ship_state']) ?> <?= $e($o['ship_zip']) ?>.</p><?php endif; ?>
  </section>

  <?php if ($review): ?>
  <section class="go-card tv-bleed" id="approve" aria-labelledby="ap-h">
    <h2 id="ap-h">Approve the order</h2>
    <?php if ($waiting): ?><p class="go-note"><b>First approve each proof above</b><?= $o['review'] === 'changes' ? ' (we\'re working on the changes you asked for, and will send you a new proof)' : '' ?>.</p>
    <?php else: ?>
    <?php if ($outside): ?><p class="go-note">You'll pay us directly, as we arranged (cash, check, Zelle…); we confirm each payment by email. Printing starts once it's paid. What you approve is made as shown, so check names, numbers and spelling.</p>
    <?php else: ?><p class="go-note"><?= $e(ClientOrders::PAY_MODES[$o['pay_mode']]) ?><?= $o['pay_mode'] === 'deposit' ? ': ' . (int) $o['deposit_pct'] . '% now' : '' ?>. Approving makes your invoice; printing starts once <?= $o['pay_mode'] === 'deposit' ? 'the deposit is paid' : 'it\'s paid' ?>. What you approve is made as shown, so check names, numbers and spelling.</p><?php endif; ?>
    <form method="post" class="go-f"><?= $hid ?><input type="hidden" name="do" value="approve">
      <label for="a-street">Billing street<?= $outside ? ' (optional)' : '' ?></label><input id="a-street" name="street" maxlength="160" autocomplete="street-address" value="<?= $e($o['bill_street']) ?>"<?= $outside ? '' : ' required' ?>>
      <div class="go-2"><div><label for="a-city">Town</label><input id="a-city" name="city" maxlength="80" autocomplete="address-level2" value="<?= $e($o['bill_city']) ?>"<?= $outside ? '' : ' required' ?>></div>
        <div class="go-2"><div><label for="a-state">State</label><input id="a-state" name="state" maxlength="2" autocomplete="address-level1" placeholder="AZ" value="<?= $e($o['bill_state']) ?>"<?= $outside ? '' : ' required' ?>></div><div><label for="a-zip">ZIP</label><input id="a-zip" name="zip" maxlength="10" inputmode="numeric" autocomplete="postal-code" value="<?= $e($o['bill_zip']) ?>"<?= $outside ? '' : ' required' ?>></div></div></div>
      <?php if ($delivery === 'ship'): ?>
      <?php $sh = trim((string) ($o['ship_street'] ?? '')) !== '';   /* our Ship to comes first; billing only when it's blank (decisions/0101, note of 2026-11-20, B.1) */ ?>
      <fieldset class="co-ship"><legend>Where should we ship it?</legend>
        <label style="display:flex;gap:.5rem;align-items:center;font-weight:400"><input type="checkbox" name="ship_same" value="1"<?= $sh ? '' : ' checked' ?> style="width:auto" data-ship-same> To the billing address above</label>
        <div data-ship-to<?= $sh ? '' : ' hidden' ?>>
          <label for="s-name">Name on the package</label><input id="s-name" name="ship_name" maxlength="120" autocomplete="shipping name" value="<?= $e($sh && trim((string) ($o['ship_name'] ?? '')) !== '' ? $o['ship_name'] : $o['bill_name']) ?>">
          <label for="s-street">Street</label><input id="s-street" name="ship_street" maxlength="160" autocomplete="shipping street-address" value="<?= $e($sh ? $o['ship_street'] : '') ?>">
          <div class="go-2"><div><label for="s-city">Town</label><input id="s-city" name="ship_city" maxlength="80" autocomplete="shipping address-level2" value="<?= $e($sh ? ($o['ship_city'] ?? '') : '') ?>"></div>
            <div class="go-2"><div><label for="s-state">State</label><input id="s-state" name="ship_state" maxlength="2" autocomplete="shipping address-level1" placeholder="AZ" value="<?= $e($sh ? ($o['ship_state'] ?? '') : '') ?>"></div><div><label for="s-zip">ZIP</label><input id="s-zip" name="ship_zip" maxlength="10" inputmode="numeric" autocomplete="shipping postal-code" value="<?= $e($sh ? ($o['ship_zip'] ?? '') : '') ?>"></div></div></div>
        </div>
      </fieldset>
      <?php elseif ($delivery === 'pickup'): ?><p class="go-note" style="margin-top:.5rem">You'll pick it up: we email you when it's ready.</p><?php endif; ?>
      <label for="a-name">Your name (your approval)</label><input id="a-name" name="name" maxlength="120" autocomplete="name" value="<?= $e($o['bill_name']) ?>" required>
      <label style="display:flex;gap:.5rem;align-items:flex-start;font-weight:400;margin-top:.6rem"><input type="checkbox" name="notify" value="1"<?= ClientOrders::wantsProgress($o) ? ' checked' : '' ?> style="width:auto;margin-top:.2rem"> Email me as my order moves along (in production, shipped). Receipts always come.</label>
      <label style="display:flex;gap:.5rem;align-items:flex-start;font-weight:400;margin-top:.4rem"><input type="checkbox" name="agree" value="1" required style="width:auto;margin-top:.2rem"> I approve this order and its proofs as shown.</label>
      <button class="go-btn main wide" style="margin-top:.7rem">Approve the order</button>
    </form>
    <p class="go-note" style="margin-top:.4rem">By approving you agree to our <a href="/terms.php" target="_blank" rel="noopener">Terms</a>.</p>
    <?php endif; ?>
  </section>
  <?php endif; ?>

  <?php $offers = ClientOrders::hasPayChoice($pdo) ? ClientOrders::offers($o) : []; $way = isset($offers[$o['pay_method'] ?? '']) ? (string) $o['pay_method'] : ($outside ? '' : 'card');   // paid outside QuickBooks: never the card form (it has no invoice to post to)
  $notifyBox = ClientOrders::hasPayChoice($pdo) ? '<form method="post" style="margin-top:.6rem">' . $hid . '<input type="hidden" name="do" value="notify"><input type="hidden" name="notify" value="0"><label style="display:flex;gap:.5rem;align-items:flex-start;font-weight:400;font-size:.92rem"><input type="checkbox" name="notify" value="1"' . (ClientOrders::wantsProgress($o) ? ' checked' : '') . ' data-tv-autosubmit style="width:auto;margin-top:.2rem"> Email me as my order moves along (in production, shipped). Receipts always come.</label></form>' : ''; ?>
  <?php if ($o['status'] === 'pending' && $due > 0): ?>
  <section class="go-card tv-bleed" id="pay" aria-labelledby="pay-h">
    <h2 id="pay-h"><?= $placed ? 'Payment on its way' : ($o['pay_mode'] === 'deposit' && $m['paid'] === 0 ? 'Pay the deposit' : ($m['paid'] > 0 ? 'Pay the rest' : 'Pay')) ?>: <?= $usd($due) ?></h2>
    <?php if ($placed): ?><details class="co-paymore"><summary>Your payment details, or change how you'll pay</summary><?php endif; ?>
    <?php if ($offers): ?>
    <div class="co-ways" role="group" aria-label="How you'll pay"><?php foreach (($outside ? [] : ['card' => 'Card']) + $offers as $k => $lab): ?><form method="post"><?= $hid ?><input type="hidden" name="do" value="pay_method"><input type="hidden" name="method" value="<?= $e($k) ?>"><input type="hidden" name="ref" value=""><button class="go-btn<?= $way === $k ? ' main' : '' ?>" aria-pressed="<?= $way === $k ? 'true' : 'false' ?>"<?= $way !== $k && in_array($k, ['wire', 'check'], true) ? ' data-ask-ref="' . $e($k === 'wire' ? 'Already sent the wire? Enter its confirmation code from your bank. Not sent yet? Leave this blank: you\'ll see our wire details next.' : 'Already mailed the check? Enter its check number. Not yet? Leave this blank.') . '"' : '' ?>><?= $e($lab) ?></button></form><?php endforeach; ?></div>
    <?php endif; ?>
    <?php if ($way === 'card'): ?>
    <?php if ($o['pay_mode'] === 'invoice' && $m['paid'] === 0): ?><p class="go-note">Your invoice<?= $o['invoice_no'] ? ' (' . $e($o['invoice_no']) . ')' : '' ?> was emailed to you; pay it by card here or on QuickBooks' page.<?= ClientOrders::overridden($pdo, (int) $o['id']) ? '' : ' Printing starts once it\'s paid.' ?></p><?php endif; ?>
    <div id="co-paybox"></div>
    <?php elseif ($way !== ''): $how = ClientOrders::howToPay($way); $lab = $offers[$way]; ?>
    <div class="co-howto">
      <p class="go-note" style="margin-top:0">Pay <b><?= $usd($due) ?></b> by <?= $e(strtolower($lab)) ?>, with <b>Order <?= $e(Orders::no($o)) ?></b> in the reference.</p>
      <?php if ($way === 'wire' && $how !== ''): $wl = ClientOrders::wireLeft($o); $wc = !empty($_SESSION['tv_wire'][$oid]) && $_SESSION['tv_wire'][$oid]['until'] > time(); ?>
      <div class="co-wire-safe"><b>Protected:</b> our wire details show here only, never in email, after a code we send to <?= $e(preg_replace('/(?<=.).(?=[^@]*@)/u', '•', (string) $o['bill_email'])) ?>. They show for <?= ClientOrders::WIRE_MINUTES ?> minutes, can't be copied or printed, and each viewing is recorded.</div>
      <?php if ($wl > 0): ?>
      <div class="co-wire" id="co-wire" data-left="<?= $wl ?>">
        <img src="/api/wire-card.php?t=<?= $e(rawurlencode($tok)) ?>&amp;v=<?= time() ?>" alt="Our wire details" draggable="false">
        <div class="co-wire-cover">Hidden while this window isn't in front. Click here to show it again.</div>
      </div>
      <form method="post" class="go-note" style="margin:.3rem 0 0;display:flex;gap:.6rem;align-items:center;flex-wrap:wrap" data-wire-hide><?= $hid ?><input type="hidden" name="do" value="wire_hide"><span>Shown for <b data-wire-left></b> more.</span><button class="go-btn sm">Hide now</button></form>
      <?php else: ?>
      <div class="co-wire-ask">
        <form method="post"><?= $hid ?><input type="hidden" name="do" value="wire_code"><button class="go-btn<?= $wc ? '' : ' main' ?>"><?= $wc ? 'Send a new code' : 'Email me a code to see them' ?></button></form>
        <?php if ($wc): ?><form method="post" class="go-f co-wire-code"><?= $hid ?><input type="hidden" name="do" value="wire_show"><label for="w-code">The 6-digit code from our email</label>
          <input id="w-code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" pattern="[0-9 ]*" required><button class="go-btn main">Show the wire details</button></form><?php endif; ?>
      </div>
      <?php endif; ?>
      <?php elseif ($how !== ''): ?><div class="co-howbox"><?= nl2br($e($how)) ?></div><?php else: ?><p class="go-note">We'll send you our <?= $e(strtolower($lab)) ?> details ourselves and confirm them with you by phone.</p><?php endif; ?>
      <?php if ($way === 'wire'): ?><p class="go-note co-wire-warn"><b>Keep your money safe:</b> before you send a wire, call us at <a href="tel:<?= $e(preg_replace('/[^\d+]/', '', ClientOrders::wirePhone())) ?>"><b><?= $e(ClientOrders::wirePhone()) ?></b></a> to confirm the details. We never send or change our bank details by email; if anyone does, it isn't us.</p><?php endif; ?>
      <?php if ($way !== 'cash'): ?>
      <?php if (($o['pay_report'] ?? '') !== ''): ?><p class="go-note"><b>You told us it's sent</b><?= !empty($o['pay_reported_at']) ? ' (' . $e(date('M j', strtotime((string) $o['pay_reported_at']))) . ')' : '' ?>: <?= $e($o['pay_report']) ?>. Your order is held until it reaches us; we email you then, and it goes to production.</p><?php endif; ?>
      <form method="post" class="go-f"><?= $hid ?><input type="hidden" name="do" value="pay_report">
        <label for="p-ref"><?= $way === 'wire' ? 'Sent it? The wire\'s confirmation code (from your bank)' : 'Mailed it? The check number' ?></label>
        <input id="p-ref" name="ref" maxlength="200" value="<?= $e($o['pay_report'] ?? '') ?>" autocomplete="off" required>
        <button class="go-btn main wide" style="margin-top:.5rem"><?= ($o['pay_report'] ?? '') !== '' ? 'Update it' : 'Tell us it\'s sent' ?></button></form>
      <?php else: ?><p class="go-note">Your order is held until we receive it; we email you a receipt then, and it goes to production.</p><?php endif; ?>
    </div>
    <?php else: ?><p class="go-note">Pay us directly, as we arranged (cash, check, Zelle…). We confirm each payment by email and it shows here.</p>
    <?php endif; ?>
    <?php if ($placed): ?></details><?php endif; ?>
    <?= $notifyBox ?>
  </section>
  <?php elseif (in_array($o['status'], ['paid', 'part_refunded', 'refunded'], true)): ?>
  <section class="go-card tv-bleed"><h2>Paid</h2><p class="go-note">Thank you. Paid <?= $usd($m['paid']) ?><?= $o['paid_at'] ? ' on ' . $e(date('F j, Y', strtotime((string) $o['paid_at']))) : '' ?><?= $o['invoice_no'] ? ' (invoice ' . $e($o['invoice_no']) . ')' : '' ?>.<?= $codes ? ' Your GO Codes are above, ready to download.' : '' ?></p><?= $notifyBox ?></section>
  <?php endif; ?>
</div>
<div class="co-sign" id="co-sign" hidden role="dialog" aria-modal="true" aria-labelledby="sg-h">
  <form method="post" class="co-sign-box" novalidate><?= $hid ?><input type="hidden" name="do" value="proof_ok"><input type="hidden" name="proof" value="">
    <button type="button" class="co-sign-x" data-sg-close aria-label="Close" title="Close">×</button>
    <h2 id="sg-h">Final approval<span data-sg-title></span></h2>
    <ul class="co-sign-terms"><?php foreach (ClientOrders::PROOF_TERMS as [$tt, $tx]): ?><li><b><?= $e($tt) ?>:</b> <?= $e($tx) ?></li><?php endforeach; ?></ul>
    <p class="co-sign-dl" data-sg-dl hidden>Download the proof: <span></span></p>
    <?php foreach (ClientOrders::PROOF_CHECKS as $ci => $ct): ?><label class="co-sign-chk"><input type="checkbox" name="check[<?= $ci ?>]" value="1"> <?= $e($ct) ?></label><?php endforeach; ?>
    <label class="co-sign-ini" for="sg-ini"><?= tv_icon('pen', 'tv-ei') ?> Please enter your initials to confirm:</label>
    <input id="sg-ini" name="initials" maxlength="12" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="JD">
    <div class="co-sign-acts"><button type="button" class="go-btn" data-sg-changes>Cancel &amp; Request Changes</button><button class="go-btn main" data-sg-go disabled>Submit Final Approval</button></div>
  </form>
</div>
<?php if ($o && !$staffView): ?><script<?= tv_nonce() ?>>
// tell us the client has the page open (once it's been showing a moment)
(function () {
  var sent = false, go = function () {
    if (sent || document.visibilityState !== 'visible') return; sent = true;
    var f = new FormData(); f.append('do', 'seen'); f.append('t', <?= json_encode($tok) ?>); f.append('csrf', <?= json_encode($csrf) ?>);
    fetch('/order.php', { method: 'POST', body: f, credentials: 'same-origin', keepalive: true }).catch(function () {});
  };
  setTimeout(go, 1500); document.addEventListener('visibilitychange', function () { setTimeout(go, 1500); });
})();
</script><?php endif; ?>
<script src="/js/tv-proof.js?v=<?= (int) @filemtime(__DIR__ . '/js/tv-proof.js') ?>"></script>
<script<?= tv_nonce() ?>>
// choosing wire or check asks for its confirmation code / check number (blank: not sent yet)
document.querySelectorAll('[data-ask-ref]').forEach(function (b) {
  b.addEventListener('click', function (ev) {
    if (b.__ok || !window.TvAsk) return;
    ev.preventDefault();
    TvAsk.ask(b.getAttribute('data-ask-ref'), '', { yes: 'Continue' }).then(function (v) {
      if (v === null) return;
      b.form.elements.ref.value = v.trim(); b.__ok = true; b.form.requestSubmit ? b.form.requestSubmit(b) : b.form.submit();
    });
  });
});
</script>
<script<?= tv_nonce() ?>>
(function () {   // our wire details: on screen only, for a while; covered when the window isn't in front; no copy, print or save
  var w = document.getElementById('co-wire'); if (!w) return;
  var left = +w.getAttribute('data-left') || 0, out = document.querySelector('[data-wire-left]');
  var off = function () { w.classList.add('off'); }, on = function () { if (document.hasFocus() && !document.hidden) w.classList.remove('off'); };
  var hideF = document.querySelector('form[data-wire-hide]');
  var gone = function () { w.remove(); if (hideF) hideF.submit(); else location.reload(); };
  var tick = function () { if (left <= 0) return gone(); var m = Math.floor(left / 60), s = left % 60; if (out) out.textContent = m + ':' + (s < 10 ? '0' : '') + s; left--; };
  tick(); setInterval(tick, 1000);
  window.addEventListener('blur', off); document.addEventListener('visibilitychange', function () { if (document.hidden) off(); });
  w.addEventListener('click', on); window.addEventListener('focus', function () { setTimeout(on, 150); });
  ['copy', 'cut', 'contextmenu', 'dragstart', 'selectstart'].forEach(function (t) { w.addEventListener(t, function (e) { e.preventDefault(); }); });
  document.addEventListener('keydown', function (e) {   // print, save, copy and the screen-capture keys: covered first
    var k = (e.key || '').toLowerCase();
    if (k === 'printscreen' || ((e.ctrlKey || e.metaKey) && ['p', 's', 'c'].indexOf(k) >= 0) || (e.metaKey && e.shiftKey)) { off(); if (k !== 'printscreen' && !e.shiftKey) e.preventDefault(); }
  }, true);
  document.addEventListener('keyup', function (e) { if ((e.key || '').toLowerCase() === 'printscreen') { off(); try { navigator.clipboard.writeText(''); } catch (x) {} } }, true);
  window.addEventListener('beforeprint', off);
})();
(function () {   // a proof's final approval: the terms, two boxes and initials, then Submit (decisions/0101, addendum 2026-10-28)
  var d = document.getElementById('co-sign'); if (!d) return;
  var f = d.querySelector('form'), go = d.querySelector('[data-sg-go]'), ini = f.elements.initials, from = null;
  var ready = function () { var ok = [].every.call(f.querySelectorAll('input[type=checkbox]'), function (c) { return c.checked; }) && ini.value.replace(/[^A-Za-z\u00C0-\u024F]/g, '').length >= 2; go.disabled = !ok; };
  var shut = function () { d.hidden = true; };
  f.addEventListener('input', ready); f.addEventListener('change', ready);
  document.addEventListener('submit', function (e) {   // Approve (in the proof's top bar): the pop-up first
    var a = e.target.closest('form[data-signoff]'); if (!a) return;
    e.preventDefault(); from = a;
    f.reset(); f.elements.proof.value = a.getAttribute('data-pid');
    d.querySelector('[data-sg-title]').textContent = a.getAttribute('data-title') ? ': ' + a.getAttribute('data-title') : '';
    var dl = []; try { dl = JSON.parse(a.getAttribute('data-dl') || '[]'); } catch (x) {}
    var box = d.querySelector('[data-sg-dl]'), sp = box.querySelector('span'); sp.textContent = '';
    dl.forEach(function (x, i) { var l = document.createElement('a'); l.href = x.url; l.textContent = x.name; l.setAttribute('download', ''); if (i) sp.appendChild(document.createTextNode(', ')); sp.appendChild(l); });
    box.hidden = !dl.length; ready(); d.hidden = false;
    setTimeout(function () { var c = f.querySelector('input[type=checkbox]'); if (c) c.focus(); }, 30);
  }, true);
  f.addEventListener('submit', function (e) { ready(); if (go.disabled) e.preventDefault(); });
  d.querySelector('[data-sg-close]').addEventListener('click', shut);
  d.querySelector('[data-sg-changes]').addEventListener('click', function () {   // back to the proof, its Make changes open
    shut(); var bar = from && from.parentNode, m = bar && bar.querySelector('details');
    if (m) { m.open = true; var t = m.querySelector('textarea'); if (t) t.focus(); }
  });
  d.addEventListener('click', function (e) { if (e.target === d) shut(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !d.hidden) { e.stopImmediatePropagation(); shut(); } }, true);
})();
document.querySelectorAll('[data-ship-same]').forEach(function (c) { var t = c.closest('fieldset').querySelector('[data-ship-to]'); var f = function () { t.hidden = c.checked; }; c.addEventListener('change', f); f(); });
</script>
<?php if ($staffView): ?>
<script<?= tv_nonce() ?>>
(function () {   // read only for our team on a real order: every action greyed out, with the reason (the server refuses them too)
  var why = <?= json_encode(ClientOrders::STAFF_VIEW_MSG) ?>;
  document.querySelectorAll('form[method="post"]').forEach(function (f) {
    f.querySelectorAll('button, input, select, textarea').forEach(function (x) { if (x.type === 'hidden') return; x.disabled = true; x.title = why; });
    f.addEventListener('submit', function (e) { e.preventDefault(); }, true);
  });
  var pb = document.getElementById('co-paybox'); if (pb) { pb.innerHTML = ''; var n = document.createElement('p'); n.className = 'go-note'; n.textContent = 'The card form is turned off for you here. ' + why; pb.appendChild(n); }
})();
</script>
<?php endif; ?>
<?php if (!$staffView && $o['status'] === 'pending' && $due > 0 && $way === 'card'): ?>
<script<?= tv_nonce() ?>>
(function () {
  var host = document.getElementById('co-paybox'); if (!host || !window.Go) return;
  var T = <?= json_encode($tok) ?>;
  Go.cardForm(host, { id: <?= $oid ?>, subtotal_cents: <?= (int) $o['subtotal_cents'] ?>, tax_cents: <?= (int) $o['tax_cents'] ?>, total_cents: <?= (int) $o['total_cents'] ?>, pay_url: <?= json_encode((string) $o['pay_url']) ?> },
    { token_url: <?= json_encode(QuickBooksPay::tokenUrl()) ?>, test: <?= QuickBooksPay::env() !== 'production' ? 'true' : 'false' ?>, mock: <?= QuickBooksPay::env() === 'mock' ? 'true' : 'false' ?> },
    { name: <?= json_encode((string) $o['bill_name']) ?>, zip: <?= json_encode((string) $o['bill_zip']) ?>, amount: <?= $due ?>, summary: false,
      note: <?= json_encode($print ? '' : 'Your GO Codes are ready the moment it\'s paid.') ?>,
      pay: function (tok) { return Go.call('/api/client-order.php', { t: T, action: 'pay', token: tok }); },
      onPaid: function () { location.reload(); } });
})();
</script>
<?php endif; ?>
<?php if (!empty($notifyBox)): ?><script<?= tv_nonce() ?>>
document.addEventListener('change', function (e) { var t = e.target; if (t && t.matches && t.matches('[data-tv-autosubmit]') && t.form) t.form.requestSubmit(); });
</script>
<?php endif; ?>
<?php tv_page_end(['footer' => 'checkout']);
