<?php
// app/lib/QrIssue.php — GO Codes: QR codes made, bought and kept (decisions/0095, 0096).
//
// Whose: a member (signed in), or a guest, by a private key in their browser (cookie tv_go; only its SHA-256 is
// stored). No account is needed to make and buy GO Codes. When a guest signs in or creates an account, their cart,
// codes and orders move into it (claim()), also by a paid order's email once that email is confirmed.
//   Free:  with an account, a basic type (link, phone, email, Wi-Fi), plain black on white: FREE_TOTAL in all.
//   Paid:  $4.95 once, plus tax, per code: the other types (contact card, event, text, text message), any code with
//          colors or a logo, a basic one past the free ones, and every code a guest gets. Paid through QuickBooks.
//   Ours:  our team can grant a code by hand.
// A code is kept with what it holds, so it can be downloaded again any time.
//
// Every GO Code routes through TRVGO (decisions/0098): its QR holds trvgo.us/{code}, so every scan is counted, and
// trvgo.us serves what it holds (a link → straight there; a contact card → the .vcf; an event → the .ics; phone, text
// message, email → a page that opens the app; text → a page showing it). Wi-Fi alone holds its network directly (only
// then can a phone join in one tap). A static code can't be changed by its buyer, but our team can correct it any time
// (E-Commerce → the order → Fix), and the printed QR never changes. A refunded or charged-back code is switched off
// (trvgo.us shows "not active"). Orders are the order system's (Orders: orders, order_lines, order_ledger).
declare(strict_types=1);

require_once __DIR__ . '/Qr.php';

final class QrIssue
{
    public const NAME = 'GO Codes';
    public const FREE_TOTAL = 5;
    public const PRICE_CENTS = 495;
    public const MAX_CART = 25;
    private const OWNED = ['free', 'paid', 'granted'];
    /** Types whose QR holds its content directly (not routed through trvgo.us): a phone joins Wi-Fi only from the code itself. */
    public const DIRECT = ['wifi'];
    /** What each type holds, for our team's Fix form (E-Commerce → an order): field => label. */
    public const FIELDS = [
        'link' => ['url' => 'Link'],
        'text' => ['text' => 'Text'],
        'phone' => ['phone' => 'Phone number'],
        'sms' => ['phone' => 'Number to text', 'message' => 'Message'],
        'email' => ['email' => 'Email address', 'subject' => 'Subject', 'body' => 'Message'],
        'wifi' => ['ssid' => 'Network name', 'security' => 'Security (WPA, WEP or nopass)', 'password' => 'Password', 'hidden' => 'Hidden network (1 = yes)'],
        'vcard' => ['name' => 'Name', 'org' => 'Business', 'title' => 'Job title', 'phone' => 'Phone', 'phone2' => 'Second phone', 'email' => 'Email', 'url' => 'Website',
                    'street' => 'Street', 'city' => 'City', 'state' => 'State', 'zip' => 'ZIP', 'country' => 'Country', 'note' => 'Note'],
        'event' => ['title' => 'Event name', 'date' => 'Starts (YYYY-MM-DD)', 'time' => 'Start time (HH:MM)', 'end_date' => 'Ends (YYYY-MM-DD)', 'end_time' => 'End time (HH:MM)',
                    'location' => 'Where', 'details' => 'Details', 'url' => 'Link'],
    ];
    private const COOKIE = 'tv_go';

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT guest_key FROM qr_issued LIMIT 1'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    // ---- whose ------------------------------------------------------------------------------------------------------

    /** This browser's guest key (made and set as a cookie when $make and there's none yet), as stored: its SHA-256. */
    public static function guestKey(bool $make = false): string
    {
        $t = (string) ($_COOKIE[self::COOKIE] ?? '');
        if (!preg_match('/^[a-f0-9]{48}$/', $t)) {
            if (!$make || headers_sent()) return '';
            $t = bin2hex(random_bytes(24));
            $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
            setcookie(self::COOKIE, $t, ['expires' => time() + 400 * 86400, 'path' => '/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']);
            $_COOKIE[self::COOKIE] = $t;
        }
        return hash('sha256', $t);
    }

    /** Who's asking: ['uid' => member id or 0, 'guest' => guest key or '']. */
    public static function owner(?array $me, bool $make = false): array
    {
        $uid = $me ? (int) $me['id'] : 0;
        return ['uid' => $uid, 'guest' => $uid ? '' : self::guestKey($make)];
    }

    /** SQL for "belongs to this owner" (with the table's alias), and its values. */
    private static function whose(array $o, string $a = ''): array
    {
        $p = $a !== '' ? $a . '.' : '';
        if ($o['uid'] > 0) return [$p . 'user_id = ?', [$o['uid']]];
        if ($o['guest'] !== '') return ['(' . $p . 'user_id IS NULL AND ' . $p . 'guest_key = ?)', [$o['guest']]];
        return ['1 = 0', []];
    }

    /** Orders this visit opened by their private link (the receipt email), so a guest sees them on any device. */
    public static function allowOrder(int $oid): void
    {
        $_SESSION['tv_go_orders'] = array_values(array_unique(array_merge(array_map('intval', (array) ($_SESSION['tv_go_orders'] ?? [])), [$oid])));
    }

    public static function orderAllowed(int $oid): bool { return in_array($oid, self::allowedOrders(), true); }

    private static function allowedOrders(): array { return array_map('intval', (array) ($_SESSION['tv_go_orders'] ?? [])); }

    /** '' when this owner may get codes, else the plain reason why not (a suspended or limited account). */
    public static function blocked(PDO $pdo, array $o): string
    {
        if ($o['uid'] <= 0) return '';
        $st = $pdo->prepare('SELECT is_suspended, deleted_at FROM users WHERE id = ?');
        try { $st->execute([$o['uid']]); $u = $st->fetch(PDO::FETCH_ASSOC); } catch (Throwable) { $u = null; }
        if (!$u || !empty($u['deleted_at'])) return 'Sign in again to get your codes.';
        if ((int) $u['is_suspended'] === 1) return 'This account is suspended.';
        try { require_once __DIR__ . '/Standing.php'; if (Standing::limited($pdo, $o['uid'])) return 'Your account is limited for now, so it can\'t get new codes.'; } catch (Throwable) {}
        return '';
    }

    /** Free codes left: FREE_TOTAL in all, for an account with a confirmed email; 0 for a guest. */
    public static function freeLeft(PDO $pdo, array $o): int
    {
        if ($o['uid'] <= 0) return 0;
        try {
            $st = $pdo->prepare('SELECT email_verified_at FROM users WHERE id = ?'); $st->execute([$o['uid']]);
            if ($st->fetchColumn() === null) return 0;
            $st = $pdo->prepare("SELECT COUNT(*) FROM qr_issued WHERE user_id = ? AND status = 'free'"); $st->execute([$o['uid']]);
            return max(0, self::FREE_TOTAL - (int) $st->fetchColumn());
        } catch (Throwable) { return 0; }
    }

    /** Is this code free-eligible: a basic type, plain black on white, no logo? */
    public static function basic(string $type, array $style, bool $logo): bool
    {
        $d = Qr::color($style['dark'] ?? null, '#000000'); $l = Qr::color($style['light'] ?? null, '#FFFFFF');
        return in_array($type, Qr::BASIC, true) && $d === '#000000' && $l === '#FFFFFF' && empty($style['round']) && !$logo;
    }

    /** A code's logo: in its owner's folder (a member's, or a guest's; decisions/0124); one from before where it was, until it moves. */
    /** A logo that arrived (api/upload.php, target go_logo), made into its small PNG, waiting for its code. Returns its id. */
    public static function logoWaiting(array $o, Upload $u): string
    {
        require_once __DIR__ . '/Qr.php'; require_once __DIR__ . '/Store.php';
        $id = bin2hex(random_bytes(8));
        $dest = Store::path($o['uid'] ? 'members' : 'guests', $o['uid'] ?: $o['guest'], 'qr-logos', 'waiting-' . $id . '.png', false);
        try { Qr::logoFromUpload($u->local(), $dest); } finally { $u->remove(); }
        $_SESSION['tv_go_logos'][$id] = $dest;
        $_SESSION['tv_go_logos'] = array_slice($_SESSION['tv_go_logos'], -10, null, true);
        return $id;
    }

    /** The waiting logo with this id, for this browser ('' if none). */
    public static function logoTaken(string $id): string
    {
        $p = (string) ($_SESSION['tv_go_logos'][$id] ?? '');
        unset($_SESSION['tv_go_logos'][$id]);
        return $p !== '' && is_file($p) ? $p : '';
    }

    public static function logoPath(int $id): string
    {
        require_once __DIR__ . '/Store.php';
        $old = __DIR__ . '/../storage/qr-logos/' . $id . '.png';
        return is_file($old) ? $old : (self::logoPlace(Database::connection(), $id) ?? $old);
    }

    public static function logoPlace(PDO $pdo, int $id): ?string
    {
        require_once __DIR__ . '/Store.php';
        $st = $pdo->prepare('SELECT user_id, guest_key FROM qr_issued WHERE id = ?'); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r || (!$r['user_id'] && !$r['guest_key'])) return null;
        return Store::path($r['user_id'] ? 'members' : 'guests', $r['user_id'] ? (int) $r['user_id'] : (string) $r['guest_key'], 'qr-logos', $id . '.png', false);
    }

    public static function look(array $row): array
    {
        $s = json_decode((string) $row['style'], true) ?: [];
        if (!empty($s['has_logo']) || is_file(self::logoPath((int) $row['id']))) {   // on the server, or in S3 (decisions/0123)
            require_once __DIR__ . '/Store.php';
            $logo = Store::local(self::logoPath((int) $row['id']));
            if ($logo !== '') $s['logo'] = $logo;
        }
        unset($s['has_logo']);
        return $s;
    }

    private static function cleanStyle(array $in): array
    {
        $d = Qr::color($in['dark'] ?? null, '#000000'); $l = Qr::color($in['light'] ?? null, '#FFFFFF');
        Qr::checkColors($d, $l);
        return ['dark' => $d, 'light' => $l, 'round' => !empty($in['round'])];
    }

    // ---- making and keeping ------------------------------------------------------------------------------------------

    /** Makes a code: issued at once when it's free, else into the cart at $4.95. Returns the row with 'free'. */
    public static function create(PDO $pdo, array $o, string $type, array $fields, array $style, string $title, string $logoTmp = ''): array
    {
        if ($o['uid'] <= 0 && $o['guest'] === '') throw new RuntimeException('Your browser didn\'t keep our cookie, so we can\'t hold a cart for you. Allow cookies for this site, or sign in.');
        if (($why = self::blocked($pdo, $o)) !== '') throw new RuntimeException($why);
        if (!isset(Qr::TYPES[$type])) throw new RuntimeException('Choose what the code should do.');
        $content = Qr::content($type, $fields);
        $style = self::cleanStyle($style);
        Qr::svg($content, $style);   // fits in one code
        $free = self::basic($type, $style, $logoTmp !== '') && self::freeLeft($pdo, $o) > 0;
        if (!$free) {
            [$w, $a] = self::whose($o);
            $st = $pdo->prepare("SELECT COUNT(*) FROM qr_issued WHERE $w AND status = 'cart'"); $st->execute($a);
            if ((int) $st->fetchColumn() >= self::MAX_CART) throw new RuntimeException('Your cart is full. Check out first, then add more.');
        }
        $pdo->prepare('INSERT INTO qr_issued (user_id, guest_key, type, fields, content, style, title, status, price_cents, issued_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$o['uid'] ?: null, $o['uid'] ? null : $o['guest'], $type, json_encode($fields, JSON_UNESCAPED_UNICODE), $content, json_encode($style),
                       mb_substr(trim($title), 0, 120) ?: Qr::TYPES[$type], $free ? 'free' : 'cart', $free ? 0 : self::PRICE_CENTS,
                       $free ? date('Y-m-d H:i:s') : null]);
        $id = (int) $pdo->lastInsertId();
        if ($free) self::issueShort($pdo, $id);
        if ($logoTmp !== '') {
            try { Qr::logoFromUpload($logoTmp, self::logoPath($id)); }
            catch (RuntimeException $e) { $pdo->prepare('DELETE FROM qr_issued WHERE id = ?')->execute([$id]); throw $e; }
            $pdo->prepare('UPDATE qr_issued SET style = ? WHERE id = ?')->execute([json_encode(['has_logo' => 1] + $style), $id]);   // so lists know without looking
            require_once __DIR__ . '/Store.php'; Store::keep(self::logoPath($id));
        }
        $r = self::get($pdo, $o, $id);
        $r['free'] = $free;
        return $r;
    }

    /** One of this owner's codes (or one in an order this visit opened by its link). */
    public static function get(PDO $pdo, array $o, int $id): array
    {
        [$w, $a] = self::whose($o);
        $ord = self::allowedOrders();
        $extra = $ord ? ' OR order_id IN (' . implode(',', $ord) . ')' : '';
        $st = $pdo->prepare("SELECT * FROM qr_issued WHERE id = ? AND status NOT IN ('removed', 'revoked') AND ($w$extra)"); $st->execute(array_merge([$id], $a));
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new RuntimeException('That code isn\'t here.');
        return $r;
    }

    public static function owned(array $r): bool { return in_array($r['status'], self::OWNED, true); }

    /** The owner's codes, newest first: owned, in the cart, and waiting for payment. */
    public static function listFor(PDO $pdo, array $o): array
    {
        [$w, $a] = self::whose($o);
        $ord = self::allowedOrders();
        $extra = $ord ? ' OR order_id IN (' . implode(',', $ord) . ')' : '';
        $st = $pdo->prepare("SELECT q.id, q.type, q.fields, q.style, q.title, q.status, q.price_cents, q.order_id, q.issued_at, q.created_at, q.short_code_id,
                                    s.code AS short_code, s.active AS short_active, s.scans
                             FROM qr_issued q LEFT JOIN short_codes s ON s.id = q.short_code_id
                             WHERE q.status NOT IN ('removed', 'revoked') AND (" . str_replace(['user_id', 'guest_key', 'order_id'], ['q.user_id', 'q.guest_key', 'q.order_id'], $w . $extra) . ") ORDER BY q.id DESC LIMIT 500");
        $st->execute($a);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if (in_array($r['status'], self::OWNED, true) && !$r['short_code_id'] && !in_array($r['type'], self::DIRECT, true)) {   // issued before codes routed through trvgo.us
                $r['short_code'] = self::issueShort($pdo, (int) $r['id']); $r['short_active'] = 1; $r['scans'] = 0;
            }
            $r['id'] = (int) $r['id'];
            $r['fields'] = json_decode((string) $r['fields'], true) ?: [];
            $r['style'] = json_decode((string) $r['style'], true) ?: [];
            $r['logo'] = !empty($r['style']['has_logo']) || is_file(self::logoPath((int) $r['id'])); unset($r['style']['has_logo']);
            $r['holds'] = self::holds((string) $r['type'], $r['fields']);
            $r['can_fix'] = $r['status'] === 'cart';   // once issued, our team corrects it (decisions/0098)
            $r['url'] = $r['short_code'] ? self::shortUrl((string) $r['short_code']) : '';
            $r['paused'] = $r['short_code'] && !(int) $r['short_active'];
            $r['scans'] = (int) ($r['scans'] ?? 0);
            unset($r['short_code_id'], $r['short_active']);
            $out[] = $r;
        }
        return $out;
    }

    /** Changes what it holds while it's in the cart. Once issued, our team corrects it (staffFix), the printed QR unchanged. */
    public static function fix(PDO $pdo, array $o, int $id, array $fields, string $title = ''): void
    {
        $r = self::get($pdo, $o, $id);
        if ($r['status'] !== 'cart') throw new RuntimeException('This code is issued. Need it changed? Write to support@traversence.com with what it should say: we\'ll correct it, and your printed code stays the same.');
        $content = Qr::content((string) $r['type'], $fields);
        $pdo->prepare('UPDATE qr_issued SET fields = ?, content = ?, title = COALESCE(NULLIF(?, \'\'), title) WHERE id = ?')
            ->execute([json_encode($fields, JSON_UNESCAPED_UNICODE), $content, mb_substr(trim($title), 0, 120), $id]);
    }

    public static function remove(PDO $pdo, array $o, int $id): void
    {
        $r = self::get($pdo, $o, $id);
        if ($r['status'] !== 'cart') throw new RuntimeException('Only a code in your cart can be removed.');
        $pdo->prepare("UPDATE qr_issued SET status = 'removed' WHERE id = ?")->execute([$id]);
        require_once __DIR__ . '/Store.php'; Store::remove(self::logoPath($id));
    }

    public static function cart(PDO $pdo, array $o): array
    {
        [$w, $a] = self::whose($o);
        $st = $pdo->prepare("SELECT id, type, title, price_cents FROM qr_issued WHERE $w AND status = 'cart' ORDER BY id");
        $st->execute($a);
        $items = array_map(fn ($i) => ['id' => (int) $i['id'], 'price_cents' => (int) $i['price_cents']] + $i, $st->fetchAll(PDO::FETCH_ASSOC));
        return ['items' => $items, 'subtotal_cents' => array_sum(array_column($items, 'price_cents'))];
    }

    /** The cart with a promotion (decisions/0108): each code's price after it, what it took off, the total off. */
    public static function withPromo(array $cart, ?array $promo): array
    {
        if (!$promo) return $cart + ['off_cents' => 0];
        require_once __DIR__ . '/Promotions.php';
        $off = 0;
        foreach ($cart['items'] as &$i) {
            [$i['price_cents'], $o] = Promotions::linePrice($promo, 'go_code', (int) $i['price_cents']);
            $i['off_cents'] = $o; $off += $o;
            if ($o) $i['title'] = (string) $i['title'] . ' (code ' . $promo['code'] . ')';
        }
        unset($i);
        $cart['subtotal_cents'] = array_sum(array_column($cart['items'], 'price_cents'));
        return $cart + ['off_cents' => $off];
    }

    // ---- orders ----------------------------------------------------------------------------------------------------

    /**
     * Checks out the cart, a member's or a guest's: an order, and its QuickBooks invoice (tax worked out there from the
     * address). Returns the order with 'pay_url' (QuickBooks' secure page) and 'access_token' (its Manage link).
     */
    public static function checkout(PDO $pdo, array $o, array $bill, ?array $promo = null): array
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        if (($why = self::blocked($pdo, $o)) !== '') throw new RuntimeException($why);
        if (!QuickBooksPay::open($pdo)) throw new RuntimeException('Buying opens soon. Your codes stay in your cart until then.');
        $b = [];
        foreach (['name' => 120, 'email' => 190, 'street' => 160, 'city' => 80, 'state' => 40, 'zip' => 12] as $k => $max) $b[$k] = mb_substr(trim((string) ($bill[$k] ?? '')), 0, $max);
        if ($b['name'] === '' || !filter_var($b['email'], FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Add your name and email: your receipt and your codes\' link go there.');
        if (!preg_match('/^\d{5}(-\d{4})?$/', $b['zip']) || $b['street'] === '' || $b['city'] === '' || $b['state'] === '') throw new RuntimeException('Add your billing address: sales tax depends on it.');
        $cart = self::withPromo(self::cart($pdo, $o), $promo);
        if (!$cart['items']) throw new RuntimeException('Your cart is empty.');
        if ($promo && !$cart['off_cents']) $promo = null;
        $token = bin2hex(random_bytes(20));
        $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO orders (user_id, guest_key, access_token, items, subtotal_cents, total_cents, bill_name, bill_email, bill_street, bill_city, bill_state, bill_zip, approved_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())')
                ->execute([$o['uid'] ?: null, $o['uid'] ? null : $o['guest'], $token, count($cart['items']), $cart['subtotal_cents'], $cart['subtotal_cents'], $b['name'], $b['email'], $b['street'], $b['city'], $b['state'], $b['zip']]);
            $oid = (int) $pdo->lastInsertId();
            [$w, $a] = self::whose($o);
            $ids = implode(',', array_column($cart['items'], 'id'));
            $pdo->prepare("UPDATE qr_issued SET status = 'pending', order_id = ? WHERE status = 'cart' AND $w AND id IN ($ids)")->execute(array_merge([$oid], $a));
            $ln = $pdo->prepare("INSERT INTO order_lines (order_id, product, ref_id, title, qty, unit_cents, approved_at) VALUES (?, 'go_code', ?, ?, 1, ?, NOW())
                                 ON DUPLICATE KEY UPDATE order_id = VALUES(order_id), title = VALUES(title), unit_cents = VALUES(unit_cents), status = 'open', approved_at = NOW()");
            foreach ($cart['items'] as $i) $ln->execute([$oid, (int) $i['id'], 'GO Code: ' . mb_substr((string) $i['title'], 0, 120), (int) $i['price_cents']]);
            if ($promo) {   // what the code took off each line, and the code on the order
                $po = $pdo->prepare("UPDATE order_lines SET promo_off_cents = ?, service_type = 'go_code' WHERE order_id = ? AND product = 'go_code' AND ref_id = ?");
                foreach ($cart['items'] as $i) $po->execute([(int) $i['off_cents'], $oid, (int) $i['id']]);
                $pdo->prepare('UPDATE orders SET promo_id = ? WHERE id = ?')->execute([(int) $promo['id'], $oid]);
                require_once __DIR__ . '/Promotions.php';
                Promotions::redeem($pdo, $promo, ['type' => $o['uid'] ? 'user' : 'guest', 'id' => (int) $o['uid'], 'email' => $b['email']], (int) $cart['off_cents'], $oid);
            }
            $pdo->commit();
        } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        self::allowOrder($oid);
        try {
            $inv = QuickBooksPay::invoice($pdo, $oid, $o['uid'] ?: 0, $b, $cart['items']);
        } catch (Throwable $e) {
            $pdo->prepare("UPDATE qr_issued SET status = 'cart', order_id = NULL WHERE order_id = ?")->execute([$oid]);
            $pdo->prepare("UPDATE orders SET status = 'void', note = ? WHERE id = ?")->execute([mb_substr('invoice failed: ' . $e->getMessage(), 0, 300), $oid]);
            $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE order_id = ?")->execute([$oid]);
            if ($promo) Promotions::release($pdo, $oid);   // the code can be used again
            error_log('go checkout: ' . $e->getMessage());
            throw new RuntimeException('Checkout couldn\'t start just now. Nothing was charged; your codes are still in your cart. Try again in a few minutes.');
        }
        $pdo->prepare('UPDATE orders SET invoice_id = ?, invoice_no = ?, pay_url = ?, tax_cents = ?, total_cents = ? WHERE id = ?')
            ->execute([$inv['id'], $inv['number'], $inv['pay_url'], $inv['tax_cents'], $inv['total_cents'], $oid]);
        try { $pdo->prepare('UPDATE orders SET qb_env = ? WHERE id = ?')->execute([QuickBooksPay::env(), $oid]); } catch (Throwable) {}   // before 2026-12-04_qb_checkout.sql
        require_once __DIR__ . '/Orders.php'; Orders::number($pdo, $oid);
        if (!empty($inv['customer_id'])) try { $pdo->prepare('UPDATE orders SET qb_customer_id = ? WHERE id = ?')->execute([$inv['customer_id'], $oid]); } catch (Throwable) {}   // before 2026-12-03_qb_refunds.sql
        require_once __DIR__ . '/Orders.php';
        Orders::event($pdo, $oid, 'placed', count($cart['items']) . ' GO Code' . (count($cart['items']) === 1 ? '' : 's') . ', invoice ' . $inv['number'] . ' sent for payment', $o['uid'] ?: null);
        return self::order($pdo, $o, $oid);
    }

    /**
     * Pays an order waiting for payment with the one-time card token from our checkout page's card form (the card number
     * itself went from the buyer's browser to Intuit, never here). One charge per order: a lock while it's paid, and
     * the same request key until a decline, so a double tap or a retry is never charged twice. The codes are issued at
     * once. Returns the order.
     */
    public static function payCard(PDO $pdo, array $o, int $oid, string $token): array
    {
        require_once __DIR__ . '/Orders.php';
        require_once __DIR__ . '/QuickBooksPay.php';
        $mine = self::order($pdo, $o, $oid);   // theirs, or "isn't here"
        if ((int) ($mine['created_by'] ?? 0) > 0) { require_once __DIR__ . '/ClientOrders.php'; throw new RuntimeException('This order is paid on its own page, where its deposit and balance are: ' . ClientOrders::url($mine) . ' Nothing was charged.'); }
        if (!preg_match('/^[A-Za-z0-9_.:-]{6,300}$/', $token)) throw new RuntimeException('The card details didn\'t come through. Try again.');
        if (!Orders::hasCol($pdo, 'charge_id') || !Orders::hasCol($pdo, 'qb_env')) {   // checked before anything is charged
            error_log('go pay: run app/migrations/2026-12-04_qb_checkout.sql');
            throw new RuntimeException('Card payment isn\'t switched on yet. Nothing was charged: use "Pay on QuickBooks\' page instead" below.');
        }
        $lock = $pdo->quote('tv-pay-' . $oid);
        if ((int) $pdo->query("SELECT GET_LOCK($lock, 15)")->fetchColumn() !== 1) throw new RuntimeException('This order is being paid already. Wait a moment.');
        try {
            $row = Orders::get($pdo, $oid);
            if ($row['status'] === 'paid') return self::order($pdo, $o, $oid);
            if ($row['status'] !== 'pending') throw new RuntimeException('This order can\'t be paid any more. Your codes are back in your cart.');
            Orders::sameEnv($row);
            $st = $pdo->prepare("SELECT COUNT(*) FROM order_events WHERE order_id = ? AND event = 'card_declined'"); $st->execute([$oid]);
            $key = 'pay-' . $oid . '-' . (int) $st->fetchColumn();
            try { $charge = QuickBooksPay::chargeCard($pdo, $row, $token, $key); }
            catch (RuntimeException $e) {
                if (str_contains($e->getMessage(), 'Nothing was charged')) Orders::event($pdo, $oid, 'card_declined', mb_substr($e->getMessage(), 0, 300));
                throw $e;
            }
            // the card is charged: from here on nothing may stop the order being marked paid
            $warn = '';
            try { $pdo->prepare('UPDATE orders SET charge_id = ? WHERE id = ?')->execute([$charge, $oid]); } catch (Throwable $e) { $warn = 'Card charge ' . $charge . ' wasn\'t saved on the order (' . $e->getMessage() . '). '; }
            $row['charge_id'] = $charge;
            try {
                $p = QuickBooksPay::recordCardPayment($pdo, $row, $charge, $key);
                if (!$p['linked']) $warn .= 'QuickBooks took the payment on invoice ' . $row['invoice_no'] . ' but not linked to card charge ' . $charge . ': check it matches the deposit.';
            } catch (Throwable $e) { $warn .= 'The card was charged (' . $charge . ') but QuickBooks didn\'t record the payment on invoice ' . $row['invoice_no'] . ' (' . $e->getMessage() . '): receive it there.'; }
            self::markPaid($pdo, $oid, 'card', 'card ' . $charge);
            if ($warn !== '') Orders::event($pdo, $oid, 'needs_books', $warn);
        } finally { $pdo->query("SELECT RELEASE_LOCK($lock)"); }
        return self::order($pdo, $o, $oid);
    }

    /** Back to the cart: an order not paid yet is cancelled by its buyer (its codes return to the cart). */
    public static function cancelMine(PDO $pdo, array $o, int $oid): void
    {
        $r = self::order($pdo, $o, $oid);
        if ($r['status'] !== 'pending' || !empty($r['charge_id'])) throw new RuntimeException('This order can\'t be changed now.');
        require_once __DIR__ . '/Orders.php';
        Orders::cancelUnpaid($pdo, $oid, 'Back to the cart, before paying' . ($r['invoice_no'] ? ': void invoice ' . $r['invoice_no'] . ' in QuickBooks' : ''), $o['uid'] ?: null);
    }

    public static function order(PDO $pdo, array $o, int $oid): array
    {
        [$w, $a] = self::whose($o);
        $ok = in_array($oid, self::allowedOrders(), true);
        $st = $pdo->prepare('SELECT * FROM orders WHERE id = ?' . ($ok ? '' : " AND $w")); $st->execute(array_merge([$oid], $ok ? [] : $a));
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new RuntimeException('That order isn\'t here.');
        return $r;
    }

    /** The order its private link points to (the receipt email's Manage link); this visit may then see it. */
    public static function byToken(PDO $pdo, string $t): ?array
    {
        if (!preg_match('/^[a-f0-9]{40}$/', $t)) return null;
        $st = $pdo->prepare('SELECT * FROM orders WHERE access_token = ?'); $st->execute([$t]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if ($r) self::allowOrder((int) $r['id']);
        return $r ?: null;
    }

    /** The owner's orders (and those opened by link): waiting or paid, newest first. */
    public static function orders(PDO $pdo, array $o): array
    {
        [$w, $a] = self::whose($o);
        $ord = self::allowedOrders();
        $extra = $ord ? ' OR id IN (' . implode(',', $ord) . ')' : '';
        $st = $pdo->prepare("SELECT id, status, items, subtotal_cents, tax_cents, total_cents, pay_url, invoice_no, bill_name, bill_email, created_at, paid_at FROM orders
                             WHERE status IN ('pending', 'paid', 'part_refunded', 'refunded', 'disputed') AND (created_by IS NULL OR created_by = 0) AND ($w$extra) ORDER BY id DESC LIMIT 30");   // an order our team built for a client is paid on its own page, with its deposit and balance (decisions/0101), never here
        $st->execute($a);
        $out = $st->fetchAll(PDO::FETCH_ASSOC);
        if ($out) {   // what each order bought, refunded lines included (they're no longer in the codes list)
            $ids = implode(',', array_map(fn ($o) => (int) $o['id'], $out));
            $lines = [];
            foreach ($pdo->query("SELECT order_id, ref_id, title, status FROM order_lines WHERE order_id IN ($ids) ORDER BY id")->fetchAll(PDO::FETCH_ASSOC) as $l)
                $lines[(int) $l['order_id']][] = ['code_id' => (int) $l['ref_id'], 'title' => preg_replace('/^GO Code: /', '', (string) $l['title']), 'status' => (string) $l['status']];
            foreach ($out as &$o) $o['lines'] = $lines[(int) $o['id']] ?? [];
            unset($o);
        }
        return $out;
    }

    /** Orders waiting for payment: asks QuickBooks again (at most every 5 seconds each) and issues what's paid. */
    public static function refresh(PDO $pdo, array $o): int
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $n = 0;
        foreach (self::orders($pdo, $o) as $r) {
            if ($r['status'] !== 'pending') continue;
            $st = $pdo->prepare('UPDATE orders SET checked_at = NOW() WHERE id = ? AND (checked_at IS NULL OR checked_at < ?)');
            $st->execute([(int) $r['id'], date('Y-m-d H:i:s', time() - 5)]);
            if (!$st->rowCount()) continue;
            try { if (self::checkPaid($pdo, (int) $r['id'])) $n++; } catch (Throwable $e) { error_log('go refresh: ' . $e->getMessage()); }
        }
        return $n;
    }

    public static function manageUrl(array $order): string
    {
        return rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/qr/manage.php?t=' . $order['access_token'];
    }

    /**
     * Asks QuickBooks about an order's invoice and records what came in. A client order (decisions/0101) records each part
     * payment as it arrives (ClientOrders::fromQuickBooks, note of 2026-11-20, B.3); any other order only once it's paid in
     * full, as before. True when something was recorded.
     */
    public static function checkPaid(PDO $pdo, int $oid): bool
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $c = $pdo->prepare('SELECT created_by FROM orders WHERE id = ?'); $c->execute([$oid]);
        if ((int) $c->fetchColumn() > 0) { require_once __DIR__ . '/ClientOrders.php'; return ClientOrders::fromQuickBooks($pdo, $oid) !== ''; }
        if (!QuickBooksPay::paid($pdo, $oid)) return false;
        self::markPaid($pdo, $oid);
        return true;
    }

    /** An order is paid: its codes are issued (each through trvgo.us), the ledger records it, the receipt goes out. Safe to call twice. */
    public static function markPaid(PDO $pdo, int $oid, string $method = 'quickbooks', string $ref = ''): void
    {
        $c = $pdo->prepare('SELECT created_by FROM orders WHERE id = ?'); $c->execute([$oid]);
        if ((int) $c->fetchColumn() > 0) {   // an order our team built for a client (decisions/0101): paid in QuickBooks
            require_once __DIR__ . '/ClientOrders.php';
            ClientOrders::paidInQuickBooks($pdo, $oid);
            return;
        }
        $st = $pdo->prepare("UPDATE orders SET status = 'paid', paid_at = NOW() WHERE id = ? AND status = 'pending'");
        $st->execute([$oid]);
        if (!$st->rowCount()) return;
        $pdo->prepare("UPDATE qr_issued SET status = 'paid', issued_at = NOW() WHERE order_id = ? AND status = 'pending'")->execute([$oid]);
        $ids = $pdo->prepare("SELECT id FROM qr_issued WHERE order_id = ? AND status = 'paid'"); $ids->execute([$oid]);
        foreach ($ids->fetchAll(PDO::FETCH_COLUMN) as $id) self::issueShort($pdo, (int) $id);
        $pdo->prepare("UPDATE order_lines SET status = 'done' WHERE order_id = ? AND status = 'open'")->execute([$oid]);
        require_once __DIR__ . '/Orders.php';
        $ord = Orders::get($pdo, $oid);
        Orders::record($pdo, $oid, 'charge', (int) $ord['total_cents'], 'charge-' . $oid, $method, mb_substr(trim((string) $ord['invoice_no'] . ($ref !== '' ? ' · ' . $ref : ''), ' ·'), 0, 60), $method === 'card' ? 'Card on our checkout page' : 'Invoice paid');
        Orders::event($pdo, $oid, 'paid', 'Paid ' . Orders::usd((int) $ord['total_cents']) . ($method === 'card' ? ' by card on our checkout page' : '') . ' (invoice ' . $ord['invoice_no'] . ($ref !== '' ? ', ' . $ref : '') . '); codes issued');
        try {
            require_once __DIR__ . '/Mailer.php';
            $o = $ord;
            $site = rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/');
            $guest = !$o['user_id'];
            Mailer::send((string) $o['bill_email'], 'Your GO Codes are ready',
                'Thank you for your order (' . (int) $o['items'] . ' GO Code' . ((int) $o['items'] === 1 ? '' : 's') . ', $' . number_format($o['total_cents'] / 100, 2) . " with tax).\n\n"
                . "Download them any time from Manage GO Codes:\n" . self::manageUrl($o) . "\n(Keep this link: it opens your codes on any device.)\n\n"
                . "Each code's link goes through trvgo.us, so you'll see how often it's scanned. Spotted a mistake in one? Reply to this email: we'll correct it, and your printed code stays the same.\n"
                . ($guest ? "\nCreate a free Traversence account with this email to keep all your GO Codes in one place and get 5 free codes:\n$site/register.php?email=" . rawurlencode((string) $o['bill_email']) . "&next=%2Fqr%2Fmanage.php\n" : '')
                . "\nQuestions about your order? Reply to this email, or write to support@traversence.com.\n"
                . "\nTraversence", (string) $o['bill_name']);
        } catch (Throwable $e) { error_log('go paid email: ' . $e->getMessage()); }
    }

    /**
     * A guest becomes a member (signed in or new account): this browser's cart, codes and orders move into the account,
     * and so do guest orders paid with the account's email, once that email is confirmed. Returns how many codes moved.
     */
    public static function claim(PDO $pdo, int $uid, string $guestKey = ''): int
    {
        if ($uid <= 0 || !self::ready($pdo)) return 0;
        $n = 0;
        try {
            if ($guestKey !== '') {
                $st = $pdo->prepare('UPDATE qr_issued SET user_id = ?, guest_key = NULL WHERE user_id IS NULL AND guest_key = ?'); $st->execute([$uid, $guestKey]); $n += $st->rowCount();
                $pdo->prepare('UPDATE orders SET user_id = ?, guest_key = NULL WHERE user_id IS NULL AND guest_key = ?')->execute([$uid, $guestKey]);
            }
            $u = $pdo->prepare('SELECT email, email_verified_at FROM users WHERE id = ?'); $u->execute([$uid]); $u = $u->fetch(PDO::FETCH_ASSOC);
            if ($u && $u['email_verified_at'] !== null) {
                $st = $pdo->prepare('SELECT id FROM orders WHERE user_id IS NULL AND LOWER(bill_email) = LOWER(?)'); $st->execute([(string) $u['email']]);
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $oid) {
                    $pdo->prepare('UPDATE orders SET user_id = ?, guest_key = NULL WHERE id = ?')->execute([$uid, (int) $oid]);
                    $s2 = $pdo->prepare('UPDATE qr_issued SET user_id = ?, guest_key = NULL WHERE order_id = ? AND user_id IS NULL'); $s2->execute([$uid, (int) $oid]); $n += $s2->rowCount();
                }
            }
        } catch (Throwable $e) { error_log('go claim: ' . $e->getMessage()); }
        return $n;
    }

    // ---- our team ----------------------------------------------------------------------------------------------------

    public static function grant(PDO $pdo, int $staff, int $id): void
    {
        $st = $pdo->prepare("UPDATE qr_issued SET status = 'granted', granted_by = ?, price_cents = 0, issued_at = NOW(), order_id = NULL WHERE id = ? AND status IN ('cart', 'pending')");
        $st->execute([$staff, $id]);
        if (!$st->rowCount()) throw new RuntimeException('That code isn\'t in a cart any more.');
        self::issueShort($pdo, $id);
    }

    // ---- through TRVGO (decisions/0098) ------------------------------------------------------------------------------

    public static function shortUrl(string $code): string
    {
        require_once __DIR__ . '/ShortCodes.php';
        return ShortCodes::url($code);
    }

    /** What a code does, in a line people can read ("Calls 505-555-1234", "Opens example.com"). */
    public const KIND = ['vcard' => 'Contact card', 'link' => 'Link', 'event' => 'Calendar event', 'phone' => 'Phone call', 'sms' => 'Text message',
                         'email' => 'Email', 'text' => 'Text', 'wifi' => 'Wi-Fi'];

    /**
     * Everything a code holds, as it will arrive, as HTML (for a proof): a contact card as a card (name, job title and
     * business, then each phone, email, website, the address on one line, the note), any other kind field by field.
     * Class names: .gc-v (name block), .gc-dl (the list). Unstyled; the page styles it.
     */
    public static function detailsHtml(string $type, array $f): string
    {
        $h = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES);
        $g = fn (string $k) => trim((string) ($f[$k] ?? ''));
        $rows = '';
        $place = trim(implode(' ', array_filter([$g('city') . ($g('state') !== '' && $g('city') !== '' ? ',' : ''), $g('state'), $g('zip')])));
        foreach (self::FIELDS[$type] ?? [] as $k => $lab) {
            $v = $g($k);
            if ($type === 'vcard') {
                if (in_array($k, ['name', 'org', 'title', 'city', 'state', 'zip', 'country'], true)) continue;
                if ($k === 'street') { $v = implode(', ', array_filter([$v, $place, $g('country')])); $lab = 'Address'; }
            }
            if ($v === '') continue;
            $rows .= '<dt>' . $h(preg_replace('/\s*\(.*\)$/', '', $lab)) . '</dt><dd>' . nl2br($h($v)) . '</dd>';
        }
        $head = $type === 'vcard' ? '<div class="gc-v"><b>' . $h($g('name')) . '</b>' . (($t = implode(' · ', array_filter([$g('title'), $g('org')]))) !== '' ? '<span>' . $h($t) . '</span>' : '') . '</div>' : '';
        return $head . ($rows !== '' ? '<dl class="gc-dl">' . $rows . '</dl>' : '');
    }

    public static function holds(string $type, array $f): string
    {
        $g = fn (string $k) => trim((string) ($f[$k] ?? ''));
        $phone = function (string $n): string { $d = preg_replace('/\D/', '', $n); return strlen($d) === 10 ? substr($d, 0, 3) . '-' . substr($d, 3, 3) . '-' . substr($d, 6) : $n; };
        switch ($type) {
            case 'link': return 'Opens ' . preg_replace('#^https?://(www\.)?#i', '', $g('url'));
            case 'phone': return 'Calls ' . $phone($g('phone'));
            case 'sms': return 'Texts ' . $phone($g('phone')) . ($g('message') !== '' ? ': "' . mb_strimwidth($g('message'), 0, 60, '…') . '"' : '');
            case 'email': return 'Emails ' . $g('email') . ($g('subject') !== '' ? ' (subject "' . mb_strimwidth($g('subject'), 0, 40, '…') . '")' : '');
            case 'wifi': return 'Joins the Wi-Fi network "' . $g('ssid') . '"';
            case 'text': return 'Shows: "' . mb_strimwidth($g('text'), 0, 80, '…') . '"';
            case 'vcard': return 'Saves the contact ' . implode(' · ', array_filter([$g('name'), $g('org'), $g('phone') !== '' ? $phone($g('phone')) : '', $g('email')]));
            case 'event':
                $when = $g('date') !== '' ? date('M j, Y', strtotime($g('date'))) . ($g('time') !== '' ? ' ' . date('g:i a', strtotime($g('date') . ' ' . $g('time'))) : '') : '';
                return 'Adds "' . $g('title') . '" to the calendar' . ($when !== '' ? ', ' . $when : '') . ($g('location') !== '' ? ', ' . $g('location') : '');
        }
        return '';
    }

    /** Gives an issued code its trvgo.us short code (once; not Wi-Fi). Returns the code ('' for Wi-Fi). */
    public static function issueShort(PDO $pdo, int $id): string
    {
        $st = $pdo->prepare('SELECT q.id, q.type, q.title, q.short_code_id, s.code FROM qr_issued q LEFT JOIN short_codes s ON s.id = q.short_code_id WHERE q.id = ?');
        $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r || in_array($r['type'], self::DIRECT, true)) return '';
        if ($r['code']) return (string) $r['code'];
        require_once __DIR__ . '/ShortCodes.php';
        $c = ShortCodes::issueGo($pdo, $id, (string) $r['title']);
        $pdo->prepare('UPDATE qr_issued SET short_code_id = ? WHERE id = ? AND short_code_id IS NULL')->execute([(int) $c['id'], $id]);
        return (string) $c['code'];
    }

    /** What the QR itself holds: its trvgo.us address, or (Wi-Fi, or a code not issued yet) what it holds directly. */
    public static function qrData(PDO $pdo, array $row): string
    {
        // GO_DIRECT=on in .env (Terms "If Traversence closes"): every download holds what it does directly, no trvgo.us
        $direct = strtolower(trim((string) (getenv('GO_DIRECT') ?: ($_ENV['GO_DIRECT'] ?? '')))) === 'on';
        // a code on a client order has its address before it's paid (decisions/0101): the proof shows the real QR
        if (!$direct && (in_array($row['status'], self::OWNED, true) || ($row['status'] === 'pending' && !empty($row['short_code_id']))) && !in_array($row['type'], self::DIRECT, true)) {
            $code = self::issueShort($pdo, (int) $row['id']);
            if ($code !== '') return self::shortUrl($code);
        }
        return (string) $row['content'];
    }

    /** Our team corrects an issued code (decisions/0098: no self-fix window; the printed QR stays the same). */
    public static function staffFix(PDO $pdo, int $id, array $fields, string $title, int $staff): array
    {
        $st = $pdo->prepare('SELECT * FROM qr_issued WHERE id = ?'); $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) throw new RuntimeException('That code isn\'t here.');
        $before = json_decode((string) $r['fields'], true) ?: [];
        $content = Qr::content((string) $r['type'], $fields);
        if (in_array($r['type'], self::DIRECT, true) && self::owned($r)) Qr::svg($content, ['ecc' => 'M']);   // a Wi-Fi code's QR changes: still fits
        $pdo->prepare('UPDATE qr_issued SET fields = ?, content = ?, title = COALESCE(NULLIF(?, \'\'), title) WHERE id = ?')
            ->execute([json_encode($fields, JSON_UNESCAPED_UNICODE), $content, mb_substr(trim($title), 0, 120), $id]);
        $changed = [];
        foreach (array_unique(array_merge(array_keys($before), array_keys($fields))) as $k) if ((string) ($before[$k] ?? '') !== (string) ($fields[$k] ?? '')) $changed[] = $k;
        return ['changed' => $changed, 'direct' => in_array($r['type'], self::DIRECT, true), 'order_id' => (int) ($r['order_id'] ?? 0)];
    }

    /** A refunded or charged-back code: switched off (trvgo.us shows "not active") and out of the buyer's list. */
    public static function revoke(PDO $pdo, int $id, string $why): void
    {
        $pdo->prepare("UPDATE qr_issued SET status = 'revoked' WHERE id = ? AND status IN ('paid', 'granted', 'free')")->execute([$id]);
        $pdo->prepare('UPDATE short_codes s JOIN qr_issued q ON q.short_code_id = s.id SET s.active = 0, s.off_reason = ? WHERE q.id = ?')->execute(['staff: ' . $why, $id]);
    }

    /** A disputed order's code is paused (or restored when the dispute is won). */
    public static function pause(PDO $pdo, int $id, bool $off): void
    {
        $pdo->prepare('UPDATE short_codes s JOIN qr_issued q ON q.short_code_id = s.id SET s.active = ?, s.off_reason = ? WHERE q.id = ?')
            ->execute([$off ? 0 : 1, $off ? 'staff: payment disputed' : '', $id]);
    }

    public static function voidOrder(PDO $pdo, int $oid, string $why = ''): void
    {
        $pdo->prepare("UPDATE orders SET status = 'void', note = ? WHERE id = ? AND status = 'pending'")->execute([mb_substr($why, 0, 300), $oid]);
        $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE order_id = ?")->execute([$oid]);
        $pdo->prepare("UPDATE qr_issued SET status = 'cart', order_id = NULL WHERE order_id = ? AND status = 'pending'")->execute([$oid]);
        { require_once __DIR__ . '/Promotions.php'; if (Promotions::ready($pdo)) Promotions::release($pdo, $oid); }   // a promo code used on it can be used again
    }
}
