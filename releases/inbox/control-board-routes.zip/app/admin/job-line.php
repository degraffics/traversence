<?php
// app/admin/job-line.php — scheduled tasks and the admin pages they serve, linked both ways (Jason, 2026-11-17: the
// Pre-flight task and its page had no way to reach each other, a dead end). On System Configuration → Scheduled tasks
// each task's card has "Open <page>"; on each page a task serves, a slim line under the command bar says when it runs,
// when it last ran and "Change", which opens that task's card (/admin/config/scheduler#job-<key>). One helper for every
// page: tv_w_section() (app/admin/widgets.php) draws it above the section, so a page gets it by being in the map below.
declare(strict_types=1);

require_once __DIR__ . '/../lib/Scheduler.php';
if (!function_exists('tv_w_e')) require_once __DIR__ . '/widgets.php';   // tv_w_e(), Modules

/**
 * Each scheduled task (Scheduler::JOBS key) => the admin page it belongs to, 'module/section' (app/admin/manifests.php).
 * A task with no page of its own isn't listed: files_tick (files to S3), notice_digest (members' own notices),
 * region_tick (the sign-up check's address ranges), like_watch_tick, earned_storage_tick, guest_tick (members' likes and
 * storage, no admin page), audit_clock_tick (the audit runs on GitHub; Site health is a Pulse case) and staging_tick (stopped, does nothing). A new job with a
 * page is added here when it's added to Scheduler::JOBS.
 */
function tv_job_pages(): array
{
    return [
        'ai_worker' => 'growth/cards',                  // scanned business cards now; menus and brochures with the Studio
        'standing_tick' => 'social/standing',
        'sales_tick' => 'growth/calls',
        'work_orders_tick' => 'backoffice/work_orders',
        'guide_finds_tick' => 'explore/place_guides',
        'listings_tick' => 'local/review',
        'guide_live_tick' => 'explore/place_guides',
        'got_it_tick' => 'backoffice/orders',
        'pay_wait_tick' => 'backoffice/orders',
        'services_tick' => 'config/register',
        'takedowns_tick' => 'social/takedowns',
        'heritage_tick' => 'insights/topics',
        'daily_report' => 'dashboard/streamset',        // the hour is set in Stream settings (Pulse's copy shows it too)
        'market_tick' => 'market/items',
        'ses_setup_tick' => 'config/services',
        'domains_tick' => 'market/domains',
        'billing_tick' => 'backoffice/plans',
        'guide_ondemand_tick' => 'explore/place_guides',
        'journeys_tick' => 'explore/journeys',
        'supabase_keepalive' => 'config/services',
        'page_read_tick' => 'config/ai',
        'vectors_tick' => 'config/ai',
        'identity_recheck_tick' => 'local/identities',
        'data_cleanup_tick' => 'insights/cleanup',
        'landmark_photos_tick' => 'local/places',
        'moments_tick' => 'social/galleries',
        'vault_digest_tick' => 'config/vault',
        'releases_tick' => 'config/releases',
        'staging_carry_tick' => 'config/staging',
        'staging_push_tick' => 'config/staging',
        'staging_night_tick' => 'config/staging',
        'staging_publish_tick' => 'config/staging',
        'frontier_tick' => 'insights/index',
        'preflight_tick' => 'config/preflight',
        'system_start_tick' => 'config/automation',
    ];
}

/** The html widgets a section is drawn with: the same page shown in two modules (Pulse's Stream settings in the
 *  Dashboard and in Pulse) gets the same line. */
function tv_job_section_fns(string $mk, string $sk): array
{
    $s = Modules::all()[$mk]['sections'][$sk] ?? null;
    if (!$s) return [];
    $out = [];
    foreach ((array) ($s['widgets'] ?? []) as $w) if (($w[0] ?? '') === 'html') $out[] = (string) $w[1];
    return $out;
}

/** The tasks that serve a page, in Scheduler::JOBS order. */
function tv_jobs_for(string $mk, string $sk): array
{
    $here = $mk . '/' . $sk; $fns = tv_job_section_fns($mk, $sk); $out = [];
    foreach (tv_job_pages() as $job => $page) {
        if (!isset(Scheduler::JOBS[$job])) continue;
        if ($page === $here) { $out[] = $job; continue; }
        [$pm, $ps] = explode('/', $page, 2);
        if ($fns && array_intersect($fns, tv_job_section_fns($pm, $ps))) $out[] = $job;
    }
    return $out;
}

/** Where each task's cron line stands, as the Scheduled tasks page last read it from cPanel (that page writes it, so a
 *  page showing the line never waits on cPanel's API): job => words ('' when it isn't set up in cPanel). */
function tv_job_schedules_file(): string { return __DIR__ . '/../storage/job-schedules.json'; }

function tv_job_remember(array $lines): void
{
    $out = [];
    foreach (array_keys(Scheduler::JOBS) as $job) { $l = Scheduler::lineFor($lines, $job); $out[$job] = $l ? Scheduler::words($l) : ''; }
    $f = tv_job_schedules_file();
    if (!is_dir(dirname($f))) @mkdir(dirname($f), 0755, true);
    @file_put_contents($f, json_encode(['at' => gmdate('c'), 'jobs' => $out]), LOCK_EX);
}

/** When a task runs, in words: cPanel's line as last read, else its usual time (said so). */
function tv_job_when(string $job): string
{
    static $known = null;
    if ($known === null) { $j = @json_decode((string) @file_get_contents(tv_job_schedules_file()), true); $known = is_array($j['jobs'] ?? null) ? $j['jobs'] : []; }
    if (array_key_exists($job, $known)) return $known[$job] !== '' ? lcfirst((string) $known[$job]) : 'not set up in cPanel';
    return lcfirst(Scheduler::PRESETS[Scheduler::JOBS[$job][2]][0] ?? 'on its own schedule') . ' (its usual time)';
}

/** "Open <page>" for a task's card on the Scheduled tasks page; greyed with the reason when the person can't open it. */
function tv_admin_job_open(string $job): string
{
    $page = tv_job_pages()[$job] ?? '';
    if ($page === '') return '';
    [$pm, $ps] = explode('/', $page, 2);
    $label = (string) (Modules::all()[$pm]['sections'][$ps]['label'] ?? '');
    if ($label === '') return '';
    [$ok, $why] = Modules::canSection($pm, $ps);
    return $ok ? '<a class="ak-b" href="' . tv_w_e(Modules::url($pm, $ps)) . '">Open ' . tv_w_e($label) . '</a>'
               : '<button type="button" class="ak-b" disabled title="' . tv_w_e($why) . '">Open ' . tv_w_e($label) . '</button>';
}

/** The line on a page a task serves: "Runs: every 15 minutes · last ran 7 minutes ago, Nov 17, 10:05 AM MST · Change". */
function tv_admin_job_line(PDO $pdo, string $mk, string $sk): string
{
    if ($mk === 'config' && $sk === 'scheduler') return '';
    try { $jobs = tv_jobs_for($mk, $sk); } catch (Throwable $e) { return ''; }
    if (!$jobs) return '';
    $runs = [];
    try {
        Scheduler::ensure($pdo);
        $t = Database::t('job_runs'); $in = implode(',', array_fill(0, count($jobs), '?'));
        $st = $pdo->prepare("SELECT r.job, r.started_at, r.finished_at, r.ok FROM $t r JOIN (SELECT MAX(id) id FROM $t WHERE job IN ($in) GROUP BY job) x ON x.id = r.id");
        $st->execute($jobs);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $runs[$r['job']] = $r;
    } catch (Throwable $e) { error_log('job line: ' . $e->getMessage()); }
    [$can, $why] = Access::can('config.scheduler.edit', ['min' => 'director', 'depts' => ['eng', 'ops']]);   // the Scheduled tasks page's own rule
    $ago = function (int $s): string { return $s < 90 ? 'just now' : ($s < 5400 ? round($s / 60) . ' minutes ago' : ($s < 172800 ? round($s / 3600) . ' hours ago' : round($s / 86400) . ' days ago')); };
    $h = '';
    foreach ($jobs as $job) {
        [$name, , , $lateMin] = Scheduler::JOBS[$job];
        $r = $runs[$job] ?? null; $when = tv_job_when($job);
        // a task that looks often but acts only on a condition says both, so "every 15 minutes" isn't read as a full run
        // (Jason, 2026-11-19: "Pre-flight is a pre-system launch check vs every 15 mins?")
        $full = '';
        if ($job === 'preflight_tick') { $when = 'it looks ' . $when . ', and runs every test only at 2 am Arizona time, after a .env change, or when you press Run all';
            try { require_once __DIR__ . '/../lib/Preflight.php'; $fa = (int) (Preflight::summary($pdo)['at'] ?? 0); } catch (Throwable $x) { $fa = 0; }
            $full = ' · last full run ' . ($fa ? '<time datetime="' . tv_w_e(date('c', $fa)) . '" data-tv-time>' . tv_w_e(date('M j, g:i A T', $fa)) . '</time>' : 'none yet'); }
        $failed = $r && $r['ok'] !== null && !(int) $r['ok'];
        $at = $r ? strtotime((string) $r['started_at']) : 0;
        $late = $r && $at < time() - (int) $lateMin * 60;
        $last = $r ? ($full !== '' ? 'last looked ' : 'last ran ') . $ago(max(0, time() - $at)) . ', <time datetime="' . tv_w_e(date('c', $at)) . '" data-tv-time>' . tv_w_e(date('M j, g:i A T', $at)) . '</time>' . ($failed ? ', and stopped' : ($late ? ', and is late' : ''))
                   : 'no run recorded yet';
        $tone = $failed || $late || $when === 'not set up in cPanel' ? 'bad' : 'ok';
        $change = $can ? '<a href="/admin/config/scheduler#job-' . tv_w_e($job) . '">Change</a>'
                       : '<span class="tv-jl-off" aria-disabled="true" title="' . tv_w_e($why) . '">Change</span>' . ($h === '' ? ' <small class="tv-jl-off">(' . tv_w_e($why) . ')</small>' : '');   // the reason once a page
        $label = count($jobs) > 1 ? 'Runs (' . $name . '):' : 'Runs:';
        // a slim line while it's running as it should; one that stopped, is late or isn't set up is the site's notice box
        $h .= '<p class="tv-jl"' . ($tone === 'bad' ? ' data-tv-status="bad"' : '') . ' data-tv-label="' . tv_w_e($label) . '" title="' . tv_w_e($name . ', a scheduled task') . '">'
            . ($tone === 'bad' ? '' : '<b>' . tv_w_e($label) . '</b> ') . tv_w_e($when) . ' · ' . $last . $full . ' · ' . $change . '</p>';
    }
    static $once = false;
    $foot = '';
    if (!$once) {
        $once = true;
        $foot = '<style>.tv-jls{margin:0 0 .5rem}.tv-jl{margin:.1rem 0;font-size:.82rem;color:#5C4632}.tv-jl b{font-weight:700}.tv-jl a{color:#92400E;text-decoration:underline}.tv-jl-off{color:#8A7355;opacity:.6;cursor:not-allowed}.tv-jl small.tv-jl-off{cursor:default}</style>'
            . '<script src="/js/tv-time.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/tv-time.js') . '"></script>'
            . '<script' . (function_exists('tv_nonce') ? tv_nonce() : '') . '>if(window.TvTime)TvTime.paint();</script>';   // tv-time.js already loaded earlier on the page: paint these too
    }
    return '<div class="tv-jls">' . $h . '</div>' . $foot;
}
