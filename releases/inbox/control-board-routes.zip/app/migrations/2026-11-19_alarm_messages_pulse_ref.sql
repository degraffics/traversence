-- control-board-routes (2026-11-19): a Control Board alarm's message is shown by its alarm's own Pulse item (or its
-- group's), so the stream doesn't list it a second time (decisions/0171 §8, "the board and Pulse are one thing"). The
-- messages already sent get the same mark; their emails were sent and stay as they were. Safe to run twice.
UPDATE comms_messages SET pulse_ref = thing WHERE kind IN ('alarm.trip', 'alarm.warning') AND pulse_ref IS NULL AND thing LIKE 'alarm:%';
