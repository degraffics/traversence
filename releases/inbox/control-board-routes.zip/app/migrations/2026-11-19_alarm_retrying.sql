-- control-board-routes (2026-11-19, 0171 §5's note): a critical part's trip while the system is still trying. Safe twice;
-- nothing to do where the table isn't made yet (ControlAlarms::ensure makes it with the column).
SET @s = (SELECT IF(COUNT(*) = 0 AND (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'control_alarms') = 1,
  'ALTER TABLE control_alarms ADD COLUMN retrying_at DATETIME NULL DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'control_alarms' AND COLUMN_NAME = 'retrying_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
