/* Long settings kept whole (2026-11-17). search_index_state.v was VARCHAR(200) (2026-10-02_search_index.sql), and the
   server cuts a longer value short without an error: Start the system's state (SystemStart, a JSON document with its log),
   the pre-flight's W0 test ask, W0's flagged list and size history, Geofabrik's test results, the identity check's last
   run, the worker's key report, search presets and Gemini's comparison were cut and read back as nothing. MEDIUMTEXT holds
   them whole. Safe to run twice: it changes the column only while it isn't MEDIUMTEXT yet; no rows change. */
SET @s = (SELECT IF(COUNT(*) = 1, 'ALTER TABLE search_index_state MODIFY v MEDIUMTEXT NOT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'search_index_state' AND COLUMN_NAME = 'v' AND DATA_TYPE <> 'mediumtext');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
