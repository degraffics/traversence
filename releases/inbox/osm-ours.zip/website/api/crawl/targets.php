<?php
// api/crawl/targets.php — crawler targets from search demand (decisions/0066).
//   GET ?limit=2 -> {targets: [{target_id, looking_for: {group, osm, offerings}, place: {name, towns, zips, zip_points, center},
//                   ours?, ours_note?}]}   (ours: what our OpenStreetMap copy holds for it, by filter; OpenPlaces::forJob)
//   POST {target_id, candidates: [...], pages, log, error?} -> {staged, already_known}   (held in Listing Intake for a person)

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/crawler/CrawlTargets.php';
require_once __DIR__ . '/../../../app/lib/OpenPlaces.php';

try {
    if (!CrawlTargets::ready($pdo)) Response::json(['ok' => true, 'targets' => [], 'note' => 'crawl_targets not set up (run 2026-11-06_search_demand.sql)']);
    if ($_SERVER['REQUEST_METHOD'] === 'GET') Response::json(['ok' => true, 'targets' => OpenPlaces::attach($pdo, CrawlTargets::lease($pdo, (int) ($_GET['limit'] ?? 2)))]);
    Response::requireMethod('POST');
    $b = Response::jsonBody();
    Response::json(['ok' => true] + CrawlTargets::complete($pdo, (int) ($b['target_id'] ?? 0), (array) ($b['candidates'] ?? []), (int) ($b['pages'] ?? 0), (array) ($b['log'] ?? []), (string) ($b['error'] ?? '')));
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'bad_request');
}
