<?php
// api/crawl/jobs.php — GET: the next few crawl jobs for the off-site worker (decisions/0044).
//   GET /api/crawl/jobs.php?limit=2   Authorization: Bearer <CRAWLER_API_TOKEN>
// Returns {"paused": bool, "jobs": [...]}; each job carries the place and what to look for, with a lease, and what our
// OpenStreetMap copy holds for it ("ours": {filter: [elements]}, "ours_note"; OpenPlaces::forJob): Overpass only for the rest.

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
Response::requireMethod('GET');

require_once __DIR__ . '/../../../app/lib/OpenPlaces.php';
Response::json(['paused' => CrawlQueue::paused(), 'jobs' => OpenPlaces::attach($pdo, CrawlQueue::lease($pdo, (int) ($_GET['limit'] ?? 2)))]);
