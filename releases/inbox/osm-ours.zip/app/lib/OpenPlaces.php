<?php

declare(strict_types=1);

require_once __DIR__ . '/SearchIndex.php';

/**
 * Businesses from OpenStreetMap, only where we have no listings yet (decisions/0065). For a place outside our regions
 * ("Seattle, WA"), a need or a search that names a kind of business ("Storage", "pizza") asks OpenStreetMap's Overpass
 * service once for that kind around the town, and keeps the answer for about a week (open_places). Shown as
 * OpenStreetMap's, with its credit; never a listing, never in our directory.
 *
 * Its own layer (Jason, 2026-11-10: "Use openstreetmap for everything we can get for sources and data as long as we
 * dont have to share back data"): kept in its own tables, shown as OpenStreetMap's with its credit (name, kind, address,
 * phone, hours, website), never copied into our listings or landmarks, so the licence (ODbL) never asks us to share our
 * own data back (its "collective database" and "horizontal layers" guidance). Businesses, and since 2026-11-10 the
 * outdoors too: trailheads, parks and preserves, viewpoints, campgrounds. Never anything marked historic, and never a
 * name that may mark a sacred or protected place (Landmarks::isProtected, decisions/0066).
 *
 * Only the kind and a point rounded to about 5 miles go to OpenStreetMap, from our server: never who searched.
 */
final class OpenPlaces
{
    /** Our kinds: [label, Overpass filters, words that ask for it]. Each filter is completed with (around:…). */
    public const KINDS = [
        'pizza' => ['Pizza', ['nwr["amenity"~"^(restaurant|fast_food)$"]["cuisine"~"pizza"]'], '/\bpizz/'],
        'coffee' => ['Coffee', ['nwr["amenity"="cafe"]'], '/\b(coffee|cafe|café|espresso)/'],
        'food' => ['Places to eat', ['nwr["amenity"~"^(restaurant|fast_food|cafe|food_court)$"]'], '/\b(restaurants?|food|eat|eating|dinner|lunch|breakfast|brunch|burgers?|tacos?|diner|bbq|barbecue|sushi|mexican|chinese|thai|italian)\b/'],
        'lodging' => ['Places to stay', ['nwr["tourism"~"^(hotel|motel|guest_house|hostel)$"]'], '/\b(hotels?|motels?|lodging|lodges?|inns?|hostels?|stay|bed and breakfast|b&b)\b/'],
        'fuel' => ['Gas', ['nwr["amenity"="fuel"]'], '/\b(gas|fuel|gas stations?|diesel)\b/'],
        'grocery' => ['Groceries', ['nwr["shop"~"^(supermarket|grocery|convenience|greengrocer)$"]'], '/\b(grocer(y|ies)|supermarkets?|food stores?|convenience)\b/'],
        'pharmacy' => ['Pharmacies', ['nwr["amenity"="pharmacy"]', 'nwr["shop"="chemist"]'], '/\b(pharmac(y|ies)|drug ?stores?|prescriptions?|meds|medicine)\b/'],
        'hospital' => ['Hospitals', ['nwr["amenity"="hospital"]'], '/\b(hospitals?|emergency rooms?|\ber\b)/'],
        'clinic' => ['Clinics', ['nwr["amenity"~"^(clinic|doctors)$"]'], '/\b(clinics?|urgent care|doctors?|walk-?in)\b/'],
        'storage' => ['Self storage', ['nwr["shop"="storage_rental"]', 'nwr["amenity"="storage_rental"]'], '/\b(storage|self-?storage|storage units?)\b/'],
        'auto' => ['Auto repair', ['nwr["shop"~"^(car_repair|tyres)$"]'], '/\b(tires?|tyres?|mechanics?|auto repair|car repair|oil change|auto shops?)\b/'],
        'hardware' => ['Hardware', ['nwr["shop"~"^(hardware|doityourself)$"]'], '/\b(hardware|home improvement)\b/'],
        'laundry' => ['Laundry', ['nwr["shop"~"^(laundry|dry_cleaning)$"]'], '/\b(laundr(y|omat)|laundromats?|dry clean(ing|ers)?)\b/'],
        // drop and collection boxes, package lockers (Jason, 2026-11-15: "drop boxes are good to know"): OpenStreetMap's own,
        // shown as its layer with its credit, never copied into our listings (decisions/0065)
        'dropoff' => ['Mail & package drop-offs', ['nwr["amenity"="post_box"]', 'nwr["amenity"="parcel_locker"]'], '/\b(drop ?box(es)?|drop[ -]?offs?|mail ?drops?|collection box(es)?|blue box(es)?|parcel lockers?|package lockers?|mail (a|my) (letter|package))\b/'],
        // the outdoors (2026-11-10)
        'trail' => ['Trailheads', ['nwr["highway"="trailhead"]', 'nwr["leisure"="nature_reserve"]["name"]'], '/\b(hik(e|es|ing)|trails?|trailheads?)\b/'],
        'camping' => ['Campgrounds', ['nwr["tourism"~"^(camp_site|caravan_site)$"]'], '/\b(camping|campgrounds?|campsites?|rv parks?|camp sites?)\b/'],
        'park' => ['Parks', ['nwr["leisure"~"^(park|nature_reserve)$"]["name"]'], '/\b(parks?|preserves?|playgrounds?)\b/'],
        'viewpoint' => ['Viewpoints', ['nwr["tourism"="viewpoint"]'], '/\b(viewpoints?|scenic views?|overlooks?|lookouts?)\b/'],
        // the places people go (2026-11-10, "the mission is immersion and connecting"): museums, galleries, zoos, gardens, parks,
        // attractions, theatres; never anything historic (ruins, memorials) or a name that may mark a sacred place
        'todo' => ['Things to do', ['nwr["tourism"~"^(museum|gallery|zoo|aquarium|theme_park|attraction)$"]["name"]', 'nwr["leisure"~"^(park|garden|water_park|nature_reserve)$"]["name"]', 'nwr["amenity"~"^(theatre|arts_centre)$"]["name"]'], '/(?!)/'],
        // outings (2026-11-10, "place to take my kids"): what suits who's coming; never asked for by words, only by an outing
        'family' => ['Places for kids', ['nwr["leisure"~"^(playground|water_park|miniature_golf|trampoline_park|amusement_arcade|ice_rink|park)$"]["name"]', 'nwr["tourism"~"^(zoo|aquarium|theme_park|museum)$"]["name"]', 'nwr["amenity"~"^(library|ice_cream)$"]["name"]'], '/(?!)/'],
        'dog' => ['Places for dogs', ['nwr["leisure"="dog_park"]', 'nwr["leisure"~"^(park|nature_reserve)$"]["name"]["dog"!="no"]'], '/(?!)/'],
        // everything everyday at once: the map with no words, and "near me" alone (2026-11-10: "results are nonexistent")
        'all' => ['Places near you', ['nwr["amenity"~"^(restaurant|fast_food|cafe|fuel|pharmacy)$"]', 'nwr["shop"~"^(supermarket|grocery|convenience)$"]', 'nwr["tourism"~"^(hotel|motel)$"]'], '/(?!)/'],
    ];
    /** Words that look like a kind but aren't that business ("Gas company" is a utility, "Food banks" aren't restaurants). */
    private const NOT = [
        'fuel' => '/\b(compan(y|ies)|lines?|propane|heat|heating)\b/',
        'food' => '/\b(banks?|pantr(y|ies)|cakes?|meals)\b/',
        'lodging' => '/\bguides?\b/',
        'auto' => '/\bchains?\b/',
        'dropoff' => '/\b(rentals?|storage|dropbox\.com|file|files|dumpster|kids?|child(ren)?|school|daycare|donations?|recycl\w*)\b/',   // a mailbox to rent, Dropbox the app, a dumpster: not a drop-off
    ];
    /** Overpass servers, tried in turn when one doesn't answer (the crawler's own list; 2026-11-10: "why am I not seeing
     *  any listings from osm" was one server timing out). Jason, 2026-11-14 ("go, automatic"): every server stays on the list,
     *  kept on OpenStreetMap's card in Outside services; the pre-use check (ServiceHealth: no open issue, not backing off,
     *  inside the day's budget and pace) is the only gate, so overpass-api.de is skipped while its ban is open and comes
     *  back by itself when its probe answers. */
    /** Days a spot and kind is kept before it's asked again: Thresholds osm_cache_days (90, Jason 2026-11-14: quarterly). */
    private static function keepDays(PDO $pdo): int { require_once __DIR__ . '/ServiceHealth.php'; return ServiceHealth::osmCacheDays($pdo); }
    private const PER_HOUR = 60;      // superseded: the register's osm_site_per_hour (Thresholds) is read now, same number
    private const BACKGROUND = 15;    // of those, the most our own jobs may use, so visitors' asks always have room
    private const RETRY_MINUTES = 10; // a spot that wasn't answered is asked again this soon, not a day later

    /** A time limit (microtime) a caller may set: no ask to OpenStreetMap starts too close to it, and none outlasts it
     *  (2026-11-10: a guide's "Finding places" ran past its own limit while OpenStreetMap was slow, and started over). */
    public static ?float $until = null;

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM open_places LIMIT 1'); $pdo->query('SELECT 1 FROM open_place_asks LIMIT 1'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    /** The kind of business some words ask for ("Storage", "Warehouses-Merchandise & Self Storage", "pizza"), or ''. */
    /**
     * The kinds of place OpenStreetMap itself names in what we ask it for ("dog_park", "playground", "water_park"), as
     * words ("dog park"), each with the kind it's asked under: [words => kind]. Its own vocabulary, not a list of ours
     * (2026-11-11: "dog park" should suggest dog parks).
     */
    public static function tagWords(): array
    {
        static $m = null;
        if ($m !== null) return $m;
        $m = [];
        foreach (self::KINDS as $k => [, $qs]) foreach ($qs as $q0) {
            if (preg_match_all('/"(?:leisure|amenity|tourism|shop)"(?:~"\^\(([a-z_|]+)\)\$"|="([a-z_]+)")/', (string) $q0, $mm, PREG_SET_ORDER)) {
                foreach ($mm as $x) foreach (explode('|', ($x[1] ?? '') !== '' ? $x[1] : ($x[2] ?? '')) as $v) if ($v !== '' && !isset($m[$w = str_replace('_', ' ', $v)])) $m[$w] = $k;
            }
        }
        return $m;
    }

    public static function kindFor(string $words): string
    {
        $w = ' ' . mb_strtolower($words) . ' ';
        if (preg_match('/ dog ?parks? | off.?leash /u', $w)) return 'dog';   // asked as dog parks, not all parks
        foreach (self::KINDS as $k => [, , $re]) if (preg_match($re, $w) && !(isset(self::NOT[$k]) && preg_match(self::NOT[$k], $w))) return $k;
        return '';
    }

    /**
     * Up to $n of a kind near a point, nearest first: from what's kept, else asked of OpenStreetMap (once a week per
     * spot). [['ref', 'label', 'what', 'phone', 'website', 'hours', 'street', 'city', 'miles', 'url', 'directions']].
     */
    public static function near(PDO $pdo, string $kind, float $lat, float $lon, int $n = 5, float $within = 25, bool $background = false): array
    {
        if (!isset(self::KINDS[$kind]) || !self::ready($pdo)) return [];
        $cell = in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? 50 : 10;   // the spot that's asked about: about 7 miles, or 1.4 for everything (asked closer in)
        $rl = round($lat * $cell) / $cell; $ro = round($lon * $cell) / $cell;
        $dp = in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? 2 : 1;
        $qkey = $kind . '@' . number_format($rl, $dp, '.', '') . ',' . number_format($ro, $dp, '.', '');   // other kinds keep their kept spots
        $st = $pdo->prepare('SELECT asked_at FROM open_place_asks WHERE qkey = ?'); $st->execute([$qkey]);
        $at = $st->fetchColumn();
        if ($at === false || strtotime((string) $at) < time() - self::keepDays($pdo) * 86400) self::ask($pdo, $kind, $qkey, $rl, $ro, $background);
        $d = 25 / 69.0;
        $st = $pdo->prepare('SELECT * FROM open_places WHERE kind = ? AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? LIMIT 400');
        $st->execute([$kind, $lat - $d, $lat + $d, $lon - $d * 1.4, $lon + $d * 1.4]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $mi = SearchIndex::miles($lat, $lon, (float) $r['lat'], (float) $r['lon']);
            if ($mi > min(25, $within)) continue;   // the Distance slider (decisions/0060), at most 25 miles
            // a nation's land (review A3, decisions/0066): a business there shows with the nation's name and its rules, its
            // directions to a place the nation opens to visitors (Nations::pin) or none; anything else there (a trailhead, a
            // reserve, a viewpoint) waits for the nation's own tools, as our landmarks do
            $n = self::nationAt($pdo, (float) $r['lat'], (float) $r['lon']);
            $to = $r['lat'] . ',' . $r['lon'];
            if ($n !== null) {
                $biz = !in_array($kind, self::OUTDOOR, true) && (trim((string) $r['phone']) !== '' || trim((string) $r['website']) !== '');
                if (!$biz) continue;
                [$pl, $po] = Nations::pin($pdo, (float) $r['lat'], (float) $r['lon']);
                $to = $pl !== null ? $pl . ',' . $po : '';
            }
            $out[] = ['ref' => (string) $r['osm_ref'], 'label' => (string) $r['name'], 'what' => (string) $r['what'], 'phone' => (string) $r['phone'],
                      'website' => (string) $r['website'], 'hours' => (string) $r['hours'], 'street' => (string) $r['street'], 'city' => (string) $r['city'],
                      'miles' => round($mi, 1), '_lat' => (float) $r['lat'], '_lon' => (float) $r['lon'], 'url' => 'https://www.openstreetmap.org/' . $r['osm_ref'],
                      'directions' => $to !== '' ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($to) : '',
                      'nation' => $n !== null ? Nations::label($pdo, $n) : '', 'note' => $n !== null ? 'On ' . Nations::label($pdo, $n) . ' land: visitors follow the nation\'s rules.' : ''];
        }
        usort($out, fn ($a, $b) => $a['miles'] <=> $b['miles']);
        // the same business mapped twice (a point and its building): once
        $kept = [];
        foreach ($out as $o) {
            foreach ($kept as $k) if (mb_strtolower($k['label']) === mb_strtolower($o['label']) && SearchIndex::miles($k['_lat'], $k['_lon'], $o['_lat'], $o['_lon']) < 0.1) continue 2;
            $kept[] = $o;
        }
        return array_map(function ($o) { unset($o['_lat'], $o['_lon']); return $o; }, array_slice($kept, 0, $n));
    }

    /** The kinds that are places outdoors, not businesses. */
    private const OUTDOOR = ['trail', 'camping', 'park', 'viewpoint', 'todo', 'family', 'dog'];

    /** The nation's land a point is on (its shape name), or null; remembered by spot for one request. */
    private static function nationAt(PDO $pdo, float $lat, float $lon): ?string
    {
        static $seen = [];
        require_once __DIR__ . '/Nations.php';
        $k = round($lat, 3) . ',' . round($lon, 3);
        if (!array_key_exists($k, $seen)) { try { $seen[$k] = Nations::at($pdo, $lat, $lon); } catch (Throwable $e) { $seen[$k] = null; } }
        return $seen[$k];
    }

    /** Asks OpenStreetMap for a kind around a spot (about 8 miles, then 25 when that finds fewer than 3) and keeps it. */
    private static function ask(PDO $pdo, string $kind, string $qkey, float $lat, float $lon, bool $background = false): void
    {
        // its fair use: all of our searches together ask at most osm_site_per_hour times an hour (the register)
        try { $n = (int) $pdo->query("SELECT COUNT(*) FROM open_place_asks WHERE asked_at >= '" . date('Y-m-d H:i:s', time() - 3600) . "'")->fetchColumn(); } catch (Throwable) { $n = 0; }
        require_once __DIR__ . '/Thresholds.php';
        if ($n >= (int) Thresholds::get($pdo, 'osm_site_per_hour') || ($background && $n >= self::BACKGROUND)) return;
        $found = 0; $ok = false;
        foreach ((in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? [3000, 8000] : [13000, 40000]) as $m) {   // everything, or things to do: closer in, it's dense
            $els = self::fetch($pdo, $kind, $lat, $lon, $m);
            if ($els === null) break;   // didn't answer: asked again later
            $ok = true;
            $found = self::keep($pdo, $kind, $els);
            if ($found >= 3) break;
        }
        // not answered: asked again in RETRY_MINUTES (marked as asked that long before a week ran out); answered: kept a week
        $when = $ok ? date('Y-m-d H:i:s') : date('Y-m-d H:i:s', time() - self::keepDays($pdo) * 86400 + self::RETRY_MINUTES * 60);
        try {
            $pdo->prepare('DELETE FROM open_place_asks WHERE qkey = ?')->execute([$qkey]);
            $pdo->prepare('INSERT INTO open_place_asks (qkey, found, asked_at) VALUES (?, ?, ?)')->execute([$qkey, $found, $when]);
        } catch (Throwable $e) { error_log('open places ask: ' . $e->getMessage()); }
    }

    /** The elements Overpass returns, or null when it didn't answer. OSM_FIXTURE (a JSON file) stands in for it in tests. */
    private static function fetch(PDO $pdo, string $kind, float $lat, float $lon, int $meters): ?array
    {
        if (($fx = getenv('OSM_FIXTURE')) && is_file($fx)) {
            $all = json_decode((string) file_get_contents($fx), true);
            return (array) ($all[$kind] ?? []);
        }
        if (!function_exists('curl_init')) return null;
        $parts = '';
        foreach (self::KINDS[$kind][1] as $f) $parts .= $f . '(around:' . $meters . ',' . $lat . ',' . $lon . ');';
        $q = '[out:json][timeout:25];(' . $parts . ');out center tags ' . (in_array($kind, ['all', 'todo', 'family', 'dog'], true) ? 200 : 80) . ';';
        return self::overpass($pdo, $q, self::$until !== null ? (int) floor(self::$until - microtime(true)) : 18, 18);
    }

    /**
     * One Overpass query, to the first server not held that answers (DeepLook asks through this too): the elements, or null.
     * One at a time from the site (a lock, the OSM statement's second promise); a failure is classified and recorded
     * (ServiceHealth), and a refused server is never asked again another way.
     */
    public static function overpass(PDO $pdo, string $q, int $left, int $wait): ?array
    {
        if (!function_exists('curl_init') || $left < 6) return null;   // no time left: not answered, asked again later
        require_once __DIR__ . '/Automation.php';
        if (Automation::gathering($pdo, 'osm') !== null) return null;   // paused (System Configuration → Automation): what we hold still shows, asked again once it's on
        require_once __DIR__ . '/ServiceHealth.php';
        $lock = false;
        try { $lock = (int) $pdo->query("SELECT GET_LOCK('tv_overpass', 3)")->fetchColumn() === 1; } catch (Throwable) {}
        if (!$lock) return null;   // another ask is out: this one waits for later
        $ob = ServiceHealth::osmBudget($pdo, 'site');
        if ($ob['queries'] <= 0 || $ob['bytes'] <= 0 || !ServiceHealth::osmPaceOk($pdo, 'site')) { try { $pdo->query("SELECT RELEASE_LOCK('tv_overpass')"); } catch (Throwable) {} return null; }   // the day's share is used (Thresholds & gates)
        try {
            $started = microtime(true);
            foreach (ServiceHealth::servers($pdo, 'osm', 'overpass') as $sv) {   // the next server when one is busy or slow, so a visitor isn't kept long
                $url = (string) $sv['url']; $host = (string) $sv['host'];
                if (ServiceHealth::allowed($pdo, $host) !== null) continue;
                $rest = $left - (int) ceil(microtime(true) - $started);
                if ($rest < 6) return null;
                $ch = curl_init($url);
                curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(['data' => $q]), CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => min($wait, $rest), CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_USERAGENT => ServiceHealth::agent()]);
                $body = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = $body === false ? curl_error($ch) : ''; curl_close($ch);
                ServiceHealth::osmUse($pdo, 'site', 1, is_string($body) ? strlen($body) : 0);
                if ($body === false || $code !== 200) {
                    ServiceHealth::siteFailed($pdo, $url, $code, is_string($body) ? $body : '', $err !== '' ? $err : ($code ? '' : 'no answer'));
                    error_log('open places: Overpass ' . $code . ' at ' . $host);
                    continue;
                }
                $j = json_decode((string) $body, true);
                if (is_array($j['elements'] ?? null) && !preg_match('/runtime (error|remark)|timed out|out of memory/i', (string) ($j['remark'] ?? ''))) { ServiceHealth::answered($pdo, $host, 'site'); return $j['elements']; }
                try { ServiceHealth::failed($pdo, $host, preg_match('/timed out|runtime error/i', (string) ($j['remark'] ?? '')) ? 'timeout' : 'malformed', 'site', ['status' => 200, 'body' => mb_substr(is_array($j) ? (string) ($j['remark'] ?? '') : (string) $body, 0, 300), 'what' => '/api/interpreter', 'at' => gmdate('c')]); } catch (Throwable) {}
            }
            return null;
        } finally {
            try { $pdo->query("SELECT RELEASE_LOCK('tv_overpass')"); } catch (Throwable) {}
        }
    }

    /** The kinds whose Overpass filters a place's tags match (the filters stay the one definition of a kind). */
    public static function kindsOfTags(array $t): array
    {
        $out = [];
        foreach (self::KINDS as $k => $def) foreach ((array) $def[1] as $f) if (self::tagsMatch((string) $f, $t)) { $out[] = $k; break; }
        return $out;
    }

    /** Whether a place's tags match one Overpass filter (nwr["amenity"="cafe"], ["cuisine"~"pizza"], ["dog"!="no"], ["name"]). */
    private static function tagsMatch(string $f, array $t): bool
    {
        if (!preg_match_all('/\["([^"]+)"(?:(=|~|!=)"([^"]*)")?\]/', $f, $m, PREG_SET_ORDER)) return false;
        foreach ($m as $c) {
            $v = isset($t[$c[1]]) ? (string) $t[$c[1]] : null; $op = $c[2] ?? ''; $want = $c[3] ?? '';
            if ($op === '') $ok = $v !== null;
            elseif ($op === '=') $ok = $v === $want;
            elseif ($op === '!=') $ok = $v !== $want;
            else $ok = $v !== null && @preg_match('/' . str_replace('/', '\/', $want) . '/', $v) === 1;
            if (!$ok) return false;
        }
        return true;
    }

    // ---- our copy first for the crawler (decisions/0163's source map, "ours first"; handoffs/preflight.md (b)) --------
    // W1's coverage and targets tasks used to ask Overpass for every kind in every town, and Overpass doesn't answer our
    // hosts (research/osm-overpass-2026-11-13.md). The states' extracts (Geofabrik, weekly) now hold those kinds too, and
    // each job leased to the crawler carries what our copy has for its town and kinds ("ours"); the crawler asks Overpass
    // only for a kind or a town our copy lacks. Still OpenStreetMap's own layer: the crawler treats these exactly as
    // Overpass's answers, a lead and a link, never copied into our listings (decisions/0065, review C11).

    /** The tags a state's extract carries (the worker's OSM_TAG_FILTER and OSM_KEEP_TAGS): a filter on any other tag
     *  (healthcare, office, social_facility…) can't be answered from our copy and stays Overpass's. */
    private const EXTRACT_KEYS = ['amenity', 'shop', 'tourism', 'leisure', 'highway', 'name', 'cuisine', 'dog'];
    /** Our copy of a state counts as fresh this long after its load finished (the pre-flight's 45 days for open_places). */
    public const COPY_DAYS = 45;
    /** Geofabrik's file names (OpenLoads::GEOFABRIK_STATES) by the two-letter state a job's towns carry. */
    public const COPY_STATES = ['AZ' => 'arizona', 'NM' => 'new-mexico'];
    /** How far around each of a job's ZIP centres its places are read: the crawler's ZIP_RADIUS_M. */
    private const JOB_RADIUS_M = 19000;
    /** At most this many places per kind for a job, as Overpass's "out … 120". */
    private const JOB_MAX = 120;

    /** Whether our copy can hold what a filter asks for: every tag it tests is one the extract carries. */
    private static function extractable(string $f): bool
    {
        if (!preg_match_all('/\["([^"]+)"/', $f, $m)) return false;
        foreach ($m[1] as $key) {
            if (!in_array($key, self::EXTRACT_KEYS, true)) return false;
            if ($key === 'highway' && !str_contains($f, '["highway"="trailhead"]')) return false;   // the extract keeps only trailheads of highway
        }
        return true;
    }

    /**
     * The crawler's own town kinds (TownCrawl::KINDS' filters) that aren't one of ours: kept from each extract under their
     * own kind, "f:" and the filter's hash, so a town job reads them here. [kind => [filter, what it is]].
     */
    public static function leadKinds(): array
    {
        static $m = null;
        if ($m !== null) return $m;
        $m = []; $ours = [];
        foreach (self::KINDS as $def) foreach ((array) $def[1] as $f) $ours[$f] = true;
        try { require_once __DIR__ . '/crawler/TownCrawl.php'; $town = TownCrawl::KINDS; } catch (Throwable $x) { $town = []; }
        foreach ($town as $def) foreach ((array) $def[1] as $f) {
            $f = (string) $f;
            if (isset($ours[$f]) || !self::extractable($f)) continue;
            $m['f:' . substr(sha1($f), 0, 12)] = [$f, (string) $def[0]];
        }
        return $m;
    }

    /** The kind our copy keeps a filter under, or '' when our copy can't answer it (Overpass then does). */
    public static function filterKind(string $f): string
    {
        $f = trim($f);
        if ($f === '' || !self::extractable($f)) return '';
        foreach (self::KINDS as $k => $def) if (in_array($f, (array) $def[1], true)) {
            foreach ((array) $def[1] as $g) if (!self::extractable((string) $g)) return '';   // a kind only partly in the extract
            return $k;
        }
        $lk = 'f:' . substr(sha1($f), 0, 12);
        return isset(self::leadKinds()[$lk]) ? $lk : '';
    }

    /** Every kind a state's extract is kept by, and its signature (stored with each state's load: a load made before the
     *  kinds changed doesn't answer for them, and the state is loaded again at once). */
    public static function copyKinds(): array
    {
        $ks = [];
        foreach (self::KINDS as $k => $def) { $all = true; foreach ((array) $def[1] as $g) if (!self::extractable((string) $g)) $all = false; if ($all) $ks[] = $k; }
        return array_merge($ks, array_keys(self::leadKinds()));
    }

    public static function copySignature(): string { return substr(sha1(json_encode(self::copyKinds())), 0, 16); }

    /**
     * Where our copy stands, by state: [code => ['name', 'at' (finished, UTC, or ''), 'places', 'fresh' (bool), 'why']].
     * Fresh: its last load finished within COPY_DAYS and was kept by today's kinds.
     */
    public static function copyStates(PDO $pdo): array
    {
        $out = [];
        require_once __DIR__ . '/SearchIndex.php';
        $names = ['arizona' => 'Arizona', 'new-mexico' => 'New Mexico'];
        $sig = self::copySignature();
        foreach (self::COPY_STATES as $code => $key) {
            $r = ['name' => $names[$key] ?? $key, 'at' => '', 'places' => 0, 'fresh' => false, 'why' => 'not loaded yet'];
            try {
                $st = $pdo->prepare("SELECT finished_at, listed FROM open_loads WHERE dataset = 'geofabrik' AND place_key = ? AND finished_at IS NOT NULL ORDER BY finished_at DESC LIMIT 1");
                $st->execute([$key]); $l = $st->fetch(PDO::FETCH_ASSOC);
            } catch (Throwable $x) { $l = false; $r['why'] = 'its loads\' table isn\'t there yet'; }
            if ($l) {
                $r['at'] = (string) $l['finished_at']; $r['places'] = (int) $l['listed'];
                $age = (int) floor((time() - (int) strtotime($r['at'] . ' UTC')) / 86400);
                $kept = '';
                try { $kept = SearchIndex::state($pdo, 'open:geofabrik_sig:' . $key); } catch (Throwable $x) {}
                if ($age > self::COPY_DAYS) $r['why'] = 'stale: loaded ' . $age . ' days ago (over ' . self::COPY_DAYS . ')';
                elseif ($kept !== $sig) $r['why'] = 'loaded before the crawler\'s kinds were kept; loaded again on the next run';
                else { $r['fresh'] = true; $r['why'] = 'loaded ' . ($age === 0 ? 'today' : $age . ' day' . ($age === 1 ? '' : 's') . ' ago'); }
            }
            $out[$code] = $r;
        }
        return $out;
    }

    /** Our copy in one line for the pre-flight and the switch-on check: [usable (a state fresh), words]. */
    public static function ourCopy(PDO $pdo): array
    {
        $s = self::copyStates($pdo); $ok = false; $w = [];
        foreach ($s as $r) { $ok = $ok || $r['fresh']; $w[] = $r['name'] . ': ' . $r['why'] . ($r['places'] ? ' (' . number_format($r['places']) . ' kept by kind)' : ''); }
        return [$ok, 'our OpenStreetMap copy from Geofabrik, ' . implode('; ', $w)];
    }

    /**
     * What our copy holds for one crawl job (its towns' states fresh, its kinds in the extract): ['ours' => [filter =>
     * Overpass-like elements], 'ours_note' => words], or [] when it holds nothing for it. A filter listed with no elements
     * is answered (our copy has none of that kind there); a filter not listed is the crawler's to ask Overpass.
     */
    public static function forJob(PDO $pdo, array $job): array
    {
        $pl = (array) ($job['place'] ?? []); $filters = (array) (($job['looking_for'] ?? [])['osm'] ?? []);
        if (!$filters || !self::ready($pdo)) return [];
        $copy = self::copyStates($pdo); $states = [];
        foreach ((array) ($pl['towns'] ?? []) as $t) $states[strtoupper((string) ($t['state'] ?? ''))] = true;
        if (!$states) return [];
        foreach (array_keys($states) as $code) if (empty($copy[$code]['fresh'])) return [];   // a town outside our copy: Overpass, as before
        $pts = [];
        foreach ((array) ($pl['zip_points'] ?? []) as $p) if (isset($p['lat'], $p['lon'])) $pts[] = [(float) $p['lat'], (float) $p['lon']];
        if (!$pts && isset($pl['center']['lat'], $pl['center']['lon'])) $pts[] = [(float) $pl['center']['lat'], (float) $pl['center']['lon']];
        if (!$pts) return [];
        $padLat = self::JOB_RADIUS_M / 111000.0;
        $mid = array_sum(array_column($pts, 0)) / count($pts);
        $padLon = $padLat / max(0.2, cos(deg2rad($mid)));
        $box = [min(array_column($pts, 0)) - $padLat, max(array_column($pts, 0)) + $padLat, min(array_column($pts, 1)) - $padLon, max(array_column($pts, 1)) + $padLon];
        $st = $pdo->prepare('SELECT osm_ref, name, lat, lon, phone, website, hours, street, city, state FROM open_places WHERE kind = ? AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? LIMIT 3000');
        $out = []; $done = []; $n = 0;
        foreach ($filters as $f) {
            $f = (string) $f; $k = self::filterKind($f);
            if ($k === '') continue;
            if (isset($done[$k])) { $out[$f] = []; continue; }   // a kind's other filter: its places already came with the first
            $done[$k] = true;
            $st->execute([$k, $box[0], $box[1], $box[2], $box[3]]);
            $rows = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $best = INF;
                foreach ($pts as [$la, $lo]) $best = min($best, SearchIndex::miles($la, $lo, (float) $r['lat'], (float) $r['lon']));
                if ($best * 1609.344 > self::JOB_RADIUS_M) continue;
                [$type, $id] = array_pad(explode('/', (string) $r['osm_ref'], 2), 2, '0');
                $rows[] = [$best, ['type' => $type, 'id' => (int) $id, 'lat' => (float) $r['lat'], 'lon' => (float) $r['lon'], 'tags' => array_filter([
                    'name' => (string) $r['name'], 'phone' => (string) $r['phone'], 'website' => (string) $r['website'], 'opening_hours' => (string) $r['hours'],
                    'addr:street' => (string) $r['street'], 'addr:city' => (string) $r['city'], 'addr:state' => (string) $r['state']], fn ($v) => $v !== '')]];
            }
            usort($rows, fn ($a, $b) => $a[0] <=> $b[0]);
            $out[$f] = array_column(array_slice($rows, 0, self::JOB_MAX), 1);
            $n += count($out[$f]);
        }
        if (!$out) return [];
        $when = [];
        foreach (array_keys($states) as $code) $when[] = $copy[$code]['name'] . ' ' . $copy[$code]['why'];
        return ['ours' => $out, 'ours_note' => count($out) . ' of ' . count($filters) . ' kind(s) from our OpenStreetMap copy (' . implode('; ', $when) . '), ' . $n . ' place(s)'];
    }

    /** The leased jobs, each with what our copy holds for it (jobs.php, targets.php). A failure here never stops a lease. */
    public static function attach(PDO $pdo, array $jobs): array
    {
        foreach ($jobs as $i => $j) {
            if (!is_array($j)) continue;
            try { $jobs[$i] = $j + self::forJob($pdo, $j); } catch (Throwable $x) { error_log('open places for a job: ' . $x->getMessage()); }
        }
        return $jobs;
    }

    /**
     * A state's OpenStreetMap extract (Geofabrik, by the Railway worker; 0163 §8 stage 8): its places kept in OpenStreetMap's
     * own table, by kind (ours, and the crawler's town kinds, leadKinds()), through keep()'s rules (no historic places, no protected names, its own layer, decisions/0065).
     * $els: [{type, id, lat, lon, tags}]. How many kept.
     */
    public static function keepExtract(PDO $pdo, array $els): int
    {
        $by = [];
        $leads = self::leadKinds();
        foreach ($els as $e) {
            if (!is_array($e) || !is_array($e['tags'] ?? null)) continue;
            foreach (self::kindsOfTags($e['tags']) as $k) $by[$k][] = $e;
            foreach ($leads as $k => [$f]) if (self::tagsMatch($f, $e['tags'])) $by[$k][] = $e;   // the crawler's town kinds (2026-11-17)
        }
        $n = 0;
        foreach ($by as $k => $list) $n += self::keep($pdo, $k, $list);
        return $n;
    }

    /** Keeps what came back (named places with a point), replacing what was kept before. How many. */
    private static function keep(PDO $pdo, string $kind, array $els): int
    {
        $n = 0;
        $del = $pdo->prepare('DELETE FROM open_places WHERE osm_ref = ? AND kind = ?');
        $ins = $pdo->prepare('INSERT INTO open_places (osm_ref, kind, name, what, lat, lon, phone, website, hours, street, city, state, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        foreach ($els as $e) {
            $t = (array) ($e['tags'] ?? []);
            $name = trim((string) ($t['name'] ?? ''));
            if ($name === '' && $kind === 'dropoff')   // boxes rarely have names: "USPS collection box", "Amazon package locker"
                $name = trim(trim((string) ($t['operator'] ?? $t['brand'] ?? '')) . ' ' . (($t['amenity'] ?? '') === 'parcel_locker' ? 'package locker' : 'collection box'));
            $name = $name !== '' ? mb_strtoupper(mb_substr($name, 0, 1)) . mb_substr($name, 1) : '';
            $lat = $e['lat'] ?? ($e['center']['lat'] ?? null); $lon = $e['lon'] ?? ($e['center']['lon'] ?? null);
            if ($name === '' || $lat === null || $lon === null || !in_array($e['type'] ?? '', ['node', 'way', 'relation'], true)) continue;
            // never anything historic (a ruin, a memorial: where sacred or restricted sites could be), never a name that may mark
            // one; a business isn't an attraction or a natural feature (the outdoor kinds may be)
            $outdoor = in_array($kind, self::OUTDOOR, true);
            if (isset($t['historic']) || (($t['tourism'] ?? '') === 'attraction' && $kind !== 'todo') || (!$outdoor && isset($t['natural']))) continue;
            if (class_exists('Landmarks') || is_file(__DIR__ . '/Landmarks.php')) { require_once __DIR__ . '/Landmarks.php'; if (Landmarks::isProtected($name . ' ' . (string) ($t['description'] ?? ''))) continue; }
            $ref = $e['type'] . '/' . (int) $e['id'];
            $street = trim(trim((string) ($t['addr:housenumber'] ?? '')) . ' ' . trim((string) ($t['addr:street'] ?? '')));
            try {
                $del->execute([$ref, $kind]);
                $ins->execute([$ref, $kind, mb_substr($name, 0, 160), mb_substr(self::what($kind, $t), 0, 60), round((float) $lat, 6), round((float) $lon, 6),
                    mb_substr(trim((string) ($t['phone'] ?? $t['contact:phone'] ?? '')), 0, 40), mb_substr(trim((string) ($t['website'] ?? $t['contact:website'] ?? '')), 0, 255),
                    mb_substr(trim((string) ($t['opening_hours'] ?? '')), 0, 255), mb_substr($street, 0, 160), mb_substr(trim((string) ($t['addr:city'] ?? '')), 0, 80),
                    mb_substr(trim((string) ($t['addr:state'] ?? '')), 0, 20), date('Y-m-d H:i:s')]);
                $n++;
            } catch (Throwable $x) { error_log('open places keep: ' . $x->getMessage()); }
        }
        return $n;
    }

    /** Its kind in words: the cuisine for a place to eat ("Pizza", "Mexican"), else the kind's own name. */
    private static function what(string $kind, array $t): string
    {
        if (in_array($kind, ['food', 'pizza', 'coffee'], true) && !empty($t['cuisine'])) return ucfirst(str_replace('_', ' ', explode(';', (string) $t['cuisine'])[0]));
        $map = ['restaurant' => 'Restaurant', 'fast_food' => 'Fast food', 'cafe' => 'Café', 'hotel' => 'Hotel', 'motel' => 'Motel', 'guest_house' => 'Guest house',
                'hostel' => 'Hostel', 'supermarket' => 'Supermarket', 'convenience' => 'Convenience store', 'tyres' => 'Tires', 'car_repair' => 'Auto repair',
                'doctors' => 'Doctor', 'clinic' => 'Clinic', 'dry_cleaning' => 'Dry cleaning',
                'trailhead' => 'Trailhead', 'nature_reserve' => 'Nature preserve', 'park' => 'Park', 'viewpoint' => 'Viewpoint', 'camp_site' => 'Campground', 'caravan_site' => 'RV park',
                'fuel' => 'Gas', 'pharmacy' => 'Pharmacy', 'supermarket' => 'Grocery', 'grocery' => 'Grocery',
                'museum' => 'Museum', 'gallery' => 'Gallery', 'zoo' => 'Zoo', 'aquarium' => 'Aquarium', 'theme_park' => 'Theme park', 'attraction' => 'Attraction', 'garden' => 'Garden', 'water_park' => 'Water park', 'theatre' => 'Theatre', 'arts_centre' => 'Arts centre',
                'playground' => 'Playground', 'miniature_golf' => 'Mini golf', 'trampoline_park' => 'Trampoline park', 'amusement_arcade' => 'Arcade', 'ice_rink' => 'Ice rink',
                'library' => 'Library', 'ice_cream' => 'Ice cream', 'dog_park' => 'Dog park', 'post_box' => 'Mail drop box', 'parcel_locker' => 'Package locker'];
        foreach (['amenity', 'tourism', 'shop', 'highway', 'leisure'] as $k) if (isset($t[$k], $map[$t[$k]])) return $map[$t[$k]];
        return self::KINDS[$kind][0] ?? (self::leadKinds()[$kind][1] ?? '');   // a crawler town kind: its own name
    }
}
