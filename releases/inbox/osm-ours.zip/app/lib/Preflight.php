<?php
// app/lib/Preflight.php — the pre-flight check, before Start the system (decisions/0163 §10's note of 2026-11-16; Jason,
// 2026-11-17: "yes start the preflight session now"). System Configuration → Pre-flight proves each part WORKS, not only
// that its key is set: the site itself, every outside company (each Outside services card's Test is its line here: one
// list, one status), W0 and the crawler on Railway, the heaviest queries timed, then 0164's phases, each workflow in Start
// the system's order and the new tasks, each ready only when everything under it is.
//   Every test is real, free and harmless: a read-only call, a sign-in without sending, a known test value. Never money,
//   never a message to a real person, never a write to anyone's data. Calls go through StagingGate::hold() (staging's
//   answer) and a host held by an open service issue isn't asked at all (its issue is the answer). A service only PAUSED
//   (Automation) is still tested: the pre-flight reads, and a paused service is what it's for.
//   Its own process: it runs any time (stopped, starting or running) and never starts, pauses or changes anything.
//   Start the system reads its latest result (SystemStart::panel); it doesn't run it. It runs again each night and after
//   a .env change (app/scripts/preflight_tick.php); red lines are one Pulse case, "Pre-flight", a step per line.
// Results: preflight_results, one row per line (its id), and '_run' for the last full runs, so a run of one line never
// overwrites another's. Its own table (2026-11-17): search_index_state's value column cut longer results short on live.
// Staging's own (staging-tables.php): each site keeps its own diagnosis.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/SearchIndex.php';

final class Preflight
{
    public const GROUPS = [
        'site' => 'The site itself',
        'services' => 'Outside services',
        'railway' => 'W0 and the crawler on Railway',
        'timing' => 'Query timings',
        'needs' => 'What the engine needs, ours first (decisions/0163, the source map)',
        'siteneeds' => 'What the site needs',
        'workflows' => 'Workflows, in Start the system\'s order',
        'tasks' => 'The new tasks',
        'phases' => 'The engine\'s phases (decisions/0164): ready when their workflows are',
    ];
    public const MARKS = ['ok' => 'Ready', 'warn' => 'On a backup', 'bad' => 'Not ready', 'na' => 'Not needed yet', 'wait' => 'Waiting', 'new' => 'Not run yet'];

    /**
     * The source map (decisions/0163's note of 2026-11-17): each need, its sources in order (ours first), and what happens
     * when none works. id => [group, name, workflows, sources, if none works, soft, planned backup].
     * A source: ['ours', table, words, days before it's stale (0: no limit)] | ['svc', company] | ['line', pre-flight line, words]
     * | ['copy', 'osm', words] (our OpenStreetMap copy by state, OpenPlaces::ourCopy).
     * Ready when its first source works; "on a backup" (amber) when a later one does; not ready when none does, unless
     * soft (its fallback always works: then amber). A paid backup is used only by a director's override (not here yet).
     */
    public const NEEDS = [
        'pages' => ['needs', 'Read pages (W0)', ['W0'], [['line', 'rw:beat', 'W0 Indexer on Railway']], 'waits; nothing lost', false, 'the crawler image on the traversence Fly organization'],
        // ours first: the Geofabrik copy by state (OpenPlaces::ourCopy: loaded, fresh, kept by today's kinds), which W1's coverage
        // and targets read before Overpass (2026-11-17); Overpass only for a kind or town it lacks
        'places' => ['needs', 'Places by kind and town (W1)', ['W1'], [['copy', 'osm', 'our OpenStreetMap copy (Geofabrik)'], ['svc', 'osm'], ['svc', 'overture']], 'waits', false, ''],
        'bulk' => ['needs', 'Businesses in bulk (W1)', ['W1'], [['ours', 'open_places', 'our open-data copies', 45], ['svc', 'overture'], ['svc', 'foursquare'], ['svc', 'geofabrik']], 'the last load is kept', false, ''],
        'health' => ['needs', 'Health providers (W1)', ['W1'], [['ours', 'npi_orgs', 'our NPI copy', 45], ['svc', 'cms']], 'the last load is kept', false, ''],
        'nonprofits' => ['needs', 'Nonprofits (W1)', ['W1'], [['ours', 'irs_orgs', 'our IRS copy', 45], ['svc', 'irs']], 'the last load is kept', false, ''],
        'recreation' => ['needs', 'Recreation areas (W1)', ['W1'], [['ours', 'rec_places', 'our Recreation.gov copy', 45], ['svc', 'ridb']], 'the last load is kept', false, ''],
        'official' => ['needs', 'Official places (W1, W9)', ['W1', 'W9'], [['ours', 'landmarks', 'our landmarks', 0], ['svc', 'wikimedia']], 'waits', false, ''],
        'confirm' => ['needs', 'Confirm a business (W1, W2)', ['W1', 'W2'], [['ours', 'open_places', 'our copies agreeing', 45], ['svc', 'cms'], ['svc', 'azcc'], ['svc', 'tavily'], ['svc', 'brave']], 'the person queue (Google Places as a paid backup by override)', false, ''],
        'prose' => ['needs', 'Page prose into facts (W1–W3, W10, W11)', ['W1', 'W2', 'W3', 'W10', 'W11'], [['svc', 'gemini']], '"waiting to be read"; nothing lost (Claude as a paid backup by override)', false, ''],
        'reread' => ['needs', 'Re-read websites (W2)', ['W2'], [['line', 'rw:crawler', 'the crawler reading directly'], ['svc', 'commoncrawl']], 'waits', false, ''],
        'contact' => ['needs', 'A missing phone or website (W2)', ['W2'], [['ours', 'open_places', 'our open-data copies', 45], ['svc', 'tavily'], ['svc', 'brave']], 'waits', false, ''],
        'geocode' => ['needs', 'Map points (W2)', ['W2'], [['ours', 'zip_coordinates', 'our ZIP and town points', 0], ['svc', 'census']], 'waits', false, ''],
        'stillopen' => ['needs', 'Still open? (W2)', ['W2'], [['ours', 'open_places', 'our copies\' open or closed status', 45], ['svc', 'google']], 'waits', false, ''],
        'sources' => ['needs', 'Sources read regularly (W3)', ['W3'], [['ours', 'source_facts', 'what our sources said', 0], ['line', 'rw:crawler', 'the crawler reading directly'], ['svc', 'commoncrawl']], 'waits', false, ''],
        'semantic' => ['needs', 'Semantic search (W3)', ['W3'], [['svc', 'supabase'], ['svc', 'gemini']], 'search uses keyword search (0164 §5.2)', true, ''],
        'writing' => ['needs', 'Writing and judging (W4–W6, W8, W10)', ['W4', 'W5', 'W6', 'W8', 'W10'], [['svc', 'anthropic']], 'queued; W5 gives a first look from what we hold', false, ''],
        'heritage' => ['needs', 'Archives and history (W6)', ['W6'], [['ours', 'heritage_facts', 'our heritage catalog', 0], ['svc', 'loc'], ['svc', 'wikimedia'], ['svc', 'nps']], 'waits', false, ''],
        'drive' => ['needs', 'Drive times (W7)', ['W7'], [['ours', 'travel_legs', 'drive times we kept', 0], ['svc', 'heigit']], 'estimated times', true, ''],
        'landmarks' => ['needs', 'Landmarks, names and photos (W9)', ['W9'], [['ours', 'landmarks', 'our landmarks', 0], ['svc', 'wikimedia'], ['svc', 'usgs'], ['svc', 'census']], 'waits', false, ''],
        'websearch' => ['needs', 'Web search (W8, W10–W12)', ['W8', 'W10', 'W11', 'W12'], [['svc', 'tavily'], ['svc', 'brave']], 'queued', false, ''],
        'authority' => ['needs', 'Authority sources (W14)', ['W14'], [['svc', 'azcc'], ['svc', 'nmsos']], 'waits (the licence lists are inactive until queue 3a)', false, ''],
        // the site (not the engine): visible, optional for the engine's launch
        'hosting' => ['siteneeds', 'Hosting (the site itself)', [], [['line', 'site:db', 'Bluehost: the site and its databases']], 'the site is down', false, 'a read-only copy of the public pages on Cloudflare or the Fly edge; nightly database backups'],
        'enginehost' => ['siteneeds', 'The engine\'s host', [], [['line', 'rw:api', 'Railway']], 'the engine waits', false, 'Bluehost\'s jobs for the light tasks; the crawler on the traversence Fly organization'],
        'sync' => ['siteneeds', 'Sync, checks and docs', [], [['svc', 'github']], 'the sync waits; the site runs', false, 'Railway runs sync.py; recorded in git once GitHub is back'],
        'siteemail' => ['siteneeds', 'The site\'s own email', [], [['svc', 'bluehost'], ['svc', 'aws']], 'waits', false, ''],
        'bulkemail' => ['siteneeds', 'Bulk email and digests', [], [['svc', 'aws']], 'waits', false, ''],
        'storage' => ['siteneeds', 'File storage', [], [['svc', 'cloudflare'], ['svc', 'aws']], 'uploads wait', false, ''],
        'payments' => ['siteneeds', 'Our orders\' payments', [], [['svc', 'quickbooks']], 'wire or check', true, 'Stripe as a second processor'],
        'checkout' => ['siteneeds', 'Marketplace checkout', [], [['svc', 'stripe'], ['svc', 'square']], 'pay at pickup; contact the seller', true, ''],
        'domains' => ['siteneeds', 'Selling domains', [], [['svc', 'namecom']], 'sales pause', true, ''],
        'owndomains' => ['siteneeds', 'Businesses\' own domains', [], [['svc', 'fly']], 'the storefront\'s trvgo.us address still works', true, ''],
        'signin' => ['siteneeds', 'Sign in with Google, Microsoft, Apple or Facebook', [], [['svc', 'google'], ['svc', 'microsoft'], ['svc', 'apple'], ['svc', 'meta']], 'email and password always work', true, ''],
        'maps' => ['siteneeds', 'Maps', [], [['svc', 'osm'], ['svc', 'usgs']], 'the list without the map', true, ''],
        'weather' => ['siteneeds', 'Weather and road work on guides', [], [['svc', 'nws'], ['svc', 'az511']], 'hidden, with a link to check', true, ''],
        'populations' => ['siteneeds', 'Populations and towns', [], [['ours', 'tv_zip_population', 'our Census loads', 0], ['svc', 'census']], 'the last load is kept', true, ''],
        'eucheck' => ['siteneeds', 'The EU sign-up check', [], [['ours', 'ip_eu_ranges', 'our DB-IP file', 45], ['svc', 'dbip']], 'the last file is kept', true, ''],
        'stock' => ['siteneeds', 'Stock photos', [], [['ours', 'stock_images', 'our stock library', 0], ['svc', 'pixabay'], ['svc', 'loc'], ['svc', 'wikimedia']], 'a placeholder', true, ''],
        'videos' => ['siteneeds', 'Videos in journeys', [], [['svc', 'vimeo'], ['svc', 'google']], 'a link out', true, ''],
        'styles' => ['siteneeds', 'Older pages\' styles', [], [['svc', 'tailwind']], 'unstyled', true, ''],
        'recalls' => ['siteneeds', 'Recalls on the Marketplace', [], [['svc', 'cpsc']], 'the check is skipped, logged', true, ''],
        'aiassist' => ['siteneeds', 'AI Assist and reading cards', [], [['svc', 'anthropic'], ['svc', 'aws']], '"try again later"', true, ''],
        'logins' => ['siteneeds', 'Staff logins', [], [['svc', 'onepassword']], 'the admin\'s Vault', true, ''],
    ];
    /** 0164 §7: the workflows each phase runs through. */
    public const PHASES = [
        1 => ['Wide discovery and source classification', ['W0', 'W1', 'W2', 'W3', 'W6', 'W9', 'W10', 'W11', 'W14']],
        2 => ['Contextual extraction', ['W1', 'W2', 'W3', 'W6', 'W9', 'W10', 'W11', 'W14']],
        3 => ['Entity resolution, vetting and privacy', ['W1', 'W2', 'W6', 'W8', 'W9', 'W10', 'W11']],
        4 => ['The master catalog, graph and index', ['W1', 'W4', 'W5', 'W6', 'W8', 'W9', 'W10', 'W11', 'W12']],
        5 => ['Publishing, serving and access', ['W1', 'W4', 'W5', 'W7', 'W10', 'W11']],
        6 => ['Lifecycle and self-healing', ['W2', 'W6', 'W14']],
    ];
    /** The query timings: id => [what, its Thresholds limit]. */
    public const TIMINGS = [
        'radius' => ['A radius search (listings within 50 miles of Kayenta)', 'pf_ms_radius'],
        'rollup' => ['A zone roll-up (live listings counted by geo-hub)', 'pf_ms_rollup'],
        'graph' => ['A graph walk (two steps out from the best-linked record)', 'pf_ms_graph'],
        'index' => ['An index lookup (one address in the W0 frontier)', 'pf_ms_index'],
    ];
    /** Companies whose red line holds everything (the engine can't launch without them). */
    private const CORE = ['bluehost', 'railway', 'github'];
    /** Outside links for fixes (a step Jason takes elsewhere). */
    private const ENV_URL = 'https://my.bluehost.com/hosting/app#/cpanel';
    /** A W0 test batch asked of the indexer is handed out once, then waited for this long. */
    private const ASK_SECS = 900;

    private static ?array $cache = null;   // one run's shared reads (cron lines, the register)

    // ---- the list -------------------------------------------------------------------------------------------------------

    /** Every line in run order: id => [group, name, required, company key ('' none), workflow ('' none)]. */
    public static function lines(PDO $pdo): array
    {
        require_once __DIR__ . '/OutsideServices.php';
        require_once __DIR__ . '/Automation.php';
        require_once __DIR__ . '/SystemStart.php';
        $L = [
            'site:db' => ['site', 'The four databases answer (main, admin, listings, users)', true, '', ''],
            'site:env' => ['site', 'The site can read and write .env', true, 'bluehost', ''],
            'site:envdup' => ['site', '.env names each set once (a second line is ignored)', true, 'bluehost', ''],
            'site:dbup' => ['site', 'Database updates: none waiting or failed', true, '', ''],
            'site:sched' => ['site', 'The scheduler: every automatic job is set up in cPanel', true, 'bluehost', ''],
            'site:jobs' => ['site', 'Scheduled jobs: none stopped in the last day', false, '', ''],
            'site:token' => ['site', 'The workers\' shared key (CRAWLER_API_TOKEN) is set and in use', true, 'railway', ''],
            'site:health' => ['site', 'HEALTH_TOKEN for the daily health report', false, 'github', ''],
            'site:staging' => ['site', 'Staging\'s safe mode: no outside call skips the gate', false, '', ''],
            'site:php' => ['site', 'The server\'s PHP', false, 'bluehost', ''],
        ];
        $req = self::requiredServices($pdo);
        foreach (OutsideServices::COMPANIES as $k => $c) $L['svc:' . $k] = ['services', $c[0], isset($req[$k]), $k, ''];
        $L['rw:api'] = ['railway', 'Railway\'s API answers with our token, and finds both services', true, 'railway', ''];
        $L['rw:paused'] = ['railway', 'The crawler and W0 Indexer stay paused until Start the system', true, 'railway', ''];
        $L['rw:beat'] = ['railway', 'W0 Indexer is running on Railway and checking in (asleep while W0 is off)', true, 'railway', 'W0'];
        $L['rw:batch'] = ['railway', 'W0\'s full-size test batch through the intake (marked test, never stored)', true, 'railway', 'W0'];
        $L['rw:crawler'] = ['railway', 'The crawler worker\'s last run reached the site', false, 'railway', ''];
        foreach (self::TIMINGS as $k => [$what]) $L['ms:' . $k] = ['timing', $what, false, '', ''];
        foreach (self::NEEDS as $k => $n) $L['nd:' . $k] = [$n[0], $n[1], $n[0] === 'needs', '', (string) ($n[2][0] ?? '')];   // the engine's needs are needed for launch; the site's are shown
        // the engine itself is needed for launch (Jason, 2026-11-17: "they are critical to our system"): every workflow, new
        // task and phase. A red one still holds only itself and what's under it at Start the system (0163 §10).
        foreach (array_merge(SystemStart::ORDER, ['W14']) as $wf) $L['wf:' . $wf] = ['workflows', $wf . ' ' . (Automation::WORKFLOWS[$wf][0] ?? ''), true, '', $wf];
        foreach (SystemStart::TASKS as $t => $d) if ($t !== 'W14') $L['t:' . $t] = ['tasks', $d[0], true, '', (string) $d[1]];   // W14 is its workflow's line
        foreach (self::PHASES as $n => [$name]) $L['ph:' . $n] = ['phases', 'Phase ' . $n . ': ' . $name, true, '', ''];   // last: they roll up the workflows
        return $L;
    }

    /** Services any workflow uses, and what everything stands on: needed for launch (Jason, 2026-11-17). Business operations
     *  the engine doesn't run on (payments, domains, sign-in, email) stay optional for the engine's launch. */
    private static function requiredServices(PDO $pdo): array
    {
        $out = array_fill_keys(self::CORE, true);
        try {
            require_once __DIR__ . '/Operations.php'; require_once __DIR__ . '/SystemStart.php';
            // since the source map (2026-11-17), the needs carry "needed for launch": a service with a working backup no longer
            // holds the launch by itself; only what everything stands on stays needed here (CORE)
        } catch (Throwable $x) {}
        return $out;
    }

    // ---- results ----------------------------------------------------------------------------------------------------------

    /** Every stored result: id => [s, said, tested, fix, at, ms, by, hist]. */
    /** Its table, made on first use (no hand step); the cut-off rows it replaces in search_index_state are cleared once. */
    private static function ensure(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        if ($pdo->query("SHOW TABLES LIKE 'preflight_results'")->fetchColumn() !== false) return;
        $pdo->exec('CREATE TABLE IF NOT EXISTS preflight_results (id VARCHAR(40) NOT NULL PRIMARY KEY, v MEDIUMTEXT NOT NULL, at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
        try { $pdo->exec("DELETE FROM search_index_state WHERE k LIKE 'pf:r:%' OR k = 'pf:run'"); } catch (Throwable $x) {}   // once, as the table is made
    }

    private static function load(PDO $pdo, string $id): ?array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT v FROM preflight_results WHERE id = ?'); $st->execute([$id]);
        $j = json_decode((string) $st->fetchColumn(), true);
        return is_array($j) ? $j : null;
    }

    private static function store(PDO $pdo, string $id, array $v): void
    {
        self::ensure($pdo);
        $pdo->prepare('INSERT INTO preflight_results (id, v, at) VALUES (?, ?, UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE v = VALUES(v), at = VALUES(at)')
            ->execute([$id, json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
    }

    public static function results(PDO $pdo): array
    {
        $out = [];
        try {
            self::ensure($pdo);
            foreach ($pdo->query("SELECT id, v FROM preflight_results WHERE id <> '_run'")->fetchAll(PDO::FETCH_KEY_PAIR) as $k => $v) {
                $j = json_decode((string) $v, true);
                if (is_array($j)) $out[(string) $k] = $j;
            }
        } catch (Throwable $x) { error_log('Preflight::results: ' . $x->getMessage()); }
        return $out;
    }

    public static function result(PDO $pdo, string $id): ?array
    {
        try { return self::load($pdo, $id); } catch (Throwable $x) { return null; }
    }

    private static function save(PDO $pdo, string $id, array $r): void { self::store($pdo, $id, $r); }

    /** Counts and the red required lines: ['ok', 'bad', 'na', 'wait', 'new', 'req_bad' => [id => name], 'at' => last full run]. */
    public static function summary(PDO $pdo): array
    {
        $res = self::results($pdo); $out = ['ok' => 0, 'bad' => 0, 'na' => 0, 'wait' => 0, 'new' => 0, 'req_bad' => [], 'bad_ids' => [], 'at' => 0];
        foreach (self::lines($pdo) as $id => $l) {
            $s = $res[$id]['s'] ?? 'new';
            $out[$s] = ($out[$s] ?? 0) + 1;
            if ($s === 'bad') { $out['bad_ids'][$id] = $l[1]; if ($l[2]) $out['req_bad'][$id] = $l[1]; }
        }
        $run = self::result($pdo, '_run');
        $out['at'] = (int) ($run['at'] ?? 0); $out['by'] = (string) ($run['by'] ?? '');
        $out['start'] = (int) ($run['start'] ?? 0); $out['secs'] = isset($run['secs']) ? (int) $run['secs'] : null; $out['runs'] = (array) ($run['runs'] ?? []);
        $lim = self::slowMs($pdo); $out['slow'] = [];
        foreach (self::results($pdo) as $id => $r) if ((int) ($r['ms'] ?? 0) > $lim) $out['slow'][$id] = (int) $r['ms'];
        arsort($out['slow']);
        return $out;
    }

    public static function can(): array
    {
        if (!class_exists('Access', false)) require_once __DIR__ . '/../admin/Access.php';
        return Access::can('config.preflight', ['min' => 'executive', 'depts' => []]);
    }

    // ---- running ------------------------------------------------------------------------------------------------------

    /** Runs one line and keeps its result. */
    public static function run(PDO $pdo, string $id, string $by = ''): array
    {
        $lines = self::lines($pdo);
        if (!isset($lines[$id])) throw new InvalidArgumentException('Not a pre-flight line.');
        @set_time_limit(90);
        $t0 = microtime(true);
        try { $r = self::test($pdo, $id, $lines[$id]); }
        catch (Throwable $x) { error_log('preflight ' . $id . ': ' . $x->getMessage()); $r = ['bad', 'The test itself stopped: ' . mb_substr($x->getMessage(), 0, 300), 'The test', []]; }
        [$s, $said, $tested, $fix] = $r + [3 => []];
        $was = self::result($pdo, $id);
        $ms = (int) round((microtime(true) - $t0) * 1000);
        $hist = array_slice(array_merge((array) ($was['hist'] ?? []), [[time(), $s, $ms]]), -10);   // [when, state, how long it took]
        $out = ['s' => $s, 'said' => self::clean((string) $said), 'tested' => (string) $tested, 'fix' => array_values((array) $fix), 'at' => time(), 'ms' => $ms, 'by' => mb_substr($by, 0, 80), 'hist' => $hist];
        if (isset($r[4])) $out['extra'] = $r[4];
        self::save($pdo, $id, $out);
        return $out;
    }

    /** Runs every line in order (the nightly run, a .env change): services first, so what's under them reads fresh results. */
    public static function runAll(PDO $pdo, string $by): array
    {
        self::$cache = null;
        $n = ['ok' => 0, 'bad' => 0, 'na' => 0, 'wait' => 0]; $t0 = time();
        foreach (array_keys(self::lines($pdo)) as $id) { $r = self::run($pdo, $id, $by); $n[$r['s']] = ($n[$r['s']] ?? 0) + 1; }
        self::finished($pdo, $by, $t0);
        return $n;
    }

    /** A full run ended (the page's Run all, or the job): its start, end and length kept, with the last 10 runs. */
    public static function finished(PDO $pdo, string $by, int $start = 0): void
    {
        $was = self::result($pdo, '_run') ?: [];
        $now = time(); $start = $start > 0 && $start <= $now && $now - $start < 6 * 3600 ? $start : 0;
        $runs = array_slice(array_merge((array) ($was['runs'] ?? []), [[$start ?: $now, $start ? $now - $start : null, mb_substr($by, 0, 80)]]), -10);
        self::store($pdo, '_run', ['at' => $now, 'start' => $start, 'secs' => $start ? $now - $start : null, 'by' => mb_substr($by, 0, 80), 'runs' => $runs]);
        // the run log (Jason, 2026-11-17: "log its runs and have the report downloadable from that log line"): each full run,
        // its counts and its report as it stood at the end, the last 50 kept
        try {
            self::ensureRuns($pdo);
            $sum = self::summary($pdo);
            $counts = ['ok' => $sum['ok'], 'bad' => $sum['bad'], 'na' => $sum['na'], 'wait' => $sum['wait'], 'req_bad' => count($sum['req_bad']), 'slow' => count($sum['slow'])];
            $pdo->prepare('INSERT INTO preflight_runs (started, finished, secs, by_name, counts, report) VALUES (FROM_UNIXTIME(?), FROM_UNIXTIME(?), ?, ?, ?, ?)')
                ->execute([$start ?: $now, $now, $start ? $now - $start : null, mb_substr($by, 0, 80), json_encode($counts), self::report($pdo)]);
            $keep = (int) $pdo->query('SELECT id FROM preflight_runs ORDER BY id DESC LIMIT 1 OFFSET 49')->fetchColumn();
            if ($keep) $pdo->prepare('DELETE FROM preflight_runs WHERE id < ?')->execute([$keep]);
        } catch (Throwable $x) { error_log('Preflight run log: ' . $x->getMessage()); }
    }

    /** The run log's table, made on first use; staging's own (staging-tables.php). */
    private static function ensureRuns(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        $pdo->exec('CREATE TABLE IF NOT EXISTS preflight_runs (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, started DATETIME NOT NULL, finished DATETIME NOT NULL, secs INT NULL,
                    by_name VARCHAR(80) NOT NULL DEFAULT \'\', counts VARCHAR(400) NOT NULL DEFAULT \'\', report MEDIUMTEXT NOT NULL, KEY finished (finished)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    /** The run log, newest first: [[id, started, finished, secs, by, counts]] (times as Unix seconds). */
    public static function runs(PDO $pdo, int $n = 50): array
    {
        try {
            self::ensureRuns($pdo);
            $rows = $pdo->query('SELECT id, UNIX_TIMESTAMP(started) s, UNIX_TIMESTAMP(finished) f, secs, by_name, counts FROM preflight_runs ORDER BY id DESC LIMIT ' . max(1, min(50, $n)))->fetchAll(PDO::FETCH_ASSOC);
            return array_map(fn ($r) => ['id' => (int) $r['id'], 'start' => (int) $r['s'], 'end' => (int) $r['f'], 'secs' => $r['secs'] !== null ? (int) $r['secs'] : null, 'by' => (string) $r['by_name'], 'counts' => json_decode((string) $r['counts'], true) ?: []], $rows);
        } catch (Throwable $x) { return []; }
    }

    /** One logged run's report, as it stood when the run ended: [text, finished] or null. */
    public static function runReport(PDO $pdo, int $id): ?array
    {
        try {
            self::ensureRuns($pdo);
            $st = $pdo->prepare('SELECT report, UNIX_TIMESTAMP(finished) f FROM preflight_runs WHERE id = ?'); $st->execute([$id]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return $r ? [(string) $r['report'], (int) $r['f']] : null;
        } catch (Throwable $x) { return null; }
    }

    /** A line slower than this (ms) is marked slow, to come back to (Thresholds pf_slow_ms). */
    public static function slowMs(PDO $pdo): int
    {
        require_once __DIR__ . '/Thresholds.php';
        return (int) (Thresholds::get($pdo, 'pf_slow_ms') ?? 5000);
    }

    /** "3 min 12 s", "48 s", "1.2 s". */
    public static function took(?int $secs, ?int $ms = null): string
    {
        if ($ms !== null) return $ms < 1000 ? $ms . ' ms' : number_format($ms / 1000, 1) . ' s';
        if ($secs === null) return '';
        return $secs >= 60 ? intdiv($secs, 60) . ' min ' . ($secs % 60) . ' s' : $secs . ' s';
    }

    /** No secret ever leaves in an answer: long tokens and key=value pairs are cut out. */
    private static function clean(string $s): string
    {
        $s = (string) preg_replace('/((?:key|token|secret|password|apikey|api_key|access_token)=)[^\s"\'&,}]+/i', '$1…', $s);   // key=value (a URL's query)
        $s = (string) preg_replace('/("(?:key|token|secret|password|apikey|api_key|access_token|client_secret)"\s*:\s*")[^"]+/i', '$1…', $s);   // "token": "…" (JSON)
        $s = (string) preg_replace('/\b[A-Za-z0-9_\-]{32,}\b/', '…', $s);
        return mb_substr(trim($s), 0, 600);
    }

    private static function env(string $k): string
    {
        Database::readEnv();
        $v = getenv($k);
        if (($v === false || $v === '') && isset($_ENV[$k])) $v = (string) $_ENV[$k];
        return $v === false ? '' : trim((string) $v);
    }

    /** One outside call, through the gates. Returns [code, body, error, ms, headers]; code -1 when held (the reason in error). */
    private static function http(PDO $pdo, string $method, string $url, array $headers = [], $body = null, string $what = '', int $timeout = 15): array
    {
        require_once __DIR__ . '/StagingGate.php';
        if (($w = StagingGate::hold($url, 'Pre-flight: ' . $what)) !== null) return [-1, '', $w, 0, []];
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (($w = self::held($pdo, $host)) !== null) return [-1, '', $w, 0, []];
        $hdr = [];
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_USERAGENT => 'Traversence pre-flight (+https://traversence.com/)', CURLOPT_HTTPHEADER => $headers, CURLOPT_NOBODY => $method === 'HEAD',
            CURLOPT_HEADERFUNCTION => function ($c, $l) use (&$hdr) { $p = strpos($l, ':'); if ($p) $hdr[strtolower(trim(substr($l, 0, $p)))] = trim(substr($l, $p + 1)); return strlen($l); }]);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body));
        $t = microtime(true);
        $b = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
        return [$code, is_string($b) ? $b : '', $err, (int) round((microtime(true) - $t) * 1000), $hdr];
    }

    /** A host held by an open service issue (a ban, a refused key): not asked again here; the issue is the answer. */
    private static function held(PDO $pdo, string $host): ?string
    {
        try {
            require_once __DIR__ . '/ServiceHealth.php';
            $r = ServiceHealth::open($pdo, $host, 'site');
            if ($r && ServiceHealth::holding($r)) { [$t, $w] = ServiceHealth::describe($r); return 'Held by issue #' . (int) $r['id'] . ': ' . $t . '. ' . $w; }
        } catch (Throwable $x) {}
        return null;
    }

    /** A call's answer in words: [ok, words]. */
    private static function said(array $r, array $okCodes = [200]): array
    {
        [$code, $b, $err, $ms] = $r;
        if ($code === -1) return [null, $err];
        if ($code === 0) return [false, 'No answer' . ($err !== '' ? ': ' . $err : '') . '.'];
        $j = json_decode($b, true); $msg = '';
        if (is_array($j)) foreach (['message', 'error_description', 'error', 'detail', 'title'] as $k) if (isset($j[$k]) && is_scalar($j[$k])) { $msg = (string) $j[$k]; break; }
        if ($msg === '' && is_array($j['error'] ?? null)) $msg = (string) ($j['error']['message'] ?? '');
        if ($msg === '' && is_array($j['errors'][0] ?? null)) $msg = (string) ($j['errors'][0]['message'] ?? '');
        if ($msg === '' && $b !== '' && !in_array($code, $okCodes, true)) $msg = preg_match('#<title[^>]*>(.*?)</title>#is', $b, $m) ? 'a page titled ' . trim(html_entity_decode($m[1])) : mb_substr(trim((string) preg_replace('/\s+/', ' ', strip_tags($b))), 0, 160);
        if ($code === 403 && preg_match('/Just a moment|cf-chl|challenge-platform/i', $b)) $msg = 'Cloudflare\'s bot check stopped us (a challenge page)';
        return [in_array($code, $okCodes, true), 'Answered ' . $code . ' in ' . $ms . ' ms' . ($msg !== '' ? ': "' . $msg . '"' : '') . '.'];
    }

    private static function fixUrl(string $label, string $url): array { return ['url', $label, $url]; }
    private static function fixTool(string $label, string $url): array { return ['tool', $label, $url]; }
    private static function fixDo(string $act, string $label): array { return ['do', $act, $label]; }
    private static function envFix(string $names): array { return self::fixUrl('Add ' . $names . ' in .env (cPanel → File Manager)', self::ENV_URL); }

    // ---- the tests -----------------------------------------------------------------------------------------------------

    /** [state ok|bad|na|wait, the answer in words, what was tested, fixes, extra?]. */
    private static function test(PDO $pdo, string $id, array $line): array
    {
        [$grp] = $line;
        if ($grp === 'services') return self::service($pdo, substr($id, 4));
        if ($grp === 'timing') return self::timing($pdo, substr($id, 3));
        if ($grp === 'workflows') return self::workflow($pdo, substr($id, 3));
        if ($grp === 'phases') return self::phase($pdo, (int) substr($id, 3));
        if ($grp === 'tasks') return self::task($pdo, substr($id, 2));
        if ($grp === 'needs' || $grp === 'siteneeds') return self::need($pdo, substr($id, 3));
        switch ($id) {
            case 'site:db':
                $v = (string) $pdo->query('SELECT VERSION()')->fetchColumn(); $out = ['main (' . Database::mainName() . ')']; $bad = []; $na = [];
                foreach (array_keys(Database::REALMS) as $r) {
                    [$db] = Database::realmConfig($r);
                    if (!$db) { $na[] = $r; continue; }
                    try { Database::realm($r)->query('SELECT 1'); $out[] = $r; } catch (Throwable $x) { $bad[] = $r . ' (' . mb_substr($x->getMessage(), 0, 80) . ')'; }
                }
                return [$bad ? 'bad' : 'ok', 'Answered: ' . implode(', ', $out) . '. Server ' . $v . '.' . ($na ? ' Not set up in .env: ' . implode(', ', $na) . '.' : '') . ($bad ? ' Refused: ' . implode('; ', $bad) . '.' : ''),
                    'A SELECT 1 on each database, with its own login', $bad ? [self::envFix('the DB_… settings')] : []];
            case 'site:env':
                $p = Database::envPath(); $ok = is_file($p) && is_readable($p) && is_writable($p) && is_writable(dirname($p));
                return [$ok ? 'ok' : 'bad', $ok ? 'Readable and writable, with a copy kept before each change (Settings changes it from the admin).' : (!is_file($p) ? 'There\'s no .env above the web root.' : 'The site can read it but not write it, so Settings can\'t change it from the admin.'),
                    'The file\'s permissions (nothing written)', $ok ? [] : [self::fixUrl('Set .env to 0640 in cPanel → File Manager', self::ENV_URL)]];
            case 'site:envdup':   // the site keeps the FIRST line for a name (Database::loadEnv): a newer value below it is silently ignored (Jason's Fly token, 2026-11-17)
                $p = Database::envPath(); $seen = []; $twice = [];
                foreach (is_readable($p) ? (file($p, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: []) : [] as $n => $l) {
                    $l = trim($l); if ($l === '' || $l[0] === '#' || !str_contains($l, '=')) continue;
                    $k = trim(explode('=', $l, 2)[0]);   // the name only: never the value
                    if (isset($seen[$k])) $twice[$k] = ($twice[$k] ?? [$seen[$k]]); else $seen[$k] = $n + 1;
                    if (isset($twice[$k])) $twice[$k][] = $n + 1;
                }
                $list = array_map(fn ($k, $ls) => $k . ' (lines ' . implode(', ', array_unique($ls)) . ')', array_keys($twice), $twice);
                return [$twice ? 'bad' : 'ok', $twice ? 'Set more than once: ' . implode('; ', $list) . '. The site uses the first line and ignores the rest, so a newer value further down has no effect: keep one line each, with the value you want.' : 'Each of its ' . count($seen) . ' names is set once.',
                    'The names in .env (never their values), counted', $twice ? [self::fixUrl('Edit .env in cPanel → File Manager (the home folder, above public_html)', self::ENV_URL)] : []];
            case 'site:dbup':
                require_once __DIR__ . '/DbUpdates.php';
                $w = DbUpdates::all($pdo); $f = array_keys(array_filter(DbUpdates::log($pdo), fn ($r) => !(int) $r['ok']));
                return [!$w && !$f ? 'ok' : 'bad', !$w && !$f ? 'None waiting, none failed.' : trim(($w ? count($w) . ' waiting (' . implode(', ', array_slice(array_column($w, 'file'), 0, 3)) . '). ' : '') . ($f ? count($f) . ' failed: ' . implode(', ', array_slice($f, 0, 3)) . '.' : '')),
                    'The migrations folder and the database updates log', $w || $f ? [self::fixDo('dbup', 'Run database updates now'), self::fixTool('Database updates', '/admin/config/dbupdates')] : []];
            case 'site:sched':
                require_once __DIR__ . '/Scheduler.php'; require_once __DIR__ . '/CPanel.php';
                if (!CPanel::ready()) return ['bad', 'cPanel\'s API isn\'t connected (CPANEL_HOST, CPANEL_USER, CPANEL_TOKEN), so the jobs can\'t be read or set up from here.', 'cPanel\'s cron list', [self::envFix('CPANEL_HOST, CPANEL_USER and CPANEL_TOKEN')]];
                $lines = self::cron();
                if ($lines === null) return ['bad', 'cPanel didn\'t answer the cron list just now.', 'cPanel\'s cron list (read only)', [self::fixTool('Scheduled tasks', '/admin/config/scheduler')]];
                $miss = [];
                foreach (Scheduler::AUTO as $j) if (!Scheduler::lineFor($lines, $j)) $miss[] = $j;
                return [$miss ? 'bad' : 'ok', $miss ? count($miss) . ' of ' . count(Scheduler::AUTO) . ' automatic jobs have no cron line: ' . implode(', ', $miss) . '. They\'re added within the hour by themselves, or now with the button.' : 'All ' . count(Scheduler::AUTO) . ' automatic jobs have their cron line (' . count($lines) . ' lines in cPanel).',
                    'cPanel\'s cron list (read only), against Scheduler::AUTO', $miss ? [self::fixDo('sched', 'Set them up now'), self::fixTool('Scheduled tasks', '/admin/config/scheduler')] : []];
            case 'site:jobs':
                require_once __DIR__ . '/Scheduler.php';
                $bad = []; foreach (Scheduler::lastRuns($pdo) as $j => $r) if ((int) ($r['fails_today'] ?? 0)) $bad[] = (Scheduler::JOBS[$j][0] ?? $j) . ' (' . (int) $r['fails_today'] . ')';
                return [$bad ? 'bad' : 'ok', $bad ? 'Stopped in the last day: ' . implode(', ', $bad) . '.' : 'None stopped in the last day.', 'Each job\'s runs, as it records them', $bad ? [self::fixTool('Scheduled tasks', '/admin/config/scheduler')] : []];
            case 'site:token':
                if (self::env('CRAWLER_API_TOKEN') === '') return ['bad', 'CRAWLER_API_TOKEN isn\'t in .env, so neither worker can reach the site.', 'The setting', [self::envFix('CRAWLER_API_TOKEN (the same value as on Railway)')]];
                $seen = [];
                try { $at = $pdo->query('SELECT MAX(started_at) FROM crawl_runs')->fetchColumn(); if ($at) $seen[] = 'the crawler, ' . self::ago((int) strtotime((string) $at)); } catch (Throwable $x) {}
                try { require_once __DIR__ . '/crawler/Frontier.php'; $b = Frontier::lastBeat($pdo); if (!empty($b['at'])) $seen[] = 'W0 Indexer, ' . self::ago((int) $b['at']); } catch (Throwable $x) {}
                return [$seen ? 'ok' : 'wait', $seen ? 'Set, and accepted from: ' . implode('; ', $seen) . ' (the site refuses a wrong key, so a call that got in proves it matches).' : 'Set; no worker has used it yet.', 'The setting, and the workers\' last calls that got in', $seen ? [] : [self::fixUrl('Railway: both services → Variables', 'https://railway.com/dashboard')]];
            case 'site:health':
                $on = self::env('HEALTH_TOKEN') !== '';
                return [$on ? 'ok' : 'bad', $on ? 'Set. It must match the GitHub secret HEALTH_TOKEN, which the site can\'t read; the daily report failing would be the sign.' : 'Not set: the daily health report can\'t read the server.', 'The setting', [self::fixUrl('GitHub: the HEALTH_TOKEN secret', 'https://github.com/degraffics/traversence/settings/secrets/actions')] + ($on ? [] : [1 => self::envFix('HEALTH_TOKEN')])];
            case 'site:staging':
                require_once __DIR__ . '/Staging.php'; require_once __DIR__ . '/StagingGate.php';
                $root = dirname(__DIR__, 2);
                $hits = is_dir($root . '/app/lib') ? StagingGate::scan($root) : [];
                return [$hits ? 'bad' : 'ok', (Staging::here() ? 'This is staging: outside calls are held, sandboxed or paced. ' : 'This is the live site. ') . ($hits ? count($hits) . ' outside call(s) skip the gate, first ' . $hits[0][0] . ':' . $hits[0][1] . ' (' . $hits[0][2] . ').' : 'No outside call skips the gate.'),
                    'The code scanned for ungated calls (StagingGate::scan)', $hits ? [self::fixTool('Staging', '/admin/config/staging')] : []];
            case 'site:php':
                return ['ok', 'PHP ' . PHP_VERSION . ' (' . PHP_SAPI . '), curl ' . (function_exists('curl_version') ? (curl_version()['version'] ?? '?') : 'missing') . '.', 'The running version', []];
            case 'rw:api': return self::railwayApi($pdo);
            case 'rw:paused': return self::railwayPaused($pdo);
            case 'rw:beat': return self::w0Beat($pdo);
            case 'rw:batch': return self::w0Batch($pdo);
            case 'rw:crawler':
                try {
                    $r = $pdo->query('SELECT started_at, status, why, worker_v FROM crawl_runs ORDER BY id DESC LIMIT 1')->fetch(PDO::FETCH_ASSOC);
                    if (!$r) return ['wait', 'No crawler run has reached the site yet.', 'The crawler\'s runs, as the site records them', [self::fixUrl('Railway: the crawler service', 'https://railway.com/dashboard')]];
                    return ['ok', 'Its last run (worker ' . ($r['worker_v'] ?: '?') . ') reached the site ' . self::ago((int) strtotime((string) $r['started_at'])) . ': ' . $r['status'] . ($r['why'] ? ' ("' . mb_substr((string) $r['why'], 0, 120) . '")' : '') . '. While it\'s paused, each run ends at once; that\'s expected.', 'The crawler\'s runs, as the site records them', []];
                } catch (Throwable $x) { return ['bad', 'Couldn\'t read its runs: ' . $x->getMessage(), 'The crawler\'s runs', []]; }
        }
        return ['na', 'No test for this line yet.', '', []];
    }

    private static function ago(int $ts): string
    {
        $d = max(0, time() - $ts);
        return $d < 120 ? $d . ' seconds ago' : ($d < 7200 ? round($d / 60) . ' minutes ago' : ($d < 172800 ? round($d / 3600) . ' hours ago' : round($d / 86400) . ' days ago'));
    }

    private static function cron(): ?array
    {
        if (isset(self::$cache['cron'])) return self::$cache['cron'] ?: null;
        try { require_once __DIR__ . '/Scheduler.php'; $l = Scheduler::cronLines(); } catch (Throwable $x) { $l = []; }
        self::$cache['cron'] = $l;
        return $l ?: null;
    }

    // ---- outside companies (each card's Test) ------------------------------------------------------------------------

    /** A key that lives on Railway: the crawler reports whether it has it at each run (never the value). */
    /** The names of the crawler service's variables on Railway (its API, read only), or null. The values come back in the
     *  same answer and are dropped at once: only the names are kept, never logged or stored. */
    private static function railwayVarNames(PDO $pdo): ?array
    {
        if (array_key_exists('rwvars', (array) self::$cache)) return self::$cache['rwvars'];
        $names = null;
        if (self::env('RAILWAY_API_TOKEN') !== '' && self::env('RAILWAY_PROJECT_ID') !== '' && self::env('RAILWAY_SERVICE_ID') !== '') {
            $p = self::railwayGql($pdo, 'query($p: String!) { project(id: $p) { environments { edges { node { id name } } } } }', ['p' => self::env('RAILWAY_PROJECT_ID')]);
            $env = ''; foreach ($p[2]['project']['environments']['edges'] ?? [] as $e) { if ($env === '' || strtolower((string) $e['node']['name']) === 'production') $env = (string) $e['node']['id']; }
            if ($p[0] && $env !== '') {
                $v = self::railwayGql($pdo, 'query($p: String!, $e: String!, $s: String) { variables(projectId: $p, environmentId: $e, serviceId: $s) }', ['p' => self::env('RAILWAY_PROJECT_ID'), 'e' => $env, 's' => self::env('RAILWAY_SERVICE_ID')]);
                if ($v[0] && is_array($v[2]['variables'] ?? null)) $names = array_keys(array_filter($v[2]['variables'], fn ($x) => trim((string) $x) !== ''));   // names of the set ones; the values go no further
                unset($v);
            }
        }
        self::$cache['rwvars'] = $names;
        return $names;
    }

    private static function railwayKey(PDO $pdo, string $svc, string $name, string $what): array
    {
        require_once __DIR__ . '/Operations.php';
        $calls = self::crawlerCalls($pdo, $svc);
        // first Railway's own list (Jason's second report: the crawler has no schedule while paused, so its own report goes stale)
        $vars = self::railwayVarNames($pdo);
        if ($vars !== null) {
            $have = in_array($name, $vars, true);
            return [$have ? 'ok' : 'bad', ($have ? $name . ' is set on the crawler service (read from Railway, names only). ' . $what : $name . ' isn\'t set on the crawler service (read from Railway, names only).') . $calls,
                'The crawler service\'s variable names, from Railway\'s API (values never kept)', $have ? [] : [self::fixUrl('Add ' . $name . ' on Railway: gracious-sparkle → traversence → Variables', 'https://railway.com/dashboard')]];
        }
        $have = Operations::workerKeys()[$name] ?? null;
        if ($have === null) return ['wait', 'The key lives on Railway, where the site can\'t read it; the crawler hasn\'t reported its keys yet (it does at the start of each run).' . $calls, 'The crawler\'s report of its keys (names only)', [self::fixUrl('Railway: the crawler service → Variables', 'https://railway.com/dashboard')]];
        return [$have ? 'ok' : 'bad', ($have ? $name . ' is on Railway (the crawler\'s report). ' . $what : $name . ' isn\'t on Railway (the crawler\'s report).') . $calls, 'The crawler\'s report of its keys (names only) and its calls this month', $have ? [] : [self::fixUrl('Add ' . $name . ' on Railway: the crawler service → Variables', 'https://railway.com/dashboard')]];
    }

    private static function crawlerCalls(PDO $pdo, string $svc): string
    {
        try {
            $st = $pdo->prepare('SELECT SUM(calls) n, SUM(fails) f, MAX(at) last FROM crawl_service_calls WHERE service = ? AND at >= NOW() - INTERVAL 30 DAY'); $st->execute([$svc]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            if ((int) ($r['n'] ?? 0)) return ' The crawler\'s calls in 30 days: ' . number_format((int) $r['n']) . ', ' . number_format((int) $r['f']) . ' failed; the last ' . self::ago((int) strtotime((string) $r['last'])) . '.';
        } catch (Throwable $x) {}
        return '';
    }

    /** A free public endpoint answers (the service's own reachability, through the gates). */
    private static function reach(PDO $pdo, string $url, string $what, array $ok = [200], string $method = 'GET', array $h = []): array
    {
        $r = self::http($pdo, $method, $url, $h, null, $what);
        [$good, $words] = self::said($r, $ok);
        return [$good === null ? 'wait' : ($good ? 'ok' : 'bad'), $words, $what . ' (' . $method . ' ' . preg_replace('/([?&](key|api_key|apikey)=)[^&]+/', '$1…', $url) . ')', []];
    }

    private static function service(PDO $pdo, string $k): array
    {
        $e = fn (string $n) => self::env($n);
        $r = self::serviceTest($pdo, $k, $e);   // its card's link is drawn on every company's line (preflight-console.php)
        try { require_once __DIR__ . '/Automation.php'; if (($p = Automation::serviceOff($pdo, $k)) !== null && $r[0] !== 'na') $r[1] .= ' (Paused on Automation until Start the system: this read-only test runs anyway.)'; } catch (Throwable $x) {}
        return $r;
    }

    private static function serviceTest(PDO $pdo, string $k, callable $e): array
    {
        require_once __DIR__ . '/Operations.php';
        $na = fn (string $why) => ['na', $why, 'Whether it\'s set up', []];
        switch ($k) {
            case 'cloudflare':
                $out = []; $bad = false; $fix = [];
                if (str_contains($e('S3_ENDPOINT'), 'r2.cloudflarestorage.com')) {
                    require_once __DIR__ . '/Aws.php'; require_once __DIR__ . '/S3.php';
                    [$ok, $say] = Aws::checkBucket(); $cors = $ok ? S3::corsOk() : null;
                    $out[] = 'R2: ' . $say . ($cors === false ? '; uploads need the CORS rule' : ($cors ? '; uploads ready' : ''));
                    if (!$ok || $cors === false) { $bad = true; $fix[] = self::fixUrl('R2 buckets', 'https://dash.cloudflare.com/?to=/:account/r2/overview'); }
                } else $out[] = 'R2 isn\'t in use (S3_ENDPOINT).';
                if ($e('TURNSTILE_SECRET_KEY') !== '') {   // a made-up token: a good secret answers "invalid-input-response", a bad one "invalid-input-secret"
                    $r = self::http($pdo, 'POST', 'https://challenges.cloudflare.com/turnstile/v0/siteverify', ['Content-Type: application/x-www-form-urlencoded'], http_build_query(['secret' => $e('TURNSTILE_SECRET_KEY'), 'response' => 'preflight-not-a-token']), 'Turnstile: the secret checked with a made-up token');
                    $codes = (array) (json_decode($r[1], true)['error-codes'] ?? []);
                    if ($r[0] === -1) $out[] = 'Turnstile: ' . $r[2];
                    elseif (in_array('invalid-input-secret', $codes, true)) { $bad = true; $out[] = 'Turnstile refused our secret (invalid-input-secret).'; $fix[] = self::fixUrl('Turnstile', 'https://dash.cloudflare.com/?to=/:account/turnstile'); }
                    elseif ($r[0] === 200) $out[] = 'Turnstile accepted our secret (it refused only the made-up token, as it should).';
                    else { $bad = true; $out[] = 'Turnstile: ' . self::said($r)[1]; }
                } else $out[] = 'Turnstile isn\'t set up.';
                return [$bad ? 'bad' : 'ok', implode(' ', $out), 'The bucket answers a HEAD and its CORS rule; Turnstile\'s siteverify with a made-up token', $fix];
            case 'aws':
                require_once __DIR__ . '/SesMail.php';
                if (!SesMail::hasKeys('personal')) return $na('SES isn\'t set up (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY).');
                $t = microtime(true);
                try { [$c, $b] = SesMail::api('personal', 'GET', '/v2/email/account'); } catch (Throwable $x) { $c = 0; $b = $x->getMessage(); }
                $j = json_decode((string) $b, true) ?: [];
                if ($c !== 200) return ['bad', 'SES answered ' . $c . ': ' . mb_substr((string) ($j['message'] ?? $b), 0, 200), 'SES GetAccount (read only)', [self::fixUrl('SES', 'https://console.aws.amazon.com/ses/home#/get-set-up'), self::fixUrl('The site\'s key (IAM)', 'https://us-east-1.console.aws.amazon.com/iam/home#/users')]];
                $prod = !empty($j['ProductionAccessEnabled']);
                return [SesMail::mode() === 'live' && !$prod ? 'bad' : 'ok', 'SES accepted our key in ' . SesMail::region() . ' (' . (int) round((microtime(true) - $t) * 1000) . ' ms). Production access: ' . ($prod ? 'yes' : 'not yet (sandbox: only verified addresses)') . '. Mode here: ' . SesMail::mode() . ' (mock records, sends nothing).',
                    'SES GetAccount (read only; nothing is sent)', $prod ? [] : [self::fixUrl('Ask for production access', 'https://console.aws.amazon.com/ses/home#/account')]];
            case 'anthropic':
                if ($e('ANTHROPIC_API_KEY') === '') return $na('Not set up (ANTHROPIC_API_KEY).');
                $r = self::http($pdo, 'GET', 'https://api.anthropic.com/v1/models?limit=1', ['x-api-key: ' . $e('ANTHROPIC_API_KEY'), 'anthropic-version: 2023-06-01'], null, 'Anthropic: list models');
                [$ok, $w] = self::said($r);
                return [$ok === null ? 'wait' : ($ok ? 'ok' : 'bad'), $ok ? 'Our key is accepted (' . $w . ') Listing models costs nothing.' : $w, 'The models list with our key (free; no answer is written)', $ok ? [] : [self::fixUrl('Keys', 'https://console.anthropic.com/settings/keys')]];
            case 'google':
                $out = []; $bad = false;
                $kr = self::railwayKey($pdo, 'google', 'GOOGLE_PLACES_KEY', 'Each check costs about 3 cents, so it isn\'t called here.');
                $out[] = 'Places: ' . $kr[1]; if ($kr[0] === 'bad') $bad = true;
                if ($e('GOOGLE_CLIENT_ID') !== '') {
                    $r = self::http($pdo, 'GET', 'https://accounts.google.com/.well-known/openid-configuration', [], null, 'Google sign-in: its discovery document');
                    $out[] = 'Continue with Google: ' . ($r[0] === 200 ? 'Google\'s sign-in answers; our client ID is set.' : self::said($r)[1]);
                    if ($r[0] !== 200 && $r[0] !== -1) $bad = true;
                }
                return [$bad ? 'bad' : $kr[0], implode(' ', $out), 'The crawler\'s key report (Places costs money, so it\'s never called here); Google\'s sign-in discovery', $kr[3]];
            case 'tavily': return self::railwayKey($pdo, 'tavily', 'TAVILY_API_KEY', 'Each search counts against the month, so none is made here.');
            case 'brave': return self::railwayKey($pdo, 'brave', 'BRAVE_API_KEY', 'Each search counts against its plan, so none is made here.');   // Brave and Tavily both live and ready; which a workflow uses is the workflow's (Jason, 2026-11-17)
            case 'ridb': return self::railwayKey($pdo, 'ridb', 'RIDB_API_KEY', 'Its monthly load runs on the crawler.');
            case 'foursquare':
                $kr = self::railwayKey($pdo, 'foursquare', 'HF_TOKEN', '');
                $r = self::http($pdo, 'GET', 'https://huggingface.co/api/datasets/foursquare/fsq-os-places', [], null, 'Hugging Face: the dataset\'s card');
                $kr[1] .= ' The dataset: ' . ($r[0] === 200 ? 'Hugging Face answers (gated: the token\'s account must have accepted Foursquare\'s terms).' : self::said($r)[1]);
                if ($r[0] > 0 && $r[0] !== 200) $kr[0] = 'bad';
                return $kr;
            case 'railway':
                if ($e('RAILWAY_API_TOKEN') === '') return ['bad', 'RAILWAY_API_TOKEN isn\'t in .env: the site can\'t read or set the crawler\'s schedule.', 'The setting', [self::envFix('RAILWAY_API_TOKEN, RAILWAY_PROJECT_ID and RAILWAY_SERVICE_ID')]];
                $g = self::railwayGql($pdo, 'query($p: String!) { project(id: $p) { name } }', ['p' => self::env('RAILWAY_PROJECT_ID')]);   // a team or project token can't ask "me" (400): the project, as Start the system asks
                return [$g[0] ? 'ok' : 'bad', $g[0] ? 'Railway accepted our token and reads project ' . ($g[2]['project']['name'] ?? '?') . '. (Its services are checked under "W0 and the crawler on Railway".)' : $g[1], 'Railway\'s API: our project (read only)', $g[0] ? [] : [self::fixUrl('Railway: account → Tokens', 'https://railway.com/account/tokens')]];
            case 'bluehost':
                $out = []; $bad = false; $fix = [];
                if (self::env('SMTP_HOST') !== '') {
                    [$ok, $w] = self::smtp($pdo);
                    $out[] = 'The site\'s email: ' . $w; if (!$ok) { $bad = true; $fix[] = self::fixUrl('Email accounts (cPanel)', self::ENV_URL); }
                } else $out[] = 'The site\'s email uses the server\'s own mail (no SMTP_HOST).';
                require_once __DIR__ . '/CPanel.php';
                if (CPanel::ready()) { $l = self::cron(); $out[] = 'cPanel\'s API: ' . ($l !== null ? 'answered (' . count($l) . ' cron lines).' : 'didn\'t answer.'); if ($l === null) $bad = true; }
                else { $out[] = 'cPanel\'s API isn\'t connected.'; $bad = true; $fix[] = self::envFix('CPANEL_HOST, CPANEL_USER and CPANEL_TOKEN'); }
                return [$bad ? 'bad' : 'ok', implode(' ', $out), 'A sign-in to the mail server without sending (EHLO, AUTH, QUIT); cPanel\'s cron list', $fix];
            case 'quickbooks':
                require_once __DIR__ . '/QuickBooksPay.php';
                if (!QuickBooksPay::configured()) return $na('Not set up (QB_CLIENT_ID, QB_CLIENT_SECRET; QB_SANDBOX_… for the sandbox).');
                $c = QuickBooksPay::connection($pdo);
                if (!$c) return ['bad', 'The app is set up (' . QuickBooksPay::env() . ') but no company is connected.', 'The connection on file (no call: a call could renew its tokens)', [self::fixTool('Connect it on E-Commerce → Payments', '/admin/ecommerce.php')]];
                $until = strtotime((string) $c['refresh_until']);
                return [$until > time() + 7 * 86400 ? 'ok' : 'bad', 'Connected (' . QuickBooksPay::env() . '); its sign-in is good until ' . gmdate('M j, Y', $until) . ' UTC' . ($until <= time() ? ': it has run out.' : ($until <= time() + 7 * 86400 ? ': under a week left, reconnect soon.' : '.')), 'The connection on file (no call: a call could renew its tokens)', $until > time() + 7 * 86400 ? [] : [self::fixTool('Reconnect on E-Commerce → Payments', '/admin/ecommerce.php')]];
            case 'stripe':
                $key = $e('STRIPE_TEST_SECRET_KEY') ?: $e('STRIPE_SECRET_KEY');
                if ($key === '') return $na('Not set up (STRIPE_TEST_SECRET_KEY).');
                if (!str_starts_with($key, 'sk_test_') && !str_starts_with($key, 'rk_test_')) return ['bad', 'The key set as the test key isn\'t a test key, so it isn\'t used here (no test touches real money).', 'The key\'s kind', [self::fixUrl('Stripe: test keys', 'https://dashboard.stripe.com/test/apikeys')]];
                $r = self::http($pdo, 'GET', 'https://api.stripe.com/v1/balance', ['Authorization: Bearer ' . $key], null, 'Stripe sandbox: the balance');
                [$ok, $w] = self::said($r);
                return [$ok === null ? 'wait' : ($ok ? 'ok' : 'bad'), ($ok ? 'The sandbox accepted our test key. ' : '') . $w, 'The sandbox\'s balance with the test key (read only; never a live key)', $ok ? [] : [self::fixUrl('Stripe: test keys', 'https://dashboard.stripe.com/test/apikeys')]];
            case 'square':
                $tok = $e('SQUARE_SANDBOX_ACCESS_TOKEN') ?: $e('SQUARE_ACCESS_TOKEN');
                if ($tok === '') return $na('Not set up (SQUARE_SANDBOX_ACCESS_TOKEN).');
                $r = self::http($pdo, 'GET', 'https://connect.squareupsandbox.com/v2/locations', ['Authorization: Bearer ' . $tok, 'Square-Version: 2024-10-17'], null, 'Square sandbox: locations');
                [$ok, $w] = self::said($r);
                return [$ok === null ? 'wait' : ($ok ? 'ok' : 'bad'), ($ok ? 'The sandbox accepted our token. ' : '') . $w, 'The sandbox\'s locations (read only; the sandbox host only)', $ok ? [] : [self::fixUrl('Square: developer apps', 'https://developer.squareup.com/apps')]];
            case 'namecom':
                $u = $e('NAMECOM_TEST_USER') ?: $e('NAMECOM_USER'); $t = $e('NAMECOM_TEST_TOKEN') ?: $e('NAMECOM_TOKEN');
                if ($u === '' || $t === '') return $na('Not set up (NAMECOM_TEST_USER, NAMECOM_TEST_TOKEN).');
                $r = self::http($pdo, 'POST', 'https://api.dev.name.com/core/v1/domains:checkAvailability', ['Content-Type: application/json', 'Authorization: Basic ' . base64_encode($u . ':' . $t)], ['domainNames' => ['traversence-preflight-' . gmdate('ymd') . '.com'], 'purchaseType' => 'registration'], 'Name.com sandbox: a search with a price');
                $j = json_decode($r[1], true) ?: []; $x = $j['results'][0] ?? null;
                if ($r[0] === 200 && $x) { $price = (float) ($x['purchasePrice'] ?? 0);
                    return [$price > 0 ? 'ok' : 'bad', 'The sandbox answered ' . $x['domainName'] . ': ' . (!empty($x['purchasable']) ? 'available' : 'not available') . ($price > 0 ? ', $' . number_format($price, 2) . ' a year.' : ', with no price.'), 'A search in Name.com\'s sandbox (api.dev.name.com; nothing bought)', $price > 0 ? [] : [self::fixUrl('Name.com: API settings', 'https://www.name.com/account/settings/api')]]; }
                return [$r[0] === -1 ? 'wait' : 'bad', self::said($r)[1], 'A search in Name.com\'s sandbox (api.dev.name.com; nothing bought)', [self::fixUrl('Name.com: API settings (the sandbox\'s own …-test user and token)', 'https://www.name.com/account/settings/api')]];
            case 'fly':
                if ($e('FLY_API_TOKEN') === '' || $e('FLY_APP') === '') return $na('Not set up (FLY_API_TOKEN, FLY_APP): businesses\' own domains open later.');
                $tok = $e('FLY_API_TOKEN'); $auth = str_starts_with($tok, 'FlyV1 ') ? $tok : (str_starts_with($tok, 'fm1') || str_starts_with($tok, 'fm2') ? 'FlyV1 ' . $tok : 'Bearer ' . $tok);   // a macaroon ("fly tokens create") goes as FlyV1, a personal token as Bearer
                $r = self::http($pdo, 'POST', 'https://api.fly.io/graphql', ['Authorization: ' . $auth, 'Content-Type: application/json'], ['query' => 'query($a: String!) { app(name: $a) { name certificates(first: 50) { totalCount nodes { hostname clientStatus } } } }', 'variables' => ['a' => $e('FLY_APP')]], 'Fly: the edge\'s certificates');
                $j = json_decode($r[1], true) ?: []; $app = $j['data']['app'] ?? null;
                if ($r[0] === 200 && $app) { $n = (int) ($app['certificates']['totalCount'] ?? 0); $pend = count(array_filter((array) ($app['certificates']['nodes'] ?? []), fn ($c) => strtolower((string) $c['clientStatus']) !== 'ready'));
                    return ['ok', 'Our token reads ' . $app['name'] . '\'s certificates: ' . $n . ' in all' . ($pend ? ', ' . $pend . ' not ready yet' : '') . '.', 'The edge app\'s certificate list (read only)', []]; }
                return [$r[0] === -1 ? 'wait' : 'bad', ($r[0] === 200 ? 'Fly answered but couldn\'t read ' . $e('FLY_APP') . ': ' . mb_substr((string) ($j['errors'][0]['message'] ?? 'no app'), 0, 200) : self::said($r)[1]) . ' (Sent as ' . strtok($auth, ' ') . '. FLY_API_TOKEN should be the whole line "fly tokens create deploy -a ' . $e('FLY_APP') . '" prints, starting "FlyV1 ", set once in .env; the .env line above checks for a second one.)', 'The edge app\'s certificate list (read only)', [self::fixUrl('Fly: the traversence organization\'s tokens', 'https://fly.io/dashboard/traversence/tokens')]];
            case 'github':
                $out = []; $bad = false;
                foreach (['GITHUB_DOCS_TOKEN' => 'degraffics/traversence', 'GITHUB_SYNC_TOKEN' => 'degraffics/traverse-3way-sync'] as $n => $repo) {
                    if ($e($n) === '') { $out[] = $n . ': not set.'; $bad = true; continue; }
                    $r = self::http($pdo, 'GET', 'https://api.github.com/repos/' . $repo, ['Authorization: Bearer ' . $e($n), 'Accept: application/vnd.github+json', 'X-GitHub-Api-Version: 2022-11-28'], null, 'GitHub: ' . $repo);
                    $exp = (string) ($r[4]['github-authentication-token-expiration'] ?? '');
                    $soon = $exp !== '' && strtotime($exp) < time() + 14 * 86400;
                    if ($r[0] !== 200 || $soon) $bad = true;
                    $out[] = $n . ': ' . ($r[0] === 200 ? 'reads ' . $repo : self::said($r)[1]) . ($exp !== '' ? '; expires ' . gmdate('M j, Y', (int) strtotime($exp)) . ($soon ? ' (soon: make a new one)' : '') : '; no expiry date') . '.';
                }
                return [$bad ? 'bad' : 'ok', implode(' ', $out), 'Each token reads its repository (and GitHub says when it expires)', $bad ? [self::fixUrl('GitHub: fine-grained tokens', 'https://github.com/settings/personal-access-tokens')] : []];
            case 'microsoft':
                if ($e('MICROSOFT_CLIENT_ID') === '') return $na('Sign in with Microsoft isn\'t set up (MICROSOFT_CLIENT_ID).');
                $t = preg_replace('/[^A-Za-z0-9.-]/', '', $e('MICROSOFT_TENANT') ?: 'common');
                return self::reach($pdo, 'https://login.microsoftonline.com/' . $t . '/v2.0/.well-known/openid-configuration', 'Microsoft sign-in: its discovery document for our tenant') ;
            case 'apple':
                if ($e('APPLE_CLIENT_ID') === '') return $na('Sign in with Apple isn\'t set up (APPLE_CLIENT_ID).');
                return self::reach($pdo, 'https://appleid.apple.com/auth/keys', 'Apple sign-in: the keys it signs with');
            case 'meta':
                if ($e('FACEBOOK_APP_ID') === '' || $e('FACEBOOK_APP_SECRET') === '') return $na('Sign in with Facebook isn\'t set up (FACEBOOK_APP_ID, FACEBOOK_APP_SECRET).');
                $r = self::http($pdo, 'GET', 'https://graph.facebook.com/oauth/access_token?' . http_build_query(['client_id' => $e('FACEBOOK_APP_ID'), 'client_secret' => $e('FACEBOOK_APP_SECRET'), 'grant_type' => 'client_credentials']), [], null, 'Meta: the app\'s own token');
                [$ok, $w] = self::said($r);
                return [$ok === null ? 'wait' : ($ok ? 'ok' : 'bad'), $ok ? 'Meta accepted our app ID and secret (an app token, kept nowhere).' : $w, 'An app token from our ID and secret (nothing posted; kept nowhere)', $ok ? [] : [self::fixUrl('Meta: the app\'s basic settings', 'https://developers.facebook.com/apps/')]];
            case 'census':
                $key = $e('CENSUS_API_KEY');
                $r = self::reach($pdo, 'https://api.census.gov/data/2020/dec/pl?get=NAME&for=state:04' . ($key !== '' ? '&key=' . rawurlencode($key) : ''), 'Census: Arizona\'s name from the 2020 count');
                if ($key === '') $r[1] .= ' (No CENSUS_API_KEY: it works without, at a lower daily limit.)';
                return $r;
            case 'osm':
                require_once __DIR__ . '/ServiceHealth.php';
                $free = 0; $all = [];
                try { $all = ServiceHealth::servers($pdo, 'osm', 'overpass', true); foreach ($all as $sv) { $st = ServiceHealth::serverState($pdo, $sv); if (!(int) $sv['paused'] && $st[0] !== 'bad') $free++; } } catch (Throwable $x) {}
                // each server not held (the site's own list), 6 seconds at most each; ready once one answers (Jason's report: one slow server isn't a failure)
                $urls = [];
                foreach ($all as $sv) { $st = ServiceHealth::serverState($pdo, $sv); if (!(int) $sv['paused'] && $st[0] !== 'bad' && !empty($sv['url'])) $urls[] = (string) $sv['url']; }
                if (!$urls) $urls = ['https://overpass-api.de/api/interpreter'];
                $said = []; $ok = false;
                foreach ($urls as $u) {
                    // a tiny real query (one node's id: the smallest answer Overpass gives), as the crawler would ask; 10 s at most
                    $x = self::http($pdo, 'POST', $u, ['Content-Type: application/x-www-form-urlencoded'], http_build_query(['data' => '[out:json][timeout:8];node(1);out ids;']), 'Overpass: a one-node query', 10);
                    [$good, $w] = self::said($x);
                    $said[] = (string) parse_url($u, PHP_URL_HOST) . ': ' . ($good ? 'answered in ' . $x[3] . ' ms' : rtrim($w, '.'));
                    if ($good) { $ok = true; break; }
                }
                return [$ok ? 'ok' : 'bad', ($all ? $free . ' of ' . count($all) . ' Overpass servers free. ' : '') . implode('; ', $said) . '.', 'A one-node query to each free Overpass server in turn, 10 seconds at most each, until one answers', $ok ? [] : [self::fixTool('OpenStreetMap\'s servers on its card', '/admin/config/services#svc-osm')]];
            case 'wikimedia': return self::reach($pdo, 'https://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q816&props=labels&languages=en&format=json', 'Wikidata: one record (Arizona)');
            case 'gemini':
                if ($e('GEMINI_API_KEY') === '') return ['bad', 'GEMINI_API_KEY isn\'t in .env.', 'The setting', [self::envFix('GEMINI_API_KEY'), self::fixUrl('Google AI Studio: API keys', 'https://aistudio.google.com/app/apikey')]];
                $r = self::http($pdo, 'GET', 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1', ['x-goog-api-key: ' . $e('GEMINI_API_KEY')], null, 'Gemini: list models');
                [$ok, $w] = self::said($r);
                return [$ok === null ? 'wait' : ($ok ? 'ok' : 'bad'), $ok ? 'Our key is accepted (' . $w . ') Listing models uses none of the day\'s allowance.' : $w, 'The models list with our key (free; nothing generated)', $ok ? [] : [self::fixUrl('Google AI Studio: API keys', 'https://aistudio.google.com/app/apikey')]];
            case 'supabase': return self::supabase($pdo);
            case 'overture': return self::reach($pdo, 'https://overturemaps-us-west-2.s3.amazonaws.com/?list-type=2&prefix=release/&delimiter=/&max-keys=5', 'Overture: its public bucket lists the releases');
            case 'geofabrik': return self::reach($pdo, 'https://download.geofabrik.de/north-america/us/arizona-updates/state.txt', 'Geofabrik: Arizona\'s extract state (a few bytes, not the file)');
            case 'azcc': return self::reach($pdo, 'https://ecorp.azcc.gov/', 'The Arizona Corporation Commission\'s search page', [200, 301, 302]);
            case 'nmsos': return self::reach($pdo, 'https://enterprise.sos.nm.gov/search', 'New Mexico\'s business search page', [200, 301, 302]);
            case 'azlicences': return ['na', 'Inactive: not released yet (licence lists, queue 3a). Their sites (azliquor.gov, roc.az.gov, the counties\') sit behind a Cloudflare challenge, so they aren\'t called; their lists come as monthly exports through the uploader when 3a ships.', 'Nothing: not called until released (Jason, 2026-11-17)', []];
            case 'heigit':
                if ($e('ORS_API_KEY') === '') return $na('Not set up (ORS_API_KEY).');
                $base = rtrim($e('ORS_API_URL') ?: 'https://api.heigit.org/openrouteservice', '/');   // its address since 2026 (api.openrouteservice.org is retired), as TravelLegs asks
                $r = self::http($pdo, 'POST', $base . '/v2/matrix/driving-car', ['Authorization: ' . $e('ORS_API_KEY'), 'Content-Type: application/json', 'Accept: application/json'], ['locations' => [[-111.6513, 35.1983], [-111.6097, 35.2135]], 'metrics' => ['duration']], 'openrouteservice: a two-point matrix');   // downtown Flagstaff to the university
                [$ok, $w] = self::said($r);
                if ($r[0] >= 500) $w .= ' That\'s their server\'s error, not our key (a refused key answers 401 or 403): try again later.';
                return [$ok === null ? 'wait' : ($ok ? 'ok' : 'bad'), ($ok ? 'Our key is accepted: one free leg near Kayenta. ' : '') . $w, 'A two-point travel-time matrix in Flagstaff with our key, the call the journeys make (1 of its 500 a day)', $ok ? [] : [self::fixUrl('openrouteservice: your keys', 'https://openrouteservice.org/dev/#/home')]];
            case 'nws': return self::reach($pdo, 'https://api.weather.gov/points/36.7278,-110.2546', 'The National Weather Service: Kayenta\'s forecast point', [200], 'GET', ['Accept: application/geo+json']);
            case 'az511':
                if ($e('AZ511_API_KEY') === '') return $na('Not set up (AZ511_API_KEY).');
                return self::reach($pdo, 'https://az511.com/api/wzdx?key=' . rawurlencode($e('AZ511_API_KEY')), 'AZ 511: the work zones feed with our key');
            case 'nps': return self::reach($pdo, 'https://npgallery.nps.gov/', 'NPGallery', [200, 301, 302]);
            case 'usgs': return self::reach($pdo, 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer?f=json', 'The National Map: the topo layer\'s description');
            case 'cms': return self::reach($pdo, 'https://npiregistry.cms.hhs.gov/api/?version=2.1&state=AZ&city=Kayenta&limit=1', 'The NPI Registry: one provider in Kayenta');
            case 'irs': return self::reach($pdo, 'https://www.irs.gov/charities-non-profits/exempt-organizations-business-master-file-extract-eo-bmf', 'The IRS\'s EO BMF page', [200, 301, 302]);
            case 'cpsc': return self::reach($pdo, 'https://www.saferproducts.gov/RestWebServices/Recall?format=json&RecallDateStart=' . gmdate('Y-m-d', time() - 3 * 86400), 'SaferProducts.gov: the last three days\' recalls');
            case 'loc': return self::reach($pdo, 'https://www.loc.gov/search/?q=kayenta&fo=json&c=1', 'The Library of Congress: one search result', [200, 301, 302]);
            case 'commoncrawl': return self::reach($pdo, 'https://index.commoncrawl.org/collinfo.json', 'Common Crawl: its list of indexes');
            case 'dbip': return self::reach($pdo, 'https://db-ip.com/db/download/ip-to-country-lite', 'DB-IP: the free country file\'s page', [200, 301, 302]);
            case 'pixabay':
                if ($e('PIXABAY_KEY') === '') return $na('Not set up (PIXABAY_KEY).');
                $r = self::reach($pdo, 'https://pixabay.com/api/?key=' . rawurlencode($e('PIXABAY_KEY')) . '&q=canyon&per_page=3', 'Pixabay: one search with our key (free)');
                if ($r[0] === 'bad') $r[3][] = self::fixUrl('Pixabay: your API key', 'https://pixabay.com/api/docs/');
                return $r;
            case 'tailwind': return self::reach($pdo, 'https://cdn.tailwindcss.com/', 'Tailwind\'s CDN (what visitors\' browsers load)', [200, 301, 302], 'HEAD');
            case 'vimeo': return self::reach($pdo, 'https://player.vimeo.com/api/player.js', 'Vimeo\'s player (what visitors\' browsers load)', [200, 301, 302], 'HEAD');
            case 'onepassword': return $na('The site never calls 1Password: each card links to the login there.');
        }
        return $na('Nothing to test from the site.');
    }

    /** A sign-in to the mail server without sending: EHLO, AUTH LOGIN, QUIT. [ok, words]. */
    private static function smtp(PDO $pdo): array
    {
        require_once __DIR__ . '/StagingGate.php';
        $host = self::env('SMTP_HOST'); $port = (int) (self::env('SMTP_PORT') ?: 465);
        if (($w = StagingGate::hold('https://' . $host . '/', 'Pre-flight: the mail server\'s sign-in')) !== null) return [true, $w];
        $t = microtime(true);
        $s = @stream_socket_client(($port === 465 ? 'ssl://' : 'tcp://') . $host . ':' . $port, $no, $err, 10);
        if (!$s) return [false, 'Couldn\'t connect to ' . $host . ':' . $port . ' (' . $err . ').'];
        stream_set_timeout($s, 10);
        $read = function () use ($s): string { $o = ''; while (($l = fgets($s, 1024)) !== false) { $o .= $l; if (isset($l[3]) && $l[3] === ' ') break; } return $o; };
        $cmd = function (string $c) use ($s, $read): string { fwrite($s, $c . "\r\n"); return $read(); };
        $read(); $cmd('EHLO traversence.com');
        if ($port === 587) { $cmd('STARTTLS'); @stream_socket_enable_crypto($s, true, STREAM_CRYPTO_METHOD_TLS_CLIENT); $cmd('EHLO traversence.com'); }
        $cmd('AUTH LOGIN'); $cmd(base64_encode(self::env('SMTP_USERNAME') ?: self::env('SMTP_FROM_EMAIL'))); $a = $cmd(base64_encode(self::env('SMTP_PASSWORD')));
        $cmd('QUIT'); fclose($s);
        $ok = str_starts_with($a, '235');
        return [$ok, ($ok ? 'Signed in to ' . $host . ':' . $port . ' and left without sending' : 'The server refused the sign-in (' . trim(substr($a, 0, 80)) . ')') . ' (' . (int) round((microtime(true) - $t) * 1000) . ' ms).'];
    }

    private static function supabase(PDO $pdo): array
    {
        $url = rtrim(self::env('SUPABASE_URL'), '/'); $k = self::env('SUPABASE_SERVICE_KEY');
        if ($url === '' || $k === '') return ['bad', 'Supabase isn\'t connected: SUPABASE_URL and SUPABASE_SERVICE_KEY in .env.', 'The settings', [self::envFix('SUPABASE_URL and SUPABASE_SERVICE_KEY')]];
        $r = self::http($pdo, 'HEAD', $url . '/rest/v1/tv_vectors?select=ref', ['apikey: ' . $k, 'Authorization: Bearer ' . $k, 'Prefer: count=exact', 'Range: 0-0'], null, 'Supabase: the index\'s size');
        if ($r[0] === -1) return ['wait', $r[2], 'Supabase', []];
        if ($r[0] === 0 || $r[0] >= 500 || $r[0] === 540) return ['bad', 'Supabase didn\'t answer (' . ($r[0] ?: $r[2]) . '): the free project may be paused. Restore it; search keeps to the normal index meanwhile (0164 §5.2\'s note).', 'The index\'s row count (read only)', [self::fixUrl('Supabase: the project (Restore)', 'https://supabase.com/dashboard/projects')]];
        if ($r[0] === 404) return ['bad', 'Supabase is awake but the table tv_vectors isn\'t there: run the setup SQL from its card.', 'The index\'s row count (read only)', [self::fixTool('The setup SQL on Supabase\'s card', '/admin/config/services#svc-supabase'), self::fixUrl('Supabase: SQL editor', 'https://supabase.com/dashboard/projects')]];
        if ($r[0] >= 400) return ['bad', self::said($r, [200, 206])[1], 'The index\'s row count (read only)', [self::fixUrl('Supabase: API keys', 'https://supabase.com/dashboard/projects')]];
        $n = (int) preg_replace('#^.*/#', '', (string) ($r[4]['content-range'] ?? '0'));
        // locked down: without our key, the table refuses
        $anon = self::http($pdo, 'GET', $url . '/rest/v1/tv_vectors?select=ref&limit=1', [], null, 'Supabase: the index without our key');
        $locked = in_array($anon[0], [401, 403, 404], true) || $anon[0] === -1;
        $want = 0;
        try { $want = (int) $pdo->query("SELECT COUNT(*) FROM entities WHERE entity_type = 'merchant' AND is_suppressed = 0")->fetchColumn(); } catch (Throwable $x) {}
        $since = SearchIndex::state($pdo, 'vectors:since');
        $behind = 0;
        try { $st = $pdo->prepare("SELECT COUNT(*) FROM entities WHERE entity_type = 'merchant' AND is_suppressed = 0 AND updated_at > ?"); $st->execute([$since ?: '2000-01-01']); $behind = (int) $st->fetchColumn(); } catch (Throwable $x) {}
        $complete = $behind === 0;
        $taskOn = false;   // the vector index fills only once its task is on (Start the system): an empty index before then is expected
        try { require_once __DIR__ . '/AiClient.php'; require_once __DIR__ . '/Automation.php'; $taskOn = !empty(AiClient::feature($pdo, 'vector_index')['enabled']) && Automation::serviceOff($pdo, 'supabase') === null && Automation::masterOff($pdo) === null; } catch (Throwable $x) {}
        $ok = $locked && ($complete || !$taskOn);
        return [$ok ? 'ok' : 'bad', 'Awake, ' . $r[3] . ' ms. The index holds ' . number_format($n) . ' vector(s) for ' . number_format($want) . ' public listings' . ($complete ? ', none waiting.' : '; ' . number_format($behind) . ' changed since its last upkeep and wait for it' . ($taskOn ? ' (its task is on, so it should be catching up).' : ': expected, as the vector index task fills it once Start the system switches it on (confidential ones are never sent).')) . ($locked ? ' Without our key it refuses (locked down).' : ' It answers WITHOUT our key: turn on row level security for tv_vectors.'),
            'The index\'s row count, the listings changed since its last upkeep, and a call without our key (all read only)', $locked ? ($complete ? [] : [self::fixTool('Automation: the vector index task', '/admin/config/automation')]) : [self::fixUrl('Supabase: table editor → tv_vectors → RLS', 'https://supabase.com/dashboard/projects')]];
    }

    // ---- Railway and W0 ------------------------------------------------------------------------------------------------

    private static function railwayGql(PDO $pdo, string $q, array $vars): array
    {
        $r = self::http($pdo, 'POST', 'https://backboard.railway.com/graphql/v2', ['Authorization: Bearer ' . self::env('RAILWAY_API_TOKEN'), 'Content-Type: application/json'], ['query' => $q, 'variables' => $vars], 'Railway: a read');
        if ($r[0] === -1) return [false, $r[2], []];
        $j = json_decode($r[1], true) ?: [];
        if ($r[0] !== 200 || !empty($j['errors'])) return [false, 'Railway answered ' . $r[0] . (!empty($j['errors'][0]['message']) ? ': "' . mb_substr((string) $j['errors'][0]['message'], 0, 200) . '"' : '') . '.', []];
        return [true, '', (array) ($j['data'] ?? [])];
    }

    /** The project's services: name => [id, cron, restart]. */
    private static function railwayServices(PDO $pdo): array
    {
        if (isset(self::$cache['rw'])) return self::$cache['rw'];
        $g = self::railwayGql($pdo, 'query($p: String!) { project(id: $p) { name services { edges { node { id name serviceInstances { edges { node { cronSchedule restartPolicyType environmentId } } } } } } } }', ['p' => self::env('RAILWAY_PROJECT_ID')]);
        $out = ['ok' => $g[0], 'why' => $g[1], 'project' => (string) ($g[2]['project']['name'] ?? ''), 'svc' => []];
        foreach ($g[2]['project']['services']['edges'] ?? [] as $e) {
            $n = $e['node']; $i = $n['serviceInstances']['edges'][0]['node'] ?? [];
            $out['svc'][(string) $n['name']] = [(string) $n['id'], $i['cronSchedule'] ?? null, (string) ($i['restartPolicyType'] ?? '')];
        }
        return self::$cache['rw'] = $out;
    }

    private static function railwayApi(PDO $pdo): array
    {
        foreach (['RAILWAY_API_TOKEN', 'RAILWAY_PROJECT_ID', 'RAILWAY_SERVICE_ID'] as $n) if (self::env($n) === '') return ['bad', $n . ' isn\'t in .env.', 'The settings', [self::envFix('RAILWAY_API_TOKEN, RAILWAY_PROJECT_ID and RAILWAY_SERVICE_ID')]];
        $rw = self::railwayServices($pdo);
        if (!$rw['ok']) return ['bad', $rw['why'], 'The project\'s services (read only)', [self::fixUrl('Railway: account → Tokens', 'https://railway.com/account/tokens')]];
        $names = array_keys($rw['svc']);
        $crawler = array_search(self::env('RAILWAY_SERVICE_ID'), array_map(fn ($s) => $s[0], $rw['svc']), true);
        $w0 = isset($rw['svc']['w0-indexer']);
        $ok = $crawler !== false && $w0;
        return [$ok ? 'ok' : 'bad', 'Project ' . $rw['project'] . ': ' . implode(', ', $names) . '. ' . ($crawler !== false ? 'RAILWAY_SERVICE_ID is "' . $crawler . '" (the crawler). ' : 'No service has the id in RAILWAY_SERVICE_ID. ') . ($w0 ? 'w0-indexer is there.' : 'There\'s no service called w0-indexer.'),
            'The project\'s services (read only)', $ok ? [] : [self::fixUrl('Railway: the project', 'https://railway.com/dashboard')]];
    }

    private static function railwayPaused(PDO $pdo): array
    {
        require_once __DIR__ . '/Automation.php'; require_once __DIR__ . '/SystemStart.php';
        $st = (string) (SystemStart::state($pdo)['state'] ?? 'idle');
        if (in_array($st, ['running', 'stopped', 'done'], true)) return ['na', 'Start the system has been pressed (' . (SystemStart::LABELS[$st] ?? $st) . '), so the engine is meant to be on.', 'Start the system\'s state', []];
        $why = [];
        $master = Automation::master($pdo);
        if (!$master) $why[] = 'the master switch is ON';
        if (Automation::wfOff($pdo, 'W0') === null && $master === null) $why[] = 'W0 is on';
        $cron = '';
        if (self::env('RAILWAY_API_TOKEN') !== '') {
            $rw = self::railwayServices($pdo);
            foreach ($rw['svc'] as $name => [$id, $c]) if ($id === self::env('RAILWAY_SERVICE_ID')) { $cron = (string) $c; if ($cron !== '') $why[] = 'the crawler (' . $name . ') has a schedule on Railway (' . $cron . '), so it would run'; }
            if (!$rw['ok']) $why[] = 'Railway couldn\'t be read (' . $rw['why'] . ')';
        }
        require_once __DIR__ . '/crawler/Frontier.php';
        $words = 'The master switch is off' . ($master ? ' (' . Automation::line($master, 'paused') . ')' : '') . '; the crawler has no schedule on Railway; W0 Indexer ' . (Frontier::off($pdo) !== null ? 'is told to sleep at each check-in' : 'would read') . '.';
        return [$why ? 'bad' : 'ok', $why ? 'Before Start the system, ' . implode('; ', $why) . '.' : $words, 'The master switch, W0\'s answer at check-in, and the crawler\'s schedule on Railway (read only; nothing is changed here)',
            $why ? [self::fixTool('Pause everything (Automation)', '/admin/config/automation#start')] : []];
    }

    private static function w0Beat(PDO $pdo): array
    {
        require_once __DIR__ . '/crawler/Frontier.php';
        if (!Frontier::ready($pdo)) return ['bad', 'The frontier\'s database update hasn\'t run yet.', 'The frontier', [self::fixTool('Database updates', '/admin/config/dbupdates')]];
        $b = Frontier::lastBeat($pdo);
        if (empty($b['at'])) return ['bad', 'W0 Indexer has never checked in.', 'Its last check-in', [self::fixUrl('Railway: the w0-indexer service', 'https://railway.com/dashboard')]];
        $age = time() - (int) $b['at']; $s = Frontier::size($pdo);
        return [$age < 300 ? 'ok' : 'bad', 'Last check-in ' . self::ago((int) $b['at']) . ' (version ' . ($b['v'] ?? '?') . ', batch ' . (int) ($b['batch'] ?? 0) . ', gap ' . ($b['gap'] ?? '?') . ' s' . (!empty($b['mismatches']) ? ', ' . (int) $b['mismatches'] . ' mismatched receipts in a row' : '') . '). '
            . ($age < 300 ? 'It answers: ' . (Frontier::off($pdo) ?? 'on, reading') . ' ' : 'Over 5 minutes: is the service running? ')
            . 'The frontier: ' . number_format($s['rows']) . ' addresses, ' . number_format($s['sites']) . ' sites, ' . $s['mb'] . ' MB; ' . number_format($s['day']) . ' new today.',
            'Its check-ins (every minute while it sleeps) and the frontier\'s size', $age < 300 ? [] : [self::fixUrl('Railway: the w0-indexer service', 'https://railway.com/dashboard')]];
    }

    /** Asks the sleeping indexer for one full-size test batch at its next check-in (handed out once; api/crawl/index.php). */
    private static function w0Batch(PDO $pdo): array
    {
        require_once __DIR__ . '/crawler/Frontier.php'; require_once __DIR__ . '/Thresholds.php';
        $ask = json_decode(SearchIndex::state($pdo, 'w0:test_ask'), true) ?: [];
        $since = (int) ($ask['at'] ?? 0);
        $got = null;
        // the receipt's time is the database's own clock (NOW()), so the ask's time is compared in it too (FROM_UNIXTIME)
        if ($since) { try { $st = $pdo->prepare("SELECT declared, received, stored_n, ok, bytes, ms, at FROM " . Database::t('crawl_batches') . " WHERE kind = 'test' AND at >= FROM_UNIXTIME(?) ORDER BY id DESC LIMIT 1"); $st->execute([$since]); $got = $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable $x) {} }
        if ($got) {
            $full = (int) Thresholds::get($pdo, 'indexer_found_batch');
            $ok = (int) $got['ok'] && (int) $got['received'] === (int) $got['declared'] && (int) $got['stored_n'] === (int) $got['received'] && (int) $got['declared'] >= $full;
            SearchIndex::setState($pdo, 'w0:test_ask', '');
            return [$ok ? 'ok' : 'bad', 'The indexer sent ' . (int) $got['declared'] . ' addresses in one batch (' . round((int) $got['bytes'] / 1024, 1) . ' KB); the site received ' . (int) $got['received'] . ' and checked ' . (int) $got['stored_n'] . ' in ' . (int) $got['ms'] . ' ms, storing none (a test). '
                . ($ok ? 'The receipt matches: the host, its firewall and the intake take a full batch.' : ((int) $got['declared'] < $full ? 'It was smaller than a full batch (' . $full . '): the worker\'s settings didn\'t reach it.' : 'The receipt doesn\'t match: something on the way cut it (Bluehost\'s ModSecurity or bot check).')),
                'One full-size batch from the w0-indexer service on Railway to the intake (kind test: checked and answered, never stored); W0 stays paused', $ok ? [] : [self::fixTool('Thresholds: W0\'s batch size', '/admin/config/thresholds')]];
        }
        if ($since && time() - $since < self::ASK_SECS) return ['wait', 'Asked ' . self::ago($since) . '; the indexer sends it at its next check-in (about a minute). Test again shortly.', 'One full-size batch from the w0-indexer service (marked test, never stored)', []];
        $v = (string) (Frontier::lastBeat($pdo)['v'] ?? '');
        if ($v !== '' && version_compare($v, '1.1.0', '<')) return ['bad', 'The indexer on Railway is version ' . $v . ': it sends the test batch from 1.1.0, which Railway deploys from main.', 'Its version at check-in', [self::fixUrl('Railway: the w0-indexer service → Deployments', 'https://railway.com/dashboard')]];
        SearchIndex::setState($pdo, 'w0:test_ask', json_encode(['at' => time(), 'handed' => 0]));
        return ['wait', 'Asked just now: the sleeping indexer sends one full-size test batch at its next check-in (about a minute), without W0 starting. Test again shortly.', 'One full-size batch from the w0-indexer service (marked test, never stored)', []];
    }

    /** For api/crawl/index.php's check-in: true once when the pre-flight asked for a test batch (then marked handed out). */
    public static function takeTestAsk(PDO $pdo): bool
    {
        try {
            $ask = json_decode(SearchIndex::state($pdo, 'w0:test_ask'), true);
            if (!is_array($ask) || !empty($ask['handed']) || time() - (int) ($ask['at'] ?? 0) > self::ASK_SECS) return false;
            $ask['handed'] = time();
            SearchIndex::setState($pdo, 'w0:test_ask', json_encode($ask));
            return true;
        } catch (Throwable $x) { return false; }
    }

    // ---- query timings -----------------------------------------------------------------------------------------------

    private static function timing(PDO $pdo, string $k): array
    {
        require_once __DIR__ . '/Thresholds.php';
        [$what, $gate] = self::TIMINGS[$k];
        $limit = (int) Thresholds::get($pdo, $gate);
        $sql = ''; $args = [];
        switch ($k) {
            case 'radius':
                [$lat, $lon, $mi] = [36.7278, -110.2546, 50];
                $sql = "SELECT COUNT(*) FROM entities e WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.latitude BETWEEN ? AND ? AND e.longitude BETWEEN ? AND ?
                          AND (3958.8 * 2 * ASIN(SQRT(POWER(SIN(RADIANS(e.latitude - ?) / 2), 2) + COS(RADIANS(?)) * COS(RADIANS(e.latitude)) * POWER(SIN(RADIANS(e.longitude - ?) / 2), 2)))) <= ?";
                $d = $mi / 69.0; $args = [$lat - $d, $lat + $d, $lon - $d * 1.3, $lon + $d * 1.3, $lat, $lat, $lon, $mi];
                break;
            case 'rollup':
                $sql = "SELECT mc.geo_hub_id, COUNT(*) FROM entities e JOIN micro_clusters mc ON mc.id = e.micro_cluster_id WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 GROUP BY mc.geo_hub_id";
                break;
            case 'graph':
                try { $pdo->query('SELECT 1 FROM entity_edges LIMIT 0'); $edges = true; } catch (Throwable $x) { $edges = false; }
                if ($edges) { $start = (int) $pdo->query('SELECT from_id FROM entity_edges GROUP BY from_id ORDER BY COUNT(*) DESC LIMIT 1')->fetchColumn();
                    $sql = 'SELECT COUNT(DISTINCT e2.to_id) FROM entity_edges e1 JOIN entity_edges e2 ON e2.from_id = e1.to_id WHERE e1.from_id = ?'; $args = [$start]; $what .= ' (entity_edges)'; }
                else { try { $start = (int) $pdo->query('SELECT a_id FROM topic_relations GROUP BY a_id ORDER BY COUNT(*) DESC LIMIT 1')->fetchColumn(); } catch (Throwable $x) { return ['na', 'No graph to walk yet (neither entity_edges nor topic_relations).', $what, []]; }
                    $sql = 'SELECT COUNT(DISTINCT r2.b_id) FROM topic_relations r1 JOIN topic_relations r2 ON r2.a_id = r1.b_id WHERE r1.a_id = ?'; $args = [$start]; $what .= ' (the Topic index, until entity_edges exists)'; }
                break;
            case 'index':
                require_once __DIR__ . '/crawler/Frontier.php';
                if (Frontier::ready($pdo)) { $sql = 'SELECT COUNT(*) FROM ' . Database::t('crawl_frontier') . ' WHERE url_hash = ?'; $args = [sha1('https://traversence.com/preflight/' . mt_rand())]; }
                else { $sql = "SELECT COUNT(*) FROM entities WHERE entity_type = 'merchant' AND name = ?"; $args = ['Pre-flight ' . mt_rand()]; }
                break;
        }
        try { $pdo->exec('SET SESSION max_execution_time = 20000'); } catch (Throwable $x) {}
        $best = PHP_INT_MAX; $n = '';
        try {
            for ($i = 0; $i < 3; $i++) { $t = microtime(true); $st = $pdo->prepare($sql); $st->execute($args); $rows = $st->fetchAll(PDO::FETCH_NUM); $best = min($best, (int) round((microtime(true) - $t) * 1000)); }
            $n = count($rows) === 1 ? number_format((int) $rows[0][count($rows[0]) - 1]) . ' found' : count($rows) . ' rows';
        } catch (Throwable $x) { return ['bad', 'The query failed: ' . mb_substr($x->getMessage(), 0, 200), $what, []]; }
        finally { try { $pdo->exec('SET SESSION max_execution_time = 0'); } catch (Throwable $x) {} }
        $was = self::result($pdo, 'ms:' . $k)['extra']['ms'] ?? [];
        $hist = array_slice(array_merge((array) $was, [$best]), -10);
        $trend = count($hist) > 2 ? ' Its last runs: ' . implode(', ', array_slice($hist, -5)) . ' ms.' : '';
        $r = [$best <= $limit ? 'ok' : 'bad', 'The best of three: ' . $best . ' ms (' . $n . '), against a limit of ' . $limit . ' ms.' . $trend . ($best > $limit ? ' It has slowed as the data grew: an index, or the query, needs a look.' : ''), $what . ': read only, timed on the live database', $best > $limit ? [self::fixTool('Thresholds: its limit', '/admin/config/thresholds')] : []];
        $r[4] = ['ms' => $hist];
        return $r;
    }

    // ---- the workflows, phases and new tasks -----------------------------------------------------------------------------

    /** The worst of some results: bad over wait over ok; na when all are na or there are none. */
    private static function worst(array $states): string
    {
        foreach (['bad', 'new', 'wait', 'warn', 'ok'] as $s) if (in_array($s, $states, true)) return $s === 'new' ? 'wait' : $s;
        return 'na';
    }

    // ---- needs (the source map, decisions/0163's note of 2026-11-17) ----------------------------------------------------------

    /** One of our own copies: [works, words]. It exists, has rows, and (with a limit) isn't stale. Read only. */
    private static function ours(PDO $pdo, string $table, int $staleDays): array
    {
        if (isset(self::$cache['ours:' . $table . ':' . $staleDays])) return self::$cache['ours:' . $table . ':' . $staleDays];
        $T = Database::t($table);
        try { $any = $pdo->query('SELECT 1 FROM ' . $T . ' LIMIT 1')->fetchColumn(); }
        catch (Throwable $x) { return self::$cache['ours:' . $table . ':' . $staleDays] = [false, $table . ' isn\'t there yet']; }
        if ($any === false) return self::$cache['ours:' . $table . ':' . $staleDays] = [false, $table . ' is empty (nothing loaded yet)'];
        $rows = 0; $col = '';
        try {
            $rows = (int) $pdo->query('SELECT MAX(TABLE_ROWS) FROM information_schema.TABLES WHERE TABLE_NAME = ' . $pdo->quote($table))->fetchColumn();
            $cols = $pdo->query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_NAME = " . $pdo->quote($table) . " AND DATA_TYPE IN ('datetime', 'timestamp', 'date')")->fetchAll(PDO::FETCH_COLUMN);
            foreach (['loaded_at', 'updated_at', 'found_at', 'fetched_at', 'seen_at', 'at', 'created_at', 'first_at'] as $c) if (in_array($c, $cols, true)) { $col = $c; break; }
        } catch (Throwable $x) {}
        $newest = 0;
        if ($col !== '') { try { $newest = (int) strtotime((string) $pdo->query('SELECT MAX(`' . $col . '`) FROM ' . $T)->fetchColumn()); } catch (Throwable $x) {} }
        $age = $newest ? (int) floor((time() - $newest) / 86400) : null;
        $stale = $staleDays > 0 && $age !== null && $age > $staleDays;
        $rows = max(1, $rows); $words = ($rows > 1 ? 'about ' . number_format($rows) . ' rows' : 'it has rows') . ($age !== null ? ', newest ' . ($age === 0 ? 'today' : $age . ' day' . ($age === 1 ? '' : 's') . ' old') : '') . ($stale ? ' (stale: over ' . $staleDays . ' days)' : '');
        return self::$cache['ours:' . $table . ':' . $staleDays] = [!$stale, $words];
    }

    /** A need: its sources in order; the first that works decides how it stands. */
    private static function need(PDO $pdo, string $k): array
    {
        require_once __DIR__ . '/OutsideServices.php';
        [, , , $sources, $fallback, $soft, $planned] = self::NEEDS[$k];
        $res = self::results($pdo); $first = null; $said = []; $fix = [];
        foreach ($sources as $i => $src) {
            if ($src[0] === 'ours') { [$ok, $w] = self::ours($pdo, $src[1], (int) $src[3]); $name = 'Ours (' . $src[2] . ')'; }
            elseif ($src[0] === 'copy') { require_once __DIR__ . '/OpenPlaces.php'; [$ok, $w] = OpenPlaces::ourCopy($pdo); $name = 'Ours (' . $src[2] . ')'; $w = preg_replace('/^our OpenStreetMap copy from Geofabrik, /', '', $w); }
            elseif ($src[0] === 'svc') { $s = (string) ($res['svc:' . $src[1]]['s'] ?? 'new'); $ok = $s === 'ok'; $name = OutsideServices::COMPANIES[$src[1]][0] ?? $src[1];
                $w = $ok ? 'works' : ($s === 'na' ? 'not set up' : ($s === 'new' ? 'not tested yet' : ($s === 'wait' ? 'waiting' : 'not ready')));
                if (!$ok && $s !== 'na') $fix[] = self::fixTool('The ' . $name . ' line', '#pf-svc-' . $src[1]); }
            else { $s = (string) ($res[$src[1]]['s'] ?? 'new'); $ok = $s === 'ok'; $name = (string) $src[2]; $w = $ok ? 'works' : ($s === 'new' ? 'not tested yet' : 'not ready'); if (!$ok) $fix[] = self::fixTool('Its line', '#pf-' . str_replace(':', '-', $src[1])); }
            $said[] = ($i + 1) . '. ' . $name . ': ' . $w;
            if ($ok && $first === null) $first = $i;
        }
        $state = $first === 0 ? 'ok' : ($first !== null ? 'warn' : ($soft ? 'warn' : 'bad'));
        $head = $first === 0 ? 'Answered by its first source.' : ($first !== null ? 'Running on a backup (source ' . ($first + 1) . ').' : 'No source works, so ' . $fallback . '.');
        if (count($sources) === 1) $head .= ' No backup yet' . ($planned !== '' ? ' (planned: ' . $planned . ')' : '') . ($first !== null ? '; if it fails, ' . $fallback : '') . '.';
        return [$state, $head . ' ' . implode('; ', $said) . '.', 'Its sources in order, ours first (decisions/0163, the source map): our copies checked for rows and freshness, each outside source by its own line', $state === 'ok' ? [] : array_slice($fix, 0, 4)];
    }

    private static function workflow(PDO $pdo, string $wf): array
    {
        require_once __DIR__ . '/Operations.php'; require_once __DIR__ . '/Automation.php'; require_once __DIR__ . '/OutsideServices.php'; require_once __DIR__ . '/Scheduler.php';
        $res = self::results($pdo); $parts = []; $states = []; $fix = [];
        // its needs (the source map): each answered by its first source, a backup (amber), or nothing (red)
        $nd = [];
        foreach (self::NEEDS as $k => $n) if (in_array($wf, $n[2], true)) $nd[$k] = (string) ($res['nd:' . $k]['s'] ?? 'new');
        if ($nd) { $states[] = self::worst(array_values($nd));
            $parts[] = 'Needs: ' . implode(', ', array_map(fn ($k, $s) => preg_replace('/ \(W[^)]*\)$/', '', self::NEEDS[$k][1]) . ' ' . (['ok' => '✓', 'warn' => '(on a backup)', 'bad' => '✗', 'na' => '—', 'wait' => '…', 'new' => '(not run)'][$s] ?? $s), array_keys($nd), $nd)) . '.';
            foreach ($nd as $k => $s) if ($s === 'bad') $fix[] = self::fixTool('The "' . self::NEEDS[$k][1] . '" line', '#pf-nd-' . $k); }
        // its jobs on the scheduler
        $jobs = array_keys(array_filter(Automation::JOBS, fn ($w) => in_array($wf, $w, true)));
        if ($jobs) { $lines = self::cron(); $miss = $lines === null ? [] : array_values(array_filter($jobs, fn ($j) => !Scheduler::lineFor($lines, $j) && in_array($j, Scheduler::AUTO, true)));   // a job shipped off gets its line from Start the system (SystemStart::ensureJob)
            $later = $lines === null ? [] : array_values(array_filter($jobs, fn ($j) => !Scheduler::lineFor($lines, $j) && !in_array($j, Scheduler::AUTO, true)));
            $states[] = $lines === null ? 'wait' : ($miss ? 'bad' : 'ok');
            $parts[] = 'Scheduled jobs: ' . implode(', ', array_map(fn ($j) => Scheduler::JOBS[$j][0] ?? $j, $jobs)) . ($lines === null ? ' (cPanel unread).' : ($miss ? '; no cron line: ' . implode(', ', $miss) . '.' : ($later ? '; ' . implode(', ', $later) . ' get their cron line from Start the system (shipped off).' : ', each with its cron line.')));
            if ($miss) $fix[] = self::fixDo('sched', 'Set up the jobs now'); }
        // its crawler tasks registered
        try { require_once __DIR__ . '/crawler/CrawlService.php';
            if (CrawlService::ready($pdo)) { $t = array_filter(CrawlService::tasks($pdo), fn ($r) => (string) $r['wf'] === $wf);
                if ($t) $parts[] = 'Crawler tasks registered: ' . implode(', ', array_map(fn ($r) => (string) $r['name'] . ((int) $r['enabled'] ? '' : ' (off)'), $t)) . '.'; } } catch (Throwable $x) {}
        // its gate (the switch-on check's lines for it and its services: keys, holds, budgets, caps recorded)
        try { $red = Operations::blocking($pdo, $wf);
            $states[] = $red ? 'bad' : 'ok';
            $parts[] = $red ? 'Its gate: ' . count($red) . ' red line(s) in the switch-on check, first "' . $red[0]['line'] . '" (' . $red[0]['why'] . ').' : 'Its gate: the switch-on check has no red line for it (keys, holds, budget and caps set).';
            if ($red && !empty($red[0]['fix'])) $fix[] = self::fixTool((string) $red[0]['fix'][0], (string) $red[0]['fix'][1]); } catch (Throwable $x) { $parts[] = 'Its gate: couldn\'t read the switch-on check (' . $x->getMessage() . ').'; $states[] = 'bad'; }
        // a dry run where there's a preview
        $dry = self::dryRun($pdo, $wf, $res);
        if ($dry) { $states[] = $dry[0]; $parts[] = 'Dry run: ' . $dry[1]; }
        else $parts[] = 'Dry run: none (it has no preview mode; its tasks are tested by their parts above).';
        // its switch, as information (paused until Start the system is expected)
        $off = Automation::wfOff($pdo, $wf);
        $parts[] = $off !== null ? 'Now: ' . $off : 'Now: switched on.';
        $s = self::worst($states);
        return [$s, implode(' ', $parts), 'Everything under it: its services\' pre-flight lines, its jobs in cPanel, its crawler tasks, its gate in the switch-on check, a dry run where it has one', $fix];
    }

    /** One small step without writing: [state, words] or null. */
    private static function dryRun(PDO $pdo, string $wf, array $res): ?array
    {
        if ($wf === 'W0') { $b = $res['rw:batch'] ?? null; return [$b['s'] ?? 'wait', $b ? 'the test batch: ' . ($b['said'] ?? '') : 'the test batch hasn\'t run yet (its line under Railway).']; }
        if ($wf === 'W1') {
            try { require_once __DIR__ . '/DataCleanup.php';
                if (!DataCleanup::ready($pdo)) return ['wait', 'Data cleanup\'s database update hasn\'t run.'];
                $p = DataCleanup::preview($pdo, 'junk_name'); $r = $p['rules']['junk_name'] ?? ['act' => 0, 'check' => 0];
                $err = array_filter(array_column($p['stores'], 'error'));
                return [$err ? 'bad' : 'ok', 'Data cleanup\'s junk-name rule previewed (nothing changed): ' . (int) $r['act'] . ' it would act on, ' . (int) $r['check'] . ' for a person.' . ($err ? ' ' . implode('; ', $err) : '')];
            } catch (Throwable $x) { return ['bad', 'Data cleanup\'s preview failed: ' . $x->getMessage()]; }
        }
        return null;
    }

    private static function phase(PDO $pdo, int $n): array
    {
        $res = self::results($pdo); $w = self::PHASES[$n][1]; $st = [];
        foreach ($w as $wf) $st[$wf] = $res['wf:' . $wf]['s'] ?? 'new';
        $bad = array_keys(array_filter($st, fn ($s) => $s === 'bad'));
        return [self::worst(array_values($st)), 'Its workflows: ' . implode(', ', array_map(fn ($k, $s) => $k . ' ' . (['ok' => '✓', 'bad' => '✗', 'na' => '—', 'wait' => '…', 'new' => '(not run)'][$s] ?? $s), array_keys($st), $st)) . '.' . ($bad ? ' A red workflow holds only itself and what\'s under it (0163 §10).' : ''),
            'Ready when each of its workflows is (0164 §7)', array_map(fn ($k) => self::fixTool('The ' . $k . ' line', '#pf-wf-' . $k), $bad)];
    }

    private static function task(PDO $pdo, string $t): array
    {
        require_once __DIR__ . '/SystemStart.php'; require_once __DIR__ . '/Scheduler.php'; require_once __DIR__ . '/OutsideServices.php';
        [$name, $wf, $svcs, $jobs, $ctasks] = SystemStart::TASKS[$t];
        if ($t === 'W14') return self::workflow($pdo, 'W14');
        $res = self::results($pdo); $states = []; $parts = []; $fix = [];
        foreach ($svcs as $k) { $s = $res['svc:' . $k]['s'] ?? 'new'; $states[] = $s; $parts[] = (OutsideServices::COMPANIES[$k][0] ?? $k) . ': ' . (self::MARKS[$s] ?? $s) . '.'; if ($s === 'bad') $fix[] = self::fixTool('The pre-flight\'s ' . (OutsideServices::COMPANIES[$k][0] ?? $k) . ' line', '#pf-svc-' . $k); }
        if ($jobs) { $lines = self::cron(); foreach ($jobs as $j) { $has = $lines !== null && Scheduler::lineFor($lines, $j); $auto = in_array($j, Scheduler::AUTO, true); $states[] = $lines === null ? 'wait' : ($has || !$auto ? 'ok' : 'bad'); $parts[] = (Scheduler::JOBS[$j][0] ?? $j) . ': ' . ($lines === null ? 'cPanel unread' : ($has ? 'its cron line is there' : ($auto ? 'no cron line' : 'its cron line comes from Start the system (shipped off)'))) . '.'; } }
        if ($ctasks) { try { require_once __DIR__ . '/crawler/CrawlService.php'; $have = CrawlService::ready($pdo) ? CrawlService::tasks($pdo) : [];
            foreach ($ctasks as $c) { $byStart = !isset($have[$c]) && $t === 'recheck';   // registered by Start the system at its turn (ListingIdentity::ensureTask)
                $states[] = isset($have[$c]) || $byStart ? 'ok' : 'bad'; $parts[] = 'Crawler task ' . $c . ': ' . (isset($have[$c]) ? 'registered' . ((int) $have[$c]['enabled'] ? ', on' : ', off until Start the system') : ($byStart ? 'registered by Start the system at its turn' : 'not registered')) . '.'; } } catch (Throwable $x) {} }
        if ($t === 'recheck') { try { require_once __DIR__ . '/Operations.php'; $red = Operations::blocking($pdo, 'W2'); if ($red) { $states[] = 'bad'; $parts[] = 'W2\'s gate: "' . $red[0]['line'] . '".'; } } catch (Throwable $x) {} }
        $wfRes = $wf !== '' ? ($res['wf:' . $wf]['s'] ?? 'new') : 'ok';
        $parts[] = 'Its workflow ' . $wf . ': ' . (self::MARKS[$wfRes] ?? $wfRes) . ' (it comes on after its workflow).';
        return [self::worst($states ?: ['ok']), implode(' ', $parts), 'Its services\' lines, its jobs in cPanel and its crawler task registered', $fix];
    }

    // ---- fixes a person presses here -----------------------------------------------------------------------------------

    public static function fix(PDO $pdo, string $act, int $uid): string
    {
        [$ok, $why] = self::can();
        if (!$ok) throw new RuntimeException($why . '.');
        if ($act === 'sched') { require_once __DIR__ . '/Scheduler.php'; $r = Scheduler::sync($pdo, true); return 'Scheduled tasks set up through cPanel' . ($r ? ': ' . implode(', ', array_map(fn ($x) => is_string($x) ? $x : json_encode($x), array_slice((array) $r, 0, 6))) : '') . '.'; }
        if ($act === 'dbup') { require_once __DIR__ . '/DbUpdates.php'; $r = DbUpdates::autoRun($pdo, false, 'preflight'); return count($r['ran'] ?? []) ? count($r['ran']) . ' database update(s) run.' : 'Nothing was waiting to run' . (!empty($r['failed']) ? '; one failed: see Database updates.' : '.'); }
        throw new InvalidArgumentException('Not a fix the pre-flight makes.');
    }

    // ---- the nightly run and .env changes (app/scripts/preflight_tick.php) ---------------------------------------------------

    /** Runs everything when the night comes (2 am Arizona) or .env changed since the last look. Returns why it ran, or ''. */
    public static function tick(PDO $pdo): string
    {
        $p = Database::envPath(); clearstatcache(true, $p);
        $sig = is_file($p) ? filemtime($p) . ':' . filesize($p) : '';
        $was = json_decode(SearchIndex::state($pdo, 'pf:tick'), true) ?: [];
        $night = (new DateTime('now', new DateTimeZone('America/Phoenix')))->format('Y-m-d');
        $hour = (int) (new DateTime('now', new DateTimeZone('America/Phoenix')))->format('G');
        $why = '';
        if (($was['env'] ?? null) !== null && $sig !== $was['env']) $why = 'a .env change';
        elseif ($hour >= 2 && ($was['night'] ?? '') !== $night) $why = 'the nightly run';
        SearchIndex::setState($pdo, 'pf:tick', json_encode(['env' => $sig, 'night' => $why === 'the nightly run' ? $night : (string) ($was['night'] ?? '')]));
        if ($why === '') return '';
        if ($why === 'a .env change') sleep(5);   // a person may be mid-edit: let the file settle
        self::runAll($pdo, 'Pre-flight (' . $why . ')');
        return $why;
    }

    // ---- Pulse: one case, "Pre-flight", a step per red line ---------------------------------------------------------------

    public static function pulseItems(PDO $pdo): array
    {
        $sum = self::summary($pdo);
        if (!$sum['bad_ids']) return [];
        $n = count($sum['bad_ids']); $req = count($sum['req_bad']);
        $first = array_slice(array_values($sum['req_bad'] + $sum['bad_ids']), 0, 3);   // what launch needs first
        return [['ops:preflight', $req ? 'alert' : 'update', 'Pre-flight: ' . $n . ' not ready', ($req ? $req . ' needed for launch. ' : 'None needed for launch. ') . implode('; ', $first) . ($n > 3 ? '; and more' : '') . '.', date('Y-m-d H:i:s', $sum['at'] ?: time()), '/admin/config/preflight']];
    }

    public static function pulseSteps(PDO $pdo, callable $s): array
    {
        $res = self::results($pdo); $lines = self::lines($pdo); $out = [];
        foreach ($lines as $id => $l) {
            $r = $res[$id] ?? null;
            if (($r['s'] ?? '') !== 'bad') continue;
            $help = (string) $r['said'];
            $act = ['do', 'ops_pf_run:' . $id, 'Test again'];
            foreach ((array) $r['fix'] as $f) {
                if ($f[0] === 'do') { $act = ['do', 'ops_pf_fix:' . $f[1], (string) $f[2]]; }
                elseif ($f[0] === 'url') $help .= ' ' . $f[1] . ': ' . $f[2];
            }
            $ext = in_array($l[3], ['railway', 'quickbooks', 'aws', 'cloudflare', 'anthropic', 'tavily', 'google', 'bluehost', 'github', 'stripe', 'namecom', 'square'], true) ? $l[3] : '';
            $out[] = $s(($l[2] ? 'Needed for launch: ' : '') . $l[1], $help . ' (https://traversence.com/admin/config/preflight#pf-' . str_replace(':', '-', $id) . ')', $act, false, $ext);
        }
        $out[] = $s('Run the whole pre-flight again', 'Every line, in order; a minute or two.', ['do', 'ops_pf_all', 'Run it all']);
        return $out;
    }

    public static function pulseDo(PDO $pdo, string $what, int $uid, string $who): string
    {
        [$ok, $why] = self::can();
        if (!$ok) throw new RuntimeException($why . '.');
        if ($what === 'ops_pf_all') { $n = self::runAll($pdo, $who); return 'The pre-flight ran: ' . $n['ok'] . ' ready, ' . $n['bad'] . ' not ready, ' . $n['wait'] . ' waiting.'; }
        if (str_starts_with($what, 'ops_pf_run:')) { $r = self::run($pdo, substr($what, 11), $who); return (self::MARKS[$r['s']] ?? $r['s']) . ': ' . $r['said']; }
        if (str_starts_with($what, 'ops_pf_fix:')) return self::fix($pdo, substr($what, 11), $uid);
        throw new RuntimeException('Unknown step.');
    }

    // ---- the plain-text report (to read, or send to Claude for fixes) -----------------------------------------------------

    /** Every line's latest result as plain text: the counts and the run's times, what's not ready (launch first), the slow
     *  ones, then every line. Answers were already cleaned of secrets when stored. Times in UTC, labelled. */
    public static function report(PDO $pdo): string
    {
        $t = fn (int $ts) => $ts ? gmdate('M j, Y g:i A', $ts) . ' UTC' : 'never';
        $mark = ['ok' => 'OK  ', 'warn' => 'BKUP', 'bad' => 'FAIL', 'na' => '--  ', 'wait' => 'WAIT', 'new' => 'NEW '];   // BKUP: running on a backup
        $lines = self::lines($pdo); $res = self::results($pdo); $sum = self::summary($pdo); $lim = self::slowMs($pdo);
        $o = ['TRAVERSENCE PRE-FLIGHT REPORT', 'Made ' . $t(time()) . ' from https://traversence.com/admin/config/preflight', ''];
        $o[] = 'Ready ' . $sum['ok'] . (!empty($sum['warn']) ? ' · On a backup ' . $sum['warn'] : '') . ' · Not ready ' . $sum['bad'] . ' · Waiting ' . $sum['wait'] . ' · Not needed yet ' . $sum['na'] . ($sum['new'] ? ' · Not run ' . $sum['new'] : '') . ' · Needed for launch and not ready ' . count($sum['req_bad']);
        $o[] = 'Last full run: ' . ($sum['start'] ? $t($sum['start']) . ' to ' . gmdate('g:i A', $sum['at']) . ' UTC (' . self::took($sum['secs']) . ')' : $t($sum['at'])) . ($sum['by'] !== '' ? ', by ' . $sum['by'] : '');
        $times = array_filter(array_map(fn ($r) => isset($r[1]) && $r[1] !== null ? gmdate('M j g:i A', (int) $r[0]) . ' ' . self::took((int) $r[1]) : '', $sum['runs']));
        if ($times) $o[] = 'Recent full runs: ' . implode('; ', $times);
        $one = function (string $id) use ($lines, $res, $mark, $t, $lim): array {
            $l = $lines[$id]; $r = $res[$id] ?? null; $s = (string) ($r['s'] ?? 'new');
            $x = [$mark[$s] . ' ' . $l[1] . ' [' . $id . ($l[2] ? ', needed for launch' : ', optional') . ']'];
            if (!$r) return array_merge($x, ['      Not run yet.']);
            $x[] = '      Took ' . self::took(null, (int) $r['ms']) . ((int) $r['ms'] > $lim ? ' (SLOW: over ' . self::took(null, $lim) . ')' : '') . ', ' . $t((int) $r['at']) . (($r['by'] ?? '') !== '' ? ', by ' . $r['by'] : '');
            $x[] = '      Answer: ' . (string) $r['said'];
            if (($r['tested'] ?? '') !== '') $x[] = '      Tested: ' . (string) $r['tested'];
            foreach ((array) ($r['fix'] ?? []) as $f) $x[] = '      Fix: ' . ($f[0] === 'do' ? $f[2] . ' (a button on the line)' : $f[1] . ': ' . ($f[0] === 'tool' && str_starts_with((string) $f[2], '/') ? 'https://traversence.com' . $f[2] : ($f[0] === 'tool' ? 'https://traversence.com/admin/config/preflight' . $f[2] : $f[2])));
            $h = array_slice((array) ($r['hist'] ?? []), -10);
            if (count($h) > 1) $x[] = '      Last runs: ' . implode(' ', array_map(fn ($e) => trim($mark[(string) $e[1]] ?? '?') . (isset($e[2]) ? ' ' . self::took(null, (int) $e[2]) : ''), $h));
            return $x;
        };
        $bad = array_keys($sum['req_bad'] + $sum['bad_ids']);
        $o[] = ''; $o[] = '== NOT READY (' . count($bad) . ', needed for launch first) ==';
        foreach ($bad as $id) $o = array_merge($o, $one($id));
        if (!$bad) $o[] = 'Nothing.';
        $o[] = ''; $o[] = '== SLOW (over ' . self::took(null, $lim) . ', slowest first) ==';
        foreach ($sum['slow'] as $id => $ms) $o[] = self::took(null, $ms) . '  ' . $lines[$id][1] . ' [' . $id . ']';
        if (!$sum['slow']) $o[] = 'Nothing.';
        foreach (self::GROUPS as $g => $label) {
            $o[] = ''; $o[] = '== ' . mb_strtoupper($label) . ' ==';
            foreach ($lines as $id => $l) if ($l[0] === $g) $o = array_merge($o, $one($id));
        }
        return implode("\n", $o) . "\n";
    }

    // ---- what Start the system shows first ---------------------------------------------------------------------------------

    /** The pre-flight's latest result, for Start the system's card. */
    public static function startNote(PDO $pdo): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $sum = self::summary($pdo);
        $link = '<a href="/admin/config/preflight">Pre-flight</a>';
        if (!$sum['at']) return '<p data-tv-status="info" data-tv-label="Pre-flight first:">It hasn\'t had a full run yet. Run it on ' . $link . ' before pressing Start: it proves each service, setting and workflow works, and changes nothing.</p>';
        $when = '<time datetime="' . gmdate('c', $sum['at']) . '" data-tv-time>' . gmdate('M j, g:i A', $sum['at']) . ' UTC</time>';
        $counts = $sum['ok'] . ' ✓ · ' . $sum['bad'] . ' ✗' . ($sum['wait'] ? ' · ' . $sum['wait'] . ' waiting' : '') . ' · ' . $sum['na'] . ' not needed yet';
        if ($sum['req_bad']) {
            $holds = [];
            foreach (array_slice($sum['req_bad'], 0, 5, true) as $id => $name) $holds[] = '<a href="/admin/config/preflight#pf-' . $e(str_replace(':', '-', $id)) . '">' . $e($name) . '</a>';
            return '<p data-tv-status="bad" data-tv-label="Pre-flight:">' . $counts . ' (' . $when . '). Needed for launch and not ready: ' . implode('; ', $holds) . (count($sum['req_bad']) > 5 ? '; and more' : '') . '. Each holds what it\'s for; the rest can start, or wait until they\'re fixed. See ' . $link . '.</p>';
        }
        return '<p data-tv-status="' . ($sum['bad'] ? 'info' : 'ok') . '" data-tv-label="Pre-flight:">' . $counts . ' (' . $when . ').' . ($sum['bad'] ? ' Nothing needed for launch is red; the red lines hold only what they\'re for.' : ' Everything is ready.') . ' See ' . $link . '.</p>';
    }
}
