<?php
// directory/index.php — Get Local: businesses near you (decisions/0053, 0055 §1).
//
// Like a "businesses near me" search. The header's search is the search box: on this page, Enter shows its words here,
// and its Quick picks (Near me, Open now, Has a phone, Has a website) switch the filters (window.tvQuick). The page:
// its title with the List | Map toggle on the same line, the filters in use (each removable), then the results. The
// Map opens the full-screen map (js/map-view.js, decisions/0058 §5) with every result as a pin. The choice is remembered. Each result shows what you need at a glance: what it is, how far, the address,
// open or closed right now, and Call, Directions and Website. A confidential location shows its phone only
// (decisions/0044). The earlier directory is kept at /directory/classic.php.
//
// Takes: ?q= &cat= &catname= &cluster= | &geo= | &hub= | &lat= &lon= &radius= &near= , &open=now, &has=phone,website,
// &sort=best|distance|name. With no place in the address, it uses the place chosen on the site.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/ui/section-rails.php';

$rail = array_values(array_filter(tv_section_rail('local')['items'], fn ($it) => $it['key'] !== 'listing'));
$rail[] = ['key' => 'classic', 'label' => 'Classic directory', 'icon' => 'book', 'url' => '/directory/classic.php', 'what' => 'The earlier directory, with its tools', 'section' => 'Also'];

// "Send the crawler" (decisions/0157 §3): Jason only (the Founder, signed in to the admin), under the results
$sendCrawler = false;
try {
    require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
    require_once __DIR__ . '/../../app/admin/Access.php';
    $me = Auth::currentUser();
    $sendCrawler = $me && IntakeStager::canUseIntake(Database::connection(), $me) && Access::who()[0] === 'founder';
} catch (Throwable $e) { $sendCrawler = false; }
if ($sendCrawler && empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

tv_app_start('Get Local', ['rail' => $rail, 'active' => 'directory', 'rail_label' => 'Get Local', 'bare' => true,
    'description' => 'Local businesses and services near you: open now, phone, directions and website at a glance.']);
?>
<style>
  /* top row: where (left), List | Map (right); then the title and count; filters live in the search's Quick picks */
  .dr-bar{display:flex;align-items:center;justify-content:space-between;gap:.6rem}
  .dr-wgrp{display:inline-flex;align-items:center;gap:.3rem;min-width:0;max-width:70%}
  .dr-wx{flex:0 0 auto;width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#92400E;font-size:1rem;line-height:1;cursor:pointer}.dr-wx[hidden]{display:none}.dr-wx:hover{background:#F7EFDC}
  .dr-head{margin-top:.6rem;display:flex;flex-wrap:wrap;align-items:baseline;gap:.2rem .8rem}
  .dr-head .dr-sum{margin:0}.dr-head .dr-chips{margin:0}
  /* the finder (2026-11-12): one search across the top, Refine under it */
  .dr-rdh{font:700 1.02rem ui-serif,Georgia,serif;color:#3E2B1F;margin:1rem 0 .4rem}.dr-rdh small{font:500 .78rem system-ui,sans-serif;color:#8A7355;margin-left:.4rem}
  .dr-it.dr-rd{border-style:dashed}.dr-src{color:#8A7355;font-size:.8rem}
  .dr-find{background:#FFFBF2;border:1px solid rgba(203,185,141,.85);border-radius:1rem;padding:.7rem .9rem .6rem;box-shadow:0 8px 22px -16px rgba(62,43,31,.55)}
  .dr-ftop{display:flex;align-items:center;justify-content:space-between;gap:.6rem;margin-bottom:.5rem}
  .dr-fh{font-family:ui-serif,Georgia,serif;font-weight:700;font-size:clamp(1.2rem,1.8vw,1.45rem);color:#3E2B1F;margin:0;line-height:1.2}
  .dr-ftop .dr-view button{padding:.25rem .75rem}
  .dr-form{display:flex;align-items:stretch;gap:.5rem}
  .dr-qbox{flex:1 1 auto;min-width:0;display:flex;align-items:center;gap:.5rem;border:2px solid #3E2B1F;border-radius:999px;background:#fff;padding:0 .4rem 0 .9rem;color:#5C4632}
  .dr-qbox:focus-within{border-color:#B45309;box-shadow:0 0 0 3px rgba(180,83,9,.15)}
  .dr-qbox input{flex:1;min-width:0;border:0;outline:0;background:none;font:inherit;font-size:1rem;padding:.5rem 0;color:#2B1D14}
  .dr-qbox input::-webkit-search-cancel-button{display:none}
  .dr-qx{border:0;background:none;color:#78716C;font-size:1.4rem;line-height:1;cursor:pointer;padding:0 .35rem}.dr-qx[hidden]{display:none}
  .dr-flash{animation:drfl 1.6s ease}@keyframes drfl{0%,60%{box-shadow:0 0 0 4px rgba(180,83,9,.45)}100%{box-shadow:none}}
  .dr-wbtn{flex:1;min-width:0;display:flex;align-items:center;gap:.45rem;border:0;background:none;color:#3E2B1F;font:600 1rem system-ui,sans-serif;padding:.5rem .4rem .5rem .8rem;cursor:pointer;text-align:left}
  .dr-wbtn>svg:first-child{color:#B45309;flex:none}.dr-wbtn span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.dr-wch{flex:none;color:#92400E}
  .dr-wbw .dr-wx{margin-right:.3rem}
  .dr-wtgt{flex:none;width:32px;height:32px;margin-right:.25rem;display:flex;align-items:center;justify-content:center;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#B45309;cursor:pointer;padding:0}.dr-wtgt:hover{border-color:#B45309}
  .dr-form .dr-wgrp{flex:0 1 17rem;max-width:none;min-width:11rem;border-width:2px;border-color:#CBB98D;border-radius:999px;background:#fff}
  .dr-go{flex:0 0 auto;border:0;border-radius:999px;background:#92400E;color:#FFFBF2;font:700 1rem system-ui,sans-serif;padding:0 1.5rem;cursor:pointer}
  .dr-go:hover{background:#B45309}
  .dr-refine{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .6rem;margin-top:.5rem;padding-top:.5rem;border-top:1px solid #EADFC4}
  .dr-rf select{padding:.28rem .45rem!important}.dr-tg{padding:.25rem .7rem!important}
  .dr-rl{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#8A7355}
  .dr-rf{display:inline-flex;align-items:center;gap:.35rem;font-size:.82rem;color:#5C4632}
  .dr-rf select{border:1px solid #CBB98D;border-radius:.6rem;background:#fff;padding:.38rem .5rem;font:inherit;font-size:.88rem;color:#3E2B1F;max-width:15rem}
  .dr-rf[hidden]{display:none}
  .dr-tgs{display:inline-flex;flex-wrap:wrap;gap:.35rem}
  .dr-tg{border:1px solid #CBB98D;background:#fff;color:#3E2B1F;border-radius:999px;padding:.33rem .75rem;font:600 .82rem system-ui,sans-serif;cursor:pointer}
  .dr-tg[aria-pressed="true"]{background:#8FBCA8;border-color:#5E8F7A;color:#1F3B30;box-shadow:0 0 8px rgba(143,188,168,.7)}
  .dr-head .dr-h1{font-size:clamp(1.1rem,1.8vw,1.35rem)}
  @media (max-width:767px){.dr-find{padding:.75rem .7rem}.dr-form{flex-wrap:wrap}.dr-qbox{flex-basis:100%}.dr-form .dr-wgrp{flex:1 1 auto;min-width:0}.dr-go{padding:.6rem 1.1rem}
    .dr-refine{gap:.4rem}.dr-rl{flex-basis:100%}.dr-rf{flex:1 1 45%}.dr-rf select{flex:1;max-width:none;min-width:0}}
  .dr-top{display:flex;align-items:center;gap:.6rem 1rem}
  .dr-tl{min-width:0;flex:0 1 auto}
  .dr-top .dr-chips{flex:1 1 auto;margin:0;justify-content:flex-end}
  .dr-c.sm{padding:.22rem .65rem;font-size:.8rem}
  .dr-h1{font-family:ui-serif,Georgia,serif;font-weight:700;font-size:clamp(1.35rem,2.4vw,1.85rem);color:#3E2B1F;margin:0;line-height:1.2}
  .dr-chips:empty{display:none}
  /* the map fills the workspace; the title and toggle float over it (top and left are set from the workspace) */
  html.dr-mapmode{overflow:hidden}
  html.dr-mapmode .dr-mapbox{position:fixed;top:var(--dr-t,120px);left:var(--dr-l,64px);right:0;bottom:0;height:auto;min-height:0;border:0;border-radius:0;z-index:20}
  html.dr-mapmode .dr-top{position:fixed;top:calc(var(--dr-t,120px) + 12px);left:calc(var(--dr-l,64px) + 12px);right:12px;z-index:25;pointer-events:none}
  html.dr-mapmode .dr-tl,html.dr-mapmode .dr-view,html.dr-mapmode .dr-chips{pointer-events:auto}
  html.dr-mapmode .dr-top{align-items:flex-start}
  html.dr-mapmode .dr-top .dr-chips{flex:0 1 auto;margin-left:auto;background:rgba(255,251,242,.95);border:1px solid #CBB98D;border-radius:1rem;padding:.4rem .5rem;box-shadow:0 8px 20px -10px rgba(0,0,0,.45)}
  .dr-pin.ap span{opacity:.85}
  html.dr-mapmode .dr-tl{background:rgba(255,251,242,.95);border:1px solid #CBB98D;border-radius:1rem;padding:.55rem .85rem;box-shadow:0 8px 20px -10px rgba(0,0,0,.45);max-width:min(34rem,70%)}
  html.dr-mapmode .dr-h1{font-size:1.15rem}
  html.dr-mapmode .dr-sum{margin:.15rem 0 0}
  html.dr-mapmode .dr-view{box-shadow:0 8px 20px -10px rgba(0,0,0,.45)}
  html.dr-mapmode .dr-mapbar{top:auto;bottom:1.6rem;right:auto;left:.75rem}
  html.dr-mapmode .dr-mapnote{left:auto;right:3.2rem}
  .dr-view{flex:0 0 auto;display:inline-flex;border:1px solid #CBB98D;border-radius:999px;overflow:hidden;background:#FFFBF2}
  .dr-view button{display:inline-flex;align-items:center;gap:.35rem;border:0;background:none;padding:.35rem .85rem;font-size:.84rem;font-weight:600;color:#3E2B1F;cursor:pointer}
  .dr-view button svg{width:16px;height:16px}
  .dr-view button[aria-pressed="true"]{background:#3E2B1F;color:#FFFBF2}
  .dr-lk{background:none;border:0;padding:0;color:#92400E;text-decoration:underline;font-size:.86rem;font-weight:600;cursor:pointer}
  .dr-pill{display:inline-flex;align-items:center;gap:.35rem;border:1px solid #CBB98D;background:#FFFBF2;color:#1D4ED8;border-radius:999px;padding:.25rem .75rem;font-size:.84rem;font-weight:600;cursor:pointer}
  .dr-chips{display:flex;flex-wrap:wrap;gap:.35rem;margin-top:.45rem;align-items:center}
  .dr-c{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.3rem .8rem;font-size:.84rem;cursor:pointer;white-space:nowrap}
  .dr-c.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}
  .dr-c.x::after{content:" \00d7";opacity:.8}
  .dr-sel{border:1px solid #CBB98D;background:#FFFBF2;border-radius:999px;padding:.28rem .6rem;font-size:.84rem;color:#3E2B1F}
  .dr-lbl{font-size:.72rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:#5C4632;margin:0 0 .45rem}
  .dr-grid{margin-top:.4rem}
  .dr-grid.map #dr-listbox{display:none}
  #dr-listbox{max-width:none}
  /* one column across the page's width (Jason, 2026-11-12: "a lot of wasted space", then "I dont like the two columns") */
  .dr-sum{font-size:.86rem;color:#5C4632;margin:.25rem 0 0}
  /* cards: edge to edge, 3px apart; the name is the link; Call, Directions, Website, Peek sit left under it; Link in the corner */
  #dr-list{margin-top:.6rem;display:flex;flex-direction:column;gap:3px}
  .dr-it{position:relative;display:block;background:#FFFBF2;border:1px solid rgba(203,185,141,.75);border-radius:.6rem;padding:.55rem .75rem .6rem;margin:0}
  .dr-it.hi{border-color:#B8863B;box-shadow:0 0 0 2px rgba(184,134,59,.25)}
  .dr-it{cursor:pointer}.dr-it:hover{border-color:#B8863B}   /* the whole card opens its pop-up card (2026-11-12) */
  .dr-main{min-width:0}
  .dr-n{display:inline-block;padding-right:2.6rem;font-family:ui-serif,Georgia,serif;font-weight:700;font-size:1.08rem;color:#92400E;text-decoration:underline;text-decoration-color:rgba(146,64,14,.35);text-underline-offset:3px}
  .dr-n:hover{color:#B45309;text-decoration-color:currentColor}
  .dr-m{font-size:.82rem;color:#5C4632;margin-top:.12rem;line-height:1.35}
  .dr-open{color:#15803D;font-weight:600}.dr-closed{color:#B91C1C;font-weight:600}
  .dr-badge.dr-shut{border-color:#FCA5A5;background:#FEF2F2;color:#991B1B}   /* marked closed (decisions/0072) */
  .dr-badge{font-size:.62rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;border:1px solid #86EFAC;background:#F0FDF4;color:#166534;border-radius:.3rem;padding:0 .3rem;margin-left:.3rem;vertical-align:middle}
  /* the name across the top; the actions as a column of round icons down the right edge, under the Link button
     (one line of controls down the right); the details on the left */
  .dr-main{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:.7rem;align-items:start}
  .dr-hd{grid-column:1/-1;margin-bottom:.35rem}
  /* the tools in a row, not stacked (Jason, 2026-11-12: "show the tool kit horizontally vs stacked because they are taking up
     valuable real estate"): on the name's line, left of the Link button; the details use the card's whole width */
  .dr-hd{grid-column:1;grid-row:1}
  .dr-acts{grid-column:2;grid-row:1;display:flex;flex-direction:row;flex-wrap:nowrap;gap:.3rem;margin-right:2.3rem}
  .dr-main>.dr-m{grid-column:1/-1}
  @media (min-width:521px){.dr-n{padding-right:0}}
  @media (max-width:520px){.dr-hd{grid-column:1/-1}.dr-acts{grid-column:1/-1;grid-row:2;margin:0 0 .3rem}}
  .dr-it{padding-right:.55rem}
  .dr-a{display:flex;align-items:center;justify-content:center;width:30px;height:30px;text-decoration:none;color:#B45309;background:#FFFBF2;border:1px solid #CBB98D;border-radius:999px;cursor:pointer;padding:0}
  .dr-a span{display:flex;align-items:center;justify-content:center}
  .dr-a svg{width:16px;height:16px}
  .dr-a:hover{border-color:#B45309;background:#FEF3C7}
  .dr-al{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
  .dr-more{display:block;width:100%;margin-top:.4rem;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.8rem;padding:.55rem;font-weight:600;color:#3E2B1F;cursor:pointer}
  .dr-mapbox{position:relative;border:1px solid #CBB98D;border-radius:1rem;overflow:hidden;background:#E8DCC0;height:calc(100vh - var(--ta-top,64px) - 170px);min-height:380px}
  .dr-mapbox[hidden]{display:none}
  .dr-pop b{font-family:ui-serif,Georgia,serif;font-size:.95rem;color:#3E2B1F}.dr-pop p{margin:.15rem 0;font-size:.78rem;color:#5C4632}
  .dr-pop .dr-pa{display:flex;gap:.6rem;margin-top:.35rem}.dr-pop .dr-pa a,.dr-pop .dr-pa button{font-size:.78rem;font-weight:600;color:#1D4ED8;background:none;border:0;padding:0;cursor:pointer;text-decoration:underline}
  .dr-map{position:absolute;inset:0}
  .dr-mapbar{position:absolute;top:.5rem;right:.5rem;z-index:500;display:flex;gap:.35rem}
  .dr-mapbar button{background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.3rem .65rem;font-size:.8rem;font-weight:600;color:#3E2B1F;cursor:pointer;box-shadow:0 4px 10px -6px rgba(0,0,0,.4)}
  .dr-mapnote{position:absolute;left:.5rem;bottom:.4rem;z-index:500;font-size:.7rem;color:#5C4632;background:rgba(255,251,242,.9);border-radius:.35rem;padding:.05rem .35rem}
  .dr-pin{position:relative}
  .dr-pin span{display:block;width:26px;height:26px;border-radius:999px 999px 999px 2px;transform:rotate(-45deg);background:#B45309;border:2px solid #FFFBF2;box-shadow:0 2px 5px rgba(0,0,0,.45)}
  .dr-pin b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#fff;font:700 11px/1 system-ui}
  .dr-pin.hi span{background:#15803D}
  .dr-tell{font-size:.85rem;color:#5C4632;margin:.7rem 0 0;text-align:center}
  .dr-ask{background:#FFFBF2;border:2px solid #B45309;border-radius:1rem;padding:1.1rem 1.2rem;text-align:center;color:#3E2B1F;box-shadow:0 10px 26px -18px rgba(62,43,31,.6)}
  .dr-ask h3{margin:0 0 .25rem;font:700 1.25rem ui-serif,Georgia,serif}.dr-ask p{margin:0 0 .8rem;color:#5C4632;font-size:.92rem}
  .dr-askb{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:.6rem}.dr-askb .dr-go{padding:.6rem 1.3rem}.dr-askb .dr-tg{padding:.55rem 1rem!important;font-size:.92rem}
  .dr-empty{background:#F7EFDC;border:1px dashed #CBB98D;border-radius:1rem;padding:1rem;color:#3E2B1F;font-size:.92rem}
  @media (max-width: 900px){.dr-top{flex-wrap:wrap}.dr-top .dr-chips{order:3;flex-basis:100%;justify-content:flex-start}.dr-view{margin-left:auto}
    html.dr-mapmode .dr-top .dr-chips{flex-basis:auto;margin-left:0}}
  @media (max-width: 640px){html.dr-mapmode .dr-tl{max-width:none;flex:1}.dr-view button{padding:.35rem .6rem}}
  @media (max-width: 767px){.dr-it{border-radius:.5rem}}   /* edge to edge: the phone standard (#dr-list is tv-bleed) */
</style>

<!-- The finder (Jason, 2026-11-12: "The listing/directory feels lackluster. Need to present a reliable, easy to use tool to find
     the business you want or need"; shown: a business directory's one search box with Refine under it, and a list with "Search
     by name or city" and "Filter by city"): one box for the name, the kind or the need, the place beside it, Search; then Refine,
     each list counting what's in the results. The header's search still searches everything. -->
<section class="dr-find tv-bleed" aria-label="Find a business">
  <div class="dr-ftop"><h1 class="dr-fh">Find a business</h1>
  <div class="dr-view" role="group" aria-label="Show as">
    <button type="button" data-view="list" aria-pressed="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>List</button>
    <button type="button" data-view="map" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><path d="M8 2v16M16 6v16"/></svg>Map</button>
  </div></div>
  <form class="dr-form" id="dr-form" role="search" autocomplete="off">
    <label class="dr-qbox"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.8-4.8"/></svg>
      <input id="dr-q" type="search" placeholder="Business name, kind of business, or what you need" aria-label="Business name, kind of business, or what you need" data-spell enterkeyhint="search">
      <button type="button" class="dr-qx" id="dr-qx" hidden aria-label="Clear the words" title="Clear the words">&times;</button></label>
    <!-- the place: one button that opens the site's place pop-up (Jason, 2026-11-12: "do we need the select location in the page if
         the popup is our selector?"); × beside it clears it -->
    <span class="dr-wgrp dr-wbw"><button type="button" class="dr-wbtn" id="dr-where" title="Choose a place" aria-haspopup="dialog"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg><span id="dr-where-l">Choose a place</span></button><button type="button" class="dr-wtgt tv-pbox-tgt" id="dr-where-tgt" title="Use my location" aria-label="Use my location"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg></button><button type="button" class="dr-wx" id="dr-where-x" hidden title="Clear the place: search everywhere" aria-label="Clear the place">&times;</button></span>
    <button type="submit" class="dr-go">Search</button>
  </form>
  <div class="dr-refine" role="group" aria-label="Refine">
    <span class="dr-rl">Refine</span>
    <label class="dr-rf"><span>Kind</span><select id="dr-kind" aria-label="Kind of business"><option value="">All kinds</option></select></label>
    <label class="dr-rf"><span>Town</span><select id="dr-town" aria-label="Town"><option value="">All towns</option></select></label>
    <label class="dr-rf" id="dr-distw"><span>Within</span><select id="dr-dist" aria-label="How far"><option value="2">2 mi</option><option value="5">5 mi</option><option value="10">10 mi</option><option value="25">25 mi</option><option value="50">50 mi</option></select></label>
    <label class="dr-rf"><span>Sort</span><select id="dr-sort" aria-label="Sort by"><option value="best">Best match</option><option value="distance">Nearest first</option><option value="name">A to Z</option></select></label>
    <span class="dr-tgs"><button type="button" class="dr-tg" data-f="open" aria-pressed="false">Open now</button><button type="button" class="dr-tg" data-f="phone" aria-pressed="false">Has a phone</button><button type="button" class="dr-tg" data-f="website" aria-pressed="false">Has a website</button><button type="button" class="dr-tg" data-f="fav" aria-pressed="false">&#9733; Favorites</button></span>
  </div>
</section>
<div class="dr-head">
  <h2 class="dr-h1" id="dr-title">Businesses near you</h2>
  <p class="dr-sum" id="dr-sum" aria-live="polite"></p>
  <div class="dr-chips" id="dr-chips" aria-label="What's narrowing these results"></div>
</div>
<div class="dr-grid" id="dr-grid">
  <section aria-label="Results" id="dr-listbox"><div id="dr-list" class="tv-bleed"></div><div id="dr-pg"></div><div id="dr-tellbox"></div></section>
  <aside class="dr-mapbox" aria-label="Map" hidden><div class="dr-map" id="dr-map"></div>
    <div class="dr-mapbar"><button type="button" id="dr-mapmore" hidden>Show more</button></div><span class="dr-mapnote" id="dr-mapnote">Pins mark the ZIP area, not the street.</span></aside>
</div>

<script src="/js/tv-pager.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-pager.js') ?>"></script>
<script>
  window.tvSendCrawler = <?= $sendCrawler ? json_encode(['csrf' => (string) $_SESSION['csrf_token']]) : 'null' ?>;
(function () {
  'use strict';
  var U = new URLSearchParams(location.search);
  var S = { q: U.get('q') || '', cat: U.get('cat') || '', catname: U.get('catname') || '', open: U.get('open') === 'now', has: (U.get('has') || '').split(',').filter(Boolean),
            sort: U.get('sort') || 'best', fav: U.get('fav') === '1', radius: +(U.get('radius') || 10), page: 1, total: 0, items: [], town: U.get('in_town') || '' };
  var urlPlace = null;
  ['cluster', 'geo', 'hub'].forEach(function (k) { if (!urlPlace && U.get(k)) urlPlace = { key: k, slug: U.get(k) }; });
  // a town (from a place page's town list): centred on the town, nearest first
  if (!urlPlace && U.get('town')) urlPlace = { town: U.get('town'), state: U.get('state') || '' };
  var localName = U.get('local') || '';   // a local name ("Wide Ruins"): its cluster's listings, said in the summary
  if (urlPlace && urlPlace.town && !U.get('sort')) S.sort = 'distance';
  if (!urlPlace && U.get('lat') && U.get('lon')) urlPlace = { lat: +U.get('lat'), lon: +U.get('lon'), near: U.get('near') || 'the place you searched' };
  var LEVEL = { cluster: 'cluster', geo_hub: 'geo', hub: 'hub' };
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function loc() { return (typeof currentLocation !== 'undefined' && currentLocation) ? currentLocation : null; }
  function short(s) { return String(s || '').split('·')[0].trim(); }

  // ---- where ----
  function place() {
    if (urlPlace && urlPlace.key) return { qs: urlPlace.key + '=' + encodeURIComponent(urlPlace.slug), label: regionName(), region: true };
    if (urlPlace && urlPlace.town) return { qs: 'city=' + encodeURIComponent(urlPlace.town) + '&state=' + encodeURIComponent(urlPlace.state || 'all') + '&radius=' + S.radius, label: urlPlace.town, point: true };
    if (urlPlace) return { qs: 'lat=' + urlPlace.lat + '&lon=' + urlPlace.lon + '&radius=' + S.radius, label: urlPlace.near === 'your precise location' ? 'you' : urlPlace.near, point: true };
    var l = loc(); if (!l) return null;
    if (l.scope && l.scope.slug && LEVEL[l.scope.level]) return { qs: LEVEL[l.scope.level] + '=' + encodeURIComponent(l.scope.slug), label: l.scope.label || l.scope.slug, region: true };
    if (l.lat != null && l.lon != null) return { qs: 'lat=' + l.lat + '&lon=' + l.lon + '&radius=' + S.radius, label: l.townName || l.savedLabel || 'your location', point: true };
    if (l.zip) return { qs: 'zip=' + encodeURIComponent(l.zip) + '&radius=' + S.radius, label: 'ZIP ' + l.zip, point: true };
    if (l.city) return { qs: 'city=' + encodeURIComponent(l.city) + '&state=' + encodeURIComponent(l.state || 'all') + '&radius=' + S.radius, label: l.city + (l.state && l.state !== 'all' ? ', ' + l.state : ''), point: true };
    if (l.state && l.state !== 'all') return { qs: 'state=' + encodeURIComponent(l.state), label: l.state };
    return null;
  }
  function regionName() {
    var l = loc();
    if (l && l.scope && l.scope.slug === urlPlace.slug && l.scope.label && l.scope.label !== l.scope.slug) return l.scope.label;
    return urlPlace.slug.replace(/^cluster-\w+-/, '').replace(/-/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }
  // Near me: the device's own location, nearest first (the place itself is set in the header, like everywhere else)
  function nearMe(b) {
      if (!navigator.geolocation) { TvAsk.say('This browser can\'t share a location. Choose a place instead.', { anchor: b }); return; }
      b.textContent = 'Finding you…';
      navigator.geolocation.getCurrentPosition(function (pos) {
        urlPlace = { lat: +pos.coords.latitude.toFixed(4), lon: +pos.coords.longitude.toFixed(4), near: 'you' };   // never shown as a place: "near you"
        S.sort = 'distance'; search(true);
      }, function () { b.textContent = '◎ Near me'; TvAsk.say('Location access was blocked or unavailable. You can choose a place instead.', { anchor: b }); }, { timeout: 10000, maximumAge: 60000 });
  }
  window.onLocationChanged = function () { urlPlace = null; localName = ''; search(true); };   // a place chosen in the menu
  // The header's search: on this page, Enter (or the words in the address) shows them here
  window.tvSearchSync = function (q) { if (q !== S.q) window.tvSearchHere(q); };   // the dropdown closed: the list follows the field
  window.tvSearchHere = function (q) { qPend = false; clearTimeout(qT); S.q = q; S.cat = ''; S.catname = ''; S.town = ''; search(true); return true; };

  // ---- filters ----
  function nearOn() { return !!(urlPlace && !urlPlace.key && (urlPlace.near === 'you' || urlPlace.near === 'your precise location')); }
  // Under the title: only what's narrowing the results, each removable (×). Turning filters on is the search's job
  // (its Quick picks: Near me, Open now, Has a phone, Has a website, Favorites).
  function paintChips() {
    var x = function (f, label) { return '<button type="button" class="dr-c sm on x" data-f="' + f + '" title="Remove">' + label + '</button>'; };
    var h = '';
    if (S.cat) h += x('uncat', esc(S.catname || S.cat.replace(/-/g, ' ')));
    if (S.town) h += x('untown', esc(S.town.toLowerCase().replace(/\b\w/g, function (c) { return c.toUpperCase(); })));
    if (S.q) h += x('unq', '“' + esc(S.q) + '”');
    if (nearOn()) h += x('near', 'Near me');   // Open now, phone, website and Favorites show lit in the finder's Refine instead
    $('dr-chips').innerHTML = h;
    paintFinder();
    var p = place(), w = $('dr-where-l'), lb = nearOn() ? 'Near you' : p ? short(p.label) : '';
    if (w) w.textContent = lb || 'Choose a place';   // the place button shows the place
    var wx = $('dr-where-x'); if (wx) wx.hidden = !p && !nearOn();   // a place set: × clears it (Jason, 2026-11-10)
  }
  // ★ Favorites: the businesses you linked or saved to your Address Book
  var favIds = null;
  function loadFavs() {
    if (favIds) return Promise.resolve(favIds);
    var j = function (u) { return fetch(u, { credentials: 'include' }).then(function (r) { return r.ok ? r.json() : {}; }).catch(function () { return {}; }); };
    return Promise.all([j('/user/api/links.php?list=1'), j('/user/api/people.php?view=contacts')]).then(function (a) {
      var ids = {};
      ((a[0].links || {}).business || []).forEach(function (l) { ids[+l.target_id] = 1; });
      (a[1].contacts || []).forEach(function (c) { if (c.kind === 'business' && c.ref) ids[+c.ref] = 1; });
      favIds = Object.keys(ids).filter(function (k) { return +k > 0; });
      favIds.signedIn = !!(a[0].ok || a[1].ok);
      return favIds;
    });
  }
  function toggle(f, b) {
    if (f === 'uncat') { S.cat = ''; S.catname = ''; }
    else if (f === 'untown') S.town = '';
    else if (f === 'unq') { qPend = false; clearTimeout(qT); $('dr-q').value = ''; S.q = ''; var hi0 = document.querySelector('.tvs-in'); if (hi0) hi0.value = ''; }
    else if (f === 'near') { if (nearOn()) { urlPlace = null; S.sort = 'best'; } else { nearMe(b || {}); return; } }
    else if (f === 'open') S.open = !S.open;
    else if (f === 'fav') { S.fav = !S.fav; if (S.fav) { loadFavs().then(function () { search(true); }); return; } }
    else { var i = S.has.indexOf(f); if (i >= 0) S.has.splice(i, 1); else S.has.push(f); }
    search(true);
  }
  $('dr-chips').addEventListener('click', function (e) { var b = e.target.closest('button[data-f]'); if (b) toggle(b.getAttribute('data-f'), b); });
  $('dr-chips').addEventListener('change', function (e) { var f = e.target.getAttribute('data-f'); if (f === 'radius') S.radius = +e.target.value; if (f === 'sort') S.sort = e.target.value; search(true); });
  // ---- the finder (2026-11-12): the words, the place, Search; Refine's lists count what's in the results ----
  var facets = null;
  function opts(sel, first, list, cur, curName) {
    var h = '<option value="">' + first + '</option>', have = false;
    (list || []).forEach(function (o) { if (o[0] === cur) have = true; h += '<option value="' + esc(o[0]) + '"' + (o[0] === cur ? ' selected' : '') + '>' + esc(o[1]) + (o[2] != null ? ' (' + Number(o[2]).toLocaleString() + ')' : '') + '</option>'; });
    if (cur && !have) h += '<option value="' + esc(cur) + '" selected>' + esc(curName || cur) + '</option>';
    sel.innerHTML = h;
  }
  function paintFinder() {
    var qi = $('dr-q'); if (!qi) return;
    if (document.activeElement !== qi && !qPend) qi.value = S.q; $('dr-qx').hidden = !qi.value;
    opts($('dr-kind'), 'All kinds', facets && facets.kinds ? facets.kinds.map(function (k) { return [k.slug, k.name, k.n]; }) : [], S.cat, S.catname || S.cat.replace(/-/g, ' '));
    opts($('dr-town'), 'All towns', facets && facets.towns ? facets.towns.map(function (t) { return [t.value, t.name, t.n]; }) : [], S.town, S.town);
    var p = place(), pt = !!(p && p.point);
    $('dr-distw').hidden = !pt; if (pt) { var ds = $('dr-dist'); if (![].some.call(ds.options, function (o) { return +o.value === S.radius; })) ds.insertAdjacentHTML('beforeend', '<option value="' + S.radius + '">' + S.radius + ' mi</option>'); ds.value = String(S.radius); }
    var so = $('dr-sort'); so.querySelector('[value=distance]').disabled = !pt; so.querySelector('[value=distance]').title = pt ? '' : 'Set a town, a ZIP or your location to sort by distance';
    so.value = S.sort === 'distance' && !pt ? 'best' : (pt && S.sort === 'best' && !U.get('sort') ? 'distance' : (S.sort || 'best'));   // what the list really uses
    document.querySelectorAll('.dr-tg').forEach(function (b) { var f = b.getAttribute('data-f'); b.setAttribute('aria-pressed', String(f === 'open' ? S.open : f === 'fav' ? S.fav : S.has.indexOf(f) >= 0)); });
  }
  // The words follow what's typed (Jason, 2026-11-13; decisions/0058 note): from 3 letters the list updates on its own once
  // typing pauses, Search or Enter at once, and emptying the box shows everything again. Words typed and not yet searched
  // are never wiped by a redraw (a place chosen, Refine): the next search takes them.
  var qPend = false, qT = 0;
  function takeWords() {
    var v = $('dr-q').value.trim(); qPend = false; clearTimeout(qT);
    if (v !== S.q) { S.q = v; S.cat = ''; S.catname = ''; S.town = ''; }   // new words: Refine starts again from what they find
    var hin = document.querySelector('.tvs-in'); if (hin) hin.value = S.q;
  }
  $('dr-form').addEventListener('submit', function (e) { e.preventDefault(); takeWords(); search(true); });
  $('dr-q').addEventListener('input', function () {
    $('dr-qx').hidden = !this.value;
    var v = this.value.trim(); clearTimeout(qT); qPend = v !== S.q;
    if (qPend && (v.length >= 3 || v === '')) qT = setTimeout(function () { takeWords(); search(true); }, 350);
  });
  $('dr-qx').addEventListener('click', function () { qPend = false; clearTimeout(qT); $('dr-q').value = ''; this.hidden = true; if (S.q) { S.q = ''; search(true); } $('dr-q').focus(); });
  $('dr-kind').addEventListener('change', function () { var o = this.options[this.selectedIndex]; S.cat = this.value; S.catname = this.value ? o.textContent.replace(/ \([\d,]+\)$/, '') : ''; S.town = ''; search(true); });
  $('dr-town').addEventListener('change', function () { S.town = this.value; search(true); });
  $('dr-dist').addEventListener('change', function () { S.radius = +this.value; search(true); });
  $('dr-sort').addEventListener('change', function () { S.sort = this.value; search(true); });
  document.querySelector('.dr-tgs').addEventListener('click', function (e) { var b = e.target.closest('[data-f]'); if (b) toggle(b.getAttribute('data-f'), b); });

  // the search's Quick picks, on this page
  window.tvQuick = {
    state: function () { return { near: nearOn(), open: S.open, phone: S.has.indexOf('phone') >= 0, website: S.has.indexOf('website') >= 0 }; },
    toggle: function (k) { toggle(k); }
  };
  (function () { var hin = document.querySelector('.tvs-in'); if (hin && S.q) hin.value = S.q; })();

  // ---- List or Map (remembered) ----
  var view = 'list';
  try { view = localStorage.getItem('tv_dir_view') === 'map' ? 'map' : 'list'; } catch (x) {}
  // Map: the full-screen map (js/map-view.js), with every result as a pin, not just this page of the list. The header
  // search says what to look for while it's open; its panel has Open now, Phone, Website and ★ Favorites; Exit returns
  // to the list, which follows anything changed on the map.
  function openMap() {
    if (!window.TvMap) { setTimeout(openMap, 200); return; }
    try { localStorage.setItem('tv_dir_view', 'map'); } catch (x) {}
    var p = place(), changed = false;
    var T = [['open', 'Open now'], ['phone', 'Phone'], ['website', 'Website'], ['fav', '\u2605 Favorites']];
    var on = function (k) { return k === 'open' ? S.open : k === 'fav' ? S.fav : S.has.indexOf(k) >= 0; };
    var tools = function () { return T.map(function (t) { return '<button type="button" class="tvm-b' + (on(t[0]) ? ' go' : '') + '" data-act="' + t[0] + '" aria-pressed="' + on(t[0]) + '">' + t[1] + '</button>'; }).join(''); };
    TvMap.open({ panel: true,
      title: $('dr-title').textContent, radius: p && p.point ? S.radius : null, tools: tools(),
      titleFor: function (j) { var n = j.total != null ? j.total : (j.pins || []).length; return n.toLocaleString() + (n === 1 ? ' business' : ' businesses') + ' · ' + $('dr-title').textContent; },
      load: function (area, words) {
        if (words && words !== S.q) { qPend = false; clearTimeout(qT); S.q = words; S.cat = ''; S.catname = ''; changed = true; $('dr-title').textContent = '“' + words + '”' + (p ? (p.point ? ' near ' : ' in ') + short(p.label) : ''); }
        var go = function () {
          var u = new URLSearchParams(qs(1, true));
          // another area on the map: the list's Town choice no longer applies there (it hid every pin, 2026-11-12)
          if (area) { ['cluster', 'geo', 'hub', 'state', 'city', 'zip', 'town', 'in_town', 'near', 'lat', 'lon', 'radius'].forEach(function (k) { u.delete(k); }); u.set('lat', area.lat); u.set('lon', area.lon); u.set('radius', area.radius); }
          return fetch('/api/search_listings.php?' + u.toString() + '&view=map', { credentials: 'include' }).then(function (r) {
            return r.json().then(function (j) { if (!(r.ok && j.success)) throw new Error(j.error || ('HTTP ' + r.status)); return j; });
          });
        };
        return S.fav ? loadFavs().then(go) : go();
      },
      onTool: function (k) {   // the same filters as the list, kept in step with it
        if (k === 'open') S.open = !S.open; else if (k === 'fav') S.fav = !S.fav;
        else { var i = S.has.indexOf(k); if (i >= 0) S.has.splice(i, 1); else S.has.push(k); }
        changed = true;
        document.querySelectorAll('.tvm-side [data-act]').forEach(function (b) { var v = on(b.getAttribute('data-act')); b.classList.toggle('go', v); b.setAttribute('aria-pressed', String(v)); });
        TvMap.reload();
      },
      onCategory: function (slug, name) { qPend = false; clearTimeout(qT); S.cat = slug; S.catname = name; S.q = ''; changed = true; TvMap.reload(); },
      onList: function () { setView('list'); if (changed) search(true); }
    });
  }
  function setView(v) {
    if (v === 'map') { openMap(); return; }
    view = v;
    try { localStorage.setItem('tv_dir_view', v); } catch (x) {}
    document.querySelectorAll('.dr-view [data-view]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-view') === v)); });
    $('dr-grid').classList.toggle('map', v === 'map');
    document.querySelector('.dr-mapbox').hidden = v !== 'map';
    if (v === 'map') window.scrollTo(0, 0);
    document.documentElement.classList.toggle('dr-mapmode', v === 'map');
    fitWork();
    if (v === 'map') pins(S.items);
  }
  // where the workspace starts (under the header, beside the toolbar; under the toolbar row on phones)
  function fitWork() {
    var w = document.getElementById('ta-work'), rail = document.getElementById('ta-rail'); if (!w) return;
    var r = w.getBoundingClientRect(), top = r.top;
    if (rail && window.matchMedia('(max-width: 767px)').matches) top = Math.max(top, rail.getBoundingClientRect().bottom);
    document.documentElement.style.setProperty('--dr-t', Math.max(0, Math.round(top)) + 'px');
    document.documentElement.style.setProperty('--dr-l', Math.round(r.left) + 'px');
    if (map) setTimeout(function () { map.invalidateSize(); }, 60);
  }
  window.addEventListener('resize', function () { if (view === 'map') fitWork(); });
  var tog = document.getElementById('ta-tog'); if (tog) tog.addEventListener('click', function () { setTimeout(fitWork, 30); });   // labels on or off: the toolbar's width
  document.querySelector('.dr-view').addEventListener('click', function (e) { var b = e.target.closest('[data-view]'); if (b) setView(b.getAttribute('data-view')); });

  // ---- search ----
  function qs(page, forMap) {
    var p = place(), now = new Date(), a = [];
    if (S.q) a.push('q=' + encodeURIComponent(S.q));
    if (S.cat) a.push('category=' + encodeURIComponent(S.cat));
    if (p) a.push(p.qs);
    if (S.open) a.push('open=now');
    a.push('at=' + now.getDay() + ',' + (now.getHours() * 60 + now.getMinutes()));
    if (S.has.length) a.push('has=' + S.has.join(','));
    if (S.town) a.push('in_town=' + encodeURIComponent(S.town));
    if (!forMap && page === (S.first || 1)) a.push('facets=1');   // the finder's Kind and Town lists, with their counts
    if (S.fav && favIds) a.push('ids=' + favIds.join(','));
    // a point (a town, near me, a ZIP): nearest first unless asked otherwise
    a.push('sort=' + (p && p.point && S.sort === 'best' && !U.get('sort') ? 'distance' : (S.sort === 'distance' && !(p && p.point) ? 'best' : S.sort)));
    if (!forMap) a.push('page=' + page, 'per_page=' + pg.per);
    return a.join('&');
  }
  function syncUrl() {
    var u = new URLSearchParams();
    if (S.q) u.set('q', S.q);
    if (S.cat) { u.set('cat', S.cat); if (S.catname) u.set('catname', S.catname); }
    if (urlPlace && urlPlace.key) { u.set(urlPlace.key, urlPlace.slug); if (localName) u.set('local', localName); }
    else if (urlPlace && urlPlace.town) { u.set('town', urlPlace.town); if (urlPlace.state) u.set('state', urlPlace.state); u.set('radius', S.radius); }
    else if (urlPlace && !urlPlace.town) { u.set('lat', urlPlace.lat); u.set('lon', urlPlace.lon); u.set('radius', S.radius); u.set('near', urlPlace.near); }
    if (S.open) u.set('open', 'now');
    if (S.has.length) u.set('has', S.has.join(','));
    if (S.town) u.set('in_town', S.town);
    if (S.fav) u.set('fav', '1');
    if (S.sort !== 'best') u.set('sort', S.sort);
    history.replaceState(null, '', '/directory/' + (u.toString() ? '?' + u.toString() : ''));
  }
  // closing the search dropdown steps back one history entry; keep the address matching what's shown
  window.addEventListener('popstate', function () { setTimeout(syncUrl, 0); });
  var seq = 0;
  function search(reset) {
    if (reset) { S.page = 1; S.first = 1; S.items = []; }
    if (qPend) { var tw = $('dr-q').value.trim(); if (tw.length >= 3 || tw === '') { S.q = tw; qPend = false; clearTimeout(qT); var hw = document.querySelector('.tvs-in'); if (hw) hw.value = S.q; } }   // typed, not yet searched: these words
    paintChips(); syncUrl();
    var p = place(), my = ++seq;
    var what = S.cat ? (S.catname || S.cat.replace(/-/g, ' ')) : S.q ? '“' + S.q + '”' : 'Businesses';
    $('dr-title').textContent = what + (p ? (S.cat || S.q ? (p.point ? ' near ' : ' in ') : ' near ') + short(p.label) : (S.cat || S.q ? '' : ' near you'));
    if (!p && !S.q && !S.cat) {
      $('dr-sum').textContent = '';
      // no place and nothing asked: an action, not a sentence (Jason, 2026-11-12: "something to lead action to setting location");
      // nothing left over from the search before (its pages, its "near …")
      // the pop-up asks; under it only a line that brings it back (Jason, 2026-11-12: "we dont need the underneath set location info box")
      $('dr-list').innerHTML = '<p class="dr-sum">No place set yet. <button type="button" class="dr-lk" data-ask="pop">Choose a place</button> and the businesses there appear here, nearest first.</p>';
      $('dr-sum').textContent = ''; pg.draw({ total: 0 }); $('dr-tellbox').innerHTML = '';
      askPop();   // and asked in a pop-up, as the map does (Jason, 2026-11-12: "maybe the directory should have the same popup")
      pins([]); return;
    }
    if (reset) $('dr-list').innerHTML = '<p class="dr-sum">Loading…</p>';
    fetch('/api/search_listings.php?' + qs(S.page), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (my !== seq) return;
      if (!d.success) throw new Error(d.error || 'Search is unavailable right now.');
      S.total = d.total || 0;
      S.items = S.items.concat(d.listings || []);
      if (d.facets) facets = d.facets;
      if (S.page === (S.first || 1)) { S.offers = d.offers || []; S.meant = d.meant || []; S.read = d.read || []; }   // the main search's reading: kinds meant, spelling offers
      pg.busy(false); paintList(); paintChips();   // sort shows once there's more than one
      if (view === 'map') pins(S.items);
    }).catch(function (e) { $('dr-list').innerHTML = '<div class="dr-empty">' + esc(e.message) + '</div>'; });
  }
  var I = {
    call: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>',
    dir: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>',
    web: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/></svg>',
    peek: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>'
  };
  // the lists' standard (Jason, 2026-11-12; js/tv-pager.js): 10 a page or the visitor's choice, Show more, and the pages
  var pg = TvPager.mount($('dr-pg'), { key: 'directory', top: $('dr-listbox'),
    onMore: function () { pg.busy(true); S.page++; search(false); },
    onPage: function (x) { S.first = S.page = x + 1; S.items = []; $('dr-list').innerHTML = '<p class="dr-sum">Loading…</p>'; search(false); },
    onPer: function () { search(true); } });
  function paintList() {
    var p = place();
    pg.draw({ total: S.items.length ? S.total : 0, page: (S.first || 1) - 1, shown: S.items.length });
    $('dr-tellbox').innerHTML = '';
    $('dr-sum').textContent = S.total ? S.total.toLocaleString() + (S.total === 1 ? ' business' : ' businesses') + (S.open ? ' open now' : '') + (p ? (p.point ? ' near ' : ' in ') + short(p.label) : '')
      + (S.items.length < S.total ? ' · showing ' + ((S.first - 1) * pg.per + 1).toLocaleString() + '–' + ((S.first - 1) * pg.per + S.items.length).toLocaleString() : '')
      + (localName && urlPlace && urlPlace.key ? ' · ' + localName + ' is part of this area' : '')
      + (S.q && S.meant && S.meant.length ? ' · includes ' + S.meant.slice(0, 3).join(', ') : '') : '';
    // spelling: offered, never changed (decisions/0064, as the site's search)
    var offerHtml = S.q && S.offers && S.offers.length ? '<p class="dr-sum dr-dym">Did you mean ' + S.offers.map(function (o) { return '<button type="button" class="dr-tg" data-dym="' + esc(o) + '">' + esc(o) + '</button>'; }).join(' ') + '?</p>' : '';
    if (!S.items.length && S.fav) {
      $('dr-list').innerHTML = '<div class="dr-empty">' + (favIds && !favIds.signedIn ? '<a class="dr-lk" href="/login.php">Sign in</a> to see your favorites: the businesses you link or save to your Address Book.'
        : 'None of your favorites match here yet. Tap the link or ☆ Save on a business to add it.') + ' <button type="button" class="dr-lk" data-f-off>Show everything</button></div>';
      return;
    }
    if (!S.items.length) {
      $('dr-list').innerHTML = offerHtml + '<div class="dr-empty">Nothing found' + (p ? (p.point ? ' near ' : ' in ') + esc(short(p.label)) : '') + '. '
        + (S.open || S.has.length ? '<button type="button" class="dr-lk" data-clear>Clear the filters</button> · ' : '')
        + (p ? '<button type="button" class="dr-lk" data-everywhere>Search everywhere</button>' : 'Try other words or a category.')
        + '<br>Know a business that should be here? ' + tellBtn('Tell us') + sendBtn() + '</div>' + readHtml();
      return;
    }
    $('dr-list').innerHTML = offerHtml + S.items.map(function (l, i) {
      var tel = l.phone ? String(l.phone).replace(/[^\d+]/g, '') : '';
      var dir = l.address ? 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(l.address + ', ' + [l.city, l.state].filter(Boolean).join(', ')) : '';
      var web = l.website ? (/^https?:/i.test(l.website) ? l.website : 'https://' + l.website) : '';
      var ht = l.hours_text || '', cut = ht.indexOf(' · ');
      // data-out: the action is counted for the business (decisions/0058 §9): which listing, which action, which day; never who
      return '<article class="dr-it" data-i="' + i + '" id="dr-it-' + l.id + '" data-link-host><span data-link="business:' + l.id + '" data-link-label="' + esc(l.business_name) + '"></span><div class="dr-main">'
        + '<div class="dr-hd"><a class="dr-n" href="/listing/view.php?id=' + l.id + '">' + (((S.first || 1) - 1) * pg.per + i + 1) + '. ' + esc(l.business_name) + '</a>' + (l.is_verified ? '<span class="dr-badge">Verified</span>' : '') + (l.closed ? '<span class="dr-badge dr-shut">Closed</span>' : '') + '</div>'
        + '<div class="dr-acts">'
        + (tel ? '<a class="dr-a" title="Call" href="tel:' + esc(tel) + '" data-out="call" data-e="' + l.id + '"><span>' + I.call + '</span><b class="dr-al">Call</b></a>' : '')
        + (dir ? '<a class="dr-a" title="Directions" href="' + esc(dir) + '" target="_blank" rel="noopener" data-out="directions" data-e="' + l.id + '"><span>' + I.dir + '</span><b class="dr-al">Directions</b></a>' : '')
        + (web ? '<a class="dr-a" title="Website" href="' + esc(web) + '" target="_blank" rel="noopener nofollow" data-out="website" data-e="' + l.id + '"><span>' + I.web + '</span><b class="dr-al">Website</b></a>' : '')
        + '<button type="button" class="dr-a" title="Peek" data-tv-peek="' + l.id + '"><span>' + I.peek + '</span><b class="dr-al">Peek</b></button>'
        + '</div>'
        + '<div class="dr-m">' + esc([l.category, l.distance != null && p && p.point ? l.distance + ' mi' : ''].filter(Boolean).join(' · ')) + '</div>'
        + '<div class="dr-m">' + (l.address ? esc(l.address) + (l.city && String(l.address).indexOf(l.city) < 0 ? ', ' + esc(l.city) : '')
            : (l.private_location ? 'Location kept private for the safety of the people it shelters. Call to get help.' : esc([l.city, l.state].filter(Boolean).join(', '))))
          + (l.phone ? ' · ' + esc(l.phone) : '') + '</div>'
        + (ht ? '<div class="dr-m"><span class="' + (l.open_now ? 'dr-open' : 'dr-closed') + '">' + esc(cut > 0 ? ht.slice(0, cut) : ht) + '</span>' + (cut > 0 ? ' · ' + esc(ht.slice(cut + 3)) : '') + '</div>' : '')
        + '</div></article>';
    }).join('');
    $('dr-tellbox').innerHTML = readHtml() + '<p class="dr-tell">Missing a business' + (p ? (p.point ? ' near ' : ' in ') + esc(short(p.label)) : '') + '? ' + tellBtn('Tell us') + sendBtn() + '</p>';
  }
  // places named on pages we read that we don't list yet (decisions/0157 §3): after ours, when ours are few. The name opens
  // the page it's named on; Call and Directions as on any card. Each is checked against another source before it's listed.
  function readHtml() {
    var R = S.read || [];
    if (!R.length) return '';
    return '<h3 class="dr-rdh">Named on pages we read <small>not listed yet</small></h3>' + R.map(function (l) {
      var tel = l.tel ? String(l.tel).replace(/[^\d+]/g, '') : '';
      var dir = l.address ? 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(l.address + (l.town && String(l.address).indexOf(l.town.split(',')[0]) < 0 ? ', ' + l.town : '')) : '';
      var web = l.website ? (/^https?:/i.test(l.website) ? l.website : 'https://' + l.website) : '';
      return '<article class="dr-it dr-rd"><div class="dr-main"><div class="dr-hd"><a class="dr-n" href="' + esc(l.source) + '" target="_blank" rel="noopener nofollow" title="The page it\u2019s named on: ' + esc(l.source_host) + '">' + esc(l.label) + '</a></div>'
        + '<div class="dr-acts">'
        + (tel ? '<a class="dr-a" title="Call" href="tel:' + esc(tel) + '"><span>' + I.call + '</span><b class="dr-al">Call</b></a>' : '')
        + (dir ? '<a class="dr-a" title="Directions" href="' + esc(dir) + '" target="_blank" rel="noopener"><span>' + I.dir + '</span><b class="dr-al">Directions</b></a>' : '')
        + (web ? '<a class="dr-a" title="Website" href="' + esc(web) + '" target="_blank" rel="noopener nofollow"><span>' + I.web + '</span><b class="dr-al">Website</b></a>' : '')
        + '</div>'
        + '<div class="dr-m">' + esc([l.kind, l.miles != null ? l.miles + ' mi' : ''].filter(Boolean).join(' · ')) + '</div>'
        + '<div class="dr-m">' + esc(l.address || l.town) + (l.phone ? ' · ' + esc(l.phone) : '') + '</div>'
        + '<div class="dr-m dr-src">' + esc(l.from) + '</div>'
        + '</div></article>';
    }).join('') + '<p class="dr-sum">Not Traversence listings yet: each is checked against another source before it\u2019s listed.</p>';
  }
  // Jason only (decisions/0157 §3): the crawler reads the town's sources again, asks OpenStreetMap again, and lists the
  // sources waiting for his call there. Free: no web search.
  function sendBtn() {
    return window.tvSendCrawler ? ' · <button type="button" class="dr-lk" data-send-crawler>Send the crawler</button>' : '';
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-send-crawler]'); if (!b || !window.tvSendCrawler) return;
    var p = place();
    if (!p || p.region) { TvAsk.say('Choose a town (or use your location) first: the crawler works a town at a time.', { anchor: b, bad: true }); return; }
    TvAsk.busy(b, true);
    var body = { qs: p.qs, q: S.q || S.catname || '' };
    fetch('/api/send-crawler.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': window.tvSendCrawler.csrf },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok || !d.ok) throw new Error((d.error && d.error.message) || d.error || 'The crawler couldn\u2019t be sent.'); return d; }); })
      .then(function (d) { TvAsk.busy(b, false); TvAsk.say(d.message, { anchor: b }); })
      .catch(function (x) { TvAsk.busy(b, false); TvAsk.say(x.message, { anchor: b, bad: true }); });
  });
  // "Tell us" (js/suggest.js): a missing business, with what they searched for
  function tellBtn(label) {
    var p = place();
    return '<button type="button" class="dr-lk" data-tv-suggest="' + esc(JSON.stringify({ kind: 'missing', topic: 'business', q: S.q || '', place_name: p ? short(p.label) : '' })) + '">' + esc(label) + '</button>';
  }
  // the place: its name opens the pop-up, the target finds where you are at once (Jason, 2026-11-12: "the location should just
  // have the autodetect or activate when clicked on")
  $('dr-where').addEventListener('click', function () { askPop(); });
  $('dr-where-tgt').addEventListener('click', function (e) { if (typeof autoDetectLocation === 'function') autoDetectLocation(e); });
  $('dr-where-x').addEventListener('click', function () { urlPlace = null; localName = ''; if (typeof chooseAnywhere === 'function') chooseAnywhere(); else search(true); });   // clear the place: everywhere, like the search's ×
  // a click anywhere on a card that isn't one of its links or buttons opens its pop-up card, as Peek does (Jason, 2026-11-12:
  // "can clicking the box of the listing fire the popup card?"); selecting text doesn't
  // the pop-up: the page greyed behind it; gone when a place is chosen or it's closed
  // every time the list opens with no place (Jason, 2026-11-12: "once popup is closed it doesnt seem to be coming back"), not
  // once a visit; closed, the line under the title brings it back
  // the site's one place pop-up (js/location-scope.js tvPlacePop, Jason's "we need a location to search"); Not sure?: search everywhere
  // Not sure? goes to browsing by region (the pop-up's own default), never a notice (2026-11-12: it showed as an "Error")
  function askPop() { if (typeof window.tvPlacePop === 'function') window.tvPlacePop(); }
  function doAsk(k) {
    var box = $('dr-where');
    if (k === 'me' || k === 'type') askPop();
    else $('dr-q').focus();
  }
  $('dr-list').addEventListener('click', function (e) {
    var dy = e.target.closest('[data-dym]');
    if (dy) { qPend = false; clearTimeout(qT); S.q = dy.getAttribute('data-dym'); S.cat = ''; S.catname = ''; S.town = ''; var hi = document.querySelector('.tvs-in'); if (hi) hi.value = S.q; search(true); return; }
    var a = e.target.closest('[data-ask]'); if (!a) return;
    if (a.getAttribute('data-ask') === 'pop') askPop(); else doAsk(a.getAttribute('data-ask'));
  });
  $('dr-list').addEventListener('click', function (e) {
    var card = e.target.closest('.dr-it'); if (!card || e.target.closest('a,button,input,select,label,[data-link]')) return;
    var sel = window.getSelection && String(window.getSelection()); if (sel && sel.trim()) return;
    var pk = card.querySelector('[data-tv-peek]'); if (pk) pk.click();
  });
  $('dr-list').addEventListener('click', function (e) {
    if (e.target.closest('[data-clear]')) { S.open = false; S.has = []; search(true); return; }
    if (e.target.closest('[data-f-off]')) { S.fav = false; search(true); return; }
    if (e.target.closest('[data-everywhere]')) { urlPlace = null; if (typeof chooseAnywhere === 'function') chooseAnywhere(); else search(true); }
  });
  $('dr-list').addEventListener('mouseover', function (e) { var a = e.target.closest('.dr-it[data-i]'); if (a) hi(+a.getAttribute('data-i'), false); });

  // ---- the map beside the results ----
  var map = null, layer = null, marks = [], loading = null;
  function leaflet() {
    if (window.L) return Promise.resolve();
    if (loading) return loading;
    var cdn = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/';
    loading = new Promise(function (res, rej) {
      var c = document.createElement('link'); c.rel = 'stylesheet'; c.href = cdn + 'leaflet.min.css'; document.head.appendChild(c);
      var s = document.createElement('script'); s.src = cdn + 'leaflet.min.js'; s.onload = res; s.onerror = function () { rej(new Error('The map could not load.')); }; document.head.appendChild(s);
    });
    return loading;
  }
  function pins(list) {
    leaflet().then(function () {
      if (!map) {
        map = L.map('dr-map', { zoomControl: false }).setView([34.2, -110.0], 8);
        L.control.zoom({ position: 'bottomright' }).addTo(map);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>' }).addTo(map);
        layer = L.layerGroup().addTo(map);
      }
      layer.clearLayers(); marks = [];
      var pts = [], at = {};
      list.forEach(function (l, i) {
        if (l.lat == null || l.lon == null) { marks[i] = null; return; }
        // listings without their own point share their ZIP's middle: spread them in a small spiral so each shows
        var k = (+l.lat).toFixed(4) + ',' + (+l.lon).toFixed(4), n = at[k] = (at[k] || 0) + 1, la = +l.lat, lo = +l.lon;
        if (n > 1) { var r = 0.0011 * Math.sqrt(n - 1), g = (n - 1) * 2.39996; la += r * Math.sin(g); lo += r * Math.cos(g) / Math.cos(la * Math.PI / 180); }
        var m = L.marker([la, lo], { title: l.business_name, icon: L.divIcon({ className: 'dr-pin' + (l.approx ? ' ap' : ''), html: '<span></span><b>' + (i + 1) + '</b>', iconSize: [26, 26], iconAnchor: [13, 26] }) });
        var tel = l.phone ? String(l.phone).replace(/[^\d+]/g, '') : '';
        m.bindPopup('<div class="dr-pop"><b>' + (i + 1) + '. ' + esc(l.business_name) + '</b><p>' + esc([l.category, l.hours_text ? String(l.hours_text).split(' · ')[0] : ''].filter(Boolean).join(' · ')) + '</p>'
          + '<p>' + esc(l.address || (l.private_location ? 'Location kept private. Call to get help.' : [l.city, l.state].filter(Boolean).join(', '))) + '</p>'
          + (l.approx ? '<p><i>Approximate: the middle of its ZIP area.</i> <button type="button" data-tv-suggest="' + esc(JSON.stringify({ kind: 'fix', entity_id: l.id, entity_name: l.business_name })) + '">Know where it is?</button></p>' : '')
          + '<div class="dr-pa">'
          + (tel ? '<a href="tel:' + esc(tel) + '">Call</a>' : '') + '<button type="button" data-tv-peek="' + l.id + '">Peek</button><a href="/listing/view.php?id=' + l.id + '">Open</a></div></div>');
        m.on('click', function () { hi(i, false); });
        m.addTo(layer); marks[i] = m; pts.push([la, lo]);
      });
      var stacked = Object.keys(at).some(function (k) { return at[k] > 1; });
      var nApprox = list.filter(function (l) { return l.approx; }).length;   // the note only when some pins are the ZIP's middle
      $('dr-mapnote').hidden = !nApprox; $('dr-mapnote').textContent = nApprox === list.length ? 'Pins mark the ZIP area, not the street.' : nApprox + ' pins mark the ZIP area, not the street.';   // shared ZIP points: zoom in so the spread pins separate
      if (pts.length) map.fitBounds(pts, { paddingTopLeft: [60, 120], paddingBottomRight: [60, 60], maxZoom: stacked ? 17 : 13 });
      var mm = $('dr-mapmore'); mm.hidden = !((S.first - 1) * pg.per + S.items.length < S.total); mm.textContent = 'Show ' + Math.min(pg.per, S.total - (S.first - 1) * pg.per - S.items.length) + ' more';
      setTimeout(function () { map.invalidateSize(); }, 60);
    }).catch(function (e) { $('dr-mapnote').textContent = e.message; });
  }
  var hiNow = -1;
  function hi(i, scroll) {
    if (hiNow === i) return;
    document.querySelectorAll('.dr-it.hi').forEach(function (x) { x.classList.remove('hi'); });
    if (marks[hiNow] && marks[hiNow]._icon) marks[hiNow]._icon.classList.remove('hi');
    hiNow = i;
    var card = document.querySelector('.dr-it[data-i="' + i + '"]'); if (card) { card.classList.add('hi'); if (scroll) card.scrollIntoView({ block: 'center' }); }
    if (marks[i] && marks[i]._icon) marks[i]._icon.classList.add('hi');
  }
  $('dr-mapmore').addEventListener('click', function () { S.page++; search(false); });

  // start once the page's place is known (location-scope.js restores it on load)
  window.addEventListener('load', function () { setTimeout(function () {
    setView('list'); if (view === 'map') openMap();   // the map was last used here: open it again
    if (U.get('near') === 'me') nearMe({}); else if (S.fav) loadFavs().then(function () { search(true); }); else search(true);   // Near me from the search's Quick picks on another page
  }, 50); });
})();
</script>
<script src="/js/link-button.js?v=<?= (int) @filemtime(__DIR__ . '/../js/link-button.js') ?>" defer></script>
<?php tv_app_end();
