<?php
// /admin/api/find.php — the admin's search (Jason, 2026-11-12: "I need a way to find something easily … pages or tools …
// or anything within the admin like a listing, guide, customer, or data point"). GET ?q=… → what matches, in groups:
//   go:      modules and their sections (what each one is for, too), so "refund" finds where refunds are done; and
//            each scheduled task and switch by its name and what it does (Jason, 2026-11-13: "audit clock" found nothing),
//            opening its own place in System Configuration → Scheduled tasks or Switches
//   records: the things themselves, through each admin list's own search (orders, listings, guides, people, prospects…),
//            the top few of each kind, only from lists the person may open, within a time budget
//   actions: what can be started from here ("New client order", "Add a listing")
//   help:    FAQ answers whose question matches
// Staff only, as the admin's other endpoints. Plain database reads: it costs nothing to run. Nothing about what was
// searched is kept.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/crawler/IntakeStager.php';
require_once __DIR__ . '/../../../app/admin/AdminModules.php';
require_once __DIR__ . '/../../../app/lib/Workspaces.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
$ok = $me && IntakeStager::canUseIntake($pdo, $me);
if ($me && !$ok) { try { $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('admin_access') . " WHERE user_id = ? AND tier = 'regional_admin' LIMIT 1"); $st->execute([(int) $me['id']]); $ok = (bool) $st->fetchColumn(); } catch (Throwable) {} }
if (!$ok) Response::error('Staff only.', 403, 'forbidden');
$uid = (int) $me['id'];

$q = trim(mb_substr((string) ($_GET['q'] ?? ''), 0, 120));
// a web address or a domain is searched as its bare domain ("https://www.visitarizona.com/x" is visitarizona.com), the way
// sources, listings' websites and services keep it (Jason, 2026-11-12: "www.visitarizona.com" found nothing)
if (preg_match('#^(?:https?://)?(?:www\.)?([a-z0-9-]+(?:\.[a-z0-9-]+)+)(?:[/?\#].*)?$#i', $q, $dm)) $q = strtolower($dm[1]);
if (mb_strlen($q) < 2) Response::success(['go' => [], 'records' => [], 'actions' => [], 'help' => []]);
$norm = fn (string $s): string => trim(preg_replace('/\s+/', ' ', preg_replace('/[^a-z0-9#@.\-]+/', ' ', mb_strtolower($s))));
$words = array_values(array_filter(explode(' ', $norm($q)), fn ($w) => $w !== ''));

// a few words people use for what the admin calls something else
$SYN = ['refund' => 'payments', 'refunds' => 'payments', 'invoice' => 'orders', 'invoices' => 'orders', 'customer' => 'clients', 'customers' => 'clients',
        'staff' => 'people', 'employees' => 'people', 'users' => 'members', 'pins' => 'map', 'cron' => 'scheduled', 'jobs' => 'scheduled', 'password' => 'vault',
        'passwords' => 'vault', 'logins' => 'vault', 'flags' => 'switches', 'features' => 'switches', 'emails' => 'mail', 'email' => 'mail', 'business' => 'listings', 'businesses' => 'listings'];
/** How well a text matches: every word (or what it stands for) must be in it; a word at the start of a word scores more. 0: no match. */
$score = function (string $text) use ($words, $norm, $SYN): int {
    $t = ' ' . $norm($text); $s = 0;
    foreach ($words as $w) {
        $alts = [$w]; if (isset($SYN[$w])) $alts[] = $SYN[$w];
        $best = 0;
        foreach ($alts as $a) { if (str_contains($t, ' ' . $a)) $best = max($best, 3); elseif (str_contains($t, $a)) $best = max($best, 1); }
        // a typo (Jason, 2026-11-12: "chameleon filiter"): a word of 5+ letters a letter off, 8+ two off, with its first letter right
        if (!$best && strlen($w) >= 5) foreach (explode(' ', trim($t)) as $tw) {
            if ($tw === '' || $tw[0] !== $w[0] || abs(strlen($tw) - strlen($w)) > 2) continue;
            if (levenshtein($w, $tw) <= (strlen($w) >= 8 ? 2 : 1)) { $best = 2; break; }
        }
        if (!$best) return 0;
        $s += $best;
    }
    return $s;
};

// ---- go: modules and sections -----------------------------------------------------------------------------------------
$go = []; $secOf = [];   // tool key → [module, section, label]
$ABOUT = (array) (@include __DIR__ . '/../../../app/admin/section-about.php');   // one line on what each section is for
foreach (Workspaces::ALL as $mk => $w) {
    $mod = Modules::module($mk); if (!$mod) continue;
    foreach ($mod['sections'] as $sk => $s) {
        foreach ((array) ($s['widgets'] ?? []) as $wd) if (in_array($wd[0], ['table', 'pipeline'], true) && !isset($secOf[$wd[1]])) $secOf[$wd[1]] = [$mk, $sk, $s['label']];
        if (isset(Workspaces::MERGED[$mk])) continue;   // Pulse's sections are found in the Dashboard
        // the section's own name and what it's for decide; its module's words only order the matches (Jason, 2026-11-12:
        // "crawler" listed every Insights section because Insights' own line mentions the crawler)
        $about = (string) ($ABOUT[$mk . '/' . $sk] ?? ($s['about'] ?? ''));
        $own = $score($s['label']) * 3 + $score($s['label'] . ' ' . $about);
        if (!$own) continue;
        $sc = $own * 2 + ($score($w[1] . ' ' . $w[2]) ? 1 : 0);
        [$can, $why] = Modules::canSection($mk, $sk);
        $go[] = ['label' => $s['label'], 'sub' => $about, 'in' => $w[0] . '. ' . $w[1], 'url' => Modules::url($mk, $sk), 'icon' => $s['icon'] ?? 'compass', 'off' => $s['status'] === 'coming' ? 'Coming' : ($can ? '' : $why), 'score' => $sc];
    }
}
// scheduled tasks (Scheduler::JOBS) and switches (Switches::DEFS): what they're called and what they do, each opening its
// own card on its page (#job-…, #sw-…)
require_once __DIR__ . '/../../../app/lib/Scheduler.php';
require_once __DIR__ . '/../../../app/lib/Switches.php';
$KINDS = [['config', 'scheduler', 'Scheduled task', 'calendar', 'job-', array_map(fn ($j) => [$j[0], $j[1]], Scheduler::JOBS)],
          ['config', 'switches', 'Switch', 'settings', 'sw-', array_map(fn ($d) => [$d[0], $d[1]], Switches::DEFS)]];
foreach ($KINDS as [$mk, $sk, $kind, $icon, $pre, $items]) {
    $mod = Modules::module($mk); $sec = $mod['sections'][$sk] ?? null;
    if (!$sec) continue;
    [$can, $why] = Modules::canSection($mk, $sk);
    foreach ($items as $key => [$name, $what]) {
        $own = $score($name) * 3 + $score($name . ' ' . str_replace('_', ' ', (string) $key) . ' ' . $what);   // not the kind's own word: "cron" finds the page, not all 30 tasks
        if (!$own) continue;
        $go[] = ['label' => $name, 'sub' => $what, 'in' => $kind . ' · ' . Workspaces::ALL[$mk][1] . ' → ' . $sec['label'], 'url' => Modules::url($mk, $sk) . '#' . $pre . $key,
                 'icon' => $icon, 'off' => $can ? '' : $why, 'score' => $own * 2];
    }
}
usort($go, fn ($a, $b) => $b['score'] <=> $a['score']);
$go = array_slice($go, 0, 8);

// ---- actions: what can be started -------------------------------------------------------------------------------------
$actions = [];
foreach (Modules::tools() as $k => $t) {
    if (empty($t['create']['label']) || !isset($secOf[$k])) continue;
    $sc = $score($t['create']['label'] . ' ' . ($t['title'] ?? '')); if (!$sc) continue;
    [$can, $why] = Modules::canTool($k);
    if ($can && isset($t['create']['rule'])) [$can, $why] = Access::can($k . '.create', $t['create']['rule']);
    [$mk, $sk] = $secOf[$k];
    $actions[] = ['label' => $t['create']['label'], 'in' => (string) ($t['title'] ?? ''), 'url' => (string) ($t['create']['page'] ?? (Modules::url($mk, $sk) . '?new=' . rawurlencode($k))), 'off' => $can ? '' : $why, 'score' => $sc];
}
usort($actions, fn ($a, $b) => $b['score'] <=> $a['score']);
$actions = array_slice($actions, 0, 5);

// ---- records: each admin list's own search, the busiest kinds first, within a time budget -----------------------------
$PRI = ['backoffice/orders', 'local/listings', 'explore/place_guides', 'growth/prospects', 'backoffice/customers', 'backoffice/work_orders', 'backoffice/vendors', 'backoffice/products', 'local/claims', 'local/places'];
$keys = array_keys(Modules::tools());
usort($keys, function ($a, $b) use ($PRI) { $x = array_search($a, $PRI, true); $y = array_search($b, $PRI, true); return ($x === false ? 99 : $x) <=> ($y === false ? 99 : $y) ?: strcmp($a, $b); });
$records = []; $t0 = microtime(true); $skipped = 0;
foreach ($keys as $k) {
    $t = Modules::tool($k);
    if (!$t || !isset($t['list'], $secOf[$k])) continue;
    if (!Modules::canTool($k)[0]) continue;   // only lists the person may open
    if (microtime(true) - $t0 > 2.5) { $skipped++; continue; }
    try { [$rows] = ($t['list'])($pdo, ['q' => $q, 'page' => 0, 'per' => 25], $uid); } catch (Throwable) { continue; }
    $cols = (array) ($t['columns'] ?? []); $hits = [];
    foreach ((array) $rows as $r) {
        $title = (string) ($r['title'] ?? ''); if ($title === '') continue;
        $rest = []; foreach ($cols as $c) if ($c[0] !== 'title' && isset($r[$c[0]]) && is_scalar($r[$c[0]]) && in_array($c[2] ?? 'text', ['text', 'pill'], true) && (string) $r[$c[0]] !== '') $rest[] = (string) $r[$c[0]];
        $sc = $score($title) * 3 + $score($title . ' ' . implode(' ', $rest));
        if (!$sc) continue;   // a list whose search is loose (or that ignores it): only what really matches
        [$mk, $sk] = $secOf[$k];
        $open = (string) ($t['open'] ?? 'detail');
        $url = (string) ($r['href'] ?? '');
        if ($url === '') $url = str_contains($open, '{') ? str_replace(['{id}', '{ref}'], [(string) ($r['id'] ?? ''), rawurlencode((string) ($r['ref'] ?? ''))], $open) : Modules::url($mk, $sk, (string) ($r['id'] ?? ''));
        $hits[] = ['label' => $title, 'sub' => implode(' · ', array_slice(array_map(fn ($x) => str_replace('_', ' ', $x), $rest), 0, 3)), 'url' => $url, 'score' => $sc];
    }
    if (!$hits) continue;
    usort($hits, fn ($a, $b) => $b['score'] <=> $a['score']);
    [$mk, $sk, $sl] = $secOf[$k];
    $records[] = ['kind' => (string) ($t['title'] ?? $sl), 'all' => Modules::url($mk, $sk) . '?q=' . rawurlencode($q), 'n' => count($hits), 'items' => array_slice($hits, 0, 4), 'best' => $hits[0]['score']];
}
// places named on pages we read that we don't list yet (decisions/0157 §3): by name, anywhere, each opening its page
try {
    require_once __DIR__ . '/../../../app/lib/crawler/SourceIndex.php';
    $rd = []; $best = 0;
    foreach (SourceIndex::search($pdo, ['text' => $q, 'named_only' => true, 'limit' => 6]) as $x) {
        $c = SourceIndex::card($x);
        $sc = $score($c['label']) * 3 + $score($c['label'] . ' ' . $c['kind'] . ' ' . $c['town']);
        if (!$sc) continue;
        $rd[] = ['label' => $c['label'], 'sub' => implode(' · ', array_filter([$c['kind'], $c['town'], $c['from']])), 'url' => $c['source'], 'score' => $sc];
        $best = max($best, $sc);
    }
    if ($rd) $records[] = ['kind' => 'Named on pages we read (not listed yet)', 'all' => '', 'n' => min(4, count($rd)), 'items' => array_slice($rd, 0, 4), 'best' => $best - 1];
} catch (Throwable $e) { error_log('admin find read: ' . $e->getMessage()); }
usort($records, fn ($a, $b) => $b['best'] <=> $a['best']);

// ---- help: FAQ questions --------------------------------------------------------------------------------------------
$help = [];
$faq = @file_get_contents(__DIR__ . '/../../../app/ui/faq.md') ?: '';
if (preg_match_all('/^#{2,3}\s+(.+\?)\s*$/m', $faq, $m)) {
    foreach ($m[1] as $qq) {
        $sc = $score($qq); if (!$sc) continue;
        $slug = substr(trim(preg_replace('/[^a-z0-9]+/', '-', strtolower(html_entity_decode(strip_tags($qq)))), '-') ?: 'q', 0, 60);
        $help[] = ['label' => $qq, 'url' => '/faq.php#' . $slug, 'score' => $sc];
    }
}
// the decisions (degraffics/traversence decisions/): the rules behind how things work, by name ("chameleon filter"), and
// each note added to one (Jason, 2026-11-12), opened in System Configuration → Decisions
foreach ((array) (@include __DIR__ . '/../../../app/data/decisions-index.php') as $dx) {
    [$dn, $dt, $dl] = $dx; $isNote = ($dx[4] ?? '') === 'note';
    $sc = $isNote ? $score($dt . ' ' . $dl) : $score($dt) * 3 + $score($dn . ' ' . $dt . ' ' . $dl); if (!$sc) continue;
    $help[] = ['label' => 'Decision ' . $dn . ($isNote ? ' · ' . $dt : ': ' . $dt), 'sub' => $dl, 'url' => '/admin/config/decisions?d=' . $dn, 'in' => $isNote ? 'Note' : 'Decision', 'score' => $sc];
}
usort($help, fn ($a, $b) => $b['score'] <=> $a['score']);

Response::success(['go' => $go, 'records' => $records, 'actions' => $actions, 'help' => array_slice($help, 0, 5), 'partial' => $skipped > 0]);
