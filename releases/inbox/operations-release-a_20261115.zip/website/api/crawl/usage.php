<?php
// api/crawl/usage.php — the worker's web search (decisions/0062, 0084), for the admin dashboard's System status and to
// keep the search plan's allowance from running out or being billed past.
//   POST {ask: 1, engine, monthly}                     -> {allow, month_used, day_used}   before a run: how many it may make
//   {service: 'places', …} the same for the Google Places check (decisions/0085), counted apart (places_* keys)
//   POST {engine: "tavily"|"brave"|"", searches, fetches, monthly} -> {month_used}       after a run: how many it made
// The month's and the day's totals are kept in search_index_state (websearch_*), reset when the month or day turns.
// The pace: never past 90% of the monthly allowance (WEBSEARCH_STOP_PCT in .env), and no further into it than the
// month is gone (by the end of the 10th of a 30-day month, a third), and no more in one day than a day's share, so
// the allowance lasts the whole month and never goes in a burst.
// WEBSEARCH=off in .env stops web search altogether. The month's allowance and the stop line are the service
// register's (System Configuration → Service register; decisions/0163 §1, Release A): the worker's SEARCH_MONTHLY and
// GOOGLE_PLACES_MONTHLY, and WEBSEARCH_STOP_PCT / PLACES_STOP_PCT in .env, are read once to start it, then retired.

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/SearchIndex.php';

Response::requireMethod('POST');
$b = Response::jsonBody();
if (!class_exists('SearchIndex') || !SearchIndex::ready($pdo)) Response::json(['ok' => true, 'month_used' => null, 'allow' => 0]);
$K = ($b['service'] ?? '') === 'places' ? 'places' : 'websearch';   // which allowance: web search (Tavily) or Google Places
$engine = in_array((string) ($b['engine'] ?? ''), ['tavily', 'brave', 'google', ''], true) ? (string) $b['engine'] : '';
$month = date('Y-m'); $day = date('Y-m-d');
$used = SearchIndex::state($pdo, $K . '_month') === $month ? (int) SearchIndex::state($pdo, $K . '_used') : 0;
$dayUsed = SearchIndex::state($pdo, $K . '_day') === $day ? (int) SearchIndex::state($pdo, $K . '_day_used') : 0;
$monthly = max(0, min(10000000, (int) ($b['monthly'] ?? 0)));
$stopPct = (float) (getenv($K === 'places' ? 'PLACES_STOP_PCT' : 'WEBSEARCH_STOP_PCT') ?: 90);
// the service register (Thresholds): its number wins; before it's recorded, the worker's number starts it (recorded once)
if (is_file(__DIR__ . '/../../../app/lib/Thresholds.php')) {
    require_once __DIR__ . '/../../../app/lib/Thresholds.php';
    $gate = $K . '_monthly';
    if (Thresholds::stored($pdo, $gate) === null && $monthly > 0) { SearchIndex::setState($pdo, $gate, (string) $monthly); Thresholds::recordFound($pdo, $gate); }   // the worker's number, recorded once
    if (Thresholds::stored($pdo, $gate) !== null) $monthly = max(0, (int) Thresholds::get($pdo, $gate));   // else the worker sent none: 0, as before
    if (Thresholds::stored($pdo, $K . '_stop_pct') === null) Thresholds::recordFound($pdo, $K . '_stop_pct');
    $stopPct = (float) Thresholds::get($pdo, $K . '_stop_pct');
}

if (!empty($b['ask'])) {
    $pct = max(10.0, min(100.0, $stopPct));
    $stop = (int) floor($monthly * $pct / 100);
    $days = (int) date('t'); $today = (int) date('j');
    $pace = (int) floor($stop * $today / $days);   // how far into the allowance the month may be by the end of today
    $off = strtolower((string) getenv($K === 'places' ? 'GOOGLE_PLACES' : 'WEBSEARCH')) === 'off';
    // and no more in a day than the month's share of a day (the stop ÷ days in the month): an unused morning never
    // turns into a burst later (2026-10-14: 25 Google checks in the first few runs of the day)
    $daily = (int) ceil($stop / max(1, $days));
    $allow = $off || !$engine ? 0 : max(0, min($stop - $used, $pace - $used, $daily - $dayUsed));
    // spread evenly through the day (Jason, 2026-11-14; Thresholds paid_spread, on unless set to 0): a run may use only the
    // day's share up to the end of this 5-minute slot, so the day's allowance lasts until midnight
    $spread = 1;
    if (is_file(__DIR__ . '/../../../app/lib/Thresholds.php')) { require_once __DIR__ . '/../../../app/lib/Thresholds.php'; $spread = (int) (Thresholds::get($pdo, 'paid_spread') ?? 1); }
    if ($spread) $allow = max(0, min($allow, (int) ceil($daily * min(1440, (int) date('G') * 60 + (int) date('i') + 5) / 1440) - $dayUsed));
    SearchIndex::setState($pdo, $K . '_monthly', (string) $monthly);
    SearchIndex::setState($pdo, $K . '_engine', $engine);
    SearchIndex::setState($pdo, $K . '_stop', (string) $stop);
    SearchIndex::setState($pdo, $K . '_seen', (string) time());
    SearchIndex::setState($pdo, $K . '_daily', (string) $daily);
    Response::json(['ok' => true, 'allow' => $allow, 'month_used' => $used, 'day_used' => $dayUsed, 'stop' => $stop, 'pace' => $pace, 'daily' => $daily]);
}

$n = max(0, min(1000, (int) ($b['searches'] ?? 0)));
SearchIndex::setState($pdo, $K . '_month', $month);
SearchIndex::setState($pdo, $K . '_used', (string) ($used + $n));
SearchIndex::setState($pdo, $K . '_day', $day);
SearchIndex::setState($pdo, $K . '_day_used', (string) ($dayUsed + $n));
SearchIndex::setState($pdo, $K . '_engine', $engine);
SearchIndex::setState($pdo, $K . '_monthly', (string) $monthly);
SearchIndex::setState($pdo, $K . '_seen', (string) time());
Response::json(['ok' => true, 'month_used' => $used + $n]);
