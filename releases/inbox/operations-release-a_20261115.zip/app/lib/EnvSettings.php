<?php
// app/lib/EnvSettings.php — the plain settings that can be changed from Settings instead of in .env (decisions/0125).
// Jason, 2026-10-24, asked to change .env without File Manager. Only the settings listed here, none of them secret:
// keys, passwords and tokens stay set by hand in .env, never through a web page, so a stolen admin login can't read or
// replace them. Each change is checked, the file before it is kept (.env.bak-<when>, the last 5), the new file goes
// in whole (written beside it, then swapped), and the action log records who changed what.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class EnvSettings
{
    /** key => [label, what it does, kind]. kind: url-aws | region | bucket | url | money | email | text | phone */
    public const EDITABLE = [
        'AWS_CONSOLE_URL' => ['AWS sign-in link', 'Where the AWS cards\' "Sign in" goes: the account\'s own sign-in page, like https://trvgo.signin.aws.amazon.com/console.', 'url-aws'],
        'AWS_REGION' => ['AWS region', 'Where the bucket and Textract are, like us-east-2. Changing it points the site at another region: only if the bucket moved.', 'region'],
        'S3_BUCKET' => ['S3 bucket', 'The bucket every file is kept in. Changing it points the site at another bucket: files already in the old one aren\'t moved.', 'bucket'],
        'S3_PUBLIC_BASE' => ['Public photo address', 'Optional: a CloudFront address (or the bucket\'s own, once public photos are open) that photos load from directly. Empty: signed links.', 'url'],
        // flat monthly plans, counted in Outside services' monthly total (decisions/0152)
        'RAILWAY_USD_MONTH' => ['Railway plan, a month', 'Dollars a month for Railway, where the crawler worker runs (Hobby: 5).', 'money'],
        'BLUEHOST_USD_MONTH' => ['Bluehost plan, a month', 'Dollars a month for the web hosting plan (a yearly bill divided by 12).', 'money'],
        'COMMUNITY_BUDGET_PCT' => ['Community budget share', 'Percent of last month\'s revenue that pays for free members\' Moments (decisions/0154 §4). Default 3. At 100% of it, free accounts\' video Moments pause until the 1st.', 'money'],
        'COMMUNITY_BUDGET_FLOOR_USD' => ['Community budget floor', 'The least the community budget is in a month, in dollars, whatever the revenue. Default 25.', 'money'],
        'SMTP_FROM_NAME' => ['Email sender name', 'The name the site\'s emails come from.', 'text'],
        'SMTP_FROM_EMAIL' => ['Email sender address', 'The address the site\'s emails come from (it must be one the mail server may send as).', 'email'],
        'BUSINESS_POSTAL_ADDRESS' => ['Postal address', 'Printed at the foot of marketing emails, as the law asks.', 'text'],
        'CLAIM_VERIFY_NUMBER' => ['Claims phone number', 'The number businesses call to verify a claim.', 'phone'],
        'ORDERS_FROM_EMAIL' => ['Orders email', 'The system address work orders go to vendors from, like orders@trvgo.us. It only sends: replies, and vendors\' updates (accepted, ready, shipped…), go to the Orders reply-to. The mail server must be allowed to send as it (its own login, if it has one, stays in .env).', 'email'],
        'ORDERS_FROM_NAME' => ['Orders sender name', 'The name work orders come from, like Traversence Orders.', 'text'],
        'ORDERS_REPLY_TO' => ['Orders reply-to', 'Where vendors\' replies and their work order updates go. Empty: support@traversence.com.', 'email'],
        'SMTP_REPLY_TO' => ['Reply-to for site emails', 'Where replies to the site\'s system emails (donotreply@…) go. Empty: support@traversence.com.', 'email'],
        'WIRE_VERIFY_PHONE' => ['Wire check phone number', 'The number a client calls to confirm our wire details before sending money.', 'phone'],
        // Traversence's identity in its legal texts (decisions/0142 §1): the Terms, Privacy Policy and Seller Agreement fill from these
        'LEGAL_NAME' => ['Legal name (Terms and policies)', 'The name the Terms, Privacy Policy and Seller Agreement give for Traversence. Empty: Traversence.com, until the legal entity\'s formal name is set.', 'text'],
        'LEGAL_ADDRESS' => ['Legal address (Terms and policies)', 'The mailing address in the legal texts. Empty: PO Box 3570, Saint Johns, AZ 85936.', 'text'],
        'LEGAL_EMAIL' => ['Legal contact email', 'Where the legal texts send questions. Empty: support@traversence.com.', 'email'],
        'LEGAL_PHONE' => ['Phone for reporting a listing', 'Shown on every Marketplace item, as the INFORM Consumers Act requires a way to report suspicious activity by phone as well as online. Empty: only the Report button shows.', 'phone'],
        'LEGAL_STATE' => ['Governing law (state)', 'The state whose laws govern the Terms. Empty: Arizona.', 'text'],
        'LEGAL_COUNTY' => ['Disputes go to (county)', 'The county whose courts hear disputes. Empty: Apache County.', 'text'],
        'DOMAINS_MODE' => ['Own domains on storefronts', 'Connect your domain (decisions/0139): off (it says "opens soon"), test (only our team sees it; the real edge, Name.com\'s sandbox, no card charged) or live (businesses on Core and up; real charges).', 'domains-mode'],
        'NAMECOM_ENV' => ['Name.com: sandbox or live', 'Where domains are bought: sandbox (test registrations, nothing real) or live. Test mode always uses the sandbox. Its username and token for each stay in .env.', 'namecom-env'],
        'CLIENT_PAY_WAYS' => ['Ways clients can pay', 'Besides a card, what a client can choose at checkout on an order we prepare: wire, check, cash (comma between). Empty: card only. The bank details stay in .env, set by hand.', 'payways'],
    ];

    /** Secrets the site writes itself and never shows again (not on Settings): the health report's token (decisions/0145, TestAccounts). */
    public const WRITE_ONLY = ['HEALTH_TOKEN'];

    public static function value(string $key): string { Database::readEnv(); return trim((string) (getenv($key) ?: '')); }

    /** A value made safe for its kind, or an exception saying plainly what's wrong. */
    public static function check(string $key, string $v): string
    {
        if (!isset(self::EDITABLE[$key])) throw new InvalidArgumentException('That setting can only be changed in .env.');
        $v = trim($v);
        if (preg_match('/["\r\n\\\\]/', $v)) throw new InvalidArgumentException('Quotes, backslashes and line breaks can\'t go in a setting.');
        if ($v === '') {
            if (in_array($key, ['AWS_REGION', 'S3_BUCKET'], true)) throw new InvalidArgumentException('This one can\'t be empty: S3 would stop. Clear it in .env if you mean to.');
            return '';
        }
        $url = function (string $v): array { $u = parse_url($v); if (!$u || ($u['scheme'] ?? '') !== 'https' || empty($u['host'])) throw new InvalidArgumentException('Write the full address, starting https://'); return $u; };
        switch (self::EDITABLE[$key][2]) {
            case 'url-aws':
                $u = $url($v);
                if (!preg_match('/(^|\.)signin\.aws\.amazon\.com$|^console\.aws\.amazon\.com$/', (string) $u['host'])) throw new InvalidArgumentException('That isn\'t an AWS sign-in address (…signin.aws.amazon.com).');
                return $v;
            case 'url': $url($v); return rtrim($v, '/');
            case 'region': if (!preg_match('/^[a-z]{2}(-gov)?-[a-z]+-\d$/', $v)) throw new InvalidArgumentException('A region looks like us-east-2.'); return $v;
            case 'bucket': if (!preg_match('/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/', $v)) throw new InvalidArgumentException('A bucket name is 3 to 63 lower-case letters, numbers, dots or dashes.'); return $v;
            case 'money': if (!is_numeric($v) || (float) $v < 1 || (float) $v > 100000) throw new InvalidArgumentException('Write a dollar amount, like 25.'); return (string) (0 + $v);
            case 'email': if (!filter_var($v, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That isn\'t an email address.'); return strtolower($v);
            case 'payways':
                $ways = array_values(array_unique(array_filter(array_map('trim', explode(',', strtolower($v))))));
                foreach ($ways as $w) if (!in_array($w, ['wire', 'check', 'cash'], true)) throw new InvalidArgumentException('Use wire, check and/or cash, with a comma between.');
                return implode(',', $ways);
            case 'phone': if (!preg_match('/^[0-9 ()+.-]{7,25}$/', $v)) throw new InvalidArgumentException('Write a phone number, like (505) 555-0100.'); return $v;
            case 'domains-mode': if (!in_array(strtolower($v), ['off', 'test', 'live'], true)) throw new InvalidArgumentException('Write off, test or live.'); return strtolower($v);
            case 'namecom-env': if (!in_array(strtolower($v), ['sandbox', 'live'], true)) throw new InvalidArgumentException('Write sandbox or live.'); return strtolower($v);
            default: if (mb_strlen($v) > 200) throw new InvalidArgumentException('Keep it under 200 characters.'); return $v;
        }
    }

    /** Writes one setting into .env (replacing its line, or adding one). Returns [before, after]. */
    public static function set(string $key, string $value): array
    {
        return self::write($key, self::check($key, $value));
    }

    /** A secret the site makes itself (WRITE_ONLY): written to .env, never offered on Settings or its endpoint. */
    public static function setSecret(string $key, string $value): void
    {
        if (!in_array($key, self::WRITE_ONLY, true) || !preg_match('/^[A-Za-z0-9_-]{32,128}$/', $value)) throw new InvalidArgumentException('That isn\'t a secret the site makes.');
        self::write($key, $value);
    }

    private static function write(string $key, string $value): array
    {
        $path = Database::envPath();
        if (!is_file($path) || !is_writable($path) || !is_writable(dirname($path))) throw new RuntimeException('The site can\'t write .env on this server. Change it in cPanel → File Manager instead.');
        $lock = fopen($path . '.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX)) throw new RuntimeException('Someone else is changing a setting. Try again in a moment.');
        try {
            $text = (string) file_get_contents($path);
            $lines = preg_split('/\r\n|\n/', $text);
            $out = preg_match('/[\s#]/', $value) ? $key . '="' . $value . '"' : $key . '=' . $value;
            $before = ''; $done = false;
            foreach ($lines as $i => $l) {
                if ($done || !preg_match('/^\s*' . preg_quote($key, '/') . '\s*=(.*)$/', $l, $m)) continue;
                $before = trim(trim($m[1]), '"\'');
                $lines[$i] = $out; $done = true;
            }
            if (!$done) { if (end($lines) === '') array_pop($lines); $lines[] = $out; $lines[] = ''; }
            $new = implode("\n", $lines);
            $perm = fileperms($path) & 0777;
            $bak = $path . '.bak-' . date('Ymd-His');
            if (!@copy($path, $bak)) throw new RuntimeException('Couldn\'t keep a copy of .env first, so nothing was changed.');
            @chmod($bak, $perm);
            foreach (array_slice(array_reverse(glob($path . '.bak-*') ?: []), 5) as $old) @unlink($old);   // the last 5
            $tmp = $path . '.new-' . bin2hex(random_bytes(4));
            if (file_put_contents($tmp, $new) !== strlen($new)) { @unlink($tmp); throw new RuntimeException('Couldn\'t write the new .env, so nothing was changed.'); }
            @chmod($tmp, $perm);
            if (!@rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException('Couldn\'t put the new .env in place, so nothing was changed.'); }
            putenv($key . '=' . $value); $_ENV[$key] = $value;
            return [$before, $value];
        } finally { flock($lock, LOCK_UN); fclose($lock); }
    }
}
