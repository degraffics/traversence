<?php
// app/lib/Takedowns.php — limiting exposure (decisions/0133, the protected-information standard): anyone, signed in or
// not, can ask us to take down something we publish (a guide's section, a heritage fact, a topic, a landmark), and it is
// hidden within 24 hours while we look. A protected reason (it shows the way to a sacred, burial or archaeological place;
// a nation asks; someone's private information; a safety risk) hides it at once; any other reason hides it when 24
// hours pass without a person deciding (the takedowns job). A person then restores it (nothing wrong, or fixed) or keeps
// it down (upheld). Every move is reversible: what an item was before is kept. Members' own posts, journeys and comments
// keep their Report button (Reports); listings their owners and Suggest a change. Read by /takedown.php, the guide page
// (held sections), the Topic index (a held topic), and Social → Takedowns.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Takedowns
{
    public const KINDS = ['guide' => 'A guide\'s section', 'fact' => 'A fact from our heritage catalog', 'topic' => 'A topic', 'landmark' => 'A landmark'];
    /** reason => [label, hidden at once]. */
    public const REASONS = [
        'way_in' => ['It shows the way to a sacred, burial or archaeological place', true],
        'nation' => ['I speak for a tribal nation, and it should not be told', true],
        'private_info' => ['It shows someone\'s private information', true],
        'safety' => ['It puts someone or something at risk', true],
        'copyright' => ['It copies my work', false],
        'wrong' => ['It\'s wrong or misleading', false],
        'other' => ['Something else', false],
    ];
    public const HOURS = 24;
    /** How many one person may send a day. */
    public const PER_DAY = 5;

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM takedowns LIMIT 0'); $ok = true; } catch (Throwable $e) { $ok = false; } }
        return $ok;
    }

    /** What the item is, if we publish it: ['title', 'url'] or null. */
    public static function describe(PDO $pdo, string $kind, string $ref, string $section = ''): ?array
    {
        try {
            if ($kind === 'guide') {
                require_once __DIR__ . '/Guides.php';
                $p = Guides::place($pdo, $ref); if (!$p) return null;
                $g = Guides::get($pdo, $ref); if ($g['status'] !== 'live') return null;
                if ($section !== '' && !isset(Guides::SECTIONS[$section])) return null;
                return ['title' => $p['name'] . ' guide' . ($section !== '' ? ': ' . Guides::SECTIONS[$section][0] : ''), 'url' => (string) $p['url'] . ($section !== '' ? '#g-' . $section : '')];
            }
            if ($kind === 'fact') {
                $st = $pdo->prepare("SELECT id, place_key, title FROM heritage_facts WHERE id = ? AND status = 'cataloged' AND tier IN ('public', 'story')"); $st->execute([(int) $ref]);
                $f = $st->fetch(PDO::FETCH_ASSOC); if (!$f) return null;
                require_once __DIR__ . '/Guides.php';
                $p = Guides::place($pdo, (string) $f['place_key']);
                return ['title' => (string) $f['title'] . ($p ? ' (' . $p['name'] . ')' : ''), 'url' => $p ? (string) $p['url'] . '#g-footsteps' : ''];
            }
            if ($kind === 'topic') {
                require_once __DIR__ . '/Topics.php';
                $t = Topics::get($pdo, $ref); if (!$t) return null;
                return ['title' => (string) $t['name'], 'url' => '/ai/?topic=' . rawurlencode((string) $t['slug'])];
            }
            if ($kind === 'landmark') {
                $st = $pdo->prepare("SELECT gnis_id, name FROM landmarks WHERE gnis_id = ? AND status IN ('shown', 'approved', 'story_only')"); $st->execute([(int) $ref]);
                $l = $st->fetch(PDO::FETCH_ASSOC); if (!$l) return null;
                return ['title' => (string) $l['name'], 'url' => '/place/landmark.php?id=' . (int) $l['gnis_id']];
            }
        } catch (Throwable $e) { error_log('takedown describe: ' . $e->getMessage()); }
        return null;
    }

    /**
     * Files a request. $in: kind, ref, section, reason, note, email. Returns ['id', 'hidden' => bool (now), 'hide_by'].
     * One person: PER_DAY a day. A second request on an item already down is kept with the first.
     */
    public static function file(PDO $pdo, array $in, ?int $uid): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('Takedowns aren\'t set up yet. Please write to support@traversence.com and we\'ll take care of it.');
        $kind = (string) ($in['kind'] ?? ''); $ref = trim((string) ($in['ref'] ?? '')); $section = (string) ($in['section'] ?? '');
        if (!isset(self::KINDS[$kind])) throw new InvalidArgumentException('That can\'t be taken down from here.');
        $reason = (string) ($in['reason'] ?? '');
        if (!isset(self::REASONS[$reason])) throw new InvalidArgumentException('Choose why it should come down.');
        $d = self::describe($pdo, $kind, $ref, $section) ?? throw new InvalidArgumentException('That isn\'t published on Traversence now: it may be down already.');
        $email = trim((string) ($in['email'] ?? ''));
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email address doesn\'t look right.');
        $note = mb_substr(trim(strip_tags((string) ($in['note'] ?? ''))), 0, 2000);
        if ($reason === 'other' && $note === '') throw new InvalidArgumentException('Tell us what\'s wrong with it.');
        $asker = self::asker($uid);
        $st = $pdo->prepare('SELECT COUNT(*) FROM takedowns WHERE asker = ? AND created_at >= CURDATE()'); $st->execute([$asker]);
        require_once __DIR__ . '/Thresholds.php'; $max = (int) Thresholds::get($pdo, 'takedown_per_day');   // Thresholds & gates
        if ((int) $st->fetchColumn() >= $max) throw new InvalidArgumentException('That\'s ' . $max . ' requests today. Please write to support@traversence.com for more.');
        $pdo->prepare('INSERT INTO takedowns (kind, ref, section, title, url, reason, note, email, user_id, asker, hide_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() + INTERVAL ' . self::HOURS . ' HOUR)')
            ->execute([$kind, mb_substr($ref, 0, 60), $section, mb_substr($d['title'], 0, 190), mb_substr($d['url'], 0, 300), $reason, $note, mb_substr($email, 0, 160), $uid ?: null, $asker]);
        $id = (int) $pdo->lastInsertId();
        $down = self::down($pdo, $kind, $ref, $section);
        $hidden = false;
        if ($down) { $pdo->prepare("UPDATE takedowns SET status = 'hidden', hidden_at = NOW(), prior = ? WHERE id = ?")->execute([(string) $down['prior'], $id]); $hidden = true; }   // already down: kept with the first
        elseif (self::REASONS[$reason][1]) { self::hide($pdo, $id); $hidden = true; }
        self::tellAdmins($pdo, 'Takedown asked: ' . $d['title'], 'Someone asked us to take down "' . $d['title'] . '" (' . self::REASONS[$reason][0] . ').'
            . "\n\n" . ($hidden ? 'It is hidden now.' : 'It is hidden in ' . self::HOURS . ' hours unless a person decides first.') . ($note !== '' ? "\n\nWhat they said:\n" . $note : '')
            . "\n\n" . rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/admin/social/takedowns');
        return ['id' => $id, 'hidden' => $hidden, 'hide_by' => date('Y-m-d H:i', time() + self::HOURS * 3600)];
    }

    /** The request holding an item down now, if any. */
    private static function down(PDO $pdo, string $kind, string $ref, string $section): ?array
    {
        $st = $pdo->prepare("SELECT * FROM takedowns WHERE kind = ? AND ref = ? AND section = ? AND status IN ('hidden', 'upheld') ORDER BY id LIMIT 1"); $st->execute([$kind, $ref, $section]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Hides the request's item, keeping what it was. */
    public static function hide(PDO $pdo, int $id): void
    {
        $r = self::row($pdo, $id); if (!$r || $r['status'] !== 'open') return;
        $prior = '';
        if ($r['kind'] === 'fact') {
            $st = $pdo->prepare('SELECT status, place_key FROM heritage_facts WHERE id = ?'); $st->execute([(int) $r['ref']]); $f = $st->fetch(PDO::FETCH_ASSOC);
            if ($f && $f['status'] === 'cataloged') {
                $prior = 'cataloged'; $pdo->prepare("UPDATE heritage_facts SET status = 'held' WHERE id = ?")->execute([(int) $r['ref']]);
                self::forget($pdo, (string) $f['place_key']);
                try { require_once __DIR__ . '/Guides.php'; Guides::due($pdo, (string) $f['place_key'], 'a fact was taken down'); } catch (Throwable $e) {}   // written again without it
            }
        } elseif ($r['kind'] === 'landmark') {
            $st = $pdo->prepare('SELECT status FROM landmarks WHERE gnis_id = ?'); $st->execute([(int) $r['ref']]); $s = $st->fetchColumn();
            if (in_array($s, ['shown', 'approved', 'story_only'], true)) { $prior = (string) $s; $pdo->prepare("UPDATE landmarks SET status = 'hidden', why = 'Taken down while we look (a request)' WHERE gnis_id = ?")->execute([(int) $r['ref']]); }
        } elseif ($r['kind'] === 'guide') self::forget($pdo, (string) $r['ref']);   // the guide page leaves the section out (heldSections)
        $pdo->prepare("UPDATE takedowns SET status = 'hidden', hidden_at = NOW(), prior = ? WHERE id = ?")->execute([$prior, $id]);
    }

    /** A person brings it back (nothing wrong with it, or it was fixed): every request on the item closes. */
    public static function restore(PDO $pdo, int $id, int $by, string $note = ''): void
    {
        $r = self::row($pdo, $id) ?? throw new InvalidArgumentException('That request isn\'t here.');
        $all = self::onItem($pdo, $r);
        $prior = ''; foreach ($all as $x) if ($x['prior'] !== '') { $prior = (string) $x['prior']; break; }
        if ($r['kind'] === 'fact' && $prior !== '') $pdo->prepare("UPDATE heritage_facts SET status = ? WHERE id = ? AND status = 'held'")->execute([$prior, (int) $r['ref']]);
        if ($r['kind'] === 'landmark' && $prior !== '') $pdo->prepare("UPDATE landmarks SET status = ?, why = '' WHERE gnis_id = ? AND status = 'hidden'")->execute([$prior, (int) $r['ref']]);
        self::close($pdo, $all, 'restored', $by, $note);
        if ($r['kind'] === 'guide') self::forget($pdo, (string) $r['ref']);
        if ($r['kind'] === 'fact') { $st = $pdo->prepare('SELECT place_key FROM heritage_facts WHERE id = ?'); $st->execute([(int) $r['ref']]); self::forget($pdo, (string) $st->fetchColumn()); }
    }

    /** A person keeps it down. A fact becomes restricted (kept, never shown); a landmark stays hidden; a guide's section stays out until it's rewritten and restored. */
    public static function uphold(PDO $pdo, int $id, int $by, string $note = ''): void
    {
        $r = self::row($pdo, $id) ?? throw new InvalidArgumentException('That request isn\'t here.');
        if ($r['status'] === 'open') self::hide($pdo, $id);
        if ($r['kind'] === 'fact') $pdo->prepare("UPDATE heritage_facts SET tier = 'restricted' WHERE id = ?")->execute([(int) $r['ref']]);
        self::close($pdo, self::onItem($pdo, self::row($pdo, $id)), 'upheld', $by, $note);
    }

    /** The job: hides what has waited 24 hours without a person deciding. Returns how many. */
    public static function tick(PDO $pdo): int
    {
        if (!self::ready($pdo)) return 0;
        $n = 0;
        foreach ($pdo->query("SELECT id FROM takedowns WHERE status = 'open' AND hide_by <= NOW() ORDER BY id LIMIT 200")->fetchAll(PDO::FETCH_COLUMN) as $id) { self::hide($pdo, (int) $id); $n++; }
        return $n;
    }

    /** A live guide's sections held down by a request ('' = the whole guide). */
    public static function heldSections(PDO $pdo, string $key): array
    {
        if (!self::ready($pdo)) return [];
        try {
            $st = $pdo->prepare("SELECT DISTINCT section FROM takedowns WHERE kind = 'guide' AND ref = ? AND status IN ('hidden', 'upheld')"); $st->execute([$key]);
            $out = $st->fetchAll(PDO::FETCH_COLUMN);
            // a fact taken down: the footsteps chapter was written from it, so it stays out until the guide is written again
            $st = $pdo->prepare("SELECT 1 FROM takedowns t JOIN heritage_facts f ON f.id = t.ref JOIN place_guides g ON g.place_key = f.place_key
                                 WHERE t.kind = 'fact' AND f.place_key = ? AND t.status IN ('hidden', 'upheld') AND t.hidden_at >= COALESCE(g.updated_at, '2000-01-01') LIMIT 1");
            $st->execute([$key]);
            if ($st->fetchColumn()) $out[] = 'footsteps';
            return array_values(array_unique($out));
        } catch (Throwable $e) { return []; }
    }

    /** Is this topic held down (its summary isn't shown or used)? */
    public static function topicHeld(PDO $pdo, array $t): bool
    {
        if (!self::ready($pdo)) return false;
        try { $st = $pdo->prepare("SELECT 1 FROM takedowns WHERE kind = 'topic' AND ref IN (?, ?) AND status IN ('hidden', 'upheld') LIMIT 1"); $st->execute([(string) $t['slug'], (string) $t['id']]); return (bool) $st->fetchColumn(); }
        catch (Throwable $e) { return false; }
    }

    /** The queue for Social → Takedowns: open and hidden first (oldest first), then the last 30 decided. */
    public static function queue(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [];
        return $pdo->query("(SELECT * FROM takedowns WHERE status IN ('open', 'hidden') ORDER BY created_at LIMIT 200)
                            UNION ALL (SELECT * FROM takedowns WHERE status IN ('restored', 'upheld') ORDER BY decided_at DESC LIMIT 30)")->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function openCount(PDO $pdo): int
    {
        if (!self::ready($pdo)) return 0;
        try { return (int) $pdo->query("SELECT COUNT(*) FROM takedowns WHERE status IN ('open', 'hidden')")->fetchColumn(); } catch (Throwable $e) { return 0; }
    }

    public static function row(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM takedowns WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private static function onItem(PDO $pdo, array $r): array
    {
        $st = $pdo->prepare("SELECT * FROM takedowns WHERE kind = ? AND ref = ? AND section = ? AND status IN ('open', 'hidden', 'upheld') ORDER BY id"); $st->execute([$r['kind'], $r['ref'], $r['section']]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Closes the requests and tells each asker who left an email. */
    private static function close(PDO $pdo, array $rows, string $status, int $by, string $note): void
    {
        $note = mb_substr(trim($note), 0, 500);
        foreach ($rows as $x) {
            $pdo->prepare('UPDATE takedowns SET status = ?, decided_by = ?, decided_at = NOW(), decision_note = ? WHERE id = ?')->execute([$status, $by, $note, (int) $x['id']]);
            if ((string) $x['email'] === '') continue;
            try {
                require_once __DIR__ . '/Mailer.php';
                Mailer::send((string) $x['email'], 'Your takedown request: ' . $x['title'], 'You asked us to take down "' . $x['title'] . '".' . "\n\n"
                    . ($status === 'upheld' ? 'We looked, and it stays down.' : 'We looked, and it\'s back on the site' . ($note !== '' ? '' : ': we didn\'t find a reason to keep it down') . '.')
                    . ($note !== '' ? "\n\n" . $note : '') . "\n\nIf you have more to tell us, write to support@traversence.com.\n\nTraversence");
            } catch (Throwable $e) { error_log('takedown mail: ' . $e->getMessage()); }
        }
    }

    /** A one-way daily hash of who asked (their account, else their address), used only to count requests a day. */
    private static function asker(?int $uid): string
    {
        $who = $uid ? 'u' . $uid : 'ip' . (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        return substr(hash('sha256', $who . '|' . date('Y-m-d') . '|' . (string) (getenv('APP_KEY') ?: __DIR__)), 0, 16);
    }

    private static function forget(PDO $pdo, string $key): void
    {
        if ($key === '') return;
        try { require_once __DIR__ . '/Guides.php'; Guides::forget($pdo, $key); } catch (Throwable $e) {}
    }

    private static function tellAdmins(PDO $pdo, string $subject, string $body): void
    {
        try {
            $to = $pdo->query("SELECT u.email FROM users u WHERE u.is_admin = 1 AND u.is_suspended = 0
                                UNION SELECT u.email FROM " . Database::t('admin_access') . " a JOIN users u ON u.id = a.user_id WHERE a.tier = 'super_admin'")->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable $e) { $to = []; }
        require_once __DIR__ . '/Mailer.php';
        foreach (array_unique($to) as $email) { try { Mailer::send((string) $email, '[Traversence] ' . $subject, $body); } catch (Throwable $t) { error_log('takedown mail: ' . $t->getMessage()); } }
    }
}
