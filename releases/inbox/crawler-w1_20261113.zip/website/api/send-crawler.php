<?php
// api/send-crawler.php — "Send the crawler" (decisions/0157 §3; Jason, 2026-11-13: "only staff, only me"). Get Local's Find a
// business, for the Founder signed in to the admin: for the town searched, the registered sources there are read again
// first, OpenStreetMap is asked again for the town's kinds of places, and the sources waiting for his call there are
// listed. Its words (review E22): a kind of place gets its own job in the town; anything else is looked up as a business's
// name, with one web search from the month's free allowance (paced, CLAUDE.md "No income, no expense"), then its own site.
//   POST {qs: the directory's place ("city=…&state=…", "lat=…&lon=…", "zip=…"), q: the words}  -> {ok, message, reread, osm, waiting}
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
require_once __DIR__ . '/../../app/lib/crawler/SourceIndex.php';
require_once __DIR__ . '/../../app/admin/Access.php';

header('Cache-Control: no-store');
Response::requireMethod('POST');
Response::requireCsrf();
$pdo = Database::connection();
$me = Auth::currentUser();
if (!$me || !IntakeStager::canUseIntake($pdo, $me) || Access::who()[0] !== 'founder') Response::error('Only the Founder can send the crawler.', 403, 'forbidden');

$b = Response::jsonBody();
parse_str((string) ($b['qs'] ?? ''), $p);
$words = trim(mb_substr((string) ($b['q'] ?? ''), 0, 120));
// the place as a town: named, or the town nearest the point or ZIP
$city = trim((string) ($p['city'] ?? '')); $state = strtoupper(trim((string) ($p['state'] ?? '')));
try {
    if ($city === '' && isset($p['zip']) && preg_match('/^\d{5}$/', (string) $p['zip'])) {
        $st = $pdo->prepare('SELECT city, state FROM zip_coordinates WHERE zip = ? LIMIT 1'); $st->execute([(string) $p['zip']]);
        if ($r = $st->fetch(PDO::FETCH_ASSOC)) { $city = (string) $r['city']; $state = (string) $r['state']; }
    } elseif ($city === '' && isset($p['lat'], $p['lon']) && is_numeric($p['lat']) && is_numeric($p['lon'])) {
        $la = (float) $p['lat']; $lo = (float) $p['lon'];
        $st = $pdo->prepare('SELECT city, state FROM zip_coordinates WHERE latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?
                              ORDER BY POW(latitude - ?, 2) + POW(longitude - ?, 2) LIMIT 1');
        $st->execute([$la - 0.5, $la + 0.5, $lo - 0.6, $lo + 0.6, $la, $lo]);
        if ($r = $st->fetch(PDO::FETCH_ASSOC)) { $city = (string) $r['city']; $state = (string) $r['state']; }
    }
} catch (Throwable $e) { error_log('send-crawler place: ' . $e->getMessage()); }
if ($city === '' || !preg_match('/^[A-Z]{2}$/', $state)) Response::error('Choose a town (or use your location) first: the crawler works a town at a time.', 422, 'no_town');

$r = SourceIndex::sendCrawler($pdo, $city, $state, $words);
$town = ucwords(mb_strtolower($city)) . ', ' . $state;
$parts = [];
$parts[] = $r['reread'] ? $r['reread'] . ' of our sources there will be read again next' : 'none of our sources there yet';
$parts[] = $r['osm'] ? 'OpenStreetMap asked again for ' . $r['osm'] . ' kinds of places' : 'OpenStreetMap couldn\'t be asked (no town record for it)';
$msg = 'Sent to ' . $town . ': ' . implode('; ', $parts) . '.';
if ($r['want'] !== '') $msg .= ' ' . $r['want'] . ' there are looked for on their own.';
if ($r['find']) $msg .= ' "' . $words . '" will be looked up by name on the next runs (Insights → Crawler shows the request).';
if ($r['waiting']) $msg .= ' Waiting for your call there: ' . implode(', ', array_map(fn ($w) => (string) $w[0], $r['waiting'])) . ' (Insights → Crawler sources).';
// honest (review §1.3: "new listings show within the hour" wasn't true of finds that need a person)
$msg .= ' What it finds is checked like any find: one confirmed by its own website or a government page shows within the hour or so; others go to Review.';
Response::json(['ok' => true, 'message' => $msg, 'reread' => $r['reread'], 'osm' => $r['osm'], 'waiting' => array_map(fn ($w) => ['host' => $w[0], 'url' => $w[1]], $r['waiting'])]);
