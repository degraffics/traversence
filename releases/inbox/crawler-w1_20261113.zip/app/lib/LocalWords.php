<?php
// app/lib/LocalWords.php — our own index as the dictionary (decisions/0157 §4): the words used here, from what we hold, and
// how often. Spelling and suggestions know them before a general dictionary does, and a word's sense comes from the words it
// sits with here.
//
//   words    every word of our listings' names and kinds, the place store's names and words (places named on pages we
//            read), our towns and the landmarks we show, with how many times it's used here
//   names    the words of towns' and landmarks' names: never "corrected"; a business's name words count by use (twice or
//            more: "Blue Hills" isn't "blue halls"), as one listing's name could hold a slip
//   kinds    for a word's root, the kinds of business it sits with here and how often ("shoot": shooting ranges), which
//            chooses among the kinds a search's words could mean (Concepts::kinds)
//   phrases  two words used together here three times or more ("oil change", "trash collection"), with their kinds: read
//            as one unit, so a phrase's meaning isn't the average of its words (decisions/0157 §4.4)
//
// Built once a day off the visitor's path (the crawler's report calls refresh(); search only reads the saved copy) into
// app/storage, which never leaves the server. Plain database reads: it costs nothing.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class LocalWords
{
    private const MAX_AGE = 86400;
    private const PUBLIC = ['unclaimed', 'claimed-unverified', 'pending-verification', 'verified'];
    /** Words that carry no meaning of their own here. */
    private const STOP = ['the', 'and', 'for', 'with', 'from', 'inc', 'llc', 'co', 'corp', 'ltd', 'dba', 'of', 'at', 'in', 'on', 'to', 'by', 'our', 'your', 'a', 'an', 'az', 'nm', 'ut'];

    private static ?array $d = null;

    private static function file(): string { return dirname(__DIR__) . '/storage/local-words.php'; }

    /** The saved words (empty until the first build). */
    private static function d(): array
    {
        if (self::$d === null) {
            $f = self::file();
            $x = is_file($f) ? @include $f : null;
            self::$d = is_array($x) ? $x + ['phrases' => []] : ['words' => [], 'names' => [], 'kinds' => [], 'phrases' => [], 'built' => 0];
        }
        return self::$d;
    }

    public static function ready(): bool { return (bool) self::d()['words']; }

    /** A word's root, as the classifier folds them (shooting / shoot, ranges / range). */
    public static function root(string $w): string
    {
        require_once __DIR__ . '/CategoryClassifier.php';
        return CategoryClassifier::stem(mb_strtolower($w));
    }

    /** How many times a word is used here (its plain and plural forms together). */
    public static function count(string $w): int
    {
        $W = self::d()['words']; $w = mb_strtolower(trim($w));
        $n = 0;
        foreach (array_unique([$w, self::singular($w), $w . 's', $w . 'es']) as $v) $n += (int) ($W[$v] ?? 0);
        return $n;
    }

    /** A word of a town's or a landmark's name here: a real name, never a slip. */
    public static function isName(string $w): bool
    {
        $N = self::d()['names']; $w = mb_strtolower(trim($w));
        return isset($N[$w]) || isset($N[self::singular($w)]);
    }

    /**
     * Is this a word used here, sure enough never to be offered a fix? A town's or landmark's name word, or a word used at
     * least three times (once or twice could be a slip a page or a listing's name repeats).
     */
    public static function knows(string $w): bool { return self::isName($w) || self::count($w) >= 3; }

    private static function singular(string $w): string
    {
        if (strlen($w) > 4 && str_ends_with($w, 'ies')) return substr($w, 0, -3) . 'y';
        if (strlen($w) > 4 && preg_match('/(ch|sh|x|ss|z)es$/', $w)) return substr($w, 0, -2);
        if (strlen($w) > 3 && str_ends_with($w, 's') && !str_ends_with($w, 'ss')) return substr($w, 0, -1);
        return $w;
    }

    /**
     * The words used here near a slip: [word => how often], those within $maxD letters, at most $max, most used first.
     * Words of three letters or fewer are never offered.
     */
    public static function near(string $t, int $maxD, int $max = 8): array
    {
        $t = mb_strtolower($t); $len = mb_strlen($t); $out = [];
        foreach (self::d()['words'] as $w => $n) {
            $w = (string) $w;
            if ($w === $t || abs(mb_strlen($w) - $len) > $maxD || mb_strlen($w) < 4) continue;
            require_once __DIR__ . '/SearchText.php';
            if (levenshtein($t, $w) <= $maxD || ($maxD >= 1 && SearchText::swapped($t, $w))) $out[$w] = (int) $n;
        }
        arsort($out);
        return array_slice($out, 0, $max, true);
    }

    /** A small lift for a word by how often it's used here: 0 (once) to 0.05 (hundreds of times). */
    public static function weight(string $w): float
    {
        $n = self::count($w);
        return $n <= 1 ? 0.0 : round(min(0.05, 0.012 * log($n)), 3);
    }

    /**
     * The sense from context (decisions/0157 §4.2): for the words of a search, how strongly each kind of business sits
     * with them here, 0 to 1 (its share of the times the words appear with any kind). [category id => share]
     */
    public static function kindsFor(array $words): array
    {
        $K = self::d()['kinds']; $P = self::d()['phrases']; $sum = []; $n = 0;
        $words = array_values(array_map('strval', $words)); $used = [];
        // a phrase used here is one unit: its own kinds, its words not counted again
        for ($i = 0; $i + 1 < count($words); $i++) {
            $ph = self::root($words[$i]) . ' ' . self::root($words[$i + 1]);
            if (empty($P[$ph])) continue;
            $tot = array_sum($P[$ph]); $n++; $used[$i] = $used[$i + 1] = true;
            foreach ($P[$ph] as $id => $c) $sum[(int) $id] = ($sum[(int) $id] ?? 0) + $c / $tot;
        }
        foreach ($words as $i => $w) {
            if (isset($used[$i])) continue;
            $r = self::root((string) $w);
            if (mb_strlen($r) < 3 || !isset($K[$r])) continue;
            $tot = array_sum($K[$r]); if ($tot < 2) continue;
            if (max($K[$r]) / $tot < 0.25) continue;   // a word that sits with every kind ("place", "service") says nothing
            $n++;
            foreach ($K[$r] as $id => $c) $sum[(int) $id] = ($sum[(int) $id] ?? 0) + $c / $tot;
        }
        if (!$n) return [];
        foreach ($sum as $id => $v) $sum[$id] = round($v / $n, 3);
        arsort($sum);
        return $sum;
    }

    /** Two words used together here, as one unit ("oil change"): its kinds, or [] when it isn't one. */
    public static function phrase(string $a, string $b): array { return self::d()['phrases'][self::root($a) . ' ' . self::root($b)] ?? []; }

    /** Builds the words again when they're a day old (or $force). Returns how many words, or null when nothing was done. */
    public static function refresh(PDO $pdo, bool $force = false): ?int
    {
        $f = self::file();
        if (!$force && is_file($f) && filemtime($f) > time() - self::MAX_AGE) return null;
        $dir = dirname($f);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return null;
        $lock = @fopen($dir . '/local-words.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) return null;   // another request is building it
        try {
            $d = self::build($pdo);
            $tmp = $f . '.' . getmypid() . '.tmp';
            if (file_put_contents($tmp, "<?php\n// Made by LocalWords::refresh() from our own listings, places and pages (decisions/0157). Don't edit.\nreturn " . var_export($d, true) . ";\n") === false) return null;
            rename($tmp, $f);
            if (function_exists('opcache_invalidate')) @opcache_invalidate($f, true);
            self::$d = $d;
            return count($d['words']);
        } catch (Throwable $e) {
            error_log('LocalWords::refresh: ' . $e->getMessage());
            return null;
        } finally {
            flock($lock, LOCK_UN); fclose($lock);
        }
    }

    private static function build(PDO $pdo): array
    {
        $words = []; $names = []; $kinds = []; $pairs = [];
        $split = fn (string $s): array => array_values(array_filter(preg_split('/[^\p{L}]+/u', mb_strtolower($s), -1, PREG_SPLIT_NO_EMPTY) ?: [],
            fn ($w) => mb_strlen($w) >= 3 && !in_array($w, self::STOP, true) && preg_match('/[aeiouy]/u', $w)));
        // $clue: whether its words say what kind of thing it is. A business's name doesn't (review E26: every "Blue Rhino"
        // made "blue" mean Propane Tank Kiosks, so "blue hills" read as propane): its words are known, never kind clues
        $add = function (string $text, ?int $cat, bool $isName, bool $clue = true) use (&$words, &$names, &$kinds, &$pairs, $split) {
            $seen = [];
            $ws = $split($text);
            if (!$isName && $clue) for ($i = 0; $i + 1 < count($ws); $i++) {   // two words together, in what things are and do (not in names)
                $ph = self::root($ws[$i]) . ' ' . self::root($ws[$i + 1]);
                $pairs[$ph]['n'] = ($pairs[$ph]['n'] ?? 0) + 1;
                if ($cat) $pairs[$ph]['k'][$cat] = ($pairs[$ph]['k'][$cat] ?? 0) + 1;
            }
            foreach ($ws as $w) {
                $words[$w] = ($words[$w] ?? 0) + 1;
                if ($isName) $names[$w] = 1;
                if ($cat && $clue) { $r = self::root($w); if (!isset($seen[$r])) { $seen[$r] = 1; $kinds[$r][$cat] = ($kinds[$r][$cat] ?? 0) + 1; } }
            }
        };
        // our listings: names (a name's words are names), their kinds, and what they say they offer
        $in = "'" . implode("','", self::PUBLIC) . "'";
        $states = [];
        try {
            $st = $pdo->query("SELECT e.name, e.category_id, c.name AS kind, LEFT(JSON_UNQUOTE(m.meta_value), 400) AS offer, JSON_UNQUOTE(s.meta_value) AS state
                                 FROM entities e LEFT JOIN categories c ON c.id = e.category_id
                                 LEFT JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'offerings'
                                 LEFT JOIN entity_metadata s ON s.entity_id = e.id AND s.meta_key = 'state'
                                WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ($in)");
            while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                $cat = $r['category_id'] !== null ? (int) $r['category_id'] : null;
                $add((string) $r['name'], $cat, false, false);   // a business's name counts by use (one could hold a slip, "Pizza Resturant"), never as a kind clue
                $add((string) $r['kind'] . ' ' . (string) $r['offer'], $cat, false);
                $sx = strtoupper(trim((string) $r['state'])); if (preg_match('/^[A-Z]{2}$/', $sx)) $states[$sx] = 1;
            }
        } catch (Throwable $e) { error_log('LocalWords listings: ' . $e->getMessage()); }
        // the place store: places named on pages we read, their own words and the heading they sit under (decisions/0157 §2)
        try {
            require_once __DIR__ . '/crawler/SourceIndex.php';
            $F = Database::t('source_facts'); $R = Database::t('reference_sources');
            $st = $pdo->query("SELECT f.name, f.category_id, f.kind_words, f.section, f.town FROM $F f LEFT JOIN $R r ON r.host = f.host WHERE COALESCE(r.status, 'read') <> 'ignore'");
            while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                $cat = $r['category_id'] !== null ? (int) $r['category_id'] : null;
                $add((string) $r['name'], $cat, false, false);
                $add(trim((string) $r['kind_words'] . ' ' . (string) $r['section']), $cat, false);
            }
        } catch (Throwable $e) { /* no place store yet */ }
        // towns in the states we serve, and the landmarks we show (never one held: decisions/0066)
        try {
            if ($states) {
                $q = $pdo->prepare('SELECT DISTINCT city FROM zip_coordinates WHERE state IN (' . implode(',', array_fill(0, count($states), '?')) . ')');
                $q->execute(array_keys($states));
                foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $c) $add((string) $c, null, true);
            }
        } catch (Throwable $e) {}
        try {
            require_once __DIR__ . '/Landmarks.php';
            foreach ($pdo->query('SELECT name FROM landmarks WHERE ' . Landmarks::visibleSql())->fetchAll(PDO::FETCH_COLUMN) as $n) $add((string) $n, null, true);
        } catch (Throwable $e) {}
        // a root's kinds: the six it sits with most, only roots seen with a kind twice or more
        foreach ($kinds as $r => $byCat) {
            if (array_sum($byCat) < 2) { unset($kinds[$r]); continue; }
            arsort($byCat); $kinds[$r] = array_slice($byCat, 0, 6, true);
        }
        // phrases: used together three times or more, with a kind
        $phrases = [];
        foreach ($pairs as $ph => $x) {
            if (($x['n'] ?? 0) < 3 || empty($x['k'])) continue;
            arsort($x['k']); $phrases[$ph] = array_slice($x['k'], 0, 6, true);
        }
        return ['words' => $words, 'names' => $names, 'kinds' => $kinds, 'phrases' => $phrases, 'built' => time()];
    }
}
