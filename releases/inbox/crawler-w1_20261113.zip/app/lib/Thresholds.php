<?php
// app/lib/Thresholds.php — thresholds and gates (decisions/0133): one table, in System Configuration → Thresholds & gates,
// each value named by what it gates. Some are numbers a director may tune here (stored in search_index_state as
// gate:<key>, with who changed it and when); some live with their feature (the AI switches, kept in ai_features, are
// changed from here through AiClient); some are standards, shown so the whole picture is in one place but changed only by
// a decision. Readers ask Thresholds::get() and fall back to the default when nothing is stored.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Thresholds
{
    /**
     * key => [what it gates, kind, default, min, max, step, unit, where it is read / what it means].
     * kind: 'number' (tuned here), 'switch' (an AI switch's lowest score, AiClient::SWITCHES), 'rule' (a standard: not tuned here).
     */
    public const GATES = [
        'listing_publishes' => ['A listing publishes', 'rule', 'The readiness rules: a real place (its own website, a registry, two sources, a government page we read, or one source scoring past the line below), a way to reach it with a street address, a category that fits, not listed already', null, null, null, '', 'AutoImport::evaluate (decisions/0076).'],
        'listing_one_source' => ['One source establishes a listing at', 'number', 50, 20, 100, 1, 'score', 'AutoImport::evaluate (decisions/0160 W1, Jason 2026-11-13: scoring decides). A find seen on one site publishes as unconfirmed when its score reaches this, and is checked continuously after. A page giving its street and phone scores about 60 (15 less outside our areas). A government page we read is enough by itself; OpenStreetMap is a lead, never a source.'],
        'guide_publish' => ['A guide publishes itself', 'switch', 70, 0, 100, 1, 'score', 'Below it a guide waits as a draft for a person. A name that may mark a protected site, or a closed business, always holds it back.'],
        'guide_ondemand_share' => ['Guides on demand: share of the day\'s AI allowance', 'number', 50, 0, 100, 5, '%', 'A searched place\'s first look is written only while today\'s on-demand spend stays under this share of the daily AI allowance (the AI monthly cap ÷ days in the month); past it, places wait for tomorrow, most asked first (decisions/0147). 0 turns Claude\'s writing off; places still get their journeys and what we hold.'],
        'guide_find_add' => ['Find it adds a listing', 'switch', 80, 0, 100, 1, 'score', 'And the listing still passes the readiness rules; below it the find waits in Review.'],
        'category_auto' => ['A category is set without a person', 'number', 80, 60, 99, 1, '% confidence', 'CategoryClassifier (decisions/0024). "Other" never is. Also the line for correcting listings already live.'],
        'category_review' => ['Below this, a person picks the category', 'number', 50, 20, 79, 1, '% confidence', 'CategoryClassifier. Between the two lines the readiness rules decide whether the best fit stands.'],
        'search_publish' => ['Search publishes what it learned (it leads the results)', 'number', 0.80, 0.50, 0.99, 0.01, 'relevance', 'Learning (decisions/0093). Must stay above "may also help".'],
        'search_may_help' => ['Search shows "May also help" under the results', 'number', 0.60, 0.30, 0.95, 0.01, 'relevance', 'Learning (decisions/0093). Below it a mapping keeps learning; one that was shown and falls below it retires.'],
        'heritage_cataloged' => ['A heritage fact is cataloged (and may be told)', 'rule', 'A primary record, or two independent sources, at least one of which our source register lets us keep and show', null, null, null, '', 'Heritage::extract (decisions/0133). The research brief never counts as a source.'],
        'ai_free_asks' => ['Free AI Assist asks a day (members with a paid plan)', 'number', 3, 0, 10, 1, 'asks', 'AiCredits. Then each ask uses a credit. Each ask costs us about 1 to 2 cents.'],
        'ai_cover' => ['The most a member\'s asks may cost in a month', 'number', 0.5, 0.1, 0.9, 0.05, 'share of what their plans pay', 'AiCredits: whatever the credits say, a member\'s AI cost stays under this share of their plans\' monthly price.'],
        'takedown_hours' => ['A takedown request is hidden within', 'rule', '24 hours (at once for a protected reason)', null, null, null, '', 'Takedowns (decisions/0133, the protected-information standard).'],
        'takedown_per_day' => ['Takedown requests one person may send a day', 'number', 5, 1, 20, 1, 'requests', 'Takedowns. Counted by a one-way daily hash, never who.'],
        'places_monthly' => ['Google checks a month (the most)', 'number', 1000, 0, 10000, 100, 'checks', 'The Google Places check (decisions/0085), about 3 cents each. Set here, it wins over the worker\'s GOOGLE_PLACES_MONTHLY on Railway; reset, the worker\'s number applies again. The site stops at 90% of it and spreads it over the month; 0 stops the checks (Jason, 2026-11-01).'],
        'audit_share' => ['Guides read in the quarterly audit', 'number', 0.1, 0.05, 0.5, 0.05, 'share of live guides (5 to 40)', 'GuideAudits.'],
    ];

    public static function get(PDO $pdo, string $key)
    {
        $g = self::GATES[$key] ?? null;
        if (!$g) return null;
        if ($g[1] === 'rule') return $g[2];
        if ($g[1] === 'switch') { require_once __DIR__ . '/AiClient.php'; return (int) AiClient::feature($pdo, $key)['per_day']; }
        $s = self::stored($pdo, $key);
        return $s !== null ? (is_float($g[2]) ? (float) $s['v'] : (int) $s['v']) : $g[2];
    }

    /** What's stored for a tuned gate: ['v', 'by', 'at'] or null (the default). */
    public static function stored(PDO $pdo, string $key): ?array
    {
        static $memo = [];
        if (array_key_exists($key, $memo)) return $memo[$key];
        try { require_once __DIR__ . '/SearchIndex.php'; $j = json_decode(SearchIndex::state($pdo, 'gate:' . $key), true); } catch (Throwable $e) { $j = null; }
        return $memo[$key] = is_array($j) && isset($j['v']) ? $j : null;
    }

    /** A director changes a gate. Returns the value kept. */
    public static function set(PDO $pdo, string $key, string $value, int $uid)
    {
        $g = self::GATES[$key] ?? throw new InvalidArgumentException('That isn\'t a gate.');
        if ($g[1] === 'rule') throw new InvalidArgumentException('That one is a standard: it changes only by a decision, not here.');
        $value = trim(str_replace(['%', ','], ['', '.'], $value));
        if (!is_numeric($value)) throw new InvalidArgumentException('Enter a number.');
        $v = is_float($g[2]) ? round((float) $value, 2) : (int) round((float) $value);
        if ($v < $g[3] || $v > $g[4]) throw new InvalidArgumentException($g[0] . ': between ' . $g[3] . ' and ' . $g[4] . '.');
        if ($key === 'category_auto' && $v <= (int) self::get($pdo, 'category_review')) throw new InvalidArgumentException('It has to stay above the review line (' . self::get($pdo, 'category_review') . ').');
        if ($key === 'category_review' && $v >= (int) self::get($pdo, 'category_auto')) throw new InvalidArgumentException('It has to stay below the auto line (' . self::get($pdo, 'category_auto') . ').');
        if ($key === 'search_publish' && $v <= (float) self::get($pdo, 'search_may_help')) throw new InvalidArgumentException('Publishing has to stay above "May also help" (' . self::get($pdo, 'search_may_help') . ').');
        if ($key === 'search_may_help' && $v >= (float) self::get($pdo, 'search_publish')) throw new InvalidArgumentException('"May also help" has to stay below publishing (' . self::get($pdo, 'search_publish') . ').');
        if ($g[1] === 'switch') {
            require_once __DIR__ . '/AiClient.php';
            $f = AiClient::feature($pdo, $key);
            AiClient::setFeature($pdo, $key, ['enabled' => $f['enabled'], 'min_score' => $v], $uid);
        } else {
            require_once __DIR__ . '/SearchIndex.php';
            SearchIndex::setState($pdo, 'gate:' . $key, json_encode(['v' => $v, 'by' => $uid, 'at' => date('Y-m-d H:i')]));
        }
        return $v;
    }

    /** Back to its default (a tuned gate). */
    public static function reset(PDO $pdo, string $key, int $uid): void
    {
        $g = self::GATES[$key] ?? throw new InvalidArgumentException('That isn\'t a gate.');
        if ($g[1] === 'rule') return;
        if ($g[1] === 'switch') { self::set($pdo, $key, (string) $g[2], $uid); return; }
        $pdo->prepare('DELETE FROM search_index_state WHERE k = ?')->execute(['gate:' . $key]);
    }
}
