<?php
// app/lib/CategoryClassifier.php — the weighted category classifier (decisions/0024): what kind of business a listing is,
// with a confidence. Real tokens (word boundaries: "spa" never matches inside "newspaper"), a light stemmer (stylist /
// styling / styles share a root) and stop words; each category is scored from its own name's distinctive words, by where
// they appear (what the business declares itself on its own site counts most, then its name, a registry's taxonomy and
// what it offers, then its description), and each group's weighted keyword dictionary says which industry the words
// point to. The confidence (0-99) is plain: the category's words all present and where, whether the group's dictionary
// agrees, and whether another category fits as well. Above the auto line it's set; below the review line a person picks;
// in between the readiness rules decide (AutoImport). "Other" (the fallback group) is never set on its own.
// Read by IntakeStager (new finds), AutoImport::evaluate and reclassifyTick (listings already live).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class CategoryClassifier
{
    /** Bump when the dictionaries or scoring change: listings already live are assessed again. */
    public const VERSION = 1;
    /** The fallback group (decisions/0024's group 24): never set automatically. */
    public const FALLBACK = ['Other'];
    /** Below this, the category a listing already has barely fits it: a sure fix may replace it without a person. */
    public const BARELY = 20;   // a partial match of its name (one word of two) is evidence enough to leave it to a person
    /** The least a correction must be sure of to be put to a person. */
    public const SUGGEST = 65;

    private const STOP = ['and', 'the', 'for', 'of', 'in', 'at', 'on', 'to', 'by', 'with', 'from', 'our', 'your', 'a', 'an', 'llc', 'inc', 'co', 'corp', 'ltd', 'pllc', 'pc', 'dba',
        'other', 'services', 'service', 'svc', 'store', 'stores', 'shop', 'new', 'used', 'sale', 'sales', 'retail', 'whls', 'nec', 'company', 'group', 'center', 'centers', 'ctr',
        'az', 'nm', 'arizona', 'mexico', 'llp', 'the', 'more'];
    /** Generic words a category name may have that say little on their own ("Health Services", "Family Care"). */
    private const GENERIC = ['family', 'care', 'home', 'homes', 'house', 'general', 'health', 'medical', 'county', 'state', 'program', 'organization',
        'information', 'agency', 'product', 'system', 'association', 'consultant', 'consulting', 'supply', 'supplies', 'equipment', 'specialty', 'office', 'facility',
        'mfr', 'wholesale', 'road', 'director', 'professional', 'public', 'local', 'community', 'national'];
    /** The same thing in other words, read before stemming. */
    private const SAME = ['dental' => 'dentist', 'dentistry' => 'dentist', 'optometric' => 'optometrist', 'optometry' => 'optometrist', 'chiropractic' => 'chiropractor',
        'orthodontic' => 'orthodontist', 'orthodontics' => 'orthodontist', 'podiatry' => 'podiatrist', 'pediatric' => 'pediatrician', 'veterinary' => 'veterinarian',
        'vet' => 'veterinarian', 'eatery' => 'restaurant', 'grill' => 'restaurant', 'diner' => 'restaurant', 'cafe' => 'restaurant', 'bistro' => 'restaurant', 'auto' => 'automotive',
        'drugstore' => 'pharmacy', 'motel' => 'motel', 'pantry' => 'bank', 'counselor' => 'counseling', 'attorney' => 'lawyer', 'attorneys' => 'lawyer', 'cpa' => 'accountant',
        'realtor' => 'real', 'realty' => 'real', 'church' => 'church', 'parish' => 'church', 'mortuary' => 'funeral', 'mortuaries' => 'funeral', 'mechanic' => 'repair', 'barbershop' => 'barber', 'hvac' => 'heating', 'print' => 'printer', 'printing' => 'printer'];

    /** Short forms in listing names ("Surgcl Ctr", "White Mntns"), read first. */
    private const ABBR = ['surgcl' => 'surgical', 'ctr' => 'center', 'ctrs' => 'centers', 'assn' => 'association', 'assoc' => 'association', 'mntns' => 'mountains', 'mtn' => 'mountain',
        'dept' => 'department', 'hosp' => 'hospital', 'med' => 'medical', 'svcs' => 'services', 'mgmt' => 'management', 'constr' => 'construction', 'elec' => 'electric',
        'mfg' => 'manufacturing', 'dist' => 'district', 'sch' => 'school', 'el' => 'elementary', 'elem' => 'elementary', 'hs' => 'high school', 'univ' => 'university', 'intl' => 'international',
        'natl' => 'national', 'cmnty' => 'community', 'comm' => 'community', 'hlth' => 'health', 'clnc' => 'clinic', 'phys' => 'physical', 'ther' => 'therapy', 'prop' => 'property', 'apts' => 'apartments', 'mhp' => 'mobile home park', 'rv park' => 'recreational vehicle park'];

    /** Two words that mean one thing, read first ("animal hospital" is a vet, not a hospital). */
    private const PHRASES = ['animal hospital' => 'veterinarian', 'animal clinic' => 'veterinarian', 'pet hospital' => 'veterinarian', 'urgent care' => 'urgentcare clinic',
        'real estate' => 'realestate', 'bed and breakfast' => 'bedandbreakfast inn', 'food bank' => 'foodbank', 'food pantry' => 'foodbank', 'credit union' => 'creditunion bank',
        'fire department' => 'firedepartment', 'post office' => 'postoffice', 'title company' => 'titlecompany escrow', 
        'car wash' => 'carwash', 'ice cream' => 'icecream', 'day care' => 'daycare', 'child care' => 'childcare', 'law firm' => 'lawyer', 'law office' => 'lawyer', 'rv' => 'recreational vehicle', 'hair salon' => 'beauty salon', 'hair studio' => 'beauty salon', 'nail salon' => 'nail salon manicuring', 'funeral home' => 'funeral', 'funeral chapel' => 'funeral', 'chapel mortuary' => 'funeral'];

    /** Each group's weighted keywords (decisions/0024 §1): word => weight (3 sure, 2 strong, 1 a hint). */
    public const DICTIONARIES = [
        'Agriculture & Farming' => ['farm' => 3, 'ranch' => 3, 'agricultur' => 3, 'livestock' => 3, 'cattle' => 3, 'feed' => 2, 'hay' => 2, 'orchard' => 3, 'nursery' => 1, 'crop' => 3, 'irrigation' => 2, 'tractor' => 2, 'grain' => 2, 'dairy' => 2, 'poultry' => 2, 'greenhouse' => 2, 'produce' => 1],
        'Automotive & Repair' => ['automotive' => 3, 'car' => 2, 'truck' => 1, 'tire' => 3, 'collision' => 3, 'body' => 1, 'muffler' => 3, 'transmission' => 3, 'brake' => 3, 'oil' => 1, 'lube' => 3, 'dealership' => 3, 'dealer' => 2, 'towing' => 2, 'wash' => 1, 'smog' => 3, 'vehicle' => 2, 'repair' => 1, 'motor' => 1, 'garage' => 2],
        'Construction & Contracting' => ['construction' => 3, 'contractor' => 3, 'builder' => 3, 'roofing' => 3, 'concrete' => 3, 'excavat' => 3, 'framing' => 3, 'drywall' => 3, 'paving' => 3, 'masonry' => 3, 'remodel' => 2, 'building' => 1, 'welding' => 2, 'grading' => 2, 'demolition' => 3],
        'Education & Childcare' => ['school' => 3, 'academy' => 2, 'college' => 3, 'university' => 3, 'preschool' => 3, 'daycare' => 3, 'childcare' => 3, 'tutor' => 3, 'learning' => 2, 'education' => 3, 'student' => 2, 'kindergarten' => 3, 'montessori' => 3, 'classes' => 1, 'training' => 1, 'library' => 2],
        'Entertainment & Recreation' => ['entertainment' => 3, 'recreation' => 3, 'theater' => 3, 'theatre' => 3, 'cinema' => 3, 'museum' => 2, 'golf' => 3, 'bowling' => 3, 'arcade' => 3, 'park' => 1, 'music' => 2, 'concert' => 2, 'gym' => 2, 'fitness' => 2, 'outfitter' => 2, 'tour' => 1, 'casino' => 3, 'rodeo' => 3, 'art' => 1, 'gallery' => 2, 'dance' => 2],
        'Financial & Insurance' => ['bank' => 2, 'credit' => 2, 'union' => 1, 'insurance' => 3, 'loan' => 3, 'mortgage' => 3, 'financial' => 3, 'invest' => 3, 'tax' => 2, 'accountant' => 2, 'bookkeep' => 3, 'wealth' => 3, 'pawn' => 2, 'payday' => 3, 'atm' => 2],
        'Food & Dining' => ['restaurant' => 3, 'pizza' => 3, 'burger' => 3, 'taco' => 3, 'bakery' => 3, 'coffee' => 3, 'espresso' => 3, 'bar' => 1, 'pub' => 2, 'brewery' => 3, 'catering' => 3, 'kitchen' => 1, 'food' => 2, 'dining' => 3, 'mexican' => 2, 'bbq' => 3, 'barbecue' => 3, 'steakhouse' => 3, 'donut' => 3, 'ice' => 1, 'cream' => 1, 'deli' => 3, 'sandwich' => 3, 'breakfast' => 2, 'lunch' => 2, 'dinner' => 2, 'menu' => 2],
        'Government & Public Services' => ['county' => 1, 'city' => 1, 'town' => 1, 'municipal' => 3, 'government' => 3, 'department' => 2, 'court' => 2, 'sheriff' => 3, 'police' => 3, 'fire' => 2, 'district' => 2, 'agency' => 1, 'clerk' => 3, 'assessor' => 3, 'recorder' => 3, 'post' => 1, 'usps' => 3, 'federal' => 2, 'tribal' => 2, 'chapter' => 1],
        'Health & Medical' => ['clinic' => 3, 'hospital' => 3, 'medical' => 2, 'physician' => 3, 'doctor' => 3, 'dentist' => 3, 'pharmacy' => 3, 'therapy' => 2, 'therapist' => 3, 'health' => 1, 'nurse' => 3, 'nursing' => 3, 'optometrist' => 3, 'chiropractor' => 3, 'urgent' => 2, 'pediatrician' => 3, 'counseling' => 2, 'behavioral' => 3, 'rehab' => 3, 'hospice' => 3, 'surgery' => 3, 'md' => 2, 'dds' => 3, 'np' => 1],
        'Home Services & Repair' => ['plumbing' => 3, 'plumber' => 3, 'electrician' => 3, 'electrical' => 2, 'heating' => 3, 'cooling' => 3, 'air' => 1, 'pest' => 3, 'landscap' => 3, 'lawn' => 3, 'cleaning' => 2, 'maid' => 3, 'janitorial' => 2, 'handyman' => 3, 'carpet' => 2, 'window' => 1, 'appliance' => 2, 'locksmith' => 3, 'septic' => 3, 'pool' => 2, 'tree' => 1, 'painting' => 2, 'flooring' => 2],
        'Hospitality & Lodging' => ['hotel' => 3, 'motel' => 3, 'inn' => 3, 'lodge' => 3, 'lodging' => 3, 'resort' => 3, 'cabin' => 2, 'rv' => 3, 'campground' => 3, 'camping' => 2, 'bed' => 1, 'breakfast' => 1, 'suite' => 2, 'vacation' => 2, 'rental' => 1, 'hostel' => 3],
        'Industrial & Manufacturing' => ['manufactur' => 3, 'industrial' => 3, 'fabrication' => 3, 'machine' => 2, 'machining' => 3, 'mill' => 2, 'plant' => 1, 'factory' => 3, 'metal' => 2, 'steel' => 2, 'lumber' => 2, 'sawmill' => 3, 'mining' => 3, 'mine' => 2, 'quarry' => 3, 'chemical' => 2, 'power' => 1],
        'Legal Services' => ['law' => 3, 'lawyer' => 3, 'legal' => 3, 'notary' => 2, 'paralegal' => 3, 'litigation' => 3, 'bail' => 3, 'bond' => 1, 'immigration' => 2, 'divorce' => 2, 'injury' => 2, 'estate' => 1, 'probate' => 3],
        'Non-Profit & Community' => ['nonprofit' => 3, 'foundation' => 2, 'charity' => 3, 'volunteer' => 3, 'shelter' => 2, 'food' => 1, 'bank' => 1, 'community' => 2, 'club' => 2, 'lodge' => 1, 'legion' => 3, 'vfw' => 3, 'rotary' => 3, 'association' => 2, 'society' => 2, 'outreach' => 3, 'mission' => 2, 'coalition' => 3, 'alliance' => 2],
        'Pet & Veterinary' => ['veterinarian' => 3, 'animal' => 3, 'pet' => 3, 'grooming' => 2, 'kennel' => 3, 'boarding' => 2, 'dog' => 3, 'cat' => 2, 'feline' => 3, 'canine' => 3, 'equine' => 3, 'horse' => 2],
        'Professional Services' => ['consulting' => 2, 'consultant' => 2, 'marketing' => 3, 'advertising' => 3, 'design' => 2, 'printing' => 3, 'photography' => 3, 'photographer' => 3, 'staffing' => 3, 'engineering' => 3, 'architect' => 3, 'survey' => 2, 'accountant' => 2, 'management' => 1, 'agency' => 1, 'studio' => 1, 'sign' => 2, 'courier' => 2],
        'Real Estate' => ['real' => 2, 'estate' => 2, 'property' => 3, 'propertie' => 3, 'apartment' => 3, 'leasing' => 3, 'realtor' => 3, 'broker' => 2, 'homes' => 1, 'title' => 2, 'escrow' => 3, 'appraisal' => 3, 'storage' => 2, 'land' => 1],
        'Religious & Faith-Based' => ['church' => 3, 'ministry' => 3, 'ministrie' => 3, 'temple' => 3, 'mosque' => 3, 'synagogue' => 3, 'baptist' => 3, 'methodist' => 3, 'catholic' => 3, 'lutheran' => 3, 'presbyterian' => 3, 'christian' => 2, 'faith' => 3, 'bible' => 3, 'worship' => 3, 'congregation' => 3, 'parish' => 3, 'saint' => 1, 'lds' => 3, 'latter' => 2],
        'Retail & Shopping' => ['boutique' => 3, 'mart' => 2, 'market' => 1, 'grocery' => 3, 'supermarket' => 3, 'hardware' => 3, 'clothing' => 3, 'apparel' => 3, 'gift' => 3, 'jewelry' => 3, 'furniture' => 3, 'florist' => 3, 'flower' => 2, 'antique' => 3, 'thrift' => 3, 'pawn' => 1, 'convenience' => 3, 'liquor' => 3, 'outlet' => 2, 'feed' => 1, 'trading' => 2, 'post' => 1,
            'dollar' => 3, 'discount' => 2, 'variety' => 3, 'toy' => 2, 'household' => 1, 'decor' => 2, 'merchandise' => 2, 'goods' => 1, 'shopping' => 2, 'brand' => 1, 'affordable' => 1, 'essentials' => 1, 'seasonal' => 1],
        'Technology & IT' => ['computer' => 3, 'software' => 3, 'it' => 1, 'tech' => 2, 'technology' => 3, 'network' => 2, 'internet' => 3, 'web' => 2, 'wireless' => 3, 'cellular' => 3, 'phone' => 1, 'repair' => 1, 'data' => 2, 'cyber' => 3, 'electronics' => 2],
        'Transportation & Logistics' => ['trucking' => 3, 'freight' => 3, 'logistics' => 3, 'shipping' => 3, 'transport' => 3, 'transportation' => 3, 'moving' => 3, 'taxi' => 3, 'shuttle' => 3, 'bus' => 2, 'airport' => 3, 'aviation' => 3, 'delivery' => 2, 'courier' => 2, 'rail' => 2, 'airline' => 3],
        'Utilities' => ['utility' => 3, 'utilitie' => 3, 'electric' => 2, 'water' => 2, 'gas' => 1, 'propane' => 3, 'sewer' => 3, 'waste' => 3, 'trash' => 3, 'recycling' => 3, 'garbage' => 3, 'sanitation' => 3, 'refuse' => 2, 'dumpster' => 3, 'landfill' => 3, 'disposal' => 3, 'hauling' => 2, 'environmental' => 1, 'solar' => 2, 'energy' => 3, 'cooperative' => 2, 'coop' => 2, 'broadband' => 2],
    ];

    /** A word's root: plural, -ing, -ed and -ist endings fold together (stylist / styling / styles). */
    public static function stem(string $w): string
    {
        $w = self::SAME[$w] ?? $w;
        if (strlen($w) > 4 && str_ends_with($w, 'ies')) return substr($w, 0, -3) . 'y';
        if (strlen($w) > 5 && str_ends_with($w, 'ing')) return substr($w, 0, -3);
        if (strlen($w) > 4 && str_ends_with($w, 'ed') && !str_ends_with($w, 'eed')) return substr($w, 0, -2);
        if (strlen($w) > 6 && str_ends_with($w, 'ists')) return substr($w, 0, -4);
        if (strlen($w) > 5 && str_ends_with($w, 'ist')) return substr($w, 0, -3);
        if (strlen($w) > 4 && preg_match('/(ch|sh|x|ss|z)es$/', $w)) return substr($w, 0, -2);   // churches, boxes, glasses
        if (strlen($w) > 4 && preg_match('/(ss|us|is)$/', $w)) return $w;
        if (strlen($w) > 3 && str_ends_with($w, 's')) return substr($w, 0, -1);
        return $w;
    }

    /** Real tokens: word boundaries, stop words out, stemmed. CamelCase ("GeneralContractor") splits. */
    public static function tokens(string $text): array
    {
        $text = strtolower((string) preg_replace('/(?<=[a-z])(?=[A-Z])/', ' ', $text));
        $text = ' ' . implode(' ', array_map(fn ($w) => self::ABBR[$w] ?? $w, preg_split('/[^a-z0-9]+/', $text))) . ' ';
        foreach (self::PHRASES as $a => $b) $text = str_replace(' ' . $a . ' ', ' ' . $b . ' ', $text);
        $out = [];
        foreach (preg_split('/[^a-z0-9]+/', $text) as $w) {
            if (strlen($w) < 2 || in_array($w, self::STOP, true) || ctype_digit($w)) continue;
            $out[self::stem($w)] = true;
        }
        return $out;
    }

    /**
     * The categories that fit, best first: [['id', 'name', 'group', 'confidence' 0-99, 'why']]. $c: a candidate or a listing
     * as ['name', 'what' => ['offerings' => [], 'types' => [], 'description' => '']]. $cats: rows with id, name, group_name.
     * $groups false: its own words only, no industry agreement (how well the category a listing has fits it).
     */
    public static function classify(array $c, array $cats, int $limit = 3, bool $groups = true): array
    {
        $fields = [
            'kind' => [self::tokens(implode(' ', (array) ($c['what']['types'] ?? []))), 'what it calls itself on its site'],
            'name' => [self::tokens((string) ($c['name'] ?? '')), 'its name'],
            'offer' => [self::tokens(implode(' ', (array) ($c['what']['offerings'] ?? []))), 'what it offers'],
            'desc' => [self::tokens((string) ($c['what']['description'] ?? '')), 'its description'],
        ];
        $fw = ['kind' => 3, 'name' => 2, 'offer' => 1.5, 'desc' => 1];
        // the groups the words point to (each dictionary word counted once, in the best field it appears in)
        $group = [];
        foreach (self::DICTIONARIES as $g => $dict) {
            $s = 0.0;
            foreach ($dict as $w => $wt) {
                $st = self::stem($w); $best = 0;
                foreach ($fw as $f => $m) if (isset($fields[$f][0][$st]) || isset($fields[$f][0][$w])) $best = max($best, $m);
                $s += $wt * $best;
            }
            if ($s > 0) $group[$g] = $s;
        }
        // the same, from everything but its name: an incidental word in a name ("Red Roof Inn") is believed when the rest agrees
        $groupElse = [];
        foreach (self::DICTIONARIES as $g => $dict) {
            $s2 = 0.0;
            foreach ($dict as $w => $wt) { $st = self::stem($w); foreach (['kind', 'offer', 'desc'] as $f) if (isset($fields[$f][0][$st]) || isset($fields[$f][0][$w])) { $s2 += $wt; break; } }
            if ($s2 > 0) $groupElse[$g] = $s2;
        }
        arsort($groupElse);
        $elseTop = (string) array_key_first($groupElse);
        $elseNext = (float) (array_values($groupElse)[1] ?? 0);
        $agrees = fn (string $g) => $g !== '' && $g === $elseTop && ($groupElse[$g] ?? 0) >= 3 && ($groupElse[$g] ?? 0) >= 1.5 * $elseNext;   // the rest of what it says points clearly to this industry
        arsort($group);
        $topGroup = (string) array_key_first($group);
        $gTop = (float) ($group[$topGroup] ?? 0); $gNext = (float) (array_values($group)[1] ?? 0);

        $df = self::wordFrequency($cats);   // how many category names share each word
        $scored = [];
        foreach ($cats as $cat) {
            $words = array_keys(self::tokens((string) $cat['name']));
            $need = array_values(array_filter($words, fn ($w) => !in_array($w, self::GENERIC, true) && !in_array(self::stem($w), self::GENERIC, true)));
            $general = !$need;
            $need = $need ?: $words;   // a name made only of general words needs all of them
            if (!$need) continue;
            $where = [];
            foreach ($need as $w) {
                $in = '';
                foreach (['kind', 'name', 'offer', 'desc'] as $f) if (isset($fields[$f][0][$w])) { $in = $f; break; }
                $where[$w] = $in;
            }
            $found = array_filter($where);
            if (!$found) continue;
            $full = count($found) === count($need);
            // a full match is only as sure as its weakest word: "Language Schools" from "school" in the name and "languages" in the description is a description match
            $rank = ['kind' => 4, 'name' => 3, 'offer' => 2, 'desc' => 1];
            $vals = array_values($found); usort($vals, fn ($a, $b) => $rank[$a] <=> $rank[$b]);
            $best = $full ? $vals[0] : end($vals);
            $conf = $full ? ['kind' => 70, 'name' => 65, 'offer' => 55, 'desc' => 35][$best] : 15 + 20 * count($found) / count($need);
            $why = [($full ? 'all of "' . $cat['name'] . '" in ' : 'part of "' . $cat['name'] . '" in ') . $fields[$best][1]];
            $cap = 99;
            if ($general) { $cap = 50; $why[] = 'its name is only general words'; }
            elseif (count($need) === 1 && $best === 'name' && !$agrees((string) ($cat['group_name'] ?? ''))) { $cap = 70; $why[] = 'one word of its name ("' . $need[0] . '"), which may be incidental ("Red Roof Inn")'; }
            elseif (count($need) === 1 && ($df[$need[0]] ?? 0) >= 3 && $best !== 'kind' && !$agrees((string) ($cat['group_name'] ?? ''))) { $cap = 70; $why[] = '"' . $need[0] . '" is in ' . $df[$need[0]] . ' categories\' names'; }
            $g = (string) ($cat['group_name'] ?? '');
            if (!$groups) {}   // how well its own words fit, nothing else (the category a listing already has)
            elseif ($g !== '' && $g === $topGroup && $gTop >= 3) { $conf += 20; $why[] = 'its words point to ' . $g; }
            elseif ($g !== '' && $topGroup !== '' && $gTop >= 6 && ($group[$g] ?? 0) * 2 < $gTop) { $conf -= 20; $why[] = 'its words point to ' . $topGroup . ' instead'; }
            $scored[] = ['id' => (int) $cat['id'], 'name' => (string) $cat['name'], 'group' => $g, 'confidence' => min($cap, $conf), 'full' => $full, 'n' => count($need), 'why' => $why];
        }
        // the fuller, more specific match first; then: another category fitting as well lowers the confidence
        usort($scored, fn ($a, $b) => [$b['confidence'], $b['n']] <=> [$a['confidence'], $a['n']]);
        if (count($scored) > 1 && $scored[1]['confidence'] >= $scored[0]['confidence'] - 5 && $scored[1]['n'] >= $scored[0]['n'] && $scored[1]['group'] !== $scored[0]['group']) {
            $scored[0]['confidence'] -= 15; $scored[0]['why'][] = '"' . $scored[1]['name'] . '" fits as well';
        }
        foreach ($scored as &$s) { $s['confidence'] = (int) max(0, min(99, round($s['confidence']))); unset($s['full'], $s['n']); }
        unset($s);
        usort($scored, fn ($a, $b) => $b['confidence'] <=> $a['confidence']);
        return array_slice($scored, 0, $limit);
    }

    /** Each word's number of category names it appears in (a word in many says little on its own). */
    private static function wordFrequency(array $cats): array
    {
        static $memo = [];
        $k = count($cats) . ':' . ($cats[0]['id'] ?? 0);
        if (isset($memo[$k])) return $memo[$k];
        $df = [];
        foreach ($cats as $cat) foreach (self::tokens((string) $cat['name']) as $w => $_) $df[$w] = ($df[$w] ?? 0) + 1;
        return $memo[$k] = $df;
    }

    /** The auto line and the review line (System Configuration → Thresholds & gates), in percent. */
    public static function lines(PDO $pdo): array
    {
        require_once __DIR__ . '/Thresholds.php';
        return [(int) Thresholds::get($pdo, 'category_auto'), (int) Thresholds::get($pdo, 'category_review')];
    }

    /** May this be set without a person: above the auto line and not the fallback group. */
    public static function sure(PDO $pdo, ?array $best): bool
    {
        return $best && $best['confidence'] >= self::lines($pdo)[0] && !in_array($best['group'], self::FALLBACK, true);
    }

    // ---- listings already live (decisions/0024 §4): a data correction, kept with an Undo --------------------------------

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM category_changes LIMIT 0'); $ok = true; } catch (Throwable $e) { $ok = false; } }
        return $ok;
    }

    /** A listing as the classifier reads it: its name, description and offerings. */
    public static function listing(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare("SELECT e.id, e.name, e.category_id, (SELECT meta_value FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'description') AS d,
                                    (SELECT meta_value FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'offerings') AS o FROM entities e WHERE e.id = ?");
        $st->execute([$id]); $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $d = json_decode((string) $r['d'], true); $o = json_decode((string) $r['o'], true);
        return ['id' => (int) $r['id'], 'category_id' => (int) $r['category_id'], 'name' => (string) $r['name'], 'what' => ['description' => is_string($d) ? $d : '', 'offerings' => is_array($o) ? $o : [], 'types' => []]];
    }

    /**
     * The job: assesses listings the crawler categorized (never one an owner or our team set or locked, never a claimed
     * one), each once per VERSION. A sure fix (at the auto line, not "Other") where the category it has doesn't fit (under
     * the review line) is applied and logged; one above the review line waits for a person. Returns [checked, applied, suggested].
     */
    public static function reclassifyTick(PDO $pdo, int $n = 200): array
    {
        if (!self::ready($pdo)) return [0, 0, 0];
        require_once __DIR__ . '/CrawlerIngest.php';
        [$auto, $review] = self::lines($pdo);
        $cats = self::categories($pdo); $byId = [];
        foreach ($cats as $c) $byId[(int) $c['id']] = $c;
        $ids = $pdo->query("SELECT e.id FROM entities e
                              JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'category' AND m.source_type = 'ai_crawler' AND m.is_locked = 0
                         LEFT JOIN entity_metadata k ON k.entity_id = e.id AND k.meta_key = 'category_checked'
                             WHERE e.is_suppressed = 0 AND e.owner_user_id IS NULL AND e.status = 'unclaimed' AND (k.id IS NULL OR k.meta_value <> '" . self::VERSION . "')
                             ORDER BY e.id LIMIT " . max(1, min(1000, $n)))->fetchAll(PDO::FETCH_COLUMN);
        $applied = 0; $suggested = 0;
        foreach ($ids as $id) {
            $l = self::listing($pdo, (int) $id); if (!$l) continue;
            CrawlerIngest::upsertMetadataKey($pdo, (int) $id, 'category_checked', self::VERSION);
            $top = self::classify($l, $cats, 1)[0] ?? null;
            if (!$top || $top['id'] === $l['category_id'] || in_array($top['group'], self::FALLBACK, true) || $top['confidence'] < $review) continue;
            $cur = $byId[$l['category_id']] ?? null;
            $curConf = $cur ? (int) (self::classify($l, [$cur], 1, false)[0]['confidence'] ?? 0) : 0;
            if ($curConf >= $review) continue;   // the category it has fits well enough: left alone
            $kept = $pdo->prepare("SELECT 1 FROM category_changes WHERE entity_id = ? AND new_category_id = ? AND status IN ('kept', 'undone') LIMIT 1");
            $kept->execute([(int) $id, $top['id']]);
            if ($kept->fetchColumn()) continue;   // a person said no to this one before
            $other = !$cur || $cur['group_name'] !== $top['group'];   // another industry, not a refinement within its group
            $weak = (bool) preg_grep('/incidental|only general words|categories\' names/', $top['why']);   // one common word decides nothing on its own
            if (!$other || $weak || $top['confidence'] < self::SUGGEST) continue;   // not worth a person's look
            $sure = $top['confidence'] >= $auto && $curConf < self::BARELY;   // by itself only when what it has barely fits and is another industry; a refinement within its group goes to a person
            $pdo->prepare('INSERT INTO category_changes (entity_id, old_category_id, new_category_id, confidence, old_confidence, why, status) VALUES (?, ?, ?, ?, ?, ?, ?)')
                ->execute([(int) $id, $l['category_id'] ?: null, $top['id'], $top['confidence'], $curConf, mb_substr(implode('; ', $top['why']), 0, 500), $sure ? 'applied' : 'suggested']);
            if ($sure) { self::setCategory($pdo, (int) $id, $top['id']); $applied++; } else $suggested++;
        }
        return [count($ids), $applied, $suggested];
    }

    /** A person decides on a change: take (apply a suggestion), keep (the old category stays), undo (put back what it was). */
    public static function decide(PDO $pdo, int $changeId, string $what, int $by): void
    {
        $st = $pdo->prepare('SELECT * FROM category_changes WHERE id = ?'); $st->execute([$changeId]);
        $ch = $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('That change isn\'t here.');
        if ($what === 'take' && $ch['status'] === 'suggested') { self::setCategory($pdo, (int) $ch['entity_id'], (int) $ch['new_category_id']); $status = 'taken'; }
        elseif ($what === 'keep' && $ch['status'] === 'suggested') $status = 'kept';
        elseif ($what === 'undo' && in_array($ch['status'], ['applied', 'taken'], true)) { if ($ch['old_category_id']) self::setCategory($pdo, (int) $ch['entity_id'], (int) $ch['old_category_id']); $status = 'undone'; }
        else throw new InvalidArgumentException('That was decided already.');
        $pdo->prepare('UPDATE category_changes SET status = ?, decided_by = ?, decided_at = NOW() WHERE id = ?')->execute([$status, $by ?: null, $changeId]);
    }

    /** Sets a listing's category the way the crawler does (its text too), never over one a person locked; reindexes it. */
    private static function setCategory(PDO $pdo, int $id, int $catId): void
    {
        $st = $pdo->prepare('SELECT name FROM categories WHERE id = ?'); $st->execute([$catId]); $name = (string) $st->fetchColumn();
        if ($name === '') return;
        $pdo->prepare("UPDATE entities SET category_id = ? WHERE id = ? AND owner_user_id IS NULL")->execute([$catId, $id]);
        require_once __DIR__ . '/CrawlerIngest.php';
        CrawlerIngest::upsertMetadataKey($pdo, $id, 'category', $name);   // respects a lock
        try { require_once __DIR__ . '/SearchIndex.php'; if (SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, [$id]); } catch (Throwable $e) {}
    }

    /** The categories (subcategories with their group's name), read once a request. */
    public static function categories(PDO $pdo): array
    {
        static $memo = null;
        if ($memo === null) $memo = $pdo->query('SELECT c.id, c.name, g.name AS group_name FROM categories c JOIN categories g ON g.id = c.parent_id WHERE c.is_active = 1 ORDER BY c.id')->fetchAll(PDO::FETCH_ASSOC);
        return $memo;
    }
}
