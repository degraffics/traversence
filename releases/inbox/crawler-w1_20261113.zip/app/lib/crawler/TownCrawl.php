<?php
// app/lib/crawler/TownCrawl.php — listings on demand (decisions/0149): a town someone searched for, outside our
// regions (Dana Point, CA), is built out like one of ours. Its guide queues crawl jobs for it: places to eat, to stay,
// things to do, shops and health care. The off-site worker takes them with the coverage jobs (they lead: interest is
// the queue), finds the places on OpenStreetMap and each one's own website, and sends them back through the same
// intake as every crawl (IntakeStager, decisions/0044): a place seen on two independent sources publishes itself; the
// rest wait in Review. Never a landmark or attraction from OpenStreetMap (decisions/0065), only businesses. Free.
// Job ids from ID_FROM up are these, so the worker and its endpoints need no change.
declare(strict_types=1);

require_once __DIR__ . '/../Database.php';

final class TownCrawl
{
    public const ID_FROM = 800000000;
    /** group => [what it is, OpenStreetMap filters, offering words, top category id (Guides::PICKS)] */
    public const KINDS = [
        'town:eat' => ['Places to eat', ['nwr["amenity"~"^(restaurant|cafe|fast_food|bar|pub|ice_cream|biergarten)$"]', 'nwr["shop"~"^(bakery|deli|coffee)$"]'], ['Restaurant'], 7],
        'town:stay' => ['Places to stay', ['nwr["tourism"~"^(hotel|motel|guest_house|hostel|apartment|camp_site|caravan_site)$"]'], ['Hotel'], 11],
        'town:do' => ['Things to do', ['nwr["tourism"~"^(museum|gallery|zoo|aquarium|theme_park)$"]', 'nwr["amenity"~"^(theatre|cinema|arts_centre|boat_rental|bicycle_rental)$"]',
                       'nwr["leisure"~"^(golf_course|marina|water_park|sports_centre|bowling_alley|miniature_golf)$"]', 'nwr["shop"~"^(surf|outdoor|dive|bicycle)$"]', 'nwr["office"="guide"]'], ['Recreation'], 5],
        'town:shop' => ['Shops', ['nwr["shop"~"^(gift|art|craft|books|antiques|clothes|boutique|jewelry|souvenir|farm|second_hand|interior_decoration|frame)$"]', 'nwr["amenity"="marketplace"]'], ['Gift shop'], 19],
        'town:care' => ['Health care', ['nwr["amenity"~"^(hospital|clinic|doctors|pharmacy|dentist)$"]', 'nwr["healthcare"~"^(hospital|clinic|urgent_care)$"]'], ['Clinic'], 9],
        // everything else OpenStreetMap offers as a lead (Jason, 2026-11-10: "Crawler should use osm as lead source for
        // anything it offers not just listings"); the top category by name where there's no id. Never shelters or safe
        // houses (amenity=social_facility): a person links those.
        'town:essentials' => ['Groceries & gas', ['nwr["shop"~"^(supermarket|grocery|convenience|greengrocer|butcher)$"]', 'nwr["amenity"="fuel"]'], ['Grocery store'], 'Food'],
        'town:services' => ['Services', ['nwr["amenity"~"^(bank|post_office|car_wash|veterinary)$"]', 'nwr["leisure"="fitness_centre"]',
                            'nwr["shop"~"^(hairdresser|beauty|car_repair|tyres|hardware|doityourself|laundry|dry_cleaning|pet|mobile_phone|optician|bicycle|car)$"]'], ['Service'], 'Services'],
        'town:civic' => ['Public services', ['nwr["amenity"~"^(library|townhall|community_centre|police|fire_station|courthouse)$"]'], ['Public office'], 'Government'],
        'town:faith' => ['Places of worship', ['nwr["amenity"="place_of_worship"]'], ['Church'], 'Religio'],
        'town:camp' => ['Campgrounds & RV parks', ['nwr["tourism"~"^(camp_site|caravan_site)$"]'], ['Campground'], 11],
    ];
    /** Bumped when KINDS grows: towns already built out get the new kinds once (addKinds). */
    private const KINDS_VERSION = 2;
    private const MAX_ATTEMPTS = 3;
    private const LEASE_MINUTES = 20;
    private const PARTIAL_MAX = 4;

    private static ?bool $ready = null;

    public static function ready(PDO $pdo): bool
    {
        if (self::$ready !== null) return self::$ready;
        try { $pdo->query('SELECT 1 FROM town_crawl_jobs LIMIT 0'); return self::$ready = true; } catch (Throwable) { return self::$ready = false; }
    }

    public static function mine(int $jobId): bool { return $jobId >= self::ID_FROM; }

    /** Queues a town's build-out (once; a failed kind gets another round). Interest sets the order: more asks, sooner. */
    public static function queue(PDO $pdo, string $key, int $asks = 1): int
    {
        if (!self::ready($pdo) || !preg_match('/^town:(\d+)$/', $key, $m)) return 0;
        $n = 0;
        $ins = $pdo->prepare("INSERT INTO town_crawl_jobs (anchor_id, place_key, group_label, priority, status, created_at, updated_at) VALUES (?, ?, ?, ?, 'queued', NOW(), NOW())
                              ON DUPLICATE KEY UPDATE priority = GREATEST(priority, VALUES(priority)), status = IF(status = 'failed', 'queued', status), attempts = IF(status = 'queued', 0, attempts), updated_at = NOW()");
        foreach (array_keys(self::KINDS) as $g) { $ins->execute([(int) $m[1], $key, $g, 1000 + $asks]); $n++; }
        return $n;
    }

    /**
     * A search for a kind of business found nothing of ours within reach of a town (2026-11-10): the town is built out
     * like one a guide was asked for (its places to eat, stay, do, shop, health care), so the next search there finds real
     * listings. Once a town every 30 days, at most DAILY towns a day. Returns the place key queued, or ''.
     */
    private const DAILY = 25;

    public static function fromSearch(PDO $pdo, string $city, string $state, string $want = ''): string
    {
        if (!self::ready($pdo)) return '';
        require_once __DIR__ . '/../PageCache.php';
        $ck = 'tc:search:' . md5(mb_strtolower(trim($city)) . '|' . strtoupper(trim($state)));
        if (PageCache::get($pdo, $ck)) return '';
        $day = 'tc:search:day:' . date('Ymd');
        $n = (int) (PageCache::get($pdo, $day) ?: 0);
        if ($n >= self::DAILY) return '';
        require_once __DIR__ . '/../OnDemand.php';
        $key = (string) (OnDemand::townFor($pdo, $city, $state) ?? '');
        PageCache::put($pdo, $ck, 30 * 86400, 1);
        if ($key === '') return '';
        // built out the first time it's searched; again once its build-out is REBUILD_DAYS old (review E21: it was built once
        // ever, so a town searched again later never got another look); and the kind searched for, when it isn't one of KINDS
        $st = $pdo->prepare("SELECT COUNT(*) n, SUM(status IN ('done', 'failed') AND updated_at < NOW() - INTERVAL " . self::REBUILD_DAYS . " DAY) stale FROM town_crawl_jobs WHERE place_key = ?"); $st->execute([$key]);
        $j = $st->fetch(PDO::FETCH_ASSOC) ?: ['n' => 0, 'stale' => 0];
        if ((int) $j['n'] === 0) { self::queue($pdo, $key, 1); PageCache::put($pdo, $day, 2 * 86400, $n + 1); }
        elseif ((int) $j['stale'] > 0) { self::rebuild($pdo, $key); PageCache::put($pdo, $day, 2 * 86400, $n + 1); }
        if ($want !== '') self::want($pdo, $key, $want);
        return $key;
    }

    private const REBUILD_DAYS = 30;
    /** The kinds a search can add to a town (OpenPlaces' business kinds), beyond KINDS. */
    private const WANTS = ['pizza', 'coffee', 'food', 'lodging', 'fuel', 'grocery', 'pharmacy', 'hospital', 'clinic', 'storage', 'auto', 'hardware', 'laundry'];

    /** A town searched again after REBUILD_DAYS: its finished kinds are looked at again (new places open; old leads retried). */
    public static function rebuild(PDO $pdo, string $key): int
    {
        $st = $pdo->prepare("UPDATE town_crawl_jobs SET status = 'queued', attempts = 0, lease_until = NULL, updated_at = NOW() WHERE place_key = ? AND status IN ('done', 'failed') AND updated_at < NOW() - INTERVAL " . self::REBUILD_DAYS . " DAY");
        $st->execute([$key]);
        return $st->rowCount();
    }

    /** The kind someone searched for in a town ("storage", "auto"), when its build-out doesn't cover it: one job of its own. */
    public static function want(PDO $pdo, string $key, string $kind): void
    {
        if (!in_array($kind, self::WANTS, true) || !preg_match('/^town:(\d+)$/', $key, $m)) return;
        $pdo->prepare("INSERT INTO town_crawl_jobs (anchor_id, place_key, group_label, priority, status, created_at, updated_at) VALUES (?, ?, ?, 1100, 'queued', NOW(), NOW())
                       ON DUPLICATE KEY UPDATE status = IF(status IN ('done', 'failed') AND updated_at < NOW() - INTERVAL " . self::REBUILD_DAYS . " DAY, 'queued', status), attempts = IF(status = 'queued', 0, attempts), updated_at = updated_at")
            ->execute([(int) $m[1], $key, 'want:' . $kind]);
    }

    /** Towns already built out get kinds added since (once per KINDS_VERSION), at the back of the queue. */
    public static function addKinds(PDO $pdo): int
    {
        require_once __DIR__ . '/../PageCache.php';
        if (!self::ready($pdo) || PageCache::get($pdo, 'tc:kinds:' . self::KINDS_VERSION)) return 0;
        $n = 0;
        try { foreach ($pdo->query('SELECT DISTINCT place_key FROM town_crawl_jobs')->fetchAll(PDO::FETCH_COLUMN) as $key) $n += self::queue($pdo, (string) $key, 0); } catch (Throwable $e) { error_log('town kinds: ' . $e->getMessage()); return 0; }
        PageCache::put($pdo, 'tc:kinds:' . self::KINDS_VERSION, 3650 * 86400, 1);
        return $n;
    }

    /** The next town jobs for the worker, described as CrawlQueue describes a coverage job. */
    public static function lease(PDO $pdo, int $limit): array
    {
        if (!self::ready($pdo) || $limit < 1) return [];
        // a lease that ran out with no report goes back untouched: not a try (review E21, as B5)
        $pdo->exec("UPDATE town_crawl_jobs SET status = 'queued', lease_until = NULL WHERE status = 'leased' AND lease_until < NOW()");
        self::retryFailed($pdo);
        $rows = $pdo->query("SELECT id, anchor_id, group_label FROM town_crawl_jobs WHERE status = 'queued' ORDER BY priority DESC, id LIMIT " . (int) $limit)->fetchAll(PDO::FETCH_ASSOC);
        $until = date('Y-m-d H:i:s', time() + self::LEASE_MINUTES * 60);
        $mark = $pdo->prepare("UPDATE town_crawl_jobs SET status = 'leased', lease_until = ?, updated_at = NOW() WHERE id = ? AND status = 'queued'");   // a try is counted when it fails, not when it's taken
        $out = [];
        foreach ($rows as $r) {
            $mark->execute([$until, (int) $r['id']]);
            if ($mark->rowCount() !== 1) continue;
            $d = self::describe($pdo, (int) $r['id'], (int) $r['anchor_id'], (string) $r['group_label'], $until);
            if ($d) $out[] = $d;
            else $pdo->prepare("UPDATE town_crawl_jobs SET status = 'failed', result = '{\"error\":\"no such town\"}' WHERE id = ?")->execute([(int) $r['id']]);
        }
        return $out;
    }

    /** Failed town jobs come back after 6 hours, a day, then 3 days (review E21: they never did); then a person retries them. */
    private const RETRY_AFTER_HOURS = [6, 24, 72];

    private static function retryFailed(PDO $pdo): void
    {
        $up = $pdo->prepare("UPDATE town_crawl_jobs SET status = 'queued', attempts = 0, result = ?, updated_at = NOW() WHERE id = ? AND status = 'failed'");
        foreach ($pdo->query("SELECT id, result, updated_at FROM town_crawl_jobs WHERE status = 'failed' LIMIT 200")->fetchAll(PDO::FETCH_ASSOC) as $j) {
            $r = json_decode((string) $j['result'], true) ?: [];
            $round = (int) ($r['rounds'] ?? 0);
            if ($round >= count(self::RETRY_AFTER_HOURS) || strtotime((string) $j['updated_at']) > time() - self::RETRY_AFTER_HOURS[$round] * 3600) continue;
            $up->execute([json_encode(['rounds' => $round + 1] + $r), (int) $j['id']]);
        }
    }

    private static function describe(PDO $pdo, int $id, int $anchorId, string $group, string $until): ?array
    {
        $k = self::KINDS[$group] ?? null;
        if (!$k && str_starts_with($group, 'want:')) {   // a kind searched for (OpenPlaces' filters), its category left to the classifier
            require_once __DIR__ . '/../OpenPlaces.php';
            $o = OpenPlaces::KINDS[substr($group, 5)] ?? null;
            if ($o) $k = [$o[0], $o[1], [$o[0]], ''];
        }
        $st = $pdo->prepare('SELECT name, state, zips, lat, lon FROM anchors WHERE id = ?'); $st->execute([$anchorId]); $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$k || !$a || $a['lat'] === null) return null;
        $zips = array_values(array_filter(explode(',', (string) $a['zips'])));
        $pts = [];
        if ($zips) {
            $z = $pdo->prepare('SELECT zip, latitude, longitude FROM zip_coordinates WHERE zip IN (' . implode(',', array_fill(0, count($zips), '?')) . ')'); $z->execute($zips);
            foreach ($z->fetchAll(PDO::FETCH_ASSOC) as $r) if ($r['latitude'] !== null) $pts[trim((string) $r['zip'])] = ['zip' => trim((string) $r['zip']), 'lat' => (float) $r['latitude'], 'lon' => (float) $r['longitude']];
        }
        if ($k[3] === '') { $cats = $pdo->prepare('SELECT id, name FROM categories WHERE 1 = 0'); $cats->execute(); }
        elseif (is_int($k[3])) { $cats = $pdo->prepare('SELECT id, name FROM categories WHERE id = ?'); $cats->execute([$k[3]]); }
        else { $cats = $pdo->prepare('SELECT id, name FROM categories WHERE is_active = 1 AND parent_id IS NULL AND name LIKE ? ORDER BY id LIMIT 1'); $cats->execute([$k[3] . '%']); }   // by name: none found sends none
        return [
            'job_id' => self::ID_FROM + $id,
            'lease_until' => $until,
            'looking_for' => ['group' => $group, 'categories' => array_map(fn ($r) => ['id' => (int) $r['id'], 'name' => $r['name']], $cats->fetchAll(PDO::FETCH_ASSOC)), 'osm' => $k[1], 'offerings' => $k[2]],
            'place' => ['cluster_id' => 0, 'name' => $a['name'] . ', ' . $a['state'], 'towns' => [['town' => $a['name'], 'state' => $a['state']]], 'zips' => $zips,
                        'zip_points' => array_values($pts), 'center' => ['lat' => (float) $a['lat'], 'lon' => (float) $a['lon']]],
            'rules' => ['max_candidates' => 50, 'auto_import_needs' => 'a trusted registry, or the listing seen on 2+ independent websites (put the second in "corroboration")', 'schema' => 'intake.v1 (see app/lib/crawler/ListingExtractor.php)'],
        ];
    }

    private static function job(PDO $pdo, int $jobId): array
    {
        $st = $pdo->prepare('SELECT * FROM town_crawl_jobs WHERE id = ?'); $st->execute([$jobId - self::ID_FROM]); $j = $st->fetch(PDO::FETCH_ASSOC);
        if (!$j) throw new InvalidArgumentException("No job #$jobId.");
        if ($j['status'] !== 'leased') throw new InvalidArgumentException("Job #$jobId is {$j['status']}, not leased (its lease may have expired).");
        return $j;
    }

    /** The worker's places for one town job, through the same intake as every crawl. */
    public static function complete(PDO $pdo, int $jobId, array $candidates, int $pages, array $log): array
    {
        $j = self::job($pdo, $jobId);
        require_once __DIR__ . '/CrawlQueue.php';
        $candidates = array_slice(array_values(array_filter(array_map([CrawlQueue::class, 'normalize'], $candidates))), 0, 50);
        $r = ['staged' => [], 'auto_imported' => [], 'already_known' => 0];
        if ($candidates) {
            $label = 'Town crawl #' . $jobId . ': ' . (self::KINDS[$j['group_label']][0] ?? $j['group_label']) . ' in ' . $j['place_key'];
            $sourceId = IntakeStager::createSource($pdo, 'https://worker.traversence/job/' . $jobId, ['create_listings', 'guide_create'], $label, 0);
            $r = IntakeStager::stage($pdo, $sourceId, $candidates);
            IntakeStager::recordRun($pdo, $sourceId, $pages, array_slice($log, 0, 200), null);
            if ($r['auto_imported']) PageCache::forget($pdo, 'guides:picks:' . $j['place_key'] . ':');   // its guide shows them at once
            if ($r['auto_imported'] && is_file(__DIR__ . '/../SearchIndex.php')) {   // and search finds them at once (2026-11-10)
                require_once __DIR__ . '/../SearchIndex.php';
                try { if (SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, array_map('intval', $r['auto_imported'])); } catch (Throwable $e) { error_log('town crawl index: ' . $e->getMessage()); }
            }
        }
        $partial = in_array('partial', $log, true);   // the worker's time ran out mid-job (2026-11-10): another round, not done
        $summary = ['candidates' => count($candidates), 'staged' => count($r['staged']), 'auto_imported' => count($r['auto_imported']), 'already_known' => $r['already_known'], 'pages' => $pages, 'finished_at' => date('c')] + ($partial ? ['partial' => true] : []);
        // a partial job goes round again, at most PARTIAL_MAX times in a row (review E21: one too big for a run looped), then it's done with what it found
        $was = json_decode((string) ($j['result'] ?? ''), true) ?: [];
        $summary['partial_rounds'] = $partial ? (int) ($was['partial_rounds'] ?? 0) + 1 : 0;
        if ($partial && $summary['partial_rounds'] >= self::PARTIAL_MAX) $partial = false;
        if ($partial) $pdo->prepare("UPDATE town_crawl_jobs SET status = 'queued', lease_until = NULL, result = ?, updated_at = NOW() WHERE id = ?")->execute([json_encode($summary), (int) $j['id']]);
        else $pdo->prepare("UPDATE town_crawl_jobs SET status = 'done', lease_until = NULL, result = ?, updated_at = NOW() WHERE id = ?")->execute([json_encode($summary), (int) $j['id']]);
        if ($r['auto_imported'] && is_file(__DIR__ . '/../JourneyPlan.php')) { require_once __DIR__ . '/../JourneyPlan.php'; try { JourneyPlan::buildPlace($pdo, (string) $j['place_key']); } catch (Throwable $e) { error_log('town crawl journeys: ' . $e->getMessage()); } }
        return ['staged' => $summary['staged'], 'auto_imported' => $summary['auto_imported'], 'already_known' => $summary['already_known']];
    }

    public static function fail(PDO $pdo, int $jobId, string $message): void
    {
        $j = self::job($pdo, $jobId);
        $was = json_decode((string) ($j['result'] ?? ''), true) ?: [];
        $pdo->prepare('UPDATE town_crawl_jobs SET attempts = attempts + 1, status = ?, lease_until = NULL, result = ?, updated_at = NOW() WHERE id = ?')
            ->execute([(int) $j['attempts'] + 1 >= self::MAX_ATTEMPTS ? 'failed' : 'queued', json_encode(['error' => mb_substr($message, 0, 500), 'at' => date('c'), 'rounds' => (int) ($was['rounds'] ?? 0)]), (int) $j['id']]);
    }

    /** Where a town's build-out stands: kind => status, for the build page and Insights. */
    public static function forPlace(PDO $pdo, string $key): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT group_label, status, result FROM town_crawl_jobs WHERE place_key = ?'); $st->execute([$key]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['group_label']] = ['status' => $r['status'], 'added' => (int) ((json_decode((string) $r['result'], true) ?: [])['auto_imported'] ?? 0)];
        return $out;
    }
}
