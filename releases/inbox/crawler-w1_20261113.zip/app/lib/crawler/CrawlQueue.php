<?php

declare(strict_types=1);

require_once __DIR__ . '/AutoImport.php';
require_once __DIR__ . '/SiteFetcher.php';
require_once __DIR__ . '/../SupportGroups.php';
require_once __DIR__ . '/../PageCache.php';

/**
 * api/lib/crawler/CrawlQueue.php — the guide-driven crawl queue (decisions/0044), in small increments.
 *
 * Bluehost only hands out jobs and checks results; the fetching happens off-site (a Railway worker):
 *   seed()     — turns coverage gaps (a cluster with no listings in a Support & wellness group) into jobs,
 *                prioritised by how many residents live with the gap. Existing jobs are kept.
 *   lease()    — gives the worker the next few jobs, each with a lease; a job not finished in time goes
 *                back to the queue, and after MAX_ATTEMPTS it is marked failed.
 *   complete() — takes the worker's candidates (intake.v1) for one job and stages them through
 *                IntakeStager::stage(), where AutoImport publishes those that pass every guardrail.
 *   fail()     — records a worker error; the job is retried until MAX_ATTEMPTS.
 * CRAWL_QUEUE=off in .env pauses hand-outs without losing the queue.
 */
final class CrawlQueue
{
    private const PARTIAL_MAX = 4;   // a job cut short by a run's time goes round again at most this often in a row
    public const MAX_ATTEMPTS = 3;
    /** A failed job goes back in the queue by itself after these waits (hours), then stays failed for a person. */
    public const RETRY_AFTER_HOURS = [6, 24, 72];
    public const LEASE_MINUTES = 20;
    public const MAX_CANDIDATES_PER_RESULT = 50;

    public static function paused(): bool
    {
        require_once __DIR__ . '/../Staging.php';
        if (!Staging::allow('crawler')) return true;   // the staging copy: off unless its switch is on for a test (decisions/0145 Phase 3)
        return strtolower(trim((string) (getenv('CRAWL_QUEUE') ?: 'on'))) === 'off';
    }

    public static function tableExists(PDO $pdo): bool
    {
        try {
            $pdo->query('SELECT 1 FROM ' . Database::t('crawl_jobs') . ' LIMIT 1');
            return true;
        } catch (Throwable) {
            return false;
        }
    }

    /** @return array<string,int> jobs per status */
    public static function stats(PDO $pdo): array
    {
        $out = ['queued' => 0, 'leased' => 0, 'done' => 0, 'failed' => 0];
        foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM ' . Database::t('crawl_jobs') . ' GROUP BY status')->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $out[$r['status']] = (int) $r['n'];
        }
        return $out;
    }

    /** Queues every gap in a geo-hub, and retries failed ones. Returns ['added' => n, 'reprioritised' => n, 'retried' => n]. */
    public static function seed(PDO $pdo, int $geoHubId, int $adminId): array
    {
        $clusters = CrawlerIngest::loadClusters($pdo, $geoHubId);
        $counts = SupportGroups::countsByCluster($pdo, array_keys($clusters));
        $existing = [];
        foreach ($pdo->query('SELECT id, cluster_id, group_label, status FROM ' . Database::t('crawl_jobs') . '')->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $existing[(int) $r['cluster_id'] . '|' . $r['group_label']] = $r;
        }
        $ins = $pdo->prepare('INSERT INTO ' . Database::t('crawl_jobs') . ' (cluster_id, group_label, priority, status, queued_by_user_id, created_at, updated_at)
                              VALUES (?, ?, ?, \'queued\', ?, NOW(), NOW())');
        $upd = $pdo->prepare("UPDATE " . Database::t('crawl_jobs') . " SET priority = ?, updated_at = NOW() WHERE id = ? AND status = 'queued'");
        // A failed job whose gap is still there gets another three tries (usually OpenStreetMap was busy).
        $retry = $pdo->prepare("UPDATE " . Database::t('crawl_jobs') . " SET status = 'queued', attempts = 0, lease_until = NULL, priority = ?, updated_at = NOW() WHERE id = ? AND status = 'failed'");
        $added = 0;
        $re = 0;
        $retried = 0;
        $pdo->beginTransaction();
        try {
            foreach ($clusters as $id => $c) {
                $pop = 0;
                foreach ($c['members'] as $m) $pop += (int) ($m['population'] ?? 0);
                foreach (array_keys(SupportGroups::GROUPS) as $g) {
                    if (($counts[$id][$g] ?? 0) > 0) continue;          // not a gap
                    $k = "$id|$g";
                    if (isset($existing[$k])) {
                        if ($existing[$k]['status'] === 'queued') { $upd->execute([$pop, $existing[$k]['id']]); $re++; }
                        if ($existing[$k]['status'] === 'failed') { $retry->execute([$pop, $existing[$k]['id']]); $retried++; }
                        continue;
                    }
                    $ins->execute([$id, $g, $pop, $adminId]);
                    $added++;
                }
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return ['added' => $added, 'reprioritised' => $re, 'retried' => $retried];
    }

    /** The next jobs for the worker, each fully described so the worker needs no database. */
    public static function lease(PDO $pdo, int $limit): array
    {
        if (self::paused()) return [];
        $limit = max(1, min(10, $limit));
        // the coverage queue's own upkeep first, whoever fills the hand-out (review E21: when towns filled it, expired leases
        // and retries never ran): an expired lease goes back untouched (not a try), failed jobs come back by rounds
        try {
            $pdo->exec("UPDATE " . Database::t('crawl_jobs') . " SET status = 'queued', lease_until = NULL WHERE status = 'leased' AND lease_until < NOW()");
            self::retryFailed($pdo);
        } catch (Throwable $e) { error_log('crawl queue upkeep: ' . $e->getMessage()); }
        // towns someone searched for come first (decisions/0149: interest is the queue)
        require_once __DIR__ . '/TownCrawl.php';
        $towns = [];
        try { $towns = TownCrawl::lease($pdo, $limit); } catch (Throwable $e) { error_log('town crawl lease: ' . $e->getMessage()); }
        if (count($towns) >= $limit) return $towns;
        $limit -= count($towns);
        $pdo->beginTransaction();
        try {
            $rows = $pdo->query("SELECT id, cluster_id, group_label FROM " . Database::t('crawl_jobs') . " WHERE status = 'queued' ORDER BY priority DESC, id LIMIT $limit")
                        ->fetchAll(PDO::FETCH_ASSOC);
            $until = date('Y-m-d H:i:s', time() + self::LEASE_MINUTES * 60);
            $mark = $pdo->prepare("UPDATE " . Database::t('crawl_jobs') . " SET status = 'leased', lease_until = ?, updated_at = NOW() WHERE id = ? AND status = 'queued'");   // a try is counted when it fails (fail()), not when it's taken
            foreach ($rows as $r) $mark->execute([$until, $r['id']]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return array_merge($towns, array_values(array_filter(array_map(fn ($r) => self::describe($pdo, (int) $r['id'], (int) $r['cluster_id'], (string) $r['group_label'], $until), $rows))));
    }

    /** One job as the worker sees it: the place (towns, ZIPs, centre, state) and what to look for. */
    public static function describe(PDO $pdo, int $jobId, int $clusterId, string $group, string $leaseUntil): ?array
    {
        $st = $pdo->prepare('SELECT geo_hub_id FROM micro_clusters WHERE id = ?');
        $st->execute([$clusterId]);
        $hub = $st->fetchColumn();
        if ($hub === false) return null;
        $c = CrawlerIngest::loadClusters($pdo, (int) $hub)[$clusterId] ?? null;
        // a situation gap (decisions/0061, batch 3): "sit:<need key>", with its own OpenStreetMap filters and Wikidata classes
        $sit = str_starts_with($group, 'sit:');
        if ($sit) { require_once __DIR__ . '/../Learning.php'; $lf = Learning::lookingFor($pdo, substr($group, 4)); if (!$lf) return null; }
        if ($c === null || (!$sit && !isset(SupportGroups::GROUPS[$group]))) return null;
        $towns = [];
        foreach ($c['members'] as $m) if ($m['city']) $towns[strtolower($m['city'] . '|' . $m['state'])] = ['town' => $m['city'], 'state' => $m['state']];
        if ($sit) {
            $lookingFor = ['group' => $lf['group'], 'categories' => $lf['categories'], 'osm' => $lf['osm'], 'wikidata' => $lf['wikidata'], 'offerings' => $lf['offerings']];
        } else {
            $ids = SupportGroups::GROUPS[$group];
            $in = implode(',', array_map('intval', $ids));
            $cats = $pdo->query("SELECT id, name FROM categories WHERE id IN ($in)")->fetchAll(PDO::FETCH_ASSOC);
            $lookingFor = ['group' => $group, 'categories' => array_map(fn ($r) => ['id' => (int) $r['id'], 'name' => $r['name']], $cats)];
        }
        return [
            'job_id' => $jobId,
            'lease_until' => $leaseUntil,
            'looking_for' => $lookingFor,
            'place' => [
                'cluster_id' => $clusterId,
                'name' => preg_replace('/\s*\(auto-seeded[^)]*\)/i', '', $c['name']),
                'towns' => array_values($towns),
                'zips' => array_column($c['members'], 'zip'),
                // ZIP centre points, so the worker can give a found place the nearest of this cluster's ZIPs
                'zip_points' => array_values(array_map(fn ($m) => ['zip' => $m['zip'], 'lat' => $m['lat'], 'lon' => $m['lon']],
                                    array_filter($c['members'], fn ($m) => $m['lat'] !== null))),
                'center' => ['lat' => $c['lat'], 'lon' => $c['lon']],
            ],
            'rules' => [
                'max_candidates' => self::MAX_CANDIDATES_PER_RESULT,
                'auto_import_needs' => 'a trusted registry, or the listing seen on 2+ independent websites (put the second in "corroboration")',
                'schema' => 'intake.v1 (see app/lib/crawler/ListingExtractor.php)',
            ],
        ];
    }

    /**
     * Stages the worker's candidates for one leased job and closes it.
     * @return array{staged:int, auto_imported:int, already_known:int}
     */
    public static function complete(PDO $pdo, int $jobId, array $candidates, int $pages, array $log): array
    {
        require_once __DIR__ . '/TownCrawl.php';
        if (TownCrawl::mine($jobId)) return TownCrawl::complete($pdo, $jobId, $candidates, $pages, $log);   // a searched-for town's job (decisions/0149)
        $job = self::leasedJob($pdo, $jobId);
        $candidates = array_slice(array_values(array_filter(array_map([self::class, 'normalize'], $candidates))), 0, self::MAX_CANDIDATES_PER_RESULT);
        $r = ['staged' => [], 'auto_imported' => [], 'already_known' => 0];
        if ($candidates) {
            $label = "Guide crawl #{$jobId}: {$job['group_label']} in cluster {$job['cluster_id']}";
            $sourceId = IntakeStager::createSource($pdo, 'https://worker.traversence/job/' . $jobId, ['create_listings', 'guide_create'], $label,
                (int) ($job['queued_by_user_id'] ?? 0));
            $r = IntakeStager::stage($pdo, $sourceId, $candidates);
            IntakeStager::recordRun($pdo, $sourceId, $pages, array_slice($log, 0, 200), null);
            if ($r['auto_imported']) PageCache::forget($pdo, 'hub:support');   // new public listings show at once
        }
        $summary = ['candidates' => count($candidates), 'staged' => count($r['staged']), 'auto_imported' => count($r['auto_imported']),
                    'already_known' => $r['already_known'], 'pages' => $pages, 'finished_at' => date('c')];
        // a job the run's time cut short goes round again (review: it was marked done), at most PARTIAL_MAX times in a row
        $was = json_decode((string) ($job['result'] ?? ''), true) ?: [];
        $partial = in_array('partial', $log, true);
        $summary['partial_rounds'] = $partial ? (int) ($was['partial_rounds'] ?? 0) + 1 : 0;
        if (isset($was['rounds'])) $summary['rounds'] = (int) $was['rounds'];
        $again = $partial && $summary['partial_rounds'] < self::PARTIAL_MAX;
        $pdo->prepare("UPDATE " . Database::t('crawl_jobs') . " SET status = ?, lease_until = NULL, result = ?, updated_at = NOW() WHERE id = ?")
            ->execute([$again ? 'queued' : 'done', json_encode($summary), $jobId]);
        if (str_starts_with((string) $job['group_label'], 'sit:')) {   // a situation gap: the websites it found places on are Tier 1 sources
            require_once __DIR__ . '/../Learning.php';
            try { Learning::tier1Done($pdo, (string) $job['group_label'], (int) $job['cluster_id'], $candidates); } catch (Throwable $e) { error_log('tier 1 sources: ' . $e->getMessage()); }
        }
        return ['staged' => $summary['staged'], 'auto_imported' => $summary['auto_imported'], 'already_known' => $summary['already_known']];
    }

    /**
     * Failed jobs retry on their own (usually OpenStreetMap was busy or refusing for a while): 6 hours after
     * failing, then a day, then 3 days. After the third round a job stays failed until a person queues it again.
     */
    private static function retryFailed(PDO $pdo): void
    {
        $st = $pdo->query("SELECT id, result, updated_at FROM " . Database::t('crawl_jobs') . " WHERE status = 'failed' ORDER BY updated_at LIMIT 50");
        $up = $pdo->prepare("UPDATE " . Database::t('crawl_jobs') . " SET status = 'queued', attempts = 0, lease_until = NULL, result = ? WHERE id = ? AND status = 'failed'");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $j) {
            $r = json_decode((string) $j['result'], true);
            $r = is_array($r) ? $r : [];
            $round = (int) ($r['rounds'] ?? 0);
            if ($round >= count(self::RETRY_AFTER_HOURS)) continue;
            if (strtotime((string) $j['updated_at']) > time() - self::RETRY_AFTER_HOURS[$round] * 3600) continue;
            $r['rounds'] = $round + 1;
            $up->execute([json_encode($r), (int) $j['id']]);
        }
    }

    /** When a failed job will try again on its own, or null if it won't. */
    /** Puts every failed job back in the queue (the crawler page's button, and Pulse's one tap). Returns how many. */
    public static function requeueFailed(PDO $pdo): int
    {
        return (int) $pdo->exec("UPDATE " . Database::t('crawl_jobs') . " SET status = 'queued', attempts = 0, lease_until = NULL, updated_at = NOW() WHERE status = 'failed'");
    }

    public static function retryAt(array $job): ?int
    {
        $r = json_decode((string) ($job['result'] ?? ''), true);
        $round = (int) (is_array($r) ? ($r['rounds'] ?? 0) : 0);
        if ($round >= count(self::RETRY_AFTER_HOURS)) return null;
        return strtotime((string) $job['updated_at']) + self::RETRY_AFTER_HOURS[$round] * 3600;
    }

    /** Records a worker error; the job goes back to the queue until MAX_ATTEMPTS, then fails. */
    public static function fail(PDO $pdo, int $jobId, string $message): void
    {
        require_once __DIR__ . '/TownCrawl.php';
        if (TownCrawl::mine($jobId)) { TownCrawl::fail($pdo, $jobId, $message); return; }
        $job = self::leasedJob($pdo, $jobId);
        $status = (int) $job['attempts'] + 1 >= self::MAX_ATTEMPTS ? 'failed' : 'queued';
        $pdo->prepare('UPDATE ' . Database::t('crawl_jobs') . ' SET attempts = attempts + 1, status = ?, lease_until = NULL, result = ?, updated_at = NOW() WHERE id = ?')
            ->execute([$status, json_encode(['error' => mb_substr($message, 0, 500), 'at' => date('c'), 'rounds' => (int) (json_decode((string) $job['result'], true)['rounds'] ?? 0)]), $jobId]);
    }

    private static function leasedJob(PDO $pdo, int $jobId): array
    {
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('crawl_jobs') . ' WHERE id = ?');
        $st->execute([$jobId]);
        $job = $st->fetch(PDO::FETCH_ASSOC);
        if ($job === false) throw new InvalidArgumentException("No job #$jobId.");
        if ($job['status'] !== 'leased') throw new InvalidArgumentException("Job #$jobId is {$job['status']}, not leased (its lease may have expired).");
        return $job;
    }

    /** A worker candidate made safe to stage: every intake.v1 field present with the right type. */
    public static function normalize(mixed $c): ?array
    {
        if (!is_array($c)) return null;
        $s = fn ($v, int $max = 500) => mb_substr(trim(html_entity_decode(strip_tags(is_scalar($v) ? (string) $v : ''), ENT_QUOTES)), 0, $max);
        if ($s($c['name'] ?? '', 255) === '') return null;
        if (!preg_match('/^\d{5}$/', $s($c['where']['zip'] ?? '', 10))) return null;   // can't be placed without a ZIP
        $l = fn ($v) => array_slice(array_values(array_filter(array_map(fn ($x) => is_scalar($x) ? mb_substr(trim((string) $x), 0, 300) : '', (array) $v))), 0, 60);
        $urls = function ($v) { $o = []; foreach ((array) $v as $u) if (is_string($u) && preg_match('#^https?://#i', $u)) $o[] = mb_substr($u, 0, 500); return array_slice($o, 0, 10); };
        $sources = [];
        foreach ((array) ($c['sources'] ?? []) as $field => $list) $sources[$s($field, 40)] = $urls($list);
        $phone = $s($c['actions']['phone'] ?? '', 30);
        return [
            'schema' => 'intake.v1',
            'name' => $s($c['name'], 255),
            'location_index' => 1, 'location_count' => 1,
            'source' => ['start_url' => $urls([$c['source']['start_url'] ?? ''])[0] ?? '', 'site' => $s($c['source']['site'] ?? '', 120),
                         'pages_crawled' => (int) ($c['source']['pages_crawled'] ?? 0), 'crawled_at' => $s($c['source']['crawled_at'] ?? date('c'), 40),
                         'registry' => $s($c['source']['registry'] ?? '', 60)],
            'who' => ['audience' => $l($c['who']['audience'] ?? [])],
            'what' => ['offerings' => $l($c['what']['offerings'] ?? []), 'description' => $s($c['what']['description'] ?? '', 2000)],
            'where' => ['address' => $s($c['where']['address'] ?? '', 255), 'city' => $s($c['where']['city'] ?? '', 120),
                        'state' => strtoupper($s($c['where']['state'] ?? '', 2)), 'zip' => preg_match('/^\d{5}$/', $s($c['where']['zip'] ?? '', 10)) ? $s($c['where']['zip'], 5) : '',
                        'location_page' => $urls([$c['where']['location_page'] ?? ''])[0] ?? '', 'service_area' => $l($c['where']['service_area'] ?? [])],
            'when' => ['hours' => $l($c['when']['hours'] ?? [])],
            'why' => ['highlights' => $l($c['why']['highlights'] ?? [])],
            'actions' => ['phone' => $phone !== '' ? (ListingExtractor::phone($phone) ?? null) : null,
                          'email' => filter_var($c['actions']['email'] ?? '', FILTER_VALIDATE_EMAIL) ?: null,
                          'website' => $urls([$c['actions']['website'] ?? ''])[0] ?? null, 'whatsapp' => null,
                          'social' => $urls($c['actions']['social'] ?? [])],
            'sources' => $sources,
            'corroboration' => $urls($c['corroboration'] ?? []),
            'flags' => [],
            'confidence' => max(0, min(100, (int) ($c['confidence'] ?? 0))),
        ];
    }
}
