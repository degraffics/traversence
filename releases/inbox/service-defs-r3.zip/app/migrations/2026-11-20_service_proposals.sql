-- decisions/0173 §2: Proposed, a service someone would like added, as a build request (only words: no address, key or call).
-- Safe to run twice.
CREATE TABLE IF NOT EXISTS service_proposals (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  link VARCHAR(255) DEFAULT NULL,
  why VARCHAR(400) NOT NULL,
  state VARCHAR(12) NOT NULL DEFAULT 'proposed',
  by_uid INT UNSIGNED DEFAULT NULL,
  by_name VARCHAR(80) DEFAULT NULL,
  at DATETIME NOT NULL,
  dropped_at DATETIME DEFAULT NULL,
  dropped_by VARCHAR(80) DEFAULT NULL,
  KEY state_id (state, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
