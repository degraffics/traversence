<?php

declare(strict_types=1);

require_once __DIR__ . '/People.php';
require_once __DIR__ . '/Links.php';
if (is_file(__DIR__ . '/Tags.php')) require_once __DIR__ . '/Tags.php';   // @tags (decisions/0051)

/**
 * api/lib/Community.php — public community groups (decisions/0047 §2, §4).
 *
 * Anyone can find a group and read what it's about and how many belong. Joining is consent to be seen by
 * the group's members, within the group: members see each other's names and the group's posts; no one else
 * does. Never an email or a location. A group can belong to a place (hub, geo-hub or town cluster: "cluster:12"),
 * and that place's page lists it. The owner (and moderators they choose) accept requests in "approval"
 * groups, and remove posts or members; admins can hide a group. People you've blocked, or who blocked you,
 * don't appear to you.
 *
 * Owners (decisions/0137 §1): a group belongs to a person, or to a listing (a business's one group, run by its team).
 * In a business's group, the team's roles decide who runs it (0102 §4c): Owner and Manager run it (only the Owner can
 * hide it), Creator and Support moderate, Sales answers as the business's rep; Accountant, Developer and Viewer have no
 * part unless they join. A team member can post as the business (Owner, Manager, Creator) or as its rep (Sales).
 * Charters (0137 §3, GroupCharters): every new group opens with one; joining records the version agreed to.
 * Moderation (0137 §5): reports on a group's posts go to its own moderators (or its owner, as the charter says), who
 * keep or remove the post or remove its author; a reported post is held (hidden from everyone but its author and the
 * moderators) when the charter's count of reports from different members of more than 7 days is reached, or at once
 * for private information, a sacred site or danger. Traversence comes in by a "Group help" case: asked for by the
 * group's leaders, or opened on its own when reports have waited 14 days (Pulse).
 * Notices sent once (0137 §6, Notices): a request to join answered, a charter changed, a post removed by moderators,
 * a new local group in a place someone follows.
 * Messages (decisions/0172 §2.8, GroupNotices): joining works like Link: each new post reaches the members in Pulse (by
 * their link settings: a muted group sends none), a mention reaches the one mentioned; a request to join reaches its
 * moderators, and a post reported to the group whoever handles its reports, each with its buttons in the message.
 * Topic groups and chapters (0136): a group's tags and the places it's about (GroupGrowth); chapters (GroupChapters),
 * whose parent's owner and moderators can moderate in them and post to all of them at once; joining by invitation or
 * invite code (skipping approval when the charter says so), answers to the join questions, a welcome message and a
 * public welcome post; joins counted by how people came (never who).
 */
final class Community
{
    public const TOPICS = ['outdoors' => 'Outdoors & recreation', 'arts' => 'Arts & crafts', 'faith' => 'Faith', 'family' => 'Family & parenting',
                           'health' => 'Health & wellness', 'food' => 'Food & cooking', 'history' => 'History & culture', 'causes' => 'Volunteering & causes',
                           'business' => 'Business & careers', 'hobbies' => 'Hobbies & games', 'other' => 'Other'];
    private const MAX_OWNED = 5;
    private const MAX_POST = 2000;
    /** A business team role → its part in the business's group (0102 §4c). */
    private const BIZ_ROLES = ['owner' => 'owner', 'manager' => 'manager', 'creator' => 'creator', 'support' => 'moderator', 'sales' => 'rep'];
    /** Who can do what: 'run' (settings, charter, moderators), 'moderate', 'hide' (end the group), 'business' (post as it), 'rep'. */
    private const CAN = ['owner' => ['run', 'moderate', 'hide', 'business'], 'manager' => ['run', 'moderate', 'business'],
                         'creator' => ['moderate', 'business'], 'moderator' => ['moderate'], 'rep' => ['rep'], 'member' => []];

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM community_posts LIMIT 1'); return true; } catch (PDOException) { return false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    private static function topicsReady(PDO $pdo): bool
    {
        static $ready = null;
        if ($ready === null) { try { $pdo->query('SELECT topic FROM community_groups LIMIT 1'); $ready = true; } catch (PDOException) { $ready = false; } }
        return $ready;
    }

    /** Whether 2027-01-16_group_charters.sql has run (owners and post voices). */
    public static function ownersReady(PDO $pdo): bool
    {
        static $ready = null;
        if ($ready === null) { try { $pdo->query('SELECT owner_kind, owner_ref FROM community_groups LIMIT 0'); $pdo->query('SELECT voice, as_listing FROM community_posts LIMIT 0'); $ready = true; } catch (PDOException) { $ready = false; } }
        return $ready;
    }

    /** Whether 2027-01-24_groups_grow.sql has run (tags, places, chapters, invitations). */
    public static function growReady(PDO $pdo): bool
    {
        if (!is_file(__DIR__ . '/GroupGrowth.php')) return false;
        require_once __DIR__ . '/GroupGrowth.php';
        return GroupGrowth::ready($pdo);
    }

    private static function placesReady(PDO $pdo): bool
    {
        static $ready = null;
        if ($ready === null) { try { $pdo->query('SELECT place_key FROM community_groups LIMIT 1'); $ready = true; } catch (PDOException) { $ready = false; } }
        return $ready;
    }

    /** Places whose name matches, for the place picker: [{key, label, level}]. */
    public static function findPlaces(PDO $pdo, string $q): array
    {
        $q = trim($q);
        if (mb_strlen($q) < 2) return [];
        $out = [];
        foreach (['cluster' => ['micro_clusters', 'Town'], 'geo_hub' => ['geo_hubs', 'Area'], 'hub' => ['hubs', 'Region']] as $level => [$table, $word]) {
            try {
                $st = $pdo->prepare("SELECT id, name FROM $table WHERE name LIKE ? ORDER BY name LIMIT 8");
                $st->execute(['%' . $q . '%']);
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    $out[] = ['key' => $level . ':' . (int) $r['id'], 'label' => PlaceScope::publicName((string) $r['name']), 'level' => $word];
                }
            } catch (PDOException) {}
        }
        return $out;
    }

    /** '' (no place) or a valid public place key; [key, label, url]. */
    public static function place(PDO $pdo, string $key): array
    {
        $key = trim($key);
        if ($key === '') return ['', '', ''];
        [$label, $url] = Links::resolve($pdo, 'place', $key);   // throws for an unknown place
        return [$key, $label, $url];
    }

    public static function group(PDO $pdo, int $gid, bool $admin = false): ?array
    {
        $st = $pdo->prepare('SELECT id, name, about, owner_id, join_mode, status, created_at' . (self::placesReady($pdo) ? ', place_key' : '') . (self::topicsReady($pdo) ? ', topic' : '')
            . (self::ownersReady($pdo) ? ', owner_kind, owner_ref' : '') . (self::growReady($pdo) ? ', parent_id, chapter_name, chapter_join, welcome_post_id, welcome_msg, leaving_at' : '') . ' FROM community_groups WHERE id = ?');
        $st->execute([$gid]);
        $g = $st->fetch(PDO::FETCH_ASSOC);
        if (!$g || ($g['status'] !== 'active' && !$admin)) return null;
        if (!empty($g['leaving_at'])) { require_once __DIR__ . '/GroupChapters.php'; $g = GroupChapters::finishLeaving($pdo, $g); }   // a chapter whose notice to leave is over
        $g['parent_id'] = isset($g['parent_id']) ? (int) $g['parent_id'] : 0;
        $g['owner_kind'] = (string) ($g['owner_kind'] ?? 'person');
        $g['owner_ref'] = isset($g['owner_ref']) ? (int) $g['owner_ref'] : 0;
        $g['members'] = self::count($pdo, $gid);
        return $g;
    }

    /** Who the group belongs to: ['kind' => person|listing, 'id', 'name', 'url']. */
    public static function owner(PDO $pdo, array $g): array
    {
        if ($g['owner_kind'] === 'listing' && $g['owner_ref'] > 0) {
            $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([$g['owner_ref']]);
            return ['kind' => 'listing', 'id' => $g['owner_ref'], 'name' => (string) ($st->fetchColumn() ?: 'A business'), 'url' => '/listing/view.php?id=' . $g['owner_ref']];
        }
        $u = People::user($pdo, (int) $g['owner_id']);
        return ['kind' => 'person', 'id' => (int) $g['owner_id'], 'name' => $u ? People::name($u) : 'A member', 'url' => '/user/profile.php?id=' . (int) $g['owner_id']];
    }

    /**
     * The person's part in the group: ['role' => owner|manager|creator|moderator|rep|member, 'status' => active|pending,
     * 'via' => business|member] or null. In a business's group, a team role comes first (0102 §4c).
     */
    public static function roleIn(PDO $pdo, int $gid, int $uid, ?array $g = null): ?array
    {
        if ($uid <= 0) return null;
        $g = $g ?? self::group($pdo, $gid, true);
        if ($g && $g['owner_kind'] === 'listing' && $g['owner_ref'] > 0 && is_file(__DIR__ . '/Team.php')) {
            require_once __DIR__ . '/Team.php';
            $tr = Team::roleOf($pdo, $uid, $g['owner_ref']);
            if ($tr !== null && isset(self::BIZ_ROLES[$tr])) return ['role' => self::BIZ_ROLES[$tr], 'status' => 'active', 'via' => 'business', 'team_role' => $tr];
        }
        $m = self::membership($pdo, $gid, $uid);
        return $m ? ['role' => (string) $m['role'], 'status' => (string) $m['status'], 'via' => 'member'] : null;
    }

    /** Whether the person may: run, moderate, hide, business (post as it), rep. */
    public static function can(PDO $pdo, int $gid, int $uid, string $what, ?array $g = null): bool
    {
        $r = self::roleIn($pdo, $gid, $uid, $g);
        if ($r !== null && $r['status'] === 'active' && in_array($what, self::CAN[$r['role']] ?? [], true)) return true;
        // a chapter's parent: its owner and moderators can moderate in the chapter, when the chapter can't settle something (0136 §2)
        if ($what === 'moderate') {
            $g = $g ?? self::group($pdo, $gid, true);
            if ($g && !empty($g['parent_id'])) return self::can($pdo, (int) $g['parent_id'], $uid, 'moderate');
        }
        return false;
    }

    private static function count(PDO $pdo, int $gid): int
    {
        $st = $pdo->prepare("SELECT COUNT(*) FROM community_group_members WHERE group_id = ? AND status = 'active'");
        $st->execute([$gid]);
        return (int) $st->fetchColumn();
    }

    /** ['role' => owner|moderator|member, 'status' => active|pending] or null. */
    public static function membership(PDO $pdo, int $gid, int $uid): ?array
    {
        $st = $pdo->prepare('SELECT role, status FROM community_group_members WHERE group_id = ? AND user_id = ?');
        $st->execute([$gid, $uid]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** A member, or (in a business's group) someone on its team with a part in it. */
    public static function isMember(PDO $pdo, int $gid, int $uid): bool
    {
        $r = self::roleIn($pdo, $gid, $uid);
        return $r !== null && $r['status'] === 'active';
    }

    private static function canModerate(PDO $pdo, int $gid, int $uid): bool
    {
        return self::can($pdo, $gid, $uid, 'moderate');
    }

    /**
     * Groups anyone can find, busiest first, optionally matching a word (in the name, about or tags). $place: the groups
     * of that place (a place's page). With $near (Community's search, 0136 §4), in this order: local groups and chapters
     * there and nearby, nearest first; groups about places nearby; then, when a topic or words are given, interest
     * groups that match, "Anywhere". Within each, more members first. Never by payment (0007).
     */
    public static function directory(PDO $pdo, string $q = '', int $limit = 60, string $place = '', string $topic = '', bool $near = false): array
    {
        $grow = self::growReady($pdo);
        $byPlace = $place !== '' && self::placesReady($pdo);
        $byTopic = $topic !== '' && isset(self::TOPICS[$topic]) && self::topicsReady($pdo);
        $extra = (self::placesReady($pdo) ? ', g.place_key' : '') . (self::topicsReady($pdo) ? ', g.topic' : '') . ($grow ? ', g.parent_id' : '');
        $w = ["g.status = 'active'"]; $a = [];
        if ($q !== '') {
            $w[] = '(g.name LIKE ? OR g.about LIKE ?' . ($grow ? " OR EXISTS (SELECT 1 FROM community_group_tags t WHERE t.group_id = g.id AND t.status = 'shown' AND t.tag LIKE ?)" : '') . ')';
            array_push($a, '%' . $q . '%', '%' . $q . '%'); if ($grow) $a[] = '%' . mb_strtolower($q) . '%';
        }
        if ($byTopic) { $w[] = 'g.topic = ?'; $a[] = $topic; }
        $rank = [];
        if ($byPlace && $near) {
            $rank = self::nearKeys($pdo, $place);
            $in = implode(',', array_fill(0, count($rank), '?'));
            $or = ["g.place_key IN ($in)"]; $a2 = array_keys($rank);
            if ($grow) { $or[] = "EXISTS (SELECT 1 FROM community_group_places gp WHERE gp.group_id = g.id AND gp.removed_by_owner = 0 AND gp.ref IN ($in))"; $a2 = array_merge($a2, array_keys($rank)); }
            if ($q !== '' || $byTopic) $or[] = "(g.place_key IS NULL OR g.place_key = '')";
            $w[] = '(' . implode(' OR ', $or) . ')'; $a = array_merge($a, $a2);
        } elseif ($byPlace) { $w[] = 'g.place_key = ?'; $a[] = $place; }
        $sql = "SELECT g.id, g.name, g.about, g.join_mode$extra, COUNT(m.user_id) AS members FROM community_groups g
                  LEFT JOIN community_group_members m ON m.group_id = g.id AND m.status = 'active'
                 WHERE " . implode(' AND ', $w) . "
                 GROUP BY g.id, g.name, g.about, g.join_mode$extra ORDER BY members DESC, g.name LIMIT " . max(1, min(200, $near ? 200 : $limit));
        $st = $pdo->prepare($sql);
        $st->execute($a);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $ids = array_map(fn ($r) => (int) $r['id'], $rows);
        $tags = $grow ? GroupGrowth::tagsFor($pdo, $ids) : [];
        $parents = [];
        if ($grow && ($pids = array_values(array_unique(array_filter(array_map(fn ($r) => (int) ($r['parent_id'] ?? 0), $rows)))))) {
            foreach ($pdo->query('SELECT id, name FROM community_groups WHERE id IN (' . implode(',', $pids) . ')') as $p) $parents[(int) $p['id']] = (string) $p['name'];
        }
        $about = [];
        if ($rank && $grow && $ids) {
            $in = implode(',', array_fill(0, count($rank), '?'));
            $st = $pdo->prepare("SELECT group_id, ref FROM community_group_places WHERE removed_by_owner = 0 AND ref IN ($in) AND group_id IN (" . implode(',', $ids) . ')'); $st->execute(array_keys($rank));
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $about[(int) $r['group_id']] = min($about[(int) $r['group_id']] ?? 9, $rank[$r['ref']] ?? 9);
        }
        $week = [];   // joins in the last 7 days, a count only, never who (decisions/0058 §13): "+N this week" on /community/'s cards
        if ($ids) { try { $st = $pdo->prepare("SELECT group_id, COUNT(*) AS n FROM community_group_members WHERE status = 'active' AND joined_at >= ? AND group_id IN (" . implode(',', $ids) . ') GROUP BY group_id');
            $st->execute([date('Y-m-d H:i:s', time() - 7 * 86400)]); foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $week[(int) $r['group_id']] = (int) $r['n']; } catch (Throwable $e) {} }
        $out = [];
        foreach ($rows as $g) {
            $id = (int) $g['id']; $pk = (string) ($g['place_key'] ?? ''); $pid = (int) ($g['parent_id'] ?? 0);
            $where = ''; $order = 0;
            if ($rank) {
                if ($pk !== '' && isset($rank[$pk])) { $where = $rank[$pk] === 0 ? 'here' : 'near'; $order = $rank[$pk]; }
                elseif (isset($about[$id])) { $where = 'about'; $order = 10 + $about[$id]; }
                elseif ($pk === '') { $where = 'anywhere'; $order = 20; }
                else continue;
            }
            $out[] = ['id' => $id, 'name' => (string) $g['name'], 'about' => mb_strimwidth((string) $g['about'], 0, 160, '…'),
                'join_mode' => (string) $g['join_mode'], 'members' => (int) $g['members'], 'week' => $week[$id] ?? 0, 'local' => $pk !== '',
                'topic' => (string) ($g['topic'] ?? ''), 'topic_label' => self::TOPICS[(string) ($g['topic'] ?? '')] ?? '',
                'tags' => $tags[$id] ?? [], 'parent' => $pid && isset($parents[$pid]) ? ['id' => $pid, 'name' => $parents[$pid]] : null, 'where' => $where, '_o' => $order];
        }
        if ($rank) usort($out, fn ($x, $y) => [$x['_o'], -$x['members'], $x['name']] <=> [$y['_o'], -$y['members'], $y['name']]);
        foreach ($out as &$o) unset($o['_o']);
        unset($o);
        return array_slice($out, 0, max(1, min(200, $limit)));
    }

    /** A place and the places near it, with how near: 0 the place, 1 the area it's in (or its towns), 2 its neighbors, 3 the region. */
    private static function nearKeys(PDO $pdo, string $key): array
    {
        $out = [$key => 0];
        if (!preg_match('/^(hub|geo_hub|cluster):(\d+)$/', $key, $m)) return $out;
        $id = (int) $m[2];
        $col = function (string $sql, array $a) use ($pdo) { $st = $pdo->prepare($sql); $st->execute($a); return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)); };
        try {
            if ($m[1] === 'cluster') {
                $gh = $col('SELECT geo_hub_id FROM micro_clusters WHERE id = ?', [$id])[0] ?? 0;
                if ($gh) {
                    $out['geo_hub:' . $gh] = 1;
                    foreach ($col('SELECT id FROM micro_clusters WHERE geo_hub_id = ? AND id <> ?', [$gh, $id]) as $c) $out['cluster:' . $c] = 2;
                    $hub = $col('SELECT hub_id FROM geo_hubs WHERE id = ?', [$gh])[0] ?? 0;
                    if ($hub) $out['hub:' . $hub] = 3;
                }
            } elseif ($m[1] === 'geo_hub') {
                foreach ($col('SELECT id FROM micro_clusters WHERE geo_hub_id = ?', [$id]) as $c) $out['cluster:' . $c] = 1;
                $hub = $col('SELECT hub_id FROM geo_hubs WHERE id = ?', [$id])[0] ?? 0;
                if ($hub) $out['hub:' . $hub] = 3;
            } else {
                foreach ($col('SELECT id FROM geo_hubs WHERE hub_id = ?', [$id]) as $g) $out['geo_hub:' . $g] = 1;
                foreach ($col('SELECT mc.id FROM micro_clusters mc JOIN geo_hubs g ON g.id = mc.geo_hub_id WHERE g.hub_id = ?', [$id]) as $c) $out['cluster:' . $c] = 2;
            }
        } catch (Throwable) {}
        return $out;
    }

    /** The groups this person belongs to (or asked to join). */
    public static function mine(PDO $pdo, int $uid): array
    {
        $st = $pdo->prepare("SELECT g.id, g.name, m.role, m.status FROM community_group_members m JOIN community_groups g ON g.id = m.group_id
                              WHERE m.user_id = ? AND g.status = 'active' ORDER BY g.name");
        $st->execute([$uid]);
        return array_map(fn ($r) => ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'role' => (string) $r['role'], 'status' => (string) $r['status']],
            $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /**
     * Starts a group. $listingId > 0: the business's one group (its Owner or Manager starts it; it doesn't use up their
     * 5). $charter: the charter's parts (GroupCharters::clean); every new group opens with a purpose.
     */
    public static function create(PDO $pdo, int $uid, string $name, string $about, string $mode, string $place = '', string $topic = '', int $listingId = 0, array $charter = []): int
    {
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);   // limited accounts can't post or send (decisions/0079)
        require_once __DIR__ . '/MemberVerification.php';
        MemberVerification::require($pdo, $uid, 'steward');   // running a community needs Verification (decisions/0062 §4)
        require_once __DIR__ . '/GroupCharters.php';
        [$place] = self::place($pdo, $place);
        $name = trim(mb_substr(strip_tags($name), 0, 80));
        if (mb_strlen($name) < 3) throw new InvalidArgumentException('Give the group a name (at least 3 letters).');
        $owners = self::ownersReady($pdo);
        $bizName = '';
        if ($listingId > 0) {
            if (!$owners) throw new InvalidArgumentException('Business groups aren\'t switched on yet.');
            require_once __DIR__ . '/Team.php';
            if (!in_array(Team::roleOf($pdo, $uid, $listingId), ['owner', 'manager'], true)) throw new InvalidArgumentException('Only the business\'s Owner or a Manager can start its group.');
            $st = $pdo->prepare("SELECT id FROM community_groups WHERE owner_kind = 'listing' AND owner_ref = ? AND status IN ('active', 'hidden') LIMIT 1");
            $st->execute([$listingId]);
            if ($st->fetchColumn() !== false) throw new InvalidArgumentException('This business already has its group. A business has one group, with chapters for its places and topics.');
            $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([$listingId]); $bizName = (string) $st->fetchColumn();
        } else {
            $st = $pdo->prepare("SELECT COUNT(*) FROM community_groups WHERE owner_id = ? AND status = 'active'" . ($owners ? " AND owner_kind = 'person'" : ''));
            $st->execute([$uid]);
            if ((int) $st->fetchColumn() >= self::MAX_OWNED) throw new InvalidArgumentException('One person can run up to ' . self::MAX_OWNED . ' groups.');
        }
        $st = $pdo->prepare("SELECT 1 FROM community_groups WHERE name = ? AND status = 'active'");
        $st->execute([$name]);
        if ($st->fetchColumn() !== false) throw new InvalidArgumentException('There\'s already a group with that name. Join it, or pick another name.');
        $charters = GroupCharters::ready($pdo);
        if ($charters) {   // checked before anything is made, so a missing purpose makes nothing
            $kind = $listingId > 0 ? 'business' : (string) ($charter['kind'] ?? ($place !== '' ? 'local' : 'interest'));
            $charter = GroupCharters::clean($charter, GroupCharters::template(isset(GroupCharters::KINDS[$kind]) ? $kind : 'interest', $bizName), $listingId > 0);
            if ($charter['transfer'] === 'successor') $charter['transfer'] = 'end';   // a successor is named once the group has members
        }
        $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO community_groups (name, about, owner_id, join_mode, created_at) VALUES (?, ?, ?, ?, ?)')
                ->execute([$name, trim(mb_substr(strip_tags($about), 0, 1000)), $uid, $mode === 'approval' ? 'approval' : 'open', self::now()]);
            $gid = (int) $pdo->lastInsertId();
            if ($place !== '' && self::placesReady($pdo)) $pdo->prepare('UPDATE community_groups SET place_key = ? WHERE id = ?')->execute([$place, $gid]);
            if (isset(self::TOPICS[$topic]) && self::topicsReady($pdo)) $pdo->prepare('UPDATE community_groups SET topic = ? WHERE id = ?')->execute([$topic, $gid]);
            if ($listingId > 0) $pdo->prepare("UPDATE community_groups SET owner_kind = 'listing', owner_ref = ? WHERE id = ?")->execute([$listingId, $gid]);
            // a person's group: its starter is its owner. A business's group: the starter is a member; the team runs it by role.
            $pdo->prepare('INSERT INTO community_group_members (group_id, user_id, role, status, joined_at) VALUES (?, ?, ?, \'active\', ?)')
                ->execute([$gid, $uid, $listingId > 0 ? 'member' : 'owner', self::now()]);
            if ($charters) GroupCharters::save($pdo, $gid, $uid, $charter, $listingId > 0, [], true);
            if ($pdo->inTransaction()) $pdo->commit();
        } catch (Throwable $x) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $x; }
        if ($charters) self::markRead($pdo, $gid, $uid);
        if ($place !== '') self::tellFollowers($pdo, $gid, $uid, $name, $place);
        return $gid;
    }

    /** A notice to whoever links (follows) the group's place: a new group started there (0137 §6). Once per group. */
    public static function tellFollowers(PDO $pdo, int $gid, int $uid, string $name, string $place): void
    {
        if (!is_file(__DIR__ . '/Notices.php')) return;
        require_once __DIR__ . '/Notices.php';
        try {
            $st = $pdo->prepare("SELECT user_id FROM user_links WHERE target_type = 'place' AND target_id = ? AND muted = 0 AND user_id <> ?");
            $st->execute([$place, $uid]);
            $ids = array_values(array_filter(array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)), fn ($f) => !People::blocked($pdo, $f, $uid)));
            [, $label] = self::place($pdo, $place);
            Notices::send($pdo, $ids, 'group_near', 'group:' . $gid, 'A new group in ' . $label . ': ' . $name, 'You follow ' . $label . '.', '/community/group.php?id=' . $gid);
        } catch (Throwable $e) { error_log('group notice: ' . $e->getMessage()); }
    }

    /** Sends a group notice through Notices, if it's there. */
    private static function notify(PDO $pdo, array $ids, string $kind, string $thing, string $title, string $body, string $url): void
    {
        if (!is_file(__DIR__ . '/Notices.php')) return;
        require_once __DIR__ . '/Notices.php';
        try { Notices::send($pdo, $ids, $kind, $thing, $title, $body, $url); } catch (Throwable $e) { error_log('group notice: ' . $e->getMessage()); }
    }

    public static function edit(PDO $pdo, int $uid, int $gid, string $about, string $mode, ?string $place = null, ?string $topic = null): void
    {
        if (!self::canModerate($pdo, $gid, $uid)) throw new InvalidArgumentException('Only the group\'s owner or moderators can do that.');
        if ($topic !== null && self::topicsReady($pdo)) $pdo->prepare('UPDATE community_groups SET topic = ? WHERE id = ?')->execute([isset(self::TOPICS[$topic]) ? $topic : null, $gid]);
        if ($place !== null && self::placesReady($pdo)) {
            [$place] = self::place($pdo, $place);
            $pdo->prepare('UPDATE community_groups SET place_key = ? WHERE id = ?')->execute([$place !== '' ? $place : null, $gid]);
        }
        $pdo->prepare('UPDATE community_groups SET about = ?, join_mode = ? WHERE id = ?')
            ->execute([trim(mb_substr(strip_tags($about), 0, 1000)), $mode === 'approval' ? 'approval' : 'open', $gid]);
    }

    /**
     * Joins an open group, or asks to join an approval group. Returns the new status. $o (0136 §5c): 'source' (how they
     * came, counted: page, place, search, share, like), 'code' (an invite code), 'answers' (to the join questions),
     * 'cascade' (false: don't follow the parent's chapter rule). An invitation, or a code made to let people in, skips
     * approval when the charter says so; the person still reads and agrees to the charter.
     */
    public static function join(PDO $pdo, int $uid, int $gid, ?int $charterVersion = null, array $o = []): string
    {
        $g = self::group($pdo, $gid) ?? throw new InvalidArgumentException('That group isn\'t available.');
        if ($m = self::membership($pdo, $gid, $uid)) return (string) $m['status'];
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);
        require_once __DIR__ . '/GroupCharters.php';
        $grow = self::growReady($pdo);
        if ($grow && $g['parent_id'] > 0) {   // the parent's charter decides how its chapters are joined (0136 §2)
            $p = self::group($pdo, $g['parent_id']);
            if ($p && ($p['chapter_join'] ?? 'both') === 'parent' && !self::isMember($pdo, $p['id'], $uid))
                throw new InvalidArgumentException('Chapters of ' . $p['name'] . ' are for its members: join ' . $p['name'] . ' first, then this chapter.');
        }
        $c = GroupCharters::current($pdo, $gid);
        // joining is consent to the charter they read (0137 §3): if it changed since, they read it again first
        if ($c && $charterVersion !== null && $charterVersion !== $c['version']) throw new InvalidArgumentException('The charter changed while you were reading. Have a look at it again, then join.');
        $status = $g['join_mode'] === 'approval' ? 'pending' : 'active';
        $source = (string) ($o['source'] ?? 'page'); $invitedBy = null; $code = null;
        if ($grow) {
            $inv = GroupGrowth::invitationFor($pdo, $gid, $uid);
            if ($inv) {
                $invitedBy = $inv['from_id']; $source = 'invite';
                $skip = $c ? (string) $c['invites_skip'] : 'never';   // whether an invitation skips approval: the charter's choice
                if ($status === 'pending' && ($skip === 'members' && self::isMember($pdo, $gid, $inv['from_id']) || $skip === 'moderators' && self::can($pdo, $gid, $inv['from_id'], 'moderate'))) $status = 'active';
            }
            if (!empty($o['code'])) {
                $code = GroupGrowth::codeFor($pdo, $gid, (string) $o['code']);
                if (!$code) throw new InvalidArgumentException('That invite code isn\'t working: it may have ended or been used up. You can still ask to join.');
                $source = 'code';
                if ($status === 'pending' && $code['skip'] && $c && (int) $c['codes_skip'] === 1) $status = 'active';
            }
        }
        $answers = null;
        if ($status === 'pending' && $c && $c['join_questions'] && isset($o['answers']) && is_array($o['answers'])) {
            $answers = [];
            foreach (array_values($c['join_questions']) as $k => $qn) $answers[] = [$qn, trim(mb_substr(strip_tags((string) ($o['answers'][$k] ?? '')), 0, 500))];
            $answers = json_encode($answers);
        }
        if ($grow) $pdo->prepare("INSERT INTO community_group_members (group_id, user_id, role, status, joined_at, answers, invited_by, via) VALUES (?, ?, 'member', ?, ?, ?, ?, ?)")
            ->execute([$gid, $uid, $status, self::now(), $answers, $invitedBy, $source]);
        else $pdo->prepare("INSERT INTO community_group_members (group_id, user_id, role, status, joined_at) VALUES (?, ?, 'member', ?, ?)")->execute([$gid, $uid, $status, self::now()]);
        if ($c) self::markRead($pdo, $gid, $uid, $c['version']);
        if ($grow) {
            if ($invitedBy !== null) GroupGrowth::answerInvite($pdo, $gid, $uid, 'joined');
            if ($code) GroupGrowth::codeUsed($pdo, $code['id']);
            GroupGrowth::countJoin($pdo, $gid, $source);
            if ($status === 'active') self::welcome($pdo, $g, $uid);
            if (($o['cascade'] ?? true) !== false && $g['parent_id'] > 0) { require_once __DIR__ . '/GroupChapters.php'; GroupChapters::afterJoin($pdo, $uid, $g); }
        }
        if ($status === 'pending') { try { require_once __DIR__ . '/GroupNotices.php'; GroupNotices::joinAsked($pdo, $g, $uid); } catch (Throwable $e) { error_log('group join notice: ' . $e->getMessage()); } }   // its moderators, with Accept and Decline (decisions/0172 §2.8)
        return $status;
    }

    /** The group's welcome message, to a new member, once (0136 §5). */
    private static function welcome(PDO $pdo, array $g, int $uid): void
    {
        $msg = trim((string) ($g['welcome_msg'] ?? ''));
        if ($msg === '') return;
        self::notify($pdo, [$uid], 'group_join', 'welcome:' . (int) $g['id'], 'Welcome to ' . $g['name'], mb_strimwidth($msg, 0, 380, '…'), '/community/group.php?id=' . (int) $g['id']);
    }

    /** Whoever runs the group sets its welcome message and pins (or unpins, 0) the one post anyone can read. */
    public static function setWelcome(PDO $pdo, int $uid, int $gid, ?string $msg, ?int $postId): void
    {
        if (!self::growReady($pdo)) throw new InvalidArgumentException('Welcome messages aren\'t switched on yet.');
        if (!self::can($pdo, $gid, $uid, 'run')) throw new InvalidArgumentException('Only whoever runs the group can do that.');
        if ($msg !== null) $pdo->prepare('UPDATE community_groups SET welcome_msg = ? WHERE id = ?')->execute([trim(mb_substr(strip_tags($msg), 0, 1000)) ?: null, $gid]);
        if ($postId !== null) {
            if ($postId > 0) {
                $st = $pdo->prepare('SELECT 1 FROM community_posts WHERE id = ? AND group_id = ? AND removed_at IS NULL' . (self::heldReady($pdo) ? ' AND held_at IS NULL' : '')); $st->execute([$postId, $gid]);
                if ($st->fetchColumn() === false) throw new InvalidArgumentException('That post isn\'t in the group any more.');
            }
            $pdo->prepare('UPDATE community_groups SET welcome_post_id = ? WHERE id = ?')->execute([$postId > 0 ? $postId : null, $gid]);
        }
    }

    /** The pinned welcome post, which anyone can read (every other post stays members-only): [author, author_url, body, at] or null. */
    public static function welcomePost(PDO $pdo, array $g): ?array
    {
        $pid = (int) ($g['welcome_post_id'] ?? 0);
        if ($pid <= 0) return null;
        $voices = self::ownersReady($pdo);
        $st = $pdo->prepare('SELECT id, user_id, body, created_at' . ($voices ? ', voice, as_listing' : '') . ' FROM community_posts WHERE id = ? AND group_id = ? AND removed_at IS NULL' . (self::heldReady($pdo) ? ' AND held_at IS NULL' : ''));
        $st->execute([$pid, (int) $g['id']]);
        $p = $st->fetch(PDO::FETCH_ASSOC);
        if (!$p) return null;
        $biz = null; [$who, $url] = self::byline($pdo, $p, People::user($pdo, (int) $p['user_id']), $biz);
        return ['id' => $pid, 'author' => $who, 'author_url' => $url, 'body' => class_exists('Tags') ? Tags::plain((string) $p['body']) : (string) $p['body'], 'at' => (string) $p['created_at']];
    }

    /** The charter version the person has read (joining, or "Got it" after a change), so they're told of a change once. */
    public static function markRead(PDO $pdo, int $gid, int $uid, ?int $version = null): void
    {
        require_once __DIR__ . '/GroupCharters.php';
        if (!GroupCharters::ready($pdo)) return;
        if ($version === null) {   // everything written so far, a change still waiting for its date included: they were told it's coming
            $st = $pdo->prepare('SELECT MAX(version) FROM community_charters WHERE group_id = ?'); $st->execute([$gid]);
            $version = (int) $st->fetchColumn(); if ($version < 1) return;
        }
        try { $pdo->prepare('UPDATE community_group_members SET charter_version = ? WHERE group_id = ? AND user_id = ?')->execute([$version, $gid, $uid]); } catch (Throwable) {}
    }

    /** A member hides (or shows) their own name in the member list. Moderators still see them, to run the group. */
    public static function hideSelf(PDO $pdo, int $uid, int $gid, bool $hidden): void
    {
        if (!self::membership($pdo, $gid, $uid)) throw new InvalidArgumentException('You aren\'t in this group.');
        $pdo->prepare('UPDATE community_group_members SET list_hidden = ? WHERE group_id = ? AND user_id = ?')->execute([$hidden ? 1 : 0, $gid, $uid]);
    }

    /** Saves the charter as a new version: the owner of a person's group; the Owner or a Manager of a business's group. */
    public static function saveCharter(PDO $pdo, int $uid, int $gid, array $in): array
    {
        $g = self::group($pdo, $gid) ?? throw new InvalidArgumentException('That group isn\'t available.');
        if (!self::can($pdo, $gid, $uid, 'run', $g)) throw new InvalidArgumentException('Only the group\'s owner can change its charter' . ($g['owner_kind'] === 'listing' ? ' (the business\'s Owner or a Manager).' : '.'));
        require_once __DIR__ . '/GroupCharters.php';
        $st = $pdo->prepare("SELECT user_id FROM community_group_members WHERE group_id = ? AND status = 'active'"); $st->execute([$gid]);
        $members = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        $out = GroupCharters::save($pdo, $gid, $uid, $in, $g['owner_kind'] === 'listing', $members);
        self::markRead($pdo, $gid, $uid);
        // members are told once per change (0137 §6): what changed, and when a part that waits takes effect
        $pend = GroupCharters::pending($pdo, $gid); $cur = GroupCharters::current($pdo, $gid);
        $note = $pend ? (string) $pend['note'] : (string) ($cur['note'] ?? '');
        $ver = $pend ? (int) $pend['version'] : (int) ($cur['version'] ?? 0);
        if ($ver > 1) self::notify($pdo, array_diff($members, [$uid]), 'group_charter', 'charter:' . $gid . ':' . $ver, 'The charter of ' . $g['name'] . ' changed',
                                  $note, '/community/group.php?id=' . $gid . '#charter');
        return $out;
    }

    /** Leaves the group; with $chapters, its chapters too (the ones they don't lead). */
    public static function leave(PDO $pdo, int $uid, int $gid, bool $chapters = false): void
    {
        $m = self::membership($pdo, $gid, $uid);
        if ($m && $m['role'] === 'owner') throw new InvalidArgumentException('You run this group: hide it instead, or make someone else owner first.');
        $pdo->prepare('DELETE FROM community_group_members WHERE group_id = ? AND user_id = ?')->execute([$gid, $uid]);
        if ($chapters && self::growReady($pdo)) $pdo->prepare("DELETE m FROM community_group_members m JOIN community_groups g ON g.id = m.group_id AND g.parent_id = ? WHERE m.user_id = ? AND m.role <> 'owner'")->execute([$gid, $uid]);
        if (self::growReady($pdo)) GroupGrowth::answerInvite($pdo, $gid, $uid, 'declined');   // a pending request withdrawn closes its invitation
    }

    /** Owner or moderator: accept or decline a request, remove a member, or (owner) make someone a moderator. */
    public static function manage(PDO $pdo, int $uid, int $gid, int $member, string $what): void
    {
        if (!self::canModerate($pdo, $gid, $uid)) throw new InvalidArgumentException('Only the group\'s owner or moderators can do that.');
        $m = self::membership($pdo, $gid, $member) ?? throw new InvalidArgumentException('They aren\'t in this group.');
        if ($m['role'] === 'owner') throw new InvalidArgumentException('The owner can\'t be changed here.');
        $isOwner = self::can($pdo, $gid, $uid, 'run');
        switch ($what) {
            case 'accept':   $pdo->prepare("UPDATE community_group_members SET status = 'active', joined_at = ? WHERE group_id = ? AND user_id = ?")->execute([self::now(), $gid, $member]);
                             if ($m['status'] === 'pending') { $gg = self::group($pdo, $gid); $wm = trim((string) ($gg['welcome_msg'] ?? '')); self::notify($pdo, [$member], 'group_join', 'join:' . $gid, 'You\'re in: ' . ($gg['name'] ?? 'the group'), $wm !== '' ? mb_strimwidth($wm, 0, 380, '…') : 'Your request to join was accepted.', '/community/group.php?id=' . $gid); }
                             break;
            case 'decline':
                if ($what === 'decline' && $m['status'] === 'pending') { $gg = self::group($pdo, $gid); self::notify($pdo, [$member], 'group_join', 'join:' . $gid, 'Your request to join ' . ($gg['name'] ?? 'the group') . ' wasn\'t accepted', 'You can look for other groups like it.', '/community/'); }
            case 'remove':
                if ($m['role'] === 'moderator' && !$isOwner) throw new InvalidArgumentException('Only the owner can remove a moderator.');
                $pdo->prepare('DELETE FROM community_group_members WHERE group_id = ? AND user_id = ?')->execute([$gid, $member]); break;
            case 'moderator':
            case 'member':
                if (!$isOwner) throw new InvalidArgumentException('Only the owner can choose moderators.');
                $pdo->prepare('UPDATE community_group_members SET role = ? WHERE group_id = ? AND user_id = ?')->execute([$what, $gid, $member]); break;
            default: throw new InvalidArgumentException('Unknown action.');
        }
    }

    /** Hide (owner or admin) or show again (admin). */
    public static function setHidden(PDO $pdo, int $uid, int $gid, bool $hidden, bool $admin): void
    {
        if (!$admin && !($hidden && self::can($pdo, $gid, $uid, 'hide'))) throw new InvalidArgumentException('Only the owner can hide this group.');
        $pdo->prepare('UPDATE community_groups SET status = ? WHERE id = ?')->execute([$hidden ? 'hidden' : 'active', $gid]);
    }

    /** Members only: names, roles; moderators also see requests. People you've blocked (either way) are left out. */
    public static function members(PDO $pdo, int $viewer, int $gid): array
    {
        if (!self::isMember($pdo, $gid, $viewer)) return [];
        $mod = self::canModerate($pdo, $gid, $viewer);
        require_once __DIR__ . '/GroupCharters.php';
        $c = GroupCharters::current($pdo, $gid);
        $onlyMods = $c && $c['member_list'] === 'moderators' && !$mod;   // the charter keeps the list to the moderators (0137 §3)
        $hidden = self::ownersReady($pdo) && GroupCharters::ready($pdo);
        $grow = $mod && self::growReady($pdo);
        $st = $pdo->prepare('SELECT user_id, role, status' . ($hidden ? ', list_hidden' : '') . ($grow ? ', answers, invited_by, via' : '') . ' FROM community_group_members WHERE group_id = ? ORDER BY role = \'owner\' DESC, role = \'moderator\' DESC, joined_at');
        $st->execute([$gid]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $id = (int) $r['user_id'];
            if ($r['status'] === 'pending' && !$mod) continue;
            if ($id !== $viewer && !$mod && ($onlyMods ? !in_array($r['role'], ['owner', 'moderator'], true) : !empty($r['list_hidden']))) continue;
            if ($id !== $viewer && People::blocked($pdo, $viewer, $id)) continue;
            $u = People::user($pdo, $id);
            if (!$u) continue;
            $row = ['id' => $id, 'name' => People::name($u), 'role' => (string) $r['role'], 'status' => (string) $r['status'], 'list_hidden' => !empty($r['list_hidden'])];
            if ($grow && $r['status'] === 'pending') {   // for the moderators deciding: the answers, and who invited them or the code they used
                $ib = (int) ($r['invited_by'] ?? 0); $iu = $ib ? People::user($pdo, $ib) : null;
                $row['answers'] = json_decode((string) ($r['answers'] ?? ''), true) ?: [];
                $row['invited_by'] = $iu ? People::name($iu) : null; $row['via'] = (string) ($r['via'] ?? '');
            }
            $out[] = $row;
        }
        return $out;
    }

    /** Members only: the group's posts, newest first. */
    public static function posts(PDO $pdo, int $viewer, int $gid, int $before = 0): array
    {
        if (!self::isMember($pdo, $gid, $viewer)) return [];
        $mod = self::canModerate($pdo, $gid, $viewer);
        $voices = self::ownersReady($pdo);
        $biz = null;
        $held = self::heldReady($pdo);
        $grow = self::growReady($pdo);
        $from = []; $pinned = 0;
        if ($grow) { $gg = self::group($pdo, $gid, true); $pinned = (int) ($gg['welcome_post_id'] ?? 0); }
        $st = $pdo->prepare('SELECT id, user_id, body, created_at' . ($voices ? ', voice, as_listing' : '') . ($held ? ', held_at' : '') . ($grow ? ', from_group_id' : '') . ' FROM community_posts WHERE group_id = ? AND removed_at IS NULL'
            . ($before > 0 ? ' AND id < ?' : '') . ' ORDER BY id DESC LIMIT 50');
        $st->execute($before > 0 ? [$gid, $before] : [$gid]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $p) {
            $a = (int) $p['user_id'];
            if ($a !== $viewer && People::blocked($pdo, $viewer, $a)) continue;
            $isHeld = !empty($p['held_at']);
            if ($isHeld && $a !== $viewer && !$mod) continue;   // held while it's looked at: its author and the moderators still see it
            $u = People::user($pdo, $a);
            [$author, $url] = self::byline($pdo, $p, $u, $biz);
            $fg = (int) ($p['from_group_id'] ?? 0);
            if ($fg && !isset($from[$fg])) { $fs = $pdo->prepare('SELECT name FROM community_groups WHERE id = ?'); $fs->execute([$fg]); $from[$fg] = (string) $fs->fetchColumn(); }
            $out[] = ['id' => (int) $p['id'], 'author_id' => $a, 'author' => $author, 'author_url' => $url, 'voice' => (string) ($p['voice'] ?? 'person'),
                      'body' => (string) $p['body'], 'at' => (string) $p['created_at'], 'can_remove' => $a === $viewer || $mod, 'held' => $isHeld,
                      'from' => $fg ? ['id' => $fg, 'name' => $from[$fg]] : null, 'pinned' => (int) $p['id'] === $pinned];
        }
        return $out;
    }

    /**
     * Posts in the group. $voice: 'person' (themselves), 'business' (as the business: its Owner, Managers and Creators),
     * 'sales' (as its rep, "Name · Sales, <business>"). No daily cap (0137 §7); the same words twice in a day are held.
     */
    public static function post(PDO $pdo, int $uid, int $gid, string $body, string $voice = 'person', bool $allChapters = false): int
    {
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);   // limited accounts can't post or send (decisions/0079)
        $g = self::group($pdo, $gid);
        if (!$g || !self::isMember($pdo, $gid, $uid)) throw new InvalidArgumentException('Join the group to post.');
        $voice = in_array($voice, ['business', 'sales'], true) ? $voice : 'person';
        if ($voice === 'business' && !self::can($pdo, $gid, $uid, 'business', $g)) throw new InvalidArgumentException('Only the business\'s Owner, Managers and Creators post as the business.');
        if ($voice === 'sales' && !self::can($pdo, $gid, $uid, 'rep', $g)) throw new InvalidArgumentException('Only the business\'s Sales team posts as its rep.');
        $body = trim(mb_substr(strip_tags(str_replace("\r", '', $body)), 0, self::MAX_POST));
        if ($body === '') throw new InvalidArgumentException('Write something first.');
        $st = $pdo->prepare('SELECT 1 FROM community_posts WHERE user_id = ? AND group_id = ? AND body = ? AND created_at > ? AND removed_at IS NULL LIMIT 1');
        $st->execute([$uid, $gid, $body, date('Y-m-d H:i:s', time() - 86400)]);
        if ($st->fetchColumn() !== false) throw new InvalidArgumentException('You posted that already today.');
        // @tags (decisions/0051 §3): checked, and only place and topic tags counted, anonymously.
        $tags = [];
        if (class_exists('Tags')) [$body, $tags] = Tags::clean($pdo, $body);
        if (self::ownersReady($pdo)) $pdo->prepare('INSERT INTO community_posts (group_id, user_id, body, created_at, voice, as_listing) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$gid, $uid, $body, self::now(), $voice, $voice !== 'person' ? $g['owner_ref'] : null]);
        else $pdo->prepare('INSERT INTO community_posts (group_id, user_id, body, created_at) VALUES (?, ?, ?, ?)')->execute([$gid, $uid, $body, self::now()]);
        $pid = (int) $pdo->lastInsertId();
        if ($tags) Tags::record($pdo, $tags, $uid, $gid, (string) ($g['place_key'] ?? ''));
        if (str_contains($body, '@[')) { require_once __DIR__ . '/ContentTags.php'; ContentTags::mentions($pdo, 'post:' . $pid, $body, $uid); }   // @tags: the author's own, never the Chameleon Filter's (decisions/0132 §2a)
        try {   // its members, by their link settings; anyone mentioned, as a mention (decisions/0172 §2.8)
            require_once __DIR__ . '/GroupNotices.php';
            $biz = null; [$who] = self::byline($pdo, ['voice' => $voice, 'as_listing' => $voice !== 'person' ? $g['owner_ref'] : 0, 'user_id' => $uid], People::user($pdo, $uid), $biz);
            GroupNotices::posted($pdo, $g, $pid, $uid, $body, $who);
        } catch (Throwable $e) { error_log('group post notice: ' . $e->getMessage()); }
        // the parent's owner and moderators post to all its chapters at once: it appears in each, marked "From <group>" (0136 §2)
        $n = 0;
        if ($allChapters) {
            if (!self::growReady($pdo) || !self::can($pdo, $gid, $uid, 'moderate', $g)) throw new InvalidArgumentException('Only the group\'s owner and moderators post to all its chapters.');
            $st = $pdo->prepare("SELECT id FROM community_groups WHERE parent_id = ? AND status = 'active'"); $st->execute([$gid]);
            $ins = $pdo->prepare('INSERT INTO community_posts (group_id, user_id, body, created_at, voice, as_listing, from_group_id) VALUES (?, ?, ?, ?, ?, ?, ?)');
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $cid) { $ins->execute([(int) $cid, $uid, $body, self::now(), $voice, $voice !== 'person' ? $g['owner_ref'] : null, $gid]); $n++; }
        }
        return $n;
    }

    /** How a post is signed: [name, link]. The business's name for its voice; "Name · Sales, <business>" for its rep. */
    private static function byline(PDO $pdo, array $p, ?array $u, ?string &$biz): array
    {
        $voice = (string) ($p['voice'] ?? 'person'); $lid = (int) ($p['as_listing'] ?? 0);
        if ($voice !== 'person' && $lid > 0) {
            if ($biz === null) { $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([$lid]); $biz = (string) ($st->fetchColumn() ?: 'the business'); }
            if ($voice === 'business') return [$biz, '/listing/view.php?id=' . $lid];
            return [($u ? People::name($u) : 'Someone') . ' · Sales, ' . $biz, '/listing/view.php?id=' . $lid];
        }
        return [$u ? People::name($u) : 'Someone who left', '/user/profile.php?id=' . (int) $p['user_id']];
    }

    public static function removePost(PDO $pdo, int $uid, int $postId): void
    {
        $st = $pdo->prepare('SELECT group_id, user_id FROM community_posts WHERE id = ? AND removed_at IS NULL');
        $st->execute([$postId]);
        $p = $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('That post is gone.');
        if ((int) $p['user_id'] !== $uid && !self::canModerate($pdo, (int) $p['group_id'], $uid)) throw new InvalidArgumentException('You can remove your own posts only.');
        $pdo->prepare('UPDATE community_posts SET removed_at = ? WHERE id = ?')->execute([self::now(), $postId]);
    }

    private static function heldReady(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT held_at FROM community_posts LIMIT 0'); $pdo->query('SELECT route FROM content_reports LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    /** Whether the person handles the group's reports: the moderators, or only whoever runs it (the charter's choice). */
    public static function handlesReports(PDO $pdo, int $gid, int $uid, ?array $g = null): bool
    {
        require_once __DIR__ . '/GroupCharters.php';
        $c = GroupCharters::current($pdo, $gid);
        return ($c && $c['reports_by'] === 'owner') ? self::can($pdo, $gid, $uid, 'run', $g) : self::can($pdo, $gid, $uid, 'moderate', $g);
    }

    /**
     * After a report on a group's post (Reports::file): holds the post when the charter says so. Counted: different
     * reporters, each a member for more than 7 days, so friends can't team up; private information, a sacred site or
     * danger hold it at the first report. "Only when a moderator decides" (hide_after 0) never holds by count.
     */
    public static function reportFiled(PDO $pdo, int $postId, string $reason): void
    {
        if (!self::heldReady($pdo)) return;
        $st = $pdo->prepare('SELECT group_id FROM community_posts WHERE id = ? AND removed_at IS NULL'); $st->execute([$postId]);
        $gid = (int) $st->fetchColumn(); if (!$gid) return;
        require_once __DIR__ . '/Reports.php';
        require_once __DIR__ . '/GroupCharters.php';
        $hold = in_array($reason, Reports::HOLD_AT_ONCE, true);
        if (!$hold) {
            $c = GroupCharters::current($pdo, $gid);
            $need = $c ? (int) $c['hide_after'] : 3;
            if ($need > 0) {
                $st = $pdo->prepare("SELECT COUNT(DISTINCT r.reporter_id) FROM content_reports r JOIN community_group_members m ON m.group_id = ? AND m.user_id = r.reporter_id AND m.status = 'active' AND m.joined_at < ?
                                      WHERE r.kind = 'group_post' AND r.target_id = ? AND r.status = 'open'");
                $st->execute([$gid, date('Y-m-d H:i:s', time() - 7 * 86400), $postId]);
                $hold = (int) $st->fetchColumn() >= $need;
            }
        }
        if ($hold) $pdo->prepare('UPDATE community_posts SET held_at = COALESCE(held_at, ?) WHERE id = ?')->execute([self::now(), $postId]);
        try { require_once __DIR__ . '/GroupNotices.php'; GroupNotices::reported($pdo, $postId, $reason); } catch (Throwable $e) { error_log('group report notice: ' . $e->getMessage()); }   // whoever handles its reports, with Keep and Remove (decisions/0172 §2.8)
    }

    /** Lets a held post show again once no report on it is open (after Traversence's Safety team dismissed theirs). */
    public static function unholdIfClear(PDO $pdo, int $postId): void
    {
        if (!self::heldReady($pdo)) return;
        $st = $pdo->prepare("SELECT 1 FROM content_reports WHERE kind = 'group_post' AND target_id = ? AND status = 'open' LIMIT 1"); $st->execute([$postId]);
        if ($st->fetchColumn() === false) $pdo->prepare('UPDATE community_posts SET held_at = NULL WHERE id = ?')->execute([$postId]);
    }

    /** The group's own report queue (for whoever handles reports): each reported post, why, how many, how long it's waited. Reporters are never shown. */
    public static function reportQueue(PDO $pdo, int $gid, int $uid): array
    {
        if (!self::heldReady($pdo) || !self::handlesReports($pdo, $gid, $uid)) return [];
        require_once __DIR__ . '/Reports.php';
        $st = $pdo->prepare("SELECT p.id, p.user_id, p.body, p.held_at, COUNT(r.id) AS n, MIN(r.created_at) AS first_at, GROUP_CONCAT(DISTINCT r.reason) AS reasons
                               FROM content_reports r JOIN community_posts p ON p.id = r.target_id AND p.group_id = ? AND p.removed_at IS NULL
                              WHERE r.kind = 'group_post' AND r.status = 'open' AND r.route = 'group' GROUP BY p.id, p.user_id, p.body, p.held_at ORDER BY first_at LIMIT 50");
        $st->execute([$gid]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $u = People::user($pdo, (int) $r['user_id']);
            $out[] = ['post_id' => (int) $r['id'], 'author' => $u ? People::name($u) : 'Someone who left', 'author_id' => (int) $r['user_id'], 'body' => mb_strimwidth((string) $r['body'], 0, 400, '…'),
                      'held' => $r['held_at'] !== null, 'reports' => (int) $r['n'], 'reasons' => array_map([Reports::class, 'label'], array_filter(explode(',', (string) $r['reasons']))),
                      'since' => (string) $r['first_at'], 'days' => (int) floor((time() - strtotime((string) $r['first_at'])) / 86400)];
        }
        return $out;
    }

    /** How many reported posts wait in the groups this person handles reports for (their Pulse). [count, oldest days]. */
    public static function reportsWaiting(PDO $pdo, int $uid, array $gids): array
    {
        if (!self::heldReady($pdo) || !$gids) return [0, 0];
        $mine = array_values(array_filter(array_map('intval', $gids), fn ($g) => self::handlesReports($pdo, $g, $uid)));
        if (!$mine) return [0, 0];
        $r = $pdo->query("SELECT COUNT(DISTINCT r.target_id), MIN(r.created_at) FROM content_reports r JOIN community_posts p ON p.id = r.target_id AND p.removed_at IS NULL
                           WHERE r.kind = 'group_post' AND r.status = 'open' AND r.route = 'group' AND p.group_id IN (" . implode(',', $mine) . ')')->fetch(PDO::FETCH_NUM);
        return [(int) $r[0], $r[1] ? (int) floor((time() - strtotime((string) $r[1])) / 86400) : 0];
    }

    /**
     * The group's decision on a reported post: keep (it shows again), remove, or remove it and its author. Closes the
     * group's reports on it; a report that went to Traversence (danger) stays with our Safety team. The group's
     * decision doesn't touch the author's standing on Traversence: that's ours (0079).
     */
    public static function decideReport(PDO $pdo, int $uid, int $postId, string $what): void
    {
        if (!in_array($what, ['keep', 'remove', 'remove_member'], true)) throw new InvalidArgumentException('Unknown action.');
        $st = $pdo->prepare('SELECT group_id, user_id FROM community_posts WHERE id = ? AND removed_at IS NULL'); $st->execute([$postId]);
        $p = $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('That post is gone.');
        $gid = (int) $p['group_id'];
        if (!self::handlesReports($pdo, $gid, $uid)) throw new InvalidArgumentException('This group\'s reports are handled by ' . (self::can($pdo, $gid, $uid, 'moderate') ? 'its owner, as its charter says.' : 'its moderators.'));
        if ($what === 'remove_member') {
            $m = self::membership($pdo, $gid, (int) $p['user_id']);
            if ($m && $m['role'] !== 'member' && !self::can($pdo, $gid, $uid, 'run')) throw new InvalidArgumentException('Only the owner can remove a moderator.');
            if ($m && $m['role'] === 'owner') throw new InvalidArgumentException('The owner can\'t be removed here.');
        }
        $pdo->prepare("UPDATE content_reports SET status = ?, handled_by = ?, handled_at = ? WHERE kind = 'group_post' AND target_id = ? AND status = 'open' AND route = 'group'")
            ->execute([$what === 'keep' ? 'dismissed' : 'removed', $uid, self::now(), $postId]);
        if ($what === 'keep') self::unholdIfClear($pdo, $postId);
        else {
            $pdo->prepare('UPDATE community_posts SET removed_at = ?, held_at = NULL WHERE id = ?')->execute([self::now(), $postId]);
            if ($what === 'remove_member') $pdo->prepare("DELETE FROM community_group_members WHERE group_id = ? AND user_id = ? AND role <> 'owner'")->execute([$gid, (int) $p['user_id']]);
            $gg = self::group($pdo, $gid);
            self::notify($pdo, [(int) $p['user_id']], 'group_post', 'post:' . $postId, 'Your post in ' . ($gg['name'] ?? 'a group') . ' was removed by its moderators',
                         $what === 'remove_member' ? 'You were removed from the group too.' : 'People reported it, and the group\'s moderators decided to remove it.', $what === 'remove_member' ? '/community/' : '/community/group.php?id=' . $gid);
        }
    }

    /** The group's leaders ask Traversence for help: a "Group help" case in our Pulse (0102 §5, 0137 §5). Returns its case number (0 before the Pulse update). */
    public static function askHelp(PDO $pdo, int $uid, int $gid, string $body): int
    {
        if (!self::can($pdo, $gid, $uid, 'moderate') && !self::can($pdo, $gid, $uid, 'run')) throw new InvalidArgumentException('The group\'s owner and moderators can ask us for help here. Anyone else: use Report.');
        $body = trim(mb_substr(strip_tags($body), 0, 3000));
        if (mb_strlen($body) < 10) throw new InvalidArgumentException('Tell us what\'s happening, in a sentence or two.');
        $st = $pdo->prepare("SELECT COUNT(*) FROM community_help WHERE group_id = ? AND status = 'open'"); $st->execute([$gid]);
        if ((int) $st->fetchColumn() >= 3) throw new InvalidArgumentException('Your group has 3 requests open with us already. We\'ll be in touch.');
        $pdo->prepare("INSERT INTO community_help (group_id, user_id, body, source, created_at) VALUES (?, ?, ?, 'leaders', ?)")->execute([$gid, $uid, $body, self::now()]);
        $id = (int) $pdo->lastInsertId();
        if (is_file(__DIR__ . '/Pulse.php')) { try { require_once __DIR__ . '/Pulse.php'; return Pulse::openTicket($pdo, 'grouphelp:' . $id, $body); } catch (Throwable $e) { error_log('group help: ' . $e->getMessage()); } }
        return 0;
    }

    /** How many posts the group had in the last $days days (the page's "at a glance", decisions/0137 §4). */
    public static function postsSince(PDO $pdo, int $gid, int $days = 7): int
    {
        $st = $pdo->prepare('SELECT COUNT(*) FROM community_posts WHERE group_id = ? AND removed_at IS NULL AND created_at > ?');
        $st->execute([$gid, date('Y-m-d H:i:s', time() - $days * 86400)]);
        return (int) $st->fetchColumn();
    }

    /** For the Community feed: recent posts in the person's groups. */
    public static function feed(PDO $pdo, int $uid, int $limit = 20): array
    {
        $voices = self::ownersReady($pdo);
        $st = $pdo->prepare("SELECT p.id, p.group_id, g.name AS group_name, p.user_id, p.body, p.created_at" . ($voices ? ', p.voice, p.as_listing' : '') . " FROM community_posts p
                               JOIN community_group_members m ON m.group_id = p.group_id AND m.user_id = ? AND m.status = 'active'
                               JOIN community_groups g ON g.id = p.group_id AND g.status = 'active'
                              WHERE p.removed_at IS NULL" . (self::heldReady($pdo) ? ' AND p.held_at IS NULL' : '') . " AND p.user_id <> ? ORDER BY p.id DESC LIMIT " . max(1, min(50, $limit)));
        $st->execute([$uid, $uid]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $p) {
            if (People::blocked($pdo, $uid, (int) $p['user_id'])) continue;
            $u = People::user($pdo, (int) $p['user_id']);
            $biz = null; [$who] = self::byline($pdo, $p, $u, $biz);
            $out[] = ['kind' => 'group_post', 'title' => $who . ' in ' . $p['group_name'], 'body' => mb_strimwidth(class_exists('Tags') ? Tags::plain((string) $p['body']) : (string) $p['body'], 0, 200, '…'),
                      'url' => '/community/group.php?id=' . (int) $p['group_id'], 'when' => (string) $p['created_at'], 'from' => (string) $p['group_name'],
                      'post_id' => (int) $p['id']];   // so Pulse can report it in place (decisions/0172)
        }
        // a charter that changed since the person last read it: told once, until they read it (0137 §3, §6). With notices
        // switched on, the notice does this (Notices, 'group_charter'); this is only for before their migration has run
        require_once __DIR__ . '/GroupCharters.php';
        $noticesOn = false;
        if (is_file(__DIR__ . '/Notices.php')) { require_once __DIR__ . '/Notices.php'; $noticesOn = Notices::ready($pdo); }
        if (GroupCharters::ready($pdo) && !$noticesOn) {
            try {
                $st = $pdo->prepare("SELECT g.id, g.name, c.version, c.note, c.takes_effect_at FROM community_group_members m
                                       JOIN community_groups g ON g.id = m.group_id AND g.status = 'active'
                                       JOIN community_charters c ON c.group_id = g.id AND c.version > COALESCE(m.charter_version, 0) AND c.changed_at > ?
                                      WHERE m.user_id = ? AND m.status = 'active' ORDER BY c.version DESC LIMIT 10");
                $st->execute([date('Y-m-d H:i:s', time() - 60 * 86400), $uid]);
                $seen = [];
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $c) {
                    if (isset($seen[$c['id']])) continue; $seen[$c['id']] = 1;
                    $out[] = ['kind' => 'group_charter', 'title' => 'The charter of ' . $c['name'] . ' changed', 'body' => (string) $c['note'],
                              'url' => '/community/group.php?id=' . (int) $c['id'] . '#charter', 'when' => (string) $c['takes_effect_at'] > date('Y-m-d H:i:s') ? date('Y-m-d H:i:s') : (string) $c['takes_effect_at'], 'from' => (string) $c['name']];
                }
            } catch (Throwable) {}
        }
        return $out;
    }
}
