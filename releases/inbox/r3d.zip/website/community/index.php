<?php
// /community/ — public community groups (decisions/0047): find, join, or start one. Starting one writes its first
// charter (decisions/0137 §3), as yourself or as a business you run (its one group, 0137 §1).
// Searching by topic and place (decisions/0136 §4): with a place, local groups and chapters there and nearby come first,
// nearest first, then groups about places nearby, then interest groups that match ("Anywhere"). Cards show a group's
// tags and, for a chapter, the group it's part of; a topic shows its popular tags.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';

tv_page_start('Community groups', ['no_crumbs' => true]);   // no breadcrumbs (decisions/0058 §11)
// each topic's brand icon on its cards (the mockup's topic icon; tv_icon(), never emoji)
$cgIcons = ['' => tv_icon('users')]; foreach (['outdoors' => 'tree', 'arts' => 'pen', 'faith' => 'landmark', 'family' => 'users', 'health' => 'heart', 'food' => 'utensils', 'history' => 'book', 'causes' => 'sparkle', 'business' => 'store', 'hobbies' => 'play', 'other' => 'users'] as $k => $n) $cgIcons[$k] = tv_icon($n);
$cgUi = ['users' => tv_icon('users'), 'search' => tv_icon('search'), 'plus' => tv_icon('plus'), 'trend' => tv_icon('chart')];
?>
<style>
  /* /community/ to Jason's mockup, adapted (2026-11-20): on the tokens and the three levels (brand.md §4) */
  .cg-top{display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:space-between;gap:.75rem 1rem}
  .cg-top h1{font:700 clamp(1.6rem,3.2vw,2.2rem)/1.2 var(--tv-font-display,var(--tv-font-head));color:var(--tv-ink);margin:0}
  .cg-top p{color:var(--tv-meta);margin:.3rem 0 0;max-width:46rem}
  .cg-bar{background:var(--tv-sec);border:1px solid var(--tv-sec-edge,var(--tv-line));border-radius:var(--tv-r);padding:.75rem;display:grid;gap:.55rem}
  .cg-find{display:flex;flex-wrap:wrap;gap:.5rem}.cg-find .cg-q{flex:1 1 16rem;min-width:0;position:relative}
  .cg-find .cg-q svg{position:absolute;left:.65rem;top:50%;transform:translateY(-50%);width:18px;height:18px;color:var(--tv-meta)}.cg-find .cg-q input{padding-left:2.2rem}
  .cg-in{width:100%;border:1px solid var(--tv-field-edge,var(--tv-line-strong));border-radius:.6rem;padding:.5rem .7rem;background:var(--tv-field,var(--tv-card-a));color:var(--tv-ink);font-size:.92rem;box-sizing:border-box}
  .cg-find select.cg-in{width:auto;flex:0 1 12rem}
  .cg-b{display:inline-flex;align-items:center;gap:.35rem;font-size:.88rem;font-weight:600;border:1px solid var(--tv-line-strong);background:var(--tv-card-a);color:var(--tv-ink);border-radius:.6rem;padding:.45rem .9rem;cursor:pointer;white-space:nowrap;text-decoration:none}
  .cg-b:hover{border-color:var(--tv-link);color:var(--tv-link)}
  .cg-b.go{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text)}.cg-b.go:hover{background:var(--tv-btn-hover);color:var(--tv-btn-text)}
  .cg-b svg{width:16px;height:16px}
  .cg-pop{font-size:.85rem;color:var(--tv-meta);display:flex;flex-wrap:wrap;gap:.2rem .7rem;align-items:baseline}.cg-pop:empty{display:none}
  .cg-tag{border:0;background:none;padding:0;font:inherit;color:var(--tv-link);text-decoration:underline;cursor:pointer}
  .cg-hd{display:flex;align-items:center;justify-content:space-between;gap:.5rem;margin:1.1rem 0 .5rem}
  .cg-h{font:700 1.2rem var(--tv-font-head);color:var(--tv-ink);margin:0;display:flex;align-items:center;gap:.45rem}.cg-h svg{width:20px;height:20px;color:var(--tv-icon,#B45309)}
  .cg-n{font-size:.8rem;font-weight:700;color:var(--tv-link);background:color-mix(in srgb,var(--tv-link) 10%,var(--tv-card-a));border-radius:999px;padding:.15rem .6rem;white-space:nowrap}
  .cg-s{font-size:.8rem;color:var(--tv-meta)}
  .cg-list{display:grid;gap:.75rem;grid-template-columns:repeat(auto-fill,minmax(17rem,1fr))}
  .cg-g{display:flex;flex-direction:column;gap:.45rem;background:var(--tv-card-a);border:1px solid var(--tv-card-edge,var(--tv-line));border-radius:var(--tv-r);padding:1rem 1.05rem;color:var(--tv-ink);box-shadow:var(--tv-shadow)}
  .cg-g:hover{border-color:var(--tv-line-strong)}
  .cg-gt{display:flex;align-items:flex-start;justify-content:space-between;gap:.5rem}
  .cg-ic{width:42px;height:42px;border-radius:.6rem;background:var(--tv-sec);border:1px solid var(--tv-line);display:grid;place-items:center;color:var(--tv-icon,#B45309)}.cg-ic svg{width:22px;height:22px}
  .cg-wk{font-size:.72rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:color-mix(in srgb,var(--tv-moss,#6B7F62) 60%,var(--tv-ink));background:color-mix(in srgb,var(--tv-sage,#92BEA5) 28%,var(--tv-card-a));border-radius:.35rem;padding:.15rem .45rem;white-space:nowrap}
  .cg-gn{font:700 1.08rem/1.3 var(--tv-font-head);color:var(--tv-link);text-decoration:underline}
  .cg-ab{font-size:.88rem;color:var(--tv-ink);margin:0}
  .cg-gf{display:flex;align-items:center;justify-content:space-between;gap:.5rem;margin-top:auto;padding-top:.6rem;border-top:1px solid var(--tv-line)}
  .cg-gf .cg-s{display:inline-flex;align-items:center;gap:.3rem}.cg-gf .cg-s svg{width:16px;height:16px}
  .cg-card{background:var(--tv-sec);border:1px solid var(--tv-sec-edge,var(--tv-line));border-radius:var(--tv-r);padding:1rem 1.1rem}
  #cg-mine .cg-b{max-width:100%;overflow:hidden;text-overflow:ellipsis;vertical-align:top}
  @media (max-width:767px){.cg-find select.cg-in{flex:1 1 9rem}.cg-top .cg-b.go{width:100%;justify-content:center}}
</style>
<div class="max-w-5xl space-y-4">
  <div class="cg-top">
    <div>
      <h1>Community groups</h1>
      <p class="text-sm">Groups for any interest, pastime or cause, and local groups for a town or area. Anyone can find a group; only members see its posts and who belongs. Joining lets that group's members see your name there, never your email or where you are.</p>
    </div>
    <a class="cg-b go" href="#cg-new" data-cg-start><?= $cgUi['plus'] ?>Start a group</a>
  </div>
  <p id="cg-here" class="text-sm"></p>
  <section class="cg-bar tv-bleed" aria-label="Find a group">
    <form id="cg-find" class="cg-find" role="search">
      <label class="cg-q"><?= $cgUi['search'] ?><input class="cg-in" name="q" placeholder="Find a group by name, topic or place" aria-label="Find a group" data-spell></label>
      <select class="cg-in" id="cg-topic" aria-label="Topic"><option value="">All topics</option></select>
      <select class="cg-in" id="cg-sort" aria-label="Sort"></select>
      <button class="cg-b" type="submit">Find</button>
    </form>
    <div id="cg-pop" class="cg-pop"></div>
  </section>
  <div id="cg-mine"></div>
  <div id="cg-all"><p class="text-sm">Loading…</p></div>
  <div id="cg-new" class="cg-card" hidden>
    <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Start a group</h2>
    <form class="space-y-2 mt-2" autocomplete="off">
      <input class="cg-in" name="name" maxlength="80" required placeholder="Name, e.g. White Mountains Trail Runners">
      <label class="text-sm block" data-as hidden>Start it as <select class="cg-in" name="as" style="width:auto"><option value="0">Myself</option></select>
        <span class="cg-s block">A business has one group, run by its team; you'll add chapters for its places and topics later.</span></label>
      <textarea class="cg-in" name="about" rows="3" maxlength="1000" placeholder="What it's about, and who it's for"></textarea>
      <label class="text-sm block" data-kind>Kind of group <select class="cg-in" name="kind" style="width:auto"><option value="interest">Interest group</option><option value="local">Local group</option><option value="support">Support group</option></select></label>
      <h3 class="font-serif font-bold text-[color:var(--tv-ink)] mt-3">Its charter</h3>
      <p class="cg-s">What people read before joining. You can change any of it later on the group's page; members are told.</p>
      <label class="text-sm block">Purpose <textarea class="cg-in" name="purpose" rows="2" maxlength="600" required placeholder="What the group is for, in a sentence or two"></textarea></label>
      <label class="text-sm block">Who it's for <input class="cg-in" name="who_for" maxlength="200"></label>
      <label class="text-sm block">House rules <span class="cg-s">one per line</span><textarea class="cg-in" name="house_rules" rows="3"></textarea></label>
      <label class="text-sm block">If you step down <select class="cg-in" name="transfer" style="width:auto"></select></label>
      <p class="cg-s">Every charter also carries Traversence's ground rules (no harassment, no one's private information, no sacred sites, selling only through Traversence). Who sees the member list, reports and selling are set on the group's page.</p>
      <label class="text-sm block">Topic <select class="cg-in" name="topic" style="width:auto"></select></label>
      <label class="text-sm flex items-center gap-2"><input type="checkbox" name="approval"> New members need my approval</label>
      <p data-verify hidden class="text-sm" data-tv-status="info" data-tv-label="First:">Running a community needs a confirmed email: open the link we sent you, or send it again from <a class="underline" href="/login.php">Sign in</a>.</p>
      <button class="cg-b go" type="submit">Create group</button>
      <p class="cg-s">Public places and events only: never pinpoint sacred or restricted sites. Tribal nations' own groups are theirs to start.</p>
    </form>
  </div>
</div>
<script src="/js/tv-pager.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-pager.js') ?>"></script>
<script>
(function () {
  var qs = new URLSearchParams(location.search), API = '/user/api/community.php', csrf = null, place = qs.get('place') || '', topic = qs.get('topic') || '', lastQ = '', started = false;
  var ICONS = <?= json_encode($cgIcons) ?>, UI = <?= json_encode($cgUi) ?>, last = null, mineIds = {};
  // the sort (the mockup's "Most active"): joins in the last 7 days, then members. The order the list had before stays a choice:
  // nearest first with a place, most members without one
  var sort = qs.get('sort') || (place ? 'near' : 'active');
  // the starting charter for the kind of group (or the business), filled into the form for the owner to edit
  function startCharter(first) {
    var f = document.querySelector('#cg-new form'); if (!f) return;
    var as = +(f.as ? f.as.value : 0), kind = as ? 'business' : f.kind.value;
    fetch(API + '?start=1&kind=' + kind + (as ? '&listing=' + as : ''), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) return;
      if (first) {
        var free = (d.businesses || []).filter(function (b) { return !b.group_id; });
        if (free.length) { f.as.innerHTML += free.map(function (b) { return '<option value="' + b.id + '">' + esc(b.name) + '</option>'; }).join(''); f.querySelector('[data-as]').hidden = false; }
        f.transfer.innerHTML = Object.keys(d.options.transfer).filter(function (k) { return k !== 'successor'; }).map(function (k) { return '<option value="' + k + '">' + esc(d.options.transfer[k]) + '</option>'; }).join('');
      }
      var t = d.template;
      f.who_for.value = t.who_for || ''; f.house_rules.value = (t.house_rules || []).join('\n'); f.transfer.value = t.transfer || 'end';
      f.querySelector('[data-kind]').hidden = !!as;
    });
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  var WHERE = { here: 'Here', near: 'Nearby', about: 'Talks about places nearby', anywhere: 'Anywhere' };
  function card(g) {
    var url = '/community/group.php?id=' + g.id + '&src=' + (place ? 'place' : 'search'), mine = mineIds[g.id];
    return '<article class="cg-g tv-bleed"><div class="cg-gt"><span class="cg-ic" aria-hidden="true">' + (ICONS[g.topic] || ICONS['']) + '</span>'
      + (g.week > 0 ? '<span class="cg-wk" title="Joined in the last 7 days">+' + g.week + ' this week</span>' : '') + '</div>'
      + '<a class="cg-gn" href="' + url + '">' + esc(g.name) + '</a>'
      + '<span class="cg-s">' + [g.where ? '<b>' + esc(WHERE[g.where] || '') + '</b>' : '', g.topic_label ? esc(g.topic_label) : '', g.join_mode === 'approval' ? 'ask to join' : ''].filter(Boolean).join(' · ') + '</span>'
      + (g.parent ? '<span class="cg-s">Part of ' + esc(g.parent.name) + '</span>' : '')
      + (g.about ? '<p class="cg-ab">' + esc(g.about) + '</p>' : '')
      + (g.tags && g.tags.length ? '<span class="cg-s">' + g.tags.map(function (t) { return '#' + esc(t); }).join(' ') + '</span>' : '')
      // Join group opens the group at "What you're agreeing to": joining is consent to its charter (decisions/0137 §3)
      + '<div class="cg-gf"><span class="cg-s">' + UI.users + g.members + ' member' + (g.members === 1 ? '' : 's') + '</span>'
      + '<a class="cg-b" href="' + url + (mine ? '' : '#charter') + '">' + (mine ? 'Open group' : g.join_mode === 'approval' ? 'Ask to join' : 'Join group') + '</a></div></article>';
  }
  function sorted(list) {
    if (sort !== 'active') return list;   // 'near' and 'members': the server's own order
    return list.slice().sort(function (a, b) { return (b.week || 0) - (a.week || 0) || b.members - a.members || a.name.localeCompare(b.name); });
  }
  function head(title, n, icon) { return '<div class="cg-hd"><h2 class="cg-h">' + (icon || '') + esc(title) + '</h2><span class="cg-n">' + n + ' group' + (n === 1 ? '' : 's') + '</span></div>'; }
  function draw(d, q) {
    var all = document.getElementById('cg-all');
    var none = '<p class="text-sm">' + (q || d.topic ? 'No groups match. Start one below.' : 'No groups yet. Start the first one below.') + '</p>';
    if (d.place && d.place.key) { var gs = sorted(d.groups); all.innerHTML = gs.length ? head('Groups in ' + d.place.label, gs.length) + '<p class="cg-s mb-1">' + (sort === 'near' ? 'Nearest first: groups here and nearby, then groups about places nearby' + (q || d.topic ? ', then groups anywhere that match' : '') + '.' : 'Most active first: joins this week, then members.') + '</p><div class="cg-list">' + gs.map(card).join('') + '</div>' : none; }
    else {
      var interest = sorted(d.groups.filter(function (g) { return !g.local; })), local = sorted(d.groups.filter(function (g) { return g.local; }));
      all.innerHTML = !d.groups.length ? none
        : (interest.length ? head(sort === 'active' ? 'Trending & growing groups' : 'Interest groups', interest.length, sort === 'active' ? UI.trend : '') + '<div class="cg-list">' + interest.map(card).join('') + '</div>' : '')
        + (local.length ? head('Local groups', local.length) + '<p class="cg-s mb-1">Groups that belong to a town or area. Each also shows on that place\'s page.</p><div class="cg-list">' + local.map(card).join('') + '</div>' : '');
    }
    // the lists' standard (2026-11-12, js/tv-pager.js): 10 a page or the visitor's choice, Show more, and the pages
    if (window.TvPager) all.querySelectorAll('.cg-list').forEach(function (l, i) { TvPager.local(l, { key: 'groups' + i }); });
  }
  function sorts() {
    var o = place ? [['near', 'Nearest first'], ['active', 'Most active']] : [['active', 'Most active'], ['members', 'Most members']], el = document.getElementById('cg-sort');
    if (!o.some(function (x) { return x[0] === sort; })) sort = o[0][0];
    el.innerHTML = o.map(function (x) { return '<option value="' + x[0] + '"' + (x[0] === sort ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('');
  }
  function url() {
    var p = [place ? 'place=' + encodeURIComponent(place) : '', topic ? 'topic=' + encodeURIComponent(topic) : '', sort !== (place ? 'near' : 'active') ? 'sort=' + sort : ''].filter(Boolean);
    history.replaceState(null, '', '/community/' + (p.length ? '?' + p.join('&') : ''));
  }
  sorts();
  function load(q) {
    lastQ = q || '';
    fetch(API + '?q=' + encodeURIComponent(lastQ) + (place ? '&place=' + encodeURIComponent(place) + '&near=1' : '') + (topic ? '&topic=' + encodeURIComponent(topic) : ''), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      var all = document.getElementById('cg-all');
      if (!d.ok) { all.textContent = (d.error && d.error.message) || 'Not available yet.'; if (place) { place = ''; } return; }
      csrf = d.csrf;
      var here = document.getElementById('cg-here');
      if (d.place && d.place.key) {
        here.innerHTML = 'Groups in <a class="font-semibold underline text-[color:var(--tv-link)]" href="' + esc(d.place.url) + '">' + esc(d.place.label) + '</a> · <a class="underline" href="/community/">all groups</a>';
        document.querySelector('#cg-new h2').textContent = 'Start a group in ' + d.place.label;
      }
      var tsel = document.getElementById('cg-topic');
      tsel.innerHTML = '<option value="">All topics</option>' + Object.keys(d.topics).map(function (k) { return '<option value="' + k + '"' + (k === d.topic ? ' selected' : '') + '>' + esc(d.topics[k]) + '</option>'; }).join('');
      var pop = document.getElementById('cg-pop');
      pop.innerHTML = d.popular && d.popular.length ? '<span>Popular' + (d.topic ? ' in ' + esc(d.topics[d.topic]) : '') + ':</span> ' + d.popular.map(function (t) { return '<button type="button" class="cg-tag" data-tag="' + esc(t) + '">#' + esc(t) + '</button>'; }).join(' ') : '';
      var sel = document.querySelector('#cg-new select[name=topic]');
      if (sel && !sel.options.length) sel.innerHTML = Object.keys(d.topics).map(function (k) { return '<option value="' + k + '">' + esc(d.topics[k]) + '</option>'; }).join('');
      if (sel && d.topic) sel.value = d.topic;
      mineIds = {}; (d.mine || []).forEach(function (g) { if (g.status !== 'pending') mineIds[g.id] = 1; });
      last = d; draw(d, q);
      document.getElementById('cg-mine').innerHTML = d.mine.length ? '<h2 class="cg-h" style="font-size:1rem;margin-bottom:.4rem">Your groups</h2><div class="flex flex-wrap gap-2">'
        + d.mine.map(function (g) { return '<a class="cg-b" href="/community/group.php?id=' + g.id + '">' + esc(g.name) + (g.status === 'pending' ? ' (asked)' : g.role !== 'member' ? ' · ' + g.role : '') + '</a>'; }).join('') + '</div>' : '';
      var nw = document.getElementById('cg-new');
      nw.hidden = false;
      var vf = nw.querySelector('[data-verify]');
      if (vf && d.signed_in && d.verify && !d.verify.on) vf.hidden = false;   // only when the email isn't confirmed yet (decisions/0062 as amended 2026-11-05)
      if (!d.signed_in) nw.querySelector('form').outerHTML = '<p class="text-sm mt-1"><a class="font-semibold underline text-[color:var(--tv-link)]" href="/login.php">Sign in</a> to start or join a group.</p>';
      else if (!started) { started = true; var nf = nw.querySelector('form'); if (place) nf.kind.value = 'local'; startCharter(true); }
    }).catch(function () { document.getElementById('cg-all').textContent = 'Not available yet.'; });
  }
  document.getElementById('cg-topic').addEventListener('change', function (e) { topic = e.target.value; url(); load(lastQ); });
  document.getElementById('cg-sort').addEventListener('change', function (e) { sort = e.target.value; url(); if (last) draw(last, lastQ); });
  document.getElementById('cg-pop').addEventListener('click', function (e) {
    var b = e.target.closest('[data-tag]'); if (!b) return;
    var f = document.getElementById('cg-find'); f.q.value = b.getAttribute('data-tag'); load(f.q.value);
  });
  document.getElementById('cg-new').addEventListener('change', function (e) { if (e.target.name === 'as' || e.target.name === 'kind') startCharter(false); });
  document.getElementById('cg-find').addEventListener('submit', function (e) { e.preventDefault(); load(e.target.q.value.trim()); });
  document.getElementById('cg-new').addEventListener('submit', function (e) {
    e.preventDefault();
    var f = e.target, sub = f.querySelector('button[type=submit]'), as = +(f.as ? f.as.value : 0);
    var body = { action: 'create', name: f.name.value, about: f.about.value, join_mode: f.approval.checked ? 'approval' : 'open', place: place, topic: f.topic.value,
                 verify: !!(f.verify && f.verify.checked), listing_id: as,
                 charter: { kind: as ? 'business' : f.kind.value, purpose: f.purpose.value, who_for: f.who_for.value, house_rules: f.house_rules.value, transfer: f.transfer.value } };
    fetch(API, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (d.ok) location.href = '/community/group.php?id=' + d.group_id; else TvAsk.say(d.error.message, { anchor: sub, bad: true });
      }).catch(function () { TvAsk.say('Couldn\'t reach the site. Try again.', { anchor: sub, bad: true }); });
  });
  // Start a group (top right) opens the form below and goes to it
  document.querySelector('[data-cg-start]').addEventListener('click', function () { var n = document.getElementById('cg-new'); if (n.hidden) n.hidden = false; setTimeout(function () { var i = n.querySelector('input,textarea'); if (i) i.focus(); }, 50); });
  load('');
})();
</script>
<?php tv_page_end();
