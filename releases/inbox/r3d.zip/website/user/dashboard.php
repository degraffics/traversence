<?php
// Server-side auth check, same pattern as listing/businessportal.php.
require_once __DIR__ . '/../../app/bootstrap.php';
// bootstrap.php sets Content-Type: application/json unconditionally,
// correct for real API endpoints but wrong here — this file outputs a
// full HTML page. Override it back before any output is sent, or the
// browser receives HTML labeled as JSON and just displays the raw
// source as plain text instead of rendering it.
header('Content-Type: text/html; charset=utf-8');
$currentUser = Auth::currentUser();
if ($currentUser === null) {
    header('Location: /login.php');
    exit;
}

// Super-Admin bootstrap / panel-link block — see
// _SUPPORT/spec/05-admin-and-capability-model.md. Three states:
// zero admin_access rows -> one-time "Become Super-Admin" card;
// current user already holds admin_access -> "Admin Panel" link;
// otherwise -> neither block renders, dashboard looks unchanged.
$pdo = Database::connection();
// a staff login has no member side (decisions/0100): it never lands here, it goes on to the admin. Its password and 2FA
// are at /admin/staff.php; its member account is the account switch (Jason, 2026-11-19: "the side bar navigation is wrong
// for the type of user I am")
require_once __DIR__ . '/../../app/lib/Roles.php';
if (Roles::staffLogin($pdo, (int) $currentUser['id'])) { header('Location: /admin/dashboard', true, 302); exit; }
$totalAdmins = (int)$pdo->query('SELECT COUNT(*) FROM ' . Database::t('admin_access') . '')->fetchColumn();
$currentUserIsAdmin = false;
if ($totalAdmins > 0) {
    $stmt = $pdo->prepare('SELECT 1 FROM ' . Database::t('admin_access') . ' WHERE user_id = :uid LIMIT 1');
    $stmt->execute(['uid' => $currentUser['id']]);
    $currentUserIsAdmin = (bool)$stmt->fetchColumn();
}

// ---- Account hub (decisions/0047): one front door, sections by role --------------------------------
require_once __DIR__ . '/../../app/lib/Links.php';
$isAdmin = $currentUserIsAdmin;
$name = trim((string) ($currentUser['display_name'] ?? '')) ?: strstr((string) $currentUser['email'], '@', true);
$initials = strtoupper(mb_substr($name, 0, 1));
$hasLinks = Links::tableExists($pdo);
$st = $pdo->prepare('SELECT COUNT(*) FROM listing_access WHERE user_id = ?');
try { $st->execute([$currentUser['id']]); $managesListings = (int) $st->fetchColumn() > 0; } catch (Throwable) { $managesListings = false; }
$roleLabel = $isAdmin ? 'Admin' : ($managesListings ? 'Member · Business' : 'Member');

// Roles and the context this visit is acting in (decisions/0055 §4, §8); the Pulse gathers what needs you (§5).
require_once __DIR__ . '/../../app/lib/Roles.php';
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/ui/pulse-panel.php';   // the Pulse, shared with a business's Overview
$ctx = Roles::current($pdo, (int) $currentUser['id']);
$contexts = Roles::contexts($pdo, (int) $currentUser['id']);
$ctxEntity = $ctx['kind'] === 'org' ? (int) $ctx['scope']['entity'] : 0;
$openNotice = $hasLinks && Links::needsOpenNotice($pdo, (int) $currentUser['id']);
$icon = fn (string $paths) => '<svg class="ah-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths . '</svg>';
$I = [
    'feeds' => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    'places' => '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
    'book' => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    'community' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    'market' => '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
    'plans' => '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    'links' => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    'settings' => '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    'security' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    'help' => '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    'business' => '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
    'admin' => '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
];
// The toolbar for the context: [key => [label, icon, section]]; a key starting with / is a page link.
$R = fn (string $key, string $label, string $icon, string $section = '', array $more = []) => ['key' => $key, 'label' => $label, 'icon' => $icon,
    'url' => str_starts_with($key, '/') ? $key : '#' . $key, 'section' => $section, 'attrs' => str_starts_with($key, '/') ? '' : 'data-go="' . $key . '"'] + $more;
$preview = !empty($ctx['scope']['preview']);
// one landing for a business (Jason, 2026-10-23: "Why not just one landing dashboard?"): acting as a listing, the
// dashboard's front is its Overview in the business portal; its Pulse and messages open here when asked for (?in=)
if ($ctx['kind'] === 'org' && !$preview && $ctxEntity && empty($_GET['in'])) { header('Location: /business/' . $ctxEntity, true, 302); exit; }
if ($ctx['kind'] === 'org') {
    if ($preview) $rail = [$R('pulse', 'Pulse', 'pulse', $ctx['label']), $R('business', 'Messages & insights', 'inbox'), $R('listing', 'The listing', 'store', '', ['soon' => true]),
             $R('edit', 'Edit listing', 'settings', '', ['soon' => true]), $R('team', 'Team & roles', 'users', 'Organization'), $R('help', 'Help', 'book', 'Help')];
    else { require_once __DIR__ . '/../../app/business/portal.php'; $rail = tv_biz_rail($pdo, $ctxEntity, (int) $currentUser['id'], true, (string) $ctx['label']); }   // the one menu for a business (0115 addendum)
} elseif ($ctx['kind'] === 'steward') {
    $rail = [$R('pulse', 'Pulse', 'pulse', 'Steward'), $R('steward', 'Your communities', 'users'),
             $R('reports', 'Member reports', 'shield', '', ['soon' => true]), $R('charter', 'Charter', 'book', '', ['soon' => true]), $R('help', 'Help', 'book', 'Help')];
} elseif ($ctx['kind'] === 'admin') {
    // the admin dashboard is its own page now (admin/index.php, decisions/0078); here an admin keeps their own account,
    // with the admin dashboard first. Arriving on the dashboard's front or an old admin section goes on to /admin/.
    $adminHome = true;
    $rail = [$R('/admin/', 'Admin dashboard', 'shield', 'Admin'), $R('pulse', 'Dashboard', 'home', 'You'), $R('/gallery/', 'Gallery', 'camera'), $R('/user/orders.php', 'Your orders', 'inbox'), $R('/user/trips/', 'Your trips', 'map'),
             $R('profile', 'Profile', 'user', 'Settings'), $R('places', 'Default places', 'map'), $R('security', 'Privacy', 'shield'), $R('settings', 'App settings', 'settings'), $R('/plans.php', 'Plans', 'sparkle', '', ['what' => 'Your plan, storage and AI Assist credits']), $R('help', 'Help', 'book')];
} else {
    // Address Book, Linked, Groups and Your journeys are on the Dashboard itself (its tabs and Pulse), so the menu stays short;
    // Marketplace and the trip planner are under "Switch to" (app-shell.php)
    $rail = [$R('pulse', 'Dashboard', 'home', 'You'),   // your profile with the Pulse (where your account opens)
             $R('/gallery/', 'Gallery', 'camera'), $R('/user/orders.php', 'Your orders', 'inbox'), $R('/user/trips/', 'Your trips', 'map'),   // your photos, videos and albums (decisions/0126)
             $R('domains', 'Domains', 'globe'),   // your domains and wallet (decisions/0169 §1a), /user/domains/ embedded below
             $R('profile', 'Profile', 'user', 'Settings'), $R('places', 'Default places', 'map'), $R('security', 'Privacy', 'shield'), $R('settings', 'App settings', 'settings'), $R('/plans.php', 'Plans', 'sparkle', '', ['what' => 'Your plan, storage and AI Assist credits']), $R('help', 'Help', 'book')];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php if (!empty($adminHome)): // the admin dashboard is /admin/ (decisions/0078): its front, and the old admin sections, go there ?>
  <script>(function () { var h = location.hash.slice(1).split(':')[0], m = { '': '/admin/', admin: '/admin/', team: '/admin/people.php#staff', procedures: '/admin/safety.php#procedures' }; if (m.hasOwnProperty(h)) location.replace(m[h]); })();</script>
  <?php endif; ?>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Account — Traversence</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .mk-r{border-top:1px solid rgba(203,185,141,.7);padding:.5rem 0}.mk-h{display:flex;align-items:center;gap:.5rem}
    .mk-n{flex:1;min-width:0;text-align:left;font-weight:600;color:var(--tv-ink,#3E2B1F);background:none;border:0;padding:0;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mk-n:hover{color:var(--tv-icon,#B45309)}
    .mk-pill{font-size:.72rem;font-weight:600;border:1px solid;border-radius:999px;padding:.1rem .5rem;white-space:nowrap}
    .mk-x{width:28px;height:28px;border-radius:999px;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-meta,#8A7355);font-size:1.1rem;line-height:1;cursor:pointer;flex:none}.mk-x:hover{color:var(--tv-crimson,#B91C1C);border-color:#B91C1C}
    .mk-p{margin:.5rem 0 .2rem;padding:.6rem .7rem;background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.7rem;display:grid;gap:.6rem}
    .mk-l{display:grid;gap:.25rem;font-size:.8rem;font-weight:600;color:var(--tv-meta,#5C4632)}.mk-f{display:flex;flex-wrap:wrap;gap:.3rem .9rem;font-weight:400}.mk-s{font-size:.75rem;font-weight:400;color:var(--tv-meta,#8A7355)}
    .ah{display:grid;grid-template-columns:260px minmax(0,1fr);gap:1.25rem;align-items:start}
    .ah>*{min-width:0}
    .ah *{box-sizing:border-box}
    .ah-side{position:sticky;top:var(--ah-top,5.5rem);background:var(--tv-sec,#F7EFDC);border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:.9rem}
    .ah-me{display:flex;align-items:center;gap:.7rem;padding-bottom:.8rem;border-bottom:1px solid rgba(203,185,141,.7)}
    .ah-av{width:44px;height:44px;border-radius:999px;background:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber-meta,#B8863B);display:flex;align-items:center;justify-content:center;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.2rem;flex:0 0 auto}
    .ah-name{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.1rem;line-height:1.1}
    .ah-role{font-size:.72rem;color:var(--tv-meta,#8A7355)}
    .ah-grp{margin-top:.7rem}
    .ah-grp>summary{cursor:pointer;list-style:none;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;color:var(--tv-meta,#8A7355);display:flex;justify-content:space-between;padding:.2rem 0}
    .ah-grp>summary::-webkit-details-marker{display:none}
    .ah-grp>summary::after{content:'\25B8';transition:transform .15s}
    .ah-grp[open]>summary::after{transform:rotate(90deg)}
    .ah-nav{display:flex;flex-direction:column;gap:.1rem;margin-top:.25rem}
    .ah-item{display:flex;align-items:center;gap:.6rem;padding:.4rem .5rem;border-radius:.6rem;font-size:.9rem;color:var(--tv-ink,#3E2B1F);text-decoration:none}
    .ah-item:hover{background:var(--tv-canvas,#EFE3C8)}
    .ah-ic{width:30px;height:30px;border-radius:999px;background:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber-meta,#B8863B);display:flex;align-items:center;justify-content:center;flex:0 0 auto;transition:color .15s,filter .15s}
    .ah-item.on{background:var(--tv-sec,#E3D3AC);font-weight:600}
    .ah-item.on .ah-ic{color:#22C55E;filter:drop-shadow(0 0 5px rgba(34,197,94,.7))}
    .ah-svg{width:16px;height:16px}
    .ah-note{background:var(--tv-sec,#F7EFDC);border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:.7rem .9rem}
    .ah-note-h{display:flex;align-items:center;justify-content:space-between;gap:.5rem;font-weight:600;font-size:.9rem}
    .ah-note li{font-size:.85rem;margin-top:.35rem}
    .ah-note a{color:var(--tv-icon,#B45309);text-decoration:underline}
    .ah-n{display:inline-block;min-width:1.4rem;text-align:center;background:#D97706;color:#fff;border-radius:999px;font-size:.72rem;font-weight:700;padding:0 .35rem;margin-right:.35rem}
    .ah-x{background:none;border:0;color:var(--tv-meta,#8A7355);cursor:pointer;font-size:1.1rem;line-height:1}
    .ah-tabs{display:flex;gap:.2rem;border-bottom:1px solid var(--tv-line-strong,#CBB98D);overflow-x:auto;scrollbar-width:none}
    .ah-tabs::-webkit-scrollbar{display:none}
    .ah-tab{flex:0 0 auto;padding:.45rem .9rem;font-size:.88rem;border:1px solid transparent;border-bottom:0;border-radius:.6rem .6rem 0 0;background:none;color:var(--tv-meta,#5C4632);cursor:pointer}
    .ah-tab.on{background:var(--tv-sec,#F7EFDC);border-color:var(--tv-line-strong,#CBB98D);color:var(--tv-ink,#3E2B1F);font-weight:600;margin-bottom:-1px}
    .ah-feed{background:var(--tv-sec,#F7EFDC);border:1px solid var(--tv-line-strong,#CBB98D);border-top:0;border-radius:0 0 1rem 1rem;padding:.8rem;min-height:10rem}
    .ah-fi{display:block;padding:.6rem .7rem;border-radius:.7rem;background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.6);margin-top:.5rem;color:inherit;text-decoration:none}
    .ah-fi:first-child{margin-top:0}
    .ah-fi b{font-family:var(--tv-font-head,ui-serif,Georgia,serif)}
    .ah-fi small{display:block;color:var(--tv-meta,#8A7355);font-size:.75rem;margin-top:.15rem}
    .ah-card{background:var(--tv-sec,#E3D3AC);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:1rem;padding:1.2rem;box-shadow:0 10px 15px -3px rgba(0,0,0,.1)}
    .pf-f{max-width:34rem;margin-top:.6rem}
    .pf-l{display:block;font-size:.8rem;font-weight:700;color:var(--tv-ink,#3E2B1F);margin-top:.9rem;margin-bottom:.3rem}
    .pf-in{width:100%;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;padding:.5rem .7rem;background:var(--tv-card-a,#FFFBF2);font-size:.92rem;color:var(--tv-ink,#3E2B1F)}
    .pf-hint{font-size:.75rem;color:var(--tv-meta,#8A7355);margin-top:.25rem}
    .pf-r{display:flex;gap:.5rem;align-items:flex-start;font-size:.88rem;color:var(--tv-ink,#3E2B1F);margin-top:.35rem}.pf-r input{margin-top:.25rem}
    .pf-b{font-size:.85rem;font-weight:600;border-radius:.65rem;padding:.45rem .9rem;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);cursor:pointer;text-decoration:none}
    .pf-b.go{background:#15803D;border-color:#15803D;color:#fff}
    .pf-msg{font-size:.85rem;margin-top:.6rem;min-height:1.2em}.pf-msg.ok{color:#15803D}.pf-msg.bad{color:var(--tv-crimson,#B91C1C)}
    .ah-soon{background:rgba(227,211,172,.5);border:1px dashed var(--tv-line-strong,#CBB98D);border-radius:1rem;padding:1.2rem;color:var(--tv-meta,#5C4632);font-size:.9rem}
    .ah-links h3{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;margin-top:.8rem}
    .ah-lrow{display:flex;align-items:center;justify-content:space-between;gap:.6rem;padding:.45rem 0;border-top:1px solid rgba(203,185,141,.6);font-size:.9rem}
    .ah-lrow a{color:var(--tv-ink,#3E2B1F)}
    .ah-lb{font-size:.78rem;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);border-radius:.5rem;padding:.2rem .55rem;cursor:pointer;margin-left:.3rem}
    [data-sec][hidden]{display:none!important}
    <?= tv_pulse_css(false) /* the Pulse (app/ui/pulse-panel.php) */ ?>
    /* the listing at a glance (the business landing) */
    .bo{background:var(--tv-sec,#F7EFDC);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:1rem;padding:.9rem 1rem;margin-top:.8rem}
    .bo.fpo{border-style:dashed;border-color:#B8863B}
    .bo-fpo{font-size:.72rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--tv-link,#92400E);margin:0 0 .5rem}
    .bo-top{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.6rem 1rem}
    .bo-n{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.3rem;margin:0;color:var(--tv-ink,#3E2B1F)}
    .bo-s{font-size:.82rem;color:var(--tv-meta,#8A7355);margin:.15rem 0 0}
    .bo-acts{display:flex;flex-wrap:wrap;gap:.35rem;align-items:flex-start}
    .bo-prof{margin-top:.7rem}
    .bo-bar{height:8px;border-radius:999px;background:var(--tv-sec,#EADFC4);overflow:hidden}.bo-bar span{display:block;height:100%;background:#15803D}
    .bo-nums{display:grid;gap:.5rem;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));margin-top:.8rem}
    .bo-nums div{background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.7rem;padding:.5rem .7rem}
    .bo-nums b{display:block;font-size:1.25rem;color:var(--tv-ink,#3E2B1F)}.bo-nums span{font-size:.74rem;color:var(--tv-meta,#8A7355)}
    /* admin work, procedures, team */
    .aw{display:grid;gap:.8rem;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));margin-top:.9rem}
    .aw-g{background:var(--tv-sec,#F7EFDC);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:1rem;padding:.8rem .9rem}
    .aw-g h3{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--tv-meta,#8A7355);margin:0 0 .3rem}
    .aw-t{display:block;padding:.45rem .55rem;border-radius:.6rem;color:var(--tv-ink,#3E2B1F);text-decoration:none}
    .aw-t:hover{background:var(--tv-card-a,#FFFBF2)}
    .aw-t b{display:block;font-size:.92rem}.aw-t span{display:block;font-size:.75rem;color:var(--tv-meta,#8A7355)}
    .aw-t.off{opacity:.55}
    .pr-steps{margin:.3rem 0 0 1.2rem;padding:0;font-size:.9rem}
    .pr-steps li{margin-top:.3rem}.pr-steps a{color:var(--tv-ink,#3E2B1F)}
    .pr-steps input:checked+a{text-decoration:line-through;color:var(--tv-meta,#8A7355)}
    .tm-r{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:.4rem;padding:.5rem 0;border-top:1px solid rgba(203,185,141,.6)}
    .tm-role{font-size:.72rem;font-weight:700;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;padding:.1rem .5rem;background:var(--tv-card-a,#FFFBF2)}
    .tm-add{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.8rem}
    .ab-find{display:flex;gap:.4rem;margin-top:.8rem}
    .ab-in{width:100%;background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;padding:.45rem .6rem;font-size:.9rem}
    .ab-b{font-size:.8rem;font-weight:600;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);border-radius:.55rem;padding:.3rem .7rem;cursor:pointer;white-space:nowrap;text-decoration:none;display:inline-block}
    .ab-b.go{background:#15803D;border-color:#15803D;color:#fff}.ab-b.no{color:var(--tv-crimson,#991B1B);border-color:#FCA5A5}
    .ab-tabs{display:flex;gap:.3rem;overflow-x:auto;scrollbar-width:none;margin-top:.9rem;border-bottom:1px solid var(--tv-line-strong,#CBB98D);padding-bottom:.3rem}
    .ab-tabs::-webkit-scrollbar{display:none}
    .ab-tab{flex:0 0 auto;font-size:.82rem;padding:.3rem .75rem;border-radius:999px;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);cursor:pointer}
    .ab-tab.on{background:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2);border-color:var(--tv-umber,#3E2B1F)}
    .ab-row{display:flex;align-items:center;justify-content:space-between;gap:.5rem;flex-wrap:wrap;padding:.5rem 0;border-top:1px solid rgba(203,185,141,.6)}
    .ab-name{font-weight:600;color:var(--tv-ink,#3E2B1F)}
    .ab-acts{display:inline-flex;gap:.3rem;flex-wrap:wrap}
    .ab-h{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;margin-top:.9rem}
    .ab-conn{padding-bottom:.4rem}
    .ab-card-view{background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.6);border-radius:.6rem;padding:.4rem .6rem}
    .ab-share summary{cursor:pointer;font-size:.8rem;color:var(--tv-icon,#B45309);margin-top:.35rem}
    .ab-chks{display:flex;flex-wrap:wrap;gap:.3rem .9rem;margin:.4rem 0}
    .ab-chk{display:flex;align-items:center;gap:.4rem;font-size:.85rem;margin-top:.25rem}
    .ab-lbl{display:block;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--tv-meta,#8A7355);margin-top:.6rem}
    .ab-cardform .ab-in{margin-top:.2rem}
    .ab-cardform .ab-b{margin-top:.7rem}
    .ab-thread{display:block;width:100%;text-align:left;background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.6);border-radius:.7rem;padding:.55rem .7rem;margin-top:.45rem;cursor:pointer}
    .ab-thread small{display:block;color:var(--tv-meta,#8A7355);font-size:.75rem;margin-top:.1rem}
    .ab-convo-h{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;margin-top:.7rem}
    .ab-convo{max-height:50vh;overflow-y:auto;margin-top:.6rem;display:flex;flex-direction:column;gap:.4rem}
    .ab-msg{max-width:85%;background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.6);border-radius:.8rem;padding:.45rem .65rem;font-size:.9rem;align-self:flex-start}
    .ab-msg.me{align-self:flex-end;background:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2);border-color:var(--tv-umber,#3E2B1F)}
    .ab-msg small{display:block;font-size:.68rem;opacity:.7;margin-top:.15rem}
    .bz-type{display:inline-block;font-size:.66rem;font-weight:700;letter-spacing:.02em;text-transform:uppercase;padding:.05rem .4rem;border-radius:999px;border:1px solid currentColor;opacity:.8;margin-bottom:.2rem}
    .bz-mutes{display:flex;flex-wrap:wrap;gap:.35rem .8rem;margin-top:.3rem}
    .bz-rep{background:none;border:0;padding:0;font-size:.68rem;text-decoration:underline;opacity:.7;cursor:pointer;color:inherit;margin-left:.4rem}
    .ab-send{display:flex;gap:.4rem;align-items:flex-end;margin-top:.6rem}
    /* Phone: the side panel's items become one swipeable icon row across the top. */
    @media (max-width: 800px) {
      .ah{grid-template-columns:minmax(0,1fr);gap:.8rem}
      .ah-side{position:static;padding:.7rem}
      .ah-grp>summary{display:none}
      .ah-grp{margin-top:.5rem}
      .ah-groups{display:flex;overflow-x:auto;gap:.2rem;scrollbar-width:none;-webkit-overflow-scrolling:touch}
      .ah-groups::-webkit-scrollbar{display:none}
      .ah-grp,.ah-grp:not([open]){display:contents}
      .ah-grp:not([open])>.ah-nav{display:flex}
      .ah-nav{flex-direction:row;gap:.2rem}
      .ah-item{flex-direction:column;gap:.2rem;font-size:.66rem;padding:.3rem .35rem;min-width:62px;text-align:center;line-height:1.1}
      .ah-ic{width:40px;height:40px}
      .ah-svg{width:20px;height:20px}
    }
  </style>
</head>
<body class="bg-[color:var(--tv-canvas)] text-[color:var(--tv-ink)] min-h-screen flex flex-col font-sans antialiased">

  <!-- Shared site header (logo + gateway icons + profile + menu). Sign Out and
       the Back-to-directory link now live in the menu / gateway icons. -->
<?php try { require_once __DIR__ . '/../../app/ui/context-switcher.php'; echo tv_acting_bar(); } catch (Throwable $e) { error_log('acting bar: ' . $e->getMessage()); }   // who you're acting as, above the header (zip 4) ?>
  <div id="top-bar" class="bg-[color:var(--tv-umber)] border-b border-[#2A1B12] sticky top-0 z-40 shadow-lg">
    <div class="px-4 sm:px-8 py-3 flex items-center justify-between">
      <?php require_once __DIR__ . '/../../app/ui/brand.php'; ?>
      <?php require_once __DIR__ . '/../../app/ui/header.php'; ?>
    </div>
  </div>

  <main class="flex-grow w-full">
  <?php tv_app_open('My account', ['rail' => $rail, 'active' => 'pulse', 'bare' => true]); ?>
    <div class="space-y-5 min-w-0">
      <?php // your profile, as you manage it (draft 2026-10-09, Jason's mockup): cover, card, details, tabs, then the section
      $pfOwner = false;
      if ($ctx['kind'] === 'member' && is_file(__DIR__ . '/../../app/lib/MemberProfile.php')) {
          require_once __DIR__ . '/../../app/ui/profile-header.php';
          if (MemberProfile::ready($pdo)) { $pfOwner = true; $pfP = MemberProfile::get($pdo, (int) $currentUser['id']); echo tv_profile_open($pfP, ['owner' => true]); }
      } ?>
      <section data-sec="pulse" class="pu">
        <?php if ($ctx['kind'] === 'member' && !empty($pfOwner) && is_file(__DIR__ . '/../../app/lib/MemberPosts.php')) { require_once __DIR__ . '/../../app/lib/MemberPosts.php'; $tvmOn = MemberPosts::ready($pdo); } else { $tvmOn = false; }
        if ($tvmOn): /* "What's on your mind?": a post from your Dashboard (decisions/0153); your posts are on the Posts tab */ ?><div id="tvm-comp" style="margin:0 0 .8rem"></div><div id="tvm-fresh"></div><?php endif; ?>
        <?= tv_pulse_head(['label' => $ctx['kind'] !== 'member' ? (string) $ctx['label'] : '', 'compose' => $ctx['kind'] === 'member', 'layout' => !empty($pfOwner) ? tv_profile_layout_button() : '']) /* the Pulse's head (app/ui/pulse-panel.php, shared with a business's Overview) */ ?>
        <?php if ($ctx['kind'] === 'member'): ?>
        <form class="pu-comp" id="pu-comp" hidden autocomplete="off">
          <label class="pu-lbl" for="pu-to">To</label>
          <div class="pu-to"><span class="pu-who" id="pu-who" hidden></span><input class="ab-in" id="pu-to" placeholder="A connection's name, or someone who can be found" aria-describedby="pu-hint"></div>
          <div class="pu-sug" id="pu-sug" role="listbox"></div>
          <p class="pu-muted" id="pu-hint">Your connections come first. People who allow it can be found by name; someone who isn't connected gets a message request.</p>
          <label class="pu-lbl" for="pu-body">Message</label>
          <textarea class="ab-in" id="pu-body" rows="3" maxlength="2000" placeholder="Write a message"></textarea>
          <div class="pu-cacts"><button type="submit" class="ab-b go" id="pu-send">Send</button><button type="button" class="ab-b" id="pu-cancel">Cancel</button><span class="pu-muted" id="pu-cmsg" role="status"></span></div>
        </form>
        <?php endif; ?>
        <?php if ($ctx['kind'] === 'org' && $preview):
            // The sample business's listing at a glance (real listings have theirs on their Overview, /business/<id>)
            if ($preview) {
                $bo = ['name' => 'Sample Trading Post', 'status' => 'Claimed · verification pending', 'town' => 'St. Johns, AZ',
                       'have' => ['Phone' => true, 'Address' => true, 'Website' => true, 'Hours' => false, 'Description' => true, 'Category' => true],
                       'nums' => ['Linked' => 42, 'Subscribers' => 18, 'New links (30 days)' => 6, 'Messages this week' => 9]];
            } else {
                $bo = ['name' => $ctx['label'], 'status' => '', 'town' => '', 'have' => [], 'nums' => []];
                try {
                    $q = $pdo->prepare('SELECT status, category_id FROM entities WHERE id = ?'); $q->execute([$ctxEntity]); $er = $q->fetch(PDO::FETCH_ASSOC) ?: [];
                    $bo['status'] = ['verified' => '✓ Verified', 'claimed-unverified' => 'Managed by owner · confirm by text to verify', 'pending-verification' => 'Claimed · verification pending', 'unclaimed' => 'Unclaimed'][$er['status'] ?? ''] ?? ucfirst((string) ($er['status'] ?? ''));
                    $m = [];
                    $q = $pdo->prepare("SELECT meta_key, meta_value FROM entity_metadata WHERE entity_id = ? AND meta_key IN ('phone','address','website','hours','description','city','state')");
                    $q->execute([$ctxEntity]);
                    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { $v = json_decode((string) $r['meta_value'], true) ?? $r['meta_value']; $m[$r['meta_key']] = $v; }
                    $bo['town'] = trim(implode(', ', array_filter([is_string($m['city'] ?? null) ? $m['city'] : '', is_string($m['state'] ?? null) ? $m['state'] : ''])));
                    $has = fn ($k) => !empty($m[$k]) && $m[$k] !== [] && $m[$k] !== '';
                    $bo['have'] = ['Phone' => $has('phone'), 'Address' => $has('address'), 'Website' => $has('website'), 'Hours' => $has('hours'), 'Description' => $has('description'), 'Category' => !empty($er['category_id'])];
                    if (is_file(__DIR__ . '/../../app/lib/Marketing.php')) {
                        require_once __DIR__ . '/../../app/lib/Marketing.php';
                        if (Marketing::tableExists($pdo) && $hasLinks) { $c = Marketing::counts($pdo, $ctxEntity); $bo['nums'] = ['Linked' => (int) $c['linked'], 'Subscribers' => (int) $c['subscribed'], 'New links (30 days)' => (int) $c['new_30d']]; }
                    }
                } catch (Throwable) {}
            }
            $done = count(array_filter($bo['have'])); $of = max(1, count($bo['have']));
        ?>
        <div class="bo<?= $preview ? ' fpo' : '' ?>">
          <?php if ($preview): ?><p class="bo-fpo">Preview for testing: a sample business with sample figures (FPO). Nothing here is real or saved.</p><?php endif; ?>
          <div class="bo-top"><div><h2 class="bo-n"><?= htmlspecialchars($bo['name']) ?></h2><p class="bo-s"><?= htmlspecialchars(implode(' · ', array_filter([$bo['status'], $bo['town']]))) ?></p></div>
            <div class="bo-acts">
              <a class="ab-b go" href="#business">Reply to messages</a>
              <?php if ($preview): ?><span class="ab-b" aria-disabled="true" style="opacity:.55">Post an update (soon)</span><span class="ab-b" aria-disabled="true" style="opacity:.55">Edit listing</span>
              <?php else: ?><a class="ab-b" href="/listing/businessportal.php">Edit listing</a><a class="ab-b" href="/listing/view.php?id=<?= $ctxEntity ?>">See it as visitors do</a><a class="ab-b" href="/listing/location.php?id=<?= $ctxEntity ?>">Location and map pin</a><?php endif; ?>
              <a class="ab-b" href="#team">Team</a></div></div>
          <?php if ($bo['have']): ?>
          <div class="bo-prof"><div class="bo-bar"><span style="width:<?= round(100 * $done / $of) ?>%"></span></div>
            <p class="bo-s">Profile <?= $done ?> of <?= $of ?> complete<?php $miss = array_keys(array_filter($bo['have'], fn ($x) => !$x)); if ($miss): ?>: add <?= htmlspecialchars(mb_strtolower(implode(', ', $miss))) ?> so more searches find you<?php endif; ?>.</p></div>
          <?php endif; ?>
          <?php if ($bo['nums']): ?><div class="bo-nums"><?php foreach ($bo['nums'] as $nl => $nv): ?><div><b><?= (int) $nv ?></b><span><?= htmlspecialchars($nl) ?></span></div><?php endforeach; ?></div><?php endif; ?>
        </div>
        <?php endif; ?>
        <?= tv_pulse_list(['me' => trim((string) ($currentUser['display_name'] ?? '')) ?: 'you', 'needs' => $ctx['kind'] === 'admin']) ?>
      </section>
      <?php if (!empty($tvmOn)): ?>
      <section data-sec="posts" hidden>
        <div id="tvm-comp2" style="margin:0 0 .8rem"></div><div id="tvm-feed"></div>
        <div class="ah-card tv-bleed" style="margin-top:.8rem"><label class="text-sm font-semibold" for="tvm-def">Who sees your new posts, unless you choose otherwise</label>
          <select id="tvm-def" class="tmo-sel" style="display:block;margin-top:.35rem"><?php foreach (MemberPosts::AUDIENCES as $k => [$l, $w]): ?><option value="<?= $k ?>"<?= MemberPosts::defaultAudience($pdo, (int) $currentUser['id']) === $k ? ' selected' : '' ?>><?= htmlspecialchars($l . ': ' . $w) ?></option><?php endforeach; ?></select>
          <p class="text-xs text-[color:var(--tv-meta)] mt-2">Each post lasts 3 or 7 days and is then deleted with its photos and videos, unless you tap Keep: kept posts stay, and their photos and videos go into your Gallery (they count toward your storage).</p></div>
      </section>
      <script src="/js/tv-moments.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-moments.js') ?>"></script>
      <script>
      (function () {   // Moments and Keep (decisions/0153): the composer on your Dashboard, your posts on its Posts tab
        var who = <?= json_encode(['name' => (string) ($pfP['name'] ?? ''), 'avatar' => (string) ($pfP['avatar'] ?? '')], JSON_HEX_TAG | JSON_HEX_AMP) ?>;
        TvMoments.composer(document.getElementById('tvm-comp'), who);    // on the Dashboard, above the Pulse
        TvMoments.composer(document.getElementById('tvm-comp2'), who);   // on the Posts tab, above your posts
        var loaded = false;
        function load() { if (loaded || location.hash.slice(1).split(':')[0] !== 'posts') return; loaded = true; TvMoments.feed(document.getElementById('tvm-feed'), { owner: <?= (int) $currentUser['id'] ?>, self: true }); }
        window.addEventListener('hashchange', load); load();
        // a new post shows where you wrote it, under the box, which stays ready for the next one (Jason, 2026-11-11);
        // the Posts tab puts it first in its list
        document.addEventListener('tvm:posted', function (e) { if (location.hash.slice(1).split(':')[0] !== 'posts') TvMoments.show(document.getElementById('tvm-fresh'), e.detail); });
        var def = document.getElementById('tvm-def');
        def.addEventListener('change', function () {
          fetch('/user/api/posts.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': <?= json_encode($_SESSION['csrf_token'] ?? '') ?> }, body: JSON.stringify({ action: 'audience', audience: def.value }) })
            .then(function (r) { return r.json(); }).then(function (d) { TvAsk.say(d.ok ? 'Saved: new posts start as ' + def.options[def.selectedIndex].text.split(':')[0] + '.' : (d.error && d.error.message) || "That didn't save. Try again.", { anchor: def, bad: !d.ok }); })
            .catch(function () { TvAsk.say("That didn’t save. Check your connection and try again.", { anchor: def, bad: true }); });
        });
      })();
      </script>
      <?php endif; ?>
      <section data-sec="places" hidden>
    <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-6 sm:p-8 shadow-xl" id="saved-places-card">
      <h2 class="text-lg font-bold text-[color:var(--tv-ink)] mb-1">Default places</h2>
      <p class="text-xs text-[color:var(--tv-meta)] mb-4">Save up to 10. Your default is used when you open Get Local directly and search. A region you arrive through (for example from Let's Explore) always wins over it.</p>
      <ul id="places-list" class="space-y-2 mb-3"></ul>
      <p id="places-empty" class="hidden text-xs text-[color:var(--tv-meta)] mb-3">No saved places yet.</p>

      <form id="place-form" class="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-2 items-end">
        <div>
          <label for="pf-kind" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">Add a place</label>
          <select id="pf-kind" class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
            <option value="zip">A ZIP code</option>
            <option value="hub">A region</option>
          </select>
        </div>
        <div>
          <label for="pf-value" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1"><span id="pf-value-label">ZIP code</span></label>
          <input id="pf-value" inputmode="numeric" maxlength="5" placeholder="e.g. 85936" class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
          <select id="pf-region" class="hidden w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]"></select>
        </div>
        <button type="submit" class="bg-[color:var(--tv-umber)] text-[color:var(--tv-on-umber)] rounded-lg py-2 px-4 text-sm font-semibold hover:bg-[color:var(--tv-umber)] transition">Save</button>
        <div class="sm:col-span-3">
          <label for="pf-label" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">Name (optional)</label>
          <input id="pf-label" maxlength="60" placeholder="e.g. Home, Cabin" class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
        </div>
      </form>
      <p id="places-msg" class="text-xs mt-2 min-h-[1rem]" role="status"></p>
    </div>
      </section>
      <section data-sec="addressbook" hidden><div id="ab"></div></section>
      <section data-sec="community" hidden><div class="ah-card">
        <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Groups</h2>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Groups around a place, a pastime or a cause. Posts from your groups show in your Community feed.</p>
        <?php
        $myGroups = [];
        if (is_file(__DIR__ . '/../../app/lib/Community.php')) {
            require_once __DIR__ . '/../../app/lib/Community.php';
            if (Community::ready($pdo)) $myGroups = Community::mine($pdo, (int) $currentUser['id']);
        }
        if ($myGroups): ?>
        <div class="flex flex-wrap gap-2 mt-3">
          <?php foreach ($myGroups as $g): ?>
          <a class="text-sm font-semibold border border-[color:var(--tv-line-strong)] bg-[color:var(--tv-card-a)] rounded-lg px-3 py-1.5 text-[color:var(--tv-ink)] hover:border-amber-700" href="/community/group.php?id=<?= (int) $g['id'] ?>"><?= htmlspecialchars($g['name']) ?><?= $g['status'] === 'pending' ? ' (asked)' : ($g['role'] !== 'member' ? ' · ' . $g['role'] : '') ?></a>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <a class="inline-block mt-3 text-sm font-semibold text-amber-800 hover:underline" href="/community/"><?= $myGroups ? 'Find more groups' : 'Find or start a group' ?> &rarr;</a>
      </div></section>
      <section data-sec="market" hidden><iframe id="pf2-mf" title="Your Marketplace" style="width:100%;border:0;min-height:520px;background:transparent;display:block" loading="lazy"></iframe></section>
      <script>
      // Your Marketplace opens here, in the dashboard (decisions/0135): Selling, Offers, Buying and Post something (#market, #market:offers, #market:buying, #market:new)
      (function () {
        var f = document.getElementById('pf2-mf');
        function load() {
          var h = location.hash.slice(1).split(':');
          if (h[0] !== 'market') return;
          var want = '/user/market/?embed=1' + (h[1] === 'new' ? '&new=1' : (h[1] === 'buying' ? '&tab=buying' : (h[1] === 'offers' ? '&tab=offers' : '')));
          if (f.getAttribute('src') !== want) f.setAttribute('src', want);
        }
        window.addEventListener('hashchange', load); load();
        window.addEventListener('message', function (e) { if (e.origin === location.origin && e.data && e.data.tvEmbed && e.source === f.contentWindow) f.style.height = (e.data.tvEmbed + 8) + 'px'; });
      })();
      </script>
      <section data-sec="domains" hidden><iframe id="pf2-dm" title="Your domains" style="width:100%;border:0;min-height:520px;background:transparent;display:block" loading="lazy"></iframe></section>
      <script>
      // Your domains open here, in the dashboard (decisions/0169 §1a): /user/domains/, embedded (#domains, #domains:wallet)
      (function () {
        var f = document.getElementById('pf2-dm');
        function load() { var h = location.hash.slice(1).split(':'); if (h[0] !== 'domains') return; var want = '/user/domains/?embed=1' + (h[1] === 'wallet' ? '#wallet' : ''); if (f.getAttribute('src') !== want) f.setAttribute('src', want); }
        window.addEventListener('hashchange', load); load();
        window.addEventListener('message', function (e) { if (e.origin === location.origin && e.data && e.data.tvEmbed && e.source === f.contentWindow) f.style.height = (e.data.tvEmbed + 8) + 'px'; });
      })();
      </script>
      <section data-sec="plans" hidden><div class="ah-soon"><h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Travel Plans</h2><p class="mt-1">Plans and collections built from the places, listings and events you save.</p></div></section>
      <section data-sec="links" hidden><div class="ah-card ah-links">
        <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Linked</h2>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Everything you've linked with the chain icon. Links are open connections: the people and businesses you link can see it. Your feeds are built from these; mute keeps a link but shows less of it. Sales messages from businesses follow your <a class="underline text-amber-800" href="#security">marketing preferences</a>.</p>
        <?php if ($openNotice): ?>
        <div class="ol-note mt-3" style="background:var(--tv-card-a,#FFF7E6);border:1px solid #E8A15A;border-radius:.8rem;padding:.7rem .85rem">
          <p class="text-sm"><b>Links are now open connections.</b> From now on, the people and businesses you link can see that you linked them, and you can message each other. Your earlier links stay private until you press <b>Got it</b>. Look through the list below first, and unlink anything you'd rather not show.</p>
          <button type="button" class="ab-b go mt-2" id="ol-ack">Got it</button>
        </div>
        <?php endif; ?>
        <div id="ah-links" class="mt-2 text-sm">Loading…</div>
        <?php $linkedMe = $hasLinks ? Links::linkedBy($pdo, 'person', (string) $currentUser['id']) : []; ?>
        <h3 class="ab-h">Linked to you</h3>
        <?php if (!$linkedMe): ?><p class="text-xs text-[color:var(--tv-meta)] mt-1">No one yet. When someone links you, they appear here; you can remove them or block them.</p><?php endif; ?>
        <?php foreach ($linkedMe as $f): ?>
        <div class="ab-row" data-follower="<?= (int) $f['user_id'] ?>"><a class="ab-name" href="/user/profile.php?id=<?= (int) $f['user_id'] ?>"><?= htmlspecialchars($f['name']) ?></a>
          <span class="ab-acts"><span class="text-xs text-[color:var(--tv-meta)]">since <?= htmlspecialchars(substr($f['since'], 0, 10)) ?></span><button type="button" class="ab-b" data-remove-follower="<?= (int) $f['user_id'] ?>">Remove</button></span></div>
        <?php endforeach; ?>
      </div></section>
      <script>
      (function () {
        function post(body) {
          return fetch('/user/api/links.php?check=', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
            return fetch('/user/api/links.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': d.csrf || '' }, body: JSON.stringify(body) });
          }).then(function (r) { return r.json(); });
        }
        var ack = document.getElementById('ol-ack');
        if (ack) ack.addEventListener('click', function () { post({ action: 'ack_open' }).then(function () { ack.closest('.ol-note').remove(); }); });
        document.addEventListener('click', function (e) {
          var b = e.target.closest('[data-remove-follower]'); if (!b) return;
          if (!TvAsk.gate(b, 'Remove them? Their link to you is removed. They can link you again unless you block them in the Address Book.', { yes: 'Remove', danger: true })) return;
          post({ action: 'remove_follower', id: b.getAttribute('data-remove-follower') }).then(function () { b.closest('[data-follower]').remove(); });
        });
      })();
      </script>
      <section data-sec="profile" hidden><div class="ah-card" id="pf">
        <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Your profile</h2>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">How other people see you on Traversence: on your journeys, comments, groups and messages. Your email is never shown.</p>
        <form id="pf-form" class="pf-f" novalidate>
          <label class="pf-l" for="pf-name">Display name</label>
          <input id="pf-name" name="display_name" class="pf-in" maxlength="40" autocomplete="nickname" placeholder="The name people see">
          <p class="pf-hint" id="pf-shown"></p>
          <div id="pf-bio-wrap" hidden>
            <label class="pf-l" for="pf-bio">Contributor bio</label>
            <textarea id="pf-bio" name="bio" class="pf-in" rows="3" maxlength="400" placeholder="A line or two about you, shown on your journeys"></textarea>
            <p class="pf-hint"><span id="pf-bio-n">0</span>/400</p>
          </div>
          <p class="pf-l">Who can see your profile</p>
          <label class="pf-r"><input type="radio" name="private" value="0"> <span><b>Public</b>: anyone can see your name and journeys, and members can follow you.</span></label>
          <label class="pf-r"><input type="radio" name="private" value="1"> <span><b>Private</b>: people must connect with you instead of following. Private profiles can&rsquo;t publish journeys.</span></label>
          <p class="pf-msg" id="pf-msg" role="status"></p>
          <p style="display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.8rem">
            <button type="submit" class="pf-b go">Save</button>
            <a class="pf-b" href="/user/profile.php?id=<?= (int) $currentUser['id'] ?>" target="_blank">See your public profile</a>
            <a class="pf-b" href="#journeys" data-go="journeys">Your journeys</a>
          </p>
        </form>
        <p class="text-xs text-[color:var(--tv-meta)] mt-3">Email and password are under <a class="underline" href="#security">Privacy</a>. A profile photo is coming; for now your initial is shown.</p>
      </div></section>
      <script>
      (function () {
        var f = document.getElementById('pf-form'); if (!f) return;
        var msg = document.getElementById('pf-msg'), shown = document.getElementById('pf-shown'), bio = document.getElementById('pf-bio'), csrf = '', loaded = false;
        function fill(p) {
          f.display_name.value = p.display_name;
          shown.textContent = p.display_name ? 'People see you as “' + p.shown_as + '”.' : 'You don’t have a name yet, so people see you as “' + p.shown_as + '”.';
          document.getElementById('pf-bio-wrap').hidden = !p.contributor;
          bio.value = p.bio; document.getElementById('pf-bio-n').textContent = p.bio.length;
          f.querySelector('input[name=private][value="' + (p.private ? 1 : 0) + '"]').checked = true;
        }
        function load() {
          if (loaded) return; loaded = true;
          fetch('/user/api/profile.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
            if (d.ok) { csrf = d.csrf || ''; fill(d.profile); } else msg.textContent = (d.error && d.error.message) || 'Couldn’t load your profile.';
          });
        }
        bio.addEventListener('input', function () { document.getElementById('pf-bio-n').textContent = bio.value.length; });
        f.addEventListener('submit', function (e) {
          e.preventDefault(); msg.className = 'pf-msg'; msg.textContent = 'Saving…';
          var body = { display_name: f.display_name.value, private: f.querySelector('input[name=private]:checked').value === '1' };
          if (!document.getElementById('pf-bio-wrap').hidden) body.bio = bio.value;
          fetch('/user/api/profile.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(body) })
            .then(function (r) { return r.json(); }).then(function (d) {
              if (!d.ok) { msg.className = 'pf-msg bad'; msg.textContent = (d.error && d.error.message) || 'Couldn’t save.'; return; }
              fill(d.profile); msg.className = 'pf-msg ok'; msg.textContent = 'Saved.';
              document.querySelectorAll('.cx-n').forEach(function (n) { n.textContent = d.profile.display_name; });
              document.querySelectorAll('.cx-av').forEach(function (n) { n.textContent = d.profile.display_name.charAt(0).toUpperCase(); });
            }).catch(function () { msg.className = 'pf-msg bad'; msg.textContent = 'Couldn’t save. Check your connection.'; });
        });
        function check() { if (location.hash === '#profile') load(); }
        window.addEventListener('hashchange', check); check();
        document.addEventListener('click', function (e) { if (e.target.closest('[data-go="profile"]')) load(); });
      })();
      </script>
      <section data-sec="settings" hidden><div class="ah-card">
        <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">App Settings</h2>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Everyday preferences live here. Tools, marketing and who can reach you are in <a class="underline text-amber-800" href="#security">Privacy Settings</a>.</p>
        <?php require_once __DIR__ . '/../../app/ui/comms-setting.php'; echo tv_comms_setting('member'); /* the one Communications setting: Pulse, email, push, quiet hours (decisions/0172 §4.4) */ ?>
      </div></section>
      <section data-sec="security" hidden>
      <div class="ah-card mb-4">
        <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Privacy Settings</h2>
        <h3 class="ab-h">Your tools</h3>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Each tool is switched on once, with your consent, and you can switch it off any time. Switching off pauses a tool; nothing is deleted. <a class="underline text-amber-800" href="/our-approach.php">Our approach</a></p>
        <div id="yt" class="mt-2 text-sm">Loading…</div>
        <h3 class="ab-h">Marketing</h3>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Businesses you link can message you in your Traversence inbox. Sales messages follow these preferences. Tap a name to change how often, unsubscribe, or share contact details (only then can it email or text you). &times; unlinks it.</p>
        <div id="mk" class="mt-2 text-sm">Loading…</div>
        <p class="text-xs text-[color:var(--tv-meta)] mt-3">Who can message you and how people find you are under Address Book → Controls for now; they move here next.</p>
      </div>
    <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-6 sm:p-8 shadow-xl">
      <h1 class="text-2xl sm:text-3xl font-serif font-bold text-amber-700 mb-2">My Account</h1>
      <div class="text-sm text-[color:var(--tv-meta)] space-y-1 mt-4">
        <p><strong>Email:</strong> <?= htmlspecialchars($currentUser['email']) ?></p>
        <p><strong>Display name:</strong> <?= htmlspecialchars($currentUser['display_name'] ?? '(not set)') ?></p>
        <p><strong>Member since:</strong> <?= htmlspecialchars(date('F j, Y', strtotime($currentUser['created_at']))) ?></p>
      </div>
    </div>
    <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-6 sm:p-8 shadow-xl">
      <h2 class="text-lg font-bold text-[color:var(--tv-ink)] mb-4">Account Security</h2>

      <details class="mb-4">
        <summary class="cursor-pointer text-sm font-semibold text-amber-700">Change Password</summary>
        <form id="password-form" class="space-y-3 mt-3">
          <div>
            <label for="current_password" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">Current Password</label>
            <div class="relative">
              <input type="password" id="current_password" placeholder="Current password" required
                     class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
            </div>
          </div>
          <div>
            <label for="new_password" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">New Password</label>
            <div class="relative">
              <input type="password" id="new_password" placeholder="New password" required minlength="8" autocomplete="new-password"
                     class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
            </div>
          </div>
          <ul id="password-checklist" class="text-xs space-y-0.5 pl-1">
            <li id="check-length" data-label="At least 8 characters" class="text-[color:var(--tv-meta)]">&#10007; At least 8 characters</li>
            <li id="check-upper" data-label="One uppercase letter" class="text-[color:var(--tv-meta)]">&#10007; One uppercase letter</li>
            <li id="check-lower" data-label="One lowercase letter" class="text-[color:var(--tv-meta)]">&#10007; One lowercase letter</li>
            <li id="check-digit" data-label="One number" class="text-[color:var(--tv-meta)]">&#10007; One number</li>
            <li id="check-special" data-label="One special character (e.g. @ $ ! % * ? &amp;)" class="text-[color:var(--tv-meta)]">&#10007; One special character (e.g. @ $ ! % * ? &amp;)</li>
          </ul>
          <div>
            <label for="confirm_new_password" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">Confirm New Password</label>
            <div class="relative">
              <input type="password" id="confirm_new_password" placeholder="Confirm new password" required minlength="8" autocomplete="new-password" data-pw-match="#new_password"
                     class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
            </div>
          </div>
          <button type="submit" class="bg-[color:var(--tv-umber)] text-[color:var(--tv-on-umber)] rounded-lg py-2 px-4 text-sm font-semibold hover:bg-[color:var(--tv-umber)] transition">Update Password</button>
        </form>
        <div id="password-status" class="text-sm mt-2"></div>
      </details>

      <details>
        <summary class="cursor-pointer text-sm font-semibold text-amber-700">Change Email</summary>
        <form id="email-request-form" class="space-y-3 mt-3">
          <div>
            <label for="email_current_password" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">Current Password</label>
            <div class="relative">
              <input type="password" id="email_current_password" placeholder="Current password" required
                     class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
            </div>
          </div>
          <div>
            <label for="new_email" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">New Email Address</label>
            <input type="email" id="new_email" placeholder="New email address" required
                   class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
          </div>
          <button type="submit" class="bg-[color:var(--tv-umber)] text-[color:var(--tv-on-umber)] rounded-lg py-2 px-4 text-sm font-semibold hover:bg-[color:var(--tv-umber)] transition">Send Verification Code</button>
        </form>
        <form id="email-confirm-form" class="space-y-3 mt-3 hidden">
          <div>
            <label for="email_code" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">Verification Code</label>
            <input type="text" id="email_code" placeholder="6-digit code" required
                   class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
          </div>
          <button type="submit" class="bg-[color:var(--tv-umber)] text-[color:var(--tv-on-umber)] rounded-lg py-2 px-4 text-sm font-semibold hover:bg-[color:var(--tv-umber)] transition">Confirm New Email</button>
        </form>
        <div id="email-status" class="text-sm mt-2"></div>
      </details>
      <?php // Ways to sign in (decisions/0090): link Google, Apple, Microsoft or Facebook to this account, whatever its email
      require_once __DIR__ . '/../../app/lib/SignInLinks.php'; require_once __DIR__ . '/../../app/ui/social-buttons.php';
      $siOn = tv_social_list(); $siLinks = SignInLinks::list($pdo, (int) $currentUser['id']);
      $siDone = (string) ($_SESSION['tv_link_done'] ?? ''); unset($_SESSION['tv_link_done']); ?>
      <div class="mt-5 pt-4 border-t border-[color:var(--tv-line-strong)]" id="sign-ins">
        <h3 class="text-sm font-bold text-[color:var(--tv-ink)]">Ways to sign in</h3>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Link the accounts you use, even with a different email, so any of them signs you in here. Signing in only tells us who you are.</p>
        <?php if ($siDone !== ''): ?><p class="text-sm mt-2 rounded-lg p-2" role="status" style="<?= $siDone[0] === '!' ? 'background:#FEE2E2;color:var(--tv-crimson,#991B1B)' : 'background:#DCFCE7;color:#166534' ?>"><?= htmlspecialchars($siDone[0] === '!' ? substr($siDone, 1) : $siDone . ' is linked. You can sign in with it now.') ?></p><?php endif; ?>
        <ul class="mt-2 space-y-2">
          <li class="flex items-center justify-between gap-2 text-sm"><span><b>Email and password</b> <span class="text-[color:var(--tv-meta)]"><?= htmlspecialchars((string) $currentUser['email']) ?></span></span><a class="text-amber-800 underline text-xs" href="/forgot-password.php">Set a password</a></li>
          <?php foreach ($siLinks as $sk => $si): if (!$si['linked'] && !isset($siOn[$sk])) continue; ?>
          <li class="flex items-center justify-between gap-2 text-sm">
            <span><b><?= htmlspecialchars($si['label']) ?></b> <?= $si['linked'] ? '<span class="text-[#166534]">Linked</span>' . ($si['email'] !== '' ? ' <span class="text-[color:var(--tv-meta)]">' . htmlspecialchars($si['email']) . '</span>' : '') : '<span class="text-[color:var(--tv-meta)]">Not linked</span>' ?></span>
            <?php if ($si['linked']): ?>
            <button type="button" class="text-xs font-semibold rounded-lg px-2 py-1" style="border:1px solid var(--tv-line-strong,#CBB98D)" data-unlink="<?= $sk ?>" data-msg="Disconnect <?= htmlspecialchars($si['label']) ?>? You'll sign in another way (set a password first if you haven't).">Disconnect</button>
            <?php else: ?>
            <a class="text-xs font-semibold rounded-lg px-2 py-1 text-white" style="background:var(--tv-btn,#92400E)" href="<?= htmlspecialchars($siOn[$sk][1]) ?>&amp;link=1">Connect</a>
            <?php endif; ?>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
      <script>
      document.querySelectorAll('[data-unlink]').forEach(function (b) {
        b.addEventListener('click', async function () {
          if (window.TvAsk && !TvAsk.gate(b, b.getAttribute('data-msg'), { yes: 'Disconnect', danger: true })) return;
          var s = await (await fetch('/api/auth/session.php', { credentials: 'include' })).json();
          var r = await (await fetch('/user/api/sign-ins.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': s.csrf_token }, body: JSON.stringify({ disconnect: b.getAttribute('data-unlink') }) })).json();
          if (r.ok) { location.hash = 'security'; location.reload(); } else if (window.TvAsk) TvAsk.say((r.error && r.error.message) || 'That didn\'t work.', { anchor: b });
        });
      });
      </script>
      <?php require_once __DIR__ . '/../../app/lib/StaffLogin.php'; $tvSt = StaffLogin::ready($pdo) && !StaffLogin::isStaffUser((string) ($currentUser["email"] ?? "")) ? StaffLogin::forMember($pdo, (int) $currentUser["id"]) : null; ?>
      <?php if ($tvSt): // linked by an owner from the admin (People → Staff logins) and confirmed by the member ?>
      <div class="mt-5 pt-4 border-t border-[color:var(--tv-line-strong)]" id="staff-link">
        <h3 class="text-sm font-bold text-[color:var(--tv-ink)]">Staff login</h3>
        <?php foreach ($tvSt as $sx): ?>
          <p class="text-sm text-[color:var(--tv-meta)] mt-1">Linked: <b><?= htmlspecialchars($sx['staff_id']) ?></b> (<?= htmlspecialchars($sx['name']) ?>). Staff notices can reach you here. This member account still can't open the admin side: staff sign in at <a class="underline" href="/admin/login.php">/admin/login.php</a>.
          <button type="button" class="text-xs font-semibold rounded-lg px-2 py-1 ml-1" style="border:1px solid var(--tv-line-strong,#CBB98D)" data-staff-unlink="<?= (int) $sx['id'] ?>">Unlink</button></p>
        <?php endforeach; ?>
      </div>
      <script>
      (function () {
        async function post(b, el) {
          var s = await (await fetch('/api/auth/session.php', { credentials: 'include' })).json();
          var r = await (await fetch('/user/api/staff-link.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': s.csrf_token }, body: JSON.stringify(b) })).json();
          if (r.ok && r.sent) { if (window.TvAsk) TvAsk.say('Code sent to ' + r.sent + '.', { anchor: el }); }
          else if (r.ok) { location.hash = 'security'; location.reload(); } else if (window.TvAsk) TvAsk.say((r.error && r.error.message) || 'That didn\'t work.', { anchor: el });
        }
        document.querySelectorAll('[data-staff-unlink]').forEach(function (b) { b.addEventListener('click', function () { if (window.TvAsk && !TvAsk.gate(b, 'Unlink your staff login from this account?', { yes: 'Unlink' })) return; post({ unlink: +b.getAttribute('data-staff-unlink') }, b); }); });
      })();
      </script>
      <?php endif; ?>
      <div class="mt-5 pt-4 border-t border-[color:var(--tv-line-strong)]">
        <h3 class="text-sm font-bold text-[color:var(--tv-ink)]">Your plan</h3>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Your personal plan, storage and AI Assist credits, and the plans of businesses you manage.</p>
        <a href="/plans.php" class="inline-block mt-2 text-sm font-semibold rounded-lg px-3 py-1.5" style="color:var(--tv-link,#92400E);border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2)">Plans</a>
      </div>
      <div class="mt-5 pt-4 border-t border-[color:var(--tv-line-strong)]">
        <h3 class="text-sm font-bold text-[color:var(--tv-ink)]">Delete my account</h3>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Delete your account and what's tied to it, for good. You'll see exactly what happens before anything is deleted.</p>
        <a href="/user/delete-account.php" class="inline-block mt-2 text-sm font-semibold rounded-lg px-3 py-1.5" style="color:var(--tv-crimson,#B91C1C);border:1px solid #B91C1C">Delete my account…</a>
      </div>
    </div>
      </section>
      <section data-sec="help" hidden><div class="ah-card">
        <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Help Center</h2>
        <ul class="text-sm mt-2 space-y-1 list-disc list-inside">
          <li><a class="underline text-amber-800" href="/claim.php">Claim or add a business</a></li>
          <li><a class="underline text-amber-800" href="/privacy.php">Privacy</a> and <a class="underline text-amber-800" href="/terms.php">terms</a></li>
        </ul>
      </div></section>
      <section data-sec="business" hidden>
    <?php if ($preview): ?><div class="ah-soon" style="margin-bottom:1rem"><b>Sample business (preview).</b> A real listing's customer messages, guest questions and insights appear here for its team. Nothing is shown for the sample, and no real conversations are ever opened in a preview.</div><?php endif; ?>
    <?php
    // Your own account: the businesses you run, each opening its own pages (Jason, 2026-11-12: "not sure we need this business
    // listing part since we have a user profile manager now"). Their messages, insights and editing are there, acting as the
    // business (the profile switcher, top left), not repeated here; the old portal banner is gone.
    if ($ctx['kind'] !== 'org' && !$preview):
        $mine = [];
        try { $st = $pdo->prepare('SELECT DISTINCT e.id, e.name FROM listing_access a JOIN entities e ON e.id = a.entity_id WHERE a.user_id = ? ORDER BY e.name LIMIT 50'); $st->execute([$currentUser['id']]); $mine = $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable) {} ?>
    <div class="ah-card">
      <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Your businesses</h2>
      <?php if ($mine): ?>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Each business has its own pages: its messages, insights, listing and team. Open one here, or switch to it with the profile switcher at the top left.</p>
        <div class="mt-2" style="display:grid;gap:3px">
        <?php foreach ($mine as $b): ?>
          <div class="tv-bleed" style="display:flex;align-items:center;justify-content:space-between;gap:.6rem;background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.75);border-radius:.6rem;padding:.6rem .8rem">
            <a href="/business/<?= (int) $b['id'] ?>" style="font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;color:var(--tv-link,#92400E);text-decoration:underline;text-underline-offset:3px"><?= htmlspecialchars((string) $b['name']) ?></a>
            <span style="display:flex;gap:.4rem;flex-wrap:wrap"><a class="ab-b go" href="/business/<?= (int) $b['id'] ?>">Open</a><a class="ab-b" href="/listing/view.php?id=<?= (int) $b['id'] ?>">See it as visitors do</a></span>
          </div>
        <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">You don't run a business on Traversence yet.</p>
      <?php endif; ?>
      <p class="text-sm mt-3"><a class="underline text-amber-800" href="/claim.php">Claim or add a business</a></p>
    </div>
    <?php else: // acting as a business (or its preview): its messages and insights ?>
    <?php
    // Business Insights (decisions/0047 §3): counts only, never names.
    $insights = [];
    if (($managesListings || $ctxEntity) && !$preview) {
        require_once __DIR__ . '/../../app/lib/Marketing.php';
        if (Marketing::tableExists($pdo) && $hasLinks) {
            try {
                $st = $pdo->prepare('SELECT DISTINCT e.id, e.name FROM listing_access a JOIN entities e ON e.id = a.entity_id WHERE a.user_id = ?' . ($ctxEntity ? ' AND e.id = ' . $ctxEntity : '') . ' ORDER BY e.name LIMIT 20');
                $st->execute([$currentUser['id']]);
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $e) $insights[] = [$e['name'], Marketing::counts($pdo, (int) $e['id']), (int) $e['id']];
            } catch (Throwable) { $insights = []; }
        }
    }
    $IN = ['linked' => 'Linked', 'subscribed' => 'Subscribers', 'unsubscribed' => 'Unsubscribed', 'new_30d' => 'New links (30 days)', 'sharing_contact' => 'Shared contact info', 'never_ask' => 'Asked never to be asked'];
    if ($insights): ?>
    <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-6 sm:p-8 shadow-xl">
      <h2 class="text-lg font-bold text-[color:var(--tv-ink)]">Business Insights</h2>
      <p class="text-xs text-[color:var(--tv-meta)] mt-1 mb-3">Links are open connections: you can see who linked you. Subscribers can receive your Sales messages in their Traversence inbox; contact details only if they choose to share them.</p>
      <?php foreach ($insights as [$bn, $c, $eid]): ?>
      <h3 class="text-sm font-semibold text-[color:var(--tv-ink)] mt-3"><?= htmlspecialchars((string) $bn) ?></h3>
      <div class="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-1">
        <?php foreach ($IN as $k => $label): ?>
        <div class="bg-[color:var(--tv-card-a)] border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2"><div class="text-xl font-bold text-[color:var(--tv-ink)]"><?= (int) $c[$k] ?></div><div class="text-xs text-[color:var(--tv-meta)]"><?= $label ?></div></div>
        <?php endforeach; ?>
      </div>
      <?php // what visitors did from the listing, last 30 days (decisions/0058 §9): counts only, never who
      require_once __DIR__ . '/../../app/lib/ListingActions.php';
      if (ListingActions::ready($pdo)): $acts = ListingActions::summary($pdo, (int) $eid, 30);
        require_once __DIR__ . '/../../app/lib/PlatformCounts.php';
        $lviews = PlatformCounts::total($pdo, 'view', 30, 'listing:' . (int) $eid)['visits']; ?>
      <p class="text-xs font-semibold text-[color:var(--tv-meta)] mt-3">From your listing, last 30 days</p>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-1">
        <div class="bg-[color:var(--tv-card-a)] border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2"><div class="text-xl font-bold text-[color:var(--tv-ink)]"><?= (int) $lviews ?></div><div class="text-xs text-[color:var(--tv-meta)]">Visits to your listing</div></div>
        <?php foreach (ListingActions::ACTIONS as $k => $label): ?>
        <div class="bg-[color:var(--tv-card-a)] border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2"><div class="text-xl font-bold text-[color:var(--tv-ink)]"><?= (int) $acts[$k] ?></div><div class="text-xs text-[color:var(--tv-meta)]"><?= $label ?></div></div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
      <?php
      // Links are open connections (decisions/0052): the business sees who linked it, with their marketing choice.
      $who = Links::linkedBy($pdo, 'business', (string) $eid, 200);
      $mk = [];
      if ($who) {
          try {
              $in = implode(',', array_map(fn ($w) => (int) $w['user_id'], $who));
              foreach ($pdo->query("SELECT l.user_id, m.status, m.frequency, s.no_marketing FROM user_links l LEFT JOIN marketing_optins m ON m.user_id = l.user_id AND m.entity_id = " . (int) $eid . "
                                     LEFT JOIN user_settings s ON s.user_id = l.user_id WHERE l.target_type = 'business' AND l.target_id = '" . (int) $eid . "' AND l.user_id IN ($in)")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                  $mk[(int) $r['user_id']] = (int) $r['no_marketing'] === 1 ? 'No sales messages' : ($r['status'] === 'no' ? 'Unsubscribed' : 'Subscribed');
              }
          } catch (Throwable) { $mk = []; }
      }
      ?>
      <details class="mt-2"><summary class="text-sm font-semibold text-amber-800 cursor-pointer">Linked to you (<?= count($who) ?>)</summary>
        <?php if (!$who): ?><p class="text-xs text-[color:var(--tv-meta)] mt-1">No one yet, or only people who linked you before links were open and haven't confirmed it.</p><?php endif; ?>
        <?php foreach ($who as $w): ?>
        <div class="flex justify-between gap-2 text-sm border-t border-[color:var(--tv-line-strong)] py-1.5"><span><?= htmlspecialchars($w['name']) ?></span>
          <span class="text-xs text-[color:var(--tv-meta)]"><?= htmlspecialchars($mk[$w['user_id']] ?? 'Subscribed') ?> · since <?= htmlspecialchars(substr($w['since'], 0, 10)) ?></span></div>
        <?php endforeach; ?>
      </details>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php foreach ($insights as $i => [$bn, $c, $eid]): ?>
    <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-6 sm:p-8 shadow-xl bz" data-e="<?= (int) $eid ?>">
      <h2 class="text-lg font-bold text-[color:var(--tv-ink)]">Messages &amp; offers · <?= htmlspecialchars((string) $bn) ?></h2>
      <div class="bz-body text-sm mt-2">Loading…</div>
    </div>
    <?php endforeach; ?>
    <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-6 sm:p-8 shadow-xl">
      <h2 class="text-lg font-bold text-[color:var(--tv-ink)] mb-4">Referral Requests</h2>
      <div id="referrals-container" class="text-sm text-[color:var(--tv-meta)]">Loading…</div>
    </div>
    <?php endif; ?>
      </section>
      <section data-sec="team" hidden><div class="ah-card" id="team-box"><p class="text-sm">Loading…</p></div></section>
      <?php if ($ctx['kind'] === 'steward'): ?>
      <section data-sec="steward" hidden><div class="ah-card">
        <h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Your communities</h2>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">The communities you run. Requests to join, member reports and escalations for them come to you here; Traversence staff step in only on an escalation (Level 2).</p>
        <?php foreach ($ctx['scope']['groups'] as $g):
            $pend = 0; $mem = 0;
            try { $q = $pdo->prepare("SELECT SUM(status = 'pending'), SUM(status = 'active') FROM community_group_members WHERE group_id = ?"); $q->execute([$g['id']]); [$pend, $mem] = array_map('intval', $q->fetch(PDO::FETCH_NUM)); } catch (Throwable) {} ?>
          <div class="ab-row"><a class="ab-name" href="/community/group.php?id=<?= (int) $g['id'] ?>"><?= htmlspecialchars($g['name']) ?></a>
            <span class="ab-acts"><span class="text-xs text-[color:var(--tv-meta)]"><?= $mem ?> member<?= $mem === 1 ? '' : 's' ?></span><?php if ($pend): ?><a class="ab-b go" href="/community/group.php?id=<?= (int) $g['id'] ?>#requests"><?= $pend ?> asking to join</a><?php endif; ?></span></div>
        <?php endforeach; ?>
      </div></section>
      <?php endif; ?>
      <?php /* the admin dashboard (Today, Procedures, Staff & roles) moved to /admin/ (decisions/0078) */ ?>
      <section data-sec="admin" hidden>
    <?php /* no "Become Super-Admin" any more: the admin side is staff logins only (decisions/0100), and owners make staff logins. */ ?>
      </section>
      <?php if ($pfOwner): $pfG = MemberProfile::gallery($pdo, (int) $currentUser['id']); $pfD = $pfP['details']; $pfOn = array_flip($pfP['published']); ?>
      <section data-sec="about" hidden><div class="ah-card">
        <div class="flex justify-between gap-2 flex-wrap items-center"><h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">About</h2>
          <span class="text-sm"><a class="underline text-[color:var(--tv-link)]" href="/user/profile.php?id=<?= (int) $currentUser['id'] ?>">See it as others do</a></span></div>
        <?php if (($pfD['about'] ?? '') !== ''): ?>
          <p class="text-sm mt-2" style="white-space:pre-line"><?= htmlspecialchars($pfD['about'], ENT_QUOTES) ?></p>
          <p class="text-xs text-[color:var(--tv-meta)] mt-1"><?= isset($pfOn['about']) ? 'Public' : 'Only you: switch on its eye to publish it' ?></p>
        <?php else: ?>
          <p class="text-sm mt-2">Tell people a little about yourself. <button type="button" class="underline text-[color:var(--tv-link)]" data-edit="personal">Add About me</button></p>
        <?php endif; ?>
        <div class="mt-4 flex flex-wrap gap-2">
          <button type="button" class="ab-b" data-edit="card">Edit your card</button>
          <button type="button" class="ab-b" data-edit="personal">Edit details</button>
          <a class="ab-b" href="#profile" data-go="profile">Name and privacy</a>
          <a class="ab-b" href="#pulse" data-go="pulse">Go to your Pulse</a>
        </div>
        <p class="text-xs text-[color:var(--tv-meta)] mt-3">Member since <?= htmlspecialchars(date('F Y', strtotime((string) $pfP['joined'])), ENT_QUOTES) ?> · <?= count($pfP['published']) ?> item<?= count($pfP['published']) === 1 ? '' : 's' ?> published<?= $pfP['private'] ? ' · private profile' : '' ?></p>
      </div></section>
      <section data-sec="gallery" hidden><div class="ah-card">
        <?php
          // the gallery module (decisions/0126) in the dashboard: your newest photos and your albums, the full gallery a tap away
          require_once __DIR__ . '/../../app/lib/Gallery.php'; require_once __DIR__ . '/../../app/ui/gallery-ui.php';
          $gUid = (int) $currentUser['id'];
          try { Gallery::sync($pdo, $gUid); $gAll = Gallery::items($pdo, 'members', (string) $gUid); $gAlbums = Gallery::albums($pdo, 'members', (string) $gUid, true); }
          catch (Throwable $gx) { error_log('dashboard gallery: ' . $gx->getMessage()); $gAll = []; $gAlbums = []; }
          $gViews = Gallery::mark($pdo, array_map(fn ($it) => Gallery::view($it), array_slice($gAll, 0, 12)), $gUid);
          echo tv_gallery_css();
        ?>
        <div class="flex justify-between gap-2 flex-wrap items-center"><h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">Gallery</h2>
          <span class="flex gap-2 flex-wrap"><a class="gl-b go" href="/gallery/">Open your gallery</a><a class="gl-b" href="/gallery/?tab=albums">Albums</a></span></div>
        <p class="text-sm text-[color:var(--tv-meta)] mt-1">Every photo and video you keep: uploads, your journeys and your profile photos, in albums you share as you choose. <?= count($gAll) ?> item<?= count($gAll) === 1 ? '' : 's' ?><?= count($gAll) > 12 ? ', the newest 12 here' : '' ?>.</p>
        <div class="gl" style="margin-top:.7rem">
          <?php if ($gAlbums): ?><h3 class="gl-mo">Albums <small><?= count($gAlbums) ?></small></h3><div class="gl-albums tv-bleed" style="margin-bottom:.8rem"><?php foreach (array_slice($gAlbums, 0, 4) as $ga) echo tv_gallery_album_card($ga, '/gallery/album.php?a=' . (int) $ga['id'], true); ?></div><?php endif; ?>
          <?php if ($gViews): ?><h3 class="gl-mo">Newest</h3><div class="gl-rows tv-bleed"><?php foreach ($gViews as $gi => $gv) echo tv_gallery_tile($gv, $gi); ?></div>
          <?php else: ?><div class="gl-empty tv-bleed"><p class="font-serif font-bold text-lg">No photos yet</p><p class="text-sm mt-1"><a class="underline text-[color:var(--tv-link)]" href="/gallery/">Upload photos and videos</a>, add a profile or cover photo, or <a class="underline text-[color:var(--tv-link)]" href="#journeys:new">write a journey</a> with photos.</p></div><?php endif; ?>
        </div>
        <script>window.TV_GAL = <?= json_encode(['items' => $gViews, 'albums' => array_map(fn ($a) => ['id' => (int) $a['id'], 'title' => $a['title'], 'n' => (int) $a['n']], $gAlbums), 'own' => true, 'csrf' => (string) ($_SESSION['csrf_token'] ?? ''),
          'me' => ['name' => (string) $pfP['name'], 'avatar' => (string) $pfP['avatar']]], JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES) ?>;</script>
        <script src="/js/photo-viewer.js?v=<?= (int) @filemtime(__DIR__ . '/../js/photo-viewer.js') ?>"></script>
        <script src="/js/gallery.js?v=<?= (int) @filemtime(__DIR__ . '/../js/gallery.js') ?>"></script>
      </div></section>
      <section data-sec="journeys" hidden><iframe id="pf2-jf" title="Your journeys" style="width:100%;border:0;min-height:520px;background:transparent;display:block" loading="lazy"></iframe></section>
      <script>
      // Journeys open here, in the dashboard: the frame loads the journeys tools and grows with them (#journeys, #journeys:new)
      (function () {
        var f = document.getElementById('pf2-jf');
        function load() {
          var h = location.hash.slice(1).split(':');
          if (h[0] !== 'journeys') return;
          var want = h[1] === 'new' ? '/user/journeys/compose.php?embed=1' : '/user/journeys/?embed=1';
          if (f.getAttribute('src') !== want) f.setAttribute('src', want);
        }
        window.addEventListener('hashchange', load); load();
        window.addEventListener('message', function (e) { if (e.origin === location.origin && e.data && e.data.tvEmbed && e.source === f.contentWindow) f.style.height = (e.data.tvEmbed + 8) + 'px'; });
      })();
      </script>
      <?php foreach (['checkins' => ['Check-ins', 'Places you\'ve been, shared when you choose.'], 'events' => ['Events', 'Events you\'re going to or hosting.'], 'reviews' => ['Reviews', 'What you\'ve recommended.']] as $pfK => [$pfT, $pfW]): ?>
      <section data-sec="<?= $pfK ?>" hidden><div class="ah-soon"><h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]"><?= $pfT ?></h2><p class="mt-1"><?= $pfW ?> Coming.</p></div></section>
      <?php endforeach; echo tv_profile_close() . tv_profile_editor($pfP); endif; ?>
    </div>
  <?php tv_app_close(); ?>
  </main>

  <footer class="border-t border-[color:var(--tv-line-strong)] bg-[color:var(--tv-canvas)] py-6 text-center text-xs text-[color:var(--tv-meta)]">
    &copy; Traversence
  </footer>

  <?php require_once __DIR__ . '/../../app/ui/location-modal.php'; ?>

  <script src="/js/shared-auth.js"></script>
  <script src="/js/location-scope.js?v=<?= (int)@filemtime(__DIR__ . '/../js/location-scope.js') ?>"></script>
  <script src="/js/header-nav.js?v=<?= (int)@filemtime(__DIR__ . '/../js/header-nav.js') ?>" defer></script>
  <script>
  // Saved places (api/places.php). Self-contained; does not touch the account code below.
  (function () {
    var csrf = null;
    function $(id) { return document.getElementById(id); }
    function msg(text, bad) { var m = $('places-msg'); m.textContent = text || ''; m.className = 'text-xs mt-2 min-h-[1rem] ' + (bad ? 'text-red-700' : 'text-green-700'); }
    function api(method, body) {
      return fetch('/api/places.php', {
        method: method, credentials: 'include',
        headers: method === 'POST' ? { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' } : {},
        body: method === 'POST' ? JSON.stringify(body) : undefined,
      }).then(function (r) { return r.json(); });
    }
    function btn(text, fn) { var b = document.createElement('button'); b.type = 'button'; b.textContent = text; b.className = 'text-xs px-2 py-1 rounded border border-[color:var(--tv-line-strong)] hover:bg-[#D5C39A] transition'; b.addEventListener('click', fn); return b; }
    function render(places) {
      var ul = $('places-list'); ul.textContent = '';
      $('places-empty').classList.toggle('hidden', places.length > 0);
      places.forEach(function (p) {
        var li = document.createElement('li');
        li.className = 'flex items-center justify-between gap-2 bg-[color:var(--tv-canvas)] border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2';
        var name = document.createElement('span'); name.className = 'text-sm font-semibold truncate'; name.textContent = p.label;
        if (p.is_default) { var b = document.createElement('span'); b.className = 'ml-2 text-[10px] uppercase tracking-wide bg-green-200 text-green-900 rounded px-1.5 py-0.5'; b.textContent = 'Default'; name.appendChild(b); }
        var acts = document.createElement('span'); acts.className = 'flex gap-2 shrink-0';
        if (p.id) {
          if (!p.is_default) acts.appendChild(btn('Make default', function () { act({ action: 'default', id: p.id }); }));
          acts.appendChild(btn('Remove', function () { act({ action: 'delete', id: p.id }); }));
        } else { var n = document.createElement('span'); n.className = 'text-[11px] text-[color:var(--tv-meta)]'; n.textContent = 'from your profile'; acts.appendChild(n); }
        li.appendChild(name); li.appendChild(acts); ul.appendChild(li);
      });
    }
    function act(body) {
      msg('Saving...');
      api('POST', body).then(function (d) {
        if (!d.success) { msg((d.error && d.error.message) || d.error || 'Something went wrong.', true); return; }
        render(d.places || []); msg('Saved.');
      }).catch(function () { msg('Could not reach the server.', true); });
    }
    $('pf-kind').addEventListener('change', function () {
      var zip = this.value === 'zip';
      $('pf-value').classList.toggle('hidden', !zip); $('pf-region').classList.toggle('hidden', zip);
      $('pf-value-label').textContent = zip ? 'ZIP code' : 'Region';
    });
    $('place-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var body = { action: 'add', label: $('pf-label').value.trim() };
      if ($('pf-kind').value === 'zip') body.zip = $('pf-value').value.trim();
      else { body.level = 'hub'; body.slug = $('pf-region').value; }
      act(body); $('pf-value').value = ''; $('pf-label').value = '';
    });
    fetch('/api/auth/session.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      csrf = d.csrf_token;
      api('GET').then(function (r) { if (r.success) render(r.places || []); else msg((r.error && r.error.message) || 'Could not load your places.', true); });
    }).catch(function () { msg('Could not load your places.', true); });
    fetch('/api/place.php?action=hubs').then(function (r) { return r.json(); }).then(function (d) {
      var sel = $('pf-region'); sel.textContent = '';
      (d.hubs || []).filter(function (h) { return h.status !== 'planned'; }).forEach(function (h) {
        var o = document.createElement('option'); o.value = h.slug; o.textContent = h.name; sel.appendChild(o);
      });
    }).catch(function () {});
  })();
  </script>
  <script>
    let csrfToken = null;

    async function apiFetch(url, options = {}) {
      const opts = Object.assign({ headers: {} }, options);
      opts.headers['Content-Type'] = 'application/json';
      if (opts.method && opts.method !== 'GET') {
        opts.headers['X-CSRF-Token'] = csrfToken;
      }
      const res = await fetch(url, opts);
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || data.message || 'Request failed.');
      }
      return data;
    }

    function togglePasswordVisibility(fieldId, btn) {
      const field = document.getElementById(fieldId);
      const isPassword = field.type === 'password';
      field.type = isPassword ? 'text' : 'password';
      btn.textContent = isPassword ? 'Hide' : 'Show';
    }

    function escapeHtml(str) {
      const div = document.createElement('div');
      div.textContent = str;
      return div.innerHTML;
    }

    function checkPasswordRequirements(password) {
      return {
        length:  password.length >= 8,
        upper:   /[A-Z]/.test(password),
        lower:   /[a-z]/.test(password),
        digit:   /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password),
      };
    }

    function renderPasswordChecklist(password) {
      const results = checkPasswordRequirements(password);
      const map = { length: 'check-length', upper: 'check-upper', lower: 'check-lower', digit: 'check-digit', special: 'check-special' };
      for (const [key, id] of Object.entries(map)) {
        const el = document.getElementById(id);
        const met = results[key];
        el.className = met ? 'text-green-700' : 'text-[color:var(--tv-meta)]';
        el.textContent = (met ? '\u2713 ' : '\u2717 ') + el.dataset.label;
      }
      return Object.values(results).every(Boolean);
    }

    document.getElementById('new_password').addEventListener('input', (e) => renderPasswordChecklist(e.target.value));

    function renderReferrals(data) {
      const container = document.getElementById('referrals-container');
      const parts = [];

      if (data.pending_your_confirmation.length > 0) {
        parts.push('<p class="font-semibold text-[color:var(--tv-ink)] mb-2">Awaiting your confirmation:</p>');
        data.pending_your_confirmation.forEach(r => {
          parts.push(`<div class="mb-2 pl-3 border-l-2 border-amber-500">
            <p>${escapeHtml(r.entity_name)} is requesting your referral.</p>
            <a class="text-amber-700 hover:text-amber-600 font-semibold text-xs" href="/listing/confirm-referral.php?token=${encodeURIComponent(r.confirmation_token)}">Review &amp; Confirm &rarr;</a>
          </div>`);
        });
      }

      if (data.sent_by_you.length > 0) {
        parts.push('<p class="font-semibold text-[color:var(--tv-ink)] mt-4 mb-2">Referrals you\'ve sent:</p>');
        data.sent_by_you.forEach(r => {
          const status = r.confirmed_at ? 'Confirmed' : 'Pending';
          parts.push(`<p class="pl-3">${escapeHtml(r.entity_name)} &mdash; ${escapeHtml(r.referrer_email)}: <strong>${status}</strong></p>`);
        });
      }

      if (parts.length === 0) {
        container.innerHTML = '<p>No referral activity yet.</p>';
      } else {
        container.innerHTML = parts.join('');
      }
    }

    async function loadReferrals() {
      if (!document.getElementById('referrals-container')) return;   // shown only acting as a business (2026-11-12)
      try {
        const data = await apiFetch('/user/api/referrals.php');
        renderReferrals(data);
      } catch (err) {
        document.getElementById('referrals-container').innerHTML =
          `<p class="text-red-700">Could not load referrals: ${escapeHtml(err.message)}</p>`;
      }
    }

    document.getElementById('password-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const statusEl = document.getElementById('password-status');
      const newPassword = document.getElementById('new_password').value;
      const confirmPassword = document.getElementById('confirm_new_password').value;

      if (!renderPasswordChecklist(newPassword)) {
        statusEl.textContent = 'New password does not meet all requirements above.';
        statusEl.className = 'text-sm mt-2 text-red-700';
        return;
      }
      if (newPassword !== confirmPassword) {
        statusEl.textContent = 'New password and confirmation do not match.';
        statusEl.className = 'text-sm mt-2 text-red-700';
        return;
      }

      try {
        const data = await apiFetch('/api/auth/change-password.php', {
          method: 'POST',
          body: JSON.stringify({
            current_password: document.getElementById('current_password').value,
            new_password: newPassword,
          }),
        });
        statusEl.textContent = data.message;
        statusEl.className = 'text-sm mt-2 text-green-700';
        e.target.reset();
      } catch (err) {
        statusEl.textContent = err.message;
        statusEl.className = 'text-sm mt-2 text-red-700';
      }
    });

    let pendingNewEmail = null;

    document.getElementById('email-request-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const statusEl = document.getElementById('email-status');
      const newEmail = document.getElementById('new_email').value;
      try {
        const data = await apiFetch('/api/auth/email/request-change.php', {
          method: 'POST',
          body: JSON.stringify({
            current_password: document.getElementById('email_current_password').value,
            new_email: newEmail,
          }),
        });
        pendingNewEmail = newEmail;
        statusEl.textContent = data.message;
        statusEl.className = 'text-sm mt-2 text-green-700';
        document.getElementById('email-confirm-form').classList.remove('hidden');
      } catch (err) {
        statusEl.textContent = err.message;
        statusEl.className = 'text-sm mt-2 text-red-700';
      }
    });

    document.getElementById('email-confirm-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const statusEl = document.getElementById('email-status');
      try {
        const data = await apiFetch('/api/auth/email/confirm-change.php', {
          method: 'POST',
          body: JSON.stringify({
            new_email: pendingNewEmail,
            code: document.getElementById('email_code').value,
          }),
        });
        statusEl.textContent = data.message + ' Reloading…';
        statusEl.className = 'text-sm mt-2 text-green-700';
        setTimeout(() => window.location.reload(), 1500);
      } catch (err) {
        statusEl.textContent = err.message;
        statusEl.className = 'text-sm mt-2 text-red-700';
      }
    });

    (async function init() {
      const session = await apiFetch('/api/auth/session.php');
      csrfToken = session.csrf_token;
      window.appCsrfToken = session.csrf_token; // shared-auth.js's logout() reads this
      loadReferrals();
    })();
  </script>

  <script>
  // Privacy Settings → Your tools (decisions/0049): activate, pause, and read what each tool means.
  (function () {
    var box = document.getElementById('yt'), csrf = null, VER = null;
    if (!box) return;
    // Verification (decisions/0062 §4): what's checked, each with its state, and the roles that need it
    function verRows() {
      if (!VER) return '';
      var S = { ok: ['\u2713', '#15803D'], todo: ['\u2022', '#B45309'], coming: ['\u2026', '#8A7355'] };
      return '<ul class="mk-s mt-1" style="list-style:none;padding:0;margin:.3rem 0 0">' + VER.checks.map(function (c) { var s = S[c[1]] || S.todo; return '<li><b style="color:' + s[1] + '">' + s[0] + '</b> ' + esc(c[0]) + ': <span style="color:var(--tv-meta,#5C4632)">' + esc(c[2]) + '</span></li>'; }).join('') + '</ul>'
        + '<p class="mk-s mt-1"><b>' + (VER.verified ? 'Your profile shows \u2713 Verified.' : 'The Verified mark shows once your email is confirmed and you\u2019ve confirmed you\u2019re 18 or older.') + '</b></p>';
    }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    var LABEL = { active: ['On', '#15803D'], paused: ['Paused', '#B45309'], not_asked: ['Not switched on', '#8A7355'], update: ['Wording updated: review', '#B45309'] };
    function render(tools) {
      box.innerHTML = tools.map(function (t) {
        // Verification has nothing to switch (Jason, 2026-11-05): confirming your email is the check; this shows where it stands
        if (t.tool === 'verification') return '<div class="mk-r" data-tool="verification"><div class="mk-h"><b class="mk-n" style="cursor:default">Verified</b>'
          + '<span class="mk-pill" style="color:' + (VER && VER.verified ? '#15803D;border-color:#15803D">\u2713 Verified' : '#B45309;border-color:#B45309">Not yet') + '</span></div>'
          + '<p class="mk-s mt-1">Your email confirmed and that you\u2019re 18 or older. That\u2019s the whole check: nothing to switch on.</p>' + verRows() + '</div>';
        var l = LABEL[t.state] || LABEL.not_asked, on = t.state === 'active';
        return '<div class="mk-r" data-tool="' + t.tool + '"><div class="mk-h"><b class="mk-n" style="cursor:default">' + esc(t.name) + '</b>'
          + '<span class="mk-pill" style="color:' + l[1] + ';border-color:' + l[1] + '">' + l[0] + (t.since && t.state !== 'not_asked' ? ' · ' + esc(String(t.since).slice(0, 10)) : '') + '</span>'
          + '<button type="button" class="ab-b' + (on ? '' : ' go') + '" data-set="' + (on ? 0 : 1) + '">' + (on ? 'Switch off' : 'Consent &amp; switch on') + '</button></div>'
          + '<p class="mk-s mt-1">' + esc(t.summary) + '</p>'
          + '<details class="mt-1"><summary class="mk-s" style="cursor:pointer;color:var(--tv-icon,#B45309);font-weight:600">ⓘ What this means</summary>'
          + String(t.explanation).split(/\n\s*\n/).map(function (p) { return '<p class="mk-s mt-1" style="color:var(--tv-meta,#5C4632)">' + esc(p) + '</p>'; }).join('') + '</details>'
          + (t.state === 'paused' ? '<p class="mk-s mt-1">' + esc(t.paused_note) + '</p>' : '') + (t.tool === 'verification' ? verRows() : '') + '</div>';
      }).join('');
    }
    function load() {
      fetch('/user/api/consent.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) { box.textContent = (d.error && d.error.message) || 'Not available yet.'; return; }
        csrf = d.csrf; VER = d.verification || null; render(d.tools);
      }).catch(function () { box.textContent = 'Not available yet.'; });
    }
    box.addEventListener('click', function (e) {
      var b = e.target.closest('[data-set]'); if (!b) return;
      var row = b.closest('[data-tool]'), tool = row.getAttribute('data-tool'), on = b.getAttribute('data-set') === '1';
      var opened = row.querySelector('details') && row.querySelector('details').open;
      if (!on && !TvAsk.gate(b, 'Switch it off? It is paused, not deleted, and you can switch it back on any time.', { yes: 'Switch it off' })) return;
      fetch('/user/api/consent.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' },
        body: JSON.stringify({ tool: tool, on: on, page: 'privacy-settings', full_text_shown: !!opened }) })
        .then(function (r) { return r.json(); }).then(function (d) {
          if (!d.ok) { TvAsk.say((d.error && d.error.message) || 'Could not save.', { anchor: b }); return; }
          VER = d.verification || VER; render(d.tools);
          if (!on && tool === 'ai_learning') { var t = d.tools.filter(function (x) { return x.tool === 'ai_learning'; })[0], r2 = box.querySelector('[data-tool="ai_learning"]'); if (t && t.declined_note) TvAsk.say(t.declined_note, { anchor: r2 || box, bad: false }); }
        });
    });
    load();
  })();

  // App Settings → Marketing (decisions/0047 §3): every linked business, where you stand, and a panel to manage it.
  (function () {
    var box = document.getElementById('mk'), csrf = null, data = null, open = {};
    if (!box) return;
    var OPTS = [['yes:weekly', 'Subscribed · weekly digest'], ['yes:any', 'Subscribed · as it happens'], ['yes:big', 'Subscribed · big offers only'],
                ['no:1m', 'Unsubscribed · may ask again in 1 month'], ['no:3m', 'Unsubscribed · may ask again in 3 months'],
                ['no:6m', 'Unsubscribed · may ask again in 6 months'], ['no:never', 'Unsubscribed · never ask again']];
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    function post(body) {
      return fetch('/user/api/marketing.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || '' }, body: JSON.stringify(body) })
        .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) TvAsk.say((d.error && d.error.message) || 'Could not save.'); return d; });
    }
    // only what works for this listing (decisions/0172 §3.1): Message them when someone manages it; otherwise Leave a message
    // (held for its claim, on its page) and its own Call, Email and Website, each counted for it (never who)
    function acts(b) {
      var A = { message: 'Message them', leave: 'Leave a message', call: 'Call', email: 'Email', website: 'Website' };
      return (b.actions || []).map(function (a) {
        var ext = a.key === 'website', href = a.key === 'message' ? '#addressbook:biz=' + b.entity_id : a.href;
        return '<a style="color:var(--tv-icon,#B45309);font-weight:600" href="' + esc(href) + '" title="' + esc(a.title) + '"' + (a.out ? ' data-out="' + esc(a.out) + '" data-e="' + b.entity_id + '"' : '')
          + (ext ? ' target="_blank" rel="noopener nofollow"' : '') + '>' + esc(A[a.key] || a.label) + '</a> · ';
      }).join('');
    }
    function cur(b) {
      if (b.subscribed) return 'yes:' + b.frequency;
      if (b.never) return 'no:never';
      var left = b.ask_after ? (new Date(b.ask_after.replace(' ', 'T')) - Date.now()) / 2592e6 : 3;   // months until they may ask
      return left > 4.5 ? 'no:6m' : left > 1.5 ? 'no:3m' : 'no:1m';
    }
    function render() {
      var d = data;
      box.innerHTML = '<label class="ab-chk"><input type="checkbox" id="mk-off"' + (d.no_marketing ? ' checked' : '') + '> <b>No marketing from anyone</b> (pauses offers from every business; you stay linked)</label>'
        + (d.businesses.length ? d.businesses.map(function (b) {
            var pill = d.no_marketing ? ['Paused', '#8A7355'] : b.subscribed ? ['Subscribed', '#15803D'] : ['Unsubscribed', '#8A7355'];
            var panel = !open[b.entity_id] ? '' : '<div class="mk-p">'
              + '<label class="mk-l">Offers and news<select class="ab-in" data-k="offers">' + OPTS.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === cur(b) ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>'
              + '<div class="mk-l">Contact details shared with this business'
              + '<div class="mk-f">' + Object.keys(d.fields).map(function (f) { return '<label><input type="checkbox" data-k="share" value="' + f + '"' + (b.shared.indexOf(f) >= 0 ? ' checked' : '') + '> ' + esc(d.fields[f]) + '</label>'; }).join('') + '</div>'
              + '<span class="mk-s">' + (b.shared.length ? 'The business can see these and may email or text you, always with a way to stop. Untick to take back; unlinking takes all of it back.' : 'None: they can reach you only in your Traversence inbox.')
              + ' This is only between you and the business, separate from anything you share with people.' + (b.staffed ? '' : ' No one manages this listing yet, so no one sees it for now.') + '</span>'
              + '</div><span class="mk-s">' + acts(b) + '<a style="color:var(--tv-icon,#B45309);font-weight:600" href="/listing/view.php?id=' + b.entity_id + '">View listing</a></span></div>';
            return '<div class="mk-r" data-e="' + b.entity_id + '"><div class="mk-h"><button type="button" class="mk-n" data-k="open">' + esc(b.name) + '</button>'
              + '<span class="mk-pill" style="color:' + pill[1] + ';border-color:' + pill[1] + '">' + pill[0] + (b.shared.length ? ' · sharing ' + b.shared.length : '') + '</span>'
              + '<button type="button" class="mk-x" data-k="unlink" title="Unlink ' + esc(b.name) + '" aria-label="Unlink ' + esc(b.name) + '">&times;</button></div>' + panel + '</div>';
          }).join('') : '<p class="text-xs text-[color:var(--tv-meta)] mt-2">No linked businesses yet. Tap the chain icon on a listing to link one.</p>');
    }
    function load() {
      fetch('/user/api/marketing.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) { box.textContent = (d.error && d.error.message) || 'Not available yet.'; return; }
        csrf = d.csrf; data = d; render();
      }).catch(function () { box.textContent = 'Not available yet.'; });
    }
    function biz(el) { var r = el.closest('[data-e]'); return r ? +r.getAttribute('data-e') : 0; }
    box.addEventListener('click', function (e) {
      var t = e.target.closest('[data-k]'); if (!t) return;
      var id = biz(t), k = t.getAttribute('data-k');
      if (k === 'open') { open[id] = !open[id]; render(); }
      if (k === 'unlink') {
        var b = data.businesses.filter(function (x) { return x.entity_id === id; })[0];
        if (!TvAsk.gate(t, 'Unlink ' + b.name + '? It leaves your feeds and can no longer message you.' + (b.shared.length ? ' Contact details you shared stay shared until you untick them; do that first if you want them back.' : ''), { yes: 'Unlink', danger: true })) return;
        post({ entity_id: id, unlink: true }).then(load);
      }
    });
    box.addEventListener('change', function (e) {
      if (e.target.id === 'mk-off') { post({ no_marketing: e.target.checked }).then(load); return; }
      var t = e.target, id = biz(t), k = t.getAttribute('data-k'); if (!id) return;
      if (k === 'offers') { var v = t.value.split(':'); post(v[0] === 'yes' ? { entity_id: id, subscribe: true, frequency: v[1] } : { entity_id: id, subscribe: false, ask_again: v[1] }).then(load); }
      if (k === 'share') {
        var f = Array.prototype.map.call(t.closest('.mk-f').querySelectorAll('input:checked'), function (i) { return i.value; });
        post({ entity_id: id, share: f }).then(load);
      }
    });
    load();
  })();
  </script>
  <script src="/js/business-inbox.js?v=<?= (int) @filemtime(__DIR__ . '/../js/business-inbox.js') ?>" defer></script>
  <script src="/js/at-tags.js?v=<?= (int) @filemtime(__DIR__ . '/../js/at-tags.js') ?>" defer></script>
  <script src="/js/address-book.js?v=<?= (int) @filemtime(__DIR__ . '/../js/address-book.js') ?>" defer></script>
  <script src="/js/collection.js?v=<?= (int) @filemtime(__DIR__ . '/../js/collection.js') ?>" defer></script>
  <script src="/js/tv-pulse.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-pulse.js') ?>"></script>
  <script>
  // The dashboard (decisions/0055): sections by #hash in the workspace, the Pulse, the Context Switcher, the team.
  (function () {
    var secs = document.querySelectorAll('[data-sec]'), items = document.querySelectorAll('[data-go]');
    var ALIAS = { feeds: 'pulse', notifications: 'pulse', linked: 'links' };
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    function show(key) {
      key = ALIAS[key] || key;
      if (!document.querySelector('[data-sec="' + key + '"]')) key = 'pulse';
      secs.forEach(function (s) { s.hidden = s.getAttribute('data-sec') !== key; });
      items.forEach(function (a) { var on = a.getAttribute('data-go') === key; a.classList.toggle('on', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
      if (key === 'links') loadLinks();
      if (key === 'team') loadTeam();
      if (key === 'pulse') loadPulse();
    }
    function sec() { return location.hash.slice(1).split(':')[0]; }
    window.addEventListener('hashchange', function () { show(sec()); });
    // the header's bell brings you to the Pulse
    var bell = document.getElementById('tv-bell');
    if (bell) bell.addEventListener('click', function (e) { e.preventDefault(); if (sec() === 'pulse') loadPulse(); else location.hash = '#pulse'; });

    // ---- the Pulse (decisions/0055 §5): js/tv-pulse.js, shared with a business's Overview ----
    function loadPulse() { if (window.TvPulse) TvPulse.load(); }

    // ---- New message, right from the Pulse ----
    var comp = document.getElementById('pu-comp');
    if (comp) (function () {
      var btn = document.getElementById('pu-new'), to = document.getElementById('pu-to'), sug = document.getElementById('pu-sug'), who = document.getElementById('pu-who');
      var body = document.getElementById('pu-body'), msg = document.getElementById('pu-cmsg'), book = null, pcsrf = null, pick = null, seqS = 0;
      function api(q) { return fetch('/user/api/people.php' + q, { credentials: 'include' }).then(function (r) { return r.json(); }); }
      function open(on) {
        comp.hidden = !on; btn.setAttribute('aria-expanded', String(on));
        if (on) { msg.textContent = ''; if (!book) api('?view=book').then(function (d) { book = d.connections || []; pcsrf = d.csrf; suggest(); }); (pick ? body : to).focus(); }
      }
      function choose(p) { pick = p; who.hidden = !p; to.hidden = !!p; who.innerHTML = p ? esc(p.name) + ' <button type="button" aria-label="Choose someone else">&times;</button>' : ''; sug.innerHTML = ''; if (p) body.focus(); else { to.value = ''; to.focus(); suggest(); } }
      function chips(list, note) { sug.innerHTML = list.slice(0, 8).map(function (p) { return '<button type="button" data-p="' + p.id + '" data-n="' + esc(p.name) + '">' + esc(p.name) + (note ? ' <small>' + note + '</small>' : '') + '</button>'; }).join(''); }
      function suggest() {
        if (pick || !book) return;
        var q = to.value.trim().toLowerCase(), mine = book.filter(function (p) { return !q || p.name.toLowerCase().indexOf(q) >= 0; });
        if (mine.length || q.length < 2) { chips(mine, ''); if (!book.length && !q) sug.innerHTML = '<span class="pu-muted">No connections yet: type a name to find someone.</span>'; return; }
        var my = ++seqS;
        api('?view=search&q=' + encodeURIComponent(q)).then(function (d) { if (my === seqS) { var ps = (d.people || []).map(function (p) { return { id: p.id, name: p.name }; }); if (ps.length) chips(ps, 'request'); else sug.innerHTML = '<span class="pu-muted">No one found by that name.</span>'; } });
      }
      btn.addEventListener('click', function () { open(comp.hidden); });
      document.getElementById('pu-cancel').addEventListener('click', function () { open(false); });
      to.addEventListener('input', suggest);
      sug.addEventListener('click', function (e) { var b = e.target.closest('[data-p]'); if (b) choose({ id: +b.getAttribute('data-p'), name: b.getAttribute('data-n') }); });
      who.addEventListener('click', function (e) { if (e.target.closest('button')) choose(null); });
      comp.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!pick) { msg.textContent = 'Choose who it\'s to.'; to.focus(); return; }
        if (!body.value.trim()) { msg.textContent = 'Write a message first.'; body.focus(); return; }
        var send = document.getElementById('pu-send'); send.disabled = true; msg.textContent = 'Sending…';
        fetch('/user/api/people.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': pcsrf || '' },
          body: JSON.stringify({ action: 'send', user_id: pick.id, body: body.value }) })
          .then(function (r) { return r.json(); }).then(function (d) {
            send.disabled = false;
            if (!d.ok) throw new Error((d.error && d.error.message) || 'It couldn\'t be sent.');
            msg.innerHTML = 'Sent to ' + esc(pick.name) + '. <a class="underline" href="#addressbook:messages">Open the conversation</a>';
            body.value = ''; loadPulse();
          }).catch(function (x) { send.disabled = false; msg.textContent = x.message; });
      });
    })();

    // ---- Team & roles (a listing's team, or the staff) ----
    var teamBox = document.getElementById('team-box'), tcsrf = null;
    function loadTeam() {
      fetch('/user/api/context.php?team=1', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) throw new Error(d.error && d.error.message);
        tcsrf = d.csrf;
        var admin = d.side === 'admin';
        var h = '<h2 class="font-serif font-bold text-lg text-[color:var(--tv-ink)]">' + (admin ? 'Staff & roles' : 'Team & roles') + '</h2>'
          + '<p class="text-sm text-[color:var(--tv-meta)] mt-1">' + (admin ? 'Traversence staff and what each can do.' : 'Who helps run this listing, and what each can do.')
          + ' Each role sees only its own scope, and no role can read people\'s private messages or contact cards.</p>';
        h += (d.team || []).map(function (t) {
          return '<div class="tm-r"><span><b>' + esc(t.name) + '</b>' + (t.me ? ' <span class="text-xs text-[color:var(--tv-meta)]">(you)</span>' : '') + (t.scope ? ' <span class="text-xs text-[color:var(--tv-meta)]">' + esc(t.scope) + '</span>' : '') + '</span>'
            + '<span class="ab-acts"><span class="tm-role" title="' + esc((d.what || {})[t.role] || '') + '">' + esc((d.roles || {})[t.role] || t.role) + '</span>'
            + (t.grant_id && (d.can_grant.indexOf(t.role) >= 0 || t.me) ? '<button type="button" class="ab-b no" data-revoke="' + t.grant_id + '">' + (t.me ? 'Step down' : 'Remove') + '</button>' : '') + '</span></div>';
        }).join('') || '<p class="text-sm mt-2">No one yet.</p>';
        if (d.can_grant && d.can_grant.length) {
          if (!d.ready) h += '<p class="text-sm mt-3">To add people, run <code>app/migrations/2026-10-04_role_grants.sql</code> first.</p>';
          else h += '<div class="tm-add"><input class="ab-in" style="flex:1;min-width:12rem" type="email" id="tm-email" placeholder="Their Traversence account email" autocomplete="off">'
            + '<select class="ab-in" style="width:auto" id="tm-role">' + d.can_grant.map(function (r) { return '<option value="' + r + '">' + esc(d.roles[r]) + '</option>'; }).join('') + '</select>'
            + '<button type="button" class="ab-b go" id="tm-add">Add</button></div><p class="pu-muted" id="tm-msg" style="margin-top:.4rem"></p>';
        }
        h += '<details class="mt-3"><summary class="text-sm font-semibold text-amber-800 cursor-pointer">What each role can do</summary>'
          + Object.keys(d.what || {}).map(function (r) { return '<p class="text-sm mt-1"><b>' + esc(d.roles[r]) + ':</b> ' + esc(d.what[r]) + '</p>'; }).join('') + '</details>';
        teamBox.innerHTML = h;
      }).catch(function (e) { teamBox.innerHTML = '<p class="text-sm">' + esc(e.message || 'Not available.') + '</p>'; });
    }
    function teamPost(body) {
      return fetch('/user/api/context.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': tcsrf || '' }, body: JSON.stringify(body) })
        .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.'); return d; });
    }
    teamBox.addEventListener('click', function (e) {
      if (e.target.id === 'tm-add') {
        var m = document.getElementById('tm-msg');
        teamPost({ grant: { email: document.getElementById('tm-email').value, role: document.getElementById('tm-role').value } })
          .then(function (d) { loadTeam(); }).catch(function (x) { m.textContent = x.message; });
      }
      var rv = e.target.closest('[data-revoke]');
      if (rv && TvAsk.gate(rv, 'Remove this role?', { yes: 'Remove', danger: true })) teamPost({ revoke: +rv.getAttribute('data-revoke') }).then(loadTeam).catch(function (x) { TvAsk.say(x.message, { anchor: rv }); });
    });

    // ---- Procedures: today's ticks, in this browser ----
    document.querySelectorAll('[data-proc]').forEach(function (ol) {
      var key = 'tv_proc_' + ol.getAttribute('data-proc') + '_' + new Date().toISOString().slice(0, 10), done = [];
      try { done = JSON.parse(localStorage.getItem(key) || '[]'); } catch (e) {}
      ol.querySelectorAll('[data-step]').forEach(function (c) { c.checked = done.indexOf(+c.getAttribute('data-step')) >= 0; });
      ol.addEventListener('change', function () {
        var d = Array.prototype.map.call(ol.querySelectorAll('[data-step]:checked'), function (c) { return +c.getAttribute('data-step'); });
        try { localStorage.setItem(key, JSON.stringify(d)); } catch (e) {}
      });
    });

    // ---- Linked ----
    function get(q) { return fetch('/user/api/links.php' + q, { credentials: 'include', headers: { Accept: 'application/json' } }).then(function (r) { return r.json(); }); }
    // Linked, as a collection (decisions/0055 §3, §6): search, sort, group by kind, filter, layout, select and act
    var linksBox = document.getElementById('ah-links'), csrf = null, linksCol = null;
    function linkPost(t, id, action) {
      return fetch('/user/api/links.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf || window.appCsrfToken || '' },
        body: JSON.stringify({ type: t, id: id, action: action }) });
    }
    function loadLinks() {
      get('?check=').then(function (d) { csrf = d.csrf; }).catch(function () {});
      get('?list=1').then(function (d) {
        if (!d.ok) throw new Error(d.error && d.error.message);
        var KIND = { person: 'People', business: 'Businesses', place: 'Places', topic: 'Topics' }, list = [];
        Object.keys(d.types).forEach(function (t) {
          (d.links[t] || []).forEach(function (l) {
            var muted = +l.muted === 1;
            list.push({ id: l.target_type + '|' + l.target_id, title: l.label, url: l.url || '', sub: (KIND[t] || d.types[t]) + (muted ? ' · muted' : '') + (l.created_at ? ' · since ' + String(l.created_at).slice(0, 10) : ''),
                        meta: { kind: KIND[t] || d.types[t], state: muted ? 'Muted' : 'In your Pulse', since: l.created_at || '' },
                        actions: [{ key: muted ? 'unmute' : 'mute', label: muted ? 'Unmute' : 'Mute' }, { key: 'unlink', label: 'Unlink', danger: true }] });
          });
        });
        if (!window.TvCollection) { linksBox.textContent = 'Loading…'; setTimeout(loadLinks, 300); return; }
        if (!linksCol) linksCol = TvCollection.mount(linksBox, {
          key: 'linked', items: list, layouts: ['list', 'blocks', 'lines'],
          sorts: [{ key: 'meta.since', label: 'Newest', desc: true }, { key: 'title', label: 'Name' }],
          groups: [{ key: 'meta.kind', label: 'Kind' }, { key: 'meta.state', label: 'Muted or not' }],
          filters: [{ key: 'meta.kind', label: 'Kind' }, { key: 'meta.state', label: 'Showing' }],
          bulk: [{ key: 'mute', label: 'Mute' }, { key: 'unmute', label: 'Unmute' }, { key: 'unlink', label: 'Unlink', danger: true }],
          empty: 'Nothing linked yet. Tap the chain icon on any place, listing or person to link it.',
          onAction: function (action, ids) {
            var go = function () { return Promise.all(ids.map(function (id) { var p = id.split('|'); return linkPost(p[0], p.slice(1).join('|'), action); })).then(loadLinks); };
            if (action === 'unlink' && ids.length > 1) return TvAsk.confirm('Unlink ' + ids.length + '?', { yes: 'Unlink', danger: true }).then(function (ok) { if (ok) return go(); });
            return Promise.all(ids.map(function (id) { var p = id.split('|'); return linkPost(p[0], p.slice(1).join('|'), action); })).then(loadLinks);
          }
        });
        else linksCol.set(list);
      }).catch(function (e) { linksBox.textContent = e.message || 'Linking isn\'t switched on yet.'; });
    }

    show(sec() || 'pulse');   // the Pulse (a member's under their profile: the Dashboard tab); an admin's front page is /admin/
  })();
  </script>
</body>
</html>
