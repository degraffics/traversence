<?php
// experiences/view.php?id= — one experience (decisions/0059): what it is, where, when and how long, how it feels, and
// its connections (the Chameleon Filter): who can take you, the outdoor places it's at, and the journeys of people who
// did it. Published ones for everyone; one waiting for review only for its author and staff.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/experience-ui.php';
require_once __DIR__ . '/../../app/ui/journey-ui.php';
require_once __DIR__ . '/../../app/lib/Journeys.php';

$pdo = Database::connection();
$uid = Auth::currentUserId();
$e = Experiences::ready($pdo) ? Experiences::get($pdo, (int) ($_GET['id'] ?? 0)) : null;
$staff = $uid && $e && Experiences::staffCan($pdo, $uid, 'content');
$own = $uid && $e && (int) $e['author_id'] === $uid && $e['source'] === 'member';
if (!$e || ($e['status'] !== 'published' && !$own && !$staff)) {
    http_response_code(404);
    tv_page_start('Experience not found');
    echo '<div class="text-center py-10"><h1 class="font-serif font-bold text-2xl mb-2">Experience not found</h1><p class="text-sm">It may have been taken down. <a class="underline" href="/discovery/?view=experiences">More experiences</a></p></div>';
    tv_page_end();
    exit;
}
$id = (int) $e['id'];
$links = Experiences::links($pdo, $id);
$cover = Experiences::cover($pdo, $id);
$placeUrl = '';
try { require_once __DIR__ . '/../../app/lib/Links.php'; [, $placeUrl] = Links::resolve($pdo, 'place', (string) $e['place_key']); } catch (Throwable) {}
$biz = [];
if ($links['listing']) {
    $st = $pdo->query("SELECT e.id, e.name, c.name AS cat, (SELECT meta_value FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'city' LIMIT 1) AS city
                         FROM entities e LEFT JOIN categories c ON c.id = e.category_id WHERE e.id IN (" . implode(',', array_map('intval', $links['listing'])) . ") AND e.is_suppressed = 0");
    $biz = $st->fetchAll(PDO::FETCH_ASSOC);
}
$rec = [];
if ($links['rec'] && is_file(__DIR__ . '/../../app/lib/crawler/RecBulk.php')) {
    require_once __DIR__ . '/../../app/lib/crawler/RecBulk.php';
    foreach ($links['rec'] as $r) if ($p = RecBulk::get($pdo, $r)) $rec[] = $p;
}
$jr = [];
foreach ($links['journey'] as $jid) if (($j = Journeys::get($pdo, (int) $jid)) && $j['status'] === 'published') $jr[] = $j;
$v = fn ($x) => is_string($d = json_decode((string) $x, true)) ? $d : (string) $x;

tv_page_start($e['title'], ['no_crumbs' => true, 'description' => mb_strimwidth((string) $e['summary'], 0, 180, '…')]);
if ($e['status'] === 'published') tv_count_item('experience:' . $id);   // the platform's counts
echo tv_journey_css();
?>
<style>
  .xv{max-width:54rem}
  .xv-head{position:relative;border-radius:1.1rem;overflow:hidden;min-height:260px;display:flex;flex-direction:column;justify-content:flex-end;padding:1rem 1.1rem;color:var(--tv-on-umber)}
  .xv-head::before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(30,20,12,.15),rgba(30,20,12,.78))}
  .xv-head>*{position:relative}.xv-head .xv-link{position:absolute;top:.8rem;right:.8rem}
  .xv-kick{font-size:.72rem;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--tv-on-umber);display:flex;align-items:center;gap:.4rem}
  .xv-kick .ta-svg{width:16px;height:16px;color:var(--tv-on-umber)}
  .xv-head h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.6rem,4.4vw,2.4rem);line-height:1.12;margin:.3rem 0 .35rem;text-shadow:0 2px 8px rgba(0,0,0,.5)}
  .xv-in{font-size:.9rem;color:var(--tv-on-umber)}.xv-in a{color:var(--tv-on-umber);text-underline-offset:3px}
  .xv-facts{display:flex;flex-wrap:wrap;gap:.35rem;margin-top:.6rem}.xv-facts span{font-size:.76rem;border-radius:999px;padding:.2rem .6rem;background:rgba(255,251,242,.18);border:1px solid rgba(255,251,242,.4)}
  .xv-facts .on{background:var(--tv-sage);color:var(--tv-umber);border-color:var(--tv-sage);font-weight:700}
  .xv-wait{background:var(--tv-hold-bg);border:1px solid color-mix(in srgb,var(--tv-hold) 35%,var(--tv-canvas));border-radius:.7rem;padding:.6rem .8rem;font-size:.86rem;color:color-mix(in srgb,var(--tv-hold) 75%,var(--tv-ink));margin:.8rem 0}
  .xv-lead{font-size:1.08rem;line-height:1.55;color:var(--tv-ink);margin:1rem 0 .6rem}
  .xv-body{font-size:.95rem;line-height:1.65;color:var(--tv-ink);white-space:pre-line}
  .xv-respect{background:var(--tv-canvas);border-left:4px solid var(--tv-sage);border-radius:.5rem;padding:.6rem .8rem;font-size:.88rem;color:var(--tv-ink);margin:1rem 0}
  .xv h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.2rem;color:var(--tv-ink);margin:1.4rem 0 .5rem}
  .xv-row{display:flex;align-items:center;gap:.6rem;padding:.6rem .75rem;background:var(--tv-card-a);border:1px solid var(--tv-line);border-radius:.7rem;margin-bottom:.4rem;text-decoration:none;color:var(--tv-ink)}
  .xv-row b{display:block}.xv-row small{color:var(--tv-meta)}.xv-row .ta-svg{color:var(--tv-icon,#B45309);flex:0 0 auto}.xv-row:hover{border-color:var(--tv-line-strong)}
  .xv-cta{display:flex;flex-wrap:wrap;gap:.5rem;margin:1.4rem 0 .4rem}
  .xv-cta a{border-radius:999px;padding:.45rem .95rem;font-weight:600;font-size:.88rem;text-decoration:none;border:1px solid var(--tv-line-strong);color:var(--tv-ink);background:var(--tv-card-a)}
  .xv-cta a.go{background:var(--tv-umber);color:var(--tv-on-umber);border-color:var(--tv-umber)}
  .xv-by{font-size:.8rem;color:var(--tv-meta);margin-top:.8rem}
  @media (max-width:767px){.ta-body:has(.xv-head){margin-top:0}.xv-head{margin:-.8rem calc(-1 * var(--tv-pad, .85rem)) 0;border-radius:0;min-height:240px}}
</style>
<article class="xv">
  <header class="xv-head" data-link-host style="<?= $cover !== '' ? "background:url('" . tv_e($cover) . "') center/cover no-repeat" : tv_explore_art((string) $e['title'], true) ?>">
    <?php if ($e['status'] === 'published'): ?><span class="xv-link" data-link="place:exp:<?= $id ?>" data-link-label="<?= tv_e($e['title']) ?>"></span><?php endif; ?>
    <span class="xv-kick"><?= tv_icon(Experiences::TYPE_ICON[$e['type']] ?? 'compass') ?><?= tv_e(Experiences::TYPES[$e['type']] ?? 'Experience') ?></span>
    <h1><?= tv_e($e['title']) ?></h1>
    <span class="xv-in">in <?= $placeUrl !== '' ? '<a href="' . tv_e($placeUrl) . '">' . tv_e($e['place_label']) . '</a>' : tv_e($e['place_label']) ?></span>
    <span class="xv-facts"><?php if (Experiences::inSeason((string) $e['seasons']) && $e['seasons'] !== 'all'): ?><span class="on">In season now</span><?php endif; ?>
      <?php foreach (array_filter(tv_experience_facts($e)) as $f): ?><span><?= tv_e($f) ?></span><?php endforeach; ?></span>
  </header>
  <?php require_once __DIR__ . '/../../app/ui/engage-ui.php';   // views, likes, comments, Share, Report (decisions/0058 §20)
  if ($e['status'] === 'published') echo tv_engage_bar($pdo, 'exp', (string) $id, ['title' => $e['title'], 'report' => $uid && !$own ? 'experience:' . $id : '']); ?>
  <?php if ($e['status'] !== 'published'): ?>
    <p class="xv-wait"><b><?= tv_e(Experiences::STATUSES[$e['status']] ?? $e['status']) ?>.</b> Only you<?= $staff ? ' and staff' : '' ?> can see this until it's approved.<?= $e['review_note'] !== '' ? ' Reviewer\'s note: ' . tv_e($e['review_note']) : '' ?></p>
  <?php endif; ?>
  <?php require_once __DIR__ . '/../../app/lib/GuideLinks.php'; $xvLive = $e['status'] === 'published';   // the names the Chameleon Filter found, highlighted (decisions/0132)
  $xvL = fn (string $sec, string $html) => $xvLive ? GuideLinks::linkify($pdo, 'experience:' . (int) $id, $sec, $html) : $html; ?>
  <p class="xv-lead"><?= $xvL('summary', tv_e($e['summary'])) ?></p>
  <?php if (trim((string) $e['body']) !== ''): ?><div class="xv-body"><?= $xvL('body', tv_e($e['body'])) ?></div><?php endif; ?>
  <?php if ($own && $xvLive) { require_once __DIR__ . '/../../app/ui/tag-chips.php'; echo tv_tag_chips($pdo, 'experience:' . (int) $id); } ?>
  <?php if (trim((string) $e['respect_note']) !== ''): ?><p class="xv-respect"><b>Go with respect.</b> <?= tv_e($e['respect_note']) ?></p><?php endif; ?>

  <?php if ($biz): ?>
  <h2>Who can take you</h2>
  <?php foreach ($biz as $b): ?><a class="xv-row" href="/listing/view.php?id=<?= (int) $b['id'] ?>"><?= tv_icon('store') ?><span><b><?= tv_e($b['name']) ?></b><small><?= tv_e(trim(implode(' · ', array_filter([(string) $b['cat'], ucwords(mb_strtolower($v($b['city'])))])))) ?></small></span></a><?php endforeach; ?>
  <?php endif; ?>
  <?php if ($rec): ?>
  <h2>Where it happens</h2>
  <?php foreach ($rec as $r): ?><a class="xv-row" href="/place/recreation.php?id=<?= rawurlencode((string) $r['ridb_id']) ?>"><?= tv_icon('tree') ?><span><b><?= tv_e(RecBulk::displayName((string) $r['name'])) ?></b><small><?= tv_e(trim(implode(' · ', array_filter([(string) $r['org'], (string) $r['city']])))) ?></small></span></a><?php endforeach; ?>
  <?php endif; ?>
  <?php if ($jr): ?>
  <h2>People who did it</h2>
  <div class="jr-grid"><?php foreach ($jr as $j) { $au = Journeys::author($pdo, $j); echo tv_journey_card(['type' => 'journey', 'id' => (int) $j['id'], 'voice' => $j['voice'], 'title' => (string) $j['title'], 'category' => (string) $j['category'],
        'url' => '/journeys/view.php?id=' . (int) $j['id'], 'image' => (string) (Journeys::media($pdo, (int) $j['id'])[0]['card_path'] ?? ''), 'place' => (string) $j['place_label'],
        'author' => $au['name'], 'author_url' => $au['url'], 'views' => (int) $j['views'], 'likes' => (int) $j['likes'], 'comments' => (int) $j['comments'], 'date' => (string) $j['published_at'], 'minutes' => Journeys::readMinutes((string) $j['body']), 'author_kind' => $au['kind']]); } ?></div>
  <?php endif; ?>

  <?php if ($e['status'] === 'published') echo tv_engage_comments($pdo, 'exp', (string) $id); ?>
  <div class="xv-cta">
    <a class="go" href="/user/journeys/">Done it? Share your journey</a>
    <a href="/user/experiences/">Know another? Post an experience</a>
    <?php if ($own && $e['status'] !== 'published'): ?><a href="/user/experiences/?edit=<?= $id ?>">Edit</a><?php endif; ?>
    <?php if ($staff): ?><a href="/admin/experiences.php?view=<?= tv_e($e['status']) ?>#x<?= $id ?>">Review</a><?php endif; ?>
  </div>
  <p class="xv-by"><?= $e['source'] === 'member' ? 'Posted by ' . tv_e(Experiences::credit($pdo, $e)) : 'From Traversence' ?><?= $e['published_at'] ? ' · ' . tv_e(date('M j, Y', strtotime((string) $e['published_at']))) : '' ?></p>
</article>
<script src="/js/link-button.js" defer></script>
<?php echo '<script src="/js/tv-tagcard.js" defer></script>';   // the preview card of a highlighted name (decisions/0132)
tv_page_end();
