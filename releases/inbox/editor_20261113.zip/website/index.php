<?php
// the sign-in session, like every other page (Jason, 2026-11-05): signed in, the account bar shows here too, with sign-out
require_once __DIR__ . '/../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');   // bootstrap defaults to JSON
require_once __DIR__ . '/../app/ui/security-headers.php';
// The live server is sending `Cache-Control: max-age=7200` (a 2-hour cache)
// on every response, including this page and both API endpoints — that's
// coming from the hosting/server config (likely an .htaccess mod_expires
// rule or a Bluehost caching feature), not from any PHP here, since nothing
// in this project set a Cache-Control header before now. During active
// development that means a browser can keep showing an already-fixed bug
// for up to two hours after the corrected file is uploaded. This explicitly
// overrides it so the page is always served fresh; once the site is done
// changing daily, this can be relaxed back to a real cache duration.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

require_once __DIR__ . '/../app/ui/routes.php';

// ---- Live-route detection: a link appears only once its page is deployed ----
$route_explore   = tv_route(['discovery/index.php' => '/discovery/']);
$route_directory = tv_route(['directory/index.php' => '/directory/']);
$route_claim     = tv_route(['claim.php' => '/claim.php', 'claim/index.php' => '/claim/']);
$route_privacy   = tv_route(['privacy.php' => '/privacy.php']);
$route_terms     = tv_route(['terms.php' => '/terms.php']);

// ---- Stats strip: real public counts, or nothing at all -------------------
// The status whitelist MUST match PUBLIC_STATUSES in api/search_listings.php.
$stats = null;
try {
    require_once __DIR__ . '/../app/lib/Database.php';
    $pdo = Database::connection();
    $row = $pdo->query(
        "SELECT COUNT(*) AS businesses,
                COUNT(DISTINCT LOWER(TRIM(JSON_UNQUOTE(m.meta_value)))) AS cities
           FROM entities e
           LEFT JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'city'
          WHERE e.entity_type = 'merchant'
            AND e.is_suppressed = 0
            AND e.status IN ('unclaimed','claimed-unverified','pending-verification','verified')"
    )->fetch(PDO::FETCH_ASSOC);
    if ($row && (int)$row['businesses'] > 0) {
        $stats = ['businesses' => (int)$row['businesses'], 'cities' => (int)$row['cities']];
    }
} catch (Throwable $e) {
    error_log('index.php stats: ' . $e->getMessage());
}

$site_url = 'https://traversence.com';
?>
<!DOCTYPE html>
<!-- Traversence HOME (/index.php): decisions/0138 -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Traversence — Explore &amp; Get Local</title>
  <meta name="description" content="Traversence connects you to narrative-driven heritage stories and trusted local businesses across the region.">
  <meta property="og:title" content="Traversence — Explore &amp; Get Local">
  <meta property="og:description" content="Discover heritage stories and find trusted local businesses and community services.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?= $site_url ?>/">
  <link rel="canonical" href="<?= $site_url ?>/">
  <script type="application/ld+json">
  <?= json_encode([
    '@context' => 'https://schema.org',
    '@graph' => [
      ['@type' => 'WebSite', 'name' => 'Traversence', 'url' => $site_url . '/',
       'description' => 'The Immersion and Connection Engine: heritage stories and trusted local businesses.'],
      ['@type' => 'Organization', 'name' => 'Traversence', 'url' => $site_url . '/',
       'logo' => $site_url . '/image/Logo-Gtext.png'],
    ],
  ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>
  </script>
  <link rel="icon" type="image/png" href="image/favicon.png">
  <!-- Paints the page's true background before Tailwind's CDN script finishes
       compiling utility classes, so there's no flash/mismatch on first paint
       (Seamless Visual Consistency). #EFE3C8 is the site's light tan body tone. -->
  <style>
    html, body { background-color: #EFE3C8; }
  </style>
  <script src="https://cdn.tailwindcss.com"></script>
  <meta name="tv-sec" content="home"><!-- the platform's counts (decisions/0058 §13) -->
</head>
<body class="bg-[#EFE3C8] text-[#3E2B1F] min-h-screen flex flex-col font-sans">

<a href="#home-landing" class="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-[#F7EFDC] focus:text-[#3E2B1F] focus:px-3 focus:py-2 focus:rounded">Skip to content</a>

<?php try { require_once __DIR__ . '/../app/ui/context-switcher.php'; echo tv_acting_bar(); } catch (Throwable $e) { error_log('acting bar: ' . $e->getMessage()); }   // who you are, above the header, as on every page ?>
<div id="top-bar" class="bg-[#3E2B1F] border-b border-[#2A1B12] sticky top-0 z-40 shadow-lg">
  <div class="px-3 sm:px-6 py-1 flex items-center justify-between">
    <?php require_once __DIR__ . '/../app/ui/brand.php'; ?>
    <?php require_once __DIR__ . '/../app/ui/header.php'; ?>
  </div>
</div>

<?php
// ---- The home page (decisions/0138) ----------------------------------------
// The hero (the one search, where to look), four doors to the main sections, groups on Connect, what's coming up, and
// a five-tab ribbon (Events, Deals, Gallery, Journey, Business) over a feed of what's newest. Everything shown is real;
// where a section is empty it invites instead (§5). Events with fewer than three real ones are topped up with cards
// marked Sample (§5). Nothing here ranks by pay or engagement: newest first (0007, 0031).
$esc = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
$hm_what = [   // one line for each door
  'explore' => 'Places, trails, history and the stories behind them.',
  'local'   => 'Local businesses, services and the people who run them.',
  'social'  => 'Groups around a place, a pastime or a cause.',
  'market'  => 'Buy, sell or give away, straight from your neighbors.',
];
$hm_tone = ['explore' => '#7B3A10', 'local' => '#92400E', 'social' => '#3F6B58', 'market' => '#5C3A1E'];
$hm_doors = [];
foreach (($tv_funnels ?? []) as $f) { if (isset($hm_what[$f[0]])) $hm_doors[] = ['key' => $f[0], 'label' => $f[1], 'url' => $f[2], 'icon' => $tv_i[$f[3]] ?? '']; }

// What's real, read once; any part that isn't ready shows its invitation instead.
$hm_groups = []; $hm_events = []; $hm_feed = [];
$hm_pdo = $pdo ?? null;
if (!$hm_pdo) { try { require_once __DIR__ . '/../app/lib/Database.php'; $hm_pdo = Database::connection(); } catch (Throwable $e) { $hm_pdo = null; } }
if ($hm_pdo) {
  try { require_once __DIR__ . '/../app/lib/Community.php'; if (Community::ready($hm_pdo)) $hm_groups = Community::directory($hm_pdo, '', 3); } catch (Throwable $e) { error_log('home groups: ' . $e->getMessage()); }
  try {
    require_once __DIR__ . '/../app/lib/LiveEvents.php';
    if (LiveEvents::ready($hm_pdo)) {
      $hm_events = $hm_pdo->query("SELECT * FROM live_events WHERE status = 'live' AND COALESCE(ends_on, starts_on) >= CURDATE() ORDER BY starts_on, id LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
      foreach ($hm_events as $ev) $hm_feed[] = ['kind' => 'events', 'name' => (string) $ev['title'], 'url' => (string) $ev['source_url'], 'out' => true, 'img' => '', 'place' => (string) ($ev['place_key'] ?? ''), 'ref' => 'event:' . (int) $ev['id'],
        'where' => (string) ($ev['venue_name'] ?? ''), 'meta' => LiveEvents::when($ev), 'date' => (string) $ev['starts_on']];
    }
  } catch (Throwable $e) { error_log('home events: ' . $e->getMessage()); }
  try {
    require_once __DIR__ . '/../app/lib/Journeys.php';
    foreach (Journeys::feed($hm_pdo, '', 6) as $j) $hm_feed[] = ['kind' => 'journey', 'name' => $j['title'], 'url' => $j['url'], 'out' => false, 'img' => $j['image'],
      'where' => $j['place'], 'meta' => ($j['type'] === 'guide' ? 'Guide' : $j['category']) . ' · ' . $j['author'] . ' · ' . $j['minutes'] . ' min read', 'date' => $j['date'], 'peek' => true];
  } catch (Throwable $e) { error_log('home journeys: ' . $e->getMessage()); }
  try {
    require_once __DIR__ . '/../app/lib/Gallery.php';
    Gallery::ensure($hm_pdo);
    foreach ($hm_pdo->query("SELECT * FROM gallery_albums WHERE visibility = 'public' ORDER BY COALESCE(updated_at, created_at) DESC, id DESC LIMIT 12")->fetchAll(PDO::FETCH_ASSOC) as $a) {
      $c = Gallery::cover($hm_pdo, $a); if (!$c) continue;   // an empty album isn't shown
      $hm_feed[] = ['kind' => 'gallery', 'name' => (string) $a['title'], 'url' => '/gallery/album.php?a=' . (int) $a['id'], 'out' => false, 'img' => (string) $c['card'],
        'where' => Gallery::ownerName($hm_pdo, (string) $a['owner_kind'], (string) $a['owner_ref']), 'meta' => 'Photos', 'date' => (string) ($a['updated_at'] ?: $a['created_at'])];
      if (count(array_filter($hm_feed, fn ($x) => $x['kind'] === 'gallery')) >= 6) break;
    }
  } catch (Throwable $e) { error_log('home gallery: ' . $e->getMessage()); }
  try {   // businesses: newest claimed or verified first (an owner has put them right)
    $st = $hm_pdo->query("SELECT e.id, e.name, e.status, e.updated_at, e.created_at, e.micro_cluster_id,
                                 (SELECT JSON_UNQUOTE(m.meta_value) FROM entity_metadata m WHERE m.entity_id = e.id AND m.meta_key = 'city' LIMIT 1) AS city
                            FROM entities e WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ('claimed-unverified','verified')
                           ORDER BY e.id DESC LIMIT 6");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $b) $hm_feed[] = ['kind' => 'business', 'name' => (string) $b['name'], 'url' => '/listing/view.php?id=' . (int) $b['id'], 'out' => false, 'img' => '',
      'where' => (string) $b['city'], 'meta' => $b['status'] === 'verified' ? 'Verified by its owner' : 'Run by its owner', 'date' => (string) ($b['updated_at'] ?: $b['created_at']),
      'place' => $b['micro_cluster_id'] ? 'cluster:' . (int) $b['micro_cluster_id'] : '', 'ref' => 'listing:' . (int) $b['id']];
  } catch (Throwable $e) { error_log('home businesses: ' . $e->getMessage()); }
}
usort($hm_feed, fn ($a, $b) => strcmp((string) $b['date'], (string) $a['date']));
$hm_tabs = [   // the five tabs (0138 §4): label, See all, the invitation when there's nothing yet
  'events'   => ['Events', null, 'No events listed near here yet.', ['How events get here', '/faq.php#where-do-the-events-under-coming-up-come-from']],
  'deals'    => ['Deals', '/directory/', 'No deals yet. Businesses will be able to post offers here soon.', ['Add your business', '/claim.php']],
  'gallery'  => ['Gallery', null, 'No public photo albums yet.', ['Share your photos', '/gallery/']],
  'journey'  => ['Journey', '/discovery/?view=stories', 'No journeys yet. Be the first to write one.', ['Write a journey', '/journeys/']],
  'business' => ['Business', '/directory/', 'No businesses run by their owners here yet.', ['Claim or add your business', '/claim.php']],
];
$hm_n = []; foreach ($hm_tabs as $k => $_) $hm_n[$k] = count(array_filter($hm_feed, fn ($x) => $x['kind'] === $k));
$hm_shown = array_map(fn ($g) => (string) ($g['topic'] ?? ''), $hm_groups);
$hm_anchors = array_values(array_filter([   // groups a place usually needs, suggested where none is shown yet (0137, 0138 §5)
  ['town' => true, 'label' => 'Local group', 'name' => 'neighbors', 'about' => 'News, help and get-togethers for the people who live here.', 'url' => '/community/#cg-new', 'topic' => ''],
  ['town' => false, 'label' => 'Outdoors & recreation', 'name' => 'Trails, lakes and the outdoors', 'about' => 'Hikes, fishing, camping and the places to go.', 'url' => '/community/?topic=outdoors#cg-new', 'topic' => 'outdoors'],
  ['town' => false, 'label' => 'History & culture', 'name' => 'Local history and heritage', 'about' => 'Old buildings, family stories and the archives behind them.', 'url' => '/community/?topic=history#cg-new', 'topic' => 'history'],
  ['town' => false, 'label' => 'Family & parenting', 'name' => 'Families and parents', 'about' => 'Playdates, schools, activities and swapping what the kids outgrow.', 'url' => '/community/?topic=family#cg-new', 'topic' => 'family'],
  ['town' => false, 'label' => 'Volunteering & causes', 'name' => 'Volunteers and causes', 'about' => 'Clean-ups, food drives and the groups that need a hand.', 'url' => '/community/?topic=causes#cg-new', 'topic' => 'causes'],
  ['town' => false, 'label' => 'Business & careers', 'name' => 'Local business owners', 'about' => 'Owners and makers sharing what works, and helping each other out.', 'url' => '/community/?topic=business#cg-new', 'topic' => 'business'],
], fn ($a) => $a['topic'] === '' || !in_array($a['topic'], $hm_shown, true)));
$hm_samples = [   // shown only to make up three event cards, each marked Sample (§5)
  ['A Saturday market', 'Farm stands, crafts and food trucks on the square.', 'Saturday mornings'],
  ['Live music night', 'Local players at a downtown venue.', 'Friday evenings'],
  ['A guided history walk', 'An hour around the old town with a local guide.', 'Sunday afternoons'],
];
// Stock photos (decisions/0143) where nothing has one of its own: the doors, events' backdrops, and cards with no photo
// (events, businesses). Always labelled; a real photo takes over by itself, since stock is only looked up where 'img' is ''.
$hm_stock = ['doors' => [], 'events' => [], 'samples' => []];
if ($hm_pdo) {
  try {
    require_once __DIR__ . '/../app/lib/StockLibrary.php';
    require_once __DIR__ . '/../app/ui/stock-ui.php';
    if (StockLibrary::ready($hm_pdo)) {
      foreach ($hm_doors as $d) if (isset(StockLibrary::DOORS[$d['key']])) $hm_stock['doors'][$d['key']] = StockLibrary::forSlot($hm_pdo, 'home_door', $d['key'], StockLibrary::DOORS[$d['key']][1]);
      foreach (array_slice($hm_events, 0, 3) as $ev) $hm_stock['events'][(int) $ev['id']] = StockLibrary::forSlot($hm_pdo, 'event_backdrop', 'event:' . (int) $ev['id'], 'event festival ' . $ev['title'], (string) ($ev['place_key'] ?? ''), ['representative' => true, 'fallback' => 'event']);
      foreach ($hm_samples as $i => $sm) $hm_stock['samples'][$i] = StockLibrary::pick($hm_pdo, $sm[0], '', ['representative' => true, 'seed' => 'sample:' . $i, 'fallback' => 'event']);
      foreach ($hm_feed as $i => $it) if ($it['img'] === '' && in_array($it['kind'], ['events', 'business'], true))
        $hm_feed[$i]['stock'] = StockLibrary::forSlot($hm_pdo, $it['kind'] === 'events' ? 'event_backdrop' : 'card', (string) ($it['ref'] ?? ''), $it['kind'] === 'events' ? 'event festival ' . $it['name'] : 'main street shop ' . $it['name'], (string) ($it['place'] ?? ''), ['representative' => true, 'fallback' => $it['kind'] === 'events' ? 'event' : 'main street']);
    }
  } catch (Throwable $e) { error_log('home stock: ' . $e->getMessage()); }
}
$hm_icon = [
  'events' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>',
  'deals' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><circle cx="7" cy="7" r="1.2"/></svg>',
  'gallery' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 17l-5-5-9 8"/></svg>',
  'journey' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/></svg>',
  'business' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9l1.5-5h15L21 9M4 9v11h16V9M3 9h18M9 20v-6h6v6"/></svg>',
  'peek' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  'users' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6"/></svg>',
];
?>
<style>
  #home-landing [hidden]{display:none!important}
  .hm-band{background:#3E2B1F;background-image:radial-gradient(rgba(224,198,142,.16) 1px,transparent 1px);background-size:16px 16px;color:#F7EFDC;border-bottom:1px solid #2A1B12}
  .hm-hero{max-width:1072px;margin:0 auto;text-align:center;padding:2.2rem 1rem 2.4rem}
  .hm-hero h1{font-family:Georgia,'Times New Roman',serif;font-weight:700;color:#F7EFDC;font-size:2rem;line-height:1.15;margin:0 0 .7rem;letter-spacing:-.01em}
  .hm-hero h1 i{font-weight:400;color:#E0C68E}
  .hm-hero h1 u{text-decoration:underline;text-decoration-color:#B45309;text-decoration-thickness:4px;text-underline-offset:7px}
  .hm-hero p.hm-sub{color:#E8DCC2;font-size:1rem;margin:0 auto 1.4rem;max-width:38rem;line-height:1.5}
  .hm-split{position:relative;max-width:1040px;margin:0 auto;display:flex;gap:.35rem;background:#FFFBF2;border-radius:.9rem;padding:.35rem;box-shadow:0 10px 30px rgba(0,0,0,.35)}
  .hm-split .f{flex:1;min-width:0;display:flex;align-items:center;gap:.5rem;background:#F7EFDC;border:1px solid #E5D7B6;border-radius:.65rem;padding:0 .7rem}
  .hm-split .ic{display:flex;color:#B45309}.hm-split .ic svg{width:18px;height:18px}
  .hm-split input.tvs-in{display:block!important;flex:1;min-width:0;border:0;background:transparent;padding:.85rem 0;font-size:1rem;font-weight:600;color:#3E2B1F;outline:none}
  .hm-split input.tvs-in::placeholder{text-transform:uppercase;letter-spacing:.06em;font-weight:700;font-size:.92rem;color:#7B6650}
  .hm-split .fw{flex:1.25}
  .hm-split .wh{flex:1;min-width:0;border:0;background:none;text-align:left;padding:.85rem 0;cursor:pointer;font-size:.92rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#7B6650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .hm-split .wh.set{text-transform:none;letter-spacing:0;font-size:1rem;font-weight:600;color:#3E2B1F}
  .hm-split .f:focus-within{border-color:#B45309;background:#FFFBF2}
  .hm-split .cx{border:0;background:none;color:#8A7355;cursor:pointer;display:flex;padding:.3rem}.hm-split .cx svg{width:17px;height:17px}.hm-split .cx:hover{color:#B45309}
  .hm-split .go{border:0;border-radius:.65rem;background:#92400E;color:#FFFBF2;padding:0 1.4rem;cursor:pointer;display:flex!important;align-items:center;justify-content:center;width:auto;height:auto;min-width:3.6rem}.hm-split .go svg{display:block!important;width:20px!important;height:20px!important;color:#FFFBF2}.hm-split .go:hover{background:#B45309}
  .hm-cx{background:#F7EFDC;border:1px solid #D9C9A3;border-radius:1rem;padding:1.3rem}
  .hm-cxhd{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:.8rem;border-bottom:1px solid #D9C9A3;padding-bottom:.9rem;margin-bottom:1rem}
  .hm-cxhd small{display:block;font-size:.7rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:#B45309}
  .hm-cxhd h2{margin:.15rem 0 0;font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.5rem;color:#3E2B1F}
  .hm-cxall{background:#92400E;color:#FFFBF2;font-weight:700;font-size:.82rem;letter-spacing:.06em;text-transform:uppercase;border-radius:.6rem;padding:.6rem 1rem;text-decoration:none}
  .hm-cxall:hover{background:#B45309}
  .hm-gc{background:#FFFBF2;border:1px solid #E5D7B6;border-radius:.8rem;padding:1rem;display:flex;flex-direction:column;gap:.45rem}
  .hm-gc:hover{border-color:#B45309}
  .hm-gc .tp{display:flex;justify-content:space-between;align-items:center;gap:.5rem}
  .hm-gc .pl{font-size:.66rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#B45309}
  .hm-gc .bd{font-size:.66rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;background:#8FBCA8;color:#1F3B30;border-radius:.35rem;padding:.15rem .45rem;white-space:nowrap}
  .hm-gc.need{border-style:dashed}.hm-gc.need .bd{background:#EFE3C8;color:#8A7355}
  .hm-gc .nm{font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.05rem;color:#92400E}
  .hm-gc a.nm{text-decoration:underline;text-underline-offset:3px}
  .hm-gc .need .nm,.hm-gc.need .nm{color:#3E2B1F}
  .hm-gc p{margin:0;font-size:.87rem;color:#5C4632;line-height:1.4}
  .hm-gc .ft{margin-top:auto;padding-top:.6rem;border-top:1px solid #EFE3C8;display:flex;justify-content:space-between;align-items:center;gap:.5rem;font-size:.8rem;color:#8A7355}
  .hm-gc .ft span{display:flex;align-items:center;gap:.35rem}.hm-gc .ft svg{width:15px;height:15px;color:#B45309}
  .hm-gc .ft a{color:#92400E;font-weight:700;text-decoration:underline}
  .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
  .hm-first{margin:1rem auto 0;font-size:.85rem;color:#C9B897}
  .hm-first a{color:#E8DCC2;text-decoration:underline}.hm-first a:hover{color:#FFFBF2}
  .hm{max-width:72rem;margin:0 auto;padding:1.8rem 1rem 2.5rem}
  .hm-sec{margin-top:2.4rem}.hm-sec:first-child{margin-top:0}
  .hm-hd{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:.5rem 1rem;border-bottom:1px solid #D9C9A3;padding-bottom:.55rem;margin-bottom:1rem}
  .hm-hd small{display:block;font-size:.7rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:#B45309}
  .hm-hd h2{margin:.1rem 0 0;font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.5rem;color:#3E2B1F}
  .hm-hd a.all{color:#92400E;font-weight:600;font-size:.9rem;text-decoration:underline}
  .hm-doors{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}
  .hm-door{position:relative;display:flex;flex-direction:column;justify-content:flex-end;min-height:12.5rem;border-radius:1rem;overflow:hidden;color:#FFFBF2;padding:1rem;box-shadow:0 6px 18px rgba(62,43,31,.18);transition:transform .25s}
  .hm-door:hover{transform:translateY(-3px)}
  .hm-door::before{content:"";position:absolute;inset:0;background-image:radial-gradient(rgba(255,251,242,.13) 1px,transparent 1px);background-size:14px 14px}
  .hm-door::after{content:"";position:absolute;inset:0;background:linear-gradient(to top,rgba(30,19,12,.75),rgba(30,19,12,.05) 70%)}
  .hm-door>*{position:relative;z-index:1}
  .hm-door .big{position:absolute;right:-.6rem;top:-.6rem;width:8.5rem;height:8.5rem;opacity:.18;z-index:0}.hm-door .big svg{width:100%;height:100%}
  .hm-door .ic{width:42px;height:42px;border-radius:999px;background:#FFFBF2;color:#B45309;display:flex;align-items:center;justify-content:center;margin-bottom:.6rem;box-shadow:0 0 0 2px rgba(255,251,242,.4)}
  .hm-door .ic svg{width:22px;height:22px}
  .hm-door a.nm{font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.25rem;color:#FFFBF2;text-decoration:underline;text-underline-offset:4px;text-decoration-color:rgba(255,251,242,.5)}
  .hm-door a.nm::after{content:"";position:absolute;inset:-100vh}   /* the whole card opens the section */
  .hm-door p{margin:.3rem 0 0;font-size:.88rem;line-height:1.35;color:#F3E9D4}
  .hm-door .soon{font-size:.8rem;color:#E0C68E}
  .hm-panel{background:#F7EFDC;border:1px solid #D9C9A3;border-radius:1rem;padding:1.1rem}
  .hm-grid3{display:grid;grid-template-columns:minmax(0,1fr);gap:.8rem}
  .hm-card{background:#FFFBF2;border:1px solid #E5D7B6;border-radius:.8rem;padding:.9rem;display:flex;flex-direction:column;gap:.35rem;position:relative}
  .hm-card .k{font-size:.68rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#B45309}
  .hm-card a.nm{font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.05rem;color:#92400E;text-decoration:underline;text-underline-offset:3px;padding-right:2.4rem}
  .hm-card p{margin:0;font-size:.87rem;color:#5C4632;line-height:1.4}
  .hm-card .ft{margin-top:auto;padding-top:.5rem;border-top:1px solid #EFE3C8;display:flex;justify-content:space-between;align-items:center;font-size:.82rem;color:#8A7355;gap:.5rem}
  .hm-card .ft a{color:#92400E;font-weight:600;text-decoration:underline}
  .hm-card.inv{border-style:dashed;background:transparent;justify-content:center;text-align:center;align-items:center}
  .hm-card.inv a.go{display:inline-block;margin-top:.3rem;background:#92400E;color:#FFFBF2;border-radius:.6rem;padding:.5rem .9rem;font-weight:600;text-decoration:none}
  .hm-sample{position:absolute;top:.6rem;right:.6rem;font-size:.66rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;background:#EFE3C8;color:#8A7355;border-radius:999px;padding:.15rem .55rem}
  .hm-dis{background:#E8DCC2;color:#8A7355;border-radius:.55rem;padding:.35rem .7rem;font-weight:600;font-size:.8rem;cursor:not-allowed;border:0}
  .hm-ev .when{font-weight:600;color:#3E2B1F;font-size:.85rem}
  .hm-tabs{display:flex;gap:.4rem;overflow-x:auto;scrollbar-width:none;background:#F7EFDC;border:1px solid #D9C9A3;border-radius:.9rem;padding:.35rem;margin-bottom:1rem}
  .hm-tabs::-webkit-scrollbar{display:none}
  .hm-tab{flex:1 0 auto;display:flex;align-items:center;justify-content:center;gap:.4rem;border:0;background:none;border-radius:.65rem;padding:.6rem .9rem;font-weight:700;font-size:.9rem;color:#5C4632;cursor:pointer;white-space:nowrap}
  .hm-tab svg{width:18px;height:18px;color:#B45309}
  .hm-tab:hover{background:#EFE3C8}
  .hm-tab[aria-pressed="true"]{background:#8FBCA8;color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .hm-tab[aria-pressed="true"] svg{color:#1F3B30}
  .hm-tab .n{font-weight:600;font-size:.75rem;color:#8A7355}
  .hm-feed{display:grid;grid-template-columns:minmax(0,1fr);gap:.9rem}
  .hm-item{background:#FFFBF2;border:1px solid #E5D7B6;border-radius:.9rem;overflow:hidden;display:flex;flex-direction:column}
  .hm-item .im{height:9.5rem;background:#E3D3AC;background-image:radial-gradient(rgba(146,64,14,.16) 1px,transparent 1px);background-size:14px 14px;display:flex;align-items:center;justify-content:center;color:#B45309}
  .hm-item .im svg{width:42px;height:42px;opacity:.55}
  .hm-item .im img{width:100%;height:100%;object-fit:cover;display:block}
  .hm-item .im{position:relative}
  .hm-door.hm-stk{background-size:cover;background-position:center}.hm-door.hm-stk::before{display:none}
  .hm-door .tv-stk{position:absolute;z-index:4}
  .hm-evim{position:relative;height:7.5rem;margin:-.9rem -.9rem .4rem;border-radius:.8rem .8rem 0 0;background:#E3D3AC center/cover no-repeat}
  @media (max-width:767px){.hm-evim{border-radius:.5rem .5rem 0 0}}
  .hm-item .bd{padding:.8rem .9rem;display:flex;flex-direction:column;gap:.3rem;position:relative;flex:1}
  .hm-item .k{font-size:.66rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#B45309}
  .hm-item a.nm{font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.05rem;color:#92400E;text-decoration:underline;text-underline-offset:3px;padding-right:2.4rem;line-height:1.3}
  .hm-item .pl{font-size:.82rem;color:#5C4632}.hm-item .mt{font-size:.8rem;color:#8A7355}
  .hm-act{position:absolute;top:.7rem;right:.7rem;width:30px;height:30px;border-radius:999px;border:1.5px solid #CBB98D;background:#FFFBF2;color:#B45309;display:flex;align-items:center;justify-content:center}
  .hm-act svg{width:16px;height:16px}
  .hm-empty{grid-column:1/-1}
  .hm-more{grid-column:1/-1;text-align:center;font-size:.9rem}.hm-more a{color:#92400E;font-weight:600;text-decoration:underline}
  .hm-go{margin:2.4rem auto 0;max-width:34rem;background:#F7EFDC;border:1px solid #D9C9A3;border-radius:1rem;padding:.9rem 1rem}
  .hm-go label{display:block;font-weight:700;color:#3E2B1F;font-size:.98rem;margin-bottom:.4rem}
  .hm-go form{display:flex;gap:.5rem}
  .hm-go input{flex:1;min-width:0;border:1px solid #CBB98D;border-radius:.6rem;background:#FFFBF2;padding:.6rem .7rem;font-size:.95rem;color:#3E2B1F}
  .hm-go button{border:0;border-radius:.6rem;background:#92400E;color:#FFFBF2;font-weight:700;padding:.6rem 1.1rem;cursor:pointer}
  .hm-go small{display:block;color:#8A7355;margin-top:.35rem}
  .hm-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem;margin-top:1.4rem;text-align:center}
  .hm-stats div{background:#F7EFDC;border:1px solid #D9C9A3;border-radius:1rem;padding:.7rem}
  .hm-stats dt{font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:#8A7355}
  .hm-stats dd{margin:0;font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.7rem;color:#3E2B1F}
  @media (min-width:768px){
    .hm-split{z-index:1372}   /* above the search's dimming, as the header's bar is: the results hang from this box */
    .hm-hero{padding:3rem 1rem 3.2rem}.hm-hero h1{font-size:3.1rem}
    .hm-doors{grid-template-columns:repeat(4,minmax(0,1fr))}
    .hm-grid3{grid-template-columns:repeat(3,minmax(0,1fr))}
    .hm-feed{grid-template-columns:repeat(2,minmax(0,1fr))}
  }
  @media (min-width:1024px){.hm-feed{grid-template-columns:repeat(3,minmax(0,1fr))}}
  /* phones: edge to edge, 3px from the sides and each other (decisions/0058 §11) */
  @media (max-width:767px){
    .hm{padding:1.2rem 3px 1.5rem}
    .hm-hd{padding-left:10px;padding-right:10px}
    .hm-doors,.hm-grid3,.hm-feed,.hm-stats{gap:3px}
    .hm-door,.hm-panel,.hm-card,.hm-item,.hm-go,.hm-stats div,.hm-tabs{border-radius:.5rem}
    .hm-door{min-height:10rem}
    .hm-panel{padding:3px;border:0;background:none}
    .hm-split{flex-direction:column;padding:.3rem}
    .hm-split .go{justify-content:center;padding:.8rem}
    .hm-cx{padding:3px;border:0;background:none}.hm-cxhd{padding:0 10px .8rem}.hm-gc{border-radius:.5rem}
    .hm-go{margin-left:0;margin-right:0}
  }
</style>
<main id="home-landing" class="flex-1">

  <section class="hm-band" aria-labelledby="hm-h">
    <div class="hm-hero">
      <h1 id="hm-h">The <i>Immersion</i> &amp; <u>Connection</u> Engine</h1>
      <p class="hm-sub">The stories of a place, the businesses that make it run, the groups that bring it together and the Marketplace between neighbors.</p>
      <?php /* The split box IS the site's search on this page (id tv-search: js/search-panel.js binds to it), so its results
         hang right under it as you type, the words staying in view. Where opens the place picker; the target auto-detects. */ ?>
      <div id="tv-search" class="hm-split" role="search">
        <label class="f fw"><span class="ic" aria-hidden="true"><?= $tv_i['explore'] ?? '' ?></span><input id="hm-what" class="tvs-in" type="search" autocomplete="off" placeholder="Discover more" aria-label="What are you looking for?"></label>
        <div class="f fl"><span class="ic" aria-hidden="true"><?= $tv_i['local'] ?? '' ?></span><button type="button" id="hm-where" class="wh" data-tv-click="tvSearchWhere" aria-label="Where: choose a place" aria-haspopup="dialog"><span id="hm-where-t">Let's get local</span></button><button type="button" class="cx" data-tv-click="autoDetectLocation:event" title="Use my location" aria-label="Use my location"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg></button></div>
        <button type="button" class="go tvs-sbtn" aria-label="Search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.8-4.8"/></svg></button>
      </div>
      <p class="hm-first">First-time visitors: Click here to learn more about our <a href="/faq.php#exploring-places">discovery portal</a>, <a href="/faq.php#the-directory-get-local">local directory</a>, <a href="/faq.php#community-groups">community hub</a>, and <a href="/faq.php#buying-and-selling-the-marketplace">marketplace</a>.</p>
    </div>
  </section>

  <div class="hm">

    <section class="hm-sec" aria-labelledby="hm-doors-h">
      <h2 id="hm-doors-h" class="sr-only">The four sections</h2>
      <nav class="hm-doors" aria-label="The site's sections">
        <?php foreach ($hm_doors as $d): ?>
          <?php $ds = $hm_stock['doors'][$d['key']] ?? null; ?>
          <article class="hm-door<?= $ds ? ' hm-stk' : '' ?>" style="background-color:<?= $esc($hm_tone[$d['key']]) ?><?= $ds ? ";background-image:url('" . $esc($ds['card']) . "')" : '' ?>">
            <?= $ds ? tv_stock_tag($ds, ['at' => 'tl']) : '' ?>
            <span class="big" aria-hidden="true"><?= $d['icon'] ?></span>
            <span class="ic" aria-hidden="true"><?= $d['icon'] /* the brand's own icon, from header.php */ ?></span>
            <?php if ($d['url']): ?>
              <a class="nm" href="<?= $esc($d['url']) ?>"><?= $esc($d['label']) ?></a>
            <?php else: ?>
              <span class="nm"><?= $esc($d['label']) ?></span> <span class="soon">Coming soon</span>
            <?php endif; ?>
            <p><?= $esc($hm_what[$d['key']]) ?></p>
          </article>
        <?php endforeach; ?>
      </nav>
    </section>

    <?php // the home page's first editable zone (decisions/0159 step 3): empty until something is published there; staff with
          // pages.edit see it outlined, with Edit (app/lib/Blocks.php)
          try { require_once __DIR__ . '/../app/lib/Blocks.php'; echo Blocks::zone($pdo ?? Database::connection(), 'home.after-doors', '', 'Home page, under the four doors'); }
          catch (Throwable $e) { error_log('home zone: ' . $e->getMessage()); } ?>

    <section class="hm-sec hm-cx" aria-labelledby="hm-groups-h">
      <div class="hm-cxhd">
        <div><small>Traversence Connect</small><h2 id="hm-groups-h">Community Groups</h2></div>
        <a class="hm-cxall" href="/community/">Explore all groups</a>
      </div>
      <div class="hm-grid3">
        <?php foreach ($hm_groups as $g): $gu = '/community/group.php?id=' . (int) $g['id']; ?>
          <article class="hm-gc">
            <div class="tp"><span class="pl"><?= $esc($g['topic_label'] ?: ($g['local'] ? 'Local group' : 'Group')) ?></span><span class="bd"><?= $g['join_mode'] === 'approval' ? 'Ask to join' : 'Open' ?></span></div>
            <a class="nm" href="<?= $esc($gu) ?>"><?= $esc($g['name']) ?></a>
            <p><?= $esc($g['about']) ?></p>
            <div class="ft"><span><?= $hm_icon['users'] ?><?= (int) $g['members'] ?> member<?= (int) $g['members'] === 1 ? '' : 's' ?></span><a href="<?= $esc($gu) ?>">Join group</a></div>
          </article>
        <?php endforeach; ?>
        <?php foreach (array_slice($hm_anchors, 0, max(0, 6 - count($hm_groups))) as $an): ?>
          <article class="hm-gc need">
            <div class="tp"><span class="pl"><?= $esc($an['label']) ?></span><span class="bd">Needs a group</span></div>
            <span class="nm"><?= $an['town'] ? '<span data-hm-place>Your town</span> ' . $esc($an['name']) : $esc($an['name']) ?></span>
            <p><?= $esc($an['about']) ?></p>
            <div class="ft"><span>No group yet: be the first</span><a href="<?= $esc($an['url']) ?>">Start this group</a></div>
          </article>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="hm-sec" aria-labelledby="hm-ev-h">
      <h2 id="hm-ev-h" class="sr-only">Events</h2>
      <div class="hm-grid3">
        <?php foreach (array_slice($hm_events, 0, 3) as $ev): ?>
          <article class="hm-card hm-ev">
            <?php $es = $hm_stock['events'][(int) $ev['id']] ?? null; if ($es): ?><div class="hm-evim" style="background-image:url('<?= $esc($es['card']) ?>')"><?= tv_stock_tag($es) ?></div><?php endif; ?>
            <span class="k">Event</span>
            <a class="nm" href="<?= $esc($ev['source_url']) ?>" target="_blank" rel="noopener nofollow"><?= $esc($ev['title']) ?></a>
            <span class="when"><?= $esc(LiveEvents::when($ev)) ?><?= (string) $ev['venue_name'] !== '' ? ' · ' . $esc($ev['venue_name']) : '' ?></span>
            <?php if ((string) $ev['summary'] !== ''): ?><p><?= $esc(mb_strimwidth((string) $ev['summary'], 0, 160, '…')) ?></p><?php endif; ?>
            <div class="ft"><span><?= $esc((string) $ev['price_text'] !== '' ? $ev['price_text'] : 'See the event page') ?></span><button type="button" class="hm-dis" disabled title="Tickets: coming">Tickets: coming</button></div>
          </article>
        <?php endforeach; ?>
        <?php foreach (array_slice($hm_samples, 0, max(0, 3 - min(3, count($hm_events))), true) as $si => $sm): ?>
          <article class="hm-card hm-ev" aria-label="Sample event">
            <?php $es = $hm_stock['samples'][$si] ?? null; if ($es): ?><div class="hm-evim" style="background-image:url('<?= $esc($es['card']) ?>')"><?= tv_stock_tag($es) ?></div><?php endif; ?>
            <span class="hm-sample">Sample</span>
            <span class="k">Event</span>
            <span class="nm" style="font-family:Georgia,'Times New Roman',serif;font-weight:700;font-size:1.05rem;color:#5C4632"><?= $esc($sm[0]) ?></span>
            <span class="when"><?= $esc($sm[2]) ?></span>
            <p><?= $esc($sm[1]) ?> This is a sample of how events will look.</p>
            <div class="ft"><span>Sample</span><button type="button" class="hm-dis" disabled title="Tickets: coming">Tickets: coming</button></div>
          </article>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="hm-sec" aria-labelledby="hm-feed-h">
      <div class="hm-hd"><div><small>Newest first</small><h2 id="hm-feed-h">What's new</h2></div><a class="all" id="hm-seeall" href="/discovery/" hidden>See all</a></div>
      <div class="hm-tabs" role="toolbar" aria-label="Show one kind">
        <?php foreach ($hm_tabs as $k => $t): ?>
          <button type="button" class="hm-tab" data-hm-tab="<?= $esc($k) ?>" data-all="<?= $esc($t[1] ?? '') ?>" aria-pressed="false"><?= $hm_icon[$k] ?><span><?= $esc($t[0]) ?></span><span class="n"><?= $hm_n[$k] ?: '' ?></span></button>
        <?php endforeach; ?>
      </div>
      <div class="hm-feed" id="hm-feed">
        <?php foreach ($hm_feed as $i => $it): ?>
          <article class="hm-item" data-kind="<?= $esc($it['kind']) ?>"<?= $i >= 9 ? ' data-extra hidden' : '' ?>>
            <div class="im"><?php if ($it['img'] !== ''): ?><img src="<?= $esc($it['img']) ?>" alt="" loading="lazy"><?php elseif (!empty($it['stock'])): ?><img src="<?= $esc($it['stock']['card']) ?>" alt="" loading="lazy"><?= tv_stock_tag($it['stock']) ?><?php else: ?><?= $hm_icon[$it['kind']] ?><?php endif; ?></div>
            <div class="bd">
              <span class="k"><?= $esc($hm_tabs[$it['kind']][0]) ?></span>
              <a class="nm" href="<?= $esc($it['url']) ?>"<?= $it['out'] ? ' target="_blank" rel="noopener nofollow"' : '' ?>><?= $esc($it['name']) ?></a>
              <?php if (!empty($it['peek'])): ?><a class="hm-act" href="<?= $esc($it['url']) ?>" data-peek-frame title="Peek" aria-label="Peek at <?= $esc($it['name']) ?>"><?= $hm_icon['peek'] ?></a><?php endif; ?>
              <?php if ($it['where'] !== ''): ?><span class="pl"><?= $esc($it['where']) ?></span><?php endif; ?>
              <span class="mt"><?= $esc($it['meta']) ?></span>
            </div>
          </article>
        <?php endforeach; ?>
        <div class="hm-card inv hm-empty" data-empty="all"<?= $hm_feed ? ' hidden' : '' ?>>
          <p><b>Nothing new near here yet. Be the first:</b> write a journey, share your photos, or add your business.</p>
          <span><a class="go" href="/journeys/">Write a journey</a> <a class="go" href="/claim.php">Add your business</a></span>
        </div>
        <?php foreach ($hm_tabs as $k => $t): ?>
          <div class="hm-card inv hm-empty" data-empty="<?= $esc($k) ?>" hidden>
            <p><b><?= $esc($t[2]) ?></b></p>
            <a class="go" href="<?= $esc($t[3][1]) ?>"><?= $esc($t[3][0]) ?></a>
          </div>
        <?php endforeach; ?>
        <?php if (count($hm_feed) > 9): ?><p class="hm-more" id="hm-more"><a href="#" data-tv-click="tvHomeMore:event">Show more</a></p><?php endif; ?>
      </div>
    </section>

    <section class="hm-go" aria-labelledby="hm-go-l">
      <label id="hm-go-l" for="hm-go-in">Have a GO Code?</label>
      <form id="hm-go-f" data-tv-submit="tvHomeGo:event">
        <input id="hm-go-in" type="text" inputmode="url" autocomplete="off" placeholder="trvgo.us/abc12 or abc12" aria-describedby="hm-go-h">
        <button type="submit">Go</button>
      </form>
      <small id="hm-go-h">Type the code from a sign or flyer to open its page.</small>
    </section>

    <?php if ($stats): ?>
    <dl class="hm-stats" aria-label="The directory at a glance">
      <div><dt>Local businesses</dt><dd><?= number_format($stats['businesses']) ?></dd></div>
      <div><dt>Cities &amp; towns</dt><dd><?= number_format($stats['cities']) ?></dd></div>
    </dl>
    <?php endif; ?>

  </div>
</main>
<script<?= function_exists('tv_nonce') ? tv_nonce() : '' ?>>
  // Where to search: the same place the header's menu shows (location-scope.js keeps it); it also names the town in
  // "start a group for …".
  (function () {
    var out = document.getElementById('hm-where'), txt = document.getElementById('hm-where-t'), what = document.getElementById('hm-what');
    function sync() {
      var l = document.getElementById('menu-location-label');
      var t = l && l.textContent ? l.textContent.trim() : '';
      var set = t && !/not set/i.test(t);
      txt.textContent = set ? t.split(' \u00b7 ')[0] : 'Let\u2019s get local';
      out.classList.toggle('set', !!set);
      out.setAttribute('aria-label', set ? 'Where: ' + t + '. Change the place' : 'Where: choose a place');
      document.querySelectorAll('[data-hm-place]').forEach(function (s) { s.textContent = set ? t.split(',')[0] : 'Your town'; });
    }
    var l = document.getElementById('menu-location-label');
    if (l && window.MutationObserver) new MutationObserver(sync).observe(l, { childList: true, characterData: true, subtree: true });
    window.addEventListener('tv:location', sync);
    setTimeout(sync, 300);
    // the search names the place in its own placeholder; here the place has its own box, so the words box keeps its label
    if (what && window.MutationObserver) new MutationObserver(function () { if (what.placeholder !== 'Discover more') what.placeholder = 'Discover more'; }).observe(what, { attributes: true, attributeFilter: ['placeholder'] });
  })();
  // The ribbon (0138 §4): a tab shows only its kind; tapping it again shows everything. An empty tab invites.
  (function () {
    var tabs = document.querySelectorAll('[data-hm-tab]'), items = document.querySelectorAll('#hm-feed .hm-item'), all = document.getElementById('hm-seeall'), more = document.getElementById('hm-more');
    function show(k) {
      tabs.forEach(function (t) { t.setAttribute('aria-pressed', t.getAttribute('data-hm-tab') === k ? 'true' : 'false'); });
      var n = 0;
      items.forEach(function (it) { var on = !k || it.getAttribute('data-kind') === k; if (on) n++; it.hidden = !on || (!k && it.hasAttribute('data-extra')); });
      document.querySelectorAll('[data-empty]').forEach(function (e) { var w = e.getAttribute('data-empty'); e.hidden = !(k ? (w === k && n === 0) : (w === 'all' && items.length === 0)); });
      var t = k && document.querySelector('[data-hm-tab="' + k + '"]'), href = t ? t.getAttribute('data-all') : '';
      if (all) { all.hidden = !href; if (href) all.href = href; }
      if (more) more.hidden = !!k;
    }
    tabs.forEach(function (t) { t.addEventListener('click', function () { var k = t.getAttribute('data-hm-tab'); show(t.getAttribute('aria-pressed') === 'true' ? '' : k); }); });
    window.tvHomeMore = function (e) { e.preventDefault(); items.forEach(function (it) { it.hidden = false; }); if (more) more.hidden = true; };
  })();
  // A GO Code: "trvgo.us/abc12", "https://trvgo.us/abc12" or just "abc12" opens its page on trvgo.us.
  window.tvHomeGo = function (e) {
    e.preventDefault();
    var inp = document.getElementById('hm-go-in');
    var v = (inp.value || '').trim().replace(/^https?:\/\//i, '').replace(/^(www\.)?trvgo\.us\/?/i, '').replace(/^#/, '').replace(/\/+$/, '');
    if (!/^[A-Za-z0-9_-]{2,40}$/.test(v)) {
      if (window.TvAsk) TvAsk.say('That doesn’t look like a GO Code. Type the letters and numbers after trvgo.us/.', { anchor: inp, bad: true });
      return;
    }
    location.href = 'https://trvgo.us/' + encodeURIComponent(v);
  };
</script>

<?php require_once __DIR__ . '/../app/ui/footer.php'; tv_footer(); ?>

<?php require_once __DIR__ . '/../app/ui/location-modal.php'; ?>

<script src="/js/location-scope.js?v=<?= (int)@filemtime(__DIR__ . '/js/location-scope.js') ?>"></script>
<script src="/js/header-nav.js?v=<?= (int)@filemtime(__DIR__ . '/js/header-nav.js') ?>" defer></script>
</body>
</html>
