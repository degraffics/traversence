<?php
// pages/view.php — one of our own pages (Storefront & pages; app/lib/SitePages.php): /pages/view.php?s=<address>.
// Drafts and hidden pages show only to our team, with a note saying so. A page with a form takes messages here
// (pages/form.php), and they come to Marketplace & Storefronts → Form entries and to Customers as leads.
declare(strict_types=1);

require_once __DIR__ . '/../../app/ui/security-headers.php';
require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/SitePages.php';
require_once __DIR__ . '/../../app/lib/Captcha.php';
header('Content-Type: text/html; charset=utf-8');   // the bootstrap starts JSON

$pdo = Database::connection();
$page = SitePages::bySlug($pdo, (string) ($_GET['s'] ?? ''));
$staff = false;
if ($page && $page['status'] !== 'live' && ($me = Auth::currentUser())) {
    require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
    $staff = IntakeStager::canUseIntake($pdo, $me);
    if (!$staff) { try { $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('admin_access') . ' WHERE user_id = ? LIMIT 1'); $st->execute([(int) $me['id']]); $staff = (bool) $st->fetchColumn(); } catch (Throwable) {} }
}
require_once __DIR__ . '/../../app/ui/page-shell.php';
if (!$page || ($page['status'] !== 'live' && !$staff)) {
    require_once __DIR__ . '/../../app/ui/not-found.php';
    tv_not_found();
}

$url = (isset($_SERVER['HTTP_HOST']) ? 'https://' . $_SERVER['HTTP_HOST'] : '') . SitePages::url($page);
$desc = $page['summary'] !== '' ? (string) $page['summary'] : mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags(SitePages::html((string) $page['body'])))), 0, 155);
$img = (string) $page['share_image'];
if ($img !== '' && $img[0] === '/' && isset($_SERVER['HTTP_HOST'])) $img = 'https://' . $_SERVER['HTTP_HOST'] . $img;
$head = '<link rel="canonical" href="' . tv_e($url) . '"><meta property="og:type" content="website"><meta property="og:site_name" content="Traversence">'
    . '<meta property="og:title" content="' . tv_e($page['title']) . '"><meta property="og:description" content="' . tv_e($desc) . '"><meta property="og:url" content="' . tv_e($url) . '">'
    . ($img !== '' ? '<meta property="og:image" content="' . tv_e($img) . '"><meta name="twitter:card" content="summary_large_image">' : '<meta name="twitter:card" content="summary">');
tv_page_start($page['title'], ['description' => $desc, 'no_crumbs' => true, 'head' => $head]);
tv_count_item('page:' . (int) $page['id']);
$ld = ['@context' => 'https://schema.org', '@type' => $page['form'] === 'contact' ? 'ContactPage' : 'WebPage', 'name' => $page['title'], 'description' => $desc, 'url' => $url,
    'isPartOf' => ['@type' => 'WebSite', 'name' => 'Traversence'], 'dateModified' => date('c', strtotime((string) $page['updated_at']))];
if ($img !== '') $ld['image'] = $img;
echo '<script type="application/ld+json">' . json_encode($ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) . '</script>';
?>
<style>
  .sp{max-width:46rem;margin:0 auto}
  .sp-card{background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:1rem;box-shadow:0 4px 10px rgba(62,43,31,.08);padding:1.1rem 1.25rem;margin-top:.8rem}
  .sp-body{font-size:1rem;line-height:1.65;color:#3E2B1F}.sp-body h2{font-family:Georgia,serif;font-weight:700;font-size:1.35rem;margin:1.2rem 0 .4rem}.sp-body h3{font-weight:700;font-size:1.1rem;margin:1rem 0 .3rem}
  .sp-body p{margin:.55rem 0}.sp-body ul{list-style:disc;padding-left:1.3rem;margin:.5rem 0}.sp-body li{margin:.2rem 0}.sp-body a{color:#92400E;text-decoration:underline}
  .sp-body figure{margin:1rem 0}.sp-body img{max-width:100%;height:auto;border-radius:.6rem}.sp-body figcaption{font-size:.85rem;color:#8A7355;margin-top:.3rem}
  .sp-note{background:#FDE68A;border:1px solid #F59E0B;border-radius:.6rem;padding:.45rem .7rem;font-size:.9rem;margin-bottom:.6rem}
  .sp-form{display:grid;gap:.6rem}.sp-form label{display:grid;gap:.2rem;font-size:.88rem;font-weight:700;color:#5C4632}
  .sp-form input,.sp-form textarea{border:1px solid #CBB98D;border-radius:.6rem;background:#FFFBF2;padding:.55rem .7rem;font:inherit;font-weight:400;color:#3E2B1F}
  .sp-form button{justify-self:start;background:#3E2B1F;color:#FFFBF2;border-radius:999px;padding:.55rem 1.3rem;font-weight:700}.sp-form button:disabled{opacity:.6}
  .sp-hp{position:absolute;left:-5000px;width:1px;height:1px;overflow:hidden}
  .sp-msg{border-radius:.6rem;padding:.5rem .7rem;font-size:.92rem}.sp-msg.ok{background:#DCEFE6;color:#1F5C43}.sp-msg.bad{background:#FDE2E2;color:#991B1B}
</style>
<article class="sp">
  <?php if ($page['status'] !== 'live'): ?><p class="sp-note"><b><?= tv_e(SitePages::STATUSES[$page['status']]) ?>:</b> only our team can see this page. Set it live in Marketplace &amp; Storefronts → Storefront &amp; pages.</p><?php endif; ?>
  <header>
    <p class="text-[11px] uppercase tracking-widest text-[#8A7355]">Traversence</p>
    <h1 class="font-serif font-bold text-3xl sm:text-4xl"><?= tv_e($page['title']) ?></h1>
  </header>
  <?php if (trim((string) $page['body']) !== ''): ?><div class="sp-card sp-body tv-bleed"><?= SitePages::html((string) $page['body']) ?></div><?php endif; ?>
  <?php // the page's blocks, under its text (decisions/0159 step 3): a page with no text is a page of blocks
        require_once __DIR__ . '/../../app/lib/Blocks.php';
        echo Blocks::zone($pdo, 'page.' . (int) $page['id'], '', 'This page\'s sections'); ?>
  <?php if ($page['form'] !== 'none'): $quote = $page['form'] === 'quote'; ?>
  <section class="sp-card tv-bleed" aria-labelledby="sp-fh">
    <h2 id="sp-fh" class="font-serif font-bold text-xl mb-2"><?= $quote ? 'Ask for a quote' : 'Send us a message' ?></h2>
    <form class="sp-form" id="sp-form" novalidate>
      <label>Your name<input name="name" autocomplete="name" required maxlength="120"></label>
      <label>Email<input name="email" type="email" autocomplete="email" required maxlength="190"></label>
      <label>Phone (optional)<input name="phone" type="tel" autocomplete="tel" maxlength="40"></label>
      <label><?= $quote ? 'What do you need? Quantities, sizes, when you need it' : 'Your message' ?><textarea name="message" rows="5" required maxlength="5000"></textarea></label>
      <div class="sp-hp" aria-hidden="true"><label>Leave this empty<input name="website" tabindex="-1" autocomplete="off"></label></div>
      <?= Captcha::widget() ?>
      <div id="sp-out" role="status"></div>
      <button type="submit"><?= $quote ? 'Ask for a quote' : 'Send' ?></button>
      <p class="text-xs text-[#8A7355]">We use your details only to answer you. See our <a class="underline" href="/privacy.php">Privacy Policy</a>.</p>
    </form>
  </section>
  <script>
  (function () {
    var f = document.getElementById('sp-form'), out = document.getElementById('sp-out');
    function say(m, ok) { out.className = 'sp-msg ' + (ok ? 'ok' : 'bad'); out.textContent = m; }
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = f.querySelector('button[type=submit]'), d = { page: <?= (int) $page['id'] ?>, captcha: window.tvCaptcha ? tvCaptcha() : '' };
      ['name', 'email', 'phone', 'message', 'website'].forEach(function (k) { d[k] = f.elements[k].value.trim(); });
      if (!d.name) return say('Please give your name.'); if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)) return say('Please check your email address.'); if (d.message.length < 5) return say('Please write your message.');
      b.disabled = true;
      fetch('/pages/form.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(window.tvSafe ? tvSafe(d) : d) })
        .then(function (r) { return r.json(); }).then(function (j) {
          if (j.ok || j.success) { f.reset(); say('Thank you. We\'ve got your message and will answer by email.', true); }
          else { say((j.error && j.error.message) || j.error || 'That didn\'t send. Try again.'); }
          b.disabled = false; if (window.tvCaptchaReset) tvCaptchaReset();
        }).catch(function () { b.disabled = false; say('That didn\'t send. Check your connection and try again.'); });
    });
  })();
  </script>
  <?php endif; ?>
</article>
<?php tv_page_end();
