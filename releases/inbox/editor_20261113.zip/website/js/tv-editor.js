/* js/tv-editor.js — the editor's core (decisions/0159 §3, step 3; app/lib/Blocks.php, /api/blocks.php). Loaded only for
 * staff with pages.edit, on a page with a zone (Blocks::zone). Edit on a zone opens its panel (a sheet from the bottom on a
 * phone, a panel at the side on a computer): its sections (1 to 3 columns, a background, centred or not), each column's
 * blocks (heading, text, picture, button), moved up and down, copied, removed. Save draft keeps it for the team only, and
 * the page shows the draft (the preview); Publish puts it live as the next version; Versions lists them, each with Roll
 * back. Every action shows its spinner, then the site's notice (TvAsk). The full editor (drag and drop, the design panel,
 * breakpoints) is step 4. */
(function () {
  var zones = document.querySelectorAll('[data-tvb-zone]');
  if (!zones.length) return;
  var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
  var REOPEN = 'tvbReopen';
  var css = document.createElement('style');
  css.textContent = '.tve{position:fixed;z-index:1360;background:#FFFBF2;color:#3E2B1F;box-shadow:0 -10px 30px -10px rgba(0,0,0,.45);display:flex;flex-direction:column;font:15px/1.4 system-ui,sans-serif;left:0;right:0;bottom:0;max-height:62vh;border-radius:1rem 1rem 0 0}'
    + '@media (min-width:900px){.tve{left:auto;top:0;width:27rem;max-height:none;border-radius:0;box-shadow:-10px 0 30px -10px rgba(0,0,0,.45)}}'
    + '.tve-hd{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center;padding:.6rem .7rem;background:#B9D8C6;border-radius:inherit;border-bottom:1px solid #9CC3AE}'
    + '.tve-hd b{flex:1 1 9rem;font:700 1rem ui-serif,Georgia,serif;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.tve-hd small{flex-basis:100%;color:#3E2B1F}'
    + '.tve-b{font:700 .85rem/1.2 system-ui,sans-serif;border:1.5px solid #E07F3C;background:#fff;color:#2B1D14;border-radius:.3rem;padding:.35rem .6rem;cursor:pointer}'
    + '.tve-b.go{background:#E07F3C;color:#fff}.tve-b.no{border-color:#B91C1C;color:#991B1B}.tve-b.sm{padding:.15rem .45rem;font-size:.78rem}'
    + '.tve-b[aria-busy=true]::before{content:"";display:inline-block;width:.7rem;height:.7rem;margin-right:.35rem;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;vertical-align:-1px;animation:tvespin .8s linear infinite}@keyframes tvespin{to{transform:rotate(360deg)}}'
    + '.tve-bd{overflow:auto;padding:.6rem .7rem 1.2rem;flex:1}.tve-sec{border:1px solid #CBB98D;border-radius:.6rem;margin:.6rem 0;background:#F7EFDC}'
    + '.tve-sh{display:flex;flex-wrap:wrap;gap:.3rem;align-items:center;padding:.45rem .5rem;border-bottom:1px solid #E2D4B2}.tve-sh strong{margin-right:auto}'
    + '.tve-col{padding:.4rem .5rem}.tve-col>h5{margin:.2rem 0;font:700 .72rem system-ui;letter-spacing:.04em;text-transform:uppercase;color:#8A7355}'
    + '.tve-blk{background:#FFFBF2;border:1px solid #E2D4B2;border-radius:.5rem;padding:.45rem;margin:.35rem 0}.tve-bh{display:flex;gap:.25rem;align-items:center;margin-bottom:.3rem}.tve-bh em{margin-right:auto;font-style:normal;font-weight:700;font-size:.85rem;color:#92400E}'
    + '.tve label{display:block;font-size:.78rem;font-weight:700;color:#5C4632;margin:.25rem 0 .1rem}.tve input,.tve textarea,.tve select{width:100%;box-sizing:border-box;font:16px system-ui,sans-serif;border:1px solid #CBB98D;border-radius:.4rem;padding:.35rem .45rem;background:#fff;color:#3E2B1F}'
    + '.tve select.inl{width:auto;font-size:.85rem;padding:.2rem}.tve-add{display:flex;gap:.3rem;margin-top:.3rem}.tve-add select{flex:1}.tve-hint{font-size:.78rem;color:#8A7355;margin:.2rem 0}'
    + '.tve-dot{display:inline-block;width:.55rem;height:.55rem;border-radius:50%;background:#E2A93B;margin-left:.3rem;vertical-align:1px}.tve-v{display:flex;gap:.4rem;align-items:center;border-bottom:1px solid #E2D4B2;padding:.4rem 0}.tve-v span{flex:1}';
  document.head.appendChild(css);

  var cur = null;   // {zone, el, data, tree, dirty, view}
  function el(tag, attrs, kids) {
    var x = document.createElement(tag);
    for (var k in (attrs || {})) { if (k === 'text') x.textContent = attrs[k]; else if (k === 'on') x.addEventListener('click', attrs[k]); else x.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c != null) x.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return x;
  }
  function say(msg, anchor, bad) { if (window.TvAsk && TvAsk.say) TvAsk.say(msg, { anchor: anchor, bad: !!bad }); }
  function busy(b, on) { if (!b) return; if (window.TvAsk && TvAsk.busy) TvAsk.busy(b, on); else { if (on) b.setAttribute('aria-busy', 'true'); else b.removeAttribute('aria-busy'); b.disabled = !!on; } }
  function api(body) {
    var o = { credentials: 'include', headers: { 'Content-Type': 'application/json' } };
    if (body) { o.method = 'POST'; o.headers['X-CSRF-Token'] = cur.el.getAttribute('data-csrf') || ''; body.tz = tz; body.zone = cur.zone; o.body = JSON.stringify(window.tvSafe ? tvSafe(body) : body); }
    return fetch('/api/blocks.php' + (body ? '' : '?zone=' + encodeURIComponent(cur.zone)), o)
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again.' } }; }); }, function () { return { ok: false, error: { message: 'The connection dropped. Try again.' } }; })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again; still stuck? Write to support@traversence.com.'); return j; });
  }
  function when(iso, z) { try { return window.TvTime && TvTime.fmt ? TvTime.fmt(iso, z) : new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short', timeZone: z || undefined }); } catch (e) { return iso; } }
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  function blank(t) { return t === 'heading' ? { t: t, text: '', level: 2 } : t === 'text' ? { t: t, md: '' } : t === 'image' ? { t: t, src: '', alt: '', caption: '' } : { t: 'button', label: '', href: '', style: 'primary' }; }
  function move(list, i, d) { var j = i + d; if (j < 0 || j >= list.length) return; var x = list[i]; list[i] = list[j]; list[j] = x; }
  function changed() { cur.dirty = true; var h = panel && panel.querySelector('.tve-hd b'); if (h && !h.querySelector('.tve-dot')) h.appendChild(el('span', { class: 'tve-dot', title: 'Not saved yet', 'aria-label': 'Not saved yet' })); }

  var panel = null;
  function open(zoneEl, view) {
    cur = { zone: zoneEl.getAttribute('data-tvb-zone'), label: zoneEl.getAttribute('data-tvb-label') || '', el: zoneEl, dirty: false, view: view === 'versions' ? 'versions' : 'edit' };
    var btn = zoneEl.querySelector('[data-tvb-edit]'); busy(btn, true);
    api().then(function (j) { busy(btn, false); cur.data = j; cur.tree = clone(j.state.draft || j.state.live || { sections: [] }); if (!cur.tree.sections.length) cur.tree.sections.push({ cols: [[]], bg: 'none', align: 'left' }); draw(); },
               function (e) { busy(btn, false); say(e.message, btn, true); });
  }
  function close() {
    if (cur && cur.dirty && window.TvAsk && TvAsk.confirm) { TvAsk.confirm('Close without saving? Your changes since the last Save draft are lost.', { yes: 'Close', danger: true }).then(function (y) { if (y) shut(); }); return; }
    shut();
  }
  function shut() { if (panel) panel.remove(); panel = null; cur = null; }

  function field(lab, input) { return el('div', {}, [el('label', { text: lab }), input]); }
  function inp(obj, key, attrs) {
    var x = el(attrs && attrs.area ? 'textarea' : 'input', Object.assign({}, attrs && attrs.area ? { rows: '4' } : { type: 'text' }, (attrs && attrs.extra) || {}));
    x.value = obj[key] || ''; x.addEventListener('input', function () { obj[key] = x.value; changed(); });
    return x;
  }
  function sel(obj, key, opts, inl) {
    var x = el('select', inl ? { class: 'inl' } : {});
    opts.forEach(function (o) { var op = el('option', { value: o[0], text: o[1] }); if (String(obj[key]) === String(o[0])) op.selected = true; x.appendChild(op); });
    x.addEventListener('change', function () { obj[key] = /^\d+$/.test(x.value) ? +x.value : x.value; changed(); });
    return x;
  }

  function blockBox(list, i) {
    var b = list[i], types = cur.data.types || {};
    var box = el('div', { class: 'tve-blk' });
    box.appendChild(el('div', { class: 'tve-bh' }, [el('em', { text: (types[b.t] || [b.t])[0] }),
      el('button', { type: 'button', class: 'tve-b sm', title: 'Move up', 'aria-label': 'Move up', text: '↑', on: function () { move(list, i, -1); changed(); draw(); } }),
      el('button', { type: 'button', class: 'tve-b sm', title: 'Move down', 'aria-label': 'Move down', text: '↓', on: function () { move(list, i, 1); changed(); draw(); } }),
      el('button', { type: 'button', class: 'tve-b sm', title: 'Copy it', 'aria-label': 'Copy it', text: '⧉', on: function () { list.splice(i + 1, 0, clone(b)); changed(); draw(); } }),
      el('button', { type: 'button', class: 'tve-b sm no', title: 'Remove it', 'aria-label': 'Remove it', text: '✕', on: function () { list.splice(i, 1); changed(); draw(); } })]));
    if (b.t === 'heading') { box.appendChild(field('Words', inp(b, 'text', { extra: { 'data-spell': '', maxlength: '200' } }))); box.appendChild(field('Size', sel(b, 'level', [[2, 'Large'], [3, 'Smaller']]))); }
    if (b.t === 'text') { box.appendChild(inp(b, 'md', { area: true, extra: { 'aria-label': 'The words' } })); box.appendChild(el('p', { class: 'tve-hint', text: 'A blank line starts a new paragraph. "- " starts a list line. **bold**, *italic*, [words](/link or https://…).' })); }
    if (b.t === 'image') {
      var src = inp(b, 'src', { extra: { placeholder: 'https://… or upload one', spellcheck: 'false' } });
      var up = el('button', { type: 'button', class: 'tve-b sm', text: 'Upload a picture' });
      var file = el('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', hidden: '', 'data-art': 'off' });
      up.addEventListener('click', function () { file.click(); });
      file.addEventListener('change', function () {
        var f = file.files && file.files[0]; file.value = ''; if (!f || !window.TvUpload) { if (f) say('The uploader isn\'t on this page: reload it and try again.', up, true); return; }
        busy(up, true);
        TvUpload.send([f], { target: 'block_image', ctx: { zone: cur.zone }, el: box }).then(function (res) {
          busy(up, false); var r = (res && res[0]) || {}, got = r.result || r;
          if (r.ok === false || r.error || !got.url) { say((r.error && (r.error.message || r.error)) || 'The upload didn\'t go through. Try again.', up, true); return; }
          b.src = got.url; src.value = got.url; changed(); say('Uploaded: it shows here once you Save draft.', up);
        }, function () { busy(up, false); say('The upload didn\'t go through. Try again.', up, true); });
      });
      box.appendChild(field('The picture', src)); box.appendChild(el('div', {}, [up, file]));
      box.appendChild(field('What it shows (for those who can\'t see it)', inp(b, 'alt', { extra: { 'data-spell': '' } })));
      box.appendChild(field('Caption (optional)', inp(b, 'caption', { extra: { 'data-spell': '' } })));
    }
    if (b.t === 'button') {
      box.appendChild(field('Words on it', inp(b, 'label', { extra: { 'data-spell': '', maxlength: '80' } })));
      box.appendChild(field('Where it goes', inp(b, 'href', { extra: { placeholder: '/page, https://…, mailto:…', spellcheck: 'false' } })));
      box.appendChild(field('Look', sel(b, 'style', [['primary', 'Filled'], ['plain', 'Outline']])));
    }
    return box;
  }

  function sectionBox(i) {
    var s = cur.tree.sections[i], n = cur.tree.sections.length;
    var box = el('div', { class: 'tve-sec' });
    var cols = el('select', { class: 'inl', 'aria-label': 'Columns' });
    [1, 2, 3].forEach(function (k) { var o = el('option', { value: k, text: k + ' column' + (k > 1 ? 's' : '') }); if (s.cols.length === k) o.selected = true; cols.appendChild(o); });
    cols.addEventListener('change', function () {
      var k = +cols.value; while (s.cols.length < k) s.cols.push([]);
      if (s.cols.length > k) { var extra = s.cols.splice(k); extra.forEach(function (c) { s.cols[k - 1] = s.cols[k - 1].concat(c); }); }   // blocks of a removed column move to the last one, never lost
      changed(); draw();
    });
    box.appendChild(el('div', { class: 'tve-sh' }, [el('strong', { text: 'Section ' + (i + 1) }), cols,
      sel(s, 'bg', Object.keys(cur.data.bgs || { none: 1 }).map(function (k) { return [k, (cur.data.bgs || {})[k] || k]; }), true),
      sel(s, 'align', [['left', 'Left'], ['center', 'Centred']], true),
      el('button', { type: 'button', class: 'tve-b sm', 'aria-label': 'Move the section up', title: 'Move up', text: '↑', on: function () { move(cur.tree.sections, i, -1); changed(); draw(); } }),
      el('button', { type: 'button', class: 'tve-b sm', 'aria-label': 'Move the section down', title: 'Move down', text: '↓', on: function () { move(cur.tree.sections, i, 1); changed(); draw(); } }),
      el('button', { type: 'button', class: 'tve-b sm', 'aria-label': 'Copy the section', title: 'Copy it', text: '⧉', on: function () { cur.tree.sections.splice(i + 1, 0, clone(s)); changed(); draw(); } }),
      el('button', { type: 'button', class: 'tve-b sm no', 'aria-label': 'Remove the section', title: 'Remove it', text: '✕', on: function (e) {
        var go = function () { cur.tree.sections.splice(i, 1); changed(); draw(); };
        if (window.TvAsk && TvAsk.confirm) TvAsk.confirm('Remove section ' + (i + 1) + ' and everything in it?', { anchor: e.currentTarget, yes: 'Remove', danger: true }).then(function (y) { if (y) go(); }); else go();
      } })]));
    s.cols.forEach(function (c, ci) {
      var col = el('div', { class: 'tve-col' });
      if (s.cols.length > 1) col.appendChild(el('h5', { text: 'Column ' + (ci + 1) }));
      c.forEach(function (b, bi) { col.appendChild(blockBox(c, bi)); });
      var add = el('select', { 'aria-label': 'Add a block' }); add.appendChild(el('option', { value: '', text: '+ Add a block…' }));
      Object.keys(cur.data.types || {}).forEach(function (t) { add.appendChild(el('option', { value: t, text: cur.data.types[t][0] + ': ' + cur.data.types[t][1] })); });
      add.addEventListener('change', function () { if (!add.value) return; c.push(blank(add.value)); changed(); draw(); });
      col.appendChild(el('div', { class: 'tve-add' }, [add]));
      box.appendChild(col);
    });
    return box;
  }

  function act(btn, action, extra, ok) {
    busy(btn, true);
    return api(Object.assign({ action: action }, extra || {})).then(function (j) {
      busy(btn, false); cur.dirty = false;
      try { sessionStorage.setItem(REOPEN, JSON.stringify({ zone: cur.zone, msg: j.message, view: ok || 'edit' })); } catch (e) {}
      location.reload();   // the page shows the draft (the preview), or what's live now
    }, function (e) { busy(btn, false); say(e.message, btn, true); });
  }

  function draw() {
    var keep = panel ? panel.querySelector('.tve-bd').scrollTop : 0;
    if (panel) panel.remove();
    var st = cur.data.state, can = cur.data.can || {};
    var line = st.draft ? 'Draft saved' + (st.draft_by ? ' by ' + st.draft_by : '') + (st.draft_at ? ', ' + when(st.draft_at.replace(' ', 'T') + 'Z', st.draft_tz) : '') + ': only our team sees it.' : st.live_version ? 'Live: version ' + st.live_version + '.' : 'Not published yet: visitors see the page as it was.';
    panel = el('div', { class: 'tve', role: 'dialog', 'aria-label': 'Edit ' + cur.label });
    var hd = el('div', { class: 'tve-hd' }, [el('b', { text: cur.label })]);
    if (cur.view === 'edit') {
      hd.appendChild(el('button', { type: 'button', class: 'tve-b', text: 'Save draft', on: function (e) { act(e.currentTarget, 'save', { tree: cur.tree }); } }));
      if (can.publish) hd.appendChild(el('button', { type: 'button', class: 'tve-b go', text: 'Publish', on: function (e) {
        var b = e.currentTarget, go = function () { act(b, 'publish', { tree: cur.tree }); };
        if (window.TvAsk && TvAsk.confirm) TvAsk.confirm('Publish this to everyone now? It becomes the next version; Versions can roll it back.', { anchor: b, yes: 'Publish' }).then(function (y) { if (y) go(); }); else go();
      } }));
      hd.appendChild(el('button', { type: 'button', class: 'tve-b', text: 'Versions', on: function () { cur.view = 'versions'; draw(); } }));
    } else hd.appendChild(el('button', { type: 'button', class: 'tve-b', text: '← Back to editing', on: function () { cur.view = 'edit'; draw(); } }));
    hd.appendChild(el('button', { type: 'button', class: 'tve-b', 'aria-label': 'Close', text: '✕', on: close }));
    hd.appendChild(el('small', { text: line }));
    panel.appendChild(hd);
    var bd = el('div', { class: 'tve-bd' });
    if (cur.view === 'edit') {
      cur.tree.sections.forEach(function (s, i) { bd.appendChild(sectionBox(i)); });
      bd.appendChild(el('button', { type: 'button', class: 'tve-b', text: '+ Add a section', on: function () { cur.tree.sections.push({ cols: [[]], bg: 'none', align: 'left' }); changed(); draw(); } }));
      if (st.draft) bd.appendChild(el('p', {}, [el('button', { type: 'button', class: 'tve-b no', text: 'Throw the draft away', on: function (e) {
        var b = e.currentTarget, go = function () { act(b, 'discard'); };
        if (window.TvAsk && TvAsk.confirm) TvAsk.confirm('Throw the draft away? The page goes back to what\'s live.', { anchor: b, yes: 'Throw it away', danger: true }).then(function (y) { if (y) go(); }); else go();
      } })]));
    } else {
      var vs = cur.data.versions || [];
      if (!vs.length) bd.appendChild(el('p', { text: 'Nothing published here yet.' }));
      vs.forEach(function (v) {
        var row = el('div', { class: 'tve-v' }, [el('span', { text: 'Version ' + v.version + (v.version === st.live_version ? ' (live)' : '') + ' · ' + (v.by || 'someone') + ' · ' + when(v.at, v.tz) + (v.note ? ' · ' + v.note : '') })]);
        if (can.publish && v.version !== st.live_version) row.appendChild(el('button', { type: 'button', class: 'tve-b sm', text: 'Roll back to it', on: function (e) {
          var b = e.currentTarget, go = function () { act(b, 'rollback', { version: v.version }, 'versions'); };
          if (window.TvAsk && TvAsk.confirm) TvAsk.confirm('Put version ' + v.version + ' live again? It becomes the next version; nothing is lost.', { anchor: b, yes: 'Roll back' }).then(function (y) { if (y) go(); }); else go();
        } }));
        bd.appendChild(row);
      });
    }
    panel.appendChild(bd);
    document.body.appendChild(panel);
    bd.scrollTop = keep;
  }

  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-tvb-edit]'); if (!b) return; if (cur) { say('Close the zone you\'re editing first.', b, true); return; } open(b.closest('[data-tvb-zone]')); });
  window.addEventListener('beforeunload', function (e) { if (cur && cur.dirty) { e.preventDefault(); e.returnValue = ''; } });
  // back after Save draft, Publish or Roll back: the same zone's panel, open again, with the answer beside it
  var again = null; try { again = JSON.parse(sessionStorage.getItem(REOPEN) || 'null'); sessionStorage.removeItem(REOPEN); } catch (e) {}
  if (again) {
    var z = document.querySelector('[data-tvb-zone="' + String(again.zone).replace(/"/g, '') + '"]');
    if (z) {
      z.scrollIntoView({ block: 'center' });
      setTimeout(function () { say(again.msg || 'Done.', z.querySelector('[data-tvb-edit]')); open(z, again.view); }, 300);
    }
  }
})();
