<?php
// app/lib/Blocks.php — the editor's core (decisions/0159 §3, §6, step 3): a page's content as a tree of blocks, edited in
// place on the real page by staff with pages.edit, kept as a draft only the team sees (the draft is the preview), put
// live with pages.publish, every publish a numbered version, Roll back to any of them.
//
//   zone      a place on a page that holds blocks: a coded page adds one where a release puts it (Blocks::zone(), the home
//             page's "home.after-doors" first), and each of our own pages (SitePages) has one under its text ("page.<id>").
//             What a coded page showed before stays its fallback, so nothing built is lost (0159 §2).
//   tree      ['sections' => [section…]]; a section is ['cols' => [[block…], …] (1 to 3 columns), 'bg' => none|sand|sage,
//             'align' => left|center]; a block is one of TYPES. Structured, never free positions: sections stack, columns
//             sit side by side in a grid and stack on phones (0159 §6, 0058 §11).
//   versions  each publish keeps its tree, numbered, with who and when (and the device's time zone). Roll back publishes a
//             copy of an earlier one as the next version, so the history only grows.
// Rendered on the server to plain HTML (escaped text; links and pictures only from safe addresses), the same for everyone;
// only an editor gets the zone's outline, its Edit button and js/tv-editor.js. The full editor (widget panel, drag and drop,
// the design panel, breakpoints, global and live components) is step 4.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/SitePages.php';

final class Blocks
{
    /** Who may (Founder only until a role is given them, System Configuration → Permissions). */
    public const PERMS = ['pages.edit' => 'Pages: edit content in place and save drafts', 'pages.publish' => 'Pages: publish content and roll it back'];
    /** The kinds of block in the core (more, and live components, in step 4): [name, what it is]. */
    public const TYPES = ['heading' => ['Heading', 'A title for what follows'], 'text' => ['Text', 'Paragraphs, lists, bold, italic and links'],
        'image' => ['Picture', 'One picture, with words for those who can\'t see it'], 'button' => ['Button', 'A link that looks like a button']];
    public const BGS = ['none' => 'No background', 'sand' => 'Sand', 'sage' => 'Sage'];
    private const MAX_SECTIONS = 20, MAX_BLOCKS = 30, MAX_TEXT = 20000;

    private static bool $ready = false;
    private static bool $kit = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci';
        $pdo->exec('CREATE TABLE IF NOT EXISTS site_block_zones (zone VARCHAR(80) NOT NULL PRIMARY KEY, draft MEDIUMTEXT NULL, draft_by INT UNSIGNED NULL,
            draft_name VARCHAR(100) NOT NULL DEFAULT \'\', draft_at DATETIME NULL, draft_tz VARCHAR(64) NOT NULL DEFAULT \'\', live_version INT UNSIGNED NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL)' . $tail);
        $pdo->exec('CREATE TABLE IF NOT EXISTS site_block_versions (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, zone VARCHAR(80) NOT NULL, version INT UNSIGNED NOT NULL,
            tree MEDIUMTEXT NOT NULL, by_user INT UNSIGNED NULL, by_name VARCHAR(100) NOT NULL DEFAULT \'\', at DATETIME NOT NULL, tz VARCHAR(64) NOT NULL DEFAULT \'\',
            note VARCHAR(200) NOT NULL DEFAULT \'\', UNIQUE KEY uq_block_version (zone, version))' . $tail);
        self::$ready = true;
    }

    // ---- who ----------------------------------------------------------------------------------------------------------

    /** [allowed, why not]. Staff signed in with their staff login, and the permission (Founder until given to a role). */
    public static function can(string $perm): array
    {
        if (!isset(self::PERMS[$perm])) return [false, 'Not a pages permission.'];
        if (PHP_SAPI === 'cli') return [true, ''];
        if (!class_exists('Auth') || !Auth::currentUser()) return [false, 'Sign in first.'];
        require_once __DIR__ . '/../admin/Access.php';
        if (Access::staff() === null) return [false, 'Sign in with your staff login (the admin) first.'];
        [$ok, $why] = Access::can($perm, ['min' => 'founder', 'depts' => []]);
        return [$ok, $ok ? '' : (($why ?: 'Your role can\'t do this') . '. It\'s given in System Configuration → Permissions.')];
    }

    private static function need(string $perm): void
    {
        [$ok, $why] = self::can($perm);
        if (!$ok) throw new RuntimeException($why);
    }

    public static function zoneOk(string $zone): bool { return (bool) preg_match('/^[a-z0-9][a-z0-9._-]{1,79}$/', $zone); }

    // ---- the tree: kept clean whatever is sent --------------------------------------------------------------------------

    /** A tree as it may be kept: only known kinds and fields, lengths capped, addresses checked. */
    public static function clean($tree): array
    {
        $out = ['sections' => []];
        foreach (array_slice((array) (is_array($tree) ? ($tree['sections'] ?? []) : []), 0, self::MAX_SECTIONS) as $s) {
            if (!is_array($s)) continue;
            $cols = [];
            foreach (array_slice((array) ($s['cols'] ?? []), 0, 3) as $c) {
                $blocks = [];
                foreach (array_slice(is_array($c) ? $c : [], 0, self::MAX_BLOCKS) as $b) if (is_array($b) && ($cb = self::cleanBlock($b))) $blocks[] = $cb;
                $cols[] = $blocks;
            }
            if (!$cols) $cols = [[]];
            $out['sections'][] = ['cols' => $cols, 'bg' => isset(self::BGS[$s['bg'] ?? '']) ? $s['bg'] : 'none', 'align' => ($s['align'] ?? '') === 'center' ? 'center' : 'left'];
        }
        return $out;
    }

    private static function cleanBlock(array $b): ?array
    {
        $t = (string) ($b['t'] ?? '');
        $str = fn ($k, $n) => mb_substr(trim((string) ($b[$k] ?? '')), 0, $n);
        switch ($t) {
            case 'heading': return ['t' => 'heading', 'text' => $str('text', 200), 'level' => (int) ($b['level'] ?? 2) === 3 ? 3 : 2];
            case 'text': return ['t' => 'text', 'md' => mb_substr((string) ($b['md'] ?? ''), 0, self::MAX_TEXT)];
            case 'image':
                $src = $str('src', 500);
                return ['t' => 'image', 'src' => self::safeUrl($src, true) ? $src : '', 'alt' => $str('alt', 200), 'caption' => $str('caption', 300)];
            case 'button':
                $href = $str('href', 500);
                return ['t' => 'button', 'label' => $str('label', 80), 'href' => self::safeUrl($href, false) ? $href : '', 'style' => ($b['style'] ?? '') === 'plain' ? 'plain' : 'primary'];
        }
        return null;
    }

    /** Pictures from our own uploads or images, or https; links to our pages, https, email or phone. */
    public static function safeUrl(string $u, bool $img): bool
    {
        if ($u === '') return true;
        return $img ? (bool) preg_match('#^(https://[^\s"<>]+|/uploads/[^\s"<>]+|/image/[^\s"<>]+)$#', $u) : (bool) preg_match('#^(/(?!/)[^\s"<>]*|https://[^\s"<>]+|mailto:[^\s"<>]+|tel:[0-9+() -]+|\#[\w-]*)$#', $u);
    }

    // ---- drawing ------------------------------------------------------------------------------------------------------

    /** The tree as HTML (no zone wrapper). Empty sections and blocks draw nothing. */
    public static function render(array $tree): string
    {
        $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $h = '';
        foreach (($tree['sections'] ?? []) as $s) {
            $cols = ''; $any = false;
            foreach ($s['cols'] as $c) {
                $in = '';
                foreach ($c as $b) {
                    if ($b['t'] === 'heading' && $b['text'] !== '') $in .= '<h' . $b['level'] . ' class="tvb-h' . $b['level'] . '">' . $e($b['text']) . '</h' . $b['level'] . '>';
                    elseif ($b['t'] === 'text' && trim($b['md']) !== '') $in .= '<div class="tvb-text">' . SitePages::html($b['md']) . '</div>';
                    elseif ($b['t'] === 'image' && $b['src'] !== '') $in .= '<figure class="tvb-img"><img src="' . $e($b['src']) . '" alt="' . $e($b['alt']) . '" loading="lazy">' . ($b['caption'] !== '' ? '<figcaption>' . $e($b['caption']) . '</figcaption>' : '') . '</figure>';
                    elseif ($b['t'] === 'button' && $b['label'] !== '' && $b['href'] !== '') $in .= '<p class="tvb-btnrow"><a class="tvb-btn' . ($b['style'] === 'plain' ? ' plain' : '') . '" href="' . $e($b['href']) . '"' . (str_starts_with($b['href'], 'http') ? ' rel="noopener" target="_blank"' : '') . '>' . $e($b['label']) . '</a></p>';
                }
                $cols .= '<div class="tvb-col">' . $in . '</div>';
                $any = $any || $in !== '';
            }
            if (!$any) continue;   // a section with nothing in it draws nothing
            $h .= '<section class="tvb-sec tvb-bg-' . $s['bg'] . ($s['align'] === 'center' ? ' tvb-center' : '') . ($s['bg'] !== 'none' ? ' tv-bleed' : '') . '"><div class="tvb-cols tvb-c' . count($s['cols']) . '">' . $cols . '</div></section>';
        }
        return $h;
    }

    /** The blocks' look, once a page (the brand's colours; phones: one column, 3px from the edges, decisions/0058 §11). */
    private static function kit(): string
    {
        if (self::$kit) return '';
        self::$kit = true;
        return '<style>.tvb-zone{display:block}.tvb-sec{margin:1.2rem 0;border-radius:1rem;color:#3E2B1F}.tvb-bg-sand{background:#F7EFDC;border:1px solid #D9C9A3;padding:1.1rem 1.25rem}'
            . '.tvb-bg-sage{background:#E3EFE8;border:1px solid #B9D8C6;padding:1.1rem 1.25rem}.tvb-center{text-align:center}.tvb-cols{display:grid;gap:1rem}'
            . '@media (min-width:768px){.tvb-c2{grid-template-columns:repeat(2,minmax(0,1fr))}.tvb-c3{grid-template-columns:repeat(3,minmax(0,1fr))}}'
            . '.tvb-h2{font:700 1.6rem/1.25 Georgia,serif;margin:.2rem 0 .5rem}.tvb-h3{font:700 1.2rem/1.3 Georgia,serif;margin:.2rem 0 .4rem}'
            . '.tvb-text{font-size:1rem;line-height:1.65}.tvb-text p{margin:.5rem 0}.tvb-text ul{list-style:disc;padding-left:1.3rem}.tvb-text a{color:#92400E;text-decoration:underline}'
            . '.tvb-text h2{font:700 1.3rem Georgia,serif;margin:1rem 0 .4rem}.tvb-text h3{font-weight:700;font-size:1.1rem;margin:.8rem 0 .3rem}'
            . '.tvb-img{margin:.5rem 0}.tvb-img img{max-width:100%;height:auto;border-radius:.6rem;display:block}.tvb-center .tvb-img img{margin:0 auto}.tvb-img figcaption{font-size:.85rem;color:#8A7355;margin-top:.3rem}'
            . '.tvb-btnrow{margin:.6rem 0}.tvb-btn{display:inline-block;background:#92400E;color:#FFFBF2;border-radius:999px;padding:.55rem 1.2rem;font-weight:700;text-decoration:none}'
            . '.tvb-btn.plain{background:transparent;color:#92400E;border:1.5px solid #92400E}'
            . '@media (max-width:767px){.tvb-sec.tv-bleed{margin-left:3px;margin-right:3px;border-radius:.5rem}.tvb-cols{gap:.6rem}}'
            . '.tvb-edit{position:relative;outline:2px dashed #E07F3C;outline-offset:4px;border-radius:.5rem;min-height:3rem}'
            . '.tvb-edit>.tvb-tag{position:absolute;top:-.9rem;right:.4rem;z-index:5;display:flex;gap:.3rem;align-items:center;font:700 .75rem system-ui,sans-serif}'
            . '.tvb-edit>.tvb-tag span{background:#FDE68A;color:#3E2B1F;border-radius:999px;padding:.15rem .5rem}'
            . '.tvb-edit>.tvb-tag button{background:#E07F3C;color:#fff;border:0;border-radius:999px;padding:.3rem .8rem;font:inherit;cursor:pointer}'
            . '.tvb-empty{border:1.5px dashed #CBB98D;border-radius:.6rem;padding:.8rem;color:#8A7355;font-size:.9rem;text-align:center}</style>';
    }

    // ---- reading ------------------------------------------------------------------------------------------------------

    public static function state(PDO $pdo, string $zone): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM site_block_zones WHERE zone = ?'); $st->execute([$zone]);
        $z = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        $live = null; $v = (int) ($z['live_version'] ?? 0);
        if ($v) { $st = $pdo->prepare('SELECT tree FROM site_block_versions WHERE zone = ? AND version = ?'); $st->execute([$zone, $v]); $live = json_decode((string) $st->fetchColumn(), true); }
        $draft = $z && $z['draft'] !== null ? json_decode((string) $z['draft'], true) : null;
        return ['zone' => $zone, 'live' => is_array($live) ? self::clean($live) : null, 'live_version' => $v,
                'draft' => is_array($draft) ? self::clean($draft) : null, 'draft_by' => (string) ($z['draft_name'] ?? ''), 'draft_at' => $z['draft_at'] ?? null, 'draft_tz' => (string) ($z['draft_tz'] ?? '')];
    }

    public static function versions(PDO $pdo, string $zone, int $limit = 30): array
    {
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT version, by_name, at, tz, note FROM site_block_versions WHERE zone = ? ORDER BY version DESC LIMIT ' . max(1, min(100, $limit)));
        $st->execute([$zone]);
        return array_map(fn ($r) => ['version' => (int) $r['version'], 'by' => (string) $r['by_name'], 'at' => gmdate('c', (int) strtotime($r['at'] . ' UTC')), 'tz' => (string) $r['tz'], 'note' => (string) $r['note']],
            $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /**
     * A zone on a page. Everyone sees the live version (or the page's own content, $fallback, until one is published).
     * An editor sees the draft when there is one (the preview, marked Draft), with the zone outlined and its Edit button.
     */
    public static function zone(PDO $pdo, string $zone, string $fallback = '', string $label = ''): string
    {
        if (!self::zoneOk($zone)) return $fallback;
        try { $s = self::state($pdo, $zone); } catch (Throwable $e) { error_log('blocks ' . $zone . ': ' . $e->getMessage()); return $fallback; }
        [$edit] = self::can('pages.edit');
        $tree = $edit && $s['draft'] !== null ? $s['draft'] : $s['live'];
        $html = $tree !== null ? self::render($tree) : $fallback;
        if (!$edit) return $html === '' ? '' : self::kit() . '<div class="tvb-zone" data-tvb="' . htmlspecialchars($zone) . '">' . $html . '</div>';
        $e = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES, 'UTF-8');
        $tag = $s['draft'] !== null ? 'Draft: only our team sees this' : ($s['live_version'] ? 'Live, version ' . $s['live_version'] : 'Not published yet');
        $js = '';
        static $once = false;
        if (!$once) { $once = true; $js = '<script src="/js/tv-editor.js?v=' . (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-editor.js') . '" defer></script>'; }
        return self::kit() . '<div class="tvb-zone tvb-edit" data-tvb-zone="' . $e($zone) . '" data-tvb-label="' . $e($label !== '' ? $label : $zone) . '" data-csrf="' . $e($_SESSION['csrf_token'] ?? '') . '">'
            . '<div class="tvb-tag"><span>' . $e($tag) . '</span><button type="button" data-tvb-edit>Edit</button></div>'
            . ($html !== '' ? $html : '<p class="tvb-empty">' . $e($label !== '' ? $label : 'This space') . ' is empty: Edit to add a section. Visitors see nothing here until it\'s published.</p>')
            . '</div>' . $js;
    }

    // ---- changing -----------------------------------------------------------------------------------------------------

    private static function touch(PDO $pdo, string $zone): void
    {
        $pdo->prepare('INSERT IGNORE INTO site_block_zones (zone, updated_at) VALUES (?, UTC_TIMESTAMP())')->execute([$zone]);
    }

    /** Save draft: kept for the team only, on the real page. */
    public static function saveDraft(PDO $pdo, string $zone, $tree, int $uid, string $name, string $tz): string
    {
        self::need('pages.edit');
        if (!self::zoneOk($zone)) throw new RuntimeException('That isn\'t a place for blocks.');
        self::ensure($pdo); self::touch($pdo, $zone);
        $pdo->prepare('UPDATE site_block_zones SET draft = ?, draft_by = ?, draft_name = ?, draft_at = UTC_TIMESTAMP(), draft_tz = ?, updated_at = UTC_TIMESTAMP() WHERE zone = ?')
            ->execute([json_encode(self::clean($tree), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $uid ?: null, mb_substr($name, 0, 100), mb_substr($tz, 0, 64), $zone]);
        return 'Draft saved: only our team sees it, here on the page. Publish puts it live.';
    }

    /** Publish: the draft (or the tree sent) becomes the next version and goes live; the draft is cleared. */
    public static function publish(PDO $pdo, string $zone, $tree, int $uid, string $name, string $tz, string $note = ''): string
    {
        self::need('pages.publish');
        if (!self::zoneOk($zone)) throw new RuntimeException('That isn\'t a place for blocks.');
        self::ensure($pdo);
        $s = self::state($pdo, $zone);
        $t = $tree !== null ? self::clean($tree) : $s['draft'];
        if ($t === null) throw new RuntimeException('Nothing to publish: make a change first.');
        return 'Published: version ' . self::newVersion($pdo, $zone, $t, $uid, $name, $tz, $note) . ' is live.';
    }

    private static function newVersion(PDO $pdo, string $zone, array $tree, int $uid, string $name, string $tz, string $note): int
    {
        self::touch($pdo, $zone);
        $pdo->beginTransaction();
        try {
            $st = $pdo->prepare('SELECT COALESCE(MAX(version), 0) + 1 FROM site_block_versions WHERE zone = ? FOR UPDATE'); $st->execute([$zone]);
            $v = (int) $st->fetchColumn();
            $pdo->prepare('INSERT INTO site_block_versions (zone, version, tree, by_user, by_name, at, tz, note) VALUES (?, ?, ?, ?, ?, UTC_TIMESTAMP(), ?, ?)')
                ->execute([$zone, $v, json_encode($tree, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $uid ?: null, mb_substr($name, 0, 100), mb_substr($tz, 0, 64), mb_substr($note, 0, 200)]);
            $pdo->prepare('UPDATE site_block_zones SET live_version = ?, draft = NULL, draft_by = NULL, draft_name = \'\', draft_at = NULL, updated_at = UTC_TIMESTAMP() WHERE zone = ?')->execute([$v, $zone]);
            $pdo->commit();
        } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        return $v;
    }

    /** Roll back: an earlier version published again, as the next version (the history only grows). */
    public static function rollBack(PDO $pdo, string $zone, int $version, int $uid, string $name, string $tz): string
    {
        self::need('pages.publish');
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT tree FROM site_block_versions WHERE zone = ? AND version = ?'); $st->execute([$zone, $version]);
        $t = json_decode((string) $st->fetchColumn(), true);
        if (!is_array($t)) throw new RuntimeException('That version isn\'t here.');
        $v = self::newVersion($pdo, $zone, self::clean($t), $uid, $name, $tz, 'Rolled back to version ' . $version);
        return 'Rolled back: version ' . $version . ' is live again (as version ' . $v . ').';
    }

    /** Throw the draft away: the page shows what's live again. */
    public static function discard(PDO $pdo, string $zone): string
    {
        self::need('pages.edit');
        self::ensure($pdo);
        $pdo->prepare('UPDATE site_block_zones SET draft = NULL, draft_by = NULL, draft_name = \'\', draft_at = NULL, updated_at = UTC_TIMESTAMP() WHERE zone = ?')->execute([$zone]);
        return 'Draft thrown away: the page shows what\'s live.';
    }
}
