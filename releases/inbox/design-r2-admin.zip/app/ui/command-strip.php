<?php
// app/ui/command-strip.php — the command strip on an admin record page (decisions/0129; Jason, 2026-10-28). One slim line
// at the top of the page in place of its title and breadcrumbs: Back, what the record is, one button for the master
// commands (Save when something's changed, with how many; else Close; ▾ Save, Save and close, Send, Close) and ☰ for
// the record's other actions. It slides away as you scroll down and comes back as you scroll up. Where the record
// stands is not in the strip: it's a notices box under it, shown on page load and closed once read (it comes back when
// something in it changes). Each section keeps its own controls in a bar on its heading (js/tv-strip.js).
//
// tv_command_strip([
//   'title' => 'Order #924',
//   'news' => ['Paid · In production', 'Client opened it Oct 28'], 'news_tone' => 'info', 'news_key' => 'order-924',
//   'send' => ['label' => 'Send the client an update', 'target' => '#co-update-btn'] (or null),
//   'back' => '/admin/backoffice/orders', 'close' => '/admin/backoffice/orders',
//   'more' => [['What the client sees', '/order.php?t=…', 'new'], ['Files', '#docs', ''], ['Cancel the order', '#co-cancel-btn', 'danger']],
//   'menu_html' => '…',       // the page's own controls that belong in ☰ (forms, a Duplicate list), moved there as they are
//   'root' => '.co',          // where the sections are (each starts at an h2.hb-h)
//   'new' => 'form:has(…)',   // forms that make something new: they wait for their own button
//   'skip' => 'form:has(…)',  // forms that aren't edits (a search box): never counted
// ])
declare(strict_types=1);

function tv_command_strip(array $c): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $h = '<div class="cs tv-bleed" id="cs" role="region" aria-label="Commands for this ' . $e($c['noun'] ?? 'record') . '" data-root="' . $e($c['root'] ?? '') . '" data-close="' . $e($c['close'] ?? '')
        . '" data-back="' . $e($c['back'] ?? '') . '" data-new="' . $e($c['new'] ?? '') . '" data-skip="' . $e($c['skip'] ?? '') . '">'
        . '<div class="cs-l"><button type="button" class="cs-b cs-back" data-cs="back" aria-label="Back" title="Back"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg></button>'
        . '<h1 class="cs-t">' . $e($c['title'] ?? '') . '</h1></div>';
    // one button: what it does now (Save when something's changed, else Close), and ▾ for the rest
    $h .= '<div class="cs-r"><div class="cs-split"><button type="button" class="cs-b go cs-main" data-cs="main">Close</button>'
        . '<details class="cs-dd"><summary class="cs-b go cs-caret" aria-label="Save, send or close">&#9662;</summary><div class="cs-menu" role="menu">'
        . '<button type="button" role="menuitem" data-cs="save">Save</button><button type="button" role="menuitem" data-cs="saveclose">Save and close</button><small class="cs-why" data-cs-why></small>'
        . (!empty($c['send']) ? '<button type="button" role="menuitem" data-cs="send" data-target="' . $e($c['send']['target']) . '">' . $e($c['send']['label'] ?? 'Send') . '</button>' : '')
        . implode('', array_map(fn ($x) => '<button type="button" role="menuitem" data-cs="go" data-target="' . $e($x[1]) . '"' . (!empty($x[2]) ? ' class="cs-done"' : '') . '>' . $e($x[0]) . '</button>', (array) ($c['finish'] ?? [])))   // e.g. Complete the order
        . '<button type="button" role="menuitem" data-cs="close">Close</button></div></details></div>';
    if (!empty($c['more']) || !empty($c['menu_html'])) {
        $h .= '<details class="cs-dd cs-ham"><summary class="cs-b" aria-label="More for this ' . $e($c['noun'] ?? 'record') . '" title="More">&#9776;</summary><div class="cs-menu" role="menu">';
        foreach ((array) ($c['more'] ?? []) as $m) {
            [$label, $to] = $m; $how = (string) ($m[2] ?? '');
            $h .= str_starts_with((string) $to, '#')
                ? '<button type="button" role="menuitem" data-cs="go" data-target="' . $e($to) . '"' . ($how === 'danger' ? ' class="no"' : '') . '>' . $e($label) . '</button>'
                : '<a role="menuitem" href="' . $e($to) . '"' . ($how === 'new' ? ' target="_blank" rel="noopener"' : '') . '>' . $e($label) . ($how === 'new' ? ' &#8599;' : '') . '</a>';
        }
        $h .= (string) ($c['menu_html'] ?? '') . '</div></details>';
    }
    $h .= '</div></div>';
    $news = array_values(array_filter(array_map('strval', (array) ($c['news'] ?? []))));
    if ($news) {   // where the record stands: closed once read, back when it changes
        $sig = substr(md5(implode('|', $news)), 0, 12);
        $h .= '<div class="cs-news" data-key="' . $e($c['news_key'] ?? ($c['title'] ?? '')) . '" data-sig="' . $sig . '"><p class="tv-bleed" data-tv-status="' . $e($c['news_tone'] ?? 'info') . '" data-tv-label="' . $e(($c['title'] ?? '') . ':') . '">'
            . implode(' · ', array_map($e, $news)) . '</p></div>';
    }
    static $css = false;
    if (!$css) {
        $css = true;
        $h .= '<style>
          .cs{position:sticky;top:var(--ta-top,56px);z-index:40;display:flex;flex-wrap:nowrap;gap:.5rem;align-items:center;justify-content:space-between;margin:0 0 .5rem;padding:.3rem .45rem;min-height:2.75rem;background:var(--tv-ink);color:var(--tv-card-a);border-radius:.7rem;box-shadow:0 8px 20px -14px rgba(0,0,0,.6);transition:transform .22s ease,opacity .22s ease}
          .cs.cs-away{transform:translateY(calc(-100% - var(--ta-top,56px)));opacity:0;pointer-events:none}
          .cs-l{display:flex;gap:.4rem;align-items:center;min-width:0;flex:1 1 auto}
          .cs-t{font:700 1.02rem var(--tv-font-head);margin:0;color:var(--tv-on-umber);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
          .cs-news{margin:0 0 .5rem}.cs-news[hidden]{display:none}
          .cs-r{display:flex;gap:.35rem;align-items:center;margin-left:auto;flex:0 0 auto}
          .cs-b{font:inherit;font-size:.88rem;font-weight:700;border:1px solid color-mix(in srgb,var(--tv-on-umber) 35%,transparent);background:transparent;color:var(--tv-card-a);border-radius:999px;padding:.34rem .85rem;cursor:pointer;list-style:none;line-height:1.2}
          .cs-b::-webkit-details-marker{display:none}.cs-b.go{background:var(--tv-sage);color:var(--tv-umber);border-color:var(--tv-sage)}.cs-back{font-size:1.3rem;line-height:1;padding:.12rem .62rem}
          .cs-split{display:flex}.cs-split .cs-main{border-radius:999px 0 0 999px;padding-right:.7rem}.cs-split .cs-caret{border-radius:0 999px 999px 0;padding:.34rem .55rem;border-left:1px solid var(--tv-umber)}
          .cs-dd{position:relative}.cs-ham>summary{font-size:1.05rem;padding:.25rem .7rem}
          .cs-menu{position:absolute;right:0;top:calc(100% + .35rem);z-index:41;min-width:15rem;max-width:min(22rem,calc(100vw - 1.5rem));max-height:min(70vh,32rem);overflow:auto;background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:.7rem;box-shadow:0 14px 30px -12px rgba(0,0,0,.45);padding:.3rem;display:grid}
          .cs-menu a,.cs-menu button,.cs-menu summary{display:flex;align-items:center;gap:.35rem;width:100%;text-align:left;font:inherit;font-size:.92rem;font-weight:600;color:var(--tv-ink);background:none;border:0;border-radius:.45rem;padding:.5rem .6rem;text-decoration:none;cursor:pointer;white-space:normal}
          .cs-menu a:hover,.cs-menu button:hover,.cs-menu summary:hover{background:var(--tv-card-b)}.cs-menu .no{color:var(--tv-fail)}.cs-menu button:disabled{opacity:.45;cursor:default}
          .cs-menu form{margin:0;display:block!important}.cs-menu small{display:block;font-size:.78rem;color:var(--tv-meta);font-weight:400;padding:0 .6rem .35rem}
          .cs-menu details>div{position:static!important;box-shadow:none!important;border:0!important;background:none!important;min-width:0!important;width:auto!important;padding:0 0 0 .6rem!important}.cs-menu .hb-b{border:0;background:none;color:var(--tv-ink);justify-content:flex-start}
          .cs-sec{display:inline-flex;gap:.3rem;align-items:center;margin-left:.5rem;vertical-align:middle}.cs-sec button{font:inherit;font-size:.78rem;font-weight:600;border:1px solid var(--tv-line-strong);background:var(--tv-on-umber);color:var(--tv-meta);border-radius:999px;padding:.12rem .55rem;cursor:pointer}
          .cs-sec .cs-dot{width:.55rem;height:.55rem;border-radius:999px;background:var(--tv-hold);display:none}.cs-sec.dirty .cs-dot{display:inline-block}
          .cs-folded{display:none!important}.cs-hide{display:none!important}
          .cs-r .cs-ab{float:none;margin:0}.cs-r .cs-ab>summary{padding:.3rem .7rem;font-size:.86rem}
          @media (max-width:640px){.cs-r .cs-ab>summary span{display:none}.cs-r .cs-ab>summary{padding:.3rem .5rem}}
          @media (max-width:767px){.cs{border-radius:.5rem}.cs-t{font-size:.98rem}.cs-b{padding:.3rem .7rem}}
          /* the admin\'s command header look (design/css-theme-brand.md §1, Release 2; it replaced the sage bar of 2026-11-12):
             one Deep Umber row joined to the site\'s top bar, Back in copper, the record in the heading serif; all from the tokens */
          body:not(.tv-embedded) .cs{top:var(--ak-top,calc(var(--ta-top,56px) + var(--as-h,0px)));margin:-1.1rem calc(-1 * clamp(1rem,3vw,2.5rem)) var(--tv-gap) !important;padding:.45rem clamp(1rem,3vw,2.5rem) .45rem .6rem;min-height:3rem;align-items:center;background:var(--tv-umber);color:var(--tv-on-umber);border-radius:0;border-bottom:1px solid var(--tv-void);box-shadow:var(--tv-shadow)}
          body.tv-embedded .cs{background:var(--tv-umber);color:var(--tv-on-umber);padding:.35rem .5rem;align-items:center;border-radius:var(--tv-r-sm);overflow:visible}
          .cs :focus-visible{outline-color:var(--tv-focus-dark)}
          .cs .cs-l{gap:.6rem}
          .cs .cs-b.cs-back{width:2.1rem;height:2.1rem;padding:0;border:0;border-radius:var(--tv-r-sm);background:var(--tv-copper);color:#fff;display:grid;place-items:center}
          .cs .cs-b.cs-back:hover{background:var(--tv-crimson)}
          h2.cs-h{cursor:pointer;user-select:none}
          .cs-fold{border:0;background:none;padding:0 .4rem 0 0;font:inherit;font-size:.9em;color:var(--tv-link);cursor:pointer;line-height:1;vertical-align:baseline}
          .cs-fold::before{content:"▾";display:inline-block;transition:transform var(--tv-ease)}.cs-fold[aria-expanded=false]::before{transform:rotate(-90deg)}
          .cs .cs-t{color:var(--tv-on-umber);font:700 1.05rem var(--tv-font-head)}
          .cs .cs-r{gap:.4rem}
          .cs .cs-b{border:1px solid var(--tv-on-umber-meta);background:transparent;color:var(--tv-on-umber);border-radius:var(--tv-r-sm);align-self:center;transition:background-color var(--tv-ease),border-color var(--tv-ease)}
          .cs .cs-b:hover{background:var(--tv-umber-line)}
          .cs .cs-b.go{background:var(--tv-copper);border-color:var(--tv-copper);color:#fff}
          .cs .cs-split .cs-main{border-radius:var(--tv-r-sm) 0 0 var(--tv-r-sm)}.cs .cs-split .cs-caret{border-radius:0 var(--tv-r-sm) var(--tv-r-sm) 0;border-left:1px solid color-mix(in srgb,#fff 40%,transparent)}
          .cs .cs-r .cs-ab{align-self:center}.cs .cs-r .cs-ab>summary{background:transparent;border:1px solid var(--tv-on-umber-meta);border-radius:var(--tv-r-sm);color:var(--tv-on-umber);box-shadow:none}
          .cs .cs-r .cs-ab>summary span{display:none}.cs .cs-r .cs-ab>summary::after{content:"▾";color:var(--tv-on-umber-meta);padding:0 .1rem;margin-left:.3rem;font-size:.85em}
          body:not(.tv-back) .ta-body:has(.cs){margin-top:0}
          @media (max-width:767px){body:not(.tv-embedded) .cs{margin:-.8rem calc(-1 * var(--tv-pad,.85rem)) 1rem !important;padding:.4rem .5rem}}
        </style><script src="/js/tv-strip.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/tv-strip.js') . '"></script>' . '<script' . (function_exists('tv_nonce') ? tv_nonce() : '') . '>(function () { var h = document.getElementById("cs"), tb = document.getElementById("top-bar"); if (!h || !tb || document.body.classList.contains("tv-embedded")) return;'
          . ' function fit() { if (window.scrollY > 2) return; h.style.removeProperty("margin-top"); var b = tb.getBoundingClientRect().bottom;'
          . ' [document.getElementById("tv-notice"), document.querySelector("body > .tv-as")].forEach(function (x) { if (x && x.offsetHeight) b = Math.max(b, x.getBoundingClientRect().bottom); });'
          . ' document.documentElement.style.setProperty("--ak-top", Math.round(b) + "px");'   // it sticks right under what's pinned above it, measured (2026-11-18)
          . ' var g = h.getBoundingClientRect().top - b; if (g > 1) h.style.setProperty("margin-top", ((parseFloat(getComputedStyle(h).marginTop) || 0) - g) + "px", "important"); }'
          . ' fit(); window.addEventListener("load", fit); window.addEventListener("resize", fit); })();</script>';
    }
    return $h;
}
