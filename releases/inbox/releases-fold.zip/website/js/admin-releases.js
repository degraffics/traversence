/* js/admin-releases.js — System Configuration → Releases (decisions/0145 Phase 5). The upload (through the one uploader,
 * target release_zip) and each release's buttons: each asks first where it changes the live site (data-confirm), shows
 * its spinner while it works (TvAsk.busy), then the site's notice beside it (TvAsk.say), and the page comes back with the
 * release where it now stands. */
(function () {
  var box = document.getElementById('rel');
  if (!box) return;
  var csrf = box.getAttribute('data-csrf') || '';
  var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}

  function post(body) {
    return fetch('/admin/api/config/releases', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'The server didn\'t answer clearly. Try again; still stuck? Write to support@traversence.com.' } }; }); })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again.'); return j; });
  }
  function say(msg, el, bad) { if (window.TvAsk) TvAsk.say(msg, { anchor: el, bad: !!bad }); }
  function back(id) { setTimeout(function () { location.hash = id ? 'rel-' + id : ''; location.reload(); }, 1600); }

  // the upload
  var up = box.querySelector('[data-rel-upload]'), note = box.querySelector('[data-rel-up-note]');
  if (up && window.TvUpload) {
    TvUpload.bind(up, { target: 'release_zip', ctx: { tz: tz }, el: box, done: function (res) {
      var r = (res && res[0]) || {};
      var ok = r.ok !== false && !r.error;
      var msg = (r.result && r.result.message) || r.message || (r.error && (r.error.message || r.error)) || (ok ? 'Uploaded.' : 'The upload didn\'t go through. Try again.');
      if (note) { note.hidden = false; note.textContent = msg; note.setAttribute('data-tv-status', ok ? 'ok' : 'bad'); }
      say(msg, up.closest('label') || box, !ok);
      if (ok) back((r.result && r.result.id) || r.id);
    } });
  }

  // Open on staging: the release's first page there, as the test account chosen, with the staging bar
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-rel-enter]');
    if (!b || b.disabled) return;
    var id = b.getAttribute('data-rel-enter'), as = document.querySelector('[data-rel-as="' + id + '"]');
    TvAsk.busy(b, true);
    location.href = '/admin/api/config/releases?action=enter&id=' + encodeURIComponent(id) + '&as=' + encodeURIComponent(as ? as.value : '') + '&to=%2F';
    setTimeout(function () { TvAsk.busy(b, false); }, 8000);
  });

  // a release's buttons
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-rel]');
    if (!btn || btn.disabled) return;
    var what = btn.getAttribute('data-rel'), id = +btn.getAttribute('data-id') || 0;
    if (btn.hasAttribute('data-confirm') && !TvAsk.gate(btn, btn.getAttribute('data-confirm'), { yes: btn.getAttribute('data-yes') || 'Yes', danger: btn.hasAttribute('data-danger') })) return;
    var body = { action: what, id: id, args: { tz: tz } };
    if (what === 'approve') {
      var f = document.querySelector('[data-rel-plan="' + id + '"]');
      if (f) f.querySelectorAll('input,textarea,select').forEach(function (x) { body.args[x.name] = x.value; });
    }
    if (what === 'review') {   // a part of the review given here (UI, UX, Functional), as on the staging bar
      body.args.part = btn.getAttribute('data-part'); body.args.ok = btn.getAttribute('data-ok') === '1' ? 1 : 0;
      var n = document.querySelector('[data-rel-note="' + id + ':' + body.args.part + '"]');
      body.args.text = n ? n.value : '';
      if (!body.args.ok && !body.args.text.trim()) { say('Say what needs changing first.', n || btn, true); if (n) n.focus(); return; }
    }
    if (what === 'schedule') {
      var w = document.querySelector('[data-rel-when="' + id + '"]');
      if (!w || !w.value) { say('Choose the date and time first.', w || btn, true); return; }
      body.args.at = w.value;
    }
    if (what === 'settings') {
      var s = {}, form = btn.closest('[data-rel-settings]'), days = [];
      form.querySelectorAll('input').forEach(function (x) { if (x.name === 'days') { if (x.checked) days.push(x.value); } else s[x.name] = x.value; });
      s.days = days; body = { action: 'settings', settings: s };
    }
    var go = function () {
      TvAsk.busy(btn, true);
      post(body).then(function (j) { TvAsk.busy(btn, false); say(j.message || 'Done.', btn); if (what !== 'settings') back(id); },
        function (err) { TvAsk.busy(btn, false); say(err.message, btn, true); });
    };
    if (what === 'urgent') {
      TvAsk.ask('Why can\'t it wait? (recorded with the release)', '').then(function (why) {
        if (!why) return;
        body.args.reason = why; go();
      });
      return;
    }
    go();
  });
})();

// each release folds to one line (Jason, 2026-11-17): open while it needs him, as the page draws it; what he opens or closes
// is remembered per release until its state changes (then the page's default again); a link to #rel-N opens that one and
// goes to it
(function () {
  var folds = document.querySelectorAll('details[data-rel-fold]');
  if (!folds.length) return;
  function key(d) { return 'tv-rel-fold:' + d.getAttribute('data-rel-fold'); }
  Array.prototype.forEach.call(folds, function (d) {
    var st = d.getAttribute('data-rel-state') || '';
    try { var v = localStorage.getItem(key(d)); if (v) { var p = v.split(':'); if (p[0] === st) d.open = p[1] === '1'; else localStorage.removeItem(key(d)); } } catch (x) {}
    d.addEventListener('toggle', function () { if (d._tvHash) { d._tvHash = false; return; } try { localStorage.setItem(key(d), st + ':' + (d.open ? '1' : '0')); } catch (x) {} });
  });
  function toHash() {
    var m = /^#rel-(\d+)$/.exec(location.hash || ''); if (!m) return;
    var d = document.getElementById('rel-' + m[1]); if (!d || d.tagName !== 'DETAILS') return;
    if (!d.open) { d._tvHash = true; d.open = true; }   // opened by a link: not remembered as his choice
    setTimeout(function () { d.scrollIntoView({ block: 'start' }); }, 0);
  }
  toHash();
  window.addEventListener('hashchange', toHash);
})();
