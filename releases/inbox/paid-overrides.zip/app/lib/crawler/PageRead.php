<?php
// app/lib/crawler/PageRead.php — Stage 9's reader (decisions/0164 §2.3, 0163 §8 stage 9; gap review P1-1): the pages
// "waiting to be read" (crawl_pages.pending_at, set when the code-first read stopped short) are read into facts by the AI
// AI use routes page_read to (Gemini's free tier for public pages, through every guard; else Claude, inside the cap). When
// Gemini's allowance, a hold or the cap stops a read, the page simply stays waiting (SourceIndex::waitToRead): the work
// waits, nothing is lost, and its fingerprint isn't trusted until its facts are taken.
// Shipped off: the AI feature page_read is off by default, and the job is under W3 and the master switch.
declare(strict_types=1);

require_once __DIR__ . '/../Database.php';
require_once __DIR__ . '/SourceIndex.php';

final class PageRead
{
    private const SCHEMA = ['type' => 'object', 'properties' => ['places' => ['type' => 'array', 'items' => ['type' => 'object',
        'properties' => ['name' => ['type' => 'string'], 'street' => ['type' => 'string'], 'city' => ['type' => 'string'], 'zip' => ['type' => 'string'], 'phone' => ['type' => 'string'], 'website' => ['type' => 'string']],
        'required' => ['name', 'street', 'city', 'zip', 'phone', 'website'], 'additionalProperties' => false]]], 'required' => ['places'], 'additionalProperties' => false];

    /** Why the reader may not run now, or null. */
    public static function off(PDO $pdo): ?string
    {
        require_once __DIR__ . '/../Automation.php';
        if (($w = Automation::masterOff($pdo)) !== null) return $w;
        if (($w = Automation::wfOff($pdo, 'W3')) !== null) return $w;
        require_once __DIR__ . '/../AiClient.php';
        if (!AiClient::feature($pdo, 'page_read')['enabled']) return 'Reading pages into facts (page_read) is switched off on AI use.';
        return null;
    }

    /** Reads up to $n waiting pages. Returns ['read' => n, 'facts' => n, 'waiting' => n, 'why' => last stop]. */
    public static function tick(PDO $pdo, int $n = 3): array
    {
        $out = ['read' => 0, 'facts' => 0, 'waiting' => SourceIndex::waitingToRead($pdo), 'why' => ''];
        if (($w = self::off($pdo)) !== null) { $out['why'] = $w; return $out; }
        try {
            $rows = $pdo->query('SELECT url, host FROM ' . Database::t('crawl_pages') . ' WHERE pending_at IS NOT NULL ORDER BY pending_at LIMIT ' . max(1, min(20, $n)))->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $x) { $out['why'] = 'The page log isn\'t set up.'; return $out; }
        require_once __DIR__ . '/../AiClient.php'; require_once __DIR__ . '/../Gemini.php'; require_once __DIR__ . '/SiteFetcher.php';
        $onBackup = false;   // Gemini couldn't answer this tick: the rest go to the paid backup while it's usable
        foreach ($rows as $r) {
            $url = (string) $r['url']; $host = (string) $r['host'];
            if (SourceIndex::useRule($pdo, $host) === 'cite') { SourceIndex::waitToRead($pdo, $url); continue; }   // never read in bulk
            try { $pages = (new SiteFetcher(['max_pages' => 1]))->fetchPages([$url])['pages'] ?? []; }   // robots.txt, the pace, held sites
            catch (Throwable $x) { $pages = []; }
            $text = trim((string) ($pages[0]['text'] ?? strip_tags((string) ($pages[0]['html'] ?? ''))));
            if ($text === '') { $out['why'] = 'A page didn\'t load; it waits for the next try.'; continue; }
            [$clean] = Gemini::safe($text, $pdo);
            $clean = mb_substr($clean, 0, 20000);
            $places = null;
            // Gemini's free tier when a director moved page reading there; when Gemini can't answer, Claude only as the paid
            // backup a director switched on, inside its own cap (PaidOverride 'prose'; decisions/0163's source map), each call
            // kept as the backup's on AI use; else the pages wait, nothing lost
            $backup = false;
            if (!$onBackup && AiClient::providerOf($pdo, 'page_read') === 'gemini') {
                $g = Gemini::read($pdo, 'page_read', 'extract_compare', ['page' => $clean]);
                if ($g['ok']) $places = self::lines((string) $g['text']);
                else {
                    require_once __DIR__ . '/../PaidOverride.php';
                    if (!PaidOverride::usable($pdo, 'prose')) { $out['why'] = $g['why']; break; }   // its allowance or a hold: the rest wait too
                    $onBackup = true;
                    error_log('page read: Gemini couldn\'t answer (' . mb_substr((string) $g['why'], 0, 120) . '): Claude, the paid backup by override');
                    $out['backup'] = 'Claude, by override (Gemini: ' . mb_substr((string) $g['why'], 0, 120) . ')';
                }
            }
            if ($places === null) {
                if ($onBackup) { require_once __DIR__ . '/../PaidOverride.php'; if (!PaidOverride::usable($pdo, 'prose')) { $out['why'] = 'Gemini can\'t answer and the paid backup\'s cap for the month is reached.'; break; } $backup = true; }
                [$ok, $why] = AiClient::allow($pdo, 'page_read');
                if (!$ok) { $out['why'] = $why; break; }
                try {
                    $c = AiClient::claudeAsk("Read the public web page below. List each business, organization or public place it names, with its street, city, ZIP, phone and website as the page gives them; leave a field empty when the page doesn't say it. Don't guess.\n\nPAGE:\n" . $clean, self::SCHEMA, 'claude-haiku-5-5', 0, 2048);
                    AiClient::record($pdo, 'page_read', 0, 'done', ['provider' => 'claude', 'model' => 'claude-haiku-5-5', 'in' => (int) ($c['in'] ?? 0), 'out' => (int) ($c['out'] ?? 0), 'micros' => (int) ($c['micros'] ?? 0)], 0, $backup ? 'po:prose' : '');
                    $places = (array) ($c['data']['places'] ?? []);
                } catch (Throwable $x) { $out['why'] = mb_substr($x->getMessage(), 0, 200); break; }
            }
            $facts = [];
            foreach (array_slice((array) $places, 0, 200) as $p) {
                if (!is_array($p) || trim((string) ($p['name'] ?? '')) === '') continue;
                $facts[] = ['url' => $url, 'name' => (string) $p['name'], 'address' => trim((string) ($p['street'] ?? '') . ', ' . (string) ($p['city'] ?? '') . ' ' . (string) ($p['zip'] ?? ''), ', '),
                            'phone' => (string) ($p['phone'] ?? ''), 'website' => (string) ($p['website'] ?? ''), 'read_how' => 'ai'];
            }
            // its facts taken: the page's fingerprint is saved now, and it's no longer waiting
            $fp = sha1((string) preg_replace('/\s+/', ' ', $text));
            SourceIndex::storeMore($pdo, $host, $facts, [['url' => $url, 'status' => 200, 'fingerprint' => $fp, 'via' => 'page_read']], 'page_read');
            SourceIndex::logPages($pdo, $host, [['url' => $url, 'status' => 200, 'fingerprint' => $fp]]);
            $out['read']++; $out['facts'] += count($facts);
        }
        $out['waiting'] = SourceIndex::waitingToRead($pdo);
        return $out;
    }

    /** The AI's JSON lines (or a JSON list) as places. */
    private static function lines(string $t): array
    {
        $t = trim((string) preg_replace('/^```(json)?|```$/m', '', $t));
        $j = json_decode($t, true);
        if (is_array($j)) return array_values(isset($j['places']) ? (array) $j['places'] : $j);
        $out = [];
        foreach (preg_split('/\R/', $t) as $l) { $x = json_decode(trim($l, " ,\t"), true); if (is_array($x)) $out[] = $x; }
        return $out;
    }
}
