<?php

declare(strict_types=1);

/**
 * Paid backups by a director's override (decisions/0163's note "the source map, ours first, a backup for every need",
 * step 3; Jason, 2026-11-17: "we can have an override for this if we need a source and no free ones are available").
 * Each is off until a director sets its cap in System Configuration → Thresholds & gates (0 = off; every change kept
 * there with who and when). It's used only while no free source works for that one need, inside its own cap for the
 * month, each use written to the cost ledger, and it shows on the need's line in the pre-flight.
 */
final class PaidOverride
{
    /** need => [its gate (a monthly cap; 0 = off), the company (OutsideServices), the paid source, the need, what the cap counts]. */
    public const NEEDS = [
        'confirm' => ['po_places_confirm', 'google', 'Google Places', 'Confirm a business (W1\'s second look, W2\'s identity check)', 'checks'],
        'prose' => ['po_claude_prose', 'anthropic', 'Claude', 'Page prose into facts (when Gemini can\'t)', 'dollars'],
    ];
    /** At most this many paid confirmations in one crawler run, so a month's cap is never spent in a burst. */
    private const PER_RUN = 3;

    /** ['on', 'cap', 'used', 'left', 'words'] for this month. */
    public static function state(PDO $pdo, string $need): array
    {
        require_once __DIR__ . '/Thresholds.php';
        $n = self::NEEDS[$need] ?? null;
        if ($n === null) return ['on' => false, 'cap' => 0, 'used' => 0, 'left' => 0, 'words' => 'no such need'];
        $cap = (float) (Thresholds::get($pdo, $n[0]) ?? 0);
        $used = self::used($pdo, $need);
        $left = max(0.0, $cap - $used);
        $fmt = fn (float $v) => $n[4] === 'dollars' ? '$' . number_format($v, 2) : (string) (int) $v;
        $words = $cap <= 0 ? 'off (a director sets its cap in Thresholds & gates to switch it on)'
            : 'on by override: ' . $fmt($used) . ' of ' . $fmt($cap) . ($n[4] === 'dollars' ? '' : ' ' . $n[4]) . ' this month' . ($left <= 0 ? ', the cap is reached' : '');
        return ['on' => $cap > 0, 'cap' => $cap, 'used' => $used, 'left' => $left, 'words' => $words];
    }

    /** Whether it may be used now (on, and inside its cap). */
    public static function usable(PDO $pdo, string $need): bool
    {
        $s = self::state($pdo, $need);
        return $s['on'] && $s['left'] > 0;
    }

    /** This month's use: confirmations counted from the crawler's reports; Claude's dollars from its calls marked as the backup. */
    public static function used(PDO $pdo, string $need): float
    {
        try {
            if ($need === 'prose') {
                require_once __DIR__ . '/Database.php';
                $st = $pdo->prepare('SELECT COALESCE(SUM(cost_micros), 0) FROM ' . Database::t('ai_jobs') . " WHERE charged_to = 'po:prose' AND created_at >= ?");
                $st->execute([date('Y-m-01')]);
                return (int) $st->fetchColumn() / 1e6;
            }
            require_once __DIR__ . '/SearchIndex.php';
            return SearchIndex::state($pdo, 'po:' . $need . ':month') === date('Y-m') ? (float) (int) SearchIndex::state($pdo, 'po:' . $need . ':used') : 0.0;
        } catch (Throwable $x) { return 0.0; }
    }

    /** What the crawler may use this run (its plan's "paid_backups"): {places_confirm: n}; 0 while off or at its cap. */
    public static function runAllowance(PDO $pdo): array
    {
        $s = self::state($pdo, 'confirm');
        return ['places_confirm' => $s['on'] ? (int) min(self::PER_RUN, floor($s['left'])) : 0];
    }

    /** The crawler used some (its run's report): counted for the month and written to the cost ledger. */
    public static function recordRun(PDO $pdo, array $used, ?int $runId): void
    {
        $n = max(0, min(100, (int) ($used['places_confirm'] ?? 0)));
        if ($n <= 0) return;
        require_once __DIR__ . '/SearchIndex.php';
        $m = date('Y-m');
        $was = SearchIndex::state($pdo, 'po:confirm:month') === $m ? (int) SearchIndex::state($pdo, 'po:confirm:used') : 0;
        SearchIndex::setState($pdo, 'po:confirm:month', $m);
        SearchIndex::setState($pdo, 'po:confirm:used', (string) ($was + $n));
        require_once __DIR__ . '/crawler/CrawlService.php';
        CrawlService::cost($pdo, 'google_places', 'W2', 'identity', $n, $runId, 'paid backup by override: confirm a business (second look or identity check)');
    }
}
