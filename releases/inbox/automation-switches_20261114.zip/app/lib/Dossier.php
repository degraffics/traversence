<?php
// app/lib/Dossier.php — a place's dossier, gathered by our crawler for free before Claude writes its guide (decisions/0131,
// Jason 2026-10-30: the crawler gathers, Claude writes, so drafts spend little on web searches). From:
//   Wikipedia   the place's article: its lead, history, geography and culture (CC BY-SA: read for facts, never copied;
//               the article is listed as a source)
//   Wikidata    facts: founded, elevation, population, county seat, its official website (CC0)
//   its own     the town's or county's official website, a few pages, read like the crawler reads a business's site
//   our data    landmarks near it with their Wikipedia summaries, and public outdoor places with their descriptions
// Kept as the place's own data (table place_dossiers, Jason 2026-10-30: saved for future use, never thrown away),
// refreshed every six months; a refresh that finds nothing keeps what's there. The facts (founded, elevation,
// population, official website) are kept apart for other pages. A community's dossier is its towns'. Anything that
// can't be reached is left out, never guessed. Where the law of the place limits copying websites, an official site is
// kept as a pointer unless a person set its rules (mayRead).
declare(strict_types=1);

final class Dossier
{
    public const UA = 'Traversence guides (support@traversence.com; https://traversence.com)';
    private const REFRESH = 180 * 86400;
    private const VERSION = 2;   // dossiers built before dead websites were caught are built again
    private const STATES = ['AZ' => 'Arizona', 'NM' => 'New Mexico', 'UT' => 'Utah', 'CO' => 'Colorado', 'NV' => 'Nevada', 'CA' => 'California', 'TX' => 'Texas'];

    /** @var callable|null for tests: fn(string $url): ?string (the body) */
    public static $fetch = null;

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM place_dossiers LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    /** The place's dossier as text for Claude, and its sources: [text, sources]. Built when there's none or it's six months old. */
    public static function forPlace(PDO $pdo, array $p, bool $fresh = false): array
    {
        $row = self::row($pdo, (string) $p['key']);
        $v = $row ? (int) ((json_decode((string) ($row['facts'] ?? ''), true) ?: [])['v'] ?? 1) : 0;
        if ($fresh || !$row || $v < self::VERSION || strtotime((string) ($row['checked_at'] ?? $row['built_at'] ?? '2000-01-01')) < time() - self::REFRESH) {
            $d = self::build($pdo, $p);
            if (!self::ready($pdo)) return [$d['text'], $d['sources']];
            $had = $row ? (array) (json_decode((string) ($row['facts'] ?? ''), true) ?: []) : [];
            $d['facts']['v'] = self::VERSION;
            if (!$row || $v < self::VERSION || ($d['text'] !== '' && (count($d['facts']) > 1 || !$had))) {   // nothing held yet, or found again: a refresh that can't reach Wikipedia keeps what we hold
                $pdo->prepare('INSERT INTO place_dossiers (place_key, body, sources, facts, built_at, checked_at) VALUES (?, ?, ?, ?, NOW(), NOW())
                               ON DUPLICATE KEY UPDATE body = VALUES(body), sources = VALUES(sources), facts = VALUES(facts), built_at = NOW(), checked_at = NOW()')
                    ->execute([$p['key'], $d['text'], json_encode($d['sources'], JSON_UNESCAPED_SLASHES), json_encode($d['facts'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
            } else $pdo->prepare('UPDATE place_dossiers SET checked_at = NOW() WHERE place_key = ?')->execute([$p['key']]);   // nothing reached this time: what we hold stays
            $row = self::row($pdo, (string) $p['key']) ?: ['body' => $d['text'], 'sources' => json_encode($d['sources'])];
        }
        return [(string) ($row['body'] ?? ''), (array) (json_decode((string) ($row['sources'] ?? ''), true) ?: [])];
    }

    /**
     * The place's research brief (Jason, 2026-10-30: a guide rich with history, culture and the experience of being
     * there): Claude researches the place once, in depth, on the web, and the brief is kept with the place for a year, so
     * every guide written after draws on it. [text, sources]; empty when Claude can't run now and none is held.
     */
    public static function research(PDO $pdo, array $p, string $dossier, bool $fresh = false, bool $spend = true): array
    {
        $row = self::row($pdo, (string) $p['key']);
        $have = $row && trim((string) ($row['research'] ?? '')) !== '';
        if ($have && !$fresh && strtotime((string) ($row['research_at'] ?? '2000-01-01')) > time() - 365 * 86400)
            return [(string) $row['research'], (array) (json_decode((string) ($row['research_sources'] ?? ''), true) ?: [])];
        if (!$spend) return $have ? [(string) $row['research'], (array) (json_decode((string) ($row['research_sources'] ?? ''), true) ?: [])] : ['', []];   // a preview: only what's held
        require_once __DIR__ . '/AiClient.php';
        if (!array_key_exists('research', $row ?: []) && $row !== null) return ['', []];   // the update that keeps briefs hasn't run yet
        if (!AiClient::allow($pdo, 'guide_research')[0]) return $have ? [(string) $row['research'], (array) (json_decode((string) ($row['research_sources'] ?? ''), true) ?: [])] : ['', []];
        $fc = AiClient::feature($pdo, 'guide_research');
        require_once __DIR__ . '/Heritage.php';   // free sources first (decisions/0133, the AI Content Crawler's templates step 3): what the public records already hold
        [$held, $heldN] = Heritage::held($pdo, (string) $p['key']);
        $rich = $heldN >= 8 || mb_strlen($dossier) > 8000;   // enough free material that the web search only fills gaps
        $where = $p['name'] . (!empty($p['state']) ? ', ' . (self::STATES[$p['state']] ?? $p['state']) : '');
        $prompt = "You are the researcher for Traversence, a regional travel guide. Research " . $where . " (" . $p['kind'] . ") in depth on the web and write a research brief our writer will build the guide from. "
            . "Search widely: local and county histories, historical societies, state and national park pages, the city and chamber sites, tribal nations' own public pages, newspapers, event pages, state historic preservation and National Register records.\n\n"
            . "Cover, with specifics (names, dates, places, numbers) and only what your sources support:\n"
            . "1. Before the town: the land and the peoples whose home it was and is (by their own names), the old trails and trade routes.\n"
            . "2. Founding and growth: who came, when and why (Spanish and Mexican-era families, pioneers, ranching, railroad, mining, faith communities), the conflicts and turning points, how it became what it is.\n"
            . "3. Culture today: faith and traditions, food the place is known for, crafts, music, language, the families and institutions that hold it together, what locals are proud of.\n"
            . "4. The year: festivals, rodeos, fairs, feast days and seasons, with the month they happen.\n"
            . "5. The land: rivers, lakes, volcanic fields, forests, wildlife, sky, weather by season, and how people use it (fishing, hunting, hiking, stargazing).\n"
            . "6. Being there: concrete experiences a visitor can have and how they feel (the sounds, smells, views, the pace of a morning on Main Street), and the places that hold the story (buildings, churches, cemeteries open to the public, museums, landmarks) with why each matters.\n"
            . "7. Practical truths a newcomer should know, said with respect for rural life.\n\n"
            . "Write it as a rich, organized brief (headings, paragraphs, lists), 1,500 to 3,000 words, in plain English. Paraphrase; never copy sentences. Give every page you used in sources. Leave out what you can't find a source for. Never locate sacred, burial or ceremonial sites that a nation hasn't made public.\n\n"
            . ($dossier !== '' ? "What our crawler already gathered (start from it, then go further):\n" . mb_substr($dossier, 0, 12000) : '')
            . ($held !== '' ? "\n\nWhat the public records already hold (the Library of Congress's catalog and historic newspapers; use their names, dates and events, citing the record):\n" . $held : '')
            . ($rich ? "\n\nSEARCH ONLY FOR THE GAPS: the material above already covers much of the place's past. Don't search for what it says; spend your searches on what it leaves out: culture today, the year's events with their months, being there, practical truths, and the parts of the story it doesn't reach." : '');
        try {
            $r = AiClient::claudeAsk($prompt, ['type' => 'object', 'additionalProperties' => false, 'required' => ['brief', 'sources'],
                                               'properties' => ['brief' => ['type' => 'string'], 'sources' => ['type' => 'array', 'items' => ['type' => 'string']]]],
                                     $fc['model'], $rich ? max(2, (int) ceil($fc['searches'] / 2)) : max(4, $fc['searches']), 16000, 'high');   // fewer searches when the free sources are rich
            AiClient::record($pdo, 'guide_research', 0, 'done', $r);
        } catch (Throwable $x) { error_log('research ' . $p['key'] . ': ' . $x->getMessage()); return $have ? [(string) $row['research'], []] : ['', []]; }
        $brief = trim((string) ($r['data']['brief'] ?? '')); $src = array_values(array_filter(array_map('strval', (array) ($r['data']['sources'] ?? []))));
        if (mb_strlen($brief) < 400) return $have ? [(string) $row['research'], []] : ['', []];   // too little to keep: what we hold stays
        try {
            $pdo->prepare('INSERT INTO place_dossiers (place_key, research, research_sources, research_at) VALUES (?, ?, ?, NOW())
                           ON DUPLICATE KEY UPDATE research = VALUES(research), research_sources = VALUES(research_sources), research_at = NOW()')
                ->execute([$p['key'], $brief, json_encode($src, JSON_UNESCAPED_SLASHES)]);
        } catch (Throwable $x) { error_log('research keep ' . $p['key'] . ': ' . $x->getMessage()); }
        return [$brief, $src];
    }

    /** The place's facts from Wikidata: founded (year), elevation_ft, population, website, wikipedia, wikidata. Empty when none are held. */
    public static function facts(PDO $pdo, string $key): array
    {
        $row = self::row($pdo, $key);
        return $row ? (array) (json_decode((string) ($row['facts'] ?? ''), true) ?: []) : [];
    }

    /** What the dossier knows now, as a fingerprint (its facts and text) and how old its research is: [hash, research_at or ''] (Guides::maintainTick). */
    public static function stamp(PDO $pdo, string $key): array
    {
        $r = self::row($pdo, $key);
        return $r ? [md5((string) ($r['facts'] ?? '') . '|' . (string) ($r['body'] ?? '')), (string) ($r['research_at'] ?? '')] : ['', ''];
    }

    private static function row(PDO $pdo, string $key): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM place_dossiers WHERE place_key = ?'); $st->execute([$key]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private static function build(PDO $pdo, array $p): array
    {
        require_once __DIR__ . '/Guides.php';
        $parts = []; $sources = []; $facts = [];
        $towns = [$p];   // a community: its towns (the two with the most listings); a town or neighborhood: itself
        if ($p['level'] === 'cluster') {
            $towns = [];
            foreach (array_slice(Guides::children($pdo, $p), 0, 2) as $k) if (str_starts_with($k[0], 'town:') && ($t = Guides::place($pdo, $k[0]))) $towns[] = $t;
            if (!$towns) $towns = [$p];
        } elseif ($p['level'] === 'sub' && !empty($p['parent'])) { $t = Guides::place($pdo, (string) $p['parent']); if ($t) $towns = [$t]; }
        foreach ($towns as $i => $t) {
            [$text, $src, $f] = self::wiki($pdo, $t);
            if ($text !== '') { $parts[] = $text; $sources = array_merge($sources, $src); }
            if ($i === 0 && $t['key'] === $p['key']) $facts = $f;   // a place's own facts, never a town's for its community
        }
        [$ours, $src] = self::ours($pdo, $p);
        if ($ours !== '') { $parts[] = $ours; $sources = array_merge($sources, $src); }
        [$nr, $src] = self::register($p);   // the National Register of Historic Places, from Wikidata (free, CC0)
        if ($nr !== '') { $parts[] = $nr; $sources = array_merge($sources, $src); }
        return ['text' => mb_substr(implode("\n\n", $parts), 0, 22000), 'sources' => array_values(array_unique($sources)), 'facts' => $facts];
    }

    /** Wikipedia's article, Wikidata's facts and the official website, for one town. */
    private static function wiki(PDO $pdo, array $t): array
    {
        $state = self::STATES[$t['state'] ?? ''] ?? '';
        $title = self::findTitle($t, $state);
        if ($title === '') return ['', [], []];
        // Wikipedia is cited, not read (its rule in the source register; Cite only since 2026-11-01): only the article's
        // address and its Wikidata number are asked for, unless the rule is set to keep its facts
        require_once __DIR__ . '/crawler/Sources.php';
        $read = Sources::mayStore($pdo, 'wikipedia.org');
        $j = self::json('https://en.wikipedia.org/w/api.php?' . http_build_query(['action' => 'query', 'format' => 'json', 'redirects' => 1, 'prop' => $read ? 'extracts|pageprops|info' : 'pageprops|info', 'inprop' => 'url',
                                                                               'explaintext' => 1, 'exsectionformat' => 'wiki', 'titles' => $title]));
        $page = $j ? current((array) ($j['query']['pages'] ?? [])) : null;
        if (!$page || isset($page['missing'])) return ['', [], []];
        $out = []; $src = [(string) ($page['fullurl'] ?? 'https://en.wikipedia.org/wiki/' . rawurlencode(str_replace(' ', '_', $title)))]; $f = ['wikipedia' => $src[0]];
        // the lead, then the sections that tell a place's story; the lists at the end are left out
        $secs = preg_split('/^==\s*([^=].*?)\s*==\s*$/m', (string) ($page['extract'] ?? ''), -1, PREG_SPLIT_DELIM_CAPTURE);
        $text = 'WIKIPEDIA, ' . $page['title'] . ":\n" . mb_substr(trim((string) $secs[0]), 0, 1800);
        for ($i = 1; $i + 1 < count($secs); $i += 2) {
            $h = trim($secs[$i]);
            if (!preg_match('/history|geograph|culture|attraction|economy|arts|recreation|tourism|climate|education|transport|landmark|notable place|parks/i', $h)) continue;
            $body = trim((string) preg_replace('/^===.*?===\s*$/m', '', $secs[$i + 1]));
            if ($body !== '') $text .= "\n\n" . $h . ":\n" . mb_substr($body, 0, preg_match('/history/i', $h) ? 6000 : 1500);
        }
        if ($read) $out[] = $text;
        $qid = (string) ($page['pageprops']['wikibase_item'] ?? '');
        if ($qid !== '' && ($w = self::json('https://www.wikidata.org/w/api.php?' . http_build_query(['action' => 'wbgetentities', 'format' => 'json', 'ids' => $qid, 'props' => 'claims'])))) {
            $c = (array) ($w['entities'][$qid]['claims'] ?? []);
            $val = fn (string $pid) => $c[$pid][0]['mainsnak']['datavalue']['value'] ?? null;
            $facts = [];
            if (($v = $val('P571')) && preg_match('/^\+?(\d{4})/', (string) ($v['time'] ?? ''), $y)) { $facts[] = 'founded ' . $y[1]; $f['founded'] = (int) $y[1]; }
            if ($v = $val('P2044')) { $amt = (float) ($v['amount'] ?? 0); $f['elevation_ft'] = (int) round(str_ends_with((string) ($v['unit'] ?? ''), 'Q3710') ? $amt : $amt * 3.28084); $facts[] = 'elevation ' . $f['elevation_ft'] . ' ft'; }
            if (!empty($c['P1082'])) { $last = end($c['P1082']); $f['population'] = (int) ltrim((string) ($last['mainsnak']['datavalue']['value']['amount'] ?? '0'), '+'); if ($f['population'] > 0) $facts[] = 'population ' . $f['population']; else unset($f['population']); }
            // its official website: Wikidata's (preferred first, never a deprecated one), our own listing of the city or town,
            // then the usual government addresses; the first that's alive and names the place. A dead one (suspended, parked,
            // for sale) is never read and never mentioned (Jason, 2026-10-30: Wikidata still gave St. Johns's old sjaz.us).
            $cands = [];
            foreach ((array) ($c['P856'] ?? []) as $cl) { $u = (string) ($cl['mainsnak']['datavalue']['value'] ?? ''); $rank = (string) ($cl['rank'] ?? 'normal'); if ($u !== '' && $rank !== 'deprecated') $cands[$rank === 'preferred' ? 0 : count($cands) + 1] = $u; }
            ksort($cands);
            [$site, $dead] = self::liveSite($pdo, $t, array_values($cands));
            if ($site !== '') $f['website'] = $site;
            if ($dead) $f['dead_sites'] = $dead;
            $f['wikidata'] = $qid;
            if ($facts) $out[] = 'WIKIDATA FACTS (' . $t['name'] . '): ' . implode('; ', $facts);
            $src[] = 'https://www.wikidata.org/wiki/' . $qid;
            if ($site !== '' && self::mayRead($pdo, $site, (string) ($t['state'] ?? '')) && ($o = self::official($site))) { $out[] = 'OFFICIAL WEBSITE, CURRENT (' . $site . "):\n" . $o; $src[] = $site; }
            elseif ($site !== '') $src[] = $site;   // the law of the place limits copying websites: a pointer only
        }
        return [implode("\n\n", $out), $src, $f];
    }

    /** The article's title: "Town, State" if it's there, else the nearest article named like the place. */
    private static function findTitle(array $t, string $state): string
    {
        $name = (string) $t['name'];
        foreach (array_unique(array_filter([$state ? $name . ', ' . $state : '', $state ? str_replace('St. ', 'Saint ', $name) . ', ' . $state : ''])) as $try) {
            $j = self::json('https://en.wikipedia.org/w/api.php?' . http_build_query(['action' => 'query', 'format' => 'json', 'redirects' => 1, 'titles' => $try]));
            $pg = $j ? current((array) ($j['query']['pages'] ?? [])) : null;
            if ($pg && !isset($pg['missing']) && isset($pg['title'])) return (string) $pg['title'];
        }
        if (($t['lat'] ?? null) === null) return '';
        $j = self::json('https://en.wikipedia.org/w/api.php?' . http_build_query(['action' => 'query', 'format' => 'json', 'list' => 'geosearch', 'gscoord' => $t['lat'] . '|' . $t['lon'], 'gsradius' => 10000, 'gslimit' => 20]));
        $norm = fn ($s) => (string) preg_replace('/[^a-z]/', '', strtolower(str_replace(['St. ', 'Saint '], 'saint ', (string) $s)));
        foreach ((array) ($j['query']['geosearch'] ?? []) as $g) if ($norm(explode(',', (string) $g['title'])[0]) === $norm($name)) return (string) $g['title'];
        return '';
    }

    /**
     * May the dossier keep what an official website says (decisions/0133, the source register reads the jurisdiction
     * register)? Where the law of the place limits reading or copying websites (a 'scraping' law), only when a person has
     * set that site's rules to keep its facts (Insights → Sources); otherwise the site is kept as a pointer only.
     */
    private static function mayRead(PDO $pdo, string $url, string $state): bool
    {
        try {
            require_once __DIR__ . '/Jurisdictions.php';
            if (!Jurisdictions::limitsReading($pdo, $state)) return true;
            require_once __DIR__ . '/crawler/Sources.php';
            $host = Sources::host($url); $r = Sources::rules($pdo, $host);
            return $r['from'] === 'set' && Sources::mayStore($pdo, $host);
        } catch (Throwable $e) { return false; }   // can't tell: the stricter reading
    }

    /** A few pages of an official website, as plain text (its home page and pages about visiting, history, parks or events). */
    /** A page's words, as our crawler reads it (for checking what a source publishes); empty when it's dead or can't be read. */
    public static function pageText(string $url): string
    {
        if (!preg_match('#^https?://#i', $url)) return '';
        $b = self::get($url, 10);
        return $b === null || self::dead($b) ? '' : mb_substr(self::plain($b), 0, 60000);
    }

    /**
     * A site's event and calendar pages (Live events: free sources first): its home page, then up to $max of its own pages
     * whose link or address says events, calendar, festival or what's happening, read as text. Where the law of the place
     * limits reading websites, only a site whose rules a person set is read. [[url, text]].
     */
    public static function eventPages(PDO $pdo, string $site, string $state, int $max = 3): array
    {
        if (!preg_match('#^https?://#i', $site) || !self::mayRead($pdo, $site, $state)) return [];
        $home = self::get($site, 10);
        if ($home === null || self::dead($home)) return [];
        $host = strtolower((string) parse_url($site, PHP_URL_HOST)); $out = []; $seen = [];
        preg_match_all('#<a\s[^>]*href=["\']([^"\'\#]+)["\'][^>]*>(.*?)</a>#is', $home, $m, PREG_SET_ORDER);
        foreach ($m as [, $href, $label]) {
            $u = preg_match('#^https?://#i', $href) ? $href : (str_starts_with($href, '/') ? rtrim(preg_replace('#^(https?://[^/]+).*$#i', '$1', $site), '/') . $href : '');
            if ($u === '' || strtolower((string) parse_url($u, PHP_URL_HOST)) !== $host || isset($seen[$u])) continue;
            if (!preg_match('/event|calendar|festival|happening|things-?to-?do|rodeo|fair\b|parade|celebrat/i', $u . ' ' . strip_tags($label))) continue;
            $seen[$u] = true;
            $t = self::pageText($u);
            if (mb_strlen($t) > 200) $out[] = [$u, mb_substr($t, 0, 12000)];
            if (count($out) >= $max) break;
        }
        if (!$out && preg_match('/event|calendar|festival/i', self::plain($home))) $out[] = [$site, mb_substr(self::plain($home), 0, 8000)];   // the home page itself lists them
        return $out;
    }

    /** A page that isn't the place's site any more    /** A page that isn't the place's site any more: suspended, parked, for sale, a host's default page, or next to nothing. */
    public static function dead(string $html): bool
    {
        if (preg_match('#suspendedpage|/cgi-sys/|parkingcrew|sedoparking|bodis\.com|domain-?for-?sale|hugedomains|dan\.com#i', $html)) return true;
        $t = self::plain($html);
        return mb_strlen($t) < 150 || (bool) preg_match('/\b(account|site|website|domain|page)\s+(has\s+been\s+|is\s+(currently\s+)?)?(suspended|disabled|expired|deactivated)\b|this domain (is|may be) for sale|buy this domain|domain (is )?parked|parked free|default (web )?page|future home of|index of \//i', $t);
    }

    /** The first candidate that answers with a live page naming the place, else one of our listing's or the usual government addresses: [url, dead ones]. */
    private static function liveSite(PDO $pdo, array $t, array $cands): array
    {
        $name = (string) $t['name']; $st = strtolower((string) ($t['state'] ?? ''));
        try {   // our own listing of the city or town
            $q = $pdo->prepare("SELECT m.meta_value FROM entities e JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'website' WHERE e.is_suppressed = 0 AND e.name IN (?, ?, ?, ?) LIMIT 3");
            $q->execute(['City of ' . $name, 'Town of ' . $name, $name . ' City Hall', $name . ' Town Hall']);
            foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $v) { $v = trim((string) json_decode((string) $v, true) ?: (string) $v, '" '); if ($v !== '') $cands[] = $v; }
        } catch (Throwable) {}
        $slug = (string) preg_replace('/[^a-z]/', '', strtolower(str_replace(['St. ', 'Saint '], 'st', $name)));
        if ($slug !== '' && $st !== '') foreach (["https://www.{$slug}{$st}.gov", "https://{$slug}{$st}.gov", "https://www.cityof{$slug}.org", "https://www.townof{$slug}.org"] as $g) $cands[] = $g;
        $norm = fn ($x) => (string) preg_replace('/[^a-z]/', '', strtolower(str_replace(['St. ', 'Saint '], 'st', (string) $x)));
        $dead = []; $seen = [];
        foreach ($cands as $u) {
            $u = preg_match('#^https?://#i', $u) ? $u : 'https://' . $u; $host = (string) parse_url($u, PHP_URL_HOST);
            if ($host === '' || isset($seen[$host])) continue; $seen[$host] = true;
            $b = self::get($u, 8);
            if ($b === null) continue;   // no answer: a guessed address that isn't there
            if (self::dead($b)) { $dead[] = $u; continue; }
            if (!str_contains($norm(self::plain($b)), $norm($name))) continue;   // a live page about something else
            return [$u, $dead];
        }
        return ['', $dead];
    }

    private static function official(string $site): string
    {
        if (self::$fetch) { $b = (self::$fetch)($site); return $b && !self::dead($b) ? mb_substr(self::plain($b), 0, 3000) : ''; }
        require_once __DIR__ . '/crawler/SiteFetcher.php';
        try { $pages = (new SiteFetcher(['max_pages' => 4]))->fetch(SiteFetcher::normalizeStartUrl($site))['pages'] ?? []; } catch (Throwable $e) { error_log('dossier site ' . $site . ': ' . $e->getMessage()); return ''; }
        usort($pages, fn ($a, $b) => (int) !preg_match('/visit|histor|park|event|tour|recreat|about/i', $a['url']) <=> (int) !preg_match('/visit|histor|park|event|tour|recreat|about/i', $b['url']));
        $out = '';
        foreach ($pages as $pg) { if (self::dead((string) $pg['html'])) continue; $t = self::plain((string) $pg['html']); if ($t !== '') $out .= "\n[" . $pg['url'] . "]\n" . mb_substr($t, 0, 1200); if (mb_strlen($out) > 3500) break; }
        return trim($out);
    }

    /** What we already hold near the place: landmarks with their summaries, public outdoor places with theirs. */
    private static function ours(PDO $pdo, array $p): array
    {
        if ($p['lat'] === null) return ['', []];
        require_once __DIR__ . '/Guides.php';
        $lines = []; $src = [];
        foreach (Guides::landmarks($pdo, $p, 10) as $l) {
            $d = trim((string) ($l['wd_desc'] ?? ''));
            try { $x = (string) $pdo->query('SELECT extract FROM landmarks WHERE gnis_id = ' . (int) $l['gnis_id'])->fetchColumn(); } catch (Throwable) { $x = ''; }
            if ($d === '' && $x === '') continue;
            $lines[] = '- ' . $l['name'] . ' (' . ($l['fclass'] ?? '') . ', ' . round((float) $l['miles']) . ' mi): ' . trim($d . ($x !== '' ? '. ' . mb_substr($x, 0, 400) : ''));
        }
        if (is_file(__DIR__ . '/crawler/RecBulk.php')) {
            require_once __DIR__ . '/crawler/RecBulk.php';
            try { foreach (RecBulk::near($pdo, [[$p['lat'], $p['lon']]], 30, 8) as $r) if (trim(strip_tags((string) ($r['summary'] ?? ''))) !== '') { $lines[] = '- ' . $r['name'] . ' (' . ($r['type'] ?? '') . '): ' . mb_substr(trim(strip_tags((string) $r['summary'])), 0, 400); if (!empty($r['url'])) $src[] = (string) $r['url']; } } catch (Throwable) {}
        }
        return [$lines ? "LANDMARKS AND OUTDOOR PLACES WE HOLD NEARBY:\n" . implode("\n", $lines) : '', $src];
    }

    /**
     * Places near it on the National Register of Historic Places (NRHP), from Wikidata (CC0): name, reference number, the
     * year listed and its description, with the nomination's page at the National Park Service. Never their coordinates;
     * a site whose location the Register restricts has none on Wikidata, so it isn't found. [text, sources].
     */
    private static function register(array $p): array
    {
        if ($p['lat'] === null) return ['', []];
        $km = in_array($p['level'] ?? '', ['town', 'sub'], true) ? 8 : 25;
        $q = 'SELECT ?item ?itemLabel ?ref ?desc (YEAR(MIN(?start)) AS ?listed) WHERE {'
           . ' SERVICE wikibase:around { ?item wdt:P625 ?loc . bd:serviceParam wikibase:center "Point(' . (float) $p['lon'] . ' ' . (float) $p['lat'] . ')"^^geo:wktLiteral . bd:serviceParam wikibase:radius "' . $km . '" . }'
           . ' ?item wdt:P649 ?ref .'
           . ' OPTIONAL { ?item p:P1435 ?h . ?h ps:P1435 wd:Q19558910 . OPTIONAL { ?h pq:P580 ?start } }'
           . ' OPTIONAL { ?item schema:description ?desc . FILTER(LANG(?desc) = "en") }'
           . ' SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . } }'
           . ' GROUP BY ?item ?itemLabel ?ref ?desc LIMIT 30';
        $j = self::json('https://query.wikidata.org/sparql?' . http_build_query(['format' => 'json', 'query' => $q]));
        $lines = []; $src = [];
        foreach ((array) ($j['results']['bindings'] ?? []) as $b) {
            $name = trim((string) ($b['itemLabel']['value'] ?? '')); $ref = trim((string) ($b['ref']['value'] ?? ''));
            if ($name === '' || $ref === '' || preg_match('/^Q\d+$/', $name)) continue;   // no English name
            $year = (int) ($b['listed']['value'] ?? 0); $desc = trim((string) ($b['desc']['value'] ?? ''));
            $lines[$ref] = '- ' . $name . ' (National Register ' . $ref . ($year ? ', listed ' . $year : '') . ')' . ($desc !== '' ? ': ' . mb_substr($desc, 0, 200) : '');
            $src[] = 'https://npgallery.nps.gov/AssetDetail/NRIS/' . rawurlencode($ref);
        }
        if (!$lines) return ['', []];
        return ["THE NATIONAL REGISTER OF HISTORIC PLACES, places listed here:\n" . implode("\n", array_slice($lines, 0, 25)), array_slice(array_values(array_unique($src)), 0, 10)];
    }

    private static function plain(string $html): string
    {
        $html = (string) preg_replace('#<(script|style|nav|header|footer|noscript)[^>]*>.*?</\1>#si', ' ', $html);
        return trim((string) preg_replace('/\s+/', ' ', html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
    }

    private static function json(string $url): ?array
    {
        $body = self::get($url);
        $j = $body !== null ? json_decode($body, true) : null;
        return is_array($j) ? $j : null;
    }

    private static function get(string $url, int $timeout = 12): ?string
    {
        if (self::$fetch) return (self::$fetch)($url);
        if (!function_exists('curl_init')) return null;
        require_once __DIR__ . '/Automation.php';
        if (Automation::gatheringUrl(null, $url) !== null) return null;   // paused (System Configuration → Automation): not asked
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_FOLLOWLOCATION => true, CURLOPT_ENCODING => '', CURLOPT_USERAGENT => self::UA]);
        $b = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if (!is_string($b) || $code >= 400) { if ($code >= 500 || $code === 0) error_log('dossier: ' . $code . ' ' . $url); return null; }
        return $b;
    }
}
