<?php
// app/lib/Automation.php — the switches over everything the site and the crawler gather and create (Jason, 2026-11-14:
// "Please update the site settings to be off until switched back on, also give me a master switch to turn on and off.
// Also I see the services as routed services connected to a task so we should be able to turn those on and off as
// well."). System Configuration → Automation; decisions/0163 §9.
//
// Four layers, one rule: a call happens only when every switch above it is on.
//   1. The master switch (automation_switches, master/all): off stops every workflow that gathers or creates content:
//      the crawler's plan says paused (CrawlQueue::paused(), so a Railway run ends at once even if its schedule comes
//      back), the site's workflow jobs (JOBS) skip, the AI features that serve them (CrawlService::FEATURE_WF) skip, and
//      their outside calls (OpenStreetMap, Wikipedia, openrouteservice, the second tier's page reads…) aren't made.
//      It never stops business operations: orders, billing, payments, email, releases, staging, Moments, members' own
//      actions (a card scan, Write it for me), staff pressing a button in the admin, guides' weather and roads.
//   2. A workflow (crawl_workflows.paused, W1–W13): its capture tasks, its scheduled jobs, its AI features and its
//      on-demand paths (W5's guides for a visitor, W9's places) stop.
//   3. A capture task (crawl_capture_tasks.enabled): the crawler's plan leaves it out.
//   4. A service (automation_switches, service/<key>): a person pauses an outside service; every caller asks first: the
//      crawler (its hosts are sent as holds, so the worker never calls them), the site's own callers (ServiceHealth::
//      allowed(), the gathering calls below), and the AI providers (AiClient). A route is a task's use of a service, as
//      AiClient::ROUTES maps an AI feature to its providers: pausing the service closes every route to it.
// A paused thing is "paused", never a failure, and never raises a Pulse warning. Each switch keeps who set it, when and why.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Automation
{
    /** The thirteen workflows (decisions/0160 §3): wf => [name, what it makes, where it runs]. Seeded into crawl_workflows. */
    public const WORKFLOWS = [
        'W1' => ['Listings', 'Businesses and organizations found, checked and published as listings.', 'crawler and site'],
        'W2' => ['Keeping listings current', 'Live listings rechecked: websites, who they are, map points, Google.', 'crawler'],
        'W3' => ['Sources and the place store', 'The source register: sites we read regularly, and what they name.', 'crawler and site'],
        'W4' => ['Place guides', 'Research briefs, guide drafts, names in guides, guide fixes.', 'site'],
        'W5' => ['Guides on demand', 'A first look at a place a visitor searched, then its full guide.', 'site'],
        'W6' => ['Heritage and topics', 'The heritage catalog, topic summaries and topic research.', 'crawler and site'],
        'W7' => ['Suggested journeys', 'Each live guide\'s journeys, with travel times from openrouteservice.', 'site'],
        'W8' => ['Find it', 'Places a guide, journey or story names that we don\'t have yet.', 'site'],
        'W9' => ['Landmarks and places on demand', 'Landmarks, their photos, places opened or searched that we don\'t hold, their descriptions.', 'crawler and site'],
        'W10' => ['Live events', 'Upcoming events for places with a live guide.', 'site'],
        'W11' => ['How-to guides', 'Official pages read into how-to guides.', 'crawler'],
        'W12' => ['Search learning', 'What people search, learned; gaps queued for the crawler.', 'crawler'],
        'W13' => ['Stories', 'Person-written only: no crawler. Its named places go to Find it (W8).', 'people'],
    ];

    /** The site's scheduled jobs that gather or create content: job => its workflows. A job skips when the master is
     *  off, or when every one of its workflows is paused (one that's on still runs its part; the rest stop at their AI
     *  features and calls). */
    public const JOBS = [
        'guide_finds_tick' => ['W4', 'W8', 'W10'],
        'guide_ondemand_tick' => ['W5'],
        'journeys_tick' => ['W7'],
        'heritage_tick' => ['W6'],
        'listings_tick' => ['W1'],
        'landmark_photos_tick' => ['W9'],
    ];

    /** AI features a person presses for themselves (a staff member in the admin, a member, a business): the master and
     *  workflow switches don't stop them (decisions/0133: AI acts on a person's words only when called); the service
     *  switch and AI use's own switch do. Every other feature in CrawlService::FEATURE_WF is a workflow's. */
    public const PERSON_FEATURES = ['guide_draft', 'fact_check', 'topic_assist', 'item_write', 'card', 'brochure', 'photo_product', 'menu'];

    /** AI providers (AiClient::PROVIDERS) => their outside service (OutsideServices::COMPANIES). */
    public const PROVIDER_SERVICE = ['claude' => 'anthropic', 'google' => 'google', 'aws' => 'aws'];

    /**
     * Services whose calls are business operations: not paused from here, so the master's promise holds (they're on the
     * page, greyed, with the reason). service => what depends on it.
     */
    public const NOT_PAUSABLE = [
        'bluehost' => 'the site itself, its jobs and its own email',
        'quickbooks' => 'invoices, card payments and refunds',
        'stripe' => 'Marketplace card checkout',
        'square' => 'Marketplace card checkout',
        'aws' => 'email (SES) and files (S3); Textract\'s scans stop with the second tier\'s switch in AI use',
        'cloudflare' => 'file storage and the sign-in captcha',
        'github' => 'releases and the 3-way sync',
        'microsoft' => 'sign-in and OneDrive',
        'apple' => 'sign-in',
        'meta' => 'sign-in',
        'namecom' => 'businesses\' domains',
        'fly' => 'businesses\' own domains on their storefronts',
        'railway' => 'it runs the crawler: its schedule is set on Railway, and while the master is off each run ends at once',
        'onepassword' => 'staff logins',
        'nws' => 'guides\' weather',
        'az511' => 'guides\' road work',
        'tailwind' => 'page styles',
        'vimeo' => 'members\' videos',
        'dbip' => 'the sign-up region check',
        'cpsc' => 'the Marketplace\'s recall check',
        'census' => 'map points for addresses people enter; the crawler\'s geocode task has its own switch',
    ];

    /** The release's seed (migration 2026-11-14_automation_switches): what the master says before anyone changes it. */
    public const SEED_WHY = 'Paused by Jason, 2026-11-14, until the crawler review';

    private static ?array $rows = null;
    private static ?array $wfs = null;

    /** Reads the switches once a request (and again after a change). Before the database update: the master is off. */
    private static function rows(?PDO $pdo): array
    {
        if (self::$rows !== null) return self::$rows;
        self::$rows = [];
        try {
            $pdo = $pdo ?? Database::connection();
            foreach ($pdo->query('SELECT s.*, u.display_name AS by_user FROM automation_switches s LEFT JOIN users u ON u.id = s.by_uid')->fetchAll(PDO::FETCH_ASSOC) as $r) self::$rows[$r['kind'] . ':' . $r['ref']] = $r;
        } catch (Throwable $e) {
            try { foreach (($pdo ?? Database::connection())->query('SELECT * FROM automation_switches')->fetchAll(PDO::FETCH_ASSOC) as $r) self::$rows[$r['kind'] . ':' . $r['ref']] = $r; }
            catch (Throwable $e2) { self::$rows = ['master:all' => ['kind' => 'master', 'ref' => 'all', 'paused' => 1, 'why' => self::SEED_WHY . ' (the switches\' database update hasn\'t run yet)', 'by_name' => 'Jason', 'at' => null, '_missing' => 1]]; }
        }
        return self::$rows;
    }

    public static function ready(?PDO $pdo = null): bool { return !isset(self::rows($pdo)['master:all']['_missing']); }

    public static function forget(): void { self::$rows = null; self::$wfs = null; }

    /** Who set a switch, for its line ("Jason"); '' when no one is named. */
    public static function by(array $r): string
    {
        return trim((string) (($r['by_user'] ?? '') !== '' ? $r['by_user'] : ($r['by_name'] ?? '')));
    }

    /** A stored UTC time, labeled ("Nov 14, 4:05 PM UTC"). */
    public static function fmt(?string $utc): string
    {
        if (!$utc) return '';
        $ts = strtotime($utc . ' UTC');
        return $ts ? gmdate('M j, g:i A', $ts) . ' UTC' : (string) $utc;
    }

    /** "why (set by Jason, Nov 14, 4:05 PM UTC)": a switch's reason and who set it, for every line that names it. */
    public static function line(array $r, string $fallback): string
    {
        $why = trim((string) ($r['why'] ?? '')) !== '' ? trim((string) $r['why']) : $fallback;
        $by = self::by($r); $at = self::fmt($r['at'] ?? null);
        return $why . ($by !== '' || $at !== '' ? ' (set' . ($by !== '' ? ' by ' . $by : '') . ($at !== '' ? ', ' . $at : '') . ')' : '');
    }

    // ---- the four layers -----------------------------------------------------------------------------------------------

    /** The master switch: null when it's on, else the row (why, who, when). */
    public static function master(?PDO $pdo = null): ?array
    {
        $r = self::rows($pdo)['master:all'] ?? null;
        return $r && (int) $r['paused'] ? $r : null;
    }

    /** The master switch's row, on or off (who last set it, when, why). */
    public static function masterRow(?PDO $pdo = null): ?array { return self::rows($pdo)['master:all'] ?? null; }

    /** Why automation is paused, or null when it's on. */
    public static function masterOff(?PDO $pdo = null): ?string
    {
        $m = self::master($pdo);
        return $m ? 'Automation is paused: ' . self::line($m, 'paused') . '.' : null;
    }

    /** The workflows' rows (crawl_workflows), read once a request. */
    public static function workflows(?PDO $pdo = null): array
    {
        if (self::$wfs !== null) return self::$wfs;
        self::$wfs = [];
        try {
            $pdo = $pdo ?? Database::connection();
            try { $rows = $pdo->query('SELECT w.*, u.display_name AS by_user FROM crawl_workflows w LEFT JOIN users u ON u.id = w.paused_by')->fetchAll(PDO::FETCH_ASSOC); }
            catch (Throwable $e) { $rows = $pdo->query('SELECT * FROM crawl_workflows')->fetchAll(PDO::FETCH_ASSOC); }
            foreach ($rows as $r) self::$wfs[(string) $r['wf']] = $r;
        } catch (Throwable $e) {}
        return self::$wfs;
    }

    /** Why a workflow is paused, or null when it runs. */
    public static function wfOff(?PDO $pdo, string $wf): ?string
    {
        $r = self::workflows($pdo)[$wf] ?? null;
        if (!$r || !(int) $r['paused']) return null;
        return $wf . ' ' . (string) ($r['name'] ?? self::WORKFLOWS[$wf][0] ?? '') . ' is paused: ' . self::line(['why' => $r['paused_why'] ?? '', 'by_user' => $r['by_user'] ?? '', 'at' => null], 'paused')
            . (!empty($r['paused_at']) ? ' since ' . date('M j', (int) strtotime((string) $r['paused_at'])) : '') . '.';
    }

    /** A service's pause: null when it may be called, else the row. */
    public static function service(?PDO $pdo, string $svc): ?array
    {
        $r = self::rows($pdo)['service:' . $svc] ?? null;
        return $r && (int) $r['paused'] ? $r : null;
    }

    /** Why a service is paused ("Paused by Jason …"), or null. A status like ServiceHealth's: never a failure. */
    public static function serviceOff(?PDO $pdo, string $svc): ?string
    {
        if ($svc === '' || isset(self::NOT_PAUSABLE[$svc])) return null;
        $r = self::service($pdo, $svc);
        if (!$r) return null;
        require_once __DIR__ . '/OutsideServices.php';
        return (OutsideServices::COMPANIES[$svc][0] ?? $svc) . ' is paused: ' . self::line($r, 'paused by a person') . '.';
    }

    /** The service a host belongs to (its card's hosts, or a server on one of its lists). */
    public static function serviceOfHost(?PDO $pdo, string $host): string
    {
        require_once __DIR__ . '/ServiceHealth.php';
        try { return ServiceHealth::serviceOf($pdo ?? Database::connection(), strtolower($host)); } catch (Throwable $e) { require_once __DIR__ . '/OutsideServices.php'; return OutsideServices::serviceOfHost($host); }
    }

    /** Why a host may not be called now because its service is paused, or null. */
    public static function hostOff(?PDO $pdo, string $host): ?string
    {
        return self::serviceOff($pdo, self::serviceOfHost($pdo, $host));
    }

    /** Every host of every paused service: host => why (the crawler's plan sends them as holds; the worker never calls them). */
    public static function pausedHosts(?PDO $pdo = null): array
    {
        $out = [];
        require_once __DIR__ . '/OutsideServices.php';
        foreach (self::rows($pdo) as $r) {
            if (($r['kind'] ?? '') !== 'service' || !(int) $r['paused'] || isset(self::NOT_PAUSABLE[$r['ref']])) continue;
            $svc = (string) $r['ref'];
            $why = 'Paused by a person (' . self::line($r, 'paused') . ')';
            foreach (OutsideServices::HOSTS[$svc] ?? [] as $h) $out[$h] = $why;
            try { foreach (($pdo ?? Database::connection())->query('SELECT url FROM service_servers WHERE service = ' . ($pdo ?? Database::connection())->quote($svc))->fetchAll(PDO::FETCH_COLUMN) as $u) if (($h = strtolower((string) parse_url((string) $u, PHP_URL_HOST))) !== '') $out[$h] = $why; } catch (Throwable $e) {}
        }
        return $out;
    }

    // ---- the questions callers ask -----------------------------------------------------------------------------------

    /**
     * A gathering call (a workflow's, made by itself): null when it may go ahead, else why not. $wf '' when the caller
     * serves several workflows (its own workflow is checked where it starts); $service '' when it calls no outside service.
     */
    public static function gathering(?PDO $pdo, string $service = '', string $wf = ''): ?string
    {
        if (($w = self::masterOff($pdo)) !== null) return $w;
        if ($wf !== '' && ($w = self::wfOff($pdo, $wf)) !== null) return $w;
        return $service !== '' ? self::serviceOff($pdo, $service) : null;
    }

    /** gathering() for a URL: its service read from its host. */
    public static function gatheringUrl(?PDO $pdo, string $url, string $wf = ''): ?string
    {
        if (($w = self::gathering($pdo, '', $wf)) !== null) return $w;
        $host = (string) parse_url($url, PHP_URL_HOST);
        return $host !== '' ? self::hostOff($pdo, $host) : null;
    }

    /** A scheduled job (Scheduler::run): null when it runs, else why it skips. Jobs not in JOBS always run. */
    public static function job(?PDO $pdo, string $job): ?string
    {
        if (!isset(self::JOBS[$job])) return null;
        if (($w = self::masterOff($pdo)) !== null) return $w;
        $why = [];
        foreach (self::JOBS[$job] as $wf) { $w = self::wfOff($pdo, $wf); if ($w === null) return null; $why[] = $w; }
        return implode(' ', $why);
    }

    /** An AI feature (AiClient::allow): null when it may run, else why not. */
    public static function feature(?PDO $pdo, string $f): ?string
    {
        if (($w = self::serviceOff($pdo, 'anthropic')) !== null) return $w;
        if (in_array($f, self::PERSON_FEATURES, true)) return null;   // a person's own press
        require_once __DIR__ . '/crawler/CrawlService.php';
        $wf = CrawlService::FEATURE_WF[$f] ?? '';
        if ($wf === '') return null;   // not a workflow's
        return self::gathering($pdo, '', $wf);
    }

    /** An AI provider's service paused (AiClient::providerFor and its calls): why, or null. */
    public static function provider(string $provider): ?string
    {
        return self::serviceOff(null, self::PROVIDER_SERVICE[$provider] ?? '');
    }

    /** What a visitor is told where an on-demand feature is paused: never our internal reason, always a way on. */
    public const VISITOR_NOTE = 'New guides are paused for now. We\'ve kept your ask: it\'s built as soon as they\'re back on, most asked-for first. Tap Notify me to hear when it\'s ready, and see what we already list there.';

    // ---- setting them ------------------------------------------------------------------------------------------------

    /** The master switch, or a service, on or off, with why and who. Logged. */
    public static function set(PDO $pdo, string $kind, string $ref, bool $pause, string $why, int $uid, string $byName): void
    {
        if (!in_array($kind, ['master', 'service'], true)) throw new InvalidArgumentException('Unknown switch.');
        if ($kind === 'master') $ref = 'all';
        if ($kind === 'service') {
            require_once __DIR__ . '/OutsideServices.php';
            if (!isset(OutsideServices::COMPANIES[$ref])) throw new InvalidArgumentException('No such outside service.');
            if (isset(self::NOT_PAUSABLE[$ref])) throw new InvalidArgumentException('Its calls are business operations (' . self::NOT_PAUSABLE[$ref] . '): it isn\'t paused from here.');
        }
        $why = mb_substr(trim($why), 0, 255);
        if ($pause && $why === '') throw new InvalidArgumentException('Say why, so whoever sees it paused knows.');
        $pdo->prepare('INSERT INTO automation_switches (kind, ref, paused, why, by_uid, by_name, at) VALUES (?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())
                       ON DUPLICATE KEY UPDATE paused = VALUES(paused), why = VALUES(why), by_uid = VALUES(by_uid), by_name = VALUES(by_name), at = VALUES(at)')
            ->execute([$kind, $ref, $pause ? 1 : 0, $why !== '' ? $why : null, $uid ?: null, mb_substr($byName, 0, 80) ?: null]);
        self::log($pdo, $kind, $ref, $pause, $why, $uid, $byName);
        self::forget();
    }

    /** A workflow paused or resumed (crawl_workflows, through CrawlService::pause). Logged. */
    public static function setWorkflow(PDO $pdo, string $wf, bool $pause, string $why, int $uid, string $byName): void
    {
        if (!isset(self::WORKFLOWS[$wf])) throw new InvalidArgumentException('No such workflow.');
        if ($pause && trim($why) === '') throw new InvalidArgumentException('Say why, so whoever sees it paused knows.');
        require_once __DIR__ . '/crawler/CrawlService.php';
        CrawlService::pause($pdo, $wf, $pause, $uid, $why);
        self::log($pdo, 'workflow', $wf, $pause, $why, $uid, $byName);
        self::forget();
    }

    /** A capture task on or off (crawl_capture_tasks, through CrawlService::setTask). Logged. */
    public static function setTask(PDO $pdo, string $task, bool $on, string $why, int $uid, string $byName): void
    {
        if (!$on && trim($why) === '') throw new InvalidArgumentException('Say why, so whoever sees it off knows.');
        require_once __DIR__ . '/crawler/CrawlService.php';
        CrawlService::setTask($pdo, $task, $on, $uid, $why);
        self::log($pdo, 'task', $task, !$on, $why, $uid, $byName);
    }

    private static function log(PDO $pdo, string $kind, string $ref, bool $pause, string $why, int $uid, string $byName): void
    {
        try {
            $pdo->prepare('INSERT INTO automation_log (at, kind, ref, paused, why, by_uid, by_name) VALUES (UTC_TIMESTAMP(), ?, ?, ?, ?, ?, ?)')
                ->execute([$kind, mb_substr($ref, 0, 40), $pause ? 1 : 0, mb_substr(trim($why), 0, 255) ?: null, $uid ?: null, mb_substr($byName, 0, 80) ?: null]);
        } catch (Throwable $e) { error_log('automation log: ' . $e->getMessage()); }
    }

    /** The last changes, newest first. */
    public static function history(PDO $pdo, int $n = 25): array
    {
        try { return $pdo->query('SELECT * FROM automation_log ORDER BY id DESC LIMIT ' . max(1, min(200, $n)))->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) { return []; }
    }

    /** Every service row (paused or resumed), for the page: service => row. */
    public static function services(?PDO $pdo = null): array
    {
        $out = [];
        foreach (self::rows($pdo) as $r) if (($r['kind'] ?? '') === 'service') $out[(string) $r['ref']] = $r;
        return $out;
    }
}
