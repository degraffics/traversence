<?php
// app/lib/OnDemand.php — guides and journeys on demand (decisions/0147): someone searches a place we have no guide for
// (Dana Point, CA), and we build one. Step by step, each run by the visitor's page as it checks in (never holding a
// request open) or by the guide_ondemand_tick job when they've gone:
//   places    the place is set up as a town of ours, and the free sources gathered: the crawler's dossier (Wikipedia,
//             Wikidata, the official site), OpenStreetMap's places to eat and stay, outdoor places and landmarks we hold
//   journeys  journeys built by rules from what's there (JourneyPlan), free
//   write     Claude writes a first look from that (Guides::$firstLook: no research bought, shorter), within the day's
//             on-demand allowance (half the daily AI allowance by default); past it, it waits for tomorrow, most asked first
//   journeys  again, with the guide's words
//   deep      the full guide: the slow sources (Library of Congress, newspapers, the research brief) through the guide
//             job's gathering; then Claude rewrites its own first-look sections and the "First look" label comes off
// Only real places from our gazetteer (zip_coordinates). Counts only, never who searched.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/PageCache.php';
require_once __DIR__ . '/Guides.php';

final class OnDemand
{
    /** step => what the visitor sees while it runs, and once it's done */
    public const STEPS = [
        'places' => ['Finding places', 'Places found'],
        'journeys' => ['Building journeys', 'Journeys built'],
        'write' => ['Writing the first look', 'First look written'],
        'journeys2' => ['Fitting the journeys to the guide', 'Journeys fitted'],
        'deep' => ['Starting the deeper research', 'Deeper research under way'],
    ];
    /** what a first look costs until we've seen some (micro-dollars) */
    private const FIRST_COST = 400000;
    /** a step's hold, so two visitors' pages never run the same one; writing takes longest */
    private const LEASE = ['write' => 300, 'places' => 150, 'default' => 90];   // seconds a step may run before another check may take it

    private static ?bool $ready = null;

    /** Whether guides on demand are paused: the automation master switch, or W5 (System Configuration → Automation). */
    public static function paused(PDO $pdo): bool
    {
        require_once __DIR__ . '/Automation.php';
        try { return Automation::gathering($pdo, '', 'W5') !== null; } catch (Throwable $e) { return false; }
    }

    public static function ready(PDO $pdo): bool
    {
        if (self::$ready !== null) return self::$ready;
        try { $pdo->query('SELECT 1 FROM guide_requests LIMIT 0'); return self::$ready = true; } catch (Throwable) { return self::$ready = false; }
    }

    // ---- the place ------------------------------------------------------------------------------------------------------

    /** Our town for a city and state from the gazetteer, made if it's new (outside our areas it belongs to no community). */
    public static function townFor(PDO $pdo, string $city, string $state): ?string
    {
        $city = trim($city); $state = strtoupper(trim($state));
        if ($city === '' || !preg_match('/^[A-Z]{2}$/', $state)) return null;
        $st = $pdo->prepare('SELECT zip, city, latitude, longitude FROM zip_coordinates WHERE city = ? AND state = ? ORDER BY id');
        $st->execute([$city, $state]); $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) return null;   // not a real place
        $name = Guides::townName((string) $rows[0]['city']);
        $f = $pdo->prepare('SELECT id FROM anchors WHERE name = ? AND state = ? ORDER BY cluster_id DESC LIMIT 1'); $f->execute([$name, $state]);
        if ($id = (int) $f->fetchColumn()) return 'town:' . $id;
        $zips = array_values(array_unique(array_map(fn ($r) => trim((string) $r['zip']), $rows)));
        $pts = array_filter($rows, fn ($r) => $r['latitude'] !== null);
        $lat = $pts ? array_sum(array_column($pts, 'latitude')) / count($pts) : null;
        $lon = $pts ? array_sum(array_column($pts, 'longitude')) / count($pts) : null;
        $base = Guides::slug($name . '-' . $state); $slug = $base; $i = 2;
        $ex = $pdo->prepare('SELECT 1 FROM anchors WHERE slug = ?');
        while (true) { $ex->execute([$slug]); if (!$ex->fetchColumn()) break; $slug = $base . '-' . $i++; }
        try { $pdo->prepare('INSERT INTO anchors (cluster_id, slug, name, zips, state, lat, lon) VALUES (NULL, ?, ?, ?, ?, ?, ?)')->execute([$slug, $name, implode(',', $zips), $state, $lat, $lon]); }   // no community: outside our areas
        catch (PDOException $e) { error_log('on demand town ' . $name . ', ' . $state . ': ' . $e->getMessage()); throw new RuntimeException('We can\'t set up ' . $name . ' just yet: the site is finishing an update. Try again within the hour.'); }
        return 'town:' . (int) $pdo->lastInsertId();
    }

    /** What the search offers for a place outside our areas: null when its guide is live (and not a first look). */
    public static function offer(PDO $pdo, array $place, string $words = ''): ?array
    {
        if (empty($place['city']) || empty($place['state']) || !self::ready($pdo)) return null;
        $q = http_build_query(array_filter(['city' => (string) $place['city'], 'state' => (string) $place['state'], 'q' => mb_substr(trim($words), 0, 80)]));
        $label = (string) ($place['label'] ?? $place['city']);
        try {
            $f = $pdo->prepare('SELECT a.id, a.slug, g.status, g.draft_info, r.status AS rs FROM anchors a LEFT JOIN place_guides g ON g.place_key = CONCAT(\'town:\', a.id) LEFT JOIN guide_requests r ON r.place_key = CONCAT(\'town:\', a.id)
                                WHERE a.name = ? AND a.state = ? ORDER BY a.cluster_id DESC LIMIT 1');
            $f->execute([Guides::townName((string) $place['city']), strtoupper((string) $place['state'])]);
            $r = $f->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable) { $r = null; }
        if ($r && $r['status'] === 'live') {
            $first = !empty((json_decode((string) $r['draft_info'], true) ?: [])['first_look']);
            return $first ? ['label' => $label, 'state' => 'first', 'url' => '/hub/?town=' . rawurlencode((string) $r['slug']), 'text' => 'A first look at ' . $label . ' is ready, and its full guide is on the way.'] : null;
        }
        $building = $r && in_array((string) $r['rs'], ['building', 'queued', 'first'], true);
        if (self::paused($pdo)) {   // W5 paused (System Configuration → Automation): the ask is still kept, and built when it's back on
            return ['label' => $label, 'state' => $building ? 'building' : 'new', 'url' => '/hub/build.php?' . $q,
                    'text' => 'We don\'t have a guide to ' . $label . ' yet, and new guides are paused for now. Ask for one and we\'ll build it when they\'re back on.'];
        }
        if (!empty($place['guessed']) && !$r) {   // a town in the words: say which one we mean
            return ['label' => $label, 'state' => 'new', 'url' => '/hub/build.php?' . $q, 'text' => 'Looking for ' . $label . '? We don\'t have a guide to it yet. We can build one now: a first look in about two minutes.'];
        }
        return ['label' => $label, 'state' => $building ? 'building' : 'new', 'url' => '/hub/build.php?' . $q,
                'text' => $building ? 'We\'re building a guide to ' . $label . '.' : 'We don\'t have a guide to ' . $label . ' yet. We can build one now: a first look in about two minutes.'];
    }

    /**
     * The words name a real town, though search didn't take them as the place ("dana point": "point" names many of
     * ours, so a town outside our areas needs its state to be the place): the town, the most populous of that name, as
     * a place chip would give it. "things to do in dana point" works too. Null when it isn't a town's name.
     */
    public static function townInWords(PDO $pdo, string $words): ?array
    {
        $w = trim(preg_replace('/\s+/', ' ', $words));
        $tries = [$w];
        if (preg_match_all('/\b(?:in|near|around|at|to)\s+/iu', $w, $mm, PREG_OFFSET_CAPTURE)) foreach ($mm[0] as [$hit, $at]) $tries[] = substr($w, $at + strlen($hit));   // every "in …" ending
        foreach ($tries as $t) {
            $t = trim($t, " ,.");
            if (mb_strlen($t) < 4 || mb_strlen($t) > 40 || preg_match('/\d/', $t)) continue;
            try {
                $st = $pdo->prepare('SELECT city, state, SUM(COALESCE(population, 0)) AS pop FROM zip_coordinates WHERE city = ? GROUP BY city, state ORDER BY pop DESC LIMIT 1');
                $st->execute([$t]); $r = $st->fetch(PDO::FETCH_ASSOC);
            } catch (Throwable) { $r = null; }
            if ($r) { $name = Guides::townName((string) $r['city']); return ['city' => $name, 'state' => (string) $r['state'], 'label' => $name . ', ' . $r['state'], 'guessed' => true]; }
        }
        return null;
    }

    // ---- the allowance (decisions/0147 §5) ------------------------------------------------------------------------------

    /** Today's on-demand allowance: ['day' (all AI), 'share' %, 'cap' (on demand), 'spent', 'left'] in dollars. */
    public static function allowance(PDO $pdo): array
    {
        require_once __DIR__ . '/AiClient.php';
        require_once __DIR__ . '/Thresholds.php';
        $day = AiClient::capUsd() / (int) date('t');
        $share = max(0, min(100, (int) (Thresholds::get($pdo, 'guide_ondemand_share') ?? 50)));
        try { $spent = (int) $pdo->query("SELECT COALESCE(SUM(cost_micros), 0) FROM " . Database::t('ai_jobs') . " WHERE kind = 'guide_ondemand' AND created_at >= CURDATE()")->fetchColumn() / 1e6; } catch (Throwable) { $spent = 0.0; }
        $cap = $day * $share / 100;
        return ['day' => round($day, 2), 'share' => $share, 'cap' => round($cap, 2), 'spent' => round($spent, 2), 'left' => round(max(0, $cap - $spent), 2)];
    }

    /** What a first look is likely to cost: the average of the last ten, else our starting guess. */
    public static function estimate(PDO $pdo): float
    {
        try { $avg = (float) $pdo->query("SELECT AVG(cost_micros) FROM (SELECT cost_micros FROM guide_requests WHERE cost_micros > 0 ORDER BY first_at DESC LIMIT 10) t")->fetchColumn(); } catch (Throwable) { $avg = 0; }
        return ($avg > 0 ? $avg : self::FIRST_COST) / 1e6;
    }

    // ---- a request and its steps -----------------------------------------------------------------------------------------

    /** Someone asked for the place's guide (their page started it). Counts the ask, once a day per visitor. */
    public static function start(PDO $pdo, string $key, string $words, string $visitor): array
    {
        $p = Guides::place($pdo, $key);
        if (!$p || !self::ready($pdo)) throw new RuntimeException('That place isn\'t one we can build a guide for.');
        $label = $p['name'] . ($p['state'] ? ', ' . $p['state'] : '');
        $new = !PageCache::get($pdo, 'gr:v:' . date('Ymd') . ':' . $key . ':' . substr(hash('sha256', $visitor), 0, 16));
        if ($new) PageCache::put($pdo, 'gr:v:' . date('Ymd') . ':' . $key . ':' . substr(hash('sha256', $visitor), 0, 16), 90000, 1);
        $g = Guides::get($pdo, $key);
        $live = $g['status'] === 'live';
        $paused = !$live && self::paused($pdo);   // W5 paused: kept as an ask, built when it's back on (most asked first)
        $pdo->prepare("INSERT INTO guide_requests (place_key, label, words, asks, visitors, status, step, note, created_at) VALUES (?, ?, ?, 1, 1, ?, ?, ?, NOW())
                       ON DUPLICATE KEY UPDATE asks = asks + 1, visitors = visitors + ?, words = IF(VALUES(words) = '', words, LEFT(CONCAT(VALUES(words), ' | ', words), 500)),
                       status = IF(status IN ('failed'), 'building', status), step = IF(status IN ('failed'), 'places', step)")
            ->execute([$key, $label, mb_substr(trim($words), 0, 120), $live ? 'done' : ($paused ? 'queued' : 'building'), $live ? 'done' : 'places', $paused ? Automation::VISITOR_NOTE : '', $new ? 1 : 0]);
        return self::status($pdo, $key);
    }

    /** Where it stands, for the visitor's page. */
    public static function status(PDO $pdo, string $key): array
    {
        $st = $pdo->prepare('SELECT * FROM guide_requests WHERE place_key = ?'); $st->execute([$key]); $r = $st->fetch(PDO::FETCH_ASSOC);
        $p = Guides::place($pdo, $key);
        if (!$r || !$p) return ['status' => 'none', 'steps' => [], 'url' => $p['url'] ?? ''];
        $order = array_keys(self::STEPS); $at = array_search($r['step'], $order, true);
        $steps = [];
        foreach (self::STEPS as $k => [$doing, $done]) {
            $i = array_search($k, $order, true);
            $state = $r['status'] === 'done' || ($at === false && $r['step'] !== 'places') || $i < (int) $at ? 'done' : ($k === $r['step'] ? ($r['status'] === 'queued' && $k === 'write' ? 'waiting' : 'now') : 'later');
            $steps[] = ['key' => $k, 'label' => $state === 'done' ? $done : $doing, 'state' => $state];
        }
        $g = Guides::get($pdo, $key);
        $first = $g['status'] === 'live';
        return ['status' => (string) $r['status'], 'step' => (string) $r['step'], 'steps' => $steps, 'note' => (string) $r['note'], 'found' => json_decode((string) $r['found'], true) ?: [],
                'ready' => $first || in_array($r['status'], ['first', 'done', 'queued', 'held'], true), 'live' => $first, 'url' => $p['url'], 'label' => (string) $r['label']];
    }

    /** Runs the place's next step if no one else is. Returns the status after. */
    public static function step(PDO $pdo, string $key): array
    {
        $st = $pdo->prepare('SELECT status, step FROM guide_requests WHERE place_key = ?'); $st->execute([$key]); $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r || !in_array($r['status'], ['building', 'queued'], true)) return self::status($pdo, $key);
        if (self::paused($pdo)) {   // W5 paused (System Configuration → Automation): it waits where it is, paused, never failed
            $pdo->prepare("UPDATE guide_requests SET status = 'queued', note = ? WHERE place_key = ? AND status IN ('building', 'queued')")->execute([Automation::VISITOR_NOTE, $key]);
            return self::status($pdo, $key);
        }
        $lease = self::LEASE[$r['step']] ?? self::LEASE['default'];
        $take = $pdo->prepare('UPDATE guide_requests SET lease_until = DATE_ADD(NOW(), INTERVAL ' . (int) $lease . ' SECOND), started_at = COALESCE(started_at, NOW()) WHERE place_key = ? AND (lease_until IS NULL OR lease_until < NOW())');
        $take->execute([$key]);
        if ($take->rowCount() !== 1) return self::status($pdo, $key);   // another page is on it
        @set_time_limit(max(60, $lease)); @ignore_user_abort(true);
        try { self::run($pdo, $key, (string) $r['step']); }
        catch (Throwable $e) {
            error_log('on demand ' . $key . ' ' . $r['step'] . ': ' . $e->getMessage());
            self::failed($pdo, $key, $e instanceof RuntimeException && !($e instanceof PDOException) ? $e->getMessage() : 'Something went wrong.');   // never a database message to a visitor
        } finally {
            $pdo->prepare('UPDATE guide_requests SET lease_until = NULL WHERE place_key = ?')->execute([$key]);
        }
        try { self::notifyReady($pdo, $key); } catch (Throwable $e) { error_log('guide ready ' . $key . ': ' . $e->getMessage()); }   // anyone who asked to hear
        return self::status($pdo, $key);
    }

    /** Waits before a failed build is tried again, by its tries so far (review W5: the visitor was told it would be, and it never was). */
    private const RETRY_MINUTES = [1 => 30, 2 => 120, 3 => 480];

    /**
     * A step failed: it's tried again by itself after 30 minutes, 2 hours and 8 hours, from the step it failed on; after
     * that it waits for our team (Pulse: "Guides that couldn't be built"), and the visitor is told so, with a way to ask us.
     * Before the tries columns exist (the database update): failed, as before.
     */
    private static function failed(PDO $pdo, string $key, string $why): void
    {
        $why = rtrim(trim($why), '.') . '.';
        try {
            $st = $pdo->prepare('SELECT tries FROM guide_requests WHERE place_key = ?'); $st->execute([$key]);
            $n = (int) $st->fetchColumn() + 1;
            $note = isset(self::RETRY_MINUTES[$n]) ? $why . ' We\'ll try again by itself shortly.' : $why . ' We tried ' . ($n - 1) . ' more times and couldn\'t build it; our team has been told and will look at it.';
            $pdo->prepare("UPDATE guide_requests SET status = 'failed', tries = ?, failed_at = NOW(), note = ? WHERE place_key = ?")->execute([$n, mb_substr($note, 0, 250), $key]);
        } catch (Throwable $x) {
            $pdo->prepare("UPDATE guide_requests SET status = 'failed', note = ? WHERE place_key = ?")->execute([mb_substr($why . ' We\'ll try again.', 0, 250), $key]);
        }
    }

    /** Failed builds whose wait is over: back to building, from the step they failed on. Returns how many. */
    private static function retryDue(PDO $pdo): int
    {
        $n = 0;
        try {
            foreach (self::RETRY_MINUTES as $tries => $min)
                $n += $pdo->exec("UPDATE guide_requests SET status = 'building' WHERE status = 'failed' AND tries = " . (int) $tries . " AND failed_at < NOW() - INTERVAL " . (int) $min . " MINUTE");
        } catch (Throwable $e) { /* before the database update: none */ }
        return $n;
    }

    /** Builds that used their tries, for Pulse: [{place_key, label, note, failed_at}]. */
    public static function givenUp(PDO $pdo): array
    {
        try { return $pdo->query("SELECT place_key, label, note, failed_at FROM guide_requests WHERE status = 'failed' AND tries > " . count(self::RETRY_MINUTES) . " ORDER BY failed_at DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $e) { return []; }
    }

    /** Our team's Retry: every build that used its tries starts again, its tries from nought. Returns how many. */
    public static function retryGivenUp(PDO $pdo): int
    {
        try { return (int) $pdo->exec("UPDATE guide_requests SET status = 'building', tries = 0, note = 'Our team asked for another try.' WHERE status = 'failed' AND tries > " . count(self::RETRY_MINUTES)); }
        catch (Throwable $e) { return 0; }
    }

    private static function next(PDO $pdo, string $key, string $step, string $status = 'building', string $note = ''): void
    {
        $pdo->prepare('UPDATE guide_requests SET step = ?, status = ?, note = ? WHERE place_key = ?')->execute([$step, $status, $note, $key]);
    }

    private static function run(PDO $pdo, string $key, string $step): void
    {
        $p = Guides::place($pdo, $key);
        if (!$p) throw new RuntimeException('That place isn\'t there any more.');
        if ($step === 'places') {
            $pdo->prepare("INSERT INTO place_guides (place_key, sections, status, updated_by, updated_at) VALUES (?, '{}', 'draft', 0, NOW()) ON DUPLICATE KEY UPDATE place_key = place_key")->execute([$key]);
            require_once __DIR__ . '/Dossier.php';
            try { Dossier::forPlace($pdo, $p); } catch (Throwable $e) { error_log('on demand dossier ' . $key . ': ' . $e->getMessage()); }
            $found = ['eat' => 0, 'stay' => 0, 'outdoors' => 0, 'landmarks' => 0];
            if ($p['lat'] !== null) {
                if (is_file(__DIR__ . '/OpenPlaces.php')) {
                    require_once __DIR__ . '/OpenPlaces.php';
                    OpenPlaces::$until = microtime(true) + 40;   // OpenStreetMap gets 40 seconds of this step at most; what it doesn't answer is asked again later
                    try { $found['eat'] = count(OpenPlaces::near($pdo, 'food', (float) $p['lat'], (float) $p['lon'], 20, 10)); $found['stay'] = count(OpenPlaces::near($pdo, 'lodging', (float) $p['lat'], (float) $p['lon'], 10, 10)); OpenPlaces::near($pdo, 'coffee', (float) $p['lat'], (float) $p['lon'], 10, 10); } catch (Throwable) {}
                    OpenPlaces::$until = null;
                }
                if (is_file(__DIR__ . '/crawler/RecBulk.php')) { require_once __DIR__ . '/crawler/RecBulk.php'; try { $found['outdoors'] = count(RecBulk::near($pdo, [[(float) $p['lat'], (float) $p['lon']]], 15, 20)); } catch (Throwable) {} }
                $found['landmarks'] = count(Guides::landmarks($pdo, $p, 20));
            }
            $pdo->prepare('UPDATE guide_requests SET found = ? WHERE place_key = ?')->execute([json_encode($found), $key]);
            if ((int) ($p['cluster'] ?? 0) === 0 && is_file(__DIR__ . '/crawler/TownCrawl.php')) {   // outside our regions: the crawler builds out its listings too (decisions/0149)
                require_once __DIR__ . '/crawler/TownCrawl.php';
                try { $a = (int) $pdo->query('SELECT visitors FROM guide_requests WHERE place_key = ' . $pdo->quote($key))->fetchColumn(); TownCrawl::queue($pdo, $key, max(1, $a)); } catch (Throwable $e) { error_log('town crawl queue ' . $key . ': ' . $e->getMessage()); }
            }
            self::next($pdo, $key, 'journeys');
        } elseif ($step === 'journeys' || $step === 'journeys2') {
            require_once __DIR__ . '/JourneyPlan.php';
            try { JourneyPlan::buildPlace($pdo, $key); } catch (Throwable $e) { error_log('on demand journeys ' . $key . ': ' . $e->getMessage()); }
            self::next($pdo, $key, $step === 'journeys' ? 'write' : 'deep');
        } elseif ($step === 'write') {
            $g = Guides::get($pdo, $key);
            if ($g['status'] === 'live') { self::next($pdo, $key, 'journeys2'); return; }   // written meanwhile (our team, or the guide job)
            $a = self::allowance($pdo);
            if ($a['left'] < self::estimate($pdo)) { self::next($pdo, $key, 'write', 'queued', 'Today\'s allowance for new guides is used; Claude writes it tomorrow.'); return; }
            require_once __DIR__ . '/AiClient.php';
            [$ok, $why] = AiClient::allow($pdo, 'guide_ondemand');
            if (!$ok) { self::next($pdo, $key, 'write', 'queued', $why); return; }
            $before = self::spent($pdo);
            Guides::$firstLook = true;
            try { Guides::writeDraft($pdo, $key, false, 'guide_ondemand'); } finally { Guides::$firstLook = false; }
            $cost = max(0, self::spent($pdo) - $before);
            require_once __DIR__ . '/PlaceFinder.php';   // the beaches, parks and museums it names get pages of their own and link (decisions/0148)
            try { PlaceFinder::forGuide($pdo, $key); } catch (Throwable $e) { error_log('places on demand ' . $key . ': ' . $e->getMessage()); }
            require_once __DIR__ . '/GuideLinks.php';
            $g = Guides::get($pdo, $key);
            $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: [];
            $has = (bool) array_filter($g['sections'], fn ($t) => trim((string) $t) !== '');
            $block = GuideLinks::blocking($pdo, $key);
            if ($has && !$block && empty($di['kept'])) {   // live as a first look, labelled; never a protected or closed name (decisions/0066)
                $di['first_look'] = date('c');
                $pdo->prepare("UPDATE place_guides SET status = 'live', published_at = COALESCE(published_at, NOW()), linked_at = NOW(), draft_info = ? WHERE place_key = ?")
                    ->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
                Guides::forget($pdo, $key);
            }
            $pdo->prepare('UPDATE guide_requests SET cost_micros = cost_micros + ?, first_at = NOW() WHERE place_key = ?')->execute([(int) round($cost * 1e6), $key]);
            self::next($pdo, $key, 'journeys2', 'building', $has ? ($block ? 'Held for a person to check a name it gives.' : '') : 'Claude found too little to write yet.');
        } elseif ($step === 'deep') {
            // the full guide: the guide job gathers the slow sources and writes the research brief (gatherTick), then tick() rewrites Claude's own sections
            $pdo->prepare("UPDATE place_guides SET draft_status = 'gathering', draft_at = NOW() WHERE place_key = ?")->execute([$key]);
            $g = Guides::get($pdo, $key);
            self::next($pdo, $key, 'renew', $g['status'] === 'live' ? 'first' : 'held');
        }
    }

    private static function spent(PDO $pdo): float
    {
        try { return (int) $pdo->query("SELECT COALESCE(SUM(cost_micros), 0) FROM " . Database::t('ai_jobs') . " WHERE kind = 'guide_ondemand' AND created_at >= CURDATE()")->fetchColumn() / 1e6; } catch (Throwable) { return 0.0; }
    }

    /**
     * The job (every 5 minutes): builds that a visitor left part way carry on; places waiting for the allowance go,
     * most asked first; and first looks whose research is in are written in full, the label off once the guide's score
     * reaches the publishing line. Returns [stepped, renewed].
     */
    public static function tick(PDO $pdo, int $n = 3): array
    {
        if (!self::ready($pdo)) return [0, 0];
        $stepped = 0; $renewed = 0;
        self::retryDue($pdo);   // failed builds whose wait is over carry on from where they stopped
        $rows = $pdo->query("SELECT place_key FROM guide_requests WHERE status IN ('building', 'queued') AND (lease_until IS NULL OR lease_until < NOW()) ORDER BY status = 'queued', visitors DESC, asks DESC, created_at LIMIT 20")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($rows as $k) { if ($stepped >= $n) break; $s = self::step($pdo, (string) $k); $stepped++; if (($s['status'] ?? '') === 'queued') break; }   // the allowance is used: the rest wait too
        // towns built before listings on demand (decisions/0149): queued once
        if (is_file(__DIR__ . '/crawler/TownCrawl.php')) {
            require_once __DIR__ . '/crawler/TownCrawl.php';
            try {
                if (TownCrawl::ready($pdo)) foreach ($pdo->query("SELECT r.place_key, r.visitors FROM guide_requests r JOIN anchors a ON CONCAT('town:', a.id) = r.place_key WHERE a.cluster_id IS NULL
                    AND NOT EXISTS (SELECT 1 FROM town_crawl_jobs j WHERE j.place_key = r.place_key) LIMIT 5")->fetchAll(PDO::FETCH_ASSOC) as $t) TownCrawl::queue($pdo, (string) $t['place_key'], max(1, (int) $t['visitors']));
            } catch (Throwable $e) { error_log('town crawl backfill: ' . $e->getMessage()); }
        }
        // the full guide, once the deeper research is in (or two days have passed)
        $st = $pdo->query("SELECT r.place_key FROM guide_requests r JOIN place_guides g ON g.place_key = r.place_key WHERE r.status IN ('first', 'held') AND r.step = 'renew'
                           AND g.draft_status IN ('done', '', 'queued') AND r.first_at < NOW() - INTERVAL 2 HOUR ORDER BY r.first_at LIMIT 1");
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $k) {
            $k = (string) $k;
            require_once __DIR__ . '/Dossier.php';
            $p = Guides::place($pdo, $k);
            $row = $pdo->prepare('SELECT research, research_at FROM place_dossiers WHERE place_key = ?'); $row->execute([$k]); $d = $row->fetch(PDO::FETCH_ASSOC);
            $g = Guides::get($pdo, $k);
            if (!$p || (trim((string) ($d['research'] ?? '')) === '' && strtotime((string) $g['draft_at']) > time() - 48 * 3600)) continue;   // still gathering
            try {
                $pdo->prepare("UPDATE place_guides SET draft_status = 'done' WHERE place_key = ?")->execute([$k]);   // the guide job's queue is ours now
                Guides::writeDraft($pdo, $k, true, 'guide_draft_auto');
                require_once __DIR__ . '/JourneyPlan.php';
                JourneyPlan::buildPlace($pdo, $k);
                $g = Guides::get($pdo, $k); $di = json_decode((string) ($g['draft_info'] ?? ''), true) ?: [];
                require_once __DIR__ . '/AiClient.php';
                [$score] = Guides::score($pdo, $k, $di);
                if (!empty($di['first_look']) && $score >= (int) AiClient::feature($pdo, 'guide_publish')['per_day']) {
                    unset($di['first_look']); $di['full_at'] = date('c'); $di['score'] = $score;
                    $pdo->prepare('UPDATE place_guides SET draft_info = ? WHERE place_key = ?')->execute([json_encode($di, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $k]);
                    Guides::forget($pdo, $k);
                }
                $pdo->prepare("UPDATE guide_requests SET status = 'done', step = 'done', done_at = NOW(), note = ? WHERE place_key = ?")
                    ->execute([!empty($di['first_look']) ? 'Written in full; the label stays until its score reaches the line (' . $score . ').' : '', $k]);
                $renewed++;
            } catch (Throwable $e) { error_log('on demand renew ' . $k . ': ' . $e->getMessage()); }
        }
        try { self::notifyReady($pdo); } catch (Throwable $e) { error_log('guide ready: ' . $e->getMessage()); }   // a guide put up any other way (our team, the guide job)
        return [$stepped, $renewed];
    }

    // ---- "Notify me when it's ready" (Jason, 2026-11-10) ---------------------------------------------------------------

    /** Signed-out asks from one device in a day, before it's asked to sign in (a guard against using us to email others). */
    public const WATCH_A_DAY = 5;

    public static function watchReady(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT 1 FROM guide_watchers LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    /**
     * Tells this person when the guide is up: a member by a notice in their Pulse and an email to their account; signed
     * out, by an email to the address given (used for this once, then cleared). Returns the words to show.
     */
    public static function watch(PDO $pdo, string $key, ?int $uid, string $email, string $device): string
    {
        if (!self::watchReady($pdo)) throw new RuntimeException('Notices for guides switch on within the hour of this update. Check back here, or search for the place again later.');
        $p = Guides::place($pdo, $key);
        if (!$p) throw new RuntimeException('We couldn\'t find that place.');
        $g = Guides::get($pdo, $key);
        if ($g['status'] === 'live') return 'It\'s ready now: open the guide.';
        $label = $p['name'] . (!empty($p['state']) ? ', ' . $p['state'] : '');
        if ($uid) {
            $pdo->prepare('INSERT IGNORE INTO guide_watchers (place_key, user_id) VALUES (?, ?)')->execute([$key, $uid]);
            return 'We\'ll tell you in your Pulse and by email when the guide to ' . $label . ' is ready.';
        }
        $email = mb_strtolower(trim($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('That email doesn\'t look right.');
        $st = $pdo->prepare('SELECT COUNT(*) FROM guide_watchers WHERE device = ? AND user_id IS NULL AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)'); $st->execute([$device]);
        if ((int) $st->fetchColumn() >= self::WATCH_A_DAY) throw new RuntimeException('That\'s a lot of guides for one day. Sign in and we\'ll tell you about each one in your Pulse, or check back here: the guide carries on without you.');
        $pdo->prepare('INSERT IGNORE INTO guide_watchers (place_key, email, device) VALUES (?, ?, ?)')->execute([$key, $email, $device]);
        return 'We\'ll email ' . $email . ' once, when the guide to ' . $label . ' is ready.';
    }

    /** Tells everyone waiting on a guide that's now up (one place, or all), once each. Returns how many were told. */
    public static function notifyReady(PDO $pdo, ?string $key = null): int
    {
        if (!self::watchReady($pdo)) return 0;
        $st = $pdo->prepare("SELECT w.* FROM guide_watchers w JOIN place_guides g ON g.place_key = w.place_key WHERE w.notified_at IS NULL AND g.status = 'live'"
            . ($key !== null ? ' AND w.place_key = ?' : '') . ' ORDER BY w.id LIMIT 200');
        $st->execute($key !== null ? [$key] : []);
        $n = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $w) {
            $p = Guides::place($pdo, (string) $w['place_key']);
            $done = $pdo->prepare('UPDATE guide_watchers SET notified_at = NOW(), email = NULL WHERE id = ? AND notified_at IS NULL');   // once, and the address isn't kept
            $done->execute([(int) $w['id']]);
            if (!$p || $done->rowCount() !== 1) continue;
            $label = $p['name'] . (!empty($p['state']) ? ', ' . $p['state'] : '');
            $url = rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . $p['url'];
            $title = 'Your guide to ' . $label . ' is ready';
            $body = 'The first look at ' . $label . ' is up: places to eat and stay, the outdoors, landmarks and journeys. The full guide follows within a day or two, on the same page.';
            $to = (string) ($w['email'] ?? ''); $name = '';
            if (!empty($w['user_id'])) {
                require_once __DIR__ . '/Notices.php';
                try { Notices::send($pdo, [(int) $w['user_id']], 'guide_ready', (string) $w['place_key'], $title, $body, $p['url']); } catch (Throwable $e) { error_log('guide ready notice: ' . $e->getMessage()); }
                $u = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ? AND is_suspended = 0'); $u->execute([(int) $w['user_id']]);
                $r = $u->fetch(PDO::FETCH_ASSOC); $to = (string) ($r['email'] ?? ''); $name = (string) ($r['display_name'] ?? '');
                try {
                    if (Notices::emailOn($pdo) && Notices::delivery($pdo, (int) $w['user_id']) === 'email') $to = '';   // their notice already comes by email: one, not two
                    $off = $pdo->prepare("SELECT 1 FROM notice_prefs WHERE user_id = ? AND kind = 'guide_ready'"); $off->execute([(int) $w['user_id']]);
                    if ($off->fetchColumn()) $to = '';   // they switched these off in App Settings
                } catch (Throwable) {}
            }
            if (filter_var($to, FILTER_VALIDATE_EMAIL)) self::mailReady($pdo, $to, $name, $title, $body . "\n\n" . $url, !empty($w['user_id']) ? (int) $w['user_id'] : null);
            $n++;
        }
        return $n;
    }

    /** The "it's ready" email: through SES as notices are, else the site's own mail. A system email: no cost (CLAUDE.md). */
    private static function mailReady(PDO $pdo, string $to, string $name, string $title, string $text, ?int $uid): void
    {
        $why = 'You asked us on traversence.com to tell you when this guide was ready. We only send this once.';
        try {
            require_once __DIR__ . '/SesMail.php';
            $r = SesMail::send($pdo, ['account' => 'personal', 'from_local' => 'notices', 'from_domain' => 'send.traversence.com', 'from_name' => 'Traversence',
                'to' => $to, 'to_name' => $name, 'subject' => $title, 'text' => $title . "\n\n" . $text, 'sender' => 'traversence', 'purpose' => 'notice',
                'user_id' => $uid, 'scope' => 'notices', 'why' => $why]);
            if (in_array($r['status'] ?? '', ['sent', 'mock', 'test', 'suppressed'], true)) return;   // suppressed: they unsubscribed, so nothing else either
        } catch (Throwable $e) { error_log('guide ready email (SES): ' . $e->getMessage()); }
        try { require_once __DIR__ . '/Mailer.php'; Mailer::send($to, $title, $title . "\n\n" . $text . "\n\n" . $why, $name !== '' ? $name : null); }
        catch (Throwable $e) { error_log('guide ready email: ' . $e->getMessage()); }
    }
}
