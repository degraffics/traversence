<?php
// app/lib/PlaceFinder.php — places on demand (decisions/0148): the beaches, parks, museums and historic places a guide
// names that we don't hold yet, found in Wikidata (CC0, free) near the guide's place, kept as landmarks of ours with
// their own page (/place/landmark.php), and linked from the guide. One Wikidata question per place (everything with a
// location within 15 km), kept 30 days; a Wikipedia summary for each match that has an article. Never a business (those
// go through Find it and the listing checks), never a town, and never a place that may be sacred or protected
// (Landmarks::decide, decisions/0066): those are held, not shown. Free: no AI. Since 2026-11-10 also each pilot town's
// places (sweepTick), each pilot state square by square (stateTick) and the names people search for (lookupTick).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/PageCache.php';
require_once __DIR__ . '/Guides.php';
require_once __DIR__ . '/Landmarks.php';

final class PlaceFinder
{
    /** what Wikidata calls it, for it to be a place with a page of its own */
    private const KEEP = '/beach|park|museum|histor|church|mission|pier|lighthouse|\bbay\b|cove|\bpoint\b|cape|headland|reef|trail|garden|theat|galler|monument|memorial|district|island|canyon|mountain|summit|peak|\bhill\b|lake|reservoir|preserve|reserve|harbo|marina|bridge|tower|landmark|zoo|aquarium|art cent|arts cent|cultural|plaza|botanical|waterfall|creek|river|wildlife|nature|tide pool|bluff|overlook|viewpoint|amphitheat|stadium|fort|ruins?\b|adobe|house museum|building|\bhouse\b|mansion|cottage|cinema|movie theat|historic|heritage|chapel|cathedral|festival|fairground/i';   // a historic house or cinema is listed in Wikidata as just that
    /** what it must not be */
    /** never a place of its own: a town or other settlement, whatever else it is */
    private const SETTLEMENT = '/^(big |small |former )?(city|town|village|hamlet)\\b|human settlement|census|municipality|unincorporated|^county\\b|county seat|neighbou?rhood|^suburb/';
    /** a business, school or the like: only when nothing about it is a place to visit (a museum run by a nonprofit stays) */
    private const OTHER = '/^(company|business|enterprise|restaurant|hotel|motel|shop|store|retail|organi[sz]ation|non-?profit organi[sz]ation|school|public school|high school|elementary school|university|college|hospital|railway station|road|street|highway|post office|electoral district|shopping (center|mall))$/';
    private const UA = 'Traversence guides (support@traversence.com)';
    private const RADIUS_KM = 10;

    /** @var callable|null for tests: fn(string $url): ?array */
    public static $fetch = null;

    /** The names in a guide we don't hold yet, looked up and linked. Returns ['looked' => n, 'added' => n, 'linked' => n]. */
    public static function forGuide(PDO $pdo, string $key): array
    {
        $out = ['looked' => 0, 'added' => 0, 'linked' => 0];
        $p = Guides::place($pdo, $key);
        if (!$p || $p['lat'] === null) return $out;
        try {
            $st = $pdo->prepare("SELECT id, name, kind FROM content_tags WHERE src = ? AND ref = '' AND status IN ('finding', 'unconfirmed', 'review')");
            $st->execute(['guide:' . $key]); $tags = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return $out; }
        $tags = array_values(array_filter($tags, fn ($t) => !in_array((string) $t['kind'], ['road', 'resource', 'town', 'neighborhood', 'area', 'person'], true)));
        PageCache::put($pdo, 'pf:checked:' . $key, 30 * 86400, 1);
        if (!$tags) return $out;
        $items = self::named($pdo, array_column($tags, 'name'), (float) $p['lat'], (float) $p['lon']);   // by the guide's own names first; then what's around, for names written a little differently
        $seen = array_flip(array_column($items, 'qid'));
        foreach (self::near($pdo, (float) $p['lat'], (float) $p['lon']) as $it) if (!isset($seen[$it['qid']])) $items[] = $it;
        $out['looked'] = count($tags);
        $made = [];
        foreach ($tags as $t) {
            $name = (string) $t['name'];
            $best = null;
            foreach ($items as $it) {
                if (!self::same($name, $it['label'])) continue;
                $d = Landmarks::miles((float) $p['lat'], (float) $p['lon'], $it['lat'], $it['lon']);
                if (!$best || $d < $best[1]) $best = [$it, $d];
            }
            if (!$best) continue;
            $it = $best[0];
            $id = $made[$it['qid']] ?? self::keep($pdo, $p, $it, $out);
            if (!$id) continue;
            $made[$it['qid']] = $id;
            $st = $pdo->prepare('SELECT gnis_id, status FROM landmarks WHERE gnis_id = ?'); $st->execute([$id]); $lm = $st->fetch(PDO::FETCH_ASSOC);
            if (!$lm || !Landmarks::visible($lm)) continue;   // held (sensitive, or on a nation's land and specific to it): the guide keeps the plain name
            $pdo->prepare("UPDATE content_tags SET ref = ?, status = 'linked', note = 'Found on Wikidata (its own page with us)', updated_at = NOW() WHERE id = ?")->execute(['landmark:' . $id, (int) $t['id']]);
            try { $pdo->prepare("DELETE FROM guide_finds WHERE place_key = ? AND name = ? AND status NOT IN ('found', 'notfound')")->execute([$key, $name]); } catch (Throwable) {}   // no need for Find it to look
            $out['linked']++;
        }
        if ($out['linked']) Guides::forget($pdo, $key);
        return $out;
    }

    /** The job: a couple of live guides a run with names we don't hold, each looked at once every 30 days. */
    public static function tick(PDO $pdo, int $n = 2): int
    {
        try {
            // guides built from a search first (their visitor is waiting), then the ones with the most names to link
            $keys = $pdo->query("SELECT t.place_key FROM content_tags t JOIN place_guides g ON g.place_key = t.place_key AND g.status = 'live'
                                 WHERE t.src LIKE 'guide:%' AND t.ref = '' AND t.status IN ('finding', 'unconfirmed', 'review')
                                 GROUP BY t.place_key ORDER BY EXISTS (SELECT 1 FROM guide_requests r WHERE r.place_key = t.place_key) DESC, COUNT(*) DESC LIMIT 200")->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable) { return 0; }
        $done = 0;
        foreach ($keys as $k) {
            if ($done >= $n) break;
            if (PageCache::get($pdo, 'pf:checked:' . $k)) continue;
            try { $r = self::forGuide($pdo, (string) $k); $done++; if ($r['linked']) error_log('places on demand ' . $k . ': linked ' . $r['linked'] . ' of ' . $r['looked']); } catch (Throwable $e) { error_log('places on demand ' . $k . ': ' . $e->getMessage()); }
        }
        return $done;
    }

    /**
     * The pilot towns (2026-11-10, Jason: "run the place finder for pilot towns"): each town's museums, monuments, historic
     * sites, harbors and the like from Wikidata, kept as landmarks, not only the ones a guide's text names. Only places
     * with a Wikipedia article or on the National Register of Historic Places; a held place stays held
     * (Landmarks::decide). One town a run, at most MAX_NEW new places each, looked at again after a year.
     */
    private const SWEEP_MILES = 6;
    private const MAX_NEW = 20;

    public static function sweepTick(PDO $pdo, int $n = 1): int
    {
        // once (2026-11-10): the places already found from Wikidata are searched again under their own kind, not "Natural landmark"
        if (!PageCache::get($pdo, 'pf:relabel:1') && is_file(__DIR__ . '/SearchIndex.php')) {
            require_once __DIR__ . '/SearchIndex.php';
            try {
                if (SearchIndex::ready($pdo)) foreach ($pdo->query("SELECT gnis_id FROM landmarks WHERE file IN ('wikidata', 'manual')")->fetchAll(PDO::FETCH_COLUMN) as $lid) SearchIndex::refreshLandmark($pdo, (int) $lid);
                PageCache::put($pdo, 'pf:relabel:1', 3650 * 86400, 1);
            } catch (Throwable $e) { error_log('places relabel: ' . $e->getMessage()); }
        }
        try { $towns = $pdo->query('SELECT id FROM anchors WHERE lat IS NOT NULL ORDER BY id')->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable) { return 0; }
        $done = 0;
        foreach ($towns as $tid) {
            if ($done >= $n) break;
            $key = 'town:' . (int) $tid;
            if (PageCache::get($pdo, 'pf:swept:' . $key)) continue;
            $done++;
            try {
                $p = Guides::place($pdo, $key);
                if (!$p || $p['lat'] === null) { PageCache::put($pdo, 'pf:swept:' . $key, 365 * 86400, 1); continue; }
                $out = ['added' => 0];
                $all = true;
                foreach (self::near($pdo, (float) $p['lat'], (float) $p['lon']) as $it) {
                    if (($it['article'] === '' && empty($it['nrhp'])) || Landmarks::miles((float) $p['lat'], (float) $p['lon'], $it['lat'], $it['lon']) > self::SWEEP_MILES) continue;
                    if ($out['added'] >= self::MAX_NEW) { $all = false; break; }   // the rest next run (the ones kept are found by their Q id at once)
                    self::keep($pdo, $p, $it, $out);
                }
                if ($all) PageCache::put($pdo, 'pf:swept:' . $key, 365 * 86400, 1);
                if ($out['added']) error_log('places for ' . $p['name'] . ': added ' . $out['added']);
            } catch (Throwable $e) { error_log('places for ' . $key . ': ' . $e->getMessage()); }
        }
        return $done;
    }

    /**
     * Each pilot state, whole (2026-11-10, Jason: "how do we fix our system to pull the right data"): the places far from
     * any town (Four Corners Monument, Window Rock) that a town's circle never reaches. The state is cut into squares of
     * TILE degrees, one square a run, and everything Wikidata places there with a Wikipedia article or on the National
     * Register of Historic Places goes through keep() (the same kinds, never a town, sensitive places held). Once every
     * square is done the state rests 30 days, then starts again for what's new.
     */
    private const TILE = 0.5;

    public static function stateTick(PDO $pdo): string
    {
        require_once __DIR__ . '/crawler/NpiBulk.php';
        foreach (NpiBulk::STATES as $stc) {
            if (PageCache::get($pdo, 'pf:tiles:done:' . $stc)) continue;
            try {
                $st = $pdo->prepare('SELECT MIN(latitude) a, MAX(latitude) b, MIN(longitude) c, MAX(longitude) d FROM zip_coordinates WHERE state = ?');
                $st->execute([$stc]); $bb = $st->fetch(PDO::FETCH_ASSOC);
            } catch (Throwable) { return ''; }
            if (!$bb || $bb['a'] === null) continue;
            $la0 = floor((float) $bb['a'] / self::TILE) * self::TILE; $lo0 = floor((float) $bb['c'] / self::TILE) * self::TILE;
            $rows = max(1, (int) ceil(((float) $bb['b'] - $la0) / self::TILE)); $cols = max(1, (int) ceil(((float) $bb['d'] - $lo0) / self::TILE));
            $i = (int) (PageCache::get($pdo, 'pf:tile:' . $stc) ?: 0);
            if ($i >= $rows * $cols) { PageCache::put($pdo, 'pf:tiles:done:' . $stc, 30 * 86400, 1); PageCache::put($pdo, 'pf:tile:' . $stc, 400 * 86400, 0); continue; }
            $s = $la0 + intdiv($i, $cols) * self::TILE; $w = $lo0 + ($i % $cols) * self::TILE;
            $items = self::box($s, $w, $s + self::TILE, $w + self::TILE);
            if ($items === null) return $stc . ' square ' . ($i + 1) . ': no answer, next run';
            $out = ['added' => 0]; $all = true;
            foreach ($items as $it) {
                if ($it['article'] === '' && empty($it['nrhp'])) continue;
                if ($out['added'] >= self::MAX_NEW) { $all = false; break; }   // the rest of this square next run
                try { self::keep($pdo, null, $it, $out); } catch (Throwable $e) { error_log('places in ' . $stc . ': ' . $e->getMessage()); }
            }
            if ($all) PageCache::put($pdo, 'pf:tile:' . $stc, 400 * 86400, $i + 1);
            return $stc . ' square ' . ($i + 1) . ' of ' . ($rows * $cols) . ': ' . count($items) . ' places, ' . $out['added'] . ' new';
        }
        return '';
    }

    /**
     * What people searched for and we didn't have (2026-11-10, Jason: "every search is demand"): a search of two words or
     * more that reads like a name ("four corners monument", "laguna art museum") is asked of Wikidata by name, anywhere
     * in the US, and a place to visit with a Wikipedia article or on the National Register becomes a landmark, searchable
     * at once. From the searches already counted (search_terms, never who); ones that found nothing first. Each is asked
     * once every 30 days. Only the words go out: never a search with a number in it (an address, a phone) or an email.
     */
    private const GENERIC = '/^(the|a|an|of|in|near|around|at|by|for|to|and|me|my|best|good|cheap|top|open|now|things|thing|do|see|places?|spots?|art|arts|museums?|parks?|history|historic|restaurants?|food|eat|eating|bars?|hotels?|motels?|stay|coffee|pizza|tacos?|beach(es)?|trails?|hikes?|hiking|camping|campgrounds?|lakes?|shops?|stores?|shopping|services?|repair|doctors?|dentists?|clinics?|church(es)?|schools?|free|kids?|family|dog|dogs|pet|pets|friendly|local|nearby|area|city|town|downtown|state|national|county)$/';

    public static function lookupTick(PDO $pdo, int $n = 6): int
    {
        try {
            $terms = $pdo->query("SELECT q, SUM(zero) z, SUM(n) t FROM search_terms WHERE day >= '" . date('Y-m-d', time() - 14 * 86400) . "' AND q LIKE '% %' GROUP BY q ORDER BY SUM(zero) > 0 DESC, SUM(n) DESC LIMIT 300")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return 0; }
        $done = 0;
        foreach ($terms as $t) {
            if ($done >= $n) break;
            $name = self::nameIn((string) $t['q']);
            if ($name === '' || PageCache::get($pdo, 'pf:q:' . md5($name))) continue;
            $done++;
            try {
                $r = self::lookupName($pdo, $name);
                if ($r === null) continue;   // no answer: asked again next run
                PageCache::put($pdo, 'pf:q:' . md5($name), 30 * 86400, 1);
                if ($r) error_log('places searched for "' . $name . '": kept ' . $r);
            } catch (Throwable $e) { error_log('places searched for "' . $name . '": ' . $e->getMessage()); }
        }
        return $done;
    }

    /** The name in a search ("laguna art museum in laguna beach" → "laguna art museum"), or '' when it doesn't read like one. */
    public static function nameIn(string $q): string
    {
        $q = trim((string) preg_replace('/\s+/', ' ', mb_strtolower($q)));
        if (preg_match('/[0-9@]/', $q)) return '';   // an address, a phone, an email: never sent out
        $q = trim((string) preg_replace('/\s+(in|near|around|by)\s.*$/u', '', $q));
        $q = trim((string) preg_replace('/^(the|visit|visiting|go to|tickets? (for|to))\s+/u', '', $q));
        $words = preg_split('/[\s,]+/u', $q, -1, PREG_SPLIT_NO_EMPTY);
        if (count($words) < 2 || mb_strlen($q) < 6 || mb_strlen($q) > 80) return '';
        if (!array_filter($words, fn ($w) => mb_strlen($w) >= 3 && !preg_match(self::GENERIC, $w))) return '';   // "art museum near me" names nothing
        return $q;
    }

    /** A name asked of Wikidata: the places found and kept (new or already ours), or null when Wikidata didn't answer. */
    public static function lookupName(PDO $pdo, string $name): ?int
    {
        $j = self::get('https://www.wikidata.org/w/api.php?action=wbsearchentities&format=json&language=en&uselang=en&type=item&limit=7&search=' . rawurlencode($name), 12);
        if ($j === null) return null;
        $ids = [];
        foreach ((array) ($j['search'] ?? []) as $hit) {
            $id = (string) ($hit['id'] ?? '');
            $lab = (string) ($hit['label'] ?? ''); $alt = (string) ($hit['match']['text'] ?? '');
            if (preg_match('/^Q\d+$/', $id) && (self::same($name, $lab) || ($alt !== '' && self::same($name, $alt)))) $ids[] = $id;
        }
        if (!$ids) return 0;
        $q = 'SELECT ?item ?itemLabel ?itemDescription ?lat ?lon ?classLabel ?article ?nrhp WHERE { VALUES ?item { wd:' . implode(' wd:', $ids) . ' } '
           . '?item wdt:P17 wd:Q30 . ?item p:P625/psv:P625 [ wikibase:geoLatitude ?lat ; wikibase:geoLongitude ?lon ] . OPTIONAL { ?item wdt:P31 ?class . } OPTIONAL { ?item wdt:P649 ?nrhp . } '
           . 'OPTIONAL { ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> . } SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . } } LIMIT 500';
        $items = self::items(self::get('https://query.wikidata.org/sparql?format=json&query=' . rawurlencode($q), 15));
        if ($items === null) return null;
        $out = ['added' => 0]; $kept = 0;
        foreach ($items as $it) {
            if ($it['article'] === '' && empty($it['nrhp'])) continue;   // notable enough for a page of its own
            if (self::keep($pdo, null, $it, $out)) $kept++;
        }
        return $kept;
    }

    /** Everything Wikidata places in a box with an article or on the Register, as places that could have a page; null when there was no answer. */
    private static function box(float $s, float $w, float $n, float $e): ?array
    {
        $q = 'SELECT ?item ?itemLabel ?itemDescription ?lat ?lon ?classLabel ?article ?nrhp WHERE { '
           . 'SERVICE wikibase:box { ?item wdt:P625 ?loc . bd:serviceParam wikibase:cornerSouthWest "Point(' . round($w, 4) . ' ' . round($s, 4) . ')"^^geo:wktLiteral . '
           . 'bd:serviceParam wikibase:cornerNorthEast "Point(' . round($e, 4) . ' ' . round($n, 4) . ')"^^geo:wktLiteral . } '
           . 'OPTIONAL { ?item wdt:P649 ?nrhp . } OPTIONAL { ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> . } FILTER (BOUND(?nrhp) || BOUND(?article)) '
           . '?item p:P625/psv:P625 [ wikibase:geoLatitude ?lat ; wikibase:geoLongitude ?lon ] . OPTIONAL { ?item wdt:P31 ?class . } '
           . 'SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . } } LIMIT 10000';
        return self::items(self::get('https://query.wikidata.org/sparql?format=json&query=' . rawurlencode($q), 50));
    }

    /**
     * OpenStreetMap as a lead for landmarks (Jason, 2026-11-10: "Crawler should use osm as lead source for anything it
     * offers"): each town's trailheads, parks and preserves, and viewpoints on OpenStreetMap (its own layer, OpenPlaces)
     * give names; each name is asked of Wikidata near the same spot, and a match with a Wikipedia article or on the
     * National Register is kept through keep(), built from Wikidata, never from OpenStreetMap (decisions/0065's layer
     * rule). One town a run, again after 30 days, and only while OpenStreetMap's hourly fair use has room.
     */
    public static function osmLeadTick(PDO $pdo): string
    {
        if (!is_file(__DIR__ . '/OpenPlaces.php')) return '';
        require_once __DIR__ . '/OpenPlaces.php';
        if (!OpenPlaces::ready($pdo)) return '';
        try {
            if ((int) $pdo->query("SELECT COUNT(*) FROM open_place_asks WHERE asked_at >= '" . date('Y-m-d H:i:s', time() - 3600) . "'")->fetchColumn() >= 20) return 'waiting: OpenStreetMap asked enough this hour';
            $towns = $pdo->query('SELECT id FROM anchors WHERE lat IS NOT NULL ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable) { return ''; }
        foreach ($towns as $tid) {
            $key = 'town:' . (int) $tid;
            if (PageCache::get($pdo, 'pf:osmlead:' . $key)) continue;
            $p = Guides::place($pdo, $key);
            PageCache::put($pdo, 'pf:osmlead:' . $key, 30 * 86400, 1);
            if (!$p || $p['lat'] === null) continue;
            $leads = [];
            foreach (['trail', 'park', 'viewpoint'] as $kind) {   // asked as a background job (true below): visitors keep their share of OpenStreetMap's hour
                try { foreach (OpenPlaces::near($pdo, $kind, (float) $p['lat'], (float) $p['lon'], 60, 10, true) as $o) $leads[(string) $o['label']] = 1; } catch (Throwable $e) { error_log('osm leads ' . $key . ': ' . $e->getMessage()); }
            }
            $names = array_keys($leads);
            if (!$names) return $p['name'] . ': no outdoor places on OpenStreetMap';
            $out = ['added' => 0]; $kept = 0;
            foreach (array_chunk($names, 50) as $chunk) {
                foreach (self::named($pdo, $chunk, (float) $p['lat'], (float) $p['lon']) as $it) {
                    if ($it['article'] === '' && empty($it['nrhp'])) continue;   // notable enough for a page of its own
                    $match = false; foreach ($chunk as $nm) if (self::same($nm, $it['label'])) { $match = true; break; }
                    if (!$match || $out['added'] >= self::MAX_NEW) continue;
                    try { if (self::keep($pdo, $p, $it, $out)) $kept++; } catch (Throwable $e) { error_log('osm leads keep: ' . $e->getMessage()); }
                }
            }
            return $p['name'] . ': ' . count($names) . ' leads from OpenStreetMap, ' . $kept . ' confirmed on Wikidata, ' . $out['added'] . ' new';
        }
        return '';
    }

    /**
     * What Wikidata records about our places from it (2026-11-10: a card that said only "historic district in Glendale,
     * Arizona"): its heritage listing, when it dates from, its style and architect, kept as landmarks.wd_facts (CC0) for
     * Landmarks::about(). Fifty a run, each place once; searched again under its new words.
     */
    public static function factsTick(PDO $pdo, int $n = 50): int
    {
        try { $rows = $pdo->query("SELECT gnis_id, qid FROM landmarks WHERE file = 'wikidata' AND qid <> '' AND wd_facts IS NULL LIMIT " . (int) $n)->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable) { return 0; }   // before the migration
        if (!$rows) return 0;
        $byQ = []; foreach ($rows as $r) if (preg_match('/^Q\d+$/', (string) $r['qid'])) $byQ[(string) $r['qid']] = (int) $r['gnis_id'];
        if (!$byQ) return 0;
        $q = 'SELECT ?item ?herLabel ?inception ?styleLabel ?architectLabel WHERE { VALUES ?item { wd:' . implode(' wd:', array_keys($byQ)) . ' } '
           . 'OPTIONAL { ?item wdt:P1435 ?her . } OPTIONAL { ?item wdt:P571 ?inception . } OPTIONAL { ?item wdt:P149 ?style . } OPTIONAL { ?item wdt:P84 ?architect . } '
           . 'SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . } } LIMIT 3000';
        $j = self::get('https://query.wikidata.org/sparql?format=json&query=' . rawurlencode($q), 20);
        if ($j === null) return 0;   // no answer: next run
        $f = []; foreach ($byQ as $qid => $id) $f[$qid] = ['heritage' => [], 'style' => [], 'architect' => [], 'year' => ''];
        foreach ((array) ($j['results']['bindings'] ?? []) as $b) {
            $qid = preg_replace('#^.*/#', '', (string) ($b['item']['value'] ?? ''));
            if (!isset($f[$qid])) continue;
            foreach (['herLabel' => 'heritage', 'styleLabel' => 'style', 'architectLabel' => 'architect'] as $k => $to) {
                $v = trim((string) ($b[$k]['value'] ?? ''));
                if ($v !== '' && !preg_match('/^Q\d+$/', $v) && !in_array($v, $f[$qid][$to], true)) $f[$qid][$to][] = $v;
            }
            if (!empty($b['inception']['value']) && preg_match('/^(\d{4})/', ltrim((string) $b['inception']['value'], '+'), $ym) && ($f[$qid]['year'] === '' || $ym[1] < $f[$qid]['year'])) $f[$qid]['year'] = $ym[1];
        }
        $up = $pdo->prepare('UPDATE landmarks SET wd_facts = ? WHERE gnis_id = ?');
        foreach ($f as $qid => $facts) {
            $up->execute([json_encode(array_filter($facts)), $byQ[$qid]]);
            self::index($pdo, $byQ[$qid]);   // its card and search read the new words
        }
        return count($f);
    }

    /**
     * A place someone opened that has no Wikipedia summary (Jason, 2026-11-10: "only ai when no data exist and it must be
     * stored as research for future reuse"): queued when opened (wantAbout), then Claude writes what it is and what you do
     * there, 2 to 3 sentences from what we hold and at most one web search, with its sources and its activities, kept on
     * the landmark (research, research_sources, research_acts) and reused everywhere. Feature place_about (System
     * Configuration → AI use), inside the month's AI cap. Never for a place held as sensitive; never the way to one.
     */
    public static function wantAbout(PDO $pdo, int $id): void
    {
        try { $pdo->prepare("UPDATE landmarks SET about_queued_at = NOW() WHERE gnis_id = ? AND about_queued_at IS NULL AND research_at IS NULL AND (extract IS NULL OR extract = '')")->execute([$id]); } catch (Throwable) {}   // before the migration: nothing
    }

    public static function aboutTick(PDO $pdo, int $n = 6): int
    {
        if (!is_file(__DIR__ . '/AiClient.php')) return 0;
        require_once __DIR__ . '/AiClient.php';
        try { $ids = $pdo->query('SELECT gnis_id FROM landmarks WHERE about_queued_at IS NOT NULL AND research_at IS NULL AND ' . Landmarks::visibleSql() . ' ORDER BY about_queued_at LIMIT ' . (int) $n)->fetchAll(PDO::FETCH_COLUMN); }
        catch (Throwable) { return 0; }
        $done = 0;
        foreach ($ids as $id) {
            if (!AiClient::allow($pdo, 'place_about')[0]) break;
            $r = Landmarks::get($pdo, (int) $id); if (!$r) continue;
            if (Landmarks::isProtected((string) $r['name'] . ' ' . (string) $r['wd_desc'] . ' ' . (string) $r['fclass'], (string) $r['nation'])) {   // never written about here
                $pdo->prepare("UPDATE landmarks SET research_at = NOW(), research = '' WHERE gnis_id = ?")->execute([(int) $id]); continue;
            }
            $facts = trim(implode("\n", array_filter([
                'Name: ' . $r['name'], 'What it is: ' . Landmarks::kindLabel($r), $r['wd_desc'] !== '' ? 'Wikidata: ' . $r['wd_desc'] : '',
                'Where: ' . trim(implode(', ', array_filter([(string) $r['near_town'], (string) $r['state']]))), Landmarks::about($pdo, $r) !== '' ? 'Known: ' . Landmarks::about($pdo, $r) : '',
            ])));
            $fc = AiClient::feature($pdo, 'place_about');
            try {
                $res = AiClient::claudeAsk("Write for travelers what this place is and what you do there: 2 or 3 plain sentences, specific to it (a walk among 1910s bungalows, a scenic drive, a museum's exhibits, a hike to a viewpoint), true to what you can back up, no hype, no hours or prices. "
                    . "Then which of these activities fit it: walk, drive, hike, exhibits, history, views, water, camp, picnic. If it's a private home, say it's seen from the street. If it may be sacred, a burial or archaeological site, or a nation's ceremonial place, return an empty text and no activities. Never describe the way to such a place. "
                    . "Give the pages you used.\n\n" . $facts,
                    ['type' => 'object', 'additionalProperties' => false, 'required' => ['text', 'activities', 'sources'], 'properties' => ['text' => ['type' => 'string'], 'activities' => ['type' => 'array', 'items' => ['type' => 'string']], 'sources' => ['type' => 'array', 'items' => ['type' => 'string']]]],
                    $fc['model'], max(0, min(1, $fc['searches'])), 1200, 'low');
                AiClient::record($pdo, 'place_about', (int) $id, 'done', $res);
            } catch (Throwable $x) { error_log('place about ' . $id . ': ' . $x->getMessage()); continue; }
            $acts = array_values(array_intersect(array_map('strval', (array) ($res['data']['activities'] ?? [])), array_keys(Landmarks::ACTIVITIES)));
            $pdo->prepare('UPDATE landmarks SET research = ?, research_sources = ?, research_acts = ?, research_at = NOW() WHERE gnis_id = ?')
                ->execute([mb_substr(trim((string) ($res['data']['text'] ?? '')), 0, 1200), json_encode(array_values(array_filter(array_map('strval', (array) ($res['data']['sources'] ?? [])))), JSON_UNESCAPED_SLASHES), $acts ? json_encode($acts) : null, (int) $id]);
            self::index($pdo, (int) $id);
            $done++;
        }
        return $done;
    }

    /**
     * Written ahead (Jason, 2026-11-10, approved as part of "All"): each town's 20 places drawing the most interest that
     * have no Wikipedia summary are queued for aboutTick, so what they're like is ready before anyone opens them. Only
     * while the queue is short (a visitor's open always comes first), $n a run, inside place_about's daily allowance.
     */
    public static function aheadTick(PDO $pdo, int $n = 6): int
    {
        try {
            if ((int) $pdo->query('SELECT COUNT(*) FROM landmarks WHERE about_queued_at IS NOT NULL AND research_at IS NULL')->fetchColumn() >= $n) return 0;
            $rows = $pdo->query("SELECT gnis_id, near_town, state, extract, research_at, about_queued_at FROM landmarks WHERE " . Landmarks::visibleSql() . " AND interest > 0 AND near_town <> '' ORDER BY interest DESC LIMIT 6000")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return 0; }   // before the migrations
        $per = []; $want = [];
        foreach ($rows as $r) {
            $t = mb_strtolower((string) $r['near_town'] . '|' . (string) $r['state']);
            if (($per[$t] = ($per[$t] ?? 0) + 1) > 20) continue;   // the town's top 20 by interest, whether written or not
            if (trim((string) $r['extract']) === '' && $r['research_at'] === null && $r['about_queued_at'] === null) $want[] = (int) $r['gnis_id'];
            if (count($want) >= $n) break;
        }
        foreach ($want as $id) self::wantAbout($pdo, $id);
        return count($want);
    }

    /**
     * How much interest a place draws (2026-11-10: rank things to do by real interest, not distance alone): its Wikipedia
     * article's views over the last 30 days (Wikimedia's free pageview counts), how many Wikipedias cover it (Wikidata's
     * sitelinks), the guides and journeys that name it, and a photo. landmarks.interest, refreshed every 30 days, thirty a
     * run; search and the landmark lists rank by it.
     */
    public static function interestTick(PDO $pdo, int $n = 30): int
    {
        try { $rows = $pdo->query('SELECT gnis_id, qid, wiki_title, image_url FROM landmarks WHERE ' . Landmarks::visibleSql() . ' AND (interest_at IS NULL OR interest_at < NOW() - INTERVAL 30 DAY) ORDER BY interest_at IS NULL DESC, interest_at LIMIT ' . (int) $n)->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable) { return 0; }   // before the migration
        if (!$rows) return 0;
        $sl = [];
        $qids = array_values(array_filter(array_column($rows, 'qid'), fn ($q) => preg_match('/^Q\d+$/', (string) $q)));
        if ($qids) {
            $j = self::get('https://query.wikidata.org/sparql?format=json&query=' . rawurlencode('SELECT ?item ?n WHERE { VALUES ?item { wd:' . implode(' wd:', $qids) . ' } ?item wikibase:sitelinks ?n . }'), 15);
            foreach ((array) ($j['results']['bindings'] ?? []) as $bb) $sl[preg_replace('#^.*/#', '', (string) ($bb['item']['value'] ?? ''))] = (int) ($bb['n']['value'] ?? 0);
        }
        $end = date('Ymd', time() - 86400); $start = date('Ymd', time() - 31 * 86400);
        $up = $pdo->prepare('UPDATE landmarks SET interest = ?, interest_at = NOW() WHERE gnis_id = ?');
        foreach ($rows as $r) {
            $views = 0;
            if ((string) $r['wiki_title'] !== '') {
                $j = self::get('https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/en.wikipedia.org/all-access/user/' . rawurlencode(str_replace(' ', '_', (string) $r['wiki_title'])) . '/daily/' . $start . '/' . $end, 10);
                foreach ((array) ($j['items'] ?? []) as $it) $views += (int) ($it['views'] ?? 0);
            }
            $named = 0;
            try { $st = $pdo->prepare("SELECT COUNT(DISTINCT src) FROM content_tags WHERE ref = ? AND status IN ('linked','thin')"); $st->execute(['landmark:' . (int) $r['gnis_id']]); $named = (int) $st->fetchColumn(); } catch (Throwable) {}
            $score = (int) round(10 * log10(1 + $views / 30)) + min(10, (int) ($sl[(string) $r['qid']] ?? 0)) + 6 * min(3, $named) + ((string) $r['image_url'] !== '' ? 2 : 0);
            $up->execute([$score, (int) $r['gnis_id']]);
            self::index($pdo, (int) $r['gnis_id']);
        }
        return count($rows);
    }

    /** US states by the name Wikidata gives them. */
    private const STATE_CODES = ['Alabama' => 'AL', 'Alaska' => 'AK', 'Arizona' => 'AZ', 'Arkansas' => 'AR', 'California' => 'CA', 'Colorado' => 'CO', 'Connecticut' => 'CT', 'Delaware' => 'DE',
        'Florida' => 'FL', 'Georgia' => 'GA', 'Hawaii' => 'HI', 'Idaho' => 'ID', 'Illinois' => 'IL', 'Indiana' => 'IN', 'Iowa' => 'IA', 'Kansas' => 'KS', 'Kentucky' => 'KY', 'Louisiana' => 'LA',
        'Maine' => 'ME', 'Maryland' => 'MD', 'Massachusetts' => 'MA', 'Michigan' => 'MI', 'Minnesota' => 'MN', 'Mississippi' => 'MS', 'Missouri' => 'MO', 'Montana' => 'MT', 'Nebraska' => 'NE',
        'Nevada' => 'NV', 'New Hampshire' => 'NH', 'New Jersey' => 'NJ', 'New Mexico' => 'NM', 'New York' => 'NY', 'North Carolina' => 'NC', 'North Dakota' => 'ND', 'Ohio' => 'OH', 'Oklahoma' => 'OK',
        'Oregon' => 'OR', 'Pennsylvania' => 'PA', 'Rhode Island' => 'RI', 'South Carolina' => 'SC', 'South Dakota' => 'SD', 'Tennessee' => 'TN', 'Texas' => 'TX', 'Utah' => 'UT', 'Vermont' => 'VT',
        'Virginia' => 'VA', 'Washington' => 'WA', 'West Virginia' => 'WV', 'Wisconsin' => 'WI', 'Wyoming' => 'WY'];

    /**
     * Where a place is, from the source (2026-11-10: Four Corners Monument read "Aneth" from the nearest ZIP, in Utah):
     * the town Wikidata says it's in, and its state (one of ours first when it's on a line between states).
     */
    private static function whereIs(string $qid): array
    {
        $out = ['town' => '', 'state' => '', 'states' => []];
        if (!preg_match('/^Q\d+$/', $qid)) return $out;
        $q = 'SELECT ?inLabel ?inClassLabel ?stLabel WHERE { OPTIONAL { wd:' . $qid . ' wdt:P131 ?in . OPTIONAL { ?in wdt:P31 ?inClass . } } '
           . 'OPTIONAL { wd:' . $qid . ' wdt:P131+ ?st . ?st wdt:P31 wd:Q35657 . } SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . } } LIMIT 200';
        $j = self::get('https://query.wikidata.org/sparql?format=json&query=' . rawurlencode($q), 12);
        foreach ((array) ($j['results']['bindings'] ?? []) as $b) {
            $stName = (string) ($b['stLabel']['value'] ?? '');
            if (isset(self::STATE_CODES[$stName])) $out['states'][self::STATE_CODES[$stName]] = 1;
            $cls = mb_strtolower((string) ($b['inClassLabel']['value'] ?? ''));
            if ($out['town'] === '' && $cls !== '' && (preg_match(self::SETTLEMENT, $cls) || str_contains($cls, 'census-designated'))) $out['town'] = trim((string) ($b['inLabel']['value'] ?? ''));
        }
        $out['states'] = array_keys($out['states']);
        require_once __DIR__ . '/crawler/NpiBulk.php';
        foreach ($out['states'] as $sc) if (in_array($sc, NpiBulk::STATES, true)) { $out['state'] = $sc; break; }
        if ($out['state'] === '' && $out['states']) $out['state'] = $out['states'][0];
        return $out;
    }

    /** The nearest ZIP [zip, city, state, miles], in one of $states when given; null when none is within 30 miles. */
    private static function zipNear(PDO $pdo, float $lat, float $lon, array $states = []): ?array
    {
        $pad = 30 / 60;
        try {
            $st = $pdo->prepare('SELECT zip, city, state, latitude, longitude FROM zip_coordinates WHERE latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ? LIMIT 600');
            $st->execute([$lat - $pad, $lat + $pad, $lon - $pad * 1.3, $lon + $pad * 1.3]);
        } catch (Throwable) { return null; }
        $best = null;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $z) {
            if ($states && !in_array((string) $z['state'], $states, true)) continue;
            $d = Landmarks::miles($lat, $lon, (float) $z['latitude'], (float) $z['longitude']);
            if ($d <= 30 && ($best === null || $d < $best[3])) $best = [substr((string) $z['zip'], 0, 5), (string) $z['city'], (string) $z['state'], $d];
        }
        return $best;
    }

    /**
     * Our landmark for a Wikidata place: the one we have (by its Q id, or the same name in the same spot), else a new one.
     * Its id, or 0. $p is the guide's place when a guide asked (its town counts when the place is in it), else null.
     * Where it is comes from the source first (the town and state Wikidata gives), then the nearest ZIP (one of our
     * states when it's nearly as near: a place on a state line), then the guide's place.
     */
    private static function keep(PDO $pdo, ?array $p, array $it, array &$out): int
    {
        $st = $pdo->prepare('SELECT gnis_id, file, qid FROM landmarks WHERE qid = ? LIMIT 1'); $st->execute([$it['qid']]);
        $have = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$have) {
            $st = $pdo->prepare('SELECT gnis_id, name, file, qid FROM landmarks WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?');   // the same place under another record (its GNIS name, or one added before we knew its Q id)
            $st->execute([$it['lat'] - .01, $it['lat'] + .01, $it['lon'] - .012, $it['lon'] + .012]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (self::same((string) $r['name'], $it['label'])) { $have = $r; break; }
        }
        if ($have && $have['file'] !== 'wikidata') return (int) $have['gnis_id'];   // GNIS's, or a person's: never overwritten
        if ($have && PageCache::get($pdo, 'pf:where:' . $it['qid'])) return (int) $have['gnis_id'];   // placed from the source already (this month)
        $where = self::whereIs($it['qid']);
        $town = $where['town'];
        if ($town === '' && $p && Landmarks::miles((float) $p['lat'], (float) $p['lon'], $it['lat'], $it['lon']) <= 4) $town = (string) $p['name'];   // the guide's own town when it's in it
        if ($town === '' && preg_match('/\bin ([A-Z][\w.\'’ -]{2,40}?), (?:[A-Z][a-z]+ County, )?[A-Z][a-z]+/u', $it['desc'], $dm)) $town = trim($dm[1]);   // "park in Dana Point, Orange County…"
        require_once __DIR__ . '/crawler/NpiBulk.php';
        $z = self::zipNear($pdo, $it['lat'], $it['lon'], $where['state'] !== '' ? [$where['state']] : []);
        if ($where['state'] === '' && $z) {   // nothing from the source: the nearest ZIP, but one of our states when it's nearly as near
            $ours = self::zipNear($pdo, $it['lat'], $it['lon'], NpiBulk::STATES);
            if ($ours && $ours[3] <= $z[3] + 10) $z = $ours;
        }
        $state = $where['state'] !== '' ? $where['state'] : ($z ? $z[2] : (string) ($p['state'] ?? ''));
        if ($town === '' && $z) $town = Guides::townName($z[1]);
        if ($have) {   // ours from Wikidata: placed again from the source
            $pdo->prepare('UPDATE landmarks SET qid = ?, near_town = ?, state = ?, zip5 = ? WHERE gnis_id = ?')->execute([$it['qid'], mb_substr($town, 0, 120), $state, $z ? $z[0] : '', (int) $have['gnis_id']]);
            PageCache::put($pdo, 'pf:where:' . $it['qid'], 30 * 86400, 1);
            self::index($pdo, (int) $have['gnis_id']);
            return (int) $have['gnis_id'];
        }
        $nation = '';
        if (is_file(__DIR__ . '/Nations.php')) { require_once __DIR__ . '/Nations.php'; try { $nation = (string) (Nations::at($pdo, $it['lat'], $it['lon']) ?? ''); } catch (Throwable) {} }
        $v = ['name' => $it['label'], 'fclass' => $it['class'], 'wd_desc' => $it['desc'], 'nation' => $nation, 'wiki_title' => (string) ($it['article'] ?? '')];   // its own article: publicly known (Landmarks::publiclyKnown)
        [$status, $why] = Landmarks::decide($v);
        $extract = $it['article'] !== '' ? self::summary($pdo, $it['article']) : '';
        $id = max(Landmarks::MANUAL_FROM, (int) $pdo->query('SELECT MAX(gnis_id) FROM landmarks')->fetchColumn() + 1);
        $pdo->prepare('INSERT INTO landmarks (gnis_id, name, fclass, state, county, lat, lon, zip5, near_town, nation, qid, wd_desc, wiki_title, extract, image_url, image_page, image_credit, image_license,
                                              status, why, reviewed_by, reviewed_at, review_note, file, loaded_at) VALUES (?, ?, ?, ?, \'\', ?, ?, ?, ?, ?, ?, ?, ?, ?, \'\', \'\', \'\', \'\', ?, ?, NULL, NULL, \'\', \'wikidata\', ?)')
            ->execute([$id, mb_substr($it['label'], 0, 200), mb_substr($it['class'], 0, 60), $state, round($it['lat'], 6), round($it['lon'], 6), $z ? $z[0] : '', mb_substr($town, 0, 120),
                       $nation, $it['qid'], mb_substr($it['desc'], 0, 250), mb_substr($it['article'], 0, 200), mb_substr($extract, 0, 1200), $status, $why, date('Y-m-d H:i:s')]);
        PageCache::put($pdo, 'pf:where:' . $it['qid'], 30 * 86400, 1);
        $out['added']++;
        self::index($pdo, $id);
        return $id;   // the photo finder (landmark_photos_tick) looks for its photo within the hour
    }

    /** Searchable at once (2026-11-10): a place we keep can be found by name. */
    private static function index(PDO $pdo, int $id): void
    {
        if (!is_file(__DIR__ . '/SearchIndex.php')) return;
        require_once __DIR__ . '/SearchIndex.php';
        try { if (SearchIndex::ready($pdo)) SearchIndex::refreshLandmark($pdo, $id); } catch (Throwable $e) { error_log('place index: ' . $e->getMessage()); }
    }

    /** Everything Wikidata places within 15 km that could have a page: [{qid, label, desc, lat, lon, class, article}]. Kept 30 days. */
    public static function near(PDO $pdo, float $lat, float $lon): array
    {
        $ck = 'pf:wd2:' . round($lat, 2) . ',' . round($lon, 2);
        $hit = PageCache::get($pdo, $ck);
        if (is_array($hit)) return $hit;
        $q = 'SELECT ?item ?itemLabel ?itemDescription ?lat ?lon ?classLabel ?article ?nrhp WHERE { '
           . 'SERVICE wikibase:around { ?item wdt:P625 ?loc . bd:serviceParam wikibase:center "Point(' . round($lon, 5) . ' ' . round($lat, 5) . ')"^^geo:wktLiteral . bd:serviceParam wikibase:radius "' . self::RADIUS_KM . '" . } FILTER EXISTS { ?item wdt:P31 ?any } '
           . '?item p:P625/psv:P625 [ wikibase:geoLatitude ?lat ; wikibase:geoLongitude ?lon ] . OPTIONAL { ?item wdt:P31 ?class . } '
           . 'OPTIONAL { ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> . } '
           . 'OPTIONAL { ?item wdt:P649 ?nrhp . } SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . } } LIMIT 8000';
        $out = self::items(self::get('https://query.wikidata.org/sparql?format=json&query=' . rawurlencode($q)));
        if ($out !== null) PageCache::put($pdo, $ck, 30 * 86400, $out);
        return $out ?? [];
    }

    /** The guide's names as Wikidata labels them (or as one of their other names), within 25 km. */
    public static function named(PDO $pdo, array $names, float $lat, float $lon): array
    {
        $names = array_values(array_unique(array_filter(array_map(fn ($n) => trim((string) $n), $names), fn ($n) => mb_strlen($n) >= 3)));
        if (!$names) return [];
        $vals = []; foreach (array_slice($names, 0, 60) as $n) { $vals[] = '"' . addcslashes($n, '"\\') . '"@en'; $alt = preg_replace(['/^St\.? /', '/^the /i'], ['Saint ', ''], $n); if ($alt !== $n) $vals[] = '"' . addcslashes($alt, '"\\') . '"@en'; }
        $q = 'SELECT ?item ?itemLabel ?itemDescription ?lat ?lon ?classLabel ?article ?nrhp WHERE { VALUES ?name { ' . implode(' ', $vals) . ' } '
           . '{ ?item rdfs:label ?name } UNION { ?item skos:altLabel ?name } ?item p:P625/psv:P625 [ wikibase:geoLatitude ?lat ; wikibase:geoLongitude ?lon ] . OPTIONAL { ?item wdt:P31 ?class . } OPTIONAL { ?item wdt:P649 ?nrhp . } '
           . 'OPTIONAL { ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> . } SERVICE wikibase:label { bd:serviceParam wikibase:language "en" . } } LIMIT 3000';
        $out = self::items(self::get('https://query.wikidata.org/sparql?format=json&query=' . rawurlencode($q))) ?? [];
        return array_values(array_filter($out, fn ($it) => Landmarks::miles($lat, $lon, $it['lat'], $it['lon']) <= 15.5));   // about 25 km: a park up the coast, not one of the same name in another state
    }

    /** Wikidata's answer as places that could have a page of their own; null when there was no answer. */
    private static function items(?array $j): ?array
    {
        if (!$j) return null;
        $by = [];
        foreach ((array) ($j['results']['bindings'] ?? []) as $b) {
            $qid = preg_replace('#^.*/#', '', (string) ($b['item']['value'] ?? ''));
            $label = trim((string) ($b['itemLabel']['value'] ?? ''));
            if ($qid === '' || $label === '' || $label === $qid) continue;
            $by[$qid] ??= ['qid' => $qid, 'label' => $label, 'desc' => (string) ($b['itemDescription']['value'] ?? ''), 'lat' => (float) ($b['lat']['value'] ?? 0), 'lon' => (float) ($b['lon']['value'] ?? 0),
                           'classes' => [], 'nrhp' => false, 'article' => isset($b['article']['value']) ? rawurldecode(str_replace('_', ' ', preg_replace('#^https://en\.wikipedia\.org/wiki/#', '', (string) $b['article']['value']))) : ''];
            if (!empty($b['classLabel']['value'])) $by[$qid]['classes'][] = mb_strtolower((string) $b['classLabel']['value']);
            if (!empty($b['nrhp']['value'])) $by[$qid]['nrhp'] = true;   // on the National Register of Historic Places
        }
        $out = [];
        foreach ($by as $it) {
            $cls = array_values(array_unique($it['classes']));
            if (array_filter($cls, fn ($c) => preg_match(self::SETTLEMENT, $c))) continue;   // a town is never a landmark ("Dana Point", the city)
            $keep = array_values(array_filter($cls, fn ($c) => preg_match(self::KEEP, $c)));
            if (!$keep && $it['nrhp']) $keep = ['historic place'];   // on the National Register: a place to visit, whatever else it is
            if (!$keep && ($cls ? true : !preg_match(self::KEEP, $it['label']))) continue;   // its kind must say it's a place to visit; only an item with no kind at all goes by its name
            if (!$keep && array_filter($cls, fn ($c) => preg_match(self::OTHER, $c))) continue;
            $it['class'] = ucfirst($keep[0] ?? 'Landmark');
            unset($it['classes']);
            $out[] = $it;
        }
        return $out;
    }

    /** Wikipedia's summary of the article (CC BY-SA; shown with its credit on the landmark page, as for every landmark). */
    private static function summary(PDO $pdo, string $title): string
    {
        $j = self::get('https://en.wikipedia.org/api/rest_v1/page/summary/' . rawurlencode(str_replace(' ', '_', $title)));
        return trim((string) ($j['extract'] ?? ''));
    }

    /** The same place's name: equal once tidied, or one inside the other when the shorter is two words or more ("Main Beach" / "Main Beach Park"). */
    public static function same(string $a, string $b): bool
    {
        $n = fn ($s) => trim((string) preg_replace(['/\bst\.?\s/i', '/\bmt\.?\s/i', '/^the\s+/i', '/[^a-z0-9 ]+/', '/\s+/'], ['saint ', 'mount ', '', ' ', ' '], mb_strtolower(trim($s))));
        $x = $n($a); $y = $n($b);
        if ($x === '' || $y === '') return false;
        if ($x === $y) return true;
        [$s, $l] = strlen($x) <= strlen($y) ? [$x, $y] : [$y, $x];
        return substr_count($s, ' ') >= 1 && strlen($s) >= 8 && preg_match('/\b' . preg_quote($s, '/') . '\b/', $l) === 1;
    }

    private static function get(string $url, int $timeout = 25): ?array
    {
        if (self::$fetch !== null) return (self::$fetch)($url);
        require_once __DIR__ . '/Automation.php';
        if (Automation::gatheringUrl(null, $url, 'W9') !== null) return null;   // paused (System Configuration → Automation): not asked
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_USERAGENT => self::UA, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
        $raw = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($code !== 200 || !is_string($raw)) { error_log('places on demand: ' . $code . ' ' . mb_substr($url, 0, 120)); return null; }
        $j = json_decode($raw, true);
        return is_array($j) ? $j : null;
    }
}
