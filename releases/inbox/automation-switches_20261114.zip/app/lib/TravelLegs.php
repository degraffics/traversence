<?php
// app/lib/TravelLegs.php — how long it takes to get from one place to another (decisions/0146 §7), kept as our own
// record. A leg is asked for once from openrouteservice (OpenStreetMap data, ODbL: credit "© OpenStreetMap
// contributors" wherever its times show), stored in travel_legs, and reused by every journey, trip and card after.
// Never asked for on a page view: only by the journey job, a whole town at a time (one matrix call). Without a key, past
// the free daily limit, or when the service is down, the time is estimated from the straight line and marked "about".
// Free plan only (no income, no expense): the service stops at its limit and never bills.
// Its address moved to api.heigit.org/openrouteservice in 2026 (api.openrouteservice.org is retired); ORS_API_URL
// in .env overrides it.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/PageCache.php';

final class TravelLegs
{
    /** our word => openrouteservice's profile */
    public const MODES = ['drive' => 'driving-car', 'walk' => 'foot-walking', 'cycle' => 'cycling-regular'];
    /** a straight line this short is a walk */
    public const WALK_MILES = 0.6;
    /** the free plan allows 500 matrices a day; we stop well short of it */
    private const MATRIX_A_DAY = 400;
    /** a matrix takes at most this many places (the free plan's limit is 3,500 pairs) */
    public const MATRIX_MAX = 50;
    /** a leg is asked for again after two years, or when either end has moved this far (km) */
    private const RENEW_DAYS = 730;
    private const MOVED_KM = 0.15;
    private const UA = 'Traversence journeys (support@traversence.com)';

    /** @var callable|null for tests: fn(string $url, array $body): ?array */
    public static $fetch = null;
    private static ?bool $ready = null;

    public static function ready(PDO $pdo): bool
    {
        if (self::$ready !== null) return self::$ready;
        try { $pdo->query('SELECT 1 FROM travel_legs LIMIT 0'); return self::$ready = true; } catch (Throwable) { return self::$ready = false; }
    }

    /** Miles in a straight line. */
    public static function miles(float $la1, float $lo1, float $la2, float $lo2): float
    {
        $dLa = deg2rad($la2 - $la1); $dLo = deg2rad($lo2 - $lo1);
        $a = sin($dLa / 2) ** 2 + cos(deg2rad($la1)) * cos(deg2rad($la2)) * sin($dLo / 2) ** 2;
        return 3959 * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }

    /** Walk when it's close, else drive. */
    public static function modeFor(float $straightMiles): string
    {
        return $straightMiles <= self::WALK_MILES ? 'walk' : 'drive';
    }

    /** An estimate from the straight line: ['minutes', 'meters', 'source' => 'line']. */
    public static function estimate(float $straightMiles, string $mode): array
    {
        if ($mode === 'walk') { $mi = $straightMiles * 1.25; $min = $mi / 3 * 60; }
        elseif ($mode === 'cycle') { $mi = $straightMiles * 1.25; $min = $mi / 10 * 60; }
        else { $mi = $straightMiles * 1.3; $mph = $mi < 3 ? 22 : ($mi < 15 ? 35 : 50); $min = $mi / $mph * 60 + 3; }
        return ['minutes' => round(max(1, $min), 1), 'meters' => (int) round($mi * 1609.34), 'source' => 'line'];
    }

    /**
     * The leg between two points (each ['ref', 'lat', 'lon']): what we hold, else the straight-line estimate.
     * ['minutes', 'meters', 'source' => 'ors'|'line', 'mode']. Never calls out.
     */
    public static function get(PDO $pdo, array $a, array $b, ?string $mode = null): array
    {
        $line = self::miles((float) $a['lat'], (float) $a['lon'], (float) $b['lat'], (float) $b['lon']);
        $mode = $mode ?? self::modeFor($line);
        $held = self::held($pdo, [$a, $b], $mode);
        $leg = $held[$a['ref'] . '>' . $b['ref']] ?? $held[$b['ref'] . '>' . $a['ref']] ?? null;
        return ($leg ?: self::estimate($line, $mode)) + ['mode' => $mode];
    }

    /**
     * Every leg we hold among these points, for this mode: "aRef>bRef" => ['minutes', 'meters', 'source'].
     * A leg whose end has moved, or that's two years old, isn't held.
     */
    public static function held(PDO $pdo, array $points, string $mode): array
    {
        if (!self::ready($pdo) || count($points) < 2) return [];
        $at = [];
        foreach ($points as $p) $at[(string) $p['ref']] = [(float) $p['lat'], (float) $p['lon']];
        $refs = array_keys($at);
        $in = implode(',', array_fill(0, count($refs), '?'));
        try {
            $st = $pdo->prepare("SELECT a_ref, b_ref, minutes, meters, source, a_lat, a_lon, b_lat, b_lon FROM travel_legs WHERE mode = ? AND a_ref IN ($in) AND b_ref IN ($in) AND found_at > ?");
            $st->execute(array_merge([$mode], $refs, $refs, [date('Y-m-d H:i:s', time() - self::RENEW_DAYS * 86400)]));
        } catch (Throwable) { return []; }
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            [$la, $lo] = $at[$r['a_ref']]; [$lb, $ob] = $at[$r['b_ref']];
            if ($r['a_lat'] !== null && self::miles($la, $lo, (float) $r['a_lat'], (float) $r['a_lon']) * 1.609 > self::MOVED_KM) continue;
            if ($r['b_lat'] !== null && self::miles($lb, $ob, (float) $r['b_lat'], (float) $r['b_lon']) * 1.609 > self::MOVED_KM) continue;
            $out[$r['a_ref'] . '>' . $r['b_ref']] = ['minutes' => (float) $r['minutes'], 'meters' => (int) $r['meters'], 'source' => (string) $r['source']];
        }
        return $out;
    }

    /**
     * Fill in the legs we don't hold among these points (a town's places), with one matrix call for the mode. Returns
     * how many legs were stored; 0 when nothing was missing, there's no key, the day's allowance is used, or it failed.
     */
    public static function prepare(PDO $pdo, array $points, string $mode = 'drive'): int
    {
        if (!self::ready($pdo) || !isset(self::MODES[$mode])) return 0;
        $pts = []; foreach ($points as $p) if (isset($p['ref'], $p['lat'], $p['lon']) && $p['lat'] !== null) $pts[(string) $p['ref']] = $p;
        $pts = array_slice(array_values($pts), 0, self::MATRIX_MAX);
        if (count($pts) < 2) return 0;
        $held = self::held($pdo, $pts, $mode);
        $missing = false;
        foreach ($pts as $i => $a) { foreach ($pts as $j => $b) if ($i !== $j && !isset($held[$a['ref'] . '>' . $b['ref']])) { $missing = true; break 2; } }
        if (!$missing || !self::canAsk($pdo)) return 0;
        $base = rtrim(self::env('ORS_API_URL') ?: 'https://api.heigit.org/openrouteservice', '/');
        $body = ['locations' => array_map(fn ($p) => [round((float) $p['lon'], 6), round((float) $p['lat'], 6)], $pts), 'metrics' => ['duration', 'distance'], 'units' => 'm'];
        $r = self::post($pdo, $base . '/v2/matrix/' . self::MODES[$mode], $body);
        if (!$r || !isset($r['durations'])) return 0;
        $now = date('Y-m-d H:i:s'); $n = 0;
        $st = $pdo->prepare('REPLACE INTO travel_legs (a_ref, b_ref, mode, minutes, meters, source, a_lat, a_lon, b_lat, b_lon, found_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        foreach ($pts as $i => $a) foreach ($pts as $j => $b) {
            if ($i === $j) continue;
            $sec = $r['durations'][$i][$j] ?? null; $m = $r['distances'][$i][$j] ?? null;
            if ($sec === null || $m === null) continue;   // no road between them
            $st->execute([$a['ref'], $b['ref'], $mode, round((float) $sec / 60, 1), (int) round((float) $m), 'ors', $a['lat'], $a['lon'], $b['lat'], $b['lon'], $now]);
            $n++;
        }
        return $n;
    }

    /** True while we may ask the service today: a key, under our daily share, and not told to stop. */
    public static function canAsk(PDO $pdo): bool
    {
        if (self::$fetch === null && self::env('ORS_API_KEY') === '') return false;
        if (PageCache::get($pdo, 'ors:stop:' . date('Y-m-d'))) return false;
        return (int) (PageCache::get($pdo, 'ors:matrix:' . date('Y-m-d')) ?: 0) < self::MATRIX_A_DAY;
    }

    /** Today's matrix calls and whether we've been told to stop (for Insights and tests). */
    public static function today(PDO $pdo): array
    {
        return ['matrix' => (int) (PageCache::get($pdo, 'ors:matrix:' . date('Y-m-d')) ?: 0), 'limit' => self::MATRIX_A_DAY, 'stopped' => (bool) PageCache::get($pdo, 'ors:stop:' . date('Y-m-d'))];
    }

    private static function post(PDO $pdo, string $url, array $body): ?array
    {
        require_once __DIR__ . '/Automation.php';
        if (self::$fetch === null && Automation::gatheringUrl($pdo, $url, 'W7') !== null) return null;   // paused (System Configuration → Automation): not asked, not counted
        $day = date('Y-m-d');
        PageCache::put($pdo, 'ors:matrix:' . $day, 90000, (int) (PageCache::get($pdo, 'ors:matrix:' . $day) ?: 0) + 1);
        if (self::$fetch !== null) return (self::$fetch)($url, $body);
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($body), CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_HTTPHEADER => ['Authorization: ' . self::env('ORS_API_KEY'), 'Content-Type: application/json', 'Accept: application/json'], CURLOPT_USERAGENT => self::UA]);
        $out = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($code === 403 || $code === 429) { PageCache::put($pdo, 'ors:stop:' . $day, 90000, 1); error_log('TravelLegs: openrouteservice said ' . $code . '; estimates until tomorrow'); return null; }
        if ($code !== 200 || !is_string($out)) { error_log('TravelLegs: openrouteservice ' . $code); return null; }
        $j = json_decode($out, true);
        return is_array($j) ? $j : null;
    }

    private static function env(string $k): string
    {
        Database::readEnv();
        return trim((string) (getenv($k) ?: ''));
    }
}
