<?php
// app/lib/crawler/SecondTier.php — the paid second tier, where the free steps fall short (decisions/0157). Two of its steps
// run here, each an AI feature in System Configuration → AI use, off until Jason switches it on and sets its budget (CLAUDE.md
// "No income, no expense"), within the month's AI cap:
//   source_terms   a site waiting for a call (a chamber, a tourism site, an organization): Claude reads its terms and what it
//                  says it is, and decides read regularly or cite only. It counts only with the exact sentence it relied
//                  on, found in the terms the worker read.
//   page_extract   a page that matters (one of a read source's) our fetch couldn't get, or that shows nothing without a
//                  browser: the worker asks Tavily Extract for its text, as many a day as this allows (never a page
//                  robots.txt or the site refuses). About $0.0016 a page.
//   scan_read      a scanned PDF (pictures of pages, no text) on a source we read: AWS Textract reads it here (one page
//                  at a time for now), and the worker reads its text into places like any page. About $0.0015 a page.
//   find_settle    a find the free steps couldn't settle (waiting in Review after the second look): Claude looks it up on
//                  the web and says open, closed or not found, each with its sources and the words on them. A source counts
//                  only when its words are on its page (the site fetches the page and looks); then the find is published
//                  through the usual guardrails (decisions/0044), or turned down as closed, with the reasons and sources kept
//                  on it (undoable in Review). What it couldn't settle stays for a person.
// Never for tribal nations' sites or places on their land, or places whose location is kept private (decisions/0066, 0044).
declare(strict_types=1);

require_once __DIR__ . '/../AiClient.php';
require_once __DIR__ . '/Sources.php';

final class SecondTier
{
    /** Words that say a place has closed for good. */
    private const CLOSED = '/\b(permanently closed|closed permanently|closed for good|has closed|have closed|is closed|out of business|no longer (open|in business|operating)|ceased operations|closing (its|our) doors)\b/i';

    private static function norm(string $s): string { return trim((string) preg_replace('/\s+/u', ' ', mb_strtolower(html_entity_decode(strip_tags((string) preg_replace('/<[^>]*>/', ' $0 ', $s)), ENT_QUOTES)))); }   // tags apart: "<b>Name</b><br>12 Main" reads "Name 12 Main"

    /** Is the quote (most of it, in order) in the text? Quotes are trimmed of their ends; a short one must be whole. */
    public static function quoted(string $quote, string $text): bool
    {
        $q = self::norm($quote); $t = self::norm($text);
        if (mb_strlen($q) < 12) return false;
        if (str_contains($t, $q)) return true;
        $q = trim((string) preg_replace('/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/u', '', $q));   // its quotation marks, a trailing period
        return mb_strlen($q) >= 12 && str_contains(preg_replace('/[^\p{L}\p{N} ]+/u', '', $t), preg_replace('/[^\p{L}\p{N} ]+/u', '', $q));
    }

    // ---- source_terms ---------------------------------------------------------------------------------------------------

    /**
     * A waiting site's call from its terms (decisions/0157 §7.1): ['decided' => bool, 'why' => …]. $terms: the text of its
     * terms page as the worker read it; $about: what it says it is.
     */
    public static function judgeTerms(PDO $pdo, string $host, string $about, string $terms, string $termsUrl): array
    {
        Sources::ensureJudge($pdo);
        $host = Sources::host('https://' . preg_replace('#^https?://#i', '', trim($host)));
        if (Sources::judgeOf($host, '', $about) !== null) return ['decided' => false, 'why' => 'Decided by its address or description.'];
        if (preg_match('/(-nsn\.gov$|tribe|tribal|navajo|hopi|zuni|pueblo|tohono|pascua|yavapai|hualapai|havasupai)/i', $host) || preg_match('/\b(tribe|tribal|nation\b(?!al)|pueblo|reservation)\b/i', $about))
            return ['decided' => false, 'why' => 'A tribal nation\'s site: a person decides (decisions/0066).'];
        $terms = mb_substr(trim($terms), 0, 12000);
        if (mb_strlen($terms) < 80) return ['decided' => false, 'why' => 'No terms page to read.'];
        [$ok, $why] = AiClient::allow($pdo, 'source_terms');
        if (!$ok) return ['decided' => false, 'why' => $why];
        $st = $pdo->prepare('SELECT id, status, judged_by FROM ' . Database::t('reference_sources') . ' WHERE host = ?'); $st->execute([$host]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row || $row['status'] !== 'suggested' || $row['judged_by'] !== null) return ['decided' => false, 'why' => 'Not waiting for a call.'];
        $f = AiClient::feature($pdo, 'source_terms');
        $schema = ['type' => 'object', 'additionalProperties' => false, 'required' => ['decision', 'licence', 'quote', 'reason'], 'properties' => [
            'decision' => ['type' => 'string', 'enum' => ['read', 'cite_only', 'unsure']],
            'licence' => ['type' => 'string', 'enum' => array_keys(Sources::LICENCES)],
            'quote' => ['type' => 'string'], 'reason' => ['type' => 'string']]];
        $ask = "A local directory (Traversence) reads public websites for the facts about places they name (a business's name, address, phone and hours), keeps those facts with a link to the page, and shows them with credit. It never copies whole pages, articles or photos.\n\n"
            . "Website: $host\nWhat it says it is: " . ($about !== '' ? $about : '(nothing)') . "\nIts terms page ($termsUrl):\n\"\"\"\n$terms\n\"\"\"\n\n"
            . "Decide from these terms only:\n- read: the terms allow reading its pages for facts like these (or say nothing against it).\n- cite_only: the terms forbid automated reading, scraping, copying or reuse of their listings or data.\n- unsure: the terms are unclear.\n"
            . "Give the licence that fits (public_domain, cc_by, cc_by_sa, cc0, odbl, terms when they restrict use, unknown) and quote, word for word, the one sentence of the terms your decision rests on. Explain in one plain sentence.";
        try {
            $r = AiClient::claudeAsk($ask, $schema, (string) $f['model'], 0, 600, 'low');
            AiClient::record($pdo, 'source_terms', (int) $row['id'], 'done', $r);
        } catch (Throwable $e) {
            AiClient::record($pdo, 'source_terms', (int) $row['id'], 'failed', ['error' => $e->getMessage()]);
            return ['decided' => false, 'why' => $e->getMessage()];
        }
        $d = $r['data'];
        if (($d['decision'] ?? 'unsure') === 'unsure') return ['decided' => false, 'why' => 'Claude wasn\'t sure: ' . (string) ($d['reason'] ?? '')];
        if (!self::quoted((string) ($d['quote'] ?? ''), $terms)) return ['decided' => false, 'why' => 'Its quote isn\'t in the terms: not used.'];
        $status = $d['decision'] === 'read' ? 'read' : 'cite_only';
        $lic = isset(Sources::LICENCES[$d['licence'] ?? '']) ? (string) $d['licence'] : 'unknown';
        if ($status === 'cite_only') $lic = 'terms';
        $why = 'Its terms (read by Claude): "' . mb_strimwidth(trim((string) $d['quote']), 0, 150, '…') . '" ' . mb_strimwidth((string) ($d['reason'] ?? ''), 0, 80, '…');
        $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET status = ?, judged_by = 'claude', judged_why = ? WHERE id = ? AND status = 'suggested' AND judged_by IS NULL")
            ->execute([$status, mb_substr($why, 0, 255), (int) $row['id']]);
        // its rules, unless a person set them: what we may do with it follows the call
        try {
            if (Sources::rulesReady($pdo))
                $pdo->prepare('INSERT IGNORE INTO ' . Database::t('source_rules') . ' (host, licence, use_rule, credit_line, limits, refresh_days, terms_url, terms_checked_at, checked_by) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL)')
                    ->execute([$host, $lic, $status === 'read' ? 'facts' : 'cite', '', '', null, mb_substr($termsUrl, 0, 500)]);
        } catch (Throwable $e) { error_log('SecondTier rules: ' . $e->getMessage()); }
        return ['decided' => true, 'why' => $why, 'status' => $status];
    }

    // ---- page_extract and scan_read: the paid reads of pages (decisions/0157 §1, §7.2) --------------------------------------

    /** Tavily Extract's price for one page (basic: a credit per five pages, about $0.008 a credit). */
    private const EXTRACT_MICROS = 1600;
    /** AWS Textract's price for one page of text (Detect Document Text, $1.50 per 1,000 pages). */
    private const SCAN_MICROS = 1500;

    /**
     * How many pages the worker may have Tavily read this run: "Pages a crawler run" in AI use (the feature's per-run
     * field, 1 to 20; 0 counts as 3), within its pages a day and its budget.
     */
    public static function extractAllowance(PDO $pdo): int
    {
        [$ok] = AiClient::allow($pdo, 'page_extract');
        if (!$ok) return 0;
        $f = AiClient::feature($pdo, 'page_extract'); $u = AiClient::used($pdo, 'page_extract');
        $left = $f['per_day'] > 0 ? max(0, $f['per_day'] - $u['today']) : 20;
        $per = (int) $f['searches'] > 0 ? min(20, (int) $f['searches']) : 3;   // 0 (or saved before this was a setting): 3; switch the feature off to stop it
        return min($per, $left);
    }

    /**
     * The pages Tavily read for the worker: each counted, with its cost, so the budget and the month's cap see it; and
     * their credits (one for every five pages) against the search plan's month, which Tavily bills from the same
     * allowance (review D17, 2026-11-13: only 10 were counted while 20 are allowed, and none against the plan).
     */
    public static function recordExtracts(PDO $pdo, int $n): void
    {
        $n = max(0, min(50, $n));
        for ($i = 0; $i < $n; $i++) AiClient::record($pdo, 'page_extract', 0, 'done', ['provider' => 'tavily', 'model' => 'extract', 'micros' => self::EXTRACT_MICROS]);
        if ($n > 0) {
            try {
                require_once dirname(__DIR__) . '/SearchIndex.php';
                $credits = (int) ceil($n / 5); $month = date('Y-m'); $day = date('Y-m-d');
                $used = SearchIndex::state($pdo, 'websearch_month') === $month ? (int) SearchIndex::state($pdo, 'websearch_used') : 0;
                $dayUsed = SearchIndex::state($pdo, 'websearch_day') === $day ? (int) SearchIndex::state($pdo, 'websearch_day_used') : 0;
                SearchIndex::setState($pdo, 'websearch_month', $month); SearchIndex::setState($pdo, 'websearch_used', (string) ($used + $credits));
                SearchIndex::setState($pdo, 'websearch_day', $day); SearchIndex::setState($pdo, 'websearch_day_used', (string) ($dayUsed + $credits));
            } catch (Throwable $e) { error_log('extract credits: ' . $e->getMessage()); }
        }
    }

    /**
     * Reads a few scanned PDFs with AWS Textract (the listings pipeline runs it): those on sources we read, not read yet (or
     * read over 90 days ago). Their text waits on the page log for the worker, which reads it into places. Returns how many.
     */
    public static function scanTick(PDO $pdo, int $max = 2): int
    {
        require_once dirname(__DIR__) . '/Aws.php';
        if (!Aws::on()) return 0;
        require_once __DIR__ . '/SourceIndex.php';
        SourceIndex::ensure($pdo);
        $P = Database::t('crawl_pages'); $R = Database::t('reference_sources');
        try {
            $rows = $pdo->query("SELECT p.id, p.url FROM $P p JOIN $R r ON r.host = p.host AND r.status = 'read'
                                  WHERE p.page_kind = 'scan' AND p.scan_text IS NULL AND (p.scan_at IS NULL OR p.scan_at < NOW() - INTERVAL 90 DAY)
                                  ORDER BY p.scan_at IS NULL DESC, p.id LIMIT " . (int) $max)->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { return 0; }
        $n = 0;
        foreach ($rows as $r) {
            [$ok] = AiClient::allow($pdo, 'scan_read'); if (!$ok) break;
            $pdo->prepare("UPDATE $P SET scan_at = NOW() WHERE id = ?")->execute([(int) $r['id']]);   // tried: not again for 90 days, whatever happens
            $pdf = self::fetch((string) $r['url'], true);
            if ($pdf === null || strlen($pdf) > 5000000) continue;
            [$code, $body] = Aws::request('POST', 'textract', 'textract.' . Aws::region() . '.amazonaws.com', '/', json_encode(['Document' => ['Bytes' => base64_encode($pdf)]]),
                ['content-type' => 'application/x-amz-json-1.1', 'x-amz-target' => 'Textract.DetectDocumentText']);
            $j = json_decode($body, true) ?: [];
            if ($code !== 200) {   // more than one page (it reads one at a time this way) or a file it can't read: left, said why
                AiClient::record($pdo, 'scan_read', (int) $r['id'], 'failed', ['provider' => 'aws', 'model' => 'textract', 'error' => mb_substr((string) ($j['__type'] ?? $j['message'] ?? 'error ' . $code), 0, 200)]);
                continue;
            }
            $lines = [];
            foreach ((array) ($j['Blocks'] ?? []) as $b) if (($b['BlockType'] ?? '') === 'LINE' && trim((string) ($b['Text'] ?? '')) !== '') $lines[] = trim((string) $b['Text']);
            $pages = max(1, (int) ($j['DocumentMetadata']['Pages'] ?? 1));
            AiClient::record($pdo, 'scan_read', (int) $r['id'], 'done', ['provider' => 'aws', 'model' => 'textract', 'micros' => self::SCAN_MICROS * $pages]);
            if ($lines) { $pdo->prepare("UPDATE $P SET scan_text = ? WHERE id = ?")->execute([mb_substr(implode("\n", $lines), 0, 200000), (int) $r['id']]); $n++; }
        }
        return $n;
    }

    /** Scans Textract read whose text waits for the worker: [['host', 'url', 'text']], at most $max. */
    public static function scansToRead(PDO $pdo, int $max = 3): array
    {
        try {
            $st = $pdo->query('SELECT host, url, scan_text FROM ' . Database::t('crawl_pages') . " WHERE scan_text IS NOT NULL AND scan_text <> '' ORDER BY scan_at LIMIT " . (int) $max);
            return array_map(fn ($r) => ['host' => (string) $r['host'], 'url' => (string) $r['url'], 'text' => (string) $r['scan_text']], $st->fetchAll(PDO::FETCH_ASSOC));
        } catch (Throwable $e) { return []; }
    }

    // ---- find_settle ----------------------------------------------------------------------------------------------------

    /**
     * Settles a few finds the free steps couldn't (the listings pipeline runs it): waiting in Review, their second look done,
     * not yet settled, nearest to publishing first. Returns ['published', 'closed', 'unsure', 'why'].
     */
    public static function settleTick(PDO $pdo, int $max = 3): array
    {
        $out = ['published' => 0, 'closed' => 0, 'unsure' => 0, 'why' => ''];
        [$ok, $why] = AiClient::allow($pdo, 'find_settle');
        if (!$ok) { $out['why'] = $why; return $out; }
        try {
            $st = $pdo->query("SELECT id, raw_payload FROM " . Database::t('crawler_raw_index') . " WHERE status = 'staged' AND raw_payload LIKE '%\"done_at\"%'
                                 AND raw_payload NOT LIKE '%\"settle\"%' ORDER BY confidence_score DESC, id DESC LIMIT 40");
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { $out['why'] = $e->getMessage(); return $out; }
        $n = 0;
        foreach ($rows as $r) {
            if ($n >= $max) break;
            $c = json_decode((string) $r['raw_payload'], true);
            if (!is_array($c) || empty($c['verify']['done_at']) || !self::mayDecide($pdo, $c)) continue;
            [$ok] = AiClient::allow($pdo, 'find_settle'); if (!$ok) break;   // its daily runs or budget, between finds
            $n++;
            $res = self::settle($pdo, (int) $r['id'], $c);
            $out[$res] = ($out[$res] ?? 0) + 1;
        }
        return $out;
    }

    /** Never a machine's call: places whose location is kept private, kinds a person reviews, places on a nation's land. */
    private static function mayDecide(PDO $pdo, array $c): bool
    {
        try {
            require_once __DIR__ . '/../ListingSafety.php';
            $cat = isset($c['category_id']) ? (int) $c['category_id'] : (isset($c['suggest']['category_id']) ? (int) $c['suggest']['category_id'] : null);
            if (ListingSafety::isConfidential($cat, (string) ($c['name'] ?? '')) || ($cat !== null && ListingSafety::needsHumanReview($cat))) return false;
            $zip = (string) ($c['where']['zip'] ?? '');
            if ($zip !== '' && is_file(__DIR__ . '/../Nations.php')) {
                require_once __DIR__ . '/../Nations.php';
                $z = $pdo->prepare('SELECT latitude, longitude FROM zip_coordinates WHERE zip = ? LIMIT 1'); $z->execute([$zip]);
                if (($p = $z->fetch(PDO::FETCH_NUM)) && $p[0] !== null && Nations::ready($pdo) && Nations::at($pdo, (float) $p[0], (float) $p[1]) !== null) return false;
            }
        } catch (Throwable $e) { return false; }
        return true;
    }

    /** One find: Claude looks it up; its sources are checked on their pages; then published, turned down as closed, or left. */
    private static function settle(PDO $pdo, int $rowId, array $c): string
    {
        $f = AiClient::feature($pdo, 'find_settle');
        $name = (string) ($c['name'] ?? ''); $w = (array) ($c['where'] ?? []);
        $addr = trim(implode(', ', array_filter([(string) ($w['address'] ?? ''), (string) ($w['city'] ?? ''), trim(($w['state'] ?? '') . ' ' . ($w['zip'] ?? ''))])));
        $phone = (string) ($c['actions']['phone'] ?? '');
        $schema = ['type' => 'object', 'additionalProperties' => false, 'required' => ['status', 'sources', 'reason'], 'properties' => [
            'status' => ['type' => 'string', 'enum' => ['open', 'closed', 'not_found', 'unsure']],
            'sources' => ['type' => 'array', 'items' => ['type' => 'object', 'additionalProperties' => false, 'required' => ['url', 'quote'], 'properties' => ['url' => ['type' => 'string'], 'quote' => ['type' => 'string']]]],
            'phone' => ['type' => 'string'], 'website' => ['type' => 'string'], 'reason' => ['type' => 'string']]];
        $ask = "Is this local business real, and open at this place today?\n\nName: $name\nWhere: " . ($addr !== '' ? $addr : '(no street address)') . "\nPhone: " . ($phone !== '' ? $phone : '(none)') . "\n\n"
            . "Search the web. Answer open (it operates there now), closed (it has closed for good), not_found, or unsure. For each source give its page address and, word for word, the words on that page that show it: its name with its street address or phone (for open), or that it closed (for closed). Pages that are the business's own site, a government page, a chamber of commerce or a news report are best; never invent a page or words. Give its phone and website if a source shows them. One plain sentence of reasons.";
        try {
            $r = AiClient::claudeAsk($ask, $schema, (string) $f['model'], max(1, min(5, (int) $f['searches'] ?: 3)), 1500, 'low');
            AiClient::record($pdo, 'find_settle', $rowId, 'done', $r);
        } catch (Throwable $e) {
            AiClient::record($pdo, 'find_settle', $rowId, 'failed', ['error' => $e->getMessage()]);
            return 'unsure';
        }
        $d = $r['data'];
        // each source: its words must be on its page (fetched here, a few seconds each)
        $good = [];
        foreach (array_slice((array) ($d['sources'] ?? []), 0, 4) as $s) {
            $url = (string) ($s['url'] ?? ''); $q = (string) ($s['quote'] ?? '');
            if (!preg_match('#^https?://#i', $url) || $q === '') continue;
            $page = self::fetch($url);
            if ($page !== null && self::quoted($q, $page)) $good[] = ['url' => $url, 'quote' => $q];
        }
        $status = (string) ($d['status'] ?? 'unsure');
        $settle = ['at' => date('c'), 'status' => $status, 'reason' => mb_substr((string) ($d['reason'] ?? ''), 0, 300), 'sources' => $good, 'by' => 'claude'];
        $digits = substr((string) preg_replace('/\D/', '', $phone), -10);
        preg_match('/^\s*(\d+)/', (string) ($w['address'] ?? ''), $hn);
        if ($status === 'closed') {
            $proof = array_values(array_filter($good, fn ($g) => preg_match(self::CLOSED, $g['quote'])));
            if ($proof) {
                $c['settle'] = $settle + ['decided' => 'closed'];
                self::save($pdo, $rowId, $c);
                require_once __DIR__ . '/IntakeStager.php';
                try { IntakeStager::reject($pdo, $rowId, 'Closed, per ' . $proof[0]['url'] . ': "' . mb_strimwidth($proof[0]['quote'], 0, 200, '…') . '" (checked by Claude, decisions/0157; undo in Review)', null); } catch (Throwable $e) {}
                return 'closed';
            }
        }
        if ($status === 'open') {
            // a source counts as a reference when its words show the name with the phone or the house number (as the second look's)
            $found = [];
            foreach ($good as $g) {
                $qd = (string) preg_replace('/\D/', '', $g['quote']);
                $byPhone = strlen($digits) === 10 && str_contains($qd, $digits);
                $byAddr = !empty($hn[1]) && preg_match('/\b' . preg_quote($hn[1], '/') . '\b/', $g['quote']);
                if (!$byPhone && !$byAddr) continue;
                $host = Sources::host($g['url']);
                $kind = preg_match('/\.(gov|[a-z]{2}\.us)$/', $host) ? 'government' : (str_contains($host, 'chamber') ? 'chamber' : 'website');
                $found[] = ['url' => $g['url'], 'kind' => $kind, 'evidence' => $byPhone && $byAddr ? 'both' : ($byPhone ? 'phone' : 'address'),
                            'label' => 'Found by Claude: ' . mb_strimwidth($g['quote'], 0, 100, '…'), 'phone' => (string) ($d['phone'] ?? '')];
            }
            $c['settle'] = $settle + ['decided' => $found ? 'references' : 'unsure'];
            self::save($pdo, $rowId, $c);
            if ($found) {
                require_once __DIR__ . '/Verify.php';
                try { $v = Verify::complete($pdo, $rowId, $found, ['claude']); return !empty($v['auto_imported']) ? 'published' : 'unsure'; } catch (Throwable $e) { error_log('settle complete: ' . $e->getMessage()); }
            }
            return 'unsure';
        }
        $c['settle'] = $settle + ['decided' => 'unsure'];
        self::save($pdo, $rowId, $c);
        return 'unsure';
    }

    private static function save(PDO $pdo, int $rowId, array $c): void
    {
        $pdo->prepare('UPDATE ' . Database::t('crawler_raw_index') . ' SET raw_payload = ? WHERE id = ?')->execute([json_encode($c, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $rowId]);
    }

    /**
     * One page's text, politely (8 seconds, 1 MB), or null. Only a public website: an address that leads to a private or
     * reserved network is refused, and redirects aren't followed (a page that moved doesn't count).
     */
    private static function fetch(string $url, bool $raw = false): ?string
    {
        if (!function_exists('curl_init')) return null;
        require_once __DIR__ . '/../Automation.php';
        if (Automation::gatheringUrl(null, $url) !== null) return null;   // paused (System Configuration → Automation): not fetched
        $p = parse_url($url);
        $host = strtolower((string) ($p['host'] ?? ''));
        if (!in_array(strtolower((string) ($p['scheme'] ?? '')), ['http', 'https'], true) || $host === '' || isset($p['user']) || isset($p['port']) && !in_array((int) $p['port'], [80, 443], true)) return null;
        $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : gethostbyname($host);
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return null;
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => $raw ? 20 : 8, CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_RESOLVE => [$host . ':' . (($p['scheme'] ?? '') === 'http' ? 80 : 443) . ':' . $ip],   // the address checked is the one used
            CURLOPT_USERAGENT => 'TraversenceCrawler/1.0 (+https://traversence.com)', CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_HTTPHEADER => [$raw ? 'Accept: application/pdf' : 'Accept: text/html,application/xhtml+xml']] + ($raw ? [] : [CURLOPT_RANGE => '0-1000000']));
        $res = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if (!is_string($res) || $code < 200 || $code >= 300) return null;
        if ($raw) return $res;
        return (string) preg_replace('/<(script|style)\b[^>]*>.*?<\/\1>/is', ' ', $res);
    }
}
