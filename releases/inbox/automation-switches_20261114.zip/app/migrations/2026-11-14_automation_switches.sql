-- The automation switches (Jason, 2026-11-14; System Configuration → Automation; decisions/0163 §9): the master switch
-- and each outside service's pause (automation_switches), their history (automation_log), who switched a capture task
-- off and why (crawl_capture_tasks.off_*), and every workflow W1–W13 as a row of crawl_workflows, the website's own
-- included, so each can be paused. Seeds the master OFF: "Paused by Jason, 2026-11-14, until the crawler review".
-- Safe to run twice: INSERT IGNORE keeps any switch a person has changed since, and the columns are added only when missing.
CREATE TABLE IF NOT EXISTS automation_switches (
  kind VARCHAR(10) NOT NULL,
  ref VARCHAR(40) NOT NULL,
  paused TINYINT(1) NOT NULL DEFAULT 0,
  why VARCHAR(255) NULL,
  by_uid INT UNSIGNED NULL,
  by_name VARCHAR(80) NULL,
  at DATETIME NULL,
  PRIMARY KEY (kind, ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO automation_switches (kind, ref, paused, why, by_uid, by_name, at) VALUES
  ('master', 'all', 1, 'Paused by Jason, 2026-11-14, until the crawler review', NULL, 'Jason', UTC_TIMESTAMP());

CREATE TABLE IF NOT EXISTS automation_log (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  at DATETIME NOT NULL,
  kind VARCHAR(10) NOT NULL,
  ref VARCHAR(40) NOT NULL,
  paused TINYINT(1) NOT NULL,
  why VARCHAR(255) NULL,
  by_uid INT UNSIGNED NULL,
  by_name VARCHAR(80) NULL,
  KEY idx_al_ref (kind, ref, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO automation_log (at, kind, ref, paused, why, by_uid, by_name)
  SELECT UTC_TIMESTAMP(), 'master', 'all', 1, 'Paused by Jason, 2026-11-14, until the crawler review', NULL, 'Jason' FROM DUAL
  WHERE NOT EXISTS (SELECT 1 FROM automation_log WHERE kind = 'master');

SET @s = (SELECT IF(COUNT(*) = 0 AND (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crawl_capture_tasks') = 1,
  'ALTER TABLE crawl_capture_tasks ADD COLUMN off_why VARCHAR(255) DEFAULT NULL, ADD COLUMN off_by INT UNSIGNED DEFAULT NULL, ADD COLUMN off_at DATETIME DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crawl_capture_tasks' AND COLUMN_NAME = 'off_why');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

-- every workflow a row, so the website's own (W4, W5, W7, W8, W10, W13) can be paused too, existing rows kept as they are
SET @s = (SELECT IF(COUNT(*) = 1,
  'INSERT IGNORE INTO crawl_workflows (wf, name, share_pct, paused, updated_at) VALUES (''W1'', ''Listings'', 0, 0, NOW()), (''W2'', ''Keeping listings current'', 0, 0, NOW()), (''W3'', ''Sources and the place store'', 0, 0, NOW()), (''W4'', ''Place guides'', 0, 0, NOW()), (''W5'', ''Guides on demand'', 0, 0, NOW()), (''W6'', ''Heritage and topics'', 0, 0, NOW()), (''W7'', ''Suggested journeys'', 0, 0, NOW()), (''W8'', ''Find it'', 0, 0, NOW()), (''W9'', ''Landmarks and places on demand'', 0, 0, NOW()), (''W10'', ''Live events'', 0, 0, NOW()), (''W11'', ''How-to guides'', 0, 0, NOW()), (''W12'', ''Search learning'', 0, 0, NOW()), (''W13'', ''Stories'', 0, 0, NOW())',
  'DO 0') FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crawl_workflows');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
