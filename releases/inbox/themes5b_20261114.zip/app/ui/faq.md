<!--
  Traversence FAQ: the one source. The site renders this file at /faq.php (copied to website/includes/faq.md).
  Format: "## Topic", then "### Question" with its answer below (paragraphs and "- " lists; **bold** and [links](/path) work).
  Keep it in plain words, from a visitor's point of view. Add or update entries with every build (see CLAUDE.md).
  Questions about things not built yet say so ("coming") rather than being left out.
-->

## Getting started

### What is Traversence?
Traversence is a regional travel guide and local directory in one place. **Let's Explore** tells the story of a place and the journeys people take there. **Get Local** is the directory of businesses, services and places. You can use both without an account.

### What's on the home page?
The search comes first, in two parts: **Discover more** (type what you're after) and **Let's get local** (where: tap it and the search's window opens at the place picker, to pick a town, ZIP or area and **Distance**, how far around it to look; or tap the target to use your location. It then shows the place you're searching). Searching opens its own window over the page, with its own box for your words, the place you're searching (tap it and the place and Distance open right there in the same window, in place of the results; pick a place, or tap it again or × to go back) and the results, so nothing behind it gets in the way. On a phone it fills the screen. Pick a result, or click outside the window, tap ×, or press Esc to close it. Then:
- **Four ways in**, one for each main section: **Let's Explore** (places, trails, history), **Get Local** (businesses and services), **Connect** (groups) and the **Marketplace**.
- **Community Groups** on Connect. Next to the groups already running are a few a place usually needs but doesn't have yet (your town's neighbors, the outdoors, local history, families, volunteers, business owners), each with **Start this group**.
- **Events** near you, from the places' own calendars. Until there are enough, a few cards marked **Sample** show how events will look. Buying tickets is coming.
- **What's new**, newest first, with five tabs: **Events**, **Deals**, **Gallery** (public photo albums), **Journey** (journeys and guides) and **Business** (businesses run by their owners). Tap a tab to see only that kind, and again to see everything. Deals from businesses are coming.
- **Have a GO Code?**: type the code from a sign or flyer to open its page.

Nothing on the home page is paid placement: it's newest first.

### How do I contact Traversence?
Email **support@traversence.com**. It's at the foot of every page, and in the emails we send you (or just reply to one of them: replies come to us too). Ask anything: your account, a listing, a GO Code order, or your privacy and data.

### Where did the big logo and icons at the top go?
The top bar starts collapsed, so the page gets the whole screen: no bar, just the compass in the top-left corner and the menu (☰) hanging from the top-right corner, with search between them on pages that have it (on the home page the search sits in the page itself, under the title). Signed in, the slim account bar sits above it all (see "How do I know which account I'm acting as?"). On a phone the two corners do different jobs. The **compass** is *where you can go*, the same on every page: Let's Explore, Get Local, Connect, Marketplace, the Trip planner, your Dashboard, and the Help Center (its big logo takes you home); not signed in, **Create account** and **Sign in** are at its top. The other corner (☰) is *what you can do here*: this part of the site's tools (tap a heading like Things to do to fold it open or shut), with **Dashboard** first so you can always get back. On pages with no tools of their own, like the FAQ, it isn't there. In your account, the layout switch (your full profile, or just your Pulse) sits in that corner too. Around the site the brown bar stays; in your account the page runs to the top with just those two corners. Notifications are in your Pulse (the bell there); an orange dot on the menu means something is waiting. To bring back the full logo or the row of icons, tap the small tab next to the compass or next to the menu. We remember your choice on this device.

### Do I need an account?
No, not to look around. You need one to save favorites, write journeys, comment, like, report something, or make suggestions under your name.

### How old do I have to be?
Traversence accounts are for adults: you must be 18 or older. You'll confirm it when you sign up. If your account was made before we asked, or you confirmed an earlier age, we'll ask once, the first time you comment or become a contributor.

### How do I choose where I'm looking?
Open the place picker at the top of the page (on the home page, **Change** under the search). You can:
- open the **Trip Planner** to plan a trip: where, when, how long and what you're after;
- pick a **region**;
- type a **destination**, or a **state, city or ZIP** anywhere in the U.S.;
- use **Auto-detect** to start near you;
- tap **Search everywhere** to have no place at all. In search, the **×** beside the place clears it the same way.

In **Destination** you can type a town, a town area, a local name, or a landmark like **Grand Canyon**, **Lyman Lake** or a museum. Towns come first. You can add the state after a comma ("St. Johns, AZ"); the list keeps up while you type it. Choosing a landmark takes you to the town area around it.

Signed in, you can make a place your default (**My default**), so you start there next time: whenever you're signed in and haven't chosen a place yet this visit, every page starts from it (shown as "your default"). A region you arrive through, or choosing everywhere, still wins for that visit.

### Does Auto-detect share where I am?
No. Auto-detect only picks a starting place for you on this visit. Your location is never shown to anyone.

## Exploring places

### Why does Let's Explore ask before showing my default place?
Your default place (the ZIP saved on your account) never picks the page by itself. Let's Explore offers it first: **Explore** the area it's in, **Choose another place**, or stay where you are. A place you choose yourself, or with Auto-detect, is followed straight away.

### How do I see more of a list?
Lists show 10 at a time; a list of cards side by side rounds that up to whole rows (four across shows 12), so a page never ends on a half row. **Show more** under a list adds the next ones; the bar under it has the page numbers, which ones you're seeing ("11–20 of 64"), and how many a page (10, 25, 50 or 100), which this browser remembers for that list. A list of 10 or fewer has neither. This works the same in the directory, Let's Explore, the Marketplace and Find groups.

### What's on the North America page?
The big picture: the story of the continent and its regions, plus the newest journeys and guides from everywhere. From there you can browse by **Regions**, **Experiences**, **Parks & Landmarks** or **Map**, or open the **Trip Planner**. **Map** shows what's around the place you've set, everything at first, then narrowed to what you'd do (Hike, Walk, Drive, Exhibits, On the water) or eat and stay; beside ours, the museums, galleries, gardens, parks, zoos, theatres and attractions OpenStreetMap knows there show as lighter pins (credited to OpenStreetMap), so the places people go are always on it; outside our areas it opens around you (or asks where first). **Parks & Landmarks** follows you outside our areas too: the landmarks near the place you've set, and the national parks nearest first, each with how far. It's where Let's Explore starts when you haven't chosen a place.

### How do I change the place I'm exploring?
Tap the pencil next to **Explore: <place>** at the top of Let's Explore or of any place page, and choose another place. On a place page, you go straight to the new place's page.

### Whose photos are at the top of a place?
Photos from journeys people have shared about that place, or about places inside it. A region shows photos from all its towns. Share a journey with photos and yours can appear there. Until there are any, a labelled stock photo may show instead (see [Why do some photos say Stock photo?](/faq.php#why-do-some-photos-say-stock-photo)).

### What are Experiences?
Things to do that are worth the trip: paddling a lake at sunrise, a rodeo weekend, a night under dark skies. You take part, it belongs to the place, and someone local can make it happen. Find them in **Let's Explore → Experiences**, in season first. Each one shows when to go, how long it takes, how hard it is, who can take you, and journeys from people who did it. An old link to traversence.com/experiences/ opens that list too.

### How do I post an experience?
Sign in and open **Dashboard → Your experiences**. Say what you do, where, what it's like and when to go, and add the local businesses that make it happen. You need to be 18 or older. Our editors review your first experiences before they show. If they don't approve one, you'll see their note and can edit it and send it again. Once two of yours have been approved, a well-described experience from you can go up at once.

### Where do the other experiences come from?
Some are posted by members. Some we suggest from what we already know: outdoor places and their activities, local guides, outfitters and museums, and journeys people shared. Our staff add others. Each one gets a credibility score from who posted it and how complete it is. The most credible go up at once and our editors check them afterwards. The rest wait for an editor.

### What's the difference between Experiences and National Parks?
National Parks are places. Experiences are what you do, in a park or anywhere else.

### What's on a place's own page?
Each place has its own guide: a **Regional guide** for a region, an **Area guide**, a **Community guide** for a group of towns, a **City guide** for a town and a **Neighborhood guide** for a local name. They all follow the same order: essentials, things to do, getting there, where to eat and stay, events, itineraries, what living there is like, and its local businesses. On a wide screen, at a glance, the places one step down (its towns, say) and landmarks & heritage run in a column beside the guide. A community of just one town (Farmington) opens that town's guide. A part with nothing in it yet is left out. In Let's Explore, **This place** in the ☰ menu opens it.

### How are places organized?
From large to small: North America, then regions, areas, communities (groups of towns), towns, and neighborhoods (the local names people use). Each has its own guide with its story, its journeys, and what's there.

### What do Visiting and Live here do on a guide?
They show the same guide in two orders. **Visiting** starts with the essentials and things to do, then what the place is like, getting there and where to eat. **Live here** starts with the essentials (who to call, road and weather alerts), local businesses and support. Your choice is remembered; coming from Get Local starts you on Live here.

### Where do a guide's weather and road conditions come from?
Weather and alerts come from the National Weather Service. Tap the weather by the guide's name to open the forecast (it starts folded): the next 24 hours as temperature, rain or wind, and the next seven days. It stays on the page; the weather service's own forecast is a link inside it. Arizona road work, lane closures, detours, incidents and alerts come from AZ 511 (its work zone feed uses the national WZDx format). Our server asks for the place's weather, not yours: your location is never sent. Weather updates every half hour, roads every ten minutes. Check AZ 511 before you drive.

### What is "Walking in the footsteps" in a guide?
The place's story, told where you can stand today: the peoples and families, trades, building materials, water and hard times that made it, each tied to a street, a building, a river crossing or a view you can visit. It's written from our heritage catalog: facts drawn from historic records (the Library of Congress's newspapers, photographs and maps, linked, never copied), the place's public records and our research, and only those backed by a historic record or two independent sources. Archaeological, sacred and burial places follow the law of the place, at three levels. A place its managers invite visitors to (a state park's ruins tour, a museum, a town's public cemetery) is told like any other, with how to get there. One that public sources name but that isn't open to visitors has its story told, never where it is or how to reach it, with a reminder that it may be visited only with the authorization of the nation or the land's managers. One no public source names isn't named at all; a guide may say only that the area holds places sacred to a nation and that they need its permission. On a tribal nation's land nothing is told until the nation says. Where a record's source asks to be credited (the Library of Congress), it's named under the chapter, and a fact we may only use to confirm something, never to tell it, isn't shown. Every guide shows when it was first published and when it was last checked. We check each guide every month, and sooner when something changes: a place it names closes, someone suggests a change, new historic records turn up, the season turns, or many more people than usual start reading it.

### Where do the events under "Coming up" come from?
From each event's own announcement. We read the town's or county's own events and calendar pages first and, for what they don't list, look on the web, keeping only events with a date ahead and a page that announces them. Each shows with its dates, time, where it is (linked when it's a place listed with us), its price when the page gives one, and a link to that page: check it before you go, since plans change. An event shows in the guide's Events section (a community's guide includes its towns') and on its venue's page under **Coming up here**, until the day after it ends. A ceremony or feast at a sacred place is listed only when the nation or parish announces it as open to the public, never with directions, and anything whose name may mark a protected place is read by a person first. We're switching this on place by place, so some guides don't show events yet. Something wrong or missing? Tap **Suggest a change** on the guide.

### What does a highlighted name in a guide do?
Point at it (tap it on a phone) and a small card shows what it is, where it is, its phone number if it has one, and **See more**, which opens its page. Every business, landmark and outdoor place a guide names is highlighted this way, and so are the names in journeys, place stories, experiences and how-tos, so you can go deeper without losing your place. You can also search for any of them by name: a landmark, park or museum a guide names is in search as soon as the guide has it.

### Why are names in my journey highlighted?
When you publish a journey (or an experience), we look for the places and businesses it names that are on Traversence, link them, and your piece shows under **Featured in** on their pages. If you've turned on AI Assist & Learning and have a paid plan (your own, or one on a business you own), Claude reads your words to find the names; if not, we only match names from our own directory, and nothing you wrote leaves Traversence. Right after you publish, and any time on your journey's page or its editor, you'll see what it's tagged with: tap × on any that aren't right and it comes off at once. Only you see that list. A name we don't have yet isn't added on its own: a person checks it first.

### What is "Featured in" on a listing or a landmark?
The published guides, journeys, place stories, experiences and how-tos that name it, so you can read what's said about it there. Group posts never show here: they're for the group's members. Nobody pays to be named.

### What do I get when I follow a business or a place?
Besides its own posts: when a guide, journey or story names a business you follow, or a place you follow gets a new guide or story, it shows in your feeds and your Pulse. A member's journey that names a business reaches that business's followers only if they also follow the person who wrote it or the place it's about.

### Who hears about it when I @mention someone?
The person you mention, once, in their Pulse, if they're in the group you posted in (so they can read it). Nobody else is told, and your post doesn't show anywhere outside the group.

### What's in a guide's Essentials?
Weather alerts and road conditions, who to call, and the nearest places for what you might need, three of each, nearest first. Everyone sees emergency and urgent care, pharmacies, police, fire and ambulance, fuel and charging, groceries, banks and ATMs, and visitor information and libraries. **Visiting** adds car trouble, getting around, pet emergencies, and laundry, mail and shipping. **Live here** adds the town hall and government offices, utilities and trash, schools and childcare, doctors, dentists and counseling, home repairs, and community help. **See more** opens the full list in Get Local. For an emergency, call 911.

### How do you choose the businesses a guide shows?
By what the section is about, how close they are, the kind of place (a quick bite or a sit-down meal), the season (winter leads with snow sports, summer with the lakes) and the weather right now: when rain, a storm warning, a heat wave, a deep cold or a strong wind keeps people in, museums, galleries and other indoor places come first, with a **Right now** note saying why; on a fair day the outdoors leads. Places our writers name come first. A paid plan never moves a business up. We only show public listings that are open, one per business: a business marked closed drops out of every guide.

### Where do I find a place's guide?
On the place's own page (open the place from search or Regions), and in **Let's Explore → Stories & guides**, which lists the guides for the place you're searching and the towns in it. A place without one says so; guides are added as they're written and checked.

### Who writes the guides?
Traversence compiles them. Our crawler first gathers what's public about the place, free: its Wikipedia article (read for facts, never copied), its facts on Wikidata, its town or county's own website, the places near it on the National Register of Historic Places, the landmarks and outdoor places we hold nearby, and the Library of Congress's records of it, including pages of historic newspapers (Chronicling America) that name it. A new guide waits up to two days for these, so its history is drawn from them first. Claude, the AI we use, then researches the place in depth, told what those records already hold so it searches only for what they don't (its peoples and founding, the families and events that shaped it, its faith, food and crafts, the festivals of its year and what it's like to be there) and keeps that research with the place. It writes the guide from, first, what people on the ground know (our team's notes from being there, and the journeys and experiences people have published about the place, a member's only if they've turned on AI & Learning), then that history, then what visitors search for there (counts only, never who). It searches the web only for what the crawler didn't find, and names only places it can back up. What the crawler gathers is kept with the place, so it's never fetched twice, and its facts (when the town was founded, its population) show under At a glance. Each guide gets a confidence score, from how sure Claude is, what it was written from, its sources and how many of its names we have. When the score is high enough, the guide goes live by itself, marked "Compiled by Traversence from public sources and local knowledge" with the date, and our team corrects or takes it down whenever something's off. Every month each live guide is checked again, the ones people have been reading first: whether what the crawler knows about the place changed, whether a date in it has passed, whether a place it names has closed, and whether its research is a year old. When something has, the parts Claude wrote are written again and scored the same way; anything our team wrote is flagged for them instead. If all that's wrong is a date that has passed, a business that has closed or a link that no longer works, just those sentences are corrected (by the least costly AI, checked before it's kept) rather than rewriting the guide. See something wrong? Tap **Suggest a change** on the guide.

### What are suggested journeys on a guide?
Routes through the guide's own places, under **Suggested journeys**, labelled "Suggested by Traversence". The guide decides what kinds there are: whatever runs most strongly through it (the outdoors, history and heritage, food, the arts or shopping) becomes a journey, and a guide with enough of everything also gets "A day in" the place. Each stop is one the guide recommends, in an order that makes sense to travel, and timed: breakfast in the morning, lunch at midday, a museum while it's open, a trail or viewpoint in daylight. Between stops you see how long it takes to drive or walk and how far; "about" means it's our estimate. Tap **See the stops** for the list, the arrow beside each for directions, or the route icon to open the whole journey in your maps app. They're timed for a Saturday, so check hours on other days. They're built by rules from what we know, with no AI, and rebuilt every week or when the guide changes, so a place that closes drops out. A business is in a journey because it fits the route, never because it pays. Saving a journey to your trips and changing it is coming with the Trip Planner.

### Why do more names in a guide link now, even in places you don't cover?
When a guide names a beach, park, museum or historic place we don't have yet, we look for it in Wikidata, the free public database behind Wikipedia, near the guide's place. When it's there, it gets its own page with us (what it is, its story from Wikipedia, a free photo when we find one, and the guides and journeys that name it), and the name in the guide links to it. Journeys can stop there too. We also look on our own: around each of our pilot towns (once a year), across each pilot state bit by bit (each month), and for any name people search for that we don't have yet ("Four Corners Monument", "Laguna Art Museum"), anywhere in the US. Museums, monuments, historic sites, harbors and parks with a Wikipedia article or on the National Register of Historic Places get a page with us and can be found by name, usually within minutes of the first search. Where a place is (its town and state) comes from the same source. So does what it is: each one is filed under one of our categories (Museums, Parks, Churches…) by what its source says it is, never guessed from its name, so tapping its kind shows more like it and a search like "museums near me" finds it. Until a category fits, it shows the source's own word for it ("Historic district"). Only the words of a search are looked up, never who searched, and never a search with a number or an email address in it. Businesses aren't added this way: they go through the same checks as every listing. A place that may be sacred, a burial site or otherwise protected is never named or located.

### Can I get directions to a place a guide names?
Yes. Tap or hover a highlighted name: its card shows what it is, a map pin to see it on our map, and an arrow for directions in your own maps app (Google Maps). **See more** opens its page.

### Where do the travel times come from?
From OpenStreetMap's roads, through a free routing service (openrouteservice), asked once for the places in a town and then kept with us, so the next journey, trip or card reads our own record instead of asking again. They're renewed only when a place moves, someone tells us a route is wrong, or the time is two years old. When we don't have one yet, we estimate it from the straight-line distance and say "about".

### Is everything named in a guide real?
Every business, place, landmark and road a guide names that we have links to its page with us. When a guide names something we don't have yet, it shows as plain text while we look for it: first on the map (OpenStreetMap) and its own website, then, if that finds nothing, by Claude on official sources. What we find gets a confidence score: when it's high and the place has an address, it joins the listings our crawler finds and goes through the same checks (a real place, a way to reach it, a category that fits, and not listed already). Once it passes, it's published and the name links, usually within the quarter hour; anything the checks can't settle, our team looks at. A shelter or safe house is never looked up outside: a person links it. A place that shares its phone or website with a listing under another name (a county office's line) is always checked by a person. A guide never names a place that may be sacred, burial or protected, or a business that's closed: it waits as a draft until those are taken out.


### How do I ask you to take something down?
Tap **Ask us to take this down** at the foot of any section of a guide, on a landmark's page, or under a topic in AI Assist. You don't need an account. Tell us why: if it shows the way to a sacred, burial or archaeological place, if you speak for a tribal nation and it shouldn't be told, if it shows someone's private information, or if it puts someone or something at risk, it comes down the moment you send it. Anything else (it copies your work, it's wrong) comes down within 24 hours while a person looks, sooner if they finish first. In the "Walking in the footsteps" chapter you can name the one fact you mean, and the chapter stays out until it's written again without it. Leave your email and we'll tell you what we decided: it stays down, or it's back because we found nothing wrong or fixed it. What you tell us is used only to decide and is never shown. Each quarter our team also reads a random sample of published guides against the same standard. For a member's post, journey or comment, use its **Report** button instead.

### I searched for a town with no guide. What does "Build the guide" do?
When you search somewhere we don't have a guide for yet (Dana Point, California, say), search offers to build one. Tap **Build the guide** and a page shows each step as it happens: we find the places there (places to eat and stay from OpenStreetMap, outdoor places and landmarks), build suggested journeys from them, and Claude, the AI we use, writes a first look from public sources. It takes about two minutes, and you can leave the page: it carries on, and the guide is there when you come back. If a step fails (a service we use is busy), it's tried again by itself after half an hour, two hours and eight hours; if it still can't be built, our team is told and looks at it. Want to hear when it's ready? Tap **Notify me when it's ready**: signed in, you get a notice in your Pulse and an email; signed out, type your email and we write once (we don't keep the address after). If the page is still open in another tab, your browser can tell you too. The first look is marked **First look** while we keep researching; within a day or two the full guide follows, with the place's history from the Library of Congress, old newspapers and deeper research, and the label comes off once it passes the same checks as every guide. Everything gathered is kept, so the next person to search that place gets it straight away. Every place a guide names is checked against our sources, and a place that may be sacred or protected is never named. Building the guide also starts our crawler on the town: it uses OpenStreetMap as its lead for everything it has there (places to eat and stay, groceries and gas, things to do, shops, services like banks, salons and auto repair, public services like the library and town hall, places of worship, campgrounds and health care), checks each one on its own website, and a place confirmed by both becomes a listing (the rest wait for our team to check), usually within an hour or two, so the town's search results, guide and journeys fill in with real listings. Its trailheads, parks and viewpoints are looked up on Wikidata by name, and the ones with a Wikipedia article or on the National Register get a page of their own with us. Writing costs us money, so we write a set number of new guides a day; when that's used, a place waits until the next day (the most-asked first), and you still see its places and journeys straight away. Finding places takes under a minute or so; when OpenStreetMap is slow, the step carries on with what it has and the rest is filled in later, so it never sits on Finding places. **Email me when it's ready** answers at once, even while a step is running.

### Why isn't there a guide for my state yet?
We open one state at a time. Before a state opens, its laws on archaeological sites, burials and privacy are written up and reviewed with an attorney, so we know what may be told there and what must be held back. Until then its guides don't go live and we don't gather its history. Arizona and New Mexico are open; others are coming.

### I searched for a local name (like Wide Ruins) and landed on a town. Why?
Many small communities are known by local names that aren't on maps as towns. We file each local name under the town area it belongs to, so searching it shows that town area's places. **Get Local**'s Map shows them on the map.

### On a place page, what happens when I tap the kind, the agency or an activity?
It searches for more like it around there. Tapping **Campground** finds other campgrounds nearby. Tapping the managing agency finds other places it runs nearby, and tapping **Fishing** finds more places to fish. The search shows listings, outdoor places, stories and groups together.

### Can I link a lake, campground or trail?
Yes. Use the link icon in the corner of its page. It's saved with your other linked places.

### What does clicking a town name do?
It opens the directory for that town, so you can switch between the list and the map.

### When I choose a town, why can I set how far to look, and what is its "Town area"?
Choosing a town (like Show Low, AZ) centres the search on the town itself, within 10 miles to start; **Within** lets you look closer or farther. Many of our towns also have a **Town area**, the town with the towns around it (The Show Low District, for one): choose that when you want the whole area, with no distance.

### How do tribal lands appear?
Tribal nations are sovereign nations, and we present them that way. We show public places and public events only. We never point to sacred or restricted sites.

## The directory (Get Local)

### Why do some kinds of business have different names than I expected?
We show each kind of business by the name people use, so you'll see "Doctors" rather than "Physicians & Surgeons" and "Self
Storage" rather than "Storage-Household & Commercial". Where a few of the trade headings mean the same thing, they show as one,
and choosing it shows every business in all of them. Searching by either name works.

### How do I find a business in Get Local?
Get Local opens with **Find a business** at the top: type a business's name, the kind of business, or what you need ("pizza", "oil change", "Head Start"), set the town or ZIP beside it (or tap the target for where you are). From the third letter, the list follows what you type: it updates by itself when you pause, with no need to press **Search** (Search or Enter updates it at once). Words you've typed stay put if you change the place or Refine first; that search uses them. Empty the box to see everything again. Then **Refine** narrows what was found: **Kind** and **Town** list what's in the results with how many of each, **Within** sets how far, **Sort** puts the best match, the nearest or A to Z first, and **Open now**, **Has a phone**, **Has a website** and **★ Favorites** turn on with a tap (lit green when on). New words start Refine over. What's narrowing the list also shows under its title, each with × to remove it.

### How do I search the directory?
Use the search bar at the top of any page. The panel that opens has:
- **Location** at the top: the place you're searching. Tap ✎ to change it.
- **Search Directory**: search **All**, or just **Discovery**, the **Directory**, **Community** or the **Marketplace**.
- **Distance**: slide from **My place only** to **∞** (no limit), or pick a distance like 25 miles. It starts at **10 mi** around your place and goes back to 10 mi whenever you change your place, so search doesn't look outside your place unless you widen it. Your place stays as you set it: searching, tapping a town in search, or opening another area's page never changes it. That page shows its area, and your place changes only when you choose a new one (or tap **Make it my place**). A link to an area sets your place only when you haven't chosen one yet. With no place chosen there's nothing to measure from, so the slider rests at ∞ until you choose one.
- **Search Results** on the left. Each one says which part of the site it's in: **Directory**, **Discovery** or **Community**.
- **Suggestions** under them, one per line: the categories that match a word you typed ("All Churches in Saint Johns"), each word on its own when nothing has them all, and other searches for the place. When your words describe a situation, its answer already says what kind of place helps, so no category lines show.
- **Quick Search** on the right: one-tap searches for the place, with how many each finds, your own, and the filters (**Near me**, **Open now**, **Has a phone**, **Has a website**, **Favorites**). **Recent Searches** are under them.
- **Show in directory list** opens your results as a list.

### How does search read what I type?
As you type, it guesses where you're headed: "plum" in Show Low offers **Plumbers** there first, "coffee near" offers **Coffee near me** and coffee near your place, "place to take my k" offers places that suit kids, and the first letters of a town ("pho") offer the town. Some other things it does:
- **The full name of a place wins.** "Four Corners Monument", "Laguna Art Museum" or "Fool Hollow Lake" finds that place, not the town that shares part of its name.
- **A misspelled town is offered, never changed.** "flagstaf" asks "Did you mean flagstaff?", and tapping it searches Flagstaff, AZ.
- **"Near me" stays inside your Distance.** For everyday errands (coffee, gas, urgent care), ours are shown within the Distance you set, and OpenStreetMap fills in where we don't list enough yet. Places to go, like trails and parks, still reach 25 miles.

### Can I search for sports, like football or basketball?
Yes. **Sports** finds athletic fields, stadiums, gyms, golf courses, public pools, rodeos and sports clubs nearby. **Football**, **basketball**, **baseball**, **soccer** and other sports also find high schools, where most local games are played, and ball fields find parks. Try **gym**, **swimming**, **tennis**, **hunting** or **fishing** too. If a place you play or watch is missing, tap **Tell us what's missing**.

### Can I find natural places like badlands, arches and canyons?
Yes. Search for words like **badlands**, **arch**, **crater**, **hot springs**, **waterfall** or **canyon**, alone or with a place ("crater near Flagstaff"). Each landmark has its own page with a photo where there's a freely licensed one, a short description from Wikipedia, directions, and comments. Names and locations come from USGS Geographic Names. Some landmarks, like monuments and viewpoints, aren't in that data, and our team adds them by hand. If you know one that's missing, use **Tell us** on any page.

### Why don't some landmarks on tribal land show?
Tribal nations are sovereign nations, and each decides what visitors are welcome to see on its land. On a nation's land we show only its public places, the ones the nation itself lists for visitors (like Four Corners Monument), and public businesses. Other places there aren't shown. That goes for the open map data we show (OpenStreetMap) too: on a nation's land, only its businesses show, and a trailhead, viewpoint or reserve there waits for the nation. We never show the location of sacred or restricted sites, and anything a nation asks us to close is closed at once. A guide may name a place the public already knows (a public source publishes it) but that isn't open to visit, and tell its story, but never how to get there, and it says the place may be visited only with the authorization of the nation or the land's managers. A place a nation has closed, or that we hold, is never named.

### Where do I find parks and landmarks?
In **Let's Explore**, open **Parks & Landmarks**. National parks, monuments and historic sites come first. Under them are natural landmarks like arches, buttes, canyons and falls: the ones near the place you're exploring, or, with no place chosen, the best-known ones with photos. They show 24 at a time; **Show more landmarks** under them adds the next 24, and goes away when there are no more. Tap one for its page. Data from the National Park Service itself is coming.

### How do I switch between my accounts or roles?
If you help run a business, or you're on the Traversence team, you can act as yourself or in that role. Tap **your photo** at the left of the account bar, the slim bar at the very top of every page. The list shows, in order: your **Traversence** staff account if you have one, **you** (your Personal Account), then **your listings** just under you, each one tap to switch to it and open its Overview, where all its tools are. With more than five, **See all** opens every one in a pop-up with a search box. **All your accounts** opens a page with all of them, a brand's locations grouped together. In the bar itself, the account's name opens its dashboard, and ✎ beside it edits it: your profile when you're yourself, the listing's page when you're acting as a business. It works the same on a phone and a computer.

### I'm on the Traversence team. How do my staff login and my own account fit together?
They're separate: the staff login (a staff ID like TRV-0001, your work email and a password) opens the admin side; your own account is for everything else. An owner links them for you from the admin (People → Staff logins → Link a member account), and we email your own account to confirm: sign in as it, open the link and tap **Link them**. You can unlink from your own account (Dashboard → Privacy → Staff login) at any time. After you sign in with the staff login, the account menu switches to your own account and back without signing in again, for up to 12 hours after you last used the admin side in that browser; after that, the switch back asks you to sign in with the staff login again. While you're on the admin side, the menu's **Your listings** shows your own account's listings: tapping one switches to your own account and opens it. Signing in with your own account never opens the admin side.

### I'm on the Traversence team. What are Switches and test accounts?
**System Configuration → Switches** turns a new feature on or off with no upload: first for staff and test accounts, then a share of members, then everyone, with a kill switch that turns it off for everyone at once. **System Configuration → Test accounts** is where the Founder makes the accounts our automatic checks sign in as (a member, a contributor, a business team on a hidden test listing, and staff logins at each level). Test accounts are left out of counts, likes, emails, people search and billing, the site sends them nothing, and they can only pay in sandbox mode.

### Do you try changes before they reach the site?
Yes. Changes are being set up to go first to a private copy of the whole site, where we try them with every kind of account before they reach you. The copy never sends anyone email, never takes a real payment, isn't shown in search engines and needs a password to open. When we refresh it from the live site, names, email addresses, phone numbers, street addresses and private messages are replaced with made-up test values first, so your details never go there. Running each new release through it first is coming.

### I'm on the Traversence team. What is staging?
**System Configuration → Staging** is the copy of the site at staging.trvgo.us. The Founder sets it up once (**Set up staging**, which also gives the test accounts new sign-ins, shown once for the GitHub secret CHECK_ACCOUNTS together with staging's viewing password) and it refreshes itself from the live site every week, or whenever **Refresh staging** is pressed. On staging, email is held and readable on its own Staging page, payments use the sandboxes, paid AI and the crawler stay off unless their switch is on (**Switches → Staging: paid AI**, **Staging: the crawler**), and staff sign in there with the test staff logins. The trvgo.us router's copy answers at staging.trvgo.us/go/, so the word "staging" is kept: no GO Code or shop can take it. A refresh goes a table at a time and carries on by itself on the server, so the page can be closed: its bar shows how far it's got, and whoever started it gets an email when it's done (or if it stops). **Carry on the refresh** nudges one that seems stuck. If **Open staging** ever meets a password prompt instead of letting you in, **Check the way in** (on the same page, Founder) asks staging for a page several ways (with nothing, with the pass, with the checks' sign-in, and the whole Open staging path) and says which part answered each: the web server, staging's guard or the page itself. It also shows the rules and settings on the way to staging's pages, never a password or key, with a **Copy the answers** button to send them to whoever is fixing it. Its first run found why Open staging kept asking: the rule that keeps staging's private folder shut also shut its pages, so its self-test put the browser's password prompt back. That's fixed, and Open staging lets you straight in.

### I'm on the Traversence team. How does a change reach the site?
Through **System Configuration → Releases**, or the **site manager** at the top of staging. A release is a zip of the changed files. Uploaded on either (the site manager's **Upload**), it goes straight onto staging.trvgo.us: its plan comes from the zip's release.json (what it changes, its switch), its database updates run there and it's checked: its code reads cleanly, its database updates only add, its pages answer and the error logs stay quiet. Then someone looks at it on staging (opening it there counts as the look), and **Publish** is the sign-off: it puts it live at once, or **Schedule** at a time you choose. A release with a switch goes to staff and test accounts first, then a share of members (25% unless changed), then everyone, each step on its own after its hours pass clean (24, then 72, on weekdays 6 am to 6 pm Arizona time) or when the next step is published. A failed check pauses it and emails whoever approved it. **Turn off** switches it off for everyone at once; **Roll back** puts the previous copy of every file back. An urgent fix can be published straight away with a reason, and is checked straight after. To try it yourself, **Open staging** (on System Configuration → Staging or Releases) or **Open on staging** (on a release) takes you there past staging's viewing password, signed in as you (or as one of the audit's test accounts, to see it as they would), with the **site manager** at the top of every page, in the admin's command bar look: **Releases ▾** (what's on staging now, what's waiting, what's live and at which step), **Upload** (your device's own file picker: a release zip isn't kept in the Gallery), **Changes** (the pages a release touches, to jump to, its files and checks), **Note** (pins what you see on that page to the release) and **Publish ▾** (Publish now, Schedule, the next step, then Turn off and Roll back once it's live), which act on the live site as you. ◆ folds it to a small tab. Publish copies exactly the files that were tried on staging, and stops if one of them changed on the live site since the release was built. Each release is recorded in git, shows in Pulse while it waits on someone, and its zip and rollback zip can be downloaded for an upload by FTP instead. Who may publish, schedule, turn off and roll back is set in **System Configuration → Permissions** (the Founder only, until a role is given them). Claude's finished builds arrive on staging by themselves from git (the site looks every 10 minutes, or **Releases ▾ → Check for builds** at once), so there's nothing to upload. Each is approved in the chat before it's sent, so once its checks on staging pass it goes live by itself; one that failed a check stops on staging and shows in Pulse. One the Founder asked to see first is **sent for review**: an email and a Pulse case take him onto staging, where the site manager's **Review** asks for **UI** (how it looks), **UX** (how it works for a person) and **Functional** (it does what it should), each **Approve** or **Needs changes** with a note kept with the release; **Publish** opens once all three are approved. The site manager keeps itself current (every minute, and when you come back to the tab); **Releases ▾ → Check for builds** fetches new builds at once. **Turn off** and **Roll back** work as for any release. Publish is for work done on staging itself: a zip uploaded there, and the page editor that's coming. Every change to the site's files should come through a release: one made straight on the server or in OneDrive shows in **Pulse → Site health** as *changed without a release*, with the files, and clears by itself once a release carries it.


### I'm on the Traversence team. How do I see which files are being worked on?
In the **site manager** at the top of staging, **Releases ▾ → Checked out** lists each file a Claude session is writing a release for: the file (and the functions, when it changes existing ones), whether it adds or changes, which session, why and since when. One near its 4-hour expiry is marked ⚠, and tapping one opens that session. **Pulse → Site health** shows the same list as a step. Adding to a file is shared, so several sessions can add to one file at once. A change holds only the functions it names, and only until its release is live. A claim ends by itself when its release is live, or after 4 hours without a release. Nothing here locks you out of the site.
### I'm on the Traversence team. How do I change what a page says?
Press **Edit** on the part of the page that's outlined for you (staff with **Pages: edit**, the Founder until a role is given it in **System Configuration → Permissions**). The first places are the home page, under the four doors, and every page of ours, under its text; more come as releases add them. A panel opens (from the bottom on a phone, at the side on a computer). **Add** holds the blocks: a heading, text (paragraphs, lists, **bold**, *italic*, links), a picture (uploaded here, kept with our pages), a button, a divider and a spacer. Tap one to add it, or drag it to its place on the page. **Layout** shows the sections (one, two or three columns each) and their blocks: drag ⠿ to move a block, between columns and sections too, or a whole section. Tap a block on the page to pick it: its toolbar (on a computer, over the block; on a phone, in the panel) moves it up or down, copies or removes it; **Manage** holds its words, **Design** its alignment, width and the space above and below. A section has its columns, background, inner space, column widths and order. The buttons at the top show the part as a **desktop**, **tablet** or **phone** sees it, and Design sets each one on its own: a tablet takes the desktop's settings unless you set it, a phone takes the tablet's (on a phone, columns always stack). Every change shows on the page at once, as visitors will see it. Under **Add → Parts of the site** are pieces of the site itself, which draw themselves from our data and stay current: a **search box** (empty, or with words already in it), **businesses** (cards from our directory for a town and, if you like, a kind of business, with a link to all of them), a **map button** (opens the site's map of those businesses), a **guide** (a card for a town's guide, shown once it has something published) and a **GO Code** (the QR code and trvgo.us address for this page or another of ours). You choose what each shows; how it works stays the site's. On one of our own pages, the **Page** tab sets its title, the description search engines show and the picture used when it's shared; these are saved for the page at once, apart from the draft. **Save draft** keeps it for our team only, right there on the page. **Publish** (staff with **Pages: publish**) puts it live for everyone as the next version; ▾ → **Versions** lists them, with who and when, and **Roll back** puts any earlier one live again, so nothing is lost. ▾ → **Publish later** picks a day and time instead: what's in the panel then goes live by itself as the next version, at the first visit to the page after that time, and your draft stays yours to keep working on (**Call it off** stops it). Two outlined places on the home page are on every page of the site: **Every page, under the header** and **Every page, above the footer**. What's published there shows on all our browsing pages (not on the admin, sign-in or payment pages), for notices like holiday hours or an event; the header's and footer's own menus and links stay as they are. If a published version has nothing in it, the outlined part says so and points to Roll back. What the page showed before stays until something is published there. On our own pages, Add → Parts of the site also has **Likes and comments** (the page's views, likes, Share and QR code, with its public comments or the bar alone) and **Form** (a contact form or a quote request; messages come to Marketplace & Storefronts → Form entries, as with a page's own form). They're offered only on our pages, where there's a page to like and to send the message about.

### I'm on the Traversence team. How do I see what the crawler is doing?
In the admin, **Insights → Crawler**. The crawler is one service that the site's workflows use (finding businesses, keeping listings current, reading our sources, the heritage catalog, landmarks, how-to guides, search learning), each with its share of every run. Every 5 minutes the site plans the run: finding businesses first, then whoever has waited longest. Each workflow folds open to show its tasks: how often each runs, when it last did, what the last day's runs did with it (did its work, had nothing to do, wasn't reached, failed, or is off and why), what's waiting in its queue, and what it spent this month (Claude, web search, Google, counted even when a call fails). A task a run didn't reach is never counted as a failure: it goes first next time. From there, Operations staff can **Pause** or **Resume** a workflow, change its **share**, **Run first** a task, **Switch off** a task, and **Retry failed** work. Below them, **The last runs** shows each run task by task. A run that couldn't work shows as failed on Railway too, and Pulse opens a case when no run has started for 30 minutes or six in a row have failed. Queueing coverage gaps by hand is still on the earlier Crawler overview, linked there, until it moves.

### I'm on the Traversence team. Where do I see every outside service we use?
In the admin, **System Configuration → Outside services**: one card for every outside service the site and the crawler depend on, the paid ones and the free ones (OpenStreetMap, Wikipedia and Wikidata, the National Weather Service, AZ 511, Recreation.gov, the NPI Registry, the IRS, the Library of Congress, the Census, Common Crawl and more). Each card says what we use it for, whether it's working (from the site's and the crawler's own logs, and anything known, like a service refusing us), what it costs ($0 for the free ones, with their usage rules), its terms and who to ask when something's wrong (its support or its community forum). What's set in another section (its licence on Sources, the crawler's tasks that call it, its scheduled tasks and switches) shows on the card as it stands, with a link there to change it. To find a card, press **Ctrl K** (or the search at the top) and type its name, its company or its address, like "overpass" or "weather.gov": it opens that card, and its linked sections show just under it. Each card also shows the crawler's own calls to that service: how many in the last 24 hours and this month, how many failed, and the last error (like an address that answers "406 Not Acceptable"). The site's own calls aren't counted there yet.

### I'm on the Traversence team. How do I read the support email?
In the admin, **Pulse → Support inbox**, then **Open the support inbox**. It opens support@traversence.com's webmail in a new tab, already signed in, so there's no mailbox password to type or share. The Founder, executives and managers in Service can open it; others can be given it in System Configuration → Permissions ("Open the support inbox"). Each time it's opened, who opened it is noted.

### I'm on the Traversence team. Where is everything in the admin?
The admin has 11 modules, in the menu on the left (☰ on a phone). Each module has its own sections, listed in the menu next to the page title. Your role and department decide which modules you see. Anything your role can't do is greyed out, with the reason. A section that's coming is greyed out in that menu and opens a page saying what it will do. Lists work the same way everywhere: a search box, filters, and the stage of each item. Tap an item to open it in a panel at the side. The panel shows where the item stands, how long it's been there, and the next steps you can take. The round icons beside the section menu open tools from other modules in a panel over your work, so you don't lose your place, and Back closes the panel. Managers and up can change the steps work goes through, and who may take each one, in **System Configuration → Workflows**. The older admin pages still open from their old links and the site map, with a note saying where their work is now. To find anything, use the admin's search (Ctrl K, or ⌘K on a Mac): it finds pages and tools, records (orders, listings, guides, people and more), things you can start, help answers and our decisions, and each scheduled task and switch by its name or what it does ("audit clock" finds the Site audit clock in both **Scheduled tasks** and **Switches**), opening its card on its page.


### I'm on the Traversence team. How do I test the Marketplace?
Post with **Test post** ticked (it's ticked for team accounts; untick it for a real post). A test post shows only to our team, marked **Test**, and never to anyone else. With a second team account (or a teammate) as the buyer, you can message, make and counter offers, tap Sold and Got it, leave a note and report a problem, all as usual. Tests use up no one's 5 posts and count in no numbers, notes or trust points. Find them in Market 360° → Items under **Test posts**, and take them down when you're done.
### What does Peek do in search?
Tapping a result opens its page. A listing also has a **Peek** button: tap it for a quick card with the address, Call and Directions, without leaving the page you're on.

### How do I add a photo of a place?
Tap the camera button at the bottom right of the photo at the top of a place or a business. It starts a journey with the place already filled in: add your photos or video and a few words, and publish. Once it's published, your photo shows at the top of that page, credited to you. A business's own photos come first, and visitors' photos follow them. If you run the business, the camera is **Photos & video** instead: it chooses the page's own photos. Places on a tribal nation's land follow the nation's rules for photos and pins.

### Why do some names look different from other sites?
Some listings come from public data that shortens words, like "Visitor Ctr" or "Natl Pk". We show them in full ("Visitor Center", "National Park"). Once a business claims its listing, we show the name exactly as the owner writes it.

### Why does a listing say "Also known as"?
Some places go by more than one name: a new name after a change of owner, a legal name on official records, or an older name people still use. "Infinia at Show Low" and "Tall Pines Care and Rehab" are one nursing home, for example. The listing keeps its other names and shows them as **Also known as**, and searching any of them finds it. When our crawler finds the same place under another name (the same address, phone and kind of place), it adds what it learned to the existing listing and keeps the name, instead of listing it twice.

### Why does a listing say "Part of" another name?
Some organizations have several locations: a school district's schools, a health center's clinics, a chain's stores, an agency's offices. Each location has its own listing, with its own address, phone and hours, and says which organization it's **Part of**. Stores of a franchise brand show **Part of** the brand too, but each is its own business: its owner manages only that store's listing. Tap that name to see every location on one page, nearest you first when your place is set. Under each location's details, **Other locations** lists the nearest few, each with Call and Directions. Searching the organization's name finds all of its locations. Our team links them, from the organization's own website (its own list of its schools, clinics or stores) or records, never from a similar name alone. A chain's shared website never makes two of its stores one listing: each store is its own place. Owners claiming all their locations at once is coming.

### Why do several listings share one address and phone number?
Clinics, medical centers and offices often house several providers or businesses under one roof and one front-desk number: a behavioral health center and the counselors who work there, say. Each is its own listing, so you can find the person or service you need. When our crawler finds a business that is already listed under a shortened name ("Apache Behavioral Health Svc" and "Apache Behavioral Health Services"), with the same phone, street address and ZIP, it adds what it learned to the existing listing instead of making a second one, and never overwrites what's there. Our team can also link a facility and its providers, so the facility's page lists them (see "Part of" above).

### Can I see a place's photo bigger?
Yes. Tap the photo at the top of a place, a listing or a profile to open it full screen, with its credit. If there are several, swipe or use the arrows to move between them. You can like it, share it or go to the comments from there too. Tap outside the photo, or ×, to close it.

### Why do some map spots show a number and "approx."?
They're listings whose exact spot isn't on the map yet. Most listings came to us with only their ZIP code, so they all sat on the middle of the ZIP area. Instead of fanning them out as if they were real places, the map shows one dashed circle with how many there are, like **157 approx.** Tap it to see them as a list, then tap one to open it. We place their street addresses on the map a batch at a time, every time our crawler runs, and each one moves to its real spot as soon as it's placed. Some addresses can't be placed that way, like PO boxes and rural routes, so those get their spot from the business's own website, from our team, or from you: open the listing and tap **Wrong spot? Fix the pin**.

### Why did my journey's pin move or disappear?
On a tribal nation's land, a pin shows only at a place the nation opens to visitors. If your pin is within half a mile of one of those places, it moves onto that place. Anywhere else on the nation's land the pin isn't shown, and your journey says where you were in your own words instead. This follows the nations' own rules: many areas are homes, grazing land or sacred places, and aren't open to visitors.

### Where do the visitor rules on a tribal place come from?
From the nation's own website. Our team checks each nation's rules for permits, fees, guides, photography, drones and alcohol, and the page says when they were last checked, with a link to the nation's visitor information. Rules change, so check that link before you go. If a nation asks us to close a place, we close it at once.
### I searched for something and got places from somewhere else. Why?
On Let's Explore, if there's nothing for your search in the place you're exploring, we look across the open regions and say so at the top of the results. Words for landscapes work too: try **badlands**, **canyon**, **petroglyphs**, **ruins** or **dark sky**.

### Why does search show different things on Let's Explore and Get Local?
Search reads where you are. On **Let's Explore** it puts the place's journeys, stories, outdoors, groups and topics first, with businesses after them. On **Get Local** businesses come first. The place you're searching sits at the top left (tap × to search everywhere), and **☆ Save** at the top right keeps the search. Tapping × on a place you typed (like "near Grants") searches the rest of your words everywhere.

### Why does search sometimes answer with a place's story?
When you ask about a place's past or a subject our guides cover ("St. Johns history", "Little Colorado River"), search answers first from what we've researched ourselves: a short summary and a few facts backed by historic records or two independent sources, with a link to the guide's "Walking in the footsteps". It says when we're still learning about something, and asking about it moves it up our research list. It never says where a sacred, burial or archaeological place is, and it says nothing about what a tribal nation or the law keeps private.

### Can I search the way I'd ask a friend?
Yes. Type it the way you'd say it: "new pizza place in town", "a good taco spot nearby", "pizza place in Show Low", "going fishing for apache trout", "where can we camp". When you name something to do, like fishing, hiking, camping or swimming, we look for places to do it, and anything else you mention ("apache trout") puts the places that mention it first. Search reads the place, the kind of business and the time ("open now"), and leaves out words that only describe it, like "new", "good" or "spot". "In town" and "nearby" mean the place you're searching. We can't yet tell which businesses opened recently, so "new" doesn't narrow the list; that's coming. "Where to buy new" reads as shopping, not as a search for the word "new".

Search reads each part of what you type for its job, even without a full sentence:
- **The thing you want**: "plumber", "hardware store", "oil change".
- **Words that narrow it**: "emergency", "urgent", "24 hour" or "after hours" put places open now first and leave out the ones known to be closed ("emergency plumber"). "Emergency room" is still a place, not a filter. Other words in front of the thing ("commercial plumber", "heavy duty generator") put the places that mention them first without hiding the rest.
- **Who it's for**: "for seniors", "for veterans"; "for beginners" looks for lessons and classes. "Family friendly restaurants" or "kid friendly pizza" puts the places that say so first.
- **Who's coming along**: "place to take my kids", "things to do with toddlers", "fun for teens", "what to do with a 5 year old", "where to take my dog" or "date night" shows the kinds of places that suit them (playgrounds, zoos, museums, splash pads and libraries for little ones; arcades, trampoline parks and go-karts for teens; dog parks and trails for the dog), nearest first and within about 25 miles. Buttons at the top switch between little ones, kids and teens, or indoors and outdoors. "Rainy day activities" or "things to do inside" shows indoor places.
- **Where**: "in", "near" and "around" mark the place, and so does a town at the end with no little word ("hardware store St Johns"). "St", "Mt" and "Ft" read as Saint, Mount and Fort.
- **What's going on**: phrases like "power went out" or "stuck on the highway" are situations (below).

### What are "Pairs with" and "Make a day of it" on a place's page?
**Pairs with** lists up to three other places within about 15 miles that go well with it, each a different kind (a canyon, a museum, a lake), the ones drawing the most interest first, with how far each is and what it's like. **Make a day of it** strings the place and two of those together in the order that drives least, ends with somewhere to eat nearby when there is one, gives the miles for each leg, and opens the whole route in Maps with one tap. A place to eat from OpenStreetMap says so; it isn't a Traversence listing.

### Who writes what a place is like when Wikipedia has nothing?
When a place has no Wikipedia summary, Claude writes two or three sentences on what it is and what you do there, from what we hold and at most one web search, with its sources. It's kept with the place and reused, never written again. We write ahead for the 20 places in each town that draw the most interest, so most are ready before anyone opens them; others are written the first time someone opens them. Places that may be sacred or a nation's are never written about.

### Two towns have the same name. Which one does search pick?
The one nearest you, or nearest the place you've set, when it's within about 150 miles ("Glendale" in Phoenix is Glendale, AZ); otherwise the one in the states we cover, then the larger one. While typing, a town named exactly what you typed comes before longer names that start the same way ("Phoenix" before Phoenixville).

While you type, two letters that could be a state's code aren't assumed to be the state: "dog pa" offers **Dog parks** first and asks "“dog” in Pennsylvania?" as a choice. After Enter, or with a comma ("show low, az"), the code is read as the state. A state named in your words is the place, at the start or the end: "arizona food" and "food in arizona" both show food across Arizona, nearest to you first. A town's own name always wins ("Virginia Beach", "Arizona City").

### Can I just describe what's going on?
Yes. Type it the way you'd say it: "the power went out", "stuck on the highway", "lost my keys", "job interview coming up", "I can't pay my bills". Search recognises the situation and shows what it needs, each part on its own: for being stuck on the road, **Towing**, **Roadside repair**, **Gas** and **Highway patrol**, each in your place first and then nearest. When something is urgent, the phone number and **Call** come first, and places known to be open now lead. Everything else your words found is one tap away under **Everything else**. You don't have to use any particular words: search also reads what they mean. "Bit by something", "a dog bit me" and "got stung" are all an injury; "my sink is leaking" is a plumbing problem; "ran out of my meds" is about prescriptions.

### Why does search say "If anyone is in danger, call 911"?
For a few situations where someone could be in danger, like a car accident, smelling gas, a wildfire or being stuck on the road, that line comes first. Everything else follows below it.

### Why isn't a business showing for something urgent?
For an urgent need, a business only shows if its listing has what you'd need to get help: for towing, a phone number. A listing missing it still shows in the directory, but not as an answer when it can't complete the task. If it's your business, claim your listing and add the missing details.

### What shows while I'm typing a search?
Only predictions, so nothing half-finished gets in the way. First **Search for "…"**, then ways your words could carry on (what you typed, with the rest in bold), and sometimes a **Maybe try**: a phrase the search noticed works well, offered as its own suggestion (only from words it understands, never anything personal), then **Go straight to**: what you might be thinking of ("Power out", "Gas for the car"), things whose names start with what you've typed, kinds of things, and towns and counties anywhere in the US. Places come first, right under the site's own tools (ours first, then the bigger towns elsewhere, marked "see what's there"), since where you're looking shapes everything else. It offers as many as match, up to 15, and keeps up with every letter until you stop, press Enter or pick one. While it's still one word ("for"), places and kinds of things come first, then listings and outdoor places that start with it, then stories, groups and experiences. When your words end in a town you're still typing ("moving to sea"), it offers them with each town that fits ("moving to Seattle, WA"). States show too, from two letters or the state's code ("ok" offers **Oklahoma**): "wash" offers **Washington**, the state, and its searches stay on the state, never Washington, DC. When something's name matches only past your Distance setting ("Ford": Show Low Ford, 38 mi, with 10 mi set), one row says how far the nearest is; tap it to widen to that distance. A word search doesn't know, like a model number ("Ford F150"), doesn't stop it: it suggests from the words it knows ("Ford") and the kind of place those names are (car dealers), and asks if you'd like to suggest the new word. When no name has all your words ("hearing test"), it shows the places the full search would find instead, so there's always something to tap. Many places that share a name at one spot ("Big Lake Dam…", "Big Lake Boating…") show as one line, **Big Lake · 9 places**; tap it to see them all. Until you type a space, search treats your last word as unfinished and finishes it the way you most likely mean: "live mu" offers **live music** and shows music venues, "self stor" shows Self Storage. Words that only describe a thing ("new", "live", "best") narrow what it is instead of changing it, so "new music" means music places. When your words clearly mean a kind of place, that kind and its places come first; a business whose name only shares a word comes after (a nurse named Musick isn't music). When many visitors who typed the same words picked the same kind, its line says "most picked": a label only, it never moves anything up. That's counted by the words and the kind only, never who, and each visit counts once, so one person repeating never changes it. When your words name a situation ("can't find my car"), its answer shows right there with the nearest places and **Call**. Tap any of them, or press **Enter**, and the full results appear with Suggestions and Quick Search. Clicking into the box selects what's there, so typing replaces it. **Esc** clears the words; press it again to close. On a phone, the **Location** line at the top also shows what Search Directory and Distance are set to. Tap it to open them, or tap ✎ to change the place. The likeliest come first: a name you've typed in full before one you've only started ("phoenix" puts Phoenix before Phoenixville, which is only 7 of its 12 letters), whole words before part of a word, and what's in the place you've set before the same name elsewhere ("plum" in Show Low offers Plumbers before Plum City, WI). Suggestions start once you've typed three letters; before that, your recent and quick searches show. When nothing fits the letters yet, it says so and Enter still searches them. On a computer, the place at the top of the search has a **×** beside it: tap it to search everywhere.

A word you're still typing is offered as the full words it's becoming, each saying what it would be for: "mexi" offers **New Mexico** (a state to explore), **Mexico** (a country), **Mexican food** (restaurants and Mexican cuisine) and **Mexican culture** (heritage, history, museums, cultural centers); "nava" offers the **Navajo Nation** (its land and visitor information), **Navajo County** and Navajo food and culture. The words come from public sources (Wikidata's countries and their peoples, our tribal nations, U.S. towns and counties), whether or not we list anything there yet; what we have comes first in the results. Words that name a kind of place come first as that kind: "dog park" (or "dog p") offers **Dog parks**, nearest first; "playg" offers Playgrounds. Tap the one you mean. The page you're on sets the order, never what's offered: on Let's Explore places, the outdoors and culture come first; in the Directory, businesses and food come first. Top to bottom, it answers in order: **where** (the Location line, asking there when your words need a place, like "near me"), **what your words mean** (a spelling offer, the full words a partly typed word is becoming, a situation like "Found someone's belongings" with its first answers, and the kinds of place it may mean), then ways to keep typing ("found a dog"; a word not finished yet, like "jalapen", offers the word it finishes), then the places and listings themselves. Press Enter (or the search icon) for every result; on a phone, **See all results for …** at the foot does the same. On the Directory page, **See them all in the directory list** at the foot of the results puts your words into the list and map below; Enter does the same. The words searched stay on the list as a filter ("“Found” ×"); opening the search again starts empty, for new words. Closing the search with × (or Escape, or a tap outside it) clears that filter and shows the whole directory again. After Enter the results open the same way as while typing: a word that starts a situation ("found": Found someone's belongings, Lost or found pet) leads, then everything that matches.

### What happens when I search "near me"?
"Near me", "nearby", "closest" and "close to me" tell search where to look, so they aren't matched as words: "concerts near me" searches for concerts. If you've set a place, it shows the **nearest**, each with how far it is, with no distance cut-off: our listings first, then what OpenStreetMap has. For everyday errands (coffee, groceries, gas) near means within 5 miles; for the outdoors (hikes, camping, fishing, parks), within 30. If fewer than 3 are that near, it says so ("Our results for coffee near Phoenix are lacking: the nearest of ours is 12 mi away"), and we hear about it: the words and the town (never who) go to our team, and the town goes to our crawler to find more. A hike counts by what a place is, not just its name: peaks, canyons, trails, preserves and parks come up for "hikes near me", and so do OpenStreetMap's trailheads. The Location line says **Near you** when the place came from your device. If you haven't set a place, **Where are you?** opens as soon as you type "near me" (and again if you press Enter), and it tries **Auto-detect** straight away (your browser asks permission, once; if you've blocked it, it says so). Or type your town or ZIP. It shows only what sets where you are: no trips, regions or distance, since "near me" is 2 miles around you. Nothing from everywhere shows until you set one, on any page, the business directory included: "near me" only makes sense around you. Just "near me", with nothing else, shows everything near you, nearest first (up to 25; with fewer than 3 of ours, what OpenStreetMap has too), then asks **Is there something specific you'd like to search for?** with one-tap choices (coffee, places to eat, groceries, gas, a pharmacy, things to do, where to stay, parks, health care). Close the picker and the results keep **Set my location** and **Use my location**. While you're still typing "near m", it offers **near me** to finish it. We don't keep your location; it's only used to set the place you search from.

### Why does search ask me to set my location?
The **Location** line at the top of search always shows where it's looking (a town, a distance, or Everywhere), and its pencil changes it: type a town or ZIP, or use your location. When your words need a place to mean anything ("near me", "nearby", "closest") and none is set, search also asks for a place right above the results: tap **Use my location** (the target icon) and it finds you in one tap, or choose a town or ZIP. A situation that needs a place, like "Locked out or lost keys", asks the same way. For other searches with no place set (pizza, a plumber), results come from everywhere and the Location line is where you narrow them.

Wherever a page or the search window asks where, it's one box and one button: type a town or ZIP and pick it (or press Enter on a ZIP), or tap the target icon to use your location. The box shows the place you're searching; × beside it clears it. **More choices** at the foot of the list opens the full picker: regions, your saved places, Distance, State · City · ZIP, Search everywhere and the Trip Planner. Distance comes after the place: it shows only once a place is set, and only for a town, a ZIP or your location (a region already has its own edges). Signed in, the picker offers your saved places and **My default place** instead of a way to sign in.

With no place set, the map never uses your location on its own, even if your browser already allows it. Under the panel's title is the same **Town or ZIP** box as everywhere else: type a town or ZIP, or tap the target to use where you are. A line under it says how the place was chosen: your default place, found by your device (the target), the region you came in through, one of your saved places, or chosen by you. On a page about one area, it says that area is the one shown. Typing in the box changes it. The count of places on the map stays in view; places OpenStreetMap adds are counted after ours. This is the same from the Directory and from Let's Explore. Tick "Always use my location when no place is set" to have the map use your location without asking on this device; the line then says so, with **Ask each time** to undo it.

When your words name a thing, search says what you might want with it, even if no business is named for it: "sea lions" offers **Where to see sea lions** (places that mention them), **Wildlife sanctuaries, zoos and aquariums**, **Help a hurt or stranded animal** and **Learn about sea lions**; a pet offers adopting, care and supplies; a food, where to eat it and where to buy it; a plant, where to see it and garden centers. What it is comes from WordNet, a public dictionary, so it works for any animal, plant or food, not just ones we've listed. Words that name one thing together are matched together: "sea lions" never finds a church "by-the-Sea" or a business in "All Seasons". Two real words one letter off a thing ("seal lions") get **Did you mean sea lions?**, offered, never changed. The kinds of place your words may mean show as buttons; tap one for those places.

When your words describe a situation and name a state's code ("ca tow truck"), search doesn't assume the state; it asks "In California? Where are you?" with a town or ZIP box and the target icon, then shows the nearest towing, roadside repair and gas.

### What happens if I misspell something?
Search never changes your words on its own. If a word isn't one it knows, it asks **Did you mean…?** and offers up to three of the closest words, the likeliest first: the ones that keep the most of what you typed, then the same first letter and the same sound. Each option says what it would find, like "bathroom: A restroom". Tap the one you meant. It asks while you type, too, once a word is finished. It only offers real slips: one letter off in a short word, two in a longer one. A word search understands, like "cardio" or "x-rays", is never "corrected", and neither is a word used here: a town's or a landmark's name, or a word in the names and descriptions of the businesses we list and the pages we read ("Blue Hills" is never "blue halls"). Two letters swapped count as one slip ("motle": motel). The words it offers come first from what's used here, the more often the likelier (our listings, the places named on pages we read, our towns and landmarks), then from the site's own dictionary (the same one behind spell check in forms), so a common word nobody has listed yet still gets offered: "swiming" offers **swimming**. When a word looks like a slip, "Did you mean" comes first, before anything else in the results. A slip always gets an offer: when nothing closer is found, the closest words our listings use are offered ("resturants": restaurants), and words run together are offered apart when they name a kind of place ("icecream": ice cream). While you're still typing a word, finishing it comes first: "jala" offers jalapeno, not a guess like "java"; a guess is offered only when nothing starts with what you've typed. The word it would finish is listed first too, above **Search for** what you've typed so far.

### Why does "mental health" show counselors and psychologists too?
Because they give that care, even when their name doesn't say "mental health". Search knows which kinds of business a phrase covers: "mental health" and "behavioral health" find mental health services and clinics, counselors, counseling services, psychologists, marriage and family counselors, social workers, and addiction and substance abuse treatment; "addiction" and "substance abuse" find the treatment centers. Places named for what you typed come first. Under **Closest kinds** you can tap one kind to see only those.

### How does search know what a word means?
It knows the kinds of place that serve everyday words, even when no business uses the word in its name. "X-rays", "xray" and "x ray" all mean Diagnostic Imaging Centers. "Cardio" and "gym" mean gyms and fitness centers. "Haircut" means barbers and salons. Each kind of business has the everyday words people use for it. An English dictionary (WordNet) and word meanings learned from a large body of everyday writing carry those further: "bread" reaches the bakery and the grocery store, and so do sourdough and bagels; "burrito" finds restaurants; "sedan" finds car dealers. That's worked out ahead of time on our server: your search isn't sent anywhere to be understood. While you type, those kinds show with how many are in your place. After **Enter**, **Closest kinds for "…"** lists them, one tap each. When it's only a loose guess, it says it's not sure and offers the guesses as **Maybe**. If nothing matches by name or kind, search shows what **mentions** your words in its description, then suggests changing your search (fewer words, or another word for it) and offers **Suggest it**. What people open after a search keeps improving it. When people keep searching for a kind of place we don't have yet, like cooking classes, search adds that kind on its own with the words people used, sends our crawler to look for such places in every town we cover (checking each one on its own website), and takes the kind away again if nothing comes of it.

### What happens if search doesn't recognize a word?
It says so instead of guessing: "We don't recognize the word 'frobnicate'", or "…the phrase" when each word is known
but together they don't name anything yet. Tap **Suggest it** and we'll look at it and teach search what it means.
Nothing about you is attached to the suggestion beyond what you type. If it's a slip, search may also ask **Did you
mean…?**, offering only words that fit where yours sits ("how to compost" won't offer "compass").

### What happens to words search didn't understand?
Search learns them. It already knows most everyday words from a dictionary: it knows a purse, a passport and keys are
someone's belongings, and that a hamster is a pet. So "I found someone's purse" or "someone stole my backpack" works
without anyone teaching it. For words the dictionary doesn't have (local names, new slang), search works out what they
mean on its own, from the words around them and from how our listings and trusted public sources use them, with no
person needed. What people tap afterwards never decides what a word means. Our team can see everything it learned and
undo any of it. Only counts are used, never who searched.

### What should I do if I found someone's wallet or lost mine?
Search for it the way you'd say it. "Found a wallet" or "I found someone's phone" shows the police (non-emergency)
near you to hand it in to, and a visitor center or ranger station if you found it on a trail or in a park. "Lost my
wallet" or "my ID was stolen" shows where to report it, where to replace a driver's license, your bank to cancel cards,
and where to replace a phone.

### Can I remove a suggestion that doesn't fit?
Yes. Tap the **×** beside a "Did you mean", a word that finishes your search, or a "May also help" result. It goes
away for you, and it counts toward taking that suggestion away for everyone who searches the same words. Only the
count is kept, never who removed it.

### How does search know which "fall" I mean?
Some words mean different things depending on the words around them, and search reads them that way. "I took a fall" or "fell down the stairs" is an injury, so it shows urgent care and emergency rooms. "Fall festival" or "fall hours" is the season, September to November. "Show Low Falls" is a waterfall. "A tree fell" is storm damage, so it shows tree services. "Feeling like I'm falling" is something you feel, so it shows someone to talk to and clinics. "Spring", "summer" and "winter" work the same way: "spring break" is the season, "hot springs" is a place. Showing only what's on during a season is coming; for now the season is read but doesn't narrow the list yet. If anyone is in danger, call 911.

### Can I search for something I need done, like "fix my chainsaw"?
Yes. Search reads what you want done and shows who does it: "fix my chainsaw" finds small-engine repair, "install a
water heater" finds plumbers and contractors, "register my truck" finds the motor vehicle office, "set up my printer"
finds computer help, "rent a trailer" finds equipment rental, and "building a deck" finds lumber, tools and builders.
If there's a how-to guide for it, it shows first; otherwise search shows the people and places that can do it or help.

### Are there step-by-step how-to guides?
Some, and more as people ask. When enough people search for how to do something ("how to compost leaves"), we gather
the steps from official how-to pages only, such as university extension services and government agencies. Our team
then puts them in our own words and checks each step against its source before the guide shows. Each step links to
its source. Search for "how to …" and a published guide comes first, followed by who can do it for you. If a step is
wrong or missing, tell us from the guide.

### Can I say when I need it, like "asap" or "this weekend"?
Yes. "Now", "asap", "right away" and "emergency" put places that are open now first. "Tonight", "today", "this
morning" and "this weekend" leave out places known to be closed then. "Fall", "spring", "summer" and "winter" are
read as the season. "Upcoming" and "coming up" are read as a time, not a word to search for; showing upcoming events
is coming.

### What does "May also help" mean in search?
Search learns what words mean, on its own: if the words you used clearly mean a kind of place (from the words themselves and trusted public sources that back it up), that kind can show under your results as **May also help**. What people open afterwards never decides it; it only helps choose between two kinds that fit your words equally well. It learns from counts of the words only, never from who searched. When a place people need is missing nearby, our crawler looks for it in public data and on official government and school websites first.

### Why does search show phone lines, not just businesses?
Some things that go wrong aren't a business's job: reporting a power outage, a road hazard, or finding local help. For these, search shows **Phone lines and services** from our area guides, with a **Call** button. Every number was found on the provider's own official website when we last checked, and we check them again every month. The full guide for your area is one tap away. If a number is wrong or missing, tap **Tell us** on the guide. If anyone is in danger, call 911.

### Can I search a county?
Yes. Type it with the word "county": "restaurants in Navajo County", "pizza Apache County AZ", "King County WA". Search looks across every town in the county. Your place stays as you set it.

### Does search know towns you don't cover yet?
Yes. Any U.S. city or town you name is the place you're searching, whether or not we have listings or a guide there yet: "pizza in Phoenix", "Dana Point", "hotels in Sedona". Arizona's towns come first when a name is used in more than one state (Glendale is Glendale, Arizona); add the state for another one ("Glendale, CA"). When your words are the exact name of a place we have ("Four Corners Monument", "Laguna Art Museum"), you get that place, not a town that shares its first words. If we don't have much there yet, search says so and offers to build its guide, and asking for it is how we know where to grow next.

### What happens if I search just a place's name?
Search asks what you'd like to know about it: **things to do**, **places to eat**, **places to stay**, **moving there** or **plan a trip**. Tap one to search it there. Your place doesn't change unless you tap **Make it my place**. This works with just the town's name too, like "Seattle". If a town's name is used in several states, like Springfield, search asks **Which Springfield?** and lists them.

### Can search take me to the Trip Planner?
Yes. Type what you're planning, like "planning", "plan a trip", "road trip" or "vacation", and the **Trip Planner** shows first while you type, set to your place. Press **Enter** and search asks if you were looking for it, above the results. If your words name something else too, like "planning and zoning", the offices come first and the Trip Planner follows them. Saving and sharing trip plans is coming.

### What happens if I search for "help"?
We ask which help you mean: **help using Traversence** (the Help Center and FAQ) or **help in your place** (assistance, services and support). If you type what kind of help, like "legal help" or "housekeeping help", we search for local services straight away.

### What happens if search can't tell what I mean?
It says so instead of guessing. You won't get a list of things that just happen to share a word ("standing on the corner" won't find a business with "corner" in its description). If your words point to a situation, like "stuck" or "leaking", it offers those under **Maybe you mean**. Otherwise, name the kind of place or service (plumber, pizza, campground), or say what's going on (stuck in the mud, the power went out). You don't have to press Enter: pause for a moment while typing and the results, or where your words are heading, appear.

### Does Traversence keep what I search for?
Not who searched it. We count the words people search, by area and day, and how those searches turned out (found something, found nothing, or searched again), for words typed but not searched, whether a suggestion was tapped or the search was closed, and what kind of thing was opened afterwards (a tire shop, a pizza place, never which one you are), so we can see what search doesn't understand yet and fix it. No account, device or location is kept with them, and words only show to our team once several searches used them. Your recent searches stay in your own browser.

### Why does search ask "Where are you?"
For something you need nearby, like a restroom, gas or a tow, "nearest" only means something once we know where you are. Tap **Choose your place or use Auto-detect** and the nearest places show. Auto-detect doesn't share where you are. Once you've set a place, search uses it. That includes a city, state or ZIP outside our regions, like Seattle, so it won't ask again.

### I set a place outside your regions. What does search show?
It searches there. Naming the place in your search works the same way, even while you type: "moving to Seattle, WA" or "moving to Seattle Washington" answers for Seattle without changing your place. When the words are both a town and the start of a name we have ("four corners": Four Corners, Wyoming, and **Four Corners Monument**), the name is offered too, however far it is from that town. If we have no listings there yet, search says so ("We have no listings in Seattle, WA yet") instead of showing places hundreds of miles away. For everyday businesses (places to eat, coffee, places to stay, gas, groceries, pharmacies, hospitals and clinics, self storage, auto repair, hardware and laundry), it shows a few nearby from **OpenStreetMap**, the free, open map, whenever we have none within your Distance setting, in our areas or not ("coffee near me" in Phoenix shows Phoenix coffee shops, not ours 90 miles away). They're marked as OpenStreetMap's, not our listings, with what OpenStreetMap knows (what it is, how far, its address, phone and hours when it has them); a tap opens directions. It covers the outdoors too: trailheads, parks and preserves, viewpoints and campgrounds ("hiking near me" shows trailheads), never anything marked historic or that may be a sacred or protected place. The same search also sends the town to our crawler, which finds its places to eat, stay, do, shop and health care on the map and on each one's own website, and checks them like every listing, so real listings usually follow within an hour or two. Landmarks and attractions never come from there. For everything else, and for more, you can carry on your search on **Google Maps** with one tap: one link for each thing you need (for a move: movers and trucks, storage, utilities, places to live), or one for what you typed ("pizza near Seattle, WA"). It opens in a new tab with only your words and the town. Nothing about you goes with it, and we only count that a link was tapped in that town. Tap **Choose another place** to pick another one.

### What are the lines that finish my words as I type?
They're ways your search could carry on, like "where can i park **overnight for free**" or "parks **for kids**". What you typed is plain and the rest is bold. Tap one to search it. They come from the situations we know, the ways people ask ("…check out", "…worth the drive") and what fits the thing you named (open now, this weekend, near your place). They don't come from other people's searches.

### Why doesn't "parks" show RV parks?
Search reads the kind of thing you mean. "Parks" are parks, including state and national parks. RV parks and mobile home parks are their own kinds, so search for those by name ("RV parks"). "Where can I park" is about parking: places to stay overnight with an RV or camper, rest areas and truck stops, parking lots, and who to call about parking rules.

### Can I search near a lake, park or landmark?
Yes. "Plumber near Lyman Lake" searches about 15 miles around the lake, and if there are none that close, the nearest ones beyond follow. Your own place stays as you set it.

### If I search a business by name, can I find others like it?
Yes. A business named in full shows first, with what it offers and **More like it nearby**.

### What if nothing matches all my words?
If no place has every word you typed, **Suggestions** lists each word on its own with how many it finds, like **Search "hat" · 1 found**. Tap one to search for it.

### Does searching change the place I set?
No. Search starts in the place you set and never changes it. Results in your place come first. Anything that matches beyond it follows under **Beyond (your place)**, nearest first, with how far away it is. If you chose a town, like "Saint Johns, AZ", that town comes first, and the rest of its area follows under **Beyond**. To search somewhere else for one search, say so: "pizza in Show Low". Your place stays as you set it. A town outside our regions counts only when you say "in" or "near" it, or name its state.

### Can I save my own search phrases?
Yes. In the search panel, **⊕** next to **Quick Search** adds the words you've typed as one of your quick searches, and **✎** lets you add, change or remove them. For now they're saved in this browser. To keep a search on your account, with its place, use **☆ Save** on its results.

### How do I switch between the list and the map?
Use the **List / Map** toggle at the top right of the directory. The map opens full screen with every result as a pin. **Exit map** brings you back to the list, which keeps any filters you changed on the map.

### Where do I find the guide to a town or area?
On Let's Explore, with the place set, **The guide to …** sits at the top of Journeys & guides: its towns, places to go, the outdoors and local businesses. Searching the town's name opens it too. A town with no guide yet offers **Build the guide** in search: a first look in about two minutes, the full guide after.

Each business in a guide shows what it is, its street, and whether it's open now when we know its hours. Our crawler reads these from the business's own website and checks them again every month or so; one we haven't read yet shows its name, kind and distance until it's been read.

### What can I do on the map?
- **Search:** type in the search at the top and press Enter. The pins change to match.
- **The list, nearest first:** the panel lists everything on the map, ours and OpenStreetMap's together, nearest first with the miles: from where you are (the blue dot, or the location you've shared with the site), else from the place you've set, else from the middle of the map. The line above the list says which. A business we only know by its ZIP code shows "about … mi · location approx." and comes after the ones we know exactly at about the same distance. Tap one of ours to choose its pin and see its card; one from OpenStreetMap opens directions. **Show 25 more** goes further.
- **Controls** (bottom right): zoom in and out, **Go to my location** (the arrow: it moves the map to where you are), **Search this area**, and **Map style**.
- **Where it opens:** in a 5-mile circle around your place when your place has a point (Auto-detect, or a ZIP), or, with no place set, around you (your browser asks once whether to share your location); widen with the distance or **Search this area**. Opened for one place, it opens there.
- **A pin's card:** its photo when it has one (credited), what you'd do there (**Walk**, **Drive**, **Hike**, **Exhibits**, **Views**, **On the water**, **Camp**, **Picnic & play**, **Historic site**, from what the place is), a few lines on what it is (from Wikipedia; for a place without an article, the first time anyone opens it Claude, the AI we use, writes two or three sentences from what we hold and public sources, kept for everyone after; until then, what Wikidata records: whether it's on the National Register, when it dates from, its style and architect), then, when one of our guides tells its story, the guide's own words about it (**From the Glendale guide ›**), where it is, hours, and **Call**, **Directions**, **Website** and **Open**. Been there? **Add a tip or review** or **Suggest a change** sits right with it. Places are ranked by the interest they draw (how much people read about them on Wikipedia, how many Wikipedias cover them, and the guides and journeys that name them), then by distance.
- **Where you are:** a blue dot marks where you are as soon as the map opens, if your browser already shares your location with Traversence (or your place came from Auto-detect). It doesn't ask on its own; tap **My location** for that. Your location stays on your device.
- **Moved the map?** A **Search this area** button appears at the top, in words, so you can look where the map now is.
- **Nothing of ours there yet?** The panel offers **Search this area**, **Widen to 25 mi**, and what OpenStreetMap has there as lighter pins, not our listings: with no words, everything everyday at once (places to eat, coffee, groceries, gas, pharmacies, places to stay); or one kind at a tap, trails, parks and campgrounds included. Tap a pin for what it is, its address, phone, hours and directions. If your words name a kind ("coffee shops"), those show at once. Asking also sends that town to our crawler, so our own listings follow, usually within an hour or two.
- **The panel:** the tab on the map's left edge (the bottom on phones) opens it. It has what's shown, the distance, "Search this area as I move the map", the map style, and the details of the place you tapped. Use the arrows there to step to the next place nearby.
- **Folding the panel (phones):** the chevron at the panel's top right folds it down to its title, so you can see more map. Tap the title or the chevron to bring it back. Tapping a pin brings it back too.

### What does Auto-detect do?
It sets your place to the town you're in, by its name ("St. Johns"), not the wider area around it, right away: searches look at that town and the miles around it, and the directory follows it. Let's Explore shows the town's name, with the area it's in under it, since its pages cover the whole area. Set your place with it before this change? Tap the target once more. If it can't name the area, it says so; pick a region or type a ZIP instead. To change it, tap the place again.

### Does "My location" share where I am?
No. It only moves the map on your device. It isn't saved or sent anywhere.

### What do the hearts on the map mean?
A heart in a circle is one of your favorites: a business you linked or saved to your Address Book. Favorites always show on their own, never grouped with other pins.

### What map styles are there?
- **Streets** and **Light** (a faded map, so pins stand out) cover everywhere.
- **Terrain** (topographic) and **Satellite** (with towns and roads labelled) cover the United States.

The map remembers the style you chose.

### I set Distance to "My place only" and nothing came up. Now what?
Search says so and tells you how far the nearest one is ("Nothing in Saint Johns. The nearest is 23 mi away."), with buttons for the next distances out, like **25 mi**, **50 mi** and **No limit**, each showing how many it finds. The same happens at any distance, including the 10 mi it starts at ("Nothing within 10 mi of St. Johns. The nearest is 40 mi away."). Tap one and the Distance slider moves with it. Search never looks further on its own. Your place stays as you set it.

### Why do some category names look shorter than in other directories?
Business categories often carry trade codes, like "Automobile Parts & Supplies-Retail-New" or "Feed-Dealers (Whls)". We show the plain name ("Automobile Parts & Supplies", "Feed-Dealers"). "Used" stays, because it tells you something.

### What if there's nothing like it where I am?
The search tells you: "No 'pizza' in St. Johns yet." You can **Recommend one**, or **Add a listing** if it's yours. Below that, it shows the nearest towns that do have it, nearest first. Tap one to see it on the map with what's around it.

### How do I filter the directory?
Tap the search at the top. At the foot of **Quick Search** are the filters: **Near me**, **Open now**, **Has a phone**, **Has a website** and **Favorites** (businesses you linked or saved). Whatever is narrowing the list shows under the title; tap × to remove it.

### How do I change where I'm looking?
Tap the place at the top left of the directory (📍 and the place name) and choose another. To clear it and search everywhere, tap the **×** beside it.

### In what order are businesses listed?
For a town or "Near me", nearest first. Otherwise, the best match for what you searched.

### Can I comment on a business, a place or an experience?
Yes. Most pages have **Comments** at the bottom: share a tip, or say what it was like. You need to be signed in and 18 or older. Comments are public and show your name. You can remove your own, and report one that breaks the rules. Stars and ratings aren't used: say what you think in words.

### What is my gallery?
Every photo and video you keep on Traversence, in one place: open **Gallery** in your Dashboard menu. It's grouped by year and month, by when each photo was taken (six a month, then **View all**), and photos from your journeys and your profile appear there too. **Upload** adds photos and videos (a video can be up to 1 GB; your phone makes photos a sensible size first, and the place a photo was taken is never sent). Tap a photo to see it full screen: swipe or use the arrows, pinch to zoom, and tap the dark background, press Esc or tap × to close. **Select** lets you put several in an album, or delete ones you uploaded (photos from journeys or your profile are removed where they live). Open one and its ⋯ menu edits your photo's caption, its alt text (a description for people who use screen readers) and when it was taken, or deletes it. A business has a gallery too (see below), and an album can be a Portfolio for clients or Brand & documents.

### Who can see my albums?
You choose for each album, under **Edit & who sees it**: **Public** (anyone, shown on your profile's Gallery tab), **Unlisted** (only people with its link or QR code; search engines don't list it) or **Private** (only you and the people you invite). **Share** gives you the link, your phone's share sheet and a QR code. What you upload is private until you put it in an album you share. Open any photo and it says who can see it, from the most open album it's in: **Public**, **Anyone with the link**, **Invited people**, or **Only you** (**Your team** for a business's photos); a journey or profile photo follows its own page. **New link** gives an album a fresh link at once, and making it private does the same, so any link or QR code you shared before stops working, photos included. Deleting an album keeps its photos in your gallery.

### How do I add photos or a video to my business or my profile?
Open your listing (as its owner or manager) or your profile, and tap **Photos & video** on the picture at the top. Add up to 8 photos, or link a YouTube or Vimeo video, and choose which shows first. Use your own photos, or ones you have permission to use. We keep a resized copy and nothing else from the file, such as where it was taken. On a private profile, only your connections see them.

### What do the views and likes on a page mean?
Views count visits that saw the page. Likes count people who liked it. We never show who viewed or liked anything. Likes are checked for automated activity, so a count means real people: likes that come at a machine's pace, or more likes than a page has views, are taken off the count, and anything unusual is looked at by our team. **Share** sends the page with your phone's share options, or copies its link.

### Does Traversence track when I call or visit a business's website?
We count it for the business, never who did it. A tap on Call, Directions, Website or a contact page adds one to that business's count for the day. No name, account, device or address is stored with it. Businesses see the totals for the last 30 days.

### What does Traversence count about how the site is used?
Totals only, never who. We count how many visits see each section, listing, journey and place. We also count how people move between sections, and what they search for in which place, with how many results it found. No name, account, device or address is stored with a count. Search words are lower-cased, with email addresses and long numbers removed, and counted by area and day so search can learn what people here look for and what's missing. They're only shown in our reports once 3 or more visits searched them. Rarer ones are deleted after 90 days. Our own team's visits aren't counted, and a business's own people looking at their listing aren't counted on it, so the numbers are visitors'. Businesses see visits to their listing in Business Insights.

### Why is a pin marked "approximate"?
Until we've placed a listing's street address, its pin sits in the middle of its ZIP area. When you open it on the map, we look the address up and move the pin if it matches. Rural addresses don't always match an exact spot. Mileposts, roads without numbers and mail-only addresses are examples. When we can only place a listing near where it is, we say so.

### A pin is in the wrong place. How do I fix it?
Tap **Wrong spot? Fix the pin** on the map card or the listing page. Drag the pin to the door (or tap the map, or tap **I'm here now** if you're there), then **Send**. You don't need an account. We check every suggestion before the map changes. If you run the business, or you're Traversence staff, your pin is saved at once, and you can change the address too.

### I own the business. How do I change our address or pin?
Open **Location and map pin** from Business in your Dashboard (or from the listing page). Change the address and the pin follows it, or drag the pin to your door and save. Only the business's owners and managers, and Traversence staff, can do this.

### Why doesn't a listing have a map pin?
A few reasons:
- The address is a PO box or mail-only, so there's no place to pin.
- We haven't confirmed the spot yet.
- The business asked to keep its address confidential. Those listings show a phone number only and never appear on the map.

### Where does a business's information come from?
From the evidence. Each listing's details (name, address, phone, website, hours) come from what we can find about the business: its own website, official registries, and other pages that match it by name and address or phone. When those disagree with what we had, **the evidence wins**: the value with the most independent sources goes on the listing by itself. Our team can see every change and undo it. Google, Yelp and Facebook pages only confirm what we found; we never copy from them. Every source we use is on our list with its licence, and the licence decides what we may do with it: keep its facts, show it with credit, link to it, or only use it to confirm. OpenStreetMap, for example, only tells us a place exists and links to it; Wikipedia gives us facts, never its words.

Once a business is **claimed and confirmed** (✓ Verified), its owner decides. Nothing we find changes it on its own. While a claim is only **Managed by owner** (step 1 of claiming), what we find can still update the name, phone, address and website, but never anything the owner wrote. Instead the owner sees **We found other information about your business** on their listing, with each value and where we found it, and can **Use this** or **Dismiss** it.

### Why does my listing say "We found other information about your business"?
Only you see it, as the listing's owner. It lists details we found about your business elsewhere (your website, an official registry, another page that matches you) that differ from your listing. Your listing keeps what you set. Tap **Use this** to put a value on your listing, or **Dismiss** to set it aside; dismissed values aren't offered again.

### What does Traversence show on a tribal nation's land?
What is public: established boundaries, key resources and services, public businesses and publicly known places, each with the nation's own name and its rules for visitors. What is sensitive or specific to the nation, such as sacred, burial or ceremonial places and its springs, is not shown. It stays that way until the nation has its own controls on Traversence and decides. When a nation asks us to close something, it stays closed until the nation asks to reopen it.

### Where does the information about a landmark or outdoor place come from?
- **Landmarks:** the name, the kind of feature and the map point come from the federal names registry (USGS Geographic
  Names). The description comes from Wikidata and Wikipedia, credited on the page.
- **Outdoor places** (campgrounds, trailheads, recreation areas): Recreation.gov, the federal recreation registry. That
  covers who runs the place, what you can do there, its phone and its page. It's refreshed each month.
- **Phone lines in a resource guide:** our staff enter them. A line shows only when its number was found on the
  provider's own official page at the last check.
- **On a tribal nation's land:** we keep only the places the nation has opened to visitors. Nothing is kept about the
  rest.

Events will work the same way when they're added. Marketplace posts come from the people who post them (see Buying and selling).

### Why doesn't a landmark have a photo?
A landmark's photo comes from Wikimedia Commons, a free library of photos, credited to the person who took it with its licence. If the landmark's own entry has none, we look on Commons for one taken there: free to use, named for the landmark, and taken nearby (or naming its state, county or town). We look every hour, a few landmarks at a time, and look again a month later for ones with nothing yet. You can also add yours with **Share a photo** on the landmark's page.

### Where do a listing's phone number and website come from?
From the business's own website first, then official registries (like the NPI Registry for health care and the IRS
list of nonprofits), then other public pages that show the business with its name and address. A number goes on a
listing when the business's own website, a registry or a government page gives it, or when two separate websites
agree; otherwise our staff check it first. Google, Yelp and Facebook pages are links that tell us where to look,
never a source on their own: we link to them rather than copy what they say. If you own the business, claim your listing to set your own
details: once your claim is confirmed, they're never overwritten.

### I own a business. How do I get it listed?
Use **Add or claim a business** at the bottom of any page. If your business is already listed, claim it. If it isn't, add it yourself: it takes a few minutes from your phone, and it's live as soon as you confirm a code we email you.

### Can I add my business if it only has a Facebook page, or no website at all?
Yes. A website isn't needed. Give its name, what it is, the town, a phone number, and a street address, or tap **Use where I am now** to drop a pin if there's no usable address. Add your Facebook page, website, hours and what you offer if you like, and photos once it's live. Your Traversence listing can be your business's page on the web.

Before saving, we check whether it's already listed (the same phone, website or Facebook page, or a similar name in the same town). If it is, we show you and you can claim that listing instead, so there aren't two.

### How do you decide which category a business is in?
From what the business says about itself: what its own website calls it, its name, what it offers and its description, matched as whole words (so a "spa" is never found inside "newspaper"), and from which industry those words point to. When it's clearly one category, that's the one; when it isn't, a person picks. A word that happens to be in a name ("Dollar Tree" isn't a tree service) never decides on its own. We also check the businesses already listed and correct a category that plainly doesn't fit (a school district filed under nurses); anything less certain goes to our team, and a category an owner or our team chose is never changed. If yours is wrong, claim your listing and set it, or use **Suggest a change** on the listing.

### Can my business be in more than one category?
Yes. Every business has one **main category**, shown on its card, and can be listed under **up to 4 more**. On the add-your-business form or in your business dashboard, tap **+** beside the category to add another, then type what it is ("movie theater", "event venue", "party rentals") and pick it from the list. Can't find yours? Pick the closest and tell us; we add new categories as businesses need them. People searching any of those categories find you there too, after the businesses whose main category it is. No plan gets more categories or ranks higher: they're the same for everyone. Pick the ones that match what you really do; that's where they work best.

### What should I put in "What you offer"?
Short names of what people come to you for, one per line: "Matinees", "Private screenings", "Concessions". Anyone searching for one of them finds you, even if it isn't a category. Your business dashboard suggests a few that similar businesses list.

### What name should I use for my business?
The name on your sign works best. What you do ("Movies, Popcorn & Parties") is better in your categories and in "What you offer", where people's searches find it. We'll suggest this if your name looks like it carries a list of services, but it's your choice.

### What do I need to add or claim a business?
A Traversence account (18 or older) with:
- **a confirmed email**: the link we email you when you join (you can ask for it again from the page);
- **a phone number**: it stays private, only our team sees it, so we can reach you about your listing;

To add a business, the form also asks for **the business's phone and email**. Your account email is filled in; change it if the business has its own. The business email isn't shown on your listing.

If you're not signed in, the page lets you sign in or create an account and keeps what you've typed.

### Where do the listings come from?
From public information: the business's own website, official records such as the federal list of health-care providers (the NPI Registry), open map data, and directories like chambers of commerce. Our crawler gathers what's there, checks that a business is real (its own website, an official record, a government page, two separate sources, or one source whose page says enough about it: that one shows as unconfirmed until more agree), puts it in the category that fits what it says it is, and joins it with what's already listed instead of making a second copy. Each listing goes up unclaimed, ready for its owner to claim. Each fact keeps where it came from, from the first time our crawler sees a business: what it found and which other sources agreed are kept together, and stay with the listing once it goes up (or with the listing it turned out to be). A business we haven't listed yet isn't forgotten either, so the next time it comes up we already know what we've seen. Open map data (OpenStreetMap) only tells our crawler where to look; what we keep is what the business's own site or an official record says.

### How often does your crawler read a website?
Only as often as it changes. Our crawler keeps a note of each page it reads (its address, when, and a fingerprint of its text, never a copy of the page) and asks the website first whether the page has changed; a page that hasn't isn't downloaded again. Pages that change often, like an events calendar, are read again within a week or two, pages that don't up to every three months, and never more often than the site's robots.txt allows. It reads a page's own structured data first (schema.org, the same markup search engines read), so a business that puts its name, address, phone and hours there is read just as it wrote them. On a page that lists many places, like a county's services page or a chamber's members, each one is read as its own place, with the kind of business its words describe and its town. Search finds the businesses named on those pages even before they're listed (see below).

### Can your crawler take a website off a listing by mistake?
It shouldn't, and we've made sure a missed visit never counts. Our crawler works in short runs, and a run sometimes ends before it reaches everything it set out to check. Until now, a website it never got to could be counted as one that didn't load, and after two of those it came off the listing. Now a check that wasn't done is simply done later: a website comes off only when our crawler actually tried it twice, at least three days apart, and it didn't load. The same goes for the pages we read: a visit that ends early keeps everything we already knew from that website, and each page replaces only what that same page said before. Guides are protected the same way. If a guide's draft doesn't finish, the guide stays as it was, and one our team took down stays down. A section someone on our team saves while Claude is writing is kept as they wrote it. The monthly load of natural landmarks never deletes a place that's held for a person or a tribal nation to decide on. We're now checking the websites taken off before this change and putting back those that load (coming). If you see a listing missing its website, tap **Suggest an edit** on the listing and tell us.

### How does your crawler choose which websites to read?
On its own, for most of them. It meets websites through the pages it reads: when a county page or a chamber's list links to another site, that site joins its list too (a link from a business's name on the page is taken as that business's own website). On each site, it reads the site's map of its pages (its sitemap) and its new pages first, so over a few visits it covers the whole site, not just its front pages. Once a month it also reads the free public web archive Common Crawl, which captures billions of pages: from it, it finds every town, county and state office site in the states we cover, and reads up to 50 pages of each website we read regularly without visiting the site itself. Every website it meets goes on its list with what kind of site it is, from its address and from what the site says about itself (its title and description). A site that said nothing the first time is asked again two weeks later, and any site still waiting for a decision is looked at again every two months. A **Visit website** link next to a business on a page we read fills in that business's website, rather than being treated as a site to read. When our team reads a site through Listing Intake, it counts as a visit too: its pages go in the crawler's notes, the site joins its list, and the places it names are kept for search where the site's terms allow (never from directories we only cite, or a site our team set aside). Public bodies, like government offices, counties, cities and schools, are read regularly from the start, since what they publish is public. Commercial directories and social media are never copied, only cited. Chambers of commerce, tourism sites and other organizations wait until their terms are checked. Tribal nations' websites are always a person's decision. Our team can change any call, and theirs always stands. It reads PDFs as well as web pages, like a county's list of transfer stations or a poster of hours. A PDF that's a picture of a page (a scanned flyer) is read by a text scanner (AWS Textract), and a page that only shows its text in a full browser is read through a service that renders it (Tavily), each within a small monthly budget. Neither is ever used on a page a website asks crawlers not to read.

### How can your team see where a listing's details came from?
Every fact we hold about a business (its name, address, phone, hours, website) keeps each source that gave it: the business itself, our team, an official record, or a page our crawler read, with the date. For a page, it also shows how it was read (its own structured data, an item on a list, a scanned flyer) and what that website's terms let us do with it. When a page we read names a business we already list, what the page says joins the listing's record as one more source, so where sources disagree, our team sees it at once.

### Do some websites count for more than others?
Yes, by their record. Each website our crawler uses keeps a count of how often what it showed was later borne out (the business was confirmed and listed) and how often it was shown wrong (the business had closed, or never existed). A site that's right nine times in ten counts for more toward the two independent sources a listing needs; one that's often wrong counts for less, or not at all. A duplicate or a business outside what we list doesn't count against a site. Our team can see each site's record and change how it's used.

### What happens when your crawler can't confirm a business?
The free steps come first: our own index, open map data, official records and the business's own website. When they can't settle it, a paid step can, within a monthly budget we set: Claude (an AI from Anthropic) looks the business up on the web and says whether it's open, closed or not found, giving the pages it relied on and the words on them. We check those words are really on those pages before anything counts. A business confirmed this way is listed under the same rules as any other; one shown to have closed is set aside, with the page that says so, and our team can undo it. Places on tribal nations' land, and places whose location is kept private, are always left to a person. Claude also reads the terms of websites like chambers of commerce, to decide whether our crawler may read them regularly or only link to them, quoting the sentence it relied on.

### How does search show it understood me?
At the top of the results, in one line: "Read as a kind of business: Gun Clubs, near St. Johns", "Read as a name", "Read as a need" or "Read as something to do". If that isn't what you meant, the line offers other readings one tap away: another kind your words could mean, or just the words as you typed them. Ask about one thing, like "Blue Hills Motel hours" or "phone for Joe's Diner", and the answer comes first: the hours or the phone, from the listing, or from the page we read it on, with a link to that page.

### What is "From pages we read" in my search results?
Pages our crawler reads regularly whose titles match your words, from sites in the place you're searching: a county notice, a calendar of events, a list of services. Each opens the page itself, so you can read it where it was published. We keep a note of each page (its title, its address, when we read it), never a copy of it.

### What is "Named on pages we read" in my search results?
Businesses our crawler found on pages it reads regularly, like a county's services page or a chamber's members, that aren't Traversence listings yet. They show when we have few listings of our own for what you searched, nearest first, each with the page it's named on (tap it to see that page) and Call or Directions where the page gave a phone or address. Each one is on its way through the same checks as any business we find: once another independent source agrees (its own website, an official record, a map), it's listed; until then it stays here, never mixed in with our listings. Know one of them is closed or wrong? Use **Tell us** under the results.

The same rules as our listings apply to them. A place that may be sacred, a burial place or an archaeological site isn't shown here unless it's plainly open to visitors (a museum, a park, a historic site), and on a tribal nation's land only businesses show, with the nation's name and a reminder that visitors follow its rules. A shelter's address is never shown, only its phone. A name that reads as a person's (a contact on a county page, say) isn't shown either. Nothing is thrown away: what isn't shown is kept, marked, for our team and, once their tools exist, the nations.

### Why doesn't a domestic-violence shelter show its address?
To keep the people inside safe. Domestic-violence shelters and safe houses don't take walk-ins: you call, they talk with you, and they arrange where to meet. So their listing shows their phone, and **Need help now?** with 911, the National Domestic Violence Hotline (1-800-799-7233, 24 hours) and its text line (text START to 88788). If a shelter publishes an office address itself, that shows. Calls and texts go straight from your phone; we don't see or keep them. Their listings are also never sent to a search or map service to be checked: we check them against our own records only. Every other place, including homeless and family shelters, crisis centers and care homes, shows its address.

### How do you know a listing is right?
Our crawler checks each business against public sources: its own website, official records, government pages and directories. Open map data (OpenStreetMap) only tells it where to look: its phone, hours and address are never copied, only what the business's own website or another source we read says. A business found on just one website can be listed when that page gives enough (its street address and phone, say); it's marked unconfirmed and is checked again and again until more sources agree. A town someone searches for is looked at again a month later, and for the kind of place they searched (storage, auto repair, pharmacies) when that isn't one we already look for there. When its own website lists its locations, that wins for each location's phone and hours. When a source shows the business at another address, it isn't listed at the old one until that's sorted out. Each listing shows when it was listed and when it was last checked. Our crawler reads each listing's own website again every month while we're less sure of it (under 51) and every three months once we're surer, and Google is checked at least every three months: it fills in what's missing (never changing what a person wrote), and checks that the business is still there. When the website now shows a different phone number or different hours from the listing, our team gets the new ones to check (a site's number can be a head office's, and hours can be one season's), and the listing changes once they confirm. It also looks over the listings for one business listed twice (the same phone with the same name, the same street address or the same Google place) and offers each pair to our team to merge; two businesses sharing one number are left as two. A website that stops working, twice a few days apart, comes off the listing (or goes to our team, if the owner entered it), and it stays off until the business's site works again or someone puts it back. Every change to a listing, by our crawler, our team, the owner or a visitor's accepted fix, is kept with who or what made it, and what it replaced is kept too, so nothing we learned is lost and an old value never quietly comes back. A listing's phone, address or website is changed by what other sources say only when two independent sources agree (one website counts once), and a business's name only ever gets spelled out in full, never swapped for another name. When two listings turn out to be one business, what we knew about both is kept together on the one that stays. When a business's own website says it has closed for good, its listing shows **Possibly closed**, quoting what the site says, with **Still open? Tell us**, and our team checks. It shows Closed (still findable, with **Reopened? Tell us**) only once a person or the owner confirms it: one website alone never closes a listing. If the site stops saying so, the notice goes. When its website says it has moved, our team gets the new address to check (never changed on its own, since one branch moving isn't the business moving). Something wrong? Use **Closed, moved or listed twice? Tell us** on the listing, or claim it if it's yours.

### What is the number in the circle on a listing?
How sure we are of the listing, out of 100. It's on the listing's page and on its card in the directory, guides, the map and search. Tap it to see how we know: each source that agrees (our own team, the owner, local people, an official registry, a government page, its own website, a chamber of commerce) and when we last saw it. Many rural businesses have no website or online record, so what our team enters and checks, the owner's claim and local people's confirmations count the most; having no website never counts against a listing. Red (up to 25) means our crawler found it and nothing else has confirmed it yet; orange (26 to 50) means some sources agree; gold (51 to 75) means enough independent sources agree; green (76 and up) means a person stands behind it: our team checked it, or the owner claimed it (with ✓ once they've shown it's theirs). Sources and computers alone never make a listing green, but they still count once it is: a claimed listing that other sources back up climbs toward 100. Older evidence counts for less, and a website that stops working or a closure report lowers it. Under the evidence, **Is this right?** lets you say Yes (it counts once a day from your device, and we never record who) or No (it opens a correction our team reviews).

### Why did Traversence call my business?
To check your listing is right. Many local businesses have no website or online record, so our team calls the ones we're least sure of to confirm you're open and your name, phone and address are right. It takes a minute, and it's how your listing earns its green "Confirmed by Traversence" mark. We may also tell you how to claim your listing (free), so you can keep it up to date yourself. If we reached a wrong number, or you've moved or closed, tell us on the call, or use **Closed, moved or listed twice? Tell us** on the listing.

### My business is listed and I didn't ask for it. Can I change it or have it removed?
Yes. Claim it (**Claim it** on the listing) to correct it, add what's missing, or make details private. Or use **Closed, moved or listed twice? Tell us** on the listing to ask us to remove it, and our team takes it off the site.

### Someone told you about a business. How does it get listed?
If it isn't yours, use **Not your business? Tell us about it instead** on the same page. Our team checks it, adds it (a website isn't needed) and emails you when it's on the site. If you said it's yours, that email has a **Claim it** link.

### My business is listed, but I never added it. How did it get here?
Most listings come from public records and our crawler. Our team also adds businesses they come across: from a business card someone hands them, or from a receipt, a menu or a sign where they've been a customer. Those start unclaimed, with what was on the card or receipt, and our crawler fills in the rest. Claim it to manage it yourself, or tap **Suggest an edit** on it if something's wrong.

### How do I claim my business?
Open your listing and tap **Claim**. You'll need a Traversence account (18 or older) with your email confirmed. Then:
1. **Confirm by email.** We send a code to your account email. Enter it and your listing shows **Managed by owner**: you can edit its description, hours, services and photos right away.
2. **Get verified.** Tap **Send verification request**. Our team gets your listing and how to reach you, checks it (usually the same day) and confirms it, and your listing shows **✓ Verified**. If they need something first, such as a call or a photo of the storefront, they'll email you, and you can send a new request when it's ready. You can also text your claim's code (it looks like TV-1234) to our Verify number instead.
3. **Choose a plan.** Free, or a paid plan (see below).

Your business dashboard (**Manage** on your listing) shows where your claim stands and what's left.

### What does "Managed by owner" mean?
Someone has added or claimed the listing and confirmed it by email, and it's waiting to be verified. Until it's verified it isn't shown to search engines. They can edit the description, hours, services and photos. Changes to the name, phone, address and website wait for our team until the claim is confirmed, so customers are never sent to the wrong place.

### I texted from a different number. What happens?
That's fine: in a lot of small businesses the owner's own cell is the business phone. Someone from our team will contact you at that number within 48 hours to confirm who you are and your role with the business. If you can't text, you can instead use an email at your business's own website domain (when your listing has a website), send a document such as a business license or utility bill (only our team sees it, and it's deleted as soon as your claim is decided), or ask for a call or a visit at a time that suits you.

### Why did Traversence contact my business?
Your business is listed on Traversence from public information, and claiming it is free. Someone from Traversence may
call, stop by, or email the address your business publishes, to offer you the listing: once it's yours you can
correct the details, add your hours and photos, and answer people who message you. We use only your business's
public phone, website and email, and never sell them. If you'd rather not hear from us, say so (or reply "no thanks"
to the email) and we won't contact you about it again.

### Someone else already claimed my business. What can I do?
Ask to claim it anyway. Only one claim goes ahead at a time, so yours is saved as **Claim Request On Hold**, not turned down, and our team is told straight away. Leave a way to reach you and anything that shows the business is yours. If the listing has a confirmed owner and you believe that's wrong, you can question it from the claim page: the owner is told and can answer, and our team decides. Nothing changes on the listing while that happens.

### I have more than one location. Do I claim each one?
When you claim one, we look for your other locations (the same name, phone or website) and offer to claim them together. Each location stays its own listing, with its own page. One confirmation can cover them all when it shows every location: your website lists them, or you send photos or a brochure that does. Otherwise each location is confirmed on its own.

### What do the plans cost?
For a business: **Free** costs nothing; **Basic Partner** is $29.95 a month, **Core Partner** $79.95, **Strategic Partner** $229.95 and **Cornerstone** $399.95. For yourself: **Personal** is free, **Personal Plus** $4.95 a month and **Personal Pro** $9.95. Paying by the year costs 10 months' price for 12 (two months free). Each plan includes storage and AI Assist credits, and each business plan adds tools to the one below it (Basic Partner adds customers, quotes and invoices, order emails and discount codes; Core Partner card checkout, a storefront and dynamic QR codes; Strategic Partner campaigns, wholesale price lists, your own workflows, the API and White Glove; Cornerstone several locations and the Co-Op hub). The **Plans** page lists everything under each plan, and **Settings & team** in your business shows what yours opens. No plan ranks you higher in search: plans pay for tools, storage and support.

### How do I choose or change my plan?
Open **Plans**: **Manage plan** in your business dashboard, or **Plans** in your Dashboard's menu, under Settings (also in the site menu, ☰). Pick a plan, monthly or yearly, and add your card. The card goes straight to QuickBooks Payments (Intuit); we never see or keep the number. A bigger plan starts right away and you pay the difference for the rest of the period; a smaller one starts at your next renewal, and you keep what you paid for until then.

### How does a free trial work?
When you claim your business and choose a paid plan, you first see a review: the plan, its price after the trial, the day the trial starts and ends, and what happens then. Tick that you agree to the Terms and choose **Start my free trial**. It lasts 30 days (our team sometimes offers 60 or 90), needs no card, and nothing is charged during it. We email you 5 days and 1 day before it ends, and on the day. To keep the plan, set up billing on the **Plans** page (add a card and choose **Keep my plan**): the price is charged from the day the trial ends, and you can cancel any time. If you don't, your business goes back to the Free plan on its own: nothing is charged, your listing and content stay, and the paid tools pause until you choose a plan again.

### Does my plan renew on its own?
Yes, on the same date each month or year, charged to the card on file, with a receipt by email each time. A yearly plan gets a reminder 7 days before it renews. Choose **Stop at the end of this period** on the Plans page any time: you keep everything until then and aren't charged again. Periods already started aren't refunded.

### What happens if my card is declined?
We email you and try again 3 days later, and once more after 7 days. Update the card on the Plans page and we charge it right away. If it's still declined after that, the plan goes back to Free; your listing stays up, and you can choose a plan again any time.

### What are storage and AI packs?
Extra storage (+25 GB, +50 GB, +100 GB, +250 GB, +1 TB or +5 TB) and +50 AI Assist credits a month, the same for every plan and for personal accounts. Add one on the Plans page once your plan is paid: you pay for the rest of the current period now, then it renews with your plan on the same date. Packs are always full price, also on a yearly plan. **Remove at renewal** takes one off at the next renewal.


### How do I use a promo code?
Type it where it says **Promo code**: on the **Plans** page, in your **GO Codes cart**, or on an order we've prepared for you, before you approve it. A trial code starts the free trial right away, with no card. A code for a percentage off shows what it takes off before you pay. If a code came with a QR code (a GO Code), scan it: its page shows the offer and takes you to where it works, with the code ready. Each code works once per account, between its dates, and some are only for one business.

### Why didn't my code take anything off?
A code works on certain things: plans, GO Codes, or kinds of work such as creative or printing. It never takes anything off storage or AI Assist packs. Some prices are already as low as they go, so a code can't take them lower. If you think it should apply, write to support@traversence.com with the code.
## Journeys and contributors

### What is a journey?
A story about a place you've been, in your words, with your photos. You can add a video link, tag the place and link the businesses you visited. Journeys appear on the place pages, so other people find them while exploring.

### How do I start writing journeys?
Become a contributor: go to your **Dashboard**, choose **Your journeys**, and click **Become a contributor**. Writing, editing and managing your journeys all happen in your Dashboard.
- You'll read the contributor guidelines and accept them.
- You'll need to be 18 or older.
- Your profile can't be private, because journeys show your name.

### How does my journey get onto the front page?
Publish it. Drafts are seen only by you and our team. A journey needs three things to show:
- **Published.** Open it from **Your journeys**, click **Edit**, then **Publish**.
- **A story of a few sentences** (at least 40 characters).
- **A place**, under **About a place**. Without one, it shows only on the North America page. With one, it also shows on that town, area or region.

Once published, it appears in the **Journeys & guides** feed right away, newest first.

### Where do my published journeys show?
- On **Let's Explore**, in the **Journeys & guides** feed for the place you chose, and the places above it, up to North America.
- On your **public profile**, under **Journeys**.
- On the **listing page** of every business you linked in your journey, under "Journeys that mention…".

A journey you post as a business also shows on that business's listing page.

### How does a photo end up in the big picture at the top of a page?
The picture at the top is chosen from published journeys at that place. Photos need to be at least 900 pixels wide, and the uploads we store are 2000, so yours qualify. The ones people like and comment on most get shown first.

### How do I get into Top Contributors?
Publish journeys as a contributor and keep your profile public. The list favors recent journeys people engage with, and accounts that have been around a while.

### My journey said "Saved as a draft: an automatic check found…". What now?
An automatic check spotted something it holds back: unsafe or spammy wording, or a pile of links. The message says what it found. Reword that part and publish again.

### The place I wrote about isn't in the place list. What do I pick?
The place list has regions, areas, towns and local names. For a lake, a park or a trailhead, pick the nearest town or the area. Mention the place itself in your title and story.

### What's the difference between "Traversence", "Contributor" and "Business"?
Every journey and guide is labelled:
- **Traversence:** written by our editorial team.
- **Contributor:** written by a member, with their name on it.
- **Business:** posted by a local business's team, shown under the business's name and linked to its listing.
- **Partnership:** the writer was paid, or given something free, for it.

### Can my business post journeys?
Yes. If you're on a listing's team as its Owner, Manager or General member, the journey editor has a **Post as** choice: yourself, or the business. A business journey shows the business's name and links to its listing. You still need to be a contributor yourself.

### Do I have to mark a partnership?
Yes. If you were paid, or given something free, for a journey, mark it **Partnership**. U.S. law requires the disclosure.

### Can I say exactly where and when it happened?
Yes, if you want to. **Where it happened** is an optional pin you set on a map, and you can add a time next to the "Was here" date. Each photo can also have its own pin and the date it was taken.

### My photo knows where and when it was taken. Does Traversence use that?
Only if you say so. When you add photos, your browser reads the photo's own date and location and shows them to you: "This photo says it was taken Aug 12 near …. Use it?" Tick what you want to keep. The photo we store has all of that removed either way.

### Where are my photos and files kept?
In secure file storage (Amazon S3, moving to Cloudflare R2), not on the web server: photos of places, businesses, journeys and profiles, a business's proofs and files, and order artwork. Photos you've made public load from there; private files (proofs, documents, order files, anything shared only with a customer) open through links that work for a few minutes and only for people allowed to see them. Everything you add is kept together in your own folder (a business's in its own), under a random name rather than your account number, so your photos' addresses don't say who you are. Removing a photo or file deletes it from storage, and deleting your account deletes your folder; files that belong to an order stay with the order, as its record. Documents sent to prove a claim are deleted as soon as the claim is decided. Downloading all your files in one go is coming.

### How big can a file be, and what happens when I upload one?
Every upload on Traversence works the same way, wherever you add it: the gallery, a business's proofs and files, an order's proofs, artwork and shipping labels, journey and profile photos, the photos at the top of a listing, a guest adding to an album, a claim document, a GO Code's logo. Before anything is sent we check the size: a file that's too big for where it's going is refused straight away with the limit, and anything over 10 MB asks you first, since it takes a while. Files go straight to secure storage in parts, with a bar showing how far along it is; if your connection drops, each part is tried again before it gives up. When it's done, the result shows right beside what you were working on (no jumping to the top of the page). Each file is checked to be what its name says (a PDF really a PDF) before it's kept. The most one file can be is **1 GB** (gallery videos and files, a business's proofs and files, order files). Some places take less, because they need less: a gallery photo up to 100 MB, photos for a listing, a profile or a journey up to 15 MB (we resize them anyway), a guest's photo 25 MB, a claim document 25 MB, a GO Code logo 2 MB. Photos are made a sensible size on your phone before they're sent, unless the album keeps originals (portfolio and brand albums).

### Can I leave the page while a big file uploads?
Yes. Once you start an upload, your browser keeps a copy of the file and carries on sending it while you move around the site: open another order, go to your dashboard, use other apps. A box in the bottom corner of every page shows each file with its size, how much has gone, one progress bar, and what you need to do before you go. On a computer, keep one Traversence page open (in any tab) until it reaches 100%. On a phone, keep the browser open and in front: phones pause uploads when you switch apps or lock the screen, and they carry on when you come back. If you close every Traversence page, the upload pauses and picks up where it stopped the next time you open the site in that browser (within a day). If the connection drops, it tries again every minute. When it's done, you get a notice with a link back to where you started it, and with **Tell me when it's done** your browser's own notification tells you even when you're in another app or tab. Closing the last Traversence page while an upload is still going asks you first. In a private window, or a browser that can't keep a copy, the page sends the file itself and asks before you leave it.

### Can I share an album with just a few people?
Yes. Open the album and choose **People**, then invite each person by email as **View only** or **Can contribute**. They get an email with a link; once they sign in (or make a free account) the album is in their gallery under **Shared with you**, whatever the album's setting. People who can contribute add their own photos (they stay theirs) and can take out only the ones they added; they can't remove anyone else's photos or change the album. You can change someone's role, take back an invitation, or **Remove** them: their photos come out of the album, and their likes and comments there are deleted. Anyone can also **Leave album**.

### Can my business have a gallery?
Yes. In your business's tools choose **Gallery** (or **Manage the gallery** on your listing page): everyone on your team with **Catalog & content** can upload photos and videos and make albums. The photos at the top of your listing are in it already. Public albums show on your listing page under **Albums**. A business's gallery counts toward its plan's storage.

### How do Portfolio albums work for my clients?
Make an album and, under **What it's for**, choose **Portfolio**. You set the rules: whether clients pick their favourites (and how many), downloads (none, picked photos only, or all, and how many each), and a watermark with your own text. Share it with its link or invite clients in **People**. Clients sign in, tap **Choose my picks**, then **Send my picks** with a note; you get an email, and **Client picks** shows each client's choices and lets you highlight them on the album. Clients see the watermark; you never do. Photos you upload to a Portfolio keep their full-size original, which is what a download gives (no watermark). Videos aren't watermarked.

### What is a Brand & documents album?
A place for a business's (or anyone's) logos, brand guides, PDFs, design files (Illustrator, Photoshop, InDesign, EPS, SVG), fonts, Office files, ZIPs, audio and video: any of them up to 1 GB. Choose **Brand & documents** under **What it's for**, then **Upload files**. Each file shows its type, size and version; **New version** uploads a replacement and keeps every older one, and the history icon lists them, each downloadable. If the album is shared, people who can see it can download its files. Searching and tagging files across albums is coming.

### Can Traversence staff see my private photos?
No. Our team's gallery tools list only what's already shared (public and unlisted albums, and what's in them); private albums and photos are only counted. If something shared breaks the rules, the team can make that album private or take a photo out of shared albums. It stays yours, in your gallery, nothing is deleted, and you get an email saying why.

### Can guests add photos to my album without an account?
Yes, for an event. In the album choose **People**, then **Let guests add photos**: you get a guest link and a QR code to print or show. Anyone who opens it can add photos (up to 60 a day each), with their name if they want; no account or app needed, and where the photos were taken is never sent. The photos are yours to keep or delete, and they show "Added by" the name they gave. **New guest link** or **Turn off** stops the old link and QR code at once.

### Can people like and comment on my photos?
Yes, anyone who can see a photo and is signed in. Open it full screen: the heart likes it (on a phone, double-tap the photo), and comments sit with that photo, not the whole album. You can remove any comment on your own photos, people can remove their own, and anyone can report one. Commenting needs an account that's 18 or older.

### Can I post a photo someone else took?
Yes, with their permission. Under the photo, choose **Used with permission** and say who took it. It shows as "Photo: their name".

### Can other people reuse my journey?
You choose, under **Rights and reuse**:
- **Shown on Traversence only** (the default);
- **Others may share it, with credit**;
- **Free to use, no credit needed**.

You keep ownership either way.

### Can I write a journey with someone else?
Yes. Under **Co-authors**, search for up to five members by name. They're invited when you save. Their name shows on the journey, and it shows on their profile, once they accept. Invitations wait on their **Your journeys** page.

### What does "Mature themes" do?
It puts a notice in front of your journey: readers choose to open it. Its card shows a notice instead of a photo, and it isn't used for the big picture at the top of pages. All Traversence accounts are for adults, but this lets readers decide.

### What's the "Caution" note for?
Anything readers should know first, such as rough roads, weather, closures or gate times. It shows as a banner at the top of your journey.

### Can I add a video?
Yes, as a YouTube or Vimeo link. We don't host video uploads.

### Who can see my comments?
Comments on journeys are public. You can remove your own comments any time.

### Can I edit or delete a journey?
Yes, from **Your journeys**. Deleting removes it and its photos.

### Who owns my journeys?
You do. Traversence shows them on the site with your name, and you can remove them any time.

## Photos and your location

### Does Traversence share where I am?
No. We never expose anyone's location. You may share your own, by tagging a place or a photo yourself.

### What happens to the hidden data in my photos?
When you upload a photo, we remove everything hidden in the file, including GPS coordinates, your device and the time it was taken. If you want to show where a photo was taken, tag it yourself with a place or a map pin.

### What's "Was here", and will there be "Am here"?
**Was here** marks a journey as a place you visited, with the month. **Am here**, live check-ins, is coming as a separate feature. You'll switch it on yourself after reading its rules and risks. Each time you check in, you'll choose to post now or later.

### Why do some photos say Stock photo?
Until a place, a business or a section has a photo of its own, we show a **stock photo** instead: a photo nobody on Traversence took, from Wikimedia Commons, the Library of Congress or Pixabay, chosen by our team one at a time. Each one is labelled **Stock photo** on the photo; hover over the label, or tap it, to see who took it, its licence and where it's from. We only use photos whose licences allow it, and never photos of sacred, burial or protected places. As soon as a real photo is added, it shows instead, by itself.

### What does "Representative photo" mean?
The stock photo shows the kind of place or thing, not this one itself: a desert road for a desert town, a shopfront for a shop. A business's stock photo is always marked Representative, because it never shows that business. When the photo really is of that place, the label says **Stock photo** alone.

### Where can stock photos be used?
Only where a photo illustrates: the photo at the top of a place's guide or of a listing with no photos yet, a card with no photo, a storefront's banner, the home page's sections and an event's backdrop. Never where a photo says "this is the real thing": a product or an item for sale, a journey, a story or a review, a gallery album, an event's own photos, a business's own photos (its premises, its people, its work, its logo), a profile picture, or a proof or an order. Those places don't offer stock photos at all, because authenticity matters.

### How do I add a photo or a file?
Wherever you add one (a journey, your profile, a Marketplace post, a catalog item, a listing's photos, a storefront), tap the button and your **Gallery** opens on the page, not your computer's file window:
- **Your gallery:** choose one of your photos (or several), sorted into catalogs. For the Marketplace, a catalog item or a storefront, the photo is used right where it is in your Gallery. A journey, your profile and a listing's photos keep a copy of their own, which then shows in that catalog too.
- **Stock:** only where a photo illustrates, like a storefront's cover (see below).
- **Upload new:** drag files in, paste a screenshot (Ctrl+V or ⌘V), or tap **Browse your device**, which opens your computer's or phone's own file window. What you upload is kept in your Gallery too, ready to use again.

It's the same for documents and order files (proofs, artwork, print-ready files, shipping labels, a quote's files): **Your gallery** shows the documents you've kept that fit, and a new file you upload is kept in your Gallery's **Documents** too, then added where you were. The order or quote keeps its own copy as part of its record.

### Does the Gallery know where my photos and files are used?
Yes. Each time you use a photo or a file from your Gallery (an order's proof, a catalog item, your storefront's cover, a journey…), the Gallery remembers. Open the photo to see **Used in …**, or look beside each file on the **Documents** tab. Only you (or your business's team) see this.

### Where are my documents?
In your **Gallery**, on the **Documents** tab: every file you've added anywhere on Traversence (proofs, artwork, quotes, brand files), newest first, with its size, its version and where it's been used. Search them, download one, or **Add documents**. To use one somewhere, tap that page's file button: it's under **Your gallery**.

### What are the Gallery's catalogs?
Your Gallery sorts every photo by where it belongs, so it's easy to find: **Uploaded here**, **Journeys**, **Profile** (or **Listing photos** for a business), **Marketplace** and **Storefront**. Documents have their own catalog and tab. **Orders** holds artwork from your orders with us that's been released to you; its photos go anywhere a photo does, your profile picture included, where you frame it like any other. Choose one from the **Catalog** button on **Photos & videos**, or from the list at the top of **Your gallery** when you're choosing a photo. Nothing needs filing by hand: a photo moves to its catalog as you use it. **Albums** are still yours to make, and **Stock photos** has a tab of its own, because they aren't yours.

### Where do I find stock photos?
In your **Gallery**, on its own tab, **Stock photos**, next to **Photos & videos** and **Albums**. Type what the photo should show and **Search**: you'll see what's already in the stock library, then free photos found at Wikimedia Commons, the Library of Congress and Pixabay, each with its credit and licence. Choosing one of those adds it to the library, labelled as a stock photo wherever it shows. One place for all your art, kept apart: your photos and albums are yours; stock photos aren't, so they never go in your photos or albums. Search them, see each one's credit, and, for a business, use one as its storefront's cover. When you pick a photo anywhere it's allowed, the picker has the same two tabs: **Your gallery** and **Stock**.

### How do I replace a stock photo with my own?
Add your own photo where it shows: on your listing, tap **Add your own photo** (or **Photos & video** at the top); on your storefront, upload a **Cover** in **Storefront & pages**. Yours shows straight away and the stock photo goes. For a place, share a journey with photos of it: journeys' photos show at the top of its guide.

### Can I choose a stock photo for my storefront?
Yes. In **Storefront & pages**, under **Logo and cover**, tap **Choose a photo** under the cover: your own photos are on the **Your gallery** tab, stock photos on the **Stock** tab. Or open your business's **Gallery** → **Stock photos** and tap **Use as storefront cover**. Visitors see it labelled as a stock photo until you upload your own cover, which takes over by itself. Your logo is always your own: stock photos can't be a logo.

## Posting guidelines and safety

### Can I post photos of other people?
Ask before you show people, and take extra care with children. You can mark a journey as showing people with their permission.

### What about private property and tribal lands?
- **Private property:** homes and private land need the owner's permission.
- **Tribal lands:** many nations restrict photography and filming. Some villages don't allow it at all, and commercial filming needs permits. Follow each nation's rules for visitors, and don't point others to sacred or restricted places.

Our guidelines are guidance, not legal advice. You're responsible for what you post.

### What can be reported?
- spam or scams;
- harassment or hate;
- sacred or restricted sites;
- someone's private information;
- people shown without consent;
- private property without permission;
- unsafe or illegal content.

### How do I report something?
Use **Report** on the journey, comment or post, choose a reason, and add a note if it helps. Our team reviews every report.

### What happens after a report?
Journeys publish as soon as they're posted, and our team responds to reports. If something breaks the rules, we hide it. A hidden journey stays visible to its writer.

## Suggestions and corrections

### Something's missing or wrong. How do I tell you?
Use **Make a suggestion** in the menu, or **Tell us** on a listing or place page. It works for anything: a business, a lake, a trail, a landmark, a story idea, or a correction to a listing. You can drop a pin on the map to show where it is.

### What happens to my suggestion?
Our team reviews it and checks it against public sources. Then:
- **A correction** (a phone, website, address, hours or name) is made on the listing.
- **Closed** keeps the listing on the site, marked **Closed** on its page and in search, so anyone looking for it knows before they go. Closed places come last in results and never show as open. If it reopens, tap **Tell us** on its page.
- **Listed twice** becomes one listing, and the other one's link takes you to it.
- **A missing business** becomes a new listing; **a missing lake, trail, park, campground or landmark** becomes a new place. Places whose names may mark a sacred, burial or protected site are held, not shown.
- **A missing event**: events are coming.

If you were signed in when you sent it, we email you when it's done. A business run by its owner is changed by its owner, so we check with them first.

## GO Codes and short links

### What are GO Codes?
GO Codes are Traversence's QR codes: for a link, a phone call, an email, Wi-Fi, a contact card, an event (it offers "Add to calendar"), text or a text message, in your colors and with your logo. Make one at [GO Codes](/qr/) (or just trvgo.us): choose what it does, type what it says, pick how it looks, and it's drawn as you type so you can scan it to check.

### What do GO Codes cost?
Each GO Code is **$4.95, once, plus sales tax**, and keeps working, unless its payment is refunded or charged back (then it stops working; see [What if something's wrong with my order?](#what-if-something-s-wrong-with-my-order)). With a free account you also get **5 free GO Codes** (link, phone, email or Wi-Fi in black and white), once your email is confirmed. Add codes to your **Cart**, then check out: the tax is worked out from your billing address, and you pay by card right there. Your card goes straight to QuickBooks Payments (Intuit); we never see your card number.

### What if something's wrong with my order?
All sales are final, but when something goes wrong that we didn't expect, in production or with files you approved, we make it right. Tell us at **support@traversence.com** within 14 days of receiving it, with your order number (and photos for printed items); if the carrier delays a package, the 14 days start when tracking shows it delivered. We **fix it first**: redo, reprint or replace what we got wrong. If it can't be fixed, you get a **full or partial credit** on your account, good for 90 days toward anything we sell. A **refund** is the last resort, when neither works.

What counts as a fix: for **digital work** (designs, video, GO Codes, plans), a code that won't scan or goes to the wrong place through our error, a file that won't open or comes in the wrong format, or something missing that was on the proof you approved. A change of mind after approval, a typo that was on the proof you initialled, or a new format or size isn't a fix; we're glad to quote it as new work. For **printed and made-to-order products**, damage in shipping, a printing or manufacturing defect (a severe color shift, bleeding text, cuts out of line with the proof), or the wrong size, material or quantity. Slight color differences between a screen and ink, and damage after delivery, aren't. **Custom and made-to-order products** are final once you approve the proof, so check names, numbers and spelling carefully. If a GO Code's payment is refunded, the code leaves your account and stops working; while a card dispute is open, it's paused. A refund goes back to the card or account you paid with, through QuickBooks, and we email you when it's made; your bank may take a few days to show it. The details are in our [Terms](/terms.php#fix-credit-refund).

### Do I need an account for GO Codes?
No. You can make GO Codes, check out as a guest, and download them. We keep them with your browser and email you a private link that opens them on any device. An account is recommended: your codes stay in one place, you get 5 free ones, and you can make Dynamic GO Codes. After a guest checkout we offer to open your account with the name and email you gave; your codes move into it, and so do earlier guest orders paid with that email once it's confirmed.

### Where are my GO Codes after I pay?
On **Manage GO Codes**. As soon as your card goes through, you land there with your codes ready, and your receipt email links back to them. (Paid on QuickBooks' own invoice page instead? Your codes appear there by themselves once the payment registers.) Each code says what it does in plain words ("Calls 505-555-1234", "Opens yoursite.com"), its trvgo.us address and how often it's been scanned. Tap its name for the details: a larger picture, everything it holds, **Try it** (trying it yourself isn't counted as a scan), and the order it came from. Download each one as **SVG** for printing (sharp at any size) or **PNG** for screens. The SVG is a true vector with no background: the code is one shape, so in a design program (Illustrator, Inkscape, Affinity) you can recolor it in one click and place it on anything. When you download it you pick how big it will be printed (from 0.8 in for something read up close, through 1 in for a business card, to 12 in for a banner, or your own size), and it opens at that size, with a clear margin around it. Keep the code darker than whatever it's printed on, with a clear margin around it, or phones may not read it. **My orders**, below your codes, lists each order with what it bought, refunded items included. Spotted a typo after it's issued? Write to **support@traversence.com** with the order number: we correct it, and the code you printed stays the same.

### What's a Dynamic GO Code?
A short trvgo.us address (like trvgo.us/k7qm2x) in a code: after you've printed it you can still change where it goes, switch it off, and see how often it's scanned. Dynamic GO Codes need an account and the QR plan ($14.95 a month or $119.40 a year; free while billing isn't switched on yet), or a business's Core plan and up. Find them under **Manage GO Codes**.

### What happens to my printed codes if my plan ends?
Nothing you've printed stops working. A business's Dynamic GO Codes go to its listing on Traversence; a person's keep going wherever they pointed last. You just can't change where they go until the plan is back on. GO Codes you bought keep doing what you made them do. Only a code switched off by its owner, or by our team because it's misused, stops working; scanning it then says it isn't active.

### Why does my GO Code go through trvgo.us?
So you can see how often it's scanned, and so a mistake can be put right after you've printed it. Every GO Code except Wi-Fi holds a short trvgo.us address: a link code goes straight to your link, a contact card or event downloads to the phone, and a phone number, text message or email starts the call, text or email straight away (if a phone's browser wants a tap first, it shows one button that does it). A Wi-Fi code holds the network itself, so phones join without going online first. Scans are counted the same privacy-first way as other trvgo.us links (the day and kind of phone, nothing else). If Traversence ever closes, you'll be able to download your GO Codes re-made to hold what they do directly, so they keep working without us ([Terms](/terms.php#go-codes)).

### Why do shared links start with trvgo.us?
When you tap **Share** or **Copy link** on a listing, a place, a journey or a photo, you get a short trvgo.us address that opens the same page. It's easier to text or print, and it's the same short link for everyone sharing that page. The **QR** button beside Share shows the page's code, to scan or print.

### How do I save a business to my phone's contacts?
On its listing, tap **Save contact** (the person with a +, in the row of round buttons). Your phone offers to add it with its name, phone, address and website as they are now. A shelter whose location is kept private has no address on its card. Each business sees how many times its card was saved, never by whom.

### What's counted when someone scans my code?
The day, and the kind of phone (iPhone, Android or computer). Nothing else: no name, account, IP address, location or cookie. Link previews (when a link is pasted into a chat) and bots aren't counted. There are no ad trackers on trvgo.us.

### Can I use my GO Codes for my business?
Yes. Once a GO Code is yours (free or paid), print it and use it on anything you make, for personal or business use, with no fee each time. What it holds and where it points is up to you, but codes and trvgo.us links that lead to scams, malware or anything unlawful are switched off. Test-scan a code at the size you'll print it before printing a lot. The full rules are in our [Terms of Use](/terms.php#go-codes).

## Orders we prepare for you

### How do I review and approve an order Traversence prepared for me?
Open the link in our email (no account needed). It shows everything in the order with its price, and a proof for anything we'll print or make, and for each GO Code. Tap **Review the proof**: it opens large and sharp on its own (a long proof scrolls; × closes it), with **Approve** and **Make changes** in the bar across the top. **Width**, **Page** (each page whole, top to bottom of your screen) and **2**, **3**, **4** (pages side by side) set how it's shown; your choice is remembered on that device. **Approve** opens the final-approval terms: you take full responsibility for checking the proof (layout, design, text, spelling, grammar, colors, dimensions and resolution); once approved it goes to production and can't be changed or cancelled; and errors found afterwards are reprinted at your expense. Tick the two boxes, type your initials and tap **Submit Final Approval**, or **Cancel & Request Changes** to go back and tell us what to change. The proof you're approving can be downloaded from there too, to check it at full size or print it. A GO Code's proof shows the code and everything it holds (a contact card as the card people will save). Tap **Make changes** and tell us what to change: we send you a new proof on the same link. A proof can have several files (front and back, or each size): they're shown together, and **Approve** approves them all. If we send a new version, it replaces the one before, and if we change a file in a proof (even one you'd approved), it comes back to you to approve again: an approval only ever covers the files you saw. Proofs are shown square, to their edges, with a **red dashed line** where the piece is cut. When every proof is approved, add your billing address and your name and tap **Approve the order**. What you approve is made as shown, so check names, numbers and spelling first. A GO Code in your order can be tested before you pay: scan it from the proof and it opens a page marked **Proof** with a button that does what the code does (opens the link, saves the contact, and so on). Those test scans aren't counted. Once the order is paid, the code goes live: scans open it directly and are counted. The link works until the date shown on it; reply to our email and we'll send it again. Your order reads like an invoice: each item shows where it ships (each can go to a different address, or be picked up) and its own shipping, added up in a Shipping line. If something ships to you, you give the address when you approve (or tick that it goes to your billing address). Once it's approved, each item shows where it stands (in production, shipped, delivered…), with tracking when there is any. Tick **Email me as my order moves along** (when you approve, or later on the same page) and we email you at each step; untick it and we don't. Receipts always come. If we've agreed you'll pay us directly (cash, check, Zelle), there's no card form: we confirm each payment by email and it shows on the same link. When you open your order's page, we note the time and whether it's on a phone or a computer, so our team knows you've seen it; nothing else about you is kept.

### Why is my order grouped into projects, and when can I download my files?
A bigger order is grouped into projects (say, a manual in English and the same manual in German). Each project lists its items with their prices and a subtotal. Each item has its own proof: rounds of concepts for design work, and the print-ready file for anything we print. You always see the current proof; once you approve one, earlier rounds aren't shown any more. Approving is what releases your files for use, once the order is paid in full: the approved print-ready file of anything we print, ready to download from your order page. Design artwork that's going to print stays there to look at, and the print file is the one you download. When an order is design only, with no printing, its print-ready file is released to you the same way.

### Do I have to pay for the whole order up front?
The order says how: in full when you approve, a deposit when you approve and the rest before delivery, or an invoice you pay later. Sales tax is added when you approve, from your billing address. You pay by card on the same page (your card goes straight to QuickBooks Payments; we never see the number), or on QuickBooks' own page by card or bank transfer. If something in the order is a GO Code, it's ready to download from the page as soon as the order is paid.

### Can I pay by wire transfer or check?
Yes: under **Pay** on your order's page, choose **Wire transfer** (for orders of $2,500 or more) or **Check** instead of Card (it's your choice, at checkout). When you choose, we ask for the wire's confirmation code from your bank (or the check number) in case you've already sent it; leave it blank if you haven't. For your safety our wire details are never emailed: tap **Email me a code**, enter the 6-digit code we send to the order's email, and they show on the page for 10 minutes (they can't be copied or printed, and each viewing is recorded). Before sending a wire, call us at (602) 708-3795 to confirm the details: we never send or change our bank details by email, so if anyone does, it isn't us. Our check details show there and come by email. Put the order number in the reference. Once you've sent it, come back to the same link (the email has it) and enter the wire's confirmation code from your bank, or the check number. Your order waits on a payment hold until the money reaches us: then we email you a receipt and it goes to production. If we haven't heard that it's sent, we email you a reminder 2 hours after you choose, again at 9 am the next business day, and at 4 pm that day with the other ways you can pay.

### Where do I see all my orders?
Once you've done your part (paid, or told us your wire or check is sent), your order's page says **Thank you** and shows what's next. From there, **Create your free account** with the email the order came to (or sign in), and **Your orders** in your account lists every order we've prepared for you, with its proofs, payment, where it stands and your files. Orders sent to your email join your account once you've confirmed that email. If your order is for a business, **Put [your business] on Traversence** adds it in the same step, filled in from your order: one account for you, with your business on it.

### How do I know my order is finished?
When everything on your order has shipped or is ready for pickup, we email you (if you get progress emails) with each item's tracking, and your order page asks **Do you have it?** Tap **Yes, I have it** once it's in your hands: that completes the order. You can add a few stars and a word or two about how it went, and say whether we may quote you. If something isn't right (missing, damaged, not what you expected), tap **Something isn't right?** instead and tell us: that opens a support ticket, we email you its number, and we'll be in touch to put it right. The order stays open until we do. If you haven't told us three days after it went out, we send one reminder. Once it's complete we email you a thank-you with a link to reorder.

### Can I reorder something you made for me?
Yes. On a completed order's page (the link in our thank-you email), **Reorder** lists what was in it: tick what you need again and how many. Or, once we've released a piece to you, it's under **Your artwork** on your **Your orders** page (sign in with the email your orders went to): look it over, download the files that are yours, and tap **Ask to reorder** with the quantity and anything we should know. Tick **I want changes** if the art changes. We send you the reorder to approve like any order. With the same art there's no new proof round: next to the proof you'll see **Confirm reuse**, and you sign off with your initials as you did the first time. Reorders are priced at today's rates.

### Where is my printed order?
On your order's page: **Where it is** shows whether it's in production, sent to print, shipped (with its tracking number) or ready for pickup. If you ticked **Email me as my order moves along**, we also email you at each step.

### What does Traversence keep about me when I buy something?
Your customer record, made from your own orders and plans: your name, email, phone and company as you gave them, what you've bought and when, and the total. Our team can add a note (say, that you asked us to call in spring) or a tag (like Wholesale) to help look after you. It's private to our team, never shown on the site and never sold. Your orders are kept for our accounts even if you close your account.

### Will my business get a list of its own customers?
Yes, on Basic Partner and up: open your business portal (**Your business** → **Open the portal**, or traversence.com/business/) and choose **Customers**. Add the people you work with, keep notes, tag them (Retail, Wholesale, or your own tags) and see groups like new, returning and VIP. Your orders and messages join them there as checkout and the inbox open. It's private to your business: no other business, and no one outside your team, can see it.

### How do I add my products and services?
In your business portal, open **Catalog** and tap **Add a product**: its name, the kind (an item, a service, a class or event) and its price. Then open it to add a description, more prices (a different price for 12, for example), options that change the price ("Size: Small, Large +1.00") and your own cost and supplier, which only your team sees. Hide anything you've stopped selling; it stays in your catalog. Every plan includes the catalog.

Coming with the Marketplace: each plan shows a number of active items at once (Free 10, Basic 25, Core 100, Strategic 250, Enterprise / Cornerstone 1,000 per listing). Hidden, sold and expired items don't count. At your plan's number, adding or showing another item is greyed out with the plan that raises it; nothing already showing is taken down.

### Can I sell things on Traversence?
Yes: anyone with an account who is 18 or older can post on the **Marketplace** (see Buying and selling below). A post shows the town or area you pick, never your address. No payment ever passes through Traversence: people pay each other directly. Offers and the dual confirmation (the seller taps Sold, the buyer taps Got it) are live too. Businesses' items are there too, and from Core Partner up a business can take card payments through its own Stripe or Square account, with no cut to us.

### What is the business portal?
Your business's own tools, for you and your team. When you act as your listing, its **Overview** is your one landing page: the listing at a glance (its status, how complete your profile is, your numbers, Reply to messages and Edit listing); **What's on your mind?** to post as the business, with its posts under it; its **Pulse**, everything coming in to the business (messages, guest questions and more), each opening right there with ▾; **Messages & offers** (send an offer or news to subscribers, ask people to link again, your conversations and guest questions); what visitors did from your listing in the last 30 days (visits, calls, directions, website visits); then every tool, with Edit listing, Gallery and Team & roles. Its menu has everything in one place: Overview, its Pulse and messages, the listing and Edit listing, then **Market 360°**, one button for everything about selling (its pages are in the **Market 360°** menu at the top of each: **Get selling** first, then six modules: **Business Identification** (Trust score, Legal identity), **Money & Processing** (E-commerce setup, Sales tax, Store policies), **Products & Inventory** (Catalog, Marketplace, Bundles), **E-commerce** (Orders, Customers, Quotes & invoices, Shipping & pickup, Discount codes, Reports), **Storefront** (Storefront & pages) and **Marketing** (Linked people, Marketing); pages still coming show greyed, saying what they'll do), then its other tools, then Team & roles and Plan & settings. **Get selling** walks you through setting up to sell in seven parts that tick themselves as you finish them: business profile, store, catalog and inventory, getting paid, shipping and tax, verification and payouts (done in Stripe's or Square's own setup; it ticks once Stripe or Square says payments and payouts are on, and lists what they still need), then test and launch. Open it by choosing the business under **Your listings** in your account menu, or at traversence.com/business/. Each person sees what their role allows (Owner, Manager, Accountant, Sales, Support, Creator, Developer or Viewer, who can look but not change anything), and each tool is opened by your plan: one your plan doesn't include shows greyed with the plan it comes with. Customers, Catalog, Marketplace, E-commerce setup, Store policies, Storefront & pages, Trust score, Linked people, Quotes & invoices, Orders, Discount codes, Sales tax, Shipping & pickup and Plan & settings (with your team) are open now; the inbox, legal identity, bundles, marketing (QR codes, short links, campaigns) and reports are coming. Your business's information is kept in its own place, walled off from every other business: no other business can reach it, whatever happens.

### How do I know which account I'm acting as?
Whenever you're signed in, a slim bar across the very top of each page, above the menu bar, says who you are, in that account's colour: **User: your name** in rust when you're yourself; **Listing: M2 ServCore** in orange while you act as one of your businesses; **Traversence: your name** in sage on Traversence staff; **Steward:** in taupe for a Steward. Your photo at its left wears a small badge and glows while you act as another account. What you post, reply and change while acting as a listing is in its name. Tap your photo to switch accounts, the name to open that account's dashboard, ✎ beside it to edit it; the icon at the right end of the bar signs you out.

### How do I stop acting as my business?
Tap your photo at the left of the account bar and choose your **Personal Account**: you're yourself again, on your own dashboard, still signed in. Opening your business's portal again (from your dashboard or the same menu) puts you back to working as it. To leave altogether, tap the sign-out icon at the right end of the bar. Beside it, the house icon takes you to the dashboard of whoever you're acting as, from any page: your own, your business's Overview, or the admin.

### Where do I sign in or create an account?
Open the menu (☰) at the top right of any page and tap **Create account** or **Sign in**: both open the same page, with a tab for each, so you can switch between them without losing the email you typed. On a phone, tap the compass at the top left: both are at the top of its menu. Once you're signed in, the account bar at the very top of the page takes over, with your photo (to switch accounts) and the sign-out icon. On the Traversence team? Type your staff ID (TRV-0001) in **Sign in** and it takes you to the staff sign-in. Already signed in? The sign-in page takes you straight to your dashboard (or back to where you were going), so you never sign in twice.

### What happens when I create an account?
Three short steps. **1.** On the **Create account** tab: your email, a password (twice), a tick that you're 18 or older,
and you accept the Terms of Use and Privacy Policy (or use Google, Microsoft or Facebook instead). **2.** We email you a
link; it works for 24 hours, and the sign-in page can send it again. Opening it confirms your email. You can't sign in
until you do. **3.** Four quick questions, each with **Continue** or **Skip**: where you're from (country, and ZIP in
the US), then three choices, **AI Assist & Learning**, **Usage analytics** and **Videos from YouTube**, each off unless
you tick it. Opening the link signs you in, so after the questions you're on your dashboard. Change any of them later in Privacy Settings.

### My business's listing is hidden. Can I still see it?
Yes. When a listing is hidden from the public (while it's checked, or at our team's request), you and your business's team still see its page, with a line saying it's hidden. **See it as visitors do** opens it for you. To ask why, or to make it public, write to support@traversence.com.

### I didn't get the email to confirm my account.
Check your spam folder first. Then go to **Sign in**, type your email and password, and tap **Send the link again**. Each
link works for 24 hours; the newest one is the one to use.

### Can I use Traversence without an account?
Yes. Browse, search, share and see a QR code without one, and like a few things: as a guest, a like counts right away,
once per item. A guest is just this visit, so nothing about you is kept and it ends when you close the browser; we never
link it to an account later. After three likes in a visit, a small panel offers a free account, with **Keep going as a
guest** if you'd rather carry on (up to 100 likes in a visit). For anything that comes back to you (comments, so you can
see replies, edit or remove them; linking a place to keep it; messages; joining a group; becoming a contributor), the same
panel offers a free account: Google, Microsoft or Facebook, or Create account and Sign in, then brings you back to the same
page. **Not now** closes it.

### Why does it say guests on this connection have liked it today already?
To keep counts honest, each item counts up to three guest likes a day from one internet connection, so a household or an
office sharing a connection can each like it, but opening new windows doesn't keep adding. Likes from an account always
count, one per person.

### Why did it ask me to confirm I'm a person when I liked something?
Liking very quickly (many likes in a minute), or at a perfectly even pace, looks like a program rather than a person, so
we ask once with the "verify you're human" check (Cloudflare Turnstile; it usually passes by itself in a second). Once it
passes, you can keep liking. New accounts and guests are asked a little sooner than accounts that have been around a while.

### Is there a limit on likes?
An account can like 100 things a day. At 100, it says so and offers **Keep liking**: confirm you're a person and you get
another 100 for the day, so going past it is always your choice. A guest can like up to 100 things in a visit (after the
first three, choosing **Keep going as a guest**).

### Why did it ask "Help improve Traversence?" after I liked something?
Once a visit, a guest is asked whether Traversence may learn from how the visit uses the site (AI & Learning,
decisions/0051), to make guides and suggestions better for everyone. Nothing about you is kept, and it ends with your
visit. **Not now** is fine: your like still counts.

### Can I create an account from Europe?
Traversence is a U.S. regional directory. If you're connecting from the EU, the EEA or the UK, **Create account** asks one
more question, where you live. If you live there too, we can't create the account on the site; email
support@traversence.com and, if you're planning a trip to the U.S., we can set one up for you. Living anywhere else, or
living in Europe but connecting from somewhere else, sign-up goes ahead as usual. Browsing never needs an account and
works everywhere. Where a connection comes from is looked up in [DB-IP](https://db-ip.com)'s free IP-to-country data
(licensed CC BY 4.0); we keep only the European ranges, and nothing about your connection is stored with your account.

### How does the menu know I have a business or a staff account?
It asks each time it opens. A business shows under you as soon as you've claimed it or someone on its team has added you, and it goes when you're removed. A Traversence staff account shows when your staff login is linked to your own account. Nothing else about you is used, and no one else sees the list.

### My business doesn't show in my account menu. How do I get it there?
Your business shows under **Your listings** and **Business portal** once your account is on its team: when you claim it and the claim is approved, when its owner adds you, or when our team assigns it to your account (as its owner, or with another role; we email you when we do). If you run a business that isn't showing, claim it from its page or ask us to add you.

### My plan includes White Glove. Who can get into my business, and what can they do?
Strategic Partner and Cornerstone include White Glove: our team sets up and keeps up your business for you. So we can, your White Glove agent (a named member of our staff) gets access to your business when the plan starts, and we email you who it is, and again if it ever changes to someone else. They can update your profile, catalog, content, storefront and codes, and see your customers, orders and messages to help with them. They can't touch your billing or payouts, your team, your keys, exports or deleting the business. Every change they make is logged. You can see who has access, and turn it off or on again, in your Business portal → **Settings & team**. The [Terms](/terms.php#white-glove) say the rest.

### How do I send a quote or an invoice from my business?
In your business portal, open **Quotes & invoices** and tap **New quote**: your customer's email (they're added to your Customers), their name and what it's for. Open it to add lines from your catalog or by hand, then **Terms & how to pay**: when it's due (on receipt, Net 15, Net 30), a deposit, your sales tax rate, your own pay link (Square, PayPal and the like) and any other way to pay (Zelle, checks). **Send** emails your customer a private link: they see the quote, approve it by typing their name (or decline it), and it becomes your invoice, with what's paid and what's still due. You get an email either way. Payments go straight to you, never through Traversence: record each one with **Record a payment** as it arrives. Included in Basic Partner and up.

### How do I set my sales tax and my usual quote terms?
In your business portal, **Sales tax** holds your rates: add one for each place you collect tax (a whole state, a city or ZIP codes), with its percent. **Shipping & pickup** holds the ways you deliver (flat rate, by weight, free over an amount, local pickup or delivery). Then in **Plan & settings**, **Quotes & invoices: your usual terms** sets what every new quote starts with: when it's due, a deposit, your usual tax rate, your pay link, other ways to pay, notes and how long a quote is good. You can still change any of them on a single quote, and pick a different rate from your list there. Included in Basic Partner and up.

### Can my business make its own discount codes?
Yes, on Basic Partner and up: in your business portal, open **Discount codes** and tap **New code**. Choose the code (like SPRING15) and the offer, a percent off or an amount off; if you want, add when it ends, how many times it can be used in all, a smallest order, and whether each customer can use it only once (the default). The offer is yours to set. Your customer types the code on their quote page before approving (**Have a discount code?**), or you add it to a quote yourself; it comes off before tax and counts as used when the quote is approved. Turn a code off any time; a quote still carrying it then can't be approved until the code is removed.

### I have a discount code from a business. Where do I use it?
On the quote that business sent you: open it from the email and tap **Have a discount code?** before you approve. The quote shows what comes off.

### Where do I keep track of orders?
In your business portal, **Orders**: every approved quote is an order there. Move each one on as you work: new, in production, ready for pickup, shipped, done. **Ready** and **Shipped** email your customer (add a tracking number or a pickup note). Its card shows what's paid and what's still due. Every plan includes orders.

### I got a quote or invoice from a business through Traversence. Is it safe?
Yes. The link in the email is private to you: it shows that business's quote, and you approve or decline it there without an account. Payment goes to the business itself, through its own pay link or the way it says (Zelle, a check): Traversence never takes your payment for it. Questions about the quote go to the business.

### We order printing from you for our business. Can my coworkers see our orders?
Yes. Our team keeps your business's orders together under your business, and its people as contacts: whoever orders, approves proofs or pays the bills. A contact gets an email from us (or from your business's Owner or a Manager) with a link to **claim their place**: tick **Activate my contact** and **Create my Traversence account**, choose a password, and you're in, with your business's orders, proofs, invoices and artwork on **Your orders**. Already have an account with that email? Sign in from the link instead. Claiming your place is not claiming your business's listing: that stays the usual claim, and the listing doesn't change. Invoices from QuickBooks are made out to the business, with who ordered noted on them (coming).

### You made a listing for our business that I didn't ask for. Is it on the site?
No. When a business we work for isn't on Traversence, we keep a **private listing** for it, only so its orders and artwork have a home. It's never shown: not in search, on maps or in the directory. If it's already listed, we connect it instead and change nothing on it. Want your business in the directory? Claim it and publish it when you're ready; guided steps for that are coming.

### How do I add people to my business's team?
In your business portal, open **Plan & settings**. Under **Your team**, type their email, choose their role and tap **Add**. Add their name too if you like. Someone with a Traversence account joins at once and gets an email; anyone else gets an invitation whose link lets them claim their place and create their free account in one step (or they join as soon as they sign up with that email). **Send again** re-sends an invitation that went astray. Change a role from the list, or take someone off with **Remove**; anyone can **Leave** a team. The Owner and Managers manage the team; only the Owner gives the Manager role. The Owner can't be removed; to hand the business to someone else, see the next question.

### How do I hand my business over to someone else?
In your business portal, **Plan & settings** → **Hand over the business** (only the Owner sees it). Choose someone on your team, or type the email of any Traversence account, and tap **Ask them to take over**. They get an email with what taking over means and **Accept** or **Decline**; nothing changes until they accept, and the request lapses after 30 days. When they accept, they're the Owner, you stay on the team as Manager (you can leave after), and everyone on the team is told. If the business has a paid plan, your card comes off it so you're never charged again: the plan runs to the end of what's paid, and the new Owner adds their card on the Plans page to keep it.

### Can I send proofs and files with a quote?
Yes. Open the quote in **Quotes & invoices** and choose **Proofs & files**. Upload a **proof** (a PDF or an image) and your customer sees it on their quote page, where they **Approve the proof** or **Ask for changes** (saying what to change); you get an email either way. Upload a new version after changes and it becomes the one they answer; answered versions are kept as the record. You can also add **files**: shared with your customer (a spec sheet, a contract) or kept for your team. Proofs: PDF, images or video (MP4, MOV, WebM; your customer can play it on their page); files: also Word, Excel, PowerPoint, text, CSV or ZIP. Files up to 24 MB upload straight away; bigger ones, up to 1 GB each (raw video included), ask you first and show their progress; you can move around the site while they go (see "Can I leave the page while a big file uploads?"). Files go straight from your browser to our secure file storage, and the links to see them are private and expire after a short while.

### How much storage does my business have?
Your plan sets it (more with a storage pack from the Plans page). Your business's **Overview** shows how much you're using, and so does each quote's **Proofs & files** page. Proofs and files count toward it; removing a file frees its space. An upload that would go past your storage is refused, with how much you're using and an **Add storage** button: a storage pack or a bigger plan, on your Plans page. When you're past 80% the meter turns amber and offers it too.

### What happens to a message I send from one of your pages?
It comes to our team, who answer by email (or by phone, if you gave a number and asked us to call). We keep your name, email, phone and message so we can answer and follow up, and they become your customer record with us. We never add you to a mailing list from it, and never sell or share it. A page's form takes a few messages an hour from one connection, to keep out spam.

### Can my business set its own sales tax, shipping and wholesale prices?
Coming, with the business tools. You'll set your own sales tax rate for each place you sell in (a state, a city or a set of ZIP codes), your shipping and pickup options (flat rate, by weight, free over an amount, local pickup, or delivery by ZIP code or distance), and price lists for groups of customers, like Wholesale, with volume breaks.

### Will my business have its own pages?
Coming, with the business tools. Your listing will get its own pages (About, Services, FAQ, Contact and others) with a contact or quote form, a search description and a share picture. Messages from your forms come to you and into your customer list.

### I make work for Traversence. Where do I see my work orders?
Each work order we send you comes by email with its own link, and with a link to a page of all your work orders from us: the open ones first, then those finished in the last 90 days. Tap one to open the full work order, download its files and update where it stands (accept it, in production, shipped or ready, complete). No account or password is needed. The links are private, so don't forward them. You'll never see our client's prices or contact details: bill Traversence, and never contact our client directly.

### My work order link has expired. How do I get a new one?
Links work for 30 days. Open the expired link and tap **Request a new link**: we email a fresh one to the address we have for you (never shown on the page), and the old link stops working. Didn't get it, or lost the link altogether? Every one of these pages has **Didn't get it, or need a hand?**: type your email to get a new link sent to it (if it's an address we have for you), or ask our team, who'll send one by hand. You're never left without a way back in.

## Buying and selling (the Marketplace)

### What is the Marketplace?
Where people and local businesses near you offer what they have: something to sell or give away, or a service (lessons, repairs, hauling). Open **Marketplace** from the compass. Start from a category, or search by words and a town, and narrow it with **Filters** (category, items or services, from people or businesses, price, free only). **Sort by** puts the newest first (the usual), the nearest first, or the lowest or highest price first. Nearest measures from the town you typed; without one, from the location you set at the top of the page (rounded to about a mile and never kept); or, when you're signed in, from your home town. It goes town to town, never from anyone's exact spot. Nothing is ranked by payment or clicks. Traversence takes 0% from any sale: you pay the seller directly, or a business through its own Stripe or Square.

### How do I post something on the Marketplace?
Tap **Post something** on the Marketplace (or in your Dashboard, open **Your Marketplace**). Add photos (at least one for an item, up to 10; the first is the cover), a title, a price (or **Free**, or **Ask me**), a category and the town or area. Then choose how long to offer it. You need an account and must be 18 or older. Your photos go into your Gallery, in an album called Marketplace. They show there while the post is up, and go private when it comes off.

### What can I sell on the Marketplace?
Most everyday things and services. Not allowed: weapons and ammunition, drugs, alcohol and tobacco, anything stolen or fake, and anything taken from a burial, sacred or protected site. A post that names something on that list can't go up, and we tell you which word stopped it. Some words, like cultural items, protected wildlife, live animals, or a request for a deposit, mean a person on our team looks before the post shows, usually within a day.

### Why does my post say "Waiting for a look"?
A word in it is one our team checks first (see What can I sell on the Marketplace?). Only you and our team can see it until then. Once it's fine, it shows on its own. If we take a post down, Your Marketplace shows why.

### How many posts can I have up at once?
Five: showing, pending, or waiting for a look. Mark one **sold**, or **Take off for now**, to make room. While you have five out, **Post it** (and **Post something** on the Marketplace) is greyed out and says why. Sold and expired posts stay in your list and don't count. Businesses' catalogs have their own limits by plan (coming).

### How long does a post stay up?
You choose when you post: an item for 7 to 90 days (30 unless you change it) or until a date, and a service the same, or **Ongoing** (90 days unless you change it). When the time is up, and every 30 days for Ongoing, we ask **Still available?** in your Pulse and by email. Tap **Still available** in Your Marketplace and it stays up. If nobody confirms it by the next check 30 days later, it comes off. It stays in Your Marketplace, and **Put it back up** brings it back in one tap.

### How do I contact a seller?
Open the post and tap **Message the seller**, or send the quick message ("Hi, is this available?"). It goes to the seller in Traversence messages, and their reply comes to yours. They see your name, never your email. A post is an invitation to message about it, so it reaches the seller even if they usually take messages only from people they know, unless one of you blocked the other. You can message up to 20 new sellers a day.

### How do I pay for something on the Marketplace?
For a person's post, between you and the seller: cash, your own payment app, whatever you agree. No payment passes through Traversence, and no one from Traversence will ever ask you to pay them. Never send a deposit to someone you haven't met, and meet somewhere public. A seller can add how they take payment (Zelle, Venmo, cash), which you see once they accept your offer. Buying from a business is different: see How do I buy from a business on the Marketplace?

### Can people see my address on the Marketplace?
No. A post shows only the town or area you pick. Share the exact spot in messages with the person you're meeting.

### Where are the posts I saved?
Tap the bookmark on a post to save it. Your saved posts, and the sellers you've messaged, are in **Your Marketplace → Buying** (in your Dashboard, or Saved and messaged on the Marketplace's menu). Sellers see how many people saved a post, never who.

### What does "Pending" mean on a post?
The seller has someone lined up (an accepted offer) but it hasn't sold yet. It still shows, so you can message them or make an offer in case it falls through.

### How do offers work on the Marketplace?
On a post, enter an amount and tap **Send offer** (on a free post, **I'd like it**). The seller can **Accept**, **Counter** with another amount, or **Decline**; you can accept their counter, counter again, or **Withdraw**. Every move also shows in your messages with them. An offer nobody answers closes after 7 days. Your offers, and offers on your posts, are in **Your Marketplace → Offers**; your Pulse tells you when one is waiting on you. An offer is what you agreed: no payment passes through Traversence.

### What are Sold and Got it?
Once an offer is accepted, meet up. Then the seller taps **Sold** and the buyer taps **Got it**. When you've both tapped, the trade is complete: the post is marked sold, other offers on it close, and you both earn trust points (once a month for the same two people). If one of you hasn't tapped after 3 days, we remind them once. If the deal falls through before then, either of you can **Call it off**, and the post shows as available again.

### Can I say how a trade went?
Yes, after you've both confirmed it: tap **Say how it went** on the trade in Your Marketplace and write a short note. It shows on the other person's posts, under their name, with whether you bought from them or sold to them. There are no stars: a note is only possible after a real, confirmed trade. Anyone signed in can report a note.

### What if something goes wrong with a trade?
Tap **Report a problem** on the trade (once an offer is accepted, and up to 14 days after it completed) and say what happened. A person on our team reads the whole history and settles it: it went through, it fell through, or one of you was in the wrong, which lowers that person's trust. We email you both what we found, usually within two days. Traversence never holds money, so we can't refund a payment: never pay before you meet.

### How do I report a post?
Open it and tap **Report** under the title. Choose why. Our team looks at it, and a post taken down tells its seller why.


### Can my business sell on the Marketplace?
Yes, on every plan. In **Catalog**, open the item and tap **Publish** in its card: choose its Marketplace category and tap **Publish it** (what buyers can do follows its kind). The card says where it stands online, and has **Publish changes** after you edit it and **Unpublish**. The **Marketplace** page lists every item the same way, for working through several at once. Publishing puts its name, description, price and photos on the Marketplace and in your listing's **Shop** (Shop from Basic Partner up). Your cost, markup and supplier stay private to your team. Publishing needs a role with **Publish**; drafts and photos need **Catalog & content**.

### How many items can my business publish?
Free 10, Basic Partner 25, Core Partner 100, Strategic Partner 250, Cornerstone 1,000 per listing. Only published items count: drafts, unpublished and expired ones don't. At your plan's number, Publish is greyed out with the plan that raises it, and nothing already up comes down. Every photo counts toward your plan's storage, so a bigger catalog grows into a storage pack or the next plan.

### What happens when I change an item that's already published?
The Marketplace keeps showing the published version while you edit the draft in your Catalog. The item then says **Published, with unpublished changes**; tap **Publish changes** when you're ready, and that becomes the next version (every version is kept). **Unpublish** takes it off the Marketplace and your Shop; Publish brings it back.

### How do I add photos to an item?
Open **Catalog**, tap the item, and under **Photos** tap **+ Photos** (JPG, PNG or WebP, up to 10 an item). The first one is its cover; × takes one off. They're the same photos the item's Marketplace page shows, so adding them in either place is the same thing. A published item shows new photos once you tap **Publish changes**; every photo counts toward your plan's storage.

### How do I remove or delete an item from my catalog?
Open **Catalog**, tap the item, and tap **Delete** in its card, then **Delete it for good**. It comes off the Marketplace, your storefront and your Shop, and out of your catalog. Quotes, invoices and orders that have it keep their own copy, so nothing earlier changes. An item brought in from Square isn't brought back by the next import. To keep an item but stop showing it, open **Details** and set **Shown** to **Hidden** instead; to take it off the Marketplace only, tap **Unpublish** on your Marketplace page.

### What can buyers do on my business's items?
It follows what each item is, so you don't set it. Goods with a set price get **Buy now**; event tickets **Get tickets**; stays **Book your stay**; rentals **Rent it**; subscriptions **Subscribe**; digital goods **Buy and download**. A service gets **Request this service** (the buyer says what they need done, where and when; you reply with a price and a time), and made-to-order work gets **Request a quote** (you send a quote, with any deposit and a proof to approve, from Quotes & invoices). Until your checkout is live, or for an item without a set price, buyers ask for a quote instead. **Message** is on every item (your team answers in your inbox). The one choice is yours: **Accept offers** on goods (physical goods, harvest, rentals), on your Marketplace page under **How buyers buy**; buyers offer an amount, and you accept, counter or decline. No payment ever passes through Traversence.

### How do I buy from a business on the Marketplace?
On an item with **Buy now**, choose how many and tap it (a stay or a rental asks for its dates first, and a subscription says **Subscribe**), or **Add to cart** to buy several things from the same business together (you have a cart for each business, because each is paid separately). At checkout choose how you get it (pickup, delivery or shipping) and how you pay: by card, Apple Pay or Google Pay through the business's own Stripe or Square account, whose card form opens right on the page, or a way the business takes directly, like Zelle, a transfer or a check, with its instructions. Your money goes straight to the business: Traversence never holds it or sees your card. Your orders are in **Your Marketplace → Buying**.

### What if I pay a business by Zelle, transfer or check?
You'll see the business's instructions with the amount and your order number to put in the memo. Your items are held for the days the business sets; they mark the order paid when it arrives, and you're emailed. Zelle and transfers have no buyer protection, so only pay businesses you know. You can cancel an unpaid order; nothing is charged.

### Who do I ask about a refund or a problem with an order?
The business: refunds are made from its own Stripe or Square account, or the way you paid it. Your order page has a link to contact them.

### How do I take payments on the Marketplace?
In your business portal, open **E-commerce setup** and go through its steps. **1. Getting paid:** from Core Partner up, connect your own Stripe or Square account by signing in (you never paste keys; on Basic, Square connects for your catalog only, below); the money goes straight to your account, Traversence takes nothing, and your processor charges its usual fee. On every plan you can also take Zelle, bank transfers, checks or payment at pickup, each with your own instructions. For a bank transfer, we suggest asking the buyer to call you for the details rather than writing your account and routing numbers there. **2. Sales tax**, **3. Shipping and pickup**, **4. how long to hold items** for a direct payment, **5. a test purchase**, then **6. Go live**. While payments are in test mode, step 5 walks you through it: **Run a test purchase** makes a $1 test order from your business, paid on the same card form your buyers see with a test card (4242 4242 4242 4242 for Stripe), with no real money and no product needed; the step ticks itself once Stripe or Square confirms it, and the order shows in Quotes & invoices, where you can void it. Once you're live, buy one of your own items from a personal account instead and refund it. Every Marketplace order also appears in Quotes & invoices: paid by card, or waiting for you to mark a direct payment received.

### Can I track stock on my Marketplace items?
Yes. In your portal's Marketplace page, switch on **Track stock** for an item and enter how many you have. Items being paid for are held (about half an hour for a card, your chosen days for Zelle or a check), paid orders take them off, and at 0 the item shows **Sold out** until you add more. It's offered for physical goods, made-to-order work and harvest; event tickets count their seats, and bookings and rentals their dates, by themselves. For physical goods you can set **Tell me when stock is down to** in its Kind details, and you're told when a sale reaches it.

### How does search know what I mean by a word with more than one meaning?
By the words around it, as they're used here. "Shoot" can mean a photo shoot, a vaccination or a shooting range: where our listings and the pages we read use "shoot" with gun clubs and ranges, "places to shoot" finds those, and "photo shoot" finds photographers, since that's what "photo" sits with. Words our team set for a kind of business always come first. Nothing you search for is used to decide this, only what's listed.

### Does Traversence check my spelling?
Yes, as you type names, descriptions and notes. Your browser underlines words it doesn't know, and once you pause, the site offers what you might have meant under the box, from its own dictionary: "Holstr: **Holster** · Host". Tap one to put it in, or **Keep it** for a name or brand you spelled on purpose (that device remembers it). Nothing is changed unless you tap. The dictionary knows this region's own words too (snickerdoodle, biscochito, sopapilla, piñon, latigo…), any our team adds, and words used by two or more businesses on the Marketplace. Lists whose choices each mean something have an **i** beside them: tap it to see what each choice is, and pick from there.

### Can Traversence write my item's description?
Yes, on a paid plan. Open the item in **Catalog**, tap **Details**, and under **Description** tap **Write it for me**: AI Assist writes one from the item's name, kind and details (and improves your words if you've started), never inventing materials, origins or claims. It goes into the box for you to read and change, and nothing is saved until you tap **Save**; **Undo** puts your words back. Each one uses one of the day's free asks, then one of your plan's AI credits. It needs **AI Assist & Learning** on in your Privacy Settings; on the Free plan the button is greyed with why.

### Do I charge sales tax on an item?
Each item's kind sets the usual answer, so you rarely touch it: physical goods, made-to-order work, tickets, digital goods, subscriptions and rentals are taxed at your store's rate (set in E-commerce setup); most services, fresh food for the home (harvest) and stays (whose lodging tax is added as its own line) aren't. Change it for any item in **Details** → **Sales tax** (tap the **i** for what each means); when you change an item's kind, its sales tax follows unless you've set it yourself. Your state and town decide what's taxable, so check with your accountant.

### What kinds of item can my business sell?
Nine, and each one works its own way, everywhere it shows (your catalog, the Marketplace, your storefront, checkout, orders and receipts). In **Catalog**, choose an item's **Kind** (tap the **i** beside the list: a pop-up shows what each kind is, with an example, and you can pick one there), then open its card and tap **Kind details**. The kinds follow the item's name: food like tamales or snickerdoodles can be Physical goods, Made to order, Harvest & perishables or a Subscription, never a service; an animal is Physical goods only; a cabin is a booking or a rental. Kinds that don't fit the name are greyed with why, and words in the name add their own ("Kayak **rental**", "Tamale-making **class**", "Coffee **club**"). Each kind:
- **Physical goods:** weight and size, a stock alert, pickup only if you like.
- **Service / labor:** a flat price bought at checkout (with a travel fee if you charge one), or by the hour, which buyers ask you to quote; the area you serve.
- **Made to order:** the questions buyers answer at checkout ("Size", "Wording"), a deposit paid when ordering (50% unless you change it) with the rest invoiced when it's ready, and a proof they approve first.
- **Event tickets:** the date and time, where, and how many; buyers get a code for each seat to show at the door, and your team checks it in once from the ticket.
- **Digital goods:** the file, kept private (add it on your Marketplace page); buyers get a download link that works a set number of times within a set number of days.
- **Subscriptions & memberships:** charged every month or year until the buyer cancels, with a free trial if you like. Through Stripe for now.
- **Bookings & reservations:** nights at your place; guests choose their dates and number, agree to your house rules (kept as a record), and pay your lodging tax on top.
- **Harvest & perishables:** the pickup windows buyers choose from, and how fresh it is.
- **Rental equipment:** rented by the day, with the dates checked against how many you have, an optional damage waiver, and a deposit, charged and refunded on return, or held on the card for rentals of 6 days or fewer on Stripe. When it comes back, open the order and tap **Mark returned**, keeping any part of the deposit for damage.
The item says what it still needs before it can be sold (a ticket its date, a digital item its file). Square items you bring in keep their kind (Square's appointments, events, digital and memberships). Earlier items carry over: items are Physical goods, classes are Event tickets.

### How do tickets, downloads, bookings, rentals and subscriptions work when I buy?
- **Tickets:** after paying, your order page has a ticket for each seat, with a code to show at the door on your phone or printed.
- **Downloads:** your order page and your email have the link. It works the number of times and days the item says; after that, ask the seller for a new one.
- **Bookings and rentals:** choose your dates (and guests) on the item, and checkout shows the price for them. A stay asks you to agree to its house rules. A rental's deposit comes back when it's returned undamaged.
- **Made to order:** answer the seller's questions at checkout; you pay the deposit then, and the rest when it's ready.
- **Subscriptions:** charged each month or year by card until you cancel. Cancel any time from your order page: it ends at the close of the period you've paid for.

### Can my business have its own storefront?
Yes, from Core Partner up: your own shop at **trvgo.us/your-name**. In your business portal, open **Storefront & pages** and tap **Set up my storefront**. It shows what you already have on Traversence (your published items, how to reach you, and pages you write, like About or Hours), so there's nothing to copy, and a change shows on it at once. Pick one of four themes, add your logo and a cover photo, and an accent color. Only your team sees it, through a preview link, until you tap **Go live**; you can pause it any time. Buying, messages and offers stay on Traversence. A business with several locations can show each under its brand (trvgo.us/brand/location). You can also put it on your own domain (see the next question).

### How do I build my storefront's pages?
In your business portal, open **Storefront & pages**, then under **Your pages** tap a page's name and **Edit the page**. It opens in the builder, the same one our own pages use: press **Edit** on the page, and a panel opens (from the bottom on a phone, at the side on a computer). **Add** holds the blocks: a heading, words (paragraphs, lists, **bold**, *italic*, links), a picture, a button, a divider and a spacer; tap one to add it, or drag it into place. **Layout** shows the sections (one, two or three columns) and lets you drag blocks and sections around; **Design** sets alignment, width and spacing for a computer, a tablet and a phone, each on its own. Pictures you upload are kept in your Gallery and count toward your plan's storage. A page you haven't built yet starts from the text you wrote for it, as one block, and that text is kept as it was. **Save draft** keeps your changes for your team only: you see them in the builder and through **Preview**, while visitors still see what's published. **Publish** puts it on your storefront as the next version; ▾ → **Versions** lists every one, with who and when, and **Roll back** puts any earlier one back. Who can do what is set by your roles in **Team & roles**: **Storefront & theme** to build and save drafts, **Publish** to publish, with no one asked to approve; for a role without Publish, the button is greyed and says why. Your storefront stays plain and fast: it runs no scripts, so the builder's parts of the site (a search box, a map, likes and comments, a form) aren't offered on it. Your pages take your storefront's theme (see the next question). Coming next: blocks for selling (your items, collections, a featured item, hours, map and directions, a booking or quote form, reviews), and the builder's bar on your preview. Publishing at a set time isn't offered for storefronts yet.

### Do my storefront's pages follow my theme?
Yes. The theme you pick in **Storefront & pages** (Canyon, Sage, Paper or Night) is every page's starting style: the page color, the words, the heading font, the buttons' shape and color, and the two backgrounds a section can have, which take the theme's names (Canyon's Sand and Clay, Sage's Sage and Stone, Paper's Linen and Honey, Night's Ember and Dusk). Your accent color colors the buttons and links. The builder shows the page in your theme, as visitors will see it. Blocks hold no colors or fonts of their own, so when you change the theme or the accent, every page follows at once, with nothing to redo or publish again.

### Can I put my storefront on my own domain?
Yes, from Core Partner up. In **Storefront & pages**, under **Your own domain**, either **buy a new domain** or **use one you already own**.
- **Buying one:** search for a name, pick one, confirm whose name it's registered to, and buy. It's registered to your business with privacy on, so your details don't show in public records. It's charged to your plan's card and renews each year two weeks before it runs out, unless you turn renewal off. It's set up for you, and it's yours: you can move it to another registrar any time (**Move it to another registrar** gives you its transfer code). Domain names aren't refundable once registered.
- **Using your own:** type it in, then add the records we show where your domain is registered (GoDaddy, Namecheap and so on): one for yourshop.com and one for www. We check every 15 minutes; DNS changes can take a few hours. Once it points at your storefront, it gets its security certificate and goes live by itself.

Either way, your trvgo.us address keeps working and sends visitors to your domain. If the domain stops pointing at your storefront for three days, your storefront goes back to trvgo.us until it's fixed, and your Pulse tells you. **Disconnect** puts it back on trvgo.us any time; a domain you bought through us stays yours. Email from your own domain is coming: its records show alongside the storefront's.

### What is my business's Trust score?
The checks your business has done, so buyers know what they can count on. Open your business portal, then **Market 360°** → **Trust score**. Each check ticks itself from what we hold and has the button that does it: **Phone verified** (you confirmed by text from the phone on your listing, when you claimed it) and **Payments verified** (Stripe or Square has checked who you are and your bank and switched on payments and payouts; we ask them daily, or tap **Check now**, and if they still need something, it says what, with a link to finish it with them). Coming: your legal identity, a match in the state's own records (Arizona Corporation Commission, Arizona TPT license, New Mexico Secretary of State), an owner ID check through Stripe Identity (included on a paid, current plan, otherwise a one-time $1.95 paid first; we keep only that it was verified and when, never the images), and accepting the Seller Agreement. The badge buyers will see names only what's done, for example "Verified: phone · payments"; we never claim more.

### Can my business see who linked it?
Yes, by name: Linking tells everyone that the business they link can see they did. Open your business portal, then **Market 360°** → **Linked people**. A person's phone, email or address shows only if they chose to share it with your business, and it's read from their own card each time, so it changes or disappears the moment they change it or unlink. There's no export, and it isn't for adding to other lists; people who bought from you are in **Customers**, which you can export. Links made before links were open show by name only once that person has seen the notice, and people who paused Linking don't show; both still count in your numbers.

### What are a business's store policies?
Its rules for orders: returns, cancellations, deposits and any house rules. You see them on its items, its storefront and at checkout (tap **Store policies** to open them), and you agree to them, with Traversence's Terms, when you tap **Place order**. Every store's policies also say that the business is the seller, Traversence isn't a party to the sale, and problems go to the business first. Your order keeps a copy of the policies it was placed under, shown on your order page and in your receipt, so a later change never rewrites it.

### How do I set my business's store policies?
In your business portal, open **Market 360°** → **Store policies** (under Money & Processing). Choose your returns (all sales final; returns within 7, 14 or 30 days; or exchanges only), your cancellations and how deposits work, and add house rules in your own words if you like. Save, and buyers see the new policies at once; orders already placed keep the ones they were placed under. The clauses every store has are shown, but can't be changed. Until you choose, buyers are told to ask you about returns before they buy.

### What does Traversence keep when I agree to its Terms or place an order?
A record that you agreed: which document and which version you were shown (with a fingerprint of the exact text), the choices shown with it (for an order, the business's returns, cancellations, deposits and house rules), when, and the internet address and browser it came from. Records are only ever added to, never changed, and kept 7 years. A business can include its order's record if it answers a dispute about that order with its payment company. If you delete your account, the records stay, without your name or email. The Privacy Policy explains it under **Records of what you agreed to**.

### What can my business sell on the Marketplace?
Most things, under the same written rules for every business, checked when you publish an item:
- **Never:** weapons, firearms and ammunition; illegal drugs and paraphernalia; prescription medicine; counterfeit or stolen goods; hazardous materials; adult content and services; gambling, lotteries and raffles; investments, crypto and multi-level marketing; government IDs; human remains and anything from a burial, sacred or protected site; endangered species. An item like that doesn't go up, and you're told why.
- **With your license:** alcohol, tobacco and vapes, CBD and hemp. You confirm you hold the license and meet the conditions; it's kept as a record. Card processors restrict these themselves, so buyers pay you directly or ask for a quote.
- **Under conditions:** meat and dairy (from an inspected processor or licensed dairy, kept cold), eggs (clean, kept at 45°F or below, in labeled cartons), homemade food (a licensed kitchen or Arizona's cottage food program), live animals and plants, lodging, resold tickets. You confirm the conditions once for each item (kept as a record); buyers see them, and can pay by card.
- The check reads an item's name the way search does: a wine rack is a rack, a beer mug is a mug and a gun holster is a holster, so they just publish; red wine, beef jerky or gun parts are the thing itself. When it's unsure, publishing asks once whether the item is that.
- **With a notice:** perishables, used or as-is goods, made-to-order and digital goods show buyers a short notice.
You don't have to wait until you publish to find out: in **Catalog**, the **Marketplace** column says, for every item, whether it can be published, may need your license, or can't go on the Marketplace (it can still stay in your catalog for quotes and invoices), and the item's card says why. To check any item quickly, or see the full list, open [What can be sold](/market/rules.php). Some words mean our team looks first, usually within a day. Stripe's and Square's own rules apply too, and can be stricter. Anyone can report an item; a shop that keeps breaking the rules can be paused (never its listing or map pin).

### What is the Seller Agreement?
The agreement between your business and Traversence for selling on the Marketplace and your storefront: you're the seller, payments go straight to you (Traversence takes 0%), refunds and disputes are yours through your processor, what can be sold, your store policies, and your customers' information. Read and accept it in **E-commerce setup**, step 6, before you go live; it's kept as a record. If it changes in a way that needs your acceptance, we ask again before your next publish. Your shop stays open meanwhile.

### A buyer disputed a card payment. What do I send?
In **E-commerce setup**, under **Marketplace orders**, tap **Dispute packet** on the order. It's one file with the order, its receipt, the store policies it was placed under, and the record of the buyer placing it (when, from what browser, and a fingerprint of the exact terms they saw). Save it as a PDF (Print, then Save as PDF) and attach it to your answer in Stripe or Square.

### Why is Traversence asking for my business's tax ID and bank details?
A federal law, the INFORM Consumers Act, asks every online marketplace to collect and verify the details of a "high-volume" seller: one with 200 or more sales and $5,000 or more in a year. Once your Marketplace sales reach that (your Trust score page shows how close you are), we ask, and you have 10 days to give your legal name, address, phone, email and tax ID, in **Market 360° → Trust score → INFORM Act details**. Your bank account counts as verified through Stripe or Square once payouts are on. We ask again each year. Your tax ID is kept encrypted and never shown to buyers. Past $20,000 a year, the law shows buyers your business's name, address and contact on your items (only your state if it's a home address). If the details aren't in by the deadline, card checkout pauses until they are; your listing and pages stay up.

### How do I report a problem with an item or a seller?
On the item's page, tap **Report** (signed in), and say what's wrong: something that can't be sold, a counterfeit, a safety problem or a recall, or a seller you think isn't genuine. You can also call us at the number shown there. Our team looks at every report; an item that clearly breaks the rules comes down at once. Items whose name matches a product on the CPSC's recall list are checked by our team before they show.

### Can I bring my Square items onto Traversence?
Yes, from Basic Partner up. In your business portal, open **E-commerce setup** and, under **Your Square catalog**, **Connect Square** by signing in, then **Import from Square**. Each Square item comes into your catalog as a draft (an item with sizes or colors comes in once for each). Nothing goes on the Marketplace until you publish it, and drafts don't count toward your plan's limit. From then on Square is in charge of price and stock. Prices and counts update every day, when you tap **Sync now**, and as soon as your stock changes in Square. Whatever sells here also comes off your Square stock. From Core Partner up, the same connection takes card payments, and Marketplace orders also show up in Square's Orders.

### Do my business's items expire?
They stay up, but every 30 days your Pulse asks **Still on offer?** for each published item. Confirm with one tap (or all at once). An item nobody confirms by the next check comes off, kept in your portal: Publish brings it back.

## Community groups

### How do I start a group?
Open **Community** and fill in **Start a group**: a name, what it's about, its kind (interest, local or support), and its charter: the purpose (required), who it's for, house rules, and what happens if you step down. You need a confirmed email to start one. One person can run up to 5 groups. If you run a business on Traversence, you can start its group instead (see Can a business run a group?).

### What's a group's charter?
The rules the group runs by, written by whoever starts it, and what you agree to when you join. Every group's page shows **What you're agreeing to**: its purpose, house rules, who sees that you're in it, what happens if the owner leaves, and how joining works, with **Read the whole charter** for everything else and every past version. Each charter also carries Traversence's ground rules, which no group can remove: our Terms, no harassment, no one's private information, no sacred or restricted sites, and selling only through Traversence. Groups started before charters show the ground rules until their owner writes one.

### What's on a group's page?
At the top, the group's name with **Join** (or **Ask to join**) on the right; a local group shows photos people have shared of its place. Under it: what kind of group it is and its topic (tap either to find more like it), what it's about, **Share** and a **QR code** for the group, and its numbers at a glance: members, posts this week, how joining works, and since when. Then the charter (**What you're agreeing to**), and, for members, the posts and the member list. A group's own cover photos are coming.

### What happens when a group's charter changes?
Members are told once, in their Community feed and on the group's page, with what changed. You don't have to agree again and nobody is removed by a change; if you don't like it, you can leave. Most changes take effect at once. Two give 14 days' notice first: what happens if the owner leaves, and opening the member list to all members (you can hide your own name meanwhile). Making the member list more private happens at once.

### Who can see that I'm in a group?
It depends on the group's charter, which you see before you join. Usually members see each other's names; in some groups, such as support groups, only the moderators do. Nobody in a group ever sees your email or where you live. When a group is about to open its member list, you can hide your name from it; the moderators still see it, to run the group.

### Can a business run a group?
Yes, one group per business, run by its team. Its Owner or a Manager starts it from **Start a group**, choosing the business under **Start it as**. The group shows **Run by** and the business's name. The Owner and Managers run it (only the Owner can close it), Creators and Support moderate it, and Sales answers as the business's rep. A business's places and topics, such as Support or How-tos, will be chapters of its one group (coming). The business contacts you outside the group only if you ask it to or Link with it.

### Why does a post say "Sales, Pine Cafe"?
In a business's group, its team can post as the business (the Owner, Managers and Creators), or as its sales rep, shown as their name with "Sales" and the business's name, so you always know who's speaking for the business.

### How do reports work in a group?
Tap **Report** on a post and choose why. Reports on a group's posts go to its own moderators (or only its owner, if the charter says so), never to Traversence, and nobody learns who reported. A post is hidden while it's looked at once enough members have reported it (the charter sets how many, counting only different members who've been in the group more than a week), or at once if it shares someone's private information or a sacred or restricted site. Its author still sees it, marked. The moderators keep it, remove it, or remove it and its author. Two kinds of report come to Traversence's Safety team instead, where our Terms apply: **Breaks the law or puts someone in danger**, and a report on a whole group.

### Can a group ask Traversence for help?
Yes. A group's owner and moderators can use **Ask Traversence for help** on the group's page for what the group can't settle, such as someone harassing people across groups or a moderator's account taken over. It reaches our support team as a case, and we reply by email. If reports in a group wait 14 days with nobody deciding, we're asked to help on our own.

### What notices will I get about groups, and can I turn them off?
Each one goes to your Pulse once, when it's about you or something you follow: your request to join a group was answered (with the group's welcome message), the charter of a group you're in changed, a group's moderators removed your post, a new group started in a place you follow, or one of your connections invited you to a group. If you run a group or lead a chapter, you also hear about its chapters; if you run a business, you hear when a group lists it among the places it's about. Switch any of them off in **Dashboard → App Settings → Notices**. There you also choose how they reach you: in your Pulse only (the usual), also by email as they happen, or also in one weekly email.

### How do I stop emails from Traversence?
Every email we send for a group, a business or your notices has **Stop these** at the foot: one tap stops that kind (notices go back to your Pulse only; a business's email stops from that business). Your mail app's own Unsubscribe button does the same. Emails about your account itself, such as sign-in codes and receipts for what you buy from us, can't be switched off. We never send to an address that bounced or marked us as spam.

### What happens to a group if its owner leaves?
Whatever its charter says: the group ends (the usual choice, with no elections), a member the owner named is offered it, the longest-serving moderator is offered it, or the moderators choose one of themselves. The steps that carry this out, and closing groups that have gone quiet for 30 days, are coming.

### What are a group's tags?
Up to 5 words that say what the group is about, under its topic: baking, cast iron, trail running. The owner and moderators set them, and existing tags are suggested as you type so spellings stay together. Tap one to find more groups like it; the Community page shows the popular ones for each topic. Tags help people find a group; they never rank it higher, and they're never taken from posts. A tag that might name a sacred or protected site waits for our team before it shows.

### What does "Places we're about" mean?
A group can name up to 10 places it goes to or talks about: towns, businesses, outdoor places and public landmarks, each with a short note ("planned for June"). They show on the group's page, and each place's page shows the group (under **Featured in**, or **Talked about by** on a town's page) with its name and member count, nothing more. Only the group's own choice puts it there; its posts are never read for it. If you run a business a group names, you're told once, and you can take your business off its list from the group's page.

### What's a chapter?
A branch of a larger group, for a place or a topic: *World Travelers* can have *World Travelers: White Mountains*, or *Cast Iron Cooks: Beginners*. A chapter has its own members, posts, moderators and lead, starts with the whole group's charter and tags, and shows on its place's page with "part of" its group. The group's owner opens chapters, or approves a member's request to start one; the person who leads it needs Verification. The group's charter says how chapters are joined: joining a chapter joins the whole group too, each chapter is joined on its own, or members of the whole group only. The group's owner and moderators can post to all its chapters at once and help moderate them. An existing local group can become a chapter when both owners agree, and a chapter can leave to stand on its own after 14 days' notice to its members. Closing quiet chapters and bringing them back are coming.

### How do I invite people to a group?
On the group's page, under **Share & invite**: tick connections from your Address Book and send. Each person gets one invitation from a group (again after 30 days if they don't answer), can say no thanks, and can switch group invitations off in App Settings. Someone who blocked you never gets one. The group's owner and moderators can also make **invite codes**: a link for a meeting, a class or a list, with an end date, that can be switched off at any time. Share and the QR code are under the group's name for anyone. Inviting a business's customers by email, flyers and badges for your own site are coming.

### Do I skip the approval queue if I'm invited?
Only if the group's charter says so. In a group that approves its members, the charter decides whether an invitation lets you straight in (from the owner and moderators, or from any member) and whether invite codes can. Otherwise your request goes to the moderators marked with who invited you. You always see the charter first and agree to it yourself. Some groups ask a few questions when you ask to join; only the moderators see your answers.

### Can anyone read a group's posts?
Only members, except for one: the group's owner can pin a **welcome** post that anyone can read, members or not, so visitors can see what the group does. The owner can also write a welcome message each new member gets when they join.

### How do I find groups near me?
Open **Community** from a place's page, or search for a place there. Groups come nearest first: those in that town or area, then nearby ones, then groups that talk about places nearby, and, if you picked a topic or typed a word, groups anywhere that match, marked "Anywhere". Groups with more active members come first within each; no one can pay to be shown higher.

### How does a group see how it's growing?
Whoever runs a group sees its page views and how many joined in the last 90 days, by how they came (the group's page, a place's page, search, invitations, invite codes, groups like it). Counts only: never who.

## Privacy and your account

### Does Traversence use cookies?
A few that the site needs: one keeps you signed in, one remembers your privacy choices, and one protects a business's question form from abuse when it's used without an account. Your browser also remembers things you set, like your place and recent searches, on your device only. Two optional kinds come from other companies, and only if you say yes: usage analytics, and videos from YouTube or Vimeo. The full list is in the [Privacy Policy](/privacy.php#cookies).

### What is "Usage analytics", and do I have to allow it?
It lets us count how Traversence is used (which pages are visited, searches that found nothing, what's hard to use) with an analytics service, so we can fix and improve it. It's off until you say yes, and everything works the same without it. We never sell what it shows us or use it for ads. You're asked once, at the foot of the page or when you create an account; change it any time on the [Privacy page](/privacy.php#choices) or in Privacy Settings → Your tools.

### Why does a video show a Play button instead of playing?
Videos come from YouTube or Vimeo, and once one plays, they can see your visit and set their cookies. So until you allow Videos, each one waits for you: tap Play to watch that one, or **Always play videos** to stop asking. Or open it on YouTube instead. Change it any time on the [Privacy page](/privacy.php#choices).

### Where do I change my privacy choices?
On the [Privacy page](/privacy.php#choices), signed in or not, or in Privacy Settings → Your tools when you're signed in. Signed in, your choices follow you to any device you sign in on.

### Can I sign in with Google?
Yes, and with Apple, Microsoft or Facebook too. Their buttons are under the email and password on the sign-in and sign-up pages (each shows once it's switched on). Each tells us only your name, your email address and an ID for your account with them, never your password or anything else in that account. Apple may give a "Hide My Email" address that forwards to you. If you already have an account with the same confirmed email, you're signed into it. If you're new, you finish signing up as everyone does: confirm you're 18 or older, choose about verification and privacy, and agree to the terms. With a work or school Microsoft account, we email you a link to confirm your address, the same as signing up with a password. There's no password to choose; to sign in another way too, use **Forgot password?** to set one. To disconnect one, or to have your data deleted, see [Deleting your data](/data-deletion.php).

### Does signing in with Google, Facebook or Microsoft connect my account to Traversence?
No. Signing in only tells us who you are. Connecting a platform so you can bring your business details, events or products in and manage them here in one place is a separate step, asked for only when you use it and only for what it needs. That's coming.


### A word means two things. Which one does search use?
Both, when it can't tell. "Tubing" offers tubing on the river and snow tubing first, then pipe and plumbing suppliers. The words around it decide when they can: "snow tubing" is the ski areas, "river tubing" the rivers, and "copper tubing" or "pvc tubing" only pipe. If a word you search for picks the wrong meaning, tell us with **Suggest it**, or with the Feedback button; that's how search learns its other meanings.
### How do I delete my account?
Go to **Dashboard → Privacy → Delete my account** (or [Delete my account](/user/delete-account.php)). It shows exactly what will happen first. To make sure it's you, you need to have signed in within the last 15 minutes, and you type DELETE to confirm. Your account closes straight away: you're signed out everywhere, and your profile and what you posted are hidden. It's deleted for good after 30 days. Until then you can restore it, exactly as it was, from the link in the email we send, or just by signing in. If you'd rather not wait, tick "Delete it right away instead". When it's deleted, your profile, address book, connections, saved places, settings, likes and sign-ins are gone; what you wrote for others (journeys, stories, posts and comments) is erased, and messages you sent show "[Deleted]". A business listing you run stays on the site for the business, back to unclaimed. An admin, or the owner of a group with other members, hands those over first. Can't sign in? Email support@traversence.com; more on [Deleting your data](/data-deletion.php).

### I signed in with Microsoft (or Google, Apple, Facebook) and it asked me to sign up. I already have an account.
That happens when the email on that account is different from the one on your Traversence account, so we can't tell they're the same person. On the page that asks you to finish signing up, choose **Sign in to link it** and sign in to the account you already have: the two are linked, and from then on either one signs you in. Already signed in? Go to **Dashboard → Privacy → Ways to sign in** and choose **Connect**. You can disconnect any of them there too.

Right after you sign in, a strip under the bar at the top of the page tells you how it went: green, "Google is now linked
to your account", or red, with the reason it couldn't be linked (most often, your account already has a different Google
account linked: one of each per account) and a **Ways to sign in** link to fix it. A sign-in that isn't linked asks again
next time.

### Does Traversence use Google's information about businesses?
Only to check our listings. Our crawler asks Google whether it knows a listed place, and if Google's place has the same name and street address, we keep Google's ID for it, nothing else (Google's terms don't let us copy its hours, photos or reviews). When Google lists a place as permanently closed, a person on our team checks before anything changes; nothing is closed on Google's word alone. Places whose address is kept private, such as shelters, are never sent to Google.

### How long do I stay signed in?
Until you sign out, or close your browser. A break, even a long one, doesn't sign you out. On a phone, the browser usually stays open in the background, so you stay signed in for days; close it fully, or tap **Sign out**, to end it. If you go 30 days without using Traversence, you'll be asked to sign in again.

### How do I change my name or profile?
Go to your **Dashboard** and choose **Profile** (under Settings), or tap your name at the top of the menu and choose **Your profile**. There you can:
- set your **display name**, the name people see on your journeys, comments and messages;
- edit your **contributor bio**, if you're a contributor;
- make your profile **public** or **private**.

**See your public profile** shows you what other people see.

### What shows on my public profile?
Only what you publish. Your dashboard opens on your profile: a cover photo, your card (photo, name, @handle, status) and your details (where you live, languages, a mantra, work, education and more). Fill in whatever you like with the pencils. Each item has an eye: **green means public**, plain means only you see it. Nothing you add is public until you switch on its eye. Your name always shows. **See it as others do** opens your profile as a visitor sees it. On a phone your details start folded away so your Pulse is near the top: tap **Details** in your card to open them (we remember your choice on that device).

### What is the Pulse?
Everything coming in, in one place: messages, your groups and connections, and news from the places, businesses and sellers you link. Each source has a pill with its count; tap one to see only that, tap it again to see everything. The bell shows what needs you, and the gear sets how the Pulse looks (a list, one stream, or a tab per source) and which sources it shows. **Pulse ▾** switches between your accounts: personal, a business you manage, or staff.

### What can I do with an item in my Pulse?
Tap ▾ to open it in place: its photos, the full text and a comment box. The chain icon goes to where it came from. Reply, forward, pin, report, move to a folder and add to a collection are on each row, and commenting, attachments and Publish, Save as draft or Schedule are in the open item. Most of these are coming: for now they show where they'll be.

### Why don't the crawler's findings show in the admin's Pulse?
The admin's Pulse (Support) lists messages from people: visitors, members and our own calls. What the crawler finds by itself (a changed phone or hours on a listing's own website, a closing, two listings that look like one business) waits in **Review** for the review checkers, and doesn't count toward **Needs you**. Checkers that settle these by themselves are coming; until then they wait in Review. If the crawler's own findings pile up (300 waiting, or 100 in an hour), one System case says so.

### Where are all my photos?
In your **Gallery** (the camera in your menu, or the **Gallery** tab of your dashboard, which shows your newest 12 and your albums with **Open your gallery** for the rest): photos and videos you uploaded, your profile and cover photos, and the photos in your journeys, grouped by when they were taken. Tap one to see it full size: swipe or use the arrows, pinch to zoom, and close it with ×, Esc or a tap on the dark background. Its ⋯ menu edits the caption, alt text and date of your own photos, saves it to your phone or computer, or shares it outside Traversence. Visitors to your profile see only what you've shared: your public albums and published journeys.

### What are posts, and why do they disappear?
A post is whatever's on your mind: words, photos, a video, or all three. Write one with **What's on your mind?** at the top of your Dashboard or your Posts tab. Every post is a Moment: it lasts **3 days** (or **7 days**, if you choose that when you post, or later from its ⋯ menu) and is then deleted, with its photos, videos, reactions and comments, unless you **Keep** it. A day before it ends we tell you in your Pulse, so you can keep it. Moments keep your feed current and mean less of your life sits on a server. Posts show in your **Pulse** with everything else coming in: posts from you and the people you follow or are connected with under **Community**, posts from businesses you've linked under **Listings**. Tap ▾ on one to open it right there, with its photos or video, reactions and comments.

### How do I keep a post?
Tick **Keep** when you post, or tap **Keep** on the post (or in its ⋯ menu) any time before it ends. A kept post stays on your profile, and its photos and videos go into your **Gallery**, in an album called Kept Moments (private until you share it). A video from a post you shared with **Public** goes to your **Channel** instead: the **Videos** tab on your profile. Kept photos and videos count toward your storage; Moments don't.

### Who sees my posts?
You choose for each post: **Public** (anyone, on or off Traversence), **Followers** (people who follow you, and your connections), **Connections** (only people you're connected with) or **Only me**. New posts start with your default, which is Connections until you change it on your Posts tab. If your profile is private, Public works like Followers. Someone you've blocked, or who blocked you, never sees your posts. Your followers and connections see your posts in their Pulse, under **People you follow**, newest first: nothing is boosted or sold, and there are no ads. To send one straight to people instead, see "What's a Snap?" below.

### What's a Snap?
A post sent straight to people instead of your feed. In **What's on your mind?**, add people or one of your groups on the **To** line, and the button becomes **Send**; tick **Also post to my feed** to do both (**Post & send**). On someone's profile, **Snap** opens it already addressed to them. It arrives in their messages as a photo or video tile with your words, and they can reply in the same conversation. A Snap stays between you: only you and the people you sent it to can open it, and it can't be shared on. Like any post it lasts 3 or 7 days; either of you can **Keep** it (it goes into the Gallery of whoever keeps it), and the conversation says who kept it. You see when it's been opened ("Opened", or "Opened by 2 of 3" in a group). Who you can send to follows their message settings: someone you haven't linked or connected with may get it as a message request, and someone who only takes messages from people they know is greyed out with the reason.

### What's on my Videos tab?
Your **Channel**: the videos you kept from posts shared with **Public**, newest first, and **Playlists**, your albums that have videos in them (only the public ones show to visitors). Share the tab with its short link, or download its QR code to print. A business's videos show the same way on its listing page, under **Videos**. Your Channel is an album in your **Gallery**: make it private there and only you see it. Videos you kept from posts shared with fewer people stay in your private Kept Moments album.

### How much storage do I have?
**2 GB** on the free Personal plan, **25 GB** on Personal Plus and **50 GB** on Personal Pro, plus any storage packs, plus what you've earned. Your Gallery counts: photos and videos you uploaded or kept. Moments don't count until you keep them. When something won't fit, we show your choices once: a bigger plan, a storage pack (+25 GB for $2.95 a month, on a paid plan), or choose what to clear in your Gallery. Nothing already there is ever removed.

### Can I earn more storage?
Yes, free, up to **25 GB**: **1 GB for every friend who joins** with your invite (from **Contacts** in your Address Book, or **Invite** on the To line), and **1 GB for every 500 followers**. A friend or follower counts once they're a settled member: email confirmed and 18 or older, their account at least 30 days old, and on Traversence on at least 3 different days; someone you've blocked or who's been suspended doesn't count. You can earn up to 5 GB a month, and what you've earned stays even if followers leave. See yours under **Earned storage** on your Plans page; it's counted every day.

### What's in the Shop?
Everything Traversence sells, in one place, at **/shop/** (**Shop** in the cart's side menu, under Cart): for you, Personal Plus and Pro, storage packs and GO Codes; for a business you're acting as, its plans, storage and AI packs, GO Codes, White Glove, and design, video, print and signs (ask for a quote). **Add to cart** puts a plan or a pack in the same cart as your GO Codes, and you pay for all of it with one card entry. A plan that starts keeps your card on file for its renewals; a change of plan, or packs added to a plan you already pay for, go on the card on file. Keeping a single video in 4K ($0.99) is in a video post's ⋯ menu and goes in the same cart. **A month of Personal Pro** ($9.95, paid once) is in the Shop too: Pro for a month with no card kept and nothing renewing; another month bought before it ends adds on. Coming: creator collaborations and licensing for businesses, and email, text and push packs. Without an account, the Shop shows GO Codes and what a free account adds.

### Can I try Personal Pro for free?
Yes, once: **Try Pro free for 7 days** on your Plans page, in the Shop, or when you reach for more (the 2-minute recording limit, a full Gallery). No card and nothing charged: you get Pro's 50 GB, 10-minute videos and uploads up to 1 GB for a week, then it goes back to the free plan on its own unless you keep it (add a card and choose **Keep my plan**). AI Assist credits come with a paid plan, not the free week. It's for Verified members (email confirmed, 18 or older), one free week per account.

### Can my business post?
Yes. If you're on a business's team with Catalog & content to edit, **What's on your mind?** shows **Post as**: choose the business, and the post shows its name and links to its page. A business's posts show on its listing page, under **Posts**, and in the Pulse of everyone who linked it; choose **Public** or **People who linked it**. They last 3 or 7 days like any post, or Keep them into the business's Gallery (its plan's storage). A business doesn't send Snaps: it reaches people through its Messages, when they've chosen to hear from it. A business sees how many saw or reacted to its posts, never who.

### How do I send to someone who isn't on Traversence?
On the **To** line, type their name: if no one by that name is here, **Invite “name” to Traversence** asks for their email or phone. By email, we send them a link to join; by phone, you get a message and link to send them yourself (we don't send texts). Once they join, you're asked to connect, and they show on the To line. You can also invite from **Contacts** in your Address Book.

### Can people see that I looked at their post?
On a post, its poster sees **Seen by** with a number. They see your name only if you're linked: you're connected, or one of you follows the other. Anyone else is counted, never named. Who reacted works the same way. Nowhere else on Traversence shows who looked at something.

### How long can a video be, and how many can I post?
Up to **2 minutes**. Tap **Record** and choose the frame: **Portrait** (9:16, for phones), **Square** or **Landscape** (16:9). What's inside the frame is exactly what's recorded, and the phone remembers your choice. Zoom with two fingers on the picture, or tap **1×** for 2× and 3×, before or while you record. The switch-camera button works while you record too: the clip carries on from the other camera, sound and all. Where your phone's browser offers the camera's own zoom (Chrome on most Android phones) it stays sharp; elsewhere (iPhones, most front cameras) the picture is enlarged, so it softens as you zoom, up to 3×. Tap the red button to start and again to stop (the ring counts down from 2:00 and stops by itself at 0:00). Then watch it back and choose **Use video** or **Retake**; × closes it, and asks first if you'd lose a recording. It records at a phone-friendly size as it goes, so it sends quickly. A video from your phone can be up to 2 minutes and 25 MB. On **Personal Pro**, and when you post as a business, videos can be up to **10 minutes** and uploads up to 1 GB; when the ring reaches 0:00 on another plan, we offer Pro once, beside **Keep my 2 minutes**. You can post **5 photo or video posts a day** (2 a day in your first week), with up to 25 up at once; words-only posts don't count. At the limit, delete one of your active posts to make room, or keep the ones you want to stay (kept posts don't count). A video bigger than 720p gets a 720p copy for feeds, so it plays quickly everywhere. On **Personal Pro** (and a business's posts) the original is kept too: **Watch in 4K** (or HD) on the video plays it. When you keep a post, its video is kept at your plan's size: 720p on Personal, 1080p on Personal Plus, the original on Personal Pro. To keep one video at full size without a plan, choose **Keep in 4K · $0.99** in its post's ⋯ menu: it goes in your cart, and once paid the post is kept with its original video (and **Watch in 4K** plays it). It's for videos bigger than 720p, before the post is kept. On free accounts, video can pause until the 1st if the month's budget for them runs out; photos and words carry on, and the page tells you when.

### What are the reactions?
Like, Love, Care, Haha, Wow, Sad and Angry. Tap **Like** to choose one; tap the same one again to take it off, or another to change it. A post shows how many of each.

### What happens to a post that's reported, or deleted?
Report a post from its ⋯ menu; the person isn't told who reported it. Our team looks at it. A post is hidden while it's looked at after three reports, or at once if it shows someone's private information or a sacred place, or puts someone in danger. When a post is reported we keep a small copy of it until the report is decided, and for 90 days after, even if the post ends or is deleted, so a decision can be checked; it's never shown or used for anything else. We may have to keep it longer if the law asks us to. Otherwise a deleted or ended post is gone for good; we keep only a line saying a post existed and when, never what it said or showed.

### What are the tabs on a profile?
Quick ways into each tool: **Dashboard** (your profile with your Pulse under it, where your account opens; tap it to come back from any other tab), **Posts** (what you've posted, and on someone else's profile what they share with you; a profile opens on it), **About**, **Contacts** (your private Address Book, only you see it), **Gallery** (for you, every photo you've uploaded; for visitors, the photos from your published journeys), **Connections** (how many people follow you, if you publish it), **Journeys**, and **Check-ins**, **Events** and **Reviews**, which are coming. Visitors see the tabs for what you share.

### How do I frame my profile photo?
Tap the pencil on your photo, then **Reposition and size**. Drag the photo to move it inside the square, and use the slider (or + and −) to make it bigger or smaller. We keep a private, resized copy of the photo you chose, so you can reframe it later without uploading it again. When you remove the photo, that copy goes too. The cover photo drags up or down the same way.

### Can I make all my photos public at once?
Yes. When you add or change a photo, tick **Make all my photo uploads public**. We remember it, and each new photo starts out public. You can still hide any one photo, and untick the box to go back to choosing each time.

### Can people look at my profile photos?
Yes, if you've made them public. On your public profile, a tap on your cover or profile photo opens it full screen with your name, likes, comments and Share; on a phone, swipe up from the photo to its comments, and drag the photo down onto the × to close it. Liking, commenting on and sharing photos are coming. To change a photo, use the pencil on it in your dashboard.

### Why do I show as "Member #" and a number?
You haven't chosen a display name yet. We never show your email, so until you pick a name, people see a member number. Set one under **Profile**.

### What names can I use?
Any name from 2 to 40 characters, using letters, numbers, spaces and simple punctuation. Leave out phone numbers and email addresses. Names that suggest you speak for Traversence, such as "Traversence", "Admin", "Staff" or "Support", are reserved.

### How do I see my profile as others do?
On your profile, under your details, tap **See it as others do**. You see it as a visitor would, with none of your own tools, and you can switch between **Anyone**, **A follower** and **A connection** to check who sees which posts. The buttons visitors get (Follow, Connect, Message, Snap) show as a preview there; they do nothing on your own profile.

### What's the difference between a public and a private profile?
- **Public:** anyone can see your name and your journeys, and members can follow you.
- **Private:** people must send you a connection request instead of following, and you can't publish journeys, because journeys show your name.

Either way, your email and your location are never shown.

### What does Verified mean?
A **✓ Verified** mark on someone's profile means their email is confirmed (with the link we sent them) and they told us
they're 18 or older. That's all it takes, and it happens when you confirm your email at sign-up: there's no separate
question. We never search for anything more about anyone. A business is checked on its own, against its website and
public records, when its owner claims it; checking a phone with a texted code is coming, and starts only when you ask for
the code.

### Do I have to be verified?
Everyone who confirms their email is. Browsing, searching, saving, commenting and messaging need nothing more. Writing
as a contributor, claiming a business, starting a community and staff work need a confirmed email; claiming a business
also checks the business itself, which starts when you tap to claim it.

### Who can see my email?
No one on the site: your email is never shown on Traversence. Traversence staff can see it only to verify your
account, or to contact you officially when we can't reach you on Traversence itself, and only when it's truly
needed. Each time they look, it's recorded.

### Why is there a "verify you're human" check when I sign in?
It stops bots from guessing passwords and making fake accounts. It's Cloudflare Turnstile: usually it passes on its own in a second, with no puzzle to solve. If you press the button before it's done, the form waits for it (a few seconds at most) and tries it again on its own if it stalls; you don't need to do anything. If it still can't finish, reload the page, or turn off any ad or script blocker for this site, or sign in with Google, Microsoft or Facebook instead. It's on the sign-in, sign-up and "forgot password" forms (signing in with Google, Apple, Microsoft or Facebook skips it, since they check already). It isn't used for ads.

### How is the Traversence team's access protected?
Anyone on our team who can use the admin side signs in in two steps: their password (or Google and the others), then a 6-digit code we email them, before any admin page opens. Every code we email (signing in, claiming or adding a business) puts the code first in the subject, so Gmail offers Copy code and a phone can fill it in for you; in the email it's shown once, large, in a box that selects with one click. A sign-in code also has **Sign in with this code**: it opens the sign-in page with the code filled in, and you tap Sign in. It works in the browser where you started signing in; anywhere else the page says so, and signing in there sends a new code. They can trust their own browser for 30 days, and changing their password makes every browser ask again. Two-step sign-in for business owners is coming, before businesses can connect payments.

### Does Traversence have a password vault?
Our own team has one now: the logins for the outside services we use are kept in a vault that only its owner's browser can open. Each password is sealed (encrypted) in the browser before it's saved, so what we store can't be read by anyone at Traversence, or by anyone who got into our server. Setting it up takes five short steps: the device's passkey (fingerprint, face or PIN); a vault passphrase, which isn't a password (it never leaves the browser, so it has its own rules: four or more words, or 20 characters, hard to guess, and used nowhere else; the page can suggest one); the recovery words; and two recommended extra checks, an authenticator app (whose code is then needed to add a device or use the recovery words) and a spare passkey or security key. Opening a password takes the passkey and the passphrase; each password opens only for its exact sign-in page; and every password opened is emailed to its owner with a link to lock the vault. If you lose your devices or passphrase, 24 recovery words you saved at the start (printed or downloaded, never emailed) get you back in, once: using them makes new ones. You type three of them back from your saved copy before they're kept, so a mistyped kit is caught at the start. We keep nothing that could open a vault, so lost words with no other device means the vault can't be opened, by anyone. A vault for members and businesses is coming, only if you choose it and agree to its terms, alongside 1Password through us or the password manager you already use. Our team also has a browser extension for Chrome and Edge: connected from the vault for up to 12 hours (the key stays in the browser's memory, gone when the browser closes or the vault is locked), it lists the saved logins under a site's sign-in box only on that exact site, so a look-alike site gets nothing, fills the one picked, and after a sign-in offers to save it or update the saved password. A public version for members and businesses comes with their vault. The vault page's bar across the top shows how long it stays open, with Close and Lock at its end: after 5 minutes unused it asks if you're still there and closes 2 minutes later, like a bank's sign-in. Reloading the page keeps it open (in that tab only, for that time); leaving by a link asks first, since leaving closes it, and closing the tab ends it. A connected extension shows how long it has left. The extension keeps its connection for 12 hours or until the browser closes, in every tab; every 30 minutes it checks with the vault and lets go at once if the vault was locked or it was disconnected. When it isn't connected, its Connect button opens the Vault page, and unlocking brings you back to the tab you were on, connected. On a sign-in that asks for the email first, Fill puts in the email and then the password when the next screen asks for it. In a new-password box it offers a strong password (within the length the page states), and after a password change on a page with no user name it asks which saved login the new password is for. The vault opens three ways: with the passphrase, with the authenticator app's code, or with a code emailed to the email on the account; the second and third are then finished by the device's own PIN, fingerprint or face (or a phone or security key), whose secret never leaves the device, so a code alone opens nothing. PIN unlock turns on for a computer the first time the vault is opened there with the passphrase, and can be turned off under Devices. Its owner chooses what the vault emails and how often (its Emails button): passwords opened, logins the extension saved, the extension connected, and the vault unlocked after a lock can each be emailed each time, the first time each day, in an hourly or daily summary, or not at all (always kept in the vault's own record). Each email, summaries included, says who did each thing: the person and the staff login, or the extension and who connected it. What would show someone else in the vault (devices, recovery words, the authenticator app, a lock, many deletes, and changes to these settings) is always emailed at once. The extension downloads from the vault page, with its install steps for Chrome and Edge.

### What can Traversence staff see about my account?
We don't look at accounts unless there's an issue or you ask us for help. When we do, staff say why before they
open yours (a report, your request, a claim, a check), and that's recorded with their name. What they see is the
basics from your sign-up: your display name, when you joined, whether your email and age are confirmed, whether
you're Verified, the roles you hold, and the privacy choices you made. Your email and phone stay hidden unless they're
needed to contact you, and showing them is recorded separately. No one, in any role, can see your private
messages, your Address Book or your contact cards.

### How will Traversence contact me?
On Traversence: through your notifications, your Pulse and a notice at the top of the page. We use your email or
phone only for official contact when we can't reach you here (for example, if you can't sign in), and only when
it's needed. If you contact us for help or sales, we reply to you, or to the contact you name, about what you asked.
A business's address is used only for that business (claiming it, or confirming it); we don't ask members for a
postal address.

### Can my account be limited or revoked?
Yes, for breaking the [posting guidelines](#posting-guidelines-and-safety) or misusing the site. You always hear from
us first, on Traversence, with what happened and the steps to put it right:
1. **Warning.** You have 24 hours to confirm you'll follow the steps, or to ask for a review.
2. **Limited, with a final warning.** If we don't hear from you, you can still browse, but you can't post, comment or
   send messages. You have 24 more hours.
3. **Access revoked.** If there's still no reply, you can't sign in. We email you what happened, how to recover, and
   a link to ask for a review.

Something serious (threats, scams, sharing someone's private information) goes straight to step 3. Asking for a
review at any step stops the clock until a person at Traversence has looked at it, and they reply by email. Your
posts aren't deleted at any step. Your notice is at [Your account notice](/user/notice.php). If you can't sign in,
you can get the review link sent again there.

### What lowers my standing?
Mostly, something you posted being taken down after people reported it. Each one lowers your account's trust score,
and when the score drops too low, a warning opens on its own. Confirming your email raises it. A take-down that's
reversed gives it back.

### Can anyone read my private messages?
No. No one at Traversence, in any role, can read your private messages or your contact cards.

### What does AI Assist do?
It helps you write: a caption, a paragraph for your journey, a few lines for a post, or an answer to a question about a place or a subject. Ask about anything, from **AI Assist** in the menu (on its own, or under a topic you've chosen) or with the **✦ AI Assist** button under the story box when you write a journey or an experience, where **Insert** puts what it wrote into your story. It writes only from what we've researched (historic records, public sources and our guides), never from guesses, and shows how many of our facts it used. When we don't know enough yet, it says so and sends the subject to our research queue; when our research learns something (within 45 days), it writes your answer again and emails you, and the ask shows **Answer ready**. Every ask and answer is kept under **Your asks** on the AI Assist page, with **Copy**, and only you see them. The subjects people ask about in a place (the subject only, counted, never your words or who asked) help decide what that place's guide covers. What you ask goes to our AI provider only with **AI Assist & Learning** turned on, and is never shown to anyone else. AI Assist comes with a paid plan: **Personal Plus** or **Personal Pro**, or any paid plan on a business you own (its owners share the business's credits). You get 3 free asks a day (the AI Assist page shows how many are left), then each ask uses one **AI Assist credit** from a plan you pay for (Personal Plus has 10 a month, Personal Pro 25, a business plan 10 to 500, and a +50 pack adds more on the Plans page). A follow-up answer costs you nothing. Your own plan's credits are used first; when you have more than one, you choose which pays. The page shows what's left on each. There's also a monthly limit on what your asks may cost, set by what your plans pay; if you reach it, it's back on the 1st, or a +50 credits pack (or a bigger plan) raises it at once. A trial includes AI Assist from its first payment, and an ask that couldn't be written costs nothing. It never says where a sacred, burial or archaeological place is.

### Why does search suggest topics as I type?
When the words match a topic our guides cover (a river, a trade, a town's history), it's offered under **From our guides**, and search results show the facts from our guides that your words name. What people search for and don't find helps decide what we research next (counts only, never who searched).

### Does Traversence use AI on what I write?
Only if you turn it on. **AI Assist & Learning** is off until you switch it on in Privacy Settings. Private messages and contact cards never enter shared learning, whatever you choose. [Our approach](/our-approach.php) has the details.

### Do you sell my information or show me targeted ads?
No. We don't sell or rent your information, share it for advertising, target ads, or track you around the web. [Our approach](/our-approach.php) explains what we never do, and the [Privacy Policy](/privacy.php) says exactly what we collect and why.
