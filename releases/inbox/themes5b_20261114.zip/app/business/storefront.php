<?php
// app/business/storefront.php — the business portal's Storefront & pages (decisions/0139, the Marketplace's step 5a).
// Core and up (Plan 'storefront'). Its shop name on trvgo.us, its look (one of the brand's ready themes, its logo and
// cover, an accent color), a tagline and a few lines about it, its pages (SitePages, owner = the listing), Go live and
// Pause, a preview link for its team while it isn't live, and a parent brand for a location. Its own domain comes next
// (step 5b: buy one through us, or bring one it owns).
// Seeing and changing it needs Storefront & theme (edit); going live or pausing, Publish (edit); photos, Catalog &
// content (the gallery's own rule). What a role can't do is greyed with the reason.
// Storefront Studio (decisions/0159 step 5a): each page opens in the builder (?edit=<page id>), the editor of our own pages
// on its zone "shop.<page id>" (app/lib/Blocks.php): Save draft for Storefront & theme, Publish and Roll back for Publish,
// no approval (0158 §3). Until it's edited there, a page's Markdown is its one text block; the Markdown is kept as it was.
declare(strict_types=1);

require_once __DIR__ . '/../lib/Storefront.php';
require_once __DIR__ . '/../lib/SitePages.php';
require_once __DIR__ . '/../lib/Team.php';

function tv_biz_storefront(PDO $main, array $ctx, int $uid): string
{
    $e = 'tv_w_e'; $id = (int) $ctx['id'];
    if (!Storefront::ready($main)) return '<div class="ak-card tv-bleed"><p data-tv-status="info" data-tv-label="Coming:">Storefronts open once their database update has run (it runs by itself within the hour).</p></div>';
    [$canEdit, $whyEdit] = tv_biz_can($main, $ctx, 'storefront', 'edit');
    $canPub = Team::can($main, $uid, $id, 'publish', 'edit');
    require_once __DIR__ . '/../lib/Gallery.php';
    $canPhoto = Gallery::canManage($main, $uid, 'businesses', (string) $id);
    $role = Team::roleName($ctx['role']);
    $dis = fn (bool $ok, string $why) => $ok ? '' : ' disabled title="' . $e($why) . '"';
    $noEdit = 'Your role (' . $role . ') can\'t change the storefront.';
    $sf = Storefront::get($main, $id);
    $h = '';
    if (!$sf) {
        return $h . '<div class="ak-card tv-bleed"><h2 class="ak-h" style="margin-top:0">Your storefront on trvgo.us</h2>'
            . '<p class="ak-note">Your own shop at its own address, <b>trvgo.us/your-name</b>: your published items, your pages, how to reach you, in your colors. It shows what you already have on Traversence, so there\'s nothing to copy; buying and messages stay on Traversence. You can connect your own domain next.</p>'
            . '<button type="button" class="ak-b go" data-sf="start"' . $dis($canEdit, $noEdit) . '>Set up my storefront</button></div>' . tv_biz_storefront_js($id);
    }
    $url = Storefront::url($sf);
    $live = $sf['status'] === 'live';
    if (isset($_GET['edit'])) return tv_biz_storefront_page($main, $ctx, $uid, $sf, (int) $_GET['edit'], $canEdit ? '' : $noEdit, $canPub);
    $preview = $url . '?preview=' . Storefront::previewKey($id);
    $h .= '<div class="ak-card tv-bleed"><p data-tv-status="' . ($live ? 'ok' : 'info') . '" data-tv-label="' . $e(Storefront::STATUSES[$sf['status']] . ':') . '">'
        . ($live ? 'Your storefront is open at <a class="underline" href="' . $e($url) . '" target="_blank" rel="noopener">' . $e(preg_replace('#^https?://#', '', $url)) . '</a>.'
            : ($sf['status'] === 'paused' ? 'Paused: visitors see that the shop isn\'t open right now. Your team can still look through the preview.' : 'Only your team sees it, through the preview, until you go live.')) . '</p>'
        . '<div class="ck-row"><a class="ak-b" href="' . $e($preview) . '" target="_blank" rel="noopener">' . ($live ? 'Open it' : 'Preview') . ' ↗</a>'
        . ($live ? '<button type="button" class="ak-b" data-sf="pause"' . $dis($canPub, 'Your role (' . $role . ') can\'t publish.') . '>Pause</button>'
            : '<button type="button" class="ak-b go" data-sf="live"' . $dis($canPub, 'Your role (' . $role . ') can\'t publish.') . '>Go live</button>') . '</div>'
        . '<p class="ak-note">The preview link works for 7 days; open it again from here for a fresh one.</p></div>';

    // ---- the name and the look
    $h .= '<form id="sf-form" class="ak-card tv-bleed"><h2 class="ak-h" style="margin-top:0">Its name and look</h2>'
        . '<label class="ck-l">Shop name: trvgo.us/<b data-sf-slug>' . $e($sf['slug']) . '</b><input class="ak-in" name="slug" maxlength="40" value="' . $e($sf['slug']) . '" autocapitalize="none" spellcheck="false"' . ($canEdit ? '' : ' disabled') . '></label>'
        . '<p class="ak-note">Letters, numbers and hyphens. Six letters alone read as a GO Code, so add a letter or a hyphen. Changing it changes your address: links to the old one stop working.</p>'
        . '<fieldset class="sf-th"><legend class="ck-l">Theme</legend>';
    foreach (Storefront::THEMES as $k => [$name, $bg, $card, $ink, , , $acc]) {
        $h .= '<label class="sf-t"><input type="radio" name="theme" value="' . $k . '"' . ($sf['theme'] === $k ? ' checked' : '') . ($canEdit ? '' : ' disabled') . '>'
            . '<span class="sf-sw" style="background:' . $bg . ';border-color:' . $card . '"><i style="background:' . $card . '"></i><i style="background:' . $acc . '"></i><i style="background:' . $ink . '"></i></span>' . $e($name) . '</label>';
    }
    $h .= '</fieldset>'
        // the theme is the pages' starting style (decisions/0159 step 5b): blocks carry no colors or fonts of their own
        . '<p class="ak-note">The theme is also your pages\' starting style: in the builder and on your storefront, their headings, words, buttons and the two section backgrounds ('
        . $e(implode(', ', array_map(fn ($k) => Storefront::THEMES[$k][0] . ': ' . Storefront::THEME_STYLE[$k][3][0] . ' and ' . Storefront::THEME_STYLE[$k][4][0], array_keys(Storefront::THEMES))))
        . ') follow it and your accent color. Change either and every page follows; nothing on a page needs redoing.</p>'
        . '<label class="ck-l">Accent color (buttons and links; blank uses the theme\'s)<span class="sf-ac"><input type="color" data-sf-pick value="' . $e($sf['accent'] ?: Storefront::THEMES[$sf['theme']][6]) . '"' . ($canEdit ? '' : ' disabled') . '><input class="ak-in" name="accent" maxlength="7" placeholder="' . $e(Storefront::THEMES[$sf['theme']][6]) . '" value="' . $e($sf['accent']) . '"' . ($canEdit ? '' : ' disabled') . '></span></label>'
        . '<label class="ck-l">Tagline (under your name)<input class="ak-in" name="tagline" maxlength="160" value="' . $e($sf['tagline']) . '"' . ($canEdit ? '' : ' disabled') . '></label>'
        . '<label class="ck-l">About (a few lines at the top of the shop)<textarea class="ak-in" name="about" rows="4" maxlength="1500"' . ($canEdit ? '' : ' disabled') . '>' . $e($sf['about']) . '</textarea></label>'
        . '<label class="ck-l">A location of another shop? Its shop name (blank if not)<input class="ak-in" name="parent" maxlength="40" value="' . $e((string) ($sf['parent_slug'] ?? '')) . '" placeholder="the brand\'s shop name"' . ($canEdit ? '' : ' disabled') . '></label>'
        . '<p class="ak-note">A location shows under its brand: trvgo.us/brand/location, and on the brand\'s storefront. You need to be on both teams.</p>'
        . '<button class="ak-b go"' . $dis($canEdit, $noEdit) . '>Save name and look</button></form>';

    // ---- the logo and cover
    $h .= '<div class="ak-card tv-bleed" id="sf-photos"><h2 class="ak-h" style="margin-top:0">Logo and cover</h2>'
        . '<p class="ak-note">A square logo beside your name, and a wide cover photo across the top. Each opens your Gallery: pick one of your photos, or upload a new one (it\'s kept in the Gallery too and counts toward your plan\'s storage). The cover can also be a stock photo, labelled as one; the logo is always your own.</p><div class="sf-pp">';
    foreach (['logo' => 'Logo', 'cover' => 'Cover'] as $w => $label) {
        $cur = Storefront::photoUrl($main, $sf[$w . '_id'] ? (int) $sf[$w . '_id'] : null);
        $h .= '<div class="sf-p"><b>' . $label . '</b><span class="sf-im sf-' . $w . '"' . ($cur !== '' ? ' style="background-image:url(\'' . $e($cur) . '\')"' : '') . '>' . ($cur === '' ? 'None yet' : '') . '</span>'
            . '<label class="ak-b"' . ($canPhoto ? '' : ' aria-disabled="true" title="' . $e('Your role (' . $role . ') can\'t add photos (it needs Catalog & content).') . '"') . '>Choose a photo<input type="file" accept="image/jpeg,image/png,image/webp" data-sf-up="' . $w . '" data-art-b="' . $id . '"'
            . ($w === 'cover' ? ' data-art-slot="storefront_cover" data-stock-post="/business/api/' . $id . '/storefront" data-stock-action="stock_cover" data-owner="' . $id . '"' : '') . ' hidden' . ($canPhoto ? '' : ' disabled') . '></label>'
            . ($cur !== '' ? ' <button type="button" class="ak-b no" data-sf="photo" data-which="' . $w . '" data-item="0"' . $dis($canEdit, $noEdit) . '>Remove</button>' : '')
            . ($w === 'cover' && $cur === '' ? tv_biz_storefront_stock($main, $id, $canEdit, $noEdit) : '') . '</div>';
    }
    $h .= '</div>';
    // choosing one of the business's own photos is the Gallery panel's Your gallery tab (js/tv-art.js), the one way to choose art
    $h .= '</div>';

    // ---- its pages
    $pages = SitePages::all($main, $id);
    $h .= '<div class="ak-card tv-bleed" id="sf-pages"><h2 class="ak-h" style="margin-top:0">Your pages</h2>'
        . '<p class="ak-note">About, Services, FAQ, Hours… Each live page is a tab on your storefront at trvgo.us/' . $e($sf['slug']) . '/its-address. <b>Edit the page</b> opens it in the builder: sections, columns, headings, words, pictures and buttons, a draft only your team sees, then Publish. Or write it here in plain text: ## for a heading, - for a list, **bold**, [a link](https://…), ![a picture](https://…).</p>';
    require_once __DIR__ . '/../lib/Blocks.php';
    foreach ($pages as $p) {
        $bz = Blocks::state($main, 'shop.' . (int) $p['id']);
        $bl = $bz['live_version'] ? 'Built, version ' . $bz['live_version'] . ($bz['draft'] !== null ? ', a draft waiting' : '') : ($bz['draft'] !== null ? 'A draft in the builder' : '');
        $edit = '<a class="ak-b go" href="' . $e(tv_biz_url($id, 'storefront') . '?edit=' . (int) $p['id']) . '">Edit the page</a>';
        $look = $p['status'] !== 'hidden' ? '<a class="ak-b" href="' . $e($url . '/' . $p['slug'] . '?preview=' . Storefront::previewKey($id)) . '" target="_blank" rel="noopener">Preview ↗</a>' : '';
        $h .= '<details class="sf-pg"><summary><b>' . $e($p['title']) . '</b> <span class="bz-pill">' . $e(SitePages::STATUSES[$p['status']]) . '</span>' . ($bl !== '' ? ' <span class="bz-pill">' . $e($bl) . '</span>' : '') . ' <small>/' . $e($p['slug']) . '</small></summary>'
            . '<div class="ck-row">' . $edit . $look . '</div>'
            . '<form class="sf-pf" data-page="' . (int) $p['id'] . '">'
            . '<label class="ck-l">Title<input class="ak-in" name="title" maxlength="120" value="' . $e($p['title']) . '"' . ($canEdit ? '' : ' disabled') . '></label>'
            . '<label class="ck-l">Address (after your shop name)<input class="ak-in" name="slug" maxlength="80" value="' . $e($p['slug']) . '"' . ($canEdit ? '' : ' disabled') . '></label>'
            . '<label class="ck-l">Search description (what search engines and shares show)<input class="ak-in" name="summary" maxlength="300" value="' . $e($p['summary']) . '"' . ($canEdit ? '' : ' disabled') . '></label>'
            . ($bz['live_version'] ? '<input type="hidden" name="body" value="' . $e($p['body']) . '"><p class="ak-note">This page is made in the builder now: <b>Edit the page</b> changes what it shows. Its earlier text is kept as it was.</p>'
                : '<label class="ck-l">The page<textarea class="ak-in" name="body" rows="10"' . ($canEdit ? '' : ' disabled') . ' data-spell>' . $e($p['body']) . '</textarea></label>')
            . '<label class="ck-l">Shows<select class="ak-in" name="status"' . ($canEdit ? '' : ' disabled') . '>';
        foreach (['draft' => 'Draft (only you)', 'live' => 'Live on your storefront', 'hidden' => 'Hidden'] as $k => $l) $h .= '<option value="' . $k . '"' . ($p['status'] === $k ? ' selected' : '') . '>' . $e($l) . '</option>';
        $h .= '</select></label><div class="ck-row"><button class="ak-b go"' . $dis($canEdit, $noEdit) . '>Save page</button>'
            . ($p['status'] === 'live' && $live ? '<a class="ak-b" href="' . $e($url . '/' . $p['slug']) . '" target="_blank" rel="noopener">See it ↗</a>' : '') . '</div></form></details>';
    }
    $h .= '<form class="sf-new ck-row" id="sf-new"><input class="ak-in" name="title" maxlength="120" placeholder="A new page\'s title (About us, Hours…)" aria-label="New page title"' . ($canEdit ? '' : ' disabled') . '>'
        . '<button class="ak-b go"' . $dis($canEdit, $noEdit) . '>Add a page</button></form></div>';

    // ---- its own domain (step 5b): buy one through us, or bring one it owns
    $h .= tv_biz_domain_card($main, $ctx, $uid, $sf);

    $h .= '<style>.ck-row{display:flex;flex-wrap:wrap;gap:.4rem;margin:.4rem 0}.ck-l{display:grid;gap:.2rem;font-size:.85rem;color:#5C4632;margin-top:.5rem}'
        . '.sf-th{border:0;padding:0;margin:.5rem 0 0;display:flex;flex-wrap:wrap;gap:.5rem}.sf-t{display:flex;flex-direction:column;align-items:center;gap:.25rem;font-size:.85rem;cursor:pointer}'
        . '.sf-t input{position:absolute;opacity:0}.sf-sw{display:flex;gap:3px;padding:.45rem;border-radius:.6rem;border:2px solid;outline:2px solid transparent}.sf-sw i{width:1.1rem;height:1.6rem;border-radius:.25rem;display:block}'
        . '.sf-t input:checked+.sf-sw{outline-color:#8FBCA8;box-shadow:0 0 0 4px rgba(143,188,168,.35)}.sf-t input:focus-visible+.sf-sw{outline-color:#92400E}'
        . '.sf-ac{display:flex;gap:.4rem;align-items:center}.sf-ac input[type=color]{width:2.6rem;height:2.2rem;border:1px solid #CBB98D;border-radius:.4rem;background:#FFFBF2;padding:2px}'
        . '.sf-pp{display:flex;flex-wrap:wrap;gap:1rem;margin:.5rem 0}.sf-p{display:grid;gap:.3rem;justify-items:start}.sf-im{display:flex;align-items:center;justify-content:center;background:#F3E7CC center/cover no-repeat;border:1px solid #EADFC4;color:#8A7355;font-size:.8rem}'
        . '.sf-logo{width:6rem;height:6rem;border-radius:.9rem}.sf-cover{width:min(18rem,80vw);height:6rem;border-radius:.6rem}'
        . '.sf-pick summary,.sf-pg summary{cursor:pointer;padding:.4rem 0}.sf-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(8rem,1fr));gap:.4rem}.sf-gi{display:grid;gap:.25rem}.sf-gi img{width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:.4rem}.sf-gi span{display:flex;gap:.25rem}'
        . '.ck-h{font-size:.95rem;margin:.8rem 0 .2rem;color:#3E2B1F}.dm-who{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(12rem,100%),1fr));gap:0 .6rem}'
        . '.dm-res{display:flex;flex-wrap:wrap;align-items:center;gap:.3rem .8rem;padding:.4rem 0;border-top:1px solid #EADFC4}.dm-res b{margin-right:auto;word-break:break-all}'
        . '.dm-tbl{display:grid;font-size:.85rem;margin:.4rem 0}.dm-r{display:grid;grid-template-columns:5rem 4rem 1fr 8rem;gap:.4rem;padding:.35rem 0;border-top:1px solid #EADFC4;align-items:start}.dm-hd{font-weight:700;color:#8A7355;border-top:0}'
        . '.dm-v{word-break:break-all}@media (max-width:640px){.dm-r{grid-template-columns:4rem 3.5rem 1fr}.dm-r span:last-child{display:none}}'
        . '.sf-pg{border-top:1px solid #EADFC4}.sf-pg small{color:#8A7355}.sf-new .ak-in{flex:1;min-width:12rem}</style>';
    return $h . tv_biz_storefront_js($id);
}

/** Your own domain (decisions/0139 §3): buy (Name.com) or bring; its records, its stage, renewal, moving it away. */
function tv_biz_domain_card(PDO $main, array $ctx, int $uid, array $sf): string
{
    require_once __DIR__ . '/../lib/Domains.php';
    $e = 'tv_w_e'; $id = (int) $ctx['id']; $role = Team::roleName($ctx['role']);
    $h = '<div class="ak-card tv-bleed" id="domain"><h2 class="ak-h" style="margin-top:0">Your own domain</h2>';
    if (!Domains::ready($main)) return $h . '<p data-tv-status="info" data-tv-label="Coming:">Connecting your own domain opens once its database update has run (within the hour).</p></div>';
    [$av, $avWhy] = Domains::available();
    if ($av && !Domains::visibleTo($main, $uid)) [$av, $avWhy] = [false, 'Connecting your own domain opens soon.'];
    if (!$av) return $h . '<p data-tv-status="info" data-tv-label="Coming soon:">' . $e($avWhy) . ' Your storefront stays at ' . $e(preg_replace('#^https?://#', '', Storefront::trvgoUrl($sf))) . '.</p></div>';
    $canDom = Team::can($main, $uid, $id, 'domain', 'edit');
    $canBill = Team::can($main, $uid, $id, 'billing', 'edit');
    $dis = fn (bool $ok, string $why) => $ok ? '' : ' disabled title="' . $e($why) . '"';
    $noDom = 'Your role (' . $role . ') can\'t change the domain.';
    if (Domains::testing()) $h .= '<p data-tv-status="info" data-tv-label="Test mode:">Only our team sees this. Domains are bought in Name.com\'s sandbox (not real registrations) and no card is charged; connecting a domain you own is real.</p>';
    $d = Domains::forEntity($main, $id);
    if (!$d) {
        [$sell, $sellWhy] = Domains::canSell();
        $h .= '<p class="ak-note">Put your storefront on its own address, like <b>yourshop.com</b>. Your trvgo.us address keeps working and sends visitors there.</p>';
        $h .= '<h3 class="ck-h">Buy a new domain</h3>';
        if (!$sell) $h .= '<p class="ak-note">' . $e($sellWhy) . '</p>';
        else {
            $me = (class_exists('Auth') ? Auth::currentUser() : null) ?: []; require_once __DIR__ . '/../lib/VCard.php';
            $card = VCard::listingCard($main, $id) ?: [];
            $nm = preg_split('/\s+/', trim((string) ($me['display_name'] ?? '')), 2) ?: [''];
            $h .= '<p class="ak-note">Registered in your business\'s name with privacy on (your details don\'t show in public records). It\'s yours: you can move it to another registrar any time. Paid on your plan\'s card, renewing each year.</p>'
                . '<form class="ck-row" id="dm-search"><input class="ak-in" name="q" maxlength="80" placeholder="The name you\'d like, like ' . $e(Storefront::slugify((string) $ctx['name']) ?: 'yourshop') . '" aria-label="Search for a domain"' . ($canDom ? '' : ' disabled') . ' style="flex:1;min-width:12rem"><button class="ak-b go"' . $dis($canDom, $noDom) . '>Search</button></form>'
                . '<div id="dm-results"></div>'
                . '<form id="dm-buy" hidden><h3 class="ck-h">Buy <span data-dm-name></span> for <span data-dm-price></span> a year</h3>'
                . '<p class="ak-note">The registrant: the person the domain is registered to, for your business. Kept private by WHOIS privacy.</p><div class="dm-who">';
            foreach ([['first', 'First name', $nm[0] ?? '', 'given-name'], ['last', 'Last name', $nm[1] ?? '', 'family-name'], ['email', 'Email', (string) ($me['email'] ?? ''), 'email'], ['phone', 'Phone', (string) ($card['phone'] ?? ''), 'tel'],
                      ['address1', 'Street address', (string) ($card['street'] ?? ''), 'street-address'], ['city', 'Town', (string) ($card['city'] ?? ''), 'address-level2'], ['state', 'State', (string) ($card['state'] ?? ''), 'address-level1'], ['zip', 'ZIP', (string) ($card['zip'] ?? ''), 'postal-code']] as [$k, $l, $v, $ac])
                $h .= '<label class="ck-l">' . $e($l) . '<input class="ak-in" name="' . $k . '" value="' . $e($v) . '" autocomplete="' . $ac . '" maxlength="120"></label>';
            $h .= '</div><p class="ak-note">Domain names aren\'t refundable once registered.</p><div class="ck-row"><button class="ak-b go"' . $dis($canDom && $canBill, $canBill ? $noDom : 'Your role (' . $role . ') can\'t pay for things (Plan & billing).') . '>Buy it</button><button type="button" class="ak-b" data-dm-cancel>Back</button></div></form>';
        }
        $h .= '<h3 class="ck-h">Use a domain you already own</h3>'
            . '<form class="ck-row" id="dm-own"><input class="ak-in" name="domain" maxlength="190" placeholder="yourshop.com" aria-label="Your domain" autocapitalize="none" spellcheck="false"' . ($canDom ? '' : ' disabled') . ' style="flex:1;min-width:12rem"><button class="ak-b go"' . $dis($canDom, $noDom) . '>Connect it</button></form>'
            . '<p class="ak-note">Next you\'ll add two records where your domain is registered (GoDaddy, Namecheap…), and we check them for you.</p>';
        return $h . '</div>';
    }
    $st = (string) $d['status'];
    $label = ['added' => ['info', 'Waiting for DNS:'], 'pointed' => ['info', 'DNS found:'], 'checked' => ['info', 'Almost there:'], 'live' => ['ok', 'Live:'], 'failed' => ['bad', 'Stopped:']][$st] ?? ['info', ''];
    $say = ['added' => 'Add the records below where ' . $d['domain'] . ' is registered. We check every 15 minutes; DNS changes can take a few hours.',
        'pointed' => $d['domain'] . ' points at your storefront. Its security certificate comes next, usually within minutes.',
        'checked' => 'Its security certificate is being issued. It goes live by itself.',
        'live' => 'Your storefront is at https://' . $d['domain'] . '. trvgo.us/' . $sf['slug'] . ' sends visitors there.',
        'failed' => ($d['last_error'] ?: 'It stopped pointing at your storefront.') . ' Your storefront is back at trvgo.us until it\'s fixed.'][$st] ?? '';
    $h .= '<p data-tv-status="' . $label[0] . '" data-tv-label="' . $e($label[1]) . '">' . $e($say) . '</p>';
    if ($st !== 'live' && $d['last_error'] !== '' && $st !== 'failed') $h .= '<p class="ak-note">Last check: ' . $e($d['last_error']) . '</p>';
    if ($d['source'] === 'own' || $st !== 'live') {
        $h .= '<p class="ak-note">' . ($d['source'] === 'bought' ? 'We set these for you; they\'re here for reference.' : 'Add these at your domain\'s registrar or DNS host, then tap Check now.') . '</p><div class="dm-tbl" role="table"><div class="dm-r dm-hd" role="row"><span>Name</span><span>Type</span><span>Value</span><span>For</span></div>';
        foreach (Domains::records($d) as [$n, $t, $v, $for]) $h .= '<div class="dm-r" role="row"><span><code>' . $e($n) . '</code></span><span>' . $e($t) . '</span><span><code class="dm-v">' . $e($v) . '</code></span><span>' . $e($for) . '</span></div>';
        $h .= '</div>';
        if (json_decode((string) $d['dkim'], true)) $h .= '<p class="ak-note">The email records let mail from your business (coming) be sent from @' . $e($d['domain']) . '. ' . ((int) $d['email_ok'] ? '<b>Found.</b>' : 'Not found yet.') . '</p>';
    }
    if ($d['source'] === 'bought') {
        $h .= '<p class="ak-note">Bought through us · ' . ($d['expires_at'] ? 'paid until ' . $e(date('M j, Y', strtotime((string) $d['expires_at']))) : '') . ' · ' . ((int) $d['auto_renew'] ? 'renews ' . $e(Domains::usd((int) $d['renew_cents'])) . ' a year on your plan\'s card, 2 weeks before' : 'won\'t renew') . '</p>'
            . '<div class="ck-row"><button type="button" class="ak-b" data-dm="' . ((int) $d['auto_renew'] ? 'renew_off' : 'renew_on') . '"' . $dis($canDom && $canBill, $noDom) . '>' . ((int) $d['auto_renew'] ? 'Stop renewing' : 'Renew each year') . '</button>'
            . '<button type="button" class="ak-b" data-dm="transfer"' . $dis($canDom, $noDom) . '>Move it to another registrar</button></div><p class="ak-note" id="dm-code" hidden></p>';
    }
    $h .= '<div class="ck-row">' . ($st !== 'live' ? '<button type="button" class="ak-b go" data-dm="check"' . $dis($canDom, $noDom) . '>Check now</button>' : '')
        . '<button type="button" class="ak-b no" data-dm="disconnect"' . $dis($canDom, $noDom) . '>Disconnect</button></div>';
    return $h . '</div>';
}

/**
 * The cover's stock photo (decisions/0143): until the business adds its own cover, its storefront shows a photo from the
 * stock library, labelled "Stock photo · Representative" for visitors (never shown as the business's own). The team can
 * choose which one; uploading a cover replaces it by itself. Only the cover: a logo is the business's own, never stock.
 */
function tv_biz_storefront_stock(PDO $main, int $id, bool $canEdit, string $noEdit): string
{
    require_once __DIR__ . '/../lib/StockLibrary.php';
    require_once __DIR__ . '/../ui/stock-ui.php';
    if (!StockLibrary::ready($main)) return '';
    $e = 'tv_w_e';
    $ch = StockLibrary::chosen($main, 'storefront_cover', (string) $id);
    $now = $ch ?: StockLibrary::forSlot($main, 'storefront_cover', (string) $id, 'main street shop', '', ['representative' => true, 'fallback' => 'main street']);
    $dis = $canEdit ? '' : ' disabled title="' . $e($noEdit) . '"';
    $api = '/business/api/' . $id . '/storefront';
    return '<div class="sf-stk"><p class="ak-note">' . ($now ? 'Until you add your own, visitors see this stock photo, labelled as one:' : 'Until you add your own, you can show a stock photo, labelled as one.') . ' <b>Choose a photo</b> opens your <a class="underline" href="/gallery/?b=' . $id . '">Gallery</a>: your photos, stock and Upload new, on separate tabs.</p>'
        . ($now ? '<span class="sf-im sf-cover" style="position:relative;background-image:url(\'' . $e($now['card']) . '\')">' . tv_stock_tag($now) . '</span>' : '')
        . ($ch ? '<span class="sf-stka"><button type="button" class="ak-b" data-stock-clear data-slot="storefront_cover" data-owner="' . $id . '" data-action="stock_cover" data-post="' . $e($api) . '"' . $dis . '>Let us pick</button></span>' : '') . '</div>'
        . '<script src="/js/tv-stock.js?v=' . (int) @filemtime(__DIR__ . '/../../website/js/tv-stock.js') . '" defer></script>'
        . '<style>.sf-stk{display:grid;gap:.35rem;max-width:20rem}.sf-stka{display:flex;flex-wrap:wrap;gap:.3rem}</style>';
}

function tv_biz_storefront_js(int $id): string
{
    return '<script>(function () {
  var API = ' . json_encode('/business/api/' . $id . '/storefront') . ', TOK = ' . json_encode((string) ($_SESSION['csrf_token'] ?? '')) . ';
  function post(b) { return fetch(API, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", "X-CSRF-Token": TOK }, body: JSON.stringify(window.tvSafe ? tvSafe(b) : b) })
    .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || "That didn\'t work."); return d; }); }
  function done(el) { return function (d) { TvAsk.say(d.message, { anchor: el }); setTimeout(function () { location.reload(); }, 900); }; }
  function fail(el) { return function (x) { TvAsk.say(x.message, { anchor: el, bad: true }); el.disabled = false; }; }
  var f = document.getElementById("sf-form");
  if (f) {
    var pick = f.querySelector("[data-sf-pick]");
    if (pick) pick.addEventListener("input", function () { f.accent.value = pick.value.toUpperCase(); });
    f.slug.addEventListener("input", function () { f.querySelector("[data-sf-slug]").textContent = f.slug.value.toLowerCase().replace(/[^a-z0-9-]+/g, "-"); });
    f.addEventListener("submit", function (ev) {
      ev.preventDefault(); var b = f.querySelector("button.go"); b.disabled = true;
      var th = f.querySelector("input[name=theme]:checked");
      post({ action: "save", slug: f.slug.value, theme: th ? th.value : "", accent: f.accent.value, tagline: f.tagline.value, about: f.about.value, parent: f.parent.value }).then(done(b), fail(b));
    });
  }
  document.querySelectorAll("form.sf-pf").forEach(function (pf) {
    pf.addEventListener("submit", function (ev) {
      ev.preventDefault(); var b = pf.querySelector("button.go"); b.disabled = true;
      post({ action: "page_save", page: +pf.getAttribute("data-page"), title: pf.title.value, slug: pf.slug.value, summary: pf.summary.value, body: pf.body.value, status: pf.status.value }).then(done(b), fail(b));
    });
  });
  var nf = document.getElementById("sf-new");
  if (nf) nf.addEventListener("submit", function (ev) { ev.preventDefault(); var b = nf.querySelector("button"); b.disabled = true; post({ action: "page_add", title: nf.title.value }).then(done(b), fail(b)); });
  document.querySelectorAll("input[data-sf-up]").forEach(function (u) {
    u.addEventListener("change", function () {
      if (!u.files.length || !window.TvUpload) return;
      var box = u.closest(".sf-p");
      TvUpload.send(u.files, { target: "storefront_photo", ctx: { b: ' . $id . ', which: u.getAttribute("data-sf-up") }, el: box, shrink: 2400, csrf: TOK })
        .then(function (r) { TvUpload.reloadHere(TvUpload.summary ? TvUpload.summary(r) : r[0].message, box); }, function () { u.value = ""; });
    });
  });
  // its own domain (step 5b)
  var ds = document.getElementById("dm-search"), dr = document.getElementById("dm-results"), db = document.getElementById("dm-buy"), pick = null;
  if (ds) ds.addEventListener("submit", function (ev) {
    ev.preventDefault(); var b = ds.querySelector("button"); b.disabled = true; dr.textContent = "";
    post({ action: "domain_search", q: ds.q.value }).then(function (d) {
      b.disabled = false;
      d.results.forEach(function (r) {
        var row = document.createElement("div"); row.className = "dm-res";
        var n = document.createElement("b"); n.textContent = r.domain; row.appendChild(n);
        var s = document.createElement("span"); s.textContent = r.ok ? (r.premium ? "Premium: ask us" : r.label) : "Taken"; row.appendChild(s);
        if (r.ok && !r.premium) { var go = document.createElement("button"); go.type = "button"; go.className = "ak-b go"; go.textContent = "Choose";
          go.addEventListener("click", function () { pick = r; db.querySelector("[data-dm-name]").textContent = r.domain; db.querySelector("[data-dm-price]").textContent = r.label.replace(" a year", ""); db.hidden = false; db.scrollIntoView({ block: "nearest" }); });
          row.appendChild(go); }
        dr.appendChild(row);
      });
    }, fail(b));
  });
  if (db) {
    db.querySelector("[data-dm-cancel]").addEventListener("click", function () { db.hidden = true; pick = null; });
    db.addEventListener("submit", function (ev) {
      ev.preventDefault(); if (!pick) return; var b = db.querySelector("button.go");
      if (!TvAsk.gate(b, "Buy " + pick.domain + " for " + pick.label + "? It\'s charged to your plan\'s card now and isn\'t refundable.", { yes: "Buy it" })) return;
      b.disabled = true; var who = {}; ["first", "last", "email", "phone", "address1", "city", "state", "zip"].forEach(function (k) { who[k] = db[k].value; });
      post({ action: "domain_buy", domain: pick.domain, price: pick.price, who: who }).then(done(b), fail(b));
    });
  }
  var dn = document.getElementById("dm-own");
  if (dn) dn.addEventListener("submit", function (ev) { ev.preventDefault(); var b = dn.querySelector("button"); b.disabled = true; post({ action: "domain_own", domain: dn.domain.value }).then(done(b), fail(b)); });
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-dm]"); if (!b) return;
    var what = b.getAttribute("data-dm");
    if (what === "disconnect" && !TvAsk.gate(b, "Disconnect your domain? Your storefront goes back to its trvgo.us address. A domain you bought through us stays yours.", { yes: "Disconnect", danger: true })) return;
    if (what === "renew_off" && !TvAsk.gate(b, "Stop renewing? It runs out on its date unless you renew it or move it.", { yes: "Stop renewing", danger: true })) return;
    if (what === "transfer" && !TvAsk.gate(b, "Unlock it and show its transfer code? Give the code only to the registrar you\'re moving to.", { yes: "Show the code" })) return;
    b.disabled = true;
    post({ action: "domain_" + what }).then(function (d) {
      if (d.code) { var c = document.getElementById("dm-code"); c.hidden = false; c.textContent = "Transfer code: " + d.code + ". Moving it takes up to 5 days; your storefront stays on it until it leaves us."; b.disabled = false; TvAsk.say(d.message, { anchor: b }); return; }
      done(b)(d);
    }, fail(b));
  });
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-sf]"); if (!b) return;
    var what = b.getAttribute("data-sf");
    if (what === "pause" && !TvAsk.gate(b, "Pause the storefront? Visitors see that the shop isn\'t open right now; nothing is lost.", { yes: "Pause" })) return;
    if (what === "live" && !TvAsk.gate(b, "Open your storefront to everyone?", { yes: "Go live" })) return;
    b.disabled = true;
    post(what === "photo" ? { action: "photo", which: b.getAttribute("data-which"), item: +b.getAttribute("data-item") } : { action: what }).then(done(b), fail(b));
  });
})();</script>';
}

/**
 * One page in the builder (decisions/0159 step 5a): its zone "shop.<page id>" with the editor for a role that may change
 * the storefront (Edit opens the panel: Add, Layout, Design per phone, tablet and computer, Save draft, Publish, Versions);
 * what's live (or its Markdown) for one that may only look. Publish is greyed with the reason for a role without it.
 */
function tv_biz_storefront_page(PDO $main, array $ctx, int $uid, array $sf, int $pid, string $noEdit, bool $canPub): string
{
    $e = 'tv_w_e'; $id = (int) $ctx['id'];
    $back = '<a class="ak-b" href="' . $e(tv_biz_url($id, 'storefront') . '#sf-pages') . '">← Storefront &amp; pages</a>';
    $p = SitePages::get($main, $pid, $id);
    if (!$p) return '<div class="ak-card tv-bleed"><p data-tv-status="bad" data-tv-label="Not found:">That page isn\'t one of this business\'s. It may have been removed.</p><div class="ck-row">' . $back . '</div></div>';
    require_once __DIR__ . '/../lib/Blocks.php';
    Blocks::useDb($main, tv_biz_url($id, 'storefront'));
    $zone = 'shop.' . (int) $p['id'];
    $s = Blocks::state($main, $zone);
    $look = $p['status'] !== 'hidden' ? '<a class="ak-b" href="' . $e(Storefront::url($sf) . '/' . $p['slug'] . '?preview=' . Storefront::previewKey($id)) . '" target="_blank" rel="noopener">Preview on your storefront ↗</a>' : '';
    $st = $s['draft'] !== null ? ['info', 'Draft:', 'A draft is waiting' . ($s['draft_by'] !== '' ? ' (' . $s['draft_by'] . ')' : '') . '. Only your team sees it, here and in the preview, until someone whose role can publish presses Publish.']
        : ($s['live_version'] ? ['ok', 'Live:', 'Version ' . $s['live_version'] . ' is on your storefront' . ($p['status'] === 'live' ? '' : ' once the page is set to Live') . '.']
        : ['info', 'Not built yet:', 'Visitors see the page\'s text as it is. Edit opens it in the builder, starting from that text.']);
    $h = '<div class="ak-card tv-bleed"><h2 class="ak-h" style="margin-top:0">' . $e($p['title']) . ' <span class="bz-pill">' . $e(SitePages::STATUSES[$p['status']]) . '</span></h2>'
        . '<p data-tv-status="' . $st[0] . '" data-tv-label="' . $e($st[1]) . '">' . $e($st[2]) . '</p>'
        . '<div class="ck-row">' . $back . $look . '</div>'
        . ($noEdit !== '' ? '' : '<p class="ak-note">Press <b>Edit</b> on the page below. Add sections and blocks (headings, words, pictures, buttons, dividers), drag them into place, and set how each looks on a phone, a tablet and a computer. <b>Save draft</b> keeps it for your team; <b>Publish</b> puts it on your storefront as the next version, and Versions rolls back to any earlier one. Pictures you upload are kept in your Gallery.'
        . ($canPub ? '' : ' Your role can save drafts but not publish: someone whose role has Publish puts them live.') . '</p>')
        . ($noEdit !== '' ? '<p data-tv-status="info" data-tv-label="Look only:">' . $e($noEdit) . '</p>' : '') . '</div>';
    $fallback = trim((string) $p['body']) !== '' ? '<div class="tvb-text">' . SitePages::html((string) $p['body']) . '</div>' : '';
    return $h . '<div class="ak-card tv-bleed sf-bld">' . Blocks::zone($main, $zone, $fallback, 'The page "' . $p['title'] . '"') . '</div>'
        . '<style>.ck-row{display:flex;flex-wrap:wrap;gap:.4rem;margin:.4rem 0}.sf-bld{padding-top:1.6rem}</style>';
}

/** The page's actions: start, save, live, pause, photo, stock_cover, page_add, page_save. Returns the message. */
function tv_biz_storefront_act(PDO $main, array $ctx, int $uid, string $act, array $in): string|array
{
    $id = (int) $ctx['id'];
    if (!Storefront::ready($main)) throw new RuntimeException('Storefronts aren\'t switched on yet.');
    $role = Team::roleName($ctx['role']);
    if ($ctx['role'] === 'white_glove') { try { Audit::log($main, ['user' => $uid, 'listing' => $id, 'route' => 'white_glove', 'action' => 'storefront.' . $act, 'detail' => '']); } catch (Throwable) {} }
    if (in_array($act, ['live', 'pause'], true)) {
        if (!Team::can($main, $uid, $id, 'publish', 'edit')) throw new RuntimeException('Your role (' . $role . ') can\'t publish.');
        Storefront::setStatus($main, $id, $uid, $act === 'live' ? 'live' : 'paused');
        return $act === 'live' ? 'You\'re live at ' . preg_replace('#^https?://#', '', Storefront::url(Storefront::get($main, $id))) . '.' : 'Paused.';
    }
    [$ok, $why] = tv_biz_can($main, $ctx, 'storefront', 'edit');
    if (!$ok) throw new RuntimeException(rtrim($why, '.') . '.');
    if (str_starts_with($act, 'domain_')) {   // its own domain (step 5b): Domain (edit); buying, Plan & billing too
        require_once __DIR__ . '/../lib/Domains.php';
        if (!Domains::visibleTo($main, $uid)) throw new RuntimeException('Connecting your own domain opens soon.');
        if (!Team::can($main, $uid, $id, 'domain', 'edit')) throw new RuntimeException('Your role (' . $role . ') can\'t change the domain.');
        switch ($act) {
            case 'domain_search':
                return ['results' => array_map(fn ($r) => ['domain' => $r[0], 'ok' => $r[1], 'price' => $r[2], 'label' => Domains::usd($r[2]) . ' a year', 'premium' => $r[5]], Domains::search((string) ($in['q'] ?? '')))];
            case 'domain_buy':
                if (!Team::can($main, $uid, $id, 'billing', 'edit')) throw new RuntimeException('Your role (' . $role . ') can\'t pay for things (Plan & billing).');
                $d = Domains::buy($main, $id, $uid, (string) ($in['domain'] ?? ''), (int) ($in['price'] ?? 0), (array) ($in['who'] ?? []), (string) $ctx['name']);
                return 'Bought: ' . $d['domain'] . ' is yours. ' . ($d['status'] === 'live' ? 'Your storefront is there now.' : 'It goes live by itself once its certificate is issued, usually within the hour.');
            case 'domain_own':
                $d = Domains::add($main, $id, $uid, (string) ($in['domain'] ?? ''));
                return 'Added ' . $d['domain'] . '. Add the records shown where it\'s registered.';
            case 'domain_check':
                $d = Domains::forEntity($main, $id); if (!$d) throw new InvalidArgumentException('Connect a domain first.');
                $d = Domains::check($main, (int) $d['id']);
                return $d['status'] === 'live' ? 'Live: your storefront is at https://' . $d['domain'] . '.' : (Domains::STATUSES[$d['status']] . ($d['last_error'] !== '' ? ': ' . $d['last_error'] : '.'));
            case 'domain_disconnect':
                Domains::disconnect($main, $id);
                return 'Disconnected. Your storefront is back at trvgo.us. A domain you bought through us is still yours.';
            case 'domain_renew_on': case 'domain_renew_off':
                Domains::setAutoRenew($main, $id, $act === 'domain_renew_on');
                return $act === 'domain_renew_on' ? 'It renews each year, two weeks before it runs out.' : 'It won\'t renew. It stays yours until its date.';
            case 'domain_transfer':
                return ['message' => 'Unlocked. Give this code to the new registrar.', 'code' => Domains::transferCode($main, $id)];
        }
        throw new InvalidArgumentException('Unknown action.');
    }
    switch ($act) {
        case 'start':
            $sf = Storefront::start($main, $id, $uid, (string) $ctx['name']);
            return 'Set up as trvgo.us/' . $sf['slug'] . '. Choose its look, then preview it and go live.';
        case 'save':
            $mayParent = fn (int $p) => Team::can($main, $uid, $p, 'theme', 'edit');
            $sf = Storefront::save($main, $id, $uid, $in, $mayParent);
            return 'Saved. Your storefront is trvgo.us/' . (!empty($sf['parent_slug']) ? $sf['parent_slug'] . '/' : '') . $sf['slug'] . '.';
        case 'stock_cover':   // a stock photo as the cover until its own is added (decisions/0143); 0 = let us pick
            require_once __DIR__ . '/../lib/StockLibrary.php';
            StockLibrary::setUse($main, 'storefront_cover', (string) $id, (int) ($in['stock'] ?? 0), $uid);
            return (int) ($in['stock'] ?? 0) ? 'Chosen. Visitors see it labelled "Stock photo" until you add your own cover.' : 'We\'ll pick one for you until you add your own cover.';
        case 'photo':
            Storefront::setPhoto($main, $id, (string) ($in['which'] ?? ''), (int) ($in['item'] ?? 0));
            return (int) ($in['item'] ?? 0) ? 'Done.' : 'Removed.';
        case 'page_add':
            if (!Storefront::get($main, $id)) throw new InvalidArgumentException('Set up the storefront first.');
            SitePages::create($main, (string) ($in['title'] ?? ''), $uid, $id);
            return 'Added as a draft. Write it, then set it to Live.';
        case 'page_save':
            $pid = (int) ($in['page'] ?? 0);
            if (!SitePages::get($main, $pid, $id)) throw new InvalidArgumentException('That page isn\'t one of yours.');
            SitePages::save($main, $pid, array_intersect_key($in, array_flip(['title', 'slug', 'summary', 'body', 'status'])), $uid, $id);
            return 'Saved.';
    }
    throw new InvalidArgumentException('Unknown action.');
}
