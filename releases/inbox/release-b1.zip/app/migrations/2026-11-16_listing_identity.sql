-- Release B (decisions/0164 §3.1, §6.1, X3, P1-2; 0163 §12): the identity keys on listings, the pairs a person or the
-- engine decided, the merge ledger (exact Undo), and the engine's steps ("The engine needs a person"). Safe to run twice.
-- The unique key on ZIP + phone + name is added by the identity recheck once no exact twins are left (ListingIdentity::uniqueKey).

SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD COLUMN ident_phone CHAR(10) DEFAULT NULL', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND COLUMN_NAME = 'ident_phone');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD COLUMN ident_name VARCHAR(160) DEFAULT NULL', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND COLUMN_NAME = 'ident_name');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD COLUMN ident_addr VARCHAR(160) DEFAULT NULL', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND COLUMN_NAME = 'ident_addr');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD COLUMN ident_geo CHAR(7) DEFAULT NULL', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND COLUMN_NAME = 'ident_geo');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD COLUMN ident_live VARCHAR(100) DEFAULT NULL', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND COLUMN_NAME = 'ident_live');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD COLUMN ident_at DATETIME DEFAULT NULL', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND COLUMN_NAME = 'ident_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD COLUMN ident_checked_at DATETIME DEFAULT NULL', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND COLUMN_NAME = 'ident_checked_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD INDEX ix_ident_phone (ident_phone)', 'DO 0') FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND INDEX_NAME = 'ix_ident_phone');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD INDEX ix_ident_zipname (primary_zip, ident_name(40))', 'DO 0') FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND INDEX_NAME = 'ix_ident_zipname');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD INDEX ix_ident_zipaddr (primary_zip, ident_addr(40))', 'DO 0') FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND INDEX_NAME = 'ix_ident_zipaddr');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD INDEX ix_ident_geo (ident_geo)', 'DO 0') FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND INDEX_NAME = 'ix_ident_geo');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE entities ADD INDEX ix_ident_checked (ident_checked_at)', 'DO 0') FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'entities' AND INDEX_NAME = 'ix_ident_checked');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

CREATE TABLE IF NOT EXISTS identity_pairs (
  a_id INT UNSIGNED NOT NULL,
  b_id INT UNSIGNED NOT NULL,
  verdict VARCHAR(12) NOT NULL,
  why VARCHAR(500) DEFAULT NULL,
  by_user INT UNSIGNED DEFAULT NULL,
  by_kind VARCHAR(12) NOT NULL DEFAULT 'system',
  at DATETIME NOT NULL,
  PRIMARY KEY (a_id, b_id),
  KEY ix_b (b_id),
  KEY ix_verdict (verdict)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS identity_merges (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  keep_id INT UNSIGNED NOT NULL,
  drop_id INT UNSIGNED NOT NULL,
  why VARCHAR(500) DEFAULT NULL,
  by_user INT UNSIGNED DEFAULT NULL,
  by_kind VARCHAR(12) NOT NULL DEFAULT 'system',
  run_id INT UNSIGNED DEFAULT NULL,
  moved MEDIUMTEXT,
  at DATETIME NOT NULL,
  undone_at DATETIME DEFAULT NULL,
  undone_by INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_keep (keep_id),
  KEY ix_drop (drop_id),
  KEY ix_run (run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS engine_steps (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  kind VARCHAR(20) NOT NULL,
  ref VARCHAR(120) NOT NULL,
  title VARCHAR(500) NOT NULL,
  data TEXT,
  value INT NOT NULL DEFAULT 10,
  status VARCHAR(8) NOT NULL DEFAULT 'open',
  assigned_to INT UNSIGNED DEFAULT NULL,
  answer VARCHAR(500) DEFAULT NULL,
  opened_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  done_at DATETIME DEFAULT NULL,
  done_by INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_kind_ref (kind, ref),
  KEY ix_status (status, kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
