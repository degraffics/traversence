-- Release B (decisions/0164 §0.8, §2.3; 0163 §11): a feature's provider on AI use (Claude, or Gemini's free tier for a
-- feature that reads public pages only, a director's call after the sample comparison). Safe to run twice.
SET @s = (SELECT IF(COUNT(*) = 0 AND (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ai_features') = 1, 'ALTER TABLE ai_features ADD COLUMN provider VARCHAR(12) NOT NULL DEFAULT ''claude''', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ai_features' AND COLUMN_NAME = 'provider');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
