<?php

declare(strict_types=1);

/**
 * Sales.php — turning unclaimed listings into active ones (decisions/0081, Jason 2026-10-14: "The sales funnel and
 * converting unclaimed listings into active listings is essential").
 *
 * Every live, unclaimed listing is a prospect. A prospect someone has worked has a row in `prospects`: its stage, the
 * last contact and its outcome, the next follow-up, who to ask for, notes; every call, visit, email, invite and note
 * is kept in `prospect_log`. Claimed, verified and paid come from the listing itself (entities.status, plan_tier).
 *
 *   new → contacted → interested → invited (claim invite sent) → claimed → verified → paid
 *   side roads: not now (back in 30 days), not interested, closed or wrong number
 *
 * A business's phone, website and email are public business details; we use them to offer the business its listing.
 * Claim-invite emails go one at a time from a person, say who we are and why, and honour "no thanks" (stage 'no'
 * stops further invites). They need BUSINESS_POSTAL_ADDRESS in .env, which every commercial email must carry.
 */
final class Sales
{
    // the stages a lead moves through (decisions/0108); Claimed, Verified and Paid come from the listing itself
    public const STAGES = ['new' => 'Not contacted', 'contacted' => 'Contacted', 'met' => 'Met in person', 'interested' => 'Interested', 'meeting' => 'Meeting set',
                           'invited' => 'Claim invite sent', 'quote' => 'Quote sent', 'won' => 'Won', 'not_now' => 'Nurture: not now', 'no' => 'Not interested',
                           'lost' => 'Lost', 'closed' => 'Closed or wrong number'];
    public const DONE = ['no', 'closed', 'won', 'lost'];   // no longer worth a call
    /** What happened on a contact => [stage it moves to (null: stays), days to the next follow-up (null: none), label]. */
    public const OUTCOMES = [
        'no_answer' => ['contacted', 2, 'No answer'],
        'left_message' => ['contacted', 3, 'Left a message'],
        'interested' => ['interested', 2, 'Talked: interested'],
        'invited' => ['invited', 3, 'Sent the claim link'],
        'not_now' => ['not_now', 30, 'Talked: not now'],
        'met' => ['met', 3, 'Met in person'],
        'meeting' => ['meeting', 1, 'Set a meeting'],
        'quote' => ['quote', 3, 'Sent a quote'],
        'won' => ['won', null, 'Won: they signed up'],
        'lost' => ['lost', null, 'Lost the deal'],
        'no' => ['no', null, 'Not interested'],
        'closed' => ['closed', null, 'Closed for good'],
        // confirming the listing (the Call list, decisions/0133): what a call proves goes into its identity as our team's word
        'confirmed' => ['contacted', 30, 'Confirmed: open, details right'],
        'wrong_number' => ['closed', null, 'Wrong number'],
        'moved' => [null, 7, 'They moved'],
        'note' => [null, null, 'Just a note'],
    ];
    public const KINDS = ['call' => 'Call', 'visit' => 'Visit', 'email' => 'Email', 'text' => 'Text', 'note' => 'Note', 'invite' => 'Invite'];
    private const LIVE = "e.entity_type = 'merchant' AND e.is_suppressed = 0 AND e.status IN ('unclaimed','claimed-unverified','pending-verification','verified')";

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM ' . Database::t('prospects') . ' LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    private static function hasTable(PDO $pdo, string $t): bool
    {
        static $have = [];
        if (!isset($have[$t])) { try { $pdo->query('SELECT 1 FROM ' . Database::t($t) . ' LIMIT 0'); $have[$t] = true; } catch (Throwable) { $have[$t] = false; } }
        return $have[$t];
    }

    private static function meta(string $key, string $alias): string
    {
        return "LEFT JOIN entity_metadata $alias ON $alias.entity_id = e.id AND $alias.meta_key = '$key'";
    }

    /**
     * Prospects to work, with what helps decide who to call: views and taps in the last 30 days, when it was added,
     * and where it stands. $f: q, town, category (id), stage ('new' = never worked), has (phone|website|email),
     * added (days), due (1: follow-ups due today or before), claimed ('no' default, 'yes', 'all'), mine (staff id).
     * $sort: best | new | views | name | due. Returns [rows, total].
     */
    public static function list(PDO $pdo, array $f, string $sort = 'best', int $limit = 50, int $offset = 0): array
    {
        // web presence (decisions/0086): a website of its own, only a social page (Facebook, Instagram…), or none
        $hasWs = "(ws.meta_value IS NOT NULL AND ws.meta_value NOT IN ('', '\"\"', 'null'))";
        $soc = "(ws.meta_value REGEXP 'facebook[.]|fb[.]com|fb[.]me|instagram[.]|linktr[.]ee|yelp[.]|tiktok[.]|twitter[.]com|//x[.]com|sites[.]google[.]com')";
        $hasSl = "(sl.meta_value IS NOT NULL AND sl.meta_value NOT IN ('', '[]', '\"\"', 'null'))";
        $web = "CASE WHEN $hasWs AND NOT $soc THEN 'own' WHEN $hasWs OR $hasSl THEN 'social' ELSE 'none' END";
        $since = date('Y-m-d', strtotime('-30 days'));
        $w = [self::LIVE]; $p = [];
        $claimed = (string) ($f['claimed'] ?? 'no');
        if ($claimed === 'no') $w[] = "e.status = 'unclaimed'";
        elseif ($claimed === 'yes') $w[] = "e.status <> 'unclaimed'";
        if (!empty($f['id'])) { $w[] = 'e.id = :eid'; $p[':eid'] = (int) $f['id']; }
        if (($q = trim((string) ($f['q'] ?? ''))) !== '') {
            $digits = preg_replace('/\D/', '', $q);
            $w[] = '(e.name LIKE :q' . (strlen($digits) >= 4 ? " OR REPLACE(REPLACE(REPLACE(REPLACE(ph.meta_value,'-',''),' ',''),'(',''),')','') LIKE :ph" : '') . (preg_match('/^#?\d+$/', $q) ? ' OR e.id = :id' : '') . ')';
            $p[':q'] = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
            if (strlen($digits) >= 4) $p[':ph'] = '%' . $digits . '%';
            if (preg_match('/^#?(\d+)$/', $q, $m)) $p[':id'] = (int) $m[1];
        }
        if (($t = trim((string) ($f['town'] ?? ''))) !== '') { $w[] = 'ci.meta_value LIKE :town'; $p[':town'] = '%' . $t . '%'; }
        if (($cat = (int) ($f['category'] ?? 0)) > 0) { $w[] = 'e.category_id = :cat'; $p[':cat'] = $cat; }
        $stage = (string) ($f['stage'] ?? '');
        if ($stage === 'new') $w[] = "(pr.entity_id IS NULL OR pr.stage = 'new')";
        elseif (isset(self::STAGES[$stage])) { $w[] = 'pr.stage = :stage'; $p[':stage'] = $stage; }
        elseif ($stage === '' && $claimed === 'no') $w[] = "(pr.stage IS NULL OR pr.stage NOT IN ('" . implode("','", self::DONE) . "'))";   // the ones still worth a call
        foreach ((array) ($f['has'] ?? []) as $h) {
            if ($h === 'phone') $w[] = "ph.meta_value IS NOT NULL AND ph.meta_value NOT IN ('', '\"\"', 'null')";
            if ($h === 'website') $w[] = "ws.meta_value IS NOT NULL AND ws.meta_value NOT IN ('', '\"\"', 'null')";
            if ($h === 'email') $w[] = "em.meta_value IS NOT NULL AND em.meta_value NOT IN ('', '\"\"', 'null')";
        }
        if (in_array($f['web'] ?? '', ['own', 'social', 'none'], true)) { $w[] = "$web = :web"; $p[':web'] = (string) $f['web']; }
        if (($f['web'] ?? '') === 'not_own') $w[] = "$web <> 'own'";
        if (($days = (int) ($f['added'] ?? 0)) > 0) { $w[] = 'e.created_at >= :added'; $p[':added'] = date('Y-m-d H:i:s', strtotime("-$days days")); }
        if (!empty($f['due'])) { $w[] = 'pr.next_at IS NOT NULL AND pr.next_at <= :today'; $p[':today'] = date('Y-m-d'); }
        if (($mine = (int) ($f['mine'] ?? 0)) > 0) { $w[] = 'pr.owner_id = :mine'; $p[':mine'] = $mine; }
        if (($f['owner'] ?? '') === 'none') $w[] = 'pr.owner_id IS NULL';   // the shared queue
        elseif (($ow = (int) ($f['owner'] ?? 0)) > 0) { $w[] = 'pr.owner_id = :ow'; $p[':ow'] = $ow; }
        if (($tr = (int) ($f['territory'] ?? 0)) > 0) { $w[] = 'pr.territory_id = :tr'; $p[':tr'] = $tr; }
        $scored = self::hasTable($pdo, 'lead_scores');
        // best: who's looking at it (views, taps), whether we can reach it, and new ones first among equals
        $score = '(COALESCE(pv.v, 0) * 3 + COALESCE(pa.a, 0) * 5 + (ph.meta_value IS NOT NULL) * 4 + (ws.meta_value IS NOT NULL) * 2 + (em.meta_value IS NOT NULL) * 2'
            . " + (e.created_at >= NOW() - INTERVAL 14 DAY) * 2 + (pr.stage = 'interested') * 8"
            . " + ($web <> 'own') * 3)";   // no website of its own: the ones a listing helps most (decisions/0086)
        $order = ['new' => 'e.created_at DESC', 'views' => 'COALESCE(pv.v,0) DESC, COALESCE(pa.a,0) DESC', 'name' => 'e.name',
                  'due' => 'pr.next_at IS NULL, pr.next_at, e.name'][$sort] ?? (($scored ? "COALESCE(ls.score, LEAST(100, $score))" : $score) . ' DESC, e.created_at DESC');   // the lead score (Leads.php) once it's scored
        $from = "FROM entities e
                 LEFT JOIN " . Database::t('prospects') . " pr ON pr.entity_id = e.id
                 LEFT JOIN categories c ON c.id = e.category_id
                 " . self::meta('city', 'ci') . ' ' . self::meta('phone', 'ph') . ' ' . self::meta('website', 'ws') . ' ' . self::meta('email', 'em') . ' ' . self::meta('address', 'ad') . ' ' . self::meta('social_links', 'sl') . "
                 " . (self::hasTable($pdo, 'identity_jobs') ? "LEFT JOIN " . Database::t('identity_jobs') . " ij ON ij.record_kind = 'listing' AND ij.record_id = e.id" : "LEFT JOIN (SELECT NULL AS status) ij ON 1 = 0") . "
                 LEFT JOIN (SELECT CAST(SUBSTRING(k, 9) AS UNSIGNED) eid, SUM(n) v FROM platform_counts WHERE metric = 'view' AND k LIKE 'listing:%' AND day >= '$since' GROUP BY k) pv ON pv.eid = e.id
                 LEFT JOIN (SELECT entity_id, SUM(n) a FROM listing_actions WHERE day >= '$since' GROUP BY entity_id) pa ON pa.entity_id = e.id
                 LEFT JOIN users u ON u.id = pr.owner_id
                 " . ($scored ? 'LEFT JOIN ' . Database::t('lead_scores') . ' ls ON ls.entity_id = e.id' : 'LEFT JOIN (SELECT NULL AS score, NULL AS why) ls ON 1 = 0') . "
                 WHERE " . implode(' AND ', $w);
        $st = $pdo->prepare("SELECT COUNT(*) $from");
        $st->execute($p);
        $total = (int) $st->fetchColumn();
        $st = $pdo->prepare("SELECT e.id, e.name, e.status, e.plan_tier, e.created_at, e.created_by_type, COALESCE(NULLIF(c.display_name, ''), c.name) AS category,
                                    JSON_UNQUOTE(ci.meta_value) city, JSON_UNQUOTE(ph.meta_value) phone, JSON_UNQUOTE(ws.meta_value) website, JSON_UNQUOTE(em.meta_value) email,
                                    JSON_UNQUOTE(ad.meta_value) address, COALESCE(pv.v, 0) views, COALESCE(pa.a, 0) taps, $web AS web, ij.status AS look,
                                    pr.stage, pr.next_at, pr.last_contact_at, pr.last_outcome, pr.contact_name, pr.notes, pr.source, u.display_name AS owner, pr.owner_id, ls.score, ls.why
                             $from ORDER BY $order LIMIT " . max(1, min(200, $limit)) . ' OFFSET ' . max(0, $offset));
        $st->execute($p);
        $rows = array_map(fn ($r) => self::shape($r), $st->fetchAll(PDO::FETCH_ASSOC));
        return [$rows, $total];
    }

    private static function shape(array $r): array
    {
        $s = fn ($v) => ($v === null || $v === 'null') ? '' : (string) $v;
        $stage = $r['status'] !== 'unclaimed' ? ($r['plan_tier'] && $r['plan_tier'] !== 'free' ? 'paid' : ($r['status'] === 'verified' ? 'verified' : 'claimed')) : ($r['stage'] ?: 'new');
        return ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'category' => $s($r['category']), 'city' => $s($r['city']), 'address' => $s($r['address']),
                'phone' => $s($r['phone']), 'website' => $s($r['website']), 'email' => $s($r['email']),
                'added' => substr((string) $r['created_at'], 0, 10), 'by' => (string) $r['created_by_type'],
                'views' => (int) $r['views'], 'taps' => (int) $r['taps'], 'stage' => $stage,
                'stage_label' => ['claimed' => 'Claimed', 'verified' => 'Verified', 'paid' => 'Paid'][$stage] ?? (self::STAGES[$stage] ?? $stage),
                'next_at' => $s($r['next_at']), 'last_contact_at' => $s($r['last_contact_at']), 'last_outcome' => self::OUTCOMES[$r['last_outcome'] ?? '']['2'] ?? '',
                'contact_name' => $s($r['contact_name']), 'notes' => $s($r['notes']), 'owner' => $s($r['owner']), 'source' => $s($r['source']),
                'owner_id' => (int) ($r['owner_id'] ?? 0), 'score' => $r['score'] === null ? null : (int) $r['score'], 'why' => json_decode((string) ($r['why'] ?? '[]'), true) ?: [],
                'lead_stage' => $r['stage'] ?: 'new',
                'claim_link' => self::claimLink((int) $r['id']),
                // web presence, said plainly; "none found" once the crawler has looked (decisions/0086)
                'web' => (string) ($r['web'] ?? 'none'),
                'web_label' => ['own' => 'Has a website', 'social' => 'Facebook or social only'][$r['web'] ?? ''] ?? (($r['look'] ?? '') === 'nothing' ? 'No website found' : 'No website yet')];
    }

    public static function claimLink(int $id): string
    {
        return rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/') . '/claim.php?listing=' . $id;
    }

    private static function upsert(PDO $pdo, int $id, int $staff, string $source = 'crawler'): void
    {
        $pdo->prepare('INSERT IGNORE INTO ' . Database::t('prospects') . ' (entity_id, owner_id, source) VALUES (?, ?, ?)')->execute([$id, $staff, $source]);
        if (is_file(__DIR__ . '/Leads.php')) { require_once __DIR__ . '/Leads.php'; try { Leads::route($pdo, $id, $source); } catch (Throwable) {} }   // its territory
        $pdo->prepare('UPDATE ' . Database::t('prospects') . ' SET owner_id = COALESCE(owner_id, ?) WHERE entity_id = ?')->execute([$staff, $id]);
    }

    /**
     * Record a contact: how (call, visit…), what happened (OUTCOMES), a note, the next follow-up (a date; '' for the
     * outcome's own default; 'none' for none), and who to ask for. Moves the stage the outcome says.
     */
    public static function log(PDO $pdo, int $staff, int $id, string $kind, string $outcome, string $note = '', string $next = '', ?string $contact = null): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run app/migrations/2026-11-18_sales.sql first.');
        if (!isset(self::KINDS[$kind])) $kind = 'call';
        if (!isset(self::OUTCOMES[$outcome])) throw new InvalidArgumentException('Choose what happened.');
        $st = $pdo->prepare('SELECT id FROM entities WHERE id = ?'); $st->execute([$id]);
        if (!$st->fetchColumn()) throw new InvalidArgumentException('That listing is gone.');
        [$stage, $days] = self::OUTCOMES[$outcome];
        $nextAt = $next === 'none' ? null : (preg_match('/^\d{4}-\d{2}-\d{2}$/', $next) ? $next : ($days !== null ? date('Y-m-d', strtotime("+$days days")) : null));
        self::upsert($pdo, $id, $staff);
        $set = ['next_at = ?']; $args = [$nextAt];
        if ($outcome !== 'note') { $set[] = 'last_contact_at = NOW()'; $set[] = 'last_outcome = ?'; $args[] = $outcome; }
        if ($stage !== null) { $set[] = 'stage = ?'; $args[] = $stage; }
        if ($contact !== null) { $set[] = 'contact_name = ?'; $args[] = mb_substr(trim($contact), 0, 120); }
        if (trim($note) !== '') { $set[] = "notes = TRIM(BOTH '\n' FROM CONCAT(?, '\n', notes))"; $args[] = date('M j') . ': ' . mb_substr(trim($note), 0, 400); }
        $args[] = $id;
        $pdo->prepare('UPDATE ' . Database::t('prospects') . ' SET ' . implode(', ', $set) . ' WHERE entity_id = ?')->execute($args);
        $pdo->prepare('INSERT INTO ' . Database::t('prospect_log') . ' (entity_id, staff_id, kind, outcome, note) VALUES (?, ?, ?, ?, ?)')
            ->execute([$id, $staff, $kind, $outcome, mb_substr(trim($note), 0, 1000)]);
        self::verify($pdo, $staff, $id, $kind, $outcome, $note);
        return self::one($pdo, $id);
    }

    /** Outcomes where someone at the business answered: the number reaches it, and it's open. */
    public const ANSWERED = ['confirmed', 'interested', 'invited', 'not_now', 'meeting', 'quote', 'won', 'no', 'met'];

    /**
     * Every contact is also a check of the listing (the Call list, decisions/0133): what it proves goes into the listing's
     * identity as our team's word, so its confidence follows. Someone at the business answered: its name and phone are
     * right (a visit: its address too). Wrong number: that phone is marked not right. Closed for good: it shows as Closed
     * (still found by name). They moved: Review gets it, with what they said. Never fails the contact it records.
     */
    private static function verify(PDO $pdo, int $staff, int $id, string $kind, string $outcome, string $note): void
    {
        try {
            require_once __DIR__ . '/Identity.php';
            if (!Identity::ready($pdo)) return;
            $how = $kind === 'visit' || $outcome === 'met' ? 'Visited' : 'Called';
            $when = $how . ' by our team, ' . date('M j, Y') . ($note !== '' ? ': ' . mb_substr(trim($note), 0, 200) : '');
            $cur = function (string $fact) use ($pdo, $id) {
                $st = $pdo->prepare('SELECT id, value FROM ' . Database::t('identity_facts') . " WHERE record_kind = 'listing' AND record_id = ? AND fact = ? AND is_current = 1 AND status NOT IN ('rejected','replaced') ORDER BY id DESC LIMIT 1");
                $st->execute([$id, $fact]); return $st->fetch(PDO::FETCH_ASSOC) ?: null;
            };
            if (in_array($outcome, self::ANSWERED, true)) {
                Identity::syncFromListing($pdo, $id);   // the listing's values are in its identity first
                $facts = ['name', 'phone']; if ($how === 'Visited' || $outcome === 'confirmed') $facts[] = 'address';
                foreach ($facts as $f) if ($c = $cur($f)) Identity::add($pdo, 'listing', $id, $f, (string) $c['value'], ['kind' => 'admin', 'label' => $how . ' by our team', 'by' => $staff, 'note' => $when]);
                Identity::recompute($pdo, 'listing', $id);
            } elseif ($outcome === 'wrong_number') {
                if ($c = $cur('phone')) Identity::reject($pdo, (int) $c['id'], 'Wrong number: ' . $when, $staff);
                require_once __DIR__ . '/Suggestions.php';   // Review finds the right one; the listing counts it against itself until then
                $e = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $e->execute([$id]);
                Suggestions::create($pdo, ['kind' => 'fix', 'entity_id' => $id, 'target_name' => (string) $e->fetchColumn(), 'note' => 'Wrong number (' . $when . '). Find its right phone.'], $staff ?: null, 'call-' . $id);
            } elseif ($outcome === 'closed') {
                require_once __DIR__ . '/SuggestionActions.php';
                SuggestionActions::markClosed($pdo, $id, $staff, 0, $when);
            } elseif ($outcome === 'moved') {
                require_once __DIR__ . '/Suggestions.php';
                $e = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $e->execute([$id]);
                Suggestions::create($pdo, ['kind' => 'fix', 'entity_id' => $id, 'target_name' => (string) $e->fetchColumn(), 'note' => 'They moved (' . $when . '). Put in the new address.'], $staff ?: null, 'call-' . $id);
            }
            require_once __DIR__ . '/ListingConfidence.php';
            ListingConfidence::refresh($pdo, $id);   // the ring follows the call at once
        } catch (Throwable $x) { error_log('sales verify #' . $id . ': ' . $x->getMessage()); }
    }

    /**
     * The Call list: listings we're least sure of (red and orange) that have a phone and no call in 90 days, the least
     * sure first. [[id, name, city, category, phone, score]].
     */
    public static function toConfirm(PDO $pdo, int $limit = 100, string $q = ''): array
    {
        require_once __DIR__ . '/ListingConfidence.php';
        if (!ListingConfidence::ready($pdo)) return [];
        $w = $q !== '' ? ' AND e.name LIKE ?' : '';
        $st = $pdo->prepare("SELECT e.id, e.name, lc.score, c.name AS category, JSON_UNQUOTE(m.meta_value) AS phone, JSON_UNQUOTE(ct.meta_value) AS city
                               FROM entities e JOIN listing_confidence lc ON lc.entity_id = e.id
                               JOIN entity_metadata m ON m.entity_id = e.id AND m.meta_key = 'phone' AND m.meta_value NOT IN ('', '\"\"', 'null')
                               LEFT JOIN entity_metadata ct ON ct.entity_id = e.id AND ct.meta_key = 'city'
                               LEFT JOIN entity_metadata cl ON cl.entity_id = e.id AND cl.meta_key = 'closed'
                               LEFT JOIN categories c ON c.id = e.category_id
                              WHERE " . self::LIVE . " AND e.owner_user_id IS NULL AND cl.entity_id IS NULL AND lc.score < 51$w
                                AND NOT EXISTS (SELECT 1 FROM " . Database::t('prospect_log') . " pl WHERE pl.entity_id = e.id AND pl.at > NOW() - INTERVAL 90 DAY AND pl.kind IN ('call','visit'))
                              ORDER BY lc.score, e.id DESC LIMIT " . max(1, min(500, $limit)));
        $st->execute($q !== '' ? ['%' . $q . '%'] : []);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function one(PDO $pdo, int $id): array
    {
        [$rows] = self::list($pdo, ['id' => $id, 'claimed' => 'all', 'stage' => 'any'], 'name', 1);
        return $rows[0] ?? [];
    }

    public static function history(PDO $pdo, int $id): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT l.kind, l.outcome, l.note, l.at, u.display_name FROM ' . Database::t('prospect_log') . ' l LEFT JOIN users u ON u.id = l.staff_id WHERE l.entity_id = ? ORDER BY l.id DESC LIMIT 30');
        $st->execute([$id]);
        return array_map(fn ($r) => ['kind' => self::KINDS[$r['kind']] ?? $r['kind'], 'outcome' => self::OUTCOMES[$r['outcome']][2] ?? '', 'note' => (string) $r['note'],
            'at' => substr((string) $r['at'], 0, 16), 'by' => (string) ($r['display_name'] ?? '')], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /** Whether claim invites can go by email from here: the sender's postal address is set (every commercial email needs it). */
    public static function canEmail(): bool
    {
        return trim((string) (getenv('BUSINESS_POSTAL_ADDRESS') ?: '')) !== '';
    }

    /** Email the business its claim link, from a person, once; "no thanks" stops it (stage 'no'). */
    public static function emailInvite(PDO $pdo, int $staff, int $id, string $staffName): array
    {
        if (!self::canEmail()) throw new InvalidArgumentException('Set BUSINESS_POSTAL_ADDRESS in .env first: every sales email must carry it. Copy the claim link instead.');
        $p = self::one($pdo, $id);
        if (!$p) throw new InvalidArgumentException('That listing is gone.');
        if ($p['email'] === '' || !filter_var($p['email'], FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('This listing has no email. Call, or copy the claim link to text it.');
        if (in_array($p['stage'], ['no', 'closed', 'claimed', 'verified', 'paid'], true)) throw new InvalidArgumentException('Not to this one: it said no, it\'s closed, or it\'s already claimed.');
        $site = rtrim((string) (getenv('APP_URL') ?: 'https://traversence.com'), '/');
        $body = "Hello" . ($p['contact_name'] !== '' ? ' ' . $p['contact_name'] : '') . ",\n\n"
            . "{$p['name']} is listed on Traversence, the local guide for " . ($p['city'] ?: 'your area') . ":\n$site/listing/view.php?id=$id\n\n"
            . "It's free to claim. Once it's yours you can correct the details, add your hours and photos, and answer people who message you:\n"
            . $p['claim_link'] . "\n\n"
            . "If you'd rather we didn't email you again, just reply \"no thanks\".\n\n"
            . ($staffName !== '' ? "$staffName\n" : '') . "Traversence\n" . trim((string) getenv('BUSINESS_POSTAL_ADDRESS')) . "\n";
        require_once __DIR__ . '/Mailer.php';
        Mailer::send($p['email'], 'Your free listing on Traversence: ' . $p['name'], $body);
        return self::log($pdo, $staff, $id, 'invite', 'invited', 'Claim invite emailed to ' . $p['email']);
    }

    /**
     * A business seen in person (Jason: "as I collect physical info I need a clean way to input new listings and put
     * them into the funnel"): it's listed (unclaimed, the crawler fills in the rest) and starts in the funnel with the
     * visit logged. Throws with the possible duplicates unless $anyway; returns [id, duplicates].
     */
    public static function addFromField(PDO $pdo, int $staff, array $in, bool $anyway = false): array
    {
        require_once __DIR__ . '/AddBusiness.php';
        $d = AddBusiness::clean($in + ['kind' => 'other'], false, true);
        if (!$anyway && ($dups = AddBusiness::duplicates($pdo, $d))) return [0, $dups];
        $id = AddBusiness::create($pdo, $d, 'admin', ['anyway' => $anyway, 'uid' => $staff]);
        if (is_file(__DIR__ . '/IdentityJobs.php')) {
            require_once __DIR__ . '/IdentityJobs.php';
            try { if (IdentityJobs::ready($pdo)) IdentityJobs::look($pdo, $id); } catch (Throwable $x) { error_log('field add look: ' . $x->getMessage()); }
        }
        if (self::ready($pdo)) {
            self::upsert($pdo, $id, $staff, 'field');
            $outcome = isset(self::OUTCOMES[$in['outcome'] ?? '']) && ($in['outcome'] ?? '') !== 'note' ? (string) $in['outcome'] : 'left_message';
            self::log($pdo, $staff, $id, 'visit', $outcome, (string) ($in['note'] ?? ''), (string) ($in['next_at'] ?? ''), (string) ($in['contact_name'] ?? ''));
        }
        return [$id, []];
    }

    /** The funnel: how many at each step, and what moved in the last 7 days. */
    public static function funnel(PDO $pdo): array
    {
        $q = function (string $sql, array $a = []) use ($pdo): int { try { $st = $pdo->prepare($sql); $st->execute($a); return (int) $st->fetchColumn(); } catch (Throwable) { return 0; } };
        $live = "entity_type = 'merchant' AND is_suppressed = 0";
        $wk = date('Y-m-d H:i:s', strtotime('-7 days'));
        $unclaimed = $q("SELECT COUNT(*) FROM entities WHERE $live AND status = 'unclaimed'");
        $stage = function (string $s) use ($q, $live): int { return $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " p JOIN entities e ON e.id = p.entity_id WHERE e.$live AND e.status = 'unclaimed' AND p.stage = ?", [$s]); };
        $f = [
            'unclaimed' => $unclaimed,
            'new' => $unclaimed - $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " p JOIN entities e ON e.id = p.entity_id WHERE e.$live AND e.status = 'unclaimed' AND p.stage <> 'new'"),
            'contacted' => $stage('contacted'), 'interested' => $stage('interested'), 'invited' => $stage('invited'),
            'not_now' => $stage('not_now'), 'no' => $stage('no'), 'closed' => $stage('closed'),
            'claimed' => $q("SELECT COUNT(*) FROM entities WHERE $live AND status IN ('claimed-unverified','pending-verification')"),
            'verified' => $q("SELECT COUNT(*) FROM entities WHERE $live AND status = 'verified'"),
            'paid' => $q("SELECT COUNT(*) FROM entities WHERE $live AND status <> 'unclaimed' AND plan_tier IS NOT NULL AND plan_tier <> 'free'"),
            // the later stages, whether or not the listing is claimed yet
            'met' => $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " WHERE stage = 'met'"), 'meeting' => $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " WHERE stage = 'meeting'"),
            'quote' => $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " WHERE stage = 'quote'"), 'won' => $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " WHERE stage = 'won'"),
            'lost' => $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " WHERE stage = 'lost'"),
            'week' => [
                'contacts' => $q("SELECT COUNT(*) FROM " . Database::t('prospect_log') . " WHERE at >= ? AND kind <> 'note'", [$wk]),
                'invites' => $q("SELECT COUNT(*) FROM " . Database::t('prospect_log') . " WHERE at >= ? AND outcome = 'invited'", [$wk]),
                'claims' => $q('SELECT COUNT(*) FROM listing_claims WHERE created_at >= ?', [$wk]),
                'added' => $q("SELECT COUNT(*) FROM entities WHERE $live AND created_at >= ?", [$wk]),
                'field' => $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " WHERE source = 'field' AND created_at >= ?", [$wk]),
            ],
            'due' => $q("SELECT COUNT(*) FROM " . Database::t('prospects') . " p JOIN entities e ON e.id = p.entity_id WHERE e.$live AND e.status = 'unclaimed' AND p.next_at IS NOT NULL AND p.next_at <= ? AND p.stage NOT IN ('no','closed','won','lost')", [date('Y-m-d')]),
        ];
        return $f;
    }
}
