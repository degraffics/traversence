<?php

declare(strict_types=1);

require_once __DIR__ . '/Lexicon.php';
require_once __DIR__ . '/Situations.php';

/**
 * How-to guides built by the crawler (decisions/0063 §8).
 *
 *   wanted     searches asked how to do something ("how to compost leaves": "how to" and an action), 3 or more in 30
 *              days, or staff asked for it
 *   looking    the crawler has it: official how-to pages only (.gov, .edu, state .us: extension services, agencies)
 *   draft      the crawler found steps, each with its source: a person puts them in our words and checks them
 *   published  shown: in search for those words, and on its own page (/guide/how.php?id=)
 *   nothing    no official page had steps: it looks again in 30 days
 *   rejected   not a guide to write ("how to get to Show Low" is directions, not steps)
 *
 * Nothing shows before a person publishes it. Until then an action leads to who does it. Counts only, never who.
 */
final class HowGuides
{
    public const MIN_SEARCHES = 3;
    public const MAX_STEPS = 15;
    public const STATUS = ['wanted' => 'Wanted', 'looking' => 'The crawler is looking', 'draft' => 'To review', 'published' => 'Published',
                           'nothing' => 'Nothing found yet', 'rejected' => 'Not a guide'];
    private const LEAD = '/^(?:please\s+)?(?:learn how to|how do i|how do you|how can i|how does one|how to|steps to)\s+/u';
    private const TAIL = '/\s+(?:in|near|around|at|close to)\s+.+$|\s+near me$/u';

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM how_guides LIMIT 1'); return $r = true; } catch (Throwable) { return $r = false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /** What a search asks how to do: ['key', 'action', 'thing', 'title'] or null (not a how-to, or no action we know). */
    public static function asks(PDO $pdo, string $q): ?array
    {
        $q = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $q)));
        if (!preg_match(self::LEAD, $q)) return null;
        $action = ''; $thing = '';
        foreach (Lexicon::read($pdo, $q) as $x) {
            if ($x['kind'] === 'action' && $action === '') $action = (string) $x['class'];
            elseif (in_array($x['kind'], ['thing', 'tool'], true) && $thing === '' && $action !== '') $thing = (string) $x['class'];
        }
        if ($action === '') return null;   // a word search doesn't know yet: teach it first (the Workbench drafts it)
        $rest = trim(preg_replace(self::TAIL, '', preg_replace(self::LEAD, '', $q)));
        if ($rest === '') return null;
        return ['key' => $action . ($thing !== '' ? '|' . $thing : ''), 'action' => $action, 'thing' => $thing, 'title' => 'How to ' . mb_substr($rest, 0, 150)];
    }

    /** From the last 30 days of searches: what people asked how to do. Returns ['new' => n, 'seen' => n]. */
    public static function refresh(PDO $pdo): array
    {
        if (!self::ready($pdo)) return ['new' => 0, 'seen' => 0];
        $since = date('Y-m-d', time() - 30 * 86400);
        $by = [];
        try {
            $st = $pdo->prepare("SELECT q, SUM(n) AS n, COUNT(DISTINCT day) AS days FROM search_terms WHERE day >= ? AND (q LIKE 'how %' OR q LIKE 'learn how %' OR q LIKE 'steps to %') GROUP BY q");
            $st->execute([$since]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $a = self::asks($pdo, (string) $r['q']);
                if (!$a) continue;
                $k = $a['key'];
                $by[$k] = $by[$k] ?? $a + ['n' => 0, 'days' => 0, 'titles' => [], 'q' => (string) $r['q']];
                $by[$k]['n'] += (int) $r['n']; $by[$k]['days'] = max($by[$k]['days'], (int) $r['days']);
                $by[$k]['titles'][$a['title']] = ($by[$k]['titles'][$a['title']] ?? 0) + (int) $r['n'];
            }
        } catch (Throwable $e) { error_log('how guides: ' . $e->getMessage()); }
        $new = 0;
        $get = $pdo->prepare('SELECT id, status FROM how_guides WHERE gkey = ?');
        foreach ($by as $k => $g) {
            arsort($g['titles']); $title = (string) array_key_first($g['titles']);   // the words people used most
            $sit = '';
            try { $s = Situations::read($pdo, $g['q']); if ($s) $sit = (string) ($s[0]['slug'] ?? ''); } catch (Throwable) {}
            $get->execute([$k]); $old = $get->fetch(PDO::FETCH_ASSOC);
            if (!$old) {
                $pdo->prepare('INSERT INTO how_guides (gkey, action, thing, title, situation, asked_n, asked_days, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                    ->execute([$k, $g['action'], $g['thing'], $title, $sit, $g['n'], $g['days'], 'wanted', self::now(), self::now()]);
                $new++;
            } else {
                // the counts follow the searches; the title is kept once a person has worked on it
                $pdo->prepare("UPDATE how_guides SET asked_n = ?, asked_days = ?, situation = CASE WHEN situation = '' THEN ? ELSE situation END,
                               title = CASE WHEN status IN ('wanted', 'nothing') THEN ? ELSE title END, updated_at = ? WHERE id = ?")
                    ->execute([$g['n'], $g['days'], $sit, $title, self::now(), (int) $old['id']]);
            }
        }
        return ['new' => $new, 'seen' => count($by)];
    }

    // ---- the crawler ----------------------------------------------------------------------------------------------

    /** Hands the crawler up to $n guides to look for (an hour each). */
    public static function lease(PDO $pdo, int $n): array
    {
        if (!self::ready($pdo)) return [];
        $now = self::now();
        $pdo->prepare("UPDATE how_guides SET status = 'wanted' WHERE status = 'looking' AND lease_until < ?")->execute([$now]);   // a lease that ran out
        $pdo->prepare("UPDATE how_guides SET status = 'wanted' WHERE status = 'nothing' AND next_at <= ?")->execute([$now]);
        $st = $pdo->prepare("SELECT id, title, action, thing FROM how_guides WHERE status = 'wanted' AND (asked_n >= ? OR requested = 1) ORDER BY requested DESC, asked_n DESC, id LIMIT " . max(1, min(10, $n)));
        $st->execute([self::MIN_SEARCHES]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $g) {
            $pdo->prepare("UPDATE how_guides SET status = 'looking', lease_until = ?, tries = tries + 1 WHERE id = ? AND status = 'wanted'")
                ->execute([date('Y-m-d H:i:s', time() + 3600), (int) $g['id']]);
            $words = trim(preg_replace('/^how to\s+/i', '', (string) $g['title']));
            $out[] = ['id' => (int) $g['id'], 'title' => $g['title'], 'words' => $words, 'query' => 'how to ' . $words];
        }
        return $out;
    }

    /** An official page: a government (.gov, a state's .us) or a university (.edu, which hosts the extension services). */
    public static function official(string $url): bool
    {
        $h = strtolower((string) parse_url($url, PHP_URL_HOST));
        $h = preg_replace('/^www\./', '', $h);
        return $h !== '' && (bool) preg_match('/\.(gov|edu|mil)$|\.gov\.[a-z]{2}$|\.[a-z]{2}\.us$/', $h);
    }

    private static function clean(string $s, int $max): string
    {
        $s = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($s), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
        return mb_strlen($s) > $max ? rtrim(mb_substr($s, 0, $max - 1)) . '…' : $s;
    }

    /**
     * What the crawler found: [{url, title, steps: [..]}], official pages only. The page with the most steps is the
     * draft; the others are kept as sources to check against. None: looks again in 30 days. Returns the new status.
     */
    public static function complete(PDO $pdo, int $id, array $pages, string $error = ''): string
    {
        $st = $pdo->prepare("SELECT id FROM how_guides WHERE id = ? AND status = 'looking'"); $st->execute([$id]);
        if (!$st->fetchColumn()) throw new InvalidArgumentException('That guide isn\'t leased.');
        $sources = []; $best = null;
        foreach (array_slice($pages, 0, 5) as $p) {
            if (!is_array($p)) continue;
            $url = (string) ($p['url'] ?? '');
            if (!preg_match('#^https?://#i', $url) || !self::official($url)) continue;   // never anything but official pages
            if (!self::mayUse($pdo, $url)) continue;   // the source register says not to use it (review C14)
            $steps = array_values(array_filter(array_map(fn ($x) => self::clean((string) $x, 300), (array) ($p['steps'] ?? [])), fn ($x) => mb_strlen($x) >= 8));
            $steps = array_slice($steps, 0, self::MAX_STEPS);
            $sources[] = ['url' => mb_substr($url, 0, 500), 'title' => self::clean((string) ($p['title'] ?? ''), 160), 'host' => preg_replace('/^www\./', '', strtolower((string) parse_url($url, PHP_URL_HOST))), 'n' => count($steps),
                          'said' => $steps];   // the page's own words, kept to check a published step isn't copied from them
            if (count($steps) >= 3 && ($best === null || count($steps) > count($best[1]))) $best = [count($sources) - 1, $steps];
        }
        if ($best === null) {
            $pdo->prepare("UPDATE how_guides SET status = 'nothing', lease_until = NULL, next_at = ?, sources = ?, note = ?, updated_at = ? WHERE id = ?")
                ->execute([date('Y-m-d H:i:s', time() + 30 * 86400), json_encode($sources, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                           mb_substr($error !== '' ? $error : ($sources ? 'Official pages found, but none listed steps.' : 'No official page found.'), 0, 300), self::now(), $id]);
            return 'nothing';
        }
        $steps = array_map(fn ($t) => ['text' => $t, 'src' => $best[0] + 1], $best[1]);
        $pdo->prepare("UPDATE how_guides SET status = 'draft', lease_until = NULL, next_at = NULL, steps = ?, sources = ?, note = ?, updated_at = ? WHERE id = ?")
            ->execute([json_encode($steps, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), json_encode($sources, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                       'Drafted from ' . $sources[$best[0]]['host'] . ' (' . count($steps) . ' steps); ' . count($sources) . ' official page' . (count($sources) === 1 ? '' : 's') . ' read.', self::now(), $id]);
        return 'draft';
    }

    // ---- people ----------------------------------------------------------------------------------------------------

    public static function get(PDO $pdo, int $id): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM how_guides WHERE id = ?'); $st->execute([$id]);
        $g = $st->fetch(PDO::FETCH_ASSOC);
        if (!$g) return null;
        $g['steps'] = json_decode((string) $g['steps'], true) ?: [];
        $g['sources'] = json_decode((string) $g['sources'], true) ?: [];
        return $g;
    }

    public static function list(PDO $pdo, string $status, int $limit = 50): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT id, title, status, asked_n, asked_days, requested, note, updated_at, published_at FROM how_guides WHERE status = ? ORDER BY requested DESC, asked_n DESC, id DESC LIMIT ' . max(1, min(200, $limit)));
        $st->execute([$status]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function counts(PDO $pdo): array
    {
        $out = array_fill_keys(array_keys(self::STATUS), 0);
        if (!self::ready($pdo)) return $out;
        foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM how_guides GROUP BY status')->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['status']] = (int) $r['n'];
        return $out;
    }

    /**
     * Saves a person's edit: title, intro, and the steps as lines ("Chop the leaves first. [1]": the number is its
     * source). $publish: shown from now on; it needs at least 3 steps, each with a source, and the person's word that
     * the steps are in our words and checked against the sources.
     */
    public static function save(PDO $pdo, int $id, array $in, int $uid, bool $publish): array
    {
        $g = self::get($pdo, $id) ?? throw new InvalidArgumentException('That guide is gone.');
        $title = self::clean((string) ($in['title'] ?? $g['title']), 160);
        if (mb_strlen($title) < 5) throw new InvalidArgumentException('Give it a title.');
        $intro = self::clean((string) ($in['intro'] ?? ''), 400);
        $n = count($g['sources']);
        $steps = [];
        foreach (preg_split('/\r?\n/', (string) ($in['steps'] ?? '')) as $line) {
            $line = trim(preg_replace('/^\s*(?:\d+[.)]|[-•*])\s*/u', '', $line));
            if ($line === '') continue;
            $src = 0;
            if (preg_match('/\s*\[(\d+)\]\s*$/', $line, $m)) { $src = (int) $m[1]; $line = trim(substr($line, 0, -strlen($m[0]))); }
            if ($src < 1 || $src > $n) $src = 0;
            $steps[] = ['text' => self::clean($line, 300), 'src' => $src];
        }
        $steps = array_slice($steps, 0, self::MAX_STEPS);
        $err = '';
        if ($publish) {
            if (count($steps) < 3) $err = 'A guide needs at least 3 steps.';
            elseif (array_filter($steps, fn ($s) => !$s['src'])) $err = 'Each step needs its source: end it with [1], [2]… for the source it comes from.';
            elseif (empty($in['own_words'])) $err = 'Confirm the steps are in our own words and checked against their sources.';
            elseif (($copied = self::copied($pdo, $steps, $g['sources'])) !== '') $err = $copied;
            if ($err !== '' && $g['status'] === 'published') throw new InvalidArgumentException($err);   // a live guide is never changed to something that can't be published
            if ($err !== '') $publish = false;   // not published, but the edit is kept as the draft, so nothing typed is lost
        }
        $status = $publish ? 'published' : ($g['status'] === 'published' && $err === '' ? 'published' : 'draft');
        $pdo->prepare('UPDATE how_guides SET title = ?, intro = ?, steps = ?, status = ?, reviewed_by = ?, published_at = CASE WHEN ? THEN COALESCE(published_at, ?) ELSE published_at END, updated_at = ? WHERE id = ?')
            ->execute([$title, $intro, json_encode($steps, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $status, $uid, $publish ? 1 : 0, self::now(), self::now(), $id]);
        require_once __DIR__ . '/ContentTags.php'; ContentTags::retag($pdo, 'howto:' . $id);   // the Chameleon Filter reads it once it's published (decisions/0132)
        if ($err !== '') throw new InvalidArgumentException($err . ' Your changes are saved as the draft.');
        return ['status' => $status, 'steps' => count($steps)];
    }

    /** May a page's steps be drafted from (the source register: not cite-only, evidence or a pointer, not set to Ignore)? */
    private static function mayUse(PDO $pdo, string $url): bool
    {
        try {
            require_once __DIR__ . '/crawler/Sources.php';
            $host = Sources::host($url);
            if (!Sources::mayStore($pdo, $host)) return false;
            $st = $pdo->prepare('SELECT status FROM ' . Database::t('reference_sources') . ' WHERE host = ?'); $st->execute([$host]);
            return $st->fetchColumn() !== 'ignore';
        } catch (Throwable $e) { return true; }   // before the register: official pages, as before
    }

    /**
     * A step that still reads as its source wrote it, from a source whose licence isn't open (review C14: steps went out
     * word for word from .edu and state pages): the message naming the first, or ''. Open licences (public domain, CC0,
     * CC BY, CC BY-SA) may be quoted, with the source shown as now.
     */
    public static function copied(PDO $pdo, array $steps, array $sources): string
    {
        $words = fn (string $t) => array_values(array_filter(explode(' ', (string) preg_replace('/[^a-z0-9 ]+/', ' ', mb_strtolower($t)))));
        foreach ($steps as $i => $st) {
            $src = $sources[(int) $st['src'] - 1] ?? null;
            if (!$src || empty($src['said'])) continue;   // drafted before its words were kept: the person's word stands
            $licence = 'unknown';
            try { require_once __DIR__ . '/crawler/Sources.php'; $licence = (string) (Sources::rules($pdo, (string) $src['host'])['licence'] ?? 'unknown'); } catch (Throwable $e) {}
            if (in_array($licence, ['public_domain', 'cc0', 'cc_by', 'cc_by_sa'], true)) continue;
            $a = $words((string) $st['text']);
            if (count($a) < 4) continue;   // "Rake the leaves." can only be said one way
            foreach ((array) $src['said'] as $said) {
                $b = $words((string) $said);
                $same = count(array_intersect(array_unique($a), array_unique($b))) / max(1, count(array_unique(array_merge($a, $b))));
                if ($same >= 0.8) return 'Step ' . ($i + 1) . ' reads as ' . $src['host'] . ' wrote it, and its terms don\'t let us copy it: put it in our own words.';
            }
        }
        return '';
    }

    /** Other decisions: unpublish (back to draft), reject (not a guide), look again (back to the crawler), restore. */
    public static function decide(PDO $pdo, int $id, string $do, int $uid): string
    {
        $map = ['unpublish' => "status = 'draft'", 'reject' => "status = 'rejected'", 'again' => "status = 'wanted', requested = 1, next_at = NULL", 'restore' => "status = 'wanted'"];
        if (!isset($map[$do])) throw new InvalidArgumentException('Pick what to do.');
        $pdo->prepare('UPDATE how_guides SET ' . $map[$do] . ', reviewed_by = ?, updated_at = ? WHERE id = ?')->execute([$uid, self::now(), $id]);
        return ['unpublish' => 'Taken down: back to review.', 'reject' => 'Set aside: not a guide.', 'again' => 'Back to the crawler: it looks on its next run.', 'restore' => 'Back in the wanted list.'][$do];
    }

    /** Staff ask for one ("How to winterize a camper"): the crawler looks without waiting for searches. */
    public static function request(PDO $pdo, string $title): int
    {
        $title = self::clean($title, 160);
        if (!preg_match('/^how to\s+\S/i', $title)) $title = 'How to ' . preg_replace('/^how to\s*/i', '', $title);
        $a = self::asks($pdo, $title);
        $key = $a['key'] ?? 'staff:' . mb_substr(trim(preg_replace('/[^a-z0-9]+/', '-', mb_strtolower(preg_replace('/^how to\s+/i', '', $title))), '-'), 0, 70);
        $st = $pdo->prepare('SELECT id FROM how_guides WHERE gkey = ?'); $st->execute([$key]);
        if ($id = (int) $st->fetchColumn()) { $pdo->prepare("UPDATE how_guides SET requested = 1, status = CASE WHEN status IN ('nothing', 'rejected') THEN 'wanted' ELSE status END, updated_at = ? WHERE id = ?")->execute([self::now(), $id]); return $id; }
        $pdo->prepare("INSERT INTO how_guides (gkey, action, thing, title, requested, status, created_at, updated_at) VALUES (?, ?, ?, ?, 1, 'wanted', ?, ?)")
            ->execute([$key, $a['action'] ?? '', $a['thing'] ?? '', ucfirst($title), self::now(), self::now()]);
        return (int) $pdo->lastInsertId();
    }

    /** The published guide for a search, if there is one. */
    public static function forQuery(PDO $pdo, string $q): ?array
    {
        if (!self::ready($pdo)) return null;
        $a = self::asks($pdo, $q);
        if (!$a) return null;
        $st = $pdo->prepare("SELECT id, title, steps FROM how_guides WHERE status = 'published' AND (gkey = ? OR gkey = ?) ORDER BY gkey = ? DESC LIMIT 1");
        $st->execute([$a['key'], $a['action'], $a['key']]);   // "how to compost leaves" falls back to "how to compost"
        $g = $st->fetch(PDO::FETCH_ASSOC);
        return $g ? ['id' => (int) $g['id'], 'title' => $g['title'], 'steps' => count(json_decode((string) $g['steps'], true) ?: [])] : null;
    }
}
