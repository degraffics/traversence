<?php
// app/lib/Clocks.php — Clocks that count only switched-on time (decisions/0164 §6.1, gap review X1; 0163 §10).
// Paused time is read from automation_log (the master's and each workflow's pauses, joined), so a pause never makes finds
// "run out" (AutoImport::exhausted) or every listing fall due at once when automation is switched back on:
//   cutoff($pdo, $wf, $secs)   the moment a record must be older than to be $secs of switched-on time old (unix time):
//                              exact, because working age is monotonic in the record's time
//   sqlTime($pdo, $unix)       that moment in the database's NOW() zone, for "… < '<time>'" in place of NOW() - INTERVAL
//   ramp($pdo, $wf)            0.5 for the 14 days after its workflow (or the master) came back on: the backlog is drained
//                              at half budget (0163 §10.2)
//   backlog($pdo)              each workflow's paused time and what waits, for the switch-on check
// A clock with an absolute due time (next_at) is moved on by the pause at switch-on instead (shiftOnResume).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class Clocks
{
    public const RAMP_DAYS = 14;

    /** Absolute due times moved on by a pause at switch-on: workflow => [[table, column, extra where]]. */
    public const DUE = [
        'W2' => [['identity_jobs', 'next_at', "status = 'queued'"]],
        'W3' => [['crawl_pages', 'next_at', '1 = 1']],
    ];

    private static array $iv = [];

    /** [[from, to]] unix intervals when $wf (or everything) was paused, merged, oldest first; an open one runs to now. */
    public static function paused(PDO $pdo, string $wf = 'all'): array
    {
        if (isset(self::$iv[$wf])) return self::$iv[$wf];
        $raw = [];
        try {
            $st = $pdo->prepare("SELECT kind, ref, paused, at FROM automation_log WHERE (kind = 'master') OR (kind = 'workflow' AND ref = ?) ORDER BY at, id");
            $st->execute([$wf]);
            $open = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $k = $r['kind'] . ':' . $r['ref']; $t = (int) strtotime((string) $r['at'] . ' UTC');
                if ((int) $r['paused']) { $open[$k] ??= $t; }
                elseif (isset($open[$k])) { $raw[] = [$open[$k], $t]; unset($open[$k]); }
            }
            foreach ($open as $t) $raw[] = [$t, time()];
            // a pause from before the log (the switches' seed): the switch's own time
            if (!$raw) {
                $s = $pdo->query("SELECT paused, at FROM automation_switches WHERE kind = 'master' AND ref = 'all'")->fetch(PDO::FETCH_ASSOC);
                if ($s && (int) $s['paused']) $raw[] = [(int) strtotime((string) $s['at'] . ' UTC'), time()];
            }
        } catch (Throwable) {}
        usort($raw, fn ($a, $b) => $a[0] <=> $b[0]);
        $m = [];
        foreach ($raw as [$a, $b]) {
            if ($m && $a <= $m[count($m) - 1][1]) $m[count($m) - 1][1] = max($m[count($m) - 1][1], $b);
            else $m[] = [$a, $b];
        }
        return self::$iv[$wf] = $m;
    }

    public static function forget(): void { self::$iv = []; }

    /** Seconds paused between two moments. */
    public static function pausedBetween(PDO $pdo, string $wf, int $from, int $to): int
    {
        $n = 0;
        foreach (self::paused($pdo, $wf) as [$a, $b]) { $x = max($a, $from); $y = min($b, $to); if ($y > $x) $n += $y - $x; }
        return $n;
    }

    /** The latest moment c with (now - c) - paused(c, now) >= $secs: a record older than c is due. */
    public static function cutoff(PDO $pdo, string $wf, int $secs, ?int $now = null): int
    {
        $now ??= time();
        $c = $now - $secs;
        for ($i = 0; $i < 12; $i++) {   // walks back by the pauses inside the window until it settles
            $next = $now - $secs - self::pausedBetween($pdo, $wf, $c, $now);
            if ($next === $c) break;
            $c = $next;
        }
        return $c;
    }

    /** cutoff() for $days, as a time in the database's own NOW() zone (for SQL in place of NOW() - INTERVAL n DAY). */
    public static function sqlCutoff(PDO $pdo, string $wf, int $days): string
    {
        return self::sqlTime($pdo, self::cutoff($pdo, $wf, $days * 86400));
    }

    public static function sqlTime(PDO $pdo, int $unix): string
    {
        static $off = null;
        if ($off === null) { try { $off = (int) $pdo->query('SELECT TIMESTAMPDIFF(SECOND, UTC_TIMESTAMP(), NOW())')->fetchColumn(); } catch (Throwable) { $off = 0; } }
        return gmdate('Y-m-d H:i:s', $unix + $off);
    }

    /** Working age of a moment, in seconds: time switched on since. */
    public static function age(PDO $pdo, string $wf, int $then): int
    {
        return max(0, time() - $then - self::pausedBetween($pdo, $wf, $then, time()));
    }

    /** 0.5 for RAMP_DAYS after the workflow (or the master) came back on, else 1. */
    public static function ramp(PDO $pdo, string $wf): float
    {
        $last = 0;
        foreach (self::paused($pdo, $wf) as [, $b]) $last = max($last, $b);
        if ($last === 0 || $last >= time() - 1) return 1.0;   // never paused, or paused now (nothing runs)
        return $last > time() - self::RAMP_DAYS * 86400 ? 0.5 : 1.0;
    }

    /** At switch-on: absolute due times of $wf moved on by its last pause, so they don't all fall due at once. */
    public static function shiftOnResume(PDO $pdo, string $wf, int $pausedSecs): int
    {
        $n = 0;
        if ($pausedSecs <= 0) return 0;
        foreach (self::DUE[$wf] ?? [] as [$t, $col, $where]) {
            try { $n += $pdo->exec('UPDATE ' . Database::t($t) . " SET `$col` = `$col` + INTERVAL " . (int) $pausedSecs . " SECOND WHERE $where AND `$col` IS NOT NULL") ?: 0; }
            catch (Throwable $x) { error_log('clocks shift ' . $t . ': ' . $x->getMessage()); }
        }
        return $n;
    }

    /** The last pause's length for a workflow (or the master), when it just ended. */
    public static function lastPause(PDO $pdo, string $wf): int
    {
        self::forget();
        $iv = self::paused($pdo, $wf);
        if (!$iv) return 0;
        [$a, $b] = $iv[count($iv) - 1];
        return $b < time() - 5 ? $b - $a : 0;
    }

    /** For the switch-on check: each workflow's time paused so far and when it was last switched on. */
    public static function backlog(PDO $pdo): array
    {
        require_once __DIR__ . '/Automation.php';
        $out = [];
        foreach (array_keys(Automation::WORKFLOWS) as $wf) {
            $iv = self::paused($pdo, $wf);
            $total = 0; foreach ($iv as [$a, $b]) $total += $b - $a;
            $out[$wf] = ['paused_days' => round($total / 86400, 1), 'since' => $iv ? $iv[count($iv) - 1][0] : 0, 'ramp' => self::ramp($pdo, $wf)];
        }
        return $out;
    }
}
