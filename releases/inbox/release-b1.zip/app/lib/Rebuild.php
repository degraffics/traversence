<?php
// app/lib/Rebuild.php — "Rebuild from its website" (decisions/0083).
//
// An organization with several places (a school district and its schools, a health system and its clinics, a chain's
// stores) is read from its own website, and the listings we have are rebuilt to match, without duplicates or strays:
//
//   read()   reads the site: the organization (its name, main office) and each place it lists, by the name the site
//            gives it in its own list ("Schools", "Locations", "Clinics", "Our stores"…), with the address and phone
//            on that place's page. A place listed with no address of its own is still a place (its address is found
//            later).
//   plan()   matches the listings we have to those places (the ones you picked, the Nexus's, the ones on the same
//            website or phone, and look-alike names in the town): for each place, the listing that becomes it
//            (renamed, gaps filled), any others that are the same place (merged in), or a new listing; listings that
//            match nothing are strays, left as they are unless you say otherwise. All of it under one Nexus.
//   apply()  does what you accepted, line by line, and returns how to undo it.
//
// Nothing a person or the owner entered is replaced; a listing its owner manages is never hidden or merged away.
declare(strict_types=1);

require_once __DIR__ . '/crawler/SiteFetcher.php';
require_once __DIR__ . '/crawler/ListingExtractor.php';
require_once __DIR__ . '/crawler/IntakeStager.php';
require_once __DIR__ . '/crawler/AutoImport.php';
require_once __DIR__ . '/WebIdentity.php';
require_once __DIR__ . '/Identity.php';
require_once __DIR__ . '/ListingBulk.php';
require_once __DIR__ . '/Nexus.php';
require_once __DIR__ . '/AddBusiness.php';   // Claims too

final class Rebuild
{
    /** A site's list of its places: the heading or menu item it sits under. */
    private const LIST_WORDS = 'schools|our\s+schools|campuses|locations?|our\s+locations|offices|clinics|branches|stores|our\s+stores|facilities|sites|centers|centres|find\s+a\s+(?:store|location|clinic|branch)';

    /** Each place's role in the Nexus, from the words in its name. */
    private const ROLE_WORDS = ['campus' => '/\b(school|academy|campus|college|elementary|preschool|kindergarten)\b/i', 'clinic' => '/\b(clinic|health center|medical center|hospital|urgent care)\b/i',
                                'branch' => '/\b(branch|bank|credit union|library)\b/i', 'office' => '/\b(office|department|administration|district office)\b/i'];

    /**
     * Reads an organization's website. Returns ['url', 'brand', 'org' => place, 'places' => [place], 'pages' => n, 'log'].
     * A place: ['name', 'address', 'city', 'state', 'zip', 'phone', 'page', 'role', 'from'].
     */
    public static function read(string $url, array $opts = []): array
    {
        $url = SiteFetcher::normalizeStartUrl($url);
        $private = getenv('TV_FETCH_ALLOW_PRIVATE') === '1';   // local tests only; never set on the server
        $F = new SiteFetcher(['max_pages' => (int) ($opts['max_pages'] ?? 30), 'delay_ms' => $private ? 0 : 400, 'budget_seconds' => 90, 'block_private' => !$private]);
        $got = $F->fetch($url);
        $pages = $got['pages'];
        $log = $got['log'];
        if (!$pages) throw new RuntimeException('The site couldn\'t be read. ' . implode(' ', array_slice($log, -2)));

        // the site's own list of its places, with the names it gives them
        $named = [];   // canonical url => [url, label]
        foreach ($pages as $p) foreach (self::placeLinks((string) $p['html'], (string) $p['url']) as $u => $label) $named[self::canon($u)] ??= [$u, $label];
        $home = self::canon($pages[0]['url']);
        unset($named[$home], $named[self::canon($url)]);
        // pages it lists that the crawl didn't reach
        $have = []; foreach ($pages as $p) $have[self::canon($p['url'])] = true;
        $missing = array_values(array_map(fn ($x) => $x[0], array_filter($named, fn ($x, $k) => !isset($have[$k]), ARRAY_FILTER_USE_BOTH)));
        if ($missing) { $more = $F->fetchPages($missing); $pages = array_merge($pages, $more['pages']); $log = array_merge($log, $more['log']); }
        $byPage = []; foreach ($pages as $p) $byPage[self::canon($p['url'])] = $p;

        $cands = ListingExtractor::extract($pages, $url);
        // an address on most pages (a footer) is the organization's own; one on a single page belongs to that page
        $spread = fn ($c) => count((array) ($c['sources']['address'] ?? []));
        usort($cands, fn ($a, $b) => $spread($b) <=> $spread($a));
        $orgC = $cands[0] ?? null;
        $orgName = trim((string) ($orgC['name'] ?? '')) ?: self::title((string) $pages[0]['html']);
        $org = $orgC ? self::place($orgC, $orgName, (string) $pages[0]['url'], 'headquarters', 'its main office') : ['name' => $orgName, 'address' => '', 'city' => '', 'state' => '', 'zip' => '', 'phone' => '', 'page' => (string) $pages[0]['url'], 'role' => 'headquarters', 'from' => 'its home page'];

        $places = []; $used = [0 => true];
        foreach ($named as $k => [$u, $label]) {
            $best = null; $bestN = PHP_INT_MAX;
            foreach ($cands as $i => $c) {
                if (!$i) continue;   // the organization's own address
                $src = array_map([self::class, 'canon'], array_merge((array) ($c['sources']['address'] ?? []), [(string) ($c['where']['location_page'] ?? '')]));
                if (in_array($k, $src, true) && $spread($c) < $bestN) { $best = $i; $bestN = $spread($c); }
            }
            if ($best !== null) { $used[$best] = true; $places[] = self::place($cands[$best], $label, $u, self::role($label), 'its list, with the address on its page'); continue; }
            // listed, but no street address on its page: its town and anything address-like, from the page itself
            $p = self::loose(isset($byPage[$k]) ? (string) $byPage[$k]['html'] : '', $label);
            $places[] = ['name' => $label, 'address' => $p['address'], 'city' => $p['city'] ?: $org['city'], 'state' => $p['state'] ?: $org['state'], 'zip' => $p['zip'],
                         'phone' => $p['phone'], 'page' => $u, 'role' => self::role($label), 'from' => isset($byPage[$k]) ? 'its list; no street address on its page' : 'its list; its page couldn\'t be read'];
        }
        // addresses found elsewhere on the site, on no listed page: places too, named by their page
        foreach ($cands as $i => $c) {
            if (isset($used[$i])) continue;
            $pg = (string) (($c['sources']['address'] ?? [])[0] ?? '');
            $nm = isset($byPage[self::canon($pg)]) ? self::title((string) $byPage[self::canon($pg)]['html']) : '';
            if ($nm === '' || mb_strtolower($nm) === mb_strtolower($orgName)) $nm = $orgName . ': ' . trim((string) ($c['where']['address'] ?? ''));
            $places[] = self::place($c, $nm, $pg, self::role($nm), 'an address on its page ' . $pg);
        }
        return ['url' => $url, 'brand' => WebIdentity::brand($url), 'org' => $org, 'places' => $places, 'pages' => count($pages), 'log' => $log];
    }

    /** Links under a heading or menu item that names a list of places: [url => the name the site gives it]. */
    public static function placeLinks(string $html, string $base): array
    {
        $out = [];
        $W = self::LIST_WORDS;
        $blocks = [];
        // <h2>Schools</h2> … <ul>…</ul>   and   <a>Schools</a> … <ul>…</ul>   (a footer list, a menu)
        if (preg_match_all('#<(h[1-6]|a|button|span|strong|p)\b[^>]*>\s*(?:<[^>]+>\s*)*(?:' . $W . ')\s*(?:<[^>]+>\s*)*</\1>\s*(?:<(?!ul\b)[^>]+>\s*){0,6}<ul\b[^>]*>(.*?)</ul>#is', $html, $m)) $blocks = $m[2];
        foreach ($blocks as $b) {
            if (!preg_match_all('#<a\b[^>]*href\s*=\s*(["\'])(.*?)\1[^>]*>(.*?)</a>#is', $b, $mm, PREG_SET_ORDER)) continue;
            foreach ($mm as $a) {
                $label = trim(html_entity_decode(strip_tags($a[3]), ENT_QUOTES | ENT_HTML5));
                $u = SiteFetcher::absolute(html_entity_decode($a[2], ENT_QUOTES), $base);
                if ($label === '' || $u === null || mb_strlen($label) > 90) continue;
                if (SiteFetcher::siteKey((string) parse_url($u, PHP_URL_HOST)) !== SiteFetcher::siteKey((string) parse_url($base, PHP_URL_HOST))) continue;
                $out[$u] ??= preg_replace('/\s+/', ' ', $label);
            }
        }
        return $out;
    }

    /**
     * Matches what the site says to the listings we have. $ids: listings picked; $nexusId: a Nexus to rebuild (its
     * listings join the pool). Returns ['nexus' => [id, name, kind, website], 'lines' => […], 'strays' => […]].
     */
    public static function plan(PDO $pdo, array $read, array $ids = [], int $nexusId = 0): array
    {
        $targets = array_merge([$read['org']], $read['places']);
        // the pool: the ones picked, the Nexus's, the same website, the same phone, a look-alike name in the town
        $pool = array_fill_keys(array_filter(array_map('intval', $ids)), true);
        if ($nexusId && Nexus::ready($pdo)) foreach (Nexus::members($pdo, $nexusId) as $m) $pool[$m['id']] = true;
        $brand = (string) $read['brand'];
        if ($brand !== '') {
            $st = $pdo->prepare("SELECT e.id, w.meta_value FROM entity_metadata w JOIN entities e ON e.id = w.entity_id WHERE w.meta_key = 'website' AND w.meta_value LIKE ? AND e.entity_type = 'merchant' LIMIT 300");
            $st->execute(['%' . str_replace(['%', '_'], ['\\%', '\\_'], explode('/', $brand)[0]) . '%']);
            foreach ($st->fetchAll(PDO::FETCH_NUM) as [$id, $w]) { $w = json_decode((string) $w, true); if (is_string($w) && WebIdentity::brand($w) === $brand) $pool[(int) $id] = true; }
        }
        $phones = array_values(array_filter(array_map(fn ($t) => Identity::digits((string) $t['phone']), $targets)));
        if ($phones) {
            $st = $pdo->prepare("SELECT e.id, m.meta_value FROM entity_metadata m JOIN entities e ON e.id = m.entity_id WHERE m.meta_key = 'phone' AND e.entity_type = 'merchant' AND m.meta_value LIKE ?");
            foreach (array_unique($phones) as $ph) { $st->execute(['%' . substr($ph, -4) . '%']); foreach ($st->fetchAll(PDO::FETCH_NUM) as [$id, $v]) if (Identity::digits((string) json_decode((string) $v, true)) === $ph) $pool[(int) $id] = true; }
        }
        $towns = array_values(array_unique(array_filter(array_map(fn ($t) => (string) $t['city'], $targets))));
        foreach ($towns as $town) {
            $st = $pdo->prepare("SELECT e.id, e.name FROM entities e JOIN entity_metadata c ON c.entity_id = e.id AND c.meta_key = 'city' WHERE e.entity_type = 'merchant' AND c.meta_value = ? LIMIT 3000");
            $st->execute([json_encode($town)]);
            foreach ($st->fetchAll(PDO::FETCH_NUM) as [$id, $nm]) foreach ($targets as $t) if (AutoImport::sameName((string) $t['name'], (string) $nm) >= 0.75 || AutoImport::sameName((string) $read['org']['name'], (string) $nm) >= 0.75) { $pool[(int) $id] = true; break; }
        }
        $X = [];
        foreach (array_keys($pool) as $id) if ($e = IntakeStager::existingListing($pdo, (int) $id)) $X[(int) $id] = $e;

        // each listing to the place it is, by evidence: the same street, the same page, its own phone, its name
        $val = fn (array $e, string $k) => is_scalar($e['meta'][$k]['value'] ?? null) ? trim((string) $e['meta'][$k]['value']) : '';
        $num = fn (string $a) => preg_match('/^\s*(\d+)/', $a, $m) ? $m[1] : '';
        $orgPhone = Identity::digits((string) $read['org']['phone']);
        $match = [];   // listing id => [target index, why, score]
        // A listing matches a place when it has the place's name, or when it carries the organization's own name (a
        // registry's legal name on each campus: "Holbrook Unified School Dist 3" at 453 N 7th St) and the place's
        // address, page or phone. A listing with another name of its own at the same address is another place in the
        // same building (a preschool in an elementary school): it is never matched by the address alone.
        $orgName = (string) $read['org']['name'];
        foreach ($X as $id => $e) {
            $best = -1; $bestS = 0; $why = '';
            $a = $val($e, 'address'); $ws = $val($e, 'website'); $ph = Identity::digits($val($e, 'phone'));
            $asOrg = self::sameNamed((string) $e['name'], $orgName);
            foreach ($targets as $ti => $t) {
                $ev = 0; $w = [];
                if ($a !== '' && $t['address'] !== '' && Identity::addr($a) === Identity::addr($t['address'])) { $ev += 4; $w[] = 'the same address'; }
                elseif ($num($a) !== '' && $num($a) === $num($t['address']) && substr((string) $e['primary_zip'], 0, 5) === substr($t['zip'], 0, 5)) { $ev += 3; $w[] = 'the same street number'; }
                if ($ws !== '' && $t['page'] !== '' && WebIdentity::page($ws) === WebIdentity::page($t['page']) && WebIdentity::page($ws) !== $brand) { $ev += 3; $w[] = 'the same page'; }
                if ($ph !== '' && $ph === Identity::digits((string) $t['phone']) && ($ti === 0 || $ph !== $orgPhone)) { $ev += 2; $w[] = 'the same phone'; }
                $named = self::sameNamed((string) $e['name'], (string) $t['name']);
                if ($ti === 0) {
                    // the organization's own office: its name, and its address (or no address to say otherwise)
                    $ok = $named && ($ev >= 2 || $a === '');
                } else {
                    $ok = $named ? true : ($asOrg && $ev >= 2);
                }
                if (!$ok) continue;
                $s = ($named ? 10 : 0) + $ev;
                if ($named) array_unshift($w, $ti === 0 ? 'its name and the office\'s ' . ($ev ? 'details' : '') : 'the same name');
                elseif ($asOrg) array_unshift($w, 'listed under the organization\'s name');
                if ($s > $bestS) { $best = $ti; $bestS = $s; $why = implode(', ', array_filter($w)); }
            }
            if ($best >= 0) $match[$id] = [$best, $why, $bestS];
        }
        // the Nexus: one the listings are already in, the one given, or a new one named for the organization
        $nx = ['id' => 0, 'name' => (string) $read['org']['name'], 'kind' => preg_match('/\b(school|district|county|city|department|health|hospital|tribe|nation|university|college)\b/i', (string) $read['org']['name']) ? 'system' : 'brand', 'website' => $brand !== '' ? 'https://' . $brand : ''];
        $nid = $nexusId;
        if (!$nid) foreach ($X as $id => $e) { $st = $pdo->prepare('SELECT nexus_id FROM entities WHERE id = ?'); $st->execute([$id]); if ($n = (int) $st->fetchColumn()) { $nid = $n; break; } }
        if ($nid && ($n = Nexus::get($pdo, $nid))) $nx = ['id' => $nid, 'name' => (string) $n['name'], 'kind' => (string) $n['kind'], 'website' => (string) $n['website']];

        $card = fn (array $e) => ListingBulk::card($e);
        $lines = [];
        foreach ($targets as $ti => $t) {
            $mine = array_keys(array_filter($match, fn ($m) => $m[0] === $ti));
            // the listing that becomes it: the owner's, then the most filled in, then the oldest
            usort($mine, fn ($a, $b) => [$card($X[$b])['claimed'], $match[$b][2], $card($X[$b])['filled'], -$a] <=> [$card($X[$a])['claimed'], $match[$a][2], $card($X[$a])['filled'], -$b]);
            $keep = $mine[0] ?? 0;
            $sugg = IntakeStager::suggestFor($pdo, ['name' => $t['name'], 'what' => ['offerings' => [], 'description' => '']]);
            $cat = $keep ? (int) $X[$keep]['category_id'] : (int) ($sugg[0]['id'] ?? 0);
            $lines[] = ['key' => 't' . $ti, 'org' => $ti === 0, 'place' => $t, 'keep' => $keep ? $card($X[$keep]) + ['why' => $match[$keep][1]] : null,
                        'merge' => array_map(fn ($id) => $card($X[$id]) + ['why' => $match[$id][1]], array_slice($mine, 1)),
                        'action' => $keep ? 'update' : 'new', 'name' => $t['name'], 'role' => $t['role'],
                        'rename' => $keep && trim((string) $X[$keep]['name']) !== trim((string) $t['name']),
                        'category_id' => $cat, 'categories' => array_values(array_map(fn ($c) => ['id' => (int) $c['id'], 'name' => (string) $c['name']], $sugg))];
        }
        $strays = [];
        // what's left: say why it's here (the same building as a place, the organization's name, a look-alike name)
        foreach ($X as $id => $e) {
            if (isset($match[$id])) continue;
            $a = $val($e, 'address'); $near = '';
            foreach ($targets as $t) if ($a !== '' && $t['address'] !== '' && Identity::addr($a) === Identity::addr($t['address'])) { $near = 'at the same address as ' . $t['name']; break; }
            $strays[] = $card($e) + ['choice' => 'leave', 'why' => $near !== '' ? $near : (AutoImport::sameName((string) $e['name'], $orgName) >= 0.75 ? 'listed under the organization\'s name, at an address its site doesn\'t give' : 'a similar name, on the same website or phone')];
        }
        return ['nexus' => $nx, 'lines' => $lines, 'strays' => $strays, 'url' => $read['url'], 'pages' => $read['pages']];
    }

    /**
     * Does what was accepted. $plan as plan() made it, with each line's choices from the form: accept (bool), name,
     * role, category_id; each stray's choice: leave | hide | merge:<line key> | nexus. Returns ['nexus', 'done' => [lines of
     * what happened], 'undo' => […]].
     */
    public static function apply(PDO $pdo, array $plan, int $admin): array
    {
        $undo = ['do' => 'rebuild', 'steps' => []];
        $done = [];
        try {
            // the Nexus
            $nx = (array) $plan['nexus'];
            $nid = (int) ($nx['id'] ?? 0);
            if (!$nid || !Nexus::get($pdo, $nid)) {
                $nid = Nexus::create($pdo, ['name' => (string) $nx['name'], 'kind' => (string) ($nx['kind'] ?? 'system'), 'website' => (string) ($nx['website'] ?? '')], $admin);
                $undo['steps'][] = ['nexus_created', $nid];
                $done[] = 'Made the Nexus ' . $nx['name'] . '.';
            } elseif (trim((string) ($nx['name'] ?? '')) !== '' && ($cur = Nexus::get($pdo, $nid)) && $cur['name'] !== $nx['name']) {
                $undo['steps'][] = ['nexus_renamed', $nid, (string) $cur['name']];
                $pdo->prepare('UPDATE nexus SET name = ?, updated_at = NOW() WHERE id = ?')->execute([mb_substr((string) $nx['name'], 0, 160), $nid]);
            }
            $keptFor = [];   // line key => listing id it ended as
            foreach ((array) $plan['lines'] as $L) {
                if (empty($L['accept'])) continue;
                $t = (array) $L['place'];
                $name = trim((string) ($L['name'] ?? $t['name'])) ?: (string) $t['name'];
                $role = (string) ($L['role'] ?? 'location');
                if (!empty($L['keep']['id'])) {
                    $id = (int) $L['keep']['id'];
                    $e = IntakeStager::existingListing($pdo, $id);
                    if (!$e) continue;
                    $prev = ['name' => (string) $e['name'], 'nexus' => [(int) ($pdo->query('SELECT nexus_id FROM entities WHERE id = ' . $id)->fetchColumn() ?: 0), (string) ($pdo->query('SELECT nexus_role FROM entities WHERE id = ' . $id)->fetchColumn() ?: '')], 'filled' => []];
                    $prev['aka'] = Aliases::get($pdo, $id);
                    if ($name !== (string) $e['name'] && !SuggestionActions::managed($e)) {
                        $pdo->prepare("UPDATE entities SET name = ?, updated_by_type = 'admin', updated_at = NOW() WHERE id = ?")->execute([mb_substr($name, 0, 255), $id]);
                        Aliases::add($pdo, $id, [(string) $e['name']], 'admin');   // its old name stays findable (a mere spelling isn't kept)
                    }
                    foreach (['address' => $t['address'], 'city' => $t['city'], 'state' => $t['state'], 'phone' => $t['phone'], 'website' => $t['page']] as $k => $v) {
                        $has = $e['meta'][$k]['value'] ?? null;
                        if ((string) $v === '' || ($has !== null && $has !== '' && $has !== [])) continue;
                        if ($k === 'website' && WebIdentity::page((string) $v) === WebIdentity::brand((string) $v) && empty($L['org'])) continue;   // the home page isn't a place's own
                        $prev['filled'][] = $k;
                        self::put($pdo, $id, $k, $k === 'phone' ? Claims::fmtPhone(Identity::digits((string) $v)) : $v);
                    }
                    Nexus::link($pdo, $id, $nid, $role);
                    Identity::syncFromListing($pdo, $id, 'admin', $admin, ['kind' => 'own_site', 'url' => (string) ($plan['url'] ?? ''), 'label' => 'Its own website']);   // read off its site, checked by staff (decisions/0133)
                    $undo['steps'][] = ['updated', $id, $prev];
                    $done[] = '#' . $id . ' is ' . $name . ($prev['filled'] ? ' (filled in ' . implode(', ', $prev['filled']) . ')' : '') . '.';
                    $keptFor[$L['key']] = $id;
                    $others = array_values(array_filter(array_map(fn ($m) => (int) $m['id'], (array) ($L['merge'] ?? []))));
                    if ($others) {
                        $r = ListingBulk::merge($pdo, array_merge([$id], $others), $id, $id, $admin);
                        $undo['steps'][] = ['merged', $r['undo']];
                        $done[] = count($others) . ' more listing' . (count($others) === 1 ? '' : 's') . ' of ' . $name . ' merged into #' . $id . '.';
                    }
                } else {
                    require_once __DIR__ . '/AddBusiness.php';
                    $d = AddBusiness::clean(['name' => $name, 'kind' => 'other', 'category_id' => (int) ($L['category_id'] ?? 0), 'town' => (string) $t['city'], 'state' => (string) $t['state'],
                                             'address' => (string) $t['address'], 'phone' => (string) $t['phone'], 'website' => (string) $t['page']], false, true);
                    $id = AddBusiness::create($pdo, $d, 'admin', ['anyway' => true, 'uid' => (int) $admin]);   // the rebuild's plan, which a person accepted, decided its pairs
                    Nexus::link($pdo, $id, $nid, $role);
                    if (is_file(__DIR__ . '/IdentityJobs.php')) { require_once __DIR__ . '/IdentityJobs.php'; try { if (IdentityJobs::ready($pdo)) IdentityJobs::look($pdo, $id); } catch (Throwable) {} }
                    $undo['steps'][] = ['created', $id];
                    $done[] = 'Listed ' . $name . ' (#' . $id . ').';
                    $keptFor[$L['key']] = $id;
                }
            }
            foreach ((array) $plan['strays'] as $s) {
                $id = (int) $s['id']; $ch = (string) ($s['choice'] ?? 'leave');
                if ($ch === 'hide') {
                    $e = IntakeStager::existingListing($pdo, $id);
                    if (!$e || SuggestionActions::managed($e)) continue;
                    IntakeStager::setSuppressed($pdo, $id, true);
                    $undo['steps'][] = ['hidden', $id, (int) $e['is_suppressed'] === 1];
                    $done[] = 'Hid #' . $id . ' ' . $e['name'] . '.';
                } elseif ($ch === 'nexus') {
                    $was = $pdo->query('SELECT nexus_id, nexus_role FROM entities WHERE id = ' . $id)->fetch(PDO::FETCH_NUM) ?: [null, null];
                    Nexus::link($pdo, $id, $nid, 'location');
                    $undo['steps'][] = ['linked', $id, $was];
                    $done[] = '#' . $id . ' ' . $s['name'] . ' put in the Nexus as it is.';
                } elseif (str_starts_with($ch, 'merge:') && ($into = $keptFor[substr($ch, 6)] ?? 0)) {
                    $r = ListingBulk::merge($pdo, [$into, $id], $into, $into, $admin);
                    $undo['steps'][] = ['merged', $r['undo']];
                    $done[] = '#' . $id . ' ' . $s['name'] . ' merged into #' . $into . '.';
                }
            }
        } catch (Throwable $x) {
            try { self::undo($pdo, $undo); } catch (Throwable $y) { error_log('rebuild rollback: ' . $y->getMessage()); }
            throw $x instanceof InvalidArgumentException ? $x : new RuntimeException('It stopped part way, and what it had done was put back: ' . $x->getMessage(), 0, $x);
        }
        return ['nexus' => $nid, 'done' => $done, 'undo' => $undo];
    }

    /** Puts back what apply() did, last step first. */
    public static function undo(PDO $pdo, array $u): string
    {
        $n = 0;
        foreach (array_reverse((array) ($u['steps'] ?? [])) as $s) {
            switch ($s[0]) {
                case 'merged': ListingBulk::undo($pdo, $s[1]); break;
                case 'created':
                    $pdo->prepare('DELETE FROM entity_metadata WHERE entity_id = ?')->execute([(int) $s[1]]);
                    try { $pdo->prepare('DELETE FROM listing_categories WHERE entity_id = ?')->execute([(int) $s[1]]); } catch (Throwable) {}
                    $pdo->prepare("DELETE FROM entities WHERE id = ? AND status = 'unclaimed'")->execute([(int) $s[1]]);
                    break;
                case 'updated':
                    [, $id, $prev] = $s;
                    $pdo->prepare('UPDATE entities SET name = ?, nexus_id = ?, nexus_role = ? WHERE id = ?')->execute([$prev['name'], $prev['nexus'][0] ?: null, $prev['nexus'][1] ?: null, (int) $id]);
                    foreach ((array) $prev['filled'] as $k) $pdo->prepare('DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = ?')->execute([(int) $id, $k]);
                    if (array_key_exists('aka', $prev)) { if ($prev['aka']) Aliases::set($pdo, (int) $id, $prev['aka'], 'admin'); else $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = 'aka'")->execute([(int) $id]); }
                    Identity::syncFromListing($pdo, (int) $id, 'admin');
                    break;
                case 'hidden': IntakeStager::setSuppressed($pdo, (int) $s[1], (bool) $s[2]); break;
                case 'linked': $pdo->prepare('UPDATE entities SET nexus_id = ?, nexus_role = ? WHERE id = ?')->execute([$s[2][0] ?: null, $s[2][1] ?: null, (int) $s[1]]); break;
                case 'nexus_renamed': $pdo->prepare('UPDATE nexus SET name = ? WHERE id = ?')->execute([$s[2], (int) $s[1]]); break;
                case 'nexus_created':
                    $st = $pdo->prepare('SELECT COUNT(*) FROM entities WHERE nexus_id = ?'); $st->execute([(int) $s[1]]);
                    if (!(int) $st->fetchColumn()) Nexus::remove($pdo, (int) $s[1]);
                    break;
            }
            $n++;
        }
        if (is_file(__DIR__ . '/SearchIndex.php')) {
            require_once __DIR__ . '/SearchIndex.php';
            $ids = []; foreach ((array) ($u['steps'] ?? []) as $s) if (in_array($s[0], ['updated', 'hidden', 'linked'], true)) $ids[] = (int) $s[1];
            try { if ($ids && SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, $ids); } catch (Throwable) {}
        }
        return 'Put back as it was (' . $n . ' change' . ($n === 1 ? '' : 's') . ').';
    }

    // ---- helpers --------------------------------------------------------------------------------------------------

    /**
     * Whether two names are one place's: nearly the same words, and neither has a word of its own beyond legal
     * endings and spellings ("Holbrook Unified School Dist 3" is "Holbrook Unified School District #3";
     * "Holbrook High School-Alternate" is another school, not Holbrook High School).
     */
    public static function sameNamed(string $a, string $b): bool
    {
        // words every school, office or clinic name may carry or leave off ("Park Elementary" is "Park Elementary School")
        $generic = ['school' => 1, 'no' => 1, 'number' => 1, 'inc' => 1];
        $A = array_diff_key(AutoImport::nameWords($a), $generic); $B = array_diff_key(AutoImport::nameWords($b), $generic);
        return $A && $A == $B;
    }

    private static function place(array $c, string $name, string $page, string $role, string $from): array
    {
        return ['name' => trim($name), 'address' => trim((string) ($c['where']['address'] ?? '')), 'city' => trim((string) ($c['where']['city'] ?? '')),
                'state' => trim((string) ($c['where']['state'] ?? '')), 'zip' => substr(trim((string) ($c['where']['zip'] ?? '')), 0, 5),
                'phone' => trim((string) ($c['actions']['phone'] ?? '')), 'page' => $page, 'role' => $role, 'from' => $from];
    }

    /** A place's role from its name. */
    public static function role(string $name): string
    {
        foreach (self::ROLE_WORDS as $role => $re) if (preg_match($re, $name)) return $role;
        return 'location';
    }

    /** A page's own name: its first heading, else its title. */
    private static function title(string $html): string
    {
        foreach (['#<h1\b[^>]*>(.*?)</h1>#is', '#<title\b[^>]*>(.*?)</title>#is'] as $re) if (preg_match($re, $html, $m) && ($t = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES | ENT_HTML5))) !== '') return preg_replace('/\s*[|–-]\s*[^|–-]+$/u', '', $t) ?: $t;
        return '';
    }

    /** From a place's page with no street address: "Town, ST 12345" and the line before it, and a phone. */
    private static function loose(string $html, string $name): array
    {
        $out = ['address' => '', 'city' => '', 'state' => '', 'zip' => '', 'phone' => ''];
        if ($html === '') return $out;
        $lines = ListingExtractor::lines($html);
        foreach ($lines as $i => $l) {
            if (!preg_match('/^(.{2,40}?),\s*([A-Z]{2})\s+(\d{5})(?:-\d{4})?$/', trim($l), $m)) continue;
            $out['city'] = trim($m[1]); $out['state'] = $m[2]; $out['zip'] = $m[3];
            $prev = trim((string) ($lines[$i - 1] ?? ''));
            if ($prev !== '' && mb_strtolower($prev) !== mb_strtolower($name) && mb_strlen($prev) <= 80 && preg_match('/\b(route|rt|hwy|highway|road|rd|junction|jct|mile|milepost|box|bia|us|sr|street|st|ave|avenue|blvd|drive|dr|lane|ln)\b/i', $prev)) $out['address'] = $prev;
            break;
        }
        foreach ($lines as $l) if (preg_match('/\(?\b\d{3}\)?[\s.-]*\d{3}[\s.-]*\d{4}\b/', $l, $m) && ($p = ListingExtractor::phone($m[0]))) { $out['phone'] = $p; break; }
        return $out;
    }

    private static function canon(string $u): string
    {
        return rtrim(strtolower((string) preg_replace(['#^https?://(www\.)?#i', '/[?#].*$/'], '', $u)), '/');
    }

    private static function put(PDO $pdo, int $id, string $k, $v): void
    {
        $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at) VALUES (?, ?, ?, 'admin', 1, NOW(), NOW())
                       ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = 'admin', is_locked = 1, updated_at = NOW()")
            ->execute([$id, $k, json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
    }
}
