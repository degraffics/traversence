<?php
// app/lib/CardScan.php — the business card scanner (decisions/0108): a rep photographs a card (front, and the back
// when it has one); Claude reads it into fields; the rep checks them, picks the category, and saves. It joins the
// listing that's already here (same phone, website or name in town) or becomes a new unclaimed listing, and the
// lead goes to the rep with the visit logged. The photos stay private (staff only), with who, when and where.
// Reading is staff work: it isn't charged to any business's AI Assist credits.
declare(strict_types=1);

require_once __DIR__ . '/AiClient.php';
require_once __DIR__ . '/Sales.php';
require_once __DIR__ . '/AddBusiness.php';

final class CardScan
{
    public const MAX_BYTES = 10 * 1024 * 1024;
    public const FIELDS = ['name' => 'Business', 'person' => 'Name', 'title' => 'Title', 'phone' => 'Phone', 'mobile' => 'Mobile', 'email' => 'Email',
        'website' => 'Website', 'street' => 'Street', 'town' => 'Town', 'state' => 'State', 'zip' => 'ZIP', 'social' => 'Social', 'business_type' => 'What they do', 'other' => 'Also on the card'];

    /** Who may scan: staff with the intake tools, or a regional admin (decisions/0108). */
    public static function mayScan(PDO $pdo, ?array $me): bool
    {
        if (!$me) return false;
        require_once __DIR__ . '/crawler/IntakeStager.php';
        if (IntakeStager::canUseIntake($pdo, $me)) return true;
        try { $st = $pdo->prepare("SELECT 1 FROM " . Database::t('admin_access') . " WHERE user_id = ? AND tier = 'regional_admin' LIMIT 1"); $st->execute([(int) $me['id']]); return (bool) $st->fetchColumn(); } catch (Throwable) { return false; }
    }

    public static function ready(PDO $pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('sales_cards') . ' LIMIT 0'); return AiClient::ready($pdo); } catch (Throwable) { return false; } }

    private static function dir(): string { return __DIR__ . '/../storage/cards'; }
    /** Our own working files (decisions/0124: internal/cards); a scan from before where it was, until it moves. */
    public static function path(int $id, int $side): string { require_once __DIR__ . '/Store.php'; return Store::either(Store::internal('cards', $id . '-' . $side . '.jpg'), self::dir() . '/' . $id . '-' . $side . '.jpg'); }

    /**
     * A new scan, from its front photo as it arrived (api/upload.php, target card_scan). Kept as JPEG (resized to 1600 px
     * and stripped of its metadata when GD is here), then queued to be read, unless $more (the back is on its way:
     * addBack queues it). $at: when it was taken, ISO 8601 with its zone (a card held offline is sent later); $tz: the
     * phone's time zone then, so its time shows where it happened (Jason, 2026-11-10). Returns its id.
     */
    public static function create(PDO $pdo, int $staff, string $file, string $mime, ?float $lat, ?float $lon, string $at = '', bool $more = false, string $tz = ''): int
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run app/migrations/2026-12-20_card_scanner.sql first.');
        $bytes = self::jpeg($file, $mime);
        $t = preg_match('/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}/', $at) ? strtotime($at) : false;   // with its Z or offset it's read as the moment it was
        $when = $t && $t <= time() + 300 && $t > time() - 30 * 86400 ? date('Y-m-d H:i:s', $t) : date('Y-m-d H:i:s');
        $ok = fn (?float $v, float $m) => $v !== null && abs($v) <= $m && $v != 0.0 ? round($v, 6) : null;
        $tz = in_array($tz, timezone_identifiers_list(), true) ? $tz : '';
        if (self::hasTz($pdo)) $pdo->prepare('INSERT INTO ' . Database::t('sales_cards') . ' (staff_id, sides, lat, lon, scanned_at, tz) VALUES (?, 1, ?, ?, ?, ?)')->execute([$staff, $ok($lat, 90), $ok($lon, 180), $when, $tz !== '' ? $tz : null]);
        else $pdo->prepare('INSERT INTO ' . Database::t('sales_cards') . ' (staff_id, sides, lat, lon, scanned_at) VALUES (?, 1, ?, ?, ?)')->execute([$staff, $ok($lat, 90), $ok($lon, 180), $when]);
        $id = (int) $pdo->lastInsertId();
        self::side($id, 1, $bytes);
        if (!$more) self::queue($pdo, $staff, $id);
        return $id;
    }

    /** Whether cards keep the time zone they were scanned in (2027-02-18_card_scan_tz.sql). */
    public static function hasTz(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT tz FROM ' . Database::t('sales_cards') . ' LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    /** A stored time as the exact moment (ISO 8601 with the server's offset), for TvTime to show in the right zone. */
    public static function iso(?string $at): string
    {
        $t = $at ? strtotime($at) : false;
        return $t ? date('c', $t) : '';
    }

    /** The town nearest a point ("Corona, CA"), from our ZIP table; '' when there's none within about 20 miles. */
    public static function townAt(PDO $pdo, ?float $lat, ?float $lon): string
    {
        if ($lat === null || $lon === null) return '';
        try {
            $st = $pdo->prepare('SELECT city, state FROM zip_coordinates WHERE latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?
                                 ORDER BY POW(latitude - ?, 2) + POW(longitude - ?, 2) LIMIT 1');
            $st->execute([$lat - .3, $lat + .3, $lon - .3, $lon + .3, $lat, $lon]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return $r ? trim(ucwords(strtolower((string) $r['city'])) . ', ' . $r['state'], ', ') : '';
        } catch (Throwable) { return ''; }
    }

    /** The back of a card whose front came first (create with $more), then it's queued to be read. */
    public static function addBack(PDO $pdo, int $staff, int $id, string $file, string $mime): void
    {
        $st = $pdo->prepare('SELECT job_id FROM ' . Database::t('sales_cards') . " WHERE id = ? AND staff_id = ? AND status = 'reading'"); $st->execute([$id, $staff]);
        $job = $st->fetchColumn();
        if ($job === false) throw new InvalidArgumentException('That card isn\'t waiting for its back.');
        self::side($id, 2, self::jpeg($file, $mime));
        $pdo->prepare('UPDATE ' . Database::t('sales_cards') . ' SET sides = 2 WHERE id = ?')->execute([$id]);
        if (!$job) self::queue($pdo, $staff, $id);
    }

    /** May this scan come in (the target's check): a front, or the back of the rep's own card still waiting for it. */
    public static function canSend(PDO $pdo, int $staff, int $card): void
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run app/migrations/2026-12-20_card_scanner.sql first.');
        if (!$card) return;
        $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('sales_cards') . " WHERE id = ? AND staff_id = ? AND status = 'reading' AND job_id IS NULL"); $st->execute([$card, $staff]);
        if (!$st->fetchColumn()) throw new InvalidArgumentException('That card isn\'t waiting for its back.');
    }

    private static function side(int $id, int $side, string $bytes): void
    {
        require_once __DIR__ . '/Store.php';
        $p = self::path($id, $side); $cdir = dirname($p);
        if (!is_dir($cdir) && !mkdir($cdir, 0750, true) && !is_dir($cdir)) throw new RuntimeException('The card couldn\'t be stored (storage folder).');
        file_put_contents($p, $bytes); Store::keep($p);   // to S3 (decisions/0123)
    }

    /** Queued, and read at once: seconds, so the rep sees it straight away (the worker catches any left behind). */
    private static function queue(PDO $pdo, int $staff, int $id): void
    {
        $job = AiClient::enqueue($pdo, 'card', $id, $staff);
        $pdo->prepare('UPDATE ' . Database::t('sales_cards') . ' SET job_id = ? WHERE id = ?')->execute([$job, $id]);
        self::read($pdo, $job);
    }

    /** A photo as JPEG: no larger than 1600 px, no camera metadata (location, device). */
    private static function jpeg(string $file, string $mime): string
    {
        if (!function_exists('imagecreatefromstring')) return (string) file_get_contents($file);
        $im = @imagecreatefromstring((string) file_get_contents($file));
        if (!$im) throw new InvalidArgumentException('That photo couldn\'t be opened. Take it again.');
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {   // turn it the right way up
            $o = (int) (@exif_read_data($file)['Orientation'] ?? 1);
            $r = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0;
            if ($r) { $t = imagerotate($im, $r, 0); if ($t) { imagedestroy($im); $im = $t; } }
        }
        [$w, $h] = [imagesx($im), imagesy($im)];
        $k = min(1, 1600 / max($w, $h));
        if ($k < 1) { $t = imagescale($im, (int) round($w * $k), (int) round($h * $k)); if ($t) { imagedestroy($im); $im = $t; } }
        ob_start(); imagejpeg($im, null, 86); imagedestroy($im);
        return (string) ob_get_clean();
    }

    /** Reads the next queued card (or this job): the worker and the upload both call it. Returns the card id, or 0. */
    public static function read(PDO $pdo, int $jobId = 0): int
    {
        $j = AiClient::claim($pdo, $jobId);
        if (!$j) return 0;
        $cid = (int) $j['ref_id'];
        $fail = function (string $why) use ($pdo, $j, $cid): int {
            AiClient::finish($pdo, (int) $j['id'], 'failed', ['error' => $why]);
            $pdo->prepare("UPDATE " . Database::t('sales_cards') . " SET status = 'failed', fields = ? WHERE id = ? AND status = 'reading'")->execute([json_encode(['_error' => $why]), $cid]);
            return $cid;
        };
        if (AiClient::overCap($pdo)) {
            $pdo->prepare("UPDATE " . Database::t('ai_jobs') . " SET status = 'paused', error = 'monthly cap' WHERE id = ?")->execute([(int) $j['id']]);
            $pdo->prepare("UPDATE " . Database::t('sales_cards') . " SET status = 'failed', fields = ? WHERE id = ?")->execute([json_encode(['_error' => 'This month\'s AI limit is reached (AI_MONTHLY_CAP_USD). Fill it in by hand, or raise the limit.']), $cid]);
            return $cid;
        }
        if (AiClient::providerFor('card') === '') return $fail('Card reading isn\'t connected yet (ANTHROPIC_API_KEY). Fill it in by hand.');
        $imgs = [];
        require_once __DIR__ . '/Store.php';
        foreach ([1, 2] as $s) if (($b = Store::read(self::path($cid, $s))) !== '') $imgs[] = ['image/jpeg', $b];
        if (!$imgs) return $fail('The photo is missing.');
        $props = [];
        foreach (array_keys(self::FIELDS) as $k) $props[$k] = ['type' => 'string'];
        $schema = ['type' => 'object', 'properties' => $props, 'required' => array_keys(self::FIELDS), 'additionalProperties' => false];
        $ask = "These photos are the front" . (count($imgs) > 1 ? ' and back' : '') . " of one business card. Read it into the fields. "
            . "name: the business's name. person, title: the person on the card. phone: the main business number; mobile: a cell number if one is marked. "
            . "Write phone numbers as digits with dashes, like 928-555-0142. website: the address as printed. street, town, state (two-letter), zip: the business's address. "
            . "social: any social media handles. business_type: what the business does, in 2 to 5 plain words (like \"auto repair shop\" or \"wedding photographer\"). "
            . "other: anything else printed that matters (licence numbers, hours, a second location). Leave a field empty when the card doesn't show it; never guess.";
        try {
            $r = AiClient::claudeRead($imgs, $ask, $schema, (string) (getenv('AI_CARD_MODEL') ?: 'claude-haiku-5-5'));
        } catch (RuntimeException $x) {
            if ($x->getCode() === 1 && (int) $j['attempts'] < 3) { AiClient::retryLater($pdo, (int) $j['id'], $x->getMessage()); return $cid; }
            return $fail($x->getMessage());
        }
        $f = array_map(fn ($v) => mb_substr(trim((string) $v), 0, 300), array_intersect_key($r['data'], self::FIELDS)) + array_fill_keys(array_keys(self::FIELDS), '');
        $f['state'] = strtoupper(substr($f['state'], 0, 2));
        $f['category_id'] = self::suggestCategory($pdo, $f['business_type'] . ' ' . $f['name']);
        AiClient::finish($pdo, (int) $j['id'], 'done', $r);
        $pdo->prepare("UPDATE " . Database::t('sales_cards') . " SET status = 'ready', fields = ? WHERE id = ? AND status = 'reading'")->execute([json_encode($f, JSON_UNESCAPED_UNICODE), $cid]);
        return $cid;
    }

    /** The closest category for "auto repair shop": the most shared words with a category's plain name. 0 if none. */
    public static function suggestCategory(PDO $pdo, string $what): int
    {
        $words = array_values(array_filter(preg_split('/\W+/u', mb_strtolower($what)), fn ($w) => mb_strlen($w) > 2 && !in_array($w, ['the', 'and', 'shop', 'store', 'services', 'service', 'company', 'llc', 'inc'], true)));
        if (!$words) return 0;
        require_once __DIR__ . '/crawler/IntakeStager.php';
        $best = 0; $score = 0;
        foreach (IntakeStager::leafCategories($pdo) as $c) {
            $n = mb_strtolower($c['plain'] . ' ' . $c['name']); $s = 0;
            foreach ($words as $w) if (preg_match('/\b' . preg_quote(rtrim($w, 's'), '/') . '/u', $n)) $s += mb_strlen($w);
            $s = $s * 100 + min(99, (int) $c['used'] / 10);   // ties go to the category used most
            if ($s > $score) { $score = $s; $best = (int) $c['id']; }
        }
        return $score >= 400 ? $best : 0;   // at least one real word in common
    }

    /** One card for its panel: what was read, the photos, and listings it may already be. */
    public static function get(PDO $pdo, int $id): array
    {
        $st = $pdo->prepare('SELECT c.*, u.display_name AS by_name FROM ' . Database::t('sales_cards') . ' c LEFT JOIN users u ON u.id = c.staff_id WHERE c.id = ?'); $st->execute([$id]);
        $c = $st->fetch(PDO::FETCH_ASSOC);
        if (!$c) throw new InvalidArgumentException('That card isn\'t here.');
        $f = json_decode((string) $c['fields'], true) ?: [];
        $out = ['id' => (int) $c['id'], 'status' => $c['status'], 'sides' => (int) $c['sides'], 'fields' => $f, 'error' => (string) ($f['_error'] ?? ''),
            'by' => (string) $c['by_name'], 'at' => self::iso($c['scanned_at'] ?: $c['created_at']), 'tz' => (string) ($c['tz'] ?? ''), 'where' => $c['lat'] !== null ? $c['lat'] . ',' . $c['lon'] : '',
            'place' => $c['lat'] !== null ? self::townAt($pdo, (float) $c['lat'], (float) $c['lon']) : '',
            'entity_id' => (int) $c['entity_id'], 'matches' => []];
        if ($c['status'] === 'ready' && ($f['name'] ?? '') !== '') {
            try { $out['matches'] = AddBusiness::duplicates($pdo, self::listingData($f, false)); } catch (Throwable) {}
        }
        return $out;
    }

    /** The rep's recent cards, newest first. */
    public static function mine(PDO $pdo, int $staff, int $limit = 30): array
    {
        $st = $pdo->prepare("SELECT c.id, c.status, c.fields, c.entity_id, c.scanned_at, c.created_at" . (self::hasTz($pdo) ? ', c.tz' : '') . ", e.name AS listing FROM " . Database::t('sales_cards') . " c LEFT JOIN entities e ON e.id = c.entity_id
                              WHERE c.staff_id = ? AND c.status <> 'discarded' ORDER BY c.id DESC LIMIT " . (int) $limit);
        $st->execute([$staff]);
        return array_map(function ($r) { $f = json_decode((string) $r['fields'], true) ?: [];
            return ['id' => (int) $r['id'], 'status' => $r['status'], 'name' => (string) ($r['listing'] ?: ($f['name'] ?? '')), 'person' => (string) ($f['person'] ?? ''),
                'town' => (string) ($f['town'] ?? ''), 'entity_id' => (int) $r['entity_id'], 'at' => self::iso($r['scanned_at'] ?: $r['created_at']), 'tz' => (string) ($r['tz'] ?? ''), 'error' => (string) ($f['_error'] ?? '')]; },
            $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /** The form's fields in AddBusiness's shape. */
    private static function listingData(array $f, bool $strict): array
    {
        $in = ['name' => $f['name'] ?? '', 'category_id' => (int) ($f['category_id'] ?? 0), 'town' => $f['town'] ?? '', 'state' => $f['state'] ?? '',
            'address' => $f['street'] ?? '', 'phone' => ($f['phone'] ?? '') !== '' ? $f['phone'] : ($f['mobile'] ?? ''), 'email' => $f['email'] ?? '',
            'website' => self::url((string) ($f['website'] ?? '')), 'kind' => 'other'];
        if (!$strict) {   // only to look for the same business: whatever is missing mustn't stop the look
            $in['category_id'] = $in['category_id'] ?: 1;
            if (trim((string) $in['town']) === '') $in['town'] = '-';
            if (!filter_var($in['email'], FILTER_VALIDATE_EMAIL)) $in['email'] = '';
        }
        return AddBusiness::clean($in, false, true);
    }

    private static function url(string $w): string { $w = trim($w); return $w === '' || preg_match('#^https?://#i', $w) ? $w : 'https://' . $w; }

    /**
     * Saves the checked card. $use: an existing listing it is (0 for a new one); $anyway: add it even though it looks
     * like one already here. The lead goes to the rep, the visit is logged with who they met and what's on the card.
     * $lead false (Save as a listing, Jason 2026-11-09): only the listing is made or joined; no lead, no visit (a receipt,
     * a menu or a sign from a place visited as a customer). Returns ['entity_id' => …] or ['duplicates' => […]].
     */
    public static function save(PDO $pdo, int $staff, int $id, array $f, int $use = 0, bool $anyway = false, string $outcome = 'met', string $next = '', bool $lead = true): array
    {
        $c = self::get($pdo, $id);
        if ($c['status'] === 'saved') throw new InvalidArgumentException('This card is saved already.');
        $f = array_map(fn ($v) => is_string($v) ? mb_substr(trim($v), 0, 300) : $v, array_intersect_key($f, self::FIELDS + ['category_id' => 1]));
        $who = trim(($f['person'] ?? '') . (($f['title'] ?? '') !== '' ? ', ' . $f['title'] : ''));
        $note = 'Business card' . ($who !== '' ? ' from ' . $who : '') . '.'
            . (($f['mobile'] ?? '') !== '' && ($f['mobile'] ?? '') !== ($f['phone'] ?? '') ? ' Mobile ' . $f['mobile'] . '.' : '')
            . (($f['email'] ?? '') !== '' ? ' Email ' . $f['email'] . '.' : '') . (($f['social'] ?? '') !== '' ? ' Social: ' . $f['social'] . '.' : '')
            . (($f['other'] ?? '') !== '' ? ' ' . $f['other'] : '');
        if (!isset(Sales::OUTCOMES[$outcome]) || $outcome === 'note') $outcome = 'met';
        if ($use) {
            $st = $pdo->prepare("SELECT id FROM entities WHERE id = ? AND entity_type = 'merchant'"); $st->execute([$use]);
            if (!$st->fetchColumn()) throw new InvalidArgumentException('That listing is gone.');
            $eid = $use;
        } else {
            if ((int) ($f['category_id'] ?? 0) <= 0) throw new InvalidArgumentException('Choose its category.');
            if (trim((string) ($f['town'] ?? '')) === '') throw new InvalidArgumentException('Which town is it in?');
            $d = self::listingData($f, true);
            if (!$anyway && ($dups = AddBusiness::duplicates($pdo, $d))) return ['duplicates' => $dups];
            try { $eid = AddBusiness::create($pdo, $d, 'admin', ['anyway' => $anyway]); }
            catch (InvalidArgumentException $x) {   // the very same name and address is listed already: the card joins it
                $st = $pdo->prepare("SELECT id FROM entities WHERE entity_type = 'merchant' AND LOWER(name) = LOWER(?) ORDER BY id LIMIT 1"); $st->execute([$d['name']]);
                if (!($eid = (int) $st->fetchColumn())) throw $x;
            }
            if (is_file(__DIR__ . '/IdentityJobs.php')) {   // the crawler looks up the rest, as for one added from the field
                require_once __DIR__ . '/IdentityJobs.php';
                try { if (IdentityJobs::ready($pdo)) IdentityJobs::look($pdo, $eid); } catch (Throwable $x) { error_log('card look: ' . $x->getMessage()); }
            }
        }
        if ($lead && Sales::ready($pdo)) {
            $pdo->prepare("INSERT IGNORE INTO " . Database::t('prospects') . " (entity_id, owner_id, source) VALUES (?, ?, 'card')")->execute([$eid, $staff]);
            $pdo->prepare('UPDATE ' . Database::t('prospects') . ' SET owner_id = COALESCE(owner_id, ?) WHERE entity_id = ?')->execute([$staff, $eid]);
            Sales::log($pdo, $staff, $eid, 'visit', $outcome, $note, $next, $who !== '' ? $who : null);
        }
        $f['_saved_as'] = $lead ? 'lead' : 'listing';
        $pdo->prepare("UPDATE " . Database::t('sales_cards') . " SET status = 'saved', fields = ?, entity_id = ?, saved_at = NOW() WHERE id = ?")->execute([json_encode($f, JSON_UNESCAPED_UNICODE), $eid, $id]);
        return ['entity_id' => $eid];
    }

    public static function discard(PDO $pdo, int $id): void
    {
        $pdo->prepare("UPDATE " . Database::t('sales_cards') . " SET status = 'discarded' WHERE id = ? AND status <> 'saved'")->execute([$id]);
        require_once __DIR__ . '/Store.php';
        foreach ([1, 2] as $s) Store::remove(self::path($id, $s));
    }

    /** Reads it again (after the key is added, or the limit raised). */
    public static function retry(PDO $pdo, int $staff, int $id): void
    {
        $c = self::get($pdo, $id);
        $st = $pdo->prepare('SELECT job_id FROM ' . Database::t('sales_cards') . ' WHERE id = ?'); $st->execute([$id]);
        if (!in_array($c['status'], ['failed', 'ready'], true) && $st->fetchColumn()) throw new InvalidArgumentException('It\'s being read now.');   // (no job: its back never came; read the front)
        $job = AiClient::enqueue($pdo, 'card', $id, $staff);
        $pdo->prepare("UPDATE " . Database::t('sales_cards') . " SET status = 'reading', job_id = ?, fields = NULL WHERE id = ?")->execute([$job, $id]);
    }

    /** Fill in by hand: a card that couldn't be read becomes ready with empty fields. */
    public static function byHand(PDO $pdo, int $id): void
    {
        $pdo->prepare("UPDATE " . Database::t('sales_cards') . " SET status = 'ready', fields = ? WHERE id = ? AND status = 'failed'")->execute([json_encode(array_fill_keys(array_keys(self::FIELDS), '') + ['category_id' => 0]), $id]);
    }
}
