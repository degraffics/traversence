<?php

declare(strict_types=1);

/**
 * api/lib/crawler/SiteFetcher.php — Listing Intake, step 1 of 3 (spec Section 31).
 *
 * Fetches the pages of ONE website, polite and bounded. It has no database access
 * and no Traversence dependencies, so the same class runs unchanged on BlueHost now
 * (admin-triggered, one site at a time — the narrow §12.3 exception logged in §31)
 * and on the offsite VPS later.
 *
 * Rules:
 *   - same site only (example.com and www.example.com count as one), http/https only
 *   - honors robots.txt (User-agent: * and TraversenceBot groups; Disallow/Allow prefixes)
 *   - page cap, per-request delay, overall time budget, per-page size cap
 *   - HTML only; asset/document links are skipped without being requested
 *   - refuses hosts that resolve to private/reserved IPs (no SSRF into the server's own network)
 *
 * fetch() returns ['pages' => [['url','status','html'], ...], 'log' => [...]].
 */
final class SiteFetcher
{
    public const USER_AGENT = 'TraversenceBot/0.1 (+https://traversence.com/)';

    private const SKIP_EXT = '/\.(jpe?g|png|gif|webp|svg|ico|bmp|tiff?|pdf|docx?|xlsx?|pptx?|zip|rar|7z|gz|mp3|mp4|mov|avi|wmv|webm|css|js|json|xml|txt|woff2?|ttf|eot)$/i';

    private int $maxPages;
    private int $delayMs;
    private int $budgetSeconds;
    private int $maxBytes;
    private bool $blockPrivate;

    /** @var array{allow:string[],disallow:string[]} */
    private array $robots = ['allow' => [], 'disallow' => []];
    /** Why the site stopped us ('' when it didn't): its caller holds the site for a person (EngineCase::blockedSite). */
    public string $blocked = '';
    private array $log = [];
    private int $priorityCount = 0;
    private array $menuPages = [];   // pages listed under a Locations menu
    private const PRIORITY_PATH = '#(locat|contact|office|clinic|branch|find-?us|visit|directions|our-?stores|where-?we|service-?area)#i';

    public function __construct(array $opts = [])
    {
        $this->maxPages      = max(1, min(50, (int) ($opts['max_pages'] ?? 20)));
        $this->delayMs       = max(0, (int) ($opts['delay_ms'] ?? 500));
        $this->budgetSeconds = max(10, (int) ($opts['budget_seconds'] ?? 75));
        $this->maxBytes      = (int) ($opts['max_bytes'] ?? 1_500_000);
        $this->blockPrivate  = (bool) ($opts['block_private'] ?? true); // false only for local tests
    }

    /** Normalizes an admin-typed URL ("example.com/x" -> "https://example.com/x"). Throws if unusable. */
    /** Sites never crawled: their terms forbid it (decisions/0133: Facebook, Instagram and the like are links on a listing). */
    public const NEVER_CRAWL = '/(^|\.)(facebook\.com|fb\.com|fb\.me|instagram\.com|twitter\.com|x\.com|tiktok\.com|linkedin\.com|yelp\.com|google\.com|goo\.gl)$/';

    public static function normalizeStartUrl(string $url): string
    {
        $url = trim($url);
        if ($url !== '' && !preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        $p = parse_url($url);
        if ($p === false || empty($p['host']) || !in_array(strtolower($p['scheme'] ?? ''), ['http', 'https'], true)) {
            throw new InvalidArgumentException('Enter a valid website address (http or https).');
        }
        $h = strtolower((string) $p['host']);
        if (!preg_match('/\.[a-z]{2,}$/', $h)) throw new InvalidArgumentException('That isn\'t a website address (it needs a name like example.com). A phone number goes on the listing instead.');
        if (preg_match(self::NEVER_CRAWL, $h)) throw new InvalidArgumentException('We never crawl social media (their terms forbid it): link the page on the listing instead.');
        return strtolower($p['scheme']) . '://' . strtolower($p['host'])
            . (isset($p['port']) ? ':' . $p['port'] : '') . ($p['path'] ?? '/') . (isset($p['query']) ? '?' . $p['query'] : '');
    }

    /** "www.example.com" -> "example.com" */
    public static function siteKey(string $host): string
    {
        return preg_replace('/^www\./i', '', strtolower($host));
    }

    public function fetch(string $startUrl): array
    {
        $startUrl = self::normalizeStartUrl($startUrl);
        $site = self::siteKey((string) parse_url($startUrl, PHP_URL_HOST));
        $this->assertPublicHost((string) parse_url($startUrl, PHP_URL_HOST));

        $deadline = microtime(true) + $this->budgetSeconds;
        // a site that blocks us is held for a person's Reactivate (decisions/0164 §1.2, P1-2): not fetched again by itself
        try { require_once __DIR__ . '/../EngineCase.php'; if (($held = EngineCase::siteHeld(Database::connection(), $startUrl)) !== null) { $this->log[] = 'Held: ' . $held; return ['pages' => [], 'log' => $this->log, 'location_pages' => [], 'held' => true]; } } catch (Throwable) {}
        $this->loadRobots($startUrl);

        $queue = [$startUrl];
        $this->priorityCount = 0;
        $seen = [$this->canonical($startUrl) => true];
        $pages = [];

        while ($queue && count($pages) < $this->maxPages) {
            if (microtime(true) > $deadline) {
                $this->log[] = 'Stopped: time budget reached (' . $this->budgetSeconds . 's).';
                break;
            }
            $url = array_shift($queue);
            $path = (string) (parse_url($url, PHP_URL_PATH) ?: '/');
            if (!$this->robotsAllows($path)) {
                $this->log[] = "Skipped (robots.txt): $url";
                continue;
            }
            if ($pages) {
                usleep($this->delayMs * 1000);
            }

            $res = $this->get($url);
            if ($res['error'] !== null) {
                $this->log[] = "Failed: $url — {$res['error']}";
                continue;
            }
            // A redirect may leave the site; only keep pages that stayed on it.
            $finalHost = self::siteKey((string) parse_url($res['final_url'], PHP_URL_HOST));
            if ($finalHost !== $site) {
                $this->log[] = "Skipped (redirected off-site): $url";
                continue;
            }
            if (in_array((int) $res['status'], [401, 403, 406, 418, 451], true)) {   // it blocks us (P1-2): held for a person, no more pages from it
                $this->log[] = "Blocked (HTTP {$res['status']}): $url: held for a person's Reactivate";
                $this->blocked = 'answered ' . (int) $res['status'];
                break;
            }
            if ($res['status'] >= 400 || stripos($res['type'], 'html') === false) {
                $this->log[] = "Skipped (HTTP {$res['status']}, {$res['type']}): $url";
                continue;
            }

            $pages[] = ['url' => $res['final_url'], 'status' => $res['status'], 'html' => $res['body']];
            $this->log[] = "Fetched: {$res['final_url']}";
            $seen[$this->canonical($res['final_url'])] = true;

            $menu = array_flip(self::locationMenuLinks($res['body'], $res['final_url']));
            foreach ($menu as $mu => $_) $this->menuPages[$this->canonical($mu)] = $mu;
            foreach (self::links($res['body'], $res['final_url']) as $link) {
                $c = $this->canonical($link);
                if (isset($seen[$c])) continue;
                if (self::siteKey((string) parse_url($link, PHP_URL_HOST)) !== $site) continue;
                if (preg_match(self::SKIP_EXT, (string) parse_url($link, PHP_URL_PATH))) continue;
                $seen[$c] = true;
                // Location and contact pages go first: a business with several locations usually lists them
                // there, and the page limit must never cut them off.
                if (isset($menu[$link]) || preg_match(self::PRIORITY_PATH, (string) parse_url($link, PHP_URL_PATH))) array_splice($queue, $this->priorityCount++, 0, [$link]);
                else $queue[] = $link;
            }
        }
        if ($queue && count($pages) >= $this->maxPages) {
            $this->log[] = 'Stopped: page cap reached (' . $this->maxPages . '); ' . count($queue) . ' link(s) not visited.';
        }
        if ($this->blocked !== '' && !$pages) { try { require_once __DIR__ . '/../EngineCase.php'; EngineCase::blockedSite(Database::connection(), $startUrl, $this->blocked, 'a page read by the site'); } catch (Throwable) {} }
        return ['pages' => $pages, 'log' => $this->log, 'location_pages' => array_values($this->menuPages)];
    }

    /**
     * Fetches these pages of one site, as fetch() would (robots.txt, the delay, the time budget, nothing off-site): for
     * pages a site lists by name that the crawl didn't reach (decisions/0083's Rebuild). Returns [pages, log].
     */
    public function fetchPages(array $urls): array
    {
        $urls = array_values(array_unique(array_filter($urls)));
        if (!$urls) return ['pages' => [], 'log' => []];
        $site = self::siteKey((string) parse_url($urls[0], PHP_URL_HOST));
        $this->assertPublicHost((string) parse_url($urls[0], PHP_URL_HOST));
        $this->loadRobots($urls[0]);
        $deadline = microtime(true) + $this->budgetSeconds;
        $pages = []; $log = [];
        foreach (array_slice($urls, 0, $this->maxPages) as $i => $url) {
            if (microtime(true) > $deadline) { $log[] = 'Stopped: time budget reached.'; break; }
            if (self::siteKey((string) parse_url($url, PHP_URL_HOST)) !== $site) continue;
            if (!$this->robotsAllows((string) (parse_url($url, PHP_URL_PATH) ?: '/'))) { $log[] = "Skipped (robots.txt): $url"; continue; }
            if ($i) usleep($this->delayMs * 1000);
            $res = $this->get($url);
            if ($res['error'] !== null || $res['status'] >= 400 || stripos($res['type'], 'html') === false) { $log[] = "Failed: $url"; continue; }
            if (self::siteKey((string) parse_url($res['final_url'], PHP_URL_HOST)) !== $site) { $log[] = "Skipped (redirected off-site): $url"; continue; }
            $pages[] = ['url' => $res['final_url'], 'status' => $res['status'], 'html' => $res['body']];
            $log[] = "Fetched: {$res['final_url']}";
        }
        return ['pages' => $pages, 'log' => $log];
    }

    /**
     * Links inside a "Locations" (or "Offices", "Clinics", "Find us") menu: a site's navigation often lists each
     * location as its own page by town name (/snowflake, /taylor), with nothing in the address saying "location".
     * Covers the usual menu markup: the menu item's link, then its sub-list.
     */
    public static function locationMenuLinks(string $html, string $baseUrl): array
    {
        $out = [];
        if (!preg_match_all('#<a\b[^>]*>\s*(?:<[^>]+>\s*)*(?:our\s+)?(?:locations?|offices|clinics|branches|find\s+us|where\s+to\s+find\s+us|schools|campuses|stores|facilities)\s*(?:<[^>]+>\s*)*</a>\s*(?:<[^>]+>\s*){0,4}?<ul\b[^>]*>(.*?)</ul>#is', $html, $m)) return $out;
        foreach ($m[1] as $sub) {
            foreach (self::links('<x>' . $sub . '</x>', $baseUrl) as $u) $out[] = $u;
        }
        return array_values(array_unique($out));
    }

    /** Absolute same-document-stripped links found in <a href>. */
    public static function links(string $html, string $baseUrl): array
    {
        $out = [];
        if (!preg_match_all('/<a\s[^>]*href\s*=\s*(["\'])(.*?)\1/is', $html, $m)) {
            return $out;
        }
        foreach ($m[2] as $href) {
            $abs = self::absolute(html_entity_decode(trim($href), ENT_QUOTES | ENT_HTML5), $baseUrl);
            if ($abs !== null) $out[] = $abs;
        }
        return array_values(array_unique($out));
    }

    public static function absolute(string $href, string $base): ?string
    {
        if ($href === '' || $href[0] === '#' || preg_match('/^(mailto|tel|javascript|sms|data|whatsapp):/i', $href)) {
            return null;
        }
        $href = preg_replace('/#.*$/', '', $href);
        if (preg_match('#^https?://#i', $href)) return $href;
        $b = parse_url($base);
        $origin = $b['scheme'] . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
        if (str_starts_with($href, '//')) return $b['scheme'] . ':' . $href;
        if ($href[0] === '/') return $origin . $href;
        $dir = preg_replace('#/[^/]*$#', '/', $b['path'] ?? '/');
        $path = $dir . $href;
        // resolve ./ and ../
        $parts = [];
        foreach (explode('/', $path) as $seg) {
            if ($seg === '..') { array_pop($parts); continue; }
            if ($seg !== '.') $parts[] = $seg;
        }
        return $origin . implode('/', $parts);
    }

    private function canonical(string $url): string
    {
        $p = parse_url($url);
        $path = rtrim($p['path'] ?? '/', '/') ?: '/';
        return self::siteKey($p['host'] ?? '') . strtolower($path) . (isset($p['query']) ? '?' . $p['query'] : '');
    }

    private function assertPublicHost(string $host): void
    {
        if (!$this->blockPrivate) return;
        $ips = gethostbynamel($host) ?: [];
        if (!$ips) {
            throw new RuntimeException("Could not resolve $host.");
        }
        foreach ($ips as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                throw new RuntimeException("Refusing to crawl $host: it resolves to a private or reserved address.");
            }
        }
    }

    private function loadRobots(string $startUrl): void
    {
        $p = parse_url($startUrl);
        $res = $this->get($p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') . '/robots.txt');
        if ($res['error'] !== null || $res['status'] >= 400) {
            $this->log[] = 'robots.txt: none found (all pages allowed).';
            return;
        }
        $groups = [];     // agent => rules
        $agents = [];
        $lastWasRule = false;
        foreach (preg_split('/\r?\n/', $res['body']) as $line) {
            $line = trim(preg_replace('/#.*$/', '', $line));
            if (!preg_match('/^([A-Za-z-]+)\s*:\s*(.*)$/', $line, $m)) continue;
            $field = strtolower($m[1]);
            $val = trim($m[2]);
            if ($field === 'user-agent') {
                if ($lastWasRule) { $agents = []; $lastWasRule = false; }
                $agents[] = strtolower($val);
                continue;
            }
            if ($field === 'allow' || $field === 'disallow') {
                $lastWasRule = true;
                foreach ($agents as $a) {
                    if ($val !== '') $groups[$a][$field][] = $val;
                }
            }
        }
        $mine = $groups['traversencebot'] ?? $groups['*'] ?? [];
        $this->robots = ['allow' => $mine['allow'] ?? [], 'disallow' => $mine['disallow'] ?? []];
        $this->log[] = 'robots.txt: ' . count($this->robots['disallow']) . ' disallow rule(s) apply.';
    }

    /** Longest matching rule wins; Allow wins ties (Google's documented behavior). Supports * and $. */
    private function robotsAllows(string $path): bool
    {
        $best = 0;
        $allowed = true;
        foreach (['disallow' => false, 'allow' => true] as $kind => $verdict) {
            foreach ($this->robots[$kind] as $rule) {
                $re = '#^' . str_replace(['\*', '\$'], ['.*', '$'], preg_quote($rule, '#')) . '#';
                if (preg_match($re, $path) && (strlen($rule) > $best || (strlen($rule) === $best && $verdict))) {
                    $best = strlen($rule);
                    $allowed = $verdict;
                }
            }
        }
        return $allowed;
    }

    /**
     * GET with redirects followed by hand, so a redirect can never lead the crawler off the
     * site (or to an internal address) before we've looked at where it points.
     * @return array{status:int,type:string,body:string,final_url:string,error:?string}
     */
    private function get(string $url): array
    {
        $site = self::siteKey((string) parse_url($url, PHP_URL_HOST));
        for ($hop = 0; $hop <= 5; $hop++) {
            $res = $this->request($url);
            if ($res['error'] !== null || $res['status'] < 300 || $res['status'] >= 400 || $res['location'] === null) {
                unset($res['location']);
                return $res + ['final_url' => $url];
            }
            $next = self::absolute($res['location'], $url);
            if ($next === null || self::siteKey((string) parse_url($next, PHP_URL_HOST)) !== $site) {
                return ['status' => $res['status'], 'type' => '', 'body' => '', 'final_url' => $url, 'error' => 'redirects off-site'];
            }
            $url = $next;
        }
        return ['status' => 0, 'type' => '', 'body' => '', 'final_url' => $url, 'error' => 'too many redirects'];
    }

    private function request(string $url): array
    {
        $body = '';
        $location = null;
        $tooBig = false;
        $max = $this->maxBytes;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_PROTOCOLS      => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_USERAGENT      => self::USER_AGENT,
            CURLOPT_ENCODING       => '',
            CURLOPT_HTTPHEADER     => ['Accept: text/html,application/xhtml+xml;q=0.9,*/*;q=0.5'],
            CURLOPT_HEADERFUNCTION => static function ($ch, string $h) use (&$location): int {
                if (preg_match('/^Location:\s*(.+)$/i', trim($h), $m)) $location = trim($m[1]);
                return strlen($h);
            },
            CURLOPT_WRITEFUNCTION  => static function ($ch, string $chunk) use (&$body, &$tooBig, $max): int {
                if (strlen($body) + strlen($chunk) > $max) { $tooBig = true; return 0; }
                $body .= $chunk;
                return strlen($chunk);
            },
        ]);
        curl_exec($ch);
        $err = curl_errno($ch) ? curl_error($ch) : null;
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $type = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);
        if ($tooBig) $err = 'page larger than ' . round($max / 1e6, 1) . ' MB';
        return ['status' => $status, 'type' => $type, 'body' => $body, 'error' => $err, 'location' => $location];
    }
}
