<?php

declare(strict_types=1);

require_once __DIR__ . '/Claims.php';
require_once __DIR__ . '/CrawlerIngest.php';

/**
 * app/lib/AddBusiness.php — adding a business (decisions/0071).
 *
 * The owner, signed in with a confirmed email and a phone on their account, fills a short form. We check for a listing
 * that's already theirs (same phone or website, or a similar name in the same town), email a code, and when the code is
 * confirmed the listing is created and opened as a claim: Managed by owner, live, noindex until verified. From there it is
 * an ordinary claim (decisions/0070): Notices, disputes, "Send verification request" (VerifyRequests) or the text code.
 *
 * Staff use create() too, from a visitor's suggestion in Review: the listing is unclaimed, and whoever sent the suggestion
 * is told it's on the site.
 */
final class AddBusiness
{
    /** "What it is": plain choices, each mapped to a top-level directory category (staff refine it later). */
    public const KINDS = [
        'food'      => ['Food & drink', 'Food & Dining'],
        'lodging'   => ['Lodging & camping', 'Hospitality & Lodging'],
        'shops'     => ['Shops', 'Retail & Shopping'],
        'services'  => ['Services', 'Professional Services'],
        'outdoors'  => ['Outdoors & guides', 'Entertainment & Recreation'],
        'arts'      => ['Arts & culture', 'Entertainment & Recreation'],
        'health'    => ['Health & care', 'Health & Medical'],
        'auto'      => ['Auto & repair', 'Automotive & Repair'],
        'farm'      => ['Farm & ranch', 'Agriculture & Farming'],
        'events'    => ['Events & venues', 'Entertainment & Recreation'],
        'community' => ['Community & churches', 'Non-Profit & Community'],
        'other'     => ['Something else', 'Other'],
    ];
    private const DRAFT = 'tv_add_business';   // the form, kept in the session while the email code is out

    /** What the account still needs before it can add or claim: email (confirmed), phone, and Claims' own (age, Verification). */
    public static function needs(PDO $pdo, int $uid): array
    {
        return Claims::missing($pdo, $uid);   // the same as claiming: confirmed email, phone, 18+, Verification
    }

    public static function accountPhone(PDO $pdo, int $uid): string
    {
        $st = $pdo->prepare('SELECT phone FROM users WHERE id = ?');
        $st->execute([$uid]);
        return (string) $st->fetchColumn();
    }

    /** Saves the phone on the account (private; staff see it on verification requests). */
    public static function setAccountPhone(PDO $pdo, int $uid, string $phone): void
    {
        $p = Claims::phone10($phone);
        if ($p === '') throw new InvalidArgumentException('Enter a 10-digit phone number.');
        $pdo->prepare('UPDATE users SET phone = ?, updated_at = NOW() WHERE id = ?')->execute([$p, $uid]);
    }

    /** Checks and tidies the form. Throws InvalidArgumentException with a plain reason. The business email is required of
     *  an owner ($needEmail), optional when staff create it from Review. */
    public static function clean(array $in, bool $needEmail = true, bool $staff = false): array
    {
        // $staff (Admin → Add a listing): the crawler finds the phone, website and the rest, so only the name, the
        // category and the town are needed; the exact category comes as category_id.
        $t = fn (string $k, int $max) => mb_substr(trim(strip_tags((string) ($in[$k] ?? ''))), 0, $max);
        $d = ['name' => $t('name', 120), 'kind' => (string) ($in['kind'] ?? ''), 'town' => $t('town', 80), 'state' => strtoupper($t('state', 2)) ?: 'AZ',
              'phone' => Claims::phone10((string) ($in['phone'] ?? '')), 'email' => strtolower($t('email', 160)), 'address' => $t('address', 160), 'point' => $t('point', 40),
              'facebook' => $t('facebook', 300), 'website' => $t('website', 300), 'hours' => $t('hours', 300), 'offers' => $t('offers', 1000),
              'also_cat' => array_slice(array_values(array_unique(array_filter(array_map('intval', (array) ($in['also_cat'] ?? []))))), 0, 4)];   // the + categories (decisions/0073)
        if ($d['name'] === '') throw new InvalidArgumentException('What is the business called?');
        $d['category_id'] = $staff ? (int) ($in['category_id'] ?? 0) : 0;
        if ($staff && $d['category_id'] <= 0) throw new InvalidArgumentException('Choose its category.');
        if ($staff && !isset(self::KINDS[$d['kind']])) $d['kind'] = 'other';
        // an owner who picked the exact kind with + needn't also choose from the short list: the first one is the main category
        if (!$staff && !isset(self::KINDS[$d['kind']]) && $d['also_cat']) { $d['kind'] = 'other'; $d['category_id'] = (int) $d['also_cat'][0]; }
        if (!isset(self::KINDS[$d['kind']])) throw new InvalidArgumentException('Choose what it is, or tap + to pick the exact kind.');
        if ($d['town'] === '') throw new InvalidArgumentException('Which town is it in (or nearest)?');
        if ($d['phone'] === '' && !$staff) throw new InvalidArgumentException('Enter the business phone, 10 digits.');
        if ($d['email'] === '' && $needEmail) throw new InvalidArgumentException('Enter the business email, so we can reach the business.');
        if ($d['email'] !== '' && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email doesn\'t look right.');
        if ($d['address'] === '' && $d['point'] === '' && !$staff) throw new InvalidArgumentException('Add a street address, or drop a pin on the map.');
        if ($d['point'] !== '') {   // a pin, or coordinates pasted from a map: "34.5055, -109.3826", "(34.5, -109.4)", any number of decimals
            $pt = preg_replace('/[\s()\[\]°]+/u', '', $d['point']);
            if (!preg_match('/^(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?)$/', $pt, $mm) || abs((float) $mm[1]) > 90 || abs((float) $mm[2]) > 180) {
                throw new InvalidArgumentException('That map point doesn\'t look right. Use latitude, longitude, like 34.5055, -109.3826.');
            }
            $d['point'] = round((float) $mm[1], 6) . ',' . round((float) $mm[2], 6);
        }
        // a Facebook link typed as the website is its Facebook page (the crawler can't copy from Facebook; it links it)
        if ($d['website'] !== '' && $d['facebook'] === '' && preg_match('#^(https?://)?([a-z0-9-]+\.)?(facebook|fb)\.(com|me)/#i', $d['website'])) { $d['facebook'] = $d['website']; $d['website'] = ''; }
        foreach (['facebook', 'website'] as $k) {
            if ($d[$k] === '') continue;
            if (!preg_match('#^https?://#i', $d[$k])) $d[$k] = 'https://' . $d[$k];
            if (!filter_var($d[$k], FILTER_VALIDATE_URL)) throw new InvalidArgumentException('That ' . ($k === 'facebook' ? 'Facebook page' : 'website') . ' doesn\'t look right.');
        }
        if ($d['facebook'] !== '' && !preg_match('#^https?://([a-z0-9-]+\.)?(facebook|fb)\.(com|me)/#i', $d['facebook'])) throw new InvalidArgumentException('That doesn\'t look like a Facebook page link.');
        if (class_exists('ListingSafety') && ($x = ListingSafety::contentProblem($d['name'], $d['offers']))) throw new InvalidArgumentException("It can't be saved ($x).");
        return $d;
    }

    /**
     * Listings that may already be this business: the same phone or website, or a similar name in the same town.
     * @return list<array{id: int, name: string, city: string, status: string, why: string}>
     */
    public static function duplicates(PDO $pdo, array $d): array
    {
        $out = [];
        $add = function (array $r, string $why) use (&$out) { $id = (int) $r['id']; if (!isset($out[$id])) $out[$id] = ['id' => $id, 'name' => (string) $r['name'], 'city' => (string) ($r['city'] ?? ''), 'status' => (string) $r['status'], 'why' => $why]; };
        $base = "SELECT e.id, e.name, e.status, JSON_UNQUOTE(mc.meta_value) AS city FROM entities e
                  LEFT JOIN entity_metadata mc ON mc.entity_id = e.id AND mc.meta_key = 'city'
                 WHERE e.entity_type = 'merchant' AND e.is_suppressed = 0";
        // the same phone (stored in many shapes: compare the digits)
        $ids = [];
        if ($d['phone'] !== '') {   // staff may add one before its phone is known
            $st = $pdo->prepare("SELECT m.entity_id, m.meta_value FROM entity_metadata m WHERE m.meta_key = 'phone' AND m.meta_value LIKE ? LIMIT 300");
            $st->execute(['%' . substr($d['phone'], -4) . '%']);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) if (Claims::phone10((string) json_decode((string) $r['meta_value'])) === $d['phone']) $ids[] = (int) $r['entity_id'];
        }
        if ($ids) foreach ($pdo->query($base . ' AND e.id IN (' . implode(',', array_unique($ids)) . ')')->fetchAll(PDO::FETCH_ASSOC) as $r) $add($r, 'the same phone');
        // the same website
        foreach (['website' => 'the same website', 'facebook' => 'the same Facebook page'] as $k => $why) {
            $host = $d[$k] !== '' ? strtolower((string) parse_url($d[$k], PHP_URL_HOST) . rtrim((string) parse_url($d[$k], PHP_URL_PATH), '/')) : '';
            $host = preg_replace('/^(www\.|m\.)/', '', $host);
            if (strlen($host) < 6) continue;
            $st = $pdo->prepare($base . " AND e.id IN (SELECT entity_id FROM entity_metadata WHERE meta_key IN ('website','social_links') AND meta_value LIKE ?) LIMIT 5");
            $st->execute(['%' . $host . '%']);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $add($r, $why);
        }
        // a similar name in the same town
        $words = array_values(array_filter(preg_split('/\W+/u', mb_strtolower($d['name'])), fn ($w) => mb_strlen($w) > 2 && !in_array($w, ['the', 'and', 'llc', 'inc', 'company'], true)));
        if ($words) {
            $st = $pdo->prepare($base . " AND LOWER(JSON_UNQUOTE(mc.meta_value)) = ? AND LOWER(e.name) LIKE ? LIMIT 40");
            $st->execute([mb_strtolower($d['town']), '%' . $words[0] . '%']);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                similar_text(mb_strtolower($r['name']), mb_strtolower($d['name']), $pct);
                if ($pct >= 70) $add($r, 'a similar name in ' . $d['town']);
            }
        }
        // the one identity check (decisions/0164 §3.1): its candidates read fresh, hidden twins included, every one scored
        try {
            require_once __DIR__ . '/ListingIdentity.php';
            [$lat, $lon] = ($d['point'] ?? '') !== '' ? array_map('floatval', explode(',', (string) $d['point'])) : [null, null];
            $zip = self::zipFor($pdo, (string) $d['town'], (string) $d['state'], $lat, $lon);
            $r = ListingIdentity::resolve($pdo, ['name' => $d['name'], 'address' => (string) ($d['address'] ?? ''), 'zip' => $zip, 'phone' => (string) ($d['phone'] ?? ''), 'website' => (string) ($d['website'] ?? ''), 'lat' => $lat, 'lng' => $lon]);
            $have = $r['hits'] ? array_column($pdo->query('SELECT e.id, e.name, e.status, e.is_suppressed, JSON_UNQUOTE(mc.meta_value) AS city FROM entities e LEFT JOIN entity_metadata mc ON mc.entity_id = e.id AND mc.meta_key = \'city\' WHERE e.id IN (' . implode(',', array_map(fn ($h) => (int) $h['id'], $r['hits'])) . ')')->fetchAll(PDO::FETCH_ASSOC), null, 'id') : [];
            foreach ($r['hits'] as $h) if (isset($have[$h['id']]) && !(int) $have[$h['id']]['is_suppressed']) $add($have[$h['id']], $h['kind'] === 'maybe' ? 'it may be the same (' . $h['why'] . ')' : $h['why']);
        } catch (Throwable $x) { error_log('add business identity: ' . $x->getMessage()); }
        return array_values($out);
    }

    /**
     * Step 1: the form is checked, duplicates offered, the draft kept and the email code sent.
     * @return array{duplicates: list<array>, sent: bool}
     */
    public static function start(PDO $pdo, array $user, array $in, bool $notMine = false): array
    {
        $uid = (int) $user['id'];
        if ($m = self::needs($pdo, $uid)) throw new DomainException(implode(',', $m));
        $d = self::clean($in);
        if (!$notMine && ($dups = self::duplicates($pdo, $d))) return ['duplicates' => $dups, 'sent' => false];
        $_SESSION[self::DRAFT] = $d + ['at' => time(), 'not_mine' => $notMine ? 1 : 0];
        $code = StepUpAuth::issue($pdo, $uid, 'claim', 'add');
        Mailer::sendCode((string) $user['email'], (string) $code, 'code to add ' . $d['name'],
            "Your code to add {$d['name']} to Traversence is: {$code}\n\nIt expires in 10 minutes. If you didn't ask for this, you can ignore this email.");
        return ['duplicates' => [], 'sent' => true];
    }

    /** Step 2: the code. The listing is created and opened as the owner's claim (Managed by owner, live). Returns the claim. */
    public static function confirm(PDO $pdo, array $user, string $code): array
    {
        $uid = (int) $user['id'];
        $d = $_SESSION[self::DRAFT] ?? null;
        if (!$d || time() - (int) $d['at'] > 3600) throw new InvalidArgumentException('That form has timed out. Please fill it in again.');
        if ($m = self::needs($pdo, $uid)) throw new DomainException(implode(',', $m));
        try { StepUpAuth::verify($pdo, $uid, 'claim', $code, 'add'); }
        catch (RuntimeException $x) { throw new InvalidArgumentException($x->getMessage()); }
        $e = self::create($pdo, $d, 'owner', ['anyway' => !empty($d['not_mine']), 'uid' => $uid]);
        $claim = Claims::adopt($pdo, $uid, $e, $d['phone'], 'Added it');
        unset($_SESSION[self::DRAFT]);
        return $claim;
    }

    /** Creates the listing (unclaimed, live). $by: 'owner' (their form) or 'admin' (Review). Returns its id. */
    public static function create(PDO $pdo, array $d, string $by, array $opt = []): int
    {
        // $opt['anyway']: a person who saw the matches and said "a different business" (Add anyway, not mine): recorded on
        // each pair for good (decisions/0164 §3.1). Without it, the one identity check refuses a business already listed.
        [$lat, $lon] = $d['point'] !== '' ? array_map('floatval', explode(',', $d['point'])) : [null, null];
        $zip = self::zipFor($pdo, $d['town'], $d['state'], $lat, $lon);
        $hubId = 0;
        try { require_once __DIR__ . '/crawler/IntakeStager.php'; $hubId = IntakeStager::defaultGeoHubId($pdo); } catch (Throwable) {}
        $cluster = $zip !== '' ? CrawlerIngest::resolveMicroClusterId($pdo, $zip, $hubId) : 0;
        if ($lat === null && ($c = CrawlerIngest::fallbackCoordinates($pdo, $zip))) { $lat = (float) $c['latitude']; $lon = (float) $c['longitude']; }
        $cat = !empty($d['category_id']) ? (int) $d['category_id'] : self::categoryId($pdo, $d['kind']);
        $id = 0;
        require_once __DIR__ . '/ListingIdentity.php';
        $hits = [];
        $lock = 'tv_ident:' . (preg_replace('/[^0-9a-z]/i', '', $zip) ?: 'none');
        try { $pdo->prepare('SELECT GET_LOCK(?, 5)')->execute([$lock]); } catch (Throwable) {}   // the identity lock (ListingIdentity::locked), held to the insert
        try {
            $r = ListingIdentity::resolve($pdo, ['name' => $d['name'], 'address' => (string) ($d['address'] ?? ''), 'zip' => $zip, 'phone' => (string) ($d['phone'] ?? ''), 'website' => (string) ($d['website'] ?? ''), 'lat' => $lat, 'lng' => $lon]);
            $hits = array_values(array_filter($r['hits'], fn ($h) => !$h['hidden']));
            if (empty($opt['anyway']) && in_array($r['kind'], ['same', 'covered'], true) && $hits)
                throw new InvalidArgumentException('It\'s already on Traversence as "' . $hits[0]['name'] . '" (#' . $hits[0]['id'] . '): search for it, and claim it instead. If it really is another business, say so and add it anyway.');
        } catch (InvalidArgumentException $x) { try { $pdo->prepare('SELECT RELEASE_LOCK(?)')->execute([$lock]); } catch (Throwable) {} throw $x; }
        catch (Throwable $x) { error_log('add business identity: ' . $x->getMessage()); }
        try { Database::transaction(function (PDO $pdo) use ($d, $by, $zip, $cluster, $lat, $lon, $cat, &$id) {
            $pdo->prepare("INSERT INTO entities (entity_type, name, composite_hash, primary_zip, micro_cluster_id, category_id, latitude, longitude, status, trust_score,
                                                 is_suppressed, submission_source, intent_utility, intent_experience, created_by_type, updated_by_type, created_at, updated_at)
                           VALUES ('merchant', ?, ?, ?, ?, ?, ?, ?, 'unclaimed', 50.00, 0, 'user_submitted', 1, 0, ?, ?, NOW(), NOW())")
                ->execute([$d['name'], CrawlerIngest::computeCompositeHash($d['name'], $d['address'] ?: $d['point'], $zip), $zip !== '' ? $zip : null, $cluster ?: null, $cat, $lat, $lon, $by, $by]);
            $id = (int) $pdo->lastInsertId();
            $catName = self::KINDS[$d['kind']][0];
            if (!empty($d['category_id'])) { $cn = $pdo->prepare('SELECT name FROM categories WHERE id = ?'); $cn->execute([(int) $d['category_id']]); $catName = (string) ($cn->fetchColumn() ?: $catName); }
            $meta = ['city' => $d['town'], 'state' => $d['state'], 'category' => $catName];
            if ($d['phone'] !== '') $meta['phone'] = Claims::fmtPhone($d['phone']);
            if (($d['email'] ?? '') !== '') $meta['email'] = $d['email'];
            if ($d['address'] !== '') $meta['address'] = $d['address'];
            if ($d['website'] !== '') $meta['website'] = $d['website'];
            if ($d['facebook'] !== '') $meta['social_links'] = [$d['facebook']];
            if ($d['hours'] !== '') $meta['hours'] = [$d['hours']];
            if ($d['offers'] !== '') $meta['description'] = $d['offers'];
            $ins = $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, trust_score, created_at, updated_at)
                                   VALUES (?, ?, ?, ?, 1, 90.00, NOW(), NOW()) ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), updated_at = NOW()");
            foreach ($meta as $k => $v) $ins->execute([$id, $k, json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $by === 'admin' ? 'admin' : 'owner']);
        }); } catch (PDOException $x) {
            if ((string) $x->getCode() === '23000') throw new InvalidArgumentException('A listing with this name and address is already on Traversence. Search for it, and claim it instead.');
            throw $x;
        } finally { try { $pdo->prepare('SELECT RELEASE_LOCK(?)')->execute([$lock]); } catch (Throwable) {} }
        ListingIdentity::writeKeys($pdo, $id);
        if (!empty($opt['anyway'])) foreach ($hits as $h) ListingIdentity::different($pdo, $id, (int) $h['id'], (int) ($opt['uid'] ?? 0), 'Added anyway: ' . ($by === 'owner' ? 'the business said' : 'our team said') . ' it is another business');
        if ($d['point'] !== '' && is_file(__DIR__ . '/Geocoder.php')) { require_once __DIR__ . '/Geocoder.php'; try { Geocoder::setPoint($pdo, $id, (float) $lat, (float) $lon, $by === 'admin' ? 'staff' : 'owner'); } catch (Throwable) {} }
        self::setCategories($pdo, $id, $cat, (array) ($d['also_cat'] ?? []), $by);
        require_once __DIR__ . '/Identity.php';
        Identity::syncFromListing($pdo, $id, $by === 'admin' ? 'admin' : 'owner');   // its identity starts with what they told us (decisions/0133)
        if (is_file(__DIR__ . '/SearchIndex.php')) { require_once __DIR__ . '/SearchIndex.php'; try { if (SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, [$id]); } catch (Throwable) {} }   // searchable at once
        return $id;
    }

    /**
     * The + categories from the form (decisions/0073). The form's short list gives a broad group; the first exact
     * category picked inside that group becomes the main one, and the rest are "also listed under".
     */
    private static function setCategories(PDO $pdo, int $id, ?int $group, array $picked, string $by): void
    {
        if (!$picked) return;
        require_once __DIR__ . '/ListingCategories.php';
        if (!ListingCategories::ready($pdo)) return;
        try {
            if ($group) {
                $in = implode(',', array_fill(0, count($picked), '?'));
                $st = $pdo->prepare("SELECT id FROM categories WHERE parent_id = ? AND is_active = 1 AND id IN ($in)");
                $st->execute(array_merge([$group], array_map('intval', $picked)));
                $inside = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
                foreach ($picked as $p) if (in_array((int) $p, $inside, true)) {
                    $pdo->prepare('UPDATE entities SET category_id = ? WHERE id = ?')->execute([(int) $p, $id]);
                    $pdo->prepare("UPDATE entity_metadata SET meta_value = (SELECT JSON_QUOTE(name) FROM categories WHERE id = ?) WHERE entity_id = ? AND meta_key = 'category'")->execute([(int) $p, $id]);
                    break;
                }
            }
            ListingCategories::set($pdo, $id, $picked, null);   // the main one is left out of these by itself
        } catch (Throwable $x) { error_log('add business categories: ' . $x->getMessage()); }
    }

    /** The zip for a pin (the nearest) or a town (its most populous zip). */
    private static function zipFor(PDO $pdo, string $town, string $state, ?float $lat, ?float $lon): string
    {
        try {
            if ($lat !== null) {
                $st = $pdo->prepare('SELECT zip FROM zip_coordinates WHERE latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?
                                      ORDER BY POW(latitude - ?, 2) + POW(longitude - ?, 2) LIMIT 1');
                $st->execute([$lat - 1, $lat + 1, $lon - 1, $lon + 1, $lat, $lon]);
                if ($z = $st->fetchColumn()) return str_pad((string) $z, 5, '0', STR_PAD_LEFT);
            }
            // the state's letters are in `state` ("AZ"); `state_code` holds the county's number, so it never matched (2026-10-14)
            $st = $pdo->prepare('SELECT zip FROM zip_coordinates WHERE city = ? AND (state = ? OR ? = \'\') ORDER BY population DESC LIMIT 1');
            $t = mb_strtolower(trim($town));
            foreach (array_unique([$t, preg_replace('/^st\.? /', 'saint ', $t), preg_replace('/^saint /', 'st ', $t), preg_replace('/^saint /', 'st. ', $t)]) as $form) {
                $st->execute([$form, $state, $state]);
                if ($z = $st->fetchColumn()) return str_pad((string) $z, 5, '0', STR_PAD_LEFT);
            }
        } catch (Throwable) {}
        return '';   // not found: no ZIP (never "00000", which made an area of its own); the map point finds it later
    }

    private static function categoryId(PDO $pdo, string $kind): ?int
    {
        try {
            $st = $pdo->prepare('SELECT id FROM categories WHERE name = ? AND parent_id IS NULL LIMIT 1');
            $st->execute([self::KINDS[$kind][1] ?? 'Other']);
            $v = $st->fetchColumn();
            return $v !== false ? (int) $v : null;
        } catch (Throwable) { return null; }
    }

    /** Review: a visitor's "something missing" becomes a listing; the suggestion is linked, and its sender is told. */
    public static function fromSuggestion(PDO $pdo, int $suggestionId, array $in, int $adminId): int
    {
        $st = $pdo->prepare('SELECT * FROM suggestions WHERE id = ?');
        $st->execute([$suggestionId]);
        $s = $st->fetch(PDO::FETCH_ASSOC);
        if (!$s) throw new InvalidArgumentException('That suggestion is gone.');
        if ($s['status'] !== 'new') throw new InvalidArgumentException('That was already handled.');
        $d = self::clean($in, false, !empty($in['category_id']));   // our team picked the exact category (Pulse): it's taken as theirs
        $id = self::create($pdo, $d, 'admin', ['anyway' => !empty($in['anyway']), 'uid' => $adminId]);
        $pdo->prepare("UPDATE suggestions SET listing_id = ?, entity_id = COALESCE(entity_id, ?), status = 'used', handled_by = ?, handled_at = NOW() WHERE id = ?")
            ->execute([$id, $id, $adminId, $suggestionId]);
        // a guide's find: the name in the guide links to the new listing at once
        try {
            $gf = $pdo->prepare('SELECT id, place_key FROM guide_finds WHERE suggestion_id = ?'); $gf->execute([$suggestionId]);
            foreach ($gf->fetchAll(PDO::FETCH_ASSOC) as $f) {
                $pdo->prepare("UPDATE content_tags SET status = 'linked', ref = ?, note = ?, updated_at = NOW() WHERE find_id = ? AND status IN ('review','finding','unconfirmed')")->execute(['entity:' . $id, 'Listed by our team from the find', (int) $f['id']]);
                if (is_file(__DIR__ . '/Guides.php')) { require_once __DIR__ . '/Guides.php'; Guides::forget($pdo, (string) $f['place_key']); }
            }
        } catch (Throwable $x) { error_log('guide link #' . $suggestionId . ': ' . $x->getMessage()); }
        if ($s['user_id']) {
            $u = $pdo->prepare('SELECT email FROM users WHERE id = ?'); $u->execute([$s['user_id']]);
            $to = (string) $u->fetchColumn();
            $url = rtrim((string) (getenv('APP_URL') ?: ''), '/');
            $mine = str_contains((string) $s['note'], 'wants to claim it');
            if ($to !== '') try {
                Mailer::send($to, $d['name'] . ' is on Traversence', "Thank you for telling us about {$d['name']}. It's on Traversence now:\n" . $url . '/listing/view.php?id=' . $id
                    . ($mine ? "\n\nIt's yours? Claim it here, to manage it and get it verified:\n" . $url . '/claim.php?listing=' . $id : ''));
            } catch (Throwable $t) { error_log('add business mail: ' . $t->getMessage()); }
        }
        return $id;
    }

    /** What a suggestion's fields give the Review form to start from. */
    public static function prefill(array $s): array
    {
        $f = is_array($s['fields'] ?? null) ? $s['fields'] : (json_decode((string) ($s['fields'] ?? ''), true) ?: []);
        $web = (string) ($f['website'] ?? '');
        $fb = preg_match('#facebook\.com|fb\.(com|me)#i', $web) ? $web : '';
        return ['name' => (string) ($f['name'] ?? $s['target_name'] ?? ''), 'kind' => '', 'town' => '', 'state' => 'AZ', 'phone' => (string) ($f['phone'] ?? ''),
                'email' => (string) ($f['email'] ?? ''), 'address' => (string) ($f['address'] ?? ''), 'point' => (string) ($f['point'] ?? ''), 'facebook' => $fb, 'website' => $fb ? '' : $web,
                'hours' => (string) ($f['hours'] ?? ''), 'offers' => trim((string) ($f['what'] ?? '') . ($f['offers'] ?? '' ? "\n" . $f['offers'] : '') . (($n = trim(str_replace('Added by someone who wants to claim it.', '', (string) ($s['note'] ?? '')))) !== '' ? "\n" . $n : ''))];
    }
}
