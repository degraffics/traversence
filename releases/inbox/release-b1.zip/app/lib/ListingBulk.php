<?php
// app/lib/ListingBulk.php — several listings at once, from Find & edit (decisions/0083):
//   merge()    several listings that are one place become one: the one you keep stays, its gaps are filled from the
//              others (what a person or the owner entered on it is never replaced), the others are hidden and their
//              links go to it. A listing its owner manages is never the one hidden.
//   toNexus()  put them in a Nexus, an existing one or a new one, with their role (campus, clinic, branch…);
//   outOfNexus() take them out.
// Each returns what undo() needs to put things back as they were.
declare(strict_types=1);

require_once __DIR__ . '/crawler/IntakeStager.php';
require_once __DIR__ . '/SuggestionActions.php';
require_once __DIR__ . '/Nexus.php';
require_once __DIR__ . '/Aliases.php';

final class ListingBulk
{
    public const MAX = 50;

    /** The listings, each once, in the order given; throws when one is gone. */
    public static function listings(PDO $pdo, array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn ($x) => $x > 0)));
        if (count($ids) > self::MAX) throw new InvalidArgumentException('Pick ' . self::MAX . ' or fewer at a time.');
        $out = [];
        foreach ($ids as $id) {
            $e = IntakeStager::existingListing($pdo, $id);
            if (!$e) throw new InvalidArgumentException('Listing #' . $id . ' no longer exists.');
            $out[$id] = $e;
        }
        return $out;
    }

    /** A listing as the merge pop-up shows it. */
    public static function card(array $e): array
    {
        $v = fn (string $k) => is_scalar($e['meta'][$k]['value'] ?? null) ? trim((string) $e['meta'][$k]['value']) : '';
        $filled = 0;
        foreach (array_keys(SuggestionActions::FILL) as $k) { $x = $e['meta'][$k]['value'] ?? null; if ($x !== null && $x !== '' && $x !== []) $filled++; }
        return ['id' => $e['id'], 'name' => (string) $e['name'], 'address' => $v('address'), 'city' => $v('city'), 'phone' => $v('phone'), 'website' => $v('website'),
                'category' => (string) ($e['category_name'] ?? ''), 'claimed' => SuggestionActions::managed($e), 'hidden' => (int) $e['is_suppressed'] === 1,
                'filled' => $filled, 'created' => substr((string) $e['created_at'], 0, 10)];
    }

    /**
     * Keeps $keep, with the name of $nameFrom (one of them; default its own); fills its missing fields from the others,
     * first given first; hides the others and points them at it. Returns ['kept', 'hidden' => [ids], 'filled' => [labels],
     * 'undo' => […]].
     */
    public static function merge(PDO $pdo, array $ids, int $keep, int $nameFrom, int $admin): array
    {
        $L = self::listings($pdo, $ids);
        if (count($L) < 2) throw new InvalidArgumentException('Pick two or more listings to merge.');
        if (!isset($L[$keep])) throw new InvalidArgumentException('Choose which listing to keep.');
        $x = $L[$keep];
        $others = array_values(array_filter($L, fn ($e) => $e['id'] !== $keep));
        foreach ($others as $y) if (SuggestionActions::managed($y)) throw new InvalidArgumentException($y['name'] . ' (#' . $y['id'] . ') is managed by its owner, so it can\'t be the one hidden. Keep it instead.');
        $name = isset($L[$nameFrom]) ? trim((string) $L[$nameFrom]['name']) : (string) $x['name'];
        $undo = ['do' => 'merge', 'keep' => $keep, 'name' => (string) $x['name'], 'filled' => [], 'hidden' => [], 'nexus' => null, 'suggestions' => []];
        $filled = [];
        Database::transaction(function (PDO $pdo) use ($x, $others, $name, $admin, &$undo, &$filled): void {
            $has = fn ($v) => $v !== null && $v !== '' && $v !== [];
            $now = $x['meta'];
            foreach ($others as $y) {
                foreach (SuggestionActions::FILL as $k => $label) {
                    $from = $y['meta'][$k]['value'] ?? null;
                    if (!$has($from) || $has($now[$k]['value'] ?? null)) continue;
                    $undo['filled'][$k] = $now[$k] ?? null;   // what was there (nothing, or an empty value): put back on undo
                    self::put($pdo, $x['id'], $k, $from);
                    $now[$k] = ['value' => $from];
                    $filled[] = strtolower($label);
                }
                IntakeStager::setSuppressed($pdo, $y['id'], true);
                $was = $y['meta']['same_as']['value'] ?? null;
                self::put($pdo, $y['id'], 'same_as', ['id' => $x['id'], 'at' => date('Y-m-d'), 'by' => $admin, 'how' => 'find & edit']);
                $undo['hidden'][] = ['id' => $y['id'], 'was_hidden' => (int) $y['is_suppressed'] === 1, 'same_as' => $was];
                $st = $pdo->prepare("SELECT id FROM suggestions WHERE entity_id = ? AND status = 'new'");
                try { $st->execute([$y['id']]); foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $sid) $undo['suggestions'][] = [(int) $sid, $y['id']]; } catch (Throwable) {}
                try { $pdo->prepare("UPDATE suggestions SET entity_id = ? WHERE entity_id = ? AND status = 'new'")->execute([$x['id'], $y['id']]); } catch (Throwable) {}
            }
            if ($name !== '' && $name !== (string) $x['name']) $pdo->prepare("UPDATE entities SET name = ?, updated_by_type = 'admin', updated_at = NOW() WHERE id = ?")->execute([mb_substr($name, 0, 255), $x['id']]);
            // the names left behind are its other names, found by search and by the crawler (decisions/0084)
            $undo['aka'] = Aliases::get($pdo, $x['id']);
            Aliases::add($pdo, $x['id'], array_merge(array_map(fn ($y) => (string) $y['name'], $others), [(string) $x['name']]), 'admin');
            // the kept one takes the others' Nexus when it has none
            if (Nexus::ready($pdo)) {
                $st = $pdo->prepare('SELECT nexus_id, nexus_role FROM entities WHERE id = ?');
                $st->execute([$x['id']]); $mine = $st->fetch(PDO::FETCH_ASSOC);
                if ($mine && !$mine['nexus_id']) foreach ($others as $y) {
                    $st->execute([$y['id']]); $theirs = $st->fetch(PDO::FETCH_ASSOC);
                    if ($theirs && $theirs['nexus_id']) {
                        $pdo->prepare('UPDATE entities SET nexus_id = ?, nexus_role = ? WHERE id = ?')->execute([$theirs['nexus_id'], $theirs['nexus_role'] ?: 'location', $x['id']]);
                        $undo['nexus'] = [$x['id'], null, null];
                        break;
                    }
                }
            }
        });
        require_once __DIR__ . '/Identity.php';   // one business: the others' evidence joins the kept identity (decisions/0133)
        foreach ($others as $y) Identity::mergeInto($pdo, (int) $y['id'], (int) $x['id']);
        Identity::syncFromListing($pdo, (int) $x['id'], 'admin', $admin);
        self::reindex($pdo, array_merge([$x['id']], array_column($others, 'id')));
        return ['kept' => $x['id'], 'name' => $name, 'hidden' => array_column($others, 'id'), 'filled' => array_values(array_unique($filled)), 'undo' => $undo];
    }

    /**
     * Puts the listings in a Nexus: $nexusId, or a new one from $new ['name', 'kind', 'website']. $role for each (a
     * listing already in another Nexus moves). Returns ['nexus' => id, 'name', 'moved' => n, 'undo' => […]].
     */
    public static function toNexus(PDO $pdo, array $ids, int $nexusId, array $new, string $role, int $admin): array
    {
        if (!Nexus::ready($pdo)) throw new RuntimeException('Run app/migrations/2026-11-16_nexus.sql first.');
        $L = self::listings($pdo, $ids);
        if (!$L) throw new InvalidArgumentException('Pick one or more listings.');
        $created = 0;
        if ($nexusId <= 0) { $nexusId = Nexus::create($pdo, $new, $admin); $created = $nexusId; }
        $n = Nexus::get($pdo, $nexusId);
        if (!$n) throw new InvalidArgumentException('That Nexus no longer exists.');
        $undo = ['do' => 'nexus', 'created' => $created, 'was' => []];
        $st = $pdo->prepare('SELECT nexus_id, nexus_role FROM entities WHERE id = ?');
        foreach ($L as $id => $e) {
            $st->execute([$id]); $w = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            $undo['was'][] = [$id, $w['nexus_id'] ?? null, $w['nexus_role'] ?? null];
            Nexus::link($pdo, $id, $nexusId, $role);
        }
        return ['nexus' => $nexusId, 'name' => (string) $n['name'], 'moved' => count($L), 'undo' => $undo];
    }

    /** Takes them out of whatever Nexus they're in. */
    public static function outOfNexus(PDO $pdo, array $ids): array
    {
        $L = self::listings($pdo, $ids);
        $undo = ['do' => 'nexus', 'created' => 0, 'was' => []];
        $st = $pdo->prepare('SELECT nexus_id, nexus_role FROM entities WHERE id = ?');
        $n = 0;
        foreach ($L as $id => $e) {
            $st->execute([$id]); $w = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            if (empty($w['nexus_id'])) continue;
            $undo['was'][] = [$id, $w['nexus_id'], $w['nexus_role']];
            Nexus::unlink($pdo, $id); $n++;
        }
        return ['out' => $n, 'undo' => $undo];
    }

    /** Puts back what merge(), toNexus() or outOfNexus() changed. Returns a line saying what was put back. */
    public static function undo(PDO $pdo, array $u): string
    {
        if (($u['do'] ?? '') === 'merge') {
            Database::transaction(function (PDO $pdo) use ($u): void {
                $keep = (int) $u['keep'];
                foreach ((array) $u['filled'] as $k => $was) {
                    if ($was === null) $pdo->prepare('DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = ?')->execute([$keep, $k]);
                    else self::put($pdo, $keep, $k, $was['value'] ?? '');
                }
                $pdo->prepare('UPDATE entities SET name = ? WHERE id = ?')->execute([(string) $u['name'], $keep]);
                if (array_key_exists('aka', $u)) { if ($u['aka']) Aliases::set($pdo, $keep, $u['aka'], 'admin'); else $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = 'aka'")->execute([$keep]); }
                require_once __DIR__ . '/ListingIdentity.php';
                foreach ((array) $u['hidden'] as $h) {
                    ListingIdentity::pair($pdo, $keep, (int) $h['id'], 'different', 'Its merge was undone (Find & edit): not the same business', 0, 'person');   // never merged again (decisions/0164 §6.1)
                    IntakeStager::setSuppressed($pdo, (int) $h['id'], (bool) $h['was_hidden']);
                    if ($h['same_as'] === null) $pdo->prepare("DELETE FROM entity_metadata WHERE entity_id = ? AND meta_key = 'same_as'")->execute([(int) $h['id']]);
                    else self::put($pdo, (int) $h['id'], 'same_as', $h['same_as']);
                }
                foreach ((array) $u['suggestions'] as [$sid, $eid]) { try { $pdo->prepare('UPDATE suggestions SET entity_id = ? WHERE id = ?')->execute([$eid, $sid]); } catch (Throwable) {} }
                if (!empty($u['nexus'])) $pdo->prepare('UPDATE entities SET nexus_id = NULL, nexus_role = NULL WHERE id = ?')->execute([(int) $u['nexus'][0]]);
            });
            require_once __DIR__ . '/Identity.php';
            foreach ((array) $u['hidden'] as $h) Identity::unmerge($pdo, (int) $h['id'], (int) $u['keep']);
            Identity::syncFromListing($pdo, (int) $u['keep'], 'admin');
            self::reindex($pdo, array_merge([(int) $u['keep']], array_map(fn ($h) => (int) $h['id'], (array) $u['hidden'])));
            return 'Put back: ' . (count((array) $u['hidden']) + 1) . ' separate listings again.';
        }
        if (($u['do'] ?? '') === 'nexus') {
            foreach ((array) $u['was'] as [$id, $nid, $role]) {
                if ($nid) $pdo->prepare('UPDATE entities SET nexus_id = ?, nexus_role = ? WHERE id = ?')->execute([(int) $nid, $role, (int) $id]);
                else $pdo->prepare('UPDATE entities SET nexus_id = NULL, nexus_role = NULL WHERE id = ?')->execute([(int) $id]);
            }
            if (!empty($u['created'])) {
                $st = $pdo->prepare('SELECT COUNT(*) FROM entities WHERE nexus_id = ?'); $st->execute([(int) $u['created']]);
                if (!(int) $st->fetchColumn()) Nexus::remove($pdo, (int) $u['created']);
            }
            self::reindex($pdo, array_map(fn ($w) => (int) $w[0], (array) $u['was']));
            return 'Put back as they were.';
        }
        throw new InvalidArgumentException('Nothing to undo.');
    }

    /** A staff value: locked, so the crawler never overwrites it. */
    private static function put(PDO $pdo, int $id, string $k, $v): void
    {
        $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at) VALUES (?, ?, ?, 'admin', 1, NOW(), NOW())
                       ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), source_type = 'admin', is_locked = 1, updated_at = NOW()")
            ->execute([$id, $k, json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
    }

    private static function reindex(PDO $pdo, array $ids): void
    {
        if (is_file(__DIR__ . '/SearchIndex.php')) { require_once __DIR__ . '/SearchIndex.php'; try { if (SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, $ids); } catch (Throwable) {} }
        if (is_file(__DIR__ . '/PageCache.php')) { require_once __DIR__ . '/PageCache.php'; try { PageCache::forget($pdo, 'hub:support'); } catch (Throwable) {} }
    }
}
