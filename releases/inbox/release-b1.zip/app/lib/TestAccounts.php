<?php
// app/lib/TestAccounts.php — the accounts the site's checks sign in as (decisions/0145 §3, site-audit/test-accounts.md).
// One Founder-only button makes them all: members, the business team on a hidden test listing, and staff logins with
// two-step keys. Their sign-ins are shown once, as one block for the GitHub secret CHECK_ACCOUNTS, and never kept
// readable here. Test accounts (users.is_test) are left out of counts, likes, emails, people search and billing (they
// pay in sandbox only). Their addresses are check+<name>@traversence.com: the live site sends them nothing. Once staging
// is set up (StagingSite), the block also holds staging's address and viewing password, and staging gets the same sign-ins.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class TestAccounts
{
    public const MAILBOX = 'check@traversence.com';
    /** member key => [display name, what it covers] (site-audit/test-accounts.md) */
    public const MEMBERS = [
        'new' => ['Test New Member', 'The first 7 days: closer like checks, the sign-up questions'],
        'member' => ['Test Member', 'Default place, saved places, likes past 100, comments, messages, groups'],
        'contributor' => ['Test Contributor', 'Journeys and stories: write, edit, publish'],
        'steward' => ['Test Steward', 'Stewarding a test community group'],
        'client' => ['Test Client', 'The test client\'s orders: proofs, approve, pay (sandbox)'],
        'owner' => ['Test Business Owner', 'The test listing\'s owner: business portal, Edit listing, storefront, plans, team'],
        'manager' => ['Test Business Manager', 'Manager on the test listing'],
        'accountant' => ['Test Business Accountant', 'Accountant: money views, no listing edits'],
        'sales' => ['Test Business Sales', 'Sales role'],
        'viewer' => ['Test Business Viewer', 'Sees, changes nothing'],
    ];
    /** the business roles each member holds on the test listing */
    private const TEAM = ['owner' => 'owner', 'manager' => 'manager', 'accountant' => 'accountant', 'sales' => 'sales', 'viewer' => 'viewer'];
    /** staff key => [name, level, department] (Founder is never a test login) */
    public const STAFF = [
        'executive' => ['Test Executive', 'executive', ''],
        'ops-director' => ['Test Ops Director', 'director', 'ops'],
        'ops-manager' => ['Test Ops Manager', 'manager', 'ops'],
        'ops-staff' => ['Test Ops Staff', 'staff', 'ops'],
        'fin-staff' => ['Test Finance Staff', 'staff', 'fin'],
        'sal-staff' => ['Test Sales Staff', 'staff', 'sal'],
        'svc-staff' => ['Test Service Staff', 'staff', 'svc'],
        'con-staff' => ['Test Content Staff', 'staff', 'con'],
        'eng-staff' => ['Test Engineering Staff', 'staff', 'eng'],
        'editor' => ['Test Editor', 'editor', 'con'],
        'creator' => ['Test Content Creator', 'creator', 'con'],
        'assistant' => ['Test Assistant', 'assistant', ''],
        'vendor' => ['Test Vendor login', 'vendor', ''],
    ];
    public const LISTING = 'Traversence Test Listing';

    private static ?bool $ready = null;

    /** The update that adds users.is_test has run. */
    public static function ready(PDO $pdo): bool
    {
        if (self::$ready !== null) return self::$ready;
        try { $pdo->query('SELECT is_test FROM users LIMIT 0'); $pdo->query('SELECT 1 FROM test_records LIMIT 0'); return self::$ready = true; } catch (Throwable) { return self::$ready = false; }
    }

    /** " AND u.is_test = 0" for a query's users alias, once the column exists ('' before). */
    public static function notTest(PDO $pdo, string $alias = ''): string
    {
        return self::ready($pdo) ? ' AND ' . ($alias !== '' ? $alias . '.' : '') . 'is_test = 0' : '';
    }

    /** A test account's address: the live site sends it nothing (staging, TEST_MAIL=on in its .env, does). */
    public static function isTestEmail(string $email): bool
    {
        if (!preg_match('/^check(\+[a-z0-9._-]+)?@traversence\.com$/i', trim($email))) return false;
        Database::readEnv();
        return strtolower((string) (getenv('TEST_MAIL') ?: '')) !== 'on';
    }

    /**
     * A request from the site's own checks (the GitHub Action): it carries the health report's token (X-Check-Token).
     * Only then, and only for a test address, does sign-in skip the "verify you're human" check (no person to solve it).
     */
    public static function checkRequest(string $email): bool
    {
        Database::readEnv();   // sign-in checks this before anything has loaded .env
        $want = (string) (getenv('HEALTH_TOKEN') ?: '');
        $got = (string) ($_SERVER['HTTP_X_CHECK_TOKEN'] ?? '');
        return $want !== '' && $got !== '' && preg_match('/^check(\+[a-z0-9._-]+)?@traversence\.com$/i', trim($email)) === 1 && hash_equals($want, $got);
    }

    public static function isTestUser(PDO $pdo, int $uid): bool
    {
        if ($uid <= 0) return false;
        if ((int) ($_SESSION['user_id'] ?? 0) === $uid && isset($_SESSION['tv_test'])) return (bool) $_SESSION['tv_test'];
        if (!self::ready($pdo)) return false;
        try { $st = $pdo->prepare('SELECT is_test FROM users WHERE id = ?'); $st->execute([$uid]); $t = (bool) (int) $st->fetchColumn(); } catch (Throwable) { return false; }
        if ((int) ($_SESSION['user_id'] ?? 0) === $uid) $_SESSION['tv_test'] = $t;
        return $t;
    }

    /** What the button has made: kind|label => ref_id. */
    public static function made(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [];
        $out = [];
        foreach ($pdo->query('SELECT kind, label, ref_id FROM test_records')->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['kind'] . '|' . $r['label']] = (int) $r['ref_id'];
        return $out;
    }

    private static function keep(PDO $pdo, string $kind, string $label, int $id): void
    {
        $pdo->prepare('INSERT INTO test_records (kind, ref_id, label, created_at) VALUES (?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE ref_id = VALUES(ref_id)')->execute([$kind, $id, $label]);
    }

    private static function password(): string
    {
        return rtrim(strtr(base64_encode(random_bytes(15)), '+/', 'Kz'), '=') . 'a7!Q';   // the member rules: 8+, upper, lower, digit, symbol
    }

    /**
     * Makes what isn't made yet and gives every test account a new sign-in. Returns the block for CHECK_ACCOUNTS (JSON)
     * and a summary of what was made. Founder only (the caller checks).
     */
    public static function makeAll(PDO $pdo, int $staffId, int $actorUid): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('The database update for test accounts hasn\'t run yet: open Database updates first.');
        require_once __DIR__ . '/Auth.php';
        require_once __DIR__ . '/StaffLogin.php';
        @set_time_limit(120);
        $made = self::made($pdo); $block = ['made_at' => date('c'), 'site' => rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/'), 'members' => [], 'staff' => []];
        $note = [];
        // the shared mailbox (cPanel's own API; free): anything sent to check+…@ lands there
        if (empty($made['mailbox|' . self::MAILBOX]) && is_file(__DIR__ . '/CPanelMail.php')) {
            require_once __DIR__ . '/CPanelMail.php';
            if (CPanelMail::ready()) { try { $pw = CPanelMail::create(self::MAILBOX); self::keep($pdo, 'mailbox', self::MAILBOX, 1); if ($pw !== '') $block['mailbox'] = ['email' => self::MAILBOX, 'password' => $pw]; $note[] = 'the check@ mailbox'; } catch (Throwable $e) { $note[] = 'the mailbox couldn\'t be made (' . $e->getMessage() . ')'; } }
        }
        // members
        foreach (self::MEMBERS as $k => [$name]) {
            $email = 'check+' . $k . '@traversence.com';
            $pw = self::password();
            $uid = $made['user|' . $k] ?? 0;
            if (!$uid) {
                $f = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ?'); $f->execute([$email]); $uid = (int) $f->fetchColumn();
                if (!$uid) $uid = (int) Auth::register($email, $pw, $name)['id'];
                self::keep($pdo, 'user', $k, $uid);
                $note[] = $name;
            }
            $pdo->prepare('UPDATE users SET is_test = 1, email_verified_at = COALESCE(email_verified_at, NOW()), password_hash = ?, is_suspended = 0' . ($k === 'new' ? ', created_at = NOW()' : '') . ' WHERE id = ?')
                ->execute([password_hash($pw, defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT), $uid]);   // "new member" stays new: its sign-up date moves with each replace
            if (is_file(__DIR__ . '/AgeGate.php')) { require_once __DIR__ . '/AgeGate.php'; try { AgeGate::confirm($pdo, $uid); } catch (Throwable) {} }
            if ($k === 'contributor') { try { $pdo->prepare("INSERT IGNORE INTO contributors (user_id, bio, guidelines_version, status, joined_at) VALUES (?, 'Test contributor for the site checks.', 1, 'active', NOW())")->execute([$uid]); } catch (Throwable) {} }
            $block['members'][$k] = ['email' => $email, 'password' => $pw, 'user_id' => $uid];
        }
        // the hidden test listing and its team
        $lid = $made['listing|' . self::LISTING] ?? 0;
        if (!$lid) {
            require_once __DIR__ . '/AddBusiness.php';
            $kind = (string) array_key_first(AddBusiness::KINDS);
            $lid = AddBusiness::create($pdo, ['name' => self::LISTING, 'point' => '34.5058,-109.3609', 'town' => 'Saint Johns', 'state' => 'AZ', 'address' => '', 'phone' => '', 'email' => '',
                                              'website' => '', 'facebook' => '', 'hours' => '', 'offers' => 'A test listing for the site checks. Not a real business.', 'kind' => $kind], 'admin', ['anyway' => true]);
            self::keep($pdo, 'listing', self::LISTING, $lid);
            $note[] = 'the test listing';
        }
        $pdo->prepare('UPDATE entities SET is_suppressed = 1 WHERE id = ?')->execute([$lid]);   // never public, never in search
        if (is_file(__DIR__ . '/SearchIndex.php')) { require_once __DIR__ . '/SearchIndex.php'; try { if (SearchIndex::ready($pdo)) SearchIndex::indexListings($pdo, [$lid]); } catch (Throwable) {} }
        require_once __DIR__ . '/Team.php';
        foreach (self::TEAM as $k => $role) {
            try { Team::adminSet($pdo, $lid, 'check+' . $k . '@traversence.com', $role, $actorUid); } catch (Throwable $e) { $note[] = 'the ' . $role . ' role (' . $e->getMessage() . ')'; }
        }
        $block['listing'] = ['id' => $lid, 'name' => self::LISTING];
        // staff logins (the Assistant assists the test Executive)
        $exec = 0;
        foreach (self::STAFF as $k => [$name, $level, $dep]) {
            $sid = $made['staff|' . $k] ?? 0;
            if ($sid && StaffLogin::get($pdo, $sid)) $s = ['sid' => $sid, 'staff_id' => (string) StaffLogin::get($pdo, $sid)['staff_id']] + StaffLogin::resetTest($pdo, $sid);
            else { $s = StaffLogin::makeTest($pdo, $name, $level, $dep, 'check+staff-' . $k . '@traversence.com', $level === 'assistant' ? $exec : 0); self::keep($pdo, 'staff', $k, (int) $s['sid']); $note[] = $name; }
            if ($k === 'executive') $exec = (int) $s['sid'];
            $block['staff'][$k] = ['staff_id' => $s['staff_id'], 'password' => $s['password'], 'totp' => $s['totp'], 'level' => $level, 'department' => $dep];
        }
        // the health report's token (decisions/0145 §1): written into .env here, and into the same block for GitHub
        $tok = rtrim(strtr(base64_encode(random_bytes(36)), '+/', '-_'), '=');
        $block['health_token'] = $tok;
        require_once __DIR__ . '/EnvSettings.php';
        try { EnvSettings::setSecret('HEALTH_TOKEN', $tok); $note[] = 'a new health report token (in .env)'; }
        catch (Throwable $e) { $block['health_token_note'] = 'Not written to .env (' . $e->getMessage() . '): add HEALTH_TOKEN=<this value> to the live .env by hand.'; $note[] = 'a health token to add to .env by hand'; }
        // the staging copy, once it's set up (decisions/0145 Phase 3): a new viewing password in the same block, and the
        // same new sign-ins there, so the checks use one block for live and staging
        if (is_file(__DIR__ . '/StagingSite.php')) {
            require_once __DIR__ . '/StagingSite.php';
            try { if ($v = StagingSite::newViewing($pdo)) { $block['staging'] = $v + ['note' => StagingSite::syncTestAccounts($pdo)]; $note[] = 'a new staging viewing password'; } }
            catch (Throwable $e) { $note[] = 'staging\'s viewing password wasn\'t changed (' . $e->getMessage() . ')'; }
        }
        error_log('test accounts made or renewed by staff #' . $staffId);
        return ['block' => json_encode($block, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), 'made' => $note];
    }
}
