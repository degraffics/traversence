<?php
// app/lib/WorkflowSettings.php — each workflow's settings, edited in the admin and kept as versions (decisions/0163 §3;
// Jason, 2026-11-14: "allow me to modify the workflows if I choose to"; Release A). One spec per workflow: what starts
// it, its tasks (order, share, limits, the services each may use), its budgets (its share of the AI cap, a monthly
// budget), its gates' thresholds, the collaborative score's weights (§12), its retry ladder (§12) and which steps need a
// person. A save writes the settings the code already reads (crawl_workflows.share_pct, crawl_capture_tasks' columns,
// Thresholds) and keeps a version: who, when, what changed, and "Go back to it", as content templates do (0164 R16).
// Switches stay on the Automation page: a save never switches anything on. Each version records the switch-on check's
// red lines for its workflow at the time (§10): what's red keeps it paused.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Automation.php';
require_once __DIR__ . '/Thresholds.php';

final class WorkflowSettings
{
    /** A task's limits a person may set: column => [label, min, max]. */
    public const TASK_FIELDS = [
        'sort' => ['Order', 0, 999], 'every_minutes' => ['Every (minutes)', 5, 43200], 'max_seconds' => ['Seconds a run at most', 10, 1800],
        'max_fetches' => ['Pages a run at most', 0, 1000], 'max_paid' => ['Paid calls a run at most', 0, 1000], 'per_run' => ['Items a run at most', 1, 1000],
    ];

    /** The gates each workflow uses (Thresholds), edited with it. */
    public const GATES_OF = ['W5' => ['guide_ondemand_share']];   // W1's listing_one_source retired as a gate (decisions/0164 §3.5, X2): the floor and readiness decide

    /** The collaborative score's weights to start (decisions/0163 §12), for W1 and W2. Read by the engine from Release B. */
    public const WEIGHTS = [
        'google_phone' => ['Google Places confirms it open, agreeing on the phone', 40], 'google_address' => ['Google Places confirms it open, agreeing on the address only', 30],
        'chamber' => ['Chamber of commerce or tourism office listing', 25], 'managed' => ['Business-managed or filings-built listing (Uberall, DAC, BrightQuery)', 25],
        'open_dataset' => ['An open-dataset record from another origin (Microsoft, Foursquare)', 20], 'facebook' => ['Its Facebook page (or Overture\'s Meta record, once)', 20],
        'directory' => ['A directory page our crawler read (at most two count)', 15], 'osm' => ['OpenStreetMap', 15], 'news' => ['A news story naming it in that town', 10],
        'gemini' => ['Gemini\'s own word (never a finder)', 0], 'our_older' => ['Our own older listings (bulk imports)', 0],
        'closure' => ['Against: a closure signal', -40], 'dissolved' => ['Against: a dissolved or revoked licence', -60],
    ];

    /** The retry ladder to start (§12): [fails in a row, next try in days]; after the last, every that many days, for good. */
    public const LADDER = [[3, 7], [6, 30], [10, 180]];

    /** Workflows the engine retries for itself (the grey zone, gaps, sightings, out-of-options finds). */
    public const RETRIES = ['W1', 'W2', 'W8'];

    /** Steps that need a person, to start (0164, 0133; never a machine's call on these). */
    public const PERSON = [
        'W1' => ['Review: the grey zone and merge offers', 'Reactivate a site that blocks us (never retried by itself)'],
        'W4' => ['A guide below its publish score waits as a draft for a person'],
        'W9' => ['A place held for its name opens fully only on a person\'s link to its managing authority'],
        'W13' => ['People write stories'],
    ];

    public static function ready(PDO $pdo): bool
    {
        try { self::table($pdo); return true; } catch (Throwable $e) { return false; }
    }

    private static function table(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        require_once __DIR__ . '/AdminTables.php';
        AdminTables::make($pdo, ['workflow_versions' => '(id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, wf VARCHAR(8) NOT NULL, version INT UNSIGNED NOT NULL,
            spec MEDIUMTEXT NOT NULL, changes TEXT NULL, note VARCHAR(300) NOT NULL DEFAULT \'\', saved_by INT UNSIGNED NULL, saved_at DATETIME NOT NULL, tz VARCHAR(64) NOT NULL DEFAULT \'\',
            check_red INT UNSIGNED NOT NULL DEFAULT 0, UNIQUE KEY wf_version (wf, version))']);
        $done = true;
    }

    private static function crawl(PDO $pdo): bool
    {
        if (!class_exists('CrawlService', false)) { if (!is_file(__DIR__ . '/crawler/CrawlService.php')) return false; require_once __DIR__ . '/crawler/CrawlService.php'; }
        return CrawlService::ready($pdo);
    }

    /** The spec as the site runs it now (from the columns the code reads), for a workflow with no version yet. */
    public static function live(PDO $pdo, string $wf): array
    {
        $tasks = []; $share = null;
        if (self::crawl($pdo)) {
            foreach (CrawlService::tasks($pdo) as $t => $r) if ((string) $r['wf'] === $wf) {
                $tasks[$t] = ['name' => (string) $r['name']];
                foreach (array_keys(self::TASK_FIELDS) as $f) $tasks[$t][$f] = (int) ($r[$f] ?? 0);
                $tasks[$t]['routes'] = self::routesOf($t);
            }
            $w = CrawlService::workflows($pdo)[$wf] ?? null;
            if ($w) $share = (int) $w['share_pct'];
        }
        $gates = [];
        foreach (self::GATES_OF[$wf] ?? [] as $g) $gates[$g] = Thresholds::get($pdo, $g);
        $jobs = array_keys(array_filter(Automation::JOBS, fn ($ws) => in_array($wf, $ws, true)));
        return ['wf' => $wf,
                'starts' => ['schedule' => $tasks ? 'The crawler\'s runs on Railway (every 5 minutes while its schedule is on), each task by its "every"' . ($jobs ? '; the site\'s jobs: ' . implode(', ', $jobs) : '') : ($jobs ? 'The site\'s jobs: ' . implode(', ', $jobs) : 'A person\'s press'), 'triggers' => ''],
                'tasks' => $tasks, 'share_pct' => $share,
                'budgets' => ['ai_share_pct' => $wf === 'W5' ? 50 : 0, 'month_usd' => 0.0],
                'gates' => $gates,
                'weights' => in_array($wf, ['W1', 'W2'], true) ? array_map(fn ($w) => $w[1], self::WEIGHTS) : [],
                'ladder' => in_array($wf, self::RETRIES, true) ? self::LADDER : [],
                'person' => self::PERSON[$wf] ?? []];
    }

    /** The services a task may use (OutsideServices::CONTROLS), to start. */
    private static function routesOf(string $task): array
    {
        require_once __DIR__ . '/OutsideServices.php';
        $out = [];
        foreach (OutsideServices::CONTROLS as $svc => $c) if (in_array($task, (array) ($c['tasks'] ?? []), true)) $out[] = $svc;
        return $out;
    }

    /** The current spec (the newest version, else as it runs now). */
    public static function current(PDO $pdo, string $wf): array
    {
        $v = self::versions($pdo, $wf, 1)[0] ?? null;
        return $v ? (json_decode((string) $v['spec'], true) ?: self::live($pdo, $wf)) : self::live($pdo, $wf);
    }

    /** Every workflow's current spec: wf => spec. */
    public static function all(PDO $pdo): array
    {
        $out = [];
        foreach (array_keys(Automation::WORKFLOWS) as $wf) $out[$wf] = self::current($pdo, $wf);
        return $out;
    }

    /** Its versions, newest first: [{version, spec, changes, note, saved_by, by_name, saved_at, tz, check_red}]. */
    public static function versions(PDO $pdo, string $wf, int $n = 20): array
    {
        try {
            self::table($pdo);
            $st = $pdo->prepare('SELECT v.*, u.display_name by_name FROM ' . Database::t('workflow_versions') . ' v LEFT JOIN users u ON u.id = v.saved_by WHERE v.wf = ? ORDER BY v.version DESC LIMIT ' . max(1, min(200, $n)));
            $st->execute([$wf]);
            return $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { return []; }
    }

    /** A spec from the board's form, checked. Throws with what's wrong. */
    public static function fromForm(PDO $pdo, string $wf, array $in): array
    {
        $spec = self::current($pdo, $wf);
        $num = function ($v, $lo, $hi, string $what, bool $float = false) {
            $v = trim(str_replace(',', '', (string) $v));
            if ($v === '' || !is_numeric($v)) throw new InvalidArgumentException($what . ': enter a number.');
            $v = $float ? round((float) $v, 2) : (int) round((float) $v);
            if ($v < $lo || $v > $hi) throw new InvalidArgumentException($what . ': between ' . $lo . ' and ' . $hi . '.');
            return $v;
        };
        $spec['starts']['triggers'] = mb_substr(trim(strip_tags((string) ($in['triggers'] ?? $spec['starts']['triggers']))), 0, 500);
        if ($spec['share_pct'] !== null && isset($in['share_pct'])) $spec['share_pct'] = $num($in['share_pct'], 0, 100, 'Its share of a crawler run');
        foreach ($spec['tasks'] as $t => &$task) {
            foreach (self::TASK_FIELDS as $f => [$label, $lo, $hi]) if (isset($in['t'][$t][$f])) $task[$f] = $num($in['t'][$t][$f], $lo, $hi, $task['name'] . ': ' . mb_strtolower($label));
            if (isset($in['t'][$t]['routes'])) {
                require_once __DIR__ . '/OutsideServices.php';
                $task['routes'] = array_values(array_intersect(array_map('strval', (array) $in['t'][$t]['routes']), array_keys(OutsideServices::COMPANIES)));
            }
        }
        unset($task);
        if (isset($in['ai_share_pct'])) $spec['budgets']['ai_share_pct'] = $num($in['ai_share_pct'], 0, 100, 'Its share of the AI cap');
        if (isset($in['month_usd'])) $spec['budgets']['month_usd'] = $num($in['month_usd'], 0, 10000, 'Its monthly budget', true);
        foreach ($spec['gates'] as $g => &$v) if (isset($in['g'][$g])) { $d = Thresholds::GATES[$g]; $v = $num($in['g'][$g], $d[3], $d[4], $d[0], is_float($d[2])); }
        unset($v);
        foreach ($spec['weights'] as $k => &$v) if (isset($in['w'][$k])) $v = $num($in['w'][$k], -100, 100, self::WEIGHTS[$k][0] ?? $k);
        unset($v);
        if ($spec['ladder'] && isset($in['ladder'])) {
            $l = [];
            foreach ((array) $in['ladder'] as $i => $step) $l[] = [$num($step[0] ?? '', 1, 100, 'Retry step ' . ($i + 1) . ': fails in a row'), $num($step[1] ?? '', 1, 365, 'Retry step ' . ($i + 1) . ': days')];
            usort($l, fn ($a, $b) => $a[0] <=> $b[0]);
            $spec['ladder'] = $l;
        }
        if (isset($in['person'])) $spec['person'] = array_values(array_filter(array_map(fn ($x) => mb_substr(trim(strip_tags((string) $x)), 0, 200), preg_split('/\R/', (string) $in['person']))));
        return $spec;
    }

    /** What changed between two specs, in words. */
    public static function diff(array $a, array $b): array
    {
        $out = [];
        $walk = function ($x, $y, string $path) use (&$walk, &$out) {
            if (is_array($x) && is_array($y) && !self::isList($x) && !self::isList($y)) {
                foreach (array_unique(array_merge(array_keys($x), array_keys($y))) as $k) $walk($x[$k] ?? null, $y[$k] ?? null, $path === '' ? (string) $k : $path . ' › ' . $k);
                return;
            }
            if (json_encode($x) !== json_encode($y)) $out[] = $path . ': ' . self::say($x) . ' → ' . self::say($y);
        };
        $walk($a, $b, '');
        return $out;
    }

    /** Whether an array is a plain list (array_is_list() is PHP 8.1). */
    private static function isList(array $a): bool
    {
        $i = 0;
        foreach ($a as $k => $v) { if ($k !== $i++) return false; }
        return true;
    }

    private static function say($v): string
    {
        if ($v === null) return '(none)';
        if (is_array($v)) return mb_strimwidth(implode(', ', array_map(fn ($x) => is_array($x) ? implode('/', $x) : (string) $x, $v)), 0, 120, '…');
        return mb_strimwidth((string) $v, 0, 120, '…');
    }

    /**
     * Saves a spec as a new version and writes the settings the code reads. Returns [version, changes, red lines].
     * A spec with no change from the current one isn't saved.
     */
    public static function save(PDO $pdo, string $wf, array $spec, int $uid, string $note = '', string $tz = ''): array
    {
        if (!isset(Automation::WORKFLOWS[$wf])) throw new InvalidArgumentException('No such workflow.');
        self::table($pdo);
        $had = self::versions($pdo, $wf, 1);
        $cur = self::current($pdo, $wf);
        $changes = self::diff($cur, $spec);
        if ($had && !$changes) throw new InvalidArgumentException('Nothing changed.');
        if (!$had) self::keep($pdo, $wf, 1, $cur, ['As it ran before the first save'], 0, 'Found: the settings as they were', '');   // version 1: where it started
        self::apply($pdo, $wf, $spec, $uid);
        require_once __DIR__ . '/Operations.php';
        $red = count(Operations::blocking($pdo, $wf, true));
        $n = (int) ($had ? $had[0]['version'] : 1) + 1;
        self::keep($pdo, $wf, $n, $spec, $changes, $uid, $note, $tz, $red);
        return [$n, $changes, $red];
    }

    private static function keep(PDO $pdo, string $wf, int $n, array $spec, array $changes, int $uid, string $note, string $tz, int $red = 0): void
    {
        $pdo->prepare('INSERT INTO ' . Database::t('workflow_versions') . ' (wf, version, spec, changes, note, saved_by, saved_at, tz, check_red) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$wf, $n, json_encode($spec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), json_encode($changes, JSON_UNESCAPED_UNICODE), mb_substr(trim($note), 0, 300), $uid ?: null, date('Y-m-d H:i:s'), mb_substr($tz, 0, 64), $red]);
    }

    /** Writes the settings the code reads now: the workflow's share, its tasks' limits, its gates. Never a switch. */
    private static function apply(PDO $pdo, string $wf, array $spec, int $uid): void
    {
        if (self::crawl($pdo)) {
            if ($spec['share_pct'] !== null) CrawlService::setShare($pdo, $wf, (int) $spec['share_pct']);
            $cols = array_keys(self::TASK_FIELDS);
            $st = $pdo->prepare('UPDATE crawl_capture_tasks SET ' . implode(', ', array_map(fn ($c) => $c . ' = ?', $cols)) . ', updated_at = NOW() WHERE task = ? AND wf = ?');
            foreach ($spec['tasks'] as $t => $task) $st->execute(array_merge(array_map(fn ($c) => (int) $task[$c], $cols), [$t, $wf]));
        }
        foreach ($spec['gates'] as $g => $v) if ((string) Thresholds::get($pdo, $g) !== (string) $v) Thresholds::set($pdo, $g, (string) $v, $uid);
    }

    /** "Go back to it": a version's spec saved as a new version (nothing is lost). */
    public static function restore(PDO $pdo, string $wf, int $version, int $uid, string $tz = ''): array
    {
        $st = $pdo->prepare('SELECT spec FROM ' . Database::t('workflow_versions') . ' WHERE wf = ? AND version = ?');
        $st->execute([$wf, $version]);
        $spec = json_decode((string) $st->fetchColumn(), true);
        if (!is_array($spec)) throw new InvalidArgumentException('That version isn\'t here.');
        return self::save($pdo, $wf, $spec, $uid, 'Back to version ' . $version, $tz);
    }
}

