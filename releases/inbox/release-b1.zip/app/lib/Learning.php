<?php

declare(strict_types=1);

/**
 * Search that learns (decisions/0061, batch 3). Rule-based, no AI.
 *
 *   logOpen()      what was opened after a search: the words, area, day and the kind of thing (its category). Never who.
 *   completions()  completions learned from what people search: phrases searched 3+ times that found something, made
 *                  only of words we know (never a business's name).
 *   run()          scores each mapping (words -> a kind of thing) by relevance: the words and outside sources, never
 *                  usage (decisions/0093). Publishes or retires it on its own, and finds situation gaps for the crawler.
 *   forSearch()    what search has learned for these exact words: "Most opened" (published) or "May also help".
 *   lookingFor()   a situation gap as a crawl job (Tier 1: OpenStreetMap filters, Wikidata classes).
 *   tier2Next() / tier2Result()   web-search work for the worker (Tier 2: .gov, .edu and sources we read), and its
 *                  findings: each useful page becomes an outside source, and a page that lists several places joins
 *                  the sources read regularly.
 */
final class Learning
{
    /**
     * Relevance decides (decisions/0093): a mapping's score is how well the words mean that kind of thing, from the words
     * themselves and outside sources that confirm it. Usage (what people opened) never adds to the score; it only puts
     * equally relevant mappings in order. 0.90 / 0.75 behaviour-weighted at first (decisions/0061).
     */
    public const PUBLISH = 0.80;    // the defaults: System Configuration → Thresholds & gates tunes them (publishAt, mayHelpAt)
    public const MAY_HELP = 0.60;

    public static function publishAt(PDO $pdo): float { require_once __DIR__ . '/Thresholds.php'; return (float) Thresholds::get($pdo, 'search_publish'); }
    public static function mayHelpAt(PDO $pdo): float { require_once __DIR__ . '/Thresholds.php'; return (float) Thresholds::get($pdo, 'search_may_help'); }
    public const MIN_SEARCHES = 10;   // the crawler's queue only (tier2Next): demand orders its work, never a mapping
    public const WEIGHTS = ['text' => 0.60, 'sources' => 0.40];
    public const DAYS = 90;
    public const RUN_EVERY = 6 * 3600;
    public const STATUS = ['learning' => 'Learning', 'may_help' => 'May also help', 'live' => 'Published', 'retired' => 'Retired'];

    private static ?bool $ready = null;

    public static function ready(PDO $pdo): bool
    {
        if (self::$ready !== null) return self::$ready;
        try { $pdo->query('SELECT 1 FROM search_learned LIMIT 1'); $pdo->query('SELECT 1 FROM search_opens LIMIT 1'); self::$ready = true; } catch (Throwable) { self::$ready = false; }
        return self::$ready;
    }

    /** The words as counted everywhere else (Situations::logOutcome): lower case, spaces tidied, 120 characters. */
    public static function words(string $q): string
    {
        return mb_substr(trim(preg_replace('/\s+/u', ' ', preg_replace('/[\x00-\x1F\x7F]/u', '', mb_strtolower($q)))), 0, 120);
    }

    // ---- what was opened -------------------------------------------------------------------------------------------

    /** One thing opened after a search, counted by its kind (category). $url as linked: "/listing/view.php?id=6178". */
    public static function logOpen(PDO $pdo, string $q, string $placeKey, string $url): void
    {
        if (!self::ready($pdo)) return;
        $q = self::words($q);
        $path = (string) parse_url($url, PHP_URL_PATH) . (($qs = parse_url($url, PHP_URL_QUERY)) ? '?' . $qs : '');
        if (mb_strlen($q) < 2 || $path === '' || !str_starts_with($path, '/')) return;
        try {
            $st = $pdo->prepare('SELECT category_id FROM search_index WHERE url = ? AND category_id IS NOT NULL LIMIT 1');
            $st->execute([mb_substr($path, 0, 300)]);
            $cat = (int) $st->fetchColumn();
            if ($cat > 0) self::bumpOpen($pdo, $q, $placeKey, $cat);
        } catch (Throwable $e) { error_log('learning open: ' . $e->getMessage()); }
    }

    /**
     * A kind of place tapped in the suggestions while typing ("Music & Live Entertainment" after "live mu"), counted
     * like an open, against the words typed (decisions/0067, 2026-10-07). Its name as shown; a plain name several
     * categories share counts for the one with the most listings. Words, area, day and kind; never who.
     */
    public static function logOpenKind(PDO $pdo, string $q, string $placeKey, string $label): void
    {
        if (!self::ready($pdo)) return;
        $q = self::words($q);
        $label = mb_strtolower(trim($label));
        if (mb_strlen($q) < 2 || $label === '' || mb_strlen($label) > 120) return;
        try {
            $nm = class_exists('SearchText') ? SearchText::catNameSql($pdo, 'c') : 'c.name';
            $st = $pdo->prepare("SELECT c.id FROM categories c WHERE c.is_active = 1 AND (LOWER(c.name) = ? OR LOWER($nm) = ?)
                                 ORDER BY (SELECT COUNT(*) FROM entities e WHERE e.category_id = c.id) DESC, c.id LIMIT 1");
            $st->execute([$label, $label]);
            $cat = (int) $st->fetchColumn();
            if ($cat > 0) self::bumpOpen($pdo, $q, $placeKey, $cat);
        } catch (Throwable $e) { error_log('learning open kind: ' . $e->getMessage()); }
    }

    private static function bumpOpen(PDO $pdo, string $q, string $placeKey, int $cat): void
    {
        $day = date('Y-m-d'); $pk = mb_substr($placeKey, 0, 40);
        // hard to game (decisions/0093): once per visit for these words, kind and day; never our team or a bot
        if (is_file(__DIR__ . '/PlatformCounts.php')) { require_once __DIR__ . '/PlatformCounts.php'; if (PlatformCounts::isBot() || PlatformCounts::isTeam($pdo)) return; }
        $seen = 'op|' . md5($q . '|' . $cat . '|' . $day);
        if (session_status() === PHP_SESSION_ACTIVE) { if (!empty($_SESSION['tv_opens'][$seen])) return; if (count($_SESSION['tv_opens'] ?? []) > 200) $_SESSION['tv_opens'] = []; $_SESSION['tv_opens'][$seen] = 1; }
        $up = $pdo->prepare('UPDATE search_opens SET n = n + 1 WHERE q = ? AND place_key = ? AND day = ? AND category_id = ?');
        $up->execute([$q, $pk, $day, $cat]);
        if ($up->rowCount() === 0) {
            try { $pdo->prepare('INSERT INTO search_opens (q, place_key, day, category_id, n) VALUES (?, ?, ?, ?, 1)')->execute([$q, $pk, $day, $cat]); }
            catch (PDOException) { $up->execute([$q, $pk, $day, $cat]); }
        }
    }

    /** How strongly a share stands out: the lower bound of its confidence (wilson()). A pattern, not a count or a clock. */
    public const PATTERN = 0.30;

    /**
     * What people who typed these words went on to open, by kind (decisions/0067; 0093): [category id => visits], best
     * first. A kind counts when it's a clear pattern: its share of the visits that opened anything after these words,
     * at the confidence those visits give (wilson() >= PATTERN). No time window and no fixed count: many visitors in one
     * day can make a pattern, a few over months can too, one visitor repeating never does (each visit counts once). A
     * label on suggestions, never a ranking factor (decisions/0093).
     */
    public static function picks(PDO $pdo, array $qs): array
    {
        if (!self::ready($pdo)) return [];
        $qs = array_values(array_unique(array_filter(array_map([self::class, 'words'], $qs), fn ($x) => mb_strlen($x) >= 2)));
        if (!$qs) return [];
        try {
            $st = $pdo->prepare('SELECT category_id, SUM(n) AS n FROM search_opens WHERE q IN (' . implode(',', array_fill(0, count($qs), '?')) . ') GROUP BY category_id');
            $st->execute($qs);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) { return []; }
        $total = (int) array_sum(array_column($rows, 'n'));
        $out = [];
        foreach ($rows as $r) if (self::wilson((int) $r['n'], $total) >= self::PATTERN) $out[(int) $r['category_id']] = (int) $r['n'];
        arsort($out);
        return array_slice($out, 0, 6, true);
    }

    // ---- learned completions ---------------------------------------------------------------------------------------

    private const BASE_WORDS = ['a', 'an', 'the', 'to', 'in', 'on', 'at', 'of', 'for', 'with', 'and', 'or', 'my', 'me', 'i', 'we', 'our', 'near', 'nearby',
        'open', 'now', 'today', 'tonight', 'tomorrow', 'weekend', 'this', 'next', 'late', 'early', 'kids', 'family', 'dogs', 'dog', 'pets', 'free', 'cheap',
        'best', 'good', 'where', 'what', 'how', 'can', 'get', 'find', 'need', 'places', 'place', 'things', 'thing', 'do', 'eat', 'stay', 'see', 'go', 'help',
        'fix', 'repair', 'rent', 'buy', 'service', 'services', 'local', 'around', 'here', 'out', 'day', 'night', 'trip'];

    /** Words we know: category names, situation phrases, taught meanings, and the 5 W's little words. Never a name. */
    private static function known(PDO $pdo): array
    {
        static $k = null;
        if ($k !== null) return $k;
        $k = array_fill_keys(self::BASE_WORDS, 1);
        $add = function (string $s) use (&$k) { foreach (preg_split('/[^a-z]+/', mb_strtolower($s)) ?: [] as $w) if (mb_strlen($w) >= 2) $k[$w] = 1; };
        try { foreach ($pdo->query('SELECT name FROM categories WHERE is_active = 1')->fetchAll(PDO::FETCH_COLUMN) as $n) $add((string) $n); } catch (Throwable) {}
        try { foreach ($pdo->query('SELECT phrase FROM situation_triggers')->fetchAll(PDO::FETCH_COLUMN) as $n) $add((string) $n); } catch (Throwable) {}
        try { foreach ($pdo->query('SELECT word FROM search_meanings')->fetchAll(PDO::FETCH_COLUMN) as $n) $add((string) $n); } catch (Throwable) {}
        return $k;
    }

    private static function isKnown(array $known, string $w): bool
    {
        if (isset($known[$w])) return true;
        foreach ([preg_replace('/ies$/', 'y', $w), preg_replace('/(x|ch|sh|ss)es$/', '$1', $w), preg_replace('/s$/', '', $w), $w . 's'] as $v) if ($v !== $w && isset($known[$v])) return true;
        return false;
    }

    /** Phrases people searched that carry on from what's typed: [['q', 'typed', 'rest']] (decisions/0061). */
    public static function completions(PDO $pdo, string $typed, int $max = 2): array
    {
        $t = self::words($typed);
        if (mb_strlen($t) < 3) return [];
        // a pattern (decisions/0093): of the visits that searched something starting this way, the share that searched
        // this phrase, at the confidence those visits give; and the phrase found something for nearly all of them.
        // No time window and no fixed count (each visit counts once, so one person repeating never makes a pattern).
        try {
            $s = fn (string $in) => "SUM(CASE WHEN outcome IN ($in) THEN n ELSE 0 END)";
            $st = $pdo->prepare("SELECT q, " . $s("'search'") . " AS n, " . $s("'zero','unread'") . " AS miss FROM search_outcomes WHERE q LIKE ? GROUP BY q");
            $st->execute([SearchText::esc($t) . '%']);
            $all = $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { error_log('learned completions: ' . $e->getMessage()); return []; }
        $total = (int) array_sum(array_column($all, 'n'));
        $rows = [];
        foreach ($all as $r) {
            $n = (int) $r['n'];
            if ((string) $r['q'] === $t || $n <= 0) continue;
            if (self::wilson($n, $total) < self::PATTERN / 2 || self::wilson(max(0, $n - (int) $r['miss']), $n) < 0.5) continue;
            $rows[] = $r + ['share' => self::wilson($n, $total)];
        }
        usort($rows, fn ($a, $b) => $b['share'] <=> $a['share']);
        $known = self::known($pdo); $out = [];
        foreach ($rows as $r) {
            $q = (string) $r['q'];
            $rest = mb_substr($q, mb_strlen($t));
            if ($rest === '' || !preg_match('/^[a-z ]+$/', $q)) continue;
            // the typed words end on a whole word, or the next one is finished from what's typed ("park" -> "parks for kids")
            $ok = true;
            foreach (explode(' ', $q) as $w) if ($w !== '' && !self::isKnown($known, $w)) { $ok = false; break; }
            if (!$ok) continue;
            $out[] = ['q' => $q, 'typed' => $typed, 'rest' => $rest];
            if (count($out) >= $max) break;
        }
        return $out;
    }

    // ---- scoring ---------------------------------------------------------------------------------------------------

    /** The lower bound of the Wilson score interval (95%): a cautious share, small samples count for less. */
    public static function wilson(int $yes, int $n): float
    {
        if ($n <= 0) return 0.0;
        $z = 1.96; $p = min(1.0, $yes / $n);
        return max(0.0, ($p + $z * $z / (2 * $n) - $z * sqrt(($p * (1 - $p) + $z * $z / (4 * $n)) / $n)) / (1 + $z * $z / $n));
    }

    private static function stem(string $w): string
    {
        $w = mb_strtolower($w);
        if (mb_strlen($w) > 4) $w = preg_replace(['/ies$/', '/(x|ch|sh|ss)es$/', '/ing$/', '/s$/'], ['y', '$1', '', ''], $w);
        return $w;
    }

    private const LITTLE = ['a', 'an', 'the', 'to', 'in', 'on', 'at', 'of', 'for', 'with', 'and', 'or', 'my', 'me', 'i', 'we', 'our', 'near', 'is', 'are',
        'where', 'what', 'how', 'can', 'get', 'find', 'need', 'some', 'any', 'good', 'best', 'place', 'places', 'open', 'now', 'today', 'nearby', 'around'];

    /** Share of the phrase's own words found in what it leads to (the category, the need, the situation). */
    public static function textMatch(string $phrase, string $target): float
    {
        $pw = array_values(array_filter(preg_split('/[^a-z]+/', mb_strtolower($phrase)) ?: [], fn ($w) => mb_strlen($w) >= 2 && !in_array($w, self::LITTLE, true)));
        if (!$pw) return 0.0;
        $tw = [];
        foreach (preg_split('/[^a-z]+/', mb_strtolower($target)) ?: [] as $w) if (mb_strlen($w) >= 2) $tw[self::stem($w)] = 1;
        $hit = 0;
        foreach ($pw as $w) {
            $s = self::stem($w);
            if (isset($tw[$s])) { $hit++; continue; }
            foreach (array_keys($tw) as $t) if (mb_strlen($s) >= 4 && mb_strlen($t) >= 4 && (str_starts_with($t, $s) || str_starts_with($s, $t))) { $hit++; break; }
        }
        return round($hit / count($pw), 3);
    }

    /**
     * Situations whose needs take a category, with the need's words and the situation's own phrases:
     * [sitId => [label, needLabel, needWords, phrases]]. Never a danger situation: learned words don't bring the 911 line.
     */
    private static function situationsFor(PDO $pdo, int $catId): array
    {
        static $map = null;
        if ($map === null) {
            $map = [];
            $cat = $pdo->prepare('SELECT id FROM categories WHERE name LIKE ?');
            $ph = [];
            foreach ($pdo->query('SELECT situation_id, phrase FROM situation_triggers')->fetchAll(PDO::FETCH_ASSOC) as $t) $ph[(int) $t['situation_id']][] = (string) $t['phrase'];
            foreach ($pdo->query("SELECT s.id, s.label, n.label AS need, n.cats, n.words FROM situation_needs n JOIN situations s ON s.id = n.situation_id WHERE s.status IN ('live', 'may_help') AND s.danger = 0")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                foreach (explode('|', (string) $r['cats']) as $p) {
                    if (trim($p) === '') continue;
                    $cat->execute([trim($p)]);
                    foreach ($cat->fetchAll(PDO::FETCH_COLUMN) as $cid) $map[(int) $cid][(int) $r['id']] = [(string) $r['label'], (string) $r['need'], (string) $r['words'], $ph[(int) $r['id']] ?? []];
                }
            }
        }
        return $map[$catId] ?? [];
    }

    /** A category with at least one listing that has a phone: a solution that can complete the task (principle 5). */
    private static function complete(PDO $pdo, int $catId): bool
    {
        try {
            $st = $pdo->prepare("SELECT 1 FROM search_index si JOIN entity_metadata m ON m.entity_id = si.item_id AND m.meta_key = 'phone'
                                 WHERE si.kind = 'listing' AND si.category_id = ? AND m.meta_value <> '' AND m.meta_value <> '\"\"' LIMIT 1");
            $st->execute([$catId]);
            return (bool) $st->fetchColumn();
        } catch (Throwable) { return false; }
    }

    /**
     * Scores every mapping (words -> a kind of thing) by relevance, publishes or retires it on its own (no person needed),
     * and refreshes the situation gaps. Returns a summary. Runs at most every 6 hours unless $force. No time window: a
     * mapping is as good as its meaning, whenever it was searched (decisions/0093).
     */
    public static function run(PDO $pdo, bool $force = false): array
    {
        if (!self::ready($pdo)) return ['ok' => false, 'error' => 'Run app/migrations/2026-10-23_search_learning.sql first.'];
        $last = (int) SearchIndex::state($pdo, 'learning_run');
        if (!$force && $last > time() - self::RUN_EVERY) return ['ok' => true, 'skipped' => true, 'last' => $last];
        SearchIndex::setState($pdo, 'learning_run', (string) time());
        $sum = ['scored' => 0, 'published' => 0, 'may_help' => 0, 'retired' => 0, 'changed' => []];

        // the kinds people opened after a set of words only suggest what to score; relevance decides
        $opens = [];
        $st = $pdo->prepare('SELECT q, category_id, SUM(n) AS n FROM search_opens GROUP BY q, category_id');
        $st->execute();
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $opens[(string) $r['q'] . "\0" . (int) $r['category_id']] = (int) $r['n'];
        // mappings already known are scored again, so one that stops working falls and retires
        $have = [];
        foreach ($pdo->query('SELECT * FROM search_learned')->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $have[(string) $r['phrase'] . "\0" . (int) $r['category_id']] = $r;
            $opens += [(string) $r['phrase'] . "\0" . (int) $r['category_id'] => 0];
        }
        // how often each set of words was searched, in how many areas, over how many days
        $phr = array_values(array_unique(array_map(fn ($k) => explode("\0", $k)[0], array_keys($opens))));
        $srch = [];
        foreach (array_chunk($phr, 200) as $chunk) {
            if (!$chunk) continue;
            $in = implode(',', array_fill(0, count($chunk), '?'));
            $st = $pdo->prepare("SELECT q, SUM(n) AS n, COUNT(DISTINCT place_key) AS areas, MIN(day) AS d1, MAX(day) AS d2 FROM search_outcomes
                                 WHERE outcome = 'search' AND q IN ($in) GROUP BY q");
            $st->execute($chunk);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $srch[(string) $r['q']] = $r;
        }
        $cname = [];
        foreach ($pdo->query('SELECT id, name FROM categories')->fetchAll(PDO::FETCH_KEY_PAIR) as $id => $n) $cname[(int) $id] = (string) $n;
        $srcCount = $pdo->prepare('SELECT COUNT(DISTINCT host) FROM situation_sources WHERE category_id = ? AND ((situation_id = ? AND situation_id > 0) OR (situation_id = 0 AND phrase = ?))');
        $ins = $pdo->prepare('INSERT INTO search_learned (phrase, category_id, situation_id, score, behaviour, sources, text_match, stability, searches, opens, areas, days, status, why, first_seen, changed_at, scored_at)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
        $upd = $pdo->prepare('UPDATE search_learned SET situation_id = ?, score = ?, behaviour = ?, sources = ?, text_match = ?, stability = ?, searches = ?, opens = ?, areas = ?, days = ?,
                              status = ?, why = ?, changed_at = COALESCE(?, changed_at), scored_at = CURRENT_TIMESTAMP WHERE id = ?');
        $read = [];
        foreach ($opens as $key => $n) {
            [$q, $cid] = explode("\0", $key); $cid = (int) $cid;
            if (!isset($cname[$cid])) continue;
            $s = $srch[$q] ?? null;
            $searches = (int) ($s['n'] ?? 0);
            $behaviour = self::wilson(min($n, max($searches, $n)), max($searches, $n));
            // the situation it serves: the words already read as it, or the one whose words it shares most
            $sitId = null; $target = $cname[$cid];
            $cands = self::situationsFor($pdo, $cid);
            if ($cands) {
                if (!isset($read[$q])) { try { $read[$q] = array_map(fn ($x) => (int) $x['id'], Situations::read($pdo, $q)); } catch (Throwable) { $read[$q] = []; } }
                foreach ($read[$q] as $rid) if (isset($cands[$rid])) { $sitId = $rid; break; }
                if ($sitId === null) {
                    $best = 0.0;
                    // the situation's label and need, or the closest of its own phrases ("car wont go" is near "car wont start")
                    foreach ($cands as $sid => [$sl, $nl, $nw, $phs]) {
                        $m = self::textMatch($q, "$sl $nl $nw");
                        foreach ($phs as $one) $m = max($m, self::textMatch($q, $one));
                        if ($m > $best) { $best = $m; $sitId = $sid; }
                    }
                }
                if ($sitId !== null) $target .= ' ' . implode(' ', array_slice($cands[$sitId], 0, 3));
            }
            $text = self::textMatch($q, $target);
            $srcCount->execute([$cid, (int) $sitId, $q]);
            $sources = min(1.0, (int) $srcCount->fetchColumn() / 3);
            $span = $s ? (int) round((strtotime((string) $s['d2']) - strtotime((string) $s['d1'])) / 86400) + 1 : 0;
            $areas = (int) ($s['areas'] ?? 0);
            $stability = min(1.0, max($span / 14, $areas / 3));
            $W = self::WEIGHTS;
            $score = round($W['sources'] * $sources + $W['text'] * $text, 3);   // relevance only; usage ($behaviour) is kept to order ties
            // gate, whatever the score: a solution that can complete the task
            $gate = !self::complete($pdo, $cid) ? 'no listing of this kind has a phone yet' : '';
            $old = $have[$key] ?? null;
            $was = (string) ($old['status'] ?? 'learning');
            $status = $gate !== '' ? 'learning' : ($score >= self::publishAt($pdo) ? 'live' : ($score >= self::mayHelpAt($pdo) ? 'may_help' : 'learning'));
            if ($status === 'learning' && in_array($was, ['live', 'may_help', 'retired'], true)) $status = 'retired';   // fell back: retires on its own
            if ($old && (int) $old['held']) $status = $was;   // a person set it
            $why = sprintf('Words match %s %.0f%%; %d outside source%s back it. Usage, for ties only: %d of %d searches opened it%s',
                $cname[$cid], $text * 100, (int) round($sources * 3), (int) round($sources * 3) === 1 ? '' : 's', $n, $searches, $gate !== '' ? '. Waiting: ' . $gate : '');
            $changed = $status !== $was || !$old ? date('Y-m-d H:i:s') : null;
            if ($old) $upd->execute([$sitId, $score, round($behaviour, 3), round($sources, 3), $text, round($stability, 3), $searches, $n, $areas, $span, $status, mb_substr($why, 0, 400), $status !== $was ? $changed : null, (int) $old['id']]);
            else $ins->execute([$q, $cid, $sitId, $score, round($behaviour, 3), round($sources, 3), $text, round($stability, 3), $searches, $n, $areas, $span, $status, mb_substr($why, 0, 400), date('Y-m-d'), $status !== 'learning' ? $changed : null]);
            $sum['scored']++;
            if ($status !== $was || (!$old && $status !== 'learning')) {
                $sum['changed'][] = "$q → {$cname[$cid]}: " . (self::STATUS[$was] ?? $was) . ' → ' . self::STATUS[$status];
                self::apply($pdo, $q, $sitId, $status, $was);
            }
            if ($status === 'live') $sum['published']++; elseif ($status === 'may_help') $sum['may_help']++; elseif ($status === 'retired') $sum['retired']++;
        }
        try { $sum['gaps'] = self::gaps($pdo); } catch (Throwable $e) { error_log('learning gaps: ' . $e->getMessage()); $sum['gaps'] = ['error' => $e->getMessage()]; }
        try { require_once __DIR__ . '/SearchDrafts.php'; $sum['drafts'] = SearchDrafts::refresh($pdo); } catch (Throwable $e) { error_log('learning drafts: ' . $e->getMessage()); }
        try { require_once __DIR__ . '/HowGuides.php'; $sum['guides'] = HowGuides::refresh($pdo); } catch (Throwable $e) { error_log('learning guides: ' . $e->getMessage()); }   // decisions/0063 §8
        $sum['ok'] = true;
        return $sum;
    }

    /** A published mapping with a situation becomes one of its phrases ('learned'); leaving published removes it. */
    private static function apply(PDO $pdo, string $q, ?int $sitId, string $status, string $was): void
    {
        if (!$sitId) return;
        $p = Situations::norm($q);
        if ($p === '') return;
        try {
            if ($status === 'live') {
                $st = $pdo->prepare('SELECT 1 FROM situation_triggers WHERE situation_id = ? AND phrase = ?'); $st->execute([$sitId, $p]);
                if (!$st->fetchColumn()) $pdo->prepare("INSERT INTO situation_triggers (situation_id, phrase, source) VALUES (?, ?, 'learned')")->execute([$sitId, $p]);
            } elseif ($was === 'live') {
                $pdo->prepare("DELETE FROM situation_triggers WHERE situation_id = ? AND phrase = ? AND source = 'learned'")->execute([$sitId, $p]);
            }
        } catch (Throwable $e) { error_log('learning apply: ' . $e->getMessage()); }
    }

    /** What search learned for these exact words: [['label', 'q', 'status', 'score']]; Published first. */
    public static function forSearch(PDO $pdo, string $q): array
    {
        if (!self::ready($pdo)) return [];
        try {
            $st = $pdo->prepare("SELECT l.status, l.score, c.name FROM search_learned l JOIN categories c ON c.id = l.category_id
                                 WHERE l.phrase = ? AND l.status IN ('live', 'may_help') ORDER BY l.status = 'live' DESC, l.score DESC, l.behaviour DESC LIMIT 3");
            $st->execute([self::words($q)]);
            return array_map(fn ($r) => ['label' => SearchText::catLabel((string) $r['name']), 'q' => mb_strtolower(SearchText::catLabel((string) $r['name'])),
                                         'status' => (string) $r['status'], 'score' => (float) $r['score']], $st->fetchAll(PDO::FETCH_ASSOC));
        } catch (Throwable) { return []; }
    }

    // ---- situation gaps and the crawler ----------------------------------------------------------------------------

    /** Tier 1 kinds: words in a need's label or categories -> OpenStreetMap filters and Wikidata classes. */
    private const OSM = [
        'tow|wrecker' => [['nwr["service:vehicle:towing"="yes"]', 'nwr["shop"="car_repair"]["service:vehicle:towing"]'], []],
        'auto repair|automobile repair|roadside repair|mechanic|truck-repair' => [['nwr["shop"="car_repair"]'], []],
        'tire' => [['nwr["shop"="tyres"]'], []],
        'gas|service station|fuel|truck stop' => [['nwr["amenity"="fuel"]'], []],
        'hardware|generator' => [['nwr["shop"~"^(hardware|doityourself)$"]'], []],
        'plumb' => [['nwr["craft"="plumber"]'], []],
        'electrician|electric contractor' => [['nwr["craft"="electrician"]'], []],
        'locksmith' => [['nwr["shop"="locksmith"]', 'nwr["craft"="locksmith"]'], []],
        'veterinar|animal hospital' => [['nwr["amenity"="veterinary"]'], []],
        'pharmac|drug store' => [['nwr["amenity"="pharmacy"]'], ['Q13107184']],
        'hospital|emergency room' => [['nwr["amenity"="hospital"]'], ['Q16917']],
        'urgent care|clinic|physician' => [['nwr["amenity"~"^(clinic|doctors)$"]', 'nwr["healthcare"="clinic"]'], []],
        'dentist|dental' => [['nwr["amenity"="dentist"]'], []],
        'grocer|supermarket' => [['nwr["shop"~"^(supermarket|convenience)$"]'], []],
        'restaurant|food & dining|coffee' => [['nwr["amenity"~"^(restaurant|fast_food|cafe)$"]'], []],
        'hotel|motel|lodging' => [['nwr["tourism"~"^(hotel|motel)$"]'], []],
        'campground|rv park|camp' => [['nwr["tourism"~"^(camp_site|caravan_site)$"]'], []],
        'laundr' => [['nwr["shop"~"^(laundry|dry_cleaning)$"]'], []],
        'police|sheriff|highway patrol' => [['nwr["amenity"="police"]'], ['Q861951']],
        'fire department|fire station' => [['nwr["amenity"="fire_station"]'], ['Q1195942']],
        'post office' => [['nwr["amenity"="post_office"]'], ['Q35054']],
        'librar' => [['nwr["amenity"="library"]'], ['Q7075']],
        'food bank|food pantr' => [['nwr["amenity"="food_bank"]', 'nwr["social_facility"~"^(food_bank|soup_kitchen)$"]'], []],
        'shelter' => [['nwr["social_facility"="shelter"]'], []],
        'courthouse|court' => [['nwr["amenity"="courthouse"]'], ['Q1137809']],
        'church' => [['nwr["amenity"="place_of_worship"]["religion"="christian"]'], []],
        'car wash' => [['nwr["amenity"="car_wash"]'], []],
        'rest area' => [['nwr["highway"="rest_area"]'], []],
    ];

    public static function needKey(string $slug, string $label): string { return substr(md5($slug . '|' . mb_strtolower($label)), 0, 12); }

    /** The Tier 1 lookups for a need, or null when no open dataset covers it (it goes to Tier 2). */
    public static function tier1For(string $label, string $cats, string $words): ?array
    {
        $hay = mb_strtolower("$label $cats $words");
        foreach (self::OSM as $pat => [$osm, $wd]) if (preg_match('/' . str_replace(['/', '&'], ['\/', '\&'], $pat) . '/', $hay)) return ['osm' => $osm, 'wikidata' => $wd];
        return null;
    }

    /** A situation gap as the crawl job's "looking_for" (CrawlQueue::describe): what to look for and how. */
    public static function lookingFor(PDO $pdo, string $needKey): ?array
    {
        $st = $pdo->prepare('SELECT g.situation_id, g.need_label, n.cats, n.words FROM situation_gaps g JOIN situation_needs n ON n.situation_id = g.situation_id AND n.label = g.need_label WHERE g.need_key = ? LIMIT 1');
        $st->execute([$needKey]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $t1 = self::tier1For((string) $r['need_label'], (string) $r['cats'], (string) $r['words']);
        if (!$t1) return null;
        $cats = [];
        $c = $pdo->prepare('SELECT id, name FROM categories WHERE name LIKE ?');
        foreach (explode('|', (string) $r['cats']) as $p) { if (trim($p) === '') continue; $c->execute([trim($p)]); foreach ($c->fetchAll(PDO::FETCH_ASSOC) as $x) $cats[(int) $x['id']] = ['id' => (int) $x['id'], 'name' => (string) $x['name']]; }
        return ['group' => (string) $r['need_label'], 'categories' => array_values($cats), 'osm' => $t1['osm'], 'wikidata' => $t1['wikidata'],
                'offerings' => array_values(array_map(fn ($x) => $x['name'], $cats)) ?: [(string) $r['need_label']], 'situation_id' => (int) $r['situation_id']];
    }

    /**
     * Situation gaps: for each area where people searched a situation (3+ times in 30 days), each of its needs with
     * nothing within 25 miles. Tier 1 first (a crawl job, when an open dataset covers the need); Tier 2 when Tier 1
     * can't (no dataset, or its job found nothing, or a week went by without an answer showing).
     */
    public static function gaps(PDO $pdo): array
    {
        $out = ['areas' => 0, 'gaps' => 0, 'tier1' => 0, 'tier2' => 0, 'filled' => 0];
        // searches set to a cluster, and to a town in one (review E22, decisions/0160 W12: only cluster-scoped searches counted,
        // so a need searched town by town never added up); towns outside our clusters are built out by TownCrawl instead
        $st = $pdo->prepare("SELECT CASE WHEN o.place_key LIKE 'town:%' THEN CONCAT('cluster:', a.cluster_id) ELSE o.place_key END AS place_key, o.q, SUM(o.n) AS n
                               FROM search_outcomes o LEFT JOIN anchors a ON o.place_key LIKE 'town:%' AND a.id = CAST(SUBSTRING(o.place_key, 6) AS UNSIGNED)
                              WHERE o.outcome = 'search' AND o.day >= ? AND (o.place_key LIKE 'cluster:%' OR (o.place_key LIKE 'town:%' AND a.cluster_id IS NOT NULL))
                              GROUP BY 1, o.q");
        $st->execute([date('Y-m-d', strtotime('-30 days'))]);
        $demand = []; $sits = []; $read = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $q = (string) $r['q'];
            if (!isset($read[$q])) { try { $read[$q] = Situations::read($pdo, $q); } catch (Throwable) { $read[$q] = []; } }
            foreach ($read[$q] as $s) { $demand[(int) substr((string) $r['place_key'], 8)][(int) $s['id']] = ($demand[(int) substr((string) $r['place_key'], 8)][(int) $s['id']] ?? 0) + (int) $r['n']; $sits[(int) $s['id']] = $s; }
        }
        $slugOf = $pdo->prepare('SELECT slug FROM micro_clusters WHERE id = ?');
        $needs = $pdo->prepare('SELECT label, cats, words FROM situation_needs WHERE situation_id = ? ORDER BY pos');
        $get = $pdo->prepare('SELECT * FROM situation_gaps WHERE need_key = ? AND cluster_id = ?');
        $ins = $pdo->prepare("INSERT INTO situation_gaps (need_key, situation_id, need_label, cluster_id, searches, status, updated_at) VALUES (?, ?, ?, ?, ?, 'open', CURRENT_TIMESTAMP)");
        $set = $pdo->prepare('UPDATE situation_gaps SET searches = ?, status = ?, tier1_job_id = ?, note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        foreach ($demand as $cid => $bySit) {
            $slugOf->execute([$cid]); $slug = $slugOf->fetchColumn();
            if (!$slug) continue;
            $place = UniversalSearch::scopePlace($pdo, ['level' => 'cluster', 'slug' => (string) $slug]);
            if (!$place) continue;
            $out['areas']++;
            $center = UniversalSearch::centerOf($pdo, $place);
            foreach ($bySit as $sid => $n) {
                if ($n < 3 || !isset($sits[$sid])) continue;
                $a = Situations::answer($pdo, [$sits[$sid]], $place, ['center' => $center ? [$center['lat'], $center['lon']] : null, 'reach' => '25', 'per' => 1]);
                $have = [];
                foreach ($a['needs'] ?? [] as $nd) if (empty($nd['resource'])) $have[mb_strtolower((string) $nd['label'])] = count($nd['items']);
                $needs->execute([$sid]);
                foreach ($needs->fetchAll(PDO::FETCH_ASSOC) as $nd) {
                    $key = self::needKey((string) $sits[$sid]['slug'], (string) $nd['label']);
                    $get->execute([$key, $cid]); $g = $get->fetch(PDO::FETCH_ASSOC);
                    $found = $have[mb_strtolower((string) $nd['label'])] ?? 0;
                    if ($found > 0) {   // answered here now
                        if ($g && $g['status'] !== 'filled') { $set->execute([$n, 'filled', $g['tier1_job_id'], 'Answered within 25 miles now.', $g['id']]); $out['filled']++; }
                        continue;
                    }
                    $out['gaps']++;
                    if (!$g) { $ins->execute([$key, $sid, mb_substr((string) $nd['label'], 0, 120), $cid, $n]); $get->execute([$key, $cid]); $g = $get->fetch(PDO::FETCH_ASSOC); }
                    if (!$g) continue;
                    $status = $g['status'] === 'filled' ? 'open' : (string) $g['status'];
                    $job = $g['tier1_job_id'] !== null ? (int) $g['tier1_job_id'] : null; $note = (string) $g['note'];
                    if ($status === 'open') {
                        if (self::tier1For((string) $nd['label'], (string) $nd['cats'], (string) $nd['words'])) {
                            $job = self::queue($pdo, $cid, 'sit:' . $key, $n);
                            $status = $job ? 'tier1' : 'tier2'; $note = $job ? 'Queued for OpenStreetMap and Wikidata.' : 'Couldn\'t queue a crawl job; a web search instead.';
                        } else { $status = 'tier2'; $note = 'No open dataset covers this; a web search of official sites.'; }
                    } elseif ($status === 'tier1' && $job) {
                        $j = $pdo->prepare('SELECT status, result, updated_at FROM ' . Database::t('crawl_jobs') . ' WHERE id = ?'); $j->execute([$job]); $jr = $j->fetch(PDO::FETCH_ASSOC);
                        $res = $jr ? (json_decode((string) $jr['result'], true) ?: []) : [];
                        if (!$jr || $jr['status'] === 'failed' || ($jr['status'] === 'done' && (int) ($res['candidates'] ?? 0) === 0)
                            || ($jr['status'] === 'done' && strtotime((string) $jr['updated_at']) < time() - 7 * 86400)) {
                            $status = 'tier2'; $note = !$jr || $jr['status'] === 'failed' ? 'The crawl job failed; a web search instead.' : ((int) ($res['candidates'] ?? 0) === 0 ? 'OpenStreetMap and Wikidata found nothing; a web search instead.' : 'Found places a week ago but none answer yet; a web search too.');
                        }
                    }
                    $set->execute([$n, $status, $job, mb_substr($note, 0, 300), $g['id']]);
                    if ($status === 'tier1') $out['tier1']++; elseif ($status === 'tier2') $out['tier2']++;
                }
            }
        }
        return $out;
    }

    /** A crawl job for one gap (crawl_jobs, group "sit:<need key>"); an existing one is reused. Its id, or null. */
    private static function queue(PDO $pdo, int $clusterId, string $group, int $priority): ?int
    {
        try {
            $st = $pdo->prepare('SELECT id, status FROM ' . Database::t('crawl_jobs') . ' WHERE cluster_id = ? AND group_label = ?'); $st->execute([$clusterId, $group]);
            if ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                if ($r['status'] === 'failed') $pdo->prepare("UPDATE " . Database::t('crawl_jobs') . " SET status = 'queued', attempts = 0, lease_until = NULL WHERE id = ?")->execute([(int) $r['id']]);
                return (int) $r['id'];
            }
            $pdo->prepare("INSERT INTO " . Database::t('crawl_jobs') . " (cluster_id, group_label, priority, status, created_at, updated_at) VALUES (?, ?, ?, 'queued', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)")
                ->execute([$clusterId, mb_substr($group, 0, 60), $priority]);
            return (int) $pdo->lastInsertId();
        } catch (Throwable $e) { error_log('learning queue: ' . $e->getMessage()); return null; }
    }

    /** A situation crawl job finished (CrawlQueue::complete): each website it found places on is a Tier 1 source. */
    public static function tier1Done(PDO $pdo, string $group, int $clusterId, array $candidates): void
    {
        if (!self::ready($pdo) || !str_starts_with($group, 'sit:')) return;
        $key = substr($group, 4);
        $lf = self::lookingFor($pdo, $key);
        if (!$lf) return;
        $hosts = [];
        foreach ($candidates as $c) {
            $u = (string) ($c['source']['start_url'] ?? '');
            $h = preg_replace('/^www\./', '', strtolower((string) parse_url($u, PHP_URL_HOST)));
            if ($h !== '') $hosts[$h] = $u;
        }
        $ins = $pdo->prepare('INSERT INTO situation_sources (situation_id, phrase, category_id, host, url, title, tier) VALUES (?, \'\', ?, ?, ?, ?, 1)');
        foreach ($hosts as $h => $u) foreach ($lf['categories'] as $cat) { try { $ins->execute([$lf['situation_id'], $cat['id'], $h, mb_substr($u, 0, 500), mb_substr($lf['group'], 0, 190)]); } catch (PDOException) {} }
        $pdo->prepare('UPDATE situation_gaps SET found = ?, note = ?, updated_at = CURRENT_TIMESTAMP WHERE need_key = ? AND cluster_id = ?')
            ->execute([count($candidates), count($candidates) . ' place(s) found on ' . (implode(', ', array_keys($hosts)) ?: 'no open dataset') . '; they go through the usual checks.', $key, $clusterId]);
    }

    /**
     * Web-search work for the worker (Tier 2), a few per run: gaps Tier 1 couldn't fill, and mappings that people use
     * but no outside source names yet. Each is looked for at most once a month. Only .gov, .edu and the sources we
     * read regularly count.
     */
    public static function tier2Next(PDO $pdo, int $limit = 3): array
    {
        if (!self::ready($pdo)) return ['tasks' => [], 'domains' => []];
        $month = date('Y-m-d H:i:s', strtotime('-30 days'));
        $tasks = [];
        $st = $pdo->prepare("SELECT g.id, g.need_label, g.cluster_id, s.label AS situation FROM situation_gaps g JOIN situations s ON s.id = g.situation_id
                             WHERE g.status = 'tier2' AND (g.tier2_at IS NULL OR g.tier2_at < ?) ORDER BY g.searches DESC LIMIT " . max(1, min(5, $limit)));
        $st->execute([$month]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $g) {
            $towns = self::towns($pdo, (int) $g['cluster_id']);
            if (!$towns) continue;
            $tasks[] = ['task' => 'gap', 'id' => (int) $g['id'], 'query' => $g['need_label'] . ' ' . $towns[0]['town'] . ', ' . $towns[0]['state'],
                        'need_words' => self::content((string) $g['need_label']), 'towns' => array_map(fn ($t) => $t['town'], $towns), 'state' => $towns[0]['state']];
        }
        if (count($tasks) < $limit) {
            $st = $pdo->prepare("SELECT l.id, l.phrase, c.name FROM search_learned l JOIN categories c ON c.id = l.category_id
                                 WHERE l.status IN ('learning', 'may_help') AND l.searches >= ? AND l.behaviour >= 0.5 AND l.sources < 1 AND (l.tier2_at IS NULL OR l.tier2_at < ?)
                                 ORDER BY l.score DESC LIMIT " . ($limit - count($tasks)));
            $st->execute([self::MIN_SEARCHES, $month]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $l) {
                $tasks[] = ['task' => 'mapping', 'id' => (int) $l['id'], 'query' => '"' . $l['phrase'] . '" ' . SearchText::catLabel((string) $l['name']),
                            'need_words' => array_values(array_unique(array_merge(self::content((string) $l['phrase']), array_slice(self::content(SearchText::catLabel((string) $l['name'])), 0, 1)))), 'towns' => [], 'state' => ''];
            }
        }
        return ['tasks' => $tasks, 'domains' => self::readDomains($pdo)];
    }

    private static function content(string $s): array
    {
        return array_values(array_filter(preg_split('/[^a-z]+/', mb_strtolower($s)) ?: [], fn ($w) => mb_strlen($w) >= 3 && !in_array($w, self::LITTLE, true) && $w !== 'non' && $w !== 'emergency'));
    }

    /** Sources a person marked "Read regularly" (not commercial or social): verified, so their pages count in Tier 2. */
    public static function readDomains(PDO $pdo): array
    {
        try { $hosts = $pdo->query("SELECT host FROM " . Database::t('reference_sources') . " WHERE status = 'read' AND kind NOT IN ('commercial', 'social', 'own_site')")->fetchAll(PDO::FETCH_COLUMN); }
        catch (Throwable) { return []; }
        require_once __DIR__ . '/crawler/Sources.php';   // the source register: only sources whose licence lets us keep what they say (decisions/0133)
        return array_values(array_filter($hosts, fn ($h) => Sources::mayStore($pdo, (string) $h)));
    }

    private static function towns(PDO $pdo, int $clusterId): array
    {
        require_once __DIR__ . '/CrawlerIngest.php';
        $st = $pdo->prepare('SELECT geo_hub_id FROM micro_clusters WHERE id = ?'); $st->execute([$clusterId]);
        $hub = $st->fetchColumn();
        if ($hub === false) return [];
        $c = CrawlerIngest::loadClusters($pdo, (int) $hub)[$clusterId] ?? null;
        $out = [];
        foreach ($c['members'] ?? [] as $m) if (!empty($m['city'])) $out[mb_strtolower($m['city'])] = ['town' => (string) $m['city'], 'state' => (string) $m['state']];
        return array_values($out);
    }

    /** An allowed Tier 2 page: .gov, .edu, a state or local .us site, or a source we read regularly. */
    public static function allowedHost(string $host, array $read): bool
    {
        $host = preg_replace('/^www\./', '', strtolower($host));
        if (preg_match('/\.(gov|edu)$|\.gov\.|\.(state|co|ci|k12)\.[a-z]{2}\.us$|\.[a-z]{2}\.us$/', $host)) return true;
        foreach ($read as $r) if ($host === $r || str_ends_with($host, '.' . $r)) return true;
        return false;
    }

    /**
     * The worker's findings for one Tier 2 task: [{url, title, places}]. Each allowed page is an outside source for the
     * gap or mapping; each joins the source list, and one that lists 3+ places is read regularly from then on, so the
     * same paid search isn't needed again. Returns ['kept' => n].
     */
    public static function tier2Result(PDO $pdo, string $task, int $id, array $pages): array
    {
        if (!self::ready($pdo)) return ['kept' => 0];
        require_once __DIR__ . '/crawler/Sources.php';
        $read = self::readDomains($pdo); $kept = 0;
        $ins = $pdo->prepare('INSERT INTO situation_sources (situation_id, phrase, category_id, host, url, title, tier) VALUES (?, ?, ?, ?, ?, ?, 2)');
        if ($task === 'gap') {
            $st = $pdo->prepare('SELECT g.*, s.slug FROM situation_gaps g JOIN situations s ON s.id = g.situation_id WHERE g.id = ?'); $st->execute([$id]);
            $g = $st->fetch(PDO::FETCH_ASSOC);
            if (!$g) return ['kept' => 0];
            $lf = self::lookingForRow($pdo, (int) $g['situation_id'], (string) $g['need_label']);
            $targets = array_map(fn ($c) => [(int) $g['situation_id'], '', $c], $lf ?: []);
            $label = (string) $g['need_label'];
        } else {
            $st = $pdo->prepare('SELECT * FROM search_learned WHERE id = ?'); $st->execute([$id]);
            $l = $st->fetch(PDO::FETCH_ASSOC);
            if (!$l) return ['kept' => 0];
            $targets = [[(int) ($l['situation_id'] ?? 0), (int) ($l['situation_id'] ?? 0) ? '' : (string) $l['phrase'], (int) $l['category_id']]];
            $label = (string) $l['phrase'];
        }
        foreach (array_slice($pages, 0, 10) as $p) {
            $url = (string) ($p['url'] ?? ''); $host = preg_replace('/^www\./', '', strtolower((string) parse_url($url, PHP_URL_HOST)));
            if ($host === '' || !self::allowedHost($host, $read)) continue;
            $title = mb_substr(trim((string) ($p['title'] ?? '')), 0, 190);
            foreach ($targets as [$sid, $ph, $cid]) { try { $ins->execute([$sid, $ph, $cid, $host, mb_substr($url, 0, 500), $title]); } catch (PDOException) {} }
            try {
                Sources::note($pdo, $url, preg_match('/\.(gov|us)$/', $host) ? 'government' : 'directory', $label, $title);
                if ((int) ($p['places'] ?? 0) >= 3) $pdo->prepare("UPDATE " . Database::t('reference_sources') . " SET status = 'read' WHERE host = ? AND status = 'suggested'")->execute([$host]);
            } catch (Throwable $e) { error_log('learning tier2 source: ' . $e->getMessage()); }
            $kept++;
        }
        if ($task === 'gap') $pdo->prepare('UPDATE situation_gaps SET tier2_at = CURRENT_TIMESTAMP, found = found + ?, note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
            ->execute([$kept, $kept ? "$kept official page(s) found by web search; they're now sources." : 'A web search of official sites found nothing this month.', $id]);
        else $pdo->prepare('UPDATE search_learned SET tier2_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$id]);
        return ['kept' => $kept];
    }

    /** A need's category ids, by its situation and label. */
    private static function lookingForRow(PDO $pdo, int $sitId, string $label): array
    {
        $st = $pdo->prepare('SELECT cats FROM situation_needs WHERE situation_id = ? AND label = ? LIMIT 1'); $st->execute([$sitId, $label]);
        $ids = [];
        $c = $pdo->prepare('SELECT id FROM categories WHERE name LIKE ?');
        foreach (explode('|', (string) $st->fetchColumn()) as $p) { if (trim($p) === '') continue; $c->execute([trim($p)]); foreach ($c->fetchAll(PDO::FETCH_COLUMN) as $id) $ids[(int) $id] = (int) $id; }
        return array_values($ids);
    }

    // ---- Admin -----------------------------------------------------------------------------------------------------

    /** A person sets a mapping's status (it's held there), or lets learning decide again. */
    public static function adminSet(PDO $pdo, int $id, string $status): void
    {
        $st = $pdo->prepare('SELECT * FROM search_learned WHERE id = ?'); $st->execute([$id]);
        $l = $st->fetch(PDO::FETCH_ASSOC);
        if (!$l) throw new InvalidArgumentException('Not found.');
        if ($status === 'auto') { $pdo->prepare('UPDATE search_learned SET held = 0 WHERE id = ?')->execute([$id]); return; }
        if (!isset(self::STATUS[$status])) throw new InvalidArgumentException('Unknown status.');
        $pdo->prepare('UPDATE search_learned SET status = ?, held = 1, changed_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$status, $id]);
        if ($status !== $l['status']) self::apply($pdo, (string) $l['phrase'], $l['situation_id'] !== null ? (int) $l['situation_id'] : null, $status, (string) $l['status']);
    }

    /** New "<service> help" pairs people search (token windows): the service words search may not know yet. */
    public static function serviceWords(PDO $pdo, int $days = 90): array
    {
        try {
            $st = $pdo->prepare("SELECT q, SUM(n) AS n FROM search_outcomes WHERE outcome = 'search' AND day >= ? AND (q LIKE '% help' OR q LIKE 'help with %' OR q LIKE '% assistance') GROUP BY q HAVING SUM(n) >= 3 ORDER BY SUM(n) DESC LIMIT 30");
            $st->execute([date('Y-m-d', strtotime("-$days days"))]);
            $known = self::known($pdo); $out = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $w = trim(preg_replace('/^help with |( help| assistance)$/', '', (string) $r['q']));
                if ($w === '' || str_contains($w, ' ') && count(explode(' ', $w)) > 3) continue;
                $new = array_values(array_filter(explode(' ', $w), fn ($x) => !self::isKnown($known, $x)));
                $out[] = ['q' => (string) $r['q'], 'service' => $w, 'n' => (int) $r['n'], 'new' => $new];
            }
            return $out;
        } catch (Throwable) { return []; }
    }
}
