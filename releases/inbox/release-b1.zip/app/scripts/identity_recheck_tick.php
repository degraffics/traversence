<?php
// app/scripts/identity_recheck_tick.php — The identity recheck (decisions/0164 §6.1; W2 task `recheck`; 0163 §12's numbers):
// live listings checked against each other by the one identity check. Exact twins (unclaimed, nothing a person's) merge by
// themselves, logged with Undo; variations go to "Vet this place" (W2's identity task); what the evidence can't settle, or
// anything claimed or a person's, becomes a step of "The engine needs a person". Pairs sent by the live-pairs pass and Data
// cleanup, and Review's open crawler offers (Pulse case #23), come first. Shipped off: it runs only while the master, W2
// and its task are switched on (Automation::JOBS and the task's own switch). Not in Scheduler::AUTO: added in System
// Configuration → Scheduled tasks when it's wanted, in a quiet hour.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('identity_recheck_tick');
require_once __DIR__ . '/../lib/ListingIdentity.php';
$pdo = Database::connection();
$r = ListingIdentity::recheckTick($pdo);
if ($r['why'] !== '' && !$r['checked']) { echo 'Not run: ' . $r['why'] . "\n"; exit(0); }
echo 'Identity recheck: ' . $r['checked'] . ' checked, ' . $r['merged'] . ' exact twins merged, ' . $r['vetted'] . ' sent to be vetted, ' . $r['queued'] . ' to the identity queue'
    . ($r['held'] ? ', ' . $r['held'] . ' held for a person\'s OK (many in one town)' : '') . ($r['why'] !== '' ? '. ' . $r['why'] : '') . ".\n";
