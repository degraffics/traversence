<?php
// user/journeys/compose.php — write or edit a journey (decisions/0056). Contributors only (journeys/ is the way in).
// Category and title, the place it's about, "Was here", the story, photos (stripped and resized on upload, then tagged
// by the contributor if they want: a caption, where it was taken, a pin), one YouTube or Vimeo video, the listings it
// mentions, the contributor's own flags (tribal land, public event, permission, private property, people shown), and
// Partnership. Save as a draft or publish.
// Two ways in (decisions/0058 §2): a contributor writes as themselves, or as a listing whose team they're on; staff with
// a content role write Traversence articles and guides from Admin → Journeys (?editorial=1), and a Content Creator's
// "Publish" sends the piece to an editor instead.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../../app/ui/page-shell.php';
require_once __DIR__ . '/../../../app/ui/journey-ui.php';
require_once __DIR__ . '/../../../app/lib/Journeys.php';

$uid = Auth::currentUserId();
if ($uid === null) { header('Location: /login.php?next=' . rawurlencode($_SERVER['REQUEST_URI'] ?? '/user/journeys/'), true, 302); exit; }
$pdo = Database::connection();
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$staff = Journeys::ready($pdo) && Journeys::isStaff($pdo, $uid);
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0) ?: null;
$j = $id ? Journeys::get($pdo, $id) : null;
if ($id && $j && !Journeys::canEdit($pdo, $j, $uid)) { header('Location: /journeys/view.php?id=' . $id, true, 302); exit; }   // staff hide or restore; they don't edit a contributor's words
if ($id && !$j) { http_response_code(404); $id = null; }
$editorial = $j ? $j['voice'] === 'traversence' : ($staff && !empty($_GET['editorial'] ?? $_POST['editorial'] ?? ''));
if (!Journeys::ready($pdo) || (!$editorial && !Journeys::contributor($pdo, $uid))) { header('Location: /user/journeys/', true, 302); exit; }
$canPublish = !$editorial || Journeys::staffCan($pdo, $uid, 'publish');
$asListings = $editorial ? [] : Journeys::listingsFor($pdo, $uid);
$back = $editorial ? '/admin/journeys.php' : '/user/journeys/';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $in = ['voice' => $editorial ? 'traversence' : 'contributor'] + $_POST + ['publish' => ($_POST['do'] ?? '') === 'publish'];
        if (!empty($_POST['coauthors_set'])) $in['coauthors'] = (array) ($_POST['coauthors'] ?? []);   // none left means everyone was removed
        $id = Journeys::save($pdo, $uid, $in, $id);
        foreach ((array) ($_POST['m'] ?? []) as $mid => $m) {   // the photos already there: caption, where, pin, or remove
            $mid = (int) $mid;
            try {
                if (!empty($m['remove'])) { Journeys::removePhoto($pdo, $uid, $mid); continue; }
                $pt = array_map('trim', explode(',', (string) ($m['pin'] ?? '')));
                $lat = count($pt) === 2 && is_numeric($pt[0]) && is_numeric($pt[1]) ? (float) $pt[0] : null;
                $lon = $lat !== null ? (float) $pt[1] : null;
                Journeys::updatePhoto($pdo, $uid, $mid, (string) ($m['caption'] ?? ''), (string) ($m['place'] ?? ''), $lat, $lon,
                                      ['taken' => (string) ($m['taken'] ?? ''), 'source' => (string) ($m['source'] ?? 'own'), 'credit' => (string) ($m['credit'] ?? '')]);
            } catch (InvalidArgumentException $x) { $errors[] = $x->getMessage(); }
        }
        // new photos come in after this, through the site's one uploader (api/upload.php, target journey_photo: decisions/0127)
        $_SESSION['jr_flash'] = trim((Journeys::$held ?? (($_POST['do'] ?? '') === 'publish' ? 'Published.' : 'Draft saved.')) . (Journeys::$pinNote ? ' ' . Journeys::$pinNote : '') . ($errors ? ' ' . implode(' ', $errors) : ''));
        header('Location: /user/journeys/compose.php?id=' . $id, true, 303);   // a Traversence piece reopens in the admin shell (its voice says so)
        exit;
    } catch (InvalidArgumentException $e) {
        $errors[] = $e->getMessage();
        $j = array_merge($j ?? [], array_intersect_key($_POST, array_flip(['title', 'category', 'place_key', 'place_label', 'was_here', 'was_time', 'pin', 'reuse', 'caution', 'mature', 'body', 'video_url', 'as'])),
                         ['flags' => implode(',', (array) ($_POST['flags'] ?? [])), 'listings' => implode(',', (array) ($_POST['listings'] ?? []))]);
    }
}
$flash = $_SESSION['jr_flash'] ?? null; unset($_SESSION['jr_flash']);
// a new journey started from a place's page ("Share a photo"): the place and its pin come filled in (decisions/0058 §30)
if (!$j && $_SERVER['REQUEST_METHOD'] !== 'POST' && ($_GET['about'] ?? '') !== '') {
    $pt = Journeys::point((string) ($_GET['pin'] ?? ''));
    $j = ['place_label' => mb_substr(trim(strip_tags((string) $_GET['about'])), 0, 160),
          'place_key' => preg_match('/^(hub|geo_hub|cluster):\d+$/', (string) ($_GET['key'] ?? '')) ? (string) $_GET['key'] : '',
          'pin' => $pt ? $pt[0] . ', ' . $pt[1] : '', 'author_id' => $uid];
}
$v = fn (string $k, string $d = '') => (string) ($j[$k] ?? $d);
$flags = array_filter(explode(',', $v('flags')));
$listingIds = array_filter(array_map('intval', explode(',', $v('listings'))));
$listingNames = [];
if ($listingIds) {
    $st = $pdo->query('SELECT id, name FROM entities WHERE id IN (' . implode(',', $listingIds) . ')');
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $listingNames[(int) $r['id']] = (string) $r['name'];
}
$media = $id ? Journeys::media($pdo, $id) : [];
$published = ($j['status'] ?? '') === 'published';
$details = Journeys::detailed($pdo);
if ($j && !isset($j['pin']) && isset($j['pin_lat']) && $j['pin_lat'] !== null) $j['pin'] = (float) $j['pin_lat'] . ', ' . (float) $j['pin_lon'];
if ($j && !empty($j['was_time'])) $j['was_time'] = substr((string) $j['was_time'], 0, 5);
$isAuthor = !$j || (int) $j['author_id'] === $uid;
$coauthors = $id && $details ? Journeys::coauthors($pdo, $id, true) : [];
$asNow = !empty($j['entity_id']) ? 'listing:' . (int) $j['entity_id'] : (string) ($j['as'] ?? '');
$what = $editorial ? ($id ? 'Edit Traversence piece' : 'Write as Traversence') : ($id ? 'Edit journey' : 'Write a journey');

tv_page_start($what, $editorial
    ? ['description' => 'Traversence articles and guides.', 'section' => 'admin', 'active' => 'journeys', 'crumbs' => [['Admin', '/admin/'], ['Journeys', '/admin/journeys.php'], [$what]]]
    : ['description' => 'Write a journey for Traversence.', 'crumbs' => [['Dashboard', '/user/dashboard.php'], ['Your journeys', '/user/journeys/'], [$what]]]);
echo tv_journey_css();
?>
<style>
  .jc{max-width:52rem}
  .jc h1{font-family:ui-serif,Georgia,serif;font-weight:700;font-size:clamp(1.4rem,2.4vw,1.85rem);color:#3E2B1F;margin:0 0 .4rem}
  .jc-card{background:#F7EFDC;border:1px solid #CBB98D;border-radius:1rem;padding:1rem 1.15rem;margin-top:.9rem}
  .jc-l{display:block;font-size:.8rem;font-weight:700;color:#3E2B1F;margin:.7rem 0 .25rem}.jc-l small{font-weight:400;color:#7A6348}
  .jc-in{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.6rem;padding:.5rem .65rem;background:#FFFBF2;font:inherit;font-size:.92rem;color:#3E2B1F}
  textarea.jc-in{min-height:14rem;line-height:1.55}
  .jc-2{display:grid;grid-template-columns:12rem minmax(0,1fr);gap:.6rem}.jc-3{display:grid;grid-template-columns:1fr 1fr;gap:.6rem}
  .jc-sug{position:relative}.jc-list{position:absolute;left:0;right:0;top:100%;z-index:20;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;margin-top:.2rem;box-shadow:0 12px 24px -12px rgba(0,0,0,.4);overflow:hidden}
  .jc-list[hidden]{display:none}.jc-list button{display:flex;justify-content:space-between;gap:.6rem;width:100%;text-align:left;background:none;border:0;border-top:1px solid #EADFC4;padding:.45rem .65rem;font-size:.86rem;cursor:pointer;color:#3E2B1F}
  .jc-list button:hover{background:#F7EFDC}.jc-list small{color:#7A6348}
  .jc-chips{display:flex;flex-wrap:wrap;gap:.35rem;margin-top:.4rem}.jc-chip{display:inline-flex;align-items:center;gap:.3rem;background:#3E2B1F;color:#FFFBF2;border-radius:999px;padding:.2rem .6rem;font-size:.8rem}
  .jc-chip button{background:none;border:0;color:#E8D6AE;cursor:pointer;font-size:.95rem;padding:0}
  .jc-flag{display:flex;gap:.5rem;align-items:flex-start;font-size:.88rem;margin:.3rem 0}
  .jc-guide{font-size:.8rem;color:#5C4632;background:#FFF8EA;border:1px dashed #CBB98D;border-radius:.6rem;padding:.5rem .65rem;margin-top:.4rem}
  .jc-ph{display:grid;grid-template-columns:120px minmax(0,1fr);gap:.7rem;border-top:1px solid #E3D3AC;padding:.7rem 0}.jc-ph:first-of-type{border-top:0}
  .jc-ph img{width:120px;height:80px;object-fit:cover;border-radius:.5rem}
  .jc-pin{display:flex;gap:.4rem;align-items:center;margin-top:.35rem}.jc-pin input{flex:1}
  .jc-b{display:inline-flex;align-items:center;gap:.4rem;background:#3E2B1F;color:#FFFBF2;border:0;border-radius:.7rem;padding:.55rem 1.1rem;font-weight:600;font-size:.9rem;cursor:pointer;text-decoration:none}
  .jc-b.ghost{background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D}.jc-b.sm{padding:.3rem .65rem;font-size:.8rem}
  .jc-msg{border-radius:.7rem;padding:.55rem .8rem;font-size:.9rem;margin-top:.6rem}.jc-msg.ok{background:#DCFCE7;color:#14532D}.jc-msg.err{background:#FEE2E2;color:#7F1D1D}
  .jc-voice{display:flex;flex-wrap:wrap;gap:.8rem;font-size:.9rem}
  .jc-mini{display:flex;flex-direction:column;gap:.2rem;font-size:.75rem;font-weight:700;color:#5C4632}
  .jc-new{display:grid;grid-template-columns:120px minmax(0,1fr);gap:.7rem;border-top:1px dashed #CBB98D;padding:.7rem 0}
  .jc-new img{width:120px;height:80px;object-fit:cover;border-radius:.5rem;background:#E3D3AC}
  .jc-found{background:#FFF8EA;border:1px dashed #CBB98D;border-radius:.5rem;padding:.4rem .55rem;font-size:.82rem;margin-top:.35rem}
  .jc-found label{display:flex;gap:.4rem;align-items:center;margin-top:.2rem}
  @media (max-width:640px){.jc-new{grid-template-columns:1fr}}
  #jc-map{height:280px;border:1px solid #CBB98D;border-radius:.7rem;margin-top:.5rem}
  @media (max-width:640px){.jc-2,.jc-3{grid-template-columns:1fr}.jc-ph{grid-template-columns:1fr}}
</style>
<div class="jc">
  <h1><?= tv_e($what) ?></h1>
  <?php if ($editorial): ?><p class="jc-guide" style="margin-top:0">Written as <b>Traversence</b>: our editorial voice, labelled Traversence on every card and page.<?= $canPublish ? '' : ' As a Content Creator, <b>Send to an editor</b> when it&rsquo;s ready; an editor publishes it.' ?><?= !empty($j['submitted_at']) && ($j['status'] ?? '') === 'draft' ? ' <b>Waiting for an editor</b> since ' . tv_e(date('M j', strtotime((string) $j['submitted_at']))) . '.' : '' ?></p><?php endif; ?>
  <?php if ($flash): ?><p class="jc-msg <?= str_starts_with($flash, 'Saved as a draft: an automatic') ? 'err' : 'ok' ?>"><?= tv_e($flash) ?><?= $published ? ' <a class="underline" href="/journeys/view.php?id=' . (int) $id . '">See it</a>' : '' ?></p><?php endif; ?>
  <?php if ($id && $published) { require_once __DIR__ . '/../../../app/ui/tag-chips.php'; echo tv_tag_chips($pdo, 'journey:' . (int) $id, str_starts_with((string) $flash, 'Published')); }   // what it's tied to, each with × (decisions/0132 §2a) ?>
  <?php foreach ($errors as $er): ?><p class="jc-msg err"><?= tv_e($er) ?></p><?php endforeach; ?>

  <form method="post" enctype="multipart/form-data" id="jc-form">
    <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><?php if ($id): ?><input type="hidden" name="id" value="<?= (int) $id ?>"><?php endif; ?>
    <?php if ($editorial): ?><input type="hidden" name="editorial" value="1"><?php endif; ?>

    <?php if ($asListings && (!$j || (int) $j['author_id'] === $uid)): ?>
    <div class="jc-card"><span class="jc-l" style="margin-top:0">Post as</span>
      <div class="jc-voice">
        <label><input type="radio" name="as" value=""<?= $asNow === '' ? ' checked' : '' ?>> Myself <small style="color:#7A6348">(with my name)</small></label>
        <?php foreach ($asListings as $eid => $ename): ?>
        <label><input type="radio" name="as" value="listing:<?= (int) $eid ?>"<?= $asNow === 'listing:' . $eid ? ' checked' : '' ?>> <?= tv_e($ename) ?> <small style="color:#7A6348">(shown as the business)</small></label>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="jc-card">
      <div class="jc-2">
        <div><label class="jc-l" for="jc-cat" style="margin-top:0">Category</label>
          <select id="jc-cat" name="category" class="jc-in"><?php foreach (Journeys::CATEGORIES as $c): ?><option<?= $v('category', 'Exploring') === $c ? ' selected' : '' ?>><?= tv_e($c) ?></option><?php endforeach; ?></select></div>
        <div><label class="jc-l" for="jc-title" style="margin-top:0">Title</label>
          <input id="jc-title" name="title" class="jc-in" maxlength="160" required value="<?= tv_e($v('title')) ?>" placeholder="e.g. The Arizona Trail"></div>
      </div>
      <div class="jc-3">
        <div class="jc-sug"><label class="jc-l" for="jc-place">About a place <small>(where it shows on Let&rsquo;s Explore)</small></label>
          <input id="jc-place" class="jc-in" value="<?= tv_e($v('place_label')) ?>" placeholder="A town, area, region or local name" autocomplete="off">
          <input type="hidden" name="place_key" id="jc-place-key" value="<?= tv_e($v('place_key')) ?>"><input type="hidden" name="place_label" id="jc-place-label" value="<?= tv_e($v('place_label')) ?>">
          <div class="jc-list" id="jc-place-list" hidden></div></div>
        <div><label class="jc-l" for="jc-was">Was here <small>(when you went)</small></label>
          <div style="display:flex;gap:.4rem"><input id="jc-was" type="date" name="was_here" class="jc-in" max="<?= date('Y-m-d') ?>" value="<?= tv_e($v('was_here')) ?>">
          <?php if ($details): ?><input type="time" name="was_time" class="jc-in" style="max-width:8.5rem" value="<?= tv_e($v('was_time')) ?>" aria-label="Time (optional)" title="Time (optional)"><?php endif; ?></div></div>
      </div>
      <?php if ($details): ?>
      <div class="jc-where"><label class="jc-l" for="jc-pin">Where it happened <small>(optional: your own pin; it puts your journey on the map)</small></label>
        <div class="jc-pin"><input id="jc-pin" class="jc-in" name="pin" value="<?= tv_e($v('pin')) ?>" placeholder="Pick a spot on the map" data-pin>
          <button type="button" class="jc-b ghost sm" data-pick><?= tv_icon('pin', 'tv-ei') ?> Pick</button></div>
        <p class="jc-guide" id="jc-pin-sug" hidden></p></div>
      <?php endif; ?>
      <label class="jc-l" for="jc-body">Your story</label>
      <textarea id="jc-body" name="body" class="jc-in" placeholder="What was it like? What did you see, who did you meet, where did you eat? Leave a blank line between paragraphs."><?= tv_e($v('body')) ?></textarea>
    </div>

    <div class="jc-card">
      <span class="jc-l" style="margin-top:0">Photos <small>(up to <?= Journeys::MAX_PHOTOS ?>; JPEG, PNG or WebP)</small></span>
      <p class="jc-guide">Everything hidden in a photo file (GPS coordinates, your device, the time) is removed when you upload. If you want to show where a photo was taken, tag it below.</p>
      <?php foreach ($media as $m): ?>
        <div class="jc-ph">
          <img src="<?= tv_e($m['card_path']) ?>" alt="">
          <div>
            <input class="jc-in" name="m[<?= (int) $m['id'] ?>][caption]" value="<?= tv_e($m['caption']) ?>" placeholder="Caption" maxlength="300">
            <input class="jc-in" style="margin-top:.35rem" name="m[<?= (int) $m['id'] ?>][place]" value="<?= tv_e($m['tag_place']) ?>" placeholder="Where it was taken (optional)" maxlength="160">
            <div class="jc-pin"><input class="jc-in" name="m[<?= (int) $m['id'] ?>][pin]" value="<?= $m['tag_lat'] !== null ? tv_e($m['tag_lat'] . ', ' . $m['tag_lon']) : '' ?>" placeholder="Show where it was taken: a pin (optional)" data-pin>
              <button type="button" class="jc-b ghost sm" data-pick><?= tv_icon('pin', 'tv-ei') ?> Pick</button></div>
            <?php if ($details): ?>
            <div class="jc-3" style="margin-top:.35rem"><label class="jc-mini">Taken <input class="jc-in" type="datetime-local" name="m[<?= (int) $m['id'] ?>][taken]" value="<?= !empty($m['taken_at']) ? tv_e(str_replace(' ', 'T', substr((string) $m['taken_at'], 0, 16))) : '' ?>"></label>
              <label class="jc-mini">Whose photo <select class="jc-in" name="m[<?= (int) $m['id'] ?>][source]" data-src><option value="own"<?= ($m['source'] ?? 'own') === 'own' ? ' selected' : '' ?>>Taken by me</option><option value="permission"<?= ($m['source'] ?? '') === 'permission' ? ' selected' : '' ?>>Used with permission</option></select></label></div>
            <input class="jc-in" style="margin-top:.35rem" name="m[<?= (int) $m['id'] ?>][credit]" value="<?= tv_e((string) ($m['credit'] ?? '')) ?>" placeholder="Photo by… (shown as the credit)" maxlength="160" data-credit<?= ($m['source'] ?? 'own') === 'permission' ? '' : ' hidden' ?>>
            <?php endif; ?>
            <label class="jc-flag"><input type="checkbox" name="m[<?= (int) $m['id'] ?>][remove]" value="1"> Remove this photo</label>
          </div>
        </div>
      <?php endforeach; ?>
      <div id="jc-map" hidden></div>
      <label class="jc-l" for="jc-photos">Add photos</label>
      <input id="jc-photos" type="file" name="photos[]" accept="image/jpeg,image/png,image/webp" multiple>
      <div id="jc-new"></div>
      <label class="jc-l" for="jc-video">A video <small>(a YouTube or Vimeo link)</small></label>
      <input id="jc-video" name="video_url" class="jc-in" value="<?= tv_e($v('video_url')) ?>" placeholder="https://www.youtube.com/watch?v=…">
    </div>

    <div class="jc-card">
      <div class="jc-sug"><label class="jc-l" for="jc-lst" style="margin-top:0">Places and businesses you mention <small>(links your journey to their listings)</small></label>
        <input id="jc-lst" class="jc-in" placeholder="Type a business or listing name" autocomplete="off"><div class="jc-list" id="jc-lst-list" hidden></div></div>
      <div class="jc-chips" id="jc-chips"><?php foreach ($listingIds as $lid): if (!isset($listingNames[$lid])) continue; ?><span class="jc-chip"><?= tv_e($listingNames[$lid]) ?><input type="hidden" name="listings[]" value="<?= (int) $lid ?>"><button type="button" aria-label="Remove">&times;</button></span><?php endforeach; ?></div>
    </div>

    <div class="jc-card">
      <span class="jc-l" style="margin-top:0">About this journey <small>(your own flags; they help readers and our team)</small></span>
      <?php foreach (Journeys::FLAGS as $k => $label): ?>
        <label class="jc-flag"><input type="checkbox" name="flags[]" value="<?= tv_e($k) ?>"<?= in_array($k, $flags, true) ? ' checked' : '' ?>> <?= tv_e($label) ?></label>
      <?php endforeach; ?>
      <p class="jc-guide" id="jc-tribal"<?= in_array('tribal_land', $flags, true) ? '' : ' hidden' ?>>Tribal nations are sovereign nations. Many restrict photography and filming, and some villages don&rsquo;t allow it at all. Follow the nation&rsquo;s rules for visitors, and don&rsquo;t point others to sacred or restricted places.</p>
      <label class="jc-flag" style="margin-top:.7rem"><input type="checkbox" name="partnership" value="1"<?= !empty($j['partnership']) ? ' checked' : '' ?>> <span><b>Partnership:</b> I was paid, or given something free, for this journey (U.S. law requires saying so)</span></label>
      <p class="jc-guide">Guidance, not legal advice: <a class="underline" href="/user/journeys/#guidelines" target="_blank">the contributor guidelines</a>. Journeys publish when you post them; readers can report them.</p>
    </div>

    <?php if ($details): ?>
    <div class="jc-card">
      <span class="jc-l" style="margin-top:0">Rights and reuse</span>
      <?php foreach (Journeys::REUSE as $k => $label): ?>
        <label class="jc-flag"><input type="radio" name="reuse" value="<?= tv_e($k) ?>"<?= $v('reuse', 'traversence') === $k ? ' checked' : '' ?>> <?= tv_e($label) ?></label>
      <?php endforeach; ?>
      <p class="jc-guide">You keep ownership either way. Photos you didn&rsquo;t take are credited to whoever took them (set under each photo).</p>
      <?php if ($isAuthor && !$editorial): ?>
      <div class="jc-sug"><label class="jc-l" for="jc-co">Co-authors <small>(up to <?= Journeys::MAX_COAUTHORS ?>; they&rsquo;re invited, and shown once they accept)</small></label>
        <input id="jc-co" class="jc-in" placeholder="Search members by name" autocomplete="off"><div class="jc-list" id="jc-co-list" hidden></div></div>
      <input type="hidden" name="coauthors_set" value="1">
      <div class="jc-chips" id="jc-cos"><?php foreach ($coauthors as $c): ?><span class="jc-chip"><?= tv_e($c['name']) ?> <small style="color:#E8D6AE"><?= $c['status'] === 'accepted' ? '✓ accepted' : 'invited' ?></small><input type="hidden" name="coauthors[]" value="<?= (int) $c['id'] ?>"><button type="button" aria-label="Remove">&times;</button></span><?php endforeach; ?></div>
      <?php endif; ?>
    </div>

    <div class="jc-card">
      <span class="jc-l" style="margin-top:0">For readers</span>
      <label class="jc-flag"><input type="checkbox" name="mature" value="1"<?= $v('mature') ? ' checked' : '' ?>> <span><b>Mature themes:</b> readers see a notice and choose to open it; it&rsquo;s kept out of the big picture at the top of pages</span></label>
      <label class="jc-l" for="jc-caution">A caution <small>(optional: terrain, weather, closures, anything readers should know first)</small></label>
      <textarea id="jc-caution" name="caution" class="jc-in" style="min-height:3.5rem" maxlength="300" placeholder="e.g. The road past the ranch gate is impassable after rain."><?= tv_e($v('caution')) ?></textarea>
    </div>
    <?php endif; ?>

    <p style="margin-top:1rem;display:flex;flex-wrap:wrap;gap:.6rem">
      <button class="jc-b" type="submit" name="do" value="publish"><?= $published ? 'Update' : ($canPublish ? 'Publish' : 'Send to an editor') ?></button>
      <?php if (!$published): ?><button class="jc-b ghost" type="submit" name="do" value="draft">Save draft</button><?php endif; ?>
      <?php if ($id): ?><a class="jc-b ghost" href="/journeys/view.php?id=<?= (int) $id ?>"><?= $published ? 'View' : 'Preview' ?></a><?php endif; ?>
      <a class="jc-b ghost" href="<?= tv_e($back) ?>"><?= $editorial ? 'Back to Journeys' : 'Back to your journeys' ?></a>
    </p>
    <p class="jc-guide"><a class="underline" href="/faq.php#how-does-my-journey-get-onto-the-front-page" target="_blank">Where will my journey show?</a></p>
  </form>
</div>
<script>
  var JC_PIN = <?= json_encode(tv_icon('pin', 'tv-ei')) ?>;   // the brand's pin (site audit P4)
(function () {
  'use strict';
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  // a type-ahead: fetch(q) -> [{label, sub, ...}], pick(o)
  function ahead(inp, list, url, map, pick) {
    var t = null, opts = [];
    inp.addEventListener('input', function () {
      clearTimeout(t); var q = inp.value.trim();
      if (q.length < 2) { list.hidden = true; return; }
      t = setTimeout(function () {
        fetch(url + encodeURIComponent(q), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
          opts = map(d);
          list.innerHTML = opts.length ? opts.map(function (o, i) { return '<button type="button" data-i="' + i + '"><span>' + esc(o.label) + '</span><small>' + esc(o.sub || '') + '</small></button>'; }).join('') : '<button type="button" disabled><span>Nothing by that name</span></button>';
          list.hidden = false;
        });
      }, 220);
    });
    list.addEventListener('click', function (e) { var b = e.target.closest('[data-i]'); if (b) { list.hidden = true; pick(opts[+b.getAttribute('data-i')]); } });
    document.addEventListener('click', function (e) { if (!list.contains(e.target) && e.target !== inp) list.hidden = true; });
  }
  var pin = document.getElementById('jc-place');
  ahead(pin, document.getElementById('jc-place-list'), '/api/journeys.php?places=', function (d) { return d.places || []; }, function (o) {
    pin.value = o.label; document.getElementById('jc-place-key').value = o.key; document.getElementById('jc-place-label').value = o.label;
  });
  pin.addEventListener('change', function () { if (!pin.value.trim()) { document.getElementById('jc-place-key').value = ''; document.getElementById('jc-place-label').value = ''; } });
  var chips = document.getElementById('jc-chips'), lst = document.getElementById('jc-lst');
  ahead(lst, document.getElementById('jc-lst-list'), '/api/journeys.php?listings=', function (d) { return (d.listings || []).map(function (l) { return { label: l.name, sub: l.city, id: l.id }; }); }, function (o) {
    if (chips.querySelector('input[value="' + o.id + '"]')) return;
    chips.insertAdjacentHTML('beforeend', '<span class="jc-chip">' + esc(o.label) + '<input type="hidden" name="listings[]" value="' + (+o.id) + '"><button type="button" aria-label="Remove">&times;</button></span>');
    lst.value = '';
  });
  chips.addEventListener('click', function (e) { if (e.target.closest('button')) e.target.closest('.jc-chip').remove(); });
  // co-authors: members found by name, invited when the journey is saved
  var cos = document.getElementById('jc-cos'), co = document.getElementById('jc-co');
  if (co) {
    ahead(co, document.getElementById('jc-co-list'), '/api/journeys.php?people=', function (d) { return (d.people || []).map(function (p) { return { label: p.name, sub: p.contributor ? 'Contributor' : 'Member', id: p.id }; }); }, function (o) {
      if (cos.querySelector('input[value="' + o.id + '"]')) return;
      if (cos.querySelectorAll('.jc-chip').length >= <?= Journeys::MAX_COAUTHORS ?>) { TvAsk.say('Up to <?= Journeys::MAX_COAUTHORS ?> co-authors.', { anchor: cos }); return; }
      cos.insertAdjacentHTML('beforeend', '<span class="jc-chip">' + esc(o.label) + ' <small style="color:#E8D6AE">invited when you save</small><input type="hidden" name="coauthors[]" value="' + (+o.id) + '"><button type="button" aria-label="Remove">&times;</button></span>');
      co.value = '';
    });
    cos.addEventListener('click', function (e) { if (e.target.closest('button')) e.target.closest('.jc-chip').remove(); });
  }
  // whose photo: a credit line when it's used with someone's permission
  document.addEventListener('change', function (e) {
    var sel = e.target.closest('[data-src]'); if (!sel) return;
    var cr = sel.closest('.jc-ph, .jc-new').querySelector('[data-credit]'); if (cr) { cr.hidden = sel.value !== 'permission'; if (!cr.hidden) cr.focus(); }
  });
  // New photos: what the photo itself says (when and where it was taken), read here in the browser before upload, and
  // offered to the author. Nothing is used unless they tick it; the stored photo has all of it removed either way.
  function exifOf(file) {
    if (!/jpe?g$/i.test(file.type.split('/')[1] || '')) return Promise.resolve({});
    return file.slice(0, 262144).arrayBuffer().then(function (b) { try { return parseExif(new DataView(b)); } catch (x) { return {}; } });
  }
  function parseExif(v) {
    if (v.getUint16(0) !== 0xFFD8) return {};
    var o = 2;
    while (o + 10 < v.byteLength) {
      var mk = v.getUint16(o);
      if (mk === 0xFFE1 && v.getUint32(o + 4) === 0x45786966) return tiff(v, o + 10);
      if ((mk & 0xFF00) !== 0xFF00) break;
      o += 2 + v.getUint16(o + 2);
    }
    return {};
  }
  function tiff(v, t) {
    var le = v.getUint16(t) === 0x4949, u16 = function (p) { return v.getUint16(p, le); }, u32 = function (p) { return v.getUint32(p, le); };
    function ifd(off) { var n = u16(t + off), r = {}; for (var i = 0; i < n; i++) { var e = t + off + 2 + i * 12; r[u16(e)] = { count: u32(e + 4), at: e + 8 }; } return r; }
    function str(x) { var p = x.count > 4 ? t + u32(x.at) : x.at, s = ''; for (var i = 0; i < x.count - 1; i++) s += String.fromCharCode(v.getUint8(p + i)); return s; }
    function deg(x) { var p = t + u32(x.at), a = []; for (var i = 0; i < 3; i++) a.push(u32(p + i * 8) / (u32(p + i * 8 + 4) || 1)); return a[0] + a[1] / 60 + a[2] / 3600; }
    var out = {}, i0 = ifd(u32(t + 4));
    if (i0[0x8769]) { var ex = ifd(u32(i0[0x8769].at)); if (ex[0x9003]) out.taken = str(ex[0x9003]); }
    if (!out.taken && i0[0x0132]) out.taken = str(i0[0x0132]);
    if (i0[0x8825]) {
      var g = ifd(u32(i0[0x8825].at));
      if (g[2] && g[4]) { var la = deg(g[2]), lo = deg(g[4]); if (g[1] && str(g[1]) === 'S') la = -la; if (g[3] && str(g[3]) === 'W') lo = -lo; if (isFinite(la) && isFinite(lo) && (la || lo)) { out.lat = la; out.lon = lo; } }
    }
    var m = /^(\d{4}):(\d{2}):(\d{2}) (\d{2}):(\d{2})/.exec(out.taken || ''); out.taken = m ? m[1] + '-' + m[2] + '-' + m[3] + 'T' + m[4] + ':' + m[5] : '';
    return out;
  }
  var nw = document.getElementById('jc-new'), files = document.getElementById('jc-photos'), wherePin = document.getElementById('jc-pin'), whereSug = document.getElementById('jc-pin-sug');
  if (nw && files && <?= $details ? 'true' : 'false' ?>) files.addEventListener('change', function () {
    nw.innerHTML = ''; if (whereSug) whereSug.hidden = true;
    [].forEach.call(files.files, function (f, i) {
      var row = document.createElement('div'); row.className = 'jc-new';
      row.innerHTML = '<img alt="" src="' + URL.createObjectURL(f) + '"><div><b style="font-size:.85rem">' + esc(f.name) + '</b>'
        + '<div class="jc-3" style="margin-top:.35rem"><label class="jc-mini">Taken <input class="jc-in" type="datetime-local" name="pm[' + i + '][taken]" data-taken></label>'
        + '<label class="jc-mini">Whose photo <select class="jc-in" name="pm[' + i + '][source]" data-src><option value="own">Taken by me</option><option value="permission">Used with permission</option></select></label></div>'
        + '<input class="jc-in" style="margin-top:.35rem" name="pm[' + i + '][credit]" placeholder="Photo by… (shown as the credit)" maxlength="160" data-credit hidden>'
        + '<div class="jc-pin"><input class="jc-in" name="pm[' + i + '][pin]" placeholder="Show where it was taken: a pin (optional)" data-pin><button type="button" class="jc-b ghost sm" data-pick>' + JC_PIN + ' Pick</button></div>'
        + '<div class="jc-found" hidden></div></div>';
      nw.appendChild(row);
      exifOf(f).then(function (x) {
        if (!x.taken && x.lat == null) return;
        var box = row.querySelector('.jc-found'), when = x.taken ? new Date(x.taken).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '';
        box.innerHTML = 'This photo says it was taken' + (when ? ' <b>' + esc(when) + '</b>' : '') + (x.lat != null ? ' near <b>' + x.lat.toFixed(4) + ', ' + x.lon.toFixed(4) + '</b>' : '') + '. Use it?'
          + (x.taken ? '<label><input type="checkbox" data-use-date> Use the date</label>' : '')
          + (x.lat != null ? '<label><input type="checkbox" data-use-pin> Show where it was taken (your pin)</label>' : '')
          + '<small style="color:#7A6348">Only what you tick is kept. The photo itself is stored with all of this removed.</small>';
        box.hidden = false;
        box.addEventListener('change', function (e) {
          if (e.target.matches('[data-use-date]')) row.querySelector('[data-taken]').value = e.target.checked ? x.taken : '';
          if (e.target.matches('[data-use-pin]')) row.querySelector('[name$="[pin]"]').value = e.target.checked ? x.lat.toFixed(5) + ', ' + x.lon.toFixed(5) : '';
        });
        if (x.lat != null && wherePin && !wherePin.value && whereSug && whereSug.hidden) {   // the journey's own "where", from its first photo that knows
          whereSug.innerHTML = '“' + esc(f.name) + '” was taken near ' + x.lat.toFixed(4) + ', ' + x.lon.toFixed(4) + '. <button type="button" class="underline" data-use-where>Use it for “Where it happened”</button>';
          whereSug.hidden = false;
          whereSug.querySelector('[data-use-where]').onclick = function () { wherePin.value = x.lat.toFixed(5) + ', ' + x.lon.toFixed(5); whereSug.hidden = true; };
        }
      });
    });
  });
  var tri = document.querySelector('input[name="flags[]"][value="tribal_land"]');
  if (tri) tri.addEventListener('change', function () { document.getElementById('jc-tribal').hidden = !tri.checked; });
  // "Pick": the contributor sets a photo's pin on a map, if they want to show where it was taken
  var mapEl = document.getElementById('jc-map'), map = null, mk = null, target = null;
  function leaflet(cb) {
    if (window.L) return cb();
    var cdn = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/', c = document.createElement('link'); c.rel = 'stylesheet'; c.href = cdn + 'leaflet.min.css'; document.head.appendChild(c);
    var s = document.createElement('script'); s.src = cdn + 'leaflet.min.js'; s.onload = cb; document.head.appendChild(s);
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pick]'); if (!b) return;
    target = b.parentNode.querySelector('[data-pin]');
    b.closest('.jc-ph, .jc-where, .jc-new').appendChild(mapEl); mapEl.hidden = false;
    leaflet(function () {
      var cur = target.value.split(',').map(Number), has = cur.length === 2 && !isNaN(cur[0]) && !isNaN(cur[1]) && target.value.trim();
      if (!map) {
        map = L.map(mapEl).setView(has ? cur : [34.2, -110.0], has ? 14 : 7);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors', referrerPolicy: 'strict-origin-when-cross-origin' }).addTo(map);
        map.on('click', function (ev) { if (mk) mk.setLatLng(ev.latlng); else mk = L.marker(ev.latlng).addTo(map); target.value = ev.latlng.lat.toFixed(5) + ', ' + ev.latlng.lng.toFixed(5); });
      } else { map.setView(has ? cur : map.getCenter(), has ? 14 : map.getZoom()); if (mk && !has) { map.removeLayer(mk); mk = null; } }
      if (has) { if (mk) mk.setLatLng(cur); else mk = L.marker(cur).addTo(map); }
      setTimeout(function () { map.invalidateSize(); }, 50);
    });
  });
})();
</script>
<script>
// New photos go through the site's one uploader (js/tv-upload.js, decisions/0127): the journey is saved first (a new one
// gets its number), then each photo is sent to it with what the author confirmed about it (date, pin, whose it is).
(function () {
  var f = document.getElementById('jc-form'), inp = document.getElementById('jc-photos'); if (!f || !inp || !window.TvUpload) return;
  inp.removeAttribute('name');
  f.addEventListener('submit', function (ev) {
    var files = Array.prototype.slice.call(inp.files || []); if (!files.length) return;
    ev.preventDefault();
    var fd = new FormData(f), by = ev.submitter;
    if (by && by.name) fd.set(by.name, by.value);
    var pm = function (i, k) { var e = f.querySelector('[name="pm[' + i + '][' + k + ']"]'); return e ? e.value : ''; };
    f.querySelectorAll('button[type=submit]').forEach(function (b) { b.disabled = true; });
    fetch(location.pathname + location.search, { method: 'POST', credentials: 'include', body: fd }).then(function (r) {
      var id = +((/[?&]id=(\d+)/.exec(r.url) || [])[1] || 0);
      if (!id) return r.text().then(function (html) {   // it said why (a title missing…): show that, and keep the photos picked
        var d = new DOMParser().parseFromString(html, 'text/html'), why = [].map.call(d.querySelectorAll('.jc-msg.err'), function (e) { return e.textContent.trim(); }).join(' ');
        throw new Error(why || 'The journey didn\'t save. Check it and try again.');
      });
      return TvUpload.send(files, { target: 'journey_photo', el: inp, shrink: 2400,
        ctx: function (file) { var i = files.indexOf(file); return { journey: id, taken: pm(i, 'taken'), pin: pm(i, 'pin'), source: pm(i, 'source') || 'own', credit: pm(i, 'credit') }; } })
        .then(function () { location.href = '/user/journeys/compose.php?id=' + id; }, function () { location.href = '/user/journeys/compose.php?id=' + id; });
    }).catch(function (x) { f.querySelectorAll('button[type=submit]').forEach(function (b) { b.disabled = false; }); if (window.TvAsk) TvAsk.say(x.message, { anchor: inp }); });
  });
})();
</script>
<script src="/js/tv-ai-assist.js?v=<?= (int) @filemtime(__DIR__ . '/../../js/tv-ai-assist.js') ?>"></script>
<script>if (window.TvAi) TvAi.attach(document.getElementById('jc-body'), { source: 'journey', place: function () { var k = document.getElementById('jc-place-key'); return k ? k.value : ''; } });   // AI Assist where members write (source-tagged)</script>
<?php tv_page_end();
