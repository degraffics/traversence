// js/map-view.js — the full-screen map (decisions/0053 §4b, redesigned in decisions/0058 §5).
//
// TvMap.open({ load, title, radius, tools, onTool, onList, onCategory, onRadius, titleFor })
//   load(area, q) -> Promise of { pins: [{id, lat, lon, name, category, city, state}], center?: {lat, lon, radius}, total, truncated }
//                    area is null (the search as it stands) or {lat, lon, radius} after "Search this area" / a distance;
//                    q is what was typed in the header search while the map is open ('' for none).
//   title         -> what the map shows ("Things to do · Ancient Borderlands")
//   radius        -> current miles, or null when the place is a region
//   tools         -> extra HTML for the panel's "Show" row (buttons with data-act are passed to onTool)
//   onCategory    -> (slug, name): the chosen place's category was tapped; narrow the search to it
//   titleFor      -> (response) -> a new title after each load
//   select        -> a pin id to choose when the map first loads ("See on map" from a place page)
//   panel         -> start with the side panel open (a map opened as its own view)
//
// Nothing floats over the map but Exit and the map's own controls. The header search above the map says what to look
// for: while the map is open, pressing Enter there searches the map. Everything else lives in a panel that opens from
// the map's left edge: what's shown, the distance, "search as I move", the map style, the legend, and the chosen place
// (Call, Directions, Website, Open, Link, Save, previous / next nearest first; swipe on phones). On phones the panel is
// a sheet from the bottom. Controls (right): zoom, my location, search this area, map style.
// Favorites (businesses you linked or saved to your Address Book) show as a heart in a circle.
// "My location" only moves the map, on this device; it's never saved or sent anywhere.
// Leaflet and its clustering plugin load on first use, from cdnjs.
(function () {
  'use strict';
  var css = '.tvm{position:fixed;left:0;right:0;bottom:0;z-index:1350;background:#E8DCC0}'
    + 'html.tvm-open #top-bar,html.tvm-open .tv-as{z-index:1360}'
    + '.tvm-map{position:absolute;inset:0}'
    // Exit: the one thing over the map, top right
    + '.tvm-exit{position:absolute;top:.6rem;right:.6rem;z-index:700;display:flex;align-items:center;gap:.35rem;border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:999px;padding:.4rem .85rem;font-size:.85rem;font-weight:700;cursor:pointer;box-shadow:0 6px 16px -8px rgba(0,0,0,.5)}'
    + '.tvm-exit:hover{background:#3E2B1F;color:#FFFBF2}'
    // controls, bottom right
    + '.tvm-ctl{position:absolute;right:.6rem;bottom:1.6rem;z-index:700;display:flex;flex-direction:column;gap:.4rem}'
    + '.tvm-ctl .grp{display:flex;flex-direction:column;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.7rem;overflow:hidden;box-shadow:0 6px 16px -8px rgba(0,0,0,.5)}'
    + '.tvm-ctl button{width:40px;height:40px;border:0;background:none;color:#3E2B1F;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1.25rem;line-height:1}'
    + '.tvm-ctl .grp button+button{border-top:1px solid #E3D3AC}.tvm-ctl button:hover{background:#F3E6C8}'
    + '.tvm-ctl button[aria-pressed="true"]{background:#3E2B1F;color:#FFFBF2}.tvm-ctl button.due{color:#B45309;background:#FEF3C7}'
    + '.tvm-ctl svg{width:20px;height:20px}'
    // the left-edge panel and its handle
    + '.tvm-side{position:absolute;top:0;left:0;bottom:0;z-index:650;width:min(22rem,86vw);background:#FFFBF2;border-right:1px solid #CBB98D;box-shadow:8px 0 24px -16px rgba(0,0,0,.5);display:flex;flex-direction:column;color:#3E2B1F;font-size:.88rem}'
    + '.tvm-side[hidden]{display:none}'
    + '.tvm-tab{position:absolute;top:50%;z-index:660;transform:translateY(-50%);left:0;width:26px;height:64px;border:1px solid #CBB98D;border-left:0;border-radius:0 .7rem .7rem 0;background:#FFFBF2;color:#3E2B1F;cursor:pointer;box-shadow:4px 0 12px -6px rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;font-size:1.1rem}'
    + '.tvm.side-open .tvm-tab{left:min(22rem,86vw)}'
    + '.tvm-sh{position:relative;padding:.8rem .95rem .6rem;border-bottom:1px solid #EADFC4}'
    + '.tvm-how{font-size:.8rem;color:#5C4632;margin:.2rem 0 .1rem}.tvm-how b{color:#3E2B1F}.tvm-how .tvm-lk{background:none;border:0;padding:0;color:#92400E;text-decoration:underline;cursor:pointer;font:inherit;margin-left:.35rem}'
    + '.tvm-how .tv-pbox{display:flex;width:100%;box-sizing:border-box;margin:.35rem 0 .3rem}.tvm-how .tv-pbox-in{width:auto}.tvm-howt{margin:0}.tvm-how label{display:flex;gap:.35rem;align-items:center;font-size:.76rem;margin-top:.25rem}'
    + '.tvm-title{font-family:ui-serif,Georgia,serif;font-weight:700;font-size:1.05rem;line-height:1.25}'
    + '.tvm-note{font-size:.75rem;color:#7A6348;margin-top:.2rem}'
    // 2026-11-10 (Jason: "Why nothing and no search here options"): "Search this area" in words when the map has moved;
    // a way on when nothing's here; OpenStreetMap's places as lighter pins, never ours
    + '.tvm-here{position:absolute;top:.6rem;left:50%;transform:translateX(-50%);z-index:700;border:0;background:#B45309;color:#FFFBF2;border-radius:999px;padding:.45rem .95rem;font-size:.85rem;font-weight:700;cursor:pointer;box-shadow:0 6px 16px -8px rgba(0,0,0,.6)}.tvm-here[hidden]{display:none}'
    + '.tvm-empty{display:flex;flex-wrap:wrap;gap:.35rem;margin-top:.5rem}.tvm-empty:empty{display:none}.tvm-empty p{flex-basis:100%;margin:.2rem 0 0;font-size:.72rem;color:#7A6348}'
    + '.tvm-lead span{display:block;width:12px;height:12px;border-radius:999px;background:#FFFBF2;border:3px solid #92400E;box-shadow:0 1px 4px rgba(0,0,0,.4)}'
    + '.tvm-sb{flex:1;overflow:auto;padding:.2rem .95rem 1rem}'
    + '.tvm-list .tvm-li{display:flex;justify-content:space-between;gap:.6rem;width:100%;text-align:left;background:none;border:0;border-top:1px solid #F1E8D3;padding:.45rem 0;cursor:pointer;font:inherit;color:#3E2B1F;text-decoration:none}'
    + '.tvm-list .tvm-li b{color:#92400E;text-decoration:underline;text-underline-offset:3px}.tvm-list .tvm-li small{display:block;color:#8A7355;font-size:.78rem}.tvm-list .tvm-mi{white-space:nowrap;font-size:.82rem;color:#5C4632;font-weight:700}'
    + '.tvm-sec{border-top:1px solid #EADFC4;padding:.7rem 0}.tvm-sb>.tvm-sec:first-child,.tvm-chosen+.tvm-sec{border-top:0}.tvm-chosen .tvm-sec{border-bottom:1px solid #EADFC4}'
    + '.tvm-sec>b{display:block;font-size:.66rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#8A7355;margin-bottom:.45rem}'
    + '.tvm-row{display:flex;flex-wrap:wrap;gap:.35rem}'
    + '.tvm-b{border:1px solid #CBB98D;background:#FFFBF2;color:#3E2B1F;border-radius:.6rem;padding:.3rem .65rem;font-size:.82rem;font-weight:600;cursor:pointer;white-space:nowrap}'
    + '.tvm-b.go{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.tvm-sel{border:1px solid #CBB98D;background:#FFFBF2;border-radius:.6rem;padding:.3rem .45rem;font-size:.84rem;color:#3E2B1F}'
    + '.tvm-chk{display:flex;align-items:center;gap:.45rem;margin-top:.5rem;font-size:.85rem;cursor:pointer}'
    + '.tvm-lyr{display:grid;grid-template-columns:1fr 1fr;gap:.4rem}.tvm-lyr label{display:flex;align-items:center;gap:.4rem;border:1px solid #CBB98D;border-radius:.6rem;padding:.35rem .5rem;cursor:pointer;font-size:.84rem}'
    + '.tvm-lyr label.on{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}.tvm-lyr input{accent-color:#B8863B}'
    + '.tvm-leg{display:grid;gap:.35rem;font-size:.82rem}.tvm-leg span{display:flex;align-items:center;gap:.5rem}'
    + '.tvm-card{position:relative}.tvm-card h3{font-family:ui-serif,Georgia,serif;font-weight:700;font-size:1.15rem;margin:.05rem 0 .2rem;padding-right:5.5rem}'
    + '.tvm-catb{border:0;background:none;padding:0;font:inherit;color:#B45309;cursor:pointer;text-decoration:underline;text-underline-offset:2px}.tvm-catb:hover{color:#3E2B1F}'
    + '.tvm-pic{margin:.45rem 0 .35rem}.tvm-pic img{display:block;width:100%;max-height:170px;object-fit:cover;border-radius:.5rem}.tvm-pic figcaption{font-size:.68rem;color:#8A7355;margin-top:.15rem}'
    + '.tvm-about{font-size:.86rem;line-height:1.4;color:#3E2B1F;margin:.35rem 0}'
    + '.tvm-guide{margin:.45rem 0;padding:.45rem .6rem;border-left:3px solid #8FBCA8;background:#F4F8F5;font-size:.84rem;line-height:1.4;color:#3E2B1F}.tvm-guide a{display:block;margin-top:.2rem;font-size:.76rem;font-weight:700;color:#92400E}'
    + '.tvm-tipbar{font-size:.8rem;margin:.35rem 0 .1rem}.tvm-tipbar a,.tvm-linkb{color:#92400E;font-weight:600;text-decoration:underline;background:none;border:0;padding:0;font:inherit;cursor:pointer}'
    + '.tvm-acts2{display:flex;flex-wrap:wrap;gap:.3rem;margin:.4rem 0 .1rem}.tvm-act{font-size:.75rem;font-weight:700;border-radius:999px;padding:.15rem .55rem;background:#E5EFE9;color:#1F5137}'
    + '.tvm-card .m{color:#8A7355;font-size:.78rem}.tvm-fix{margin:.45rem 0 0}.tvm-fix a{color:#92400E}.tvm-acts{display:flex;flex-wrap:wrap;gap:.35rem;margin-top:.5rem}'
    + '.tvm-acts a{font-size:.8rem;font-weight:600;border:1px solid #CBB98D;border-radius:.55rem;padding:.3rem .65rem;color:#3E2B1F;text-decoration:none;background:#FFFBF2}.tvm-acts a.go{background:#3E2B1F;color:#FFFBF2;border-color:#3E2B1F}'
    + '.tvm-nav{position:absolute;top:.6rem;right:0;display:flex;gap:.25rem}.tvm-nav button{width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;cursor:pointer;color:#3E2B1F}'
    + '.tvm-keep{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:.5rem;margin-top:.6rem;padding:.5rem 3rem .1rem 0;border-top:1px solid #EADFC4}'
    // pins: a dot; a favorite is a heart in a circle; the chosen one is green (a chosen favorite fills in)
    + '.tvm-pin span{display:block;width:14px;height:14px;border-radius:999px;background:#B45309;border:2px solid #FFFBF2;box-shadow:0 1px 4px rgba(0,0,0,.45)}.tvm-pin.on span{background:#15803D;width:18px;height:18px;margin:-2px}'
    + '.tvm-stack span{display:flex;flex-direction:column;align-items:center;justify-content:center;width:46px;height:46px;border-radius:999px;background:#FFFBF2;border:2px dashed #92400E;color:#92400E;box-shadow:0 1px 5px rgba(0,0,0,.45);line-height:1}.tvm-stack b{font-size:13px}.tvm-stack small{font-size:9px}'
    + '.tvm-stackl ul{list-style:none;margin:.4rem 0 0;padding:0;max-height:50vh;overflow:auto}.tvm-stackl li button{display:block;width:100%;text-align:left;padding:.45rem .5rem;border:0;border-top:1px solid #E7D7BC;background:none;cursor:pointer}.tvm-stackl li button b{display:block;color:#92400E;text-decoration:underline;font-size:.9rem}.tvm-stackl li button small{color:#8A7355;font-size:.75rem}'
    + '.tvm-fav span{display:flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:999px;background:#FFFBF2;border:2px solid #BE123C;color:#BE123C;font-size:13px;line-height:1;box-shadow:0 1px 5px rgba(0,0,0,.45)}.tvm-fav.on span{background:#BE123C;color:#FFFBF2}'
    + '.tvm-me span{display:block;width:16px;height:16px;border-radius:999px;background:#2563EB;border:3px solid #FFFBF2;box-shadow:0 0 0 6px rgba(37,99,235,.2)}'
    + '.tvm .leaflet-top.leaflet-left{top:.2rem;left:.2rem}.tvm.side-open .leaflet-top.leaflet-left{left:min(22rem,86vw)}@media (max-width:767px){.tvm.side-open .leaflet-top.leaflet-left{left:.2rem}}'
    + '.tvm-faded{filter:grayscale(.85) brightness(1.08) contrast(.9)}'
    + '.tvm-shx{display:none;position:absolute;top:.55rem;right:.6rem;width:30px;height:30px;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;cursor:pointer;color:#3E2B1F}'
    + '@media (max-width:767px){.tvm-side{top:auto;right:0;width:auto;max-height:58%;border-right:0;border-top:1px solid #CBB98D;border-radius:1rem 1rem 0 0;box-shadow:0 -10px 24px -14px rgba(0,0,0,.5)}'
    + '.tvm-tab{top:auto;bottom:0;left:50%;transform:translateX(-50%);width:84px;height:28px;border:1px solid #CBB98D;border-bottom:0;border-radius:.7rem .7rem 0 0}.tvm.side-open .tvm-tab{display:none}'
    + '.tvm-ctl{bottom:2.6rem}.tvm.side-open .tvm-ctl{display:none}.tvm-sh{padding-right:2.8rem}.tvm-shx{display:flex;align-items:center;justify-content:center;padding:0}'
    + '.tvm-shx svg{transition:transform .2s}.tvm.side-min .tvm-shx svg{transform:rotate(180deg)}.tvm.side-min .tvm-side>:not(.tvm-sh){display:none}.tvm.side-min .tvm-sh{border-bottom:0;cursor:pointer}'
    + '.tvm.side-min .tvm-ctl{display:flex;bottom:5.2rem}}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  // Map styles. Streets: OpenStreetMap. Terrain and Satellite: the U.S. Geological Survey's National Map (public
  // domain; United States coverage; Satellite has towns and roads labelled). Light: OpenStreetMap, faded, so the pins stand out.
  var OSM = '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors';   // the tile usage policy: credited, a real Referer (referrerPolicy), no bulk download
  var LAYERS = {
    streets: ['Streets', 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: OSM, referrerPolicy: 'strict-origin-when-cross-origin' }],
    terrain: ['Terrain', 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}', { maxZoom: 16, attribution: 'USGS The National Map' }],
    // imagery with towns, roads and boundaries labelled on it
    satellite: ['Satellite', 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/{z}/{y}/{x}', { maxZoom: 16, attribution: 'USGS The National Map: imagery and topography' }],
    light: ['Light', 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, className: 'tvm-faded', attribution: OSM, referrerPolicy: 'strict-origin-when-cross-origin' }],
  };
  var I = {
    locate: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>',   // the location arrow (2026-11-10: "an icon button to take me to my current location")
    area: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>',
    layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  };

  var leaflet = null, cur = null, favs = null;
  function asset(tag, attrs) {
    return new Promise(function (res, rej) { var el = document.createElement(tag); Object.assign(el, attrs); el.onload = res; el.onerror = function () { rej(new Error('Could not load the map')); }; document.head.appendChild(el); });
  }
  function loadLeaflet() {
    if (window.L && window.L.markerClusterGroup) return Promise.resolve();
    if (leaflet) return leaflet;
    var cdn = 'https://cdnjs.cloudflare.com/ajax/libs/';
    leaflet = Promise.all([
      asset('link', { rel: 'stylesheet', href: cdn + 'leaflet/1.9.4/leaflet.min.css' }),
      asset('link', { rel: 'stylesheet', href: cdn + 'leaflet.markercluster/1.5.3/MarkerCluster.css' }),
      asset('link', { rel: 'stylesheet', href: cdn + 'leaflet.markercluster/1.5.3/MarkerCluster.Default.css' }),
    ]).then(function () { return window.L ? null : asset('script', { src: cdn + 'leaflet/1.9.4/leaflet.min.js' }); })
      .then(function () { return window.L.markerClusterGroup ? null : asset('script', { src: cdn + 'leaflet.markercluster/1.5.3/leaflet.markercluster.js' }); })
      .catch(function (e) { leaflet = null; throw e; });
    return leaflet;
  }
  // Favorites: the businesses this person linked or saved to their Address Book (the same as the directory's ★)
  function loadFavs() {
    if (favs) return favs;
    var j = function (u) { return fetch(u, { credentials: 'include' }).then(function (r) { return r.ok ? r.json() : {}; }).catch(function () { return {}; }); };
    favs = Promise.all([j('/user/api/links.php?list=1'), j('/user/api/people.php?view=contacts')]).then(function (a) {
      var ids = {};
      ((a[0].links || {}).business || []).forEach(function (l) { ids[String(+l.target_id)] = 1; });
      (a[1].contacts || []).forEach(function (c) { if (c.kind === 'business' && c.ref) ids[String(+c.ref)] = 1; });
      return ids;
    });
    return favs;
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  // under the top bar and the account bar (your name and role stay in sight while the map is open; Jason, 2026-11-12: "it looks
  // wrong with no user command bar")
  function top() {
    var y = 0, b = document.getElementById('top-bar'); if (b) y = Math.max(0, b.getBoundingClientRect().bottom);
    // below whichever of the header and the account bar ends lower (the bar is above the header again, 2026-11-12)
    var a = document.querySelector('.tv-as'); if (a) { var r = a.getBoundingClientRect(); if (r.height && getComputedStyle(a).display !== 'none' && r.bottom > y) y = r.bottom; }
    return y;
  }
  function miles(a, b) { var R = 3958.8, r = Math.PI / 180, dl = (b[0] - a[0]) * r, dn = (b[1] - a[1]) * r;
    var x = Math.sin(dl / 2) * Math.sin(dl / 2) + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(dn / 2) * Math.sin(dn / 2); return 2 * R * Math.asin(Math.sqrt(x)); }
  function pref(k, v) { try { if (v === undefined) return localStorage.getItem('tvm_' + k); localStorage.setItem('tvm_' + k, v); } catch (x) {} return null; }
  function isPhone() { return window.matchMedia('(max-width: 767px)').matches; }

  function open(opt) {
    close(true);
    var el = document.createElement('div'); el.className = 'tvm'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Map');
    el.style.top = top() + 'px';
    var layer = LAYERS[pref('layer')] ? pref('layer') : 'streets', auto = pref('auto') === '1';
    el.innerHTML = '<div class="tvm-map"></div>'
      + '<button type="button" class="tvm-exit" data-exit title="Leave the map (Esc)">&times; Exit map</button>'
      + '<button type="button" class="tvm-here" data-area hidden>Search this area</button>'
      + '<button type="button" class="tvm-tab" data-side aria-expanded="false" aria-controls="tvm-side" title="Map tools and details">&rsaquo;</button>'
      + '<aside class="tvm-side" id="tvm-side" hidden aria-label="Map tools">'
      +   '<div class="tvm-sh"><div class="tvm-title"></div><div class="tvm-how"></div><div class="tvm-note">Loading the map…</div><div class="tvm-empty"></div><button type="button" class="tvm-shx" data-min aria-expanded="true" aria-label="Fold the panel down" title="Fold down"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg></button></div>'
      +   '<div class="tvm-sb"><div class="tvm-chosen"></div><div class="tvm-sec tvm-list" hidden></div>'
      +     '<div class="tvm-sec"><b>Show</b>' + (opt.tools ? '<div class="tvm-row">' + opt.tools + '</div>' : '')
      +       '<p class="tvm-note" style="margin:.45rem 0 0">Looking for something in particular? Type it in the search at the top and press Enter.</p></div>'
      +     '<div class="tvm-sec"><b>Distance</b><select class="tvm-sel" aria-label="Distance"><option value="">The whole place</option><option value="5">Within 5 mi</option><option value="10">Within 10 mi</option><option value="25">Within 25 mi</option><option value="50">Within 50 mi</option><option value="100">Within 100 mi</option></select>'
      +       '<label class="tvm-chk"><input type="checkbox" data-auto' + (auto ? ' checked' : '') + '> Search this area as I move the map</label></div>'
      +     '<div class="tvm-sec" data-sec-layers><b>Map style</b><div class="tvm-lyr">' + Object.keys(LAYERS).map(function (k) {
              return '<label' + (k === layer ? ' class="on"' : '') + '><input type="radio" name="tvm-layer" value="' + k + '"' + (k === layer ? ' checked' : '') + '> ' + LAYERS[k][0] + '</label>'; }).join('') + '</div>'
      +       '<p class="tvm-note" style="margin:.4rem 0 0">Terrain and Satellite cover the United States.</p></div>'
      +     '<div class="tvm-sec"><b>On the map</b><div class="tvm-leg">'
      +       '<span><i class="tvm-pin" style="display:inline-block"><span></span></i> A place or business</span>'
      +       '<span><i class="tvm-fav" style="display:inline-block"><span>&#9829;</span></i> One of your favorites</span>'
      +       '<span><i class="tvm-stack" style="display:inline-block;transform:scale(.6);margin:-9px"><span><b>12</b></span></i> Listings whose location is approximate</span>'
      +       '<span><i style="display:inline-flex;width:24px;height:24px;border-radius:999px;background:rgba(241,211,87,.8);align-items:center;justify-content:center;font-style:normal;font-size:.7rem">12</i> Several places together: zoom in or tap</span>'
      +       '<span class="tvm-note" style="margin:0">Most pins mark the ZIP area, not the street.</span></div></div>'
      +   '</div></aside>'
      + '<div class="tvm-ctl"><div class="grp"><button type="button" data-zoom="1" aria-label="Zoom in" title="Zoom in">+</button><button type="button" data-zoom="-1" aria-label="Zoom out" title="Zoom out">&minus;</button></div>'
      +   '<div class="grp"><button type="button" data-locate aria-label="Go to my location" title="Go to my location (stays on this device)">' + I.locate + '</button>'
      +   '<button type="button" data-area aria-label="Search this area" title="Search this area">' + I.area + '</button>'
      +   '<button type="button" data-layers aria-label="Map style" title="Map style">' + I.layers + '</button></div></div>';
    document.body.appendChild(el);
    document.documentElement.style.overflow = 'hidden';
    document.documentElement.classList.add('tvm-open');
    cur = { el: el, opt: opt, pins: [], markers: {}, sel: null, area: null, q: '', map: null, cluster: null, circle: null, tiles: null, me: null, pushed: false, quiet: false, auto: auto, favs: {} };
    try { history.pushState({ tvmap: 1 }, ''); cur.pushed = true; } catch (x) {}
    el.querySelector('.tvm-title').textContent = opt.title || 'Map';
    if (opt.radius) el.querySelector('.tvm-sel').value = String(opt.radius);
    if (opt.panel || (pref('side') === '1' && !isPhone())) side(true);   // a map opened as its own view starts with its panel open (decisions/0058 §21)
    // while the map is open, the header search says what to look for; after, it goes back to the page's own use
    cur.prevHere = window.tvSearchHere;
    window.tvSearchHere = function (q) { if (!cur) return false; cur.q = q; reload(); return true; };
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-exit]')) { close(); return; }
      if (e.target.closest('[data-side]')) { side(el.querySelector('.tvm-side').hidden); return; }
      // a phone: the panel folds down to its title line and back up; it doesn't close (decisions/0058 §23)
      var lk = e.target.closest('[data-lead]'); if (lk) { leads(lk.getAttribute('data-lead'), ''); return; }
      if (e.target.closest('[data-widen25]') && cur.map) { var wc = cur.map.getCenter(); cur.area = { lat: wc.lat, lon: wc.lng, radius: 25 }; el.querySelector('.tvm-sel').value = '25'; reload(true); return; }
      if (e.target.closest('.tvm-empty [data-area]')) { searchArea(); return; }
      if (e.target.closest('[data-min]') || (el.classList.contains('side-min') && e.target.closest('.tvm-sh'))) { fold(!el.classList.contains('side-min')); return; }
      var z = e.target.closest('[data-zoom]'); if (z && cur.map) { cur.map.setZoom(cur.map.getZoom() + (+z.getAttribute('data-zoom'))); return; }
      if (e.target.closest('[data-locate]')) { locate(); return; }
      // how the place was chosen (under the title): change it, or answer the question when no place is set
      if (e.target.closest('[data-change-place]')) { if (typeof openLocationModal === 'function') openLocationModal(); return; }
      var keep = e.target.closest('[data-device-keep]');
      if (keep) { devicePref(keep.checked); if (keep.checked && cur.ask) cur.ask(true); return; }   // ticking "always" is a yes
      if (e.target.closest('[data-device-stop]')) { devicePref(false); how(cur); return; }
      var pk = e.target.closest('[data-pick]');
      if (pk && cur.map) { var pid = pk.getAttribute('data-pick'), pp = cur.pins.filter(function (x) { return String(x.id) === pid; })[0];
        if (pp) { cur.quiet = true; cur.map.setView([+pp.lat, +pp.lon], Math.max(cur.map.getZoom(), 15)); setTimeout(function () { cur.quiet = false; }, 600); select(pp.id); } return; }
      if (e.target.closest('[data-more-list]')) { cur.listN = (cur.listN || 25) + 25; list(cur); return; }
      if (e.target.closest('[data-area]')) { searchArea(); return; }
      if (e.target.closest('[data-layers]')) { side(true); var ls = el.querySelector('[data-sec-layers]'); if (ls) ls.scrollIntoView({ block: 'nearest' }); return; }
      var a = e.target.closest('[data-act]');
      if (a && opt.onTool) { el.querySelectorAll('.tvm-side [data-act]').forEach(function (b) { b.classList.toggle('go', b === a); }); opt.onTool(a.getAttribute('data-act')); return; }
      var ct = e.target.closest('[data-cat]');
      if (ct && opt.onCategory) { select(null); opt.onCategory(ct.getAttribute('data-cat'), ct.getAttribute('data-catname')); return; }
      var n = e.target.closest('[data-step]'); if (n) { step(+n.getAttribute('data-step')); return; }
      if (e.target.closest('[data-card-x]')) { select(null); }
    });
    el.querySelector('.tvm-sel').addEventListener('change', function () {
      var r = +this.value; if (!cur.map) return;
      if (!r) { cur.area = null; reload(); return; }
      var c = cur.map.getCenter(); cur.area = { lat: c.lat, lon: c.lng, radius: r };
      if (opt.onRadius) opt.onRadius(r, cur.area);
      reload();
    });
    el.querySelector('[data-auto]').addEventListener('change', function () { cur.auto = this.checked; pref('auto', this.checked ? '1' : '0'); if (cur.auto) searchArea(); });
    el.querySelectorAll('input[name="tvm-layer"]').forEach(function (r) { r.addEventListener('change', function () { setLayer(this.value); }); });
    // swipe between results on phones
    var sx = null;
    el.addEventListener('touchstart', function (e) { if (e.target.closest('.tvm-card')) sx = e.touches[0].clientX; }, { passive: true });
    el.addEventListener('touchend', function (e) { if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; sx = null; if (Math.abs(dx) > 50) step(dx < 0 ? 1 : -1); }, { passive: true });
    loadFavs().then(function (f) { if (cur && cur.el === el) { cur.favs = f; if (cur.pins.length) paint(false); } });
    loadLeaflet().then(function () {
      if (!cur || cur.el !== el) return;
      cur.map = L.map(el.querySelector('.tvm-map'), { zoomControl: false, attributionControl: false }).setView([34.2, -110.0], 8);
      L.control.attribution({ position: 'topleft', prefix: '<a href="https://leafletjs.com" target="_blank" rel="noopener">Leaflet</a>' }).addTo(cur.map);   // top left: clear of the panel's tab and the controls
      setLayer(layer);
      cur.cluster = L.markerClusterGroup({ showCoverageOnHover: false, maxClusterRadius: 45 });
      cur.map.addLayer(cur.cluster);
      var t = null;
      cur.map.on('moveend', function () {
        if (!cur || cur.quiet) return;
        if (cur.auto) { clearTimeout(t); t = setTimeout(searchArea, 450); }
        else { el.querySelector('.tvm-ctl [data-area]').classList.add('due'); el.querySelector('.tvm-here').hidden = false; }   // "search this area" is waiting, in words too
      });
      startNear(function () { reload(); });   // where you are, 5 mi, before anything loads (2026-11-10)
      showMe();   // where you are, when this browser already shares it (2026-11-10)
    }).catch(function (e) { note(e.message + '. Exit to see the list.'); side(true); });
  }
  function side(openIt) {
    if (!cur) return;
    var s = cur.el.querySelector('.tvm-side'), tab = cur.el.querySelector('.tvm-tab');
    s.hidden = !openIt; cur.el.classList.toggle('side-open', openIt);
    tab.innerHTML = openIt ? '&lsaquo;' : '&rsaquo;'; tab.setAttribute('aria-expanded', String(openIt));
    if (!isPhone()) pref('side', openIt ? '1' : '0');
  }
  function fold(down) {
    if (!cur) return;
    cur.el.classList.toggle('side-min', down);
    var b = cur.el.querySelector('[data-min]'); b.setAttribute('aria-expanded', String(!down));
    b.setAttribute('aria-label', down ? 'Unfold the panel' : 'Fold the panel down'); b.title = down ? 'Unfold' : 'Fold down';
  }
  function setLayer(k) {
    if (!cur || !cur.map || !LAYERS[k]) return;
    if (cur.tiles) cur.map.removeLayer(cur.tiles);
    cur.tiles = L.tileLayer(LAYERS[k][1], LAYERS[k][2]).addTo(cur.map);
    pref('layer', k);
    cur.el.querySelectorAll('.tvm-lyr label').forEach(function (l) { var i = l.querySelector('input'); i.checked = i.value === k; l.classList.toggle('on', i.checked); });
  }
  function locate() {
    if (!cur || !cur.map) return;
    if (!navigator.geolocation) { note('This browser can\'t share a location.'); side(true); return; }
    var b = cur.el.querySelector('[data-locate]'); b.setAttribute('aria-pressed', 'true');
    navigator.geolocation.getCurrentPosition(function (p) {
      if (!cur) return;
      var ll = [p.coords.latitude, p.coords.longitude];
      if (cur.me) cur.map.removeLayer(cur.me);
      cur.me = L.marker(ll, { interactive: false, icon: L.divIcon({ className: 'tvm-me', html: '<span></span>', iconSize: [16, 16], iconAnchor: [8, 8] }) }).addTo(cur.map);
      cur.map.setView(ll, Math.max(cur.map.getZoom(), 11));
      b.setAttribute('aria-pressed', 'false');
    }, function () { b.setAttribute('aria-pressed', 'false'); note('Your location isn\'t available. Check the browser\'s location permission.'); side(true); }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 });
  }
  // "A pin for where I am currently located physically" (Jason, 2026-11-10): the blue dot, on opening, when the place came
  // from this device or the browser already allows location for the site; never a permission prompt nobody asked for
  // (the location button asks). It doesn't move the map. Nothing about it leaves the device.
  function showMe() {
    var me = cur; if (!me || !me.map) return;
    var put = function (lat, lon) {
      if (cur !== me || !isFinite(lat) || !isFinite(lon)) return;
      if (me.me) me.map.removeLayer(me.me);
      me.me = L.marker([lat, lon], { interactive: false, keyboard: false, zIndexOffset: 800, icon: L.divIcon({ className: 'tvm-me', html: '<span title="You are here"></span>', iconSize: [16, 16], iconAnchor: [8, 8] }) }).addTo(me.map); list(me);   // the list measures from you now
    };
    try { var loc = typeof currentLocation !== 'undefined' ? currentLocation : null; if (loc && loc.source === 'device' && loc.lat != null && loc.lon != null) put(+loc.lat, +loc.lon); } catch (x) {}
    // only when the person said yes (now, or "always" on this device; 2026-11-11), never because the browser would answer
    if (!me.fromDevice) return;
    try {
      if (navigator.geolocation && navigator.permissions && navigator.permissions.query) navigator.permissions.query({ name: 'geolocation' }).then(function (st) {
        if (st.state === 'granted') navigator.geolocation.getCurrentPosition(function (p) { put(p.coords.latitude, p.coords.longitude); }, function () {}, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
      }, function () {});
    } catch (x) {}
  }
  // "Map should open zoomed to current location + 5 mile radius so it doesn't see entire western states" (Jason,
  // 2026-11-10): opened without a pin to show, the map starts 5 mi around the place set on the site when it has a point
  // (Auto-detect, a ZIP's middle), or around the device when the browser already shares it and no place is set. Else as
  // before: everything for the place, fitted. Widening is the Distance setting or Search this area.
  var START_MI = 5;
  function startNear(go) {
    var me = cur; if (!me || me.opt.select) { go(); return; }
    var done = false, at = function (lat, lon) {
      if (done) return; done = true;
      // the distance the page already uses (the directory's Within), else 5 mi (2026-11-12: the map opened at 5 mi on a list of 50)
      var mi = [5, 10, 25, 50, 100].indexOf(+me.opt.radius) >= 0 ? +me.opt.radius : START_MI;
      if (cur === me && isFinite(lat) && isFinite(lon)) { me.area = { lat: +lat, lon: +lon, radius: mi }; var sel = me.el.querySelector('.tvm-sel'); if (sel) sel.value = String(mi); }
      go();
    };
    var loc = null; try { loc = typeof currentLocation !== 'undefined' ? currentLocation : null; } catch (x) {}
    if (loc && loc.lat != null && loc.lon != null) { at(loc.lat, loc.lon); return; }
    if (loc && loc.zip) { fetch('/api/place.php?zip=' + encodeURIComponent(loc.zip)).then(function (r) { return r.json(); }).then(function (d) { var p = d && d.place; if (p && p.lat != null) at(p.lat, p.lon); else { done = true; go(); } }).catch(function () { if (!done) { done = true; go(); } }); return; }
    // no place set: opening the map is asking what's around, so the device is asked where it is (the browser's one-time
    // question, as the location button asks; 2026-11-10: the map sat on its default view of eastern Arizona instead)
    var placeSet = !!(loc && (loc.city || (loc.scope && loc.scope.slug)));
    if (!placeSet && navigator.geolocation) {
      // never silently (Jason, 2026-11-11: "this needs to be a confirmed setting each time unless there is a setting set for
      // future use"): asked here each time, unless "always" was chosen on this device
      if (!devicePref()) {
        // the site's own Town or ZIP box and target, under the title, wait for the person (a place typed, or the target tapped)
        me.ask = function (yes) { me.ask = null; askBox(me, false); if (yes) { me.fromDevice = 'always'; findMe(); } how(me); };
        how(me); note('');
        askBox(me, true);   // and said over the map itself, where it's seen (Jason, 2026-11-12: "needs a popup or notification to set location")
        return;
      }
      me.fromDevice = 'always';
      findMe();
      return;
    }
    done = true; go();
    function findMe() {
      note('Finding where you are…');
      navigator.geolocation.getCurrentPosition(function (p) { at(p.coords.latitude, p.coords.longitude); showMe(); },
        function () { if (!done) { done = true; go(); setTimeout(function () { if (cur === me && !me.pins.length) note('Allow location for this site, or choose a place, to see what\u2019s near you.'); }, 1500); } },
        { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 });
    }
  }
  // No place set: a card over the map asks where to look: this device's location, a town or ZIP (the panel's place box), or
  // look around without one. Gone once a place is chosen or the card is closed.
  function askBox(me, on) {
    // the site's one place pop-up (js/location-scope.js tvPlacePop, 2026-11-12); this map's own card where it isn't loaded
    if (!on && me.ppClose) { var pc = me.ppClose; me.ppClose = null; pc(); }
    if (on && typeof window.tvPlacePop === 'function') { me.ppClose = window.tvPlacePop({ notSure: function () {}, onClose: function () { me.ppClose = null; } }); return; }
    var old = me.el.querySelector('.tvm-askbox'); if (old) old.remove();
    var od = me.el.querySelector('.tvm-askdim'); if (od) od.remove();
    if (!on) return;
    if (!document.getElementById('tvm-ask-css')) {
      var st = document.createElement('style'); st.id = 'tvm-ask-css';
      st.textContent = '.tvm-askdim{position:absolute;inset:0;z-index:715;background:rgba(43,29,20,.45)}'   /* the map greyed behind the question (2026-11-12) */
        + '.tvm-askbox{position:absolute;z-index:720;left:50%;top:50%;transform:translate(-50%,-50%);width:min(24rem,calc(100% - 2rem));background:#FFFBF2;border:1px solid #CBB98D;border-radius:1rem;box-shadow:0 18px 40px -16px rgba(0,0,0,.6);padding:1rem 1.1rem;color:#3E2B1F;text-align:center}'
        + '.tvm-askbox h3{margin:0 0 .3rem;font:700 1.15rem ui-serif,Georgia,serif}.tvm-askbox p{margin:0 0 .8rem;font-size:.9rem;color:#5C4632}'
        + '.tvm-askbox .tvm-ab{display:flex;align-items:center;justify-content:center;gap:.4rem;width:100%;margin-top:.4rem;border-radius:.7rem;padding:.6rem;font:700 .95rem system-ui,sans-serif;cursor:pointer;border:1px solid #CBB98D;background:#fff;color:#3E2B1F}'
        + '.tvm-askbox .tvm-ab.go{background:#92400E;border-color:#92400E;color:#FFFBF2}.tvm-askbox .tvm-ab.lt{border:0;background:none;font-weight:600;color:#78716C;text-decoration:underline}'
        + '.tvm-askbox .tvm-abx{position:absolute;top:.4rem;right:.5rem;border:0;background:none;font-size:1.4rem;line-height:1;color:#78716C;cursor:pointer}'
        + '@media (max-width:767px){.tvm-askbox{top:38%}}';
      document.head.appendChild(st);
    }
    var b = document.createElement('div'); b.className = 'tvm-askbox'; b.setAttribute('role', 'dialog'); b.setAttribute('aria-label', 'Where should the map look?');
    b.innerHTML = '<button type="button" class="tvm-abx" data-ab="close" aria-label="Close" title="Close">&times;</button><h3>Where should the map look?</h3><p>No place is set yet. Use where you are, or choose a town or ZIP.</p>'
      + '<button type="button" class="tvm-ab go" data-ab="me">&#9678; Use my location</button>'
      + '<button type="button" class="tvm-ab" data-ab="type">Type a town or ZIP</button>'
      + '<button type="button" class="tvm-ab lt" data-ab="close">Look around without a place</button>';
    b.addEventListener('click', function (e) {
      var k = (e.target.closest('[data-ab]') || {}).getAttribute ? e.target.closest('[data-ab]').getAttribute('data-ab') : ''; if (!k) return;
      if (k === 'me') { if (me.ask) me.ask(true); else askBox(me, false); return; }
      askBox(me, false);
      if (k === 'type') { side(true); var i = me.el.querySelector('.tvm-how [data-place-box] input'); if (i) setTimeout(function () { i.focus(); }, 60); }
    });
    var dim = document.createElement('div'); dim.className = 'tvm-askdim'; dim.addEventListener('click', function () { askBox(me, false); });
    me.el.appendChild(dim); me.el.appendChild(b);
  }
  // "Always use my location when no place is set", kept on this device; read with no argument, set with true or false
  window.addEventListener('tv:location', function () {
    var me = cur; if (!me || !me.map || me.opt.select) return;
    askBox(me, false);
    me.ask = null; me.fromDevice = false; me.area = null; how(me);
    startNear(function () { reload(); }); showMe();
  });
  function devicePref(v) {
    try { if (v === undefined) return localStorage.getItem('tv_map_device') === 'always'; if (v) localStorage.setItem('tv_map_device', 'always'); else localStorage.removeItem('tv_map_device'); } catch (x) {}
    return false;
  }
  // Under the panel's title: how the place for this map was chosen, with a way to change it (Jason, 2026-11-11: "I would
  // like the method used listed under the title in the panel so it can be changed if the user wants it changed")
  function how(me) {
    if (!me || !me.el) return; var box = me.el.querySelector('.tvm-how'); if (!box) return;
    // the site's one place box (js/location-scope.js wirePlaceBox: a town or ZIP, or the target), made once so typing isn't lost
    // (Jason, 2026-11-11: "I gave you instructions to use the simple location/autodetect for this")
    // the place is one button that opens the site's place pop-up, the one place chooser (Jason, 2026-11-12: "do we need the
    // select location in the page if the popup is our selector?"); the old box where the pop-up isn't loaded
    var popup = typeof window.tvPlacePop === 'function';
    if (!box.querySelector('.tvm-howt')) {
      box.innerHTML = (popup ? '<div class="tvm-plw"><button type="button" class="tvm-plb" data-tvm-place aria-haspopup="dialog"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg><span></span></button><button type="button" class="tvm-pltg tv-pbox-tgt" data-tvm-tgt title="Use my location" aria-label="Use my location"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg></button></div>'
        : (typeof window.wirePlaceBox === 'function' ? '<span class="tv-pbox" data-place-box></span>' : '')) + '<p class="tvm-howt"></p>';
      var pb = box.querySelector('[data-place-box]'); if (pb) window.wirePlaceBox(pb);
      var plb = box.querySelector('[data-tvm-place]'); if (plb) plb.addEventListener('click', function () { window.tvPlacePop({ notSure: function () {} }); });
      var ptg = box.querySelector('[data-tvm-tgt]'); if (ptg) ptg.addEventListener('click', function (e) { if (typeof autoDetectLocation === 'function') autoDetectLocation(e); });   // the target: where you are, at once
      if (popup && !document.getElementById('tvm-plb-css')) { var cs = document.createElement('style'); cs.id = 'tvm-plb-css'; cs.textContent = '.tvm-plb{display:flex;align-items:center;gap:.4rem;width:100%;border:1px solid #CBB98D;border-radius:999px;background:#FFFBF2;color:#3E2B1F;font:600 .95rem system-ui,sans-serif;padding:.45rem .75rem;cursor:pointer;text-align:left}.tvm-plb svg{color:#B45309;flex:none}.tvm-plb span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.tvm-plw{display:flex;align-items:center;gap:.35rem}.tvm-plw .tvm-plb{flex:1;min-width:0}.tvm-pltg{flex:none;width:34px;height:34px;display:flex;align-items:center;justify-content:center;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#B45309;cursor:pointer;padding:0}.tvm-pltg:hover{border-color:#B45309}.tvm-plb:hover{border-color:#B45309}'; document.head.appendChild(cs); }
    }
    var plbl = box.querySelector('[data-tvm-place] span');
    if (plbl) { var nm = ''; try { nm = typeof tvPlaceLabel === 'function' ? tvPlaceLabel() : ''; } catch (x) {} plbl.textContent = (me.opt.pagePlace && me.opt.pagePlace.label) || nm || 'Choose a place'; }
    var t = box.querySelector('.tvm-howt'), lk = function (txt, a) { return '<button type="button" class="tvm-lk" ' + a + '>' + txt + '</button>'; };
    var pw = null; try { pw = typeof tvPlaceWhy === 'function' ? tvPlaceWhy() : null; } catch (x) {}
    // a page about one area (Let's Explore's map of St. Johns) shows that area, whatever the site's place is
    var pg = me.opt.pagePlace;
    if (pg && pg.label && !(pw && pw.place && String(pw.place).toLowerCase() === String(pg.label).toLowerCase())) t.innerHTML = esc(pg.label) + ': the area this page is about.';
    else if (pw && pw.place) t.innerHTML = esc(pw.place) + ': ' + esc(pw.why) + '.';
    else if (me.fromDevice && me.area) t.innerHTML = 'Around you, ' + me.area.radius + ' mi: this device’s location' + (devicePref() ? ' (your setting: always, when no place is set).' + lk('Ask each time', 'data-device-stop') : '.');
    else t.innerHTML = (popup ? 'No place set. Choose one above: a town, a ZIP or where you are.' : 'No place set. Type a town or ZIP, or tap the target to use where you are.')
      + '<label><input type="checkbox" data-device-keep' + (devicePref() ? ' checked' : '') + '> Always use my location when no place is set (this device)</label>';
  }

  function note(t) { if (cur) cur.el.querySelector('.tvm-sh .tvm-note').textContent = t; }
  function searchArea() {
    if (!cur || !cur.map) return;
    cur.el.querySelector('.tvm-ctl [data-area]').classList.remove('due'); cur.el.querySelector('.tvm-here').hidden = true;
    cur.fromDevice = false; how(cur);   // this area now, not where the device is
    var b = cur.map.getBounds(), c = cur.map.getCenter();
    var r = Math.max(2, Math.min(250, Math.round(miles([c.lat, c.lng], [b.getNorth(), b.getEast()]))));
    cur.area = { lat: c.lat, lon: c.lng, radius: r };
    cur.el.querySelector('.tvm-sel').value = [5, 10, 25, 50, 100].indexOf(r) >= 0 ? String(r) : '';
    reload(true);
  }
  function reload(keepView) {
    if (!cur || !cur.map) return;
    var me = cur;
    note('Loading pins…'); how(me);
    me.opt.load(me.area, me.q).then(function (d) {
      if (cur !== me) return;
      if (me.opt.titleFor) { try { var tt = String(me.opt.titleFor(d)).replace(/^[\d,]+\s*(·\s*)?/, ''); tt = tt.charAt(0).toUpperCase() + tt.slice(1);   // the count is in the line under it
          me.el.querySelector('.tvm-title').textContent = tt + (me.q ? ' · “' + me.q + '”' : ''); } catch (x) {} }
      me.pins = (d.pins || []).filter(function (p) { return p.lat != null && p.lon != null; });
      if (me.circle) { me.map.removeLayer(me.circle); me.circle = null; }
      var c = me.area || d.center;
      if (c && c.radius) me.circle = L.circle([c.lat, c.lon], { radius: c.radius * 1609.34, color: '#B45309', weight: 2, dashArray: '6 6', fillOpacity: 0.04, interactive: false }).addTo(me.map);
      paint(!keepView);
      var nf = me.pins.filter(function (p) { return me.favs[String(p.id)]; }).length;
      note(me.countNote = me.pins.length ? me.pins.length.toLocaleString() + ' on the map' + (nf ? ' · ♥ ' + nf + ' of your favorites' : '') + (d.truncated ? ' (the first ' + me.pins.length + ' of ' + d.total + '; zoom in or narrow the search)' : '')
                          : 'Nothing of ours here' + (me.q ? ' for “' + me.q + '”' : '') + ' yet.');
      emptyWays(me);
      me.leadItems = []; me.listN = 25; list(me);
      if (me.opt.leadsFor && !me.q) { var lk0 = me.opt.leadsFor(); if (lk0) leads(lk0, ''); }   // OpenStreetMap's, beside ours (2026-11-10)
      if (me.opt.select && !me.selDone) { me.selDone = true; select(me.opt.select); } else select(null);   // opened for one place: it's chosen
    }).catch(function (e) { if (cur === me) note('The pins could not load (' + e.message + ').'); });
  }
  // nothing of ours here: search where the map is, widen, or OpenStreetMap's places (a lead only: name, kind, how far,
  // directions; asking also sends the town to our crawler, so our listings follow)
  var LEADS = [['food', 'Places to eat'], ['coffee', 'Coffee'], ['grocery', 'Groceries'], ['fuel', 'Gas'], ['pharmacy', 'Pharmacy'], ['lodging', 'Places to stay'], ['trail', 'Trails'], ['park', 'Parks'], ['camping', 'Campgrounds']];
  function emptyWays(me) {
    var box = me.el.querySelector('.tvm-empty'); if (!box) return;
    if (me.leadLayer) me.leadLayer.clearLayers();
    if (me.pins.length) { box.innerHTML = ''; return; }
    box.innerHTML = '<button type="button" class="tvm-b go" data-area>Search this area</button><button type="button" class="tvm-b" data-widen25>Widen to 25 mi</button>'
      + '<p>Or what OpenStreetMap has here:</p>' + LEADS.map(function (k) { return '<button type="button" class="tvm-b" data-lead="' + k[0] + '">' + k[1] + '</button>'; }).join('');
    if (me.opt.leadsFor) return;   // the page asks for its own kind of leads after every load (Discovery)
    if (me.q) leads('', me.q);   // the words name a kind ("coffee shops"): its places at once
    else leads('all', '');        // no words: everything everyday OpenStreetMap has here, at once (2026-11-10)
  }
  function leads(kind, words) {
    var me = cur; if (!me || !me.map) return;
    var c = me.area || (function () { var x = me.map.getCenter(); return { lat: x.lat, lon: x.lng, radius: 5 }; })();
    var p = new URLSearchParams({ lat: (+c.lat).toFixed(3), lon: (+c.lon).toFixed(3), mi: String(Math.max(1, Math.min(25, c.radius || 5))), crawl: '1' });
    if (kind) p.set('kind', kind); else p.set('words', words);
    var base = me.countNote || '';
    if (kind) note((base ? base + ' · ' : '') + 'checking OpenStreetMap for more…');
    fetch('/api/open-places.php?' + p.toString(), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (cur !== me || !d.ok) return;
      if (!me.leadLayer) me.leadLayer = L.layerGroup().addTo(me.map);
      me.leadLayer.clearLayers();
      var e = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (ch) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]; }); };
      var ours = {}; (me.pins || []).forEach(function (pp) { ours[String(pp.name || '').toLowerCase()] = [pp.lat, pp.lon]; });
      (d.items || []).forEach(function (it) {
        var ll = /destination=([-\d.]+),([-\d.]+)/.exec(decodeURIComponent(it.directions || ''));
        if (!ll) return;
        var o = ours[String(it.label || '').toLowerCase()]; if (o && miles(o, [+ll[1], +ll[2]]) < 0.3) return;   // ours already: one pin
        L.marker([+ll[1], +ll[2]], { title: it.label, icon: L.divIcon({ className: 'tvm-lead', html: '<span></span>', iconSize: [18, 18], iconAnchor: [9, 9] }) })
          .bindPopup('<b>' + e(it.label) + '</b><br><small>' + e(it.what) + ' · ' + e(it.miles) + ' mi' + (it.street ? ' · ' + e(it.street) : '') + (it.hours ? '<br>' + e(it.hours) : '') + '<br>from <a href="' + e(d.credit_url) + '" target="_blank" rel="noopener">OpenStreetMap</a>, not our listing</small><br>'
            + '<a href="' + e(it.directions) + '" target="_blank" rel="noopener">Directions</a>' + (it.phone ? ' · <a href="tel:' + e(String(it.phone).replace(/[^\d+]/g, '')) + '">Call</a>' : '') + (it.website ? ' · <a href="' + e(it.website) + '" target="_blank" rel="noopener nofollow">Website</a>' : ''))
          .addTo(me.leadLayer);
      });
      me.leadItems = (d.items || []).map(function (it) { var m2 = /destination=([-\d.]+),([-\d.]+)/.exec(decodeURIComponent(it.directions || ''));
        return m2 ? { label: it.label, what: it.what, directions: it.directions, lat: +m2[1], lon: +m2[2] } : null; }).filter(Boolean)
        .filter(function (it) { var o2 = ours[String(it.label || '').toLowerCase()]; return !(o2 && miles(o2, [it.lat, it.lon]) < 0.3); });
      list(me);
      var n = (d.items || []).length;
      // our count stays (Jason, 2026-11-11: "not sure about … osm not findings"); OpenStreetMap's places are added to it, and an
      // empty answer (none, or OpenStreetMap busy) is never said as if nothing were here
      if (n || kind) note(n ? (base ? base + ' · plus ' : '') + n + ' ' + String(d.label || 'places').toLowerCase() + ' from OpenStreetMap (lighter pins), not our listings yet. We\u2019ve asked our crawler to add them.'
        : (base || (me.pins && me.pins.length ? '' : 'Nothing listed here yet. Try a wider Distance, or another place.')));
      if (n) { var b = L.latLngBounds(me.leadLayer.getLayers().map(function (m) { return m.getLatLng(); })); me.quiet = true; me.map.fitBounds(b.pad(0.25), { maxZoom: 15 }); setTimeout(function () { me.quiet = false; }, 600); }
    }).catch(function () {});
  }
  function paint(fit) {
    var me = cur; if (!me || !me.cluster) return;
    me.cluster.clearLayers(); me.markers = {};
    if (!me.favLayer) me.favLayer = L.layerGroup().addTo(me.map);
    me.favLayer.clearLayers();
    if (!me.stackLayer) me.stackLayer = L.layerGroup().addTo(me.map);
    me.stackLayer.clearLayers();
    var hearts = [];
    // Three or more listings on exactly the same point are almost always on their ZIP area's middle (how they were
    // imported, until Map points places their street address): one marked spot that opens as a list, never a starburst
    // that looks like real places (decisions/0058 §14)
    var at = {};
    me.pins.forEach(function (p) { if (!me.favs[String(p.id)]) { var k = (+p.lat).toFixed(5) + ',' + (+p.lon).toFixed(5); (at[k] = at[k] || []).push(p); } });
    var stacked = {}, stacks = []; me.approx = stacked;
    Object.keys(at).forEach(function (k) {
      var g = at[k]; if (g.length < 3) return;
      g.forEach(function (p) { stacked[p.id] = 1; });
      me.approx = stacked;   // the list says these are approximate
      var sm = L.marker([g[0].lat, g[0].lon], { title: g.length + ' listings, location approximate', zIndexOffset: 300,
        icon: L.divIcon({ className: 'tvm-stack', html: '<span><b>' + g.length + '</b><small>approx.</small></span>', iconSize: [46, 46], iconAnchor: [23, 23] }) });
      sm.on('click', function () { stackList(g); });
      me.stackLayer.addLayer(sm); stacks.push(sm);
    });
    var ms = me.pins.map(function (p) {
      if (stacked[p.id]) return null;
      var fav = !!me.favs[String(p.id)];
      var m = L.marker([p.lat, p.lon], { title: p.name + (fav ? ' (a favorite)' : ''), zIndexOffset: fav ? 500 : 0,
        icon: fav ? L.divIcon({ className: 'tvm-fav', html: '<span>&#9829;</span>', iconSize: [24, 24], iconAnchor: [12, 12] })
                  : L.divIcon({ className: 'tvm-pin', html: '<span></span>', iconSize: [14, 14], iconAnchor: [7, 7] }) });
      m.on('click', function () { select(p.id); });
      me.markers[p.id] = m;
      if (fav) { hearts.push(m); return null; }   // favorites stay out of the groups: always visible
      return m;
    }).filter(Boolean);
    me.cluster.addLayers(ms);
    hearts.forEach(function (m) { me.favLayer.addLayer(m); });
    if (fit) {
      me.quiet = true;
      var all = L.featureGroup(ms.concat(hearts, stacks));
      if (ms.length || hearts.length || stacks.length) me.map.fitBounds(all.getBounds().pad(0.15), { maxZoom: 14 });
      else if (me.circle) me.map.fitBounds(me.circle.getBounds());
      setTimeout(function () { me.quiet = false; }, 500);
    }
  }
  // The pins in view, nearest the map's centre first: what previous / next steps through.
  function inView() {
    var b = cur.map.getBounds(), c = cur.map.getCenter();
    return cur.pins.filter(function (p) { return b.contains([p.lat, p.lon]); })
      .sort(function (a, z) { return miles([c.lat, c.lng], [a.lat, a.lon]) - miles([c.lat, c.lng], [z.lat, z.lon]); });
  }
  function step(dir) {
    if (!cur || !cur.pins.length) return;
    var list = inView(); if (!list.length) list = cur.pins;
    var i = list.map(function (p) { return p.id; }).indexOf(cur.sel);
    var next = list[(i + dir + list.length) % list.length];
    if (next) { select(next.id); cur.quiet = true; cur.map.panTo([next.lat, next.lon]); setTimeout(function () { if (cur) cur.quiet = false; }, 500); }
  }
  // The listings on one approximate spot, as a list in the side panel: tap one for its card
  function stackList(g) {
    if (!cur) return;
    if (cur.sel && cur.markers[cur.sel] && cur.markers[cur.sel]._icon) cur.markers[cur.sel]._icon.classList.remove('on');
    cur.sel = null;
    var box = cur.el.querySelector('.tvm-chosen'); box.innerHTML = '';
    fold(false);
    var list = g.slice().sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); });
    var card = document.createElement('div'); card.className = 'tvm-sec tvm-card tvm-stackl';
    card.innerHTML = '<div class="tvm-nav"><button type="button" data-card-x aria-label="Close">&times;</button></div>'
      + '<h3>' + g.length + ' listings here</h3><p class="m">Their location is approximate: the middle of the ZIP area, until their street address is placed on the map. Tap one to see it.</p>'
      + '<ul>' + list.map(function (p) { return '<li><button type="button" data-stackpick="' + esc(String(p.id)) + '"><b>' + esc(p.name) + '</b><small>' + esc(p.category || '') + '</small></button></li>'; }).join('') + '</ul>';
    card.addEventListener('click', function (e) {
      var b = e.target.closest('[data-stackpick]'); if (!b) return;
      var id = b.getAttribute('data-stackpick'), p = g.filter(function (x) { return String(x.id) === id; })[0];
      if (p) select(p.id);
    });
    box.appendChild(card);
    side(true); cur.el.querySelector('.tvm-sb').scrollTop = 0;
  }
  // the places as a list, nearest first (Jason, 2026-11-10: "Why do I have to select a pin instead of seeing a list of the
  // results ordered by closest"): ours and OpenStreetMap's together, measured from you (the blue dot), else the area's
  // middle; tap one of ours to choose its pin, one of OpenStreetMap's for directions
  function list(me) {
    var box = me.el.querySelector('.tvm-list'); if (!box || !me.map) return;
    // from you (Jason, 2026-11-11: "Based on my precise location shouldnt the listing be ordered by closest to my location?"):
    // the blue dot, else the location this site already has for you, else the middle of the map
    var loc = null; try { loc = typeof currentLocation !== 'undefined' ? currentLocation : null; } catch (x) {}
    var mine = loc && loc.lat != null && loc.lon != null && isFinite(+loc.lat) && isFinite(+loc.lon) ? { lat: +loc.lat, lng: +loc.lon } : null;
    var o = me.me ? me.me.getLatLng() : (mine || (me.area ? { lat: me.area.lat, lng: me.area.lon } : me.map.getCenter()));
    var fromWhat = me.me || (mine && loc.source === 'device') ? 'From where you are.' : (mine ? 'From ' + (String(loc.city || (loc.scope && loc.scope.label) || 'your place').split('\u00b7')[0].trim()) + '.' : 'From the middle of the map.');
    var from = [o.lat, o.lng];
    var rows = me.pins.map(function (p) { return { id: p.id, name: p.name, sub: p.category || '', mi: miles(from, [+p.lat, +p.lon]), approx: !!(me.approx && me.approx[p.id]) }; })
      .concat((me.leadItems || []).map(function (it) { return { url: it.directions, name: it.label, sub: (it.what || '') + ' · OpenStreetMap', mi: miles(from, [it.lat, it.lon]) }; }));
    // a listing placed at its ZIP code's middle (the map's "approx." spots) after the ones placed where they are, at about the same distance
    rows.sort(function (a, b) { return (Math.round(a.mi) - Math.round(b.mi)) || ((a.approx ? 1 : 0) - (b.approx ? 1 : 0)) || (a.mi - b.mi); });
    if (!rows.length) { box.hidden = true; box.innerHTML = ''; return; }
    var n = me.listN || 25;
    var mi = function (m) { return m < 0.1 ? 'here' : (m < 10 ? m.toFixed(1) : Math.round(m)) + ' mi'; };
    box.hidden = false;
    // where the place came from, at the top (Jason, 2026-11-11): a default, earlier in the visit, the region you came from…
    how(me);   // how the place was chosen, under the panel's title (2026-11-11)
    box.innerHTML = '<b>Nearest first</b><p class="tvm-note" style="margin:.2rem 0 .3rem">' + fromWhat + '</p>'
      + rows.slice(0, n).map(function (r) {
        var inner = '<span><b>' + esc(r.name) + '</b>' + (r.sub ? '<small>' + esc(r.sub) + '</small>' : '') + '</span><span class="tvm-mi">' + (r.approx ? 'about ' + mi(Math.max(r.mi, 0.1)).replace('here', '0.1 mi') + '<small style="display:block;font-weight:400;font-size:.7rem;color:#8A7355">location approx.</small>' : mi(r.mi)) + '</span>';
        return r.url ? '<a class="tvm-li" href="' + esc(r.url) + '" target="_blank" rel="noopener" data-out="directions">' + inner + '</a>'
                     : '<button type="button" class="tvm-li" data-pick="' + esc(r.id) + '">' + inner + '</button>';
      }).join('') + (rows.length > n ? '<button type="button" class="tvm-b" data-more-list style="margin-top:.4rem">Show ' + Math.min(25, rows.length - n) + ' more</button>' : '');
  }
  function select(id) {
    if (!cur) return;
    if (cur.sel && cur.markers[cur.sel] && cur.markers[cur.sel]._icon) cur.markers[cur.sel]._icon.classList.remove('on');
    cur.sel = id;
    var box = cur.el.querySelector('.tvm-chosen'); box.innerHTML = '';
    if (id === null) return;
    fold(false);   // a pin was tapped: show its card
    var m = cur.markers[id]; if (m && m._icon) m._icon.classList.add('on');
    var p = cur.pins.filter(function (x) { return x.id === id; })[0]; if (!p) return;
    var fav = !!cur.favs[String(p.id)];
    var card = document.createElement('div'); card.className = 'tvm-sec tvm-card'; card.setAttribute('aria-live', 'polite');
    var c = cur.map.getCenter();
    card.innerHTML = '<div class="tvm-nav"><button type="button" data-step="-1" aria-label="Previous">&lsaquo;</button><button type="button" data-step="1" aria-label="Next">&rsaquo;</button><button type="button" data-card-x aria-label="Close">&times;</button></div>'
      + '<p class="m tvm-cat">' + esc(p.category || '') + '</p><h3>' + (fav ? '<span title="One of your favorites" style="color:#BE123C">&#9829;</span> ' : '') + esc(p.name) + '</h3><p class="m">' + esc([p.city, p.state].filter(Boolean).join(', ')) + ' · ' + miles([c.lat, c.lng], [p.lat, p.lon]).toFixed(1) + ' mi from the map centre</p><div class="tvm-more m">Loading…</div>';
    box.appendChild(card);
    side(true); cur.el.querySelector('.tvm-sb').scrollTop = 0;
    fetch('/api/search.php?peek=' + encodeURIComponent(id), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      var more = card.querySelector('.tvm-more'); if (!more || !d.ok) { if (more) more.textContent = ''; return; }
      var l = d.listing;
      var out = function (k) { return l.kind === 'outdoors' ? '' : ' data-out="' + k + '" data-e="' + (+l.id) + '"'; };   // counted for the business (js/out-count.js)
      more.className = 'tvm-more';
      var cp = card.querySelector('.tvm-cat');
      if (cp && l.category_slug && cur && cur.opt.onCategory) cp.innerHTML = '<button type="button" class="tvm-catb" data-cat="' + esc(l.category_slug) + '" data-catname="' + esc(l.category) + '" title="Show every ' + esc(l.category) + ' listing here">' + esc(l.category) + ' &rsaquo;</button>';
      // enough to decide whether to go (2026-11-10: "a name only isn't enough to make a qualified decision to visit"): a photo,
      // what it is in a few lines, then where, hours and the ways to reach it
      more.innerHTML = (l.image ? '<figure class="tvm-pic"><img src="' + esc(l.image) + '" alt="" loading="lazy">' + (l.image_credit ? '<figcaption>' + esc(l.image_credit) + '</figcaption>' : '') + '</figure>' : '')
        + ((l.activities || []).length ? '<p class="tvm-acts2">' + l.activities.map(function (a) { return '<span class="tvm-act" title="' + esc(a.how) + '">' + esc(a.label) + '</span>'; }).join('') + '</p><p class="m">' + esc(l.activities[0].how) + '</p>' : '')
        + (l.about ? '<p class="tvm-about">' + esc(l.about) + '</p>' : '')
        // the guide that tells its story, in its own words (2026-11-10: the guide folded into the results)
        + (l.guide && l.guide.line ? '<blockquote class="tvm-guide">\u201C' + esc(l.guide.line) + '\u201D <a href="' + esc(l.guide.url) + '">From ' + esc(l.guide.title) + ' \u203A</a></blockquote>' : '')
        // been there? a tip or a review, or a change, right with what it's like (2026-11-10)
        + '<p class="tvm-tipbar"><a href="' + esc(l.url) + '#comments">Add a tip or review</a>' + (l.suggest ? ' \u00B7 <button type="button" class="tvm-linkb" data-tv-suggest="' + esc(JSON.stringify(l.suggest)) + '">Suggest a change</button>' : '') + '</p>'
        + (l.address ? '<p>' + esc(l.address) + '</p>' : l.private_location ? '<p class="m">Location kept private for the safety of the people it serves. Please call.</p>' : '')
        + (l.hours.length ? '<p class="m">' + l.hours.slice(0, 3).map(esc).join(' · ') + '</p>' : '')
        + '<div class="tvm-acts">' + (l.phone ? '<a href="tel:' + esc(l.phone.replace(/[^\d+]/g, '')) + '"' + out('call') + '>Call</a>' : '')
        + (l.directions ? '<a href="' + esc(l.directions) + '" target="_blank" rel="noopener"' + out('directions') + '>Directions</a>' : '')
        + (l.website ? '<a href="' + esc(l.website) + '" target="_blank" rel="noopener nofollow"' + out('website') + '>Website</a>' : '')
        + '<a class="go" href="' + esc(l.url) + '">Open &rsaquo;</a></div>'
        + (l.kind !== 'outdoors' && !l.private_location ? '<p class="m tvm-fix"><a href="/listing/location.php?id=' + (+l.id) + '">Wrong spot? Fix the pin</a></p>' : '')
        + (l.kind === 'outdoors' ? '' : '<div class="tvm-keep" data-link-host><span data-contact-save="business:' + l.id + '" data-link-label="' + esc(l.name) + '"></span><span data-link="business:' + l.id + '" data-link-label="' + esc(l.name) + '"></span></div>');
      if (l.approx) fixPin(card, p, l);
      if (l.kind !== 'outdoors' && !document.querySelector('script[src*="/js/link-button.js"]')) { var sc = document.createElement('script'); sc.src = '/js/link-button.js'; document.body.appendChild(sc); }
    }).catch(function () {});
  }
  // A pin that is only its ZIP area's middle (decisions/0058 §14): say so, ask the Census for the street point once,
  // and move the pin when it comes back. One the Census can't place stays where it is, labelled.
  function fixPin(card, p, l) {
    var more = card.querySelector('.tvm-more'); if (!more) return;
    var n = document.createElement('p'); n.className = 'm tvm-approx';
    n.textContent = 'Approximate pin: the middle of its ZIP area. Finding the street address…';
    more.insertBefore(n, more.firstChild);
    var fd = new FormData(); fd.append('id', String(l.id));
    fetch('/api/locate.php', { method: 'POST', body: fd, credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d || !d.ok || !d.lat) { n.textContent = 'Approximate pin: the middle of its ZIP area. The street address could not be placed on the map.'; return; }
      p.lat = +d.lat; p.lon = +d.lon;
      var m = cur && cur.markers[p.id];
      if (m) { m.setLatLng([p.lat, p.lon]); if (cur.cluster && cur.cluster.refreshClusters) cur.cluster.refreshClusters(m); }
      if (cur && cur.sel === p.id) { cur.quiet = true; cur.map.panTo([p.lat, p.lon]); setTimeout(function () { if (cur) cur.quiet = false; }, 500); }
      n.textContent = 'Pin moved to the street address.';
      var dir = card.querySelector('[data-out="directions"]'); if (dir) dir.href = 'https://www.google.com/maps/dir/?api=1&destination=' + p.lat + ',' + p.lon;
    }).catch(function () { n.textContent = 'Approximate pin: the middle of its ZIP area.'; });
  }
  function close(silent) {
    if (!cur) return;
    var c = cur; cur = null;
    window.tvSearchHere = c.prevHere;   // the header search goes back to the page's own use
    if (c.map) c.map.remove();
    c.el.remove();
    document.documentElement.style.overflow = '';
    document.documentElement.classList.remove('tvm-open');
    if (c.pushed && silent !== 'back') { try { history.back(); } catch (x) {} }
    if (silent !== true && c.opt.onList) c.opt.onList();
  }
  window.addEventListener('popstate', function () { if (cur) { cur.pushed = false; close('back'); } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && cur && !document.querySelector('.tv-cs, .tvs-panel')) close(); });
  window.addEventListener('resize', function () { if (cur) { cur.el.style.top = top() + 'px'; if (cur.map) cur.map.invalidateSize(); } });
  window.TvMap = { open: open, close: close, reload: function () { reload(); },
                   title: function (t) { if (cur) cur.el.querySelector('.tvm-title').textContent = t; }, isOpen: function () { return !!cur; },
                   query: function (q) { if (cur) { cur.q = q || ''; reload(); } },
                   retop: function () { if (cur) { cur.el.style.top = top() + 'px'; if (cur.map) cur.map.invalidateSize(); } } };
})();
