<?php
// admin/listing-add.php — Admin → Add a listing (decisions/0073 §6). Staff (admins and regional managers) start a
// listing with what they know: its name, category and town. It goes live unclaimed, with nobody assigned, and goes to
// the front of the crawler's identity queue (IdentityJobs::look), which finds its phone, website, email, social pages
// and hours and fills them in once confirmed, so staff don't have to look them up. With a website, "Crawl its website"
// reads the rest (about, offerings, hours) through Listing Intake. POSTs carry the CSRF token.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/admin-crawler.php';
require_once __DIR__ . '/../../app/lib/AddBusiness.php';
require_once __DIR__ . '/../../app/lib/ListingCategories.php';
require_once __DIR__ . '/../../app/lib/IdentityJobs.php';
require_once __DIR__ . '/../../app/ui/category-fields.php';

$pdo = Database::connection();
$me = tv_listing_staff_require($pdo);   // admins and regional managers
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$cats = IntakeStager::leafCategories($pdo);
$form = $_POST;
$dups = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $d = AddBusiness::clean($_POST + ['kind' => 'other'], false, true);
        if (empty($_POST['anyway']) && ($dups = AddBusiness::duplicates($pdo, $d))) throw new InvalidArgumentException('It may already be listed: check below, or add it anyway.');
        $id = AddBusiness::create($pdo, $d, 'admin', ['anyway' => !empty($_POST['anyway']), 'uid' => (int) ($me['id'] ?? 0)]);   // the one identity check (decisions/0164 §3.1)
        $look = false;
        if (IdentityJobs::ready($pdo)) { try { IdentityJobs::look($pdo, $id); $look = true; } catch (Throwable $x) { error_log('listing-add look: ' . $x->getMessage()); } }
        tv_crawler_flash([true, 'Added and live, unclaimed. ' . ($look ? 'The crawler is looking up its phone, website, email and hours now; what it confirms fills in here.' : 'Fill in what you know below.')
            . ($d['website'] !== '' ? ' Crawl its website (below) to read the rest.' : '')]);
        header('Location: /admin/listing-edit.php?id=' . $id . '&added=1', true, 303);
        exit;
    } catch (InvalidArgumentException $x) {
        tv_crawler_flash([false, $x->getMessage()]);
    }
}

tv_crawler_start('review', 'Add a listing', $pdo, 'A business you know of: start it with its name, category and town. It goes live unclaimed, nobody assigned. The crawler then finds its phone, website, email and hours for you.');
$v = fn (string $k, string $d = '') => tv_e((string) ($form[$k] ?? $d));
?>
<style>
  .la{max-width:40rem;margin-top:.8rem}
  .la label.l{display:block;font-size:.8rem;font-weight:600;margin:.65rem 0 .2rem}
  .la-in{width:100%;background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.45rem .65rem;font-size:.9rem}
  .la-h{font-size:.72rem;color:#8A7355;margin-top:.15rem}
  .la-b{font-size:.9rem;font-weight:700;border:1px solid #15803D;background:#15803D;color:#fff;border-radius:.6rem;padding:.55rem 1.1rem;cursor:pointer}
  .la-dup{background:#FFF8EA;border:1px solid #F3D9A4;border-radius:.7rem;padding:.6rem .8rem;font-size:.85rem;margin-top:.6rem}
  .la-card{background:#F7EFDC;border:1px solid #EADFC4;border-radius:.8rem;padding:.75rem .9rem}
</style>
<div class="la">
  <?php if ($dups): ?><div class="la-dup tv-bleed"><b>Already listed?</b>
    <?php foreach ($dups as $d0): ?><br><a class="underline" href="/listing/view.php?id=<?= (int) $d0['id'] ?>" data-peek-frame><?= tv_e($d0['name']) ?></a><?= $d0['city'] ? ', ' . tv_e($d0['city']) : '' ?> <span class="text-[#8A7355]">(<?= tv_e($d0['why']) ?>)</span><?php endforeach; ?></div><?php endif; ?>
  <form method="post" class="la-card tv-bleed mt-2">
    <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>">
    <label class="l" for="la-name">Business name</label><input class="la-in" id="la-name" name="name" required maxlength="120" value="<?= $v('name') ?>">
    <div data-cat-more data-max="<?= ListingCategories::MAX ?>"<?= tv_cat_staff_attrs($pdo) ?>>
      <label class="l" for="la-cat">Category</label>
      <div class="tv-cat-line"><select class="la-in" id="la-cat" name="category_id" data-cat-pick required><?= tv_cat_options($cats, (int) ($form['category_id'] ?? 0)) ?></select><?= ListingCategories::ready($pdo) ? tv_cat_add_button() : '' ?></div>
      <?= ListingCategories::ready($pdo) ? tv_cat_more_rows($cats, array_map('intval', (array) ($form['also_cat'] ?? [])), 'la-in') : '' ?>
      <div class="la-h">The main one shows on its card; + lists it under up to <?= ListingCategories::MAX ?> more.</div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 5rem;gap:.5rem">
      <div><label class="l" for="la-town">Town (or nearest)</label><input class="la-in" id="la-town" name="town" required maxlength="80" value="<?= $v('town') ?>"></div>
      <div><label class="l" for="la-state">State</label><input class="la-in" id="la-state" name="state" maxlength="2" value="<?= $v('state', 'AZ') ?>" style="text-transform:uppercase"></div>
    </div>
    <label class="l" for="la-addr">Street address <span class="text-[#8A7355] font-normal">(if you know it)</span></label><input class="la-in" id="la-addr" name="address" maxlength="160" value="<?= $v('address') ?>">
    <label class="l" for="la-pt">Map point <span class="text-[#8A7355] font-normal">(latitude, longitude, if you know it)</span></label><input class="la-in" id="la-pt" name="point" maxlength="40" value="<?= $v('point') ?>" placeholder="34.505,-109.36">
    <div class="la-h">Without either, it goes at the middle of its town until the crawler or someone fixes the pin.</div>
    <label class="l" for="la-phone">Phone <span class="text-[#8A7355] font-normal">(optional)</span></label><input class="la-in" id="la-phone" name="phone" maxlength="20" inputmode="tel" value="<?= $v('phone') ?>">
    <label class="l" for="la-web">Website or Facebook page <span class="text-[#8A7355] font-normal">(optional)</span></label><input class="la-in" id="la-web" name="website" maxlength="300" inputmode="url" value="<?= $v('website') ?>">
    <div class="la-h">Leave these blank and the crawler looks for them. A website it can read in full.</div>
    <?php if ($dups): ?><label class="text-sm mt-2 block"><input type="checkbox" name="anyway" value="1"> It's a different business: add it anyway</label><?php endif; ?>
    <div class="mt-3"><button class="la-b" type="submit">Add the listing</button></div>
  </form>
</div>
<script src="/js/cat-more.js?v=<?= (int) @filemtime(__DIR__ . '/../js/cat-more.js') ?>"></script>
<?php tv_crawler_end();
