/* js/stg-bar.js — the site manager (decisions/0159 §5; it was the staging bar, decisions/0145 Phase 5): on staging.trvgo.us,
 * for whoever came in from the live admin (Open staging). At the top of every page, in the admin command bar's look (0129):
 *   Releases ▾  what's on staging now, what's waiting, what's live and at which step; choosing one shows it here;
 *               Check for builds takes Claude's finished builds from git onto staging now (the site also looks every 10 min)
 *   Upload      a release zip goes straight onto staging and its checks run (the one uploader: target release_zip_bar,
 *               then the live site makes it a release); no separate Approve the plan or Put it on staging
 *   Changes     the pages it touches, to jump to and look at, its files and checks
 *   Note        pins what you see to this page (kept with the release)
 *   Publish ▾   Publish now, Schedule, the next step; Turn off and Roll back once it's live
 * Opening a release here is the look (the live site records it); Publish is the sign-off. Every action goes to the live site
 * (/api/stg-bar.php passes it on, signed) as you, with the release permissions you had when you came in. ◆ folds it. */
(function () {
  var mount = document.getElementById('tv-stg-bar');
  if (!mount) return;
  var KEY = 'tvStgRel', FOLD = 'tvStgFold';
  var get = function (k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
  var put = function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} };
  var tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
  var C = { sage: '#B9D8C6', sageLine: '#9CC3AE', orange: '#E07F3C', peach: '#F1B48C', ink: '#2B1D14', cream: '#FFFBF2', line: '#CBB98D', brown: '#92400E', ok: '#8FBCA8', bad: '#B91C1C' };

  // the bar sits over the page (z-index 1000) but under the site's own pop-ups (the Gallery, search, peek: 1370 and up)
  var css = document.createElement('style');
  css.textContent = '#tv-stg-bar{position:relative;z-index:1000;font:14px/1.35 system-ui,sans-serif;color:' + C.ink + '}'
    + '#tv-stg-bar .sm{display:flex;align-items:stretch;min-height:2.6rem;background:' + C.sage + ';border-bottom:1px solid ' + C.sageLine + ';box-shadow:0 6px 14px -12px rgba(0,0,0,.5)}'
    + '#tv-stg-bar .sm-fold{flex:0 0 2.6rem;border:0;background:' + C.orange + ';color:#fff;font-size:1.1rem;cursor:pointer}#tv-stg-bar .sm-fold:hover{background:#C96A28}'
    + '#tv-stg-bar .sm-l{box-sizing:border-box;flex:1 1 10rem;min-width:0;display:flex;flex-direction:column;justify-content:center;padding:.25rem .7rem}'
    + '#tv-stg-bar .sm-t{font:700 1rem ui-serif,Georgia,serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
    + '#tv-stg-bar .sm-s{font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#3E2B1F}'
    + '#tv-stg-bar .sm-dot{display:inline-block;width:.55rem;height:.55rem;border-radius:50%;margin-right:.35rem;vertical-align:0}'
    + '#tv-stg-bar .sm-r{position:relative;isolation:isolate;display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;gap:.35rem;padding:.3rem .6rem .3rem 2.1rem}'
    + '#tv-stg-bar .sm-r::before{content:"";position:absolute;inset:0;z-index:-1;background:' + C.peach + ';clip-path:polygon(1.5rem 0,100% 0,100% 100%,0 100%)}'
    + '#tv-stg-bar .sm-b{font:700 .85rem/1.2 system-ui,sans-serif;border:1.5px solid ' + C.orange + ';background:#fff;color:' + C.ink + ';border-radius:.3rem;padding:.32rem .65rem;cursor:pointer;text-decoration:none;white-space:nowrap}'
    + '#tv-stg-bar .sm-b.go{background:' + C.orange + ';color:#fff}#tv-stg-bar .sm-b[disabled]{opacity:.5;cursor:default}'
    + '#tv-stg-bar .sm-b[aria-busy=true]::before{content:"";display:inline-block;width:.7rem;height:.7rem;margin-right:.35rem;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;vertical-align:-1px;animation:smspin .8s linear infinite}'
    + '@keyframes smspin{to{transform:rotate(360deg)}}'
    + '#tv-stg-bar .sm-dd{position:relative}'
    + '#tv-stg-bar .sm-menu{position:absolute;right:0;top:calc(100% + .35rem);min-width:15rem;max-width:min(22rem,calc(100vw - 1rem));max-height:min(70vh,30rem);overflow:auto;background:' + C.cream + ';border:1px solid ' + C.line + ';border-radius:.7rem;box-shadow:0 14px 30px -12px rgba(0,0,0,.45);padding:.3rem;display:grid;z-index:2}'
    + '#tv-stg-bar .sm-menu button{display:block;width:100%;text-align:left;font:600 .9rem/1.3 system-ui,sans-serif;color:#3E2B1F;background:none;border:0;border-radius:.45rem;padding:.5rem .6rem;cursor:pointer}'
    + '#tv-stg-bar .sm-menu button:hover,#tv-stg-bar .sm-menu button[aria-current=true]{background:#F3EAD6}#tv-stg-bar .sm-menu .no{color:#991B1B}'
    + '#tv-stg-bar .sm-menu h5{margin:.4rem .6rem .15rem;font:700 .72rem system-ui,sans-serif;letter-spacing:.04em;text-transform:uppercase;color:#8A7355}'
    + '#tv-stg-bar .sm-menu small{display:block;font-weight:400;color:#8A7355}'
    + '#tv-stg-bar .sm-panel{background:' + C.cream + ';color:#3E2B1F;max-height:60vh;overflow:auto;padding:.7rem .9rem;border-bottom:3px solid ' + C.orange + '}'
    + '#tv-stg-bar .sm-panel h4{margin:.6rem 0 .25rem;font-size:.85rem;color:' + C.brown + '}#tv-stg-bar .sm-panel a{color:' + C.brown + '}'
    + '#tv-stg-bar .sm-panel ul{margin:0;padding-left:1.1rem}#tv-stg-bar .sm-panel textarea,#tv-stg-bar .sm-panel input{width:100%;box-sizing:border-box;font:16px system-ui,sans-serif;padding:.4rem;border:1px solid ' + C.line + ';border-radius:.4rem}'
    + '#tv-stg-bar .sm-panel .sm-b{margin:.5rem .35rem 0 0}'
    + '#tv-stg-bar .sm-msg{padding:.45rem .9rem;font-weight:600}'
    + '#tv-stg-bar .sm-tab{position:fixed;right:8px;bottom:8px;background:' + C.orange + ';color:#fff;border:0;border-radius:999px;padding:6px 12px;font:700 12px system-ui,sans-serif;box-shadow:0 1px 4px rgba(0,0,0,.3);z-index:1000}'
    + '@media (max-width:640px){#tv-stg-bar .sm{flex-wrap:wrap}#tv-stg-bar .sm-l{flex-basis:calc(100% - 2.6rem)}#tv-stg-bar .sm-r{flex:1 1 100%;justify-content:flex-start;padding-left:.6rem}#tv-stg-bar .sm-r::before{clip-path:none}#tv-stg-bar .sm-menu{right:auto;left:0}}';
  document.head.appendChild(css);

  var state = null, open = '', menu = '', msg = null;
  function el(tag, attrs, kids) {
    var x = document.createElement(tag);
    for (var k in (attrs || {})) { if (k === 'text') x.textContent = attrs[k]; else if (k === 'on') x.addEventListener('click', attrs[k]); else x.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c) x.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return x;
  }
  function api(method, body) {
    var o = { method: method, credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-Tv-Stg-Bar': '1' } };
    if (body) o.body = JSON.stringify(window.tvSafe ? tvSafe(body) : body);
    var url = '/api/stg-bar.php' + (method === 'GET' ? '?rel=' + encodeURIComponent(get(KEY) || '') : '');
    return fetch(url, o).then(function (r) { return r.json().catch(function () { return { ok: false, error: { message: 'Staging didn\'t answer clearly. Try again.' } }; }); }, function () { return { ok: false, error: { message: 'The connection dropped. Try again.' } }; })
      .then(function (j) { if (!j.ok) throw new Error((j.error && j.error.message) || 'Something went wrong. Try again; still stuck? Write to support@traversence.com.'); return j; });
  }
  function busy(btn, on) { if (!btn) return; if (on) { btn.setAttribute('aria-busy', 'true'); btn.disabled = true; } else { btn.removeAttribute('aria-busy'); btn.disabled = false; } }
  function say(text, bad, btn) { msg = [text, !!bad]; if (window.TvAsk && TvAsk.say && btn && btn.isConnected) TvAsk.say(text, { anchor: btn, bad: !!bad }); }
  function load() { return api('GET').then(function (j) { state = j; if (j.release) put(KEY, String(j.release.id)); draw(); }, function (e) { msg = [e.message, true]; draw(); }); }
  function act(btn, action, args) {
    busy(btn, true);
    return api('POST', { action: action, rel: state && state.release ? state.release.id : 0, args: Object.assign({ tz: tz, page: location.pathname + location.search }, args || {}) })
      .then(function (j) { open = action === 'note' ? 'notes' : ''; menu = ''; say(j.message || 'Done.', false, btn); if (j.id) put(KEY, String(j.id)); return load(); },
            function (e) { busy(btn, false); say(e.message, true, btn); draw(); });
  }

  // Upload: the one uploader (js/tv-upload.js, loaded when first needed), then the live site makes it a release, on staging
  function withUploader() {
    if (window.TvUpload) return Promise.resolve();
    return new Promise(function (ok, no) { var s = document.createElement('script'); s.src = '/js/tv-upload.js'; s.onload = ok; s.onerror = function () { no(new Error('The uploader didn\'t load. Reload the page and try again.')); }; document.head.appendChild(s); });
  }
  function upload(btn, file) {
    if (!/\.zip$/i.test(file.name || '')) { say('Choose the release\'s .zip file.', true, btn); draw(); return; }
    busy(btn, true); msg = ['Uploading ' + file.name + '…', false]; open = ''; drawMsg();
    withUploader().then(function () { return TvUpload.send([file], { target: 'release_zip_bar', ctx: { tz: tz }, el: mount }); })
      .then(function (res) {
        var r = (res && res[0]) || {}, got = r.result || r;
        if (r.ok === false || r.error || !got.inbox) throw new Error((r.error && (r.error.message || r.error)) || 'The upload didn\'t go through. Try again.');
        msg = ['Uploaded: making it a release and putting it on staging (its checks run now; a minute or two)…', false]; drawMsg();
        return act(btn, 'upload', { inbox: got.inbox, name: got.name || file.name });
      })
      .catch(function (e) { busy(btn, false); say(e.message, true, btn); draw(); });
  }

  function drawMsg() {
    var old = mount.querySelector('.sm-msg'); if (old) old.remove();
    if (!msg) return;
    var m = el('div', { class: 'sm-msg', role: 'status', style: 'background:' + (msg[1] ? C.bad : C.ok) + ';color:' + (msg[1] ? C.cream : '#1F2E27') }, [(msg[1] ? 'Error: ' : (/…$/.test(msg[0]) ? '' : 'Success: ')) + msg[0]]);
    m.appendChild(el('button', { type: 'button', class: 'sm-b', style: 'float:right;padding:0 .4rem;margin-left:.5rem', 'aria-label': 'Close', text: '×', on: function () { msg = null; drawMsg(); } }));
    var bar = mount.querySelector('.sm'); if (bar && bar.nextSibling) mount.insertBefore(m, bar.nextSibling); else mount.appendChild(m);
  }

  function dd(name, label, items) {   // a drop-down like the command bar's Shortcuts: [label, onclick, class, small]
    var wrap = el('div', { class: 'sm-dd' });
    wrap.appendChild(el('button', { type: 'button', class: 'sm-b', 'aria-haspopup': 'true', 'aria-expanded': String(menu === name), text: label + ' ▾', on: function () { menu = menu === name ? '' : name; draw(); } }));
    if (menu === name) {
      var m = el('div', { class: 'sm-menu', role: 'menu' });
      items.forEach(function (it) {
        if (typeof it === 'string') { m.appendChild(el('h5', { text: it })); return; }
        var b = el('button', { type: 'button', role: 'menuitem', class: it[2] || '', on: it[1] }, [it[0]]);
        if (it[3]) b.appendChild(el('small', { text: it[3] }));
        if (it[4]) b.setAttribute('aria-current', 'true');
        m.appendChild(b);
      });
      wrap.appendChild(m);
    }
    return wrap;
  }

  function draw() {
    mount.innerHTML = '';
    if (get(FOLD) === '1') { mount.appendChild(el('button', { class: 'sm-tab', type: 'button', text: 'Site manager ▾', 'aria-label': 'Open the site manager', on: function () { put(FOLD, ''); draw(); } })); return; }
    var r = state && state.release, list = (state && state.releases) || [];
    var bar = el('div', { class: 'sm', role: 'region', 'aria-label': 'Site manager' });
    bar.appendChild(el('button', { type: 'button', class: 'sm-fold', title: 'Fold the site manager', 'aria-label': 'Fold the site manager', text: '◆', on: function () { put(FOLD, '1'); draw(); } }));
    var l = el('div', { class: 'sm-l' });
    var t = el('div', { class: 'sm-t' });
    if (r) { t.appendChild(el('span', { class: 'sm-dot', style: 'background:' + (r.tone === 'bad' ? C.bad : r.tone === 'ok' ? '#2F7D5B' : '#8A7355') })); t.appendChild(document.createTextNode('#' + r.id + ' ' + r.title)); t.title = r.title; }
    else t.textContent = 'Site manager · staging';
    l.appendChild(t);
    l.appendChild(el('div', { class: 'sm-s', title: r ? r.line : '', text: r ? r.state_name + (r.state === 'live' && r.switch ? ', step ' + r.step + ' of 3' : '') + ': ' + r.line
      : (state ? (list.length ? 'No release chosen: Releases ▾ to choose one, or Upload a zip.' : 'No release on staging now: you\'re looking at a copy of live. Upload a zip to try one.') : 'Loading…') }));
    bar.appendChild(l);

    var right = el('div', { class: 'sm-r' });
    // Releases ▾
    var items = [], groups = { staging: 'On staging now', waiting: 'Waiting', live: 'Live' };
    ['staging', 'waiting', 'live'].forEach(function (g) {
      var xs = list.filter(function (x) { return x.group === g; }); if (!xs.length) return;
      items.push(groups[g]);
      xs.forEach(function (x) { items.push(['#' + x.id + ' ' + x.title, function () { put(KEY, String(x.id)); menu = ''; msg = null; load(); }, '', x.state + (x.step ? ', ' + x.step : ''), r && r.id === x.id]); });
    });
    if (!items.length) items.push(['No releases yet', function () { menu = ''; draw(); }, '', 'Check for builds, or Upload a zip.']);
    if (state && state.can_upload) items.push(['Check for builds', function () {   // Claude's builds wait in git (Phase 6); the site also looks every 10 minutes
      menu = ''; put(KEY, ''); draw(); act(mount.querySelector('.sm-dd > .sm-b'), 'pull');
    }, '', 'Claude\'s finished builds, from git, straight onto staging']);
    right.appendChild(dd('rel', 'Releases', items));
    // Upload
    if (state && state.can_upload) {
      var up = el('button', { type: 'button', class: 'sm-b', text: 'Upload', title: 'A release zip goes straight onto staging, and its checks run' });
      var inp = el('input', { type: 'file', accept: '.zip,application/zip', hidden: '', 'data-art': 'off', 'aria-label': 'The release zip' });
      inp.addEventListener('change', function () { var f = inp.files && inp.files[0]; inp.value = ''; if (f) upload(up, f); });
      // a release zip is the site's, not a Gallery item: the device's own file picker (data-art off); any open view closes first
      up.addEventListener('click', function () { open = ''; menu = ''; Array.prototype.forEach.call(mount.querySelectorAll('.sm-panel,.sm-menu'), function (x) { x.remove(); }); inp.click(); });
      right.appendChild(up); right.appendChild(inp);
    }
    if (r) {
      right.appendChild(el('button', { type: 'button', class: 'sm-b', 'aria-expanded': String(open === 'changes'), text: 'Changes', on: function () { open = open === 'changes' ? '' : 'changes'; menu = ''; draw(); } }));
      right.appendChild(el('button', { type: 'button', class: 'sm-b', 'aria-expanded': String(open === 'notes'), text: 'Note' + (r.notes.length ? ' (' + r.notes.length + ')' : ''), on: function () { open = open === 'notes' ? '' : 'notes'; menu = ''; draw(); } }));
      if (r.acts.length) {
        var pubs = r.acts.map(function (a) {
          return [a[1], function () {
            menu = '';
            if (a[0] === 'schedule') { open = 'schedule'; draw(); return; }
            if (a[2]) { open = 'confirm:' + a[0] + ':' + a[2] + ':' + a[1]; draw(); return; }
            act(right.querySelector('.sm-dd:last-of-type > .sm-b'), a[0]);
          }, a[2] === 2 ? 'no' : ''];
        });
        right.appendChild(dd('pub', 'Publish', pubs));
      }
    }
    right.appendChild(el('a', { class: 'sm-b', href: r ? r.admin : 'https://traversence.com/admin/config/releases', text: 'Live admin ↗' }));
    bar.appendChild(right);
    mount.appendChild(bar);

    var panel = null;
    if (r && open === 'changes') {
      panel = el('div', { class: 'sm-panel' });
      panel.appendChild(el('p', { style: 'margin:0', text: r.line }));
      if (r.why) { panel.appendChild(el('h4', { text: 'What it changes' })); panel.appendChild(el('p', { style: 'margin:0;white-space:pre-wrap', text: r.why })); }
      panel.appendChild(el('h4', { text: 'Pages to look at (here, on staging)' }));
      panel.appendChild(el('ul', {}, r.pages.map(function (p) { return el('li', {}, [el('a', { href: p, text: p })]); })));
      panel.appendChild(el('h4', { text: 'Its files (' + r.files.length + ')' + (r.switch ? ' · switch ' + r.switch : ' · no switch: everyone at once') }));
      panel.appendChild(el('ul', { style: 'font:12px ui-monospace,monospace' }, r.files.slice(0, 60).map(function (f) { return el('li', { text: f }); })));
      if (r.checks.length) { panel.appendChild(el('h4', { text: 'Its checks' })); panel.appendChild(el('ul', {}, r.checks.map(function (c) { return el('li', { text: (c.ok === false ? '✗ ' : c.ok ? '✓ ' : '· ') + c.name + ': ' + c.detail }); }))); }
      if (r.stale) panel.appendChild(el('p', { style: 'color:' + C.bad + ';font-weight:600', text: 'Staging was refreshed from live since this release went on: Publish ▾ → Put it on staging again before publishing.' }));
    }
    if (r && open === 'notes') {
      panel = el('div', { class: 'sm-panel' });
      var ta = el('textarea', { rows: '3', 'aria-label': 'What you saw on this page', placeholder: 'What you saw on this page (' + location.pathname + ')', 'data-spell': '' });
      panel.appendChild(ta);
      panel.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Save the note', on: function (e) { if (!ta.value.trim()) { say('Write what you saw first.', true, e.currentTarget); drawMsg(); return; } act(e.currentTarget, 'note', { text: ta.value }); } }));
      if (r.notes.length) { panel.appendChild(el('h4', { text: 'Notes so far' })); panel.appendChild(el('ul', {}, r.notes.map(function (n) { return el('li', { text: n.msg }); }))); }
      setTimeout(function () { ta.focus(); }, 30);
    }
    if (r && open === 'schedule') {
      panel = el('div', { class: 'sm-panel' });
      var when = el('input', { type: 'datetime-local', 'aria-label': 'When it goes live' });
      panel.appendChild(el('p', { style: 'margin:0 0 6px', text: 'When should it go live? (your time zone: ' + (tz || 'this device\'s') + ')' + (r.state === 'staged' ? ' Scheduling it is its sign-off.' : '') }));
      panel.appendChild(when);
      panel.appendChild(el('button', { type: 'button', class: 'sm-b go', text: 'Schedule it', on: function (e) { if (!when.value) { say('Choose the date and time first.', true, e.currentTarget); drawMsg(); return; } act(e.currentTarget, 'schedule', { at: when.value }); } }));
      panel.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Cancel', on: function () { open = ''; draw(); } }));
    }
    if (r && open.indexOf('confirm:') === 0) {
      var p = open.split(':'), what = p[1], danger = p[2] === '2', label = p.slice(3).join(':');
      var ask = { publish: 'Publish it to the live site now?' + (r.state === 'staged' ? ' That signs it off.' : '') + (r.switch ? ' It goes to staff and test accounts first.' : ' It has no switch: everyone gets it at once.'),
        next: r.step === 1 ? 'Turn it on for a share of members as well?' : 'Turn it on for everyone?', off: 'Turn it off for everyone, now? Its files stay; Roll back takes them out.',
        back: 'Put the previous copy of every file back on the live site, now?', withdraw: 'Withdraw it? It won\'t go live.' }[what] || label + '?';
      panel = el('div', { class: 'sm-panel' });
      panel.appendChild(el('p', { style: 'margin:0', text: ask }));
      panel.appendChild(el('button', { type: 'button', class: 'sm-b go', style: danger ? 'background:' + C.bad + ';border-color:' + C.bad : '', text: label, on: function (e) { act(e.currentTarget, what); } }));
      panel.appendChild(el('button', { type: 'button', class: 'sm-b', text: 'Cancel', on: function () { open = ''; draw(); } }));
    }
    if (panel) mount.appendChild(panel);
    drawMsg();
  }
  document.addEventListener('click', function (e) { if (menu && e.target.isConnected && !mount.contains(e.target)) { menu = ''; draw(); } });   // (a button the bar just redrew isn't outside it)
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && (menu || open)) { menu = ''; open = ''; draw(); } });
  draw();
  load();
})();
