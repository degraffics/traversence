-- The registrant's contact verification, followed until it's resolved (Jason, 2026-11-17: "the verification process
-- follows after the purchase … we need a worker to follow and communicate this until it is resolved"). Name.com emails
-- the registrant (ICANN's rule); unconfirmed after about 15 days, the domain stops resolving. verify_state: '' (from
-- before), 'waiting', 'verified'. Adds columns only; safe to run twice. account_domains is in the main database
-- (2027-03-10_account_domains_wallet).
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE account_domains ADD COLUMN verify_state VARCHAR(10) NOT NULL DEFAULT ''''', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'account_domains' AND COLUMN_NAME = 'verify_state');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE account_domains ADD COLUMN verify_id INT UNSIGNED DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'account_domains' AND COLUMN_NAME = 'verify_id');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE account_domains ADD COLUMN verify_by DATETIME DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'account_domains' AND COLUMN_NAME = 'verify_by');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE account_domains ADD COLUMN verify_email VARCHAR(190) NOT NULL DEFAULT ''''', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'account_domains' AND COLUMN_NAME = 'verify_email');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE account_domains ADD COLUMN verify_told TINYINT UNSIGNED NOT NULL DEFAULT 0', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'account_domains' AND COLUMN_NAME = 'verify_told');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE account_domains ADD COLUMN verify_seen_at DATETIME DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'account_domains' AND COLUMN_NAME = 'verify_seen_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
