<?php
// app/lib/GoogleAuth.php — Continue with Google (decisions/0085).
//
// Google's sign-in (OAuth 2.0 / OpenID Connect, authorization code flow), asking only for openid, email and profile:
// we receive the person's Google ID ("sub"), email address (only when Google has verified it) and name. Never their
// Google password, contacts or anything else.
//
//   start()   the address to send the person to, with a one-time state kept in their session
//   finishIdToken()  back from Google (by way of the page, decisions/0085 fix): the state, Google's signature on the
//             ID token (its published keys), issuer, audience, expiry, nonce and confirmed email checked
//   finish()  the code flow (kept for a host without the firewall): the code exchanged server to server, same checks
//   signIn()  an account with that Google ID, or with that email: signed in (and linked). An account with that email
//             whose email was never confirmed has its password cleared and its sessions ended first, so a stranger who
//             registered someone else's address can't keep a way in. Otherwise the profile waits in the session for
//             the person to finish signing up (18+, verification, privacy choices, the terms), as everyone does.
//   create()  that new account: email confirmed (Google confirmed it), no password (Forgot password sets one).
//
// .env: GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET. Google's client lists https://traversence.com/api/auth/google.php (and
// the www. form) as its redirect.
declare(strict_types=1);

final class GoogleAuth
{
    private const AUTH = 'https://accounts.google.com/o/oauth2/v2/auth';
    private const TOKEN = 'https://oauth2.googleapis.com/token';
    private const STATE_TTL = 900;     // 15 minutes to choose an account at Google
    private const PENDING_TTL = 3600;  // an hour to finish signing up

    private static ?bool $on = null;

    /** Set up in .env, and the database update run (2026-11-21_google_sign_in.sql): until both, no button shows. */
    public static function enabled(): bool
    {
        if (self::$on !== null) return self::$on;
        // connect first: the site reads .env when it first connects to the database, so the keys aren't there before
        try { $pdo = Database::connection(); } catch (Throwable) { return self::$on = false; }
        if (trim((string) getenv('GOOGLE_CLIENT_ID')) === '' || trim((string) getenv('GOOGLE_CLIENT_SECRET')) === '') return self::$on = false;
        try { $pdo->query('SELECT google_sub FROM users LIMIT 0'); return self::$on = true; } catch (Throwable) { return self::$on = false; }
    }

    /** The redirect address, on the host the person is on (traversence.com or www.), else the site's own. */
    public static function redirectUri(): string
    {
        $app = rtrim((string) (getenv('APP_URL') ?: ''), '/');
        $appHost = (string) parse_url($app, PHP_URL_HOST);
        $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $base = ($appHost !== '' && ($host === $appHost || $host === 'www.' . $appHost || 'www.' . $host === $appHost))
            ? (parse_url($app, PHP_URL_SCHEME) ?: 'https') . '://' . $host : $app;
        return $base . '/api/auth/google.php';
    }

    /** Where to send the person: Google's account chooser. $next: a path on this site to come back to. */
    public static function start(string $next = '', bool $link = false): string
    {
        $state = bin2hex(random_bytes(16)); $nonce = bin2hex(random_bytes(16));
        // $link: Connect from Privacy (decisions/0090): link this Google account to the signed-in person, whatever its email
        $_SESSION['tv_google_state'] = ['state' => $state, 'nonce' => $nonce, 'next' => self::safeNext($next), 'at' => time(), 'link' => $link ? (int) ($_SESSION['user_id'] ?? 0) : 0];
        // Google's signed ID token straight back, after "#" (the way this kind of answer always comes). The browser never
        // sends what's after "#" to the server: Google's answers carry links (iss=https://accounts.google.com, the
        // granted scopes), and Bluehost's firewall (ModSecurity) refuses any request carrying a link to another site.
        // /api/auth/google.php reads it in the page and posts on only the token and state; the token's signature is
        // checked against Google's published keys (verifyIdToken), because it came by way of the browser.
        return self::AUTH . '?' . http_build_query([
            'client_id' => trim((string) getenv('GOOGLE_CLIENT_ID')), 'redirect_uri' => self::redirectUri(), 'response_type' => 'id_token',
            'scope' => 'openid email profile', 'state' => $state, 'nonce' => $nonce, 'prompt' => 'select_account',
        ]);
    }

    /**
     * Back from Google with its ID token (by way of the page). Checks the state, Google's signature, the issuer, the
     * audience, the expiry, the nonce and the confirmed email. Returns ['sub', 'email', 'name', 'next'].
     * $certs: Google's public certificates [kid => PEM] (tests pass their own).
     */
    public static function finishIdToken(string $idt, string $state, ?array $certs = null): array
    {
        $S = $_SESSION['tv_google_state'] ?? null;
        unset($_SESSION['tv_google_state']);   // one use
        if (!$S || $state === '' || !hash_equals((string) $S['state'], $state) || time() - (int) $S['at'] > self::STATE_TTL) {
            throw new RuntimeException('That sign-in link expired. Try Continue with Google again.');
        }
        $parts = explode('.', $idt);
        if (count($parts) !== 3) throw new RuntimeException('Google didn\'t send a sign-in. Try again.');
        $head = json_decode((string) self::b64url($parts[0]), true);
        $claims = json_decode((string) self::b64url($parts[1]), true);
        $sig = self::b64url($parts[2]);
        if (!is_array($head) || !is_array($claims) || $sig === false || ($head['alg'] ?? '') !== 'RS256') throw new RuntimeException('Google\'s answer couldn\'t be read.');
        $certs ??= self::googleCerts();
        $pem = $certs[(string) ($head['kid'] ?? '')] ?? null;
        if (!$pem || openssl_verify($parts[0] . '.' . $parts[1], $sig, $pem, OPENSSL_ALGO_SHA256) !== 1) throw new RuntimeException('That sign-in couldn\'t be confirmed as Google\'s. Try again.');
        if (!isset($S['nonce']) || !hash_equals((string) $S['nonce'], (string) ($claims['nonce'] ?? ''))) throw new RuntimeException('That sign-in was for another attempt. Try again.');
        return self::claims($claims) + ['next' => (string) $S['next'], 'link' => (int) ($S['link'] ?? 0)];
    }

    /** Google's public certificates for its ID tokens [kid => PEM], kept for an hour. */
    public static function googleCerts(): array
    {
        if (($fx = getenv('GOOGLE_CERTS_FIXTURE')) && is_file($fx)) return json_decode((string) file_get_contents($fx), true) ?: [];   // local tests only
        $cache = dirname(__DIR__) . '/storage/google-certs.json';
        if (is_file($cache) && filemtime($cache) > time() - 3600 && is_array($c = json_decode((string) file_get_contents($cache), true)) && $c) return $c;
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold('https://www.googleapis.com/oauth2/v1/certs', 'Google sign-in keys')) !== null) throw new RuntimeException($w . ' Sign in with your email on staging.');   // social sign-in is off on staging
        $ch = curl_init('https://www.googleapis.com/oauth2/v1/certs');
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15]);
        $body = curl_exec($ch); curl_close($ch);
        $c = json_decode((string) $body, true);
        if (!is_array($c) || !$c) throw new RuntimeException('Google\'s keys couldn\'t be fetched just now. Try again in a minute.');
        @file_put_contents($cache, json_encode($c));
        return $c;
    }

    /** The checks every Google ID token must pass; the profile it gives. */
    private static function claims(array $claims): array
    {
        Database::connection();   // the .env keys are read on the first connection: the client ID is compared below
        if (!in_array($claims['iss'] ?? '', ['accounts.google.com', 'https://accounts.google.com'], true)) throw new RuntimeException('That sign-in didn\'t come from Google.');
        if (($claims['aud'] ?? '') !== trim((string) getenv('GOOGLE_CLIENT_ID'))) throw new RuntimeException('That sign-in was for another site.');
        if ((int) ($claims['exp'] ?? 0) < time() - 60) throw new RuntimeException('That sign-in expired. Try again.');
        $email = strtolower(trim((string) ($claims['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($claims['email_verified'] ?? false, [true, 'true'], true)) {
            throw new RuntimeException('Google didn\'t share a confirmed email address for that account, so it can\'t be used here.');
        }
        $sub = (string) ($claims['sub'] ?? '');
        if ($sub === '' || strlen($sub) > 64) throw new RuntimeException('Google\'s answer couldn\'t be read.');
        return ['sub' => $sub, 'email' => $email, 'name' => mb_substr(trim((string) ($claims['name'] ?? '')), 0, 80)];
    }

    /**
     * Back from Google. Returns ['sub', 'email', 'name', 'next']. Throws RuntimeException with a plain reason.
     * $post: how to POST (tests pass their own); by default an HTTPS POST to Google.
     */
    public static function finish(string $code, string $state, ?callable $post = null): array
    {
        $S = $_SESSION['tv_google_state'] ?? null;
        unset($_SESSION['tv_google_state']);   // one use
        if (!$S || $state === '' || !hash_equals((string) $S['state'], $state) || time() - (int) $S['at'] > self::STATE_TTL) {
            throw new RuntimeException('That sign-in link expired. Try Continue with Google again.');
        }
        if ($code === '') throw new RuntimeException('Google didn\'t send a sign-in code. Try again.');
        $post ??= [self::class, 'httpPost'];
        $r = $post(self::TOKEN, [
            'code' => $code, 'client_id' => trim((string) getenv('GOOGLE_CLIENT_ID')), 'client_secret' => trim((string) getenv('GOOGLE_CLIENT_SECRET')),
            'redirect_uri' => self::redirectUri(), 'grant_type' => 'authorization_code',
        ]);
        $idt = (string) ($r['id_token'] ?? '');
        if ($idt === '') throw new RuntimeException('Google didn\'t confirm the sign-in' . (!empty($r['error']) ? ' (' . $r['error'] . ')' : '') . '.');
        // The token came straight from Google over HTTPS in exchange for our secret, so its claims are Google's
        // (Google's guidance: no signature check is needed for a token received this way). Its claims are still checked.
        $parts = explode('.', $idt);
        $claims = json_decode((string) self::b64url($parts[1] ?? ''), true);
        if (!is_array($claims)) throw new RuntimeException('Google\'s answer couldn\'t be read.');
        return self::claims($claims) + ['next' => (string) $S['next'], 'link' => (int) ($S['link'] ?? 0)];
    }

    /**
     * Signs in the account for this Google profile. Returns 'signed_in', or 'new' (the profile waits in the session for
     * the person to finish signing up). Throws RuntimeException for an account whose access is revoked.
     */
    public static function signIn(PDO $pdo, array $p): string
    {
        $st = $pdo->prepare('SELECT id, email, is_suspended, session_version, email_verified_at, google_sub FROM users WHERE google_sub = ? LIMIT 1');
        $st->execute([$p['sub']]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if (!$u) {
            $st = $pdo->prepare('SELECT id, email, is_suspended, session_version, email_verified_at, google_sub FROM users WHERE email = ? LIMIT 1');
            $st->execute([$p['email']]);
            $u = $st->fetch(PDO::FETCH_ASSOC);
            if ($u && $u['google_sub'] !== null && $u['google_sub'] !== '' && $u['google_sub'] !== $p['sub']) {
                throw new RuntimeException('That email is already linked to a different Google account. Sign in with your password instead.');
            }
            if ($u) {
                // the same person: link it. An address that was never confirmed may have been registered by someone
                // else: their password is cleared and every session on it ended before the owner gets in.
                if ($u['email_verified_at'] === null) {
                    $pdo->prepare('UPDATE users SET password_hash = ?, email_verified_at = NOW(), session_version = session_version + 1, updated_at = NOW() WHERE id = ?')
                        ->execute([password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), (int) $u['id']]);
                    $u['session_version'] = (int) $u['session_version'] + 1;
                }
                $pdo->prepare('UPDATE users SET google_sub = ?, updated_at = NOW() WHERE id = ?')->execute([$p['sub'], (int) $u['id']]);
            }
        }
        if (!$u) {
            $_SESSION['tv_google_pending'] = ['sub' => $p['sub'], 'email' => $p['email'], 'name' => $p['name'], 'at' => time(), 'next' => $p['next'] ?? ''];
            return 'new';
        }
        if ((int) $u['is_suspended'] === 1) {
            throw new RuntimeException('Access to this account is revoked for now. We emailed you what happened, how to recover, and a link to ask for a review; to get that link again, go to /user/notice.php.');   // decisions/0079
        }
        if (self::closingHold($pdo, (int) $u['id'])) return 'closing';
        self::session((int) $u['id'], (int) $u['session_version']);
        return 'signed_in';
    }

    /** A closing account (decisions/0091) isn't signed in: it's held for /user/restore-account.php (Restore or Keep closed). */
    private static function closingHold(PDO $pdo, int $id): bool
    {
        if (!is_file(__DIR__ . '/AccountDeletion.php')) return false;
        require_once __DIR__ . '/AccountDeletion.php';
        if (!AccountDeletion::ready($pdo) || !AccountDeletion::closing($pdo, $id)) return false;
        AccountDeletion::holdForRestore($id);
        return true;
    }

    /** The profile waiting to finish signing up, or null. */
    public static function pending(): ?array
    {
        $p = $_SESSION['tv_google_pending'] ?? null;
        if (!$p || time() - (int) $p['at'] > self::PENDING_TTL) { unset($_SESSION['tv_google_pending']); return null; }
        return $p;
    }

    /** Creates the account for the waiting profile and signs it in. Returns the new user id. */
    public static function create(PDO $pdo, ?string $displayName): int
    {
        $p = self::pending();
        if (!$p) throw new RuntimeException('That sign-up expired. Try Continue with Google again.');
        $st = $pdo->prepare('SELECT id FROM users WHERE email = ? OR google_sub = ? LIMIT 1');
        $st->execute([$p['email'], $p['sub']]);
        if ($st->fetchColumn()) { unset($_SESSION['tv_google_pending']); throw new RuntimeException('There\'s already an account for that email. Use Continue with Google on the sign-in page.'); }
        $name = trim((string) $displayName) !== '' ? mb_substr(trim((string) $displayName), 0, 80) : ($p['name'] !== '' ? $p['name'] : null);
        $pdo->prepare('INSERT INTO users (email, password_hash, display_name, email_verified_at, google_sub, created_at, updated_at) VALUES (?, ?, ?, NOW(), ?, NOW(), NOW())')
            ->execute([$p['email'], password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), $name, $p['sub']]);
        $id = (int) $pdo->lastInsertId();
        require_once __DIR__ . '/Acceptance.php'; Acceptance::signup($pdo, $id);   // the Terms shown when finishing sign-up (decisions/0142 §2)
        unset($_SESSION['tv_google_pending']);
        $v = $pdo->prepare('SELECT session_version FROM users WHERE id = ?'); $v->execute([$id]);
        self::session($id, (int) $v->fetchColumn());
        return $id;
    }

    /** A path on this site, or ''. */
    public static function safeNext(string $n): string
    {
        return preg_match('#^/(?!/)[^\s\\\\]*$#', $n) ? $n : '';
    }

    private static function session(int $id, int $version): void
    {
        session_regenerate_id(true);   // a new session id across the sign-in, as Auth::attemptLogin does
        $_SESSION['user_id'] = $id;
        $_SESSION['logged_in_at'] = time();
        $_SESSION['session_version'] = $version;
        try { require_once __DIR__ . '/SignInLinks.php'; SignInLinks::afterSignIn(Database::connection(), $id); } catch (Throwable) {}   // "I already have an account": link the waiting sign-in
    }

    private static function b64url(string $s): string|false
    {
        return base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
    }

    /** POST a form to Google; the JSON answer, or ['error' => …]. */
    public static function httpPost(string $url, array $fields): array
    {
        if (($fx = getenv('GOOGLE_TOKEN_FIXTURE')) && is_file($fx)) return json_decode((string) file_get_contents($fx), true) ?: [];   // local tests only
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold($url, 'Google sign-in')) !== null) return ['error' => $w . ' Sign in with your email on staging.'];   // social sign-in is off on staging
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($fields), CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
        $body = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($body === false) return ['error' => 'no answer from Google: ' . $err];
        $j = json_decode((string) $body, true);
        return is_array($j) ? $j : ['error' => 'unreadable answer from Google'];
    }
}
