<?php
// app/lib/Aws.php — the site's AWS account (decisions/0108): S3 storage and Textract, signed requests with the
// restricted traversence-site key (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, S3_BUCKET in .env).
// Plain HTTPS with Signature Version 4 (no Composer on Bluehost).
declare(strict_types=1);

final class Aws
{
    private static function env(string $k): string { return trim((string) (getenv($k) ?: '')); }

    public static function on(): bool { return self::env('AWS_ACCESS_KEY_ID') !== '' && self::env('AWS_SECRET_ACCESS_KEY') !== '' && self::env('AWS_REGION') !== ''; }
    public static function bucket(): string { return self::env('S3_BUCKET'); }
    public static function region(): string { return self::env('AWS_REGION'); }

    /**
     * A signed request. $host e.g. "bucket.s3.us-east-2.amazonaws.com"; $service "s3" or "textract".
     * Returns [http code, body].
     */
    public static function request(string $method, string $service, string $host, string $path = '/', string $body = '', array $headers = []): array
    {
        $key = self::env('AWS_ACCESS_KEY_ID'); $secret = self::env('AWS_SECRET_ACCESS_KEY'); $region = self::region();
        $now = gmdate('Ymd\THis\Z');
        $hash = hash('sha256', $body);
        $h = array_change_key_case($headers + ['host' => $host, 'x-amz-date' => $now, 'x-amz-content-sha256' => $hash], CASE_LOWER);
        $h['authorization'] = self::authorization($method, $path, '', $h, $hash, $key, $secret, $region, $service, $now);
        $out = []; foreach ($h as $k2 => $v) if ($k2 !== 'host') $out[] = $k2 . ': ' . $v;
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold('https://' . $host . $path, 'Amazon ' . $service . ' ' . $method)) !== null) return [0, (string) json_encode(['message' => $w])];   // Textract is paid: held on staging; the store is allowed
        $ch = curl_init('https://' . $host . $path);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => $out,
            CURLOPT_NOBODY => $method === 'HEAD'] + ($body !== '' ? [CURLOPT_POSTFIELDS => $body] : []));
        $res = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return [$code, is_string($res) ? $res : ''];
    }

    /** The Signature Version 4 Authorization header for a request (its headers in $h, lower-case names). */
    public static function authorization(string $method, string $path, string $query, array $h, string $payloadHash, string $key, string $secret, string $region, string $service, string $now): string
    {
        ksort($h);
        $canonHeaders = ''; foreach ($h as $k => $v) $canonHeaders .= $k . ':' . trim((string) $v) . "\n";
        $signed = implode(';', array_keys($h));
        $canon = $method . "\n" . $path . "\n" . $query . "\n" . $canonHeaders . "\n" . $signed . "\n" . $payloadHash;
        $day = substr($now, 0, 8); $scope = "$day/$region/$service/aws4_request";
        $toSign = "AWS4-HMAC-SHA256\n$now\n$scope\n" . hash('sha256', $canon);
        $k = hash_hmac('sha256', 'aws4_request', hash_hmac('sha256', $service, hash_hmac('sha256', $region, hash_hmac('sha256', $day, 'AWS4' . $secret, true), true), true), true);
        return "AWS4-HMAC-SHA256 Credential=$key/$scope, SignedHeaders=$signed, Signature=" . hash_hmac('sha256', $toSign, $k);
    }

    /** Can the site reach its bucket with its key? [ok, plain words]. */
    public static function checkBucket(): array
    {
        $other = trim((string) (getenv('S3_ENDPOINT') ?: '')) !== '';   // an S3-compatible store with its own key (decisions/0122, 0151)
        if ($other) { require_once __DIR__ . '/S3.php'; if (!S3::on()) return [false, 'Not connected: S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY and S3_BUCKET'];
            [$code] = S3::call('HEAD', '', [], '', [], 10);
            $host = (string) parse_url((string) getenv('S3_ENDPOINT'), PHP_URL_HOST);
            return match (true) {
                $code === 200 => [true, 'Connected: ' . self::bucket() . (str_contains($host, 'r2.cloudflarestorage.com') ? ' (Cloudflare R2)' : ' (' . $host . ')')],
                $code === 403 => [false, 'The key can\'t reach ' . self::bucket() . ': check S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY'],
                $code === 404 => [false, 'No bucket called ' . self::bucket() . ' at ' . $host],
                $code === 0 => [false, 'Couldn\'t reach ' . $host . ' from the server'],
                default => [false, $host . ' answered ' . $code],
            };
        }
        if (!self::on()) return [false, 'Not connected'];
        if (self::bucket() === '') return [false, 'S3_BUCKET isn\'t set'];
        [$code] = self::request('HEAD', 's3', self::bucket() . '.s3.' . self::region() . '.amazonaws.com', '/');
        return match (true) {
            $code === 200 => [true, 'Connected: ' . self::bucket() . ' (' . self::region() . ')'],
            $code === 301 => [false, 'The bucket is in another region: check AWS_REGION'],
            $code === 403 => [false, 'The key can\'t reach ' . self::bucket() . ': check the key and the policy'],
            $code === 404 => [false, 'No bucket called ' . self::bucket()],
            $code === 0 => [false, 'Couldn\'t reach AWS from the server'],
            default => [false, 'AWS answered ' . $code],
        };
    }
}
