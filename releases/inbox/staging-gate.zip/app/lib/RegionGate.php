<?php
// app/lib/RegionGate.php — the sign-up check of decisions/0027: where someone lives and where they're connecting from.
// Only when BOTH are in the EU, the EEA or the UK is self-service sign-up not offered (a support contact instead);
// either one elsewhere and sign-up goes ahead. Browsing is never checked. Asked at sign-up only when the connection is
// in the EU/UK (everyone else answers "where are you from" after the email link, or skips it).
// The connection's country comes from Cloudflare's CF-IPCountry header when the site is behind Cloudflare, else from
// ip_eu_ranges: DB-IP's free IP-to-country file (CC BY 4.0, https://db-ip.com), only its EU/EEA/UK ranges, refreshed
// monthly by region_tick (no key, no cost). Until it's loaded, nobody is stopped.
declare(strict_types=1);

final class RegionGate
{
    /** The EU's 27, the EEA's three (Iceland, Liechtenstein, Norway) and the UK. */
    public const EUUK = ['AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL',
        'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'IS', 'LI', 'NO', 'GB'];
    public const HOME_EUUK = 'EUUK';   // the answer "A country in the EU or the UK" on the sign-up question
    public const MESSAGE = 'Traversence is a U.S. regional business directory and isn\'t currently available to residents of the EU or UK. Planning a trip to the U.S.? Email support@traversence.com and we can set up an account for you.';
    private const SOURCE = 'https://download.db-ip.com/free/dbip-country-lite-%s.csv.gz';

    /** The connection's country when it's in the EU/EEA/UK ('DE', 'GB'…), else ''. */
    public static function ipCountry(PDO $pdo, ?string $ip = null): string
    {
        $cf = strtoupper((string) ($_SERVER['HTTP_CF_IPCOUNTRY'] ?? ''));
        if (preg_match('/^[A-Z]{2}$/', $cf)) return in_array($cf, self::EUUK, true) ? $cf : '';
        $bin = self::bin($ip ?? (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        if ($bin === '') return '';
        try {
            $st = $pdo->prepare('SELECT ip_to, cc FROM ip_eu_ranges WHERE ip_from <= ? ORDER BY ip_from DESC LIMIT 1');
            $st->execute([$bin]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return ($r && strcmp($bin, (string) $r['ip_to']) <= 0) ? (string) $r['cc'] : '';
        } catch (PDOException) { return ''; }
    }

    /**
     * 'ok' | 'ask' (the connection is in the EU/UK: ask where they live) | 'refuse' (both in the EU/UK).
     * $home: what they chose ('US', 'CA', 'MX', 'EUUK', another country's name) or null when not asked yet.
     */
    public static function check(PDO $pdo, ?string $home): string
    {
        if (self::ipCountry($pdo) === '') return 'ok';
        if ($home === null || trim($home) === '') return 'ask';
        $h = strtoupper(trim($home));
        return ($h === self::HOME_EUUK || in_array($h, self::EUUK, true)) ? 'refuse' : 'ok';
    }

    /** 16-byte form of an address (IPv4 as ::ffff:a.b.c.d), or '' if it isn't one. */
    public static function bin(string $ip): string
    {
        $b = @inet_pton(trim($ip));
        if ($b === false) return '';
        return strlen($b) === 4 ? str_repeat("\0", 10) . "\xff\xff" . $b : $b;
    }

    /** When the ranges were last loaded: ['source', 'rows', 'at'] or null. */
    public static function status(PDO $pdo): ?array
    {
        try { $r = $pdo->query('SELECT source, rows_kept, loaded_at FROM ip_eu_meta WHERE id = 1')->fetch(PDO::FETCH_ASSOC); }
        catch (PDOException) { return null; }
        return $r ? ['source' => (string) $r['source'], 'rows' => (int) $r['rows_kept'], 'at' => (string) $r['loaded_at']] : null;
    }

    /** Loads this month's file (or last month's) when the ranges are missing or over 30 days old. Returns a line for the log. */
    public static function refresh(PDO $pdo, bool $force = false): string
    {
        $s = self::status($pdo);
        if (!$force && $s && $s['rows'] > 0 && strtotime($s['at']) > time() - 30 * 86400) return 'Up to date (' . $s['rows'] . ' ranges, ' . $s['at'] . ').';
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold(sprintf(self::SOURCE, date('Y-m')), 'the IP country file', '', true)) !== null) return $w;   // a bulk download: held on staging
        $tmp = tempnam(sys_get_temp_dir(), 'dbip');
        $url = '';
        foreach ([date('Y-m'), date('Y-m', strtotime('first day of last month'))] as $m) {
            $u = sprintf(self::SOURCE, $m);
            $ch = curl_init($u); $fh = fopen($tmp, 'wb');
            curl_setopt_array($ch, [CURLOPT_FILE => $fh, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 300, CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_USERAGENT => 'Traversence region check (support@traversence.com)']);
            $ok = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch); fclose($fh);
            if ($ok && $code === 200 && filesize($tmp) > 100000) { $url = $u; break; }
        }
        if ($url === '') { @unlink($tmp); return 'Couldn\'t download the IP country file; the check keeps the last ranges (or lets everyone through).'; }
        $gz = gzopen($tmp, 'rb');
        if (!$gz) { @unlink($tmp); return 'The downloaded file couldn\'t be read.'; }
        $pdo->exec('CREATE TABLE IF NOT EXISTS ip_eu_ranges_new LIKE ip_eu_ranges');
        $pdo->exec('TRUNCATE TABLE ip_eu_ranges_new');
        $ins = []; $n = 0;
        $flush = function () use ($pdo, &$ins) {
            if (!$ins) return;
            $pdo->prepare('INSERT INTO ip_eu_ranges_new (ip_from, ip_to, cc) VALUES ' . implode(',', array_fill(0, count($ins), '(?, ?, ?)')))->execute(array_merge(...$ins));
            $ins = [];
        };
        while (($line = gzgets($gz)) !== false) {
            $f = str_getcsv(trim($line));
            if (count($f) < 3 || !in_array($f[2], self::EUUK, true)) continue;
            $a = self::bin($f[0]); $z = self::bin($f[1]);
            if ($a === '' || $z === '') continue;
            $ins[] = [$a, $z, $f[2]]; $n++;
            if (count($ins) >= 500) $flush();
        }
        $flush(); gzclose($gz); @unlink($tmp);
        if ($n < 1000) return 'The file had too few EU/UK ranges (' . $n . '); kept the old ones.';
        $pdo->exec('DROP TABLE IF EXISTS ip_eu_ranges_old');
        $pdo->exec('RENAME TABLE ip_eu_ranges TO ip_eu_ranges_old, ip_eu_ranges_new TO ip_eu_ranges');
        $pdo->exec('DROP TABLE IF EXISTS ip_eu_ranges_old');
        $pdo->prepare('REPLACE INTO ip_eu_meta (id, source, rows_kept, loaded_at) VALUES (1, ?, ?, NOW())')->execute([$url, $n]);
        return 'Loaded ' . $n . ' EU/EEA/UK ranges from ' . $url . '.';
    }
}
