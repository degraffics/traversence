<?php
// api/lib/ResourceGuides.php — resource guides (decisions/0061, batch 2): the phone lines and services that answer a
// situation but aren't businesses (the power company's outage line, highway patrol non-emergency, 211, poison control).
// One guide per area ('all' is everywhere we cover). Each entry: name, phone, hours, what it's for, the situations it
// answers, its official source, and when its number was last found there.
//
// The rule (decisions/0061): a number is published only when it appears on the provider's own official page. check()
// fetches that page and looks for the number; an entry shows in search only while it's verified. A check over a month
// old is flagged in Admin → Search oversight (automatic monthly re-checks come with the crawler, batch 3).
declare(strict_types=1);

final class ResourceGuides
{
    public const STALE_DAYS = 31;

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT 1 FROM resource_entries LIMIT 1'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    /** The guide's area key for a place: its own level and slug (a town in its area uses the area's). */
    public static function areaKey(?array $place): string
    {
        if (!$place || empty($place['slug']) || empty($place['level'])) return '';
        return $place['level'] . ':' . $place['slug'];
    }

    /**
     * The places a guide can be for (decisions/0131: every tier of the funnel; a place's lines show in its own guide and
     * every guide below it): everywhere, regions, areas, communities, towns, neighborhoods. [key => name]
     */
    public static function areas(PDO $pdo): array
    {
        $o = ['all' => 'Everywhere we cover'];
        try {
            foreach ($pdo->query('SELECT slug, name FROM hubs ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $r) $o['hub:' . $r['slug']] = 'Region: ' . $r['name'];
            foreach ($pdo->query('SELECT slug, name FROM geo_hubs ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $r) $o['geo_hub:' . $r['slug']] = 'Area: ' . $r['name'];
            foreach ($pdo->query('SELECT slug, name FROM micro_clusters ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $r) $o['cluster:' . $r['slug']] = 'Community: ' . (class_exists('PlaceScope') ? PlaceScope::publicName((string) $r['name']) : (string) $r['name']);
            foreach ($pdo->query('SELECT slug, name, state FROM anchors ORDER BY name')->fetchAll(PDO::FETCH_ASSOC) as $r) $o['town:' . $r['slug']] = 'Town: ' . $r['name'] . ($r['state'] ? ', ' . $r['state'] : '');
            foreach ($pdo->query("SELECT id, name FROM cluster_subgroups WHERE status = 'accepted' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC) as $r) $o['sub:' . $r['id']] = 'Neighborhood: ' . trim((string) preg_replace('/[\p{Cf}?]+/u', '', (string) $r['name']));
        } catch (Throwable) {}
        return $o;
    }

    public static function guides(PDO $pdo): array
    {
        return $pdo->query("SELECT g.*, (SELECT COUNT(*) FROM resource_entries e WHERE e.guide_id = g.id) AS entries,
                                   (SELECT COUNT(*) FROM resource_entries e WHERE e.guide_id = g.id AND e.verified = 1 AND e.status = 'live') AS shown
                            FROM resource_guides g ORDER BY g.area_key = 'all' DESC, g.title")->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function guide(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM resource_guides WHERE id = ?'); $st->execute([$id]);
        $g = $st->fetch(PDO::FETCH_ASSOC);
        if (!$g) return null;
        $st = $pdo->prepare('SELECT * FROM resource_entries WHERE guide_id = ? ORDER BY pos, id'); $st->execute([$id]);
        $g['entries'] = $st->fetchAll(PDO::FETCH_ASSOC);
        return $g;
    }

    public static function guideByArea(PDO $pdo, string $key): ?array
    {
        $st = $pdo->prepare('SELECT id FROM resource_guides WHERE area_key = ?'); $st->execute([$key]);
        $id = $st->fetchColumn();
        return $id ? self::guide($pdo, (int) $id) : null;
    }

    /** Creates or updates a guide: its id. */
    public static function saveGuide(PDO $pdo, int $id, string $area, string $title, string $intro, string $status, int $uid): int
    {
        $title = mb_substr(trim($title), 0, 160); $intro = mb_substr(trim($intro), 0, 4000);
        if (mb_strlen($title) < 3) throw new InvalidArgumentException('Give the guide a title.');
        if (!isset(self::areas($pdo)[$area])) throw new InvalidArgumentException('Pick the area it\'s for.');
        $status = $status === 'live' ? 'live' : 'draft';
        if ($id > 0) {
            $pdo->prepare('UPDATE resource_guides SET area_key = ?, title = ?, intro = ?, status = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$area, $title, $intro, $status, $uid, $id]);
            return $id;
        }
        if (self::guideByArea($pdo, $area)) throw new InvalidArgumentException('That area already has a guide: open it instead.');
        $pdo->prepare('INSERT INTO resource_guides (area_key, title, intro, status, updated_by) VALUES (?, ?, ?, ?, ?)')->execute([$area, $title, $intro, $status, $uid]);
        return (int) $pdo->lastInsertId();
    }

    /** Creates or updates an entry (an edited number is unverified until checked again): its id. */
    public static function saveEntry(PDO $pdo, int $guideId, int $id, array $in, int $uid): int
    {
        $name = mb_substr(trim((string) ($in['name'] ?? '')), 0, 160);
        if (mb_strlen($name) < 2) throw new InvalidArgumentException('Give it a name.');
        $phone = mb_substr(trim((string) ($in['phone'] ?? '')), 0, 40);
        if ($phone !== '' && strlen(preg_replace('/\D/', '', $phone)) < 3) throw new InvalidArgumentException('That doesn\'t look like a phone number.');
        $url = trim((string) ($in['source_url'] ?? ''));
        if ($url !== '' && !preg_match('#^https?://[^\s]+$#i', $url)) throw new InvalidArgumentException('The official source must start with https://.');
        $sits = array_values(array_filter(array_map(fn ($x) => preg_replace('/[^a-z0-9-]/', '', (string) $x), (array) ($in['situations'] ?? []))));
        $row = [mb_substr(trim((string) ($in['hours'] ?? '')), 0, 160), mb_substr(trim((string) ($in['purpose'] ?? '')), 0, 400), $sits ? ',' . implode(',', $sits) . ',' : '',
                mb_substr($url, 0, 500), ($in['status'] ?? 'live') === 'hidden' ? 'hidden' : 'live'];
        if ($id > 0) {
            $st = $pdo->prepare('SELECT phone, source_url FROM resource_entries WHERE id = ? AND guide_id = ?'); $st->execute([$id, $guideId]);
            $old = $st->fetch(PDO::FETCH_ASSOC);
            if (!$old) throw new InvalidArgumentException('That entry is gone.');
            $changed = $old['phone'] !== $phone || $old['source_url'] !== $row[3];   // a new number or source must be checked again
            $pdo->prepare('UPDATE resource_entries SET name = ?, phone = ?, hours = ?, purpose = ?, situations = ?, source_url = ?, status = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP'
                . ($changed ? ", verified = 0, check_note = 'Changed: check it again'" : '') . ' WHERE id = ?')->execute(array_merge([$name, $phone], $row, [$uid, $id]));
            return $id;
        }
        $pos = (int) $pdo->query('SELECT COALESCE(MAX(pos), 0) + 1 FROM resource_entries WHERE guide_id = ' . (int) $guideId)->fetchColumn();
        $pdo->prepare('INSERT INTO resource_entries (guide_id, pos, name, phone, hours, purpose, situations, source_url, status, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute(array_merge([$guideId, $pos, $name, $phone], $row, [$uid]));
        return (int) $pdo->lastInsertId();
    }

    public static function deleteEntry(PDO $pdo, int $id): void { $pdo->prepare('DELETE FROM resource_entries WHERE id = ?')->execute([$id]); }

    /**
     * Fetches the entry's official page and looks for its number (digits only, any formatting). Found: verified and
     * dated. Not found, or the page can't be read: unverified, so it stops showing in search. ['ok', 'note']
     */
    public static function check(PDO $pdo, int $id, ?callable $fetch = null): array
    {
        $st = $pdo->prepare('SELECT phone, source_url FROM resource_entries WHERE id = ?'); $st->execute([$id]);
        $e = $st->fetch(PDO::FETCH_ASSOC);
        if (!$e) return ['ok' => false, 'note' => 'That entry is gone.'];
        $digits = substr(preg_replace('/\D/', '', (string) $e['phone']), -10);
        if ($e['source_url'] === '') $r = [false, 'No official source yet: add the provider\'s own page.'];
        elseif ($digits === '') $r = [false, 'No phone number to look for.'];
        else {
            self::$held = null;
            $html = $fetch ? $fetch((string) $e['source_url']) : self::fetch((string) $e['source_url']);
            if ($html === null && self::$held !== null) return ['ok' => false, 'note' => self::$held];   // held on staging: the entry is left as it was
            if ($html === null) $r = [false, 'The source page couldn\'t be read just now.'];
            else {
                $txt = preg_replace('/\D/', '', html_entity_decode(strip_tags(preg_replace('#<(script|style)\b.*?</\1>#is', ' ', $html))));
                $tel = preg_match_all('/tel:\+?([\d\-\.\(\) ]+)/i', $html, $tm) ? preg_replace('/\D/', '', implode('', $tm[1])) : '';
                $found = str_contains($txt, $digits) || ($tel !== '' && str_contains($tel, $digits)) || (strlen($digits) <= 4 && str_contains($txt, $digits));
                $r = $found ? [true, 'Found on ' . (parse_url((string) $e['source_url'], PHP_URL_HOST) ?: 'the source')] : [false, 'The number isn\'t on the source page any more: not shown until it\'s fixed.'];
            }
        }
        $pdo->prepare('UPDATE resource_entries SET verified = ?, last_checked = CURRENT_TIMESTAMP, check_note = ? WHERE id = ?')->execute([$r[0] ? 1 : 0, mb_substr($r[1], 0, 240), $id]);
        return ['ok' => $r[0], 'note' => $r[1]];
    }

    private static ?string $held = null;

    private static function fetch(string $url): ?string
    {
        require_once __DIR__ . '/StagingGate.php'; if ((self::$held = StagingGate::hold($url, 'a resource\'s source page')) !== null) return null;   // a public page: held on staging
        if (!function_exists('curl_init')) {
            $ctx = stream_context_create(['http' => ['timeout' => 8, 'header' => "User-Agent: TraversenceResourceCheck/1.0\r\n"]]);
            $b = @file_get_contents($url, false, $ctx, 0, 2_000_000);
            return $b === false ? null : $b;
        }
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 4, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 5,
                               CURLOPT_USERAGENT => 'TraversenceResourceCheck/1.0 (+https://traversence.com)', CURLOPT_MAXFILESIZE => 2_000_000]);
        $b = curl_exec($c); $code = (int) curl_getinfo($c, CURLINFO_HTTP_CODE); curl_close($c);
        return is_string($b) && $code >= 200 && $code < 400 ? $b : null;
    }

    /**
     * The verified, live entries of the live guides for a place (its area's guide and the everywhere guide) that answer
     * any of these situations, as answer items (Situations::answer).
     */
    public static function forSituations(PDO $pdo, array $slugs, ?array $place): array
    {
        if (!$slugs || !self::ready($pdo)) return [];
        $keys = array_values(array_filter(['all', self::areaKey($place)]));
        $in = implode(',', array_fill(0, count($keys), '?'));
        $or = implode(' OR ', array_fill(0, count($slugs), 'e.situations LIKE ?'));
        $st = $pdo->prepare("SELECT e.*, g.area_key FROM resource_entries e JOIN resource_guides g ON g.id = e.guide_id
                             WHERE g.status = 'live' AND e.status = 'live' AND e.verified = 1 AND g.area_key IN ($in) AND ($or)
                             ORDER BY g.area_key = 'all', e.pos, e.id LIMIT 8");
        $st->execute(array_merge($keys, array_map(fn ($s) => '%,' . $s . ',%', $slugs)));
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $e) {
            $out[] = ['kind' => 'resource', 'id' => 'res:' . $e['id'], 'label' => (string) $e['name'], 'sub' => trim(implode(' · ', array_filter([(string) $e['purpose'], (string) $e['hours']]))),
                      'url' => '/guide/resources.php?id=' . (int) $e['guide_id'] . '#r' . (int) $e['id'], 'phone' => (string) $e['phone'],
                      'open' => preg_match('/24\s*(h|hours|\/7)/i', (string) $e['hours']) ? true : null, 'always' => (bool) preg_match('/24\s*(h|hours|\/7)/i', (string) $e['hours']),
                      'here' => false, 'miles' => null, 'peek' => false];   // a phone line has no "here"; the area is in its guide
        }
        return $out;
    }

    /** Entries that need a person: never checked, not found at the last check, checked over a month ago, or no source. */
    public static function needsCheck(PDO $pdo): array
    {
        $st = $pdo->prepare("SELECT e.id, e.name, e.phone, e.source_url, e.verified, e.last_checked, e.check_note, g.id AS guide_id, g.title AS guide
                             FROM resource_entries e JOIN resource_guides g ON g.id = e.guide_id
                             WHERE e.status = 'live' AND (e.verified = 0 OR e.last_checked IS NULL OR e.last_checked < ? OR e.source_url = '')
                             ORDER BY e.verified, e.last_checked LIMIT 100");
        $st->execute([date('Y-m-d H:i:s', time() - self::STALE_DAYS * 86400)]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
