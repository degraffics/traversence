<?php
// app/lib/S3.php — the site's file storage on S3 (master-aos §5D: business and member files live in object storage, not
// on Bluehost). Signed with the site's key (Aws, Signature Version 4, no SDK): short-lived links the browser uploads to
// and downloads from directly, so a file never passes through the web host and its upload limit doesn't matter;
// multipart uploads for big files (parts of 8 MB, up to 1 GB a file here); and the few calls the server makes itself
// (start, finish, check, read the first bytes, delete). S3_ENDPOINT (optional) points it at an S3-compatible store
// (Cloudflare R2, a local test server), path-style; without it, AWS itself (bucket.s3.<region>.amazonaws.com).
// The bucket needs CORS for the site's origin: PUT and GET, exposing ETag (decisions/0122 has the exact rule).
// On the staging copy (decisions/0145 Phase 3) every key goes through Staging::s3Key(): what staging writes goes under
// staging/, what it reads is its own copy or else the live file, and it never deletes a live file. Nothing changes on live.
declare(strict_types=1);

require_once __DIR__ . '/Aws.php';
require_once __DIR__ . '/Staging.php';

final class S3
{
    public const PART = 8 * 1024 * 1024;

    public static function on(): bool { [$id, $secret, $region] = self::creds(); return $id !== '' && $secret !== '' && $region !== '' && Aws::bucket() !== ''; }

    /**
     * The key and region the file store signs with: [key id, secret, region]. An S3-compatible store (S3_ENDPOINT: Cloudflare
     * R2, decisions/0151) has its own key (S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY) and region (S3_REGION, "auto" for R2), so
     * the AWS key stays for Amazon's email (SES); without S3_ENDPOINT, the AWS key and region as before.
     */
    public static function creds(): array
    {
        $e = fn (string $k) => trim((string) (getenv($k) ?: ''));
        if ($e('S3_ENDPOINT') === '') return [$e('AWS_ACCESS_KEY_ID'), $e('AWS_SECRET_ACCESS_KEY'), Aws::region()];
        return [$e('S3_ACCESS_KEY_ID') ?: $e('AWS_ACCESS_KEY_ID'), $e('S3_SECRET_ACCESS_KEY') ?: $e('AWS_SECRET_ACCESS_KEY'), $e('S3_REGION') ?: 'auto'];
    }

    /** [base URL, host, path prefix] for the bucket. */
    private static function base(): array
    {
        $ep = rtrim(trim((string) (getenv('S3_ENDPOINT') ?: '')), '/');
        if ($ep !== '') { $u = parse_url($ep); $host = $u['host'] . (isset($u['port']) ? ':' . $u['port'] : ''); return [$u['scheme'] . '://' . $host, $host, '/' . rawurlencode(Aws::bucket())]; }
        $host = Aws::bucket() . '.s3.' . Aws::region() . '.amazonaws.com';
        return ['https://' . $host, $host, ''];
    }

    private static function path(string $key): string { return implode('/', array_map('rawurlencode', explode('/', $key))); }

    private static function query(array $q): string
    {
        ksort($q, SORT_STRING);
        $out = []; foreach ($q as $k => $v) $out[] = rawurlencode((string) $k) . '=' . rawurlencode((string) $v);
        return implode('&', $out);
    }

    /** A link the browser can use for a while without our key: GET a file, or PUT one part of an upload. */
    public static function presign(string $method, string $key, int $seconds = 600, array $extra = [], ?int $at = null): string
    {
        [$base, $host, $pre] = self::base();
        $key = Staging::s3Key($key, $method !== 'GET' && $method !== 'HEAD');   // the key as it is, except on staging
        $now = gmdate('Ymd\THis\Z', $at ?? time()); $day = substr($now, 0, 8);
        [$id, $secret, $region] = self::creds();
        $path = $pre . '/' . self::path($key);
        $q = $extra + ['X-Amz-Algorithm' => 'AWS4-HMAC-SHA256', 'X-Amz-Credential' => "$id/$day/$region/s3/aws4_request", 'X-Amz-Date' => $now,
            'X-Amz-Expires' => (string) max(1, min(604800, $seconds)), 'X-Amz-SignedHeaders' => 'host'];
        $qs = self::query($q);
        $canon = $method . "\n" . $path . "\n" . $qs . "\nhost:" . $host . "\n\nhost\nUNSIGNED-PAYLOAD";
        $scope = "$day/$region/s3/aws4_request";
        $toSign = "AWS4-HMAC-SHA256\n$now\n$scope\n" . hash('sha256', $canon);
        $k = hash_hmac('sha256', 'aws4_request', hash_hmac('sha256', 's3', hash_hmac('sha256', $region, hash_hmac('sha256', $day, 'AWS4' . $secret, true), true), true), true);
        return $base . $path . '?' . $qs . '&X-Amz-Signature=' . hash_hmac('sha256', $toSign, $k);
    }

    /** A signed call from the server. Returns [http code, body, headers (lower-case)]. */
    public static function call(string $method, string $key, array $q = [], string $body = '', array $headers = [], int $timeout = 30): array
    {
        if ($key !== '' && Staging::here()) {   // staging: its own files only; a live one is never deleted from there
            if ($method === 'DELETE' && !isset($q['uploadId'])) { if (!Staging::s3Mine($key)) return [204, '', []]; $real = Staging::s3Key($key, false); Staging::s3Forget($key); $key = $real; }
            else $key = Staging::s3Key($key, !in_array($method, ['GET', 'HEAD'], true));
        }
        [$base, $host, $pre] = self::base();
        $path = $pre . '/' . ($key === '' ? '' : self::path($key)); $qs = self::query($q);
        $now = gmdate('Ymd\THis\Z'); $hash = hash('sha256', $body);
        $h = array_change_key_case($headers + ['host' => $host, 'x-amz-date' => $now, 'x-amz-content-sha256' => $hash], CASE_LOWER);
        [$cid, $csecret, $cregion] = self::creds();
        $h['authorization'] = Aws::authorization($method, $path, $qs, $h, $hash, $cid, $csecret, $cregion, 's3', $now);
        $out = []; foreach ($h as $k => $v) if ($k !== 'host') $out[] = $k . ': ' . $v;
        $rh = [];
        $ch = curl_init($base . $path . ($qs !== '' ? '?' . $qs : ''));
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => $out,
            CURLOPT_NOBODY => $method === 'HEAD', CURLOPT_HEADERFUNCTION => function ($c, $line) use (&$rh) { $p = strpos($line, ':'); if ($p) $rh[strtolower(trim(substr($line, 0, $p)))] = trim(substr($line, $p + 1)); return strlen($line); }]
            + ($body !== '' ? [CURLOPT_POSTFIELDS => $body] : []));
        $res = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return [$code, is_string($res) ? $res : '', $rh];
    }

    /** Starts a multipart upload; returns its upload id. */
    public static function start(string $key, string $type): string
    {
        [$code, $body] = self::call('POST', $key, ['uploads' => ''], '', ['content-type' => $type ?: 'application/octet-stream']);
        if ($code !== 200 || !preg_match('#<UploadId>([^<]+)</UploadId>#', $body, $m)) { error_log('S3 start ' . $code . ': ' . substr($body, 0, 300)); throw new RuntimeException('The file store didn\'t answer. Try again in a minute.'); }
        return html_entity_decode($m[1], ENT_XML1);
    }

    /** A link per part, for the browser to PUT each piece to. */
    public static function partUrls(string $key, string $uploadId, int $parts, int $seconds = 3600): array
    {
        $u = [];
        for ($n = 1; $n <= $parts; $n++) $u[] = self::presign('PUT', $key, $seconds, ['partNumber' => (string) $n, 'uploadId' => $uploadId]);
        return $u;
    }

    /** Finishes a multipart upload from the parts' ETags (1-based, in order). */
    public static function finish(string $key, string $uploadId, array $etags): void
    {
        $xml = '<CompleteMultipartUpload>';
        foreach (array_values($etags) as $i => $e) $xml .= '<Part><PartNumber>' . ($i + 1) . '</PartNumber><ETag>' . htmlspecialchars('"' . trim((string) $e, '"') . '"', ENT_XML1) . '</ETag></Part>';
        $xml .= '</CompleteMultipartUpload>';
        [$code, $body] = self::call('POST', $key, ['uploadId' => $uploadId], $xml, ['content-type' => 'application/xml'], 120);
        if ($code !== 200 || str_contains($body, '<Error>')) { error_log('S3 finish ' . $code . ': ' . substr($body, 0, 300)); throw new RuntimeException('The file didn\'t finish uploading. Try again.'); }
    }

    public static function abort(string $key, string $uploadId): void { self::call('DELETE', $key, ['uploadId' => $uploadId]); }

    /** The stored size, or -1 when it isn't there. */
    public static function size(string $key): int
    {
        [$code, , $h] = self::call('HEAD', $key);
        return $code === 200 ? (int) ($h['content-length'] ?? -1) : -1;
    }

    /** The first bytes of a stored file (to see what it really is). */
    public static function head(string $key, int $bytes = 8192): string
    {
        [$code, $body] = self::call('GET', $key, [], '', ['range' => 'bytes=0-' . ($bytes - 1)]);
        return in_array($code, [200, 206], true) ? $body : '';
    }

    public static function delete(string $key): void { self::call('DELETE', $key); }

    /** Stores a file from the server's disk (streamed, not read into memory). */
    public static function put(string $key, string $file, string $type, string $cache = ''): void
    {
        [$base, $host, $pre] = self::base();
        $key = Staging::s3Key($key, true);   // the key as it is, except on staging
        $path = $pre . '/' . self::path($key); $now = gmdate('Ymd\THis\Z'); $size = (int) filesize($file);
        $h = ['content-length' => (string) $size, 'content-type' => $type ?: 'application/octet-stream', 'host' => $host, 'x-amz-content-sha256' => 'UNSIGNED-PAYLOAD', 'x-amz-date' => $now]
            + ($cache !== '' ? ['cache-control' => $cache] : []);
        [$cid, $csecret, $cregion] = self::creds();   // the store's own key and region (R2's since decisions/0151), as every other call
        $h['authorization'] = Aws::authorization('PUT', $path, '', $h, 'UNSIGNED-PAYLOAD', $cid, $csecret, $cregion, 's3', $now);
        $out = []; foreach ($h as $k => $v) if ($k !== 'host') $out[] = $k . ': ' . $v;
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold($base . $path, 'store a file')) !== null) throw new RuntimeException($w);   // the store is allowed (staging writes under staging/)
        $fh = fopen($file, 'rb'); if (!$fh) throw new RuntimeException('The file couldn\'t be read.');
        $ch = curl_init($base . $path);
        curl_setopt_array($ch, [CURLOPT_UPLOAD => true, CURLOPT_INFILE => $fh, CURLOPT_INFILESIZE => $size, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 300, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => $out]);
        $res = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); fclose($fh);
        if ($code !== 200) { error_log('S3 put ' . $code . ' ' . $key . ': ' . substr((string) $res, 0, 300)); throw new RuntimeException('The file store didn\'t take the file.'); }
    }

    /** Every file under a prefix: [key => bytes]. */
    public static function list(string $prefix): array
    {
        $out = []; $token = '';
        do {
            [$code, $body] = self::call('GET', '', ['list-type' => '2', 'prefix' => $prefix] + ($token !== '' ? ['continuation-token' => $token] : []), '', [], 60);
            if ($code !== 200) { error_log('S3 list ' . $code . ': ' . substr($body, 0, 200)); break; }
            preg_match_all('#<Contents>.*?<Key>(.*?)</Key>.*?<Size>(\d+)</Size>.*?</Contents>#s', $body, $m, PREG_SET_ORDER);
            foreach ($m as $x) $out[html_entity_decode($x[1], ENT_XML1)] = (int) $x[2];
            $token = preg_match('#<NextContinuationToken>(.*?)</NextContinuationToken>#', $body, $t) ? html_entity_decode($t[1], ENT_XML1) : '';
        } while ($token !== '');
        return $out;
    }

    /** Copies a stored file within the bucket (up to 5 GB). */
    public static function copy(string $from, string $to): bool
    {
        [$code, $body] = self::call('PUT', $to, [], '', ['x-amz-copy-source' => '/' . Aws::bucket() . '/' . self::path(Staging::s3Key($from, false))], 120);
        if ($code !== 200 || str_contains($body, '<Error>')) { error_log('S3 copy ' . $code . ' ' . $from . ': ' . substr($body, 0, 200)); return false; }
        return true;
    }

    /** A stored file's bytes, or null when it isn't there. */
    public static function get(string $key): ?string
    {
        [$code, $body] = self::call('GET', $key, [], '', [], 120);
        return $code === 200 ? $body : null;
    }

    /** Whether the bucket lets the site's pages upload (its CORS rule allows PUT and shows the ETag): true, false, or
     *  null when the key may not read the rule (s3:GetBucketCORS). */
    public static function corsOk(): ?bool
    {
        [$code, $body] = self::call('GET', '', ['cors' => ''], '', [], 10);
        if ($code === 404) return false;
        if ($code !== 200) return null;
        return stripos($body, '<AllowedMethod>PUT</AllowedMethod>') !== false && stripos($body, '<ExposeHeader>ETag</ExposeHeader>') !== false;
    }

    /** A short-lived link to a file: shown in the browser (pictures, PDFs, video) or saved, under its own name. */
    public static function link(string $key, string $name, string $mime, bool $inline, int $seconds = 900): string
    {
        $n = str_replace(['"', "\r", "\n"], '', $name);
        return self::presign('GET', $key, $seconds, ['response-content-type' => $mime, 'response-content-disposition' => ($inline ? 'inline' : 'attachment') . '; filename="' . $n . '"',
            'response-cache-control' => 'private, max-age=600']);
    }
}
