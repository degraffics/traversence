<?php
// app/lib/SocialAuth.php — Sign in with Apple, Microsoft and Facebook (decisions/0090), alongside Continue with Google
// (decisions/0085, app/lib/GoogleAuth.php). Each asks only who the person is: the provider's ID for them, their email
// and their name. Never a password, contacts or anything else (connections to a platform's data are a separate thing,
// asked for later and only for what they're for: future-considerations.md, "Connections").
//
//   Apple      OpenID Connect. Apple posts its signed ID token back (form_post); its signature is checked against
//              Apple's published keys. Apple confirms every email; "Hide My Email" gives a relay address that forwards.
//   Microsoft  OpenID Connect, the same way (personal accounts and work or school accounts). Microsoft confirms the email
//              of a personal account; a work or school account's email is only what its organisation typed, so it is
//              never used to find an existing account, and a new account made with it gets the usual confirmation email.
//   Facebook   OAuth: the code is exchanged server to server with our secret, then Facebook is asked for id, name, email.
//              Facebook shares only a confirmed email.
//
// An Apple or Microsoft answer is posted from their site. The browser doesn't send our session cookie with a post from
// another site (SameSite=Lax), so the endpoint first answers with a small page that posts the same fields on from our
// own site, with the cookie (endpoint(), before the session starts, so the person's session is never replaced).
//
// Who gets signed in: the account with that provider's ID; otherwise the account with that confirmed email, which is
// then linked (an account whose email was never confirmed has its password cleared and its sessions ended first, as
// for Google); otherwise the person finishes signing up on /register.php?social=1 (18+, verification, choices).
//
// .env: APPLE_CLIENT_ID (the Services ID), MICROSOFT_CLIENT_ID (+ MICROSOFT_TENANT, default "common"),
// FACEBOOK_APP_ID, FACEBOOK_APP_SECRET. Each provider lists https://traversence.com/api/auth/<provider>.php as its
// return address. Off until set, and until app/migrations/2026-11-23_social_sign_in.sql has run.
declare(strict_types=1);

final class SocialAuth
{
    public const PROVIDERS = [
        'apple'     => ['label' => 'Apple', 'env' => ['APPLE_CLIENT_ID']],
        'microsoft' => ['label' => 'Microsoft', 'env' => ['MICROSOFT_CLIENT_ID']],
        'facebook'  => ['label' => 'Facebook', 'env' => ['FACEBOOK_APP_ID', 'FACEBOOK_APP_SECRET']],
    ];
    private const MS_CONSUMERS = '9188040d-6c67-4c5b-b112-36a304b66dad';   // Microsoft's tenant for personal accounts
    private const STATE_TTL = 900;
    private const PENDING_TTL = 3600;
    private const RELAY_FIELDS = ['id_token', 'state', 'user', 'error', 'code'];

    private static array $on = [];

    public static function enabled(string $p): bool
    {
        if (isset(self::$on[$p])) return self::$on[$p];
        if (!isset(self::PROVIDERS[$p])) return false;
        try { $pdo = Database::connection(); } catch (Throwable) { return self::$on[$p] = false; }   // .env is read on connecting
        foreach (self::PROVIDERS[$p]['env'] as $k) if (trim((string) getenv($k)) === '') return self::$on[$p] = false;
        try { $pdo->query('SELECT 1 FROM user_identities LIMIT 0'); return self::$on[$p] = true; } catch (Throwable) { return self::$on[$p] = false; }
    }

    public static function label(string $p): string { return self::PROVIDERS[$p]['label'] ?? ucfirst($p); }

    public static function redirectUri(string $p): string
    {
        $app = rtrim((string) (getenv('APP_URL') ?: ''), '/');
        $appHost = (string) parse_url($app, PHP_URL_HOST);
        $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $base = ($appHost !== '' && ($host === $appHost || $host === 'www.' . $appHost || 'www.' . $host === $appHost))
            ? (parse_url($app, PHP_URL_SCHEME) ?: 'https') . '://' . $host : $app;
        return $base . '/api/auth/' . $p . '.php';
    }

    /** Where to send the person to choose their account. */
    public static function start(string $p, string $next = '', bool $link = false): string
    {
        $state = bin2hex(random_bytes(16)); $nonce = bin2hex(random_bytes(16));
        // $link: Connect from Privacy: link this account to the signed-in person, whatever its email
        $_SESSION['tv_social_state'][$p] = ['state' => $state, 'nonce' => $nonce, 'next' => self::safeNext($next), 'at' => time(), 'link' => $link ? (int) ($_SESSION['user_id'] ?? 0) : 0];
        $ret = self::redirectUri($p);
        switch ($p) {
            case 'apple':
                return 'https://appleid.apple.com/auth/authorize?' . http_build_query(['client_id' => trim((string) getenv('APPLE_CLIENT_ID')), 'redirect_uri' => $ret,
                    'response_type' => 'code id_token', 'response_mode' => 'form_post', 'scope' => 'name email', 'state' => $state, 'nonce' => $nonce]);
            case 'microsoft':
                $t = preg_replace('/[^A-Za-z0-9.-]/', '', (string) (getenv('MICROSOFT_TENANT') ?: 'common'));
                return 'https://login.microsoftonline.com/' . $t . '/oauth2/v2.0/authorize?' . http_build_query(['client_id' => trim((string) getenv('MICROSOFT_CLIENT_ID')),
                    'redirect_uri' => $ret, 'response_type' => 'id_token', 'response_mode' => 'form_post', 'scope' => 'openid email profile', 'state' => $state, 'nonce' => $nonce,
                    'prompt' => 'select_account']);
            case 'facebook':
                return 'https://www.facebook.com/' . self::fbVersion() . '/dialog/oauth?' . http_build_query(['client_id' => trim((string) getenv('FACEBOOK_APP_ID')),
                    'redirect_uri' => $ret, 'response_type' => 'code', 'scope' => 'email,public_profile', 'state' => $state]);
        }
        throw new RuntimeException('Unknown sign-in.');
    }

    /**
     * The endpoint for one provider (website/api/auth/<provider>.php). Runs before the session starts so a post from the
     * provider's site can be passed on with our cookie.
     */
    public static function endpoint(string $p): never
    {
        // 1. posted from Apple's or Microsoft's site: pass the same fields on from our own site (no session yet)
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !isset($_POST['tv_relay']) && !isset($_POST['do']) && (isset($_POST['state']) || isset($_POST['error']))) {
            header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store'); header('Referrer-Policy: no-referrer');
            $f = '';
            foreach (self::RELAY_FIELDS as $k) if (isset($_POST[$k]) && is_string($_POST[$k])) $f .= '<input type="hidden" name="' . $k . '" value="' . htmlspecialchars(mb_substr($_POST[$k], 0, 8000), ENT_QUOTES) . '">';
            echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Signing in…</title>'
                . '<form id="f" method="post" action="/api/auth/' . $p . '.php"><input type="hidden" name="tv_relay" value="1">' . $f
                . '<p style="font:16px system-ui,sans-serif;color:#3E2B1F;text-align:center;margin-top:30vh">Signing you in… <noscript><button>Continue</button></noscript></p></form>'
                . '<script>document.getElementById("f").submit();</script>';
            exit;
        }
        require_once __DIR__ . '/../bootstrap.php';
        Database::connection();   // .env (the keys) is read on the first connection
        $back = fn (string $why, string $next = '') => '/login.php?social=' . rawurlencode($why) . '&p=' . $p . ($next !== '' ? '&next=' . rawurlencode($next) : '');
        $go = function (string $to): never { header('Location: ' . $to, true, 303); exit; };
        header('Cache-Control: no-store');

        // 4. the new account, from /register.php?social=1 (CSRF, 18+)
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !isset($_POST['tv_relay'])) {
            Response::requireCsrf();
            $b = Response::jsonBody();
            if ((string) ($b['do'] ?? '') !== 'create') Response::error('Unknown request.', 400, 'bad_request');
            if (($b['over_18'] ?? false) !== true) Response::error('You must be 18 years old or older to create an account.', 422, 'age_required');   // decisions/0058 §7
            // where they live and where they're connecting from (decisions/0027): only both in the EU/UK stops sign-up here
            require_once __DIR__ . '/RegionGate.php';
            $tvHome = isset($b['home_country']) ? (string) $b['home_country'] : null;
            $tvGate = RegionGate::check(Database::connection(), $tvHome);
            if ($tvGate === 'ask') Response::error('Where do you live?', 422, 'ask_home');
            if ($tvGate === 'refuse') Response::error(RegionGate::MESSAGE, 451, 'region');
            $pdo = Database::connection();
            $pp = self::pending();
            try { $uid = self::create($pdo, isset($b['display_name']) ? (string) $b['display_name'] : null); }
            catch (RuntimeException $e) { Response::error($e->getMessage(), 409, 'social_signup_failed'); }
            if (!empty($_SESSION['tv_invite'])) {
                try { require_once __DIR__ . '/People.php'; People::acceptInvite($pdo, (string) $_SESSION['tv_invite'], $uid); } catch (Throwable $e) { error_log('Invite accept failed: ' . $e->getMessage()); }
                unset($_SESSION['tv_invite']);
            }
            try { require_once __DIR__ . '/AgeGate.php'; AgeGate::confirm($pdo, $uid); } catch (Throwable $e) { error_log('Age confirmation not saved: ' . $e->getMessage()); }
            try {
                require_once __DIR__ . '/Consent.php';
                if (Consent::ready($pdo)) {
                    if (is_array($b['choices'] ?? null)) foreach (['analytics', 'video'] as $t) Consent::set($pdo, $uid, $t, !empty($b['choices'][$t]), $p . '.php');
                    if (in_array($b['verify'] ?? '', ['yes', 'no'], true)) Consent::set($pdo, $uid, 'verification', $b['verify'] === 'yes', $p . '.php', !empty($b['verify_read']));
                }
            } catch (Throwable $e) { error_log('social sign-up choices: ' . $e->getMessage()); }
            Response::success(['next' => self::safeNext((string) ($pp['next'] ?? '')) ?: '/user/dashboard.php']);
        }

        $next = self::safeNext((string) ($_GET['next'] ?? ''));
        if (!self::enabled($p)) $go($back('off', $next));
        // 2. start
        if (isset($_GET['start'])) $go(self::start($p, $next, !empty($_GET['link'])));
        // 3. back from the provider: posted on (Apple, Microsoft) or in the address (Facebook)
        $in = isset($_POST['tv_relay']) ? $_POST : $_GET;
        if (isset($in['error'])) {
            $S = $_SESSION['tv_social_state'][$p] ?? null; unset($_SESSION['tv_social_state'][$p]);
            $go($back('cancelled', (string) ($S['next'] ?? '')));
        }
        if (isset($in['state'])) {
            try {
                $prof = self::finish($p, array_map(fn ($v) => is_string($v) ? $v : '', array_intersect_key($in, array_flip(self::RELAY_FIELDS))));
                if ($prof['link'] > 0) {   // Connect from Privacy: link it to the person signed in, never anyone else
                    if ((int) ($_SESSION['user_id'] ?? 0) !== $prof['link']) throw new RuntimeException('Sign in again, then connect ' . self::label($p) . ' from Privacy.');
                    require_once __DIR__ . '/SignInLinks.php';
                    try { SignInLinks::link(Database::connection(), $prof['link'], $p, $prof['sub'], $prof['email']); $_SESSION['tv_link_done'] = self::label($p); }
                    catch (RuntimeException $e) { $_SESSION['tv_link_done'] = '!' . $e->getMessage(); }
                    $go('/user/dashboard.php#security');
                }
                $r = self::signIn(Database::connection(), $p, $prof);
            } catch (RuntimeException $e) {
                error_log($p . ' sign-in: ' . $e->getMessage());
                $_SESSION['tv_social_error'] = $e->getMessage();
                $go($back('error'));
            }
            if ($r === 'closing') $go('/user/restore-account.php');   // decisions/0091
            if ($r === 'new') $go('/register.php?social=1' . ($prof['next'] !== '' ? '&next=' . rawurlencode($prof['next']) : ''));
            $go($prof['next'] !== '' ? $prof['next'] : '/user/dashboard.php');
        }
        $go('/login.php');
    }

    /** The provider's answer checked; returns ['sub', 'email', 'verified', 'name', 'next']. Throws RuntimeException. */
    public static function finish(string $p, array $in): array
    {
        $S = $_SESSION['tv_social_state'][$p] ?? null;
        unset($_SESSION['tv_social_state'][$p]);   // one use
        $L = self::label($p);
        if (!$S || ($in['state'] ?? '') === '' || !hash_equals((string) $S['state'], (string) $in['state']) || time() - (int) $S['at'] > self::STATE_TTL) {
            throw new RuntimeException("That sign-in link expired. Try Continue with $L again.");
        }
        if ($p === 'facebook') return self::facebook((string) ($in['code'] ?? '')) + ['next' => (string) $S['next'], 'link' => (int) ($S['link'] ?? 0)];

        $c = self::verifyJwt((string) ($in['id_token'] ?? ''), $p);
        if (!isset($S['nonce']) || !hash_equals((string) $S['nonce'], (string) ($c['nonce'] ?? ''))) throw new RuntimeException('That sign-in was for another attempt. Try again.');
        if ((int) ($c['exp'] ?? 0) < time() - 60) throw new RuntimeException('That sign-in expired. Try again.');
        $sub = (string) ($c['sub'] ?? '');
        if ($sub === '' || strlen($sub) > 191) throw new RuntimeException("$L's answer couldn't be read.");
        if ($p === 'apple') {
            if (($c['iss'] ?? '') !== 'https://appleid.apple.com') throw new RuntimeException('That sign-in didn\'t come from Apple.');
            if (($c['aud'] ?? '') !== trim((string) getenv('APPLE_CLIENT_ID'))) throw new RuntimeException('That sign-in was for another site.');
            $email = strtolower(trim((string) ($c['email'] ?? '')));
            $verified = in_array($c['email_verified'] ?? false, [true, 'true'], true);
            $u = json_decode((string) ($in['user'] ?? ''), true);   // Apple sends the name once, the first time only
            $name = is_array($u) ? trim((string) ($u['name']['firstName'] ?? '') . ' ' . (string) ($u['name']['lastName'] ?? '')) : '';
        } else {
            $tid = (string) ($c['tid'] ?? '');
            if (!preg_match('/^[0-9a-f-]{36}$/', $tid) || ($c['iss'] ?? '') !== "https://login.microsoftonline.com/$tid/v2.0") throw new RuntimeException('That sign-in didn\'t come from Microsoft.');
            if (($c['aud'] ?? '') !== trim((string) getenv('MICROSOFT_CLIENT_ID'))) throw new RuntimeException('That sign-in was for another site.');
            $email = strtolower(trim((string) ($c['email'] ?? '')));
            // a personal account's email is Microsoft's own, confirmed; a work or school account's is what its
            // organisation typed, unless Microsoft says the organisation owns that domain (xms_edov)
            $verified = $tid === self::MS_CONSUMERS || in_array($c['xms_edov'] ?? false, [true, 'true', 1, '1'], true);
            $name = trim((string) ($c['name'] ?? ''));
        }
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException("$L didn't share an email address for that account, so it can't be used here. Sign up with your email instead.");
        return ['sub' => $sub, 'email' => $email, 'verified' => $verified, 'name' => mb_substr($name, 0, 80), 'next' => (string) $S['next'], 'link' => (int) ($S['link'] ?? 0)];
    }

    /** Facebook: the code exchanged with our secret, then who it is. */
    private static function facebook(string $code): array
    {
        if ($code === '') throw new RuntimeException('Facebook didn\'t send a sign-in. Try again.');
        $v = self::fbVersion(); $id = trim((string) getenv('FACEBOOK_APP_ID')); $secret = trim((string) getenv('FACEBOOK_APP_SECRET'));
        $t = self::httpGet("https://graph.facebook.com/$v/oauth/access_token?" . http_build_query(['client_id' => $id, 'client_secret' => $secret, 'redirect_uri' => self::redirectUri('facebook'), 'code' => $code]), 'token');
        $tok = (string) ($t['access_token'] ?? '');
        if ($tok === '') throw new RuntimeException('Facebook didn\'t confirm the sign-in' . (!empty($t['error']['message']) ? ' (' . mb_substr((string) $t['error']['message'], 0, 120) . ')' : '') . '.');
        $me = self::httpGet("https://graph.facebook.com/$v/me?" . http_build_query(['fields' => 'id,name,email', 'access_token' => $tok, 'appsecret_proof' => hash_hmac('sha256', $tok, $secret)]), 'me');
        $sub = (string) ($me['id'] ?? '');
        if ($sub === '' || !preg_match('/^\d{1,40}$/', $sub)) throw new RuntimeException('Facebook\'s answer couldn\'t be read.');
        $email = strtolower(trim((string) ($me['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Facebook didn\'t share an email address (it may have been unticked, or the account has none). Try again and allow the email, or sign up with your email.');
        return ['sub' => $sub, 'email' => $email, 'verified' => true, 'name' => mb_substr(trim((string) ($me['name'] ?? '')), 0, 80)];   // Facebook shares only a confirmed email
    }

    /** An RS256 JWT's signature checked against the provider's published keys; its claims. */
    private static function verifyJwt(string $jwt, string $p): array
    {
        $L = self::label($p);
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) throw new RuntimeException("$L didn't send a sign-in. Try again.");
        $head = json_decode((string) self::b64url($parts[0]), true);
        $claims = json_decode((string) self::b64url($parts[1]), true);
        $sig = self::b64url($parts[2]);
        if (!is_array($head) || !is_array($claims) || $sig === false || ($head['alg'] ?? '') !== 'RS256') throw new RuntimeException("$L's answer couldn't be read.");
        $key = null;
        foreach (self::jwks($p) as $k) if (($k['kid'] ?? '') === ($head['kid'] ?? '#')) { $key = self::jwkPem($k); break; }
        if (!$key || openssl_verify($parts[0] . '.' . $parts[1], $sig, $key, OPENSSL_ALGO_SHA256) !== 1) throw new RuntimeException("That sign-in couldn't be confirmed as $L's. Try again.");
        return $claims;
    }

    /** The provider's published signing keys, kept for an hour. */
    private static function jwks(string $p): array
    {
        if (($fx = getenv(strtoupper($p) . '_JWKS_FIXTURE')) && is_file($fx)) return (array) (json_decode((string) file_get_contents($fx), true)['keys'] ?? []);   // local tests only
        $url = $p === 'apple' ? 'https://appleid.apple.com/auth/keys' : 'https://login.microsoftonline.com/common/discovery/v2.0/keys';
        $cache = dirname(__DIR__) . '/storage/' . $p . '-keys.json';
        if (is_file($cache) && filemtime($cache) > time() - 3600 && is_array($c = json_decode((string) file_get_contents($cache), true)) && !empty($c['keys'])) return $c['keys'];
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold($url, self::label($p) . ' sign-in keys')) !== null) throw new RuntimeException($w . ' Sign in with your email on staging.');   // social sign-in is off on staging (decisions/0165)
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15]);
        $body = curl_exec($ch); curl_close($ch);
        $c = json_decode((string) $body, true);
        if (!is_array($c) || empty($c['keys'])) throw new RuntimeException(self::label($p) . '\'s keys couldn\'t be fetched just now. Try again in a minute.');
        @file_put_contents($cache, json_encode($c));
        return $c['keys'];
    }

    /** A published key (JWK) as PEM: its certificate when it has one (Microsoft), else built from its modulus and exponent (Apple). */
    public static function jwkPem(array $k): ?string
    {
        if (!empty($k['x5c'][0]) && is_string($k['x5c'][0])) return "-----BEGIN CERTIFICATE-----\n" . chunk_split($k['x5c'][0], 64, "\n") . "-----END CERTIFICATE-----\n";
        if (($k['kty'] ?? '') !== 'RSA' || empty($k['n']) || empty($k['e'])) return null;
        $n = self::b64url((string) $k['n']); $e = self::b64url((string) $k['e']);
        if ($n === false || $e === false) return null;
        $len = function (int $l): string { if ($l < 0x80) return chr($l); $s = ltrim(pack('N', $l), "\x00"); return chr(0x80 | strlen($s)) . $s; };
        $int = fn (string $b) => "\x02" . $len(strlen($b = (ord($b[0]) > 0x7f ? "\x00" . $b : $b))) . $b;
        $seq = fn (string $c) => "\x30" . $len(strlen($c)) . $c;
        $rsa = $seq($int($n) . $int($e));
        $spki = $seq($seq("\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00") . "\x03" . $len(strlen($rsa) + 1) . "\x00" . $rsa);
        return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($spki), 64, "\n") . "-----END PUBLIC KEY-----\n";
    }

    /**
     * Signs in the account for this profile. Returns 'signed_in', or 'new' (the profile waits in the session for the
     * person to finish signing up). Throws RuntimeException with a plain reason.
     */
    public static function signIn(PDO $pdo, string $p, array $prof): string
    {
        $L = self::label($p);
        $sel = 'SELECT u.id, u.email, u.is_suspended, u.session_version, u.email_verified_at FROM users u';
        $st = $pdo->prepare("$sel JOIN user_identities i ON i.user_id = u.id WHERE i.provider = ? AND i.subject = ? LIMIT 1");
        $st->execute([$p, $prof['sub']]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if (!$u) {
            $st = $pdo->prepare("$sel WHERE u.email = ? LIMIT 1");
            $st->execute([$prof['email']]);
            $u = $st->fetch(PDO::FETCH_ASSOC);
            if ($u && !$prof['verified']) {
                // an email the provider didn't confirm never opens an existing account
                throw new RuntimeException("There's already an account for {$prof['email']}. Sign in with your email and password, or with the way you signed up.");
            }
            if ($u) {
                $o = $pdo->prepare('SELECT 1 FROM user_identities WHERE user_id = ? AND provider = ? LIMIT 1'); $o->execute([(int) $u['id'], $p]);
                if ($o->fetchColumn()) throw new RuntimeException("That email is already linked to a different $L account. Sign in with that one, or with your password.");
                if ($u['email_verified_at'] === null) {   // as for Google: whoever registered an unconfirmed address loses the way in first
                    $pdo->prepare('UPDATE users SET password_hash = ?, email_verified_at = NOW(), session_version = session_version + 1, updated_at = NOW() WHERE id = ?')
                        ->execute([password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), (int) $u['id']]);
                    $u['session_version'] = (int) $u['session_version'] + 1;
                }
                $pdo->prepare('INSERT INTO user_identities (user_id, provider, subject, email, created_at) VALUES (?, ?, ?, ?, NOW())')->execute([(int) $u['id'], $p, $prof['sub'], $prof['email']]);
            }
        }
        if (!$u) {
            $_SESSION['tv_social_pending'] = ['provider' => $p, 'sub' => $prof['sub'], 'email' => $prof['email'], 'verified' => (bool) $prof['verified'],
                                              'name' => $prof['name'], 'at' => time(), 'next' => $prof['next'] ?? ''];
            return 'new';
        }
        if ((int) $u['is_suspended'] === 1) {
            throw new RuntimeException('Access to this account is revoked for now. We emailed you what happened, how to recover, and a link to ask for a review; to get that link again, go to /user/notice.php.');   // decisions/0079
        }
        $pdo->prepare('UPDATE user_identities SET last_used_at = NOW() WHERE provider = ? AND subject = ?')->execute([$p, $prof['sub']]);
        if (self::closingHold($pdo, (int) $u['id'])) return 'closing';
        self::session((int) $u['id'], (int) $u['session_version']);
        return 'signed_in';
    }

    /** A closing account (decisions/0091) isn't signed in: it's held for /user/restore-account.php (Restore or Keep closed). */
    private static function closingHold(PDO $pdo, int $id): bool
    {
        if (!is_file(__DIR__ . '/AccountDeletion.php')) return false;
        require_once __DIR__ . '/AccountDeletion.php';
        if (!AccountDeletion::ready($pdo) || !AccountDeletion::closing($pdo, $id)) return false;
        AccountDeletion::holdForRestore($id);
        return true;
    }

    /** The profile waiting to finish signing up, or null. */
    public static function pending(): ?array
    {
        $p = $_SESSION['tv_social_pending'] ?? null;
        if (!$p || time() - (int) $p['at'] > self::PENDING_TTL) { unset($_SESSION['tv_social_pending']); return null; }
        return $p;
    }

    /** Creates the account for the waiting profile and signs it in. Returns the new user id. */
    public static function create(PDO $pdo, ?string $displayName): int
    {
        $p = self::pending();
        if (!$p) throw new RuntimeException('That sign-up expired. Try again from the sign-in page.');
        $L = self::label($p['provider']);
        $st = $pdo->prepare('SELECT 1 FROM users WHERE email = ? UNION SELECT 1 FROM user_identities WHERE provider = ? AND subject = ? LIMIT 1');
        $st->execute([$p['email'], $p['provider'], $p['sub']]);
        if ($st->fetchColumn()) { unset($_SESSION['tv_social_pending']); throw new RuntimeException("There's already an account for that email. Use Continue with $L on the sign-in page, or your password."); }
        $name = trim((string) $displayName) !== '' ? mb_substr(trim((string) $displayName), 0, 80) : ($p['name'] !== '' ? $p['name'] : null);
        $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO users (email, password_hash, display_name, email_verified_at, created_at, updated_at) VALUES (?, ?, ?, ' . ($p['verified'] ? 'NOW()' : 'NULL') . ', NOW(), NOW())')
                ->execute([$p['email'], password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), $name]);
            $id = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO user_identities (user_id, provider, subject, email, created_at, last_used_at) VALUES (?, ?, ?, ?, NOW(), NOW())')->execute([$id, $p['provider'], $p['sub'], $p['email']]);
            $pdo->commit();
        } catch (Throwable $e) { $pdo->rollBack(); throw new RuntimeException('That account couldn\'t be created just now. Try again.'); }
        require_once __DIR__ . '/Acceptance.php'; Acceptance::signup($pdo, $id);   // the Terms shown when finishing sign-up (decisions/0142 §2)
        unset($_SESSION['tv_social_pending']);
        if (!$p['verified']) {   // a work or school email: confirmed the usual way, as when signing up with a password
            try {
                require_once __DIR__ . '/Mailer.php';
                $tok = Auth::issueEmailConfirmation($id, 'registration');
                Mailer::send($p['email'], 'Verify your Traversence account',
                    "Welcome to Traversence.\n\nPlease verify your email address by visiting:\n" . rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/verify-email.php?token=' . urlencode($tok) . "\n\n"
                    . "You won't have full access until you verify.\n\nIf you didn't create this account, you can ignore this email.");
            } catch (Throwable $e) { error_log('social sign-up verification email: ' . $e->getMessage()); }
        }
        $v = $pdo->prepare('SELECT session_version FROM users WHERE id = ?'); $v->execute([$id]);
        self::session($id, (int) $v->fetchColumn());
        return $id;
    }

    public static function safeNext(string $n): string { return preg_match('#^/(?!/)[^\s\\\\]*$#', $n) ? $n : ''; }

    private static function session(int $id, int $version): void
    {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $id;
        $_SESSION['logged_in_at'] = time();
        $_SESSION['session_version'] = $version;
        try { require_once __DIR__ . '/SignInLinks.php'; SignInLinks::afterSignIn(Database::connection(), $id); } catch (Throwable) {}   // "I already have an account": link the waiting sign-in
    }

    private static function fbVersion(): string { return preg_match('/^v\d{1,2}\.\d$/', (string) getenv('FACEBOOK_GRAPH_VERSION')) ? (string) getenv('FACEBOOK_GRAPH_VERSION') : 'v21.0'; }

    private static function b64url(string $s): string|false
    {
        return base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
    }

    /** GET JSON from Facebook's API. $fx: which local test answer to use. */
    private static function httpGet(string $url, string $fx): array
    {
        if (($f = getenv('FACEBOOK_FIXTURE')) && is_file($f)) return (array) (json_decode((string) file_get_contents($f), true)[$fx] ?? []);   // local tests only
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold($url, 'Facebook sign-in')) !== null) return ['error' => ['message' => $w . ' Sign in with your email on staging.']];   // social sign-in is off on staging
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
        $body = curl_exec($ch); curl_close($ch);
        $j = json_decode((string) $body, true);
        return is_array($j) ? $j : ['error' => ['message' => 'no answer from Facebook']];
    }
}
