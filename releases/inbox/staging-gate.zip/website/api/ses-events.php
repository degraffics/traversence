<?php
// /api/ses-events.php — bounce and complaint reports from Amazon SES, through SNS (decisions/0137 §8). Every message is
// checked before anything is done: its signature against AWS's own certificate (from an sns.<region>.amazonaws.com
// address only), and its topic against the ones our setup made. A subscription is confirmed once; each notification is
// handled once (email_events). A bounce or complaint stops mail to that address and may pause its sender (SesMail::event).
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/SesMail.php';
require_once __DIR__ . '/../../app/lib/StagingGate.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo 'POST only'; exit; }
$raw = (string) file_get_contents('php://input');
$m = json_decode($raw, true);
if (!is_array($m) || empty($m['Type']) || empty($m['Signature']) || empty($m['SigningCertURL'])) { http_response_code(400); echo 'Not an SNS message'; exit; }
$pdo = Database::connection();

/** The string SNS signs, by message type (AWS: "Verifying the signatures of Amazon SNS messages"). */
function tv_sns_string(array $m): string
{
    $keys = $m['Type'] === 'Notification' ? ['Message', 'MessageId', 'Subject', 'Timestamp', 'TopicArn', 'Type']
                                           : ['Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type'];
    $s = '';
    foreach ($keys as $k) if (isset($m[$k])) $s .= $k . "\n" . $m[$k] . "\n";
    return $s;
}

function tv_sns_valid(array $m): bool
{
    $u = parse_url((string) $m['SigningCertURL']);
    if (($u['scheme'] ?? '') !== 'https' || !preg_match('/^sns\.[a-z0-9-]+\.amazonaws\.com$/', (string) ($u['host'] ?? '')) || !str_ends_with((string) ($u['path'] ?? ''), '.pem')) return false;
    if (StagingGate::hold((string) $m['SigningCertURL'], 'an SNS signing certificate') !== null) return false;   // SNS is held on staging (live's webhooks never reach it)
    $ch = curl_init((string) $m['SigningCertURL']);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10]);
    $pem = curl_exec($ch); curl_close($ch);
    if (!is_string($pem) || $pem === '') return false;
    $key = openssl_pkey_get_public($pem);
    if ($key === false) return false;
    $alg = (string) ($m['SignatureVersion'] ?? '1') === '2' ? OPENSSL_ALGO_SHA256 : OPENSSL_ALGO_SHA1;
    return openssl_verify(tv_sns_string($m), (string) base64_decode((string) $m['Signature']), $key, $alg) === 1;
}

$topics = array_filter([SesMail::state($pdo, 'topic_personal'), SesMail::state($pdo, 'topic_bulk')]);
if (!$topics || !in_array((string) ($m['TopicArn'] ?? ''), $topics, true)) { http_response_code(403); echo 'Unknown topic'; exit; }
if (!tv_sns_valid($m)) { http_response_code(403); echo 'Bad signature'; exit; }

if ($m['Type'] === 'SubscriptionConfirmation') {
    $u = parse_url((string) ($m['SubscribeURL'] ?? ''));
    if (($u['scheme'] ?? '') === 'https' && preg_match('/^sns\.[a-z0-9-]+\.amazonaws\.com$/', (string) ($u['host'] ?? ''))) {
        if (($w = StagingGate::hold((string) $m['SubscribeURL'], 'confirm an SNS subscription')) !== null) { echo $w; exit; }   // a change to our AWS account: never from staging
        $ch = curl_init((string) $m['SubscribeURL']); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10]); curl_exec($ch); curl_close($ch);
        SesMail::setState($pdo, 'confirmed_' . md5((string) $m['TopicArn']), date('Y-m-d H:i:s'));
    }
    echo 'confirmed'; exit;
}
if ($m['Type'] !== 'Notification') { echo 'ignored'; exit; }
try {
    $st = $pdo->prepare('INSERT IGNORE INTO email_events (id, received_at) VALUES (?, ?)');
    $st->execute([mb_substr((string) $m['MessageId'], 0, 100), date('Y-m-d H:i:s')]);
    if ($st->rowCount() === 0) { echo 'already handled'; exit; }
    $e = json_decode((string) $m['Message'], true);
    echo is_array($e) ? SesMail::event($pdo, $e) : 'not an SES event';
} catch (Throwable $x) {
    error_log('ses-events: ' . $x->getMessage());
    http_response_code(500); echo 'error';   // SNS tries again
}
