<?php
// includes/explore-hero.php — the Explore hero (decisions/0058 §18): the standard top of Let's Explore and of every
// place page (region, area, town area). Photos from the published journeys for that place and the places inside it
// (Journeys::hero by scope key), the title "Explore: <place>" with a pencil to change the place, the place's
// context (the region and area it's in) and, on Let's Explore, its tabs. One name, said once.
//
//   echo tv_explore_hero($pdo, ['name' => 'St. Johns', 'scope' => 'cluster:1', 'within' => [['Ancient Borderlands', '/hub/?geo=…']],
//                               'tabs' => [[key, label, icon, url], …], 'active' => 'regions', 'link' => '<span data-link=…>']);
//
// Also: tv_explore_art($seed) — a card's background when it has no photo (the brand's colours, a quiet topo line).

declare(strict_types=1);

function tv_explore_hero(?PDO $pdo, array $o): string
{
    static $n = 0; $n++;
    $name = (string) ($o['name'] ?? 'North America');
    $scope = (string) ($o['scope'] ?? '');
    $own = $o['slides'] ?? null;   // a listing's or a profile's own photos and videos (HeroMedia); a landmark's Commons photo
    // journeys' photos: for a level, its journeys; for one place ('near') or a listing ('tagged'), the journeys shared
    // there, shown after the owner's own (decisions/0058 §30)
    $slides = [];
    if ($pdo && ($own === null || !empty($o['tagged']) || !empty($o['near']))) {
        try {
            if (!class_exists('Journeys')) require_once __DIR__ . '/../lib/Journeys.php';
            if (Journeys::ready($pdo)) $slides = !empty($o['tagged']) ? Journeys::heroTagged($pdo, (int) $o['tagged'])
                : (!empty($o['near']) ? Journeys::heroNear($pdo, (float) $o['near'][0], (float) $o['near'][1]) : Journeys::hero($pdo, $scope, 5));
        } catch (Throwable $e) { error_log('explore hero: ' . $e->getMessage()); }
    }
    // no photo of its own and none shared: the page's own photos of what's there come next ('fallback_slides': Let's Explore
    // passes its landmarks' Commons photos, credited), real photos before any stock (decisions/0058 §30, 0138, 0143 §4;
    // Jason, 2026-11-17: "the hero is not changing like it should")
    if (!$own && !$slides && !empty($o['fallback_slides'])) $own = (array) $o['fallback_slides'];
    // and only then a stock photo from the library, labelled (decisions/0143), until a real one is added (then this isn't
    // reached). 'stock' => [subject, place, owner, representative, fallback, nudge (HTML)]
    $stk = null;
    if ($pdo && !$own && !$slides && !empty($o['stock'])) {
        try {
            require_once __DIR__ . '/../lib/StockLibrary.php';
            $so = (array) $o['stock'];
            $stk = StockLibrary::forSlot($pdo, 'hero', (string) ($so['owner'] ?? ''), (string) ($so['subject'] ?? ''), (string) ($so['place'] ?? ''),
                ['representative' => !empty($so['representative']), 'fallback' => (string) ($so['fallback'] ?? 'landscape')]);
        } catch (Throwable $e) { error_log('explore hero stock: ' . $e->getMessage()); }
    }
    $id = 'xh-' . $n;
    $h = $n === 1 ? tv_explore_hero_css() : '';
    $none = !$own && !$slides && !$stk;   // no photos or video at all: the hero shrinks to a band (decisions/0058 §33)
    $h .= '<section class="xh' . (empty($o['tabs']) ? ' xh-solo' : '') . ($none ? ' xh-nophoto' : '') . '" data-xh-name="' . tv_e((string) ($o['heading'] ?? $name)) . '"' . (!empty($o['link']) ? ' data-link-host' : '') . ' aria-label="' . tv_e('Explore ' . $name) . '"><div class="xh-track" id="' . $id . '">';
    $ownHtml = '';
    foreach ((array) $own as $s) {
        // a video loads from YouTube or Vimeo only when allowed or tapped (js/consent.js, decisions/0077)
        if (!empty($s['video'])) $ownHtml .= '<div class="xh-slide xh-vid"><div class="tv-vid" style="height:100%;aspect-ratio:auto;border-radius:0" data-vsrc="' . tv_e($s['video']) . '" data-vtitle="' . tv_e($s['caption'] ?: 'Video') . '"></div></div>';
        else $ownHtml .= '<div class="xh-slide xh-zoom" data-lb="' . tv_e($s['image']) . '" data-lb-cap="' . tv_e($s['caption']) . '"'
            . (!empty($s['href']) ? ' data-lb-name="' . tv_e((string) ($s['subject'] ?? '')) . '" data-lb-href="' . tv_e((string) $s['href']) . '"'   // the photo is of another place: the viewer names it (2026-11-19)
                . (!empty($s['kind']) ? ' data-lb-kind="' . tv_e((string) $s['kind']) . '" data-lb-ref="' . tv_e((string) $s['ref']) . '"' : '')
                . (isset($s['lat'], $s['lon']) ? ' data-lb-lat="' . (float) $s['lat'] . '" data-lb-lon="' . (float) $s['lon'] . '"' : '') : '') . ' role="button" tabindex="0" aria-label="Open the photo" style="background-image:url(\'' . tv_e($s['image']) . '\')">'   // a tap opens the lightbox (decisions/0058 §28)
            . ($s['caption'] !== '' ? '<span class="xh-cap"><span>' . tv_e($s['caption']) . '</span></span>' : '') . '</div>';
    }
    $journeys = $slides;
    $slides = array_merge((array) $own, $journeys);   // counted for the arrows and "no photos"
    $jHtml = '';
    foreach ($journeys as $s) {
        $jHtml .= '<a class="xh-slide" href="' . tv_e($s['url']) . '" style="background-image:url(\'' . tv_e($s['image']) . '\')"><span class="xh-cap"><span>' . tv_e($s['caption'])
            . ($s['place'] ? ' · ' . tv_e($s['place']) : '') . '</span><span class="xh-cred"><span class="jr-av" aria-hidden="true">' . tv_e(mb_strtoupper(mb_substr((string) $s['author'], 0, 1)))
            . '</span><b>' . tv_e($s['author']) . '</b><span>♥ ' . (int) $s['likes'] . '</span></span></span></a>';
    }
    // the owner's photos lead (a listing, a profile); a landmark's Commons photo goes after visitors' journeys ('own_last')
    $h .= !empty($o['own_last']) ? $jHtml . $ownHtml : $ownHtml . $jHtml;
    if (!$slides && $stk) {   // a stock photo, labelled, with "Add your own photo" for whoever runs the page
        require_once __DIR__ . '/stock-ui.php';
        $h .= '<div class="xh-slide xh-stock" style="background-image:url(\'' . tv_e($stk['url']) . '\')"><div class="xh-stkw">'
            . tv_stock_tag($stk, ['at' => 'in', 'nudge' => (string) ($o['stock']['nudge'] ?? '')]) . '</div></div>';
    } elseif (!$slides) {   // no photos: the brand's art. "Be the first" is the camera button below, not a box (decisions/0058 §34)
        $h .= '<div class="xh-slide xh-empty" style="' . tv_explore_art($name, true) . '">'
            . (empty($o['manage']) && (string) ($o['empty'] ?? '') !== '' ? '<span class="xh-cap"><span>' . tv_e((string) $o['empty']) . '</span></span>' : '') . '</div>';
    }
    $h .= '</div><div class="xh-head' . (!empty($o['link']) ? ' xh-haslink' : '') . '"><h1 class="xh-title">' . (isset($o['heading']) ? '' : tv_icon('compass')) . '<span>' . tv_e(isset($o['heading']) ? (string) $o['heading'] : 'Explore: ' . $name) . '</span></h1>'
        . (($o['edit'] ?? true) ? '<button type="button" class="xh-edit" onclick="if(window.openLocationModal)openLocationModal()" title="Change the place" aria-label="Change the place">'
        . '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg></button>' : '')
        . (string) ($o['link'] ?? '')
        . (!empty($o['corner']) ? '<span class="xh-corner">' . $o['corner'] . '</span>' : '');   // the top-right corner: Claim or Manage on a listing
    // the line about the page sits right under the title, in the same block, so a long name pushes it down
    if (!empty($o['sub'])) $h .= '<p class="xh-in">' . tv_e((string) $o['sub']) . '</p>';   // a line about the page (Regions, Destinations…)
    elseif (!empty($o['trail'])) {   // a guide: the places above it from the top down, as the funnel runs (Ancient America › Ancient Borderlands › …)
        $h .= '<p class="xh-in xh-trail">' . implode(' <span aria-hidden="true">›</span> ', array_map(fn ($w) => $w[1] ? '<a href="' . tv_e($w[1]) . '">' . tv_e($w[0]) . '</a>' : tv_e($w[0]), $o['trail'])) . '</p>';
    }
    elseif (!empty($o['within'])) {   // the region and area it's in, each a way up
        $h .= '<p class="xh-in">in ' . implode(' · ', array_map(fn ($w) => $w[1] ? '<a href="' . tv_e($w[1]) . '">' . tv_e($w[0]) . '</a>' : tv_e($w[0]), $o['within'])) . '</p>';
    }
    $h .= '</div>';
    $acts = (string) ($o['actions'] ?? '');   // views, likes, Share, Save, Claim: over the hero's foot (decisions/0058 §22)
    if (!empty($o['manage'])) {   // the owner chooses the photos and videos (decisions/0058 §21)
        [$mk, $mr] = $o['manage'];
        $acts .= '<button type="button" class="xh-own" title="Photos and video" aria-label="Photos and video" data-hm-kind="' . tv_e((string) $mk) . '" data-hm-ref="' . (int) $mr . '"><svg class="ta-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg><span>Photos &amp; video</span></button>';
        $acts .= '<script src="/js/hero-media.js" defer></script>';
    }
    // one camera per person (decisions/0058 §34): whoever runs the page chooses its photos and video ('manage' above);
    // everyone else shares theirs as a journey, which then shows here, credited
    if (empty($o['manage']) && !(array_key_exists('empty', $o) && !isset($o['share']))) {
        $acts .= '<a class="xh-a xh-shr" href="' . tv_e((string) ($o['share'] ?? '/user/journeys/compose.php')) . '" title="' . tv_e($slides ? 'Share your photos or video of ' . (string) ($o['photos_of'] ?? $name) : 'No photos of ' . (string) ($o['photos_of'] ?? $name) . ' yet. Be the first: share a photo or video') . '" aria-label="Share a photo or video">'
            . '<svg class="ta-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><path d="M12 10v6M9 13h6"/></svg></a>';
    }
    // a bar with ⋯ takes the camera in words, after Share and QR (Jason, 2026-11-19: "minimize how much real-estate is used on hero")
    if (strpos($acts, '<!--eg-more-->') !== false) {
        $cam = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>';
        $in = '';
        if (preg_match('#<button type="button" class="xh-own"[^>]*data-hm-kind="([^"]*)" data-hm-ref="(\d+)">.*?</button>#s', $acts, $mm)) {
            $acts = str_replace($mm[0], '', $acts); $in .= '<button type="button" role="menuitem" data-hm-kind="' . $mm[1] . '" data-hm-ref="' . $mm[2] . '">' . $cam . 'Photos and video</button>'; }
        if (preg_match('#<a class="xh-a xh-shr" href="([^"]*)".*?</a>#s', $acts, $mm)) {
            $acts = str_replace($mm[0], '', $acts); $in .= '<a role="menuitem" href="' . $mm[1] . '">' . $cam . 'Share a photo or video</a>'; }
        $acts = str_replace('<!--eg-more-->', $in, $acts);
    }
    if ($acts !== '') $h .= '<div class="xh-acts">' . $acts . '</div>';
    if (count($slides) > 1) $h .= '<button type="button" class="xh-arr l" data-xh="' . $id . '" data-d="-1" aria-label="Previous photo">&lsaquo;</button><button type="button" class="xh-arr r" data-xh="' . $id . '" data-d="1" aria-label="Next photo">&rsaquo;</button>';
    $h .= '</section>';
    if (!empty($o['tabs'])) {
        $h .= '<nav class="xh-tabs" aria-label="Explore by" style="grid-template-columns:repeat(' . count($o['tabs']) . ',1fr)">';
        foreach ($o['tabs'] as [$k, $label, $icon, $href]) {
            $on = ($o['active'] ?? '') === $k;
            $h .= '<a href="' . tv_e($href) . '"' . ($on ? ' class="on" aria-current="page"' : '') . '>' . tv_icon($icon) . '<span>' . tv_e($label) . '</span></a>';
        }
        $h .= '</nav>';
    }
    if (!empty($o['carousel'])) {   // cards of their own under the hero, two side by side on a phone, swiped left and right
        $cid = $id . '-c';
        $h .= '<section class="xh-car" aria-label="' . tv_e((string) ($o['carousel_label'] ?? 'More')) . '"><div class="xh-ct" id="' . $cid . '">' . $o['carousel'] . '</div>'
            . '<button type="button" class="xh-cn l" data-xh="' . $cid . '" data-d="-1" aria-label="Previous">&lsaquo;</button><button type="button" class="xh-cn r" data-xh="' . $cid . '" data-d="1" aria-label="Next">&rsaquo;</button></section>';
    }
    return $h;
}

/**
 * A photo card (decisions/0058 §18): regions, destinations, parks, experiences. $c: name, url ('' = not linked, shown
 * quieter), image ('' = the brand's art), badge, icon, kicker (under the name), text, stats (HTML pieces), chips.
 */
function tv_explore_card(array $c): string
{
    static $css = false;
    $c += ['image' => '', 'badge' => '', 'icon' => 'compass', 'kicker' => '', 'text' => '', 'stats' => [], 'chips' => [], 'url' => ''];
    $h = $css ? '' : tv_explore_card_css();
    $css = true;
    $bg = $c['image'] !== '' ? "background:url('" . tv_e($c['image']) . "') center/cover no-repeat" : tv_explore_art((string) $c['name']);
    $tag = $c['url'] !== '' ? 'a href="' . tv_e($c['url']) . '"' : 'div aria-disabled="true"';
    return $h . '<' . $tag . ' class="xc' . ($c['url'] === '' ? ' off' : '') . '"><span class="xc-art" style="' . $bg . '">' . ($c['badge'] !== '' ? '<em class="xc-badge' . ($c['url'] === '' ? ' soon' : '') . '">' . tv_e($c['badge']) . '</em>' : '')
        . '<span class="xc-ic">' . tv_icon((string) $c['icon']) . '</span><b>' . tv_e((string) $c['name']) . '</b>' . ($c['kicker'] !== '' ? '<small>' . tv_e((string) $c['kicker']) . '</small>' : '') . '</span>'
        . '<span class="xc-body">' . ($c['text'] !== '' ? '<span class="xc-text">' . tv_e((string) $c['text']) . '</span>' : '')
        . ($c['stats'] ? '<span class="xc-stats">' . implode('', array_map(fn ($x) => '<span>' . $x . '</span>', $c['stats'])) . '</span>' : '')
        . ($c['chips'] ? '<span class="xc-chips">' . implode('', array_map(fn ($x) => '<i>' . tv_e($x) . '</i>', $c['chips'])) . '</span>' : '')
        . '</span></' . ($c['url'] !== '' ? 'a' : 'div') . '>';
}

function tv_explore_card_css(): string
{
    return "<style>\n  /* the landing pages' cards (decisions/0058 §18) */
  .xl-lead{font-size:.95rem;color:var(--tv-meta);line-height:1.5;margin:0 0 .9rem;max-width:46rem}
  .xc-grid{display:grid;gap:.8rem;grid-template-columns:repeat(auto-fill,minmax(270px,1fr))}
  .xc{display:flex;flex-direction:column;background:var(--tv-card-a);border:1px solid var(--tv-line-strong);border-radius:1rem;overflow:hidden;text-decoration:none;color:var(--tv-ink);box-shadow:0 6px 16px -12px rgba(62,43,31,.45);transition:transform .15s,box-shadow .15s}
  a.xc:hover{transform:translateY(-2px);box-shadow:0 14px 24px -14px rgba(62,43,31,.55);border-color:var(--tv-line-strong)}
  .xc-art{position:relative;display:flex;flex-direction:column;justify-content:flex-end;aspect-ratio:16/9;padding:.8rem .9rem;color:var(--tv-on-umber)}
  .xc-art::before{content:\"\";position:absolute;inset:0;background:linear-gradient(180deg,rgba(30,20,12,0) 35%,rgba(30,20,12,.72))}
  .xc-art>*{position:relative}
  .xc-art b{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.3rem;line-height:1.15;text-shadow:0 2px 8px rgba(0,0,0,.5)}
  .xc-art small{font-size:.78rem;color:var(--tv-on-umber);margin-top:.15rem}
  .xc-ic{position:absolute;top:.75rem;left:.85rem;width:34px;height:34px;border-radius:999px;background:rgba(255,251,242,.18);border:1px solid rgba(255,251,242,.45);display:flex;align-items:center;justify-content:center}
  .xc-ic .ta-svg{color:var(--tv-on-umber);width:18px;height:18px}
  .xc-badge{position:absolute;top:.75rem;right:.75rem;font-style:normal;font-size:.62rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;border-radius:999px;padding:.2rem .55rem;background:var(--tv-sage);color:var(--tv-umber)}
  .xc-badge.soon{background:rgba(255,251,242,.85);color:var(--tv-meta)}
  .xc-body{display:flex;flex-direction:column;gap:.45rem;padding:.7rem .9rem .85rem}
  .xc-text{font-size:.85rem;color:var(--tv-meta);line-height:1.45}
  .xc-stats{display:flex;flex-wrap:wrap;gap:.25rem .8rem;font-size:.78rem;color:var(--tv-meta)}.xc-stats b{color:var(--tv-ink)}
  .xc-chips{display:flex;flex-wrap:wrap;gap:.3rem}.xc-chips i{font-style:normal;font-size:.72rem;border:1px solid var(--tv-line);border-radius:999px;padding:.1rem .5rem;color:var(--tv-meta);background:var(--tv-canvas)}
  .xc.off{opacity:.78}.xc.off .xc-art{filter:saturate(.35)}
  @media (max-width:767px){.xc-grid{gap:3px}.xc{border-radius:.5rem}.xl-lead{margin:.2rem 0 .7rem}}
</style>";
}

/** A card's background with no photo: a gradient in the brand's earth tones picked by name, with a quiet topo line. */
function tv_explore_art(string $seed, bool $dark = false): string
{
    $pal = [['#7A5A3A', '#3E2B1F'], ['#8C6A3F', '#4A3523'], ['#5E6B4A', '#2F3A26'], ['#8A5A44', '#47291D'], ['#6B5B7A', '#352B40'], ['#4F6D73', '#24363A'], ['#9A7B4F', '#4E3B22']];
    [$a, $b] = $pal[abs(crc32($seed)) % count($pal)];
    $topo = "url('data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27240%27 height=%27160%27 viewBox=%270 0 240 160%27%3E%3Cg fill=%27none%27 stroke=%27%23FFFBF2%27 stroke-opacity=%27.13%27 stroke-width=%271.2%27%3E%3Cpath d=%27M-10 120c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3Cpath d=%27M-10 95c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3Cpath d=%27M-10 145c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3Cpath d=%27M-10 70c40-30 70 10 110-15s60-55 100-30 40 20 60 10%27/%3E%3C/g%3E%3C/svg%3E')";   // no double quotes: it goes in a style=\"\" attribute
    return 'background:' . $topo . ',linear-gradient(135deg,' . $a . ' 0%,' . $b . ' ' . ($dark ? '70' : '100') . '%)';
}

function tv_explore_hero_css(): string
{
    return <<<'CSS'
<style>
  .xh{position:relative;border-radius:1.1rem 1.1rem 0 0;overflow:hidden;background:var(--tv-umber);aspect-ratio:21/9;min-height:250px}
  .xh.xh-solo{border-radius:1.1rem}
  .xh-track{display:flex;height:100%;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none}.xh-track::-webkit-scrollbar{display:none}
  .xh-slide{flex:0 0 100%;scroll-snap-align:start;position:relative;background:#5A4330 center/cover no-repeat;text-decoration:none;color:var(--tv-ink)}
  .xh-slide::after{content:"";position:absolute;inset:0 0 auto 0;height:50%;background:linear-gradient(180deg,rgba(30,20,12,.72),rgba(30,20,12,.35) 55%,rgba(30,20,12,0));pointer-events:none}
  /* the photo's credit: small words in the bottom-left corner, no card (decisions/0058 §28) */
  .xh-slide::before{content:"";position:absolute;inset:auto 0 0 0;height:38%;background:linear-gradient(0deg,rgba(20,13,8,.62),rgba(20,13,8,0));pointer-events:none}
  .xh-cap{position:absolute;z-index:1;left:1rem;bottom:.8rem;max-width:min(17rem,44%);background:rgba(255,251,242,.14);border:1px solid rgba(255,251,242,.45);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);color:var(--tv-on-umber);text-shadow:0 1px 3px rgba(0,0,0,.75);border-radius:.45rem;padding:.32rem .5rem .36rem;font-size:.66rem;line-height:1.35;box-shadow:0 6px 16px -10px rgba(0,0,0,.6)}
  .xh-cap>span:first-child{display:block;font-weight:600}
  .xh-stkw{position:absolute;z-index:3;left:1rem;bottom:.8rem;max-width:44%;display:flex;flex-direction:column;align-items:flex-start;gap:.35rem}
  @media (max-width:767px){.xh-stkw{left:.6rem;bottom:3.4rem;max-width:calc(100% - 1.2rem)}}
  .xh-cred{display:flex;align-items:center;gap:.3rem;margin-top:.2rem;font-size:.62rem;color:var(--tv-on-umber)}.xh-cred b{flex:1;font-weight:700;text-transform:uppercase;letter-spacing:.03em}.xh-cred .jr-av{width:15px;height:15px;font-size:.52rem}
  .xh-capb{display:inline-block;margin-top:.25rem;background:rgba(255,251,242,.16);border:1px solid rgba(255,251,242,.55);color:var(--tv-on-umber);text-shadow:none;border-radius:999px;padding:.16rem .55rem;font-size:.64rem;font-weight:600;text-decoration:none}
  .xh-head{position:absolute;z-index:2;left:1rem;right:1rem;top:.85rem;display:flex;flex-wrap:wrap;align-items:center;gap:.25rem .5rem;pointer-events:none}
  .xh-head>*{pointer-events:auto}
  .xh-title{margin:0;display:flex;align-items:center;gap:.5rem;min-width:0;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.2rem,2.4vw,1.7rem);line-height:1.15;color:var(--tv-on-umber);text-shadow:0 2px 8px rgba(0,0,0,.6);pointer-events:none}
  .xh-title .ta-svg{color:var(--tv-on-umber);width:26px;height:26px;flex:0 0 26px}
  .xh-edit{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:999px;border:1px solid rgba(255,251,242,.6);background:rgba(62,43,31,.45);color:var(--tv-on-umber);cursor:pointer;padding:0;backdrop-filter:blur(2px)}
  .xh-edit svg{width:15px;height:15px}.xh-edit:hover{background:rgba(62,43,31,.75);border-color:var(--tv-on-umber)}
  .xh-head [data-link]{margin-left:auto}
  .xh-in{order:9;flex:0 0 100%;margin:0;font-size:.82rem;color:var(--tv-on-umber);text-shadow:0 1px 6px rgba(0,0,0,.8)}
  .xh-in a{color:var(--tv-on-umber);text-decoration:underline;text-decoration-color:rgba(255,251,242,.45);text-underline-offset:3px}
  .xh-arr{position:absolute;top:50%;transform:translateY(-50%);width:34px;height:52px;border:0;background:rgba(62,43,31,.55);color:var(--tv-on-umber);font-size:1.8rem;cursor:pointer}
  .xh-arr.l{left:0;border-radius:0 .6rem .6rem 0}.xh-arr.r{right:0;border-radius:.6rem 0 0 .6rem}
  .xh-tabs{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--tv-line-strong);border-top:0;border-radius:0 0 .9rem .9rem;overflow:hidden;background:color-mix(in srgb,#fff 55%,var(--tv-canvas));margin-bottom:1rem}
  .xh-tabs a{display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.65rem .5rem;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.05rem;color:var(--tv-ink);text-decoration:none;border-left:1px solid var(--tv-line-strong);position:relative}
  .xh-tabs a:first-child{border-left:0}.xh-tabs a:hover{background:var(--tv-canvas)}.xh-tabs .ta-svg{color:var(--tv-icon,#B45309)}
  /* the open tab, sage (Jason, 2026-11-19: "The active state feels lacking", chose B): a sage fill, a full-width bar, the
     icon with the active glow (CLAUDE.md's icons: active sage with a soft glow) */
  .xh-tabs a.on{background:color-mix(in srgb,var(--tv-sage) 38%,#fff);color:var(--tv-umber)}
  .xh-tabs a.on::after{content:"";position:absolute;left:0;right:0;bottom:0;height:4px;background:color-mix(in srgb,var(--tv-moss) 70%,var(--tv-sage))}
  .xh-tabs a.on .ta-svg{color:var(--tv-umber);filter:drop-shadow(0 0 4px rgba(146,190,165,.9))}
  .xh-tabs a.on:hover{background:color-mix(in srgb,var(--tv-sage) 48%,#fff)}
  .xh-solo{margin-bottom:1rem}
  .tv-page > .xh{margin-top:0 !important}   /* Tailwind's space-y on the page wrapper: the hero is the page's top (decisions/0058 §21) */
  .xh-vid{background:#000}.xh-vid iframe{width:100%;height:100%;border:0;display:block}
  .xh-own{flex:0 0 auto;margin-left:auto;display:inline-flex;align-items:center;gap:.35rem;border-radius:999px;border:1px solid rgba(255,251,242,.5);background:rgba(255,251,242,.12);-webkit-backdrop-filter:blur(6px);color:var(--tv-on-umber);font:inherit;font-size:.78rem;font-weight:700;padding:.35rem .7rem;cursor:pointer;backdrop-filter:blur(2px)}
  .xh-own .ta-svg{width:15px;height:15px;color:var(--tv-on-umber)}.xh-own:hover{background:rgba(255,251,242,.24)}
  .xh-head.xh-haslink{padding-right:3.4rem}.xh-title{flex:0 1 auto}
  .xh-title span{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
  /* the foot of the hero: the page's actions over the photo, on a dark band */
  /* the page's buttons: the bottom-right corner; the credit keeps the left (decisions/0058 §28) */
  .xh-acts{position:absolute;left:auto;right:0;bottom:0;z-index:2;max-width:58%;display:flex;flex-wrap:wrap-reverse;justify-content:flex-end;align-items:center;gap:.3rem;padding:0 .75rem .65rem}
  .xh-acts .eg-bar{margin:0;justify-content:flex-end}.xh-acts .eg-bar .eg-n{color:var(--tv-on-umber);text-shadow:0 1px 4px rgba(0,0,0,.8);padding:0 .25rem}.xh-acts .eg-bar .eg-n svg{color:var(--tv-on-umber)}
  .xh-acts .eg-b,.xh-acts [data-contact-save] button,.xh-acts .xh-a{border-color:rgba(255,251,242,.5);background:rgba(255,251,242,.12);color:var(--tv-on-umber);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);text-shadow:0 1px 3px rgba(0,0,0,.6)}
  .xh-acts .eg-b svg{color:var(--tv-on-umber)}.xh-acts .eg-b[aria-pressed="true"]{background:var(--tv-sage);color:var(--tv-umber)}
  .xh-acts .tv-save{border-color:rgba(255,251,242,.5) !important;background:rgba(255,251,242,.12) !important;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);color:var(--tv-on-umber) !important;font-size:.8rem !important;padding:.28rem .7rem !important;border-radius:999px !important}.xh-acts .tv-save svg{color:var(--tv-on-umber) !important}
  .xh-acts .tv-save span{display:none}.xh-acts .tv-save::after{content:"Save"}.xh-acts .tv-save.on::after{content:"Saved"}   /* short on the hero; its title says it's private */
  .xh-a{display:inline-flex;align-items:center;gap:.3rem;border:1px solid;border-radius:999px;padding:.28rem .75rem;font-size:.8rem;font-weight:700;text-decoration:none;line-height:1.2}
  .xh-a.go,.xh-corner .xh-a.go{background:var(--tv-btn) !important;border-color:color-mix(in srgb,#E4DCC5 70%,transparent) !important;color:var(--tv-btn-text) !important;text-shadow:none;-webkit-backdrop-filter:none;backdrop-filter:none;font-size:.9rem;padding:.42rem 1rem}
  .xh-a.go:hover,.xh-corner .xh-a.go:hover{background:var(--tv-btn-hover) !important}
  .xh-a.go .ta-svg{width:16px;height:16px;color:var(--tv-btn-text)}
  .xh-corner small{display:block;margin-top:.25rem;text-align:right;font-size:.72rem;color:var(--tv-on-umber);text-shadow:0 1px 3px rgba(0,0,0,.7)}
  .xh-corner:has(small){flex-direction:column;align-items:flex-end}
  .xh:has(.xh-acts) .xh-cap{bottom:.85rem}
  .xh:not(:has(.xh-cap)) .xh-acts{max-width:none;flex-wrap:nowrap}   /* no credit card: the buttons get the whole row */
  .xh-acts .eg-b{min-height:32px;padding:.28rem .65rem;gap:.35rem}.xh-acts .eg-b span{font-weight:700;color:var(--tv-on-umber);font-variant-numeric:tabular-nums}
  .xh-acts .eg-b svg{width:16px;height:16px}
  /* a phone: one row. Counts keep their numbers; Share and Photos & video become icons (their titles say what they are) */
  @media (max-width:640px){.xh-acts{gap:.25rem;padding:0 .6rem .55rem}.xh-acts .eg-bar{flex-wrap:wrap-reverse;justify-content:flex-end}
    .xh-acts .eg-bar{flex-wrap:nowrap;gap:.3rem}
    .xh-acts .tv-save::after{content:none !important}.xh-acts .tv-save{width:32px;height:32px;padding:0 !important;justify-content:center}   /* Save: an icon on a phone */
    .xh-acts [data-eg-share] span,.xh-own span{display:none}.xh-acts [data-eg-share],.xh-own{width:32px;height:32px;padding:0;justify-content:center}
    .xh-acts .eg-b.r{display:none}}
  /* the carousel under the hero: whole cards snap into place; two on a phone, three or four on wider screens */
  .xh-car{position:relative;margin:0 0 1.1rem}
  .xh-ct{display:flex;gap:.7rem;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;padding:2px 0 6px}.xh-ct::-webkit-scrollbar{display:none}
  .xh-ct>*{flex:0 0 calc((100% - 2.1rem) / 4);scroll-snap-align:start;min-width:0}
  .xh-ct .xc-art{aspect-ratio:4/3}.xh-ct .xc-art b{font-size:1.1rem}
  .xh-ct .xc-text{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
  .xh-cn{position:absolute;top:35%;width:34px;height:34px;border-radius:999px;border:1px solid var(--tv-line-strong);background:var(--tv-field);color:var(--tv-ink);font-size:1.3rem;line-height:1;cursor:pointer;box-shadow:0 6px 14px -8px rgba(0,0,0,.5);z-index:2}
  .xh-cn.l{left:-10px}.xh-cn.r{right:-10px}.xh-cn:hover{border-color:var(--tv-line-strong)}
  @media (max-width:1100px){.xh-ct>*{flex-basis:calc((100% - 1.4rem) / 3)}}
  /* phones: edge to edge, right under the tool bar (decisions/0058 §11) */
  @media (max-width:767px){.ta-body:has(.xh),.tv-main:has(> .xh),body:not(.tv-back):has(#ta-rail) .ta-body:has(.xh){margin-top:0}   /* the rail's 1.1rem (app-shell) outranked the plain rule: a 23px band above the hero (2026-11-10, layout probe) */
    .tv-page > .xh{margin-top:-.8rem !important}
    .xh{margin:-.8rem calc(-1 * var(--tv-pad, .85rem)) 0;border-radius:0}.xh.xh-solo{border-radius:0;margin-bottom:.8rem}
    .xh-tabs{margin:0 calc(-1 * var(--tv-pad, .85rem)) .8rem;border-radius:0;border-left:0;border-right:0}
    .xh-car{margin:0 calc(3px - var(--tv-pad, .85rem)) .8rem}.xh-ct{gap:3px;padding:0}
    .xh-ct>*{flex-basis:calc((100% - 3px) / 2)}.xh-ct .xc{border-radius:.5rem}.xh-ct .xc-art{aspect-ratio:4/5;padding:.6rem .65rem}.xh-ct .xc-art b{font-size:1rem}
    .xh-ct .xc-body{padding:.5rem .6rem .6rem;gap:.3rem}.xh-ct .xc-text{font-size:.78rem;-webkit-line-clamp:2}.xh-ct .xc-stats{font-size:.72rem;gap:.15rem .5rem}
    .xh-ct .xc-chips{display:none}.xh-ct .xc-ic{width:28px;height:28px;top:.5rem;left:.55rem}.xh-ct .xc-badge{top:.55rem;right:.5rem}
    .xh-cn{display:none}}
  @media (max-width:640px){.xh{aspect-ratio:4/3}.xh-tabs a{font-size:.88rem;flex-direction:column;gap:.2rem}.xh-cap{left:.6rem;bottom:.6rem;max-width:46%}.xh-head{left:.75rem;right:.75rem}.xh-title{font-size:1.25rem}}
  /* wider screens, as on a phone (decisions/0058 §33): flush with the top bar and the toolbar, square corners, and a
     height that fits the screen instead of a wide 21:9 frame */
  @media (min-width:768px){.ta-body:has(.xh),body:not(.tv-back):has(#ta-rail) .ta-body:has(.xh){margin-top:0}
    .ta-work .xh{margin:-1.1rem calc(-1 * clamp(1rem,3vw,2.5rem)) 0;border-radius:0;aspect-ratio:auto;min-height:0;height:clamp(300px,50vh,480px)}
    .ta-work .tv-page > .xh{margin-top:-1.1rem !important}
    .ta-work .xh.xh-solo{border-radius:0;margin-bottom:1rem}
    .ta-work .xh-tabs{margin-left:calc(-1 * clamp(1rem,3vw,2.5rem));margin-right:calc(-1 * clamp(1rem,3vw,2.5rem));border-radius:0;border-left:0;border-right:0}
  }
  /* no photos: a band as tall as its title and the line under it, with the buttons' row below (decisions/0058 §34) */
  .xh.xh-nophoto,.ta-work .xh.xh-nophoto{aspect-ratio:auto;min-height:0;height:auto}
  .xh-nophoto .xh-track{position:absolute;inset:0}
  .xh-nophoto .xh-head{position:relative;left:auto;right:auto;top:auto;padding:.85rem 1rem 3.4rem}
  @media (max-width:640px){.xh-nophoto .xh-head{padding:.75rem .75rem 3.1rem}}
  /* the top-right corner (Claim, Manage); the camera button is an icon like Share */
  .xh-corner{margin-left:auto;align-self:flex-start;display:flex;gap:.3rem}
  .xh-corner .xh-a{border-color:rgba(255,251,242,.5);background:rgba(255,251,242,.12);color:var(--tv-on-umber);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);text-shadow:0 1px 3px rgba(0,0,0,.6)}
  .xh-acts .xh-shr{width:32px;height:32px;padding:0;justify-content:center}.xh-shr .ta-svg{width:16px;height:16px;color:var(--tv-on-umber)}
</style>
<style>
  .xh-zoom{cursor:zoom-in}
  .xlb{position:fixed;inset:0;z-index:3000;background:rgba(15,10,6,.9);-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;flex-direction:column;align-items:center;justify-content:center;touch-action:pan-y}
  .xlb img{max-width:100vw;max-height:76vh;max-height:76dvh;object-fit:contain;display:block;user-select:none;-webkit-user-drag:none}
  .xlb-cap{color:var(--tv-on-umber);font-size:.82rem;line-height:1.4;text-align:center;max-width:40rem;padding:.6rem 1rem 0}
  .xlb-n{color:var(--tv-on-umber-meta);font-size:.72rem;margin-top:.2rem}
  .xlb button{position:absolute;border:1px solid rgba(255,251,242,.45);background:rgba(255,251,242,.12);color:var(--tv-on-umber);border-radius:999px;cursor:pointer;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}
  .xlb .x{top:max(.8rem,env(safe-area-inset-top));right:.8rem;width:40px;height:40px;font-size:1.5rem;line-height:1}
  /* what's in the photo (Jason, 2026-11-19: "a way for the view to see the location/url of the subject") */
  .xlb-sub{position:absolute;left:.8rem;right:4rem;top:max(.8rem,env(safe-area-inset-top));display:flex;flex-wrap:wrap;align-items:center;gap:.4rem;color:var(--tv-on-umber);font-size:.86rem}
  .xlb-sub a.xlb-to{color:var(--tv-on-umber);font:700 1rem var(--tv-font-head,ui-serif,Georgia,serif);text-decoration:underline;text-underline-offset:3px;margin-right:.3rem}
  .xlb .xlb-sub button{position:static;font-size:.8rem;font-weight:600;padding:.3rem .7rem;min-height:32px}
  .xlb .eg-ml button,.xlb .eg-mx{position:static}.xlb .eg-ml{color:var(--tv-ink)}
  @media (max-width:640px){.xlb-sub{right:3.6rem}.xlb-sub a.xlb-to{flex-basis:100%}}
  .xlb-acts .eg-bar{display:flex;align-items:center}.xlb-acts .eg-b{display:inline-flex;align-items:center;gap:.3rem;border-radius:999px;padding:.3rem .75rem;font-weight:600;text-decoration:none;cursor:pointer}   /* also where the page has no bar of its own */
  .xlb-acts{position:absolute;left:0;right:0;bottom:max(1rem,env(safe-area-inset-bottom));display:flex;justify-content:center;padding:0 .75rem}
  .xlb-acts .eg-bar{margin:0;justify-content:center;flex-wrap:wrap;gap:.35rem}
  .xlb-acts .eg-n{color:var(--tv-on-umber);display:inline-flex;align-items:center;gap:.3rem;font-size:.82rem;font-weight:700;padding:0 .3rem}.xlb-acts .eg-n svg{width:16px;height:16px;color:var(--tv-on-umber)}
  .xlb-acts .eg-b{position:static;transform:none;width:auto;height:auto;min-height:34px;font-size:.82rem;border:1px solid rgba(255,251,242,.45);background:rgba(255,251,242,.12);color:var(--tv-on-umber)}
  .xlb-acts .eg-b svg{color:var(--tv-on-umber);width:16px;height:16px}.xlb-acts .eg-b[aria-pressed="true"]{background:var(--tv-sage);border-color:var(--tv-sage);color:var(--tv-umber)}.xlb-acts .eg-b[aria-pressed="true"] svg{color:var(--tv-umber)}
  .xlb-acts .eg-b.r{display:inline-flex}
  .xlb .p,.xlb .n{top:50%;transform:translateY(-50%);width:40px;height:56px;font-size:1.8rem}.xlb .p{left:.5rem}.xlb .n{right:.5rem}
</style>
<script>
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-xh]'); if (!b) return;
    var tr = document.getElementById(b.getAttribute('data-xh')); if (tr) tr.scrollBy({ left: tr.clientWidth * +b.getAttribute('data-d'), behavior: 'smooth' });
  });
  // the lightbox: a tap on a hero photo opens it full screen; arrows, swipe and the keys move between the hero's photos (decisions/0058 §28)
  (function () {
    if (window.tvLightbox) return; window.tvLightbox = true;
    var box = null, list = [], at = 0, back = null, x0 = null;
    function show() {
      var it = list[at]; box.querySelector('img').src = it.src; box.querySelector('img').alt = it.cap || 'Photo';
      box.querySelector('.xlb-cap').textContent = it.cap || '';
      box.querySelector('.xlb-n').textContent = list.length > 1 ? (at + 1) + ' of ' + list.length : '';
      subject(it);
    }
    // what's in the photo: its name (a link to its page), See on the map, Copy link; and its own counts when it isn't this page
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    var seq = 0;
    function subject(it) {
      var sub = box.querySelector('.xlb-sub'), acts = box.querySelector('.xlb-acts'), page = !it.href;
      var name = page ? pageName : it.name, href = page ? location.pathname + location.search : it.href;
      var mapBtn = page ? (src && src.querySelector('[data-eg-click]')) : null;
      sub.innerHTML = (name ? '<a class="xlb-to" href="' + esc(href) + '">' + esc(name) + '</a>' : '')
        + (page ? (mapBtn ? '<button type="button" data-xlb="pmap">See on the map</button>' : '') : (it.lat != null ? '<button type="button" data-xlb="map">See on the map</button>' : ''))
        + (name ? '<button type="button" data-xlb="copy">Copy link</button>' : '');
      sub.hidden = !sub.innerHTML;
      if (page) { acts.innerHTML = ''; if (src) acts.appendChild(src.cloneNode(true)); acts.hidden = !src; return; }
      acts.innerHTML = ''; acts.hidden = true; var my = ++seq;
      if (!it.kind) return;
      fetch('/api/engage.php?counts=1&kind=' + encodeURIComponent(it.kind) + '&ref=' + encodeURIComponent(it.ref), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
        if (my !== seq || !box || !d.ok) return;
        var ic = function (p) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
        acts.innerHTML = '<div class="eg-bar" data-eg-kind="' + esc(it.kind) + '" data-eg-ref="' + esc(it.ref) + '" data-eg-title="' + esc(it.name) + '">'
          + '<span class="eg-n" title="' + d.views + ' ' + (d.views === 1 ? 'visit' : 'visits') + ' saw its page"' + ' aria-label="' + d.views + ' views">' + ic('<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>') + '<span>' + d.views + '</span></span>'
          + (d.like ? '<button type="button" class="eg-b" data-eg-like aria-pressed="' + (d.liked ? 'true' : 'false') + '" title="Like">' + ic('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>') + '<span>' + d.likes + '</span></button>' : '')
          + '<a class="eg-b" href="' + esc(it.href) + '#comments" title="Comments on its page">' + ic('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>') + '<span>' + d.comments + '</span></a></div>';
        acts.hidden = false;
        if (!window.tvEngage && !document.querySelector('script[src^="/js/engage.js"]')) { var sc = document.createElement('script'); sc.src = '/js/engage.js'; document.head.appendChild(sc); }   // Like works here too
      }).catch(function () {});
    }
    var pageName = '';
    function mapAt(it) {   // the map around what's in the photo, with what's near it (as its own page's map does)
      if (!window.TvMap) return;
      var here = { lat: +it.lat, lon: +it.lon, radius: 10 }, id = it.kind === 'lm' ? 'rec:g' + ('0000000000' + it.ref).slice(-10) : '';
      TvMap.open({ panel: true, title: it.name, radius: 10, select: id || undefined,
        titleFor: function () { return 'Around ' + it.name; },
        load: function (area, words) {
          var a = area || here, qs = new URLSearchParams({ pins: 1, kinds: words ? 'listing,outdoors' : 'outdoors', lat: a.lat, lon: a.lon, radius: a.radius }); if (words) qs.set('q', words);
          return fetch('/api/search.php?' + qs.toString(), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
            if (id && !(d.pins || []).some(function (p) { return p.id === id; })) (d.pins = d.pins || []).push({ id: id, lat: here.lat, lon: here.lon, name: it.name });
            d.center = a; return d; });
        } });
    }
    window.tvMapAround = function (p) { mapAt({ lat: p.lat, lon: p.lon, name: p.name || '', kind: '', ref: '' }); };
    function step(d) { if (list.length > 1) { at = (at + d + list.length) % list.length; show(); } }
    var src = null;   // the hero's own bar, kept in step with the lightbox's copy (a like made here shows there)
    function close() {
      if (!box) return;
      var copy = box.querySelector('.xlb-acts .eg-bar');
      if (copy && src && copy.getAttribute('data-eg-ref') === src.getAttribute('data-eg-ref') && copy.getAttribute('data-eg-kind') === src.getAttribute('data-eg-kind')) { var a = copy.querySelector('[data-eg-like]'), b = src.querySelector('[data-eg-like]'); if (a && b) b.outerHTML = a.outerHTML; }   // the page's own bar only
      box.remove(); box = null; src = null; document.documentElement.style.overflow = ''; if (back) back.focus();
    }
    function open(slide) {
      var track = slide.parentNode;
      list = Array.prototype.map.call(track.querySelectorAll('[data-lb]'), function (s) { return { src: s.getAttribute('data-lb'), cap: s.getAttribute('data-lb-cap') || (s.querySelector('.xh-cap') ? s.querySelector('.xh-cap').textContent : ''),
        name: s.getAttribute('data-lb-name') || '', href: s.getAttribute('data-lb-href') || '', kind: s.getAttribute('data-lb-kind') || '', ref: s.getAttribute('data-lb-ref') || '',
        lat: s.hasAttribute('data-lb-lat') ? +s.getAttribute('data-lb-lat') : null, lon: s.hasAttribute('data-lb-lon') ? +s.getAttribute('data-lb-lon') : null }; });
      var hx = slide.closest('.xh'); pageName = hx ? (hx.getAttribute('data-xh-name') || '') : '';
      at = Math.max(0, Array.prototype.indexOf.call(track.querySelectorAll('[data-lb]'), slide)); back = slide;
      box = document.createElement('div'); box.className = 'xlb'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'Photo');
      box.innerHTML = '<div class="xlb-sub" hidden></div><img alt=""><p class="xlb-cap"></p><p class="xlb-n"></p><button type="button" class="x" aria-label="Close">&times;</button>'
        + (list.length > 1 ? '<button type="button" class="p" aria-label="Previous photo">&lsaquo;</button><button type="button" class="n" aria-label="Next photo">&rsaquo;</button>' : '');
      // the page's social buttons come along: views, likes, comments, Share (js/engage.js handles them by their bar's data)
      var bar = slide.closest('.xh') && slide.closest('.xh').querySelector('.xh-acts .eg-bar');
      var acts = document.createElement('div'); acts.className = 'xlb-acts'; acts.hidden = true; box.appendChild(acts); src = bar || null;   // filled per photo (subject())
      document.body.appendChild(box); document.documentElement.style.overflow = 'hidden'; show(); box.querySelector('.x').focus();
      box.addEventListener('click', function (ev) {
        if (ev.target.closest('.xlb-acts')) {   // Comments: close and go to them; a tool that leaves the viewer closes it; the rest work in place
          if (ev.target.closest('a[href="#comments"]')) close();
          else if (ev.target.closest('[data-eg-click], [data-eg-map], [data-eg-trip], [data-tv-suggest], [data-eg-report]')) setTimeout(close, 0);   // after the tool has run
          return;
        }
        var xb = ev.target.closest('[data-xlb]');
        if (xb) { var it = list[at], k = xb.getAttribute('data-xlb');
          if (k === 'copy') { var u = location.origin + (it.href || (location.pathname + location.search)); var ok = function () { if (window.TvAsk) TvAsk.say('Link copied', { anchor: xb }); };
            if (navigator.clipboard) navigator.clipboard.writeText(u).then(ok, function () { if (window.TvAsk) TvAsk.ask('Copy this link', u); }); else if (window.TvAsk) TvAsk.ask('Copy this link', u); }
          else if (k === 'map') { close(); mapAt(it); }
          else if (k === 'pmap') { var mb = src && src.querySelector('[data-eg-click]'), el = mb && document.querySelector(mb.getAttribute('data-eg-click')); close(); if (el) el.click(); }
          return; }
        if (ev.target.closest('.xlb-sub')) return;
        if (ev.target.closest('.p')) return step(-1);
        if (ev.target.closest('.n')) return step(1);
        if (ev.target.closest('.x') || !ev.target.closest('img')) close();
      });
      box.addEventListener('touchstart', function (ev) { x0 = ev.touches[0].clientX; }, { passive: true });
      box.addEventListener('touchend', function (ev) { if (x0 === null) return; var dx = ev.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) > 40) step(dx < 0 ? 1 : -1); });
    }
    document.addEventListener('click', function (e) {
      var s = e.target.closest('[data-lb]'); if (!s || e.target.closest('a, button')) return;
      e.preventDefault(); open(s);
    });
    document.addEventListener('keydown', function (e) {
      if (!box) { var s = e.target.closest && e.target.closest('[data-lb]'); if (s && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); open(s); } return; }
      if (e.key === 'Escape') close(); else if (e.key === 'ArrowLeft') step(-1); else if (e.key === 'ArrowRight') step(1);
    });
  })();
</script>
CSS;
}
