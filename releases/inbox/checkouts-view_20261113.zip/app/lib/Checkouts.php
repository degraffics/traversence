<?php
// app/lib/Checkouts.php — what's checked out (decisions/0161 §10): the site files Claude sessions have claimed while
// writing a release, read from releases/checkouts.json in the docs repo (written by tools/page-audit/checkout.py; public,
// no key, no cost, kept 10 minutes by DocsRepo). Shown in the site manager's Releases ▾ and as a step of Pulse's Site
// health: the file, who, why, since when, and claims near expiry. Read only: claims are taken and released in git.
declare(strict_types=1);

require_once __DIR__ . '/DocsRepo.php';

final class Checkouts
{
    public const PATH = 'releases/checkouts.json';
    /** a claim this close to its 4-hour expiry is flagged */
    public const NEAR = 1800;

    /** ['ok' => bool, 'claims' => [...] (active, oldest first), 'lapsed' => [...] (newest first, up to 5)] */
    public static function now(bool $fresh = false): array
    {
        $raw = DocsRepo::raw(self::PATH, $fresh);
        $d = $raw !== null ? json_decode($raw, true) : null;
        if (!is_array($d)) return ['ok' => false, 'claims' => [], 'lapsed' => []];
        $t = time();
        $one = function ($c) use ($t): ?array {
            if (!is_array($c) || !is_string($c['path'] ?? null) || !preg_match('#^(website|app|trvgo|workers)/[\w./-]+$#', $c['path'])) return null;
            $since = strtotime((string) ($c['since'] ?? '')) ?: 0;
            $until = strtotime((string) ($c['expires'] ?? '')) ?: 0;
            $s = fn (string $k, int $n) => mb_substr(trim((string) ($c[$k] ?? '')), 0, $n);
            return ['path' => $c['path'], 'functions' => array_slice(array_map(fn ($f) => mb_substr((string) $f, 0, 80), (array) ($c['functions'] ?? [])), 0, 12),
                    'kind' => ($c['kind'] ?? '') === 'change' ? 'change' : 'add', 'session' => preg_match('/^session_[A-Za-z0-9]+$/', (string) ($c['session'] ?? '')) ? (string) $c['session'] : $s('session', 60),
                    'why' => $s('why', 200), 'release' => $s('release', 120), 'since' => $since, 'until' => $until,
                    'near' => $until > $t && $until - $t < self::NEAR, 'callers' => array_sum(array_map('count', (array) ($c['callers'] ?? [])))];
        };
        $claims = []; $lapsed = [];
        foreach ((array) ($d['claims'] ?? []) as $c) if (($x = $one($c)) !== null) { if ($x['until'] > $t) $claims[] = $x; else $lapsed[] = $x; }
        foreach (array_slice((array) ($d['lapsed'] ?? []), 0, 5) as $c) if (($x = $one($c)) !== null) $lapsed[] = $x;
        usort($claims, fn ($a, $b) => $a['since'] <=> $b['since']);
        return ['ok' => true, 'claims' => $claims, 'lapsed' => array_slice($lapsed, 0, 5)];
    }

    /** "app/lib/LocalWords.php::match" */
    public static function what(array $c): string
    {
        return $c['path'] . ($c['functions'] ? '::' . implode(',', $c['functions']) : '');
    }

    /** The session's page in Claude Code, where Jason can read or message it. */
    public static function sessionUrl(string $s): string
    {
        return preg_match('/^session_[A-Za-z0-9]+$/', $s) ? 'https://claude.ai/code/' . $s : '';
    }

    private static function short(string $s): string { return str_starts_with($s, 'session_') ? '…' . substr($s, -6) : $s; }

    /** "Change, by session …abc123: fix the search (since Nov 13, 3:10 PM UTC; until 7:10 PM UTC, near expiry)" */
    public static function line(array $c): string
    {
        $at = fn (int $x) => $x ? gmdate('M j, g:i A', $x) . ' UTC' : '';
        return ($c['kind'] === 'change' ? 'Change' : 'Add') . ', by session ' . self::short($c['session']) . ($c['why'] !== '' ? ': ' . $c['why'] : '')
            . ' (since ' . $at($c['since']) . '; until ' . gmdate('g:i A', $c['until']) . ' UTC' . ($c['near'] ? ', near expiry' : '') . ')'
            . ($c['callers'] ? ' · ' . $c['callers'] . ' caller' . ($c['callers'] === 1 ? '' : 's') . ' on the live site' : '');
    }

    /** For the site manager's Releases ▾: [what, kind, session, session_url, why, since, until (unix), near, line]. */
    public static function forBar(): array
    {
        $n = self::now();
        $out = [];
        foreach ($n['claims'] as $c) $out[] = ['what' => self::what($c), 'kind' => $c['kind'], 'session' => $c['session'], 'session_url' => self::sessionUrl($c['session']),
            'why' => $c['why'], 'since' => $c['since'], 'until' => $c['until'], 'near' => $c['near'], 'line' => self::line($c)];
        return ['ok' => $n['ok'], 'claims' => $out, 'lapsed' => count($n['lapsed']), 'url' => DocsRepo::webUrl(self::PATH)];
    }

    /** A step for Pulse's Site health: what's checked out now, or null when nothing is. */
    public static function step(): ?array
    {
        $n = self::now();
        if (!$n['claims'] && !$n['lapsed']) return null;
        $near = count(array_filter($n['claims'], fn ($c) => $c['near']));
        $lines = array_map(fn ($c) => self::what($c) . ': ' . self::line($c), array_slice($n['claims'], 0, 12));
        if (count($n['claims']) > 12) $lines[] = 'and ' . (count($n['claims']) - 12) . ' more';
        foreach ($n['lapsed'] as $c) $lines[] = 'Lapsed (no release within 4 hours): ' . self::what($c) . ', session ' . self::short($c['session']);
        return ['t' => 'Checked out now: ' . count($n['claims']) . ' file' . (count($n['claims']) === 1 ? '' : 's') . ($near ? ', ' . $near . ' near expiry' : ''),
                'h' => 'Files Claude sessions are writing a release for (decisions/0161). Adding is shared; a change holds only the functions named, for one release. ' . implode(' · ', $lines) . '.',
                'act' => null, 'auto' => false, 'ext' => ['what\'s checked out, in git', DocsRepo::webUrl(self::PATH)]];
    }
}
