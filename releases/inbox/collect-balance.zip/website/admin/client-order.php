<?php
// admin/client-order.php — an order our team builds for a client (E-Commerce → Orders → New order, decisions/0101):
//   ?new=1   start one: the client's name and email (a member with that email is linked)
//   ?id=     build it (catalog products with options and quantity, GO Codes, custom lines; a proof per line), set the
//            terms (pay in full, or a deposit; invoice later isn't offered any more), send the client their private link, see their
//            answers (proofs approved or changes asked for), and after approval move printed items through production.
// Money after approval (refunds, credits, the ledger) is on the order page (admin/order.php), as for any order.
declare(strict_types=1);
ob_start();   // its styles print before the admin frame, which still has headers to send (no-cache)

require_once __DIR__ . '/../../app/ui/admin-hub.php';
require_once __DIR__ . '/../../app/lib/ClientOrders.php';
require_once __DIR__ . '/../../app/lib/Shipments.php';
require_once __DIR__ . '/../../app/lib/QrIssue.php';
require_once __DIR__ . '/../../app/lib/Qr.php';
require_once __DIR__ . '/../../app/lib/VendorOrders.php';
require_once __DIR__ . '/../../app/lib/Promotions.php';
require_once __DIR__ . '/../../app/lib/QuickBooksPay.php';
require_once __DIR__ . '/../../app/lib/WorkOrders.php';
require_once __DIR__ . '/../../app/lib/Vendors.php';
require_once __DIR__ . '/../../app/lib/Uploads.php';
require_once __DIR__ . '/../../app/ui/cost-tab.php';
require_once __DIR__ . '/../../app/lib/Collateral.php';
require_once __DIR__ . '/../../app/lib/Clients.php';

$pdo = Database::connection();
tv_crawler_require_admin($pdo);
[$me, $ctx] = tv_admin_require($pdo);
$e = 'tv_e';
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$usd = fn ($c) => Orders::usd((int) $c);
$staff = (int) $me['id'];
$oid = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$base = '/admin/backoffice/orders/';   // its address: an order in Back-Office (decisions/0109); /admin/client-order.php forwards here
$self = $base . $oid;
if (!isset($tvItemRoute) && empty($_GET['embed']) && $_SERVER['REQUEST_METHOD'] === 'GET') { header('Location: ' . $base . ($oid ? $oid : (!empty($_GET['new']) ? 'new' : '')), true, 301); exit; }
$ready = Products::ready($pdo);
$hasDel = $ready && ClientOrders::hasDelivery($pdo);   // 2026-12-08_delivery_outside.sql
$cents = function (string $v): int {
    $v = str_replace([',', '$', ' '], '', trim($v));
    if (!preg_match('/^\d+(\.\d{1,2})?$/', $v)) throw new RuntimeException('Enter the amount in dollars, like 25.00.');
    return (int) round((float) $v * 100);
};

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = $self;
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new RuntimeException('This page had expired. Try again.');
        $line = (int) ($_POST['line'] ?? 0);
        $msg = '';
        // how many, as typed: empty is 1; "abc", 0 or -5 is refused, never taken as 1 (the ordering survey, #14)
        $howMany = function (string $v): int { if (trim($v) === '') return 1; $n = ClientOrders::countIn($v); if ($n < 1 || preg_match('/^\s*-/', $v)) throw new RuntimeException('Enter how many as a whole number, 1 or more (you typed "' . mb_substr(trim($v), 0, 20) . '"). Nothing was added.'); return $n; };
        // a second press of an Add form (a double click) is the same request: its one-time key was used (the survey, #15)
        $once = (string) ($_POST['once'] ?? ''); $doNow = (string) ($_POST['do'] ?? '');
        if ($once !== '' && preg_match('/^[a-f0-9]{16}$/', $once)) {
            $_SESSION['tv_co_once'] = array_slice((array) ($_SESSION['tv_co_once'] ?? []), -40, null, true);
            if (isset($_SESSION['tv_co_once'][$once])) $doNow = 'pressed_twice'; else $_SESSION['tv_co_once'][$once] = time();
        }
        switch ($doNow) {
            case 'pressed_twice': $msg = 'Added once: the second press was the same request, so nothing more was added.'; break;
            case 'create':
                $oid = ClientOrders::create($pdo, $staff, $_POST);
                $to = $base . $oid;
                $msg = 'Started. Fill in Bill to and Ship to, then + Add item.';
                break;
            case 'promo': ClientOrders::setPromo($pdo, $oid, (string) ($_POST['code'] ?? ''), $staff); $msg = trim((string) ($_POST['code'] ?? '')) === '' ? 'Code taken off.' : 'Code added: it comes off the prices when the client approves.'; $to .= '#lines'; break;
            case 'add_product':
                ClientOrders::addProduct($pdo, $oid, (int) ($_POST['product'] ?? 0), $howMany((string) ($_POST['qty'] ?? '')), (array) ($_POST['opt'] ?? []), (string) ($_POST['price'] ?? ''), (string) ($_POST['note'] ?? ''), $staff);
                $msg = 'Added.'; $to .= '#lines'; break;
            case 'add_custom':
                ClientOrders::addCustom($pdo, $oid, (string) ($_POST['title'] ?? ''), $howMany((string) ($_POST['qty'] ?? '')), (string) ($_POST['price'] ?? ''), !empty($_POST['taxable']), (string) ($_POST['note'] ?? ''), $staff, (string) ($_POST['cost'] ?? ''), 'custom', (string) ($_POST['type'] ?? ''));
                $msg = 'Added.'; $to .= '#lines'; break;
            case 'add_ship':
                ClientOrders::addCustom($pdo, $oid, 'Shipping: ' . trim((string) ($_POST['method'] ?? 'Ground')), 1, (string) ($_POST['price'] ?? ''), !empty($_POST['taxable']), (string) ($_POST['note'] ?? ''), $staff, (string) ($_POST['cost'] ?? ''), 'shipping');
                $msg = 'Shipping added.'; $to .= '#lines'; break;
            case 'add_go':
                $type = (string) ($_POST['type'] ?? '');
                ClientOrders::addGoCode($pdo, $oid, $type, (array) (($_POST['f'] ?? [])[$type] ?? []), (string) ($_POST['title'] ?? ''), (string) ($_POST['price'] ?? ''), $staff);
                $msg = 'Added.'; $to .= '#lines'; break;
            case 'go_save':
                $l0 = Orders::lines($pdo, $oid); $t0 = '';
                foreach ($l0 as $x) if ((int) $x['id'] === $line && $x['ref_id']) $t0 = (string) $pdo->query('SELECT type FROM qr_issued WHERE id = ' . (int) $x['ref_id'])->fetchColumn();
                ClientOrders::updateGoCode($pdo, $oid, $line, (string) ($_POST['title'] ?? ''), (array) (($_POST['f'] ?? [])[$t0] ?? []), $staff);
                if (trim((string) ($_POST['price'] ?? '')) !== '') ClientOrders::updateLine($pdo, $oid, $line, 1, (string) $_POST['price'], (string) ($_POST['note'] ?? ''), $staff);
                $msg = 'Saved. The printed QR stays the same.'; $to .= '#l' . $line; break;
            case 'line_remove': ClientOrders::removeLine($pdo, $oid, $line, $staff); $msg = 'Removed.'; $to .= '#lines'; break;
            // proofs and item files come in through the uploader (api/upload.php, targets order_proof and order_file: decisions/0127)
            case 'tags':
                ClientOrders::setTags($pdo, $oid, $line, (string) ($_POST['tags'] ?? ''), $staff); $msg = 'Tags saved.'; $to .= '#item=' . $line . ':details'; break;
            case 'vjob_line':   // which item a vendor job is for ('' = the whole order: it moves every item without its own job)
                $jb = VendorOrders::job($pdo, (int) ($_POST['job'] ?? 0));
                if (!$jb || (int) $jb['order_id'] !== $oid) throw new RuntimeException('That job isn\'t on this order.');
                VendorOrders::setLine($pdo, (int) $jb['id'], (int) ($_POST['for'] ?? 0), $staff);
                $msg = 'Vendor job set.'; $to .= '#item=' . $line . ':vendor'; break;
            case 'test_open':   // a sandbox order, straight to the client's page (proofs, approve, pay) in a new tab: no email
                $oo = Orders::get($pdo, $oid);
                if (!$oo || !Orders::isTest($oo)) throw new RuntimeException('Only a sandbox (test) order opens as the client. A real one is sent.');
                if ($oo['status'] === 'void') throw new RuntimeException('This test order was cancelled: make another with Duplicate ▾ → Test copy.');
                if ($oo['status'] === 'draft' || ($oo['status'] === 'sent' && strtotime((string) $oo['expires_at']) < time())) ClientOrders::send($pdo, $oid, ClientOrders::DAYS, $staff, false);
                header('Location: /order.php?t=' . rawurlencode((string) $oo['access_token']), true, 303); exit;   // this site, whatever SITE_BASE says
            case 'send':
                $url = ClientOrders::send($pdo, $oid, (int) ($_POST['days'] ?? ClientOrders::DAYS), $staff);
                if (ClientOrders::$mailed === false) throw new RuntimeException('Sent, but the email to ' . (string) (Orders::get($pdo, $oid)['bill_email'] ?? '') . ' didn\'t go: copy the link below and send it yourself, or check the address and Send again.');   // it is sent (the link works); the email is what failed, said as an error
                $msg = 'Sent. The client has the link by email; you can also copy it below.'; break;
            case 'split':   // several addresses: one order each (decisions/0177, release A), with Undo
                $kids = ClientOrders::split($pdo, $oid, $staff);
                $msg = 'Split: this order keeps its first address; ' . implode(', ', array_map(fn ($n) => 'order #' . Orders::no(Orders::get($pdo, $n)), $kids)) . (count($kids) === 1 ? ' has' : ' have') . ' the others, as drafts on the same terms. Send each when it\'s ready, or Undo the split.'; break;
            case 'unsplit':
                ClientOrders::unsplit($pdo, $oid, $staff);
                $msg = 'Split undone: the items are back on this order.'; break;
            case 'reopen':   // approved, but something's wrong (a quantity): back to editing, approve again when it's right
                ClientOrders::reopen($pdo, Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.'), (string) ($_POST['why'] ?? ''), $staff);
                $msg = 'Reopened: make your changes, then approve it again (Approve for the client, or Handled outside).'; break;
            case 'staff_approve':   // the checkout skipped: the client said yes in person, on the phone or by email
                if (!empty($_POST['release'])) {   // asked before anything is approved, so a refusal leaves nothing half done (model 1.9: admins only, with a reason)
                    [$okR, $whyR] = ClientOrders::canRelease();
                    if (!$okR) throw new RuntimeException('Only an admin can release an order before payment (' . $whyR . '). Nothing was approved.');
                    if (mb_strlen(trim((string) ($_POST['release_why'] ?? ''))) < 3) throw new RuntimeException('Say why it goes ahead before payment: the reason is kept on the order. Nothing was approved.');
                }
                ClientOrders::approve($pdo, Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.'), (string) ($_POST['name'] ?? ''), $_POST, $staff);
                if (!empty($_POST['release'])) ClientOrders::releaseHold($pdo, $oid, $staff, (string) ($_POST['release_why'] ?? ''));
                $msg = 'Approved for the client' . (!empty($_POST['release']) ? ' and released before payment: it can go to the vendor and be released for delivery. The reason is on the order.' : '. It waits for their payment; they pay on their page as usual.'); break;
            case 'release_hold': ClientOrders::releaseHold($pdo, $oid, $staff, (string) ($_POST['why'] ?? '')); $msg = 'Released before payment: it can go to the vendor and be released for delivery. The payment is still to come; the reason is on the order.'; $to .= '#payhold'; break;
            case 'outside_wo':   // handled outside QuickBooks and Traversence: process it (no invoice made here) and send its work order
                // the work order's must-haves first, so a form missing one doesn't leave the order half done
                if (!ctype_digit((string) ($_POST['vendor_id'] ?? '')) && trim((string) ($_POST['vendor'] ?? '')) === '') throw new RuntimeException('Who makes it? Choose the vendor, or add a new one. (Nothing was processed.)');
                if (empty($_POST['lines'])) throw new RuntimeException('Tick at least one item for the vendor. (Nothing was processed.)');
                $oo = WorkOrders::processOutside($pdo, Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.'), (string) ($_POST['name'] ?? ''), (string) ($_POST['invoice_ref'] ?? ''), $staff);
                $sv = (string) ($_POST['save'] ?? (trim((string) ($_POST['email'] ?? '')) !== '' ? 'send' : 'close'));
                $go = $sv === 'send';
                try { $wo = WorkOrders::create($pdo, $oo, $_POST, $staff, $go); }
                catch (RuntimeException $x) { throw new RuntimeException('The order is processed and in production, but the work order didn\'t go: ' . $x->getMessage()); }
                $msg = 'Processed (no invoice made here) and in production. Work order ' . $wo['wo_no'] . ($go ? ' emailed to ' . $wo['vendor'] . '.' : ' saved, not sent yet.');
                $to .= $go ? '#work' : ($sv === 'stay' ? '?wo_edit=' . (int) $wo['id'] . '#wo-edit' : ($sv === 'new' ? '?wo_new=1#wo-new' : '#work')); break;
            case 'line_cost':   // the item's Cost tab: save, save and mark checked, or keep as the product's recipe (our team only)
                $cl = ClientOrders::line($pdo, $oid, $line); $act = (string) ($_POST['act'] ?? 'save');
                if ($act === 'load') { $ws = Costing::startFrom($pdo, $oid, $cl, (string) ($_POST['from'] ?? ''), $staff); $msg = 'Costing replaced: COGS ' . Orders::usd($ws['cogs']) . ' at this item\'s run. Check it, then Save and mark checked.'; $to .= '#item=' . $line . ':cost'; break; }
                $rc = ['parts' => (array) ($_POST['parts'] ?? []), 'items' => (array) ($_POST['items'] ?? []), 'spoil' => $_POST['spoil'] ?? 0, 'tiers' => (array) ($_POST['tiers'] ?? [])];
                $ws = Costing::saveLine($pdo, $oid, $cl, $rc, $staff, $act === 'check' || $act === 'none', $act === 'none');
                if ($act === 'recipe') Costing::saveRecipe($pdo, ($cl['product'] ?? '') === 'product' ? (int) ($cl['product_id'] ?? 0) : 0, json_decode((string) $pdo->query('SELECT recipe FROM order_line_costs WHERE line_id = ' . (int) $line)->fetchColumn(), true) ?: $rc, $staff);
                if ($act === 'none') { $msg = 'No hard cost: COGS $0.00, checked.'; $to .= '#item=' . $line . ':cost'; break; }
                $msg = 'COGS ' . Orders::usd($ws['cogs']) . ($act === 'check' ? ' saved and checked.' : ($act === 'recipe' ? ' saved, and kept as the product\'s recipe.' : ' saved (not checked yet).')); $to .= '#item=' . $line . ':cost'; break;
            case 'line_vendor':
                Vendors::setForLine($pdo, $oid, $line, (int) ($_POST['vendor_id'] ?? 0), $staff);
                $msg = 'Vendor set for this item.'; $to .= '#item=' . $line . ':vendor'; break;
            case 'wo_create':   // Save (keep editing), Save and close, Save and send
                $go = ($_POST['save'] ?? '') === 'send';
                $wo = WorkOrders::create($pdo, Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.'), $_POST, $staff, $go);
                $msg = 'Work order ' . $wo['wo_no'] . ($go ? ' emailed to ' . $wo['vendor'] . ' (' . $wo['vendor_email'] . ').' : ' saved, not sent yet.');
                $sv = (string) ($_POST['save'] ?? 'close');
                $to .= $go ? '#work' : ($sv === 'stay' ? '?wo_edit=' . (int) $wo['id'] . '#wo-edit' : ($sv === 'new' ? '?wo_new=1#wo-new' : '#work')); break;
            case 'wo_link':   // the vendor's link for our team to send themselves; a work order not sent yet is marked sent by it
                $wl = WorkOrders::get($pdo, (int) ($_POST['wo'] ?? 0), $oid) ?: throw new RuntimeException('That work order isn\'t here.');
                [$wl, $url, $mailto] = WorkOrders::handLink($pdo, $wl, $staff);
                $_SESSION['tv_wo_link'] = ['oid' => $oid, 'wo' => (int) $wl['id'], 'url' => $url, 'mailto' => $mailto, 'how' => ($_POST['how'] ?? '') === 'email' ? 'email' : 'copy'];
                $msg = 'Work order ' . $wl['wo_no'] . ' is marked sent. ' . (($_POST['how'] ?? '') === 'email' ? 'Your email opens with its link.' : 'Its link is ready to copy.'); $to .= '#work'; break;
            case 'wo_send':
                $st = $pdo->prepare('SELECT * FROM order_work_orders WHERE id = ? AND order_id = ?'); $st->execute([(int) ($_POST['wo'] ?? 0), $oid]);
                $wo = $st->fetch(PDO::FETCH_ASSOC) ?: throw new RuntimeException('That work order isn\'t here.');
                if (trim((string) ($_POST['email'] ?? '')) !== '') {
                    if (!filter_var(trim((string) $_POST['email']), FILTER_VALIDATE_EMAIL)) throw new RuntimeException('That vendor email doesn\'t look right.');
                    $pdo->prepare('UPDATE order_work_orders SET vendor_email = ? WHERE id = ?')->execute([trim((string) $_POST['email']), (int) $wo['id']]); $wo['vendor_email'] = trim((string) $_POST['email']);
                }
                if (trim((string) ($_POST['cost'] ?? '')) !== '' && WorkOrders::statusReady($pdo)) { $pdo->prepare("UPDATE order_work_orders SET cost_cents = ?, cost_state = 'ours' WHERE id = ?")->execute([ClientOrders::cents((string) $_POST['cost']), (int) $wo['id']]); $wo = WorkOrders::get($pdo, (int) $wo['id']); }
                $wo = WorkOrders::send($pdo, $wo, $staff); WorkOrders::markOrdered($pdo, Orders::get($pdo, $oid) ?: [], $staff, (string) $wo['vendor']); $msg = 'Work order ' . $wo['wo_no'] . ' emailed to ' . $wo['vendor'] . ' (' . $wo['vendor_email'] . ').'; $to .= '#work'; break;
            case 'wo_receive':
                $wo = WorkOrders::get($pdo, (int) ($_POST['wo'] ?? 0), $oid) ?: throw new RuntimeException('That work order isn\'t here.');
                $wo = WorkOrders::receive($pdo, $wo, !empty($_POST['ok']), (string) ($_POST['by'] ?? ''), (string) ($_POST['on'] ?? ''), (string) ($_POST['note'] ?? ''), $staff);
                $msg = $wo['status'] === 'received' ? 'Work order ' . $wo['wo_no'] . ' received.' : 'Work order ' . $wo['wo_no'] . ' rejected; the vendor is told. Reprint it when you\'re ready.'; $to .= '#work'; break;
            case 'wo_delete':   // a draft made by mistake, never sent
                $wo = WorkOrders::get($pdo, (int) ($_POST['wo'] ?? 0), $oid) ?: throw new RuntimeException('That work order isn\'t here.');
                WorkOrders::deleteDraft($pdo, $wo, $staff); $msg = 'Draft work order ' . $wo['wo_no'] . ' deleted.'; $to .= '#work'; break;
            case 'wo_cancel':
                $wo = WorkOrders::get($pdo, (int) ($_POST['wo'] ?? 0), $oid) ?: throw new RuntimeException('That work order isn\'t here.');
                WorkOrders::cancel($pdo, $wo, (string) ($_POST['why'] ?? ''), $staff); $msg = 'Work order ' . $wo['wo_no'] . ' cancelled.'; $to .= '#work'; break;
            case 'proof_retire': case 'proof_restore': case 'version_retire': case 'version_restore':   // a concept or version taken back from the client and from work orders
                $back = (string) ($_POST['back'] ?? '');
                $nr = ClientOrders::retireProof($pdo, $oid, (int) ($_POST['proof'] ?? 0), in_array($_POST['do'], ['proof_retire', 'version_retire'], true), $staff, str_starts_with((string) $_POST['do'], 'version_'));
                $msg = in_array($_POST['do'], ['proof_retire', 'version_retire'], true) ? ($nr ? $nr . ' file' . ($nr === 1 ? '' : 's') . ' retired: the client no longer sees ' . ($nr === 1 ? 'it' : 'them') . ', and no work order offers ' . ($nr === 1 ? 'it' : 'them') . '.' : 'Already retired.') : ($nr ? 'Brought back.' : 'Already back.');
                $to .= $back !== '' ? '#' . preg_replace('/[^a-z0-9_=:-]/i', '', $back) : '#work'; break;
            case 'file_retire': case 'file_restore':   // an old copy kept on the order but never offered for a work order
                $rf = ClientOrders::retireFile($pdo, $oid, (int) ($_POST['file'] ?? 0), $_POST['do'] === 'file_retire', $staff);
                $msg = $rf['file_name'] . ($_POST['do'] === 'file_retire' ? ' retired: it stays on the order but isn\'t offered for work orders.' : ' is back: work orders can offer it again.'); $to .= !empty($_POST['back']) ? '#' . preg_replace('/[^a-z0-9_-]/i', '', (string) $_POST['back']) : '#work'; break;
            case 'wo_files':   // new files for the vendor on a work order that has gone out
                $wo = WorkOrders::get($pdo, (int) ($_POST['wo'] ?? 0), $oid) ?: throw new RuntimeException('That work order isn\'t here.');
                $fc = WorkOrders::setFiles($pdo, $wo, (array) ($_POST['files'] ?? []), $staff, !empty($_POST['tell']));
                $msg = 'Work order ' . $wo['wo_no'] . ': ' . implode('; ', array_filter([$fc['added'] ? count($fc['added']) . ' file' . (count($fc['added']) === 1 ? '' : 's') . ' added' : '', $fc['removed'] ? count($fc['removed']) . ' taken off' : ''])) . (!empty($_POST['tell']) ? '. The vendor is emailed.' : '.'); $to .= '#work'; break;
            case 'wo_reprint':
                $wo = WorkOrders::get($pdo, (int) ($_POST['wo'] ?? 0), $oid) ?: throw new RuntimeException('That work order isn\'t here.');
                $nw = WorkOrders::reprint($pdo, $wo, $staff); $msg = 'Work order ' . $nw['wo_no'] . ' made from ' . $wo['wo_no'] . ' (not sent yet): check it and Send.'; $to .= '#work'; break;
            case 'wo_invoice':
                WorkOrders::setInvoiceNo($pdo, Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.'), (string) ($_POST['invoice_ref'] ?? ''), $staff);
                $msg = trim((string) ($_POST['invoice_ref'] ?? '')) !== '' ? 'QuickBooks invoice number kept with the order (for reference: nothing is posted to it).' : 'QuickBooks invoice number taken off.'; $to .= '#work'; break;
            case 'qb_merge':   // decisions/0128, step 3: the order takes its QuickBooks invoice's lines, tax and payments
                require_once __DIR__ . '/../../app/lib/QbPull.php';
                [$canM, $whyM] = Access::can('backoffice.orders.pull', ['min' => 'manager', 'depts' => ['fin', 'ops']]);
                if (!$canM) throw new RuntimeException($whyM);
                $msg = QbPull::merge($pdo, (string) ($_POST['invoice'] ?? ''), $oid, ['item' => (array) ($_POST['item'] ?? []), 'keep' => (array) ($_POST['keep'] ?? [])], $staff); $to .= '#qbmerge'; break;
            case 'record_pay':
                if (!isset(ClientOrders::PAY_METHODS[(string) ($_POST['method'] ?? '')])) throw new RuntimeException('Choose how the payment came in.');
                $rcpt = !empty($_POST['receipt']);
                $qbm = ClientOrders::recordPayment($pdo, $oid, $cents((string) ($_POST['amount'] ?? '')), (string) ($_POST['method'] ?? ''), (string) ($_POST['ref'] ?? ''), $staff, $rcpt); $msg = 'Payment recorded' . ($rcpt ? '; the client is emailed a receipt' : ' (no receipt emailed)') . $qbm . '.'; break;
            case 'ship_save':   // the ship icon: style, carrier, address, charge, cost, tracking, and a label file
                ClientOrders::setShip($pdo, $oid, $line, $_POST, $staff);
                $msg = 'Shipping saved.'; $to .= '#l' . $line; break;
            case 'ship_mode': Shipments::setMode($pdo, $oid, (string) ($_POST['mode'] ?? ''), (string) ($_POST['reason'] ?? ''), $staff); $msg = 'Shipping set.'; break;
            case 'dest_save': Shipments::saveDest($pdo, $oid, $_POST, $staff); $msg = 'Destination saved.'; $to .= '#ship'; break;
            case 'dest_delete': Shipments::deleteDest($pdo, $oid, (int) ($_POST['dest'] ?? 0), $staff); $msg = 'Destination removed.'; $to .= '#ship'; break;
            case 'lots_save':
                $rows = []; foreach ((array) ($_POST['lq'] ?? []) as $i => $q) $rows[] = ['id' => (int) (($_POST['lid'] ?? [])[$i] ?? 0), 'qty' => (int) $q, 'dest' => (int) (($_POST['ld'] ?? [])[$i] ?? 0), 'label' => (string) (($_POST['ll'] ?? [])[$i] ?? '')];
                Shipments::saveLots($pdo, $oid, $line, $rows, $staff); $msg = 'Lots saved.'; $to .= '#ship'; break;
            case 'pack_save': $pid = Shipments::savePack($pdo, $oid, $_POST, $staff); $msg = 'Pack saved.'; $to .= '#ship'; break;
            case 'pack_delete': Shipments::deletePack($pdo, $oid, (int) ($_POST['pack'] ?? 0), $staff); $msg = 'Pack removed.'; $to .= '#ship'; break;
            case 'line_status':
                ClientOrders::setItemStatus($pdo, $oid, $line, (string) ($_POST['status'] ?? ''), (string) ($_POST['tracking'] ?? ''), $staff); $msg = 'Status saved (the client isn\'t told until you send an update).'; $to .= !empty($_POST['ip']) ? '#item=' . $line . ':status' : '#l' . $line; break;
            case 'send_update':
                ClientOrders::sendUpdate($pdo, $oid, (string) ($_POST['note'] ?? ''), $staff); $msg = 'Update emailed to the client.'; break;
            case 'new_product':   // a product made from the order's + Add item, added to the order at once
                if (!($oo = Orders::get($pdo, $oid)) || !ClientOrders::editable($oo)) throw new RuntimeException('This order can\'t be changed now.');
                $np = $_POST;
                if (($np['kind'] ?? '') === 'service') { $q0 = (array) ($np['qty'] ?? []); if ((int) preg_replace('/\D/', '', (string) ($q0[0] ?? '')) <= 0) $np['qty'] = ['1']; }   // a service: one of it unless said
                if (trim((string) (((array) ($np['cost'] ?? []))[0] ?? '')) === '' && trim((string) (((array) ($np['price'] ?? []))[0] ?? '')) === '') throw new RuntimeException('Give your price for it (or your cost, and the markup makes the price).');
                $pid = Products::save($pdo, 0, $np + ['status' => 'active']);
                ClientOrders::addProduct($pdo, $oid, $pid, max(1, (int) preg_replace('/\D/', '', (string) (((array) ($np['qty'] ?? []))[0] ?? '1'))), [], '', (string) ($_POST['note'] ?? ''), $staff);
                $msg = 'Added, and saved to the catalog.'; $to .= '#lines'; break;
            // projects (decisions/0101, addendum 2026-10-27): a heading for an order's items, each with its own setup
            case 'project_add': $pj = ClientOrders::addProject($pdo, $oid, (string) ($_POST['title'] ?? ''), $staff); if ($line) ClientOrders::setLineProject($pdo, $oid, $line, $pj, $staff); $msg = 'Project added.'; $to .= '#p' . $pj; break;
            case 'project_rename': ClientOrders::renameProject($pdo, $oid, (int) ($_POST['project'] ?? 0), (string) ($_POST['title'] ?? ''), $staff); $msg = 'Saved.'; $to .= '#p' . (int) ($_POST['project'] ?? 0); break;
            case 'project_remove': ClientOrders::removeProject($pdo, $oid, (int) ($_POST['project'] ?? 0), $staff); $msg = 'Project taken off. Its items are still on the order.'; $to .= '#lines'; break;
            case 'line_project': ClientOrders::setLineProject($pdo, $oid, $line, (int) ($_POST['project'] ?? 0), $staff); $msg = 'Moved.'; $to .= '#l' . $line; break;
            case 'line_edit': ClientOrders::editLine($pdo, $oid, $line, $_POST, $staff); $msg = 'Saved.'; $to .= '#l' . $line; break;
            case 'file_remove': ClientOrders::removeFile($pdo, $oid, (int) ($_POST['file'] ?? 0), $staff); $msg = 'File taken off.'; $to .= $line ? (!empty($_POST['ip']) ? '#item=' . $line . ':files' : '#l' . $line) : '#docs'; break;
            case 'part_add': ClientOrders::addPart($pdo, $oid, $line, (string) ($_POST['title'] ?? ''), (int) ($_POST['qty'] ?? 1), (string) ($_POST['price'] ?? ''), (string) ($_POST['cost'] ?? ''), $staff); $msg = 'Added to the bundle.'; $to .= '#l' . $line; break;
            case 'part_save':
                foreach (['title', 'qty', 'unit', 'cost'] as $pf0) if (isset($_POST[$pf0])) ClientOrders::setPart($pdo, $oid, (int) ($_POST['part'] ?? 0), $pf0, (string) $_POST[$pf0], $staff);
                $msg = 'Saved.'; $to .= '#l' . $line; break;
            case 'part_remove': ClientOrders::setPart($pdo, $oid, (int) ($_POST['part'] ?? 0), 'remove', '', $staff); $msg = 'Taken out of the bundle.'; $to .= '#l' . $line; break;
            case 'client_attach':   // the order's business (decisions/0101, addendum 2026-10-28)
                Clients::attachOrder($pdo, $oid, (int) ($_POST['listing'] ?? 0), $staff);
                $msg = (int) ($_POST['listing'] ?? 0) ? 'Connected: the order is for that business.' : 'The order is for the person alone (no listing).'; break;
            case 'client_private':
                $oo = Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.');
                if (trim((string) $oo['client_company']) === '' && trim((string) $oo['bill_name']) === '') throw new RuntimeException('Add the business name in Bill to first.');
                $bz = Clients::makePrivate($pdo, ['name' => $oo['client_company'] ?: $oo['bill_name'], 'town' => $oo['bill_city'] ?? '', 'state' => $oo['bill_state'] ?? '', 'phone' => $oo['client_phone'] ?? '', 'email' => $oo['bill_email'], 'address' => $oo['bill_street'] ?? ''], $staff);
                Clients::attachOrder($pdo, $oid, (int) $bz['id'], $staff); $msg = 'A private listing was made for ' . $bz['name'] . ' (never shown on the site), and the order is for it.'; break;
            case 'client_find':
                $q = trim((string) ($_POST['q'] ?? ''));
                $_SESSION['tv_biz_q'][$oid] = $q;
                $_SESSION['tv_biz_find'][$oid] = $q === '' ? [] : Clients::find($pdo, $q, (string) ((Orders::get($pdo, $oid) ?: [])['bill_email'] ?? ''));
                break;
            case 'reorder_art':   // decisions/0101, addendum 2026-10-28: this order's collateral, reordered with the same art
                $ids = array_values(array_unique(array_filter(array_map(fn ($x) => (int) ($x['collateral_id'] ?? 0), Orders::lines($pdo, $oid)))));
                if (!$ids) throw new RuntimeException('Nothing on this order is in the Collateral Center yet (it comes in when the order is approved).');
                $nid = Collateral::reorder($pdo, $ids, [], true, $staff);
                $msg = 'Reorder started from order #' . Orders::no(Orders::get($pdo, $oid) ?: ['id' => $oid]) . ': check the quantities and send it to the client.'; $to = $base . $nid; break;
            case 'duplicate': $nid = ClientOrders::duplicate($pdo, $oid, $staff, !empty($_POST['test'])); $msg = 'Copied from order #' . Orders::no(Orders::get($pdo, $oid) ?: ['id' => $oid]) . (!empty($_POST['test']) ? ', billed to you. Send it to yourself to run it through as the client.' : '.'); $to = $base . $nid; break;
            case 'proof_remove': ClientOrders::removeProofFile($pdo, $oid, (int) ($_POST['proof'] ?? 0), $staff); $msg = 'Taken out.'; $to .= '#item=' . $line . ':proofs'; break;
            case 'final_remove': ClientOrders::removeFinal($pdo, $oid, (int) ($_POST['proof'] ?? 0), $staff); $msg = 'Print-ready file taken off.'; $to .= '#l' . $line; break;
            case 'test_delete':   // a sandbox order, from Orders → Sandbox orders or its own page
                $tn = Orders::no(Orders::get($pdo, $oid) ?: ['id' => $oid]); ClientOrders::deleteTest($pdo, $oid); $msg = 'Sandbox order #' . $tn . ' deleted.'; $to = rtrim($base, '/') . '#sandbox'; break;
            case 'cancel': ClientOrders::cancel($pdo, $oid, trim((string) ($_POST['why'] ?? '')), $staff); $msg = 'Cancelled.'; break;
            case 'complete':   // the command strip's Complete the order
                $co = Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.');
                ClientOrders::complete($pdo, $oid, $staff, ClientOrders::openBeforeComplete($pdo, $co, (int) (Orders::money($pdo, $oid)['paid'] ?? 0)));
                $msg = 'Order #' . Orders::no($co) . ' is complete and in the archive. The client was thanked, with a link to reorder.'; break;
            case 'problem_ok':   // a problem the client reported, put right
                ClientOrders::resolveProblem($pdo, $oid, (int) ($_POST['fb'] ?? 0), $staff); $msg = 'Marked resolved.'; break;
        }
        if (str_starts_with((string) ($_POST['do'] ?? ''), 'add_') || ($_POST['do'] ?? '') === 'new_product') {
            $pj = (int) ($_POST['project'] ?? 0);
            if ($pj && ($nl = (int) $pdo->query('SELECT MAX(id) FROM order_lines WHERE order_id = ' . (int) $oid)->fetchColumn())) ClientOrders::setLineProject($pdo, $oid, $nl, $pj, $staff);
        }
        if ($msg !== '') tv_crawler_flash(['type' => 'ok', 'text' => $msg]);
    } catch (Throwable $ex) {
        if (!($ex instanceof RuntimeException) || $ex instanceof PDOException) error_log('client-order: ' . $ex->getMessage());
        // the error shows where you were working: an Add item tab opens again with what you typed; otherwise beside the item
        $dlg = ['add_product' => 'catalog', 'add_custom' => 'custom', 'add_go' => 'go', 'add_ship' => 'ship', 'new_product' => 'newprod'][(string) ($_POST['do'] ?? '')] ?? (($_POST['do'] ?? '') === 'line_edit' ? 'edit:' . (int) ($_POST['line'] ?? 0) : '');
        $flat = function (array $a, string $pre = '') use (&$flat): array { $o = []; foreach ($a as $k => $v) { $n = $pre === '' ? (string) $k : $pre . '[' . $k . ']'; if (is_array($v)) $o += $flat($v, $n); elseif ($n !== 'csrf') $o[$n] = (string) $v; } return $o; };
        tv_crawler_flash(['type' => 'error', 'text' => $ex instanceof RuntimeException && !($ex instanceof PDOException) ? $ex->getMessage() : 'That didn\'t work. Try again.',
            'dlg' => $dlg, 'fields' => $dlg !== '' ? $flat($_POST) : []]);
        if (($dlg === '' || str_starts_with($dlg, 'edit:')) && !empty($_POST['line'])) $to .= '#l' . (int) $_POST['line'];
        elseif ($dlg === '' && !empty($_POST['project']) && ctype_digit((string) $_POST['project'])) $to .= '#p' . (int) $_POST['project'];   // not a work order's project name
        if (($_POST['do'] ?? '') === 'create') $to = $base . 'new';
        if (($_POST['do'] ?? '') === 'qb_merge') $to .= '?qbmerge=' . rawurlencode((string) ($_POST['invoice'] ?? '')) . '#qbmerge';
        if (!str_contains($to, '#') && in_array($_POST['do'] ?? '', ['outside_wo', 'wo_create', 'wo_files', 'file_retire', 'file_restore', 'proof_retire', 'proof_restore', 'version_retire', 'version_restore', 'wo_send', 'wo_invoice', 'wo_receive', 'wo_cancel', 'wo_delete', 'wo_reprint'], true)) $to .= ($_POST['do'] === 'outside_wo' && in_array((Orders::get($pdo, $oid) ?: [])['status'] ?? '', ['draft', 'sent'], true) ? '#outside' : '#work');
    }
    header('Location: ' . $to, true, 303); exit;
}

// if the page stops part way (staff only see it), say why on the page instead of a blank 500
register_shutdown_function(function () {
    $er = error_get_last();
    if (!$er || !in_array($er['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) return;
    error_log('client-order stopped: ' . $er['message'] . ' in ' . $er['file'] . ':' . $er['line']);
    echo '<div style="margin:1rem 0;padding:.8rem 1rem;border:2px solid #B91C1C;border-radius:.6rem;background:#FEF2F2;color:#7F1D1D;font:15px system-ui,sans-serif"><b>This page stopped part way.</b> Send this to support: '
        . htmlspecialchars(mb_strimwidth((string) $er['message'], 0, 400, '…')) . ' (' . htmlspecialchars(basename((string) $er['file'])) . ', line ' . (int) $er['line'] . ')</div>';
});
// a partial upload (this page newer than its library): say which file, not a blank 500
if (!method_exists('ClientOrders', 'groups') || !method_exists('ClientOrders', 'rateTotal')) { tv_admin_start('backoffice', 'Client order'); echo '<div class="hb-card tv-bleed"><p class="text-sm">The server has an older <code>app/lib/ClientOrders.php</code> than this page needs. Upload it again from the latest zip, then reload.</p></div>'; tv_admin_end(); return; }
if (!$ready) { tv_admin_start('backoffice', 'Client order'); echo '<div class="hb-card tv-bleed"><p class="text-sm">Run <code>app/migrations/2026-12-06_client_orders.sql</code> in phpMyAdmin first.</p></div>'; tv_admin_end(); return; }
$flash = tv_crawler_flash();
$o = $oid ? Orders::get($pdo, $oid) : null;
if ($oid && (!$o || !ClientOrders::isClient($o))) { tv_admin_start('backoffice', 'Client order'); echo '<div class="hb-card tv-bleed"><p class="text-sm">That isn\'t an order built for a client. <a class="hb-go" href="/admin/order.php?id=' . $oid . '">Open it as an order</a></p></div>'; tv_admin_end(); return; }
$hidden = fn (string $do, int $line = 0) => '<input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="id" value="' . $oid . '"><input type="hidden" name="do" value="' . $do . '">' . ($line ? '<input type="hidden" name="line" value="' . $line . '">' : '')
    . (str_starts_with($do, 'add_') ? '<input type="hidden" name="once" value="' . bin2hex(random_bytes(8)) . '">' : '');   // one press, one line
$when = fn ($t) => $t ? date('M j, Y g:i a', strtotime((string) $t)) : '';
ob_start();   // the page's styles, printed once the page has started (before <!doctype> they'd put it in quirks mode, and a frame sized to it grows without end)
?>
<style>button.tv-note-x:focus-visible,button.tv-ask-x:focus-visible{outline:2px solid var(--tv-icon,#B45309)!important;outline-offset:-3px!important;border-radius:.35rem}.co-help{display:block;font-weight:400;text-align:left;color:var(--tv-meta,#6B5843);font-size:.8rem;line-height:1.35;margin:.15rem 0 .2rem}</style>
<style>
  .co{color:#3E2B1F;font-size:0.98rem}
  .co-inv{display:flex;flex-wrap:wrap;gap:.6rem;margin:.3rem 0 .4rem}.co-inv>*{flex:1 1 17rem;min-width:0}   /* three across when there's room; a box that wraps takes the whole row */
  .co-box{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem;padding:.7rem .85rem;line-height:1.45;overflow-wrap:anywhere}
  .co-box h3{margin:0 0 .3rem;font:700 .78rem system-ui,sans-serif;letter-spacing:.07em;text-transform:uppercase;color:#8A7355}
  .co-box small{display:block;color:#8A7355;font-size:.85rem;margin-top:.3rem}.co-box dl{display:grid;grid-template-columns:auto 1fr;gap:.15rem .7rem;margin:0}.co-box dt{color:#8A7355;white-space:nowrap;overflow-wrap:normal}
  .co-ways{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:.15rem .7rem;margin:0;font-weight:400}.co-ways label{display:inline-flex;gap:.25rem;align-items:center;white-space:nowrap}
  .co-confirm{display:inline;margin:0 0 0 .5rem}.co-confirm .hb-b{padding:.25rem .7rem;font-size:.88rem;vertical-align:middle}
  .co-hold{background:#FEF3C7;border:1px solid #F59E0B;border-radius:.5rem;padding:.5rem .7rem;margin:.2rem 0 .5rem}.co-box dd{margin:0;text-align:right;font-weight:700}
  .co-note{margin:.2rem 0;color:#5C4632;font-size:.95rem}.co-terms{margin:.2rem 0 .6rem}
  @media (max-width:900px){.co-inv{grid-template-columns:1fr}}
  .co-plus{font-size:1rem;padding:.5rem 1rem}
  .co-stl{display:flex;flex-wrap:wrap;align-items:center;gap:.3rem;margin-top:.35rem}
  .co-st{border:1px solid #CBB98D;border-radius:999px;padding:.12rem .6rem;font:700 .82rem system-ui,sans-serif;cursor:pointer;background:#FFF8EA;color:#5C4632}
  .co-st::after{content:" ▾";color:#8A7355;font-size:.8em}.co-st:hover{box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .co-st.pre{background:#FEF3C7;border-color:#E8C77A;color:#78350F}.co-st.ok{background:#E0EEF4;border-color:#A9C8D6;color:#1E3A4A}
  .co-st.out{background:#DCEFE5;border-color:#8FBCA8;color:#1F3B30}.co-st.ex{background:#FDE2E2;border-color:#E5B4B4;color:#991B1B}.co-st.hk{background:#EEE8DC;color:#6B5A45}
  .co-tag{border:1px solid #CBB98D;border-radius:.35rem;padding:.05rem .4rem;font:700 .75rem system-ui,sans-serif;background:#3E2B1F;color:#FFF8EA;letter-spacing:.02em}
  button.co-tag{cursor:pointer;background:#FFF8EA;color:#3E2B1F}button.co-tag[aria-pressed=true]{background:#3E2B1F;color:#FFF8EA}
  .co-vst{border:0;background:none;padding:0;font-size:.82rem;color:#6B5A45;text-decoration:underline dotted;cursor:pointer}
  .co-lk{border:0;background:none;padding:0;color:#92400E;text-decoration:underline;cursor:pointer;font-size:inherit}
  .co-ip{position:fixed;top:0;right:0;bottom:0;width:min(32rem,100%);z-index:1800;background:#FFFBF2;border-left:1px solid #CBB98D;box-shadow:-18px 0 40px -20px rgba(0,0,0,.45);display:flex;flex-direction:column}
  .co-ip-bar{position:relative;display:flex;align-items:center;gap:.5rem;padding:.6rem .8rem;background:#3E2B1F;color:#FFF8EA}.co-ip-bar>b{flex:1;min-width:0;font:700 1.02rem var(--tv-font-head,Georgia,serif)}.co-ip-bar>b small{display:block;font:600 .8rem system-ui,sans-serif;color:#F3DDB0}
  .co-ip-menu{flex:none;width:2.2rem;height:2.2rem;border-radius:999px;border:1px solid #6B4F35;background:transparent;color:#FFF8EA;font-size:1.15rem;cursor:pointer}.co-ip-menu[aria-expanded=true]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3A2E}
  .co-ip-tabs{position:absolute;right:.8rem;top:calc(100% - .2rem);z-index:5;display:grid;min-width:11rem;padding:.3rem;background:#3E2B1F;border:1px solid #6B4F35;border-radius:.5rem;box-shadow:0 12px 24px -12px rgba(0,0,0,.6)}.co-ip-tabs[hidden]{display:none}
  .co-ip-tabs button{border:0;background:transparent;color:#F3DDB0;border-radius:.35rem;padding:.45rem .7rem;font-weight:600;text-align:left;cursor:pointer}.co-ip-tabs button[aria-selected=true]{background:#8FBCA8;color:#1F3A2E}
  .co-ip-body{flex:1;overflow-y:auto;padding:.8rem 1rem 2rem}.co-ip-body h4{margin:1rem 0 .3rem;font:700 .78rem system-ui,sans-serif;letter-spacing:.07em;text-transform:uppercase;color:#8A7355}
  .co-ip-dl{display:grid;grid-template-columns:auto 1fr;gap:.3rem .8rem;margin:0 0 .6rem}.co-ip-dl dt{color:#8A7355}.co-ip-dl dd{margin:0}
  .co-tagq{display:flex;gap:.3rem;flex-wrap:wrap;margin:-.2rem 0 .2rem}
  .co-ip-hist{list-style:none;margin:0;padding:0}.co-ip-hist li{padding:.35rem 0;border-top:1px solid #EADFC4}.co-ip-hist small{display:block;color:#8A7355}
  .co-ip-ver{border:1px solid #EADFC4;border-radius:.5rem;padding:.5rem .65rem;margin-bottom:.5rem;background:#FFF}.co-ip-ver small{display:block;color:#8A7355;margin-top:.15rem}.co-ip-ver ul,.co-ip-files{margin:.3rem 0 0;padding-left:1.1rem}
  .co-ip-ver a,.co-ip-files a{color:#92400E;text-decoration:underline}.co-ip-for{margin-top:.4rem}.co-margin{margin:.6rem 0;font-size:.95rem}.co-margin small{color:#8A7355}
  @media (min-width:1500px){body.co-ip-on .co{margin-right:32rem}}   /* room beside it; narrower, it opens over the page */
  .co-dlg{position:fixed;inset:0;z-index:1900;background:rgba(18,11,6,.82);display:flex;align-items:center;justify-content:center;padding:12px 0}.co-dlg[hidden]{display:none}
  .co-dlg-box{width:min(56rem,calc(100% - 24px));max-height:100%;display:flex;flex-direction:column;background:#FFFBF2;box-shadow:0 24px 60px -18px rgba(0,0,0,.8)}   /* fits what you can see; its body scrolls */
  .co-dlg-bar{position:sticky;top:0;z-index:2;display:flex;flex-wrap:wrap;align-items:center;gap:.5rem .8rem;padding:.6rem .8rem;background:#3E2B1F;color:#FFF8EA}
  .co-tabs{display:flex;flex-wrap:wrap;gap:.3rem;flex:1}.co-tabs button{border:1px solid #6B4F35;background:transparent;color:#F3DDB0;border-radius:999px;padding:.3rem .75rem;font-weight:600;cursor:pointer}
  .co-tabs button[aria-selected="true"]{background:#8FBCA8;border-color:#8FBCA8;color:#1F3A2E}
  .co-dlg-x{width:34px;height:34px;border-radius:999px;border:1px solid rgba(255,248,234,.45);background:transparent;color:#FFF8EA;font-size:1.3rem;cursor:pointer}
  .co-dlg-body{padding:.8rem 1rem 1rem;overflow-y:auto;min-height:0;-webkit-overflow-scrolling:touch}
  .co-shipf{display:grid;grid-template-columns:minmax(0,2fr) 8rem 8rem auto;gap:.4rem;align-items:end;margin-top:.45rem;padding:.45rem .55rem;background:#FFFBF2;border:1px dashed #CBB98D;border-radius:.5rem}
  .co-shipf label{display:grid;gap:.1rem;font-size:.85rem;color:#5C4632}.co-shipf .hb-in{padding:.3rem .45rem;font-size:.9rem}.co-shipf .hb-in[readonly]{opacity:.65}
  .co-shr{display:block;font-size:.8rem;color:#8A7355;margin-top:.15rem}
  @media (max-width:767px){.co-shipf{grid-template-columns:1fr 1fr}.co-shipf label:first-child{grid-column:1/-1}}
  .co-cust{display:flex;flex-wrap:wrap;gap:.4rem 1.2rem;align-items:center;margin:.3rem 0 .5rem}.co-pick{display:flex;gap:.5rem;align-items:center;font-weight:700;flex:1 1 22rem;max-width:34rem}.co-pick .hb-in{flex:1}.co-mail{color:#5C4632}
  .co-ed{display:inline-block;min-width:3ch;padding:.05rem .25rem;margin:-.05rem -.25rem;border-radius:.3rem;border:1px dashed transparent;cursor:text;outline:none;overflow-wrap:anywhere}
  .co-ed:hover{border-color:#CBB98D;background:#FFFBF2}.co-ed:focus{border-color:#8FBCA8;background:#fff;box-shadow:0 0 0 3px rgba(143,188,168,.3)}
  .co-ed:empty::before{content:attr(data-ph);color:#B9A88A;font-weight:400}.co-saved{background:#DCFCE7!important}
  .co-sel{font:inherit;font-size:.92rem;border:1px solid #CBB98D;border-radius:.4rem;background:#FFFBF2;color:#3E2B1F;padding:.15rem .3rem;max-width:100%}
  .co-link-b{border:0;background:none;color:#92400E;text-decoration:underline;font-weight:600;cursor:pointer;padding:0;margin-top:.3rem}
  .co-msgbox{margin:0 0 .6rem;color:#5C4632}
  .co-th,.co-line .hd{display:grid!important;grid-template-columns:1.4rem 1.6rem minmax(0,1fr) 4.5rem 6rem 6.5rem 2.6rem 6.8rem!important;gap:.6rem;align-items:start}
  .co-drag{cursor:grab;color:#B9A88A;user-select:none;letter-spacing:-.15em;padding-top:.1rem}.co-n{color:#8A7355;padding-top:.1rem}.co-dragging{opacity:.5}
  .co-desc{min-width:0}.co-desc small{display:block}.co-desc small.co-sz{display:inline}.co-meta .co-cogs{font-size:inherit;color:#92400E}.co-meta .co-cogs.no{color:#991B1B}.co-d{color:#5C4632;margin-top:.1rem}.co-meta{color:#B9A88A!important}
  .co-tax{text-align:center}.co-tax input{width:1.1rem;height:1.1rem;accent-color:#3E2B1F}
  .co-ic{display:flex;gap:.3rem;justify-content:flex-end}.co-ic form{margin:0}
  .co-icb{width:34px;height:34px;display:inline-flex;align-items:center;justify-content:center;border-radius:999px;border:1px solid #CBB98D;background:#FFFBF2;color:#B45309;cursor:pointer}.co-icb.no{color:#991B1B;border-color:#E5B4B4}.co-icb:hover{background:#8FBCA8;color:#1F3A2E}
  .co-shipline{display:block;margin-top:.3rem;border:0;background:none;padding:0;color:#92400E;text-decoration:underline;cursor:pointer;text-align:left;font-size:.9rem}
  .co-files{display:flex;flex-wrap:wrap;gap:.2rem .9rem;margin-top:.3rem;font-size:.9rem}.co-files a{color:#92400E;text-decoration:underline}.co-sz{color:#8A7355;font-size:.8em;white-space:nowrap}.co-upf{margin:0}.co-up{color:#92400E;font-weight:700;cursor:pointer}
  .co-stf{margin-top:.3rem}.co-more>summary{font-size:.88rem!important}
  .co-radios{display:flex;gap:.8rem;flex-wrap:wrap}.co-radios label{display:flex!important;gap:.3rem;align-items:center;font-size:.95rem!important;color:#3E2B1F!important}
  .co-table{container:coitems/inline-size}   /* the items lay out by the room they have (the item panel beside them takes some), not the screen's width */
  @container coitems (max-width:880px){.co-th{display:none!important}.co-line .hd{grid-template-columns:1.2rem minmax(0,1fr) auto auto auto!important;grid-template-areas:"drag desc desc desc ic" "n q u amt tax"}
    .co-drag{grid-area:drag}.co-n{grid-area:n}.co-desc{grid-area:desc}.co-q{grid-area:q}.co-u{grid-area:u}.co-amt{grid-area:amt}.co-tax{grid-area:tax}.co-ic{grid-area:ic;flex-direction:column}
    .co-q::before{content:"Qty ";color:#8A7355}.co-u::before{content:"@ ";color:#8A7355}.co-q,.co-u{display:block!important}}
  .co-modef{display:flex;gap:.4rem;flex-wrap:wrap;margin:0 0 .4rem}.co-print{font:600 .85rem system-ui,sans-serif;color:#92400E;margin-left:.6rem}
  .co-dest{margin-top:.5rem}.co-dest-hd{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.4rem 1rem}.co-money{font-size:.92rem}
  .co-lots{width:100%;border-collapse:collapse;margin-top:.5rem;font-size:.92rem}.co-lots th{text-align:left;font:700 .75rem system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;color:#8A7355;border-bottom:1px solid #EADFC4;padding:.25rem}
  .co-lots td{padding:.3rem .25rem;border-bottom:1px solid #F1E8D4}.co-lots td.ok{color:#1F5C43;font-weight:700}.co-lots td.warn{color:#B45309;font-weight:700}
  .co-warn{color:#B45309;font-weight:600;margin:.3rem 0 0}.co-okp{color:#1F5C43;margin:.3rem 0 0}
  .co-pack{border:1px solid #EADFC4;background:#FFFBF2;border-radius:.5rem;padding:.5rem .65rem;margin-top:.45rem}.co-pack small{display:block;color:#6B5640}.co-pack-a{display:inline-flex;gap:.6rem;margin-top:.2rem}
  .co-in{border:1px solid #EADFC4;border-radius:.5rem;padding:.4rem .6rem}.co-in label{display:grid!important;grid-template-columns:minmax(0,1fr) 6rem;gap:.5rem;align-items:center}
  .co-lotrow{display:grid;grid-template-columns:6rem minmax(0,1fr) minmax(0,1.2fr) auto;gap:.4rem;align-items:end;margin-top:.35rem}.co-lotrow label{display:grid;font-size:.85rem}.co-lotrow [hidden]{display:none}
  .co-msg{padding:.5rem .7rem;border-radius:.5rem;background:#DCFCE7;margin:.45rem 0}.co-msg.error{background:#FEE2E2}
  .co-f{display:grid;gap:.45rem;margin-top:.45rem}.co-f label{display:grid;gap:.15rem;font-size:0.88rem;color:#5C4632;align-content:start;min-width:0}.co-f textarea.hb-in{font:inherit;resize:vertical;width:100%;max-width:100%;box-sizing:border-box}.co-f .two>*,.co-f .three>*{min-width:0}
  .co-split{display:inline-flex;position:relative;align-items:stretch;gap:1px;justify-self:end;margin-left:auto;width:max-content}.co-split>.hb-b{height:2.4rem;box-sizing:border-box;margin:0;vertical-align:top;display:inline-flex;align-items:center}
  .co-split>.hb-b[data-split-main]{border-radius:999px 0 0 999px}.co-split>.co-split-t{border-radius:0 999px 999px 0;padding-left:.75rem;padding-right:.8rem}
  .co-split-l{position:absolute;bottom:calc(100% + 4px);right:0;z-index:1000;min-width:12rem;background:#fff;border:1px solid #E3D3AC;border-radius:.5rem;box-shadow:0 6px 18px rgba(62,43,31,.15);display:grid;padding:.25rem 0}.co-split-l[hidden]{display:none}.co-split-l button{background:none;border:0;text-align:left;padding:.55rem .9rem;font:500 .95rem system-ui,sans-serif;color:#3E2B1F;cursor:pointer}.co-split-l button:hover,.co-split-l button:focus{background:#FBF3E2}
  .co-wo-ship{display:grid;gap:.3rem;align-content:start;min-width:0}.co-wo-ship .co-wo-f{margin-left:0}.co-wo-docs{border:1px dashed #D9C79B;border-radius:.5rem;padding:.35rem .5rem;display:grid;gap:.15rem}.co-wo-docs b{font-size:.84rem;color:#5C4632}.co-f small{color:#8A7355;font-size:0.84rem}
  .co-f .two{display:grid;grid-template-columns:1fr 1fr;gap:.45rem}.co-f .three{display:grid;grid-template-columns:2fr 1fr 1fr;gap:.45rem}
  .co-top{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;margin:.2rem 0 .5rem}
  .co-line{border-top:1px solid #EADFC4;padding:.6rem 0}.co-line:first-child{border-top:0;padding-top:0}
  .co-dup{position:relative}.co-dup>summary{list-style:none;cursor:pointer}.co-dup>summary::-webkit-details-marker{display:none}
  .co-dupm{position:absolute;right:0;top:calc(100% + .3rem);z-index:30;width:min(22rem,calc(100vw - 24px));background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.6rem;box-shadow:0 12px 30px -12px rgba(0,0,0,.4);display:grid;gap:.6rem}
  .co-dupm form{display:grid;gap:.25rem}.co-dupm small{color:#5C4632;font-size:.82rem}
  .co-prj{border:2px solid #E3D3AC;border-radius:.6rem;padding:.4rem .6rem .2rem;margin:.6rem 0;background:#FFFDF7}
  @media (min-width:768px){.co-prj{margin-left:calc(-.6rem - 2px);margin-right:calc(-.6rem - 2px)}}   /* its items line up with the columns above */.co-prj .co-line:first-of-type{border-top:0}
  .co-prjh{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .7rem;padding-bottom:.4rem;border-bottom:1px solid #E3D3AC;margin-bottom:.3rem}
  .co-prjn{flex:1 1 14rem;min-width:0}.co-prjn .hb-in{font:700 1.05rem var(--tv-font-head,Georgia,serif);width:100%;background:transparent;border-color:transparent}.co-prjn .hb-in:hover,.co-prjn .hb-in:focus{border-color:#CBB98D;background:#FFFBF2}
  .co-prjs{font-size:.9rem;color:#5C4632}
  .co-parts{display:grid;gap:.25rem;margin:.3rem 0}.co-parth,.co-part{display:grid;grid-template-columns:minmax(8rem,1fr) 4rem 6rem 6rem 6rem auto;gap:.3rem;align-items:center}.co-parth{font-size:.75rem;color:#8A7355;text-transform:uppercase}
  .co-part .hb-in{padding:.25rem .4rem;font-size:.9rem;min-width:0;width:100%;box-sizing:border-box}.co-partadd{margin-top:.3rem}
  @media (max-width:767px){.co-parth{display:none}.co-part{grid-template-columns:1fr 3.5rem 5rem;}.co-part>b,.co-part>span:empty{display:none}.co-prj{padding:.3rem .4rem}}
  .co-line.on{background:#F1F7F3;box-shadow:inset 3px 0 0 #8FBCA8}
  @container coitems (min-width:881px){.co-ic{display:grid;grid-template-columns:repeat(3,34px);gap:3px;justify-content:end}}   /* Edit, Status, Files / Project, Ship, Delete: two short rows */
  @container coitems (max-width:880px){.co-ic{display:grid!important;grid-template-columns:repeat(2,34px);gap:3px;align-content:start}}
  .co-pjm{position:relative}.co-pjm>summary{list-style:none}.co-pjm>summary::-webkit-details-marker{display:none}.co-icb.on,.co-pjm[open]>summary{background:#8FBCA8;color:#1F3A2E;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .co-pjmenu{position:absolute;right:0;top:calc(100% + .3rem);z-index:40;width:min(16rem,calc(100vw - 24px));background:#FFFBF2;border:1px solid #CBB98D;border-radius:.6rem;padding:.4rem;box-shadow:0 12px 30px -12px rgba(0,0,0,.45);display:grid;gap:.15rem}
  .co-pjmenu b{font:700 .72rem system-ui,sans-serif;letter-spacing:.07em;text-transform:uppercase;color:#8A7355;padding:.15rem .4rem}.co-pjmenu form{margin:0}
  .co-pjmenu button{display:block;width:100%;text-align:left;border:0;background:none;padding:.4rem .5rem;border-radius:.4rem;font:inherit;font-size:.92rem;color:#3E2B1F;cursor:pointer}.co-pjmenu button:hover{background:#F1E8D4}.co-pjmenu button[disabled]{color:#1F5C43;font-weight:700;cursor:default;background:#DCEFE5}
  .co-wo-pick{border:1px solid #E3D3AC;border-radius:.5rem;padding:.5rem .6rem;display:grid;gap:.2rem;min-width:0}.co-wo-pick legend{font-size:.88rem;color:#5C4632;padding:0 .3rem}
  .co-wo-f{margin-left:1.6rem;font-size:.86rem!important;overflow-wrap:anywhere}.co-wo-f small{color:#8A7355}.co-wo-opt{margin-left:1.6rem;color:#8A7355;font-size:.82rem}
  .co-wo-t{width:100%;border-collapse:collapse;font-size:.9rem}.co-wo-t th,.co-wo-t td{text-align:left;padding:.4rem .3rem;border-bottom:1px solid #EADFC4;vertical-align:top}.co-wo-t small{color:#8A7355}
  .co-wo-pn{display:flex!important;align-items:center;gap:.4rem;flex-wrap:wrap}.co-wo-spec{display:grid!important;gap:.15rem}.co-wo-spec textarea{font-size:.86rem;padding:.3rem .45rem}.co-wo-pn .hb-in{max-width:12rem;padding:.2rem .45rem}
  .co-wfl{display:grid;gap:3px;margin:.2rem 0 .3rem;grid-template-columns:repeat(auto-fill,minmax(min(26rem,100%),1fr))}
.co-wo-frow td{padding-top:0}.co-wo-frow .co-wo-rcv .co-f{min-width:0;max-width:none}.co-wo-frow .co-wo-rcv[open]>summary{margin-bottom:.4rem}
.co-wo-frow .co-wo-rcv .co-f .hb-b.go{justify-self:start;min-width:12rem}
.co-f label.co-wf{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:.15rem .6rem;align-items:center;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.5rem;padding:.45rem .6rem;cursor:pointer;color:#3E2B1F}
.co-f label.co-wf.on{border-color:#8FBCA8;background:#F1F7F3}.co-f label.co-wf input{width:1.1rem;height:1.1rem;margin:0}
.co-wf-t{display:grid;gap:.05rem;min-width:0}.co-wf-t a{color:#92400E;font-weight:600;text-decoration:underline;overflow-wrap:anywhere}.co-wf-t small{color:#8A7355;font-size:.78rem}.co-wf-t small b{color:#5C4632}
.co-wf-s{font-size:.72rem;font-weight:700;color:#2F6B53;white-space:nowrap}.co-wf-s .co-lk{font-weight:400;font-size:.8rem}
.co-wf-x{color:#92400E;font-weight:600}.co-ret>a{opacity:.6;text-decoration:line-through}.co-wf-ret{margin:.5rem 0 0}.co-wf-ret summary{cursor:pointer;font-size:.82rem;color:#5C4632}.co-wf-r{display:flex;gap:.6rem;align-items:center;justify-content:space-between;padding:.35rem .6rem;border:1px dashed #CBB98D;border-radius:.5rem;margin-top:3px;opacity:.85}
@media (max-width:560px){.co-f label.co-wf{grid-template-columns:auto minmax(0,1fr)}.co-wf-s{grid-column:2}}.co-wo-log summary,.co-wo-rcv>summary{cursor:pointer;font-size:.82rem;color:#92400E;list-style:none}.co-wo-log ul{margin:.3rem 0 0;padding-left:1rem;font-size:.84rem}.co-wo-log small{color:#8A7355}
  .co-wo-acts{display:grid;gap:.35rem;justify-items:end}.co-wo-rcv>summary{display:inline-block}.co-wo-rcv .co-f{min-width:14rem;text-align:left}
  .co-wo-again{display:flex;flex-wrap:wrap;gap:.3rem;justify-content:flex-end}.co-wo-again .hb-in{max-width:12rem}.co-wo-inv{margin-top:.6rem}
  @media (max-width:767px){.co-wo-t tr{display:grid;grid-template-columns:1fr 1fr;border-bottom:1px solid #EADFC4}.co-wo-t th{display:none}.co-wo-t td{border:0}.co-wo-t td:nth-child(3),.co-wo-t td:last-child{grid-column:1/-1}.co-wo-again{justify-content:flex-start}.co-wo-acts{justify-items:start}}
  .co-biz{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.7rem;padding:.5rem .8rem;margin:.4rem 0}.co-biz>summary{cursor:pointer;list-style:none;display:flex;flex-wrap:wrap;gap:.35rem .6rem;align-items:center}
  .co-biz-l{font:700 .72rem system-ui,sans-serif;letter-spacing:.07em;text-transform:uppercase;color:#8A7355}.co-biz small{color:#8A7355}
  .co-biz-b{display:grid;gap:.5rem;margin-top:.5rem}.co-biz-c{list-style:none;margin:0;padding:0}.co-biz-c li{padding:.35rem 0;border-top:1px solid #EADFC4;display:flex;flex-wrap:wrap;gap:.3rem .6rem;align-items:center}
  .co-biz-f{display:flex;gap:.35rem}.co-biz-f .hb-in{flex:1;min-width:0}.co-biz-a{display:flex;flex-wrap:wrap;gap:.35rem}
  .co-chk{display:flex!important;align-items:center;gap:.4rem;font-size:.92rem!important;color:#3E2B1F!important}.co-chk input{width:1.05rem;height:1.05rem;accent-color:#3E2B1F}
  .co-docs ul{list-style:none;margin:.3rem 0;padding:0;display:grid;gap:.25rem}.co-docs li{display:flex;flex-wrap:wrap;gap:.2rem .6rem;align-items:baseline}.co-docs a{color:#92400E;text-decoration:underline}.co-docs small{color:#8A7355}
  .co-docs table{width:100%;border-collapse:collapse;font-size:.92rem;margin-top:.3rem}.co-docs td,.co-docs th{padding:.3rem .25rem;border-bottom:1px solid #F1E8D4;text-align:left;vertical-align:top}.co-docs th{font:700 .72rem system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;color:#8A7355}
  .co-th,.co-line .hd{display:grid;grid-template-columns:minmax(0,1fr) 14rem 3rem 6.5rem 6.5rem;gap:.7rem;align-items:start}
  .co-th{background:#3E2B1F;color:#FFF8EA;font:700 .78rem system-ui,sans-serif;letter-spacing:.07em;text-transform:uppercase;padding:.6rem .8rem;margin:-.75rem -.85rem .5rem;border-radius:.8rem .8rem 0 0}
  .co-th span:nth-child(n+3),.co-q,.co-u{text-align:right}.co-q,.co-u{white-space:nowrap}
  .co-stf{display:grid;gap:.25rem}.co-stf .hb-in{padding:.3rem .45rem;font-size:.9rem}
  @container coitems (max-width:880px){.co-stc{grid-column:1/-1;order:5}}
  .co-line small{display:block;color:#8A7355;font-size:0.88rem;overflow-wrap:anywhere}
  .co-amt{text-align:right;white-space:nowrap;font-weight:700}.co-amt s{color:#8A7355;font-weight:400;font-size:0.88rem;display:block}
  .co-pf{display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;margin-top:.35rem;font-size:0.9rem}
  .co-pf a{color:#92400E;text-decoration:underline}
  .co-ch{background:#FEF3C7;border:1px solid #F59E0B;border-radius:.5rem;padding:.4rem .55rem;margin-top:.35rem;font-size:0.92rem}
  .co details>summary{cursor:pointer;color:#92400E;font-weight:700;font-size:0.93rem;margin-top:.35rem}
  .co [hidden]{display:none!important}
  .co-qr{display:flex;gap:.6rem;align-items:center;margin-top:.4rem;flex-wrap:wrap}
  .co-qr img{width:5.5rem;height:5.5rem;background:#fff;border:1px solid #EADFC4;border-radius:.35rem}
  .co-qr .acts{display:flex;gap:.3rem;flex-wrap:wrap}.co-qr small{flex-basis:100%}
  .co-types{display:flex;flex-wrap:wrap;gap:.35rem;margin:.2rem 0 .3rem}
  .co-types button{border:1px solid #CBB98D;background:#FFFBF2;color:#5C4632;border-radius:999px;padding:.35rem .75rem;font-size:0.92rem;font-weight:600;cursor:pointer}
  .co-types button[aria-pressed="true"]{background:#8FBCA8;border-color:#6E9F8A;color:#1F3A2E;box-shadow:0 0 0 3px rgba(143,188,168,.3)}
  .co-sum{display:grid;grid-template-columns:repeat(auto-fit,minmax(8.5rem,1fr));gap:.45rem;margin-top:.5rem}
  .co-sum div{background:#FFFBF2;border:1px solid #EADFC4;border-radius:.6rem;padding:.45rem .7rem;font-size:0.88rem;color:#5C4632}.co-sum b{display:block;font:700 1.1rem var(--tv-font-head,Georgia,serif);color:#3E2B1F}
  .co-link{background:#FFFBF2;border:1px dashed #B8863B;border-radius:.6rem;padding:.55rem;overflow-wrap:anywhere;font-size:0.93rem}
  .co-log{list-style:none;margin:.3rem 0 0;padding:0}.co-log li{border-top:1px solid #EADFC4;padding:.35rem 0;font-size:0.92rem}.co-log li:first-child{border-top:0}.co-log small{color:#8A7355}
  @media (max-width:767px){.co-f .two,.co-f .three{grid-template-columns:1fr}}
</style>
<?php
$coCss = (string) ob_get_clean();
// ---- start one --------------------------------------------------------------------------------------------------------------
if (!$o) {
    tv_admin_start('backoffice', 'New order', 'Build an order for a client: they get a private link to review it, approve the proofs, and pay by card (in full or a deposit). Or they pay you directly, outside QuickBooks, and you record it.', null, [['E-Commerce', '/admin/ecommerce.php'], ['Orders', '/admin/ecommerce.php#orders'], ['New order', null]]); ?><?= $coCss ?>
<div class="co">
  <?php if ($flash): ?><p class="co-msg <?= $e($flash['type'] ?? '') ?>" role="status" data-tv-flash="<?= $e($flash['type'] ?? '') ?>"><?= $e($flash['text'] ?? '') ?></p><?php endif; ?>
  <div class="hb-card tv-bleed">
    <?php   // past clients: everyone we've had an order from (client orders and GO Codes checkouts), newest details first
      $past = [];
      try {
        foreach ($pdo->query("SELECT o.bill_name, o.bill_email, o.client_company, o.client_phone, o.id FROM orders o
                              JOIN (SELECT bill_email, MAX(id) AS id FROM orders WHERE bill_email <> '' GROUP BY bill_email) x ON x.id = o.id ORDER BY o.bill_name LIMIT 500")->fetchAll(PDO::FETCH_ASSOC) as $r)
          $past[] = ['label' => trim($r['bill_name'] . ($r['client_company'] !== '' ? ' · ' . $r['client_company'] : '') . ' · ' . $r['bill_email']), 'name' => $r['bill_name'], 'email' => $r['bill_email'], 'company' => $r['client_company'], 'phone' => $r['client_phone']];
      } catch (Throwable) {} ?>
    <?php if ($past): ?>
    <label style="display:grid;gap:.15rem;font-size:.8rem;color:#5C4632">A past client (type to find them), or fill in a new one below
      <input class="hb-in" id="co-past" list="co-pastl" placeholder="Name, business or email" autocomplete="off"></label>
    <datalist id="co-pastl"><?php foreach ($past as $c): ?><option value="<?= $e($c['label']) ?>"></option><?php endforeach; ?></datalist>
    <?php endif; ?>
    <form method="post" class="co-f" novalidate id="co-new"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="create">
      <div class="two"><label>Client's name<input class="hb-in" name="name" required maxlength="120"></label><label>Email (the order goes here)<input class="hb-in" type="email" name="email" required maxlength="190"></label></div>
      <div class="two"><label>Business (optional)<input class="hb-in" name="company" maxlength="120"></label><label>Phone (optional)<input class="hb-in" name="phone" maxlength="40" inputmode="tel"></label></div>
      <small>If they have a Traversence account with this email, the order is linked to it. They don't need one.</small>
      <div><button class="hb-b go">Start the order</button></div>
    </form>
  </div>
</div>
<?php if ($past): ?>
<script>
(function () {
  var P = <?= json_encode($past, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>, i = document.getElementById('co-past'), f = document.getElementById('co-new');
  i.addEventListener('input', function () {
    var c = P.filter(function (x) { return x.label === i.value; })[0]; if (!c) return;
    var el = f.elements; el['name'].value = c.name; el['email'].value = c.email; el['company'].value = c.company || ''; el['phone'].value = c.phone || '';
  });
})();
</script>
<?php endif; ?>
<?php tv_admin_end(); return; }

// ---- the order ------------------------------------------------------------------------------------------------------------
ClientOrders::refreshPrices($pdo, $oid);   // a draft follows the catalog
$o = Orders::get($pdo, $oid);
// its business (decisions/0101, addendum 2026-10-28): connected from the start when the listing is clear, a private one made when there's none
$clientsReady = Clients::ready($pdo); $bizMaybe = []; $bizNote = '';
if ($clientsReady && $o && array_key_exists('listing_id', $o) && $o['listing_id'] === null) {
    try { [$bizNote, $bizMaybe] = Clients::autoConnect($pdo, $o, $staff); if ($bizNote !== '') $o = Orders::get($pdo, $oid); } catch (Throwable $x) { error_log('client auto-connect: ' . $x->getMessage()); }
}
$bizFound = $_SESSION['tv_biz_find'][$oid] ?? null; unset($_SESSION['tv_biz_find'][$oid]);
$lines = ClientOrders::lines($pdo, $oid);
$editable = ClientOrders::editable($o);
$m = Orders::money($pdo, $oid);
$products = Products::all($pdo, true);
$events = Orders::events($pdo, $oid);
$state = match (true) {
    $o['status'] === 'draft' => ['Draft: not sent yet', ''],
    $o['status'] === 'sent' && ClientOrders::expired($o) => ['Sent: the link has expired', 'red'],
    $o['status'] === 'sent' && $o['review'] === 'changes' => ['Changes requested', 'red'],
    $o['status'] === 'sent' => ['Sent: waiting on the client', ''],
    $o['status'] === 'pending' && $m['paid'] > 0 => ['Deposit paid: ' . $usd((int) $o['total_cents'] - $m['paid']) . ' left', ''],
    $o['status'] === 'pending' => ['Approved: waiting for payment', ''],
    default => [Orders::STATUS[$o['status']] ?? $o['status'], $o['status'] === 'paid' ? 'ok' : ''],
};
tv_admin_start('backoffice', 'Order #' . Orders::no($o), '', null, [['Back-Office', '/admin/backoffice'], ['Orders', '/admin/backoffice/orders'], ['Order #' . Orders::no($o), null]]);
echo $coCss;
?>
<div class="co">
  <?php ob_start(); ?>
    <?php if ($o['status'] === 'pending' && ClientOrders::isClient($o)): $rb = ClientOrders::reopenBlock($pdo, $o); ?><form method="post" style="margin:0;display:inline"><?= $hidden('reopen') ?><button class="hb-b" id="co-reopen"<?= $rb !== '' ? ' disabled title="' . $e($rb) . '" style="opacity:.55;cursor:not-allowed"' : ' title="Not approved any more: change quantities, prices or items, then approve it again" data-confirm="Reopen this order for changes? It\'s no longer approved or in production until you approve it again. Its proofs stay approved." data-yes="Reopen it"' ?>>Reopen for changes</button><?php if ($rb !== ''): ?><small class="co-note" style="display:block;max-width:22rem"><?= $e($rb) ?></small><?php endif; ?></form><?php endif; ?>
    <?php if (Orders::isTest($o) && $o['status'] !== 'void'): ?><form method="post" target="_blank" style="margin:0;display:inline"><?= $hidden('test_open') ?><button class="hb-b go" title="Sandbox: opens the client's page in a new tab to look at the proofs, approve and pay with a test card. Nothing is emailed." style="display:inline-flex;align-items:center;gap:.35rem"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6M10 3v6l-5.5 9.5A1.7 1.7 0 0 0 6 21h12a1.7 1.7 0 0 0 1.5-2.5L14 9V3"/><path d="M7.5 15h9"/></svg> Open as the client</button></form><?php endif; ?>
    <details class="co-dup" id="co-dup"><summary class="hb-b">Duplicate ▾</summary>
      <div class="co-dupm">
        <form method="post"><?= $hidden('duplicate') ?><input type="hidden" name="test" value="1"><button class="hb-b go">Test copy, billed to you</button>
          <small>Always a test order in the QuickBooks sandbox: no real money moves, whatever mode Payments is in<?= QuickBooksPay::env() === 'sandbox' ? '' : ' (to run it through, switch E-Commerce → Payments to Sandbox)' ?>. Nothing reaches the client.</small></form>
        <?php $colIds = Collateral::ready($pdo) ? array_values(array_unique(array_filter(array_map(fn ($x) => (int) ($x['collateral_id'] ?? 0), $lines)))) : []; if ($colIds): ?>
        <form method="post"><?= $hidden('reorder_art') ?><button class="hb-b go">Reorder with the same art</button><small>A new draft for the same client, its items and files from the Collateral Center; the client confirms the reuse with their initials (no new proof round).</small></form><?php endif; ?>
        <form method="post"><?= $hidden('duplicate') ?><button class="hb-b">Copy for the same client</button><small>A new draft with the same items and proofs to approve again.</small></form>
      </div></details>
  <?php $coMenu = (string) ob_get_clean();
  // the command strip (decisions/0129): what the order is and where it stands; one button for Save/Send/Close; ☰ for the rest
  require_once __DIR__ . '/../../app/ui/command-strip.php';
  $op = $o['status'] !== 'draft' ? ClientOrders::opens($pdo, $oid) : null;
  $csMore = [];
  if ($o['status'] !== 'draft') $csMore[] = ['What the client sees', ClientOrders::url($o), 'new'];
  if (!$editable) $csMore[] = ['Money: refund, credit, history', '/admin/order.php?id=' . $oid, ''];
  if (ClientOrders::hasInline($pdo)) $csMore[] = ['Documents and files', '#docs', ''];
  if (in_array($o['status'], ['draft', 'sent'], true)) $csMore[] = ['Cancel the order', '#co-cancel-btn', 'danger'];
  $csProb = (bool) array_filter(ClientOrders::feedback($pdo, $oid), fn ($f) => $f['kind'] === 'problem' && $f['resolved_at'] === null);   // the client says something isn't right
  // several addresses: the order's own notice carries the split (and, after it, Undo), never a box of its own
  $csSplitForm = ''; $csAct = [];
  if ($editable && count($shipTos = ClientOrders::shipTos($pdo, $o, Orders::lines($pdo, $oid))) > 1) {
      $csSplitForm = 'split';
      $csAct = ['<b>Ships to ' . count($shipTos) . ' addresses:</b> QuickBooks taxes an invoice for one address, so it can\'t be approved as one order yet. Split it: this order keeps the first address, each other gets its items on the same terms.',
          '<button type="submit" form="co-split-f" class="hb-b go" data-confirm="Split it into ' . count($shipTos) . ' orders, one per address? You can undo it." data-yes="Split it">Split into one order per address</button>'];
  } elseif ($editable && ($undo = ClientOrders::splitUndoable($pdo, $oid))) {
      $csSplitForm = 'unsplit';
      $csAct = ['<b>Split by address:</b> its other addresses are on ' . implode(', ', array_map(fn ($n) => '<a href="/admin/backoffice/orders/' . (int) $n . '" style="color:#92400E;text-decoration:underline">order #' . $e(Orders::no(Orders::get($pdo, $n))) . '</a>', $undo)) . '.',
          '<button type="submit" form="co-split-f" class="hb-b" data-confirm="Put their items back on this order and cancel those orders?" data-yes="Undo the split">Undo the split</button>'];
  }
  echo tv_command_strip(['noun' => 'order', 'title' => 'Order #' . Orders::no($o), 'news_key' => 'order-' . $oid, 'news_act' => $csAct, 'news_tone' => $csProb || in_array($state[1], ['red', 'bad'], true) ? 'bad' : 'info',
      // whose turn it is: the client's (approve, pay), the vendor's (the work order); when they opened the order only matters while it's theirs to approve
      'news' => [$o['status'] === 'pending' ? ($m['paid'] > 0 ? 'Deposit paid, ' . $usd((int) $o['total_cents'] - $m['paid']) . ' left: waiting on the client' : 'Approved: waiting on the client\'s payment') : $state[0],
          in_array($o['stage'], ['ordered', 'production'], true) ? 'With the vendor: ' . lcfirst(ClientOrders::STAGES[$o['stage']]) : ($o['stage'] !== '' ? (ClientOrders::STAGES[$o['stage']] ?? $o['stage']) : ''),
          ($o['qb_env'] ?? '') === 'sandbox' ? 'Test order (sandbox)' : '',
          $csProb ? 'Open support ticket: the client says something isn\'t right (see Complete the order)' : (ClientOrders::hasReceived($pdo) && ClientOrders::outTheDoor($pdo, $o) ? 'All out the door: waiting on the client to say they have it' : ''),
          $op && $o['status'] === 'sent' ? ($op['last'] ? 'The client opened it ' . date('M j, g:i a', strtotime((string) $op['last'])) . ($op['n'] > 1 ? ' (' . $op['n'] . ' visits)' : '') : 'The client hasn\'t opened it yet') : ''],
      'send' => in_array($o['status'], ['draft', 'sent'], true) ? ['label' => $o['status'] === 'sent' ? 'Send again' : 'Send to the client', 'target' => '#co-send-btn'] : (in_array($o['status'], ['pending', 'paid'], true) ? ['label' => 'Send the client an update', 'target' => '#co-update-btn'] : null),
      'finish' => in_array($o['status'], ['pending', 'paid'], true) && ClientOrders::isClient($o) && $o['stage'] !== 'complete' ? [['Complete the order', '#co-complete', true]] : [],
      'back' => '/admin/backoffice/orders', 'close' => '/admin/backoffice/orders', 'more' => $csMore, 'menu_html' => $coMenu, 'root' => '.co',
      // forms that make something new wait for their own button; searches aren't edits
      'new' => 'form:has(input[name=do][value=wo_create]):not(:has(input[name=wo])), form:has(input[name=do][value^=add_]), form:has(input[name=do][value=project_add]), form:has(input[name=do][value=new_product]), form:has(input[name=do][value=duplicate]), form:has(input[name=do][value=reorder_art]), form:has(input[name=do][value=reopen]), form:has(input[name=do][value=test_open])',
      'skip' => 'form:has(input[name=do][value=client_find])']); ?>
  <?php // the split's forms: their buttons sit in the order's notices box (news_act above), these only carry the post
  if (!empty($csSplitForm)): ?><form method="post" id="co-split-f" hidden><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="id" value="<?= $oid ?>"><input type="hidden" name="do" value="<?= $e($csSplitForm) ?>"></form><?php endif; ?>
  <?php if ($flash): ?><p class="co-msg <?= $e($flash['type'] ?? '') ?>" role="status" id="co-flash" data-tv-flash="<?= $e($flash['type'] ?? '') ?>"><?= $e($flash['text'] ?? '') ?></p>
  <script>window.__coFlash = <?= json_encode(['type' => $flash['type'] ?? '', 'text' => $flash['text'] ?? '', 'dlg' => $flash['dlg'] ?? '', 'fields' => (object) ($flash['fields'] ?? [])], JSON_HEX_TAG | JSON_HEX_AMP) ?>;</script><?php endif; ?>

  <?php
  $hasItems = ClientOrders::hasItems($pdo); $hasShip = ClientOrders::hasShip($pdo); $addrs = ClientOrders::addresses($pdo, $oid);
  $inl = ClientOrders::hasInline($pdo); $files = ClientOrders::files($pdo, $oid); $anyEd = $o['status'] !== 'void';
  // a value edited in place: click it, change it, and it saves when you leave it (/api/admin/client-order.php)
  $ed = fn (string $f, string $v, string $ph, bool $on, string $attr = 'data-f') => $on
      ? '<span class="co-ed" contenteditable="plaintext-only" ' . $attr . '="' . $f . '" data-ph="' . $e($ph) . '" role="textbox" aria-label="' . $e($ph) . '">' . $e($v) . '</span>'
      : '<span>' . $e($v) . '</span>';
  $past = $editable ? $pdo->query("SELECT LOWER(bill_email) AS email, MAX(bill_name) AS name, MAX(client_company) AS company FROM orders WHERE bill_email <> '' GROUP BY LOWER(bill_email) ORDER BY MAX(id) DESC LIMIT 300")->fetchAll(PDO::FETCH_ASSOC) : [];
  ?>
  <div class="co-cust">
    <?php if ($editable): ?><label class="co-pick"><span>Customer</span><input class="hb-in" list="co-pastc" id="co-cust" placeholder="Find a past client by email, or type a new one in Bill to" autocomplete="off"></label>
      <datalist id="co-pastc"><?php foreach ($past as $pc): if ($pc['email'] === strtolower((string) $o['bill_email'])) continue; ?><option value="<?= $e($pc['email']) ?>"><?= $e(trim($pc['name'] . ($pc['company'] !== '' ? ' · ' . $pc['company'] : ''))) ?></option><?php endforeach; ?></datalist><?php endif; ?>
    <span class="co-mail">Email: <?= $ed('email', (string) $o['bill_email'], 'email', $editable) ?></span>
  </div>
  <?php if ($clientsReady): $biz = (int) ($o['listing_id'] ?? 0) ? Clients::get($pdo, (int) $o['listing_id']) : null; $cands = $bizFound ?? $bizMaybe; ?>
  <details class="co-biz tv-bleed"<?= ($o['listing_id'] === null && $cands) || $bizFound !== null ? ' open' : '' ?>><summary><span class="co-biz-l">Business</span>
    <?php if ($biz): ?><b><?= $e($biz['name']) ?></b><?= $biz['city'] ? ' · ' . $e($biz['city']) : '' ?> <span class="hb-pill<?= (int) $biz['is_suppressed'] ? '' : ' ok' ?>" style="margin:0"><?= (int) $biz['is_suppressed'] ? 'Private listing' : ($biz['status'] === 'unclaimed' ? 'On Traversence (not claimed)' : 'On Traversence') ?></span><?= $bizNote === 'connected' ? ' <small>connected: the same business</small>' : ($bizNote === 'private' ? ' <small>no listing found: a private one was made</small>' : '') ?>
    <?php elseif ($o['listing_id'] !== null): ?><b>The person alone</b> <small>no business listing</small>
    <?php else: ?><b>Not connected yet</b> <small><?= $cands ? count($cands) . ' possible listing' . (count($cands) === 1 ? '' : 's') . ' below' : 'add the business name in Bill to, or settle it here' ?></small><?php endif; ?>
    <span class="co-lk">Change ▾</span></summary>
    <div class="co-biz-b">
      <?php if ($cands): ?><ul class="co-biz-c"><?php foreach ($cands as $c): ?><li><b><?= $e($c['name']) ?></b><?= $c['city'] ? ' · ' . $e($c['city']) : '' ?> <small><?= $c['private'] ? 'private' : ($c['status'] === 'unclaimed' ? 'on Traversence, not claimed' : 'on Traversence, claimed') ?> · matches <?= $e($c['why']) ?><?= $c['client'] ? ' · already a client' : '' ?> · #<?= (int) $c['id'] ?></small>
        <form method="post" style="display:inline"><?= $hidden('client_attach') ?><input type="hidden" name="listing" value="<?= (int) $c['id'] ?>"><button class="hb-b"<?= (int) ($o['listing_id'] ?? 0) === (int) $c['id'] ? ' disabled' : '' ?>>Connect</button></form></li><?php endforeach; ?></ul>
      <?php elseif ($bizFound !== null): ?><p class="co-note">No listing matches that.</p><?php endif; ?>
      <form method="post" class="co-biz-f"><?= $hidden('client_find') ?><input class="hb-in" name="q" placeholder="Find a listing: name, phone or listing #" value="<?= $e((string) ($_SESSION['tv_biz_q'][$oid] ?? $o['client_company'])) ?>"><button class="hb-b">Find</button></form>
      <div class="co-biz-a">
        <form method="post"><?= $hidden('client_private') ?><button class="hb-b" data-confirm="Make a private listing for <?= $e($o['client_company'] ?: $o['bill_name']) ?>? It's never shown on the site; the client can publish it later." data-yes="Make it">Make a private listing</button></form>
        <form method="post"><?= $hidden('client_attach') ?><input type="hidden" name="listing" value="0"><button class="hb-b"<?= $o['listing_id'] !== null && !(int) $o['listing_id'] ? ' disabled' : '' ?>>The person alone (no listing)</button></form>
        <?php if ($biz): ?><a class="hb-b" href="/admin/backoffice/clients/<?= (int) $biz['id'] ?>">Its contacts</a><?php endif; ?>
      </div>
    </div></details>
  <?php endif; ?>
  <div class="co-inv tv-bleed">
    <div class="co-box"><h3>Bill to</h3>
      <div><?= $ed('name', (string) $o['bill_name'], 'Name', $editable) ?></div><div><?= $ed('company', (string) $o['client_company'], 'Business', $editable) ?></div>
      <div><?= $ed('phone', (string) $o['client_phone'], 'Phone', $editable) ?></div><div><?= $ed('bill_street', (string) $o['bill_street'], 'Street', $anyEd) ?></div>
      <div><?= $ed('bill_city', (string) $o['bill_city'], 'Town', $anyEd) ?> <?= $ed('bill_state', (string) $o['bill_state'], 'ST', $anyEd) ?> <?= $ed('bill_zip', (string) $o['bill_zip'], 'ZIP', $anyEd) ?></div></div>
    <?php $shipOk = Shipments::ready($pdo); $smode = $shipOk ? Shipments::mode($o) : ''; ?>
    <div class="co-box"><h3>Shipping</h3>
      <?php if ($shipOk): ?>
      <form method="post" class="co-modef"><?= $hidden('ship_mode') ?>
        <select class="co-sel" name="mode" aria-label="How it ships" onchange="this.form.requestSubmit()"<?= $anyEd ? '' : ' disabled' ?>><option value=""<?= $smode === '' ? ' selected' : '' ?> disabled>Choose how it ships…</option><?php foreach (Shipments::MODES as $k => $lab): ?><option value="<?= $k ?>"<?= $smode === $k ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></select>
        <?php if ($smode === 'none'): ?><select class="co-sel" name="reason" aria-label="Why" onchange="this.form.requestSubmit()"><?php foreach (Shipments::REASONS as $k => $lab): ?><option value="<?= $k ?>"<?= ($o['no_ship_reason'] ?? '') === $k ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></select><?php endif; ?>
      </form>
      <?php endif; ?>
      <?php if ($shipOk && $smode === 'multi'): ?><p class="co-note" style="margin:.4rem 0 0"><?= count(Shipments::destinations($pdo, $o)) ?> destinations: <a class="hb-go" href="#ship">Shipping &amp; manifests</a>. The first (Ship to) is this address:</p><?php endif; ?>
      <?php if ((!$shipOk || $smode !== 'none') && ($hasShip || ClientOrders::hasDelivery($pdo))): ?>
      <div><?= $ed('ship_name', (string) ($o['ship_name'] ?? ''), 'Name', $anyEd) ?></div><div><?= $ed('ship_street', (string) ($o['ship_street'] ?? ''), 'Street', $anyEd) ?></div>
      <div><?= $ed('ship_city', (string) ($o['ship_city'] ?? ''), 'Town', $anyEd) ?> <?= $ed('ship_state', (string) ($o['ship_state'] ?? ''), 'ST', $anyEd) ?> <?= $ed('ship_zip', (string) ($o['ship_zip'] ?? ''), 'ZIP', $anyEd) ?></div>
      <?php if ($anyEd): ?><button type="button" class="co-link-b" data-same>Same as Bill to</button><?php endif; ?>
      <small><?= $shipOk ? ($smode === 'multi' ? 'Send items (or lots of them) elsewhere with each item\'s ship icon.' : '') : 'Each item can ship somewhere else: its ship icon.' ?></small>
      <?php endif; ?></div>
    <div class="co-box"><h3>Order details</h3>
      <dl><dt>Invoice no.</dt><dd><?= $e(ClientOrders::ref($o)) ?></dd>
        <dt>Terms</dt><dd><?php if ($hasItems && $anyEd): ?><select class="co-sel" data-f="due_terms"><?php foreach (ClientOrders::DUE_TERMS as $k => [$lab]): ?><option value="<?= $k ?>"<?= ($o['due_terms'] ?? 'receipt') === $k ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></select><?php else: ?><?= $e(ClientOrders::DUE_TERMS[$o['due_terms'] ?? 'receipt'][0] ?? '') ?><?php endif; ?></dd>
        <?php if (Orders::hasCol($pdo, 'tax_choice')): $tc = ClientOrders::taxChoice($o); ?><dt>Sales tax</dt><dd><?php if ($editable): ?><select class="co-sel" data-f="tax_choice" aria-label="How the order is taxed" title="<?= $e(ClientOrders::TAX_CHOICES[$tc][1]) ?>"><?php foreach (ClientOrders::TAX_CHOICES as $k => [$lab, $why]): ?><option value="<?= $k ?>" title="<?= $e($why) ?>"<?= $tc === $k ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></select><?php else: ?><?= $e(ClientOrders::TAX_CHOICES[$tc][0]) ?><?php endif; ?>
          <?php if ($tc !== 'taxable' || ($o['tax_note'] ?? '') !== ''): ?><br><?= $ed('tax_note', (string) ($o['tax_note'] ?? ''), 'Certificate no. or reason', $editable) ?><?php endif; ?>
          <small class="co-help"><?= $e(ClientOrders::TAX_CHOICES[$tc][1]) ?></small></dd><?php endif; ?>
        <dt>Invoice date</dt><dd><?= $e(date('M j, Y', strtotime((string) ($o['sent_at'] ?: $o['created_at'])))) ?></dd>
        <dt>Due date</dt><dd><?php if ($inl && $anyEd): ?><input type="date" class="co-sel" data-f="due_date" value="<?= $e($o['due_date'] ?? '') ?>" title="Empty: from the terms (<?= $e(ClientOrders::dueDate(['due_date' => null] + $o)) ?>)"><?php else: ?><?= $e(ClientOrders::dueDate($o)) ?><?php endif; ?></dd>
        <dt>Order no.</dt><dd><?= $hasItems ? $ed('po_number', (string) ($o['po_number'] ?? ''), 'P.O. / order no.', $anyEd) : '' ?></dd>
        <dt>Payment</dt><dd><?php if ($editable): ?><select class="co-sel" data-f="pay_mode"><?php foreach (ClientOrders::PAY_MODES as $k => $lab): if (($k === 'outside' && !$hasDel) || (!in_array($k, ClientOrders::OFFERED, true) && $o['pay_mode'] !== $k)) continue; ?><option value="<?= $k ?>"<?= $o['pay_mode'] === $k ? ' selected' : '' ?>><?= $e(['full' => 'Pay in full', 'deposit' => 'Deposit', 'invoice' => 'Invoice later (no longer offered)', 'outside' => 'Outside QuickBooks'][$k]) ?></option><?php endforeach; ?></select><?php else: ?><?= $e(ClientOrders::PAY_MODES[$o['pay_mode']]) ?><?php endif; ?></dd>

        <?php if ($o['pay_mode'] === 'deposit'): [$depC, $depW, $depOpen, $depIds] = ClientOrders::depositFor($pdo, $o, (int) ($o['status'] === 'draft' || $o['status'] === 'sent' ? $o['subtotal_cents'] : $o['total_cents'])); ?><dt>Deposit</dt><dd><b><?= $e(Orders::usd((int) ($o['deposit_cents'] ?? 0) > 0 ? (int) $o['deposit_cents'] : $depC)) ?></b>
          <small class="co-help"><?= $e($depW) ?></small>
          <?= $ed('deposit_pct', (int) $o['deposit_pct'] > 0 ? (string) (int) $o['deposit_pct'] : '', '% instead (empty: cost + ' . ClientOrders::DEPOSIT_MARKUP . '%)', $editable) ?></dd><?php endif; ?></dl>
        <?php if ($o['pay_mode'] === 'deposit' && $depOpen): ?><p data-tv-status="info" data-tv-label="No cost recorded:" style="margin:.4rem 0 0"><?= $e(implode(', ', array_slice($depOpen, 0, 4)) . (count($depOpen) > 4 ? '…' : '')) ?> count<?= count($depOpen) === 1 ? 's' : '' ?> at <?= ClientOrders::DEPOSIT_DEFAULT ?>% of price. <button type="button" class="co-lk" data-item-open="<?= (int) $depIds[0] ?>" data-tab="cost">Record their costs</button></p><?php endif; ?>
      <small><?= $o['expires_at'] && $o['status'] === 'sent' ? 'Link good until ' . $e(date('M j', strtotime((string) $o['expires_at']))) : '' ?><?= $o['approved_at'] ? ' Approved by ' . $e($o['approved_name']) . ' ' . $e($when($o['approved_at'])) : '' ?></small></div>
  </div>
  <div class="co-msgbox"><b>Message to the client</b> <?= $ed('note', (string) $o['note'], 'On their order and in the email (optional)', $editable) ?></div>

  <div class="hb-card tv-bleed co-table" id="lines">
    <div class="co-th"><span></span><span>#</span><span>Product / service &amp; description</span><span>Qty</span><span>Rate</span><span>Amount</span><span>Tax</span><span></span></div>
    <?php if (!$lines): ?><p class="text-sm" style="margin:.4rem 0">Nothing yet. Tap <b>+ Add item</b> below.</p><?php endif; ?>
    <?php
    // a proof opens in the proof lightbox (js/tv-proof.js): a file as an image or PDF, a GO Code as its QR and what it holds
    $proofLink = function (array $l, array $p, string $label) use ($e, $oid): string {
        $t = $e(preg_replace('/^GO Code: /', '', (string) $l['title']) . ' · version ' . (int) $p['version']);
        if ($p['mime'] === 'go-code') return $l['code'] ? '<a href="/api/qr.php?issued=' . (int) $l['code']['id'] . '&amp;staff=1&amp;format=svg" data-proof="go" data-proof-info="#gi' . (int) $l['id'] . '" data-proof-title="' . $t . '">' . $e($label) . '</a>' : $e($label);
        return '<a href="/api/order-proof.php?o=' . $oid . '&amp;p=' . (int) $p['id'] . '" data-proof="' . ($p['mime'] === 'application/pdf' ? 'pdf' : 'image') . '" data-proof-title="' . $t . '">' . $e($label) . '</a>';
    };
    // the item panel (decisions/0107): status groups for the pill's colour, vendor jobs by item, each item's history
    $grp = function (string $k): string { $i = 0; foreach (ClientOrders::ITEM_STATUS as $opts) { if (isset($opts[$k])) return ['pre', 'ok', 'out', 'ex', 'hk'][$i] ?? 'hk'; $i++; } return 'hk'; };
    $vjobs = VendorOrders::forOrder($pdo, $oid); $hasTags = ClientOrders::hasTags($pdo);
    $vjOf = fn (int $lid) => array_values(array_filter($vjobs, fn ($j) => (int) $j['line_id'] === $lid));
    $vjOrder = array_values(array_filter($vjobs, fn ($j) => $j['line_id'] === null));
    $vjFor = function (int $lid) use ($vjOf, $vjOrder) { return $vjOf($lid)[0] ?? $vjOrder[0] ?? null; };   // its own job, else the order's
    $evOf = fn (int $lid) => array_reverse(array_values(array_filter($events, fn ($ev) => (int) ($ev['line_id'] ?? 0) === $lid)));
    $fileLink = fn (array $f, string $title) => '<a href="/api/order-proof.php?o=' . $oid . '&amp;f=' . (int) $f['id'] . '"' . (isset(ClientOrders::FILE_TYPES[$f['mime']]) ? ' data-proof="' . ($f['mime'] === 'application/pdf' ? 'pdf' : 'image') . '" data-proof-title="' . $e($title) . '"' : ' download') . '>' . $e($f['file_name'] ?: 'file') . '</a>' . (isset($f['size']) ? ' <small class="co-sz">' . Uploads::size((int) $f['size']) . '</small>' : '');
    $proofPill = fn (string $st) => '<span class="hb-pill' . ($st === 'approved' ? ' ok' : ($st === 'changes' ? ' red' : '')) . '" style="margin:0">' . $e(['waiting' => 'Waiting on the client', 'approved' => 'Approved', 'changes' => 'Changes asked for', 'replaced' => 'Replaced'][$st] ?? $st) . '</span>';
    $n = 0;
    $projects = ClientOrders::projects($pdo, $oid); $hasProj = ClientOrders::hasProjects($pdo); $pjNames = array_column($projects, 'title', 'id');
    $groups = $hasProj ? ClientOrders::groups($lines, $projects) : [['project' => null, 'lines' => $lines, 'subtotal' => 0]];
    // a project's items: the client sees each one's price and the project's subtotal (decisions/0101, addendum 2026-10-27)
    foreach ($groups as $g): $gp = $g['project']; $gPrint = $hasProj && array_filter($g['lines'], fn ($x) => ClientOrders::role($pdo, $x) === 'print');
    if ($gp): ?>
    <div class="co-prj" id="p<?= (int) $gp['id'] ?>">
      <div class="co-prjh">
        <?php if ($editable): ?><form method="post" class="co-prjn"><?= $hidden('project_rename') ?><input type="hidden" name="project" value="<?= (int) $gp['id'] ?>"><input class="hb-in" name="title" value="<?= $e($gp['title']) ?>" aria-label="Project name" maxlength="160" onchange="this.form.requestSubmit()"></form>
        <?php else: ?><b><?= $e($gp['title']) ?></b><?php endif; ?>
        <span class="co-prjs">Project · <?= count($g['lines']) ?> item<?= count($g['lines']) === 1 ? '' : 's' ?> · <b><?= $usd($g['subtotal']) ?></b></span>
        <?php if ($editable): ?><button type="button" class="hb-b" data-add-open data-project="<?= (int) $gp['id'] ?>">+ Add item here</button>
        <form method="post"><?= $hidden('project_remove') ?><input type="hidden" name="project" value="<?= (int) $gp['id'] ?>"><button class="co-lk" data-confirm="Take off this project? Its items stay on the order." data-yes="Take it off">Take off project</button></form><?php endif; ?>
      </div>
      <?php if (!$g['lines']): ?><p class="text-sm" style="margin:.3rem 0">No items yet: <b>+ Add item here</b>, or move an item in with its project icon (the folder on its right).</p><?php endif; ?>
    <?php endif;
    foreach ($g['lines'] as $l): $pf = $l['proof']; $n++; $lid = (int) $l['id']; $isShipLine = $l['product'] === 'shipping'; $role = $hasProj ? ClientOrders::role($pdo, $l) : 'other';
      $runQty = $l['product'] === 'product' ? (ClientOrders::runKnown($l) ? ClientOrders::runQty($l) : 0) : (int) $l['qty']; ?>
    <div class="co-line" id="l<?= $lid ?>" data-line="<?= $lid ?>">
      <div class="hd">
        <span class="co-drag" title="Drag to reorder" aria-label="Drag to reorder"><?= $editable || $anyEd ? '⋮⋮' : '' ?></span>
        <span class="co-n"><?= $n ?></span>
        <div class="co-desc">
          <b><?= $ed('title', (string) $l['title'], 'Name', $editable, 'data-lf') ?></b>
          <?php if ($l['options'] !== ''): ?><small><?= $e($l['options']) ?></small><?php endif; ?>
          <div class="co-d"><?= $ed('note', (string) $l['note'], 'Description', $editable, 'data-lf') ?></div>
          <?php if ($hasProj && in_array($l['product'], ['custom'], true)): $pts = $l['parts']; ?>
          <details class="co-more"<?= $pts ? ' open' : '' ?>><summary><?= $pts ? 'Bundled lines (' . count($pts) . '): only you see these; the client sees this item at their total' : 'Bundle lines into this item (only you see them)' ?></summary>
            <?php if ($pts): ?><div class="co-parts"><div class="co-parth"><span>Line</span><span>Qty</span><span>Each</span><span>Our cost</span><span>Amount</span><span></span></div>
            <?php foreach ($pts as $pt): ?><form method="post" class="co-part"><?= $hidden('part_save', $lid) ?><input type="hidden" name="part" value="<?= (int) $pt['id'] ?>">
              <input class="hb-in" name="title" value="<?= $e($pt['title']) ?>" aria-label="Line"<?= $editable ? '' : ' disabled' ?>><input class="hb-in" name="qty" value="<?= (int) $pt['qty'] ?>" inputmode="numeric" aria-label="How many"<?= $editable ? '' : ' disabled' ?>>
              <input class="hb-in" name="unit" value="<?= number_format((int) $pt['unit_cents'] / 100, 2, '.', '') ?>" inputmode="decimal" aria-label="Price each"<?= $editable ? '' : ' disabled' ?>><input class="hb-in" name="cost" value="<?= (int) $pt['cost_cents'] ? number_format((int) $pt['cost_cents'] / 100, 2, '.', '') : '' ?>" inputmode="decimal" aria-label="Our cost each"<?= $editable ? '' : ' disabled' ?>>
              <b><?= $usd((int) $pt['qty'] * (int) $pt['unit_cents']) ?></b>
              <span><?php if ($editable): ?><button class="co-lk">Save</button> <button class="co-lk" name="do" value="part_remove" data-confirm="Take this line out of the bundle?" data-yes="Take it out" data-danger>×</button><?php endif; ?></span></form><?php endforeach; ?></div><?php endif; ?>
            <?php if ($editable): ?><form method="post" class="co-part co-partadd"><?= $hidden('part_add', $lid) ?><input class="hb-in" name="title" placeholder="Translation (German)" aria-label="New line"><input class="hb-in" name="qty" value="1" inputmode="numeric" aria-label="How many"><input class="hb-in" name="price" placeholder="85.00" inputmode="decimal" aria-label="Price each"><input class="hb-in" name="cost" placeholder="cost" inputmode="decimal" aria-label="Our cost each"><span></span><span><button class="hb-b">+ Add</button></span></form>
            <?php if (!$pts): ?><small>The item's price now becomes its first line, so nothing changes until you add more.</small><?php endif; endif; ?>
          </details>
          <?php endif; ?>
          <?php if ($l['code']): $c = $l['code'];
            if (!$c['short_code_id'] && $c['status'] === 'pending' && !in_array($c['type'], QrIssue::DIRECT, true)) { QrIssue::issueShort($pdo, (int) $c['id']); $c = $pdo->query('SELECT q.*, s.code AS short_code FROM qr_issued q LEFT JOIN short_codes s ON s.id = q.short_code_id WHERE q.id = ' . (int) $c['id'])->fetch(PDO::FETCH_ASSOC); }
            $qu = '/api/qr.php?issued=' . (int) $c['id'] . '&staff=1'; $go = $c['short_code'] ? QrIssue::shortUrl((string) $c['short_code']) : ''; $cf = json_decode((string) $c['fields'], true) ?: []; ?>
            <small><?= $e(Qr::TYPES[$c['type']] ?? $c['type']) ?>: <?= $e(QrIssue::holds((string) $c['type'], $cf)) ?></small>
            <template id="gi<?= $lid ?>"><h3><?= $e(QrIssue::KIND[$c['type']] ?? 'GO Code') ?></h3><?= QrIssue::detailsHtml((string) $c['type'], $cf) ?><?php if ($go !== ''): ?><p style="margin:.8rem 0 0;font:600 .85rem system-ui,sans-serif;color:#8A7355"><?= $e(preg_replace('#^https?://#', '', $go)) ?></p><?php endif; ?></template>
            <div class="co-qr"><a href="<?= $e($qu) ?>&amp;format=svg" data-proof="go" data-proof-info="#gi<?= $lid ?>" data-proof-title="<?= $e($c['title'] ?: 'GO Code') ?>" title="See it larger"><img src="<?= $e($qu) ?>&amp;format=png&amp;px=300" alt="The GO Code" loading="lazy"></a>
              <div class="acts"><a class="hb-b" href="<?= $e($qu) ?>&amp;format=svg&amp;download=1">SVG (print)</a><a class="hb-b" href="<?= $e($qu) ?>&amp;format=png&amp;px=1200&amp;download=1">PNG</a>
                <?php if ($go !== ''): ?><a class="hb-b" href="<?= $e($go) ?>" target="_blank" rel="noopener" title="Opens it as a phone would. Before the order is paid it's a proof: it works, and scans aren't counted">Try it</a><?php endif; ?></div>
              <small><?= $go !== '' ? $e(preg_replace('#^https?://#', '', $go)) . ' · ' : '' ?><?= QrIssue::owned($c) ? 'live' : 'a proof until the order is paid (works, not counted)' ?></small></div>
            <?php if ($editable): ?><details class="co-more"><summary>Edit what the code holds</summary>
              <form method="post" class="co-f" novalidate><?= $hidden('go_save', $lid) ?>
                <div class="two"><?php foreach (QrIssue::FIELDS[$c['type']] ?? [] as $k => $lab): $v = (string) ($cf[$k] ?? ''); ?><label><?= $e($lab) ?><?php if (in_array($k, ['text', 'body', 'details', 'note', 'message'], true)): ?><textarea class="hb-in" name="f[<?= $e($c['type']) ?>][<?= $e($k) ?>]" rows="2"><?= $e($v) ?></textarea><?php else: ?><input class="hb-in" name="f[<?= $e($c['type']) ?>][<?= $e($k) ?>]" value="<?= $e($v) ?>"><?php endif; ?></label><?php endforeach; ?></div>
                <input type="hidden" name="title" value="<?= $e($c['title']) ?>"><div><button class="hb-b">Save the code</button></div></form></details><?php endif; ?>
          <?php endif; ?>
          <?php if ($hasItems && !$isShipLine): $ist = ClientOrders::itemStatus($o, $l); $vjl = $vjFor($lid); ?>
          <div class="co-stl">
            <button type="button" class="co-st <?= $grp($ist) ?>" data-item-open="<?= $lid ?>" data-tab="status" title="Status: open the item to change it"><?= $e(ClientOrders::statusLabel($ist)) ?></button>
            <?php foreach (ClientOrders::tags($l) as $tg): ?><span class="co-tag"><?= $e($tg) ?></span><?php endforeach; ?>
            <?php if ($vjl): ?><button type="button" class="co-vst" data-item-open="<?= $lid ?>" data-tab="vendor" title="Our team only: the vendor's own status<?= $vjl['line_id'] === null ? ' (the order\'s job: it covers this item)' : '' ?>"><?= $e($vjl['vendor']) ?>: <?= $e($vjl['job_status'] !== '' ? $vjl['job_status'] : 'no status yet') ?></button><?php endif; ?>
          </div>
          <?php endif; ?>
          <?php if (!$isShipLine && ((int) ($l['ship_cents'] ?? 0) || ($l['ship_style'] ?? '') !== '' || ($l['ship_address'] ?? '') !== '' || ($l['ship_to'] ?? '') !== '' || ($l['tracking'] ?? '') !== '')): ?>
          <button type="button" class="co-shipline" data-ship-open="<?= $lid ?>"><?= $e(ClientOrders::shipLabel($o, $l, $addrs)) ?><?= (int) $l['ship_cents'] ? ' · ' . $usd($l['ship_cents']) : '' ?><?= ($l['tracking'] ?? '') !== '' ? ' · tracking ' . $e($l['tracking']) : '' ?></button>
          <?php endif; ?>
          <div class="co-files">
            <?php if ($pf): $pfs = $l['proof_files']; ?><span><?= !empty($pf['reuse_of']) ? '<b title="A reorder with the same art: the client confirms the reuse">Reuse</b> · ' : '' ?>Proof v<?= (int) $pf['version'] ?><?= count($pfs) > 1 ? ' (' . count($pfs) . ' files)' : '' ?>: <?php foreach ($pfs as $i => $p1): ?><?= $i ? ', ' : '' ?><?= $proofLink($l, $p1, $p1['mime'] === 'go-code' ? 'the GO Code' : ($p1['file_name'] ?: 'the file')) ?><?php endforeach; ?> <?= $proofPill((string) $pf['status']) ?><?php if (count($l['versions']) > 1): ?> <button type="button" class="co-lk" data-item-open="<?= $lid ?>" data-tab="proofs"><?= count($l['versions']) - 1 ?> earlier version<?= count($l['versions']) > 2 ? 's' : '' ?></button><?php endif; ?></span><?php endif; ?>
            <?php $fk = []; foreach ($files[$lid] ?? [] as $f) $fk[(string) ($f['kind'] ?? 'label')][] = $f; foreach ($fk as $kd => $fs): ?><span><?= $e(ClientOrders::FILE_KINDS[$kd] ?? 'File') ?>: <?php if (count($fs) > 2): ?><button type="button" class="co-lk" data-item-open="<?= $lid ?>" data-tab="files"><?= count($fs) ?> files</button><?php else: foreach ($fs as $i => $f): ?><?= $i ? ', ' : '' ?><?= $fileLink($f, (ClientOrders::FILE_KINDS[$kd] ?? 'File') . ' · ' . $l['title']) ?><?php endforeach; endif; ?></span><?php endforeach; ?>
            <?php if ($editable && !$isShipLine && $l['product'] !== 'go_code'): ?><form method="post" enctype="multipart/form-data" class="co-upf"><?= $hidden('proof', $lid) ?><label class="co-up" title="Choose one file or several: they go to the client as one version">+ Upload proof<input type="file" name="file[]" multiple accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/*" hidden></label></form><?php endif; ?>
          </div>
          <?php if ($hasProj && $role === 'creative' && !$gPrint): $appr = (bool) array_filter($l['proofs'], fn ($x) => $x['status'] === 'approved'); ?>
          <div class="co-files co-final"><span>Print-ready file<?= $l['finals'] ? '' : ($appr ? ': none yet' : ': after the client approves the artwork') ?></span>
            <?php foreach ($l['finals'] as $fn): ?><span><a href="/api/order-proof.php?o=<?= $oid ?>&amp;p=<?= (int) $fn['id'] ?>&amp;download=1"><?= $e($fn['file_name']) ?></a> <span class="hb-pill<?= ClientOrders::paidInFull($pdo, $o) ? ' ok' : '' ?>" style="margin:0"><?= ClientOrders::paidInFull($pdo, $o) ? 'Released to the client' : 'Released once paid in full' ?></span>
              <form method="post" style="display:inline"><?= $hidden('final_remove', $lid) ?><input type="hidden" name="proof" value="<?= (int) $fn['id'] ?>"><button class="co-lk" data-confirm="Take this print-ready file off?" data-yes="Take it off" data-danger>×</button></form></span><?php endforeach; ?>
            <?php if ($appr && $o['status'] !== 'void'): ?><label class="co-up">+ Add print-ready file<input type="file" data-final="<?= $lid ?>" hidden></label><?php endif; ?></div>
          <?php elseif ($hasProj && $role === 'creative' && $gPrint): ?><small class="co-meta">Creative in a project with print: the client sees the approved artwork; the print item's file is what they download.</small>
          <?php endif; ?>
          <?php foreach (array_reverse($l['proofs']) as $old) if ($old['client_note'] !== '') { echo '<div class="co-ch"><b>Client asked (v' . (int) $old['version'] . '):</b> ' . $e($old['client_note']) . '</div>'; break; } ?>
          <small class="co-meta"><?= ['product' => 'Catalog', 'go_code' => 'GO Code', 'shipping' => 'Shipping'][$l['product']] ?? 'Custom' ?><?php $cxo = $cxo ?? (Costing::ready($pdo) ? Costing::forOrder($pdo, $oid) : []); $cxl = $cxo[(int) $l['id']] ?? null;
            if (!$cxl): ?><?= (int) $l['cost_cents'] ? ' · cost ' . $usd((int) $l['cost_cents'] * ((int) $l['qty'] ?: 1)) . ($l['product'] === 'product' ? ' (the catalog\'s)' : '') : '' ?><?php
            elseif ($l['product'] === 'product' && ($cp = Products::get($pdo, (int) $l['product_id']))): $cc = Products::priceFor($cp, ClientOrders::runQty($l) / max(1, (int) $l['qty']), Products::pickedFrom($cp, (string) $l['options']))['cost'] * max(1, (int) $l['qty']);
              if ($cc && abs($cc - (int) $cxl['cogs_cents']) > 1): ?> · catalog cost <?= $usd($cc) ?><?php endif; endif; ?><?php if ((int) $l['list_cents'] > (int) $l['unit_cents']): ?> · catalog <?= $usd((int) $l['list_cents']) ?><?php endif; ?>
            <?php if (Costing::ready($pdo) && !in_array($l['product'], ['go_code', 'shipping'], true)): $cxo = $cxo ?? Costing::forOrder($pdo, $oid); $cx = $cxo[(int) $l['id']] ?? null; $cxok = Costing::isChecked($cx); ?> · <button type="button" class="co-lk co-cogs<?= $cxok ? '' : ' no' ?>" data-item-open="<?= (int) $l['id'] ?>" data-tab="cost" title="Our team only: its cost of goods, worked out and checked"><?= $cx ? 'COGS ' . $usd((int) $cx['cogs_cents']) . ($cxok ? ' ✓' : ' (not checked)') : 'Work out its COGS' ?></button><?php endif; ?></small>
        </div>
        <span class="co-q"><?= $l['product'] === 'go_code' ? '1' : $ed('qty', (string) $runQty, 'Qty', $editable, 'data-lf') ?></span>
        <span class="co-u"><?= $ed('unit', $l['product'] === 'product' ? ClientOrders::rate($l) : number_format((int) $l['unit_cents'] / 100, 2, '.', ''), 'Rate', $editable, 'data-lf') ?></span>
        <span class="co-amt"><?= $usd((int) $l['unit_cents'] * (int) $l['qty']) ?></span>
        <span class="co-tax"><input type="checkbox" data-lf="taxable" aria-label="Taxable"<?= $l['taxable'] ? ' checked' : '' ?><?= $editable ? '' : ' disabled' ?>></span>
        <span class="co-ic">
          <?php if ($editable && !$isShipLine): ?><button type="button" class="co-icb" data-edit-open="<?= $lid ?>" title="Edit the item: name, how many, rate, options" aria-label="Edit the item"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg></button><?php endif; ?>
          <?php if (!$isShipLine): ?><button type="button" class="co-icb" data-item-open="<?= $lid ?>" data-tab="status" title="Status: where it is, the vendor's job, its history" aria-label="Its status"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.5a9.5 9.5 0 1 0 9.5 9.5" stroke-dasharray="3.2 2.2"/><path d="M21.5 12l-2.2-2.4M21.5 12l2-2.6" stroke-dasharray="none"/><circle cx="12" cy="12" r="2.3"/><path d="M12 7.6v1.6M12 14.8v1.6M7.6 12h1.6M14.8 12h1.6M8.9 8.9l1.1 1.1M14 14l1.1 1.1M8.9 15.1 10 14M14 10l1.1-1.1"/></svg></button>
          <button type="button" class="co-icb" data-item-open="<?= $lid ?>" data-tab="<?= $l['product'] === 'go_code' ? 'files' : 'proofs' ?>" title="Files: proofs and every version, artwork, documents" aria-label="Its files"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg></button><?php endif; ?>
          <?php if ($hasProj && $editable && !$isShipLine): $inPj = (int) ($l['project_id'] ?? 0); ?><details class="co-pjm"><summary class="co-icb<?= $inPj ? ' on' : '' ?>" title="Project: <?= $e($inPj ? ($pjNames[$inPj] ?? 'a project') : 'on its own') ?>" aria-label="Its project"><svg viewBox="0 0 24 24" width="19" height="19" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><rect x="2.5" y="4" width="7" height="6" rx=".6"/><rect x="15" y="3" width="6.5" height="4.6" rx=".5"/><rect x="15" y="9.7" width="6.5" height="4.6" rx=".5"/><rect x="15" y="16.4" width="6.5" height="4.6" rx=".5"/><path fill="none" d="M9.5 7h2.8M12.3 5.3v13.4M12.3 5.3H15M12.3 12H15M12.3 18.7H15"/></svg></summary>
            <div class="co-pjmenu" role="menu"><b>Project</b>
              <?php foreach (array_merge([['id' => 0, 'title' => 'On its own']], $projects) as $pj): $on = $inPj === (int) $pj['id']; ?><form method="post"><?= $hidden('line_project', $lid) ?><input type="hidden" name="project" value="<?= (int) $pj['id'] ?>"><button role="menuitemradio" aria-checked="<?= $on ? 'true' : 'false' ?>"<?= $on ? ' disabled' : '' ?>><?= $on ? '✓ ' : '' ?><?= $e($pj['title']) ?></button></form><?php endforeach; ?>
              <button type="button" role="menuitem" data-pj-new-line="<?= $lid ?>" data-pj-title="<?= $e($l['title']) ?>">+ New project…</button></div></details><?php endif; ?>
          <?php if (!$isShipLine && $inl && $anyEd): ?><button type="button" class="co-icb" data-ship-open="<?= $lid ?>" title="Shipping for this item" aria-label="Shipping for this item"><svg viewBox="0 0 512 512" width="20" height="20" fill="none" stroke="currentColor" stroke-width="32" stroke-linejoin="round" stroke-linecap="round"><path d="M256 32 32 128v256l224 96 224-96V128z"/><path d="M32 128l224 96 224-96M256 224v256M144 80l224 96v80"/></svg></button><?php endif; ?>
          <?php if ($editable): ?><form method="post"><?= $hidden('line_remove', $lid) ?><button class="co-icb no" title="Delete this item" aria-label="Delete this item" data-confirm="Delete <?= $e($l['title']) ?><?= count($l['proofs']) ? ' and its proofs' : '' ?>?" data-yes="Delete" data-danger><svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/></svg></button></form><?php endif; ?>
        </span>
        <template data-ship-data="<?= $lid ?>"><?= $e(json_encode(['title' => $l['title'], 'style' => $l['ship_style'] ?? '', 'carrier' => $l['ship_carrier'] ?? '', 'address' => $l['ship_address'] ?? '', 'charge' => (int) ($l['ship_cents'] ?? 0) ? number_format($l['ship_cents'] / 100, 2, '.', '') : '', 'cost' => (int) ($l['ship_cost_cents'] ?? 0) ? number_format($l['ship_cost_cents'] / 100, 2, '.', '') : '', 'tracking' => $l['tracking'] ?? ''], JSON_UNESCAPED_UNICODE)) ?></template>
        <?php if ($editable && !$isShipLine): $isProd = $l['product'] === 'product'; $isGo = $l['product'] === 'go_code'; $bundled = $hasProj && !empty($l['parts']);
          $typed = $isProd && (int) $l['list_cents'] > 0 && (int) $l['unit_cents'] !== (int) $l['list_cents']; $cp = $isProd && $l['product_id'] ? Products::get($pdo, (int) $l['product_id']) : null; ?>
        <template data-edit-form="<?= $lid ?>"><form method="post" class="co-f" novalidate data-edit-f><?= $hidden('line_edit', $lid) ?>
          <label>Name<input class="hb-in" name="title" value="<?= $e($l['title']) ?>" maxlength="160" required></label>
          <label>Description<textarea class="hb-in" name="note" rows="2" maxlength="300"><?= $e($l['note']) ?></textarea></label>
          <?php if (!$isGo): ?>
          <div class="two">
            <label><?= $isProd ? 'How many (the run)' : 'Quantity' ?><input class="hb-in" name="qty" value="<?= $runQty ?: '' ?>" inputmode="numeric" placeholder="<?= $isProd ? '1000' : '1' ?>" required<?= $bundled ? ' readonly title="A bundle is one item; its lines have their own quantities"' : '' ?>></label>
            <label>Rate (each)<input class="hb-in" name="rate" value="<?= $e($isProd ? ClientOrders::rate($l) : number_format((int) $l['unit_cents'] / 100, 2, '.', '')) ?>" inputmode="decimal"<?= $bundled ? ' readonly title="Set by the bundled lines"' : '' ?> data-edit-rate></label>
          </div>
          <?php if ($isProd && $cp): ?><label class="co-chk"><input type="checkbox" name="catalog" value="1"<?= $typed ? '' : ' checked' ?> data-edit-cat> Use the catalog's price for this run (<?= $e($cp['name']) ?>)</label><?php endif; ?>
          <?php if ($isProd && !$runQty): ?><small class="co-warn">Its run size was lost when it was renamed: enter it, and check the rate.</small><?php endif; ?>
          <?php if ($bundled): ?><small>Its price is the sum of its bundled lines (change them on the item).</small><?php endif; ?>
          <?php endif; ?>
          <?php if ($cp && $cp['options']): $cur = ClientOrders::pickedOf($pdo, $l); ?><div class="two"><?php foreach ($cp['options'] as $oi => $op): ?><label><?= $e($op['name']) ?><select class="hb-in" name="opt[<?= $oi ?>]"><?php foreach ($op['choices'] as $ch): ?><option<?= ($cur[$oi] ?? '') === $ch['label'] ? ' selected' : '' ?>><?= $e($ch['label']) ?></option><?php endforeach; ?></select></label><?php endforeach; ?></div><?php endif; ?>
          <?php if ($l['product'] === 'custom'): ?><label>Kind (promo codes, and how its files go to the client)<select class="hb-in" name="service_type"><option value="">Not set</option><?php foreach (Promotions::SERVICE_TYPES as $k => $v): if ($k === 'go_code') continue; ?><option value="<?= $e($k) ?>"<?= ($l['service_type'] ?? '') === $k ? ' selected' : '' ?>><?= $e($v) ?></option><?php endforeach; ?></select></label><?php endif; ?>
          <label class="co-chk"><input type="checkbox" name="taxable" value="1"<?= $l['taxable'] ? ' checked' : '' ?>> Taxable</label>
          <div><button class="hb-b go">Save the item</button></div></form></template>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if ($gp): ?></div><?php endif; endforeach; ?>
    <?php $sh = ClientOrders::shipping($pdo, $o); ?>
    <div class="co-sum">
      <?php if ($sh['cents']): ?><div><b><?= $usd((int) $o['subtotal_cents'] - $sh['cents']) ?></b>items</div><div><b><?= $usd($sh['cents']) ?></b>shipping<?php foreach ($sh['rows'] as $r): ?><small class="co-shr"><?= $e($r['title']) ?> → <?= $e($r['to']) ?>: <?= $usd($r['cents']) ?></small><?php endforeach; ?></div><?php endif; ?>
      <?php $pv = ClientOrders::promoPreview($pdo, $o); if ($pv && $pv['off'] > 0): ?><div style="background:#DCEFE5"><b>−<?= $usd($pv['off']) ?></b>code <?= $e($pv['promo']['code']) ?> (<?= $e(Promotions::offer($pv['promo'])) ?>)<?= $pv['applied'] ? '' : ', comes off at approval' ?><?= array_filter(array_column($pv['lines'], 1)) ? '; some lines capped at the 65% profit floor' : '' ?></div><?php endif; ?>
      <div><b><?= $usd($o['subtotal_cents']) ?></b><?= $sh['cents'] ? 'subtotal with shipping' : 'subtotal' ?><?= $pv && $pv['off'] > 0 && !$pv['applied'] ? ' before the code' : '' ?></div>
      <?php if ($editable): ?><div style="display:flex;flex-wrap:wrap;gap:.3rem;align-items:center;max-width:100%"><?php /* promo codes are made in Growth → Promotions and entered by the client at checkout; here we make one, not apply one (Jason, 2026-10-28) */ ?>
        <a class="hb-b" href="/admin/growth/promotions" data-peek-frame title="Opens Promotions over this order: make a code and send it to the client; they enter it on their order page">Make a promo code</a>
        <?php if ($pv): ?><form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="do" value="promo"><input type="hidden" name="code" value=""><button class="co-lk" data-confirm="Take code <?= $e($pv['promo']['code']) ?> off this order?" data-yes="Take it off" data-danger>Take <?= $e($pv['promo']['code']) ?> off</button></form><?php endif; ?></div><?php endif; ?>
      <?php if ($o['approved_at']): ?>
      <div><b><?= $usd($o['tax_cents']) ?></b>tax</div><div><b><?= $usd($o['total_cents']) ?></b>total</div><div><b><?= $usd($m['paid']) ?></b>paid</div>
      <?php if ((int) $o['deposit_cents'] && $m['paid'] < (int) $o['total_cents']): ?><div><b><?= $usd((int) $o['total_cents'] - $m['paid']) ?></b>left</div><?php endif; ?>
      <?php else: ?><div><b>at approval</b>sales tax (from their address)</div><?php endif; ?>
      <?php /* staff only (decisions/0106): our vendor cost against the client's price; never on the client's page */
      require_once __DIR__ . '/../../app/lib/VendorOrders.php'; $vm = VendorOrders::ready($pdo) ? VendorOrders::margin($pdo, $o) : null;
      if ($vm): ?><div style="<?= $vm['margin'] < 0 ? 'background:#FEE2E2;' : 'background:#DCEFE5;' ?>"><b><?= $usd($vm['margin']) ?></b>margin (<?= (int) $vm['pct'] ?>%) · vendor cost <?= $usd($vm['cost']) ?> · our team only</div><?php endif; ?>
      <?php /* profit from each item's COGS (its Cost tab), else its catalog cost; staff only (Jason, 2026-10-29) */
      if (Costing::ready($pdo)): $cxo = $cxo ?? Costing::forOrder($pdo, $oid); $pc = 0; $nW = 0; $nAll = 0; $nChk = 0;
        foreach ($lines as $pl) { $nAll++; $cr = $cxo[(int) $pl['id']] ?? null; if ($cr) { $pc += (int) $cr['cogs_cents']; $nW++; if (Costing::isChecked($cr)) $nChk++; } else $pc += (int) $pl['cost_cents'] * ((int) $pl['qty'] ?: 1); }
        $sub = (int) $o['subtotal_cents']; $pf = $sub - $pc;
        if ($nW): ?><div class="co-profit" style="<?= $pf < 0 ? 'background:#FEE2E2;' : 'background:#DCEFE5;' ?>"><b><?= $usd($pf) ?></b>profit (<?= $sub ? round($pf / $sub * 100) : 0 ?>%, <?= number_format($sub / max(1, $pc), 2) ?>× cost) · COGS <?= $usd($pc) ?><small style="display:block;color:#3E6B55"><?= $nW ?> of <?= $nAll ?> items worked out<?= $nChk < $nW ? ' (' . ($nW - $nChk) . ' not checked)' : ', all checked' ?><?= $nW < $nAll ? '; the rest at catalog cost' : '' ?> · before tax · our team only</small></div><?php endif; endif; ?>
    </div>
  </div>

  <?php if ($editable): ?>
  <p style="margin:.5rem 0;display:flex;flex-wrap:wrap;gap:.4rem"><button type="button" class="hb-b go co-plus" data-add-open>+ Add item</button><?php if (ClientOrders::hasProjects($pdo)): ?><button type="button" class="hb-b" data-pj-add>+ New project</button><?php endif; ?></p>
  <form method="post" id="co-pjf" hidden><?= $hidden('project_add') ?><input type="hidden" name="title"><input type="hidden" name="line" value="0"></form>
  <?php endif; ?>
  <?php if ($inl): $odocs = array_values(array_filter($files[0] ?? [], fn ($f) => ($f['kind'] ?? '') !== 'label')); ?>
  <div class="hb-card tv-bleed co-docs" id="docs">
    <h2 class="hb-h" style="margin:0">Files &amp; versions</h2>
    <h3 style="margin:.5rem 0 0;font-size:1rem">The order's documents <small>(our team only: a contract, a P.O., a brief, the client's files for the whole job)</small></h3>
    <?php if (!$odocs): ?><p class="co-note" style="margin:.2rem 0">None yet.</p><?php else: ?><ul><?php foreach ($odocs as $f): ?><li><?= $fileLink($f, (ClientOrders::FILE_KINDS[$f['kind']] ?? 'File') . ' · order #' . $oid) ?> <small><?= $e(ClientOrders::FILE_KINDS[$f['kind']] ?? 'File') ?><?= !empty($f['created_at']) ? ' · ' . $e(date('M j', strtotime((string) $f['created_at']))) : '' ?></small>
      <?php if ($anyEd): ?><form method="post" style="display:inline"><?= $hidden('file_remove') ?><input type="hidden" name="file" value="<?= (int) $f['id'] ?>"><button class="co-lk" data-confirm="Take <?= $e($f['file_name']) ?> off the order?" data-yes="Take it off" data-danger>Remove</button></form><?php endif; ?></li><?php endforeach; ?></ul><?php endif; ?>
    <?php if ($anyEd): ?><form method="post" enctype="multipart/form-data" class="co-f" style="grid-template-columns:auto minmax(0,1fr) auto;align-items:end"><?= $hidden('order_files') ?>
      <label>Kind<select class="hb-in" name="kind"><?php foreach (array_keys(array_diff_key(ClientOrders::FILE_KINDS, ['label' => 1])) as $k): ?><option value="<?= $k ?>"><?= $e(ClientOrders::FILE_KINDS[$k]) ?></option><?php endforeach; ?></select></label>
      <label>Files: one or several<input class="hb-in" type="file" name="file[]" multiple></label>
      <div><button class="hb-b">Add to the order</button></div></form><?php endif; ?>
    <?php $withFiles = array_filter($lines, fn ($x) => $x['product'] !== 'shipping'); if ($withFiles): ?>
    <h3 style="margin:.7rem 0 0;font-size:1rem">Each item's proofs and files</h3>
    <table><tr><th>Item</th><th>Proofs (the client sees)</th><th>Other files (ours)</th></tr>
    <?php foreach ($withFiles as $x): $xl = (int) $x['id']; $nv = count($x['versions']); $nf = count($files[$xl] ?? []); ?>
      <tr><td><a href="#l<?= $xl ?>"><?= $e($x['title']) ?></a></td>
        <td><button type="button" class="co-lk" data-item-open="<?= $xl ?>" data-tab="proofs"><?php $npf = count($x['proof_files'] ?? []); ?><?= $nv ? 'v' . (int) max(array_keys($x['versions'])) . ' · ' . $npf . ' file' . ($npf === 1 ? '' : 's') . ($nv > 1 ? ' · ' . ($nv - 1) . ' earlier' : '') : 'none yet' ?></button><?= $x['finals'] ? ' · print-ready ' . count($x['finals']) : '' ?></td>
        <td><button type="button" class="co-lk" data-item-open="<?= $xl ?>" data-tab="files"><?= $nf ? $nf . ' file' . ($nf === 1 ? '' : 's') : 'none · add' ?></button></td></tr>
    <?php endforeach; ?></table>
    <small class="co-note">Each item's panel keeps every version: open its Proofs to see them all, replace or remove a file; its Files for artwork, reference, documents and labels.</small>
    <?php endif; ?>
  </div>
  <?php endif; ?>
  <?php if ($shipOk && Shipments::shipped($o)):
    Shipments::ensureLots($pdo, $oid);
    $dests = Shipments::destinations($pdo, $o); $lotsBy = Shipments::lots($pdo, $oid); $packs = Shipments::packs($pdo, $oid);
    $lineBy = array_column($lines, null, 'id'); $carr = ClientOrders::CARRIERS; ?>
  <h2 class="hb-h" id="ship">Shipping &amp; manifests <a class="co-print" href="/admin/manifest.php?id=<?= $oid ?>" target="_blank" rel="noopener">Print the master manifest ↗</a></h2>
  <?php foreach ($dests as $did => $d):
    $dl = []; foreach ($lotsBy as $lid0 => $ls) foreach ($ls as $lt) if ((int) $lt['dest_id'] === $did) $dl[] = $lt;
    $dp = array_filter($packs, fn ($p) => (int) $p['dest_id'] === $did);
    $actual = array_sum(array_map(fn ($p) => (int) $p['cost_cents'], $dp));
    $left = array_sum(array_map(fn ($lt) => max(0, (int) $lt['qty'] - (int) $lt['packed']), $dl)); ?>
  <div class="hb-card tv-bleed co-dest" id="d<?= $did ?>">
    <div class="co-dest-hd"><div><b><?= $e($d['label']) ?></b> <span class="co-note"><?= $e($d['text'] ?: ((int) $d['is_main'] ? 'Fill in Ship to above' : '')) ?></span></div>
      <div class="co-money">Estimate <b><?= $usd((int) $d['est_cents']) ?></b> · actual <b><?= $usd($actual) ?></b><?php if ($dp && $actual !== (int) $d['est_cents']): ?> <span class="hb-pill <?= $actual > (int) $d['est_cents'] ? 'red' : 'ok' ?>"><?= $actual > (int) $d['est_cents'] ? '+' : '−' ?><?= $usd(abs($actual - (int) $d['est_cents'])) ?></span><?php endif; ?>
        · <a class="hb-go" href="/admin/manifest.php?id=<?= $oid ?>&amp;dest=<?= $did ?>" target="_blank" rel="noopener">Manifest ↗</a></div></div>
    <?php if ($anyEd): ?><details class="co-more"><summary>Edit this destination</summary>
      <form method="post" class="co-f" novalidate><?= $hidden('dest_save') ?><input type="hidden" name="dest" value="<?= $did ?>">
        <div class="three"><label>Call it<input class="hb-in" name="label" value="<?= $e($d['label']) ?>" maxlength="80"></label><label>Method (how it goes)<input class="hb-in" name="method" value="<?= $e($d['method']) ?>" maxlength="60" placeholder="UPS Ground, USPS flat rate"></label><label>Shipping estimate (charged)<input class="hb-in" name="est" inputmode="decimal" value="<?= (int) $d['est_cents'] ? number_format($d['est_cents'] / 100, 2, '.', '') : '' ?>" placeholder="0.00"<?= $editable ? '' : ' readonly' ?>></label></div>
        <?php if (!(int) $d['is_main']): ?><div class="three"><label>Name on the package<input class="hb-in" name="name" value="<?= $e($d['name']) ?>" maxlength="120"></label><label>Street<input class="hb-in" name="street" value="<?= $e($d['street']) ?>" maxlength="160"></label><label>Town<input class="hb-in" name="city" value="<?= $e($d['city']) ?>" maxlength="80"></label></div>
        <div class="three"><label>State<input class="hb-in" name="state" value="<?= $e($d['state']) ?>" maxlength="2"></label><label>ZIP<input class="hb-in" name="zip" value="<?= $e($d['zip']) ?>" maxlength="10"></label><span></span></div><?php endif; ?>
        <div><button class="hb-b">Save</button></div></form>
      <?php if (!(int) $d['is_main']): ?><form method="post" style="margin-top:.3rem"><?= $hidden('dest_delete') ?><input type="hidden" name="dest" value="<?= $did ?>"><button class="hb-b no" data-confirm="Remove <?= $e($d['label']) ?>? Its lots go back to Ship to." data-yes="Remove" data-danger>Remove this destination</button></form><?php endif; ?>
    </details><?php endif; ?>
    <table class="co-lots"><thead><tr><th>Item</th><th>Lot</th><th>Qty</th><th>Packed</th></tr></thead><tbody>
      <?php if (!$dl): ?><tr><td colspan="4" class="co-note">Nothing goes here yet. Send items or lots here with their ship icon.</td></tr><?php endif; ?>
      <?php foreach ($dl as $lt): ?><tr><td><?= $e($lineBy[(int) $lt['line_id']]['title'] ?? '') ?></td><td><?= $e($lt['label']) ?></td><td><?= (int) $lt['qty'] ?></td><td class="<?= (int) $lt['packed'] >= (int) $lt['qty'] ? 'ok' : 'warn' ?>"><?= (int) $lt['packed'] ?></td></tr><?php endforeach; ?>
    </tbody></table>
    <?php if ($dl && $left): ?><p class="co-warn"><?= $left ?> not packed yet.</p><?php elseif ($dl): ?><p class="co-okp">Everything here is packed.</p><?php endif; ?>
    <?php $pn = 0; foreach ($dp as $pid => $p): $pn++; ?>
    <div class="co-pack"><b>Pack <?= $pn ?></b> <?= $e($p['box']) ?><?= (float) $p['weight_lb'] ? ' · ' . $e(rtrim(rtrim((string) $p['weight_lb'], '0'), '.')) . ' lb' : '' ?><?= $p['carrier'] !== '' ? ' · ' . $e($carr[$p['carrier']] ?? '') : '' ?><?= $p['service'] !== '' ? ' ' . $e($p['service']) : '' ?><?= (int) $p['cost_cents'] ? ' · ' . $usd($p['cost_cents']) : '' ?><?= $p['tracking'] !== '' ? ' · ' . $e($p['tracking']) : '' ?>
      <small><?= $e(implode(', ', array_map(function ($lid1, $q) use ($dl, $lineBy) { foreach ($dl as $lt) if ((int) $lt['id'] === $lid1) return $q . ' × ' . ($lineBy[(int) $lt['line_id']]['title'] ?? '') . ($lt['label'] !== '' ? ' (' . $lt['label'] . ')' : ''); return ''; }, array_keys($p['items'] ?? []), $p['items'] ?? []))) ?: 'Empty' ?></small>
      <span class="co-pack-a"><a class="hb-go" href="/admin/manifest.php?id=<?= $oid ?>&amp;pack=<?= $pid ?>" target="_blank" rel="noopener">Packing slip ↗</a><?php if ($p['label_id']): ?> <a class="hb-go" href="/api/order-proof.php?o=<?= $oid ?>&amp;f=<?= (int) $p['label_id'] ?>" data-proof="image" data-proof-title="Label · pack <?= $pn ?>">Label</a><?php endif; ?></span>
      <details class="co-more"><summary>Edit</summary><?php $pk = $p; include __DIR__ . '/../../app/ui/pack-form.php'; ?>
        <form method="post"><?= $hidden('pack_delete') ?><input type="hidden" name="pack" value="<?= $pid ?>"><button class="hb-b no" data-confirm="Remove this pack?" data-yes="Remove" data-danger>Remove the pack</button></form></details>
    </div>
    <?php endforeach; ?>
    <?php if ($dl): ?><details class="co-more"><summary>+ Add a pack</summary><?php $pk = ['id' => 0, 'dest_id' => $did, 'items' => []]; include __DIR__ . '/../../app/ui/pack-form.php'; ?></details><?php endif; ?>
  </div>
  <?php endforeach; ?>
  <?php if (Shipments::mode($o) === 'multi'): ?>
  <details class="hb-card tv-bleed co-more"><summary>+ Add a destination</summary>
    <form method="post" class="co-f" novalidate><?= $hidden('dest_save') ?>
      <div class="three"><label>Call it<input class="hb-in" name="label" maxlength="80" placeholder="Store 2, Event venue"></label><label>Name on the package<input class="hb-in" name="name" maxlength="120"></label><label>Street<input class="hb-in" name="street" maxlength="160"></label></div>
      <div class="three"><label>Town<input class="hb-in" name="city" maxlength="80"></label><label>State<input class="hb-in" name="state" maxlength="2" placeholder="AZ"></label><label>ZIP<input class="hb-in" name="zip" maxlength="10" inputmode="numeric"></label></div>
      <div class="two"><label>Method<input class="hb-in" name="method" maxlength="60" placeholder="UPS Ground"></label><label>Shipping estimate (charged)<input class="hb-in" name="est" inputmode="decimal" placeholder="0.00"></label></div>
      <div><button class="hb-b go">Add the destination</button></div></form>
  </details>
  <?php endif; ?>
  <div class="co-dlg" id="co-lots" hidden role="dialog" aria-modal="true" aria-label="Lots and destinations">
   <div class="co-dlg-box" style="width:min(40rem,calc(100% - 24px))">
    <div class="co-dlg-bar"><b>Lots: <span data-lots-title></span></b><span style="flex:1"></span><button type="button" class="co-dlg-x" data-lots-close aria-label="Close">×</button></div>
    <form method="post" class="co-f co-dlg-body" novalidate><?= $hidden('lots_save') ?><input type="hidden" name="line" value="">
      <p class="co-note" style="margin:0">Split the item into lots and send each where it goes. <span data-lots-sum></span></p>
      <div data-lots-rows></div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:center"><button type="button" class="hb-b" data-lot-add>+ Lot</button>
        <span>Split into <input class="hb-in" style="width:4.5rem;display:inline-block" data-split-n inputmode="numeric" placeholder="10"> equal lots <button type="button" class="hb-b" data-split>Split</button></span></div>
      <div><button class="hb-b go">Save the lots</button></div>
    </form>
   </div>
  </div>
  <template id="co-lots-data"><?= $e(json_encode(['dests' => array_map(fn ($d) => ['id' => (int) $d['id'], 'label' => $d['label']], array_values($dests)), 'single' => Shipments::mode($o) === 'single',
      'lines' => array_map(fn ($l) => ['id' => (int) $l['id'], 'title' => $l['title'], 'qty' => Shipments::itemQty($l), 'lots' => array_map(fn ($lt) => ['id' => (int) $lt['id'], 'qty' => (int) $lt['qty'], 'dest' => (int) $lt['dest_id'], 'label' => $lt['label']], $lotsBy[(int) $l['id']] ?? [])], Shipments::shippable($lines))], JSON_UNESCAPED_UNICODE)) ?></template>
  <?php endif; ?>
  <?php // the item panel (decisions/0107): one item at a time beside the order, its tabs from the row's buttons ?>
  <aside class="co-ip" id="co-item" hidden role="dialog" aria-label="The item">
    <div class="co-ip-bar"><b><span data-ip-title></span><small data-ip-cur></small></b><button type="button" class="co-ip-menu" data-ip-menu aria-haspopup="true" aria-expanded="false" aria-label="The item's tools" title="The item's tools">☰</button><button type="button" class="co-dlg-x" data-ip-close aria-label="Close" title="Close">×</button>
      <div class="co-ip-tabs" role="menu" hidden><?php foreach (['details' => 'Details', 'status' => 'Status', 'proofs' => 'Proofs', 'files' => 'Files', 'shipping' => 'Shipping', 'vendor' => 'Vendor', 'cost' => 'Cost'] as $tk => $tl): ?><button type="button" role="menuitem" data-ip-tab="<?= $tk ?>" aria-selected="false"><?= $tl ?></button><?php endforeach; ?></div></div>
    <?php foreach ($lines as $l): if ($l['product'] === 'shipping') continue; $lid = (int) $l['id']; $ist = ClientOrders::itemStatus($o, $l);
      $tabs = ['details', 'status', 'proofs']; if ($inl) { $tabs[] = 'files'; $tabs[] = 'shipping'; } if (VendorOrders::ready($pdo)) $tabs[] = 'vendor'; if (!in_array($l['product'], ['go_code'], true)) $tabs[] = 'cost';
      $own = $vjOf($lid); $jobsHere = array_merge($own, $own ? [] : $vjOrder); ?>
    <section class="co-ip-body" data-ip="<?= $lid ?>" data-title="<?= $e($l['title']) ?>" data-tabs="<?= implode(',', $tabs) ?>" hidden>
      <div data-pane="details">
        <dl class="co-ip-dl"><dt>Item</dt><dd><?= $e($l['title']) ?></dd><?php if ($l['options'] !== ''): ?><dt>Options</dt><dd><?= $e($l['options']) ?></dd><?php endif; ?>
          <?php if ($l['note'] !== ''): ?><dt>Description</dt><dd><?= $e($l['note']) ?></dd><?php endif; ?>
          <dt>Qty × rate</dt><dd><?= ClientOrders::runQty($l) ?> × $<?= $e($l['product'] === 'product' ? ClientOrders::rate($l) : number_format((int) $l['unit_cents'] / 100, 2)) ?> = <b><?= $usd((int) $l['unit_cents'] * (int) $l['qty']) ?></b></dd>
          <dt>Status</dt><dd><button type="button" class="co-st <?= $grp($ist) ?>" data-ip-go="status"><?= $e(ClientOrders::statusLabel($ist)) ?></button></dd></dl>
        <?php if ($editable): ?><p class="co-note">Change the name, description, quantity and rate on the order itself.</p><?php endif; ?>
        <?php if ($hasTags): ?>
        <form method="post" class="co-f"><?= $hidden('tags', $lid) ?>
          <label>Tags (our team only)<input class="hb-in" name="tags" value="<?= $e(implode(', ', ClientOrders::tags($l))) ?>" placeholder="Rush, Reprint, Sample" data-tags></label>
          <div class="co-tagq"><?php foreach (ClientOrders::TAGS as $tg): ?><button type="button" class="co-tag" data-tag-add="<?= $e($tg) ?>" title="Add or remove <?= $e($tg) ?>"><?= $e($tg) ?></button><?php endforeach; ?></div>
          <div><button class="hb-b">Save tags</button></div></form>
        <?php endif; ?>
      </div>
      <div data-pane="status" hidden>
        <form method="post" class="co-f"><?= $hidden('line_status', $lid) ?><input type="hidden" name="ip" value="1">
          <label>Status<select class="hb-in" name="status"><?php foreach (ClientOrders::ITEM_STATUS as $g => $opts): ?><optgroup label="<?= $e($g) ?>"><?php foreach ($opts as $k => $lab): ?><option value="<?= $k ?>"<?= $ist === $k ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></optgroup><?php endforeach; ?></select></label>
          <label>Tracking (when it ships)<input class="hb-in" name="tracking" value="<?= $e($l['tracking'] ?? '') ?>"></label>
          <div><button class="hb-b">Save the status</button></div>
          <small class="co-note">The client isn't emailed: use <b>Send an update</b> on the order when you want them told.<?php if ($jobsHere): ?> The vendor's status moves this item forward on its own (never back).<?php endif; ?></small></form>
        <h4>History</h4>
        <?php $evs = $evOf($lid); if (!$evs): ?><p class="co-note">Nothing yet.</p><?php endif; ?>
        <ol class="co-ip-hist"><?php foreach ($evs as $ev): ?><li><small><?= $e(date('M j, g:i a', strtotime((string) $ev['created_at']))) ?><?= ($ev['actor_name'] ?? '') !== '' ? ' · ' . $e($ev['actor_name']) : '' ?></small><?= $e((string) $ev['note']) ?></li><?php endforeach; ?></ol>
      </div>
      <div data-pane="proofs" hidden>
        <?php if (!$l['versions']): ?><p class="co-note">No proof yet.</p><?php endif; ?>
        <?php foreach (array_reverse($l['versions'], true) as $v => $pfs): $p0 = $pfs[0]; ?>
        <div class="co-ip-ver"><b>Version <?= (int) $v ?></b> <?= $proofPill((string) $p0['status']) ?> <small><?= !empty($p0['created_at']) ? $e(date('M j, g:i a', strtotime((string) $p0['created_at']))) : '' ?><?= !empty($p0['decided_at']) ? ' · answered ' . $e(date('M j', strtotime((string) $p0['decided_at']))) : '' ?><?= ($p0['client_initials'] ?? '') !== '' ? ' · final approval initialled <b>' . $e($p0['client_initials']) . '</b>' . (($p0['client_ip'] ?? '') !== '' ? ' from ' . $e($p0['client_ip']) : '') : '' ?></small>
          <?php $vRet = $p0['mime'] !== 'go-code' && ClientOrders::canRetireProofs($pdo); $vAll = $vRet && !array_filter($pfs, fn ($x) => empty($x['retired_at'])); ?>
          <?php if ($vRet && $anyEd): ?><form method="post" style="display:inline"><?= $hidden($vAll ? 'version_restore' : 'version_retire', $lid) ?><input type="hidden" name="proof" value="<?= (int) $p0['id'] ?>"><input type="hidden" name="back" value="item=<?= (int) $lid ?>:proofs"><button class="co-lk" title="<?= $vAll ? 'Show this version to the client again' : 'Take this version away from the client and from work orders (kept here)' ?>"><?= $vAll ? 'Restore version' : 'Retire version' ?></button></form><?php endif; ?>
          <ul><?php foreach ($pfs as $p1): ?><li<?= !empty($p1['retired_at']) ? ' class="co-ret"' : '' ?>><?= $proofLink($l, $p1, $p1['mime'] === 'go-code' ? 'the GO Code' : ($p1['file_name'] ?: 'the file')) ?><?= !empty($p1['retired_at']) ? ' <small class="co-wf-x">retired: the client doesn\'t see it</small>' : '' ?>
            <?php if ($vRet && $anyEd): ?><form method="post" style="display:inline"><?= $hidden(empty($p1['retired_at']) ? 'proof_retire' : 'proof_restore', $lid) ?><input type="hidden" name="proof" value="<?= (int) $p1['id'] ?>"><input type="hidden" name="back" value="item=<?= (int) $lid ?>:proofs"><button class="co-lk"><?= empty($p1['retired_at']) ? 'Retire' : 'Restore' ?></button></form><?php endif; ?>
            <?php if ($editable && $p1['mime'] !== 'go-code'): ?> <label class="co-lk" style="cursor:pointer">Replace<input type="file" data-replace-proof="<?= (int) $p1['id'] ?>" accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/*" hidden></label>
            <form method="post" style="display:inline"><?= $hidden('proof_remove', $lid) ?><input type="hidden" name="proof" value="<?= (int) $p1['id'] ?>"><button class="co-lk" data-confirm="Take <?= $e($p1['file_name']) ?> out of version <?= (int) $v ?>?" data-yes="Take it out" data-danger>Remove</button></form><?php endif; ?></li><?php endforeach; ?></ul>
          <?php if (($p0['client_note'] ?? '') !== ''): ?><div class="co-ch"><b>Client asked:</b> <?= $e($p0['client_note']) ?></div><?php endif; ?></div>
        <?php endforeach; ?>
        <?php if ($editable && $l['product'] !== 'go_code'): ?>
        <form method="post" enctype="multipart/form-data" class="co-f"><?= $hidden('proof', $lid) ?><input type="hidden" name="ip" value="1">
          <label>New version (v<?= ($l['versions'] ? max(array_keys($l['versions'])) : 0) + 1 ?>): one file or several<input class="hb-in" type="file" name="file[]" multiple accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/*"></label>
          <div><button class="hb-b">Upload the version</button></div>
          <small class="co-note">PDF, PNG, JPG or WebP, up to 12 files. The client approves or asks for changes on the version as a whole; earlier versions stay here.</small></form>
        <?php elseif (!$editable): ?><p class="co-note">The client has approved the order, so its proofs are final.</p><?php endif; ?>
      </div>
      <?php if ($inl): ?>
      <div data-pane="files" hidden>
        <?php $fk = []; foreach ($files[$lid] ?? [] as $f) $fk[(string) ($f['kind'] ?? 'label')][] = $f; if (!$fk): ?><p class="co-note">No files yet. Keep the client's artwork, reference files and labels here (our team only).</p><?php endif; ?>
        <?php foreach ($fk as $kd => $fs): ?><h4><?= $e(ClientOrders::FILE_KINDS[$kd] ?? 'Files') ?></h4><ul class="co-ip-files"><?php foreach ($fs as $f): ?><li><?= $fileLink($f, (ClientOrders::FILE_KINDS[$kd] ?? 'File') . ' · ' . $l['title']) ?> <small><?= !empty($f['created_at']) ? $e(date('M j', strtotime((string) $f['created_at']))) : '' ?></small>
          <?php if (!empty($f['retired_at'])): ?><small class="co-wf-x">retired: not offered for work orders</small><?php endif; ?>
          <?php if ($anyEd && ClientOrders::canRetire($pdo)): ?><form method="post" style="display:inline"><?= $hidden(empty($f['retired_at']) ? 'file_retire' : 'file_restore', $lid) ?><input type="hidden" name="file" value="<?= (int) $f['id'] ?>"><input type="hidden" name="back" value="l<?= (int) $lid ?>"><button class="co-lk" title="<?= empty($f['retired_at']) ? 'Keep it on the order, but never offer it for a work order' : 'Offer it for work orders again' ?>"><?= empty($f['retired_at']) ? 'Retire' : 'Restore' ?></button></form><?php endif; ?>
          <?php if ($anyEd): ?><form method="post" style="display:inline"><?= $hidden('file_remove', $lid) ?><input type="hidden" name="ip" value="1"><input type="hidden" name="file" value="<?= (int) $f['id'] ?>"><button class="co-lk" data-confirm="Take <?= $e($f['file_name']) ?> off?" data-yes="Take it off" data-danger>Remove</button></form><?php endif; ?></li><?php endforeach; ?></ul><?php endforeach; ?>
        <?php if ($anyEd): ?>
        <form method="post" enctype="multipart/form-data" class="co-f"><?= $hidden('item_files', $lid) ?>
          <label>Kind<select class="hb-in" name="kind"><?php foreach (ClientOrders::FILE_KINDS as $k => $lab): ?><option value="<?= $k ?>"><?= $e($lab) ?></option><?php endforeach; ?></select></label>
          <label>Files: one or several<input class="hb-in" type="file" name="file[]" multiple></label>
          <div><button class="hb-b">Add the files</button></div>
          <small class="co-note">Artwork, reference and documents: PDF, images, SVG, TIFF, EPS, PSD, AI, InDesign, Word, Excel, PowerPoint, text or ZIP, up to 1 GB each. Labels: PDF or an image.</small></form>
        <?php endif; ?>
      </div>
      <div data-pane="shipping" hidden>
        <p class="co-note"><?= $e(ClientOrders::shipLabel($o, $l, $addrs)) ?><?= (int) ($l['ship_cents'] ?? 0) ? ' · ' . $usd($l['ship_cents']) : '' ?><?= ($l['tracking'] ?? '') !== '' ? ' · tracking ' . $e($l['tracking']) : '' ?></p>
        <?php if ($anyEd): ?><button type="button" class="hb-b" data-ship-open="<?= $lid ?>">Edit the shipping</button><?php endif; ?>
      </div>
      <?php endif; ?>
      <?php if (VendorOrders::ready($pdo)): ?>
      <div data-pane="vendor" hidden>
        <?php if (Vendors::ready($pdo) && !in_array($l['product'], ['shipping', 'go_code'], true)): $lv = Vendors::forLine($pdo, $l); ?>
        <form method="post" class="co-f"><?= $hidden('line_vendor', $lid) ?>
          <label>Who makes it<select class="hb-in" name="vendor_id" onchange="this.form.requestSubmit()"><option value="0">Not chosen yet</option><?php foreach (Vendors::all($pdo, true) as $v): ?><option value="<?= (int) $v['id'] ?>"<?= $lv && (int) $lv['id'] === (int) $v['id'] ? ' selected' : '' ?>><?= $e($v['name']) ?><?= $v['email'] !== '' ? ' · ' . $e($v['email']) : '' ?></option><?php endforeach; ?></select></label>
          <small><?= $lv && empty($l['vendor_id']) ? 'From the product (' . $e($lv['name']) . '); choose to set it for this item. ' : '' ?><a href="/admin/backoffice/vendor_list" data-peek-frame data-title="Vendors">Set up vendors</a> (emails, contacts, account numbers)<?php if (WorkOrders::ready($pdo) && in_array($o['status'], ['pending', 'paid', 'part_refunded'], true)): ?> · <a href="#wo-new" data-wo-for="<?= $lid ?>">Send a work order</a><?php elseif (WorkOrders::ready($pdo) && in_array($o['status'], ['draft', 'sent'], true)): ?> · <a href="#outside" data-wo-for="<?= $lid ?>">Handled outside: create the work order</a><?php endif; ?></small>
        </form>
        <?php endif; ?>
        <?php if (!$jobsHere): ?><p class="co-note">No vendor job tracked yet. Once the vendor has it, add their job from the order's case in the Pulse (Add a vendor job, or Paste from 4OVER).</p><?php endif; ?>
        <?php if (!$own && $vjOrder): ?><p class="co-note">This item follows the order's job below, since it has none of its own. Set a job to this item to track it alone.</p><?php endif; ?>
        <?php foreach ($jobsHere as $j): $to1 = VendorOrders::itemStatusFor((string) $j['job_status'], (string) $j['tracking']); ?>
        <div class="co-ip-ver"><b><?= $e(VendorOrders::label($pdo, (int) $j['id'])) ?></b>
          <small><?= $j['job_status'] !== '' ? 'Their status: ' . $e($j['job_status']) . ($to1 ? ' → this item: ' . $e(ClientOrders::statusLabel($to1)) : ' (doesn\'t move the item)') : 'No status from them yet' ?><?= $j['completion_on'] ? ' · completes ' . $e(date('M j', strtotime((string) $j['completion_on']))) : '' ?></small>
          <form method="post" class="co-f co-ip-for"><?= $hidden('vjob_line', $lid) ?><input type="hidden" name="job" value="<?= (int) $j['id'] ?>">
            <label>This job is for<select class="hb-in" name="for" onchange="this.form.requestSubmit()"><option value="0"<?= $j['line_id'] === null ? ' selected' : '' ?>>The whole order (every item without its own job)</option><?php foreach ($lines as $l2): if ($l2['product'] === 'shipping') continue; ?><option value="<?= (int) $l2['id'] ?>"<?= (int) $j['line_id'] === (int) $l2['id'] ? ' selected' : '' ?>><?= $e($l2['title']) ?></option><?php endforeach; ?></select></label></form></div>
        <?php endforeach; ?>
        <?php $cost = 0; $anyC = false; foreach ($own as $j) if ($j['total_cents'] !== null) { $cost += (int) $j['total_cents']; $anyC = true; } $price = (int) $l['unit_cents'] * (int) $l['qty'];
        if ($anyC): ?><p class="co-margin">Our cost <?= $usd($cost) ?> · price <?= $usd($price) ?> · margin <b><?= $usd($price - $cost) ?></b><?= $price ? ' (' . round(($price - $cost) / $price * 100) . '%)' : '' ?> <small>our team only</small></p>
        <?php elseif ($vjOrder): ?><p class="co-note">The cost is on the order's job: see the order's margin.</p><?php endif; ?>
        <p><a class="hb-go" href="/admin/vendors.php">All vendor orders</a></p>
      </div>
      <?php endif; ?>
      <?php if (!in_array($l['product'], ['go_code'], true)): ?><div data-pane="cost" hidden><?= tv_cost_pane($pdo, $l, $hidden) ?></div><?php endif; ?>
    </section>
    <?php endforeach; ?>
  </aside>
  <?php if (ClientOrders::hasInline($pdo) && $o['status'] !== 'void'): ?>
  <div class="co-dlg" id="co-edit" hidden role="dialog" aria-modal="true" aria-label="Edit an item">
   <div class="co-dlg-box" style="width:min(36rem,calc(100% - 24px))">
    <div class="co-dlg-bar"><b>Edit: <span data-edit-title></span></b><span style="flex:1"></span><button type="button" class="co-dlg-x" data-edit-close aria-label="Close">×</button></div>
    <div class="co-dlg-body" data-edit-body></div></div></div>
  <div class="co-dlg" id="co-ship" hidden role="dialog" aria-modal="true" aria-label="Shipping for an item">
   <div class="co-dlg-box" style="width:min(36rem,calc(100% - 24px))">
    <div class="co-dlg-bar"><b>Shipping: <span data-ship-title></span></b><span style="flex:1"></span><button type="button" class="co-dlg-x" data-ship-close aria-label="Close">×</button></div>
    <form method="post" class="co-f co-dlg-body" enctype="multipart/form-data" novalidate><?= $hidden('ship_save') ?><input type="hidden" name="line" value="">
      <div class="co-radios" role="radiogroup" aria-label="Style"><?php foreach (ClientOrders::SHIP_STYLES as $k => $lab): ?><label><input type="radio" name="style" value="<?= $k ?>"> <?= $e($lab) ?></label><?php endforeach; ?></div>
      <label data-not-pickup>Carrier<select class="hb-in" name="carrier"><option value="">—</option><?php foreach (ClientOrders::CARRIERS as $k => $lab): ?><option value="<?= $k ?>"><?= $e($lab) ?></option><?php endforeach; ?></select></label>
      <label data-not-pickup>Ship to (empty: the order's Ship to)<textarea class="hb-in" name="address" rows="3" maxlength="400" placeholder="<?= $e(ClientOrders::shipToText($o) ?: "Name\nStreet\nTown, ST ZIP") ?>"></textarea></label>
      <div class="two" data-not-pickup><label>Shipping charge (to the client)<input class="hb-in" name="charge" inputmode="decimal" placeholder="0.00"<?= $editable ? '' : ' readonly title="Approved: the charge stays"' ?>></label><label>Our cost (the vendor's charge)<input class="hb-in" name="cost" inputmode="decimal" placeholder="0.00"<?= $editable ? '' : ' readonly' ?>></label></div>
      <label>Tracking<input class="hb-in" name="tracking" maxlength="160" placeholder="1Z… or a note"></label>
      <label>Add a shipping label (PDF or image)<input class="hb-in" type="file" name="label" accept=".pdf,image/*,application/pdf"></label>
      <div><button class="hb-b go">Save</button></div>
    </form>
   </div>
  </div>
  <?php endif; ?>
  <?php if ($editable): ?>
  <div class="co-dlg" id="co-add" hidden role="dialog" aria-modal="true" aria-label="Add an item">
   <div class="co-dlg-box">
    <div class="co-dlg-bar"><b>Add an item</b>
      <div class="co-tabs" role="tablist"><?php foreach (['catalog' => 'Catalog', 'newprod' => 'New product', 'go' => 'GO Code', 'custom' => 'Custom', 'ship' => 'Shipping'] as $k => $lab): ?><button type="button" role="tab" data-tab="<?= $k ?>" aria-selected="<?= $k === 'catalog' ? 'true' : 'false' ?>"><?= $e($lab) ?></button><?php endforeach; ?></div>
      <button type="button" class="co-dlg-x" data-add-close aria-label="Close">×</button></div>
    <div class="co-dlg-body">
    <section data-panel="catalog">
      <?php if (!$products): ?><p class="text-sm" style="margin-top:.3rem">The catalog is empty. <a class="hb-go" href="/admin/products.php#new">Add products</a> (business cards, for example).</p><?php else: ?>
      <form method="post" class="co-f" id="co-prod" novalidate><?= $hidden('add_product') ?>
        <div class="three"><label>Product<select class="hb-in" name="product" required><?php foreach ($products as $p): ?><option value="<?= (int) $p['id'] ?>"><?= $e($p['name']) ?></option><?php endforeach; ?></select></label>
          <label>Run size<input class="hb-in" name="qty" type="number" min="1" list="co-qty"></label>
          <label>Price for the line (empty: the catalog's)<input class="hb-in" name="price" inputmode="decimal" placeholder="—"></label></div>
        <datalist id="co-qty"></datalist>
        <div id="co-opts" class="two"></div>
        <small id="co-hint"></small>
        <label>Note on the line (shown to the client)<input class="hb-in" name="note" maxlength="300" placeholder="Front: logo; back: QR to the listing"></label>
        <div><button class="hb-b go">Add it</button> <a class="hb-go" href="/admin/products.php">The catalog</a></div>
      </form>
      <?php endif; ?>
    </section>
    <section data-panel="go" hidden>
      <form method="post" class="co-f" id="co-go" novalidate><?= $hidden('add_go') ?>
        <label>What should it do?</label>
        <input type="hidden" name="type" value="vcard">
        <div class="co-types" role="group" aria-label="What the code does"><?php foreach (QrIssue::FIELDS as $t => $f): ?><button type="button" data-t="<?= $e($t) ?>" aria-pressed="<?= $t === 'vcard' ? 'true' : 'false' ?>"><?= $e(Qr::TYPES[$t] ?? $t) ?></button><?php endforeach; ?></div>
        <?php $ph = ['url' => 'https://', 'phone' => '480-555-0123', 'email' => 'name@example.com', 'name' => 'First Last', 'org' => 'Business name', 'date' => '2026-11-01', 'time' => '18:00', 'security' => 'WPA']; ?>
        <?php foreach (QrIssue::FIELDS as $t => $fs): ?><div class="two" data-type="<?= $e($t) ?>"<?= $t === 'vcard' ? '' : ' hidden' ?>><?php foreach ($fs as $k => $lab): ?><label><?= $e($lab) ?><?php if (in_array($k, ['text', 'body', 'details', 'note', 'message'], true)): ?><textarea class="hb-in" name="f[<?= $e($t) ?>][<?= $e($k) ?>]" rows="2"></textarea><?php else: ?><input class="hb-in" name="f[<?= $e($t) ?>][<?= $e($k) ?>]" placeholder="<?= $e($ph[$k] ?? '') ?>"><?php endif; ?></label><?php endforeach; ?></div><?php endforeach; ?>
        <div class="two"><label>Name on the code (for you and the client)<input class="hb-in" name="title" maxlength="120" placeholder="Paul Stewart business card"></label>
          <label>Price<input class="hb-in" name="price" inputmode="decimal" value="<?= number_format(QrIssue::PRICE_CENTS / 100, 2) ?>"></label></div>
        <small>Its trvgo.us address and QR are made now, so you can put it on proofs; it starts working once the order is paid, and the client downloads it from their order page.</small>
        <div><button class="hb-b go">Add it</button></div>
      </form>
    </section>
    <section data-panel="ship" hidden>
      <form method="post" class="co-f" novalidate><?= $hidden('add_ship') ?>
        <div class="three"><label>Method<input class="hb-in" name="method" maxlength="80" value="Ground" placeholder="Ground, 2–5 days"></label>
          <label>Vendor's charge<input class="hb-in" name="cost" inputmode="decimal" placeholder="13.25"></label>
          <label>Charge the client<input class="hb-in" name="price" inputmode="decimal" placeholder="13.25"></label></div>
        <label>Note (shown to the client)<input class="hb-in" name="note" maxlength="300" placeholder="UPS Ground, 3 to 5 business days"></label>
        <label style="display:flex;gap:.4rem;align-items:center"><input type="checkbox" name="taxable" value="1"> Sales tax applies to shipping</label>
        <div><button class="hb-b go">Add shipping</button></div>
      </form>
    </section>
    <section data-panel="newprod" hidden>
      <form method="post" class="co-f" novalidate><?= $hidden('new_product') ?>
        <p class="text-sm" style="margin:0">Makes a catalog product and adds it to this order. Change its details later under Products.</p>
        <div class="three"><label>Product name<input class="hb-in" name="name" maxlength="120" placeholder="Magnetic business cards"></label>
          <label>Kind<select class="hb-in" name="kind"><?php foreach (Products::KINDS as $k => $lab): ?><option value="<?= $k ?>"><?= $e($lab) ?></option><?php endforeach; ?></select></label>
          <label>Vendor<input class="hb-in" name="vendor" maxlength="120" placeholder="4OVER"></label></div>
        <div class="three"><label>Run size (how many)<input class="hb-in" name="qty[]" inputmode="numeric" placeholder="250"></label>
          <label>Vendor cost for the run<input class="hb-in" name="cost[]" inputmode="decimal" placeholder="18.04"></label>
          <label>Markup %<input class="hb-in" name="markup" inputmode="numeric" placeholder="100"></label></div>
        <div class="two"><label>Your price for the run (empty: cost + markup)<input class="hb-in" name="price[]" inputmode="decimal"></label>
          <label>Note on the line (shown to the client)<input class="hb-in" name="note" maxlength="300"></label></div>
        <label>Options, one per line (optional)<textarea class="hb-in" name="options" rows="2" placeholder="Stock: 17pt magnetic&#10;Coating: UV, None"></textarea></label>
        <label>Description (optional)<input class="hb-in" name="description" maxlength="600" placeholder="Full color, full bleed, front only"></label>
        <label style="display:flex;gap:.4rem;align-items:center"><input type="checkbox" name="taxable" value="1" checked> Sales tax applies</label>
        <div><button class="hb-b go">Create and add it</button></div>
      </form>
    </section>
    <section data-panel="custom" hidden>
      <form method="post" class="co-f" novalidate><?= $hidden('add_custom') ?>
        <div class="three"><label>What it is<input class="hb-in" name="title" maxlength="160" placeholder="Card design (2 rounds of changes)"></label>
          <label>How many<input class="hb-in" name="qty" type="number" min="1" value="1"></label>
          <label>Price each<input class="hb-in" name="price" inputmode="decimal" placeholder="45.00"></label></div>
        <div class="two"><label>Your cost each (optional, for margins)<input class="hb-in" name="cost" inputmode="decimal"></label>
          <label>Kind<select class="hb-in" name="type"><option value="creative">Creative (concepts, artwork: viewed, not downloaded)</option><option value="print">Print (its approved print-ready file is released)</option><option value="additional" selected>Additional service</option></select></label></div>
        <label>Note (shown to the client)<input class="hb-in" name="note" maxlength="300"></label>
        <label style="display:flex;gap:.4rem;align-items:center"><input type="checkbox" name="taxable" value="1" checked> Sales tax applies</label>
        <div><button class="hb-b go">Add it</button></div>
      </form>
    </section>
    </div>
   </div>
  </div>

  <h2 class="hb-h">Send it</h2>
  <div class="hb-card tv-bleed">
    <form method="post" class="co-f" novalidate><?= $hidden('send') ?>
      <label style="max-width:16rem">The link works for (days)<input class="hb-in" name="days" type="number" min="1" max="90" value="<?= ClientOrders::DAYS ?>"></label>
      <div><button class="hb-b go" id="co-send-btn" data-confirm="Email <?= $e($o['bill_email']) ?> the order to review?" data-yes="Send it"><?= $o['status'] === 'sent' ? 'Send again' : 'Send to the client' ?></button></div>
    </form>
    <?php if ($o['status'] === 'sent'): ?><p class="text-sm" style="margin-top:.5rem">Their link (to text it, or send it yourself):</p><div class="co-link"><code id="co-url"><?= $e(ClientOrders::url($o)) ?></code></div>
      <button type="button" class="hb-b" style="margin-top:.35rem" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('co-url').textContent).then(function(){TvAsk.say('Copied')})">Copy the link</button><?php endif; ?>
    <form method="post" style="margin-top:.6rem"><?= $hidden('cancel') ?><input type="hidden" name="why" value=""><button class="hb-b no" id="co-cancel-btn" data-confirm="Cancel this order?<?= $o['status'] !== 'draft' ? ' The client is told.' : '' ?>" data-yes="Cancel it" data-danger>Cancel the order</button></form>
  </div>
  <?php endif; ?>

  <?php $outside = $o['pay_mode'] === 'outside'; $mo = Orders::money($pdo, $oid); $left = max(0, (int) $o['total_cents'] - $mo['paid']); ?>
<?php
  // a work order's fields (decisions/0101, addendum 2026-10-28): who makes it, their email, which items and files, where it ships, when, notes
  $woReady = WorkOrders::ready($pdo); $woLines = WorkOrders::printLines($lines); $stReady = WorkOrders::statusReady($pdo);
  $woFields = function (?array $d = null, bool $template = false) use ($pdo, $oid, $o, $lines, $woLines, $e, $stReady, $addrs): string {   // $d: a saved draft, to edit
      $ch = WorkOrders::choices($pdo, $oid, $lines); $vs = Vendors::all($pdo, true);
      $pre = 0; foreach ($woLines as $l) { $lv = Vendors::forLine($pdo, $l); if ($lv) { $pre = (int) $lv['id']; break; } }   // the items' vendor, from their Vendor tab (or the product's)
      if ($d && !empty($d['vendor_id'])) $pre = (int) $d['vendor_id'];
      $dl = $d ? array_map('intval', array_filter(explode(',', (string) $d['line_ids']))) : null; $df = $d ? (json_decode((string) $d['files'], true) ?: []) : null; $dp = $d ? WorkOrders::parts($d) : [];
      $tick = fn (array $f) => ($df !== null ? in_array($f[0], $df, true) : $f[3]) ? ' checked' : '';
      $from = $e(getenv('ORDERS_FROM_EMAIL') ?: 'orders@trvgo.us');
      $h = ($d && !$template ? '<input type="hidden" name="wo" value="' . (int) $d['id'] . '">' : '') . (Vendors::ready($pdo)
         ? '<div class="two"><label>Vendor (who makes it)<select class="hb-in" name="vendor_id" data-wo-vendor><option value="">Choose…</option>'
           . implode('', array_map(fn ($v) => '<option value="' . (int) $v['id'] . '" data-email="' . $e($v['email']) . '" data-pref="' . $e((string) ($v['file_pref'] ?? '')) . '"' . ((int) $v['id'] === $pre ? ' selected' : '') . '>' . $e($v['name']) . '</option>', $vs))
           . '<option value="new">+ A new vendor…</option></select><input class="hb-in" name="vendor" maxlength="80" placeholder="The new vendor\'s name" data-wo-new hidden style="margin-top:.3rem"></label>'
           . '<label>Their orders email (it goes from ' . $from . ')<input class="hb-in" name="email" type="email" maxlength="160" data-wo-email value="' . $e($d ? (string) $d['vendor_email'] : (string) (array_column($vs, 'email', 'id')[$pre] ?? '')) . '" placeholder="orders@vendor.com"></label></div>'
           . '<small><a href="/admin/backoffice/vendor_list" data-peek-frame data-title="Vendors">Set up vendors</a>: their emails, contacts and account numbers. A new one typed here joins the list.</small>'
         : '<div class="two"><label>Vendor (who makes it)<input class="hb-in" name="vendor" maxlength="80" placeholder="4OVER" value="' . $e($d['vendor'] ?? '') . '"></label><label>Their email (it goes from ' . $from . ')<input class="hb-in" name="email" type="email" maxlength="160" placeholder="orders@vendor.com" value="' . $e($d['vendor_email'] ?? '') . '"></label></div>');
      // where it goes: the order's address (or one of its ship-to addresses), and its shipping labels and manifests, sent with the work order
      $shipBox = function (string $label) use ($e, $o, $ch, $addrs, $d, $df): string {
          $b = '<div class="co-wo-ship"><label>' . $e($label) . '<textarea class="hb-in" name="ship_to" rows="4" maxlength="400" data-wo-shipto>' . $e($d ? (string) $d['ship_to'] : (WorkOrders::shipText($o) ?: (count($addrs) === 1 ? ClientOrders::addressText(reset($addrs)) : ''))) . '</textarea></label>';
          if (count($addrs) > 1) $b .= '<label>Use an address<select class="hb-in" data-wo-shipuse><option value="">Choose…</option>' . implode('', array_map(fn ($a) => '<option value="' . $e(ClientOrders::addressText($a)) . '">' . $e(($a['label'] ?: $a['city']) . ' · ' . $a['street']) . '</option>', $addrs))
              . '<option value="' . $e('Several addresses: see the shipping labels and manifest attached.') . '">All of them (per the labels / manifest)</option></select></label>';
          $docs = $ch[-1] ?? [];
          $b .= '<div class="co-wo-docs"><b>Shipping labels and manifests</b>';
          foreach ($docs as $f) $b .= '<label class="co-chk co-wo-f"><input type="checkbox" name="files[]" value="' . $e($f[0]) . '" data-kind="' . $e($f[4] ?? '') . '"' . ($df === null || in_array($f[0], $df, true) ? ' checked' : '') . '> ' . $e($f[1]) . ' <small>' . $e($f[2]) . '</small></label>';
          if (!$docs) $b .= '<small>None on this order. Add a label or a manifest under the order\'s Documents (or an item\'s Files), and it\'s sent with the work order.</small>';
          return $b . '</div></div>';
      };
      $h .= '<fieldset class="co-wo-pick"><legend>Items and files for the vendor</legend>'; $costs = Costing::forOrder($pdo, $oid);
      $anyPrint = (bool) array_filter($woLines, fn ($l) => ClientOrders::role($pdo, $l) === 'print');
      foreach ($woLines as $l) {
          $lid = (int) $l['id']; $isPrint = ClientOrders::role($pdo, $l) === 'print';   // printed items ticked; creative work and services can be added
          $cr = $costs[$lid] ?? null; $cok = Costing::isChecked($cr);
          if ($isPrint && ($dl !== null ? in_array($lid, $dl, true) : ($isPrint || !$anyPrint))) $autoCents = ($autoCents ?? 0) + (int) ($cr['vendor_cents'] ?? 0);   // the cost to start from: the ticked items' vendor share   // its COGS: checked before the work order goes (Jason, 2026-10-29)
          $h .= '<label class="co-chk"><input type="checkbox" name="lines[]" value="' . $lid . '"' . (Costing::ready($pdo) && $isPrint ? ' data-cogs="' . ($cok ? 'ok' : 'no') . '" data-cogs-name="' . $e(preg_replace('/ · [\d,]+.*$/', '', (string) $l['title'])) . '" data-vendor-cents="' . (int) ($cr['vendor_cents'] ?? 0) . '"' : '') . (($dl !== null ? in_array($lid, $dl, true) : ($isPrint || !$anyPrint)) ? ' checked' : '') . '> <b>' . $e($l['title']) . '</b>' . ($isPrint ? '' : ' <small>(' . $e(ClientOrders::role($pdo, $l) === 'creative' ? 'creative work' : 'a service') . ')</small>') . '</label>';
          if ($l['options'] !== '') $h .= '<small class="co-wo-opt">' . $e($l['options']) . '</small>';
          if (Costing::ready($pdo) && ($isPrint || $cr)) $h .= '<small class="co-wo-opt">' . ($cr ? 'COGS ' . Orders::usd((int) $cr['cogs_cents']) . ', the vendor\'s share ' . Orders::usd((int) $cr['vendor_cents']) . ' · ' . ($cok ? '✓ checked' : '<b style="color:#991B1B">not checked</b>') : '<b style="color:#991B1B">No COGS yet</b>') . ' · <button type="button" class="co-lk" data-item-open="' . $lid . '" data-tab="cost">' . ($cok ? 'See' : 'Check') . ' its cost</button></small>';
          if ($stReady) {   // our code (the product's) and the vendor's part number, remembered per product and vendor
              [$code] = WorkOrders::partFor($pdo, $l, 0); $pns = [];
              if (($l['product'] ?? '') === 'product' && !empty($l['product_id'])) { $q = $pdo->prepare('SELECT vendor_id, vendor_pn FROM product_vendor_parts WHERE product_id = ?'); $q->execute([(int) $l['product_id']]); $pns = $q->fetchAll(PDO::FETCH_KEY_PAIR); }
              $h .= '<label class="co-wo-opt co-wo-pn">' . ($code !== '' ? 'Our product ' . $e($code) . ' · ' : '') . 'their part #<input class="hb-in" name="pn[' . $lid . ']" maxlength="80" value="' . $e((string) ($dp[$lid][1] ?? ($pns[$pre] ?? ''))) . '" data-pns="' . $e(json_encode((object) $pns)) . '" placeholder="if they have one"></label>';
          }
          if ($stReady && $isPrint) {   // the specs the vendor reads: the item's options to start, checked against what it was costed with
              $spv = WorkOrders::specs($l, $dp[$lid] ?? ($d ? [] : WorkOrders::lastSpecs($pdo, $oid, $lid))); [$cw, $gap] = WorkOrders::specGaps($pdo, $l, $spv);   // a new one: the specs last written for it
              $h .= '<label class="co-wo-opt co-wo-spec">Specs for the vendor<textarea class="hb-in" name="spec[' . $lid . ']" rows="3" maxlength="1000">' . $e($spv) . '</textarea></label>'
                 . ($cw ? '<small class="co-wo-opt">Costed with: ' . $e(implode(' · ', $cw)) . '</small>' : '')
                 . ($gap ? '<p class="co-wo-opt" data-tv-status="bad" data-tv-label="The specs don\'t match the costing:">' . $e(implode(', ', $gap)) . ' isn\'t in these specs. Fix them before it goes (the costing is what you priced).</p>' : '');
          }
          foreach ($ch[$lid] ?? [] as $f) $h .= '<label class="co-chk co-wo-f"><input type="checkbox" name="files[]" value="' . $e($f[0]) . '" data-kind="' . $e($f[4] ?? '') . '"' . $tick($f) . '> ' . $e($f[1]) . ' <small>' . $e($f[2]) . '</small></label>';
          if (empty($ch[$lid])) $h .= '<small class="co-wo-f">No files on this item yet: add a print-ready file or proof first, or send them yourself.</small>';
      }
      foreach ($ch[0] ?? [] as $f) $h .= '<label class="co-chk co-wo-f"><input type="checkbox" name="files[]" value="' . $e($f[0]) . '" data-kind="' . $e($f[4] ?? '') . '"' . $tick($f) . '> ' . $e($f[1]) . ' <small>' . $e($f[2]) . ', the whole order</small></label>';
      $h .= '</fieldset>';
      if ($stReady) {
          $proj = ''; try { $pj = array_filter(array_map(fn ($l) => (int) ($l['project_id'] ?? 0), $woLines)); if ($pj) $proj = (string) $pdo->query('SELECT title FROM order_projects WHERE id = ' . (int) reset($pj))->fetchColumn(); } catch (Throwable $x) {}
          if ($proj === '' && $woLines) $proj = preg_replace('/ · [\d,]+$/', '', (string) $woLines[0]['title']);
          $h .= '<div class="two"><label>Project name<input class="hb-in" name="project" maxlength="160" value="' . $e($d ? (string) $d['project'] : $proj) . '"></label><label>Total cost (our cost of goods; they accept or decline at it)<input class="hb-in" name="cost" inputmode="decimal" placeholder="0.00"' . ($d && $d['cost_cents'] !== null ? ' value="' . number_format((int) $d['cost_cents'] / 100, 2, '.', '') . '"' : ' value="' . (!empty($autoCents) ? number_format($autoCents / 100, 2, '.', '') : '') . '" data-wo-auto') . '>' . (Costing::ready($pdo) ? '<button type="button" class="co-lk" data-wo-cogs hidden style="justify-self:start">Reset to COGS</button>' : '') . '</label></div>'
             . '<div class="three"><label>Must have date<input class="hb-in" name="due_on" type="date" value="' . $e($d['due_on'] ?? '') . '"></label><label>Must have by<input class="hb-in" name="due_time" type="time" value="' . $e(substr((string) ($d['due_time'] ?? ''), 0, 5)) . '"></label><label>Delivery method<select class="hb-in" name="delivery"><option value="">Choose…</option>'
             . implode('', array_map(fn ($k, $v) => '<option value="' . $k . '"' . ($k === ($d['delivery'] ?? '') ? ' selected' : '') . '>' . $e($v) . '</option>', array_keys(WorkOrders::DELIVERY), WorkOrders::DELIVERY)) . '</select></label></div>'
             . '<div class="two">' . $shipBox('Ship to (the vendor delivers here)')
             . '<div style="display:grid;gap:.45rem;align-content:start"><label>Purchase order no. (optional)<input class="hb-in" name="po_no" maxlength="60" value="' . $e($d['po_no'] ?? '') . '"></label></div></div>'
             . '<label>Production notes (optional)<textarea class="hb-in" name="note" rows="5" maxlength="1000" placeholder="1 pack of 50 in shrink wrap. Blind ship: no vendor name on the box.">' . $e($d['note'] ?? '') . '</textarea></label>';
      } else
      $h .= '<div class="two">' . $shipBox('Ship to (the vendor ships here)')
         . '<div style="display:grid;gap:.45rem;align-content:start"><label>Needed by (optional)<input class="hb-in" name="due_on" type="date" value="' . $e($d['due_on'] ?? '') . '"></label>'
         . '<label>Notes for the vendor (optional)<textarea class="hb-in" name="note" rows="2" maxlength="1000" placeholder="Blind ship: no vendor name on the box.">' . $e($d['note'] ?? '') . '</textarea></label></div></div>';
      $h .= ''
         . '<label class="co-chk"><input type="checkbox" name="ordered" value="1" checked> Mark the order "Work order issued" when it\'s sent' . (ClientOrders::wantsProgress($o) ? ' (the client gets a progress email)' : '') . '</label>';
      return $h;
  };
  // one save button, four ways (like QuickBooks); the main one is the last way used. $first: what it asks before any of them (processing outside)
  $woBtns = function (bool $outside = false) use ($e): string {
      // each way says what it does; on "Handled outside" the question also says how the order is processed (its QuickBooks invoice #, when given)
      $from = $e(getenv('ORDERS_FROM_EMAIL') ?: 'orders@trvgo.us');
      $ways = [['stay', 'Save draft, keep editing', 'The work order is saved, not sent, and stays open.', 'Yes'], ['new', 'Save and start another', 'The work order is saved, not sent.', 'Yes'],
               ['close', 'Save work order', 'The work order is saved, not sent.', 'Yes'], ['send', 'Save and send to vendor', ($outside ? 'Its work order is emailed to the vendor from ' : 'Email this work order and its files to the vendor from ') . html_entity_decode($from) . ($outside ? '.' : '?'), $outside ? 'Process and send' : 'Send it']];
      $btn = fn (array $w, string $attrs) => '<button ' . $attrs . ' name="save" value="' . $w[0] . '"' . ($outside || $w[0] === 'send' ? ' data-then="' . $e($w[2]) . '" data-confirm="' . $e($w[2]) . '" data-yes="' . $e($w[3]) . '"' : '') . '>' . $e($w[1]) . '</button>';
      return '<div class="co-split" data-split' . ($outside ? ' data-outside' : '') . '>' . $btn($ways[2], 'class="hb-b go" data-split-main')
          . '<button type="button" class="hb-b go co-split-t" aria-haspopup="true" aria-expanded="false" aria-label="More ways to save" title="More ways to save">▾</button>'
          . '<div class="co-split-l" hidden>' . implode('', array_map(fn ($w) => $btn($w, 'type="button"'), $ways)) . '</div></div>';
  }; ?>
  <?php
  // an admin's release before payment (decisions/0101 note 2026-11-23, model 1.9: "Admins only, with a reason recorded");
  // others see it greyed with the reason. Shown where the hold is reported: the payment hold and the work orders.
  [$canRel, $whyRel] = ClientOrders::canRelease();
  $relNeeded = $o['status'] === 'pending' && !ClientOrders::overridden($pdo, $oid) && (ClientOrders::vendorHold($pdo, $o) !== '' || ClientOrders::shipHold($pdo, $o) !== '');
  $releaseBox = function (string $id) use ($hidden, $e, $canRel, $whyRel): string {
      if (!$canRel) return '<p class="co-note" style="margin:.5rem 0 0;display:flex;flex-wrap:wrap;gap:.4rem;align-items:center"><button type="button" class="hb-b" disabled title="' . $e($whyRel) . '" aria-disabled="true" style="opacity:.5;cursor:not-allowed">Release before payment</button> <small>' . $e($whyRel) . ': only an admin releases an order before payment.</small></p>';
      return '<form method="post" class="co-f co-rel" style="margin-top:.5rem" novalidate>' . $hidden('release_hold')
          . '<label for="' . $e($id) . '">Release before payment (admins): why it goes ahead without the money, kept on the order<input class="hb-in" id="' . $e($id) . '" name="why" maxlength="300" required minlength="3" data-spell placeholder="A client on agreed terms; paying on delivery"></label>'
          . '<div><button class="hb-b" data-confirm="Release it before payment? It can go to the vendor and be released for delivery before the money is in." data-yes="Release it">Release before payment</button></div></form>';
  }; ?>
  <?php if (in_array($o['status'], ['draft', 'sent'], true) && $lines): ?>
  <details class="hb-card tv-bleed co-more" id="bypass"<?= $outside ? ' open' : '' ?>><summary style="font:700 1.05rem var(--tv-font-head,Georgia,serif)">Approve for the client (skip their checkout)</summary>
    <p class="text-sm"><?= $outside
      ? 'Paid outside QuickBooks: no invoice and no card form. Sales tax isn\'t added for you; if it\'s owed, add it as a line (no tax on it).'
      : 'Makes the QuickBooks invoice now (with sales tax, from Bill to above), as if they had approved it on their page.' ?> Use it when the client said yes in person, on the phone or by email; their proofs count as approved. How they pay stays theirs to choose on their page; it goes to the vendor once it's paid (a deposit order: its deposit), unless an admin releases it before payment.</p>
    <form method="post" class="co-f" novalidate><?= $hidden('staff_approve') ?>
      <div class="two"><label>Who approved it (the client's name)<input class="hb-in" name="name" value="<?= $e($o['bill_name']) ?>" maxlength="120"></label>
      <?php if (ClientOrders::delivery($o, $lines) === 'ship'): ?><label style="display:flex;gap:.4rem;align-items:center;align-self:end"><input type="checkbox" name="ship_same" value="1" style="width:auto"> Ship to the billing address</label><?php endif; ?></div>
      <?php if (ClientOrders::delivery($o, $lines) === 'ship'): ?><div class="three"><label>Ship to: street<input class="hb-in" name="ship_street" value="<?= $e($o['ship_street'] ?? '') ?>" maxlength="160"></label><label>Town<input class="hb-in" name="ship_city" value="<?= $e($o['ship_city'] ?? '') ?>" maxlength="80"></label><label>State and ZIP<span style="display:flex;gap:.3rem"><input class="hb-in" name="ship_state" value="<?= $e($o['ship_state'] ?? '') ?>" maxlength="2" placeholder="AZ" style="width:4.5rem"><input class="hb-in" name="ship_zip" value="<?= $e($o['ship_zip'] ?? '') ?>" maxlength="10" placeholder="ZIP"></span></label></div><?php endif; ?>
      <?php if ($canRel): ?><label class="co-chk"><input type="checkbox" name="release" value="1" data-rel-tick> Release before payment (admins): it can go to the vendor and be released for delivery without waiting for the money</label>
      <label data-rel-why hidden>Why it goes ahead before payment (kept on the order)<input class="hb-in" name="release_why" maxlength="300" data-spell placeholder="A client on agreed terms; paying on delivery"></label>
      <?php else: ?><label class="co-chk" title="<?= $e($whyRel) ?>"><input type="checkbox" disabled aria-disabled="true"> Release before payment <small>(<?= $e($whyRel) ?>: only an admin releases an order before payment)</small></label><?php endif; ?>
      <div><button class="hb-b go" data-confirm="Approve it for <?= $e($o['bill_name']) ?>? Its proofs count as approved<?= $outside ? '' : ', and the QuickBooks invoice is made' ?>." data-yes="Approve it">Approve for the client</button></div>
    </form>
  </details>
  <script>/* the release's reason, asked once it's ticked */ document.querySelectorAll('[data-rel-tick]').forEach(function (t) { var w = t.form.querySelector('[data-rel-why]'); if (!w) return; var i = w.querySelector('input'); t.addEventListener('change', function () { w.hidden = !t.checked; i.required = t.checked; if (t.checked) i.focus(); }); });</script>
  <?php if ($woReady && $woLines): ?>
  <details class="hb-card tv-bleed co-more" id="outside"><summary style="font:700 1.05rem var(--tv-font-head,Georgia,serif)">Handled outside: create the work order</summary>
    <p class="text-sm">For an order invoiced and paid outside Traversence (a QuickBooks invoice you made by hand, cash, a check). One step: it's approved for the client with <b>no invoice made here</b> and nothing posted to QuickBooks, put into production, and its work order goes to the vendor from orders@trvgo.us with the files to download. The client isn't emailed (unless they asked for progress emails).</p>
    <form method="post" class="co-f" novalidate><?= $hidden('outside_wo') ?>
      <div class="two"><label>Who approved it (the client's name)<input class="hb-in" name="name" value="<?= $e($o['bill_name']) ?>" maxlength="120"></label>
        <label>QuickBooks invoice # you made (optional, for reference)<input class="hb-in" name="invoice_ref" maxlength="40" placeholder="1044"></label></div>
      <?php   // reopened and approved again: the work order made before comes back (a draft is saved again; one cancelled or declined fills a new one)
        $woPrev = null; try { $wp = $pdo->prepare("SELECT * FROM order_work_orders WHERE order_id = ? ORDER BY status = 'draft' DESC, id DESC LIMIT 1"); $wp->execute([$oid]); $woPrev = $wp->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable $x) {}
        if ($woPrev && !in_array($woPrev['status'] ?? 'draft', ['draft', 'cancelled', 'declined', 'rejected'], true)) $woPrev = null; ?>
      <?php if ($woPrev): ?><p class="co-note" style="margin:.2rem 0"><?= ($woPrev['status'] ?? 'draft') === 'draft' ? 'Work order ' . $e($woPrev['wo_no']) . ' (not sent yet) is filled in below: saving changes it.' : 'Filled in from work order ' . $e($woPrev['wo_no']) . ' (' . $e(WorkOrders::STATUS[$woPrev['status']] ?? $woPrev['status']) . '): saving makes a new one.' ?></p><?php endif; ?>
      <?= $woFields($woPrev, $woPrev && ($woPrev['status'] ?? 'draft') !== 'draft') ?>
      <?= $woBtns(true) ?>
      <small style="text-align:right">Every way processes the order. Not ready to send? Save it: it waits under Work orders, where you edit and send it.</small>
    </form>
  </details>
  <?php endif; ?>
  <?php endif; ?>
  <?php if ($o['status'] !== 'void' && ($o['invoice_no'] ?? '') . ($_GET['qbmerge'] ?? '') !== ''): require_once __DIR__ . '/../../app/ui/qb-merge.php'; echo tv_qb_merge_box($pdo, $o, $hidden('qb_merge')); endif; ?>
  <?php if ($o['status'] === 'pending' && $left > 0): $pm = (string) ($o['pay_method'] ?? ''); $held = $o['stage'] === ''; ?>
  <h2 class="hb-h" id="payhold"><?= $held ? 'Payment hold' : 'Waiting for payment' ?></h2>
  <div class="hb-card tv-bleed">
    <div class="co-hold" style="background:#FFFBF2;border-color:#EADFC4"><b>The client's checkout:</b> <?= $pm !== '' ? 'paying by <b>' . $e(strtolower(ClientOrders::CLIENT_METHODS[$pm] ?? $pm)) . '</b>' . (($o['pay_report'] ?? '') !== '' ? ', they say it\'s sent (reference <b>' . $e($o['pay_report']) . '</b>' . (!empty($o['pay_reported_at']) ? ', ' . $e(date('M j, g:i a', strtotime((string) $o['pay_reported_at']))) : '') . ')' : ($pm === 'cash' ? '' : ', not sent yet')) : ($outside ? 'they haven\'t chosen how to pay yet' : 'a card on their page, unless they choose another way there') ?>.
      <?php if (isset(ClientOrders::PAY_METHODS[$pm]) && ($pm === 'cash' || ($o['pay_report'] ?? '') !== '')): $dn = ClientOrders::dueNow($pdo, $o); ?>
      <form method="post" class="co-confirm"><?= $hidden('record_pay') ?><input type="hidden" name="receipt" value="1"><input type="hidden" name="amount" value="<?= number_format($dn / 100, 2, '.', '') ?>"><input type="hidden" name="method" value="<?= $e($pm) ?>"><input type="hidden" name="ref" value="<?= $e(mb_substr((string) ($o['pay_report'] ?? ''), 0, 60)) ?>">
        <button class="hb-b go" data-confirm="Confirm <?= $usd($dn) ?> received by <?= $e(strtolower(ClientOrders::PAY_METHODS[$pm])) ?><?= ($o['pay_report'] ?? '') !== '' ? ' (' . $e($o['pay_report']) . ')' : '' ?>? It's recorded, the order goes to production and the client gets a receipt." data-yes="Confirm it">✓ Confirm <?= $usd($dn) ?> received</button></form>
      <?php endif; ?></div>
    <?php if ($held): ?><div class="co-hold"><b>On a payment hold:</b> it goes to production and the vendor when <?= $o['pay_mode'] === 'deposit' && (int) $o['deposit_cents'] > 0 ? 'its deposit' : 'the payment' ?> is in: a card on their page records itself; anything else, record below when it reaches you.</div><?php endif; ?>
    <?php if (!$held && $relNeeded): ?><div class="co-hold"><b>Waiting for payment:</b> <?= $e(ClientOrders::vendorHold($pdo, $o) ?: ClientOrders::shipHold($pdo, $o)) ?></div><?php endif; ?>
    <p class="text-sm"><b>When the money arrives:</b> <?= $usd($left) ?> left to pay<?= $mo['paid'] ? ' (' . $usd($mo['paid']) . ' paid)' : '' ?>. For money received outside the card form: a wire, a check, cash and the like.<?= !empty($o['invoice_id']) ? ' Recording it also receives it on QuickBooks invoice ' . $e($o['invoice_no']) . ', so the invoice shows paid.' : ($o['invoice_no'] ? ' QuickBooks invoice ' . $e($o['invoice_no']) . ' was made by hand, so nothing is posted to it: receive the payment there too. This order\'s total comes from its own lines, so they should match the invoice.' : '') ?></p>
    <form method="post" class="co-f" novalidate><?= $hidden('record_pay') ?>
      <div class="three"><label>Amount<input class="hb-in" name="amount" inputmode="decimal" value="<?= number_format($left / 100, 2, '.', '') ?>"></label>
        <label>How it came in<select class="hb-in" name="method"><option value=""<?= $pm === '' ? ' selected' : '' ?>>Choose…</option><?php foreach (ClientOrders::PAY_METHODS as $k => $lab): ?><option value="<?= $k ?>"<?= $pm === $k ? ' selected' : '' ?>><?= $e($lab) ?></option><?php endforeach; ?></select></label>
        <label>Reference (wire confirmation, check number)<input class="hb-in" name="ref" maxlength="60" value="<?= $e(mb_substr((string) ($o['pay_report'] ?? ''), 0, 60)) ?>"></label></div>
      <label class="co-chk"><input type="checkbox" name="receipt" value="1"<?= $outside ? '' : ' checked' ?> data-receipt> Email the client a receipt</label>
      <?php $relAt = ClientOrders::releaseAt($o); $startsWith = $held ? ' Production and the vendor start once ' . ($o['pay_mode'] === 'deposit' && (int) $o['deposit_cents'] > 0 ? 'the deposit (' . $usd($relAt) . ')' : 'all ' . $usd($relAt)) . ' is in.' : ''; ?>
      <div style="display:flex;flex-wrap:wrap;gap:.4rem"><button class="hb-b go" data-confirm="Record this payment?<?= $e($startsWith) ?>" data-confirm-receipt="Record this payment and email the client a receipt?<?= $e($startsWith) ?>" data-yes="Record it">Record the payment</button></div>
    </form>
    <?php if ($relNeeded): ?><?= $releaseBox('rel-why-pay') ?><?php endif; ?>
    <?php if (ClientOrders::overridden($pdo, $oid)): ?><p data-tv-status="info" data-tv-label="Released before payment:">It can go to the vendor and be released for delivery; the payment is still to come. Its reason is in the history.</p><?php endif; ?>
  </div>
  <?php endif; ?>

  <?php
    // each file a work order can carry: where it previews (the proof lightbox for a PDF or image), when it was added, its size
    $woFiles = []; foreach (ClientOrders::files($pdo, $oid) as $fs) foreach ($fs as $ff) $woFiles['f' . (int) $ff['id']] = $ff;
    $woProofs = []; try { $stP = $pdo->prepare('SELECT id, mime, created_at FROM order_proofs WHERE order_id = ?'); $stP->execute([$oid]); foreach ($stP->fetchAll(PDO::FETCH_ASSOC) as $pp) $woProofs['p' . (int) $pp['id']] = $pp; } catch (Throwable $x) {}
    $woFileInfo = function (string $key) use ($woFiles, $woProofs, $oid): array {
        $r = $woFiles[$key] ?? $woProofs[$key] ?? null; $mime = (string) ($r['mime'] ?? '');
        $sz = isset($r['size']) && $r['size'] ? ($r['size'] >= 1048576 ? round($r['size'] / 1048576, 1) . ' MB' : max(1, (int) round($r['size'] / 1024)) . ' KB') : '';
        return ['url' => '/api/order-proof.php?o=' . $oid . '&' . ($key[0] === 'p' ? 'p' : 'f') . '=' . (int) substr($key, 1), 'kind' => $mime === 'application/pdf' ? 'pdf' : (str_starts_with($mime, 'image/') ? 'image' : ''),
                'when' => !empty($r['created_at']) ? date('M j, g:i a', strtotime((string) $r['created_at'])) : '', 'when_at' => (string) ($r['created_at'] ?? ''), 'size' => $sz];
    };
  ?>
  <?php if ($woReady && $woLines && in_array($o['status'], ['pending', 'paid', 'part_refunded'], true)): $wos = WorkOrders::forOrder($pdo, $oid); ?>
  <h2 class="hb-h" id="work">Work orders</h2>
  <div class="hb-card tv-bleed">
    <?php $payUp = $o['status'] === 'pending' && $left > 0; $payUpName = $o['stage'] === '' ? 'Payment hold' : 'Waiting for payment';   // the section's own heading   // Waiting for payment is above with the whole notice and the release: here, one line pointing to it (one fact, shown once; Design, 2026-11-23) ?>
    <?php if (($vh = ClientOrders::vendorHold($pdo, $o)) !== ''): ?><?php if ($payUp): ?><p data-tv-status="info" data-tv-keep data-tv-label="Held until it's paid:"><a class="underline" href="#payhold" style="color:#92400E;font-weight:600"><?= $payUpName ?> ↑</a></p><?php else: ?><p data-tv-status="info" data-tv-label="Waiting for payment:"><?= $e($vh) ?></p><?= $relNeeded ? $releaseBox('rel-why-wo') : '' ?><?php endif; ?>
    <?php elseif (($sh0 = ClientOrders::shipHold($pdo, $o)) !== '' && $o['status'] === 'pending' && array_filter($wos ?? [], fn ($w0) => in_array((string) ($w0['status'] ?? ''), ['shipped', 'ready', 'complete'], true))): ?><p data-tv-status="info" data-tv-label="Held for its balance:">The vendor has done their part; it's released for delivery once paid, and the client hasn't been told it shipped. <?php if ($payUp): ?><a class="underline" href="#payhold" style="color:#92400E;font-weight:600"><?= $payUpName ?> ↑</a><?php else: ?><?= $e($sh0) ?><?php endif; ?></p><?= !$payUp && $relNeeded ? $releaseBox('rel-why-wo') : '' ?><?php endif; ?>
    <?php if ($wos): ?><table class="co-wo-t"><tr><th>Work order</th><th>Vendor</th><th>Where it stands</th><th></th></tr>
    <?php foreach ($wos as $w): $nf = count(json_decode((string) $w['files'], true) ?: []); $ws = (string) ($w['status'] ?? ($w['sent_at'] ? 'sent' : 'draft')); $wdue = WorkOrders::dueAt($w); ?>
      <tr><td><a href="/wo.php?w=<?= $e($w['token']) ?>" data-peek-frame data-title="Work order <?= $e($w['wo_no']) ?>"><?= $e($w['wo_no']) ?></a><br><small><?= ($w['project'] ?? '') !== '' ? $e($w['project']) . ' · ' : '' ?><?= count(array_filter(explode(',', (string) $w['line_ids']))) ?> item<?= count(array_filter(explode(',', (string) $w['line_ids']))) === 1 ? '' : 's' ?> · <?= $nf ?> file<?= $nf === 1 ? '' : 's' ?>
          <?= $wdue ? '<br>Must have ' . $e(date('M j', $wdue)) . (!empty($w['due_time']) ? ', ' . $e(date('g:i a', $wdue)) : '') : '' ?><?= ($w['delivery'] ?? '') !== '' ? ' · ' . $e(WorkOrders::DELIVERY[$w['delivery']] ?? $w['delivery']) : '' ?><?= isset($w['cost_cents']) && $w['cost_cents'] !== null ? '<br>Cost ' . $usd($w['cost_cents']) . (($w['cost_state'] ?? '') === 'accepted' ? ' (agreed)' : '') : '' ?></small></td>
        <td><?= $e($w['vendor']) ?><br><small><?= $e($w['vendor_email'] ?: 'no email yet') ?></small></td>
        <td><span class="hb-pill<?= in_array($ws, ['declined', 'rejected', 'cancelled'], true) ? ' bad' : (in_array($ws, ['received', 'complete', 'shipped', 'ready'], true) ? ' ok' : '') ?>" style="margin:0"><?= $e(WorkOrders::STATUS[$ws] ?? $ws) ?></span>
          <br><small><?= ($w['job_no'] ?? '') !== '' ? 'Job ' . $e($w['job_no']) . ' · ' : '' ?><?= !empty($w['accepted_by']) ? 'received by ' . $e($w['accepted_by']) . ' · ' : '' ?><?= ($w['tracking'] ?? '') !== '' ? $e(trim(($w['carrier'] ?? '') . ' ' . $w['tracking'])) . ' · ' : '' ?><?= $w['sent_at'] ? 'sent ' . $e(date('M j, g:i a', strtotime((string) $w['sent_at']))) : 'not sent' ?><?= $w['opened_at'] ? ' · opened ' . $e(date('M j', strtotime((string) $w['opened_at']))) : ($w['sent_at'] ? ' · not opened yet' : '') ?>
          <?= ($w['vendor_note'] ?? '') !== '' ? '<br>' . $e($w['vendor']) . ': "' . $e($w['vendor_note']) . '"' : '' ?><?= ($w['received_by'] ?? '') !== '' ? '<br>' . ($ws === 'rejected' ? 'Rejected' : 'Received') . ' by ' . $e($w['received_by']) . (!empty($w['received_on']) ? ', ' . $e(date('M j', strtotime((string) $w['received_on']))) : '') . (($w['receive_note'] ?? '') !== '' ? ': ' . $e($w['receive_note']) : '') : '' ?></small>
          <?php $lg = WorkOrders::log($pdo, (int) $w['id']); if ($lg): ?><details class="co-wo-log"><summary>History (<?= count($lg) ?>)</summary><ul><?php foreach (array_reverse($lg) as $g): ?><li><?= $e($g['note'] ?: (WorkOrders::STATUS[$g['status']] ?? $g['status'])) ?> <small><?= $e(date('M j, g:i a', strtotime((string) $g['created_at']))) ?> · <?= (int) $g['by_vendor'] ? $e($w['vendor']) : 'us' ?></small></li><?php endforeach; ?></ul></details><?php endif; ?></td>
        <td class="co-wo-acts">
          <?php if ($ws === 'draft' && $stReady): ?><span class="co-wo-again"><a class="hb-b" href="<?= $e($self) ?>?wo_edit=<?= (int) $w['id'] ?>#wo-edit">Edit</a></span><?php endif; ?>
          <span class="co-wo-again"><a class="hb-b" href="/wo.php?w=<?= $e($w['token']) ?>" target="_blank" rel="noopener" title="The page the vendor gets, with its files; its buttons are off for you">See it as the vendor</a></span>
          <?php if (!in_array($ws, ['cancelled', 'declined', 'rejected', 'received'], true)): [$wUrl, $wMail] = WorkOrders::linkFor($w); ?><span class="co-wo-again">
            <?php if ($ws === 'draft'): ?><form method="post" style="display:contents"><?= $hidden('wo_link') ?><input type="hidden" name="wo" value="<?= (int) $w['id'] ?>"><button class="hb-b" name="how" value="copy" data-confirm="It isn't sent yet: giving its link marks it sent, so the vendor can accept it. Go ahead?" data-yes="Yes, get the link">Copy link</button><button class="hb-b" name="how" value="email" data-confirm="It isn't sent yet: giving its link marks it sent, so the vendor can accept it. Go ahead?" data-yes="Yes, email it">Email the link</button></form>
            <?php else: ?><button type="button" class="hb-b" data-copy-link="<?= $e($wUrl) ?>" title="The vendor's private link, to paste in your own email">Copy link</button><a class="hb-b" href="<?= $e($wMail) ?>" title="Opens your email to <?= $e($w['vendor_email'] ?: 'the vendor') ?> with the link">Email the link</a><?php endif; ?></span><?php endif; ?>
          <?php if (in_array($ws, ['draft', 'sent'], true)): ?><form method="post" class="co-wo-again"><?= $hidden('wo_send') ?><input type="hidden" name="wo" value="<?= (int) $w['id'] ?>"><?php if ($w['vendor_email'] === ''): ?><input class="hb-in" name="email" type="email" placeholder="Their email" aria-label="Vendor email" required><?php endif; ?><?php if ($stReady && $w['cost_cents'] === null): ?><input class="hb-in" name="cost" inputmode="decimal" placeholder="Total cost" aria-label="Total cost" required><?php endif; ?>
            <button class="hb-b" data-confirm="Email work order <?= $e($w['wo_no']) ?> to <?= $e($w['vendor']) ?>?" data-yes="Send it"><?= $w['sent_at'] ? 'Send again' : 'Send' ?></button></form><?php endif; ?>
          <?php $wfPanel = ''; ob_start(); if ($ws !== 'draft' && !in_array($ws, ['cancelled', 'declined', 'rejected', 'received'], true)): $wIds = array_map('intval', array_filter(explode(',', (string) $w['line_ids']))); $wHave = json_decode((string) $w['files'], true) ?: []; ?><details class="co-wo-rcv"><summary class="hb-b">Files (<?= $nf ?>) ▾</summary>
            <form method="post" class="co-f" novalidate><?= $hidden('wo_files') ?><input type="hidden" name="wo" value="<?= (int) $w['id'] ?>">
              <p class="co-note" style="margin:0">Tick what the vendor gets. Upload new files to the order first (Proofs &amp; files), then tick them here.</p>
              <?php $wfAll = []; foreach (WorkOrders::choices($pdo, $oid, $lines) as $lid => $cs) { if ($lid > 0 && !in_array($lid, $wIds, true)) continue; foreach ($cs as $f) $wfAll[] = $f + ['fi' => $woFileInfo($f[0])]; }
                $wfNewest = []; foreach ($wfAll as $f) { $t = strtotime((string) $f['fi']['when_at']) ?: 0; if ($t >= ($wfNewest[$f[1]][1] ?? -1)) $wfNewest[$f[1]] = [$f[0], $t]; }
                $wfCount = array_count_values(array_map(fn ($f) => $f[1], $wfAll)); ?>
              <div class="co-wfl">
              <?php foreach ($wfAll as $f): $fi = $f['fi']; $on = in_array($f[0], $wHave, true); $dup = ($wfCount[$f[1]] ?? 1) > 1; ?>
                <label class="co-wf<?= $on ? ' on' : '' ?>"><input type="checkbox" name="files[]" value="<?= $e($f[0]) ?>"<?= $on ? ' checked' : '' ?>>
                  <span class="co-wf-t"><a href="<?= $e($fi['url']) ?>"<?= $fi['kind'] ? ' data-proof="' . $fi['kind'] . '" data-proof-title="' . $e($f[1]) . '"' : ' target="_blank" rel="noopener"' ?> title="Preview it"><?= $e($f[1]) ?></a>
                    <small><?= $e($f[2]) ?><?= $fi['when'] ? ' · added ' . $e($fi['when']) : '' ?><?= $fi['size'] ? ' · ' . $e($fi['size']) : '' ?><?= $dup ? ' · <b>' . ($wfNewest[$f[1]][0] === $f[0] ? 'newer copy' : 'older copy') . '</b>' : '' ?></small></span>
                  <span class="co-wf-s"><?= $on ? 'On the work order' : (($f[0][0] === 'f' ? ClientOrders::canRetire($pdo) : ClientOrders::canRetireProofs($pdo)) ? '<button type="submit" class="co-lk" form="wfr-' . (int) $w['id'] . '-' . $e(substr($f[0], 1)) . '" title="Keep it on the order, but never offer it for a work order (restore it any time)">Retire</button>' : '') ?></span></label>
              <?php endforeach; ?>
              </div>
              <label style="display:flex;gap:.4rem;align-items:center;font-weight:400"><input type="checkbox" name="tell" value="1" checked> Email <?= $e($w['vendor']) ?> what changed</label>
              <button class="hb-b go">Save files</button></form>
            <?php // the Retire buttons above belong to these small forms (a form can't sit inside another)
              foreach ($wfAll as $f) echo '<form method="post" id="wfr-' . (int) $w['id'] . '-' . $e(substr($f[0], 1)) . '" hidden>' . ($f[0][0] === 'f' ? $hidden('file_retire') . '<input type="hidden" name="file" value="' . (int) substr($f[0], 1) . '">' : $hidden('proof_retire') . '<input type="hidden" name="proof" value="' . (int) substr($f[0], 1) . '">') . '</form>';
              $wfRet = []; foreach ($files as $flid => $fs) { if ($flid > 0 && !in_array($flid, $wIds, true)) continue; foreach ($fs as $ff) if (!empty($ff['retired_at'])) $wfRet[] = $ff + ['key' => 'f' . (int) $ff['id']]; }
              foreach ($lines as $wl) if (in_array((int) $wl['id'], $wIds, true)) foreach (array_merge($wl['proofs'] ?? [], $wl['finals'] ?? []) as $pp) if (!empty($pp['retired_at']) && $pp['mime'] !== 'go-code') $wfRet[] = $pp + ['key' => 'p' . (int) $pp['id'], 'kind' => ($pp['kind'] ?? 'proof') === 'final' ? 'final_p' : 'proof_v'];
              if ($wfRet): ?><details class="co-wf-ret"><summary>Retired files (<?= count($wfRet) ?>): kept on the order, not offered</summary>
              <?php foreach ($wfRet as $ff): $fi = $woFileInfo($ff['key']); $isP = $ff['key'][0] === 'p'; ?><div class="co-wf-r"><span class="co-wf-t"><a href="<?= $e($fi['url']) ?>"<?= $fi['kind'] ? ' data-proof="' . $fi['kind'] . '" data-proof-title="' . $e((string) $ff['file_name']) . '"' : ' target="_blank" rel="noopener"' ?>><?= $e((string) $ff['file_name']) ?></a><small><?= $e($isP ? ($ff['kind'] === 'final_p' ? 'Print-ready' : 'Proof v' . (int) $ff['version']) : (ClientOrders::FILE_KINDS[$ff['kind']] ?? 'File')) ?><?= $fi['when'] ? ' · added ' . $e($fi['when']) : '' ?> · retired <?= $e(date('M j', strtotime((string) $ff['retired_at']))) ?></small></span>
                <form method="post"><?= $isP ? $hidden('proof_restore') . '<input type="hidden" name="proof" value="' . (int) $ff['id'] . '">' : $hidden('file_restore') . '<input type="hidden" name="file" value="' . (int) $ff['id'] . '">' ?><button class="co-lk">Restore</button></form></div><?php endforeach; ?></details><?php endif; ?>
            </details><?php endif; $wfPanel = ob_get_clean(); ?>
          <?php if ($stReady && in_array($ws, ['accepted', 'production', 'shipped', 'ready', 'complete'], true)): ?><details class="co-wo-rcv"><summary class="hb-b">Receive ▾</summary>
            <form method="post" class="co-f" novalidate><?= $hidden('wo_receive') ?><input type="hidden" name="wo" value="<?= (int) $w['id'] ?>">
              <label>Received by<input class="hb-in" name="by" maxlength="120" value="<?= $e((string) ($me['display_name'] ?? '')) ?>"></label><label>Date<input class="hb-in" name="on" type="date" value="<?= date('Y-m-d') ?>"></label>
              <label>Note (what's wrong, if you reject it)<input class="hb-in" name="note" maxlength="500"></label>
              <div style="display:flex;gap:.35rem;flex-wrap:wrap"><button class="hb-b go" name="ok" value="1">Accept it</button><button class="hb-b no" name="ok" value="0" data-confirm="Reject this work order on receipt? The vendor is told." data-yes="Reject it" data-danger>Reject</button></div></form></details><?php endif; ?>
          <?php if ($stReady && in_array($ws, ['rejected', 'declined', 'cancelled'], true)): ?><form method="post" class="co-wo-again"><?= $hidden('wo_reprint') ?><input type="hidden" name="wo" value="<?= (int) $w['id'] ?>"><button class="hb-b" title="A new work order with the same items, files and details, to send to this vendor or another"><?= $ws === 'rejected' ? 'Reprint' : 'Make it again' ?></button></form><?php endif; ?>
          <?php if ($ws === 'draft' && empty($w['sent_at'])): ?><form method="post" class="co-wo-again"><?= $hidden('wo_delete') ?><input type="hidden" name="wo" value="<?= (int) $w['id'] ?>"><button class="co-lk" data-confirm="Delete draft work order <?= $e($w['wo_no']) ?>? It was never sent; the order's history keeps a line." data-yes="Delete it" data-danger>Delete draft</button></form>
          <?php elseif ($stReady && !in_array($ws, ['received', 'cancelled', 'rejected', 'declined'], true)): ?><form method="post" class="co-wo-again"><?= $hidden('wo_cancel') ?><input type="hidden" name="wo" value="<?= (int) $w['id'] ?>"><input type="hidden" name="why" value=""><button class="co-lk" data-confirm="Cancel work order <?= $e($w['wo_no']) ?>?<?= $w['sent_at'] ? ' The vendor is told to stop.' : '' ?>" data-yes="Cancel it" data-danger>Cancel</button></form><?php endif; ?></td></tr>
      <?php if (trim($wfPanel) !== ''): ?><tr class="co-wo-frow"><td colspan="4"><?= $wfPanel ?></td></tr><?php endif; ?>
    <?php endforeach; ?></table><?php else: ?><p class="text-sm" style="margin:0">None yet. Send the vendor what to make, with the files: it goes from orders@trvgo.us with a private link where they download the files, accept it and update it as it moves along (no client prices or billing).</p><?php endif; ?>
    <?php if (empty($o['invoice_id'])): ?><form method="post" class="co-f co-wo-inv" novalidate><?= $hidden('wo_invoice') ?><label>QuickBooks invoice # (made by hand; for reference only, nothing is posted to it)<span style="display:flex;gap:.3rem"><input class="hb-in" name="invoice_ref" maxlength="40" value="<?= $e($o['invoice_no'] ?? '') ?>" placeholder="1044" style="max-width:10rem"><button class="hb-b">Keep it</button></span></label></form><?php endif; ?>
    <?php
      $woEdit = null; if (ctype_digit((string) ($_GET['wo_edit'] ?? ''))) { $woEdit = WorkOrders::get($pdo, (int) $_GET['wo_edit']); if (!$woEdit || (int) $woEdit['order_id'] !== $oid || ($woEdit['status'] ?? 'draft') !== 'draft') $woEdit = null; } ?>
    <?php if ($woEdit): ?>
    <details class="co-more" id="wo-edit" open><summary style="font-weight:700;margin-top:.6rem">Work order <?= $e($woEdit['wo_no']) ?> (not sent yet)</summary>
      <p class="co-note" style="margin:.3rem 0">Saved <?= $e(date('M j, g:i a', strtotime((string) ($woEdit['status_at'] ?? $woEdit['created_at'])))) ?>. <a class="underline" href="/wo.php?w=<?= $e($woEdit['token']) ?>" target="_blank" rel="noopener">See it as the vendor</a> · <a class="underline" href="<?= $e($self) ?>#work">Close</a></p>
      <form method="post" class="co-f" novalidate><?= $hidden('wo_create') ?>
        <?= $woFields($woEdit) ?>
        <?= $woBtns() ?>
      </form></details>
    <?php endif; ?>
    <details class="co-more" id="wo-new"<?= empty($_GET['wo_new']) ? '' : ' open' ?>><summary style="font-weight:700;margin-top:.6rem">+ New work order</summary>
      <form method="post" class="co-f" novalidate><?= $hidden('wo_create') ?>
        <?= $woFields() ?>
        <?= $woBtns() ?>
      </form></details>
  </div>
  <?php endif; ?>

  <?php if ($o['status'] !== 'draft' && $o['status'] !== 'void'): ?>
  <h2 class="hb-h">Tell the client</h2>
  <div class="hb-card tv-bleed">
    <p class="text-sm">Set each item's status in the list above; the client isn't told until you send an update. It lists each item, its status and tracking.</p>
    <?php $vendors = array_unique(array_filter(array_map(fn ($l) => $l['product'] === 'product' ? (string) (Products::get($pdo, (int) $l['product_id'])['vendor'] ?? '') : '', $lines))); if ($vendors): ?><small style="color:#8A7355">Place it with: <?= $e(implode(', ', $vendors)) ?>, using the approved proof<?= count($lines) > 1 ? 's' : '' ?> above.</small><?php endif; ?>
    <form method="post" class="co-f" novalidate><?= $hidden('send_update') ?>
      <label>A note with it (optional)<textarea class="hb-in" name="note" rows="2" maxlength="600" placeholder="Your cards ship tomorrow; the banner is a day behind."></textarea></label>
      <div><button class="hb-b go" id="co-update-btn" data-confirm="Email <?= $e($o['bill_email']) ?> where each item stands?" data-yes="Send it">Send update</button></div>
    </form>
  </div>
  <?php endif; ?>

  <?php if (in_array($o['status'], ['pending', 'paid'], true) && ClientOrders::isClient($o)): $openC = ClientOrders::openBeforeComplete($pdo, $o, (int) $m['paid']); ?>
  <h2 class="hb-h" id="finish">Complete the order</h2>
  <div class="hb-card tv-bleed">
    <?php $fbs = ClientOrders::feedback($pdo, $oid); $stars = fn ($n) => $n ? str_repeat('★', (int) $n) . str_repeat('☆', 5 - (int) $n) : '';
      foreach ($fbs as $f) if ($f['kind'] === 'problem' && $f['resolved_at'] === null): ?>
    <?php require_once __DIR__ . '/../../app/lib/Pulse.php'; $tk = Pulse::caseNo($pdo, 'fb:' . $f['id']); ?>
    <p data-tv-status="bad" data-tv-label="<?= $e($tk ? 'Support ticket #' . $tk . ':' : 'The client says something isn\'t right:') ?>"><?= $e($f['words']) ?> <small>(<?= $e($when($f['created_at'])) ?>)</small></p>
    <form method="post" style="margin:-.2rem 0 .5rem;display:flex;gap:.4rem;flex-wrap:wrap"><?= $hidden('problem_ok') ?><input type="hidden" name="fb" value="<?= (int) $f['id'] ?>"><a class="hb-b" href="/admin/pulse/stream#case=<?= $e(rawurlencode('fb:' . $f['id'])) ?>" target="_top">Reply from the ticket</a><button class="hb-b" data-confirm="Put right, with the client told? This resolves the ticket." data-yes="Mark resolved">Mark resolved</button></form>
    <?php endif; foreach ($fbs as $f) if ($f['kind'] === 'review'): ?>
    <p data-tv-status="info" data-tv-label="The client said:"><?= $e(trim($stars($f['rating']) . ' ' . ($f['words'] !== '' ? '"' . $f['words'] . '"' : ''))) ?><?= (int) $f['may_quote'] ? ' (we may quote it)' : '' ?> <small>(<?= $e($when($f['created_at'])) ?>)</small></p>
    <?php endif; ?>
    <?php if ($o['stage'] === 'complete'): ?><p data-tv-status="ok" data-tv-label="Complete:">This order is done<?= !empty($o['received_at']) ? ': the client confirmed they have it on ' . $e(date('M j', strtotime((string) $o['received_at']))) : '' ?>. It's in the archive (Order management → Completed). The client was thanked, with a link to reorder at today's prices; a reorder re-runs each item's costing at today's costs (to check again) and starts its work order from these specs.</p>
    <?php else: ?>
    <?php if (ClientOrders::hasReceived($pdo) && ClientOrders::outTheDoor($pdo, $o)): ?><p data-tv-status="info" data-tv-label="Waiting on the client:">Everything is out the door. The client was asked to tell us when they have it, and how it went: that completes the order. If they've told you another way, complete it here.</p>
    <?php else: ?><p class="text-sm" style="margin:0 0 .4rem">When the last item ships or is ready for pickup, the client is emailed and asked to tell us when they have it: that completes the order. You can complete it here too. Either way it moves to the archive, and the client gets a thank-you with a link to reorder.</p><?php endif; ?>
    <?php if ($openC): ?><p data-tv-status="info" data-tv-label="Still open:"><?= $e(implode('; ', $openC)) ?>.</p><?php endif; ?>
    <form method="post"><?= $hidden('complete') ?><button class="hb-b go" id="co-complete" data-confirm="<?= $e(($openC ? 'Still open: ' . implode('; ', $openC) . '. ' : '') . 'Complete order #' . Orders::no($o) . '? It moves to the archive and the client gets a thank-you with a reorder link.') ?>" data-yes="Complete it">Complete the order</button></form>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <h2 class="hb-h">History</h2>
  <div class="hb-card tv-bleed"><ul class="co-log"><?php foreach (array_reverse($events) as $ev): ?><li><?= $e(str_replace('_', ' ', ucfirst((string) $ev['event']))) ?><?= $ev['note'] !== '' ? ': ' . $e($ev['note']) : '' ?><br><small><?= $e($when($ev['created_at'])) ?><?= $ev['actor_name'] ? ' · ' . $e($ev['actor_name']) : ($ev['actor_user_id'] ? '' : ' · the client or the system') ?></small></li><?php endforeach; ?></ul></div>
</div>
<script>
(function () {   // + Add item: the pop-up and its tabs
  var d = document.getElementById('co-add'); if (!d) return;
  var open = function (t) { d.hidden = false; document.documentElement.style.overflow = 'hidden'; if (t) tab(t); };
  var close = function () { d.hidden = true; document.documentElement.style.overflow = ''; };
  var tab = function (k) { d.querySelectorAll('[data-tab]').forEach(function (b) { b.setAttribute('aria-selected', b.getAttribute('data-tab') === k ? 'true' : 'false'); }); d.querySelectorAll('[data-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== k; }); };
  document.querySelectorAll('[data-add-open]').forEach(function (b) { b.addEventListener('click', function () {
    var pj = b.getAttribute('data-project') || '';   // + Add item here: the new item goes into that project
    d.querySelectorAll('form').forEach(function (f) { var h = f.querySelector('input[name=project]'); if (!h) { h = document.createElement('input'); h.type = 'hidden'; h.name = 'project'; f.appendChild(h); } h.value = pj; });
    open(); }); });
  d.querySelectorAll('[data-tab]').forEach(function (b) { b.addEventListener('click', function () { tab(b.getAttribute('data-tab')); }); });
  d.querySelector('[data-add-close]').addEventListener('click', close);
  d.addEventListener('click', function (e) { if (e.target === d) close(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !d.hidden && !document.querySelector('.tv-ask-lb')) close(); });
  if (location.hash === '#add') open();
  // a message shows where you were working: an Add item error in its tab (what you typed kept), else beside the item
  var FL = window.__coFlash, top = document.getElementById('co-flash');
  if (FL && FL.dlg) {
    var panel = d.querySelector('[data-panel="' + FL.dlg + '"]');
    if (panel) {
      if (top) top.hidden = true;
      open(FL.dlg);
      var f = panel.querySelector('form'), box = TvAsk.say(FL.text, { anchor: panel.firstElementChild || panel, bad: true }); if (box && panel.firstChild !== box) panel.insertBefore(box, panel.firstChild);
      if (f) Object.keys(FL.fields || {}).forEach(function (k) { if (k === 'do' || k === 'id') return; var el = f.elements[k]; if (!el) { if (k === 'project') { el = document.createElement('input'); el.type = 'hidden'; el.name = 'project'; f.appendChild(el); } else return; }
        if (el.type === 'checkbox') el.checked = !!FL.fields[k]; else el.value = FL.fields[k]; });
      if (f) f.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }
})();
(function () {   // after a change to an item or a project, its message shows beside it (the page comes back where you were)
  var FL = window.__coFlash, top = document.getElementById('co-flash'); if (!FL || FL.dlg || !top || !window.TvAsk) return;
  var m = /^#(l|p)(\d+)$/.exec(location.hash) || /^#item=(\d+)/.exec(location.hash);
  var el = m ? document.getElementById(m.length === 3 ? m[1] + m[2] : 'l' + m[1]) : null;
  if (!el) return;
  top.hidden = true;
  setTimeout(function () { TvAsk.say(FL.text, { bad: FL.type === 'error', anchor: el.querySelector('.co-desc > b, .co-prjh') || el /* inside the description: in the row's grid it would push the icons out */ }); }, 60);
})();
</script>
<script>
(function () {   // the save button: ▾ lists the four ways; picking one makes it the main button (remembered in this browser) and runs it
  var last = ''; try { last = localStorage.getItem('tvWoSave') || ''; } catch (x) {}
  document.querySelectorAll('[data-split]').forEach(function (sp) {
    var main = sp.querySelector('[data-split-main]'), tog = sp.querySelector('.co-split-t'), list = sp.querySelector('.co-split-l'), form = sp.closest('form');
    var inv = sp.hasAttribute('data-outside') && form ? form.querySelector('[name=invoice_ref]') : null;
    var ask = function (b) {   // the question: how the order is processed (outside), then what this way does
      if (!b.hasAttribute('data-then')) { b.removeAttribute('data-confirm'); return; }
      var then = b.getAttribute('data-then'), n = inv ? inv.value.trim().replace(/^#/, '') : '';
      var unc = form && b.value === 'send' ? [].filter.call(form.querySelectorAll('input[name="lines[]"][data-cogs]:checked'), function (c) { return c.getAttribute('data-cogs') !== 'ok'; }).map(function (c) { return c.getAttribute('data-cogs-name'); }) : [];
      if (unc.length) then = 'COGS isn\'t checked for ' + unc.join(', ') + ' (its Cost tab). Send anyway? ' + then;
      var due = form && b.value === 'send' && form.querySelector('[name=due_on]');   // no must-have date: the vendor has nothing to schedule by
      if (due && !due.value) then = 'No must-have date: the vendor sees "Not set". Send anyway? ' + then;
      var first = !inv ? '' : (n ? 'Process this order against QuickBooks invoice #' + n + ' (the one you made there: nothing new is made or posted) and put it into production?' : 'Process this order outside QuickBooks (no invoice made here or there) and put it into production?');
      b.setAttribute('data-confirm', (first ? first + ' ' : '') + then);
    };
    var use = function (b) { main.value = b.value; main.textContent = b.textContent; ['data-then', 'data-yes'].forEach(function (k) { if (b.hasAttribute(k)) main.setAttribute(k, b.getAttribute(k)); else main.removeAttribute(k); }); ask(main); };
    var pick = last && list.querySelector('button[value="' + last + '"]'); if (pick) use(pick); else ask(main);
    if (inv) inv.addEventListener('input', function () { ask(main); });
    if (form) form.addEventListener('change', function (e) { if (e.target.name === 'lines[]' || e.target.name === 'due_on') ask(main); });
    // the cost starts as the vendor's share of the ticked items' COGS, and follows the ticks until someone types one
    var autoC = form && form.querySelector('input[name=cost][data-wo-auto]');
    var fillC = function () { if (!autoC || !autoC.hasAttribute('data-wo-auto')) return; var t = 0; form.querySelectorAll('input[name="lines[]"][data-cogs]:checked').forEach(function (c) { t += +c.getAttribute('data-vendor-cents') || 0; }); autoC.value = t ? (t / 100).toFixed(2) : ''; };
    if (autoC) { fillC(); autoC.defaultValue = autoC.value; autoC.addEventListener('input', function () { autoC.removeAttribute('data-wo-auto'); }); form.addEventListener('change', function (e) { if (e.target.name === 'lines[]') fillC(); }); }
    // Reset to COGS ($X): shown only when the cost typed differs from the vendor's share of the ticked items' COGS
    var cg = form && form.querySelector('[data-wo-cogs]');
    var share = function () { var t = 0; form.querySelectorAll('input[name="lines[]"][data-cogs]:checked').forEach(function (c) { t += +c.getAttribute('data-vendor-cents') || 0; }); return t; };
    var cgSync = function () { if (!cg) return; var t = share(), v = Math.round((parseFloat(String(form.elements.cost.value || '').replace(/[,$\s]/g, '')) || 0) * 100); cg.hidden = !t || v === t; cg.textContent = 'Reset to COGS ($' + (t / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ')'; };
    if (cg) { cgSync(); form.addEventListener('input', cgSync); form.addEventListener('change', cgSync);
      cg.addEventListener('click', function () { var t = share(); form.elements.cost.value = (t / 100).toFixed(2); cgSync(); if (window.TvAsk) TvAsk.say('The cost is the vendor\'s share of the ticked items\' COGS again.', { anchor: form.elements.cost, bad: false }); }); }
    var shut = function () { list.hidden = true; tog.setAttribute('aria-expanded', 'false'); };
    // the list floats over the page, pinned to the ▾ (a card around the form can't clip it): up when there's room, else down
    var place = function () {
      var r = tog.getBoundingClientRect(), h = list.offsetHeight;
      list.style.position = 'fixed'; list.style.right = Math.max(4, document.documentElement.clientWidth - r.right) + 'px'; list.style.left = 'auto';
      if (r.top - h - 4 > 0) { list.style.top = 'auto'; list.style.bottom = (window.innerHeight - r.top + 4) + 'px'; }
      else { list.style.bottom = 'auto'; list.style.top = (r.bottom + 4) + 'px'; }
    };
    tog.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); list.hidden = !list.hidden; tog.setAttribute('aria-expanded', list.hidden ? 'false' : 'true'); if (!list.hidden) place(); });
    window.addEventListener('scroll', function () { if (!list.hidden) shut(); }, { passive: true }); window.addEventListener('resize', function () { if (!list.hidden) shut(); });
    list.querySelectorAll('button').forEach(function (b) { b.addEventListener('click', function () { try { localStorage.setItem('tvWoSave', b.value); } catch (x) {} use(b); shut(); main.click(); }); });
    document.addEventListener('click', function (e) { if (!list.hidden && !sp.contains(e.target)) shut(); });
  });
})();
</script>
<script>
(function () {   // recording a payment: the question mentions a receipt only when one is to go
  document.querySelectorAll('[data-receipt]').forEach(function (c) {
    var b = c.closest('form').querySelector('[data-confirm-receipt]'); if (!b) return;
    var plain = b.getAttribute('data-confirm'), set = function () { b.setAttribute('data-confirm', c.checked ? b.getAttribute('data-confirm-receipt') : plain); };
    c.addEventListener('change', set); set();
  });
})();
</script>
<script>
(function () {   // the vendor's link, to send yourself: copied here (no request), or shown after a draft was marked sent
  var show = function (url, at) { TvAsk.ask('The vendor\'s link: copy it into your email', url); };
  document.querySelectorAll('[data-copy-link]').forEach(function (b) {
    b.addEventListener('click', function () {
      var url = b.getAttribute('data-copy-link');
      try { if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(url).then(function () { TvAsk.say('Link copied: ' + url, { anchor: b, bad: false }); }, function () { show(url, b); }); return; } } catch (x) {}
      show(url, b);
    });
  });
  var L = <?php $wl = $_SESSION['tv_wo_link'] ?? null; if ($wl && (int) $wl['oid'] === $oid) { unset($_SESSION['tv_wo_link']); echo json_encode($wl, JSON_HEX_TAG | JSON_HEX_AMP); } else echo 'null'; ?>;
  if (L) window.addEventListener('load', function () { setTimeout(function () { if (L.how === 'email') window.location.href = L.mailto; show(L.url); }, 400); });
})();
</script>
<script>
(function () {   // the work order's Ship to: one of the order's addresses fills it in
  document.querySelectorAll('select[data-wo-shipuse]').forEach(function (u) {
    u.addEventListener('change', function () { var t = u.closest('.co-wo-ship').querySelector('[data-wo-shipto]'); if (t && u.value) t.value = u.value; });
  });
})();
(function () {   // a vendor picked: its orders email from the list; "a new vendor" asks for the name
  document.querySelectorAll('select[data-wo-vendor]').forEach(function (v) {
    v.addEventListener('change', function () {
      var em = v.form.querySelector('[data-wo-email]'), nw = v.form.querySelector('[data-wo-new]'), o = v.options[v.selectedIndex];
      if (nw) { nw.hidden = v.value !== 'new'; if (!nw.hidden) nw.focus(); }
      if (em) em.value = v.value === 'new' ? '' : (o.getAttribute('data-email') || '');
      v.form.querySelectorAll('[data-pns]').forEach(function (p) { var m = {}; try { m = JSON.parse(p.getAttribute('data-pns')); } catch (x) {} p.value = m[v.value] || ''; });
      var pref = o.getAttribute('data-pref') || '';   // the files this vendor takes: production setups, or 1-up print files
      if (pref) { var has = function (k) { return !!v.form.querySelector('input[name="files[]"][data-kind="' + k + '"]'); };
        if (has(pref)) v.form.querySelectorAll('input[name="files[]"]').forEach(function (c) { var k = c.getAttribute('data-kind'); c.checked = k === pref; }); }
    });
  });
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-wo-for]'); if (!a) return;
    var id = a.getAttribute('href').slice(1), d = document.getElementById(id), lid = a.getAttribute('data-wo-for'); if (!d) return;
    e.preventDefault(); var x = document.querySelector('#co-item:not([hidden]) [data-ip-close]'); if (x) x.click();   // the item's panel closes; the form opens with just this item
    d.open = true; d.querySelectorAll('input[name="lines[]"]').forEach(function (c) { c.checked = c.value === lid; });
    setTimeout(function () { d.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 60);
  });
  if (/^#(work|outside)$/.test(location.hash)) { var d = document.getElementById(location.hash.slice(1)); if (d && d.tagName === 'DETAILS') d.open = true; }
})();
(function () {   // the order edited in place: values save as you leave them (/api/admin/client-order.php)
  var OID = <?= (int) $oid ?>, CSRF = <?= json_encode($csrf) ?>;
  function save(body, el) {
    body.id = OID;
    return fetch('/api/admin/client-order.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
      .then(function (res) {   // a reply that isn't ours (a server or firewall page) is still a "didn't save", never silence
        return res.text().then(function (t) { try { return JSON.parse(t); } catch (x) { return { ok: false, error: { message: 'That didn\'t save (the server answered ' + res.status + (res.status === 406 ? ': blocked by the host\'s firewall' : '') + '). Try again, or use the item\'s Edit button.' } }; } });
      }, function () { return { ok: false, error: { message: 'That didn\'t save: no connection. Try again.' } }; })
      .then(function (r) {
        var at = el ? { anchor: el.closest('.co-box,.co-line,.co-cust,.co-msgbox') || el, bad: true } : { bad: true };
        if (!r || r.ok === false || r.success === false) { var m = (r && r.error && (r.error.message || r.error)) || 'That didn\'t save.'; if (el && el.__was !== undefined) el.textContent = el.__was; TvAsk.say(String(m), at); return; }
        if (el) { el.classList.add('co-saved'); setTimeout(function () { el.classList.remove('co-saved'); }, 900); }
        if (r.reload) location.reload();
      });
  }
  function bodyFor(el, v) { var ln = el.closest('[data-line]'); return el.hasAttribute('data-lf') ? { do: 'line', line: +ln.getAttribute('data-line'), f: el.getAttribute('data-lf'), v: v } : { do: 'field', f: el.getAttribute('data-f'), v: v }; }
  document.querySelectorAll('.co-ed').forEach(function (el) {
    el.addEventListener('focus', function () { el.__was = el.textContent; });
    el.addEventListener('keydown', function (e) { if (e.key === 'Enter' && el.getAttribute('data-lf') !== 'note' && el.getAttribute('data-f') !== 'note') { e.preventDefault(); el.blur(); } if (e.key === 'Escape') { el.textContent = el.__was; el.blur(); } });
    el.addEventListener('blur', function () { var v = el.textContent.trim(); if (v === (el.__was || '').trim()) return; save(bodyFor(el, v), el); });
  });
  document.querySelectorAll('select.co-sel[data-f], input.co-sel[data-f]').forEach(function (el) { el.addEventListener('change', function () { save({ do: 'field', f: el.getAttribute('data-f'), v: el.value }, el); }); });
  document.querySelectorAll('select[data-lf]').forEach(function (el) { el.addEventListener('change', function () { save(bodyFor(el, el.value), el); }); });
  document.querySelectorAll('input[type=checkbox][data-lf]').forEach(function (el) { el.addEventListener('change', function () { save(bodyFor(el, el.checked ? '1' : '0'), el); }); });
  var same = document.querySelector('[data-same]');   // Ship to = Bill to
  if (same) same.addEventListener('click', function () {
    var get = function (f) { var x = document.querySelector('[data-f="' + f + '"]'); return x ? x.textContent.trim() : ''; };
    var map = { ship_name: get('company') || get('name'), ship_street: get('bill_street'), ship_city: get('bill_city'), ship_state: get('bill_state'), ship_zip: get('bill_zip') };
    Promise.all(Object.keys(map).map(function (f) { var x = document.querySelector('[data-f="' + f + '"]'); if (x) x.textContent = map[f]; return save({ do: 'field', f: f, v: map[f] }); }));
  });
  var cust = document.getElementById('co-cust');   // a past client fills the order
  if (cust) cust.addEventListener('change', function () { var v = cust.value.trim().toLowerCase(); if ([].some.call(document.querySelectorAll('#co-pastc option'), function (o) { return o.value === v; })) save({ do: 'customer', key: v }, cust); });
  // the ship icon: its pop-up, filled from the item
  var sd = document.getElementById('co-ship');
  if (sd) {
    var sf = sd.querySelector('form');
    var toggle = function () { var pick = (sf.querySelector('input[name=style]:checked') || {}).value === 'pickup'; sf.querySelectorAll('[data-not-pickup]').forEach(function (x) { x.hidden = pick; }); };
    sf.querySelectorAll('input[name=style]').forEach(function (r) { r.addEventListener('change', toggle); });
    document.querySelectorAll('[data-ship-open]').forEach(function (b) { b.addEventListener('click', function () {
      var id = b.getAttribute('data-ship-open'), t = document.querySelector('template[data-ship-data="' + id + '"]'), d = JSON.parse(t.content.textContent || '{}');
      sf.line.value = id; sd.querySelector('[data-ship-title]').textContent = d.title || '';
      sf.querySelectorAll('input[name=style]').forEach(function (r) { r.checked = r.value === (d.style || 'drop'); });
      sf.carrier.value = d.carrier || ''; sf.address.value = d.address || ''; sf.charge.value = d.charge || ''; sf.cost.value = d.cost || ''; sf.tracking.value = d.tracking || ''; sf.label.value = '';
      toggle(); sd.hidden = false; document.documentElement.style.overflow = 'hidden';
    }); });
    var shut = function () { sd.hidden = true; document.documentElement.style.overflow = ''; };
    sd.querySelector('[data-ship-close]').addEventListener('click', shut);
    sd.addEventListener('click', function (e) { if (e.target === sd) shut(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !sd.hidden) shut(); });
  }
  // drag the ⋮⋮ handle to reorder the items
  var list = document.getElementById('lines'), dragging = null;
  if (list) {
    list.querySelectorAll('.co-drag').forEach(function (h) {
      var row = h.closest('.co-line');
      h.addEventListener('mousedown', function () { row.draggable = true; });
      h.addEventListener('touchstart', function () { row.draggable = true; }, { passive: true });
      row.addEventListener('dragstart', function (e) { dragging = row; row.classList.add('co-dragging'); e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', row.id); } catch (x) {} });
      row.addEventListener('dragend', function () {
        row.draggable = false; row.classList.remove('co-dragging'); dragging = null;
        var ids = [].map.call(list.querySelectorAll('.co-line[data-line]'), function (r) { return +r.getAttribute('data-line'); });
        [].forEach.call(list.querySelectorAll('.co-line .co-n'), function (n, i) { n.textContent = i + 1; });
        save({ do: 'reorder', ids: ids });
      });
    });
    list.addEventListener('dragover', function (e) {
      if (!dragging) return; e.preventDefault();
      var over = e.target.closest && e.target.closest('.co-line'); if (!over || over === dragging) return;
      var r = over.getBoundingClientRect(); over.parentNode.insertBefore(dragging, e.clientY > r.top + r.height / 2 ? over.nextSibling : over);
    });
  }
})();
</script>
<script>
(function () {   // an item's ship icon, when the order ships: its lots editor (Shipments)
  var d = document.getElementById('co-lots'), t = document.getElementById('co-lots-data'); if (!d || !t) return;
  var D = JSON.parse(t.content.textContent || '{}'), f = d.querySelector('form'), rows = d.querySelector('[data-lots-rows]'), cur = null;
  var esc = function (x) { return String(x).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var opts = function (sel) { return D.dests.map(function (x) { return '<option value="' + x.id + '"' + (x.id === sel ? ' selected' : '') + '>' + esc(x.label) + '</option>'; }).join(''); };
  var row = function (l) { var r = document.createElement('div'); r.className = 'co-lotrow';
    r.innerHTML = '<input type="hidden" name="lid[]" value="' + (l.id || 0) + '"><label>Qty<input class="hb-in" name="lq[]" inputmode="numeric" value="' + (l.qty || '') + '"></label>'
      + '<label>Lot<input class="hb-in" name="ll[]" maxlength="80" value="' + esc(l.label || '') + '" placeholder="Lot ' + (rows.children.length + 1) + '"></label>'
      + '<label' + (D.single ? ' hidden' : '') + '>Goes to<select class="hb-in" name="ld[]">' + opts(l.dest) + '</select></label><button type="button" class="co-icb no" aria-label="Remove lot">×</button>';
    r.querySelector('button').onclick = function () { r.remove(); sum(); }; r.addEventListener('input', sum); rows.appendChild(r); };
  var sum = function () { var n = 0; rows.querySelectorAll('input[name="lq[]"]').forEach(function (i) { n += +i.value || 0; }); d.querySelector('[data-lots-sum]').textContent = n + ' of ' + cur.qty + (n === cur.qty ? ' ✓' : ' (should add up to ' + cur.qty + ')'); };
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-ship-open]'); if (!b) return;
    e.preventDefault(); e.stopImmediatePropagation();
    cur = D.lines.filter(function (x) { return String(x.id) === b.getAttribute('data-ship-open'); })[0]; if (!cur) return;
    f.line.value = cur.id; d.querySelector('[data-lots-title]').textContent = cur.title; rows.innerHTML = '';
    (cur.lots.length ? cur.lots : [{ qty: cur.qty, dest: D.dests[0] && D.dests[0].id }]).forEach(row); sum();
    d.hidden = false; document.documentElement.style.overflow = 'hidden';
  }, true);
  d.querySelector('[data-lot-add]').onclick = function () { row({ qty: '', dest: D.dests[0] && D.dests[0].id }); };
  d.querySelector('[data-split]').onclick = function () { var n = +d.querySelector('[data-split-n]').value || 0; if (n < 1 || !cur) return; var dest = (rows.querySelector('select') || {}).value; rows.innerHTML = '';
    var each = Math.floor(cur.qty / n), extra = cur.qty - each * n; for (var i = 0; i < n; i++) row({ qty: each + (i < extra ? 1 : 0), label: 'Lot ' + (i + 1), dest: +dest || (D.dests[0] && D.dests[0].id) }); sum(); };
  var shut = function () { d.hidden = true; document.documentElement.style.overflow = ''; };
  d.querySelector('[data-lots-close]').onclick = shut; d.addEventListener('click', function (e) { if (e.target === d) shut(); });
})();
</script>
<script>
// the item panel (decisions/0107): opens beside the order (#item=<line>:<tab> after a save brings it back)
(function () {
  var P = document.getElementById('co-item'); if (!P) return;
  var cur = null;
  function show(lid, tab) {
    var sec = P.querySelector('[data-ip="' + lid + '"]'); if (!sec) return;
    var tabs = sec.getAttribute('data-tabs').split(','); if (tabs.indexOf(tab) < 0) tab = tabs[0];
    P.querySelectorAll('[data-ip]').forEach(function (x) { x.hidden = x !== sec; });
    P.querySelectorAll('[data-ip-tab]').forEach(function (b) { var t = b.getAttribute('data-ip-tab'); b.hidden = tabs.indexOf(t) < 0; b.setAttribute('aria-selected', t === tab ? 'true' : 'false'); });
    sec.querySelectorAll('[data-pane]').forEach(function (d) { d.hidden = d.getAttribute('data-pane') !== tab; });
    P.querySelector('[data-ip-title]').textContent = sec.getAttribute('data-title');
    var on = P.querySelector('[data-ip-tab="' + tab + '"]'); P.querySelector('[data-ip-cur]').textContent = on ? on.textContent : ''; menu(false);
    P.hidden = false; document.body.classList.add('co-ip-on'); cur = lid;
    document.querySelectorAll('.co-line.on').forEach(function (r) { r.classList.remove('on'); }); var row = document.getElementById('l' + lid); if (row) row.classList.add('on');
    history.replaceState(null, '', '#item=' + lid + ':' + tab);
  }
  function menu(open) { var l = P.querySelector('.co-ip-tabs'), b = P.querySelector('[data-ip-menu]'); l.hidden = !open; b.setAttribute('aria-expanded', open ? 'true' : 'false'); }   // ☰: the item's tools, beside ×
  function close() { menu(false); P.hidden = true; document.body.classList.remove('co-ip-on'); cur = null; document.querySelectorAll('.co-line.on').forEach(function (r) { r.classList.remove('on'); }); history.replaceState(null, '', location.pathname + location.search); }
  document.addEventListener('click', function (e) {
    var o = e.target.closest('[data-item-open]'); if (o) { e.preventDefault(); show(o.getAttribute('data-item-open'), o.getAttribute('data-tab') || 'details'); return; }
    if (e.target.closest('[data-ip-menu]')) { menu(P.querySelector('.co-ip-tabs').hidden); return; }
    if (!e.target.closest('.co-ip-tabs') && cur) menu(false);
    var t = e.target.closest('[data-ip-tab]'); if (t && cur) { show(cur, t.getAttribute('data-ip-tab')); return; }
    var g = e.target.closest('[data-ip-go]'); if (g && cur) { show(cur, g.getAttribute('data-ip-go')); return; }
    if (e.target.closest('[data-ip-close]')) { close(); return; }
    var a = e.target.closest('[data-tag-add]'); if (a) {   // a quick tag: adds it, or takes it away when it's there
      var i = a.closest('form').querySelector('[data-tags]'), list = i.value.split(',').map(function (x) { return x.trim(); }).filter(Boolean), w = a.getAttribute('data-tag-add'),
        k = list.map(function (x) { return x.toLowerCase(); }).indexOf(w.toLowerCase());
      if (k < 0) list.push(w); else list.splice(k, 1); i.value = list.join(', '); mark(a.closest('form'));
    }
  });
  function mark(f) { var i = f.querySelector('[data-tags]'), have = i.value.toLowerCase().split(',').map(function (x) { return x.trim(); });
    f.querySelectorAll('[data-tag-add]').forEach(function (b) { b.setAttribute('aria-pressed', have.indexOf(b.getAttribute('data-tag-add').toLowerCase()) >= 0 ? 'true' : 'false'); }); }
  P.querySelectorAll('[data-tags]').forEach(function (i) { mark(i.form); i.addEventListener('input', function () { mark(i.form); }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && cur && !document.querySelector('.co-dlg:not([hidden])')) close(); });
  var m = /^#item=(\d+)(?::(\w+))?/.exec(location.hash); if (m) show(m[1], m[2] || 'details');
})();
</script>
<?= tv_cost_css() ?><script src="/js/tv-cost.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-cost.js') ?>"></script>
<script src="/js/tv-proof.js?v=<?= (int) @filemtime(__DIR__ . '/../js/tv-proof.js') ?>"></script>
<script>
(function () {
  var P = <?= json_encode(array_map(fn ($p) => ['id' => (int) $p['id'], 'options' => $p['options'], 'tiers' => $p['tiers'], 'markup' => (int) $p['markup'], 'desc' => $p['description'], 'turn' => $p['turnaround']], $products), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>;
  var f = document.getElementById('co-prod');
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function paint() {
    if (!f) return;
    var p = P.filter(function (x) { return String(x.id) === f.product.value; })[0]; if (!p) return;
    document.getElementById('co-opts').innerHTML = p.options.map(function (o, i) { return '<label>' + esc(o.name) + '<select class="hb-in" name="opt[' + i + ']">' + o.choices.map(function (c) { return '<option value="' + esc(c.label) + '">' + esc(c.label) + (c.pct ? ' (+' + c.pct + '%)' : (c.add ? ' (+$' + (c.add * (100 + p.markup) / 10000).toFixed(2) + ')' : '')) + '</option>'; }).join('') + '</select></label>'; }).join('');
    f.querySelectorAll('#co-opts select').forEach(function (s) { s.addEventListener('change', function () { hint(); }); });
    document.getElementById('co-qty').innerHTML = p.tiers.map(function (t) { return '<option value="' + t.qty + '">'; }).join('');
    if (!f.qty.value && p.tiers[0]) f.qty.value = p.tiers[0].qty;
    hint(p);
  }
  function hint(p) {
    p = p || P.filter(function (x) { return String(x.id) === f.product.value; })[0]; if (!p) return;
    var q = +f.qty.value || 0, t = null; p.tiers.forEach(function (x) { if (x.qty <= q) t = x; }); t = t || p.tiers[0];
    var base = t ? (t.qty === q ? t.price : t.price / t.qty * q) : 0, price = base;
    p.options.forEach(function (o, i) { var sel = f.querySelector('[name="opt[' + i + ']"]'), c = o.choices.filter(function (x) { return sel && x.label === sel.value; })[0];
      if (c) price += c.pct ? base * c.pct / 100 : c.add * (100 + p.markup) / 100; });
    price = Math.round(price);
    document.getElementById('co-hint').textContent = (q ? 'Catalog price for ' + q.toLocaleString() + ': $' + (price / 100).toFixed(2) : '') + (p.turn ? ' · ' + p.turn : '');
  }
  if (f) { f.product.addEventListener('change', function () { f.qty.value = ''; paint(); }); f.qty.addEventListener('input', function () { hint(); }); paint(); }
  var g = document.getElementById('co-go');
  if (g) {
    var ty = g.querySelector('input[name=type]');
    var show = function () { g.querySelectorAll('[data-type]').forEach(function (d) { d.hidden = d.getAttribute('data-type') !== ty.value; d.querySelectorAll('input,textarea').forEach(function (i) { i.disabled = d.hidden; }); });
      g.querySelectorAll('.co-types button').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-t') === ty.value ? 'true' : 'false'); }); };
    g.querySelectorAll('.co-types button').forEach(function (b) { b.addEventListener('click', function () { ty.value = b.getAttribute('data-t'); show(); }); });
    show();
  }
})();
</script>
<script>
(function () {   // projects: a new one (named in the site's own box), moving an item between them
  var f = document.getElementById('co-pjf');
  var make = function (title, line) { if (!f || !window.TvAsk) return; TvAsk.ask('Name the project', title || '').then(function (v) { if (!v) return; f.elements.title.value = v; f.elements.line.value = line || 0; f.submit(); }); };
  document.querySelectorAll('[data-pj-add]').forEach(function (b) { b.addEventListener('click', function () { make(''); }); });
  document.querySelectorAll('[data-pj-new-line]').forEach(function (b) { b.addEventListener('click', function () { var m = b.closest('details'); if (m) m.open = false; make(b.getAttribute('data-pj-title'), +b.getAttribute('data-pj-new-line')); }); });
  // one file of a proof version, swapped for a new one (same version)
  document.querySelectorAll('input[data-replace-proof]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      if (!inp.files.length || !window.TvUpload) return;
      var box = inp.closest('li') || inp.parentNode;
      TvUpload.send(inp.files, { target: 'order_proof', ctx: { order: <?= (int) $oid ?>, line: 0, replace: +inp.getAttribute('data-replace-proof') }, el: box, csrf: <?= json_encode($csrf) ?> })
        .then(function (r) { TvUpload.reloadHere(TvUpload.summary(r), box); }, function () { inp.value = ''; });
    });
  });
  // a creative item's print-ready file (no print in its project): through the site's one uploader
  document.querySelectorAll('input[data-final]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      if (!inp.files.length || !window.TvUpload) return;
      TvUpload.send(inp.files, { target: 'order_final', ctx: { order: <?= (int) $oid ?>, line: +inp.getAttribute('data-final') }, el: inp.closest('.co-final'), csrf: <?= json_encode($csrf) ?> })
        .then(function (r) { TvUpload.reloadHere(TvUpload.summary(r), inp.closest('.co-final')); }, function () { inp.value = ''; });
    });
  });
})();
</script>
<script>
// Files on this order (proofs, artwork, reference, labels) go through the site's one uploader (js/tv-upload.js,
// decisions/0127): straight to S3, up to 1 GB, with the size checked first, a progress bar and the result beside the item.
(function () {
  if (!window.TvUpload) return;
  var OID = <?= (int) $oid ?>, CSRF = <?= json_encode($csrf) ?>;
  document.querySelectorAll('form[enctype="multipart/form-data"]').forEach(function (f) {
    var inp = f.querySelector('input[type=file]'); if (!inp) return;
    var v = function (n) { var e = f.elements[n]; return e ? e.value : ''; };
    var act = v('do'), line = +v('line') || 0, ip = !!f.elements.ip || !!f.closest('[data-ip]');
    var label = act === 'ship_save' || act === 'pack_save';
    var opts = { target: act === 'proof' ? 'order_proof' : 'order_file', el: f.closest('.co-upf') ? (f.closest('[data-line]') || f) : f, csrf: CSRF, batch: act === 'proof',
      ctx: { order: OID, line: act === 'pack_save' || act === 'order_files' ? 0 : line, kind: label ? 'label' : (act === 'item_files' || act === 'order_files' ? (v('kind') || 'artwork') : '') } };
    var go = function () {
      var files = Array.prototype.slice.call(inp.files || []); if (!files.length) return;
      if (label) opts.ctx.kind = 'label'; else if (act === 'item_files' || act === 'order_files') opts.ctx.kind = v('kind') || 'artwork';
      TvUpload.send(files, opts).then(function (res) {
        inp.value = '';
        if (label) {   // the label is in; now the rest of the form (a pack links to it by its id)
          var h = f.querySelector('input[name=label_id]'); if (!h) { h = document.createElement('input'); h.type = 'hidden'; h.name = 'label_id'; f.appendChild(h); }
          h.value = res[0] && res[0].file ? res[0].file : ''; inp.removeAttribute('name'); f.submit(); return;
        }
        if (ip) history.replaceState(null, '', location.pathname + location.search + '#item=' + line + ':' + (act === 'proof' ? 'proofs' : 'files'));
        TvUpload.reloadHere(TvUpload.summary(res), opts.el);
      }, function () { inp.value = ''; });
    };
    if (f.classList.contains('co-upf')) inp.addEventListener('change', go);
    f.addEventListener('submit', function (ev) { if (!inp.files || !inp.files.length) return; ev.preventDefault(); go(); });
  });
})();
</script>
<script>
(function () {   // an item's Edit icon: its whole setup in one form (name, how many, rate, options, kind, tax)
  var d = document.getElementById('co-edit'); if (!d) return;
  var body = d.querySelector('[data-edit-body]');
  var shut = function () { d.hidden = true; body.innerHTML = ''; document.documentElement.style.overflow = ''; };
  var open = function (lid, fields, err) {
    var t = document.querySelector('template[data-edit-form="' + lid + '"]'); if (!t) return;
    body.innerHTML = ''; body.appendChild(t.content.cloneNode(true));
    var f = body.querySelector('form'), cat = f.querySelector('[data-edit-cat]'), rate = f.querySelector('[data-edit-rate]');
    if (fields) Object.keys(fields).forEach(function (k) { if (k === 'do' || k === 'id' || k === 'line') return; var el = f.elements[k]; if (!el) return; if (el.type === 'checkbox') el.checked = !!fields[k]; else el.value = fields[k]; });
    if (fields && cat && !('catalog' in fields)) cat.checked = false;
    if (fields) { var tx = f.elements.taxable; if (tx && !('taxable' in fields)) tx.checked = false; }
    if (err) { var box = document.createElement('p'); box.className = 'co-msg error'; box.setAttribute('role', 'alert'); box.textContent = err; f.insertBefore(box, f.firstChild); }
    if (rate && cat) { rate.addEventListener('input', function () { cat.checked = false; }); }   // a rate typed is yours: it stays for this run
    d.querySelector('[data-edit-title]').textContent = f.elements.title.value;
    d.hidden = false; document.documentElement.style.overflow = 'hidden';
    setTimeout(function () { (f.querySelector('.co-msg') ? f.elements.qty || f.elements.title : f.elements.title).focus(); }, 30);
  };
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-edit-open]'); if (b) open(b.getAttribute('data-edit-open')); });
  d.querySelector('[data-edit-close]').onclick = shut;
  d.addEventListener('click', function (e) { if (e.target === d) shut(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !d.hidden && !document.querySelector('.tv-ask-lb')) shut(); });
  var FL = window.__coFlash, m = FL && /^edit:(\d+)$/.exec(FL.dlg || '');
  if (m) { var top = document.getElementById('co-flash'); if (top) top.hidden = true; open(m[1], FL.fields || {}, FL.text); }
})();
(function () {   // an item's Project icon: one menu open at a time, closed by a tap anywhere else
  var all = document.querySelectorAll('.co-pjm');
  all.forEach(function (x) { x.addEventListener('toggle', function () { if (x.open) all.forEach(function (y) { if (y !== x) y.open = false; }); }); });
  document.addEventListener('click', function (e) { all.forEach(function (x) { if (x.open && !x.contains(e.target)) x.open = false; }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') all.forEach(function (x) { x.open = false; }); });
})();
</script>
<?php tv_admin_end();
