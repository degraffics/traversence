<?php
// app/lib/Domains.php — a business's own domain on its storefront: Connect your domain (decisions/0139 §3, step 5b;
// 0137 §8). Core and up. Two ways in:
//   - bring your own: the business adds the records we show at its own registrar; we check them;
//   - buy one through us: Name.com's reseller API registers it in the business's name with WHOIS privacy, paid on the
//     plan's card on file (QuickBooks, like a pack), and its records are set through the same API, so nothing is typed.
// Either way, once the domain points at the edge (a small proxy on Fly.io), the edge gets it a certificate through
// Fly's API and passes each visit to trvgo.us with the domain asked for (X-TV-Host), signed with a secret only the edge
// and the site hold (X-TV-Edge). The storefront's address becomes the domain; trvgo.us/<shop> redirects to it.
// Stages: Added → Pointed (DNS answers with the edge) → Checked (certificate asked for) → Live; Failed; Removed.
// The job domains_tick (every 15 minutes) checks what's waiting, re-checks live ones daily, and renews bought domains
// before they run out (charging the card first, then renewing). Email from the domain: its three DKIM records for SES
// are shown beside the storefront's when SES is set up; sending from it comes with businesses' email (0137).
// .env: DOMAINS_MODE off | test | live | mock — changeable in Settings (EnvSettings). test: only our team sees it; the
//       real edge and real DNS, Name.com's sandbox whatever NAMECOM_ENV says, and no card is ever charged. mock: a
//       local test only, refused on the server, like MARKET_PAY_ENV (no Fly, no Name.com). DOMAINS_MODE is only the
//       storefront's own domain (Jason, 2026-11-17: "finding and buying was to be its own process").
//       DOMAIN_SALES_MODE off | test | live | mock — "Domain sales", on the Name.com card: Shop → Domains, the account's
//       Domains tab (buying, renewals, auto-renew) and the wallet's domain charges (AccountDomains, decisions/0169 §1a).
//       Unset is off. test: only our team, Name.com's and QuickBooks' sandboxes; mock refused on the server likewise.
//       FLY_API_TOKEN, FLY_APP (the edge app), FLY_IPV4 (its dedicated IPv4), FLY_IPV6, STOREFRONT_EDGE_KEY (shared with the edge)
//       NAMECOM_USER, NAMECOM_TOKEN (live), NAMECOM_TEST_USER, NAMECOM_TEST_TOKEN (the sandbox's own: the …-test
//       username; without them the live pair is tried), NAMECOM_ENV (sandbox | live), DOMAIN_MARKUP_CENTS (default 500: our margin a year)
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Storefront.php';

final class Domains
{
    public const STATUSES = ['added' => 'Added', 'pointed' => 'DNS pointed', 'checked' => 'Certificate coming', 'live' => 'Live', 'failed' => 'Failed', 'removed' => 'Removed'];
    public const SOURCES = ['own' => 'Brought', 'bought' => 'Bought through us'];
    public const TLDS = ['com', 'net', 'shop', 'store', 'co', 'us', 'biz'];   // offered when a business searches a name
    private const RESERVED = ['traversence.com', 'trvgo.us'];

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM business_domains LIMIT 0'); return true; } catch (Throwable) { return false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }
    private static function env(string $k, string $d = ''): string { $v = trim((string) getenv($k)); return $v !== '' ? $v : $d; }

    /** live | mock | off. Mock only in a local test (MarketPay::localTest), so the server never fakes a purchase. */
    public static function mode(): string
    {
        $m = strtolower(self::env('DOMAINS_MODE', 'off'));
        if ($m === 'mock') { require_once __DIR__ . '/MarketPay.php'; if (!MarketPay::localTest()) { error_log('SECURITY domains: DOMAINS_MODE=mock refused outside a local test.'); return 'off'; } }
        return in_array($m, ['live', 'test', 'mock'], true) ? $m : 'off';
    }

    /** Test mode: only our team; Name.com's sandbox; no card charged. */
    public static function testing(): bool { return self::mode() === 'test'; }

    /** Domain sales (DOMAIN_SALES_MODE, AccountDomains): live | test | mock | off; unset is off. Mock only in a local test. */
    public static function salesMode(): string
    {
        $m = strtolower(self::env('DOMAIN_SALES_MODE', 'off'));
        if ($m === 'mock') { require_once __DIR__ . '/MarketPay.php'; if (!MarketPay::localTest()) { error_log('SECURITY domains: DOMAIN_SALES_MODE=mock refused outside a local test.'); return 'off'; } }
        return in_array($m, ['live', 'test', 'mock'], true) ? $m : 'off';
    }

    private static bool $sales = false;   // set by forSales(): Name.com calls for domain sales, read by DOMAIN_SALES_MODE, not DOMAINS_MODE

    /** Runs $f as a domain sale's call: which Name.com it reaches follows DOMAIN_SALES_MODE (test: the sandbox), never the storefront switch. */
    public static function forSales(callable $f)
    {
        $was = self::$sales; self::$sales = true;
        try { return $f(); } finally { self::$sales = $was; }
    }

    /** No real money: test mode, or a test account signed in (Jason, 2026-11-10: no test makes a real transaction). */
    private static function noRealMoney(): bool
    {
        if (self::$sales ? self::salesMode() === 'test' : self::testing()) return true;   // each switch's own test mode
        require_once __DIR__ . '/QuickBooksPay.php';
        return QuickBooksPay::testHere();   // a test account, or the staging copy
    }

    /** May this person see Connect your domain at all? In test mode, only our team. */
    public static function visibleTo(PDO $pdo, int $uid): bool
    {
        if (!self::testing()) return true;
        require_once __DIR__ . '/Market.php';
        return Market::isStaff($pdo, $uid);
    }

    /** Can a business connect a domain now? [yes, why not] */
    public static function available(): array
    {
        $m = self::mode();
        if ($m === 'mock') return [true, ''];
        if ($m === 'off') return [false, 'Connecting your own domain opens soon: Traversence is finishing its setup.'];
        foreach (['FLY_API_TOKEN', 'FLY_APP', 'FLY_IPV4', 'STOREFRONT_EDGE_KEY'] as $k) if (self::env($k) === '') return [false, 'Connecting your own domain opens soon (' . $k . ' isn\'t set).'];
        return [true, ''];
    }

    /** Can businesses buy a domain through us now? (Name.com set up as well.) */
    public static function canSell(): array
    {
        [$ok, $why] = self::available();
        if (!$ok) return [$ok, $why];
        if (self::mode() === 'live' && self::ncAccount()[3] === 'sandbox') { error_log('domains: DOMAINS_MODE=live with NAMECOM_ENV=sandbox: selling refused (a real charge for a test domain)'); return [false, 'Buying a domain through us opens soon. You can connect one you already own now.']; }   // never charge for a sandbox domain
        if (in_array(self::mode(), ['live', 'test'], true) && self::ncDown()) return [false, self::PAUSED];   // Name.com refusing us: said plainly, before they try
        [, $ncU, $ncT] = self::ncAccount();
        if (in_array(self::mode(), ['live', 'test'], true) && ($ncU === '' || $ncT === '')) return [false, 'Buying a domain through us opens soon. You can connect one you already own now.'];
        return [true, ''];
    }

    /** "Pine-Cafe.com", "https://www.pinecafe.com/menu" → "pinecafe.com"; '' when it isn't a domain. */
    public static function clean(string $d): string
    {
        $d = strtolower(trim($d));
        $d = (string) preg_replace('#^[a-z]+://#', '', $d);
        $d = (string) preg_replace('#[/?\#].*$#', '', $d);
        $d = rtrim((string) preg_replace('/^www\./', '', $d), '.');
        if (strlen($d) > 190 || !preg_match('/^(?=.{4,190}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/', $d)) return '';
        return $d;
    }

    // ---- what a business has --------------------------------------------------------------------------------------

    /** The business's domain (the newest one not removed), or null. */
    public static function forEntity(PDO $pdo, int $e): ?array
    {
        $st = $pdo->prepare("SELECT * FROM business_domains WHERE entity_id = ? AND status <> 'removed' ORDER BY id DESC LIMIT 1"); $st->execute([$e]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function get(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM business_domains WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** The live domain a visit arrived on: [storefront entity id, domain row] or null. */
    public static function byHost(PDO $pdo, string $host): ?array
    {
        $host = self::clean($host);
        if ($host === '') return null;
        $st = $pdo->prepare("SELECT * FROM business_domains WHERE domain = ? AND status = 'live'"); $st->execute([$host]);
        $d = $st->fetch(PDO::FETCH_ASSOC);
        return $d ? [(int) $d['entity_id'], $d] : null;
    }

    /** The records a domain needs: [[name, type, value, what for], …]. The storefront's first, then email's (if SES is set up). */
    public static function records(array $d): array
    {
        $app = self::env('FLY_APP', 'trvgo-edge');
        $out = [['@', 'A', self::env('FLY_IPV4', '203.0.113.10'), 'Your storefront'], ['www', 'CNAME', $app . '.fly.dev', 'Your storefront with www']];
        if (self::env('FLY_IPV6') !== '') array_splice($out, 1, 0, [['@', 'AAAA', self::env('FLY_IPV6'), 'Your storefront (IPv6)']]);
        foreach ((array) json_decode((string) ($d['dkim'] ?? ''), true) as $t) $out[] = [$t . '._domainkey', 'CNAME', $t . '.dkim.amazonses.com', 'Email from your domain'];
        return $out;
    }

    // ---- bringing your own -----------------------------------------------------------------------------------------

    /** Adds a domain the business owns (Added: it now adds our records at its registrar). */
    public static function add(PDO $pdo, int $e, int $uid, string $domain, string $source = 'own', array $extra = []): array
    {
        [$ok, $why] = self::available(); if (!$ok) throw new InvalidArgumentException($why);
        self::mayHave($pdo, $e);
        $d = self::clean($domain);
        if ($d === '') throw new InvalidArgumentException('That doesn\'t look like a domain. Type it like yourshop.com.');
        foreach (self::RESERVED as $r) if ($d === $r || str_ends_with($d, '.' . $r)) throw new InvalidArgumentException('That one is Traversence\'s own.');
        $cur = self::forEntity($pdo, $e);
        if ($cur && $cur['domain'] !== $d) throw new InvalidArgumentException('Your storefront already has ' . $cur['domain'] . '. Disconnect it first.');
        if ($cur) return $cur;
        $st = $pdo->prepare('SELECT id, entity_id, status FROM business_domains WHERE domain = ?'); $st->execute([$d]);
        $old = $st->fetch(PDO::FETCH_ASSOC);
        if ($old && $old['status'] !== 'removed') throw new InvalidArgumentException('Another business on Traversence has connected ' . $d . '. If it\'s yours, write to support@traversence.com.');
        $now = self::now();
        $vals = [$e, $d, $source, $source === 'bought' ? 'pointed' : 'added', (int) ($extra['auto_renew'] ?? 1), (int) ($extra['renew_cents'] ?? 0), $extra['registered_at'] ?? null, $extra['expires_at'] ?? null,
            (string) ($extra['order'] ?? ''), $uid ?: null, $now, $now];
        if ($old) {
            $pdo->prepare("UPDATE business_domains SET entity_id = ?, domain = ?, source = ?, status = ?, auto_renew = ?, renew_cents = ?, registered_at = ?, expires_at = ?, provider_order = ?, created_by = ?, created_at = ?, updated_at = ?,
                cert_status = '', seen = '', last_error = '', dkim = '', email_ok = 0, last_check_at = NULL WHERE id = ?")->execute(array_merge($vals, [(int) $old['id']]));
            $id = (int) $old['id'];
        } else {
            $pdo->prepare('INSERT INTO business_domains (entity_id, domain, source, status, auto_renew, renew_cents, registered_at, expires_at, provider_order, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')->execute($vals);
            $id = (int) $pdo->lastInsertId();
        }
        self::emailRecords($pdo, $id, $d);
        return self::get($pdo, $id);
    }

    /** Storefront & pages (Core and up), and a storefront set up. */
    private static function mayHave(PDO $pdo, int $e): void
    {
        [$ok, $start] = Storefront::allowed($pdo, $e);
        if (!$ok) { require_once __DIR__ . '/Plan.php'; throw new InvalidArgumentException(Plan::upgradeNote($start) . '.'); }
        if (!Storefront::get($pdo, $e)) throw new InvalidArgumentException('Set up your storefront first.');
    }

    /** The DKIM records for email from the domain, when SES is set up (0137 §8): SES makes them for the domain's identity. */
    private static function emailRecords(PDO $pdo, int $id, string $d): void
    {
        try {
            require_once __DIR__ . '/SesMail.php';
            if (SesMail::mode() === 'off') return;
            $acct = SesMail::hasKeys('bulk') ? 'bulk' : (SesMail::hasKeys('personal') ? 'personal' : '');
            if ($acct === '') return;
            if (SesMail::mode() === 'mock' && self::mode() === 'mock') { $tokens = ['mock1' . substr(md5($d), 0, 6), 'mock2' . substr(md5($d), 0, 6), 'mock3' . substr(md5($d), 0, 6)]; }
            else {
                [$code, $res] = SesMail::api($acct, 'POST', '/v2/email/identities', ['EmailIdentity' => $d]);
                if ($code !== 200) [$code, $res] = SesMail::api($acct, 'GET', '/v2/email/identities/' . rawurlencode($d));
                $tokens = (array) ((json_decode((string) $res, true) ?: [])['DkimAttributes']['Tokens'] ?? []);
            }
            if ($tokens) $pdo->prepare('UPDATE business_domains SET dkim = ? WHERE id = ?')->execute([json_encode(array_values($tokens)), $id]);
        } catch (Throwable $x) { error_log('domains dkim ' . $d . ': ' . $x->getMessage()); }
    }

    // ---- checking ---------------------------------------------------------------------------------------------------

    /** What DNS answers for a name: ['A' => [...], 'AAAA' => [...], 'CNAME' => [...]]. Mock: DOMAINS_MOCK_DNS (JSON). */
    public static function lookup(string $name): array
    {
        if (self::mode() === 'mock') { $m = (array) json_decode(self::env('DOMAINS_MOCK_DNS', '{}'), true); return (array) ($m[$name] ?? []); }
        $out = ['A' => [], 'AAAA' => [], 'CNAME' => []];
        foreach ([DNS_A => 'A', DNS_AAAA => 'AAAA', DNS_CNAME => 'CNAME'] as $t => $k) {
            $r = @dns_get_record($name, $t) ?: [];
            foreach ($r as $x) $out[$k][] = strtolower(rtrim((string) ($x['ip'] ?? $x['ipv6'] ?? $x['target'] ?? ''), '.'));
        }
        return $out;
    }

    /** Does the name answer with the edge? (an A or AAAA of the edge, or a CNAME to it) */
    public static function pointsHere(array $dns): bool
    {
        $v4 = self::env('FLY_IPV4', '203.0.113.10'); $v6 = strtolower(self::env('FLY_IPV6')); $app = strtolower(self::env('FLY_APP', 'trvgo-edge')) . '.fly.dev';
        return in_array($v4, (array) ($dns['A'] ?? []), true) || ($v6 !== '' && in_array($v6, (array) ($dns['AAAA'] ?? []), true)) || in_array($app, (array) ($dns['CNAME'] ?? []), true);
    }

    /**
     * Moves a domain on as far as it can: DNS → certificate → Live. Returns the row. A live domain whose DNS has moved
     * away for 3 days is Failed (its storefront goes back to trvgo.us); the business is told in its Pulse.
     */
    public static function check(PDO $pdo, int $id): array
    {
        $d = self::get($pdo, $id);
        if (!$d || $d['status'] === 'removed') throw new InvalidArgumentException('That domain isn\'t connected.');
        $now = self::now(); $err = '';
        $apex = self::lookup($d['domain']); $www = self::lookup('www.' . $d['domain']);
        $okApex = self::pointsHere($apex); $okWww = self::pointsHere($www);
        $seen = trim(implode(' ', array_merge((array) ($apex['A'] ?? []), (array) ($apex['CNAME'] ?? []))));
        $status = (string) $d['status']; $cert = (string) $d['cert_status'];
        if (!$okApex && !$okWww) {
            if ($status === 'live') {
                $since = strtotime((string) ($d['last_ok_at'] ?? $d['updated_at']));
                if ($since < strtotime('-3 days')) { $status = 'failed'; $err = 'Its DNS no longer points at your storefront.'; self::unlink($pdo, $d); }
            } elseif ($status !== 'failed') { $status = 'added'; $err = $seen !== '' ? 'It answers with ' . mb_substr($seen, 0, 120) . ', not your storefront yet. DNS changes can take a few hours.' : 'No answer yet. DNS changes can take a few hours.'; }
        } else {
            if (in_array($status, ['added', 'pointed', 'failed'], true)) $status = 'pointed';
            try {
                foreach (array_filter([$okApex ? $d['domain'] : '', $okWww ? 'www.' . $d['domain'] : '']) as $h) $cert = self::certificate($h);
                if ($cert === 'ready' && $status !== 'live') { $status = 'live'; self::link($pdo, $d); }
                elseif ($status !== 'live') $status = 'checked';
            } catch (RuntimeException $x) { $err = 'The certificate: ' . $x->getMessage(); }
            if ($status === 'live') $pdo->prepare('UPDATE business_domains SET last_ok_at = ? WHERE id = ?')->execute([$now, $id]);
        }
        $email = 0;
        foreach ((array) json_decode((string) $d['dkim'], true) as $t) { $email = in_array($t . '.dkim.amazonses.com', (array) (self::lookup($t . '._domainkey.' . $d['domain'])['CNAME'] ?? []), true) ? 1 : 0; if (!$email) break; }
        $pdo->prepare('UPDATE business_domains SET status = ?, cert_status = ?, seen = ?, email_ok = ?, last_error = ?, last_check_at = ?, updated_at = IF(status <> ?, ?, updated_at) WHERE id = ?')
            ->execute([$status, $cert, mb_substr($seen, 0, 300), $email, mb_substr($err, 0, 300), $now, $status, $now, $id]);
        return self::get($pdo, $id);
    }

    /** The domain becomes the storefront's address. */
    private static function link(PDO $pdo, array $d): void
    {
        $pdo->prepare('UPDATE storefronts SET domain = ?, updated_at = ? WHERE entity_id = ?')->execute([$d['domain'], self::now(), (int) $d['entity_id']]);
    }

    private static function unlink(PDO $pdo, array $d): void
    {
        $pdo->prepare("UPDATE storefronts SET domain = '', updated_at = ? WHERE entity_id = ? AND domain = ?")->execute([self::now(), (int) $d['entity_id'], $d['domain']]);
    }

    /** Disconnects it: the storefront goes back to trvgo.us, the edge forgets its certificate. A bought domain stays the business's. */
    public static function disconnect(PDO $pdo, int $e): void
    {
        $d = self::forEntity($pdo, $e);
        if (!$d) return;
        self::unlink($pdo, $d);
        foreach ([$d['domain'], 'www.' . $d['domain']] as $h) { try { self::forgetCertificate($h); } catch (Throwable $x) { error_log('domains forget cert ' . $h . ': ' . $x->getMessage()); } }
        $pdo->prepare("UPDATE business_domains SET status = 'removed', auto_renew = 0, updated_at = ? WHERE id = ?")->execute([self::now(), (int) $d['id']]);
    }

    // ---- the edge's certificates (Fly.io's API) ------------------------------------------------------------------

    /** Asks the edge for a certificate for a hostname (once), and how it stands: 'ready', 'pending'. */
    public static function certificate(string $host): string
    {
        if (self::mode() === 'mock') return in_array($host, (array) json_decode(self::env('DOMAINS_MOCK_PENDING', '[]'), true), true) ? 'pending' : 'ready';
        $app = self::env('FLY_APP');
        $q = 'query($app: String!, $h: String!) { app(name: $app) { id certificate(hostname: $h) { clientStatus configured } } }';
        $r = self::fly($q, ['app' => $app, 'h' => $host]);
        $c = $r['data']['app']['certificate'] ?? null;
        if (!$c) {
            $m = 'mutation($appId: ID!, $h: String!) { addCertificate(appId: $appId, hostname: $h) { certificate { clientStatus configured } } }';
            $r = self::fly($m, ['appId' => (string) ($r['data']['app']['id'] ?? $app), 'h' => $host]);
            $c = $r['data']['addCertificate']['certificate'] ?? null;
            if (!$c) throw new RuntimeException('Fly didn\'t take it: ' . mb_substr((string) ($r['errors'][0]['message'] ?? 'no answer'), 0, 160));
        }
        return strtolower((string) ($c['clientStatus'] ?? '')) === 'ready' ? 'ready' : 'pending';
    }

    public static function forgetCertificate(string $host): void
    {
        if (self::mode() === 'mock') return;
        $r = self::fly('query($app: String!) { app(name: $app) { id } }', ['app' => self::env('FLY_APP')]);
        self::fly('mutation($appId: ID!, $h: String!) { deleteCertificate(appId: $appId, hostname: $h) { app { name } } }', ['appId' => (string) ($r['data']['app']['id'] ?? ''), 'h' => $host]);
    }

    private static function fly(string $query, array $vars): array
    {
        require_once __DIR__ . '/StagingGate.php';
        if (($w = StagingGate::hold('https://api.fly.io/graphql', 'Fly: a storefront domain\'s certificate')) !== null) throw new RuntimeException($w);   // staging's answer (decisions/0165 §1); null at once on live
        $ch = curl_init('https://api.fly.io/graphql');
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . self::env('FLY_API_TOKEN'), 'Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode(['query' => $query, 'variables' => $vars])]);
        $raw = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($raw === false || $code >= 500) throw new RuntimeException('Fly didn\'t answer. It\'s tried again on the next check.');
        $j = json_decode((string) $raw, true) ?: [];
        if ($code >= 400) throw new RuntimeException('Fly answered ' . $code . ': ' . mb_substr((string) ($j['errors'][0]['message'] ?? ''), 0, 160));
        return $j;
    }

    // ---- buying through Name.com ----------------------------------------------------------------------------------

    /** Our price a year for Name.com's cost (dollars): rounded up to the cent, plus our margin. */
    public static function price(float $costDollars): int
    {
        return (int) ceil($costDollars * 100) + max(0, (int) self::env('DOMAIN_MARKUP_CENTS', '500'));
    }

    /**
     * Names to offer for what the business typed: [[domain, available, price cents a year, renewal cents, cost dollars,
     * premium]]. "pine cafe" → pinecafe.com, .net, .shop…; "pinecafe.co" → that one first.
     */
    public static function search(string $typed): array
    {
        [$ok, $why] = self::canSell(); if (!$ok) throw new InvalidArgumentException($why);
        $t = strtolower(trim($typed));
        $full = self::clean($t);
        $base = (string) preg_replace('/[^a-z0-9-]/', '', $full !== '' ? explode('.', $full)[0] : str_replace(' ', '', $t));
        if (strlen($base) < 2) throw new InvalidArgumentException('Type the name you\'d like, like pinecafe.');
        $names = array_values(array_unique(array_merge($full !== '' ? [$full] : [], array_map(fn ($x) => $base . '.' . $x, self::TLDS))));
        if (self::mode() === 'mock') {
            $taken = (array) json_decode(self::env('DOMAINS_MOCK_TAKEN', '[]'), true);
            return array_map(fn ($n) => [$n, !in_array($n, $taken, true), self::price(str_ends_with($n, '.com') ? 12.99 : 19.99), self::price(str_ends_with($n, '.com') ? 14.99 : 21.99), str_ends_with($n, '.com') ? 12.99 : 19.99, false], $names);
        }
        $r = self::namecom('POST', '/v4/domains:checkAvailability', ['domainNames' => $names]);
        $out = [];
        foreach ((array) ($r['results'] ?? []) as $x) {
            $cost = (float) ($x['purchasePrice'] ?? 0);
            $out[] = [(string) $x['domainName'], !empty($x['purchasable']), $cost > 0 ? self::price($cost) : 0, isset($x['renewalPrice']) ? self::price((float) $x['renewalPrice']) : 0, $cost, !empty($x['premium'])];
        }
        return $out;
    }

    /**
     * Buys a domain for the business and connects it: the price is checked again (never more than it was shown), the
     * plan's card is charged, Name.com registers it in the business's name (WHOIS privacy on), then its records are set.
     * If registering fails, the charge is refunded. $who: the registrant (first, last, email, phone, address1, city,
     * state, zip; the business's name as the organization).
     */
    public static function buy(PDO $pdo, int $e, int $uid, string $domain, int $shownCents, array $who, string $org): array
    {
        [$ok, $why] = self::canSell(); if (!$ok) throw new InvalidArgumentException($why);
        self::mayHave($pdo, $e);
        $d = self::clean($domain);
        if ($d === '') throw new InvalidArgumentException('That doesn\'t look like a domain.');
        if ($cur = self::forEntity($pdo, $e)) throw new InvalidArgumentException('Your storefront already has ' . $cur['domain'] . '. Disconnect it first.');
        $c = self::contact($who, $org);
        $hit = null; foreach (self::search($d) as $x) if ($x[0] === $d) { $hit = $x; break; }
        if (!$hit || !$hit[1]) throw new InvalidArgumentException($d . ' isn\'t available any more. Search again.');
        if ($hit[5]) throw new InvalidArgumentException($d . ' is a premium name. Choose another, or write to support@traversence.com.');
        if ($hit[2] > $shownCents) throw new InvalidArgumentException('Its price changed to ' . self::usd($hit[2]) . ' a year. Search again to see it.');
        require_once __DIR__ . '/Billing.php';
        $key = 'domain-' . $d . '-' . date('Ymd');
        $charge = self::mode() === 'mock' ? 'MOCK-DOMAIN-' . substr(md5($d), 0, 6) : (self::noRealMoney() ? 'TEST-NOT-CHARGED'
            : Billing::chargeExtra($pdo, 'listing', $e, 'domain', [[$d . ': domain name, 1 year (with WHOIS privacy)', $hit[2]]], $key));
        try {
            if (self::mode() === 'mock') { $reg = ['order' => 'MOCK-' . substr(md5($d), 0, 8), 'expires' => date('Y-m-d H:i:s', strtotime('+1 year'))]; }
            else {
                $r = self::namecom('POST', '/v4/domains', ['domain' => ['domainName' => $d, 'privacyEnabled' => true, 'contacts' => ['registrant' => $c, 'admin' => $c, 'tech' => $c, 'billing' => $c]],
                    'purchasePrice' => $hit[4], 'years' => 1]);
                if (empty($r['domain']['domainName'])) throw new RuntimeException('Name.com didn\'t register it: ' . mb_substr((string) ($r['message'] ?? $r['details'] ?? 'no answer'), 0, 160));
                $reg = ['order' => (string) ($r['order'] ?? ''), 'expires' => !empty($r['domain']['expireDate']) ? date('Y-m-d H:i:s', strtotime((string) $r['domain']['expireDate'])) : date('Y-m-d H:i:s', strtotime('+1 year'))];
            }
        } catch (Throwable $x) {
            if (self::mode() === 'live') { try { require_once __DIR__ . '/QuickBooksPay.php'; QuickBooksPay::refundCharge($pdo, $charge, $hit[2], 'Domain ' . $d . ' couldn\'t be registered', $key . '-refund'); }
                catch (Throwable $y) { error_log('SECURITY domains: ' . $d . ' charged (' . $charge . ') but not registered or refunded: ' . $y->getMessage()); throw new RuntimeException('It couldn\'t be registered, and the refund didn\'t go through: our team has been told and will refund you by hand.'); } }
            throw new RuntimeException('It couldn\'t be registered (' . $x->getMessage() . ').' . (self::mode() === 'live' ? ' Your card was refunded.' : ' Nothing was charged (test).'));
        }
        $row = self::add($pdo, $e, $uid, $d, 'bought', ['auto_renew' => 1, 'renew_cents' => $hit[3] ?: $hit[2], 'registered_at' => self::now(), 'expires_at' => $reg['expires'], 'order' => $reg['order']]);
        self::setRecords($row);
        return self::check($pdo, (int) $row['id']);
    }

    /** The storefront's and email's records, set at Name.com for a bought domain. */
    private static function setRecords(array $d): void
    {
        if (self::mode() === 'mock') return;
        foreach (self::records($d) as [$name, $type, $value]) {
            try { self::namecom('POST', '/v4/domains/' . rawurlencode($d['domain']) . '/records', ['host' => $name === '@' ? '' : $name, 'type' => $type, 'answer' => $value, 'ttl' => 300]); }
            catch (Throwable $x) { error_log('domains record ' . $d['domain'] . ' ' . $name . ': ' . $x->getMessage()); }
        }
    }

    /** The registrant as Name.com takes it. */
    public static function contact(array $w, string $org): array
    {
        $t = fn ($k) => trim((string) ($w[$k] ?? ''));
        foreach (['first' => 'first name', 'last' => 'last name', 'email' => 'email', 'phone' => 'phone', 'address1' => 'street address', 'city' => 'town', 'state' => 'state', 'zip' => 'ZIP code'] as $k => $l)
            if ($t($k) === '') throw new InvalidArgumentException('Add the registrant\'s ' . $l . ': the domain is registered in your name.');
        if (!filter_var($t('email'), FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('The registrant\'s email doesn\'t look right.');
        $digits = (string) preg_replace('/\D/', '', $t('phone'));
        if (strlen($digits) === 10) $digits = '1' . $digits;
        if (strlen($digits) !== 11) throw new InvalidArgumentException('The phone should be a US number with its area code.');
        return ['firstName' => mb_substr($t('first'), 0, 60), 'lastName' => mb_substr($t('last'), 0, 60), 'companyName' => mb_substr($org, 0, 120), 'address1' => mb_substr($t('address1'), 0, 120),
            'city' => mb_substr($t('city'), 0, 60), 'state' => strtoupper(mb_substr($t('state'), 0, 2)), 'zip' => mb_substr($t('zip'), 0, 10), 'country' => 'US',
            'phone' => '+1.' . substr($digits, 1), 'email' => $t('email')];
    }

    /** Auto-renew on or off (a bought domain). Off: it runs out on its date unless renewed or moved. */
    public static function setAutoRenew(PDO $pdo, int $e, bool $on): void
    {
        $d = self::forEntity($pdo, $e);
        if (!$d || $d['source'] !== 'bought') throw new InvalidArgumentException('Only a domain bought through us renews here.');
        $pdo->prepare('UPDATE business_domains SET auto_renew = ?, updated_at = ? WHERE id = ?')->execute([$on ? 1 : 0, self::now(), (int) $d['id']]);
    }

    /** Moving a bought domain to another registrar: unlocks it and returns its transfer code (shown once to the business). */
    public static function transferCode(PDO $pdo, int $e): string
    {
        $d = self::forEntity($pdo, $e);
        if (!$d || $d['source'] !== 'bought') throw new InvalidArgumentException('Only a domain bought through us moves from here.');
        if (self::mode() === 'mock') return 'MOCK-AUTH-' . strtoupper(substr(md5($d['domain']), 0, 8));
        self::namecom('POST', '/v4/domains/' . rawurlencode($d['domain']) . ':unlock', []);
        $r = self::namecom('GET', '/v4/domains/' . rawurlencode($d['domain']) . ':getAuthCode', null);
        $code = (string) ($r['authCode'] ?? '');
        if ($code === '') throw new RuntimeException('Name.com didn\'t give the code. Try again, or write to support@traversence.com.');
        return $code;
    }

    /** Renews a bought domain for a year: the card first, then Name.com. Returns what happened, in words. */
    public static function renew(PDO $pdo, array $d): string
    {
        if ($d['source'] !== 'bought' || !(int) $d['auto_renew']) return 'skipped';
        require_once __DIR__ . '/Billing.php';
        $key = 'domain-renew-' . $d['domain'] . '-' . substr((string) $d['expires_at'], 0, 10);
        $pdo->prepare('UPDATE business_domains SET renew_tried_at = ? WHERE id = ?')->execute([self::now(), (int) $d['id']]);
        try {
            if (self::mode() !== 'mock') {
                if (!self::testing()) Billing::chargeExtra($pdo, 'listing', (int) $d['entity_id'], 'domain', [[$d['domain'] . ': domain name renewal, 1 year', (int) $d['renew_cents']]], $key);
                $cost = max(0, ((int) $d['renew_cents'] - max(0, (int) self::env('DOMAIN_MARKUP_CENTS', '500')))) / 100;
                self::namecom('POST', '/v4/domains/' . rawurlencode($d['domain']) . ':renew', ['purchasePrice' => $cost, 'years' => 1]);
            }
        } catch (Throwable $x) {
            $pdo->prepare('UPDATE business_domains SET last_error = ? WHERE id = ?')->execute([mb_substr('Renewing: ' . $x->getMessage(), 0, 300), (int) $d['id']]);
            return 'failed';
        }
        $pdo->prepare("UPDATE business_domains SET expires_at = DATE_ADD(expires_at, INTERVAL 1 YEAR), last_error = '', updated_at = ? WHERE id = ?")->execute([self::now(), (int) $d['id']]);
        return 'renewed';
    }

    /** Which Name.com we talk to, and as whom: the sandbox has its own username (…-test) and token (NAMECOM_TEST_*). */
    private static ?bool $sandbox = null;   // set by asSandbox(): a test account's or a sandbox domain's call, whoever is signed in

    /** Runs Name.com calls in the sandbox ($on) or as configured, for a call made on someone's behalf (the domains job, an account's sandbox domain). */
    public static function asSandbox(bool $on, callable $f)
    {
        $was = self::$sandbox; self::$sandbox = $on ? true : null;
        try { return $f(); } finally { self::$sandbox = $was; }
    }

    /** Is Name.com's sign-in set for the account calls go to now (the sandbox's own pair, or the live one)? */
    public static function ncReady(): bool { [, $u, $t] = self::ncAccount(); return $u !== '' && $t !== ''; }

    /** Which Name.com this call goes to: 'sandbox' or 'live' (the live + sandbox guard, canSell, reads the same). */
    public static function ncEnv(): string { return self::ncAccount()[3]; }

    private static function ncAccount(): array
    {
        $sandbox = self::$sandbox === true || self::env('NAMECOM_ENV', 'sandbox') !== 'live' || self::noRealMoney();   // test mode or a test account: always the sandbox
        $user = $sandbox ? self::env('NAMECOM_TEST_USER', self::env('NAMECOM_USER')) : self::env('NAMECOM_USER');
        $token = $sandbox ? self::env('NAMECOM_TEST_TOKEN', self::env('NAMECOM_TOKEN')) : self::env('NAMECOM_TOKEN');
        return [$sandbox ? 'https://api.dev.name.com' : 'https://api.name.com', $user, $token, $sandbox ? 'sandbox' : 'live'];
    }

    private const NC_DOWN = 'domains:namecom_down';   // market_settings: the last time Name.com refused us, while it lasts

    /** Name.com refusing our sign-in, if it is: ['at', 'error', 'env', 'user'] or null. Shown to our team (Pulse), never to businesses. */
    public static function ncDown(): ?array
    {
        try { $st = Database::connection()->prepare('SELECT v FROM market_settings WHERE k = ?'); $st->execute([self::NC_DOWN]); $v = json_decode((string) $st->fetchColumn(), true); return is_array($v) ? $v : null; }
        catch (Throwable) { return null; }
    }

    private static function ncMark(?array $v): void
    {
        try {
            $pdo = Database::connection();
            if ($v === null) $pdo->prepare('DELETE FROM market_settings WHERE k = ?')->execute([self::NC_DOWN]);
            else $pdo->prepare('INSERT INTO market_settings (k, v, updated_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = VALUES(updated_at)')->execute([self::NC_DOWN, json_encode($v), self::now()]);
        } catch (Throwable $x) { error_log('domains namecom state: ' . $x->getMessage()); }
    }

    /** Asks Name.com whether it accepts our sign-in now (Pulse's Check again, and the 15-minute job while it's refusing). */
    public static function ncCheck(): string
    {
        self::namecom('GET', '/v4/hello', null);
        return 'Name.com accepts our sign-in again (' . self::ncAccount()[3] . '): buying domains is open.';
    }

    /** A Name.com API call for another library (AccountDomains: an account's own domains, decisions/0169 §1a). */
    public static function api(string $method, string $path, ?array $body): array { return self::forSales(fn () => self::namecom($method, $path, $body)); }

    private static function namecom(string $method, string $path, ?array $body): array
    {
        [$base, $user, $token, $which] = self::ncAccount();
        require_once __DIR__ . '/StagingGate.php';
        if (($w = StagingGate::hold($base . $path, 'Name.com: ' . $method . ' ' . strtok($path, ':'))) !== null) throw new RuntimeException($w);   // staging's answer (decisions/0165 §1); null at once on live
        $ch = curl_init($base . $path);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30,
            CURLOPT_USERPWD => $user . ':' . $token, CURLOPT_HTTPHEADER => ['Content-Type: application/json']]);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body ?: new stdClass()));
        $raw = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($raw === false) throw new RuntimeException('Name.com isn\'t answering right now. Try again in a few minutes.');
        $j = json_decode((string) $raw, true) ?: [];
        if ($code === 401 || $code === 403) {   // our sign-in refused: our team fixes it; the business is told plainly (Jason, 2026-11-03)
            $why = mb_substr((string) ($j['message'] ?? 'error ' . $code) . (isset($j['details']) ? ' (' . $j['details'] . ')' : ''), 0, 200);
            self::ncMark(['at' => (self::ncDown()['at'] ?? self::now()), 'last' => self::now(), 'error' => $why, 'code' => $code, 'env' => $which, 'user' => $user]);
            error_log('domains: Name.com refused our sign-in (' . $which . ', ' . $user . '): ' . $why);
            throw new RuntimeException(self::PAUSED);
        }
        if ($code >= 500) throw new RuntimeException('Name.com isn\'t answering right now. Try again in a few minutes.');
        if ($code >= 400) throw new RuntimeException('Name.com: ' . mb_substr((string) ($j['message'] ?? 'error ' . $code) . (isset($j['details']) ? ' (' . $j['details'] . ')' : ''), 0, 200));
        if (self::ncDown()) self::ncMark(null);   // answering again
        return $j;
    }

    public const PAUSED = 'Buying a domain through us is paused for a moment: our team has been told and is fixing it. You can connect a domain you already own meanwhile.';

    public static function usd(int $c): string { return '$' . number_format($c / 100, 2); }

    // ---- the job -----------------------------------------------------------------------------------------------------

    /** Every 15 minutes: domains waiting are checked; live ones once a day; bought ones renewed 14 days ahead. [checked, live now, renewed, failed] */
    public static function tick(PDO $pdo): array
    {
        if (!self::ready($pdo) || self::mode() === 'off') return [0, 0, 0, 0];
        $checked = 0; $live = 0; $renewed = 0; $failed = 0;
        $st = $pdo->prepare("SELECT id, status FROM business_domains WHERE (status IN ('added','pointed','checked') AND (last_check_at IS NULL OR last_check_at < ?) AND created_at > ?)
            OR (status = 'live' AND (last_check_at IS NULL OR last_check_at < ?)) LIMIT 100");
        $st->execute([date('Y-m-d H:i:s', strtotime('-10 minutes')), date('Y-m-d H:i:s', strtotime('-30 days')), date('Y-m-d H:i:s', strtotime('-1 day'))]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            try { $was = $r['status']; $d = self::check($pdo, (int) $r['id']); $checked++; if ($d['status'] === 'live' && $was !== 'live') $live++; if ($d['status'] === 'failed' && $was !== 'failed') $failed++; }
            catch (Throwable $x) { error_log('domains check ' . $r['id'] . ': ' . $x->getMessage()); }
        }
        $st = $pdo->prepare("SELECT * FROM business_domains WHERE source = 'bought' AND auto_renew = 1 AND status <> 'removed' AND expires_at < ? AND (renew_tried_at IS NULL OR renew_tried_at < ?) LIMIT 50");
        $st->execute([date('Y-m-d H:i:s', strtotime('+14 days')), date('Y-m-d H:i:s', strtotime('-1 day'))]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $d) if (self::renew($pdo, $d) === 'renewed') $renewed++;
        if (self::ncDown()) { try { self::ncCheck(); } catch (Throwable $x) {} }   // refused before: ask again, so buying reopens by itself once it's fixed
        return [$checked, $live, $renewed, $failed];
    }

    /** For the admin's Custom domains: every domain with its business's name. */
    public static function all(PDO $pdo, string $status = '', string $q = ''): array
    {
        $w = ['1 = 1']; $a = [];
        if (isset(self::STATUSES[$status])) { $w[] = 'd.status = ?'; $a[] = $status; } else $w[] = "d.status <> 'removed'";
        if (($q = trim($q)) !== '') { $w[] = '(d.domain LIKE ? OR e.name LIKE ?)'; array_push($a, "%$q%", "%$q%"); }
        $st = $pdo->prepare('SELECT d.*, e.name FROM business_domains d LEFT JOIN entities e ON e.id = d.entity_id WHERE ' . implode(' AND ', $w) . ' ORDER BY d.updated_at DESC LIMIT 300');
        $st->execute($a);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
