<?php
// app/lib/AccountDomains.php — domains as a standalone product (decisions/0169 §1a): Shop → Domains and the account's
// Domains tab. A domain belongs to the account that bought it, a member or a business; no storefront or plan needed.
//   - Shop → Domains: search a name (the typed name and .com, .net, .shop, .store, .co, .us, .biz) with our price a year
//     (Name.com's cost + DOMAIN_MARKUP_CENTS; premium names referred to us), into the one cart with its registrant (18 or
//     older, real contact details: ICANN's rule, Name.com emails them to confirm).
//   - Paying is an order (0098): the card from the account's wallet (0166 §6a) is charged first, then Name.com registers
//     it in the buyer's name with WHOIS privacy; one that can't be registered is refunded. Two catalog products: Domain
//     Purchase and Domain Renewal, each line carrying Name.com as its vendor and Name.com's actual cost, so 0166's ledger
//     can post the cost of goods (the margin is the markup). No account is chosen here: the receipt uses the product's
//     QuickBooks item once 0166 §4 links one, else today's item.
//   - The Domains tab: expiry, Renew now, auto-renew (charged on the domain's wallet card two weeks ahead; a decline is
//     tried again 3 and 7 days later, a new card at once), where it points (forward to an address, its own DNS records,
//     or nameservers elsewhere), the email records when SES sends for it, transfer away (unlocked, the code shown once),
//     its history, and Something isn't right (a support ticket). A domain brought from elsewhere is listed for pointing
//     only: its records are set where it's registered.
//   - What goes wrong is on the order: Needs attention and a Pulse case (Try again, Refund, Email the owner).
// The storefront's own domain (business_domains, Domains.php, 0139) is untouched: it's listed on a business's tab,
// read only. Joining a storefront to the account's domains is the Storefront app's (0169 app 6).
// Its own switch (Jason, 2026-11-17: "finding and buying was to be its own process"): DOMAIN_SALES_MODE ("Domain sales",
// on the Name.com card) alone opens Shop → Domains, the tab's buying, renewals and auto-renew, and the wallet's domain
// charges; unset is off. DOMAINS_MODE is only the storefront's own domain. No real money in a test: DOMAIN_SALES_MODE=test,
// a test account, or the staging copy go to Name.com's sandbox and pay in QuickBooks' sandbox; DOMAIN_SALES_MODE=live
// with NAMECOM_ENV=sandbox refuses to sell. Every Name.com call passes StagingGate::hold() and runs as a sale's call
// (Domains::api → Domains::forSales).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Domains.php';
require_once __DIR__ . '/Wallet.php';

final class AccountDomains
{
    public const STATUSES = ['active' => 'Active', 'expired' => 'Expired', 'transferred' => 'Moved away', 'removed' => 'Removed'];
    public const POINTS = ['' => 'Not pointed anywhere yet', 'forward' => 'Forwards to another address', 'dns' => 'Its own DNS records', 'nameservers' => 'Nameservers set elsewhere'];
    public const SKUS = ['purchase' => ['DOMAIN-PURCHASE', 'Domain Purchase', 'A domain name registered through Name.com for one year, in the buyer\'s name with WHOIS privacy. Priced per sale: Name.com\'s cost plus our markup. Sold in Shop → Domains.'],
                         'renewal' => ['DOMAIN-RENEWAL', 'Domain Renewal', 'A year\'s renewal of a domain registered through us (Renew now or auto-renew). Priced per sale: Name.com\'s cost plus our markup.']];
    public const RECORD_TYPES = ['A', 'AAAA', 'CNAME', 'MX', 'TXT'];
    public const NAMECOM_NS = ['ns1.name.com', 'ns2.name.com', 'ns3.name.com', 'ns4.name.com'];
    public const RENEW_AHEAD_DAYS = 14;
    public const RETRY_DAYS = [3, 7];

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r !== null) return $r;
        try { $pdo->query('SELECT 1 FROM account_domains LIMIT 0'); $pdo->query('SELECT 1 FROM domain_cart LIMIT 0'); return $r = Wallet::ready($pdo); } catch (Throwable) { return $r = false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }
    private static function env(string $k, string $d = ''): string { $v = trim((string) getenv($k)); return $v !== '' ? $v : $d; }
    public static function usd(int $c): string { return '$' . number_format($c / 100, 2); }

    // ---- who may, and whether it's open --------------------------------------------------------------------------

    /** Domain sales' switch, DOMAIN_SALES_MODE: live | test | mock | off (unset: off). Not the storefront's switch. */
    public static function mode(): string { return Domains::salesMode(); }

    /** Domain sales in test mode: our team only; Name.com's sandbox and QuickBooks' sandbox. */
    public static function testing(): bool { return self::mode() === 'test'; }

    /** May this person see domain sales at all? In test mode, only our team. */
    public static function visibleTo(PDO $pdo, int $uid): bool
    {
        if (!self::testing()) return true;
        require_once __DIR__ . '/Market.php';
        return Market::isStaff($pdo, $uid);
    }

    /** Is Shop → Domains open for this person? [yes, why not]. Test mode: our team only. */
    public static function open(PDO $pdo, int $uid): array
    {
        if (!self::ready($pdo)) return [false, 'Buying domains opens once its database update has run (within the hour).'];
        $m = self::mode();
        if ($m === 'off') return [false, 'Buying a domain through Traversence opens soon.'];
        if (!self::visibleTo($pdo, $uid)) return [false, 'Buying a domain through Traversence opens soon.'];
        if ($m === 'mock') return [true, ''];
        [$ncEnv, $ncReady] = Domains::forSales(fn () => [Domains::ncEnv(), Domains::ncReady()]);   // the Name.com a sale reaches now
        if ($m === 'live' && !self::sandboxed($pdo, '', 0) && $ncEnv === 'sandbox') { error_log('domains: DOMAIN_SALES_MODE=live with NAMECOM_ENV=sandbox: selling refused (a real charge for a test domain)'); return [false, 'Buying a domain through Traversence opens soon.']; }
        if (Domains::ncDown()) return [false, Domains::PAUSED];
        if (!$ncReady) return [false, 'Buying a domain through Traversence opens soon.'];
        return [true, ''];
    }

    /** Test mode, a test account, or staging: Name.com's sandbox and QuickBooks' sandbox (no real money). */
    public static function sandboxed(PDO $pdo, string $type, int $id): bool
    {
        if (self::testing()) return true;
        require_once __DIR__ . '/QuickBooksPay.php';
        if (QuickBooksPay::testHere()) return true;
        return $type !== '' && Wallet::testOwner($pdo, $type, $id);
    }

    /** Runs $f with Name.com and the card in the right place for this account. */
    private static function inPlace(PDO $pdo, string $type, int $id, callable $f, ?bool $sandbox = null)
    {
        $sb = $sandbox ?? self::sandboxed($pdo, $type, $id);
        return Domains::asSandbox($sb, fn () => Wallet::asSandbox($sb, $f));
    }

    /** May this person buy for, and manage, the account's domains? A member their own; a business: Domain (edit). Paying: the wallet's rule too. */
    public static function canManage(PDO $pdo, int $uid, string $type, int $id): bool
    {
        if ($uid <= 0) return false;
        if ($type === 'user') return $uid === $id;
        if ($type !== 'listing') return false;
        require_once __DIR__ . '/Team.php';
        return Team::can($pdo, $uid, $id, 'domain', 'edit');
    }

    public static function canPay(PDO $pdo, int $uid, string $type, int $id): bool
    {
        return self::canManage($pdo, $uid, $type, $id) && Wallet::canManage($pdo, $uid, $type, $id);
    }

    /** The account's name, as its tab and emails say it. */
    public static function ownerName(PDO $pdo, string $type, int $id): string
    {
        require_once __DIR__ . '/Billing.php';
        try { return (string) Billing::owner($pdo, $type, $id)['name']; } catch (Throwable) { return ''; }
    }

    // ---- searching ---------------------------------------------------------------------------------------------------

    /**
     * Names to offer for what was typed: [{domain, ok, premium, price, renew, cost, renew_cost}], cents a year. Premium
     * names show, marked, and are referred to us rather than sold.
     */
    public static function search(PDO $pdo, string $typed, string $type = '', int $id = 0): array
    {
        $t = strtolower(trim($typed));
        $full = Domains::clean($t);
        $base = (string) preg_replace('/[^a-z0-9-]/', '', $full !== '' ? explode('.', $full)[0] : str_replace(' ', '', $t));
        $base = trim($base, '-');
        if (strlen($base) < 2) throw new InvalidArgumentException('Type the name you\'d like, like pinecafe.');
        if (strlen($base) > 63) throw new InvalidArgumentException('That name is longer than a domain can be (63 letters before the dot).');
        $names = array_values(array_unique(array_merge($full !== '' && self::reservedWhy($full) === '' ? [$full] : [], array_map(fn ($x) => $base . '.' . $x, Domains::TLDS))));
        $names = array_values(array_filter($names, fn ($n) => self::reservedWhy($n) === ''));
        $mark = max(0, (int) self::env('DOMAIN_MARKUP_CENTS', '500'));
        if (self::mode() === 'mock') {
            $taken = (array) json_decode(self::env('DOMAINS_MOCK_TAKEN', '[]'), true);
            $prem = (array) json_decode(self::env('DOMAINS_MOCK_PREMIUM', '[]'), true);
            return array_map(function ($n) use ($taken, $prem, $mark) {
                $cost = str_ends_with($n, '.com') ? 1299 : 1999; $rc = str_ends_with($n, '.com') ? 1499 : 2199;
                return ['domain' => $n, 'ok' => !in_array($n, $taken, true), 'premium' => in_array($n, $prem, true), 'price' => $cost + $mark, 'renew' => $rc + $mark, 'cost' => $cost, 'renew_cost' => $rc];
            }, $names);
        }
        $r = self::inPlace($pdo, $type, $id, fn () => Domains::api('POST', '/v4/domains:checkAvailability', ['domainNames' => $names]));
        $out = [];
        foreach ((array) ($r['results'] ?? []) as $x) {
            $cost = (int) ceil(((float) ($x['purchasePrice'] ?? 0)) * 100); $rc = (int) ceil(((float) ($x['renewalPrice'] ?? 0)) * 100);
            $out[] = ['domain' => (string) $x['domainName'], 'ok' => !empty($x['purchasable']) && $cost > 0, 'premium' => !empty($x['premium']), 'price' => $cost > 0 ? $cost + $mark : 0,
                'renew' => $rc > 0 ? $rc + $mark : ($cost > 0 ? $cost + $mark : 0), 'cost' => $cost, 'renew_cost' => $rc ?: $cost];
        }
        return $out;
    }

    /** '' when the name can be sold or listed; else why not. */
    private static function reservedWhy(string $d): string
    {
        foreach (['traversence.com', 'trvgo.us'] as $r) if ($d === $r || str_ends_with($d, '.' . $r)) return 'That one is Traversence\'s own.';
        return '';
    }

    // ---- the cart ----------------------------------------------------------------------------------------------------

    /**
     * Puts a domain in the person's cart for an account (theirs, or a business they buy for). The price is checked
     * again (never more than shown); the registrant must be 18 or older, with real contact details. Returns the cart row.
     */
    public static function addToCart(PDO $pdo, int $uid, string $type, int $id, string $domain, int $shown, array $who, bool $adult): array
    {
        [$ok, $why] = self::open($pdo, $uid); if (!$ok) throw new InvalidArgumentException($why);
        if ($type === 'user') $id = $uid;
        if (!self::canPay($pdo, $uid, $type, $id)) throw new InvalidArgumentException($type === 'listing' ? 'Buying a domain for this business needs Domain (edit) and Plan & billing (edit) on its team: the owner can give you both.' : 'Sign in to buy a domain.');
        require_once __DIR__ . '/AgeGate.php';
        if (!$adult) throw new InvalidArgumentException('Tick that you and the registrant are 18 or older: a domain is registered to an adult (ICANN\'s rule, decisions/0058).');
        $d = Domains::clean($domain);
        if ($d === '') throw new InvalidArgumentException('That doesn\'t look like a domain.');
        $org = $type === 'listing' ? self::ownerName($pdo, $type, $id) : '';
        $c = Domains::contact($who, $org);   // throws with what's missing
        $hit = null; foreach (self::search($pdo, $d, $type, $id) as $x) if ($x['domain'] === $d) { $hit = $x; break; }
        if (!$hit || !$hit['ok']) throw new InvalidArgumentException($d . ' isn\'t available any more. Search again.');
        if ($hit['premium']) throw new InvalidArgumentException($d . ' is a premium name, priced by its owner. Write to support@traversence.com and we\'ll find out its price for you.');
        if ($shown > 0 && $hit['price'] > $shown) throw new InvalidArgumentException('Its price changed to ' . self::usd($hit['price']) . ' a year. Search again to see it.');
        $have = $pdo->prepare("SELECT dc.id FROM domain_cart dc JOIN cart_plans cp ON cp.owner_type = 'oneoff' AND cp.item IN ('domain_purchase','domain_renewal') AND cp.owner_id = dc.id WHERE dc.user_id = ? AND dc.domain = ?"); $have->execute([$uid, $d]);
        if ($have->fetchColumn()) throw new InvalidArgumentException($d . ' is in your cart already.');
        $own = $pdo->prepare("SELECT 1 FROM account_domains WHERE domain = ? AND status IN ('active','expired')"); $own->execute([$d]);
        if ($own->fetchColumn()) throw new InvalidArgumentException($d . ' is already registered through Traversence.');
        if (!AgeGate::confirmed($pdo, $uid)) AgeGate::confirm($pdo, $uid);   // the same 18+ confirmation the rest of the site asks once (0058 §7)
        $pdo->prepare("INSERT INTO domain_cart (user_id, owner_type, owner_id, kind, domain, price_cents, cost_cents, renew_cents, renew_cost_cents, who, created_at) VALUES (?, ?, ?, 'purchase', ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$uid, $type, $id, $d, $hit['price'], $hit['cost'], $hit['renew'], $hit['renew_cost'], json_encode(['contact' => $c, 'adult' => true, 'org' => $org]), self::now()]);
        $dc = (int) $pdo->lastInsertId();
        $pdo->prepare("INSERT INTO cart_plans (user_id, owner_type, owner_id, item, qty, cycle, created_at) VALUES (?, 'oneoff', ?, 'domain_purchase', 1, 'year', ?)")->execute([$uid, $dc, self::now()]);
        return self::cartRow($pdo, $dc) ?: [];
    }

    /** A year's renewal into the cart (Renew now without a card in the wallet). */
    public static function renewToCart(PDO $pdo, int $uid, int $domainId): void
    {
        $d = self::mine($pdo, $uid, $domainId, true);
        if ($d['source'] !== 'bought') throw new InvalidArgumentException('Only a domain registered through us renews here.');
        [$price, $cost] = self::renewPrice($pdo, $d);
        $have = $pdo->prepare("SELECT dc.id FROM domain_cart dc JOIN cart_plans cp ON cp.owner_type = 'oneoff' AND cp.item IN ('domain_purchase','domain_renewal') AND cp.owner_id = dc.id WHERE dc.user_id = ? AND dc.domain_id = ? AND dc.kind = 'renewal'"); $have->execute([$uid, $domainId]);
        if ($have->fetchColumn()) throw new InvalidArgumentException('Its renewal is in your cart already.');
        $pdo->prepare("INSERT INTO domain_cart (user_id, owner_type, owner_id, kind, domain, domain_id, price_cents, cost_cents, renew_cents, renew_cost_cents, created_at) VALUES (?, ?, ?, 'renewal', ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$uid, $d['owner_type'], (int) $d['owner_id'], $d['domain'], $domainId, $price, $cost, $price, $cost, self::now()]);
        $pdo->prepare("INSERT INTO cart_plans (user_id, owner_type, owner_id, item, qty, cycle, created_at) VALUES (?, 'oneoff', ?, 'domain_renewal', 1, 'year', ?)")->execute([$uid, (int) $pdo->lastInsertId(), self::now()]);
    }

    /** A renewal's price now: Name.com's renewal cost (asked again when it can be) plus our markup. [cents, cost cents] */
    private static function renewPrice(PDO $pdo, array $d): array
    {
        $mark = max(0, (int) self::env('DOMAIN_MARKUP_CENTS', '500'));
        $cost = (int) $d['renew_cost_cents'];
        if (self::mode() !== 'mock') {
            try {
                $r = self::inPlace($pdo, (string) $d['owner_type'], (int) $d['owner_id'], fn () => Domains::api('GET', '/v4/domains/' . rawurlencode((string) $d['domain']), null), $d['env'] === 'sandbox');
                if (!empty($r['renewalPrice'])) $cost = (int) ceil(((float) $r['renewalPrice']) * 100);
            } catch (Throwable $x) { error_log('domains renewal price ' . $d['domain'] . ': ' . $x->getMessage()); }
        }
        if ($cost <= 0) $cost = max(0, (int) $d['renew_cents'] - $mark);
        return [$cost + $mark, $cost];
    }

    public static function cartRow(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM domain_cart WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Which card pays the domains in the cart for an account: 'wallet:<id>' or 'new'. */
    public static function setCartCard(PDO $pdo, int $uid, string $type, int $id, string $pick): void
    {
        if ($pick !== 'new' && !preg_match('/^wallet:\d+$/', $pick)) throw new InvalidArgumentException('Choose a card.');
        if ($pick !== 'new') Wallet::resolve($pdo, $uid, $type, $id, $pick);   // it's theirs and usable
        $pdo->prepare("UPDATE domain_cart dc JOIN cart_plans cp ON cp.owner_type = 'oneoff' AND cp.item IN ('domain_purchase','domain_renewal') AND cp.owner_id = dc.id AND cp.user_id = dc.user_id SET dc.pay_with = ? WHERE dc.user_id = ? AND dc.owner_type = ? AND dc.owner_id = ?")
            ->execute([$pick, $uid, $type, $id]);
    }

    /**
     * The cart's domain lines, one group per account (CartPlans::groups adds them): [{type 'domain', owner_type, owner_id,
     * name, lines, card: 'wallet' (a saved card pays) | 'new' (a card is entered), card_label, cards, pick, due_now}].
     */
    public static function cartGroups(PDO $pdo, int $uid): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT cp.id AS line, cp.item, dc.* FROM cart_plans cp JOIN domain_cart dc ON dc.id = cp.owner_id WHERE cp.user_id = ? AND cp.owner_type = 'oneoff' AND cp.item IN ('domain_purchase','domain_renewal') ORDER BY dc.owner_type DESC, dc.owner_id, cp.id");
        $st->execute([$uid]);
        $g = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $k = $r['owner_type'] . ':' . $r['owner_id'];
            if (!isset($g[$k])) {
                $cards = self::inPlace($pdo, (string) $r['owner_type'], (int) $r['owner_id'], fn () => Wallet::cards($pdo, (string) $r['owner_type'], (int) $r['owner_id']));   // the wallet in use: the test one for a test
                $g[$k] = ['type' => 'domain', 'id' => 0, 'owner_type' => (string) $r['owner_type'], 'owner_id' => (int) $r['owner_id'], 'name' => 'Domains' . ($r['owner_type'] === 'listing' ? ' for ' . self::ownerName($pdo, 'listing', (int) $r['owner_id']) : ''),
                    'lines' => [], 'plan' => '', 'cycle' => 'year', 'cards' => array_map(fn ($c) => ['pick' => 'wallet:' . $c['id'], 'label' => $c['label']], $cards), 'pick' => (string) $r['pay_with'], 'why' => '', 'due_now' => 0];
            }
            $g[$k]['lines'][] = ['id' => (int) $r['line'], 'item' => (string) $r['item'], 'kind' => 'domain', 'qty' => 1, 'ref' => (int) $r['id'],
                'name' => $r['domain'] . ($r['kind'] === 'renewal' ? ': renewal, 1 year' : ': 1 year, with WHOIS privacy'), 'cents' => (int) $r['price_cents'], 'per' => 'a year'];
            $g[$k]['due_now'] += (int) $r['price_cents'];
        }
        foreach ($g as &$x) {
            $pick = $x['pick'];
            if ($pick === '' && $x['cards']) $pick = $x['cards'][0]['pick'];   // the default card first
            $have = array_column($x['cards'], 'label', 'pick');
            if ($pick !== 'new' && isset($have[$pick])) { $x['card'] = 'wallet'; $x['card_label'] = $have[$pick]; $x['pick'] = $pick; }
            else { $x['card'] = 'new'; $x['card_label'] = ''; $x['pick'] = 'new'; }
        }
        return array_values($g);
    }

    /** Pays one account's domain lines from the cart: one order, the card charged once, then each registered or renewed. Returns the order id. */
    public static function payGroup(PDO $pdo, int $uid, array $group, string $token): int
    {
        $ids = array_map(fn ($l) => (int) $l['ref'], $group['lines']);
        $rows = [];
        foreach ($ids as $i) { $r = self::cartRow($pdo, $i); if (!$r || (int) $r['user_id'] !== $uid) throw new RuntimeException('Your cart changed. Look it over and pay again.'); $rows[] = $r; }
        $type = (string) $group['owner_type']; $id = (int) $group['owner_id'];
        $pick = $group['card'] === 'wallet' ? (string) $group['pick'] : $token;
        $specs = array_map(fn ($r) => ['kind' => (string) $r['kind'], 'domain' => (string) $r['domain'], 'domain_id' => (int) ($r['domain_id'] ?? 0), 'cents' => (int) $r['price_cents'], 'cost' => (int) $r['cost_cents'],
            'renew' => (int) $r['renew_cents'], 'renew_cost' => (int) $r['renew_cost_cents'], 'who' => (array) ((json_decode((string) $r['who'], true) ?: [])['contact'] ?? [])], $rows);
        return self::pay($pdo, $uid, $type, $id, $specs, $pick, true);
    }

    // ---- paying: one order --------------------------------------------------------------------------------------------

    /**
     * Charges first, then does what was bought. $specs: [{kind purchase|renewal, domain, domain_id, cents, cost, renew,
     * renew_cost, who}]. $pick: 'wallet:<id>' or a one-time card token; '' with $auto: the domain's assigned card. A
     * decline voids the order and throws (402). Returns the order id.
     */
    public static function pay(PDO $pdo, int $uid, string $type, int $id, array $specs, string $pick, bool $fromCart = false, bool $auto = false): int
    {
        if (!$specs) throw new InvalidArgumentException('Nothing to pay for.');
        if (!$auto) { [$ok, $why] = self::open($pdo, $uid); if (!$ok && !self::hasOnly($specs, 'renewal')) throw new InvalidArgumentException($why); }
        if (!$auto && !self::canPay($pdo, $uid, $type, $id)) throw new InvalidArgumentException('Only someone who can pay for this account can do that.');
        $sandbox = self::sandboxed($pdo, $type, $id) || ($auto && self::anySandbox($pdo, $specs));
        return self::inPlace($pdo, $type, $id, function () use ($pdo, $uid, $type, $id, $specs, $pick, $fromCart, $auto, $sandbox) {
            require_once __DIR__ . '/QuickBooksPay.php'; require_once __DIR__ . '/Orders.php'; require_once __DIR__ . '/Billing.php';
            // checked again before any charge: still available, never more than shown; still theirs to renew
            foreach ($specs as &$s) {
                if ($s['kind'] === 'purchase') {
                    $hit = null; foreach (self::search($pdo, $s['domain'], $type, $id) as $x) if ($x['domain'] === $s['domain']) { $hit = $x; break; }
                    if (!$hit || !$hit['ok'] || $hit['premium']) throw new InvalidArgumentException($s['domain'] . ' isn\'t available any more. Take it out of your cart and search again.');
                    if ($hit['price'] > $s['cents']) throw new InvalidArgumentException($s['domain'] . '\'s price changed to ' . self::usd($hit['price']) . ' a year. Take it out of your cart and add it again.');
                    $s['cost'] = $hit['cost'];   // Name.com's actual cost for this domain and year
                } else {
                    $d = self::get($pdo, $s['domain_id']);
                    if (!$d || $d['owner_type'] !== $type || (int) $d['owner_id'] !== $id || !in_array($d['status'], ['active', 'expired'], true)) throw new InvalidArgumentException($s['domain'] . ' can\'t be renewed here any more.');
                }
            }
            unset($s);
            $card = $pick === '' ? Wallet::assigned($pdo, 'domain', (int) $specs[0]['domain_id']) : Wallet::resolve($pdo, $uid, $type, $id, $pick);
            if (!$card) throw new RuntimeException('There\'s no card for its renewals. Add one in the Domains tab\'s Wallet.', 402);
            $o = Billing::owner($pdo, $type, $id);
            $st = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ?'); $st->execute([$uid ?: (int) $o['payer']]); $u = $st->fetch(PDO::FETCH_ASSOC) ?: ['email' => $o['email'], 'display_name' => $o['payer_name']];
            $billName = $type === 'listing' ? $o['name'] : (string) ($u['display_name'] ?: $u['email']);
            $billEmail = (string) ($u['email'] ?: $o['email']);
            $total = array_sum(array_column($specs, 'cents'));
            $pdo->prepare("INSERT INTO orders (status, user_id, access_token, items, subtotal_cents, total_cents, bill_name, bill_email, approved_at) VALUES ('pending', ?, ?, ?, ?, ?, ?, ?, NOW())")
                ->execute([$uid ?: ((int) $o['payer'] ?: null), bin2hex(random_bytes(20)), count($specs), $total, $total, $billName, $billEmail]);
            $oid = (int) $pdo->lastInsertId();
            try { $pdo->prepare('UPDATE orders SET qb_env = ? WHERE id = ?')->execute([$sandbox ? 'sandbox' : QuickBooksPay::env(), $oid]); } catch (Throwable) {}
            if ($type === 'listing') { try { $pdo->prepare('UPDATE orders SET client_company = ? WHERE id = ?')->execute([mb_substr($o['name'], 0, 190), $oid]); } catch (Throwable) {} }
            $vendor = self::vendorId($pdo);
            $lineIds = [];
            foreach ($specs as $i => $s) {
                $pid = self::productId($pdo, $s['kind'] === 'renewal' ? 'renewal' : 'purchase');
                $title = $s['kind'] === 'renewal' ? 'Domain Renewal: ' . $s['domain'] . ', 1 year' : 'Domain Purchase: ' . $s['domain'] . ', 1 year, WHOIS privacy';
                $pdo->prepare("INSERT INTO order_lines (order_id, product, product_id, ref_id, title, qty, unit_cents, list_cents, cost_cents, taxable, approved_at) VALUES (?, 'product', ?, ?, ?, 1, ?, ?, ?, 0, NOW())")
                    ->execute([$oid, $pid ?: null, $s['domain_id'] ?: null, $title, $s['cents'], $s['cents'], $s['cost']]);
                $lid = (int) $pdo->lastInsertId(); $lineIds[$i] = $lid;
                if ($vendor) { try { $pdo->prepare('UPDATE order_lines SET vendor_id = ? WHERE id = ?')->execute([$vendor, $lid]); } catch (Throwable) {} }
                try { $pdo->prepare('INSERT INTO order_line_costs (line_id, order_id, recipe, run_qty, cogs_cents, vendor_cents, checked_cents, checked_by, checked_at, updated_by, updated_at) VALUES (?, ?, ?, 1, ?, ?, ?, NULL, NOW(), NULL, NOW())')
                    ->execute([$lid, $oid, json_encode(['source' => 'namecom', 'note' => 'Name.com\'s price for ' . $s['domain'] . ', 1 year']), $s['cost'], $s['cost'], $s['cost']]); }
                catch (Throwable $x) { error_log('domains cost line ' . $lid . ': ' . $x->getMessage()); }
            }
            Orders::number($pdo, $oid);
            $row = Orders::get($pdo, $oid);
            $key = $auto ? 'domrenew-' . (int) $specs[0]['domain_id'] . '-' . substr((string) (self::get($pdo, (int) $specs[0]['domain_id'])['expires_at'] ?? ''), 0, 10) . '-' . (int) (self::get($pdo, (int) $specs[0]['domain_id'])['renew_fails'] ?? 0) : 'domorder-' . $oid;
            try {
                if (!$sandbox) QuickBooksPay::guardReal($pdo, $row);   // never real money for a test (decisions/0145)
                $charge = Wallet::charge($pdo, $card, $total, 'Traversence domains for ' . $billName . ': ' . implode(', ', array_column($specs, 'domain')), $key);
            } catch (Throwable $e) {
                $pdo->prepare("UPDATE orders SET status = 'void', note = ? WHERE id = ?")->execute([mb_substr('card: ' . $e->getMessage(), 0, 300), $oid]);
                $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE order_id = ?")->execute([$oid]);
                Orders::event($pdo, $oid, 'declined', 'Card ' . $card['label'] . ' declined: ' . mb_substr($e->getMessage(), 0, 200));
                throw $e;
            }
            // charged: from here on nothing may stop what was bought
            $pdo->prepare("UPDATE orders SET status = 'paid', paid_at = NOW() WHERE id = ?")->execute([$oid]);
            try { $pdo->prepare('UPDATE orders SET charge_id = ? WHERE id = ?')->execute([$charge, $oid]); } catch (Throwable) {}
            Orders::record($pdo, $oid, 'charge', $total, 'charge-' . $oid, 'card', '', 'card ' . $charge);
            Orders::event($pdo, $oid, 'paid', 'Paid ' . Orders::usd($total) . ' on ' . $card['label'] . ($auto ? ' (auto-renew)' : ''), $uid ?: null);
            $done = []; $failed = [];
            foreach ($specs as $i => $s) {
                $lid = $lineIds[$i];
                try {
                    if ($s['kind'] === 'purchase') { $did = self::register($pdo, $uid, $type, $id, $s, $oid, (int) $card['id'], $sandbox); $pdo->prepare('UPDATE order_lines SET ref_id = ? WHERE id = ?')->execute([$did, $lid]); }
                    else self::renewAt($pdo, $uid, $s, $oid, $sandbox);
                    $pdo->prepare("UPDATE order_lines SET status = 'done' WHERE id = ?")->execute([$lid]);
                    Orders::event($pdo, $oid, 'done', ($s['kind'] === 'renewal' ? 'Renewed ' : 'Registered ') . $s['domain'] . ' at Name.com', null, $lid);
                    $done[] = $s;
                } catch (Throwable $x) {
                    $failed[] = $s;
                    self::lineFailed($pdo, $oid, $lid, $s, (string) $charge, $x->getMessage(), $sandbox);
                }
            }
            if ($done) self::receipt($pdo, $uid ?: (int) $o['payer'], $billName, $billEmail, $done, (string) $charge, $oid, $sandbox);
            self::mailBuyer($billEmail, $billName, $oid, $done, $failed, $card['label'], $type, $id);
            if (!$failed) $pdo->prepare("UPDATE orders SET stage = 'complete' WHERE id = ?")->execute([$oid]);
            return $oid;
        }, $sandbox);
    }

    private static function hasOnly(array $specs, string $kind): bool { foreach ($specs as $s) if ($s['kind'] !== $kind) return false; return true; }

    private static function anySandbox(PDO $pdo, array $specs): bool
    {
        foreach ($specs as $s) if ($s['domain_id'] && ($d = self::get($pdo, (int) $s['domain_id'])) && $d['env'] === 'sandbox') return true;
        return false;
    }

    /** Registers a paid domain at Name.com, in the registrant's name with WHOIS privacy. Returns its row id. */
    private static function register(PDO $pdo, int $uid, string $type, int $id, array $s, int $oid, int $cardId, bool $sandbox): int
    {
        $d = $s['domain'];
        if (self::mode() === 'mock') {
            if (in_array($d, (array) json_decode(self::env('DOMAINS_MOCK_FAIL', '[]'), true), true)) throw new RuntimeException('Name.com didn\'t register it (test)');
            $reg = ['order' => 'MOCK-' . substr(md5($d), 0, 8), 'expires' => date('Y-m-d H:i:s', strtotime('+1 year'))];
        } else {
            $c = (array) $s['who'];
            $r = Domains::api('POST', '/v4/domains', ['domain' => ['domainName' => $d, 'privacyEnabled' => true, 'locked' => true, 'contacts' => ['registrant' => $c, 'admin' => $c, 'tech' => $c, 'billing' => $c]],
                'purchasePrice' => round($s['cost'] / 100, 2), 'years' => 1]);
            if (empty($r['domain']['domainName'])) throw new RuntimeException('Name.com didn\'t register it: ' . mb_substr((string) ($r['message'] ?? $r['details'] ?? 'no answer'), 0, 160));
            $reg = ['order' => (string) ($r['order'] ?? ''), 'expires' => !empty($r['domain']['expireDate']) ? date('Y-m-d H:i:s', strtotime((string) $r['domain']['expireDate'])) : date('Y-m-d H:i:s', strtotime('+1 year'))];
        }
        $now = self::now();
        $old = $pdo->prepare('SELECT id FROM account_domains WHERE domain = ?'); $old->execute([$d]);
        $vals = [$type, $id, 'bought', 'active', $sandbox ? 'sandbox' : 'live', 'dns', 1, (int) $s['renew'], (int) $s['renew_cost'], $now, $reg['expires'], $reg['order'], $uid ?: null];
        if ($oldId = (int) ($old->fetchColumn() ?: 0)) {   // a domain that was here before (removed, moved away, expired and gone): this account's now
            $pdo->prepare("UPDATE account_domains SET owner_type = ?, owner_id = ?, source = ?, status = ?, env = ?, points = ?, auto_renew = ?, renew_cents = ?, renew_cost_cents = ?, registered_at = ?, expires_at = ?, provider_order = ?, created_by = ?,
                forward_to = '', nameservers = '', dkim = NULL, email_ok = 0, renew_fails = 0, renew_next = NULL, renew_order = NULL, attention = '', updated_at = ? WHERE id = ?")->execute(array_merge($vals, [$now, $oldId]));
            $did = $oldId;
        } else {
            $pdo->prepare('INSERT INTO account_domains (owner_type, owner_id, source, status, env, points, auto_renew, renew_cents, renew_cost_cents, registered_at, expires_at, provider_order, created_by, domain, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute(array_merge($vals, [$d, $now, $now]));
            $did = (int) $pdo->lastInsertId();
        }
        if ($cardId > 0) Wallet::assign($pdo, $cardId, 'domain', $did);   // its renewals go on this card (locked in the wallet)
        else $pdo->prepare('UPDATE account_domains SET auto_renew = 0 WHERE id = ?')->execute([$did]);   // no card for it: renewals wait for one
        self::event($pdo, $did, 'bought', 'Registered through Name.com for a year, with WHOIS privacy' . ($sandbox ? ' (Name.com\'s sandbox: a test, not a real registration)' : ''), $oid, $uid);
        self::dkim($pdo, $did);
        return $did;
    }

    /** Renews a paid domain at Name.com for a year. */
    private static function renewAt(PDO $pdo, int $uid, array $s, int $oid, bool $sandbox): void
    {
        $d = self::get($pdo, (int) $s['domain_id']);
        if (self::mode() === 'mock') {
            if (in_array($d['domain'], (array) json_decode(self::env('DOMAINS_MOCK_FAIL', '[]'), true), true)) throw new RuntimeException('Name.com didn\'t renew it (test)');
        } else Domains::api('POST', '/v4/domains/' . rawurlencode((string) $d['domain']) . ':renew', ['purchasePrice' => round(((int) $s['cost'] ?: (int) $d['renew_cost_cents']) / 100, 2), 'years' => 1]);
        $base = $d['expires_at'] && strtotime((string) $d['expires_at']) > time() ? (string) $d['expires_at'] : self::now();
        $pdo->prepare("UPDATE account_domains SET status = 'active', expires_at = DATE_ADD(?, INTERVAL 1 YEAR), renew_fails = 0, renew_next = NULL, renew_order = ?, attention = '', renew_cents = ?, renew_cost_cents = ?, updated_at = ? WHERE id = ?")
            ->execute([$base, $oid, (int) $s['cents'], (int) $s['cost'] ?: (int) $d['renew_cost_cents'], self::now(), (int) $d['id']]);
        self::event($pdo, (int) $d['id'], 'renewed', 'Renewed for a year, to ' . date('M j, Y', strtotime($base . ' +1 year')), $oid, $uid ?: null);
    }

    /** A paid line that Name.com didn't do: a new purchase is refunded; a renewal waits for our team (the name mustn't lapse). */
    private static function lineFailed(PDO $pdo, int $oid, int $lid, array $s, string $charge, string $why, bool $sandbox): void
    {
        $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE id = ?")->execute([$lid]);
        if ($s['kind'] === 'renewal') {
            $pdo->prepare("UPDATE order_lines SET status = 'approved' WHERE id = ?")->execute([$lid]);
            $pdo->prepare('UPDATE account_domains SET attention = ? WHERE id = ?')->execute([mb_substr('Paid, but Name.com didn\'t renew it: ' . $why, 0, 300), (int) $s['domain_id']]);
            Orders::event($pdo, $oid, 'needs_attention', 'Paid for ' . $s['domain'] . '\'s renewal, but Name.com didn\'t renew it (' . mb_substr($why, 0, 160) . '). Try again, or refund.', null, $lid);
            self::event($pdo, (int) $s['domain_id'], 'renew_failed', 'Paid, but Name.com didn\'t renew it yet: our team is on it', $oid);
            return;
        }
        try {
            $ref = Wallet::sandboxFor($pdo, '', 0, fn () => QuickBooksPay::refundCharge($pdo, $charge, (int) $s['cents'], 'Domain ' . $s['domain'] . ' couldn\'t be registered', 'domrefund-' . $lid));
            Orders::record($pdo, $oid, 'refund', (int) $s['cents'], 'refund-' . $lid, 'card', '', 'refund ' . $ref . ': ' . $s['domain'] . ' not registered');   // the order's status follows (Orders::settle)
            Orders::event($pdo, $oid, 'refund', 'Refunded ' . Orders::usd((int) $s['cents']) . ': Name.com didn\'t register ' . $s['domain'] . ' (' . mb_substr($why, 0, 160) . ')', null, $lid);
        } catch (Throwable $y) {
            error_log('SECURITY domains: ' . $s['domain'] . ' charged (' . $charge . ') but not registered or refunded: ' . $y->getMessage());
            Orders::event($pdo, $oid, 'needs_attention', 'Charged for ' . $s['domain'] . ', not registered (' . mb_substr($why, 0, 120) . '), and the refund didn\'t go through (' . mb_substr($y->getMessage(), 0, 120) . '). Refund it, or try registering again.', null, $lid);
        }
    }

    /** The receipt in the books: each line on its product's QuickBooks item when the catalog links one (0166 §4), else today's. */
    private static function receipt(PDO $pdo, int $uid, string $name, string $email, array $done, string $charge, int $oid, bool $sandbox): void
    {
        require_once __DIR__ . '/Books.php';
        try {
            $lines = array_map(fn ($s) => [($s['kind'] === 'renewal' ? 'Domain Renewal: ' : 'Domain Purchase: ') . $s['domain'] . ', 1 year', (int) $s['cents'], Books::itemFor($pdo, self::productId($pdo, $s['kind'] === 'renewal' ? 'renewal' : 'purchase'))], $done);
            Wallet::sandboxFor($pdo, '', 0, fn () => QuickBooksPay::salesReceiptFor($pdo, $uid, ['name' => $name, 'email' => $email], $lines, $charge, 'domorder-' . $oid, 'Traversence domains, order ' . $oid));   // a test's receipt goes to the sandbox's books
        } catch (Throwable $x) { Orders::event($pdo, $oid, 'needs_books', 'The card was charged (' . $charge . ') but QuickBooks didn\'t take the sales receipt (' . mb_substr($x->getMessage(), 0, 160) . '): add it there.'); }
    }

    private static function mailBuyer(string $to, string $name, int $oid, array $done, array $failed, string $card, string $type, int $id): void
    {
        if ($to === '') return;
        require_once __DIR__ . '/Mailer.php';
        $o = Orders::get(Database::connection(), $oid);
        $lines = array_map(fn ($s) => '  ' . $s['domain'] . ($s['kind'] === 'renewal' ? ', renewed for a year' : ', registered for a year (WHOIS privacy on)') . ': ' . self::usd((int) $s['cents']), $done);
        $fail = array_map(fn ($s) => '  ' . $s['domain'] . ($s['kind'] === 'renewal' ? ': paid; Name.com didn\'t renew it yet. Our team is on it and will write to you.' : ': Name.com couldn\'t register it, so it was refunded to your card.'), $failed);
        $verify = array_filter($done, fn ($s) => $s['kind'] === 'purchase') ? "\nName.com will email the registrant to confirm their contact details (ICANN's rule): please answer it within 15 days, or the domain is paused until it's confirmed.\n" : '';
        try {
            Mailer::send($to, 'Your Traversence receipt: domains, order #' . Orders::no($o), "Hello " . $name . ",\n\nThank you. Order #" . Orders::no($o) . ":\n\n" . implode("\n", $lines) . ($fail ? "\n\n" . implode("\n", $fail) : '')
                . "\n\nCharged to " . $card . ': ' . self::usd(array_sum(array_column($done, 'cents')) + array_sum(array_map(fn ($s) => $s['kind'] === 'renewal' ? (int) $s['cents'] : 0, $failed))) . "\n" . $verify
                . "\nManage your domains: " . self::tabUrl($type, $id) . "\nSomething not right? Use Something isn't right on the domain there, or write to support@traversence.com.\n");
        } catch (Throwable $x) { error_log('domains receipt: ' . $x->getMessage()); }
    }

    /** The two catalog products (made once, kept in the catalog: Back-Office → Products). */
    public static function productId(PDO $pdo, string $kind): int
    {
        static $ids = [];
        if (isset($ids[$kind])) return $ids[$kind];
        [$sku, $name, $desc] = self::SKUS[$kind];
        require_once __DIR__ . '/Scope.php';
        try {
            $t = Scope::t('products');
            $st = $pdo->prepare('SELECT id FROM ' . $t . ' WHERE sku = ?'); $st->execute([$sku]);
            $id = (int) ($st->fetchColumn() ?: 0);
            if (!$id) {
                $pdo->prepare('INSERT INTO ' . $t . " (sku, name, kind, description, options, tiers, taxable, vendor, turnaround, status) VALUES (?, ?, 'service', ?, '[]', ?, 0, 'Name.com', 'Minutes', 'hidden')")
                    ->execute([$sku, $name, $desc, json_encode(['markup' => 0, 'rows' => []])]);
                $id = (int) $pdo->lastInsertId();
            }
            return $ids[$kind] = $id;
        } catch (Throwable $x) { error_log('domains product ' . $sku . ': ' . $x->getMessage()); return 0; }
    }

    /** Name.com, as a vendor (each domain line names it, with its cost). */
    public static function vendorId(PDO $pdo): int
    {
        static $v = null;
        if ($v !== null) return $v;
        try {
            require_once __DIR__ . '/Vendors.php';
            if (!Vendors::ready($pdo)) return $v = 0;
            $r = Vendors::byName($pdo, 'Name.com');
            return $v = $r ? (int) $r['id'] : Vendors::save($pdo, ['name' => 'Name.com', 'email' => '', 'contact' => '', 'phone' => '', 'website' => 'https://www.name.com', 'account_no' => '', 'notes' => 'Domain registrar (reseller API): domains sold in Shop → Domains (decisions/0169 §1a).']);
        } catch (Throwable $x) { error_log('domains vendor: ' . $x->getMessage()); return $v = 0; }
    }

    // ---- what an account holds ---------------------------------------------------------------------------------------

    public static function get(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM account_domains WHERE id = ?'); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** The account's domains (not removed), soonest to expire first. */
    public static function forOwner(PDO $pdo, string $type, int $id): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare("SELECT * FROM account_domains WHERE owner_type = ? AND owner_id = ? AND status <> 'removed' ORDER BY status = 'transferred', expires_at IS NULL, expires_at, domain"); $st->execute([$type, $id]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** A domain this person may manage, or it throws. */
    public static function mine(PDO $pdo, int $uid, int $id, bool $pay = false): array
    {
        $d = self::get($pdo, $id);
        if (!$d || $d['status'] === 'removed') throw new InvalidArgumentException('That domain isn\'t here.');
        if (!($pay ? self::canPay($pdo, $uid, (string) $d['owner_type'], (int) $d['owner_id']) : self::canManage($pdo, $uid, (string) $d['owner_type'], (int) $d['owner_id'])))
            throw new InvalidArgumentException($pay ? 'Paying for this needs Plan & billing (edit) on the business\'s team.' : 'You can\'t change this domain. The owner can give you Domain (edit).');
        return $d;
    }

    /** Its history, newest first. */
    public static function history(PDO $pdo, int $id, int $limit = 40): array
    {
        $st = $pdo->prepare('SELECT * FROM domain_events WHERE domain_id = ? ORDER BY id DESC LIMIT ' . max(1, min(200, $limit))); $st->execute([$id]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function event(PDO $pdo, int $id, string $kind, string $note, ?int $order = null, ?int $actor = null): int
    {
        $pdo->prepare('INSERT INTO domain_events (domain_id, kind, note, order_id, actor, created_at) VALUES (?, ?, ?, ?, ?, ?)')->execute([$id, $kind, mb_substr($note, 0, 600), $order, $actor ?: null, self::now()]);
        return (int) $pdo->lastInsertId();
    }

    /** Lists a domain the account owns elsewhere, for pointing only (its records stay where it's registered). */
    public static function addOwn(PDO $pdo, int $uid, string $type, int $id, string $domain): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('Domains open once their database update has run (within the hour).');
        if ($type === 'user') $id = $uid;
        if (!self::canManage($pdo, $uid, $type, $id)) throw new InvalidArgumentException('You can\'t add domains for this account.');
        $d = Domains::clean($domain);
        if ($d === '') throw new InvalidArgumentException('That doesn\'t look like a domain. Type it like yourname.com.');
        if (($w = self::reservedWhy($d)) !== '') throw new InvalidArgumentException($w);
        $st = $pdo->prepare('SELECT * FROM account_domains WHERE domain = ?'); $st->execute([$d]);
        $old = $st->fetch(PDO::FETCH_ASSOC);
        if ($old && !in_array($old['status'], ['removed', 'transferred'], true)) throw new InvalidArgumentException($old['owner_type'] === $type && (int) $old['owner_id'] === $id ? $d . ' is on your list already.' : 'Another account on Traversence lists ' . $d . '. If it\'s yours, write to support@traversence.com.');
        $now = self::now();
        if ($old) {
            $pdo->prepare("UPDATE account_domains SET owner_type = ?, owner_id = ?, source = 'own', status = 'active', env = 'live', points = '', forward_to = '', nameservers = '', auto_renew = 0, registered_at = NULL, expires_at = NULL, provider_order = '', dkim = NULL, email_ok = 0, attention = '', created_by = ?, updated_at = ? WHERE id = ?")
                ->execute([$type, $id, $uid, $now, (int) $old['id']]);
            $did = (int) $old['id'];
        } else {
            $pdo->prepare("INSERT INTO account_domains (owner_type, owner_id, domain, source, status, auto_renew, created_by, created_at, updated_at) VALUES (?, ?, ?, 'own', 'active', 0, ?, ?, ?)")->execute([$type, $id, $d, $uid, $now, $now]);
            $did = (int) $pdo->lastInsertId();
        }
        self::event($pdo, $did, 'listed', 'Listed as a domain registered elsewhere, for pointing only', null, $uid);
        self::dkim($pdo, $did);
        return self::get($pdo, $did) ?: [];
    }

    /** Takes a brought domain off the list (a bought one stays the account's until it runs out or moves away). */
    public static function removeOwn(PDO $pdo, int $uid, int $id): void
    {
        $d = self::mine($pdo, $uid, $id);
        if ($d['source'] !== 'own' && $d['status'] === 'active') throw new InvalidArgumentException('A domain registered through us stays yours until it runs out. To move it, use Transfer away.');
        $pdo->prepare("UPDATE account_domains SET status = 'removed', auto_renew = 0, updated_at = ? WHERE id = ?")->execute([self::now(), $id]);
        Wallet::release($pdo, 'domain', $id);
        self::event($pdo, $id, 'removed', 'Taken off the list', null, $uid);
    }

    // ---- renewing ----------------------------------------------------------------------------------------------------

    /** Auto-renew on (needs a card from the wallet: it's assigned and locked) or off (the card unlocks). */
    public static function setAutoRenew(PDO $pdo, int $uid, int $id, bool $on, string $pick = ''): string
    {
        $d = self::mine($pdo, $uid, $id, $on);
        if ($d['source'] !== 'bought') throw new InvalidArgumentException('Only a domain registered through us renews here.');
        if (!in_array($d['status'], ['active', 'expired'], true)) throw new InvalidArgumentException('It isn\'t here to renew any more.');
        if ($on) {
            $card = self::inPlace($pdo, (string) $d['owner_type'], (int) $d['owner_id'], fn () => $pick !== '' ? Wallet::resolve($pdo, $uid, (string) $d['owner_type'], (int) $d['owner_id'], $pick)
                : (Wallet::assigned($pdo, 'domain', $id) ?: Wallet::defaultCard($pdo, (string) $d['owner_type'], (int) $d['owner_id'])), $d['env'] === 'sandbox');
            if ($card && !self::inPlace($pdo, (string) $d['owner_type'], (int) $d['owner_id'], fn () => Wallet::usable($pdo, $card), $d['env'] === 'sandbox')) $card = null;   // a test domain renews only on a test card, a real one only on a real card
            if (!$card) throw new InvalidArgumentException('Add a card to the wallet first: auto-renew charges it two weeks before ' . $d['domain'] . ' runs out.');
            Wallet::assign($pdo, (int) $card['id'], 'domain', $id);
            $pdo->prepare('UPDATE account_domains SET auto_renew = 1, updated_at = ? WHERE id = ?')->execute([self::now(), $id]);
            self::event($pdo, $id, 'auto_renew', 'Auto-renew on, on ' . $card['label'], null, $uid);
            return 'It renews each year on ' . $card['label'] . ', two weeks before it runs out.';
        }
        $pdo->prepare('UPDATE account_domains SET auto_renew = 0, renew_next = NULL, updated_at = ? WHERE id = ?')->execute([self::now(), $id]);
        Wallet::release($pdo, 'domain', $id);
        self::event($pdo, $id, 'auto_renew', 'Auto-renew off', null, $uid);
        return 'It won\'t renew by itself. It stays yours until ' . ($d['expires_at'] ? date('M j, Y', strtotime((string) $d['expires_at'])) : 'its date') . '; Renew now any time.';
    }

    /** Renew now: a year paid at once, on a wallet card or a new one ($pick). Returns the order id. */
    public static function renewNow(PDO $pdo, int $uid, int $id, string $pick): int
    {
        $d = self::mine($pdo, $uid, $id, true);
        if ($d['source'] !== 'bought' || !in_array($d['status'], ['active', 'expired'], true)) throw new InvalidArgumentException('Only a domain registered through us renews here.');
        if ($d['expires_at'] && strtotime((string) $d['expires_at']) > strtotime('+9 years')) throw new InvalidArgumentException('It\'s paid up for as long as a domain can be (10 years).');
        [$price, $cost] = self::renewPrice($pdo, $d);
        $oid = self::pay($pdo, $uid, (string) $d['owner_type'], (int) $d['owner_id'], [['kind' => 'renewal', 'domain' => $d['domain'], 'domain_id' => $id, 'cents' => $price, 'cost' => $cost, 'renew' => $price, 'renew_cost' => $cost, 'who' => []]], $pick);
        if (preg_match('/^wallet:(\d+)$/', $pick, $m) && (int) $d['auto_renew']) Wallet::assign($pdo, (int) $m[1], 'domain', $id);
        return $oid;
    }

    /** A renewal declined before is tried at once (a new card was put on it). */
    public static function retryRenewal(PDO $pdo, int $id): void
    {
        $d = self::get($pdo, $id);
        if ($d && (int) $d['renew_fails'] > 0 && (int) $d['auto_renew']) self::autoRenew($pdo, $d);
    }

    /** Auto-renew, from the job: the assigned card first, then Name.com. 'renewed' | 'retry' | 'failed' | 'skipped'. */
    public static function autoRenew(PDO $pdo, array $d): string
    {
        if ($d['source'] !== 'bought' || !(int) $d['auto_renew'] || !in_array($d['status'], ['active', 'expired'], true)) return 'skipped';
        $id = (int) $d['id'];
        $card = Wallet::assigned($pdo, 'domain', $id);
        require_once __DIR__ . '/Billing.php';
        $o = Billing::owner($pdo, (string) $d['owner_type'], (int) $d['owner_id']);
        if (!$card) return self::renewDeclined($pdo, $d, 'there\'s no card for its renewals', $o);
        [$price, $cost] = self::renewPrice($pdo, $d);
        try {
            self::pay($pdo, 0, (string) $d['owner_type'], (int) $d['owner_id'], [['kind' => 'renewal', 'domain' => $d['domain'], 'domain_id' => $id, 'cents' => $price, 'cost' => $cost, 'renew' => $price, 'renew_cost' => $cost, 'who' => []]], '', false, true);
            return 'renewed';
        } catch (Throwable $x) {
            if ($x->getCode() === 503) return 'retry';   // QuickBooks didn't answer: the next run tries again, the same key
            return self::renewDeclined($pdo, $d, $x->getMessage(), $o);
        }
    }

    private static function renewDeclined(PDO $pdo, array $d, string $why, array $o): string
    {
        $id = (int) $d['id']; $fails = (int) $d['renew_fails'] + 1;
        $last = $fails > count(self::RETRY_DAYS);
        $next = $last ? null : date('Y-m-d', strtotime('+' . self::RETRY_DAYS[$fails - 1] . ' days'));
        $pdo->prepare('UPDATE account_domains SET renew_fails = ?, renew_next = ?, attention = ?, updated_at = ? WHERE id = ?')
            ->execute([$fails, $next, $last ? mb_substr('Auto-renew declined ' . $fails . ' times: ' . $why, 0, 300) : '', self::now(), $id]);
        self::event($pdo, $id, 'renew_declined', 'Auto-renew couldn\'t be paid (' . mb_substr($why, 0, 160) . ')' . ($next ? '; tried again ' . date('M j', strtotime($next)) : '; no more tries: renew now, or it runs out ' . date('M j, Y', strtotime((string) $d['expires_at']))));
        if ($o['email'] !== '') {
            require_once __DIR__ . '/Mailer.php';
            try { Mailer::send($o['email'], 'We couldn\'t renew ' . $d['domain'], "Hello,\n\nWe tried to renew " . $d['domain'] . ' (it runs out ' . date('F j, Y', strtotime((string) $d['expires_at'])) . ") but couldn't: " . $why . ".\n\n"
                . ($next ? 'We\'ll try again on ' . date('F j', strtotime($next)) . '. ' : 'We won\'t try again by ourselves. ') . "To keep it, replace the card or renew it now:\n" . self::tabUrl((string) $d['owner_type'], (int) $d['owner_id']) . '#d' . $id
                . "\n\nA new card is tried at once. Questions: support@traversence.com.\n"); } catch (Throwable $x) { error_log('domains renew mail: ' . $x->getMessage()); }
        }
        return 'failed';
    }

    // ---- where it points ---------------------------------------------------------------------------------------------

    /** Forwards the domain to another address (Name.com's URL forwarding). */
    public static function forward(PDO $pdo, int $uid, int $id, string $to): string
    {
        $d = self::bought($pdo, $uid, $id);
        $to = trim($to);
        if (!preg_match('#^https?://#i', $to)) $to = 'https://' . $to;
        if (!filter_var($to, FILTER_VALIDATE_URL) || strlen($to) > 480) throw new InvalidArgumentException('That doesn\'t look like a web address. Type it like https://example.com/page.');
        $host = strtolower((string) parse_url($to, PHP_URL_HOST));
        if ($host === $d['domain'] || $host === 'www.' . $d['domain']) throw new InvalidArgumentException('It can\'t forward to itself.');
        self::nc($pdo, $d, function () use ($d, $to) {
            if (self::mode() === 'mock') return;
            foreach ([$d['domain'], 'www.' . $d['domain']] as $h) {
                try { Domains::api('DELETE', '/v4/domains/' . rawurlencode($d['domain']) . '/url/forwarding/' . rawurlencode($h), null); } catch (Throwable) {}   // none there yet is fine
                Domains::api('POST', '/v4/domains/' . rawurlencode($d['domain']) . '/url/forwarding', ['host' => $h, 'forwardsTo' => $to, 'type' => 'redirect']);
            }
        });
        $pdo->prepare("UPDATE account_domains SET points = 'forward', forward_to = ?, updated_at = ? WHERE id = ?")->execute([$to, self::now(), $id]);
        self::event($pdo, $id, 'points', 'Forwards to ' . $to, null, $uid);
        return $d['domain'] . ' now forwards to ' . $to . '. It can take a few minutes to start.';
    }

    /** Its DNS records at Name.com: [{id, host, type, answer, ttl, priority}]. */
    public static function records(PDO $pdo, int $uid, int $id): array
    {
        $d = self::bought($pdo, $uid, $id, false);
        if (self::mode() === 'mock') return array_values((array) json_decode(self::env('DOMAINS_MOCK_RECORDS', '[]'), true));
        $r = self::nc($pdo, $d, fn () => Domains::api('GET', '/v4/domains/' . rawurlencode($d['domain']) . '/records', null));
        return array_map(fn ($x) => ['id' => (int) ($x['id'] ?? 0), 'host' => (string) ($x['host'] ?? ''), 'type' => (string) ($x['type'] ?? ''), 'answer' => (string) ($x['answer'] ?? ''), 'ttl' => (int) ($x['ttl'] ?? 300), 'priority' => (int) ($x['priority'] ?? 0)],
            (array) ($r['records'] ?? []));
    }

    /** Adds or changes a record ($rec: id (0 new), host, type, answer, ttl, priority). */
    public static function saveRecord(PDO $pdo, int $uid, int $id, array $rec): string
    {
        $d = self::bought($pdo, $uid, $id);
        $type = strtoupper(trim((string) ($rec['type'] ?? '')));
        if (!in_array($type, self::RECORD_TYPES, true)) throw new InvalidArgumentException('Choose the record\'s type: ' . implode(', ', self::RECORD_TYPES) . '.');
        $host = strtolower(trim((string) ($rec['host'] ?? '')));
        if ($host === '@') $host = '';
        if ($host !== '' && !preg_match('/^(\*|[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?)(\.[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?)*$/', $host)) throw new InvalidArgumentException('The name should be like www or mail (blank or @ for ' . $d['domain'] . ' itself).');
        $ans = trim((string) ($rec['answer'] ?? ''));
        if ($ans === '' || strlen($ans) > 1000) throw new InvalidArgumentException('Add what the record points to.');
        if ($type === 'A' && !filter_var($ans, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) throw new InvalidArgumentException('An A record points to an IPv4 address, like 203.0.113.10.');
        if ($type === 'AAAA' && !filter_var($ans, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) throw new InvalidArgumentException('An AAAA record points to an IPv6 address.');
        if (in_array($type, ['CNAME', 'MX'], true) && !preg_match('/^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}\.?$/i', $ans)) throw new InvalidArgumentException('A ' . $type . ' record points to a host name, like mail.example.com.');
        $ttl = max(300, min(86400, (int) ($rec['ttl'] ?? 300)));
        $body = ['host' => $host, 'type' => $type, 'answer' => $ans, 'ttl' => $ttl] + ($type === 'MX' ? ['priority' => max(0, min(65535, (int) ($rec['priority'] ?? 10)))] : []);
        $rid = (int) ($rec['id'] ?? 0);
        self::nc($pdo, $d, function () use ($d, $rid, $body) {
            if (self::mode() === 'mock') return;
            if ($rid > 0) Domains::api('PUT', '/v4/domains/' . rawurlencode($d['domain']) . '/records/' . $rid, $body);
            else Domains::api('POST', '/v4/domains/' . rawurlencode($d['domain']) . '/records', $body);
        });
        if ($d['points'] !== 'dns') $pdo->prepare("UPDATE account_domains SET points = 'dns', updated_at = ? WHERE id = ?")->execute([self::now(), $id]);
        self::event($pdo, $id, 'dns', ($rid ? 'Changed' : 'Added') . ' a ' . $type . ' record: ' . ($host === '' ? '@' : $host) . ' → ' . mb_substr($ans, 0, 120), null, $uid);
        return 'Saved. DNS changes reach everyone within an hour or so.';
    }

    public static function deleteRecord(PDO $pdo, int $uid, int $id, int $rid): string
    {
        $d = self::bought($pdo, $uid, $id);
        if ($rid <= 0) throw new InvalidArgumentException('Choose a record.');
        self::nc($pdo, $d, function () use ($d, $rid) { if (self::mode() !== 'mock') Domains::api('DELETE', '/v4/domains/' . rawurlencode($d['domain']) . '/records/' . $rid, null); });
        self::event($pdo, $id, 'dns', 'Removed a DNS record (#' . $rid . ')', null, $uid);
        return 'Removed.';
    }

    /** Nameservers set elsewhere ($list), or back to Name.com's ([] : its own DNS records here). */
    public static function setNameservers(PDO $pdo, int $uid, int $id, array $list): string
    {
        $d = self::bought($pdo, $uid, $id);
        $ns = array_values(array_unique(array_filter(array_map(fn ($x) => strtolower(rtrim(trim((string) $x), '.')), $list))));
        foreach ($ns as $n) if (!preg_match('/^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/', $n)) throw new InvalidArgumentException($n . ' doesn\'t look like a nameserver (like ns1.example.net).');
        if ($ns && count($ns) < 2) throw new InvalidArgumentException('Give at least two nameservers (your DNS host lists them).');
        if (count($ns) > 6) throw new InvalidArgumentException('Six nameservers at most.');
        $use = $ns ?: self::NAMECOM_NS;
        self::nc($pdo, $d, function () use ($d, $use) { if (self::mode() !== 'mock') Domains::api('POST', '/v4/domains/' . rawurlencode($d['domain']) . ':setNameservers', ['nameservers' => $use]); });
        $pdo->prepare('UPDATE account_domains SET points = ?, nameservers = ?, updated_at = ? WHERE id = ?')->execute([$ns ? 'nameservers' : 'dns', $ns ? json_encode($ns) : '', self::now(), $id]);
        self::event($pdo, $id, 'points', $ns ? 'Nameservers set to ' . implode(', ', $ns) : 'Back on Name.com\'s nameservers: its DNS records are edited here', null, $uid);
        return $ns ? 'Its nameservers are ' . implode(', ', $ns) . ' now. Its records are set at that DNS host; changes can take up to a day to reach everyone.' : 'Back on Name.com\'s nameservers: edit its records here.';
    }

    /** The email records (DKIM) when SES sends for the domain (0137 §8): [[name, type, value], …]; [] when SES isn't set up. */
    public static function emailRecords(array $d): array
    {
        $out = [];
        foreach ((array) json_decode((string) ($d['dkim'] ?? ''), true) as $t) $out[] = [$t . '._domainkey', 'CNAME', $t . '.dkim.amazonses.com'];
        return $out;
    }

    /** Asks SES for the domain's three DKIM records (once SES sends mail), and keeps them on the row. */
    public static function dkim(PDO $pdo, int $id): void
    {
        $d = self::get($pdo, $id); if (!$d) return;
        try {
            require_once __DIR__ . '/SesMail.php';
            if (SesMail::mode() === 'off') return;
            $acct = SesMail::hasKeys('bulk') ? 'bulk' : (SesMail::hasKeys('personal') ? 'personal' : '');
            if ($acct === '') return;
            if (SesMail::mode() === 'mock' || self::mode() === 'mock') $tokens = ['mock1' . substr(md5($d['domain']), 0, 6), 'mock2' . substr(md5($d['domain']), 0, 6), 'mock3' . substr(md5($d['domain']), 0, 6)];
            else {
                [$code, $res] = SesMail::api($acct, 'POST', '/v2/email/identities', ['EmailIdentity' => $d['domain']]);
                if ($code !== 200) [$code, $res] = SesMail::api($acct, 'GET', '/v2/email/identities/' . rawurlencode((string) $d['domain']));
                $tokens = (array) ((json_decode((string) $res, true) ?: [])['DkimAttributes']['Tokens'] ?? []);
            }
            if ($tokens) $pdo->prepare('UPDATE account_domains SET dkim = ? WHERE id = ?')->execute([json_encode(array_values($tokens)), $id]);
        } catch (Throwable $x) { error_log('account domains dkim ' . $d['domain'] . ': ' . $x->getMessage()); }
    }

    /** Sets the email records at Name.com for a domain registered through us (one tap). */
    public static function addEmailRecords(PDO $pdo, int $uid, int $id): string
    {
        $d = self::bought($pdo, $uid, $id);
        if (!$d['dkim']) self::dkim($pdo, $id);
        $d = self::get($pdo, $id);
        $recs = self::emailRecords($d);
        if (!$recs) throw new InvalidArgumentException('Email from your own domain opens once Traversence\'s email service sends for it.');
        foreach ($recs as [$n, $t, $v]) self::nc($pdo, $d, function () use ($d, $n, $t, $v) { if (self::mode() !== 'mock') Domains::api('POST', '/v4/domains/' . rawurlencode($d['domain']) . '/records', ['host' => $n, 'type' => $t, 'answer' => $v, 'ttl' => 300]); });
        self::event($pdo, $id, 'email', 'Email records (DKIM) added', null, $uid);
        return 'Added. They\'re checked within the hour.';
    }

    /** Checks the email records answer (DNS), and keeps the result. */
    public static function checkEmail(PDO $pdo, int $id): bool
    {
        $d = self::get($pdo, $id); if (!$d) return false;
        $ok = (bool) self::emailRecords($d);
        foreach (self::emailRecords($d) as [$n, , $v]) if (!in_array($v, (array) (Domains::lookup($n . '.' . $d['domain'])['CNAME'] ?? []), true)) { $ok = false; break; }
        $pdo->prepare('UPDATE account_domains SET email_ok = ? WHERE id = ?')->execute([$ok ? 1 : 0, $id]);
        return $ok;
    }

    /** Transfer away: unlocks it at Name.com and returns its code, shown once (it's never kept here). Auto-renew stops. */
    public static function transferCode(PDO $pdo, int $uid, int $id): string
    {
        $d = self::bought($pdo, $uid, $id);
        $code = (string) self::nc($pdo, $d, function () use ($d) {
            if (self::mode() === 'mock') return 'MOCK-AUTH-' . strtoupper(substr(md5($d['domain']), 0, 8));
            Domains::api('POST', '/v4/domains/' . rawurlencode($d['domain']) . ':unlock', []);
            return (string) (Domains::api('GET', '/v4/domains/' . rawurlencode($d['domain']) . ':getAuthCode', null)['authCode'] ?? '');
        });
        if ($code === '') throw new RuntimeException('Name.com didn\'t give the code. Try again, or write to support@traversence.com.');
        $pdo->prepare('UPDATE account_domains SET auto_renew = 0, updated_at = ? WHERE id = ?')->execute([self::now(), $id]);
        Wallet::release($pdo, 'domain', $id);
        self::event($pdo, $id, 'transfer_code', 'Unlocked, and its transfer code shown (not kept here). Auto-renew is off: the new registrar renews it.', null, $uid);
        return $code;
    }

    /** A domain registered through us and still here, this person may change; else it throws. */
    private static function bought(PDO $pdo, int $uid, int $id, bool $change = true): array
    {
        $d = self::mine($pdo, $uid, $id);
        if ($d['source'] !== 'bought') throw new InvalidArgumentException('Its records are set where it\'s registered: this one is listed for pointing only.');
        if ($change && $d['status'] !== 'active') throw new InvalidArgumentException($d['domain'] . ' is ' . strtolower(self::STATUSES[$d['status']] ?? $d['status']) . ': renew it first.');
        return $d;
    }

    /** A Name.com call for this domain, in its sandbox when it's a test registration. */
    private static function nc(PDO $pdo, array $d, callable $f)
    {
        return self::inPlace($pdo, (string) $d['owner_type'], (int) $d['owner_id'], $f, $d['env'] === 'sandbox');
    }

    // ---- support tickets ----------------------------------------------------------------------------------------------

    /**
     * Something isn't right: a support ticket. On the domain's latest order when it has one (as orders' tickets work:
     * order_feedback 'problem', a Support case in the Pulse, replies by email); a brought domain's is its own case.
     * Returns the ticket number.
     */
    public static function ticket(PDO $pdo, int $uid, int $id, string $words): int
    {
        $d = self::mine($pdo, $uid, $id);
        $words = mb_substr(trim($words), 0, 2000);
        if ($words === '') throw new InvalidArgumentException('Tell us what isn\'t right.');
        require_once __DIR__ . '/Pulse.php'; require_once __DIR__ . '/Orders.php'; require_once __DIR__ . '/Mailer.php';
        $st = $pdo->prepare("SELECT ol.order_id FROM order_lines ol JOIN orders o ON o.id = ol.order_id WHERE ol.ref_id = ? AND ol.product = 'product' AND ol.product_id IN (?, ?) AND o.status <> 'void' ORDER BY ol.order_id DESC LIMIT 1");
        $st->execute([$id, self::productId($pdo, 'purchase'), self::productId($pdo, 'renewal')]);
        $oid = (int) ($st->fetchColumn() ?: 0);
        $me = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ?'); $me->execute([$uid]); $u = $me->fetch(PDO::FETCH_ASSOC) ?: ['email' => '', 'display_name' => ''];
        $from = (string) ($u['display_name'] ?: $u['email']);
        $no = 0;
        if ($oid) {
            $pdo->prepare("INSERT INTO order_feedback (order_id, kind, rating, words, may_quote) VALUES (?, 'problem', NULL, ?, 0)")->execute([$oid, $d['domain'] . ': ' . $words]);
            $key = 'fb:' . (int) $pdo->lastInsertId();
            try { $no = Pulse::openTicket($pdo, $key, 'From ' . $from . ', about ' . $d['domain'] . ' (order #' . Orders::no(Orders::get($pdo, $oid)) . '): ' . $words); } catch (Throwable $x) { error_log('domain ticket: ' . $x->getMessage()); }
            Orders::event($pdo, $oid, 'problem', ($no ? 'Support ticket #' . $no . ': ' : '') . 'something isn\'t right with ' . $d['domain'] . ': "' . mb_strimwidth($words, 0, 200, '…') . '"', $uid);
        } else {
            $eid = self::event($pdo, $id, 'ticket', 'Something isn\'t right: ' . $words, null, $uid);
            $key = 'domtk:' . $eid;
            try { $no = Pulse::openTicket($pdo, $key, 'From ' . $from . ' (' . $u['email'] . '), about ' . $d['domain'] . ': ' . $words); } catch (Throwable $x) { error_log('domain ticket: ' . $x->getMessage()); }
        }
        if ($oid) self::event($pdo, $id, 'ticket', ($no ? 'Support ticket #' . $no . ': ' : '') . $words, $oid, $uid);
        $base = rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/');
        try { Mailer::send((string) (getenv('SUPPORT_EMAIL') ?: 'support@traversence.com'), 'Support ticket' . ($no ? ' #' . $no : '') . ': ' . $d['domain'], $from . ' (' . $u['email'] . ') says something isn\'t right with ' . $d['domain'] . ":\n\n" . $words . "\n\nThe case: " . $base . '/admin/pulse/stream#case=' . rawurlencode($key)); } catch (Throwable) {}
        if ($u['email'] !== '') { try { Mailer::send((string) $u['email'], 'We have your note about ' . $d['domain'] . ($no ? ' (ticket #' . $no . ')' : ''), "Hello,\n\nThank you for telling us. " . ($no ? 'Your ticket number is #' . $no . '. ' : '') . "We'll be in touch soon.\n\nWhat you told us:\n" . $words . "\n\nYour domains: " . self::tabUrl((string) $d['owner_type'], (int) $d['owner_id']) . "\n"); } catch (Throwable) {} }
        return $no;
    }

    // ---- our team: orders that need a person (Pulse) --------------------------------------------------------------------

    /** Domain orders with a Needs attention not yet cleared: [{order, line, note, at}], and brought domains' open tickets. */
    public static function attention(PDO $pdo): array
    {
        if (!self::ready($pdo)) return [];
        $p = self::productId($pdo, 'purchase'); $r = self::productId($pdo, 'renewal');
        $st = $pdo->prepare("SELECT e.order_id, e.line_id, e.note, e.created_at, e.id FROM order_events e WHERE e.event = 'needs_attention'
            AND EXISTS (SELECT 1 FROM order_lines ol WHERE ol.order_id = e.order_id AND ol.product_id IN (?, ?))
            AND NOT EXISTS (SELECT 1 FROM order_events c WHERE c.order_id = e.order_id AND c.event = 'attention_cleared' AND c.id > e.id) ORDER BY e.id DESC LIMIT 30");
        $st->execute([$p, $r]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $x) $out['domorder:' . $x['order_id']] = $out['domorder:' . $x['order_id']] ?? $x;
        // auto-renew out of tries (no order to hang it on when the card was missing): one case per domain
        foreach ($pdo->query("SELECT id, domain, attention, updated_at, renew_order FROM account_domains WHERE attention <> '' AND status IN ('active','expired') AND renew_fails > " . count(self::RETRY_DAYS) . ' LIMIT 30')->fetchAll(PDO::FETCH_ASSOC) as $d)
            $out['domrenew:' . $d['id']] = ['order_id' => (int) ($d['renew_order'] ?? 0), 'line_id' => null, 'note' => $d['domain'] . ': ' . $d['attention'], 'created_at' => $d['updated_at'], 'domain_id' => (int) $d['id']];
        return $out;
    }

    /** Steps for a domain case (Pulse::playbook). */
    public static function pulseSteps(PDO $pdo, string $key, callable $s): array
    {
        $tell = ['form', 'dom_tell', 'Email the owner', [['text', 'What to tell them (they get it by email)', 'textarea', '']]];
        if (str_starts_with($key, 'domrenew:')) return [
            $s('See what happened', 'Its card was declined on each try, or there was no card. The owner was emailed each time with Replace card and Renew now.', ['tool', '/admin/backoffice/orders']),
            ['t' => 'Email the owner', 'h' => 'A word before it runs out: the domain goes to Name.com\'s grace period after its date, then can be lost.', 'act' => $tell, 'auto' => false],
            $s('Resolve the case', 'It closes on its own once it\'s renewed.', ['do', 'dom_clear', 'Clear it']),
        ];
        if (str_starts_with($key, 'domtk:')) return [
            ['t' => 'Answer them', 'h' => 'Their words are the case\'s first entry. Your answer goes to them by email.', 'act' => $tell, 'auto' => false],
            $s('Resolve the case', '', ['resolve']),
        ];
        $oid = (int) substr($key, 9);
        return [
            $s('Read the order', 'Its events say what Name.com answered and whether the refund went through.', ['tool', '/admin/backoffice/orders/' . $oid]),
            ['t' => 'Try again at Name.com', 'h' => 'Registers or renews what was paid for and not done. Nothing is charged again.', 'act' => ['do', 'dom_retry', 'Try again'], 'auto' => false, 'ext' => ['Name.com', 'https://www.name.com/account/domain']],
            ['t' => 'Or refund it', 'h' => 'Refunds what wasn\'t done to the card it was paid with.', 'act' => ['do', 'dom_refund', 'Refund'], 'auto' => false],
            ['t' => 'Email the owner', 'h' => 'Say what happened and what\'s next.', 'act' => $tell, 'auto' => false],
            $s('Resolve the case', 'Try again or Refund clears it.', ['do', 'dom_clear', 'Clear it']),
        ];
    }

    /** A step done from the case (Pulse::manage). */
    public static function pulseDo(PDO $pdo, string $key, string $what, array $a, int $staff): string
    {
        require_once __DIR__ . '/Orders.php'; require_once __DIR__ . '/QuickBooksPay.php';
        if (str_starts_with($key, 'domtk:')) {
            $st = $pdo->prepare('SELECT d.*, e.actor FROM domain_events e JOIN account_domains d ON d.id = e.domain_id WHERE e.id = ?'); $st->execute([(int) substr($key, 6)]);
            $d = $st->fetch(PDO::FETCH_ASSOC); if (!$d) throw new RuntimeException('That domain isn\'t here.');
            if ($what === 'dom_tell') return self::tellOwner($pdo, $d, (string) ($a['text'] ?? ''), (int) $d['actor']);
            throw new RuntimeException('Unknown step.');
        }
        if (str_starts_with($key, 'domrenew:')) {
            $d = self::get($pdo, (int) substr($key, 9)); if (!$d) throw new RuntimeException('That domain isn\'t here.');
            if ($what === 'dom_tell') return self::tellOwner($pdo, $d, (string) ($a['text'] ?? ''));
            if ($what === 'dom_clear') { $pdo->prepare("UPDATE account_domains SET attention = '' WHERE id = ?")->execute([(int) $d['id']]); return 'Cleared.'; }
            throw new RuntimeException('Unknown step.');
        }
        $oid = (int) substr($key, 9);
        $o = Orders::get($pdo, $oid); if (!$o) throw new RuntimeException('That order isn\'t here.');
        $open = [];
        foreach (Orders::lines($pdo, $oid) as $l) if (in_array((int) $l['product_id'], [self::productId($pdo, 'purchase'), self::productId($pdo, 'renewal')], true) && $l['status'] !== 'done') $open[] = $l;
        $sandbox = ($o['qb_env'] ?? '') === 'sandbox';
        if ($what === 'dom_clear') { Orders::event($pdo, $oid, 'attention_cleared', 'Cleared by our team', $staff); return 'Cleared.'; }
        if ($what === 'dom_tell') {
            $d = $open && $open[0]['ref_id'] ? self::get($pdo, (int) $open[0]['ref_id']) : null;
            if (!$d) { $t = trim((string) ($a['text'] ?? '')); if ($t === '' || (string) $o['bill_email'] === '') throw new RuntimeException('Write what to tell them.'); require_once __DIR__ . '/Mailer.php'; Mailer::send((string) $o['bill_email'], 'About your order #' . Orders::no($o), $t . "\n\n— Traversence (support@traversence.com)"); Orders::event($pdo, $oid, 'note', 'Emailed the owner: ' . mb_strimwidth($t, 0, 200, '…'), $staff); return 'Sent.'; }
            return self::tellOwner($pdo, $d, (string) ($a['text'] ?? ''));
        }
        if (!$open) { Orders::event($pdo, $oid, 'attention_cleared', 'Nothing left to do on it', $staff); return 'Nothing is waiting on this order now.'; }
        if ($what === 'dom_refund') {
            $sum = 0;
            foreach ($open as $l) {
                $c = (int) $l['unit_cents'];
                if (in_array('refund-' . $l['id'], array_column(Orders::ledger($pdo, $oid), 'request_key'), true)) continue;
                $ref = Domains::asSandbox($sandbox, fn () => Wallet::asSandbox($sandbox, fn () => Wallet::sandboxFor($pdo, '', 0, fn () => QuickBooksPay::refundCharge($pdo, (string) ($o['charge_id'] ?? ''), $c, 'Domain order ' . Orders::no($o) . ': not done', 'domrefund-' . $l['id']))));
                Orders::record($pdo, $oid, 'refund', $c, 'refund-' . $l['id'], 'card', '', 'refund ' . $ref);
                $pdo->prepare("UPDATE order_lines SET status = 'cancelled' WHERE id = ?")->execute([(int) $l['id']]);
                $sum += $c;
            }
            Orders::event($pdo, $oid, 'refund', 'Refunded ' . Orders::usd($sum) . ' by our team', $staff);
            Orders::event($pdo, $oid, 'attention_cleared', 'Refunded', $staff);
            return 'Refunded ' . Orders::usd($sum) . '.';
        }
        if ($what === 'dom_retry') {
            $did = 0;
            foreach ($open as $l) {
                $isRenew = (int) $l['product_id'] === self::productId($pdo, 'renewal');
                $domain = (string) preg_replace('/^Domain (Purchase|Renewal): ([^,]+),.*$/', '$2', (string) $l['title']);
                $spec = ['kind' => $isRenew ? 'renewal' : 'purchase', 'domain' => $domain, 'domain_id' => (int) $l['ref_id'], 'cents' => (int) $l['unit_cents'], 'cost' => (int) $l['cost_cents'], 'renew' => (int) $l['unit_cents'], 'renew_cost' => (int) $l['cost_cents'], 'who' => []];
                if (!$isRenew) {
                    $dc = $pdo->prepare('SELECT who, renew_cents, renew_cost_cents, owner_type, owner_id FROM domain_cart WHERE user_id = ? AND domain = ? ORDER BY id DESC LIMIT 1'); $dc->execute([(int) $o['user_id'], $domain]);
                    $row = $dc->fetch(PDO::FETCH_ASSOC) ?: null;
                    if (!$row) throw new RuntimeException('The registrant\'s details for ' . $domain . ' aren\'t here any more: refund it, and ask them to buy it again.');
                    $spec['who'] = (array) ((json_decode((string) $row['who'], true) ?: [])['contact'] ?? []); $spec['renew'] = (int) $row['renew_cents']; $spec['renew_cost'] = (int) $row['renew_cost_cents'];
                    $card = Wallet::asSandbox($sandbox, fn () => Wallet::defaultCard($pdo, (string) $row['owner_type'], (int) $row['owner_id']));
                    Domains::asSandbox($sandbox, function () use ($pdo, $o, $row, $spec, $oid, $card, $sandbox, $l, &$did) {
                        $did = self::register($pdo, (int) $o['user_id'], (string) $row['owner_type'], (int) $row['owner_id'], $spec, $oid, $card ? (int) $card['id'] : 0, $sandbox);
                        $pdo->prepare("UPDATE order_lines SET status = 'done', ref_id = ? WHERE id = ?")->execute([$did, (int) $l['id']]);
                    });
                } else {
                    Domains::asSandbox($sandbox, fn () => self::renewAt($pdo, $staff, $spec, $oid, $sandbox));
                    $pdo->prepare("UPDATE order_lines SET status = 'done' WHERE id = ?")->execute([(int) $l['id']]);
                }
                Orders::event($pdo, $oid, 'done', 'Done at Name.com on a retry by our team: ' . $domain, $staff, (int) $l['id']);
            }
            Orders::event($pdo, $oid, 'attention_cleared', 'Done on a retry', $staff);
            return 'Done at Name.com.';
        }
        throw new RuntimeException('Unknown step.');
    }

    private static function tellOwner(PDO $pdo, array $d, string $text, int $uid = 0): string
    {
        $text = trim($text);
        if ($text === '') throw new RuntimeException('Write what to tell them.');
        require_once __DIR__ . '/Billing.php'; require_once __DIR__ . '/Mailer.php';
        $to = '';
        if ($uid) { $st = $pdo->prepare('SELECT email FROM users WHERE id = ?'); $st->execute([$uid]); $to = (string) ($st->fetchColumn() ?: ''); }
        if ($to === '') $to = (string) Billing::owner($pdo, (string) $d['owner_type'], (int) $d['owner_id'])['email'];
        if ($to === '') throw new RuntimeException('The account has no email address.');
        Mailer::send($to, 'About ' . $d['domain'], $text . "\n\nYour domains: " . self::tabUrl((string) $d['owner_type'], (int) $d['owner_id']) . "\n— Traversence (support@traversence.com)");
        self::event($pdo, (int) $d['id'], 'note', 'Our team wrote: ' . mb_strimwidth($text, 0, 300, '…'));
        return 'Sent to ' . $to . '.';
    }

    // ---- the job ----------------------------------------------------------------------------------------------------

    /**
     * From domains_tick (every 15 minutes): auto-renewals due (14 days ahead; declines tried again 3 and 7 days later),
     * domains past their date marked Expired, moved-away ones noticed, and the wallet's expiry reminders. [renewed, failed, expired]
     */
    public static function tick(PDO $pdo): array
    {
        if (!self::ready($pdo) || self::mode() === 'off') return [0, 0, 0];
        $renewed = 0; $failed = 0; $expired = 0;
        $st = $pdo->prepare("SELECT * FROM account_domains WHERE source = 'bought' AND auto_renew = 1 AND status IN ('active','expired') AND expires_at < ? AND (renew_next IS NULL OR renew_next <= ?) AND renew_fails <= ? AND updated_at < ? LIMIT 25");
        $st->execute([date('Y-m-d H:i:s', strtotime('+' . self::RENEW_AHEAD_DAYS . ' days')), date('Y-m-d'), count(self::RETRY_DAYS), date('Y-m-d H:i:s', strtotime('-10 minutes'))]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $d) {
            $paid = $pdo->prepare("SELECT 1 FROM domain_events WHERE domain_id = ? AND kind = 'renewed' AND created_at > ?"); $paid->execute([(int) $d['id'], date('Y-m-d H:i:s', strtotime('-' . (self::RENEW_AHEAD_DAYS + 2) . ' days'))]);
            if ($paid->fetchColumn()) continue;   // renewed for this term already
            $r = self::autoRenew($pdo, $d);
            if ($r === 'renewed') $renewed++; elseif ($r === 'failed') $failed++;
        }
        $x = $pdo->prepare("UPDATE account_domains SET status = 'expired', updated_at = ? WHERE source = 'bought' AND status = 'active' AND expires_at < ?"); $x->execute([self::now(), self::now()]);
        $expired = $x->rowCount();
        if (self::mode() !== 'mock' && (int) date('i') < 15) {   // hourly: a domain whose transfer code was shown and that has left Name.com is Moved away
            $st = $pdo->query("SELECT d.* FROM account_domains d WHERE d.source = 'bought' AND d.status = 'active' AND EXISTS (SELECT 1 FROM domain_events e WHERE e.domain_id = d.id AND e.kind = 'transfer_code' AND e.created_at > DATE_SUB(NOW(), INTERVAL 60 DAY)) LIMIT 10");
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $d) {
                try { self::nc($pdo, $d, fn () => Domains::api('GET', '/v4/domains/' . rawurlencode((string) $d['domain']), null)); }
                catch (Throwable $e) {
                    if (!str_contains($e->getMessage(), 'Not Found') && !str_contains($e->getMessage(), '404')) continue;
                    $pdo->prepare("UPDATE account_domains SET status = 'transferred', auto_renew = 0, updated_at = ? WHERE id = ?")->execute([self::now(), (int) $d['id']]);
                    Wallet::release($pdo, 'domain', (int) $d['id']);
                    self::event($pdo, (int) $d['id'], 'transferred', 'It has moved to another registrar');
                }
            }
        }
        if ((int) date('G') === 9 && (int) date('i') < 15) Wallet::tick($pdo);   // once a day
        if ((int) date('i') < 15) { foreach ($pdo->query("SELECT id FROM account_domains WHERE dkim IS NOT NULL AND dkim <> '' AND email_ok = 0 AND status = 'active' LIMIT 20")->fetchAll(PDO::FETCH_COLUMN) as $i) { try { self::checkEmail($pdo, (int) $i); } catch (Throwable) {} } }
        $pdo->prepare("DELETE dc FROM domain_cart dc LEFT JOIN cart_plans cp ON cp.owner_type = 'oneoff' AND cp.item IN ('domain_purchase','domain_renewal') AND cp.owner_id = dc.id WHERE cp.id IS NULL AND dc.created_at < ?")->execute([date('Y-m-d H:i:s', strtotime('-30 days'))]);   // left carts' details (registrants) aren't kept
        return [$renewed, $failed, $expired];
    }

    // ---- for the pages ----------------------------------------------------------------------------------------------

    /** The account's Domains tab. */
    public static function tabUrl(string $type, int $id): string
    {
        $base = rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/');
        return $type === 'listing' ? $base . '/business/' . $id . '/domains' : $base . '/user/domains/';
    }

    /** A domain as its tab shows it. */
    public static function shape(PDO $pdo, array $d): array
    {
        $card = $d['source'] === 'bought' ? Wallet::assigned($pdo, 'domain', (int) $d['id']) : null;
        return ['id' => (int) $d['id'], 'domain' => (string) $d['domain'], 'source' => (string) $d['source'], 'status' => (string) $d['status'], 'status_label' => self::STATUSES[$d['status']] ?? $d['status'],
            'test' => $d['env'] === 'sandbox', 'points' => (string) $d['points'], 'points_label' => self::POINTS[$d['points']] ?? '', 'forward_to' => (string) $d['forward_to'],
            'nameservers' => (array) (json_decode((string) $d['nameservers'], true) ?: []), 'auto_renew' => (bool) (int) $d['auto_renew'], 'renew_cents' => (int) $d['renew_cents'],
            'expires_at' => $d['expires_at'] ? date('c', strtotime((string) $d['expires_at'])) : null, 'registered_at' => $d['registered_at'] ? date('c', strtotime((string) $d['registered_at'])) : null,
            'card' => $card ? ['id' => (int) $card['id'], 'label' => (string) $card['label']] : null, 'email' => self::emailRecords($d), 'email_ok' => (bool) (int) $d['email_ok'],
            'renew_fails' => (int) $d['renew_fails'], 'renew_next' => $d['renew_next'], 'attention' => (string) $d['attention']];
    }
}
