<?php

declare(strict_types=1);

require_once __DIR__ . '/SearchIndex.php';
require_once __DIR__ . '/UniversalSearch.php';

/**
 * api/lib/SearchPresets.php — one-tap searches per place, from the system, never from admins (decisions/0053 §5).
 *
 * Each preset is a 5W question filled in ahead of time ("Places to eat", "Things to do this weekend", "Open now",
 * "Where to get help"). Which ones show, and in what order, comes from aggregate signals only:
 *   - what's there: how many things in the place answer it (from the 5W index);
 *   - the time: meal times put food first, the weekend puts things to do first, evenings put "Open now" up;
 *   - what's asked there: counts of the question's reading (why:eat, cat:pharmacies) per place per day, counted when
 *     someone picks a result, never the words typed and never who asked (search_counts, kept 90 days).
 * A category shows as its own preset only once it has been asked about at least 3 times in 30 days in that place.
 * A person's own quick searches (kept on their device) are counted too (mine(): Jason, 2026-11-22, "Count them").
 */
final class SearchPresets
{
    /** [reading key, label, query, base weight] */
    private const BASE = [
        ['why:eat', 'Places to eat', 'places to eat', 50],
        ['why:explore', 'Things to do', 'things to do', 48],
        ['when:now', 'Open now', 'open now', 38],
        ['why:stay', 'Where to stay', 'where to stay', 34],
        ['why:heal', 'Health care', 'see a doctor', 30],
        ['why:help', 'Where to get help', 'get help', 30],
        ['why:buy', 'Shopping', 'shopping', 26],
        ['kind:group', 'Groups', 'groups', 22],
        ['why:learn', 'Learning', 'to learn', 14],
        ['why:connect', 'Meeting people', 'meet people', 12],
    ];
    private const MIN_CATEGORY_ASKS = 3;

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM search_counts LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    /**
     * @param ?array $place a place chip (from the visitor's scope or a place named in $near), or null for anywhere
     * @param array  $at    [day of week 0-6, minute of the day], the visitor's own time
     * @param string $near  the place's words, added to each query when the place isn't the visitor's scope
     * @return list<array{label: string, q: string, count: ?int}>
     */
    public static function forPlace(PDO $pdo, ?array $place, array $at, string $near = ''): array
    {
        if (!SearchIndex::ready($pdo) || SearchIndex::state($pdo, 'built_listing') === '') return [];
        [$dow, $min] = $at + [0, 720];
        $hour = intdiv((int) $min, 60);
        $have = self::have($pdo, $place);
        $asked = self::asked($pdo, (string) ($place['key'] ?? ''));
        $out = [];
        foreach (self::BASE as [$k, $label, $q, $score]) {
            $n = $have[$k] ?? 0;
            if ($k === 'when:now' ? ($have['hours'] ?? 0) < 3 : $n < 1) continue;
            if ($k === 'why:eat') {
                $meal = $hour >= 6 && $hour < 10 ? 'Breakfast' : ($hour >= 11 && $hour < 14 ? 'Lunch' : ($hour >= 17 && $hour < 21 ? 'Dinner' : ''));
                if ($meal !== '') { $score += 15; $label = $meal; $q = mb_strtolower($meal); }
            }
            if ($k === 'why:explore' && ($dow === 6 || $dow === 0 || ($dow === 5 && $hour >= 12) || $dow === 4)) {
                $score += 12; $label = 'Things to do this weekend'; $q = 'things to do this weekend';
            }
            if ($k === 'when:now' && ($hour >= 17 || $hour < 7)) $score += 10;
            if ($k === 'why:stay' && ($dow === 5 || $dow === 6)) $score += 8;
            $score += (int) round(min(30, 8 * log(1 + ($asked[$k] ?? 0))));
            $out[] = ['label' => $label, 'q' => $q, 'count' => $k === 'when:now' ? null : $n, 'score' => $score];
        }
        // categories people here keep asking about
        foreach ($asked as $k => $n) {
            if (!str_starts_with($k, 'cat:') || $n < self::MIN_CATEGORY_ASKS) continue;
            $st = $pdo->prepare('SELECT name FROM categories WHERE slug = ? AND is_active = 1 LIMIT 1');
            $st->execute([substr($k, 4)]);
            if ($name = $st->fetchColumn()) $out[] = ['label' => (string) $name, 'q' => mb_strtolower((string) $name), 'count' => self::inCategory($pdo, $place, substr($k, 4)), 'score' => 28 + (int) round(min(30, 8 * log(1 + $n)))];
        }
        usort($out, fn ($a, $b) => $b['score'] <=> $a['score']);
        $out = array_slice($out, 0, 6);
        $near = trim($near);
        return array_map(fn ($p) => ['label' => $p['label'], 'q' => $p['q'] . ($near !== '' ? ' in ' . $near : ''), 'count' => $p['count']], $out);
    }

    /**
     * A person's own quick searches, counted for where they are (Jason, 2026-11-22: "Count them", B2's follow-up): each
     * phrase is run as the search it opens, with no side effects (no_side: nothing sent to the crawler or recorded as
     * demand, as while typing), and its total kept an hour per place and phrase, like have(). A phrase that changes by
     * the minute ("open now") gets no number (B2); one that finds nothing, or can't be run, shows no number rather than a
     * wrong one. The phrases come from the device; nothing about them or the person is stored.
     * @param list<string> $phrases at most 12, as kept by js/search-panel.js
     * @return list<array{q: string, count: ?int}>
     */
    public static function mine(PDO $pdo, array $ctx, array $phrases): array
    {
        $out = []; $seen = [];
        foreach (array_slice($phrases, 0, 12) as $q) {
            if (!is_string($q)) continue;
            $q = mb_substr(trim(preg_replace('/\s+/u', ' ', $q)), 0, 80);
            $low = mb_strtolower($q);
            if (mb_strlen($q) < 2 || isset($seen[$low])) continue;
            $seen[$low] = 1;
            $out[] = ['q' => $q, 'count' => self::countMine($pdo, $ctx, $q)];
        }
        return $out;
    }

    private static function countMine(PDO $pdo, array $ctx, string $q): ?int
    {
        try {
            $u = UniversalSearch::understand($pdo, $q, $ctx, []);
            foreach ($u['chips'] as $c) if (($c['type'] ?? '') === 'when' && ($c['value'] ?? '') === 'now') return null;   // by the minute (B2)
            $where = [$ctx['level'] ?? '', $ctx['slug'] ?? '', $ctx['town'] ?? '', $ctx['city'] ?? '', $ctx['state'] ?? '', $ctx['zip'] ?? '',
                isset($ctx['lat']) ? round((float) $ctx['lat'], 2) : '', isset($ctx['lon']) ? round((float) $ctx['lon'], 2) : '', $ctx['reach'] ?? '', $ctx['track'] ?? ''];
            $key = 'pm:' . substr(md5(json_encode([$where, mb_strtolower($q)])), 0, 20);
            $c = SearchIndex::state($pdo, $key);
            if ($c !== '' && ($j = json_decode($c, true)) && ($j['t'] ?? 0) > time() - 3600) return $j['n'] ?? null;
            $r = UniversalSearch::search($pdo, $q, $ctx + ['no_side' => 1]);
            $n = (int) ($r['results']['total'] ?? 0);   // what its Results tab says
            $n = $n > 0 ? $n : null;
            try { SearchIndex::setState($pdo, $key, json_encode(['t' => time(), 'n' => $n])); } catch (Throwable) {}
            return $n;
        } catch (Throwable $e) { error_log('quick search count: ' . $e->getMessage()); return null; }
    }

    /** How many things in the place answer each question (cached an hour per place). */
    /** How many listings here are in a category (its own and its sub-categories), for its Quick Search line (Jason,
     * 2026-11-22: counts on the rest); null when it can't be counted, so no number shows rather than a wrong one. */
    private static function inCategory(PDO $pdo, ?array $place, string $slug): ?int
    {
        try {
            $p = [':slug' => $slug, ':slug2' => $slug];
            $where = SearchIndex::whereSql($pdo, $place, null, $p);
            $st = $pdo->prepare("SELECT COUNT(*) FROM search_index si WHERE si.kind = 'listing' AND si.category_id IN (SELECT c.id FROM categories c LEFT JOIN categories pc ON pc.id = c.parent_id WHERE c.slug = :slug OR pc.slug = :slug2)" . ($where !== '' ? " AND $where" : ''));
            $st->execute($p);
            $n = (int) $st->fetchColumn();
            return $n > 0 ? $n : null;
        } catch (Throwable $e) { return null; }
    }

    private static function have(PDO $pdo, ?array $place): array
    {
        $key = 'pc:' . substr(md5(json_encode([$place['key'] ?? '', $place['slug'] ?? '', $place['zips'] ?? [], $place['state'] ?? ''])), 0, 20);
        $c = SearchIndex::state($pdo, $key);
        if ($c !== '' && ($j = json_decode($c, true)) && ($j['t'] ?? 0) > time() - 3600) return $j;
        $p = [];
        $where = SearchIndex::whereSql($pdo, $place, null, $p);
        $sum = [];
        foreach (['eat', 'explore', 'stay', 'heal', 'help', 'buy', 'learn', 'connect'] as $i => $w) { $sum[] = "SUM(CASE WHEN si.why LIKE :y$i THEN 1 ELSE 0 END) AS $w"; $p[":y$i"] = '%' . $w . '%'; }
        $sql = 'SELECT ' . implode(', ', $sum) . ", SUM(CASE WHEN si.kind = 'listing' AND si.hours IS NOT NULL THEN 1 ELSE 0 END) AS hours,
                       SUM(CASE WHEN si.kind = 'group' THEN 1 ELSE 0 END) AS grp
                  FROM search_index si WHERE si.kind <> 'topic'" . ($where !== '' ? " AND $where" : '');
        $st = $pdo->prepare($sql);
        $st->execute($p);
        $r = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        $out = ['t' => time(), 'hours' => (int) ($r['hours'] ?? 0), 'kind:group' => (int) ($r['grp'] ?? 0)];
        foreach (['eat', 'explore', 'stay', 'heal', 'help', 'buy', 'learn', 'connect'] as $w) $out['why:' . $w] = (int) ($r[$w] ?? 0);
        try { SearchIndex::setState($pdo, $key, json_encode($out)); } catch (Throwable) {}
        return $out;
    }

    /** What's been asked in this place in the last 30 days: reading key => times. */
    private static function asked(PDO $pdo, string $placeKey): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT k, SUM(n) AS n FROM search_counts WHERE place_key = ? AND day >= ? GROUP BY k');
        $st->execute([$placeKey, date('Y-m-d', time() - 30 * 86400)]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string) $r['k']] = (int) $r['n'];
        return $out;
    }

    /**
     * Count a search someone acted on (picked a result, a preset's result, "See all", the map). Only its reading is
     * counted, per place and day: never the words, never the person. Once per question per 10 minutes per visit.
     */
    public static function record(PDO $pdo, string $q, array $ctx): void
    {
        if (!self::ready($pdo)) return;
        $u = UniversalSearch::understand($pdo, $q, $ctx, []);
        $keys = [];
        $placeKey = '';
        foreach ($u['chips'] as $c) {
            switch ($c['type']) {
                case 'place': $placeKey = (string) ($c['key'] ?? ''); break;
                case 'category': $keys[] = 'cat:' . $c['slug']; break;
                case 'why': $keys[] = 'why:' . $c['value']; break;
                case 'when': $keys[] = 'when:' . (str_starts_with((string) $c['value'], 'day:') ? 'day' : $c['value']); break;
                case 'who': if (!empty($c['value'])) $keys[] = 'who:' . $c['value']; break;
                case 'kind': $keys[] = 'kind:' . rtrim((string) $c['value'], 's'); break;
            }
        }
        if (!$keys) return;
        $seen = &$_SESSION['tv_search_counted'];
        if (!is_array($seen)) $seen = [];
        $sig = md5(implode(',', $keys) . '|' . $placeKey);
        if (($seen[$sig] ?? 0) > time() - 600) return;
        $seen[$sig] = time();
        $day = date('Y-m-d');
        foreach (array_unique($keys) as $k) {
            $k = mb_substr($k, 0, 60);
            $up = $pdo->prepare('UPDATE search_counts SET n = n + 1 WHERE k = ? AND place_key = ? AND day = ?');
            $up->execute([$k, $placeKey, $day]);
            if ($up->rowCount() === 0) {
                try { $pdo->prepare('INSERT INTO search_counts (k, place_key, day, n) VALUES (?, ?, ?, 1)')->execute([$k, $placeKey, $day]); }
                catch (PDOException) { $up->execute([$k, $placeKey, $day]); }   // someone else added the row first
            }
        }
        if (random_int(1, 100) === 1) $pdo->prepare('DELETE FROM search_counts WHERE day < ?')->execute([date('Y-m-d', time() - 90 * 86400)]);
    }
}
