-- 2027-03-10_account_domains_wallet.sql — domains as a standalone product (decisions/0169 §1a) and the wallet
-- (decisions/0166 §6a). Safe to run twice: CREATE TABLE IF NOT EXISTS, and the plan cards copied in with INSERT IGNORE
-- and NOT EXISTS. No UPDATE or DELETE: business_domains (the storefront's domain, 0139) and subscriptions are untouched.

-- a domain an account holds: bought in Shop → Domains, or brought from elsewhere for pointing only
CREATE TABLE IF NOT EXISTS account_domains (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  owner_type VARCHAR(10) NOT NULL,
  owner_id INT UNSIGNED NOT NULL,
  domain VARCHAR(190) NOT NULL,
  source VARCHAR(10) NOT NULL DEFAULT 'bought',
  status VARCHAR(16) NOT NULL DEFAULT 'active',
  env VARCHAR(10) NOT NULL DEFAULT 'live',
  points VARCHAR(16) NOT NULL DEFAULT '',
  forward_to VARCHAR(500) NOT NULL DEFAULT '',
  nameservers VARCHAR(600) NOT NULL DEFAULT '',
  auto_renew TINYINT(1) NOT NULL DEFAULT 1,
  renew_cents INT NOT NULL DEFAULT 0,
  renew_cost_cents INT NOT NULL DEFAULT 0,
  registered_at DATETIME DEFAULT NULL,
  expires_at DATETIME DEFAULT NULL,
  provider_order VARCHAR(60) NOT NULL DEFAULT '',
  dkim TEXT,
  email_ok TINYINT(1) NOT NULL DEFAULT 0,
  renew_fails TINYINT UNSIGNED NOT NULL DEFAULT 0,
  renew_next DATE DEFAULT NULL,
  renew_order INT UNSIGNED DEFAULT NULL,
  attention VARCHAR(300) NOT NULL DEFAULT '',
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_domain (domain),
  KEY k_owner (owner_type, owner_id),
  KEY k_expires (expires_at)
) ENGINE=InnoDB;

-- what happened to a domain: bought, renewed, pointed, records changed, transfer code shown, tickets
CREATE TABLE IF NOT EXISTS domain_events (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  domain_id INT UNSIGNED NOT NULL,
  kind VARCHAR(24) NOT NULL,
  note VARCHAR(600) NOT NULL DEFAULT '',
  order_id INT UNSIGNED DEFAULT NULL,
  actor INT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL,
  KEY k_domain (domain_id, id)
) ENGINE=InnoDB;

-- a domain in the one cart (a cart_plans line, owner_type 'oneoff' and item domain_purchase or domain_renewal, names this row): what was shown, for whom, the registrant
CREATE TABLE IF NOT EXISTS domain_cart (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  owner_type VARCHAR(10) NOT NULL,
  owner_id INT UNSIGNED NOT NULL,
  kind VARCHAR(10) NOT NULL DEFAULT 'purchase',
  domain VARCHAR(190) NOT NULL,
  domain_id INT UNSIGNED DEFAULT NULL,
  price_cents INT NOT NULL,
  cost_cents INT NOT NULL DEFAULT 0,
  renew_cents INT NOT NULL DEFAULT 0,
  renew_cost_cents INT NOT NULL DEFAULT 0,
  who TEXT,
  pay_with VARCHAR(24) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL,
  KEY k_user (user_id)
) ENGINE=InnoDB;

-- the wallet: an account's saved cards (only the processor's reference and a label, never the number)
CREATE TABLE IF NOT EXISTS wallet_cards (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  owner_type VARCHAR(10) NOT NULL,
  owner_id INT UNSIGNED NOT NULL,
  processor VARCHAR(20) NOT NULL DEFAULT 'quickbooks',
  env VARCHAR(12) NOT NULL DEFAULT '',
  wallet VARCHAR(40) NOT NULL DEFAULT '',
  card_ref VARCHAR(120) NOT NULL,
  label VARCHAR(60) NOT NULL DEFAULT '',
  exp VARCHAR(7) NOT NULL DEFAULT '',
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  added_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL,
  removed_at DATETIME DEFAULT NULL,
  reminded_at DATETIME DEFAULT NULL,
  UNIQUE KEY uq_card (processor, card_ref),
  KEY k_owner (owner_type, owner_id)
) ENGINE=InnoDB;

-- which card pays each thing that renews (a plan, a domain); an open assignment locks the card
CREATE TABLE IF NOT EXISTS wallet_assignments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  card_id INT UNSIGNED NOT NULL,
  item_type VARCHAR(12) NOT NULL,
  item_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  ended_at DATETIME DEFAULT NULL,
  KEY k_item (item_type, item_id),
  KEY k_card (card_id)
) ENGINE=InnoDB;

-- plans pay from the wallet too (Jason, 2026-11-17): each running plan's card goes into its account's wallet (the
-- QuickBooks wallet id TRV-U<id> / TRV-L<id> is already per account) and is assigned to the plan; a test account's
-- card goes into its test wallet (env 'sandbox': only ever charged in QuickBooks' sandbox)
INSERT IGNORE INTO wallet_cards (owner_type, owner_id, processor, env, wallet, card_ref, label, is_default, added_by, created_at)
  SELECT s.owner_type, s.owner_id, 'quickbooks', IF(EXISTS (SELECT 1 FROM users u WHERE u.id = s.payer_id AND u.is_test = 1), 'sandbox', ''), COALESCE(NULLIF(s.wallet, ''), CONCAT('TRV-', IF(s.owner_type = 'listing', 'L', 'U'), s.owner_id)),
         s.card_id, COALESCE(s.card_label, ''), 1, s.payer_id, NOW()
  FROM subscriptions s WHERE s.card_id IS NOT NULL AND s.card_id <> '' AND s.status <> 'ended';

INSERT INTO wallet_assignments (card_id, item_type, item_id, created_at)
  SELECT w.id, 'plan', s.id, NOW()
  FROM subscriptions s JOIN wallet_cards w ON w.processor = 'quickbooks' AND w.card_ref = s.card_id
  WHERE s.card_id IS NOT NULL AND s.card_id <> '' AND s.status <> 'ended'
    AND NOT EXISTS (SELECT 1 FROM wallet_assignments a WHERE a.item_type = 'plan' AND a.item_id = s.id AND a.ended_at IS NULL);
