<?php
// app/lib/QuickBooksPay.php — selling through Traversence's QuickBooks merchant account (decisions/0095).
//
// A checkout becomes a QuickBooks invoice: QuickBooks' Automated Sales Tax adds the tax from the buyer's address, the
// buyer pays on QuickBooks' own secure payment page (its invoice link: card, and bank transfer or Apple Pay when the
// account offers them), and QuickBooks tells us it's paid (api/qb-webhook.php), or we ask it (paid()). No card number
// ever touches our server, and every sale is in the books with its tax.
//
// .env: QB_CLIENT_ID, QB_CLIENT_SECRET (the Intuit developer app), QB_ENV (production | sandbox | mock, a local test
// with no network), QB_WEBHOOK_TOKEN (the app's webhook verifier token), optionally QB_INCOME_ACCOUNT_ID.
// The connection (one company) is made by an admin at /admin/quickbooks.php; its tokens are kept encrypted.
declare(strict_types=1);

require_once __DIR__ . '/Orders.php';   // Orders::no(): the order number people see

final class QuickBooksPay
{
    // The OAuth endpoints come from Intuit's discovery document (kept a day in app/storage); these are only the fallback
    // if it can't be read.
    private const AUTH = 'https://appcenter.intuit.com/connect/oauth2';
    private const TOKEN = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';
    private const REVOKE = 'https://developer.api.intuit.com/v2/oauth2/tokens/revoke';
    private const DISCOVERY = ['production' => 'https://developer.api.intuit.com/.well-known/openid_configuration',
                               'sandbox' => 'https://developer.api.intuit.com/.well-known/openid_sandbox_configuration'];
    private const MINOR = '75';
    public const ITEM_NAME = 'GO Code';

    private static ?string $forced = null;
    private static ?string $modeCache = null;
    private static bool $oneRow = false;   // before 2026-12-04_qb_checkout.sql: one connection, row 1

    /**
     * production, sandbox or mock. The mode our team sets on E-Commerce → Payments wins; until it's set, QB_ENV in .env
     * decides (production when it's missing). QB_ENV=mock (the local test) always wins.
     */
    public static function env(): string
    {
        if (self::envRaw() === 'mock') return 'mock';
        if (self::testHere()) return 'sandbox';   // a test account signed in: never live QuickBooks, whatever the switch says (Jason, 2026-11-10)
        if (self::$forced !== null) return self::$forced;
        $m = self::mode();
        if ($m !== '') return $m;
        return self::envRaw() === 'sandbox' ? 'sandbox' : 'production';
    }

    /** For one request (a webhook, the way back from connecting): work in this mode whatever the switch says. */
    public static function useEnv(?string $e): void { self::$forced = in_array($e, ['production', 'sandbox'], true) ? $e : null; }

    /** The mode useEnv() set, or null (so a nested caller can put it back as it was). */
    public static function forcedEnv(): ?string { return self::$forced; }

    /** The mode set on E-Commerce → Payments, or '' (not set: QB_ENV decides). */
    public static function mode(): string
    {
        if (self::$modeCache !== null) return self::$modeCache;
        try {
            require_once __DIR__ . '/Database.php';
            $v = Database::connection()->query("SELECT value FROM " . Database::t('qb_settings') . " WHERE name = 'mode'")->fetchColumn();
            self::$modeCache = in_array($v, ['production', 'sandbox'], true) ? (string) $v : '';
        } catch (Throwable) { self::$modeCache = ''; }
        return self::$modeCache;
    }

    public static function setMode(PDO $pdo, string $mode, int $uid): void
    {
        if (!in_array($mode, ['production', 'sandbox'], true)) throw new RuntimeException('Choose production or sandbox.');
        $pdo->prepare("INSERT INTO " . Database::t('qb_settings') . " (name, value, updated_by) VALUES ('mode', ?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_by = VALUES(updated_by)")->execute([$mode, $uid]);
        self::$modeCache = $mode;
    }

    /**
     * An Intuit key for a mode: QB_CLIENT_ID, QB_CLIENT_SECRET, QB_WEBHOOK_TOKEN are production's and QB_SANDBOX_CLIENT_ID,
     * QB_SANDBOX_CLIENT_SECRET, QB_SANDBOX_WEBHOOK_TOKEN the sandbox's. A .env from before the switch (QB_ENV=sandbox and
     * no QB_SANDBOX_ keys) holds the sandbox's keys under the plain names.
     */
    public static function key(string $name, ?string $env = null): string
    {
        $env = $env ?? self::env();
        $plainIsSandbox = trim((string) getenv('QB_SANDBOX_CLIENT_ID')) === '' && self::envRaw() === 'sandbox';
        $v = $env === 'sandbox' ? (getenv('QB_SANDBOX_' . $name) ?: ($plainIsSandbox ? getenv('QB_' . $name) : '')) : ($plainIsSandbox ? '' : getenv('QB_' . $name));
        return trim((string) $v);
    }

    /** Runs $f in a mode (for showing both modes on E-Commerce → Payments), then puts the mode back. */
    private static ?bool $testHere = null;

    /**
     * A test account is signed in, a member's or a staff test login's (users.is_test, decisions/0145 §3): everything it
     * does with QuickBooks runs in the sandbox, so no test makes a live charge, invoice, payment or receipt. On the staging
     * copy it's true for everyone (MarketPay and Domains ask this too).
     */
    public static function testHere(): bool
    {
        if (self::$testHere !== null) return self::$testHere;
        require_once __DIR__ . '/Staging.php';
        if (Staging::here()) return self::$testHere = true;   // the staging copy: everyone, every job, sandbox only (decisions/0145 Phase 3)
        self::$testHere = false;
        if (PHP_SAPI === 'cli' || session_status() !== PHP_SESSION_ACTIVE) return false;
        try {
            require_once __DIR__ . '/TestAccounts.php';
            $pdo = Database::connection();
            $uid = (int) ($_SESSION['user_id'] ?? 0);
            if ($uid > 0 && TestAccounts::isTestUser($pdo, $uid)) return self::$testHere = true;
            if (class_exists('StaffLogin', false) && ($st = StaffLogin::inSession($pdo)) && !empty($st['user_id']) && TestAccounts::isTestUser($pdo, (int) $st['user_id'])) return self::$testHere = true;
        } catch (Throwable) {}
        return false;
    }

    /**
     * Never real money for a test (Jason, 2026-11-10: "ensure no test can create actual transactions outside the
     * sandbox"): a test order (made in the sandbox, or a "TEST · …" copy, even one made while payments were live) never
     * goes through live QuickBooks. Called before every charge, invoice and payment on an order; refunds and credits only
     * send money back, so a test copy that once took real money can still be refunded.
     */
    public static function guardReal(PDO $pdo, array $o): void
    {
        self::guardStaging();
        if (self::env() !== 'production') return;
        $test = ($o['qb_env'] ?? '') === 'sandbox' || str_starts_with((string) ($o['bill_name'] ?? ''), 'TEST · ');
        if (!$test && !empty($o['user_id'])) { require_once __DIR__ . '/TestAccounts.php'; $test = TestAccounts::isTestUser($pdo, (int) $o['user_id']); }
        if ($test) throw new RuntimeException('Order ' . (class_exists('Orders') ? '#' . Orders::no($o) : '#' . (int) ($o['id'] ?? 0)) . ' is a test order: it never goes through live QuickBooks, so no real money moves. Switch E-Commerce → Payments to Sandbox to run it through.');
    }

    /**
     * Payments refuse to start on staging while a live payment key is in its .env (decisions/0165 §1): the site manager
     * says which, and payments stay off until it's gone. Nothing on live.
     */
    public static function guardStaging(): void
    {
        require_once __DIR__ . '/StagingGate.php';
        $keys = StagingGate::liveKeys();
        if ($keys) throw new RuntimeException('Payments are off on staging: a live payment key is in its .env (' . implode(', ', $keys) . '). Press Set up staging again on the live site (System Configuration → Staging) to write staging\'s .env without it, or ask our team at support@traversence.com.');
    }

    public static function withEnv(string $env, callable $f)
    {
        $was = self::$forced;
        self::useEnv($env);
        try { return $f(); } finally { self::$forced = $was; }
    }

    /** One mode at a glance: its keys are in .env, it's connected (and to which company), when it needs reconnecting. */
    public static function modeStatus(PDO $pdo, string $env): array
    {
        return self::withEnv($env, function () use ($pdo, $env) {
            $c = self::connection($pdo);
            return ['configured' => self::configured(), 'webhook' => self::key('WEBHOOK_TOKEN') !== '', 'connected' => (bool) $c && !self::needsReconnect($c),
                    'company' => (string) ($c['company_name'] ?? ''), 'cards' => (bool) $c && str_contains((string) ($c['scopes'] ?? ''), 'payment'), 'lapsed' => $c && self::needsReconnect($c)];
        });
    }

    private static function connId(): int { return !self::$oneRow && self::env() === 'sandbox' ? 2 : 1; }

    /** QB_ENV as written, first word only (a comment after it on the line is ignored), lower case; '' when not set. */
    public static function envRaw(): string
    {
        return strtolower((string) (preg_split('/[\s#;]+/', trim((string) getenv('QB_ENV')))[0] ?? ''));
    }

    /** What the connection asks QuickBooks for: the books, and QuickBooks Payments (card refunds, decisions/0098). */
    public const SCOPES = 'com.intuit.quickbooks.accounting com.intuit.quickbooks.payment';

    private static function api(): string { return (string) (getenv('QB_TEST_API') ?: '') ?: (self::env() === 'sandbox' ? 'https://sandbox-quickbooks.api.intuit.com' : 'https://quickbooks.api.intuit.com'); }   // QB_TEST_API: a local stand-in, tests only

    public static function configured(?string $env = null): bool { return self::env() === 'mock' || (self::key('CLIENT_ID', $env) !== '' && self::key('CLIENT_SECRET', $env) !== ''); }

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM ' . Database::t('qb_connection') . ' LIMIT 1'); return true; } catch (Throwable) { return false; }
    }

    public static function connection(PDO $pdo): ?array
    {
        if (!self::ready($pdo)) return null;
        self::sortLegacy($pdo);
        $st = $pdo->prepare('SELECT * FROM ' . Database::t('qb_connection') . ' WHERE id = ?'); $st->execute([self::connId()]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** The connection made before the switch existed: it belongs to the mode QB_ENV named (sandbox moves to row 2). */
    private static function sortLegacy(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        try {
            if ($pdo->query("SELECT id FROM " . Database::t('qb_connection') . " WHERE id = 1 AND env = ''")->fetchColumn() === false) return;
            if (self::envRaw() === 'sandbox' && $pdo->query('SELECT id FROM ' . Database::t('qb_connection') . ' WHERE id = 2')->fetchColumn() === false) $pdo->exec("UPDATE " . Database::t('qb_connection') . " SET id = 2, env = 'sandbox' WHERE id = 1");
            else $pdo->exec("UPDATE " . Database::t('qb_connection') . " SET env = 'production' WHERE id = 1");
        } catch (Throwable) { self::$oneRow = true; }   // no env column yet
    }

    /** Is buying open: the app is set up and a company is connected (or the local mock)? */
    public static function open(PDO $pdo): bool
    {
        if (self::env() === 'mock') return true;
        if (self::env() === 'sandbox' && !self::staffHere($pdo)) return false;   // test mode: only our team can check out
        $c = self::connection($pdo);
        return self::configured() && $c && strtotime((string) $c['refresh_until']) > time();
    }

    /** Is the person on this page one of our team (sandbox checkouts are theirs only)? */
    public static function staffHere(PDO $pdo): bool
    {
        if (!class_exists('Auth')) return false;
        try { $u = Auth::currentUser(); } catch (Throwable) { return false; }
        if (!$u) return false;
        require_once __DIR__ . '/TwoStep.php';
        return TwoStep::isStaff($pdo, $u);
    }

    // ---- secrets -----------------------------------------------------------------------------------------------------

    /**
     * The key the tokens are sealed with: from the site's own secret, so it stays the same when Intuit's keys move about
     * in .env (the sandbox/production switch). Connections sealed before used the client secret too; still read.
     */
    private static function sealKeys(): array
    {
        $site = (string) (getenv('APP_SECRET') ?: getenv('DB_PASSWORD') ?: '');
        $keys = [sodium_crypto_generichash('tv-qb-2|' . $site, '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES)];
        foreach (array_unique(array_filter([(string) getenv('QB_CLIENT_SECRET'), (string) getenv('QB_SANDBOX_CLIENT_SECRET'), ''], fn ($x) => true)) as $old)
            $keys[] = sodium_crypto_generichash('tv-qb|' . $site . '|' . $old, '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES);
        return $keys;
    }

    private static function seal(string $s): string
    {
        $n = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return base64_encode($n . sodium_crypto_secretbox($s, $n, self::sealKeys()[0]));
    }

    /**
     * The QuickBooks company id (realmId) is kept encrypted like the tokens (decisions/0096 addendum, Intuit's review:
     * "customer IDs … must be stored securely"). A plain number is a connection made before that, still read.
     */
    private static function realm(array $c): string
    {
        $r = (string) $c['realm_id'];
        return ctype_digit($r) ? $r : self::unseal($r);
    }

    /** Can realm_id hold an encrypted value (2026-12-01_qb_realm_sealed.sql run)? */
    public static function realmSealable(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try {
            $st = $pdo->query("SELECT CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = " . $pdo->quote(Database::schemaOf('qb_connection')) . " AND TABLE_NAME = 'qb_connection' AND COLUMN_NAME = 'realm_id'");
            return $ok = ((int) $st->fetchColumn()) >= 200;
        } catch (Throwable) { return $ok = false; }
    }

    private static function unseal(string $b): string
    {
        $raw = base64_decode($b, true) ?: '';
        $n = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $out = false;
        foreach (self::sealKeys() as $k) { $out = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $n, $k); if ($out !== false) break; }
        if ($out === false) throw new RuntimeException('The QuickBooks connection can\'t be read. Connect QuickBooks again.');
        return $out;
    }

    // ---- connecting ----------------------------------------------------------------------------------------------------

    public static function redirectUri(): string
    {
        return rtrim((string) (getenv('QB_REDIRECT_URI') ?: (rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/quickbooks.php')), '/');
    }

    /** authorization / token / revocation endpoint, from the discovery document (cached a day), else the fallback. */
    private static function endpoint(string $which): string
    {
        $fallback = ['authorization_endpoint' => self::AUTH, 'token_endpoint' => self::TOKEN, 'revocation_endpoint' => self::REVOKE][$which];
        $env = self::env();
        if (!isset(self::DISCOVERY[$env])) return $fallback;
        static $doc = null;
        if ($doc === null) {
            $file = __DIR__ . '/../storage/qb-discovery-' . $env . '.json';
            $doc = is_file($file) ? (json_decode((string) file_get_contents($file), true) ?: []) : [];
            if (!is_file($file) || filemtime($file) < time() - 86400) {
                try {
                    [$code, $j] = self::http('GET', self::DISCOVERY[$env], ['Accept: application/json']);
                    if ($code === 200 && !empty($j['token_endpoint'])) { $doc = $j; @file_put_contents($file, json_encode($j)); }
                    elseif (is_file($file)) @touch($file);   // keep the old copy; try again tomorrow
                } catch (Throwable $e) { error_log('qb discovery: ' . $e->getMessage()); }
            }
        }
        $u = (string) ($doc[$which] ?? '');
        return str_starts_with($u, 'https://') || (getenv('QB_TEST_API') && str_starts_with($u, 'http://127.0.0.1:')) ? $u : $fallback;
    }

    /** Where an admin goes to connect the company. $state is kept in the session and checked on the way back. */
    /** Intuit's sign-in page; $cards false asks for accounting only (Payments needs its own production approval at Intuit). */
    public static function authUrl(string $state, bool $cards = true): string
    {
        $_SESSION['tv_qb_scopes'] = $cards ? self::SCOPES : 'com.intuit.quickbooks.accounting';
        return self::endpoint('authorization_endpoint') . '?' . http_build_query(['client_id' => trim(self::key('CLIENT_ID')), 'response_type' => 'code',
            'scope' => $_SESSION['tv_qb_scopes'], 'redirect_uri' => self::redirectUri(), 'state' => $state], '', '&', PHP_QUERY_RFC3986);
    }

    /** One request to Intuit: [status, decoded JSON, raw body, intuit_tid]. Every call is logged (see log()). */
    private static function http(string $method, string $url, array $headers, ?string $body = null): array
    {
        $tid = '';
        require_once __DIR__ . '/StagingGate.php'; if (($w = StagingGate::hold($url, 'QuickBooks ' . $method)) !== null) { self::log($method, $url, 0, '', 'held: ' . $w); throw new RuntimeException($w); }   // staging: the sandbox only
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_HEADERFUNCTION => function ($ch, string $h) use (&$tid) {   // Intuit's id for this request, for its support team
                if (stripos($h, 'intuit_tid:') === 0) $tid = trim(substr($h, 11));
                return strlen($h);
            }] + ($body !== null ? [CURLOPT_POSTFIELDS => $body] : []));
        $out = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        require_once __DIR__ . '/ServiceHealth.php'; ServiceHealth::seen($url, $out === false ? 0 : $code, '', $err, 'QuickBooks', true);   // server errors and timeouts only; a payment is never held by it
        if ($out === false) { self::log($method, $url, 0, '', 'no answer: ' . $err); throw new RuntimeException('QuickBooks didn\'t answer: ' . $err); }
        $j = json_decode((string) $out, true);
        $j = is_array($j) ? $j : [];
        self::log($method, $url, $code, $tid, $code >= 400 ? self::faultText($j, (string) $out) : '');
        return [$code, $j, (string) $out, $tid];
    }

    /** The error QuickBooks gave, in a line: its Fault (API), or error/error_description (OAuth). */
    private static function faultText(array $j, string $raw): string
    {
        $f = $j['Fault']['Error'][0] ?? $j['fault']['error'][0] ?? null;
        if (is_array($f)) return trim(($f['code'] ?? '') . ' ' . ($f['Message'] ?? $f['message'] ?? '') . ': ' . ($f['Detail'] ?? $f['detail'] ?? '') . (isset($f['element']) && $f['element'] ? ' [' . $f['element'] . ']' : ''));
        if (isset($j['error'])) return trim($j['error'] . ' ' . ($j['error_description'] ?? ''));
        return mb_substr(preg_replace('/\s+/', ' ', $raw), 0, 300);
    }

    /**
     * The QuickBooks log, app/storage/logs/quickbooks.log (never served): one line per call to Intuit with the time, the
     * method and path (no query, no request body, so no tokens or customer details), the status, Intuit's intuit_tid,
     * and for errors what QuickBooks said. Kept to about 2 MB (the older half moves to quickbooks.log.1). Admins can
     * download it from Admin → GO Code orders to share with Intuit support.
     */
    public static function logPath(): string { return __DIR__ . '/../storage/logs/quickbooks.log'; }

    /** A webhook from QuickBooks, in the same log: whether its signature was right, and the invoices it named. */
    public static function logWebhook(bool $signed, array $invoiceIds, string $note = ''): void
    {
        self::log('IN', 'webhook/api/qb-webhook.php', $signed ? 200 : 401, '', $signed ? '' : 'signature not valid');
        if ($signed && ($invoiceIds || $note !== '')) @file_put_contents(self::logPath(), date('c') . ' ' . self::env() . ' webhook invoices=' . ($invoiceIds ? implode(',', $invoiceIds) : '-') . ($note !== '' ? ' ' . $note : '') . "\n", FILE_APPEND | LOCK_EX);
    }

    /** A line in the QuickBooks log about what a webhook led to (no customer details). */
    public static function logNote(string $note): void
    {
        @file_put_contents(self::logPath(), date('c') . ' ' . self::env() . ' webhook ' . mb_substr($note, 0, 200) . "\n", FILE_APPEND | LOCK_EX);
    }

    private static function log(string $method, string $url, int $code, string $tid, string $error): void
    {
        $f = self::logPath();
        if (!is_dir(dirname($f))) @mkdir(dirname($f), 0700, true);
        if (is_file($f) && filesize($f) > 2_000_000) @rename($f, $f . '.1');
        $path = (string) parse_url($url, PHP_URL_HOST) . (string) parse_url($url, PHP_URL_PATH);
        $path = preg_replace(['#/company/[^/]+#', '#/companyinfo/[^/]+#'], ['/company/{company}', '/companyinfo/{company}'], $path);   // the company id stays out of the log
        $line = date('c') . ' ' . self::env() . ' ' . $method . ' ' . $path . ' ' . ($code ?: '---') . ' intuit_tid=' . ($tid !== '' ? $tid : '-')
            . ($error !== '' ? ' error="' . str_replace(["\n", '"'], [' ', "'"], mb_substr($error, 0, 500)) . '"' : '') . "\n";
        @file_put_contents($f, $line, FILE_APPEND | LOCK_EX);
    }

    /** http(), tried once more after a moment if QuickBooks didn't answer or was busy (429, 5xx). */
    private static function httpRetry(string $method, string $url, array $headers, ?string $body = null): array
    {
        try { $r = self::http($method, $url, $headers, $body); if ($r[0] !== 429 && $r[0] < 500) return $r; }
        catch (Throwable $e) { error_log('qb retry: ' . $e->getMessage()); }
        sleep(2);
        return self::http($method, $url, $headers, $body);
    }

    private static function tokenCall(array $form): array
    {
        [$code, $j, $raw, $tid] = self::httpRetry('POST', self::endpoint('token_endpoint'), ['Accept: application/json', 'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Basic ' . base64_encode(self::key('CLIENT_ID') . ':' . self::key('CLIENT_SECRET'))], http_build_query($form));
        if ($code !== 200 || empty($j['access_token'])) {
            $err = (string) ($j['error'] ?? '');
            throw new RuntimeException('QuickBooks refused the connection (' . $code . ($err !== '' ? ', ' . $err : '') . ')' . ($tid !== '' ? ' [intuit_tid ' . $tid . ']' : ''), $err === 'invalid_grant' ? 4001 : 0);
        }
        return $j;
    }

    private static function store(PDO $pdo, string $realm, array $t, ?int $uid = null): void
    {
        $pdo->prepare('INSERT INTO ' . Database::t('qb_connection') . ' (id, realm_id, access_token, refresh_token, access_until, refresh_until, connected_by) VALUES (' . self::connId() . ', ?, ?, ?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE realm_id = VALUES(realm_id), access_token = VALUES(access_token), refresh_token = VALUES(refresh_token),
                       access_until = VALUES(access_until), refresh_until = VALUES(refresh_until), connected_by = COALESCE(VALUES(connected_by), connected_by)')
            ->execute([self::realmSealable($pdo) ? self::seal($realm) : $realm, self::seal((string) $t['access_token']), self::seal((string) $t['refresh_token']),
                       date('Y-m-d H:i:s', time() + (int) ($t['expires_in'] ?? 3600) - 120),
                       date('Y-m-d H:i:s', time() + (int) ($t['x_refresh_token_expires_in'] ?? 8640000) - 3600), $uid]);
        if (!self::$oneRow) try { $pdo->prepare('UPDATE ' . Database::t('qb_connection') . ' SET env = ? WHERE id = ?')->execute([self::env(), self::connId()]); } catch (Throwable) {}
    }

    /** The admin came back from QuickBooks with a code: keep the tokens, name the company, set up the product. */
    public static function connect(PDO $pdo, string $code, string $realm, int $uid): string
    {
        if (!preg_match('/^\d{1,30}$/', $realm)) throw new RuntimeException('QuickBooks didn\'t say which company.');
        $t = self::tokenCall(['grant_type' => 'authorization_code', 'code' => $code, 'redirect_uri' => self::redirectUri()]);
        self::store($pdo, $realm, $t, $uid);
        $name = '';
        try { $ci = self::call($pdo, 'GET', 'companyinfo/' . $realm); $name = (string) ($ci['CompanyInfo']['CompanyName'] ?? ''); } catch (Throwable) {}
        $pdo->prepare('UPDATE ' . Database::t('qb_connection') . ' SET company_name = ?, item_id = NULL WHERE id = ' . self::connId())->execute([$name]);
        try { $pdo->prepare('UPDATE ' . Database::t('qb_connection') . ' SET scopes = ? WHERE id = ' . self::connId())->execute([(string) ($_SESSION['tv_qb_scopes'] ?? self::SCOPES)]); } catch (Throwable) {}   // before 2026-12-03_qb_refunds.sql
        self::itemId($pdo);
        return $name;
    }

    public static function disconnect(PDO $pdo): void
    {
        $c = self::connection($pdo);
        if ($c && self::env() !== 'mock') {
            try { self::http('POST', self::endpoint('revocation_endpoint'), ['Accept: application/json', 'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode(self::key('CLIENT_ID') . ':' . self::key('CLIENT_SECRET'))], json_encode(['token' => self::unseal((string) $c['refresh_token'])])); }
            catch (Throwable $e) { error_log('qb revoke: ' . $e->getMessage()); }
        }
        $pdo->exec('DELETE FROM ' . Database::t('qb_connection') . ' WHERE id = ' . self::connId());
    }

    /**
     * After someone disconnects the app from inside QuickBooks (Intuit then sends them to our Disconnect URL), our tokens
     * no longer work. Ask QuickBooks: if it refuses them (401/400 on the token or the API), forget the connection here.
     * A network failure changes nothing, so following the link can't switch payments off on its own.
     */
    public static function stillConnected(PDO $pdo): bool
    {
        $c = self::connection($pdo);
        if (!$c) return false;
        if (self::env() === 'mock') return true;
        try { self::call($pdo, 'GET', 'companyinfo/' . rawurlencode(self::realm($c))); return true; }
        catch (Throwable $e) {
            if (!preg_match('/\((400|401|403)[,)]|needs reconnecting/', $e->getMessage())) throw $e;
            $pdo->exec('DELETE FROM ' . Database::t('qb_connection') . ' WHERE id = ' . self::connId());
            return false;
        }
    }

    /** A read-only check that QuickBooks answers us (the company's info); throws on a refusal. Never deletes the connection. */
    public static function ping(PDO $pdo): void
    {
        $c = self::connection($pdo);
        if (!$c) throw new RuntimeException('QuickBooks isn\'t connected.');
        self::call($pdo, 'GET', 'companyinfo/' . rawurlencode(self::realm($c)));
    }

    /** A current access token (refreshed when it has run out; QuickBooks hands a new refresh token each time). */
    private static function access(PDO $pdo, bool $fresh = false): array
    {
        $c = self::connection($pdo);
        if (!$c) throw new RuntimeException('QuickBooks isn\'t connected.');
        if (self::needsReconnect($c)) throw new RuntimeException('QuickBooks needs reconnecting (Admin → E-Commerce → Payments).');
        if (!$fresh && strtotime((string) $c['access_until']) > time()) return [self::unseal((string) $c['access_token']), self::realm($c)];
        try {
            $t = self::tokenCall(['grant_type' => 'refresh_token', 'refresh_token' => self::unseal((string) $c['refresh_token'])]);
        } catch (RuntimeException $e) {
            // invalid_grant: the refresh token has run out or was revoked. Buying shows "opens soon" and the admin page
            // asks for a reconnect; the old tokens are of no further use.
            if ($e->getCode() === 4001) { self::markReconnect($pdo); throw new RuntimeException('QuickBooks needs reconnecting (Admin → E-Commerce → Payments).'); }
            throw $e;
        }
        $realm = self::realm($c);
        self::store($pdo, $realm, $t);
        return [(string) $t['access_token'], $realm];
    }

    /** The connection can't be used until an admin connects again (refresh token expired, revoked or refused). */
    public static function needsReconnect(?array $c): bool
    {
        return $c !== null && strtotime((string) $c['refresh_until']) <= time();
    }

    private static function markReconnect(PDO $pdo): void
    {
        $pdo->exec("UPDATE " . Database::t('qb_connection') . " SET refresh_until = NOW() - INTERVAL 1 SECOND, access_until = NOW() - INTERVAL 1 SECOND WHERE id = " . self::connId());
        error_log('qb: refresh token refused (invalid_grant); QuickBooks needs reconnecting');
    }

    /** One QuickBooks Accounting API call: $path after /v3/company/{realm}/. */
    public static function call(PDO $pdo, string $method, string $path, ?array $body = null, array $query = [], string $requestId = ''): array
    {
        [$tok, $realm] = self::access($pdo);
        // requestid: QuickBooks does a create only once per id, so a retry or a double click never makes a second
        // invoice or credit memo (decisions/0098)
        if ($requestId !== '') $query['requestid'] = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $requestId), 0, 50);
        $url = self::api() . '/v3/company/' . rawurlencode($realm) . '/' . $path . '?' . http_build_query($query + ['minorversion' => self::MINOR]);
        $send = fn (string $tok) => self::httpRetry($method, $url, ['Accept: application/json', 'Content-Type: application/json', 'Authorization: Bearer ' . $tok],
            $body !== null ? json_encode($body, JSON_UNESCAPED_SLASHES) : null);
        [$code, $j, $raw, $tid] = $send($tok);
        if ($code === 401) {   // the access token was refused before its time: get a new one and try once more
            [$tok] = self::access($pdo, true);
            [$code, $j, $raw, $tid] = $send($tok);
        }
        if ($code < 200 || $code >= 300) {
            throw new RuntimeException('QuickBooks (' . $code . '): ' . self::faultText($j, $raw) . ($tid !== '' ? ' [intuit_tid ' . $tid . ']' : ''));
        }
        return $j;
    }

    private static function q(string $s): string { return str_replace(["\\", "'"], ["\\\\", "\\'"], $s); }

    private static function query(PDO $pdo, string $sql): array
    {
        $j = self::call($pdo, 'GET', 'query', null, ['query' => $sql]);
        return (array) ($j['QueryResponse'] ?? []);
    }

    /** The "Designed QR code" product in QuickBooks (taxable service at $4.95), found or made once. */
    public static function itemId(PDO $pdo): string
    {
        $c = self::connection($pdo);
        if ($c && !empty($c['item_id'])) return (string) $c['item_id'];
        $found = self::query($pdo, "select Id from Item where Name = '" . self::q(self::ITEM_NAME) . "'");
        $id = (string) ($found['Item'][0]['Id'] ?? '');
        if ($id === '') {
            $acct = (string) (getenv('QB_INCOME_ACCOUNT_ID') ?: '');
            if ($acct === '') { $a = self::query($pdo, "select Id from Account where AccountType = 'Income' and Active = true maxresults 1"); $acct = (string) ($a['Account'][0]['Id'] ?? ''); }
            if ($acct === '') throw new RuntimeException('QuickBooks has no income account to record QR code sales in. Set QB_INCOME_ACCOUNT_ID in .env.');
            require_once __DIR__ . '/QrIssue.php';
            $j = self::call($pdo, 'POST', 'item', ['Name' => self::ITEM_NAME, 'Type' => 'Service', 'Taxable' => true, 'UnitPrice' => QrIssue::PRICE_CENTS / 100,
                'Description' => 'A GO Code (QR code) from Traversence / trvgo.us, kept in the buyer\'s Manage GO Codes', 'IncomeAccountRef' => ['value' => $acct]]);
            $id = (string) ($j['Item']['Id'] ?? '');
        }
        if ($id === '') throw new RuntimeException('QuickBooks didn\'t make the QR code product.');
        $pdo->prepare('UPDATE ' . Database::t('qb_connection') . ' SET item_id = ? WHERE id = ' . self::connId())->execute([$id]);
        return $id;
    }

    /** The buyer as a QuickBooks customer, found or added: a member by account ("Name · TRVGO 36"), a guest by email. */
    private static function customerId(PDO $pdo, int $uid, array $b, array $addr): string
    {
        $dn = mb_substr($b['name'], 0, 60) . ' · ' . ($uid > 0 ? 'TRVGO ' . $uid : mb_substr(strtolower($b['email']), 0, 90));
        $f = self::query($pdo, "select Id from Customer where DisplayName = '" . self::q($dn) . "'");
        if (!empty($f['Customer'][0]['Id'])) return (string) $f['Customer'][0]['Id'];
        $j = self::call($pdo, 'POST', 'customer', ['DisplayName' => $dn, 'PrimaryEmailAddr' => ['Address' => $b['email']]] + ($addr ? ['BillAddr' => $addr, 'ShipAddr' => $addr] : [])
            + ['Notes' => $uid > 0 ? 'Traversence member #' . $uid . ($addr ? ' (GO Codes)' : ' (subscriptions)') : 'GO Codes guest checkout']);   // no address: a subscriber
        return (string) ($j['Customer']['Id'] ?? '');
    }

    /**
     * The order's invoice: one line per code, taxable, Automated Sales Tax works out the tax from the address; online
     * payment on. Returns ['id', 'number', 'pay_url', 'tax_cents', 'total_cents'].
     */
    public static function invoice(PDO $pdo, int $oid, int $uid, array $b, array $items): array
    {
        if (class_exists('Orders') && ($go = Orders::get($pdo, $oid))) self::guardReal($pdo, $go);   // never real money for a test
        $sub = array_sum(array_map(fn ($i) => (int) $i['price_cents'], $items));
        if (self::env() === 'mock') {   // local test only: a made-up 8.6% tax and a pretend payment page
            $tax = (int) round($sub * 0.086);
            return ['id' => 'M' . $oid, 'number' => 'M-' . $oid, 'pay_url' => '/qr/?mockpay=' . $oid, 'tax_cents' => $tax, 'total_cents' => $sub + $tax];
        }
        $addr = ['Line1' => $b['street'], 'City' => $b['city'], 'CountrySubDivisionCode' => strtoupper($b['state']), 'PostalCode' => $b['zip'], 'Country' => 'USA'];
        $item = self::itemId($pdo);
        $cust = self::customerId($pdo, $uid, $b, $addr);
        if ($cust === '') throw new RuntimeException('QuickBooks didn\'t add the customer.');
        $lines = [];
        foreach ($items as $i) {
            $p = (int) $i['price_cents'] / 100;
            $lines[] = ['DetailType' => 'SalesItemLineDetail', 'Amount' => $p, 'Description' => 'GO Code: ' . mb_substr((string) $i['title'], 0, 80) . ' (' . (string) $i['type'] . ', #' . (int) $i['id'] . ')',
                        'SalesItemLineDetail' => ['ItemRef' => ['value' => $item], 'Qty' => 1, 'UnitPrice' => $p, 'TaxCodeRef' => ['value' => 'TAX']]];
        }
        $j = self::call($pdo, 'POST', 'invoice', ['CustomerRef' => ['value' => $cust], 'Line' => $lines, 'BillEmail' => ['Address' => $b['email']],
            'BillAddr' => $addr, 'ShipAddr' => $addr, 'AllowOnlineCreditCardPayment' => true, 'AllowOnlineACHPayment' => true,
            'CustomerMemo' => ['value' => 'GO Codes, order ' . $oid . '. Your codes appear in Manage GO Codes as soon as this is paid.'],
            'PrivateNote' => 'Traversence GO Codes order #' . $oid . ($uid > 0 ? ', member #' . $uid : ', guest')], [], 'inv-' . $oid);
        $inv = (array) ($j['Invoice'] ?? []);
        $id = (string) ($inv['Id'] ?? '');
        if ($id === '') throw new RuntimeException('QuickBooks didn\'t make the invoice.');
        $link = self::link($pdo, $id);
        if ($link === '') {   // some accounts only give the payment link once the invoice is sent
            try { self::call($pdo, 'POST', 'invoice/' . $id . '/send', null, ['sendTo' => $b['email']]); } catch (Throwable $e) { error_log('qb send: ' . $e->getMessage()); }
            $link = self::link($pdo, $id);
        }
        if ($link === '') throw new RuntimeException('QuickBooks didn\'t give a payment link: turn on online payments (cards) for invoices in QuickBooks.');
        $full = self::call($pdo, 'GET', 'invoice/' . $id);
        $inv = (array) ($full['Invoice'] ?? $inv);
        return ['id' => $id, 'number' => (string) ($inv['DocNumber'] ?? ''), 'pay_url' => $link, 'customer_id' => $cust,
                'tax_cents' => (int) round(((float) ($inv['TxnTaxDetail']['TotalTax'] ?? 0)) * 100), 'total_cents' => (int) round(((float) ($inv['TotalAmt'] ?? $sub / 100)) * 100)];
    }

    /**
     * An invoice for an order our team built for a client (decisions/0101), made when the client approves it: one line
     * per order line, each under its catalog product's own QuickBooks product (found or made by name), tax worked out
     * by QuickBooks from the address on taxable lines. $lines: [['title', 'qty', 'unit_cents', 'taxable', 'item' =>
     * QuickBooks item name, 'item_desc']]. $email: QuickBooks emails the invoice too (pay later). Returns like invoice().
     */
    public static function invoiceFor(PDO $pdo, int $oid, int $uid, array $b, array $lines, string $memo, bool $email = false): array
    {
        if (class_exists('Orders') && ($go = Orders::get($pdo, $oid))) self::guardReal($pdo, $go);   // never real money for a test
        $sub = 0; $taxable = 0;
        foreach ($lines as $l) { $amt = (int) $l['qty'] * (int) $l['unit_cents']; $sub += $amt; if ($l['taxable']) $taxable += $amt; }
        if (self::env() === 'mock') {   // local test only: a made-up 8.6% tax
            $tax = (int) round($taxable * 0.086);
            return ['id' => 'M' . $oid, 'number' => 'M-' . $oid, 'pay_url' => '/order.php?mockpay=' . $oid, 'tax_cents' => $tax, 'total_cents' => $sub + $tax, 'customer_id' => 'MC' . $oid];
        }
        $addr = ['Line1' => $b['street'], 'City' => $b['city'], 'CountrySubDivisionCode' => strtoupper($b['state']), 'PostalCode' => $b['zip'], 'Country' => 'USA'];
        $cust = self::customerId($pdo, $uid, $b, $addr);
        if ($cust === '') throw new RuntimeException('QuickBooks didn\'t add the customer.');
        $items = [];
        $ql = [];
        foreach ($lines as $l) {
            $name = (string) $l['item']; $pid = (int) ($l['product_id'] ?? 0);
            require_once __DIR__ . '/Books.php';
            if ($name === self::ITEM_NAME) $iid = self::itemId($pdo);
            elseif ($pid > 0 && ($tagged = Books::itemFor($pdo, $pid)) !== '') $iid = $tagged;   // its tagged item (decisions/0128), whatever either side is called
            else {
                $iid = $items[$name] ??= self::namedItem($pdo, $name, (string) ($l['item_desc'] ?? ''), (bool) $l['taxable']);
                if ($pid > 0) { try { SystemTags::set($pdo, 'qbo.item', $pid, self::env(), $iid, $name, $uid, 'made or found when invoicing'); } catch (Throwable $e) { error_log('qb item tag: ' . $e->getMessage()); } }   // made once, then remembered
            }
            $unit = (int) $l['unit_cents'] / 100;
            $ql[] = ['DetailType' => 'SalesItemLineDetail', 'Amount' => round($unit * (int) $l['qty'], 2), 'Description' => mb_substr((string) $l['title'], 0, 4000),
                     'SalesItemLineDetail' => ['ItemRef' => ['value' => $iid], 'Qty' => (int) $l['qty'], 'UnitPrice' => $unit, 'TaxCodeRef' => ['value' => $l['taxable'] ? 'TAX' : 'NON']]];
        }
        $j = self::call($pdo, 'POST', 'invoice', ['CustomerRef' => ['value' => $cust], 'Line' => $ql, 'BillEmail' => ['Address' => $b['email']],
            'BillAddr' => $addr, 'ShipAddr' => $addr, 'AllowOnlineCreditCardPayment' => true, 'AllowOnlineACHPayment' => true,
            'CustomerMemo' => ['value' => mb_substr($memo, 0, 1000)], 'PrivateNote' => 'Traversence order #' . $oid . ' (client order)' . ($uid > 0 ? ', member #' . $uid : '')], [], 'inv-' . $oid);
        $inv = (array) ($j['Invoice'] ?? []);
        $id = (string) ($inv['Id'] ?? '');
        if ($id === '') throw new RuntimeException('QuickBooks didn\'t make the invoice.');
        if ($email) { try { self::call($pdo, 'POST', 'invoice/' . $id . '/send', null, ['sendTo' => $b['email']]); } catch (Throwable $e) { error_log('qb send: ' . $e->getMessage()); } }
        $link = self::link($pdo, $id);
        if ($link === '' && !$email) { try { self::call($pdo, 'POST', 'invoice/' . $id . '/send', null, ['sendTo' => $b['email']]); } catch (Throwable $e) { error_log('qb send: ' . $e->getMessage()); } $link = self::link($pdo, $id); }
        $full = self::call($pdo, 'GET', 'invoice/' . $id);
        $inv = (array) ($full['Invoice'] ?? $inv);
        return ['id' => $id, 'number' => (string) ($inv['DocNumber'] ?? ''), 'pay_url' => $link, 'customer_id' => $cust,
                'tax_cents' => (int) round(((float) ($inv['TxnTaxDetail']['TotalTax'] ?? 0)) * 100), 'total_cents' => (int) round(((float) ($inv['TotalAmt'] ?? $sub / 100)) * 100)];
    }

    /**
     * An invoice by its number (DocNumber), read only (decisions/0128), with its customer and payments:
     * ['invoice' => Invoice, 'customer' => Customer, 'payments' => [[id, date, cents]]], or null when there's none.
     */
    public static function invoiceByNumber(PDO $pdo, string $no): ?array
    {
        $no = trim($no);
        if ($no === '') return null;
        if (self::env() === 'mock') {   // local test only: invoice 112906 as QuickBooks has it (paid), and 112907, the same unpaid
            if ($no !== '112906' && $no !== '112907') return null;
            $open = $no === '112907';
            $gc = fn ($d) => ['DetailType' => 'SalesItemLineDetail', 'Amount' => 329.40, 'Description' => $d . "\n3000, Gift Certificate Vouchers, digitally printed full color front only, full bleed, on 130# C2S (1107404).",
                              'SalesItemLineDetail' => ['ItemRef' => ['value' => '2', 'name' => 'Gift Certificates'], 'Qty' => 3000, 'UnitPrice' => 0.1098, 'TaxCodeRef' => ['value' => 'TAX']]];
            return ['invoice' => ['Id' => $open ? '9113' : '9112', 'DocNumber' => $no, 'TxnDate' => '2026-10-11', 'DueDate' => '2026-10-11', 'TotalAmt' => 1111.14, 'Balance' => $open ? 1111.14 : 0,
                    'CustomerRef' => ['value' => '58', 'name' => 'Sonoran Hospitality Group'], 'BillEmail' => ['Address' => 'terry@sonoranhospitality.example'],
                    'BillAddr' => ['Line1' => 'Terry Craig', 'Line2' => 'Sonoran Hospitality Group', 'Line3' => '23857 N. Scottsdale Rd.', 'City' => 'Scottsdale', 'CountrySubDivisionCode' => 'AZ', 'PostalCode' => '85255'],
                    'ShipAddr' => ['Line1' => 'Jalapeno Inferno HQ', 'Line2' => '22646 N 55TH ST.', 'City' => 'PHOENIX', 'CountrySubDivisionCode' => 'AZ', 'PostalCode' => '85054'],
                    'TxnTaxDetail' => ['TotalTax' => 89.94],
                    'Line' => [$gc('$25 Gift Certificates'), $gc('$50 Gift Certificates'), $gc('$100 Gift Certificates'),
                        ['DetailType' => 'SalesItemLineDetail', 'Amount' => 15, 'Description' => 'Shrink Wrapping: Packaged in lots of 250 certificates in shrink wrap.', 'SalesItemLineDetail' => ['ItemRef' => ['value' => '4', 'name' => 'Shrink Wrapping'], 'Qty' => 1, 'UnitPrice' => 15, 'TaxCodeRef' => ['value' => 'NON']]],
                        ['DetailType' => 'SalesItemLineDetail', 'Amount' => 18, 'Description' => 'Product will be shipped directly from production house to your shipping address on-file.', 'SalesItemLineDetail' => ['ItemRef' => ['value' => '3', 'name' => 'Shipping'], 'Qty' => 1, 'UnitPrice' => 18, 'TaxCodeRef' => ['value' => 'NON']]],
                        ['DetailType' => 'SubTotalLineDetail', 'Amount' => 1021.20]],
                    'LinkedTxn' => $open ? [] : [['TxnId' => '7001', 'TxnType' => 'Payment']]],
                'customer' => ['Id' => '58', 'DisplayName' => 'Sonoran Hospitality Group', 'CompanyName' => 'Sonoran Hospitality Group', 'GivenName' => 'Terry', 'FamilyName' => 'Craig', 'PrimaryEmailAddr' => ['Address' => 'terry@sonoranhospitality.example'], 'PrimaryPhone' => ['FreeFormNumber' => '(480) 555-0142']],
                'payments' => $open ? [] : [['id' => '7001', 'date' => '2026-10-19', 'cents' => 111114]]];
        }
        $f = self::query($pdo, "select * from Invoice where DocNumber = '" . self::q($no) . "'");
        $inv = (array) (($f['Invoice'] ?? [])[0] ?? []);
        if (!$inv) return null;
        $cust = []; try { $cust = self::fetch($pdo, 'Customer', (string) ($inv['CustomerRef']['value'] ?? '')); } catch (Throwable $e) { error_log('qb pull customer: ' . $e->getMessage()); }
        $pays = [];
        foreach ((array) ($inv['LinkedTxn'] ?? []) as $t) {
            if (($t['TxnType'] ?? '') !== 'Payment' || count($pays) >= 10) continue;
            try {
                $p = self::fetch($pdo, 'Payment', (string) $t['TxnId']); $amt = 0.0;
                foreach ((array) ($p['Line'] ?? []) as $pl) foreach ((array) ($pl['LinkedTxn'] ?? []) as $lt) if (($lt['TxnType'] ?? '') === 'Invoice' && (string) $lt['TxnId'] === (string) $inv['Id']) $amt += (float) ($pl['Amount'] ?? 0);
                $pays[] = ['id' => (string) $t['TxnId'], 'date' => (string) ($p['TxnDate'] ?? ''), 'cents' => (int) round($amt * 100)];
            } catch (Throwable $e) { error_log('qb pull payment: ' . $e->getMessage()); }
        }
        return ['invoice' => $inv, 'customer' => $cust, 'payments' => $pays];
    }

    /** QuickBooks' item list, read only (decisions/0128): Id, Name, Description, UnitPrice, Taxable, Active, Type. */
    public static function items(PDO $pdo): array
    {
        if (self::env() === 'mock') return [   // local test only
            ['Id' => '1', 'Name' => 'Business cards', 'Description' => '16pt, full color both sides', 'UnitPrice' => 0.08, 'Taxable' => true, 'Active' => true, 'Type' => 'Service'],
            ['Id' => '2', 'Name' => 'Gift Certificates', 'Description' => 'Digitally printed, 130# C2S', 'UnitPrice' => 0.1098, 'Taxable' => true, 'Active' => true, 'Type' => 'Service'],
            ['Id' => '3', 'Name' => 'Shipping', 'Description' => 'Shipped to your address', 'UnitPrice' => 18, 'Taxable' => false, 'Active' => true, 'Type' => 'Service'],
            ['Id' => '4', 'Name' => 'Shrink Wrapping', 'Description' => 'Packaged in lots', 'UnitPrice' => 15, 'Taxable' => false, 'Active' => true, 'Type' => 'Service'],
            ['Id' => '5', 'Name' => 'Magnetic Business Cards', 'Description' => '', 'UnitPrice' => 0.35, 'Taxable' => true, 'Active' => true, 'Type' => 'Service'],
            ['Id' => '6', 'Name' => 'Old brochure item', 'Description' => '', 'UnitPrice' => 0, 'Taxable' => true, 'Active' => false, 'Type' => 'Service'],
        ];
        $out = [];
        for ($start = 1; $start < 20000; $start += 500) {
            $f = self::query($pdo, 'select * from Item where Active in (true, false) startposition ' . $start . ' maxresults 500');
            $page = (array) ($f['Item'] ?? []);
            foreach ($page as $i) if (in_array((string) ($i['Type'] ?? ''), ['Service', 'NonInventory', 'Inventory', 'Group', 'Bundle'], true)) $out[] = $i;
            if (count($page) < 500) break;
        }
        return $out;
    }

    /** A QuickBooks product by name (a catalog product, or "Custom work"), made as a Service on first use. */
    private static function namedItem(PDO $pdo, string $name, string $desc, bool $taxable): string
    {
        $name = mb_substr(trim(str_replace([':', '"'], ['-', ''], $name)), 0, 100);
        $found = self::query($pdo, "select Id from Item where Name = '" . self::q($name) . "'");
        if (!empty($found['Item'][0]['Id'])) return (string) $found['Item'][0]['Id'];
        $acct = (string) (getenv('QB_INCOME_ACCOUNT_ID') ?: '');
        if ($acct === '') { $a = self::query($pdo, "select Id from Account where AccountType = 'Income' and Active = true maxresults 1"); $acct = (string) ($a['Account'][0]['Id'] ?? ''); }
        if ($acct === '') throw new RuntimeException('QuickBooks has no income account to record sales in. Set QB_INCOME_ACCOUNT_ID in .env.');
        $j = self::call($pdo, 'POST', 'item', ['Name' => $name, 'Type' => 'Service', 'Taxable' => $taxable, 'Description' => mb_substr($desc, 0, 4000), 'IncomeAccountRef' => ['value' => $acct]]);
        $id = (string) ($j['Item']['Id'] ?? '');
        if ($id === '') throw new RuntimeException('QuickBooks didn\'t make the product "' . $name . '".');
        return $id;
    }

    private static function link(PDO $pdo, string $id): string
    {
        $j = self::call($pdo, 'GET', 'invoice/' . $id, null, ['include' => 'invoiceLink']);
        $l = (string) ($j['Invoice']['InvoiceLink'] ?? '');
        return preg_match('#^https://#', $l) ? $l : '';
    }

    /** Has the order's invoice been paid in full? Keeps its tax and total up to date. */
    public static function paid(PDO $pdo, int $oid): bool
    {
        $o = $pdo->query('SELECT * FROM orders WHERE id = ' . (int) $oid)->fetch(PDO::FETCH_ASSOC);
        if (!$o || !$o['invoice_id']) return false;
        if (!empty($o['qb_env']) && self::env() !== 'mock' && $o['qb_env'] !== self::env()) return false;   // made in the other mode
        if (self::env() === 'mock') return $o['note'] === 'mock-paid';
        $j = self::call($pdo, 'GET', 'invoice/' . rawurlencode((string) $o['invoice_id']));
        $inv = (array) ($j['Invoice'] ?? []);
        $total = (float) ($inv['TotalAmt'] ?? 0);
        $pdo->prepare('UPDATE orders SET tax_cents = ?, total_cents = ? WHERE id = ?')
            ->execute([(int) round(((float) ($inv['TxnTaxDetail']['TotalTax'] ?? 0)) * 100), (int) round($total * 100), (int) $oid]);
        return $total > 0 && (float) ($inv['Balance'] ?? $total) <= 0.004;
    }

    // ---- refunds (decisions/0098) ----------------------------------------------------------------------------------------

    /** The tag on every QuickBooks record the site makes for an order, so the webhook knows it's ours: [TRV:key]. */
    public static function mark(string $key): string { return '[TRV:' . substr(preg_replace('/[^A-Za-z0-9_-]/', '', $key), 0, 50) . ']'; }

    public static function isOurs(array $doc): bool { return str_contains((string) ($doc['PrivateNote'] ?? ''), '[TRV:'); }

    /** Was the connection made with QuickBooks Payments allowed (needed to refund a card from here)? */
    public static function canRefundCards(PDO $pdo): bool
    {
        if (self::env() === 'mock') return true;
        $c = self::connection($pdo);
        return $c && str_contains((string) ($c['scopes'] ?? ''), 'com.intuit.quickbooks.payment');
    }

    private static function paymentsApi(): string
    {
        return (string) (getenv('QB_TEST_API') ?: '') ?: (self::env() === 'sandbox' ? 'https://sandbox.api.intuit.com' : 'https://api.intuit.com');
    }

    /** One QuickBooks Payments call (/quickbooks/v4/payments/…). Request-Id: Intuit does it once per id (no double refund). */
    private static function payCall(PDO $pdo, string $method, string $path, ?array $body, string $requestId): array
    {
        [$tok] = self::access($pdo);
        $url = self::paymentsApi() . '/quickbooks/v4/payments/' . $path;
        $rid = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $requestId), 0, 50);
        $send = fn (string $tok) => self::httpRetry($method, $url, ['Accept: application/json', 'Content-Type: application/json', 'Authorization: Bearer ' . $tok, 'Request-Id: ' . $rid],
            $body !== null ? json_encode($body, JSON_UNESCAPED_SLASHES) : null);
        [$code, $j, $raw, $tid] = $send($tok);
        if ($code === 401) { [$tok] = self::access($pdo, true); [$code, $j, $raw, $tid] = $send($tok); }
        if ($code < 200 || $code >= 300) {
            $err = $j['errors'][0] ?? null;
            $msg = is_array($err) ? trim(($err['code'] ?? '') . ' ' . ($err['message'] ?? '') . (!empty($err['detail']) ? ': ' . $err['detail'] : '') . (!empty($err['moreInfo']) ? ' (' . $err['moreInfo'] . ')' : '')) : self::faultText($j, $raw);
            throw new RuntimeException('QuickBooks Payments (' . $code . '): ' . $msg . ($tid !== '' ? ' [intuit_tid ' . $tid . ']' : ''), $code);
        }
        return $j;
    }

    /** The QuickBooks customer an order was invoiced to (kept on the order once known). */
    public static function orderCustomer(PDO $pdo, array $o): string
    {
        if (!empty($o['qb_customer_id'])) return (string) $o['qb_customer_id'];
        if (empty($o['invoice_id']) || self::env() === 'mock') return '';
        $j = self::call($pdo, 'GET', 'invoice/' . rawurlencode((string) $o['invoice_id']));
        $c = (string) ($j['Invoice']['CustomerRef']['value'] ?? '');
        if ($c !== '') try { $pdo->prepare('UPDATE orders SET qb_customer_id = ? WHERE id = ?')->execute([$c, (int) $o['id']]); } catch (Throwable) {}
        return $c;
    }

    // ---- the card, taken on our checkout page (decisions/0098) --------------------------------------------------------
    //
    // The card number goes from the buyer's browser straight to Intuit (the tokens endpoint, no credentials needed, as
    // Intuit's own Payments SDK calls it), which hands back a one-time token. Our server only ever sees that token: it
    // charges it, then records the payment against the order's invoice in QuickBooks, linked to the charge.

    /** Where the browser sends the card for its one-time token ('' in the local test). */
    public static function tokenUrl(): string
    {
        $e = self::env();
        if ($e === 'mock') return '';
        if (getenv('QB_TEST_API')) return rtrim((string) getenv('QB_TEST_API'), '/') . '/quickbooks/v4/payments/tokens';
        return ($e === 'sandbox' ? 'https://sandbox.api.intuit.com' : 'https://api.intuit.com') . '/quickbooks/v4/payments/tokens';
    }

    /**
     * Charges the card token for the order's total (captured at once: pay on approval, no holds). Returns the charge id.
     * A decline throws with the bank's reason and "nothing was charged". $key makes a repeat the same charge.
     */
    public static function chargeCard(PDO $pdo, array $o, string $token, string $key, ?int $cents = null): string
    {
        self::guardReal($pdo, $o);   // never real money for a test
        $amount = number_format(((int) ($cents ?? $o['total_cents'])) / 100, 2, '.', '');   // $cents: a deposit or the balance (client orders)
        if (self::env() === 'mock') {
            if (str_contains($token, 'decline')) throw new RuntimeException('Your card was declined (test). Nothing was charged.');
            return 'MCH-' . (int) $o['id'] . '-' . substr(hash('sha256', $key), 0, 6);
        }
        if (!self::canRefundCards($pdo)) throw new RuntimeException('Card payments need QuickBooks reconnected (E-Commerce → Payments). Nothing was charged.');
        try { self::access($pdo); }   // a connection problem shows here, before anything is sent
        catch (Throwable $e) { throw new RuntimeException('Card payments aren\'t available right now (' . $e->getMessage() . '). Nothing was charged.'); }
        try {
            $j = self::payCall($pdo, 'POST', 'charges', ['amount' => $amount, 'currency' => 'USD', 'token' => $token, 'capture' => true,
                'description' => 'Traversence order #' . Orders::no($o), 'context' => ['mobile' => false, 'isEcommerce' => true]], $key);
        } catch (RuntimeException $e) {
            $c = $e->getCode();
            if ($c >= 400 && $c < 500) {
                error_log('qb charge order ' . (int) $o['id'] . ': ' . $e->getMessage());
                throw new RuntimeException('The card wasn\'t accepted: ' . trim(preg_replace(['/^QuickBooks Payments \(\d+\): /', '/\s*\[intuit_tid [^\]]*\]/', '/\bPMT-\d+\s*/'], '', $e->getMessage())) . '. Nothing was charged.');
            }
            throw new RuntimeException('QuickBooks Payments didn\'t answer, so we can\'t tell yet whether the card was charged. Don\'t pay again: refresh this page in a minute.');
        }
        $st = strtoupper((string) ($j['status'] ?? ''));
        if ($st !== 'CAPTURED' && $st !== 'SETTLED') throw new RuntimeException('The card was declined' . ($st !== '' ? ' (' . strtolower($st) . ')' : '') . '. Nothing was charged.');
        $id = (string) ($j['id'] ?? '');
        if ($id === '') throw new RuntimeException('QuickBooks Payments didn\'t say which charge it made. Don\'t pay again: we\'ll check and email you.');
        return $id;
    }

    /**
     * The payment in the books: a QuickBooks payment on the order's invoice, marked as made through QuickBooks Payments
     * (TxnSource IntuitPayment, the charge as its CCTransId) so it matches the deposit. If QuickBooks won't take it in
     * that form, a plain payment with the charge as its reference. Returns ['id', 'linked' (bool)].
     */
    public static function recordCardPayment(PDO $pdo, array $o, string $chargeId, string $key, ?int $cents = null): array
    {
        self::guardReal($pdo, $o);   // never real money for a test
        if (self::env() === 'mock') return ['id' => 'MPY-' . (int) $o['id'], 'linked' => true];
        $cust = self::orderCustomer($pdo, $o);
        $amt = ((int) ($cents ?? $o['total_cents'])) / 100;
        $base = ['CustomerRef' => ['value' => $cust], 'TotalAmt' => $amt, 'PaymentRefNum' => mb_substr($chargeId, 0, 21),
                 'Line' => [['Amount' => $amt, 'LinkedTxn' => [['TxnId' => (string) $o['invoice_id'], 'TxnType' => 'Invoice']]]],
                 'PrivateNote' => 'Traversence order #' . Orders::no($o) . ', card charge ' . $chargeId . ' ' . self::mark($key)];
        try {
            $j = self::call($pdo, 'POST', 'payment', $base + ['TxnSource' => 'IntuitPayment',
                'CreditCardPayment' => ['CreditChargeInfo' => ['ProcessPayment' => true], 'CreditChargeResponse' => ['CCTransId' => $chargeId]]], [], $key);
            return ['id' => (string) ($j['Payment']['Id'] ?? ''), 'linked' => true];
        } catch (Throwable $e) {
            error_log('qb card payment, linked form refused: ' . $e->getMessage());
            $j = self::call($pdo, 'POST', 'payment', $base, [], $key . 'p');
            return ['id' => (string) ($j['Payment']['Id'] ?? ''), 'linked' => false];
        }
    }

    /**
     * Money that came in another way (a wire, a check, cash), recorded by our team: a QuickBooks payment received on the
     * order's invoice, with the client's reference, so the invoice shows paid (Jason, 2026-10-28). Returns its id.
     */
    public static function recordOtherPayment(PDO $pdo, array $o, int $cents, string $method, string $ref, string $key): string
    {
        self::guardReal($pdo, $o);   // never real money for a test
        if (self::env() === 'mock') return 'MPY-' . (int) $o['id'];
        $amt = $cents / 100;
        $j = self::call($pdo, 'POST', 'payment', ['CustomerRef' => ['value' => self::orderCustomer($pdo, $o)], 'TotalAmt' => $amt,
            'PaymentRefNum' => mb_substr($ref !== '' ? $ref : $method, 0, 21),
            'Line' => [['Amount' => $amt, 'LinkedTxn' => [['TxnId' => (string) $o['invoice_id'], 'TxnType' => 'Invoice']]]],
            'PrivateNote' => mb_substr('Traversence order #' . Orders::no($o) . ', ' . strtolower($method) . ($ref !== '' ? ' ' . $ref : '') . ', recorded by our team ' . self::mark($key), 0, 4000)], [], $key);
        return (string) ($j['Payment']['Id'] ?? '');
    }

    /** The card charge that paid an order's invoice: its QuickBooks Payments id (CCTransId), or '' (paid another way). */
    public static function chargeFor(PDO $pdo, array $o): string
    {
        if (!empty($o['charge_id'])) return (string) $o['charge_id'];   // taken on our checkout page
        self::guardReal($pdo, $o);   // never real money for a test
        if (self::env() === 'mock') return 'MCH-' . (int) $o['id'];
        $cust = self::orderCustomer($pdo, $o);
        if ($cust === '') return '';
        $f = self::query($pdo, "select * from Payment where CustomerRef = '" . self::q($cust) . "' maxresults 100");
        foreach ((array) ($f['Payment'] ?? []) as $p) {
            foreach ((array) ($p['Line'] ?? []) as $l) foreach ((array) ($l['LinkedTxn'] ?? []) as $t) {
                if (($t['TxnType'] ?? '') === 'Invoice' && (string) ($t['TxnId'] ?? '') === (string) $o['invoice_id']) {
                    $id = (string) ($p['CreditCardPayment']['CreditChargeResponse']['CCTransId'] ?? '');
                    if ($id !== '') return $id;
                }
            }
        }
        return '';
    }

    /**
     * Refunds the card that paid the order, through QuickBooks Payments. Returns the refund's id. Throws with a plain
     * reason when it can't (paid by bank transfer, connected before card refunds, or QuickBooks refused).
     */
    public static function refundCard(PDO $pdo, array $o, int $cents, string $note, string $key): string
    {
        if (self::env() === 'mock') return 'MRF-' . (int) $o['id'] . '-' . $cents;
        if (!self::canRefundCards($pdo)) throw new RuntimeException('QuickBooks was connected before card refunds were turned on: reconnect it (E-Commerce → Payments), or refund it in QuickBooks and the site will record it.');
        $charge = self::chargeFor($pdo, $o);
        if ($charge === '') throw new RuntimeException('This invoice wasn\'t paid by a card charge through QuickBooks Payments (it was paid by bank transfer, or the payment was recorded by hand in QuickBooks), so there\'s no card to refund from here. Refund it in QuickBooks: the site records it when QuickBooks tells us.');
        try {
            $j = self::payCall($pdo, 'POST', 'charges/' . rawurlencode($charge) . '/refunds',
                ['amount' => number_format($cents / 100, 2, '.', ''), 'description' => mb_substr('Traversence order #' . Orders::no($o) . ($note !== '' ? ': ' . $note : ''), 0, 4000)], $key);
        } catch (RuntimeException $e) {
            throw new RuntimeException('Nothing was refunded: ' . $e->getMessage() . '. Try again, or refund it in QuickBooks (the site records it when QuickBooks tells us).');
        }
        $st = strtoupper((string) ($j['status'] ?? ''));
        if (in_array($st, ['DECLINED', 'CANCELLED'], true)) throw new RuntimeException('QuickBooks Payments declined the refund (' . $st . '). Nothing was refunded.');
        return (string) ($j['id'] ?? '');
    }

    /**
     * The refund in the books: a Refund Receipt for the order's customer, with the tax in the same proportion as the
     * order's (so sales tax owed comes down), from the account in QB_REFUND_ACCOUNT_ID or the first bank account.
     * Tagged [TRV:key] so the webhook knows it's ours. Returns its number.
     */
    public static function refundReceipt(PDO $pdo, array $o, int $cents, string $note, string $key, string $cardRefundId): string
    {
        if (self::env() === 'mock') return 'MRR-' . (int) $o['id'] . '-' . $cents;
        $cust = self::orderCustomer($pdo, $o);
        if ($cust === '') throw new RuntimeException('QuickBooks didn\'t find the order\'s customer.');
        $acct = (string) (getenv('QB_REFUND_ACCOUNT_ID') ?: '');
        if ($acct === '') { $a = self::query($pdo, "select Id from Account where AccountType = 'Bank' and Active = true maxresults 1"); $acct = (string) ($a['Account'][0]['Id'] ?? ''); }
        if ($acct === '') throw new RuntimeException('QuickBooks has no bank account to refund from. Set QB_REFUND_ACCOUNT_ID in .env.');
        $total = max(1, (int) $o['total_cents']);
        $tax = (int) round($cents * ((int) $o['tax_cents']) / $total);
        $sub = $cents - $tax;
        $body = ['CustomerRef' => ['value' => $cust], 'DepositToAccountRef' => ['value' => $acct],
            'Line' => [['DetailType' => 'SalesItemLineDetail', 'Amount' => $sub / 100, 'Description' => 'Refund, Traversence order #' . Orders::no($o) . ($note !== '' ? ': ' . mb_substr($note, 0, 120) : ''),
                        'SalesItemLineDetail' => ['ItemRef' => ['value' => self::itemId($pdo)], 'Qty' => 1, 'UnitPrice' => $sub / 100, 'TaxCodeRef' => ['value' => $tax > 0 ? 'TAX' : 'NON']]]],
            'PrivateNote' => 'Traversence refund, order #' . Orders::no($o) . ($o['invoice_no'] ? ', invoice ' . $o['invoice_no'] : '') . ($cardRefundId !== '' ? ', card refund ' . $cardRefundId : '') . ' ' . self::mark($key)];
        if ($tax > 0) $body['TxnTaxDetail'] = ['TotalTax' => $tax / 100];   // the tax refunded, as charged (not worked out again)
        if ($cardRefundId !== '') $body['PaymentRefNum'] = mb_substr($cardRefundId, 0, 21);
        if (filter_var((string) $o['bill_email'], FILTER_VALIDATE_EMAIL)) $body['BillEmail'] = ['Address' => (string) $o['bill_email']];
        $j = self::call($pdo, 'POST', 'refundreceipt', $body, [], $key);
        $rr = (array) ($j['RefundReceipt'] ?? []);
        return (string) ($rr['DocNumber'] ?? $rr['Id'] ?? '');
    }

    /** A Refund Receipt or credit memo from QuickBooks, by id (for the webhook). */
    public static function fetch(PDO $pdo, string $entity, string $id): array
    {
        $j = self::call($pdo, 'GET', strtolower($entity) . '/' . rawurlencode($id));
        return (array) ($j[$entity] ?? []);
    }

    /** Refund Receipts (or credit memos) made in QuickBooks lately, for "Check QuickBooks" (a missed webhook). */
    public static function recent(PDO $pdo, string $entity, int $days = 45): array
    {
        if (self::env() === 'mock') return [];
        $f = self::query($pdo, 'select * from ' . $entity . " where TxnDate >= '" . date('Y-m-d', strtotime("-$days days")) . "' maxresults 200");
        return (array) ($f[$entity] ?? []);
    }

    /** The orders invoiced to a QuickBooks customer (their invoices), for matching a refund made in QuickBooks. */
    public static function customerInvoices(PDO $pdo, string $cust): array
    {
        if ($cust === '' || self::env() === 'mock') return [];
        $f = self::query($pdo, "select Id from Invoice where CustomerRef = '" . self::q($cust) . "' maxresults 200");
        return array_map(fn ($i) => (string) $i['Id'], (array) ($f['Invoice'] ?? []));
    }

    // ---- webhooks ------------------------------------------------------------------------------------------------------

    /** Is this webhook really from QuickBooks: its intuit-signature is the HMAC of the body with our verifier token? */
    public static function verify(string $body, string $signature): bool
    {
        return self::verifyEnv($body, $signature) !== '';
    }

    /** Which mode's verifier token signed this webhook: production, sandbox, or '' (neither: refuse it). */
    public static function verifyEnv(string $body, string $signature): string
    {
        if ($signature === '') return '';
        foreach (['production', 'sandbox'] as $env) {
            $tok = self::key('WEBHOOK_TOKEN', $env);
            if ($tok !== '' && hash_equals(base64_encode(hash_hmac('sha256', $body, $tok, true)), $signature)) return $env;
        }
        return '';
    }

    /** The invoices a webhook's payments and invoice changes touch. */
    /**
     * A credit on the customer's account (decisions/0098: fix, then credit, then refund): a QuickBooks credit memo for
     * the order's customer, not taxed (it's money back on account). QuickBooks applies open credits to the customer's
     * next invoice when "Automatically apply credits" is on (Settings → Advanced → Automation). Returns its number.
     */
    public static function creditMemo(PDO $pdo, array $o, int $cents, string $note, string $requestId): string
    {
        if (self::env() === 'mock') return 'MCM-' . (int) $o['id'] . '-' . $cents;
        $addr = ['Line1' => (string) $o['bill_street'], 'City' => (string) $o['bill_city'], 'CountrySubDivisionCode' => strtoupper((string) $o['bill_state']), 'PostalCode' => (string) $o['bill_zip'], 'Country' => 'USA'];
        $b = ['name' => (string) $o['bill_name'], 'email' => (string) $o['bill_email']];
        $cust = self::customerId($pdo, (int) ($o['user_id'] ?? 0), $b, $addr);
        if ($cust === '') throw new RuntimeException('QuickBooks didn\'t find the customer.');
        $amt = round($cents / 100, 2);
        $j = self::call($pdo, 'POST', 'creditmemo', ['CustomerRef' => ['value' => $cust], 'BillEmail' => ['Address' => (string) $o['bill_email']],
            'Line' => [['DetailType' => 'SalesItemLineDetail', 'Amount' => $amt, 'Description' => 'Account credit, order #' . Orders::no($o) . ($note !== '' ? ': ' . mb_substr($note, 0, 120) : ''),
                        'SalesItemLineDetail' => ['ItemRef' => ['value' => self::itemId($pdo)], 'Qty' => 1, 'UnitPrice' => $amt, 'TaxCodeRef' => ['value' => 'NON']]]],
            'PrivateNote' => 'Traversence credit for order #' . Orders::no($o) . ' ' . self::mark($requestId)], [], $requestId);
        $cm = (array) ($j['CreditMemo'] ?? []);
        return (string) ($cm['DocNumber'] ?? $cm['Id'] ?? '');
    }

    /** What else a webhook reports: [['RefundReceipt'|'CreditMemo', id, operation], …]. */
    public static function refundsIn(array $payload): array
    {
        $out = [];
        foreach ((array) ($payload['eventNotifications'] ?? []) as $n) {
            foreach ((array) ($n['dataChangeEvent']['entities'] ?? []) as $e) {
                $name = (string) ($e['name'] ?? ''); $id = (string) ($e['id'] ?? '');
                if ($id !== '' && in_array($name, ['RefundReceipt', 'CreditMemo'], true)) $out[$name . ':' . $id] = [$name, $id, (string) ($e['operation'] ?? '')];
            }
        }
        return array_values($out);
    }

    public static function invoicesIn(PDO $pdo, array $payload): array
    {
        $ids = [];
        foreach ((array) ($payload['eventNotifications'] ?? []) as $n) {
            foreach ((array) ($n['dataChangeEvent']['entities'] ?? []) as $e) {
                $name = (string) ($e['name'] ?? ''); $id = (string) ($e['id'] ?? '');
                if ($id === '') continue;
                if ($name === 'Invoice') $ids[$id] = true;
                if ($name === 'Payment') {
                    try {
                        $p = self::call($pdo, 'GET', 'payment/' . rawurlencode($id));
                        foreach ((array) ($p['Payment']['Line'] ?? []) as $l) foreach ((array) ($l['LinkedTxn'] ?? []) as $t) if (($t['TxnType'] ?? '') === 'Invoice') $ids[(string) $t['TxnId']] = true;
                    } catch (Throwable $x) { error_log('qb webhook payment ' . $id . ': ' . $x->getMessage()); }
                }
            }
        }
        return array_keys($ids);
    }

    // ---- subscriptions (decisions/0108, option B): a card kept on file in QuickBooks Payments, charged on schedule ------
    //
    // The card goes from the browser to Intuit for a one-time token (as at checkout); the token is turned into a card on
    // file in QuickBooks Payments' wallet for the account (customers/{wallet}/cards), and each renewal charges that card.
    // Our server never sees the card number. Each charge is written into the books as a Sales Receipt linked to it.
    // To verify against the sandbox before production: the wallet call (createFromToken) and the cardOnFile charge.

    /** Keeps the card behind $token on file for $wallet (our own id for the account). Returns [card id, "Visa ••1111", "YYYY-MM" it expires ('' if not given)]. */
    public static function saveCard(PDO $pdo, string $wallet, string $token, string $key): array
    {
        if (self::env() === 'mock') {
            if (str_contains($token, 'decline')) throw new RuntimeException('That card wasn\'t accepted (test). Nothing was saved or charged.');
            return ['MCARD-' . substr(hash('sha256', $wallet . $token), 0, 10), 'Visa ••' . (preg_match('/(\d{4})$/', $token, $m) ? $m[1] : '4242'), str_contains($token, 'expiring') ? date('Y-m') : date('Y-m', strtotime('+3 years'))];
        }
        if (!self::canRefundCards($pdo)) throw new RuntimeException('Card payments need QuickBooks reconnected (E-Commerce → Payments). Nothing was saved or charged.');
        [$tok] = self::access($pdo);
        $url = self::paymentsApi() . '/quickbooks/v4/customers/' . rawurlencode($wallet) . '/cards/createFromToken';
        [$code, $j, $raw] = self::httpRetry('POST', $url, ['Accept: application/json', 'Content-Type: application/json', 'Authorization: Bearer ' . $tok,
            'Request-Id: ' . substr(preg_replace('/[^A-Za-z0-9_-]/', '', $key), 0, 50)], json_encode(['value' => $token]));
        if ($code < 200 || $code >= 300 || empty($j['id'])) {
            $e = $j['errors'][0] ?? null;
            throw new RuntimeException('The card wasn\'t saved: ' . (is_array($e) ? trim(($e['message'] ?? '') . (!empty($e['detail']) ? ': ' . $e['detail'] : '')) : 'QuickBooks Payments answered ' . $code) . '. Nothing was charged.');
        }
        $num = (string) ($j['number'] ?? '');
        $exp = ((int) ($j['expYear'] ?? 0) > 2000 && (int) ($j['expMonth'] ?? 0) >= 1) ? sprintf('%04d-%02d', (int) $j['expYear'], (int) $j['expMonth']) : '';
        return [(string) $j['id'], trim(ucfirst(strtolower((string) ($j['cardType'] ?? 'Card'))) . ' ••' . substr(preg_replace('/\D/', '', $num), -4)), $exp];
    }

    /** Charges a card on file (a renewal, or the first payment of a plan). Returns the charge id; throws on a decline. */
    /** Refunds a charge by its id (a domain we couldn't register after charging for it, decisions/0139). Returns the refund's id. */
    public static function refundCharge(PDO $pdo, string $chargeId, int $cents, string $note, string $key): string
    {
        if (self::env() === 'mock') return 'MRF-' . substr(hash('sha256', $chargeId), 0, 8);
        $j = self::payCall($pdo, 'POST', 'charges/' . rawurlencode($chargeId) . '/refunds', ['amount' => number_format($cents / 100, 2, '.', ''), 'description' => mb_substr($note, 0, 4000)], $key);
        $st = strtoupper((string) ($j['status'] ?? ''));
        if (in_array($st, ['DECLINED', 'CANCELLED'], true)) throw new RuntimeException('QuickBooks Payments declined the refund (' . $st . ').');
        return (string) ($j['id'] ?? '');
    }

    public static function chargeSaved(PDO $pdo, string $cardId, int $cents, string $what, string $key): string
    {
        if (self::env() === 'mock') {
            if (str_contains($cardId, 'decline') || getenv('QB_MOCK_DECLINE')) throw new RuntimeException('The card was declined (test).', 402);
            return 'MCH-S-' . substr(hash('sha256', $key), 0, 8);
        }
        try {
            $j = self::payCall($pdo, 'POST', 'charges', ['amount' => number_format($cents / 100, 2, '.', ''), 'currency' => 'USD', 'cardOnFile' => $cardId, 'capture' => true,
                'description' => mb_substr($what, 0, 4000), 'context' => ['mobile' => false, 'isEcommerce' => true, 'recurring' => true]], $key);
        } catch (RuntimeException $e) {
            $c = $e->getCode();
            if ($c >= 400 && $c < 500) throw new RuntimeException('The card was declined: ' . trim(preg_replace(['/^QuickBooks Payments \(\d+\): /', '/\s*\[intuit_tid [^\]]*\]/'], '', $e->getMessage())), 402);
            throw new RuntimeException('QuickBooks Payments didn\'t answer; the charge will be checked and tried again.', 503);
        }
        $st = strtoupper((string) ($j['status'] ?? ''));
        if ($st !== 'CAPTURED' && $st !== 'SETTLED') throw new RuntimeException('The card was declined' . ($st !== '' ? ' (' . strtolower($st) . ')' : '') . '.', 402);
        return (string) ($j['id'] ?? '');
    }

    /**
     * The same Sales Receipt for a card charge, with each line on its own product's QuickBooks item when the catalog links
     * one (Books::itemFor; decisions/0166 §4 sets those up with their income and cost accounts), else on today's item, so
     * no account is chosen here. $lines: [[title, cents, item ref or ''], …]. Domains first (0169 §1a). Returns its id.
     */
    public static function salesReceiptFor(PDO $pdo, int $uid, array $b, array $lines, string $chargeId, string $key, string $note = 'Traversence sale'): string
    {
        if (self::env() === 'mock') return 'MSR-' . substr(hash('sha256', $key), 0, 8);
        $cust = self::customerId($pdo, $uid, $b, []);
        $fallback = '';
        $ql = [];
        foreach ($lines as $l) {
            [$title, $cents] = $l; $item = (string) ($l[2] ?? '');
            if ($item === '') $item = $fallback !== '' ? $fallback : ($fallback = self::namedItem($pdo, 'Traversence plan', 'Traversence plans and add-ons, billed by the month or year', false));
            $ql[] = ['DetailType' => 'SalesItemLineDetail', 'Amount' => round($cents / 100, 2), 'Description' => mb_substr((string) $title, 0, 4000),
                     'SalesItemLineDetail' => ['ItemRef' => ['value' => $item], 'Qty' => 1, 'UnitPrice' => round($cents / 100, 2), 'TaxCodeRef' => ['value' => 'NON']]];
        }
        $j = self::call($pdo, 'POST', 'salesreceipt', ['CustomerRef' => ['value' => $cust], 'Line' => $ql, 'BillEmail' => ['Address' => (string) $b['email']],
            'PaymentRefNum' => mb_substr($chargeId, 0, 21), 'TxnSource' => 'IntuitPayment',
            'CreditCardPayment' => ['CreditChargeInfo' => ['ProcessPayment' => true], 'CreditChargeResponse' => ['CCTransId' => $chargeId]],
            'PrivateNote' => mb_substr($note, 0, 200) . ', card charge ' . $chargeId . ' ' . self::mark($key)], [], $key);
        return (string) ($j['SalesReceipt']['Id'] ?? '');
    }

    /**
     * The charge in the books: a Sales Receipt for the account's customer, one line per plan or add-on, linked to the
     * card charge. Plan lines are recorded as not taxable until sales tax on subscriptions is settled with the
     * accountant (set QB_PLAN_TAXABLE=1 to change it). Returns its id.
     */
    public static function salesReceipt(PDO $pdo, int $uid, array $b, array $lines, string $chargeId, string $key): string
    {
        if (self::env() === 'mock') return 'MSR-' . substr(hash('sha256', $key), 0, 8);
        $cust = self::customerId($pdo, $uid, $b, []);
        $tax = (bool) getenv('QB_PLAN_TAXABLE');
        $item = self::namedItem($pdo, 'Traversence plan', 'Traversence plans and add-ons, billed by the month or year', $tax);
        $ql = []; $total = 0;
        foreach ($lines as [$title, $cents]) {
            $total += (int) $cents;
            $ql[] = ['DetailType' => 'SalesItemLineDetail', 'Amount' => round($cents / 100, 2), 'Description' => mb_substr((string) $title, 0, 4000),
                     'SalesItemLineDetail' => ['ItemRef' => ['value' => $item], 'Qty' => 1, 'UnitPrice' => round($cents / 100, 2), 'TaxCodeRef' => ['value' => $tax ? 'TAX' : 'NON']]];
        }
        $j = self::call($pdo, 'POST', 'salesreceipt', ['CustomerRef' => ['value' => $cust], 'Line' => $ql, 'BillEmail' => ['Address' => (string) $b['email']],
            'PaymentRefNum' => mb_substr($chargeId, 0, 21), 'TxnSource' => 'IntuitPayment',
            'CreditCardPayment' => ['CreditChargeInfo' => ['ProcessPayment' => true], 'CreditChargeResponse' => ['CCTransId' => $chargeId]],
            'PrivateNote' => 'Traversence subscription, card charge ' . $chargeId . ' ' . self::mark($key)], [], $key);
        return (string) ($j['SalesReceipt']['Id'] ?? '');
    }
}
