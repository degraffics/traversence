<?php
/**
 * includes/page-shell.php
 *
 * Shared page frame for the rough PLACEHOLDER pages (discovery, hub, dashboard,
 * claim, admin portal, privacy, terms). Same top bar, header, footer and
 * location modal as the home page, so the whole site can be walked through and
 * judged for navigation and feel before each page is properly built.
 *
 *   require_once __DIR__ . '/../../app/ui/page-shell.php';   // from a page one folder down (website/<folder>/)
 *   tv_page_start('Page title');            // call before any output
 *   ... page content ...
 *   tv_page_end();
 *
 * Replace a placeholder by simply uploading the real file over it.
 */
require_once __DIR__ . '/routes.php';
require_once __DIR__ . '/favicon.php';   // the tab's icon (tv_favicon_links)
require_once __DIR__ . '/csp.php';   // nonces for inline scripts; the card pages' policy (decisions/0098, 0135)

function tv_e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/**
 * A page opened inside the dashboard (Jason, 2026-10-09: "everything stays on the dashboard"): no top bar, menu or
 * footer of its own; it reports its height so the dashboard can size it. ?embed=1, or any page loaded in a frame.
 */
function tv_embedded(): bool
{
    return !empty($_GET['embed']) || ($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '') === 'iframe';
}

function tv_page_start(string $title, array $opt = []): void
{
    // Every page knows who is signed in (the toolbar shows you and your role switcher): the same session as the API.
    if (!class_exists('Auth') && !headers_sent()) {
        require_once __DIR__ . '/../bootstrap.php';
        header('Content-Type: text/html; charset=utf-8');   // bootstrap defaults to JSON
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    $desc = $opt['description'] ?? 'Traversence placeholder page.';
    ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex">
  <title><?= tv_e($title) ?> | Traversence</title>
  <meta name="description" content="<?= tv_e($desc) ?>">
  <?= tv_favicon_links() ?>
  <style>html, body { background-color: #EFE3C8; }</style>
  <script src="https://cdn.tailwindcss.com"></script>
  <?= tv_on_js() ?>
<?= $opt['head'] ?? '' /* a page's own tags (share card, canonical): built and escaped by the page */ ?>
</head>
<body class="bg-[#EFE3C8] text-[#3E2B1F] min-h-screen flex flex-col font-sans<?= tv_embedded() ? ' tv-embedded' : '' ?><?= preg_match('#^/(user/|admin/|listing/businessportal)#', (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH)) ? ' tv-back' : '' ?>">   <?php /* tv-back: the signed-in side (your account, staff); everything else is the front end */ ?>
<?php if (tv_embedded()): ?>
<style>body.tv-embedded{min-height:0;background:transparent}body.tv-embedded #tv-main{padding:0 0 1rem}<?php if (!empty($_GET['peek'])): /* in a pop-up: a margin round the page (Jason, 2026-10-14: "the margins are off") */ ?>
  body.tv-embedded #tv-main{padding:.8rem 1rem 1rem}@media (max-width:767px){body.tv-embedded #tv-main{padding:.5rem 3px 1rem}}<?php endif; ?>
  .tv-eback{display:inline-flex;align-items:center;gap:.35rem;margin:0 0 .6rem;padding:.3rem .8rem .3rem .55rem;border:1px solid #CBB98D;border-radius:999px;background:#FFFBF2;color:#92400E;font-weight:700;font-size:.85rem;text-decoration:none}
  .tv-eback:hover{background:#8FBCA8;border-color:#8FBCA8;color:#1F3B30}</style>
<main class="flex-1 w-full" id="tv-main">
<script src="/js/tv-ask.js?v=<?= (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-ask.js') ?>"></script><script src="/js/tv-pager.js?v=<?= (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-pager.js') ?>" defer></script><script src="/js/tv-trail.js?v=<?= (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-trail.js') ?>" defer></script><script src="/js/tv-password.js?v=<?= (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-password.js') ?>"></script><script src="/js/tv-upload.js?v=<?= (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-upload.js') ?>"></script><script src="/js/tv-conf.js?v=<?= (int) @filemtime(dirname(__DIR__, 2) . '/website/js/tv-conf.js') ?>" defer></script><?php /* inline questions, pop-ups and link wrapping work in here too */ ?>
<script src="/js/consent.js?v=<?= (int) @filemtime(dirname(__DIR__, 2) . '/website/js/consent.js') ?>" defer></script><?php /* videos wait for a yes in here too (decisions/0077) */ ?>
<?php
    // inside the dashboard there are no breadcrumbs: the way back is a button at the top (the page's own 'back', or its parent crumb)
    $eb = $opt['back'] ?? null;
    if (!$eb && !empty($opt['crumbs']) && count($opt['crumbs']) > 1) { $pc = $opt['crumbs'][count($opt['crumbs']) - 2]; if (!empty($pc[1]) && !str_starts_with((string) $pc[1], '/user/dashboard.php')) $eb = [$pc[1], $pc[0]]; }
    if (!empty($_GET['peek'])) $eb = null;   // in a pop-up (TvAsk.peek): the pop-up's own × is the way back
    if ($eb) echo '<a class="tv-eback" href="' . tv_e($eb[0]) . '">&lsaquo; ' . tv_e($eb[1]) . '</a>';
    // inside Manage listings (admin/listings.php) its own sections are the way around: no back button there
    if ($eb) echo '<script' . tv_nonce() . '>try { if (window.frameElement && window.frameElement.hasAttribute("data-no-back")) { var b = document.querySelector(".tv-eback"); if (b) b.remove(); } } catch (e) {}</script>';
    require_once __DIR__ . '/app-shell.php';   // the shared helpers pages use (tv_icon, tv_count_item…)
    $GLOBALS['tv_shell'] = 'embed'; return; endif; ?>

<?php try { require_once __DIR__ . '/context-switcher.php'; echo tv_acting_bar(); } catch (Throwable $e) { error_log('acting bar: ' . $e->getMessage()); }   // who you're acting as, above the header (zip 4) ?>
<div id="top-bar" class="bg-[#3E2B1F] border-b border-[#2A1B12] sticky top-0 z-40 shadow-lg">
  <div class="px-3 sm:px-6 py-1 flex items-center justify-between">
    <?php require_once __DIR__ . '/brand.php'; ?>
    <?php require_once __DIR__ . '/header.php'; ?>
  </div>
</div>

<?php if (!empty($opt['app'])): // the app layout (includes/app-shell.php): toolbar left, workspace right, edge to edge ?>
<main class="flex-1 w-full" id="tv-main">
<?php $GLOBALS['tv_shell'] = 'app'; return; endif; ?>
<main class="flex-1 w-full" id="tv-main">
<?php
    // Every page: the toolbar for its part of the site on the left, the page in the workspace (decisions/0055 §1)
    require_once __DIR__ . '/app-shell.php';
    require_once __DIR__ . '/section-rails.php';
    [$sec, $act] = tv_section_for((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH));
    $sec = $opt['section'] ?? $sec; $act = $opt['active'] ?? $act;
    if (isset($opt['rail'])) { $railItems = $opt['rail']; $railLabel = $opt['rail_label'] ?? ''; }
    else {
        $r = tv_section_rail($sec);
        $railLabel = $r['label']; $railSite = !empty($r['site']);
        // "This listing" / "This group" / "This place" show only while you're on one
        $railItems = array_values(array_filter($r['items'], fn ($it) => !in_array($it['key'], ['listing', 'group'], true) || $it['key'] === $act));
    }
    tv_app_open($title, ['rail' => $railItems, 'active' => $act, 'rail_label' => $railLabel, 'bare' => true, 'rail_site' => $railSite ?? false]);
    $GLOBALS['tv_shell'] = 'section';
    ?>
<div class="tv-page space-y-5" style="max-width:none">
<?php
    // Breadcrumb + "Back": every placeholder page gets one. Pass
    // $opt['crumbs'] = [[label, url], ..., [current label]] to override.
    $crumbs = $opt['crumbs'] ?? [['Home', '/'], [$title]];
    if (!empty($opt['no_crumbs'])) { echo ''; }   // a page that says where it is itself (e.g. a place page)
    // admin pages: no breadcrumbs (Jason, 2026-10-03); the menu says where you are, and this goes back to the dashboard
    elseif ($sec === 'admin') { echo '<p class="ta-back"><a href="/admin/">&larr; Admin dashboard</a></p>'; }
    else {
    $backUrl = $opt['back'] ?? (end($crumbs) && count($crumbs) > 1 ? ($crumbs[count($crumbs) - 2][1] ?? '/') : '/');
    ?>
  <nav aria-label="Breadcrumb" class="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#8A7355] -mb-1">
    <a id="tv-back" href="<?= tv_e($backUrl) ?>" class="inline-flex items-center gap-1 font-semibold text-[#5C4632] hover:text-[#3E2B1F] hover:underline mr-2">&larr; Back</a>
    <span class="text-[#CBB98D]" aria-hidden="true">|</span>
    <?php foreach ($crumbs as $i => $c): $last = ($i === count($crumbs) - 1); ?>
      <?php if ($i > 0): ?><span aria-hidden="true">&rsaquo;</span><?php endif; ?>
      <?php if (!$last && !empty($c[1])): ?><a href="<?= tv_e($c[1]) ?>" class="hover:text-[#3E2B1F] hover:underline"><?= tv_e($c[0]) ?></a>
      <?php else: ?><span class="text-[#3E2B1F] font-semibold" aria-current="page"><?= tv_e($c[0]) ?></span><?php endif; ?>
    <?php endforeach; ?>
  </nav>
  <script<?= tv_nonce() ?>>
    // Return to the page they came from (their search, place and filters intact) when it was on this site.
    (function () {
      var b = document.getElementById('tv-back');
      if (!b) return;
      b.addEventListener('click', function (e) {
        try {
          if (document.referrer && new URL(document.referrer).origin === location.origin && history.length > 1) {
            e.preventDefault(); history.back();
          }
        } catch (x) {}
      });
    })();
  </script>
<?php }
}

/** Amber "this is a placeholder" box: what the page will be, and what is real now. */
function tv_placeholder_banner(string $what, array $planned = [], ?string $real = null): void
{
    ?>
  <aside class="rounded-xl border-2 border-dashed border-amber-600/60 bg-amber-100/60 px-4 py-3 text-xs text-[#5C4632]" role="note">
    <p class="font-semibold text-amber-800 uppercase tracking-wide text-[11px] mb-1">Placeholder page</p>
    <p><?= tv_e($what) ?></p>
    <?php if ($planned): ?>
    <ul class="list-disc ml-5 mt-2 space-y-0.5">
      <?php foreach ($planned as $p): ?><li><?= tv_e($p) ?></li><?php endforeach; ?>
    </ul>
    <?php endif; ?>
    <?php if ($real): ?><p class="mt-2"><span class="font-semibold text-green-800">Working now:</span> <?= tv_e($real) ?></p><?php endif; ?>
  </aside>
<?php
}

function tv_page_end(array $opt = []): void
{
    if (($GLOBALS['tv_shell'] ?? '') === 'embed') {
        // links back to the dashboard leave the frame; the frame's height follows the page ?>
</main>
<script<?= tv_nonce() ?>>
(function () {
  document.querySelectorAll('a[href^="/user/dashboard.php"], a[href="/"], a[href^="/login.php"]').forEach(function (a) { a.target = '_top'; });
  function tell() { try { parent.postMessage({ tvEmbed: document.documentElement.scrollHeight, path: location.pathname + location.search }, location.origin); } catch (e) {} }
  window.addEventListener('load', tell); if (window.ResizeObserver) new ResizeObserver(tell).observe(document.body); tell();
})();
</script>
</body>
</html>
<?php   return;
    }
    if (($GLOBALS['tv_shell'] ?? '') === 'section') { echo "</div>\n"; tv_app_close(); $GLOBALS['tv_shell'] = 'app'; }
    $explore   = tv_route(['discovery/index.php' => '/discovery/']);
    $directory = tv_route(['directory/index.php' => '/directory/']);
    $claim     = tv_route(['claim.php' => '/claim.php', 'claim/index.php' => '/claim/']);
    $privacy   = tv_route(['privacy.php' => '/privacy.php']);
    $terms     = tv_route(['terms.php' => '/terms.php']);
    $root = dirname(__DIR__, 2) . '/website';   // the web root (website/)
    ?>
</main>

<?php if (!str_starts_with((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH), '/admin/')): /* the admin has no site footer (Jason, 2026-10-27) */ require_once __DIR__ . '/footer.php'; if (($opt['footer'] ?? '') === 'checkout') tv_footer_checkout(); else tv_footer(); endif; ?>

<?php require_once __DIR__ . '/location-modal.php'; ?>

<script src="/js/location-scope.js?v=<?= (int)@filemtime($root . '/js/location-scope.js') ?>"></script>
<script src="/js/header-nav.js?v=<?= (int)@filemtime($root . '/js/header-nav.js') ?>" defer></script>
</body>
</html>
<?php
}
