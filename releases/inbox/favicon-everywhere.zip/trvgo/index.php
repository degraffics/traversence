<?php
// trvgo/index.php — the trvgo.us router (decisions/0094). trvgo.us's own folder on the server, beside website/ and app/:
// it serves only this. trvgo.us/{code} goes where the code points (a temporary redirect, so a changeable code can be
// pointed somewhere new) or hands over its contact card; trvgo.us itself opens the QR service on traversence.com.
// GO Codes (kind 'go', decisions/0098) are served by what they do: a link goes straight there, a contact card or event
// downloads to the phone, a phone number, text message or email starts the call, text or email at once (the page
// behind it keeps a button, for a browser that won't open the phone's app without a tap),
// and text shows as a page. A refunded or charged-back code is switched off: "This code isn't active" (a 404).
// No session, no cookie: each scan or tap is counted by code, day and kind of device, never who.
// trvgo.us/<shop> (decisions/0139): a path that isn't a code may be a business's storefront (app/ui/storefront-view.php);
// a shop name can never look like a code, so every code works as before. A business's own domain arrives through the
// edge (Fly.io) with the domain in X-TV-Host and the edge's key in X-TV-Edge (decisions/0139 §3, step 5b).
declare(strict_types=1);

require_once __DIR__ . '/../app/lib/Database.php';
require_once __DIR__ . '/../app/lib/ShortCodes.php';
require_once __DIR__ . '/../app/lib/Storefront.php';
require_once __DIR__ . '/../app/ui/favicon.php';   // the tab's icon, from traversence.com

$site = rtrim((string) (getenv('SITE_BASE') ?: ($_ENV['SITE_BASE'] ?? '') ?: 'https://traversence.com'), '/');
require_once __DIR__ . '/../app/lib/Staging.php';
if (Staging::here()) { $site = Staging::siteBase(); Staging::guard(); }   // the router's staging copy, at staging.trvgo.us/go/ (decisions/0145 Phase 3)
header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex');
header('X-Content-Type-Options: nosniff');

$raw = (string) ($_GET['c'] ?? trim((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH), '/'));
$tvHost = (string) ($_SERVER['HTTP_X_TV_HOST'] ?? '');
if ($tvHost !== '') {   // a business's own domain, passed on by the edge: only its storefront, never codes
    try {
        $pdo = Database::connection();
        require_once __DIR__ . '/../app/ui/storefront-view.php';
        if (tv_storefront_domain($pdo, $tvHost, (string) ($_SERVER['HTTP_X_TV_EDGE'] ?? ''), $raw === 'index.php' ? '' : $raw, $site)) exit;
    } catch (Throwable $e) { error_log('trvgo domain: ' . $e->getMessage()); }
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Not found</title>' . tv_favicon_links($site) . '</head>'
       . '<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7EFDC;color:#3E2B1F;font:16px/1.5 Georgia,serif;padding:16px">'
       . '<p style="max-width:24rem;text-align:center">There\'s nothing here. If this is your domain, finish connecting it in your Traversence business portal.</p></body></html>';
    exit;
}

if ($raw === '' || $raw === 'index.php') { header('Location: ' . $site . '/qr/', true, 302); exit; }

$hit = null; $proof = false;
if (ShortCodes::reserved($raw)) $raw = '-';   // a word trvgo.us keeps, like staging, is never a code or a shop, so it's "not found" below

try {
    $pdo = Database::connection();
    $hit = ShortCodes::resolve($pdo, $raw);
    if ($hit && $hit['kind'] === 'go') {   // a GO Code: what it does is on its qr_issued row
        $go = (int) ((json_decode((string) $hit['row']['payload'], true) ?: [])['go'] ?? 0);
        $st = $pdo->prepare("SELECT id, type, title, content FROM qr_issued WHERE id = ? AND status IN ('free', 'paid', 'granted')");
        $st->execute([$go]);
        $hit['go'] = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$hit['go']) {   // a client order's code before it's paid: a proof (decisions/0101)
            try {
                $st = $pdo->prepare("SELECT q.id, q.type, q.title, q.content, q.fields, o.id AS order_id FROM qr_issued q JOIN orders o ON o.id = q.order_id
                                     WHERE q.id = ? AND q.status = 'pending' AND o.created_by > 0 AND o.status IN ('draft', 'sent', 'pending')");
                $st->execute([$go]);
                $hit['go'] = $st->fetch(PDO::FETCH_ASSOC) ?: null;
            } catch (Throwable) { $hit['go'] = null; }   // before 2026-12-06_client_orders.sql
            $proof = (bool) $hit['go'];
        }
        if (!$hit['go']) $hit = null;
    }
} catch (Throwable $e) {
    error_log('trvgo: ' . $e->getMessage());
    $hit = null;
}

if (!$hit && Storefront::looksLikeShop($raw)) {   // a storefront (decisions/0139)
    try {
        $pdo = $pdo ?? Database::connection();
        require_once __DIR__ . '/../app/ui/storefront-view.php';
        if (tv_storefront_serve($pdo, $raw, $site)) exit;
    } catch (Throwable $e) { error_log('trvgo storefront: ' . $e->getMessage()); }
}

if (!$hit) {
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    $home = htmlspecialchars($site);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Code not found · TRVGO</title>' . tv_favicon_links($site)
       . '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7EFDC;color:#3E2B1F;font:16px/1.5 Georgia,serif;padding:16px}'
       . '.c{max-width:24rem;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.9rem;padding:1.2rem 1.3rem;text-align:center}a{color:#92400E}</style></head>'
       . '<body><div class="c"><h1 style="font-size:1.3rem;margin:0 0 .4rem">This code isn\'t active</h1>'
       . '<p style="margin:0 0 .8rem">It may have been switched off, or mistyped.</p><p style="margin:0"><a href="' . $home . '">Go to Traversence</a></p></div></body></html>';
    exit;
}

$row = $hit['row'];
$ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
if (empty($_GET['b']) && !$proof) ShortCodes::count($pdo, (int) $row['id'], $ua);   // ?b=1: Android's fallback to the button page, counted already

// A proof: the code works for our team and the client while the order is being proofed, never counted. First a page
// that says so, with what it does and a button that does it (?go=1); it goes live, and counts, once the order is paid.
if ($proof && empty($_GET['go']) && empty($_GET['b'])) {
    require_once __DIR__ . '/../app/lib/QrIssue.php';
    $g = $hit['go']; $h = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES);
    $f = json_decode((string) $g['fields'], true) ?: [];
    $does = ''; try { $does = QrIssue::holds((string) $g['type'], $f); } catch (Throwable) {}
    $card = QrIssue::detailsHtml((string) $g['type'], $f);
    $kind = QrIssue::KIND[$g['type']] ?? 'GO Code';
    $label = ['link' => 'Open the link', 'vcard' => 'Save the contact', 'event' => 'Add to calendar', 'phone' => 'Call', 'sms' => 'Text', 'email' => 'Email', 'text' => 'Show the text', 'wifi' => 'Show the Wi-Fi'][$g['type']] ?? 'Try it';
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Proof · ' . $h($g['title'] ?: 'GO Code') . ' · TRVGO</title>' . tv_favicon_links($site)
       . '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7EFDC;color:#3E2B1F;font:16px/1.5 Georgia,serif;padding:16px;box-sizing:border-box}'
       . '.c{max-width:26rem;width:100%;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.9rem;padding:1.2rem 1.3rem;text-align:center}'
       . '.p{display:inline-block;background:#FDE68A;color:#78350F;font:700 .75rem system-ui,sans-serif;letter-spacing:.08em;border-radius:999px;padding:.2rem .7rem;margin-bottom:.5rem}'
       . '.b{display:inline-block;background:#92400E;color:#fff;text-decoration:none;font:700 1rem system-ui,sans-serif;border-radius:.6rem;padding:.7rem 1.2rem;margin:.4rem 0}'
       . '.d{margin:.3rem 0 .6rem;word-wrap:break-word}.k{font:600 .8rem system-ui,sans-serif;color:#8A7355;margin:0 0 .5rem}'
       . '.card{text-align:left;border:1px solid #EADFC4;border-radius:.7rem;background:#fff;padding:.8rem .9rem;margin:.6rem 0}.gc-v b{display:block;font-size:1.15rem}.gc-v span{color:#6B5640;font-size:.95rem}'
       . 'dl{margin:.5rem 0 0;display:grid;grid-template-columns:auto 1fr;gap:.3rem .7rem;font-size:.95rem}dt{font:600 .78rem system-ui,sans-serif;color:#8A7355;padding-top:.15rem}dd{margin:0;word-break:break-word}small{color:#8A7355;font-family:system-ui,sans-serif;display:block;line-height:1.4}</style></head><body><div class="c">'
       . '<span class="p">PROOF</span>'
       . '<h1 style="font-size:1.25rem;margin:0 0 .2rem">' . $h($g['title'] ?: 'GO Code') . '</h1><p class="k">' . $h($kind) . '</p>'
       . ($card !== '' ? '<div class="card">' . $card . '</div>' : ($does !== '' ? '<p class="d">' . $h($does) . '</p>' : ''))
       . '<p style="margin:.4rem 0"><a class="b" href="' . $h(ShortCodes::url((string) $row['code'])) . '?go=1">' . $h($label) . '</a></p>'
       . '<small>This GO Code is being proofed for order #' . (int) $g['order_id'] . '. It works for checking, and scans aren\'t counted. Once the order is paid it goes live: scans open it directly and are counted.</small>'
       . '</div></body></html>';
    exit;
}

if ($hit['kind'] === 'go') {
    $g = $hit['go']; $c = (string) $g['content']; $type = (string) $g['type'];
    $h = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES);
    if ($type === 'link') {
        $to = preg_match('#^https?://#i', $c) ? $c : $site . '/';
        header('Location: ' . $to, true, 302); exit;
    }
    if ($type === 'vcard') {
        header('Content-Type: text/vcard; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . (preg_replace('/[^a-z0-9-]+/i', '-', strtolower((string) $g['title'])) ?: 'contact') . '.vcf"');
        echo $c; exit;
    }
    if ($type === 'event') {
        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: attachment; filename="event.ics"');
        $body = str_starts_with($c, 'BEGIN:VCALENDAR') ? $c
            : "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Traversence//GO Code//EN\r\n" . str_replace('BEGIN:VEVENT', "BEGIN:VEVENT\r\nUID:go-" . (int) $g['id'] . "@trvgo.us\r\nDTSTAMP:" . gmdate('Ymd\THis\Z'), $c) . "\r\nEND:VCALENDAR\r\n";
        echo $body; exit;
    }
    // phone, text message, email and text: a small page (a link that opens the phone's own app needs a tap)
    $btn = ''; $what = ''; $text = '';
    if ($type === 'phone') { $btn = $c; $what = 'Call ' . substr($c, 4); }
    elseif ($type === 'email') { $btn = $c; $what = 'Email ' . preg_replace('/\?.*$/', '', substr($c, 7)); }
    elseif ($type === 'sms' && preg_match('/^SMSTO:([^:]*):?(.*)$/s', $c, $m)) {
        $btn = 'sms:' . $m[1] . ($m[2] !== '' ? '?&body=' . rawurlencode($m[2]) : ''); $what = 'Text ' . $m[1]; $text = $m[2];
    } else { $text = $c; }
    // Android: the scan is counted (above), then straight to the phone's dialer, Messages or email app. An intent: link
    // from the redirect itself is allowed to open the app (a script on a page isn't, without a tap); if no app takes it,
    // the browser comes back to the button page (?b=1).
    if ($btn !== '' && empty($_GET['b']) && preg_match('/Android/i', $ua) && preg_match('/^(tel|sms|mailto):(.*)$/s', $btn, $u)) {
        $data = $u[1] === 'sms' ? str_replace('?&body=', '?body=', $u[2]) : $u[2];
        header('Location: intent:' . $data . '#Intent;scheme=' . $u[1] . ';S.browser_fallback_url=' . rawurlencode(ShortCodes::url((string) $row['code']) . '?b=1') . ';end', true, 302);
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $h($g['title'] ?: 'GO Code') . ' · TRVGO</title>' . tv_favicon_links($site)
       . '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7EFDC;color:#3E2B1F;font:16px/1.5 Georgia,serif;padding:16px;box-sizing:border-box}'
       . '.c{max-width:26rem;width:100%;background:#FFFBF2;border:1px solid #EADFC4;border-radius:.9rem;padding:1.2rem 1.3rem;text-align:center}'
       . '.b{display:inline-block;background:#92400E;color:#fff;text-decoration:none;font:700 1rem system-ui,sans-serif;border-radius:.6rem;padding:.7rem 1.2rem;margin:.4rem 0}'
       . '.t{white-space:pre-wrap;text-align:left;font-size:1rem;margin:.6rem 0;word-wrap:break-word}small{color:#8A7355;font-family:system-ui,sans-serif}a.s{color:#92400E}</style></head><body><div class="c">'
       . ($g['title'] !== '' ? '<h1 style="font-size:1.25rem;margin:0 0 .5rem">' . $h($g['title']) . '</h1>' : '')
       . ($text !== '' ? '<div class="t">' . $h($text) . '</div>' : '')
       . ($btn !== '' ? '<p style="margin:.5rem 0"><a class="b" href="' . $h($btn) . '">' . $h($what) . '</a></p>' : '')
       . '<p style="margin:.6rem 0 0"><small>A GO Code by <a class="s" href="' . $h($site) . '/qr/">Traversence</a></small></p></div>'
       // no gate: the call, text or email starts by itself where the phone allows it (the scan is already counted);
       // where a browser blocks an app opening without a tap, the button above is the way through
       . ($btn !== '' ? '<script>location.replace(' . json_encode($btn, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES) . ');</script>' : '')
       . '</body></html>';
    exit;
}

if ($hit['kind'] === 'vcard') {
    require_once __DIR__ . '/../app/lib/VCard.php';
    $card = (array) $hit['card'];
    if (!empty($card['listing'])) $card = VCard::listingCard($pdo, (int) $card['listing']) ?? [];   // a listing's card: its details as they are now
    if (!$card) { header('Location: ' . $site . '/', true, 302); exit; }
    VCard::send($card, $site);
    exit;
}

$to = (string) $hit['to'];
if ($to === '') $to = '/';
if ($to[0] === '/') $to = $site . $to;   // a page on the site
if (!preg_match('#^https?://#i', $to)) $to = $site . '/';
header('Location: ' . $to, true, 302);
