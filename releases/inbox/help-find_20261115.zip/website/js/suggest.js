/* js/suggest.js — "Tell us" (decisions/0053): one short form for anything a visitor knows that we don't.
 * Something missing (a business, a lake, a trail, a landmark, an event), something wrong on a listing or place,
 * closed or moved, two listings that are one business, information for a place's guide story, or feedback on
 * search results. Works signed out. A person reviews every suggestion; nothing changes on the site by itself.
 *
 *   TvSuggest.open({kind, topic, entity_id, entity_name, target, target_name, place_key, place_name, section, q})
 *   <button data-tv-suggest='{"kind":"missing","topic":"outdoors","section":"Lakes"}'>Missing something?</button>
 * With no kind, the form asks what the visitor wants to tell us (only the choices that fit what they're looking at).
 */
(function () {
  'use strict';
  if (window.TvSuggest) return;
  var meta = null, root = null, opts = {};
  var TOPICS = [['business', 'A business'], ['outdoors', 'Outdoors: lake, trail, park, campground'], ['culture', 'History, arts or culture'],
                ['food', 'Food or drink'], ['event', 'An event'], ['other', 'Something else']];

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function load() {
    if (meta) return Promise.resolve(meta);
    return fetch('/api/suggestion.php', { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { meta = d; return d; });
  }
  function css() {
    if (document.getElementById('sg-css')) return;
    var s = document.createElement('style'); s.id = 'sg-css';
    s.textContent = '.sg-bg{position:fixed;inset:0;background:rgba(40,28,18,.45);z-index:3000;display:flex;align-items:flex-start;justify-content:center;padding:4vh 12px;overflow:auto}'
      + '.sg{background:#FFFBF2;color:#3E2B1F;border:1px solid #CBB98D;border-radius:1rem;max-width:520px;width:100%;padding:1.1rem 1.2rem;box-shadow:0 18px 50px rgba(0,0,0,.25);font-size:.95rem}'
      + '.sg h2{font-family:ui-serif,Georgia,serif;font-size:1.25rem;margin:0 0 .2rem}.sg p{margin:.2rem 0 .7rem;color:#6B5540;font-size:.86rem}'
      + '.sg-x{float:right;background:none;border:0;font-size:1.4rem;line-height:1;color:#6B5540;cursor:pointer}'
      + '.sg-ch{display:grid;gap:.4rem}.sg-ch button{text-align:left;background:#fff;border:1px solid #D9C9A3;border-radius:.7rem;padding:.6rem .8rem;cursor:pointer;color:#3E2B1F;font:inherit}'
      + '.sg-ch button:hover,.sg-ch button:focus{border-color:#B8863B;outline:none;background:#FFF6E3}.sg-ch small{display:block;color:#7A6348;font-size:.8rem}'
      + '.sg label{display:block;font-weight:600;font-size:.84rem;margin:.55rem 0 .2rem}.sg label small{font-weight:400;color:#7A6348}'
      + '.sg input,.sg select,.sg textarea{width:100%;box-sizing:border-box;border:1px solid #CBB98D;border-radius:.55rem;padding:.5rem .6rem;font:inherit;background:#fff;color:#3E2B1F}'
      + '.sg textarea{min-height:5.5rem;resize:vertical}.sg .sg-two{display:grid;grid-template-columns:1fr 1fr;gap:0 .6rem}@media(max-width:480px){.sg .sg-two{grid-template-columns:1fr}}'
      + '.sg-hp{position:absolute!important;left:-9999px!important;height:0;width:0;opacity:0}'
      + '.sg-row{display:flex;gap:.5rem;justify-content:flex-end;align-items:center;margin-top:.9rem;flex-wrap:wrap}'
      + '.sg-b{background:#3E2B1F;color:#FFFBF2;border:0;border-radius:999px;padding:.5rem 1.1rem;font:inherit;font-weight:600;cursor:pointer}.sg-b[disabled]{opacity:.6}'
      + '.sg-l{background:none;border:0;color:#6B5540;text-decoration:underline;cursor:pointer;font:inherit}'
      + '.sg-err{color:#991B1B;font-size:.85rem;margin-right:auto}.sg-tag{display:inline-block;background:#F3E6C8;border-radius:999px;padding:.1rem .55rem;font-size:.78rem;margin:.1rem 0 .3rem}'
      + '.sg-pick{display:grid;gap:.25rem;margin-top:.3rem}.sg-pick button{text-align:left;background:#fff;border:1px solid #E3D6B6;border-radius:.5rem;padding:.35rem .55rem;cursor:pointer;font:inherit;color:#3E2B1F}'
      + '.sg-pick button.on{border-color:#3E2B1F;background:#FFF6E3}'
      + '.sg-pt{margin-top:.55rem;border:1px dashed #CBB98D;border-radius:.7rem;padding:.5rem .6rem;background:#FFF8EA}.sg-pt p{margin:.1rem 0 .4rem;font-size:.8rem}'
      + '.sg-pt .sg-pb{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center}.sg-pt button{background:#fff;border:1px solid #CBB98D;border-radius:999px;padding:.3rem .75rem;font:inherit;font-size:.84rem;cursor:pointer;color:#3E2B1F}'
      + '.sg-pt .sg-ps{font-size:.8rem;color:#166534;font-weight:600}.sg-map{height:220px;border-radius:.6rem;margin-top:.45rem;border:1px solid #CBB98D}';
    document.head.appendChild(s);
  }
  function close() { if (root) { root.remove(); root = null; document.removeEventListener('keydown', onKey); } }
  function onKey(e) { if (e.key === 'Escape') close(); }
  function shell(inner) {
    close(); css();
    root = document.createElement('div'); root.className = 'sg-bg';
    root.innerHTML = '<div class="sg" role="dialog" aria-modal="true" aria-labelledby="sg-h"><button type="button" class="sg-x" aria-label="Close">&times;</button>' + inner + '</div>';
    root.addEventListener('click', function (e) { if (e.target === root || e.target.closest('.sg-x')) close(); });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(root);
    var f = root.querySelector('button:not(.sg-x), input:not(.sg-hp), textarea, select'); if (f) f.focus();
    return root.querySelector('.sg');
  }
  function about() {
    return opts.entity_name || opts.target_name || '';
  }

  // What would you like to tell us? Only the choices that fit what the visitor is looking at.
  function choose() {
    var a = about(), c = [];
    c.push(['missing', 'Something’s missing', (opts.section ? 'Not in “' + opts.section + '” yet: ' : '') + 'a business, a lake or trail, a landmark, an event']);
    if (a) c.push(['fix', 'Something’s wrong on “' + a + '”', 'Name, website, phone, hours, what it offers']);
    if (a) c.push(['closed', '“' + a + '” has closed or moved', '']);
    if (opts.entity_id) c.push(['same', 'It’s listed twice', 'Two listings that are one business']);
    c.push(['story', 'I know something for a story' + (opts.place_name ? ' about ' + opts.place_name : ''), 'History, what to see, local knowledge: for the place’s guide']);
    if (opts.q) c.push(['feedback', 'These results aren’t right', 'For “' + opts.q + '”']);
    var box = shell('<h2 id="sg-h">Tell us</h2><p>What would you like to tell us? A person reads every one.</p><div class="sg-ch">'
      + c.map(function (x) { return '<button type="button" data-k="' + x[0] + '"><b>' + esc(x[1]) + '</b>' + (x[2] ? '<small>' + esc(x[2]) + '</small>' : '') + '</button>'; }).join('') + '</div>');
    box.addEventListener('click', function (e) { var b = e.target.closest('[data-k]'); if (b) form(b.getAttribute('data-k')); });
  }

  function input(name, label, val, hint, type) {
    return '<div><label for="sg-' + name + '">' + esc(label) + (hint ? ' <small>' + esc(hint) + '</small>' : '') + '</label><input id="sg-' + name + '" name="' + name + '" type="' + (type || 'text') + '" value="' + esc(val || '') + '" maxlength="160"></div>';
  }
  function area(name, label, hint, ph, max) {
    return '<label for="sg-' + name + '">' + esc(label) + (hint ? ' <small>' + esc(hint) + '</small>' : '') + '</label><textarea id="sg-' + name + '" name="' + name + '" maxlength="' + (max || 1000) + '" placeholder="' + esc(ph || '') + '"></textarea>';
  }

  function form(kind) {
    var a = about(), h = '', title = '', lead = '';
    var topic = opts.topic || (kind === 'story' ? 'story' : (opts.entity_id ? 'business' : ''));
    if (kind === 'missing') {
      title = 'What’s missing?';
      lead = opts.section ? 'Missing from <span class="sg-tag">' + esc(opts.section) + '</span>' + (opts.place_name ? ' near ' + esc(opts.place_name) : '') : 'Anything we should list: a business, a lake, a trail, a landmark, an event.';
      h += '<label for="sg-topic">What is it?</label><select id="sg-topic" name="topic">' + TOPICS.map(function (t) { return '<option value="' + t[0] + '"' + (t[0] === topic ? ' selected' : '') + '>' + esc(t[1]) + '</option>'; }).join('') + '</select>'
        + input('name', 'Name', opts.q || '', '', '') + '<div class="sg-two">' + input('address', 'Where is it?', '', 'town or address', '') + input('what', 'What it is', '', 'e.g. state park, bakery', '') + '</div>'
        + '<div class="sg-two">' + input('website', 'Website', '', 'if you know it', 'url') + input('phone', 'Phone', '', '', 'tel') + '</div>'
        + pointBlock()
        + area('note', 'Anything else?', 'optional', 'e.g. it belongs with the lakes; open May to October');
    } else if (kind === 'fix' && opts.help_find) {   // "Help us find this business" (decisions/0164 §3.5): what we're missing, and how they know (R4)
      title = 'Help us find it'; lead = 'We know <b>' + esc(a) + '</b> by name only. What do you know?';
      h += '<div class="sg-two">' + input('phone', 'Phone', '', '', 'tel') + input('address', 'Street address', '', 'e.g. 249 W Ponderosa', '') + '</div>'
        + input('website', 'Website', '', 'if it has one', 'url')
        + input('source', 'How do you know?', '', 'e.g. I shop there; its sign; its Facebook page', '')
        + pointBlock('Know where it is? Show us on the map.')
        + area('note', 'Anything else?', 'optional', 'e.g. it closed; it moved; its owner\u2019s name for the business');
    } else if (kind === 'fix') {
      title = 'Suggest a fix'; lead = 'For <b>' + esc(a) + '</b>. Fill in only what’s wrong.';
      h += '<div class="sg-two">' + input('name', 'Correct name', '', '', '') + input('other_names', 'Other names it goes by', '', '', '') + '</div>'
        + '<div class="sg-two">' + input('website', 'Website', '', '', 'url') + input('phone', 'Phone', '', '', 'tel') + '</div>'
        + input('address', 'Address', '', '', '') + input('hours', 'Hours', '', 'e.g. Mon–Fri 8–5', '') + input('offers', 'What it offers', '', '', '')
        + pointBlock('The pin on our map is wrong? Show us where it is.')
        + area('note', 'Anything else?', 'optional', '');
    } else if (kind === 'closed') {
      title = 'Closed or moved'; lead = 'For <b>' + esc(a) + '</b>.';
      h += area('note', 'What happened?', '', 'e.g. closed for good in June; moved to 400 Main St')
        + pointBlock('Moved? Show us the new spot.');
    } else if (kind === 'same') {
      title = 'Listed twice'; lead = '<b>' + esc(a) + '</b> is the same business as:';
      h += '<label for="sg-find">Find the other listing</label><input id="sg-find" type="search" placeholder="Type its name" autocomplete="off"><div class="sg-pick" id="sg-pick"></div>'
        + area('note', 'Anything else?', 'optional', 'e.g. same phone, new owner changed the name');
    } else if (kind === 'story') {
      title = 'For a guide story'; lead = (opts.place_name ? 'About <b>' + esc(opts.place_name) + '</b>. ' : '') + 'Our writers check it before anything is published. Please keep sacred or restricted places private.';
      h += area('note', 'What should people know?', '', 'History, a local story, what to see, the best time to go…', 4000)
        + input('source', 'Where this comes from', '', 'a link, a book, or “I live here”', '');
    } else {
      title = 'Feedback on these results'; lead = opts.q ? 'For <span class="sg-tag">' + esc(opts.q) + '</span>' : '';
      h += area('note', 'What were you looking for?', '', 'e.g. the lake campground was missing; this isn’t a restaurant');
    }
    var signed = meta && meta.signed_in;
    var box = shell('<h2 id="sg-h">' + esc(title) + '</h2><p>' + lead + '</p><form novalidate>' + h
      + '<input class="sg-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true">'
      + '<p style="margin-top:.7rem">' + (signed ? 'Sent from your account. ' : 'No account needed. ') + 'We never publish who sent a suggestion.</p>'
      + '<div class="sg-row"><span class="sg-err" role="alert"></span><button type="button" class="sg-l" data-back>Back</button><button class="sg-b" type="submit">Send</button></div></form>');
    var same = 0;
    if (kind === 'same') picker(box, function (id) { same = id; });
    wirePoint(box);
    box.querySelector('[data-back]').addEventListener('click', choose);
    box.querySelector('form').addEventListener('submit', function (e) {
      e.preventDefault();
      var fm = e.target, err = box.querySelector('.sg-err'), btn = box.querySelector('.sg-b'), fields = {};
      ['name', 'what', 'website', 'phone', 'address', 'hours', 'offers', 'other_names', 'source', 'point'].forEach(function (k) { if (fm[k] && fm[k].value.trim()) fields[k] = fm[k].value.trim(); });
      var body = { kind: kind, topic: fm.topic ? fm.topic.value : topic, entity_id: opts.entity_id || 0, same_as_id: same, target: opts.target || '', target_name: a,
                   place_key: opts.place_key || '', section: opts.section || '', fields: fields, note: fm.note ? fm.note.value : '', hp: fm.hp.value,
                   context: [location.pathname + location.search, opts.q ? 'search: ' + opts.q : ''].filter(Boolean).join(' · ').slice(0, 400) };
      btn.disabled = true; err.textContent = '';
      fetch('/api/suggestion.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': (meta && meta.csrf) || '' }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) })
        .then(function (r) { return r.json().then(function (d) { return [r.ok, d]; }); })
        .then(function (x) {
          if (!x[0] || !x[1].ok) { btn.disabled = false; err.textContent = (x[1] && (x[1].error || x[1].message)) || 'That didn’t send. Please try again.'; return; }
          var done = shell('<h2 id="sg-h">Thank you</h2><p>' + (kind === 'story' ? 'A writer will read it for the place’s guide.' : 'A person will look at it soon. If it checks out, it shows on the site.') + '</p>'
            + '<div class="sg-row"><button type="button" class="sg-l" data-more>Tell us something else</button><button type="button" class="sg-b" data-ok>Done</button></div>');
          done.querySelector('[data-ok]').addEventListener('click', close);
          done.querySelector('[data-more]').addEventListener('click', choose);
        })
        .catch(function () { btn.disabled = false; err.textContent = 'That didn’t send. Check your connection and try again.'; });
    });
  }

  // Where exactly: rural places often have no street address (a PO box, a highway, a mile marker), so a pin is the
  // best way to say where. "I'm here now" uses this device's location once; it becomes the place's point, never yours.
  function pointBlock(hint) {
    return '<div class="sg-pt"><label style="margin:0">Where exactly is it? <small>optional</small></label>'
      + '<p>' + esc(hint || 'Many places out here have no street address. A pin on the map helps people find it.') + '</p>'
      + '<div class="sg-pb"><button type="button" data-pt="here"><svg class="tv-ei" width="1em" height="1em" style="vertical-align:-.125em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg> I’m here now</button><button type="button" data-pt="map"><svg class="tv-ei" width="1em" height="1em" style="vertical-align:-.125em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg> Pick on a map</button>'
      + '<span class="sg-ps" aria-live="polite"></span></div><div class="sg-map" hidden></div><input type="hidden" name="point"></div>';
  }
  function leaflet() {
    if (window.L) return Promise.resolve();
    return new Promise(function (res, rej) {
      var cdn = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/';
      if (!document.querySelector('link[href*="leaflet.min.css"]')) { var c = document.createElement('link'); c.rel = 'stylesheet'; c.href = cdn + 'leaflet.min.css'; document.head.appendChild(c); }
      var s = document.createElement('script'); s.src = cdn + 'leaflet.min.js'; s.onload = res; s.onerror = function () { rej(new Error('The map could not load.')); }; document.head.appendChild(s);
    });
  }
  function wirePoint(box) {
    var wrap = box.querySelector('.sg-pt'); if (!wrap) return;
    var inp = wrap.querySelector('[name="point"]'), st = wrap.querySelector('.sg-ps'), mapEl = wrap.querySelector('.sg-map'), map = null, mk = null;
    function set(lat, lon, how) {
      lat = +(+lat).toFixed(6); lon = +(+lon).toFixed(6);
      inp.value = lat + ',' + lon; st.textContent = '✓ ' + how + ' (' + lat.toFixed(4) + ', ' + lon.toFixed(4) + ')';
      if (map) { if (mk) mk.setLatLng([lat, lon]); else { mk = L.marker([lat, lon], { draggable: true }).addTo(map); mk.on('dragend', function () { var p = mk.getLatLng(); set(p.lat, p.lng, 'Pin placed'); }); } }
    }
    function showMap(lat, lon, z) {
      mapEl.hidden = false;
      return leaflet().then(function () {
        if (!map) {
          map = L.map(mapEl).setView([lat, lon], z);
          L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(map);
          map.on('click', function (e) { set(e.latlng.lat, e.latlng.lng, 'Pin placed'); });
        }
        setTimeout(function () { map.invalidateSize(); }, 50);
      }).catch(function (e) { st.textContent = e.message; });
    }
    wrap.addEventListener('click', function (e) {
      var b = e.target.closest('[data-pt]'); if (!b) return;
      if (b.getAttribute('data-pt') === 'here') {
        if (!navigator.geolocation) { st.textContent = 'This browser can’t share a location. Pick on a map instead.'; return; }
        st.textContent = 'Finding you…';
        navigator.geolocation.getCurrentPosition(function (pos) {
          var la = pos.coords.latitude, lo = pos.coords.longitude;
          showMap(la, lo, 16).then(function () { set(la, lo, 'Your spot now (drag the pin to adjust)'); map.setView([la, lo], 16); });
        }, function () { st.textContent = 'Location access was blocked. Pick on a map instead.'; }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 });
      } else {
        var c = (typeof currentLocation !== 'undefined' && currentLocation && currentLocation.lat != null) ? [currentLocation.lat, currentLocation.lon, 11] : [opts.lat || 34.2, opts.lon || -110.0, opts.lat ? 15 : 7];
        showMap(c[0], c[1], c[2]).then(function () { if (!inp.value) st.textContent = 'Tap the map where it is; drag the pin to adjust.'; });
      }
    });
  }

  // "Listed twice": find the other listing by name
  function picker(box, set) {
    var inp = box.querySelector('#sg-find'), out = box.querySelector('#sg-pick'), t = null;
    inp.addEventListener('input', function () {
      clearTimeout(t); var q = inp.value.trim(); if (q.length < 2) { out.innerHTML = ''; return; }
      t = setTimeout(function () {
        fetch('/api/search_listings.php?per_page=6&q=' + encodeURIComponent(q), { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) {
          out.innerHTML = (d.listings || []).filter(function (l) { return +l.id !== +opts.entity_id; }).map(function (l) {
            return '<button type="button" data-id="' + (+l.id) + '"><b>' + esc(l.name) + '</b> <small>' + esc([l.city, l.state].filter(Boolean).join(', ')) + '</small></button>';
          }).join('') || '<small>No listing by that name.</small>';
        });
      }, 250);
    });
    out.addEventListener('click', function (e) {
      var b = e.target.closest('[data-id]'); if (!b) return;
      out.querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); });
      set(+b.getAttribute('data-id'));
    });
  }

  window.TvSuggest = {
    open: function (o) {
      opts = o || {};
      load().then(function () { if (opts.kind) form(opts.kind); else choose(); }).catch(function () { opts.kind ? form(opts.kind) : choose(); });
    },
    close: close
  };
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-tv-suggest]'); if (!b) return;
    e.preventDefault();
    var o = {}; try { o = JSON.parse(b.getAttribute('data-tv-suggest') || '{}'); } catch (x) {}
    window.TvSuggest.open(o);
  });
})();
