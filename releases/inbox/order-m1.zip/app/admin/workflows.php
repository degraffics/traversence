<?php
// app/admin/workflows.php — the built-in workflows (decisions/0109 Part C): each one's default stages and moves (its
// first version, editable in System Configuration → Workflows) and its adapter, which reads where an item is from the
// site's own records and does the protected moves through the library that owns them.
//
// A stage with 'op' or 'locked', and a move with 'op', is part of how the site works: the builder can rename it, time
// it, give it an owner and add stages around it, not remove it or its checks. Who may make each move is its 'who'
// (the lowest level, and departments), changeable in System Configuration → Permissions.
declare(strict_types=1);

$S = fn (string $key, string $label, string $kind = '', array $x = []) => ['key' => $key, 'label' => $label, 'kind' => $kind] + $x;

return [

    // ---- Back-Office: an order our team prepares for a client (decisions/0101) ----------------------------------------
    'client_order' => [
        'name' => 'Client order', 'module' => 'backoffice', 'entity' => 'order',
        'def' => [
            'stages' => [
                $S('draft', 'Draft', 'start', ['owner_dept' => 'sal', 'sla_hours' => 72, 'locked' => true]),
                $S('sent', 'With the client', '', ['owner_dept' => 'sal', 'sla_hours' => 120, 'locked' => true]),
                $S('approved', 'Approved, waiting for payment', '', ['owner_dept' => 'fin', 'sla_hours' => 72, 'locked' => true]),
                $S('paid', 'Paid', '', ['owner_dept' => 'svc', 'sla_hours' => 24, 'locked' => true]),
                $S('production', 'In production', '', ['owner_dept' => 'svc', 'sla_hours' => 120, 'op' => 'stage']),
                $S('ordered', 'Work order issued', '', ['owner_dept' => 'svc', 'sla_hours' => 168, 'op' => 'stage']),
                $S('shipped', 'Shipped', '', ['owner_dept' => 'svc', 'sla_hours' => 168, 'op' => 'stage']),
                $S('ready', 'Ready for pickup', '', ['owner_dept' => 'svc', 'sla_hours' => 168, 'op' => 'stage']),
                $S('complete', 'Complete', 'end', ['outcome' => 'done', 'op' => 'stage']),
                $S('cancelled', 'Cancelled', 'end', ['outcome' => 'cancelled', 'locked' => true]),
                $S('refunded', 'Refunded', 'end', ['outcome' => 'cancelled', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'send', 'label' => 'Send to the client', 'from' => ['draft'], 'to' => 'sent', 'op' => 'send', 'who' => ['min' => 'staff', 'depts' => ['sal', 'svc']]],
                ['key' => 'resend', 'label' => 'Send again', 'from' => ['sent'], 'to' => 'sent', 'op' => 'send', 'who' => ['min' => 'staff', 'depts' => ['sal', 'svc']]],
                ['key' => 'to_production', 'label' => 'Start production', 'from' => ['approved', 'paid'], 'to' => 'production', 'op' => 'stage', 'checks' => ['proofs_approved'], 'who' => ['min' => 'staff', 'depts' => ['svc']]],
                ['key' => 'to_ordered', 'label' => 'Work order issued', 'from' => ['paid', 'production'], 'to' => 'ordered', 'op' => 'stage', 'who' => ['min' => 'staff', 'depts' => ['svc']]],
                ['key' => 'to_shipped', 'label' => 'Shipped', 'from' => ['production', 'ordered'], 'to' => 'shipped', 'op' => 'stage', 'asks' => ['tracking'], 'checks' => ['paid_in_full'], 'who' => ['min' => 'staff', 'depts' => ['svc']]],
                ['key' => 'to_ready', 'label' => 'Ready for pickup', 'from' => ['production', 'ordered'], 'to' => 'ready', 'op' => 'stage', 'checks' => ['paid_in_full'], 'who' => ['min' => 'staff', 'depts' => ['svc']]],
                ['key' => 'to_complete', 'label' => 'Complete', 'from' => ['shipped', 'ready'], 'to' => 'complete', 'op' => 'stage', 'who' => ['min' => 'staff', 'depts' => ['svc']]],
                ['key' => 'approved', 'label' => 'Client approves', 'from' => ['sent'], 'to' => 'approved', 'op' => 'none', 'auto' => 'on the client\'s order page'],
                ['key' => 'paid', 'label' => 'Paid', 'from' => ['approved'], 'to' => 'paid', 'op' => 'none', 'auto' => 'when the payment comes in'],
                ['key' => 'refunded', 'label' => 'Refunded', 'from' => ['paid', 'production', 'ordered', 'shipped', 'ready', 'complete'], 'to' => 'refunded', 'op' => 'none', 'auto' => 'when a full refund is made on the order page'],
                ['key' => 'cancel', 'label' => 'Cancel the order', 'from' => ['draft', 'sent', 'approved'], 'to' => 'cancelled', 'op' => 'cancel', 'asks' => ['note'], 'who' => ['min' => 'manager', 'depts' => ['sal', 'svc', 'fin']]],
            ],
            'any' => [
                ['key' => 'open', 'label' => 'Open the order', 'link' => '/admin/backoffice/orders/{id}', 'who' => ['min' => 'staff', 'depts' => []]],
                ['key' => 'money', 'label' => 'Refund, credit or chargeback', 'link' => '/admin/order.php?id={id}', 'who' => ['min' => 'manager', 'depts' => ['fin', 'svc']]],
            ],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                require_once __DIR__ . '/../lib/ClientOrders.php';
                $o = Orders::get($pdo, $id);
                if (!$o || !ClientOrders::isClient($o)) return null;
                $stage = match (true) {
                    $o['status'] === 'void' => 'cancelled',
                    in_array($o['status'], ['refunded'], true) => 'refunded',
                    in_array($o['status'], ['draft', 'sent'], true) => $o['status'],
                    ($o['stage'] ?? '') !== '' && isset(ClientOrders::STAGES[$o['stage']]) => $o['stage'],
                    in_array($o['status'], ['paid', 'part_refunded'], true) => 'paid',
                    default => 'approved',
                };
                return ['stage' => $stage, 'title' => 'Order #' . Orders::no($o) . ' · ' . ($o['client_company'] ?: $o['bill_name']), 'client_email' => (string) $o['bill_email'],
                        'since' => $o['updated_at'] ?? $o['created_at'], 'owner_id' => $o['created_by'] ? (int) $o['created_by'] : null, 'row' => $o];
            },
            'ops' => [
                'send' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/ClientOrders.php'; ClientOrders::send($pdo, $id, ClientOrders::DAYS, $uid); },
                'stage' => function (PDO $pdo, int $id, array $in, int $uid, string $to) { require_once __DIR__ . '/../lib/ClientOrders.php';
                    // Complete: paid in full, or an admin's override with a reason on the order page (decisions/0177 §4; Jason: "paid in full or overrides")
                    if ($to === 'complete' && ($o = Orders::get($pdo, $id)) && ($hold = ClientOrders::completeHold($pdo, $o)) !== '') throw new RuntimeException(ucfirst($hold) . ' (an admin can complete it anyway on the order page, with a reason).');
                    ClientOrders::setStage($pdo, $id, $to, (string) ($in['tracking'] ?? ''), $uid); },
                'cancel' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/ClientOrders.php'; ClientOrders::cancel($pdo, $id, (string) ($in['note'] ?? ''), $uid); },
            ],
            // why a move can't be made now ('' when it can): Workflow::moves() greys it with this, so the drawer's Complete is
            // greyed with what's still owed, not only refused once pressed (decisions/0177 §4; M1)
            'guard' => function (PDO $pdo, int $id, string $to, array $item): string {
                if ($to !== 'complete') return '';
                require_once __DIR__ . '/../lib/ClientOrders.php';
                $o = Orders::get($pdo, $id); $hold = $o ? ClientOrders::completeHold($pdo, $o) : '';
                return $hold !== '' ? ucfirst($hold) . ' (an admin can complete it anyway on the order page, with a reason)' : '';
            },
        ],
    ],

    // ---- Sales & Growth: a lead (a listing worth a call; decisions/0081, 0108) -----------------------------------------
    'lead' => [
        'name' => 'Lead', 'module' => 'growth', 'entity' => 'listing',
        'def' => [
            'stages' => [
                $S('new', 'Not contacted', 'start', ['owner_dept' => 'sal', 'sla_hours' => 168, 'op' => 'stage']),
                $S('contacted', 'Contacted', '', ['owner_dept' => 'sal', 'sla_hours' => 72, 'op' => 'stage']),
                $S('met', 'Met in person', '', ['owner_dept' => 'sal', 'sla_hours' => 72, 'op' => 'stage']),
                $S('interested', 'Interested', '', ['owner_dept' => 'sal', 'sla_hours' => 48, 'op' => 'stage']),
                $S('meeting', 'Meeting set', '', ['owner_dept' => 'sal', 'op' => 'stage']),
                $S('invited', 'Claim invite sent', '', ['owner_dept' => 'sal', 'sla_hours' => 120, 'op' => 'stage']),
                $S('quote', 'Quote sent', '', ['owner_dept' => 'sal', 'sla_hours' => 120, 'op' => 'stage']),
                $S('won', 'Won', 'end', ['outcome' => 'done', 'op' => 'stage']),
                $S('not_now', 'Nurture: not now', '', ['owner_dept' => 'sal', 'sla_hours' => 2160, 'op' => 'stage']),
                $S('no', 'Not interested', 'end', ['outcome' => 'lost', 'op' => 'stage']),
                $S('lost', 'Lost', 'end', ['outcome' => 'lost', 'op' => 'stage']),
                $S('closed', 'Closed or wrong number', 'end', ['outcome' => 'cancelled', 'op' => 'stage']),
            ],
            'moves' => array_map(fn ($k, $l) => ['key' => 'to_' . $k, 'label' => $l, 'from' => ['*'], 'to' => $k, 'op' => 'stage', 'who' => ['min' => 'staff', 'depts' => ['sal']]],
                ['new', 'contacted', 'met', 'interested', 'meeting', 'invited', 'quote', 'won', 'not_now', 'no', 'lost', 'closed'],
                ['Not contacted', 'Contacted', 'Met in person', 'Interested', 'Meeting set', 'Claim invite sent', 'Quote sent', 'Won', 'Not now', 'Not interested', 'Lost', 'Closed or wrong number']),
            'any' => [],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT e.name, p.stage, p.owner_id, p.last_contact_at, p.created_at FROM entities e LEFT JOIN ' . Database::t('prospects') . ' p ON p.entity_id = e.id WHERE e.id = ?'); $st->execute([$id]);
                $r = $st->fetch(PDO::FETCH_ASSOC);
                if (!$r) return null;
                return ['stage' => $r['stage'] ?: 'new', 'title' => (string) $r['name'], 'since' => $r['last_contact_at'] ?: $r['created_at'], 'owner_id' => $r['owner_id'] ? (int) $r['owner_id'] : null];
            },
            'ops' => [
                'stage' => function (PDO $pdo, int $id, array $in, int $uid, string $to) { require_once __DIR__ . '/../lib/Leads.php'; Leads::setStage($pdo, $uid, $id, $to, (string) ($in['note'] ?? '')); },
            ],
        ],
    ],

    // ---- Back-Office: a plan (decisions/0108 step 3) --------------------------------------------------------------------
    'subscription' => [
        'name' => 'Subscription', 'module' => 'backoffice', 'entity' => 'subscription',
        'def' => [
            'stages' => [
                $S('trial', 'Trial', 'start', ['owner_dept' => 'sal', 'locked' => true]),
                $S('active', 'Active', '', ['owner_dept' => 'fin', 'locked' => true]),
                $S('past_due', 'Card declined', '', ['owner_dept' => 'fin', 'sla_hours' => 168, 'locked' => true]),
                $S('ended', 'Ended', 'end', ['outcome' => 'done', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'end', 'label' => 'End now (back to Free)', 'from' => ['trial', 'active', 'past_due'], 'to' => 'ended', 'op' => 'end', 'asks' => ['note'], 'who' => ['min' => 'manager', 'depts' => ['fin', 'sal']]],
                // a trial becoming paid, renewals, retries and declines happen on their own (billing_tick) or on the Plans page
                ['key' => 'paid', 'label' => 'Becomes paid', 'from' => ['trial', 'past_due'], 'to' => 'active', 'op' => 'none', 'auto' => 'when the client keeps the plan, or the card goes through'],
                ['key' => 'declined', 'label' => 'Card declined', 'from' => ['active'], 'to' => 'past_due', 'op' => 'none', 'auto' => 'at a declined renewal'],
            ],
            'any' => [
                ['key' => 'stop', 'label' => 'Stop at renewal', 'op' => 'stop', 'who' => ['min' => 'manager', 'depts' => ['fin', 'sal']]],
            ],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare("SELECT s.*, COALESCE(e.name, u.display_name, u.email) AS who FROM subscriptions s LEFT JOIN entities e ON s.owner_type = 'listing' AND e.id = s.owner_id
                                     LEFT JOIN users u ON s.owner_type = 'user' AND u.id = s.owner_id WHERE s.id = ?"); $st->execute([$id]);
                $s = $st->fetch(PDO::FETCH_ASSOC);
                if (!$s) return null;
                return ['stage' => $s['status'], 'title' => (string) $s['who'], 'client_email' => (string) $s['bill_email'], 'since' => $s['updated_at'], 'owner_id' => null, 'row' => $s];
            },
            'ops' => [
                'end' => function (PDO $pdo, int $id, array $in) { require_once __DIR__ . '/../lib/Billing.php'; Billing::endNow($pdo, $id, mb_substr((string) ($in['note'] ?? 'ended by our team'), 0, 40)); },
                'stop' => function (PDO $pdo, int $id) { require_once __DIR__ . '/../lib/Billing.php'; Billing::cancelAtEnd($pdo, $id, true); },
                'none' => function () { throw new RuntimeException('That happens on its own (renewals) or on the client\'s Plans page.'); },
            ],
        ],
    ],

    // ---- Sales & Growth: a promotion (decisions/0108 step 4) ------------------------------------------------------------
    'promotion' => [
        'name' => 'Promotion', 'module' => 'growth', 'entity' => 'promotion',
        'def' => [
            'stages' => [
                $S('active', 'Active', 'start', ['owner_dept' => 'sal', 'op' => 'status']),
                $S('paused', 'Paused', '', ['owner_dept' => 'sal', 'op' => 'status']),
                $S('ended', 'Ended', 'end', ['outcome' => 'done', 'op' => 'status']),
            ],
            'moves' => [
                ['key' => 'pause', 'label' => 'Pause', 'from' => ['active'], 'to' => 'paused', 'op' => 'status', 'who' => ['min' => 'manager', 'depts' => ['sal']]],
                ['key' => 'resume', 'label' => 'Resume', 'from' => ['paused'], 'to' => 'active', 'op' => 'status', 'who' => ['min' => 'manager', 'depts' => ['sal']]],
                ['key' => 'end', 'label' => 'End it', 'from' => ['active', 'paused'], 'to' => 'ended', 'op' => 'status', 'who' => ['min' => 'manager', 'depts' => ['sal']]],
            ],
            'any' => [],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT * FROM promotions WHERE id = ?'); $st->execute([$id]);
                $p = $st->fetch(PDO::FETCH_ASSOC);
                return $p ? ['stage' => $p['status'], 'title' => $p['code'], 'since' => $p['updated_at'], 'owner_id' => $p['created_by'] ? (int) $p['created_by'] : null, 'row' => $p] : null;
            },
            'ops' => [
                'status' => function (PDO $pdo, int $id, array $in, int $uid, string $to) { require_once __DIR__ . '/../lib/Promotions.php'; Promotions::setStatus($pdo, $id, $to); },
            ],
        ],
    ],
    // ---- Directory & Places: a claim on a listing (decisions/0071, 0074) -------------------------------------------------
    'claim' => [
        'name' => 'Claim', 'module' => 'local', 'entity' => 'claim',
        'def' => [
            'stages' => [
                $S('emailing', 'Confirming their email', 'start', ['owner_dept' => 'ops', 'locked' => true]),
                $S('managed', 'Managing, to verify', '', ['owner_dept' => 'ops', 'sla_hours' => 48, 'locked' => true]),
                $S('on_hold', 'On hold (another claim holds it)', '', ['owner_dept' => 'ops', 'sla_hours' => 72, 'locked' => true]),
                $S('verified', 'Verified', 'end', ['outcome' => 'done', 'locked' => true]),
                $S('declined', 'Declined', 'end', ['outcome' => 'lost', 'locked' => true]),
                $S('withdrawn', 'Withdrawn or started', 'end', ['outcome' => 'cancelled', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'confirmed', 'label' => 'Email confirmed', 'from' => ['emailing'], 'to' => 'managed', 'op' => 'none', 'auto' => 'when the claimant enters the code we emailed'],
                ['key' => 'verify', 'label' => 'Verify', 'from' => ['managed'], 'to' => 'verified', 'op' => 'verify', 'who' => ['min' => 'staff', 'depts' => ['ops', 'svc']]],
                ['key' => 'start', 'label' => 'Start it (they manage the listing)', 'from' => ['on_hold'], 'to' => 'withdrawn', 'op' => 'start', 'who' => ['min' => 'staff', 'depts' => ['ops', 'svc']]],
                ['key' => 'decline', 'label' => 'Decline', 'from' => ['managed', 'on_hold'], 'to' => 'declined', 'op' => 'decline', 'asks' => ['note'], 'who' => ['min' => 'staff', 'depts' => ['ops', 'svc']]],
                ['key' => 'held', 'label' => 'Held', 'from' => ['emailing'], 'to' => 'on_hold', 'op' => 'none', 'auto' => 'when another claim already holds the listing'],
                ['key' => 'withdrawn', 'label' => 'Withdrawn', 'from' => ['emailing', 'managed', 'on_hold'], 'to' => 'withdrawn', 'op' => 'none', 'auto' => 'when the claimant withdraws it'],
            ],
            'any' => [
                ['key' => 'contact', 'label' => 'Log a call or email', 'op' => 'contact', 'asks' => ['note'], 'who' => ['min' => 'staff', 'depts' => []]],
                ['key' => 'ask', 'label' => 'Ask them for more', 'op' => 'ask', 'asks' => ['note'], 'who' => ['min' => 'staff', 'depts' => ['ops', 'svc']]],
                ['key' => 'full', 'label' => 'Open in the claims page', 'link' => '/admin/claims.php#c{id}', 'who' => ['min' => 'staff', 'depts' => []]],
            ],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT c.*, e.name AS listing, u.email, u.display_name FROM listing_claims c JOIN entities e ON e.id = c.entity_id LEFT JOIN users u ON u.id = c.user_id WHERE c.id = ?'); $st->execute([$id]);
                $c = $st->fetch(PDO::FETCH_ASSOC);
                return $c ? ['stage' => $c['status'], 'title' => (string) $c['listing'], 'client_email' => (string) $c['email'], 'since' => $c['updated_at'], 'owner_id' => null, 'row' => $c] : null;
            },
            'ops' => [
                'verify' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Claims.php'; Claims::verify($pdo, $id, $uid, 'admin', (string) ($in['note'] ?? '')); },
                'start' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Claims.php'; Claims::startHeld($pdo, $id, $uid); },
                'decline' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Claims.php'; Claims::decline($pdo, $id, $uid, (string) ($in['note'] ?? '')); },
                'contact' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Claims.php'; Claims::logContact($pdo, $id, $uid, 'call', (string) ($in['note'] ?? '')); },
                'ask' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Claims.php'; Claims::askMore($pdo, $id, $uid, (string) ($in['note'] ?? '')); },
                'none' => function () { throw new RuntimeException('That happens on the claimant\'s side.'); },
            ],
        ],
    ],

    // ---- Directory & Places: a landmark from the data, or added by hand (decisions/0058 §25–27, 0066) -------------------
    'landmark' => [
        'name' => 'Place review', 'module' => 'local', 'entity' => 'landmark',
        'def' => [
            'stages' => [
                $S('waiting', 'Waiting (kept until the nation tools)', 'start', ['owner_dept' => 'con', 'locked' => true]),
                $S('shown', 'Shown (from the data)', '', ['owner_dept' => 'con', 'locked' => true]),
                $S('approved', 'Shown (opened by a person)', '', ['owner_dept' => 'con', 'locked' => true]),
                $S('hidden', 'Hidden by us', '', ['owner_dept' => 'con', 'locked' => true]),
                $S('closed', 'Closed by a nation', 'end', ['outcome' => 'cancelled', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'approve', 'label' => 'Show it', 'from' => ['waiting'], 'to' => 'approved', 'op' => 'approve', 'who' => ['min' => 'manager', 'depts' => ['con', 'ops']]],
                ['key' => 'hide', 'label' => 'Hide it', 'from' => ['waiting', 'shown', 'approved'], 'to' => 'hidden', 'op' => 'hide', 'asks' => ['note'], 'who' => ['min' => 'staff', 'depts' => ['con', 'ops']]],
                ['key' => 'restore', 'label' => 'Undo the hide', 'from' => ['hidden'], 'to' => 'shown', 'op' => 'restore', 'who' => ['min' => 'staff', 'depts' => ['con', 'ops']]],
                ['key' => 'nation_close', 'label' => 'Close at the nation\'s request', 'from' => ['waiting', 'shown', 'approved', 'hidden'], 'to' => 'closed', 'op' => 'nation_close', 'asks' => ['note'], 'who' => ['min' => 'manager', 'depts' => ['ops']]],
            ],
            'any' => [],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT * FROM landmarks WHERE gnis_id = ?'); $st->execute([$id]);
                $r = $st->fetch(PDO::FETCH_ASSOC);
                return $r ? ['stage' => $r['status'], 'title' => (string) $r['name'], 'since' => $r['reviewed_at'] ?: $r['loaded_at'], 'owner_id' => null, 'row' => $r] : null;
            },
            'ops' => array_combine(['approve', 'hide', 'restore', 'nation_close'], array_map(fn ($do) => function (PDO $pdo, int $id, array $in, int $uid) use ($do) {
                require_once __DIR__ . '/../lib/Landmarks.php';
                Landmarks::review($pdo, $uid, $id, $do, (string) ($in['note'] ?? ''));
                try { require_once __DIR__ . '/../lib/SearchIndex.php'; if (SearchIndex::ready($pdo)) SearchIndex::refreshLandmark($pdo, $id); } catch (Throwable $e) { error_log('landmark reindex: ' . $e->getMessage()); }
            }, ['approve', 'hide', 'restore', 'nation_close'])),
        ],
    ],

    // ---- Journeys & Exploration: content (decisions/0056, 0060) -----------------------------------------------------------
    'journey' => [
        'name' => 'Journey', 'module' => 'explore', 'entity' => 'journey',
        'def' => [
            'stages' => [
                $S('draft', 'Draft', 'start', ['owner_dept' => 'con', 'locked' => true]),
                $S('published', 'Published', '', ['owner_dept' => 'con', 'locked' => true]),
                $S('hidden', 'Hidden', '', ['owner_dept' => 'con', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'publish', 'label' => 'Publish (Traversence pieces)', 'from' => ['draft'], 'to' => 'published', 'op' => 'publish', 'who' => ['min' => 'manager', 'depts' => ['con']]],
                ['key' => 'unpublish', 'label' => 'Back to a draft (Traversence pieces)', 'from' => ['published'], 'to' => 'draft', 'op' => 'unpublish', 'who' => ['min' => 'manager', 'depts' => ['con']]],
                ['key' => 'hide', 'label' => 'Hide it', 'from' => ['published'], 'to' => 'hidden', 'op' => 'hide', 'asks' => ['note'], 'who' => ['min' => 'manager', 'depts' => ['con', 'ops']]],
                ['key' => 'restore', 'label' => 'Restore', 'from' => ['hidden'], 'to' => 'published', 'op' => 'restore', 'who' => ['min' => 'manager', 'depts' => ['con', 'ops']]],
                ['key' => 'posted', 'label' => 'Posted by its author', 'from' => ['draft'], 'to' => 'published', 'op' => 'none', 'auto' => 'when a contributor publishes their own'],
            ],
            'any' => [['key' => 'view', 'label' => 'See it', 'link' => '/journeys/view.php?id={id}', 'who' => ['min' => 'staff', 'depts' => []]]],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT * FROM journeys WHERE id = ?'); $st->execute([$id]);
                $j = $st->fetch(PDO::FETCH_ASSOC);
                return $j ? ['stage' => $j['status'], 'title' => (string) $j['title'], 'since' => $j['updated_at'], 'owner_id' => $j['author_id'] ? (int) $j['author_id'] : null, 'row' => $j] : null;
            },
            'ops' => [
                'publish' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Journeys.php'; Journeys::setEditorial($pdo, $uid, $id, true); },
                'unpublish' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Journeys.php'; Journeys::setEditorial($pdo, $uid, $id, false); },
                'hide' => function (PDO $pdo, int $id, array $in) { require_once __DIR__ . '/../lib/Journeys.php'; Journeys::setHidden($pdo, $id, true, mb_substr(trim((string) ($in['note'] ?? '')), 0, 200)); },
                'restore' => function (PDO $pdo, int $id) { require_once __DIR__ . '/../lib/Journeys.php'; Journeys::setHidden($pdo, $id, false, ''); },
                'none' => function () { throw new RuntimeException('Its author publishes it.'); },
            ],
        ],
    ],

    'experience' => [
        'name' => 'Experience', 'module' => 'explore', 'entity' => 'experience',
        'def' => [
            'stages' => [
                $S('suggested', 'Suggested (from the data)', 'start', ['owner_dept' => 'con', 'locked' => true]),
                $S('submitted', 'Waiting for review', '', ['owner_dept' => 'con', 'sla_hours' => 72, 'locked' => true]),
                $S('published', 'Published', '', ['owner_dept' => 'con', 'locked' => true]),
                $S('rejected', 'Not approved', 'end', ['outcome' => 'lost', 'locked' => true]),
                $S('hidden', 'Hidden', '', ['owner_dept' => 'con', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'approve', 'label' => 'Approve', 'from' => ['suggested', 'submitted'], 'to' => 'published', 'op' => 'approve', 'who' => ['min' => 'manager', 'depts' => ['con']]],
                ['key' => 'reject', 'label' => 'Not approved', 'from' => ['suggested', 'submitted'], 'to' => 'rejected', 'op' => 'reject', 'asks' => ['note'], 'who' => ['min' => 'staff', 'depts' => ['con']]],
                ['key' => 'hide', 'label' => 'Hide it', 'from' => ['published'], 'to' => 'hidden', 'op' => 'hide', 'asks' => ['note'], 'who' => ['min' => 'staff', 'depts' => ['con']]],
                ['key' => 'restore', 'label' => 'Restore', 'from' => ['hidden', 'rejected'], 'to' => 'published', 'op' => 'restore', 'who' => ['min' => 'manager', 'depts' => ['con']]],
                ['key' => 'sent', 'label' => 'Sent for review', 'from' => ['suggested'], 'to' => 'submitted', 'op' => 'none', 'auto' => 'when its author sends it'],
            ],
            'any' => [['key' => 'view', 'label' => 'See it', 'link' => '/experiences/view.php?id={id}', 'who' => ['min' => 'staff', 'depts' => []]]],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT * FROM experiences WHERE id = ?'); $st->execute([$id]);
                $x = $st->fetch(PDO::FETCH_ASSOC);
                return $x ? ['stage' => $x['status'], 'title' => (string) $x['title'], 'since' => $x['updated_at'], 'owner_id' => $x['author_id'] ? (int) $x['author_id'] : null, 'row' => $x] : null;
            },
            'ops' => array_combine(['approve', 'reject', 'hide', 'restore'], array_map(fn ($do) => function (PDO $pdo, int $id, array $in, int $uid) use ($do) {
                require_once __DIR__ . '/../lib/Experiences.php';
                Experiences::review($pdo, $uid, $id, $do, (string) ($in['note'] ?? ''));
            }, ['approve', 'reject', 'hide', 'restore'])) + ['none' => function () { throw new RuntimeException('Its author sends it.'); }],
        ],
    ],

    'how_guide' => [
        'name' => 'How-to guide', 'module' => 'explore', 'entity' => 'how_guide',
        'def' => [
            'stages' => [
                $S('wanted', 'Wanted (people search for it)', 'start', ['owner_dept' => 'con', 'locked' => true]),
                $S('looking', 'The crawler is looking', '', ['owner_dept' => 'eng', 'locked' => true]),
                $S('draft', 'To review', '', ['owner_dept' => 'con', 'sla_hours' => 72, 'locked' => true]),
                $S('published', 'Published', '', ['owner_dept' => 'con', 'locked' => true]),
                $S('nothing', 'Nothing found yet', '', ['owner_dept' => 'con', 'locked' => true]),
                $S('rejected', 'Not a guide', 'end', ['outcome' => 'lost', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'found', 'label' => 'Crawler takes it', 'from' => ['wanted'], 'to' => 'looking', 'op' => 'none', 'auto' => 'on the crawler\'s next run'],
                ['key' => 'drafted', 'label' => 'Drafted from official pages', 'from' => ['looking'], 'to' => 'draft', 'op' => 'none', 'auto' => 'when the crawler finds official steps'],
                ['key' => 'notfound', 'label' => 'Nothing found', 'from' => ['looking'], 'to' => 'nothing', 'op' => 'none', 'auto' => 'when the crawler finds nothing'],
                ['key' => 'publish', 'label' => 'Publish (in the editor)', 'from' => ['draft'], 'to' => 'published', 'op' => 'none', 'auto' => 'from the guide editor, after checking its steps'],
                ['key' => 'unpublish', 'label' => 'Take it down', 'from' => ['published'], 'to' => 'draft', 'op' => 'unpublish', 'who' => ['min' => 'manager', 'depts' => ['con']]],
                ['key' => 'reject', 'label' => 'Not a guide', 'from' => ['wanted', 'draft', 'nothing'], 'to' => 'rejected', 'op' => 'reject', 'who' => ['min' => 'staff', 'depts' => ['con']]],
                ['key' => 'again', 'label' => 'Look again', 'from' => ['nothing', 'draft'], 'to' => 'wanted', 'op' => 'again', 'who' => ['min' => 'staff', 'depts' => ['con']]],
                ['key' => 'restore', 'label' => 'Back to wanted', 'from' => ['rejected'], 'to' => 'wanted', 'op' => 'restore', 'who' => ['min' => 'staff', 'depts' => ['con']]],
            ],
            'any' => [['key' => 'edit', 'label' => 'Open the guide editor', 'link' => '/admin/how-guides.php?id={id}', 'who' => ['min' => 'staff', 'depts' => ['con']]]],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT * FROM how_guides WHERE id = ?'); $st->execute([$id]);
                $g = $st->fetch(PDO::FETCH_ASSOC);
                return $g ? ['stage' => $g['status'], 'title' => (string) $g['title'] ?: (string) $g['gkey'], 'since' => $g['updated_at'], 'owner_id' => null, 'row' => $g] : null;
            },
            'ops' => array_combine(['unpublish', 'reject', 'again', 'restore'], array_map(fn ($do) => function (PDO $pdo, int $id, array $in, int $uid) use ($do) {
                require_once __DIR__ . '/../lib/HowGuides.php';
                HowGuides::decide($pdo, $id, $do, $uid);
            }, ['unpublish', 'reject', 'again', 'restore'])) + ['none' => function () { throw new RuntimeException('That happens on its own, or in the guide editor.'); }],
        ],
    ],

    // ---- Community & Events: a report on a post, a group, a journey… (decisions/0079) -------------------------------------
    // The item is the first open report on something; the decision covers every report on it.
    'report' => [
        'name' => 'Report', 'module' => 'social', 'entity' => 'report',
        'def' => [
            'stages' => [
                $S('open', 'New', 'start', ['owner_dept' => 'ops', 'sla_hours' => 24, 'locked' => true]),
                $S('removed', 'Taken down', 'end', ['outcome' => 'done', 'locked' => true]),
                $S('dismissed', 'Left up', 'end', ['outcome' => 'cancelled', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'remove', 'label' => 'Take it down', 'from' => ['open'], 'to' => 'removed', 'op' => 'remove', 'who' => ['min' => 'staff', 'depts' => ['ops', 'svc', 'con']]],
                ['key' => 'dismiss', 'label' => 'Leave it up', 'from' => ['open'], 'to' => 'dismissed', 'op' => 'dismiss', 'who' => ['min' => 'staff', 'depts' => ['ops', 'svc', 'con']]],
                ['key' => 'restore', 'label' => 'Put it back', 'from' => ['removed'], 'to' => 'dismissed', 'op' => 'restore', 'who' => ['min' => 'manager', 'depts' => ['ops']]],
            ],
            'any' => [],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                require_once __DIR__ . '/../lib/Reports.php';
                $st = $pdo->prepare('SELECT * FROM content_reports WHERE id = ?'); $st->execute([$id]);
                $r = $st->fetch(PDO::FETCH_ASSOC);
                if (!$r) return null;
                $o = $pdo->prepare("SELECT COUNT(*) FROM content_reports WHERE kind = ? AND target_id = ? AND status = 'open'"); $o->execute([$r['kind'], $r['target_id']]);
                return ['stage' => (int) $o->fetchColumn() ? 'open' : $r['status'], 'title' => (Reports::KIND_LABEL[$r['kind']] ?? 'Something') . ' #' . (int) $r['target_id'],
                        'since' => $r['handled_at'] ?: $r['created_at'], 'owner_id' => null, 'row' => $r];
            },
            'ops' => array_combine(['remove', 'dismiss', 'restore'], array_map(fn ($what) => function (PDO $pdo, int $id, array $in, int $uid) use ($what) {
                require_once __DIR__ . '/../lib/Reports.php';
                $st = $pdo->prepare('SELECT kind, target_id FROM content_reports WHERE id = ?'); $st->execute([$id]);
                $r = $st->fetch(PDO::FETCH_ASSOC);
                Reports::decide($pdo, $uid, (string) $r['kind'], (int) $r['target_id'], $what);
                // put back: what was taken down shows again, and its reports read as left up
                if ($what === 'restore') $pdo->prepare("UPDATE content_reports SET status = 'dismissed', handled_by = ?, handled_at = NOW() WHERE kind = ? AND target_id = ? AND status = 'removed'")->execute([$uid, $r['kind'], (int) $r['target_id']]);
            }, ['remove', 'dismiss', 'restore'])),
        ],
    ],

    // ---- Community & Events: a member's standing (the enforcement ladder, decisions/0079) ---------------------------------
    'standing' => [
        'name' => 'Standing notice', 'module' => 'social', 'entity' => 'member_action',
        'def' => [
            'stages' => [
                $S('open', 'Open (24 hours to put right)', 'start', ['owner_dept' => 'ops', 'sla_hours' => 24, 'locked' => true]),
                $S('review', 'Review asked', '', ['owner_dept' => 'ops', 'sla_hours' => 48, 'locked' => true]),
                $S('corrected', 'Put right', 'end', ['outcome' => 'done', 'locked' => true]),
                $S('lifted', 'Lifted after review', 'end', ['outcome' => 'done', 'locked' => true]),
                $S('closed', 'Closed', 'end', ['outcome' => 'cancelled', 'locked' => true]),
            ],
            'moves' => [
                ['key' => 'asked', 'label' => 'Member asks for a review', 'from' => ['open'], 'to' => 'review', 'op' => 'none', 'auto' => 'when the member asks from their notice'],
                ['key' => 'corrected', 'label' => 'Member puts it right', 'from' => ['open'], 'to' => 'corrected', 'op' => 'none', 'auto' => 'when the member confirms the steps'],
                ['key' => 'lift', 'label' => 'Lift it', 'from' => ['open', 'review'], 'to' => 'lifted', 'op' => 'lift', 'asks' => ['note'], 'who' => ['min' => 'manager', 'depts' => ['ops']]],
                ['key' => 'final', 'label' => 'Access revoked for good', 'from' => ['open', 'review'], 'to' => 'closed', 'op' => 'none', 'auto' => 'when a final step is upheld, or its time runs out'],
                ['key' => 'uphold', 'label' => 'Uphold it', 'from' => ['review'], 'to' => 'open', 'op' => 'uphold', 'asks' => ['note'], 'who' => ['min' => 'manager', 'depts' => ['ops']]],
            ],
            'any' => [['key' => 'member', 'label' => 'Their member card', 'link' => '/admin/people.php?sec=members&u={user_id}', 'who' => ['min' => 'staff', 'depts' => []]]],
        ],
        'adapter' => [
            'info' => function (PDO $pdo, int $id): ?array {
                $st = $pdo->prepare('SELECT a.*, u.display_name, u.email FROM member_actions a JOIN users u ON u.id = a.user_id WHERE a.id = ?'); $st->execute([$id]);
                $a = $st->fetch(PDO::FETCH_ASSOC);
                return $a ? ['stage' => $a['status'], 'title' => (trim((string) $a['display_name']) ?: (string) $a['email']), 'since' => $a['updated_at'], 'owner_id' => null, 'row' => $a] : null;
            },
            'ops' => [
                'lift' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Standing.php'; Standing::decide($pdo, $uid, $id, 'lift', (string) ($in['note'] ?? '')); },
                'uphold' => function (PDO $pdo, int $id, array $in, int $uid) { require_once __DIR__ . '/../lib/Standing.php'; Standing::decide($pdo, $uid, $id, 'uphold', (string) ($in['note'] ?? '')); },
                'none' => function () { throw new RuntimeException('That happens on the member\'s side.'); },
            ],
        ],
    ],
];
