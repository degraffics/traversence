<?php
// app/scripts/got_it_tick.php — "Did it arrive?" (decisions/0101, addendum 2026-10-30): an order all out the door for 72
// hours that the client hasn't confirmed gets one reminder to tell us they have it (that completes the order once it's paid; decisions/0178 §6). After it,
// the Pulse asks our team to complete it if they know it arrived.
// Sets itself up in cPanel through the API (Scheduler::AUTO): every hour.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('got_it_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Orders.php';
require_once __DIR__ . '/../lib/ClientOrders.php';
$pdo = Database::connection();
echo 'Arrival reminders sent: ' . ClientOrders::gotItTick($pdo) . "\n";
