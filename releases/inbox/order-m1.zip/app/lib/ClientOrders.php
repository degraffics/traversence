<?php
// app/lib/ClientOrders.php — orders our team builds for a client to review, approve and pay (decisions/0101).
//
//   draft     our team builds it: the client (a member, or a name and email), lines (catalog products with options and
//             quantity, GO Codes, custom lines), a proof per line to approve, the terms (pay in full, or a deposit when the
//             terms may still change; invoice later is no longer offered, decisions/0101 note "the order model",
//             2026-11-23), a note and how long it's good for
//   sent      the client has a private link (/order.php?t=…): they approve each proof or ask for changes (our team
//             uploads a new version and sends again), then approve the order with their name and billing address
//   pending   approved: the QuickBooks invoice is made then (tax from the address); they pay by card on the same page
//             (all of it, or the deposit and later the rest)
//   paid      GO Codes go live at once; printed products move through their stages: in production → ordered from the
//             printer → shipped / ready for pickup → complete; each step emails the client
// Paid in full before the vendor (a deposit order: its deposit) and before delivery (vendorHold, shipHold), unless an
// admin releases it before payment with a reason (releaseHold) or it was handled outside (decisions/0101 note
// 2026-11-23, model 1.9).
// Everything after approval is the order system's as for any order (Orders: refunds, credits, the ledger, the history).
declare(strict_types=1);

require_once __DIR__ . '/Orders.php';
require_once __DIR__ . '/Products.php';

require_once __DIR__ . '/Store.php';

final class ClientOrders
{
    public const PAY_MODES = ['full' => 'Pay in full on approval', 'deposit' => 'A deposit on approval, the rest once production schedules it, before delivery', 'invoice' => 'Approve now, pay the invoice later',
                              'outside' => 'Paid outside QuickBooks (cash, check, Zelle…): we record it'];
    /**
     * The terms a new order can be given (decisions/0101 note "the order model", 2026-11-23, §0 item 1: "Credit account
     * terms needed for delayed payments. Or admin override to proceed without payment."). Invoice later stays in
     * PAY_MODES so the orders that have it still read; it isn't offered, and a copy of one starts as Pay in full.
     */
    public const OFFERED = ['full', 'deposit', 'outside'];
    /** An item's statuses that release it for delivery (model 1.9): they wait for payment in full (shipHold). */
    public const OUT_DOOR = ['ready', 'shipped', 'in_route', 'delivered', 'complete'];
    /**
     * A deposit is figured from cost (decisions/0177 §3, Jason, 2026-11-23: "in most cases deposits are figured by covering
     * cogs + 15%"): each item's cost (its COGS and the shipping we pay) plus DEPOSIT_MARKUP %, never above the order. An item
     * whose cost isn't recorded counts at DEPOSIT_DEFAULT % of its price. Staff can still set a % for the whole order.
     */
    public const DEPOSIT_MARKUP = 15;
    public const DEPOSIT_DEFAULT = 65;
    /** Who may release an order before payment (model 1.9: "Admins only, with a reason recorded"): Executives and the Founder. */
    public const RELEASE_RULE = ['min' => 'executive', 'depts' => []];
    /** How it reaches the client (2026-12-08_delivery_outside.sql). '' = shipped when the order has a shipping line. */
    public const DELIVERY = ['ship' => 'We ship it to the client', 'pickup' => 'The client picks it up', 'none' => 'Nothing to deliver (GO Codes, services)'];
    /**
     * Each item's status (Jason, 2026-10-16): the order is the carrier, each item goes through its own process. Set by
     * hand; the client hears only when our team taps Send update. Grouped as they're offered.
     */
    public const ITEM_STATUS = [
        'Before approval' => ['incoming' => 'Incoming', 'review' => 'Under Review', 'pending' => 'Pending Approval', 'changes' => 'Changes Requested', 'response' => 'Response Required'],
        'Approved' => ['approved' => 'Approved (Production Queue)', 'creative_queue' => 'Creative Queue', 'creative' => 'Creative In-progress', 'preproduction' => 'Pre-production',
                       'holding' => 'Holding for resources', 'production' => 'In Production', 'finishing' => 'In Finishing', 'post' => 'Post Production'],
        'Out the door' => ['ready' => 'Ready for pickup', 'shipped' => 'Shipped', 'in_route' => 'Delivery In Route', 'delivered' => 'Delivered', 'complete' => 'Complete'],
        'Exceptions' => ['payment_hold' => 'Payment Hold', 'collections' => 'Collections', 'cancelled' => 'Cancelled'],
        'Housekeeping' => ['archived' => 'Archived', 'deactivated' => 'Deactivated', 'deleted' => 'Deleted (hidden, kept)'],
    ];
    /** Billed From on every order and invoice (Jason, 2026-10-16). */
    public const FROM = ['Traversence.com', 'PO Box 3570', 'Saint Johns, AZ 85936', 'support@traversence.com'];
    public const DUE_TERMS = ['receipt' => ['Due on receipt', 0], 'net15' => ['Net 15', 15], 'net30' => ['Net 30', 30]];
    public const PAY_METHODS = ['wire' => 'Wire transfer', 'cash' => 'Cash', 'check' => 'Check', 'zelle' => 'Zelle', 'venmo' => 'Venmo', 'bank' => 'Bank transfer', 'card' => 'Card (another terminal)', 'other' => 'Other'];
    public const STAGES = ['production' => 'In production', 'ordered' => 'Work order issued', 'shipped' => 'Shipped', 'ready' => 'Ready for pickup', 'complete' => 'Complete'];
    public const PROOF_TYPES = ['application/pdf' => 'pdf', 'image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
    public const DAYS = 14;

    // ---- reading ---------------------------------------------------------------------------------------------------------

    public static function isClient(array $o): bool { return (int) ($o['created_by'] ?? 0) > 0; }

    public static function byToken(PDO $pdo, string $t): ?array
    {
        if (!preg_match('/^[a-f0-9]{40}$/', $t)) return null;
        $st = $pdo->prepare('SELECT * FROM orders WHERE access_token = ? AND created_by IS NOT NULL'); $st->execute([$t]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function url(array $o): string
    {
        return rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/order.php?t=' . $o['access_token'];
    }

    public static function editable(array $o): bool { return in_array($o['status'], ['draft', 'sent'], true); }

    public static function expired(array $o): bool { return $o['status'] === 'sent' && $o['expires_at'] && strtotime((string) $o['expires_at']) < time(); }

    /** Lines with their latest proof (and its history) and, for a GO Code, the code. */
    public static function lines(PDO $pdo, int $oid): array
    {
        $lines = Orders::lines($pdo, $oid);
        $pr = $pdo->prepare('SELECT * FROM order_proofs WHERE order_id = ? ORDER BY line_id, version'); $pr->execute([$oid]);
        $proofs = []; $finals = [];
        foreach ($pr->fetchAll(PDO::FETCH_ASSOC) as $p) { if (($p['kind'] ?? 'proof') === 'final') $finals[(int) $p['line_id']][] = $p; else $proofs[(int) $p['line_id']][] = $p; }
        $parts = self::hasProjects($pdo) ? self::partsOf($pdo, array_map(fn ($l) => (int) $l['id'], $lines)) : [];
        foreach ($lines as &$l) {
            $l['finals'] = $finals[(int) $l['id']] ?? [];   // a creative item's print-ready files (no print in its project)
            $l['parts'] = $parts[(int) $l['id']] ?? [];     // a bundle's lines: our team only
            $h = $proofs[(int) $l['id']] ?? [];
            $l['proofs'] = $h;
            $l['proof'] = $h ? end($h) : null;
            $l['versions'] = [];   // version => its files
            foreach ($h as $p) $l['versions'][(int) $p['version']][] = $p;
            $l['proof_files'] = $l['proof'] ? $l['versions'][(int) $l['proof']['version']] : [];
            $l['code'] = null;
            if ($l['product'] === 'go_code' && $l['ref_id']) {
                $st = $pdo->prepare('SELECT q.*, s.code AS short_code FROM qr_issued q LEFT JOIN short_codes s ON s.id = q.short_code_id WHERE q.id = ?'); $st->execute([(int) $l['ref_id']]);
                $l['code'] = $st->fetch(PDO::FETCH_ASSOC) ?: null;
            }
        }
        unset($l);
        return array_values(array_filter($lines, fn ($l) => $l['status'] !== 'cancelled' || in_array($l['status'], ['refunded'], true)));
    }

    /** What the client owes now: the deposit first (when the terms say so), then whatever is left. */
    public static function dueNow(PDO $pdo, array $o): int
    {
        if ($o['status'] !== 'pending') return 0;
        $paid = Orders::money($pdo, (int) $o['id'])['paid'];
        $left = max(0, (int) $o['total_cents'] - $paid);
        // the deposit first: after a part payment below it (QuickBooks' page), the rest of the deposit, never the whole balance
        if ($o['pay_mode'] === 'deposit' && (int) $o['deposit_cents'] > 0 && $paid < (int) $o['deposit_cents']) return min($left, (int) $o['deposit_cents'] - $paid);
        return $left;
    }

    /**
     * The deposit on $total (decisions/0177 §3): staff's % when set, else each item's cost (COGS and the shipping we pay)
     * plus DEPOSIT_MARKUP %, an item with no recorded cost at DEPOSIT_DEFAULT % of its price; never above $total.
     * Returns [cents, words for our team, the titles and ids of items without a recorded cost].
     */
    public static function depositFor(PDO $pdo, array $o, int $total, ?array $lines = null): array
    {
        $pct = (int) ($o['deposit_pct'] ?? 0);
        if ($pct > 0) return [min($total, (int) round($total * $pct / 100)), $pct . '% of the total, as set', [], []];
        $lines ??= Orders::lines($pdo, (int) $o['id']);
        $cost = 0; $guess = 0; $open = []; $openIds = [];
        foreach ($lines as $l) {
            if (($l['status'] ?? '') === 'cancelled') continue;
            $c = max(1, (int) $l['qty']) * (int) ($l['cost_cents'] ?? 0) + (int) ($l['ship_cost_cents'] ?? 0);
            if ($c > 0) { $cost += $c; continue; }
            $price = max(1, (int) $l['qty']) * (int) $l['unit_cents'] + (int) ($l['ship_cents'] ?? 0);
            if ($price <= 0) continue;
            $guess += (int) round($price * self::DEPOSIT_DEFAULT / 100); $open[] = (string) $l['title']; $openIds[] = (int) $l['id'];
        }
        $dep = min($total, (int) round($cost * (100 + self::DEPOSIT_MARKUP) / 100) + $guess);
        $words = 'items\' cost + ' . self::DEPOSIT_MARKUP . '%' . ($open ? '; ' . count($open) . ' item' . (count($open) === 1 ? '' : 's') . ' at ' . self::DEPOSIT_DEFAULT . '% of price' : '');
        return [$dep, $words, $open, $openIds];
    }

    /** Who to tell about the client's answers: the staff member who built it (their work email), else the site's address. */
    private static function staffEmail(PDO $pdo, array $o): string
    {
        try {
            $st = $pdo->prepare("SELECT email FROM " . Database::t('staff_accounts') . " WHERE user_id = ? AND status = 'active'"); $st->execute([(int) $o['created_by']]);
            $e = (string) ($st->fetchColumn() ?: '');
            if (filter_var($e, FILTER_VALIDATE_EMAIL)) return $e;
        } catch (Throwable) {}
        $u = $pdo->prepare('SELECT email FROM users WHERE id = ?'); $u->execute([(int) $o['created_by']]);
        $e = (string) ($u->fetchColumn() ?: '');
        if (filter_var($e, FILTER_VALIDATE_EMAIL) && !str_ends_with($e, '.invalid')) return $e;
        return (string) (getenv('SMTP_FROM_EMAIL') ?: 'support@traversence.com');
    }

    // ---- building it (our team) --------------------------------------------------------------------------------------------

    /** A new draft for a client. $c: name, email, company, phone. A member with that email is linked. */
    public static function create(PDO $pdo, int $staffUid, array $c): int
    {
        [$name, $email, $company, $phone] = self::client($c);
        $token = bin2hex(random_bytes(20));
        $uid = self::memberFor($pdo, $email);
        $pdo->prepare("INSERT INTO orders (status, user_id, guest_key, access_token, bill_name, bill_email, client_company, client_phone, created_by, pay_mode) VALUES ('draft', ?, ?, ?, ?, ?, ?, ?, ?, 'full')")
            ->execute([$uid ?: null, $uid ? null : hash('sha256', 'client:' . $token), $token, $name, $email, $company, $phone, $staffUid]);
        $oid = (int) $pdo->lastInsertId();
        try { require_once __DIR__ . '/QuickBooksPay.php'; $pdo->prepare('UPDATE orders SET qb_env = ? WHERE id = ?')->execute([QuickBooksPay::env(), $oid]); } catch (Throwable) {}
        Orders::number($pdo, $oid);   // a sandbox order gets S-1, S-2…, not the next real number
        Orders::event($pdo, $oid, 'drafted', 'Started for ' . $name . ($company !== '' ? ' (' . $company . ')' : ''), $staffUid);
        return $oid;
    }

    /**
     * A copy of an order as a new draft: its items (projects, options, bundled lines, rates, run sizes) and their proofs
     * (each item's latest version waiting again; earlier ones kept as earlier). $test: billed to you, not the client, so
     * nothing reaches them. It's made in the QuickBooks mode that's on now (switch to Sandbox first for a test run).
     * GO Codes aren't copied (each is one code). Returns the new order's id.
     */
    public static function duplicate(PDO $pdo, int $oid, int $staff, bool $test): int
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o)) throw new RuntimeException('That order isn\'t here.');
        $me = self::staffEmail($pdo, ['created_by' => $staff]);
        $mk = fn () => self::create($pdo, $staff, ['name' => $test ? 'TEST · ' . preg_replace('/^(TEST · )+/u', '', (string) $o['bill_name']) : $o['bill_name'], 'email' => $test ? $me : $o['bill_email'],
            'company' => (string) $o['client_company'], 'phone' => (string) $o['client_phone']]);
        // a test copy is always a sandbox order (Jason, 2026-11-10), whatever mode Payments is in: no real money, ever
        require_once __DIR__ . '/QuickBooksPay.php';
        $nid = $test ? QuickBooksPay::withEnv('sandbox', $mk) : $mk();
        $keep = ['bill_street', 'bill_city', 'bill_state', 'bill_zip', 'ship_name', 'ship_street', 'ship_city', 'ship_state', 'ship_zip', 'note', 'pay_mode', 'deposit_pct', 'due_terms', 'ship_mode', 'delivery', 'no_ship_reason'];
        $set = []; $vals = [];
        foreach ($keep as $c) if (array_key_exists($c, $o)) { $set[] = "$c = ?"; $vals[] = $c === 'pay_mode' ? self::offeredMode((string) $o[$c]) : $o[$c]; }
        if ($set) { $vals[] = $nid; $pdo->prepare('UPDATE orders SET ' . implode(', ', $set) . ' WHERE id = ?')->execute($vals); }
        $pmap = [];
        foreach (self::projects($pdo, $oid) as $pj) { $pdo->prepare('INSERT INTO order_projects (order_id, title, position, created_at) VALUES (?, ?, ?, NOW())')->execute([$nid, $pj['title'], (int) $pj['position']]); $pmap[(int) $pj['id']] = (int) $pdo->lastInsertId(); }
        // collateral_id too: a copy is a new order, not a reorder of that collateral (Collateral's own reorder sets it itself);
        // Collateral::fromOrder gives the copy's items their own when it's approved (the survey, #16)
        $skip = ['id', 'order_id', 'status', 'approved_at', 'created_at', 'item_status', 'tracking', 'project_id', 'ref_id', 'promo_off_cents', 'collateral_id'];
        $st = $pdo->prepare("SELECT * FROM order_lines WHERE order_id = ? AND status <> 'cancelled' AND product <> 'go_code' ORDER BY position, id"); $st->execute([$oid]);
        $copied = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $l) {
            $cols = array_values(array_diff(array_keys($l), $skip));
            $pdo->prepare('INSERT INTO order_lines (order_id, ' . implode(', ', $cols) . ', project_id) VALUES (?' . str_repeat(', ?', count($cols)) . ', ?)')
                ->execute(array_merge([$nid], array_map(fn ($c) => $l[$c], $cols), [isset($l['project_id']) && isset($pmap[(int) $l['project_id']]) ? $pmap[(int) $l['project_id']] : null]));
            $lid = (int) $pdo->lastInsertId(); $copied++;
            if (preg_match('/^\d+$/', (string) ($l['ship_to'] ?? ''))) $pdo->prepare("UPDATE order_lines SET ship_to = '' WHERE id = ?")->execute([$lid]);   // an address of the old order: the new one's own instead
            require_once __DIR__ . '/Costing.php'; Costing::carry($pdo, (int) $l['id'], $nid, $lid, $staff);   // its costing, at today's costs (unchecked)
            foreach (self::partsOf($pdo, [(int) $l['id']])[(int) $l['id']] ?? [] as $pt)
                $pdo->prepare('INSERT INTO order_line_parts (line_id, title, qty, unit_cents, cost_cents, position, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())')->execute([$lid, $pt['title'], $pt['qty'], $pt['unit_cents'], $pt['cost_cents'], $pt['position']]);
            $pr = $pdo->prepare('SELECT * FROM order_proofs WHERE line_id = ? ORDER BY version, id'); $pr->execute([(int) $l['id']]);
            $proofs = $pr->fetchAll(PDO::FETCH_ASSOC);
            $last = 0; foreach ($proofs as $p) if (($p['kind'] ?? 'proof') === 'proof') $last = max($last, (int) $p['version']);
            foreach ($proofs as $p) {
                $src = Store::local(self::proofPath($p));
                if ($src === '') continue;   // its file is missing: skip it
                $final = ($p['kind'] ?? 'proof') === 'final';
                $pdo->prepare('INSERT INTO order_proofs (order_id, line_id, version, file_name, mime, status, created_by' . (self::hasProjects($pdo) ? ', kind' : '') . ') VALUES (?, ?, ?, ?, ?, ?, ?' . (self::hasProjects($pdo) ? ', ?' : '') . ')')
                    ->execute(array_merge([$nid, $lid, (int) $p['version'], $p['file_name'], $p['mime'], $final ? 'approved' : ((int) $p['version'] === $last ? 'waiting' : 'replaced'), $staff], self::hasProjects($pdo) ? [$final ? 'final' : 'proof'] : []));
                $np = (int) $pdo->lastInsertId();
                $dest = self::proofPlace($pdo, ['id' => $np, 'order_id' => $nid, 'mime' => $p['mime']]);
                if (!is_dir(dirname($dest))) @mkdir(dirname($dest), Store::mode($dest), true);
                if (!@copy($src, $dest)) { $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$np]); continue; }
                Store::keep($dest);
            }
        }
        self::recalc($pdo, $nid);
        Orders::event($pdo, $nid, 'drafted', ($test ? 'Test copy' : 'Copy') . ' of order #' . Orders::no($o) . ' (' . $copied . ' items)', $staff);
        Orders::event($pdo, $oid, 'copied', ($test ? 'Test copy' : 'Copied') . ' as order #' . Orders::no(Orders::get($pdo, $nid) ?: ['id' => $nid]), $staff);
        return $nid;
    }

    private static function client(array $c): array
    {
        $name = mb_substr(trim((string) ($c['name'] ?? '')), 0, 120);
        $email = strtolower(mb_substr(trim((string) ($c['email'] ?? '')), 0, 190));
        if ($name === '') throw new RuntimeException('Add the client\'s name.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Add the client\'s email: the order goes there.');
        return [$name, $email, mb_substr(trim((string) ($c['company'] ?? '')), 0, 120), mb_substr(trim((string) ($c['phone'] ?? '')), 0, 40)];
    }

    private static function memberFor(PDO $pdo, string $email): int
    {
        $st = $pdo->prepare("SELECT id FROM users WHERE email = ? AND email NOT LIKE '%@staff.traversence.invalid' LIMIT 1"); $st->execute([$email]);
        return (int) ($st->fetchColumn() ?: 0);
    }

    /** The client, the terms and the note (while it's a draft or sent). */
    public static function saveTerms(PDO $pdo, int $oid, array $in, int $staff): void
    {
        $o = self::mine($pdo, $oid, true);
        [$name, $email, $company, $phone] = self::client($in);
        $mode = isset(self::PAY_MODES[$in['pay_mode'] ?? '']) ? (string) $in['pay_mode'] : 'full';
        if (!in_array($mode, self::OFFERED, true) && $mode !== (string) $o['pay_mode']) throw new RuntimeException('Invoice later isn\'t offered any more: choose Pay in full or a Deposit. To go ahead before payment, an admin releases the order once it\'s approved, with a reason.');
        $pct = $mode === 'deposit' ? (int) ($in['deposit_pct'] ?? 0) : 0;
        if ($mode === 'deposit' && ($pct < 0 || $pct > 99)) throw new RuntimeException('Enter the deposit as a % between 1 and 99, or leave it empty for the items\' cost plus ' . self::DEPOSIT_MARKUP . '%.');
        if ($mode === 'outside' && !self::hasDelivery($pdo)) throw new RuntimeException('Import app/migrations/2026-12-08_delivery_outside.sql in phpMyAdmin first.');
        if (self::hasItems($pdo)) $pdo->prepare('UPDATE orders SET po_number = ?, due_terms = ? WHERE id = ?')->execute([mb_substr(trim((string) ($in['po'] ?? '')), 0, 60), isset(self::DUE_TERMS[$in['due_terms'] ?? '']) ? (string) $in['due_terms'] : 'receipt', $oid]);
        if (self::hasDelivery($pdo)) $pdo->prepare('UPDATE orders SET delivery = ? WHERE id = ?')->execute([isset(self::DELIVERY[$in['delivery'] ?? '']) ? (string) $in['delivery'] : '', $oid]);
        $uid = self::memberFor($pdo, $email);
        $pdo->prepare('UPDATE orders SET bill_name = ?, bill_email = ?, client_company = ?, client_phone = ?, pay_mode = ?, deposit_pct = ?, note = ?, user_id = ?, guest_key = ? WHERE id = ?')
            ->execute([$name, $email, $company, $phone, $mode, $pct, mb_substr(trim((string) ($in['note'] ?? '')), 0, 300), $uid ?: null, $uid ? null : hash('sha256', 'client:' . $o['access_token']), $oid]);
        $pdo->prepare('UPDATE qr_issued SET user_id = ?, guest_key = ? WHERE order_id = ? AND status = \'pending\'')->execute([$uid ?: null, $uid ? null : hash('sha256', 'client:' . $o['access_token']), $oid]);
    }

    /**
     * While an order is a draft (not sent yet), its catalog lines follow the catalog: a changed price or cost updates
     * them; a price our team typed stays, only its catalog price (shown struck through) moves. Once sent, never.
     */
    public static function refreshPrices(PDO $pdo, int $oid): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || $o['status'] !== 'draft') return;
        $changed = false;
        foreach (Orders::lines($pdo, $oid) as $l) {
            if ($l['product'] !== 'product' || !$l['product_id']) continue;
            $p = Products::get($pdo, (int) $l['product_id']);
            if (!$p || !self::runKnown($l)) continue;   // its size lost to a rename: leave its price alone until it's set again
            $qty = self::runQty($l) / max(1, (int) $l['qty']);
            $list = Products::priceFor($p, $qty, Products::pickedFrom($p, (string) $l['options']));
            $own = (int) $l['unit_cents'] !== (int) $l['list_cents'];   // a price our team typed
            $unit = $own ? (int) $l['unit_cents'] : $list['total'];
            if (self::costed($pdo, (int) $l['id'])) $list['cost'] = (int) $l['cost_cents'];   // its COGS (Cost tab) is its cost: the catalog's doesn't replace it
            // Taxable is the line's own (set from the product when it was added; our team's untick stays): never reset here
            if ($unit !== (int) $l['unit_cents'] || $list['total'] !== (int) $l['list_cents'] || $list['cost'] !== (int) $l['cost_cents']) {
                $pdo->prepare('UPDATE order_lines SET unit_cents = ?, list_cents = ?, cost_cents = ? WHERE id = ?')->execute([$unit, $list['total'], $list['cost'], (int) $l['id']]);
                $changed = true;
            }
        }
        if ($changed) self::recalc($pdo, $oid);
    }

    /** A catalog product line: quantity, options picked, the catalog price (or ours: a change shows as a discount). */
    public static function addProduct(PDO $pdo, int $oid, int $pid, int $qty, array $opts, string $price, string $note, int $staff): int
    {
        self::mine($pdo, $oid, true);
        $p = Products::get($pdo, $pid);
        if (!$p || $p['status'] !== 'active') throw new RuntimeException('Choose a product from the catalog.');
        if ($qty < 1) throw new RuntimeException('Enter how many as a whole number, 1 or more. Nothing was added.');   // never taken silently as 1 (the survey, #14)
        $labels = []; $picked = [];
        foreach ($p['options'] as $i => $o) {
            $v = (string) ($opts[$i] ?? '');
            if (!in_array($v, array_column($o['choices'], 'label'), true)) $v = $o['choices'][0]['label'];
            $labels[] = $v; $picked[] = $o['name'] . ': ' . $v;
        }
        $list = Products::priceFor($p, $qty, $labels);
        $unit = trim($price) === '' ? $list['total'] : self::cents($price);
        $title = $p['name'] . ' · ' . number_format($qty);
        $pdo->prepare("INSERT INTO order_lines (order_id, product, product_id, title, qty, unit_cents, list_cents, cost_cents, taxable, options, note) VALUES (?, 'product', ?, ?, 1, ?, ?, ?, ?, ?, ?)")
            ->execute([$oid, $pid, mb_substr($title, 0, 160), $unit, $list['total'], $list['cost'], (int) $p['taxable'], mb_substr(implode(' · ', $picked), 0, 400), mb_substr(trim($note), 0, 300)]);
        $id = (int) $pdo->lastInsertId();
        if (self::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([$qty, $id]);
        self::recalc($pdo, $oid);
        Orders::event($pdo, $oid, 'line_added', $title . ' · ' . Orders::usd($unit), $staff);
        return $id;
    }

    /** A custom line: our own description and price. */
    public static function addCustom(PDO $pdo, int $oid, string $title, int $qty, string $price, bool $taxable, string $note, int $staff, string $cost = '', string $kind = 'custom', string $type = ''): int
    {
        self::mine($pdo, $oid, true);
        $title = mb_substr(trim($title), 0, 160);
        if ($title === '') throw new RuntimeException('Describe the line.');
        $unit = self::cents($price);
        $c = trim($cost) === '' ? 0 : self::cents($cost);
        $pdo->prepare("INSERT INTO order_lines (order_id, product, title, qty, unit_cents, list_cents, cost_cents, taxable, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$oid, $kind === 'shipping' ? 'shipping' : 'custom', $title, max(1, $qty), $unit, $unit, $c, $taxable ? 1 : 0, mb_substr(trim($note), 0, 300)]);
        $id = (int) $pdo->lastInsertId();
        if ($type !== '' && $kind !== 'shipping') { require_once __DIR__ . '/Promotions.php'; if (isset(Promotions::SERVICE_TYPES[$type])) $pdo->prepare('UPDATE order_lines SET service_type = ? WHERE id = ?')->execute([$type, $id]); }
        self::recalc($pdo, $oid);
        Orders::event($pdo, $oid, 'line_added', $title . ' · ' . max(1, $qty) . ' × ' . Orders::usd($unit), $staff);
        return $id;
    }

    /** A GO Code line: made now with what it holds, issued (through trvgo.us) once the order is paid. */
    public static function addGoCode(PDO $pdo, int $oid, string $type, array $fields, string $title, string $price, int $staff): void
    {
        $o = self::mine($pdo, $oid, true);
        require_once __DIR__ . '/QrIssue.php';
        if (!isset(Qr::TYPES[$type])) throw new RuntimeException('Choose what the code should do.');
        $fields = array_intersect_key(array_map(fn ($v) => trim((string) $v), $fields), QrIssue::FIELDS[$type] ?? []);
        $content = Qr::content($type, $fields);
        Qr::svg($content, []);
        $unit = trim($price) === '' ? QrIssue::PRICE_CENTS : self::cents($price);
        $title = mb_substr(trim($title), 0, 120) ?: Qr::TYPES[$type];
        $pdo->prepare("INSERT INTO qr_issued (user_id, guest_key, type, fields, content, style, title, status, price_cents, order_id) VALUES (?, ?, ?, ?, ?, '[]', ?, 'pending', ?, ?)")
            ->execute([$o['user_id'] ?: null, $o['user_id'] ? null : $o['guest_key'], $type, json_encode($fields, JSON_UNESCAPED_UNICODE), $content, $title, $unit, $oid]);
        $qid = (int) $pdo->lastInsertId();
        QrIssue::issueShort($pdo, $qid);   // its trvgo.us address now, for the proof (it reads "not active" until the order is paid)
        $pdo->prepare("INSERT INTO order_lines (order_id, product, ref_id, title, qty, unit_cents, list_cents, taxable) VALUES (?, 'go_code', ?, ?, 1, ?, ?, 1)")
            ->execute([$oid, $qid, 'GO Code: ' . $title, $unit, QrIssue::PRICE_CENTS]);
        self::goProof($pdo, $oid, (int) $pdo->lastInsertId(), $staff);
        self::recalc($pdo, $oid);
        Orders::event($pdo, $oid, 'line_added', 'GO Code: ' . $title . ' · ' . Orders::usd($unit), $staff);
    }

    /** A GO Code line's name and what it holds (before the client approves); its printed QR stays the same. */
    public static function updateGoCode(PDO $pdo, int $oid, int $lineId, string $title, array $fields, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        if ($l['product'] !== 'go_code' || !$l['ref_id']) throw new RuntimeException('That line isn\'t a GO Code.');
        require_once __DIR__ . '/QrIssue.php';
        $q = $pdo->query('SELECT * FROM qr_issued WHERE id = ' . (int) $l['ref_id'])->fetch(PDO::FETCH_ASSOC);
        if (!$q) throw new RuntimeException('That GO Code isn\'t here.');
        $fields = array_intersect_key(array_map(fn ($v) => trim((string) $v), $fields), QrIssue::FIELDS[$q['type']] ?? []);
        $content = Qr::content((string) $q['type'], $fields);
        $title = mb_substr(trim($title), 0, 120) ?: (string) $q['title'];
        $pdo->prepare('UPDATE qr_issued SET fields = ?, content = ?, title = ? WHERE id = ?')->execute([json_encode($fields, JSON_UNESCAPED_UNICODE), $content, $title, (int) $q['id']]);
        if ($q['short_code_id']) $pdo->prepare('UPDATE short_codes SET title = ? WHERE id = ?')->execute([$title, (int) $q['short_code_id']]);
        $pdo->prepare('UPDATE order_lines SET title = ? WHERE id = ?')->execute(['GO Code: ' . $title, $lineId]);
        Orders::event($pdo, $oid, 'line_changed', 'GO Code: ' . $title . ' (what it holds)', $staff, $lineId);
        self::goProof($pdo, $oid, $lineId, $staff);   // changed: a new proof for the client to approve
    }

    /**
     * A GO Code's proof: no file, the code itself (its QR and what it holds), approved by the client like any proof
     * (mime 'go-code'). A new version replaces one still waiting or with changes asked for.
     */
    private static function goProof(PDO $pdo, int $oid, int $lineId, ?int $staff): void
    {
        $v = (int) $pdo->query('SELECT COALESCE(MAX(version), 0) FROM order_proofs WHERE line_id = ' . $lineId)->fetchColumn() + 1;
        $pdo->prepare("UPDATE order_proofs SET status = 'replaced' WHERE line_id = ? AND status IN ('waiting', 'changes')")->execute([$lineId]);
        $pdo->prepare("INSERT INTO order_proofs (order_id, line_id, version, file_name, mime, created_by) VALUES (?, ?, ?, 'GO Code', 'go-code', ?)")->execute([$oid, $lineId, $v, $staff ?: null]);
    }

    public static function updateLine(PDO $pdo, int $oid, int $lineId, int $qty, string $price, string $note, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        $unit = trim($price) === '' ? (int) $l['unit_cents'] : self::cents($price);   // blank: a catalog line takes the catalog's price below
        if ($l['product'] === 'product') {   // a catalog line's quantity is in its title; its price follows the catalog unless typed
            $p = Products::get($pdo, (int) $l['product_id']);
            if ($p && $qty > 0) {
                $list = Products::priceFor($p, $qty, Products::pickedFrom($p, (string) $l['options']));
                $t = (string) $l['title'];   // a name you changed stays; one still ending in its size ("… · 500") follows it
                $title = $t === '' ? $p['name'] . ' · ' . number_format($qty) : (self::runInTitle($t) > 0 || !self::hasRunQty($pdo) ? self::titleWithRun($t, $qty) : $t);   // nowhere else to keep it until 2026-12-28_order_run_qty.sql
                $pdo->prepare('UPDATE order_lines SET title = ?, list_cents = ?, cost_cents = ? WHERE id = ?')->execute([mb_substr($title, 0, 160), $list['total'], $list['cost'], $lineId]);
                if (self::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([$qty, $lineId]);
                if (trim($price) === '') $unit = $list['total'];
            } elseif ($qty > 0) {   // the product isn't in the catalog any more: its size (name and run) still changes; its price is the one given
                $t = (string) $l['title'];
                if (self::runInTitle($t) > 0 || !self::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET title = ? WHERE id = ?')->execute([mb_substr(self::titleWithRun($t, $qty), 0, 160), $lineId]);
                if (self::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([$qty, $lineId]);
            }
            $pdo->prepare('UPDATE order_lines SET unit_cents = ?, note = ? WHERE id = ?')->execute([$unit, mb_substr(trim($note), 0, 300), $lineId]);
        } else {
            $pdo->prepare('UPDATE order_lines SET qty = ?, unit_cents = ?, note = ? WHERE id = ?')->execute([$l['product'] === 'go_code' ? 1 : max(1, $qty), $unit, mb_substr(trim($note), 0, 300), $lineId]);
            if ($l['product'] === 'go_code' && $l['ref_id']) $pdo->prepare('UPDATE qr_issued SET price_cents = ? WHERE id = ?')->execute([$unit, (int) $l['ref_id']]);
        }
        self::recalc($pdo, $oid);
        Orders::event($pdo, $oid, 'line_changed', $l['title'] . ' · ' . Orders::usd($unit), $staff, $lineId);
    }

    public static function removeLine(PDO $pdo, int $oid, int $lineId, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        if ($l['product'] === 'go_code' && $l['ref_id']) $pdo->prepare("DELETE FROM qr_issued WHERE id = ? AND status = 'pending'")->execute([(int) $l['ref_id']]);
        foreach ($pdo->query('SELECT * FROM order_proofs WHERE line_id = ' . $lineId)->fetchAll(PDO::FETCH_ASSOC) as $p) { require_once __DIR__ . '/Store.php'; Store::remove(self::proofPath($p)); }
        $pdo->prepare('DELETE FROM order_proofs WHERE line_id = ?')->execute([$lineId]);
        if (self::hasProjects($pdo)) $pdo->prepare('DELETE FROM order_line_parts WHERE line_id = ?')->execute([$lineId]);
        $pdo->prepare('DELETE FROM order_lines WHERE id = ?')->execute([$lineId]);
        self::recalc($pdo, $oid);
        Orders::event($pdo, $oid, 'line_removed', (string) $l['title'], $staff);
    }

    /** Types by file extension, for the uploader (Uploads): ext => [the types it may really be]. */
    public static function extTypes(array $mimeToExt): array
    {
        $out = []; foreach ($mimeToExt as $m => $x) $out[$x][] = $m;
        if (isset($out['jpg'])) $out['jpeg'] = $out['jpg'];
        if (isset($out['tif'])) $out['tiff'] = $out['tif'];
        return $out;
    }

    /**
     * A proof file that has arrived (Uploads, decisions/0127). Files sent together ($batch) are one new version: the
     * first starts it (the unanswered version before it is marked replaced; every earlier one is kept), the rest join it.
     */
    public static function proofFromUpload(PDO $pdo, int $oid, int $lineId, Upload $u, int $staff, string $batch): array
    {
        self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        $mime = (string) (array_search($u->ext === 'jpeg' ? 'jpg' : $u->ext, self::PROOF_TYPES, true) ?: '');
        if ($mime === '') throw new InvalidArgumentException($u->name . ': a proof is a PDF, PNG, JPG or WebP file.');
        $bk = $lineId . ':' . (preg_match('/^[a-z0-9]{6,40}$/', $batch) ? $batch : $u->token);
        $v = (int) ($_SESSION['tv_op_batch'][$bk] ?? 0); $new = !$v;
        if ($new) {
            $kq = self::hasProjects($pdo) ? " AND kind = 'proof'" : '';
            $v = (int) $pdo->query('SELECT COALESCE(MAX(version), 0) FROM order_proofs WHERE line_id = ' . $lineId . $kq)->fetchColumn() + 1;
            $pdo->prepare("UPDATE order_proofs SET status = 'replaced' WHERE line_id = ? AND status IN ('waiting', 'changes', 'approved')" . $kq)->execute([$lineId]);   // a new version needs its own approval
            $_SESSION['tv_op_batch'][$bk] = $v;
        }
        $pdo->prepare("INSERT INTO order_proofs (order_id, line_id, version, file_name, mime, created_by) VALUES (?, ?, ?, ?, ?, ?)")
            ->execute([$oid, $lineId, $v, mb_substr($u->name, 0, 160), $mime, $staff]);
        $pid = (int) $pdo->lastInsertId();
        try { $u->moveTo(self::proofPlace($pdo, ['id' => $pid, 'order_id' => $oid, 'mime' => $mime])); }
        catch (Throwable $x) { $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$pid]); throw $x; }
        Orders::event($pdo, $oid, 'proof', 'Proof v' . $v . ' for ' . $l['title'] . ': ' . $u->name, $staff, $lineId);
        $o = Orders::get($pdo, $oid);
        return ['proof' => $pid, 'version' => $v, 'message' => $u->name . ' added to proof v' . $v . '.' . ($o && $o['status'] === 'sent' ? ' Send the order again so the client sees it.' : '')];
    }

    /** Swaps one file of a proof version for a new one (same version, same answer so far); the old file is deleted. */
    public static function replaceProofFile(PDO $pdo, int $oid, int $pid, Upload $u, int $staff): array
    {
        self::mine($pdo, $oid, true);
        $old = self::proof($pdo, $oid, $pid);
        if (!$old || ($old['kind'] ?? 'proof') !== 'proof' || $old['mime'] === 'go-code') throw new RuntimeException('That proof file isn\'t here.');
        $mime = (string) (array_search($u->ext === 'jpeg' ? 'jpg' : $u->ext, self::PROOF_TYPES, true) ?: '');
        if ($mime === '') throw new InvalidArgumentException($u->name . ': a proof is a PDF, PNG, JPG or WebP file.');
        $pdo->prepare('INSERT INTO order_proofs (order_id, line_id, version, file_name, mime, status, client_note, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$oid, (int) $old['line_id'], (int) $old['version'], mb_substr($u->name, 0, 160), $mime, $old['status'] === 'replaced' ? 'replaced' : 'waiting', (string) $old['client_note'], $staff]);
        $nid = (int) $pdo->lastInsertId();
        try { $u->moveTo(self::proofPlace($pdo, ['id' => $nid, 'order_id' => $oid, 'mime' => $mime])); }
        catch (Throwable $x) { $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$nid]); throw $x; }
        require_once __DIR__ . '/Store.php'; Store::remove(self::proofPath($old));
        $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$pid]);
        $again = $old['status'] !== 'replaced' && self::reproof($pdo, $oid, (int) $old['line_id'], (int) $old['version']);
        Orders::event($pdo, $oid, 'proof', 'Proof v' . (int) $old['version'] . ': ' . $old['file_name'] . ' replaced by ' . $u->name . ($again ? '; the client approves it again' : ''), $staff, (int) $old['line_id']);
        $o = Orders::get($pdo, $oid);
        return ['proof' => $nid, 'message' => $old['file_name'] . ' replaced by ' . $u->name . ' (still version ' . (int) $old['version'] . ')' . ($again ? '. It needs the client\'s approval again' . ($o && $o['status'] === 'sent' ? ': send the order again so they see it.' : '.') : '.')];
    }

    /** Takes one file out of a proof version (a version with no files left is gone; the one before it is current again). */
    public static function removeProofFile(PDO $pdo, int $oid, int $pid, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $p = self::proof($pdo, $oid, $pid);
        if (!$p || ($p['kind'] ?? 'proof') !== 'proof' || $p['mime'] === 'go-code') throw new RuntimeException('That proof file isn\'t here.');
        require_once __DIR__ . '/Store.php'; Store::remove(self::proofPath($p));
        $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$pid]);
        $kq = self::hasProjects($pdo) ? " AND kind = 'proof'" : '';
        $left = (int) $pdo->query('SELECT COUNT(*) FROM order_proofs WHERE line_id = ' . (int) $p['line_id'] . ' AND version = ' . (int) $p['version'] . $kq)->fetchColumn();
        if (!$left) {   // the whole version is gone: the latest one left is the current proof again
            $prev = $pdo->query('SELECT MAX(version) FROM order_proofs WHERE line_id = ' . (int) $p['line_id'] . $kq)->fetchColumn();
            if ($prev) $pdo->prepare("UPDATE order_proofs SET status = 'waiting' WHERE line_id = ? AND version = ? AND status = 'replaced'" . $kq)->execute([(int) $p['line_id'], (int) $prev]);
        }
        $again = $left && $p['status'] !== 'replaced' && self::reproof($pdo, $oid, (int) $p['line_id'], (int) $p['version']);   // what's left changed: approved again
        Orders::event($pdo, $oid, 'proof', 'Proof v' . (int) $p['version'] . ': ' . $p['file_name'] . ' taken out' . ($again ? '; the client approves it again' : ''), $staff, (int) $p['line_id']);
    }

    /**
     * A proof version whose files changed (one replaced or taken out) needs the client's approval again (Jason,
     * 2026-10-28): back to waiting, its approval, initials and changes request cleared. True when it was decided before.
     */
    private static function reproof(PDO $pdo, int $oid, int $lineId, int $version): bool
    {
        $kq = self::hasProjects($pdo) ? " AND kind = 'proof'" : '';
        $was = (int) $pdo->query("SELECT COUNT(*) FROM order_proofs WHERE line_id = $lineId AND version = $version AND status IN ('approved', 'changes')" . $kq)->fetchColumn();
        $pdo->prepare("UPDATE order_proofs SET status = 'waiting', decided_at = NULL" . (self::hasSignoff($pdo) ? ", client_initials = '', client_ip = ''" : '') . " WHERE line_id = ? AND version = ? AND status <> 'replaced'" . $kq)->execute([$lineId, $version]);
        $open = (int) $pdo->query("SELECT COUNT(*) FROM order_proofs WHERE order_id = $oid AND status = 'changes'")->fetchColumn();
        $pdo->prepare('UPDATE orders SET review = ? WHERE id = ?')->execute([$open ? 'changes' : '', $oid]);
        return $was > 0;
    }

    /** An item's file that has arrived (Uploads): artwork, reference or a shipping label ($lineId 0: a pack's label). */
    public static function fileFromUpload(PDO $pdo, int $oid, int $lineId, Upload $u, int $staff, string $kind = 'label'): int
    {
        if (!self::hasInline($pdo)) throw new RuntimeException('Run 2026-12-18_item_panel.sql first.');
        if ($lineId) self::line($pdo, $oid, $lineId);
        if (!isset(self::FILE_KINDS[$kind])) $kind = 'reference';
        $types = $kind === 'label' ? self::FILE_TYPES : self::ALL_TYPES;
        $ext = $u->ext === 'jpeg' ? 'jpg' : ($u->ext === 'tiff' ? 'tif' : $u->ext);
        $mime = (string) (array_search($ext, $types, true) ?: '');
        if ($mime === '') throw new InvalidArgumentException($kind === 'label' ? 'A label is a PDF or an image.' : $u->name . ': use PDF, an image, SVG, TIFF, EPS, PSD, AI, InDesign, Word, Excel, PowerPoint, text or ZIP.');
        $pdo->prepare("INSERT INTO order_files (order_id, line_id, kind, file_name, mime, created_by) VALUES (?, ?, ?, ?, ?, ?)")->execute([$oid, $lineId, $kind, mb_substr($u->name, 0, 160), $mime, $staff]);
        $id = (int) $pdo->lastInsertId();
        try { $u->moveTo(self::filePlace($pdo, ['id' => $id, 'order_id' => $oid, 'mime' => $mime])); }
        catch (Throwable $x) { $pdo->prepare('DELETE FROM order_files WHERE id = ?')->execute([$id]); throw $x; }
        Orders::event($pdo, $oid, $kind === 'label' ? 'label' : 'file', self::FILE_KINDS[$kind] . ($lineId ? ' for line ' . $lineId : '') . ': ' . $u->name, $staff, $lineId ?: null);
        return $id;
    }

    /**
     * A sandbox (test) order deleted for good, with everything on it: its items, proofs and files (from storage too),
     * projects, shipping, history and test money. Only a sandbox order: a real one is cancelled, never deleted.
     */
    public static function deleteTest(PDO $pdo, int $oid): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o) throw new RuntimeException('That order is already gone.');
        if (!Orders::isTest($o)) throw new RuntimeException('Only a sandbox (test) order can be deleted. A real one is cancelled, and kept.');
        require_once __DIR__ . '/Store.php';
        $q = function (string $sql) use ($pdo, $oid) { try { $pdo->prepare($sql)->execute([$oid]); } catch (Throwable $x) { } };   // a table from a migration not run yet: nothing to clear
        try { foreach ($pdo->query('SELECT * FROM order_proofs WHERE order_id = ' . $oid)->fetchAll(PDO::FETCH_ASSOC) as $p) if ($p['mime'] !== 'go-code') Store::remove(self::proofPath($p)); } catch (Throwable $x) { }
        try { foreach ($pdo->query('SELECT * FROM order_files WHERE order_id = ' . $oid)->fetchAll(PDO::FETCH_ASSOC) as $f) Store::remove(self::filePath($f)); } catch (Throwable $x) { }
        $q('DELETE FROM order_line_parts WHERE line_id IN (SELECT id FROM order_lines WHERE order_id = ?)');
        $q('DELETE FROM order_pack_items WHERE pack_id IN (SELECT id FROM order_packs WHERE order_id = ?)');
        foreach (['order_proofs', 'order_files', 'order_packs', 'order_lots', 'order_addresses', 'order_vendor_jobs', 'order_work_orders', 'vendor_jobs', 'order_projects', 'promotion_uses', 'order_ledger', 'order_events', 'order_lines'] as $t) $q("DELETE FROM $t WHERE order_id = ?");
        $q('DELETE FROM qr_issued WHERE order_id = ?');
        $q('UPDATE order_inbox SET order_id = NULL WHERE order_id = ?');
        $pdo->prepare('DELETE FROM orders WHERE id = ?')->execute([$oid]);
    }

    /** An item's file or one of the order's documents taken off (a pack keeps its place, without the label). */
    public static function removeFile(PDO $pdo, int $oid, int $fid, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o)) throw new RuntimeException('That order isn\'t here.');
        $st = $pdo->prepare('SELECT * FROM order_files WHERE id = ? AND order_id = ?'); $st->execute([$fid, $oid]);
        $f = $st->fetch(PDO::FETCH_ASSOC);
        if (!$f) throw new RuntimeException('That file is already gone.');
        require_once __DIR__ . '/Store.php';
        Store::remove(self::filePath($f));
        try { $pdo->prepare('UPDATE order_packs SET label_id = NULL WHERE label_id = ?')->execute([$fid]); } catch (Throwable $x) { }
        $pdo->prepare('DELETE FROM order_files WHERE id = ?')->execute([$fid]);
        Orders::event($pdo, $oid, 'file', (self::FILE_KINDS[$f['kind']] ?? 'File') . ' taken off: ' . $f['file_name'], $staff, (int) $f['line_id'] ?: null);
    }

    /** Can files be retired (2027-01-24_order_files_retired.sql has run)? */
    public static function canRetire(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT retired_at FROM order_files LIMIT 0'); $ok = true; } catch (Throwable $x) { $ok = false; } }
        return $ok;
    }

    /**
     * A file retired (Jason, 2026-10-30: an old copy never sent to a vendor by mistake) or brought back: it stays on the order,
     * and while retired no work order offers it. Not while a work order that's still open carries it.
     */
    public static function retireFile(PDO $pdo, int $oid, int $fid, bool $retire, int $staff): array
    {
        if (!self::canRetire($pdo)) throw new RuntimeException('Retiring files waits on its database update (it runs within the hour, or open Database updates).');
        $st = $pdo->prepare('SELECT * FROM order_files WHERE id = ? AND order_id = ?'); $st->execute([$fid, $oid]);
        $f = $st->fetch(PDO::FETCH_ASSOC) ?: throw new RuntimeException('That file isn\'t on this order.');
        if ($retire) {
            require_once __DIR__ . '/WorkOrders.php';
            foreach (WorkOrders::forOrder($pdo, $oid) as $w) {
                $ws = (string) ($w['status'] ?? ($w['sent_at'] ? 'sent' : 'draft'));
                if (!in_array($ws, ['cancelled', 'declined', 'rejected', 'received'], true) && in_array('f' . $fid, json_decode((string) $w['files'], true) ?: [], true))
                    throw new RuntimeException($f['file_name'] . ' is on work order ' . $w['wo_no'] . ': untick it there and save, then retire it.');
            }
        }
        $pdo->prepare('UPDATE order_files SET retired_at = ' . ($retire ? 'NOW()' : 'NULL') . ', retired_by = ? WHERE id = ?')->execute([$retire ? $staff : null, $fid]);
        Orders::event($pdo, $oid, 'file', (self::FILE_KINDS[$f['kind']] ?? 'File') . ($retire ? ' retired (not offered for work orders): ' : ' brought back: ') . $f['file_name'], $staff, (int) $f['line_id'] ?: null);
        return $f;
    }

    /** Can proof versions be retired (2027-01-25_order_proofs_retired.sql has run)? */
    public static function canRetireProofs(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT retired_at FROM order_proofs LIMIT 0'); $ok = true; } catch (Throwable $x) { $ok = false; } }
        return $ok;
    }

    /**
     * A proof file (a concept, a version's file, a print-ready file) retired or brought back, or every file of its version
     * with $wholeVersion (Jason, 2026-10-30: take away access to old concepts and versions). Retired, our team still sees it;
     * the client's page doesn't show it and its links don't open it, and no work order offers it. Not while an open work
     * order carries it. Returns how many files changed.
     */
    public static function retireProof(PDO $pdo, int $oid, int $pid, bool $retire, int $staff, bool $wholeVersion = false): int
    {
        if (!self::canRetireProofs($pdo)) throw new RuntimeException('Retiring proofs waits on its database update (it runs within the hour, or open Database updates).');
        $st = $pdo->prepare('SELECT * FROM order_proofs WHERE id = ? AND order_id = ?'); $st->execute([$pid, $oid]);
        $p = $st->fetch(PDO::FETCH_ASSOC) ?: throw new RuntimeException('That proof isn\'t on this order.');
        $rows = [$p];
        if ($wholeVersion) { $st = $pdo->prepare('SELECT * FROM order_proofs WHERE line_id = ? AND version = ? AND ' . (self::hasProjects($pdo) ? 'kind = ?' : '1 = ?')); $st->execute([(int) $p['line_id'], (int) $p['version'], self::hasProjects($pdo) ? (string) ($p['kind'] ?? 'proof') : 1]); $rows = $st->fetchAll(PDO::FETCH_ASSOC); }
        if ($retire) {
            require_once __DIR__ . '/WorkOrders.php';
            foreach (WorkOrders::forOrder($pdo, $oid) as $w) {
                $ws = (string) ($w['status'] ?? ($w['sent_at'] ? 'sent' : 'draft'));
                if (in_array($ws, ['cancelled', 'declined', 'rejected', 'received'], true)) continue;
                $on = json_decode((string) $w['files'], true) ?: [];
                foreach ($rows as $r) if (in_array('p' . (int) $r['id'], $on, true)) throw new RuntimeException($r['file_name'] . ' is on work order ' . $w['wo_no'] . ': untick it there and save, then retire it.');
            }
        }
        $n = 0;
        foreach ($rows as $r) {
            if (!empty($r['retired_at']) === $retire) continue;
            $pdo->prepare('UPDATE order_proofs SET retired_at = ' . ($retire ? 'NOW()' : 'NULL') . ', retired_by = ? WHERE id = ?')->execute([$retire ? $staff : null, (int) $r['id']]);
            $n++;
        }
        if ($n) Orders::event($pdo, $oid, 'proof', (($p['kind'] ?? 'proof') === 'final' ? 'Print-ready file' : 'Proof v' . (int) $p['version']) . ($wholeVersion ? ' (' . $n . ' file' . ($n === 1 ? '' : 's') . ')' : ': ' . $p['file_name'])
            . ($retire ? ' retired: the client no longer sees it, and no work order offers it' : ' brought back'), $staff, (int) $p['line_id'] ?: null);
        return $n;
    }

    /** May this order take files now (Uploads checks before anything is sent)? */
    public static function canAddFiles(PDO $pdo, int $oid, bool $proof, int $lineId = 0): void
    {
        $o = self::mine($pdo, $oid, $proof);
        if ($lineId) self::line($pdo, $oid, $lineId);
        if (!$proof && !self::hasInline($pdo)) throw new RuntimeException('Run 2026-12-18_item_panel.sql first.');
        unset($o);
    }

    /** A proof's file: kept with its order (decisions/0124); one from before owner folders where it was, until it moves. */
    public static function proofPath(array $p): string
    {
        require_once __DIR__ . '/Store.php';
        return Store::either(self::proofPlace(Database::connection(), $p), __DIR__ . '/../storage/order-proofs/' . (int) $p['order_id'] . '/' . (int) $p['id'] . '.' . (self::PROOF_TYPES[$p['mime']] ?? 'bin'));
    }

    public static function proofPlace(PDO $pdo, array $p): string
    {
        require_once __DIR__ . '/Store.php';
        return Store::path('orders', (int) $p['order_id'], 'proofs', (int) $p['id'] . '.' . (self::PROOF_TYPES[$p['mime']] ?? 'bin'), false);
    }

    public static function proof(PDO $pdo, int $oid, int $pid): ?array
    {
        $st = $pdo->prepare('SELECT * FROM order_proofs WHERE id = ? AND order_id = ?'); $st->execute([$pid, $oid]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Sends (or sends again) the order to the client: their private link by email, good for $days. */
    /** Out to the client: their link, by email. $mail false: a sandbox order opened by our team as the client, no email. */
    public static function send(PDO $pdo, int $oid, int $days, int $staff, bool $mail = true): string
    {
        $o = self::mine($pdo, $oid, true);
        $lines = Orders::lines($pdo, $oid);
        if (!$lines) throw new RuntimeException('Add something to the order first.');
        if ($gaps = self::proofGaps($pdo, $lines)) throw new RuntimeException(self::proofGapText($gaps));
        self::refreshPrices($pdo, $oid);   // the catalog's latest, as it goes out
        foreach ($lines as $l) if ($l['product'] === 'go_code' && !$pdo->query('SELECT 1 FROM order_proofs WHERE line_id = ' . (int) $l['id'])->fetchColumn()) self::goProof($pdo, $oid, (int) $l['id'], $staff);   // codes added before proofs
        $again = $o['status'] === 'sent';
        $days = max(1, min(90, $days ?: self::DAYS));
        $until = date('Y-m-d 23:59:59', strtotime('+' . $days . ' days'));
        $pdo->prepare("UPDATE orders SET status = 'sent', sent_at = NOW(), expires_at = ?, review = '' WHERE id = ?")->execute([$until, $oid]);
        $o = Orders::get($pdo, $oid);
        $proofs = (int) $pdo->query("SELECT COUNT(*) FROM order_proofs WHERE order_id = $oid AND status = 'waiting'")->fetchColumn();
        self::$mailed = null;
        if (!$mail) { Orders::event($pdo, $oid, $again ? 'resent' : 'sent', 'Opened as the client by our team (sandbox test, no email), good until ' . date('M j', strtotime($until)), $staff); return self::url($o); }
        if ($o['pay_mode'] === 'deposit') $depWords = (int) $o['deposit_pct'] > 0 ? ' (' . (int) $o['deposit_pct'] . '% when you approve)' : ' (' . Orders::usd(self::depositFor($pdo, $o, (int) $o['subtotal_cents'], $lines)[0]) . ' when you approve)';
        self::$mailed = self::mail($o, ($again ? 'Your updated order from Traversence' : 'Your order from Traversence') . ', for your review',
            'Hello ' . $o['bill_name'] . ",\n\n" . ($again ? 'We\'ve updated your order' . ($proofs ? ' with new proofs' : '') . '.' : 'Your order is ready for your review.')
            . ($o['note'] !== '' ? "\n\n" . $o['note'] : '')
            . "\n\nReview it" . ($proofs ? ', approve the proofs,' : '') . " and approve it here:\n" . self::url($o)
            . "\n\nThe total is " . Orders::usd((int) $o['subtotal_cents']) . ' before tax. ' . self::PAY_MODES[$o['pay_mode']] . ($depWords ?? '') . '.'
            . "\nThis link works until " . date('F j, Y', strtotime($until)) . ".");
        Orders::event($pdo, $oid, $again ? 'resent' : 'sent', (self::$mailed ? 'To ' : 'The email didn\'t go to ') . $o['bill_email'] . ', good until ' . date('M j', strtotime($until)), $staff);
        return self::url($o);
    }

    public static function cancel(PDO $pdo, int $oid, string $why, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o)) throw new RuntimeException('That order isn\'t here.');
        if (Orders::money($pdo, $oid)['paid'] > 0) throw new RuntimeException('Something has been paid on this order: refund it from the order page instead.');
        $pdo->prepare("DELETE FROM qr_issued WHERE order_id = ? AND status = 'pending'")->execute([$oid]);
        Orders::cancelUnpaid($pdo, $oid, $why !== '' ? $why : 'Cancelled', $staff);
        if ($o['status'] !== 'draft') self::mail($o, 'Your Traversence order was cancelled', 'Hello ' . $o['bill_name'] . ",\n\nOrder #" . Orders::no($o) . ' was cancelled' . ($why !== '' ? ': ' . $why : '') . '. Nothing was charged.');
    }

    /** Printed products' progress after payment (or after an admin released it before payment). */
    public static function setStage(PDO $pdo, int $oid, string $stage, string $tracking, ?int $staff, string $detail = '', bool $mail = true, bool $checkPaid = true): void   // $detail: for our history only (the vendor's name), never the client's
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o)) throw new RuntimeException('That order isn\'t here.');
        if (!isset(self::STAGES[$stage])) throw new RuntimeException('Choose a stage.');
        if (in_array($o['status'], ['draft', 'sent', 'void'], true)) throw new RuntimeException('The client hasn\'t approved this order yet.');
        if ($checkPaid && in_array($stage, ['shipped', 'ready'], true) && ($why = self::shipHold($pdo, $o)) !== '') throw new RuntimeException($why);
        if ($stage === 'ordered' && ($why = self::vendorHold($pdo, $o)) !== '') throw new RuntimeException($why);   // sent to a printer is released to the vendor (model 1.9)
        $tracking = mb_substr(trim($tracking), 0, 160);
        $pdo->prepare('UPDATE orders SET stage = ?, tracking = ? WHERE id = ?')->execute([$stage, $tracking, $oid]);
        if (in_array($stage, ['shipped', 'ready', 'complete'], true)) $pdo->prepare("UPDATE order_lines SET status = 'done' WHERE order_id = ? AND status = 'open'")->execute([$oid]);
        Orders::event($pdo, $oid, 'stage', self::STAGES[$stage] . ($detail !== '' ? ' ' . $detail : '') . ($tracking !== '' ? ' · ' . $tracking : ''), $staff);
        $say = ['production' => 'is in production', 'ordered' => 'has been sent to print', 'shipped' => 'has shipped', 'ready' => 'is ready for pickup', 'complete' => 'is complete'][$stage];
        if ($mail && self::wantsProgress($o)) self::mail($o, 'Your Traversence order ' . $say, 'Hello ' . $o['bill_name'] . ",\n\nYour order #" . Orders::no($o) . ' ' . $say . '.' . ($tracking !== '' ? "\n" . ($stage === 'shipped' ? 'Tracking: ' : '') . $tracking : '')
            . (in_array($stage, ['shipped', 'ready'], true) && self::hasReceived($pdo) ? "\n\n" . self::GOT_IT_ASK . "\n" . self::url($o) . '#got-it' : "\n\nSee your order any time:\n" . self::url($o)));
    }

    /**
     * Why an order can't be released for delivery (Shipped or Ready for pickup) yet, or '' when it can. One rule on every
     * path (decisions/0101 note of 2026-11-20, B.4, as the order model changes it, note of 2026-11-23): paid in full
     * ("Balance must be paid before order is release for delivery", model 1.9), except an admin's release before payment
     * (releaseHold) or outside terms (B.4: the order is paid outside QuickBooks, or was handled outside). Invoice later is
     * no longer an exception (model §0 item 3).
     */
    public static function shipHold(PDO $pdo, array $o): string
    {
        $oid = (int) $o['id'];
        if (($o['pay_mode'] ?? '') === 'outside') return '';
        $left = (int) $o['total_cents'] - Orders::money($pdo, $oid)['paid'];
        if ($left <= 0 || self::overridden($pdo, $oid)) return '';
        return 'Order #' . Orders::no($o) . ' isn\'t paid in full yet (' . Orders::usd($left) . ' still to pay), so it can\'t be released for delivery (shipped or ready for pickup). Record the payment when it comes in, or an admin can release it before payment, with a reason.';
    }

    /**
     * Why an approved order can't go to a vendor yet (a work order sent or its link handed over, or marked sent to a
     * printer), or '' when it can. Model 1.9: "Paid in full before order is released to vendor", "a deposit overrides this
     * statement" (a deposit order goes once its deposit is paid: releaseAt), and "Admin can override payment requirements
     * to initiate vendor work orders pre funding" (releaseHold, which the outside path also records). A draft can still
     * be prepared and saved.
     */
    public static function vendorHold(PDO $pdo, array $o): string
    {
        if (!self::isClient($o) || !in_array((string) $o['status'], ['pending'], true)) return '';   // paid, or not approved (create() says so)
        $oid = (int) $o['id'];
        $need = self::releaseAt($o); $paid = Orders::money($pdo, $oid)['paid'];
        if ($need <= 0 || $paid >= $need || self::overridden($pdo, $oid)) return '';
        $dep = $o['pay_mode'] === 'deposit' && (int) ($o['deposit_cents'] ?? 0) > 0;
        return 'Order #' . Orders::no($o) . ' goes to the vendor once ' . ($dep ? 'its deposit is paid' : 'it\'s paid in full') . ' (' . Orders::usd($need - $paid) . ' still to pay). Save the work order now and send it then, or an admin can release the order before payment, with a reason.';
    }

    /** An admin released it before payment, or it was handled outside (an order_events 'released'). */
    public static function overridden(PDO $pdo, int $oid): bool
    {
        $st = $pdo->prepare("SELECT 1 FROM order_events WHERE order_id = ? AND event = 'released' LIMIT 1"); $st->execute([$oid]);
        return (bool) $st->fetchColumn();
    }

    /** May this person release an order before payment? [true, ''] or [false, why] (model 1.9: admins only). */
    public static function canRelease(): array
    {
        require_once __DIR__ . '/../admin/Access.php';
        return Access::can('backoffice.release_unpaid', self::RELEASE_RULE);
    }

    /**
     * Orders still on invoice-later terms, open (a draft, sent, or approved and not paid in full) and not yet chosen for
     * (decisions/0101 note 2026-11-23, §0 item 1; the session manager's review of the rebuild, 2026-11-23: "one Pulse case,
     * choose for each"). Each: the order, what's paid, and whether it was pulled from QuickBooks (QbPull marks those with
     * pay_mode 'invoice' too). Nothing about them changes until someone chooses (invoiceLaterChoose).
     */
    public static function invoiceLaterOpen(PDO $pdo): array
    {
        $st = $pdo->query("SELECT o.*, (SELECT COALESCE(SUM(l.amount_cents), 0) FROM order_ledger l WHERE l.order_id = o.id AND l.kind IN ('charge', 'deposit')) AS paid_cents
            FROM orders o WHERE o.created_by > 0 AND o.pay_mode = 'invoice' AND o.status IN ('draft', 'sent', 'pending') AND COALESCE(o.qb_env, '') NOT IN ('sandbox', 'mock')
            AND NOT EXISTS (SELECT 1 FROM order_events e WHERE e.order_id = o.id AND e.event = 'released') ORDER BY o.id");
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $o) $out[] = $o + ['pulled' => str_starts_with((string) $o['approved_name'], 'QuickBooks invoice ')];
        return $out;
    }

    /**
     * What happens to one order still on invoice later (the Pulse case's choice): 'invoice' (Send invoice, model 1.1: it's
     * paid in full now; an approved one's client is emailed that its invoice is due, with the link to pay), or 'release'
     * (an admin's release before payment, with a reason: releaseHold). Send cart waits for the cart route. Returns words.
     */
    public static function invoiceLaterChoose(PDO $pdo, int $oid, string $choice, string $why, int $staff): string
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || ($o['pay_mode'] ?? '') !== 'invoice') throw new RuntimeException('That order isn\'t on invoice-later terms any more: it\'s been chosen for.');
        if ($choice === 'release') {
            if ($o['status'] !== 'pending') throw new RuntimeException('Order #' . Orders::no($o) . ' isn\'t approved yet: send it as an invoice now, and release it once it\'s approved if it should go ahead before payment.');
            self::releaseHold($pdo, $oid, $staff, $why);
            return 'Order #' . Orders::no($o) . ' is released before payment; it keeps its invoice-later terms.';
        }
        if ($choice !== 'invoice') throw new RuntimeException('Choose what happens to it.');
        $pdo->prepare("UPDATE orders SET pay_mode = 'full' WHERE id = ?")->execute([$oid]);
        Orders::event($pdo, $oid, 'terms', 'Invoice later ended: paid in full now (decisions/0101 note 2026-11-23)', $staff);
        if ($o['status'] !== 'pending') return 'Order #' . Orders::no($o) . ' is Pay in full now: it goes to the client that way when it\'s sent.';
        $left = max(0, (int) $o['total_cents'] - Orders::money($pdo, $oid)['paid']);
        self::mail($o, 'Order #' . Orders::no($o) . ': your invoice is due now', 'Hello ' . $o['bill_name'] . ",\n\nOrder #" . Orders::no($o) . "'s invoice" . ($o['invoice_no'] ? ' (' . $o['invoice_no'] . ')' : '') . ' is due now: '
            . Orders::usd($left) . ". We start printing once it's paid.\n\nSee it and pay here:\n" . self::url($o) . "\n\nQuestions? Just reply.");
        return 'Order #' . Orders::no($o) . ' is Pay in full now; ' . $o['bill_name'] . ' was emailed that ' . Orders::usd($left) . ' is due, with the link to pay.';
    }

    /** A copy of an order keeps its terms, but invoice later (no longer offered) becomes Pay in full. */
    public static function offeredMode(string $mode): string { return in_array($mode, self::OFFERED, true) ? $mode : 'full'; }

    /** What's still open on an approved order before it's complete: words for the question, [] when nothing is. */
    /**
     * Why an order can't be completed yet: money still owed ('' when nothing is). Jason, 2026-11-23: "paid in full or
     * overrides" (decisions/0177 §4). An admin may complete it anyway with a reason (completeOwed), as for releasing
     * before payment (RELEASE_RULE). The client saying they have it isn't stopped: that's a fact, and staff are told.
     */
    public static function completeHold(PDO $pdo, array $o): string
    {
        if (($o['status'] ?? '') !== 'pending') return '';
        $left = (int) $o['total_cents'] - (int) (Orders::money($pdo, (int) $o['id'])['paid'] ?? 0);
        return $left > 0 ? Orders::usd($left) . ' still owed: collect the balance first' : '';
    }

    /** Complete an order with money still owed: admins only, with a reason kept on the order. */
    public static function completeOwed(PDO $pdo, int $oid, int $staff, string $why): void
    {
        [$may, $whyNot] = self::canRelease();
        if (!$may) throw new RuntimeException($whyNot . ': only an admin completes an order with money still owed.');
        $why = trim(preg_replace('/\s+/u', ' ', $why));
        if (mb_strlen($why) < 3) throw new RuntimeException('Say why it\'s complete with money still owed: it\'s kept on the order.');
        $o = Orders::get($pdo, $oid) ?: throw new RuntimeException('That order isn\'t here.');
        $hold = self::completeHold($pdo, $o);
        if ($hold !== '') Orders::event($pdo, $oid, 'completed_owed', 'Completed with ' . strtok($hold, ':') . ': ' . mb_substr($why, 0, 300), $staff);
        self::complete($pdo, $oid, $staff, self::openBeforeComplete($pdo, $o, (int) (Orders::money($pdo, $oid)['paid'] ?? 0)));
    }

    public static function openBeforeComplete(PDO $pdo, array $o, int $paid): array
    {
        $out = [];
        $left = (int) $o['total_cents'] - $paid; if ($left > 0) $out[] = Orders::usd($left) . ' still to be paid';
        require_once __DIR__ . '/WorkOrders.php';
        $wo = 0; foreach (WorkOrders::forOrder($pdo, (int) $o['id']) as $w) if (!in_array((string) ($w['status'] ?? ''), ['received', 'cancelled', 'complete', 'declined', 'rejected'], true)) $wo++;
        if ($wo) $out[] = $wo . ' work order' . ($wo === 1 ? '' : 's') . ' not received yet';
        $n = 0; foreach (Orders::lines($pdo, (int) $o['id']) as $l) if ($l['product'] !== 'shipping' && !in_array(self::itemStatus($o, $l), ['shipped', 'in_route', 'delivered', 'ready', 'complete', 'cancelled', 'archived', 'deactivated', 'deleted'], true)) $n++;
        if ($n) $out[] = $n . ' item' . ($n === 1 ? '' : 's') . ' not shipped or picked up';
        return $out;
    }

    /**
     * Where an order stands, as one (research/order-management-design-2026-11-23.md §3, approved as the plan by Jason,
     * 2026-11-23): three states kept apart, Order (where the job stands, §3.1), Money (what's owed, §3.2) and Delivery
     * (where the goods are, §3.3), and the one Next step by §3.4's rule. The board's rows and tiles, the order page's three
     * lines and anything else that says where an order stands read this; nothing else decides it.
     * Returns ['order' => [key, word, sub, sentence], 'money' => [key, word, sub, sentence, left, due, past_due], 'delivery'
     * => [key, word, sentence], 'next' => [state, label, href, act, who] or null, 'tile' => needs|client|production|door|done,
     * 'open' => bool]. Each sentence follows its word ("Out the door." + "Ready for pickup since Nov 2; …"), never repeats it.
     * Money 'left' is all that's still to pay; 'due' is what's owed now (a deposit order's balance isn't due until it's
     * out the door), which is what Money owed counts.
     */
    public static function boardState(PDO $pdo, array $o, ?array $lines = null): array
    {
        $oid = (int) $o['id']; $u = '/admin/backoffice/orders/' . $oid; $st = (string) $o['status']; $stage = (string) ($o['stage'] ?? '');
        $lines ??= self::lines($pdo, $oid);
        $m = Orders::money($pdo, $oid); $paid = (int) $m['paid']; $total = (int) $o['total_cents'];
        $day = fn ($t) => $t ? date('M j', is_int($t) ? $t : strtotime((string) $t)) : '';
        $ago = function ($t): string { if (!$t) return ''; $d = (int) floor((strtotime(date('Y-m-d')) - strtotime(date('Y-m-d', is_int($t) ? $t : strtotime((string) $t)))) / 86400); return $d <= 0 ? 'today' : ($d === 1 ? '1 day' : $d . ' days'); };
        $next = fn (string $label, string $href = '', string $act = '', string $who = 'us', string $state = '') => ['state' => $state, 'label' => $label, 'href' => $href ?: $u, 'act' => $act, 'who' => $who];
        $closed = $st === 'void' || $stage === 'complete' || $st === 'refunded';
        $deliv = self::deliverables($o, $lines);
        $wos = []; if (!in_array($st, ['draft', 'sent', 'void'], true)) { try { require_once __DIR__ . '/WorkOrders.php'; $wos = array_values(array_filter(WorkOrders::forOrder($pdo, $oid), fn ($w) => !in_array((string) ($w['status'] ?? ''), ['cancelled', 'declined', 'rejected'], true))); } catch (Throwable) {} }
        $woOut = array_values(array_filter($wos, fn ($w) => ($w['status'] ?? 'draft') !== 'draft'));
        $received = !empty($o['received_at']);
        $out = !$closed && ($received || self::outTheDoor($pdo, $o, $lines) || in_array($stage, ['shipped', 'ready'], true));
        $dispute = $st === 'disputed' || Orders::disputeOpen($pdo, $oid);

        // ---- Delivery (§3.3) ----
        $pickup = self::delivery($o, $lines) === 'pickup' || in_array($stage, ['ready'], true);
        $istat = array_map(fn ($l) => self::itemStatus($o, $l), $deliv);
        if (!$deliv) $dl = ['none', 'Nothing to send', ': digital, a service or GO Codes only.'];
        elseif ($received || $stage === 'complete' || ($istat && !array_diff($istat, ['delivered', 'complete']))) {
            $by = ''; if ($received) {   // who said so: the person on our team, by name, or the client
                $rs = $pdo->prepare("SELECT e.actor_user_id, u.display_name FROM order_events e LEFT JOIN users u ON u.id = e.actor_user_id WHERE e.order_id = ? AND e.event = 'received' ORDER BY e.id DESC LIMIT 1"); $rs->execute([$oid]); $rw = $rs->fetch(PDO::FETCH_ASSOC) ?: [];
                $nm = trim((string) strtok(preg_replace('/\s*\(.*$/', '', (string) ($rw['display_name'] ?? '')), ' '));
                $by = !empty($rw['actor_user_id']) ? ' on ' . $day($o['received_at']) . ', recorded by ' . ($nm !== '' ? $nm : 'our team') . '.' : ': the client told us on ' . $day($o['received_at']) . '.'; }
            $dl = ['delivered', 'Delivered', $received ? $by : '.'];
        }
        elseif ($stage === 'ready' || in_array('ready', $istat, true)) $dl = ['ready', 'Ready for pickup', ' at our shop.'];
        elseif ($stage === 'shipped' || array_intersect($istat, ['shipped', 'in_route'])) $dl = ['shipped', 'Shipped', (($o['tracking'] ?? '') !== '' ? ': ' . $o['tracking'] : '') . '.'];
        elseif ($woOut || $stage === 'ordered') $dl = ['vendor', 'At the vendor', $woOut ? ': work order ' . $woOut[0]['wo_no'] . ', ' . lcfirst(WorkOrders::STATUS[$woOut[0]['status']] ?? $woOut[0]['status']) . '.' : '.'];
        else $dl = ['not_started', 'Not started', $pickup ? ': it\'s picked up at our shop once it\'s made.' : ': no work order yet.'];
        $delivery = ['key' => $dl[0], 'word' => $dl[1], 'sentence' => $dl[2]];   // the sentence carries on from the word ("Ready for pickup" + " at our shop.")

        // ---- Money (§3.2) ----
        $left = max(0, $total - $paid); $due = 0;
        $dep = $o['pay_mode'] === 'deposit' && (int) ($o['deposit_cents'] ?? 0) > 0 ? (int) $o['deposit_cents'] : 0;
        $released = $left > 0 && self::overridden($pdo, $oid);
        $byHand = ($o['invoice_no'] ?? '') !== '' && empty($o['invoice_id']) ? ' Its QuickBooks invoice ' . $o['invoice_no'] . ' was made by hand.' : '';
        if ($st === 'void') $mn = ['none', 'Nothing owed', '', 'The order was cancelled.'];
        elseif (in_array($st, ['draft', 'sent'], true)) $mn = ['not_due', 'Not due yet', '', 'Nothing is owed until the client approves.'];
        elseif ($dispute) $mn = ['disputed', 'Disputed', Orders::usd((int) $m['disputed']), 'The card holder disputed ' . Orders::usd((int) $m['disputed']) . ' with their bank.'];
        elseif ($st === 'refunded') $mn = ['refunded', 'Refunded', Orders::usd((int) $m['refunded']), Orders::usd((int) $m['refunded']) . ' went back to the client.'];
        elseif ($left <= 0) $mn = $st === 'part_refunded' ? ['part_refunded', 'Part refunded', Orders::usd((int) $m['refunded']) . ' back', 'Paid; ' . Orders::usd((int) $m['refunded']) . ' went back to the client.'] : ['paid', 'Paid', '', Orders::usd($paid) . ' received, in full.'];
        elseif ($released) { $due = $left; $mn = ['released', Orders::usd($left) . ' owed', 'released before payment', 'Released before payment by an admin' . (($r = self::releasedAt($pdo, $oid)) ? ' on ' . $day($r) : '') . '.' . $byHand]; }
        elseif ($dep && $paid < $dep) { $due = $dep - $paid; $mn = ['deposit_due', Orders::usd($due) . ' deposit due', (int) ($o['deposit_pct'] ?? 0) > 0 ? (int) $o['deposit_pct'] . '% of the total' : 'cost + ' . self::DEPOSIT_MARKUP . '%', 'Due before production; ' . Orders::usd($left) . ' in all.' . $byHand]; }
        elseif ($dep && !$out) $mn = ['deposit_paid', 'Deposit paid', Orders::usd($paid) . ' · ' . Orders::usd($left) . ' to come', Orders::usd($paid) . ' paid; ' . Orders::usd($left) . ' is due before delivery.' . $byHand];
        else { $due = $left; $mn = ['balance_due', Orders::usd($left) . ' owed', $paid > 0 ? Orders::usd($paid) . ' paid' : '', trim(($paid > 0 ? Orders::usd($paid) . ' paid of ' . Orders::usd($total) . '.' : 'Due now.') . $byHand)]; }
        // past due: a due date set, or Net terms run out (Due on receipt has no later date to be past)
        $pastDue = $due > 0 && (!empty($o['due_date']) || ($o['due_terms'] ?? 'receipt') !== 'receipt') && ($dd = strtotime(self::dueDate($o))) && $dd < strtotime(date('Y-m-d'));
        if ($pastDue) $mn[2] = trim($mn[2] . ($mn[2] !== '' ? ' · ' : '') . 'past due');
        $money = ['key' => $mn[0], 'word' => $mn[1], 'sub' => $mn[2], 'sentence' => $mn[3], 'left' => $left, 'due' => $due, 'past_due' => $pastDue];

        // ---- Order (§3.1) ----
        $changes = false; foreach ($lines as $l) { $pv = (array) ($l['proofs'] ?? []); if ($pv && (string) end($pv)['status'] === 'changes') $changes = true; }
        $changes = $changes || ($st === 'sent' && ($o['review'] ?? '') === 'changes');
        $relMet = $paid >= self::releaseAt($o) || self::overridden($pdo, $oid) || ($o['pay_mode'] ?? '') === 'outside';
        if ($st === 'void') $or = ['cancelled', 'Cancelled', '', 'Stopped before production.'];
        elseif ($stage === 'complete') $or = ['complete', 'Complete', $day($o['updated_at'] ?? ''), ($received ? 'The client confirmed they have it on ' . $day($o['received_at']) . '; ' : '') . 'it\'s in the archive.'];
        elseif ($st === 'refunded') $or = ['refunded', 'Refunded', '', 'Closed: the money went back to the client.'];
        elseif ($st === 'draft') $or = ['draft', 'Draft', 'started ' . $day($o['created_at'] ?? ''), 'Being built; the client hasn\'t seen it.'];
        elseif ($st === 'sent' && self::expired($o)) $or = ['expired', 'Link expired', 'sent ' . $day($o['sent_at'] ?? ''), 'Sent ' . $day($o['sent_at'] ?? '') . '; its link ran out on ' . $day($o['expires_at']) . ' before the client approved.'];
        elseif ($changes) { $v = 0; $at = ''; foreach ($lines as $l) foreach ((array) ($l['proofs'] ?? []) as $p) if ($p['status'] === 'changes') { $v = max($v, (int) ($p['version'] ?? 1)); $at = (string) ($p['decided_at'] ?? ''); }
            $or = ['changes', 'Changes asked', trim(($v ? 'proof v' . $v : '') . ($at !== '' ? ' · ' . $ago($at) : ''), ' ·'), 'The client asked for a change on a proof' . ($v ? ' (v' . $v . ')' : '') . '.']; }
        elseif ($st === 'sent') { $op = self::opens($pdo, $oid); $or = ['client', 'With the client', 'sent ' . $day($o['sent_at'] ?? ''), 'Sent ' . $day($o['sent_at'] ?? '') . ' to ' . $o['bill_email'] . '; ' . ($op['last'] ? 'they opened it ' . $day($op['last']) : 'they haven\'t opened it yet') . '.']; }
        elseif ($out) { $since = self::outSince($pdo, $oid); $or = ['door', 'Out the door', ($pickup ? 'ready since ' : 'out since ') . $day($since ?: ($o['updated_at'] ?? '')), $received ? 'Delivered on ' . $day($o['received_at']) . ($left > 0 ? '; it completes once the balance is settled.' : '.') : ($pickup ? 'Ready for pickup' : 'Shipped') . ($since ? ' since ' . $day($since) : '') . '; the client was asked to tell us they have it.']; }
        elseif ($woOut || $stage === 'ordered') $or = ['production', 'In production', $woOut ? 'with ' . $woOut[0]['vendor'] : '', 'The work order is with the vendor' . ($woOut ? ' (' . $woOut[0]['vendor'] . ')' : '') . '.'];
        else $or = ['approved', 'Approved', $ago($o['approved_at'] ?? ''), 'The client approved it ' . $day($o['approved_at'] ?? '') . ($relMet ? '; it\'s staged for production.' : '; production waits for the payment.')];
        $order = ['key' => $or[0], 'word' => $or[1], 'sub' => $or[2], 'sentence' => $or[3]];

        // ---- Next step (§3.4): the first that applies ----
        $pay = $u . '#payhold';
        if ($closed) $nx = null;   // complete, cancelled or refunded: nothing to do (a reorder starts from the order's Duplicate)
        elseif ($dispute) $nx = $next('Answer the dispute', '/admin/order.php?id=' . $oid);
        elseif ($due > 0 && ($out || $pastDue)) $nx = $next('Collect the balance', $pay, '', 'us', $received ? 'Delivered, balance due' : '');
        elseif ($or[0] === 'draft') $nx = $next('Finish and send', $u . '#lines');
        elseif ($or[0] === 'expired') $nx = $next('Send it again', '', 'resend');
        elseif ($or[0] === 'changes') $nx = $next('Upload the new proof', $u . '#lines');
        elseif ($or[0] === 'client') $nx = $next('Send a reminder', '', 'resend', 'client', 'Waiting on the client');
        elseif ($due > 0) $nx = $next('Take a payment', $pay);
        elseif ($or[0] === 'approved') $nx = $deliv ? $next('Send the work order', $u . '#work') : $next('Complete the order', $u . '#finish');
        elseif ($or[0] === 'production') $nx = $next('Follow the work order', $u . '#work', '', 'vendor', 'With the vendor');
        elseif ($or[0] === 'door') $nx = $next('Complete the order', $u . '#finish', '', 'client', $received ? '' : 'Waiting on the client to say they have it');
        else $nx = $next('Open', $u);
        $tile = $closed ? 'done' : (($nx['who'] ?? '') === 'us' ? 'needs' : ['client' => 'client', 'production' => 'production', 'door' => 'door'][$or[0]] ?? 'needs');
        return ['order' => $order, 'money' => $money, 'delivery' => $delivery, 'next' => $nx, 'tile' => $tile, 'open' => !$closed];
    }

    /** When an admin released it before payment (its 'released' event), or ''. */
    public static function releasedAt(PDO $pdo, int $oid): string
    {
        $st = $pdo->prepare("SELECT MIN(created_at) FROM order_events WHERE order_id = ? AND event = 'released'"); $st->execute([$oid]);
        return (string) ($st->fetchColumn() ?: '');
    }

    /**
     * The order is done (Jason, 2026-10-30): its stage is Complete, every item that isn't cancelled is Complete, and it
     * moves to the archive (Order management → Completed). The client confirming they have it completes it (confirmReceived());
     * our team can too ("Complete the order" in the command strip). $what: what was still open, for the history. The
     * client gets a thank-you with a link to reorder (priced at today's rates) and, if they haven't yet, to tell us how it
     * went. Its art stays in the Collateral Center for the reorder.
     */
    public static function complete(PDO $pdo, int $oid, ?int $staff, array $what = []): void
    {
        self::setStage($pdo, $oid, 'complete', '', $staff, $what ? '(completed with ' . implode(', ', $what) . ')' : '', false);
        if (self::hasItems($pdo)) $pdo->prepare("UPDATE order_lines SET item_status = 'complete' WHERE order_id = ? AND product <> 'shipping' AND COALESCE(item_status, '') NOT IN ('cancelled', 'archived', 'deactivated', 'deleted')")->execute([$oid]);
        $o = Orders::get($pdo, $oid); if (!$o) return;
        $told = self::hasReceived($pdo) && array_filter(self::feedback($pdo, $oid), fn ($f) => $f['kind'] === 'review');
        $first = trim((string) strtok(preg_replace('/^TEST · /u', '', (string) $o['bill_name']), ' '));
        self::mail($o, 'Thank you for your order #' . Orders::no($o), 'Hello ' . ($first !== '' ? $first : $o['bill_name']) . ",\n\nOrder #" . Orders::no($o) . ' is complete. Thank you for working with us.'
            . ($told ? '' : "\n\nHow did it go? Tell us in a minute (a few stars and a word or two):\n" . self::url($o) . '#feedback')
            . "\n\nWhen you need more, reorder it here: the same art, or with changes, at today's prices. We'll send you the order to look over before anything is made.\n" . self::url($o) . '#reorder');
    }

    /** Asked in the shipped and ready emails, and on the order page. */
    public const GOT_IT_ASK = 'When you have it, tell us here, and how it went:';

    public static function hasReceived(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT received_at FROM orders LIMIT 0'); $pdo->query('SELECT 1 FROM order_feedback LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }

    /** The items that count toward delivery: printed and made things, not shipping, GO Codes or anything set aside. */
    private static function deliverables(array $o, array $lines): array
    {
        return array_values(array_filter($lines, fn ($l) => !in_array($l['product'], ['shipping', 'go_code'], true) && !in_array($l['status'], ['cancelled', 'refunded'], true)
            && !in_array(self::itemStatus($o, $l), ['cancelled', 'archived', 'deactivated', 'deleted'], true)));
    }

    /** Is all of it on its way or there (shipped, in route, delivered, ready for pickup)? Then the client can confirm they have it. */
    public static function outTheDoor(PDO $pdo, array $o, ?array $lines = null): bool
    {
        if (!in_array($o['status'], ['pending', 'paid', 'part_refunded'], true) || ($o['stage'] ?? '') === 'complete') return false;
        if (!self::hasItems($pdo)) return in_array((string) ($o['stage'] ?? ''), ['shipped', 'ready'], true);
        $d = self::deliverables($o, $lines ?? Orders::lines($pdo, (int) $o['id']));
        if (!$d) return false;
        foreach ($d as $l) if (!in_array(self::itemStatus($o, $l), ['shipped', 'in_route', 'delivered', 'ready'], true) && !in_array((string) ($o['stage'] ?? ''), ['shipped', 'ready'], true)) return false;
        return true;
    }

    /** What the client has told us about an order, newest first: reviews (stars, words, may we quote) and problems. */
    public static function feedback(PDO $pdo, int $oid): array
    {
        if (!self::hasReceived($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM order_feedback WHERE order_id = ? ORDER BY id DESC'); $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * The client has it (Jason, 2026-10-30: "once confirmed delivered it is considered complete"): when, what they thought
     * of it (optional), and the order completes. Our team hears, with their stars and words.
     * With money still owed (decisions/0178 §6, Jason, 2026-11-23: "should prompt the admin to address balance, if
     * received, mark paid, if not, collect... override with reason, then proceed"): the delivery and their words are kept
     * and they're thanked, but the order doesn't complete. It's Delivered, balance due: our team's task (the board's row,
     * the order page's Money line, the Pulse) is to record the payment, collect it, or an admin's override with a reason;
     * once it's paid (received()) or overridden (completeOwed()), it completes as here.
     */
    public static function confirmReceived(PDO $pdo, array $o, int $rating, string $words, bool $quote): void
    {
        if (!self::hasReceived($pdo)) throw new RuntimeException('That isn\'t ready yet. Reply to our email instead.');
        if (($o['stage'] ?? '') === 'complete') throw new RuntimeException('This order is already complete. Thank you!');
        if (!empty($o['received_at'])) throw new RuntimeException('You told us you have it on ' . date('F j', strtotime((string) $o['received_at'])) . '. Thank you!');
        if (!self::outTheDoor($pdo, $o)) throw new RuntimeException('Not everything is on its way yet: we\'ll email you when it is.');
        $oid = (int) $o['id'];
        $pdo->prepare('UPDATE orders SET received_at = NOW() WHERE id = ?')->execute([$oid]);
        $said = self::saveFeedback($pdo, $oid, 'review', $rating, $words, $quote);
        Orders::event($pdo, $oid, 'received', 'The client confirmed they have it' . ($said !== '' ? ': ' . $said : ''), null);
        if (($hold = self::completeHold($pdo, $o)) !== '') {   // 0178 §6: delivered, balance due; it waits for our team
            $owed = (string) strtok($hold, ':');
            Orders::event($pdo, $oid, 'delivered_owed', 'Delivered, balance due: ' . $owed, null);
            self::mailStaff($pdo, $o, 'Delivered, balance due: order #' . Orders::no($o) . ($rating ? ' ' . str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) : ''),
                $o['bill_name'] . ' confirmed they have order #' . Orders::no($o) . ', with ' . $owed . '. It stays open until that\'s settled: if the money came in, record the payment; if not, collect the balance; or an admin can complete it with a reason.'
                . ($said !== '' ? "\n\nThey said: " . $said : '') . "\n\n" . rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/backoffice/orders/' . $oid . '#payhold');
            return;
        }
        $what = []; foreach (self::openBeforeComplete($pdo, $o, Orders::money($pdo, $oid)['paid']) as $w) if (!str_contains($w, 'not shipped')) $what[] = $w;
        self::complete($pdo, $oid, null, $what);
        self::mailStaff($pdo, $o, 'Received: order #' . Orders::no($o) . ($rating ? ' ' . str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) : ''),
            $o['bill_name'] . ' confirmed they have order #' . Orders::no($o) . '. It\'s complete and in the archive.' . ($said !== '' ? "\n\nThey said: " . $said : '') . ($what ? "\n\nStill open: " . implode('; ', $what) . '.' : ''));
    }

    /**
     * Our team knows it arrived (the Design reviewer on M1, 2026-11-23: "aged items raise their own question": Ready 21
     * days. Picked up?): the same as the client's "Yes, I have it", recorded by staff. Paid, it completes (the client
     * gets the thank-you); with money owed it's Delivered, balance due (decisions/0178 §6) and can be undone.
     */
    public static function markReceived(PDO $pdo, int $oid, int $staff): string
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || !self::hasReceived($pdo)) throw new RuntimeException('That order isn\'t here.');
        if (($o['stage'] ?? '') === 'complete' || !empty($o['received_at'])) throw new RuntimeException('It\'s already recorded as delivered.');
        if (!self::outTheDoor($pdo, $o)) throw new RuntimeException('Not everything is shipped or ready for pickup yet.');
        $pdo->prepare('UPDATE orders SET received_at = NOW() WHERE id = ?')->execute([$oid]);
        $pick = self::delivery($o, Orders::lines($pdo, $oid)) === 'pickup' || ($o['stage'] ?? '') === 'ready';
        Orders::event($pdo, $oid, 'received', ($pick ? 'Picked up' : 'Delivered') . ': recorded by our team', $staff);
        if (($hold = self::completeHold($pdo, $o)) !== '') { Orders::event($pdo, $oid, 'delivered_owed', 'Delivered, balance due: ' . strtok($hold, ':'), $staff); return 'owed'; }
        self::complete($pdo, $oid, $staff);
        return 'complete';
    }

    /**
     * Edit the delivery (CLAUDE.md #1315: a recorded fact is edited, its old value kept in History): the day it was picked
     * up or delivered. A date that isn't a real day, or is in the future, is refused.
     */
    public static function setReceivedOn(PDO $pdo, int $oid, string $day, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || empty($o['received_at'])) throw new RuntimeException('There\'s no delivery recorded to edit.');
        $t = preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) ? strtotime($day . ' 12:00:00') : false;
        if (!$t || $t > time() + 86400) throw new RuntimeException('Choose the day it was delivered (today or before).');
        $pdo->prepare('UPDATE orders SET received_at = ? WHERE id = ?')->execute([date('Y-m-d H:i:s', $t), $oid]);
        Orders::event($pdo, $oid, 'received_date', 'Delivered on ' . date('M j', $t) . ' (was ' . date('M j', strtotime((string) $o['received_at'])) . ')', $staff);
    }

    /** Undo markReceived() while the order is still open (a delivery recorded by mistake): "not delivered after all". */
    public static function unmarkReceived(PDO $pdo, int $oid, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || empty($o['received_at']) || ($o['stage'] ?? '') === 'complete') throw new RuntimeException('There\'s no delivery to undo here.');
        $pdo->prepare('UPDATE orders SET received_at = NULL WHERE id = ?')->execute([$oid]);
        Orders::event($pdo, $oid, 'received_undone', 'Undone: not delivered yet', $staff);
    }

    /** Remind the client to tell us they have it, now (the got-it reminder, sent by our team). Returns when. */
    public static function remindReceived(PDO $pdo, int $oid, int $staff): string
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || !self::outTheDoor($pdo, $o) || !empty($o['received_at'])) throw new RuntimeException('There\'s nothing to ask the client about yet.');
        $first = trim((string) strtok(preg_replace('/^TEST · /u', '', (string) $o['bill_name']), ' '));
        $at = self::outSince($pdo, $oid) ?: time();
        $ok = self::mail($o, 'Did order #' . Orders::no($o) . ' arrive?', 'Hello ' . ($first !== '' ? $first : $o['bill_name']) . ",\n\nYour order #" . Orders::no($o) . ' ' . (($o['stage'] ?? '') === 'ready' ? 'has been ready for pickup since ' : 'went out ') . date('F j', $at) . '. Do you have it? '
            . "Tell us here (one tap), and how it went:\n" . self::url($o) . "#got-it\n\nIf something isn't right, tell us on the same page and we'll put it right.");
        if (!$ok) throw new RuntimeException('The email didn\'t go to ' . $o['bill_email'] . '. Copy the client\'s link from ☰ → What the client sees.');
        Orders::event($pdo, $oid, 'got_it_reminder', 'Reminded the client to tell us they have it', $staff);
        return date('M j');
    }

    /** Ask the client to pay what's owed (decisions/0178 §6's "collect the balance"): an email with the amount and their link. */
    public static function askToPay(PDO $pdo, int $oid, int $staff): string
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] !== 'pending') throw new RuntimeException('Nothing is owed on this order.');
        $left = max(0, (int) $o['total_cents'] - Orders::money($pdo, $oid)['paid']);
        if ($left <= 0) throw new RuntimeException('Nothing is owed on this order.');
        $first = trim((string) strtok(preg_replace('/^TEST · /u', '', (string) $o['bill_name']), ' '));
        $ok = self::mail($o, 'Order #' . Orders::no($o) . ': ' . Orders::usd($left) . ' still to pay', 'Hello ' . ($first !== '' ? $first : $o['bill_name']) . ",\n\n" . Orders::usd($left) . ' is still to pay on order #' . Orders::no($o)
            . ($o['invoice_no'] ? ' (invoice ' . $o['invoice_no'] . ')' : '') . ". You can pay it here:\n" . self::url($o) . "\n\nIf it's already on its way, thank you, and please ignore this.");
        if (!$ok) throw new RuntimeException('The email didn\'t go to ' . $o['bill_email'] . '. Copy the client\'s link from ☰ → What the client sees.');
        Orders::event($pdo, $oid, 'pay_asked', 'Asked the client to pay ' . Orders::usd($left), $staff);
        return date('M j');
    }

    /** When something last happened on an order (its newest event of a kind), as a time, or 0. */
    public static function lastEvent(PDO $pdo, int $oid, string $event): int
    {
        $st = $pdo->prepare('SELECT MAX(created_at) FROM order_events WHERE order_id = ? AND event = ?'); $st->execute([$oid, $event]);
        return ($t = $st->fetchColumn()) ? (int) strtotime((string) $t) : 0;
    }

    /** How long after the last of it went out the door the client is reminded to tell us they have it (Jason, 2026-10-30). */
    public const GOT_IT_REMIND_HOURS = 72;

    /**
     * The reminder (app/scripts/got_it_tick.php, hourly): an order all out the door for 72 hours that the client hasn't
     * confirmed gets one email asking them to (whatever their progress emails setting: it's how the order completes).
     * After that the Pulse asks our team to complete it if they know it arrived. Returns how many were sent.
     */
    public static function gotItTick(PDO $pdo): int
    {
        if (!self::hasReceived($pdo)) return 0;
        $n = 0;
        $st = $pdo->query("SELECT o.* FROM orders o WHERE o.created_by IS NOT NULL AND o.approved_at IS NOT NULL AND o.status IN ('pending','paid','part_refunded') AND COALESCE(o.stage, '') <> 'complete' AND o.received_at IS NULL
            AND NOT EXISTS (SELECT 1 FROM order_events r WHERE r.order_id = o.id AND r.event = 'got_it_reminder') ORDER BY o.id DESC LIMIT 300");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $o) {
            if (!self::outTheDoor($pdo, $o)) continue;
            $at = self::outSince($pdo, (int) $o['id']);
            if (!$at || $at > time() - self::GOT_IT_REMIND_HOURS * 3600 || $at < time() - 30 * 86400) continue;   // older than a month: our team completes it (no late surprise email)
            if (array_filter(self::feedback($pdo, (int) $o['id']), fn ($f) => $f['kind'] === 'problem' && $f['resolved_at'] === null)) continue;   // a ticket open: we're already talking
            $first = trim((string) strtok(preg_replace('/^TEST · /u', '', (string) $o['bill_name']), ' '));
            self::mail($o, 'Did order #' . Orders::no($o) . ' arrive?', 'Hello ' . ($first !== '' ? $first : $o['bill_name']) . ",\n\nYour order #" . Orders::no($o) . ' went out ' . date('F j', $at) . '. Do you have it? '
                . "Tell us here (one tap), and how it went:\n" . self::url($o) . "#got-it\n\nIf something isn't right, tell us on the same page and we'll put it right.");
            Orders::event($pdo, (int) $o['id'], 'got_it_reminder', 'Reminded the client to tell us they have it', null);
            $n++;
        }
        return $n;
    }

    /** When the last of an order went out the door: its newest item status or stage change. */
    public static function outSince(PDO $pdo, int $oid): int
    {
        $st = $pdo->prepare("SELECT MAX(created_at) FROM order_events WHERE order_id = ? AND event IN ('item_status', 'stage')"); $st->execute([$oid]);
        return ($t = $st->fetchColumn()) ? (int) strtotime((string) $t) : 0;
    }

    /** Their stars and words after the order is complete (from the thank-you email), once. */
    public static function review(PDO $pdo, array $o, int $rating, string $words, bool $quote): void
    {
        if (!self::hasReceived($pdo)) throw new RuntimeException('That isn\'t ready yet. Reply to our email instead.');
        if (($o['stage'] ?? '') !== 'complete') throw new RuntimeException('Tell us when you have your order, just above.');
        if (array_filter(self::feedback($pdo, (int) $o['id']), fn ($f) => $f['kind'] === 'review' && ($f['rating'] || trim((string) $f['words']) !== ''))) throw new RuntimeException('We have your thoughts on this order already. Thank you!');
        if (!$rating && trim($words) === '') throw new RuntimeException('Pick the stars, or write a word or two.');
        $said = self::saveFeedback($pdo, (int) $o['id'], 'review', $rating, $words, $quote);
        Orders::event($pdo, (int) $o['id'], 'feedback', 'The client said: ' . $said, null);
        self::mailStaff($pdo, $o, 'Feedback: order #' . Orders::no($o) . ($rating ? ' ' . str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) : ''), $o['bill_name'] . ' said: ' . $said);
    }

    /**
     * Something isn't right with what arrived: it opens a support ticket (a case in the Pulse, Jason 2026-10-30) with what
     * they wrote; our team hears at once and replies from the case; the client gets the ticket number. The order stays
     * open until the ticket is resolved (in the Pulse, or Mark resolved on the order). Returns the ticket number.
     */
    public static function problem(PDO $pdo, array $o, string $words): int
    {
        if (!self::hasReceived($pdo)) throw new RuntimeException('That isn\'t ready yet. Reply to our email instead.');
        if (trim($words) === '') throw new RuntimeException('Tell us what isn\'t right.');
        if (!in_array($o['status'], ['pending', 'paid', 'part_refunded'], true)) throw new RuntimeException('Reply to our email and we\'ll look into it.');
        $said = self::saveFeedback($pdo, (int) $o['id'], 'problem', 0, $words, false);
        $fid = (int) $pdo->lastInsertId();
        require_once __DIR__ . '/Pulse.php';
        $no = 0; try { $no = Pulse::openTicket($pdo, 'fb:' . $fid, 'From ' . $o['bill_name'] . ', about order #' . Orders::no($o) . ': ' . trim($words)); } catch (Throwable $x) { error_log('order ticket: ' . $x->getMessage()); }
        Orders::event($pdo, (int) $o['id'], 'problem', ($no ? 'Support ticket #' . $no . ': ' : '') . 'the client says something isn\'t right: ' . $said, null);
        self::mailStaff($pdo, $o, 'Support ticket' . ($no ? ' #' . $no : '') . ': order #' . Orders::no($o), $o['bill_name'] . ' says something isn\'t right with order #' . Orders::no($o) . ":\n\n" . $said
            . "\n\nReply to them from the case in the Pulse: " . rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/pulse/stream#case=' . rawurlencode('fb:' . $fid) . "\nResolve it there when it's put right.");
        $first = trim((string) strtok(preg_replace('/^TEST · /u', '', (string) $o['bill_name']), ' '));
        self::mail($o, 'We have your note about order #' . Orders::no($o) . ($no ? ' (ticket #' . $no . ')' : ''), 'Hello ' . ($first !== '' ? $first : $o['bill_name']) . ",\n\nThank you for telling us. We're sorry something isn't right with order #" . Orders::no($o) . '. ' . ($no ? 'Your ticket number is ' . $no . '. ' : '')
            . "We'll be in touch soon to put it right.\n\nWhat you told us:\n" . trim($words) . "\n\nYour order:\n" . self::url($o));
        return $no;
    }

    /** A client's ticket, put right (from the order page; the same as resolving its case in the Pulse). */
    public static function resolveProblem(PDO $pdo, int $oid, int $id, int $staff): void
    {
        $st = $pdo->prepare("SELECT id FROM order_feedback WHERE id = ? AND order_id = ? AND kind = 'problem'"); $st->execute([$id, $oid]);
        if (!$st->fetchColumn()) throw new RuntimeException('That ticket isn\'t on this order.');
        require_once __DIR__ . '/Pulse.php';
        if (Pulse::ready($pdo)) Pulse::mark($pdo, 'fb:' . $id, 'done', $staff);
        $pdo->prepare('UPDATE order_feedback SET resolved_at = COALESCE(resolved_at, NOW()) WHERE id = ?')->execute([$id]);
        $no = Pulse::caseNo($pdo, 'fb:' . $id);
        Orders::event($pdo, $oid, 'problem', ($no ? 'Support ticket #' . $no : 'The client\'s problem') . ' marked resolved', $staff);
    }

    private static function saveFeedback(PDO $pdo, int $oid, string $kind, int $rating, string $words, bool $quote): string
    {
        $rating = max(0, min(5, $rating)); $words = mb_substr(trim($words), 0, 2000);
        if (!$rating && $words === '' && $kind === 'review') return '';
        $pdo->prepare('INSERT INTO order_feedback (order_id, kind, rating, words, may_quote) VALUES (?, ?, ?, ?, ?)')->execute([$oid, $kind, $rating ?: null, $words, $quote && $words !== '' ? 1 : 0]);
        return trim(($rating ? str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) . ' ' : '') . ($words !== '' ? '"' . $words . '"' : '') . ($quote && $words !== '' ? ' (we may quote it)' : ''));
    }

    // ---- the client ----------------------------------------------------------------------------------------------------------

    /** The client approves a proof, or asks for changes (with what to change). */
    /**
     * The final-approval terms a client accepts to approve a proof (Jason, 2026-10-28): shown in the approval pop-up,
     * ticked and initialled there, checked again here. Changing the wording: change PROOF_TERMS_V too, so the record says
     * which wording each approval was given under.
     */
    public const PROOF_TERMS_V = '2026-10-28';
    public const PROOF_TERMS = [
        ['100% Client Responsibility', 'The client assumes 100% responsibility for the proof and its final state. This includes, but is not limited to, the verification of all layout, design, text, spelling, grammar, colors, dimensions, and resolution.'],
        ['All Sales Are Final', 'Once this proof is approved, it is automatically sent to production. No further changes, modifications, or cancellations can be made.'],
        ['Error Liability', 'Jason DeGraff, and company, is not liable for any errors, typos, or design oversight discovered after this approval is submitted. Reprints due to uncorrected errors on approved proofs will be billed at the client\'s expense.'],
    ];
    public const PROOF_CHECKS = [
        'I have thoroughly reviewed the artwork proof and verify that all information, layout, and spelling are correct.',
        'I understand that this approval is final, and no further changes can be made once submitted.',
    ];

    /**
     * Our team looking at a real order's client page (Open as the client, or the emailed link): it shows exactly what the
     * client sees, but nothing on it acts for them: approving, paying, changes and wire details are theirs alone. Staff act
     * for a client from the order in Back-Office (Approve for the client, Confirm received). Sandbox orders stay usable,
     * and a staff member's own order is theirs to act on (Jason, 2026-10-28).
     */
    public static function staffView(PDO $pdo, array $o): bool
    {
        if (Orders::isTest($o)) return false;
        require_once __DIR__ . '/QuickBooksPay.php';
        if (!QuickBooksPay::staffHere($pdo)) return false;
        $u = Auth::currentUser();
        return !((int) ($o['user_id'] ?? 0) > 0 && (int) ($o['user_id'] ?? 0) === (int) $u['id'])
            && strcasecmp((string) $u['email'], (string) ($o['bill_email'] ?? '')) !== 0;
    }

    public const STAFF_VIEW_MSG = 'You\'re viewing a real order as the client sees it, so approving, paying and changes are turned off here. To act for the client, use this order in Back-Office.';

    public static function hasSignoff(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT client_initials FROM order_proofs LIMIT 0'); $r = true; } catch (Throwable $x) { $r = false; } } return $r; }

    /** $sign (a client approving): ['checks' => [1, 1], 'initials' => 'JD'], the terms accepted and initialled. */
    public static function decideProof(PDO $pdo, array $o, int $pid, bool $ok, string $note, ?array $sign = null): void
    {
        if ($o['status'] !== 'sent' || self::expired($o)) throw new RuntimeException('This order can\'t be changed now.');
        $p = self::proof($pdo, (int) $o['id'], $pid);
        if (!$p || !in_array($p['status'], ['waiting', 'approved', 'changes'], true)) throw new RuntimeException('That proof has been replaced: refresh the page.');
        $note = mb_substr(trim($note), 0, 1000);
        if (!$ok && $note === '') throw new RuntimeException('Say what to change.');
        if (($p['kind'] ?? 'proof') === 'final') throw new RuntimeException('That file isn\'t a proof.');
        $ini = '';
        if ($ok && $sign !== null) {   // the final-approval terms: both boxes ticked and initialled (the pop-up asks; this makes sure)
            $checks = (array) ($sign['checks'] ?? []);
            foreach (array_keys(self::PROOF_CHECKS) as $i) if (empty($checks[$i])) throw new RuntimeException('Tick both boxes to approve the proof.');
            $ini = strtoupper(trim(preg_replace('/[^\p{L}.\- ]/u', '', (string) ($sign['initials'] ?? ''))));
            if (mb_strlen(str_replace(['.', ' ', '-'], '', $ini)) < 2 || mb_strlen($ini) > 12) throw new RuntimeException('Enter your initials to confirm.');
        }
        $pdo->prepare("UPDATE order_proofs SET status = ?, client_note = ?, decided_at = NOW() WHERE line_id = ? AND version = ? AND status <> 'replaced'" . (self::hasProjects($pdo) ? " AND kind = 'proof'" : ''))->execute([$ok ? 'approved' : 'changes', $ok ? '' : $note, (int) $p['line_id'], (int) $p['version']]);   // the whole version, all its files
        if ($ini !== '' && self::hasSignoff($pdo)) $pdo->prepare("UPDATE order_proofs SET client_initials = ?, client_ip = ? WHERE line_id = ? AND version = ? AND status = 'approved'")->execute([$ini, mb_substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45), (int) $p['line_id'], (int) $p['version']]);
        $line = self::line($pdo, (int) $o['id'], (int) $p['line_id']);
        $open = (int) $pdo->query("SELECT COUNT(*) FROM order_proofs WHERE order_id = " . (int) $o['id'] . " AND status = 'changes'")->fetchColumn();
        $pdo->prepare('UPDATE orders SET review = ? WHERE id = ?')->execute([$open ? 'changes' : '', (int) $o['id']]);
        Orders::event($pdo, (int) $o['id'], $ok ? 'proof_approved' : 'changes_requested', $line['title'] . ' v' . $p['version'] . ($ok ? ($ini !== '' ? ': final approval initialled ' . $ini . ' under the terms of ' . self::PROOF_TERMS_V . (($_SERVER['REMOTE_ADDR'] ?? '') !== '' ? ' from ' . $_SERVER['REMOTE_ADDR'] : '') : '') : ': ' . $note), null, (int) $line['id']);
        if (!$ok) self::mailStaff($pdo, $o, 'Changes requested: order #' . Orders::no($o), $o['bill_name'] . ' asked for changes to ' . $line['title'] . ' (proof v' . $p['version'] . "):\n\n" . $note);
    }

    /**
     * The client approves the order: every proof approved, their name, and the billing address (sales tax depends on
     * it). The QuickBooks invoice is made now. Returns the order.
     */
    public static function approve(PDO $pdo, array $o, string $name, array $bill, ?int $byStaff = null): array
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $oid = (int) $o['id'];
        $outside = $o['pay_mode'] === 'outside';
        if (!($o['status'] === 'sent' || ($byStaff && $o['status'] === 'draft'))) throw new RuntimeException($o['status'] === 'pending' ? 'This order is already approved.' : 'This order can\'t be approved now.');
        if (!$byStaff && self::expired($o)) throw new RuntimeException('This order\'s link has expired. Ask us to send it again.');
        $have = array_filter(Orders::lines($pdo, $oid), fn ($l) => ($l['status'] ?? '') !== 'cancelled' && (int) $l['qty'] > 0);
        if (!$have) throw new RuntimeException($byStaff ? 'This order has no items: add one before it\'s approved.' : 'This order has no items yet: we\'ll email you when it\'s ready to approve.');
        if ($gaps = self::proofGaps($pdo, Orders::lines($pdo, $oid))) throw new RuntimeException($byStaff ? self::proofGapText($gaps) : 'We\'re still preparing a proof for an item on this order: we\'ll email you when it\'s ready to approve.');
        $wait = (int) $pdo->query("SELECT COUNT(*) FROM order_proofs WHERE order_id = $oid AND status IN ('waiting', 'changes')")->fetchColumn();
        if ($wait && !$byStaff) throw new RuntimeException('Approve each proof first' . ($o['review'] === 'changes' ? ' (we\'re working on the changes you asked for)' : '') . '.');
        $name = mb_substr(trim($name), 0, 120);
        if ($name === '') throw new RuntimeException($byStaff ? 'Type who approved it (the client\'s name).' : 'Type your name to approve.');
        $b = ['name' => (string) $o['bill_name'], 'email' => (string) $o['bill_email']];
        if ($byStaff && trim((string) ($bill['street'] ?? '')) === '') foreach (['street', 'city', 'state', 'zip'] as $k) $bill[$k] = (string) ($o['bill_' . $k] ?? '');   // our team approving: the order's Bill to
        foreach (['street' => 160, 'city' => 80, 'state' => 40, 'zip' => 12] as $k => $max) $b[$k] = mb_substr(trim((string) ($bill[$k] ?? '')), 0, $max);
        $hasBill = $b['street'] !== '' || $b['city'] !== '' || $b['zip'] !== '';
        if ((!$outside || $hasBill) && (!preg_match('/^\d{5}(-\d{4})?$/', $b['zip']) || $b['street'] === '' || $b['city'] === '' || $b['state'] === '')) throw new RuntimeException($byStaff && !$outside ? 'Fill in Bill to (street, town, state, ZIP) first: the invoice\'s sales tax comes from it.' : ($outside ? 'Finish the billing address, or leave it empty.' : 'Add your billing address: sales tax depends on it.'));
        if (!empty($o['promo_id'])) { require_once __DIR__ . '/Promotions.php'; self::applyPromo($pdo, $o); $o = Orders::get($pdo, $oid); }   // its code, off the prices now
        $lines = Orders::lines($pdo, $oid);
        $ship = self::shipFrom($o, $lines, $bill, $b);   // [] when it isn't shipped
        if (!$outside && ($why = self::cantInvoice($pdo, $o)) !== '') {   // said to our team as it is; the client hears approving opens soon, and we're told
            if (!$byStaff) { Orders::event($pdo, $oid, 'approve_failed', $why); self::mailStaff($pdo, $o, 'Couldn\'t approve: order #' . Orders::no($o), 'The client tried to approve order #' . Orders::no($o) . ' and couldn\'t: ' . $why); }
            throw new RuntimeException($byStaff ? $why : 'Approving opens soon: we\'ve been told and will email you. Nothing was charged.');
        }
        // several addresses: QuickBooks taxes an invoice for its one Ship to, so until one invoice per address is built
        // (decisions/0177), such an order isn't invoiced for the wrong place; each address goes as its own order
        if (!$outside && ($n = count(self::shipTos($pdo, $o, Orders::lines($pdo, $oid)))) > 1) {
            $why = 'This order ships to ' . $n . ' addresses, and QuickBooks taxes an invoice for one. Until one invoice per address is built, press Split into one order per address (at the top of this order), so each is taxed for where it goes. Nothing was charged.';
            if (!$byStaff) { Orders::event($pdo, $oid, 'approve_failed', $why); self::mailStaff($pdo, $o, 'Couldn\'t approve: order #' . Orders::no($o), 'The client tried to approve order #' . Orders::no($o) . ': ' . $why); }
            throw new RuntimeException($byStaff ? $why : 'We need to split this order by address before you approve it: we\'ve been told and will email you. Nothing was charged.');
        }
        if ($byStaff && $wait) $pdo->prepare("UPDATE order_proofs SET status = 'approved', decided_at = NOW() WHERE order_id = ? AND status IN ('waiting', 'changes')")->execute([$oid]);
        $pdo->prepare('UPDATE orders SET bill_street = ?, bill_city = ?, bill_state = ?, bill_zip = ? WHERE id = ?')->execute([$b['street'], $b['city'], strtoupper($b['state']), $b['zip'], $oid]);
        if ($ship) $pdo->prepare('UPDATE orders SET ship_name = ?, ship_street = ?, ship_city = ?, ship_state = ?, ship_zip = ? WHERE id = ?')->execute([$ship['name'], $ship['street'], $ship['city'], strtoupper($ship['state']), $ship['zip'], $oid]);
        $who = $byStaff ? ' (recorded by our team)' : '';
        if ($outside) {   // no QuickBooks invoice: the total is the lines (add a tax line if it's owed); our team records each payment
            $total = (int) $o['subtotal_cents'];
            $pdo->prepare("UPDATE orders SET status = 'pending', approved_at = NOW(), approved_name = ?, tax_cents = 0, total_cents = ?, deposit_cents = 0, items = ?, stage = ?, review = '' WHERE id = ?")
                ->execute([$name . $who, $total, count($lines), '', $oid]);   // on a payment hold: the payment recorded releases it to production (or Release now)
            $pdo->prepare('UPDATE order_lines SET approved_at = NOW() WHERE order_id = ?')->execute([$oid]);
            Orders::number($pdo, $oid);   // its mode is settled now
        Orders::event($pdo, $oid, 'approved', 'Approved by ' . $name . $who . ': ' . Orders::usd($total) . ', paid outside QuickBooks', $byStaff);
            if (!$byStaff) self::mailStaff($pdo, $o, 'Approved: order #' . Orders::no($o), $name . ' approved order #' . Orders::no($o) . ' (' . Orders::usd($total) . '). It\'s paid outside QuickBooks and on a payment hold: record the payment on the order to release it to production.');
            self::toCollateral($pdo, $oid);
            return Orders::get($pdo, $oid);
        }
        $ql = [];
        foreach ($lines as $l) {
            $p = $l['product'] === 'product' ? Products::get($pdo, (int) $l['product_id']) : null;
            $ql[] = ['title' => $l['title'] . ($l['options'] !== '' ? ' (' . $l['options'] . ')' : '') . ($l['note'] !== '' ? ' — ' . $l['note'] : ''), 'qty' => (int) $l['qty'], 'unit_cents' => (int) $l['unit_cents'], 'product_id' => $p ? (int) $p['id'] : 0,
                     'taxable' => (bool) $l['taxable'], 'item' => $l['product'] === 'go_code' ? QuickBooksPay::ITEM_NAME : ($p ? $p['name'] : ($l['product'] === 'shipping' ? 'Shipping' : 'Custom work')), 'item_desc' => $p ? (string) $p['description'] : 'Custom work for a client order'];
        }
        $sh = self::shipping($pdo, $o);
        if ($sh['cents'] > 0) $ql[] = ['title' => 'Shipping: ' . implode('; ', array_map(fn ($r) => $r['title'] . ' to ' . $r['to'] . ' ' . Orders::usd($r['cents']), $sh['rows'])), 'qty' => 1, 'unit_cents' => $sh['cents'],
                                       'taxable' => false, 'item' => 'Shipping', 'item_desc' => 'Shipping'];
        if (self::taxChoice($o) !== 'taxable') foreach ($ql as &$q) $q['taxable'] = false;   // reseller, exempt or out of state: no line is taxed (decisions/0177 §2)
        unset($q);
        $shipTo = $ship ?: (self::delivery($o, $lines) === 'ship' && ($o['ship_street'] ?? '') !== '' ? ['name' => (string) $o['ship_name'], 'street' => (string) $o['ship_street'], 'city' => (string) $o['ship_city'], 'state' => (string) $o['ship_state'], 'zip' => (string) $o['ship_zip']] : []);
        try {
            $inv = QuickBooksPay::invoiceFor($pdo, $oid, (int) ($o['user_id'] ?? 0), $b, $ql, 'Order #' . Orders::no($o) . ' from Traversence. See it any time: ' . self::url($o), $o['pay_mode'] === 'invoice', $shipTo);
        } catch (Throwable $e) {
            error_log('client order approve: ' . $e->getMessage());
            $why = 'QuickBooks didn\'t make the invoice: ' . mb_substr($e->getMessage(), 0, 200);
            Orders::event($pdo, $oid, 'approve_failed', $why);
            if (!$byStaff) self::mailStaff($pdo, $o, 'Couldn\'t approve: order #' . Orders::no($o), 'The client tried to approve order #' . Orders::no($o) . ' and QuickBooks didn\'t make the invoice: ' . $e->getMessage());
            throw new RuntimeException($byStaff ? $why . '. Nothing was charged.' : 'We couldn\'t finish approving just now: we\'ve been told. Nothing was charged: try again in a few minutes.');
        }
        $total = (int) $inv['total_cents'];
        $dep = $o['pay_mode'] === 'deposit' ? self::depositFor($pdo, $o, $total, $lines)[0] : 0;   // decisions/0177 §3
        $pdo->prepare("UPDATE orders SET status = 'pending', approved_at = NOW(), approved_name = ?, invoice_id = ?, invoice_no = ?, pay_url = ?, tax_cents = ?, total_cents = ?, deposit_cents = ?, qb_customer_id = ?, qb_env = ?, items = ?, stage = ? WHERE id = ?")
            ->execute([$name . $who, $inv['id'], $inv['number'], $inv['pay_url'], $inv['tax_cents'], $total, $dep, $inv['customer_id'] ?? null, QuickBooksPay::env(), count($lines),
                       '', $oid]);   // production waits for payment on every order, invoice later's too (model §0 item 1, 1.9)
        $pdo->prepare('UPDATE order_lines SET approved_at = NOW() WHERE order_id = ?')->execute([$oid]);
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        Orders::number($pdo, $oid);   // its mode is settled now
        Orders::event($pdo, $oid, 'approved', 'Approved by ' . $name . $who . ' (' . $o['bill_email'] . ($ip !== '' && !$byStaff ? ', ' . $ip : '') . '): ' . Orders::usd($total) . ' with tax, invoice ' . $inv['number'], $byStaff);
        self::mailStaff($pdo, $o, 'Approved: order #' . Orders::no($o), $name . ' approved order #' . Orders::no($o) . ' (' . Orders::usd($total) . ' with tax). ' . self::PAY_MODES[$o['pay_mode']] . '.');
        self::toCollateral($pdo, $oid);
        return Orders::get($pdo, $oid);
    }

    /**
     * Why a QuickBooks invoice can't be made for this order now, in words for our team, or '' when it can: not set up,
     * the connection lapsed, or (#7 of the ordering survey) Payments in Sandbox for a real order, which would invoice it in
     * the sandbox and release production on test money.
     */
    public static function cantInvoice(PDO $pdo, array $o): string
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $env = QuickBooksPay::env();
        if ($env === 'mock') return '';
        if (!QuickBooksPay::configured()) return 'Payments isn\'t set up: connect QuickBooks in E-Commerce → Payments. Nothing was charged.';
        if ($env === 'sandbox' && !Orders::isTest($o)) return 'Payments is in Sandbox (testing), and this is a real order: it would be invoiced in the sandbox. Switch E-Commerce → Payments to Production, then approve. Nothing was charged.';
        $c = QuickBooksPay::connection($pdo);
        if (!$c || strtotime((string) $c['refresh_until']) <= time()) return 'QuickBooks isn\'t connected (its sign-in lapsed): reconnect it in E-Commerce → Payments, then approve. Nothing was charged.';
        return '';
    }

    /** The distinct addresses an order ships to: its destinations (manifests), items' own addresses, the order's Ship to. */
    public static function shipTos(PDO $pdo, array $o, array $lines): array
    {
        return array_values(array_map(fn ($g) => $g['text'], self::destinationGroups($pdo, $o, $lines)));
    }

    /**
     * An order's items by where they go: [key => ['text' => the address, 'lines' => [line ids], 'own' => true when the
     * items carry it themselves (not the order's Ship to)]]. The same place written two ways (a name line, commas) is one
     * address: keyed by its house number and ZIP when it has them. Picked-up items, shipping charges and GO Codes go
     * nowhere and stay out. Manifest destinations (Shipments, "multi") are read as their own addresses with no lines.
     */
    public static function destinationGroups(PDO $pdo, array $o, array $lines): array
    {
        $norm = function (string $t): string {
            if (preg_match_all('/\b(\d{5})(?:-\d{4})?\b/', $t, $z) && preg_match('/\b(\d+)\b/', $t, $h) && $h[1] !== end($z[1])) return $h[1] . '-' . end($z[1]);
            return strtolower(preg_replace('/[^a-z0-9]+/i', '', $t));
        };
        $out = [];
        require_once __DIR__ . '/Shipments.php';
        if (Shipments::ready($pdo) && Shipments::mode($o) === 'multi') foreach (Shipments::destinations($pdo, $o) as $d) if (trim((string) $d['street']) !== '') $out[$norm((string) $d['text'])] ??= ['text' => (string) $d['text'], 'lines' => [], 'own' => false, 'manifest' => true];
        $mine = trim(self::shipToText($o), ' ,'); $mineKey = $mine !== '' && trim((string) ($o['ship_street'] ?? '')) !== '' ? $norm($mine) : '';
        foreach ($lines as $l) {
            if (in_array($l['product'], ['shipping', 'go_code'], true) || ($l['status'] ?? '') === 'cancelled' || ($l['ship_style'] ?? '') === 'pickup' || ($l['ship_to'] ?? '') === 'pickup') continue;
            $a = trim((string) ($l['ship_address'] ?? ''));
            if ($a !== '') { $k = $norm($a); $out[$k] ??= ['text' => $a, 'lines' => [], 'own' => $k !== $mineKey]; $out[$k]['lines'][] = (int) $l['id']; }
            elseif ($mineKey !== '') { $out[$mineKey] ??= ['text' => $mine, 'lines' => [], 'own' => false]; $out[$mineKey]['lines'][] = (int) $l['id']; }
        }
        return $out;
    }

    /**
     * Splits an order shipping to several addresses into one order per address (the session manager's condition on
     * release A, 2026-11-23: the refusal carries its way forward). The first address stays on this order; each other
     * address's items move, with their proofs, files and costs, to a new draft for the same client on the same terms.
     * Undone by unsplit(). Manifest destinations (items divided into lots across addresses) can't be split by item:
     * refused with the steps. Returns the new orders' ids.
     */
    public static function split(PDO $pdo, int $oid, int $staff): array
    {
        $o = self::mine($pdo, $oid, true);
        $groups = self::destinationGroups($pdo, $o, Orders::lines($pdo, $oid));
        if (count($groups) < 2) throw new RuntimeException('This order ships to one address: there\'s nothing to split.');
        if (array_filter($groups, fn ($g) => !empty($g['manifest']))) throw new RuntimeException('Its items are divided into lots across destinations (Shipping & manifests), so it can\'t be split by item. For each other destination: Duplicate ▾ → Copy, keep only what goes there, set its Ship to, and take those lots off this order.');
        $keep = array_values(array_filter(['bill_street', 'bill_city', 'bill_state', 'bill_zip', 'pay_mode', 'deposit_pct', 'tax_choice', 'tax_note', 'delivery', 'note', 'po_number', 'due_terms', 'qb_env', 'listing_id'], fn ($c) => Orders::hasCol($pdo, $c)));
        $new = [];
        $pdo->beginTransaction();
        try {
            foreach (array_slice($groups, 1, null, true) as $g) {
                $nid = self::create($pdo, $staff, ['name' => $o['bill_name'], 'email' => $o['bill_email'], 'company' => $o['client_company'], 'phone' => $o['client_phone']]);
                $pdo->prepare('UPDATE orders SET ' . implode(', ', array_map(fn ($c) => "$c = ?", $keep)) . ' WHERE id = ?')->execute(array_merge(array_map(fn ($c) => $o[$c], $keep), [$nid]));
                if (!$g['own']) $pdo->prepare('UPDATE orders SET ship_name = ?, ship_street = ?, ship_city = ?, ship_state = ?, ship_zip = ? WHERE id = ?')->execute([$o['ship_name'], $o['ship_street'], $o['ship_city'], $o['ship_state'], $o['ship_zip'], $nid]);
                if (self::moveLines($pdo, $g['lines'], $oid, $nid) !== count($g['lines'])) throw new RuntimeException('The split didn\'t finish: not every item moved. Nothing was changed.');   // all or nothing
                self::recalc($pdo, $nid);
                Orders::event($pdo, $nid, 'split_from', 'Split from order #' . Orders::no($o) . ': its items going to ' . $g['text'], $staff);
                $new[] = $nid;
            }
            if ($o['status'] === 'sent') foreach ($new as $nid) $pdo->prepare("UPDATE orders SET status = 'draft' WHERE id = ?")->execute([$nid]);   // each goes to the client when our team sends it
            self::recalc($pdo, $oid);
            Orders::event($pdo, $oid, 'split', 'Split by address into ' . implode(', ', array_map(fn ($n) => 'order #' . Orders::no(Orders::get($pdo, $n)), $new)) . ' [' . implode(',', $new) . ']', $staff);
            $pdo->commit();
        } catch (Throwable $x) { $pdo->rollBack(); throw $x; }
        return $new;
    }

    /** The split's new orders while Undo can still put them back (each still a draft or out for review, nothing paid), else []. */
    public static function splitUndoable(PDO $pdo, int $oid): array
    {
        $st = $pdo->prepare("SELECT event, note FROM order_events WHERE order_id = ? AND event IN ('split', 'split_undone') ORDER BY id DESC LIMIT 1"); $st->execute([$oid]);
        $ev = $st->fetch(PDO::FETCH_ASSOC);
        if (!$ev || $ev['event'] !== 'split' || !preg_match('/\[([\d,]+)\]$/', (string) $ev['note'], $m)) return [];
        $ids = array_map('intval', explode(',', $m[1]));
        foreach ($ids as $n) { $c = Orders::get($pdo, $n); if (!$c || !in_array($c['status'], ['draft', 'sent'], true) || Orders::money($pdo, $n)['paid'] > 0) return []; }
        $p = Orders::get($pdo, $oid);
        return $p && in_array($p['status'], ['draft', 'sent'], true) ? $ids : [];
    }

    /** Undo of split(): the new orders' items come back here, and those orders are cancelled (kept, with the reason). */
    public static function unsplit(PDO $pdo, int $oid, int $staff): void
    {
        $ids = self::splitUndoable($pdo, $oid);
        if (!$ids) throw new RuntimeException('The split can\'t be undone now: one of its orders has moved on (sent and approved, or paid). Change them one by one.');
        // what comes back, found first: nothing to move is refused, never an order cancelled and "undone" with nothing moved
        $back = [];
        foreach ($ids as $n) { $st = $pdo->prepare("SELECT id FROM order_lines WHERE order_id = ? AND (status IS NULL OR status <> 'cancelled')"); $st->execute([$n]); $back[$n] = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)); }
        if (!array_sum(array_map('count', $back))) throw new RuntimeException('The split can\'t be undone: its other orders have no items left to bring back. Nothing was changed.');
        // one transaction: every item is moved and checked back here before any order is cancelled; anything short of
        // that rolls it all back and says so (never an order cancelled with its items left behind)
        $pdo->beginTransaction();
        try {
            foreach ($ids as $n) {
                $moved = self::moveLines($pdo, $back[$n], $n, $oid);
                $st = $pdo->prepare("SELECT COUNT(*) FROM order_lines WHERE order_id = ? AND (status IS NULL OR status <> 'cancelled')"); $st->execute([$n]);
                if ($moved !== count($back[$n]) || (int) $st->fetchColumn() > 0) throw new RuntimeException('The split can\'t be undone: ' . ($moved ?: 'none') . ' of the ' . count($back[$n]) . ' items on order #' . Orders::no(Orders::get($pdo, $n)) . ' came back. Nothing was changed.');
            }
            foreach ($ids as $n) {
                $pdo->prepare("UPDATE orders SET status = 'void', note = ? WHERE id = ?")->execute(['Split undone: its items are back on order #' . Orders::no(Orders::get($pdo, $oid)), $n]);
                Orders::event($pdo, $n, 'cancelled', 'Split undone: its items went back to order #' . Orders::no(Orders::get($pdo, $oid)), $staff);
            }
            self::recalc($pdo, $oid);
            Orders::event($pdo, $oid, 'split_undone', 'Split undone: the items of ' . count($ids) . ' order' . (count($ids) === 1 ? '' : 's') . ' are back here', $staff);
            $pdo->commit();
        } catch (PDOException $x) { $pdo->rollBack(); error_log('unsplit ' . $oid . ': ' . $x->getMessage()); throw new RuntimeException('The split can\'t be undone just now: the items couldn\'t be moved back. Nothing was changed.'); }   // the database's own words to the log, plain ones to the page
        catch (Throwable $x) { $pdo->rollBack(); throw $x; }
    }

    /** Items, with their proofs, files and costs, from one order to another (a split or its undo). */
    /** Returns how many items moved (the caller checks it). */
    private static function moveLines(PDO $pdo, array $ids, int $from, int $to): int
    {
        if (!$ids) return 0;
        $in = implode(',', array_map('intval', $ids));
        $st = $pdo->prepare("UPDATE order_lines SET order_id = ? WHERE order_id = ? AND id IN ($in)"); $st->execute([$to, $from]); $moved = $st->rowCount();
        try { $pdo->exec("UPDATE order_lines SET project_id = NULL WHERE id IN ($in)"); } catch (PDOException $e) { /* no projects here */ }   // a project belongs to the order it was made on
        foreach (['order_proofs', 'order_files', 'order_line_costs'] as $t) { try { $pdo->prepare("UPDATE $t SET order_id = ? WHERE order_id = ? AND line_id IN ($in)")->execute([$to, $from]); } catch (PDOException $e) { /* a table this site doesn't have yet */ } }
        return $moved;
    }

    /** The order's sales tax (decisions/0177 §2): taxable, reseller, exempt or out of state; [key => [name, what it means]]. */
    public const TAX_CHOICES = [
        'taxable' => ['Taxable', 'Sales tax on each taxable item, at the rate where it ships (or ours, when picked up)'],
        'reseller' => ['Reseller', 'The client resells it: no sales tax; keep their resale certificate\'s number'],
        'exempt' => ['Exempt', 'The client or the sale is exempt (a nonprofit, a government, an exemption code): no sales tax'],
        'out_of_state' => ['Out of state', 'Shipped out of Arizona: no Arizona sales tax (interstate commerce, deduction 504)'],
    ];
    public static function taxChoice(array $o): string { $t = (string) ($o['tax_choice'] ?? 'taxable'); return isset(self::TAX_CHOICES[$t]) ? $t : 'taxable'; }

    /**
     * Why an approved order can't go back to being edited, or '' when it can (Jason, 2026-10-28: a wrong quantity after
     * approving): approved and waiting for payment, no money recorded, no QuickBooks invoice made here, and no work order
     * with a vendor (a draft one is fine; one that went out is cancelled first, so the vendor is told).
     */
    public static function reopenBlock(PDO $pdo, array $o): string
    {
        if ($o['status'] !== 'pending') return $o['status'] === 'paid' ? 'It\'s paid: change it with Money (credit or refund), or duplicate it.' : 'Only an approved order waiting for payment reopens.';
        if (Orders::money($pdo, (int) $o['id'])['paid'] > 0) return 'A payment is recorded on it: change it with Money (credit or refund).';
        if (!empty($o['invoice_id'])) return 'Its QuickBooks invoice ' . $o['invoice_no'] . ' was made here: change it with Money (credit), or void that invoice in QuickBooks and ask us.';
        try {
            $st = $pdo->prepare("SELECT wo_no FROM order_work_orders WHERE order_id = ? AND COALESCE(status, 'sent') NOT IN ('draft', 'cancelled', 'declined', 'rejected')"); $st->execute([(int) $o['id']]);
            $out = $st->fetchAll(PDO::FETCH_COLUMN);
            if ($out) return 'Work order ' . implode(', ', $out) . ' is with the vendor: cancel it first (they\'re told), then reopen.';
        } catch (Throwable $x) {}
        return '';
    }

    /** Takes an approved order back to editing: not approved, not in production; its proofs stay approved. Approve it again when it's right. */
    public static function reopen(PDO $pdo, array $o, string $why, int $staff): array
    {
        $oid = (int) $o['id'];
        if (($b = self::reopenBlock($pdo, $o)) !== '') throw new RuntimeException($b);
        $to = !empty($o['sent_at']) ? 'sent' : 'draft';
        $pdo->prepare("UPDATE orders SET status = ?, approved_at = NULL, approved_name = '', stage = '' WHERE id = ?")->execute([$to, $oid]);
        $pdo->prepare('UPDATE order_lines SET approved_at = NULL WHERE order_id = ?')->execute([$oid]);
        Orders::event($pdo, $oid, 'reopened', 'Reopened for changes (no longer approved)' . (trim($why) !== '' ? ': ' . mb_substr(trim($why), 0, 300) : ''), $staff);
        return Orders::get($pdo, $oid);
    }

    /** An approved order's pieces into the client's collateral (decisions/0101, addendum 2026-10-28); never stops an approval. */
    private static function toCollateral(PDO $pdo, int $oid): void
    {
        if (!is_file(__DIR__ . '/Collateral.php')) return;
        try { require_once __DIR__ . '/Collateral.php'; Collateral::fromOrder($pdo, $oid); } catch (Throwable $x) { error_log('collateral: ' . $x->getMessage()); }
    }

    /**
     * Every printed item needs a proof before Send or approval (decisions/0101, note of 2026-11-20, B.2), by one of its
     * paths: (1) our proof, for the client to approve; (2) an exact reorder's approved proof (reuse_of), "only when the
     * product's specs and vendor are unchanged". The third path (the client's own file through the order file check, then
     * our proof of it) waits on the check's limits (0176). Returns [item title => what's missing]. The vendor half of
     * (2) is checked once the vendor is chosen before the cart (research/one-cart-proposal-2026-11-20.md).
     */
    public static function proofGaps(PDO $pdo, array $lines): array
    {
        $gaps = [];
        $kq = self::hasProjects($pdo) ? " AND kind = 'proof'" : '';
        foreach ($lines as $l) {
            if (($l['status'] ?? '') === 'cancelled' || self::role($pdo, $l) !== 'print') continue;
            $st = $pdo->prepare("SELECT * FROM order_proofs WHERE line_id = ? AND status <> 'replaced'" . $kq); $st->execute([(int) $l['id']]);
            $ps = $st->fetchAll(PDO::FETCH_ASSOC);
            $title = (string) ($l['title'] ?: 'An item');
            if (!$ps) { $gaps[$title] = 'no proof yet'; continue; }
            foreach ($ps as $p) {
                if (empty($p['reuse_of'])) continue;
                $s = $pdo->prepare('SELECT l.product_id, l.options FROM order_proofs p JOIN order_lines l ON l.id = p.line_id WHERE p.id = ?'); $s->execute([(int) $p['reuse_of']]);
                $src = $s->fetch(PDO::FETCH_ASSOC);
                if ($src && ((int) $src['product_id'] !== (int) $l['product_id'] || self::sameOptions((string) $src['options'], (string) $l['options']) === false))
                    $gaps[$title] = 'its product or options changed since the art was approved, so it needs a fresh proof';
            }
        }
        return $gaps;
    }

    private static function sameOptions(string $a, string $b): bool
    {
        $n = function (string $s) { $j = json_decode($s, true); if (is_array($j)) { ksort($j); return json_encode($j); } return trim($s); };
        return $n($a) === $n($b);
    }

    public static function proofGapText(array $gaps): string
    {
        $out = []; foreach ($gaps as $t => $why) $out[] = $t . ': ' . $why;
        return 'Every printed item needs a proof first (' . implode('; ', $out) . '). Add a proof under the item, or reuse the approved art on an exact reorder.';
    }

    private static function hasPrint(array $lines): bool { return (bool) array_filter($lines, fn ($l) => !in_array($l['product'], ['go_code', 'shipping'], true)); }

    /** The client pays what's due now (the deposit, or the rest) with the card form's one-time token. Returns the order. */
    public static function pay(PDO $pdo, array $o, string $token, ?int $expect = null): array
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $oid = (int) $o['id'];
        if (!preg_match('/^[A-Za-z0-9_.:-]{6,300}$/', $token)) throw new RuntimeException('The card details didn\'t come through. Try again.');
        $lock = $pdo->quote('tv-pay-' . $oid);
        if ((int) $pdo->query("SELECT GET_LOCK($lock, 15)")->fetchColumn() !== 1) throw new RuntimeException('This order is being paid already. Wait a moment.');
        try {
            $row = Orders::get($pdo, $oid);
            if (($row['pay_mode'] ?? '') === 'outside') throw new RuntimeException('This order is paid directly to us, as arranged (cash, check, Zelle…), not by card here. Nothing was charged.');   // no invoice to post a card payment to
            $due = self::dueNow($pdo, $row);
            if ($due <= 0) return $row;
            // the amount the page showed: a second press after the deposit went through, or a total changed since the page
            // opened, is refused rather than charging a different amount than the client agreed to
            if ($expect !== null && $expect !== $due) throw new RuntimeException('The amount due is now ' . Orders::usd($due) . ', not ' . Orders::usd($expect) . ': it changed since this page opened. Nothing was charged. Reload the page to see it, then pay.');
            Orders::sameEnv($row);
            $paidBefore = Orders::money($pdo, $oid)['paid'];
            $st = $pdo->prepare("SELECT COUNT(*) FROM order_events WHERE order_id = ? AND event = 'card_declined'"); $st->execute([$oid]);
            $key = 'pay-' . $oid . '-' . $paidBefore . '-' . (int) $st->fetchColumn();
            try { $charge = QuickBooksPay::chargeCard($pdo, $row, $token, $key, $due); }
            catch (RuntimeException $e) { if (str_contains($e->getMessage(), 'Nothing was charged')) Orders::event($pdo, $oid, 'card_declined', mb_substr($e->getMessage(), 0, 300)); throw $e; }
            $warn = '';
            try { $pdo->prepare('UPDATE orders SET charge_id = ? WHERE id = ?')->execute([$charge, $oid]); } catch (Throwable $e) { $warn = 'Card charge ' . $charge . ' wasn\'t saved on the order. '; }
            try {
                $p = QuickBooksPay::recordCardPayment($pdo, $row, $charge, $key, $due);
                if (!$p['linked']) $warn .= 'QuickBooks took the payment on invoice ' . $row['invoice_no'] . ' but not linked to card charge ' . $charge . '.';
            } catch (Throwable $e) { $warn .= 'The card was charged (' . $charge . ') but QuickBooks didn\'t record the payment on invoice ' . $row['invoice_no'] . ' (' . $e->getMessage() . '): receive it there.'; }
            $isDeposit = $paidBefore + $due < (int) $row['total_cents'];
            self::received($pdo, $oid, $due, $isDeposit ? 'deposit' : 'charge', 'card', 'card ' . $charge, $key);
            if ($warn !== '') Orders::event($pdo, $oid, 'needs_books', $warn);
        } finally { $pdo->query("SELECT RELEASE_LOCK($lock)"); }
        return Orders::get($pdo, $oid);
    }

    /** The invoice was paid in QuickBooks (its page, or recorded there): the rest is recorded and the order goes on. */
    public static function paidInQuickBooks(PDO $pdo, int $oid): void
    {
        if (self::fromQuickBooks($pdo, $oid) !== '') return;
        $o = Orders::get($pdo, $oid);
        if (!$o || $o['status'] !== 'pending') return;
        $left = (int) $o['total_cents'] - Orders::money($pdo, $oid)['paid'];
        if ($left <= 0) return;
        self::received($pdo, $oid, $left, 'charge', 'quickbooks', (string) $o['invoice_no'], 'charge-' . $oid);
    }

    /**
     * What came in on QuickBooks' own invoice page since we last looked, recorded as it arrives (decisions/0101, note of
     * 2026-11-20, B.3): a part payment is a deposit entry in the ledger, the rest a charge once the balance is zero. "A
     * recorded part payment that reaches the required deposit amount releases production as a deposit paid on our site
     * does"; one below it is recorded and waits. Returns what it recorded, in words ('' when nothing new).
     */
    public static function fromQuickBooks(PDO $pdo, int $oid): string
    {
        require_once __DIR__ . '/QuickBooksPay.php';
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] !== 'pending') return '';
        // the card payment's lock (pay()): while a card is being charged here, its payment is recorded by pay(), so this
        // waits and then sees it, rather than recording the same money from QuickBooks' side a second time
        $lock = $pdo->quote('tv-pay-' . $oid);
        if ((int) $pdo->query("SELECT GET_LOCK($lock, 20)")->fetchColumn() !== 1) return '';   // a charge still running: the next look records what's new
        try { return self::fromQuickBooksLocked($pdo, $oid); } finally { $pdo->query("SELECT RELEASE_LOCK($lock)"); }
    }

    private static function fromQuickBooksLocked(PDO $pdo, int $oid): string
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || $o['status'] !== 'pending') return '';
        $s = QuickBooksPay::invoicePaid($pdo, $oid);
        if (!$s || $s['total'] <= 0) return '';
        $o = Orders::get($pdo, $oid);   // its total, as QuickBooks has it now
        $have = Orders::money($pdo, $oid)['paid'];
        $new = min($s['paid'], (int) $o['total_cents']) - $have;
        if ($new <= 0) return '';
        $full = $have + $new >= (int) $o['total_cents'];
        self::received($pdo, $oid, $new, $full ? 'charge' : 'deposit', 'quickbooks', (string) $o['invoice_no'], 'qbpaid-' . $oid . '-' . ($have + $new), true);
        return Orders::usd($new) . ($full ? ', paid in full' : ' received on QuickBooks\' invoice page');
    }

    /** The amount that releases production when it's paid: the deposit on deposit terms, else the whole. */
    public static function releaseAt(array $o): int
    {
        return $o['pay_mode'] === 'deposit' && (int) ($o['deposit_cents'] ?? 0) > 0 ? (int) $o['deposit_cents'] : (int) $o['total_cents'];
    }

    /** Money in: the ledger, then (paid in full) GO Codes issued and printed products into production; the client is emailed. */
    public static function hasItems(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT item_status FROM order_lines LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }

    public static function statusLabel(string $k): string { foreach (self::ITEM_STATUS as $g) if (isset($g[$k])) return $g[$k]; return $k; }

    /** An item's status: its own, else what the order's state implies (before anyone has set one). */
    public static function itemStatus(array $o, array $l): string
    {
        $set = (string) ($l['item_status'] ?? '');
        // a status from before approval ("Pending Approval") doesn't outlast the approval: the order's own state wins
        if ($set !== '' && !(isset(self::ITEM_STATUS['Before approval'][$set]) && !in_array($o['status'], ['draft', 'sent'], true))) return $set;
        if ($o['status'] === 'void') return 'cancelled';
        if ($o['status'] === 'draft') return 'incoming';
        if ($o['status'] === 'sent') return ($o['review'] ?? '') === 'changes' ? 'changes' : 'pending';
        return 'approved';
    }

    /** The invoice number the client sees: TRV-<year>-<order number>. */
    public static function ref(array $o): string { $n = Orders::no($o); return date('Y-md', strtotime((string) ($o['created_at'] ?? 'now'))) . '-' . (Orders::isTest($o) ? 'S' : '') . str_pad(ltrim($n, 'S-'), 5, '0', STR_PAD_LEFT); }

    /** When it's due: from approval (or today, before it) plus the terms. */
    public static function dueDate(array $o): string
    {
        if (!empty($o['due_date'])) return date('M j, Y', strtotime((string) $o['due_date']));   // set directly
        $days = self::DUE_TERMS[$o['due_terms'] ?? 'receipt'][1] ?? 0;
        return date('M j, Y', strtotime((string) ($o['approved_at'] ?: date('Y-m-d'))) + $days * 86400);
    }

    public static function setItemStatus(PDO $pdo, int $oid, int $lineId, string $status, string $tracking, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o)) throw new RuntimeException('That order isn\'t here.');
        if (self::statusLabel($status) === $status) throw new RuntimeException('Choose a status.');
        $l = self::line($pdo, $oid, $lineId);
        if (in_array($status, self::OUT_DOOR, true) && ($why = self::shipHold($pdo, $o)) !== '') throw new RuntimeException($why);   // released for delivery waits for payment (model 1.9)
        $tracking = mb_substr(trim($tracking), 0, 160);
        $was = self::outTheDoor($pdo, $o);
        $pdo->prepare('UPDATE order_lines SET item_status = ?, tracking = ? WHERE id = ?')->execute([$status, $tracking, $lineId]);
        if (in_array($status, ['shipped', 'in_route', 'delivered', 'ready', 'complete'], true)) $pdo->prepare("UPDATE order_lines SET status = 'done' WHERE id = ? AND status = 'open'")->execute([$lineId]);
        Orders::event($pdo, $oid, 'item_status', $l['title'] . ': ' . self::statusLabel($status) . ($tracking !== '' ? ' · ' . $tracking : ''), $staff, $lineId);
        // the last of it out the door (Jason, 2026-10-30): the client hears once, with each item's tracking, and is asked to
        // tell us when they have it (that completes the order once it's paid; decisions/0178 §6)
        if (!$was && self::hasReceived($pdo) && self::outTheDoor($pdo, $o) && self::wantsProgress($o)) {
            $rows = []; $pick = false;
            foreach (self::deliverables($o, Orders::lines($pdo, $oid)) as $x) { $st = self::itemStatus($o, $x); $pick = $pick || $st === 'ready'; $rows[] = '• ' . $x['title'] . ': ' . self::statusLabel($st) . (($x['tracking'] ?? '') !== '' ? ' (' . $x['tracking'] . ')' : ''); }
            self::mail($o, 'Your Traversence order #' . Orders::no($o) . ($pick && count(array_filter($rows, fn ($r) => !str_contains($r, 'Ready for pickup'))) === 0 ? ' is ready for pickup' : ' is on its way'),
                'Hello ' . $o['bill_name'] . ",\n\nEverything on order #" . Orders::no($o) . ' is on its way' . ($pick ? ' or ready for pickup' : '') . ":\n\n" . implode("\n", $rows) . "\n\n" . self::GOT_IT_ASK . "\n" . self::url($o) . '#got-it');
        }
    }

    /** Emails the client where each item stands (with tracking), when our team chooses to. */
    public static function sendUpdate(PDO $pdo, int $oid, string $note, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] === 'draft') throw new RuntimeException('Send the order to the client first.');
        if (!self::wantsProgress($o)) throw new RuntimeException('The client turned off progress emails on their order page, so this isn\'t sent. Their receipts still go.');
        $rows = [];
        foreach (Orders::lines($pdo, $oid) as $l) {
            $st = self::itemStatus($o, $l);
            if (in_array($st, ['deleted', 'archived', 'deactivated'], true) || $l['product'] === 'shipping') continue;
            $rows[] = '• ' . $l['title'] . ': ' . self::statusLabel($st) . (($l['tracking'] ?? '') !== '' ? ' (' . $l['tracking'] . ')' : '');
        }
        $note = mb_substr(trim($note), 0, 600);
        self::mail($o, 'An update on your order ' . self::ref($o), 'Hello ' . $o['bill_name'] . ",

Here's where your order " . self::ref($o) . " stands:

" . implode("
", $rows)
            . ($note !== '' ? "

" . $note : '') . "

" . (self::hasReceived($pdo) && self::outTheDoor($pdo, $o) ? self::GOT_IT_ASK . "\n" . self::url($o) . '#got-it' : "See your order any time:\n" . self::url($o)));
        Orders::event($pdo, $oid, 'update_sent', 'To ' . $o['bill_email'] . ($note !== '' ? ': ' . $note : ''), $staff);
    }

    // ---- drop ship per item (2026-12-10_item_shipping.sql) -------------------------------------------------------------

    public static function hasShip(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT ship_cents FROM order_lines LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }

    public static function addresses(PDO $pdo, int $oid): array
    {
        if (!self::hasShip($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM order_addresses WHERE order_id = ? ORDER BY id'); $st->execute([$oid]);
        return array_column($st->fetchAll(PDO::FETCH_ASSOC), null, 'id');
    }

    public static function addressText(array $a): string
    {
        return trim(implode(', ', array_filter([$a['name'] ?? '', $a['street'] ?? '', $a['city'] ?? '', trim(($a['state'] ?? '') . ' ' . ($a['zip'] ?? ''))])), ', ');
    }

    // ---- the order edited in place (2026-12-11_inline_order.sql) -----------------------------------------------------

    public const SHIP_STYLES = ['drop' => 'Drop Ship', 'courier' => 'Courier', 'pickup' => 'Pick Up'];
    public const CARRIERS = ['usps' => 'USPS', 'ups' => 'UPS', 'fedex' => 'FedEx', 'other' => 'Other'];
    public const FILE_TYPES = ['application/pdf' => 'pdf', 'image/png' => 'png', 'image/jpeg' => 'jpg', 'image/gif' => 'gif', 'image/webp' => 'webp'];
    /** Artwork and reference files on an item (decisions/0107): also vector, layered and zipped files, always downloaded, never shown inline. */
    public const ART_TYPES = self::FILE_TYPES + ['image/svg+xml' => 'svg', 'image/tiff' => 'tif', 'application/postscript' => 'eps', 'image/vnd.adobe.photoshop' => 'psd',
        'application/zip' => 'zip', 'application/x-zip-compressed' => 'zip', 'application/illustrator' => 'ai'];
    /** Documents on an order or an item (a contract, a P.O., a brief): Office files and text too, always downloaded. */
    /** (Office's own type names are longer than order_files.mime holds; these short ones download the same.) */
    public const DOC_TYPES = ['application/msword' => 'docx', 'application/vnd.ms-excel' => 'xlsx', 'application/vnd.ms-powerpoint' => 'pptx',
        'text/plain' => 'txt', 'text/csv' => 'csv', 'application/x-indesign' => 'indd'];
    public const ALL_TYPES = self::ART_TYPES + self::DOC_TYPES;
    // what a file is (Jason, 2026-10-28): a production setup is imposed and output-configured for a vendor that skips
    // preflight and prepress (Competition); a print file is 1-up, for a vendor that does its own prepress (4OVER)
    public const FILE_KINDS = ['setup' => 'Production setup', 'print' => 'Print file (1-up)', 'artwork' => 'Artwork', 'native' => 'Native', 'reference' => 'Reference',
                               'document' => 'Document', 'estimate' => 'Estimate', 'invoice' => 'Invoice', 'label' => 'Shipping label', 'manifest' => 'Shipping manifest'];

    /** Tags on items (Rush, Reprint, Sample…): 2026-12-18_item_panel.sql. */
    public const TAGS = ['Rush', 'Reprint', 'Sample'];
    public static function hasTags(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT tags FROM order_lines LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }
    public static function tags(array $l): array { return array_values(array_filter(array_map('trim', explode(',', (string) ($l['tags'] ?? ''))), 'strlen')); }

    /** An item's tags, comma separated; our team's only (the client doesn't see them). */
    public static function setTags(PDO $pdo, int $oid, int $lineId, string $tags, int $staff): void
    {
        if (!self::hasTags($pdo)) throw new RuntimeException('Run 2026-12-18_item_panel.sql first.');
        $l = self::line($pdo, $oid, $lineId);
        $t = [];
        foreach (explode(',', $tags) as $x) { $x = mb_substr(trim(preg_replace('/\s+/', ' ', $x)), 0, 30); if ($x !== '' && !in_array(mb_strtolower($x), array_map('mb_strtolower', $t), true)) $t[] = $x; }
        $v = mb_substr(implode(', ', $t), 0, 200);
        $pdo->prepare('UPDATE order_lines SET tags = ? WHERE id = ?')->execute([$v, $lineId]);
        Orders::event($pdo, $oid, 'item_tags', $l['title'] . ': ' . ($v !== '' ? $v : 'no tags'), $staff, $lineId);
    }

    public static function hasInline(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT ship_style FROM order_lines LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }

    /** The order's own Ship to, as text (the default for its items). */
    public static function shipToText(array $o): string
    {
        return self::addressText(['name' => $o['ship_name'] ?? '', 'street' => $o['ship_street'] ?? '', 'city' => $o['ship_city'] ?? '', 'state' => $o['ship_state'] ?? '', 'zip' => $o['ship_zip'] ?? '']);
    }

    /** One field of the order, changed in place. Client and payment while it's open; Ship to, P.O. and dates until cancelled. */
    public static function setField(PDO $pdo, int $oid, string $f, string $v, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] === 'void') throw new RuntimeException('That order isn\'t here.');
        $v = trim($v);
        $terms = ['name' => 'bill_name', 'email' => 'bill_email', 'company' => 'client_company', 'phone' => 'client_phone', 'pay_mode' => 'pay_mode', 'deposit_pct' => 'deposit_pct', 'note' => 'note'];
        $any = ['bill_street' => 160, 'bill_city' => 80, 'bill_state' => 40, 'bill_zip' => 12, 'ship_name' => 120, 'ship_street' => 160, 'ship_city' => 80, 'ship_state' => 40, 'ship_zip' => 12, 'po_number' => 60];
        if (isset($terms[$f])) {
            if (!self::editable($o)) throw new RuntimeException('The client has approved it: the client and payment stay as they are.');
            $in = ['name' => $o['bill_name'], 'email' => $o['bill_email'], 'company' => $o['client_company'], 'phone' => $o['client_phone'], 'pay_mode' => $o['pay_mode'], 'deposit_pct' => $o['deposit_pct'],
                   'note' => $o['note'], 'delivery' => $o['delivery'] ?? '', 'po' => $o['po_number'] ?? '', 'due_terms' => $o['due_terms'] ?? 'receipt'];
            $in[$f] = $v;
            // a deposit with no % set is figured from the items' cost (decisions/0177 §3): nothing to fill in
            self::saveTerms($pdo, $oid, $in, $staff);
        } elseif (isset($any[$f])) {
            $pdo->prepare("UPDATE orders SET $f = ? WHERE id = ?")->execute([mb_substr(in_array($f, ['bill_state', 'ship_state'], true) ? strtoupper($v) : $v, 0, $any[$f]), $oid]);
        } elseif ($f === 'tax_choice' || $f === 'tax_note') {   // the order's sales tax, chosen by the order taker (decisions/0177 §2)
            if (!Orders::hasCol($pdo, 'tax_choice')) throw new RuntimeException('The tax choice opens once its database update has run (System Configuration → Database updates).');
            if (!self::editable($o)) throw new RuntimeException('The client has approved it: its tax is on the invoice. Reopen it to change the tax.');
            if ($f === 'tax_choice' && !isset(self::TAX_CHOICES[$v])) throw new RuntimeException('Choose how the order is taxed.');
            $pdo->prepare("UPDATE orders SET $f = ? WHERE id = ?")->execute([mb_substr($v, 0, 200), $oid]);
            if ($f === 'tax_choice') Orders::event($pdo, $oid, 'tax_choice', 'Sales tax: ' . self::TAX_CHOICES[$v][0] . ($v === 'taxable' ? '' : ' (no line is taxed)'), $staff);
        } elseif ($f === 'due_terms') {
            if (!isset(self::DUE_TERMS[$v])) throw new RuntimeException('Choose the terms.');
            $pdo->prepare('UPDATE orders SET due_terms = ?, due_date = NULL WHERE id = ?')->execute([$v, $oid]);
        } elseif ($f === 'due_date') {
            if ($v !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) throw new RuntimeException('Pick the due date.');
            $pdo->prepare('UPDATE orders SET due_date = ? WHERE id = ?')->execute([$v === '' ? null : $v, $oid]);
        } else throw new RuntimeException('That can\'t be changed here.');
    }

    /** One field of an item, changed in place, while the order is open: its name, description, qty, rate or tax. */
    public static function setLineField(PDO $pdo, int $oid, int $lineId, string $f, string $v, int $staff): void
    {
        $o = self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        $v = trim($v);
        if ($f === 'title') {
            if ($v === '') throw new RuntimeException('Give it a name.');
            if ($l['product'] === 'product' && self::hasRunQty($pdo) && !(int) ($l['run_qty'] ?? 0) && ($rn = self::runInTitle((string) $l['title'])) > 0) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([$rn, $lineId]);   // renaming keeps its size
            if ($l['product'] === 'go_code' && $l['ref_id']) { self::updateGoCode($pdo, $oid, $lineId, preg_replace('/^GO Code:\s*/', '', $v), json_decode((string) $pdo->query('SELECT fields FROM qr_issued WHERE id = ' . (int) $l['ref_id'])->fetchColumn(), true) ?: [], $staff); return; }
            $pdo->prepare('UPDATE order_lines SET title = ? WHERE id = ?')->execute([mb_substr($v, 0, 160), $lineId]);
        } elseif ($f === 'note') {
            $pdo->prepare('UPDATE order_lines SET note = ? WHERE id = ?')->execute([mb_substr($v, 0, 300), $lineId]);
        } elseif ($f === 'qty' || $f === 'unit') {
            if ($f === 'qty' && self::countIn($v) < 1) throw new RuntimeException('Enter how many, like 500.');
            $qty = $f === 'qty' ? self::countIn($v) : (int) $l['qty'];
            $price = $f === 'unit' ? $v : number_format((int) $l['unit_cents'] / 100, 2, '.', '');
            if ($l['product'] === 'product' && $f === 'qty') {   // a new run size: a rate typed by hand stays (rate × the new run); otherwise the catalog's price for it
                // priced by the catalog only when its price is the catalog's for this run and the product is still there with prices;
                // anything else (a rate typed, no list price, the product gone) keeps its rate, and the amount follows the run
                $pc = $l['product_id'] ? Products::get($pdo, (int) $l['product_id']) : null;
                $typed = !$pc || empty($pc['tiers']) || (int) $l['list_cents'] <= 0 || (int) $l['unit_cents'] !== (int) $l['list_cents'];
                $run = !self::runKnown($l) ? number_format((int) $l['unit_cents'] / 100, 2, '.', '')   // its size was lost to a rename: set it, keep its price
                    : ($typed ? number_format(self::rateTotal(self::rate($l), $qty * max(1, (int) $l['qty'])) / max(1, (int) $l['qty']) / 100, 2, '.', '') : '');
                self::updateLine($pdo, $oid, $lineId, $qty, $run, (string) $l['note'], $staff); return;
            }
            // a catalog line is one run (qty 1, its price the run's): the rate typed is each item's, so the run's price is rate × run size
            if ($l['product'] === 'product') $pdo->prepare('UPDATE order_lines SET unit_cents = ? WHERE id = ?')->execute([self::rateTotal($price, self::runQty($l)), $lineId]);
            else $pdo->prepare('UPDATE order_lines SET qty = ?, unit_cents = ? WHERE id = ?')->execute([$l['product'] === 'go_code' ? 1 : $qty, self::cents($price), $lineId]);
            self::recalc($pdo, $oid);
        } elseif ($f === 'service_type') {   // what a promotion can work on (decisions/0108)
            require_once __DIR__ . '/Promotions.php';
            $pdo->prepare('UPDATE order_lines SET service_type = ? WHERE id = ?')->execute([isset(Promotions::SERVICE_TYPES[$v]) ? $v : '', $lineId]);
        } elseif ($f === 'taxable') {
            $pdo->prepare('UPDATE order_lines SET taxable = ? WHERE id = ?')->execute([$v === '1' ? 1 : 0, $lineId]);
        } else throw new RuntimeException('That can\'t be changed here.');
        Orders::event($pdo, $oid, 'line_changed', $l['title'] . ': ' . $f, $staff, $lineId);
    }

    /**
     * An item's Edit form, all at once: its name, description, how many (a catalog item's run size), its rate (each one's
     * price) or the catalog's price, its options, kind and tax. A catalog item's run is one line (qty 1) priced rate × run.
     */
    public static function editLine(PDO $pdo, int $oid, int $lineId, array $in, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        if ($l['product'] === 'shipping') throw new RuntimeException('Shipping changes from its ship icon.');
        $title = trim((string) ($in['title'] ?? $l['title']));
        if ($title === '') throw new RuntimeException('Give it a name.');
        $note = mb_substr(trim((string) ($in['note'] ?? $l['note'])), 0, 300);
        $tax = !empty($in['taxable']) ? 1 : 0;
        if ($l['product'] === 'go_code') {   // a GO Code is one, at its price; what it holds has its own form
            if ($title !== $l['title'] && $l['ref_id']) self::updateGoCode($pdo, $oid, $lineId, preg_replace('/^GO Code:\s*/', '', $title), json_decode((string) $pdo->query('SELECT fields FROM qr_issued WHERE id = ' . (int) $l['ref_id'])->fetchColumn(), true) ?: [], $staff);
            $pdo->prepare('UPDATE order_lines SET note = ?, taxable = ? WHERE id = ?')->execute([$note, $tax, $lineId]);
            self::recalc($pdo, $oid); Orders::event($pdo, $oid, 'line_changed', $title . ': edited', $staff, $lineId); return;
        }
        $n = self::countIn((string) ($in['qty'] ?? ''));
        if ($n < 1) throw new RuntimeException('Enter how many, like 500.');
        $rate = trim((string) ($in['rate'] ?? ''));
        $catalog = !empty($in['catalog']) || $rate === '';
        if ($l['product'] === 'product') {
            $p = $l['product_id'] ? Products::get($pdo, (int) $l['product_id']) : null;
            $labels = []; $picked = (string) $l['options'];
            if ($p) {
                $cur = Products::pickedFrom($p, (string) $l['options']); $pk = [];
                foreach ($p['options'] as $i => $o) {
                    $v = (string) (($in['opt'] ?? [])[$i] ?? ($cur[$i] ?? ''));
                    if (!in_array($v, array_column($o['choices'], 'label'), true)) $v = $o['choices'][0]['label'];
                    $labels[] = $v; $pk[] = $o['name'] . ': ' . $v;
                }
                $picked = implode(' · ', $pk);
            }
            $list = $p ? Products::priceFor($p, $n, $labels) : ['total' => (int) $l['list_cents'], 'cost' => (int) $l['cost_cents']];
            if ($catalog && !$p) throw new RuntimeException('That product is no longer in the catalog: type its rate.');
            $unit = $catalog ? $list['total'] : self::rateTotal($rate, $n);
            if (self::hasRunQty($pdo)) { if (self::runInTitle($title) > 0) $title = self::titleWithRun($title, $n); }
            else $title = self::titleWithRun($title, $n);   // nowhere else to keep the size until 2026-12-28_order_run_qty.sql
            $pdo->prepare('UPDATE order_lines SET title = ?, note = ?, qty = 1, unit_cents = ?, list_cents = ?, cost_cents = ?, options = ?, taxable = ? WHERE id = ?')
                ->execute([mb_substr($title, 0, 160), $note, $unit, $list['total'], $list['cost'], mb_substr($picked, 0, 400), $tax, $lineId]);
            if (self::hasRunQty($pdo)) $pdo->prepare('UPDATE order_lines SET run_qty = ? WHERE id = ?')->execute([$n, $lineId]);
        } else {
            $bundle = self::hasProjects($pdo) && (self::partsOf($pdo, [$lineId])[$lineId] ?? []);
            $unit = $bundle ? (int) $l['unit_cents'] : ($rate === '' ? (int) $l['unit_cents'] : self::cents($rate));
            $pdo->prepare('UPDATE order_lines SET title = ?, note = ?, qty = ?, unit_cents = ?, taxable = ? WHERE id = ?')
                ->execute([mb_substr($title, 0, 160), $note, $bundle ? 1 : $n, $unit, $tax, $lineId]);
            if (array_key_exists('service_type', $in)) { require_once __DIR__ . '/Promotions.php'; $st = (string) $in['service_type']; $pdo->prepare('UPDATE order_lines SET service_type = ? WHERE id = ?')->execute([isset(Promotions::SERVICE_TYPES[$st]) ? $st : '', $lineId]); }
        }
        self::recalc($pdo, $oid);
        Orders::event($pdo, $oid, 'line_changed', $title . ': edited', $staff, $lineId);
    }

    /** The items in the order they were dragged to. */
    public static function reorder(PDO $pdo, int $oid, array $ids): void
    {
        $st = $pdo->prepare('UPDATE order_lines SET position = ? WHERE id = ? AND order_id = ?');
        foreach (array_values(array_map('intval', $ids)) as $i => $id) $st->execute([$i + 1, $id, $oid]);
    }

    /** An item's shipping from its ship icon. The charge can change only while the order is open. */
    public static function setShip(PDO $pdo, int $oid, int $lineId, array $in, int $staff): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] === 'void') throw new RuntimeException('That order isn\'t here.');
        $l = self::line($pdo, $oid, $lineId);
        $style = isset(self::SHIP_STYLES[$in['style'] ?? '']) ? (string) $in['style'] : '';
        $carrier = $style === 'pickup' ? '' : (isset(self::CARRIERS[$in['carrier'] ?? '']) ? (string) $in['carrier'] : '');
        $c = $style === 'pickup' || trim((string) ($in['charge'] ?? '')) === '' ? 0 : self::cents((string) $in['charge']);
        $k = $style === 'pickup' || trim((string) ($in['cost'] ?? '')) === '' ? 0 : self::cents((string) $in['cost']);
        if ($c !== (int) $l['ship_cents'] && !self::editable($o)) throw new RuntimeException('The client has approved the order, so its shipping charge stays. The rest can still change.');
        $pdo->prepare('UPDATE order_lines SET ship_style = ?, ship_carrier = ?, ship_address = ?, ship_cents = ?, ship_cost_cents = ?, tracking = ? WHERE id = ?')
            ->execute([$style, $carrier, mb_substr(trim((string) ($in['address'] ?? '')), 0, 400), $c, $k, mb_substr(trim((string) ($in['tracking'] ?? '')), 0, 160), $lineId]);
        if ($c !== (int) $l['ship_cents']) self::recalc($pdo, $oid);
        Orders::event($pdo, $oid, 'line_ship', $l['title'] . ': ' . (self::SHIP_STYLES[$style] ?? 'shipping') . ($carrier !== '' ? ' · ' . self::CARRIERS[$carrier] : '') . ($c ? ' · ' . Orders::usd($c) : ''), $staff, $lineId);
    }

    /** An item's file (artwork, label…): kept with its order (decisions/0124); one from before where it was, until it moves. */
    public static function filePath(array $f): string
    {
        require_once __DIR__ . '/Store.php';
        return Store::either(self::filePlace(Database::connection(), $f), __DIR__ . '/../storage/order-files/' . (int) $f['order_id'] . '/' . (int) $f['id'] . '.' . (self::ALL_TYPES[$f['mime']] ?? 'bin'));
    }

    public static function filePlace(PDO $pdo, array $f): string
    {
        require_once __DIR__ . '/Store.php';
        return Store::path('orders', (int) $f['order_id'], 'files', (int) $f['id'] . '.' . (self::ALL_TYPES[$f['mime']] ?? 'bin'), false);
    }

    /** An order's files by line, each with its size in bytes (null when the file is missing from storage). */
    public static function files(PDO $pdo, int $oid): array
    {
        if (!self::hasInline($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM order_files WHERE order_id = ? ORDER BY id'); $st->execute([$oid]);
        $by = [];
        $sizes = []; require_once __DIR__ . '/Store.php';   // one look at the order's storage (this server or S3) for every file's size
        try { foreach (Store::files('orders', $oid) as $k => $b) if (preg_match('~/files/(\d+)\.\w+$~', (string) $k, $m)) $sizes[(int) $m[1]] = (int) $b; } catch (Throwable) {}
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) { $f['size'] = $sizes[(int) $f['id']] ?? null; $by[(int) $f['line_id']][] = $f; }
        return $by;
    }

    /** Where an item goes: its ship icon's setting (style, carrier, address), else the older ship_to, else the order's Ship to. */
    public static function shipLabel(array $o, array $l, array $addrs): string
    {
        $style = (string) ($l['ship_style'] ?? '');
        if ($style === 'pickup') return 'Pick Up';
        if ($style !== '' || ($l['ship_address'] ?? '') !== '') {
            $to = (string) ($l['ship_address'] ?? '') !== '' ? preg_replace('/\s*\R\s*/', ', ', (string) $l['ship_address']) : (self::shipToText($o) ?: 'the client\'s address');
            return trim((self::SHIP_STYLES[$style] ?? '') . (($l['ship_carrier'] ?? '') !== '' ? ' · ' . (self::CARRIERS[$l['ship_carrier']] ?? '') : '') . ': ' . $to, ': ');
        }
        $t = (string) ($l['ship_to'] ?? '');
        if ($t === 'pickup') return 'Pickup';
        if (preg_match('/^a(\d+)$/', $t, $m) && isset($addrs[(int) $m[1]])) { $a = $addrs[(int) $m[1]]; return $a['label'] . ': ' . self::addressText($a); }
        return ($o['ship_street'] ?? '') !== '' ? 'The client: ' . self::addressText(['name' => $o['ship_name'], 'street' => $o['ship_street'], 'city' => $o['ship_city'], 'state' => $o['ship_state'], 'zip' => $o['ship_zip']]) : 'The client\'s address';
    }

    /** The order's shipping: the total and, per item, where it goes and what it costs. */
    public static function shipping(PDO $pdo, array $o): array
    {
        $rows = []; $sum = 0;
        require_once __DIR__ . '/Shipments.php';
        if (Shipments::ready($pdo) && Shipments::shipped($o)) {   // manifests: each destination's estimate
            foreach (Shipments::destinations($pdo, $o) as $d) if ((int) $d['est_cents'] > 0) { $sum += (int) $d['est_cents']; $rows[] = ['title' => $d['label'] . ($d['method'] !== '' ? ' (' . $d['method'] . ')' : ''), 'to' => $d['text'] ?: $d['label'], 'cents' => (int) $d['est_cents']]; }
        }
        // and each item's own shipping charge, as the total counts it (recalc): never shown to the client and left off the invoice
        if (!self::hasShip($pdo)) return ['cents' => $sum, 'rows' => $rows];
        $addrs = self::addresses($pdo, (int) $o['id']);
        foreach (Orders::lines($pdo, (int) $o['id']) as $l) {
            if ((int) $l['ship_cents'] <= 0) continue;
            $sum += (int) $l['ship_cents'];
            $to = self::shipLabel($o, $l, $addrs);
            $rows[] = ['title' => (string) $l['title'], 'to' => $to, 'cents' => (int) $l['ship_cents']];
        }
        return ['cents' => $sum, 'rows' => $rows];
    }

    public static function hasDelivery(PDO $pdo): bool { return Orders::hasCol($pdo, 'delivery'); }

    /** How the order reaches the client: its setting, else shipped when it has a shipping line, else '' (not said). */
    public static function delivery(array $o, array $lines): string
    {
        $d = (string) ($o['delivery'] ?? '');
        if ($d !== '') return $d;
        foreach ($lines as $l) if ($l['product'] === 'shipping') return 'ship';
        return '';
    }

    /** Whether any item ships to the client's own address (the one asked for when approving). */
    public static function needsClientAddress(array $lines): bool
    {
        foreach ($lines as $l) if ($l['product'] !== 'shipping' && ($l['ship_to'] ?? '') === '') return true;
        return false;
    }

    /** The ship-to address from the approval form ('ship_same' = the billing address); [] when it isn't shipped. */
    private static function shipFrom(array $o, array $lines, array $in, array $bill): array
    {
        if (self::delivery($o, $lines) !== 'ship' || !self::needsClientAddress($lines)) return [];   // every item has its own address or is picked up
        if (!empty($in['_ship_on_wo']) && trim((string) ($in['ship_street'] ?? '')) === '') return [];   // handled outside: where it ships is on its work order (WorkOrders::processOutside)
        if (!empty($in['ship_same'])) {
            if ($bill['street'] === '') throw new RuntimeException('Add the billing address to ship there, or give the address to ship to.');
            return ['name' => (string) $o['bill_name']] + array_intersect_key($bill, array_flip(['street', 'city', 'state', 'zip']));
        }
        $a = [];
        foreach (['name' => 120, 'street' => 160, 'city' => 80, 'state' => 40, 'zip' => 12] as $k => $max) $a[$k] = mb_substr(trim((string) ($in['ship_' . $k] ?? '')), 0, $max);
        if ($a['name'] === '') $a['name'] = (string) $o['bill_name'];
        if ($a['street'] === '' || $a['city'] === '' || $a['state'] === '' || !preg_match('/^\d{5}(-\d{4})?$/', $a['zip'])) throw new RuntimeException('Add the address to ship to (street, town, state and ZIP).');
        return $a;
    }

    /**
     * A payment received outside QuickBooks (cash, check, Zelle…), recorded by our team on an approved order: a deposit
     * while some is left, the payment when it's all in (the GO Codes go live, printing starts, the client is emailed).
     */
    public static function recordPayment(PDO $pdo, int $oid, int $cents, string $method, string $ref, int $staff, bool $receipt = true): string   // $receipt: email the client a receipt
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] !== 'pending') throw new RuntimeException('Record a payment once the order is approved and until it\'s paid.');
        $left = (int) $o['total_cents'] - Orders::money($pdo, $oid)['paid'];
        if ($cents <= 0) throw new RuntimeException('Enter the amount received.');
        if ($cents > $left) throw new RuntimeException('That\'s more than is left to pay (' . Orders::usd($left) . ').'
            . (empty($o['invoice_id']) && (string) ($o['invoice_no'] ?? '') !== '' ? ' If the client paid QuickBooks invoice ' . $o['invoice_no'] . ' for more, this order\'s lines don\'t match it: use Reopen for changes, make the prices, extra lines (shipping, a tax line) match the invoice, then record the payment.' : ''));
        $m = self::PAY_METHODS[$method] ?? 'Other';
        $key = 'out-' . $oid . '-' . substr(hash('sha256', $cents . '|' . $method . '|' . $ref . '|' . date('YmdHi')), 0, 16);   // a double tap is recorded once
        self::received($pdo, $oid, $cents, $cents < $left ? 'deposit' : 'charge', $m, mb_substr(trim($ref), 0, 60), $key, $receipt);
        $qb = '';
        if ($o['invoice_id']) {   // the invoice in QuickBooks shows it paid too, in the order's own mode (sandbox or production)
            require_once __DIR__ . '/QuickBooksPay.php';
            try {
                $pid = QuickBooksPay::withEnv((string) ($o['qb_env'] ?: QuickBooksPay::env()), fn () => QuickBooksPay::recordOtherPayment($pdo, $o, $cents, $m, trim($ref), $key));
                $qb = '. Received on QuickBooks invoice ' . $o['invoice_no'] . ($pid !== '' ? ' (payment ' . $pid . ')' : '');
            } catch (Throwable $x) {
                error_log('qb other payment, order ' . $oid . ': ' . $x->getMessage());
                $qb = '. QuickBooks didn\'t take it (' . mb_substr($x->getMessage(), 0, 160) . '): receive it on invoice ' . $o['invoice_no'] . ' in QuickBooks by hand';
            }
        }
        Orders::event($pdo, $oid, 'payment_recorded', Orders::usd($cents) . ' by ' . strtolower($m) . (trim($ref) !== '' ? ' (' . trim($ref) . ')' : '') . $qb . ($receipt ? '' : ' · no receipt emailed'), $staff);
        return $qb;
    }

    // ---- other ways to pay (decisions/0101, addendum 2026-10-28): a wire, a check, cash, chosen by the client on their
    // order page; the order waits on a payment hold until our team records the money (recordPayment), which releases it.

    /** What a client may choose instead of a card; the how-to for each comes from .env (bank details are never edited on a page). */
    public const CLIENT_METHODS = ['wire' => 'Wire transfer', 'check' => 'Check', 'cash' => 'Cash'];

    public static function hasPayChoice(PDO $pdo): bool { return Orders::hasCol($pdo, 'pay_offer') && Orders::hasCol($pdo, 'notify_progress'); }

    /**
     * The ways a client can choose at checkout besides a card: the client picks, not our team (Jason, 2026-10-28).
     * Site-wide, from Settings (CLIENT_PAY_WAYS); unset, a wire or a check.
     */
    public static function offers(array $o): array
    {
        Database::readEnv();
        $set = getenv('CLIENT_PAY_WAYS');
        $out = [];
        foreach (explode(',', $set === false ? 'wire,check' : (string) $set) as $k) if (isset(self::CLIENT_METHODS[$k = trim($k)])) $out[$k] = self::CLIENT_METHODS[$k];
        if (isset($out['wire']) && (int) (($o['total_cents'] ?? 0) ?: ($o['subtotal_cents'] ?? 0)) < self::WIRE_MIN_CENTS) unset($out['wire']);   // a wire only for $2,500 and up
        return $out;
    }

    /**
     * Has the client done their part (Jason, 2026-10-28: "If it complete move to thank you for your order page")? Paid;
     * or approved with a wire or check they've told us is sent, or cash they'll bring.
     */
    public static function placed(array $o): bool
    {
        if (in_array($o['status'], ['paid', 'part_refunded'], true)) return true;
        if ($o['status'] !== 'pending') return false;
        $m = (string) ($o['pay_method'] ?? '');
        return ($m === 'cash') || (in_array($m, ['wire', 'check'], true) && (string) ($o['pay_report'] ?? '') !== '');
    }

    /** A member's orders we prepared for them (their account, or their confirmed email), newest first; drafts aren't theirs yet. */
    public static function forMember(PDO $pdo, int $uid): array
    {
        require_once __DIR__ . '/QrIssue.php';
        QrIssue::claim($pdo, $uid);   // orders sent to their confirmed email join their account
        $st = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? AND created_by IS NOT NULL AND status NOT IN ('draft') ORDER BY id DESC LIMIT 200");
        $st->execute([$uid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Where an order stands, in a few words, for the client. */
    public static function clientStatus(PDO $pdo, array $o): string
    {
        if ($o['status'] === 'sent') return self::expired($o) ? 'Link expired: ask us to send it again' : 'Waiting for your review';
        if ($o['status'] === 'void') return 'Cancelled';
        if (in_array($o['status'], ['refunded'], true)) return 'Refunded';
        if ($o['status'] === 'pending') {
            if (in_array((string) ($o['pay_method'] ?? ''), ['wire', 'check'], true) && (string) ($o['pay_report'] ?? '') !== '') return 'Placed: waiting for your ' . strtolower(self::CLIENT_METHODS[$o['pay_method']]) . ' to arrive';
            return 'Approved: ' . Orders::usd(self::dueNow($pdo, $o)) . ' to pay';
        }
        return self::STAGES[$o['stage']] ?? 'Paid';
    }

    // ---- wire details, shown only to the client, only on screen (Jason, 2026-10-28) -----------------------------------
    // Never emailed, never on the page as text: a code goes to the order's email; once it's entered, the details show
    // for 10 minutes as a picture (no text to copy) stamped with who, which order, when and from where. Each view is
    // logged and our team is emailed. The details and the phone number to confirm them live only in .env, by hand.

    public const WIRE_MIN_CENTS = 250000;
    public const WIRE_MINUTES = 10;

    /** The number a client calls to confirm our wire details (WIRE_VERIFY_PHONE in .env). */
    public static function wirePhone(): string
    {
        Database::readEnv();
        return trim((string) (getenv('WIRE_VERIFY_PHONE') ?: '(602) 708-3795'));
    }

    private static function wireReady(PDO $pdo, array $o): void
    {
        if ($o['status'] !== 'pending' || self::dueNow($pdo, $o) <= 0 || ($o['pay_method'] ?? '') !== 'wire' || !isset(self::offers($o)['wire'])) throw new RuntimeException('Choose Wire transfer under Pay first.');
        if (self::howToPay('wire') === '') throw new RuntimeException('We\'ll send you our wire details ourselves. Call us at ' . self::wirePhone() . ' if you haven\'t heard from us.');
    }

    /** A 6-digit code to the order's email, good for WIRE_MINUTES; at most 5 an hour. */
    public static function wireSendCode(PDO $pdo, array $o): void
    {
        self::wireReady($pdo, $o);
        $oid = (int) $o['id'];
        $sent = array_values(array_filter((array) ($_SESSION['tv_wire_sent'][$oid] ?? []), fn ($t) => $t > time() - 3600));
        if (count($sent) >= 5) throw new RuntimeException('That\'s a lot of codes: wait a while, or call us at ' . self::wirePhone() . '.');
        $code = (string) random_int(100000, 999999);
        $_SESSION['tv_wire'][$oid] = ['h' => password_hash($code, PASSWORD_DEFAULT), 'until' => time() + self::WIRE_MINUTES * 60, 'tries' => 0];
        $sent[] = time(); $_SESSION['tv_wire_sent'][$oid] = $sent;
        self::mail($o, 'Your code to see our wire details: ' . $code,
            'Hello ' . $o['bill_name'] . ",\n\nYour code to see our wire details for order #" . Orders::no($o) . ' is: ' . $code
            . "\n\nIt works for " . self::WIRE_MINUTES . ' minutes, on the page where you asked for it.'
            . "\n\nBefore you send a wire, call us at " . self::wirePhone() . ' to confirm the details. We never send or change our bank details by email.'
            . "\n\nDidn't ask for this? Call us at " . self::wirePhone() . '.');
        Orders::event($pdo, $oid, 'wire_code', 'A code to see the wire details went to ' . $o['bill_email'] . (($_SERVER['REMOTE_ADDR'] ?? '') !== '' ? ' (asked from ' . $_SERVER['REMOTE_ADDR'] . ')' : ''));
    }

    /** The code entered: the details show for WIRE_MINUTES. Five wrong tries and a new code is needed. */
    public static function wireCheckCode(PDO $pdo, array $o, string $code): void
    {
        self::wireReady($pdo, $o);
        $oid = (int) $o['id'];
        $c = $_SESSION['tv_wire'][$oid] ?? null;
        if (!$c || $c['until'] < time()) throw new RuntimeException('That code has run out: ask for a new one.');
        if ($c['tries'] >= 5) { unset($_SESSION['tv_wire'][$oid]); throw new RuntimeException('Too many tries: ask for a new code.'); }
        $_SESSION['tv_wire'][$oid]['tries']++;
        if (!password_verify(preg_replace('/\D/', '', $code), $c['h'])) throw new RuntimeException('That code isn\'t right. Check the latest email from us.');
        unset($_SESSION['tv_wire'][$oid]);
        $_SESSION['tv_wire_ok'][$oid] = time() + self::WIRE_MINUTES * 60;
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        Orders::event($pdo, $oid, 'wire_viewed', 'Wire details shown to ' . $o['bill_email'] . ($ip !== '' ? ' from ' . $ip : ''));
        self::mailStaff($pdo, $o, 'Wire details viewed: order #' . Orders::no($o), 'The wire details were shown for order #' . Orders::no($o) . ' (' . Orders::usd(self::dueNow($pdo, $o)) . ') after a code to ' . $o['bill_email'] . ' was entered'
            . ($ip !== '' ? ', from ' . $ip : '') . ', at ' . date('M j, g:i a') . ".\n\nIf that wasn't your client, call them before any money moves.");
    }

    /** Seconds the details still show for on this visit (0: hidden). */
    public static function wireLeft(array $o): int { return max(0, (int) ($_SESSION['tv_wire_ok'][(int) $o['id']] ?? 0) - time()); }

    /** The details as a PNG, stamped across with who, which order, when and from where; null without GD. */
    public static function wireCard(PDO $pdo, array $o): ?string
    {
        if (!function_exists('imagecreatetruecolor')) return null;
        $lines = array_merge(['WIRE TRANSFER: ORDER ' . Orders::no($o), 'Amount: ' . Orders::usd(self::dueNow($pdo, $o)), ''], explode("\n", self::howToPay('wire')), ['', 'Reference: Order ' . Orders::no($o), 'Confirm by phone before sending: ' . self::wirePhone()]);
        $lines = array_map(fn ($l) => preg_replace('/[^\x20-\x7E]/', '', (string) $l), $lines);
        $f = 5; $fw = imagefontwidth($f); $fh = imagefontheight($f) + 6;
        $w = max(360, max(array_map('strlen', $lines)) * $fw + 40); $h = count($lines) * $fh + 36;
        $im = imagecreatetruecolor($w, $h);
        imagefill($im, 0, 0, imagecolorallocate($im, 255, 251, 242));
        imagerectangle($im, 0, 0, $w - 1, $h - 1, imagecolorallocate($im, 146, 64, 14));
        $ink = imagecolorallocate($im, 62, 43, 31);
        foreach ($lines as $i => $l) imagestring($im, $f, 20, 18 + $i * $fh, $l, $ink);
        $stamp = Orders::no($o) . ' ' . $o['bill_email'] . ' ' . date('Y-m-d H:i') . ' ' . ($_SERVER['REMOTE_ADDR'] ?? '');   // whose screen it was on
        $wm = imagecolorallocatealpha($im, 146, 64, 14, 100);
        for ($y = 8; $y < $h; $y += 26) imagestring($im, 2, (intdiv($y, 26) % 3) * 40 - 20, $y, str_repeat($stamp . '   ', 4), $wm);
        $big = imagecreatetruecolor($w * 2, $h * 2);   // twice the size, so it reads on a phone and a large screen
        imagecopyresampled($big, $im, 0, 0, 0, 0, $w * 2, $h * 2, $w, $h);
        ob_start(); imagepng($big); $png = (string) ob_get_clean();
        imagedestroy($im); imagedestroy($big);
        return $png;
    }

    /** How to pay this way: our details from .env (WIRE_INSTRUCTIONS, CHECK_INSTRUCTIONS, CASH_INSTRUCTIONS; " | " between lines). */
    public static function howToPay(string $method): string
    {
        Database::readEnv();   // set by hand in .env only, never from a page: a stolen admin login can't swap the bank details
        $v = trim((string) (getenv(strtoupper($method) . '_INSTRUCTIONS') ?: ''));
        return $v === '' ? '' : implode("\n", array_map('trim', explode('|', $v)));
    }

    /** The client picks a way to pay (on their order page): the how-to by email, with a link back to tell us it's sent.
     *  $ref: the wire's confirmation code or the check number, asked for as they choose (blank: not sent yet). */
    public static function choosePay(PDO $pdo, array $o, string $method, string $ref = ''): void
    {
        $oid = (int) $o['id'];
        if ($o['status'] !== 'pending' || self::dueNow($pdo, $o) <= 0) throw new RuntimeException('There\'s nothing to pay on this order now.');
        if ($method === 'card') { $pdo->prepare("UPDATE orders SET pay_method = '' WHERE id = ?")->execute([$oid]); return; }
        $offers = self::offers($o);
        if (!isset($offers[$method])) throw new RuntimeException('Choose one of the ways shown.');
        $ref = $method === 'cash' ? '' : mb_substr(trim(preg_replace('/\s+/', ' ', $ref)), 0, 200);
        $pdo->prepare('UPDATE orders SET pay_method = ? WHERE id = ?')->execute([$method, $oid]);
        if ($ref !== '') $pdo->prepare('UPDATE orders SET pay_report = ?, pay_reported_at = NOW() WHERE id = ?')->execute([$ref, $oid]);
        $refWord = $method === 'wire' ? 'confirmation code' : 'check number';
        Orders::event($pdo, $oid, 'pay_method', 'The client chose to pay by ' . strtolower($offers[$method]) . ($ref !== '' ? ' and says it\'s sent: ' . $ref : ''));
        $how = $method === 'wire' ? '' : self::howToPay($method); $due = self::dueNow($pdo, $o);   // wire details are never emailed
        self::mail($o, 'How to pay order #' . Orders::no($o) . ' by ' . strtolower($offers[$method]),
            'Hello ' . $o['bill_name'] . ",\n\nThank you. To pay " . Orders::usd($due) . ' for order #' . Orders::no($o) . ' by ' . strtolower($offers[$method]) . ':'
            . "\n\n" . ($method === 'wire' ? (self::howToPay('wire') !== '' ? 'For your safety our wire details aren\'t in email: they\'re on your order page, shown after a code we email you. Before sending, call us at ' . self::wirePhone() . ' to confirm them.' : 'We\'ll send you our wire details ourselves; call us at ' . self::wirePhone() . ' to confirm them before sending.') : ($how !== '' ? $how : 'We\'ll send you our details ourselves and confirm them with you by phone.')) . "\n\nPlease put \"Order " . Orders::no($o) . '" in the reference.'
            . ($method === 'wire' ? "\n\nIf anyone sends you bank details by email, call us at " . self::wirePhone() . " before you send anything: we never send or change them by email." : '')
            . ($method === 'cash' ? '' : ($ref !== '' ? "\n\nYou told us it's sent (" . $refWord . ' ' . $ref . '). We\'ll email you when it reaches us.' : "\n\nOnce it's sent, tell us here" . ($method === 'wire' ? ' with the wire\'s confirmation code' : ' with the check number') . ":\n" . self::url($o) . '#pay'))
            . "\n\nYour order is held until the payment reaches us, then it goes to production.");
        self::mailStaff($pdo, $o, 'Paying by ' . strtolower($offers[$method]) . ': order #' . Orders::no($o), $o['bill_name'] . ' chose to pay ' . Orders::usd($due) . ' by ' . strtolower($offers[$method]) . '. The order is on a payment hold until you record it.'
            . ($method === 'cash' ? '' : ($ref !== '' ? "\n\nThey say it's sent. Their " . $refWord . ': ' . $ref . '.' : "\n\nNo " . $refWord . ' yet: they haven\'t sent it. When they do, they enter it on their order page and you get a "' . ($method === 'wire' ? 'Wire sent' : 'Check sent') . '" email with it.')) . (self::howToPay($method) === '' && $method !== 'cash' ? "\n\nThey're waiting for your " . strtolower($offers[$method]) . ' details: send them yourself (and confirm them by phone). The site doesn\'t show them, as WIRE_INSTRUCTIONS/CHECK_INSTRUCTIONS aren\'t set in .env.' : ''));
    }

    /**
     * Reminders while a wire or check is chosen and no confirmation code has come (app/scripts/pay_wait_tick.php, every 15
     * minutes; Jason, 2026-10-28), each once, to the client and to support: 2 hours after they chose; 9:00 am the next
     * business day; 4:00 pm that day, with the other ways to pay. A code, a payment or another choice stops them (choosing
     * again starts over). Returns how many went.
     */
    public static function payWaitTick(PDO $pdo, ?int $now = null): int
    {
        if (!self::hasPayChoice($pdo)) return 0;
        require_once __DIR__ . '/WorkOrders.php';
        require_once __DIR__ . '/Mailer.php';
        $now = $now ?? time(); $n = 0;
        $rows = $pdo->query("SELECT o.*, (SELECT MAX(e.created_at) FROM order_events e WHERE e.order_id = o.id AND e.event = 'pay_method') AS chosen_at,
                                    (SELECT MAX(e.id) FROM order_events e WHERE e.order_id = o.id AND e.event = 'pay_method') AS chosen_ev
                             FROM orders o WHERE o.status = 'pending' AND o.pay_method IN ('wire', 'check') AND COALESCE(o.pay_report, '') = ''")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $o) {
            if (!$o['chosen_at'] || self::dueNow($pdo, $o) <= 0) continue;
            $chosen = strtotime((string) $o['chosen_at']);
            $nine = WorkOrders::nextBusinessNine($chosen); $four = strtotime(date('Y-m-d 16:00:00', $nine));
            $stage = $now >= $four ? 3 : ($now >= $nine ? 2 : ($now >= $chosen + 2 * 3600 ? 1 : 0));
            if (!$stage) continue;
            $st = $pdo->prepare("SELECT MAX(CAST(SUBSTRING(event, 10) AS UNSIGNED)) FROM order_events WHERE order_id = ? AND event LIKE 'pay_nudge%' AND id > ?");
            $st->execute([(int) $o['id'], (int) $o['chosen_ev']]);
            if ((int) $st->fetchColumn() >= $stage) continue;   // this one (or a later one) already went: one email per step, never a backlog
            $way = strtolower(self::CLIENT_METHODS[$o['pay_method']]); $due = Orders::usd(self::dueNow($pdo, $o)); $no = Orders::no($o);
            $code = $o['pay_method'] === 'wire' ? 'the wire\'s confirmation code from your bank' : 'the check number';
            $other = array_values(array_diff_key(self::offers($o), [$o['pay_method'] => 1]));
            if ($o['pay_mode'] !== 'outside') array_unshift($other, 'Card');
            $body = 'Hello ' . $o['bill_name'] . ",\n\n" . ($stage === 3
                    ? 'We haven\'t received your ' . $way . ' of ' . $due . ' for order #' . $no . ' yet, so it\'s still on hold.'
                    : 'A reminder: order #' . $no . ' is waiting on your ' . $way . ' of ' . $due . ', and it goes to production when it reaches us.')
                . "\n\nAlready sent it? Tell us with " . $code . ":\n" . self::url($o) . '#pay'
                . ($o['pay_method'] === 'wire' ? "\n\nCouldn't see our wire details? The code email may be in your spam folder, or call us at " . self::wirePhone() . '.' : '')
                . ($stage === 3 ? "\n\n" . ($other ? 'If it\'s easier, you can pay another way: ' . implode(', ', array_map('strtolower', $other)) . '. Choose it on your order page (the same link).' : 'If another way to pay is easier, call us at ' . self::wirePhone() . ' and we\'ll arrange it.') : '');
            self::mail($o, ($stage === 3 ? 'Still waiting on your payment' : 'Reminder: your payment') . ' for order #' . $no, $body);
            $what = ['', '2 hours', 'the next morning', '4 pm the next day'][$stage];
            try {
                Mailer::send((string) (getenv('SUPPORT_EMAIL') ?: 'support@traversence.com'), 'Payment reminder ' . $stage . ' of 3: order #' . $no,
                    $o['bill_name'] . ' chose to pay ' . $due . ' by ' . $way . ' (' . date('M j, g:i a', $chosen) . ') and hasn\'t given ' . ($o['pay_method'] === 'wire' ? 'a confirmation code' : 'a check number') . ' yet. Reminder ' . $stage . ' of 3 (' . $what . ') went to ' . $o['bill_email'] . ($stage === 3 ? ', with the other ways to pay' : '') . '.'
                    . (function () use ($pdo, $o) { $op = self::opens($pdo, (int) $o['id']); return $op['last'] ? "\n\nThey last opened their order page " . date('M j, g:i a', strtotime((string) $op['last'])) . ' (' . $op['n'] . ' visit' . ($op['n'] === 1 ? '' : 's') . ').' : "\n\nThey haven't opened their order page yet."; })()
                    . "\n\nA call may be quicker: " . ((string) ($o['client_phone'] ?? '') !== '' ? $o['client_phone'] : 'their phone is on the order') . '.'
                    . "\n\nThe order: " . rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/backoffice/orders/' . (int) $o['id'] . "#payhold\n\nTraversence");
            } catch (Throwable $e) { error_log('pay reminder to support: ' . $e->getMessage()); }
            Orders::event($pdo, (int) $o['id'], 'pay_nudge' . $stage, 'Payment reminder ' . $stage . ' of 3 (' . $what . ') sent to ' . $o['bill_email'] . ' and support');
            $n++;
        }
        return $n;
    }

    /**
     * The client opened their order page (Jason, 2026-10-28): told by the page itself once it's showing in a browser, so
     * a mail scanner that only fetches the link doesn't count, and our team viewing it doesn't either. One record per
     * visit (30 minutes apart), with the kind of device. Nothing else about them is kept.
     */
    public static function seen(PDO $pdo, array $o): void
    {
        $st = $pdo->prepare("SELECT MAX(created_at) FROM order_events WHERE order_id = ? AND event = 'client_opened'"); $st->execute([(int) $o['id']]);
        $last = $st->fetchColumn();
        if ($last && strtotime((string) $last) > time() - 1800) return;
        $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $dev = preg_match('/iPad|Tablet/i', $ua) ? 'a tablet' : (preg_match('/Mobi|Android|iPhone/i', $ua) ? 'a phone' : 'a computer');
        Orders::event($pdo, (int) $o['id'], 'client_opened', 'The client opened their order page, on ' . $dev);
    }

    /** When the client last opened their page, and how many visits: ['last' => datetime|null, 'n' => int]. */
    public static function opens(PDO $pdo, int $oid): array
    {
        $st = $pdo->prepare("SELECT MAX(created_at), COUNT(*) FROM order_events WHERE order_id = ? AND event = 'client_opened'"); $st->execute([$oid]);
        [$last, $n] = $st->fetch(PDO::FETCH_NUM) ?: [null, 0];
        return ['last' => $last ?: null, 'n' => (int) $n];
    }

    /** The client tells us it's sent: the wire's confirmation code, the check number. We record the money when it arrives. */
    public static function reportPay(PDO $pdo, array $o, string $ref): void
    {
        $oid = (int) $o['id'];
        if ($o['status'] !== 'pending' || !isset(self::offers($o)[$o['pay_method'] ?? ''])) throw new RuntimeException('Choose how you\'re paying first.');
        $ref = mb_substr(trim(preg_replace('/\s+/', ' ', $ref)), 0, 200);
        if ($ref === '') throw new RuntimeException($o['pay_method'] === 'wire' ? 'Enter the wire\'s confirmation code (from your bank).' : 'Enter the check number.');
        $pdo->prepare('UPDATE orders SET pay_report = ?, pay_reported_at = NOW() WHERE id = ?')->execute([$ref, $oid]);
        $m = self::CLIENT_METHODS[$o['pay_method']];
        Orders::event($pdo, $oid, 'pay_reported', 'The client says the ' . strtolower($m) . ' is sent: ' . $ref);
        self::mailStaff($pdo, $o, strtolower($m) === 'wire transfer' ? 'Wire sent: order #' . Orders::no($o) : $m . ' sent: order #' . Orders::no($o),
            $o['bill_name'] . ' says the ' . strtolower($m) . ' for ' . Orders::usd(self::dueNow($pdo, $o)) . ' is sent. Their reference: ' . $ref . ".\n\nWhen it's in your account, record it on the order (Record the payment).");
    }

    /**
     * An admin releases an approved order before payment (model 1.9: "Admin can override payment requirements to
     * initiate vendor work orders pre funding", "Admins only, with a reason recorded"): it can go to the vendor and be
     * released for delivery before the money is in; the reason is kept in the order's history. $outside: the outside path
     * (WorkOrders::processOutside, an order invoiced and paid outside Traversence), which isn't the override and needs no
     * admin. Work orders the vendor already shipped move the order on now (WorkOrders::catchUp).
     */
    public static function releaseHold(PDO $pdo, int $oid, int $staff, string $why = '', bool $outside = false): void
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] !== 'pending') throw new RuntimeException('Only an approved order waiting on payment can be released before payment.');
        $why = mb_substr(trim($why), 0, 300);
        if (!$outside) {
            [$ok, $no] = self::canRelease();
            if (!$ok) throw new RuntimeException('Only an admin can release an order before payment (' . $no . ').');
            if (self::overridden($pdo, $oid)) throw new RuntimeException('It\'s already released before payment.');
            if (self::vendorHold($pdo, $o) === '' && self::shipHold($pdo, $o) === '') throw new RuntimeException('Nothing on it is waiting for payment.');
            if (mb_strlen($why) < 3) throw new RuntimeException('Say why it goes ahead before payment: the reason is kept on the order.');
        }
        if ($o['stage'] === '') $pdo->prepare("UPDATE orders SET stage = 'production' WHERE id = ?")->execute([$oid]);
        Orders::event($pdo, $oid, 'released', $outside ? 'Handled outside Traversence: released to production (its payment is taken outside)'
            : 'Released before payment by an admin: ' . $why . ' (' . Orders::usd(max(0, (int) $o['total_cents'] - Orders::money($pdo, $oid)['paid'])) . ' still to come)', $staff);
        if (!$outside) { try { require_once __DIR__ . '/WorkOrders.php'; WorkOrders::catchUp($pdo, $oid); } catch (Throwable $x) { error_log('release catch up: ' . $x->getMessage()); } }
    }

    /** The client: emails as the order moves along (in production, shipped, our updates), or not. Receipts always go. */
    public static function setNotify(PDO $pdo, array $o, bool $on): void
    {
        if (!self::hasPayChoice($pdo)) return;
        $pdo->prepare('UPDATE orders SET notify_progress = ? WHERE id = ?')->execute([$on ? 1 : 0, (int) $o['id']]);
        if ((bool) ($o['notify_progress'] ?? 1) !== $on) Orders::event($pdo, (int) $o['id'], 'notify', $on ? 'The client wants progress emails' : 'The client turned off progress emails');
    }

    public static function wantsProgress(array $o): bool { return (int) ($o['notify_progress'] ?? 1) === 1; }

    private static function received(PDO $pdo, int $oid, int $cents, string $kind, string $method, string $ref, string $key, bool $receipt = true): void
    {
        if (!Orders::record($pdo, $oid, $kind, $cents, $key, $method, mb_substr($ref, 0, 60), $kind === 'deposit' ? 'Deposit' : 'Payment')) return;   // recorded already
        $o = Orders::get($pdo, $oid);
        $m = Orders::money($pdo, $oid);
        $full = $m['paid'] >= (int) $o['total_cents'];
        $lines = Orders::lines($pdo, $oid);
        $print = self::hasPrint($lines);
        if ($full) {
            $pdo->prepare("UPDATE orders SET status = IF(status = 'pending', 'paid', status), paid_at = COALESCE(paid_at, NOW()) WHERE id = ?")->execute([$oid]);
            require_once __DIR__ . '/QrIssue.php';
            $pdo->prepare("UPDATE qr_issued SET status = 'paid', issued_at = NOW() WHERE order_id = ? AND status = 'pending'")->execute([$oid]);
            $ids = $pdo->prepare("SELECT id FROM qr_issued WHERE order_id = ? AND status = 'paid'"); $ids->execute([$oid]);
            foreach ($ids->fetchAll(PDO::FETCH_COLUMN) as $id) QrIssue::issueShort($pdo, (int) $id);
            $pdo->prepare("UPDATE order_lines SET status = 'done' WHERE order_id = ? AND product = 'go_code' AND status = 'open'")->execute([$oid]);
        }
        // production starts once what releases it is in (B.3; model 1.8–1.9: paid in full, or a deposit order's deposit)
        $start = $m['paid'] >= self::releaseAt($o) || self::overridden($pdo, $oid);
        $toStart = max(0, self::releaseAt($o) - $m['paid']);
        if ($print && $o['stage'] === '' && $start) $pdo->prepare("UPDATE orders SET stage = 'production' WHERE id = ?")->execute([$oid]);
        if (!$print && $full) $pdo->prepare("UPDATE orders SET stage = 'complete' WHERE id = ?")->execute([$oid]);
        Orders::event($pdo, $oid, $kind === 'deposit' ? 'deposit_paid' : 'paid', ($kind === 'deposit' ? 'Deposit ' : 'Paid ') . Orders::usd($cents) . ' (' . $method . ($ref !== '' ? ', ' . $ref : '') . ')' . ($full ? '' : '; ' . Orders::usd((int) $o['total_cents'] - $m['paid']) . ' left'));
        $o = Orders::get($pdo, $oid);
        if ($receipt) self::mail($o, $full ? 'Thank you: order #' . Orders::no($o) . ' is paid' : 'Thank you: your deposit on order #' . Orders::no($o),
            'Hello ' . $o['bill_name'] . ",\n\nWe received " . Orders::usd($cents) . ($full ? ', so order #' . Orders::no($o) . ' is paid in full.' : ' toward order #' . Orders::no($o) . '. ' . Orders::usd((int) $o['total_cents'] - $m['paid'])
                . ($o['pay_mode'] === 'deposit' ? ' is left: it\'s due once production schedules your order, and it must be paid before your order is released for delivery.' : ' is left to pay.'))   // model 1.9
            . ($print ? ($start ? "\n\nYour printed items are in production; we'll email you as they move along." : "\n\nPrinting starts once " . Orders::usd($toStart) . ' more is paid.') : '')
            . ((int) $pdo->query("SELECT COUNT(*) FROM qr_issued WHERE order_id = $oid AND status = 'paid'")->fetchColumn() ? "\n\nYour GO Codes are ready to download from your order page." : '')
            . "\n\nYour order, its receipt and what's next:\n" . self::url($o));
        self::mailStaff($pdo, $o, ($full ? 'Paid' : 'Deposit paid') . ': order #' . Orders::no($o), Orders::usd($cents) . ' received from ' . $o['bill_name'] . ($full ? '' : ' (deposit)') . '.' . ($print ? ($start ? ' Its printed items are ready to order from the printer.' : ' Production and the vendor wait until ' . Orders::usd($toStart) . ' more is paid.') : ''));
        if ($full) { try { require_once __DIR__ . '/WorkOrders.php'; WorkOrders::catchUp($pdo, $oid); } catch (Throwable $x) { error_log('paid catch up: ' . $x->getMessage()); } }   // what the vendor shipped while it waited for payment moves on now
        // delivered with a balance due (decisions/0178 §6): the client already has it, so paid in full completes it, with the thank-you
        if ($full && !empty($o['received_at']) && ($o['stage'] ?? '') !== 'complete') self::complete($pdo, $oid, null);
    }

    // ---- promotions (decisions/0108) -------------------------------------------------------------------------------------
    // A code is attached while the order is a draft or out for review (our team or the client adds it) and comes off
    // the prices when the client approves: then each line's price is the price after it, and what it took off is kept.

    /** A line's kind for promotions: its own, its catalog product's, or a GO Code's. */
    public static function lineType(PDO $pdo, array $l): string
    {
        if (($l['service_type'] ?? '') !== '') return (string) $l['service_type'];
        if ($l['product'] === 'go_code') return 'go_code';
        if ($l['product'] === 'product' && $l['product_id']) {   // the catalog product's own type (none until 2026-12-23_promotions.sql is run)
            static $types = [];
            $pid = (int) $l['product_id'];
            if (!array_key_exists($pid, $types)) { try { $st = $pdo->prepare('SELECT service_type FROM ' . Database::t('products') . ' WHERE id = ?'); $st->execute([$pid]); $types[$pid] = (string) $st->fetchColumn(); } catch (Throwable $x) { $types[$pid] = ''; } }
            return $types[$pid];
        }
        return '';
    }

    /** The order's code and what it takes off: ['promo', 'lines' => [line id => [off a unit, capped]], 'off' => total], or null. */
    public static function promoPreview(PDO $pdo, array $o): ?array
    {
        if (empty($o['promo_id'])) return null;
        require_once __DIR__ . '/Promotions.php';
        try { $p = Promotions::get($pdo, (int) $o['promo_id']); } catch (Throwable) { return null; }
        $out = ['promo' => $p, 'lines' => [], 'off' => 0, 'applied' => false];
        foreach (Orders::lines($pdo, (int) $o['id']) as $l) {
            if ($l['status'] === 'cancelled') continue;
            if ((int) ($l['promo_off_cents'] ?? 0) > 0) { $out['applied'] = true; $out['lines'][(int) $l['id']] = [(int) $l['promo_off_cents'], false]; $out['off'] += (int) $l['promo_off_cents'] * (int) $l['qty']; continue; }
            [, $off, $capped] = Promotions::linePrice($p, self::lineType($pdo, $l), (int) $l['unit_cents'], (int) $l['cost_cents']);
            if ($off || $capped) $out['lines'][(int) $l['id']] = [$off, $capped];
            $out['off'] += $off * (int) $l['qty'];
        }
        return $out;
    }

    /** Puts a code on the order ('' takes it off). $who: the client (for "one use each"). */
    public static function setPromo(PDO $pdo, int $oid, string $code, ?int $staff = null): array
    {
        require_once __DIR__ . '/Promotions.php';
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || !self::editable($o)) throw new RuntimeException('A code can be added before the order is approved.');
        if (trim($code) === '') { $pdo->prepare('UPDATE orders SET promo_id = NULL WHERE id = ?')->execute([$oid]); Orders::event($pdo, $oid, 'note', 'Promo code taken off', $staff); return Orders::get($pdo, $oid); }
        $p = Promotions::check($pdo, $code, 'quote', ['type' => (int) $o['user_id'] ? 'user' : 'guest', 'id' => (int) $o['user_id'], 'uid' => (int) $o['user_id'], 'email' => (string) $o['bill_email']]);
        $pdo->prepare('UPDATE orders SET promo_id = ? WHERE id = ?')->execute([(int) $p['id'], $oid]);
        $o = Orders::get($pdo, $oid);
        $pv = self::promoPreview($pdo, $o);
        if (!$pv || !$pv['off']) { $pdo->prepare('UPDATE orders SET promo_id = NULL WHERE id = ?')->execute([$oid]); throw new RuntimeException('That code doesn\'t take anything off this order' . ($pv && array_filter(array_column($pv['lines'], 1)) ? ' (its prices are already at the lowest we can go).' : '.')); }
        Orders::event($pdo, $oid, 'note', 'Promo code ' . $p['code'] . ' added: ' . Promotions::offer($p) . ', ' . Orders::usd($pv['off']) . ' off', $staff);
        return $o;
    }

    /** At approval: the code comes off each line's price (once), and the use is recorded. */
    private static function applyPromo(PDO $pdo, array $o): void
    {
        $pv = self::promoPreview($pdo, $o);
        if (!$pv || $pv['applied']) return;
        $p = $pv['promo'];
        try { Promotions::check($pdo, (string) $p['code'], 'quote', ['type' => (int) $o['user_id'] ? 'user' : 'guest', 'id' => (int) $o['user_id'], 'uid' => (int) $o['user_id'], 'email' => (string) $o['bill_email']]); }
        catch (RuntimeException $x) { $pdo->prepare('UPDATE orders SET promo_id = NULL WHERE id = ?')->execute([(int) $o['id']]); Orders::event($pdo, (int) $o['id'], 'note', 'Promo code ' . $p['code'] . ' dropped at approval: ' . $x->getMessage()); return; }
        $up = $pdo->prepare('UPDATE order_lines SET unit_cents = unit_cents - ?, promo_off_cents = ? WHERE id = ? AND promo_off_cents = 0');
        foreach ($pv['lines'] as $lid => [$off]) if ($off > 0) $up->execute([$off, $off, $lid]);
        self::recalc($pdo, (int) $o['id']);
        Promotions::redeem($pdo, $p, ['type' => (int) $o['user_id'] ? 'user' : 'guest', 'id' => (int) $o['user_id'], 'email' => (string) $o['bill_email']], (int) $pv['off'], (int) $o['id']);
    }

    // ---- helpers ---------------------------------------------------------------------------------------------------------


    // ---- projects, bundles and released files (decisions/0101, addendum 2026-10-27) ------------------------------------
    // An order holds projects; a project holds items, each with its own setup and its own proofs (creative concept
    // rounds, or a print item's print-ready file). The client sees each item's price and the project's subtotal, never
    // the lines bundled inside an item. Approval is the release for use, once the order is paid in full: in a project
    // with print, the print items' approved files; a creative item's approved artwork stays view only. A project with no
    // print releases the creative item's print-ready file (uploaded by our team after approval). Earlier rounds are ours.

    public static function hasProjects(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT project_id FROM order_lines LIMIT 0'); $pdo->query('SELECT 1 FROM order_projects LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }

    public static function projects(PDO $pdo, int $oid): array
    {
        if (!self::hasProjects($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM order_projects WHERE order_id = ? ORDER BY position, id'); $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * The order's items as projects, in order: ['project' => row or null, 'lines' => [...], 'subtotal' => cents]. An
     * item in no project stands as its own (null project); a project shows where its first item is, empty ones last.
     */
    public static function groups(array $lines, array $projects): array
    {
        $byId = []; foreach ($projects as $p) $byId[(int) $p['id']] = $p;
        $out = []; $seen = [];
        foreach ($lines as $l) {
            $pid = (int) ($l['project_id'] ?? 0);
            if ($pid && isset($byId[$pid])) {
                if (isset($seen[$pid])) continue;
                $seen[$pid] = true;
                $ls = array_values(array_filter($lines, fn ($x) => (int) ($x['project_id'] ?? 0) === $pid));
                $out[] = ['project' => $byId[$pid], 'lines' => $ls];
            } else $out[] = ['project' => null, 'lines' => [$l]];
        }
        foreach ($projects as $p) if (!isset($seen[(int) $p['id']])) $out[] = ['project' => $p, 'lines' => []];
        foreach ($out as &$g) $g['subtotal'] = array_sum(array_map(fn ($l) => (int) $l['unit_cents'] * (int) $l['qty'] + (int) ($l['ship_cents'] ?? 0), $g['lines']));
        return $out;
    }

    public static function addProject(PDO $pdo, int $oid, string $title, int $staff): int
    {
        self::mine($pdo, $oid, true);
        $title = mb_substr(trim($title), 0, 160);
        if ($title === '') throw new RuntimeException('Name the project.');
        $pos = (int) $pdo->query('SELECT COALESCE(MAX(position), 0) + 1 FROM order_projects WHERE order_id = ' . $oid)->fetchColumn();
        $pdo->prepare('INSERT INTO order_projects (order_id, title, position, created_at) VALUES (?, ?, ?, NOW())')->execute([$oid, $title, $pos]);
        $id = (int) $pdo->lastInsertId();
        Orders::event($pdo, $oid, 'project', 'Project: ' . $title, $staff);
        return $id;
    }

    public static function renameProject(PDO $pdo, int $oid, int $pid, string $title, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $title = mb_substr(trim($title), 0, 160);
        if ($title === '') throw new RuntimeException('Name the project.');
        $pdo->prepare('UPDATE order_projects SET title = ? WHERE id = ? AND order_id = ?')->execute([$title, $pid, $oid]);
    }

    /** Takes a project away; its items stay on the order, each on its own. */
    public static function removeProject(PDO $pdo, int $oid, int $pid, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $pdo->prepare('UPDATE order_lines SET project_id = NULL WHERE order_id = ? AND project_id = ?')->execute([$oid, $pid]);
        $pdo->prepare('DELETE FROM order_projects WHERE id = ? AND order_id = ?')->execute([$pid, $oid]);
        Orders::event($pdo, $oid, 'project', 'Project taken off (its items stay)', $staff);
    }

    /** Puts an item in a project ($pid 0: on its own). Its proofs and files go with it. */
    public static function setLineProject(PDO $pdo, int $oid, int $lineId, int $pid, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        if ($pid) { $st = $pdo->prepare('SELECT title FROM order_projects WHERE id = ? AND order_id = ?'); $st->execute([$pid, $oid]); if ($st->fetchColumn() === false) throw new RuntimeException('That project isn\'t on this order.'); }
        $pdo->prepare('UPDATE order_lines SET project_id = ? WHERE id = ?')->execute([$pid ?: null, $lineId]);
        Orders::event($pdo, $oid, 'project', $l['title'] . ($pid ? ': moved into a project' : ': on its own'), $staff, $lineId);
    }

    /** An item's role for files: creative, print, or other (additional work, GO Codes, shipping). */
    public static function role(PDO $pdo, array $l): string
    {
        if (in_array($l['product'], ['go_code', 'shipping'], true)) return 'other';
        $t = self::lineType($pdo, $l);
        if ($t === 'creative' || $t === 'print') return $t;
        return $t === '' && $l['product'] === 'product' ? 'print' : 'other';
    }

    // ---- an item's bundled lines (our team only) ----
    public static function partsOf(PDO $pdo, array $lineIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $lineIds)));
        if (!$ids) return [];
        $out = [];
        foreach ($pdo->query('SELECT * FROM order_line_parts WHERE line_id IN (' . implode(',', $ids) . ') ORDER BY position, id') as $r) $out[(int) $r['line_id']][] = $r;
        return $out;
    }

    public static function addPart(PDO $pdo, int $oid, int $lineId, string $title, int $qty, string $price, string $cost, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $l = self::line($pdo, $oid, $lineId);
        if (in_array($l['product'], ['product', 'go_code', 'shipping'], true)) throw new RuntimeException('A catalog product, GO Code or shipping line can\'t be a bundle. Add a custom item for the service and bundle its lines there.');
        $title = mb_substr(trim($title), 0, 160);
        if ($title === '') throw new RuntimeException('Describe the line.');
        $parts = self::partsOf($pdo, [$lineId])[$lineId] ?? [];
        if (!$parts) {   // the item's price so far becomes its first line, so nothing is lost
            $pdo->prepare('INSERT INTO order_line_parts (line_id, title, qty, unit_cents, cost_cents, position, created_at) VALUES (?, ?, ?, ?, ?, 0, NOW())')
                ->execute([$lineId, mb_substr((string) $l['title'], 0, 160), max(1, (int) $l['qty']), (int) $l['unit_cents'], (int) $l['cost_cents']]);
        }
        $pdo->prepare('INSERT INTO order_line_parts (line_id, title, qty, unit_cents, cost_cents, position, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())')
            ->execute([$lineId, $title, max(1, $qty), self::cents($price), trim($cost) === '' ? 0 : self::cents($cost), count($parts) + 1]);
        self::syncParts($pdo, $oid, $lineId);
        Orders::event($pdo, $oid, 'line_changed', $l['title'] . ': bundled ' . $title, $staff, $lineId);
    }

    public static function setPart(PDO $pdo, int $oid, int $partId, string $f, string $v, int $staff): void
    {
        self::mine($pdo, $oid, true);
        $st = $pdo->prepare('SELECT p.* FROM order_line_parts p JOIN order_lines l ON l.id = p.line_id WHERE p.id = ? AND l.order_id = ?'); $st->execute([$partId, $oid]);
        $p = $st->fetch(PDO::FETCH_ASSOC);
        if (!$p) throw new RuntimeException('That line isn\'t on this order.');
        $v = trim($v);
        if ($f === 'title') { if ($v === '') throw new RuntimeException('Describe the line.'); $pdo->prepare('UPDATE order_line_parts SET title = ? WHERE id = ?')->execute([mb_substr($v, 0, 160), $partId]); }
        elseif ($f === 'qty') { if (!preg_match('/^\d+$/', str_replace(',', '', $v))) throw new RuntimeException('Enter how many, like 6.'); $pdo->prepare('UPDATE order_line_parts SET qty = ? WHERE id = ?')->execute([max(1, (int) str_replace(',', '', $v)), $partId]); }
        elseif ($f === 'unit') $pdo->prepare('UPDATE order_line_parts SET unit_cents = ? WHERE id = ?')->execute([self::cents($v), $partId]);
        elseif ($f === 'cost') $pdo->prepare('UPDATE order_line_parts SET cost_cents = ? WHERE id = ?')->execute([$v === '' ? 0 : self::cents($v), $partId]);
        elseif ($f === 'remove') $pdo->prepare('DELETE FROM order_line_parts WHERE id = ?')->execute([$partId]);
        else throw new RuntimeException('That can\'t be changed here.');
        self::syncParts($pdo, $oid, (int) $p['line_id']);
    }

    /** A bundle's price is its lines': the item becomes one of it, at their total (and our cost, theirs). */
    private static function syncParts(PDO $pdo, int $oid, int $lineId): void
    {
        $parts = self::partsOf($pdo, [$lineId])[$lineId] ?? [];
        if ($parts) {
            $sum = array_sum(array_map(fn ($p) => (int) $p['qty'] * (int) $p['unit_cents'], $parts));
            $cost = array_sum(array_map(fn ($p) => (int) $p['qty'] * (int) $p['cost_cents'], $parts));
            $pdo->prepare('UPDATE order_lines SET qty = 1, unit_cents = ?, list_cents = ?, cost_cents = ? WHERE id = ?')->execute([$sum, $sum, $cost, $lineId]);
        }
        self::recalc($pdo, $oid);
    }

    /** The choices a catalog item has now, for its Change options form (option index => label). */
    public static function pickedOf(PDO $pdo, array $l): array
    {
        $p = $l['product'] === 'product' && $l['product_id'] ? Products::get($pdo, (int) $l['product_id']) : null;
        return $p ? Products::pickedFrom($p, (string) $l['options']) : [];
    }

    // ---- what the client may open ----
    public static function paidInFull(PDO $pdo, array $o): bool
    {
        if (in_array($o['status'], ['paid', 'part_refunded'], true)) return true;
        return !empty($o['approved_at']) && (int) $o['total_cents'] > 0 && Orders::money($pdo, (int) $o['id'])['paid'] >= (int) $o['total_cents'];
    }

    /** The proof version the client sees for an item: its latest one (earlier rounds are ours alone). */
    public static function clientProofs(array $l): array
    {
        return $l['proof'] && $l['proof']['status'] !== 'replaced' ? array_values(array_filter($l['proof_files'], fn ($f) => empty($f['retired_at']))) : [];   // a retired file isn't the client's to see
    }

    private static function approvedFiles(array $l): array
    {
        foreach (array_reverse($l['versions'] ?? [], true) as $files) if ($files && $files[0]['status'] === 'approved') return array_values(array_filter($files, fn ($f) => empty($f['retired_at'])));
        return [];
    }

    /**
     * The files released to the client (line id => files), once the order is paid in full: a print item's approved
     * print-ready files; in a project with no print, its creative items' print-ready files once their proof is approved.
     */
    public static function released(PDO $pdo, array $o, array $lines): array
    {
        if (!self::paidInFull($pdo, $o)) return [];
        $out = [];
        foreach (self::groups($lines, self::projects($pdo, (int) $o['id'])) as $g) {
            $hasPrint = (bool) array_filter($g['lines'], fn ($l) => self::role($pdo, $l) === 'print');
            foreach ($g['lines'] as $l) {
                $r = self::role($pdo, $l);
                if ($r === 'print' && ($f = self::approvedFiles($l))) $out[(int) $l['id']] = $f;
                elseif ($r === 'creative' && !$hasPrint && self::approvedFiles($l) && ($fin = array_values(array_filter($l['finals'], fn ($f) => empty($f['retired_at']))))) $out[(int) $l['id']] = $fin;
            }
        }
        return $out;
    }

    /** May the client open this file ($download: save it, not just see it)? Our team may open any. */
    public static function clientMay(PDO $pdo, array $o, array $p, bool $download): bool
    {
        if (!empty($p['retired_at'])) return false;   // retired: our team only
        $lines = self::lines($pdo, (int) $o['id']);
        $rel = self::released($pdo, $o, $lines);
        foreach ($rel[(int) $p['line_id']] ?? [] as $f) if ((int) $f['id'] === (int) $p['id']) return true;
        if (($p['kind'] ?? 'proof') === 'final') return false;
        if ($download && $p['status'] !== 'waiting') return false;   // the proof waiting for their OK downloads (Jason, 2026-10-28); others once released
        foreach ($lines as $l) if ((int) $l['id'] === (int) $p['line_id']) foreach (self::clientProofs($l) as $f) if ((int) $f['id'] === (int) $p['id']) return true;
        return false;
    }

    /** A creative item's print-ready file (no print in its project), uploaded after its proof is approved. */
    public static function finalFromUpload(PDO $pdo, int $oid, int $lineId, Upload $u, int $staff): array
    {
        if (!self::hasProjects($pdo)) throw new RuntimeException('Run 2026-12-27_order_projects.sql first.');
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o) || $o['status'] === 'void') throw new RuntimeException('That order isn\'t here.');
        $l = null; foreach (self::lines($pdo, $oid) as $x) if ((int) $x['id'] === $lineId) $l = $x;
        if (!$l || self::role($pdo, $l) !== 'creative') throw new RuntimeException('A print-ready file goes on a creative item.');
        if (!self::approvedFiles($l)) throw new RuntimeException('The client approves the artwork first; then add its print-ready file.');
        $mime = (string) (array_search($u->ext === 'jpeg' ? 'jpg' : ($u->ext === 'tiff' ? 'tif' : $u->ext), self::ART_TYPES, true) ?: '');
        if ($mime === '') throw new InvalidArgumentException($u->name . ': use PDF, an image, SVG, TIFF, EPS, PSD, AI or ZIP.');
        $v = (int) $pdo->query("SELECT COALESCE(MAX(version), 0) FROM order_proofs WHERE line_id = $lineId AND kind = 'final'")->fetchColumn() + 1;
        $pdo->prepare("INSERT INTO order_proofs (order_id, line_id, version, file_name, mime, status, kind, created_by, created_at) VALUES (?, ?, ?, ?, ?, 'approved', 'final', ?, NOW())")
            ->execute([$oid, $lineId, $v, mb_substr($u->name, 0, 160), $mime, $staff]);
        $pid = (int) $pdo->lastInsertId();
        try { $u->moveTo(self::proofPlace($pdo, ['id' => $pid, 'order_id' => $oid, 'mime' => $mime])); }
        catch (Throwable $x) { $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$pid]); throw $x; }
        Orders::event($pdo, $oid, 'proof', 'Print-ready file for ' . $l['title'] . ': ' . $u->name, $staff, $lineId);
        return ['proof' => $pid, 'message' => $u->name . ' added as the print-ready file. The client gets it once the order is paid in full.'];
    }

    /** Takes a print-ready file off (our team). */
    public static function removeFinal(PDO $pdo, int $oid, int $pid, int $staff): void
    {
        $p = self::proof($pdo, $oid, $pid);
        if (!$p || ($p['kind'] ?? '') !== 'final') throw new RuntimeException('That file isn\'t here.');
        require_once __DIR__ . '/Store.php'; Store::remove(self::proofPath($p));
        $pdo->prepare('DELETE FROM order_proofs WHERE id = ?')->execute([$pid]);
        Orders::event($pdo, $oid, 'proof', 'Print-ready file taken off: ' . $p['file_name'], $staff, (int) $p['line_id']);
    }

    private static function mine(PDO $pdo, int $oid, bool $editing = false): array
    {
        $o = Orders::get($pdo, $oid);
        if (!$o || !self::isClient($o)) throw new RuntimeException('That order isn\'t here.');
        if ($editing && !self::editable($o)) throw new RuntimeException('The client has approved this order, so it can\'t be changed here. Use Fix, Credit or Refund on the order page.');
        return $o;
    }

    /** An item with its own costing (its Cost tab, decisions/0130): its cost is that COGS, not the catalog's. */
    public static function costed(PDO $pdo, int $lineId): bool
    {
        try { $st = $pdo->prepare('SELECT 1 FROM order_line_costs WHERE line_id = ?'); $st->execute([$lineId]); return (bool) $st->fetchColumn(); } catch (Throwable) { return false; }
    }

    /** One line of an order, or an error when it isn't on it. */
    public static function line(PDO $pdo, int $oid, int $lineId): array
    {
        $st = $pdo->prepare('SELECT * FROM order_lines WHERE id = ? AND order_id = ?'); $st->execute([$lineId, $oid]);
        $l = $st->fetch(PDO::FETCH_ASSOC);
        if (!$l) throw new RuntimeException('That line isn\'t on this order.');
        return $l;
    }

    public static function recalcOrder(PDO $pdo, int $oid): void { self::recalc($pdo, $oid); }

    /**
     * The order's item count, subtotal and total from its lines (and destinations' estimates) while it's a draft or out for
     * review. Once approved, its money is the invoice's (with its tax): only the item count follows, so a later edit
     * (shipping set or a destination saved) never rewrites the total to the pre-tax subtotal.
     */
    private static function recalc(PDO $pdo, int $oid): void
    {
        $st = $pdo->prepare("SELECT COUNT(*) AS n, COALESCE(SUM(qty * unit_cents" . (self::hasShip($pdo) ? ' + ship_cents' : '') . "), 0) AS s FROM order_lines WHERE order_id = ? AND status <> 'cancelled'"); $st->execute([$oid]);   // per-item shipping is part of the total
        $r = $st->fetch(PDO::FETCH_ASSOC);
        require_once __DIR__ . '/Shipments.php';
        $s = (int) $r['s'] + (($o = Orders::get($pdo, $oid)) ? Shipments::estimateCents($pdo, $o) : 0);   // the destinations' shipping estimates are part of the total
        if ($o && !in_array((string) $o['status'], ['draft', 'sent'], true)) { $pdo->prepare('UPDATE orders SET items = ? WHERE id = ?')->execute([(int) $r['n'], $oid]); return; }
        $pdo->prepare('UPDATE orders SET items = ?, subtotal_cents = ?, total_cents = ? WHERE id = ?')->execute([(int) $r['n'], $s, $s, $oid]);
    }


    /** How many a line is for: a catalog line's run size (in its title, "… · 500"), else its quantity. */
    public static function runQty(array $l): int
    {
        if ($l['product'] !== 'product') return max(1, (int) $l['qty']);
        $n = (int) ($l['run_qty'] ?? 0) ?: self::runInTitle((string) $l['title']);   // kept on its own (2026-12-28_order_run_qty.sql), else read from its name
        return $n > 0 ? $n * max(1, (int) $l['qty']) : max(1, (int) $l['qty']);
    }

    /** A run size in an item's name ("… · 1,000"), or 0. */
    public static function runInTitle(string $t): int { $tail = strrchr($t, '·'); return $tail !== false && preg_match('/^·[^\d]*?(\d[\d,]*)/u', $tail, $m) ? (int) str_replace(',', '', $m[1]) : 0; }

    /** The name with its run size changed: the number after its last "·" ("… · 1,000 - EN version"), else " · N" added. */
    public static function titleWithRun(string $t, int $n): string
    {
        $at = strrpos($t, '·');
        if ($at !== false && self::runInTitle($t) > 0) return substr($t, 0, $at) . preg_replace('/\d[\d,]*/u', number_format($n), substr($t, $at), 1);
        return rtrim($t) . ' · ' . number_format($n);
    }

    /** How many, as typed: "1,000", "1 000", "1000 pcs" (and the hard space an in-place edit can leave) → 1000; else -1. */
    public static function countIn(string $v): int
    {
        $v = trim(str_replace(["\u{00A0}", "\u{202F}", ',', ' '], '', $v));
        return preg_match('/^(\d+)[^\d]*$/u', $v, $m) ? (int) $m[1] : -1;
    }

    /** Is a catalog item's run size known (kept, or in its name)? Renamed before it was kept: not until it's set again. */
    public static function runKnown(array $l): bool { return (int) ($l['run_qty'] ?? 0) > 0 || self::runInTitle((string) $l['title']) > 0; }

    public static function hasRunQty(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT run_qty FROM order_lines LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }

    /** Each item's rate, for showing: the line's total ÷ how many (up to 4 decimals, at least 2: 17.59, 0.0425). */
    public static function rate(array $l): string
    {
        $r = number_format(((int) $l['unit_cents'] * max(1, (int) $l['qty'])) / 100 / self::runQty($l), 4, '.', '');
        return preg_replace('/(\.\d\d)0{1,2}$/', '$1', $r);
    }

    /** A rate typed for each item (up to 4 decimals) × how many → the run's price in cents. */
    public static function rateTotal(string $s, int $n): int
    {
        $s = str_replace([',', '$', ' ', "\u{00A0}", "\u{202F}"], '', trim($s));   // the hard space an in-place edit can leave
        $s = preg_replace('/^(\d*\.\d{4})0+$/', '$1', $s);   // 0.12250 is 0.1225
        if (!preg_match('/^(\d+(\.\d{1,4})?|\.\d{1,4})$/', $s)) throw new RuntimeException('Enter the rate in dollars for each one, up to 4 decimals: 17.59, 0.1225 or .0425.');
        return (int) round(((float) $s) * max(1, $n) * 100);
    }

    public static function cents(string $s): int
    {
        $s = str_replace([',', '$', ' '], '', trim($s));
        if (!preg_match('/^\d+(\.\d{1,2})?$/', $s)) throw new RuntimeException('Enter the price in dollars, like 29.00.');
        return (int) round(((float) $s) * 100);
    }

    /** The client's email; false when it didn't go (no address, or the sender refused it), so the words can say so. */
    private static function mail(array $o, string $subject, string $body): bool
    {
        if (!filter_var((string) $o['bill_email'], FILTER_VALIDATE_EMAIL)) return false;
        try {
            require_once __DIR__ . '/Mailer.php';
            Mailer::send((string) $o['bill_email'], $subject, $body . "\n\nQuestions? Reply to this email, or write to support@traversence.com.\n\nTraversence", (string) $o['bill_name'] ?: null);
            return true;
        } catch (Throwable $e) { error_log('client order email: ' . $e->getMessage()); return false; }
    }

    /** Whether the last send() reached the client's inbox (null: no email was meant). */
    public static ?bool $mailed = null;

    private static function mailStaff(PDO $pdo, array $o, string $subject, string $body): void
    {
        try {
            require_once __DIR__ . '/Mailer.php';
            Mailer::send(self::staffEmail($pdo, $o), $subject, $body . "\n\nThe order: " . rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/backoffice/orders/' . (int) $o['id'] . "\n\nTraversence");
        } catch (Throwable $e) { error_log('client order staff email: ' . $e->getMessage()); }
    }
}
