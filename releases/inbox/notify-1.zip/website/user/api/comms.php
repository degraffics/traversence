<?php
// /user/api/comms.php — the person's Communications setting (decisions/0172 §4.4): what reaches them, by which channel,
// and their quiet hours. It takes in the Notices settings (notice kinds are listed here with the rest). Signed in; POSTs
// need X-CSRF-Token.
//   GET                                   -> {kinds: [{kind, name, what, level, group, pulse, pulse_fixed, email, email_fixed}],
//                                             quiet: {from, to, tz}|null, digest, digest_on, ready, csrf}
//   POST {kind, via: pulse|email, on}     one kind × channel
//   POST {quiet: {from: "HH:MM", to: "HH:MM", tz}} or {quiet: null}   quiet hours on, or off
//   POST {digest: bool}                   the weekly email of notices

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/Notify.php';
require_once __DIR__ . '/../../../app/lib/Roles.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$uid = (int) $me['id'];
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $who = ['member'];   // a business's kinds show to whoever is on a business's team
        foreach (Roles::contexts($pdo, $uid) as $c) if ($c['kind'] === 'org' && empty($c['scope']['preview'])) { $who[] = 'business'; break; }
        Response::json(['ok' => true, 'csrf' => $_SESSION['csrf_token'] ?? null] + Notify::settings($pdo, $uid, $who));
    }
    Response::requireMethod('POST');
    Response::requireCsrf();
    $b = Response::jsonBody();
    if (array_key_exists('quiet', $b)) {
        $q = $b['quiet'];
        Notify::setQuiet($pdo, $uid, is_array($q) ? (string) ($q['from'] ?? '') : null, is_array($q) ? (string) ($q['to'] ?? '') : null, is_array($q) ? (string) ($q['tz'] ?? '') : '');
        Response::json(['ok' => true, 'quiet' => Notify::quiet($pdo, $uid)]);
    }
    if (array_key_exists('digest', $b)) { Notify::setDigest($pdo, $uid, !empty($b['digest'])); Response::json(['ok' => true]); }
    Notify::setChannel($pdo, $uid, (string) ($b['kind'] ?? ''), (string) ($b['via'] ?? ''), !empty($b['on']));
    Response::json(['ok' => true]);
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'not_allowed');
}
