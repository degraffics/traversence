<?php
// /user/api/bell.php — the bell's count (decisions/0172 §6 step 2, gap 6): everything unread for this person at Alert or
// above, from where each lives. Signed in.
//   GET -> {ok, requests, contact_asks, unread, message_requests, from_businesses, business_messages, guest_questions, sent_to_you}
// Each is a count; the header's bell adds them up (js/header-nav.js). Business messages and guest questions count for
// the listings this person helps run.

declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
require_once __DIR__ . '/../../../app/lib/People.php';
require_once __DIR__ . '/../../../app/lib/BizMessages.php';
require_once __DIR__ . '/../../../app/lib/Notify.php';

header('Cache-Control: no-store');
$me = Auth::currentUser();
if ($me === null) Response::error('Please sign in.', 401, 'unauthenticated');
$pdo = Database::connection();
$uid = (int) $me['id'];
$out = ['requests' => 0, 'contact_asks' => 0, 'unread' => 0, 'message_requests' => 0, 'from_businesses' => 0, 'business_messages' => 0, 'guest_questions' => 0, 'sent_to_you' => 0];
$try = function (string $k, callable $f) use (&$out) { try { $out[$k] = (int) $f(); } catch (Throwable $e) { error_log('bell ' . $k . ': ' . $e->getMessage()); } };
if (People::tableExists($pdo)) { try { $out = array_merge($out, array_map('intval', People::waiting($pdo, $uid))); } catch (Throwable $e) { error_log('bell people: ' . $e->getMessage()); } }
if (BizMessages::ready($pdo)) {
    $try('from_businesses', fn () => BizMessages::personUnread($pdo, $uid));
    $try('business_messages', fn () => BizMessages::staffUnread($pdo, $uid));
}
if (is_file(__DIR__ . '/../../../app/lib/GuestInquiries.php')) {
    require_once __DIR__ . '/../../../app/lib/GuestInquiries.php';
    $try('guest_questions', fn () => GuestInquiries::ready($pdo) ? GuestInquiries::staffUnread($pdo, $uid) : 0);
}
$try('sent_to_you', fn () => Notify::unreadForBell($pdo, $uid));
Response::json(['ok' => true] + $out);
