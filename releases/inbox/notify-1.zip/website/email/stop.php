<?php
// /email/stop.php?t=… — "Stop these" from an email the one dispatcher sent (decisions/0172, Notify; 0141 §5): stops
// that kind of message by email for that person. It still reaches their Pulse. A visit shows what it stops and a
// button; no sign-in needed (the link is signed, Notify::stopUrl). Choose again any time in the Communications setting.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/../../app/lib/Notify.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';

$pdo = Database::connection();
$t = (string) ($_GET['t'] ?? $_POST['t'] ?? '');
$row = Notify::fromStop($pdo, $t);
$done = false;
if ($row && $row['can'] && $_SERVER['REQUEST_METHOD'] === 'POST') { Notify::stop($pdo, $row); $done = true; }

tv_page_start('Stop these emails', ['no_crumbs' => true]);
?>
<div class="max-w-xl tv-bleed" style="background:#F7EFDC;border:1px solid rgba(203,185,141,.7);border-radius:.5rem;padding:1rem 1.1rem">
  <h1 class="font-serif font-bold text-2xl text-[#3E2B1F]">Stop these emails</h1>
  <?php if (!$row): ?>
    <p class="mt-2" data-tv-status="bad" data-tv-label="Not found:">This link isn't valid. Use the link in the email itself, or choose what you get in <a class="underline" href="/user/dashboard.php#settings">Dashboard → App Settings → Communications</a>. Still stuck? Write to us at <a class="underline" href="mailto:support@traversence.com">support@traversence.com</a>.</p>
  <?php elseif (!$row['can']): ?>
    <p class="mt-2" data-tv-status="info" data-tv-label="Always sent:">"<?= tv_e($row['name']) ?>" always comes by email: it's about your account's safety.</p>
  <?php elseif ($done): ?>
    <p class="mt-2" data-tv-flash="ok" data-tv-status="ok" data-tv-label="Done:">You won't get "<?= tv_e($row['name']) ?>" by email any more. It still reaches your Pulse.</p>
    <p class="text-sm mt-2">Changed your mind? Signed in, switch it back on in <a class="underline" href="/user/dashboard.php#settings">Dashboard → App Settings → Communications</a>.</p>
  <?php else: ?>
    <p class="text-sm mt-2">This stops "<?= tv_e($row['name']) ?>" by email. It still reaches your Pulse.</p>
    <form method="post" class="mt-3"><input type="hidden" name="t" value="<?= tv_e($t) ?>"><button class="font-semibold" style="background:#3E2B1F;color:#EFE3C8;border-radius:.6rem;padding:.5rem 1rem" type="submit">Stop them</button></form>
  <?php endif; ?>
</div>
<?php tv_page_end();
