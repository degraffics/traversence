<?php
// app/lib/Notices.php — notices sent once (decisions/0137 §6). A notice goes to someone who asked for it or needs it to
// act, and once: one per person, per thing, per reason (notices_sent's unique key), however often the same thing
// happens again. It shows in the person's Pulse (MemberPulse::stream, the Community source) until seen. Each kind can be
// switched off in Dashboard → App Settings → Communications (notice_prefs). Each person also chooses how notices reach
// them: by email per kind (comms_prefs, decisions/0172; notice_delivery's "by email as they happen" is the default for
// those who chose it before), or a weekly digest (notice_delivery). Email goes through Amazon SES (SesMail, the personal
// account, from notices@send.traversence.com), never Bluehost (0137 §8). Sending goes through Notify (0172 step 2).
declare(strict_types=1);

final class Notices
{
    /** The kinds, as a person sees them in App Settings: key => [what it tells you, why]. */
    public const KINDS = [
        'group_join'    => ['Your request to join a group is answered', 'You asked to join and are waiting.'],
        'group_charter' => ['A group you\'re in changes its charter', 'What you agreed to has changed.'],
        'group_post'    => ['A group\'s moderators remove your post', 'So you know what happened to it.'],
        'group_near'    => ['A new group starts in a place you follow', 'You follow the place.'],
        'group_invite'  => ['One of your connections invites you to a group', 'You\'re connected with them. Switch this off to get no group invitations.'],
        'group_chapter' => ['News about chapters of a group you run or lead', 'A chapter asked to start, opened, changed lead, or is leaving.'],
        'group_about'   => ['A group lists your business among the places it\'s about', 'You run the business, and can take it off the group\'s list.'],
        'guide_ready'   => ['A guide you asked us to build is ready', 'You tapped Notify me while it was being built.'],
        'moment_ending' => ['A post of yours ends tomorrow', 'So you can Keep it before its photos and videos are deleted.'],
        'post_comment'  => ['Someone comments on your post', 'It\'s your post.'],
    ];

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM notices_sent LIMIT 0'); $pdo->query('SELECT 1 FROM notice_prefs LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    /**
     * Sends a notice to these people, once each for this kind and thing; skips anyone who switched the kind off. Returns
     * how many went. Since decisions/0172 step 2 it goes through the one dispatcher (Notify, kind 'notice.<kind>'): the
     * notice still lands in notices_sent once per person, kind and thing, and is emailed by SES to those who chose email
     * (now per kind, in Dashboard → App Settings → Communications), waiting for their quiet hours if they set them.
     */
    public static function send(PDO $pdo, array $userIds, string $kind, string $thing, string $title, string $body = '', string $url = ''): int
    {
        if (!self::ready($pdo) || !isset(self::KINDS[$kind])) return 0;
        $ids = array_values(array_unique(array_filter(array_map('intval', $userIds), fn ($i) => $i > 0)));
        if (!$ids) return 0;
        require_once __DIR__ . '/Notify.php';
        return Notify::send($pdo, 'notice.' . $kind, ['users' => $ids], ['thing' => $thing, 'url' => $url], ['title' => $title, 'body' => $body]);
    }

    public const DELIVERY = ['pulse' => 'In my Pulse only', 'email' => 'In my Pulse, and by email as they happen', 'digest' => 'In my Pulse, and a weekly email of them'];

    public static function deliveryReady(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) { try { $pdo->query('SELECT 1 FROM notice_delivery LIMIT 0'); $ok = true; } catch (Throwable) { $ok = false; } }
        return $ok;
    }

    /** Whether email can go at all (SES switched on and its tables there). */
    public static function emailOn(PDO $pdo): bool
    {
        if (!is_file(__DIR__ . '/SesMail.php')) return false;
        require_once __DIR__ . '/SesMail.php';
        return self::deliveryReady($pdo) && SesMail::mode() !== 'off' && SesMail::ready($pdo);
    }

    public static function delivery(PDO $pdo, int $uid): string
    {
        if (!self::deliveryReady($pdo)) return 'pulse';
        $st = $pdo->prepare('SELECT how FROM notice_delivery WHERE user_id = ?'); $st->execute([$uid]);
        $h = (string) $st->fetchColumn();
        return isset(self::DELIVERY[$h]) ? $h : 'pulse';
    }

    public static function setDelivery(PDO $pdo, int $uid, string $how): void
    {
        if (!isset(self::DELIVERY[$how])) throw new InvalidArgumentException('Choose how you get notices.');
        if (!self::deliveryReady($pdo)) throw new InvalidArgumentException('Notices by email aren\'t switched on yet.');
        $pdo->prepare('INSERT INTO notice_delivery (user_id, how) VALUES (?, ?) ON DUPLICATE KEY UPDATE how = VALUES(how)')->execute([$uid, $how]);
    }

    /** One notice by email, for someone who chose that: through SES, personal account. Never throws; says whether it went (Notify writes it on the route). */
    public static function emailOne(PDO $pdo, int $uid, string $title, string $body, string $url): bool
    {
        try {
            $st = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ? AND is_suspended = 0'); $st->execute([$uid]);
            $u = $st->fetch(PDO::FETCH_ASSOC); if (!$u || (string) $u['email'] === '') return false;
            $link = $url !== '' && $url !== '#' ? 'https://traversence.com' . $url : 'https://traversence.com/user/dashboard.php#pulse';
            SesMail::send($pdo, ['account' => 'personal', 'from_local' => 'notices', 'from_domain' => 'send.traversence.com', 'from_name' => 'Traversence',
                'to' => (string) $u['email'], 'to_name' => (string) $u['display_name'], 'subject' => $title, 'text' => $title . "\n\n" . ($body !== '' ? $body . "\n\n" : '') . $link,
                'sender' => 'traversence', 'purpose' => 'notice', 'user_id' => $uid, 'scope' => 'notices',
                'why' => 'You chose to get Traversence notices by email (Dashboard → App Settings → Communications).']);
            return true;
        } catch (Throwable $e) { error_log('notice email: ' . $e->getMessage()); return false; }
    }

    /**
     * The weekly digest (the notice_digest job): for each person who chose it, one email of the notices since their last
     * digest. Returns how many digests went.
     */
    public static function digest(PDO $pdo, int $limit = 500): int
    {
        if (!self::emailOn($pdo)) return 0;
        $sent = 0;
        $st = $pdo->prepare("SELECT d.user_id, d.digest_sent_at, u.email, u.display_name FROM notice_delivery d JOIN users u ON u.id = d.user_id AND u.is_suspended = 0" . (function () use ($pdo) { require_once __DIR__ . '/TestAccounts.php'; return TestAccounts::notTest($pdo, 'u'); })() . "
                              WHERE d.how = 'digest' AND (d.digest_sent_at IS NULL OR d.digest_sent_at < ?) LIMIT " . max(1, $limit));
        $st->execute([date('Y-m-d H:i:s', time() - 6 * 86400)]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $d) {
            $q = $pdo->prepare('SELECT title, body, url FROM notices_sent WHERE user_id = ? AND created_at > ? ORDER BY id LIMIT 50');
            $q->execute([(int) $d['user_id'], (string) ($d['digest_sent_at'] ?? date('Y-m-d H:i:s', time() - 7 * 86400))]);
            $items = $q->fetchAll(PDO::FETCH_ASSOC);
            $pdo->prepare('UPDATE notice_delivery SET digest_sent_at = ? WHERE user_id = ?')->execute([date('Y-m-d H:i:s'), (int) $d['user_id']]);
            if (!$items || (string) $d['email'] === '') continue;
            $text = "Your Traversence notices this week:\n\n" . implode("\n\n", array_map(fn ($i) => '• ' . $i['title'] . ($i['body'] !== '' ? "\n  " . $i['body'] : '')
                . "\n  https://traversence.com" . ($i['url'] !== '' && $i['url'] !== '#' ? $i['url'] : '/user/dashboard.php#pulse'), $items));
            try {
                SesMail::send($pdo, ['account' => 'personal', 'from_local' => 'notices', 'from_domain' => 'send.traversence.com', 'from_name' => 'Traversence',
                    'to' => (string) $d['email'], 'to_name' => (string) $d['display_name'], 'subject' => 'Your week on Traversence: ' . count($items) . ' notice' . (count($items) === 1 ? '' : 's'),
                    'text' => $text, 'sender' => 'traversence', 'purpose' => 'digest', 'user_id' => (int) $d['user_id'], 'scope' => 'notices',
                    'why' => 'You chose a weekly email of your Traversence notices (Dashboard → App Settings).']);
                $sent++;
            } catch (Throwable $e) { error_log('notice digest: ' . $e->getMessage()); }
        }
        return $sent;
    }

    /** The person's notices, newest first, for their Pulse: [{kind, title, body, url, when, unread}]. */
    public static function forUser(PDO $pdo, int $uid, int $limit = 30): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT kind, title, body, url, created_at, read_at FROM notices_sent WHERE user_id = ? ORDER BY id DESC LIMIT ' . max(1, min(100, $limit)));
        $st->execute([$uid]);
        return array_map(fn ($r) => ['kind' => 'notice', 'title' => (string) $r['title'], 'body' => (string) $r['body'], 'url' => (string) $r['url'] ?: '#',
                                     'when' => (string) $r['created_at'], 'unread' => $r['read_at'] === null, 'from' => 'Notice'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function unread(PDO $pdo, int $uid): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->prepare('SELECT COUNT(*) FROM notices_sent WHERE user_id = ? AND read_at IS NULL'); $st->execute([$uid]);
        return (int) $st->fetchColumn();
    }

    /** Seen: opening the Pulse marks what it showed. */
    public static function markSeen(PDO $pdo, int $uid): void
    {
        if (!self::ready($pdo)) return;
        $pdo->prepare('UPDATE notices_sent SET read_at = ? WHERE user_id = ? AND read_at IS NULL')->execute([date('Y-m-d H:i:s'), $uid]);
    }

    /** Which kinds are on: [kind => [label, why, on]]. */
    public static function prefs(PDO $pdo, int $uid): array
    {
        $off = [];
        if (self::ready($pdo)) { $st = $pdo->prepare('SELECT kind FROM notice_prefs WHERE user_id = ?'); $st->execute([$uid]); $off = array_flip($st->fetchAll(PDO::FETCH_COLUMN)); }
        $out = [];
        foreach (self::KINDS as $k => [$label, $why]) $out[$k] = ['label' => $label, 'why' => $why, 'on' => !isset($off[$k])];
        return $out;
    }

    public static function setPref(PDO $pdo, int $uid, string $kind, bool $on): void
    {
        if (!isset(self::KINDS[$kind])) throw new InvalidArgumentException('Unknown kind of notice.');
        if (!self::ready($pdo)) throw new InvalidArgumentException('Notices aren\'t switched on yet.');
        if ($on) $pdo->prepare('DELETE FROM notice_prefs WHERE user_id = ? AND kind = ?')->execute([$uid, $kind]);
        else $pdo->prepare('INSERT IGNORE INTO notice_prefs (user_id, kind, off_since) VALUES (?, ?, ?)')->execute([$uid, $kind, date('Y-m-d H:i:s')]);
    }
}
