<?php
// app/lib/Notify.php — the one dispatcher (decisions/0172 §4, §6 step 2). Every message the site sends a person goes
// through Notify::send: one record per recipient in comms_messages (sender, recipient, kind, level, words), routed by the
// recipient's choices, along one route written to comms_route (created → addressed → held → sent → delivered → read).
//
// Pulse is the inbox: every message lands in the person's Pulse; email only tells them something is waiting there.
// The channels in this step are Pulse and free email: system email (Mailer: Bluehost) for the new kinds, and Amazon SES
// for notices, as decisions/0137 §8 set. Push and text are later builds on the same contract (0172 §4.6).
//
// What a kind is, its level, whom it goes to and its default channels are in one register, Notify::kinds(), which the
// person's Communications setting (Dashboard → App Settings) and the admin read alike. A person's choices are in
// comms_prefs (kind × channel) and comms_quiet (quiet hours: off until they set them, 0172 §4.4).
//
// Rules from the decision kept here:
//   - No clock is set on anyone's messages (Jason, 2026-11-18): a level says how a message reaches you, never how fast
//     you must act. No new digests: the weekly notice digest (Notices::digest) stays as it is.
//   - Quiet hours hold email for Notice, General and Special; Critical, Urgent and Alert go anyway (Alert would hold
//     only push, which isn't built). Held email goes out when they end (the notify_release job).
//   - One email per conversation while it's unread: a kind sent with a `thread` adds to the unread message already in
//     the person's Pulse instead of sending another email, until they've read it. (Not a digest: nothing waits.)
//   - Never throws: a failed send is written on the route and logged; the caller's own work carries on.
declare(strict_types=1);

final class Notify
{
    /** The six levels (0172 "The six levels"): key => name. Pulse::SEVERITY takes them on in step 3. */
    public const LEVELS = ['critical' => 'Critical', 'urgent' => 'Urgent', 'alert' => 'Alert', 'notice' => 'Notice', 'general' => 'General', 'special' => 'Special'];
    /** Levels that wait for quiet hours to end (email; push would be held for Alert too, once push is built). */
    private const WAITS = ['notice', 'general', 'special'];
    /** The channels this step delivers on. */
    public const CHANNELS = ['pulse' => 'Pulse', 'email' => 'Email'];

    /**
     * The kinds that aren't notices: key => [name, what it is, level, who it's for (business|staff|member), group,
     * email on by default, email can be turned off, engine (system: Bluehost; ses: Amazon SES), the team role's
     * capability that receives it (business kinds, Roles::CAN 'org')].
     * Notices (Notices::KINDS) join as 'notice.<kind>' in kinds().
     */
    public const KINDS = [
        'biz.message'  => ['A new message to your business', 'Someone wrote to a business you help run: a message, a question on an item, an offer.', 'alert', 'business', 'Your business', true, true, 'system', 'messages'],
        'biz.question' => ['A guest question', 'A visitor who isn\'t signed in asked your business a question.', 'alert', 'business', 'Your business', true, true, 'system', 'messages'],
        'biz.order'    => ['A Marketplace order for your business', 'An order or booking was placed, paid or changed by the buyer.', 'urgent', 'business', 'Your business', true, true, 'system', 'orders'],
        'biz.comment'  => ['A comment on your listing', 'Someone commented on a listing you help run.', 'general', 'business', 'Your business', false, true, 'system', 'messages'],
        'case.assigned'  => ['A Pulse case assigned to you', 'A teammate gave you a case to handle.', 'alert', 'staff', 'Team', true, true, 'system', ''],
        'case.escalated' => ['A Pulse case escalated to you', 'A case in your department was escalated to its Manager or Director.', 'alert', 'staff', 'Team', true, true, 'system', ''],
    ];

    /** Notices' levels (0172 §2): the rest are General. */
    private const NOTICE_LEVELS = ['group_join' => 'notice', 'group_charter' => 'notice', 'group_post' => 'alert', 'group_chapter' => 'notice', 'group_about' => 'notice',
                                   'guide_ready' => 'notice'];

    private const SITE = 'https://traversence.com';
    private const SETTINGS = 'https://traversence.com/user/dashboard.php#settings';

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok === null) {
            try { foreach (['comms_messages', 'comms_route', 'comms_prefs', 'comms_quiet'] as $t) $pdo->query("SELECT 1 FROM $t LIMIT 0"); $ok = true; } catch (Throwable) { $ok = false; }
        }
        return $ok;
    }

    /** Every kind, notices included: key => [name, what, level, for, group, email default, email can be off, engine, cap]. */
    public static function kinds(): array
    {
        $k = self::KINDS;
        if (is_file(__DIR__ . '/Notices.php')) {
            require_once __DIR__ . '/Notices.php';
            foreach (Notices::KINDS as $n => [$label, $why]) $k['notice.' . $n] = [$label, $why, self::NOTICE_LEVELS[$n] ?? 'general', 'member', 'Notices', false, true, 'ses', ''];
        }
        return $k;
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    /**
     * Sends a message of this kind. Returns how many people got a new message (or an unread one added to).
     *
     * $to     ['users' => [ids]] a person; ['entity' => id, 'except' => [ids]] a business's team, by the roles that take
     *         the kind (0102 §4, RBAC); ['staff' => [user ids]] our staff.
     * $about  'thing' (once per person, kind and thing; required), 'thread' (adds to an unread message of the same
     *         thread instead of sending another), 'url' (where it opens: a path on the site), 'pulse_ref' (when the
     *         sender's own table already shows it in Pulse, e.g. a business conversation), 'from' [type, id, name].
     * $words  'title', 'body'.
     */
    public static function send(PDO $pdo, string $kind, array $to, array $about, array $words): int
    {
        $kinds = self::kinds();
        if (!isset($kinds[$kind])) { error_log('Notify: unknown kind ' . $kind); return 0; }
        $def = $kinds[$kind];
        $isNotice = str_starts_with($kind, 'notice.');
        try { $users = self::recipients($pdo, $def, $to); } catch (Throwable $e) { error_log('Notify recipients: ' . $e->getMessage()); return 0; }
        if (!$users) return 0;
        $thing = mb_substr((string) ($about['thing'] ?? ''), 0, 120);
        if ($thing === '') $thing = bin2hex(random_bytes(8));
        $thread = mb_substr((string) ($about['thread'] ?? ''), 0, 120);
        $title = mb_substr(trim((string) ($words['title'] ?? '')), 0, 200);
        $body = mb_substr(trim((string) ($words['body'] ?? '')), 0, 2000);
        $url = mb_substr((string) ($about['url'] ?? ''), 0, 255);
        [$fType, $fId, $fName] = array_pad((array) ($about['from'] ?? []), 3, null);
        $entity = isset($to['entity']) ? (int) $to['entity'] : null;
        $n = 0;
        foreach ($users as $u) {
            try {
                if ($isNotice) {   // a notice keeps notices_sent's "once per person, kind and thing", and its own off switch
                    $pulseRef = self::noticeRow($pdo, $u, substr($kind, 7), $thing, $title, $body, $url);
                    if ($pulseRef === null) continue;
                } else {
                    $pulseRef = isset($about['pulse_ref']) ? mb_substr((string) $about['pulse_ref'], 0, 120) : null;
                }
                if (!self::ready($pdo)) { if ($isNotice) { $n++; self::noticeEmailOld($pdo, $u, $title, $body, $url); } continue; }   // before the update runs: as notices did
                if ($thread !== '' && ($mid = self::unreadInThread($pdo, $u, $kind, $thread))) {
                    $pdo->prepare('UPDATE comms_messages SET title = ?, body = ?, url = ?, times = times + 1, updated_at = ? WHERE id = ?')->execute([$title, $body, $url, self::now(), $mid]);
                    self::route($pdo, $mid, 'pulse', 'delivered', 'Added to the unread message already in their Pulse; no second email');
                    $n++;
                    continue;
                }
                $ins = $pdo->prepare('INSERT IGNORE INTO comms_messages (kind, lvl, sender_type, sender_id, sender_name, to_user, to_entity, thing, thread, title, body, url, pulse_ref, created_at, updated_at)
                                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $ins->execute([$kind, $def[2], $fType ?: 'system', $fId !== null ? (int) $fId : null, mb_substr((string) ($fName ?? ''), 0, 120), $u, $entity, $thing, $thread, $title, $body, $url, $pulseRef, self::now(), self::now()]);
                if (!$ins->rowCount()) continue;   // sent once already
                $mid = (int) $pdo->lastInsertId();
                $n++;
                self::route($pdo, $mid, 'pulse', 'created', $fName ? 'From ' . $fName : 'From the system');
                $email = self::emailOn($pdo, $u, $kind);
                self::route($pdo, $mid, 'pulse', 'addressed', 'Pulse' . ($email ? ' and email' : '') . ($email ? '' : ' (email off for this kind)'));
                self::route($pdo, $mid, 'pulse', 'delivered', $pulseRef ? 'Shown in Pulse by ' . strtok($pulseRef, ':') : 'In their Pulse');
                if (!$email) continue;
                if (in_array($def[2], self::WAITS, true) && self::quietNow($pdo, $u)) { self::route($pdo, $mid, 'email', 'held', 'Quiet hours: it goes when they end'); continue; }
                self::deliverEmail($pdo, $mid);
            } catch (Throwable $e) { error_log('Notify ' . $kind . ' to ' . $u . ': ' . $e->getMessage()); }
        }
        return $n;
    }

    /** Who gets it: user ids, without the sender, suspended accounts left out. */
    private static function recipients(PDO $pdo, array $def, array $to): array
    {
        $ids = [];
        if (isset($to['users'])) $ids = (array) $to['users'];
        elseif (isset($to['staff'])) $ids = (array) $to['staff'];
        elseif (isset($to['entity'])) {
            require_once __DIR__ . '/Roles.php';
            $cap = (string) $def[8];
            foreach (Roles::team($pdo, 'org', 'entity', (string) (int) $to['entity']) as $m) {
                $caps = Roles::CAN['org'][$m['role']] ?? [];
                $takes = in_array('*', $caps, true) || in_array($cap, $caps, true) || ($cap === 'orders' && (in_array('messages', $caps, true) || in_array('billing', $caps, true)));
                if ($takes) $ids[] = (int) $m['user_id'];
            }
        }
        $ids = array_values(array_diff(array_unique(array_filter(array_map('intval', $ids), fn ($i) => $i > 0)), array_map('intval', (array) ($to['except'] ?? []))));
        if (!$ids) return [];
        $st = $pdo->query('SELECT id FROM users WHERE is_suspended = 0 AND id IN (' . implode(',', $ids) . ')');
        return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }

    /** A notice's own row (notices_sent), unless the person switched the kind off. Its Pulse reference, or null. */
    private static function noticeRow(PDO $pdo, int $u, string $nkind, string $thing, string $title, string $body, string $url): ?string
    {
        require_once __DIR__ . '/Notices.php';
        if (!Notices::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT 1 FROM notice_prefs WHERE user_id = ? AND kind = ?'); $st->execute([$u, $nkind]);
        if ($st->fetchColumn() !== false) return null;
        $ins = $pdo->prepare('INSERT IGNORE INTO notices_sent (user_id, kind, thing, title, body, url, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $ins->execute([$u, $nkind, mb_substr($thing, 0, 80), mb_substr($title, 0, 200), mb_substr($body, 0, 400), mb_substr($url, 0, 255), self::now()]);
        if (!$ins->rowCount()) return null;   // once, as before
        return 'notices:' . (int) $pdo->lastInsertId();
    }

    /** Before the update has run: a notice is emailed exactly as Notices did (by SES, to those who chose email). */
    private static function noticeEmailOld(PDO $pdo, int $u, string $title, string $body, string $url): void
    {
        require_once __DIR__ . '/Notices.php';
        if (Notices::emailOn($pdo) && Notices::delivery($pdo, $u) === 'email') Notices::emailOne($pdo, $u, $title, $body, $url);
    }

    private static function unreadInThread(PDO $pdo, int $u, string $kind, string $thread): int
    {
        $st = $pdo->prepare('SELECT id FROM comms_messages WHERE to_user = ? AND kind = ? AND thread = ? AND read_at IS NULL ORDER BY id DESC LIMIT 1');
        $st->execute([$u, $kind, $thread]);
        return (int) ($st->fetchColumn() ?: 0);
    }

    /** One stage of a message's route. */
    public static function route(PDO $pdo, int $mid, string $via, string $stage, string $detail = '', string $providerId = ''): void
    {
        try {
            $pdo->prepare('INSERT INTO comms_route (message_id, via, stage, detail, provider_id, happened_at) VALUES (?, ?, ?, ?, ?, ?)')
                ->execute([$mid, $via, $stage, mb_substr($detail, 0, 255), mb_substr($providerId, 0, 120), self::now()]);
        } catch (Throwable $e) { error_log('Notify route: ' . $e->getMessage()); }
    }

    // ---- the person's choices: kind × channel, quiet hours ------------------------------------------------------------

    /** Whether this kind reaches this person by email: their choice, else the kind's default, and only if the engine works. */
    public static function emailOn(PDO $pdo, int $u, string $kind): bool
    {
        $def = self::kinds()[$kind] ?? null;
        if (!$def) return false;
        if ($def[7] === 'ses') {
            require_once __DIR__ . '/Notices.php';
            if (!Notices::emailOn($pdo)) return false;
            if (self::noticesStopped($pdo, $u)) return false;   // "Stop these" in a notice email stops them all (SesMail::unsubscribe)
        }
        if (!$def[6]) return true;   // can't be turned off
        if (self::ready($pdo)) {
            $st = $pdo->prepare('SELECT is_on FROM comms_prefs WHERE user_id = ? AND kind = ? AND via = ?'); $st->execute([$u, $kind, 'email']);
            $v = $st->fetchColumn();
            if ($v !== false) return (bool) (int) $v;
        }
        if ($def[7] === 'ses') return Notices::delivery($pdo, $u) === 'email';   // notices: the "by email as they happen" choice from before
        return (bool) $def[5];
    }

    /** Whether this person stopped notice emails with "Stop these" (an unsubscribe on their address, scope notices). */
    private static function noticesStopped(PDO $pdo, int $u): bool
    {
        $addr = self::addressOf($pdo, $u, false)[0];
        if ($addr === '' || !class_exists('SesMail')) return false;
        try { return SesMail::suppressed($pdo, SesMail::hash($addr), 'notices'); } catch (Throwable) { return false; }
    }

    /** Quiet hours: ['from' => minutes, 'to' => minutes, 'tz' => zone] or null (off). */
    public static function quiet(PDO $pdo, int $u): ?array
    {
        if (!self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT quiet_from, quiet_to, tz FROM comms_quiet WHERE user_id = ?'); $st->execute([$u]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ? ['from' => (int) $r['quiet_from'], 'to' => (int) $r['quiet_to'], 'tz' => (string) $r['tz']] : null;
    }

    public static function quietNow(PDO $pdo, int $u, ?int $at = null): bool
    {
        $q = self::quiet($pdo, $u);
        if (!$q || $q['from'] === $q['to']) return false;
        try { $tz = new DateTimeZone($q['tz'] !== '' ? $q['tz'] : date_default_timezone_get()); } catch (Throwable) { $tz = new DateTimeZone('UTC'); }
        $d = (new DateTimeImmutable('@' . ($at ?? time())))->setTimezone($tz);
        $m = (int) $d->format('G') * 60 + (int) $d->format('i');
        return $q['from'] < $q['to'] ? ($m >= $q['from'] && $m < $q['to']) : ($m >= $q['from'] || $m < $q['to']);
    }

    /** The Communications setting: every kind this person can get, with their choices; quiet hours. */
    public static function settings(PDO $pdo, int $u, array $forWho): array
    {
        require_once __DIR__ . '/Notices.php';
        $offPulse = [];
        if (Notices::ready($pdo)) { $st = $pdo->prepare('SELECT kind FROM notice_prefs WHERE user_id = ?'); $st->execute([$u]); $offPulse = array_flip($st->fetchAll(PDO::FETCH_COLUMN)); }
        $out = [];
        foreach (self::kinds() as $k => $d) {
            if (!in_array($d[3], $forWho, true)) continue;
            $notice = str_starts_with($k, 'notice.');
            $engineOn = $d[7] !== 'ses' || Notices::emailOn($pdo);
            $out[] = ['kind' => $k, 'name' => $d[0], 'what' => $d[1], 'level' => self::LEVELS[$d[2]], 'group' => $d[4],
                'pulse' => $notice ? !isset($offPulse[substr($k, 7)]) : true,
                'pulse_fixed' => $notice ? '' : 'Messages and work always reach your Pulse, so nothing that needs an answer is lost.',
                'email' => $engineOn && self::emailOn($pdo, $u, $k),
                'email_fixed' => !$engineOn ? 'Notices by email aren\'t switched on yet.' : (!$d[6] ? 'This one always comes by email: it\'s about your account\'s safety.' : '')];
        }
        $q = self::quiet($pdo, $u);
        $digest = Notices::deliveryReady($pdo) && Notices::delivery($pdo, $u) === 'digest';
        return ['kinds' => $out, 'quiet' => $q, 'digest' => $digest, 'digest_on' => Notices::emailOn($pdo), 'ready' => self::ready($pdo)];
    }

    /** Sets one kind × channel. Pulse for notices is their old off switch (notice_prefs); other kinds always reach Pulse. */
    public static function setChannel(PDO $pdo, int $u, string $kind, string $via, bool $on): void
    {
        $def = self::kinds()[$kind] ?? null;
        if (!$def) throw new InvalidArgumentException('Unknown kind of message.');
        if ($via === 'pulse') {
            if (!str_starts_with($kind, 'notice.')) throw new InvalidArgumentException('Messages and work always reach your Pulse.');
            require_once __DIR__ . '/Notices.php';
            Notices::setPref($pdo, $u, substr($kind, 7), $on);
            return;
        }
        if ($via !== 'email') throw new InvalidArgumentException('Choose Pulse or email.');
        if (!$def[6]) throw new InvalidArgumentException('This one always comes by email.');
        if (!self::ready($pdo)) throw new InvalidArgumentException('These choices switch on once the site\'s update has run.');
        if ($on && $def[7] === 'ses' && ($addr = self::addressOf($pdo, $u, false)[0]) !== '' && is_file(__DIR__ . '/SesMail.php')) {
            require_once __DIR__ . '/SesMail.php';   // signed in and asking again: an earlier "Stop these" is lifted
            try { $pdo->prepare("DELETE FROM email_suppress WHERE addr_hash = ? AND scope = 'notices' AND reason = 'unsubscribe'")->execute([SesMail::hash($addr)]); } catch (Throwable) {}
        }
        $pdo->prepare('INSERT INTO comms_prefs (user_id, kind, via, is_on, changed_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE is_on = VALUES(is_on), changed_at = VALUES(changed_at)')
            ->execute([$u, $kind, 'email', $on ? 1 : 0, self::now()]);
    }

    /**
     * The weekly email of notices (Notices::digest, as it is; no new digests) on or off. Whoever had chosen "by email as
     * they happen" keeps each notice's email as it was: it's written per kind first, so turning the digest on or off
     * changes nothing else.
     */
    public static function setDigest(PDO $pdo, int $u, bool $on): void
    {
        require_once __DIR__ . '/Notices.php';
        if (!Notices::deliveryReady($pdo)) throw new InvalidArgumentException('The weekly email isn\'t switched on yet.');
        if (self::ready($pdo) && Notices::delivery($pdo, $u) === 'email') {
            $ins = $pdo->prepare('INSERT IGNORE INTO comms_prefs (user_id, kind, via, is_on, changed_at) VALUES (?, ?, ?, 1, ?)');
            foreach (array_keys(Notices::KINDS) as $k) $ins->execute([$u, 'notice.' . $k, 'email', self::now()]);
        }
        Notices::setDelivery($pdo, $u, $on ? 'digest' : 'pulse');
    }

    /** Quiet hours on ("HH:MM" to "HH:MM", in the device's zone) or off (null). */
    public static function setQuiet(PDO $pdo, int $u, ?string $from, ?string $to, string $tz): void
    {
        if (!self::ready($pdo)) throw new InvalidArgumentException('Quiet hours switch on once the site\'s update has run.');
        if ($from === null) { $pdo->prepare('DELETE FROM comms_quiet WHERE user_id = ?')->execute([$u]); return; }
        $m = function (?string $t): int {
            if (!preg_match('/^([01]?\d|2[0-3]):([0-5]\d)$/', (string) $t, $x)) throw new InvalidArgumentException('Choose a start and an end time.');
            return (int) $x[1] * 60 + (int) $x[2];
        };
        $f = $m($from); $t = $m($to);
        if ($f === $t) throw new InvalidArgumentException('Quiet hours need a different start and end.');
        try { new DateTimeZone($tz); } catch (Throwable) { $tz = ''; }
        $pdo->prepare('INSERT INTO comms_quiet (user_id, quiet_from, quiet_to, tz, changed_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE quiet_from = VALUES(quiet_from), quiet_to = VALUES(quiet_to), tz = VALUES(tz), changed_at = VALUES(changed_at)')
            ->execute([$u, $f, $t, mb_substr($tz, 0, 64), self::now()]);
    }

    // ---- delivering by email --------------------------------------------------------------------------------------

    /** Emails one message now, by its kind's engine, and writes how it went on its route. */
    private static function deliverEmail(PDO $pdo, int $mid): bool
    {
        $st = $pdo->prepare('SELECT * FROM comms_messages WHERE id = ?'); $st->execute([$mid]);
        $m = $st->fetch(PDO::FETCH_ASSOC);
        if (!$m) return false;
        $def = self::kinds()[(string) $m['kind']] ?? null;
        if (!$def) return false;
        $u = (int) $m['to_user'];
        if ($def[7] === 'ses') {   // notices: Amazon SES, as decisions/0137 §8 set
            require_once __DIR__ . '/Notices.php';
            $ok = Notices::emailOne($pdo, $u, (string) $m['title'], (string) $m['body'], (string) $m['url']);
            self::route($pdo, $mid, 'email', $ok ? 'sent' : 'failed', $ok ? 'By Amazon SES (notices)' : 'Amazon SES didn\'t take it (see the error log)');
            return $ok;
        }
        [$addr, $name] = self::addressOf($pdo, $u, $def[3] === 'staff');
        if ($addr === '') { self::route($pdo, $mid, 'email', 'failed', 'No email address on the account'); return false; }
        $link = str_starts_with((string) $m['url'], 'http') ? (string) $m['url'] : self::SITE . ((string) $m['url'] !== '' ? $m['url'] : '/user/dashboard.php#pulse');
        $text = trim((string) $m['title']) . "\n\n" . ((string) $m['body'] !== '' ? $m['body'] . "\n\n" : '')
              . ((int) $m['times'] > 1 ? '(' . (int) $m['times'] . " of these are waiting.)\n\n" : '')
              . 'Open it: ' . $link . "\n\n"
              . '-- ' . "\n" . ($def[3] === 'staff'
                  ? 'You get this email because the case is yours now. Staff choices for these come with the staff Communications setting (coming).'
                  : 'You get this email because of your choices for "' . $def[0] . '".' . "\nStop these: " . self::stopUrl($mid, $u) . "\nChange what reaches you, and how: " . self::SETTINGS) . "\nTraversence";
        try {
            require_once __DIR__ . '/Mailer.php';
            Mailer::send($addr, (string) $m['title'] . ' · Traversence', $text, $name !== '' ? $name : null);
            self::route($pdo, $mid, 'email', 'sent', 'System email (Bluehost) to ' . self::maskAddr($addr));
            return true;
        } catch (Throwable $e) {
            self::route($pdo, $mid, 'email', 'failed', mb_substr($e->getMessage(), 0, 200));
            error_log('Notify email ' . $mid . ': ' . $e->getMessage());
            return false;
        }
    }

    // ---- "Stop these": one tap in an email stops that kind by email (decisions/0141 §5; /email/stop.php) -----------------

    private static function linkKey(): string
    {
        $k = getenv('EMAIL_LINK_KEY');
        return $k !== false && trim((string) $k) !== '' ? 'notify|' . trim((string) $k) : hash('sha256', 'tv-notify|' . (getenv('DB_PASSWORD') ?: '') . '|' . dirname(__DIR__));
    }

    public static function stopUrl(int $mid, int $u): string
    {
        return self::SITE . '/email/stop.php?t=' . $mid . '-' . substr(hash_hmac('sha256', $mid . '|' . $u, self::linkKey()), 0, 24);
    }

    /** The message a stop link is for, or null: [id, to_user, kind, name of the kind]. */
    public static function fromStop(PDO $pdo, string $t): ?array
    {
        if (!self::ready($pdo) || !preg_match('/^(\d+)-([a-f0-9]{24})$/', $t, $m)) return null;
        $st = $pdo->prepare('SELECT id, to_user, kind FROM comms_messages WHERE id = ?'); $st->execute([(int) $m[1]]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r || !hash_equals(substr(hash_hmac('sha256', (int) $r['id'] . '|' . (int) $r['to_user'], self::linkKey()), 0, 24), $m[2])) return null;
        $def = self::kinds()[(string) $r['kind']] ?? null;
        return $def ? ['id' => (int) $r['id'], 'to_user' => (int) $r['to_user'], 'kind' => (string) $r['kind'], 'name' => $def[0], 'can' => (bool) $def[6]] : null;
    }

    /** Stops this kind by email for that person (Pulse keeps it). */
    public static function stop(PDO $pdo, array $r): void
    {
        if (!$r['can']) return;
        $pdo->prepare('INSERT INTO comms_prefs (user_id, kind, via, is_on, changed_at) VALUES (?, ?, ?, 0, ?) ON DUPLICATE KEY UPDATE is_on = 0, changed_at = VALUES(changed_at)')
            ->execute([$r['to_user'], $r['kind'], 'email', self::now()]);
        self::route($pdo, $r['id'], 'email', 'stopped', 'Stop these: no more of this kind by email');
    }

    /** [email, name]: a staff member's own mailbox where they have one, else the account's email. */
    private static function addressOf(PDO $pdo, int $u, bool $staff): array
    {
        if ($staff) {
            try {
                $st = $pdo->prepare("SELECT email, name FROM " . Database::t('staff_accounts') . " WHERE user_id = ? AND status = 'active' LIMIT 1"); $st->execute([$u]);
                if (($s = $st->fetch(PDO::FETCH_ASSOC)) && trim((string) $s['email']) !== '') return [trim((string) $s['email']), (string) $s['name']];
            } catch (Throwable) {}
        }
        $st = $pdo->prepare('SELECT email, display_name FROM users WHERE id = ? AND is_suspended = 0'); $st->execute([$u]);
        $r = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        return [trim((string) ($r['email'] ?? '')), (string) ($r['display_name'] ?? '')];
    }

    /** The route keeps where it went, not the whole address: j***@example.com. */
    private static function maskAddr(string $a): string
    {
        [$l, $d] = array_pad(explode('@', $a, 2), 2, '');
        return mb_substr($l, 0, 1) . '***@' . $d;
    }

    /**
     * The notify_release job: email held for quiet hours goes once they end. A message read in Pulse meanwhile isn't
     * emailed (it's been seen). Returns how many went.
     */
    public static function releaseHeld(PDO $pdo, int $limit = 200): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->query("SELECT r.message_id, m.to_user, m.read_at FROM comms_route r JOIN comms_messages m ON m.id = r.message_id
                            WHERE r.via = 'email' AND r.stage = 'held'
                              AND NOT EXISTS (SELECT 1 FROM comms_route x WHERE x.message_id = r.message_id AND x.via = 'email' AND x.id > r.id)
                            ORDER BY r.id LIMIT " . max(1, $limit));
        $sent = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $h) {
            $mid = (int) $h['message_id'];
            if ($h['read_at'] !== null) { self::route($pdo, $mid, 'email', 'skipped', 'Read in Pulse during quiet hours, so not emailed'); continue; }
            if (self::quietNow($pdo, (int) $h['to_user'])) continue;
            if (self::deliverEmail($pdo, $mid)) $sent++;
        }
        return $sent;
    }

    // ---- reading -----------------------------------------------------------------------------------------------------

    /**
     * This person's messages that Pulse shows from here (those another table shows, pulse_ref, are left to it), newest
     * first: [{id, kind, level, title, body, url, when, unread, from, times}]. $entity: only those for that business.
     */
    public static function forUser(PDO $pdo, int $u, ?int $entity = null, int $limit = 30): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT id, kind, lvl, title, body, url, sender_name, times, updated_at, read_at FROM comms_messages
                              WHERE to_user = ? AND pulse_ref IS NULL AND ' . ($entity === null ? 'to_entity IS NULL' : 'to_entity = ' . (int) $entity) . ' ORDER BY updated_at DESC LIMIT ' . max(1, min(100, $limit)));
        $st->execute([$u]);
        return array_map(fn ($r) => ['id' => (int) $r['id'], 'kind' => (string) $r['kind'], 'level' => (string) $r['lvl'], 'title' => (string) $r['title']
            . ((int) $r['times'] > 1 ? ' (' . (int) $r['times'] . ')' : ''), 'body' => (string) $r['body'], 'url' => (string) $r['url'] ?: '#',
            'when' => (string) $r['updated_at'], 'unread' => $r['read_at'] === null, 'from' => (string) $r['sender_name'] ?: 'Traversence'], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    /** Unread at Alert or above, for the bell (0172: the bell counts everything unread at Alert or above). */
    public static function unreadForBell(PDO $pdo, int $u): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->prepare("SELECT COUNT(*) FROM comms_messages WHERE to_user = ? AND read_at IS NULL AND pulse_ref IS NULL AND lvl IN ('critical','urgent','alert')");
        $st->execute([$u]);
        return (int) $st->fetchColumn();
    }

    /** Read: these message ids, or every unread one of a kind and thread (a conversation opened). */
    public static function markRead(PDO $pdo, int $u, array $ids = [], string $kind = '', string $thread = ''): void
    {
        if (!self::ready($pdo)) return;
        try {
            if ($ids) $st = $pdo->query('SELECT id FROM comms_messages WHERE read_at IS NULL AND to_user = ' . $u . ' AND id IN (' . implode(',', array_map('intval', $ids)) . ')');
            elseif ($kind !== '') { $st = $pdo->prepare('SELECT id FROM comms_messages WHERE read_at IS NULL AND to_user = ? AND kind = ? AND thread = ?'); $st->execute([$u, $kind, $thread]); }
            else return;
            foreach (array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)) as $mid) {
                $pdo->prepare('UPDATE comms_messages SET read_at = ? WHERE id = ?')->execute([self::now(), $mid]);
                self::route($pdo, $mid, 'pulse', 'read', 'Opened in Pulse');
            }
        } catch (Throwable $e) { error_log('Notify read: ' . $e->getMessage()); }
    }

    /** A message's whole route, oldest first (message control, 0172 §4.3): [{via, stage, detail, at}]. */
    public static function routeOf(PDO $pdo, int $mid): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT via, stage, detail, happened_at FROM comms_route WHERE message_id = ? ORDER BY id'); $st->execute([$mid]);
        return array_map(fn ($r) => ['via' => (string) $r['via'], 'stage' => (string) $r['stage'], 'detail' => (string) $r['detail'], 'at' => (string) $r['happened_at']], $st->fetchAll(PDO::FETCH_ASSOC));
    }
}
