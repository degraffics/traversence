<?php

declare(strict_types=1);

require_once __DIR__ . '/Marketing.php';
require_once __DIR__ . '/Links.php';

/**
 * api/lib/BizMessages.php — messages between one person and one business (decisions/0047 §3).
 *
 * Always B2C and 1:1: a conversation is a person and a business (not the business's staff as people), kept
 * apart from person-to-person messages. The business sees a person's name only once that person writes to
 * it; everyone else is a count.
 *   - A person can message any business someone manages. The business replies while the person is linked,
 *     or within 30 days of the person's last message.
 *   - Offers go to subscribers (linked, not unsubscribed, no master switch): at once for "as it happens",
 *     on Monday morning for the weekly digest, and only big offers for "big offers only". One a day.
 *   - Asks ("subscribe again?" / "link to us?") go only to people whose own wait has passed: linked but
 *     unsubscribed, or who wrote to the business but aren't linked. One a week. The person answers yes, or
 *     no with when to ask again; an unanswered ask can't be repeated for 3 months.
 *   - Every message a listing sends is typed (decisions/0052 §4). Sales goes only to subscribers who haven't
 *     muted it; Support, General inquiry and Relationship management go to people who linked the listing
 *     (open links) or wrote to it. A person can mute any type per listing and report a mislabelled message.
 */
final class BizMessages
{
    private const REPLY_DAYS = 30;
    private const MAX_LEN = 4000;
    public const TYPES = ['sales' => 'Sales', 'support' => 'Support', 'inquiry' => 'General inquiry', 'relationship' => 'Relationship management'];

    /** Has the typed-messages migration run? */
    public static function typesReady(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT msg_type FROM business_messages LIMIT 1'); $pdo->query('SELECT 1 FROM business_message_mutes LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    /** The types this person has muted for this listing. */
    public static function mutes(PDO $pdo, int $uid, int $e): array
    {
        if (!self::typesReady($pdo)) return [];
        $st = $pdo->prepare('SELECT msg_type FROM business_message_mutes WHERE user_id = ? AND entity_id = ?');
        $st->execute([$uid, $e]);
        return array_values(array_map('strval', $st->fetchAll(PDO::FETCH_COLUMN)));
    }

    public static function setMute(PDO $pdo, int $uid, int $e, string $type, bool $on): void
    {
        if (!self::typesReady($pdo)) throw new InvalidArgumentException('Message types aren\'t switched on yet.');
        if (!isset(self::TYPES[$type])) throw new InvalidArgumentException('Unknown message type.');
        $pdo->prepare('DELETE FROM business_message_mutes WHERE user_id = ? AND entity_id = ? AND msg_type = ?')->execute([$uid, $e, $type]);
        if ($on) $pdo->prepare('INSERT INTO business_message_mutes (user_id, entity_id, msg_type) VALUES (?, ?, ?)')->execute([$uid, $e, $type]);
    }

    /** Linked, and the link is open to the listing (Linking not paused, earlier links acknowledged). */
    public static function openLinked(PDO $pdo, int $uid, int $e): bool
    {
        if (!self::linked($pdo, $uid, $e)) return false;
        return in_array($uid, array_column(Links::linkedBy($pdo, 'business', (string) $e, 500), 'user_id'), true);
    }

    /** May the listing send this person a Sales message? Subscribed and Sales not muted. */
    public static function canSales(PDO $pdo, int $e, int $u): bool
    {
        return isset(self::subscribers($pdo, $e)[$u]) && !in_array('sales', self::mutes($pdo, $u, $e), true);
    }

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM business_messages LIMIT 1'); return Marketing::tableExists($pdo); } catch (PDOException) { return false; }
    }

    public static function isStaff(PDO $pdo, int $uid, int $e): bool
    {
        return in_array($uid, Marketing::staff($pdo, $e), true);
    }

    public static function entityName(PDO $pdo, int $e): string
    {
        $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?');
        $st->execute([$e]);
        return (string) ($st->fetchColumn() ?: 'A business');
    }

    private static function personName(PDO $pdo, int $uid): string
    {
        $st = $pdo->prepare('SELECT display_name FROM users WHERE id = ?');
        $st->execute([$uid]);
        $n = trim((string) $st->fetchColumn());
        return $n !== '' ? $n : 'Member #' . $uid;
    }

    private static function linked(PDO $pdo, int $uid, int $e): bool
    {
        return (bool) (Links::states($pdo, $uid, ['business:' . $e])['business:' . $e] ?? false);
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    private static function clean(string $body): string
    {
        $body = trim(str_replace("\r", '', strip_tags($body)));
        if ($body === '') throw new InvalidArgumentException('Write something first.');
        return mb_substr($body, 0, self::MAX_LEN);
    }

    private static function read(PDO $pdo, int $uid, int $e, string $col): void
    {
        $st = $pdo->prepare('SELECT 1 FROM business_message_reads WHERE user_id = ? AND entity_id = ?');
        $st->execute([$uid, $e]);
        if ($st->fetchColumn() === false) $pdo->prepare('INSERT INTO business_message_reads (user_id, entity_id) VALUES (?, ?)')->execute([$uid, $e]);
        $pdo->prepare("UPDATE business_message_reads SET $col = ? WHERE user_id = ? AND entity_id = ?")->execute([self::now(), $uid, $e]);
    }

    private static function insert(PDO $pdo, int $e, int $uid, bool $fromBiz, string $kind, string $body, bool $big = false, ?int $by = null, ?string $visible = null, ?string $type = null): void
    {
        if (self::typesReady($pdo)) {
            $pdo->prepare('INSERT INTO business_messages (entity_id, user_id, from_business, kind, body, big, sent_by, visible_at, created_at, msg_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$e, $uid, $fromBiz ? 1 : 0, $kind, $body, $big ? 1 : 0, $by, $visible ?? self::now(), self::now(), $fromBiz ? $type : null]);
            return;
        }
        $pdo->prepare('INSERT INTO business_messages (entity_id, user_id, from_business, kind, body, big, sent_by, visible_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$e, $uid, $fromBiz ? 1 : 0, $kind, $body, $big ? 1 : 0, $by, $visible ?? self::now(), self::now()]);
    }

    private static function typeCol(PDO $pdo): string
    {
        return self::typesReady($pdo) ? 'msg_type' : 'NULL AS msg_type';
    }

    private static function typeLabel(?string $t): ?string
    {
        return $t !== null && isset(self::TYPES[$t]) ? self::TYPES[$t] : null;
    }

    // ---- The person's side ------------------------------------------------------------------------------

    /** The person's conversations with businesses, newest first. */
    public static function personInbox(PDO $pdo, int $uid): array
    {
        $now = self::now();
        $st = $pdo->prepare('SELECT m.entity_id, MAX(m.id) AS last_id, MAX(m.visible_at) AS at FROM business_messages m
                              WHERE m.user_id = ? AND m.visible_at <= ? GROUP BY m.entity_id ORDER BY at DESC LIMIT 100');
        $st->execute([$uid, $now]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $e = (int) $r['entity_id'];
            $l = $pdo->prepare('SELECT body, from_business, kind FROM business_messages WHERE id = ?');
            $l->execute([(int) $r['last_id']]);
            $last = $l->fetch(PDO::FETCH_ASSOC);
            $u = $pdo->prepare('SELECT COUNT(*) FROM business_messages m LEFT JOIN business_message_reads r ON r.user_id = m.user_id AND r.entity_id = m.entity_id
                                 WHERE m.user_id = ? AND m.entity_id = ? AND m.from_business = 1 AND m.visible_at <= ? AND m.visible_at > COALESCE(r.person_read_at, ?)');
            $u->execute([$uid, $e, $now, '1970-01-01']);
            $out[] = ['entity_id' => $e, 'name' => self::entityName($pdo, $e), 'at' => (string) $r['at'], 'unread' => (int) $u->fetchColumn(),
                      'last' => mb_strimwidth((string) $last['body'], 0, 90, '…'), 'mine' => !(int) $last['from_business'], 'kind' => (string) $last['kind']];
        }
        return $out;
    }

    public static function personUnread(PDO $pdo, int $uid): int
    {
        return array_sum(array_column(self::personInbox($pdo, $uid), 'unread'));
    }

    /** One conversation for the person; opening it marks it read. */
    public static function personThread(PDO $pdo, int $uid, int $e): array
    {
        $st = $pdo->prepare('SELECT id, from_business, kind, body, big, answered, visible_at, ' . self::typeCol($pdo) . ' FROM business_messages
                              WHERE user_id = ? AND entity_id = ? AND visible_at <= ? ORDER BY id DESC LIMIT 200');
        $st->execute([$uid, $e, self::now()]);
        $msgs = array_reverse(array_map(fn ($m) => ['id' => (int) $m['id'], 'mine' => !(int) $m['from_business'], 'kind' => (string) $m['kind'],
            'body' => (string) $m['body'], 'big' => (int) $m['big'], 'answered' => (int) $m['answered'], 'at' => (string) $m['visible_at'],
            'type' => $m['msg_type'], 'type_label' => self::typeLabel($m['msg_type'])], $st->fetchAll(PDO::FETCH_ASSOC)));
        self::read($pdo, $uid, $e, 'person_read_at');
        $sub = array_values(array_filter(Marketing::all($pdo, $uid), fn ($b) => $b['entity_id'] === $e));
        return ['entity_id' => $e, 'name' => self::entityName($pdo, $e), 'messages' => $msgs,
                'can_reply' => (bool) array_diff(Marketing::staff($pdo, $e), [$uid]),
                'linked' => (bool) $sub, 'subscribed' => $sub ? $sub[0]['subscribed'] : false,
                'types' => self::TYPES, 'mutes' => self::mutes($pdo, $uid, $e), 'types_ready' => self::typesReady($pdo)];
    }

    /**
     * A person writes to a business. Its team is told (decisions/0172 gap 1): in their Pulse and, unless they turned it
     * off, by email, one email per conversation until they've read it. $tell is the kind it's told as ('biz.order' for a
     * Marketplace order's note, which MarketCheckout sends this way; '' tells no one).
     */
    public static function personSend(PDO $pdo, int $uid, int $e, string $body, string $tell = 'biz.message'): void
    {
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);   // limited accounts can't post or send (decisions/0079)
        if (!array_diff(Marketing::staff($pdo, $e), [$uid])) throw new InvalidArgumentException('No one manages this listing yet, so there\'s no one to read it.');
        $st = $pdo->prepare('SELECT COUNT(*) FROM business_messages WHERE user_id = ? AND from_business = 0 AND created_at > ?');
        $st->execute([$uid, date('Y-m-d H:i:s', time() - 86400)]);
        if ((int) $st->fetchColumn() >= 50) throw new InvalidArgumentException('That\'s a lot of messages today. Try again tomorrow.');
        $text = self::clean($body);
        self::insert($pdo, $e, $uid, false, 'message', $text);
        $mid = (int) $pdo->lastInsertId();   // read before any other query
        self::read($pdo, $uid, $e, 'person_read_at');
        if ($tell !== '') {
            try {
                require_once __DIR__ . '/Notify.php';
                $who = self::personName($pdo, $uid); $biz = self::entityName($pdo, $e);
                $order = $tell === 'biz.order';
                Notify::send($pdo, $tell, ['entity' => $e, 'except' => [$uid]],
                    ['thing' => 'bizmsg:' . $mid, 'thread' => 'bizmsg:' . $e . ':' . $uid, 'url' => '/business/' . $e . '#messages', 'pulse_ref' => 'bizmsg:' . $e . ':' . $uid, 'from' => ['user', $uid, $who]],
                    ['title' => $order ? $biz . ': ' . mb_strimwidth((string) strtok($text, "\n"), 0, 150, '…') : $who . ' wrote to ' . $biz,
                     'body' => $order ? 'From ' . $who . '. Open the conversation to see it and answer.' : 'Read and answer it in ' . $biz . '\'s messages on Traversence.']);
            } catch (Throwable $x) { error_log('biz message notify: ' . $x->getMessage()); }
        }
    }

    /** The person answers an ask: yes links (if needed) and subscribes; no records when they may ask again. */
    public static function answerAsk(PDO $pdo, int $uid, int $messageId, bool $yes, string $askAgain): void
    {
        $st = $pdo->prepare("SELECT entity_id FROM business_messages WHERE id = ? AND user_id = ? AND kind = 'ask' AND answered = 0");
        $st->execute([$messageId, $uid]);
        $e = (int) $st->fetchColumn();
        if ($e <= 0) throw new InvalidArgumentException('That request was already answered.');
        if ($yes) {
            if (!self::linked($pdo, $uid, $e)) Links::set($pdo, $uid, 'business', (string) $e, true);
            Marketing::subscribe($pdo, $uid, $e, 'weekly');
        } else {
            Marketing::unsubscribe($pdo, $uid, $e, $askAgain);
        }
        $pdo->prepare('UPDATE business_messages SET answered = 1 WHERE id = ?')->execute([$messageId]);
    }

    // ---- The business's side ----------------------------------------------------------------------------

    /** Conversations: people who wrote to this business, or whom it wrote to directly (not offers or asks alone). */
    public static function bizInbox(PDO $pdo, int $e): array
    {
        $st = $pdo->prepare("SELECT user_id, MAX(id) AS last_id, MAX(created_at) AS at FROM business_messages
                              WHERE entity_id = ? AND user_id IN (SELECT user_id FROM business_messages WHERE entity_id = ? AND (from_business = 0 OR kind = 'message'))
                                AND visible_at <= ? GROUP BY user_id ORDER BY at DESC LIMIT 200");
        $st->execute([$e, $e, self::now()]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $u = (int) $r['user_id'];
            $l = $pdo->prepare('SELECT body, from_business FROM business_messages WHERE id = ?');
            $l->execute([(int) $r['last_id']]);
            $last = $l->fetch(PDO::FETCH_ASSOC);
            $n = $pdo->prepare('SELECT COUNT(*) FROM business_messages m LEFT JOIN business_message_reads r ON r.user_id = m.user_id AND r.entity_id = m.entity_id
                                 WHERE m.entity_id = ? AND m.user_id = ? AND m.from_business = 0 AND m.created_at > COALESCE(r.biz_read_at, ?)');
            $n->execute([$e, $u, '1970-01-01']);
            $out[] = ['user_id' => $u, 'name' => self::personName($pdo, $u), 'at' => (string) $r['at'], 'unread' => (int) $n->fetchColumn(),
                      'last' => mb_strimwidth((string) $last['body'], 0, 90, '…'), 'mine' => (bool) (int) $last['from_business']];
        }
        return $out;
    }

    /** Unread messages from people across every listing this person manages. */
    public static function staffUnread(PDO $pdo, int $staff): int
    {
        $st = $pdo->prepare('SELECT COUNT(*) FROM business_messages m JOIN listing_access a ON a.entity_id = m.entity_id AND a.user_id = ?
                               LEFT JOIN business_message_reads r ON r.user_id = m.user_id AND r.entity_id = m.entity_id
                              WHERE m.from_business = 0 AND m.created_at > COALESCE(r.biz_read_at, ?)');
        $st->execute([$staff, '1970-01-01']);
        return (int) $st->fetchColumn();
    }

    private static function lastWrote(PDO $pdo, int $e, int $u): ?string
    {
        $st = $pdo->prepare('SELECT MAX(created_at) FROM business_messages WHERE entity_id = ? AND user_id = ? AND from_business = 0');
        $st->execute([$e, $u]);
        $last = $st->fetchColumn();
        return $last ? (string) $last : null;
    }

    /** May the business write to this person now? While they're linked to it (open), or within 30 days of their last message. */
    public static function bizCanReply(PDO $pdo, int $e, int $u): bool
    {
        if (in_array($u, Marketing::staff($pdo, $e), true)) return false;
        if (self::openLinked($pdo, $u, $e)) return true;
        $last = self::lastWrote($pdo, $e, $u);
        return $last !== null && strtotime($last) >= time() - self::REPLY_DAYS * 86400;
    }

    public static function bizThread(PDO $pdo, int $e, int $u): array
    {
        if (!self::bizCanSee($pdo, $e, $u)) throw new InvalidArgumentException('That conversation isn\'t there.');
        $st = $pdo->prepare('SELECT from_business, kind, body, big, created_at, ' . self::typeCol($pdo) . ' FROM business_messages
                              WHERE entity_id = ? AND user_id = ? AND visible_at <= ? ORDER BY id DESC LIMIT 200');
        $st->execute([$e, $u, self::now()]);
        $msgs = array_reverse(array_map(fn ($m) => ['mine' => (bool) (int) $m['from_business'], 'kind' => (string) $m['kind'], 'body' => (string) $m['body'],
            'big' => (int) $m['big'], 'at' => (string) $m['created_at'], 'type' => $m['msg_type'], 'type_label' => self::typeLabel($m['msg_type'])], $st->fetchAll(PDO::FETCH_ASSOC)));
        self::read($pdo, $u, $e, 'biz_read_at');
        if (class_exists('Auth') && ($me = Auth::currentUser()) !== null) {   // the conversation is read: its message in this person's Pulse and the bell too (decisions/0172)
            require_once __DIR__ . '/Notify.php';
            foreach (['biz.message', 'biz.order'] as $k) Notify::markRead($pdo, (int) $me['id'], [], $k, 'bizmsg:' . $e . ':' . $u);
        }
        return ['user_id' => $u, 'name' => self::personName($pdo, $u), 'messages' => $msgs, 'can_reply' => self::bizCanReply($pdo, $e, $u),
                'linked' => self::linked($pdo, $u, $e), 'contact' => Marketing::cardForBusiness($pdo, $u, $e),
                'types' => self::TYPES, 'types_ready' => self::typesReady($pdo), 'can_sales' => self::canSales($pdo, $e, $u),
                'muted' => self::mutes($pdo, $u, $e), 'wrote' => self::lastWrote($pdo, $e, $u) !== null];
    }

    private static function bizCanSee(PDO $pdo, int $e, int $u): bool
    {
        if (self::openLinked($pdo, $u, $e)) return true;
        $st = $pdo->prepare('SELECT 1 FROM business_messages WHERE entity_id = ? AND user_id = ? AND (from_business = 0 OR kind = \'message\') LIMIT 1');
        $st->execute([$e, $u]);
        return $st->fetchColumn() !== false;
    }

    public static function bizReply(PDO $pdo, int $staff, int $e, int $u, string $body, string $type = 'inquiry'): void
    {
        if (!self::bizCanReply($pdo, $e, $u)) throw new InvalidArgumentException('You can write while they\'re linked to you, or within 30 days of their last message.');
        if (self::typesReady($pdo)) {
            if (!isset(self::TYPES[$type])) throw new InvalidArgumentException('Choose what kind of message this is.');
            if ($type === 'sales' && !self::canSales($pdo, $e, $u)) throw new InvalidArgumentException('Sales messages go only to people subscribed to your offers who haven\'t muted Sales.');
            if (in_array($type, self::mutes($pdo, $u, $e), true)) throw new InvalidArgumentException('They\'ve muted ' . self::TYPES[$type] . ' messages from you.');
        }
        self::insert($pdo, $e, $u, true, 'message', self::clean($body), false, $staff, null, $type);
        self::read($pdo, $u, $e, 'biz_read_at');
    }

    /** Subscribers who'd receive an offer: [user_id => frequency]. */
    private static function subscribers(PDO $pdo, int $e): array
    {
        $st = $pdo->prepare("SELECT l.user_id, m.status, m.frequency, s.no_marketing FROM user_links l
                               LEFT JOIN marketing_optins m ON m.user_id = l.user_id AND m.entity_id = l.target_id
                               LEFT JOIN user_settings s ON s.user_id = l.user_id
                              WHERE l.target_type = 'business' AND l.target_id = ?");
        $st->execute([(string) $e]);
        $staff = Marketing::staff($pdo, $e);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $u = (int) $r['user_id'];
            if ($r['status'] === 'no' || (int) $r['no_marketing'] === 1 || in_array($u, $staff, true)) continue;
            if (is_file(__DIR__ . '/Consent.php') && (require_once __DIR__ . '/Consent.php') && Consent::paused($pdo, $u, 'linking')) continue;   // Linking paused
            $out[$u] = $r['status'] === 'yes' ? (string) $r['frequency'] : 'weekly';
        }
        return $out;
    }

    /** People this business may ask right now: linked but unsubscribed, or who wrote to it but aren't linked. */
    private static function askable(PDO $pdo, int $e): array
    {
        $st = $pdo->prepare("SELECT DISTINCT user_id FROM (
                                 SELECT l.user_id FROM user_links l JOIN marketing_optins m ON m.user_id = l.user_id AND m.entity_id = l.target_id
                                  WHERE l.target_type = 'business' AND l.target_id = ? AND m.status = 'no'
                                 UNION SELECT user_id FROM business_messages WHERE entity_id = ? AND from_business = 0) x");
        $st->execute([(string) $e, $e]);
        $staff = Marketing::staff($pdo, $e);
        $subs = self::subscribers($pdo, $e);
        $out = [];
        foreach (array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)) as $u) {
            if (in_array($u, $staff, true)) continue;
            $linked = self::linked($pdo, $u, $e);
            $sub = $linked && isset($subs[$u]);
            if (!$sub && Marketing::mayAsk($pdo, $u, $e)) $out[$u] = $linked;   // true: ask to subscribe again; false: ask to link
        }
        return $out;
    }

    private static function lastBroadcast(PDO $pdo, int $e, string $kind): ?int
    {
        $st = $pdo->prepare('SELECT MAX(created_at) FROM business_broadcasts WHERE entity_id = ? AND kind = ?');
        $st->execute([$e, $kind]);
        $t = $st->fetchColumn();
        return $t ? strtotime((string) $t) : null;
    }

    /** Monday 9am after now (or today, if it's Monday before 9). */
    private static function digestTime(): string
    {
        $t = strtotime('monday 09:00');
        if ($t <= time()) $t = strtotime('next monday 09:00');
        return date('Y-m-d H:i:s', $t);
    }

    public static function sendOffer(PDO $pdo, int $staff, int $e, string $body, bool $big): int
    {
        $body = self::clean($body);
        $last = self::lastBroadcast($pdo, $e, 'offer');
        if ($last !== null && $last > time() - 86400) throw new InvalidArgumentException('One offer a day. The next can go out after ' . date('M j, g:ia', $last + 86400) . '.');
        $n = 0;
        foreach (self::subscribers($pdo, $e) as $u => $freq) {
            if ($freq === 'big' && !$big) continue;
            if (in_array('sales', self::mutes($pdo, $u, $e), true)) continue;   // muted Sales from this listing
            self::insert($pdo, $e, $u, true, 'offer', $body, $big, $staff, $freq === 'weekly' ? self::digestTime() : null, 'sales');
            $n++;
        }
        $pdo->prepare("INSERT INTO business_broadcasts (entity_id, kind, body, big, recipients, sent_by, created_at) VALUES (?, 'offer', ?, ?, ?, ?, ?)")
            ->execute([$e, $body, $big ? 1 : 0, $n, $staff, self::now()]);
        return $n;
    }

    public static function sendAsk(PDO $pdo, int $staff, int $e): int
    {
        $last = self::lastBroadcast($pdo, $e, 'ask');
        if ($last !== null && $last > time() - 7 * 86400) throw new InvalidArgumentException('One request a week. The next can go out after ' . date('M j', $last + 7 * 86400) . '.');
        $name = self::entityName($pdo, $e);
        $after = date('Y-m-d H:i:s', strtotime('+3 months'));
        $n = 0;
        foreach (self::askable($pdo, $e) as $u => $linked) {
            $body = $linked ? "$name would like to send you offers and news again, in your Traversence inbox."
                            : "$name would like you to link to it: it shows in your feeds, and you can message each other here.";
            if (in_array('relationship', self::mutes($pdo, $u, $e), true)) continue;
            self::insert($pdo, $e, $u, true, 'ask', $body, false, $staff, null, 'relationship');
            // Not again for 3 months unless the person answers with their own choice.
            $pdo->prepare('DELETE FROM marketing_optins WHERE user_id = ? AND entity_id = ?')->execute([$u, $e]);
            $pdo->prepare("INSERT INTO marketing_optins (user_id, entity_id, status, frequency, ask_after, never) VALUES (?, ?, 'no', 'weekly', ?, 0)")->execute([$u, $e, $after]);
            $n++;
        }
        $pdo->prepare("INSERT INTO business_broadcasts (entity_id, kind, body, recipients, sent_by, created_at) VALUES (?, 'ask', ?, ?, ?, ?)")
            ->execute([$e, 'Asked to link or subscribe', $n, $staff, self::now()]);
        return $n;
    }

    /** Everything the business's messages card needs. */
    public static function bizOverview(PDO $pdo, int $e): array
    {
        $subs = self::subscribers($pdo, $e);
        $h = $pdo->prepare('SELECT kind, body, big, recipients, created_at FROM business_broadcasts WHERE entity_id = ? ORDER BY id DESC LIMIT 10');
        $h->execute([$e]);
        $lo = self::lastBroadcast($pdo, $e, 'offer');
        $la = self::lastBroadcast($pdo, $e, 'ask');
        return ['name' => self::entityName($pdo, $e), 'conversations' => self::bizInbox($pdo, $e),
                'subscribers' => count($subs), 'big_only' => count(array_filter($subs, fn ($f) => $f === 'big')),
                'askable' => count(self::askable($pdo, $e)),
                'linked' => array_values(array_filter(Links::linkedBy($pdo, 'business', (string) $e, 500), fn ($p) => !in_array($p['user_id'], Marketing::staff($pdo, $e), true))),
                'types' => self::TYPES, 'types_ready' => self::typesReady($pdo),
                'offer_after' => $lo !== null && $lo > time() - 86400 ? date('M j, g:ia', $lo + 86400) : null,
                'ask_after' => $la !== null && $la > time() - 7 * 86400 ? date('M j', $la + 7 * 86400) : null,
                'history' => $h->fetchAll(PDO::FETCH_ASSOC)];
    }
}
