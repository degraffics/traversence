<?php

declare(strict_types=1);

require_once __DIR__ . '/Marketing.php';

/**
 * api/lib/GuestInquiries.php — a guest asks a listing a question (decisions/0052 §5).
 *
 *   - Guests write to listings only, never to people, and only to listings someone manages (someone reads it).
 *   - A simple self-hosted check, nothing third-party (decisions/0050): a hidden field people never fill in, a
 *     minimum time on the form, and a small question anyone can answer at a glance. All kept in the session.
 *   - Contact is the guest's choice: an email (replies are emailed through Traversence), a phone number (the listing
 *     may call), or neither. Every inquiry gets a reply code to check back on the listing page.
 *   - Limits: 3 new questions a day per device and 6 per network. The listing validates: replying marks it answered;
 *     it can mark spam or couldn't reach. Two spam marks end guest messaging from that device.
 *   - Devices and networks are stored only as one-way hashes. No marketing to guests, ever. Conversations with no
 *     activity for 180 days are deleted.
 *   - Signed in with the code, the guest can move the conversation into their account (a normal business conversation).
 */
final class GuestInquiries
{
    private const MIN_SECONDS = 4;
    private const PER_DEVICE = 3;
    private const PER_NETWORK = 6;
    private const SPAM_BLOCK = 2;
    private const KEEP_DAYS = 180;
    private const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM guest_inquiries LIMIT 1'); $pdo->query('SELECT 1 FROM guest_devices LIMIT 1'); return true; } catch (PDOException) { return false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    private static function pepper(): string
    {
        return (string) (getenv('GUEST_HASH_KEY') ?: hash('sha256', 'tv-guest|' . (getenv('DB_PASSWORD') ?: '') . '|' . dirname(__DIR__, 2) . '/website/api/lib'));   // the old folder: keeps existing hashes valid
    }

    private static function h(string $v): string { return hash_hmac('sha256', $v, self::pepper()); }

    /** A random device id in a first-party cookie (no tracking: it only counts this form's use). */
    public static function deviceHash(): string
    {
        $id = (string) ($_COOKIE['tv_gd'] ?? '');
        if (!preg_match('/^[a-f0-9]{32}$/', $id)) {
            $id = bin2hex(random_bytes(16));
            if (!headers_sent()) setcookie('tv_gd', $id, ['expires' => time() + 365 * 86400, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']), 'httponly' => true, 'samesite' => 'Lax']);
        }
        return self::h('d|' . $id);
    }

    private static function ipHash(): string
    {
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        if (str_contains($ip, ':')) $ip = implode(':', array_slice(explode(':', $ip), 0, 4));   // IPv6: the network, not the device
        return self::h('n|' . $ip);
    }

    public static function managed(PDO $pdo, int $e): bool
    {
        return (bool) Marketing::staff($pdo, $e);
    }

    private static function blockedDevice(PDO $pdo, string $dev): bool
    {
        $st = $pdo->prepare('SELECT blocked_at FROM guest_devices WHERE device_hash = ?');
        $st->execute([$dev]);
        return (bool) $st->fetchColumn();
    }

    /** A fresh check for the form: the question, and a nonce that remembers when the form was shown. */
    public static function challenge(): array
    {
        $a = random_int(2, 9); $b = random_int(1, 9);
        $nonce = bin2hex(random_bytes(8));
        $_SESSION['gq'] = array_slice(($_SESSION['gq'] ?? []) + [$nonce => ['t' => time(), 'sum' => $a + $b]], -5, null, true);
        return ['nonce' => $nonce, 'question' => "What is $a + $b?"];
    }

    private static function code(): string
    {
        $c = '';
        for ($i = 0; $i < 8; $i++) $c .= self::CODE_CHARS[random_int(0, strlen(self::CODE_CHARS) - 1)];
        return substr($c, 0, 4) . '-' . substr($c, 4);
    }

    private static function normCode(string $code): string
    {
        return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code));
    }

    private static function cleanup(PDO $pdo): void
    {
        $old = date('Y-m-d H:i:s', time() - self::KEEP_DAYS * 86400);
        $pdo->prepare('DELETE FROM guest_inquiry_messages WHERE inquiry_id IN (SELECT id FROM (SELECT id FROM guest_inquiries WHERE last_at < ?) x)')->execute([$old]);
        $pdo->prepare('DELETE FROM guest_inquiries WHERE last_at < ?')->execute([$old]);
    }

    private static function body(string $s): string
    {
        $s = trim(str_replace("\r", '', strip_tags($s)));
        if (mb_strlen($s) < 2) throw new InvalidArgumentException('Write your question first.');
        return mb_substr($s, 0, 2000);
    }

    /**
     * A guest's question. Returns the reply code (shown once).
     * @param array{nonce?:string, answer?:string, website?:string, name?:string, contact_type?:string, contact?:string, body?:string} $in
     */
    public static function create(PDO $pdo, int $e, array $in): string
    {
        // The self-hosted check. Failures all read the same, so they teach a bot nothing.
        $nonce = (string) ($in['nonce'] ?? '');
        $gq = $_SESSION['gq'][$nonce] ?? null;
        unset($_SESSION['gq'][$nonce]);
        $fail = new InvalidArgumentException('That didn\'t go through. Please check the question and try again.');
        if (!$gq || trim((string) ($in['website'] ?? '')) !== '') throw $fail;
        if (time() - (int) $gq['t'] < self::MIN_SECONDS) throw $fail;
        if ((int) trim((string) ($in['answer'] ?? '')) !== (int) $gq['sum']) throw $fail;

        if (!self::managed($pdo, $e)) throw new InvalidArgumentException('No one manages this listing on Traversence yet, so no one would read it. Try calling instead.');
        $dev = self::deviceHash();
        $ip = self::ipHash();
        if (self::blockedDevice($pdo, $dev)) throw new InvalidArgumentException('Questions from this device are turned off. Create an account to message listings.');
        $since = date('Y-m-d H:i:s', time() - 86400);
        $n = $pdo->prepare('SELECT COUNT(*) FROM guest_inquiries WHERE device_hash = ? AND created_at > ?');
        $n->execute([$dev, $since]);
        if ((int) $n->fetchColumn() >= self::PER_DEVICE) throw new InvalidArgumentException('That\'s ' . self::PER_DEVICE . ' questions today. Try again tomorrow, or create an account.');
        $n = $pdo->prepare('SELECT COUNT(*) FROM guest_inquiries WHERE ip_hash = ? AND created_at > ?');
        $n->execute([$ip, $since]);
        if ((int) $n->fetchColumn() >= self::PER_NETWORK) throw new InvalidArgumentException('Too many questions from this network today. Try again tomorrow, or create an account.');

        $name = mb_substr(trim(strip_tags((string) ($in['name'] ?? ''))), 0, 80);
        if ($name === '') throw new InvalidArgumentException('Add a name the listing can call you.');
        $type = (string) ($in['contact_type'] ?? 'none');
        $contact = trim((string) ($in['contact'] ?? ''));
        if ($type === 'email') {
            if (!filter_var($contact, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email doesn\'t look right.');
        } elseif ($type === 'phone') {
            $d = preg_replace('/\D/', '', $contact);
            if (strlen($d) < 10) throw new InvalidArgumentException('Enter a 10-digit phone number.');
            $contact = mb_substr($contact, 0, 40);
        } else {
            $type = 'none'; $contact = '';
        }
        $body = self::body((string) ($in['body'] ?? ''));

        self::cleanup($pdo);
        do {
            $code = self::code();
            $st = $pdo->prepare('SELECT 1 FROM guest_inquiries WHERE code_hash = ?');
            $st->execute([self::h('c|' . self::normCode($code))]);
        } while ($st->fetchColumn() !== false);
        $now = self::now();
        $pdo->prepare('INSERT INTO guest_inquiries (entity_id, name, contact_type, contact, code_hash, device_hash, ip_hash, status, guest_read_at, created_at, last_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$e, $name, $type, $contact !== '' ? mb_substr($contact, 0, 255) : null, self::h('c|' . self::normCode($code)), $dev, $ip, 'open', $now, $now, $now]);
        $id = (int) $pdo->lastInsertId();
        $pdo->prepare('INSERT INTO guest_inquiry_messages (inquiry_id, from_business, body, created_at) VALUES (?, 0, ?, ?)')->execute([$id, $body, $now]);
        $mid = (int) $pdo->lastInsertId();
        self::tell($pdo, $e, $id, $mid, $name);
        return $code;
    }

    /**
     * The listing's team is told of a guest's question or follow-up (decisions/0172 §2.2): in their Pulse, where the
     * question already shows, and by email unless they turned it off, one email per conversation until it's read.
     * The guest's contact details are never in the email.
     */
    private static function tell(PDO $pdo, int $e, int $id, int $mid, string $name): void
    {
        try {
            require_once __DIR__ . '/Notify.php';
            $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?'); $st->execute([$e]);
            $biz = (string) $st->fetchColumn();
            Notify::send($pdo, 'biz.question', ['entity' => $e], ['thing' => 'guestq:' . $mid, 'thread' => 'guestq:' . $e . ':' . $id, 'url' => '/business/' . $e . '#messages',
                'pulse_ref' => 'guestq:' . $e . ':' . $id, 'from' => ['guest', null, $name . ' (guest)']],
                ['title' => $name . ' (a guest) asked ' . ($biz !== '' ? $biz : 'your business') . ' a question', 'body' => 'Read and answer it in your messages on Traversence. Answers reach them by email if they chose it, or under their reply code.']);
        } catch (Throwable $x) { error_log('guest question notify: ' . $x->getMessage()); }
    }

    // ---- the guest, with a reply code ------------------------------------------------------------------

    private static function byCode(PDO $pdo, string $code): array
    {
        // Slow down guessing: 12 tries an hour per session.
        $tries = array_filter((array) ($_SESSION['gq_tries'] ?? []), fn ($t) => $t > time() - 3600);
        if (count($tries) >= 12) throw new InvalidArgumentException('Too many tries. Wait a while and try again.');
        $st = $pdo->prepare("SELECT * FROM guest_inquiries WHERE code_hash = ? AND status <> 'moved'");
        $st->execute([self::h('c|' . self::normCode($code))]);
        $q = $st->fetch(PDO::FETCH_ASSOC);
        if (!$q) { $tries[] = time(); $_SESSION['gq_tries'] = array_values($tries); throw new InvalidArgumentException('No conversation matches that code.'); }
        return $q;
    }

    private static function messages(PDO $pdo, int $id): array
    {
        $st = $pdo->prepare('SELECT from_business, body, created_at FROM guest_inquiry_messages WHERE inquiry_id = ? ORDER BY id LIMIT 200');
        $st->execute([$id]);
        return array_map(fn ($m) => ['from_business' => (bool) (int) $m['from_business'], 'body' => (string) $m['body'], 'at' => (string) $m['created_at']], $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function guestView(PDO $pdo, string $code): array
    {
        $q = self::byCode($pdo, $code);
        $pdo->prepare('UPDATE guest_inquiries SET guest_read_at = ? WHERE id = ?')->execute([self::now(), (int) $q['id']]);
        $st = $pdo->prepare('SELECT name FROM entities WHERE id = ?');
        $st->execute([(int) $q['entity_id']]);
        return ['entity_id' => (int) $q['entity_id'], 'listing' => (string) $st->fetchColumn(), 'name' => (string) $q['name'],
                'status' => (string) $q['status'], 'messages' => self::messages($pdo, (int) $q['id']),
                'can_write' => !in_array($q['status'], ['spam'], true) && !self::blockedDevice($pdo, self::deviceHash())];
    }

    /** A follow-up from the guest in the same conversation (up to 10 a day per conversation). */
    public static function guestReply(PDO $pdo, string $code, string $body): void
    {
        $q = self::byCode($pdo, $code);
        if ($q['status'] === 'spam' || self::blockedDevice($pdo, self::deviceHash())) throw new InvalidArgumentException('This conversation is closed.');
        $n = $pdo->prepare('SELECT COUNT(*) FROM guest_inquiry_messages WHERE inquiry_id = ? AND from_business = 0 AND created_at > ?');
        $n->execute([(int) $q['id'], date('Y-m-d H:i:s', time() - 86400)]);
        if ((int) $n->fetchColumn() >= 10) throw new InvalidArgumentException('That\'s a lot for one day. Try again tomorrow.');
        $now = self::now();
        $pdo->prepare('INSERT INTO guest_inquiry_messages (inquiry_id, from_business, body, created_at) VALUES (?, 0, ?, ?)')->execute([(int) $q['id'], self::body($body), $now]);
        $mid = (int) $pdo->lastInsertId();
        $pdo->prepare('UPDATE guest_inquiries SET last_at = ?, guest_read_at = ? WHERE id = ?')->execute([$now, $now, (int) $q['id']]);
        self::tell($pdo, (int) $q['entity_id'], (int) $q['id'], $mid, (string) $q['name']);
    }

    /** Signed in, with the code: the conversation becomes a normal one between this member and the listing. */
    public static function moveToAccount(PDO $pdo, string $code, int $uid): int
    {
        require_once __DIR__ . '/BizMessages.php';
        $q = self::byCode($pdo, $code);
        if ($q['status'] === 'spam') throw new InvalidArgumentException('This conversation is closed.');
        $e = (int) $q['entity_id'];
        $typed = BizMessages::typesReady($pdo);
        foreach (self::messages($pdo, (int) $q['id']) as $m) {
            $cols = 'entity_id, user_id, from_business, kind, body, big, visible_at, created_at' . ($typed ? ', msg_type' : '');
            $vals = [$e, $uid, $m['from_business'] ? 1 : 0, 'message', $m['body'], 0, $m['at'], $m['at']];
            if ($typed) $vals[] = $m['from_business'] ? 'inquiry' : null;
            $pdo->prepare("INSERT INTO business_messages ($cols) VALUES (" . implode(', ', array_fill(0, count($vals), '?')) . ')')->execute($vals);
        }
        $pdo->prepare("UPDATE guest_inquiries SET status = 'moved', moved_user_id = ?, contact = NULL WHERE id = ?")->execute([$uid, (int) $q['id']]);
        $pdo->prepare('DELETE FROM guest_inquiry_messages WHERE inquiry_id = ?')->execute([(int) $q['id']]);
        return $e;
    }

    // ---- the listing ----------------------------------------------------------------------------------

    public static function bizList(PDO $pdo, int $e): array
    {
        $st = $pdo->prepare("SELECT id, name, contact_type, status, last_at, biz_read_at FROM guest_inquiries WHERE entity_id = ? AND status <> 'moved' ORDER BY last_at DESC LIMIT 100");
        $st->execute([$e]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $l = $pdo->prepare('SELECT body, from_business, created_at FROM guest_inquiry_messages WHERE inquiry_id = ? ORDER BY id DESC LIMIT 1');
            $l->execute([(int) $r['id']]);
            $last = $l->fetch(PDO::FETCH_ASSOC) ?: ['body' => '', 'from_business' => 0, 'created_at' => ''];
            $out[] = ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'contact_type' => (string) $r['contact_type'], 'status' => (string) $r['status'],
                      'at' => (string) $r['last_at'], 'last' => mb_strimwidth((string) $last['body'], 0, 90, '…'), 'mine' => (bool) (int) $last['from_business'],
                      'unread' => !(int) $last['from_business'] && ($r['biz_read_at'] === null || $r['biz_read_at'] < $last['created_at'])];
        }
        return $out;
    }

    private static function bizRow(PDO $pdo, int $e, int $id): array
    {
        $st = $pdo->prepare("SELECT * FROM guest_inquiries WHERE id = ? AND entity_id = ? AND status <> 'moved'");
        $st->execute([$id, $e]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: throw new InvalidArgumentException('That question isn\'t there.');
    }

    public static function bizThread(PDO $pdo, int $e, int $id): array
    {
        $q = self::bizRow($pdo, $e, $id);
        $pdo->prepare('UPDATE guest_inquiries SET biz_read_at = ? WHERE id = ?')->execute([self::now(), $id]);
        if (class_exists('Auth') && ($me = Auth::currentUser()) !== null) { require_once __DIR__ . '/Notify.php'; Notify::markRead($pdo, (int) $me['id'], [], 'biz.question', 'guestq:' . $e . ':' . $id); }
        return ['id' => $id, 'name' => (string) $q['name'], 'contact_type' => (string) $q['contact_type'], 'contact' => (string) ($q['contact'] ?? ''),
                'status' => (string) $q['status'], 'messages' => self::messages($pdo, $id)];
    }

    /** The listing answers. An email contact gets the answer by email, through Traversence. */
    public static function bizReply(PDO $pdo, int $staff, int $e, int $id, string $body, string $listingName): bool
    {
        $q = self::bizRow($pdo, $e, $id);
        if ($q['status'] === 'spam') throw new InvalidArgumentException('You marked this as spam.');
        $body = self::body($body);
        $now = self::now();
        $emailed = false;
        if ($q['contact_type'] === 'email' && $q['contact']) {
            require_once __DIR__ . '/Mailer.php';
            $url = rtrim(getenv('APP_URL') ?: '', '/') . '/listing/view.php?id=' . $e;
            try {
                Mailer::send((string) $q['contact'], "$listingName answered your question",
                    "$listingName replied on Traversence:\n\n$body\n\nTo reply, open $url and use \"Check a reply\" with the code you were given when you asked."
                    . "\n\nYou're getting this because you asked $listingName a question and chose to be answered by email. Nothing else will be sent.", (string) $q['name']);
                $emailed = true;
            } catch (Throwable $x) { error_log('Guest reply email failed: ' . $x->getMessage()); }
        }
        $pdo->prepare('INSERT INTO guest_inquiry_messages (inquiry_id, from_business, body, sent_by, emailed, created_at) VALUES (?, 1, ?, ?, ?, ?)')->execute([$id, $body, $staff, $emailed ? 1 : 0, $now]);
        $pdo->prepare("UPDATE guest_inquiries SET status = 'answered', last_at = ?, biz_read_at = ? WHERE id = ?")->execute([$now, $now, $id]);
        return $emailed;
    }

    /** spam | unreachable | open (undo). Two spam marks end guest messaging from that device. */
    public static function mark(PDO $pdo, int $e, int $id, string $what): void
    {
        if (!in_array($what, ['spam', 'unreachable', 'open'], true)) throw new InvalidArgumentException('Unknown choice.');
        $q = self::bizRow($pdo, $e, $id);
        $pdo->prepare('UPDATE guest_inquiries SET status = ? WHERE id = ?')->execute([$what, $id]);
        $dev = (string) $q['device_hash'];
        $st = $pdo->prepare('SELECT spam_count FROM guest_devices WHERE device_hash = ?');
        $st->execute([$dev]);
        $had = $st->fetchColumn();
        $delta = ($what === 'spam' && $q['status'] !== 'spam') ? 1 : (($q['status'] === 'spam' && $what !== 'spam') ? -1 : 0);
        if ($delta === 0) return;
        if ($had === false) $pdo->prepare('INSERT INTO guest_devices (device_hash, spam_count) VALUES (?, 0)')->execute([$dev]);
        $n = max(0, (int) $had + $delta);
        $pdo->prepare('UPDATE guest_devices SET spam_count = ?, blocked_at = ? WHERE device_hash = ?')->execute([$n, $n >= self::SPAM_BLOCK ? self::now() : null, $dev]);
    }

    /** New guest questions waiting across the listings this person manages. */
    public static function staffUnread(PDO $pdo, int $staff): int
    {
        if (!self::ready($pdo)) return 0;
        $st = $pdo->prepare("SELECT COUNT(*) FROM guest_inquiries g JOIN listing_access a ON a.entity_id = g.entity_id AND a.user_id = ?
                              WHERE g.status IN ('open', 'answered', 'unreachable') AND (g.biz_read_at IS NULL OR g.biz_read_at < g.last_at)
                                AND EXISTS (SELECT 1 FROM guest_inquiry_messages m WHERE m.inquiry_id = g.id AND m.from_business = 0 AND m.created_at >= COALESCE(g.biz_read_at, '1970-01-01'))");
        $st->execute([$staff]);
        return (int) $st->fetchColumn();
    }
}
