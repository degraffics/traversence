<?php
// app/scripts/notify_release.php — email held for people's quiet hours goes once they end (decisions/0172, the one
// dispatcher: Notify::releaseHeld). Every 10 minutes; sets itself up in cPanel through the API (Scheduler::AUTO).
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('notify_release');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Notify.php';
$n = Notify::releaseHeld(Database::connection());
echo $n ? "Sent $n held email" . ($n === 1 ? '' : 's') . ".\n" : "Nothing held is due.\n";
