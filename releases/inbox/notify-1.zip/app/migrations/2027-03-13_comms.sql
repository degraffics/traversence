-- 2027-03-13_comms.sql: one dispatcher into Pulse (decisions/0172 §4, §6 step 2). Add-only, safe to run twice.
-- comms_messages: every message Notify sends, one row per recipient (who, kind, level, words, where Pulse shows it).
-- comms_route:    its route, one row per stage per channel (created, addressed, held, sent, delivered, failed, read).
-- comms_prefs:    a person's choice per kind and channel (the Communications setting); no row = the kind's default.
-- comms_quiet:    a person's quiet hours (off unless they set them; minutes after midnight, in their own time zone).
-- Column names avoid MySQL 8's reserved words (no `from`, `to`, `end`, `channel`, `level`).

CREATE TABLE IF NOT EXISTS comms_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  kind VARCHAR(48) NOT NULL,
  lvl VARCHAR(12) NOT NULL DEFAULT 'notice',
  sender_type VARCHAR(10) NOT NULL DEFAULT 'system',
  sender_id INT UNSIGNED NULL,
  sender_name VARCHAR(120) NOT NULL DEFAULT '',
  to_user INT UNSIGNED NOT NULL,
  to_entity INT UNSIGNED NULL,
  thing VARCHAR(120) NOT NULL,
  thread VARCHAR(120) NOT NULL DEFAULT '',
  title VARCHAR(200) NOT NULL,
  body VARCHAR(2000) NOT NULL DEFAULT '',
  url VARCHAR(255) NOT NULL DEFAULT '',
  pulse_ref VARCHAR(120) NULL,
  times INT UNSIGNED NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  read_at DATETIME NULL,
  UNIQUE KEY comms_once (to_user, kind, thing),
  KEY comms_inbox (to_user, read_at),
  KEY comms_thread (to_user, kind, thread)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comms_route (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  message_id BIGINT UNSIGNED NOT NULL,
  via VARCHAR(12) NOT NULL,
  stage VARCHAR(12) NOT NULL,
  detail VARCHAR(255) NOT NULL DEFAULT '',
  provider_id VARCHAR(120) NOT NULL DEFAULT '',
  happened_at DATETIME NOT NULL,
  KEY comms_route_msg (message_id),
  KEY comms_route_held (stage, via, happened_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comms_prefs (
  user_id INT UNSIGNED NOT NULL,
  kind VARCHAR(48) NOT NULL,
  via VARCHAR(12) NOT NULL,
  is_on TINYINT(1) NOT NULL DEFAULT 1,
  changed_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, kind, via)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comms_quiet (
  user_id INT UNSIGNED NOT NULL PRIMARY KEY,
  quiet_from SMALLINT UNSIGNED NOT NULL,
  quiet_to SMALLINT UNSIGNED NOT NULL,
  tz VARCHAR(64) NOT NULL DEFAULT '',
  changed_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
