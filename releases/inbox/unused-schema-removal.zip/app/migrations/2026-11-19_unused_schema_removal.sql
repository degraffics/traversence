-- The unused tables and columns Jason approved removing (2026-11-19, Pulse #31; the Control Board's list, reviewed by the
-- session manager): no live code names them, no decision plans them, and every row of each column is empty (counted live
-- by SchemaUpkeep::filled). The tables are dated copies from decisions/0087's Oct 14 reset, the Stripe-era
-- subscriptions_old (0108) and guide_mentions (0132 moved its names into content tags). Each is copied first (0162), so
-- the removal can be undone from System Configuration -> Database updates -> Copies before migrations. Safe to run twice.
-- Kept, as Jason decided: service_area_zips, ai_credit_usage and the short-named columns (Keep), and every Unsure item.
-- Not here: degraff1_trv_admin.crawler_sources.target_entity_id (another database; its own release).
DROP TABLE IF EXISTS listing_actions_bak_20261014;
DROP TABLE IF EXISTS platform_counts_bak_20261014;
DROP TABLE IF EXISTS search_demand_bak_20261014;
DROP TABLE IF EXISTS subscriptions_old;
DROP TABLE IF EXISTS guide_mentions;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE cluster_overrides DROP COLUMN is_excluded', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cluster_overrides' AND COLUMN_NAME = 'is_excluded');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE cluster_overrides DROP COLUMN created_by_user_id', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cluster_overrides' AND COLUMN_NAME = 'created_by_user_id');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE community_help DROP COLUMN closed_at', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'community_help' AND COLUMN_NAME = 'closed_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE contributors DROP COLUMN home_place', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'contributors' AND COLUMN_NAME = 'home_place');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE crawl_capture_tasks DROP COLUMN fresh_days', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crawl_capture_tasks' AND COLUMN_NAME = 'fresh_days');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE opt_out_requests DROP COLUMN requested_by_email', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'opt_out_requests' AND COLUMN_NAME = 'requested_by_email');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE order_vendor_jobs DROP COLUMN expected_on', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_vendor_jobs' AND COLUMN_NAME = 'expected_on');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) > 0, 'ALTER TABLE order_work_orders DROP COLUMN vendor_cost_cents', 'DO 0') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_work_orders' AND COLUMN_NAME = 'vendor_cost_cents');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
