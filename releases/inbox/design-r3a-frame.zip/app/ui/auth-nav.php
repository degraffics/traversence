<?php
require_once __DIR__ . '/security-headers.php';
/**
 * includes/auth-nav.php
 *
 * The site's top bar (logo + Explore / Directory / profile / menu) for pages
 * that have their own markup: login.php, register.php, forgot/reset password,
 * verify-email, and so on. Three calls, each in one place:
 *
 *   <?php require_once __DIR__ . '/../app/ui/auth-nav.php'; ?>   // top of a page at the web root
 *   <head> ... <?php tv_nav_head(); ?> </head>                    // last thing in <head>
 *   <body ...>
 *   <?php tv_nav_bar(); ?>                                        // first thing in <body>
 *   ... the page's own form ...
 *   <?php tv_nav_foot(); ?>                                       // just before </body>
 *
 * (from a page in a sub-folder use  __DIR__ . '/../../app/ui/auth-nav.php')
 * It does not touch the page's own form or styles. Tailwind is only loaded if
 * the page has not already loaded it.
 */
require_once __DIR__ . '/routes.php';

function tv_nav_head(bool $loadTailwind = true): void
{
    require_once __DIR__ . '/favicon.php';
    echo tv_favicon_links() . "\n";   // the tab's icon, for every page that builds its own head
    if ($loadTailwind) echo '<script src="https://cdn.tailwindcss.com"></script>' . "\n";
    require_once __DIR__ . '/theme-tokens.php';
    echo tv_theme_tokens() . "\n";   // the design tokens (the sign-in pages' notices and buttons read them)
    echo '<style>#tv-nav{font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}</style>' . "\n";
}

function tv_nav_bar(): void
{
    ?>
<div id="tv-nav" class="bg-[#3E2B1F] border-b border-[#2A1B12] sticky top-0 z-40 shadow-lg">
  <div class="px-3 sm:px-6 py-1 flex items-center justify-between">
    <?php require_once __DIR__ . '/brand.php'; ?>
    <?php require_once __DIR__ . '/header.php'; ?>
  </div>
</div>
<?php
}

function tv_nav_foot(): void
{
    $root = dirname(__DIR__, 2) . '/website';   // the web root (website/)
    require_once __DIR__ . '/footer.php';
    tv_footer();
    require_once __DIR__ . '/location-modal.php';
    ?>
<script src="/js/location-scope.js?v=<?= (int)@filemtime($root . '/js/location-scope.js') ?>"></script>
<script src="/js/header-nav.js?v=<?= (int)@filemtime($root . '/js/header-nav.js') ?>" defer></script>
<?php
}
