<?php
/**
 * includes/brand.php — the logo lockup at the left of the top bar (decisions/0055 §2).
 *
 * Expanded: the full logo (compass, "Traversence" and the tagline, all in the image), in an outlined box. Minimized: the compass mark
 * only. The small tab beside the box switches between them; the choice is remembered in this browser. Phones always
 * show the mark. No animation: it changes instantly. Always a link home. Behavior: js/header-nav.js.
 * The slim bar (2026-10-09): the logo and the icons start collapsed, so the bar is just the mark (left) and the bell,
 * search and menu (right), and the page gets the screen. The tabs open them again; that choice is remembered.
 *
 * Images (site-root paths): /image/North-Star-logo.svg (the compass mark) and /image/Traversence-IC-logo.svg (the
 * name and tagline, text as outlines), side by side as in the lockup; /image/Logo-Gtext.png if the SVG can't load
 * (data-tv-fallback, js/tv-on.js: no inline handlers, for the card pages' policy).
 */
require_once __DIR__ . '/csp.php';
?>
<style>
  .tvb{display:flex;align-items:center;flex:none}
  .tvb-box{display:flex;align-items:center;gap:.6rem;border:1.5px solid var(--tv-taupe);border-radius:.8rem;padding:.3rem .7rem .3rem .45rem;text-decoration:none}
  .tvb-box:focus-visible{outline:2px solid var(--tv-line);outline-offset:2px}
  .tvb-mark{display:none;width:40px;height:40px}
  .tvb-full{display:flex;align-items:center;gap:.55rem}
  .tvb-full img{height:46px;width:auto;display:block}
  .tvb-full .tvb-star{height:50px}
  .tvb-tab{display:flex;align-items:center;justify-content:center;width:14px;height:26px;margin-left:-1px;background:var(--tv-taupe);color:var(--tv-ink);border:0;border-radius:0 .35rem .35rem 0;cursor:pointer;padding:0}
  .tvb-tab svg{width:10px;height:10px}
  .tv-brand-min .tvb-full{display:none}
  .tv-brand-min .tvb-mark{display:block}
  .tv-brand-min .tvb-box{padding:.25rem}
  .tv-brand-min .tvb-tab svg{transform:scaleX(-1)}
  /* collapsed: a small mark, no box, so the bar is slim */
  .tv-brand-min .tvb-box{border-color:transparent;padding:.1rem}
  .tv-brand-min .tvb-mark{width:34px;height:34px}
  .tv-brand-min.tv-nav-min #top-bar>div,.tv-brand-min.tv-nav-min #tv-nav>div{padding-top:2px;padding-bottom:2px}
  /* both collapsed (Jason's mockup, 2026-10-09): no bar. The compass is a brown block in the top-left corner, on top of the
     toolbar; the menu is a brown tab hanging from the top-right corner; the bell moves into the Pulse (a dot on the menu
     says something is waiting). Search, where a page has it, floats between them. */
  .tv-brand-min.tv-nav-min :is(#top-bar,#tv-nav){background:var(--tv-umber)!important;border-color:var(--tv-umber)!important;box-shadow:none!important;pointer-events:none}   /* collapsed, the bar keeps its dark brown (Jason, 2026-11-05) */
  .tv-brand-min.tv-nav-min :is(#top-bar,#tv-nav)>div{padding:0!important;align-items:flex-start}
  .tv-brand-min.tv-nav-min :is(#top-bar,#tv-nav) .tvn{pointer-events:none;align-items:flex-start;gap:0}
  .tv-brand-min.tv-nav-min :is(#top-bar,#tv-nav) :is(.tvb,.tvs-bar,.tvn-tab,.tvn-box){pointer-events:auto}
  .tv-brand-min.tv-nav-min .tvb{align-items:flex-start}
  .tv-brand-min.tv-nav-min .tvb-box{background:var(--tv-umber);border:0;border-radius:0 0 .7rem 0;padding:.45rem .65rem;width:64px;justify-content:center;box-shadow:2px 3px 10px -4px rgba(42,27,18,.55)}
  .tv-brand-min.tv-nav-min .tvb-mark{width:36px;height:36px}
  .tv-brand-min.tv-nav-min .tvb-tab{height:26px;margin-top:.7rem;border-radius:0 .35rem .35rem 0}
  .tv-brand-min.tv-nav-min .tvn-bell{display:none}
  .tv-brand-min.tv-nav-min .tvn-tab{margin:.7rem 0 0;border-radius:.35rem 0 0 .35rem}
  .tv-brand-min.tv-nav-min .tvn-box{background:var(--tv-umber);border:0;border-radius:0 0 0 .8rem;padding:.2rem .45rem .25rem .5rem;box-shadow:-2px 3px 10px -4px rgba(42,27,18,.55)}
  .tv-brand-min.tv-nav-min .tvn-menu{position:relative;width:40px;height:42px}.tv-brand-min.tv-nav-min .tvn-menu svg{width:28px;height:28px}
  .tv-brand-min.tv-nav-min .tvn:has(.tvn-badge:not([hidden])) .tvn-menu::after{content:"";position:absolute;top:7px;right:3px;width:9px;height:9px;border-radius:50%;background:var(--tv-copper);box-shadow:0 0 0 2px var(--tv-umber)}
  .tv-brand-min.tv-nav-min .tvs-bar{margin-top:.45rem;border:2px solid var(--tv-umber);box-shadow:0 2px 8px rgba(42,27,18,.3)}
  @media (min-width: 768px){ .tv-brand-min.tv-nav-min .tvb-box{border-radius:0;box-shadow:none} }   /* it sits on the toolbar, one piece */
  @media (max-width: 767px){ .tv-brand-min.tv-nav-min .tvb-box{width:auto;padding:.4rem .5rem} .tv-brand-min.tv-nav-min .tvs-bar{border:0;box-shadow:none;margin-top:.4rem}
    .tv-brand-min.tv-nav-min .tvs-open{border:2px solid var(--tv-umber);box-shadow:0 2px 8px rgba(42,27,18,.3)} }
  @media (max-width: 767px){ .tvb-full{display:none!important} .tvb-mark{display:block!important} .tvb-box{padding:.25rem} .tvb-tab{display:none} }
</style>
<div class="tvb" id="tv-brand">
  <a href="/" id="brand-link" class="tvb-box" aria-label="Traversence home" title="Traversence home">
    <span id="brand-mark" class="tvb-full"><img class="tvb-star" src="/image/North-Star-logo.svg" alt=""><img id="header-logo" src="/image/Traversence-IC-logo.svg" alt="Traversence: The Immersion and Connection Engine"
      data-tv-fallback="/image/Logo-Gtext.png"></span>
    <img id="brand-icon-img" class="tvb-mark" src="/image/North-Star-logo.svg" alt="Traversence">
  </a>
  <button type="button" class="tvb-tab" data-tv-toggle="brand" aria-label="Collapse or expand the logo" title="Collapse or expand">
    <svg viewBox="0 0 10 10" aria-hidden="true"><path d="M7 1 3 5l4 4" fill="none" stroke="currentColor" stroke-width="2"/></svg>
  </button>
</div>
<script<?= tv_nonce() ?>>
  // the signed-in side (your account, staff) looks different on a phone (app-shell.php): mark it here, since every page has the logo
  if (/^\/(user|admin)\/|^\/listing\/businessportal/.test(location.pathname)) document.body.classList.add('tv-back');
  // Remembered state before first paint, so nothing jumps. Collapsed (the slim bar) unless the person opened it.
  (function () { try { var s = JSON.parse(localStorage.getItem('tv_header') || '{}'); if (s.brand !== 'full') document.documentElement.classList.add('tv-brand-min'); if (s.nav !== 'full') document.documentElement.classList.add('tv-nav-min'); } catch (e) {} })();
</script>
