<?php
// api/crawl/service.php — the crawler as one service (decisions/0160 §2): the worker's plan for a run, and its report.
// Worker token required. Contract 2 (an older worker never calls this and runs its fixed order as before).
//   POST {start: {run_key, worker_v, budget, fetches, have: [tasks]}}
//        -> {run_id, run_key, paused, why, contract, plan: [{task, wf, mode, seconds, fetches, paid, per_run}], requests: [{id, wf, kind, ref, payload}]}
//   POST {report: {run_key, status: ok|failed, why, seconds, fetches, searches, engine,
//                  items: [{task, outcome: done|idle|not_reached|failed|off|skipped, allotted, seconds, fetches, searches, places, counts, why}],
//                  requests: [{id, outcome: done|failed|back, result, why}]}}
//        -> {status, counts}
//   GET  -> {ready, contract}   (the worker asks once whether the site has the service yet)

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/crawler/CrawlService.php';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') Response::json(['ok' => true, 'ready' => CrawlService::ready($pdo), 'contract' => CrawlService::CONTRACT]);
    Response::requireMethod('POST');
    if (!CrawlService::ready($pdo)) Response::json(['ok' => true, 'ready' => false, 'note' => 'The crawler service isn\'t set up yet (its database update runs within the hour).']);
    $b = Response::jsonBody();
    if (isset($b['start']) && is_array($b['start'])) Response::json(['ok' => true, 'ready' => true] + CrawlService::plan($pdo, $b['start']));
    if (isset($b['report']) && is_array($b['report'])) Response::json(['ok' => true] + CrawlService::report($pdo, $b['report']));
    Response::error('Start a run or report one.', 422, 'bad_request');
} catch (InvalidArgumentException $e) {
    Response::error($e->getMessage(), 422, 'bad_request');
} catch (Throwable $e) {
    error_log('api/crawl/service.php: ' . $e->getMessage());
    Response::error('The crawler service had a problem: ' . mb_substr($e->getMessage(), 0, 200), 500, 'server_error');
}
