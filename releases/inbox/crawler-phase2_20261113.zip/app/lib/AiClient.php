<?php
// app/lib/AiClient.php — the AI services the site reads pictures and words with (decisions/0108): one place for the
// providers, their keys, the job queue and what it costs. Each provider is on when its key is in .env:
//   Claude (Anthropic)    ANTHROPIC_API_KEY                         cards, brochures, photo → product, writing
//   Google Document AI    GOOGLE_DOCAI_KEY_FILE, GOOGLE_DOCAI_PROCESSOR   menus and price lists (with the Studio)
//   AWS Textract          AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION   tables and forms (with the Studio)
// AI_MONTHLY_CAP_USD (default 25) stops the queue for the month when reached; the Pulse says so. Nothing read by AI
// goes live on its own: a person checks it first. Calls are plain HTTPS (no Composer on Bluehost).
declare(strict_types=1);

final class AiClient
{
    public const PROVIDERS = [
        'claude' => ['Claude (Anthropic)', ['ANTHROPIC_API_KEY']],
        'google' => ['Google Document AI', ['GOOGLE_DOCAI_KEY_FILE', 'GOOGLE_DOCAI_PROCESSOR']],
        'aws' => ['AWS Textract', ['AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'AWS_REGION']],
    ];
    // what each kind of job uses first, then next (only providers that are on are tried)
    public const ROUTES = ['card' => ['claude'], 'brochure' => ['claude'], 'photo_product' => ['claude'], 'menu' => ['google', 'aws', 'claude'],
                           'guide_names' => ['claude'], 'guide_find' => ['claude'], 'place_about' => ['claude'], 'source_terms' => ['claude'], 'find_settle' => ['claude'], 'page_extract' => ['claude'], 'scan_read' => ['aws'], 'guide_draft' => ['claude'], 'heritage_extract' => ['claude'], 'topic_summary' => ['claude'], 'topic_assist' => ['claude'], 'topic_research' => ['claude'], 'live_events' => ['claude'], 'fact_check' => ['claude'], 'item_write' => ['claude']];   // a guide's names, finding one we don't have, and its draft (decisions/0131)
    /** Claude's web search: dollars per search (Anthropic's list price, $10 per 1,000). */
    private const SEARCH_USD = 0.01;
    // dollars per million tokens (input, output), for the running cost; Anthropic's list prices
    private const PRICES = ['claude-haiku-5-5' => [0.10, 0.50], 'claude-sonnet-5-5' => [2.00, 10.00], 'claude-opus-5-5' => [4.00, 20.00]];

    private static function env(string $k): string
    {
        // the staging copy: paid AI only while its switch is on for a test (decisions/0145 Phase 3); nothing changes on live
        if (in_array($k, ['ANTHROPIC_API_KEY', 'GOOGLE_DOCAI_KEY_FILE', 'AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY'], true)) { require_once __DIR__ . '/Staging.php'; if (!Staging::allow('ai')) return ''; }
        return trim((string) (getenv($k) ?: ''));
    }

    public static function ready(PDO $pdo): bool { try { $pdo->query('SELECT 1 FROM ' . Database::t('ai_jobs') . ' LIMIT 0'); return true; } catch (Throwable) { return false; } }

    public static function on(string $provider): bool
    {
        foreach (self::PROVIDERS[$provider][1] ?? ['-'] as $k) if (self::env($k) === '') return false;
        return true;
    }

    /** "…a1b2" — the end of the key, never the key. */
    public static function keyHint(string $provider): string
    {
        $k = self::env(self::PROVIDERS[$provider][1][0] ?? '');
        return $k === '' ? '' : '…' . substr($k, -4);
    }

    public static function capUsd(): float { $c = (float) (self::env('AI_MONTHLY_CAP_USD') ?: 25); return $c > 0 ? $c : 25.0; }

    /** This month's spend in dollars. */
    public static function monthUsd(PDO $pdo): float
    {
        try { return (int) $pdo->query("SELECT COALESCE(SUM(cost_micros), 0) FROM " . Database::t('ai_jobs') . " WHERE created_at >= '" . date('Y-m-01') . "'")->fetchColumn() / 1e6; } catch (Throwable) { return 0.0; }
    }

    // ---- AI use: each feature's switch, model, daily runs, monthly budget and web searches (System Configuration → AI use) ----

    /** The AI features the site runs on its own: key => [name, what it does, default model, runs a day, web searches, on by default]. */
    public const FEATURES = [
        'guide_research' => ['Research briefs', 'Before a guide is written, Claude researches the place once, in depth, on the web: its peoples and founding, families and events, faith, food and crafts, the year\'s festivals, the land, and what it\'s like to be there. The brief is kept with the place, so later guides reuse it.', 'claude-sonnet-5-5', 5, 10, true],
        'guide_draft' => ['Guide drafts (asked for)', 'Claude writes a guide\'s empty sections when someone presses Write a draft, from the dossier our crawler gathered (searching the web only for what it lacks).', 'claude-sonnet-5-5', 20, 3, true],
        'guide_draft_auto' => ['Guide drafts on their own', 'The guide job compiles unwritten city and community guides by itself, busiest first, from the crawler\'s dossier.', 'claude-sonnet-5-5', 3, 2, true],
        'guide_names' => ['Names in guides', 'Reads a guide\'s text for the places it names, so they link.', 'claude-haiku-5-5', 100, 0, true],
        'content_names' => ['Names in journeys and stories', 'Reads published journeys, stories, experiences and how-tos for the places they name (a member\'s only with their consent).', 'claude-haiku-5-5', 100, 0, true],
        'guide_triage' => ['Guide fixes before a rewrite', 'When the monthly check finds a passed date, a closed business or a dead link in what Claude wrote, the cheapest model proposes the exact sentences to change; they are applied only when they fix it, and the guide is rewritten in full only when they don\'t.', 'claude-haiku-5-5', 40, 0, true],
        'heritage_extract' => ['Heritage facts', 'Reads the passages about a place\'s past (the Library of Congress\'s records, the crawler\'s dossier, the research brief) into facts for the heritage catalog: turning points, people, trades, materials, water and land, hardships, lore and places to stand on today. Only what the passages say.', 'claude-haiku-5-5', 10, 0, true],
        'topic_summary' => ['Topic summaries', 'Writes each topic\'s summary in the Topic index from its vetted facts only, and again when they change.', 'claude-haiku-5-5', 20, 0, true],
        'topic_assist' => ['AI assist on a topic', 'Writes about a topic from our Topic index (its vetted facts, summary and research), citing what it used; a thin topic is queued for research.', 'claude-sonnet-5-5', 30, 0, true],
        'topic_research' => ['Topic research', 'Researches the most asked-for thin topics on the web, kept with the topic as unvetted research for the next call.', 'claude-sonnet-5-5', 3, 5, true],
        'fact_check' => ['Check my facts', 'When someone presses Check my facts in a guide\'s editor, reads what our team wrote against what we hold (the dossier, the research brief, the heritage catalog) and lists what disagrees or isn\'t supported. Never changes their words.', 'claude-haiku-5-5', 30, 0, true],
        'live_events' => ['Live events', 'Finds what\'s coming up in each place with a live guide (Content templates → Live events), from its official event pages first, web search only for what they don\'t list. Runs only while the template is set running.', 'claude-sonnet-5-5', 10, 3, true],
        'item_write' => ['Write it for me (catalog)', 'Writes a catalog item\'s description when a business presses Write it for me, from its name, kind and details only; paid from the business\'s AI credits (AiCredits), and nothing is saved until the business saves it.', 'claude-haiku-5-5', 200, 0, true],
        'guide_ondemand' => ['Guides on demand', 'A first look at a place someone searched that has no guide: written at once from what we hold and the free sources, at most one web search, then the full guide follows within two days. Spends at most half of each day\'s AI allowance; past it, places wait for the next day, most-searched first (decisions/0147).', 'claude-sonnet-5-5', 40, 1, true],
        'guide_find' => ['Find it', 'Looks on the web for a place a guide names that we don\'t have yet, for Review, when our crawler (OpenStreetMap and the place\'s own website) couldn\'t find it.', 'claude-sonnet-5-5', 30, 5, true],
        'place_about' => ['Place descriptions', 'Writes what a place is and what you do there (2 to 3 sentences, its activities and sources) the first time someone opens a place that has no Wikipedia summary, kept as research and reused (decisions/0148).', 'claude-haiku-5-5', 60, 1, true],
        // the second tier, where the free steps fall short (decisions/0157): off until Jason switches each on and sets its budget
        'source_terms' => ['Source terms (second tier)', 'Reads the terms of a website waiting for a call (a chamber, a tourism site, an organization) and decides whether our crawler reads it regularly or only cites it, with the exact sentence it relied on (a quote not in the terms isn\'t used). Never a tribal nation\'s site.', 'claude-haiku-5-5', 20, 0, false],
        'find_settle' => ['Settle a find (second tier)', 'Looks up on the web a business the free steps couldn\'t confirm (waiting in Review after the second look): open, closed or not found, each with its sources and the words on them, checked on the pages themselves. Confirmed ones are published through the usual rules, closed ones turned down (undoable in Review); the rest stay for a person. Never places on a nation\'s land or kept private.', 'claude-sonnet-5-5', 20, 3, false],
        'page_extract' => ['Read a page through Tavily (second tier)', 'A page of a source we read that our crawler couldn\'t fetch, or that shows nothing without a browser: Tavily Extract reads its text (about $0.0016 a page; TAVILY_API_KEY on the worker). Never a page robots.txt or the site refuses. Pages a day and pages a crawler run are set here.', 'claude-haiku-5-5', 30, 3, false],
        'scan_read' => ['Read a scanned PDF (second tier)', 'A scanned PDF (pictures of pages, no text) on a source we read: AWS Textract reads it (about $0.0015 a page, one page at a time for now), and our crawler reads its text into places like any page. Runs a day here are scans a day.', 'claude-haiku-5-5', 10, 0, false],
    ];
    /**
     * Switches that spend nothing themselves, each with the lowest confidence score (0-100) it acts on:
     * key => [name, what it does, on by default, lowest score by default]. Kept in ai_features like the rest (the score in per_day).
     */
    public const SWITCHES = [
        'guide_publish' => ['Guides publish themselves', 'A guide Claude compiles goes live by itself when its confidence score reaches this; below it, it waits as a draft for a person. Our team edits or takes down any guide later. A name that may mark a protected site, or a closed business, always holds it back.', true, 70],
        'guide_find_add' => ['Finds become listings by themselves', 'A business, museum or organization a guide names that Find it confirms (our crawler first, then Claude) is added as a listing, and the name linked, when its score reaches this; below it, it waits in Review. One we already list (same phone or website) is linked instead.', true, 80],
    ];
    /**
     * Features that aren't Claude (the second tier's Tavily and Textract reads, decisions/0157): no model to choose, and their
     * fields named for what they count. feature => [runs a day label, per-run label and its note (or null: none)].
     */
    public const NOT_CLAUDE = [
        'page_extract' => ['Pages a day', ['Pages a crawler run', '1 to 20 (0 = 3); the crawler runs every 5 minutes; each page about 0.16¢']],
        'scan_read' => ['Scans a day', null],
    ];

    /** What a call would cost in dollars: tokens in and out at the model's price, and each web search. */
    public static function estimate(string $model, int $in, int $out, int $searches): float
    {
        [$pi, $po] = self::PRICES[$model] ?? [4.00, 20.00];
        return ($in * $pi + $out * $po) / 1e6 + $searches * self::SEARCH_USD;
    }

    public const MODELS = ['claude-haiku-5-5' => 'Haiku (quick, cheapest)', 'claude-sonnet-5-5' => 'Sonnet (balanced)', 'claude-opus-5-5' => 'Opus (most capable, priciest)'];

    /** @var array<string, array>|null the features' rows, read once a request (and again after a change) */
    private static ?array $featRows = null;

    /** A feature's settings: its row, else its defaults. [enabled, model, per_day, month_usd, searches]. */
    public static function feature(PDO $pdo, string $f): array
    {
        $d = self::FEATURES[$f] ?? (isset(self::SWITCHES[$f]) ? ['', '', 'claude-haiku-5-5', self::SWITCHES[$f][3], 0, self::SWITCHES[$f][2]] : ['', '', 'claude-haiku-5-5', 0, 0, true]);
        if (self::$featRows === null) { self::$featRows = []; try { foreach ($pdo->query('SELECT * FROM ai_features')->fetchAll(PDO::FETCH_ASSOC) as $r) self::$featRows[$r['feature']] = $r; } catch (Throwable) {} }
        $r = self::$featRows[$f] ?? null;
        return ['enabled' => $r ? (bool) $r['enabled'] : (bool) $d[5], 'model' => $r && isset(self::MODELS[$r['model']]) ? (string) $r['model'] : (string) $d[2],
                'per_day' => $r ? (int) $r['per_day'] : (int) $d[3], 'month_usd' => $r ? (float) $r['month_usd'] : 0.0, 'searches' => $r ? (int) $r['searches'] : (int) $d[4]];
    }

    /** Runs and dollars for a feature: today and this month. */
    public static function used(PDO $pdo, string $f): array
    {
        try {
            $st = $pdo->prepare('SELECT SUM(created_at >= CURDATE()) d, COUNT(*) m, COALESCE(SUM(cost_micros), 0) c FROM ' . Database::t('ai_jobs') . " WHERE kind = ? AND created_at >= ?");
            $st->execute([$f, date('Y-m-01')]); $r = $st->fetch(PDO::FETCH_ASSOC);
            return ['today' => (int) $r['d'], 'month' => (int) $r['m'], 'usd' => (int) $r['c'] / 1e6];
        } catch (Throwable) { return ['today' => 0, 'month' => 0, 'usd' => 0.0]; }
    }

    /** May this feature run now? [yes, why not]. Claude on, the month's overall cap, the feature switched on, its daily runs and its own budget. */
    public static function allow(PDO $pdo, string $f): array
    {
        self::$asking = $f;   // a paid answer that then fails is counted against it (review D16)
        if (!self::on('claude')) return [false, 'Claude isn\'t connected (ANTHROPIC_API_KEY in .env).'];
        if (!self::ready($pdo)) return [false, 'The AI jobs table isn\'t set up.'];
        if (self::overCap($pdo)) return [false, 'The month\'s AI cap ($' . number_format(self::capUsd(), 2) . ') is reached: it starts again on the 1st.'];
        $c = self::feature($pdo, $f);
        if (!$c['enabled']) return [false, (self::FEATURES[$f][0] ?? 'This') . ' is switched off in System Configuration → AI use.'];
        $u = self::used($pdo, $f);
        if ($c['per_day'] > 0 && $u['today'] >= $c['per_day']) return [false, (self::FEATURES[$f][0] ?? 'This') . ' has had its ' . $c['per_day'] . ' run' . ($c['per_day'] === 1 ? '' : 's') . ' today: more tomorrow.'];
        if ($c['month_usd'] > 0 && $u['usd'] >= $c['month_usd']) return [false, (self::FEATURES[$f][0] ?? 'This') . ' has used its $' . number_format($c['month_usd'], 2) . ' for the month.'];
        return [true, ''];
    }

    /** Save a feature's settings (System Configuration → AI use). */
    public static function setFeature(PDO $pdo, string $f, array $in, int $uid): void
    {
        if (isset(self::SWITCHES[$f])) $in = ['enabled' => !empty($in['enabled']), 'model' => 'claude-haiku-5-5', 'per_day' => max(0, min(100, (int) ($in['min_score'] ?? self::SWITCHES[$f][3])))];   // a switch: on or off, and its lowest score
        elseif (!isset(self::FEATURES[$f])) throw new InvalidArgumentException('Unknown AI feature.');
        $model = isset(self::MODELS[$in['model'] ?? '']) ? (string) $in['model'] : (self::FEATURES[$f][2] ?? 'claude-haiku-5-5');
        $pdo->prepare('INSERT INTO ai_features (feature, enabled, model, per_day, month_usd, searches, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                       ON DUPLICATE KEY UPDATE enabled = VALUES(enabled), model = VALUES(model), per_day = VALUES(per_day), month_usd = VALUES(month_usd), searches = VALUES(searches), updated_by = VALUES(updated_by), updated_at = NOW()')
            ->execute([$f, !empty($in['enabled']) ? 1 : 0, $model, max(0, min(10000, (int) ($in['per_day'] ?? 0))), max(0, min(10000, round((float) ($in['month_usd'] ?? 0), 2))), max(0, min(20, (int) ($in['searches'] ?? 0))), $uid ?: null]);
        self::$featRows = null;   // read fresh
    }

    /** This month by service: provider => [dollars, jobs done, by kind => count]. */
    public static function monthBy(PDO $pdo): array
    {
        $out = [];
        try {
            foreach ($pdo->query("SELECT provider, kind, COUNT(*) n, COALESCE(SUM(cost_micros), 0) c FROM " . Database::t('ai_jobs') . " WHERE status = 'done' AND provider <> '' AND created_at >= '" . date('Y-m-01') . "' GROUP BY provider, kind") as $r) {
                $o = &$out[$r['provider']]; $o ??= [0.0, 0, []];
                $o[0] += (int) $r['c'] / 1e6; $o[1] += (int) $r['n']; $o[2][$r['kind']] = (int) $r['n'];
            }
        } catch (Throwable) {}
        return $out;
    }

    public static function overCap(PDO $pdo): bool { return self::monthUsd($pdo) >= self::capUsd(); }

    /** The first provider that is on for a kind of job, or ''. */
    public static function providerFor(string $kind): string
    {
        foreach (self::ROUTES[$kind] ?? [] as $p) if (self::on($p)) return $p;
        return '';
    }

    public static function enqueue(PDO $pdo, string $kind, int $refId, int $by): int
    {
        $pdo->prepare('INSERT INTO ' . Database::t('ai_jobs') . ' (kind, ref_id, created_by) VALUES (?, ?, ?)')->execute([$kind, $refId, $by]);
        return (int) $pdo->lastInsertId();
    }

    /** A call made straight away (not through the queue), kept with its cost so the monthly cap counts it. */
    public static function record(PDO $pdo, string $kind, int $refId, string $status, array $r, int $by = 0, string $charged = ''): void
    {
        try {
            $pdo->prepare('INSERT INTO ' . Database::t('ai_jobs') . ' (kind, ref_id, provider, model, status, attempts, result, error, tokens_in, tokens_out, cost_micros, charged_to, created_by, started_at, done_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())')
                ->execute([$kind, $refId, (string) ($r['provider'] ?? 'claude'), (string) ($r['model'] ?? ''), $status, isset($r['data']) ? json_encode($r['data'], JSON_UNESCAPED_UNICODE) : null,
                    mb_substr((string) ($r['error'] ?? ''), 0, 500), (int) ($r['in'] ?? 0), (int) ($r['out'] ?? 0), (int) ($r['micros'] ?? 0), $charged !== '' ? mb_substr($charged, 0, 20) : 'staff', $by ?: null]);
        } catch (Throwable $x) { error_log('ai record: ' . $x->getMessage()); }
    }

    /** Takes a queued job for this worker (so two never run the same one). Returns the job or null. */
    public static function claim(PDO $pdo, int $jobId = 0): ?array
    {
        $sql = "SELECT * FROM " . Database::t('ai_jobs') . " WHERE status = 'queued'" . ($jobId ? ' AND id = ' . $jobId : '') . ' ORDER BY id LIMIT 1';
        $j = $pdo->query($sql)->fetch(PDO::FETCH_ASSOC);
        if (!$j) return null;
        $st = $pdo->prepare("UPDATE " . Database::t('ai_jobs') . " SET status = 'working', started_at = NOW(), attempts = attempts + 1 WHERE id = ? AND status = 'queued'");
        $st->execute([(int) $j['id']]);
        return $st->rowCount() ? $j : null;
    }

    public static function finish(PDO $pdo, int $id, string $status, array $r): void
    {
        $pdo->prepare('UPDATE ' . Database::t('ai_jobs') . ' SET status = ?, provider = ?, model = ?, result = ?, error = ?, tokens_in = ?, tokens_out = ?, cost_micros = ?, done_at = NOW() WHERE id = ?')
            ->execute([$status, (string) ($r['provider'] ?? ''), (string) ($r['model'] ?? ''), isset($r['data']) ? json_encode($r['data'], JSON_UNESCAPED_UNICODE) : null,
                mb_substr((string) ($r['error'] ?? ''), 0, 500), (int) ($r['in'] ?? 0), (int) ($r['out'] ?? 0), (int) ($r['micros'] ?? 0), $id]);
    }

    /** A job that failed for a passing reason (busy, timeout) goes back in the queue, up to 3 tries. */
    public static function retryLater(PDO $pdo, int $id, string $why): void
    {
        $pdo->prepare("UPDATE " . Database::t('ai_jobs') . " SET status = IF(attempts >= 3, 'failed', 'queued'), error = ? WHERE id = ?")->execute([mb_substr($why, 0, 500), $id]);
    }

    // ---- Claude ----------------------------------------------------------------------------------------------------

    /**
     * Asks Claude a question in words, for JSON that fits $schema; with $search it may search the web (up to $search
     * times) first. Same return and errors as claudeRead(); the cost includes the searches.
     */
    public static function claudeAsk(string $instructions, array $schema, string $model, int $search = 0, int $maxTokens = 2048, string $effort = 'low'): array
    {
        $key = self::env('ANTHROPIC_API_KEY');
        if ($key === '') throw new RuntimeException('Claude isn\'t connected: add ANTHROPIC_API_KEY to .env.');
        $messages = [['role' => 'user', 'content' => $instructions]];
        $body = ['model' => $model, 'max_tokens' => $maxTokens, 'messages' => $messages, 'output_config' => ['effort' => $effort, 'format' => ['type' => 'json_schema', 'schema' => $schema]]];
        if ($search > 0) $body['tools'] = [['type' => 'web_search_20250305', 'name' => 'web_search', 'max_uses' => $search, 'user_location' => ['type' => 'approximate', 'country' => 'US']]];
        $in = 0; $out = 0; $searches = 0; $j = []; $searchError = '';
        try {
            for ($turn = 0; $turn < 3; $turn++) {   // a long search can pause the turn: send it back to finish
                $j = self::post($key, $body);
                $in += (int) ($j['usage']['input_tokens'] ?? 0); $out += (int) ($j['usage']['output_tokens'] ?? 0); $searches += (int) ($j['usage']['server_tool_use']['web_search_requests'] ?? 0);
                foreach ($j['content'] ?? [] as $b) if (($b['type'] ?? '') === 'web_search_tool_result' && ($b['content']['type'] ?? '') === 'web_search_tool_result_error') $searchError = (string) ($b['content']['error_code'] ?? 'error');   // e.g. web search not turned on for the organization
                if (($j['stop_reason'] ?? '') !== 'pause_turn') break;
                $body['messages'] = [$messages[0], ['role' => 'assistant', 'content' => $j['content'] ?? []]];
            }
            if (($j['stop_reason'] ?? '') === 'refusal') throw new RuntimeException('Claude declined this one.');
            $text = '';
            foreach ($j['content'] ?? [] as $b) if (($b['type'] ?? '') === 'text') $text = (string) $b['text'];   // the answer is the last text
            $data = json_decode($text, true);
            if (!is_array($data)) throw new RuntimeException(($j['stop_reason'] ?? '') === 'max_tokens' ? 'The answer was cut off.' : 'Claude\'s answer wasn\'t readable.');
        } catch (Throwable $e) {
            self::paidFailure($model, $in, $out, $searches, $e->getMessage());   // paid for, then failed: still counted (review D16)
            throw $e;
        }
        [$pi, $po] = self::PRICES[$model] ?? [4.00, 20.00];
        return ['data' => $data, 'in' => $in, 'out' => $out, 'searches' => $searches, 'search_error' => $searchError, 'micros' => (int) ceil($in * $pi + $out * $po + $searches * self::SEARCH_USD * 1e6), 'model' => $model, 'provider' => 'claude'];
    }

    /** The feature that last asked allow() (the one calling Claude now), for paidFailure(). */
    private static string $asking = '';

    /**
     * A call Claude answered and billed, that then failed here (a refusal, a cut-off or unreadable answer, a second turn
     * that errored): recorded with its cost against the feature that asked, so the month's cap and the feature's own
     * budget see it (review D16, 2026-11-13; decisions/0160 §5: every call's cost is counted, failed calls included).
     * The caller's own "failed" record, if any, carries no cost, so nothing counts twice.
     */
    private static function paidFailure(string $model, int $in, int $out, int $searches, string $why): void
    {
        if ($in + $out + $searches === 0) return;   // nothing was billed (it never reached Claude)
        [$pi, $po] = self::PRICES[$model] ?? [4.00, 20.00];
        try {
            self::record(Database::connection(), self::$asking !== '' ? self::$asking : 'unattributed', 0, 'failed',
                ['provider' => 'claude', 'model' => $model, 'in' => $in, 'out' => $out, 'micros' => (int) ceil($in * $pi + $out * $po + $searches * self::SEARCH_USD * 1e6), 'error' => 'Paid, then failed: ' . $why]);
        } catch (Throwable $x) { error_log('ai paid failure: ' . $x->getMessage()); }
    }

    /** One call to the Messages API; errors as plain reasons (code 1: try again later). */
    private static function post(string $key, array $body): array
    {
        $base = rtrim(self::env('ANTHROPIC_BASE_URL') ?: 'https://api.anthropic.com', '/');
        $ch = curl_init($base . '/v1/messages');
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 90, CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => ['content-type: application/json', 'x-api-key: ' . $key, 'anthropic-version: 2023-06-01'],
            CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_SLASHES)]);
        $raw = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $cerr = curl_error($ch); curl_close($ch);
        if ($raw === false) throw new RuntimeException('Couldn\'t reach Claude (' . $cerr . ').', 1);
        $j = json_decode((string) $raw, true) ?: [];
        if ($code === 401 || $code === 403) throw new RuntimeException('Claude refused the key: check ANTHROPIC_API_KEY.');
        if ($code === 400 && str_contains((string) ($j['error']['message'] ?? ''), 'credit')) throw new RuntimeException('The Claude account is out of credit: add credit in the Anthropic console.');
        if ($code === 429 || $code === 529 || $code >= 500) throw new RuntimeException('Claude is busy; trying again shortly.', 1);
        if ($code !== 200) throw new RuntimeException('Claude said: ' . mb_substr((string) ($j['error']['message'] ?? 'error ' . $code), 0, 200));
        return $j;
    }

    /**
     * Asks Claude to read images into JSON that fits $schema. $images: [[mime, bytes], …]. Returns
     * ['data' => array, 'in' => tokens, 'out' => tokens, 'micros' => cost, 'model' => …, 'provider' => 'claude'].
     * Throws RuntimeException with a plain reason; ->getCode() 1 means "try again later" (busy, timeout, 5xx).
     */
    public static function claudeRead(array $images, string $instructions, array $schema, string $model): array
    {
        $key = self::env('ANTHROPIC_API_KEY');
        if ($key === '') throw new RuntimeException('Claude isn\'t connected: add ANTHROPIC_API_KEY to .env.');
        $content = [];
        foreach ($images as [$mime, $bytes]) $content[] = ['type' => 'image', 'source' => ['type' => 'base64', 'media_type' => $mime, 'data' => base64_encode($bytes)]];
        $content[] = ['type' => 'text', 'text' => $instructions];
        $body = ['model' => $model, 'max_tokens' => 2048, 'messages' => [['role' => 'user', 'content' => $content]],
            'output_config' => ['effort' => 'low', 'format' => ['type' => 'json_schema', 'schema' => $schema]]];
        $base = rtrim(self::env('ANTHROPIC_BASE_URL') ?: 'https://api.anthropic.com', '/');
        $ch = curl_init($base . '/v1/messages');
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 45, CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => ['content-type: application/json', 'x-api-key: ' . $key, 'anthropic-version: 2023-06-01'],
            CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_SLASHES)]);
        $raw = curl_exec($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $cerr = curl_error($ch); curl_close($ch);
        if ($raw === false) throw new RuntimeException('Couldn\'t reach Claude (' . $cerr . ').', 1);
        $j = json_decode((string) $raw, true) ?: [];
        if ($code === 401 || $code === 403) throw new RuntimeException('Claude refused the key: check ANTHROPIC_API_KEY.');
        if ($code === 400 && str_contains((string) ($j['error']['message'] ?? ''), 'credit')) throw new RuntimeException('The Claude account is out of credit: add credit in the Anthropic console.');
        if ($code === 429 || $code === 529 || $code >= 500) throw new RuntimeException('Claude is busy; trying again shortly.', 1);
        if ($code !== 200) throw new RuntimeException('Claude said: ' . mb_substr((string) ($j['error']['message'] ?? 'error ' . $code), 0, 200));
        $in = (int) ($j['usage']['input_tokens'] ?? 0); $out = (int) ($j['usage']['output_tokens'] ?? 0);
        $text = '';
        foreach ($j['content'] ?? [] as $b) if (($b['type'] ?? '') === 'text') $text .= $b['text'];
        $data = json_decode($text, true);
        $fail = ($j['stop_reason'] ?? '') === 'refusal' ? 'Claude declined to read this image.' : (!is_array($data) ? (($j['stop_reason'] ?? '') === 'max_tokens' ? 'The answer was cut off.' : 'Claude\'s answer wasn\'t readable.') : '');
        if ($fail !== '') { self::paidFailure($model, $in, $out, 0, $fail); throw new RuntimeException($fail); }   // paid for, then failed: still counted (review D16)
        [$pi, $po] = self::PRICES[$model] ?? [4.00, 20.00];
        return ['data' => $data, 'in' => $in, 'out' => $out, 'micros' => (int) ceil($in * $pi + $out * $po), 'model' => $model, 'provider' => 'claude'];
    }
}
