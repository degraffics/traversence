-- The crawler as one service (decisions/0160 §2, handoffs/crawler-revamp.md Phase 2): the workflows and their capture
-- tasks, the runs and what each did task by task, the one queue of requests, and the cost ledger. Only adds, and is safe to
-- run twice (CREATE TABLE IF NOT EXISTS, INSERT IGNORE).

CREATE TABLE IF NOT EXISTS crawl_workflows (
  wf VARCHAR(8) NOT NULL,
  name VARCHAR(80) NOT NULL,
  share_pct TINYINT UNSIGNED NOT NULL DEFAULT 10,
  paused TINYINT(1) NOT NULL DEFAULT 0,
  paused_by INT UNSIGNED NULL,
  paused_at DATETIME NULL,
  paused_why VARCHAR(255) NULL,
  updated_at DATETIME NULL,
  PRIMARY KEY (wf)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_capture_tasks (
  task VARCHAR(24) NOT NULL,
  wf VARCHAR(8) NOT NULL,
  name VARCHAR(120) NOT NULL,
  what VARCHAR(255) NOT NULL DEFAULT '',
  from_where VARCHAR(255) NOT NULL DEFAULT '',
  mode VARCHAR(8) NOT NULL DEFAULT 'run',
  every_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 5,
  fresh_days SMALLINT UNSIGNED NULL,
  per_run SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  max_seconds SMALLINT UNSIGNED NOT NULL DEFAULT 60,
  max_fetches SMALLINT UNSIGNED NOT NULL DEFAULT 20,
  max_paid SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  sort SMALLINT NOT NULL DEFAULT 50,
  last_served_at DATETIME NULL,
  last_outcome VARCHAR(16) NULL,
  last_why VARCHAR(255) NULL,
  updated_at DATETIME NULL,
  PRIMARY KEY (task),
  KEY idx_crawl_tasks_wf (wf)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_runs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  run_key CHAR(16) NOT NULL,
  worker_v VARCHAR(12) NOT NULL DEFAULT '',
  started_at DATETIME NOT NULL,
  ended_at DATETIME NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'running',
  budget_s SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  seconds SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  fetches SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  searches SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  why VARCHAR(500) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_crawl_runs_key (run_key),
  KEY idx_crawl_runs_started (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_run_items (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  run_id INT UNSIGNED NOT NULL,
  wf VARCHAR(8) NOT NULL,
  task VARCHAR(24) NOT NULL,
  outcome VARCHAR(16) NOT NULL,
  allotted_s SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  seconds SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  fetches SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  searches SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  counts TEXT NULL,
  why VARCHAR(500) NULL,
  at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_crawl_items_run (run_id),
  KEY idx_crawl_items_task (task, at),
  KEY idx_crawl_items_wf (wf, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_requests (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  wf VARCHAR(8) NOT NULL,
  kind VARCHAR(24) NOT NULL,
  ref VARCHAR(190) NOT NULL DEFAULT '',
  payload TEXT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'queued',
  priority TINYINT UNSIGNED NOT NULL DEFAULT 5,
  est_seconds SMALLINT UNSIGNED NOT NULL DEFAULT 20,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  lease_until DATETIME NULL,
  run_id INT UNSIGNED NULL,
  result TEXT NULL,
  why VARCHAR(500) NULL,
  next_at DATETIME NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_crawl_req_take (status, wf, priority, next_at),
  KEY idx_crawl_req_ref (wf, kind, ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS crawl_costs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  at DATETIME NOT NULL,
  service VARCHAR(16) NOT NULL,
  wf VARCHAR(8) NOT NULL DEFAULT '',
  task VARCHAR(24) NOT NULL DEFAULT '',
  units INT UNSIGNED NOT NULL DEFAULT 0,
  usd_micros INT UNSIGNED NOT NULL DEFAULT 0,
  ok TINYINT(1) NOT NULL DEFAULT 1,
  run_id INT UNSIGNED NULL,
  note VARCHAR(255) NULL,
  PRIMARY KEY (id),
  KEY idx_crawl_costs_at (at, service),
  KEY idx_crawl_costs_wf (wf, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO crawl_workflows (wf, name, share_pct, updated_at) VALUES
  ('W1', 'Listings', 35, NOW()),
  ('W2', 'Keeping listings current', 20, NOW()),
  ('W3', 'The source register and the place store', 15, NOW()),
  ('W4', 'Place guides', 0, NOW()),
  ('W5', 'Guides on demand', 0, NOW()),
  ('W6', 'The heritage catalog and topics', 8, NOW()),
  ('W7', 'Suggested journeys', 0, NOW()),
  ('W8', 'Find it', 0, NOW()),
  ('W9', 'Landmarks and places on demand', 5, NOW()),
  ('W10', 'Live events', 0, NOW()),
  ('W11', 'How-to guides', 7, NOW()),
  ('W12', 'Search learning', 10, NOW()),
  ('W13', 'Stories', 0, NOW());

INSERT IGNORE INTO crawl_capture_tasks (task, wf, name, what, from_where, mode, every_minutes, per_run, max_seconds, max_fetches, max_paid, sort, updated_at) VALUES
  ('coverage',   'W1', 'Find places by kind and town', 'places of a kind in a town or a cluster (coverage, towns searched, situation gaps)', 'OpenStreetMap and Wikidata, then each place''s own website', 'run', 5, 5, 150, 40, 0, 10, NOW()),
  ('second_look','W1', 'The second look', 'a second source for finds with one', 'the NPI Registry, our place store, web search', 'run', 5, 10, 100, 20, 10, 20, NOW()),
  ('targets',    'W1', 'Search targets', 'a kind of business in a place (decisions/0066)', 'OpenStreetMap, web search', 'run', 5, 2, 90, 20, 0, 30, NOW()),
  ('npi_bulk',   'W1', 'The NPI Registry file', 'health-care organizations in our states', 'CMS''s monthly NPI file', 'bulk', 1440, 1, 1500, 0, 0, 90, NOW()),
  ('irs_bulk',   'W1', 'The IRS exempt-organization file', 'nonprofits in our states, to confirm listings', 'the IRS''s monthly files', 'bulk', 1440, 1, 600, 0, 0, 91, NOW()),
  ('refresh',    'W2', 'Re-read listings'' own websites', 'empty fields, closed, moved or dead websites', 'each listing''s own website', 'run', 5, 3, 40, 12, 0, 10, NOW()),
  ('identity',   'W2', 'Fill a missing phone or website', 'a way to reach listings that have none', 'its own website, the NPI Registry, web search', 'run', 5, 5, 60, 15, 5, 20, NOW()),
  ('geocode',    'W2', 'Map points', 'a point for listings with a street and none', 'the Census geocoder (free)', 'run', 15, 2, 120, 0, 0, 30, NOW()),
  ('places',     'W2', 'The Google check', 'whether Google lists a listing as closed', 'Google Places (paid, capped)', 'run', 5, 5, 40, 0, 5, 40, NOW()),
  ('source',     'W3', 'Read a source', 'the places a site we read regularly names', 'the sites on the register marked read', 'run', 5, 1, 60, 25, 3, 10, NOW()),
  ('commoncrawl','W3', 'Common Crawl', 'local public sites and pages of sites we read', 'Common Crawl''s index and archive', 'run', 30, 1, 60, 0, 0, 20, NOW()),
  ('heritage',   'W6', 'The Library of Congress', 'historic records and newspapers naming a place', 'loc.gov and Chronicling America', 'run', 10, 2, 40, 0, 0, 10, NOW()),
  ('rec_bulk',   'W9', 'Recreation.gov', 'campgrounds, recreation areas and trailheads in our states', 'Recreation.gov (RIDB)', 'bulk', 1440, 1, 1500, 0, 0, 90, NOW()),
  ('landmarks_bulk','W9', 'Natural landmarks', 'named natural features, nations'' boundaries', 'USGS names, the Census, Wikidata, Wikipedia, Commons', 'bulk', 1440, 1, 1500, 0, 0, 91, NOW()),
  ('howto',      'W11', 'How-to guides', 'official steps for a how-to guide', '.gov, .edu and state pages', 'run', 10, 2, 45, 10, 2, 10, NOW()),
  ('learn',      'W12', 'Search learning', 'pages for situations open data can''t fill', 'web search (.gov, .edu, sources we read)', 'run', 10, 3, 45, 10, 3, 10, NOW());
