<?php
// app/lib/WorkOrders.php — work orders to vendors (decisions/0101, addendum 2026-10-28). What we send a printer for an
// order: the items, how many, their specs and notes, where it ships, when it's due, and the files (print-ready files,
// the approved proof, artwork). It's emailed from orders@trvgo.us (ORDERS_* in .env) with a private link to a page that
// lists it all and downloads each file (/wo.php?w=…, 30 days from when it's sent; after that the page offers Request a
// new link, emailed to the vendor: decisions/0150). Each vendor also has one link to all their work orders (Vendors::link). No prices or client billing ever go to a vendor.
//
// An order handled outside QuickBooks and Traversence (invoiced by hand in QuickBooks, paid however) is processed with
// processOutside(): approved for the client with no invoice made here (the QuickBooks invoice number is kept as a
// reference only, so nothing is posted to it and nothing is made twice), released to production, then its work order
// goes out. Staff only.
declare(strict_types=1);

require_once __DIR__ . '/ClientOrders.php';

final class WorkOrders
{
    public const DAYS = 30;   // a link works this long from when it's sent (decisions/0150; 60 before 2026-11-09)

    /** How it gets there (Jason's list, 2026-10-28). */
    public const DELIVERY = ['will_call' => 'Will Call', 'internal' => 'Internal Transfer', 'blind_drop' => 'Blind Drop Ship', 'local' => 'Local Delivery', 'courier' => 'Next-day Courier',
                             'usps' => 'Ship USPS', 'ups' => 'Ship UPS', 'fedex' => 'Ship FedEx', 'freight' => 'Freight'];
    /** Where a work order stands. The vendor moves it from their page (accept → in production → shipped / ready → complete); we receive it. */
    public const STATUS = ['draft' => 'Not sent', 'sent' => 'Sent to vendor', 'accepted' => 'Accepted', 'declined' => 'Rejected by vendor', 'production' => 'In production',
                           'shipped' => 'Shipped', 'ready' => 'Ready for pickup', 'complete' => 'Complete', 'received' => 'Received', 'rejected' => 'Rejected on receipt', 'cancelled' => 'Cancelled'];
    /** What the vendor may move it to, from each status. */
    public const VENDOR_MOVES = ['sent' => ['accepted', 'declined'], 'accepted' => ['production', 'shipped', 'ready'], 'production' => ['shipped', 'ready'], 'shipped' => ['complete'], 'ready' => ['complete']];
    /** A vendor status → our item's status (forward only; see moveItems). */
    private const ITEM_FOR = ['production' => 'production', 'shipped' => 'shipped', 'ready' => 'ready', 'complete' => 'delivered'];
    /** The files a vendor takes: production setups (we impose; they skip preflight and prepress) or 1-up print files (they do prepress). */
    public const FILE_PREF = ['' => 'Ask each time', 'setup' => 'Production setups (we impose; they skip prepress)', 'print' => 'Print files, 1-up (they do prepress)'];

    public static function statusReady(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT status, cost_cents, parts FROM order_work_orders LIMIT 0'); $pdo->query('SELECT 1 FROM order_work_order_log LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    /**
     * The next number: the day it's made, the vendor's code, then a running number across all work orders and vendors
     * (Jason: YYYYMMDD-WO####, then the vendor's code where WO was: 20261027-CP0001; WO_START_NO in .env continues an old count).
     */
    public static function nextNo(PDO $pdo, string $code = 'WO'): string
    {
        $max = 0;
        foreach ($pdo->query("SELECT wo_no FROM order_work_orders WHERE wo_no REGEXP '^[0-9]{8}-[A-Z]{1,4}[0-9]+$'")->fetchAll(PDO::FETCH_COLUMN) as $n) if (preg_match('/^\d{8}-[A-Z]{1,4}(\d+)$/', (string) $n, $m)) $max = max($max, (int) $m[1]);
        $start = (int) (getenv('WO_START_NO') ?: 0);
        $code = preg_match('/^[A-Z]{1,4}$/', $code) ? $code : 'WO';
        return date('Ymd') . '-' . $code . str_pad((string) max($max + 1, $start, 1), 4, '0', STR_PAD_LEFT);
    }

    /** The same number for another vendor (a draft whose vendor changed): its code swapped, its date and count kept. */
    public static function recode(string $no, string $code): string
    {
        return preg_match('/^(\d{8}-)[A-Z]{1,4}(\d+)$/', $no, $m) && preg_match('/^[A-Z]{1,4}$/', $code) ? $m[1] . $code . $m[2] : $no;
    }

    public static function get(PDO $pdo, int $id, int $oid = 0): ?array
    {
        $st = $pdo->prepare('SELECT * FROM order_work_orders WHERE id = ?' . ($oid ? ' AND order_id = ' . $oid : '')); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public static function log(PDO $pdo, int $woId): array
    {
        if (!self::statusReady($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM order_work_order_log WHERE wo_id = ? ORDER BY id'); $st->execute([$woId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** When it's needed: the date and time (5 pm when no time is given), or null. */
    public static function dueAt(array $w): ?int
    {
        if (empty($w['due_on'])) return null;
        return strtotime($w['due_on'] . ' ' . (!empty($w['due_time']) ? $w['due_time'] : '17:00:00')) ?: null;
    }

    /** Our code and the vendor's part number for an item: [our code, vendor part #]. */
    public static function partFor(PDO $pdo, array $l, int $vendorId): array
    {
        $code = ''; $pn = '';
        if (($l['product'] ?? '') === 'product' && !empty($l['product_id'])) {
            require_once __DIR__ . '/Products.php';
            $p = Products::get($pdo, (int) $l['product_id']); $code = (string) ($p['sku'] ?? '');
            if ($vendorId && self::statusReady($pdo)) { $st = $pdo->prepare('SELECT vendor_pn FROM product_vendor_parts WHERE product_id = ? AND vendor_id = ?'); $st->execute([(int) $l['product_id'], $vendorId]); $pn = (string) ($st->fetchColumn() ?: ''); }
        }
        return [$code, $pn];
    }

    public static function ready(PDO $pdo): bool
    {
        static $r = null;
        if ($r === null) { try { $pdo->query('SELECT 1 FROM order_work_orders LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } }
        return $r;
    }

    public static function forOrder(PDO $pdo, int $oid): array
    {
        if (!self::ready($pdo)) return [];
        $st = $pdo->prepare('SELECT * FROM order_work_orders WHERE order_id = ? ORDER BY id'); $st->execute([$oid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function byToken(PDO $pdo, string $t): ?array
    {
        if (!preg_match('/^[a-f0-9]{40}$/', $t) || !self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM order_work_orders WHERE token = ? AND expires_at > NOW()'); $st->execute([$t]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** A work order whose link has expired (or works): for its Request a new link. Null for a link that was replaced or never ours. */
    public static function byTokenAny(PDO $pdo, string $t): ?array
    {
        if (!preg_match('/^[a-f0-9]{40}$/', $t) || !self::ready($pdo)) return null;
        $st = $pdo->prepare('SELECT * FROM order_work_orders WHERE token = ?'); $st->execute([$t]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Closed work orders get no new link: the vendor writes to us instead. */
    public const NO_NEW_LINK = ['draft', 'cancelled', 'declined', 'rejected'];

    /** A new link for the work order (30 days; the old one stops working). $email: send it to the vendor's address on the work order first, and switch only once it has gone. */
    public static function renewLink(PDO $pdo, array $w, bool $email): array
    {
        if (in_array((string) ($w['status'] ?? 'sent'), self::NO_NEW_LINK, true)) throw new RuntimeException('This work order is closed.');
        $t = bin2hex(random_bytes(20));
        if ($email) {
            if (!filter_var((string) $w['vendor_email'], FILTER_VALIDATE_EMAIL)) throw new RuntimeException('There\'s no email on this work order.');
            $body = 'Hello ' . $w['vendor'] . ",\n\nHere is a new link to work order " . $w['wo_no'] . (($w['project'] ?? '') !== '' ? ' (' . $w['project'] . ')' : '') . ' from Traversence:'
                . "\n\n" . self::url(['token' => $t]) . "\n\nIt works until " . date('F j, Y', time() + self::DAYS * 86400) . '. The old link no longer opens it.' . "\n\nThank you,\nTraversence orders";
            require_once __DIR__ . '/Mailer.php';
            try { Mailer::send((string) $w['vendor_email'], 'New link: work order ' . $w['wo_no'], $body, (string) $w['vendor'], 'ORDERS'); }
            catch (Throwable $e) { error_log('work order new link mail: ' . $e->getMessage()); throw new RuntimeException('The email didn\'t go. Try again, or write to us.'); }
        }
        $pdo->prepare('UPDATE order_work_orders SET token = ?, expires_at = DATE_ADD(NOW(), INTERVAL ' . self::DAYS . ' DAY) WHERE id = ?')->execute([$t, (int) $w['id']]);
        $w = self::get($pdo, (int) $w['id']);
        if ($email) self::note($pdo, $w, (string) ($w['status'] ?? 'sent'), 'A new link emailed to the vendor (they asked from the expired page)', true, null);
        return $w;
    }

    /** The work order's link for its vendor's own page: a working one, renewed (without email) when it has expired. */
    public static function urlForVendor(PDO $pdo, array $w): string
    {
        if (strtotime((string) $w['expires_at']) <= time() && !in_array((string) ($w['status'] ?? 'sent'), self::NO_NEW_LINK, true)) $w = self::renewLink($pdo, $w, false);
        return self::url($w);
    }

    public static function url(array $w): string
    {
        return rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/wo.php?w=' . $w['token'];
    }

    /** The vendors to choose from: the list (Back-Office → Vendors), else those we've sent work to, with their email. */
    public static function vendors(PDO $pdo): array
    {
        require_once __DIR__ . '/Vendors.php';
        if (Vendors::ready($pdo)) { $out = []; foreach (Vendors::all($pdo, true) as $v) $out[(int) $v['id']] = $v; return $out; }
        $out = [];
        if (self::ready($pdo)) foreach ($pdo->query('SELECT vendor, vendor_email FROM order_work_orders WHERE vendor_email <> \'\' ORDER BY id DESC LIMIT 200')->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['vendor']] ??= $r['vendor_email'];
        require_once __DIR__ . '/VendorOrders.php';
        foreach (VendorOrders::vendors($pdo) as $v) $out[$v] ??= '';
        return $out;
    }

    /** The items a vendor makes (not shipping, not GO Codes, not cancelled). */
    public static function printLines(array $lines): array
    {
        return array_values(array_filter($lines, fn ($l) => !in_array($l['product'], ['shipping', 'go_code'], true) && !in_array($l['status'], ['cancelled', 'refunded'], true)));
    }

    /**
     * Each item's files that can go with it, ticked when they're what a printer wants: its print-ready files, else its
     * current proof (approved or not, the newest version); artwork and references too. Order-wide files at the end (line 0).
     * [line id => [[key, name, what it is, ticked], …]]
     */
    public static function choices(PDO $pdo, int $oid, array $lines): array
    {
        $files = ClientOrders::files($pdo, $oid);
        $out = [];
        foreach (self::printLines($lines) as $l) {
            $lid = (int) $l['id']; $c = [];
            $own = array_column($files[$lid] ?? [], 'kind');
            $ready = !empty($l['finals']) || array_intersect($own, ['setup', 'print']);   // print-ready files there: the proof stays home
            foreach ($l['finals'] ?? [] as $p) if (empty($p['retired_at'])) $c[] = ['p' . (int) $p['id'], (string) $p['file_name'], 'Print-ready', true, 'final'];
            foreach ($l['proof_files'] ?? [] as $p) if ($p['mime'] !== 'go-code' && empty($p['retired_at'])) $c[] = ['p' . (int) $p['id'], (string) $p['file_name'], 'Proof v' . (int) $p['version'] . ($p['status'] === 'approved' ? ', approved' : ''), !$ready, 'proof'];
            foreach ($files[$lid] ?? [] as $f) if (empty($f['retired_at']) && !in_array($f['kind'], ['label', 'manifest', 'invoice', 'estimate'], true)) $c[] = ['f' . (int) $f['id'], (string) $f['file_name'], ClientOrders::FILE_KINDS[$f['kind']] ?? 'File', in_array($f['kind'], ['setup', 'print'], true) || ($f['kind'] === 'artwork' && !$ready), (string) $f['kind']];
            $out[$lid] = $c;
        }
        $docs = [];
        foreach ($files[0] ?? [] as $f) if (empty($f['retired_at']) && !in_array($f['kind'], ['label', 'manifest', 'invoice', 'estimate'], true)) $docs[] = ['f' . (int) $f['id'], (string) $f['file_name'], ClientOrders::FILE_KINDS[$f['kind']] ?? 'File', in_array($f['kind'], ['setup', 'print'], true), (string) $f['kind']];
        if ($docs) $out[0] = $docs;
        $ship = [];   // shipping labels and manifests, on the order or an item: they go with the work order (key -1)
        foreach ($files as $lid => $fs) foreach ($fs as $f) if (empty($f['retired_at']) && in_array($f['kind'], ['label', 'manifest'], true)) $ship[] = ['f' . (int) $f['id'], (string) $f['file_name'], ClientOrders::FILE_KINDS[$f['kind']] ?? 'File', true, (string) $f['kind']];
        if ($ship) $out[-1] = $ship;
        return $out;
    }

    /** Where it ships, as written on a label, for the work order's Ship to (the order's address; empty when none). */
    public static function shipText(array $o): string
    {
        if (trim((string) ($o['ship_street'] ?? '')) === '') return '';
        return implode("\n", array_filter([trim((string) ($o['ship_name'] ?: $o['bill_name'])), trim((string) $o['client_company']), trim((string) $o['ship_street']),
            trim($o['ship_city'] . ', ' . $o['ship_state'] . ' ' . $o['ship_zip'], ', ')]));
    }

    /** An item as the vendor reads it: name, how many, its specs and note (never a price). */
    public static function itemText(array $l, array $part = ['', '']): string
    {
        $n = $l['product'] === 'product' ? ClientOrders::runQty($l) : (int) $l['qty'];
        return preg_replace('/ · [\d,]+$/', '', (string) $l['title']) . ' · ' . number_format($n)
            . ($part[0] !== '' || $part[1] !== '' ? "\n  " . trim(($part[0] !== '' ? 'Product ' . $part[0] : '') . ($part[1] !== '' ? ($part[0] !== '' ? ' · ' : '') . 'your part # ' . $part[1] : '')) : '')
            . (self::specs($l, $part) !== '' ? "\n  " . str_replace("\n", "\n  ", self::specs($l, $part)) : '')
            . (($l['ship_address'] ?? '') !== '' ? "\n  Ships to: " . str_replace("\n", ', ', (string) $l['ship_address']) : '');
    }

    /** A work order's code, part number and specs for each item, as it was sent: [line id => [our code, vendor part #, specs]]. */
    public static function parts(array $w): array
    {
        $p = json_decode((string) ($w['parts'] ?? ''), true);
        return is_array($p) ? array_map(fn ($x) => [(string) ($x[0] ?? ''), (string) ($x[1] ?? ''), (string) ($x[2] ?? '')], $p) : [];
    }

    /** The specs last written for an item on this order's work orders (newest first), as a part: ['', '', specs], or []. */
    public static function lastSpecs(PDO $pdo, int $oid, int $lineId): array
    {
        $st = $pdo->prepare('SELECT parts FROM order_work_orders WHERE order_id = ? ORDER BY id DESC'); $st->execute([$oid]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $pj) { $p = self::parts(['parts' => $pj]); if (trim($p[$lineId][2] ?? '') !== '') return $p[$lineId]; }
        // a reorder (Jason, 2026-10-30: "use previous specs"): those last written for the same piece on an earlier order
        try {
            $c = $pdo->prepare('SELECT collateral_id FROM order_lines WHERE id = ?'); $c->execute([$lineId]); $cid = (int) ($c->fetchColumn() ?: 0);
            if (!$cid) return [];
            $prev = $pdo->prepare('SELECT id, order_id FROM order_lines WHERE collateral_id = ? AND id <> ? AND order_id <> ? ORDER BY id DESC LIMIT 10'); $prev->execute([$cid, $lineId, $oid]);
            foreach ($prev->fetchAll(PDO::FETCH_ASSOC) as $pl) {
                $st->execute([(int) $pl['order_id']]);
                foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $pj) { $p = self::parts(['parts' => $pj]); if (trim($p[(int) $pl['id']][2] ?? '') !== '') return $p[(int) $pl['id']]; }
            }
        } catch (Throwable) {}
        return [];
    }

    /** The specs the vendor reads for an item: those written on the work order, else the item's options. */
    public static function specs(array $l, array $part = []): string
    {
        if (trim((string) ($part[2] ?? '')) !== '') return (string) $part[2];   // written for the vendor: all they read about it
        return trim((string) $l['options'] . ((string) $l['note'] !== '' ? "\nNote: " . $l['note'] : ''));   // else its options and its description, to start from
    }

    /**
     * What an item's costing says that its specs don't (Jason, 2026-10-29: the order said a 14mm coil, the costing a
     * 10mm one): each listed paper and binding it was costed with, and the sizes and weights in their names ("10mm",
     * "100#", "11x17") missing from the specs. [costed with (names), missing (tokens)]
     */
    public static function specGaps(PDO $pdo, array $l, string $specs): array
    {
        require_once __DIR__ . '/Costing.php';
        if (!Costing::ready($pdo)) return [[], []];
        [$r, $row] = Costing::forLine($pdo, $l); if (!$row) return [[], []];
        $items = Costing::items($pdo); $names = [];
        $check = [];   // a paper's weight (its sheet size is ours to impose); a binding's size
        foreach ($r['parts'] as $p) if (isset($items[$p['stock']])) { $c = $items[$p['stock']]; $names[] = $c['name'] . ($c['size'] !== '' ? ' ' . $c['size'] : ''); $check[] = [$c['name'], '/\d+(?:\.\d+)?\s*(?:#|lb\b|pt\b)/i']; }
        foreach ($r['items'] as $i) if (isset($items[$i['item']]) && $items[$i['item']]['kind'] === 'binding') { $names[] = $items[$i['item']]['name']; $check[] = [$items[$i['item']]['name'], '/\d+(?:\.\d+)?\s*mm\b|\d+\/\d+\s*"?|\d+:\d+/i']; }
        $miss = []; $sp = strtolower(str_replace(' ', '', $specs));
        foreach ($check as [$nm, $re]) foreach (preg_match_all($re, $nm, $m) ? $m[0] : [] as $tok)
            if (!str_contains($sp, strtolower(str_replace(' ', '', $tok)))) $miss[] = trim($tok);
        return [array_values(array_unique($names)), array_values(array_unique($miss))];
    }

    /** A work order's items, from the order as it is now. */
    public static function items(PDO $pdo, array $w): array
    {
        $ids = array_map('intval', array_filter(explode(',', (string) $w['line_ids'])));
        return array_values(array_filter(ClientOrders::lines($pdo, (int) $w['order_id']), fn ($l) => in_array((int) $l['id'], $ids, true)));
    }

    /** A work order's files: [[key, name, what it is], …], only ones still on the order (a retired file is never offered: choices()). */
    public static function files(PDO $pdo, array $w): array
    {
        $want = json_decode((string) $w['files'], true) ?: [];
        $all = [];
        foreach (self::choices($pdo, (int) $w['order_id'], ClientOrders::lines($pdo, (int) $w['order_id'])) as $c) foreach ($c as $f) $all[$f[0]] = $f;
        $finals = $pdo->prepare("SELECT id, file_name FROM order_proofs WHERE order_id = ? AND kind = 'final'" . (ClientOrders::canRetireProofs($pdo) ? ' AND retired_at IS NULL' : '')); $finals->execute([(int) $w['order_id']]);   // print-ready files ride along even once replaced in the list
        foreach ($finals->fetchAll(PDO::FETCH_ASSOC) as $f) $all['p' . $f['id']] ??= ['p' . $f['id'], $f['file_name'], 'Print-ready', true];
        return array_values(array_filter(array_map(fn ($k) => $all[$k] ?? null, $want)));
    }

    /** The file behind a key on this work order: [path, name, mime], or null. */
    public static function file(PDO $pdo, array $w, string $key): ?array
    {
        if (!in_array($key, json_decode((string) $w['files'], true) ?: [], true) || !preg_match('/^([pf])(\d+)$/', $key, $m)) return null;
        $st = $pdo->prepare('SELECT * FROM ' . ($m[1] === 'p' ? 'order_proofs' : 'order_files') . ' WHERE id = ? AND order_id = ?'); $st->execute([(int) $m[2], (int) $w['order_id']]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        return [$m[1] === 'p' ? ClientOrders::proofPath($r) : ClientOrders::filePath($r), (string) ($r['file_name'] ?: 'file'), (string) $r['mime']];
    }

    /**
     * An order handled outside QuickBooks and Traversence: approved for the client with no invoice made here, released to
     * production. $invoiceNo, the QuickBooks invoice made by hand, is kept for reference only (nothing is posted to it).
     */
    public static function processOutside(PDO $pdo, array $o, string $name, string $invoiceNo, int $staff): array
    {
        $oid = (int) $o['id'];
        if (!in_array($o['status'], ['draft', 'sent'], true)) throw new RuntimeException('This order is already approved: send its work order below.');
        if (!self::printLines(ClientOrders::lines($pdo, $oid))) throw new RuntimeException('Nothing on this order goes to a vendor (no printed items).');
        $was = (string) $o['pay_mode'];
        $pdo->prepare("UPDATE orders SET pay_mode = 'outside' WHERE id = ?")->execute([$oid]);
        $ship = ['_ship_on_wo' => 1]; foreach (['name', 'street', 'city', 'state', 'zip'] as $k) $ship['ship_' . $k] = (string) ($o['ship_' . $k] ?? '');
        try { $o = ClientOrders::approve($pdo, Orders::get($pdo, $oid), $name !== '' ? $name : (string) $o['bill_name'], $ship, $staff); }
        catch (Throwable $x) { $pdo->prepare('UPDATE orders SET pay_mode = ? WHERE id = ?')->execute([$was, $oid]); throw $x; }   // as it was
        self::setInvoiceNo($pdo, $o, $invoiceNo, $staff);
        ClientOrders::releaseHold($pdo, $oid, $staff, '', true);   // the outside path, not the admin's override (model 1.6, 1.9): its payment is taken outside
        Orders::event($pdo, $oid, 'outside', 'Handled outside Traversence: no invoice made here' . (trim($invoiceNo) !== '' ? ' (QuickBooks invoice ' . trim($invoiceNo) . ', made by hand)' : ''), $staff);
        return Orders::get($pdo, $oid);
    }

    /**
     * The QuickBooks invoice made by hand for an order handled outside: its number. The order page then finds it in
     * QuickBooks by that number and links it (ClientOrders::readQuickBooks, M1b): its payments are read, and a payment
     * recorded here is received on it; it's never merged. A new number drops the old link.
     */
    public static function setInvoiceNo(PDO $pdo, array $o, string $no, int $staff): void
    {
        $no = mb_substr(trim($no), 0, 40);
        if (!empty($o['invoice_id'])) throw new RuntimeException('This order has its own QuickBooks invoice (' . $o['invoice_no'] . ').');
        if ($no === (string) ($o['invoice_no'] ?? '')) return;
        $pdo->prepare('UPDATE orders SET invoice_no = ? WHERE id = ?')->execute([$no !== '' ? $no : null, (int) $o['id']]);
        if (Orders::hasCol($pdo, 'qb_link_id')) $pdo->prepare('UPDATE orders SET qb_link_id = NULL, qb_link_customer = NULL, qb_read_at = NULL WHERE id = ?')->execute([(int) $o['id']]);
        Orders::event($pdo, (int) $o['id'], 'invoice_ref', $no !== '' ? 'QuickBooks invoice (made by hand): ' . $no : 'QuickBooks invoice number taken off', $staff);
    }

    /**
     * A new work order: $in vendor, email, lines[], files[], ship_to, due_on, note, ordered (mark the order "Ordered from
     * the printer"). Sent by email when $send (and it has an email); returns the row.
     */
    public static function create(PDO $pdo, array $o, array $in, int $staff, bool $send = true): array
    {
        if (!self::ready($pdo)) throw new RuntimeException('Run the work orders update (2027-01-01_work_orders.sql) first.');
        $oid = (int) $o['id'];
        if (!in_array($o['status'], ['pending', 'paid', 'part_refunded'], true)) throw new RuntimeException('Approve the order first (or process it as handled outside).');
        if ($send && ($why = ClientOrders::vendorHold($pdo, $o)) !== '') throw new RuntimeException($why . ' (Nothing was saved.)');   // model 1.9: paid in full before the vendor
        // the vendor: one from the list (Back-Office → Vendors), or a new one typed here, which joins the list
        require_once __DIR__ . '/Vendors.php';
        $vid = ctype_digit((string) ($in['vendor_id'] ?? '')) ? (int) $in['vendor_id'] : 0;
        $email = mb_substr(trim((string) ($in['email'] ?? '')), 0, 160);
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('That vendor email doesn\'t look right.');
        $v = $vid ? Vendors::get($pdo, $vid) : null;
        if (!$v) {
            $name = mb_substr(trim((string) ($in['vendor'] ?? '')), 0, 80);
            if ($name === '') throw new RuntimeException('Who makes it? Choose the vendor, or add a new one.');
            $v = Vendors::byName($pdo, $name);
            if (!$v && Vendors::ready($pdo)) $v = Vendors::get($pdo, Vendors::save($pdo, ['name' => $name, 'email' => $email]));
            if (!$v) $v = ['id' => null, 'name' => $name, 'email' => ''];
        }
        if ($email === '') $email = (string) $v['email'];
        elseif ($v['id'] && (string) $v['email'] === '') $pdo->prepare('UPDATE vendors SET email = ? WHERE id = ?')->execute([$email, (int) $v['id']]);   // its orders email, kept on the list
        $vendor = (string) $v['name'];
        if ($send && $email === '') throw new RuntimeException('Add the vendor\'s email to send it (or save it without sending).');
        if ($send && self::statusReady($pdo) && trim((string) ($in['cost'] ?? '')) === '') throw new RuntimeException('Add the total cost: the vendor accepts or declines at that cost (it\'s the project\'s cost of goods).');
        $lines = self::printLines(ClientOrders::lines($pdo, $oid));
        $valid = array_map(fn ($l) => (int) $l['id'], $lines);
        $ids = array_values(array_intersect($valid, array_map('intval', (array) ($in['lines'] ?? []))));
        if (!$ids) throw new RuntimeException('Tick at least one item for the vendor.');
        $ok = [];
        foreach (self::choices($pdo, $oid, $lines) as $lid => $c) if ($lid <= 0 || in_array($lid, $ids, true)) foreach ($c as $f) $ok[] = $f[0];
        $files = array_values(array_intersect($ok, array_map('strval', (array) ($in['files'] ?? []))));
        $due = trim((string) ($in['due_on'] ?? ''));
        if ($due !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) throw new RuntimeException('Pick the must-have date from the calendar.');
        $tok = bin2hex(random_bytes(20));
        $edit = (int) ($in['wo'] ?? 0) ? self::get($pdo, (int) $in['wo']) : null;   // a draft saved earlier, saved again
        if ((int) ($in['wo'] ?? 0) && (!$edit || (int) $edit['order_id'] !== $oid)) throw new RuntimeException('That work order isn\'t here.');
        if ($edit && ($edit['status'] ?? 'draft') !== 'draft') throw new RuntimeException('Work order ' . $edit['wo_no'] . ' has gone to the vendor: change it with them, or cancel it and make it again.');
        if ($edit && !self::statusReady($pdo)) throw new RuntimeException('Run app/migrations/2027-01-02_work_order_status.sql to edit saved work orders.');
        if (self::statusReady($pdo)) {
            $time = trim((string) ($in['due_time'] ?? ''));
            if ($time !== '' && !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $time)) throw new RuntimeException('Pick the must-have time from the clock.');
            $deliv = (string) ($in['delivery'] ?? '');
            if ($deliv !== '' && !isset(self::DELIVERY[$deliv])) throw new RuntimeException('Choose the delivery method from the list.');
            $cost = trim((string) ($in['cost'] ?? '')) === '' ? null : ClientOrders::cents((string) $in['cost']);
            if ($cost === null) {   // none typed: the vendor's share of the items' checked COGS (one system: decisions/0130)
                require_once __DIR__ . '/Costing.php'; $vc = 0;
                foreach (Costing::forOrder($pdo, (int) $o['id']) as $lid => $cr) if (in_array((int) $lid, $ids, true)) $vc += (int) $cr['vendor_cents'];
                if ($vc > 0) $cost = $vc;
            }
            // each item's code and the vendor's part number; a part number typed here is kept for that product and vendor
            $parts = [];
            foreach ($lines as $l) {
                if (!in_array((int) $l['id'], $ids, true)) continue;
                [$code, $pn] = self::partFor($pdo, $l, (int) ($v['id'] ?? 0));
                $typed = mb_substr(trim((string) (($in['pn'] ?? [])[(int) $l['id']] ?? $pn)), 0, 80);
                if ($typed !== '' && $typed !== $pn && ($l['product'] ?? '') === 'product' && !empty($l['product_id']) && !empty($v['id']))
                    $pdo->prepare('INSERT INTO product_vendor_parts (product_id, vendor_id, vendor_pn) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE vendor_pn = VALUES(vendor_pn)')->execute([(int) $l['product_id'], (int) $v['id'], $typed]);
                $spec = trim(str_replace("\r", '', (string) (($in['spec'] ?? [])[(int) $l['id']] ?? '')));   // the specs written for the vendor (blank: the item's options)
                $parts[(int) $l['id']] = [$code, $typed, $spec === self::specs($l) ? '' : mb_substr($spec, 0, 1000)];
            }
            $project = mb_substr(trim((string) ($in['project'] ?? '')), 0, 160);
            if ($edit) {
                $pdo->prepare('UPDATE order_work_orders SET vendor = ?, vendor_email = ?, line_ids = ?, files = ?, ship_to = ?, due_on = ?, due_time = ?, note = ?, vendor_id = ?, delivery = ?, po_no = ?, project = ?, cost_cents = ?, cost_state = ?, parts = ? WHERE id = ?')
                    ->execute([$vendor, $email, implode(',', $ids), json_encode($files), mb_substr(trim((string) ($in['ship_to'] ?? '')), 0, 400), $due !== '' ? $due : null, $time !== '' ? $time : null,
                               mb_substr(trim((string) ($in['note'] ?? '')), 0, 1000), (int) ($v['id'] ?? 0) ?: null, $deliv, mb_substr(trim((string) ($in['po_no'] ?? '')), 0, 60), $project,
                               $cost, $cost !== null ? 'ours' : '', json_encode($parts), (int) $edit['id']]);
                $no = (string) $edit['wo_no'];
                $re = self::recode($no, Vendors::codeFor($v));   // its vendor changed: the code follows, the number stays
                if ($re !== $no) { $pdo->prepare('UPDATE order_work_orders SET wo_no = ? WHERE id = ?')->execute([$re, (int) $edit['id']]); $no = $re; }
            } else {
            for ($try = 0; ; $try++) {   // the number is unique; two made at once: the second takes the next
                $no = self::nextNo($pdo, Vendors::codeFor($v));
                if (!$pdo->query('SELECT 1 FROM order_work_orders WHERE wo_no = ' . $pdo->quote($no))->fetchColumn() || $try > 5) break;
            }
            $pdo->prepare('INSERT INTO order_work_orders (order_id, wo_no, vendor, vendor_email, line_ids, files, ship_to, due_on, due_time, note, token, expires_at, created_by, vendor_id, status, status_at, delivery, po_no, project, cost_cents, cost_state, parts)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?, DATE_ADD(NOW(), INTERVAL ' . self::DAYS . ' DAY), ?,?, \'draft\', NOW(), ?,?,?,?, ?, ?)')
                ->execute([$oid, $no, $vendor, $email, implode(',', $ids), json_encode($files), mb_substr(trim((string) ($in['ship_to'] ?? '')), 0, 400), $due !== '' ? $due : null, $time !== '' ? $time : null,
                           mb_substr(trim((string) ($in['note'] ?? '')), 0, 1000), $tok, $staff, (int) ($v['id'] ?? 0) ?: null, $deliv, mb_substr(trim((string) ($in['po_no'] ?? '')), 0, 60), $project,
                           $cost, $cost !== null ? 'ours' : '', json_encode($parts)]);
            }
        } else {
            $no = Orders::no($o) . '-W' . ((int) $pdo->query('SELECT COUNT(*) FROM order_work_orders WHERE order_id = ' . $oid)->fetchColumn() + 1);   // before 2027-01-02_work_order_status.sql
            $pdo->prepare('INSERT INTO order_work_orders (order_id, wo_no, vendor, vendor_email, line_ids, files, ship_to, due_on, note, token, expires_at, created_by' . (Vendors::ready($pdo) ? ', vendor_id' : '') . ') VALUES (?,?,?,?,?,?,?,?,?,?, DATE_ADD(NOW(), INTERVAL ' . self::DAYS . ' DAY), ?' . (Vendors::ready($pdo) ? ', ' . (int) ($v['id'] ?? 0) : '') . ')')
                ->execute([$oid, $no, $vendor, $email, implode(',', $ids), json_encode($files), mb_substr(trim((string) ($in['ship_to'] ?? '')), 0, 400), $due !== '' ? $due : null,
                           mb_substr(trim((string) ($in['note'] ?? '')), 0, 1000), $tok, $staff]);
        }
        $w = $pdo->query('SELECT * FROM order_work_orders WHERE id = ' . ($edit ? (int) $edit['id'] : (int) $pdo->lastInsertId()))->fetch(PDO::FETCH_ASSOC);
        self::note($pdo, $w, 'draft', ($edit ? 'Saved' : 'Made') . ($w['cost_cents'] ?? null ? ' at ' . Orders::usd((int) $w['cost_cents']) : ''), false, $staff);
        if (!$edit) Orders::event($pdo, $oid, 'work_order', 'Work order ' . $no . ' for ' . $vendor . ': ' . count($ids) . ' item' . (count($ids) === 1 ? '' : 's') . ', ' . count($files) . ' file' . (count($files) === 1 ? '' : 's'), $staff);
        if ($send) {
            $w = self::send($pdo, $w, $staff);
            if (!empty($in['ordered'])) self::markOrdered($pdo, $o, $staff, (string) $w['vendor']);   // saved to send later: the order is marked when it goes
        }
        return $w;
    }

    /** The order is "Work order issued" (once its work order goes; the client hears only if they asked for progress emails). */
    public static function markOrdered(PDO $pdo, array $o, int $staff, string $vendor = ''): void
    {
        if (!in_array((string) ($o['stage'] ?? ''), ['', 'production'], true)) return;
        if ($o['stage'] === '') $pdo->prepare("UPDATE orders SET stage = 'production' WHERE id = ?")->execute([(int) $o['id']]);
        ClientOrders::setStage($pdo, (int) $o['id'], 'ordered', (string) ($o['tracking'] ?? ''), $staff, $vendor !== '' ? 'to vendor (' . $vendor . ')' : '');   // "Work order issued to vendor (Competition Printing)"; the client hears only "sent to print"
    }

    /** Our team's tracking for a courier we book (Jason, 2026-10-28): kept on the work order, shown on its page, and emailed to the vendor once it's sent. */
    public static function setTracking(PDO $pdo, array $w, string $carrier, string $tracking, int $staff): array
    {
        $carrier = mb_substr(trim($carrier), 0, 40); $tracking = mb_substr(trim($tracking), 0, 80);
        if ($tracking === '') throw new RuntimeException('Add the tracking number.');
        $pdo->prepare('UPDATE order_work_orders SET carrier = ?, tracking = ? WHERE id = ?')->execute([$carrier, $tracking, (int) $w['id']]);
        self::note($pdo, $w, (string) ($w['status'] ?? 'sent'), 'Courier booked: ' . trim($carrier . ' ' . $tracking), false, $staff);
        $w = self::get($pdo, (int) $w['id']); $w['_told'] = false;   // said only when the email went (M2b: words follow the state)
        if ($w['sent_at'] && filter_var((string) $w['vendor_email'], FILTER_VALIDATE_EMAIL)) {
            require_once __DIR__ . '/Mailer.php';
            $w = self::tellVendor($pdo, $w, 'Work order ' . $w['wo_no'] . ': courier booked', 'Hello ' . $w['vendor'] . ",\n\nThe courier for work order " . $w['wo_no'] . ' is booked.' . "\nTracking: " . trim($carrier . ' ' . $tracking) . "\n\nThe work order: " . self::url($w) . "\n\nTraversence orders", $staff);
        }
        return $w;
    }

    /**
     * Where a work order takes the goods (decisions/0101's note, 2026-11-24, M2b): 'client' straight to them, else 'us'.
     * Blind Drop Ship always goes to the client; Will Call and Internal Transfer come to us; a Ship, Freight, Local
     * Delivery or Next-day Courier work order goes to its ship-to, and with none it comes to us.
     */
    public static function goesTo(array $w): string
    {
        $d = (string) ($w['delivery'] ?? '');
        if ($d === 'blind_drop') return 'client';
        if ($d === '' || in_array($d, ['will_call', 'internal'], true)) return 'us';
        return trim((string) ($w['ship_to'] ?? '')) !== '' ? 'client' : 'us';
    }

    /**
     * A system email to the work order's vendor (M2b): '_told' true when it went; when it didn't, '_unsent' holds what we'd
     * have sent (to, subject, body) for the page's Send again, Copy the message and its mail link (never a dead end), and
     * the work order's History says so. Also Send again's own sender, with $again.
     */
    public static function tellVendor(PDO $pdo, array $w, string $subject, string $body, int $staff, bool $again = false): array
    {
        $w['_told'] = false; unset($w['_unsent']);
        require_once __DIR__ . '/Mailer.php';
        try { Mailer::send((string) $w['vendor_email'], $subject, $body, (string) $w['vendor'], 'ORDERS'); $w['_told'] = true; if ($again) self::note($pdo, $w, (string) $w['status'], 'Emailed again: ' . $subject, false, $staff); }
        catch (Throwable $x) {
            error_log('work order vendor mail: ' . $x->getMessage());
            $w['_unsent'] = ['to' => (string) $w['vendor_email'], 'subject' => $subject, 'body' => $body, 'wo' => (int) $w['id'], 'vendor' => (string) $w['vendor']];
            self::note($pdo, $w, (string) $w['status'], 'The email to ' . $w['vendor'] . ' didn\'t go: ' . $subject, false, $staff);
        }
        return $w;
    }

    /** What a work order's delivery means, in a line (M2b's Change how it goes…). */
    public const DELIVERY_MEANS = ['will_call' => 'We collect it from the vendor, or a courier we book does.', 'internal' => 'It comes to us from our own shop.',
        'blind_drop' => 'The vendor ships it straight to the client, under our name.', 'local' => 'The vendor delivers it locally: to the ship-to, or to us with none.',
        'courier' => 'A next-day courier from the vendor: to the ship-to, or to us with none.', 'usps' => 'The vendor ships it by USPS: to the ship-to, or to us with none.',
        'ups' => 'The vendor ships it by UPS: to the ship-to, or to us with none.', 'fedex' => 'The vendor ships it by FedEx: to the ship-to, or to us with none.',
        'freight' => 'By freight from the vendor: to the ship-to, or to us with none.'];

    /** The short words for how a work order goes, under the Delivery line ("Will Call: we collect it."). */
    public static function legWords(array $w): string
    {
        $d = (string) ($w['delivery'] ?? ''); $how = self::DELIVERY[$d] ?? '';
        if ($how === '') return '';
        if ($d === 'will_call') return 'Will Call: we collect it.';
        if ($d === 'internal') return 'Internal Transfer: it comes to us.';
        return $how . (self::goesTo($w) === 'client' ? ': straight to the client.' : ': to us.');
    }

    /**
     * Change how a work order goes (M2b, the Delivery line's Change how it goes…): ✎ on its delivery, never Undo; the old
     * value in its History and the order's. $tell emails the vendor "Work order X: delivery changed to …" (only once it was
     * sent). Returns the work order, with '_told' true when the vendor was emailed.
     */
    public static function setDelivery(PDO $pdo, array $w, string $to, bool $tell, int $staff): array
    {
        if (!isset(self::DELIVERY[$to])) throw new RuntimeException('Pick how it goes.');
        if (in_array((string) $w['status'], ['received', 'rejected', 'cancelled', 'declined'], true)) throw new RuntimeException('Work order ' . $w['wo_no'] . ' is ' . strtolower(self::STATUS[$w['status']] ?? $w['status']) . ': how it went is done.');
        $was = (string) ($w['delivery'] ?? '');
        if ($was === $to) { $w['_told'] = false; return $w; }
        $wasW = self::DELIVERY[$was] ?? 'not set';
        $pdo->prepare('UPDATE order_work_orders SET delivery = ? WHERE id = ?')->execute([$to, (int) $w['id']]);
        $what = 'Delivery changed from ' . $wasW . ' to ' . self::DELIVERY[$to];
        self::note($pdo, $w, (string) $w['status'], $what, false, $staff);
        Orders::event($pdo, (int) $w['order_id'], 'work_order_delivery', 'Work order ' . $w['wo_no'] . ': ' . lcfirst($what), $staff);
        $w = self::get($pdo, (int) $w['id']); $w['_told'] = false;
        if ($tell && $w['sent_at'] && filter_var((string) $w['vendor_email'], FILTER_VALIDATE_EMAIL)) {
            $w = self::tellVendor($pdo, $w, 'Work order ' . $w['wo_no'] . ': delivery changed to ' . self::DELIVERY[$to], 'Hello ' . $w['vendor'] . ",\n\nThe delivery for work order " . $w['wo_no'] . ' is now ' . self::DELIVERY[$to] . ' (it was ' . $wasW . ').' . (trim((string) $w['ship_to']) !== '' && self::goesTo($w) === 'client' ? "\n\nShip to:\n" . $w['ship_to'] : '') . "\n\nThe work order: " . self::url($w) . "\n\nTraversence orders", $staff);
        }
        return $w;
    }

    /**
     * The vendor's link, for our team to send themselves (Jason, 2026-10-28: "a send link, in case I just want to email the
     * rep"). A work order not sent yet is marked sent by it (its cost first, as for sending), so the rep can accept it.
     * Returns [the work order, its link, a mailto: with the vendor's email, subject and a short note].
     */
    public static function handLink(PDO $pdo, array $w, int $staff): array
    {
        if (in_array($w['status'] ?? 'sent', ['cancelled', 'declined', 'rejected', 'received'], true)) throw new RuntimeException('Work order ' . $w['wo_no'] . ' is ' . strtolower(self::STATUS[$w['status']] ?? $w['status']) . ': make it again to send it.');
        if (self::statusReady($pdo) && ($w['status'] ?? '') === 'draft') {
            if ($w['cost_cents'] === null) throw new RuntimeException('Add the total cost first (Edit it): the vendor accepts or rejects it at that cost.');
            if (($o = Orders::get($pdo, (int) $w['order_id'])) && ($why = ClientOrders::vendorHold($pdo, $o)) !== '') throw new RuntimeException($why);   // its link is the work order going out
            $pdo->prepare("UPDATE order_work_orders SET status = 'sent', status_at = NOW(), sent_at = COALESCE(sent_at, NOW()), expires_at = GREATEST(expires_at, DATE_ADD(NOW(), INTERVAL " . self::DAYS . " DAY)) WHERE id = ?")->execute([(int) $w['id']]);   // 30 days from when it goes
            self::note($pdo, $w, 'sent', 'Its link given to the vendor by our team', false, $staff);
            if ($o = Orders::get($pdo, (int) $w['order_id'])) self::markOrdered($pdo, $o, $staff, (string) $w['vendor']);
            $w = self::get($pdo, (int) $w['id']);
        }
        [$url, $mailto] = self::linkFor($w);
        return [$w, $url, $mailto];
    }

    /** A work order's link and a mailto: to the vendor with its number, project, must-have date and the link. */
    public static function linkFor(array $w): array
    {
        $url = self::url($w);
        $due = self::dueAt($w);
        $body = 'Hello' . ($w['vendor'] !== '' ? ' ' . $w['vendor'] : '') . ",\n\nWork order " . $w['wo_no'] . (($w['project'] ?? '') !== '' ? ' (' . $w['project'] . ')' : '') . ' from Traversence is ready for you'
            . ($due ? ', must have by ' . date('l, F j', $due) . (!empty($w['due_time']) ? ' at ' . date('g:i a', $due) : '') : '') . ".\n\nOpen it here to download the files and accept it:\n" . $url . "\n\nThank you,\nTraversence";
        $mailto = 'mailto:' . str_replace('%40', '@', rawurlencode((string) $w['vendor_email'])) . '?subject=' . rawurlencode('Work order ' . $w['wo_no']) . '&body=' . rawurlencode($body);
        return [$url, $mailto];
    }

    /** Emails the work order to the vendor from orders@ (again, when it's already gone). */
    public static function send(PDO $pdo, array $w, int $staff): array
    {
        if (!filter_var((string) $w['vendor_email'], FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Add the vendor\'s email first.');
        if (self::statusReady($pdo) && $w['cost_cents'] === null) throw new RuntimeException('Add the total cost first: the vendor accepts or declines at that cost.');
        $o = Orders::get($pdo, (int) $w['order_id']);
        if ($o && ($why = ClientOrders::vendorHold($pdo, $o)) !== '') throw new RuntimeException($why);   // model 1.9: paid in full before the vendor
        $items = self::items($pdo, $w); $files = self::files($pdo, $w); $parts = self::parts($w);
        $due = self::dueAt($w);
        $pdo->prepare('UPDATE order_work_orders SET expires_at = GREATEST(expires_at, DATE_ADD(NOW(), INTERVAL ' . self::DAYS . ' DAY)) WHERE id = ?')->execute([(int) $w['id']]);   // 30 days from when it goes
        $w = self::get($pdo, (int) $w['id']) ?? $w;
        $all = '';   // the vendor's own page of all their work orders (decisions/0150)
        if (!empty($w['vendor_id'])) { require_once __DIR__ . '/Vendors.php'; if ($vd = Vendors::get($pdo, (int) $w['vendor_id'])) { try { $all = Vendors::link($pdo, $vd); } catch (Throwable $x) { error_log('vendor link: ' . $x->getMessage()); } } }
        $body = 'Hello ' . $w['vendor'] . ",\n\nPlease produce work order " . $w['wo_no'] . ' for Traversence.'
            . (($w['project'] ?? '') !== '' ? "\nProject: " . $w['project'] : '')
            . ($due ? "\nMust have by: " . date('l, F j, Y', $due) . (!empty($w['due_time']) ? ' at ' . date('g:i a', $due) : '') : '')
            . (($w['delivery'] ?? '') !== '' ? "\nDelivery: " . (self::DELIVERY[$w['delivery']] ?? $w['delivery']) : '')
            . (($w['po_no'] ?? '') !== '' ? "\nP.O. number: " . $w['po_no'] : '')
            . (isset($w['cost_cents']) && $w['cost_cents'] !== null ? "\nTotal cost: " . Orders::usd((int) $w['cost_cents']) : '')
            . "\n\nItems:\n" . implode("\n", array_map(fn ($l) => '- ' . self::itemText($l, $parts[(int) $l['id']] ?? ['', '']), $items))
            . ($w['ship_to'] !== '' ? "\n\nShip to:\n" . $w['ship_to'] : '')
            . ($w['note'] !== '' ? "\n\nProduction notes:\n" . $w['note'] : '')
            . "\n\nOpen the work order to download its " . count($files) . ' file' . (count($files) === 1 ? '' : 's') . ', accept it (your job number, ship date' . (self::statusReady($pdo) ? ' and the cost' : '') . ') and update it as it moves along'
            . ' (the link works until ' . date('F j, Y', strtotime((string) $w['expires_at'])) . "):\n" . self::url($w)
            . ($all !== '' ? "\n\nAll your work orders from us, on one page:\n" . $all : '')
            . "\n\nBill Traversence; never contact our client directly.\n\nThank you,\nTraversence orders";
        require_once __DIR__ . '/Mailer.php';
        try { Mailer::send((string) $w['vendor_email'], 'Work order ' . $w['wo_no'] . ' from Traversence', $body, (string) $w['vendor'], 'ORDERS'); }
        catch (Throwable $e) { error_log('work order mail: ' . $e->getMessage()); throw new RuntimeException('The work order is saved, but the email didn\'t go (' . mb_substr($e->getMessage(), 0, 120) . '). Try Send again.'); }
        $pdo->prepare('UPDATE order_work_orders SET sent_at = NOW() WHERE id = ?')->execute([(int) $w['id']]);
        if (self::statusReady($pdo) && $w['status'] === 'draft') { $pdo->prepare("UPDATE order_work_orders SET status = 'sent', status_at = NOW() WHERE id = ?")->execute([(int) $w['id']]); self::note($pdo, $w, 'sent', 'Emailed to ' . $w['vendor_email'], false, $staff); }
        Orders::event($pdo, (int) $w['order_id'], 'work_order_sent', 'Work order ' . $w['wo_no'] . ' emailed to ' . $w['vendor'] . ' (' . $w['vendor_email'] . ') from ' . (getenv('ORDERS_FROM_EMAIL') ?: 'our orders address'), $staff);
        return $pdo->query('SELECT * FROM order_work_orders WHERE id = ' . (int) $w['id'])->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * The files on a work order already with the vendor (Jason, 2026-10-30: new files for the vendor after it went out):
     * $keys from the order's files for its items (choices()). The vendor's page shows the new list at once; with $tell the
     * vendor is emailed what changed, with the same link. Returns ['added' => names, 'removed' => names].
     */
    public static function setFiles(PDO $pdo, array $w, array $keys, int $staff, bool $tell = true): array
    {
        $ws = (string) ($w['status'] ?? ($w['sent_at'] ? 'sent' : 'draft'));
        if (in_array($ws, ['cancelled', 'declined', 'rejected', 'received'], true)) throw new RuntimeException('Work order ' . $w['wo_no'] . ' is ' . (self::STATUS[$ws] ?? $ws) . ': make it again to send new files.');
        $ids = array_map('intval', array_filter(explode(',', (string) $w['line_ids'])));
        $ok = []; $name = [];
        foreach (self::choices($pdo, (int) $w['order_id'], ClientOrders::lines($pdo, (int) $w['order_id'])) as $lid => $c) if ($lid <= 0 || in_array($lid, $ids, true)) foreach ($c as $f) { $ok[] = $f[0]; $name[$f[0]] = $f[1]; }
        foreach (self::files($pdo, $w) as $f) $name[$f[0]] ??= $f[1];
        $was = json_decode((string) $w['files'], true) ?: [];
        $now = array_values(array_unique(array_intersect(array_map('strval', $keys), $ok)));
        $added = array_values(array_diff($now, $was)); $removed = array_values(array_diff($was, $now));
        $off = count(array_diff(array_unique(array_map('strval', $keys)), $ok));
        if (!$added && !$removed) throw new RuntimeException($off ? 'Those files aren\'t for this work order\'s items: add the item to a new work order, or upload the file to this item.' : 'Those are the files it has already.');
        if (!$now) throw new RuntimeException('Keep at least one file on it (or cancel the work order).');
        $pdo->prepare('UPDATE order_work_orders SET files = ? WHERE id = ?')->execute([json_encode($now), (int) $w['id']]);
        $nm = fn (array $k) => array_map(fn ($x) => (string) ($name[$x] ?? $x), $k);
        $line = 'Files changed: ' . implode('; ', array_filter([$added ? 'added ' . implode(', ', $nm($added)) : '', $removed ? 'taken off ' . implode(', ', $nm($removed)) : '']));
        self::note($pdo, $w, $ws, $line, false, $staff);
        Orders::event($pdo, (int) $w['order_id'], 'work_order', 'Work order ' . $w['wo_no'] . ': ' . lcfirst($line), $staff);
        if ($tell && $ws !== 'draft' && filter_var((string) $w['vendor_email'], FILTER_VALIDATE_EMAIL)) {
            $body = 'Hello ' . $w['vendor'] . ",\n\nThe files for work order " . $w['wo_no'] . ' have changed.'
                . ($added ? "\n\nNew:\n" . implode("\n", array_map(fn ($n) => '- ' . $n, $nm($added))) : '')
                . ($removed ? "\n\nNo longer used (please don't print these):\n" . implode("\n", array_map(fn ($n) => '- ' . $n, $nm($removed))) : '')
                . "\n\nDownload them from the work order:\n" . self::url($w) . "\n\nThank you,\nTraversence orders";
            require_once __DIR__ . '/Mailer.php';
            try { Mailer::send((string) $w['vendor_email'], 'New files for work order ' . $w['wo_no'], $body, (string) $w['vendor'], 'ORDERS'); }
            catch (Throwable $e) { error_log('work order files mail: ' . $e->getMessage()); throw new RuntimeException('The files are changed on the work order, but the email to the vendor didn\'t go (' . mb_substr($e->getMessage(), 0, 120) . '). Use Email the link to tell them.'); }
        }
        return ['added' => $nm($added), 'removed' => $nm($removed)];
    }

    /** The vendor opened the page (not our team). */
    public static function opened(PDO $pdo, array $w): void
    {
        $pdo->prepare('UPDATE order_work_orders SET opened_at = COALESCE(opened_at, NOW()), opens = opens + 1 WHERE id = ?')->execute([(int) $w['id']]);
    }

    // ---- where it stands: the vendor's moves from their page, ours, receiving, reminders --------------------------------

    private static function note(PDO $pdo, array $w, string $status, string $note, bool $vendor, ?int $staff): void
    {
        if (!self::statusReady($pdo)) return;
        $pdo->prepare('INSERT INTO order_work_order_log (wo_id, status, note, by_vendor, staff_id) VALUES (?, ?, ?, ?, ?)')->execute([(int) $w['id'], $status, mb_substr($note, 0, 500), $vendor ? 1 : 0, $staff ?: null]);
    }

    private static function set(PDO $pdo, array $w, array $fields): array
    {
        $fields['status_at'] = date('Y-m-d H:i:s');
        $pdo->prepare('UPDATE order_work_orders SET ' . implode(', ', array_map(fn ($k) => $k . ' = ?', array_keys($fields))) . ' WHERE id = ?')->execute(array_merge(array_values($fields), [(int) $w['id']]));
        return self::get($pdo, (int) $w['id']);
    }

    /** Tells our orders inbox (orders@) what a vendor did. */
    private static function tellUs(PDO $pdo, array $w, string $what): void
    {
        $to = getenv('ORDERS_REPLY_TO') ?: (getenv('SMTP_REPLY_TO') ?: 'support@traversence.com');   // orders@ only sends: our team reads support@
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return;
        require_once __DIR__ . '/Mailer.php';
        try { Mailer::send($to, 'Work order ' . $w['wo_no'] . ': ' . $what, $w['vendor'] . ': ' . $what . "\n\nThe order: " . rtrim((string) (getenv('SITE_BASE') ?: 'https://traversence.com'), '/') . '/admin/backoffice/orders/' . (int) $w['order_id'] . '#work', 'Traversence orders', 'ORDERS'); }
        catch (Throwable $e) { error_log('work order note: ' . $e->getMessage()); }
    }

    /**
     * The vendor, from their page: accept (who received it, their job #), reject (production comments), in
     * production, shipped (carrier, tracking), ready for pickup, complete. Returns what to say to them.
     */
    public static function hasAcceptedBy(PDO $pdo): bool { static $r = null; if ($r === null) { try { $pdo->query('SELECT accepted_by FROM order_work_orders LIMIT 0'); $r = true; } catch (Throwable) { $r = false; } } return $r; }

    public static function vendorMove(PDO $pdo, array $w, string $to, array $in): string
    {
        if (!self::statusReady($pdo)) throw new RuntimeException('This work order can\'t be updated here yet. Reply to the email instead.');
        if (!in_array($to, self::VENDOR_MOVES[$w['status']] ?? [], true)) throw new RuntimeException('This work order is ' . strtolower(self::STATUS[$w['status']] ?? $w['status']) . ' now, so that step isn\'t open. Reload the page.');
        $f = ['status' => $to]; $say = ''; $note = '';
        if ($to === 'accepted') {   // at our cost, or not at all (Jason, 2026-10-28: accept or decline, no counter-offers)
            $f['job_no'] = mb_substr(trim((string) ($in['job_no'] ?? '')), 0, 60);
            // who received it; accepting accepts the must-have date (Jason, 2026-10-28: no ship date asked)
            $by = mb_substr(trim((string) ($in['accepted_by'] ?? '')), 0, 120);
            if ($by === '') throw new RuntimeException('Add the agent\'s name under Received by.');
            if (self::hasAcceptedBy($pdo)) $f['accepted_by'] = $by;
            if (!empty($w['due_on'])) $f['promised_on'] = (string) $w['due_on'];
            if ($w['cost_cents'] !== null) $f['cost_state'] = 'accepted';   // the cost of goods for the project, set now
            $note = 'Accepted by ' . $by . ($f['job_no'] !== '' ? '. Job ' . $f['job_no'] : '');
            $say = 'Accepted. Thank you: update it here as it moves along.';
        } elseif ($to === 'declined') {
            $why = mb_substr(trim((string) ($in['why'] ?? '')), 0, 500);
            if ($why === '') throw new RuntimeException('Add your production comments, so we can sort it out or send it elsewhere.');
            $f['vendor_note'] = $why; $note = 'Rejected: ' . $why; $say = 'Rejected. We\'ve been told; thank you for your comments.';
        } elseif ($to === 'shipped') {
            $f['carrier'] = mb_substr(trim((string) ($in['carrier'] ?? '')), 0, 30); $f['tracking'] = mb_substr(trim((string) ($in['tracking'] ?? '')), 0, 160);
            if ($f['tracking'] === '' && !in_array($w['delivery'], ['will_call', 'internal', 'local', 'courier'], true)) throw new RuntimeException('Add the tracking number.');
            $note = 'Shipped' . ($f['carrier'] !== '' ? ' by ' . $f['carrier'] : '') . ($f['tracking'] !== '' ? ', tracking ' . $f['tracking'] : ''); $say = 'Marked shipped. Thank you.';
        } else {
            $note = self::STATUS[$to]; $say = 'Marked ' . strtolower(self::STATUS[$to]) . '. Thank you.';
        }
        $w = self::set($pdo, $w, $f);
        self::note($pdo, $w, $to, $note, true, null);
        Orders::event($pdo, (int) $w['order_id'], 'work_order_' . $to, 'Work order ' . $w['wo_no'] . ' (' . $w['vendor'] . '): ' . $note);
        $held = self::moveItems($pdo, $w);
        self::tellUs($pdo, $w, $note . ($held !== '' ? '. ' . $held : ''));
        return $say;
    }

    /** How far along each status is, for moving forward only. */
    private const RANK = ['draft' => 0, 'sent' => 1, 'accepted' => 2, 'production' => 3, 'shipped' => 4, 'ready' => 4, 'complete' => 5];

    /** Where our team may move a work order for the vendor: every status ahead of where it is (skipping is fine). */
    public static function staffMoves(array $w): array
    {
        $at = self::RANK[$w['status']] ?? null;
        if ($at === null || $at < 1) return [];   // not sent, or out of the flow (declined, received, rejected, cancelled)
        return array_values(array_filter(['accepted', 'production', 'shipped', 'ready', 'complete'], fn ($k) => self::RANK[$k] > $at));
    }

    /**
     * Our team moves a work order on for the vendor (Jason, 2026-11-01: the vendor is working on it but never clicked
     * Accept or updated their page): forward only, skipping steps is fine (sent → shipped). It's logged as ours, with who;
     * our items and the order follow as they would for the vendor. Tracking is asked for shipped, but optional here.
     */
    public static function staffMove(PDO $pdo, array $w, string $to, array $in, int $staff, string $who = ''): string
    {
        if (!self::statusReady($pdo)) throw new RuntimeException('Work order statuses aren\'t set up here yet.');
        if (!in_array($to, self::staffMoves($w), true)) throw new RuntimeException('Work order ' . $w['wo_no'] . ' is ' . strtolower(self::STATUS[$w['status']] ?? $w['status']) . ': it can only move forward from there.');
        $f = ['status' => $to]; $by = $who !== '' ? $who : 'our team';
        if (self::RANK[$w['status']] < self::RANK['accepted']) {   // it was never accepted: accepting happens with it
            if (self::hasAcceptedBy($pdo)) $f['accepted_by'] = mb_substr('For the vendor, by ' . $by, 0, 120);
            if (!empty($w['due_on'])) $f['promised_on'] = (string) $w['due_on'];
            if ($w['cost_cents'] !== null) $f['cost_state'] = 'accepted';
        }
        $note = self::STATUS[$to];
        if ($to === 'shipped') {
            $f['carrier'] = mb_substr(trim((string) ($in['carrier'] ?? '')), 0, 30); $f['tracking'] = mb_substr(trim((string) ($in['tracking'] ?? '')), 0, 160);
            $note = 'Shipped' . ($f['carrier'] !== '' ? ' by ' . $f['carrier'] : '') . ($f['tracking'] !== '' ? ', tracking ' . $f['tracking'] : '');
        }
        $note .= ' (marked for the vendor by ' . $by . ')';
        $w = self::set($pdo, $w, $f);
        self::note($pdo, $w, $to, $note, false, $staff ?: null);
        Orders::event($pdo, (int) $w['order_id'], 'work_order_' . $to, 'Work order ' . $w['wo_no'] . ' (' . $w['vendor'] . '): ' . $note, $staff ?: null);
        $held = self::moveItems($pdo, $w);
        return 'Work order ' . $w['wo_no'] . ': ' . strtolower(self::STATUS[$to]) . '.' . ($held !== '' ? ' ' . $held : '');
    }

    /**
     * Our items follow the vendor (forward only, never out of a hold or past what we set by hand); the order ships when all
     * of it has. Out the door waits for payment in full (model 1.9: "Balance must be paid before order is release for
     * delivery, delays may result in orders being held for payment before shipping"): the work order keeps the vendor's
     * status and tracking, our items and the order stay where they are, the client isn't told, and the order's Pulse case
     * asks our team to collect the balance (wobal); the payment (or an admin's release) moves it on (catchUp). Returns
     * what's held, in words ('' when nothing is).
     */
    private static function moveItems(PDO $pdo, array $w): string
    {
        $to = self::ITEM_FOR[$w['status']] ?? null;
        if (!$to) return '';
        if ($to === 'delivered' && self::goesTo($w) === 'us') return '';   // it came to us: we take it from here (decisions/0101's note, 2026-11-24: by where the work order goes, not its method alone)
        $o = Orders::get($pdo, (int) $w['order_id']);
        if (in_array($to, ClientOrders::OUT_DOOR, true) && $o && ($why = ClientOrders::shipHold($pdo, $o)) !== '') {
            Orders::event($pdo, (int) $o['id'], 'balance_hold', 'Work order ' . $w['wo_no'] . ' is ' . strtolower(self::STATUS[$w['status']] ?? $w['status']) . ': the order waits for its balance before it\'s released for delivery');
            return 'The order waits for its balance (' . Orders::usd(max(0, (int) $o['total_cents'] - Orders::money($pdo, (int) $o['id'])['paid'])) . ') before it\'s released for delivery; the client isn\'t told it shipped until then.';
        }
        $rank = []; $i = 0; foreach (ClientOrders::ITEM_STATUS['Approved'] + ClientOrders::ITEM_STATUS['Out the door'] as $k => $_) $rank[$k] = ++$i;
        foreach (self::items($pdo, $w) as $l) {
            $now = ClientOrders::itemStatus($o, $l);
            if (!isset($rank[$now]) || $rank[$now] >= ($rank[$to] ?? 0)) continue;
            ClientOrders::setItemStatus($pdo, (int) $w['order_id'], (int) $l['id'], $to, $w['status'] === 'shipped' ? trim(($w['carrier'] ? $w['carrier'] . ' ' : '') . $w['tracking']) : (string) ($l['tracking'] ?? ''), 0);
        }
        // every printed item on the order out the door (by its work orders): the order moves too (the client hears if they asked)
        if (in_array($w['status'], ['shipped', 'ready'], true) && in_array((string) $o['stage'], ['', 'production', 'ordered'], true)) {
            $all = true;
            foreach (self::printLines(ClientOrders::lines($pdo, (int) $o['id'])) as $l) if (ClientOrders::role($pdo, $l) === 'print' && !in_array(ClientOrders::itemStatus($o, $l), ['shipped', 'ready', 'in_route', 'delivered', 'complete'], true)) $all = false;
            if ($all) { if ($o['stage'] === '') $pdo->prepare("UPDATE orders SET stage = 'production' WHERE id = ?")->execute([(int) $o['id']]); ClientOrders::setStage($pdo, (int) $o['id'], $w['status'] === 'ready' ? 'ready' : 'shipped', trim(($w['carrier'] ? $w['carrier'] . ' ' : '') . $w['tracking']), 0); }   // paid in full by here (the hold above)
        }
        return '';
    }

    /**
     * The order is paid in full, or an admin released it: work orders the vendor moved on while it waited for its balance
     * (moveItems) move our items and the order on now, as they would have then. Safe to call twice.
     */
    public static function catchUp(PDO $pdo, int $oid): void
    {
        if (!self::statusReady($pdo)) return;
        foreach (self::forOrder($pdo, $oid) as $w) if (in_array((string) $w['status'], ['production', 'shipped', 'ready', 'complete'], true)) self::moveItems($pdo, $w);
    }

    /** Ours: received (who, when), or rejected on receipt (why). A rejected work order can be printed again (reprint). */
    public static function receive(PDO $pdo, array $w, bool $ok, string $by, string $on, string $note, int $staff): array
    {
        if (!in_array($w['status'], ['shipped', 'ready', 'complete', 'accepted', 'production'], true)) throw new RuntimeException('It can be received once the vendor has it under way.');
        $by = mb_substr(trim($by), 0, 120); $note = mb_substr(trim($note), 0, 500);
        if ($by === '') throw new RuntimeException('Who received it?');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $on)) throw new RuntimeException('Pick the date it came in.');
        if (!$ok && $note === '') throw new RuntimeException('Say what\'s wrong with it.');
        $w = self::set($pdo, $w, ['status' => $ok ? 'received' : 'rejected', 'received_by' => $by, 'received_on' => $on, 'receive_note' => $note]);
        $msg = ($ok ? 'Received' : 'Rejected on receipt') . ' by ' . $by . ' on ' . date('M j', strtotime($on)) . ($note !== '' ? ': ' . $note : '');
        self::note($pdo, $w, $w['status'], $msg, false, $staff);
        Orders::event($pdo, (int) $w['order_id'], 'work_order_' . $w['status'], 'Work order ' . $w['wo_no'] . ': ' . $msg, $staff);
        if (!$ok && filter_var((string) $w['vendor_email'], FILTER_VALIDATE_EMAIL)) {
            require_once __DIR__ . '/Mailer.php';
            try { Mailer::send((string) $w['vendor_email'], 'Work order ' . $w['wo_no'] . ': rejected on receipt', 'Hello ' . $w['vendor'] . ",\n\nWork order " . $w['wo_no'] . ' arrived and we can\'t accept it: ' . $note . "\n\nWe'll be in touch about a reprint.\n\nTraversence orders", (string) $w['vendor'], 'ORDERS'); }
            catch (Throwable $e) { error_log('work order reject mail: ' . $e->getMessage()); }
        }
        return $w;
    }

    /** A new work order like this one (a reprint after a rejection, or after a decline): same items, files and details, not sent yet. */
    public static function reprint(PDO $pdo, array $w, int $staff): array
    {
        if (!in_array($w['status'], ['rejected', 'declined', 'cancelled'], true)) throw new RuntimeException('Only a rejected, declined or cancelled work order is made again.');
        require_once __DIR__ . '/Vendors.php';
        $no = self::nextNo($pdo, Vendors::codeFor(Vendors::get($pdo, (int) ($w['vendor_id'] ?? 0)) ?? ['name' => (string) $w['vendor']]));
        $pdo->prepare('INSERT INTO order_work_orders (order_id, wo_no, vendor, vendor_email, vendor_id, line_ids, files, ship_to, due_on, due_time, note, token, expires_at, created_by, status, status_at, delivery, po_no, project, cost_cents, cost_state, parts, reprint_of)
                       SELECT order_id, ?, vendor, vendor_email, vendor_id, line_ids, files, ship_to, due_on, due_time, note, ?, DATE_ADD(NOW(), INTERVAL ' . self::DAYS . ' DAY), ?, \'draft\', NOW(), delivery, po_no, project, cost_cents, IF(cost_cents IS NULL, \'\', \'ours\'), parts, id FROM order_work_orders WHERE id = ?')
            ->execute([$no, bin2hex(random_bytes(20)), $staff, (int) $w['id']]);
        $n = self::get($pdo, (int) $pdo->lastInsertId());
        self::note($pdo, $n, 'draft', 'Made again from ' . $w['wo_no'] . ($w['status'] === 'rejected' ? ' (a reprint)' : ''), false, $staff);
        Orders::event($pdo, (int) $w['order_id'], 'work_order', 'Work order ' . $no . ' made from ' . $w['wo_no'] . ($w['status'] === 'rejected' ? ' (a reprint)' : ''), $staff);
        return $n;
    }

    /** Ours: stop a work order (it stays in the history). */
    /** A draft made by mistake, never sent: gone (its number isn't used again; the order's history keeps a line). */
    public static function deleteDraft(PDO $pdo, array $w, int $staff): void
    {
        if (($w['status'] ?? 'draft') !== 'draft' || !empty($w['sent_at'])) throw new RuntimeException('Only a work order that was never sent can be deleted. This one went to ' . $w['vendor'] . ': cancel it instead, and they\'re told.');
        $pdo->prepare('DELETE FROM order_work_order_log WHERE wo_id = ?')->execute([(int) $w['id']]);
        $pdo->prepare('DELETE FROM order_work_orders WHERE id = ?')->execute([(int) $w['id']]);
        Orders::event($pdo, (int) $w['order_id'], 'work_order_deleted', 'Draft work order ' . $w['wo_no'] . ' (' . $w['vendor'] . ') deleted, never sent', $staff);
    }

    public static function cancel(PDO $pdo, array $w, string $why, int $staff): void
    {
        if (in_array($w['status'], ['received', 'cancelled'], true)) throw new RuntimeException('It\'s already ' . strtolower(self::STATUS[$w['status']]) . '.');
        $w = self::set($pdo, $w, ['status' => 'cancelled']);
        self::note($pdo, $w, 'cancelled', 'Cancelled' . (trim($why) !== '' ? ': ' . trim($why) : ''), false, $staff);
        Orders::event($pdo, (int) $w['order_id'], 'work_order_cancelled', 'Work order ' . $w['wo_no'] . ' cancelled', $staff);
        if ($w['sent_at'] && filter_var((string) $w['vendor_email'], FILTER_VALIDATE_EMAIL)) {
            require_once __DIR__ . '/Mailer.php';
            try { Mailer::send((string) $w['vendor_email'], 'Work order ' . $w['wo_no'] . ': cancelled', 'Hello ' . $w['vendor'] . ",\n\nPlease stop work order " . $w['wo_no'] . '. ' . (trim($why) !== '' ? trim($why) . ' ' : '') . "Reply if anything is already done.\n\nTraversence orders", (string) $w['vendor'], 'ORDERS'); }
            catch (Throwable $e) { error_log('work order cancel mail: ' . $e->getMessage()); }
        }
    }

    /** 9:00 am on the next business day (Monday to Friday) after a time: when an unaccepted work order is chased. */
    public static function nextBusinessNine(int $t): int
    {
        $d = strtotime(date('Y-m-d 09:00:00', $t) . ' +1 day');
        while ((int) date('N', $d) >= 6) $d = strtotime('+1 day', $d);
        return $d;
    }

    /**
     * The hourly reminders (app/scripts/work_orders_tick.php), each sent once (Jason, 2026-10-28): not accepted by 9:00 am
     * the next business day after it went; 24 hours before the must-have time; and at the must-have time.
     */
    public static function tick(PDO $pdo, ?int $now = null): int
    {
        if (!self::statusReady($pdo)) return 0;
        $n = 0; $now = $now ?? time();
        foreach ($pdo->query("SELECT * FROM order_work_orders WHERE status IN ('sent','accepted','production') AND vendor_email <> '' AND expires_at > NOW()")->fetchAll(PDO::FETCH_ASSOC) as $w) {
            $done = array_filter(explode(',', (string) $w['reminders']));
            $due = self::dueAt($w); $want = [];
            if ($w['status'] === 'sent' && $w['sent_at'] && $now >= self::nextBusinessNine(strtotime((string) $w['sent_at']))) $want[] = ['accept', 'hasn\'t been accepted yet'];
            if ($due && $now >= $due) $want[] = ['due', 'is due now (' . date('M j, g:i a', $due) . ')'];
            elseif ($due && $due - $now <= 24 * 3600) $want[] = ['24h', 'is due within 24 hours (' . date('M j, g:i a', $due) . ')'];
            $want = array_values(array_filter($want, fn ($x) => !in_array($x[0], $done, true)));
            if (!$want) continue;
            require_once __DIR__ . '/Mailer.php';
            $why = implode(', and ', array_column($want, 1));
            try {
                Mailer::send((string) $w['vendor_email'], 'Reminder: work order ' . $w['wo_no'] . ($w['status'] === 'sent' ? ' is waiting on you' : ': an update, please'),
                    'Hello ' . $w['vendor'] . ",\n\nWork order " . $w['wo_no'] . ' ' . $why . '. Please ' . ($w['status'] === 'sent' ? 'accept it with the agent\'s name and your job number (or reject it)' : 'update where it stands: in production, shipped with tracking, or ready') . " on its page:\n" . self::url($w) . "\n\nThank you,\nTraversence orders", (string) $w['vendor'], 'ORDERS');
            } catch (Throwable $e) { error_log('work order reminder: ' . $e->getMessage()); continue; }
            foreach ($want as $x) $done[] = $x[0];
            $pdo->prepare('UPDATE order_work_orders SET reminders = ? WHERE id = ?')->execute([implode(',', $done), (int) $w['id']]);
            self::note($pdo, $w, $w['status'], 'Reminder sent: it ' . $why, false, null);
            $n++;
        }
        return $n;
    }
}
