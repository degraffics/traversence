<?php
// market/cart.php — the buyer's carts and checkout (decisions/0135, "Step 4 decided"). One cart per business, since each
// is paid through its own gateway; Buy now is a checkout of one item (?item=&qty=).
//   /market/cart.php           your carts, a business each
//   /market/cart.php?b=<id>    checkout for that business's cart
//   /market/cart.php?item=<id>&qty=<n>   Buy now
//   /market/cart.php?test=<id>  the business's test purchase (its team, sandbox only; E-commerce setup step 5)
// Checkout: how to get it (pickup, delivery, shipping), how to pay (card through the business's own Stripe or Square,
// whose own card fields open right here; or its direct ways, with its instructions), the total as its invoice adds it up.
// By kind (decisions/0141 §5, KindCheckout): a stay's or a rental's dates (?from=&to=&guests=&waiver=, Buy now), a Made-to-
// order item's questions, a harvest's pickup window, house rules to agree, a subscription's terms; "How you get it" only
// when something ships; a deposit paid now and the rest when it's ready.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/MarketCheckout.php';
require_once __DIR__ . '/../../app/lib/StorePolicies.php';
tv_card_page_csp('market-cart', ['stripe', 'square']);   // a card page: only our scripts and the business's gateway (0135; its script list there)

$uid = Auth::currentUserId();
if ($uid === null) { header('Location: /login.php?next=' . rawurlencode((string) ($_SERVER['REQUEST_URI'] ?? '/market/cart.php')), true, 302); exit; }
$pdo = Database::connection();
$ready = MarketCheckout::ready($pdo);
$carts = $ready ? MarketCheckout::carts($pdo, $uid) : [];
$e = (int) ($_GET['b'] ?? 0); $itemId = (int) ($_GET['item'] ?? 0); $qty = max(1, min(MarketCheckout::MAX_QTY, (int) ($_GET['qty'] ?? 1)));
$check = null; $why = '';
$testE = (int) ($_GET['test'] ?? 0);
if ($ready && $testE) {   // the setup's test purchase: a $1 stand-in, paid by card through the business's own gateway
    [$tok, $why] = MarketCheckout::testAllowed($pdo, $uid, $testE);
    if ($tok) { $e = $testE; $check = ['lines' => [['item_id' => 0, 'title' => 'Test purchase (test card, no real money)', 'qty' => 1, 'unit_cents' => 100, 'taxable' => 0]], 'buy' => false, 'test' => true]; }
} elseif ($ready && $itemId) {   // Buy now
    $it = MarketBiz::get($pdo, $itemId);
    if ($it) {
        $bk = ItemKinds::key((string) $it['kind']);
        [$ok, $why] = MarketCheckout::buyable($pdo, $it);
        $left = MarketCheckout::available($pdo, $it);
        if ($ok && $left !== null && $qty > $left) { $ok = false; $why = 'Only ' . $left . ' left.'; }
        if ($ok) { $e = (int) $it['entity_id']; $check = ['lines' => [['item_id' => $itemId, 'title' => $it['title'] . ((int) $it['price_qty'] > 1 ? ' (pack of ' . (int) $it['price_qty'] . ')' : ''), 'qty' => $qty, 'unit_cents' => (int) $it['price_cents'], 'taxable' => (int) $it['taxable']]], 'buy' => true]; }
    } else $why = 'That item isn\'t available.';
} elseif ($ready && $e && isset($carts[$e])) {
    $bad = array_filter($carts[$e]['lines'], fn ($l) => !$l['ok']);
    $check = ['lines' => array_values(array_filter($carts[$e]['lines'], fn ($l) => $l['ok'])), 'buy' => false, 'bad' => $bad];
    if (!$check['lines']) { $check = null; $why = 'Nothing in this cart can be bought right now.'; }
}
// by kind: what it asks, adds and charges now (the same KindCheckout::prepare placing the order runs, here not yet strict)
$bk = $bk ?? ''; $kErr = '';
$kx = ['from' => (string) ($_GET['from'] ?? ''), 'to' => (string) ($_GET['to'] ?? ''), 'guests' => max(1, (int) ($_GET['guests'] ?? 1)), 'waiver' => !empty($_GET['waiver'])];
$kp = ['lines' => $check['lines'] ?? [], 'extra' => [], 'mode' => 'payment', 'hold' => false, 'ships' => true, 'house_rules' => '', 'windows' => [], 'needs' => []];
if ($check && empty($check['test'])) {
    $gw = MarketCheckout::gateway($pdo, $e);
    try { $kp = KindCheckout::prepare($pdo, $check['lines'], $kx, false, $gw && $gw['status'] === 'connected' ? (string) $gw['provider'] : ''); }
    catch (InvalidArgumentException $x) { $kErr = $x->getMessage(); $kp['needs'][] = 'dates'; }
}
$kd = $check && $bk !== '' ? ItemKinds::data($bk, $it['kind_data'] ?? null) : [];
$s = $check ? MarketCheckout::settings($pdo, $e) : null;
$ways = $check ? (!empty($check['test']) ? ['card' => 'Card (a test card)'] : MarketCheckout::payWays($pdo, $e, (array) ($check['lines'] ?? []))) : [];   // a restricted item: no card (decisions/0142 §4)
if ($kp['mode'] === 'subscription') $ways = array_intersect_key($ways, ['card' => 1]);   // a subscription renews on the card
if (!empty($check['test'])) $s = ['ship' => [['id' => 'test', 'name' => 'Pick up (a test: nothing is sent)', 'price_cents' => 0, 'pickup' => true]], 'tax_milli' => 0] + $s;
if ($check && !empty($kp['pickup_only'])) $s['ship'] = array_values(array_filter($s['ship'], fn ($o) => !empty($o['pickup']))) ?: $s['ship'];
$biz = $check ? (string) (MarketBiz::entity($pdo, $e)['name'] ?? '') : '';
$all = array_merge($kp['lines'], $kp['extra']);
$first = $check ? $s['ship'][0] : null;
$t = $check ? MarketCheckout::totals($all, $kp['ships'] ? (int) $first['price_cents'] : 0, (int) $s['tax_milli']) : null;
$bal = (int) ($kp['balance'] ?? 0);
$canPlace = $ways && !in_array('dates', $kp['needs'], true);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');

tv_page_start($check ? 'Checkout · ' . $biz : 'Your carts', ['section' => 'market', 'active' => 'cart', 'no_crumbs' => true]);
?>
<style>
  .ct{max-width:46rem}.ct h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.6rem;margin:0 0 .4rem;color:var(--tv-ink,#3E2B1F)}
  .ct-card{background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.9rem;padding:.85rem .95rem;margin-bottom:.8rem}
  .ct-card h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.08rem;margin:0 0 .5rem;color:var(--tv-ink,#3E2B1F)}
  .ct-l{display:flex;gap:.6rem;align-items:center;padding:.45rem 0;border-top:1px solid var(--tv-line,#EADFC4);flex-wrap:wrap}.ct-l:first-of-type{border-top:0}
  .ct-l a.nm{color:var(--tv-link,#92400E);text-decoration:underline;font-weight:600;flex:1 1 12rem;min-width:0;overflow-wrap:anywhere}.ct-l small{color:var(--tv-meta,#8A7355)}
  .ct-l input[type=number]{width:4.5rem;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.5rem;padding:.3rem .4rem}
  .ct-b{font:inherit;font-size:.86rem;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;padding:.35rem .9rem;background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);cursor:pointer;font-weight:600;text-decoration:none;display:inline-block}
  .ct-b.go{background:var(--tv-umber,#3E2B1F);border-color:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2)}
  .ct-opt{display:flex;gap:.5rem;align-items:flex-start;padding:.35rem 0;font-size:.92rem}.ct-opt small{display:block;color:var(--tv-meta,#8A7355)}.ct-f .ct-opt input{width:auto;flex:none;margin-top:.25rem}
  .ct-f{display:grid;gap:.45rem}.ct-f input,.ct-f textarea{border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.5rem;padding:.45rem .55rem;font:inherit;font-size:.92rem;background:var(--tv-card-a,#fff);width:100%;box-sizing:border-box}
  .ct-sum{display:grid;grid-template-columns:1fr auto;gap:.2rem .8rem;font-size:.95rem}.ct-sum b{font-size:1.1rem}
  #ct-pay{margin-top:.6rem}
  .ct-agree{font-size:.84rem;color:var(--tv-meta,#5C4632);margin:.6rem 0 0}.ct-agree p{margin:0}
  .ct-k{display:grid;gap:.45rem}.ct-k label:not(.ct-opt){display:grid;gap:.15rem;font-size:.88rem;font-weight:600;color:var(--tv-ink,#3E2B1F)}.ct-k select{border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.5rem;padding:.4rem;font:inherit;background:var(--tv-card-a,#fff)}
  .ct-dates{display:flex;flex-wrap:wrap;gap:.5rem;align-items:flex-end}.ct-dates label{flex:1 1 9rem}.ct-dates input{border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.5rem;padding:.4rem;font:inherit;background:var(--tv-card-a,#fff);width:100%;box-sizing:border-box}
  .ct-rules{white-space:pre-line;font-size:.88rem;color:var(--tv-meta,#5C4632);background:var(--tv-card-a,#fff);border:1px solid var(--tv-line,#EADFC4);border-radius:.5rem;padding:.5rem .6rem;max-height:12rem;overflow:auto}
</style>
<div class="ct">
<?php if (!$ready): ?><p data-tv-status="info" data-tv-label="Coming:">Buying opens once its database update has run.</p>
<?php elseif ($check): ?>
  <h1><?= !empty($check['test']) ? 'Test purchase' : 'Checkout' ?></h1>
  <?php if (!empty($check['test'])): $tg = MarketCheckout::gateway($pdo, $e); $tp = (string) ($tg['provider'] ?? ''); ?><p data-tv-status="info" data-tv-label="Test mode:">No real money moves. Place the order and <?= tv_e(MarketPay::PROVIDERS[$tp] ?? 'the gateway') ?>&rsquo;s card form opens here. Its test cards: <?= tv_e(implode('; ', array_map(fn ($c) => $c[0] . ': ' . $c[1] . ' (' . $c[2] . ')', MarketPay::TEST_CARDS[$tp] ?? []))) ?>. Then go back to E-commerce setup: step 5 shows how it went.</p><?php endif; ?>
  <p class="text-sm text-[color:var(--tv-meta)]">From <a class="underline" href="/listing/view.php?id=<?= $e ?>"><?= tv_e($biz) ?></a>. You pay <?= tv_e($biz) ?> directly; Traversence never holds your money.</p>
  <?php if (!empty($check['bad'])): ?><p data-tv-status="info" data-tv-label="Left out:"><?= tv_e(implode('; ', array_map(fn ($l) => $l['title'] . ': ' . $l['why'], $check['bad']))) ?></p><?php endif; ?>
  <form id="ct" class="ct-f" novalidate>
    <section class="ct-card tv-bleed"><h2>Your order</h2>
      <?php foreach ($all as $l): ?><div class="ct-l"><span class="nm"><?= tv_e($l['title']) ?></span><small><?= (int) $l['qty'] ?> × <?= tv_e(MarketCheckout::money((int) $l['unit_cents'])) ?></small><b><?= tv_e(MarketCheckout::money((int) $l['qty'] * (int) $l['unit_cents'])) ?></b></div><?php endforeach; ?>
      <?php if (!empty($kp['lines'][0]['kx']['interval'])): $iv = $kp['lines'][0]['kx']['interval']; ?><p data-tv-status="info" data-tv-label="Subscription:">Charged <?= tv_e(MarketCheckout::money((int) $t['total'])) ?> every <?= tv_e($iv) ?><?= !empty($kp['lines'][0]['kx']['trial_days']) ? ', starting after a ' . (int) $kp['lines'][0]['kx']['trial_days'] . '-day free trial' : '' ?>, until you cancel. Cancel any time from your order page; it ends at the close of the <?= tv_e($iv) ?> you&rsquo;ve paid for.</p><?php endif; ?>
      <?php if ($bal > 0): ?><p data-tv-status="info" data-tv-label="Deposit:">Made to order: you pay <?= tv_e(MarketCheckout::money((int) $t['total'] - $bal)) ?> now, and <?= tv_e(MarketCheckout::money($bal)) ?> when it&rsquo;s ready.</p><?php endif; ?>
      <?php if ($kp['hold']): ?><p data-tv-status="info" data-tv-label="Deposit:">The deposit is held on your card, not charged, and released when it comes back undamaged.</p><?php endif; ?>
    </section>
    <?php if (in_array($bk, ['booking', 'rental'], true) || $kErr !== '' || in_array('specs', $kp['needs'], true) || $kp['windows'] || $kp['house_rules'] !== ''): /* what this kind needs from the buyer */ ?>
    <section class="ct-card tv-bleed ct-k"><h2><?= $bk === 'booking' ? 'Your stay' : ($bk === 'rental' ? 'Your rental' : 'What ' . tv_e($biz) . ' needs') ?></h2>
      <?php if ($kErr !== ''): ?><p data-tv-status="bad" data-tv-label="Check this:"><?= tv_e($kErr) ?></p><?php endif; ?>
      <?php if (in_array($bk, ['booking', 'rental'], true)): /* dates change the price, so they're asked here and the page recounts */ ?>
        <div class="ct-dates" id="ct-dates">
          <label><?= $bk === 'booking' ? 'Check in' : 'Pick up' ?><input type="date" name="from" value="<?= tv_e($kx['from']) ?>" min="<?= date('Y-m-d') ?>"></label>
          <label><?= $bk === 'booking' ? 'Check out' : 'Bring back' ?><input type="date" name="to" value="<?= tv_e($kx['to']) ?>" min="<?= date('Y-m-d') ?>"></label>
          <?php if ($bk === 'booking'): ?><label>Guests<input type="number" name="guests" min="1" max="<?= (int) ($kd['max_guests'] ?? 2) ?>" value="<?= (int) $kx['guests'] ?>"></label><?php endif; ?>
          <button type="button" class="ct-b" id="ct-recount">Check dates</button>
        </div>
        <?php if ($bk === 'rental' && !empty($kd['waiver'])): ?><label class="ct-opt"><input type="checkbox" name="waiver" value="1"<?= $kx['waiver'] ? ' checked' : '' ?> id="ct-waiver"><span>Add the damage waiver, <?= tv_e(MarketCheckout::money((int) $kd['waiver'])) ?><small>Covers accidental damage while you have it.</small></span></label><?php endif; ?>
        <?php if (in_array('dates', $kp['needs'], true) && $kErr === ''): ?><p data-tv-status="info" data-tv-label="Dates:">Choose your dates to see the price and book.</p><?php endif; ?>
      <?php endif; ?>
      <?php foreach ($kp['lines'] as $l) if (!empty($l['kx']['specs'])) { echo '<p class="text-sm" style="margin:.2rem 0 0"><b>' . tv_e($l['title']) . '</b></p>'; $si = 0; foreach ($l['kx']['specs'] as $q => $a) echo '<label>' . tv_e($q) . '<input data-spec="' . (int) $l['item_id'] . '" data-i="' . $si++ . '" maxlength="400" required></label>'; } ?>
      <?php if ($kp['windows']): ?><label>Pickup window<select name="window" required><option value="">Choose one</option><?php foreach ($kp['windows'] as $w): ?><option><?= tv_e($w) ?></option><?php endforeach; ?></select></label><?php endif; ?>
      <?php if ($kp['house_rules'] !== ''): ?><div><b class="text-sm">House rules</b><div class="ct-rules"><?= tv_e($kp['house_rules']) ?></div></div>
        <label class="ct-opt"><input type="checkbox" name="rules" value="1"><span>I&rsquo;ve read the house rules and agree to them<small>Kept with your booking.</small></span></label><?php endif; ?>
    </section>
    <?php endif; ?>
    <?php if ($kp['ships']): ?>
    <section class="ct-card tv-bleed"><h2>How you get it</h2>
      <?php foreach ($s['ship'] as $i => $o): ?><label class="ct-opt"><input type="radio" name="ship" value="<?= tv_e($o['id']) ?>" data-cents="<?= (int) $o['price_cents'] ?>" data-pickup="<?= !empty($o['pickup']) ? 1 : 0 ?>"<?= $i ? '' : ' checked' ?>><span><?= tv_e($o['name']) ?> · <?= (int) $o['price_cents'] ? tv_e(MarketCheckout::money((int) $o['price_cents'])) : 'free' ?><?php if (!empty($o['pickup']) && $s['pickup_note'] !== ''): ?><small><?= tv_e($s['pickup_note']) ?></small><?php endif; ?></span></label><?php endforeach; ?>
      <div id="ct-addr" hidden><input name="who" maxlength="120" placeholder="Name it goes to" autocomplete="name"><textarea name="address" rows="2" maxlength="400" placeholder="Street, town, state and ZIP" autocomplete="street-address"></textarea></div>
      <textarea name="note" rows="2" maxlength="600" placeholder="A note for <?= tv_e($biz) ?> (optional)"></textarea>
    </section>
    <?php else: ?><section class="ct-card tv-bleed"><h2>Getting it</h2><p class="text-sm" style="margin:0 0 .4rem"><?= tv_e(KindCheckout::getting($kp)) ?></p><div id="ct-addr" hidden><input name="who"><textarea name="address"></textarea></div>
      <textarea name="note" rows="2" maxlength="600" placeholder="A note for <?= tv_e($biz) ?> (optional)"></textarea></section><?php endif; ?>
    <section class="ct-card tv-bleed"><h2>How you pay</h2>
      <?php if (!$ways): ?><p data-tv-status="bad" data-tv-label="Not right now:"><?= tv_e($biz) ?> isn&rsquo;t taking <?= $kp['mode'] === 'subscription' ? 'card payments for subscriptions' : 'payments here' ?> at the moment. Message them.</p><?php endif; ?>
      <?php $n = 0; foreach ($ways as $k => $label): ?><label class="ct-opt"><input type="radio" name="method" value="<?= tv_e($k) ?>"<?= $n++ ? '' : ' checked' ?>><span><?= tv_e($label) ?><?php if ($k !== 'card'): ?><small>You&rsquo;ll see <?= tv_e($biz) ?>&rsquo;s instructions next. They confirm when it arrives.</small><?php else: ?><small>Through <?= tv_e($biz) ?>&rsquo;s own <?= tv_e(MarketPay::PROVIDERS[MarketCheckout::gateway($pdo, $e)['provider'] ?? 'stripe'] ?? 'card') ?> account. Your card details go to them, never to Traversence.</small><?php endif; ?></span></label><?php endforeach; ?>
    </section>
    <section class="ct-card tv-bleed">
      <div class="ct-sum"><span>Items</span><span><?= tv_e(MarketCheckout::money($t['sub'])) ?></span><?php if ($kp['ships']): ?><span>Getting it</span><span id="ct-ship"><?= tv_e(MarketCheckout::money($t['ship'])) ?></span><?php endif; ?>
        <span>Sales tax</span><span><?= tv_e(MarketCheckout::money($t['tax'])) ?></span><b>Total<?= $kp['mode'] === 'subscription' ? ' each ' . tv_e($kp['lines'][0]['kx']['interval'] ?? 'month') : '' ?></b><b id="ct-total"><?= tv_e(MarketCheckout::money($t['total'])) ?></b>
        <?php if ($bal > 0): ?><span>Paid now (deposit)</span><span id="ct-now"><?= tv_e(MarketCheckout::money($t['total'] - $bal)) ?></span><span>When it&rsquo;s ready</span><span><?= tv_e(MarketCheckout::money($bal)) ?></span><?php endif; ?></div>
      <?php [$ctLine, $ctSnap] = MarketCheckout::agreement($pdo, $e); echo StorePolicies::css() . StorePolicies::box($pdo, $e, $ctSnap, false, $biz . '\'s store policies'); ?>
      <?php if ($canPlace): ?><div class="ct-agree"><?= LegalTexts::md($ctLine) ?></div><?php endif; /* placing the order is the acceptance, recorded (decisions/0142 §1, §2) */ ?>
      <?php if ($canPlace): ?><div style="margin-top:.7rem"><button class="ct-b go" type="submit" id="ct-go"><?= $kp['mode'] === 'subscription' ? 'Subscribe' : ($bk === 'booking' ? 'Book it' : 'Place order') ?></button> <a class="ct-b" href="/market/cart.php">Back</a></div><?php endif; ?>
      <div id="ct-pay"></div>
    </section>
  </form>
<?php else: ?>
  <h1>Your carts</h1>
  <?php if ($why !== ''): ?><p data-tv-status="info" data-tv-label="Not now:"><?= tv_e($why) ?></p><?php endif; ?>
  <?php if (!$carts): ?><p class="text-sm">Nothing in your carts. <a class="underline" href="/market/?from=business">Shop local businesses on the Marketplace</a></p><?php endif; ?>
  <?php foreach ($carts as $c): ?>
  <section class="ct-card tv-bleed"><h2>Your order from <?= tv_e($c['name']) ?></h2>
    <?php foreach ($c['lines'] as $l): ?><div class="ct-l"><a class="nm" href="/market/item.php?id=<?= (int) $l['item_id'] ?>"><?= tv_e($l['title']) ?></a><small><?= tv_e(MarketCheckout::money((int) $l['unit_cents'])) ?> each<?= $l['ok'] ? '' : ' · ' . tv_e($l['why']) ?></small>
      <input type="number" min="0" max="<?= MarketCheckout::MAX_QTY ?>" value="<?= (int) $l['qty'] ?>" data-qty="<?= (int) $l['item_id'] ?>" aria-label="How many"></div><?php endforeach; ?>
    <div class="ct-l"><b>Items: <?= tv_e(MarketCheckout::money((int) $c['sub'])) ?></b><a class="ct-b go" href="/market/cart.php?b=<?= (int) $c['entity_id'] ?>">Check out</a></div>
  </section>
  <?php endforeach; ?>
<?php endif; ?>
</div>
<script<?= tv_nonce() ?>>
(function () {
  var TOK = <?= json_encode($csrf) ?>;
  function post(b) { return fetch('/api/market-pay.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': TOK }, body: JSON.stringify(window.tvSafe ? tvSafe(b) : b) })
    .then(function (r) { return r.json(); }).then(function (d) { if (!d.ok) throw new Error((d.error && d.error.message) || 'That didn\'t work.'); return d; }); }
  document.querySelectorAll('[data-qty]').forEach(function (q) { q.addEventListener('change', function () { post({ action: 'qty', item: +q.getAttribute('data-qty'), qty: +q.value }).then(function () { location.reload(); }, function (x) { TvAsk.say(x.message, { anchor: q, bad: true }); }); }); });
  var f = document.getElementById('ct'); if (!f) return;
  var SUB = <?= (int) ($t['sub'] ?? 0) ?>, TAX = <?= (int) ($t['tax'] ?? 0) ?>, BAL = <?= $bal ?>, addr = document.getElementById('ct-addr');
  var rc = document.getElementById('ct-recount');   // a stay's or a rental's dates: the page recounts the price
  function recount() { var q = new URLSearchParams({ item: <?= (int) $itemId ?> }); f.querySelectorAll('#ct-dates input').forEach(function (i) { if (i.value) q.set(i.name, i.value); });
    var w = document.getElementById('ct-waiver'); if (w && w.checked) q.set('waiver', '1'); TvAsk.busy(rc, true); location.href = '/market/cart.php?' + q.toString(); }
  if (rc) { rc.addEventListener('click', recount); var w0 = document.getElementById('ct-waiver'); if (w0) w0.addEventListener('change', recount); }
  function money(c) { return '$' + (c / 100).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function ship() { var o = f.querySelector('[name=ship]:checked'); if (!o) return; addr.hidden = o.getAttribute('data-pickup') === '1'; var c = +o.getAttribute('data-cents');
    document.getElementById('ct-ship').textContent = money(c); document.getElementById('ct-total').textContent = money(SUB + c + TAX); var n = document.getElementById('ct-now'); if (n) n.textContent = money(SUB + c + TAX - BAL); }
  f.querySelectorAll('[name=ship]').forEach(function (r) { r.addEventListener('change', ship); }); ship();
  function load(src) { return new Promise(function (ok, no) { var s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = function () { no(new Error('The payment form didn\'t load. Check your connection and try again.')); }; document.head.appendChild(s); }); }
  f.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var go = document.getElementById('ct-go'), m = f.querySelector('[name=method]:checked'), sh = f.querySelector('[name=ship]:checked');
    var body = { action: 'place', method: m ? m.value : '', ship: sh ? sh.value : '', name: f.who.value, address: f.address.value, note: f.note.value };
    var kx = <?= json_encode(['from' => $kx['from'], 'to' => $kx['to'], 'guests' => $kx['guests'], 'waiver' => $kx['waiver']]) ?>, specs = {};   // what this kind asked (KindCheckout::prepare)
    f.querySelectorAll('[data-spec]').forEach(function (i) { var k = i.getAttribute('data-spec'); (specs[k] = specs[k] || {})[i.getAttribute('data-i')] = i.value; });
    kx.specs = specs; if (f.window) kx.window = f.window.value; if (f.rules) kx.rules = f.rules.checked; body.kx = kx;
    <?php if (!empty($check['test'])): ?>body.action = 'test'; body.entity = <?= (int) $e ?>;<?php elseif ($check && $check['buy']): ?>body.item = <?= (int) $itemId ?>; body.qty = <?= (int) $qty ?>;<?php else: ?>body.entity = <?= (int) $e ?>;<?php endif; ?>
    TvAsk.busy(go, true);
    post(body).then(function (d) {
      if (!d.pay) { location.href = d.url; return; }
      f.querySelectorAll('input,textarea,button').forEach(function (x) { if (x !== go) x.disabled = true; });
      var box = document.getElementById('ct-pay'); go.hidden = true;
      if (d.pay.kind === 'mock') {
        box.innerHTML = '<p data-tv-status="info" data-tv-label="Test mode:">No money moves.</p><button type="button" class="ct-b go" id="ct-mock">Pay ' + d.total + ' with the test card</button>';
        document.getElementById('ct-mock').addEventListener('click', function () { post({ action: 'mock_pay', order: d.order }).then(function (r) { location.href = r.url; }, function (x) { TvAsk.say(x.message, { anchor: box, bad: true }); }); });
      } else if (d.pay.kind === 'stripe') {
        load('https://js.stripe.com/v3/').then(function () {
          var stripe = Stripe(d.pay.publishable, { stripeAccount: d.pay.account });
          var o = { fetchClientSecret: function () { return Promise.resolve(d.pay.client_secret); } };   // Stripe's embedded_page Checkout (2026-11-02)
          return stripe.createEmbeddedCheckoutPage ? stripe.createEmbeddedCheckoutPage(o) : stripe.initEmbeddedCheckout(o);
        }).then(function (c) { c.mount('#ct-pay'); }, function (x) { TvAsk.say(x.message, { anchor: box, bad: true }); });
      } else if (d.pay.kind === 'square') {
        load(d.pay.sandbox ? 'https://sandbox.web.squarecdn.com/v1/square.js' : 'https://web.squarecdn.com/v1/square.js').then(function () {
          var payments = Square.payments(d.pay.app_id, d.pay.location_id);
          return payments.card().then(function (card) {
            box.innerHTML = '<div id="ct-card"></div><button type="button" class="ct-b go" id="ct-sq">Pay ' + d.total + '</button>';
            return card.attach('#ct-card').then(function () {
              document.getElementById('ct-sq').addEventListener('click', function () {
                var b = this; b.disabled = true;
                card.tokenize().then(function (r) {
                  if (r.status !== 'OK') throw new Error((r.errors && r.errors[0] && r.errors[0].message) || 'Check the card details.');
                  return post({ action: 'square_pay', order: d.order, source: r.token });
                }).then(function (r) { location.href = r.url; }, function (x) { TvAsk.say(x.message, { anchor: b, bad: true }); b.disabled = false; });
              });
            });
          });
        }).catch(function (x) { TvAsk.say(x.message, { anchor: box, bad: true }); });
      }
    }, function (x) { TvAsk.busy(go, false); TvAsk.say(x.message, { anchor: go, bad: true }); });
  });
})();
</script>
<?php tv_page_end();
