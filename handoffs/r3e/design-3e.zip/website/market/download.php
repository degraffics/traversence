<?php
// market/download.php?t=<token> — a Digital goods file, for the buyer who paid for it (decisions/0141 §5, KindCheckout).
// The link works its set number of times within its set days; each use is counted. The file stays private: the browser
// is sent to a short-lived link to it in storage, with its own name, never a lasting address.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/MarketCheckout.php';
require_once __DIR__ . '/../../app/lib/Store.php';

$pdo = Database::connection();
[$ok, $rel, $name, $why, $mime] = KindCheckout::download($pdo, (string) ($_GET['t'] ?? '')) + [4 => 'application/octet-stream'];
$path = $ok ? dirname(__DIR__, 2) . '/app/storage/' . ltrim(str_replace('..', '', $rel), '/') : '';
$name = preg_replace('/[^A-Za-z0-9._ -]+/', '-', $name) ?: 'download';
if ($ok) {
    Store::redirect($path, $name, $mime, false);   // in S3: a 15-minute link, then this stops
    if (is_file($path)) {
        header('Content-Type: ' . $mime); header('Content-Length: ' . filesize($path)); header('Cache-Control: private, no-store');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        readfile($path); exit;
    }
    $why = 'The file isn\'t where it should be. Ask the seller.';
}
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
http_response_code(404);
tv_page_start('Download', ['section' => 'market', 'no_crumbs' => true]);
?>
<div style="max-width:40rem"><h1 style="font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.5rem;color:var(--tv-ink,#3E2B1F);margin:0 0 .5rem">Download</h1>
  <p data-tv-status="bad" data-tv-label="Not available:"><?= tv_e($why) ?></p>
  <p class="text-sm"><a class="underline" href="/user/market/">Your orders</a></p></div>
<?php tv_page_end();
