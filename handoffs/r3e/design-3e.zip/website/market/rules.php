<?php
// market/rules.php — what can be sold on the Marketplace (decisions/0142 §4), for anyone: check an item by its name
// (?q=), and the rules by tier. The same check publishing makes (MarketRules), so what it says here is what happens there.
// The words our team looks at first aren't listed (listing them would show how to word around them); the check still
// says when an item would wait for a look. No script: the check is a plain form.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/MarketRules.php';

$q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 160);
$about = mb_substr(trim((string) ($_GET['about'] ?? '')), 0, 600);
$res = $q !== '' ? MarketRules::forCatalog($q, $about) : null;
$tier = $q !== '' ? MarketRules::check((function () { try { return Database::connection(); } catch (Throwable) { return null; } })(), $q, $about)['tier'] : '';

tv_page_start('What can be sold', ['no_crumbs' => true, 'description' => 'What can and can\'t be sold on the Traversence Marketplace, and a quick check for any item.']);
$byTier = ['prohibited' => [], 'restricted' => [], 'confirm' => [], 'notice' => []];
foreach (MarketRules::RULES as [$t, $name, , $why]) $byTier[$t][] = [$name, $why];
$tone = ['prohibited' => 'bad', 'restricted' => 'info', 'confirm' => 'info', 'review' => 'info', 'notice' => 'ok', 'ok' => 'ok'][$tier] ?? 'info';
?>
<style>
  .mr{max-width:46rem;color:var(--tv-ink,#3E2B1F)}.mr h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.6rem,2.8vw,2.1rem);margin:0}
  .mr-sub{font-size:.92rem;color:var(--tv-meta,#5C4632);margin:.3rem 0 1rem}
  .mr-f{display:flex;flex-wrap:wrap;gap:.45rem;background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line,#EADFC4);border-radius:.8rem;padding:.7rem}
  .mr-f input{flex:1 1 14rem;min-width:0;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;padding:.5rem .65rem;font-size:.95rem;background:var(--tv-card-a,#fff)}
  .mr-f button{border:0;background:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2);border-radius:.6rem;padding:.5rem 1rem;font-weight:700;cursor:pointer}
  .mr-r{margin:.7rem 0 0}.mr-r b{display:block}
  .mr h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1.15rem;margin:1.5rem 0 .3rem}.mr-n{font-size:.88rem;color:var(--tv-meta,#5C4632);margin:.1rem 0 .5rem}
  .mr dl{margin:0;display:grid;gap:.1rem}.mr dt{font-weight:700;margin-top:.5rem;font-size:.92rem}.mr dd{margin:0;font-size:.9rem;color:var(--tv-meta,#5C4632);line-height:1.45}
  .mr-box{background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line,#EADFC4);border-radius:.8rem;padding:.4rem .9rem .8rem}
  @media (max-width:767px){.mr-f,.mr-box{border-radius:.5rem}}
</style>
<div class="mr">
  <h1>What can be sold</h1>
  <p class="mr-sub">The same rules for every business and every member, checked when an item is published. Stripe's and Square's own rules apply too, and can be stricter. Anything can stay in a business's own catalog for quotes and invoices.</p>
  <form class="mr-f tv-bleed" method="get" action="/market/rules.php" role="search">
    <input name="q" value="<?= tv_e($q) ?>" placeholder="Check an item: its name, like “wine rack” or “hunting knife”" aria-label="The item's name" maxlength="160">
    <button type="submit">Check</button>
  </form>
  <?php if ($res): ?>
  <div class="mr-r"><p data-tv-status="<?= $tone ?>" data-tv-label="<?= tv_e($res[0]) ?>:"><?= tv_e($res[1]) ?></p></div>
  <p class="mr-n">The check reads a name the way search does: what the item is, not just the words in it. A wine rack is a rack and a gun safe is a safe; red wine is wine. A description only sends an item to our team for a look, never blocks it. If a name still sounds restricted, publishing asks whether it is, and you answer once.</p>
  <?php endif; ?>

  <h2>Never sold here</h2>
  <p class="mr-n">An item like this doesn't go up, and the business or member is told why.</p>
  <div class="mr-box tv-bleed"><dl><?php foreach ($byTier['prohibited'] as [$n, $w]): ?><dt><?= tv_e($n) ?></dt><dd><?= tv_e($w) ?></dd><?php endforeach; ?></dl></div>

  <h2>Sold with a license</h2>
  <p class="mr-n">A business confirms it holds the license and meets the conditions (kept as a record). Card processors (Stripe, Square) restrict these themselves, so buyers pay the business directly or ask for a quote.</p>
  <div class="mr-box tv-bleed"><dl><?php foreach ($byTier['restricted'] as [$n, $w]): ?><dt><?= tv_e($n) ?></dt><dd><?= tv_e($w) ?></dd><?php endforeach; ?></dl></div>

  <h2>Sold under conditions</h2>
  <p class="mr-n">Lawful to sell when these conditions are met. A business confirms them once for each item (kept as a record); buyers see them on the item, and can pay by card.</p>
  <div class="mr-box tv-bleed"><dl><?php foreach ($byTier['confirm'] as [$n, $w]): ?><dt><?= tv_e($n) ?></dt><dd><?= tv_e($w) ?></dd><?php endforeach; ?></dl></div>

  <h2>Sold with a notice</h2>
  <p class="mr-n">Fine to sell; buyers see a short notice on the item.</p>
  <div class="mr-box tv-bleed"><dl><?php foreach ($byTier['notice'] as [$n, $w]): ?><dt><?= tv_e($n) ?></dt><dd><?= tv_e($w) ?></dd><?php endforeach; ?></dl></div>

  <h2>Looked at first</h2>
  <p class="mr-n">Some words, such as cultural items, protected wildlife or a request for a deposit, mean a person on our team looks before the item shows, usually within a day. The check above says when that would happen. Anyone can report an item from its page; a shop that keeps breaking the rules can be paused, never its listing or map pin. More in the <a class="underline" href="/faq.php#what-can-my-business-sell-on-the-marketplace">FAQ</a>.</p>
</div>
<?php tv_page_end();
