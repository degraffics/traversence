<?php
// /shop/ — the Traversence Shop (decisions/0154 §6): one place for what Traversence sells, shown for who's looking (T06).
// A member: Personal Plus and Pro, storage packs, GO Codes. A business (you're acting as it): its plan and upgrades,
// storage and AI packs, GO Codes, White Glove, design, video, print and signs, the creator add-ons. A guest: GO Codes, and
// what an account adds. Plans and packs pay in place on the Plans page (a card kept on file, QuickBooks Pay); GO Codes go
// in the cart (/qr/cart.php). Named Shop, not Market, so it isn't confused with the Marketplace or Market 360°.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/Billing.php';
require_once __DIR__ . '/../../app/lib/QrIssue.php';
require_once __DIR__ . '/../../app/lib/Roles.php';
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/ui/go-codes.php';
header('Content-Type: text/html; charset=utf-8');   // bootstrap defaults to JSON

$me = Auth::currentUser();
$pdo = Database::connection();
$uid = $me ? (int) $me['id'] : 0;
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$usd = fn (int $c) => '$' . number_format($c / 100, 2);
$biz = 0; $bizName = '';
if ($uid) { try { $cx = Roles::current($pdo, $uid); if (str_starts_with((string) $cx['key'], 'entity:')) { $biz = (int) substr((string) $cx['key'], 7); $bizName = (string) $cx['label']; } } catch (Throwable) {} }
$ready = Billing::ready($pdo);
$canBill = $biz && $ready && Billing::canManage($pdo, $uid, 'listing', $biz);
$plan = $uid && $ready ? (string) Billing::allowance($pdo, $biz ? 'listing' : 'user', $biz ?: $uid)['plan'] : '';
$cartN = 0; try { if ($me || QrIssue::guestKey() !== '') $cartN = count(QrIssue::cart($pdo, QrIssue::owner($me, false))['items']); } catch (Throwable) {}   // the items, as the header's cart counts them
if ($uid) { try { require_once __DIR__ . '/../../app/lib/CartPlans.php'; foreach (CartPlans::groups($pdo, $uid) as $cg) $cartN += count($cg['lines']); } catch (Throwable) {} }   // and plans and packs (one cart)

tv_page_start('Shop', ['no_crumbs' => true, 'description' => 'The Traversence Shop: plans, storage, GO Codes and services, for members and businesses.']);
tv_go_head('', false);
// [name, what it is, price line, link, label of the button, it's what you have now]
$card = function (string $name, string $what, string $price, string $href, string $btn, bool $now = false) use ($e): string {
    return '<div class="sh-it tv-bleed"><div><b>' . $e($name) . ($now ? ' <span class="sh-now">Yours now</span>' : '') . '</b><small>' . $e($what) . '</small></div>'
        . '<div class="sh-r"><span class="sh-p">' . $e($price) . '</span>' . ($now || $href === '' ? '' : (str_starts_with($href, 'cart:')   // into the one cart (decisions/0154 §6)
            ? '<button type="button" class="go-btn" data-cart="' . $e(substr($href, 5)) . '">' . $e($btn) . '</button>' : '<a class="go-btn" href="' . $e($href) . '">' . $e($btn) . '</a>')) . '</div></div>';
};
?>
<style>
  .sh-it{display:flex;gap:.8rem;justify-content:space-between;align-items:center;border-top:1px solid var(--tv-line,#EADFC4);padding:.6rem 0}
  .sh-it:first-of-type{border-top:0}.sh-it b{display:block;color:var(--tv-ink,#3E2B1F)}.sh-it small{display:block;color:var(--tv-meta,#5C4632);font-size:.82rem;line-height:1.35;margin-top:.1rem}
  .sh-r{display:flex;flex-direction:column;align-items:flex-end;gap:.3rem;flex:none;text-align:right}.sh-p{font-weight:700;white-space:nowrap}
  .sh-now{display:inline-block;background:var(--tv-sage,#8FBCA8);color:#1F3A2E;border-radius:999px;padding:0 .5rem;font-size:.72rem;font-weight:700;margin-left:.3rem}
  .sh-soon{opacity:.75}.sh-cart{display:flex;justify-content:space-between;align-items:center;gap:.6rem;flex-wrap:wrap}
  @media (max-width:540px){.sh-it{flex-direction:column;align-items:stretch}.sh-r{flex-direction:row;justify-content:space-between;align-items:center}}
</style>
<div class="go">
  <h1>Shop</h1>
  <p class="go-lead">What Traversence sells, in one place<?= $biz ? ', for <b>' . $e($bizName) . '</b>' : ($uid ? ', for you' : '') ?>. Plans sell tools, storage and support, never a higher place in search. Creators keep 100% of what they earn here.</p>
  <section class="go-card tv-bleed sh-cart"><span><b>Your cart</b>: <?= $cartN ?> <?= $cartN === 1 ? 'item' : 'items' ?>. GO Codes, plans and storage packs all go in the cart and are paid together; a plan keeps your card on file for renewals.</span><a class="go-btn" href="/qr/cart.php">Open the cart</a></section>
  <section class="go-card tv-bleed" id="domains"><h2>Domains</h2>   <!-- a department of its own (decisions/0169 §1a): any account, no plan needed -->
    <?= $card('A domain name', 'Your own web address, like yourname.com: search a name and see our price a year. Registered in your name with privacy on, yours to keep, renew or move.' . ($biz ? ' For ' . $bizName . ', or for you.' : ''), 'A year, shown in search', '/shop/domains.php' . ($biz ? '?for=listing:' . $biz : ''), 'Find a domain') ?>
    <?php if ($uid): ?><p class="go-note" style="margin-top:.4rem">Domains you hold: <a href="<?= $biz ? '/business/' . $biz . '/domains' : '/user/domains/' ?>">Your domains</a>.</p><?php endif; ?>
  </section>
<?php if ($biz): /* ---- a business ---------------------------------------------------------------------------------- */
  $pu = '/plans.php?listing=' . $biz; ?>
  <section class="go-card tv-bleed"><h2>Plans for <?= $e($bizName) ?></h2>
    <?php if (!$canBill): ?><p class="go-note">Only the owner, or someone they let handle billing, can change the plan. Ask them, or see the plans below.</p><?php endif; ?>
    <?php foreach (Billing::PLANS as $k => [$n, $for, $c, $gb, $ai]) { if ($for !== 'listing' || $k === 'free') continue;
        echo $card($n, $gb . ' GB storage' . ($ai ? ', ' . $ai . ' AI Assist credits a month' : '') . ', and the tools its tier opens.', $usd($c) . ' a month', $canBill ? 'cart:listing:' . $biz . ':' . $k : $pu . '&pick=' . $k, $canBill ? 'Add to cart' : 'Choose', $plan === $k); } ?>
  </section>
  <section class="go-card tv-bleed" id="packs"><h2>Storage and AI packs</h2>
    <?php foreach (Billing::ADDONS as $k => [$n, $c]) echo $card($n, 'Renews with your plan; added now, you pay for the rest of this period.', $usd($c) . ' a month', $canBill ? 'cart:listing:' . $biz . ':' . $k : $pu . '#packs', $canBill ? 'Add to cart' : 'Add'); ?>
  </section>
  <section class="go-card tv-bleed"><h2>Services</h2>
    <?= $card('GO Codes', 'QR codes for your door, menus, signs and cards, in your colors with your logo.', $usd(QrIssue::PRICE_CENTS) . ' each', '/qr/', 'Make one') ?>
    <?= $card('White Glove', 'Our team works in your business for you. Included with Strategic Partner and Cornerstone.', 'With the plan', $pu . '&pick=strategic', 'See the plan', in_array($plan, ['strategic', 'cornerstone'], true)) ?>
    <?= $card('Design, video, print and signs', 'Logos, menus, photos and video, banners, signs and printed cards: tell us what you need and we\'ll send a quote.', 'Quoted', 'mailto:support@traversence.com?subject=' . rawurlencode('A quote for ' . $bizName), 'Ask for a quote') ?>
  </section>
  <section class="go-card tv-bleed sh-soon"><h2>Coming</h2>
    <?= $card('Creator collaborations', 'Find local creators, ask for a post or video, and pay them through our checkout; their post says "Paid partnership". The creator keeps the fee.', 'Add-on', '', '', false) ?>
    <?= $card('Licensing', 'Ask to use a member\'s kept photo or video on your listing, with or without a fee.', 'Add-on', '', '', false) ?>
    <?= $card('Email, text and push packs', 'Send more to the people who linked you.', 'Packs', '', '', false) ?>
  </section>
<?php elseif ($uid): /* ---- a member ------------------------------------------------------------------------------ */
  $pu = '/plans.php?me=1'; ?>
  <section class="go-card tv-bleed"><h2>Your plan</h2>
    <?= $card('Personal', 'Everything social, free: posts, Moments and Snaps, following, reactions and comments, Keep into your Gallery. 2 GB, plus the storage you earn.', 'Free', $pu, 'Choose', $plan === 'personal_free') ?>
    <?php foreach (['personal_plus' => '25 GB, the AI tools, video at 1080p when the video worker is on.', 'personal_pro' => 'The Creator plan: 50 GB, the AI tools, 10-minute videos, uploads to 1 GB, and the income tools as they come.'] as $k => $w)
        echo $card(Billing::PLANS[$k][0], $w, $usd(Billing::PLANS[$k][2]) . ' a month', 'cart:user:' . $uid . ':' . $k, 'Add to cart', $plan === $k); ?>
  </section>
  <?php if (Billing::selfTrialWhyNot($pdo, $uid) === '') echo '<section class="go-card tv-bleed">' . $card('Try Pro free for 7 days', 'Personal Pro for a week: 50 GB, 10-minute videos, uploads to 1 GB. No card, nothing charged; back to Free on its own unless you keep it. Once an account.', 'Free', $pu . '#try', 'Start') . '</section>'; ?>
  <section class="go-card tv-bleed" id="packs"><h2>Storage</h2>
    <?php foreach (Billing::ADDONS as $k => [$n, $c, $gb]) { if (!$gb || $gb > 250) continue; echo $card($n, 'Renews with your plan; added now, you pay for the rest of this period.', $usd($c) . ' a month', 'cart:user:' . $uid . ':' . $k, 'Add to cart'); } ?>
    <p class="go-note" style="margin-top:.5rem"><?= $plan === 'personal_free' ? 'Packs are added to a paid plan (Plus or Pro). ' : '' ?>You can also earn space, free: 1 GB for every friend who joins with your invite, and for every 500 followers, up to 25 GB. <a href="<?= $e($pu) ?>#earned">See yours</a>.</p>
  </section>
  <section class="go-card tv-bleed"><h2>GO Codes</h2>
    <?= $card('GO Codes', 'QR codes for a link, a contact card, an event or your Wi-Fi, in your colors. ' . QrIssue::FREE_TOTAL . ' basic ones free with your account.', $usd(QrIssue::PRICE_CENTS) . ' each', '/qr/', 'Make one') ?>
  </section>
  <section class="go-card tv-bleed"><h2>For a single video</h2>
    <?= $card('Keep one video in 4K', 'Keeps a post with its video at full size, without a plan: Keep in 4K in the post\'s ⋯ menu, then it\'s in your cart. For videos bigger than 720p, before the post is kept.', '$0.99 once', '/user/dashboard.php', 'Your posts') ?>
  </section>
  <section class="go-card tv-bleed"><h2>A single month of Pro</h2>
    <?= $card('A month of Personal Pro', 'Pro\'s 50 GB, 10-minute videos, uploads to 1 GB, the AI tools and creator tools, for one month. Paid once, no card kept, nothing renews: it goes back to the free plan on its own. Buy another before it ends to add a month.', $usd(Billing::PLANS['personal_pro'][2]) . ' once', Billing::oneMonthWhyNot($pdo, $uid) === '' ? 'cart:oneoff:' . $uid . ':pro_month' : '', 'Add to cart', $plan === 'personal_pro' && Billing::oneMonthWhyNot($pdo, $uid) !== '') ?>
  </section>
<?php else: /* ---- a guest ------------------------------------------------------------------------------------------ */ ?>
  <section class="go-card tv-bleed"><h2>GO Codes</h2>
    <?= $card('GO Codes', 'QR codes for a link, a contact card, an event or your Wi-Fi, in your colors with your logo. No account needed.', $usd(QrIssue::PRICE_CENTS) . ' each', '/qr/', 'Make one') ?>
  </section>
  <section class="go-card tv-bleed"><h2>With a free account</h2>
    <?= $card('Personal', 'Posts, Moments and Snaps, following, your Gallery with 2 GB, ' . QrIssue::FREE_TOTAL . ' free GO Codes, and plans when you want more.', 'Free', '/register.php?next=' . rawurlencode('/shop/'), 'Join') ?>
    <?= $card('For a business', 'Claim or add your business: its listing, posts, messages and tools, free to start.', 'Free to start', '/claim.php', 'Claim or add') ?>
  </section>
<?php endif; ?>
  <p class="go-note">Prices are before tax. Plans are monthly (a year is 10 months' price for 12); packs are always full price. <a href="/terms.php#plans">Terms</a> · Questions: <a href="mailto:support@traversence.com">support@traversence.com</a></p>
</div>
<script<?= function_exists('tv_nonce') ? tv_nonce() : '' ?>>
document.addEventListener('click', function (e) {   // Add to cart: plans and packs go in the one cart (decisions/0154 §6), then the cart
  var b = e.target.closest('[data-cart]'); if (!b || !window.Go) return;
  var p = b.getAttribute('data-cart').split(':');
  if (window.TvAsk && TvAsk.busy) TvAsk.busy(b, true);
  Go.go(p[0] === 'oneoff' ? { action: p[2] + '_add' } : { action: 'plan_add', type: p[0], id: +p[1], item: p[2], cycle: 'month' }).then(function () { location.href = '/qr/cart.php'; })
    .catch(function (x) { if (window.TvAsk) { TvAsk.busy(b, false); TvAsk.say(x.message, { anchor: b, bad: true }); } });
});
</script>
<?php tv_page_end();
