<?php
// app/ui/domains-view.php — the account's Domains (decisions/0169 §1a) as one shared view: a member's Domains page
// (/user/domains/, also in the Dashboard), a business's Domains in the portal, and Shop → Domains. The page is drawn by
// js/tv-domains.js from /api/domains.php, so the Storefront app's address step (0169 app 6) can reuse the same pieces.
// tv_domains_view($type, $id, 'tab' | 'shop'). Needs tv_go_head() on the page (the buttons and js/go-codes.js).
declare(strict_types=1);

function tv_domains_view(string $type, int $id, string $mode = 'tab'): string
{
    $e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
    $v = (int) @filemtime(__DIR__ . '/../../website/js/tv-domains.js');
    return '<style>'
        . '.dm-card{background:var(--tv-sec,#F7EFDC);border:1px solid var(--tv-line,#EADFC4);border-radius:.9rem;padding:1rem;margin:0 0 .9rem;color:var(--tv-ink,#3E2B1F)}'
        . '.dm-h{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.15rem;margin:0 0 .5rem}.dm-h3{font:700 .98rem var(--tv-font-head,Georgia,serif);margin:.4rem 0 .3rem}'
        . '.dm-note{font-size:.82rem;color:var(--tv-meta,#5C4632);line-height:1.45;margin:.25rem 0}.dm-note a{color:var(--tv-link,#92400E);text-decoration:underline;font-weight:600}'
        . '.dm-row{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;margin:.4rem 0}.dm-in{border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.5rem;padding:.45rem .6rem;background:var(--tv-card-a,#FFFBF2);font:inherit;min-width:0;max-width:100%}'
        . 'textarea.dm-in{width:100%}.dm-l{display:grid;gap:.2rem;font-size:.8rem;font-weight:600;color:var(--tv-meta,#5C4632)}.dm-tick{display:flex;gap:.45rem;align-items:center;font-size:.85rem;margin:.5rem 0}'
        . '.dm-who{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(12rem,100%),1fr));gap:.4rem .6rem}'
        . '.dm-res{display:flex;flex-wrap:wrap;align-items:center;gap:.3rem .8rem;padding:.5rem 0;border-top:1px solid var(--tv-line,#EADFC4)}.dm-res b{margin-right:auto;word-break:break-all}.dm-yrs{font:inherit;font-size:.85rem;padding:.3rem .45rem;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.5rem;background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);cursor:pointer}'
        . '.dm-top{display:flex;align-items:center;gap:.5rem;justify-content:space-between}.dm-name{color:var(--tv-link,#92400E);text-decoration:underline;font-weight:700;font-size:1.05rem;word-break:break-all}'
        . '.dm-pill{font-size:.72rem;font-weight:600;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;padding:.1rem .5rem;white-space:nowrap;background:var(--tv-card-a,#FFFBF2)}'
        . '.dm-acts .go-btn{padding:.35rem .65rem;font-size:.8rem}.dm-panel{border-top:1px solid var(--tv-line,#EADFC4);margin-top:.5rem;padding-top:.4rem}.dm-sub{border-top:1px dashed var(--tv-line,#EADFC4);padding:.5rem 0}'
        . '.dm-tbl{display:grid;font-size:.85rem;margin:.4rem 0}.dm-r{display:grid;grid-template-columns:6rem 4rem 1fr 2rem;gap:.4rem;padding:.35rem 0;border-top:1px solid var(--tv-line,#EADFC4);align-items:start}.dm-hd{font-weight:700;color:var(--tv-meta,#8A7355);border-top:0}'
        . '.dm-v{word-break:break-all}.dm-x{width:28px;height:28px;border-radius:999px;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-meta,#8A7355);cursor:pointer}.dm-x:hover{color:var(--tv-crimson,#B91C1C);border-color:var(--tv-fail,#B91C1C)}'
        . '.dm-wc{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.4rem;border-top:1px solid var(--tv-line,#EADFC4);padding:.5rem 0}.dm-wc small{display:block}.dm-hist{font-size:.82rem;padding-left:1rem;margin:.3rem 0}'
        . '@media (max-width:640px){.dm-r{grid-template-columns:4rem 3.2rem 1fr 2rem}}'
        . '</style><div data-dm-root data-dm-mode="' . $e($mode) . '" data-type="' . $e($type) . '" data-id="' . (int) $id . '"><p class="dm-note">Loading…</p></div>'
        . '<script src="/js/tv-domains.js?v=' . $v . '"' . (function_exists('tv_nonce') ? tv_nonce() : '') . ' defer></script>';
}
