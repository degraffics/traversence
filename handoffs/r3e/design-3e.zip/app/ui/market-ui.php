<?php
// app/ui/market-ui.php — what Marketplace pages share (decisions/0135): the card, its styles and the Save button.
// The card follows the card anatomy (decisions/0058 §11): the name is the link, brand brown and underlined; Save is a
// round icon button with a label for screen readers; details on the left. Phones: edge to edge (tv-bleed).
declare(strict_types=1);

if (!function_exists('tv_icon')) require_once __DIR__ . '/app-shell.php';

function tv_market_css(): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    return '<style>
  .mk-grid{display:grid;gap:.8rem;grid-template-columns:repeat(auto-fill,minmax(190px,1fr))}
  .mk-card{position:relative;background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.9rem;overflow:hidden;display:flex;flex-direction:column}
  .mk-ph{display:block;aspect-ratio:1/1;background:linear-gradient(135deg,var(--tv-sec,#E3D3AC),var(--tv-canvas,#EFE3C8));overflow:hidden}
  .mk-ph img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block}
  .mk-ph .ta-svg{width:40px;height:40px;color:#B8863B;opacity:.6;margin:auto;display:block;position:relative;top:calc(50% - 20px)}
  .mk-b{padding:.5rem .7rem .65rem}
  .mk-price{font-weight:700;font-size:1.02rem;color:var(--tv-ink,#3E2B1F)}
  .mk-name{display:block;font-size:.9rem;line-height:1.25;color:var(--tv-link,#92400E);text-decoration:underline;text-underline-offset:2px;margin-top:.1rem;overflow-wrap:anywhere}
  .mk-m{font-size:.74rem;color:var(--tv-meta,#8A7355);margin-top:.2rem}
  .mk-biz{display:flex;align-items:center;gap:.25rem;color:var(--tv-meta,#5C4632);font-weight:600}.mk-biz .ta-svg{width:13px;height:13px;color:var(--tv-icon,#B45309)}
  .mk-ph{position:relative}.mk-cat{position:absolute;left:.5rem;bottom:.5rem;max-width:calc(100% - 1rem);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:700 .62rem system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;background:rgba(31,92,67,.9);color:var(--tv-on-umber,#FFFBF2);border-radius:.35rem;padding:.15rem .45rem}
  .mk-tag{position:absolute;top:.5rem;left:.5rem;font-size:.62rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;background:rgba(62,43,31,.86);color:var(--tv-on-umber,#FFFBF2);border-radius:.35rem;padding:.12rem .4rem}
  .mk-save{position:absolute;top:.45rem;right:.45rem;width:30px;height:30px;border-radius:999px;border:1.5px solid #B8863B;background:rgba(255,251,242,.9);color:var(--tv-icon,#B45309);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0}
  .mk-save .ta-svg{width:15px;height:15px}
  .mk-save[aria-pressed="true"]{background:var(--tv-sage,#8FBCA8);border-color:var(--tv-sage,#8FBCA8);color:#1F3B30;box-shadow:0 0 0 3px rgba(143,188,168,.35)}
  .mk-save[aria-pressed="true"] .ta-svg{fill:currentColor}
  .mo{border-top:1px solid var(--tv-line,#EADFC4);padding:.6rem 0}.mo:first-of-type{border-top:0}
  .mo-top{display:flex;flex-wrap:wrap;gap:.2rem .6rem;align-items:baseline}
  .mo-amt{font-weight:700;font-size:1.02rem;color:var(--tv-ink,#3E2B1F)}
  .mo-st{font-size:.64rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;border-radius:999px;padding:.12rem .5rem;background:var(--tv-canvas,#EFE3C8);color:var(--tv-meta,#5C4632)}
  .mo-st.turn{background:var(--tv-sage,#8FBCA8);color:#1F3B30}.mo-st.completed{background:#E8F2EC;color:#2F5D4A}.mo-st.disputed{background:#FEE2E2;color:var(--tv-crimson,#991B1B)}
  .mo-who{font-size:.82rem;color:var(--tv-meta,#5C4632)}.mo-who a{color:var(--tv-link,#92400E);text-decoration:underline}
  .mo-say{font-size:.84rem;color:var(--tv-ink,#3E2B1F);margin:.2rem 0 .35rem}
  .mo-acts{display:flex;flex-wrap:wrap;gap:.3rem}
  .mo-b{font:inherit;font-size:.8rem;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;padding:.25rem .75rem;background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);cursor:pointer;font-weight:600}
  .mo-b.go{background:var(--tv-umber,#3E2B1F);border-color:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2)}.mo-b.ok{background:var(--tv-sage,#8FBCA8);border-color:var(--tv-sage,#8FBCA8);color:#1F3B30}
  @media (max-width:767px){.mk-grid{gap:3px;grid-template-columns:repeat(2,minmax(0,1fr))}.mk-card{border-radius:.5rem}
    .ta-work .mk-grid{margin-left:calc(3px - var(--tv-pad));margin-right:calc(3px - var(--tv-pad))}.ta-work .mk-grid>.mk-card.mk-card{margin-left:0;margin-right:0}}   /* the grid runs edge to edge, not each card (they overlapped) */
</style>';
}

/** A post's card. $c from Market::card(); $saved: the viewer saved it; $save: show the Save button. */
function tv_market_card(array $c, bool $saved = false, bool $save = true): string
{
    $ph = tv_icon('store') . ($c['photo'] !== '' ? '<img src="' . tv_e($c['photo']) . '" alt="" loading="lazy">' : '');   // the icon under the photo shows if it can't load
    $tag = !empty($c['test']) ? '<span class="mk-tag" style="background:#B45309">Test' . ($c['status'] !== 'active' ? ' · ' . tv_e($c['status_label']) : '') . '</span>'
        : ($c['status'] !== 'active' ? '<span class="mk-tag">' . tv_e($c['status_label']) . '</span>' : '');
    $sv = $save ? '<button type="button" class="mk-save" data-mk-save="' . (int) $c['id'] . '" aria-pressed="' . ($saved ? 'true' : 'false') . '" title="' . ($saved ? 'Saved' : 'Save') . '" aria-label="' . ($saved ? 'Saved: tap to unsave' : 'Save') . '">' . tv_icon('bookmark') . '</button>' : '';
    $tagText = !empty($c['kind_name']) && ($c['kind'] ?? 'physical') !== 'physical' ? (string) $c['kind_name'] : (string) ($c['category'] ?? '');   // a business item's kind when it isn't plain goods (decisions/0141 §5), else its category
    $cat = $tagText !== '' ? '<span class="mk-cat">' . tv_e($tagText) . '</span>' : '';   // its category, on the photo (the landing, 2026-11-03)
    return '<article class="mk-card tv-bleed"><a class="mk-ph" href="' . tv_e($c['url']) . '" tabindex="-1" aria-hidden="true">' . $ph . $cat . '</a>' . $tag . $sv
        . '<div class="mk-b"><div class="mk-price">' . tv_e($c['price']) . '</div><a class="mk-name" href="' . tv_e($c['url']) . '">' . tv_e($c['title']) . '</a>'
        . (!empty($c['biz']) ? '<div class="mk-m mk-biz">' . tv_icon('store') . tv_e($c['biz']) . '</div>' : '')
        . '<div class="mk-m">' . tv_e(trim($c['place'] . (isset($c['miles']) ? ' · ' . ($c['miles'] < 1 ? 'here' : $c['miles'] . ' mi') : '') . ($c['ago'] !== '' ? ' · ' . $c['ago'] : ''), ' ·')) . '</div></div></article>';
}

/**
 * One offer, as the person looking at it sees it (MarketOffers::view): the amount, where it stands, what they can do.
 * $title: the post's name and link (on Your Marketplace, where offers from several posts are listed together).
 */
function tv_market_offer(array $v, bool $title = false, string $target = ''): string
{
    $go = ['accept' => 'ok', 'sold' => 'ok', 'got_it' => 'ok', 'counter' => '', 'note' => 'go'];
    $h = '<div class="mo" id="offer-' . (int) $v['id'] . '"><div class="mo-top"><span class="mo-amt">' . tv_e($v['amount']) . '</span>'
        . '<span class="mo-st ' . ($v['turn'] && in_array($v['status'], ['asked', 'countered', 'accepted'], true) ? 'turn' : tv_e($v['status'])) . '">' . tv_e($v['turn'] && in_array($v['status'], ['asked', 'countered', 'accepted'], true) ? 'Your turn' : $v['status_label']) . '</span>'
        . '<span class="mo-who">' . ($title ? '<a href="' . tv_e($v['url']) . '"' . $target . '>' . tv_e($v['title']) . '</a> · ' : '') . ($v['role'] === 'seller' ? 'from ' : 'to ') . tv_e($v['other']) . '</span></div>'
        . '<p class="mo-say">' . tv_e($v['say']) . '</p>'
        . (($v['payhow'] ?? '') !== '' ? '<p class="mo-say" data-tv-status="info" data-tv-label="How they take payment:">' . tv_e($v['payhow']) . ' Pay only when you meet: these have no buyer protection.</p>' : '');
    if ($v['acts']) {
        $h .= '<div class="mo-acts">';
        foreach ($v['acts'] as [$k, $label]) $h .= '<button type="button" class="mo-b ' . ($go[$k] ?? '') . '" data-mo="' . tv_e($k) . '" data-offer="' . (int) $v['id'] . '" data-amount="' . tv_e($v['amount_raw']) . '">' . tv_e($label) . '</button>';
        $h .= '</div>';
    }
    return $h . '</div>';
}

/** The Save buttons' script (one per page): signed out goes to sign-in. */
function tv_market_js(): string
{
    static $done = false;
    if ($done) return '';
    $done = true;
    return '<script>
document.addEventListener("error", function (e) { var t = e.target; if (t && t.tagName === "IMG" && t.parentNode && t.parentNode.classList && t.parentNode.classList.contains("mk-ph")) t.remove(); }, true);   // a photo that won\'t load: the icon under it shows
(function () {
  var tok = null;
  function csrf() { if (tok) return tok; var m = document.querySelector(\'meta[name="csrf-token"]\'); tok = m && m.content ? Promise.resolve(m.content) : fetch("/api/auth/session.php", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (d) { return (d && d.csrf_token) || ""; }); return tok; }
  window.tvMarketPost = function (body) {
    return csrf().then(function (t) { return fetch("/api/market.php", { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", "X-CSRF-Token": t }, body: JSON.stringify(window.tvSafe ? tvSafe(body) : body) }); })
      .then(function (r) { return r.json().then(function (d) { if (r.status === 401) { location.href = "/login.php?next=" + encodeURIComponent(location.pathname + location.search); throw new Error("Sign in first."); } if (!d.ok) throw new Error((d.error && d.error.message) || "That didn\'t work. Try again."); return d; }); });
  };
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-mk-save]"); if (!b) return;
    e.preventDefault(); b.disabled = true;
    tvMarketPost({ action: "save", id: +b.getAttribute("data-mk-save") }).then(function (d) {
      document.querySelectorAll(\'[data-mk-save="\' + b.getAttribute("data-mk-save") + \'"]\').forEach(function (x) { x.setAttribute("aria-pressed", d.saved ? "true" : "false"); x.title = d.saved ? "Saved" : "Save"; x.setAttribute("aria-label", d.saved ? "Saved: tap to unsave" : "Save"); var t = x.querySelector("[data-mk-save-t]"); if (t) t.textContent = d.saved ? "Saved" : "Save"; });
    }).catch(function (x) { if (window.TvAsk) TvAsk.say(x.message, { anchor: b, bad: true }); }).then(function () { b.disabled = false; });
  });
  // offers (decisions/0135 §4): each button moves the offer; counters, problems and notes ask for a word first
  var ASK = { counter: ["Your counter, in dollars", "amount"], problem: ["What went wrong? Our team reads this and writes to you both.", "note", true], note: ["How did it go? A short note others see on their posts.", "body", true],
              decline: ["A word to them? (optional)", "note"], call_off: ["Why it\'s off? (optional, they see it)", "note"] };
  var GATE = { decline: ["Decline this offer?", "Decline"], call_off: ["Call off the deal? The post shows as available again.", "Call it off"] };
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-mo]"); if (!b) return;
    var what = b.getAttribute("data-mo"), id = +b.getAttribute("data-offer");
    if (GATE[what] && !TvAsk.gate(b, GATE[what][0], { yes: GATE[what][1], danger: true })) return;
    var go = function (extra) {
      b.disabled = true;
      var body = what === "note" ? { action: "note", offer: id } : { action: "offer_act", offer: id, what: what };
      for (var k in extra) body[k] = extra[k];
      tvMarketPost(body).then(function (d) { TvAsk.say(d.message, { anchor: b }); setTimeout(function () { location.reload(); }, 1000); })
        .catch(function (x) { TvAsk.say(x.message, { anchor: b, bad: true }); b.disabled = false; });
    };
    var a = ASK[what];
    if (!a) return go({});
    TvAsk.ask(a[0], what === "counter" ? (b.getAttribute("data-amount") || "") : "", { anchor: b, multiline: !!a[2] }).then(function (v) {
      if (v === null) return; var x = {}; x[a[1]] = v; go(x);
    });
  });
})();
</script>';
}
