<?php
// app/admin/index-console.php — Insights → The index (W0): W0 Indexer's frontier (decisions/0164 §1.4's note of
// 2026-11-17). Whether it runs and why not, its last check-in from Railway, the frontier's size and growth (for the
// pre-flight), its states and verdicts, sites that blocked us (Reactivate), skip rules, the last verdicts with Undo, and
// a URL looked up with a person's verdict on it (an override, never a gate). Times show where they happened (each <time>
// is drawn in the viewer's zone by js/tv-time.js).
declare(strict_types=1);

function tv_admin_mod_index(PDO $pdo): string
{
    require_once __DIR__ . '/../lib/crawler/Frontier.php';
    $e = 'tv_w_e';
    if (!Frontier::ready($pdo)) return '<p data-tv-status="info" data-tv-label="Not ready:">The frontier\'s database update hasn\'t run yet: it runs within the hour, or open System Configuration → Database updates.</p>';
    Frontier::ensureWorkflow($pdo);
    [$can, $why] = Access::can('insights.index.edit', ['min' => 'staff', 'depts' => ['ops']]);
    $uid = (int) (Auth::currentUserId() ?? 0);
    $me = Auth::currentUser(); $who = (string) ($me['display_name'] ?? '');
    $csrf = (string) ($_SESSION['csrf_token'] ?? ''); $msg = ''; $q = '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['ix_do']) && hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        $q = trim((string) ($_POST['url'] ?? ''));   // a lookup goes by POST, so the link travels wrapped past ModSecurity (tv-ask.js)
        if ($_POST['ix_do'] !== 'lookup') try {
            if (!$can) throw new RuntimeException($why);
            switch ((string) $_POST['ix_do']) {
                case 'undo': $say = Frontier::undo($pdo, (int) ($_POST['id'] ?? 0), $uid, $who); break;
                // Reactivate moved to W0's page on the board (decisions/0176 R3; Jason, 2026-11-20): one place to act
                case 'verdict':
                    $v = (string) ($_POST['v'] ?? '');
                    $id = Frontier::verdict($pdo, (string) ($_POST['subject'] ?? 'url'), (string) ($_POST['ref'] ?? ''), $v, 'A person\'s call' . (trim((string) ($_POST['why'] ?? '')) !== '' ? ': ' . trim((string) $_POST['why']) : '') . '.', 'person', $uid, $who);
                    $say = $id ? 'Marked ' . strtolower(Frontier::VERDICTS[$v] ?? $v) . ' (with Undo below).' : 'Nothing changed: it was already so.';
                    break;
                case 'rule_off':
                    $pdo->prepare('UPDATE ' . Database::t('crawl_skip_rules') . ' SET active = 0 WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]);
                    Frontier::audit($pdo, 'rule', (string) (int) ($_POST['id'] ?? 0), 'rule_off', 'active', 'off', 'Switched off by ' . ($who !== '' ? $who : 'a person') . '.', 'person', $uid, $who);
                    $say = 'The rule is off: what it matched is logged again when it\'s found.';
                    break;
                default: throw new RuntimeException('Unknown action.');
            }
            $msg = '<p data-tv-flash="ok">' . $e($say) . '</p>';
        } catch (Throwable $x) { $msg = '<p data-tv-flash="error">' . $e($x->getMessage()) . '</p>'; }
    }
    $at = fn (?string $t) => $t ? '<time datetime="' . $e(date('c', (int) strtotime($t))) . '" data-tv-time>' . $e(date('M j, g:i a', (int) strtotime($t))) . '</time>' : 'never';
    $btn = function (string $do, string $label, array $hidden, string $confirm = '', bool $danger = false) use ($e, $can, $why, $csrf): string {
        $h = '<form method="post" style="display:inline"><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="ix_do" value="' . $e($do) . '">';
        foreach ($hidden as $k => $v) $h .= '<input type="hidden" name="' . $e($k) . '" value="' . $e((string) $v) . '">';
        if (isset($hidden['ref']) && ($u = trim((string) ($_POST['url'] ?? ''))) !== '') $h .= '<input type="hidden" name="url" value="' . $e($u) . '">';
        return $h . '<button class="ak-b" type="submit"' . ($can ? '' : ' disabled title="' . $e($why) . '"') . ($confirm !== '' ? ' data-confirm="' . $e($confirm) . '" data-yes="' . $e($label) . '"' . ($danger ? ' data-danger' : '') : '') . '>' . $e($label) . '</button></form>';
    };

    $h = '<p class="ak-note">W0 Indexer is Phase 1\'s engine (decisions/0164 §1.4): every link on every page read is logged here, on the same site or another, and every new site is classified by the machine. '
       . 'Logging isn\'t reading: a URL is read only where the rules allow (Read regularly, robots.txt, a polite pace, never Facebook or Instagram, a nation\'s site only when a person says). '
       . 'What later steps learn comes back as a verdict (promoted, normal, demoted, junk); junk is kept as its hash, so it\'s never logged or read twice. A person\'s call overrides, never gates.' . ($can ? '' : ' <b>' . $e($why) . '</b>') . '</p>' . $msg;

    // whether it runs, and its last check-in
    $off = Frontier::off($pdo); $beat = Frontier::lastBeat($pdo);
    $h .= $off !== null ? '<p data-tv-status="info" data-tv-label="Not indexing:">' . $e($off) . ' Switch W0 on at <a class="underline" href="/admin/config/automation">System Configuration → Automation</a> (Start the system starts it first).</p>'
                        : '<p data-tv-status="ok" data-tv-label="On:">W0 hands out work and takes batches.</p>';
    if (!empty($beat['at'])) {
        $late = (int) $beat['at'] < time() - 900;
        $h .= '<p data-tv-status="' . ($late ? 'bad' : 'ok') . '" data-tv-label="' . ($late ? 'Not heard from:' : 'Last check-in:') . '"><time datetime="' . $e(gmdate('c', (int) $beat['at'])) . '" data-tv-time>' . $e(gmdate('M j, H:i', (int) $beat['at'])) . ' UTC</time>'
            . ' from the indexer ' . $e((string) ($beat['v'] ?? '')) . ': batch ' . (int) ($beat['batch'] ?? 0) . ', one every ' . $e((string) ($beat['gap'] ?? '')) . ' s, ' . number_format((int) ($beat['queue'] ?? 0)) . ' waiting to send'
            . ((int) ($beat['mismatches'] ?? 0) ? ', ' . (int) $beat['mismatches'] . ' receipt(s) in a row didn\'t match' : '') . (($beat['note'] ?? '') !== '' ? ' (' . $e((string) $beat['note']) . ')' : '') . '.</p>';
    } else $h .= '<p data-tv-status="info" data-tv-label="No check-in yet:">The indexer\'s service on Railway hasn\'t checked in. Once it\'s deployed it checks in every minute, and sleeps while W0 is off.</p>';

    // the numbers
    $s = Frontier::size($pdo); $b = Frontier::budget($pdo); $held = Frontier::heldSites($pdo, 100);
    $h .= '<div class="ak-metrics">';
    foreach ([['URLs logged', number_format($s['rows'])], ['Sites', number_format($s['sites'])], ['New today', number_format($s['day'])], ['New this week', number_format($s['week'])], ['Junk (kept as a hash)', number_format($s['junk'])],
              ['Compressed (hash only)', number_format($s['compressed'])], ['On disk', number_format($s['mb'], 1) . ' MB'], ['Sites that blocked us', count($held)], ['Railway this month', '$' . number_format($b['used'], 2) . ' of $' . number_format($b['cap'], 2)]] as [$l, $v])
        $h .= '<div class="ak-metric tv-bleed"><b>' . $e((string) $v) . '</b><span>' . $e($l) . '</span></div>';
    $h .= '</div>';

    // states and verdicts
    $body = '<div class="ak-aa"><table><thead><tr><th>Where URLs stand</th><th>How many</th></tr></thead><tbody>';
    foreach (Frontier::STATES as $k => $l) $body .= '<tr><td>' . $e($l) . '</td><td>' . number_format((int) ($s['by_state'][$k] ?? 0)) . '</td></tr>';
    foreach (Frontier::VERDICTS as $k => $l) if ($k !== 'junk') $body .= '<tr><td>Verdict: ' . $e($l) . '</td><td>' . number_format((int) ($s['by_verdict'][$k] ?? 0)) . '</td></tr>';
    $body .= '<tr><td>Verdict: Junk (kept as a hash)</td><td>' . number_format($s['junk']) . '</td></tr></tbody></table></div>';
    $g = Frontier::growth($pdo);
    if ($g) {
        $body .= '<div class="ak-aa"><table><thead><tr><th>Day</th><th>URLs</th><th>Junk</th><th>Size</th></tr></thead><tbody>';
        foreach (array_slice(array_reverse($g, true), 0, 14, true) as $d => $r) $body .= '<tr><td>' . $e((string) $d) . '</td><td>' . number_format((int) $r['rows']) . '</td><td>' . number_format((int) $r['junk']) . '</td><td>' . number_format((float) $r['mb'], 1) . ' MB</td></tr>';
        $body .= '</tbody></table></div>';
    }
    $h .= tv_admin_fold('The frontier', number_format($s['rows']) . ' URLs · ' . number_format($s['mb'], 1) . ' MB', 'info', '', $body, false);

    // look up a URL, and a person's verdict on it
    $body = '<form method="post" class="ak-note"><input type="hidden" name="csrf" value="' . $e($csrf) . '"><input type="hidden" name="ix_do" value="lookup"><label>A URL <input class="ak-in" type="url" name="url" value="' . $e($q) . '" style="width:min(36rem,100%)" spellcheck="false"></label> <button class="ak-b" type="submit">Look it up</button></form>';
    if ($q !== '') {
        $n = Frontier::normalize($q);
        if ($n === null) $body .= '<p data-tv-status="bad" data-tv-label="Not a web address:">' . $e($q) . '</p>';
        else {
            $hash = Frontier::hash($n);
            $st = $pdo->prepare('SELECT * FROM ' . Database::t('crawl_frontier') . ' WHERE url_hash = ?'); $st->execute([$hash]); $r = $st->fetch(PDO::FETCH_ASSOC);
            $j = $pdo->prepare('SELECT * FROM ' . Database::t('crawl_junk') . ' WHERE url_hash = ?'); $j->execute([$hash]); $jr = $j->fetch(PDO::FETCH_ASSOC);
            if (!$r && !$jr) $body .= '<p data-tv-status="info" data-tv-label="Not logged yet:">' . $e($n) . ' hasn\'t been found on any page we read.</p>';
            elseif ($jr) $body .= '<p data-tv-status="info" data-tv-label="Junk:">' . $e($n) . ': ' . $e(Frontier::REASONS[$jr['reason']] ?? (string) $jr['reason']) . ', since ' . $at((string) $jr['at']) . '. ' . $btn('verdict', 'Not junk', ['subject' => 'url', 'ref' => $hash, 'v' => 'normal']) . '</p>';
            else {
                $body .= '<p data-tv-status="info" data-tv-label="' . $e(Frontier::VERDICTS[$r['verdict']] ?? $r['verdict']) . ':">' . $e($n) . ' · ' . $e(Frontier::STATES[$r['state']] ?? $r['state']) . ($r['reason'] ? ' (' . $e((string) $r['reason']) . ')' : '')
                       . ' · found ' . $at((string) $r['first_at']) . ', ' . number_format((int) $r['links_in']) . ' page(s) link to it, ' . (int) $r['depth'] . ' link(s) from a trusted source, priority ' . (int) $r['priority'] . ($r['link_text'] ? ' · its link said "' . $e((string) $r['link_text']) . '"' : '') . '.</p><p class="ak-note">';
                foreach (Frontier::VERDICTS as $v => $l) if ($v !== $r['verdict']) $body .= $btn('verdict', $l, ['subject' => 'url', 'ref' => $hash, 'v' => $v], $v === 'junk' ? 'Mark it junk? It\'s never read, and recognised when found again (Undo below).' : '', $v === 'junk') . ' ';
                $body .= '</p>';
            }
        }
    }
    $h .= tv_admin_fold('Look up a URL', 'A person\'s verdict overrides the machine\'s', 'info', '', $body, $q !== '');

    // sites that blocked us
    $body = $held ? '<div class="ak-aa"><table><thead><tr><th>Site</th><th>What it answered</th><th>Since</th><th></th></tr></thead><tbody>' : '<p class="ak-note">None: no site has blocked the indexer.</p>';
    require_once __DIR__ . '/../lib/EngineCase.php';
    // each site's own line; its Reactivate is on W0's page on the board, the one place to act (decisions/0176 §5, 0175 §6; Jason, 2026-11-20)
    require_once __DIR__ . '/../lib/ControlAlarms.php';
    foreach ($held as $r) $body .= '<tr id="' . $e(ControlAlarms::heldAnchor((string) $r['host'])) . '"><td>' . $e((string) $r['host']) . '</td><td>' . $e(EngineCase::blockReason((string) $r['held_why'])) . '<br><small>' . $e((string) $r['held_why']) . '</small></td><td>' . $at((string) $r['held_at']) . '</td><td>' . '<a class="ak-b" href="/admin/config/control/wf-W0#' . $e(ControlAlarms::heldAnchor((string) $r['host'])) . '" data-peek-frame="W0 Indexer">Reactivate on W0\'s page</a>' . '</td></tr>';
    if ($held) $body .= '</tbody></table></div><p class="ak-note">A site that blocks us (a sign-in wall, 403, 406 or 451, a challenge) is never retried by itself (decisions/0164 §1.2, 5). Reactivate is on W0\'s page on the board, with its alarms.</p>';
    $h .= '<div id="held">' . tv_admin_fold('Sites that blocked us', count($held) ? count($held) . ' held' : 'None', count($held) ? 'info' : 'ok', '', $body, false) . '</div>';   // #held: the view; each site's Reactivate is on W0's page on the board

    // skip rules
    $rules = Frontier::rules($pdo, 50);
    $body = $rules ? '<div class="ak-aa"><table><thead><tr><th>Site</th><th>Skips</th><th>Why</th><th>Skipped</th><th>Made</th><th></th></tr></thead><tbody>' : '<p class="ak-note">None yet: junk seen 25 times in a week with the same pattern on one site becomes a rule.</p>';
    foreach ($rules as $r) $body .= '<tr><td>' . $e((string) $r['site']) . '</td><td><code>' . $e((string) $r['pattern']) . '</code></td><td>' . $e(Frontier::REASONS[$r['reason']] ?? (string) $r['reason']) . '</td><td>' . number_format((int) $r['hits']) . '</td><td>' . $at((string) $r['at']) . ' by the ' . $e((string) $r['made_by']) . '</td><td>'
        . ((int) $r['active'] ? $btn('rule_off', 'Switch off', ['id' => $r['id']], 'Switch the rule off? What it matched is logged again when found.') : 'Off') . '</td></tr>';
    if ($rules) $body .= '</tbody></table></div>';
    $h .= tv_admin_fold('Skip rules', count(array_filter($rules, fn ($r) => (int) $r['active'])) . ' on', 'info', '', $body, false);

    // the audit log: the last verdicts, calls and holds, with Undo
    $log = Frontier::history($pdo, 40);
    $body = $log ? '<div class="ak-aa"><table><thead><tr><th>When</th><th>What</th><th>Change</th><th>Why</th><th>By</th><th></th></tr></thead><tbody>' : '<p class="ak-note">Nothing yet.</p>';
    foreach ($log as $a) {
        $what = $a['subject'] === 'url' ? ($a['url'] ? mb_strimwidth((string) $a['url'], 0, 80, '…') : 'a URL (' . substr((string) $a['ref'], 0, 10) . '…)') : (string) $a['ref'];
        $undo = empty($a['undone_at']) && in_array($a['action'], ['verdict', 'hold', 'skip_rule'], true) ? $btn('undo', 'Undo', ['id' => $a['id']], 'Undo this? It goes back as it was, and the undo is logged.') : (!empty($a['undone_at']) ? 'Undone' : '');
        $body .= '<tr><td>' . $at((string) $a['at']) . '</td><td><small>' . $e($a['subject'] . ': ' . $what) . '</small></td><td>' . $e(trim(($a['was'] ?? '') . ' → ' . ($a['now_is'] ?? ''), ' →')) . '</td><td><small>' . $e((string) $a['reason']) . ' <em>' . $e((string) $a['rule']) . '</em></small></td><td>' . $e((string) ($a['by_name'] ?: ((int) $a['by_uid'] ? 'a person' : 'the machine'))) . '</td><td>' . $undo . '</td></tr>';
    }
    if ($log) $body .= '</tbody></table></div>';
    $h .= tv_admin_fold('Verdicts and calls', count($log) . ' latest', 'info', '', $body, false);

    $h .= '<p class="ak-note">Sites and their calls (Read regularly, Cite only, Ignore) are on <a class="underline" href="/admin/insights/sources">Insights → Sources</a>; its batches\' sizes and pace on <a class="underline" href="/admin/config/thresholds">Thresholds</a>; its budget line on <a class="underline" href="/admin/config/register#svc-railway">the Service register</a>.</p>';
    return '<div>' . $h . '</div><style>.ak-aa{overflow-x:auto;margin:.6rem 0}.ak-aa table{width:100%;border-collapse:collapse;font-size:.85rem}.ak-aa th,.ak-aa td{padding:.35rem .5rem;border-bottom:1px solid #E8DCC6;text-align:left;vertical-align:top}</style>';
}
