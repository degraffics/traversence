<?php
// app/lib/EnvSettings.php — the plain settings that can be changed from Settings instead of in .env (decisions/0125).
// Jason, 2026-10-24, asked to change .env without File Manager. The settings listed here aren't secret. Secrets go
// through one writer, setKey() (decisions/0167 §4, extended to every service's key by 0173 §3): the Founder only, never
// on staging, never shown back or logged (the log names who, when and which key), the old value kept until its Check
// passes; nothing reads a secret back out to a page. Each change is checked, the file before it is kept (.env.bak-<when>, the last 5), the new file goes
// in whole (written beside it, then swapped), and the action log records who changed what.
declare(strict_types=1);

require_once __DIR__ . '/Database.php';

final class EnvSettings
{
    /** key => [label, what it does, kind]. kind: url-aws | region | bucket | url | money | email | text | phone */
    public const EDITABLE = [
        'AWS_CONSOLE_URL' => ['AWS sign-in link', 'Where the AWS cards\' "Sign in" goes: the account\'s own sign-in page, like https://trvgo.signin.aws.amazon.com/console.', 'url-aws'],
        'AWS_REGION' => ['AWS region', 'Where the bucket and Textract are, like us-east-2. Changing it points the site at another region: only if the bucket moved.', 'region'],
        'S3_BUCKET' => ['S3 bucket', 'The bucket every file is kept in. Changing it points the site at another bucket: files already in the old one aren\'t moved.', 'bucket'],
        'S3_PUBLIC_BASE' => ['Public photo address', 'Optional: a CloudFront address (or the bucket\'s own, once public photos are open) that photos load from directly. Empty: signed links.', 'url'],
        // flat monthly plans, counted in Outside services' monthly total (decisions/0152)
        'RAILWAY_USD_MONTH' => ['Railway plan, a month', 'Dollars a month for Railway, where the crawler worker runs (Hobby: 5).', 'money'],
        'BLUEHOST_USD_MONTH' => ['Bluehost plan, a month', 'Dollars a month for the web hosting plan (a yearly bill divided by 12).', 'money'],
        'COMMUNITY_BUDGET_PCT' => ['Community budget share', 'Percent of last month\'s revenue that pays for free members\' Moments (decisions/0154 §4). Default 3. At 100% of it, free accounts\' video Moments pause until the 1st.', 'money'],
        'COMMUNITY_BUDGET_FLOOR_USD' => ['Community budget floor', 'The least the community budget is in a month, in dollars, whatever the revenue. Default 25.', 'money'],
        'SMTP_FROM_NAME' => ['Email sender name', 'The name the site\'s emails come from.', 'text'],
        'SMTP_FROM_EMAIL' => ['Email sender address', 'The address the site\'s emails come from (it must be one the mail server may send as).', 'email'],
        'BUSINESS_POSTAL_ADDRESS' => ['Postal address', 'Printed at the foot of marketing emails, as the law asks.', 'text'],
        'CLAIM_VERIFY_NUMBER' => ['Claims phone number', 'The number businesses call to verify a claim.', 'phone'],
        'ORDERS_FROM_EMAIL' => ['Orders email', 'The system address work orders go to vendors from, like orders@trvgo.us. It only sends: replies, and vendors\' updates (accepted, ready, shipped…), go to the Orders reply-to. The mail server must be allowed to send as it (its own login, if it has one, stays in .env).', 'email'],
        'ORDERS_FROM_NAME' => ['Orders sender name', 'The name work orders come from, like Traversence Orders.', 'text'],
        'ORDERS_REPLY_TO' => ['Orders reply-to', 'Where vendors\' replies and their work order updates go. Empty: support@traversence.com.', 'email'],
        'SMTP_REPLY_TO' => ['Reply-to for site emails', 'Where replies to the site\'s system emails (donotreply@…) go. Empty: support@traversence.com.', 'email'],
        // Communications (decisions/0167 §1): each sender's server and login, and requests@ for visitors' requests to unclaimed
        // listings (0172 §3.3). Edited on its sender's card in System Configuration → Communications; passwords never here.
        'SMTP_HOST' => ['Mail server', 'The server the system sender signs in to, like mail.traversence.com (Bluehost: cPanel → Email Accounts → Connect Devices).', 'text'],
        'SMTP_PORT' => ['Mail server port', '587 (STARTTLS) or 465 (SSL).', 'text'],
        'SMTP_USERNAME' => ['Mailbox it signs in with', 'The system sender\'s mailbox, like donotreply@traversence.com.', 'email'],
        'ORDERS_SMTP_HOST' => ['Orders mail server', 'Only when orders@ signs in on its own. Empty: the system sender\'s server.', 'text'],
        'ORDERS_SMTP_PORT' => ['Orders mail server port', 'Empty: the system sender\'s port.', 'text'],
        'ORDERS_SMTP_USERNAME' => ['Orders mailbox it signs in with', 'Like orders@trvgo.us. Empty: it sends through the system sender\'s mailbox.', 'email'],
        'REQUESTS_FROM_EMAIL' => ['Requests sender address', 'Visitors\' requests to unclaimed listings come from this address, like requests@traversence.com: its own sender, so a complaint never touches sign-in codes or receipts (decisions/0172 §3.3).', 'email'],
        'REQUESTS_FROM_NAME' => ['Requests sender name', 'Like "Traversence visitor requests".', 'text'],
        'REQUESTS_REPLY_TO' => ['Requests reply-to', 'Empty: each request carries its own reply address, so the business\'s answer comes back to the visitor.', 'email'],
        'REQUESTS_SMTP_HOST' => ['Requests mail server', 'Empty: the system sender\'s server.', 'text'],
        'REQUESTS_SMTP_PORT' => ['Requests mail server port', 'Empty: the system sender\'s port.', 'text'],
        'REQUESTS_SMTP_USERNAME' => ['Requests mailbox it signs in with', 'Like requests@traversence.com. Empty: it sends through the system sender\'s mailbox.', 'email'],
        'GMAIL_ASSESSMENT_USD' => ['Google\'s yearly mail assessment', 'What Google\'s yearly security assessment costs, in dollars, before Sign in with Google may read mail (decisions/0172 §4.7). Default 15000. It switches on only when a year\'s revenue covers it.', 'money'],
        'WIRE_VERIFY_PHONE' => ['Wire check phone number', 'The number a client calls to confirm our wire details before sending money.', 'phone'],
        // Traversence's identity in its legal texts (decisions/0142 §1): the Terms, Privacy Policy and Seller Agreement fill from these
        'LEGAL_NAME' => ['Legal name (Terms and policies)', 'The name the Terms, Privacy Policy and Seller Agreement give for Traversence. Empty: Traversence.com, until the legal entity\'s formal name is set.', 'text'],
        'LEGAL_ADDRESS' => ['Legal address (Terms and policies)', 'The mailing address in the legal texts. Empty: PO Box 3570, Saint Johns, AZ 85936.', 'text'],
        'LEGAL_EMAIL' => ['Legal contact email', 'Where the legal texts send questions. Empty: support@traversence.com.', 'email'],
        'LEGAL_PHONE' => ['Phone for reporting a listing', 'Shown on every Marketplace item, as the INFORM Consumers Act requires a way to report suspicious activity by phone as well as online. Empty: only the Report button shows.', 'phone'],
        'LEGAL_STATE' => ['Governing law (state)', 'The state whose laws govern the Terms. Empty: Arizona.', 'text'],
        'LEGAL_COUNTY' => ['Disputes go to (county)', 'The county whose courts hear disputes. Empty: Apache County.', 'text'],
        'DOMAIN_SALES_MODE' => ['Domain sales', 'Finding and buying domains, its own process (decisions/0169 §1a; Jason, 2026-11-17): Shop → Domains, the Domains tab\'s buying, renewals and auto-renew, and the wallet\'s domain charges. off (it says "opens soon"; unset is off), test (only our team sees it; Name.com\'s and QuickBooks\' sandboxes, no real money) or live (everyone; real charges, refused while Name.com is on its sandbox).', 'domains-mode'],
        'DOMAINS_MODE' => ['Own domains on storefronts', 'Connect your domain on a storefront only (decisions/0139), not domain sales: off (it says "opens soon"), test (only our team sees it; the real edge, Name.com\'s sandbox, no card charged) or live (businesses on Core and up; real charges).', 'domains-mode'],
        'NAMECOM_ENV' => ['Name.com: sandbox or live', 'Where domains are bought: sandbox (test registrations, nothing real) or live. Either switch\'s test mode, a test account and the staging copy always use the sandbox. Its username and token for each stay in .env.', 'namecom-env'],
        'CLIENT_PAY_WAYS' => ['Ways clients can pay', 'Besides a card, what a client can choose at checkout on an order we prepare: wire, check, cash (comma between). Empty: card only. The bank details stay in .env, set by hand.', 'payways'],
    ];

    /**
     * The settings with set answers: each answer and what it does, offered as choices on Edit (TvAsk.choose), never a
     * blank box you must know the answer to (Jason, 2026-11-17). [key => [[value, name, what it does], …]].
     */
    public static function choices(string $key): array
    {
        switch ($key) {
            case 'DOMAIN_SALES_MODE': return [
                ['off', 'Off', 'Shop → Domains says "opens soon". Nothing is searched, sold or auto-renewed here; domains already bought stay registered until their date, and their contact confirmations are still followed.'],
                ['test', 'Test', 'Only our team sees Shop → Domains. Searches and purchases go to Name.com\'s sandbox (test registrations) and pay from the test wallet in QuickBooks\' sandbox: no real money.'],
                ['live', 'Live', 'Everyone can find and buy domains, with real charges. Needs Name.com on Live too.']];
            case 'DOMAINS_MODE': return [
                ['off', 'Off', 'A storefront\'s Your own domain says "opens soon".'],
                ['test', 'Test', 'Only our team sees Your own domain on storefronts: the real edge, Name.com\'s sandbox for buying, no card charged.'],
                ['live', 'Live', 'Businesses on Core and up can put their storefront on their own domain, with real charges for one bought through us.']];
            case 'NAMECOM_ENV': return [
                ['sandbox', 'Sandbox', 'Test registrations, nothing real. Every test (test modes, test accounts, staging) uses it whatever this says.'],
                ['live', 'Live', 'Real registrations and real charges, for whatever is switched to Live.']];
            case 'CLIENT_PAY_WAYS': return [
                ['wire', 'Wire', 'A bank wire to the details in .env.'],
                ['check', 'Check', 'A mailed check.'],
                ['cash', 'Cash', 'Cash in person.']];
        }
        return [];
    }

    /** How the value reads on the page: a choice's name ("Test"; "Off (not set)" when unset), else the value. */
    public static function shown(string $key): string
    {
        $v = self::value($key); $c = self::choices($key);
        if (!$c) return $v;
        $names = [];
        foreach (array_filter(array_map('trim', explode(',', self::current($key)))) as $x) foreach ($c as [$cv, $cn]) if ($cv === $x) $names[] = $cn;
        $t = implode(', ', $names);
        return $v === '' ? ($t !== '' ? $t . ' (not set)' : '') : ($t !== '' ? $t : $v);
    }

    /** The Edit button's data: its choices (JSON), several or one, and the value it acts as now. */
    public static function editAttrs(string $key): string
    {
        $e = fn ($x) => htmlspecialchars((string) $x, ENT_QUOTES, 'UTF-8');
        $c = self::choices($key);
        if (!$c) return ' data-value="' . $e(self::value($key)) . '"';
        return ' data-value="' . $e(self::current($key)) . '" data-env-choices="' . $e(json_encode($c)) . '"' . (self::multi($key) ? ' data-multi' : '');
    }

    /** Several may be ticked (CLIENT_PAY_WAYS); else one. */
    public static function multi(string $key): bool { return $key === 'CLIENT_PAY_WAYS'; }

    /** The value as it acts now: an unset mode is Off, an unset Name.com is its sandbox. */
    public static function current(string $key): string
    {
        $v = strtolower(self::value($key));
        if ($v === '' && in_array($key, ['DOMAIN_SALES_MODE', 'DOMAINS_MODE'], true)) return 'off';
        if ($v === '' && $key === 'NAMECOM_ENV') return 'sandbox';
        return $key === 'CLIENT_PAY_WAYS' ? $v : self::value($key);
    }

    /**
     * What to do next, once a setting is saved: whether the thing it switches on now works for the person who saved it,
     * and the step that finishes the job as a button: [text, kind 'go'|'set'|'do'|'', label, href or [key, value] or
     * action, bad?] (Jason, 2026-11-17: "intuitive processing for action steps … start to finish"). Empty: nothing more.
     */
    public static function next(PDO $pdo, int $uid, string $key, string $value): array
    {
        try {
            if ($key === 'DOMAIN_SALES_MODE' || ($key === 'NAMECOM_ENV' && self::current('DOMAIN_SALES_MODE') !== 'off')) {
                require_once __DIR__ . '/AccountDomains.php';
                $m = AccountDomains::mode();
                if ($m === 'off') return ['Domain sales are off: Shop → Domains says "opens soon".', '', '', '', false];
                if ($m === 'live' && self::current('NAMECOM_ENV') !== 'live')
                    return ['Domain sales are Live, but Name.com is still on its sandbox, so nothing can be bought yet (a real charge for a test domain is refused). Switch Name.com to Live to open sales, with real registrations and charges.', 'set', 'Switch Name.com to Live', ['NAMECOM_ENV', 'live'], true];
                [$ok, $why] = AccountDomains::open($pdo, $uid);
                if ($ok) return [($m === 'test' ? 'Domain sales are on in Test: only our team sees them, in the sandboxes.' : 'Domain sales are Live for everyone.') . ' Find a domain in the Shop.', 'go', 'Open Shop → Domains', '/shop/domains.php', false];
                if (Domains::ncDown()) { $nc = Domains::ncDown(); return ['Name.com refused our sign-in (' . $nc['env'] . '): "' . $nc['error'] . '", so buying is paused. Check the username and token on Name.com\'s API page (https://www.name.com/account/settings/api), then ask Name.com again.', 'do', 'Ask Name.com again', 'namecom_check', true]; }
                if (!Domains::forSales(fn () => Domains::ncReady())) return ['Name.com\'s sign-in for ' . Domains::forSales(fn () => Domains::ncEnv()) . ' isn\'t in .env yet: NAMECOM_TEST_USER and NAMECOM_TEST_TOKEN for the sandbox (NAMECOM_USER and NAMECOM_TOKEN for live), from https://www.name.com/account/settings/api.', 'go', 'Open Name.com\'s API page', 'https://www.name.com/account/settings/api', true];
                return ['Saved, but Shop → Domains isn\'t open for you yet: ' . $why, '', '', '', true];
            }
            if ($key === 'DOMAINS_MODE') {
                require_once __DIR__ . '/Domains.php';
                if (Domains::mode() === 'off') return ['Own domains on storefronts are off: a storefront\'s Your own domain says "opens soon".', '', '', '', false];
                [$ok, $why] = Domains::available();
                return $ok ? ['Own domains on storefronts are on. A business adds one in its storefront\'s Your own domain; they\'re listed in Custom domains.', 'go', 'Open Custom domains', '/admin/market/domains', false]
                           : ['Saved, but storefronts can\'t connect a domain yet: ' . $why, '', '', '', true];
            }
        } catch (Throwable $x) { error_log('env next ' . $key . ': ' . $x->getMessage()); }
        return [];
    }

    /** A next step's action ('do'): runs it and returns what happened. */
    public static function act(string $what): string
    {
        if ($what === 'namecom_check') { require_once __DIR__ . '/Domains.php'; return self::current('DOMAIN_SALES_MODE') !== 'off' ? Domains::forSales(fn () => Domains::ncCheck()) : Domains::ncCheck(); }   // the Name.com that sales reach
        throw new InvalidArgumentException('That step isn\'t one the settings know.');
    }

    /** Secrets the site writes itself and never shows again (not on Settings): the health report's token (decisions/0145, TestAccounts). */
    public const WRITE_ONLY = ['HEALTH_TOKEN', 'COMMS_SEAL_KEY', 'VAPID_PRIVATE_PEM_B64', 'VAPID_PUBLIC_B64U', 'LIVE_READ_TOKEN'];   // + the live reads' key (/api/live-read.php, Jason 2026-11-23)   // + Communications' seal key and the web push keys (decisions/0172)

    /**
     * Secrets an owner types or the site makes in System Configuration → Communications (decisions/0167 §4, 0172 §4.7):
     * mailbox passwords and the Microsoft sign-in app's keys. Written straight to .env, never shown back; the old value is
     * kept as a dated comment line until the next Check passes (forgetOld()), so a failed reset can be undone (putBack()).
     */
    public const MAIL_SECRETS = ['SMTP_PASSWORD', 'ORDERS_SMTP_PASSWORD', 'REQUESTS_SMTP_PASSWORD', 'MS_MAIL_CLIENT_ID', 'MS_MAIL_CLIENT_SECRET'];

    public static function setMailSecret(string $key, string $value): void
    {
        if (!in_array($key, self::MAIL_SECRETS, true)) throw new InvalidArgumentException('That isn\'t a mail setting the site writes.');
        self::setKey($key, $value);   // the one writer and its guards (decisions/0173 §3)
    }

    /**
     * Every secret the site may write (decisions/0173 §3): each service's key that lives in .env (Operations::KEYS) and
     * the mailboxes' (MAIL_SECRETS). Never a sign-in secret of the site itself (APP_KEY, the database's).
     */
    public static function secrets(): array
    {
        require_once __DIR__ . '/Operations.php';
        $out = self::MAIL_SECRETS;
        foreach (Operations::KEYS as $keys) foreach ($keys as [$k, $where]) if (str_starts_with($where, '.env') && !str_contains($where, 'Railway')) $out[] = $k;   // one kept on Railway too (the crawler's token) changes in both places at once, so not from here
        return array_values(array_unique($out));
    }

    /**
     * The one writer of secrets (decisions/0167 §4, 0173 §3). Its guards are here, so no caller can skip them: only a
     * secret it knows, never on staging, only for the Founder,
     * a value .env can hold. The old value is kept as "# OLD <key> <date>" until a Check passes (forgetOld) or Undo puts it
     * back (putBack). Logged as who, when and which key: never the value.
     */
    public static function setKey(string $key, string $value, string $how = 'set'): void
    {
        self::guard($key);
        $value = trim($value);
        if ($value === '' || strlen($value) > 2000 || preg_match('/["\r\n\\\\]/', $value)) throw new InvalidArgumentException('That can\'t be written to .env: no quotes, backslashes or line breaks, up to 2,000 characters.');
        $old = self::value($key);
        if ($old !== '' && $old !== $value) self::keepOld($key, $old);
        self::write($key, $value);
        self::logged($key, $old === '' ? 'added' : ($how === 'set' ? 'replaced' : $how));
    }

    /** A key taken out (Remove the key): kept as "# OLD" first, so Put the old one back works until it's forgotten. */
    public static function removeKey(string $key): void
    {
        self::guard($key);
        $old = self::value($key);
        if ($old === '') throw new InvalidArgumentException('It isn\'t set, so there\'s nothing to remove.');
        self::keepOld($key, $old);
        self::write($key, '');
        self::logged($key, 'removed (kept until forgotten)');
    }

    /** The Founder, the secret named, and never on staging (decisions/0165). */
    private static function guard(string $key): void
    {
        if (!in_array($key, self::secrets(), true)) throw new InvalidArgumentException('That isn\'t a key the site writes.');
        require_once __DIR__ . '/Staging.php';
        if (Staging::here()) throw new RuntimeException('Staging never writes .env: set it on the live site.');
        if (PHP_SAPI !== 'cli' || class_exists('Access', false)) {
            if (!class_exists('Access', false)) require_once __DIR__ . '/../admin/Access.php';
            // the Founder only (decisions/0173 §3, 0167 §4: owner-only): Access::can lets Executives through everything, so the
            // level itself is asked
            if ((Access::who()[0] ?? '') !== 'founder') throw new RuntimeException('Keys are set by the Founder: ask them, or write to support@traversence.com.');
        }
    }

    /** Who changed which key, and how: never the value (the action log). */
    private static function logged(string $key, string $how): void
    {
        try {
            require_once __DIR__ . '/Team.php'; require_once __DIR__ . '/Auth.php';
            if (!class_exists('Access', false)) require_once __DIR__ . '/../admin/Access.php';
            $uid = (int) (Auth::currentUserId() ?? 0); $st = Access::staff();
            Audit::log(Database::connection(), ['user' => $uid, 'staff' => $st ? (int) $st['id'] : null, 'route' => 'admin', 'action' => 'config.key', 'detail' => $key . ': ' . $how]);
        } catch (Throwable $x) { error_log('key log ' . $key . ': ' . $x->getMessage()); }
    }

    /** The old value as "# OLD <key> <date>: <value>" (one per key), so Undo can put it back until the next Check passes. */
    private static function keepOld(string $key, string $old): void
    {
        self::swap(function (string $text) use ($key, $old): string {
            $lines = array_values(array_filter(preg_split('/\r\n|\n/', $text), fn ($l) => !str_starts_with($l, '# OLD ' . $key . ' ')));
            return rtrim(implode("\n", $lines), "\n") . "\n# OLD " . $key . ' ' . date('Y-m-d') . ': ' . $old . "\n";
        }, 'Couldn\'t keep the old value first, so nothing was changed.');
    }

    /**
     * .env changed whole, as write() does it (decisions/0173 R2, the session manager: a half-written .env takes the site
     * down): under the same lock, the new text beside it with the old file's permissions, then swapped in.
     */
    private static function swap(callable $edit, string $fail): void
    {
        $path = Database::envPath();
        $lock = fopen($path . '.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX)) throw new RuntimeException('Someone else is changing a setting. Try again in a moment.');
        try {
            $text = (string) @file_get_contents($path);
            $new = (string) $edit($text);
            if ($new === $text) return;
            $tmp = $path . '.new-' . bin2hex(random_bytes(4));
            if (@file_put_contents($tmp, $new) !== strlen($new)) { @unlink($tmp); throw new RuntimeException($fail); }
            @chmod($tmp, fileperms($path) & 0777);   // never wider than the .env it replaces
            if (!@rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException($fail); }
        } finally { flock($lock, LOCK_UN); fclose($lock); }
    }

    /** Whether an old value is waiting (for the Undo button). */
    public static function hasOld(string $key): bool
    {
        return (bool) preg_match('/^# OLD ' . preg_quote($key, '/') . ' /m', (string) @file_get_contents(Database::envPath()));
    }

    /** Undo a reset: the kept old value goes back in. */
    public static function putBack(string $key): void
    {
        if (!in_array($key, self::secrets(), true)) throw new InvalidArgumentException('Nothing to put back.');
        self::guard($key);
        if (!preg_match('/^# OLD ' . preg_quote($key, '/') . ' \S+: (.*)$/m', (string) @file_get_contents(Database::envPath()), $m)) throw new InvalidArgumentException('There\'s no earlier value kept for it.');
        self::write($key, trim($m[1]));
        self::forgetOld($key);
        self::logged($key, 'old value put back');
    }

    /** After a Check passes, the old value goes. */
    public static function forgetOld(string $key): void
    {
        try { self::swap(fn (string $text): string => (string) (preg_replace('/^# OLD ' . preg_quote($key, '/') . ' [^\n]*\n?/m', '', $text) ?? $text), 'Couldn\'t forget the old value.'); }
        catch (Throwable $x) { error_log('forgetOld ' . $key . ': ' . $x->getMessage()); }   // as before: the old line just stays
    }

    public static function value(string $key): string { Database::readEnv(); return trim((string) (getenv($key) ?: '')); }

    /** A value made safe for its kind, or an exception saying plainly what's wrong. */
    public static function check(string $key, string $v): string
    {
        if (!isset(self::EDITABLE[$key])) throw new InvalidArgumentException('That setting can only be changed in .env.');
        $v = trim($v);
        if (preg_match('/["\r\n\\\\]/', $v)) throw new InvalidArgumentException('Quotes, backslashes and line breaks can\'t go in a setting.');
        if ($v === '') {
            if (in_array($key, ['AWS_REGION', 'S3_BUCKET'], true)) throw new InvalidArgumentException('This one can\'t be empty: S3 would stop. Clear it in .env if you mean to.');
            return '';
        }
        $url = function (string $v): array { $u = parse_url($v); if (!$u || ($u['scheme'] ?? '') !== 'https' || empty($u['host'])) throw new InvalidArgumentException('Write the full address, starting https://'); return $u; };
        switch (self::EDITABLE[$key][2]) {
            case 'url-aws':
                $u = $url($v);
                if (!preg_match('/(^|\.)signin\.aws\.amazon\.com$|^console\.aws\.amazon\.com$/', (string) $u['host'])) throw new InvalidArgumentException('That isn\'t an AWS sign-in address (…signin.aws.amazon.com).');
                return $v;
            case 'url': $url($v); return rtrim($v, '/');
            case 'region': if (!preg_match('/^[a-z]{2}(-gov)?-[a-z]+-\d$/', $v)) throw new InvalidArgumentException('A region looks like us-east-2.'); return $v;
            case 'bucket': if (!preg_match('/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/', $v)) throw new InvalidArgumentException('A bucket name is 3 to 63 lower-case letters, numbers, dots or dashes.'); return $v;
            case 'money': if (!is_numeric($v) || (float) $v < 1 || (float) $v > 100000) throw new InvalidArgumentException('Write a dollar amount, like 25.'); return (string) (0 + $v);
            case 'email': if (!filter_var($v, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That isn\'t an email address.'); return strtolower($v);
            case 'payways':
                $ways = array_values(array_unique(array_filter(array_map('trim', explode(',', strtolower($v))))));
                foreach ($ways as $w) if (!in_array($w, ['wire', 'check', 'cash'], true)) throw new InvalidArgumentException('Use wire, check and/or cash, with a comma between.');
                return implode(',', $ways);
            case 'phone': if (!preg_match('/^[0-9 ()+.-]{7,25}$/', $v)) throw new InvalidArgumentException('Write a phone number, like (505) 555-0100.'); return $v;
            case 'domains-mode': if (!in_array(strtolower($v), ['off', 'test', 'live'], true)) throw new InvalidArgumentException('Write off, test or live.'); return strtolower($v);
            case 'namecom-env': if (!in_array(strtolower($v), ['sandbox', 'live'], true)) throw new InvalidArgumentException('Write sandbox or live.'); return strtolower($v);
            default: if (mb_strlen($v) > 200) throw new InvalidArgumentException('Keep it under 200 characters.'); return $v;
        }
    }

    /** Writes one setting into .env (replacing its line, or adding one). Returns [before, after]. */
    public static function set(string $key, string $value): array
    {
        return self::write($key, self::check($key, $value));
    }

    /** A secret the site makes itself (WRITE_ONLY): written to .env, never offered on Settings or its endpoint. */
    public static function setSecret(string $key, string $value): void
    {
        if (!in_array($key, self::WRITE_ONLY, true) || !preg_match('/^[A-Za-z0-9_-]{32,128}$/', $value)) throw new InvalidArgumentException('That isn\'t a secret the site makes.');
        self::write($key, $value);
    }

    private static function write(string $key, string $value): array
    {
        $path = Database::envPath();
        if (!is_file($path) || !is_writable($path) || !is_writable(dirname($path))) throw new RuntimeException('The site can\'t write .env on this server. Change it in cPanel → File Manager instead.');
        $lock = fopen($path . '.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX)) throw new RuntimeException('Someone else is changing a setting. Try again in a moment.');
        try {
            $text = (string) file_get_contents($path);
            $lines = preg_split('/\r\n|\n/', $text);
            $out = preg_match('/[\s#]/', $value) ? $key . '="' . $value . '"' : $key . '=' . $value;
            $before = ''; $done = false;
            foreach ($lines as $i => $l) {
                if ($done || !preg_match('/^\s*' . preg_quote($key, '/') . '\s*=(.*)$/', $l, $m)) continue;
                $before = trim(trim($m[1]), '"\'');
                $lines[$i] = $out; $done = true;
            }
            if (!$done) { if (end($lines) === '') array_pop($lines); $lines[] = $out; $lines[] = ''; }
            $new = implode("\n", $lines);
            $perm = fileperms($path) & 0777;
            $bak = $path . '.bak-' . date('Ymd-His');
            if (!@copy($path, $bak)) throw new RuntimeException('Couldn\'t keep a copy of .env first, so nothing was changed.');
            @chmod($bak, $perm);
            foreach (array_slice(array_reverse(glob($path . '.bak-*') ?: []), 5) as $old) @unlink($old);   // the last 5
            $tmp = $path . '.new-' . bin2hex(random_bytes(4));
            if (file_put_contents($tmp, $new) !== strlen($new)) { @unlink($tmp); throw new RuntimeException('Couldn\'t write the new .env, so nothing was changed.'); }
            @chmod($tmp, $perm);
            if (!@rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException('Couldn\'t put the new .env in place, so nothing was changed.'); }
            putenv($key . '=' . $value); $_ENV[$key] = $value;
            return [$before, $value];
        } finally { flock($lock, LOCK_UN); fclose($lock); }
    }
}
