<?php
// /api/upload-act.php — the buttons inside an upload's staff thread in Pulse (decisions/0176 §6, release 4;
// app/lib/UploadThreads.php). Staff only, as the admin's own endpoint (admin/api.php). POST JSON with X-CSRF-Token:
//   {act: hide, journey, body (the reason its author sees), msg}   the journey workflow's Hide
//   {act: show, journey, msg}                                      its Restore (Show again)
//   {act: report_remove|report_dismiss, report, msg}               the report workflow's Take it down / Leave it up
// Each through Workflow::move, with its own permission. -> {ok, message, html (the message's body drawn again)}.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/crawler/IntakeStager.php';
require_once __DIR__ . '/../../app/lib/UploadThreads.php';

header('Cache-Control: no-store');
$pdo = Database::connection();
$me = Auth::currentUser();
if (!$me) Response::error('Sign in to answer it.', 401, 'unauthenticated');
$ok = IntakeStager::canUseIntake($pdo, $me);   // staff, as /admin/api/ asks
if (!$ok) { try { $st = $pdo->prepare('SELECT 1 FROM ' . Database::t('admin_access') . " WHERE user_id = ? AND tier = 'regional_admin' LIMIT 1"); $st->execute([(int) $me['id']]); $ok = (bool) $st->fetchColumn(); } catch (Throwable) {} }
if (!$ok) Response::error('Staff only.', 403, 'forbidden');
Response::requireMethod('POST');
Response::requireCsrf();
try {
    [$said, $html] = UploadThreads::act($pdo, (int) $me['id'], Response::jsonBody());
    Response::success(['message' => $said] + ($html !== '' ? ['html' => $html] : []));
} catch (InvalidArgumentException $x) {
    Response::error($x->getMessage(), 422, 'not_allowed');
}
