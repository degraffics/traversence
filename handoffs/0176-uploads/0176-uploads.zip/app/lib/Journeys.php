<?php

declare(strict_types=1);

require_once __DIR__ . '/People.php';
require_once __DIR__ . '/AgeGate.php';
require_once __DIR__ . '/MemberVerification.php';
require_once __DIR__ . '/ListingSafety.php';

/**
 * api/lib/Journeys.php — journeys and contributors (decisions/0056).
 *
 * Two kinds of content, always labelled: Traversence (our editorial voice, staff only) and Contributor (first-person
 * journeys by a named member). Anyone 18 or older with a public profile can become a contributor. Journeys publish
 * when posted; reports go to Admin → Reports (post first, respond to flags and reports). A hidden journey stays
 * visible to its author.
 *
 * Privacy (decisions/0056 §4): photos are re-encoded on upload, which drops everything hidden in the file (GPS,
 * device, timestamps). The contributor tags where it was taken themselves, if they want to.
 *
 * Levels (the six-tier funnel): a journey is about a place (hub:, geo_hub:, cluster:). Its scope_keys hold that place
 * and the places above it ("|hub:1|geo_hub:3|cluster:12|"), so the feed at any level finds what's beneath it.
 */
final class Journeys
{
    public const GUIDELINES_VERSION = '2026-10';
    public const CATEGORIES = ['Exploring', 'Hiking', 'Outdoors', 'Outdoor recreation', 'Dining', 'Shopping', 'History', 'Culture', 'Road trip', 'Events', 'Family', 'Night skies'];
    /** Which magazine section (Let's Explore view) each category belongs to (decisions/0058 §7). */
    public const SECTIONS = ['outdoors' => ['Hiking', 'Outdoors', 'Outdoor recreation', 'Night skies'], 'food' => ['Dining'], 'culture' => ['History', 'Culture'],
                             'events' => ['Events'], 'shopping' => ['Shopping'], 'trips' => ['Exploring', 'Road trip', 'Family']];
    /** How others may reuse a journey's photos and words. Traversence only is the default. */
    public const REUSE = ['traversence' => 'Shown on Traversence only', 'credit' => 'Others may share it, with credit', 'free' => 'Free to use, no credit needed'];
    public const MAX_COAUTHORS = 5;
    /** What a contributor says about their own content (flags, decisions/0056 §5). */
    public const FLAGS = ['tribal_land' => 'On tribal land', 'public_event' => 'At a public event', 'permission' => 'Taken with permission',
                          'private_property' => 'On private property', 'people' => 'People are shown'];
    public const MAX_PHOTOS = 10;
    private const MAX_BYTES = 15 * 1024 * 1024;
    private const FULL = 2000;   // longest side, pixels
    private const CARD = 640;
    /** Why the last save() was held as a draft by an automatic check (null when it wasn't). */
    public static ?string $held = null;
    /** What happened to a pin on a nation's land, to tell the writer (decisions/0058 §26). */
    public static ?string $pinNote = null;

    public static function ready(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT 1 FROM journeys LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    private static function now(): string { return date('Y-m-d H:i:s'); }

    // ---- contributors -----------------------------------------------------------------------------------------

    public static function contributor(PDO $pdo, int $uid): ?array
    {
        $st = $pdo->prepare("SELECT * FROM contributors WHERE user_id = ? AND status = 'active'");
        $st->execute([$uid]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Staff who may post in the Traversence voice: an admin context that can manage content (decisions/0055). */
    /** Staff who write as Traversence: Content Creators, Editors, Managers, Owners (decisions/0058 §2). */
    public static function isStaff(PDO $pdo, int $uid): bool
    {
        return self::staffCan($pdo, $uid, 'content');
    }

    /** A staff capability: content (write as Traversence), publish (publish it), journeys (look after contributors' journeys). */
    public static function staffCan(PDO $pdo, int $uid, string $cap): bool
    {
        try {
            require_once __DIR__ . '/Roles.php';
            foreach (Roles::contexts($pdo, $uid) as $c) if ($c['kind'] === 'admin' && Roles::can($c, $cap)) return true;
        } catch (Throwable) {}
        return false;
    }

    /** Whether the journey-management columns are there (api/migrations/2026-10-08_journey_management.sql). */
    public static function managed(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT entity_id, submitted_at FROM journeys LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    /** Whether the journey-details columns are there (api/migrations/2026-10-09_journey_details.sql). */
    public static function detailed(PDO $pdo): bool
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        try { $pdo->query('SELECT pin_lat, reuse, mature FROM journeys LIMIT 1'); $pdo->query('SELECT 1 FROM journey_coauthors LIMIT 1'); return $ok = true; } catch (PDOException) { return $ok = false; }
    }

    /**
     * A pin, following the nations' rules (decisions/0058 §26): on a nation's land it's kept only at a public place,
     * moved onto it; anywhere else there it's dropped. [lat|null, lon|null, a note for the writer|null].
     */
    public static function nationPin(PDO $pdo, ?float $lat, ?float $lon): array
    {
        if (!is_file(__DIR__ . '/Nations.php')) return [$lat, $lon, null];
        require_once __DIR__ . '/Nations.php';
        return Nations::pin($pdo, $lat, $lon);
    }

    /** "34.50512, -109.36" -> [lat, lon], or null. */
    public static function point(string $s): ?array
    {
        $pt = array_map('trim', explode(',', $s));
        if (count($pt) !== 2 || !is_numeric($pt[0]) || !is_numeric($pt[1])) return null;
        $lat = (float) $pt[0]; $lon = (float) $pt[1];
        return $lat >= -90 && $lat <= 90 && $lon >= -180 && $lon <= 180 && ($lat != 0.0 || $lon != 0.0) ? [round($lat, 6), round($lon, 6)] : null;
    }

    /** Listings this person may post a journey as: ones whose team they're on with the right to post. [id => name] */
    public static function listingsFor(PDO $pdo, int $uid): array
    {
        if (!self::managed($pdo)) return [];
        $out = [];
        try {
            require_once __DIR__ . '/Roles.php';
            foreach (Roles::contexts($pdo, $uid) as $c) {
                if ($c['kind'] !== 'org' || !empty($c['scope']['preview']) || !(Roles::can($c, 'posts') || Roles::can($c, '*'))) continue;
                $out[(int) $c['scope']['entity']] = (string) $c['label'];
            }
        } catch (Throwable) {}
        return $out;
    }

    /** Who a journey is shown as: Traversence, a listing, or the person. ['name', 'url', 'kind' => traversence|listing|person, 'id'] */
    public static function author(PDO $pdo, array $j): array
    {
        if (($j['voice'] ?? '') === 'traversence') return ['name' => 'Traversence', 'url' => '', 'kind' => 'traversence', 'id' => 0];
        if (!empty($j['entity_id'])) {
            static $names = [];
            $eid = (int) $j['entity_id'];
            if (!array_key_exists($eid, $names)) {
                $st = $pdo->prepare('SELECT name FROM entities WHERE id = ? AND is_suppressed = 0');
                $st->execute([$eid]);
                $names[$eid] = $st->fetchColumn() ?: null;
            }
            if ($names[$eid] !== null) return ['name' => (string) $names[$eid], 'url' => '/listing/view.php?id=' . $eid, 'kind' => 'listing', 'id' => $eid];
        }
        $u = People::user($pdo, (int) $j['author_id']);
        return ['name' => $u ? People::name($u) : 'A contributor', 'url' => $u ? '/user/profile.php?id=' . (int) $j['author_id'] : '', 'kind' => 'person', 'id' => (int) $j['author_id']];
    }

    /** Who may edit it: its author; Traversence pieces, any staff writer. Staff don't edit contributors' words. */
    public static function canEdit(PDO $pdo, array $j, int $uid): bool
    {
        return (int) $j['author_id'] === $uid || ($j['voice'] === 'traversence' && self::isStaff($pdo, $uid));
    }

    /** What stands between this person and contributing: [] when nothing. */
    public static function blockers(PDO $pdo, int $uid): array
    {
        $b = [];
        if (!AgeGate::confirmed($pdo, $uid)) $b[] = 'age';
        try { if (People::settings($pdo, $uid)['profile_private']) $b[] = 'private'; } catch (Throwable) {}
        if (!MemberVerification::consented($pdo, $uid)) $b[] = 'verify';   // decisions/0062 §4
        return $b;
    }

    public static function become(PDO $pdo, int $uid, string $bio, bool $acceptGuidelines): void
    {
        if (!$acceptGuidelines) throw new InvalidArgumentException('Please read and accept the contributor guidelines.');
        if (in_array('age', self::blockers($pdo, $uid), true)) throw new InvalidArgumentException('Please confirm you are 18 or older first.');
        if (in_array('verify', self::blockers($pdo, $uid), true)) MemberVerification::require($pdo, $uid, 'contributor');
        if (in_array('private', self::blockers($pdo, $uid), true)) throw new InvalidArgumentException('Contributors have a public profile. Turn off "private profile" in your privacy settings first.');
        $bio = mb_substr(trim(strip_tags($bio)), 0, 400);
        if ($p = ListingSafety::contentProblem($bio)) throw new InvalidArgumentException('Your bio can\'t be saved: ' . $p . '.');
        $st = $pdo->prepare('SELECT 1 FROM contributors WHERE user_id = ?');
        $st->execute([$uid]);
        if ($st->fetchColumn()) {   // back again (paused before): the latest guidelines and bio
            $pdo->prepare("UPDATE contributors SET bio = ?, guidelines_version = ?, status = 'active' WHERE user_id = ?")->execute([$bio, self::GUIDELINES_VERSION, $uid]);
        } else {
            $pdo->prepare("INSERT INTO contributors (user_id, bio, guidelines_version, status, joined_at) VALUES (?, ?, ?, 'active', ?)")->execute([$uid, $bio, self::GUIDELINES_VERSION, self::now()]);
        }
    }

    // ---- journeys ---------------------------------------------------------------------------------------------

    /** The place and the places above it, as "|hub:1|geo_hub:3|cluster:12|". */
    public static function scopeKeys(PDO $pdo, string $key): string
    {
        if (!preg_match('/^(hub|geo_hub|cluster):(\d+)$/', $key, $m)) return '';
        $keys = [$key];
        try {
            if ($m[1] === 'cluster') {
                $st = $pdo->prepare('SELECT mc.geo_hub_id, g.hub_id FROM micro_clusters mc LEFT JOIN geo_hubs g ON g.id = mc.geo_hub_id WHERE mc.id = ?');
                $st->execute([(int) $m[2]]);
                if ($r = $st->fetch(PDO::FETCH_ASSOC)) { if ($r['geo_hub_id']) $keys[] = 'geo_hub:' . (int) $r['geo_hub_id']; if ($r['hub_id']) $keys[] = 'hub:' . (int) $r['hub_id']; }
            } elseif ($m[1] === 'geo_hub') {
                $st = $pdo->prepare('SELECT hub_id FROM geo_hubs WHERE id = ?');
                $st->execute([(int) $m[2]]);
                if ($h = $st->fetchColumn()) $keys[] = 'hub:' . (int) $h;
            }
        } catch (Throwable) {}
        return '|' . implode('|', array_reverse($keys)) . '|';
    }

    /** A YouTube or Vimeo link → its embed address; '' for anything else. */
    public static function embed(string $url): string
    {
        $url = trim($url);
        if (preg_match('#^https?://(?:www\.|m\.)?(?:youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|embed/)|youtu\.be/)([A-Za-z0-9_-]{6,15})#', $url, $m)) return 'https://www.youtube-nocookie.com/embed/' . $m[1];
        if (preg_match('#^https?://(?:www\.|player\.)?vimeo\.com/(?:video/)?(\d{5,12})#', $url, $m)) return 'https://player.vimeo.com/video/' . $m[1];
        return '';
    }

    /**
     * Create or update. $in: title, category, place_key, place_label, was_here (Y-m-d), body, video_url, flags[],
     * listings[] (ids), voice (contributor|traversence, staff only), publish (bool). Returns the id.
     */
    public static function save(PDO $pdo, int $uid, array $in, ?int $id = null): int
    {
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);   // limited accounts can't post or send (decisions/0079)
        $cur = $id ? self::get($pdo, $id) : null;
        if ($id && (!$cur || !self::canEdit($pdo, $cur, $uid))) throw new InvalidArgumentException('That journey isn\'t yours to edit.');
        $editorial = $cur ? $cur['voice'] === 'traversence' : (($in['voice'] ?? '') === 'traversence' && self::isStaff($pdo, $uid));
        if (!$editorial && !self::contributor($pdo, $uid)) throw new InvalidArgumentException('Become a contributor first.');
        $title = mb_substr(trim(strip_tags((string) ($in['title'] ?? ''))), 0, 160);
        $body = trim(str_replace("\r", '', strip_tags((string) ($in['body'] ?? ''))));
        $publish = !empty($in['publish']);
        if ($title === '') throw new InvalidArgumentException('Give your journey a title.');
        if ($publish && mb_strlen($body) < 40) throw new InvalidArgumentException('Tell a little more of the story (a few sentences at least) before publishing.');
        $category = in_array($in['category'] ?? '', self::CATEGORIES, true) ? (string) $in['category'] : 'Exploring';
        $placeKey = preg_match('/^(hub|geo_hub|cluster):\d+$/', (string) ($in['place_key'] ?? '')) ? (string) $in['place_key'] : '';
        $wasHere = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($in['was_here'] ?? '')) && strtotime((string) $in['was_here']) <= time() + 86400 ? (string) $in['was_here'] : null;
        $video = trim((string) ($in['video_url'] ?? ''));
        if ($video !== '' && self::embed($video) === '') throw new InvalidArgumentException('Videos are linked from YouTube or Vimeo. Paste the video\'s address.');
        $flags = array_values(array_intersect(array_keys(self::FLAGS), (array) ($in['flags'] ?? [])));
        $listings = array_slice(array_values(array_unique(array_filter(array_map('intval', (array) ($in['listings'] ?? []))))), 0, 20);
        $voice = $editorial ? 'traversence' : 'contributor';
        // posted as a listing its author helps run (contributor voice only); kept as it was when someone else edits
        $entity = null;
        if (!$editorial && self::managed($pdo)) {
            if ($cur && (int) $cur['author_id'] !== $uid) $entity = $cur['entity_id'] ? (int) $cur['entity_id'] : null;
            elseif (preg_match('/^listing:(\d+)$/', (string) ($in['as'] ?? ''), $m)) {
                if (!isset(self::listingsFor($pdo, $uid)[(int) $m[1]])) throw new InvalidArgumentException('You can only post as a listing whose team you\'re on.');
                $entity = (int) $m[1];
            }
        }
        $held = null; $sent = false;
        if ($publish && ($p = ListingSafety::contentProblem($title, $body))) { $publish = false; $held = $p; }   // an automated check holds it as a draft
        if ($publish && $editorial && !self::staffCan($pdo, $uid, 'publish')) { $publish = false; $sent = true; }   // a Content Creator sends it to an editor
        $row = [$voice, $category, $title, $placeKey, mb_substr(trim(strip_tags((string) ($in['place_label'] ?? ''))), 0, 160), self::scopeKeys($pdo, $placeKey),
                $wasHere, $body, $video, implode(',', $flags), implode(',', $listings), !empty($in['partnership']) ? 1 : 0];
        if ($id) {
            $pdo->prepare("UPDATE journeys SET voice = ?, category = ?, title = ?, place_key = ?, place_label = ?, scope_keys = ?, was_here = ?, body = ?, video_url = ?, flags = ?, listings = ?,
                                  partnership = ?, status = CASE WHEN status = 'hidden' THEN 'hidden' ELSE ? END, published_at = COALESCE(published_at, ?), updated_at = ? WHERE id = ?")
                ->execute(array_merge($row, [$publish ? 'published' : 'draft', $publish ? self::now() : null, self::now(), $id]));
        } else {
            $pdo->prepare('INSERT INTO journeys (author_id, voice, category, title, place_key, place_label, scope_keys, was_here, body, video_url, flags, listings, partnership, status, created_at, updated_at, published_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute(array_merge([$uid], $row, [$publish ? 'published' : 'draft', self::now(), self::now(), $publish ? self::now() : null]));
            $id = (int) $pdo->lastInsertId();
        }
        if (self::detailed($pdo)) {   // where it happened, the time, reuse, the mature gate, a caution (decisions/0058 §7)
            $pt = self::point((string) ($in['pin'] ?? ''));
            if ($pt) {   // on a nation's land a pin is kept only at a public place (decisions/0058 §26)
                [$la, $lo, $why] = self::nationPin($pdo, $pt[0], $pt[1]);
                $pt = $la !== null ? [$la, $lo] : null;
                if ($why) self::$pinNote = $why;
            }
            $time = preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string) ($in['was_time'] ?? '')) ? $in['was_time'] . ':00' : null;
            $caution = mb_substr(trim(strip_tags((string) ($in['caution'] ?? ''))), 0, 300);
            $pdo->prepare('UPDATE journeys SET pin_lat = ?, pin_lon = ?, was_time = ?, reuse = ?, mature = ?, caution = ? WHERE id = ?')
                ->execute([$pt[0] ?? null, $pt[1] ?? null, $time, isset(self::REUSE[$in['reuse'] ?? '']) ? (string) $in['reuse'] : 'traversence', !empty($in['mature']) ? 1 : 0, $caution, $id]);
            if (array_key_exists('coauthors', $in) && (!$cur || (int) $cur['author_id'] === $uid)) self::setCoauthors($pdo, $uid, $id, (array) $in['coauthors']);
        }
        if (self::managed($pdo)) {
            $pdo->prepare('UPDATE journeys SET entity_id = ?, submitted_at = ? WHERE id = ?')
                ->execute([$entity, $sent ? self::now() : ($publish ? null : ($cur['submitted_at'] ?? null)), $id]);
        }
        require_once __DIR__ . '/ContentTags.php'; ContentTags::retag($pdo, 'journey:' . $id);   // the Chameleon Filter reads it once it's published (decisions/0132)
        self::$held = $held ? 'Saved as a draft: an automatic check found ' . $held . '. Change it and publish again, or ask us to look.'
                    : ($sent ? 'Sent to an editor. It stays a draft until an editor publishes it.' : null);
        // its photos went live now (decisions/0176 §6: post first, and staff get the photo's thread): only on the publish itself
        if ($publish && ($cur['status'] ?? '') !== 'published' && (self::get($pdo, $id)['status'] ?? '') === 'published') { require_once __DIR__ . '/UploadThreads.php'; UploadThreads::placePhoto($pdo, $id, $uid); }
        return $id;
    }

    public static function get(PDO $pdo, int $id): ?array
    {
        $st = $pdo->prepare('SELECT * FROM journeys WHERE id = ?');
        $st->execute([$id]);
        $j = $st->fetch(PDO::FETCH_ASSOC);
        return $j ?: null;
    }

    /** Whether this viewer may see it: published to everyone; drafts and hidden ones to the author and staff. */
    public static function visible(PDO $pdo, array $j, ?int $viewer): bool
    {
        return $j['status'] === 'published' || ($viewer && ((int) $j['author_id'] === $viewer || self::isStaff($pdo, $viewer) || self::staffCan($pdo, $viewer, 'journeys')));
    }

    public static function setHidden(PDO $pdo, int $id, bool $hide, string $why): void
    {
        $pdo->prepare("UPDATE journeys SET status = ?, hidden_reason = ?, updated_at = ? WHERE id = ? AND status <> 'draft'")
            ->execute([$hide ? 'hidden' : 'published', $hide ? $why : '', self::now(), $id]);
    }

    public static function setCommentHidden(PDO $pdo, int $id, bool $hide): void
    {
        $pdo->prepare('UPDATE journey_comments SET status = ? WHERE id = ?')->execute([$hide ? 'hidden' : 'visible', $id]);
        $st = $pdo->prepare('SELECT journey_id FROM journey_comments WHERE id = ?'); $st->execute([$id]);
        if ($j = (int) $st->fetchColumn()) self::recount($pdo, $j);
    }

    public static function remove(PDO $pdo, int $uid, int $id): void
    {
        $j = self::get($pdo, $id);
        if (!$j || !self::canEdit($pdo, $j, $uid)) throw new InvalidArgumentException('That journey isn\'t yours.');
        foreach (self::media($pdo, $id) as $m) self::deleteFiles($m);
        foreach (['journey_media', 'journey_likes', 'journey_comments', 'journey_views'] as $t) $pdo->prepare("DELETE FROM $t WHERE journey_id = ?")->execute([$id]);
        $pdo->prepare('DELETE FROM journeys WHERE id = ?')->execute([$id]);
    }

    // ---- photos -----------------------------------------------------------------------------------------------

    public static function media(PDO $pdo, int $id): array
    {
        $st = $pdo->prepare('SELECT * FROM journey_media WHERE journey_id = ? ORDER BY sort, id');
        $st->execute([$id]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Add a photo that arrived (api/upload.php, target journey_photo: Upload::asFile()). It's turned the right way up, resized (2000 px and a 640 px card)
     * and re-encoded as JPEG, which drops everything hidden in the original file (GPS, device, timestamps).
     */
    public static function addPhoto(PDO $pdo, int $uid, int $id, array $file, string $caption = '', string $tagPlace = '', ?float $lat = null, ?float $lon = null): int
    {
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);   // limited accounts can't post or send (decisions/0079)
        $j = self::get($pdo, $id);
        if (!$j || !self::canEdit($pdo, $j, $uid)) throw new InvalidArgumentException('That journey isn\'t yours.');
        if (count(self::media($pdo, $id)) >= self::MAX_PHOTOS) throw new InvalidArgumentException('A journey holds up to ' . self::MAX_PHOTOS . ' photos.');
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_file((string) $file['tmp_name'])) throw new InvalidArgumentException('The photo didn\'t arrive. Try again.');
        if ((int) $file['size'] > self::MAX_BYTES) throw new InvalidArgumentException('That photo is too large (15 MB at most).');
        $info = @getimagesize((string) $file['tmp_name']);
        if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) throw new InvalidArgumentException('Photos can be JPEG, PNG or WebP.');
        $src = match ($info[2]) { IMAGETYPE_JPEG => @imagecreatefromjpeg($file['tmp_name']), IMAGETYPE_PNG => @imagecreatefrompng($file['tmp_name']), default => @imagecreatefromwebp($file['tmp_name']) };
        if (!$src) throw new InvalidArgumentException('That photo couldn\'t be read.');
        if ($info[2] === IMAGETYPE_JPEG && function_exists('exif_read_data')) {   // read only the orientation, then the file is discarded
            $o = (int) (@exif_read_data((string) $file['tmp_name'])['Orientation'] ?? 1);
            if ($o === 3) $src = imagerotate($src, 180, 0); elseif ($o === 6) $src = imagerotate($src, -90, 0); elseif ($o === 8) $src = imagerotate($src, 90, 0);
        }
        require_once __DIR__ . '/Store.php';   // in the author's folder, then S3 (decisions/0124)
        $name = bin2hex(random_bytes(12));
        $dir = dirname(Store::path('members', (int) ($j['author_id'] ?: $uid), 'journeys', "$name.jpg", true));
        if (!is_dir($dir) && !@mkdir($dir, 0755, true)) throw new RuntimeException('Photos can\'t be stored right now.');
        [$w, $h] = self::writeJpeg($src, $dir . "/$name.jpg", self::FULL);
        self::writeJpeg($src, $dir . "/$name-card.jpg", self::CARD);
        imagedestroy($src);
        Store::keep($dir . "/$name.jpg", $dir . "/$name-card.jpg");
        $rel = substr(Store::address($dir . "/$name.jpg"), 0, -4);
        $okPt = $lat !== null && $lon !== null && $lat >= -90 && $lat <= 90 && $lon >= -180 && $lon <= 180;
        if ($okPt) { [$lat, $lon, $why] = self::nationPin($pdo, $lat, $lon); $okPt = $lat !== null; if ($why) self::$pinNote = $why; }
        $pdo->prepare('INSERT INTO journey_media (journey_id, path, card_path, width, height, caption, tag_lat, tag_lon, tag_place, sort, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$id, "$rel.jpg", "$rel-card.jpg", $w, $h, mb_substr(trim(strip_tags($caption)), 0, 300), $okPt ? round($lat, 6) : null, $okPt ? round($lon, 6) : null,
                       mb_substr(trim(strip_tags($tagPlace)), 0, 160), count(self::media($pdo, $id)), self::now()]);
        return (int) $pdo->lastInsertId();
    }

    /** @return array{0:int,1:int} the written size */
    private static function writeJpeg($src, string $path, int $max): array
    {
        $w = imagesx($src); $h = imagesy($src);
        $k = min(1, $max / max($w, $h));
        $nw = max(1, (int) round($w * $k)); $nh = max(1, (int) round($h * $k));
        $dst = imagecreatetruecolor($nw, $nh);
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));   // transparent PNGs on white
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
        imageinterlace($dst, true);
        if (!imagejpeg($dst, $path, 82)) throw new RuntimeException('Photos can\'t be stored right now.');
        imagedestroy($dst);
        return [$nw, $nh];
    }

    /** The contributor's own tag for a photo: a caption, where it was taken (words), and a pin they set, or none. */
    /** $more: taken (a date or date and time), source (own|permission), credit (who it's used with permission from). */
    public static function updatePhoto(PDO $pdo, int $uid, int $mediaId, string $caption, string $tagPlace, ?float $lat, ?float $lon, array $more = []): void
    {
        $st = $pdo->prepare('SELECT j.author_id, j.voice FROM journey_media m JOIN journeys j ON j.id = m.journey_id WHERE m.id = ?');
        $st->execute([$mediaId]);
        $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a || !self::canEdit($pdo, $a, $uid)) throw new InvalidArgumentException('That photo isn\'t yours.');
        $okPt = $lat !== null && $lon !== null && $lat >= -90 && $lat <= 90 && $lon >= -180 && $lon <= 180;
        if ($okPt) { [$lat, $lon, $why] = self::nationPin($pdo, $lat, $lon); $okPt = $lat !== null; if ($why) self::$pinNote = $why; }
        $pdo->prepare('UPDATE journey_media SET caption = ?, tag_place = ?, tag_lat = ?, tag_lon = ? WHERE id = ?')
            ->execute([mb_substr(trim(strip_tags($caption)), 0, 300), mb_substr(trim(strip_tags($tagPlace)), 0, 160), $okPt ? round($lat, 6) : null, $okPt ? round($lon, 6) : null, $mediaId]);
        if ($more && self::detailed($pdo)) {
            $t = (string) ($more['taken'] ?? '');
            $taken = preg_match('/^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2})?/', $t) && ($ts = strtotime($t)) && $ts <= time() + 86400 ? date('Y-m-d H:i:s', $ts) : null;
            $source = ($more['source'] ?? '') === 'permission' ? 'permission' : 'own';
            $credit = $source === 'permission' ? mb_substr(trim(strip_tags((string) ($more['credit'] ?? ''))), 0, 160) : '';
            if ($source === 'permission' && $credit === '') throw new InvalidArgumentException('Say whose photo it is, for the credit line.');
            $pdo->prepare('UPDATE journey_media SET taken_at = ?, source = ?, credit = ? WHERE id = ?')->execute([$taken, $source, $credit, $mediaId]);
        }
    }

    // ---- co-authors: invited by the author, shown once they accept (decisions/0058 §7) -----------------------------

    /** The co-authors of a journey: [['id', 'name', 'status']]; accepted only unless $all. */
    public static function coauthors(PDO $pdo, int $id, bool $all = false): array
    {
        if (!self::detailed($pdo)) return [];
        $st = $pdo->prepare('SELECT user_id, status FROM journey_coauthors WHERE journey_id = ?' . ($all ? " AND status <> 'declined'" : " AND status = 'accepted'") . ' ORDER BY invited_at');
        $st->execute([$id]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $u = People::user($pdo, (int) $r['user_id']); if ($u) $out[] = ['id' => (int) $r['user_id'], 'name' => People::name($u), 'status' => (string) $r['status']]; }
        return $out;
    }

    /** The author sets who's invited: new ones are invited, dropped ones removed; an accepted co-author stays unless dropped. */
    public static function setCoauthors(PDO $pdo, int $uid, int $id, array $ids): void
    {
        $ids = array_slice(array_values(array_unique(array_filter(array_map('intval', $ids), fn ($x) => $x > 0 && $x !== $uid))), 0, self::MAX_COAUTHORS);
        $have = [];
        $st = $pdo->prepare('SELECT user_id FROM journey_coauthors WHERE journey_id = ?'); $st->execute([$id]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $x) $have[(int) $x] = true;
        foreach (array_keys($have) as $x) if (!in_array($x, $ids, true)) $pdo->prepare('DELETE FROM journey_coauthors WHERE journey_id = ? AND user_id = ?')->execute([$id, $x]);
        foreach ($ids as $x) {
            if (isset($have[$x]) || !People::user($pdo, $x)) continue;
            try { if (People::blocked($pdo, $uid, $x) || People::blocked($pdo, $x, $uid)) continue; } catch (Throwable) {}
            $pdo->prepare('INSERT INTO journey_coauthors (journey_id, user_id, status, invited_by, invited_at) VALUES (?, ?, ?, ?, ?)')->execute([$id, $x, 'invited', $uid, self::now()]);
        }
    }

    /** Invitations waiting for this person: [['journey_id', 'title', 'from']] */
    public static function invites(PDO $pdo, int $uid): array
    {
        if (!self::detailed($pdo)) return [];
        $st = $pdo->prepare("SELECT c.journey_id, j.title, j.category, j.author_id FROM journey_coauthors c JOIN journeys j ON j.id = c.journey_id WHERE c.user_id = ? AND c.status = 'invited' ORDER BY c.invited_at DESC");
        $st->execute([$uid]);
        return array_map(function ($r) use ($pdo) { $u = People::user($pdo, (int) $r['author_id']);
            return ['journey_id' => (int) $r['journey_id'], 'title' => (string) $r['category'] . ' | ' . $r['title'], 'from' => $u ? People::name($u) : 'A member']; }, $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function respond(PDO $pdo, int $uid, int $id, bool $accept): void
    {
        if ($accept) AgeGate::require($pdo, $uid);
        $st = $pdo->prepare("UPDATE journey_coauthors SET status = ?, responded_at = ? WHERE journey_id = ? AND user_id = ?");
        $st->execute([$accept ? 'accepted' : 'declined', self::now(), $id, $uid]);
        if (!$st->rowCount()) throw new InvalidArgumentException('That invitation is gone.');
    }

    public static function removePhoto(PDO $pdo, int $uid, int $mediaId): void
    {
        $st = $pdo->prepare('SELECT m.*, j.author_id, j.voice FROM journey_media m JOIN journeys j ON j.id = m.journey_id WHERE m.id = ?');
        $st->execute([$mediaId]);
        $m = $st->fetch(PDO::FETCH_ASSOC);
        if (!$m || !self::canEdit($pdo, $m, $uid)) throw new InvalidArgumentException('That photo isn\'t yours.');
        self::deleteFiles($m);
        $pdo->prepare('DELETE FROM journey_media WHERE id = ?')->execute([$mediaId]);
    }

    private static function deleteFiles(array $m): void
    {
        require_once __DIR__ . '/Store.php';   // on the server or in S3 (decisions/0123)
        foreach (['path', 'card_path'] as $k) if (str_starts_with((string) $m[$k], '/uploads/') && !str_contains((string) $m[$k], '..')) Store::remove(Store::web((string) $m[$k]));
    }

    // ---- reading ----------------------------------------------------------------------------------------------

    public static function readMinutes(string $body): int { return max(1, (int) round(str_word_count(strip_tags($body)) / 220)); }

    /**
     * The feed for a level: Traversence guides (published place stories) and journeys (both voices), newest first.
     * $scope: '' for North America, or a place key ("cluster:12"). Each item: type (journey|guide), voice, title,
     * category, url, image, place, author, author_id, date, minutes, views, likes, comments, video.
     */
    public static function feed(PDO $pdo, string $scope, int $limit = 12, int $offset = 0, string $section = ''): array
    {
        $items = [];
        $cats = self::SECTIONS[$section] ?? [];   // a magazine section (Outdoors, Food & drink …): journeys only, in its categories
        if (self::ready($pdo)) {
            $where = "j.status = 'published'" . ($scope !== '' ? ' AND j.scope_keys LIKE ?' : '') . ($cats ? ' AND j.category IN (' . implode(',', array_fill(0, count($cats), '?')) . ')' : '');
            $st = $pdo->prepare("SELECT j.*, (SELECT card_path FROM journey_media m WHERE m.journey_id = j.id ORDER BY m.sort, m.id LIMIT 1) AS card
                                   FROM journeys j WHERE $where ORDER BY j.published_at DESC LIMIT " . ($limit + $offset + 12));
            $st->execute(array_merge($scope !== '' ? ['%|' . $scope . '|%'] : [], $cats));
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $j) {
                $au = self::author($pdo, $j);
                $items[] = ['type' => 'journey', 'id' => (int) $j['id'], 'voice' => $j['voice'], 'title' => (string) $j['title'], 'category' => (string) $j['category'],
                            'url' => '/journeys/view.php?id=' . (int) $j['id'], 'image' => (string) ($j['card'] ?? ''), 'place' => (string) $j['place_label'],
                            'author' => $au['name'], 'author_kind' => $au['kind'], 'author_id' => $au['kind'] === 'person' ? $au['id'] : 0,
                            'date' => (string) $j['published_at'], 'minutes' => self::readMinutes((string) $j['body']), 'views' => (int) $j['views'], 'likes' => (int) $j['likes'],
                            'comments' => (int) $j['comments'], 'video' => $j['video_url'] !== '', 'partnership' => (bool) $j['partnership'], 'mature' => !empty($j['mature'])];
            }
        }
        // our reviewed guide stories for this level (decisions/0043): Traversence voice
        if (!$cats) try {
            $keys = self::storyKeys($pdo, $scope);
            $sql = "SELECT place_key, title, body, updated_at FROM place_stories WHERE status = 'published'" . ($keys === null ? " AND place_key <> 'na'" : ' AND place_key IN (' . implode(',', array_fill(0, count($keys), '?')) . ')') . ' ORDER BY updated_at DESC LIMIT 30';
            $st = $pdo->prepare($sql);
            $st->execute($keys ?? []);
            require_once __DIR__ . '/Links.php';
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $g) {
                try { [$pl, $url] = Links::resolve($pdo, 'place', (string) $g['place_key']); } catch (Throwable) { continue; }
                $items[] = ['type' => 'guide', 'id' => 0, 'voice' => 'traversence', 'title' => (string) ($g['title'] ?: 'The story of ' . $pl), 'category' => 'Guide', 'url' => $url . '#story-h',
                            'image' => '', 'place' => $pl, 'author' => 'Traversence', 'author_id' => 0, 'date' => (string) $g['updated_at'], 'minutes' => self::readMinutes((string) $g['body']),
                            'views' => 0, 'likes' => 0, 'comments' => 0, 'video' => false, 'partnership' => false];
            }
        } catch (Throwable) {}
        usort($items, fn ($a, $b) => strcmp($b['date'], $a['date']));
        return array_slice($items, $offset, $limit);
    }

    /** The place keys whose guide stories a level's feed carries: the level and the levels in it. null: everywhere. */
    private static function storyKeys(PDO $pdo, string $scope): ?array
    {
        if ($scope === '') return null;
        $keys = [];
        if (preg_match('/^(hub|geo_hub|cluster):(\d+)$/', $scope, $m)) {
            $keys = [$scope];
            if ($m[1] === 'hub') { foreach ($pdo->query('SELECT id FROM geo_hubs WHERE hub_id = ' . (int) $m[2])->fetchAll(PDO::FETCH_COLUMN) as $g) { $keys[] = 'geo_hub:' . $g;
                                   foreach ($pdo->query('SELECT id FROM micro_clusters WHERE geo_hub_id = ' . (int) $g)->fetchAll(PDO::FETCH_COLUMN) as $c) $keys[] = 'cluster:' . $c; } }
            if ($m[1] === 'geo_hub') foreach ($pdo->query('SELECT id FROM micro_clusters WHERE geo_hub_id = ' . (int) $m[2])->fetchAll(PDO::FETCH_COLUMN) as $c) $keys[] = 'cluster:' . $c;
        }
        return $keys;
    }

    /** How many cards feed() has in all for a level (and section), for its pages (the lists' standard, 2026-11-12). */
    public static function feedTotal(PDO $pdo, string $scope, string $section = ''): int
    {
        $n = 0; $cats = self::SECTIONS[$section] ?? [];
        try {
            if (self::ready($pdo)) {
                $where = "status = 'published'" . ($scope !== '' ? ' AND scope_keys LIKE ?' : '') . ($cats ? ' AND category IN (' . implode(',', array_fill(0, count($cats), '?')) . ')' : '');
                $st = $pdo->prepare("SELECT COUNT(*) FROM journeys WHERE $where"); $st->execute(array_merge($scope !== '' ? ['%|' . $scope . '|%'] : [], $cats));
                $n += (int) $st->fetchColumn();
            }
            if (!$cats) {
                $keys = self::storyKeys($pdo, $scope);
                $st = $pdo->prepare("SELECT COUNT(*) FROM place_stories WHERE status = 'published'" . ($keys === null ? " AND place_key <> 'na'" : ' AND place_key IN (' . implode(',', array_fill(0, count($keys), '?')) . ')'));
                $st->execute($keys ?? []);
                $n += min(30, (int) $st->fetchColumn());   // feed() carries the 30 newest stories
            }
        } catch (Throwable) {}
        return $n;
    }

    /**
     * The hero for one place (an outdoor place, a landmark): photos from published journeys pinned within $miles of it,
     * or with a photo tagged there, credited (decisions/0058 §30). Same shape as hero().
     */
    public static function heroNear(PDO $pdo, float $lat, float $lon, float $miles = 0.5, int $n = 5): array
    {
        if (!self::ready($pdo) || !self::detailed($pdo)) return [];
        $dLat = $miles / 69.0; $dLon = $miles / max(0.0001, 69.0 * cos(deg2rad($lat)));
        $st = $pdo->prepare("SELECT m.path, m.caption, m.tag_place, j.id, j.title, j.voice, j.author_id, " . (self::managed($pdo) ? 'j.entity_id' : 'NULL AS entity_id') . ", j.views, j.likes, j.comments, j.place_label
                               FROM journey_media m JOIN journeys j ON j.id = m.journey_id
                              WHERE j.status = 'published' AND j.mature = 0 AND m.width >= 900
                                AND ((j.pin_lat BETWEEN ? AND ? AND j.pin_lon BETWEEN ? AND ?) OR (m.tag_lat BETWEEN ? AND ? AND m.tag_lon BETWEEN ? AND ?))
                              ORDER BY (j.likes * 3 + j.comments * 2 + j.views / 50) DESC, j.published_at DESC LIMIT " . ($n * 3));
        $box = [$lat - $dLat, $lat + $dLat, $lon - $dLon, $lon + $dLon];
        $st->execute(array_merge($box, $box));
        $out = []; $seen = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if (isset($seen[$r['id']])) continue;
            $seen[$r['id']] = 1;
            $au = self::author($pdo, $r);
            $out[] = ['image' => (string) $r['path'], 'caption' => (string) ($r['caption'] ?: $r['title']), 'place' => (string) ($r['tag_place'] ?: $r['place_label']),
                      'url' => '/journeys/view.php?id=' . (int) $r['id'], 'author' => $au['name'], 'author_kind' => $au['kind'],
                      'author_id' => $au['kind'] === 'person' ? $au['id'] : 0, 'views' => (int) $r['views'], 'likes' => (int) $r['likes'], 'comments' => (int) $r['comments']];
            if (count($out) >= $n) break;
        }
        return $out;
    }

    /** The hero for a listing with no photos of its own: photos from published journeys that tag it (decisions/0058 §30). */
    public static function heroTagged(PDO $pdo, int $listingId, int $n = 5): array
    {
        if (!self::ready($pdo) || $listingId <= 0) return [];
        $st = $pdo->prepare("SELECT m.path, m.caption, m.tag_place, j.id, j.title, j.voice, j.author_id, " . (self::managed($pdo) ? 'j.entity_id' : 'NULL AS entity_id') . ", j.views, j.likes, j.comments, j.place_label
                               FROM journey_media m JOIN journeys j ON j.id = m.journey_id
                              WHERE j.status = 'published' AND m.width >= 900" . (self::detailed($pdo) ? ' AND j.mature = 0' : '') . " AND CONCAT(',', j.listings, ',') LIKE ?
                              ORDER BY (j.likes * 3 + j.comments * 2 + j.views / 50) DESC, j.published_at DESC LIMIT " . ($n * 3));
        $st->execute(['%,' . $listingId . ',%']);
        $out = []; $seen = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if (isset($seen[$r['id']])) continue;
            $seen[$r['id']] = 1;
            $au = self::author($pdo, $r);
            $out[] = ['image' => (string) $r['path'], 'caption' => (string) ($r['caption'] ?: $r['title']), 'place' => (string) ($r['tag_place'] ?: $r['place_label']),
                      'url' => '/journeys/view.php?id=' . (int) $r['id'], 'author' => $au['name'], 'author_kind' => $au['kind'],
                      'author_id' => $au['kind'] === 'person' ? $au['id'] : 0, 'views' => (int) $r['views'], 'likes' => (int) $r['likes'], 'comments' => (int) $r['comments']];
            if (count($out) >= $n) break;
        }
        return $out;
    }

    /** The hero: the top photos for a level, credited. */
    public static function hero(PDO $pdo, string $scope, int $n = 5): array
    {
        if (!self::ready($pdo)) return [];
        $where = "j.status = 'published'" . ($scope !== '' ? ' AND j.scope_keys LIKE ?' : '');
        $st = $pdo->prepare("SELECT m.path, m.caption, m.tag_place, j.id, j.title, j.voice, j.author_id, " . (self::managed($pdo) ? 'j.entity_id' : 'NULL AS entity_id') . ", j.views, j.likes, j.comments, j.place_label
                               FROM journey_media m JOIN journeys j ON j.id = m.journey_id
                              WHERE $where AND m.width >= 900" . (self::detailed($pdo) ? ' AND j.mature = 0' : '') . " ORDER BY (j.likes * 3 + j.comments * 2 + j.views / 50) DESC, j.published_at DESC LIMIT " . ($n * 3));
        $st->execute($scope !== '' ? ['%|' . $scope . '|%'] : []);
        $out = []; $seen = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if (isset($seen[$r['id']])) continue;   // one photo per journey
            $seen[$r['id']] = 1;
            $au = self::author($pdo, $r);
            $out[] = ['image' => (string) $r['path'], 'caption' => (string) ($r['caption'] ?: $r['title']), 'place' => (string) ($r['tag_place'] ?: $r['place_label']),
                      'url' => '/journeys/view.php?id=' . (int) $r['id'], 'author' => $au['name'], 'author_kind' => $au['kind'],
                      'author_id' => $au['kind'] === 'person' ? $au['id'] : 0, 'views' => (int) $r['views'], 'likes' => (int) $r['likes'], 'comments' => (int) $r['comments']];
            if (count($out) >= $n) break;
        }
        return $out;
    }

    /**
     * Top contributors: trust score from recent well-received journeys (90 days), journeys without upheld reports,
     * account age and a verified email (decisions/0056 §3). Private profiles never appear. Each with what they make.
     */
    public static function topContributors(PDO $pdo, string $scope = '', int $n = 9): array
    {
        if (!self::ready($pdo)) return [];
        $since = date('Y-m-d H:i:s', time() - 90 * 86400);
        $st = $pdo->prepare("SELECT c.user_id, u.created_at, u.email_verified_at,
                                    SUM(CASE WHEN j.published_at >= ? THEN 3 + j.likes + 2 * j.comments ELSE 1 END) AS pts,
                                    SUM(j.video_url <> '') AS videos, SUM(LENGTH(j.body) > 1200) AS writing,
                                    (SELECT COUNT(*) FROM journey_media m JOIN journeys j2 ON j2.id = m.journey_id WHERE j2.author_id = c.user_id AND j2.status = 'published') AS photos,
                                    (SELECT COUNT(*) FROM content_reports r JOIN journeys j3 ON j3.id = r.target_id WHERE r.kind = 'journey' AND r.status = 'removed' AND j3.author_id = c.user_id) AS upheld
                               FROM contributors c JOIN users u ON u.id = c.user_id JOIN journeys j ON j.author_id = c.user_id AND j.status = 'published' AND j.voice = 'contributor'" . (self::managed($pdo) ? ' AND j.entity_id IS NULL' : '')
                           . ($scope !== '' ? ' AND j.scope_keys LIKE ?' : '') . "
                              WHERE c.status = 'active' GROUP BY c.user_id, u.created_at, u.email_verified_at");
        $st->execute($scope !== '' ? [$since, '%|' . $scope . '|%'] : [$since]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            try { if (People::settings($pdo, (int) $r['user_id'])['profile_private']) continue; } catch (Throwable) {}
            $age = min(6, (time() - strtotime((string) $r['created_at'])) / (30 * 86400));
            $score = (float) $r['pts'] - 10 * (int) $r['upheld'] + $age + ($r['email_verified_at'] ? 2 : 0);
            $u = People::user($pdo, (int) $r['user_id']);
            if (!$u) continue;
            $makes = array_keys(array_filter(['video' => (int) $r['videos'], 'photo' => (int) $r['photos'], 'writing' => (int) $r['writing']]));
            $out[] = ['id' => (int) $r['user_id'], 'name' => People::name($u), 'score' => round($score, 1), 'makes' => $makes ?: ['writing']];
        }
        usort($out, fn ($a, $b) => $b['score'] <=> $a['score']);
        return array_slice($out, 0, $n);
    }

    // ---- likes, comments, views -------------------------------------------------------------------------------

    public static function liked(PDO $pdo, int $id, ?int $uid): bool
    {
        if (!$uid) return false;
        $st = $pdo->prepare('SELECT 1 FROM journey_likes WHERE journey_id = ? AND user_id = ?');
        $st->execute([$id, $uid]);
        return (bool) $st->fetchColumn();
    }

    public static function toggleLike(PDO $pdo, int $uid, int $id): bool
    {
        $j = self::get($pdo, $id);
        if (!$j || $j['status'] !== 'published') throw new InvalidArgumentException('That journey isn\'t available.');
        if (self::liked($pdo, $id, $uid)) { $pdo->prepare('DELETE FROM journey_likes WHERE journey_id = ? AND user_id = ?')->execute([$id, $uid]); $on = false; }
        else { $pdo->prepare('INSERT INTO journey_likes (journey_id, user_id, created_at) VALUES (?, ?, ?)')->execute([$id, $uid, self::now()]); $on = true; }
        self::recount($pdo, $id);
        return $on;
    }

    public static function comments(PDO $pdo, int $id, int $limit = 200): array
    {
        $st = $pdo->prepare("SELECT id, user_id, body, created_at FROM journey_comments WHERE journey_id = ? AND status = 'visible' ORDER BY created_at LIMIT " . max(1, $limit));
        $st->execute([$id]);
        return array_map(function ($c) use ($pdo) { $u = People::user($pdo, (int) $c['user_id']); return $c + ['name' => $u ? People::name($u) : 'Someone who left']; }, $st->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function comment(PDO $pdo, int $uid, int $id, string $body): int
    {
        require_once __DIR__ . '/Standing.php'; Standing::guard($pdo, $uid);   // limited accounts can't post or send (decisions/0079)
        AgeGate::require($pdo, $uid);
        $j = self::get($pdo, $id);
        if (!$j || $j['status'] !== 'published') throw new InvalidArgumentException('That journey isn\'t available.');
        $body = mb_substr(trim(strip_tags($body)), 0, 2000);
        if ($body === '') throw new InvalidArgumentException('Write a comment first.');
        if ($p = ListingSafety::contentProblem($body)) throw new InvalidArgumentException('That comment can\'t be posted: ' . $p . '.');
        $st = $pdo->prepare('SELECT COUNT(*) FROM journey_comments WHERE user_id = ? AND created_at >= ?');
        $st->execute([$uid, date('Y-m-d H:i:s', time() - 3600)]);
        if ((int) $st->fetchColumn() >= 30) throw new InvalidArgumentException('That\'s a lot of comments for one hour. Try again later.');
        $pdo->prepare('INSERT INTO journey_comments (journey_id, user_id, body, created_at) VALUES (?, ?, ?, ?)')->execute([$id, $uid, $body, self::now()]);
        $cid = (int) $pdo->lastInsertId();
        self::recount($pdo, $id);
        return $cid;
    }

    public static function removeComment(PDO $pdo, int $uid, int $commentId): void
    {
        $st = $pdo->prepare('SELECT c.user_id, c.journey_id, j.author_id FROM journey_comments c JOIN journeys j ON j.id = c.journey_id WHERE c.id = ?');
        $st->execute([$commentId]);
        $c = $st->fetch(PDO::FETCH_ASSOC);
        // the commenter, the journey's author, or staff who look after journeys
        if (!$c || ($uid !== (int) $c['user_id'] && $uid !== (int) $c['author_id'] && !self::staffCan($pdo, $uid, 'journeys'))) throw new InvalidArgumentException('That comment isn\'t yours to remove.');
        $pdo->prepare('DELETE FROM journey_comments WHERE id = ?')->execute([$commentId]);
        self::recount($pdo, (int) $c['journey_id']);
    }

    /** Count a view once a day per person (or device). */
    public static function view(PDO $pdo, int $id, string $viewer): void
    {
        try {
            $st = $pdo->prepare('INSERT INTO journey_views (journey_id, viewer, day) VALUES (?, ?, ?)');
            $st->execute([$id, hash('sha256', 'jv|' . $viewer), date('Y-m-d')]);
            $pdo->prepare('UPDATE journeys SET views = views + 1 WHERE id = ?')->execute([$id]);
        } catch (PDOException) {}   // already counted today
    }

    private static function recount(PDO $pdo, int $id): void
    {
        $pdo->prepare("UPDATE journeys SET likes = (SELECT COUNT(*) FROM journey_likes WHERE journey_id = ?),
                                           comments = (SELECT COUNT(*) FROM journey_comments WHERE journey_id = ? AND status = 'visible') WHERE id = ?")->execute([$id, $id, $id]);
    }

    /** A person's journeys (theirs to manage), newest first. */
    // ---- journey management (Admin → Journeys, decisions/0058 §2) ----------------------------------------------

    public const VIEWS = ['waiting' => 'Waiting for an editor', 'traversence' => 'Traversence', 'contributors' => 'Contributors', 'reported' => 'Reported', 'hidden' => 'Hidden'];

    /** One management view: rows with author, status, counts and open reports. Contributors' drafts are never listed. */
    public static function manage(PDO $pdo, string $view, string $q = '', int $limit = 100): array
    {
        $m = self::managed($pdo);
        $where = match ($view) {
            'waiting'      => $m ? "j.voice = 'traversence' AND j.status = 'draft' AND j.submitted_at IS NOT NULL" : '1 = 0',
            'traversence'  => "j.voice = 'traversence'",
            'reported'     => "j.status <> 'draft' AND EXISTS (SELECT 1 FROM content_reports r WHERE r.kind = 'journey' AND r.target_id = j.id AND r.status = 'open')",
            'hidden'       => "j.status = 'hidden'",
            default        => "j.voice = 'contributor' AND j.status = 'published'",
        };
        $args = [];
        if (trim($q) !== '') { $where .= " AND j.title LIKE ? ESCAPE '!'"; $args[] = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], trim($q)) . '%'; }
        $st = $pdo->prepare("SELECT j.*, (SELECT COUNT(*) FROM content_reports r WHERE r.kind = 'journey' AND r.target_id = j.id AND r.status = 'open') AS reports
                               FROM journeys j WHERE $where ORDER BY " . ($view === 'waiting' && $m ? 'j.submitted_at' : 'j.updated_at DESC') . ' LIMIT ' . max(1, $limit));
        $st->execute($args);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $j) {
            $au = self::author($pdo, $j);
            $w = People::user($pdo, (int) $j['author_id']);
            $out[] = $j + ['shown_as' => $au['name'], 'shown_kind' => $au['kind'], 'writer' => $w ? People::name($w) : 'Someone who left'];
        }
        return $out;
    }

    /** How many in each view, for the tabs. */
    public static function manageCounts(PDO $pdo): array
    {
        $c = [];
        foreach (array_keys(self::VIEWS) as $v) $c[$v] = count(self::manage($pdo, $v, '', 500));
        return $c;
    }

    /** An editor publishes a Traversence piece, or takes it back to a draft. */
    public static function setEditorial(PDO $pdo, int $uid, int $id, bool $publish): void
    {
        $j = self::get($pdo, $id);
        if (!$j || $j['voice'] !== 'traversence') throw new InvalidArgumentException('Only Traversence pieces are published here.');
        if (!self::staffCan($pdo, $uid, 'publish')) throw new InvalidArgumentException('Publishing needs an Editor.');
        if ($publish && mb_strlen(trim((string) $j['body'])) < 40) throw new InvalidArgumentException('It needs a few sentences before it can be published.');
        $pdo->prepare("UPDATE journeys SET status = ?, published_at = CASE WHEN ? = 'published' THEN COALESCE(published_at, ?) ELSE published_at END, updated_at = ? WHERE id = ?")
            ->execute([$publish ? 'published' : 'draft', $publish ? 'published' : 'draft', self::now(), self::now(), $id]);
        if (self::managed($pdo)) $pdo->prepare('UPDATE journeys SET submitted_at = NULL WHERE id = ?')->execute([$id]);
    }

    /**
     * Published journeys as feed cards, for a profile or a listing (decisions/0058 §1): by a person (as themselves),
     * by a listing's team, or mentioning a listing.
     */
    public static function cardsFor(PDO $pdo, string $kind, int $id, int $limit = 12): array
    {
        if (!self::ready($pdo) || $id <= 0) return [];
        $m = self::managed($pdo);
        [$where, $args] = match ($kind) {
            'person'   => ["((j.author_id = ? AND j.voice = 'contributor'" . ($m ? ' AND j.entity_id IS NULL' : '') . ')'
                           . (self::detailed($pdo) ? " OR j.id IN (SELECT journey_id FROM journey_coauthors WHERE user_id = ? AND status = 'accepted')" : '') . ')', self::detailed($pdo) ? [$id, $id] : [$id]],
            'listing'  => $m ? ['j.entity_id = ?', [$id]] : ['1 = 0', []],
            'mentions' => ["(',' || j.listings || ',') LIKE ?" . ($m ? ' AND (j.entity_id IS NULL OR j.entity_id <> ?)' : ''), $m ? ['%,' . $id . ',%', $id] : ['%,' . $id . ',%']],
            default    => ['1 = 0', []],
        };
        if ($kind === 'mentions') $where = str_replace("(',' || j.listings || ',')", "CONCAT(',', j.listings, ',')", $where);
        $st = $pdo->prepare("SELECT j.*, (SELECT card_path FROM journey_media x WHERE x.journey_id = j.id ORDER BY x.sort, x.id LIMIT 1) AS card
                               FROM journeys j WHERE j.status = 'published' AND $where ORDER BY j.published_at DESC LIMIT " . max(1, $limit));
        $st->execute($args);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $j) {
            $au = self::author($pdo, $j);
            $out[] = ['type' => 'journey', 'id' => (int) $j['id'], 'voice' => $j['voice'], 'title' => (string) $j['title'], 'category' => (string) $j['category'],
                      'url' => '/journeys/view.php?id=' . (int) $j['id'], 'image' => (string) ($j['card'] ?? ''), 'place' => (string) $j['place_label'],
                      'author' => $au['name'], 'author_kind' => $au['kind'], 'author_id' => $au['kind'] === 'person' ? $au['id'] : 0,
                      'date' => (string) $j['published_at'], 'minutes' => self::readMinutes((string) $j['body']), 'views' => (int) $j['views'], 'likes' => (int) $j['likes'],
                      'comments' => (int) $j['comments'], 'video' => $j['video_url'] !== '', 'partnership' => (bool) $j['partnership'], 'mature' => !empty($j['mature'])];
        }
        return $out;
    }

    /** Your own journeys (contributor voice; Traversence pieces live in Admin → Journeys). */
    public static function mine(PDO $pdo, int $uid): array
    {
        $st = $pdo->prepare("SELECT id, title, category, status, voice, " . (self::managed($pdo) ? 'entity_id' : 'NULL AS entity_id') . ", author_id, place_label, views, likes, comments, updated_at, hidden_reason
                               FROM journeys WHERE author_id = ? AND voice = 'contributor' ORDER BY updated_at DESC");
        $st->execute([$uid]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
