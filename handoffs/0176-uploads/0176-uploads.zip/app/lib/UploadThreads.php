<?php
// app/lib/UploadThreads.php — people's uploads as threads for our staff (decisions/0176 §6, A6; release 4). Each upload
// target that tells staff names its thread here (upload-targets.php 'thread' and 'land'): its Notify kind, who's told,
// its facts and the spot its button opens, in the side panel (0176 §5).
//   - A photo of a place: a journey, live at once (post first, Journeys.php): "New photo of <place>", one thread per
//     journey, raised when its photos go live (it publishes, or a photo is added to a published journey), with Open it,
//     Hide (the journey workflow's Hide, its reason shown to the author) and Show again. A report on it joins the same
//     thread (A1: one thread per thing), with the report workflow's Take it down and Leave it up.
//   - An order file: "New artwork on Order #N", one thread per order, with Open the order (its Files). Ask for a new
//     file, the file check and Replace file are to come (0176 Question 3: Jason sets the check's limits).
// Who's told is who is already told today: the place photo's, the safety team (Pulse's Reports rows, 'safety'); the
// order file's, the order's team (upload-targets' $tvOrderStaff: 'backoffice/orders.edit'), never the uploader.
// Both kinds are level Notice and never push (Notify::NO_PUSH; 0176 "no new kinds of push").
declare(strict_types=1);

require_once __DIR__ . '/Thread.php';

final class UploadThreads
{
    public const ENDPOINT = '/api/upload-act.php';
    public const PLACE = 'upload.place_photo';
    public const ORDER = 'upload.order_file';
    /** The file check's parts still to come, greyed with this reason (0176 Question 3's answer, 2026-11-20). */
    public const LIMITS_SOON = 'To come: Jason sets the file check\'s minimum resolution, bleed and size (decisions/0176, Question 3)';
    public const ASK_SOON = 'Ask for a new file is to come (decisions/0176 §6)';

    private static function e($s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }
    private static function at(?string $t): string { $ts = $t ? strtotime($t) : false; return $ts ? '{t:' . gmdate('Y-m-d\TH:i:s\Z', $ts) . '}' : ''; }

    // ---- who's told -------------------------------------------------------------------------------------------------

    /** Active staff, as user ids, a test deciding each (from their staff_accounts row); never $except. */
    private static function staffWhere(PDO $pdo, callable $ok, int $except = 0): array
    {
        $out = [];
        try {
            require_once __DIR__ . '/Workspaces.php';
            foreach ($pdo->query('SELECT * FROM ' . Database::t('staff_accounts') . " WHERE status = 'active' AND user_id IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC) as $s)
                if ((int) $s['user_id'] !== $except && $ok($s)) $out[] = (int) $s['user_id'];
        } catch (Throwable $x) { error_log('upload threads staff: ' . $x->getMessage()); }
        return array_values(array_unique($out));
    }

    /** The safety team: who sees Pulse's Reports rows today (Pulse::SOURCES 'safety', Workspaces::allowsArea). */
    public static function safetyTeam(PDO $pdo, int $except = 0): array
    {
        require_once __DIR__ . '/Pulse.php';
        $area = (string) (Pulse::SOURCES['safety'][2] ?? 'safety');
        return self::staffWhere($pdo, fn (array $s) => Workspaces::allowsArea($s, $area, $pdo), $except);
    }

    /** The order's team: who may change orders (upload-targets' $tvOrderStaff, Access 'backoffice/orders.edit'), by its rule. */
    public static function orderTeam(PDO $pdo, int $except = 0): array
    {
        require_once __DIR__ . '/../admin/Access.php';
        $r = Access::rule('backoffice/orders.edit', ['min' => 'staff', 'depts' => ['fin', 'svc', 'sal']]);
        return self::staffWhere($pdo, function (array $s) use ($r): bool {
            [$lv, $dep] = Workspaces::levelOf($s); $rank = Access::RANK[$lv] ?? 0;
            return $rank >= Access::RANK['executive'] || ($rank >= (Access::RANK[$r['min']] ?? 2) && (!$r['depts'] || in_array($dep, $r['depts'], true)));
        }, $except);
    }

    // ---- a photo of a place ---------------------------------------------------------------------------------------------

    /** Its place, in words: the journey's place, else a photo's tagged place, else its title. */
    public static function placeOf(PDO $pdo, array $j): string
    {
        $p = trim((string) ($j['place_label'] ?? ''));
        if ($p === '') { try { $st = $pdo->prepare("SELECT tag_place FROM journey_media WHERE journey_id = ? AND tag_place <> '' ORDER BY sort, id LIMIT 1"); $st->execute([(int) $j['id']]); $p = trim((string) ($st->fetchColumn() ?: '')); } catch (Throwable $x) {} }
        return $p !== '' ? $p : trim((string) $j['title']);
    }

    private static function photos(PDO $pdo, int $jid): int
    {
        try { $st = $pdo->prepare('SELECT COUNT(*) FROM journey_media WHERE journey_id = ?'); $st->execute([$jid]); return (int) $st->fetchColumn(); } catch (Throwable $x) { return 0; }
    }

    /** Its open reports, newest first. */
    private static function reports(PDO $pdo, int $jid): array
    {
        try { $st = $pdo->prepare("SELECT id, reason, note, created_at FROM content_reports WHERE kind = 'journey' AND target_id = ? AND status = 'open' ORDER BY created_at DESC, id DESC LIMIT 10"); $st->execute([$jid]); return $st->fetchAll(PDO::FETCH_ASSOC); }
        catch (Throwable $x) { return []; }
    }

    /** Whether a journey's photos have a staff thread (so its reports join it instead of a row of their own). */
    public static function hasPlaceThread(PDO $pdo, int $jid): bool
    {
        try { $st = $pdo->prepare('SELECT 1 FROM comms_messages WHERE kind IN (?, ?) AND thing = ? LIMIT 1'); $st->execute([self::PLACE, self::PLACE . '.reported', 'journey:' . $jid]); return (bool) $st->fetchColumn(); }
        catch (Throwable $x) { return false; }
    }

    /**
     * The thread for a journey's photos, raised or updated in place: when its photos go live (it publishes with photos, or
     * a photo is added to a published journey), and when it's reported (the same thread, unread again). Nothing for a
     * draft, a hidden journey or one without photos. Never throws; returns how many staff it reached.
     */
    public static function placePhoto(PDO $pdo, int $jid, int $by = 0, bool $reported = false, bool $refresh = false): int
    {
        try {
            require_once __DIR__ . '/Journeys.php'; require_once __DIR__ . '/Notify.php';
            $j = Journeys::get($pdo, $jid);
            if (!$j || (!$reported && !$refresh && $j['status'] !== 'published') || !self::photos($pdo, $jid)) return 0;
            if ($refresh && !self::hasPlaceThread($pdo, $jid)) return 0;   // after a button: only a thread that's there
            $n = self::photos($pdo, $jid); $place = self::placeOf($pdo, $j);
            $title = 'New photo' . ($n === 1 ? '' : 's') . ' of ' . $place . ($n === 1 ? '' : ' (' . $n . ')');
            $rep = self::reports($pdo, $jid);
            return Notify::send($pdo, $rep ? self::PLACE . '.reported' : self::PLACE, ['staff' => self::safetyTeam($pdo, $by)],
                ['thing' => 'journey:' . $jid, 'url' => '/journeys/view.php?id=' . $jid, 'from' => ['system', null, 'Journeys']],
                ['title' => $title . ($j['status'] === 'hidden' ? ': hidden' : ($rep ? ': reported' : '')), 'body' => Thread::text(self::placeFacts($pdo, $j), 'pulse')]);   // words follow the state (0176 §7)
        } catch (Throwable $x) { error_log('upload thread place ' . $jid . ': ' . $x->getMessage()); return 0; }
    }

    /** The journey's photos as one thread, read now (0176 §7). */
    public static function placeFacts(PDO $pdo, array $j): array
    {
        require_once __DIR__ . '/People.php';
        $jid = (int) $j['id']; $n = self::photos($pdo, $jid); $rep = self::reports($pdo, $jid);
        $author = ($u = People::user($pdo, (int) $j['author_id'])) ? People::name($u) : 'Someone who left';
        $hidden = $j['status'] === 'hidden';
        $status = $hidden ? 'Hidden since ' . self::at((string) $j['updated_at']) . ((string) ($j['hidden_reason'] ?? '') !== '' ? ': ' . $j['hidden_reason'] : '') . '. Its author still sees it, with the reason.'
            : ($j['status'] === 'published' ? 'Live since ' . self::at((string) ($j['published_at'] ?: $j['updated_at'])) . ', posted by ' . $author . '.' : 'A draft: not on the site.');
        if ($rep) $status .= ' ' . count($rep) . ' open report' . (count($rep) === 1 ? '' : 's') . ': ' . implode('; ', array_map(fn ($r) => str_replace('_', ' ', (string) $r['reason']) . ((string) $r['note'] !== '' ? ' ("' . mb_strimwidth((string) $r['note'], 0, 80, '…') . '")' : ''), $rep)) . '.';
        return ['title' => 'New photo' . ($n === 1 ? '' : 's') . ' of ' . self::placeOf($pdo, $j) . ($n === 1 ? '' : ' (' . $n . ')'),
                'level' => $hidden ? 'closed' : ($rep ? 'warning' : 'notice'), 'pill' => $hidden ? 'Hidden' : ($rep ? 'Reported' : 'Live'),
                'status' => $status, 'affects' => ['The journey "' . (string) $j['title'] . '" and its place\'s photos'],
                'doing' => 'Post first: a place\'s photo goes live at once, and reports come to this thread (decisions/0056, 0176 §6).',
                'todo' => $hidden ? '' : ($rep ? 'Look at the photos and the reports, then Take it down or Leave it up.' : 'Nothing, unless something\'s wrong: Hide takes it off the site, with a reason its author sees.'),
                'details' => [['Photos', (string) $n], ['Journey', '#' . $jid . ', ' . (string) $j['status']], ['Place', (string) ($j['place_key'] ?: 'none named')]]];
    }

    // ---- an order file --------------------------------------------------------------------------------------------------

    /** The order's files thread, raised or updated in place when a file is added (not a shipping label). Never throws. */
    public static function orderFile(PDO $pdo, int $oid, string $kind, int $by = 0): int
    {
        if ($kind === 'label') return 0;
        try {
            require_once __DIR__ . '/Notify.php';
            $o = self::order($pdo, $oid); if (!$o) return 0;
            $f = self::orderFacts($pdo, $o);
            return Notify::send($pdo, self::ORDER, ['staff' => self::orderTeam($pdo, $by)],
                ['thing' => 'order:' . $oid . ':files', 'url' => '/admin/backoffice/orders/' . $oid . '#docs', 'from' => ['system', null, 'Orders']],
                ['title' => $f['title'], 'body' => Thread::text($f, 'pulse')]);
        } catch (Throwable $x) { error_log('upload thread order ' . $oid . ': ' . $x->getMessage()); return 0; }
    }

    private static function order(PDO $pdo, int $oid): ?array
    {
        try { $st = $pdo->prepare('SELECT * FROM orders WHERE id = ?'); $st->execute([$oid]); return $st->fetch(PDO::FETCH_ASSOC) ?: null; } catch (Throwable $x) { return null; }
    }

    /** The order's files as one thread, read now. */
    public static function orderFacts(PDO $pdo, array $o): array
    {
        require_once __DIR__ . '/Orders.php'; require_once __DIR__ . '/ClientOrders.php';
        $oid = (int) $o['id'];
        // its rows only (ClientOrders::files also lists the storage for sizes: not needed to say what came)
        try { $st = $pdo->prepare("SELECT * FROM order_files WHERE order_id = ? AND kind <> 'label' ORDER BY id"); $st->execute([$oid]); $files = $st->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $x) { $files = []; }
        $last = $files ? end($files) : null;
        $words = $files ? implode('; ', array_map(fn ($x) => (string) ($x['file_name'] ?? 'a file') . ' (' . (ClientOrders::FILE_KINDS[(string) ($x['kind'] ?? '')] ?? (string) ($x['kind'] ?? 'file')) . ')', array_slice($files, -5))) : 'none yet';
        return ['title' => 'New artwork on Order #' . Orders::no($o), 'level' => 'notice', 'pill' => 'New',
                'status' => count($files) . ' file' . (count($files) === 1 ? '' : 's') . ' on the order' . ($last && !empty($last['created_at']) ? ', the latest ' . self::at((string) $last['created_at']) : '') . '.',
                'affects' => ['Order #' . Orders::no($o) . ': ' . $words], 'doing' => 'The file check (resolution, size and bleed) is to come: no file is checked yet.',
                'todo' => 'Open the order and look at its files; its proofs and approval are there.',
                'details' => [['Order', '#' . Orders::no($o) . ' (' . $oid . ')'], ['Files', (string) count($files)]]];
    }

    // ---- in Pulse ---------------------------------------------------------------------------------------------------

    /** Notify::BODIES: the thread inside its message, with its buttons, read now. */
    public static function pulseBody(PDO $pdo, array $m, int $viewer): array
    {
        $thing = (string) ($m['thing'] ?? ''); $msg = (int) ($m['id'] ?? 0);
        if (preg_match('/^journey:(\d+)$/', $thing, $mm)) {
            require_once __DIR__ . '/Journeys.php';
            $j = Journeys::get($pdo, (int) $mm[1]);
            if (!$j) return ['html' => '<p>Its author deleted this journey, so there\'s nothing to look at now.</p>', 'state' => 'Deleted by its author'];
            $f = self::placeFacts($pdo, $j); $jid = (int) $j['id']; $rep = self::reports($pdo, $jid);
            $b = '<a class="tv-btn" href="/journeys/view.php?id=' . $jid . '" data-peek-frame="' . self::e((string) $j['title']) . '">Open it</a> ';
            if ($j['status'] === 'hidden') $b .= self::btn('Show again', ['act' => 'show', 'journey' => $jid, 'msg' => $msg], ['confirm' => 'Show it on the site again?', 'yes' => 'Show again']);
            elseif ($j['status'] === 'published') {
                if ($rep) $b .= self::btn('Take it down', ['act' => 'report_remove', 'report' => (int) $rep[0]['id'], 'msg' => $msg], ['confirm' => 'Take it down? Its author still sees it, with "Hidden after reports"; Show again puts it back.', 'yes' => 'Take it down', 'danger' => true])
                              . self::btn('Leave it up', ['act' => 'report_dismiss', 'report' => (int) $rep[0]['id'], 'msg' => $msg], ['confirm' => 'Leave it up? The reports are closed as left up.', 'yes' => 'Leave it up']);
                $b .= '<form class="tv-mb-reply" data-msg-reply="' . self::ENDPOINT . '" data-msg-body=\'' . self::e(json_encode(['act' => 'hide', 'journey' => $jid, 'msg' => $msg])) . '\'>'
                    . '<input class="tv-in" name="body" maxlength="200" required data-spell placeholder="Why it\'s hidden (its author sees this)" aria-label="Why it\'s hidden">'
                    . '<button type="submit" class="tv-btn">Hide</button></form>';
            }
            return ['html' => Thread::html($f, 'pulse', $b), 'state' => (string) $f['pill']];
        }
        if (preg_match('/^order:(\d+):files$/', $thing, $mm)) {
            $o = self::order($pdo, (int) $mm[1]);
            if (!$o) return ['html' => '<p>This order is no longer kept.</p>', 'state' => 'Gone'];
            $f = self::orderFacts($pdo, $o);
            $b = '<a class="tv-btn" href="/admin/backoffice/orders/' . (int) $o['id'] . '#docs" data-peek-frame="Order #' . self::e(Orders::no($o)) . '">Open the order</a> '
               . '<button type="button" class="tv-btn" disabled title="' . self::e(self::ASK_SOON) . '">Ask for a new file</button><small class="tv-fix-soon">' . self::e(self::ASK_SOON) . '.</small> '
               . '<button type="button" class="tv-btn" disabled title="' . self::e(self::LIMITS_SOON) . '">Check the files</button><small class="tv-fix-soon">' . self::e(self::LIMITS_SOON) . '.</small>';
            return ['html' => Thread::html($f, 'pulse', $b), 'state' => 'New'];
        }
        return ['html' => '<p>Nothing to show.</p>', 'state' => ''];
    }

    private static function btn(string $label, array $body, array $o): string
    {
        return '<button type="button" class="tv-btn' . (!empty($o['danger']) ? ' tv-btn-danger' : '') . '" data-msg-act="' . self::ENDPOINT . '" data-msg-body=\'' . self::e(json_encode($body)) . '\''
             . (!empty($o['confirm']) ? ' data-confirm="' . self::e($o['confirm']) . '" data-yes="' . self::e($o['yes'] ?? $label) . '"' . (!empty($o['danger']) ? ' data-danger' : '') : '') . '>' . self::e($label) . '</button> ';
    }

    /**
     * A button pressed inside the thread (/api/upload-act.php): each through its workflow, with its own permission
     * (Workflow::move: the journey's Hide and Restore; the report's Take it down and Leave it up). Returns [what to say,
     * the message's body drawn again]. Unknown or not allowed: an InvalidArgumentException with the reason.
     */
    public static function act(PDO $pdo, int $uid, array $in): array
    {
        require_once __DIR__ . '/../admin/Workflow.php';
        $act = (string) ($in['act'] ?? '');
        try {
            if ($act === 'hide') {
                $why = mb_substr(trim(strip_tags((string) ($in['body'] ?? ''))), 0, 200);
                if ($why === '') throw new InvalidArgumentException('Say why it\'s hidden. Its author sees the reason.');
                Workflow::move($pdo, 'journey', (int) ($in['journey'] ?? 0), 'hide', ['note' => $why], $uid); $said = 'Hidden. Its author still sees it, with your reason; Show again puts it back.';
            } elseif ($act === 'show') { Workflow::move($pdo, 'journey', (int) ($in['journey'] ?? 0), 'restore', [], $uid); $said = 'It\'s on the site again.'; }
            elseif ($act === 'report_remove' || $act === 'report_dismiss') {
                Workflow::move($pdo, 'report', (int) ($in['report'] ?? 0), $act === 'report_remove' ? 'remove' : 'dismiss', [], $uid);
                $said = $act === 'report_remove' ? 'Taken down: its author still sees it, with "Hidden after reports". Show again puts it back.' : 'Left up: its reports are closed.';
            } else throw new InvalidArgumentException('Unknown step.');
        } catch (RuntimeException $x) { throw new InvalidArgumentException($x->getMessage()); }
        // the thread's title follows where it stands now, on every staff member's Pulse (0176 §7)
        $jid = (int) ($in['journey'] ?? 0);
        if (!$jid && ($rid = (int) ($in['report'] ?? 0))) { try { $st = $pdo->prepare("SELECT target_id FROM content_reports WHERE id = ? AND kind = 'journey'"); $st->execute([$rid]); $jid = (int) $st->fetchColumn(); } catch (Throwable $x) {} }
        if ($jid) self::placePhoto($pdo, $jid, 0, false, true);
        $html = '';
        if (($msg = (int) ($in['msg'] ?? 0)) > 0) {
            try { $st = $pdo->prepare('SELECT * FROM comms_messages WHERE id = ? AND to_user = ?'); $st->execute([$msg, $uid]); if ($m = $st->fetch(PDO::FETCH_ASSOC)) $html = self::pulseBody($pdo, $m, $uid)['html']; } catch (Throwable $x) {}
        }
        return [$said, $html];
    }
}
