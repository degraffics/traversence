<?php
// app/lib/crawler/OpenLoads.php — The open-dataset loads for Arizona and New Mexico (decisions/0164 §1.5, §3.5; 0163 §8
// stage 8, §12's lead order): Overture Maps Places as the base layer, Foursquare's open places where Overture doesn't
// already carry its record, and Geofabrik's state files for OpenStreetMap (the first step: one test download from the
// Railway worker). The worker reads each town's box (DuckDB over the public files) and sends the records here; this side:
//   - keeps what the licence allows: name, street, phone, website, category, the record's id, its sources and licences,
//     with credit; never emails (decisions/0164 §1.5), never a closed record as a listing (a closure signal instead)
//   - folds the batch (ListingIdentity::fold), drops what's already listed (the one identity check), and stages the rest
//     through the crawler's one pipeline, so the floor (§3.5), readiness and the identity check decide each one
//   - runs the identity recheck at once on the listings the load touched (0163 §12: "the recheck after a load"), straight
//     after the batch's reply (IR-0001, 2026-11-24: 500 rows took 101–130 s against the worker's 120 s read)
//   - each batch carries its number: one taken again answers what it did and does nothing (open_load_batches)
// Towns go in order of our coverage gap: the fewest listings we have first (Kayenta has 0; Run 2).
// Shipped off: each load is a W1 task added disabled, its service paused (Operations::ADDED_OFF), under the master switch.
declare(strict_types=1);

require_once __DIR__ . '/../Database.php';

final class OpenLoads
{
    public const DATASETS = [
        'overture' => ['Overture Maps Places', 'overture_bulk', 'https://docs.overturemaps.org/attribution/'],
        'foursquare' => ['Foursquare open places', 'foursquare_bulk', 'https://huggingface.co/datasets/foursquare/fsq-os-places'],
    ];
    public const STATES = ['AZ', 'NM'];
    /** A town's box around its middle, in degrees (about 7 km each way). */
    private const BOX = [0.065, 0.08];

    public static function ready(PDO $pdo): bool
    {
        try { $pdo->query('SELECT 1 FROM open_loads LIMIT 0'); return true; } catch (Throwable) { return false; }
    }

    /** The load tasks on the switches (W1), added off; site-side bookkeeping, the worker does the reading. */
    public static function ensureTasks(PDO $pdo): void
    {
        require_once __DIR__ . '/../ListingIdentity.php';
        foreach (self::DATASETS as $ds => [$name, $task]) ListingIdentity::ensureTask($pdo, $task, 'W1', 'bulk', $name . ': load by town', 'A town\'s records from ' . $name . ' through the one identity check (decisions/0164 §1.5).', 3, 1440);
        ListingIdentity::ensureTask($pdo, 'geofabrik_bulk', 'W1', 'bulk', 'Geofabrik: OpenStreetMap by state', 'The OpenStreetMap files of Arizona, New Mexico, Utah, Colorado and Nevada, weekly (its first run is one test download).', 1, 10080);
    }

    /** Why a dataset's load may not run now, or null. */
    public static function off(PDO $pdo, string $ds): ?string
    {
        require_once __DIR__ . '/../Automation.php';
        if (($w = Automation::masterOff($pdo)) !== null) return $w;
        if (($w = Automation::wfOff($pdo, 'W1')) !== null) return $w;
        if (($w = Automation::serviceOff($pdo, $ds)) !== null) return $w;
        $task = self::DATASETS[$ds][1] ?? ($ds === 'geofabrik' ? 'geofabrik_bulk' : '');
        try { $st = $pdo->prepare('SELECT enabled FROM crawl_capture_tasks WHERE task = ?'); $st->execute([$task]); if (!(int) $st->fetchColumn()) return 'Its load task (' . $task . ', W1) is switched off.'; } catch (Throwable) { return 'The task list isn\'t there yet.'; }
        if (($w = Automation::sysAny($pdo, ['master:all', 'wf:W1', 'service:' . $ds, 'task:' . $task])) !== null) return $w;   // paused by the system: a trip (decisions/0175)
        return null;
    }

    /** The next towns due for a dataset's release, the biggest gap first: [{key, name, state, zip, box: [x0, y0, x1, y1]}]. */
    public static function due(PDO $pdo, string $ds, string $release, int $n = 3): array
    {
        $out = [];
        $rows = $pdo->query("SELECT mc.id, mc.name, mc.primary_zip, z.latitude, z.longitude, z.state,
                                    (SELECT COUNT(*) FROM entities e WHERE e.primary_zip = mc.primary_zip AND e.is_suppressed = 0) AS listed
                               FROM micro_clusters mc JOIN zip_coordinates z ON z.zip = mc.primary_zip
                              ORDER BY listed, mc.id")->fetchAll(PDO::FETCH_ASSOC);
        $done = $pdo->prepare('SELECT 1 FROM open_loads WHERE dataset = ? AND place_key = ? AND release_id = ? AND finished_at IS NOT NULL');
        foreach ($rows as $r) {
            if (!in_array(strtoupper((string) ($r['state'] ?? '')), self::STATES, true)) continue;
            $key = 'cluster:' . (int) $r['id'];
            $done->execute([$ds, $key, $release]);
            if ($done->fetchColumn()) continue;
            $la = (float) $r['latitude']; $lo = (float) $r['longitude'];
            $out[] = ['key' => $key, 'name' => (string) $r['name'], 'state' => strtoupper((string) $r['state']), 'zip' => (string) $r['primary_zip'], 'listed' => (int) $r['listed'],
                      'box' => [round($lo - self::BOX[1], 4), round($la - self::BOX[0], 4), round($lo + self::BOX[1], 4), round($la + self::BOX[0], 4)]];
            if (count($out) >= $n) break;
        }
        return $out;
    }

    /**
     * One town's records from the worker. $rows: [{id, name, street, city, state, zip, phone, website, category, confidence,
     * lat, lng, status, sources: [[dataset, licence]]}]. Returns ['seen', 'staged', 'listed', 'closed', 'skipped', 'duplicates',
     * 'already_known']: every record seen is skipped, closed, folded into a twin in the batch (duplicates), already known to the
     * intake, or staged, so the ledger's received adds up (W1's "received 100, accounted for 80", 2026-11-24). 'listed' is a
     * part of staged (a listed one still stages), never added again.
     */
    public static function batch(PDO $pdo, string $ds, string $release, string $key, array $rows, ?int $no = null, ?array &$recheck = null): array
    {
        $out = ['seen' => 0, 'staged' => 0, 'listed' => 0, 'closed' => 0, 'skipped' => 0, 'duplicates' => 0, 'already_known' => 0];
        if (!isset(self::DATASETS[$ds])) throw new InvalidArgumentException('Unknown dataset.');
        // a batch already taken answers what it did then, and does nothing (IR-0001: a reply that reached the worker too late
        // is sent again; resent, it must not stage or count twice)
        if ($no !== null && ($was = self::batchDone($pdo, $ds, $release, $key, $no)) !== null) return $was + ['again' => true];
        require_once __DIR__ . '/../ListingIdentity.php'; require_once __DIR__ . '/../DataCleanup.php'; require_once __DIR__ . '/IntakeStager.php'; require_once __DIR__ . '/CrawlQueue.php';
        $cands = [];
        foreach (array_slice($rows, 0, 2000) as $r) {
            $out['seen']++;
            $name = trim((string) ($r['name'] ?? ''));
            if ($name === '' || DataCleanup::junkName($name)[0]) { $out['skipped']++; continue; }
            $state = strtoupper(substr((string) ($r['state'] ?? ''), 0, 2));
            if ($state !== '' && !in_array($state, self::STATES, true)) { $out['skipped']++; continue; }
            $phone = ListingIdentity::phoneKey((string) ($r['phone'] ?? ''));
            $street = trim((string) ($r['street'] ?? ''));
            $closed = in_array(strtolower((string) ($r['status'] ?? '')), ['permanently_closed', 'closed'], true) || trim((string) ($r['date_closed'] ?? '')) !== '';
            if ($closed) {   // a closure signal against a listing we have (−40, 0163 §12), never a new listing
                $m = ListingIdentity::resolve($pdo, ['name' => $name, 'address' => $street, 'zip' => (string) ($r['zip'] ?? ''), 'phone' => $phone]);
                if ($m['kind'] === 'same') { self::closureSignal($pdo, $m['id'], $ds); $out['closed']++; } else $out['skipped']++;
                continue;
            }
            $lic = []; foreach ((array) ($r['sources'] ?? []) as $s) { $s = (array) $s; $lic[] = trim((string) ($s[0] ?? '')) . ':' . trim((string) ($s[1] ?? '')); }
            $url = $ds === 'overture' ? 'https://explore.overturemaps.org/#/place/' . rawurlencode((string) ($r['id'] ?? '')) : 'https://foursquare.com/v/' . rawurlencode((string) ($r['id'] ?? ''));
            $conf = (float) ($r['confidence'] ?? 0.5);
            $c = CrawlQueue::normalize([
                'name' => $name,
                'source' => ['start_url' => $url, 'site' => $ds === 'overture' ? 'overturemaps.org' : 'foursquare.com', 'kind' => $ds === 'overture' ? 'overture' : 'foursquare_os', 'record' => (string) ($r['id'] ?? ''),
                             'release' => $release, 'licences' => array_values(array_unique($lic)), 'credit' => self::DATASETS[$ds][0], 'crawled_at' => gmdate('Y-m-d\TH:i:s\Z')],
                'where' => ['address' => $street, 'city' => (string) ($r['city'] ?? ''), 'state' => $state, 'zip' => substr(preg_replace('/\D/', '', (string) ($r['zip'] ?? '')), 0, 5)],
                'what' => ['offerings' => array_values(array_filter([(string) ($r['category'] ?? '')])), 'description' => ''],
                'when' => ['hours' => []],
                'actions' => ['phone' => $phone !== '' ? substr($phone, 0, 3) . '-' . substr($phone, 3, 3) . '-' . substr($phone, 6) : '', 'website' => (string) ($r['website'] ?? '')],
                'sources' => array_filter(['name' => [$url], 'address' => $street !== '' ? [$url] : [], 'phone' => $phone !== '' ? [$url] : []]),
                'corroboration' => [], 'confidence' => (int) round(30 + 30 * min(1, $conf)),   // under 0.5 Overture confidence counts half (0163 §12)
            ]);
            if (!$c) { $out['skipped']++; continue; }
            // kept after the intake's shape (CrawlQueue::normalize keeps only its own keys): the dataset's own point, its record
            // id, release, licences and credit (R9: each record's licence kept with it)
            $c['source'] += ['kind' => '', 'record' => (string) ($r['id'] ?? ''), 'release' => $release, 'licences' => array_values(array_unique($lic)), 'credit' => self::DATASETS[$ds][0]];
            $c['source']['kind'] = $ds === 'overture' ? 'overture' : 'foursquare_os';   // AutoImport::OPEN_DATASETS: a source we may keep
            if (is_numeric($r['lat'] ?? null) && is_numeric($r['lng'] ?? null)) $c['where']['point'] = ['lat' => (float) $r['lat'], 'lon' => (float) $r['lng']];
            $cands[] = $c;
        }
        $n = count($cands); $cands = ListingIdentity::fold($cands); $out['duplicates'] = $n - count($cands);   // folded into a twin in this batch
        $new = [];
        foreach ($cands as $c) { $m = ListingIdentity::resolve($pdo, $c); if (in_array($m['kind'], ['same', 'covered'], true)) { $out['listed']++; $touched[] = $m['id']; } $new[] = $c; }   // listed ones still stage: their source joins the listing's identity (R11)
        $touched = $touched ?? [];
        if ($new) {
            $src = self::sourceId($pdo, $ds);
            $r = IntakeStager::stage($pdo, $src, $new);
            $out['staged'] = count($r['staged']) + count($r['auto_imported']);
            $out['already_known'] = (int) ($r['already_known'] ?? 0);   // the same content the intake already has
            foreach ((array) $r['auto_imported'] as $a) if (is_array($a) && !empty($a['entity_id'])) $touched[] = (int) $a['entity_id'];
        }
        // the recheck after a load: the ids it touched, at once (0163 §12), while the recheck is on. With $recheck the caller runs
        // it straight after its reply (loads.php: the worker doesn't wait on it; the session manager, 2026-11-24)
        $touched = array_values(array_unique($touched));
        if (func_num_args() >= 7) $recheck = $touched;
        elseif ($touched) self::recheck($pdo, $touched);
        $pdo->prepare('INSERT INTO open_loads (dataset, place_key, release_id, started_at, seen, staged, listed, closed) VALUES (?, ?, ?, UTC_TIMESTAMP(), ?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE seen = seen + VALUES(seen), staged = staged + VALUES(staged), listed = listed + VALUES(listed), closed = closed + VALUES(closed)')
            ->execute([$ds, $key, mb_substr($release, 0, 40), $out['seen'], $out['staged'], $out['listed'], $out['closed']]);
        if ($no !== null) self::batchKeep($pdo, $ds, $release, $key, $no, $out);
        return $out;
    }

    /** The identity recheck on the listings a batch touched (0163 §12); never fails the load. */
    public static function recheck(PDO $pdo, array $ids): void
    {
        if (!$ids) return;
        require_once __DIR__ . '/../ListingIdentity.php';
        try { ListingIdentity::recheckTick($pdo, $ids); } catch (Throwable $x) { error_log('open load recheck: ' . $x->getMessage()); }
    }

    /** A batch already taken (open_load_batches): what it did, or null. No table yet: null (the batch runs as before). */
    private static function batchDone(PDO $pdo, string $ds, string $release, string $key, int $no): ?array
    {
        try { $st = $pdo->prepare('SELECT result FROM open_load_batches WHERE dataset = ? AND place_key = ? AND release_id = ? AND batch_no = ?');
              $st->execute([$ds, $key, mb_substr($release, 0, 40), $no]); $r = $st->fetchColumn(); } catch (Throwable $x) { return null; }
        $d = $r !== false ? json_decode((string) $r, true) : null;
        return is_array($d) ? $d : null;
    }

    private static function batchKeep(PDO $pdo, string $ds, string $release, string $key, int $no, array $out): void
    {
        try { $pdo->prepare('INSERT IGNORE INTO open_load_batches (dataset, place_key, release_id, batch_no, result, at) VALUES (?, ?, ?, ?, ?, UTC_TIMESTAMP())')
                  ->execute([$ds, $key, mb_substr($release, 0, 40), $no, json_encode($out)]); } catch (Throwable $x) { error_log('open load batch key: ' . $x->getMessage()); }
    }

    public static function finish(PDO $pdo, string $ds, string $release, string $key): void
    {
        $pdo->prepare('UPDATE open_loads SET finished_at = UTC_TIMESTAMP() WHERE dataset = ? AND place_key = ? AND release_id = ?')->execute([$ds, $key, $release]);
        // a state's extract: which kinds it was kept by, so W1 reads it before Overpass only for those (OpenPlaces::forJob)
        if ($ds === 'geofabrik' && isset(self::GEOFABRIK_STATES[$key])) { require_once __DIR__ . '/../OpenPlaces.php'; require_once __DIR__ . '/../SearchIndex.php'; SearchIndex::setState($pdo, 'open:geofabrik_sig:' . $key, OpenPlaces::copySignature()); }
        // "returns empty" (0163 §4): a bulk load's first empty run is flagged by Operations::empties from the ledger
    }

    /** Geofabrik's states (its file names) and which is due: one download every geofabrik_days a state, at most. */
    public const GEOFABRIK_STATES = ['arizona' => 'Arizona', 'new-mexico' => 'New Mexico', 'utah' => 'Utah', 'colorado' => 'Colorado', 'nevada' => 'Nevada'];   // UT, CO, NV: Jason, 2026-11-19

    public static function geofabrikDue(PDO $pdo): array
    {
        require_once __DIR__ . '/../Thresholds.php';
        require_once __DIR__ . '/../OpenPlaces.php'; require_once __DIR__ . '/../SearchIndex.php';
        $days = max(1, (int) Thresholds::get($pdo, 'geofabrik_days'));
        $out = [];
        $st = $pdo->prepare("SELECT MAX(finished_at) FROM open_loads WHERE dataset = 'geofabrik' AND place_key = ?");
        foreach (self::GEOFABRIK_STATES as $k => $name) {
            $st->execute([$k]); $last = $st->fetchColumn();
            // kept by today's kinds (OpenPlaces::copySignature): a state loaded before the crawler's kinds were kept is due at once
            $sig = ''; try { $sig = SearchIndex::state($pdo, 'open:geofabrik_sig:' . $k); } catch (Throwable $x) {}
            if ($last && strtotime($last . ' UTC') > time() - $days * 86400 && $sig === OpenPlaces::copySignature()) continue;
            $out[] = ['key' => $k, 'name' => $name, 'release' => gmdate('Y-m-d')];
        }
        return $out;
    }

    /** One batch of a state's extract: kept in OpenStreetMap's own table (OpenPlaces::keepExtract), counted on its load. */
    public static function geofabrikBatch(PDO $pdo, string $release, string $state, array $els): array
    {
        if (!isset(self::GEOFABRIK_STATES[$state])) throw new InvalidArgumentException('Which state?');
        $pdo->prepare('INSERT IGNORE INTO open_loads (dataset, place_key, release_id, started_at) VALUES (\'geofabrik\', ?, ?, UTC_TIMESTAMP())')->execute([$state, $release]);
        require_once __DIR__ . '/../OpenPlaces.php';
        $kept = OpenPlaces::keepExtract($pdo, array_slice($els, 0, 2000));
        $pdo->prepare("UPDATE open_loads SET seen = seen + ?, listed = listed + ? WHERE dataset = 'geofabrik' AND place_key = ? AND release_id = ?")->execute([count($els), $kept, $state, $release]);
        return ['seen' => count($els), 'kept' => $kept];
    }

    /** A closure signal from a dataset against a listing: recorded with its source, lowers confidence, asks "Still open?" (R12). */
    private static function closureSignal(PDO $pdo, int $id, string $ds): void
    {
        try {
            $pdo->prepare("INSERT INTO entity_metadata (entity_id, meta_key, meta_value, source_type, is_locked, created_at, updated_at) VALUES (?, 'closed_signal', ?, 'ai_crawler', 0, NOW(), NOW())
                           ON DUPLICATE KEY UPDATE meta_value = IF(is_locked = 1, meta_value, VALUES(meta_value)), updated_at = NOW()")
                ->execute([$id, json_encode(['line' => self::DATASETS[$ds][0] . ' marks it closed', 'url' => self::DATASETS[$ds][2], 'at' => date('Y-m-d'), 'from' => $ds], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
            require_once __DIR__ . '/../ListingConfidence.php'; ListingConfidence::refresh($pdo, $id);
        } catch (Throwable $x) { error_log('open load closure #' . $id . ': ' . $x->getMessage()); }
    }

    private static function sourceId(PDO $pdo, string $ds): int
    {
        $url = self::DATASETS[$ds][2];
        $st = $pdo->prepare('SELECT id FROM ' . Database::t('crawler_sources') . ' WHERE url = ? ORDER BY id LIMIT 1'); $st->execute([$url]);
        return (int) ($st->fetchColumn() ?: IntakeStager::createSource($pdo, $url, ['create_listings'], self::DATASETS[$ds][0] . ' (open data, credited)', 0));
    }

    // ---- Geofabrik: the first step is one test download from Railway (0163 §8 stage 8) --------------------------------

    /** The worker's test of Geofabrik: [{state, ok, status, bytes, why, at}], kept for the card and the switch-on check. */
    public static function probed(PDO $pdo, array $r): void
    {
        require_once __DIR__ . '/../SearchIndex.php';
        SearchIndex::setState($pdo, 'open:geofabrik_probe', json_encode(array_slice($r, 0, 4) + ['at' => gmdate('c')], JSON_UNESCAPED_SLASHES));
        foreach ($r as $x) if (is_array($x) && empty($x['ok'])) { require_once __DIR__ . '/../EngineCase.php'; EngineCase::raise($pdo, 'service', 'geofabrik', 'Geofabrik refused the Railway worker\'s test download (' . ($x['why'] ?? $x['status'] ?? '?') . '): use another free OpenStreetMap mirror, by hand, never repeated tries.', ['host' => 'download.geofabrik.de']); break; }
    }

    public static function lastProbe(PDO $pdo): ?array
    {
        try { require_once __DIR__ . '/../SearchIndex.php'; $v = json_decode(SearchIndex::state($pdo, 'open:geofabrik_probe'), true); return is_array($v) ? $v : null; } catch (Throwable) { return null; }
    }
}
