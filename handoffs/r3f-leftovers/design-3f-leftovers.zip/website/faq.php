<?php
// faq.php — Frequently asked questions. The content is includes/faq.md (the same file as faq.md in the docs repo),
// grown with every build so the FAQ never has to be reconstructed later. "## Topic", "### Question", answer below.
require_once __DIR__ . '/../app/ui/page-shell.php';

/** Inline Markdown: **bold**, [text](/path). Everything else is escaped. */
function faq_inline(string $s): string
{
    $s = tv_e($s);
    $s = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $s);
    return preg_replace_callback('/\[([^\]]+)\]\(([^)\s]+)\)/', function ($m) {
        $url = html_entity_decode($m[2], ENT_QUOTES);
        if (!preg_match('#^(/|https://|\#)#', $url)) return $m[1];
        return '<a href="' . tv_e($url) . '" class="underline">' . $m[1] . '</a>';
    }, $s);
}

function faq_slug(string $s): string
{
    return trim(preg_replace('/[^a-z0-9]+/', '-', strtolower(html_entity_decode(strip_tags($s)))), '-') ?: 'q';
}

/** @return list<array{topic: string, id: string, items: list<array{q: string, id: string, html: string, text: string}>}> */
function faq_load(string $file): array
{
    $md = (string) @file_get_contents($file);
    $md = preg_replace('/<!--.*?-->/s', '', $md);
    $topics = []; $t = -1; $q = -1; $block = []; $list = false;
    $flush = function () use (&$topics, &$t, &$q, &$block, &$list) {
        if ($t < 0 || $q < 0 || !$block) { $block = []; return; }
        $html = ''; $list = false;
        foreach ($block as $line) {
            if ($line === '') { if ($list) { $html .= '</ul>'; $list = false; } continue; }
            if (str_starts_with($line, '- ')) {
                if (!$list) { $html .= '<ul>'; $list = true; }
                $html .= '<li>' . faq_inline(substr($line, 2)) . '</li>';
            } else {
                if ($list) { $html .= '</ul>'; $list = false; }
                $html .= '<p>' . faq_inline($line) . '</p>';
            }
        }
        if ($list) $html .= '</ul>';
        $topics[$t]['items'][$q]['html'] = $html;
        $topics[$t]['items'][$q]['text'] .= ' ' . mb_strtolower(strip_tags($html));
        $block = [];
    };
    $used = [];
    foreach (preg_split('/\R/', $md) as $line) {
        $line = rtrim($line);
        if (str_starts_with($line, '## ')) {
            $flush(); $q = -1;
            $name = trim(substr($line, 3));
            $topics[++$t] = ['topic' => $name, 'id' => faq_slug($name), 'items' => []];
        } elseif (str_starts_with($line, '### ') && $t >= 0) {
            $flush();
            $text = trim(substr($line, 4));
            $id = faq_slug($text); $id = substr($id, 0, 60); $base = $id; $n = 2;
            while (isset($used[$id])) $id = $base . '-' . $n++;
            $used[$id] = true;
            $topics[$t]['items'][] = ['q' => $text, 'id' => $id, 'html' => '', 'text' => mb_strtolower($text)];
            $q = count($topics[$t]['items']) - 1;
        } elseif ($q >= 0) {
            $block[] = ltrim($line) === '' ? '' : $line;
        }
    }
    $flush();
    return array_values(array_filter($topics, fn ($x) => $x['items']));
}

$topics = faq_load(__DIR__ . '/../app/ui/faq.md');
tv_page_start('Frequently asked questions', ['description' => 'Answers about exploring, the directory, journeys, photos, privacy and how Traversence works.']);
// the switch test (decisions/0145 §6): a line only whoever the switch is on for sees, to check switches work
$switchOn = false;
if (is_file(__DIR__ . '/../app/lib/Switches.php')) { require_once __DIR__ . '/../app/lib/Database.php'; require_once __DIR__ . '/../app/lib/Switches.php'; try { $switchOn = Switches::on(Database::connection(), 'switch_test'); } catch (Throwable) {} }
?>
<?php if ($switchOn): ?><p data-tv-status="info" data-tv-label="Switch test:" id="switch-test">The test switch is on for you.</p><?php endif; ?>
<style>
  .faq{max-width:48rem;margin:0 auto;color:var(--tv-ink,#3E2B1F)}
  .faq h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:2rem;line-height:1.15}
  .faq-lead{color:var(--tv-meta,#5C4632);margin-top:.4rem}
  .faq-find{position:relative;margin:1rem 0 .6rem}
  .faq-find input{width:100%;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);border-radius:.8rem;padding:.65rem .9rem;font-size:.95rem;color:var(--tv-ink,#3E2B1F)}
  .faq-find input:focus{outline:2px solid #B8863B;outline-offset:1px}
  .faq-topics{display:flex;flex-wrap:wrap;gap:.4rem;margin-bottom:1rem}
  .faq-topics a{font-size:.8rem;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;padding:.2rem .7rem;background:var(--tv-sec,#F7EFDC);color:var(--tv-ink,#3E2B1F);text-decoration:none}
  .faq-topics a:hover{background:var(--tv-canvas,#EFE3C8)}
  .faq-sec{margin-top:1.4rem;scroll-margin-top:5rem}
  .faq-sec h2{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.25rem;margin-bottom:.5rem}
  .faq details{background:var(--tv-sec,#F7EFDC);border:1px solid rgba(203,185,141,.7);border-radius:.9rem;margin-bottom:.5rem;scroll-margin-top:5rem}
  .faq summary{cursor:pointer;list-style:none;padding:.7rem 2.2rem .7rem .95rem;font-weight:600;position:relative}
  .faq summary::-webkit-details-marker{display:none}
  .faq summary::after{content:'+';position:absolute;right:.95rem;top:.55rem;font-size:1.2rem;color:var(--tv-meta,#8A7355)}
  .faq details[open] summary::after{content:'–'}
  .faq-a{padding:0 .95rem .85rem;font-size:.94rem;line-height:1.6}
  .faq-a p+p,.faq-a ul+p,.faq-a p+ul{margin-top:.5rem}
  .faq-a ul{list-style:disc;padding-left:1.25rem}
  .faq-a li+li{margin-top:.2rem}
  .faq-link{float:right;font-size:.75rem;color:var(--tv-meta,#8A7355);text-decoration:none;margin-left:.5rem}
  .faq-none{display:none;background:var(--tv-card-a,#FFFBF2);border:1px dashed var(--tv-line-strong,#CBB98D);border-radius:.9rem;padding:1rem;margin-top:1rem}
  .faq-more{margin-top:2rem;font-size:.92rem;color:var(--tv-meta,#5C4632)}
</style>
<article class="faq">
  <header>
    <p class="text-[11px] uppercase tracking-widest text-[color:var(--tv-meta)]">Help</p>
    <h1>Frequently asked questions</h1>
    <p class="faq-lead">How Traversence works, in plain words. We add to this as Traversence grows.</p>
  </header>
  <div class="faq-find">
    <label for="faq-q" class="sr-only">Search the questions</label>
    <input id="faq-q" type="search" placeholder="Search the questions (for example: photos, draft, map pin)" autocomplete="off">
  </div>
  <nav class="faq-topics" aria-label="Topics">
    <?php foreach ($topics as $tp): ?><a href="#<?= tv_e($tp['id']) ?>"><?= tv_e($tp['topic']) ?></a><?php endforeach; ?>
  </nav>
  <?php foreach ($topics as $tp): ?>
  <section class="faq-sec" id="<?= tv_e($tp['id']) ?>">
    <h2><?= tv_e($tp['topic']) ?></h2>
    <?php foreach ($tp['items'] as $it): ?>
    <details id="<?= tv_e($it['id']) ?>" data-text="<?= tv_e($it['text']) ?>">
      <summary><?= faq_inline($it['q']) ?></summary>
      <div class="faq-a"><a class="faq-link" href="#<?= tv_e($it['id']) ?>" title="Link to this question">#</a><?= $it['html'] ?></div>
    </details>
    <?php endforeach; ?>
  </section>
  <?php endforeach; ?>
  <p class="faq-none" id="faq-none">No questions match that yet. Try other words, or <button type="button" class="underline" data-tv-suggest="{}">ask us</button>.</p>
  <p class="faq-more">Didn&rsquo;t find it? <button type="button" class="underline" data-tv-suggest="{}">Make a suggestion</button> and tell us what you were looking for. See also <a href="/our-approach.php" class="underline">Our approach</a>.</p>
</article>
<script>
(function () {
  var q = document.getElementById('faq-q'), none = document.getElementById('faq-none');
  var all = [].slice.call(document.querySelectorAll('.faq details'));
  function openHash() {
    var id = decodeURIComponent(location.hash.slice(1)); if (!id) return;
    var el = document.getElementById(id);
    if (el && el.tagName === 'DETAILS') { el.open = true; el.scrollIntoView({block: 'start'}); }
  }
  q.addEventListener('input', function () {
    var words = q.value.toLowerCase().split(/\s+/).filter(Boolean), shown = 0;
    all.forEach(function (d) {
      var hit = words.every(function (w) { return d.dataset.text.indexOf(w) !== -1; });
      d.hidden = !hit; if (hit) shown++;
      if (words.length) d.open = hit && shown <= 3;
    });
    document.querySelectorAll('.faq-sec').forEach(function (s) { s.hidden = !s.querySelector('details:not([hidden])'); });
    none.style.display = shown ? 'none' : 'block';
  });
  window.addEventListener('hashchange', openHash); openHash();
})();
</script>
<?php tv_page_end();
