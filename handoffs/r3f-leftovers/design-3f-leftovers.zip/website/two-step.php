<?php
// two-step.php — the second step of signing in, for staff (decisions/0097). The admin side sends staff here until they
// enter the 6-digit code we email them; then back to where they were going (?next=, a path on this site only).
// Also where staff see and forget the browsers they trust.
require_once __DIR__ . '/../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/../app/lib/TwoStep.php';
require_once __DIR__ . '/../app/ui/page-shell.php';

$pdo = Database::connection();
$me = Auth::currentUser();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
$next = (string) ($_GET['next'] ?? $_POST['next'] ?? '/admin/');
if (!preg_match('#^/(?!/)[^\s\\\\]*$#', $next)) $next = '/admin/';
if (!$me) { header('Location: /login.php?next=' . rawurlencode('/two-step.php?next=' . rawurlencode($next))); exit; }
$staff = TwoStep::isStaff($pdo, $me);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$msg = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) $err = 'This page had expired. Try again.';
    else try {
        switch ((string) ($_POST['do'] ?? '')) {
            case 'send':
                $wait = TwoStep::send($me);
                $msg = $wait < TwoStep::RESEND_WAIT ? "A code was sent a moment ago. You can ask for another in $wait seconds." : 'We emailed you a new code.';
                break;
            case 'check':
                TwoStep::check($pdo, $me, (string) ($_POST['code'] ?? ''), !empty($_POST['trust']));
                header('Location: ' . $next, true, 303); exit;
            case 'forget':
                TwoStep::forgetDevices($pdo, (int) $me['id']);
                $msg = 'Done: every browser will ask for a code again, this one included next time you sign in.';
                break;
        }
    } catch (Throwable $ex) { $err = $ex->getMessage(); }
}

$need = TwoStep::needed($pdo, $me);
// the first visit sends a code straight away (one less tap); later visits wait for "Send a new code"
if ($need && $_SERVER['REQUEST_METHOD'] === 'GET' && empty($_SESSION['tv_2s'])) {
    try { TwoStep::send($me); } catch (Throwable $ex) { $err = 'We couldn\'t send the code just now (' . $ex->getMessage() . '). Try "Send a new code" in a minute.'; }
}

tv_page_start('Two-step sign-in', ['no_crumbs' => true, 'description' => 'Enter the code we emailed you to open the Traversence admin side.']);
?>
<style>
  .ts{max-width:26rem;margin:1.5rem auto;background:var(--tv-sec,#F7EFDC);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:1rem;padding:1.2rem 1.2rem 1rem;color:var(--tv-ink,#3E2B1F)}
  .ts h1{font-family:var(--tv-font-head,Georgia,serif);font-weight:700;font-size:1.5rem;margin:0 0 .4rem}
  .ts p{font-size:.92rem;line-height:1.5;margin:.4rem 0}
  .ts input[type=text]{width:100%;font-size:1.6rem;letter-spacing:.4em;text-align:center;padding:.5rem;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;background:var(--tv-card-a,#FFFBF2);margin:.4rem 0}
  .ts input[type=text]::placeholder{letter-spacing:normal;font-size:1.05rem}
  .ts .b{border:1px solid var(--tv-link,#92400E);background:var(--tv-btn);color:var(--tv-btn-text);border-radius:.6rem;padding:.55rem 1rem;font-weight:700;font-size:.95rem;cursor:pointer;width:100%}
  .ts .l{border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);border-radius:.6rem;padding:.4rem .8rem;font-weight:600;font-size:.85rem;cursor:pointer}
  .ts .ok{background:#DCFCE7;border-radius:.5rem;padding:.45rem .6rem}.ts .no{background:#FEE2E2;border-radius:.5rem;padding:.45rem .6rem}
  .ts label{font-size:.88rem;display:flex;gap:.45rem;align-items:center;margin:.3rem 0 .6rem}
  .ts ul{font-size:.85rem;margin:.3rem 0 .5rem 1.1rem;list-style:disc}
  .ts .row{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.7rem}
  @media (max-width:767px){.ts{margin:.6rem 0}}
</style>
<div class="ts tv-bleed">
  <h1>Two-step sign-in</h1>
  <?php if ($msg): ?><p class="ok" role="status"><?= $e($msg) ?></p><?php endif; ?>
  <?php if ($err): ?><p class="no" role="alert"><?= $e($err) ?></p><?php endif; ?>

  <?php if (!$staff): ?>
    <p>Two-step sign-in is for the Traversence team's accounts. Yours doesn't need it.</p>
    <p><a class="underline text-[color:var(--tv-link)]" href="/user/dashboard.php">Go to your dashboard</a></p>
  <?php elseif (TwoStep::off()): ?>
    <p>Two-step sign-in is switched off on this site for now (TV_TWO_STEP=off).</p>
    <p><a class="underline text-[color:var(--tv-link)]" href="<?= $e($next) ?>">Continue</a></p>
  <?php elseif ($need): ?>
    <?php $tsUntil = (int) ($_SESSION['tv_2s']['exp'] ?? 0); if (($_SESSION['tv_2s']['uid'] ?? 0) != $me['id'] || $tsUntil <= time()) $tsUntil = 0;   // when the code stops working (3f A11) ?>
    <p>The admin side asks for a second step: a 6-digit code <?= $err === '' ? 'we emailed' : 'we email' ?> to <b><?= $e(TwoStep::masked((string) $me['email'])) ?></b>. It works <?= $tsUntil ? 'until <time datetime="' . $e(date('c', $tsUntil)) . '" data-tv-time data-tv-clock>' . $e(date('g:i A T', $tsUntil)) . '</time>' : 'for 10 minutes after it\'s sent' ?>.</p>
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>">
      <input type="text" name="code" inputmode="numeric" maxlength="12" autocomplete="one-time-code" placeholder="6 digits" aria-label="The 6-digit code" required autofocus data-tv-code>
      <label><input type="checkbox" name="trust" value="1" checked> Trust this browser for <?= TwoStep::DEVICE_DAYS ?> days</label>
      <button class="b" name="do" value="check">Continue</button>
    </form>
    <div class="row">
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="next" value="<?= $e($next) ?>"><button class="l" name="do" value="send">Send a new code</button></form>
    </div>
    <p style="font-size:.8rem;color:var(--tv-meta,#8A7355);margin-top:.8rem">No email? Check spam for "Your Traversence sign-in code". Not you signing in? Change your password and tell us at <a class="underline" href="mailto:support@traversence.com">support@traversence.com</a>.</p>
  <?php else: ?>
    <p>You're through: this sign-in has passed the second step.</p>
    <p><a class="underline text-[color:var(--tv-link)]" href="<?= $e($next) ?>">Continue</a></p>
    <?php $dev = TwoStep::devices($pdo, (int) $me['id']); ?>
    <p style="margin-top:.9rem"><b>Browsers you trust</b> (no code for <?= TwoStep::DEVICE_DAYS ?> days):</p>
    <?php if ($dev): ?>
      <ul><?php foreach ($dev as $d): ?><li><?= $e($d['label']) ?>, since <?= $e(date('M j', strtotime((string) $d['created_at']))) ?><?= $d['last_used_at'] ? ', last used ' . $e(date('M j', strtotime((string) $d['last_used_at']))) : '' ?></li><?php endforeach; ?></ul>
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><button class="l" name="do" value="forget" data-confirm="Stop trusting every browser? Each will ask for a code next time." data-yes="Forget them" data-danger>Forget all of them</button></form>
    <?php else: ?><p style="font-size:.88rem">None.</p><?php endif; ?>
  <?php endif; ?>
</div>
<script src="/js/tv-time.js" defer></script>
<script src="/js/code-link.js" defer></script>
<?php tv_page_end();
