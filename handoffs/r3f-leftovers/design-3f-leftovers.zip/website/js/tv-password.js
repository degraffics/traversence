// js/tv-password.js — every password box on the site (loaded on every page with tv-ask.js):
//   * a Show / Hide button inside the box, so people can check what they typed;
//   * for a new password (autocomplete="new-password", or data-pw-min), a live checklist under it: long enough,
//     not containing data-pw-not (e.g. the staff ID), and, on the box with data-pw-match="#other", the same as that one.
//     The form can't be sent until the list is all ticked (the box says why: no browser pop-ups).
(function () {
  'use strict';
  if (window.TvPassword) return;
  var EYE = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
  var EYE_OFF = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.9 17.9A10.8 10.8 0 0 1 12 20c-7 0-11-8-11-8a19.8 19.8 0 0 1 5.1-5.9M9.9 4.2A9.6 9.6 0 0 1 12 4c7 0 11 8 11 8a19.6 19.6 0 0 1-2.2 3.2M1 1l22 22"/><path d="M14.1 14.1a3 3 0 1 1-4.2-4.2"/></svg>';
  var css = document.createElement('style');
  css.textContent = '.tvpw{position:relative;display:block}.tvpw>input{padding-right:2.8rem!important;width:100%}'
    + '.tvpw-b{position:absolute;top:50%;right:.35rem;transform:translateY(-50%);width:34px;height:34px;border:0;background:none;color:var(--tv-meta,#8A7355);cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:.4rem}'
    + '.tvpw-b:hover,.tvpw-b[aria-pressed="true"]{color:var(--tv-link,#92400E);background:rgba(146,64,14,.08)}'
    + '.tvpw-list{list-style:none;margin:.3rem 0 0;padding:0;font-size:.78rem;line-height:1.5}.tvpw-list li{color:var(--tv-meta,#8A7355)}.tvpw-list li:before{content:"○ ";}'
    + '.tvpw-list li.ok{color:#1F5C43}.tvpw-list li.ok:before{content:"✓ ";font-weight:700}.tvpw-list li.no{color:var(--tv-crimson,#991B1B)}.tvpw-list li.no:before{content:"✕ "}';
  document.head.appendChild(css);

  function rules(inp) {
    var r = [], min = +(inp.getAttribute('data-pw-min') || inp.getAttribute('minlength') || 0), not = inp.getAttribute('data-pw-not'), match = inp.getAttribute('data-pw-match');
    if (match) r.push({ t: 'The same as above', f: function (v) { var o = document.querySelector(match); return !!o && v !== '' && v === o.value; } });
    else {
      if (min) r.push({ t: 'At least ' + min + ' characters', f: function (v) { return v.length >= min; } });
      if (not) r.push({ t: 'Doesn\'t contain ' + not, f: function (v) { return v !== '' && v.toLowerCase().indexOf(not.toLowerCase()) < 0; } });
      if (inp.hasAttribute('data-pw-strong')) {   // the sign-up rule the server checks (decisions/0014)
        r.push({ t: 'A capital letter', f: function (v) { return /[A-Z]/.test(v); } });
        r.push({ t: 'A small letter', f: function (v) { return /[a-z]/.test(v); } });
        r.push({ t: 'A number', f: function (v) { return /[0-9]/.test(v); } });
        r.push({ t: 'A symbol, like ! or #', f: function (v) { return /[^A-Za-z0-9]/.test(v); } });
      }
    }
    return r;
  }
  function enhance(inp) {
    if (inp.getAttribute('data-tvpw') || inp.type !== 'password' || inp.hidden) return;
    inp.setAttribute('data-tvpw', '1');
    var wrap = document.createElement('span'); wrap.className = 'tvpw';
    inp.parentNode.insertBefore(wrap, inp); wrap.appendChild(inp);
    var b = document.createElement('button'); b.type = 'button'; b.className = 'tvpw-b'; b.innerHTML = EYE;
    b.setAttribute('aria-label', 'Show password'); b.title = 'Show password'; b.setAttribute('aria-pressed', 'false');
    b.addEventListener('click', function () {
      var show = inp.type === 'password'; inp.type = show ? 'text' : 'password';
      b.innerHTML = show ? EYE_OFF : EYE; b.setAttribute('aria-pressed', show ? 'true' : 'false');
      b.setAttribute('aria-label', show ? 'Hide password' : 'Show password'); b.title = show ? 'Hide password' : 'Show password'; inp.focus();
    });
    wrap.appendChild(b);
    var isNew = inp.getAttribute('autocomplete') === 'new-password' || inp.hasAttribute('data-pw-min') || inp.hasAttribute('data-pw-match') || inp.hasAttribute('data-pw-strong');
    if (!isNew) return;
    var rs = rules(inp); if (!rs.length) return;
    var ul = document.createElement('ul'); ul.className = 'tvpw-list'; ul.setAttribute('aria-live', 'polite');
    rs.forEach(function (x) { var li = document.createElement('li'); li.textContent = x.t; ul.appendChild(li); x.li = li; });
    wrap.parentNode.insertBefore(ul, wrap.nextSibling);
    var touched = false;
    function check(final) {
      var v = inp.value, all = true;
      rs.forEach(function (x) { var ok = x.f(v); x.li.className = ok ? 'ok' : (touched || final ? 'no' : ''); if (!ok) all = false; });
      return all;
    }
    inp.addEventListener('input', function () { touched = touched || inp.value.length > 0; check(false); });
    inp.addEventListener('blur', function () { if (inp.value) { touched = true; check(false); } });
    var m = inp.getAttribute('data-pw-match'), other = m && document.querySelector(m);
    if (other) other.addEventListener('input', function () { if (inp.value) check(false); });
    // checked when the form is sent: the list turns red and the box gets the focus (no browser pop-up); the button
    // stays as it is. Click handlers on the submit button run before this, so their pages check the same way.
    if (inp.form) inp.form.addEventListener('submit', function (e) { if (!check(true)) { e.preventDefault(); e.stopImmediatePropagation(); inp.focus(); ul.scrollIntoView({ block: 'nearest' }); } }, true);
    check(false);
  }
  function all(root) { [].forEach.call((root || document).querySelectorAll('input[type="password"]'), enhance); }
  window.TvPassword = { enhance: enhance, all: all };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { all(); }); else all();
  new MutationObserver(function (ms) { ms.forEach(function (m) { [].forEach.call(m.addedNodes, function (n) { if (n.nodeType === 1) { if (n.matches && n.matches('input[type="password"]')) enhance(n); else if (n.querySelectorAll) all(n); } }); }); })
    .observe(document.documentElement, { childList: true, subtree: true });
})();
