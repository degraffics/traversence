<?php require_once __DIR__ . '/../app/ui/auth-nav.php'; require_once __DIR__ . '/../app/ui/google-button.php';
tv_google_session();   // the session, to know who's here
// signed in and no reset link (site audit P2): nothing to reset here, so their dashboard; a link they were sent still works
if (empty($_GET['token']) && Auth::currentUserId()) { header('Location: /user/dashboard.php', true, 302); exit; } ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Password — Traversence</title>
  <?php tv_nav_head(); ?>
</head>
<body class="bg-[color:var(--tv-canvas)] text-[color:var(--tv-ink)] min-h-screen flex flex-col font-sans">
  <?php tv_nav_bar(); ?>
  <main class="flex-1 flex items-center justify-center py-8">
  <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-8 max-w-md w-full mx-4 shadow-xl">
    <h1 class="text-xl font-serif font-bold mb-4 text-center">Reset Your Password</h1>
    <form id="reset-form" class="space-y-4">
      <div>
        <label for="password" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">New Password</label>
        <div class="relative">
          <input type="password" id="password" placeholder="New password" required minlength="8" autocomplete="new-password"
                 class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
        </div>
      </div>
      <ul id="password-checklist" class="text-xs space-y-0.5 pl-1">
        <li id="check-length" data-label="At least 8 characters" class="text-[color:var(--tv-meta)]">&#10007; At least 8 characters</li>
        <li id="check-upper" data-label="One uppercase letter" class="text-[color:var(--tv-meta)]">&#10007; One uppercase letter</li>
        <li id="check-lower" data-label="One lowercase letter" class="text-[color:var(--tv-meta)]">&#10007; One lowercase letter</li>
        <li id="check-digit" data-label="One number" class="text-[color:var(--tv-meta)]">&#10007; One number</li>
        <li id="check-special" data-label="One special character (e.g. @ $ ! % * ? &amp;)" class="text-[color:var(--tv-meta)]">&#10007; One special character (e.g. @ $ ! % * ? &amp;)</li>
      </ul>
      <div>
        <label for="confirm_password" class="block text-xs font-semibold text-[color:var(--tv-meta)] mb-1">Confirm New Password</label>
        <div class="relative">
          <input type="password" id="confirm_password" placeholder="Confirm new password" required minlength="8" autocomplete="new-password" data-pw-match="#password"
                 class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
        </div>
      </div>
      <button type="submit" class="w-full bg-[color:var(--tv-umber)] text-[color:var(--tv-on-umber)] rounded-lg py-2 text-sm font-semibold hover:bg-[color:var(--tv-umber)] transition">
        Set New Password
      </button>
    </form>
    <div id="status" class="text-sm text-center mt-4"></div>
  </div>
  </main>
  <?php tv_nav_foot(); ?>
  <script>
    const token = new URLSearchParams(window.location.search).get('token');
    const statusEl = document.getElementById('status');
    let csrfToken = null;

    async function getCsrfToken() {
      // A CSRF token is issued to every session on first contact
      // (bootstrap.php), even an anonymous pre-login one — session.php
      // returns it in its response body regardless of login state.
      const res = await fetch('/api/auth/session.php', { credentials: 'include' });
      const data = await res.json();
      return data.csrf_token;
    }

    function togglePasswordVisibility(inputId, btn) {
      const input = document.getElementById(inputId);
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.textContent = showing ? 'Show' : 'Hide';
    }

    // Shared password-requirements check — mirrors the server-side
    // policy in Auth::assertPasswordMeetsRequirements() exactly, but is
    // UX feedback only; the server independently re-checks everything,
    // since client-side validation is never a security boundary.
    function checkPasswordRequirements(password) {
      return {
        length:  password.length >= 8,
        upper:   /[A-Z]/.test(password),
        lower:   /[a-z]/.test(password),
        digit:   /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password),
      };
    }

    function renderChecklist(password) {
      const results = checkPasswordRequirements(password);
      const map = { length: 'check-length', upper: 'check-upper', lower: 'check-lower', digit: 'check-digit', special: 'check-special' };
      for (const [key, id] of Object.entries(map)) {
        const el = document.getElementById(id);
        const met = results[key];
        el.className = met ? 'text-green-700' : 'text-[color:var(--tv-meta)]';
        el.textContent = (met ? '\u2713 ' : '\u2717 ') + el.dataset.label;
      }
      return Object.values(results).every(Boolean);
    }

    document.getElementById('password').addEventListener('input', (e) => renderChecklist(e.target.value));

    document.getElementById('reset-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!token) {
        statusEl.textContent = 'No reset token provided.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        return;
      }

      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirm_password').value;

      if (!renderChecklist(password)) {
        statusEl.textContent = 'Password does not meet all requirements above.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        return;
      }
      if (password !== confirmPassword) {
        statusEl.textContent = 'Passwords do not match.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        return;
      }

      const submitBtn = e.target.querySelector('button[type="submit"]');
      submitBtn.disabled = true;

      try {
        if (!csrfToken) {
          csrfToken = await getCsrfToken();
        }
        const res = await fetch('/api/auth/password/reset.php', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify({ token, password }),
        });
        const data = await res.json();
        if (res.ok && data.ok) {
          statusEl.textContent = 'Password updated. You can now sign in.';
          statusEl.className = 'text-sm text-center mt-4 text-green-700';
          document.getElementById('reset-form').style.display = 'none';
        } else {
          statusEl.textContent = data?.error?.message || 'Reset failed.';
          statusEl.className = 'text-sm text-center mt-4 text-red-700';
          submitBtn.disabled = false;
        }
      } catch (err) {
        statusEl.textContent = 'Something went wrong. Please try again.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        submitBtn.disabled = false;
      }
    });
  </script>
</body>
</html>
