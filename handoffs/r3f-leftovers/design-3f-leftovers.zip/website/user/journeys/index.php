<?php
// user/journeys/index.php — Your journeys, in the member Dashboard (decisions/0056, 0058). Signed in. Not a contributor yet: Become a contributor (the
// guidelines, 18 or older, a public profile, a short bio). A contributor: their journeys (drafts, published, hidden),
// Write a journey, edit, delete. Traversence pieces are written from Admin → Journeys.
declare(strict_types=1);

require_once __DIR__ . '/../../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../../app/ui/page-shell.php';
require_once __DIR__ . '/../../../app/ui/journey-ui.php';
require_once __DIR__ . '/../../../app/lib/Journeys.php';

$uid = Auth::currentUserId();
if ($uid === null) { header('Location: /login.php?next=' . rawurlencode('/user/journeys/'), true, 302); exit; }
$pdo = Database::connection();
$ready = Journeys::ready($pdo);
$csrf = (string) ($_SESSION['csrf_token'] ?? '');
$msg = null;

if ($ready && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Your session expired. Reload the page and try again.');
        $do = (string) ($_POST['do'] ?? '');
        if ($do === 'become') {
            if (!empty($_POST['over_18'])) AgeGate::confirm($pdo, $uid);
            if (!empty($_POST['verify'])) MemberVerification::accept($pdo, $uid, 'user/journeys');
            Journeys::become($pdo, $uid, (string) ($_POST['bio'] ?? ''), !empty($_POST['accept']));
            $_SESSION['jr_flash'] = 'Welcome, contributor. Write your first journey whenever you\'re ready.';
        } elseif ($do === 'accept' || $do === 'decline') {   // a co-author invitation (decisions/0058 §7)
            if ($do === 'accept' && !empty($_POST['over_18'])) AgeGate::confirm($pdo, $uid);
            Journeys::respond($pdo, $uid, (int) ($_POST['id'] ?? 0), $do === 'accept');
            $_SESSION['jr_flash'] = $do === 'accept' ? 'You’re a co-author. Your name shows on the journey.' : 'Declined.';
        } elseif ($do === 'delete') {
            Journeys::remove($pdo, $uid, (int) ($_POST['id'] ?? 0));
            $_SESSION['jr_flash'] = 'Deleted.';
        }
        header('Location: /user/journeys/', true, 303);
        exit;
    } catch (InvalidArgumentException $e) {
        $msg = $e->getMessage();
    }
}
$flash = $_SESSION['jr_flash'] ?? null; unset($_SESSION['jr_flash']);
$me = $ready ? Journeys::contributor($pdo, $uid) : null;
$blockers = $ready ? Journeys::blockers($pdo, $uid) : [];
$staff = $ready && Journeys::isStaff($pdo, $uid);

tv_page_start($me ? 'Your journeys' : 'Become a contributor', ['description' => 'Share your journeys on Traversence.', 'crumbs' => [['Dashboard', '/user/dashboard.php'], [$me ? 'Your journeys' : 'Become a contributor']]]);
echo tv_journey_css();
?>
<style>
  .jy{max-width:52rem}
  .jy h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:clamp(1.5rem,2.6vw,2rem);color:var(--tv-ink,#3E2B1F);margin:0}
  .jy-lead{color:var(--tv-meta,#5C4632);font-size:.95rem;margin:.3rem 0 1rem}
  .jy-card{background:var(--tv-sec,#F7EFDC);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:1rem;padding:1rem 1.15rem;margin-top:.9rem}
  .cg h3{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:1rem;color:var(--tv-ink,#3E2B1F);margin:.8rem 0 .2rem}.cg h3:first-child{margin-top:0}
  .cg p{font-size:.88rem;color:var(--tv-ink,#3E2B1F);line-height:1.5;margin:0}.cg .cg-note{font-size:.78rem;color:var(--tv-meta,#7A6348);margin-top:.8rem}
  .jy label{display:flex;gap:.5rem;align-items:flex-start;font-size:.9rem;color:var(--tv-ink,#3E2B1F);margin-top:.6rem}
  .jy textarea{width:100%;box-sizing:border-box;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;padding:.5rem .65rem;background:var(--tv-card-a,#FFFBF2);font:inherit;font-size:.9rem;min-height:4.5rem}
  .jy-b{display:inline-flex;align-items:center;gap:.4rem;background:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2);border:0;border-radius:.7rem;padding:.55rem 1.1rem;font-weight:600;font-size:.9rem;cursor:pointer;text-decoration:none}
  .jy-b.ghost{background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);border:1px solid var(--tv-line-strong,#CBB98D)}.jy-b.no{background:var(--tv-card-a,#FFFBF2);color:var(--tv-crimson,#991B1B);border:1px solid #FCA5A5}
  .jy-msg{border-radius:.7rem;padding:.55rem .8rem;font-size:.9rem;margin-top:.8rem}.jy-msg.ok{background:#DCFCE7;color:#14532D}.jy-msg.err{background:#FEE2E2;color:#7F1D1D}
  .jy-row{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .8rem;border-top:1px solid var(--tv-line,#E3D3AC);padding:.6rem 0}
  .jy-row:first-child{border-top:0}.jy-row b{flex:1;min-width:12rem;font-size:.95rem}.jy-row small{color:var(--tv-meta,#7A6348);font-size:.78rem}
  .jy-st{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;border-radius:.3rem;padding:.08rem .4rem}
  .jy-st.published{background:#DCFCE7;color:#14532D}.jy-st.draft{background:#FEF3C7;color:#78350F}.jy-st.hidden{background:#FEE2E2;color:#7F1D1D}
</style>
<div class="jy">
<?php if ($flash): ?><p class="jy-msg ok"><?= tv_e($flash) ?></p><?php endif; ?>
<?php if ($msg): ?><p class="jy-msg err"><?= tv_e($msg) ?></p><?php endif; ?>
<?php $invites = $ready ? Journeys::invites($pdo, $uid) : []; ?>
  <?php if ($invites): ?>
  <div class="jy-card" style="border-color:#B8863B">
    <b>Co-author invitations</b>
    <?php foreach ($invites as $iv): ?>
      <div class="jy-row"><b><?= tv_e($iv['title']) ?> <small>from <?= tv_e($iv['from']) ?></small></b>
        <a class="jy-b ghost" href="/journeys/view.php?id=<?= (int) $iv['journey_id'] ?>">Read it</a>
        <form method="post" style="display:inline-flex;flex-wrap:wrap;align-items:center;gap:.4rem"><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="id" value="<?= (int) $iv['journey_id'] ?>">
          <?php if (!AgeGate::confirmed($pdo, $uid)): ?><label style="margin:0;font-size:.82rem"><input type="checkbox" name="over_18" value="1"> <?= tv_e(AgeGate::TEXT) ?></label><?php endif; ?>
          <button class="jy-b" name="do" value="accept">Accept</button><button class="jy-b no" name="do" value="decline">Decline</button></form></div>
    <?php endforeach; ?>
    <p class="jy-lead" style="margin:.4rem 0 0;font-size:.82rem">Accepting puts your name on the journey and it shows on your profile. You can be removed by its author any time.</p>
  </div>
  <?php endif; ?>
<?php if (!$ready): ?>
  <h1>Journeys</h1><p class="jy-lead">Journeys aren&rsquo;t switched on yet (run <code>app/migrations/2026-10-07_journeys.sql</code>).</p>
<?php elseif (!$me): ?>
  <h1>Become a contributor</h1>
  <p class="jy-lead">Share your journeys: the trail you hiked, the town you wandered, the caf&eacute; you stopped at. Your journeys show on Let&rsquo;s Explore with your name,
    next to Traversence&rsquo;s own guides, and link the places and local businesses you mention.</p>
  <div class="jy-card" id="guidelines"><?= tv_contributor_guidelines() ?></div>
  <form method="post" class="jy-card">
    <input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="do" value="become">
    <?php if (in_array('private', $blockers, true)): ?>
      <p class="jy-msg err" style="margin-top:0">Contributors have a public profile, and yours is private. <a class="underline" href="/user/dashboard.php#security">Change it in Privacy</a>, then come back.</p>
    <?php endif; ?>
    <label for="jy-bio" style="display:block"><b>A line about you</b> <small style="color:var(--tv-meta,#7A6348)">(optional, shown with your journeys)</small></label>
    <textarea id="jy-bio" name="bio" maxlength="400" placeholder="e.g. Born in Springerville; I hike the White Mountains every weekend."></textarea>
    <?php if (in_array('age', $blockers, true)): ?><label><input type="checkbox" name="over_18" value="1" required> <span><?= tv_e(AgeGate::TEXT) ?></span></label><?php endif; ?>
    <?php if (in_array('verify', $blockers, true)): ?><p class="text-sm" data-tv-status="info" data-tv-label="First:">Confirm your email: open the link we sent you, or send it again from <a class="underline" href="/login.php">Sign in</a>.</p><?php endif; ?>
    <label><input type="checkbox" name="accept" value="1" required> <span>I&rsquo;ve read the contributor guidelines and I&rsquo;ll follow them.</span></label>
    <p style="margin-top:.9rem"><button class="jy-b" type="submit"<?= in_array('private', $blockers, true) ? ' disabled' : '' ?>>Become a contributor</button></p>
  </form>
<?php else: $mine = Journeys::mine($pdo, $uid); ?>
  <div style="display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:.6rem">
    <div><h1>Your journeys</h1><p class="jy-lead" style="margin-bottom:0">Drafts are only yours. Published journeys show on Let&rsquo;s Explore for their place<?= $staff ? '. Traversence articles and guides are written in <a class="underline" href="/admin/journeys.php">Admin &rarr; Journeys</a>' : '' ?>.</p></div>
    <a class="jy-b" href="/user/journeys/compose.php">✎ Write a journey</a>
  </div>
  <div class="jy-card">
    <?php if (!$mine): ?><p class="jy-lead" style="margin:0">No journeys yet. <a class="underline" href="/user/journeys/compose.php">Write your first</a>.</p><?php endif; ?>
    <?php foreach ($mine as $j): ?>
      <div class="jy-row">
        <b><?= tv_e($j['category']) ?> | <?= tv_e($j['title']) ?> <span class="jr-voice c">Contributor</span><?php if (!empty($j['entity_id'])): ?> <small>as <?= tv_e(Journeys::author($pdo, $j)['name']) ?></small><?php endif; ?></b>
        <span class="jy-st <?= tv_e($j['status']) ?>"><?= tv_e($j['status']) ?></span>
        <small><?= tv_e($j['place_label'] ?: 'No place yet') ?> · <?= tv_icon('eye', 'tv-ei') ?> <?= (int) $j['views'] ?> · <?= tv_icon('heart', 'tv-ei') ?> <?= (int) $j['likes'] ?> · <?= tv_icon('comment', 'tv-ei') ?> <?= (int) $j['comments'] ?></small>
        <?php if ($j['status'] === 'hidden' && $j['hidden_reason']): ?><small style="color:var(--tv-crimson,#991B1B)">Hidden: <?= tv_e($j['hidden_reason']) ?></small><?php endif; ?>
        <a class="jy-b ghost" href="/journeys/view.php?id=<?= (int) $j['id'] ?>">View</a>
        <a class="jy-b ghost" href="/user/journeys/compose.php?id=<?= (int) $j['id'] ?>">Edit</a>
        <form method="post" data-confirm="Delete this journey and its photos? This can't be undone." data-yes="Delete" data-danger><input type="hidden" name="csrf" value="<?= tv_e($csrf) ?>"><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= (int) $j['id'] ?>"><button class="jy-b no" type="submit">Delete</button></form>
      </div>
    <?php endforeach; ?>
  </div>
  <details class="jy-card" id="guidelines"><summary style="cursor:pointer;font-weight:600">The contributor guidelines</summary><div style="margin-top:.6rem"><?= tv_contributor_guidelines() ?></div></details>
<?php endif; ?>
</div>
<?php tv_page_end();
