<?php
// /plans.php — choose and manage a plan (decisions/0108 step 3; Master AOS v44 §5): ?listing=N for a business the
// signed-in person owns (or handles billing for), ?me=1 for their own personal plan, neither for the list of both.
// Monthly or yearly (a year is 10 months), storage and AI Assist packs, a card kept on file in QuickBooks Payments
// (the card goes from the browser to Intuit; only a one-time token reaches us), receipts. All through /api/plans.php.
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/Billing.php';
require_once __DIR__ . '/../app/lib/Promotions.php';
require_once __DIR__ . '/../app/ui/page-shell.php';
require_once __DIR__ . '/../app/ui/go-codes.php';
tv_card_page_csp('plans', ['quickbooks']);   // a card page: only our scripts and Intuit's (0098; its script list there)
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');

$me = Auth::currentUser();
$pdo = Database::connection();
$e = fn ($s) => htmlspecialchars((string) $s, ENT_QUOTES);
if (!$me) { header('Location: /login.php?next=' . rawurlencode($_SERVER['REQUEST_URI'] ?? '/plans.php'), true, 302); exit; }
$uid = (int) $me['id'];
$type = isset($_GET['me']) ? 'user' : (isset($_GET['listing']) ? 'listing' : '');
$id = $type === 'user' ? $uid : (int) ($_GET['listing'] ?? 0);
$allowed = $type !== '' && Billing::ready($pdo) && Billing::canManage($pdo, $uid, $type, $id);

tv_page_start('Plans', ['no_crumbs' => true, 'description' => 'Choose and manage your Traversence plan.']);
tv_go_head('', false);
?>
<style>
  .pl-row{display:flex;gap:.6rem;align-items:flex-start;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);border-radius:.7rem;padding:.6rem .75rem;margin:0 0 .4rem;cursor:pointer}
  .pl-row.on{border-color:#6E9F8A;box-shadow:0 0 0 2px rgba(143,188,168,.45)}
  .pl-row input{margin-top:.25rem;accent-color:#5E8F79}
  .pl-row b{display:block}.pl-row small{color:var(--tv-meta,#5C4632);font-size:.8rem}
  .pl-price{margin-left:auto;text-align:right;font-weight:700;white-space:nowrap}
  .pl-now{font-size:.9rem;line-height:1.5}
  .pl-tag{display:inline-block;background:var(--tv-sage,#8FBCA8);color:#1F3A2E;border-radius:999px;padding:0 .5rem;font-size:.72rem;font-weight:700;margin-left:.3rem}
  .pl-cyc{display:inline-flex;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;overflow:hidden;margin:0 0 .6rem}
  .pl-cyc button{border:0;background:var(--tv-card-a,#FFFBF2);padding:.35rem .85rem;font-weight:600;font-size:.85rem;color:var(--tv-meta,#5C4632);cursor:pointer}
  .pl-cyc button.on{background:var(--tv-sage,#8FBCA8);color:#1F3A2E}
  .pl-inc{margin:.3rem 0 0;font-size:.8rem;color:var(--tv-meta,#5C4632)}
  .pl-inc ul{margin:.15rem 0 0;padding-left:1.05rem}.pl-inc li{margin:.1rem 0}
  .pl-line{display:flex;justify-content:space-between;font-size:.88rem;margin:.15rem 0}
  .pl-pack{display:flex;gap:.5rem;align-items:center;justify-content:space-between;border-top:1px solid var(--tv-line,#EADFC4);padding:.45rem 0;font-size:.88rem}
  .pl-msg[hidden],.pl-x[hidden],[data-cardbox][hidden],[data-promo-note][hidden]{display:none}
  .pl-msg{background:#E7F3EC;border:1px solid #B7D9C7;border-radius:.6rem;padding:.5rem .7rem;font-size:.88rem;margin:.5rem 0}
  .pl-x{background:#FDECEC;border:1px solid #F3B7B7;border-radius:.6rem;padding:.5rem .7rem;font-size:.88rem;margin:.5rem 0}
</style>
<div class="go">
<?php if ($type === ''): $pq = isset($_GET['promo']) ? '&promo=' . rawurlencode(Promotions::clean((string) $_GET['promo'])) : '';
    $mine = $pdo->prepare('SELECT id, name, plan_tier FROM entities WHERE owner_user_id = ? ORDER BY name LIMIT 100'); $mine->execute([$uid]); ?>
  <h1>Plans</h1>
  <p class="go-lead">Choose which plan to manage.</p>
  <section class="go-card tv-bleed">
    <div class="pl-pack"><span><a href="/plans.php?me=1<?= $pq ?>" style="color:var(--tv-link,#92400E);font-weight:700">Your personal plan</a></span><span class="go-note"><?= $e((Billing::PLANS[Billing::allowance($pdo, 'user', $uid)['plan']][0] ?? 'Personal')) ?></span></div>
    <?php foreach ($mine as $l): ?>
    <div class="pl-pack"><span><a href="/plans.php?listing=<?= (int) $l['id'] ?><?= $pq ?>" style="color:var(--tv-link,#92400E);font-weight:700"><?= $e($l['name']) ?></a></span><span class="go-note"><?= $e(Billing::PLANS[Billing::allowance($pdo, 'listing', (int) $l['id'])['plan']][0] ?? 'Free') ?></span></div>
    <?php endforeach; ?>
  </section>
<?php elseif (!$allowed): ?>
  <section class="go-card tv-bleed"><h1>Plans</h1><p class="go-note">Only the owner of this business, or someone they let handle billing, can manage its plan. <a href="/plans.php">See your plans</a>.</p></section>
<?php else: ?>
  <h1 data-title>Plan</h1>
  <div class="pl-msg" data-msg hidden></div><div class="pl-x" data-err hidden></div>
  <section class="go-card tv-bleed"><h2>Now</h2><div class="pl-now" data-now></div><div data-cardbox hidden style="margin-top:.6rem"></div></section>
  <section class="go-card tv-bleed"><h2>Have a code?</h2><div class="ec-code" style="display:flex;gap:.4rem"><input class="go-in" data-code value="<?= $e(Promotions::clean((string) ($_GET['promo'] ?? ''))) ?>" placeholder="Enter a promo code" aria-label="Promo code" autocapitalize="characters" style="flex:1;min-width:0;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;padding:.45rem .6rem;background:var(--tv-card-a,#FFFBF2)"><button type="button" class="go-btn" data-apply>Apply</button></div><p class="go-note" data-promo-note style="margin-top:.4rem" hidden></p></section>
<?php if ($type === 'user' && Billing::selfTrialWhyNot($pdo, $uid) === ''): /* the free week of Pro (decisions/0154 §5): once, no card */ ?>
  <section class="go-card tv-bleed" id="try" data-trycard><h2>Try Pro free for 7 days</h2><p class="go-note">Personal Pro for a week: 50 GB, 10-minute videos, uploads to 1 GB and the creator tools. No card, nothing charged; it goes back to Free on its own unless you keep it. Once an account; AI Assist credits come with a paid plan.</p>
    <button type="button" class="go-btn main" data-try style="margin-top:.5rem">Start my free week</button></section>
<?php endif; ?>
  <section class="go-card tv-bleed"><h2>Choose a plan</h2><div data-cyc></div><div data-plans></div><p class="go-note" style="margin-top:.2rem">An AI Assist credit is one ask, or one description written for you, after the 3 free asks a day. Storage holds your photos, files and items. <a href="/faq.php#what-does-ai-assist-do">More about AI Assist</a></p><div data-act style="margin-top:.7rem"></div></section>
  <section class="go-card tv-bleed" id="packs" data-packs-card hidden><h2>Storage and AI packs</h2><p class="go-note">The same packs for every plan, at full price, renewing with your plan. Added now, you pay for the rest of this period.</p><div data-packs></div></section>
<?php if ($type === 'user'): /* earned storage (decisions/0154 §7): counted now, then once a day */
    require_once __DIR__ . '/../app/lib/EarnedStorage.php';
    $es = EarnedStorage::status($pdo, $uid);
    if ($es['ready']) { try { $es = EarnedStorage::recount($pdo, $uid); } catch (Throwable $x) { error_log('earned recount: ' . $x->getMessage()); } } ?>
  <section class="go-card tv-bleed" id="earned"><h2>Earned storage</h2>
    <?php if (!$es['ready']): ?><p class="go-note">Coming within the hour: the space you earn from followers and friends who join.</p>
    <?php else: ?><p class="pl-now">You've earned <b><?= (int) $es['earned_gb'] ?> GB</b> of <?= (int) $es['cap_gb'] ?> GB, on top of your plan's storage.</p>
    <p class="go-note">1 GB for every <?= EarnedStorage::PER_FOLLOWERS ?> followers (you have <?= (int) $es['followers'] ?> who count, <?= (int) $es['to_next'] ?> more to the next GB) and for every friend who joins with your invite (<?= (int) $es['friends'] ?> so far).
      They count once they're settled members: email confirmed and 18+, their account 30 days old, and on Traversence on 3 different days. Up to <?= EarnedStorage::MONTH_GB ?> GB a month (<?= (int) $es['month_left'] ?> GB left this month); it stays when followers leave.
      Invite friends from your <a href="/user/dashboard.php#addressbook">Address Book</a>.</p><?php endif; ?>
  </section>
<?php endif; ?>
  <section class="go-card tv-bleed" data-rec-card hidden><h2>Receipts</h2><div data-rec></div><p class="go-note" style="margin-top:.4rem">Each payment is also emailed to you, with a receipt from QuickBooks.</p></section>
  <p class="go-note">Plans sell tools, storage and support, never a higher place in search. A yearly plan is 10 months' price for 12; packs are always full price. <a href="/terms.php#plans">Terms</a>.</p>
  <p class="go-note">Strategic Partner and Cornerstone include White Glove: choosing one gives your White Glove agent access to your business for that work, limited as the <a href="/terms.php#white-glove">White Glove terms</a> say. You can turn it off in Settings &amp; team.</p>
<?php endif; ?>
</div>
<?php if ($allowed): ?>
<script<?= tv_nonce() ?>>
(function () {
  var T = <?= json_encode($type) ?>, ID = <?= $id ?>, V = null, pick = <?= json_encode(isset(Billing::PLANS[(string) ($_GET['pick'] ?? '')]) && Billing::PLANS[(string) $_GET['pick']][1] === ($type === 'user' ? 'user' : 'listing') ? (string) $_GET['pick'] : null) /* from the Shop or the upgrade sheet */ ?>, cyc = 'month', PROMO = null;
  var $ = function (k) { return document.querySelector('[data-' + k + ']'); }, esc = Go.esc;
  var money = function (c) { return '$' + ((+c || 0) / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var day = function (d) { return d ? new Date(d + 'T12:00:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : ''; };
  function api(b) {
    b.type = T; b.id = ID; $('err').hidden = true;
    return Go.call('/api/plans.php', b).then(function (d) { V = d.view; if (d.message) { $('msg').textContent = d.message; $('msg').hidden = false; } paint(); return d; },
      function (x) { $('err').textContent = x.message; $('err').hidden = false; throw x; });
  }
  var tb = $('try');
  if (tb) tb.addEventListener('click', function () {
    if (window.TvAsk && TvAsk.busy) TvAsk.busy(tb, true);
    api({ action: 'try' }).then(function () { var c = $('trycard'); if (c) c.remove(); }, function () {}).then(function () { if (window.TvAsk && TvAsk.busy && tb.isConnected) TvAsk.busy(tb, false); });
  });
  function planOf(k) { return V.plans.filter(function (p) { return p.key === k; })[0]; }
  function paint() {
    var s = V.sub, a = V.allowance;
    $('title').textContent = 'Plan for ' + V.name;
    var now = '';
    if (!s) now = 'You\'re on the <b>' + esc(planOf(a.plan).name) + '</b> plan, at no cost.';
    else if (s.status === 'trial') now = '<b>' + esc(s.name) + '</b>, free trial until <b>' + day(s.trial_ends) + '</b>. It goes back to the free plan on its own unless you keep it below.';
    else {
      now = '<b>' + esc(s.name) + '</b>, ' + money(s.price) + (s.cycle === 'year' ? ' a year' : ' a month') + '. ';
      if (s.status === 'past_due') now += '<br><b style="color:var(--tv-crimson,#B91C1C)">Your card was declined.</b> We\'ll try again on ' + day(s.next_try) + '. Update the card to settle it now.';
      else if (s.cancel_at_end) now += 'Stops on ' + day(s.period_end) + '. <a href="#" data-resume>Keep renewing</a>';
      else now += 'Renews ' + day(s.period_end) + (s.card ? ' on ' + esc(s.card) : '') + '.' + (s.next_plan ? ' Moves to ' + esc(s.next_plan) + ' then.' : '')
        + (s.promo ? ' Your code takes ' + s.promo.percent + '% off the plan ' + (s.promo.left === 255 ? 'at every renewal.' : (s.promo.left === 1 ? 'at the next renewal.' : 'at the next ' + s.promo.left + ' renewals.')) : '');
      now += '<div style="margin-top:.5rem;display:flex;gap:.4rem;flex-wrap:wrap"><button type="button" class="go-btn sm" data-newcard>Update the card</button>'
        + (s.cancel_at_end ? '' : '<button type="button" class="go-btn sm" data-stop>Stop at the end of this period</button>') + '</div>';
    }
    now += '<p class="go-note" style="margin-top:.4rem">Includes ' + a.storage_gb + ' GB storage' + (a.ai_credits ? ' and ' + a.ai_credits + ' AI Assist credits a month' : '') + '.</p>';
    $('now').innerHTML = now;
    var paid = s && s.status !== 'trial';
    if (paid) cyc = s.cycle;
    $('cyc').innerHTML = paid ? '<p class="go-note">Billed ' + (cyc === 'year' ? 'yearly' : 'monthly') + '.</p>'
      : '<div class="pl-cyc" role="group" aria-label="Billing"><button type="button" data-c="month" class="' + (cyc === 'month' ? 'on' : '') + '">Monthly</button><button type="button" data-c="year" class="' + (cyc === 'year' ? 'on' : '') + '">Yearly: 2 months free</button></div>';
    if (pick === null) pick = s ? s.plan : (a.plan);
    $('plans').innerHTML = V.plans.map(function (p) {
      var cur = s ? s.plan === p.key : a.plan === p.key, price = p.month ? money(cyc === 'year' ? p.year : p.month) + (cyc === 'year' ? '/yr' : '/mo') : 'Free';
      return '<label class="pl-row' + (pick === p.key ? ' on' : '') + '"><input type="radio" name="pl" value="' + p.key + '"' + (pick === p.key ? ' checked' : '') + '><span><b>' + esc(p.name)
        + (cur ? '<span class="pl-tag">' + (s && s.status === 'trial' ? 'Trial' : 'Now') + '</span>' : '') + '</b><small>' + p.gb + ' GB storage' + (p.ai ? ', ' + p.ai + ' AI Assist credits a month' : '') + '</small>' + inc(p) + '</span><span class="pl-price">' + price + '</span></label>';
    }).join('');
    paintPacks(); paintRec(); action();
  }
  function inc(p) {   // what the plan includes: everything in the one below, plus these
    if (!p.adds || !p.adds.length) return '';
    return '<div class="pl-inc">' + (p.after ? 'Everything in ' + esc(p.after) + ', plus:' : 'Includes:') + '<ul>' + p.adds.map(function (a) { return '<li>' + esc(a) + '</li>'; }).join('') + '</ul></div>';
  }
  function paintPacks() {
    var s = V.sub, on = s && s.status === 'active';
    $('packs-card').hidden = !on; if (!on) return;
    var have = s.addons.map(function (x) { return '<div class="pl-pack"><span>' + esc(x.name) + (x.qty > 1 ? ' × ' + x.qty : '') + (x.off ? ' <i class="go-note">comes off ' + day(s.period_end) + '</i>' : '') + '</span>'
      + '<button type="button" class="go-btn sm" data-off="' + x.id + '" data-v="' + (x.off ? 0 : 1) + '">' + (x.off ? 'Keep it' : 'Remove at renewal') + '</button></div>'; }).join('');
    $('packs').innerHTML = have + V.packs.map(function (p) {
      return '<div class="pl-pack"><span>' + esc(p.name) + ' <span class="go-note">' + money(p.month) + ' a month</span></span><button type="button" class="go-btn sm" data-add="' + p.key + '">Add</button></div>';
    }).join('');
  }
  function paintRec() {
    var s = V.sub, r = s ? s.charges : [];
    $('rec-card').hidden = !r.length;
    $('rec').innerHTML = r.map(function (c) { return '<div class="pl-line"><span>' + day(c.when) + ' · ' + esc({ start: 'Plan started', renewal: 'Renewal', upgrade: 'Plan change', addon: 'Pack' }[c.kind] || c.kind) + (c.status !== 'paid' ? ' <b style="color:var(--tv-crimson,#B91C1C)">declined</b>' : '') + '</span><span>' + money(c.amount) + '</span></div>'; }).join('');
  }
  function action() {
    var s = V.sub, box = $('act'), p = planOf(pick), paid = s && s.status !== 'trial';
    box.innerHTML = '';
    if (!p) return;
    if (!p.month) {   // the free plan
      box.innerHTML = '<p class="go-note">' + (!s ? 'You\'re on the free plan.' : s.status === 'trial' ? 'Your trial goes back to Free on its own on ' + day(s.trial_ends) + '.' : 'To go back to Free, choose <b>Stop at the end of this period</b> above. Everything stays until then.') + '</p>';
      return;
    }
    if (paid) {
      if (s.status !== 'active') { box.innerHTML = '<p class="go-note">Update the card first, then change the plan.</p>'; return; }
      Go.call('/api/plans.php', { type: T, id: ID, action: 'quote', plan: pick }).then(function (d) {
        var c = d.change; if (!c || c.when === 'same') { box.innerHTML = '<p class="go-note">This is your plan.</p>'; return; }
        box.innerHTML = '<p class="go-note">' + (c.when === 'now' ? 'Starts now. Charged today for the rest of this period: <b>' + money(c.charge) + '</b>; then ' + money(d.quote.lines[0][1]) + (s.cycle === 'year' ? ' a year.' : ' a month.')
          : 'Starts at your renewal on ' + day(s.period_end) + '. Nothing is charged now, and you keep ' + esc(s.name) + ' until then.') + '</p>'
          + '<button type="button" class="go-btn main" data-change style="margin-top:.4rem">Change to ' + esc(p.name) + '</button>';
      });
      return;
    }
    // no plan yet, or a trial to keep: the total and the card
    Go.call('/api/plans.php', { type: T, id: ID, action: 'quote', plan: pick, cycle: cyc, promo: PROMO ? PROMO.code : '' }).then(function (d) {
      var q = d.quote;
      box.innerHTML = q.lines.map(function (l) { return '<div class="pl-line"><span>' + esc(l[0]) + '</span><span>' + money(l[1]) + '</span></div>'; }).join('')
        + '<div class="go-sum"><span>' + (PROMO ? 'Today' : 'Today, then every ' + (cyc === 'year' ? 'year' : 'month')) + '</span><span>' + money(q.total) + '</span></div>'
        + (PROMO ? '<p class="go-note">With your code ' + esc(PROMO.code) + ': ' + esc(PROMO.offer) + '. After that, the plan\'s full price.</p>' : '') + '<div data-pay></div>';
      Go.cardForm(box.querySelector('[data-pay]'), { id: 'pl', subtotal_cents: q.total, tax_cents: 0, total_cents: q.total }, V.pay,
        { amount: q.total, summary: false, label: (s ? 'Keep ' : 'Start ') + p.name + ' · ' + money(q.total),
          note: 'Renews on its own; stop any time from this page. A receipt is emailed each time.',
          pay: function (tok) { return api({ action: 'start', plan: pick, cycle: cyc, addons: {}, token: tok, promo: PROMO ? PROMO.code : '' }).then(function (d) { PROMO = null; $('promo-note').hidden = true; return d; }); },
          onPaid: function () { window.scrollTo(0, 0); } });
    });
  }
  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('button,a,input'); if (!t || !t.closest('.go')) return;
    if (t.name === 'pl') { pick = t.value; paint(); return; }
    if (t.dataset.c) { cyc = t.dataset.c; paint(); return; }
    if (t.hasAttribute('data-apply')) { applyCode(); return; }
    if (t.hasAttribute('data-change')) { api({ action: 'change', plan: pick }); return; }
    if (t.hasAttribute('data-stop')) { if (!TvAsk.gate(t, 'Stop your plan at the end of this period? Everything stays until ' + day(V.sub.period_end) + '.', { yes: 'Stop it', danger: true })) return; api({ action: 'cancel', stop: true }); return; }
    if (t.hasAttribute('data-resume')) { ev.preventDefault(); api({ action: 'cancel', stop: false }); return; }
    if (t.dataset.add) { var pk = V.packs.filter(function (x) { return x.key === t.dataset.add; })[0];
      Go.call('/api/plans.php', { type: T, id: ID, action: 'quote', plan: V.sub.plan, addon: pk.key }).then(function (d) {
        if (!TvAsk.gate(t, 'Add ' + pk.name + '? ' + money(d.addon_now) + ' now for the rest of this period, then ' + money(pk.month * (V.sub.cycle === 'year' ? 12 : 1)) + (V.sub.cycle === 'year' ? ' a year' : ' a month') + ' with your plan.', { yes: 'Add it' })) return;
        api({ action: 'addon', addon: pk.key, qty: 1 });
      }); return; }
    if (t.dataset.off) { api({ action: 'remove', aid: +t.dataset.off, remove: t.dataset.v === '1' }); return; }
    if (t.hasAttribute('data-newcard')) {
      var cb = $('cardbox'); cb.hidden = !cb.hidden; if (cb.hidden) return;
      Go.cardForm(cb, { id: 'plc', subtotal_cents: 0, tax_cents: 0, total_cents: 0 }, V.pay, { amount: 0, summary: false, label: 'Save this card',
        note: V.sub.status === 'past_due' ? 'The declined payment is tried on it right away.' : 'Nothing is charged now.',
        pay: function (tok) { return api({ action: 'card', token: tok }); }, onPaid: function () { cb.hidden = true; } });
    }
  });
  function applyCode() {
    var c = $('code').value.trim(); if (!c) return;
    api({ action: 'code', code: c }).then(function (d) {
      var n = $('promo-note');
      if (d.promo) { PROMO = d.promo; n.innerHTML = '<b>' + esc(d.promo.code) + '</b>: ' + esc(d.promo.offer) + (d.promo.terms ? '. ' + esc(d.promo.terms) : '') + ' <a href="#" data-unpromo>Remove</a>'; n.hidden = false; action(); }
      else { n.hidden = true; $('code').value = ''; pick = null; paint(); }
    }, function () {});
  }
  document.addEventListener('click', function (ev) { if (ev.target.closest('[data-unpromo]')) { ev.preventDefault(); PROMO = null; $('promo-note').hidden = true; $('code').value = ''; action(); } });
  api({ action: 'status' }).then(function () { if ($('code').value) applyCode(); });
})();
</script>
<?php endif; ?>
<?php tv_page_end();
