<?php
// nexus.php?slug=… — an organization with many locations (decisions/0054 §4): what it is, its website, and every
// location as a card (name, what it is there, address, Call and Directions), nearest to the visitor first when the
// browser knows where they are, else by town. Each location's own page says "Part of …" and links back here.
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/../app/ui/page-shell.php';
require_once __DIR__ . '/../app/lib/Nexus.php';

$pdo = Database::connection();
$n = Nexus::ready($pdo) ? Nexus::bySlug($pdo, trim((string) ($_GET['slug'] ?? ''))) : null;
if (!$n) {
    http_response_code(404);
    tv_page_start('Not found', ['no_crumbs' => true]);
    echo '<h1 class="font-serif font-bold text-2xl mt-4">That organization isn\'t listed</h1><p class="mt-2"><a class="underline" href="/directory/">Search the directory</a></p>';
    tv_page_end(); exit;
}
$locs = Nexus::members($pdo, (int) $n['id'], true);
usort($locs, fn ($a, $b) => [$a['closed'], $a['city'], $a['name']] <=> [$b['closed'], $b['city'], $b['name']]);
$parent = $n['parent_id'] ? Nexus::get($pdo, (int) $n['parent_id']) : null;
$kids = array_values(array_filter(Nexus::all($pdo), fn ($x) => (int) $x['parent_id'] === (int) $n['id'] && $x['status'] === 'active'));
$towns = count(array_unique(array_filter(array_column($locs, 'city'))));
if (function_exists('tv_count_item')) tv_count_item('nexus:' . (int) $n['id']);
$ic = fn (string $p) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
$web = (string) $n['website'];

tv_page_start($n['name'], ['no_crumbs' => true, 'description' => $n['name'] . ': ' . count($locs) . ' locations' . ($towns ? ' in ' . $towns . ' town' . ($towns === 1 ? '' : 's') : '') . '.']);
?>
<style>
  .nxp{max-width:60rem;margin:0 auto;padding:.8rem .3rem 1.5rem}
  .nxp-kick{font-size:.7rem;letter-spacing:.09em;text-transform:uppercase;color:var(--tv-meta,#8A7355)}
  .nxp h1{font:700 clamp(1.5rem,3vw,2rem)/1.15 var(--tv-font-head,Georgia,serif);color:var(--tv-ink,#3E2B1F);margin:.15rem 0 .2rem}
  .nxp-sub{color:var(--tv-meta,#5C4632);font-size:.92rem}
  .nxp-about{margin-top:.7rem;color:var(--tv-ink,#3E2B1F);font-size:.95rem;line-height:1.5;white-space:pre-line;max-width:46rem}
  .nxp-b{display:inline-flex;align-items:center;gap:.35rem;font-weight:700;font-size:.88rem;border-radius:.7rem;padding:.45rem .9rem;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);text-decoration:none;margin-top:.7rem}
  .nxp-b svg{width:16px;height:16px;color:var(--tv-icon,#B45309)}
  .nxp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(17rem,100%),1fr));gap:.6rem;margin-top:.8rem}
  .nxp-c{display:flex;justify-content:space-between;gap:.5rem;background:var(--tv-sec,#F7EFDC);border:1px solid var(--tv-line,#EADFC4);border-radius:.8rem;padding:.7rem .8rem}
  .nxp-c .n{font-weight:700;color:var(--tv-link,#92400E);text-decoration:underline}
  .nxp-c small{display:block;color:var(--tv-meta,#5C4632);font-size:.82rem;margin-top:.12rem}
  .nxp-c .acts{display:flex;flex-direction:column;gap:.3rem;flex-shrink:0}
  .nxp-c .acts a{width:30px;height:30px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-icon,#B45309)}
  .nxp-c .acts svg{width:15px;height:15px}
  .nxp h2{font:700 1.15rem var(--tv-font-head,Georgia,serif);color:var(--tv-ink,#3E2B1F);margin:1.3rem 0 0}
  .nxp-closed{opacity:.75}
  @media (max-width:767px){ .nxp-grid{gap:3px} }
</style>
<div class="nxp">
  <p class="nxp-kick"><?= tv_e(['brand' => 'Organization', 'system' => 'System', 'affiliation' => 'Network'][$n['kind']] ?? 'Organization') ?><?= $parent ? ' · part of <a class="underline" href="/nexus.php?slug=' . tv_e($parent['slug']) . '">' . tv_e($parent['name']) . '</a>' : '' ?></p>
  <h1><?= tv_e($n['name']) ?></h1>
  <p class="nxp-sub"><?= count($locs) ?> location<?= count($locs) === 1 ? '' : 's' ?><?= $towns ? ' in ' . $towns . ' town' . ($towns === 1 ? '' : 's') : '' ?></p>
  <?php if (trim((string) $n['about']) !== ''): ?><p class="nxp-about"><?= tv_e((string) $n['about']) ?></p><?php endif; ?>
  <?php if ($web !== ''): ?><a class="nxp-b" href="<?= tv_e($web) ?>" target="_blank" rel="noopener nofollow"><?= $ic('<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/>') ?>Website</a><?php endif; ?>

  <?php if ($kids): ?><h2>Its branches</h2><p class="mt-1 text-sm"><?php foreach ($kids as $i => $k): ?><?= $i ? ' · ' : '' ?><a class="underline text-[color:var(--tv-link)]" href="/nexus.php?slug=<?= tv_e($k['slug']) ?>"><?= tv_e($k['name']) ?></a> (<?= (int) $k['members'] ?>)<?php endforeach; ?></p><?php endif; ?>

  <h2>Locations</h2>
  <div class="nxp-grid" id="nxp-list">
    <?php foreach ($locs as $o): $otel = preg_replace('/[^\d+]/', '', $o['phone']); $odir = $o['address'] !== '' ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($o['address'] . ', ' . $o['city'] . ' ' . $o['state']) : ''; ?>
    <div class="nxp-c tv-bleed<?= $o['closed'] ? ' nxp-closed' : '' ?>" data-lat="<?= $o['lat'] ?? '' ?>" data-lon="<?= $o['lon'] ?? '' ?>"><div><a class="n" href="/listing/view.php?id=<?= $o['id'] ?>"><?= tv_e($o['name']) ?></a><?= $o['city'] !== '' && mb_stripos($o['name'], $o['city']) === false ? ' <b style="color:var(--tv-ink,#3E2B1F)">· ' . tv_e($o['city']) . '</b>' : '' ?>
      <small><?= tv_e(implode(' · ', array_filter([$o['closed'] ? 'Closed' : '', $o['role'] !== 'location' ? (Nexus::ROLES[$o['role']] ?? '') : '', $o['category']]))) ?></small>
      <small><?= tv_e(trim($o['address'] . ($o['city'] !== '' ? ', ' . $o['city'] : ''), ', ')) ?></small><?php if ($o['phone'] !== ''): ?><small><?= tv_e($o['phone']) ?></small><?php endif; ?></div>
      <div class="acts"><?php if ($otel): ?><a href="tel:<?= tv_e($otel) ?>" title="Call" aria-label="Call <?= tv_e($o['name']) ?>" data-out="call" data-e="<?= $o['id'] ?>"><?= $ic('<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>') ?></a><?php endif; ?>
        <?php if ($odir): ?><a href="<?= tv_e($odir) ?>" target="_blank" rel="noopener" title="Directions" aria-label="Directions to <?= tv_e($o['name']) ?>" data-out="directions" data-e="<?= $o['id'] ?>"><?= $ic('<polygon points="3 11 22 2 13 21 11 13 3 11"/>') ?></a><?php endif; ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<script>
  // nearest first when the visitor's place is set on this device (location-scope.js keeps it); nothing is asked
  (function () {
    var loc = (typeof currentLocation !== 'undefined' && currentLocation) ? currentLocation : null;
    if (!loc || loc.lat == null || loc.lon == null || loc.lat === '') return;
    var box = document.getElementById('nxp-list'), cards = [].slice.call(box.children);
    function mi(c) { var a = +c.getAttribute('data-lat'), b = +c.getAttribute('data-lon'); if (!c.getAttribute('data-lat')) return 1e9; var r = Math.PI / 180, x = Math.sin((a - loc.lat) * r / 2), y = Math.sin((b - loc.lon) * r / 2); return 7917.6 * Math.asin(Math.sqrt(x * x + Math.cos(a * r) * Math.cos(loc.lat * r) * y * y)); }
    cards.sort(function (p, q) { return (p.classList.contains('nxp-closed') - q.classList.contains('nxp-closed')) || (mi(p) - mi(q)); }).forEach(function (c) { box.appendChild(c); });
  })();
</script>
<?php tv_page_end();
