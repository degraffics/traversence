<?php
// /guide/resources.php?id=3 (or ?area=cluster:<slug>) — a resource guide (decisions/0061): who to call in an area for
// the things that aren't businesses. Only entries whose number was found on their official source show. Content page
// standard (decisions/0058 §20): header with the kind (searches for more), title, place and Link button; Engage bar;
// the entries as cards (name is the link, Call and Website down the right); comments.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
require_once __DIR__ . '/../../app/ui/app-shell.php';
require_once __DIR__ . '/../../app/lib/ResourceGuides.php';

$pdo = Database::connection();
$g = null;
if (ResourceGuides::ready($pdo)) {
    if (isset($_GET['id'])) $g = ResourceGuides::guide($pdo, (int) $_GET['id']);
    elseif (isset($_GET['area'])) $g = ResourceGuides::guideByArea($pdo, mb_substr((string) $_GET['area'], 0, 100));
}
if ($g && $g['status'] !== 'live') $g = null;
$title = $g ? (string) $g['title'] : 'Guide not found';
if (!$g) http_response_code(404);
tv_page_start($title, ['no_crumbs' => true, 'description' => $g ? 'Phone lines and services, checked against each provider\'s own site.' : '']);
if (!$g): ?>
  <div class="max-w-xl"><h1 class="font-serif font-bold text-2xl">Guide not found</h1><p class="text-sm text-[color:var(--tv-meta)] mt-2">It may not be published yet.</p></div>
<?php tv_page_end(); exit; endif;

tv_count_item('guide:' . (int) $g['id']);   // the platform's counts
$areas = ResourceGuides::areas($pdo);
$areaName = $areas[$g['area_key']] ?? '';
$entries = array_values(array_filter($g['entries'], fn ($x) => $x['status'] === 'live' && (int) $x['verified'] === 1));
require_once __DIR__ . '/../../app/ui/engage-ui.php';
$here = $g['area_key'] !== 'all' ? $areaName : '';
$ico = ['call' => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
        'web' => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>'];
$svg = fn (string $k) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $ico[$k] . '</svg>';
?>
<style>
  .rgp{max-width:46rem}
  .rgp-head{position:relative;background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.8rem 3rem .8rem .9rem}
  .rgp-kick{display:flex;flex-wrap:wrap;gap:.15rem .5rem;font-size:.7rem;letter-spacing:.09em;text-transform:uppercase;color:var(--tv-meta,#8A7355);margin:0}
  .rgp-q{background:none;border:0;padding:0;font:inherit;letter-spacing:inherit;text-transform:inherit;color:var(--tv-link,#92400E);cursor:pointer;text-decoration:underline;text-decoration-color:rgba(146,64,14,.3);text-underline-offset:3px}
  .rgp-head h1{font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-weight:700;font-size:1.45rem;color:var(--tv-ink,#3E2B1F);margin:.25rem 0 .1rem}
  .rgp-place{font-size:.86rem;color:var(--tv-meta,#5C4632);margin:0}.rgp-intro{font-size:.93rem;line-height:1.6;color:var(--tv-ink,#3E2B1F);margin:.6rem 0 0;white-space:pre-line}
  .rgp-eng{margin:.6rem 0}
  .rgp-list{display:grid;gap:.6rem;margin-top:.6rem}
  .rgp-e{position:relative;background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.7rem 3rem .75rem .9rem;min-height:5.2rem}
  .rgp-e a.n{font-weight:700;color:var(--tv-link,#92400E);text-decoration:underline;font-size:1rem}
  .rgp-e p{margin:.2rem 0 0;font-size:.88rem;color:var(--tv-ink,#3E2B1F)}.rgp-e .ph{font-weight:600}.rgp-e .h{color:var(--tv-meta,#5C4632)}
  .rgp-e .src{font-size:.72rem;color:var(--tv-meta,#8A7355)}.rgp-e .src a{color:var(--tv-link,#92400E)}
  .rgp-acts{position:absolute;top:.6rem;right:.55rem;display:flex;flex-direction:column;gap:.3rem}
  .rgp-a{display:flex;align-items:center;justify-content:center;width:30px;height:30px;color:var(--tv-icon,#B45309);background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;text-decoration:none}
  .rgp-a svg{width:16px;height:16px}.rgp-a:hover{border-color:#B45309;background:#FEF3C7}
  .rgp-note{font-size:.8rem;color:var(--tv-meta,#5C4632);margin:.8rem 0}
</style>
<div class="rgp">
  <header class="rgp-head tv-bleed" data-link-host>
    <span data-link="place:guide:<?= (int) $g['id'] ?>" data-link-label="<?= tv_e($title) ?>"></span>
    <p class="rgp-kick"><button type="button" class="rgp-q" data-q="<?= tv_e('help' . ($here !== '' ? ' in ' . $here : '')) ?>" title="Find more help<?= $here !== '' ? ' in ' . tv_e($here) : '' ?>">Resource guide</button></p>
    <h1><?= tv_e($title) ?></h1>
    <?php if ($areaName !== ''): ?><p class="rgp-place"><?= tv_e($areaName) ?></p><?php endif; ?>
    <?php if (trim((string) $g['intro']) !== ''): ?><p class="rgp-intro"><?= tv_e((string) $g['intro']) ?></p><?php endif; ?>
  </header>
  <div class="rgp-eng"><?= tv_engage_bar($pdo, 'guide', (string) $g['id'], ['title' => $title]) ?></div>
  <p class="rgp-note">If anyone is in danger, call 911. Every number here was found on the provider's own website when we last checked; if one is wrong, tell us below.</p>
  <div class="rgp-list">
    <?php foreach ($entries as $x): $tel = preg_replace('/[^\d+]/', '', (string) $x['phone']); ?>
      <article class="rgp-e tv-bleed" id="r<?= (int) $x['id'] ?>">
        <a class="n" href="<?= tv_e($x['source_url']) ?>" target="_blank" rel="noopener"><?= tv_e($x['name']) ?></a>
        <?php if ($x['phone'] !== ''): ?><p class="ph"><?= tv_e($x['phone']) ?></p><?php endif; ?>
        <?php if ($x['purpose'] !== ''): ?><p><?= tv_e($x['purpose']) ?></p><?php endif; ?>
        <?php if ($x['hours'] !== ''): ?><p class="h"><?= tv_e($x['hours']) ?></p><?php endif; ?>
        <p class="src">Checked <?= tv_e(date('M j, Y', strtotime((string) $x['last_checked']))) ?> on <a href="<?= tv_e($x['source_url']) ?>" target="_blank" rel="noopener"><?= tv_e(parse_url((string) $x['source_url'], PHP_URL_HOST) ?: 'its site') ?></a></p>
        <div class="rgp-acts">
          <?php if ($tel !== ''): ?><a class="rgp-a" href="tel:<?= tv_e($tel) ?>" title="Call <?= tv_e($x['name']) ?>" aria-label="Call <?= tv_e($x['name']) ?>"><?= $svg('call') ?></a><?php endif; ?>
          <a class="rgp-a" href="<?= tv_e($x['source_url']) ?>" target="_blank" rel="noopener" title="Website" aria-label="<?= tv_e($x['name']) ?> website"><?= $svg('web') ?></a>
        </div>
      </article>
    <?php endforeach; ?>
    <?php if (!$entries): ?><p class="rgp-note">Nothing here has been checked yet.</p><?php endif; ?>
  </div>
  <p class="rgp-note"><button type="button" class="underline" data-tv-suggest="<?= tv_e(json_encode(['target' => 'guide:' . (int) $g['id'], 'target_name' => $title, 'topic' => 'help'], JSON_UNESCAPED_UNICODE)) ?>">A number wrong or missing? Tell us</button></p>
  <?= tv_engage_comments($pdo, 'guide', (string) $g['id']) ?>
</div>
<script>
  document.querySelector('.rgp').addEventListener('click', function (e) { var b = e.target.closest('[data-q]'); if (b && window.TvSearch) TvSearch.open(b.getAttribute('data-q')); });
</script>
<script src="/js/link-button.js?v=<?= (int) @filemtime(__DIR__ . '/../js/link-button.js') ?>" defer></script>
<?php tv_page_end();
