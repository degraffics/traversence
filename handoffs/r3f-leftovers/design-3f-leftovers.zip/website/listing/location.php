<?php
// listing/location.php?id= — where a listing is (decisions/0058 §15). One page for everyone:
//   a visitor drags the pin (or taps the map, or "I'm here") and sends it; a person checks it in Review;
//   the business (owner or manager) and Traversence staff drag the pin and it's saved at once, or change the address.
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';   // the session (who's looking)
header('Content-Type: text/html; charset=utf-8'); // bootstrap defaults to JSON
header('Cache-Control: private, no-cache');
require_once __DIR__ . '/../../app/ui/page-shell.php';
require_once __DIR__ . '/../../app/lib/ListingLocation.php';

$pdo = Database::connection();
$id = (int) ($_GET['id'] ?? 0);
$l = $id > 0 ? ListingLocation::get($pdo, $id) : null;
tv_page_start($l ? 'Where is ' . $l['name'] . '?' : 'Listing not found', ['no_crumbs' => true, 'description' => 'Put this listing\'s pin where it is.']);
$uid = Auth::currentUserId();   // after the page starts the session
$role = $l ? ListingLocation::role($pdo, $uid, $id) : 'visitor';
$canSet = $role !== 'visitor';
if (!$l) { echo '<p>That listing isn\'t there any more. <a href="/directory/">Back to the directory</a></p>'; tv_page_end(); return; }
?>
<style>
  .ll-card{background:var(--tv-card-a,#FFFBF2);border:1px solid rgba(203,185,141,.75);border-radius:.8rem;padding:.8rem .9rem;margin-bottom:.6rem}
  .ll-card h1{margin:0 0 .25rem;font-family:var(--tv-font-head,ui-serif,Georgia,serif);font-size:clamp(1.3rem,4.4vw,1.8rem);color:var(--tv-ink,#3E2B1F);line-height:1.2}
  .ll-card h1 a{color:var(--tv-link,#92400E);text-underline-offset:3px}
  .ll-p{margin:.2rem 0;font-size:.88rem;color:var(--tv-meta,#5C4632);line-height:1.45}
  .ll-who{display:inline-block;font-size:.7rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;border-radius:999px;padding:.12rem .55rem;background:#E8F2EC;color:#2F5D4A;margin-bottom:.35rem}
  .ll-who.v{background:#FEF3C7;color:var(--tv-link,#92400E)}
  #ll-map{height:min(58vh,520px);border-radius:.8rem;border:1px solid rgba(203,185,141,.75);background:var(--tv-sec,#EADFC4)}
  .ll-bar{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center;margin:.55rem 0}
  .ll-btn{display:inline-flex;align-items:center;gap:.35rem;border-radius:999px;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F);font-weight:600;font-size:.86rem;padding:.45rem .9rem;cursor:pointer}
  .ll-btn.go{background:var(--tv-umber,#3E2B1F);border-color:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2)}.ll-btn[disabled]{opacity:.5;cursor:default}
  .ll-lay{margin-left:auto;display:flex;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:999px;overflow:hidden}
  .ll-lay button{border:0;background:var(--tv-card-a,#FFFBF2);padding:.35rem .7rem;font-size:.78rem;font-weight:600;color:var(--tv-meta,#5C4632);cursor:pointer}.ll-lay button.on{background:var(--tv-umber,#3E2B1F);color:var(--tv-on-umber,#FFFBF2)}
  .ll-msg{font-size:.86rem;margin:.3rem 0;min-height:1.2em}.ll-msg.ok{color:#2F5D4A;font-weight:600}.ll-msg.err{color:var(--tv-crimson,#B91C1C)}
  .ll-f{display:grid;grid-template-columns:1fr;gap:.45rem}.ll-f label{font-size:.75rem;font-weight:700;color:var(--tv-meta,#5C4632);display:grid;gap:.15rem}
  .ll-f input,.ll-f textarea{font:inherit;font-size:.92rem;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.5rem;padding:.45rem .55rem;background:var(--tv-card-a,#fff);color:var(--tv-ink,#3E2B1F);width:100%;box-sizing:border-box}
  .ll-row{display:grid;grid-template-columns:2fr .8fr 1.1fr;gap:.45rem}
  .ll-pin{background:none;border:0}.ll-pin svg{filter:drop-shadow(0 2px 2px rgba(0,0,0,.35));cursor:grab}
  .ll-card h2{font-size:1rem;margin:0 0 .35rem;color:var(--tv-ink,#3E2B1F)}
</style>
<div class="ll-card">
  <span class="ll-who <?= $canSet ? '' : 'v' ?>"><?= $role === 'staff' ? 'Traversence staff' : ($role === 'owner' ? 'Your business' : 'Suggest a fix') ?></span>
  <h1>Where is <a href="/listing/view.php?id=<?= $id ?>"><?= tv_e($l['name']) ?></a>?</h1>
  <?php if ($l['private']): ?>
    <p class="ll-p">This listing's location is kept private for the safety of the people it serves, so it has no pin on the map.</p>
  <?php else: ?>
    <p class="ll-p"><?= tv_e(trim(implode(', ', array_filter([$l['address'], $l['city'], trim($l['state'] . ' ' . $l['zip'])])))) ?></p>
    <?php if ($l['approx']): ?><p class="ll-p"><b>The pin is approximate:</b> it's in the middle of the ZIP area, not at the business.</p><?php endif; ?>
    <p class="ll-p"><?= $canSet ? 'Drag the pin (or tap the map) to the front door, then <b>Save the pin</b>. It moves for everyone at once.'
                                  : 'Drag the pin (or tap the map) to where it is, then <b>Send</b>. We check every suggestion before the map changes.' ?></p>
  <?php endif; ?>
</div>
<?php if (!$l['private']): ?>
<div id="ll-map" role="application" aria-label="Map: drag the pin to where <?= tv_e($l['name']) ?> is"></div>
<div class="ll-bar">
  <button type="button" class="ll-btn go" id="ll-save" disabled><?= $canSet ? 'Save the pin' : 'Send' ?></button>
  <button type="button" class="ll-btn" id="ll-here" title="Use where you are now (only for this pin; it isn't kept anywhere else)">I'm here now</button>
  <button type="button" class="ll-btn" id="ll-reset">Undo</button>
  <span class="ll-lay" role="group" aria-label="Map layer"><button type="button" data-lay="sat" class="on">Satellite</button><button type="button" data-lay="str">Streets</button></span>
</div>
<p class="ll-msg" id="ll-msg" aria-live="polite"></p>
<?php if (!$canSet): ?>
<div class="ll-card ll-f"><label>Anything to add? (optional)<textarea id="ll-note" rows="2" maxlength="500" placeholder="Behind the gas station, entrance on 2nd St…"></textarea></label></div>
<?php else: ?>
<form class="ll-card ll-f" id="ll-addr">
  <h2>Address</h2>
  <p class="ll-p" style="margin-top:0">Moved, or the address is wrong? Change it and the pin follows it. Then check the pin.</p>
  <label>Street address<input name="street" value="<?= tv_e($l['address']) ?>" autocomplete="street-address" required></label>
  <div class="ll-row">
    <label>Town<input name="city" value="<?= tv_e($l['city']) ?>" required></label>
    <label>State<input name="state" value="<?= tv_e($l['state']) ?>" maxlength="2" required></label>
    <label>ZIP<input name="zip" value="<?= tv_e($l['zip']) ?>" inputmode="numeric" maxlength="5" required></label>
  </div>
  <div><button type="submit" class="ll-btn go">Save the address</button></div>
</form>
<?php endif; ?>
<script>
(function () {
  var ID = <?= $id ?>, CAN = <?= $canSet ? 'true' : 'false' ?>, start = <?= json_encode($l['lat'] !== null ? [$l['lat'], $l['lon']] : null) ?>;
  var csrf = '', msg = document.getElementById('ll-msg'), save = document.getElementById('ll-save'), map, pin, tiles, moved = false;
  function say(t, cls) { msg.textContent = t; msg.className = 'll-msg' + (cls ? ' ' + cls : ''); }
  function post(body) {
    return (csrf ? Promise.resolve() : fetch('/api/pin.php?id=' + ID, { credentials: 'include' }).then(function (r) { return r.json(); }).then(function (d) { csrf = d.csrf || ''; }))
      .then(function () { return fetch('/api/pin.php', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(Object.assign({ id: ID }, body)) }); })
      .then(function (r) { return r.json(); });
  }
  var cdn = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/';
  var css = document.createElement('link'); css.rel = 'stylesheet'; css.href = cdn + 'leaflet.min.css'; document.head.appendChild(css);
  var js = document.createElement('script'); js.src = cdn + 'leaflet.min.js'; js.onload = init; js.onerror = function () { say('The map could not load. Please try again.', 'err'); }; document.head.appendChild(js);
  var LAY = { sat: ['https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/{z}/{y}/{x}', { maxZoom: 16, attribution: 'USGS The National Map' }],
              str: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors', referrerPolicy: 'strict-origin-when-cross-origin' }] };
  function layer(k) {
    if (tiles) map.removeLayer(tiles);
    tiles = L.tileLayer(LAY[k][0], LAY[k][1]).addTo(map);
    [].forEach.call(document.querySelectorAll('[data-lay]'), function (b) { b.classList.toggle('on', b.getAttribute('data-lay') === k); });
  }
  function place(ll, pan) {
    pin.setLatLng(ll); moved = true; save.disabled = false;
    if (pan) map.setView(ll, Math.max(map.getZoom(), 16));
    say(CAN ? 'Pin moved. Save it when it\'s right.' : 'Pin moved. Send it when it\'s right.');
  }
  function init() {
    var c = start || [34.5, -109.4];
    map = L.map('ll-map', { zoomControl: true }).setView(c, start ? 16 : 7);
    layer('sat');
    var icon = L.divIcon({ className: 'll-pin', html: '<svg viewBox="0 0 24 34" width="34" height="48" aria-hidden="true"><path d="M12 33s11-12.2 11-20.5A11 11 0 0 0 1 12.5C1 20.8 12 33 12 33z" fill="#B45309" stroke="#FFFBF2" stroke-width="1.6"/><circle cx="12" cy="12.5" r="4.2" fill="#FFFBF2"/></svg>',
                           iconSize: [34, 48], iconAnchor: [17, 47] });
    pin = L.marker(c, { draggable: true, title: 'Drag to where it is', autoPan: true, icon: icon }).addTo(map);
    pin.on('dragend', function () { place(pin.getLatLng(), false); });
    map.on('click', function (e) { place(e.latlng, false); });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-lay]'); if (b && map) layer(b.getAttribute('data-lay'));
  });
  document.getElementById('ll-reset').addEventListener('click', function () { if (!pin || !start) return; pin.setLatLng(start); map.setView(start, 16); moved = false; save.disabled = true; say(''); });
  document.getElementById('ll-here').addEventListener('click', function () {
    if (!navigator.geolocation) { say('This device can\'t share where it is.', 'err'); return; }
    say('Finding where you are…');
    navigator.geolocation.getCurrentPosition(function (p) { if (pin) place([p.coords.latitude, p.coords.longitude], true); },
      function () { say('Couldn\'t get your location. Drag the pin instead.', 'err'); }, { enableHighAccuracy: true, timeout: 10000 });
  });
  save.addEventListener('click', function () {
    if (!moved || !pin) return;
    var ll = pin.getLatLng(), note = document.getElementById('ll-note');
    save.disabled = true; say(CAN ? 'Saving…' : 'Sending…');
    post({ action: 'pin', lat: ll.lat, lon: ll.lng, note: note ? note.value : '' }).then(function (d) {
      if (!d.ok) { save.disabled = false; say(d.error && d.error.message ? d.error.message : 'That didn\'t work. Please try again.', 'err'); return; }
      moved = false; start = [ll.lat, ll.lng];
      say(d.set ? 'Saved. The pin is here for everyone now.' : 'Thank you. We\'ll check it and move the pin.', 'ok');
    }).catch(function () { save.disabled = false; say('That didn\'t work. Please try again.', 'err'); });
  });
  var f = document.getElementById('ll-addr');
  if (f) f.addEventListener('submit', function (e) {
    e.preventDefault();
    var fd = new FormData(f), body = { action: 'address' }; fd.forEach(function (v, k) { body[k] = v; });
    say('Saving the address and finding it on the map…');
    post(body).then(function (d) {
      if (!d.ok) { say(d.error && d.error.message ? d.error.message : 'That didn\'t work. Please try again.', 'err'); return; }
      var l = d.listing;
      if (l.lat !== null && pin) { start = [l.lat, l.lon]; pin.setLatLng(start); map.setView(start, 16); moved = false; save.disabled = true; }
      say(l.approx ? 'Address saved. We couldn\'t find it exactly, so the pin is in the middle of the ZIP area: drag it to the door and save.' : 'Address saved, and the pin moved to it. Check it\'s at the door.', 'ok');
    }).catch(function () { say('That didn\'t work. Please try again.', 'err'); });
  });
})();
</script>
<?php endif; ?>
<?php tv_page_end();
