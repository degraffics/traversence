<?php
// verify-listing.php?t=… : the admin's one-tap verification (decisions/0071 §4). The link in the email opens this page:
// the listing and who's asking, one Confirm button (a POST, so a mail scanner opening the link verifies nothing), or
// Not yet with a note for the owner (&not=1 opens it there). The link is single-use, 14 days, and needs no sign-in.
require_once __DIR__ . '/../app/ui/page-shell.php';
require_once __DIR__ . '/../app/lib/Database.php';
if (!class_exists('Auth')) { require_once __DIR__ . '/../app/bootstrap.php'; header('Content-Type: text/html; charset=utf-8'); }
require_once __DIR__ . '/../app/lib/VerifyRequests.php';

header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');   // the token stays out of other sites' logs
$pdo = Database::connection();
$token = (string) ($_POST['t'] ?? $_GET['t'] ?? '');
$done = null; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $verify = ($_POST['do'] ?? '') === 'verify';
        VerifyRequests::decide($pdo, $token, $verify, (string) ($_POST['note'] ?? ''));
        $done = $verify ? 'verified' : 'not_yet';
    } catch (InvalidArgumentException $x) { $err = $x->getMessage(); }
}
$r = VerifyRequests::open($pdo, $token);
$notYet = !empty($_GET['not']) || ($_POST['do'] ?? '') === 'not_yet';

tv_page_start('Verify a listing', ['no_crumbs' => true, 'description' => 'Verify a listing from the request email.']);
$e = 'tv_e';
?>
<style>
  .vl{max-width:36rem}
  .vl-card{background:var(--tv-sec,#F7EFDC);border:1px solid rgba(203,185,141,.7);border-radius:1rem;padding:1rem 1.1rem;margin-top:.8rem}
  .vl-card h2{font:700 1.05rem var(--tv-font-head,Georgia,serif);color:var(--tv-ink,#3E2B1F);margin:0 0 .4rem}
  .vl dl{display:grid;grid-template-columns:max-content 1fr;gap:.25rem .8rem;margin:0;font-size:.9rem}.vl dt{color:var(--tv-meta,#8A7355)}.vl dd{margin:0;overflow-wrap:anywhere}
  .vl dd a{color:var(--tv-link,#92400E);text-decoration:underline}
  .vl-b{display:inline-flex;align-items:center;justify-content:center;font-weight:700;border-radius:.8rem;padding:.75rem 1.2rem;font-size:1rem;cursor:pointer;border:1px solid var(--tv-line-strong,#CBB98D);background:var(--tv-card-a,#FFFBF2);color:var(--tv-ink,#3E2B1F)}
  .vl-b.go{background:var(--tv-sage,#8FBCA8);border-color:var(--tv-sage,#8FBCA8);color:#1F3B30;min-width:12rem}
  .vl-in{width:100%;background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;padding:.55rem .7rem;font:inherit;font-size:.92rem;min-height:5rem}
  .vl-ok{font:700 1.2rem var(--tv-font-head,Georgia,serif);color:#166534}.vl-bad{color:var(--tv-crimson,#991B1B);font-size:.9rem}
  @media (max-width:767px){.vl-card{border-radius:.5rem}.vl-b.go{width:100%}}
</style>
<div class="vl">
  <h1 class="font-serif font-bold text-3xl">Verify a listing</h1>
<?php if ($done === 'verified'): ?>
  <div class="tv-bleed vl-card"><p class="vl-ok">✓ Verified</p><p class="text-sm mt-1"><?= $e($r['info']['name'] ?? 'The listing') ?> now shows ✓ Verified, and its owner has been told.
    <a class="underline text-[color:var(--tv-link)]" href="<?= $e($r['info']['url'] ?? '/') ?>">See the listing</a></p></div>
<?php elseif ($done === 'not_yet'): ?>
  <div class="tv-bleed vl-card"><p class="vl-ok" style="color:var(--tv-link,#92400E)">Sent</p><p class="text-sm mt-1">Your note went to the owner. They can send a new request when it's ready.</p></div>
<?php elseif (!$r): ?>
  <div class="tv-bleed vl-card"><p class="text-sm">This link isn't valid. Open the latest request email, or go to <a class="underline" href="/admin/claims.php">Admin → Claims</a>.</p></div>
<?php elseif (!$r['usable']): ?>
  <div class="tv-bleed vl-card"><p class="text-sm"><?= $r['status'] === 'verified' || ($r['claim']['status'] ?? '') === 'verified' ? 'This listing is already verified.' : 'This link has been used or has expired, or the listing was already decided.' ?>
    <a class="underline" href="/admin/claims.php">Admin → Claims</a> has every request.</p></div>
<?php else: $i = $r['info']; ?>
  <p class="text-sm mt-1"><?= $e($i['who']) ?> asks you to verify <b><?= $e($i['name']) ?></b>. <?= $i['added'] ? 'A new business, added by its owner.' : 'A claim on an existing listing.' ?></p>
  <?php if ($err !== ''): ?><p class="vl-bad mt-2"><?= $e($err) ?></p><?php endif; ?>
  <div class="tv-bleed vl-card"><h2>The listing</h2><dl>
    <?php foreach ($i['listing'] as $k => $v): ?><dt><?= $e($k) ?></dt><dd><?= $k === 'Business email' ? '<a href="mailto:' . $e($v) . '">' . $e($v) . '</a>' : (preg_match('#^https?://#', $v) ? '<a href="' . $e($v) . '" target="_blank" rel="noopener">' . ($k === 'Map' ? 'Open the map' : $e(mb_strimwidth($v, 0, 60, '…'))) . '</a>' : $e($v)) ?></dd><?php endforeach; ?>
    </dl><p class="text-sm mt-2"><a class="underline text-[color:var(--tv-link)]" href="<?= $e($i['url']) ?>" target="_blank" rel="noopener">Open the listing</a></p></div>
  <div class="tv-bleed vl-card"><h2>Who is asking</h2><dl>
    <?php foreach ($i['person'] as $k => $v): ?><dt><?= $e($k) ?></dt><dd><?= $k === 'Phone' ? '<a href="tel:' . $e(preg_replace('/\D/', '', $v)) . '">' . $e($v) . '</a>' : ($k === 'Email' ? '<a href="mailto:' . $e($v) . '">' . $e($v) . '</a>' : $e($v)) ?></dd><?php endforeach; ?>
  </dl></div>
  <?php if (!$notYet): ?>
  <form method="post" class="tv-bleed vl-card">
    <input type="hidden" name="t" value="<?= $e($token) ?>"><input type="hidden" name="do" value="verify">
    <button class="vl-b go" type="submit">Confirm: verify it</button>
    <p class="text-xs text-[color:var(--tv-meta)] mt-2">Not sure yet? <a class="underline" href="?t=<?= $e(rawurlencode($token)) ?>&amp;not=1">Not yet: send them a note</a></p>
  </form>
  <?php else: ?>
  <form method="post" class="tv-bleed vl-card">
    <input type="hidden" name="t" value="<?= $e($token) ?>"><input type="hidden" name="do" value="not_yet">
    <h2>Not yet</h2>
    <label class="text-sm" for="vl-note">What you need before you can verify it (sent to the owner)</label>
    <textarea class="vl-in mt-1" id="vl-note" name="note" maxlength="500" required placeholder="Please call me at…, or send a photo of the storefront."><?= $e((string) ($_POST['note'] ?? '')) ?></textarea>
    <div class="mt-2 flex gap-2 flex-wrap"><button class="vl-b" type="submit">Send the note</button><a class="vl-b" href="?t=<?= $e(rawurlencode($token)) ?>">Back</a></div>
  </form>
  <?php endif; ?>
<?php endif; ?>
</div>
<?php tv_page_end();
