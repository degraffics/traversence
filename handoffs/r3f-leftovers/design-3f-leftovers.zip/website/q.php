<?php
// q.php — a business's quote or invoice, for its customer (BizQuotes, decisions/0118): /q.php?t=<business>.<token>,
// from the email. No account needed: the link is the key. A sent quote shows its lines and terms, with Approve (the
// customer types their name) and Decline; once approved it's the invoice: what's paid, what's still due and by when,
// and how to pay (the business's own pay link, or its note: Zelle, checks…). The business is told by email either way.
// The quote lives in the business's own walled data: this page opens that business's realm and reads it there.
declare(strict_types=1);

require_once __DIR__ . '/../app/ui/security-headers.php';
require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/BusinessData.php';
require_once __DIR__ . '/../app/lib/BizQuotes.php';
require_once __DIR__ . '/../app/lib/BizFiles.php';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');

$raw = (string) ($_POST['t'] ?? $_GET['t'] ?? '');
$q = null; $biz = null; $owner = 0; $tok = '';
if (preg_match('/^(\d{1,10})\.([a-f0-9]{32})$/', $raw, $x)) {
    [, $owner, $tok] = $x; $owner = (int) $owner;
    $main = Database::connection();
    $st = $main->prepare('SELECT e.id, e.name, u.email AS owner_email FROM entities e LEFT JOIN users u ON u.id = e.owner_user_id WHERE e.id = ?'); $st->execute([$owner]);
    $biz = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    if ($biz) {
        try { $bpdo = BusinessData::open($owner); $q = BizQuotes::byToken($bpdo, $tok); }
        catch (Throwable $e) { error_log('q.php: ' . $e->getMessage()); }
    }
}
require_once __DIR__ . '/../app/ui/page-shell.php';
if (!$q || !$biz) { require_once __DIR__ . '/../app/ui/not-found.php'; tv_not_found(); }

// the form's key comes from the link itself (the link is the customer's key; no session needed, so it works for anyone who has it)
$csrf = substr(hash_hmac('sha256', 'q|' . $raw, (string) (getenv('APP_SECRET') ?: getenv('DB_PASSWORD') ?: 'tv')), 0, 32);
$msg = ''; $err = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    try {
        if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('This page had expired. Try again.');
        $do = (string) ($_POST['do'] ?? '');
        $tell = function (string $subject, string $body) use ($biz, $owner) {   // the business hears about it (its owner's email)
            if (empty($biz['owner_email'])) return;
            try { require_once __DIR__ . '/../app/lib/Mailer.php'; Mailer::send((string) $biz['owner_email'], $subject, $body . "\n\nOpen it: " . rtrim((string) (getenv('APP_URL') ?: ''), '/') . '/business/' . $owner . "/quotes\n\nTraversence\n"); }
            catch (Throwable $x) { error_log('q.php tell: ' . $x->getMessage()); }
        };
        if ($do === 'approve') {
            BizQuotes::approve($bpdo, $q, (string) ($_POST['name'] ?? ''));
            $tell('Approved: ' . BizQuotes::ref($q) . ' for ' . BizQuotes::money((int) $q['total']), ($q['cust_name'] ?: $q['cust_email']) . ' approved your quote' . ($q['title'] ? ' for ' . $q['title'] : '') . ', ' . BizQuotes::money((int) $q['total']) . ". It's an invoice now.");
            $msg = 'Thank you: it\'s approved. Here\'s your invoice.';
        } elseif ($do === 'proof_ok' || $do === 'proof_changes') {   // the customer answers a proof version (decisions/0120)
            $v = (int) ($_POST['version'] ?? 0);
            BizFiles::decide($bpdo, (int) $q['id'], $v, $do === 'proof_ok', (string) ($_POST['note'] ?? ''));
            $tell('Proof v' . $v . ($do === 'proof_ok' ? ' approved' : ': changes asked') . ' · ' . BizQuotes::ref($q), ($q['cust_name'] ?: $q['cust_email']) . ($do === 'proof_ok' ? ' approved proof v' . $v . '.' : ' asked for changes to proof v' . $v . ': ' . trim((string) ($_POST['note'] ?? ''))));
            $msg = $do === 'proof_ok' ? 'Thank you: the proof is approved.' : 'Thank you: ' . $biz['name'] . ' has your changes.';
        } elseif ($do === 'code') {   // the customer adds (or takes off) a discount code before approving (decisions/0121)
            if ($q['status'] !== 'sent') throw new InvalidArgumentException('A code goes on before the quote is approved.');
            $msg = BizQuotes::setCode($bpdo, (int) $q['id'], (string) ($_POST['code'] ?? ''), null);
        } elseif ($do === 'decline') {
            BizQuotes::decline($bpdo, $q, (string) ($_POST['why'] ?? ''));
            $tell('Declined: ' . BizQuotes::ref($q), ($q['cust_name'] ?: $q['cust_email']) . ' declined your quote' . ($q['title'] ? ' for ' . $q['title'] : '') . (trim((string) ($_POST['why'] ?? '')) !== '' ? ': ' . trim((string) $_POST['why']) : '.'));
            $msg = 'Declined. ' . $biz['name'] . ' has been told.';
        }
        $q = BizQuotes::byToken($bpdo, $tok);
    } catch (InvalidArgumentException $e) { $err = $e->getMessage(); }
}

$m = [BizQuotes::class, 'money'];
$isQuote = in_array($q['status'], ['sent', 'declined'], true);
$expired = $q['status'] === 'sent' && $q['expires_at'] && strtotime((string) $q['expires_at']) < time();
$date = fn ($d) => $d ? date('F j, Y', strtotime((string) $d)) : '';
$e = 'tv_e';
tv_page_start(($isQuote ? 'Quote ' : 'Invoice ') . BizQuotes::ref($q) . ' · ' . $biz['name'], ['no_crumbs' => true, 'head' => '<meta name="robots" content="noindex,nofollow">', 'description' => 'Your ' . ($isQuote ? 'quote' : 'invoice') . ' from ' . $biz['name'] . '.']);
?>
<style>
  .qv{max-width:46rem;color:var(--tv-ink,#3E2B1F)}
  .qv-card{background:var(--tv-card-a,#FFFBF2);border:1px solid var(--tv-line,#EADFC4);border-radius:.9rem;padding:1rem 1.1rem;margin-top:.7rem}
  .qv-hd{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.5rem 1rem;align-items:flex-start}
  .qv-k{font:700 .74rem system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;color:var(--tv-meta,#8A7355);margin:0}
  .qv h1{font:700 1.45rem var(--tv-font-head,Georgia,serif);margin:.15rem 0 0}
  .qv-pill{display:inline-block;border-radius:999px;padding:.15rem .7rem;font:700 .8rem system-ui,sans-serif;background:#F3E7CC;color:var(--tv-meta,#5C4632)}
  .qv-pill.ok{background:#DCEFE4;color:#1F5C43}.qv-pill.no{background:#F6DADA;color:#7F1D1D}
  .qv table{width:100%;border-collapse:collapse;font-size:.92rem;margin-top:.4rem}
  .qv td,.qv th{padding:.45rem .25rem;border-top:1px solid var(--tv-line,#EADFC4);text-align:left;vertical-align:top}
  .qv th{font:700 .72rem system-ui,sans-serif;letter-spacing:.05em;text-transform:uppercase;color:var(--tv-meta,#8A7355)}
  .qv .r{text-align:right;white-space:nowrap}
  .qv-sum td{border:0;padding:.15rem .25rem}.qv-sum .tot td{font-weight:800;font-size:1.05rem;border-top:2px solid var(--tv-line-strong,#CBB98D);padding-top:.4rem}
  .qv p{margin:.35rem 0;font-size:.95rem;line-height:1.5}
  .qv-b{display:inline-flex;align-items:center;justify-content:center;border-radius:.6rem;padding:.55rem 1rem;font:700 .95rem system-ui,sans-serif;border:1px solid var(--tv-line-strong,#CBB98D);background:#FFF8EA;color:var(--tv-ink,#3E2B1F);text-decoration:none;cursor:pointer}
  .qv-b.go{background:var(--tv-btn);border-color:var(--tv-btn);color:var(--tv-btn-text)}
  .qv-in{width:100%;border:1px solid var(--tv-line-strong,#CBB98D);border-radius:.6rem;padding:.55rem .7rem;background:var(--tv-card-a,#fff);font-size:1rem}
  .qv-row{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.6rem}
  .qv-msg{border-radius:.7rem;padding:.6rem .8rem;margin-top:.7rem;font-weight:600}.qv-msg.ok{background:#DCEFE4;color:#1F5C43}.qv-msg.no{background:#F6DADA;color:#7F1D1D}
  .qv small{color:var(--tv-meta,#8A7355)}
  @media print { header, footer, nav, .qv-act, #top-bar, #ta-rail, .tv-as { display:none!important } .qv-card{border:0;padding:0} }
</style>
<div class="qv">
  <?php if ($msg): ?><div class="qv-msg ok" role="status"><?= $e($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="qv-msg no" role="alert"><?= $e($err) ?></div><?php endif; ?>
  <div class="qv-card tv-bleed">
    <div class="qv-hd">
      <div><p class="qv-k"><?= $isQuote ? 'Quote' : 'Invoice' ?> <?= $e(BizQuotes::ref($q)) ?> · from <a class="underline" href="/listing/view.php?id=<?= (int) $owner ?>"><?= $e($biz['name']) ?></a></p>
        <h1><?= $e($q['title'] !== '' ? $q['title'] : ($isQuote ? 'Your quote' : 'Your invoice')) ?></h1>
        <p><small>For <?= $e(trim($q['cust_name'] . ' · ' . $q['cust_email'], ' ·')) ?></small></p></div>
      <span class="qv-pill<?= $q['status'] === 'paid' ? ' ok' : (in_array($q['status'], ['declined', 'void'], true) || $expired ? ' no' : '') ?>"><?= $e($expired ? 'Expired' : ['sent' => 'Waiting for your approval', 'approved' => 'Approved · not paid yet', 'paid' => 'Paid', 'declined' => 'Declined', 'void' => 'Cancelled'][$q['status']] ?? '') ?></span>
    </div>
    <table>
      <tr><th>What</th><th class="r">How many</th><th class="r">Each</th><th class="r">Amount</th></tr>
      <?php foreach ($q['lines'] as $l): ?>
      <tr><td><?= $e($l['title']) ?><?= (int) $l['taxable'] ? '' : ' <small>(no tax)</small>' ?></td><td class="r"><?= number_format((int) $l['qty']) ?></td><td class="r"><?= $m((int) $l['unit_cents']) ?></td><td class="r"><?= $m((int) $l['qty'] * (int) $l['unit_cents']) ?></td></tr>
      <?php endforeach; ?>
    </table>
    <table class="qv-sum">
      <tr><td>Subtotal</td><td class="r"><?= $m($q['sub']) ?></td></tr>
      <?php if ($q['off']): ?><tr><td>Discount (<?= $e($q['code']) ?>)</td><td class="r">−<?= $m($q['off']) ?></td></tr><?php endif; ?>
      <?php if ($q['tax']): ?><tr><td>Sales tax (<?= $e(rtrim(rtrim(number_format((int) $q['tax_milli'] / 1000, 3, '.', ''), '0'), '.')) ?>%)</td><td class="r"><?= $m($q['tax']) ?></td></tr><?php endif; ?>
      <tr class="tot"><td>Total</td><td class="r"><?= $m($q['total']) ?></td></tr>
      <?php if ($q['paid']): ?><tr><td>Paid</td><td class="r"><?= $m($q['paid']) ?></td></tr><tr><td><b>Still due</b></td><td class="r"><b><?= $m($q['balance']) ?></b></td></tr><?php endif; ?>
    </table>
    <p><small><?= $e(BizQuotes::TERMS[$q['terms']][0]) ?><?= $q['deposit'] && $isQuote ? ' · ' . (int) $q['deposit_pct'] . '% deposit (' . $m($q['deposit']) . ') on approval' : '' ?><?= $q['due_at'] && $q['status'] === 'approved' ? ' · due by ' . $e($date($q['due_at'])) : '' ?><?= $isQuote && $q['expires_at'] && !$expired ? ' · this quote is good until ' . $e($date($q['expires_at'])) : '' ?></small></p>
    <?php if (trim((string) $q['notes']) !== ''): ?><p><?= nl2br($e((string) $q['notes'])) ?></p><?php endif; ?>
    <?php if ($q['approved_name']): ?><p><small>Approved by <?= $e($q['approved_name']) ?> on <?= $e($date($q['approved_at'])) ?>.</small></p><?php endif; ?>
    <?php if ($q['stage'] && in_array($q['status'], ['approved', 'paid'], true)): ?><p><small>Your order: <b><?= $e(BizQuotes::STAGES[$q['stage']] ?? $q['stage']) ?></b><?= $q['tracking'] ? ' · ' . $e($q['tracking']) : '' ?></small></p><?php endif; ?>
  </div>

  <?php
  // proofs (the current version) and the files shared with the customer
  $fl = BizFiles::forQuote($bpdo, (int) $q['id']);
  $cur = array_values(array_filter($fl, fn ($f) => $f['kind'] === 'proof' && $f['status'] !== 'replaced'));   // newest version first
  $cur = $cur ? array_values(array_filter($cur, fn ($f) => (int) $f['version'] === (int) $cur[0]['version'])) : [];
  $shared = array_values(array_filter($fl, fn ($f) => $f['kind'] === 'file' && (int) $f['shared']));
  $furl = fn ($f) => '/q-file.php?t=' . rawurlencode($raw) . '&f=' . (int) $f['id'];
  if ($cur || $shared): ?>
  <div class="qv-card tv-bleed">
    <?php if ($cur): $pv = (int) $cur[0]['version']; $pst = (string) $cur[0]['status']; ?>
    <p><b>Proof, version <?= $pv ?></b> <span class="qv-pill<?= $pst === 'approved' ? ' ok' : ($pst === 'changes' ? ' no' : '') ?>"><?= $e(['waiting' => 'Waiting for your answer', 'approved' => 'You approved it', 'changes' => 'You asked for changes'][$pst] ?? '') ?></span></p>
    <?php foreach ($cur as $f): ?><p><a class="underline" href="<?= $e($furl($f)) ?>" target="_blank" rel="noopener"><?= $e($f['file_name']) ?></a> <small>(<?= $e(BizFiles::size((int) $f['bytes'])) ?>)</small><?= $f['note'] !== '' ? '<br><small>' . $e($f['note']) . '</small>' : '' ?></p><?php endforeach; ?>
    <?php foreach ($cur as $f) if (str_starts_with((string) $f['mime'], 'video/')): ?><p><video src="<?= $e($furl($f)) ?>" controls preload="metadata" playsinline style="width:100%;border-radius:.5rem;background:#000"></video></p><?php endif; ?>
    <?php if (str_starts_with((string) $cur[0]['mime'], 'image/')): ?><p><img src="<?= $e($furl($cur[0])) ?>" alt="Proof" style="max-width:100%;border:1px solid var(--tv-line,#EADFC4);border-radius:.5rem"></p><?php endif; ?>
    <?php if ($pst === 'changes' && $cur[0]['decided_note'] !== ''): ?><p><small>You asked: “<?= $e($cur[0]['decided_note']) ?>”</small></p><?php endif; ?>
    <?php if ($pst === 'waiting' && !in_array($q['status'], ['void', 'declined'], true)): ?>
    <div class="qv-row qv-act">
      <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($raw) ?>"><input type="hidden" name="do" value="proof_ok"><input type="hidden" name="version" value="<?= $pv ?>"><button class="qv-b go" data-confirm="Approve this proof as it is?" data-yes="Approve it">Approve the proof</button></form>
    </div>
    <form method="post" class="qv-act" style="margin-top:.6rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($raw) ?>"><input type="hidden" name="do" value="proof_changes"><input type="hidden" name="version" value="<?= $pv ?>">
      <details><summary class="underline" style="cursor:pointer;font-size:.9rem">Ask for changes</summary><label><small>What should change?</small><textarea class="qv-in" name="note" rows="3" required minlength="3"></textarea></label><div class="qv-row"><button class="qv-b">Send my changes</button></div></details></form>
    <?php endif; endif; ?>
    <?php if ($shared): ?><p style="margin-top:.6rem"><b>Files</b></p><?php foreach ($shared as $f): ?><p><a class="underline" href="<?= $e($furl($f)) ?>" target="_blank" rel="noopener"><?= $e($f['file_name']) ?></a> <small>(<?= $e(BizFiles::size((int) $f['bytes'])) ?>)</small></p><?php endforeach; endif; ?>
  </div>
  <?php endif; ?>

  <?php if ($q['status'] === 'sent' && !$expired): ?>
  <div class="qv-card tv-bleed qv-act">
    <form method="post"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($raw) ?>"><input type="hidden" name="do" value="approve">
      <p><b>Approve this quote</b><?= $q['deposit'] ? ': a ' . (int) $q['deposit_pct'] . '% deposit (' . $m($q['deposit']) . ') is due when you approve' : '' ?>.</p>
      <label><small>Type your name to approve it</small><input class="qv-in" name="name" required minlength="2" autocomplete="name" value="<?= $e($q['cust_name']) ?>"></label>
      <div class="qv-row"><button class="qv-b go">Approve</button></div></form>
    <form method="post" style="margin-top:.8rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($raw) ?>"><input type="hidden" name="do" value="code">
      <details<?= $q['code'] ? ' open' : '' ?>><summary class="underline" style="cursor:pointer;font-size:.9rem"><?= $q['code'] ? 'Discount code: ' . $e($q['code']) : 'Have a discount code?' ?></summary>
        <div class="qv-row"><input class="qv-in" name="code" value="<?= $e($q['code']) ?>" maxlength="40" autocomplete="off" aria-label="Discount code" style="flex:1;min-width:9rem;text-transform:uppercase"><button class="qv-b"><?= $q['code'] ? 'Change' : 'Apply' ?></button></div>
        <?php if ($q['code']): ?><p><small>Clear the box and tap Change to take it off.</small></p><?php endif; ?></details></form>
    <form method="post" style="margin-top:.8rem"><input type="hidden" name="csrf" value="<?= $e($csrf) ?>"><input type="hidden" name="t" value="<?= $e($raw) ?>"><input type="hidden" name="do" value="decline">
      <details><summary class="underline" style="cursor:pointer;font-size:.9rem">Decline it</summary>
        <label><small>Anything to tell <?= $e($biz['name']) ?>? (optional)</small><input class="qv-in" name="why" maxlength="300"></label>
        <div class="qv-row"><button class="qv-b" data-confirm="Decline this quote? <?= $e($biz['name']) ?> is told." data-yes="Decline it" data-danger>Decline</button></div></details></form>
  </div>
  <?php elseif ($expired): ?>
  <div class="qv-card tv-bleed"><p>This quote has expired. Ask <?= $e($biz['name']) ?> for a new one.</p></div>
  <?php endif; ?>

  <?php if ($q['status'] === 'approved' && $q['balance'] > 0): ?>
  <div class="qv-card tv-bleed qv-act">
    <p><b>How to pay <?= $m($q['paid'] ? $q['balance'] : ($q['deposit'] ?: $q['balance'])) ?><?= !$q['paid'] && $q['deposit'] ? ' (your deposit)' : '' ?></b></p>
    <?php if ($q['pay_link']): ?><div class="qv-row"><a class="qv-b go" href="<?= $e($q['pay_link']) ?>" target="_blank" rel="noopener noreferrer">Pay now</a></div><p><small>Opens the business's own payment page.</small></p><?php endif; ?>
    <?php if (trim((string) $q['pay_note']) !== ''): ?><p><?= nl2br($e((string) $q['pay_note'])) ?></p><?php endif; ?>
    <?php if (!$q['pay_link'] && trim((string) $q['pay_note']) === ''): ?><p><?= $e($biz['name']) ?> will tell you how to pay.</p><?php endif; ?>
    <p><small>Payments are made to <?= $e($biz['name']) ?>, not to Traversence. They record them here when they arrive.</small></p>
  </div>
  <?php endif; ?>
  <div class="qv-row qv-act" style="margin:.8rem 0"><button type="button" class="qv-b" onclick="window.print()">Print or save as PDF</button></div>
  <p><small>Sent through Traversence on behalf of <?= $e($biz['name']) ?>. Questions about this <?= $isQuote ? 'quote' : 'invoice' ?> go to them.</small></p>
</div>
<?php tv_page_end();
