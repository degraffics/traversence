// js/vendor-bill.js — the order page's Vendor line (M1b: research/order-management-design-2026-11-23.md §3.6.3). The
// vendor's invoice is dropped (or chosen), kept as the order's file through the one uploader (js/tv-upload.js, target
// order_vendor_bill, decisions/0127), and its text read here in the browser with pdf.js: no AI, nothing sent anywhere
// (it's private; decisions/0164). Invoice number, date, PO, amount, tax, shipping, total, due and ship-via are pulled out,
// matched to the work order by PO (our work order number), else by vendor and amount, and shown beside what we expected:
// matches ticked, each mismatch asked once with its two answers. Then "Record the vendor bill" posts it (vbill_record),
// which also makes it a bill in QuickBooks (decisions/0178 note (c)). A scan with no text says so and asks the four key
// fields. The line's inline forms close with their Cancel (and Esc).
(function () {
  'use strict';
  var PDFJS = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/';
  var cfgEl = document.getElementById('vb-data');
  var zone = document.querySelector('[data-vb-drop]');
  // the line's inline forms (✎, Not billed, Dispute…, by hand): Cancel and Esc close them
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-vb-shut]'); if (!b) return; var f = b.closest('[data-cs-edf]'); if (f) f.hidden = true; });
  document.addEventListener('keydown', function (e) { if (e.key !== 'Escape') return; document.querySelectorAll('.cs-lines [data-cs-edf]:not([hidden])').forEach(function (f) { if (f.querySelector('.vb-f')) f.hidden = true; }); });
  if (!cfgEl || !zone) return;
  var cfg = JSON.parse(cfgEl.textContent || '{}');
  var input = zone.querySelector('[data-vb-file]'), out = document.querySelector('[data-vb-read]');

  function el(t, c, x) { var n = document.createElement(t); if (c) n.className = c; if (x != null) n.textContent = x; return n; }
  function usd(c) { return (c < 0 ? '−' : '') + '$' + (Math.abs(c) / 100).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function norm(s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
  function cents(s) { var v = String(s || '').replace(/[^0-9.]/g, ''); return v === '' ? null : Math.round(parseFloat(v) * 100); }
  var MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
  function iso(s) {   // 11/17/2026, 11-17-26, 2026-11-17, Nov 17, 2026, November 17 2026 → 2026-11-17
    if (!s) return ''; var m, y, mo, d; s = String(s).trim();
    if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) { y = +m[1]; mo = +m[2]; d = +m[3]; }
    else if ((m = s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})$/))) { mo = +m[1]; d = +m[2]; y = +m[3]; if (y < 100) y += 2000; }
    else if ((m = s.match(/^([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})$/))) { var k = m[1].toLowerCase(); mo = MON[k.slice(0, 4)] || MON[k.slice(0, 3)] || 0; d = +m[2]; y = +m[3]; }
    else return '';
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return '';
    return y + '-' + (mo < 10 ? '0' : '') + mo + '-' + (d < 10 ? '0' : '') + d;
  }
  function nice(isoD) { if (!isoD) return ''; var p = isoD.split('-'); return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][+p[1] - 1] + ' ' + (+p[2]) + ', ' + p[0]; }

  // ---- reading: the PDF's text, by lines, then the fields by their labels ----
  var lib = null;
  function loadPdf() {
    if (lib) return lib;
    lib = new Promise(function (ok, no) {
      if (window.pdfjsLib) return ok(window.pdfjsLib);
      var s = document.createElement('script'); s.src = PDFJS + 'pdf.min.js';
      s.onload = function () { window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS + 'pdf.worker.min.js'; ok(window.pdfjsLib); };
      s.onerror = function () { lib = null; no(new Error('pdf.js didn\'t load')); };
      document.head.appendChild(s);
    });
    return lib;
  }
  function textOf(file) {
    if (!/pdf$/i.test(file.type) && !/\.pdf$/i.test(file.name || '')) return Promise.resolve('');   // a photo: no text to read
    return file.arrayBuffer().then(function (buf) {
      return loadPdf().then(function (L) { return L.getDocument({ data: new Uint8Array(buf), isEvalSupported: false }).promise; });
    }).then(function (doc) {
      var pages = []; for (var i = 1; i <= Math.min(doc.numPages, 4); i++) pages.push(doc.getPage(i).then(function (pg) { return pg.getTextContent(); }));
      return Promise.all(pages).then(function (cs) {
        var lines = [];
        cs.forEach(function (c) {
          var rows = {};
          c.items.forEach(function (it) { if (!it.str || !it.str.trim()) return; var y = Math.round(it.transform[5] / 3) * 3; (rows[y] = rows[y] || []).push({ x: it.transform[4], s: it.str }); });
          Object.keys(rows).map(Number).sort(function (a, b) { return b - a; }).forEach(function (y) { lines.push(rows[y].sort(function (a, b) { return a.x - b.x; }).map(function (r) { return r.s; }).join(' ').replace(/\s+/g, ' ').trim()); });
        });
        return lines.join('\n');
      });
    });
  }
  var DATE = '(\\d{4}-\\d{1,2}-\\d{1,2}|\\d{1,2}[\\/.-]\\d{1,2}[\\/.-]\\d{2,4}|[A-Za-z]{3,9}\\.?\\s+\\d{1,2},?\\s+\\d{4})';
  var MONEY = '\\$?\\s*([\\d,]+\\.\\d{2})';
  function grab(t, re) { var m = t.match(re); return m ? m[m.length - 1].trim() : ''; }
  function parse(t) {
    var f = {};
    f.bill_no = grab(t, /invoice\s*(?:#|no\.?|number|num\.?)\s*[:.]?\s*([A-Z0-9][A-Z0-9-]{2,})/i) || grab(t, /\binvoice\s*[:]\s*([A-Z0-9][A-Z0-9-]{2,})/i);
    f.po = grab(t, /(?:customer\s+)?(?:p\.?\s?o\.?|purchase\s+order)\s*(?:#|no\.?|number)?\s*[:.]?\s*([A-Z0-9][A-Z0-9-]{3,})/i);
    f.due = iso(grab(t, new RegExp('(?:due\\s*date|payment\\s+due|due\\s+by|due)\\s*[:.]?\\s*' + DATE, 'i')));
    var dm, dre = new RegExp('(\\w+\\s+)?date\\s*[:.]?\\s*' + DATE, 'ig');
    while ((dm = dre.exec(t))) { if (!/^(due|ship|order)\s/i.test(dm[1] || '')) { f.date = iso(dm[2]); if (f.date) break; } }
    if (!f.date) f.date = '';
    f.total = cents(grab(t, new RegExp('(?:total\\s+due|amount\\s+due|balance\\s+due|invoice\\s+total|grand\\s+total)\\s*[:.]?\\s*' + MONEY, 'i')) || grab(t, new RegExp('(?:^|\\n)\\s*total\\b[^\\n\\d$]{0,12}' + MONEY, 'i')));
    f.amount = cents(grab(t, new RegExp('(?:sub\\s*-?\\s*total|merchandise|amount)\\b[^\\n\\d$]{0,12}' + MONEY, 'i')));
    f.tax = cents(grab(t, new RegExp('(?:sales\\s+tax|\\btax)\\b[^\\n\\d$]{0,12}' + MONEY, 'i')));
    f.ship = cents(grab(t, new RegExp('(?:shipping|freight|delivery\\s+charge|postage)\\b[^\\n\\d$]{0,12}' + MONEY, 'i')));
    f.ship_via = grab(t, /ship(?:ped)?\s*via\s*[:.]?\s*([^\n]{2,40}?)(?:\s{2,}|\n|$)/i);
    if (f.total == null && f.amount != null) f.total = f.amount + (f.tax || 0) + (f.ship || 0);
    if (f.amount == null && f.total != null) f.amount = f.total - (f.tax || 0) - (f.ship || 0);
    return f;
  }

  // ---- the check: what they say beside what we expected; each mismatch one question ----
  var CARRIER = /\b(usps|ups|fed\s?ex|dhl|freight|ground|priority|overnight|express|shipped|ltl)\b/i, PICKUP = /\b(will\s*call|pick\s*-?\s*up|pickup|customer\s+pick)/i;
  function check(f, text, fileId, forceId) {
    var wos = cfg.wos || [], w = null, rows = [], qs = [], why = '';
    var byPo = f.po ? wos.filter(function (x) { return norm(x.wo) === norm(f.po) || (x.po && norm(x.po) === norm(f.po)); })[0] : null;
    if (byPo) { w = byPo; rows.push(['PO', f.po, 'ok', 'our work order']); }
    else {
      var byAmt = wos.filter(function (x) { return (f.amount != null && x.cost === f.amount) || (f.total != null && x.cost === f.total); });
      var byVen = wos.filter(function (x) { return x.vendor && text.toLowerCase().indexOf(String(x.vendor).toLowerCase()) >= 0; });
      w = (forceId ? wos.filter(function (x) { return x.id === forceId; })[0] : null) || (byAmt.length === 1 ? byAmt[0] : null) || (byVen.length === 1 ? byVen[0] : null) || (wos.length === 1 ? wos[0] : null) || wos[0] || null;
      if (f.po) qs.push({ k: 'po', q: 'Their PO ' + f.po + ' isn\'t this order\'s work order' + (w ? ' (' + w.wo + ')' : '') + '. Is it this order\'s bill?', a: ['Yes, it\'s this order\'s', 'No: another order\'s'] });
      rows.push(['PO', f.po || 'none on their invoice', f.po ? 'ne' : '', w ? (byAmt.length === 1 || byVen.length === 1 ? 'matched by ' + (byAmt.length === 1 ? 'amount' : 'vendor') + ': ' + w.wo : 'work order ' + w.wo) : '']);
    }
    if (!w) return { none: true };
    var pick = !byPo && wos.length > 1;   // more than one work order and no PO to tell: which one, asked with a choice
    if (f.amount != null) {
      var amtOk = f.amount === w.cost || f.total === w.cost;
      rows.push(['Amount', usd(f.amount), amtOk ? 'ok' : 'ne', amtOk ? 'the agreed cost' : 'agreed ' + usd(w.cost)]);
      if (!amtOk) qs.push({ k: 'amount', q: 'Their bill says ' + usd(f.amount) + '; the work order agreed ' + usd(w.cost) + '. Which is right?', a: ['Their ' + usd(f.amount), 'The agreed ' + usd(w.cost) + ': dispute it'], dispute: 1, why: 'billed ' + usd(f.amount) + '; the work order agreed ' + usd(w.cost) });
      var extra = (f.tax || 0) + (f.ship || 0);
      rows.push(['Tax · shipping', usd(f.tax || 0) + ' · ' + usd(f.ship || 0), extra === 0 || f.total === w.cost ? 'ok' : 'ne', extra === 0 || f.total === w.cost ? '' : 'added to the agreed cost']);
      if (extra > 0 && f.total !== w.cost && amtOk) qs.push({ k: 'extra', q: 'Their bill adds ' + usd(extra) + ' tax and shipping to the agreed ' + usd(w.cost) + '. Is it owed?', a: ['Yes, it\'s owed', 'No: dispute it'], dispute: 1, why: usd(extra) + ' tax and shipping added to the agreed ' + usd(w.cost) });
    }
    if (f.ship_via) {
      var says = CARRIER.test(f.ship_via) ? 'ship' : (PICKUP.test(f.ship_via) ? 'pickup' : ''), ours = w.pickup ? 'pickup' : 'ship';
      var shipOk = !says || says === ours;
      rows.push(['Ship via', f.ship_via, shipOk ? 'ok' : 'ne', shipOk ? '' : w.deliveryName || (w.pickup ? 'pickup' : 'shipped')]);
      if (!shipOk) qs.push({ k: 'ship', q: 'The vendor says ' + (says === 'ship' ? 'it shipped by ' + f.ship_via : 'it was picked up') + '; the work order says ' + (w.deliveryName || (ours === 'pickup' ? 'pickup' : 'it ships')) + '. Which is right?', a: ['It was picked up', 'It shipped: add tracking'], track: 1 });
    }
    return { w: w, rows: rows, qs: qs, f: f, fileId: fileId, pick: pick, text: text };
  }

  function hidden(form, n, v) { var i = form.querySelector('input[name="' + n + '"]') || el('input'); i.type = 'hidden'; i.name = n; i.value = v == null ? '' : v; form.appendChild(i); }
  function show(r, scan) {
    out.textContent = ''; out.hidden = false;
    var head = el('span', 'vb-q'), x = el('button', 'cs-ib', '×'); x.type = 'button'; x.title = 'Close the read invoice'; x.setAttribute('aria-label', 'Close the read invoice'); x.style.float = 'right';
    x.addEventListener('click', function () { out.hidden = true; out.textContent = ''; zone.hidden = false; });
    out.appendChild(x);
    var form = el('form', 'vb-f'); form.method = 'post';
    [['csrf', cfg.csrf], ['id', cfg.order], ['do', 'vbill_record'], ['file', r.fileId || ''], ['answers', '[]']].forEach(function (p) { hidden(form, p[0], p[1]); });
    if (scan) {
      head.textContent = 'This file has no text to read (a scan or a photo). It\'s kept with the order\'s files; type its four key fields:';
      out.appendChild(head);
      var g = el('span', 'vb-grid');
      [['Their invoice #', 'bill_no', 'text'], ['Its date', 'bill_date', 'date'], ['Total', 'total', 'text'], ['Due', 'due_date', 'date']].forEach(function (d) { var l = el('label', '', d[0]), i = el('input', 'hb-in'); i.name = d[1]; i.type = d[2]; if (d[1] === 'total') i.inputMode = 'decimal'; l.appendChild(i); g.appendChild(l); });
      form.appendChild(g);
      if ((cfg.wos || []).length === 1) hidden(form, 'wo', cfg.wos[0].id);
      else { var sl = el('label', '', 'Work order'), sel = el('select', 'hb-in'); sel.name = 'wo'; (cfg.wos || []).forEach(function (w) { var o = el('option', '', w.wo + ' · ' + w.vendor + ' · ' + usd(w.cost)); o.value = w.id; sel.appendChild(o); }); sl.appendChild(sel); form.insertBefore(sl, g); }
      var bs = el('span', 'vb-btns'), go = el('button', 'hb-b go', 'Record the vendor bill'); bs.appendChild(go); form.appendChild(bs);
      out.appendChild(form); return;
    }
    if (r.none) { head.textContent = 'Read, but it doesn\'t match a work order on this order. It\'s kept with the order\'s files; record it by hand if it is this order\'s.'; out.appendChild(head); return; }
    var f = r.f, w = r.w, answers = {};
    head.innerHTML = '';
    var lead = el('b', '', 'Their invoice ' + (f.bill_no || '(no number found)') + (f.date ? ', ' + nice(f.date).replace(/, \d{4}$/, '') : '')); head.appendChild(lead);
    head.appendChild(document.createTextNode(r.qs.length ? ', read: ' : ', read: everything matches work order ' + w.wo + '.'));
    if (r.qs.length) head.appendChild(el('b', '', r.qs[0].q));
    out.appendChild(head);
    if (r.pick) {   // which work order: the check runs again against the one chosen
      var pl = el('label', 'vb-pickwo', 'Which work order is it for? '), ps = el('select', 'hb-in');
      (cfg.wos || []).forEach(function (x) { var o = el('option', '', x.wo + ' · ' + x.vendor + ' · ' + usd(x.cost)); o.value = x.id; if (x.id === w.id) o.selected = true; ps.appendChild(o); });
      ps.addEventListener('change', function () { show(check(f, r.text, r.fileId, +ps.value), false); });
      pl.appendChild(ps); out.appendChild(pl);
    }
    var tb = el('table', 'vb-tbl');
    r.rows.forEach(function (row) { var tr = el('tr'); tr.appendChild(el('td', '', row[0])); tr.appendChild(el('td', '', row[1])); var m = el('td', row[2]); m.textContent = (row[2] === 'ok' ? '✓ ' : row[2] === 'ne' ? '≠ ' : '') + (row[3] || ''); tr.appendChild(m); tb.appendChild(tr); });
    if (f.due) { var tr2 = el('tr'); tr2.appendChild(el('td', '', 'Due')); tr2.appendChild(el('td', '', nice(f.due))); tr2.appendChild(el('td')); tb.appendChild(tr2); }
    out.appendChild(tb);
    var go = el('button', 'hb-b go', 'Record the vendor bill');
    var track = null;
    function ready() {
      var open = r.qs.filter(function (q) { return answers[q.k] == null; });
      go.disabled = open.length > 0 || !f.bill_no; go.title = !f.bill_no ? 'Their invoice number wasn\'t found: record it by hand' : open.length ? 'Answer the question above first' : '';
      var list = r.qs.filter(function (q) { return answers[q.k] != null; }).map(function (q) { return { q: q.q, a: q.a[answers[q.k]] }; });
      form.querySelector('input[name=answers]').value = JSON.stringify(list);
      var disp = r.qs.filter(function (q) { return q.dispute && answers[q.k] === 1; });
      hidden(form, 'dispute', disp.length ? 1 : ''); hidden(form, 'why', disp.map(function (q) { return q.why; }).join('; '));
      if (r.qs.some(function (q) { return q.k === 'po' && answers.po === 1; })) { go.disabled = true; go.title = 'It\'s another order\'s bill: its file stays in this order\'s files, to take off there'; }
    }
    r.qs.forEach(function (q, qi) {
      if (qi > 0) out.appendChild(el('span', 'vb-q', q.q));
      var box = el('span', 'vb-ans');
      q.a.forEach(function (lab, i) {
        var b = el('button', 'hb-b', lab); b.type = 'button'; b.setAttribute('aria-pressed', 'false');
        b.addEventListener('click', function () {
          answers[q.k] = i; box.querySelectorAll('button').forEach(function (o) { o.setAttribute('aria-pressed', o === b ? 'true' : 'false'); });
          if (q.track) { if (i === 1 && !track) { track = el('label', '', 'Tracking (kept on the bill and the work order)'); var ti = el('input', 'hb-in'); ti.name = 'tracking'; ti.maxLength = 160; track.appendChild(ti); form.insertBefore(track, form.querySelector('.vb-btns')); } else if (i === 0 && track) { track.remove(); track = null; } }
          ready();
        });
        box.appendChild(b);
      });
      out.appendChild(box);
    });
    [['wo', w.id], ['bill_no', f.bill_no], ['bill_date', f.date], ['due_date', f.due], ['po', f.po], ['amount', f.amount != null ? (f.amount / 100).toFixed(2) : ''], ['tax', ((f.tax || 0) / 100).toFixed(2)], ['ship', ((f.ship || 0) / 100).toFixed(2)], ['total', f.total != null ? (f.total / 100).toFixed(2) : ''], ['ship_via', f.ship_via]].forEach(function (p) { hidden(form, p[0], p[1]); });
    var bs = el('span', 'vb-btns'); bs.appendChild(go); form.appendChild(bs);
    form.appendChild(el('small', '', 'Also made in QuickBooks as a bill against ' + w.vendor + '. Read wrong? Close it (×) and record the bill by hand.'));
    out.appendChild(form);
    ready();
    if (window.TvAsk && go.disabled && r.qs.length) out.querySelector('.vb-ans button').focus();
  }

  function take(file) {
    if (!file) return;
    if (!window.TvUpload) { if (window.TvAsk) TvAsk.say('The uploader didn\'t load: refresh the page and drop it again.', { anchor: zone, bad: true }); return; }
    zone.classList.remove('on');
    var reading = textOf(file).catch(function () { return ''; });
    TvUpload.send([file], { target: 'order_vendor_bill', ctx: { order: cfg.order }, el: zone, csrf: cfg.csrf }).then(function (res) {
      var fid = res && res[0] && res[0].file;
      return reading.then(function (t) {
        zone.hidden = true;
        if (!t || t.replace(/\s/g, '').length < 20) return show({ fileId: fid }, true);
        show(check(parse(t), t, fid), false);
      });
    }, function () { input.value = ''; });
  }
  zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('on'); });
  zone.addEventListener('dragleave', function () { zone.classList.remove('on'); });
  zone.addEventListener('drop', function (e) { e.preventDefault(); take(e.dataTransfer.files && e.dataTransfer.files[0]); });
  var pick = document.getElementById('vb-pick'); if (pick) pick.addEventListener('click', function () { input.click(); });
  input.addEventListener('change', function () { take(input.files && input.files[0]); });
  window.TvVendorBill = { parse: parse, check: function (f, t) { return check(f, t || '', 0); }, iso: iso };   // for the tests
})();
