<?php
// app/scripts/qb_orders_tick.php — "QuickBooks invoices on orders" (M1b: research/order-management-design-2026-11-23.md
// §3.6.1): each open order that names a QuickBooks invoice is read again, and a payment QuickBooks shows that the order
// hasn't recorded is applied (ClientOrders::readQuickBooks; decisions/0178's note, the session manager's decision (a)).
// The order page also reads it when it opens. Nothing is written to QuickBooks.
// Sets itself up in cPanel through the API (Scheduler::AUTO): every hour.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../lib/Database.php';
require_once __DIR__ . '/../lib/Scheduler.php';
Scheduler::run('qb_orders_tick');   // its runs show in System Configuration → Scheduled tasks
require_once __DIR__ . '/../lib/Orders.php';
require_once __DIR__ . '/../lib/ClientOrders.php';
$pdo = Database::connection();
echo 'Orders with a QuickBooks payment recorded: ' . ClientOrders::qbOrdersTick($pdo) . "\n";
