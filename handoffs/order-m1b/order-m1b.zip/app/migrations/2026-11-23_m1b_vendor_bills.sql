-- M1b (research/order-management-design-2026-11-23.md §3.6; decisions/0178 notes of 2026-11-23): what the order knows,
-- what it asks. Add-only, safe to run twice.
--
-- 1. An order's QuickBooks invoice made by hand, linked by its number: its QuickBooks Id and customer, kept apart from
--    invoice_id (an invoice made here, which the order's total follows), so reading and posting to it never rewrites the
--    order's lines, tax or total. qb_read_at: when QuickBooks was last read for it (the page reads again after 5 minutes).
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE orders ADD COLUMN qb_link_id VARCHAR(20) DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'qb_link_id');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE orders ADD COLUMN qb_link_customer VARCHAR(20) DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'qb_link_customer');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE orders ADD COLUMN qb_read_at DATETIME DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'qb_read_at');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;

-- 2. The vendor's bills on an order (decisions/0178 note (c)): typed, or read from their dropped invoice (no AI). status:
--    recorded, cancelled (the record cancelled before it reached QuickBooks), none ("Not billed by them", with why),
--    disputed. qb_bill_id: the Bill made in QuickBooks against the vendor; qb_error: why it isn't there yet.
CREATE TABLE IF NOT EXISTS order_vendor_bills (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  wo_id INT DEFAULT NULL,
  vendor VARCHAR(120) NOT NULL DEFAULT '',
  vendor_id INT DEFAULT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'recorded',
  bill_no VARCHAR(40) NOT NULL DEFAULT '',
  bill_date DATE DEFAULT NULL,
  due_date DATE DEFAULT NULL,
  po VARCHAR(60) NOT NULL DEFAULT '',
  amount_cents INT NOT NULL DEFAULT 0,
  tax_cents INT NOT NULL DEFAULT 0,
  ship_cents INT NOT NULL DEFAULT 0,
  total_cents INT NOT NULL DEFAULT 0,
  ship_via VARCHAR(80) NOT NULL DEFAULT '',
  answers TEXT,
  why VARCHAR(300) NOT NULL DEFAULT '',
  file_id INT DEFAULT NULL,
  source VARCHAR(8) NOT NULL DEFAULT 'typed',
  qb_bill_id VARCHAR(20) DEFAULT NULL,
  qb_env VARCHAR(12) NOT NULL DEFAULT '',
  qb_account VARCHAR(120) NOT NULL DEFAULT '',
  qb_error VARCHAR(300) NOT NULL DEFAULT '',
  created_by INT DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT NULL,
  KEY order_id (order_id),
  KEY wo_id (wo_id)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. The History of QuickBooks settings chosen in the admin (the first: "Vendor bills post to", the session manager for
--    Jason, 2026-11-24: a setting in System Configuration → Settings, never in .env; History keeps its changes).
CREATE TABLE IF NOT EXISTS qb_settings_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL,
  old_value VARCHAR(300) NOT NULL DEFAULT '',
  new_value VARCHAR(300) NOT NULL DEFAULT '',
  note VARCHAR(300) NOT NULL DEFAULT '',
  changed_by INT DEFAULT NULL,
  changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY name (name)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
