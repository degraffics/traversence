<?php
// api/crawl/geocode.php — map points on a schedule (decisions/0053 follow-up, 2026-10-04): the off-site worker asks the
// site to place one batch of street addresses each run, so nobody has to press Find points (Admin → Crawler → Map
// points does the same by hand). The site sends the batch to the U.S. Census geocoder itself (api/lib/Geocoder.php):
// only points that are missing or just the ZIP's middle are replaced; confidential listings are never geocoded.
//   GET  -> {left}                       how many are waiting
//   POST -> {sent, found, not_found, skipped, private, mailonly, milepost, nonumber, left}   one batch (up to 500)
//        or {waits: true, why, left} when the Census didn't answer (the batch waits; the worker reports held)
//        or {waits: true, why, left, backup: {url, benchmark, ids, csv (base64)}} when the site couldn't reach it on its
//           connection (decisions/0175's note, the Census geocoder's backup): the worker sends the batch itself
//   POST {ids, answers_b64} -> {via: railway, sent, found, not_found, left}   the Census's reply to that batch, placed

declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../../../app/lib/Geocoder.php';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        Response::json(['ok' => true, 'left' => count(Geocoder::candidates($pdo, 100000, true))]);
    }
    Response::requireMethod('POST');
    if (CrawlQueue::paused()) Response::json(['ok' => true, 'paused' => true, 'left' => count(Geocoder::candidates($pdo, 100000, true))]);
    @set_time_limit(240);
    $b = Response::jsonBody();
    if (isset($b['answers_b64'])) {   // the backup's answers: the worker sent the batch to the Census itself
        $raw = base64_decode((string) $b['answers_b64'], true);
        if ($raw === false) Response::json(['ok' => false, 'error' => 'The Census answers weren\'t readable.'], 400);
        Response::json(['ok' => true, 'via' => 'railway'] + Geocoder::takeAnswers($pdo, (array) ($b['ids'] ?? []), $raw));
    }
    Response::json(['ok' => true] + Geocoder::runOrHandOff($pdo, Geocoder::BATCH));
} catch (RuntimeException $e) {
    // the Census geocoder didn't answer (decisions/0163's source map, W2 map points: ours, then the Census, else it
    // waits): the batch waits for the next run, nothing lost, and the worker reports the task held, not failed
    error_log('api/crawl/geocode.php: the Census geocoder: ' . $e->getMessage());
    Response::json(['ok' => true, 'waits' => true, 'why' => 'The Census geocoder didn\'t answer: ' . mb_substr($e->getMessage(), 0, 200), 'sent' => 0, 'left' => count(Geocoder::candidates($pdo, 100000, true))]);
}
