<?php
// app/ui/search-lock.php — the search lock (decisions/0181 §4): until Jason lifts it, the site isn't indexed. Every page
// tv_page_start draws (page-shell.php), and through security-headers.php every other page and endpoint, plus the home page,
// sign-in, sign-up, password reset, the classic directory and storefronts (storefront-view.php). Lifting it is Jason's call
// alone, on his date: one release sets TV_SEARCH_LOCK to false here (0181 §4; the plan's G.4). No side effects: it only
// defines, so the trvgo.us router can load it too.
declare(strict_types=1);

if (!defined('TV_SEARCH_LOCK')) define('TV_SEARCH_LOCK', true);

/** The lock's robots meta, for pages that write their own <head> (page-shell.php prints its own). Nothing once lifted. */
function tv_robots_meta(): string
{
    return TV_SEARCH_LOCK ? '<meta name="robots" content="noindex">' : '';
}
