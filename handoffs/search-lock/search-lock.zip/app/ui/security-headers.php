<?php
// app/ui/security-headers.php — security headers and allowed methods, for every page and endpoint (Intuit's app security
// requirements, decisions/0096). Loaded by app/bootstrap.php, and first thing by the few pages that don't load it.
declare(strict_types=1);

// Only GET, HEAD and POST are used (OPTIONS answers a browser's preflight); TRACE and the rest are refused. Pages may be
// framed only by our own pages (Peek), browsers mustn't guess file types, and once on HTTPS a browser stays on it.
// Sensitive responses already carry Cache-Control: no-store (session pages, page-shell).
require_once __DIR__ . '/search-lock.php';   // the search lock (decisions/0181 §4)

if (PHP_SAPI !== 'cli') {
    // Always HTTPS on the live site. cPanel can't force it for an addon domain (traversence.com), so it's done here
    // too, before anything else; the root .htaccess can do the same for static files.
    $tvHost = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
    $tvHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    if (!$tvHttps && preg_match('/^(www\.)?traversence\.com$/', $tvHost)) {
        $m = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        header('Location: https://' . $tvHost . ($_SERVER['REQUEST_URI'] ?? '/'), true, in_array($m, ['GET', 'HEAD'], true) ? 301 : 308);
        exit;
    }
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD', 'POST', 'OPTIONS'], true)) {
        http_response_code(405); header('Allow: GET, HEAD, POST, OPTIONS'); exit;
    }
    // The staging copy only (decisions/0145 Phase 3): its viewing password, no indexing, the "Staging" mark. Does nothing on live.
    require_once __DIR__ . '/../lib/Staging.php';
    Staging::guard();
    // The search lock (decisions/0181 §4): until Jason lifts it, nothing on the site is indexed: every page, the home
    // page, sign-in, the directory and storefronts too. Lifting it is one release that sets TV_SEARCH_LOCK to false.
    if (TV_SEARCH_LOCK) header('X-Robots-Tag: noindex');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    if (!headers_sent() && !array_filter(headers_list(), fn ($h) => stripos($h, 'Referrer-Policy:') === 0)) header('Referrer-Policy: strict-origin-when-cross-origin');
    if ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
