<?php
// The live server is sending `Cache-Control: max-age=7200` (a 2-hour cache)
// on every response, including this page and both API endpoints — that's
// coming from the hosting/server config (likely an .htaccess mod_expires
// rule or a Bluehost caching feature), not from any PHP here, since nothing
// in this project set a Cache-Control header before now. During active
// development that means a browser can keep showing an already-fixed bug
// for up to two hours after the corrected file is uploaded. This explicitly
// overrides it so the page is always served fresh; once the site is done
// changing daily, this can be relaxed back to a real cache duration.
require_once __DIR__ . '/../../app/ui/security-headers.php';
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// Browse groups for the category filter, straight from the categories table
// (admin-managed; see migrations/2026-09-19_categories.sql). Rendered
// server-side so the saved-search restore in the page script always finds its
// option. If the table is unavailable the filter just shows "All Categories".
$dir_categories = [];
try {
  require_once __DIR__ . '/../../app/lib/Database.php';
  $dir_categories = Database::connection()
    ->query('SELECT slug, name FROM categories WHERE parent_id IS NULL AND is_active = 1 ORDER BY sort_order, name')
    ->fetchAll(PDO::FETCH_ASSOC);
} catch (\Throwable $e) {
  error_log('directory/index.php categories: ' . $e->getMessage());
}

// Claim flow entry (add-listing and claim are ONE flow). Null until the page
// is deployed, so no dead links. PROPOSED URL contract for that page:
//   <claim>?listing={entity id}  -> claim an existing unclaimed listing
//   <claim>?new=1                -> business isn't listed; add it via claim
require_once __DIR__ . '/../../app/ui/routes.php';
$claim_url = tv_route(['claim.php' => '/claim.php', 'claim/index.php' => '/claim/']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?= tv_robots_meta() ?>
  <title>Traversence — Local Business Directory</title>
  <meta name="description" content="Find trusted local businesses and community services near you.">
  <meta name="tv-build" content="directory-2j">
  <meta property="og:title" content="Traversence — Local Business Directory">
  <meta property="og:description" content="Find trusted local businesses and community services near you.">
  <meta property="og:type" content="website">
  <?php require_once __DIR__ . '/../../app/ui/favicon.php'; echo tv_favicon_links(); ?>
  <!-- Paints the page's true background before Tailwind's CDN script finishes
       compiling utility classes, so there's no flash/mismatch on first paint
       (Seamless Visual Consistency). #EFE3C8 is the site's light tan body tone. -->
  <style>
    html, body { background-color: var(--tv-canvas); }
  </style>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[var(--tv-canvas)] text-[color:var(--tv-ink)] min-h-screen flex flex-col font-sans">

<!-- Top bar: ONE compact fixed block, always the same size.
       Row 1  logo | search | nav icons   (search moves under the logo on phones)
       Row 2  a thin text line: Where / Category / Sort / count
     No hide-and-show toggle: it is small enough to just stay. -->
<style>
  .fl-select { background: transparent; color: var(--tv-on-umber); font-size: 12px; border: 0; border-bottom: 1px dotted var(--tv-taupe);
    padding: 0 2px; cursor: pointer; max-width: 11rem; }
  .fl-select:focus { outline: none; border-bottom-color: color-mix(in srgb,var(--tv-hold) 35%,var(--tv-canvas)); }
  .fp-h { color: var(--tv-sage); font-weight: 600; text-transform: uppercase; letter-spacing: .05em; font-size: 11px; margin-right: .25rem; }
  .fp-o { display: inline-flex; align-items: center; gap: .3rem; cursor: pointer; }
  .fp-o input { accent-color: var(--tv-hold); }
  .fp-cats { display: grid; grid-template-columns: repeat(auto-fill, minmax(12rem, 1fr)); gap: .15rem .9rem; margin-top: .35rem; }
  #fl-more-n:not(:empty) { margin-left: .3rem; background: var(--tv-hold-bg); color: var(--tv-ink); border-radius: 999px; padding: 0 .4rem; font-weight: 700; }
  .fl-select option { background: var(--tv-canvas); color: var(--tv-ink); }
  .fl-select option:disabled { color: var(--tv-on-umber-meta); }
  @media (max-width: 639px) {
    /* Phones: the status row is just Category + Sort on one line. The place is already in
       the search box and the count is in the summary below, so nothing is said twice. */
    #status-row .fl-select { max-width: none; width: 100%; font-size: 13px; }
    #status-row label { display: flex; align-items: baseline; gap: .35rem; min-width: 0; }
    #narrow-row, #saved-row { flex-wrap: nowrap !important; overflow-x: auto; -webkit-overflow-scrolling: touch; scrollbar-width: none; padding-bottom: 2px; }
    #narrow-row::-webkit-scrollbar, #saved-row::-webkit-scrollbar { display: none; }
    #narrow-row > *, #saved-row > * { flex-shrink: 0; white-space: nowrap; }
  }
  .fl-select.fl-active { color: var(--tv-sage); border-bottom: 1px solid var(--tv-sage); font-weight: 600; }
  .fl-link { color: var(--tv-on-umber); text-decoration: underline dotted; text-underline-offset: 3px; }
  .fl-link:hover { color: var(--tv-sage); }
  .tb-icon { display: inline-flex; align-items: center; justify-content: center; height: 2rem; width: 2rem; border-radius: .5rem; color: var(--tv-ink); transition: background .15s, color .15s; position: relative; }
  .tb-icon:hover { background: var(--tv-card-b); }
  .tb-icon.hidden { display: none; }
  /* "on" = glowing green: place set, tools open */
  .tb-icon[aria-expanded="true"], .tb-icon.tv-glow { color: color-mix(in srgb,var(--tv-moss) 50%,var(--tv-ink)); background: color-mix(in srgb,var(--tv-moss) 18%,var(--tv-canvas)); filter: none; }
  .tb-icon[aria-expanded="true"] svg, .tb-icon.tv-glow svg { filter: drop-shadow(0 0 4px rgba(34,197,94,.75)); }
  /* Results: cards, or cards + map (side by side on desktop, map alone on phones) */
  #map-col { display: none; }
  #results-layout.map-mode { display: grid; gap: 1.5rem; grid-template-columns: minmax(0, 2fr) minmax(0, 3fr); align-items: start; }
  #results-layout.map-mode #map-col { display: block; position: sticky; top: calc(var(--bar-h, 120px) + 12px); }
  #results-layout.map-mode .list { grid-template-columns: 1fr !important; }
  #map { height: calc(100vh - var(--bar-h, 120px) - 64px); min-height: 380px; border: 1px solid var(--tv-line-strong); border-radius: .75rem; background: var(--tv-card-b); z-index: 0; }
  @media (max-width: 1023px) {
    #results-layout.map-mode { display: block; }
    #results-layout.map-mode #list-col { display: none; }
    #results-layout.map-mode #map-col { position: relative; top: 0; }
    #map { height: 68vh; }
  }
  .tv-pin span { display: block; width: 16px; height: 16px; border-radius: 50%; background: var(--tv-copper); border: 2px solid var(--tv-umber); box-shadow: 0 1px 3px rgba(0,0,0,.45); }
  .tv-pin.tv-ok span { background: #16A34A; }
</style>
<div id="top-bar" class="bg-[var(--tv-umber)] fixed top-0 left-0 right-0 z-40 shadow-lg">
  <div class="px-3 sm:px-6 py-1 flex flex-wrap sm:flex-nowrap items-center gap-x-3 gap-y-1">
    <div class="order-1 shrink-0"><?php require_once __DIR__ . '/../../app/ui/brand.php'; ?></div>

    <div class="order-3 sm:order-2 w-full sm:w-auto sm:flex-1 min-w-0 sm:max-w-3xl sm:mx-auto pb-1.5 sm:pb-0">
      <div class="relative">
        <div class="flex items-center bg-[var(--tv-canvas)] border border-[color:var(--tv-line-strong)] rounded-lg shadow-inner focus-within:border-[color:var(--tv-focus)] focus-within:ring-2 focus-within:ring-amber-500/40 transition">
          <input type="text" id="search-main-input" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="suggest-list" autocomplete="off" spellcheck="false" class="search flex-1 min-w-0 bg-transparent px-4 py-2 text-[color:var(--tv-ink)] placeholder-[color:var(--tv-meta)] focus:outline-none text-sm sm:text-base font-medium" placeholder="Click here to start your search experience, Let&rsquo;s Get Local!">
          <!-- Icons live inside the bar: search, place, tools (radius + nearby towns), clear -->
          <div class="flex items-center shrink-0 pr-1 gap-0.5 border-l border-[color:var(--tv-line-strong)] ml-1 pl-1">
            <button type="button" id="tb-search" onclick="launchSearch(document.querySelector('.search').value)" class="tb-icon" title="Search" aria-label="Search">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            </button>
            <button type="button" id="tb-place" onclick="openLocationModal()" class="tb-icon" title="Choose where to search" aria-label="Choose where to search" aria-haspopup="dialog">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            </button>
            <button type="button" id="tb-map" onclick="toggleMapView()" class="tb-icon hidden" title="Show results on a map" aria-label="Show results on a map" aria-pressed="false">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"></polygon><line x1="8" y1="2" x2="8" y2="18"></line><line x1="16" y1="6" x2="16" y2="22"></line></svg>
            </button>
            <button type="button" id="tb-radius" onclick="toggleToolsPanel('both')" class="tb-icon hidden" title="Radius and nearby towns" aria-label="Radius and nearby towns" aria-expanded="false" aria-controls="tools-panel">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>
            </button>
            <button type="button" id="tb-clear" onclick="clearAll()" class="tb-icon hidden" title="Clear everything and start over" aria-label="Clear everything and start over">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-[18px] w-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
            </button>
          </div>
        </div>
        <ul id="suggest-list" role="listbox" aria-label="Search suggestions" class="hidden absolute left-0 right-0 top-full mt-1 z-50 bg-[var(--tv-canvas)] border border-[color:var(--tv-line-strong)] rounded-xl shadow-2xl max-h-80 overflow-y-auto py-1"></ul>
      </div>
    </div>

    <div class="order-2 sm:order-3 ml-auto shrink-0"><?php require_once __DIR__ . '/../../app/ui/header.php'; ?></div>
  </div>

  <!-- Row 2: only once a search is running. Plain text, thin separator above. -->
  <div id="status-row" class="hidden border-t border-[color:color-mix(in_srgb,var(--tv-umber-line)_70%,transparent)] bg-[var(--tv-umber)]">
    <div class="px-3 sm:px-6 py-1 flex items-center gap-x-3 gap-y-0.5 sm:flex-wrap text-xs text-[color:var(--tv-on-umber-meta)] leading-6">
      <span class="hidden sm:inline-flex flex-wrap items-center gap-x-1.5">
        <span class="text-[color:var(--tv-meta)]">Active search:</span>
        <span id="fl-where-text" class="text-[color:var(--tv-sage)] font-semibold truncate max-w-[14rem]">Everywhere</span>
        <span id="fl-where-note" class="text-[color:var(--tv-meta)]"></span>
        <span id="fl-widen" class="hidden"></span>
      </span>
      <span class="hidden sm:inline text-[color:var(--tv-on-umber-meta)]" aria-hidden="true">|</span>
      <label class="flex-1 sm:flex-none min-w-0">Category
        <select id="category-filter" onchange="applyToolbarFilters()" class="fl-select">
          <option value="all">All</option>
          <?php foreach ($dir_categories as $cat): ?>
          <option value="<?= htmlspecialchars($cat['slug'], ENT_QUOTES, 'UTF-8') ?>" data-name="<?= htmlspecialchars($cat['name'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($cat['name'], ENT_QUOTES, 'UTF-8') ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="shrink-0">Sort
        <select id="sort-filter" onchange="sortTouched = true; applyToolbarFilters()" class="fl-select">
          <option value="best" id="sort-opt-best" hidden disabled>Best match</option>
          <option value="name">A&ndash;Z</option>
          <option value="distance" id="sort-opt-distance">Nearest</option>
          <option value="city">Town</option>
        </select>
      </label>
      <button type="button" id="fl-more" onclick="toggleFilters()" class="fl-link" aria-expanded="false" aria-controls="filters-panel">Filters<span id="fl-more-n"></span></button>
      <span class="hidden sm:flex ml-auto items-center gap-3">
        <span id="results-count" class="text-[color:var(--tv-meta)]"></span>
        <button type="button" id="fl-start-over" onclick="resetToBrowse()" class="fl-link">Start over</button>
      </span>
    </div>
  </div>

  <!-- Row 3 (opens from the gear or share icon). A distance needs a centre, so for
       a state, a region (or no place) it offers a ZIP box instead. -->
  <!-- Filters (decisions/0053 §4): open now / on a day, has phone / website, several categories at once. -->
  <div id="filters-panel" class="hidden border-t border-[color:color-mix(in_srgb,var(--tv-umber-line)_70%,transparent)] bg-[var(--tv-umber)]">
    <div class="px-3 sm:px-6 py-2.5 text-xs text-[color:var(--tv-on-umber-meta)] space-y-2.5">
      <div class="flex flex-wrap items-center gap-x-3 gap-y-1.5">
        <span class="fp-h">Open</span>
        <label class="fp-o"><input type="radio" name="fp-open" value=""> Any time</label>
        <label class="fp-o"><input type="radio" name="fp-open" value="now"> Open now</label>
        <label class="fp-o"><input type="radio" name="fp-open" value="day"> Open on
          <select id="fp-day" class="fl-select"><option value="mon">Monday</option><option value="tue">Tuesday</option><option value="wed">Wednesday</option><option value="thu">Thursday</option><option value="fri">Friday</option><option value="sat">Saturday</option><option value="sun">Sunday</option></select></label>
        <span class="text-[color:var(--tv-meta)]">Uses the hours listings publish; unknown hours are left out.</span>
      </div>
      <div class="flex flex-wrap items-center gap-x-3 gap-y-1.5">
        <span class="fp-h">Has</span>
        <label class="fp-o"><input type="checkbox" id="fp-phone"> a phone number</label>
        <label class="fp-o"><input type="checkbox" id="fp-web"> a website</label>
        <button type="button" class="fl-link" onclick="toggleToolsPanel('both')">Distance &amp; nearby towns</button>
      </div>
      <div>
        <span class="fp-h">Categories</span> <span class="text-[color:var(--tv-meta)]">(tick several to see them together)</span>
        <div id="fp-cats" class="fp-cats"></div>
      </div>
      <div class="flex gap-3"><button type="button" class="fl-link" onclick="clearExtraFilters()">Clear these filters</button><button type="button" class="fl-link" onclick="toggleFilters(false)">Close</button></div>
    </div>
  </div>

  <div id="tools-panel" class="hidden border-t border-[color:color-mix(in_srgb,var(--tv-umber-line)_70%,transparent)] bg-[var(--tv-umber)]">
    <div class="px-3 sm:px-6 py-2 text-xs text-[color:var(--tv-on-umber-meta)] space-y-2">
      <div id="tools-point" class="space-y-2">
        <div id="tools-radius-row" class="flex flex-wrap items-center gap-x-3 gap-y-1">
          <label for="radius-slider">Radius</label>
          <input type="range" id="radius-slider" min="10" max="250" step="10" value="10" oninput="previewRadius(this.value)" class="w-44 sm:w-72 accent-amber-500 cursor-pointer">
          <span class="font-mono text-[color:var(--tv-sage)]"><span id="radius-val">10</span> miles</span>
          <span class="text-[color:var(--tv-meta)]">10 &ndash; 250</span>
        </div>
        <div id="tools-towns-row" class="flex flex-wrap items-center gap-1.5">
          <span class="text-[color:var(--tv-meta)]">Towns in range:</span>
          <span id="regional-hubs-container" class="flex flex-wrap gap-1.5"></span>
        </div>
      </div>
      <div id="tools-region" class="hidden flex flex-wrap items-center gap-x-3 gap-y-1.5">
        <span>Distance and nearby towns work around a ZIP or town. Enter a ZIP:</span>
        <form onsubmit="return goZip(event, 'tools-zip', 'tools-zip-msg')" class="flex items-center gap-1.5">
          <input id="tools-zip" inputmode="numeric" maxlength="5" pattern="\d{5}" placeholder="ZIP" aria-label="ZIP code" class="w-20 bg-[var(--tv-void)] border border-[color:var(--tv-umber-line)] rounded-md px-2 py-1 text-[color:var(--tv-on-umber)] focus:outline-none focus:border-[color:var(--tv-focus)]">
          <button type="submit" class="px-2.5 py-1 rounded-md bg-[var(--tv-link)] hover:bg-[var(--tv-crimson)] text-white font-semibold transition">Go</button>
        </form>
        <button type="button" onclick="openLocationModal()" class="fl-link">Use my location or a town</button>
        <span id="tools-zip-msg" class="text-[color:var(--tv-sage)]"></span>
      </div>
      <div class="flex"><button type="button" onclick="toggleToolsPanel(false)" class="ml-auto fl-link">Close</button></div>
    </div>
  </div>
</div>
<!-- Reserves the flow-space the fixed bar occupies (height set by syncTopBarSpacer). -->
<div id="fixed-stack-spacer"></div>

<div class="flex-1 flex flex-col">
  <!-- Places strip: saved places (signed in) and the next step down the
       hierarchy. Plain chips, one or two lines, scrolls away with the page. -->
  <section id="narrow-strip" class="hidden max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-12 pt-3 space-y-1.5">
    <div id="saved-row" data-more class="hidden flex flex-wrap items-center gap-1.5 text-xs text-[color:var(--tv-meta)]"></div>
    <div id="narrow-row" data-more class="hidden flex flex-wrap items-center gap-1.5 text-xs text-[color:var(--tv-meta)]"></div>
  </section>

  <!-- Browse view (before any search). Where first, then what. -->
  <section id="funnel" class="max-w-5xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-20 sm:min-h-[75vh]">
    <h1 class="text-2xl sm:text-3xl font-serif font-bold text-[color:var(--tv-ink)]">Find local businesses</h1>
    <p class="mt-2 text-sm sm:text-base text-[color:var(--tv-meta)] max-w-3xl leading-relaxed">Traversence groups every business by the community it belongs to, so what you see is what is really near you. Answer two quick questions and the listings appear. You can also click the search bar at any time and it will ask them for you.</p>

    <ol id="funnel-steps" class="grid sm:grid-cols-3 gap-3 mt-5 mb-6 text-sm" aria-label="How it works">
      <li data-step="1" class="rounded-xl border border-[color:var(--tv-line-strong)] bg-[var(--tv-canvas)] px-4 py-3"><span class="font-serif font-bold text-[color:var(--tv-ink)]">1 &middot; Choose a place</span><span class="block text-xs text-[color:var(--tv-meta)] mt-0.5">A state, a ZIP code, or your current location.</span></li>
      <li data-step="2" class="rounded-xl border border-[color:var(--tv-line-strong)] bg-[var(--tv-canvas)] px-4 py-3"><span class="font-serif font-bold text-[color:var(--tv-ink)]">2 &middot; Say what you need</span><span class="block text-xs text-[color:var(--tv-meta)] mt-0.5">Pick a category, or type a business or town.</span></li>
      <li data-step="3" class="rounded-xl border border-[color:var(--tv-line-strong)] bg-[var(--tv-canvas)] px-4 py-3"><span class="font-serif font-bold text-[color:var(--tv-ink)]">3 &middot; Narrow and choose</span><span class="block text-xs text-[color:var(--tv-meta)] mt-0.5">Phone and address at a glance. Sort, filter or widen the area as you go.</span></li>
    </ol>

    <!-- Step 1: where (shown until a place is chosen) -->
    <div id="funnel-where" class="mt-4 space-y-4">
      <p class="text-sm text-[color:var(--tv-meta)]">Where are you looking?</p>
      <div>
        <p class="text-[11px] uppercase tracking-widest text-[color:var(--tv-meta)] mb-1.5">Pick a state</p>
        <div id="funnel-states" class="flex flex-wrap gap-2"><span class="text-xs text-[color:var(--tv-meta)]">Loading states&hellip;</span></div>
      </div>
      <div class="flex flex-wrap items-center gap-x-4 gap-y-2">
        <form onsubmit="return goZip(event, 'land-zip', 'land-zip-msg')" class="flex items-center gap-2">
          <label for="land-zip" class="text-sm text-[color:var(--tv-ink)]">Or enter your ZIP</label>
          <input id="land-zip" inputmode="numeric" maxlength="5" pattern="\d{5}" placeholder="ZIP" class="w-24 bg-[var(--tv-canvas)] border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-[color:var(--tv-focus)]">
          <button type="submit" class="px-3 py-1.5 rounded-lg bg-[var(--tv-link)] hover:bg-[var(--tv-crimson)] text-white text-sm font-semibold transition">Go</button>
        </form>
        <button type="button" id="land-locate" onclick="useMyLocation(this)" class="text-sm px-3 py-1.5 rounded-lg border border-[color:var(--tv-line-strong)] bg-[var(--tv-card-b)] hover:bg-[var(--tv-card-b)] transition">Use my location</button>
        <span id="land-zip-msg" class="text-xs text-[color:var(--tv-link)]"></span>
      </div>
      <p><button type="button" id="land-browse-cats" class="text-sm underline decoration-dotted text-[color:var(--tv-link)] hover:text-[color:var(--tv-crimson)]">Just browsing? See categories first</button></p>
    </div>

    <!-- Step 2: what (after a place is chosen, or by choice) -->
    <div id="funnel-what" class="hidden mt-2">
      <p id="funnel-what-title" class="text-sm text-[color:var(--tv-meta)] mb-3">What are you looking for?</p>
      <?php if ($dir_categories): ?>
      <div id="funnel-tiles" class="flex flex-wrap gap-2">
        <?php foreach ($dir_categories as $cat): ?>
        <button type="button" data-cat="<?= htmlspecialchars($cat['slug'], ENT_QUOTES, 'UTF-8') ?>" class="text-sm px-4 py-2 rounded-full border border-[color:var(--tv-line-strong)] bg-[var(--tv-card-b)] hover:bg-[var(--tv-card-b)] hover:border-amber-600/60 text-[color:var(--tv-ink)] transition"><?= htmlspecialchars($cat['name'], ENT_QUOTES, 'UTF-8') ?></button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
    <p id="funnel-place-hint" class="hidden text-sm text-[color:var(--tv-ink)] mt-5 inline-block rounded-lg border border-[color:var(--tv-line-strong)] bg-[color-mix(in_srgb,var(--tv-card-b)_60%,transparent)] px-3 py-2"></p>
  </section>

  <!-- Results (hidden until a search runs) -->
  <section id="directory" class="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-12 pt-4 pb-16 flex-1 hidden">
    <!-- "What am I looking at?": the count plus every active filter, each removable. -->
    <div id="results-summary" class="mb-4 flex flex-wrap items-center gap-2 text-sm text-[color:var(--tv-ink)]" aria-live="polite"></div>
    <div id="results-layout">
      <div id="list-col">
        <ul class="list grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <!-- Dynamic results load here -->
        </ul>
        <div id="pagination-container" class="flex justify-center items-center gap-2 mt-10 pt-6 border-t border-[color:var(--tv-line-strong)] hidden"></div>
      </div>
      <div id="map-col">
        <div id="map" role="region" aria-label="Map of the results"></div>
        <p id="map-note" class="text-xs text-[color:var(--tv-meta)] mt-2" aria-live="polite"></p>
      </div>
    </div>
    <p id="widen-hint" class="hidden text-center text-xs text-[color:var(--tv-meta)] mt-6"></p>
    <p id="add-hint" class="hidden text-center text-xs text-[color:var(--tv-meta)] mt-2"></p>
  </section>
</div>


  <?php require_once __DIR__ . '/../../app/ui/footer.php'; tv_footer(); ?>

  <?php require_once __DIR__ . '/../../app/ui/location-modal.php'; ?>

  <script src="/js/shared-auth.js"></script>
  <script src="/js/location-scope.js?v=<?= (int)@filemtime(__DIR__ . '/../js/location-scope.js') ?>"></script>
  <script src="/js/map-view.js?v=<?= (int)@filemtime(__DIR__ . '/../js/map-view.js') ?>" defer></script>
  <script src="/js/header-nav.js?v=<?= (int)@filemtime(__DIR__ . '/../js/header-nav.js') ?>" defer></script>
  <script src="/js/link-button.js?v=<?= (int)@filemtime(__DIR__ . '/../js/link-button.js') ?>" defer></script>
  <script>
    // allListings holds only the CURRENT PAGE; filtering, sorting and paging are
    // done by api/search_listings.php. totalListings is the full match count.
    let allListings = [];
    let totalListings = 0;
    let listingsFetchToken = 0; // discards a slow response that a newer search superseded
    let currentPage = 1;
    let hasSearched = false;
    const itemsPerPage = 9;

    // ---- Layout: one fixed bar, one measured height --------------------------
    // #top-bar is fixed; the spacer below it is set to its exact height so the
    // page starts right underneath (re-measured whenever the bar can change size:
    // resize, image load, logo shrink, places changing the "Where" line).
    function syncTopBarSpacer() {
      const topBar = document.getElementById('top-bar');
      const spacer = document.getElementById('fixed-stack-spacer');
      if (!topBar || !spacer) return;
      spacer.style.height = topBar.offsetHeight + 'px';
      if (window.TvMap) TvMap.retop();   // the full-screen map sits just under the bar
      document.documentElement.style.setProperty('--bar-h', topBar.offsetHeight + 'px');
    }
    window.addEventListener('resize', syncTopBarSpacer);
    window.addEventListener('load', syncTopBarSpacer);

    // ---- Remembered search (query + filters) across a round trip to e.g. the dashboard ----
    // This tab only. A filter is never carried into a later visit: coming back
    // days later to a search you don't remember (and can't see why) is confusing.
    function saveSearchState() {
      const state = {
        query: document.querySelector('.search').value,
        category: document.getElementById('category-filter').value,
        sort: document.getElementById('sort-filter').value,
        active: hasSearched,
        view: viewMode,
        xf: xf,
      };
      try { sessionStorage.setItem('traversence_search_state', JSON.stringify(state)); } catch (e) {}
      try { localStorage.removeItem('traversence_search_state'); } catch (e) {} // older builds kept it here
    }
    function loadSavedSearchState() {
      try { localStorage.removeItem('traversence_search_state'); } catch (e) {}
      try {
        const raw = sessionStorage.getItem('traversence_search_state');
        return raw ? JSON.parse(raw) : null;
      } catch (e) { return null; }
    }
    function clearSavedSearchState() {
      try { localStorage.removeItem('traversence_search_state'); } catch (e) {}
      try { sessionStorage.removeItem('traversence_search_state'); } catch (e) {}
    }

    // ---- Nothing here ever blocks a search ------------------------------------
    // A search needs *something* to look for: words, a category or a place. With
    // none of those the page shows its browse view (categories + places) instead.
    // No place is never an error: results are simply from everywhere.
    function hasCriteria(query) {
      return !!(hasLocationSet(currentLocation) || (query || '').trim() || document.getElementById('category-filter').value !== 'all' || xfCount() > 0);
    }

    let authSettled = false;
    async function launchSearch(query) {
      const input = document.querySelector('.search');
      if (query === undefined) query = input.value;
      if (!authSettled && window.authReady) { try { await window.authReady; } catch (e) {} authSettled = true; }
      // A signed-in visitor who opens the directory directly starts from their
      // default place (never on a funneled/region visit: that set a place already).
      if (!hasSearched) applyDefaultPlaceIfAny();
      if (!hasCriteria(query)) { if (hasSearched) resetToBrowse(); return; }
      syncSortOptions();
      markActiveFilters();
      revealSearchUI();
      fetchListings(query, currentLocation, 1);
    }

    function revealSearchUI() {
      hasSearched = true;
      document.getElementById('funnel').classList.add('hidden');
      document.getElementById('directory').classList.remove('hidden');
      document.getElementById('status-row').classList.remove('hidden');
      renderWhere();
      syncTopBarSpacer();
    }

    // Back to the browse view. Keeps the chosen place; clears words and category.
    function resetToBrowse() {
      hasSearched = false;
      if (viewMode === 'map') setViewMode('cards');
      listingsFetchToken++; // ignore any response still in flight
      searchWide = false;
      sortTouched = false;
      document.getElementById('sort-filter').value = 'name';
      document.querySelector('.search').value = '';
      document.getElementById('category-filter').value = 'all';
      xf.open = ''; xf.phone = false; xf.web = false; xf.cats = []; paintFilters(); toggleFilters(false);
      document.getElementById('funnel').classList.remove('hidden');
      document.getElementById('directory').classList.add('hidden');
      document.getElementById('status-row').classList.add('hidden');
      document.getElementById('results-count').textContent = '';
      clearSavedSearchState();
      markActiveFilters();
      renderWhere();
      syncTopBarSpacer();
    }

    // Non-default filters are highlighted so they can't hide.
    function markActiveFilters() {
      document.getElementById('category-filter').classList.toggle('fl-active', document.getElementById('category-filter').value !== 'all');
      document.getElementById('sort-filter').classList.toggle('fl-active', document.getElementById('sort-filter').value === 'city');
    }

    // The sentence above the results: how many, and exactly what is filtering them.
    function renderResultsSummary() {
      const box = document.getElementById('results-summary');
      if (!box) return;
      box.textContent = '';
      const strong = document.createElement('strong');
      strong.textContent = totalListings.toLocaleString() + (totalListings === 1 ? ' listing' : ' listings');
      box.appendChild(strong);
      const chip = (prefix, text, fn, title, hideOnPhone) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.title = title;
        b.className = (hideOnPhone ? 'hidden sm:inline-flex ' : 'inline-flex ') + 'items-center gap-1.5 px-2.5 py-1 rounded-full border border-amber-600/60 bg-amber-100/70 hover:bg-amber-200 text-[color:var(--tv-ink)] text-xs transition';
        b.appendChild(document.createTextNode(prefix + text + ' '));
        const x = document.createElement('span'); x.setAttribute('aria-hidden', 'true'); x.className = 'text-[color:var(--tv-link)] font-bold'; x.textContent = '\u00d7';
        b.appendChild(x);
        b.addEventListener('click', fn);
        box.appendChild(b);
      };
      const q = document.querySelector('.search').value.trim();
      const catSel = document.getElementById('category-filter');
      if (q) chip('matching ', '\u201c' + q + '\u201d', () => { document.querySelector('.search').value = ''; applyToolbarFilters(); }, 'Clear search words');
      if (catSel.value !== 'all' && !searchWide) chip('in ', (catSel.options[catSel.selectedIndex].dataset.name || catSel.options[catSel.selectedIndex].text), () => { catSel.value = 'all'; applyToolbarFilters(); }, 'Clear category');
      if (!searchWide) {
        if (xf.cats.length) chip('in ', xf.cats.length === 1 ? (catSel.querySelector('option[value="' + xf.cats[0] + '"]')?.dataset.name || xf.cats[0]) : xf.cats.length + ' categories', () => { xf.cats = []; paintFilters(); applyToolbarFilters(); }, 'Clear categories');
        if (xf.open) chip('', DAY_NAME[xf.open], () => { xf.open = ''; paintFilters(); applyToolbarFilters(); }, 'Any time');
        if (xf.phone) chip('', 'has a phone', () => { xf.phone = false; paintFilters(); applyToolbarFilters(); }, 'Clear');
        if (xf.web) chip('', 'has a website', () => { xf.web = false; paintFilters(); applyToolbarFilters(); }, 'Clear');
      }
      if (searchWide) {
        const t = document.createElement('span'); t.className = 'text-xs text-[color:var(--tv-meta)]'; t.textContent = 'from everywhere (looking up a business name)';
        box.appendChild(t);
      } else if (hasLocationSet(currentLocation)) {
        const l = currentLocation;
        const pt = isPointPlace() ? ' (' + (l.radius || 10) + ' mi)' : '';
        chip(isRegionLike() ? 'in ' : 'near ', placeLabel() + pt, chooseAnywhere, 'Search everywhere instead', true);
      } else {
        const t = document.createElement('span'); t.className = 'text-xs text-[color:var(--tv-meta)]'; t.textContent = 'from everywhere';
        box.appendChild(t);
      }
    }

    // ---- The Filters panel (decisions/0053 §4) ----
    // xf: open ('' | 'now' | 'mon'…'sun'), has a phone / website, several categories (ticked groups).
    const xf = { open: '', phone: false, web: false, cats: [] };
    function xfCount() { return (xf.open ? 1 : 0) + (xf.phone ? 1 : 0) + (xf.web ? 1 : 0) + (xf.cats.length ? 1 : 0); }
    function paintFilters() {
      const n = xfCount();
      document.getElementById('fl-more-n').textContent = n ? String(n) : '';
      document.querySelectorAll('input[name="fp-open"]').forEach(r => { r.checked = r.value === (xf.open === 'now' ? 'now' : xf.open ? 'day' : ''); });
      if (xf.open && xf.open !== 'now') document.getElementById('fp-day').value = xf.open;
      document.getElementById('fp-phone').checked = xf.phone;
      document.getElementById('fp-web').checked = xf.web;
      const box = document.getElementById('fp-cats');
      if (!box.childElementCount) {
        [...document.getElementById('category-filter').options].forEach(o => {
          if (o.value === 'all' || o.dataset.dyn) return;
          const l = document.createElement('label'); l.className = 'fp-o';
          l.innerHTML = '<input type="checkbox" value="' + o.value + '"> ' + (o.dataset.name || o.text).replace(/[<>&]/g, '');
          box.appendChild(l);
        });
      }
      box.querySelectorAll('input').forEach(i => { i.checked = xf.cats.indexOf(i.value) >= 0; });
    }
    function toggleFilters(force) {
      const p = document.getElementById('filters-panel'), open = force === undefined ? p.classList.contains('hidden') : force;
      p.classList.toggle('hidden', !open);
      document.getElementById('fl-more').setAttribute('aria-expanded', String(open));
      if (open) paintFilters();
      syncTopBarSpacer();
    }
    function readFilters() {
      const r = document.querySelector('input[name="fp-open"]:checked');
      xf.open = !r || !r.value ? '' : r.value === 'now' ? 'now' : document.getElementById('fp-day').value;
      xf.phone = document.getElementById('fp-phone').checked;
      xf.web = document.getElementById('fp-web').checked;
      xf.cats = [...document.querySelectorAll('#fp-cats input:checked')].map(i => i.value);
      if (xf.cats.length) document.getElementById('category-filter').value = 'all';   // ticked categories replace the single one
      paintFilters();
      applyToolbarFilters();
    }
    function clearExtraFilters() { xf.open = ''; xf.phone = false; xf.web = false; xf.cats = []; paintFilters(); applyToolbarFilters(); }
    document.getElementById('filters-panel').addEventListener('change', readFilters);
    document.getElementById('category-filter').addEventListener('change', () => { if (xf.cats.length) { xf.cats = []; paintFilters(); } });
    function extraQS() {
      const p = [];
      if (xf.open === 'now') { const d = new Date(); p.push('open=now', 'at=' + d.getDay() + ',' + (d.getHours() * 60 + d.getMinutes())); }
      else if (xf.open) p.push('open=' + xf.open);
      const has = [xf.phone ? 'phone' : '', xf.web ? 'website' : ''].filter(Boolean);
      if (has.length) p.push('has=' + has.join(','));
      return p.length ? '&' + p.join('&') : '';
    }
    const DAY_NAME = { now: 'open now', mon: 'open Monday', tue: 'open Tuesday', wed: 'open Wednesday', thu: 'open Thursday', fri: 'open Friday', sat: 'open Saturday', sun: 'open Sunday' };

    function applyToolbarFilters() {
      currentPage = 1;
      markActiveFilters();
      launchSearch(document.querySelector('.search').value);
    }

    // A specific category (a leaf such as "Bars") is not one of the ~20 groups in the
    // dropdown, so it is added as a temporary option while it is chosen.
    function pickCategory(slug, label) {
      const sel = document.getElementById('category-filter');
      sel.querySelectorAll('option[data-dyn]').forEach(o => { if (o.value !== slug) o.remove(); });
      sel.value = slug;
      if (sel.value !== slug && label) {
        const o = document.createElement('option');
        o.value = slug; o.dataset.name = label; o.dataset.dyn = '1'; o.textContent = label;
        sel.appendChild(o);
        sel.value = slug;
      }
      if (sel.value !== slug) sel.value = 'all';
      applyToolbarFilters();
    }

    // Category dropdown follows the search: each group shows how many results it holds;
    // groups with none stay listed but greyed out (the chosen one is never disabled).
    let didYouMean = null;
    function applyFacets(f) {
      const sel = document.getElementById('category-filter');
      const groups = f.groups || {};
      [...sel.options].forEach(o => {
        const name = o.dataset.name || (o.value === 'all' ? 'All categories' : o.text);
        if (o.value === 'all') { o.textContent = name + ' (' + (f.total || 0).toLocaleString() + ')'; o.disabled = false; return; }
        if (o.dataset.dyn) { o.textContent = name; return; }
        const n = groups[o.value] || 0;
        o.textContent = name + ' (' + n.toLocaleString() + ')';
        o.disabled = (n === 0 && sel.value !== o.value);
      });
    }

    // ---- "Where" ---------------------------------------------------------------
    function placeLabel() {
      const l = currentLocation;
      if (l.savedLabel) return l.savedLabel + ((l.scope || isStateOnly(l)) ? '' : (l.city ? ' (' + l.city + ')' : (l.zip ? ' (' + l.zip + ')' : '')));
      if (l.scope) return l.scope.label;
      if (l.zip) return 'ZIP ' + l.zip;
      if (l.city) return l.city + (l.state && l.state !== 'all' ? ', ' + l.state : '');
      if (isStateOnly(l)) return STATE_NAMES[l.state] || l.state;
      if (l.lat != null && l.lon != null) return 'Current location';
      return 'Everywhere';
    }

    // Called by js/location-scope.js whenever the place label changes.
    function onPlaceLabelChanged() { renderWhere(); }

    // Sort follows how the visitor is searching. Nearest only means something around a
    // point (ZIP, town, GPS) and is the default there; for a state, a region or
    // everywhere it is A-Z (or Town, which groups by town). Their own pick is kept.
    let sortTouched = false;

    // The circled x: one tap puts the page back to a fresh start. Clears the words,
    // category, sort, radius and place, closes the tools, and shows "where first"
    // again. (A signed-in default is not pulled back in until they choose a place.)
    function updateClearBtn() {
      const any = hasLocationSet(currentLocation) || hasSearched || catsFirst ||
        document.querySelector('.search').value.trim() !== '' || document.getElementById('category-filter').value !== 'all';
      document.getElementById('tb-clear').classList.toggle('hidden', !any);
    }
    function clearAll() {
      toggleToolsPanel(false);
      catsFirst = false;
      currentLocation = { state: null, city: null, zip: null, lat: null, lon: null, radius: 10, scope: null, source: null };
      clearSavedLocation();
      try { sessionStorage.setItem('traversence_anywhere', '1'); } catch (e) {}
      setRadiusUi(10);
      resetToBrowse();          // words, category, sort, results, remembered search
      updateLocationLabels();   // menu label, header glow
      renderPlacesStrip();
      const inp = document.querySelector('.search');
      inp.blur();
    }
    function syncSortOptions() {
      const sel = document.getElementById('sort-filter');
      const opt = document.getElementById('sort-opt-distance');
      const best = document.getElementById('sort-opt-best');
      const pt = isPointPlace();
      const hasQ = document.querySelector('.search').value.trim() !== '';
      opt.disabled = !pt; opt.hidden = !pt;
      best.disabled = !hasQ; best.hidden = !hasQ;
      // Typed words sort by Best match; otherwise nearest (point places) or A-Z.
      if (hasQ && !sortTouched) sel.value = 'best';
      else if (!hasQ && sel.value === 'best') sel.value = pt ? 'distance' : 'name';
      if (!pt && sel.value === 'distance') sel.value = hasQ ? 'best' : 'name';
      else if (pt && !hasQ && !sortTouched && sel.value === 'name') sel.value = 'distance';
      markActiveFilters();
    }

    let catsFirst = false; // "Just browsing? See categories first"
    function isRegionLike() { return !!(currentLocation.scope || isStateOnly(currentLocation)); }

    function renderWhere() {
      const set = hasLocationSet(currentLocation);
      const isDefault = currentLocation.source === 'default';
      document.getElementById('fl-where-text').textContent = (isDefault ? '\u2605 ' : '') + (set ? placeLabel() : 'Everywhere');
      const note = isDefault ? 'your default'
        : currentLocation.source === 'arrived' ? 'region you came from'
        : currentLocation.source === 'device' ? 'device guess' : '';
      document.getElementById('fl-where-note').textContent = (set && note) ? '\u00b7 ' + note : '';
      // Distance tools only mean something for a point (ZIP, town, GPS), not a region or a state.
      const isPoint = isPointPlace();
      syncSortOptions();
      document.getElementById('tools-point').classList.toggle('hidden', !isPoint);
      document.getElementById('tools-region').classList.toggle('hidden', isPoint);
      if (isPoint) setRadiusUi(currentLocation.radius || 10);
      // Toolbar icons: radius / nearby only when there is something to tune; the
      // pin gets a dot when a place is set; the x clears the place.
      const showTools = set || hasSearched;
      document.getElementById('tb-radius').classList.toggle('hidden', !showTools);
      document.getElementById('tb-map').classList.toggle('hidden', !showTools);
      document.getElementById('tb-place').classList.toggle('tv-glow', set);
      updateClearBtn();
      document.getElementById('tb-place').title = set ? 'Searching ' + placeLabel() + '. Change place' : 'Choose where to search';
      renderWiden();

      // Say how the search will run, right in the box.
      document.querySelector('.search').placeholder = set ? 'Search in ' + placeLabel() + '\u2026' : 'Click here to start your search experience, Let\u2019s Get Local!';

      // Browse view: where first (until a place is chosen), then what.
      const chosen = set || currentLocation.source === 'anywhere' || catsFirst;
      document.getElementById('funnel-where').classList.toggle('hidden', chosen);
      document.getElementById('funnel-what').classList.toggle('hidden', !chosen);
      document.getElementById('funnel-what-title').textContent = set ? 'What are you looking for in ' + placeLabel() + '?' : 'What are you looking for?';

      const stepNow = chosen ? 2 : 1;
      document.querySelectorAll('#funnel-steps li').forEach(li => {
        const on = Number(li.dataset.step) === stepNow;
        li.classList.toggle('border-[color:var(--tv-link)]', on); li.classList.toggle('ring-2', on); li.classList.toggle('ring-amber-500/40', on);
        li.classList.toggle('bg-[var(--tv-card-a)]', on); li.style.opacity = (Number(li.dataset.step) > stepNow && !on) ? '.7' : '1';
      });

      // Banner on the browse view (only once a place, or everywhere, was chosen).
      const hint = document.getElementById('funnel-place-hint');
      if (hint) {
        hint.textContent = '';
        if (!chosen) {
          hint.classList.add('hidden');
        } else {
          const b = (t, fn) => { const x = document.createElement('button'); x.type = 'button'; x.className = 'underline decoration-dotted font-semibold text-[color:var(--tv-link)] hover:text-[color:var(--tv-crimson)]'; x.textContent = t; x.addEventListener('click', fn); return x; };
          hint.appendChild(document.createTextNode('Searching '));
          if (set) {
            const strong = document.createElement('strong');
            strong.textContent = placeLabel();
            hint.appendChild(strong);
            if (note) hint.appendChild(document.createTextNode(' (' + note + ')'));
            hint.appendChild(document.createTextNode('. '));
            hint.appendChild(b('Change place', openLocationModal));
            hint.appendChild(document.createTextNode(' \u00b7 '));
            hint.appendChild(b('Search everywhere', chooseAnywhere));
          } else {
            hint.appendChild(document.createTextNode('everywhere. '));
            hint.appendChild(b('Pick a place to narrow it', openLocationModal));
          }
          hint.classList.remove('hidden');
        }
      }
      syncTopBarSpacer();
    }

    // "Wider" links: the ancestors of the current region, then Everywhere. This is
    // what keeps a place from becoming a trap: one tap always widens it.
    let currentTrail = [];
    function renderWiden() {
      const box = document.getElementById('fl-widen');
      box.textContent = '';
      const set = hasLocationSet(currentLocation);
      if (!set) { box.classList.add('hidden'); return; }
      const mk = (label, fn) => {
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'fl-link'; b.textContent = label;
        b.addEventListener('click', fn);
        return b;
      };
      const sep = () => { const s = document.createElement('span'); s.className = 'text-[color:var(--tv-on-umber-meta)]'; s.textContent = ' › '; return s; };
      box.appendChild(document.createTextNode(' · wider: '));
      const anc = currentLocation.scope ? currentTrail.slice().reverse() : [];
      anc.forEach((a, i) => {
        if (i) box.appendChild(sep());
        box.appendChild(mk(a.name, () => applyLocation({ scope: { level: a.level, slug: a.slug, label: a.name } }, 'picked')));
      });
      if (anc.length) box.appendChild(sep());
      box.appendChild(mk('Everywhere', chooseAnywhere));
      box.classList.remove('hidden');
    }

    // ---- Places strip: saved places + the next step down the hierarchy ------------
    const narrowCache = new Map();
    async function fetchNarrow(scope) {
      const key = scope ? scope.level + ':' + scope.slug : 'root';
      if (narrowCache.has(key)) return narrowCache.get(key);
      const qs = scope ? '&' + scopeParam(scope.level) + '=' + encodeURIComponent(scope.slug) : '';
      const r = await fetch('/api/place.php?action=narrow' + qs);
      const d = await r.json();
      if (!(d && d.success)) throw new Error('narrow failed');
      narrowCache.set(key, d);
      return d;
    }

    // Levels that offer only one choice are skipped (e.g. one live region with one
    // geo-hub goes straight to its clusters), so the chips are always a real choice.
    async function getNarrowView(scope) {
      let d = await fetchNarrow(scope);
      const trail = d.trail || [];
      let children = d.children || [];
      const via = [];
      let hops = 0;
      while (children.length === 1 && children[0].level !== 'cluster' && hops < 2) {
        via.push(children[0].name);
        d = await fetchNarrow({ level: children[0].level, slug: children[0].slug });
        children = d.children || [];
        hops++;
      }
      return { trail, children, via };
    }

    let lastTowns = []; // towns of the current state place (alphabetical), for the search dropdown
    let narrowToken = 0;
    let narrowExpanded = false;
    async function renderPlacesStrip() {
      const mine = ++narrowToken;
      const strip = document.getElementById('narrow-strip');
      const savedRow = document.getElementById('saved-row');
      const narrowRow = document.getElementById('narrow-row');

      const chip = (text, fn, extra) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'px-2.5 py-1 rounded-full border border-[color:var(--tv-line-strong)] bg-[var(--tv-card-b)] hover:bg-[var(--tv-card-b)] text-[color:var(--tv-ink)] transition ' + (extra || '');
        b.textContent = text;
        b.addEventListener('click', fn);
        return b;
      };
      const label = (t) => { const s = document.createElement('span'); s.className = 'text-[color:var(--tv-meta)] mr-0.5'; s.textContent = t; return s; };

      // Saved places (signed in)
      savedRow.textContent = '';
      const places = (realAuthActive && window.appSavedPlaces) ? window.appSavedPlaces : [];
      if (places.length) {
        savedRow.appendChild(label('Your places:'));
        places.forEach(p => savedRow.appendChild(chip((p.is_default ? '★ ' : '') + p.label, () => applyLocation({ ...p.location, savedLabel: p.label }, 'picked'))));
      }
      savedRow.classList.toggle('hidden', !places.length);

      // Next step down. Nothing to offer until a place is chosen (a first visit
      // asks "where?" on the page instead of showing region or ZIP jargon).
      let view = null;
      const stateOnly = isStateOnly(currentLocation);
      if (!stateOnly) lastTowns = [];
      if (currentLocation.scope) {
        try { view = await getNarrowView(currentLocation.scope); } catch (e) { view = null; }
      } else if (stateOnly) {
        // Towns in the state, alphabetical, with how many listings each has.
        try {
          const d = await (await fetch('/api/place.php?action=towns&state=' + encodeURIComponent(currentLocation.state))).json();
          if (d && d.success) lastTowns = d.towns || [];
          if (d && d.success) view = { trail: [], via: [], towns: true, children: (d.towns || []).map(t => ({ name: t.city, count: t.count, city: t.city })) };
        } catch (e) { view = null; }
      }
      if (mine !== narrowToken) return; // a newer render superseded this one
      currentTrail = view && view.trail ? view.trail : [];
      renderWiden();

      narrowRow.textContent = '';
      const usable = !!view && view.children.length > 0;
      if (usable) {
        narrowRow.appendChild(label(view.towns ? 'Towns:' : 'Narrow to:'));
        const LIMIT = view.towns ? 24 : 12;
        const list = narrowExpanded ? view.children : view.children.slice(0, LIMIT);
        list.forEach(c => narrowRow.appendChild(chip(c.name + ' (' + c.count.toLocaleString() + ')',
          view.towns
            ? () => applyLocation({ state: currentLocation.state, city: c.city, zip: '', lat: null, lon: null }, 'picked')
            : () => applyLocation({ scope: { level: c.level, slug: c.slug, label: c.name } }, 'picked'))));
        if (view.children.length > LIMIT) {
          const more = chip(narrowExpanded ? 'Show fewer' : '+' + (view.children.length - LIMIT) + ' more',
            () => { narrowExpanded = !narrowExpanded; renderPlacesStrip(); }, 'border-dashed bg-transparent');
          narrowRow.appendChild(more);
        }
      }
      narrowRow.classList.toggle('hidden', !usable);
      strip.classList.toggle('hidden', !(places.length || usable));
      syncTopBarSpacer();
    }

    // The shared location script calls this after any place change (picked in the
    // modal, a chip, a saved place, a device guess, "everywhere", a default).
    function onLocationChanged() {
      narrowExpanded = false;
      searchWide = false;
      hubsExpanded = false;
      if (toolsOpen() && isPointPlace()) fetchNearbyHubs();
      renderWhere();
      renderPlacesStrip();
      if (hasSearched) {
        launchSearch(document.querySelector('.search').value);
      } else if ((currentLocation.source === 'picked' || currentLocation.source === 'device') && !isStateOnly(currentLocation)) {
        // Choosing a ZIP, town or region is an explicit "show me what's here". A
        // default applied on load or an arrival region does not run a search by
        // itself, and a whole state shows its towns and categories first.
        launchSearch(document.querySelector('.search').value);
      }
    }

    document.addEventListener('DOMContentLoaded', async () => {
      syncTopBarSpacer();
      const searchInput = document.querySelector('.search');
      initSearchSuggest(searchInput);
      if (location.hash === '#search') searchInput.focus();

      // Category tiles on the browse view.
      document.getElementById('funnel-tiles')?.addEventListener('click', (e) => {
        const b = e.target.closest('button[data-cat]');
        if (b) pickCategory(b.dataset.cat);
      });

      // Typing: search after a short pause; Enter searches immediately.
      let debounceTimer = null;
      searchInput.addEventListener('input', (e) => {
        updateClearBtn();
        clearTimeout(debounceTimer);
        const query = e.target.value;
        debounceTimer = setTimeout(() => launchSearch(query), 700);
      });
      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { clearTimeout(debounceTimer); launchSearch(searchInput.value); }
      });

      document.getElementById('land-browse-cats')?.addEventListener('click', () => { catsFirst = true; renderWhere(); });
      loadLandingStates();
      renderWhere();

      // Wait for the session (saved places, default) before the first place decision.
      if (window.authReady) { try { await window.authReady; } catch (e) {} authSettled = true; }

      const arrived = currentLocation.source === 'arrived' && hasLocationSet(currentLocation);
      // Arriving from the search panel's "See all" (decisions/0053): ?q= and ?cat=, alongside ?cluster= / ?geo= / ?hub=
      // (location-scope.js has already made that the place).
      const arrive = new URLSearchParams(location.search);
      if (arrive.has('q') || arrive.has('cat')) {
        // "See all" from a distance search: a point and a radius, named for the place it was measured from
        const aLat = parseFloat(arrive.get('lat')), aLon = parseFloat(arrive.get('lon')), aRad = parseInt(arrive.get('radius'), 10);
        if (isFinite(aLat) && isFinite(aLon) && Math.abs(aLat) <= 90 && Math.abs(aLon) <= 180) {
          currentLocation = { state: 'all', city: '', zip: '', lat: aLat, lon: aLon, radius: Math.max(1, Math.min(250, aRad || 10)), scope: null,
                              savedLabel: (arrive.get('near') || 'the place you searched').slice(0, 80), source: 'arrived' };
          if (typeof updateLocationLabels === 'function') updateLocationLabels();
        }
        searchInput.value = (arrive.get('q') || '').slice(0, 60);
        const cs = document.getElementById('category-filter'), cat = (arrive.get('cat') || '').slice(0, 120);
        if (cat && /^[a-z0-9-]+$/.test(cat)) {
          cs.value = cat;
          if (cs.value !== cat) {   // a specific category (e.g. Restaurants): a temporary option, as pickCategory() does
            const o = document.createElement('option');
            o.value = cat; o.dataset.dyn = '1';
            o.dataset.name = o.textContent = (arrive.get('catname') || cat.replace(/-/g, ' ')).slice(0, 80);
            cs.appendChild(o); cs.value = cat;
          }
          markActiveFilters();
        }
        await launchSearch(searchInput.value);
      } else if (arrived) {
        // A Local/region link: show what's there straight away.
        launchSearch('');
      } else {
        // A search is only brought back when they come back with the Back button. Any
        // other visit to the directory (a menu link, a typed address, a reload from
        // another page) starts fresh, so an old search never surprises them.
        let cameBack = false;
        try { const nv = performance.getEntriesByType('navigation')[0]; cameBack = !!nv && nv.type === 'back_forward'; } catch (e) {}
        if (!cameBack) clearSavedSearchState();
        const saved = loadSavedSearchState();
        if (saved && saved.active) {
          searchInput.value = saved.query || '';
          document.getElementById('category-filter').value = saved.category || 'all';
          if (!document.getElementById('category-filter').value) document.getElementById('category-filter').value = 'all';
          document.getElementById('sort-filter').value = saved.sort || 'name';
          if (saved.xf) { Object.assign(xf, saved.xf); paintFilters(); }
          await launchSearch(saved.query || '');
          if (saved.view === 'map' && hasSearched) setViewMode('map');
        } else {
          applyDefaultPlaceIfAny(); // signed-in direct visit: start from their default
        }
      }
      renderWhere();
      renderPlacesStrip();
    });


    // ---- Search type-ahead ------------------------------------------------
    // What the dropdown shows:
    //   * Empty box, on focus: quick picks (your saved places, near me, everywhere)
    //     and popular categories, so a first-time visitor has somewhere to start.
    //   * Two or more letters: categories, towns and business names that match
    //     (api/suggest.php). With a place set they are matches IN that place, and
    //     the list says so and ends with "search everywhere" so it never traps.
    //   * Picking a category sets the Category filter; a town sets the place; a
    //     business name is a named lookup and searches everywhere.
    // Keyboard: Up/Down to move, Enter to pick, Esc to close.
    let searchWide = false; // true while a business-name lookup ignores the place

    function initSearchSuggest(input) {
      const list = document.getElementById('suggest-list');
      const MIN_CHARS = 2;
      const cache = new Map();
      let rows = [];      // {kind:'header'|'item', ...}
      let active = -1;    // index into rows (items only)
      let timer = null;
      let token = 0;

      const itemIdx = () => rows.map((r, i) => r.kind === 'item' ? i : -1).filter(i => i >= 0);
      function isOpen() { return !list.classList.contains('hidden'); }

      function close() {
        list.classList.add('hidden');
        input.setAttribute('aria-expanded', 'false');
        input.removeAttribute('aria-activedescendant');
        active = -1;
      }

      function setActive(i) {
        active = i;
        [...list.children].forEach((li, idx) => {
          const on = idx === i;
          li.classList.toggle('bg-[var(--tv-card-b)]', on);
          if (li.getAttribute('role') === 'option') li.setAttribute('aria-selected', String(on));
        });
        if (i >= 0) {
          input.setAttribute('aria-activedescendant', 'suggest-opt-' + i);
          list.children[i].scrollIntoView({ block: 'nearest' });
        } else {
          input.removeAttribute('aria-activedescendant');
        }
      }

      function highlight(label, q) {
        if (!q) return escapeHtml(label);
        const at = label.toLowerCase().indexOf(q.toLowerCase());
        if (at < 0) return escapeHtml(label);
        return escapeHtml(label.slice(0, at))
          + '<strong class="text-[color:var(--tv-link)]">' + escapeHtml(label.slice(at, at + q.length)) + '</strong>'
          + escapeHtml(label.slice(at + q.length));
      }

      const TAGS = { category: 'Category', city: 'Town', business: '', place: 'Your place', near: 'Device', everywhere: 'Place', wide: '' };

      function render(q) {
        if (!rows.length) { close(); return; }
        list.innerHTML = rows.map((r, i) => {
          if (r.kind === 'header') {
            return `<li role="presentation" class="px-4 pt-2 pb-1 text-[10px] uppercase tracking-widest text-[color:var(--tv-meta)] select-none font-semibold">${escapeHtml(r.text)}</li>`;
          }
          let tag;
          if (r.type === 'city') tag = 'Town' + (r.sub ? ', ' + r.sub : '') + (r.listings === 0 ? ' \u00b7 none yet' : (r.listings ? ' \u00b7 ' + r.listings : ''));
          else if (r.type === 'business') tag = r.sub || 'Business';
          else tag = r.sub || TAGS[r.type] || '';
          if (r.type === 'state') tag = 'State';
          const hot = (r.type === 'business') ? 'text-[color:var(--tv-meta)]' : ((r.type === 'city' && r.listings === 0) || r.soon ? 'text-[color:var(--tv-meta)]' : 'text-[color:var(--tv-link)]');
          return `<li id="suggest-opt-${i}" role="option" aria-selected="false" data-i="${i}" class="flex items-center justify-between gap-3 px-4 py-2 cursor-pointer text-sm text-[color:var(--tv-ink)] hover:bg-[var(--tv-card-b)]">
            <span class="truncate">${r.plain ? escapeHtml(r.label) : highlight(r.label, q)}</span>
            <span class="shrink-0 text-[10px] uppercase tracking-wide ${hot}">${escapeHtml(tag)}</span>
          </li>`;
        }).join('');
        list.classList.remove('hidden');
        input.setAttribute('aria-expanded', 'true');
        active = -1;
      }

      // Rows shown before anything is typed.
      // The empty box walks the visitor through it: where, then what, then narrowing.
      // Each row is an answer; picking one moves to the next question.
      function starterRows() {
        const out = [];
        const set = hasLocationSet(currentLocation);
        const anywhere = currentLocation.source === 'anywhere' || catsFirst;
        const places = (realAuthActive && window.appSavedPlaces) ? window.appSavedPlaces : [];
        if (!set && !anywhere) {
          out.push({ kind: 'header', text: 'Step 1 of 3 \u00b7 Where are you looking?' });
          places.forEach(p => out.push({ kind: 'item', type: 'place', label: (p.is_default ? '\u2605 ' : '') + p.label, plain: true, sub: 'Your place', place: p }));
          out.push({ kind: 'item', type: 'near', label: 'Near me right now', plain: true, sub: 'Use my location' });
          out.push({ kind: 'item', type: 'zipprompt', label: 'I have a ZIP code', plain: true, sub: 'Enter ZIP' });
          out.push({ kind: 'item', type: 'stateprompt', label: 'I know my state', plain: true, sub: 'Pick a state' });
          out.push({ kind: 'item', type: 'catsfirst', label: 'Not sure yet, show me what is listed', plain: true, sub: 'Categories' });
          return out;
        }
        out.push({ kind: 'header', text: 'Step 2 of 3 \u00b7 What do you need' + (set ? ' in ' + placeLabel() : '') + '?' });
        const cats = [...document.querySelectorAll('#category-filter option')].filter(o => o.value !== 'all' && !o.dataset.dyn).slice(0, 8);
        cats.forEach(o => out.push({ kind: 'item', type: 'category', label: (o.dataset.name || o.text), slug: o.value, plain: true, sub: 'Category' }));
        out.push({ kind: 'item', type: 'hint', label: 'Or type a business name or a word above', plain: true, sub: '' });
        if (isStateOnly(currentLocation) && lastTowns.length) {
          out.push({ kind: 'header', text: 'Or narrow to a town in ' + placeLabel() });
          lastTowns.slice(0, 8).forEach(t => out.push({ kind: 'item', type: 'city', label: t.city, sub: currentLocation.state, listings: t.count }));
        }
        out.push({ kind: 'header', text: 'Change the area' });
        places.forEach(p => out.push({ kind: 'item', type: 'place', label: (p.is_default ? '\u2605 ' : '') + p.label, plain: true, sub: 'Your place', place: p }));
        out.push({ kind: 'item', type: 'near', label: 'Near me right now', plain: true, sub: 'Use my location' });
        if (set) out.push({ kind: 'item', type: 'everywhere', label: 'Search everywhere', plain: true, sub: 'No place' });
        return out;
      }

      function showStarter() {
        rows = starterRows();
        render('');
      }

      function pick(i) {
        const it = rows[i];
        if (!it || it.kind !== 'item') return;
        close();
        if (it.type === 'category') {
          input.value = '';
          searchWide = false;
          pickCategory(it.slug, it.label);
        } else if (it.type === 'dym') {
          input.value = it.label;
          searchWide = false;
          launchSearch(it.label);
        } else if (it.type === 'city') {
          input.value = '';
          applyLocation({ state: it.sub || 'all', city: it.label, zip: '', lat: null, lon: null }, 'picked');
        } else if (it.type === 'region') {
          input.value = '';
          applyLocation({ scope: { level: it.level, slug: it.slug, label: it.label, soon: !!it.soon } }, 'picked');
        } else if (it.type === 'place') {
          input.value = '';
          applyLocation({ ...it.place.location, savedLabel: it.place.label }, 'picked');
        } else if (it.type === 'state') {
          input.value = '';
          applyLocation({ state: it.code, city: '', zip: '', lat: null, lon: null }, 'picked');
        } else if (it.type === 'zipprompt' || it.type === 'stateprompt') {
          input.value = '';
          const land = document.getElementById(it.type === 'zipprompt' ? 'land-zip' : 'funnel-states');
          if (land && !hasSearched && land.offsetParent !== null) { (it.type === 'zipprompt' ? land : land.querySelector('button,select'))?.focus(); }
          else openLocationModal();
        } else if (it.type === 'placeprompt') {
          openLocationModal();
        } else if (it.type === 'catsfirst') {
          input.value = ''; catsFirst = true; renderWhere();
        } else if (it.type === 'hint') {
          input.focus();
        } else if (it.type === 'near') {
          openLocationModal();
        } else if (it.type === 'everywhere') {
          chooseAnywhere();
        } else if (it.type === 'wide') {
          // "Search everywhere for <words>": drop the place, keep the words.
          const words = input.value;
          chooseAnywhere();
          input.value = words;
          launchSearch(words);
        } else {
          // Business name: a named lookup, so it ignores the place.
          input.value = it.label;
          searchWide = true;
          launchSearch(it.label);
        }
      }

      function load(q) {
        const loc = (typeof currentLocation !== 'undefined' && currentLocation) ? currentLocation : {};
        const params = new URLSearchParams({ q });
        if (loc.scope) { params.set(scopeParam(loc.scope.level), loc.scope.slug); }
        else if (loc.lat != null && loc.lon != null) { params.set('lat', loc.lat); params.set('lon', loc.lon); }
        else if (loc.zip) { params.set('zip', loc.zip); }
        else if (isStateOnly(loc)) { params.set('state', loc.state); }
        params.set('radius', loc.radius || 10);
        const url = '/api/suggest.php?' + params.toString();
        const build = (sugs, dym) => {
          const out = [];
          const placeSet = hasLocationSet(currentLocation);
          const scoped = placeSet;
          const by = t => sugs.filter(s => s.type === t);
          const regions = by('region'), towns = by('city'), cats = by('category'), biz = by('business');
          // States match on the client ("az", "ariz"): a whole state is a place too.
          const ql = q.toLowerCase();
          const states = Object.keys(STATE_NAMES)
            .filter(c => (ql.length === 2 && c.toLowerCase() === ql) || (ql.length >= 2 && STATE_NAMES[c].toLowerCase().startsWith(ql)))
            .sort((a, b) => STATE_NAMES[a].localeCompare(STATE_NAMES[b])).slice(0, 4)
            .map(c => ({ type: 'state', code: c, label: STATE_NAMES[c], sub: 'State', plain: false }));
          // Places come first and are never limited to the current place, or to
          // towns that already have listings: an empty town is a chance to add one.
          // Once a place is chosen the box is about listings (categories and businesses in that place);
          // places only come back through the pin icon or the last row.
          if (!scoped && !isStateOnly(currentLocation) && (regions.length || towns.length || states.length)) {
            out.push({ kind: 'header', text: 'Places' });
            states.forEach(s => out.push({ kind: 'item', ...s }));
            regions.forEach(s => out.push({ kind: 'item', ...s }));
            towns.forEach(s => out.push({ kind: 'item', ...s }));
          }
          if (cats.length) { out.push({ kind: 'header', text: scoped ? 'Categories in ' + placeLabel() : 'Categories' }); cats.forEach(s => out.push({ kind: 'item', ...s, sub: s.count != null ? s.count.toLocaleString() + (s.count === 1 ? ' listing' : ' listings') : '' })); }
          if (biz.length) { out.push({ kind: 'header', text: scoped ? 'Businesses in ' + placeLabel() : 'Businesses' }); biz.forEach(s => out.push({ kind: 'item', ...s })); }
          if (!cats.length && !biz.length && (scoped || !(regions.length || towns.length || states.length))) out.push({ kind: 'header', text: 'Nothing matches \u201c' + q + '\u201d' + (scoped ? ' in ' + placeLabel() : '') });
          if (dym && !cats.length && !biz.length) out.push({ kind: 'item', type: 'dym', label: dym, plain: true, sub: 'Did you mean?' });
          if (scoped) {
            out.push({ kind: 'item', type: 'wide', label: 'Search everywhere for \u201c' + q + '\u201d', plain: true, sub: 'No place' });
            out.push({ kind: 'item', type: 'placeprompt', label: 'Change the area\u2026', plain: true, sub: 'Place' });
          }
          return out;
        };
        if (cache.has(url)) { const c = cache.get(url); rows = build(c.sugs, c.dym); render(q); return; }
        const mine = ++token;
        fetch(url, { credentials: 'same-origin' })
          .then(r => r.json())
          .then(data => {
            if (mine !== token || input.value.trim() !== q) return; // stale
            const sugs = (data && data.success && Array.isArray(data.suggestions)) ? data.suggestions : [];
            const dym = (data && data.did_you_mean) || null;
            cache.set(url, { sugs, dym });
            rows = build(sugs, dym);
            render(q);
          })
          .catch(() => { if (mine === token) close(); }); // suggestions are optional; fail quietly
      }

      input.addEventListener('input', () => {
        clearTimeout(timer);
        searchWide = false; // typing again is a normal, placed search
        const q = input.value.trim();
        if (q.length === 0) { token++; showStarter(); return; }
        if (q.length < MIN_CHARS) { token++; close(); return; }
        timer = setTimeout(() => load(q), 200);
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { if (isOpen()) { close(); e.stopPropagation(); } return; }
        if (!isOpen()) return;
        const idx = itemIdx();
        const pos = idx.indexOf(active);
        if (e.key === 'ArrowDown') { e.preventDefault(); setActive(idx[(pos + 1) % idx.length]); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(idx[pos <= 0 ? idx.length - 1 : pos - 1]); }
        else if (e.key === 'Enter' && active >= 0) {
          e.preventDefault();
          e.stopImmediatePropagation(); // don't also run the plain-Enter search below
          pick(active);
        } else if (e.key === 'Enter' || e.key === 'Tab') {
          close(); // plain Enter proceeds to the normal search
        }
      });

      // mousedown (not click) so the input keeps focus and blur can't close the list first.
      list.addEventListener('mousedown', (e) => {
        e.preventDefault();
        const li = e.target.closest('li[data-i]');
        if (li) pick(Number(li.dataset.i));
      });
      input.addEventListener('blur', () => setTimeout(close, 120));
      input.addEventListener('focus', () => {
        const q = input.value.trim();
        if (q.length === 0) showStarter();
        else if (rows.length && q.length >= MIN_CHARS) render(q);
      });
    }

    // ---- Radius & nearby places (for ZIP / town / GPS places) ------------------
    // The thin line shows a "Radius" link for those places; it opens a small panel
    // with the distance slider and the towns within that distance.
    let hubsExpanded = false;
    let lastRenderedHubs = [];
    let hubsFetchToken = 0;
    let radiusTimer = null;

    let toolsMode = null; // 'radius' | 'towns' | null (closed)
    function toolsOpen() { return !document.getElementById('tools-panel').classList.contains('hidden'); }

    // The gear opens the radius slider, the share icon the towns in range. For a
    // state or region (no centre point) both open the ZIP box instead.
    function toggleToolsPanel(mode) {
      const panel = document.getElementById('tools-panel');
      const open = (mode === false) ? false : !(toolsOpen() && toolsMode === mode);
      toolsMode = open ? (mode || 'both') : null;
      panel.classList.toggle('hidden', !open);
      document.getElementById('tb-radius').setAttribute('aria-expanded', String(open));
      if (open && isPointPlace()) fetchNearbyHubs();
      syncTopBarSpacer();
    }

    function isPointPlace() { return hasLocationSet(currentLocation) && !currentLocation.scope && !isStateOnly(currentLocation); }

    // ZIP boxes (landing + tools panel). Sets a ZIP place, which searches right away.
    async function goZip(e, inputId, msgId) {
      e.preventDefault();
      const msg = document.getElementById(msgId || 'tools-zip-msg');
      const zip = document.getElementById(inputId || 'tools-zip').value.trim();
      msg.textContent = '';
      if (!/^\d{5}$/.test(zip)) { msg.textContent = 'Enter a 5-digit ZIP.'; return false; }
      try {
        const r = await fetch('/api/place.php?zip=' + encodeURIComponent(zip));
        const d = await r.json();
        if (!(d && d.success && d.place)) { msg.textContent = 'We could not find that ZIP.'; return false; }
        const pl = d.place;
        applyLocation({ state: pl.state || 'all', city: pl.city || '', zip: pl.zip || zip, lat: null, lon: null }, 'picked');
      } catch (err) { msg.textContent = 'Lookup failed. Try again.'; }
      return false;
    }

    // "Use my location" on the landing: the visitor asked for it, so apply it.
    function useMyLocation(btn) {
      const msg = document.getElementById('land-zip-msg');
      msg.textContent = '';
      if (!navigator.geolocation) { msg.textContent = 'Your browser cannot share a location. Pick a state or enter a ZIP.'; return; }
      const idle = btn.textContent;
      btn.textContent = 'Locating\u2026';
      navigator.geolocation.getCurrentPosition(async (pos) => {
        try {
          const q = new URLSearchParams({ lat: pos.coords.latitude, lon: pos.coords.longitude });
          if (Number.isFinite(pos.coords.accuracy)) q.set('accuracy', Math.round(pos.coords.accuracy));
          const d = await (await fetch('/api/place.php?' + q.toString())).json();
          if (!(d && d.success && d.place)) throw new Error('lookup failed');
          const pl = d.place;
          applyLocation({ state: pl.state || 'all', city: pl.city || '', zip: pl.zip || '',
            lat: pl.approximate ? null : pos.coords.latitude, lon: pl.approximate ? null : pos.coords.longitude }, 'device');
        } catch (e) { msg.textContent = 'We could not name your area. Pick a state or enter a ZIP.'; }
        btn.textContent = idle;
      }, () => {
        btn.textContent = idle;
        msg.textContent = 'Location was not shared. Pick a state or enter a ZIP.';
      }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
    }

    // State chips on the landing (states that have listings) plus a picker for any other.
    async function loadLandingStates() {
      const box = document.getElementById('funnel-states');
      try {
        const d = await (await fetch('/api/place.php?action=states')).json();
        const codes = (d && d.success ? d.states : []).map(x => x.code).filter(c => STATE_NAMES[c]);
        box.textContent = '';
        const goState = (code) => applyLocation({ state: code, city: '', zip: '', lat: null, lon: null }, 'picked');
        codes.sort((a, b) => STATE_NAMES[a].localeCompare(STATE_NAMES[b])).forEach(code => {
          const b = document.createElement('button');
          b.type = 'button';
          b.className = 'text-sm px-4 py-2 rounded-full border border-[color:var(--tv-line-strong)] bg-[var(--tv-card-b)] hover:bg-[var(--tv-card-b)] hover:border-amber-600/60 text-[color:var(--tv-ink)] transition';
          b.textContent = STATE_NAMES[code];
          b.addEventListener('click', () => goState(code));
          box.appendChild(b);
        });
        const sel = document.createElement('select');
        sel.setAttribute('aria-label', 'Any other state');
        sel.className = 'text-sm px-3 py-2 rounded-full border border-dashed border-[color:var(--tv-line-strong)] bg-transparent text-[color:var(--tv-meta)]';
        sel.appendChild(new Option(codes.length ? 'Another state\u2026' : 'Choose a state\u2026', ''));
        Object.keys(STATE_NAMES).sort((a, b) => STATE_NAMES[a].localeCompare(STATE_NAMES[b])).forEach(c => sel.appendChild(new Option(STATE_NAMES[c], c)));
        sel.addEventListener('change', () => { if (sel.value) goState(sel.value); });
        box.appendChild(sel);
      } catch (e) {
        box.textContent = '';
        const t = document.createElement('span'); t.className = 'text-xs text-[color:var(--tv-meta)]'; t.textContent = 'States are unavailable right now. Enter a ZIP or use the search box.';
        box.appendChild(t);
      }
    }

    // Slider moves: update the readout live, search once it settles.
    function previewRadius(v) {
      document.getElementById('radius-val').textContent = v;
      currentLocation.radius = parseInt(v, 10) || 10;
      renderWhere();
      clearTimeout(radiusTimer);
      radiusTimer = setTimeout(() => commitRadius(v), 350);
    }
    function commitRadius(v) {
      currentLocation.radius = parseInt(v, 10) || 10;
      saveCurrentLocation();
      updateLocationLabels();
      if (toolsOpen()) fetchNearbyHubs();
      if (hasSearched) launchSearch(document.querySelector('.search').value);
    }
    function expandRadiusToTier(miles) {
      setRadiusUi(miles);
      commitRadius(miles);
    }

    // Pulls only the towns inside the current centre + radius (api/nearby_hubs.php).
    function fetchNearbyHubs() {
      const container = document.getElementById('regional-hubs-container');
      const thisFetch = ++hubsFetchToken;
      const coordParams = (currentLocation.lat != null && currentLocation.lon != null)
        ? `&lat=${encodeURIComponent(currentLocation.lat)}&lon=${encodeURIComponent(currentLocation.lon)}` : '';
      const url = `/api/nearby_hubs.php?state=${encodeURIComponent(currentLocation.state || 'all')}&city=${encodeURIComponent(currentLocation.city || 'all')}&zip=${encodeURIComponent(currentLocation.zip || '')}&radius=${encodeURIComponent(currentLocation.radius || 10)}${coordParams}`;
      container.innerHTML = '<span class="text-[color:var(--tv-meta)]">Loading nearby places&hellip;</span>';
      fetch(url)
        .then(r => r.json())
        .then(data => {
          if (thisFetch !== hubsFetchToken) return;
          if (data.success) renderProximityHubs(data.hubs || []);
          else container.innerHTML = '<span class="text-[color:var(--tv-meta)]">No places found in range.</span>';
        })
        .catch(() => {
          if (thisFetch === hubsFetchToken) container.innerHTML = '<span class="text-[color:var(--tv-meta)]">Unable to load places right now.</span>';
        });
    }

    function renderProximityHubs(hubs) {
      const container = document.getElementById('regional-hubs-container');
      const activeCity = (currentLocation.city && currentLocation.city !== 'all') ? currentLocation.city : '';
      if (!hubs.length) { container.innerHTML = '<span class="text-[color:var(--tv-meta)]">No places found within this radius.</span>'; syncTopBarSpacer(); return; }
      // SECURITY: city/state come from the database and are rendered as text. They
      // are never put into an inline onclick attribute: pass them via data-* and
      // read them in a real listener (an escaped quote would become live JS again).
      container.textContent = '';
      const limit = hubsExpanded ? hubs.length : Math.min(8, hubs.length);
      hubs.slice(0, limit).forEach((reg) => {
        const on = activeCity.toLowerCase() === String(reg.city).toLowerCase();
        const b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('aria-pressed', String(on));
        b.className = 'px-2.5 py-0.5 rounded-full border transition ' + (on
          ? 'bg-amber-600/20 text-[color:var(--tv-sage)] border-amber-500/50 font-semibold'
          : 'bg-[var(--tv-void)] hover:bg-[var(--tv-umber-line)] text-[color:var(--tv-on-umber-meta)] border-[color:var(--tv-umber-line)]');
        b.textContent = reg.city + ', ' + reg.state;
        b.addEventListener('click', () => switchRegion(reg.city, reg.state));
        container.appendChild(b);
      });
      if (hubs.length > 8) {
        const t = document.createElement('button');
        t.type = 'button';
        t.className = 'px-2.5 py-0.5 rounded-full border border-dashed border-[color:var(--tv-umber-line)] text-[color:var(--tv-sage)] hover:bg-[var(--tv-umber-line)] transition';
        t.textContent = hubsExpanded ? 'Show fewer' : '+' + (hubs.length - 8) + ' more';
        t.addEventListener('click', () => { hubsExpanded = !hubsExpanded; renderProximityHubs(hubs); });
        container.appendChild(t);
      }
      lastRenderedHubs = hubs;
      syncTopBarSpacer();
    }

    // Picking a nearby town re-centres the search there (radius resets to 10).
    function switchRegion(cityName, stateAbbr) {
      applyLocation({ state: stateAbbr || 'all', city: cityName, zip: '', lat: null, lon: null }, 'picked');
    }

    // Query-string key for each region level (matches api/lib/PlaceScope.php).
    function scopeParam(level) {
      return level === 'cluster' ? 'cluster' : level === 'geo_hub' ? 'geo' : 'hub';
    }

    // The search as a query string (shared by the cards and the map pins).
    function searchQS(query, loc) {
      // A region scope (hub / geo-hub / cluster) replaces distance search; the
      // server enforces it (api/lib/PlaceScope.php), the browser only names it.
      // A business-name lookup ignores the place entirely (searchWide).
      if (searchWide) loc = { state: 'all', city: '', zip: '', lat: null, lon: null, radius: 10, scope: null };
      const scopeParams = loc.scope ? `&${scopeParam(loc.scope.level)}=${encodeURIComponent(loc.scope.slug)}` : '';
      const coordParams = (!loc.scope && loc.lat != null && loc.lon != null)
        ? `&lat=${encodeURIComponent(loc.lat)}&lon=${encodeURIComponent(loc.lon)}`
        : '';
      // A business-name lookup ignores the category as well as the place.
      const category = searchWide ? 'all' : (xf.cats.length ? xf.cats.join(',') : document.getElementById('category-filter').value);
      let sort = document.getElementById('sort-filter').value;
      if (sort === 'best' && !(query || '').trim()) sort = '';
      return `q=${encodeURIComponent(query)}&state=${encodeURIComponent(loc.state || 'all')}&city=${encodeURIComponent(loc.city || 'all')}&zip=${encodeURIComponent(loc.zip || '')}&radius=${encodeURIComponent(loc.radius || 10)}&category=${encodeURIComponent(category)}&sort=${encodeURIComponent(sort)}${coordParams}${scopeParams}${searchWide ? '' : extraQS()}`;
    }

    function fetchListings(query, loc, page = 1) {
      // Persist the in-progress search so a round trip to the dashboard restores it.
      if (hasSearched) saveSearchState();

      const url = `/api/search_listings.php?${searchQS(query, loc)}&page=${encodeURIComponent(page)}&per_page=${itemsPerPage}${page === 1 ? '&facets=1' : ''}`;
      if (viewMode === 'map' && page === 1) fetchPins(query, loc);

      const thisFetch = ++listingsFetchToken;
      fetch(url)
        .then(async response => {
          const text = await response.text();
          let data;
          try { data = JSON.parse(text); }
          catch (e) { throw new Error('HTTP ' + response.status + ', not JSON: ' + text.replace(/\s+/g, ' ').slice(0, 140)); }
          if (!response.ok || !data.success) throw new Error('HTTP ' + response.status + ': ' + (data.error || 'search failed'));
          return data;
        })
        .then(data => {
          if (thisFetch !== listingsFetchToken) return; // a newer search already superseded this one
          if (data && data.needs_filter) { resetToBrowse(); return; }
          if (!(data.success && data.listings)) throw new Error(data.error || 'Search failed');
          allListings = data.listings;
          totalListings = data.total;
          didYouMean = data.did_you_mean || null;
          if (data.facets) applyFacets(data.facets);
          currentPage = data.page;
          renderListings();
        })
        .catch(error => {
          console.error('Error fetching listings:', error);
          if (thisFetch !== listingsFetchToken) return;
          document.getElementById('results-count').textContent = 'Search unavailable';
          document.getElementById('results-summary').textContent = '';
          document.getElementById('pagination-container').classList.add('hidden');
          document.getElementById('widen-hint').classList.add('hidden');
          document.querySelector('.list').innerHTML = `
            <li class="col-span-full text-center py-16 px-4 bg-[color-mix(in_srgb,var(--tv-card-b)_60%,transparent)] border border-[color:var(--tv-line-strong)] rounded-xl">
              <h3 class="text-[color:var(--tv-ink)] font-serif font-bold text-lg mb-1">We couldn't load results</h3>
              <p class="text-[color:var(--tv-meta)] text-xs max-w-md mx-auto mb-2 leading-relaxed">Something went wrong reaching the directory. Please try again.</p>
              <p class="text-[color:var(--tv-meta)] text-[11px] max-w-md mx-auto mb-6 font-mono break-words">${escapeHtml(String(error && error.message || error))}</p>
              <button onclick="fetchListings(document.querySelector('.search').value, currentLocation, currentPage)" class="bg-[var(--tv-link)] hover:bg-[var(--tv-crimson)] text-white font-medium text-xs px-4 py-2 rounded-lg transition shadow-sm">Try Again</button>
            </li>`;
        });
    }


    // ---- Map view ---------------------------------------------------------------
    // Cards or map for the same search. The map (Leaflet + OpenStreetMap tiles) loads
    // only when first asked for. Pins come from api/search_listings.php?view=map and
    // are clustered; a radius search also draws its circle.
    let viewMode = 'cards', mapObj = null, mapCluster = null, mapCircle = null, mapToken = 0, leafletPromise = null;

    function loadAsset(tag, attrs) {
      return new Promise((resolve, reject) => {
        const el = document.createElement(tag);
        Object.assign(el, attrs);
        el.onload = resolve; el.onerror = () => reject(new Error('Could not load ' + (attrs.src || attrs.href)));
        document.head.appendChild(el);
      });
    }
    function loadLeaflet() {
      if (window.L && window.L.markerClusterGroup) return Promise.resolve();
      if (leafletPromise) return leafletPromise;
      const cdn = 'https://cdnjs.cloudflare.com/ajax/libs/';
      leafletPromise = Promise.all([
        loadAsset('link', { rel: 'stylesheet', href: cdn + 'leaflet/1.9.4/leaflet.min.css' }),
        loadAsset('link', { rel: 'stylesheet', href: cdn + 'leaflet.markercluster/1.5.3/MarkerCluster.css' }),
        loadAsset('link', { rel: 'stylesheet', href: cdn + 'leaflet.markercluster/1.5.3/MarkerCluster.Default.css' }),
      ]).then(() => loadAsset('script', { src: cdn + 'leaflet/1.9.4/leaflet.min.js' }))
        .then(() => loadAsset('script', { src: cdn + 'leaflet.markercluster/1.5.3/leaflet.markercluster.js' }))
        .catch(e => { leafletPromise = null; throw e; });
      return leafletPromise;
    }
    async function ensureMap() {
      await loadLeaflet();
      if (mapObj) return;
      mapObj = L.map('map', { scrollWheelZoom: true }).setView([39.5, -98.35], 4);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors', referrerPolicy: 'strict-origin-when-cross-origin',
      }).addTo(mapObj);
      mapCluster = L.markerClusterGroup({ showCoverageOnHover: false, maxClusterRadius: 45 });
      mapObj.addLayer(mapCluster);
    }

    function setViewMode(mode) {
      viewMode = mode;
      document.getElementById('results-layout').classList.toggle('map-mode', mode === 'map');
      const b = document.getElementById('tb-map');
      b.classList.toggle('tv-glow', mode === 'map');
      b.setAttribute('aria-pressed', String(mode === 'map'));
      b.title = mode === 'map' ? 'Back to cards only' : 'Show results on a map';
      syncTopBarSpacer();
      if (hasSearched) saveSearchState();
      if (mode === 'map') openFullMap();
    }
    // The map is full screen under the bar (decisions/0053 §4b): the bar's search, category, sort and Filters stay on top
    // and still apply; the map adds distance, "Search this area" and a card per pin. List (or Back) returns here.
    function openFullMap() {
      if (!window.TvMap) { setMapNote('The map is still loading; try again in a moment.'); return; }
      const q = document.querySelector('.search').value;
      TvMap.open({
        title: totalListings.toLocaleString() + (totalListings === 1 ? ' listing' : ' listings') + (hasLocationSet(currentLocation) ? ' · ' + placeLabel() : ''),
        radius: isPointPlace() ? (currentLocation.radius || 10) : null,
        load: (area) => {
          const loc = area ? { state: 'all', city: '', zip: '', lat: area.lat, lon: area.lon, radius: area.radius, scope: null } : currentLocation;
          return fetch('/api/search_listings.php?' + searchQS(document.querySelector('.search').value, loc) + '&view=map')
            .then(r => r.json().then(d => { if (!(r.ok && d.success)) throw new Error(d.error || ('HTTP ' + r.status)); return d; }));
        },
        titleFor: (d) => { const n = d.total != null ? d.total : (d.pins || []).length; const c = document.getElementById('category-filter');
          const cn = c && c.value !== 'all' && c.selectedOptions[0] ? (c.selectedOptions[0].dataset.name || c.selectedOptions[0].textContent).trim() : '';
          return n.toLocaleString() + (n === 1 ? ' listing' : ' listings') + (cn ? ' · ' + cn : '') + (hasLocationSet(currentLocation) ? ' · ' + placeLabel() : ''); },
        onCategory: (slug, name) => { const si = document.querySelector('.search'); si.value = ''; if (typeof updateClearBtn === 'function') updateClearBtn(); pickCategory(slug, name); },   // the card's category: everything like it here, in one tap (the words give way to it)
        onList: () => { viewMode = 'cards'; const b = document.getElementById('tb-map'); b.classList.remove('tv-glow'); b.setAttribute('aria-pressed', 'false'); b.title = 'Show results on a map'; if (hasSearched) saveSearchState(); },
      });
    }
    async function toggleMapView() {
      if (viewMode === 'map') { setViewMode('cards'); return; }
      if (!hasSearched) { await launchSearch(document.querySelector('.search').value); if (!hasSearched) return; }
      setViewMode('map');
    }
    function setMapNote(t) { const n = document.getElementById('map-note'); if (n) n.textContent = t; }

    function pinPopup(p) {
      const box = document.createElement('div');
      box.style.minWidth = '150px';
      const h = document.createElement('strong'); h.textContent = p.name; box.appendChild(h);
      const sub = document.createElement('div'); sub.style.fontSize = '12px';
      sub.textContent = [p.category, [p.city, p.state].filter(Boolean).join(', ')].filter(Boolean).join(' \u00b7 ');
      box.appendChild(sub);
      if (p.phone) { const a = document.createElement('a'); a.href = 'tel:' + p.phone; a.textContent = p.phone; a.style.display = 'block'; a.style.fontWeight = '600'; box.appendChild(a); }
      const ap = document.createElement('div'); ap.style.fontSize = '11px'; ap.style.color = 'var(--tv-meta)'; ap.style.marginTop = '2px';
      ap.textContent = 'Pin marks the ZIP-code area, not the street address.'; box.appendChild(ap);
      if (!p.is_claimed && CLAIM_URL) { const c = document.createElement('a'); c.href = CLAIM_URL + '?listing=' + encodeURIComponent(p.id); c.textContent = 'Own this listing? Claim it'; c.style.display = 'block'; c.style.fontSize = '12px'; box.appendChild(c); }
      return box;
    }

    async function fetchPins(query, loc) {
      if (window.TvMap && TvMap.isOpen()) { TvMap.reload(); return; }   // the full-screen map follows the search
      if (!mapObj) return;
      const mine = ++mapToken;
      setMapNote('Loading pins\u2026');
      try {
        const r = await fetch(`/api/search_listings.php?${searchQS(query, loc)}&view=map`);
        const d = await r.json();
        if (mine !== mapToken) return;
        if (!(r.ok && d.success)) throw new Error(d.error || ('HTTP ' + r.status));
        mapCluster.clearLayers();
        if (mapCircle) { mapObj.removeLayer(mapCircle); mapCircle = null; }
        const markers = d.pins.map(p => {
          const m = L.marker([p.lat, p.lon], { title: p.name, icon: L.divIcon({ className: 'tv-pin' + (p.is_verified ? ' tv-ok' : ''), html: '<span></span>', iconSize: [18, 18], iconAnchor: [9, 9] }) });
          m.bindPopup(() => pinPopup(p));
          return m;
        });
        mapCluster.addLayers(markers);
        if (d.center && !searchWide) {
          mapCircle = L.circle([d.center.lat, d.center.lon], { radius: d.center.radius * 1609.34, color: 'var(--tv-icon,#B45309)', weight: 2, dashArray: '6 6', fillOpacity: 0.05 }).addTo(mapObj);
        }
        if (markers.length) mapObj.fitBounds(mapCluster.getBounds().pad(0.12), { maxZoom: 14 });
        else if (mapCircle) mapObj.fitBounds(mapCircle.getBounds());
        const missing = d.total - d.pins.length;
        let note = d.pins.length.toLocaleString() + ' on the map';
        if (d.truncated) note += '. Showing the first ' + d.pins.length.toLocaleString() + ' of ' + d.total.toLocaleString() + '; narrow the search to see the rest.';
        else if (missing > 0) note += '. ' + missing.toLocaleString() + (missing === 1 ? ' listing has' : ' listings have') + ' no map location yet.';
        if (!d.pins.length) note = 'Nothing to show on the map for this search.';
        setMapNote(note);
      } catch (e) {
        if (mine === mapToken) setMapNote('The map pins could not load (' + e.message + ').');
      }
    }

    const CLAIM_URL = <?= json_encode($claim_url) ?>;

    function renderListings() {
      const searchQuery = document.querySelector('.search').value.trim();

      document.getElementById('results-count').textContent = `${totalListings.toLocaleString()} ${totalListings === 1 ? 'listing' : 'listings'}`;
      renderWidenHint();
      renderResultsSummary();

      // The server already filtered, sorted and paged these.
      const paginated = allListings;

      const listContainer = document.querySelector('.list');
      if (paginated.length === 0) {
        let radius = currentLocation.radius || 10;
        let expandButtonHtml = '';
        const scopeLabel = isRegionLike() ? placeLabel() : '';

        if (isRegionLike()) {
          expandButtonHtml = ''; // a region or state is an area, not a radius: nothing to widen
        } else if (radius < 50) {
          expandButtonHtml = `<button onclick="expandRadiusToTier(50)" class="bg-amber-600/25 hover:bg-amber-600/35 text-[color:var(--tv-link)] border border-amber-600/50 font-medium text-xs px-4 py-2 rounded-lg transition shadow-sm">Expand Search to 50 Miles</button>`;
        } else if (radius < 250) {
          expandButtonHtml = `<button onclick="expandRadiusToTier(250)" class="bg-amber-600/25 hover:bg-amber-600/35 text-[color:var(--tv-link)] border border-amber-600/50 font-medium text-xs px-4 py-2 rounded-lg transition shadow-sm">Expand Search to 250 Miles</button>`;
        }

        listContainer.innerHTML = `
          <li class="col-span-full text-center py-16 px-4 bg-[color-mix(in_srgb,var(--tv-card-b)_60%,transparent)] border border-[color:var(--tv-line-strong)] rounded-xl">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-[color:var(--tv-meta)] mx-auto mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
            <h3 class="text-[color:var(--tv-ink)] font-serif font-bold text-lg mb-1">${hasLocationSet(currentLocation) ? `No listings ${scopeLabel ? 'in' : 'near'} ${escapeHtml(placeLabel())} yet` : 'No listings found'}</h3>
            <p class="text-[color:var(--tv-meta)] text-sm max-w-md mx-auto mb-6 leading-relaxed">
              ${hasLocationSet(currentLocation)
                ? (currentLocation.scope && currentLocation.scope.soon
                    ? 'This region is opening up soon. Add a business now and it will be listed when it does.'
                    : 'Be the first. Add your business, or tell us about one, and it will show up here.')
                : 'Try different words, or add a missing business to the directory.'}
              ${!scopeLabel && hasLocationSet(currentLocation) && radius < 250 ? ' Or widen the distance.' : ''}
            </p>
            ${(didYouMean && searchQuery) ? `<p class="text-sm text-[color:var(--tv-ink)] mb-4">Did you mean <button type="button" onclick="useSuggestion(this.dataset.q)" data-q="${escapeHtml(didYouMean)}" class="font-semibold text-[color:var(--tv-link)] underline">${escapeHtml(didYouMean)}</button>?</p>` : ''}
            <div class="flex flex-wrap justify-center gap-3 items-center">
              ${expandButtonHtml}
              ${CLAIM_URL ? `<a href="${CLAIM_URL}?new=1${hasLocationSet(currentLocation) ? '&near=' + encodeURIComponent(placeLabel()) : ''}" class="bg-[var(--tv-link)] hover:bg-[var(--tv-crimson)] text-white font-semibold text-sm px-5 py-2.5 rounded-lg transition shadow-sm no-underline">+ Add a business${hasLocationSet(currentLocation) ? ' in ' + escapeHtml(placeLabel()) : ''}</a>` : ''}
              ${(searchQuery && document.getElementById('category-filter').value !== 'all') ? `<button onclick="pickCategory('all')" class="bg-[var(--tv-link)] hover:bg-[var(--tv-crimson)] text-white font-medium text-xs px-4 py-2 rounded-lg transition">Search all categories for "${escapeHtml(searchQuery)}"</button>` : ''}
              ${searchQuery ? `<button onclick="clearSearchQuery()" class="bg-[var(--tv-card-b)] hover:bg-[var(--tv-card-b)] text-[color:var(--tv-ink)] border border-[color:var(--tv-line-strong)] font-medium text-xs px-4 py-2 rounded-lg transition">Clear Search ("${escapeHtml(searchQuery)}")</button>` : ''}
              ${hasLocationSet(currentLocation) ? `<button onclick="chooseAnywhere()" class="bg-[var(--tv-link)] hover:bg-[var(--tv-crimson)] text-white font-medium text-xs px-4 py-2 rounded-lg transition">Search everywhere</button>` : ''}
              <button onclick="resetToBrowse()" class="bg-[var(--tv-card-b)] hover:bg-[var(--tv-card-b)] text-[color:var(--tv-ink)] border border-[color:var(--tv-line-strong)] font-medium text-xs px-4 py-2 rounded-lg transition">Start over</button>
            </div>
          </li>
        `;
        document.getElementById('pagination-container').classList.add('hidden');
        return;
      }

      const ICON_PIN = '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 shrink-0 mt-0.5 text-[color:var(--tv-link)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>';
      const ICON_PHONE = '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>';
      listContainer.innerHTML = paginated.map(b => {
        const town = [b.city, b.state].filter(Boolean).join(', ');
        const where = [b.address, town].filter(Boolean).join(', ');
        const dist = (b.distance != null && isPointPlace()) ? ' <span class="text-[color:var(--tv-meta)]">&middot; ' + escapeHtml(String(b.distance)) + ' mi</span>' : '';
        const incomplete = !b.phone || !b.description;
        return `
        <li class="bg-[var(--tv-card-b)] border border-[color:var(--tv-line-strong)] hover:border-amber-600/60 rounded-xl p-5 flex flex-col justify-between transition group shadow-md">
          <div>
            <div class="flex items-start justify-between gap-3">
              <div style="padding-right:2.25rem">
                <h3 class="text-base font-serif font-bold text-[color:var(--tv-ink)] group-hover:text-[color:var(--tv-crimson)] transition leading-snug"><a href="/listing/view.php?id=${encodeURIComponent(b.id)}" class="hover:underline">${escapeHtml(b.business_name)}</a></h3>
                ${b.category ? `<span class="inline-block mt-1 bg-[color-mix(in_srgb,var(--tv-card-b)_60%,transparent)] text-[color:var(--tv-ink)] px-2 py-0.5 rounded text-[10px] font-semibold uppercase">${escapeHtml(b.category)}</span>` : ''}
              </div>
              <span data-link="business:${encodeURIComponent(b.id)}" data-link-label="${escapeHtml(b.business_name)}"></span>
            </div>
            ${where ? `<p class="flex items-start gap-1.5 text-xs text-[color:var(--tv-meta)] mt-2 leading-snug">${ICON_PIN}<span>${escapeHtml(where)}${dist}</span></p>` : ''}
            ${b.phone ? `<a href="tel:${escapeHtml(b.phone)}" class="inline-flex items-center gap-1.5 mt-2 text-sm font-semibold text-[color:color-mix(in_srgb,var(--tv-link)_80%,var(--tv-ink))] hover:text-[color:var(--tv-crimson)] hover:underline">${ICON_PHONE}${escapeHtml(b.phone)}</a>` : ''}
            <p class="text-xs text-[color:var(--tv-meta)] line-clamp-2 leading-relaxed mt-3">${escapeHtml(b.description || (b.is_verified ? 'Verified local business.' : 'This listing hasn\'t been claimed or verified yet.'))}</p>
          </div>
          ${CLAIM_URL ? `<div class="pt-3 mt-3 border-t border-[color:var(--tv-line-strong)] flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px]">
            ${!b.is_claimed ? `<a href="${CLAIM_URL}?listing=${encodeURIComponent(b.id)}" class="text-[color:var(--tv-link)] font-semibold hover:underline">Own this listing? Claim it</a>` : ''}
            ${incomplete ? `<a href="${CLAIM_URL}?listing=${encodeURIComponent(b.id)}&mode=contribute" class="text-[color:var(--tv-meta)] hover:text-[color:var(--tv-ink)] underline decoration-dotted">Know more? Help complete it</a>` : ''}
          </div>` : ''}
        </li>`;
      }).join('');

      renderPagination(totalListings);
    }

    function useSuggestion(q) {
      const searchInput = document.querySelector('.search');
      searchInput.value = q;
      searchWide = false;
      launchSearch(q);
    }

    function clearSearchQuery() {
      const searchInput = document.querySelector('.search');
      searchInput.value = '';
      launchSearch('');
    }

    function renderPagination(totalItems) {
      const totalPages = Math.ceil(totalItems / itemsPerPage);
      const container = document.getElementById('pagination-container');

      if (totalPages <= 1) {
        container.classList.add('hidden');
        return;
      }

      container.classList.remove('hidden');
      let html = '';

      // Previous Arrow Icon Button
      const prevDisabled = currentPage === 1 ? 'opacity-40 cursor-not-allowed' : 'hover:bg-[var(--tv-card-b)]';
      html += `<button onclick="changePage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''} class="p-2 rounded-lg bg-[var(--tv-card-b)] text-[color:var(--tv-ink)] border border-[color:var(--tv-line-strong)] transition ${prevDisabled}" title="Previous Page">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>`;

      if (totalPages <= 10) {
        for (let i = 1; i <= totalPages; i++) {
          const activeClass = i === currentPage ? 'bg-[var(--tv-link)] text-white font-bold' : 'bg-[var(--tv-card-b)] text-[color:var(--tv-ink)] hover:bg-[var(--tv-card-b)] border border-[color:var(--tv-line-strong)]';
          html += `<button onclick="changePage(${i})" class="px-3 py-1.5 rounded-lg text-xs transition ${activeClass}">${i}</button>`;
        }
      } else {
        html += `<span class="px-3 py-1.5 text-xs text-[color:var(--tv-meta)] font-mono">Page ${currentPage} of ${totalPages}</span>`;
      }

      // Next Arrow Icon Button
      const nextDisabled = currentPage === totalPages ? 'opacity-40 cursor-not-allowed' : 'hover:bg-[var(--tv-card-b)]';
      html += `<button onclick="changePage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''} class="p-2 rounded-lg bg-[var(--tv-card-b)] text-[color:var(--tv-ink)] border border-[color:var(--tv-line-strong)] transition ${nextDisabled}" title="Next Page">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>
      </button>`;

      container.innerHTML = html;
    }

    function changePage(p) {
      fetchListings(document.querySelector('.search').value, currentLocation, p);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Under the results: a place is never a trap. One tap searches everywhere.
    function renderWidenHint() {
      const add = document.getElementById('add-hint');
      if (add) {
        add.textContent = '';
        if (CLAIM_URL) {
          add.appendChild(document.createTextNode("We are looking for good local businesses, and you can help us find them. Know one that is missing? "));
          const a = document.createElement('a');
          a.href = CLAIM_URL + '?new=1' + (hasLocationSet(currentLocation) ? '&near=' + encodeURIComponent(placeLabel()) : '');
          a.className = 'text-[color:var(--tv-link)] font-medium underline decoration-dotted';
          a.textContent = 'Add it';
          add.appendChild(a);
          add.classList.remove('hidden');
        } else { add.classList.add('hidden'); }
      }
      const el = document.getElementById('widen-hint');
      if (!el) return;
      el.textContent = '';
      if (!hasLocationSet(currentLocation)) { el.classList.add('hidden'); return; }
      el.appendChild(document.createTextNode('Showing results for ' + placeLabel() + '. Not finding it? '));
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'text-[color:var(--tv-link)] font-medium underline decoration-dotted';
      b.textContent = 'Search everywhere';
      b.addEventListener('click', chooseAnywhere);
      el.appendChild(b);
      el.classList.remove('hidden');
    }

    function escapeHtml(str) {
      if (!str) return '';
      return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }
  </script>
</body>
</html>
