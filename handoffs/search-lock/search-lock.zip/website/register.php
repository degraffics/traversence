<?php require_once __DIR__ . '/../app/ui/auth-nav.php'; require_once __DIR__ . '/../app/ui/social-buttons.php';
// finishing sign-up after Google (decisions/0085), Apple, Microsoft or Facebook (decisions/0090): no email or password
// to type; everything else the same
tv_google_session();   // first, before any output: the settings (.env), the database and the session
$gp = !empty($_GET['google']) ? GoogleAuth::pending() : (!empty($_GET['social']) ? SocialAuth::pending() : null);
if ($gp && !empty($_GET['google'])) $gp += ['provider' => 'google', 'verified' => true];
$gWho = $gp ? ($gp['provider'] === 'google' ? 'Google' : SocialAuth::label((string) $gp['provider'])) : '';
// one page for both (Jason, 2026-11-05): a plain visit opens Create account on the sign-in page; finishing a sign-up that
// started with Google, Apple, Microsoft or Facebook (or saying it expired) stays here
if (empty($_GET['google']) && empty($_GET['social'])) {
    $q = ['tab' => 'create'];
    foreach (['next', 'email', 'name'] as $k) if (isset($_GET[$k]) && is_string($_GET[$k]) && $_GET[$k] !== '') $q[$k] = mb_substr($_GET[$k], 0, 190);
    header('Location: /login.php?' . http_build_query($q), true, 302); exit;
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?= tv_robots_meta() ?>
  <title>Register — Traversence</title>
  <?php tv_nav_head(); ?>
</head>
<body class="bg-[color:var(--tv-canvas)] text-[color:var(--tv-ink)] min-h-screen flex flex-col font-sans">
  <?php tv_nav_bar(); ?>
  <main class="flex-1 flex items-center justify-center py-8">
  <div class="bg-[color:var(--tv-sec)] border border-[color:var(--tv-line-strong)] rounded-2xl p-8 max-w-md w-full mx-[3px] sm:mx-4 shadow-xl">
    <h1 class="text-xl font-serif font-bold mb-6 text-center"><?= $gp ? 'Finish creating your account' : 'Create an Account' ?></h1>
    <?php if ($gp): ?>
    <p class="text-sm text-center mb-3">You signed in with <?= htmlspecialchars($gWho) ?> as <b><?= htmlspecialchars($gp['email']) ?></b>, and there's no Traversence account for that email yet.</p>
    <div class="rounded-lg p-3 mb-4 text-sm" style="background:var(--tv-card-a,#F7F1E3);border:1px solid var(--tv-line-strong,#CBB98D)">
      <p class="font-semibold">Already have a Traversence account?</p>
      <p class="mt-1">Maybe with a different email. Sign in to it, and we'll link this <?= htmlspecialchars($gWho) ?> account to it, so either way signs you in.</p>
      <a href="/login.php?link=1<?= !empty($_GET['next']) ? '&next=' . rawurlencode((string) $_GET['next']) : '' ?>" class="inline-block mt-2 rounded-lg px-3 py-1.5 font-semibold text-white" style="background:var(--tv-btn,#92400E)">Sign in to link it</a>
    </div>
    <p class="text-sm font-semibold mb-2">New to Traversence? Create your account with <?= htmlspecialchars($gWho) ?>:</p>
    <p class="text-xs text-[color:var(--tv-meta)] mb-3"><?= !empty($gp['verified']) ? 'Your email is already confirmed by ' . htmlspecialchars($gWho) . '; there\'s' : 'We\'ll send a link to confirm this email. There\'s' ?> no password to choose (you can add one later with "Forgot password?").</p>
    <?php elseif (!empty($_GET['google']) || !empty($_GET['social'])): ?>
    <p class="text-sm text-center text-red-700 mb-4">That sign-up expired. Try again from the sign-in page.</p>
    <?php endif; ?>
    <form id="register-form" class="space-y-4" data-google="<?= $gp ? '1' : '' ?>" data-endpoint="<?= $gp ? '/api/auth/' . htmlspecialchars((string) $gp['provider']) . '.php' : '' ?>">
      <input type="text" id="display_name" placeholder="Display name (optional)" value="<?= $gp ? htmlspecialchars((string) $gp['name']) : htmlspecialchars(mb_substr((string) ($_GET['name'] ?? ''), 0, 80)) ?>"
             class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
      <?php if (!$gp): ?>
      <input type="email" id="email" placeholder="you@example.com" required value="<?= htmlspecialchars(mb_substr((string) ($_GET['email'] ?? ''), 0, 190)) ?>"
             class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
      <input type="password" id="password" placeholder="Password (10+ characters)" required minlength="10" autocomplete="new-password"
             class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2 text-sm bg-[color:var(--tv-canvas)]">
      <?php endif; ?>
      <label class="flex items-start gap-2 text-sm text-[color:var(--tv-ink)]">
        <input type="checkbox" id="over_18" required class="mt-0.5 accent-amber-700 w-4 h-4">
        <span>I am 18 years old or older. <span class="text-xs text-[color:var(--tv-meta)]">Traversence accounts are for adults, 18 and up.</span></span>
      </label>
      <?php // no Verification question, and the choices come next on their own screens (Jason, 2026-11-05) ?>
      <div id="g_homew" hidden>
        <label class="block text-xs font-semibold text-[color:var(--tv-meta)]" for="g_home">Where do you live?</label>
        <select id="g_home" style="margin-top:.25rem" class="w-full border border-[color:var(--tv-line-strong)] rounded-lg px-3 py-2.5 text-sm bg-[color:var(--tv-card-a)]">
          <option value="">Choose…</option><option value="US">United States</option><option value="CA">Canada</option><option value="MX">Mexico</option>
          <option value="EUUK">A country in the EU or the UK</option><option value="other">Another country</option>
        </select>
      </div>
      <p class="text-xs text-[color:var(--tv-meta)]">By creating an account you accept our <a class="underline" href="/terms.php" target="_blank">Terms of Use</a> and <a class="underline" href="/privacy.php" target="_blank">Privacy Policy</a>.</p>
      <?php if (!$gp) { require_once __DIR__ . '/../app/lib/Captcha.php'; echo Captcha::widget(); } ?>
      <button type="submit" class="w-full bg-[color:var(--tv-umber)] text-[color:var(--tv-on-umber)] rounded-lg py-2 text-sm font-semibold hover:bg-[color:var(--tv-umber)] transition">
        <?= $gp ? 'Create my account' : 'Register' ?>
      </button>
    </form>
    <div id="status" class="text-sm text-center mt-4"></div>
    <?= $gp ? '' : tv_social_buttons('Sign up with', (string) ($_GET['next'] ?? '')) ?>
    <p class="text-xs text-center mt-6 text-[color:var(--tv-meta)]">
      Already have an account? <a href="/login.php" class="text-amber-700 hover:text-amber-600 font-semibold">Sign in</a>
    </p>
  </div>
  </main>
  <?php tv_nav_foot(); ?>
  <script>
    const statusEl = document.getElementById('status');
    let csrfToken = null;

    async function getCsrfToken() {
      const res = await fetch('/api/auth/session.php', { credentials: 'include' });
      const data = await res.json();
      return data.csrf_token;
    }

    document.getElementById('register-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const display_name = document.getElementById('display_name').value;
      const viaGoogle = e.target.getAttribute('data-google') === '1';
      const email = viaGoogle ? '' : document.getElementById('email').value;
      const password = viaGoogle ? '' : document.getElementById('password').value;
      const submitBtn = e.target.querySelector('button[type=submit]');
      submitBtn.disabled = true;
      statusEl.textContent = '';

      try {
        if (!csrfToken) {
          csrfToken = await getCsrfToken();
        }
        const res = await fetch(viaGoogle ? e.target.getAttribute('data-endpoint') : '/api/auth/register.php', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify({ do: viaGoogle ? 'create' : undefined, display_name, email, password, over_18: document.getElementById('over_18').checked, home_country: (!document.getElementById('g_homew').hidden && document.getElementById('g_home').value) || undefined,
            captcha: window.tvCaptchaWait ? await tvCaptchaWait() : (window.tvCaptcha ? tvCaptcha() : '') }),
        });
        const data = await res.json();

        if (data?.error?.code === 'ask_home') {   // decisions/0027: connecting from the EU/UK, so one more question
          document.getElementById('g_homew').hidden = false; document.getElementById('g_home').required = true;
          statusEl.textContent = 'One more question: where do you live?'; statusEl.className = 'text-sm text-center mt-4 text-[color:var(--tv-link)]';
          submitBtn.disabled = false; return;
        }
        if (res.ok && data.ok && viaGoogle) { window.location.href = '/verify-email.php?setup=1&next=' + encodeURIComponent(data.next || '/user/dashboard.php'); return; }   // signed in already: the four questions, then on
        if (res.ok && data.ok) {
          statusEl.textContent = data.message;
          statusEl.className = 'text-sm text-center mt-4 text-green-700';
          document.getElementById('register-form').style.display = 'none';
          // ?next= (e.g. adding your business): confirm the email, then sign in and carry on where you were
          const next = new URLSearchParams(location.search).get('next') || '';
          if (/^\/(?!\/)[^\s\\]*$/.test(next)) {
            const a = document.createElement('a'); a.href = '/login.php?next=' + encodeURIComponent(next); a.className = 'underline font-semibold';
            a.textContent = 'Confirmed your email? Sign in and continue';
            statusEl.appendChild(document.createElement('br')); statusEl.appendChild(a);
          }
        } else {
          window.tvCaptchaReset && tvCaptchaReset();
          statusEl.textContent = data?.error?.message || 'Registration failed.';
          statusEl.className = 'text-sm text-center mt-4 text-red-700';
          submitBtn.disabled = false;
        }
      } catch (err) {
        statusEl.textContent = 'Something went wrong. Please try again.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        submitBtn.disabled = false;
      }
    });
  </script>
</body>
</html>
