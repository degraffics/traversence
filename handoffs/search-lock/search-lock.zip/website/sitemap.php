<?php
// /sitemap.php — the site's sitemap for search engines (2026-11-15: there was none, and no robots.txt pointed to one).
// With no `part`, the sitemap index; its parts: `pages` (the page builder's live pages), `hubs` (each hub's page) and
// `listings&n=<k>` (public listings, 40,000 a file, as the sitemap protocol allows 50,000). Hidden, merged, confidential and
// suppressed listings are never in it. On the staging copy it answers 404, so staging is never offered to a search engine.
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/lib/Staging.php';
if (Staging::here()) { http_response_code(404); exit; }
require_once __DIR__ . '/../app/lib/PlaceScope.php';
require_once __DIR__ . '/../app/lib/ListingSafety.php';

const PER = 40000;
$pdo = Database::connection();
$base = 'https://traversence.com';
$x = fn (string $s) => htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
$day = fn ($t) => $t ? date('Y-m-d', strtotime((string) $t)) : date('Y-m-d');
header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
$pub = implode(',', array_map(fn ($s) => $pdo->quote($s), PlaceScope::PUBLIC_STATUSES));
$part = (string) ($_GET['part'] ?? '');

// The search lock (decisions/0181 §4): the site isn't open to search engines yet, so the sitemap offers nothing until
// Jason lifts it. An empty index, not a 404, so a search engine that already knows the address reads it as "nothing yet".
if (TV_SEARCH_LOCK) {
    echo '<!-- Traversence is not open to search engines yet. This sitemap lists pages once we open the site. -->' . "\n";
    echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></sitemapindex>' . "\n";
    exit;
}

if ($part === '') {
    $n = 0;
    try { $n = (int) $pdo->query("SELECT COUNT(*) FROM entities WHERE entity_type = 'merchant' AND is_suppressed = 0 AND status IN ($pub)")->fetchColumn(); } catch (Throwable) {}
    echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    echo '  <sitemap><loc>' . $x($base . '/sitemap.php?part=pages') . '</loc></sitemap>' . "\n";
    echo '  <sitemap><loc>' . $x($base . '/sitemap.php?part=hubs') . '</loc></sitemap>' . "\n";
    for ($k = 1; $k <= max(1, (int) ceil($n / PER)); $k++) echo '  <sitemap><loc>' . $x($base . '/sitemap.php?part=listings&n=' . $k) . '</loc></sitemap>' . "\n";
    echo '</sitemapindex>' . "\n";
    exit;
}

echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
$url = function (string $path, $mod = null) use ($x, $base, $day) { echo '  <url><loc>' . $x($base . $path) . '</loc><lastmod>' . $day($mod) . '</lastmod></url>' . "\n"; };
try {
    if ($part === 'pages') {
        foreach (['/', '/faq.php', '/our-approach.php', '/plans.php', '/privacy.php', '/terms.php', '/directory/', '/discovery/', '/community/', '/market/'] as $p) $url($p);
        require_once __DIR__ . '/../app/lib/SitePages.php';
        foreach (SitePages::all($pdo) as $p) if ($p['status'] === 'live') $url(SitePages::url($p), $p['updated_at'] ?? null);
    } elseif ($part === 'hubs') {
        foreach ($pdo->query('SELECT slug FROM hubs WHERE slug <> \'\'')->fetchAll(PDO::FETCH_COLUMN) as $s) $url('/hub/?hub=' . rawurlencode((string) $s));
    } elseif ($part === 'listings') {
        $k = max(1, (int) ($_GET['n'] ?? 1));
        $st = $pdo->query("SELECT id, name, category_id, updated_at FROM entities WHERE entity_type = 'merchant' AND is_suppressed = 0 AND status IN ($pub) ORDER BY id LIMIT " . PER . ' OFFSET ' . (($k - 1) * PER));
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            if (ListingSafety::isConfidential($r['category_id'] !== null ? (int) $r['category_id'] : null, (string) $r['name'])) continue;   // a confidential place is never offered
            $url('/listing/view.php?id=' . (int) $r['id'], $r['updated_at']);
        }
    }
} catch (Throwable $e) { error_log('sitemap ' . $part . ': ' . $e->getMessage()); }
echo '</urlset>' . "\n";
