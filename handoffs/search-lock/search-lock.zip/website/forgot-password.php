<?php require_once __DIR__ . '/../app/ui/auth-nav.php'; require_once __DIR__ . '/../app/ui/google-button.php';
tv_google_session();   // the session, to know who's here
// signed in already (site audit P2): their account is where a password is changed
if (Auth::currentUserId()) { header('Location: /user/dashboard.php', true, 302); exit; } ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?= tv_robots_meta() ?>
  <title>Forgot Password — Traversence</title>
  <?php tv_nav_head(); ?>
</head>
<body class="bg-[#EFE3C8] text-[#3E2B1F] min-h-screen flex flex-col font-sans">
  <?php tv_nav_bar(); ?>
  <main class="flex-1 flex items-center justify-center py-8">
  <div class="bg-[#E3D3AC] border border-[#CBB98D] rounded-2xl p-8 max-w-md w-full mx-4 shadow-xl">
    <h1 class="text-xl font-serif font-bold mb-2 text-center">Forgot Your Password?</h1>
    <p class="text-sm text-[#5C4632] text-center mb-6">Enter your account email and we'll send you a reset link.</p>
    <form id="forgot-form" class="space-y-4">
      <input type="email" id="email" placeholder="you@example.com" required
             class="w-full border border-[#CBB98D] rounded-lg px-3 py-2 text-sm bg-[#EFE3C8]">
      <?php require_once __DIR__ . '/../app/lib/Captcha.php'; echo Captcha::widget(); ?>
      <button type="submit" class="w-full bg-[#3E2B1F] text-[#EFE3C8] rounded-lg py-2 text-sm font-semibold hover:bg-[#2A1B12] transition">
        Send Reset Link
      </button>
    </form>
    <div id="status" class="text-sm text-center mt-4"></div>
  </div>
  </main>
  <?php tv_nav_foot(); ?>
  <script>
    const statusEl = document.getElementById('status');
    let csrfToken = null;

    async function getCsrfToken() {
      // A CSRF token is issued to every session on first contact
      // (bootstrap.php), even an anonymous pre-login one — session.php
      // returns it in its response body regardless of login state.
      const res = await fetch('/api/auth/session.php', { credentials: 'include' });
      const data = await res.json();
      return data.csrf_token;
    }

    document.getElementById('forgot-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('email').value;
      const submitBtn = e.target.querySelector('button');
      submitBtn.disabled = true;

      try {
        if (!csrfToken) {
          csrfToken = await getCsrfToken();
        }
        const res = await fetch('/api/auth/password/request-reset.php', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify({ email, captcha: window.tvCaptchaWait ? await tvCaptchaWait() : (window.tvCaptcha ? tvCaptcha() : '') }),
        });
        const data = await res.json();
        if (data?.error?.code === 'captcha') {   // the human check didn't pass: say so, and let them try again
          window.tvCaptchaReset && tvCaptchaReset();
          statusEl.textContent = data.error.message;
          statusEl.className = 'text-sm text-center mt-4 text-red-700';
          submitBtn.disabled = false;
          return;
        }
        // Deliberately shown regardless of whether the account exists —
        // matches request-reset.php's own anti-enumeration design.
        statusEl.textContent = data.message || 'If an account exists for that email, a reset link has been sent.';
        statusEl.className = 'text-sm text-center mt-4 text-green-700';
        document.getElementById('forgot-form').style.display = 'none';
      } catch (err) {
        statusEl.textContent = 'Something went wrong. Please try again.';
        statusEl.className = 'text-sm text-center mt-4 text-red-700';
        submitBtn.disabled = false;
      }
    });
  </script>
</body>
</html>
