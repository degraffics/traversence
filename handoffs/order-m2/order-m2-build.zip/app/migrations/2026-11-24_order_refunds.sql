-- Order management M2 (decisions/0178 §1 and its money note): a refund prepared on an order waits here for Jason's OK
-- (Approve or Decline in Pulse); and a payment recorded here keeps the QuickBooks payment it was received as, so it's
-- known to be processed (Refund…) rather than only recorded (Cancel the record). Add-only; safe to run twice.
CREATE TABLE IF NOT EXISTS order_refund_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  ledger_id INT NULL,
  amount_cents INT NOT NULL,
  reason VARCHAR(400) NOT NULL DEFAULT '',
  revoke_lines VARCHAR(400) NOT NULL DEFAULT '',
  stop_wos VARCHAR(400) NOT NULL DEFAULT '',
  cancel_order TINYINT NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'waiting',
  asked_by INT NULL,
  asked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  asked_tz VARCHAR(60) NULL,
  decided_by INT NULL,
  decided_at DATETIME NULL,
  decided_note VARCHAR(400) NULL,
  result VARCHAR(400) NULL,
  KEY order_status (order_id, status),
  KEY status (status)
) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @s = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE order_ledger ADD COLUMN qb_payment_id VARCHAR(40) DEFAULT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_ledger' AND COLUMN_NAME = 'qb_payment_id');
PREPARE q FROM @s; EXECUTE q; DEALLOCATE PREPARE q;
