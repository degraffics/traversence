<?php
// app/lib/Customers.php — the CRM's customers (business-portal-architecture.md, "admin first"): everyone who has bought
// from an owner, built from their orders and plans, with tags, notes and segments. owner_id 0 is Traversence; a
// business's own customers carry its listing id once the business portal scopes the tools (decisions/0110).
// The tables are the admin's: on first use they're made in the admin database and recorded in data_moves, so
// Database::t() finds them there (or in main, until the admin database is set).
declare(strict_types=1);

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Scope.php';
require_once __DIR__ . '/Billing.php';

require_once __DIR__ . '/Orders.php';

final class Customers
{
    public const TABLES = ['crm_customers', 'crm_tags', 'crm_customer_tags', 'crm_notes', 'crm_sync'];

    /** Segments, worked out from the numbers (never stored): key => [label, icon]. */
    public const SEGMENTS = ['new' => 'New (first 30 days)', 'returning' => 'Returning', 'vip' => 'VIP ($500+)', 'plan' => 'On a plan', 'inactive' => 'Inactive (6 months)', 'lead' => 'No purchase yet'];
    public const SHORT = ['new' => 'New', 'returning' => 'Returning', 'vip' => 'VIP', 'plan' => 'On a plan', 'inactive' => 'Inactive', 'lead' => 'Lead'];
    public const VIP_CENTS = 50000;
    public const STARTER_TAGS = ['Retail', 'Wholesale', 'Client order', 'GO Codes'];

    private static bool $ready = false;

    /** A table's name: ours (Database::t), or a business's tenant view inside the business portal (Scope). */
    public static function t(string $x): string { return Scope::t($x); }

    /** Makes the tables if they aren't anywhere yet: in the admin database when it's set and reachable, else in main. */
    public static function ensure(PDO $pdo): void
    {
        if (self::$ready) return;
        if (Scope::isBusiness()) {   // a business: BusinessData made the tables; its starter tags, once
            $pdo = Scope::pdo($pdo);
            $tg = $pdo->prepare('INSERT IGNORE INTO ' . self::t('crm_tags') . ' (owner_id, name) VALUES (?, ?)');
            if (!(int) $pdo->query('SELECT COUNT(*) FROM ' . self::t('crm_tags'))->fetchColumn()) foreach (self::STARTER_TAGS as $n) $tg->execute([Scope::owner(), $n]);
            self::$ready = true; return;
        }
        try { $pdo->query('SELECT 1 FROM ' . self::t('crm_sync') . ' LIMIT 0'); self::$ready = true; return; } catch (Throwable) {}
        [$adb] = Database::realmConfig('admin');
        $inAdmin = $adb && Database::mainCanSee((string) $adb);
        $q = fn (string $t) => $inAdmin ? '`' . str_replace('`', '', (string) $adb) . '`.`' . $t . '`' : '`' . $t . '`';
        $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci';
        $pdo->exec('CREATE TABLE IF NOT EXISTS ' . $q('crm_customers') . ' (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, owner_id INT UNSIGNED NOT NULL DEFAULT 0, email VARCHAR(190) NOT NULL DEFAULT \'\',
            name VARCHAR(160) NOT NULL DEFAULT \'\', company VARCHAR(160) NOT NULL DEFAULT \'\', phone VARCHAR(40) NOT NULL DEFAULT \'\',
            user_id INT UNSIGNED DEFAULT NULL, entity_id INT UNSIGNED DEFAULT NULL, qb_customer_id VARCHAR(40) NOT NULL DEFAULT \'\',
            first_at DATETIME DEFAULT NULL, last_at DATETIME DEFAULT NULL, orders_n INT UNSIGNED NOT NULL DEFAULT 0, plans_n INT UNSIGNED NOT NULL DEFAULT 0,
            plans_active INT UNSIGNED NOT NULL DEFAULT 0, spent_cents BIGINT NOT NULL DEFAULT 0, refunded_cents BIGINT NOT NULL DEFAULT 0,
            manual TINYINT(1) NOT NULL DEFAULT 0, edited TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
            UNIQUE KEY uq_crm_owner_email (owner_id, email), KEY idx_crm_last (owner_id, last_at))' . $tail);
        $pdo->exec('CREATE TABLE IF NOT EXISTS ' . $q('crm_tags') . ' (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, owner_id INT UNSIGNED NOT NULL DEFAULT 0,
            name VARCHAR(40) NOT NULL, UNIQUE KEY uq_crm_tag (owner_id, name))' . $tail);
        $pdo->exec('CREATE TABLE IF NOT EXISTS ' . $q('crm_customer_tags') . ' (customer_id INT UNSIGNED NOT NULL, tag_id INT UNSIGNED NOT NULL, PRIMARY KEY (customer_id, tag_id), KEY idx_crm_ct_tag (tag_id))' . $tail);
        $pdo->exec('CREATE TABLE IF NOT EXISTS ' . $q('crm_notes') . ' (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, customer_id INT UNSIGNED NOT NULL,
            body TEXT NOT NULL, by_user INT UNSIGNED DEFAULT NULL, created_at DATETIME NOT NULL, KEY idx_crm_notes (customer_id, created_at))' . $tail);
        $pdo->exec('CREATE TABLE IF NOT EXISTS ' . $q('crm_sync') . ' (owner_id INT UNSIGNED NOT NULL PRIMARY KEY, synced_at DATETIME NOT NULL)' . $tail);
        if ($inAdmin) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS data_moves (tbl VARCHAR(64) NOT NULL PRIMARY KEY, realm VARCHAR(16) NOT NULL, moved_at DATETIME NOT NULL, rows_moved INT UNSIGNED NOT NULL DEFAULT 0)
                        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
            $st = $pdo->prepare("INSERT IGNORE INTO data_moves (tbl, realm, moved_at, rows_moved) VALUES (?, 'admin', NOW(), 0)");
            foreach (self::TABLES as $t) $st->execute([$t]);
            Database::forgetMoves();
        }
        $tg = $pdo->prepare('INSERT IGNORE INTO ' . self::t('crm_tags') . ' (owner_id, name) VALUES (0, ?)');
        foreach (self::STARTER_TAGS as $n) $tg->execute([$n]);
        self::$ready = true;
    }

    /** Brings the customer list up to date from orders and plans, when either has changed since the last time. */
    public static function sync(PDO $pdo, bool $force = false): int
    {
        if (Scope::isBusiness()) return 0;   // a business's customers come from its own orders, with its checkout (a later step)
        self::ensure($pdo);
        $last = $pdo->query('SELECT synced_at FROM ' . self::t('crm_sync') . ' WHERE owner_id = 0')->fetchColumn();
        $changed = (string) $pdo->query("SELECT GREATEST(COALESCE((SELECT MAX(updated_at) FROM orders), '2000-01-01'), COALESCE((SELECT MAX(updated_at) FROM subscriptions), '2000-01-01'),
                                          COALESCE((SELECT MAX(created_at) FROM order_ledger), '2000-01-01'), COALESCE((SELECT MAX(created_at) FROM subscription_charges), '2000-01-01'))")->fetchColumn();
        try { $changed = max($changed, (string) $pdo->query('SELECT COALESCE(MAX(created_at), \'2000-01-01\') FROM site_form_entries')->fetchColumn()); } catch (Throwable) {}   // the site's forms (SitePages)
        require_once __DIR__ . '/PageCache.php';
        $once = PageCache::get($pdo, 'crm:no-test-orders') === null;   // once after this update: test orders come out of the numbers
        if (!$force && !$once && $last && $changed <= (string) $last) return 0;
        if ($once) PageCache::remember($pdo, 'crm:no-test-orders', 86400 * 3650, fn () => 1);
        $now = date('Y-m-d H:i:s');

        $c = [];   // email => what we know
        $add = function (string $email, array $x) use (&$c) {
            $e = strtolower(trim($email)); if ($e === '' || !str_contains($e, '@')) return;
            $r = $c[$e] ?? ['name' => '', 'company' => '', 'phone' => '', 'user_id' => null, 'entity_id' => null, 'qb' => '', 'first' => null, 'last' => null, 'orders' => 0, 'plans' => 0, 'active' => 0, 'spent' => 0, 'refunded' => 0];
            foreach (['name', 'company', 'phone', 'qb'] as $k) if (($x[$k] ?? '') !== '' && $x[$k] !== null) $r[$k] = (string) $x[$k];
            foreach (['user_id', 'entity_id'] as $k) if (!empty($x[$k])) $r[$k] = (int) $x[$k];
            foreach (['orders', 'plans', 'active', 'spent', 'refunded'] as $k) $r[$k] += (int) ($x[$k] ?? 0);
            if (!empty($x['at'])) { $r['first'] = $r['first'] === null || $x['at'] < $r['first'] ? $x['at'] : $r['first']; $r['last'] = $r['last'] === null || $x['at'] > $r['last'] ? $x['at'] : $r['last']; }
            $c[$e] = $r;
        };

        // orders that went to the customer (not drafts or voided ones), oldest first so the latest details win. Never a
        // test: a sandbox order, or a "Test copy, billed to you" (named "TEST · …"), isn't a sale (2026-11-10: a test copy of
        // a $16,725 order showed as a VIP customer)
        $noTest = " AND bill_name NOT LIKE 'TEST · %'";
        try { $pdo->query('SELECT qb_env FROM orders LIMIT 0'); $noTest .= " AND (qb_env IS NULL OR qb_env NOT IN ('sandbox', 'mock'))"; } catch (Throwable) {}
        $led = [];
        foreach ($pdo->query("SELECT order_id, SUM(CASE WHEN kind IN ('charge','deposit','chargeback_reversed') THEN amount_cents WHEN kind IN ('refund','chargeback','payment_cancelled') THEN -amount_cents ELSE 0 END) net,
                                     SUM(CASE WHEN kind = 'refund' THEN amount_cents ELSE 0 END) ref FROM order_ledger GROUP BY order_id") as $r) $led[(int) $r['order_id']] = [(int) $r['net'], (int) $r['ref']];
        foreach ($pdo->query("SELECT id, user_id, bill_email, bill_name, client_company, client_phone, qb_customer_id, created_at FROM orders WHERE status NOT IN ('draft', 'void') AND bill_email <> ''" . $noTest . " ORDER BY id") as $o) {
            [$net, $ref] = $led[(int) $o['id']] ?? [0, 0];
            $add((string) $o['bill_email'], ['name' => $o['bill_name'], 'company' => $o['client_company'], 'phone' => $o['client_phone'] ?? '', 'user_id' => $o['user_id'], 'qb' => $o['qb_customer_id'] ?? '',
                'orders' => 1, 'spent' => $net, 'refunded' => $ref, 'at' => $o['created_at']]);
        }
        // plans: the payer, with what their renewals brought in
        $paid = [];
        foreach ($pdo->query("SELECT sub_id, SUM(amount_cents) c FROM subscription_charges WHERE status = 'paid' GROUP BY sub_id") as $r) $paid[(int) $r['sub_id']] = (int) $r['c'];
        foreach ($pdo->query("SELECT s.id, s.owner_type, s.owner_id, s.status, s.payer_id, s.bill_name, s.bill_email, s.created_at, u.email AS u_email, u.display_name
                                FROM subscriptions s LEFT JOIN users u ON u.id = s.payer_id ORDER BY s.id") as $s) {
            $email = (string) ($s['bill_email'] ?: $s['u_email']);
            $add($email, ['name' => $s['bill_name'] ?: $s['display_name'], 'user_id' => $s['payer_id'], 'entity_id' => $s['owner_type'] === 'listing' ? $s['owner_id'] : null,
                'plans' => 1, 'active' => in_array($s['status'], ['active', 'trial', 'past_due'], true) ? 1 : 0, 'spent' => $paid[(int) $s['id']] ?? 0, 'at' => $s['created_at']]);
        }

        // people who wrote through a form on our pages: leads until they buy (no purchase dates or numbers)
        try {
            foreach ($pdo->query("SELECT name, email, phone FROM site_form_entries WHERE owner_id = 0 AND status <> 'spam' ORDER BY id") as $f) $add((string) $f['email'], ['name' => $f['name'], 'phone' => $f['phone']]);
        } catch (Throwable) {}

        // write: details we found fill in what's blank or not edited by hand; the numbers are always replaced
        $up = $pdo->prepare('INSERT INTO ' . self::t('crm_customers') . ' (owner_id, email, name, company, phone, user_id, entity_id, qb_customer_id, first_at, last_at, orders_n, plans_n, plans_active, spent_cents, refunded_cents, created_at, updated_at)
            VALUES (0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE name = IF(edited = 1 AND name <> \'\', name, VALUES(name)), company = IF(edited = 1 AND company <> \'\', company, VALUES(company)),
              phone = IF(edited = 1 AND phone <> \'\', phone, VALUES(phone)), user_id = COALESCE(VALUES(user_id), user_id), entity_id = COALESCE(VALUES(entity_id), entity_id),
              qb_customer_id = IF(VALUES(qb_customer_id) <> \'\', VALUES(qb_customer_id), qb_customer_id), first_at = VALUES(first_at), last_at = VALUES(last_at),
              orders_n = VALUES(orders_n), plans_n = VALUES(plans_n), plans_active = VALUES(plans_active), spent_cents = VALUES(spent_cents), refunded_cents = VALUES(refunded_cents), updated_at = VALUES(updated_at)');
        foreach ($c as $e => $r) $up->execute([$e, mb_substr($r['name'], 0, 160), mb_substr($r['company'], 0, 160), mb_substr($r['phone'], 0, 40), $r['user_id'], $r['entity_id'], $r['qb'],
            $r['first'], $r['last'], $r['orders'], $r['plans'], $r['active'], $r['spent'], $r['refunded'], $now, $now]);
        // someone whose only order was voided since: their numbers go back to nothing (the record, notes and tags stay)
        $keep = array_keys($c);
        $gone = $pdo->query('SELECT id, email FROM ' . self::t('crm_customers') . ' WHERE owner_id = 0 AND (orders_n > 0 OR plans_n > 0)')->fetchAll(PDO::FETCH_KEY_PAIR);
        $z = $pdo->prepare('UPDATE ' . self::t('crm_customers') . ' SET orders_n = 0, plans_n = 0, plans_active = 0, spent_cents = 0, refunded_cents = 0, updated_at = ? WHERE id = ?');
        foreach ($gone as $id => $e) if (!isset($c[$e])) $z->execute([$now, $id]);
        $pdo->prepare('INSERT INTO ' . self::t('crm_sync') . ' (owner_id, synced_at) VALUES (0, ?) ON DUPLICATE KEY UPDATE synced_at = VALUES(synced_at)')->execute([$now]);
        return count($c);
    }

    /** The segments a customer is in. */
    public static function segments(array $r): array
    {
        $s = [];
        $buys = (int) $r['orders_n'] + (int) $r['plans_n'];
        if (!$buys) $s[] = 'lead';
        if ($r['first_at'] && strtotime((string) $r['first_at']) > time() - 30 * 86400 && $buys) $s[] = 'new';
        if ((int) $r['orders_n'] >= 2 || ((int) $r['orders_n'] && (int) $r['plans_n'])) $s[] = 'returning';
        if ((int) $r['spent_cents'] >= self::VIP_CENTS) $s[] = 'vip';
        if ((int) $r['plans_active'] > 0) $s[] = 'plan';
        if ($buys && !(int) $r['plans_active'] && $r['last_at'] && strtotime((string) $r['last_at']) < time() - 180 * 86400) $s[] = 'inactive';
        return $s;
    }

    /** All of an owner's customers, with their tags, newest activity first. */
    public static function all(PDO $pdo, int $owner = 0, string $q = '', int $tag = 0): array
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        self::ensure($pdo);
        $w = ['c.owner_id = ?', "NOT (c.name LIKE 'TEST · %' AND c.orders_n = 0 AND c.plans_n = 0)"]; $a = [$owner];   // a test copy's leftover record
        if ($q !== '') { $w[] = '(c.email LIKE ? OR c.name LIKE ? OR c.company LIKE ? OR c.phone LIKE ?)'; array_push($a, "%$q%", "%$q%", "%$q%", "%$q%"); }
        if ($tag) { $w[] = 'EXISTS (SELECT 1 FROM ' . self::t('crm_customer_tags') . ' x WHERE x.customer_id = c.id AND x.tag_id = ?)'; $a[] = $tag; }
        $st = $pdo->prepare('SELECT c.*, (SELECT GROUP_CONCAT(t.name ORDER BY t.name SEPARATOR \', \') FROM ' . self::t('crm_customer_tags') . ' ct JOIN ' . self::t('crm_tags') . ' t ON t.id = ct.tag_id WHERE ct.customer_id = c.id) AS tags
                               FROM ' . self::t('crm_customers') . ' c WHERE ' . implode(' AND ', $w) . ' ORDER BY COALESCE(c.last_at, c.created_at) DESC, c.id DESC LIMIT 2000');
        $st->execute($a);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function get(PDO $pdo, int $id, int $owner = 0): ?array
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT * FROM ' . self::t('crm_customers') . ' WHERE id = ? AND owner_id = ?'); $st->execute([$id, $owner]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if (!$r) return null;
        $r['tag_ids'] = array_map('intval', self::col($pdo, 'SELECT tag_id FROM ' . self::t('crm_customer_tags') . ' WHERE customer_id = ?', [$id]));
        return $r;
    }

    /** The owner's tags: id => name. */
    public static function tags(PDO $pdo, int $owner = 0): array
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT id, name FROM ' . self::t('crm_tags') . ' WHERE owner_id = ? ORDER BY name'); $st->execute([$owner]);
        return array_map('strval', $st->fetchAll(PDO::FETCH_KEY_PAIR));
    }

    /** How many customers carry each tag. */
    public static function tagCounts(PDO $pdo, int $owner = 0): array
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        self::ensure($pdo);
        $st = $pdo->prepare('SELECT ct.tag_id, COUNT(*) FROM ' . self::t('crm_customer_tags') . ' ct JOIN ' . self::t('crm_customers') . ' c ON c.id = ct.customer_id WHERE c.owner_id = ? GROUP BY ct.tag_id'); $st->execute([$owner]);
        return array_map('intval', $st->fetchAll(PDO::FETCH_KEY_PAIR));
    }

    /** Adds someone by hand (a lead, or a customer from before the site). */
    public static function create(PDO $pdo, array $in, int $owner = 0): int
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        self::ensure($pdo);
        $email = strtolower(trim((string) ($in['email'] ?? '')));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('That email doesn\'t look right.');
        $st = $pdo->prepare('SELECT id FROM ' . self::t('crm_customers') . ' WHERE owner_id = ? AND email = ?'); $st->execute([$owner, $email]);
        if ($id = (int) $st->fetchColumn()) throw new InvalidArgumentException('That email is already a customer (#' . $id . ').');
        $now = date('Y-m-d H:i:s');
        $pdo->prepare('INSERT INTO ' . self::t('crm_customers') . ' (owner_id, email, name, company, phone, manual, edited, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 1, ?, ?)')
            ->execute([$owner, $email, mb_substr(trim((string) ($in['name'] ?? '')), 0, 160), mb_substr(trim((string) ($in['company'] ?? '')), 0, 160), mb_substr(trim((string) ($in['phone'] ?? '')), 0, 40), $now, $now]);
        return (int) $pdo->lastInsertId();
    }

    /** Edits the name, company and phone; from then on the orders don't overwrite them. */
    public static function edit(PDO $pdo, int $id, array $in, int $owner = 0): void
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        $pdo->prepare('UPDATE ' . self::t('crm_customers') . ' SET name = ?, company = ?, phone = ?, edited = 1, updated_at = NOW() WHERE id = ? AND owner_id = ?')
            ->execute([mb_substr(trim((string) ($in['name'] ?? '')), 0, 160), mb_substr(trim((string) ($in['company'] ?? '')), 0, 160), mb_substr(trim((string) ($in['phone'] ?? '')), 0, 40), $id, $owner]);
    }

    /** Sets a customer's tags to these ids, plus a new one by name if given. */
    public static function setTags(PDO $pdo, int $id, array $tagIds, string $newTag = '', int $owner = 0): void
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        if (!self::get($pdo, $id, $owner)) throw new InvalidArgumentException('That customer isn\'t here.');
        $mine = self::tags($pdo, $owner);
        $ids = array_values(array_filter(array_map('intval', $tagIds), fn ($t) => isset($mine[$t])));
        $newTag = trim(preg_replace('/\s+/', ' ', $newTag));
        if ($newTag !== '') {
            if (mb_strlen($newTag) > 40) throw new InvalidArgumentException('Keep a tag under 40 letters.');
            $pdo->prepare('INSERT IGNORE INTO ' . self::t('crm_tags') . ' (owner_id, name) VALUES (?, ?)')->execute([$owner, $newTag]);
            $st = $pdo->prepare('SELECT id FROM ' . self::t('crm_tags') . ' WHERE owner_id = ? AND name = ?'); $st->execute([$owner, $newTag]);
            $ids[] = (int) $st->fetchColumn();
        }
        $pdo->prepare('DELETE FROM ' . self::t('crm_customer_tags') . ' WHERE customer_id = ?')->execute([$id]);
        $ins = $pdo->prepare('INSERT IGNORE INTO ' . self::t('crm_customer_tags') . ' (customer_id, tag_id) VALUES (?, ?)');
        foreach (array_unique($ids) as $t) $ins->execute([$id, $t]);
    }

    public static function addNote(PDO $pdo, int $id, string $body, int $uid, int $owner = 0): void
    {
        $pdo = Scope::pdo($pdo); $owner = $owner ?: Scope::owner();
        $body = trim($body);
        if ($body === '') throw new InvalidArgumentException('Write the note first.');
        if (!self::get($pdo, $id, $owner)) throw new InvalidArgumentException('That customer isn\'t here.');
        $pdo->prepare('INSERT INTO ' . self::t('crm_notes') . ' (customer_id, body, by_user, created_at) VALUES (?, ?, ?, NOW())')->execute([$id, mb_substr($body, 0, 4000), $uid ?: null]);
    }

    /** What happened with this customer, newest first: notes, orders, plans and their charges. [at, kind, text, by, link] */
    public static function activity(PDO $pdo, array $c): array
    {
        $out = [];
        if (Scope::isBusiness()) {   // a business sees its own notes (its team's names come from the router); its orders join this with its checkout
            $st = Scope::pdo($pdo)->prepare('SELECT body, created_at, by_user FROM ' . self::t('crm_notes') . ' WHERE customer_id = ? ORDER BY id DESC LIMIT 100');
            $st->execute([(int) $c['id']]);
            foreach ($st as $n) $out[] = [$n['created_at'], 'note', $n['body'], Scope::person((int) $n['by_user']), ''];
            return $out;
        }
        $st = $pdo->prepare('SELECT n.body, n.created_at, COALESCE(u.display_name, u.email) AS who FROM ' . self::t('crm_notes') . ' n LEFT JOIN users u ON u.id = n.by_user WHERE n.customer_id = ? ORDER BY n.id DESC LIMIT 100');
        $st->execute([(int) $c['id']]);
        foreach ($st as $n) $out[] = [$n['created_at'], 'note', $n['body'], (string) $n['who'], ''];
        $st = $pdo->prepare("SELECT id, status, total_cents, created_by, created_at FROM orders WHERE LOWER(bill_email) = ? AND status NOT IN ('draft', 'void') ORDER BY id DESC LIMIT 100");
        $st->execute([$c['email']]);
        foreach ($st as $o) $out[] = [$o['created_at'], 'order', 'Order #' . Orders::no($o) . ' · ' . ucfirst(str_replace('_', ' ', (string) $o['status'])) . ' · $' . number_format($o['total_cents'] / 100, 2), '', $o['created_by'] ? '/admin/backoffice/orders/' . $o['id'] : '/admin/order.php?id=' . $o['id']];
        $st = $pdo->prepare('SELECT s.id, s.plan, s.status, s.created_at FROM subscriptions s LEFT JOIN users u ON u.id = s.payer_id WHERE LOWER(COALESCE(NULLIF(s.bill_email, \'\'), u.email)) = ? ORDER BY s.id DESC LIMIT 50');
        $st->execute([$c['email']]);
        foreach ($st as $s) {
            $out[] = [$s['created_at'], 'plan', (class_exists('Billing') && isset(Billing::PLANS[$s['plan']]) ? Billing::PLANS[$s['plan']][0] : ucfirst(str_replace('_', ' ', (string) $s['plan']))) . ' plan · ' . ucfirst(str_replace('_', ' ', (string) $s['status'])), '', ''];
            $ch = $pdo->prepare("SELECT kind, amount_cents, created_at FROM subscription_charges WHERE sub_id = ? AND status = 'paid' ORDER BY id DESC LIMIT 24"); $ch->execute([(int) $s['id']]);
            foreach ($ch as $x) $out[] = [$x['created_at'], 'charge', ucfirst((string) $x['kind']) . ' · $' . number_format($x['amount_cents'] / 100, 2), '', ''];
        }
        try {
            $st = $pdo->prepare("SELECT e.message, e.created_at, e.status, p.title FROM site_form_entries e LEFT JOIN site_pages p ON p.id = e.page_id WHERE e.owner_id = 0 AND e.email = ? AND e.status <> 'spam' ORDER BY e.id DESC LIMIT 50");
            $st->execute([$c['email']]);
            foreach ($st as $f) $out[] = [$f['created_at'], 'form', 'Wrote on ' . ($f['title'] ?: 'a page') . ":\n" . $f['message'], '', ''];
        } catch (Throwable) {}
        usort($out, fn ($a, $b) => strcmp((string) $b[0], (string) $a[0]));
        return $out;
    }

    private static function col(PDO $pdo, string $sql, array $a): array { $st = $pdo->prepare($sql); $st->execute($a); return $st->fetchAll(PDO::FETCH_COLUMN); }
}
